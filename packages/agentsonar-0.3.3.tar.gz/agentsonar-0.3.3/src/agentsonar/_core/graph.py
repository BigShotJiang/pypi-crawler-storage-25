"""
CoordinationGraph — thin wrapper around NetworkX DiGraph for agent interaction tracking.

Framework-agnostic — no imports from _integrations/ or _output/.
"""
from __future__ import annotations

import networkx as nx


class CoordinationGraph:
    """Directed graph tracking agent-to-agent interactions.

    Each edge carries:
      - `count`          number of interactions (incremented on every add_event)
      - `total_tokens`   estimated token cost of those interactions
      - `first_ts`       timestamp of the first interaction on this edge
                         (None if add_event was ever called without a timestamp)
      - `last_ts`        timestamp of the most recent interaction on this edge

    The `first_ts` / `last_ts` fields power the Run Activity view in the
    HTML report — they let the renderer show "edge X fired N times between
    T0 and T1" even on clean runs that produced no coordination alerts.
    """

    def __init__(self) -> None:
        self._graph = nx.DiGraph()

    @property
    def graph(self) -> nx.DiGraph:
        """Raw NetworkX DiGraph for direct access by detectors."""
        return self._graph

    def add_event(
        self,
        src: str,
        tgt: str,
        tokens: int = 0,
        timestamp: float | None = None,
    ) -> int:
        """Record an interaction edge. Returns the new edge count.

        `timestamp` is optional so legacy call sites (tests, older adapters)
        keep working unchanged — when omitted, `first_ts` and `last_ts`
        stay None for that edge. Real ingestion paths always pass the
        event timestamp.
        """
        if self._graph.has_edge(src, tgt):
            self._graph[src][tgt]["count"] += 1
            if timestamp is not None:
                # Only overwrite last_ts with a real timestamp. Don't
                # clobber a previously-set last_ts with None if a caller
                # later forgets to pass it.
                self._graph[src][tgt]["last_ts"] = timestamp
                # Back-fill first_ts if this edge was first created
                # without a timestamp (legacy path) — we'd rather have
                # a somewhat-late first_ts than None forever.
                if self._graph[src][tgt].get("first_ts") is None:
                    self._graph[src][tgt]["first_ts"] = timestamp
        else:
            self._graph.add_edge(
                src,
                tgt,
                count=1,
                total_tokens=0,
                first_ts=timestamp,
                last_ts=timestamp,
            )
        self._graph[src][tgt]["total_tokens"] += tokens
        return self._graph[src][tgt]["count"]

    def get_edge_count(self, src: str, tgt: str) -> int:
        if self._graph.has_edge(src, tgt):
            return self._graph[src][tgt]["count"]
        return 0

    def has_edge(self, src: str, tgt: str) -> bool:
        return self._graph.has_edge(src, tgt)

    def has_node(self, node: str) -> bool:
        return self._graph.has_node(node)

    def edges_data(self) -> list[tuple[str, str, dict]]:
        return list(self._graph.edges(data=True))

    def edge_activity_summary(self) -> list[dict]:
        """Per-edge activity records for the Run Activity view.

        Returns a list of dicts with keys:
          - source, target   the directed edge
          - count            total number of interactions on this edge
          - first_ts         timestamp of the first interaction (or None)
          - last_ts          timestamp of the most recent interaction (or None)

        Sorted by `last_ts` descending so the hottest / most-recent edges
        float to the top of the rendered table. Edges with no timestamp
        (legacy call sites) sort to the bottom.
        """
        records: list[dict] = []
        for u, v, d in self._graph.edges(data=True):
            records.append(
                {
                    "source": u,
                    "target": v,
                    "count": d.get("count", 0),
                    "first_ts": d.get("first_ts"),
                    "last_ts": d.get("last_ts"),
                }
            )
        # `or -inf` so None / missing timestamps sort to the bottom.
        records.sort(key=lambda r: r.get("last_ts") or float("-inf"), reverse=True)
        return records
