"""
AgentSonar proprietary event schema — v0.1.0

This module defines the vocabulary developers use to talk about multi-agent
coordination failures. It's the contract between AgentSonar and the outside
world: every output format (JSON, HTML, terminal) and every future integration
(webhook, dashboard, CLI) consumes this schema.

Design principles:
- frozen dataclasses, no Pydantic (minimize dependencies)
- all schema blocks except identity fields are Optional — a cyclic_delegation
  event has topology/thresholds, a resource_exhaustion event has provider_error
- to_dict() strips None fields for clean JSON output
- v0.1.0 intentionally omits token/cost/velocity data (not yet implemented)
"""
from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, fields, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from agentsonar._core.constants import SCHEMA_VERSION
from agentsonar._core.models import Alert


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class FailureClass(Enum):
    """Every coordination failure AgentSonar can detect.

    These names become the vocabulary developers use. Values defined now
    even when detectors don't exist yet, so schema consumers can be
    forward-compatible.
    """
    CYCLIC_DELEGATION = "cyclic_delegation"
    REPETITIVE_DELEGATION = "repetitive_delegation"
    TOKEN_VELOCITY_ANOMALY = "token_velocity_anomaly"
    CASCADE_FAILURE = "cascade_failure"
    AUTHORITY_VIOLATION = "authority_violation"   # Post-MVP, enum slot only
    RESOURCE_EXHAUSTION = "resource_exhaustion"
    DEADLOCK = "deadlock"                         # Post-MVP, enum slot only
    AGENT_STALL = "agent_stall"                   # Post-MVP, enum slot only


class AlertSeverity(Enum):
    """Wraps the existing Alert.severity strings from models.py."""
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"

    @classmethod
    def from_string(cls, s: str | None) -> AlertSeverity:
        """Convert an Alert.severity string to the enum value.

        Defensive against non-string inputs and unknown severities: the
        schema's `_fallback_event` path calls this with whatever severity
        the upstream Alert carried, and a future detector emitting a
        novel severity (or a buggy one emitting None) should NOT break
        fault isolation by crashing the fallback builder itself. Unknown
        or null severities degrade to INFO — the lowest severity — so
        the event is still captured and surfaced, just marked
        non-actionable until the upstream is fixed.
        """
        if s is None:
            return cls.INFO
        try:
            return cls(str(s).upper())
        except (ValueError, AttributeError):
            return cls.INFO


# ---------------------------------------------------------------------------
# Schema building blocks (all frozen, all Optional on CoordinationEvent)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Topology:
    """The shape of the coordination failure in the interaction graph.

    `interaction_pattern` already tells consumers the shape of the failure
    (`"circular"`, `"one_directional"`, `"strongly_connected_component"`,
    `"throttled"`, ...) — there used to be a `detection_method` field that
    leaked AgentSonar's internal layer names ("incremental" / "scc_sweep")
    into the public JSON/HTML output. That's an implementation detail; users
    care WHAT was detected, not WHICH layer detected it. Removed in favor
    of `interaction_pattern`, which carries the same information in
    user-facing terms.
    """
    agents_involved: tuple[str, ...]
    # "circular", "one_directional", "fan_out", "stall",
    # "strongly_connected_component", "throttled"
    interaction_pattern: str
    # Number of distinct agents in the failure. For a 3-node cycle A→B→C→A
    # this is 3; for a one-directional edge A→B this is 2. Renamed from the
    # old `delegation_depth` because "depth" was misleading — it implied a
    # nested structure that doesn't exist.
    agent_count: int
    # Times the pattern was observed: rotations for cycles, events for
    # repetitive edges.
    occurrence_count: int
    # Maps "agent_a->agent_b" to the number of times that edge was traversed.
    edge_frequency: dict[str, int]


@dataclass(frozen=True)
class Thresholds:
    """Where the failure sits relative to configured thresholds."""
    warning_at: int
    critical_at: int
    current_value: int
    headroom_remaining: int


@dataclass(frozen=True)
class ProviderError:
    """Details about a resource exhaustion event (rate limit, timeout, etc.)."""
    error_type: str                              # "rate_limit_exceeded", "context_overflow", "timeout"
    retry_after_seconds: int | None = None


@dataclass(frozen=True)
class DownstreamImpact:
    """Which agents are affected by a resource exhaustion or cascade."""
    blocked_agents: tuple[str, ...]
    estimated_delay_seconds: float
    cascade_risk_score: float


# ---------------------------------------------------------------------------
# The main event
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CoordinationEvent:
    """The single structured event AgentSonar emits for every detection.

    Every output format renders from this. Every future integration consumes
    this. All schema blocks except identity fields are Optional — not every
    failure class populates every block.

    v0.1.0 intentionally has NO cost_impact, risk_assessment, or
    recommendations fields. These may be added in future schema bumps.
    """
    # Identity (required)
    schema_version: str
    event_id: str
    session_id: str
    timestamp: float

    # Classification (required)
    event_type: str
    failure_class: FailureClass
    severity: AlertSeverity

    # Stable hash of the failure pattern — same agents always produce the
    # same fingerprint regardless of detection time. Used for dedup and trending.
    coordination_fingerprint: str

    # Optional schema blocks (populated based on failure_class)
    topology: Topology | None = None
    thresholds: Thresholds | None = None
    provider_error: ProviderError | None = None
    downstream_impact: DownstreamImpact | None = None

    # Human-readable one-liner (placed late in field order because Python
    # dataclasses require default-valued fields to come after required ones;
    # to_dict() below outputs it early in the serialized form for readability)
    summary: str = ""

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict.

        Output order is controlled here — `summary` appears right after
        `session_id` so humans scanning the JSON see the one-liner first.
        Optional blocks are omitted when None.

        Two timestamp fields are emitted for every event:
          * `timestamp`      — raw Unix epoch float (microsecond precision,
                               machine-friendly, sortable, math-safe)
          * `timestamp_iso`  — ISO 8601 UTC string with microseconds
                               (human-friendly; e.g. "2026-04-10T22:35:22.789123+00:00")
        """
        result: dict[str, Any] = {
            "schema_version": self.schema_version,
            "event_id": self.event_id,
            "session_id": self.session_id,
            "summary": self.summary,
            "timestamp": self.timestamp,
            "timestamp_iso": _timestamp_to_iso(self.timestamp),
            "event_type": self.event_type,
            "failure_class": self.failure_class.value,
            "severity": self.severity.value,
            "coordination_fingerprint": self.coordination_fingerprint,
        }
        if self.topology is not None:
            result["topology"] = _convert_to_dict(self.topology)
        if self.thresholds is not None:
            result["thresholds"] = _convert_to_dict(self.thresholds)
        if self.provider_error is not None:
            result["provider_error"] = _convert_to_dict(self.provider_error)
        if self.downstream_impact is not None:
            result["downstream_impact"] = _convert_to_dict(self.downstream_impact)
        return result

    def to_json(self, indent: int = 2) -> str:
        """Serialize to a JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

def _timestamp_to_iso(ts: float) -> str:
    """Format a Unix epoch float as an ISO 8601 UTC string with microseconds.

    Defensive: falls back to the raw string if the value isn't convertible
    (e.g. NaN, None, or already a string). Never raises — this is called
    from to_dict() during serialization and a failure here would blow up
    report generation.
    """
    try:
        dt = datetime.fromtimestamp(float(ts), tz=timezone.utc)
        return dt.isoformat()
    except (ValueError, OSError, TypeError, OverflowError):
        return str(ts)


def _convert_to_dict(obj: Any) -> Any:
    """Recursive converter for to_dict().

    Two stripping rules:
      * `None` field values are omitted entirely (the block
        serializer's None check). Optional schema blocks like
        `provider_error` stay absent rather than rendering as `null`.
      * `None` dict values are dropped (keeps nested kv pairs clean).

    We do NOT strip empty lists/tuples anymore. The previous version
    did — originally to hide an empty `recommendations=()` field
    that no longer exists in the schema — but stripping empty
    `agents_involved=()` silently hid a meaningful field from
    consumers who need to distinguish "no agents" from "field
    missing". JSON consumers already handle empty arrays correctly;
    we shouldn't be losing information here.
    """
    if obj is None:
        return None
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, (tuple, list)):
        return [_convert_to_dict(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _convert_to_dict(v) for k, v in obj.items() if v is not None}
    if is_dataclass(obj):
        result: dict[str, Any] = {}
        for f in fields(obj):
            value = getattr(obj, f.name)
            if value is None:
                continue
            result[f.name] = _convert_to_dict(value)
        return result
    return obj


# ---------------------------------------------------------------------------
# Fingerprint helper
# ---------------------------------------------------------------------------

def compute_fingerprint(
    failure_class: FailureClass,
    agents: list[str],
    ordered: bool = False,
) -> str:
    """Compute a stable coordination fingerprint.

    Args:
        failure_class: The kind of failure being fingerprinted.
        agents: The agents involved in the failure.
        ordered: If False (default), treat the agent collection as an
            unordered SET — de-duplicate and sort alphabetically so
            the same cycle produces the same fingerprint regardless
            of which agent the traversal started at (and regardless
            of whether the path visits an agent multiple times).
            Correct for CYCLIC_DELEGATION and SCCs, which are
            orbit-equivalent.
            If True, preserve agent order and multiplicity so
            directional problems stay distinct — e.g. A→B
            repetitive spam and B→A repetitive spam are two
            separate problems and must not collapse into one
            fingerprint. Use `ordered=True` for REPETITIVE_DELEGATION
            and for per-edge RESOURCE_EXHAUSTION; leave as False
            for cycles.

    Encoding: the hash input is `json.dumps(failure_class.value) + ":" +
    json.dumps(key_agents)`. JSON is used as the canonical encoding
    because it's injective — distinct agent lists produce distinct
    byte strings, even for agents whose names contain `,`, `[`,
    `]`, `"`, quotes, or other punctuation that a naive
    `','.join(...)` would silently collapse. Without JSON (or some
    equivalent unambiguous encoding), an agent literally named
    `"a,b"` would produce the same fingerprint as the pair
    `["a", "b"]` — two unrelated failure patterns would collapse
    into one row in every summary report. Round 3 audit caught this.
    """
    if ordered:
        key_agents = list(agents)
    else:
        # De-duplicate AND sort so `["a","b","a"]` and `["a","b"]`
        # produce the same fingerprint — both describe the agent
        # set `{a, b}`. The old implementation only sorted, so
        # duplicates changed the fingerprint even though the agent
        # set was identical (the docstring claimed orbit equivalence
        # but the code didn't enforce it).
        key_agents = sorted(set(agents))
    raw = (
        json.dumps(failure_class.value, ensure_ascii=False)
        + ":"
        + json.dumps(key_agents, ensure_ascii=False)
    )
    return f"sha256:{hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16]}"


# ---------------------------------------------------------------------------
# Alert → CoordinationEvent wrapping
# ---------------------------------------------------------------------------

def alert_to_coordination_event(
    alert: Alert,
    session_id: str,
    failure_class: FailureClass,
    agents: list[str] | None = None,
    topology: Topology | None = None,
    thresholds: Thresholds | None = None,
    provider_error: ProviderError | None = None,
    downstream_impact: DownstreamImpact | None = None,
    summary: str | None = None,
    ordered: bool = False,
) -> CoordinationEvent:
    """Wrap an existing Alert plus optional schema blocks into a CoordinationEvent.

    Agents for fingerprint computation are pulled in priority order:
      1. Explicit `agents` parameter
      2. topology.agents_involved
      3. alert.details source/target

    `ordered` is forwarded to compute_fingerprint — pass True for directional
    problems (REPETITIVE_DELEGATION, per-edge RESOURCE_EXHAUSTION) so that
    A→B and B→A stay as distinct events in the deduped report.
    """
    if agents is None:
        if topology is not None:
            agents = list(topology.agents_involved)
        elif "source" in alert.details and "target" in alert.details:
            agents = [alert.details["source"], alert.details["target"]]
        else:
            agents = []

    # Coerce every agent to a string so downstream code
    # (compute_fingerprint, join operations, JSON serialization)
    # can't blow up on an int/None/dict that slipped in from a
    # buggy builder or a future code path storing non-string agent
    # ids. `None` becomes "None" rather than crashing — still a
    # valid fingerprint key, just not a pretty one.
    agents = [str(a) for a in agents]

    if summary is None:
        summary = _build_summary(failure_class, topology)

    return CoordinationEvent(
        schema_version=SCHEMA_VERSION,
        event_id=str(uuid.uuid4()),
        session_id=session_id,
        timestamp=alert.timestamp,
        event_type="coordination_failure",
        failure_class=failure_class,
        severity=AlertSeverity.from_string(alert.severity),
        coordination_fingerprint=compute_fingerprint(failure_class, agents, ordered=ordered),
        topology=topology,
        thresholds=thresholds,
        provider_error=provider_error,
        downstream_impact=downstream_impact,
        summary=summary,
    )


# ---------------------------------------------------------------------------
# Deduplication for summary views
# ---------------------------------------------------------------------------

# Lower rank = higher severity (takes priority in dedup)
_SEVERITY_RANK = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}


def dedupe_events_by_fingerprint(
    events: list[CoordinationEvent],
) -> list[CoordinationEvent]:
    """Collapse events with the same coordination_fingerprint.

    Best practice in modern alerting systems (Prometheus, PagerDuty, Sentry):
    a summary view shows one entry per unique problem, at its current
    (highest) severity. Timeline views keep the full history.

    Rule: for each fingerprint, keep the event with the highest severity.
    If multiple events share that severity, keep the latest one (highest
    timestamp) so the displayed counts/rotations reflect the most recent
    state of the pattern.

    Example: if a cycle fires WARNING at 5 rotations and CRITICAL at 15
    rotations, the deduped result shows ONE event (CRITICAL at 15 rotations),
    not two.

    The engine's `get_recent_events()` and the `.log` files remain
    chronological — this helper is only for summary exports (JSON, HTML).
    """
    best: dict[str, CoordinationEvent] = {}
    for event in events:
        fp = event.coordination_fingerprint
        current = best.get(fp)
        if current is None:
            best[fp] = event
            continue

        new_rank = _SEVERITY_RANK.get(event.severity.value, 99)
        current_rank = _SEVERITY_RANK.get(current.severity.value, 99)

        # Higher severity wins (lower rank number)
        if new_rank < current_rank:
            best[fp] = event
        # Same severity — latest timestamp wins (most up-to-date state)
        elif new_rank == current_rank and event.timestamp > current.timestamp:
            best[fp] = event

    return list(best.values())


def inhibit_subsumed_events(
    events: list[CoordinationEvent],
) -> list[CoordinationEvent]:
    """Suppress symptom events when a higher-order root-cause event covers them.

    Implements the "alert inhibition" pattern from Prometheus Alertmanager's
    `inhibit_rules`: when a critical root-cause alert is firing, symptom
    alerts that are part of the same failure are silenced so the user sees
    one actionable signal instead of a flood.

    v0.1.0 rule:
      A CYCLIC_DELEGATION event (whether detected incrementally by
      CycleDetector or by the periodic SCC sweep) INHIBITS any
      REPETITIVE_DELEGATION events whose agents are a subset of the
      cycle's agents. The repetitive edges are the symptoms of the cycle;
      the cycle is the root cause.

    Events with other failure classes (RESOURCE_EXHAUSTION from the rate
    limiter, etc.) are not inhibited — they represent independent problems.

    Pure function — doesn't mutate the input list.

    Example:
        Input:
          - CYCLIC_DELEGATION {A, B, C}  (root cause)
          - REPETITIVE_DELEGATION (A, B) (symptom — edge of the cycle)
          - REPETITIVE_DELEGATION (B, C) (symptom)
          - REPETITIVE_DELEGATION (C, A) (symptom)
          - REPETITIVE_DELEGATION (X, Y) (unrelated — different agents)
        Output:
          - CYCLIC_DELEGATION {A, B, C}
          - REPETITIVE_DELEGATION (X, Y)
    """
    # Materialize the input once — we iterate twice (cycle collection +
    # main loop) and silently lose data if the caller passes a generator.
    events = list(events)

    # Collect (agents, severity_rank) for every cycle event so we
    # can enforce the severity check below.
    cycle_context: list[tuple[set[str], int]] = [
        (
            set(e.topology.agents_involved),
            _SEVERITY_RANK.get(e.severity.value, 99),
        )
        for e in events
        if e.failure_class == FailureClass.CYCLIC_DELEGATION
        and e.topology is not None
        and e.topology.agents_involved
    ]

    if not cycle_context:
        return events  # already a fresh list — nothing to inhibit

    result: list[CoordinationEvent] = []
    for event in events:
        if (
            event.failure_class == FailureClass.REPETITIVE_DELEGATION
            and event.topology is not None
            and event.topology.agents_involved
        ):
            edge_agents = set(event.topology.agents_involved)
            edge_rank = _SEVERITY_RANK.get(event.severity.value, 99)
            # Suppress only when a cycle both:
            #   (a) CONTAINS all of this edge's agents (the structural
            #       "symptom of this cycle" relationship), AND
            #   (b) is at LEAST as severe as the edge (so a WARNING
            #       cycle cannot silence a CRITICAL repetitive edge —
            #       that would hide the more urgent signal)
            #
            # Severity ranks are inverted: 0 = CRITICAL, 1 = WARNING,
            # 2 = INFO. "At least as severe" = cycle_rank <= edge_rank.
            if any(
                edge_agents <= cycle_agents and cycle_rank <= edge_rank
                for cycle_agents, cycle_rank in cycle_context
            ):
                continue
        result.append(event)
    return result


def _build_summary(failure_class: FailureClass, topology: Topology | None) -> str:
    """Build a human-readable one-liner for the event.

    The format depends on failure_class AND interaction_pattern:
      - "circular" cycles render as closed loops: "a -> b -> c -> a"
      - "one_directional" and "throttled" render as linear arrows: "a -> b"

    For cycles, the `agents_involved` tuple is treated as a traversal
    order. Layer 3 (CycleDetector) provides a real ordered path; Layer 5
    (SCC sweep) provides sorted agents — which is technically not the
    exact traversal but the user only cares WHICH agents are stuck in a
    loop, not the exact direction. Both layers produce the same
    `interaction_pattern="circular"` so users see identical output
    regardless of which detection path fired.

    No token/cost data in v0.1.0.
    """
    if topology is None:
        return f"{failure_class.value} detected"

    agents = topology.agents_involved
    if not agents:
        return f"{failure_class.value} detected"

    pattern = topology.interaction_pattern
    occ = topology.occurrence_count

    if failure_class == FailureClass.CYCLIC_DELEGATION:
        if pattern == "circular":
            # Close the loop visually so readers immediately see it's a cycle
            path_str = " -> ".join(agents) + " -> " + agents[0]
            return f"Cyclic delegation detected: {path_str} ({occ} rotations)"
        # Fallback for unknown cycle patterns
        return f"Cyclic delegation detected: {' -> '.join(agents)} ({occ} rotations)"

    if failure_class == FailureClass.REPETITIVE_DELEGATION:
        agents_str = " -> ".join(agents)
        return f"Repetitive delegation detected: {agents_str} ({occ} events)"

    if failure_class == FailureClass.RESOURCE_EXHAUSTION:
        agents_str = " -> ".join(agents)
        return f"Resource exhaustion: {agents_str}"

    return f"{failure_class.value} detected: {' -> '.join(agents)}"
