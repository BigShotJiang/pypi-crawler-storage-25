"""
Shared data classes for AgentSonar coordination failure detection.

Framework-agnostic — no imports from _integrations/ or _output/.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class InteractionEvent:
    source_agent: str
    target_agent: str
    timestamp: float
    metadata: dict[str, Any] | None = None


@dataclass
class Alert:
    pattern: str
    severity: str  # "WARNING", "CRITICAL", or "INFO"
    details: dict[str, Any]
    timestamp: float = field(default_factory=time.time)


@dataclass
class CycleInfo:
    """Returned by CycleDetector.check() when a cycle is found."""
    fingerprint: tuple[str, ...]                  # sorted tuple of agents in cycle
    cycle_path: list[str]                         # ordered path: [A, B, C] for A->B->C->A
    rotations: int                                # min edge count across cycle edges
    edge_counts: dict[tuple[str, str], int]       # {(A,B): 7, (B,C): 5, (C,A): 6}


@dataclass(frozen=True)
class PreventionResult:
    """Snapshot of a coordination failure that crossed the prevent threshold.

    Returned by `engine.should_prevent()` and carried inside `PreventError`.
    Frozen so callers cannot mutate engine state via the result.
    """
    failure_class: str           # "cyclic_delegation"
    pattern: str                 # internal: "cycle" or "scc_cycle"
    reason: str                  # human-readable one-liner
    cycle_path: list[str]        # ordered cycle path
    rotations: int               # min edge count at time of trip
    severity: str                # "WARNING" | "CRITICAL"
    timestamp: float             # alert timestamp (epoch seconds)


class PreventError(Exception):
    """Raised by AgentSonar adapters when a prevented coordination failure is detected.

    Carries a `PreventionResult` describing what tripped, plus convenience
    attributes mirrored on the exception itself for ergonomic `except` blocks:

        try:
            sonar.delegation(source="reviewer", target="generator")
        except agentsonar.PreventError as e:
            print(f"Stopped: {e.reason}")
            print(f"Cycle:   {' -> '.join(e.cycle_path)}")

    Re-raise behavior:
      Once raised, the tripped alert remains in the engine's recent-alerts
      buffer, so any subsequent `delegation()` call will re-raise PreventError
      again (same fingerprint, same trip). This is intentional — Prevent
      Mode's contract is "stop the loop." If you catch PreventError, you must
      either exit your orchestrator loop or call `sonar.shutdown()` and stop
      ingesting events. Restarting detection mid-run requires a fresh
      `monitor_orchestrator(...)` instance.
    """
    def __init__(self, prevention: PreventionResult):
        self.prevention = prevention
        self.failure_class = prevention.failure_class
        self.reason = prevention.reason
        self.cycle_path = list(prevention.cycle_path)
        self.rotations = prevention.rotations
        self.severity = prevention.severity
        self.timestamp = prevention.timestamp
        super().__init__(prevention.reason)

    def __reduce__(self):
        # Default Exception pickling reconstructs as `cls(*args)`, but
        # our `args` is `(reason_string,)` — calling `PreventError("...")`
        # would crash when __init__ tries to read attributes off a string.
        # Tell pickle to reconstruct with the actual PreventionResult.
        return (self.__class__, (self.prevention,))
