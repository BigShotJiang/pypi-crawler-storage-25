"""
Core detection engine for multi-agent coordination failures.

5-layer architecture, cheapest checks first:
  Layer 1: SlidingWindowLimiter      — O(1) circuit breaker
  Layer 2: ExponentialDecayDetector  — O(1) update, O(E) anomaly scan
  Layer 3: CycleDetector             — O(V+E) cycle detection
  Layer 4: AlertStateManager         — O(1) alert dedup / state machine
  Layer 5: PeriodicSCCAnalyzer       — O(V+E) backup SCC sweep

Framework-agnostic — receives InteractionEvent objects, maintains an
interaction graph, and delegates to the 5 detection layers.
"""
from __future__ import annotations

import logging
import threading
import time
import uuid

logger = logging.getLogger(__name__)

from agentsonar._core.constants import SCHEMA_VERSION
from agentsonar._core.detectors.alert_state import AlertStateManager
from agentsonar._core.detectors.cycle_detector import CycleDetector
from agentsonar._core.detectors.rate_limiter import SlidingWindowLimiter
from agentsonar._core.detectors.repetitive_detector import ExponentialDecayDetector
from agentsonar._core.detectors.scc_analyzer import PeriodicSCCAnalyzer
from agentsonar._core.graph import CoordinationGraph
from agentsonar._core.models import Alert, InteractionEvent, PreventError, PreventionResult
from agentsonar._core.schema import (
    AlertSeverity,
    CoordinationEvent,
    DownstreamImpact,
    FailureClass,
    ProviderError,
    Thresholds,
    Topology,
    alert_to_coordination_event,
    compute_fingerprint,
)

# Default lock timeout in seconds. If detection takes longer than this,
# something is catastrophically wrong — drop the event rather than stall
# the entire crew.
_LOCK_TIMEOUT = 5.0


class DetectionEngine:

    def __init__(self, config: dict | None = None):
        config = config or {}
        self._lock = threading.Lock()
        self.session_id = uuid.uuid4().hex[:16]
        self.coord_graph = CoordinationGraph()
        self._event_count = 0
        self._alert_count = 0
        # Latch — atomically claims ownership of shutdown() so concurrent
        # callers don't double-emit log_session_end (duplicate banners, etc).
        self._shutdown_requested = False
        self._recent_alerts: list[Alert] = []  # bounded: last N alerts for summary
        self._MAX_RECENT_ALERTS = 200
        # Structured schema events — parallel to _recent_alerts, one per Alert
        self._recent_events: list[CoordinationEvent] = []
        self._MAX_RECENT_EVENTS = 200
        # Raw chronological delegation stream — powers the "Session Log"
        # view in the HTML report (click the Information chip). Each
        # tuple is (timestamp, src_agent, tgt_agent). Bounded so that
        # long-running sessions don't leak memory; when the cap is
        # exceeded we keep the most recent N entries and the HTML
        # renderer surfaces a "showing N of M" banner so users know
        # they're not seeing the whole run.
        self._session_log: list[tuple[float, str, str]] = []
        self._MAX_SESSION_LOG = 500
        self._session_log_total = 0  # total events ingested, uncapped
        self.iteration_count = 0
        self._delegation_count = 0
        # Track cycle fingerprints we've already emitted log messages for,
        # so we don't flood the terminal with duplicate "cycle found" lines.
        # AlertStateManager handles its own dedup for formal WARNING/CRITICAL alerts.
        #
        # Bounded so long-running sessions that see many distinct cycles
        # (multi-tenant, large graphs, test suites) don't leak memory.
        # When we exceed _MAX_LOGGED_CYCLES, we drop the entire set —
        # "cycle found" logs only repeat if the fingerprint vanishes
        # from the set, which at that point is fine (it's a first
        # sighting for each new chunk of cycles).
        self._logged_cycles: set[tuple[str, ...]] = set()
        self._MAX_LOGGED_CYCLES = 500
        # Thresholds are read from config in the Layer 4 setup below.
        # No placeholder assignment here — previous code initialized
        # them to defaults that were unconditionally overwritten,
        # which masked any future bug where the real assignment
        # was skipped.

        # Lazy import to avoid circular dependency (_core.engine ↔ _output.terminal)
        from agentsonar._output.terminal import SonarLogger

        # Structured logger. Pass the engine's session_id so the
        # per-run session directory name includes the same id as the
        # session_start log record — users can grep for the session_id
        # and find both the run dir and every event record in it.
        #
        # `keep_runs` defaults to None here — SonarLogger resolves
        # it from the AGENTSONAR_KEEP_RUNS env var or its own default.
        # Explicit config overrides env var.
        self.logger = SonarLogger(
            output_dir=config.get("log_dir", "."),
            console_output=config.get("console_output", True),
            file_output=config.get("file_output", True),
            log_level=config.get("log_level", "INFO"),
            session_id=self.session_id,
            keep_runs=config.get("keep_runs"),
        )

        # Layer 1: Circuit breaker
        self._limiter = SlidingWindowLimiter(
            window_size=config.get("window_size", 180.0),
            per_edge_limit=config.get("per_edge_limit", 10),
            global_limit=config.get("global_limit", 200),
        )

        # Layer 2: Decay-weighted anomaly detection.
        # Defaults match the detector's own defaults so raising the
        # z-score warm-up gates in repetitive_detector.py actually
        # takes effect for engine users. If these drift again,
        # z-score false positives will return.
        self._decay = ExponentialDecayDetector(
            half_life_seconds=config.get("half_life_seconds", 180.0),
            z_score_threshold=config.get("z_score_threshold", 3.0),
            hard_weight_limit=config.get("hard_weight_limit", 10.0),
            min_edges_for_zscore=config.get("min_edges_for_zscore", 10),
            min_total_events=config.get("min_total_events", 20),
        )

        # Layer 3: Cycle detection (stateless)
        self._cycle = CycleDetector()

        # Prevent Mode (opt-in, off by default).
        # Parsed BEFORE Layer 4 so a low `max_rotations` can auto-lower
        # warning_threshold below — alerts only emit at >= warning_threshold,
        # so a max_rotations below that floor would otherwise never trip.
        # Accepted shapes:
        #   prevent=None                                           # off
        #   prevent={"cyclic_delegation": True}                    # default: trip on CRITICAL
        #   prevent={"cyclic_delegation": {"max_rotations": 3}}    # custom threshold
        #   prevent={"cyclic_delegation": True, "raise": False}    # escape hatch
        # Defensive parse — bad shapes (string, list, etc.) silently
        # disable Prevent Mode without crashing the engine. Without
        # this, build_engine_safely would degrade the WHOLE engine
        # to NoOp on a typo'd prevent config — wasteful given the
        # rest of detection works fine.
        prevent_cfg = config.get("prevent")
        if not isinstance(prevent_cfg, dict):
            prevent_cfg = {}
        self._prevent_raise = bool(prevent_cfg.get("raise", True))
        # One-shot flag: ensures the "prevention" event is emitted into
        # _recent_events EXACTLY ONCE per session, regardless of how many
        # times check_prevent() is called after the trip. Prevents the
        # report from showing duplicate prevention entries when the user's
        # loop catches PreventError and keeps calling delegation().
        self._prevent_event_emitted = False
        # Per-failure-class override map: {"cyclic_delegation": {"max_rotations": int|None}}
        # max_rotations=None means "use AlertStateManager's CRITICAL threshold".
        self._prevent_classes: dict[str, dict] = {}
        cyc_cfg = prevent_cfg.get("cyclic_delegation")
        if cyc_cfg is True:
            self._prevent_classes["cyclic_delegation"] = {"max_rotations": None}
        elif isinstance(cyc_cfg, dict):
            mr_raw = cyc_cfg.get("max_rotations")
            try:
                mr_int = int(mr_raw) if mr_raw is not None else None
            except (TypeError, ValueError):
                mr_int = None
            # Clamp to >= 1. Negative or zero values would otherwise
            # propagate into warning_threshold via the auto-lower below
            # and produce nonsense alert behavior. Treat them as
            # "trip on first cycle alert" instead of crashing or no-op'ing.
            if mr_int is not None and mr_int < 1:
                mr_int = 1
            self._prevent_classes["cyclic_delegation"] = {"max_rotations": mr_int}
        # else: cyc_cfg is False/None/anything-else — disabled

        # Layer 4: Alert state machine (manages WARNING → CRITICAL → RESOLVED)
        self._warning_threshold = config.get("warning_threshold", 5)
        self._critical_threshold = config.get("critical_threshold", 15)
        # Prevent Mode override: if max_rotations < warning_threshold,
        # lower the threshold so alerts emit early enough for
        # should_prevent() to see them. Prevent intent wins.
        cyc_pc = self._prevent_classes.get("cyclic_delegation")
        if cyc_pc is not None:
            mr = cyc_pc.get("max_rotations")
            if mr is not None and mr < self._warning_threshold:
                self._warning_threshold = mr
        self._alert_mgr = AlertStateManager(
            warning_threshold=self._warning_threshold,
            critical_threshold=self._critical_threshold,
            re_alert_interval=config.get("re_alert_interval", 30),
            resolve_after_seconds=config.get("resolve_after_seconds", 60.0),
        )

        # Layer 5: Periodic SCC sweep
        self._scc = PeriodicSCCAnalyzer(
            interval_seconds=config.get("scc_interval_seconds", 10.0),
            interval_events=config.get("scc_interval_events", 50),
        )

        # Auto-export JSON + HTML reports on shutdown so zero-config users
        # get the full output set without writing any extra code. The
        # default follows the `file_output` setting: if file logging is
        # enabled, reports are enabled; if file logging is disabled
        # (as in tests), reports are disabled too. Users who need a
        # different behavior can set auto_export_on_shutdown explicitly.
        #
        # Reports now land in the same per-run session directory as
        # the log files (the logger's `run_dir`), so `_auto_export_dir`
        # is NOT set at init — auto-export reads `self.logger.run_dir`
        # at shutdown time.
        self._auto_export_on_shutdown = config.get(
            "auto_export_on_shutdown",
            config.get("file_output", True),
        )
        self._auto_export_title = config.get("report_title", "AgentSonar Report")

        # Log session start (I/O — no lock needed during init, single-threaded)
        self.logger.log_session_start(session_id=self.session_id, framework="unknown")

    @property
    def graph(self):
        """Expose raw NetworkX DiGraph for backward compatibility."""
        return self.coord_graph.graph

    # ------------------------------------------------------------------
    # Event ingestion
    # ------------------------------------------------------------------

    def ingest(self, event: InteractionEvent) -> list[Alert]:
        """Ingest an interaction event. Thread-safe with timeout.

        Returns list of new alerts. If the lock cannot be acquired within
        the timeout, the event is dropped silently (logged at DEBUG).

        HOST-SAFETY GUARANTEE: this method never raises. Every internal
        detection layer is individually fault-isolated (see
        `_ingest_locked`), and this outer wrapper adds a second
        catch-all around the entire path — lock acquisition, detection,
        log flushing — so even a totally unexpected failure (e.g. a
        bug in a future detector, a numpy division-by-zero, a sudden
        `MemoryError`) cannot propagate into the host application's
        event handler. Coordination detection must degrade; the host
        event loop must not.
        """
        try:
            acquired = self._lock.acquire(timeout=_LOCK_TIMEOUT)
        except Exception:
            # Lock acquisition itself threw (e.g. interrupted system
            # call on Unix). Drop the event silently rather than
            # surfacing to the host.
            return []
        if not acquired:
            try:
                logger.debug(
                    "Lock acquisition timed out after %.1fs — dropping event %s->%s",
                    _LOCK_TIMEOUT, event.source_agent, event.target_agent,
                )
            except Exception:
                pass
            return []

        try:
            new_alerts, log_actions, deferred_errors = self._ingest_locked(event)
        except Exception:
            # Catastrophic failure inside the detection pipeline.
            # Every individual layer is already try/except'd inside
            # `_ingest_locked`, so reaching here means something even
            # more fundamental broke (graph mutation, state tracking,
            # etc.). Swallow it — the host MUST keep running.
            try:
                logger.debug(
                    "AgentSonar: _ingest_locked raised unexpectedly; "
                    "dropping event",
                    exc_info=True,
                )
            except Exception:
                pass
            return []
        finally:
            try:
                self._lock.release()
            except Exception:
                pass

        # All I/O happens OUTSIDE the lock. Wrap the flush so a
        # broken logger can't bubble out of ingest() either.
        try:
            self._flush_log_actions(log_actions, deferred_errors)
        except Exception:
            try:
                logger.debug(
                    "AgentSonar: _flush_log_actions raised unexpectedly",
                    exc_info=True,
                )
            except Exception:
                pass
        return new_alerts

    def _ingest_locked(self, event: InteractionEvent) -> tuple[list[Alert], list[tuple], list[str]]:
        """Pure computation under the lock. No I/O, no file writes, no printing.

        Returns (new_alerts, log_actions, deferred_errors) where:
          - log_actions: (method_name, args, kwargs) tuples to execute after lock release
          - deferred_errors: error messages to log after lock release
        """
        self._event_count += 1
        src, tgt = event.source_agent, event.target_agent
        now = event.timestamp

        # Update graph
        tokens = (event.metadata or {}).get("tokens", 0)
        edge_count = self.coord_graph.add_event(src, tgt, tokens, timestamp=now)
        self._delegation_count += 1

        # Append to the chronological session log (powers the HTML
        # report's "Session Log" view). Bounded to _MAX_SESSION_LOG so
        # that a long-running session can't balloon memory — we keep
        # the most recent N entries and track the true total in
        # _session_log_total so the HTML can show "showing N of M".
        self._session_log.append((now, src, tgt))
        self._session_log_total += 1
        if len(self._session_log) > self._MAX_SESSION_LOG:
            self._session_log = self._session_log[-self._MAX_SESSION_LOG:]

        # Collect log actions to flush after lock release
        log_actions: list[tuple] = [
            ("log_delegation", (src, tgt, edge_count, self._delegation_count), {}),
            ("log_graph_update", (src, tgt, edge_count), {}),
        ]

        new_alerts: list[Alert] = []
        graph = self.coord_graph.graph

        # Collect error messages to log AFTER lock release (no I/O under lock)
        _deferred_errors: list[str] = []

        # --- Layer 1: Circuit breaker (O(1), cheapest) ---
        try:
            rate_alert = self._limiter.check(src, tgt, now)
            if rate_alert:
                new_alerts.append(rate_alert)
                log_actions.append(("log_rate_limit_hit", (rate_alert,), {}))
                # Build structured CoordinationEvent (fault-isolated)
                try:
                    coord_event = self._build_rate_limit_event(rate_alert, src, tgt)
                except Exception as build_err:
                    coord_event = self._fallback_event(
                        rate_alert, FailureClass.RESOURCE_EXHAUSTION, build_err
                    )
                self._append_event(coord_event)
                # Circuit breaker fired — skip heavier analysis.
                # Use the helper so the cap is enforced even on this
                # early-return path (bug before: sustained Layer 1
                # firing grew _recent_alerts unbounded because the
                # trim at the bottom of _ingest_locked was bypassed).
                self._alert_count += len(new_alerts)
                self._append_recent_alerts(new_alerts)
                return new_alerts, log_actions, _deferred_errors
        except Exception as e:
            _deferred_errors.append(f"Layer 1 (SlidingWindowLimiter) failed: {e}")

        # --- Layer 2: Exponential decay anomaly detection ---
        try:
            self._decay.record_event(src, tgt, now)
            anomaly = self._decay.check_anomaly(src, tgt, now)
            if anomaly:
                log_actions.append(("log_anomaly_detected", (anomaly,), {}))
                edge_fp = ("edge", src, tgt)
                edge_alert = self._alert_mgr.process(
                    fingerprint=edge_fp,
                    rotations=anomaly.get("event_count", 0),
                    pattern="edge_anomaly",
                    now=now,
                    extra_details=anomaly,
                )
                if edge_alert:
                    new_alerts.append(edge_alert)
                    log_actions.append(("log_alert", (edge_alert,), {}))
                    # Build structured CoordinationEvent (fault-isolated)
                    try:
                        coord_event = self._build_edge_anomaly_event(anomaly, edge_alert)
                    except Exception as build_err:
                        coord_event = self._fallback_event(
                            edge_alert, FailureClass.REPETITIVE_DELEGATION, build_err
                        )
                    self._append_event(coord_event)
        except Exception as e:
            _deferred_errors.append(f"Layer 2 (ExponentialDecayDetector) failed: {e}")

        # --- Layer 3: Cycle detection ---
        try:
            cycle_info = self._cycle.check(graph, event)
            if cycle_info:
                # Only log the cycle the FIRST time we see this fingerprint.
                # Subsequent traversals of the same cycle are silent until
                # AlertStateManager escalates to a formal alert (which has
                # its own log action via log_alert).
                if cycle_info.fingerprint not in self._logged_cycles:
                    # Enforce the bound before adding. If we're at cap,
                    # clear the whole set — "cycle found" logs repeat
                    # for the next chunk of distinct cycles, which is
                    # fine: it's a first-sighting heads-up, not an
                    # alert. Alternative (LRU eviction) costs more
                    # without actually improving the UX.
                    if len(self._logged_cycles) >= self._MAX_LOGGED_CYCLES:
                        self._logged_cycles.clear()
                    self._logged_cycles.add(cycle_info.fingerprint)
                    log_actions.append(("log_cycle_detected", (cycle_info.cycle_path, cycle_info.rotations), {}))
                cycle_alert = self._alert_mgr.process(
                    fingerprint=cycle_info.fingerprint,
                    rotations=cycle_info.rotations,
                    pattern="cycle",
                    now=now,
                    extra_details={
                        "cycle_path": cycle_info.cycle_path,
                        "edge_counts": {
                            f"{u}->{v}": c for (u, v), c in cycle_info.edge_counts.items()
                        },
                    },
                )
                if cycle_alert:
                    new_alerts.append(cycle_alert)
                    log_actions.append(("log_alert", (cycle_alert,), {}))
                    # Build structured CoordinationEvent (fault-isolated)
                    try:
                        coord_event = self._build_cycle_event(cycle_info, cycle_alert)
                    except Exception as build_err:
                        coord_event = self._fallback_event(
                            cycle_alert, FailureClass.CYCLIC_DELEGATION, build_err
                        )
                    self._append_event(coord_event)
        except Exception as e:
            _deferred_errors.append(f"Layer 3 (CycleDetector) failed: {e}")

        # --- Layer 5: Periodic SCC sweep ---
        try:
            scc_results = self._scc.maybe_run(graph, now)
            if scc_results:
                log_actions.append(("log_scc_sweep", (scc_results,), {}))
                for scc in scc_results:
                    scc_alert = self._alert_mgr.process(
                        fingerprint=scc["fingerprint"],
                        rotations=scc["min_rotations"],
                        pattern="scc_cycle",
                        now=now,
                        extra_details={
                            "agents": list(scc["agents"]),
                            "size": scc["size"],
                            # SCC analysis doesn't trace a specific traversal
                            # path — the sorted agents list is a faithful
                            # approximation (same set, lexicographic order).
                            # Including this means downstream consumers
                            # (Prevent Mode's `should_prevent()`,
                            # CoordinationEvent fingerprint computation)
                            # don't have to special-case scc_cycle alerts
                            # that lack a cycle_path. Without it, prevent
                            # events built from an scc_cycle alert ended
                            # up with `agents=["unknown"]` and a
                            # mismatched fingerprint, which broke dedupe.
                            "cycle_path": list(scc["agents"]),
                        },
                    )
                    if scc_alert:
                        new_alerts.append(scc_alert)
                        log_actions.append(("log_alert", (scc_alert,), {}))
                        # Build structured CoordinationEvent (fault-isolated)
                        try:
                            coord_event = self._build_scc_event(scc, scc_alert)
                        except Exception as build_err:
                            coord_event = self._fallback_event(
                                scc_alert, FailureClass.CYCLIC_DELEGATION, build_err
                            )
                        self._append_event(coord_event)
        except Exception as e:
            _deferred_errors.append(f"Layer 5 (PeriodicSCCAnalyzer) failed: {e}")

        # --- Layer 4 recovery check (runs on every event) ---
        try:
            recoveries = self._alert_mgr.check_recoveries(now)
            for recovery in recoveries:
                new_alerts.append(recovery)
                fp = recovery.details.get("fingerprint", ())
                rotations = recovery.details.get("rotations", 0)
                tracked_entry = self._alert_mgr._tracked.get(fp)
                duration = (now - tracked_entry.created_at) if tracked_entry else 0.0
                log_actions.append(("log_alert_resolved", (), {
                    "pattern": recovery.pattern,
                    "fingerprint": fp if isinstance(fp, tuple) else tuple(fp),
                    "total_rotations": rotations,
                    "duration_seconds": duration,
                }))
        except Exception as e:
            _deferred_errors.append(f"Layer 4 (AlertStateManager recovery) failed: {e}")

        self._alert_count += len(new_alerts)
        self._append_recent_alerts(new_alerts)

        return new_alerts, log_actions, _deferred_errors

    def _append_recent_alerts(self, alerts: list[Alert]) -> None:
        """Append to _recent_alerts and enforce the _MAX_RECENT_ALERTS cap.

        Called from EVERY site that mutates _recent_alerts — the
        Layer 1 early-return path, the normal ingest path, and the
        shutdown-time recovery sweep. Before this helper existed,
        the cap was only enforced on the normal path; the other two
        paths grew the list unboundedly. The test
        `test_layer1_early_return_bounds_recent_alerts` in
        test_stress_and_edge_cases.py pins this behavior.
        """
        if not alerts:
            return
        self._recent_alerts.extend(alerts)
        if len(self._recent_alerts) > self._MAX_RECENT_ALERTS:
            self._recent_alerts = self._recent_alerts[-self._MAX_RECENT_ALERTS:]

    def _flush_log_actions(self, log_actions: list[tuple], deferred_errors: list[str]) -> None:
        """Execute deferred log/error calls outside the lock. Failures are swallowed."""
        for msg in deferred_errors:
            try:
                logger.debug(msg)
            except Exception:
                pass
        for method_name, args, kwargs in log_actions:
            try:
                getattr(self.logger, method_name)(*args, **kwargs)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # CoordinationEvent builders — pure, called under the lock
    # All wrapped in try/except at the call site with _fallback_event
    # ------------------------------------------------------------------

    def _append_event(self, event: CoordinationEvent) -> None:
        """Append a CoordinationEvent to the bounded recent-events buffer."""
        self._recent_events.append(event)
        if len(self._recent_events) > self._MAX_RECENT_EVENTS:
            self._recent_events = self._recent_events[-self._MAX_RECENT_EVENTS:]

    def _fallback_event(
        self,
        alert: Alert,
        failure_class: FailureClass,
        error: Exception,
    ) -> CoordinationEvent:
        """Minimal event used when a full builder throws.

        Each fallback event gets a unique fingerprint (`error:<class>:<uuid>`)
        so that multiple builder failures in the same session don't collapse
        into a single row in the deduped summary. Fallbacks are rare by
        construction — when they do happen we want every single one visible
        in the report so the user can investigate.
        """
        event_id = str(uuid.uuid4())
        return CoordinationEvent(
            schema_version=SCHEMA_VERSION,
            event_id=event_id,
            session_id=self.session_id,
            timestamp=alert.timestamp,
            event_type="coordination_failure",
            failure_class=failure_class,
            severity=AlertSeverity.from_string(alert.severity),
            coordination_fingerprint=f"error:{failure_class.value}:{event_id}",
            summary=f"{failure_class.value} detected (schema build failed: {error})",
        )

    def _build_cycle_event(self, cycle_info, alert: Alert) -> CoordinationEvent:
        """Wrap CycleDetector output + Alert into a CoordinationEvent."""
        agents = list(cycle_info.fingerprint)  # sorted unique agents
        cycle_path = tuple(cycle_info.cycle_path)

        topology = Topology(
            agents_involved=cycle_path,
            interaction_pattern="circular",
            agent_count=len(cycle_path),
            occurrence_count=cycle_info.rotations,
            edge_frequency={
                f"{u}->{v}": c for (u, v), c in cycle_info.edge_counts.items()
            },
        )

        thresholds = Thresholds(
            warning_at=self._warning_threshold,
            critical_at=self._critical_threshold,
            current_value=cycle_info.rotations,
            headroom_remaining=max(0, self._critical_threshold - cycle_info.rotations),
        )

        return alert_to_coordination_event(
            alert=alert,
            session_id=self.session_id,
            failure_class=FailureClass.CYCLIC_DELEGATION,
            agents=agents,
            topology=topology,
            thresholds=thresholds,
        )

    def _build_scc_event(self, scc_dict: dict, alert: Alert) -> CoordinationEvent:
        """Wrap PeriodicSCCAnalyzer output + Alert into a CoordinationEvent.

        SCC-detected cycles are rendered identically to incremental cycles
        from the user's perspective (interaction_pattern="circular") — the
        distinction between "the cycle we traced" vs "the SCC we swept"
        is internal detection-pipeline noise. What users care about is:
        there's a cycle, here are the agents. The exact traversal order
        (which the SCC sweep doesn't know) is approximated by the sorted
        agent list; it may not match the real path that was traced but
        identifies the same set of stuck agents either way.
        """
        scc_agents = sorted(scc_dict.get("agents", []))
        min_rotations = scc_dict.get("min_rotations", 0)

        topology = Topology(
            agents_involved=tuple(scc_agents),
            # Unified with Layer 3 cycles — "strongly_connected_component"
            # was jargon. Users see one kind of cycle.
            interaction_pattern="circular",
            agent_count=len(scc_agents),
            occurrence_count=min_rotations,
            edge_frequency={},  # SCC doesn't give us individual edge counts
        )

        thresholds = Thresholds(
            warning_at=self._warning_threshold,
            critical_at=self._critical_threshold,
            current_value=min_rotations,
            headroom_remaining=max(0, self._critical_threshold - min_rotations),
        )

        return alert_to_coordination_event(
            alert=alert,
            session_id=self.session_id,
            failure_class=FailureClass.CYCLIC_DELEGATION,
            agents=scc_agents,
            topology=topology,
            thresholds=thresholds,
        )

    def _build_edge_anomaly_event(self, anomaly: dict, alert: Alert) -> CoordinationEvent:
        """Wrap ExponentialDecayDetector anomaly + Alert into a CoordinationEvent."""
        src = anomaly.get("source", "unknown")
        tgt = anomaly.get("target", "unknown")
        event_count = anomaly.get("event_count", 0)

        topology = Topology(
            agents_involved=(src, tgt),
            interaction_pattern="one_directional",
            # Count DISTINCT agents. A normal directed edge has 2 agents
            # (src, tgt); a self-loop (src == tgt) has 1. Hardcoding 2
            # here misrepresented self-loop repetitive delegations in
            # every user-facing report — round 4 audit caught it.
            agent_count=len({src, tgt}),
            occurrence_count=event_count,
            edge_frequency={f"{src}->{tgt}": event_count},
        )

        thresholds = Thresholds(
            warning_at=self._warning_threshold,
            critical_at=self._critical_threshold,
            current_value=event_count,
            headroom_remaining=max(0, self._critical_threshold - event_count),
        )

        return alert_to_coordination_event(
            alert=alert,
            session_id=self.session_id,
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            agents=[src, tgt],
            topology=topology,
            thresholds=thresholds,
            # Directional: A→B spam and B→A spam must stay distinct
            ordered=True,
        )

    def _build_rate_limit_event(
        self,
        alert: Alert,
        triggering_src: str,
        triggering_tgt: str,
    ) -> CoordinationEvent:
        """Wrap SlidingWindowLimiter Alert into a CoordinationEvent.

        The SlidingWindowLimiter produces two alert patterns:
          - "rate_limit_exceeded" — per-edge limit. Each edge is its own
            problem, so the fingerprint uses the per-edge (src, tgt) pair.
            Multiple firings on the same edge dedupe together.
          - "global_rate_exceeded" — global limit. The whole system is over
            capacity — this is ONE system-wide problem regardless of which
            edge triggered it. Uses a constant fingerprint so multiple
            firings (across different triggering edges) dedupe together in
            summary views.

        Either way, the topology still shows the triggering edge for context.
        """
        # Prefer details from the alert (present for per-edge); fall back to
        # the triggering event (the only info available for global rate)
        src = alert.details.get("source") or triggering_src
        tgt = alert.details.get("target") or triggering_tgt

        # The alert pattern tells us which limit type fired
        is_global = alert.pattern == "global_rate_exceeded"
        error_type = "global_rate_exceeded" if is_global else "rate_limit_exceeded"

        topology = Topology(
            agents_involved=(src, tgt),
            interaction_pattern="throttled",
            # Count DISTINCT agents. Self-loop edges (src == tgt) have
            # 1 agent, not 2 — hardcoding 2 here lied in every rate
            # limit report when a recursive agent tripped the limiter.
            agent_count=len({src, tgt}),
            occurrence_count=0,
            edge_frequency={f"{src}->{tgt}": int(alert.details.get("estimated_rate", 0))},
        )

        provider_err = ProviderError(
            error_type=error_type,
            retry_after_seconds=None,
        )

        downstream = DownstreamImpact(
            blocked_agents=(tgt,),
            estimated_delay_seconds=0.0,
            cascade_risk_score=0.5,
        )

        # Fingerprint policy:
        #   Per-edge rate limit → agents=[src, tgt] (one fingerprint per edge,
        #                                           DIRECTIONAL — A→B and B→A
        #                                           are two separate rate
        #                                           limits, don't collapse)
        #   Global rate limit   → agents=[]         (one fingerprint total;
        #                                           all firings collapse to
        #                                           a single "system over
        #                                           capacity" event)
        fp_agents: list[str] = [] if is_global else [src, tgt]

        # Build a summary string that distinguishes per-edge from global
        # rate limits. Without this, both used the generic
        # `_build_summary` output ("Resource exhaustion: src -> tgt"),
        # which misled readers into thinking every global alert was a
        # per-edge problem on the triggering edge. Global alerts now
        # read "Global rate limit exceeded (triggered by src -> tgt)"
        # so the system-wide scope is unambiguous.
        if is_global:
            rate = alert.details.get("estimated_rate", "?")
            limit = alert.details.get("limit", "?")
            summary = (
                f"Global rate limit exceeded: "
                f"{rate} events/window (limit {limit}), "
                f"triggered by {src} -> {tgt}"
            )
        else:
            rate = alert.details.get("estimated_rate", "?")
            limit = alert.details.get("limit", "?")
            summary = (
                f"Per-edge rate limit exceeded: {src} -> {tgt} "
                f"at {rate} events/window (limit {limit})"
            )

        return alert_to_coordination_event(
            alert=alert,
            session_id=self.session_id,
            failure_class=FailureClass.RESOURCE_EXHAUSTION,
            agents=fp_agents,
            topology=topology,
            provider_error=provider_err,
            downstream_impact=downstream,
            summary=summary,
            # ordered=True only matters for the per-edge case;
            # the global path uses an empty list which is identical
            # under sorted() and list()
            ordered=not is_global,
        )

    def _build_prevention_event(
        self, prevention: PreventionResult,
    ) -> CoordinationEvent:
        """Build a `event_type="prevention"` CoordinationEvent reflecting
        the moment Prevent Mode actually tripped — with the LIVE rotation
        count at trip time, not the stale count from the last emitted alert.

        Why this exists:
          AlertStateManager only emits alerts at threshold boundaries
          (warning_threshold, critical_threshold) and on re_alert_interval
          rotations after CRITICAL. A user who configures
          `max_rotations=45` with default thresholds (warning=5,
          critical=15, re_alert=30) sees alerts at rotations 5, 15, 45
          (re_alert) — but Prevent Mode might trip BETWEEN those
          boundaries. Without this synthetic "prevention" event, the
          HTML report's last alert (e.g. CRITICAL@15 or @33) would
          undercount the actual trip rotation.

          This method synthesizes a final event that:
          (a) shares the cycle's coordination_fingerprint so dedupe
              recognizes it as the same problem,
          (b) carries `event_type="prevention"` so the HTML report can
              render it with a distinct visual treatment ("🛑 Prevent
              Mode tripped"),
          (c) uses time.time() at trip-emit time as the event timestamp,
              guaranteeing it sorts AFTER the alert events with the same
              fingerprint and wins the dedupe-by-fingerprint pass.

        Note on severity:
          Stays at CRITICAL (matching the cycle alert that crossed the
          threshold) so the existing severity filters in the report
          ("Show only CRITICAL") still surface it.
        """
        # Sorted unique agents — matches the fingerprint convention used
        # by the cycle and SCC builders so dedup correctly groups this
        # prevention event with the cycle alerts that preceded it.
        agents = sorted(set(prevention.cycle_path)) or ["unknown"]
        cycle_path = tuple(prevention.cycle_path)
        rotations = int(prevention.rotations)

        topology = Topology(
            agents_involved=cycle_path or tuple(agents),
            interaction_pattern="circular",
            agent_count=len(agents),
            occurrence_count=rotations,
            edge_frequency={},
        )

        thresholds = Thresholds(
            warning_at=self._warning_threshold,
            critical_at=self._critical_threshold,
            current_value=rotations,
            headroom_remaining=0,
        )

        summary = (
            f"Prevent Mode tripped: {prevention.failure_class} stopped at "
            f"{rotations} rotations"
            + (f" (cycle: {' -> '.join(cycle_path)})" if cycle_path else "")
        )

        # Compute a trip timestamp that is GUARANTEED strictly greater
        # than the underlying alert's timestamp. Why this matters:
        # dedupe-by-fingerprint keeps the latest event among same-severity
        # entries with the same fingerprint. If `time.time()` happens to
        # equal the alert's timestamp (possible on Windows where clock
        # resolution can be 15ms, or in tight unit-test loops where two
        # events fire within the same microsecond), dedupe's strict `>`
        # check would keep the cycle alert instead — bringing back the
        # very rotation-count mismatch this method exists to prevent.
        # Adding a microsecond ensures strictly-greater ordering even
        # under degenerate clock conditions.
        trip_ts = time.time()
        if trip_ts <= prevention.timestamp:
            trip_ts = prevention.timestamp + 1e-6

        return CoordinationEvent(
            schema_version=SCHEMA_VERSION,
            event_id=str(uuid.uuid4()),
            session_id=self.session_id,
            timestamp=trip_ts,
            event_type="prevention",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            severity=AlertSeverity.from_string(prevention.severity),
            coordination_fingerprint=compute_fingerprint(
                FailureClass.CYCLIC_DELEGATION, agents, ordered=False,
            ),
            topology=topology,
            thresholds=thresholds,
            summary=summary,
        )

    def increment_iteration(self) -> None:
        """Never raises — protects the host from lock/state errors."""
        try:
            acquired = self._lock.acquire(timeout=_LOCK_TIMEOUT)
        except Exception:
            return
        if not acquired:
            return
        try:
            self.iteration_count += 1
        except Exception:
            pass
        finally:
            try:
                self._lock.release()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def get_summary(self) -> dict:
        acquired = self._lock.acquire(timeout=_LOCK_TIMEOUT)
        if not acquired:
            return {"total_events": 0, "iteration_count": 0, "edge_counts": {},
                    "total_estimated_token_waste": 0, "alerts_raised": 0, "alerts": []}
        try:
            return self._get_summary_locked()
        finally:
            self._lock.release()

    def _get_summary_locked(self) -> dict:
        edge_counts = {
            f"{u}->{v}": d["count"]
            for u, v, d in self.coord_graph.edges_data()
        }
        total_tokens = sum(
            d.get("total_tokens", 0) for _, _, d in self.coord_graph.edges_data()
        )
        return {
            "total_events": self._event_count,
            "iteration_count": self.iteration_count,
            "edge_counts": edge_counts,
            "total_estimated_token_waste": total_tokens,
            "alerts_raised": self._alert_count,
            "alerts": [
                {
                    "pattern": a.pattern,
                    "severity": a.severity,
                    "details": a.details,
                }
                for a in self._recent_alerts
            ],
        }

    def get_recent_events(self) -> list[CoordinationEvent]:
        """Return a snapshot of recent CoordinationEvents. Thread-safe."""
        acquired = self._lock.acquire(timeout=_LOCK_TIMEOUT)
        if not acquired:
            return []
        try:
            return list(self._recent_events)
        finally:
            self._lock.release()

    # ------------------------------------------------------------------
    # Prevent Mode (opt-in)
    # ------------------------------------------------------------------

    def should_prevent(self) -> PreventionResult | None:
        """Return a PreventionResult if a tracked failure has crossed the
        configured threshold, else None. Thread-safe, never raises.

        Designed to be called frequently and cheaply by adapters after
        each `ingest()`. Walks the bounded `_recent_alerts` list to
        recover cycle_path / pattern / fingerprint for each known cycle,
        then queries the LIVE rotation count from `_alert_mgr._tracked`
        for the threshold check. Using live state (rather than the
        rotation count frozen in the alert at emit time) means
        `max_rotations` can be set higher than `critical_threshold`
        without waiting for the alert state machine's opportunistic
        re-alert path to fire — the trip happens at exactly the
        rotation count the user requested.
        """
        if not self._prevent_classes:
            return None
        try:
            acquired = self._lock.acquire(timeout=_LOCK_TIMEOUT)
        except Exception:
            return None
        if not acquired:
            return None
        try:
            cyc_cfg = self._prevent_classes.get("cyclic_delegation")
            if cyc_cfg is None:
                return None
            max_rot = cyc_cfg.get("max_rotations")  # None => use CRITICAL severity
            # Walk alerts most-recent-first. Each emitted cycle alert
            # carries the fingerprint + ordered cycle_path; the LIVE
            # rotation count comes from the alert state machine, which
            # always has the latest count whether or not a fresh alert
            # has been emitted at that boundary.
            for alert in reversed(self._recent_alerts):
                if alert.pattern not in ("cycle", "scc_cycle"):
                    continue
                # Prefer cycle_path (ordered traversal); fall back to
                # agents (unordered set) for detectors that don't trace
                # a specific path. This keeps PreventionResult.cycle_path
                # populated and the prevention-event fingerprint
                # consistent with the cycle-alert fingerprint, so dedupe
                # collapses them into a single card.
                cycle_path = list(
                    alert.details.get("cycle_path")
                    or alert.details.get("agents")
                    or []
                )
                fingerprint = alert.details.get("fingerprint")
                tracked = (
                    self._alert_mgr._tracked.get(fingerprint)
                    if fingerprint is not None
                    else None
                )
                # Live count if available; fall back to the alert's
                # frozen value if the tracked entry has been GC'd
                # (e.g. resolved + recreated).
                rotations = (
                    tracked.current_rotations
                    if tracked is not None
                    else int(alert.details.get("rotations", 0))
                )
                if max_rot is None:
                    # Default mode: trip only when AlertStateManager has
                    # already escalated this to CRITICAL.
                    if alert.severity != "CRITICAL":
                        continue
                else:
                    # Custom mode: trip as soon as the LIVE rotation
                    # count crosses the user's threshold, regardless
                    # of WARNING/CRITICAL emission cadence.
                    if rotations < max_rot:
                        continue
                reason = (
                    f"cyclic_delegation prevented after {rotations} rotations: "
                    f"{' -> '.join(cycle_path)}"
                ) if cycle_path else (
                    f"cyclic_delegation prevented after {rotations} rotations"
                )
                return PreventionResult(
                    failure_class="cyclic_delegation",
                    pattern=alert.pattern,
                    reason=reason,
                    cycle_path=cycle_path,
                    rotations=rotations,
                    severity=alert.severity,
                    timestamp=alert.timestamp,
                )
            return None
        except Exception:
            return None
        finally:
            self._lock.release()

    def check_prevent(self) -> PreventionResult | None:
        """Adapter-facing helper — calls should_prevent(), then raises
        PreventError if `prevent={..., "raise": True}` (the default).
        Returns the result either way (None when nothing to prevent).

        Wrapped in try/except — the only exception that can escape this
        method is `PreventError`. Any other failure (e.g. a hypothetical
        bug in the PreventError constructor) returns None instead of
        propagating, preserving the "observability never breaks the
        observed" contract.
        """
        try:
            result = self.should_prevent()
        except Exception:
            return None
        if result is None:
            return None
        # Emit a "prevention" CoordinationEvent into the report stream the
        # FIRST time the trip is detected. The standard alert-driven events
        # only fire at threshold boundaries (warning_threshold,
        # critical_threshold, re_alert_interval); the actual trip can land
        # between those boundaries (especially with max_rotations override),
        # so the report would otherwise show a stale rotation count from
        # the last alert instead of the live rotation count at trip time.
        # Wrapped in try/except to preserve host-safety — if event-building
        # fails for any reason, we still raise PreventError correctly.
        if not self._prevent_event_emitted:
            try:
                event = self._build_prevention_event(result)
                self._append_event(event)
                # Also log to the chronological alerts.log + JSONL timeline
                # so the human-readable signal log shows the trip alongside
                # the WARNING / CRITICAL alerts that preceded it. Wrapped
                # separately so logger failure can't block the report-event
                # bookkeeping (and vice versa).
                try:
                    self.logger.log_prevented(result)
                except Exception:
                    pass
                self._prevent_event_emitted = True
            except Exception:
                # Don't let report-bookkeeping failure block the actual
                # PreventError. Mark as emitted anyway so we don't spin.
                self._prevent_event_emitted = True
        if not self._prevent_raise:
            return result
        # Build PreventError outside any catch — this MUST propagate.
        raise PreventError(result)

    def shutdown(self) -> None:
        """Log session end summary, write reports, close the logger.

        Safe to call multiple times. Concurrent shutdown() calls are
        serialized — only the first caller runs the shutdown work, the
        rest return immediately. Uses a latch claimed atomically inside
        the engine lock so two threads can never both emit
        log_session_end (which would produce duplicate banners).

        If `auto_export_on_shutdown` is enabled (the default when
        `file_output=True`), this also writes a JSON and an HTML report
        to `log_dir` — zero extra code from the caller. Export failures
        are swallowed (fault isolation: the observer must never crash
        the observed system even at exit time).

        Order of operations is deliberate:
          1. Acquire the lock, latch shutdown, snapshot state.
          2. Fire a final `check_recoveries()` sweep so any ACTIVE /
             ESCALATED alerts that have been idle long enough get
             their RESOLVED notification BEFORE the logger closes.
             Without this, short-lived workloads (user's crew
             finishes, no more events arrive) would never emit
             RESOLVED because `check_recoveries()` only runs inside
             the ingest path — no more ingest means no more checks.
          3. Release the lock and generate reports.
          4. Emit the session-end banner (references report paths).
        """
        import time as _time

        acquired = self._lock.acquire(timeout=_LOCK_TIMEOUT)
        if not acquired:
            return
        try:
            # Atomic check-and-set: whoever flips this first owns the
            # shutdown. We short-circuit in two cases:
            #   a) a previous shutdown() call already ran — `_shutdown_requested`
            #      is True. Nothing to do; already done.
            #   b) user code directly closed the logger (bypassing
            #      shutdown) — `logger._closed` is True but
            #      `_shutdown_requested` is still False. In that case
            #      the engine state is inconsistent: logger is gone
            #      but the engine thinks it hasn't been shut down.
            #      Set the latch to True so subsequent introspection
            #      (`engine._shutdown_requested`) correctly reports
            #      the engine as shut down, even though we can't
            #      emit the session-end banner.
            if self._shutdown_requested or self.logger._closed:
                self._shutdown_requested = True
                return
            self._shutdown_requested = True

            # Final recovery sweep. Use wall-clock `now` — a workload
            # that's been idle for `resolve_after_seconds` by the time
            # shutdown() is called deserves its RESOLVED alerts fired.
            #
            # We pretend events "just happened at now" so the recovery
            # check sees the full idle duration. If the workload was
            # active right up until shutdown, `now - last_activity_time`
            # will be tiny and nothing resolves (which is correct —
            # those alerts really are still firing when the session
            # ends, and marking them RESOLVED would be misleading).
            shutdown_now = _time.time()
            final_recoveries: list[Alert] = []
            try:
                final_recoveries = self._alert_mgr.check_recoveries(shutdown_now)
            except Exception as e:
                logger.debug("Shutdown: final check_recoveries failed: %s", e)

            self._alert_count += len(final_recoveries)
            # Use the capped helper — without this, a long-running
            # session with many final recoveries would push the
            # _recent_alerts list past its cap at shutdown time.
            self._append_recent_alerts(final_recoveries)

            summary = self._get_summary_locked()
            # Snapshot events under the lock so auto-export sees a
            # consistent slice even if another thread is ingesting.
            events_snapshot = list(self._recent_events)
            # Snapshot per-edge activity too — this powers the Run
            # Activity view in the HTML report, which surfaces INFO-level
            # delegation traffic even on clean runs where no warnings or
            # criticals fired. Kept inside the lock for the same
            # consistency reason as events_snapshot.
            try:
                edge_activity_snapshot = self.coord_graph.edge_activity_summary()
            except Exception:
                logger.debug(
                    "Shutdown: edge_activity_summary failed", exc_info=True
                )
                edge_activity_snapshot = []
            # Snapshot the chronological delegation stream — powers
            # the "Session Log" view accessed via the Information chip.
            # `session_log_total` is the uncapped count so the renderer
            # can tell users "showing 500 of N total" when truncated.
            session_log_snapshot = list(self._session_log)
            session_log_total = self._session_log_total
        finally:
            self._lock.release()
        # Only one thread reaches here — safe to do I/O outside the lock

        # Emit recovery log actions for any alerts the final sweep
        # marked RESOLVED. They need to land in the JSONL + alerts
        # log files BEFORE log_session_end closes them.
        for recovery in final_recoveries:
            try:
                fp = recovery.details.get("fingerprint", ())
                rotations = recovery.details.get("rotations", 0)
                tracked_entry = self._alert_mgr._tracked.get(fp)
                duration = (
                    (shutdown_now - tracked_entry.created_at)
                    if tracked_entry
                    else 0.0
                )
                self.logger.log_alert_resolved(
                    pattern=recovery.pattern,
                    fingerprint=fp if isinstance(fp, tuple) else tuple(fp),
                    total_rotations=rotations,
                    duration_seconds=duration,
                )
            except Exception as e:
                logger.debug("Shutdown: failed to emit recovery log: %s", e)

        # Generate reports BEFORE log_session_end so the banner can
        # reference their paths. report_paths is a dict like:
        #   {"json": "/cwd/agentsonar_report_XXX.json",
        #    "html": "/cwd/agentsonar_report_XXX.html"}
        # and is empty ({}) if auto-export is disabled or failed.
        #
        # Every line between here and the end of shutdown() is wrapped
        # in try/except at the method level (`_auto_export_reports`
        # already swallows exceptions internally, but an outer guard
        # protects against future refactors that might introduce a new
        # raise site). shutdown() is the worst possible moment to
        # surprise the host application.
        report_paths: dict[str, str] = {}
        if self._auto_export_on_shutdown:
            try:
                report_paths = self._auto_export_reports(
                    events_snapshot,
                    edge_activity=edge_activity_snapshot,
                    session_log=session_log_snapshot,
                    session_log_total=session_log_total,
                )
            except Exception:
                logger.debug(
                    "Shutdown: auto-export raised unexpectedly", exc_info=True
                )
                report_paths = {}

        try:
            self.logger.log_session_end(summary, report_paths=report_paths)
        except Exception:
            logger.debug(
                "Shutdown: log_session_end raised unexpectedly", exc_info=True
            )
            # Best-effort fallback: try to at least close the logger
            # so file handles are released even when the session-end
            # banner path exploded.
            try:
                self.logger.close()
            except Exception:
                pass

    def _auto_export_reports(
        self,
        events: list[CoordinationEvent],
        *,
        edge_activity: list[dict] | None = None,
        session_log: list[tuple[float, str, str]] | None = None,
        session_log_total: int | None = None,
    ) -> dict[str, str]:
        """Write report.json + report.html into the per-run session dir.

        Called from shutdown() when auto_export_on_shutdown is enabled.
        Writes into `self.logger.run_dir` with fixed filenames
        (`report.json` and `report.html`) so all 4 files for this run
        sit in the same directory. Lazy-imports the output modules so
        tests that never touch shutdown() don't pay the import cost —
        and so auto-export failures don't pollute the rest of shutdown.

        `edge_activity` is a pre-snapshotted list of per-edge activity
        records (from `CoordinationGraph.edge_activity_summary()`). When
        provided, the HTML renderer folds it into a "Run Activity" view
        that surfaces every delegation edge — including clean runs with
        zero alerts. Enriched in-place with `alert_count` derived from
        the events list before being forwarded to the HTML exporter.

        Returns a dict mapping report type ("json", "html") to the
        absolute file path that was written. A missing key means that
        report failed or was never generated — the session-end banner
        checks for presence before displaying a row.

        If the logger has no run_dir (file_output=False, or session
        directory creation failed), auto-export silently skips — the
        fallback path of writing reports somewhere else on disk would
        just create the loose-files problem users hit before. Better
        to skip and let the user know via the banner.
        """
        paths: dict[str, str] = {}

        # No session directory → nothing to write into. file_output=False
        # tests hit this path; so does a first-run permission failure
        # that degraded the logger to console-only mode.
        run_dir = getattr(self.logger, "run_dir", None)
        if run_dir is None:
            return paths

        try:
            from agentsonar._output.html_report import export_html
            from agentsonar._output.json_export import export_json
        except Exception:
            logger.debug("Auto-export: failed to import output modules", exc_info=True)
            return paths

        # Edge activity is passed through RAW. The HTML renderer folds
        # in per-edge severity counts AFTER the dedupe + inhibition
        # pipeline runs — otherwise the Edge Activity chips would say
        # "4 alerts" while the Coordination Failures section only shows
        # 1 card for that edge (because escalations got deduped and
        # repetitive symptoms got inhibited by their root-cause cycle).
        activity_for_html = list(edge_activity) if edge_activity else []

        # Fixed filenames — the enclosing run dir already carries the
        # timestamp and session id, so the files inside it don't need
        # a timestamp prefix of their own.
        import os as _os
        try:
            paths["json"] = export_json(
                events, path=_os.path.join(run_dir, "report.json"),
            )
        except Exception:
            logger.debug("Auto-export: JSON report failed", exc_info=True)

        try:
            paths["html"] = export_html(
                events,
                path=_os.path.join(run_dir, "report.html"),
                title=self._auto_export_title,
                edge_activity=activity_for_html,
                session_log=session_log,
                session_log_total=session_log_total,
            )
        except Exception:
            logger.debug("Auto-export: HTML report failed", exc_info=True)

        return paths

