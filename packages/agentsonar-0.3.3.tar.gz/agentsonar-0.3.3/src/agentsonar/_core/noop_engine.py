"""
_NoOpEngine — the "host-safety fallback" engine.

When the real `DetectionEngine` fails to construct (bad user config,
platform/permission issues, missing dependencies, etc.) we MUST NOT
let the failure propagate into the host application. AgentSonar's
prime directive is *the observer must never crash the observed
system* — if we can't monitor, we fall back to a silent no-op and
let the host keep running.

This module provides `_NoOpEngine`, a drop-in replacement that:

  * Exposes the same public surface as `DetectionEngine`
    (ingest, get_summary, get_recent_events, shutdown,
    increment_iteration, session_id, logger).
  * Silently swallows every `ingest(...)` call.
  * Returns empty-but-valid results from getters so downstream
    code that inspects the engine doesn't trip on `None`.
  * Keeps `shutdown()` idempotent and exception-free.

`_NoOpEngine` is NEVER instantiated during normal operation. The
integration layer (`AgentSonarCallback`, `AgentSonarListener`,
`monitor`) falls back to it only when the real engine's constructor
raises, and logs a clear warning so users know AgentSonar is
running in degraded mode.
"""
from __future__ import annotations

import logging
import uuid
from typing import Any

logger = logging.getLogger("agentsonar")


class _NoOpLogger:
    """Minimal logger stand-in that matches the small slice of
    `SonarLogger`'s surface the integrations touch.

    Every method is a no-op. `run_dir` and `logs_root` are None so
    the auto-export path in the real engine's shutdown() correctly
    skips (it already checks `run_dir is None`). `_closed` is True
    so any code that probes "has this logger been closed?" gets a
    consistent answer.
    """

    run_dir: str | None = None
    logs_root: str | None = None
    _closed: bool = True

    def log_session_start(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_session_end(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_delegation(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_graph_update(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_alert(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_alert_resolved(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_cycle_detected(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_anomaly_detected(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_rate_limit_hit(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_scc_sweep(self, *args: Any, **kwargs: Any) -> None:
        pass

    def close(self) -> None:
        pass


class _NoOpEngine:
    """Silent fallback for failed `DetectionEngine` construction.

    Matches the exact subset of `DetectionEngine`'s public surface
    that the `_integrations/` layer touches:

        .session_id
        .logger
        .ingest(event)
        .increment_iteration()
        .get_summary()
        .get_recent_events()
        .shutdown()

    Every method either does nothing or returns a harmless empty
    result. No I/O, no state, no locks. The host application keeps
    running exactly as it would without AgentSonar.

    This class is PRIVATE to AgentSonar — users never see it, they
    only notice that `AgentSonarCallback()` / `AgentSonarListener()`
    / `monitor()` all quietly succeeded with a warning in the logs.
    """

    def __init__(self, reason: str | None = None) -> None:
        self.session_id = uuid.uuid4().hex[:16]
        self.logger = _NoOpLogger()
        self._shutdown_requested = False
        self.iteration_count = 0
        self._reason = reason or "AgentSonar running in degraded (no-op) mode"

    def ingest(self, event: Any) -> list:
        """Swallow every event. Host never sees an exception."""
        return []

    def increment_iteration(self) -> None:
        self.iteration_count += 1

    def get_summary(self) -> dict:
        """Return an empty-but-valid summary dict.

        Downstream HTML/JSON export code already handles empty event
        lists (the new "No coordination failures detected" banner), so
        feeding it an empty summary is safe.
        """
        return {
            "total_events": 0,
            "iteration_count": self.iteration_count,
            "edge_counts": {},
            "total_estimated_token_waste": 0,
            "alerts_raised": 0,
            "alerts": [],
            "degraded": True,
            "degraded_reason": self._reason,
        }

    def get_recent_events(self) -> list:
        return []

    def should_prevent(self) -> Any:
        """No-op — degraded engines never trip prevent mode."""
        return None

    def check_prevent(self) -> Any:
        """No-op — degraded engines never raise PreventError."""
        return None

    def shutdown(self) -> None:
        """Idempotent no-op shutdown. Never raises."""
        self._shutdown_requested = True
