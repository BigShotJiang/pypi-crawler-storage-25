"""
AgentSonar schema and detection constants.

Token tracking, cost estimation, and velocity metrics are out of scope
for v0.1.0. The schema intentionally omits these fields.
"""
from __future__ import annotations

SCHEMA_VERSION = "0.1.0"

# Default thresholds — may be overridden via DetectionEngine config dict
DEFAULT_CYCLE_WARNING_ROTATIONS = 3
DEFAULT_CYCLE_CRITICAL_ROTATIONS = 10
DEFAULT_REPETITIVE_WARNING_COUNT = 5
DEFAULT_REPETITIVE_CRITICAL_COUNT = 15
DEFAULT_STALL_THRESHOLD_SECONDS = 300
