"""
Layer 5: PeriodicSCCAnalyzer — O(V+E) backup SCC sweep.

Runs on a time/event interval and returns every strongly-connected
component with 2+ nodes. Catches cycles that the incremental
CycleDetector may have missed or retroactively exposes via back-edges.

Separated from AlertStateManager (Layer 4) — they had nothing to do with
each other besides living in the same file in the prototype.
"""
from __future__ import annotations

import networkx as nx


class PeriodicSCCAnalyzer:
    """Periodic SCC (Strongly Connected Components) sweep.

    Runs every N seconds or N events, whichever comes first.  Finds all
    SCCs with 2+ nodes, which represent groups of agents that can reach
    each other — i.e., cycle groups.

    Args:
        interval_seconds: Minimum time between sweeps (default 10).
        interval_events: Minimum events between sweeps (default 50).
    """

    def __init__(
        self,
        interval_seconds: float = 10.0,
        interval_events: int = 50,
    ):
        self.interval_seconds = interval_seconds
        self.interval_events = interval_events
        self.last_run_time: float = 0.0
        self.events_since_last_run: int = 0

    def maybe_run(self, graph: nx.DiGraph, now: float) -> list[dict] | None:
        """Increment event counter and run SCC analysis if interval is reached.

        Returns list of cycle-group dicts if analysis ran, None if skipped.
        """
        self.events_since_last_run += 1

        time_ok = (now - self.last_run_time) >= self.interval_seconds
        events_ok = self.events_since_last_run >= self.interval_events

        if not time_ok and not events_ok:
            return None

        # Reset counters
        self.last_run_time = now
        self.events_since_last_run = 0

        results: list[dict] = []
        for scc in nx.strongly_connected_components(graph):
            if len(scc) < 2:
                continue
            subgraph = graph.subgraph(scc)
            edge_counts = [data.get("count", 0) for _, _, data in subgraph.edges(data=True)]
            min_rotations = min(edge_counts) if edge_counts else 0
            # Sort the agents for a deterministic order and convert
            # the set to a list. NetworkX returns a `set` here which
            # would serialize to JSON via the logger's `default=str`
            # fallback as a Python repr string (e.g. `"{'alice', 'bob'}"`)
            # — NOT a JSON array. Machine consumers parsing the timeline
            # would lose agent structure for SCC sweep events. Explicit
            # list + sort is both JSON-safe and deterministic.
            agents_sorted = sorted(scc)
            fingerprint = ("scc",) + tuple(agents_sorted)
            results.append({
                "fingerprint": fingerprint,
                "agents": agents_sorted,
                "min_rotations": min_rotations,
                "size": len(scc),
            })

        return results

    def reset(self) -> None:
        """Reset counters."""
        self.last_run_time = 0.0
        self.events_since_last_run = 0
