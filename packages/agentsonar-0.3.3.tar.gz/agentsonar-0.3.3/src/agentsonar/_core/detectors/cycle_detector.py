"""
Layer 3: CycleDetector — O(V+E) cycle detection via has_path.

Detects when a delegation creates or extends a graph cycle.  Uses
has_path + shortest_path rather than simple_cycles for efficiency.
Reports CycleInfo; does NOT decide severity (that's AlertStateManager).
"""
from __future__ import annotations

import networkx as nx

from agentsonar._core.models import CycleInfo, InteractionEvent


class CycleDetector:
    """Stateless cycle detector.

    On each event (src -> dst), checks whether a path already exists from
    dst back to src in the graph.  If so, extracts the cycle path and
    computes rotation count (min edge count around the loop).
    """

    def __init__(self) -> None:
        pass  # stateless — thresholds live in AlertStateManager

    def check(self, graph: nx.DiGraph, event: InteractionEvent) -> CycleInfo | None:
        """Check if the latest event creates or extends a cycle.

        Returns CycleInfo if a cycle exists through this edge, else None.
        """
        src = event.source_agent
        dst = event.target_agent

        # Self-loop is not a meaningful coordination cycle
        if src == dst:
            return None

        # If dst can reach src, then src->dst closes a cycle
        try:
            if not graph.has_node(dst) or not graph.has_node(src):
                return None
            if not nx.has_path(graph, dst, src):
                return None
        except (nx.NetworkXError, nx.NodeNotFound):
            return None

        try:
            path = nx.shortest_path(graph, dst, src)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return None

        # Full cycle: src -> ... path from dst to src ... but path starts at dst
        # path = [dst, ..., src], so full cycle = [src] + [dst, ..., src] minus trailing src
        # i.e. cycle_path = [src] + path[:-1]  (the cycle loops back to src implicitly)
        cycle_path = [src] + path[:-1]

        # Build edges around the cycle: (A,B), (B,C), (C,A)
        cycle_edges = list(zip(cycle_path, cycle_path[1:] + cycle_path[:1]))
        edge_counts: dict[tuple[str, str], int] = {}
        counts = []
        for u, v in cycle_edges:
            if graph.has_edge(u, v):
                c = graph.edges[u, v].get("count", 0)
            else:
                c = 0
            edge_counts[(u, v)] = c
            counts.append(c)

        rotations = min(counts) if counts else 0
        fingerprint = tuple(sorted(set(cycle_path)))

        return CycleInfo(
            fingerprint=fingerprint,
            cycle_path=cycle_path,
            rotations=rotations,
            edge_counts=edge_counts,
        )

    def reset(self) -> None:
        """Nothing to reset (stateless)."""
        pass
