"""
Detection layer implementations. Internal — not part of the public API.

Layer 1: SlidingWindowLimiter      — rate-limit circuit breaker
Layer 2: ExponentialDecayDetector  — decay-weighted edge anomaly
Layer 3: CycleDetector             — incremental cycle detection
Layer 4: AlertStateManager         — alert state machine (WARNING → CRITICAL → RESOLVED)
Layer 5: PeriodicSCCAnalyzer       — backup SCC sweep
"""
from agentsonar._core.detectors.alert_state import AlertStateManager
from agentsonar._core.detectors.cycle_detector import CycleDetector
from agentsonar._core.detectors.rate_limiter import SlidingWindowLimiter
from agentsonar._core.detectors.repetitive_detector import ExponentialDecayDetector
from agentsonar._core.detectors.scc_analyzer import PeriodicSCCAnalyzer

__all__ = [
    "AlertStateManager",
    "CycleDetector",
    "ExponentialDecayDetector",
    "PeriodicSCCAnalyzer",
    "SlidingWindowLimiter",
]
