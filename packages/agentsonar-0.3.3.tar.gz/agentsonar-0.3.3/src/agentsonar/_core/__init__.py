"""
AgentSonar core — internal detection engine.

Not part of the public API. Consumers should import from `agentsonar`
directly (AgentSonarListener, AgentSonarCallback).
"""
