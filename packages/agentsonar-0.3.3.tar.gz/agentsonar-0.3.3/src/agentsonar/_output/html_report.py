"""
Standalone HTML report for AgentSonar CoordinationEvents.

Renders a self-contained HTML file with one card per event. Uses inline CSS
and a tiny inline JavaScript filter (no external dependencies). Each card
expands to show populated schema blocks: topology, thresholds, provider
errors, and downstream impact. INFO-severity events are filtered out, and
events are sorted CRITICAL first, WARNING second.

By default, the renderer applies the same summary pipeline as the JSON
exporter: dedupe by coordination_fingerprint AND inhibit symptom events
subsumed by root-cause alerts. Pass `dedupe=False` to get the raw
chronological timeline with every state transition preserved.
"""
from __future__ import annotations

import html
import json
import os
from datetime import datetime, timezone

from agentsonar._core.schema import (
    CoordinationEvent,
    dedupe_events_by_fingerprint,
    inhibit_subsumed_events,
)
from agentsonar._output.json_export import _sanitize_for_json


# Short human-readable descriptions for every failure class, shown as
# hover tooltips on the failure class label in each event card. Keeps
# the glossary next to the data so readers don't have to jump to the
# README every time they see an unfamiliar term.
_FAILURE_CLASS_DESCRIPTIONS = {
    "cyclic_delegation": (
        "Agents are stuck in a loop. A delegates to B, B to C, C back "
        "to A. Often means an exit condition is missing — e.g. the "
        "reviewer never approves, so the cycle never terminates."
    ),
    "repetitive_delegation": (
        "One agent keeps calling another without making progress. A "
        "sends many requests to B in a short window. Often means A "
        "can't make a decision without B and isn't getting what it needs."
    ),
    "resource_exhaustion": (
        "The system is processing events faster than it can handle. "
        "Either one edge is being hammered (per-edge rate limit) or "
        "total throughput is too high (global rate limit). Indicates "
        "a runaway agent or insufficient throttling."
    ),
    "cascade_failure": (
        "A chain of related failures — one agent's problem triggers "
        "failures in downstream agents. Reserved for future use."
    ),
    "authority_violation": (
        "An agent performed an action it wasn't authorized to perform. "
        "Reserved for future use."
    ),
    "deadlock": (
        "Every agent is blocked waiting on another agent. No progress "
        "is possible. Reserved for future use."
    ),
    "agent_stall": (
        "A single agent has stopped producing output without signaling "
        "failure. Reserved for future use."
    ),
    "token_velocity_anomaly": (
        "Token consumption rate is far above expected baseline. "
        "Reserved for future use."
    ),
}


def _summarize(events: list[CoordinationEvent]) -> list[CoordinationEvent]:
    """Apply dedupe + inhibition — the summary view pipeline."""
    deduped = dedupe_events_by_fingerprint(events)
    return inhibit_subsumed_events(deduped)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def export_html(
    events: list[CoordinationEvent],
    path: str | None = None,
    *,
    output_dir: str = ".",
    title: str = "AgentSonar Report",
    dedupe: bool = True,
    edge_activity: list[dict] | None = None,
    session_log: list[tuple[float, str, str]] | None = None,
    session_log_total: int | None = None,
) -> str:
    """Write a standalone HTML report for the given events.

    Args:
        events: List of CoordinationEvent objects.
        path: Destination file path. If None, auto-generates a timestamped
            filename of the form `agentsonar_report_YYYYMMDD_HHMMSS_mmm.html`
            in `output_dir`. The `_mmm` millisecond suffix guarantees
            back-to-back calls don't collide on the same filename.
        output_dir: Directory for the auto-generated filename (keyword-only).
            Ignored when `path` is provided explicitly. Created if missing.
        title: Page title for the report (keyword-only).
        dedupe: If True (default), produce a SUMMARY view: collapse events
            with the same coordination_fingerprint (keep highest severity /
            latest), AND inhibit symptom events (e.g. a REPETITIVE_DELEGATION
            edge that's part of a detected CYCLIC_DELEGATION is suppressed
            because the cycle is the root cause). Events are then sorted
            CRITICAL-first, WARNING-second for quick scanning.

            If False, include every raw state transition in chronological
            order (timeline view) so you can trace what happened when.
        edge_activity: Optional per-edge activity records powering the
            "Run Activity" view — one row per delegation edge with
            source, target, count, first_ts, last_ts, and alert_count.
            When provided (even on clean runs with zero alerts), renders
            as a visible section between the summary and the event cards.
            Omit to suppress the section (legacy / tests / manual exports).
        session_log: Optional chronological list of delegation tuples
            `(timestamp, src_agent, tgt_agent)`. When provided, renders
            a "Session Log" <details> section (collapsed by default) and
            adds an "Information" chip to the summary counts that, when
            clicked, opens the details block and scrolls to it. This is
            the INFO-level view users click into to see "what happened
            and in what order" — independent of whether alerts fired.
        session_log_total: Optional uncapped count of session events.
            If the engine's session log was bounded (see engine's
            `_MAX_SESSION_LOG`), `session_log` may be a tail of the
            true stream. Pass the true total so the renderer can show
            "showing N most recent of M total". Defaults to
            `len(session_log)` if omitted.

    Returns:
        The actual file path written.
    """
    # Compute alert timestamps from the FULL event list BEFORE dedup so
    # the Chronological Log row coloring shows every WARNING/CRITICAL
    # alert that actually fired during the run, not just the deduped
    # summary survivor. The synthetic "prevention" event uses
    # time.time() to win dedup, which would otherwise leave us with
    # one un-matchable timestamp; this preserves the full history.
    # Same pre-dedup snapshot is also handed to _render_html so Edge
    # Activity per-edge alert counts reflect the full alert history,
    # not just the deduped summary survivor.
    pre_dedup_alert_timestamps = _compute_alert_timestamps_by_severity(events)
    pre_dedup_events_snapshot = list(events)

    if dedupe:
        events = _summarize(events)

    if path is None:
        os.makedirs(output_dir, exist_ok=True)
        # Millisecond precision (YYYYMMDD_HHMMSS_mmm) so back-to-back
        # exports in the same second don't collide. strftime's %f is
        # microseconds (6 digits); we slice to 3 for milliseconds.
        #
        # LOCAL time (not UTC) is intentional — only applies to the
        # auto-generated filename path, which is a local-machine
        # browsing affordance. The "Generated at" banner INSIDE the
        # rendered HTML (see _render_html further down) uses UTC so
        # shared reports are timezone-unambiguous.
        now = datetime.now()
        ts = now.strftime("%Y%m%d_%H%M%S") + f"_{now.microsecond // 1000:03d}"
        path = os.path.join(output_dir, f"agentsonar_report_{ts}.html")
    else:
        # Make sure the parent directory exists for explicit paths too.
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        f.write(
            _render_html(
                events,
                title,
                sort_by_severity=dedupe,
                edge_activity=edge_activity,
                session_log=session_log,
                session_log_total=session_log_total,
                pre_dedup_alert_timestamps=pre_dedup_alert_timestamps,
                pre_dedup_events=pre_dedup_events_snapshot,
            )
        )
    return path


def events_to_html(
    events: list[CoordinationEvent],
    title: str = "AgentSonar Report",
    *,
    dedupe: bool = True,
    edge_activity: list[dict] | None = None,
    session_log: list[tuple[float, str, str]] | None = None,
    session_log_total: int | None = None,
) -> str:
    """Render events to an HTML string without writing to disk.

    See `export_html` for the `dedupe`, `edge_activity`, and
    `session_log` parameter semantics. Kept as a thin wrapper so
    callers (tests, in-memory snapshotting) can inspect the rendered
    output without touching the filesystem.
    """
    # See write_html: compute alert timestamps + snapshot events BEFORE
    # dedup so the Chronological Log row coloring AND Edge Activity
    # per-edge alert counts both see every WARNING/CRITICAL that fired,
    # not just the deduped summary survivor.
    pre_dedup_alert_timestamps = _compute_alert_timestamps_by_severity(events)
    pre_dedup_events_snapshot = list(events)
    if dedupe:
        events = _summarize(events)
    return _render_html(
        events,
        title,
        sort_by_severity=dedupe,
        edge_activity=edge_activity,
        session_log=session_log,
        pre_dedup_alert_timestamps=pre_dedup_alert_timestamps,
        pre_dedup_events=pre_dedup_events_snapshot,
        session_log_total=session_log_total,
    )


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

# Events sorted by severity for display — CRITICAL first, then WARNING.
# Also acts as a whitelist: severities not in this dict (e.g. INFO) are
# filtered out of the rendered report.
_SEVERITY_RANK = {"CRITICAL": 0, "WARNING": 1}


def _render_html(
    events: list[CoordinationEvent],
    title: str,
    sort_by_severity: bool = True,
    edge_activity: list[dict] | None = None,
    session_log: list[tuple[float, str, str]] | None = None,
    session_log_total: int | None = None,
    pre_dedup_alert_timestamps: dict[float, str] | None = None,
    pre_dedup_events: list[CoordinationEvent] | None = None,
) -> str:
    # UTC ISO 8601 with second precision for the "Generated at" meta
    # line. Explicit UTC (not local time) because reports are meant to
    # be shareable across timezones — a user viewing a report their
    # colleague generated shouldn't have to guess whether the timestamp
    # was PST, IST, or UTC. ISO 8601 format with the explicit `+00:00`
    # suffix is unambiguous and matches the timestamps inside each
    # CoordinationEvent's `timestamp_iso` field.
    generated_at_utc = datetime.now(timezone.utc).isoformat(timespec="seconds")

    # Filter out INFO events — the report only surfaces actionable severities
    displayed = [e for e in events if e.severity.value in _SEVERITY_RANK]

    # Summary view: sort CRITICAL-first for quick scanning.
    # Timeline view: preserve chronological input order.
    if sort_by_severity:
        displayed = sorted(
            displayed,
            key=lambda e: _SEVERITY_RANK.get(e.severity.value, 99),
        )

    cards = "\n".join(_render_event_card(e) for e in displayed)

    # Clean-run banner: no WARNING / CRITICAL events to surface means
    # the run completed without any coordination failures that crossed
    # the alert thresholds. Prefer a positive confirmation over the
    # old "No coordination events detected." gray placeholder — users
    # need to SEE that the run is clean, not just notice that the
    # card list is empty. Still wraps the phrase "No coordination"
    # so existing test assertions continue to match.
    # Session log total for the Chronological Log tab count badge.
    # `session_log_total` may exceed len(session_log) when the engine
    # capped the buffer — we show the TRUE total so users aren't misled
    # by a truncated tail. Fallback to len() when the uncapped total
    # wasn't provided (legacy callers, standalone HTML export).
    log_total = 0
    if session_log is not None:
        log_total = session_log_total if session_log_total is not None else len(session_log)

    # "Coordination Failures" section — the primary-signal section, per
    # the Sentry / Snyk pattern. Either shows alert cards with a filter
    # chip bar above (alert run) or the green clean-run banner (clean
    # run). The section always renders with an <h2> so readers know
    # what they're looking at without guessing.
    coordination_failures_html = _render_coordination_failures(displayed, cards)

    # Enrich edge_activity with per-edge severity counts. We feed the
    # PRE-DEDUP event list when available so every CRITICAL/WARNING
    # alert that fired during the run contributes to the per-edge
    # counts shown in Edge Activity. The deduped list collapses to one
    # event per fingerprint (and after Prevent Mode work, that survivor
    # is the synthetic "prevention" event with empty edge_frequency,
    # which would zero out every edge's alert count). Pre-dedup
    # preserves the full alert history; we still INFO-filter to keep
    # parity with the summary view.
    enrich_source: list[CoordinationEvent]
    if pre_dedup_events is not None:
        enrich_source = [
            e for e in pre_dedup_events
            if e.severity.value in _SEVERITY_RANK
            and e.event_type != "prevention"
        ]
    else:
        enrich_source = displayed
    enriched_activity = (
        _enrich_edge_activity_by_severity(edge_activity, enrich_source)
        if edge_activity
        else None
    )

    # Map timestamp -> severity ("critical" or "warning") for session
    # log highlighting. Each Chronological Log row whose delegation
    # timestamp matches an alert gets a colored background so users can
    # see WHEN the failure fired relative to surrounding activity —
    # pattern recognition at a glance.
    #
    # IMPORTANT: this map MUST be computed from the PRE-DEDUP event list,
    # not from `displayed`. Dedup collapses many alerts (one per
    # threshold crossing + the synthetic "prevention" event) down to a
    # single card per fingerprint. If we compute timestamps from the
    # deduped list, only the surviving event's timestamp ends up in the
    # map, and only one log row gets colored — even though many alerts
    # actually fired. The caller passes `pre_dedup_alert_timestamps`
    # computed from the raw event list before dedup; we fall back to
    # computing from `displayed` only when no pre-dedup map was
    # provided (legacy code paths / direct tests).
    if pre_dedup_alert_timestamps is not None:
        alert_timestamps = pre_dedup_alert_timestamps
    else:
        alert_timestamps = _compute_alert_timestamps_by_severity(displayed)

    # "Session Activity" section — tabbed container holding the two
    # INFO-level peer views (Edge Activity aggregate + Chronological Log
    # raw stream). Renders only when at least one of the underlying
    # datasets was provided; otherwise suppressed entirely to keep the
    # report compact for legacy callers that don't pass either.
    session_activity_html = _render_session_activity(
        edge_activity=enriched_activity,
        session_log=session_log,
        session_log_total=log_total,
        alert_timestamps=alert_timestamps,
    )

    # Session Activity badge count. Prefer the session_log total
    # (matches what users see inside the Chronological Log tab). When
    # only edge_activity is available, sum the per-edge fire counts
    # — semantically that's the total event count across all edges.
    # BUGFIX: previously used `len(edge_activity)` (edge COUNT), not
    # the event total, which misled the badge on edge-only reports.
    if session_log is not None:
        session_badge_count = log_total
    elif edge_activity:
        session_badge_count = sum(
            int(r.get("count", 0) or 0) for r in edge_activity
        )
    else:
        session_badge_count = 0

    # Wrap both sections into top-level tabs only when there's real
    # data for Session Activity. Otherwise (legacy callers, tiny
    # tests) render failures section directly — no tab nav.
    page_body_html = _render_main_tabs(
        coordination_failures_html=coordination_failures_html,
        session_activity_html=session_activity_html,
        coordination_count=len(displayed),
        session_count=session_badge_count,
    )

    # Pretty-printed JSON of every displayed event (same data that
    # `export_json()` writes to the `.json` sidecar file). Embedded in
    # the HTML inside a collapsible <details> block so users who want
    # the raw machine-readable view don't have to open a second file.
    # `_sanitize_for_json` + `allow_nan=False` produces strict JSON
    # even if an event carries a NaN/Infinity timestamp — see the
    # json_export module for the rationale.
    # `ensure_ascii=False` writes native Unicode so CJK / emoji agent
    # names display correctly in the browser. The HTML document has
    # `<meta charset="UTF-8">` and html.escape() only touches the
    # HTML-special characters `& < > ' "`, so Unicode passes through
    # unchanged.
    all_events_json = json.dumps(
        _sanitize_for_json([e.to_dict() for e in displayed]),
        indent=2,
        default=str,
        allow_nan=False,
        ensure_ascii=False,
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{html.escape(title)}</title>
<script>
(function () {{
    try {{
        var stored = localStorage.getItem("agentsonar-theme");
        var theme;
        if (stored === "light" || stored === "dark") {{
            theme = stored;
        }} else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {{
            theme = "dark";
        }} else {{
            theme = "light";
        }}
        document.documentElement.setAttribute("data-theme", theme);
    }} catch (_) {{
        /* localStorage blocked — fall through to CSS default (light) */
    }}
}})();
</script>
<style>
:root {{
    color-scheme: light dark;

    --bg:              #f4f4f6;
    --fg:              #1a1a1a;
    --fg-muted:        #6b6b6b;
    --fg-dim:          #8a8a8a;

    --card-bg:         #ffffff;
    --card-bg-hover:   #eceef2;
    --card-bg-pill:    #f8f8fa;
    --border:          #e0e0e4;
    --border-soft:     #f0f0f3;
    --border-dotted:   #bbbbbb;

    --critical:        #c0392b;
    --critical-bg:     #fdf0ee;
    --warning:         #e67e22;
    --warning-bg:      #fef5ed;
    --clean:           #1f9b5c;
    --clean-bg:        #edfbf3;
    --clean-border:    #c6ecd6;
    --clean-fg:        #0d6b3c;

    --heading-link:    #2c3e50;
    --event-body-fg:   #4a4a4a;
}}
[data-theme="dark"] {{
    --bg:              #0d1117;
    --fg:              #e6edf3;
    --fg-muted:        #8b949e;
    --fg-dim:          #6e7681;

    --card-bg:         #161b22;
    --card-bg-hover:   #1c222b;
    --card-bg-pill:    #21262d;
    --border:          #30363d;
    --border-soft:     #21262d;
    --border-dotted:   #484f58;

    --critical:        #f85149;
    --critical-bg:     #321a1a;
    --warning:         #e0833d;
    --warning-bg:      #32241a;
    --clean:           #3fb950;
    --clean-bg:        #0f2818;
    --clean-border:    #1f5131;
    --clean-fg:        #9ee6b1;

    --heading-link:    #58a6ff;
    --event-body-fg:   #c9d1d9;
}}

body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    background: var(--bg);
    color: var(--fg);
    max-width: 960px;
    margin: 2rem auto;
    padding: 0 1.5rem;
    line-height: 1.5;
    transition: background 0.15s ease, color 0.15s ease;
}}
h1 {{
    margin-bottom: 0.25rem;
}}
.meta {{
    color: var(--fg-muted);
    font-size: 0.9rem;
    margin-bottom: 2rem;
}}

.theme-toggle {{
    position: fixed;
    top: 1rem;
    right: 1rem;
    z-index: 100;
    background: var(--card-bg);
    border: 1px solid var(--border);
    border-radius: 999px;
    padding: 0.4rem 0.75rem;
    font-size: 1rem;
    cursor: pointer;
    color: var(--fg);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
    transition: background 0.15s ease, border-color 0.15s ease;
}}
.theme-toggle:hover {{
    background: var(--card-bg-hover);
}}
.theme-toggle .theme-label {{
    margin-left: 0.4rem;
    font-size: 0.75rem;
    color: var(--fg-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
}}

/* ----- Top-level (main) tabs — "Coordination Failures" vs "Session Activity" */
.main-tabs {{
    display: flex;
    gap: 0;
    border-bottom: 2px solid var(--border);
    margin: 1.5rem 0 2rem 0;
}}
.main-tab {{
    appearance: none;
    background: transparent;
    border: none;
    border-bottom: 3px solid transparent;
    padding: 0.85rem 1.5rem;
    font-size: 1.05rem;
    font-weight: 600;
    cursor: pointer;
    color: var(--fg-muted);
    font-family: inherit;
    transition: color 0.15s ease, border-color 0.15s ease;
    /* Compensate for the 2px tabs-bar border so the active 3px
       underline visually sits on top of the bar — clean merged look. */
    margin-bottom: -2px;
}}
.main-tab:hover {{
    color: var(--fg);
}}
.main-tab.active {{
    color: var(--heading-link);
    border-bottom-color: var(--heading-link);
}}
.main-tab-badge {{
    display: inline-block;
    margin-left: 0.5rem;
    padding: 2px 10px;
    border-radius: 999px;
    background: var(--card-bg-pill);
    border: 1px solid var(--border);
    color: var(--fg-muted);
    font-size: 0.75rem;
    font-weight: 700;
    font-family: "SF Mono", Consolas, monospace;
    vertical-align: 2px;
}}
.main-tab.active .main-tab-badge {{
    background: var(--card-bg-hover);
    color: var(--heading-link);
    border-color: var(--heading-link);
}}
.main-tab-panel {{
    display: none;
}}
.main-tab-panel.active {{
    display: block;
}}

section.coordination-failures,
section.session-activity {{
    margin: 0 0 2rem 0;
}}
.section-title {{
    margin: 0 0 0.75rem 0;
    font-size: 1.4rem;
    font-weight: 600;
    color: var(--fg);
}}
.filter-chip-bar {{
    background: var(--card-bg);
    border-radius: 8px;
    padding: 1rem 1.5rem;
    margin-bottom: 1rem;
    border: 1px solid var(--border);
}}
.filter-hint {{
    color: var(--fg-dim);
    font-size: 0.8rem;
    margin: 0 0 0.75rem 0;
}}
.summary-counts {{
    display: flex;
    gap: 1rem;
    margin-top: 0.5rem;
}}
.count-item {{
    font-size: 1.1rem;
    cursor: pointer;
    padding: 0.75rem 1.25rem;
    border-radius: 8px;
    border: 2px solid transparent;
    background: var(--card-bg-pill);
    transition: all 0.15s ease;
    user-select: none;
    min-width: 100px;
    color: var(--fg);
}}
.count-item:hover {{
    background: var(--card-bg-hover);
}}
.count-item.active {{
    border-color: var(--fg);
    background: var(--card-bg);
}}
.count-item.critical {{ color: var(--critical); }}
.count-item.critical.active {{ border-color: var(--critical); background: var(--critical-bg); }}
.count-item.warning {{ color: var(--warning); }}
.count-item.warning.active {{ border-color: var(--warning); background: var(--warning-bg); }}
.count-item strong {{
    display: block;
    font-size: 1.8rem;
}}
article.event {{
    background: var(--card-bg);
    border-radius: 8px;
    margin-bottom: 1rem;
    border: 1px solid var(--border);
    border-left: 4px solid var(--border);
    overflow: hidden;
}}
article.event.critical {{ border-left-color: var(--critical); }}
article.event.warning {{ border-left-color: var(--warning); }}
/* Prevention events — synthetic events emitted when Prevent Mode trips.
   Visually loudest because they represent the moment AgentSonar
   intervened. Same red as critical (it IS a critical state) but with a
   thicker left border and a faint red wash so users instantly identify
   the trip entry without parsing severity badges. */
article.event.prevented {{
    border-left-width: 8px;
    border-left-color: var(--critical);
    background: linear-gradient(
        90deg,
        color-mix(in srgb, var(--critical) 8%, transparent) 0%,
        transparent 60%
    );
}}
.event-header {{
    padding: 1rem 1.5rem;
    border-bottom: 1px solid var(--border-soft);
}}
.event-title {{
    font-weight: 600;
    font-size: 1.05rem;
    margin: 0 0 0.25rem 0;
}}
.event-summary {{
    margin: 0;
    color: var(--event-body-fg);
}}
.badge {{
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 700;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-right: 0.5rem;
}}
.badge.critical {{ background: var(--critical); }}
.badge.warning {{ background: var(--warning); }}
/* Prevention badge — slightly darker than critical so it stands out
   when both badges sit side-by-side in the same event-title row. */
.badge.prevented {{
    background: #8b0a14;
    color: #fff;
    text-transform: none;
    letter-spacing: 0;
    font-weight: 700;
}}
.event-body {{
    padding: 0 1.5rem 1rem;
}}
details {{
    margin: 0.75rem 0;
}}
details summary {{
    cursor: pointer;
    color: var(--heading-link);
    font-weight: 500;
}}
.kv {{
    display: grid;
    grid-template-columns: max-content 1fr;
    gap: 0.25rem 1rem;
    margin: 0.5rem 0 0.5rem 1rem;
    font-size: 0.9rem;
}}
.kv .k {{
    color: var(--fg-muted);
}}
.kv .v {{
    font-family: "SF Mono", Consolas, monospace;
    font-size: 0.85rem;
}}
.fingerprint {{
    font-family: "SF Mono", Consolas, monospace;
    font-size: 0.75rem;
    color: var(--fg-dim);
    word-break: break-all;
    margin-top: 0.25rem;
}}
.fingerprint-label,
.id-label {{
    font-family: inherit;
    font-size: 0.7rem;
    color: var(--fg-dim);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-right: 0.35rem;
    cursor: help;
    border-bottom: 1px dotted var(--border-dotted);
}}
.event-ids {{
    margin-top: 0.15rem;
    font-family: "SF Mono", Consolas, monospace;
    font-size: 0.72rem;
    color: var(--fg-dim);
    word-break: break-all;
}}
.event-ids > div {{
    margin-top: 0.1rem;
}}
.failure-class {{
    cursor: help;
    border-bottom: 1px dotted var(--border-dotted);
}}
.clean-run {{
    text-align: center;
    padding: 2.5rem 1.5rem;
    margin: 1rem 0 2rem 0;
    background: var(--clean-bg);
    border: 1px solid var(--clean-border);
    border-left: 4px solid var(--clean);
    border-radius: 8px;
    color: var(--clean-fg);
}}
.clean-run .clean-icon {{
    font-size: 2rem;
    display: block;
    margin-bottom: 0.5rem;
}}
.clean-run .clean-title {{
    font-weight: 600;
    font-size: 1.1rem;
    margin: 0 0 0.25rem 0;
    color: var(--clean);
}}
.clean-run .clean-sub {{
    font-size: 0.9rem;
    color: var(--fg-muted);
    margin: 0;
}}
.activity-hint {{
    color: var(--fg-dim);
    font-size: 0.8rem;
    margin: 0 0 0.75rem 0;
}}
.edge-card {{
    background: var(--card-bg);
    border: 1px solid var(--border);
    border-left: 4px solid var(--border);
    border-radius: 8px;
    padding: 0.85rem 1.25rem;
    margin-bottom: 0.5rem;
    transition: background 0.15s ease;
}}
.edge-card.has-critical {{
    border-left-color: var(--critical);
}}
.edge-card.has-warning {{
    border-left-color: var(--warning);
}}
.edge-card:hover {{
    background: var(--card-bg-hover);
}}
.edge-card > summary {{
    cursor: pointer;
    list-style: none;
    display: grid;
    grid-template-columns: 1fr auto auto;
    gap: 1rem;
    align-items: baseline;
    color: var(--fg);
    font-weight: 500;
}}
.edge-card > summary::-webkit-details-marker {{
    display: none;
}}
.edge-route {{
    font-family: "SF Mono", Consolas, monospace;
    font-size: 0.95rem;
}}
.edge-arrow {{
    color: var(--fg-muted);
    margin: 0 0.4rem;
}}
.edge-fires {{
    color: var(--fg-muted);
    font-size: 0.85rem;
    font-family: "SF Mono", Consolas, monospace;
}}
.edge-alerts-chip {{
    display: inline-block;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    padding: 2px 8px;
    border-radius: 999px;
    background: var(--card-bg-pill);
    color: var(--fg-muted);
    border: 1px solid var(--border);
}}
.edge-alerts-chip.has-critical {{
    background: var(--critical-bg);
    color: var(--critical);
    border-color: var(--critical);
}}
.edge-alerts-chip.has-warning {{
    background: var(--warning-bg);
    color: var(--warning);
    border-color: var(--warning);
}}
.edge-details {{
    display: grid;
    grid-template-columns: max-content 1fr;
    gap: 0.25rem 1rem;
    margin-top: 0.75rem;
    padding-top: 0.75rem;
    border-top: 1px solid var(--border-soft);
    font-size: 0.85rem;
}}
.edge-details .k {{
    color: var(--fg-muted);
}}
.edge-details .v {{
    font-family: "SF Mono", Consolas, monospace;
    font-size: 0.82rem;
    color: var(--fg);
}}
.tab-bar {{
    display: flex;
    gap: 0.25rem;
    border-bottom: 1px solid var(--border);
    margin-bottom: 1rem;
}}
.tab {{
    appearance: none;
    background: transparent;
    color: var(--fg-muted);
    border: none;
    border-bottom: 2px solid transparent;
    padding: 0.65rem 1rem;
    font-size: 0.95rem;
    font-family: inherit;
    font-weight: 500;
    cursor: pointer;
    transition: color 0.15s ease, border-color 0.15s ease;
    /* Small negative margin so the active tab's bottom-border
       sits on top of the tab-bar's own bottom-border — clean
       underline effect. */
    margin-bottom: -1px;
}}
.tab:hover {{
    color: var(--fg);
}}
.tab.active {{
    color: var(--heading-link);
    border-bottom-color: var(--heading-link);
}}
.tab-count {{
    display: inline-block;
    margin-left: 0.45rem;
    padding: 1px 8px;
    border-radius: 999px;
    background: var(--card-bg-pill);
    border: 1px solid var(--border);
    color: var(--fg-muted);
    font-size: 0.72rem;
    font-weight: 600;
    font-family: "SF Mono", Consolas, monospace;
    vertical-align: 1px;
}}
.tab.active .tab-count {{
    background: var(--card-bg-hover);
    color: var(--heading-link);
    border-color: var(--heading-link);
}}
.tab-panel {{
    display: none;
}}
.tab-panel.active {{
    display: block;
}}
.session-log-truncation {{
    color: var(--fg-dim);
    font-size: 0.78rem;
    font-style: italic;
    margin: 0 0 0.75rem 0;
}}
.session-log-list {{
    list-style: none;
    padding: 0;
    margin: 0;
    max-height: 480px;
    overflow: auto;
    border-radius: 6px;
    background: var(--card-bg-pill);
    border: 1px solid var(--border);
}}
.session-log-entry {{
    display: grid;
    grid-template-columns: max-content 1fr;
    gap: 1rem;
    padding: 0.4rem 0.85rem;
    font-family: "SF Mono", Consolas, monospace;
    font-size: 0.82rem;
    line-height: 1.5;
    border-bottom: 1px solid var(--border-soft);
}}
.session-log-entry:last-child {{
    border-bottom: none;
}}
.session-log-entry:nth-child(even) {{
    background: rgba(0, 0, 0, 0.02);
}}
[data-theme="dark"] .session-log-entry:nth-child(even) {{
    background: rgba(255, 255, 255, 0.02);
}}
/* Severity-tinted rows — highlighted when the delegation on this row
   triggered a WARNING / CRITICAL alert. Placed AFTER the :nth-child
   rule so specificity + source-order ensures severity wins over the
   zebra stripe. */
.session-log-entry.entry-warning,
[data-theme="dark"] .session-log-entry.entry-warning {{
    background: var(--warning-bg);
    border-left: 3px solid var(--warning);
    padding-left: calc(0.85rem - 3px);
}}
.session-log-entry.entry-critical,
[data-theme="dark"] .session-log-entry.entry-critical {{
    background: var(--critical-bg);
    border-left: 3px solid var(--critical);
    padding-left: calc(0.85rem - 3px);
}}
.session-log-highlight-hint {{
    color: var(--fg-muted);
    font-size: 0.8rem;
    margin: 0 0 0.75rem 0;
}}
.hint-legend {{
    display: inline-block;
    padding: 1px 8px;
    border-radius: 4px;
    font-size: 0.72rem;
    font-weight: 600;
    margin: 0 0.15rem;
}}
.hint-legend.entry-warning {{
    background: var(--warning-bg);
    color: var(--warning);
    border: 1px solid var(--warning);
    border-left-width: 3px;
}}
.hint-legend.entry-critical {{
    background: var(--critical-bg);
    color: var(--critical);
    border: 1px solid var(--critical);
    border-left-width: 3px;
}}
.session-log-time {{
    color: var(--fg-dim);
    white-space: nowrap;
}}
.session-log-route {{
    color: var(--fg);
}}
.session-log-route .edge-arrow {{
    color: var(--fg-muted);
    margin: 0 0.4rem;
}}
details.json-view {{
    background: var(--card-bg);
    border-radius: 8px;
    border: 1px solid var(--border);
    padding: 0.75rem 1.25rem;
    margin-top: 2rem;
}}
details.json-view > summary {{
    font-weight: 600;
    font-size: 1.05rem;
    color: var(--fg);
}}
details.json-view[open] > summary {{
    border-bottom: 1px solid var(--border-soft);
    padding-bottom: 0.5rem;
    margin-bottom: 0.75rem;
}}
.json-view-hint {{
    font-weight: 400;
    font-size: 0.8rem;
    color: var(--fg-dim);
    margin-left: 0.5rem;
}}
.json-toolbar {{
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin: 0.5rem 0 0.75rem 0;
}}
.json-copy-btn {{
    background: var(--card-bg-pill);
    color: var(--fg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 0.4rem 0.85rem;
    font-size: 0.8rem;
    font-family: inherit;
    cursor: pointer;
    transition: background 0.15s ease, border-color 0.15s ease;
}}
.json-copy-btn:hover {{
    background: var(--card-bg-hover);
}}
.json-copy-status {{
    font-size: 0.75rem;
    color: var(--fg-muted);
    font-style: italic;
}}
.json-block {{
    font-family: "SF Mono", Consolas, "Courier New", monospace;
    font-size: 0.78rem;
    background: var(--card-bg-pill);
    color: var(--fg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 0.85rem 1rem;
    margin: 0;
    max-height: 480px;
    overflow: auto;
    line-height: 1.45;
    white-space: pre;
    word-break: normal;
}}
</style>
</head>
<body>
<button
    type="button"
    class="theme-toggle"
    id="theme-toggle"
    aria-label="Toggle color theme"
    title="Toggle between light and dark mode. Respects your system preference by default; manual choices persist across runs via localStorage."
>
    <span class="theme-icon">\U0001f319</span><span class="theme-label">dark</span>
</button>
<h1>{html.escape(title)}</h1>
<p class="meta">
    Generated at
    <time
        datetime="{html.escape(generated_at_utc)}"
        title="UTC ISO 8601 timestamp. Explicit timezone so reports are timezone-agnostic when shared across teams."
    >{html.escape(generated_at_utc)} UTC</time>
</p>
{page_body_html}

<details class="json-view">
    <summary>
        Coordination Failures — Raw JSON
        <span class="json-view-hint">(same payload as report.json — pipe into dashboards and CI gates)</span>
    </summary>
    <div class="json-toolbar">
        <button type="button" class="json-copy-btn" id="json-copy-btn"
                title="Copy the JSON below to your clipboard">
            Copy JSON
        </button>
        <span class="json-copy-status" id="json-copy-status"></span>
    </div>
    <pre class="json-block" id="json-block">{html.escape(all_events_json)}</pre>
</details>
<script>
// ---------------------------------------------------------------------
// Theme toggle — click to switch between light and dark, and persist
// the choice in localStorage so the next run opens in the same theme.
// The initial theme was already set by the inline <head> script (before
// first paint) so this just wires up the button.
// ---------------------------------------------------------------------
(function () {{
    var btn = document.getElementById("theme-toggle");
    if (!btn) return;

    function currentTheme() {{
        return document.documentElement.getAttribute("data-theme") || "light";
    }}
    function applyTheme(theme) {{
        document.documentElement.setAttribute("data-theme", theme);
        // Button shows the icon + label for the theme you'll switch TO.
        var icon = btn.querySelector(".theme-icon");
        var label = btn.querySelector(".theme-label");
        if (theme === "dark") {{
            if (icon) icon.textContent = "\u2600\ufe0f";  // ☀️
            if (label) label.textContent = "light";
        }} else {{
            if (icon) icon.textContent = "\U0001f319";  // 🌙
            if (label) label.textContent = "dark";
        }}
    }}

    applyTheme(currentTheme());

    btn.addEventListener("click", function () {{
        var next = currentTheme() === "dark" ? "light" : "dark";
        applyTheme(next);
        try {{
            localStorage.setItem("agentsonar-theme", next);
        }} catch (_) {{
            /* localStorage blocked — toggle still works this session */
        }}
    }});
}})();

// ---------------------------------------------------------------------
// Severity filter — click a count to show only that severity.
// ---------------------------------------------------------------------
function filterEvents(severity) {{
    // Hide/show event cards
    const articles = document.querySelectorAll('article.event');
    articles.forEach(a => {{
        if (severity === 'all' || a.classList.contains(severity)) {{
            a.style.display = '';
        }} else {{
            a.style.display = 'none';
        }}
    }});
    // Update active count-item
    document.querySelectorAll('.count-item').forEach(el => {{
        el.classList.remove('active');
    }});
    const active = document.querySelector(`.count-item[data-severity="${{severity}}"]`);
    if (active) active.classList.add('active');
}}

// ---------------------------------------------------------------------
// Top-level tabs (Coordination Failures vs Session Activity) and
// inner tabs (Edge Activity vs Chronological Log). Same pattern,
// different selectors. No dependencies, no persistence.
// ---------------------------------------------------------------------
function switchMainTab(tabName) {{
    document.querySelectorAll('.main-tab').forEach(t => {{
        var match = t.getAttribute('data-main') === tabName;
        t.classList.toggle('active', match);
        t.setAttribute('aria-selected', match ? 'true' : 'false');
    }});
    document.querySelectorAll('.main-tab-panel').forEach(p => {{
        p.classList.toggle('active', p.getAttribute('data-main') === tabName);
    }});
}}

function switchTab(tabName) {{
    document.querySelectorAll('.tab').forEach(t => {{
        t.classList.toggle('active', t.getAttribute('data-tab') === tabName);
    }});
    document.querySelectorAll('.tab-panel').forEach(p => {{
        p.classList.toggle('active', p.getAttribute('data-tab') === tabName);
    }});
}}

// ---------------------------------------------------------------------
// Raw JSON copy button — copies the text inside <pre id="json-block">
// to the clipboard. Falls back to a textarea + execCommand("copy") on
// older browsers / contexts where navigator.clipboard is unavailable
// (file:// URLs, some corporate proxies, etc.).
// ---------------------------------------------------------------------
(function () {{
    var btn = document.getElementById("json-copy-btn");
    var block = document.getElementById("json-block");
    var status = document.getElementById("json-copy-status");
    if (!btn || !block) return;

    function setStatus(msg) {{
        if (!status) return;
        status.textContent = msg;
        // Clear the message after a short delay so the toolbar
        // doesn't stay cluttered with stale state.
        setTimeout(function () {{ status.textContent = ""; }}, 2500);
    }}

    function legacyCopy(text) {{
        // Last-resort fallback for environments without
        // navigator.clipboard (e.g. Firefox on file:// URLs).
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.setAttribute("readonly", "");
        ta.style.position = "absolute";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.select();
        try {{
            var ok = document.execCommand("copy");
            return ok;
        }} catch (_) {{
            return false;
        }} finally {{
            document.body.removeChild(ta);
        }}
    }}

    btn.addEventListener("click", function () {{
        var text = block.textContent || "";
        if (navigator.clipboard && navigator.clipboard.writeText) {{
            navigator.clipboard.writeText(text).then(
                function () {{ setStatus("Copied."); }},
                function () {{
                    if (legacyCopy(text)) setStatus("Copied.");
                    else setStatus("Copy failed — select + Ctrl-C instead.");
                }}
            );
        }} else if (legacyCopy(text)) {{
            setStatus("Copied.");
        }} else {{
            setStatus("Copy failed — select + Ctrl-C instead.");
        }}
    }});
}})();
</script>
</body>
</html>
"""


def _render_coordination_failures(
    displayed: list[CoordinationEvent],
    cards_html: str,
) -> str:
    """Render the "Coordination Failures" primary-signal section.

    Always emits an <h2>Coordination Failures</h2> header so readers
    know what the section is about. Two modes:

      * Alert run (len(displayed) > 0) — filter chips (Total / Critical
        / Warning) above the alert cards. Clicking a chip filters the
        cards below via filterEvents().

      * Clean run (len(displayed) == 0) — green clean-run banner
        ("No coordination failures detected."). No chips because
        there's nothing to filter.

    Named after the section's contents (Sentry "Issues", Snyk
    "Findings" pattern) rather than generic "Summary" — the title
    tells you what you're looking at.
    """
    total = len(displayed)
    critical = sum(1 for e in displayed if e.severity.value == "CRITICAL")
    warning = sum(1 for e in displayed if e.severity.value == "WARNING")

    if total == 0:
        body = (
            '<div class="clean-run">'
            '<span class="clean-icon">\u2713</span>'
            '<p class="clean-title">No coordination failures detected</p>'
            '<p class="clean-sub">The run completed cleanly — no cycles, '
            'repetitive delegations, or rate-limit events crossed the '
            'alert thresholds.</p>'
            '</div>'
        )
        filter_bar = ""
    else:
        body = cards_html
        filter_bar = f"""
    <div class="filter-chip-bar">
        <p class="filter-hint">Click a count to filter the events below.</p>
        <div class="summary-counts">
            <div class="count-item active" data-severity="all" onclick="filterEvents('all')">
                <strong>{total}</strong>Total Events
            </div>
            <div class="count-item critical" data-severity="critical" onclick="filterEvents('critical')">
                <strong>{critical}</strong>Critical
            </div>
            <div class="count-item warning" data-severity="warning" onclick="filterEvents('warning')">
                <strong>{warning}</strong>Warning
            </div>
        </div>
    </div>
"""

    return f"""
<section class="coordination-failures">
    <h2 class="section-title">Coordination Failures</h2>
    {filter_bar}
    {body}
</section>
"""


def _compute_alert_timestamps_by_severity(
    displayed_events: list[CoordinationEvent],
) -> dict[float, str]:
    """Map delegation timestamp → severity ("critical" or "warning").

    Each CoordinationEvent carries the timestamp of the delegation that
    triggered it (the engine passes `event.timestamp` through to both
    the session log tuple and the alert). Matching those timestamps
    back to session_log rows is an exact-float lookup — same source
    of truth, no drift.

    CRITICAL wins over WARNING when multiple events share a timestamp
    (cycle + repetitive firing on the same delegation). Only WARNING
    and CRITICAL severities are returned; INFO is skipped.
    """
    by_ts: dict[float, str] = {}
    for event in displayed_events:
        # Skip the synthetic "prevention" event — its timestamp is
        # time.time() at trip-emit, NOT a delegation timestamp, so it
        # won't match any session log row and would just waste a map
        # slot. The trip moment is already represented by the underlying
        # CRITICAL alert that triggered Prevent Mode (which IS in the
        # event stream with its real delegation timestamp).
        if event.event_type == "prevention":
            continue
        sev_value = event.severity.value  # "CRITICAL" / "WARNING"
        if sev_value not in ("CRITICAL", "WARNING"):
            continue
        sev = sev_value.lower()
        ts = event.timestamp
        existing = by_ts.get(ts)
        if existing == "critical":
            continue  # already at the top; don't downgrade
        by_ts[ts] = sev
    return by_ts


def _render_main_tabs(
    coordination_failures_html: str,
    session_activity_html: str,
    coordination_count: int,
    session_count: int,
) -> str:
    """Wrap the two top-level sections in a main-tabs navigation.

    When Session Activity has no data to show (both edge_activity and
    session_log were absent), we skip the tab nav entirely and render
    the Coordination Failures section directly — a legacy/minimal
    report stays compact.

    Default active tab is Coordination Failures (primary signal — the
    Sentry model: Issues/failures on top, supplemental context one
    click away). Badges show counts when > 0; absent when 0 to avoid
    a noisy "0" next to "Coordination Failures" on clean runs.
    """
    if not session_activity_html.strip():
        # No session activity data → skip the tab nav. Coordination
        # Failures section stands alone, as in prior versions.
        return coordination_failures_html

    def _badge(n: int) -> str:
        if n <= 0:
            return ""
        return f'<span class="main-tab-badge">{n}</span>'

    return f"""
<nav class="main-tabs" role="tablist">
    <button type="button" class="main-tab active"
            data-main="failures"
            onclick="switchMainTab('failures')"
            role="tab" aria-selected="true">
        Coordination Failures{_badge(coordination_count)}
    </button>
    <button type="button" class="main-tab"
            data-main="activity"
            onclick="switchMainTab('activity')"
            role="tab" aria-selected="false">
        Session Activity{_badge(session_count)}
    </button>
</nav>
<div class="main-tab-panel active" data-main="failures" role="tabpanel">
    {coordination_failures_html}
</div>
<div class="main-tab-panel" data-main="activity" role="tabpanel">
    {session_activity_html}
</div>
"""


def _enrich_edge_activity_by_severity(
    edge_activity: list[dict],
    displayed_events: list[CoordinationEvent],
) -> list[dict]:
    """Fold per-edge severity counts into edge-activity records.

    Walks every DISPLAYED event (already passed through dedupe +
    inhibition + INFO-filter by the caller) and counts how many
    CRITICAL vs WARNING events reference each source→target edge via
    their `topology.edge_frequency`. Cycles contribute to every edge
    in the cycle; one-directional events to just the one edge.

    Returns a new list with two fields added per record:
      - `critical_count`  int, count of CRITICAL events touching this edge
      - `warning_count`   int, count of WARNING events touching this edge

    Input list is not mutated. Records missing source/target are
    passed through untouched.
    """
    per_edge: dict[tuple[str, str], dict[str, int]] = {}
    for event in displayed_events:
        topology = event.topology
        if topology is None:
            continue
        edge_freq = getattr(topology, "edge_frequency", None) or {}
        # .value is the uppercased enum string ("CRITICAL" / "WARNING")
        severity_key = (
            "critical" if event.severity.value == "CRITICAL"
            else "warning" if event.severity.value == "WARNING"
            else None
        )
        if severity_key is None:
            continue
        for edge_key in edge_freq.keys():
            if "->" not in edge_key:
                continue
            src, _, tgt = edge_key.partition("->")
            bucket = per_edge.setdefault(
                (src, tgt), {"critical": 0, "warning": 0}
            )
            bucket[severity_key] += 1

    enriched: list[dict] = []
    for rec in edge_activity:
        new_rec = dict(rec)  # shallow copy
        key = (new_rec.get("source"), new_rec.get("target"))
        bucket = per_edge.get(key, {"critical": 0, "warning": 0})
        new_rec["critical_count"] = bucket["critical"]
        new_rec["warning_count"] = bucket["warning"]
        enriched.append(new_rec)
    return enriched


def _render_session_activity(
    *,
    edge_activity: list[dict] | None,
    session_log: list[tuple[float, str, str]] | None,
    session_log_total: int,
    alert_timestamps: dict[float, str] | None = None,
) -> str:
    """Render the "Session Activity" tabbed container.

    Holds the two INFO-level peer views:

      * Tab 1 — "Edge Activity": edge-grouped aggregate (each row is
        one delegation edge with fire count + alert count).
      * Tab 2 — "Chronological Log": raw event stream with timestamps.

    Default active tab is Edge Activity (aggregate view scans faster
    than a long chronological list). Tab state does not persist across
    reports — this is a per-view UX detail, not a preference.

    Renders as empty string when neither dataset was provided so
    legacy callers / tests that pass only events still get a compact
    report with no orphaned section. If exactly one dataset was
    provided, only that tab shows (we don't fake an empty tab).
    """
    has_edges = bool(edge_activity)
    has_log = bool(session_log)
    if not has_edges and not has_log:
        return ""

    # Defensive counts for the tab badges.
    edge_count = 0
    if has_edges:
        edge_count = len([
            r for r in edge_activity
            if r.get("source") is not None and r.get("target") is not None
        ])

    tabs: list[str] = []
    panels: list[str] = []

    # The first available tab is active by default. Edge Activity is
    # always first when it's present — it's the aggregate view and
    # scans faster.
    active_set = False

    if has_edges:
        is_active = not active_set
        active_set = True
        active_cls = " active" if is_active else ""
        tabs.append(f"""\
        <button type="button" class="tab{active_cls}" data-tab="edges"
                onclick="switchTab('edges')">
            Edge Activity<span class="tab-count">{edge_count}</span>
        </button>""")
        panels.append(f"""\
    <div class="tab-panel{active_cls}" data-tab="edges">
        {_render_edge_activity_panel(edge_activity)}
    </div>""")

    if has_log:
        is_active = not active_set
        active_set = True
        active_cls = " active" if is_active else ""
        tabs.append(f"""\
        <button type="button" class="tab{active_cls}" data-tab="log"
                onclick="switchTab('log')">
            Chronological Log<span class="tab-count">{session_log_total}</span>
        </button>""")
        panels.append(f"""\
    <div class="tab-panel{active_cls}" data-tab="log">
        {_render_chronological_log_panel(session_log, session_log_total, alert_timestamps=alert_timestamps)}
    </div>""")

    return f"""
<section class="session-activity">
    <h2 class="section-title">Session Activity</h2>
    <div class="tab-bar" role="tablist">
{chr(10).join(tabs)}
    </div>
{chr(10).join(panels)}
</section>
"""


def _render_event_card(event: CoordinationEvent) -> str:
    severity = event.severity.value
    severity_class = severity.lower()
    failure_value = event.failure_class.value
    summary = html.escape(event.summary or "No summary")
    # Prevention events (the synthetic event emitted when Prevent Mode trips)
    # are rendered with an additional "prevented" class so the report can
    # show them with a distinct treatment — a "🛑 PREVENTED" badge prefix
    # and a different left-border accent — making it obvious which entry
    # represents the actual trip versus regular threshold-driven alerts.
    is_prevention = event.event_type == "prevention"
    article_classes = f"event {severity_class}"
    prevention_badge_html = ""
    if is_prevention:
        article_classes += " prevented"
        prevention_badge_html = (
            '<span class="badge prevented" '
            'title="Prevent Mode caught this failure and raised PreventError '
            'in the user code, stopping the run. Rotation count is the LIVE '
            'count at trip time, not the last alert\'s frozen count.">'
            '🛑 PREVENTED'
            '</span>'
        )

    sections = []

    if event.topology is not None:
        sections.append(_render_topology(event.topology))
    if event.thresholds is not None:
        sections.append(_render_thresholds(event.thresholds))
    if event.provider_error is not None:
        sections.append(_render_provider_error(event.provider_error))
    if event.downstream_impact is not None:
        sections.append(_render_downstream(event.downstream_impact))

    body = "\n".join(sections) if sections else '<p class="meta">No additional details.</p>'

    # Failure class with a hover tooltip explaining the term. Readers
    # new to AgentSonar's vocabulary can hover on "cyclic_delegation"
    # and get a one-sentence definition without leaving the report.
    failure_description = _FAILURE_CLASS_DESCRIPTIONS.get(
        failure_value,
        "A detected coordination failure — see the AgentSonar docs for details.",
    )
    failure_html = (
        f'<span class="failure-class" title="{html.escape(failure_description)}">'
        f'{html.escape(failure_value)}'
        f'</span>'
    )

    # Stable ID for this failure pattern. Same cycle/edge always produces
    # the same fingerprint — that's how dedupe collapses escalations and
    # how you correlate events across runs. Label + tooltip so readers
    # aren't left wondering what "sha256:5c102a66..." means.
    fingerprint_label = (
        '<span class="fingerprint-label" '
        'title="Stable hash of the failure pattern. Same agents '
        'always produce the same fingerprint — used to dedupe '
        'repeat alerts and track the same issue across runs.">'
        'fingerprint</span>'
    )

    # session_id and event_id rows. session_id identifies the AgentSonar
    # run that produced this event; event_id is a UUID unique to this
    # specific CoordinationEvent. Both are useful when correlating the
    # HTML report with the JSONL log files or with downstream analytics.
    session_label = (
        '<span class="id-label" '
        'title="Unique identifier for the AgentSonar run that produced '
        'this event. Match this against the session_start line in the '
        'JSONL log to find the full context.">'
        'session</span>'
    )
    event_label = (
        '<span class="id-label" '
        'title="UUID unique to this specific CoordinationEvent. '
        'Use it to deep-link to this exact row from external tools.">'
        'event id</span>'
    )
    return f"""
<article class="{article_classes}">
    <div class="event-header">
        <p class="event-title">{prevention_badge_html}<span class="badge {severity_class}">{html.escape(severity)}</span>{failure_html}</p>
        <p class="event-summary">{summary}</p>
        <p class="fingerprint">{fingerprint_label}{html.escape(event.coordination_fingerprint)}</p>
        <div class="event-ids">
            <div>{session_label}{html.escape(event.session_id)}</div>
            <div>{event_label}{html.escape(event.event_id)}</div>
        </div>
    </div>
    <div class="event-body">
        {body}
    </div>
</article>
"""


def _render_topology(t) -> str:
    agents = ", ".join(html.escape(a) for a in t.agents_involved)
    # Append "events" to each edge frequency value so readers know what
    # the number means. "15" alone could be anything — "15 events" is
    # unambiguous. Uses non-breaking space for a tighter rendering.
    edges_html = "".join(
        f'<div class="k">{html.escape(k)}</div>'
        f'<div class="v">{v}&nbsp;events</div>'
        for k, v in t.edge_frequency.items()
    )
    return f"""
<details open>
<summary>Topology</summary>
<div class="kv">
    <div class="k">agents</div><div class="v">{agents}</div>
    <div class="k">pattern</div><div class="v">{html.escape(t.interaction_pattern)}</div>
    <div class="k">agent count</div><div class="v">{t.agent_count}</div>
    <div class="k">occurrences</div><div class="v">{t.occurrence_count}</div>
    {edges_html}
</div>
</details>
"""


def _render_thresholds(t) -> str:
    return f"""
<details>
<summary>Thresholds</summary>
<div class="kv">
    <div class="k">warning at</div><div class="v">{t.warning_at}</div>
    <div class="k">critical at</div><div class="v">{t.critical_at}</div>
    <div class="k">current</div><div class="v">{t.current_value}</div>
    <div class="k">headroom</div><div class="v">{t.headroom_remaining}</div>
</div>
</details>
"""


def _render_provider_error(pe) -> str:
    retry = pe.retry_after_seconds if pe.retry_after_seconds is not None else "—"
    return f"""
<details>
<summary>Provider Error</summary>
<div class="kv">
    <div class="k">error type</div><div class="v">{html.escape(pe.error_type)}</div>
    <div class="k">retry after</div><div class="v">{retry}</div>
</div>
</details>
"""


def _render_downstream(di) -> str:
    agents = ", ".join(html.escape(a) for a in di.blocked_agents)
    return f"""
<details>
<summary>Downstream Impact</summary>
<div class="kv">
    <div class="k">blocked</div><div class="v">{agents}</div>
    <div class="k">delay (s)</div><div class="v">{di.estimated_delay_seconds}</div>
    <div class="k">cascade risk</div><div class="v">{di.cascade_risk_score}</div>
</div>
</details>
"""


def _format_ts(ts: float | None) -> str:
    """Render a UNIX timestamp as HH:MM:SS.mmm UTC.

    Used by the Run Activity view to render `first_ts` / `last_ts` in
    a shape that's scannable at a glance — the full ISO string is
    overkill for per-edge rows. Returns "—" for None / non-numeric
    inputs so the renderer stays defensive on partially-populated
    records (e.g. the back-fill path in CoordinationGraph).
    """
    if ts is None:
        return "—"
    try:
        # UTC to match the "Generated at" banner at the top of the page.
        dt = datetime.fromtimestamp(float(ts), tz=timezone.utc)
    except (TypeError, ValueError, OSError, OverflowError):
        return "—"
    millis = dt.microsecond // 1000
    return f"{dt.strftime('%H:%M:%S')}.{millis:03d} UTC"


def _render_edge_activity_panel(edge_activity: list[dict]) -> str:
    """Render the CONTENTS of the Edge Activity tab panel.

    No section wrapper or H2 — the parent tab container supplies the
    "Session Activity" heading and this view's identity is carried
    by the tab label ("Edge Activity"). One card per delegation edge
    with source → target arrow, fire count, first/last timestamps,
    and alert attribution.

    Empty string when nothing renderable remains after the defensive
    filter — the caller (`_render_session_activity`) decides whether
    the tab gets shown at all.
    """
    if not edge_activity:
        return ""

    # Defensive filter — skip records that lack the minimum fields.
    # Bad records would blow up the f-string below; better to silently
    # drop them than crash the whole report.
    valid = [
        rec for rec in edge_activity
        if rec.get("source") is not None and rec.get("target") is not None
    ]
    if not valid:
        return ""

    total_edges = len(valid)
    total_fires = sum(int(rec.get("count", 0) or 0) for rec in valid)

    cards = "\n".join(_render_edge_card(rec) for rec in valid)

    return f"""
<p class="activity-hint">
    {total_edges} delegation edge{"s" if total_edges != 1 else ""},
    {total_fires} total event{"s" if total_fires != 1 else ""}.
    Click an edge to see first / last timestamps and alert counts.
</p>
{cards}
"""


def _render_chronological_log_panel(
    session_log: list[tuple[float, str, str]],
    total: int | None = None,
    *,
    alert_timestamps: dict[float, str] | None = None,
) -> str:
    """Render the CONTENTS of the Chronological Log tab panel.

    No tab wrapper — the parent `_render_session_activity` supplies
    the enclosing `<div class="tab-panel">`. Each row renders as
    `[HH:MM:SS.mmm UTC]  source → target`.

    When `alert_timestamps` is provided (mapping delegation timestamp
    to severity), rows whose timestamp matches a displayed alert get
    a severity-tinted background — light red for CRITICAL, light
    orange for WARNING. This lets users see AT WHICH row a failure
    fired, so the pattern (e.g. "warnings clustering near iteration
    15") is scannable at a glance.

    Truncation banner at the top when the engine's bounded buffer
    clipped the stream.
    """
    if not session_log:
        return ""

    alert_ts_map: dict[float, str] = alert_timestamps or {}
    shown = len(session_log)
    true_total = total if total is not None else shown
    # Rendered LOGICAL total — always >= shown. Guards against an
    # explicitly-passed total that's less than shown (shouldn't
    # happen but defensive).
    true_total = max(true_total, shown)

    # Count how many entries get highlighted so the hint can say
    # "2 rows below fired an alert" — orients the reader before
    # they scan the long list.
    highlighted_count = sum(1 for ts, *_ in session_log if ts in alert_ts_map)

    entries: list[str] = []
    for ts, src, tgt in session_log:
        sev = alert_ts_map.get(ts)
        css_class = "session-log-entry"
        if sev == "critical":
            css_class = "session-log-entry entry-critical"
        elif sev == "warning":
            css_class = "session-log-entry entry-warning"
        time_str = _format_ts(ts)
        entries.append(
            f'<li class="{css_class}">'
            f'<span class="session-log-time">{html.escape(time_str)}</span>'
            '<span class="session-log-route">'
            f'{html.escape(str(src))}'
            '<span class="edge-arrow">\u2192</span>'
            f'{html.escape(str(tgt))}'
            '</span>'
            '</li>'
        )

    truncation_note = ""
    if true_total > shown:
        omitted = true_total - shown
        truncation_note = (
            f'<p class="session-log-truncation">'
            f'Showing {shown} most recent of {true_total} total events '
            f'({omitted} earlier event{"s" if omitted != 1 else ""} '
            f'omitted — see timeline.jsonl for the full log).'
            f'</p>'
        )

    highlight_hint = ""
    if highlighted_count > 0:
        highlight_hint = (
            f'<p class="session-log-highlight-hint">'
            f'Highlighted rows fired an alert '
            f'(<span class="hint-legend entry-critical">red = critical</span>, '
            f'<span class="hint-legend entry-warning">orange = warning</span>) '
            f'— {highlighted_count} row{"s" if highlighted_count != 1 else ""} '
            f'of {shown} shown.'
            f'</p>'
        )

    return f"""
{truncation_note}
{highlight_hint}
<ol class="session-log-list">
    {chr(10).join(entries)}
</ol>
"""


def _render_edge_card(rec: dict) -> str:
    """One card per edge — collapsed summary + expandable detail.

    Alert chip rules:
      * CRITICAL wins over WARNING — when both severities touched the
        same edge after dedupe+inhibition, we show the critical count
        and drop the warning noise. This matches the Coordination
        Failures cards above (which also hide inhibited symptoms), so
        "3 critical here, 1 critical card below" lines up.
      * No alerts → neutral chip, no border highlight.
    """
    src = str(rec.get("source", "?"))
    tgt = str(rec.get("target", "?"))
    count = int(rec.get("count", 0) or 0)
    first_ts = rec.get("first_ts")
    last_ts = rec.get("last_ts")
    critical_count = int(rec.get("critical_count", 0) or 0)
    warning_count = int(rec.get("warning_count", 0) or 0)

    # Critical wins over warning. Unitless "critical" / "warning"
    # labels per observability convention (Sentry, Datadog) — treated
    # as severity-category nouns, not pluralized.
    if critical_count > 0:
        card_class = "edge-card has-critical"
        chip_class = "edge-alerts-chip has-critical"
        chip_text = f"{critical_count} critical"
        detail_label = "critical"
        detail_value = critical_count
    elif warning_count > 0:
        card_class = "edge-card has-warning"
        chip_class = "edge-alerts-chip has-warning"
        chip_text = f"{warning_count} warning"
        detail_label = "warning"
        detail_value = warning_count
    else:
        card_class = "edge-card"
        chip_class = "edge-alerts-chip"
        chip_text = "no alerts"
        detail_label = "alerts"
        detail_value = 0

    fires_text = f"{count} fire{'s' if count != 1 else ''}"

    return f"""
<details class="{card_class}">
    <summary>
        <span class="edge-route">
            {html.escape(src)}<span class="edge-arrow">\u2192</span>{html.escape(tgt)}
        </span>
        <span class="edge-fires">{fires_text}</span>
        <span class="{chip_class}">{chip_text}</span>
    </summary>
    <div class="edge-details">
        <div class="k">first</div><div class="v">{html.escape(_format_ts(first_ts))}</div>
        <div class="k">last</div><div class="v">{html.escape(_format_ts(last_ts))}</div>
        <div class="k">events</div><div class="v">{count}</div>
        <div class="k">{detail_label}</div><div class="v">{detail_value}</div>
    </div>
</details>
"""
