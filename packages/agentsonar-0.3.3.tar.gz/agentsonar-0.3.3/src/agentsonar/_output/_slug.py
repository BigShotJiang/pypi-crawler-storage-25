"""
Memorable run-slug generator — Docker-style adjective + noun pairs.

Used by SonarLogger to label each session directory with a
human-friendly name like `brave-otter` or `hungry-atlas` instead of a
meaningless hex id. The slug is DETERMINISTIC from the seed (typically
the engine's session_id), so the same session always produces the same
slug — a log line that mentions `session_id=abc123...` can be traced
back to the `...-brave-otter/` directory without a lookup table.

Why slugs at all?
-----------------
The dominant convention across Weights & Biases, MLflow, and similar
per-run artifact tools is `run-<timestamp>-<hex id>`. Timestamps sort
chronologically, which is great, but hex ids are unmemorable — users
can't say "the brave-otter run failed" out loud the way they can with
a slug. Docker's `namesgenerator` (adjective + noun) is the industry
reference for this pattern in the container world, and we borrow the
idea whole.

Collision math
--------------
64 adjectives × 64 nouns = 4096 unique slugs. At 20 runs/day that's
a ~5% collision probability per YEAR (birthday bound) — not "never",
but the full dir name is `run-<date>_<time>-<slug>`, so two runs
sharing a slug still get distinct dir names as long as they don't
share the exact same second (which only happens in tests). For
production usage the slug is effectively collision-free.

Filesystem safety
-----------------
Every word is lowercase [a-z] only. No apostrophes, no hyphens inside
a word, no accents — safe on every major filesystem including older
Windows FAT drives. The `-` between adjective and noun is the only
separator (matching Docker's `_` convention except with `-` so the
slug looks like a URL path segment and can appear in logs without
quoting).
"""
from __future__ import annotations

import hashlib


# Adjective list — 64 short, positive or neutral English adjectives.
# Kept tight and uncontroversial — no brand names, no politics, no
# words with alternate spellings, no homophones.
_ADJECTIVES = (
    "amber", "ancient", "autumn", "azure", "blazing", "bold", "brave", "breezy",
    "bright", "bronze", "calm", "clever", "clear", "cosmic", "crimson", "crisp",
    "daring", "deep", "divine", "eager", "early", "emerald", "falling", "fearless",
    "fierce", "floating", "frosty", "gentle", "glowing", "golden", "happy", "hidden",
    "humble", "icy", "jolly", "keen", "kind", "lively", "lucky", "mighty",
    "misty", "noble", "orange", "patient", "peaceful", "proud", "purple", "quiet",
    "rapid", "rare", "ready", "regal", "royal", "ruby", "silent", "silver",
    "sleek", "solar", "steady", "stormy", "sunny", "swift", "tranquil", "witty",
)

# Noun list — 64 short concrete nouns. Animals lead the list (easy
# to picture), mixed with celestial / nature terms for variety.
# Same uncontroversial criteria as the adjective list.
_NOUNS = (
    "atlas", "aurora", "badger", "bear", "beech", "beetle", "birch", "bison",
    "blossom", "boulder", "bridge", "canyon", "cedar", "cheetah", "cobra", "comet",
    "coral", "crane", "dahlia", "dawn", "delta", "dolphin", "dragon", "eagle",
    "ember", "falcon", "ferret", "fjord", "forest", "fox", "garnet", "glacier",
    "gorilla", "hawk", "heron", "hornet", "island", "jaguar", "kestrel", "lantern",
    "lemur", "leopard", "lion", "lotus", "lynx", "maple", "marlin", "meadow",
    "moose", "nebula", "ocelot", "opal", "orchid", "otter", "panda", "panther",
    "pebble", "puma", "raven", "rhino", "river", "sable", "summit", "tiger",
)


# Powers of two: with 64 elements in each list, we can index by taking
# the lower 6 bits for adjective + next 6 bits for noun, all from a
# single 12-bit integer. No modulo bias.
_ADJ_COUNT = len(_ADJECTIVES)
_NOUN_COUNT = len(_NOUNS)
assert _ADJ_COUNT == 64, "adjective list drifted off 64"
assert _NOUN_COUNT == 64, "noun list drifted off 64"


def generate_slug(seed: str) -> str:
    """Return a deterministic `adjective-noun` slug for the given seed.

    The seed is typically the engine's `session_id` (a 16-char hex
    string). Any string works — non-hex input is hashed just the same,
    so custom session_ids from future integrations would still produce
    valid slugs.

    Args:
        seed: Arbitrary string. Must be non-None but may be empty;
            an empty seed still produces a valid (constant) slug.

    Returns:
        A hyphenated `adjective-noun` pair, always lowercase ASCII,
        always filesystem-safe.

    Examples:
        >>> generate_slug("65efaff4bf554327")
        'clear-garnet'
        >>> generate_slug("65efaff4bf554327")   # deterministic
        'clear-garnet'
        >>> generate_slug("")                    # empty is still valid
        'keen-moose'
    """
    if seed is None:
        seed = ""

    # SHA-256 over UTF-8 bytes. The first 2 bytes = 16 bits, which
    # cleanly divides into two 6-bit indices (64 values each) with no
    # modulo bias — taking `int & 63` gives a uniform distribution
    # when the input is uniformly hashed.
    digest = hashlib.sha256(seed.encode("utf-8")).digest()
    adj_index = digest[0] & 0x3F  # low 6 bits of byte 0
    noun_index = digest[1] & 0x3F  # low 6 bits of byte 1
    return f"{_ADJECTIVES[adj_index]}-{_NOUNS[noun_index]}"


def iter_all_slugs():
    """Yield every possible slug this generator can emit.

    Useful for tests — lets us assert properties like "every slug is
    safe as a filesystem path component" without enumerating by hand.
    """
    for adjective in _ADJECTIVES:
        for noun in _NOUNS:
            yield f"{adjective}-{noun}"
