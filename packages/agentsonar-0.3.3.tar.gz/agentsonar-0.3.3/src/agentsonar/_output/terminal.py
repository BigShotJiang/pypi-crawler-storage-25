"""
SonarLogger — structured logging for AgentSonar detection events.

Every run writes to its OWN session directory under `agentsonar_logs/`
in the user's configured `log_dir` (defaults to cwd):

    <log_dir>/
    └── agentsonar_logs/
        ├── .gitignore                                  # contains: *
        ├── latest                                       # run dir basename
        ├── run-2026-04-11_06-48-40-brave-otter/
        │   ├── timeline.jsonl                           # every event
        │   ├── alerts.log                               # signal-only
        │   ├── report.json                              # (written by engine)
        │   └── report.html                              # (written by engine)
        └── run-2026-04-11_06-50-12-swift-lantern/
            └── ...

The directory pattern combines two conventions:

  * **Sortable timestamp** (from W&B / MLflow / Ray Tune) —
    `YYYY-MM-DD_HH-MM-SS` with ISO date and filesystem-safe time,
    so `ls` sorts chronologically and users can scan dates at a glance.

  * **Memorable slug** (from Docker's `namesgenerator`) —
    `adjective-noun` pairs like `brave-otter`, deterministic from the
    engine's session_id so the same session always produces the same
    slug. Users can say "the brave-otter run failed" out loud — much
    more usable than `9bb283` hex.

Additional conventions:

  * `agentsonar_logs/` — visible top-level dir, matches wandb/mlruns
  * Fixed filenames inside — `timeline.jsonl`, `alerts.log`, `report.*`
    — the enclosing run dir already carries identity
  * `latest` is a plain text file (not a symlink) holding the run dir
    basename — works on Windows, macOS, Linux, and zip extraction
  * `.gitignore` with `*` inside prevents accidental commits of logs
    (trick borrowed from pytest-cache)

The JSONL timeline captures every event; the alerts log is a
signal-only subset for humans watching the run.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from agentsonar._core.models import Alert
from agentsonar._output._slug import generate_slug

# Internal debug logger. Used for breadcrumbs when defensive checks
# skip a best-effort write (e.g. `agentsonar_logs/latest` already
# exists as a directory). Never reaches stderr by default — users
# who want to diagnose file-creation issues can enable it via
# `logging.getLogger("agentsonar").setLevel(logging.DEBUG)`.
_module_logger = logging.getLogger("agentsonar")

# Directory name convention. Visible top-level dir matching wandb's
# `wandb/` and MLflow's `mlruns/` — user-facing artifacts, not caches.
_LOGS_DIR_NAME = "agentsonar_logs"

# Filename constants for the per-run session directory. Fixed names
# (no per-file timestamp) because the enclosing run directory already
# carries the timestamp and slug.
_FILENAME_TIMELINE = "timeline.jsonl"
_FILENAME_ALERTS = "alerts.log"
_FILENAME_REPORT_JSON = "report.json"
_FILENAME_REPORT_HTML = "report.html"
_FILENAME_LATEST = "latest"
_FILENAME_GITIGNORE = ".gitignore"

# Regex matching a run directory name. Used by the retention sweep
# to identify which subdirectories are AgentSonar runs vs unrelated
# directories the user may have created inside `agentsonar_logs/`.
#
# Base format: run-YYYY-MM-DD_HH-MM-SS-adjective-noun
#   * Date:  \d{4}-\d{2}-\d{2}      (ISO date)
#   * Sep:   _                      (underscore)
#   * Time:  \d{2}-\d{2}-\d{2}      (HH-MM-SS, hyphens not colons)
#   * Sep:   -                      (dash before slug)
#   * Slug:  [a-z]+-[a-z]+          (adjective-noun, lowercase ASCII)
#
# Collision disambiguator suffix is ALSO matched:
#   * Optional: -\d+                (numeric suffix -1, -2, ...)
#   * Optional: -[0-9a-f]{6}        (uuid fallback for pathological collision)
#
# Without the optional suffix, collision-disambiguated runs would
# never be pruned by retention — they'd leak forever.
_RUN_DIR_PATTERN = re.compile(
    r"^run-\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}-[a-z]+-[a-z]+"
    r"(?:-\d+|-[0-9a-f]{6})?$"
)

# ---------------------------------------------------------------------------
# ANSI color codes
# ---------------------------------------------------------------------------
_COLORS = {
    "DEBUG": "\033[90m",       # dim gray
    "INFO": "",                # default
    "WARNING": "\033[93m",     # yellow
    "CRITICAL": "\033[91;1m",  # red bold
}
_RESET = "\033[0m"

# ---------------------------------------------------------------------------
# Log level ordering
# ---------------------------------------------------------------------------
_LEVEL_ORDER = {"DEBUG": 0, "INFO": 1, "WARNING": 2, "CRITICAL": 3}

# ---------------------------------------------------------------------------
# Human-readable alerts log allowlist.
#
# The JSONL log captures every event for machine consumption. The alerts
# log is a second sibling file that ONLY contains the events a human
# watching the run would care about — alerts, recoveries, session markers.
# Debug noise (delegation, graph_update, anomaly_detected, scc_sweep) is
# skipped so `tail -f agentsonar_alerts_*.log` stays readable.
# ---------------------------------------------------------------------------
_ALERTS_LOG_EVENTS = frozenset({
    "session_start",
    "session_end",
    "alert",                 # formal WARNING/CRITICAL from AlertStateManager
    "rate_limit_hit",        # circuit breaker fired
    "alert_resolved",        # recovered after quiet period
    "prevented",             # Prevent Mode tripped — caller will see PreventError
})

# ---------------------------------------------------------------------------
# Stderr suppress list.
#
# These events are written to the JSONL log (machine-readable record)
# but NEVER streamed to stderr. They're raw low-level detection signals
# that generate a lot of visual noise without adding information that
# the human watching the console needs to act on:
#
#   anomaly_detected  — Layer 2 precursor. Each one eventually resolves
#                       into a formal WARNING/CRITICAL edge_anomaly alert
#                       via the AlertStateManager. Showing both the raw
#                       detection AND the formal alert means the user
#                       sees "anomaly: a->b (11 events)" followed by
#                       "WARNING edge_anomaly: a->b (11 events)" and
#                       wonders why the same information is printed twice.
#
#   cycle_detected    — Layer 3 first-sighting heads-up, fires before
#                       the AlertStateManager has decided whether to
#                       emit a formal alert. Same deal: redundant with
#                       the follow-up WARNING cycle alert.
#
# Users who want the full signal stream can `tail -f agentsonar_*.log`
# or set log_level=DEBUG to see everything.
# ---------------------------------------------------------------------------
_STDERR_SUPPRESSED_EVENTS = frozenset({
    "anomaly_detected",
    "cycle_detected",
})


class SonarLogger:
    """Structured JSONL logger for AgentSonar detection events.

    Creates a per-run session directory under `<output_dir>/agentsonar_logs/`
    and writes two files inside it: `timeline.jsonl` (JSONL, every event)
    and `alerts.log` (human-readable, signal-only). The engine writes its
    JSON and HTML reports into the same directory on shutdown.

    Args:
        output_dir: Parent directory for the `agentsonar_logs/` folder.
            Defaults to cwd. Created if missing.
        console_output: Print colored human-readable lines to stderr.
        file_output: Write files to disk. Disable for tests and for
            completely silent operation.
        log_level: Minimum level to emit ("DEBUG", "INFO", "WARNING", "CRITICAL").
        session_id: Optional session id; appended to the run directory
            name so concurrent sessions don't collide. Typically the
            engine passes its own `session_id` in — users don't touch this.
        keep_runs: Retention. After creating a new run directory, prune
            old ones so at most `keep_runs` remain (sorted newest-first).
            Default 20, overridable via env var `AGENTSONAR_KEEP_RUNS`.
            Set to 0 to disable retention entirely.

    Attributes set after init (even if `file_output=False` — they're None
    in that case):
        run_dir: Absolute path to this run's session directory, or None.
        logs_root: Absolute path to the `agentsonar_logs/` parent, or None.
    """

    def __init__(
        self,
        output_dir: str = ".",
        console_output: bool = True,
        file_output: bool = True,
        log_level: str = "INFO",
        session_id: str | None = None,
        keep_runs: int | None = None,
    ) -> None:
        self.console_output = console_output
        self.file_output = file_output
        self.log_level = log_level.upper()
        self._min_level = _LEVEL_ORDER.get(self.log_level, 1)
        self._lock = threading.Lock()
        self._file = None
        self._file_path: str | None = None
        # Second file: human-readable alerts log (signal only, no noise)
        self._alerts_file = None
        self._alerts_file_path: str | None = None
        self._closed = False
        self._delegation_count = 0
        self._start_time: float | None = None

        # New layout: per-run session directory inside agentsonar_logs/.
        # These stay None when file_output=False or directory creation
        # fails. The engine reads `run_dir` to decide where to write
        # the JSON + HTML reports, so tests disabling file_output also
        # implicitly skip auto-export.
        self.run_dir: str | None = None
        self.logs_root: str | None = None

        # Resolve retention from arg → env var → default.
        if keep_runs is None:
            env_value = os.environ.get("AGENTSONAR_KEEP_RUNS")
            if env_value is not None:
                try:
                    keep_runs = int(env_value)
                except ValueError:
                    keep_runs = 20
            else:
                keep_runs = 20
        self.keep_runs = max(0, keep_runs)

        if self.file_output:
            try:
                self._create_session_directory(output_dir, session_id)
                self._open_session_files()
                self._write_latest_pointer()
                self._write_gitignore_once()
                # Retention runs AFTER the new run dir is created so
                # the current run is never pruned (it's always the
                # most recent). Failures are swallowed.
                try:
                    self._prune_old_runs()
                except Exception:
                    pass
            except Exception:
                # Total session-setup failure — degrade to console-only
                # mode so the engine can still emit stderr alerts even
                # though file logging isn't working.
                self._cleanup_partial_session()

    # ------------------------------------------------------------------
    # Session directory setup
    # ------------------------------------------------------------------

    def _create_session_directory(
        self, output_dir: str, session_id: str | None
    ) -> None:
        """Create `<output_dir>/agentsonar_logs/run-<date>_<time>-<slug>/`.

        Directory name format: `run-YYYY-MM-DD_HH-MM-SS-adjective-noun`
        — e.g. `run-2026-04-11_06-48-40-brave-otter`.

        Three pieces:
          * ISO date with hyphens — human-readable, sortable
          * Time with hyphens (not colons) — filesystem-safe on Windows
          * Docker-style memorable slug, deterministic from session_id
            so the same session always produces the same slug

        If `session_id` isn't provided, a fresh UUID seeds the slug
        instead — every run still gets a stable, memorable name.
        """
        self.logs_root = os.path.abspath(os.path.join(output_dir, _LOGS_DIR_NAME))
        os.makedirs(self.logs_root, exist_ok=True)

        # Timestamp: ISO date + filesystem-safe time. No milliseconds
        # in the dir name — same-second runs are disambiguated by the
        # slug first, then by a numeric suffix if the slug also
        # collides. The JSONL `ts` field still has microsecond
        # precision for machine consumers.
        #
        # Local time (not UTC) is INTENTIONAL here. Session directory
        # names are primarily a filesystem-browsing affordance for the
        # user running the SDK on their own machine: "what time did I
        # run that yesterday?" is a local-time question. Shared reports
        # use UTC throughout (see html_report.py "Generated at" line
        # and every CoordinationEvent.timestamp_iso field) so reports
        # are unambiguous across teams. Mixing local and UTC across the
        # two surfaces is deliberate.
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")

        # Slug: deterministic from the engine's session_id when one
        # is provided. Falls back to a fresh random UUID seed so the
        # slug still exists even without a session_id.
        slug_seed = session_id if session_id else uuid.uuid4().hex
        slug = generate_slug(slug_seed)

        # Collision handling. Two runs in the same second with the
        # same slug (rare: same UUID prefix hashing to the same slot
        # out of 4096 options) would otherwise collide. Previously
        # `os.makedirs(exist_ok=True)` silently merged them and the
        # second run's `open(path, "w")` overwrote the first run's
        # log files — silent data loss. Now we try suffixes `-1`,
        # `-2`, ... until we find a unique directory name, then use
        # `os.makedirs(..., exist_ok=False)` to assert exclusivity.
        base_run_name = f"run-{timestamp}-{slug}"
        run_name = base_run_name
        suffix = 1
        while os.path.exists(os.path.join(self.logs_root, run_name)):
            run_name = f"{base_run_name}-{suffix}"
            suffix += 1
            if suffix > 999:  # defensive: pathological collision storm
                run_name = f"{base_run_name}-{uuid.uuid4().hex[:6]}"
                break

        self.run_dir = os.path.join(self.logs_root, run_name)
        # exist_ok=False → if another process races us to create the
        # same directory between the existence check above and now,
        # we raise instead of silently merging. The outer try/except
        # in __init__ catches this and degrades to console-only mode.
        os.makedirs(self.run_dir, exist_ok=False)

    def _open_session_files(self) -> None:
        """Open the timeline JSONL and alerts log files inside run_dir.

        Uses fixed filenames (`timeline.jsonl`, `alerts.log`) because
        the enclosing directory already carries the timestamp and id.

        File descriptor safety: if the SECOND open() raises (disk
        full mid-call, handle limit reached, permission weirdness),
        the first file's descriptor would leak until `_cleanup_partial_session`
        gets around to closing it in the outer except handler — and
        if THAT path also failed, the handle would leak for the
        lifetime of the process. Explicitly close the first file
        here on any exception from the second open, then re-raise.
        """
        assert self.run_dir is not None
        self._file_path = os.path.join(self.run_dir, _FILENAME_TIMELINE)
        self._file = open(self._file_path, "w", encoding="utf-8")

        self._alerts_file_path = os.path.join(self.run_dir, _FILENAME_ALERTS)
        try:
            self._alerts_file = open(self._alerts_file_path, "w", encoding="utf-8")
        except Exception:
            # Second open failed — close the first to avoid leaking
            # its fd. The outer except in __init__ will still see
            # the raised exception and call `_cleanup_partial_session`
            # to finish the rollback.
            try:
                self._file.close()
            except Exception:
                pass
            self._file = None
            self._file_path = None
            raise

    def _write_latest_pointer(self) -> None:
        """Write `agentsonar_logs/latest` with the current run dir basename.

        A plain text file — NOT a symlink — so it works identically on
        Windows, macOS, Linux, and after zip extraction. wandb's symlink
        approach has a known Windows bug (issue #5149). Users read the
        pointer with `cat agentsonar_logs/latest` or
        `Get-Content agentsonar_logs/latest`.

        Best-effort: failure to write the pointer doesn't abort the run.
        Pre-check: if `latest` already exists as a directory (someone
        did `mkdir agentsonar_logs/latest/`), `open(..., "w")` would
        raise `IsADirectoryError`. Detect that explicitly and log a
        debug breadcrumb so users have something to grep for if they
        wonder why `cat agentsonar_logs/latest` returns no output.
        """
        if self.logs_root is None or self.run_dir is None:
            return
        latest_path = os.path.join(self.logs_root, _FILENAME_LATEST)
        # Proactive type check — if `latest` exists but is NOT a
        # regular file, skip silently. open("dir", "w") would raise
        # IsADirectoryError on Linux or PermissionError on Windows;
        # both would be caught by the broad except below, but the
        # debug log here tells the user WHY in case they go looking.
        if os.path.exists(latest_path) and not os.path.isfile(latest_path):
            _module_logger.debug(
                "AgentSonar: %s exists but is not a regular file — "
                "skipping latest pointer update",
                latest_path,
            )
            return
        try:
            with open(latest_path, "w", encoding="utf-8") as f:
                f.write(os.path.basename(self.run_dir) + "\n")
        except Exception as e:
            _module_logger.debug(
                "AgentSonar: failed to write latest pointer at %s: %s",
                latest_path, e,
            )

    def _write_gitignore_once(self) -> None:
        """Write a self-excluding `.gitignore` inside `agentsonar_logs/`.

        Trick borrowed from pytest-cache: `.gitignore` containing `*`
        prevents accidental commits of every log file in the directory
        without requiring users to remember to add it to their own
        `.gitignore`. Only written if one doesn't already exist — users
        who customize it won't have their version overwritten.

        Same dir-type defense as `_write_latest_pointer`: if someone
        has `mkdir agentsonar_logs/.gitignore/`, open-for-write would
        crash with IsADirectoryError. Skip silently with a debug log.
        """
        if self.logs_root is None:
            return
        gitignore_path = os.path.join(self.logs_root, _FILENAME_GITIGNORE)
        if os.path.exists(gitignore_path):
            # Already exists — may be a user-customized file OR a
            # directory someone pre-created. Either way, leave it.
            if not os.path.isfile(gitignore_path):
                _module_logger.debug(
                    "AgentSonar: %s exists but is not a regular file — "
                    "skipping .gitignore write",
                    gitignore_path,
                )
            return
        try:
            with open(gitignore_path, "w", encoding="utf-8") as f:
                f.write(
                    "# Created automatically by AgentSonar.\n"
                    "# All per-run logs/reports are git-ignored so they\n"
                    "# never sweep into commits. Delete this file if you\n"
                    "# want to manage inclusion yourself.\n"
                    "*\n"
                )
        except Exception as e:
            _module_logger.debug(
                "AgentSonar: failed to write .gitignore at %s: %s",
                gitignore_path, e,
            )

    def _prune_old_runs(self) -> None:
        """Retention: keep the `keep_runs` most recent run directories.

        Sorted by directory `mtime` (newest first) rather than by
        directory NAME. Previous versions sorted by name, which works
        for runs in different seconds (ISO timestamps are lex-sortable)
        BUT breaks in two cases:

          1. DST fall-back — when the clock moves backwards 1 hour
             (e.g. 02:59 EDT → 02:00 EST), two runs 10 minutes apart
             on each side of the transition have inverted lex order.
             Name-based retention keeps the older clock-wise run and
             prunes the newer one. Mtime-based retention reflects
             the filesystem's actual creation order and is immune.

          2. User-set wall clock — a user who adjusts their system
             clock backwards creates runs with "earlier" names than
             their predecessors. Same inversion. Mtime is still
             monotonic because the filesystem tracks actual events.

        Three hard rules:
          1. Only directories matching `_RUN_DIR_PATTERN` are candidates
             — anything else the user dropped into `agentsonar_logs/`
             is left untouched (custom notes, subdirectories, etc).
          2. The CURRENT run's directory is NEVER deleted. Without
             this guard, a newly-created run with a very early slug
             could get pruned underneath itself.
          3. `os.stat` failures on individual candidates are
             tolerated — the directory is silently skipped rather
             than crashing the whole sweep.

        Set `keep_runs=0` to disable retention entirely.
        """
        if self.keep_runs <= 0:
            return
        if self.logs_root is None or not os.path.isdir(self.logs_root):
            return

        # The current run's dir name is the basename of self.run_dir.
        # We compare by basename not full path so the `skip` check is
        # resilient to any path normalization difference.
        current_run_name = (
            os.path.basename(self.run_dir) if self.run_dir else None
        )

        # Build candidate list with (mtime, name) pairs. Collect
        # mtimes under the sweep so we can sort reliably.
        candidates: list[tuple[float, str]] = []
        for name in os.listdir(self.logs_root):
            if not _RUN_DIR_PATTERN.match(name):
                continue
            full = os.path.join(self.logs_root, name)
            try:
                stat = os.stat(full)
            except OSError:
                # Dir vanished between listdir and stat (another
                # process pruned it), or we don't have permission.
                # Skip it — can't safely include without an mtime.
                continue
            if not os.path.isdir(full):
                continue
            candidates.append((stat.st_mtime, name))

        if len(candidates) <= self.keep_runs:
            return

        # Newest first by mtime
        candidates.sort(key=lambda pair: pair[0], reverse=True)
        sorted_names = [name for _, name in candidates]

        # Protect the current run — see rule #2 above.
        if current_run_name and current_run_name in sorted_names:
            sorted_names.remove(current_run_name)
            effective_keep = max(0, self.keep_runs - 1)
        else:
            effective_keep = self.keep_runs

        to_delete = sorted_names[effective_keep:]

        for name in to_delete:
            victim = os.path.join(self.logs_root, name)
            try:
                import shutil
                shutil.rmtree(victim, ignore_errors=True)
            except Exception:
                pass

    def _cleanup_partial_session(self) -> None:
        """Best-effort rollback if session setup failed partway through.

        Closes any files that DID open, nulls all the path/file
        attributes, and leaves the logger in console-only mode so
        detection + stderr output still works.
        """
        if self._file:
            try:
                self._file.close()
            except Exception:
                pass
        if self._alerts_file:
            try:
                self._alerts_file.close()
            except Exception:
                pass
        self._file = None
        self._file_path = None
        self._alerts_file = None
        self._alerts_file_path = None
        self.run_dir = None
        self.logs_root = None

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> SonarLogger:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Core log method
    # ------------------------------------------------------------------

    def log(self, level: str, event: str, data: dict) -> None:
        """Core log method. Writes JSONL to file and formatted line to stderr."""
        # Bail out during interpreter shutdown — I/O handles may be gone
        if sys.is_finalizing():
            return
        level = level.upper()
        if _LEVEL_ORDER.get(level, 0) < self._min_level:
            return

        now = datetime.now(timezone.utc)
        # Microsecond precision in the JSONL timeline (ts field) so two
        # events emitted in the same millisecond still sort correctly
        # and users can see the exact ingest ordering. %f is 6 digits.
        ts_iso = now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        # Console prefix uses millisecond precision — enough to
        # disambiguate two events in the same second (which happens all
        # the time with hot cycles) while staying compact for a live
        # stderr stream. Format: [SONAR HH:MM:SS.mmm].
        ts_short = now.strftime("%H:%M:%S.") + f"{now.microsecond // 1000:03d}"

        record = {"ts": ts_iso, "level": level, "event": event, "data": data}

        # Format once; reused for both stderr and the alerts log
        formatted_line: str | None = None
        if self.console_output or (self._alerts_file and event in _ALERTS_LOG_EVENTS):
            try:
                formatted_line = self._format_console(level, event, data, ts_short)
            except Exception:
                formatted_line = None

        with self._lock:
            # JSONL file (full machine-readable log — every event).
            # `ensure_ascii=False` writes UTF-8 directly instead of
            # escaping non-ASCII characters to `\uXXXX` surrogate
            # pairs. The file already opens with `encoding="utf-8"`
            # so native characters are fine on disk. The default
            # (escape-everything) would quadruple the file size on
            # runs with CJK/emoji/RTL agent names AND make the
            # human-visible content unreadable in `cat` / `less` /
            # `tail`. JSON parsers accept both forms per RFC 8259.
            if self._file and not self._closed:
                try:
                    self._file.write(
                        json.dumps(record, default=str, ensure_ascii=False) + "\n"
                    )
                    self._file.flush()
                except Exception:
                    pass

            # Alerts file (human-readable, signal-only)
            if (self._alerts_file and not self._closed
                    and event in _ALERTS_LOG_EVENTS and formatted_line):
                try:
                    self._alerts_file.write(formatted_line + "\n")
                    self._alerts_file.flush()
                except Exception:
                    pass

            # Console output (stderr).
            # Events in _STDERR_SUPPRESSED_EVENTS stay in the JSONL log
            # above but are hidden from the live stderr stream — they're
            # raw precursor signals that resolve into formal alerts, and
            # showing both doubles the visual noise. Users who need the
            # raw stream can tail the JSONL file.
            if (
                self.console_output
                and formatted_line
                and event not in _STDERR_SUPPRESSED_EVENTS
            ):
                try:
                    color = _COLORS.get(level, "")
                    if color:
                        print(f"{color}{formatted_line}{_RESET}", file=sys.stderr)
                    else:
                        print(formatted_line, file=sys.stderr)
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Console formatting
    # ------------------------------------------------------------------

    def _format_console(self, level: str, event: str, data: dict, ts: str) -> str:
        """Format a single human-readable console line."""
        prefix = f"[SONAR {ts}]"

        if event == "delegation":
            src = data.get("source", "?")
            tgt = data.get("target", "?")
            num = data.get("delegation_number", "?")
            return f"{prefix} delegation: {src} -> {tgt} (#{num})"

        if event == "alert":
            severity = data.get("severity", level)
            pattern = data.get("pattern", "unknown")
            icon = "\u26a0" if severity == "WARNING" else "\U0001f6a8"

            if "cycle_path" in data:
                path = data["cycle_path"]
                cycle_str = " -> ".join(str(a) for a in path) + " -> " + str(path[0]) if path else "?"
                rotations = data.get("rotations", "?")
                return f"{prefix} {icon} {severity} {pattern}: [{cycle_str}] {rotations} rotations"

            if "source" in data and "target" in data:
                src = data["source"]
                tgt = data["target"]
                extra_parts = []
                # Count info — prefer event_count (decay detector) over
                # rotations (AlertStateManager) for one-directional patterns
                if "event_count" in data:
                    extra_parts.append(f"{data['event_count']} events")
                elif "rotations" in data and data["rotations"]:
                    extra_parts.append(f"{data['rotations']} rotations")
                if "estimated_rate" in data:
                    extra_parts.append(f"rate: {data['estimated_rate']}")
                if "limit" in data:
                    extra_parts.append(f"limit: {data['limit']}")
                extra = f" ({', '.join(extra_parts)})" if extra_parts else ""
                return f"{prefix} {icon} {severity} {pattern}: {src} -> {tgt}{extra}"

            # SCC alerts carry an `agents` list but no cycle_path / src / tgt.
            # Without this branch, SCC alerts fell through to the bare
            # "pattern-only" line and the user never saw which agents were
            # stuck in the cycle group.
            if "agents" in data and isinstance(data["agents"], (list, tuple)):
                agents_list = list(data["agents"])
                agents_str = ", ".join(str(a) for a in agents_list) if agents_list else "?"
                rotations = data.get("rotations", "?")
                return (
                    f"{prefix} {icon} {severity} {pattern}: "
                    f"{{{agents_str}}} {rotations} rotations"
                )

            return f"{prefix} {icon} {severity} {pattern}"

        if event == "alert_resolved":
            fp = data.get("fingerprint", [])
            fp_str = ", ".join(str(a) for a in fp) if fp else "?"
            dur = data.get("duration_seconds", "?")
            return f"{prefix} \u2713 RESOLVED {data.get('pattern', 'alert')}: [{fp_str}] after {dur}s"

        if event == "prevented":
            failure_class = data.get("failure_class", "coordination_failure")
            cycle_path = data.get("cycle_path") or []
            rotations = data.get("rotations", "?")
            # \U0001F6D1 is \ud83d\uded1 (octagonal sign / stop emoji) \u2014 consistent
            # with the HTML report's PREVENTED badge so users see the
            # same visual marker in both places.
            if cycle_path:
                path_str = " -> ".join(str(a) for a in cycle_path)
                return (
                    f"{prefix} \U0001f6d1 PREVENTED {failure_class}: "
                    f"[{path_str}] stopped at {rotations} rotations"
                )
            return (
                f"{prefix} \U0001f6d1 PREVENTED {failure_class}: "
                f"stopped at {rotations} rotations"
            )

        if event == "session_start":
            sid = data.get("session_id", "?")
            return f"{prefix} session started (id: {sid})"

        if event == "session_end":
            total = data.get("total_delegations", 0)
            alerts = data.get("total_alerts", 0)
            return f"{prefix} session ended ({total} delegations, {alerts} alerts)"

        if event == "cycle_detected":
            path = data.get("cycle_path", [])
            cycle_str = " -> ".join(str(a) for a in path) + " -> " + str(path[0]) if path else "?"
            rotations = data.get("rotations", 0)
            return f"{prefix} cycle found: [{cycle_str}] {rotations} rotations"

        if event == "scc_sweep":
            count = len(data.get("components", []))
            return f"{prefix} SCC sweep: {count} components"

        if event == "rate_limit_hit":
            # Circuit breaker fired (CRITICAL). SlidingWindowLimiter produces
            # two variants: "rate_limit_exceeded" (per-edge) has source/target,
            # "global_rate_exceeded" (global) has no source/target.
            pattern = data.get("pattern", "rate_limit")
            src = data.get("source")
            tgt = data.get("target")
            rate = data.get("estimated_rate", "?")
            limit = data.get("limit", "?")
            if src and tgt:
                return (
                    f"{prefix} \U0001f6a8 CRITICAL {pattern}: {src} -> {tgt} "
                    f"(rate: {rate}, limit: {limit})"
                )
            return f"{prefix} \U0001f6a8 CRITICAL {pattern}: rate {rate} exceeded limit {limit}"

        if event == "anomaly_detected":
            # Raw decay-detector signal. Mostly a heads-up before the formal
            # alert fires — dimmer than a real alert but still worth reading.
            src = data.get("source", "?")
            tgt = data.get("target", "?")
            count = data.get("event_count", "?")
            return f"{prefix} anomaly: {src} -> {tgt} ({count} events)"

        # Fallback
        return f"{prefix} {event}: {json.dumps(data, default=str)}"

    # ------------------------------------------------------------------
    # Typed log methods
    # ------------------------------------------------------------------

    def log_session_start(
        self,
        session_id: str | None = None,
        framework: str = "unknown",
        agents: list[str] | None = None,
    ) -> None:
        """Called once at engine initialization."""
        import time
        self._start_time = time.time()
        if session_id is None:
            session_id = uuid.uuid4().hex[:8]
        self.log("INFO", "session_start", {
            "session_id": session_id,
            "framework": framework,
            "agents": agents or [],
        })

    def log_delegation(
        self, source: str, target: str, edge_count: int, delegation_number: int
    ) -> None:
        """Called on every delegation event."""
        self._delegation_count = delegation_number
        self.log("DEBUG", "delegation", {
            "source": source,
            "target": target,
            "edge_count": edge_count,
            "delegation_number": delegation_number,
        })

    def log_graph_update(self, source: str, target: str, edge_count: int) -> None:
        """Called when an edge is added or count incremented."""
        self.log("DEBUG", "graph_update", {
            "source": source,
            "target": target,
            "edge_count": edge_count,
        })

    def log_alert(self, alert: Alert) -> None:
        """Called when an alert is emitted. Uses alert.severity as level."""
        data = dict(alert.details)
        data["pattern"] = alert.pattern
        data["severity"] = alert.severity
        # Convert tuple fingerprints to lists for JSON
        if "fingerprint" in data and isinstance(data["fingerprint"], tuple):
            data["fingerprint"] = list(data["fingerprint"])
        self.log(alert.severity, "alert", data)

    def log_alert_resolved(
        self,
        pattern: str,
        fingerprint: tuple,
        total_rotations: int,
        duration_seconds: float,
    ) -> None:
        """Called when alert state machine resolves an alert."""
        self.log("INFO", "alert_resolved", {
            "pattern": pattern,
            "fingerprint": list(fingerprint) if isinstance(fingerprint, tuple) else fingerprint,
            "total_rotations": total_rotations,
            "duration_seconds": round(duration_seconds, 1),
        })

    def log_prevented(self, prevention: Any) -> None:
        """Called when Prevent Mode trips — emits a CRITICAL-level
        'prevented' event so the chronological alerts.log shows the
        trip alongside the WARNING/CRITICAL alerts that preceded it.

        `prevention` is duck-typed as a PreventionResult (or anything
        with `failure_class`, `severity`, `rotations`, `cycle_path`,
        `reason` attributes). Defensive `getattr` so a future logger
        rewrap doesn't crash if fields are missing.
        """
        self.log("CRITICAL", "prevented", {
            "failure_class": getattr(prevention, "failure_class", "unknown"),
            "severity": getattr(prevention, "severity", "CRITICAL"),
            "rotations": getattr(prevention, "rotations", 0),
            "cycle_path": list(getattr(prevention, "cycle_path", []) or []),
            "reason": getattr(prevention, "reason", ""),
        })

    def log_cycle_detected(self, cycle_path: list[str], rotations: int) -> None:
        """Called when has_path finds a cycle, even before threshold."""
        self.log("INFO", "cycle_detected", {
            "cycle_path": cycle_path,
            "rotations": rotations,
        })

    def log_anomaly_detected(self, anomaly: dict) -> None:
        """Called when exponential decay flags an edge."""
        self.log("WARNING", "anomaly_detected", anomaly)

    def log_rate_limit_hit(self, alert: Alert) -> None:
        """Called when sliding window circuit breaker fires."""
        data = dict(alert.details)
        data["pattern"] = alert.pattern
        self.log("CRITICAL", "rate_limit_hit", data)

    def log_scc_sweep(self, results: list[dict]) -> None:
        """Called when periodic SCC runs."""
        self.log("DEBUG", "scc_sweep", {"components": results})

    def log_session_end(
        self,
        summary: dict,
        report_paths: dict[str, str] | None = None,
    ) -> None:
        """Called at end of run. Writes summary, prints banner, closes file.

        Args:
            summary: Engine summary dict (events, alerts, edge counts).
            report_paths: Optional dict mapping report type ("json", "html")
                to the absolute file path. When provided, the banner's
                "Output files" section lists each report alongside the
                log files so users see all 4 artifacts in one place
                instead of having to `ls` the directory after the run.
        """
        import time

        duration = 0.0
        if self._start_time:
            duration = time.time() - self._start_time

        # Break alerts down by severity so downstream consumers reading
        # the final JSONL record can see at a glance whether the run was
        # clean. `clean_run` is an explicit boolean — "no WARNING or
        # CRITICAL alerts fired" — so tools that tail timeline.jsonl
        # for the last record get a one-field yes/no instead of having
        # to parse the full alerts list.
        alerts_list = summary.get("alerts", []) or []
        warning_count = sum(
            1 for a in alerts_list if a.get("severity") == "WARNING"
        )
        critical_count = sum(
            1 for a in alerts_list if a.get("severity") == "CRITICAL"
        )
        clean_run = (warning_count == 0 and critical_count == 0)

        data = {
            "total_events": summary.get("total_events", 0),
            "total_alerts": summary.get("alerts_raised", 0),
            "warning_count": warning_count,
            "critical_count": critical_count,
            "clean_run": clean_run,
            "total_delegations": self._delegation_count,
            "duration_seconds": round(duration, 1),
            "edge_counts": summary.get("edge_counts", {}),
            "message": (
                "No coordination failures detected during this run."
                if clean_run
                else f"{critical_count} CRITICAL, {warning_count} WARNING "
                     f"coordination alert(s) detected during this run."
            ),
        }
        self.log("INFO", "session_end", data)

        # Print summary banner to stderr
        if self.console_output:
            try:
                self._print_summary_banner(
                    summary, duration, report_paths=report_paths or {},
                )
            except Exception:
                pass

        self.close()

    # ------------------------------------------------------------------
    # Summary banner
    # ------------------------------------------------------------------

    def _print_summary_banner(
        self,
        summary: dict,
        duration: float,
        report_paths: dict[str, str] | None = None,
    ) -> None:
        """Print a boxed run-summary banner to stderr, followed by a
        list of every output file AgentSonar wrote for this run.

        The box contains small fixed-width stats (duration, counts,
        top edge). Output file paths go UNDERNEATH the box on their
        own lines — filenames are long enough that trying to fit them
        inside a 48-char box breaks the right-border alignment, so we
        don't try.
        """
        mins = int(duration // 60)
        secs = int(duration % 60)
        dur_str = f"{mins}m {secs}s" if mins > 0 else f"{secs}s"

        delegations = self._delegation_count
        total_alerts = summary.get("alerts_raised", 0)
        alerts_list = summary.get("alerts", [])
        warning_count = sum(1 for a in alerts_list if a.get("severity") == "WARNING")
        critical_count = sum(1 for a in alerts_list if a.get("severity") == "CRITICAL")

        edge_counts = summary.get("edge_counts", {})
        top_edge = ""
        if edge_counts:
            top_key = max(edge_counts, key=edge_counts.get)
            top_edge = f"{top_key} ({edge_counts[top_key]}x)"

        w = 48
        lines = [
            "\u2554" + "\u2550" * w + "\u2557",
            "\u2551" + "AGENT SONAR - RUN SUMMARY".center(w) + "\u2551",
            "\u2560" + "\u2550" * w + "\u2563",
            "\u2551" + f"  Duration:        {dur_str}".ljust(w) + "\u2551",
            "\u2551" + f"  Delegations:     {delegations}".ljust(w) + "\u2551",
            "\u2551" + f"  Alerts:          {total_alerts}".ljust(w) + "\u2551",
            "\u2551" + f"    WARNING:       {warning_count}".ljust(w) + "\u2551",
            "\u2551" + f"    CRITICAL:      {critical_count}".ljust(w) + "\u2551",
        ]
        if top_edge:
            # Truncate top-edge line if it would overflow the box border.
            # Budget: w chars minus the 2-char leading "  ", minus the
            # 17-char label ("Top edge:        "). Remaining chars get
            # an ellipsis if the edge name + count won't fit.
            label_width = len("  Top edge:        ")
            remaining = w - label_width
            if len(top_edge) > remaining:
                top_edge = top_edge[: remaining - 1] + "\u2026"
            lines.append("\u2551" + f"  Top edge:        {top_edge}".ljust(w) + "\u2551")
        lines.append("\u255a" + "\u2550" * w + "\u255d")

        banner = "\n".join(lines)
        print(banner, file=sys.stderr)

        # Clean-run confirmation — a single green line under the box
        # so users running live see the "nothing to worry about"
        # signal without having to open the HTML report. Appears only
        # when no WARNING or CRITICAL alerts fired. Uses the same
        # ANSI green (\033[92m) the stderr INFO theme already uses,
        # so `less -R` / `cat` on a dumb terminal still read cleanly.
        if warning_count == 0 and critical_count == 0:
            print(
                "\033[92m\u2713 No coordination failures detected — "
                "clean run.\033[0m",
                file=sys.stderr,
            )

        # Print the output file list below the box. Filenames are long
        # enough that squeezing them into a 48-char box would break the
        # right border, so they get their own lines with no border.
        self._print_output_files(report_paths or {})

    def _print_output_files(self, report_paths: dict[str, str]) -> None:
        """Print the run directory + basenames of every file in it.

        All 4 files share one directory (`agentsonar_logs/run-*/`), so
        the banner shows the directory ONCE and lists the basenames
        indented below it. Much cleaner than printing 4 nearly-identical
        absolute paths.

        Example output:
            Output directory:
              C:\\Users\\srini\\project\\agentsonar_logs\\run-20260411_063000_123-a1b2c3
                ├─ timeline.jsonl
                ├─ alerts.log
                ├─ report.json
                └─ report.html
        """
        # Collect basenames of everything that was actually written
        entries: list[str] = []
        if self._file_path:
            entries.append(os.path.basename(self._file_path))
        if self._alerts_file_path:
            entries.append(os.path.basename(self._alerts_file_path))
        if "json" in report_paths:
            entries.append(os.path.basename(report_paths["json"]))
        if "html" in report_paths:
            entries.append(os.path.basename(report_paths["html"]))

        if not entries:
            return

        print("  Output directory:", file=sys.stderr)
        if self.run_dir:
            print(f"    {self.run_dir}", file=sys.stderr)
        for i, name in enumerate(entries):
            connector = "\u2514\u2500" if i == len(entries) - 1 else "\u251c\u2500"
            print(f"      {connector} {name}", file=sys.stderr)

        # Tip at the bottom: how to get back to the latest run later.
        if self.logs_root is not None:
            latest_path = os.path.join(self.logs_root, _FILENAME_LATEST)
            print(
                f"  (Tip: `{latest_path}` holds the latest run dir name.)",
                file=sys.stderr,
            )

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Flush and close both log files."""
        with self._lock:
            if self._closed:
                return
            if self._file:
                try:
                    self._file.flush()
                    self._file.close()
                except Exception:
                    pass
            if self._alerts_file:
                try:
                    self._alerts_file.flush()
                    self._alerts_file.close()
                except Exception:
                    pass
            self._closed = True
