"""
JSON export for AgentSonar CoordinationEvents.

Serializes a list of CoordinationEvent objects into structured JSON that
consumers (dashboards, webhooks, CLI tools) can parse. By default, events
are deduplicated by coordination_fingerprint AND inhibited (symptom alerts
subsumed by root-cause alerts are suppressed), so the report is a summary
view showing actionable signals only. Pass `dedupe=False` to get the full
raw timeline.

Output is strict JSON (RFC 8259) — no bareword NaN / Infinity tokens.
See `_sanitize_for_json` for the sanitization pipeline.
"""
from __future__ import annotations

import json
import math
import os
from datetime import datetime
from typing import Any

from agentsonar._core.schema import (
    CoordinationEvent,
    dedupe_events_by_fingerprint,
    inhibit_subsumed_events,
)


def _summarize(events: list[CoordinationEvent]) -> list[CoordinationEvent]:
    """Apply dedupe + inhibition — the summary view pipeline."""
    deduped = dedupe_events_by_fingerprint(events)
    return inhibit_subsumed_events(deduped)


def _sanitize_for_json(value: Any) -> Any:
    """Recursively replace non-finite floats (NaN, Infinity, -Infinity)
    with None so the serialized JSON is strict-RFC-8259 compliant.

    Python's `json.dumps` accepts non-finite floats by default and
    emits them as bareword tokens (`NaN`, `Infinity`) — NOT valid JSON.
    Strict parsers (Go, Rust serde_json, Postgres jsonb) reject these.
    Dashboards that consume our report would fail parsing even though
    Python can re-parse its own non-strict output.

    Policy: quietly substitute None. Alternatives considered:
      * `json.dumps(allow_nan=False)` — raises ValueError mid-write,
        would blow up the whole report generation path; bad UX.
      * Convert to string ("NaN", "inf") — machine consumers then
        get strings where they expect numbers; breaks schema contracts.
      * Raise at entry — same problem, bad UX for a defensive sweep.

    None is the least-bad choice: strict JSON, preserves the dict
    key shape, and machine consumers already handle null for
    "missing / unknown numeric value".
    """
    if isinstance(value, float):
        if math.isfinite(value):
            return value
        return None  # NaN, +inf, -inf all become null
    if isinstance(value, dict):
        return {k: _sanitize_for_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize_for_json(v) for v in value]
    return value


def export_json(
    events: list[CoordinationEvent],
    path: str | None = None,
    *,
    output_dir: str = ".",
    dedupe: bool = True,
) -> str:
    """Write CoordinationEvents as a JSON array to a file.

    Args:
        events: List of CoordinationEvent objects.
        path: Destination file path. If None, auto-generates a timestamped
            filename of the form `agentsonar_report_YYYYMMDD_HHMMSS_mmm.json`
            in `output_dir`. The `_mmm` millisecond suffix guarantees
            back-to-back calls don't collide on the same filename.
        output_dir: Directory for the auto-generated filename (keyword-only).
            Ignored when `path` is provided explicitly. Created if missing.
        dedupe: If True (default), produce a SUMMARY view: collapse events
            with the same coordination_fingerprint (keep highest severity /
            latest), AND inhibit symptom events (e.g. a REPETITIVE_DELEGATION
            edge that's part of a detected CYCLIC_DELEGATION is suppressed
            because the cycle is the root cause). Pass False to include
            every raw state transition (timeline view).

    Returns:
        The actual file path written.
    """
    if dedupe:
        events = _summarize(events)

    if path is None:
        os.makedirs(output_dir, exist_ok=True)
        # Millisecond precision (YYYYMMDD_HHMMSS_mmm) so back-to-back
        # exports in the same second don't collide. strftime's %f is
        # microseconds (6 digits); we slice to 3 for milliseconds.
        #
        # LOCAL time (not UTC) is intentional — this only runs on the
        # auto-generated-filename path, which is a filesystem-browsing
        # affordance for the user on their own machine. Shared reports
        # are addressed by content (JSON fields use UTC throughout),
        # not by filename. See the session-directory comment in
        # terminal.py::_create_session_directory for the full rationale.
        now = datetime.now()
        ts = now.strftime("%Y%m%d_%H%M%S") + f"_{now.microsecond // 1000:03d}"
        path = os.path.join(output_dir, f"agentsonar_report_{ts}.json")
    else:
        # Make sure the parent directory exists for explicit paths too —
        # otherwise open() fails with FileNotFoundError. No-op if the
        # path has no directory component (cwd) or it already exists.
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            _sanitize_for_json([e.to_dict() for e in events]),
            f,
            indent=2,
            default=str,
            # Belt and suspenders: raise if any non-finite float
            # somehow survived _sanitize_for_json. Catches logic bugs
            # in future refactors that would otherwise silently emit
            # invalid JSON.
            allow_nan=False,
            # Write native UTF-8 rather than `\uXXXX` escape pairs —
            # the file is opened with encoding="utf-8" so Unicode
            # agent names and summaries should be human-readable in
            # the output file (cat / less / grep all work correctly).
            ensure_ascii=False,
        )
    return path


def events_to_json(
    events: list[CoordinationEvent],
    indent: int = 2,
    *,
    dedupe: bool = True,
) -> str:
    """Serialize events to a JSON string without writing to disk.

    See `export_json` for the `dedupe` parameter semantics (dedupe + inhibit).
    Sanitizes non-finite floats to `null` so the output is strict
    RFC 8259 JSON (see `_sanitize_for_json` for rationale).
    """
    if dedupe:
        events = _summarize(events)
    return json.dumps(
        _sanitize_for_json([e.to_dict() for e in events]),
        indent=indent,
        default=str,
        allow_nan=False,
        # Native UTF-8 — see the comment in `export_json` above.
        ensure_ascii=False,
    )
