"""
AgentSonar — detect coordination failures in multi-agent AI systems.

Two lines to integrate:

    # CrewAI
    from agentsonar import AgentSonarListener
    sonar = AgentSonarListener()
    # ...run your crew normally.

    # LangGraph / LangChain — option 1: pass the callback yourself
    from agentsonar import AgentSonarCallback
    result = graph.invoke(input, config={"callbacks": [AgentSonarCallback()]})

    # LangGraph / LangChain — option 2: wrap the graph (auto-merges callbacks)
    from agentsonar import monitor
    graph = monitor(graph)
    result = graph.invoke(input)                                # auto-monitored
    result = graph.invoke(input, config={"callbacks": [my_cb]}) # my_cb preserved

    # Custom orchestrators (hand-rolled Python loops, subprocess pipelines,
    # Celery/FastAPI coordinators, anything that doesn't fit CrewAI's event
    # bus or LangGraph's callback manager)
    from agentsonar import monitor_orchestrator
    sonar = monitor_orchestrator()
    sonar.delegation(source="planner", target="researcher")
    # ...run your agents normally...
    sonar.shutdown()

    # Prevent Mode (opt-in) — auto-raise on cyclic_delegation
    from agentsonar import monitor_orchestrator, PreventError
    sonar = monitor_orchestrator(prevent={"cyclic_delegation": True})
    try:
        for i in range(50):
            sonar.delegation(source="reviewer",  target="generator")
            ...
            sonar.delegation(source="generator", target="reviewer")
            ...
    except PreventError as e:
        print(f"Stopped: {e.reason}")
    sonar.shutdown()

Detection and terminal output happen automatically. No config, no API
keys, no accounts. Alerts stream to stderr and to per-run log files
under `agentsonar_logs/` in the working directory.

Public API:
    AgentSonarListener   — CrewAI integration (requires `agentsonar[crewai]`)
    AgentSonarCallback   — LangGraph/LangChain integration (requires `agentsonar[langgraph]`)
    monitor              — LangGraph wrapper that auto-merges AgentSonar
                           into the callback list without overriding existing
                           user callbacks. Recommended when you already have
                           your own callbacks configured.
    monitor_orchestrator — Generic adapter for custom orchestrators that
                           don't fit the two framework integrations. One
                           explicit `.delegation()` call per agent-to-agent
                           handoff; detection + reports are identical.
    PreventError         — Exception raised by AgentSonar adapters when
                           Prevent Mode is enabled (`prevent={...}`) AND a
                           tracked failure has crossed its threshold.
    PreventionResult     — Frozen dataclass attached to PreventError carrying
                           the cycle path, rotations, severity, and timestamp
                           of the tripped failure.
"""
from __future__ import annotations

__version__ = "0.3.3"

# Everything below is the ONLY public surface. Framework integrations use
# conditional imports for their underlying framework — they remain
# importable even when the optional extra is not installed, and raise a
# clear RuntimeError at instantiation time instead.
#
# The custom adapter has NO optional-extra dependency — it works from a
# plain `pip install agentsonar` because it doesn't need CrewAI or
# LangGraph.
from agentsonar._core.models import PreventError, PreventionResult
from agentsonar._integrations.crewai_listener import AgentSonarListener
from agentsonar._integrations.custom import (
    CustomAdapter,
    monitor_orchestrator,
)
from agentsonar._integrations.langgraph_callback import (
    AgentSonarCallback,
    monitor,
)

__all__ = [
    "AgentSonarListener",
    "AgentSonarCallback",
    "CustomAdapter",
    "monitor",
    "monitor_orchestrator",
    "PreventError",
    "PreventionResult",
    "__version__",
]
