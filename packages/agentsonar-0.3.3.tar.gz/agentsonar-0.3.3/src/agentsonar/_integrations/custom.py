"""
Custom-orchestrator adapter — for agent pipelines that don't fit a
framework-specific event bus (CrewAI) or callback manager (LangGraph).

Use this when your orchestrator:

  * Spawns agent processes as subprocesses (headless CLI calls, Docker
    containers, remote workers) where a Python callback can't live.
  * Runs inside a web server / Celery / RQ / FastAPI handler and
    coordinates agents via plain function calls or queue messages.
  * Is a hand-rolled Python loop that calls different LLM providers
    directly and dispatches work between them.
  * Is anything else that doesn't plug into CrewAI or LangGraph's
    built-in event mechanisms.

The adapter gives you a tiny explicit API — one call per
agent-to-agent delegation — and everything else (detection pipeline,
HTML report, JSONL timeline, clean-run banners, host-safety
guarantees, `AGENTSONAR_DISABLED` kill switch) works exactly like
the framework adapters.

Usage:
    from agentsonar import monitor_orchestrator

    sonar = monitor_orchestrator()

    # Before each agent hands work to another agent:
    sonar.delegation(source="planner", target="researcher")
    # ... run the researcher agent ...

    sonar.delegation(source="researcher", target="writer")
    # ... run the writer agent ...

    sonar.shutdown()   # writes report.json + report.html

Design notes
============

Unlike the CrewAI listener (which auto-captures `ToolUsageStartedEvent`
off a real event bus) and the LangGraph callback (which auto-captures
node transitions off the callback manager), the custom adapter is
*explicit*. The orchestrator has to tell AgentSonar which agent just
handed work to which other agent. This is intentional:

  * Custom orchestrators don't have a single canonical "delegation"
    event shape. A function call, a queue push, an HTTP POST, a
    subprocess spawn, or a websocket message all mean different
    things in different codebases. AgentSonar doesn't try to infer
    — it takes the caller's word for it.
  * Explicit events make the integration trivially auditable. Grep
    the codebase for `sonar.delegation(` and every monitored
    handoff is visible.
  * No runtime magic, no subclassing, no hook registration. Works
    in any Python context including serverless, Celery tasks,
    async code, and tests.

Host-safety contract
====================

Like every other integration, `CustomAdapter` NEVER raises to the
caller. `delegation()` catches every exception internally and drops
the event silently. `shutdown()` is idempotent and exception-free.
The underlying engine is constructed via `build_engine_safely` so
bad config or platform issues degrade to a `_NoOpEngine` rather
than crashing the host orchestrator.
"""
from __future__ import annotations

import logging
import sys
import time
from typing import Any

from agentsonar._core.models import InteractionEvent, PreventError
from agentsonar._integrations._safe_engine import build_engine_safely

logger = logging.getLogger(__name__)


class CustomAdapter:
    """Minimal-surface adapter for custom orchestrators.

    Hands events directly to the DetectionEngine — no framework-specific
    event bus or callback manager required. Every delegation call is
    fault-isolated: if AgentSonar itself breaks mid-run, the exception
    is swallowed and the orchestrator keeps running.

    Attributes:
        engine: The underlying DetectionEngine (or _NoOpEngine on
            construction failure). Advanced users can call
            `adapter.engine.get_recent_events()` to pull structured
            CoordinationEvents mid-run, same as the other adapters.

    Args:
        config: Optional config dict matching the same schema the
            framework adapters accept. See the Configuration
            reference in the README. Pass `None` for defaults.
    """

    def __init__(self, config: dict | None = None):
        # Host-safety seam: `build_engine_safely` never raises. Bad
        # config values, platform quirks, missing dependencies, an
        # AGENTSONAR_DISABLED env var — all degrade to a silent
        # `_NoOpEngine` and log a clear WARNING. The caller's code
        # ALWAYS succeeds past this line.
        self.engine = build_engine_safely(config)

    def delegation(
        self,
        source: str,
        target: str,
        metadata: dict | None = None,
        timestamp: float | None = None,
    ) -> None:
        """Record one agent → agent delegation.

        Call this once per handoff in your orchestrator, right before
        (or right after) `source` hands work to `target`. AgentSonar's
        detection engine uses the stream of delegation events to
        detect cycles, runaway edges, and rate-limit exhaustion.

        Args:
            source: Name of the agent handing off work. Arbitrary
                string — use whatever naming scheme your orchestrator
                already uses. AgentSonar treats it as an opaque
                identifier.
            target: Name of the agent receiving work. Same rules as
                `source`.
            metadata: Optional dict of free-form key/value pairs
                attached to the event (e.g. iteration number,
                subprocess PID, task ID). Appears on the
                CoordinationEvent and in the JSONL timeline.
            timestamp: Optional Unix epoch float. Defaults to
                `time.time()` at call time. Override if you're
                replaying historical events through the adapter.

        Exception contract:
          * `PreventError` is the ONE exception this method intentionally
            propagates — only when the engine was constructed with
            `prevent={"cyclic_delegation": True, ...}` AND a tracked
            failure has crossed the configured threshold. The user's
            `try/except agentsonar.PreventError` block catches it.
          * EVERY other exception — bad arguments, engine failures,
            logger failures, interpreter shutdown — is caught
            internally and the event is dropped silently.
        """
        # Guard: ignore events arriving during Python interpreter
        # shutdown (matching the other adapters' behavior).
        if sys.is_finalizing():
            return

        try:
            # Coerce source/target to strings defensively — callers
            # sometimes pass integers, enums, or other identifier
            # types and our downstream schema wants strings. The
            # engine itself is also defensive here but doing it at
            # the boundary gives nicer log output.
            event = InteractionEvent(
                source_agent=str(source) if source is not None else "unknown",
                target_agent=str(target) if target is not None else "unknown",
                timestamp=timestamp if timestamp is not None else time.time(),
                metadata=dict(metadata) if metadata else None,
            )
            self.engine.ingest(event)
        except Exception:
            # Never raise to the caller. Detection degrades silently;
            # the orchestrator's next line runs normally.
            try:
                logger.debug(
                    "AgentSonar: CustomAdapter.delegation(%r -> %r) "
                    "raised unexpectedly; dropping event",
                    source, target,
                    exc_info=True,
                )
            except Exception:
                pass

        # Prevent Mode hook (opt-in, off by default). MUST run AFTER
        # ingest() so the most-recent alert is in _recent_alerts.
        # PreventError is the ONE exception type this method
        # intentionally lets propagate — every other exception
        # remains swallowed.
        try:
            check = getattr(self.engine, "check_prevent", None)
            if check is not None:
                check()  # raises PreventError if a tracked failure tripped
        except PreventError:
            raise
        except Exception:
            try:
                logger.debug(
                    "AgentSonar: check_prevent() raised non-PreventError; ignoring",
                    exc_info=True,
                )
            except Exception:
                pass

    def get_summary(self) -> dict:
        """Return the detection engine summary. Never raises.

        On failure (or in degraded mode) returns an empty-but-valid
        summary dict matching the shape of a successful call so
        downstream dashboard code that does `summary["alerts_raised"]`
        keeps working.
        """
        try:
            return self.engine.get_summary()
        except Exception:
            logger.debug(
                "AgentSonar: CustomAdapter.get_summary() raised; "
                "returning empty",
                exc_info=True,
            )
            return {
                "total_events": 0,
                "iteration_count": 0,
                "edge_counts": {},
                "total_estimated_token_waste": 0,
                "alerts_raised": 0,
                "alerts": [],
                "degraded": True,
            }

    def shutdown(self) -> None:
        """Finalize the run: log the session-end banner, write the
        JSON + HTML reports, and close the logger.

        Safe to call multiple times. Never raises — shutdown is the
        last thing the orchestrator does, and an exception here
        would turn a successful run into a confusing traceback at
        teardown time.
        """
        try:
            self.engine.shutdown()
        except Exception:
            logger.debug(
                "AgentSonar: CustomAdapter.shutdown() raised; "
                "swallowing",
                exc_info=True,
            )

    # ------------------------------------------------------------------
    # Context manager — lets orchestrators use `with monitor_orchestrator() as sonar:`
    # which guarantees shutdown() runs even on early returns / exceptions.
    # ------------------------------------------------------------------

    def __enter__(self) -> CustomAdapter:
        return self

    def __exit__(self, *exc_info: Any) -> None:
        self.shutdown()


def monitor_orchestrator(config: dict | None = None) -> CustomAdapter:
    """Start AgentSonar monitoring for a custom orchestrator.

    Returns a handle with `.delegation()` and `.shutdown()` methods.
    Use this when your code doesn't fit CrewAI's event bus
    (`AgentSonarListener`) or LangGraph's callback manager
    (`AgentSonarCallback` / `monitor()`) — e.g. a hand-rolled Python
    orchestrator that spawns subprocesses, a Celery-based agent
    pipeline, or a custom FastAPI coordinator.

    Example:
        from agentsonar import monitor_orchestrator

        sonar = monitor_orchestrator()

        for iteration in range(max_iterations):
            sonar.delegation("orchestrator", "generator",
                             metadata={"iteration": iteration})
            run_generator_subprocess(...)

            sonar.delegation("orchestrator", "evaluator",
                             metadata={"iteration": iteration})
            run_evaluator_subprocess(...)

        sonar.shutdown()

    Or use as a context manager (guarantees shutdown on early return):

        with monitor_orchestrator() as sonar:
            sonar.delegation("orchestrator", "generator")
            ...

    Args:
        config: Optional dict of engine config overrides. Same schema
            as `AgentSonarCallback(config=...)` and
            `AgentSonarListener(config=...)`. Pass `None` for defaults.

    Returns:
        A `CustomAdapter` instance. Never raises — bad config, platform
        issues, or the `AGENTSONAR_DISABLED` env var all produce a
        silently-degraded adapter whose `.delegation()` is a no-op.
    """
    return CustomAdapter(config)
