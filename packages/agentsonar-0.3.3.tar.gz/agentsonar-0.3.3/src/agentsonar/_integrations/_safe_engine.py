"""
Safe-construct helper for framework integrations.

`build_engine_safely(config)` is the one and only way the
framework integrations (`AgentSonarListener`, `AgentSonarCallback`,
`monitor`) should construct their `DetectionEngine`. It:

  0. Honors the `AGENTSONAR_DISABLED` environment variable — the
     production kill switch. If set to any truthy value
     ("1"/"true"/"yes"/"on"), `build_engine_safely` returns a
     `_NoOpEngine` IMMEDIATELY without even attempting to import
     the real engine. This gives ops teams a way to disable
     AgentSonar at runtime if something catastrophic happens in
     production without having to edit the user's code.

  1. Normalizes `config` — if the caller passed something that isn't
     a dict (None, a string, a list), swap it for an empty dict.
     The real engine's `config.get(...)` calls would otherwise
     crash with `AttributeError` on a non-dict.

  2. Tries to build a real `DetectionEngine`.

  3. On ANY failure — bad config values, I/O errors, platform
     quirks, import issues — logs a clear warning at the
     `agentsonar` logger and returns a `_NoOpEngine` instead.
     The host application never sees the exception.

  4. Outer catch-all: even if `_normalize_config` or the logger
     itself raises (extremely unlikely, but possible during
     interpreter shutdown or with a broken logging handler), we
     STILL return a `_NoOpEngine`. The `build_engine_safely`
     contract is "never raise to the caller," full stop.

This is the load-bearing host-safety seam. Every integration funnels
through it so a single audit point governs whether AgentSonar can
ever crash the host.
"""
from __future__ import annotations

import logging
import os
from typing import Any

from agentsonar._core.noop_engine import _NoOpEngine

logger = logging.getLogger("agentsonar")

# Environment variable names — centralized so future docs can
# reference them without string-hunting.
_ENV_DISABLED = "AGENTSONAR_DISABLED"
_DISABLED_VALUES = frozenset({"1", "true", "yes", "on", "enabled"})


def _is_disabled_by_env() -> bool:
    """Return True when `AGENTSONAR_DISABLED` is set to a truthy value.

    Accepts any of: "1", "true", "yes", "on", "enabled"
    (case-insensitive). Anything else — including unset, "0",
    "false" — leaves AgentSonar enabled.

    This is the production kill switch: if AgentSonar is ever
    implicated in a user outage, they can `export AGENTSONAR_DISABLED=1`
    in their deployment config and every new session immediately
    degrades to a silent no-op WITHOUT touching the user's code.
    """
    try:
        value = os.environ.get(_ENV_DISABLED, "").strip().lower()
    except Exception:
        # Broken os.environ? Absurdly defensive, but the whole point
        # of this module is to never raise. Err on the side of
        # "monitoring enabled" — the user can always disable it
        # with a code change if the env var mechanism itself is
        # compromised.
        return False
    return value in _DISABLED_VALUES


def _normalize_config(config: Any) -> dict:
    """Coerce arbitrary input into a plain dict.

    Accepts: dict, None, arbitrary non-dict (silently discarded with
    a debug breadcrumb). Returns a fresh dict instance — the caller
    can mutate it without affecting the user's original.
    """
    if config is None:
        return {}
    if isinstance(config, dict):
        try:
            return dict(config)
        except Exception:
            # Dict subclass with broken __iter__ / __getitem__. Very
            # rare, but observed in the wild with proxy-dict classes.
            return {}
    try:
        logger.debug(
            "AgentSonar: config must be a dict, got %s; falling back to defaults",
            type(config).__name__,
        )
    except Exception:
        pass
    return {}


def build_engine_safely(config: Any) -> Any:
    """Construct a `DetectionEngine`, never raising to the caller.

    Returns a real `DetectionEngine` on success or a `_NoOpEngine`
    on any failure. Logs a warning on failure so users running under
    `logging.getLogger("agentsonar").setLevel(logging.WARNING)` see
    the degradation without having to call `get_summary()`.

    Use this in every integration `__init__`. Never call
    `DetectionEngine(config)` directly from the integration layer.

    Host-safety contract:
      * This function NEVER raises. Period. Any exception anywhere
        inside it (including in the logger itself) is caught and
        swallowed in favor of returning a `_NoOpEngine`.
      * Setting `AGENTSONAR_DISABLED=1` short-circuits the entire
        function and returns a `_NoOpEngine` without even importing
        the real engine module — cheapest possible kill switch.
    """
    # Wrap the ENTIRE body in an outer try/except as the final
    # safety net. _normalize_config, the logger, and the env var
    # check are all "should never fail" paths — but this function
    # sits on the host-safety critical path and the cost of an
    # extra try/except is negligible next to the value of an
    # absolute "never raises" guarantee.
    try:
        # Kill switch — cheap and explicit, runs before any imports
        # or real work. Users who want to disable AgentSonar in
        # production just set the env var; no code change needed.
        if _is_disabled_by_env():
            try:
                logger.info(
                    "AgentSonar disabled via AGENTSONAR_DISABLED env var; "
                    "running in no-op mode for this session."
                )
            except Exception:
                pass
            return _NoOpEngine(reason="disabled via AGENTSONAR_DISABLED env var")

        safe_config = _normalize_config(config)
        try:
            # Lazy import avoids a hard dependency cycle between
            # `_integrations` and `_core` at module load time AND
            # keeps networkx out of the import path until it's
            # actually needed. If networkx is missing (broken
            # install), this import raises ImportError and we
            # degrade cleanly instead of crashing the host at
            # `from agentsonar import monitor`.
            from agentsonar._core.engine import DetectionEngine

            return DetectionEngine(safe_config)
        except Exception as exc:
            try:
                logger.warning(
                    "AgentSonar failed to initialize detection engine "
                    "(%s: %s). Running in degraded (no-op) mode — your "
                    "application will continue normally but AgentSonar "
                    "will not detect any coordination failures for this "
                    "run.",
                    type(exc).__name__,
                    exc,
                )
                logger.debug(
                    "AgentSonar engine initialization traceback:",
                    exc_info=True,
                )
            except Exception:
                # Even the warning logger failed. Silently continue.
                pass
            return _NoOpEngine(reason=f"{type(exc).__name__}: {exc}")
    except Exception:
        # Catastrophic failure of the safety layer itself (the
        # normalize/env/logger path threw unexpectedly). Return
        # the safest possible thing we can construct, without
        # calling anything else.
        try:
            return _NoOpEngine(reason="safe-construct outer safety net fired")
        except Exception:
            # _NoOpEngine construction itself failed? Return a
            # last-resort shell object with just enough surface to
            # keep integrations from AttributeError'ing. This
            # branch is unreachable in practice — _NoOpEngine has
            # no code that can fail — but we keep it as the
            # absolute-last-line-of-defense.
            return _LastResortEngine()


class _LastResortEngine:
    """Absolute last-line-of-defense engine stub.

    Used only if `_NoOpEngine()` construction itself raises —
    which means something is deeply broken in the runtime
    (corrupted Python install, missing `uuid` module, etc.). Has
    just enough attributes to prevent `AttributeError` crashes
    from bubbling into the host, with no imports and no logic.

    This class exists as a theoretical backstop. Regression tests
    never exercise it because `_NoOpEngine` construction is
    infallible in practice.
    """

    session_id = "disabled"
    logger: Any = None
    iteration_count = 0
    _shutdown_requested = True

    def ingest(self, *_a: Any, **_k: Any) -> list:
        return []

    def increment_iteration(self) -> None:
        pass

    def get_summary(self) -> dict:
        return {
            "total_events": 0, "iteration_count": 0, "edge_counts": {},
            "total_estimated_token_waste": 0, "alerts_raised": 0,
            "alerts": [], "degraded": True,
            "degraded_reason": "last-resort fallback",
        }

    def get_recent_events(self) -> list:
        return []

    def should_prevent(self) -> Any:
        return None

    def check_prevent(self) -> Any:
        return None

    def shutdown(self) -> None:
        pass
