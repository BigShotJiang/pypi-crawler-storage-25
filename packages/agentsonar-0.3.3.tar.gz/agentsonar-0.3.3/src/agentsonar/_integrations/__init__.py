"""
AgentSonar framework integrations — internal.

These modules contain the framework-specific adapters. Each one imports
its framework (crewai, langchain-core) conditionally so the package is
importable without them installed. Users get a helpful RuntimeError if
they try to instantiate the adapter without the required framework.
"""
