"""
langgraph_prevent_mode_demo.py -- the "reviewer never approves"
infinite loop in LangGraph, caught by Prevent Mode.

Same scenario as `langgraph_reviewer_insufficient_loop.py` (LangGraph
issue #6731) but with Prevent Mode wired in. Without prevent, the graph
spins until LangGraph's `recursion_limit` raises `GraphRecursionError`.
With prevent on, AgentSonar trips at CRITICAL severity and the
orchestrator's `try/except PreventError` block catches it cleanly.

The scenario
============
A common LangGraph writing pipeline:

    researcher -> writer -> reviewer -> (back to researcher | END)

The reviewer routes BACK to the researcher whenever it judges the
output "insufficient." For this demo the reviewer is hardcoded
to always return "REVISION REQUIRED" (no LLM, runs in <1s).

What Prevent Mode does
======================
The graph has NO rotation cap and NO recursion_limit hack. With:

    monitor(graph, config={"prevent": {"cyclic_delegation": True}})

AgentSonar raises `PreventError` the moment the cycle reaches
CRITICAL severity (default: 15 rotations). The user's
`try/except PreventError` catches it and `graph.invoke()` returns
control to the host.

Notice what is NOT in the orchestrator below:
  * No rotation counter on the State.
  * No `if rotations > N: return END`.
  * No `recursion_limit` set artificially low to avoid burning tokens.

Run:
    uv run python examples/langgraph_prevent_mode_demo.py
"""
from __future__ import annotations

import operator
from typing import Literal

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

from agentsonar import PreventError, monitor


class State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]


def researcher(state: State):
    """Stand-in for an LLM that does another round of digging."""
    return {"messages": [AIMessage(content="additional research findings")]}


def writer(state: State):
    """Stand-in for a writer drafting a section from the research."""
    return {"messages": [AIMessage(content="draft section v2")]}


def reviewer(state: State):
    """The problem agent. Hardcoded to always demand revision so the
    cycle reproduces deterministically without LLM calls.
    """
    return {"messages": [AIMessage(content="REVISION REQUIRED: depth insufficient")]}


def quality_gate(state: State) -> Literal["researcher"]:
    """Conditional routing -- reviewer to (researcher | END).

    We never return END. The graph would loop forever without
    Prevent Mode.
    """
    return "researcher"


def main() -> None:
    print("=" * 72)
    print("LANGGRAPH PREVENT MODE DEMO -- reviewer never approves")
    print("=" * 72)
    print()
    print("Three-node cycle: researcher -> writer -> reviewer -> researcher.")
    print("Reviewer is hardcoded to always say 'REVISION REQUIRED'.")
    print("Without Prevent Mode this graph runs until recursion_limit hits.")
    print()

    builder = StateGraph(State)
    builder.add_node("researcher", researcher)
    builder.add_node("writer", writer)
    builder.add_node("reviewer", reviewer)
    builder.add_edge(START, "researcher")
    builder.add_edge("researcher", "writer")
    builder.add_edge("writer", "reviewer")
    builder.add_conditional_edges("reviewer", quality_gate)
    graph = builder.compile()

    # The ONLY change from a regular monitor() setup:
    #     prevent={"cyclic_delegation": True}
    monitored = monitor(graph, config={
        "console_output": False,    # quiet -- demo prints its own summary
        "warning_threshold": 5,
        "critical_threshold": 15,
        "prevent": {"cyclic_delegation": True},
    })

    caught: PreventError | None = None
    try:
        # No artificial recursion_limit dropped low -- if Prevent Mode
        # works, the trip happens long before this is reached.
        monitored.invoke(
            {"messages": [HumanMessage(content="write a research article")]},
            config={"recursion_limit": 200},
        )
    except PreventError as e:
        caught = e

    monitored.shutdown()

    print("-" * 72)
    print("OUTCOME")
    print("-" * 72)
    if caught is None:
        print("  Loop exited via END or recursion_limit. Prevent Mode did")
        print("  not trip -- this is unexpected for the hardcoded fake-LLM")
        print("  in this demo.")
        return

    print(f"  Loop terminated by:    PreventError")
    print(f"  failure_class:         {caught.failure_class}")
    print(f"  severity:              {caught.severity}")
    print(f"  rotations at trip:     {caught.rotations}")
    print(f"  cycle path:            {' -> '.join(caught.cycle_path)}")
    print(f"  reason:                {caught.reason}")
    print()
    print("Without Prevent Mode this graph would have looped until")
    print("recursion_limit raised GraphRecursionError -- a cryptic ceiling")
    print("with no signal about WHICH cycle was hot. AgentSonar caught it")
    print(f"after {caught.rotations} rotations of the same cycle.")


if __name__ == "__main__":
    main()
