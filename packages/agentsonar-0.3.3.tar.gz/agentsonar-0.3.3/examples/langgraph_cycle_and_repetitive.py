"""
langgraph_cycle_and_repetitive.py

LangGraph scenario demonstrating TWO distinct failure classes in one run:

    A -> B -> C -> A   (16 rotations, cyclic_delegation)
    A -> D -> E -> F -> G   (linear escape path)
    F -> G x 15        (repetitive_delegation — G hammered)

Phase 1 is a classic 3-node cycle: planner -> researcher -> reviewer that
loops back 16 times. Triggers Layer 3 (CycleDetector) + Layer 4
(AlertStateManager) all the way to CRITICAL (critical_threshold=15).

Phase 2 escapes the cycle: planner -> delegator -> executor -> validator ->
worker -> END. Each edge in this chain fires exactly once.

Phase 3 (post-graph) hammers the F->G edge WITHOUT creating a micro-cycle
between them. LangGraph can't route back-and-forth on a node without an
intermediate node, and any back-edge would create an F<->G cycle that
inhibits the repetitive signal in the summary view. To avoid that,
Phase 3 runs OUTSIDE the LangGraph callback — we feed InteractionEvent
objects directly into `sonar.engine` via `sonar.engine.ingest()`. No
G->F edge is ever created, so there's no cycle on {F, G} and the
REPETITIVE_DELEGATION alert survives the summary view's inhibition rule.

NO LLM CALLS — all nodes return deterministic responses. Runs in under
a second.

Requires the `langgraph` extra:
    pip install agentsonar[langgraph]

Run:
    uv run python examples/langgraph_cycle_and_repetitive.py
    uv run python examples/langgraph_cycle_and_repetitive.py 20 18
      (first arg = max cycle rotations, second arg = G hammer count)
"""
from __future__ import annotations

import operator
import sys
import time
from typing import Literal

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

# Public API — the 2-line promise
from agentsonar import AgentSonarCallback

# The hammer phase needs InteractionEvent and access to the underlying
# engine. InteractionEvent is an internal API (underscore-prefixed
# subpackage) — not part of the stable public surface but exposed for
# custom usage when you need to inject events outside the normal
# framework flow.
from agentsonar._core.models import InteractionEvent


# ============================================================
# STATE
# ============================================================

class FlowState(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    cycle_rotations: int
    max_cycle_rotations: int
    phase: str  # "cycle" or "linear"


# ============================================================
# DETERMINISTIC NODE FUNCTIONS (no LLM calls)
# ============================================================
# Phase 1 nodes — the cycle {A, B, C}

def planner_node(state: FlowState):
    """Agent A: plans work. Branches into cycle OR linear path based on phase."""
    rotations = state["cycle_rotations"]
    return {
        "messages": [AIMessage(content=f"[Plan v{rotations + 1}] Coordinate the crew.")],
    }


def researcher_node(state: FlowState):
    """Agent B: gathers information."""
    return {
        "messages": [AIMessage(content=f"[Research v{state['cycle_rotations'] + 1}] Collected 3 sources.")],
    }


def reviewer_node(state: FlowState):
    """Agent C: reviews research; closes the cycle by incrementing rotations."""
    next_count = state["cycle_rotations"] + 1
    return {
        "messages": [AIMessage(content=f"[Review v{next_count}] REVISE: more depth needed.")],
        "cycle_rotations": next_count,
    }


# Phase 2 nodes — the linear escape path {D, E, F, G}

def delegator_node(state: FlowState):
    """Agent D: dispatches the task after the cycle exits."""
    return {
        "messages": [AIMessage(content="[Delegator] Routing to executor.")],
        "phase": "linear",
    }


def executor_node(state: FlowState):
    """Agent E: executes the plan."""
    return {
        "messages": [AIMessage(content="[Executor] Running task.")],
    }


def validator_node(state: FlowState):
    """Agent F: validates the output before handing off to the worker."""
    return {
        "messages": [AIMessage(content="[Validator] Output validated.")],
    }


def worker_node(state: FlowState):
    """Agent G: the final worker that completes the task."""
    return {
        "messages": [AIMessage(content="[Worker] Task complete.")],
    }


# ============================================================
# ROUTING
# ============================================================

def after_planner(state: FlowState) -> Literal["researcher_node", "delegator_node"]:
    """A routes to B (cycle) OR D (linear) depending on whether we've
    completed the target number of rotations."""
    if state["cycle_rotations"] >= state["max_cycle_rotations"]:
        return "delegator_node"
    return "researcher_node"


def after_reviewer(state: FlowState) -> Literal["planner_node"]:
    """C always loops back to A. The 'exit the cycle' decision happens at
    the planner node via after_planner — this keeps the cycle visible
    (C -> A is a real edge in the coordination graph) until planner sees
    the counter and takes the other branch."""
    return "planner_node"


# ============================================================
# BUILD GRAPH
# ============================================================

def build_graph():
    builder = StateGraph(FlowState)
    builder.add_node("planner_node", planner_node)
    builder.add_node("researcher_node", researcher_node)
    builder.add_node("reviewer_node", reviewer_node)
    builder.add_node("delegator_node", delegator_node)
    builder.add_node("executor_node", executor_node)
    builder.add_node("validator_node", validator_node)
    builder.add_node("worker_node", worker_node)

    builder.add_edge(START, "planner_node")
    builder.add_conditional_edges("planner_node", after_planner)
    builder.add_edge("researcher_node", "reviewer_node")
    builder.add_conditional_edges("reviewer_node", after_reviewer)
    builder.add_edge("delegator_node", "executor_node")
    builder.add_edge("executor_node", "validator_node")
    builder.add_edge("validator_node", "worker_node")
    builder.add_edge("worker_node", END)
    return builder.compile()


# ============================================================
# RUN
# ============================================================

def main() -> None:
    max_cycle_rotations = 16
    hammer_count = 15  # extra F->G events fed directly into the engine

    if len(sys.argv) > 1:
        try:
            max_cycle_rotations = int(sys.argv[1])
        except ValueError:
            print("Usage: langgraph_cycle_and_repetitive.py [cycles] [hammers]")
            sys.exit(1)
    if len(sys.argv) > 2:
        try:
            hammer_count = int(sys.argv[2])
        except ValueError:
            print("Usage: langgraph_cycle_and_repetitive.py [cycles] [hammers]")
            sys.exit(1)

    print("=" * 70)
    print("LANGGRAPH: CYCLE + REPETITIVE")
    print(f"Phase 1: planner -> researcher -> reviewer -> planner x {max_cycle_rotations}")
    print(f"Phase 2: planner -> delegator -> executor -> validator -> worker")
    print(f"Phase 3: validator -> worker x {hammer_count} (direct engine ingest)")
    print("No LLM calls — deterministic responses for fast execution")
    print("=" * 70)

    graph = build_graph()

    # The two-line promise:
    #
    #     from agentsonar import AgentSonarCallback
    #     result = graph.invoke(input, config={"callbacks": [AgentSonarCallback()]})
    #
    # This example passes a `config` dict ONLY to disable Layer 1's rate
    # limiter (which would otherwise trip during the post-graph hammer
    # phase before Layer 2's hard_weight_limit fires). File logging and
    # stderr output run with their defaults, so running the example
    # produces `agentsonar_*.log` files in the current working directory
    # — that's the out-of-the-box behavior real users get.
    sonar = AgentSonarCallback(config={
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })

    initial_state = {
        "messages": [HumanMessage(content="Demonstrate cycle and repetitive patterns")],
        "cycle_rotations": 0,
        "max_cycle_rotations": max_cycle_rotations,
        "phase": "cycle",
    }

    # ------------------------------------------------------------
    # Phase 1 + 2: Run the graph (cycle then linear escape)
    # ------------------------------------------------------------
    print("\n--- Execution (Phases 1 + 2) ---\n")
    start_time = time.time()

    for step in graph.stream(
        initial_state,
        stream_mode="updates",
        # LangGraph's default recursion limit of 25 isn't enough for a
        # 16-rotation 3-node cycle (48 node visits). Bump it so the graph
        # doesn't bail out mid-cycle.
        config={"callbacks": [sonar], "recursion_limit": max_cycle_rotations * 10},
    ):
        for node_name, update in step.items():
            msgs = update.get("messages", [])
            if msgs:
                content = msgs[-1].content[:80]
                rotations = update.get("cycle_rotations", "")
                marker = f"[rot {rotations}]" if rotations != "" else "         "
                print(f"  {marker} {node_name:<20s} | {content}")

    elapsed_graph = time.time() - start_time

    # ------------------------------------------------------------
    # Phase 3: Hammer F->G directly through the engine
    # ------------------------------------------------------------
    print(f"\n--- Execution (Phase 3: hammer validator -> worker) ---\n")
    hammer_start = time.time()
    base_ts = time.time()
    for i in range(hammer_count):
        ev = InteractionEvent(
            source_agent="validator_node",
            target_agent="worker_node",
            timestamp=base_ts + i * 0.01,
        )
        sonar.engine.ingest(ev)
        if (i + 1) % 5 == 0:
            print(f"  [hammer #{i + 1:2d}] validator_node -> worker_node")
    elapsed_hammer = time.time() - hammer_start
    elapsed = time.time() - start_time

    # ============================================================
    # RESULTS
    # ============================================================
    print("\n" + "=" * 70)
    print("DETECTION RESULTS")
    print("=" * 70)

    summary = sonar.get_summary()

    print(f"\n  Total execution:   {elapsed:.2f}s")
    print(f"    Graph phase:     {elapsed_graph:.2f}s")
    print(f"    Hammer phase:    {elapsed_hammer:.2f}s")
    print(f"  Total events:      {summary['total_events']}")
    print(f"  Total alerts:      {summary['alerts_raised']}")

    print(f"\n  Edge counts:")
    for edge, count in sorted(summary["edge_counts"].items(), key=lambda x: -x[1]):
        print(f"    {edge}: {count}x")

    if summary["alerts"]:
        print(f"\n  Alerts fired ({len(summary['alerts'])}):")
        for i, alert in enumerate(summary["alerts"], 1):
            pattern = alert["pattern"]
            severity = alert["severity"]
            details = alert["details"]

            if pattern == "cycle":
                layer = "Layer 3 (CycleDetector) -> Layer 4"
            elif pattern == "edge_anomaly":
                layer = "Layer 2 (ExponentialDecayDetector) -> Layer 4"
            elif pattern == "scc_cycle":
                layer = "Layer 5 (PeriodicSCCAnalyzer) -> Layer 4"
            elif pattern in ("rate_limit_exceeded", "global_rate_exceeded"):
                layer = "Layer 1 (SlidingWindowLimiter)"
            else:
                layer = f"Unknown ({pattern})"

            print(f"\n  Alert #{i}:")
            print(f"    Layer:     {layer}")
            print(f"    Severity:  {severity}")
            print(f"    Pattern:   {pattern}")
            if "cycle_path" in details:
                path = details["cycle_path"]
                print(f"    Cycle:     {' -> '.join(path)} -> {path[0]}")
            if "source" in details and "target" in details:
                print(f"    Edge:      {details['source']} -> {details['target']}")
            if "rotations" in details and details["rotations"]:
                print(f"    Rotations: {details['rotations']}")
            if "event_count" in details:
                print(f"    Events:    {details['event_count']}")
    else:
        print(f"\n  No alerts fired! Check detection thresholds.")

    # Failure-class coverage from the structured CoordinationEvents
    events = sonar.engine.get_recent_events()
    cyclic = [e for e in events if e.failure_class.value == "cyclic_delegation"]
    repetitive = [e for e in events if e.failure_class.value == "repetitive_delegation"]

    print(f"\n  --- Failure Class Coverage ---")
    print(f"    cyclic_delegation:     "
          f"{'FIRED (' + str(len(cyclic)) + ' events)' if cyclic else 'not triggered'}")
    print(f"    repetitive_delegation: "
          f"{'FIRED (' + str(len(repetitive)) + ' events)' if repetitive else 'not triggered'}")

    if cyclic:
        ev = cyclic[-1]
        print(f"\n    Latest cyclic event:")
        print(f"      severity:  {ev.severity.value}")
        print(f"      summary:   {ev.summary}")

    if repetitive:
        ev = repetitive[-1]
        print(f"\n    Latest repetitive event:")
        print(f"      severity:  {ev.severity.value}")
        print(f"      summary:   {ev.summary}")

    # sonar.shutdown() auto-writes the JSON + HTML reports to cwd.
    # (auto_export_on_shutdown is True by default.) If you need the raw
    # chronological timeline view instead of the summary, call
    # export_json(events, dedupe=False) explicitly before shutdown —
    # see examples/warning_and_critical.py for a full-timeline example.
    print(f"\n  Structured events: {len(events)}")
    print(f"  (JSON + HTML reports will be written by sonar.shutdown())")
    print("=" * 70)

    sonar.shutdown()


if __name__ == "__main__":
    main()
