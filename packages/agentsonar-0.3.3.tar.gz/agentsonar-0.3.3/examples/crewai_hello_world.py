"""
crewai_hello_world.py

Minimal CrewAI integration example. Shows the 2-line AgentSonar setup
for a CrewAI crew — a manager agent that delegates to a researcher and
a writer via hierarchical process.

This example RUNS a real crew, which means it makes actual LLM calls.
You'll need:
  1. pip install agentsonar[crewai]
  2. OPENAI_API_KEY set in your environment (or configure a different LLM
     — see https://docs.crewai.com/concepts/llms)

The crew isn't pathological by design — it's a simple delegation flow
that should finish cleanly with minimal AgentSonar alerts. The point is
to show the integration pattern, not to trigger detection.

For a pathological scenario that DOES trigger cycle + repetitive
detection without any LLM calls, see `langgraph_cycle_and_repetitive.py`.

Run:
    export OPENAI_API_KEY=sk-...
    uv run python examples/crewai_hello_world.py
"""
from __future__ import annotations

import os
import sys

# The 2-line promise for CrewAI:
#
#     from agentsonar import AgentSonarListener
#     sonar = AgentSonarListener()
#     # ...run your crew normally. Detection happens automatically.
#
# That's it. Just instantiating the listener wires it into CrewAI's
# event bus — the listener observes delegations, runs them through the
# 5-layer detection pipeline, and streams alerts to stderr + log files.
from agentsonar import AgentSonarListener


def main() -> None:
    # Bail out early if CrewAI isn't installed. Instantiating
    # AgentSonarListener below would also fail with a friendly message,
    # but this check lets us show BOTH missing pieces (crewai AND the
    # API key) at once instead of making the user fix one, rerun, and
    # discover the next.
    try:
        from crewai import Agent, Crew, Process, Task
    except ImportError:
        print(
            "CrewAI is not installed. Run:\n"
            "    pip install agentsonar[crewai]\n"
            "and set OPENAI_API_KEY (or configure another LLM provider).",
            file=sys.stderr,
        )
        sys.exit(1)

    if not os.getenv("OPENAI_API_KEY"):
        print(
            "OPENAI_API_KEY is not set. This example runs a real CrewAI "
            "crew, which makes LLM calls. Set the env var or configure "
            "another provider before running.\n"
            "    export OPENAI_API_KEY=sk-...\n"
            "See https://docs.crewai.com/concepts/llms for alternatives.",
            file=sys.stderr,
        )
        sys.exit(1)

    print("=" * 60)
    print("CREWAI HELLO WORLD (with AgentSonar monitoring)")
    print("=" * 60)

    # ================== THE 2 LINES ==================
    sonar = AgentSonarListener()
    # =================================================
    #
    # That's the entire integration. Everything below this point is
    # your normal CrewAI code — unchanged by AgentSonar.

    researcher = Agent(
        role="Researcher",
        goal="Gather concise information about the given topic.",
        backstory="A senior researcher who cites sources and stays focused.",
        allow_delegation=False,
        verbose=False,
    )

    writer = Agent(
        role="Writer",
        goal="Write a short, clear summary from the researcher's findings.",
        backstory="A precise technical writer who keeps summaries tight.",
        allow_delegation=False,
        verbose=False,
    )

    manager = Agent(
        role="Manager",
        goal="Coordinate the researcher and writer to produce a short article.",
        backstory="A project manager who delegates work and reviews results.",
        allow_delegation=True,
        verbose=False,
    )

    task = Task(
        description=(
            "Write a 3-sentence summary of how multi-agent AI systems "
            "coordinate. Delegate research to the Researcher, then "
            "delegate writing to the Writer."
        ),
        expected_output="A 3-sentence summary.",
        agent=manager,
    )

    # CrewAI requires the manager agent to be passed via
    # `manager_agent` ONLY — it must NOT also appear in the `agents`
    # list (newer CrewAI versions enforce this at validation time).
    crew = Crew(
        agents=[researcher, writer],
        tasks=[task],
        process=Process.hierarchical,
        manager_agent=manager,
        verbose=False,
    )

    print("\n--- Running crew (this makes real LLM calls) ---\n")
    result = crew.kickoff()

    print("\n--- Crew result ---")
    print(result)

    # AgentSonarListener auto-shuts down on CrewKickoffCompletedEvent —
    # the listener's setup_listeners() hooks that event to close the
    # logger and print the summary banner. Nothing else needed from you.


if __name__ == "__main__":
    main()
