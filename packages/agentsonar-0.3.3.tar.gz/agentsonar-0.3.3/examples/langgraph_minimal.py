"""
langgraph_minimal.py — the shortest possible AgentSonar LangGraph setup.

This example is intentionally bare-bones. It matches EXACTLY what the
README's 2-line promise shows: no custom prints, no get_summary() call,
no manual result inspection, no explicit export_json/export_html calls.
Just `monitor()` the graph, invoke it, call shutdown, and see what
AgentSonar gives you out of the box:

  * Live colored alerts streamed to stderr as the graph runs
  * JSONL timeline file:     agentsonar_{ts}.log
  * Human-readable alerts:   agentsonar_alerts_{ts}.log
  * Structured JSON report:  agentsonar_report_{ts}.json
  * Standalone HTML report:  agentsonar_report_{ts}.html

All five outputs are produced automatically on shutdown(). Zero extra
code from this example — what you see is what every user gets.

This example uses the `monitor()` wrapper rather than passing
`AgentSonarCallback()` directly. Both are part of the public API; we
chose monitor() here because it's the recommended path for users who
already pass their own callbacks to graph.invoke() — it auto-merges
AgentSonar without overriding whatever you had.

Requires: pip install agentsonar[langgraph]

Run:
    uv run python examples/langgraph_minimal.py
"""
from __future__ import annotations

import operator
from typing import Literal

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

# ============================================================
# THE PUBLIC API — this is the entire AgentSonar integration.
# ============================================================
from agentsonar import monitor


# ============================================================
# A tiny 3-node LangGraph with a deliberate cycle
# ============================================================
# planner -> researcher -> reviewer -> (back to planner or END)
#
# The reviewer always rejects, so the graph loops until it hits the
# recursion limit. That's enough to trip AgentSonar's cycle detector.

class State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    iteration: int


def planner(state: State):
    return {"messages": [AIMessage(content="Plan the work")]}


def researcher(state: State):
    return {"messages": [AIMessage(content="Research findings")]}


def reviewer(state: State):
    return {
        "messages": [AIMessage(content="REVISE: not enough depth")],
        "iteration": state.get("iteration", 0) + 1,
    }


def after_reviewer(state: State) -> Literal["planner", "__end__"]:
    # Loop 8 times. That's enough to cross the WARNING threshold
    # (5 rotations) so users see AgentSonar fire, but not so many that
    # we trip Layer 1's rate-limit circuit breaker (default 10 per
    # edge per window). The goal of this example is to show CLEAN
    # default output, not flood stderr.
    if state.get("iteration", 0) >= 8:
        return END
    return "planner"


builder = StateGraph(State)
builder.add_node("planner", planner)
builder.add_node("researcher", researcher)
builder.add_node("reviewer", reviewer)
builder.add_edge(START, "planner")
builder.add_edge("planner", "researcher")
builder.add_edge("researcher", "reviewer")
builder.add_conditional_edges("reviewer", after_reviewer)
graph = builder.compile()


if __name__ == "__main__":
    # ─── AgentSonar: the entire integration, right here ───────────
    graph = monitor(graph)
    # ──────────────────────────────────────────────────────────────
    #
    # That's it. `monitor()` wraps the compiled graph so every
    # graph.invoke(...) auto-injects AgentSonar's callback, merging
    # with any callbacks the user passes rather than overriding them.
    #
    # Equivalent "direct callback" form:
    #
    #     from agentsonar import AgentSonarCallback
    #     sonar = AgentSonarCallback()
    #     graph.invoke(state, config={"callbacks": [sonar]})
    #
    # Use monitor() if you already have your own callbacks and want
    # them preserved automatically. Use AgentSonarCallback() directly
    # if you want explicit control over callback ordering.

    # Run your graph normally. Everything below is plain LangGraph.
    graph.invoke(
        {"messages": [HumanMessage(content="Coordinate the crew")], "iteration": 0},
        # LangGraph's default recursion limit is 25; 8 loop iterations
        # × 3 nodes = 24 hops + start, so bump it.
        config={"recursion_limit": 50},
    )

    # shutdown() does two things:
    #   1. Prints the boxed summary banner on stderr.
    #   2. Auto-writes the JSON + HTML reports to cwd.
    # Both the log files AND the structured reports come out of this
    # one call — zero extra code for the example.
    graph.shutdown()
