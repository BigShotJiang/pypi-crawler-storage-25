"""
crewai_clean_sequential.py — a CrewAI workload with ZERO
coordination failures.

Simple sequential (non-hierarchical) crew:

    Researcher → Writer  (each runs exactly once, in order)

No hierarchical manager, no `allow_delegation=True`, no loops.
AgentSonar should run quietly and report:

  * stderr        — a green "✓ No coordination failures detected —
                    clean run." line under the summary banner
  * timeline.jsonl — the final `session_end` record with
                    `"clean_run": true`, `"warning_count": 0`,
                    `"critical_count": 0`
  * report.html   — a green "No coordination failures detected"
                    banner replacing the event cards
  * report.json   — an empty events array (nothing to report)

Use this example as a control case when you're integrating
AgentSonar into a new CrewAI project and want to verify the wiring
is correct without expecting any alerts. If you see ANY alerts
from this script, something's misconfigured.

The contrast with `crewai_delegation_ping_pong.py` is deliberate:
  * ping_pong uses Process.hierarchical + allow_delegation=True
    and a deliberately ambiguous task — triggers alerts.
  * this file uses Process.sequential + allow_delegation=False
    and a concrete terminating task — clean run.

Running this example
====================
You'll need:
  1. pip install agentsonar[crewai]
  2. OPENAI_API_KEY in your environment (or configure a different
     LLM — see https://docs.crewai.com/concepts/llms)

Cost estimate: ~$0.02-$0.05 in GPT-4 tokens (this is a single
two-agent sequential crew, much cheaper than the ping-pong example).

Run:
    export OPENAI_API_KEY=sk-...
    uv run python examples/crewai_clean_sequential.py
"""
from __future__ import annotations

import os
import sys

# The 2 lines that wire AgentSonar into CrewAI:
from agentsonar import AgentSonarListener


def main() -> None:
    try:
        from crewai import Agent, Crew, LLM, Process, Task
    except ImportError:
        print(
            "CrewAI is not installed. Run:\n"
            "    pip install agentsonar[crewai]\n"
            "and set OPENAI_API_KEY (or configure another LLM provider).",
            file=sys.stderr,
        )
        sys.exit(1)

    if not os.getenv("OPENAI_API_KEY"):
        print(
            "OPENAI_API_KEY is not set. This example runs a real CrewAI "
            "crew, which makes LLM calls. Set the env var or configure "
            "another provider before running.\n"
            "    export OPENAI_API_KEY=sk-...\n"
            "See https://docs.crewai.com/concepts/llms for alternatives.",
            file=sys.stderr,
        )
        sys.exit(1)

    print("=" * 60)
    print("CREWAI CLEAN SEQUENTIAL (with AgentSonar monitoring)")
    print("=" * 60)
    print()
    print("Running a real CrewAI sequential crew with a concrete task.")
    print("Expected: AgentSonar reports a clean run with no alerts.")
    print()

    # ================== THE 2 LINES ==================
    sonar = AgentSonarListener()
    # =================================================

    # Pin the LLM to gpt-4o-mini for consistent, cheap runs.
    # Swap for a different model if you prefer — any model that
    # supports function calling will work here.
    llm = LLM(model="gpt-4o-mini", temperature=0.2)

    researcher = Agent(
        role="Researcher",
        goal=(
            "Collect three concrete facts about the assigned topic "
            "and return them in a clear list."
        ),
        backstory=(
            "A pragmatic researcher who finds the shortest path to "
            "useful information and returns cleanly."
        ),
        llm=llm,
        allow_delegation=False,
        verbose=False,
    )

    writer = Agent(
        role="Writer",
        goal=(
            "Take the researcher's three facts and turn them into "
            "a one-paragraph summary. Do not ask for clarification; "
            "work with what you're given."
        ),
        backstory=(
            "A disciplined technical writer who accepts incoming "
            "research and produces clean prose on the first pass."
        ),
        llm=llm,
        allow_delegation=False,
        verbose=False,
    )

    # Concrete, terminating task — each agent runs exactly once.
    research_task = Task(
        description=(
            "Gather three concrete facts about the programming "
            "language Python (e.g. its creator, year of release, "
            "licensing). Return them as a short bulleted list."
        ),
        expected_output="A bulleted list of exactly three facts about Python.",
        agent=researcher,
    )

    writing_task = Task(
        description=(
            "Take the three facts from the previous task and compose "
            "a single-paragraph summary (3-4 sentences)."
        ),
        expected_output="A single paragraph summarizing the three facts.",
        agent=writer,
        context=[research_task],
    )

    crew = Crew(
        agents=[researcher, writer],
        tasks=[research_task, writing_task],
        # Sequential process — tasks run in order, no delegation
        process=Process.sequential,
        verbose=False,
    )

    print("--- Running crew (this makes real LLM calls) ---\n")
    result = crew.kickoff()

    print("\n--- Crew result ---")
    print(result)

    # AgentSonarListener auto-shuts down on CrewKickoffCompletedEvent.
    # On a clean run you'll see the green "No coordination failures
    # detected — clean run." line in the summary banner above.
    # The HTML report will show a green banner instead of event cards.


if __name__ == "__main__":
    main()
