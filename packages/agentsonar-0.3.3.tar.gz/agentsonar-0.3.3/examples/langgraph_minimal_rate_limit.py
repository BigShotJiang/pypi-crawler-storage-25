"""
langgraph_minimal_rate_limit.py — resource exhaustion in minimal style.

Like langgraph_minimal.py but triggers Layer 1 (SlidingWindowLimiter),
the circuit-breaker that detects per-edge rate limit violations:

  * resource_exhaustion (rate_limit_exceeded)

How: a tiny linear `A -> B` graph (no cycle, no return edge) invoked
in a loop. Each invocation feeds one A->B event to the engine. With
per_edge_limit=5 configured, the 6th invocation trips the circuit
breaker and AgentSonar fires a CRITICAL alert.

This pattern — invoking a linear graph repeatedly — is the cleanest
way to burst events on the SAME edge without creating a cycle. In real
code, the same thing happens when the graph's input is streamed or
when a retry loop re-invokes the same step.

Zero custom print statements, zero explicit export calls. The default
output behavior (stderr alerts, two log files, JSON + HTML reports on
shutdown) is the entire observability story.

Requires: pip install agentsonar[langgraph]

Run:
    uv run python examples/langgraph_minimal_rate_limit.py
"""
from __future__ import annotations

import operator
from typing import Literal

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

# ============================================================
# THE PUBLIC API — monitor() is the entire AgentSonar integration.
# ============================================================
from agentsonar import monitor


# ============================================================
# State + 2-node linear graph A -> B -> END
# ============================================================

class State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]


def node_a(state: State):
    return {"messages": [AIMessage(content="A: dispatching")]}


def node_b(state: State):
    return {"messages": [AIMessage(content="B: receiving")]}


builder = StateGraph(State)
builder.add_node("A", node_a)
builder.add_node("B", node_b)
builder.add_edge(START, "A")
builder.add_edge("A", "B")
builder.add_edge("B", END)
graph = builder.compile()


if __name__ == "__main__":
    # Configure a low per-edge rate limit so the circuit breaker fires
    # within a few invocations. In a real app you'd leave these at
    # their defaults (per_edge_limit=10, global_limit=200, window=180s)
    # — this example uses a tighter limit so the demo doesn't need
    # hundreds of invocations to show rate limiting in action.
    graph = monitor(graph, config={
        "per_edge_limit": 5,
        "window_size": 60.0,
    })

    # Invoke 7 times. Each call feeds one A -> B event to the engine
    # (callback resets `previous_node` between invocations, so there's
    # no phantom B -> A edge in between). The 6th invocation trips
    # per_edge_limit=5 and fires CRITICAL resource_exhaustion.
    for i in range(7):
        graph.invoke({"messages": [HumanMessage(content=f"run {i+1}")]})

    graph.shutdown()
