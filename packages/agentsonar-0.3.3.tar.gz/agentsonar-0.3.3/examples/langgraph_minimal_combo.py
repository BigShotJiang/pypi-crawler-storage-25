"""
langgraph_minimal_combo.py — cycle + repetitive in minimal style.

Like langgraph_minimal.py but triggers BOTH of AgentSonar's main failure
classes in the same run:
  * cyclic_delegation     — planner -> researcher -> reviewer -> planner
  * repetitive_delegation — validator -> worker (hot one-directional edge)

Zero custom print statements, zero explicit export calls. Just
  monitor(graph) -> invoke -> optional direct-ingest hammer -> shutdown

and AgentSonar handles the rest: stderr alerts, two log files, JSON
report, and HTML report — all five outputs generated automatically.

Requires: pip install agentsonar[langgraph]

Run:
    uv run python examples/langgraph_minimal_combo.py
"""
from __future__ import annotations

import operator
import time
from typing import Literal

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

# ============================================================
# THE PUBLIC API — monitor() is the entire AgentSonar integration.
# ============================================================
from agentsonar import monitor

# InteractionEvent is an internal API used only for the post-graph
# hammer phase — see the comment below for why we reach for it.
from agentsonar._core.models import InteractionEvent


# ============================================================
# State + 3-node cycle (planner -> researcher -> reviewer -> ...)
# ============================================================

class State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    cycle_count: int


def planner(state: State):
    return {"messages": [AIMessage(content="Plan work")]}


def researcher(state: State):
    return {"messages": [AIMessage(content="Research")]}


def reviewer(state: State):
    return {
        "messages": [AIMessage(content="REVISE: not enough depth")],
        "cycle_count": state.get("cycle_count", 0) + 1,
    }


def after_reviewer(state: State) -> Literal["planner", "__end__"]:
    # 8 rotations — above Layer 4's warning_threshold=5 but below
    # critical_threshold=15, so the cycle fires WARNING only. 8 is
    # also low enough that each edge stays under Layer 1's default
    # per_edge_limit=10, so the rate limiter doesn't interfere.
    if state.get("cycle_count", 0) >= 8:
        return END
    return "planner"


builder = StateGraph(State)
builder.add_node("planner", planner)
builder.add_node("researcher", researcher)
builder.add_node("reviewer", reviewer)
builder.add_edge(START, "planner")
builder.add_edge("planner", "researcher")
builder.add_edge("researcher", "reviewer")
builder.add_conditional_edges("reviewer", after_reviewer)
graph = builder.compile()


if __name__ == "__main__":
    # ─── AgentSonar: the entire integration, right here ───────────
    # The config override disables Layer 1 (rate limiter) so the
    # 16-event validator->worker burst in Phase 3 doesn't trip the
    # circuit breaker before Layer 2 (decay detector) has a chance
    # to see it. In real code you'd leave this at the default —
    # per_edge_limit=10 is the right behavior for production, where
    # that many events in 180 seconds IS a sign of a problem. We
    # bump it here only because the demo ingests events faster than
    # any real workload ever would.
    graph = monitor(graph, config={
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    # ──────────────────────────────────────────────────────────────

    # Phase 1 + 2: run the graph normally. 8 rotations of
    # planner -> researcher -> reviewer -> planner tripping the
    # cyclic_delegation detector.
    graph.invoke(
        {"messages": [HumanMessage(content="Coordinate")], "cycle_count": 0},
        config={"recursion_limit": 50},
    )

    # Phase 3: trigger repetitive_delegation on a separate edge.
    # We can't reach this cleanly through LangGraph routing — any
    # "call G many times in a row" pattern needs an intermediate
    # node that would itself create a cycle on {F, G}, and that
    # cycle would inhibit the repetitive alert in the summary view.
    # Easier: feed InteractionEvents directly into the engine.
    # `graph.sonar.engine` is the underlying DetectionEngine that
    # the callback owns — reaching for it is a minor layering
    # violation, acceptable for hand-crafted scenarios like this.
    base_ts = time.time()
    for i in range(16):
        graph.sonar.engine.ingest(
            InteractionEvent("validator", "worker", base_ts + i * 0.01)
        )

    # shutdown() prints the summary banner, closes the log files,
    # and auto-writes the JSON + HTML reports. Zero extra code.
    graph.shutdown()
