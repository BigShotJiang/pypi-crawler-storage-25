"""
prevent_mode_demo.py — the "reviewer never approves" infinite loop,
caught by Prevent Mode.

This is the custom-Python sibling of `langgraph_reviewer_insufficient_loop.py`
(LangGraph issue #6731). Same scenario, same 3-node cycle, hardcoded
fake-LLM outputs so the demo runs in <1 second with no API keys.

The scenario
============
A common multi-agent writing pipeline:

    researcher → writer → reviewer → (back to researcher | done)

The reviewer's "approved / not-approved" decision drives a conditional
edge. In production this branches on an LLM verdict — and if the
task is even slightly ambiguous the LLM keeps emitting "REVISION
REQUIRED" forever. The orchestrator spins until something external
kills it (timeout, recursion limit, the human who's now $$$ down).

For this demo we hardcode the reviewer to always say "REVISION
REQUIRED" so the loop reproduces deterministically without LLM calls.

What Prevent Mode does
======================
The orchestrator is a plain `while True:` loop. Without Prevent Mode
it would spin forever. With:

    monitor_orchestrator(config={"prevent": {"cyclic_delegation": True}})

AgentSonar raises `PreventError` the moment the cycle reaches CRITICAL
severity (default: 15 rotations). The user's `try/except PreventError`
catches it and the loop terminates cleanly — no rotation cap, no
recursion-limit traceback, no manual bookkeeping.

Notice what is NOT in the orchestrator below:
  * No iteration counter. AgentSonar tells you what rotation tripped.
  * No `if rotations > N: break`. AgentSonar trips for you.
  * No `recursion_limit` hack. The `while True:` is honest.

Run:
    uv run python examples/prevent_mode_demo.py
"""
from __future__ import annotations

from agentsonar import PreventError, monitor_orchestrator


# ============================================================
# Three "agents" — hardcoded fake-LLM outputs.
# Swap these for real LLM calls to reproduce the production bug.
# ============================================================

def researcher(state: dict) -> str:
    """Stand-in for an LLM that does another round of digging."""
    return "additional research findings"


def writer(state: dict) -> str:
    """Stand-in for a writer drafting a section from the research."""
    return "draft section v2"


def reviewer(state: dict) -> str:
    """The problem agent. In the real bug this is an LLM that keeps
    emitting 'REVISION REQUIRED' on an ambiguous task. We hardcode
    that behavior so the cycle reproduces deterministically.
    """
    return "REVISION REQUIRED: depth insufficient"


def quality_gate(review_output: str) -> str:
    """Conditional routing — the reviewer-output → next-node decision."""
    if "approved" in review_output.lower():
        return "done"
    return "researcher"  # back around the loop


# ============================================================
# Orchestrator — a plain while True, no manual cycle limit.
# ============================================================

def main() -> None:
    print("=" * 72)
    print("PREVENT MODE DEMO -- reviewer never approves")
    print("=" * 72)
    print()
    print("Three-node cycle: researcher -> writer -> reviewer -> researcher.")
    print("Reviewer is hardcoded to always say 'REVISION REQUIRED'.")
    print("Without Prevent Mode this loop runs forever.")
    print()

    # The ONLY change from a regular orchestrator setup:
    #     prevent={"cyclic_delegation": True}
    # `per_edge_limit` and `global_limit` are bumped because this
    # script fires events with no LLM latency in between; in
    # production you'd leave them at their defaults.
    sonar = monitor_orchestrator(config={
        "console_output": False,    # quiet — demo prints its own summary
        "warning_threshold": 5,
        "critical_threshold": 20,
        "per_edge_limit": 99999,
        "global_limit": 99999,
        "prevent": {"cyclic_delegation": {"max_rotations": 45}},
    })

    state: dict = {"facts": None, "draft": None, "review": None}
    caught: PreventError | None = None

    try:
        # Honest while True — no rotation cap, no recursion_limit,
        # no manual counter. The loop only terminates on either:
        #   (a) the reviewer says "approved" (never happens here)
        #   (b) AgentSonar raises PreventError
        while True:
            # researcher → writer
            sonar.delegation(source="researcher", target="writer")
            state["draft"] = writer(state)

            # writer → reviewer
            sonar.delegation(source="writer", target="reviewer")
            state["review"] = reviewer(state)

            # reviewer → (researcher | done)
            if quality_gate(state["review"]) == "done":
                break
            sonar.delegation(source="reviewer", target="researcher")
            state["facts"] = researcher(state)
    except PreventError as e:
        caught = e

    sonar.shutdown()

    # ============================================================
    # Report what happened
    # ============================================================
    print("-" * 72)
    print("OUTCOME")
    print("-" * 72)
    if caught is None:
        print("  Loop exited via the 'approved' path. Prevent Mode did not")
        print("  trip - the reviewer said yes (would not happen with the")
        print("  hardcoded fake-LLM in this demo, so this is a bug if seen).")
        return

    print(f"  Loop terminated by:    PreventError")
    print(f"  failure_class:         {caught.failure_class}")
    print(f"  severity:              {caught.severity}")
    print(f"  rotations at trip:     {caught.rotations}")
    print(f"  cycle path:            {' -> '.join(caught.cycle_path)}")
    print(f"  reason:                {caught.reason}")
    print()
    print("Without Prevent Mode this loop would have run until something")
    print("external killed it -- a timeout, a recursion limit, or the user")
    print("after their token bill arrived. AgentSonar caught it after")
    print(f"{caught.rotations} rotations of the same cycle.")


if __name__ == "__main__":
    main()
