"""
langgraph_clean_pipeline.py — a LangGraph workload with ZERO
coordination failures.

Simple linear 3-node pipeline:

    fetch → transform → store → END

No cycles, no repetition, no conditional edges, no back-references.
AgentSonar should run quietly and report:

  * stderr       — a green "✓ No coordination failures detected —
                   clean run." line under the summary banner
  * timeline.jsonl — the final `session_end` record with
                   `"clean_run": true`, `"warning_count": 0`,
                   `"critical_count": 0`
  * report.html  — a green "No coordination failures detected"
                   banner replacing the event cards
  * report.json  — an empty events array (nothing to report)

Use this example as a control case when you're integrating
AgentSonar into a new project and want to verify the wiring is
correct without expecting any alerts. If you see ANY alerts from
this script, something's misconfigured.

Requires: pip install agentsonar[langgraph]

Run:
    uv run python examples/langgraph_clean_pipeline.py
"""
from __future__ import annotations

import operator

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

from agentsonar import monitor


# ============================================================
# State + linear 3-node pipeline
# ============================================================

class State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]


def fetch(state: State):
    """Fetch input data (simulated)."""
    return {"messages": [AIMessage(content="fetched: 42 records")]}


def transform(state: State):
    """Transform the fetched data (simulated)."""
    return {"messages": [AIMessage(content="transformed: 42 records cleaned")]}


def store(state: State):
    """Persist the transformed data (simulated)."""
    return {"messages": [AIMessage(content="stored: 42 records written")]}


builder = StateGraph(State)
builder.add_node("fetch", fetch)
builder.add_node("transform", transform)
builder.add_node("store", store)
builder.add_edge(START, "fetch")
builder.add_edge("fetch", "transform")
builder.add_edge("transform", "store")
builder.add_edge("store", END)
graph = builder.compile()


if __name__ == "__main__":
    # ─── AgentSonar: wire it in with two lines ────────────────────
    graph = monitor(graph)
    # ──────────────────────────────────────────────────────────────

    graph.invoke({"messages": [HumanMessage(content="process batch 7")]})

    # shutdown() prints the summary banner. On a clean run you'll
    # see the green "No coordination failures detected — clean run"
    # line confirming everything ran without any alerts firing.
    graph.shutdown()
