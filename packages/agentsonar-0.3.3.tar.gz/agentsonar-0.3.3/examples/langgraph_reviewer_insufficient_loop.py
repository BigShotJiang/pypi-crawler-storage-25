"""
langgraph_reviewer_insufficient_loop.py — reproduction of the
"reviewer never approves" infinite loop (LangGraph issue #6731).

Reference:
    https://github.com/langchain-ai/langgraph/issues/6731

The scenario
============
A common LangGraph pattern for writing tasks:

    researcher → writer → reviewer → (back to researcher | END)

The reviewer's conditional edge routes BACK to the researcher
whenever the output quality is judged "insufficient". In real
setups this branches on the reviewer's LLM output — and if the
task is even slightly ambiguous, the LLM keeps saying "insufficient"
forever. The graph spins until LangGraph's `recursion_limit` kicks
in (default 25), at which point the user gets a cryptic
`GraphRecursionError` with no visibility into WHICH nodes were hot
or how many times each edge fired.

The diagnosis gap
=================
LangChain callback traces DO capture every node transition — but
they capture THOUSANDS of events per minute, and the "cycle" is
buried among normal state transitions. Users spend hours staring
at raw traces trying to figure out which specific node triple is
looping.

What AgentSonar does
====================
AgentSonar watches node transitions as they happen and surfaces
the cycle as a structured alert:

    * WARNING at rotation 5:
        Cyclic delegation detected: researcher -> writer -> reviewer
        -> researcher (5 rotations)

    * CRITICAL at rotation 15:
        same cycle, every per-edge frequency visible in the HTML
        report, fingerprint stable across runs so you can correlate
        the SAME loop between today's failure and yesterday's.

The HTML report shows the closed-loop arrow path at the top of the
card, the `agents_involved`, and each edge's fire count so you can
tell which transition is hottest.

Note on "real" LLMs vs this example
====================================
The real bug is LLM-driven — the reviewer's language model keeps
emitting "REVISION REQUIRED". For this example to be CHEAP and
REPRODUCIBLE, we use a hardcoded-response reviewer that always
says "insufficient" until a rotation cap is reached. Swap the
reviewer body out for an actual LLM call to reproduce the real
bug end-to-end.

The rotation cap is 18 — above both the WARNING threshold (5) and
the CRITICAL threshold (15), so the full alert lifecycle fires.

Requires: pip install agentsonar[langgraph]

Run:
    uv run python examples/langgraph_reviewer_insufficient_loop.py
"""
from __future__ import annotations

import operator
from typing import Literal

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict

# ============================================================
# The entire AgentSonar integration — one import, one call.
# ============================================================
from agentsonar import monitor


# ============================================================
# State + 3-node cycle
# ============================================================

class State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    rotation_count: int


def researcher(state: State):
    """Mimics an LLM researcher doing another round of digging."""
    return {
        "messages": [AIMessage(content="additional research findings")],
    }


def writer(state: State):
    """Mimics a writer drafting a section from the research."""
    return {
        "messages": [AIMessage(content="draft section v2")],
    }


def reviewer(state: State):
    """The problem node. In the real bug this is an LLM that keeps
    emitting 'REVISION REQUIRED' because the task is ambiguous. For
    the example we hard-code that behavior so it reproduces without
    API calls.
    """
    return {
        "messages": [AIMessage(content="REVISION REQUIRED: depth insufficient")],
        "rotation_count": state.get("rotation_count", 0) + 1,
    }


def quality_gate(state: State) -> Literal["researcher", "__end__"]:
    """Conditional edge: reviewer → researcher or END.

    In the real bug this parses the reviewer's LLM output for a
    "sufficient" verdict and falls back to "researcher" otherwise.
    Since our mock reviewer always returns "insufficient", we use
    a hardcoded rotation cap of 18 so the script terminates.
    Set this to >=25 to reproduce the real GraphRecursionError
    that users hit in production.
    """
    if state.get("rotation_count", 0) >= 18:
        return END
    return "researcher"


builder = StateGraph(State)
builder.add_node("researcher", researcher)
builder.add_node("writer", writer)
builder.add_node("reviewer", reviewer)
builder.add_edge(START, "researcher")
builder.add_edge("researcher", "writer")
builder.add_edge("writer", "reviewer")
builder.add_conditional_edges("reviewer", quality_gate)
graph = builder.compile()


if __name__ == "__main__":
    # ─── AgentSonar: wire it in with two lines ────────────────────
    # We bump `per_edge_limit` and `global_limit` above their
    # defaults because this script fires events far faster than
    # any real LLM workload (there's no actual network I/O). In
    # production you'd leave these at the defaults — `per_edge_limit=10`
    # is the right circuit-breaker for real crews.
    graph = monitor(graph, config={
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    # ──────────────────────────────────────────────────────────────

    # Run the graph. 18 rotations × 3 nodes = 54 state transitions,
    # recursion_limit needs to be at least that. We pad it out.
    graph.invoke(
        {
            "messages": [HumanMessage(content="Write a research article")],
            "rotation_count": 0,
        },
        config={"recursion_limit": 80},
    )

    # shutdown() prints the summary banner, writes the JSON + HTML
    # reports, and closes the logger. Look for two alerts in the
    # output: a WARNING cycle at rotation 5 and a CRITICAL cycle
    # at rotation 15.
    graph.shutdown()
