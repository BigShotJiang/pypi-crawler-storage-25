"""
crewai_delegation_ping_pong.py — detecting runaway delegation
patterns in CrewAI hierarchical crews.

Background
==========
CrewAI's hierarchical process lets a manager agent delegate work
to specialized worker agents via an internal "Delegate Work to
Coworker" tool. In production, design partners have reported a
recurring failure mode: the manager repeatedly delegates the
same kind of work to the same worker in tight bursts — sometimes
because of a genuine task shape, sometimes because of LLM-driven
retry loops (see the Azguards Technolabs write-up on
"Delegation Ping-Pong" for the full story:
https://azguards.com/technical/the-delegation-ping-pong-breaking-infinite-handoff-loops-in-crewai-hierarchical-topologies/).

The diagnosis gap
=================
Regardless of whether the hot edge comes from a real bug or a
legitimate multi-step task, the signal is the same at the
delegation-event level: one `manager -> worker` edge fires many
times in a short window. CrewAI's event bus emits a
`ToolUsageStartedEvent` for each delegation, but in a busy
hierarchical crew there are thousands of events and no obvious
way to spot which edge is "hot". Users burn hours staring at
traces before realizing a single delegation edge has fired 20+
times.

What AgentSonar does
====================
AgentSonar watches each delegation as a directed edge
`manager -> worker` and tracks the decayed event count per edge
over a sliding window. When the same edge fires more than
`hard_weight_limit` times (default 10) in the window, it fires a
structured `repetitive_delegation` alert at WARNING and escalates
to CRITICAL as the count grows.

You'll see:

  * WARNING `edge_anomaly`:  manager -> researcher (11 events)
  * CRITICAL `edge_anomaly`: manager -> researcher (15 events)
  * A per-edge frequency breakdown in the HTML report card so
    you know exactly which edge is hot
  * A stable `coordination_fingerprint` you can grep for across
    runs to correlate today's failure with yesterday's

What this example runs
======================
A real CrewAI hierarchical crew with a concrete multi-step
research task. The manager is given a list of 15 factual
sub-questions about a topic and instructed to delegate EACH
question to the Researcher one at a time. The Researcher
answers each question cleanly and the manager compiles the
results.

No ambiguous instructions, no "always re-verify" retry loops,
and no parallel-tool-call behavior — we pin the LLM to
`gpt-4o-mini` and give deterministic instructions so the
run completes reliably. The repeated `manager -> researcher`
delegations are LEGITIMATE work, but the edge frequency alone
crosses AgentSonar's threshold and produces the same
`repetitive_delegation` alert you'd see from a pathological
loop. That's the point: AgentSonar's output is identical for
"legitimate hot edge" and "runaway hot edge" — both are
equally worth knowing about in a production crew.

If you want AgentSonar to STAY QUIET for this workload,
either:
  * Raise `hard_weight_limit` in the config to 20 or higher,
  * Or split the 15 subtasks across two workers so each edge
    stays under the threshold.

Both of those are normal tuning knobs; `examples/crewai_clean_sequential.py`
shows the clean-run equivalent.

Running this example
====================
You'll need:
  1. pip install agentsonar[crewai]
  2. OPENAI_API_KEY in your environment

Cost estimate: ~$0.05-$0.15 in gpt-4o-mini tokens for a single run.
That's significantly cheaper than earlier versions of this example
which tried to trigger LLM retry loops on GPT-4.

Run:
    export OPENAI_API_KEY=sk-...
    uv run python examples/crewai_delegation_ping_pong.py
"""
from __future__ import annotations

import os
import sys

# The 2 lines that wire AgentSonar into CrewAI:
#
#     from agentsonar import AgentSonarListener
#     sonar = AgentSonarListener()
#
# The listener subscribes to CrewAI's event bus the moment it's
# instantiated. No other setup, no custom tool wrappers, no
# explicit shutdown call — `AgentSonarListener` hooks
# `CrewKickoffCompletedEvent` and auto-tears down when the crew
# finishes.
from agentsonar import AgentSonarListener


def main() -> None:
    # Bail out early if CrewAI isn't installed. Instantiating
    # AgentSonarListener below would also fail with a friendly
    # message, but this check lets us show BOTH missing pieces
    # (crewai AND the API key) at once.
    try:
        from crewai import Agent, Crew, LLM, Process, Task
    except ImportError:
        print(
            "CrewAI is not installed. Run:\n"
            "    pip install agentsonar[crewai]\n"
            "and set OPENAI_API_KEY (or configure another LLM provider).",
            file=sys.stderr,
        )
        sys.exit(1)

    if not os.getenv("OPENAI_API_KEY"):
        print(
            "OPENAI_API_KEY is not set. This example runs a real CrewAI "
            "crew, which makes LLM calls. Set the env var or configure "
            "another provider before running.\n"
            "    export OPENAI_API_KEY=sk-...\n"
            "See https://docs.crewai.com/concepts/llms for alternatives.",
            file=sys.stderr,
        )
        sys.exit(1)

    print("=" * 60)
    print("CREWAI DELEGATION PING-PONG (with AgentSonar monitoring)")
    print("=" * 60)
    print()
    print("Running a real CrewAI hierarchical crew with a multi-step")
    print("research task. The manager delegates 15 concrete sub-questions")
    print("to the Researcher. AgentSonar watches the delegation edge and")
    print("fires WARNING + CRITICAL alerts when manager->researcher crosses")
    print("the default hot-edge threshold.")
    print()

    # ================== THE 2 LINES ==================
    sonar = AgentSonarListener()
    # =================================================
    #
    # That's it. Everything below is vanilla CrewAI — AgentSonar
    # is already watching the event bus.

    # Pin the LLM to gpt-4o-mini. This model is:
    #   * cheap (~$0.15/1M input tokens at time of writing)
    #   * deterministic-enough that we don't hit the parallel-
    #     tool-call race that GPT-4o / GPT-5 sometimes trip on
    #     in hierarchical CrewAI (where the message history ends
    #     up with an orphaned tool_call_id and the API rejects
    #     the next call with a 400 error)
    #   * still capable enough to handle concrete subtasks
    #
    # If you want to experiment with a different model, swap
    # it in here — just know that more capable models are more
    # likely to emit parallel tool_calls and crash CrewAI's
    # hierarchical executor. See the note in the docstring.
    llm = LLM(model="gpt-4o-mini", temperature=0.2)

    researcher = Agent(
        role="Researcher",
        goal=(
            "Answer each delegated sub-question with a short, "
            "concrete fact. One sentence per answer. Do not ask "
            "clarifying questions — work with the information "
            "you're given."
        ),
        backstory=(
            "A pragmatic researcher who returns concise, "
            "one-sentence facts without second-guessing."
        ),
        llm=llm,
        allow_delegation=False,
        verbose=False,
    )

    manager = Agent(
        role="Manager",
        goal=(
            "Delegate every sub-question in the task description "
            "to the Researcher, one at a time. After you have "
            "collected all the answers, compile them into a "
            "short summary. Do NOT ask the Researcher to revise "
            "or clarify — each sub-question is independent."
        ),
        backstory=(
            "A methodical project manager who breaks work into "
            "concrete sub-questions and delegates each one "
            "exactly once."
        ),
        llm=llm,
        allow_delegation=True,
        verbose=False,
    )

    # Concrete multi-step research task. 15 explicit sub-questions
    # so the manager has a clear, terminating agenda and the
    # `manager -> researcher` edge fires 15 times without any
    # retry loops or ambiguity. 15 events is above the default
    # `hard_weight_limit=10` AND above the `critical_threshold=15`,
    # so both WARNING and CRITICAL edge_anomaly alerts fire.
    task = Task(
        description=(
            "Gather the following 15 facts about the Python "
            "programming language by delegating EACH question "
            "to the Researcher separately, one at a time. "
            "Do not combine questions. Do not ask for revisions. "
            "\n\n"
            "1. Who created Python?\n"
            "2. In what year was Python first released?\n"
            "3. What is Python's official license called?\n"
            "4. What is Python's official package manager?\n"
            "5. What is Python's official website URL?\n"
            "6. What is the name of Python's default interpreter?\n"
            "7. What file extension do Python source files use?\n"
            "8. What is the Python indentation convention (spaces or tabs)?\n"
            "9. What is the name of Python's unit test framework in stdlib?\n"
            "10. What does PEP stand for in the Python ecosystem?\n"
            "11. Which Python version introduced f-strings?\n"
            "12. What is the name of Python's built-in virtual environment module?\n"
            "13. What is the name of Python's default HTTP client library in stdlib?\n"
            "14. What is the name of the foundation that stewards Python?\n"
            "15. What is Python's slogan or informal tagline?\n"
            "\n"
            "Once all 15 facts are collected, compile them into "
            "a short numbered list and return it as your answer."
        ),
        expected_output="A numbered list of all 15 facts about Python.",
        agent=manager,
    )

    # CrewAI requires the manager agent to be passed via
    # `manager_agent` ONLY — it must NOT also appear in the `agents`
    # list. Workers go in `agents`; the manager is separate.
    crew = Crew(
        agents=[researcher],
        tasks=[task],
        process=Process.hierarchical,
        manager_agent=manager,
        verbose=False,
    )

    print("--- Running crew (this makes real LLM calls) ---\n")
    result = crew.kickoff()

    print("\n--- Crew result ---")
    print(result)

    # AgentSonarListener auto-shuts down on CrewKickoffCompletedEvent.
    # Check the stderr output above for AgentSonar's WARNING and
    # CRITICAL `edge_anomaly: manager -> researcher` alerts, and
    # open the HTML report in agentsonar_logs/<latest>/report.html
    # for the full structured view.


if __name__ == "__main__":
    main()
