"""
warning_and_critical.py — a scenario that produces exactly 1 WARNING
and 2 CRITICAL events in the summary view.

Useful for:
  * Screenshotting the HTML report for docs / slides
  * Verifying the severity rendering in your own UI before shipping
  * Showing reviewers the three severities side-by-side

No framework required — runs directly against the DetectionEngine.
No LLM calls. Completes in under a second.

How the counts land:

  Pattern 1  (WARNING CRITICAL cyclic_delegation):
    A <-> B 2-node cycle traversed 10 times. Hits warning_threshold=5
    but NOT critical_threshold=15, so it stays at WARNING.

  Pattern 2  (CRITICAL cyclic_delegation):
    C -> D -> E -> C 3-node cycle traversed 20 times. Crosses both
    thresholds: WARNING at rotation 5, CRITICAL at rotation 15. The
    deduped summary keeps the highest severity → CRITICAL.

  Pattern 3  (CRITICAL repetitive_delegation):
    X -> Y hammered 20 times (no Y -> X return edge). Layer 2's
    exponential-decay detector fires on the hot edge; state manager
    takes it through WARNING → CRITICAL. No {X, Y} cycle exists so
    the alert is NOT inhibited by any root cause.

Deduped summary output:
  [WARNING]  cyclic_delegation      {A, B}          10 rotations
  [CRITICAL] cyclic_delegation      {C, D, E}       20 rotations
  [CRITICAL] repetitive_delegation  X -> Y          20 events

Run:
    uv run python examples/warning_and_critical.py
"""
from __future__ import annotations

import time

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent


def main() -> None:
    print("=" * 64)
    print("WARNING + CRITICAL DEMO — 1 WARNING + 2 CRITICAL in summary")
    print("=" * 64)

    # Default thresholds: warning=5, critical=15.
    # Disable Layer 1 (rate limiter) so burst ingest doesn't trip it
    # before the detection layers have a chance to react.
    engine = DetectionEngine({
        "warning_threshold": 5,
        "critical_threshold": 15,
        "hard_weight_limit": 10.0,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })

    base_ts = time.time()

    # ------------------------------------------------------------------
    # Pattern 1: 2-node cycle A <-> B, 10 rotations → WARNING only
    # ------------------------------------------------------------------
    print("\n[1/3] Building A <-> B cycle for 10 rotations (WARNING)...")
    for i in range(10):
        engine.ingest(InteractionEvent("A", "B", base_ts + i * 0.01))
        engine.ingest(InteractionEvent("B", "A", base_ts + i * 0.01 + 0.005))

    # ------------------------------------------------------------------
    # Pattern 2: 3-node cycle C -> D -> E -> C, 20 rotations → CRITICAL
    # ------------------------------------------------------------------
    print("[2/3] Building C -> D -> E -> C cycle for 20 rotations (CRITICAL)...")
    base_ts += 10.0  # move forward in time so the cycles stay separate
    for i in range(20):
        engine.ingest(InteractionEvent("C", "D", base_ts + i * 0.01))
        engine.ingest(InteractionEvent("D", "E", base_ts + i * 0.01 + 0.003))
        engine.ingest(InteractionEvent("E", "C", base_ts + i * 0.01 + 0.006))

    # ------------------------------------------------------------------
    # Pattern 3: One-directional hammer X -> Y, 20 events → CRITICAL
    # ------------------------------------------------------------------
    # Directly ingested (not a real cycle) so no {X, Y} cycle exists
    # and the repetitive alert survives the summary view's inhibition.
    print("[3/3] Hammering X -> Y one-directional 20 times (CRITICAL)...")
    base_ts += 10.0
    for i in range(20):
        engine.ingest(InteractionEvent("X", "Y", base_ts + i * 0.01))

    # ------------------------------------------------------------------
    # Inspect the deduped summary view
    # ------------------------------------------------------------------
    events = engine.get_recent_events()

    # Apply the same dedupe + inhibit pipeline that export_json uses by
    # default, so the in-memory preview matches the report on disk.
    from agentsonar._core.schema import (
        dedupe_events_by_fingerprint,
        inhibit_subsumed_events,
    )
    summarized = inhibit_subsumed_events(dedupe_events_by_fingerprint(events))

    warnings = [e for e in summarized if e.severity.value == "WARNING"]
    criticals = [e for e in summarized if e.severity.value == "CRITICAL"]

    print("\n" + "=" * 64)
    print("SUMMARY VIEW")
    print("=" * 64)
    print(f"  WARNING events:  {len(warnings)}")
    print(f"  CRITICAL events: {len(criticals)}")
    print(f"  Total in summary: {len(summarized)}")
    print()
    for ev in sorted(summarized, key=lambda e: (e.severity.value, e.timestamp)):
        sev = ev.severity.value.ljust(8)
        print(f"  [{sev}] {ev.summary}")
    print()

    # Expected counts match exactly what the script promised
    assert len(warnings) == 1, (
        f"expected 1 WARNING in summary, got {len(warnings)}"
    )
    assert len(criticals) == 2, (
        f"expected 2 CRITICAL in summary, got {len(criticals)}"
    )

    # shutdown() auto-writes the JSON + HTML reports to cwd.
    print("  (JSON + HTML reports will be written by engine.shutdown())")
    print("=" * 64)
    engine.shutdown()


if __name__ == "__main__":
    main()
