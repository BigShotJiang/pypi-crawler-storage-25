"""
engine_only.py — using AgentSonar's detection engine directly, no framework.

Demonstrates the bare-metal detection pipeline: feed InteractionEvent
objects straight into the DetectionEngine, no CrewAI, no LangGraph. Use
this if you want AgentSonar monitoring for a custom orchestration
framework we don't have an adapter for yet — you just need to translate
your framework's events into InteractionEvent objects.

No LLM calls, no external dependencies beyond networkx. Runs in under
a second.

Scenario:
  Phase 1: A -> B -> C -> A cycle for 16 rotations  (cyclic_delegation)
  Phase 2: F -> G hammered 15 times                  (repetitive_delegation)

Note on imports:
  AgentSonar's public API is intentionally minimal — only
  `AgentSonarListener` (CrewAI) and `AgentSonarCallback` (LangGraph) are
  exposed at the top level. This example reaches into the internal
  `_core` subpackage because it's demonstrating advanced / custom usage.
  These underscore-prefixed imports are not part of the stable public
  API and may change between minor versions.

Run:
    uv run python examples/engine_only.py
"""
from __future__ import annotations

import time

# Internal imports — custom framework integrators only.
from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent


def main() -> None:
    print("=" * 60)
    print("AGENTSONAR — ENGINE-ONLY DEMO (no framework)")
    print("=" * 60)

    # Two-line setup equivalent for custom frameworks:
    engine = DetectionEngine({
        "warning_threshold": 5,
        "critical_threshold": 15,
        "hard_weight_limit": 10.0,
        # Disable rate limiter so the hammer burst doesn't trip it before
        # Layer 2 sees the hot edge.
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })

    # -------------------------------------------------------------
    # Phase 1: Cycle A -> B -> C -> A for 16 rotations
    # -------------------------------------------------------------
    print("\n--- Phase 1: cycle (A -> B -> C -> A) x 16 ---")
    base_ts = time.time()
    for i in range(16):
        engine.ingest(InteractionEvent("A", "B", base_ts + i * 0.1))
        engine.ingest(InteractionEvent("B", "C", base_ts + i * 0.1 + 0.03))
        engine.ingest(InteractionEvent("C", "A", base_ts + i * 0.1 + 0.06))

    # -------------------------------------------------------------
    # Phase 2: Hammer F -> G to trigger repetitive detection
    # -------------------------------------------------------------
    # No G -> F return edge means no {F, G} cycle forms, so the
    # repetitive_delegation alert isn't inhibited by a cycle root cause.
    print("--- Phase 2: hammer F -> G x 15 ---")
    hammer_ts = time.time()
    for i in range(15):
        engine.ingest(InteractionEvent("F", "G", hammer_ts + i * 0.01))

    # -------------------------------------------------------------
    # Results
    # -------------------------------------------------------------
    print("\n" + "=" * 60)
    print("DETECTION RESULTS")
    print("=" * 60)

    summary = engine.get_summary()
    print(f"\n  Total events:  {summary['total_events']}")
    print(f"  Total alerts:  {summary['alerts_raised']}")
    print(f"\n  Edge counts:")
    for edge, count in sorted(summary["edge_counts"].items(), key=lambda x: -x[1]):
        print(f"    {edge}: {count}x")

    events = engine.get_recent_events()
    cyclic = [e for e in events if e.failure_class.value == "cyclic_delegation"]
    repetitive = [e for e in events if e.failure_class.value == "repetitive_delegation"]

    print(f"\n  --- Failure Class Coverage ---")
    print(f"    cyclic_delegation:     "
          f"{'FIRED (' + str(len(cyclic)) + ' events)' if cyclic else 'not triggered'}")
    print(f"    repetitive_delegation: "
          f"{'FIRED (' + str(len(repetitive)) + ' events)' if repetitive else 'not triggered'}")

    if cyclic:
        ev = cyclic[-1]
        print(f"\n    Latest cyclic event:")
        print(f"      severity:  {ev.severity.value}")
        print(f"      summary:   {ev.summary}")

    if repetitive:
        ev = repetitive[-1]
        print(f"\n    Latest repetitive event:")
        print(f"      severity:  {ev.severity.value}")
        print(f"      summary:   {ev.summary}")

    # shutdown() writes the JSON + HTML reports to cwd automatically.
    # (auto_export_on_shutdown is True by default when file_output is
    # enabled.) No explicit export_json/export_html calls needed — zero
    # extra code from this example.
    print(f"\n  Structured events: {len(events)}")
    print(f"  (JSON + HTML reports will be written by engine.shutdown())")
    print("=" * 60)

    engine.shutdown()


if __name__ == "__main__":
    main()
