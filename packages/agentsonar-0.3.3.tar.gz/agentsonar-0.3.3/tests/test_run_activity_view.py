"""
Run Activity view regression tests.

The Run Activity section surfaces every delegation edge the
CoordinationGraph saw during the run — INFO-level visibility that
OpenTelemetry / LangSmith / Langfuse trade-tree views can't easily
give. It renders on BOTH clean runs and alert runs because the point
is to answer "what did the graph actually do?" — not just "what
went wrong?"

The section is a first-class feature of the HTML report, so we
regression-test it across four axes:

  * CoordinationGraph correctly records first_ts / last_ts per edge.
  * The engine snapshots and enriches edge activity at shutdown
    (alert_count derived from topology.edge_frequency).
  * events_to_html renders the section when activity is provided,
    skips it when not.
  * Clean runs and alert runs BOTH get the section.
"""
from __future__ import annotations

import os
import tempfile

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.graph import CoordinationGraph
from agentsonar._core.models import InteractionEvent
from agentsonar._output.html_report import events_to_html


# ---------------------------------------------------------------------------
# CoordinationGraph.edge_activity_summary()
# ---------------------------------------------------------------------------

def test_graph_tracks_first_and_last_timestamp_per_edge():
    g = CoordinationGraph()
    g.add_event("a", "b", timestamp=100.0)
    g.add_event("a", "b", timestamp=101.5)
    g.add_event("a", "b", timestamp=102.25)
    records = g.edge_activity_summary()
    assert len(records) == 1
    r = records[0]
    assert r["source"] == "a"
    assert r["target"] == "b"
    assert r["count"] == 3
    assert r["first_ts"] == 100.0
    assert r["last_ts"] == 102.25


def test_graph_backfills_first_ts_when_initial_call_lacked_one():
    """Legacy callers can pass no timestamp on the first add_event. If
    a later call does supply one, we back-fill first_ts rather than
    leaving it None forever — otherwise the Run Activity view would
    show a perfectly-timestamped edge with "first: —" which is
    confusing.
    """
    g = CoordinationGraph()
    g.add_event("a", "b")  # no timestamp
    g.add_event("a", "b", timestamp=200.0)
    [rec] = g.edge_activity_summary()
    assert rec["first_ts"] == 200.0
    assert rec["last_ts"] == 200.0
    assert rec["count"] == 2


def test_graph_activity_summary_sorted_by_last_ts_desc():
    """Hottest / most recent edges float to the top of the table."""
    g = CoordinationGraph()
    g.add_event("a", "b", timestamp=100.0)
    g.add_event("c", "d", timestamp=300.0)
    g.add_event("e", "f", timestamp=200.0)
    records = g.edge_activity_summary()
    timestamps = [r["last_ts"] for r in records]
    assert timestamps == [300.0, 200.0, 100.0]


def test_graph_activity_summary_empty_when_no_events():
    g = CoordinationGraph()
    assert g.edge_activity_summary() == []


# ---------------------------------------------------------------------------
# HTML rendering — presence / absence of the section
# ---------------------------------------------------------------------------

def test_html_renders_edge_activity_tab_on_clean_run():
    """The whole raison d'être of Shape A: show activity even when
    no warnings or criticals fired. A clean run with activity must
    still render the Session Activity section with Edge Activity
    as the default active tab."""
    activity = [
        {
            "source": "orchestrator",
            "target": "generator",
            "count": 5,
            "first_ts": 1700000000.0,
            "last_ts": 1700000002.5,
            "alert_count": 0,
        },
    ]
    html = events_to_html([], edge_activity=activity)
    assert '<section class="session-activity">' in html
    assert 'Edge Activity<span class="tab-count">' in html
    assert "orchestrator" in html
    assert "generator" in html
    assert "5 fires" in html
    assert "no alerts" in html
    # Clean-run banner still present — the two sections are independent.
    assert "No coordination failures detected" in html


def test_html_skips_session_activity_when_no_edge_activity_provided():
    """Legacy callers (tests, manual exports) that pass no
    edge_activity AND no session_log should NOT see the Session
    Activity section — keeps the contract backward-compatible."""
    html = events_to_html([])
    assert '<section class="session-activity">' not in html
    assert '<details class="edge-card' not in html


def test_html_skips_session_activity_when_edge_activity_is_empty_list():
    html = events_to_html([], edge_activity=[])
    assert '<section class="session-activity">' not in html


def test_html_renders_session_activity_alongside_coordination_failures():
    """When alerts fired AND activity is provided, both sections
    must render — users need to see "here's what happened" (Session
    Activity) and "here's what crossed the threshold" (Coordination
    Failures cards) together.

    Enrichment now runs INSIDE the HTML renderer (after dedupe +
    inhibit), so callers just pass the raw edge_activity snapshot
    and the displayed counts line up with the displayed cards.
    """
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        ts = 1000.0
        for i in range(15):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        events = engine.get_recent_events()
        raw_activity = engine.coord_graph.edge_activity_summary()
        # Pass RAW — renderer does the enrichment.
        html = events_to_html(events, edge_activity=raw_activity)
        # Both sections rendered
        assert '<section class="coordination-failures">' in html
        assert '<section class="session-activity">' in html
        # Edge Activity tab active with at least one edge card
        assert 'Edge Activity<span class="tab-count">' in html
        assert '<details class="edge-card' in html
        # Alert cards also present
        assert '<article class="event' in html
        # Clean-run banner must NOT show — alerts fired
        assert "No coordination failures detected" not in html
    finally:
        engine.shutdown()


# ---------------------------------------------------------------------------
# Alert count enrichment
# ---------------------------------------------------------------------------

# Helper — the CoordinationEvent constructor is long, wrap it once.
def _make_event(*, severity, failure_class, edge_key, occurrences, ts=100.0, fp="sha256:test"):
    """Build a synthetic CoordinationEvent for severity-count tests."""
    from agentsonar._core.schema import (
        AlertSeverity, CoordinationEvent, FailureClass, Topology,
    )
    src, _, tgt = edge_key.partition("->")
    return CoordinationEvent(
        schema_version="0.1.0",
        event_id=f"test-{edge_key}-{severity}",
        session_id="test-sess",
        timestamp=ts,
        event_type="coordination_failure",
        failure_class=failure_class,
        severity=severity,
        coordination_fingerprint=fp,
        summary="synthetic test event",
        topology=Topology(
            agents_involved=(src, tgt),
            interaction_pattern="circular" if failure_class.value == "cyclic_delegation" else "one_directional",
            agent_count=2,
            occurrence_count=occurrences,
            edge_frequency={edge_key: occurrences},
        ),
    )


# The CSS stylesheet ALWAYS contains `has-critical` / `has-warning`
# (they're class-selectors). To check "did we emit a card with this
# class?", match against the actual class= attribute on the edge-card
# element.
_HAS_CRITICAL_CARD = '<details class="edge-card has-critical">'
_HAS_WARNING_CARD = '<details class="edge-card has-warning">'


def test_edge_with_critical_alerts_gets_red_chip():
    """CRITICAL-severity event touching this edge → chip '1 critical',
    card gets has-critical class (red border + red chip)."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    event = _make_event(
        severity=AlertSeverity.CRITICAL,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=15,
    )
    activity = [{
        "source": "a", "target": "b", "count": 15,
        "first_ts": 100.0, "last_ts": 200.0,
    }]
    html = events_to_html([event], edge_activity=activity)
    assert "1 critical" in html
    assert _HAS_CRITICAL_CARD in html
    # Must NOT fall back to generic "N alerts" wording
    assert "1 alerts" not in html


def test_edge_with_warning_only_gets_orange_chip():
    """WARNING-severity only → chip '1 warning' with has-warning class."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    event = _make_event(
        severity=AlertSeverity.WARNING,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=6,
    )
    activity = [{
        "source": "a", "target": "b", "count": 6,
        "first_ts": 100.0, "last_ts": 150.0,
    }]
    html = events_to_html([event], edge_activity=activity)
    assert "1 warning" in html
    assert _HAS_WARNING_CARD in html
    # No critical card rendered
    assert _HAS_CRITICAL_CARD not in html


def test_edge_with_no_displayed_alerts_uses_neutral_chip():
    """No displayed events touching this edge → 'no alerts'."""
    activity = [{
        "source": "a", "target": "b", "count": 10,
        "first_ts": 100.0, "last_ts": 200.0,
    }]
    html = events_to_html([], edge_activity=activity)
    assert "no alerts" in html
    assert _HAS_CRITICAL_CARD not in html
    assert _HAS_WARNING_CARD not in html


def test_critical_dominates_warning_on_same_edge():
    """When both CRITICAL and WARNING events touch the same edge
    after dedupe+inhibit, only the critical count renders — matches
    user expectation that 'if it's critical, show 1 critical, not
    warning noise'."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    # Different fingerprints so dedupe keeps both. Inhibit likely
    # drops the repetitive one since the cycle covers this edge,
    # but the test asserts the END result either way: critical
    # wins the chip, warning is invisible.
    crit = _make_event(
        severity=AlertSeverity.CRITICAL,
        failure_class=FailureClass.CYCLIC_DELEGATION,
        edge_key="a->b",
        occurrences=10,
        fp="sha256:crit",
    )
    warn = _make_event(
        severity=AlertSeverity.WARNING,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=6,
        ts=50.0,
        fp="sha256:warn",
    )
    activity = [{
        "source": "a", "target": "b", "count": 16,
        "first_ts": 50.0, "last_ts": 100.0,
    }]
    html = events_to_html([crit, warn], edge_activity=activity)
    assert "1 critical" in html
    assert _HAS_CRITICAL_CARD in html
    # Chip does not show warning when critical dominates
    assert "1 warning" not in html


def test_edge_alert_count_matches_displayed_cards_after_dedupe():
    """Regression for the original bug: edge chips showed '4 alerts'
    while only 1 card appeared in the final report, because raw
    events (pre-dedupe) were counted instead of displayed ones.

    After the fix, the edge chip count equals the number of displayed
    cards that touch that edge."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 2,
        "critical_threshold": 4,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        ts = 1000.0
        # 3-node cycle — fires both WARNING and CRITICAL over its run;
        # dedupe collapses to 1 CRITICAL per cycle fingerprint.
        for i in range(10):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "c", ts + i * 0.01 + 0.002))
            engine.ingest(InteractionEvent("c", "a", ts + i * 0.01 + 0.004))
        events = engine.get_recent_events()
        raw = engine.coord_graph.edge_activity_summary()
        html = events_to_html(events, edge_activity=raw)

        # Count displayed critical cards for edges in the cycle —
        # should be 1 (the dedupe-surviving cycle event).
        # And the Edge Activity chip on any cycle edge should say
        # '1 critical', NOT '3 critical' or '4 alerts'.
        assert "1 critical" in html
        # Legacy wording gone
        assert " alerts<" not in html or "no alerts<" in html
        # 3-card inflation not happening
        assert "3 critical" not in html
        assert "4 alerts" not in html
    finally:
        engine.shutdown()


# ---------------------------------------------------------------------------
# Shutdown integration — the real glue path
# ---------------------------------------------------------------------------

def test_shutdown_writes_report_with_session_activity_on_clean_run():
    """End-to-end: clean run, file_output=True. The generated HTML
    file must contain the Session Activity section with Edge
    Activity tab active, confirming that shutdown() wired the
    edge_activity snapshot through _auto_export_reports to
    export_html."""
    with tempfile.TemporaryDirectory() as td:
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": td,
            "warning_threshold": 1000,   # no alerts — clean run
            "critical_threshold": 10000,
            "per_edge_limit": 99999,
            "global_limit": 99999,
        })
        ts = 1000.0
        engine.ingest(InteractionEvent("planner", "coder", ts))
        engine.ingest(InteractionEvent("coder", "qa", ts + 0.01))
        engine.ingest(InteractionEvent("qa", "planner", ts + 0.02))
        run_dir = engine.logger.run_dir
        engine.shutdown()

        with open(os.path.join(run_dir, "report.html"), encoding="utf-8") as f:
            html = f.read()
        assert '<section class="session-activity">' in html
        assert 'Edge Activity<span class="tab-count">' in html
        assert "planner" in html
        assert "coder" in html
        assert "qa" in html
        # Clean-run banner still there
        assert "No coordination failures detected" in html


def test_shutdown_run_activity_shows_correct_fire_counts():
    """The count per edge must match the number of times we ingested
    that src→tgt pair. This is a correctness check — if the graph
    drifts from the ingest stream we want the test to catch it."""
    with tempfile.TemporaryDirectory() as td:
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": td,
            "warning_threshold": 1000,
            "critical_threshold": 10000,
            "per_edge_limit": 99999,
            "global_limit": 99999,
        })
        ts = 1000.0
        for i in range(7):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
        for i in range(3):
            engine.ingest(InteractionEvent("b", "c", ts + 10 + i * 0.01))
        run_dir = engine.logger.run_dir
        engine.shutdown()

        with open(os.path.join(run_dir, "report.html"), encoding="utf-8") as f:
            html = f.read()
        assert "7 fires" in html
        assert "3 fires" in html


def test_edge_activity_section_format_scannable():
    """Shape A sanity check: the section should mention the total
    edge count and total fire count in the hint line so users get a
    one-glance summary without expanding anything."""
    activity = [
        {"source": "a", "target": "b", "count": 5,
         "first_ts": 100.0, "last_ts": 101.0, "alert_count": 0},
        {"source": "b", "target": "c", "count": 3,
         "first_ts": 100.5, "last_ts": 101.5, "alert_count": 0},
    ]
    html = events_to_html([], edge_activity=activity)
    # 2 edges, 8 total fires
    assert "2 delegation edges" in html
    assert "8 total events" in html


# ---------------------------------------------------------------------------
# Defensive edge cases
# ---------------------------------------------------------------------------

def test_runs_without_first_ts_still_render():
    """Records with first_ts=None should render '—' not crash."""
    activity = [
        {"source": "a", "target": "b", "count": 1,
         "first_ts": None, "last_ts": None, "alert_count": 0},
    ]
    html = events_to_html([], edge_activity=activity)
    assert '<section class="session-activity">' in html
    # The em-dash fallback from _format_ts
    assert "—" in html


def test_malformed_records_are_skipped_not_crashed():
    """Missing source/target records should be silently dropped."""
    activity = [
        {"source": None, "target": "b", "count": 1,
         "first_ts": 100.0, "last_ts": 100.0, "alert_count": 0},
        {"source": "a", "target": "b", "count": 2,
         "first_ts": 100.0, "last_ts": 101.0, "alert_count": 0},
    ]
    html = events_to_html([], edge_activity=activity)
    # The good record still rendered
    assert '<section class="session-activity">' in html
    assert "2 fires" in html


# ---------------------------------------------------------------------------
# Session Activity tabs — Edge Activity + Chronological Log
# ---------------------------------------------------------------------------
#
# The Session Activity section holds two peer INFO-level views as
# tabs: Edge Activity (aggregate) and Chronological Log (raw stream).
# Tab switching is handled by switchTab() — no localStorage, no
# persistence, purely per-view.

_CHRON_TAB_PANEL = '<div class="tab-panel active" data-tab="log">'
_CHRON_TAB_PANEL_INACTIVE = '<div class="tab-panel" data-tab="log">'
_EDGE_TAB_PANEL_ACTIVE = '<div class="tab-panel active" data-tab="edges">'


def test_chronological_log_renders_when_session_log_provided():
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b"), (101.5, "b", "c")],
        session_log_total=2,
    )
    assert '<section class="session-activity">' in html
    assert 'Chronological Log<span class="tab-count">' in html
    # With only session_log (no edge_activity), the log tab is active
    assert _CHRON_TAB_PANEL in html
    assert html.count('<li class="session-log-entry">') == 2


def test_session_activity_absent_when_nothing_provided():
    """Legacy callers passing no edge_activity AND no session_log
    must not see the Session Activity section at all. Tab label text
    may appear in embedded JS comments — check for rendered elements
    instead."""
    html = events_to_html([])
    assert '<section class="session-activity">' not in html
    assert 'Chronological Log<span class="tab-count">' not in html
    assert 'Edge Activity<span class="tab-count">' not in html
    # And the top-level main-tab nav should not render when there's
    # no Session Activity to navigate to.
    assert '<nav class="main-tabs"' not in html


def test_session_activity_absent_when_both_empty():
    """Explicit empty lists behave the same as None — no section."""
    html = events_to_html([], edge_activity=[], session_log=[])
    assert '<section class="session-activity">' not in html


def test_chronological_tab_count_badge_uses_session_log_total():
    """When the engine's buffer capped the log, the Chronological
    Log tab's count badge must show the TRUE total, not the
    truncated tail. Users shouldn't see a '5' badge when 100
    events actually fired."""
    html = events_to_html(
        [],
        session_log=[(i, "a", "b") for i in range(5)],
        session_log_total=100,
    )
    # The badge adjacent to "Chronological Log" shows the true count
    import re
    m = re.search(
        r'Chronological Log<span class="tab-count">(\d+)</span>',
        html,
    )
    assert m is not None, "Chronological Log tab badge not found"
    assert m.group(1) == "100"


def test_session_log_truncation_banner_shows_when_capped():
    html = events_to_html(
        [],
        session_log=[(i, "a", "b") for i in range(5)],
        session_log_total=100,
    )
    assert "Showing 5 most recent of 100 total events" in html
    assert "95 earlier events omitted" in html


def test_session_log_no_truncation_banner_when_complete():
    """If we have the full stream, no truncation note should appear."""
    html = events_to_html(
        [],
        session_log=[(i, "a", "b") for i in range(3)],
        session_log_total=3,
    )
    assert "most recent of" not in html
    assert "earlier event" not in html


def test_session_log_handles_none_total_defaults_to_len():
    """Legacy callers / standalone exports may pass session_log but
    no session_log_total. The renderer should fall back to len()."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b"), (101.0, "b", "c")],
        # session_log_total omitted
    )
    assert "most recent of" not in html
    # Tab badge equals the implied total
    import re
    m = re.search(
        r'Chronological Log<span class="tab-count">(\d+)</span>',
        html,
    )
    assert m and m.group(1) == "2"


def test_session_log_entries_in_input_order():
    """The engine appends to _session_log chronologically; the
    renderer preserves that order (doesn't re-sort). This is a
    regression guard — if someone later decides to sort entries,
    the chronological view breaks."""
    log = [
        (100.0, "first", "second"),
        (50.0,  "second", "third"),   # earlier timestamp but later position
        (200.0, "third", "fourth"),
    ]
    html = events_to_html([], session_log=log, session_log_total=3)
    # Positions of each route name in the HTML
    pos_first = html.find(">first<")
    pos_second = html.find(">second<")
    pos_third = html.find(">third<")
    assert pos_first > 0 and pos_second > 0 and pos_third > 0
    assert pos_first < pos_second < pos_third


def test_switch_tab_js_embedded():
    """The tab onclick handlers call switchTab() — must be defined
    in the embedded <script> so it resolves at browser parse time.
    Kept decoupled from the per-report dataset so a future test
    that passes a minimal dataset still gets the full JS wiring."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b")],
        session_log_total=1,
    )
    assert "function switchTab(tabName)" in html
    assert 'onclick="switchTab(\'log\')"' in html


def test_edge_activity_is_default_tab_when_both_datasets_present():
    """When both edge_activity and session_log are passed, Edge
    Activity is the default active tab — aggregate view scans
    faster than a long chronological list."""
    html = events_to_html(
        [],
        edge_activity=[
            {"source": "a", "target": "b", "count": 3,
             "first_ts": 100.0, "last_ts": 102.0, "alert_count": 0},
        ],
        session_log=[(100.0, "a", "b")],
        session_log_total=1,
    )
    # Edge Activity tab is active
    assert 'class="tab active" data-tab="edges"' in html
    # Chronological Log tab is present but inactive
    assert 'class="tab" data-tab="log"' in html
    # Corresponding panel states
    assert _EDGE_TAB_PANEL_ACTIVE in html
    assert _CHRON_TAB_PANEL_INACTIVE in html


def test_only_tab_is_active_when_other_dataset_missing():
    """If only session_log is provided, the Chronological Log tab
    is the sole (and therefore active) tab. Same for edge_activity
    alone."""
    # Session log only
    h1 = events_to_html(
        [],
        session_log=[(100.0, "a", "b")],
        session_log_total=1,
    )
    assert 'class="tab active" data-tab="log"' in h1
    assert 'data-tab="edges"' not in h1

    # Edge activity only
    h2 = events_to_html(
        [],
        edge_activity=[
            {"source": "a", "target": "b", "count": 1,
             "first_ts": 100.0, "last_ts": 100.0, "alert_count": 0},
        ],
    )
    assert 'class="tab active" data-tab="edges"' in h2
    assert 'data-tab="log"' not in h2


def test_clean_run_has_no_severity_filter_chips():
    """Clean run (no alerts): the Coordination Failures section
    should show the clean-run banner but NOT the filter chip bar
    above it — there's nothing to filter. The Session Activity
    section below is independent and still shows."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b")],
        session_log_total=1,
    )
    # Clean-run banner present
    assert "No coordination failures detected" in html
    # No severity chips on clean run
    assert 'data-severity="critical"' not in html
    assert 'data-severity="warning"' not in html
    assert 'data-severity="all"' not in html
    # Session Activity section still renders
    assert '<section class="session-activity">' in html


def test_alert_run_keeps_severity_filter_chips():
    """Alert run: Total / Critical / Warning chips filter cards,
    just like before. The tabs below are independent."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        ts = 1000.0
        for i in range(15):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        events = engine.get_recent_events()
        html = events_to_html(
            events,
            session_log=list(engine._session_log),
            session_log_total=engine._session_log_total,
        )
        # Severity chips present
        assert 'data-severity="all"' in html
        assert 'data-severity="critical"' in html
        assert 'data-severity="warning"' in html
        # Session Activity tabs also present
        assert '<section class="session-activity">' in html
        assert 'Chronological Log<span class="tab-count">' in html
    finally:
        engine.shutdown()


def test_engine_session_log_capped():
    """_MAX_SESSION_LOG caps the in-memory buffer. _session_log_total
    keeps the uncapped count so the HTML can show 'showing N of M'."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 99999,
        "critical_threshold": 99999,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        # Shrink the cap for the test so we don't need 501 events
        engine._MAX_SESSION_LOG = 10
        ts = 1000.0
        for i in range(25):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.001))
        # Cap was 10, we ingested 25 → buffer holds 10, total is 25
        assert len(engine._session_log) == 10
        assert engine._session_log_total == 25
        # The retained tail should be the most recent 10 events
        last_ts = engine._session_log[-1][0]
        first_retained_ts = engine._session_log[0][0]
        assert last_ts > first_retained_ts
    finally:
        engine.shutdown()


def test_shutdown_emits_session_activity_into_html():
    """End-to-end: engine writes an HTML report with the Session
    Activity section containing both tabs (Edge Activity default,
    Chronological Log secondary). This is the integration seam —
    if any step in the snapshot-through-render chain breaks, this
    test catches it."""
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": td,
            "warning_threshold": 1000,
            "critical_threshold": 10000,
            "per_edge_limit": 99999,
            "global_limit": 99999,
        })
        ts = 1000.0
        engine.ingest(InteractionEvent("planner", "coder", ts))
        engine.ingest(InteractionEvent("coder", "qa", ts + 0.01))
        engine.ingest(InteractionEvent("qa", "planner", ts + 0.02))
        run_dir = engine.logger.run_dir
        engine.shutdown()

        with open(os.path.join(run_dir, "report.html"), encoding="utf-8") as f:
            html = f.read()
        assert '<section class="session-activity">' in html
        # Both tabs present — Edge Activity active by default
        assert 'class="tab active" data-tab="edges"' in html
        assert 'class="tab" data-tab="log"' in html
        # Three session log entries
        assert html.count('<li class="session-log-entry">') == 3
        # Arrow rendering for each delegation
        assert "planner" in html and "coder" in html and "qa" in html


def test_tabs_do_not_break_severity_filter():
    """Regression: adding the tabs must not change the behavior of
    clicking Critical / Warning chips on the Coordination Failures
    section. Those still filter the article.event cards exactly
    as before via filterEvents()."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        ts = 1000.0
        for i in range(15):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        events = engine.get_recent_events()
        html = events_to_html(
            events,
            session_log=list(engine._session_log),
            session_log_total=engine._session_log_total,
        )
        # filterEvents() is still wired up for severity chips
        assert "function filterEvents(severity)" in html
        assert "onclick=\"filterEvents('critical')\"" in html
        assert "onclick=\"filterEvents('warning')\"" in html
        # switchTab() is ALSO wired up — two separate handlers
        assert "function switchTab(tabName)" in html
    finally:
        engine.shutdown()


def test_coordination_failures_is_section_title():
    """Regression: the primary-signal section is titled with
    domain-specific language ('Coordination Failures' per the
    Sentry/Snyk pattern), not generic 'Summary'. Ties back to the
    README tagline."""
    html = events_to_html([])
    assert "<h2 class=\"section-title\">Coordination Failures</h2>" in html
    # Old generic "Summary" heading should not appear as an h2
    assert "<h2 style=\"margin:0\">Summary</h2>" not in html


# ---------------------------------------------------------------------------
# Top-level (main) tabs — Coordination Failures | Session Activity
# ---------------------------------------------------------------------------
#
# The main tabs sit above both sections. Clicking a tab hides the other
# section entirely — per Sentry's Issues-first model (primary signal on
# the default view, supplemental context one click away).

_MAIN_TAB_FAILURES_ACTIVE = 'class="main-tab active"\n            data-main="failures"'
_MAIN_TAB_ACTIVITY_INACTIVE = 'class="main-tab"\n            data-main="activity"'


def test_main_tabs_render_when_session_activity_has_data():
    """Both top-level tabs appear with 'failures' active by default
    (primary signal) and 'activity' inactive until the user clicks."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b")],
        session_log_total=1,
    )
    assert '<nav class="main-tabs"' in html
    assert 'data-main="failures"' in html
    assert 'data-main="activity"' in html
    # Default active = failures (primary signal)
    assert 'class="main-tab active"\n            data-main="failures"' in html
    assert 'class="main-tab"\n            data-main="activity"' in html
    # Matching panel state
    assert '<div class="main-tab-panel active" data-main="failures"' in html
    assert '<div class="main-tab-panel" data-main="activity"' in html


def test_main_tabs_skipped_when_no_session_activity_data():
    """No edge_activity and no session_log → no main tabs. Coordination
    Failures section renders standalone, as in minimal reports."""
    html = events_to_html([])
    assert '<nav class="main-tabs"' not in html
    assert 'switchMainTab' in html  # JS is still embedded (harmless)
    # Coordination Failures content still appears
    assert '<section class="coordination-failures">' in html


def test_main_tab_badge_shows_counts():
    """Badges next to each tab label show displayed card count +
    session event total. 0-values are omitted so clean runs don't
    show a noisy '0' badge."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        ts = 1000.0
        for i in range(15):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        events = engine.get_recent_events()
        log_snap = list(engine._session_log)
        total = engine._session_log_total
        html = events_to_html(events, session_log=log_snap, session_log_total=total)
        # Both badges present
        assert 'Coordination Failures<span class="main-tab-badge">' in html
        assert 'Session Activity<span class="main-tab-badge">' in html
        # Session Activity badge value equals the true total
        import re
        m = re.search(
            r'Session Activity<span class="main-tab-badge">(\d+)</span>',
            html,
        )
        assert m and int(m.group(1)) == total
    finally:
        engine.shutdown()


def test_main_tab_badge_omitted_on_clean_run():
    """When there are 0 failures, the failures badge shouldn't render
    — no noisy '0' beside the label. The Session Activity badge still
    shows because activity is not zero."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b"), (101.0, "b", "c")],
        session_log_total=2,
    )
    # Session Activity badge present
    assert 'Session Activity<span class="main-tab-badge">' in html
    # Coordination Failures has no badge (0 cards)
    # The tab label is naked, immediately followed by the closing tag
    assert 'Coordination Failures<span class="main-tab-badge">' not in html


def test_switch_main_tab_js_wired():
    """The main tab onclick calls switchMainTab(). Must be defined
    in the embedded JS block so it resolves at parse time."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b")],
        session_log_total=1,
    )
    assert "function switchMainTab(tabName)" in html
    assert 'onclick="switchMainTab(\'failures\')"' in html
    assert 'onclick="switchMainTab(\'activity\')"' in html


# ---------------------------------------------------------------------------
# Chronological Log severity highlighting
# ---------------------------------------------------------------------------

def test_log_row_highlighted_when_timestamp_matches_critical_alert():
    """A session log entry whose timestamp matches a displayed
    CRITICAL CoordinationEvent gets the entry-critical class →
    light red background so users can see WHICH row triggered it."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    # Alert fires at timestamp=101.0
    event = _make_event(
        severity=AlertSeverity.CRITICAL,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=15,
        ts=101.0,
    )
    session_log = [
        (100.0, "a", "b"),   # not an alert row
        (101.0, "a", "b"),   # matches the alert timestamp → HIGHLIGHTED
        (102.0, "a", "b"),   # not an alert row
    ]
    html = events_to_html(
        [event],
        session_log=session_log,
        session_log_total=3,
    )
    # Exactly one row with entry-critical class (the 101.0 row)
    assert html.count('<li class="session-log-entry entry-critical">') == 1
    # Hint appears explaining the highlighting
    assert "Highlighted rows fired an alert" in html


def test_log_row_highlighted_when_timestamp_matches_warning_alert():
    """WARNING event → entry-warning class (orange) on matching row.
    No critical `<li>` rows should render (the hint legend does contain
    both color swatches as a reference — that's expected, so we check
    the `<li>` element specifically)."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    event = _make_event(
        severity=AlertSeverity.WARNING,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=6,
        ts=105.5,
    )
    session_log = [
        (100.0, "a", "b"),
        (105.5, "a", "b"),   # WARNING here
    ]
    html = events_to_html([event], session_log=session_log, session_log_total=2)
    assert html.count('<li class="session-log-entry entry-warning">') == 1
    # No critical <li> rows — only warnings matched. (Hint legend
    # always includes both swatches for reference; that's fine.)
    assert '<li class="session-log-entry entry-critical">' not in html


def test_log_critical_wins_over_warning_on_same_timestamp():
    """If two events share a timestamp (e.g. cycle + repetitive
    detectors firing on the same delegation), the row gets the
    critical class, not warning. Matches the Edge Activity rule."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    crit = _make_event(
        severity=AlertSeverity.CRITICAL,
        failure_class=FailureClass.CYCLIC_DELEGATION,
        edge_key="a->b",
        occurrences=10,
        ts=100.0,
        fp="sha256:crit",
    )
    warn = _make_event(
        severity=AlertSeverity.WARNING,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=6,
        ts=100.0,  # same timestamp
        fp="sha256:warn",
    )
    session_log = [(100.0, "a", "b")]
    html = events_to_html([crit, warn], session_log=session_log, session_log_total=1)
    assert '<li class="session-log-entry entry-critical">' in html
    assert '<li class="session-log-entry entry-warning">' not in html


def test_log_no_highlight_when_no_alerts_fired():
    """Clean run → no entries get highlighted, no hint line appears."""
    html = events_to_html(
        [],
        session_log=[(100.0, "a", "b"), (101.0, "b", "c")],
        session_log_total=2,
    )
    assert 'entry-critical">' not in html
    assert 'entry-warning">' not in html
    assert "Highlighted rows fired an alert" not in html


def test_log_highlight_hint_mentions_highlighted_count():
    """The hint line above the log tells readers how many rows are
    highlighted so they can orient before scanning."""
    from agentsonar._core.schema import AlertSeverity, FailureClass
    event = _make_event(
        severity=AlertSeverity.CRITICAL,
        failure_class=FailureClass.REPETITIVE_DELEGATION,
        edge_key="a->b",
        occurrences=15,
        ts=101.0,
    )
    session_log = [
        (100.0, "a", "b"),
        (101.0, "a", "b"),   # HIGHLIGHTED
        (102.0, "a", "b"),
    ]
    html = events_to_html([event], session_log=session_log, session_log_total=3)
    # Says "1 row of 3 shown" — singular "row"
    assert "1 row of 3 shown" in html


def test_session_activity_badge_sums_edge_counts_when_no_session_log():
    """Regression for the bug where the Session Activity main-tab
    badge showed `len(edge_activity)` (number of EDGES) instead of
    the total EVENT count when session_log was absent. The badge
    represents 'how much activity happened', which for edge-only
    reports must be the sum of per-edge fire counts, not the number
    of distinct edges."""
    activity = [
        {"source": "a", "target": "b", "count": 5,
         "first_ts": 100.0, "last_ts": 105.0},
        {"source": "b", "target": "c", "count": 12,
         "first_ts": 105.0, "last_ts": 110.0},
    ]
    # No session_log passed — fall-through path
    html = events_to_html([], edge_activity=activity)
    import re
    m = re.search(
        r'Session Activity<span class="main-tab-badge">(\d+)</span>',
        html,
    )
    assert m is not None, "Session Activity badge not found"
    # Expect 17 (5 + 12), NOT 2 (the edge count)
    assert m.group(1) == "17", f"badge shows {m.group(1)!r}, expected '17' (sum of counts)"


def test_log_entries_escape_html_injection_in_agent_names():
    """Defense: agent names sometimes come from user-provided strings
    (LangGraph node names, CrewAI role names). The renderer must
    escape HTML so a malicious agent name can't inject script tags
    or markup into the report."""
    malicious = "<script>alert(1)</script>"
    html = events_to_html(
        [],
        session_log=[(100.0, malicious, "&amp;safe")],
        session_log_total=1,
    )
    # Raw tag must NOT appear — browser would execute it
    assert "<script>alert(1)</script>" not in html
    # Escaped form must be present
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html


def test_log_entries_render_with_nan_timestamps():
    """Defensive: a NaN timestamp from a broken integration shouldn't
    crash the renderer. _format_ts returns '—' as a safe fallback."""
    nan = float("nan")
    html = events_to_html([], session_log=[(nan, "a", "b")], session_log_total=1)
    # Row renders
    assert '<li class="session-log-entry">' in html
    # Time cell shows em-dash fallback
    assert "—" in html


def test_log_highlight_survives_end_to_end_shutdown():
    """End-to-end: run engine, shutdown, open the report file, verify
    that alert-firing rows are highlighted. Catches any breakage in
    the timestamp-match chain from engine → snapshot → renderer."""
    with tempfile.TemporaryDirectory() as td:
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": td,
            "warning_threshold": 3,
            "critical_threshold": 5,
            "per_edge_limit": 99999,
            "global_limit": 99999,
        })
        ts = 1000.0
        for i in range(15):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        run_dir = engine.logger.run_dir
        engine.shutdown()

        with open(os.path.join(run_dir, "report.html"), encoding="utf-8") as f:
            html = f.read()
        # At least one row is highlighted with a severity class
        assert (
            "session-log-entry entry-critical" in html
            or "session-log-entry entry-warning" in html
        )
        # The explanatory hint is present
        assert "Highlighted rows fired an alert" in html
