"""
Tests for the memorable run-slug generator.

The slug is a Docker-style `adjective-noun` pair used to label each
session directory. Key invariants these tests lock in place:

  1. Determinism — same seed always produces same slug.
  2. Filesystem safety — every possible slug is lowercase ASCII,
     hyphenated, and contains no characters that would need escaping
     on Windows, macOS, or Linux.
  3. Stable wordlist size — both lists must be exactly 64 entries so
     the "low 6 bits of byte N" indexing has no modulo bias.
  4. Reasonable distribution — a smallish sample of seeds should
     produce a decent spread of slugs (not everything hashing to the
     same pair).
"""
from __future__ import annotations

import re
import string

import pytest

from agentsonar._output._slug import (
    _ADJECTIVES,
    _NOUNS,
    generate_slug,
    iter_all_slugs,
)


class TestDeterminism:
    """Same seed → same slug, forever. This is the property that makes
    slugs correlatable with session_ids across reruns, log files, and
    debugging sessions."""

    def test_same_seed_produces_same_slug(self):
        for seed in ("a1b2c3", "65efaff4bf554327", "hello-world", ""):
            first = generate_slug(seed)
            second = generate_slug(seed)
            assert first == second

    def test_different_seeds_usually_produce_different_slugs(self):
        """Two different seeds should map to different slugs in the
        common case. There's a collision probability of ~1/4096 per
        pair, so we test with 20 seeds and accept that a few MIGHT
        collide — but they shouldn't all collapse to one slug."""
        seeds = [f"session-{i:04d}" for i in range(20)]
        slugs = {generate_slug(s) for s in seeds}
        assert len(slugs) >= 15, (
            f"20 seeds produced only {len(slugs)} unique slugs — "
            "the distribution is suspiciously narrow"
        )

    def test_known_seed_to_slug_mappings(self):
        """Pin a handful of (seed, slug) pairs so accidental changes
        to the word lists or the hashing algorithm are caught. If
        this test fails, someone edited _ADJECTIVES or _NOUNS — either
        intentionally (update the expected values) or accidentally
        (revert the change).
        """
        # These specific mappings were computed from the v0.1.0
        # word lists. If the word lists change, these need to update.
        known = {
            "a" * 16: "clear-canyon",
            "b" * 16: "purple-hawk",
            "c" * 16: "fierce-forest",
            "d" * 16: "daring-rhino",
        }
        for seed, expected in known.items():
            actual = generate_slug(seed)
            assert actual == expected, (
                f"seed {seed!r}: expected {expected!r}, got {actual!r}"
            )


class TestFilesystemSafety:
    """Every possible slug must be safe as a filesystem path component
    on Windows, macOS, and Linux. No spaces, no special chars, no
    uppercase, no non-ASCII. Just `[a-z]+-[a-z]+`."""

    _PATTERN = re.compile(r"^[a-z]+-[a-z]+$")

    def test_generated_slug_matches_format_regex(self):
        for seed in ("foo", "bar", "baz", "qux", "quux"):
            slug = generate_slug(seed)
            assert self._PATTERN.match(slug), (
                f"slug {slug!r} does not match [a-z]+-[a-z]+"
            )

    def test_every_possible_slug_is_filesystem_safe(self):
        """Enumerate ALL 4096 possible slugs and assert each is safe."""
        for slug in iter_all_slugs():
            assert self._PATTERN.match(slug), f"unsafe slug: {slug!r}"
            # No character outside lowercase ASCII + single hyphen
            for ch in slug:
                assert ch in string.ascii_lowercase + "-", (
                    f"slug {slug!r} contains unsafe char {ch!r}"
                )

    def test_slug_contains_exactly_one_hyphen(self):
        for slug in iter_all_slugs():
            assert slug.count("-") == 1, (
                f"slug {slug!r} has != 1 hyphens"
            )


class TestWordLists:
    """The adjective and noun lists must remain exactly 64 entries each.
    The `generate_slug` implementation indexes by taking the low 6 bits
    of a SHA-256 digest byte, which assumes 64 entries (2**6). Drifting
    to 63 or 65 silently introduces modulo bias."""

    def test_adjective_count_is_64(self):
        assert len(_ADJECTIVES) == 64

    def test_noun_count_is_64(self):
        assert len(_NOUNS) == 64

    def test_adjectives_are_unique(self):
        assert len(set(_ADJECTIVES)) == len(_ADJECTIVES)

    def test_nouns_are_unique(self):
        assert len(set(_NOUNS)) == len(_NOUNS)

    def test_all_adjectives_are_lowercase_ascii(self):
        for word in _ADJECTIVES:
            assert word.isascii()
            assert word.islower()
            assert all(c.isalpha() for c in word)

    def test_all_nouns_are_lowercase_ascii(self):
        for word in _NOUNS:
            assert word.isascii()
            assert word.islower()
            assert all(c.isalpha() for c in word)


class TestEdgeCases:

    def test_empty_seed(self):
        """Empty string is a valid input — must return some slug,
        not raise."""
        slug = generate_slug("")
        assert TestFilesystemSafety._PATTERN.match(slug)

    def test_none_seed_is_handled(self):
        """None is normalized to empty string rather than crashing.
        Callers passing Optional[str] shouldn't have to check first."""
        slug = generate_slug(None)  # type: ignore[arg-type]
        assert TestFilesystemSafety._PATTERN.match(slug)

    def test_long_seed(self):
        """Very long seeds are fine — SHA-256 accepts any input length."""
        slug = generate_slug("x" * 10_000)
        assert TestFilesystemSafety._PATTERN.match(slug)

    def test_unicode_seed(self):
        """Unicode in the seed is fine — it's UTF-8 encoded before hashing."""
        slug = generate_slug("你好-мир-🌙")
        assert TestFilesystemSafety._PATTERN.match(slug)
