"""
Public API surface tests.

Every other test file imports from internal paths like
`agentsonar._core.engine`. This file pins down the PUBLIC import surface:
what `pip install agentsonar` users actually type. If any of these tests
break, we've silently changed the 2-line promise — that's a breaking
change that needs a conscious decision.

Tests here cover:
  * `from agentsonar import AgentSonarListener, AgentSonarCallback, __version__`
  * `__all__` lists only the 2 classes (plus __version__)
  * `AgentSonarListener()` raises a clear RuntimeError when crewai is
    not installed (test env does NOT have crewai — the dev install is
    `--extra langgraph` only).
  * `AgentSonarCallback()` can be instantiated cleanly when
    langchain-core IS installed (which it is in the dev env).
"""
from __future__ import annotations

import pytest


# ---------------------------------------------------------------------------
# Import surface
# ---------------------------------------------------------------------------

class TestPublicImportSurface:

    def test_top_level_imports_exist(self):
        """Both public classes and __version__ must be importable from `agentsonar`."""
        from agentsonar import (  # noqa: F401
            AgentSonarCallback,
            AgentSonarListener,
            __version__,
        )

    def test_version_is_string(self):
        from agentsonar import __version__
        assert isinstance(__version__, str)
        # Sanity: semver-ish
        assert len(__version__.split(".")) >= 2

    def test_all_list_matches_expected_public_surface(self):
        """The public __all__ must NOT leak internal symbols. Any addition
        to this list is a conscious API change — update the list AND
        this test together. Current public surface:

          AgentSonarListener   — CrewAI integration (2-line promise)
          AgentSonarCallback   — LangGraph integration (2-line promise)
          CustomAdapter        — generic orchestrator adapter class,
                                 exposed so design partners can type-hint
                                 their return values from
                                 `monitor_orchestrator()`
          monitor              — LangGraph graph wrapper that auto-merges
                                 AgentSonar without overriding existing
                                 user callbacks
          monitor_orchestrator — generic custom-orchestrator entry point
                                 (returns a CustomAdapter)
          PreventError         — exception raised by adapters when Prevent
                                 Mode trips (opt-in via `prevent={...}`)
          PreventionResult     — frozen dataclass attached to PreventError
                                 carrying the tripped failure's details
          __version__          — SDK version string
        """
        import agentsonar

        assert set(agentsonar.__all__) == {
            "AgentSonarListener",
            "AgentSonarCallback",
            "CustomAdapter",
            "monitor",
            "monitor_orchestrator",
            "PreventError",
            "PreventionResult",
            "__version__",
        }

    def test_no_private_names_accidentally_exposed(self):
        """No underscore-prefixed symbols should be in the public namespace
        (except dunders like __version__)."""
        import agentsonar

        exposed = [
            name for name in agentsonar.__all__
            if name.startswith("_") and not name.startswith("__")
        ]
        assert exposed == [], f"private symbols leaked into __all__: {exposed}"

    def test_internal_subpackages_are_underscore_prefixed(self):
        """Subpackages that are implementation details must be underscore-
        prefixed so users know not to rely on them."""
        import agentsonar
        import pkgutil

        # Walk the top-level package — every non-underscore subpackage is
        # public API. The current design has ZERO public subpackages.
        public_subpackages = [
            m.name for m in pkgutil.iter_modules(agentsonar.__path__)
            if not m.name.startswith("_") and m.ispkg
        ]
        assert public_subpackages == [], (
            f"unexpected public subpackages: {public_subpackages} — "
            f"implementation details should live under _core/_output/_integrations"
        )


# ---------------------------------------------------------------------------
# Optional-dependency guards
# ---------------------------------------------------------------------------

class TestOptionalDependencyGuards:

    def test_listener_raises_runtime_error_when_crewai_missing(self):
        """When `crewai` is NOT installed, AgentSonarListener() must
        raise RuntimeError with an actionable message. Regression:
        any future code path that lets instantiation succeed would
        mean the next line (wiring up setup_listeners) fails with a
        confusing AttributeError instead.

        This test SKIPS when `crewai` is actually importable — the
        dev environment may have it installed (e.g. when running
        CrewAI example validation), in which case the guard never
        fires and there's nothing to assert. When crewai is NOT
        installed the test runs normally.
        """
        import importlib.util
        if importlib.util.find_spec("crewai") is not None:
            pytest.skip(
                "crewai is installed in this environment; the "
                "optional-dependency guard can't be exercised here. "
                "Run in a venv without crewai to test this path."
            )

        from agentsonar import AgentSonarListener

        with pytest.raises(RuntimeError) as excinfo:
            AgentSonarListener()

        msg = str(excinfo.value)
        # The error must tell the user HOW to fix it
        assert "crewai" in msg.lower()
        assert "pip install" in msg
        assert "agentsonar[crewai]" in msg

    def test_callback_works_when_langchain_installed(self):
        """Dev env installs `[langgraph]`, which pulls in langchain-core.
        AgentSonarCallback() must instantiate and expose the expected
        public interface (engine attribute, shutdown method)."""
        from agentsonar import AgentSonarCallback

        cb = AgentSonarCallback(config={"file_output": False, "console_output": False})
        try:
            # Must expose .engine for advanced users who call
            # sonar.engine.get_recent_events() (documented in README)
            assert hasattr(cb, "engine")
            # Must expose shutdown for explicit teardown
            assert callable(getattr(cb, "shutdown", None))
            # Must expose get_summary so users can inspect the run
            summary = cb.get_summary()
            assert isinstance(summary, dict)
            assert "total_events" in summary
            assert "alerts_raised" in summary
        finally:
            cb.shutdown()

    def test_imported_listener_class_is_the_internal_one(self):
        """Sanity: the symbol exposed from `agentsonar` must BE the class
        from `agentsonar._integrations.crewai_listener`. No accidental
        stubs or re-wraps."""
        from agentsonar import AgentSonarListener
        from agentsonar._integrations.crewai_listener import (
            AgentSonarListener as InternalListener,
        )
        assert AgentSonarListener is InternalListener

    def test_imported_callback_class_is_the_internal_one(self):
        """Same sanity check for AgentSonarCallback."""
        from agentsonar import AgentSonarCallback
        from agentsonar._integrations.langgraph_callback import (
            AgentSonarCallback as InternalCallback,
        )
        assert AgentSonarCallback is InternalCallback


# ---------------------------------------------------------------------------
# monitor() public API — auto-merges AgentSonar into user callbacks
# ---------------------------------------------------------------------------

class _FakeCallbackA:
    """User's own callback — must survive monitor() wrapping."""


class _FakeCallbackB:
    """Another user callback — must also survive."""


class _FakeGraph:
    """Mock LangGraph CompiledGraph that records the config passed to invoke."""
    def __init__(self):
        self.last_config = None

    def invoke(self, input, config=None, **kwargs):
        self.last_config = config
        return {"result": "ok"}

    def stream(self, input, config=None, **kwargs):
        self.last_config = config
        return iter([])


class TestMonitorPublicAPI:
    """The monitor() helper is the RECOMMENDED integration path for
    users who already pass callbacks to graph.invoke() — it auto-merges
    AgentSonar into their list without clobbering anything.

    These tests pin that behavior so we can't accidentally break the
    promise that monitor() never overrides user callbacks."""

    def test_monitor_importable_from_top_level(self):
        """monitor must be accessible as `from agentsonar import monitor`."""
        from agentsonar import monitor
        assert callable(monitor)

    def test_monitor_preserves_existing_user_callbacks(self):
        """The critical invariant: if the user passes their own callbacks,
        monitor must APPEND AgentSonar to that list, not replace it."""
        from agentsonar import monitor

        graph = _FakeGraph()
        wrapped = monitor(graph, config={
            "file_output": False,
            "console_output": False,
        })

        user_cb_a = _FakeCallbackA()
        user_cb_b = _FakeCallbackB()
        wrapped.invoke(
            {"input": "x"},
            config={"callbacks": [user_cb_a, user_cb_b]},
        )

        callbacks = graph.last_config.get("callbacks", [])
        # Both user callbacks survive
        assert user_cb_a in callbacks, "user callback A was dropped by monitor"
        assert user_cb_b in callbacks, "user callback B was dropped by monitor"
        # AgentSonar got appended
        from agentsonar import AgentSonarCallback
        sonar_callbacks = [cb for cb in callbacks if isinstance(cb, AgentSonarCallback)]
        assert len(sonar_callbacks) == 1, (
            f"expected exactly 1 AgentSonarCallback, got {len(sonar_callbacks)}"
        )
        # Total count: 2 user + 1 sonar = 3
        assert len(callbacks) == 3

    def test_monitor_adds_callback_when_user_has_none(self):
        """When the user passes no config at all, monitor still injects
        AgentSonar on its own — zero-config path."""
        from agentsonar import AgentSonarCallback, monitor

        graph = _FakeGraph()
        wrapped = monitor(graph, config={
            "file_output": False,
            "console_output": False,
        })

        wrapped.invoke({"input": "x"})

        callbacks = graph.last_config.get("callbacks", [])
        assert len(callbacks) == 1
        assert isinstance(callbacks[0], AgentSonarCallback)

    def test_monitor_does_not_leak_across_invokes(self):
        """Two successive invokes must each get a fresh merged config —
        AgentSonar should be in BOTH, and user callbacks for one call
        shouldn't leak into the other."""
        from agentsonar import AgentSonarCallback, monitor

        graph = _FakeGraph()
        wrapped = monitor(graph, config={
            "file_output": False,
            "console_output": False,
        })

        # First invoke: user callback A
        cb_a = _FakeCallbackA()
        wrapped.invoke({"input": "1"}, config={"callbacks": [cb_a]})
        first_callbacks = list(graph.last_config["callbacks"])
        assert cb_a in first_callbacks

        # Second invoke: user callback B only
        cb_b = _FakeCallbackB()
        wrapped.invoke({"input": "2"}, config={"callbacks": [cb_b]})
        second_callbacks = list(graph.last_config["callbacks"])
        # B is present
        assert cb_b in second_callbacks
        # A should NOT leak into the second call
        assert cb_a not in second_callbacks
        # Both calls have AgentSonar
        for calls in (first_callbacks, second_callbacks):
            assert any(isinstance(cb, AgentSonarCallback) for cb in calls)

    def test_monitor_exposes_sonar_attribute(self):
        """Users can reach the wrapped callback via `graph.sonar` for
        things like `events = graph.sonar.engine.get_recent_events()`."""
        from agentsonar import AgentSonarCallback, monitor

        graph = _FakeGraph()
        wrapped = monitor(graph, config={
            "file_output": False,
            "console_output": False,
        })
        assert hasattr(wrapped, "sonar")
        assert isinstance(wrapped.sonar, AgentSonarCallback)
        wrapped.sonar.shutdown()
