"""
Performance benchmarks for the detection engine.

Pins per-event latency budgets so future changes that quietly
regress the hot path are caught. These are off by default — run
explicitly with `pytest -m performance` or
`pytest tests/test_performance.py`.

Budget philosophy
-----------------
The numbers here are BUDGETS, not tight measurements. They're set
looser than what a modern dev machine actually produces so noisy CI
runners don't create false failures. Real observed p50 on a dev
machine with default engine config is ~50-200 microseconds; we assert
< 2 milliseconds to leave slack for slow CI, Python warm-up, and
Windows scheduler jitter.

Scenarios
---------
  clean sequential     — healthy workload, no cycles, no anomalies
  3-node cycle         — Layer 3 cycle detection firing continuously
  hot edge + baselines — Layer 2 decay scan over many known edges

Scenarios use **production-realistic engine config** — SCC runs on
its own periodic schedule (every 10 s / 50 events), not on every
event. Stressing an unrealistic config wouldn't catch meaningful
regressions, and it inflates the budget so much that actual
production regressions hide in the slack.

What we DON'T measure
---------------------
  * Absolute throughput (ops/sec) — too environment-dependent
  * Memory usage — bounded by _MAX_RECENT_* caps
  * End-to-end crew latency — AgentSonar is observable, not a workload

If a test here fails, DON'T relax the budget blindly. Figure out
which change regressed the hot path and fix it or document the
tradeoff in the commit message.
"""
from __future__ import annotations

import time

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent


def _make_engine() -> DetectionEngine:
    """Engine with production defaults plus output disabled.

    Output disabled: we measure detection cost, not I/O cost.
    Defaults: Layer 1 limits, Layer 5 schedule, all thresholds
    match the shipping defaults so these numbers reflect what
    real users experience.
    """
    return DetectionEngine({
        "file_output": False,
        "console_output": False,
    })


def _percentile(sorted_values: list[float], p: float) -> float:
    """Linear-interpolation percentile for a pre-sorted list. p in [0, 100]."""
    if not sorted_values:
        return 0.0
    k = (len(sorted_values) - 1) * (p / 100.0)
    lo = int(k)
    hi = min(lo + 1, len(sorted_values) - 1)
    frac = k - lo
    return sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac


def _run_and_measure(
    engine: DetectionEngine,
    events: list[InteractionEvent],
) -> dict[str, float]:
    """Ingest each event one at a time, return latency stats in microseconds."""
    latencies_ns: list[int] = []
    for event in events:
        t0 = time.perf_counter_ns()
        engine.ingest(event)
        t1 = time.perf_counter_ns()
        latencies_ns.append(t1 - t0)

    latencies_us = sorted(ns / 1_000.0 for ns in latencies_ns)
    return {
        "count": float(len(latencies_us)),
        "mean": sum(latencies_us) / len(latencies_us),
        "p50": _percentile(latencies_us, 50),
        "p95": _percentile(latencies_us, 95),
        "p99": _percentile(latencies_us, 99),
        "max": latencies_us[-1],
    }


def _print_stats(scenario: str, stats: dict[str, float]) -> None:
    """Emit latency stats visibly (with `pytest -s` or via capsys.disabled)."""
    print(
        f"\n  [{scenario}] n={int(stats['count'])}  "
        f"mean={stats['mean']:.1f}µs  "
        f"p50={stats['p50']:.1f}µs  "
        f"p95={stats['p95']:.1f}µs  "
        f"p99={stats['p99']:.1f}µs  "
        f"max={stats['max']:.1f}µs"
    )


# -----------------------------------------------------------------------
# Per-event overhead budgets
# -----------------------------------------------------------------------

class TestPerEventOverhead:

    @pytest.mark.performance
    def test_clean_sequential_flow(self, capsys):
        """Healthy workload — 100 distinct agents in a sequential
        chain, 1000 total events. No cycle fires, no anomaly fires.
        This is the cheapest ingest path and the one production
        users hit most often.
        """
        engine = _make_engine()
        now = 1000.0
        # 100-agent chain traversed 10 times = 1000 sequential events.
        # Each pass reuses the same edges so the coordination graph
        # stays small (~100 edges), avoiding the O(E) blowup of
        # creating 1000 distinct edges.
        events = []
        for pass_idx in range(10):
            for i in range(99):
                events.append(InteractionEvent(
                    f"agent_{i}", f"agent_{i+1}",
                    now + pass_idx * 1.0 + i * 0.001,
                ))

        stats = _run_and_measure(engine, events)
        with capsys.disabled():
            _print_stats("clean sequential (100 agents, 10 passes)", stats)

        # Loose budgets for CI slack
        assert stats["p50"] < 2_000, (
            f"p50 latency {stats['p50']:.1f}µs exceeds 2ms budget — "
            "clean-path ingest regressed"
        )
        assert stats["p99"] < 10_000, (
            f"p99 latency {stats['p99']:.1f}µs exceeds 10ms budget"
        )

        engine.shutdown()

    @pytest.mark.performance
    def test_3node_cycle_flow(self, capsys):
        """A classic 3-agent cycle traversed 300 times. Layer 3 cycle
        detection fires on every edge insertion that closes the loop,
        so this stresses the BFS-per-event path."""
        engine = _make_engine()
        now = 1000.0
        events = []
        for i in range(300):
            events.append(InteractionEvent("planner", "researcher", now + i * 0.01))
            events.append(InteractionEvent("researcher", "reviewer", now + i * 0.01 + 0.003))
            events.append(InteractionEvent("reviewer", "planner", now + i * 0.01 + 0.006))

        stats = _run_and_measure(engine, events)
        with capsys.disabled():
            _print_stats("3-node cycle (300 rotations)", stats)

        assert stats["p50"] < 2_000, (
            f"p50 latency {stats['p50']:.1f}µs exceeds 2ms budget — "
            "Layer 3 cycle detection regressed"
        )
        assert stats["p99"] < 15_000, (
            f"p99 latency {stats['p99']:.1f}µs exceeds 15ms budget"
        )

        engine.shutdown()

    @pytest.mark.performance
    def test_hot_edge_with_baselines(self, capsys):
        """100 baseline edges + one edge hammered 500 times. Layer 2's
        exponential decay detector does an O(E) scan of all edges on
        every anomaly check — this is the scenario where that cost
        shows up most prominently."""
        engine = _make_engine()
        now = 1000.0
        events = []
        # 100 baseline edges to give Layer 2 something to scan
        for i in range(100):
            events.append(InteractionEvent(
                f"src_{i}", f"tgt_{i}", now + i * 0.001,
            ))
        # Then hammer one edge
        base = now + 1.0
        for i in range(500):
            events.append(InteractionEvent(
                "hot_src", "hot_tgt", base + i * 0.001,
            ))

        stats = _run_and_measure(engine, events)
        with capsys.disabled():
            _print_stats("hot edge + 100 baselines", stats)

        # Layer 2 scan is O(E) so we allow more slack
        assert stats["p50"] < 3_000, (
            f"p50 latency {stats['p50']:.1f}µs exceeds 3ms budget — "
            "Layer 2 decay detector regressed"
        )
        assert stats["p99"] < 20_000, (
            f"p99 latency {stats['p99']:.1f}µs exceeds 20ms budget"
        )

        engine.shutdown()

    @pytest.mark.performance
    def test_mean_under_1ms_on_clean_path(self, capsys):
        """Sanity: the MEAN per-event cost on a healthy workload
        should be comfortably below 1ms. If this fails, something
        in the hot path has grown an expensive call."""
        engine = _make_engine()
        now = 1000.0
        # Short chain, 500 events
        events = []
        for pass_idx in range(10):
            for i in range(49):
                events.append(InteractionEvent(
                    f"a_{i}", f"a_{i+1}",
                    now + pass_idx * 1.0 + i * 0.001,
                ))

        stats = _run_and_measure(engine, events)
        with capsys.disabled():
            _print_stats("clean mean (50 agents)", stats)

        assert stats["mean"] < 1_000, (
            f"mean ingest latency {stats['mean']:.1f}µs exceeds 1ms — "
            "the hot path has a fixed cost that's too high"
        )

        engine.shutdown()


# -----------------------------------------------------------------------
# Startup + shutdown overhead
# -----------------------------------------------------------------------

class TestLifecycleOverhead:

    @pytest.mark.performance
    def test_engine_startup_under_200ms(self, tmp_path):
        """The 2-line promise means users feel startup cost on every
        `AgentSonarCallback()` / `AgentSonarListener()` instantiation.
        Construction + logger file creation must stay fast — above
        ~200ms and users notice a pause before their crew starts."""
        import time as _time
        t0 = _time.perf_counter_ns()
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": str(tmp_path),
        })
        t1 = _time.perf_counter_ns()
        try:
            elapsed_ms = (t1 - t0) / 1_000_000.0
            assert elapsed_ms < 200, (
                f"DetectionEngine startup took {elapsed_ms:.1f}ms — "
                "the 2-line promise feels slow"
            )
        finally:
            engine.shutdown()

    @pytest.mark.performance
    def test_shutdown_under_1s(self, tmp_path):
        """Shutdown fires check_recoveries, generates JSON + HTML
        reports, prints the banner, and closes the logger. Under 1s
        is comfortable for teardown — users won't notice."""
        import time as _time
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": str(tmp_path),
        })
        # Ingest enough events that auto-export has something real
        # to serialize (tests the realistic-shutdown path, not the
        # empty-report degenerate case).
        now = 1000.0
        for i in range(100):
            engine.ingest(InteractionEvent(
                f"src_{i % 10}", f"tgt_{(i + 1) % 10}", now + i * 0.001,
            ))

        t0 = _time.perf_counter_ns()
        engine.shutdown()
        t1 = _time.perf_counter_ns()
        elapsed_ms = (t1 - t0) / 1_000_000.0
        assert elapsed_ms < 1_000, (
            f"shutdown() took {elapsed_ms:.1f}ms — teardown path regressed"
        )
