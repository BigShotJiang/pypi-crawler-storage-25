"""
Round-2 audit regression tests.

Each test documents a specific bug that a second-pass audit found
and fixes made in response. If any test here fails, one of the
round-2 fixes has regressed.

Bug list (bug # matches the audit report):

  1. LangGraph callback leaks `_previous_node` across invoke() calls
     when LangGraph doesn't emit a metadata-less root start event
  2. Rate limiter global counter polluted by suppressed per-edge events
  3. Inhibition wrongly silences CRITICAL repetitive with WARNING cycle
  5. SCC analyzer returns `set` for agents; JSONL logs it as a repr string
  8. `_logged_cycles` grows unbounded in long sessions
  9. Retention sort uses lex-on-name which inverts under DST fall-back
 10. Retention regex doesn't match numeric-suffix-disambiguated runs
 11. Shutdown latch state leak when logger._closed is True at entry
 13. Non-string source/target in alert.details crashes compute_fingerprint
 18. `_MonitoredGraph._merge_config` shallow-copies config sub-dicts
 20. CrewAI listener double-registration on re-init
 21. CrewAI listener init-order fd leak if super().__init__ raises
"""
from __future__ import annotations

import json
import os
import time

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import Alert, InteractionEvent
from agentsonar._core.detectors.rate_limiter import SlidingWindowLimiter
from agentsonar._core.detectors.scc_analyzer import PeriodicSCCAnalyzer
from agentsonar._core.schema import (
    AlertSeverity,
    CoordinationEvent,
    FailureClass,
    Topology,
    alert_to_coordination_event,
    inhibit_subsumed_events,
)
from agentsonar._output.terminal import SonarLogger


# =========================================================================
# Bug 1 — LangGraph callback leaks _previous_node across invoke() calls
# =========================================================================

class TestLangGraphInvokeIsolation:
    """When a user reuses an `AgentSonarCallback` across multiple
    `graph.invoke()` calls, no phantom edge may form between the
    last node of invoke N and the first node of invoke N+1. Round 1
    relied on LangGraph emitting a metadata-less root `on_chain_start`
    between invokes to reset `_previous_node`, but that signal isn't
    guaranteed across LangGraph versions or execution modes.

    Fix: also detect new invocations by watching for a chain_start
    with `parent_run_id=None` (= root run), which IS guaranteed.
    """

    def test_parent_run_id_none_resets_previous_node(self):
        pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback

        cb = AgentSonarCallback(config={"file_output": False, "console_output": False})

        # Run 1: simulate an invocation where ONLY chain_start events
        # arrive, none with metadata=None. Round 1 would have left
        # `_previous_node` set after the run.
        cb.on_chain_start(
            serialized={"name": "planner"},
            inputs={},
            run_id="run-1-step-1",
            parent_run_id=None,  # root of invoke 1
            metadata={"langgraph_node": "planner", "langgraph_step": 1},
        )
        cb.on_chain_start(
            serialized={"name": "researcher"},
            inputs={},
            run_id="run-1-step-2",
            parent_run_id="run-1-step-1",  # child
            metadata={"langgraph_node": "researcher", "langgraph_step": 2},
        )
        assert cb._previous_node == "researcher"

        # Run 2: a fresh invoke with parent_run_id=None (new root)
        # but no metadata=None event first. The callback MUST reset
        # `_previous_node` on seeing the new root.
        cb.on_chain_start(
            serialized={"name": "analyst"},
            inputs={},
            run_id="run-2-step-1",
            parent_run_id=None,  # ROOT — new invocation
            metadata={"langgraph_node": "analyst", "langgraph_step": 1},
        )
        cb.on_chain_start(
            serialized={"name": "writer"},
            inputs={},
            run_id="run-2-step-2",
            parent_run_id="run-2-step-1",
            metadata={"langgraph_node": "writer", "langgraph_step": 2},
        )

        # No phantom `researcher -> analyst` edge should exist
        summary = cb.get_summary()
        edges = summary.get("edge_counts", {})
        assert "researcher->analyst" not in edges, (
            "phantom edge leaked across invoke() boundary"
        )
        # The legitimate `analyst -> writer` edge SHOULD be there
        assert "analyst->writer" in edges

        cb.shutdown()


# =========================================================================
# Bug 2 — Rate limiter global counter polluted by suppressed per-edge
# =========================================================================

class TestRateLimiterGlobalCounterSemantics:
    """Before the fix: once the per-edge limiter latched on edge A,
    subsequent A events were silently suppressed — BUT still counted
    toward the global window. A runaway A could push the global
    counter to the global_limit, and the next legitimate B event
    would fire a misleading `global_rate_exceeded` attributed to B.

    Fix: when the per-edge limiter is tripped for the current event,
    do NOT increment the global counter. "Global rate" means events
    that cleared the per-edge gate.
    """

    def test_suppressed_per_edge_events_do_not_pollute_global_counter(self):
        """The global window's `current_count` should only reflect
        events that cleared the per-edge gate — not suppressed ones.
        We check the internal counter directly rather than waiting
        for the global limit to fire, because the global limit could
        get "correctly" triggered by the legitimate per-edge fires
        and mask the pollution bug.
        """
        limiter = SlidingWindowLimiter(
            window_size=60.0,
            per_edge_limit=5,
            global_limit=1_000_000,  # so high the global NEVER fires
        )
        now = 1000.0

        # Burst 50 events on edge A. Per-edge fires ONCE on event ~6,
        # then the tripped latch suppresses the rest.
        for i in range(50):
            limiter.check("a", "b", now + i * 0.01)

        # Count how many events the per-edge limiter actually let through
        edge_window = limiter._edges[("a", "b")]
        per_edge_fired_once = edge_window.tripped  # proves per-edge fired

        # The global counter should NOT contain all 50 events. The
        # intended policy: global counts events that cleared their
        # per-edge gate. Under the bug, global.current_count == 50.
        global_count = limiter._global.current_count
        assert per_edge_fired_once
        assert global_count <= 10, (
            f"global counter polluted by suppressed per-edge events: "
            f"expected ≤ ~10 (pre-latch events), got {global_count}"
        )


# =========================================================================
# Bug 3 — Inhibition wrongly silences CRITICAL repetitive with WARNING cycle
# =========================================================================

class TestInhibitionRespectsEventSeverity:
    """A WARNING-severity cycle must not inhibit a CRITICAL repetitive
    alert. The whole point of inhibition is that the root-cause
    signal subsumes the symptom — but if the "root cause" is less
    severe than the "symptom", we're actively hiding the more
    urgent signal. The fix requires the cycle's severity to be
    >= the repetitive's severity for inhibition to apply."""

    def _cycle_event(
        self, agents, severity=AlertSeverity.WARNING,
    ) -> CoordinationEvent:
        topo = Topology(
            agents_involved=agents,
            interaction_pattern="circular",
            agent_count=len(agents),
            occurrence_count=5,
            edge_frequency={},
        )
        return alert_to_coordination_event(
            alert=Alert(
                pattern="cycle",
                severity=severity.value,
                details={},
                timestamp=1000.0,
            ),
            session_id="s",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            topology=topo,
        )

    def _repetitive_event(
        self, agents, severity=AlertSeverity.WARNING,
    ) -> CoordinationEvent:
        topo = Topology(
            agents_involved=agents,
            interaction_pattern="one_directional",
            agent_count=len(agents),
            occurrence_count=100,
            edge_frequency={f"{agents[0]}->{agents[1]}": 100},
        )
        return alert_to_coordination_event(
            alert=Alert(
                pattern="edge_anomaly",
                severity=severity.value,
                details={},
                timestamp=1000.0,
            ),
            session_id="s",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            topology=topo,
        )

    def test_warning_cycle_does_not_inhibit_critical_repetitive(self):
        """Regression: the hot edge is MORE severe than the cycle
        that contains it. The user needs to see the CRITICAL."""
        cycle = self._cycle_event(("a", "b"), severity=AlertSeverity.WARNING)
        rep = self._repetitive_event(("a", "b"), severity=AlertSeverity.CRITICAL)
        result = inhibit_subsumed_events([cycle, rep])
        # Both should survive — the WARNING cycle cannot inhibit a CRITICAL
        classes = {e.failure_class for e in result}
        assert FailureClass.REPETITIVE_DELEGATION in classes, (
            "CRITICAL repetitive was incorrectly inhibited by WARNING cycle"
        )

    def test_critical_cycle_still_inhibits_warning_repetitive(self):
        """Counter-test: equal-or-greater severity cycles DO still
        inhibit repetitive edges. The round-1 behavior for the common
        case is preserved."""
        cycle = self._cycle_event(
            ("a", "b", "c"), severity=AlertSeverity.CRITICAL,
        )
        rep = self._repetitive_event(
            ("a", "b"), severity=AlertSeverity.WARNING,
        )
        result = inhibit_subsumed_events([cycle, rep])
        classes = [e.failure_class for e in result]
        assert FailureClass.REPETITIVE_DELEGATION not in classes, (
            "CRITICAL cycle failed to inhibit WARNING repetitive "
            "(round-1 behavior regressed)"
        )

    def test_equal_severity_cycle_still_inhibits_repetitive(self):
        cycle = self._cycle_event(
            ("a", "b", "c"), severity=AlertSeverity.CRITICAL,
        )
        rep = self._repetitive_event(
            ("a", "b"), severity=AlertSeverity.CRITICAL,
        )
        result = inhibit_subsumed_events([cycle, rep])
        classes = [e.failure_class for e in result]
        assert FailureClass.REPETITIVE_DELEGATION not in classes


# =========================================================================
# Bug 5 — SCC analyzer returns `set` for agents, logged as repr string
# =========================================================================

class TestSccAgentsAreList:
    """`PeriodicSCCAnalyzer.maybe_run` used to store the raw set of
    agents in the result dict. When the logger serialized the sweep
    event to JSONL via `json.dumps(..., default=str)`, sets got
    stringified to their Python repr (`"{'alice', 'bob'}"`), not a
    JSON array. Machine consumers parsing the timeline lost agent
    structure for SCC sweep events."""

    def test_scc_agents_serializes_as_json_array(self):
        import networkx as nx
        graph = nx.DiGraph()
        graph.add_edge("alice", "bob", count=3)
        graph.add_edge("bob", "alice", count=3)

        scc = PeriodicSCCAnalyzer(interval_seconds=0, interval_events=1)
        results = scc.maybe_run(graph, 1000.0)
        assert results is not None
        assert len(results) == 1

        # The `agents` field must be a list (JSON-serializable as
        # an array), not a set (which would serialize as a repr string).
        agents = results[0]["agents"]
        assert isinstance(agents, list), (
            f"scc agents field is {type(agents).__name__}, expected list"
        )
        assert set(agents) == {"alice", "bob"}

        # Prove it round-trips through json.dumps correctly
        blob = json.dumps({"components": results}, default=str)
        parsed = json.loads(blob)
        scc_agents_json = parsed["components"][0]["agents"]
        assert isinstance(scc_agents_json, list)
        assert set(scc_agents_json) == {"alice", "bob"}


# =========================================================================
# Bug 8 — _logged_cycles unbounded growth
# =========================================================================

class TestLoggedCyclesBounded:
    """`_logged_cycles` is a set used to dedupe "cycle found" log
    lines. Never pruned. Long-running sessions that see many distinct
    cycle fingerprints (multi-tenant, large graphs, test suites)
    grow it monotonically. The fix caps it just like the other
    bounded buffers on the engine."""

    def test_logged_cycles_respects_cap(self):
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 10_000,  # never escalate
            "hard_weight_limit": 100_000.0,
            "per_edge_limit": 100_000,
        })
        # Shrink the cap so the test doesn't need thousands of cycles
        engine._MAX_LOGGED_CYCLES = 20

        # Create 100 distinct 3-node cycles. Each iteration uses
        # unique agent names so a new fingerprint enters _logged_cycles.
        now = time.time()
        for i in range(100):
            a = f"planner_{i}"
            b = f"researcher_{i}"
            c = f"reviewer_{i}"
            engine.ingest(InteractionEvent(a, b, now + i * 0.01))
            engine.ingest(InteractionEvent(b, c, now + i * 0.01 + 0.001))
            engine.ingest(InteractionEvent(c, a, now + i * 0.01 + 0.002))

        assert len(engine._logged_cycles) <= 20, (
            f"_logged_cycles grew past cap: len={len(engine._logged_cycles)}"
        )
        engine.shutdown()


# =========================================================================
# Bug 10 — Retention regex doesn't match numeric-suffix-disambiguated dirs
# =========================================================================

class TestRetentionMatchesSuffixedRuns:
    """When the slug + timestamp collide, `_create_session_directory`
    appends a `-1`, `-2`, ... numeric suffix. Round 1 added that
    logic but never updated `_RUN_DIR_PATTERN`, so retention IGNORED
    the suffixed runs — they leaked forever."""

    def test_retention_prunes_suffixed_runs(self, tmp_path):
        from agentsonar._output.terminal import _RUN_DIR_PATTERN
        # Pre-create a mix of base and suffixed run dir names
        root = tmp_path / "agentsonar_logs"
        root.mkdir()
        names = [
            "run-2026-04-11_10-00-00-brave-otter",
            "run-2026-04-11_10-00-00-brave-otter-1",
            "run-2026-04-11_10-00-00-brave-otter-2",
            "run-2026-04-11_10-00-00-clear-canyon-1",
        ]
        for name in names:
            assert _RUN_DIR_PATTERN.match(name), (
                f"regex failed to match {name!r} — "
                "disambiguated runs leak past retention"
            )

    def test_retention_sweeps_suffixed_runs_in_practice(self, tmp_path):
        """End-to-end: create a number of runs, force a collision by
        pre-creating a run dir, and verify the collision-disambiguated
        dir is still pruned by retention."""
        # Pre-seed with several old runs
        root = tmp_path / "agentsonar_logs"
        root.mkdir()
        for i in range(5):
            (root / f"run-2020-01-01_00-00-0{i}-ancient-ember").mkdir()
        # Also pre-seed a suffixed one that should be prunable
        (root / "run-2020-01-01_00-00-00-ancient-ember-1").mkdir()

        # Create one fresh run with keep_runs=2
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=2,
            session_id="a" * 16,
        )
        logger.close()

        # Count how many runs remain — should be exactly 2
        # (the current one + one preserved preseed)
        remaining = [
            p for p in root.iterdir()
            if p.is_dir() and p.name.startswith("run-")
        ]
        assert len(remaining) == 2, (
            f"expected 2 run dirs after pruning, got {len(remaining)}: "
            f"{[p.name for p in remaining]}"
        )


# =========================================================================
# Bug 11 — Shutdown latch state leak when logger._closed is True at entry
# =========================================================================

class TestShutdownLatchStateLeak:
    """If user code directly closes the logger (via `engine.logger.close()`)
    and THEN calls `engine.shutdown()`, the shutdown short-circuits on
    the `logger._closed` check without setting `_shutdown_requested`.
    The engine is then stuck in a weird state where `_shutdown_requested`
    is False but shutdown is effectively done.

    Fix: set `_shutdown_requested = True` on every short-circuit path."""

    def test_shutdown_latches_after_direct_logger_close(self, tmp_path):
        engine = DetectionEngine({
            "log_dir": str(tmp_path),
            "file_output": False,
            "console_output": False,
        })
        engine.ingest(InteractionEvent("a", "b", time.time()))

        # Directly close the logger (bypassing shutdown)
        engine.logger.close()
        assert engine.logger._closed

        # Now call shutdown — it should short-circuit BUT still set
        # the _shutdown_requested latch so the engine's state is
        # consistent.
        engine.shutdown()
        assert engine._shutdown_requested, (
            "_shutdown_requested was not set after shutdown() "
            "short-circuited on a pre-closed logger"
        )


# =========================================================================
# Bug 13 — Non-string source/target in alert.details crashes compute_fingerprint
# =========================================================================

class TestNonStringAgentCoercion:
    """If an alert's `details` contains non-string `source`/`target`
    (from a buggy builder, a test fixture, or future code that
    stores ints for agent ids), `compute_fingerprint` used to crash
    on `','.join(key_agents)`. The fix coerces via `str()` so the
    alert still produces a valid CoordinationEvent."""

    def test_non_string_source_target_coerce_to_string(self):
        alert = Alert(
            pattern="edge_anomaly",
            severity="WARNING",
            details={"source": 42, "target": 99, "event_count": 5},
            timestamp=1000.0,
        )
        # Must not crash. The resulting event should have a valid
        # fingerprint derived from the string representation.
        event = alert_to_coordination_event(
            alert=alert,
            session_id="s",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
        )
        assert event.coordination_fingerprint.startswith("sha256:")

    def test_none_source_target_coerce(self):
        """None values in the details shouldn't crash either."""
        alert = Alert(
            pattern="edge_anomaly",
            severity="WARNING",
            details={"source": None, "target": None},
            timestamp=1000.0,
        )
        event = alert_to_coordination_event(
            alert=alert,
            session_id="s",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
        )
        assert event.coordination_fingerprint.startswith("sha256:")


# =========================================================================
# Bug 18 — _merge_config shallow-copies (shared sub-dicts)
# =========================================================================

class TestMergeConfigIsolation:
    """`_MonitoredGraph._merge_config` used a shallow `dict(config)`
    copy. Nested mutable values (configurable, metadata, tags lists)
    were shared with the user's original dict. If LangGraph or any
    other callback mutated them, the user's object was affected.

    Fix: deep-copy the callbacks list (was already done) AND don't
    mutate nested structures that we forward through."""

    def test_merge_config_does_not_mutate_user_callbacks_list(self):
        pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import (
            AgentSonarCallback,
            _MonitoredGraph,
        )

        class _FakeGraph:
            def __init__(self):
                self.last_config = None

            def invoke(self, input, config=None, **kwargs):
                self.last_config = config
                return {}

        graph = _FakeGraph()
        cb = AgentSonarCallback(config={"file_output": False, "console_output": False})
        wrapped = _MonitoredGraph(graph, cb)

        class UserCallback:
            pass

        user_callbacks = [UserCallback()]
        user_config = {"callbacks": user_callbacks}

        wrapped.invoke({"x": 1}, config=user_config)

        # User's original callbacks list must be UNCHANGED
        assert len(user_callbacks) == 1
        assert not any(isinstance(cb, AgentSonarCallback) for cb in user_callbacks)

        # But the wrapped invoke saw a merged config with BOTH callbacks
        merged = graph.last_config.get("callbacks", [])
        assert len(merged) == 2
        assert any(isinstance(cb, AgentSonarCallback) for cb in merged)

        cb.shutdown()


# =========================================================================
# Bugs 20 & 21 — CrewAI listener init order + double-registration
# =========================================================================
# These are documented as latent for the round-2 audit. Without
# crewai installed in the test env we can't exercise them end-to-end,
# so the fix + smoke tests go in via a stub BaseEventListener.

class TestCrewAIListenerGuards:
    """Smoke tests for the CrewAI listener guards. The listener is
    not fully testable without the crewai package in the dev env,
    but we can verify:

      1. Double `setup_listeners` on the same bus does NOT register
         duplicate handlers (bug 20)
      2. An exception from `super().__init__()` doesn't leak the
         already-created engine (bug 21)
    """

    def _make_listener_class_with_stub_base(self):
        """Build an AgentSonarListener subclass whose base class is
        our own stub — simulates crewai being installed."""
        from agentsonar._core.engine import DetectionEngine
        from agentsonar._integrations import crewai_listener as cl

        # The listener module imports BaseEventListener at module
        # load time, which falls back to `object` when crewai isn't
        # installed. For this test we monkey-patch it with a stub
        # base class that tracks init calls.
        class StubBaseEventListener:
            def __init__(self):
                pass

        return StubBaseEventListener

    def test_double_setup_listeners_does_not_double_register(self, monkeypatch):
        """Regression: calling `setup_listeners` twice on the same
        bus used to register event handlers twice, causing every
        ingest to fire the engine twice. Fix: guard with a latch."""
        from agentsonar._integrations import crewai_listener as cl

        # Force the listener to think crewai is installed for this test
        monkeypatch.setattr(cl, "_HAS_CREWAI", True)

        class StubBus:
            def __init__(self):
                self.handlers: list = []

            def on(self, event_type):
                def decorator(fn):
                    self.handlers.append((event_type, fn))
                    return fn
                return decorator

        # Build a minimal AgentSonarListener that doesn't actually
        # inherit from crewai's base class
        class FakeListener:
            def __init__(self):
                self.engine = DetectionEngine({
                    "file_output": False,
                    "console_output": False,
                })
                self._listeners_registered = False

            # Copy the real listener's setup_listeners body,
            # expecting the guard to be in place
            setup_listeners = cl.AgentSonarListener.setup_listeners

        listener = FakeListener()
        bus = StubBus()

        # Call setup_listeners TWICE — the guard should prevent the
        # second call from registering additional handlers.
        listener.setup_listeners(bus)
        first_count = len(bus.handlers)
        listener.setup_listeners(bus)
        second_count = len(bus.handlers)

        assert first_count == second_count, (
            f"double setup_listeners registered extra handlers: "
            f"first={first_count}, second={second_count}"
        )
        listener.engine.shutdown()


# =========================================================================
# Bug 9 — Retention DST safety via mtime sort
# =========================================================================

class TestRetentionDstSafety:
    """Directory names encode LOCAL time, which means on DST fall-back
    (02:59 → 02:00) two runs an hour apart can have the same or
    inverted sort keys. Retention using lex-sort-on-name would keep
    the wrong runs. Fix: sort by directory mtime instead — mtime
    comes from the filesystem and is always monotonic regardless
    of wall-clock shenanigans."""

    def test_retention_sorts_by_mtime_not_name(self, tmp_path):
        """Create two dirs with an inverted name→mtime order and
        verify retention keeps the newest (by mtime), not the
        lex-largest (by name)."""
        root = tmp_path / "agentsonar_logs"
        root.mkdir()
        # Create dir1 first, then dir2 — mtime(dir1) < mtime(dir2)
        dir1 = root / "run-2026-04-11_02-30-00-zulu-zebra"
        dir1.mkdir()
        time.sleep(0.01)
        dir2 = root / "run-2026-04-11_02-00-00-alpha-ant"  # earlier NAME, later mtime
        dir2.mkdir()

        # Run a new logger with keep_runs=2 — should retain both
        # pre-existing dirs + the new one = 3 total, so one gets
        # pruned. We want the OLDER-by-mtime one (dir1, despite its
        # later name) pruned — the newer-by-mtime one (dir2) kept.
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=2,
            session_id="c" * 16,
        )
        logger.close()

        remaining = {p.name for p in root.iterdir() if p.is_dir()}
        # The current run is always kept (self-protect)
        assert os.path.basename(logger.run_dir) in remaining
        # dir2 (newer mtime) must survive
        assert dir2.name in remaining, (
            f"dir2 (newer mtime) was pruned but older dir1 survived — "
            f"retention is lex-sorting instead of mtime-sorting"
        )
        # dir1 (older mtime despite later name) must be gone
        assert dir1.name not in remaining
