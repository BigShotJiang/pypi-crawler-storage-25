"""
Unit tests for the AgentSonar event schema.
"""
from __future__ import annotations

import dataclasses
import json

import pytest

from agentsonar._core.models import Alert
from agentsonar._core.schema import (
    AlertSeverity,
    CoordinationEvent,
    DownstreamImpact,
    FailureClass,
    ProviderError,
    Thresholds,
    Topology,
    alert_to_coordination_event,
    compute_fingerprint,
    dedupe_events_by_fingerprint,
    inhibit_subsumed_events,
)


# ---------------------------------------------------------------------------
# compute_fingerprint
# ---------------------------------------------------------------------------

class TestComputeFingerprint:

    def test_stable(self):
        fp1 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b", "c"])
        fp2 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b", "c"])
        assert fp1 == fp2

    def test_order_independent(self):
        fp1 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b", "c"])
        fp2 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["c", "b", "a"])
        fp3 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["b", "c", "a"])
        assert fp1 == fp2 == fp3

    def test_different_agents_different_fingerprint(self):
        fp1 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b"])
        fp2 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "c"])
        assert fp1 != fp2

    def test_different_failure_class_different_fingerprint(self):
        fp1 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b"])
        fp2 = compute_fingerprint(FailureClass.REPETITIVE_DELEGATION, ["a", "b"])
        assert fp1 != fp2

    def test_format(self):
        fp = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b"])
        assert fp.startswith("sha256:")
        assert len(fp) == len("sha256:") + 16

    def test_ordered_preserves_direction(self):
        """Regression: A→B repetitive and B→A repetitive are two distinct
        directed problems. With ordered=True, the fingerprint MUST differ
        between (a,b) and (b,a). Before the fix, both directions sorted
        to the same key and collapsed into one event in deduped views."""
        fp_ab = compute_fingerprint(
            FailureClass.REPETITIVE_DELEGATION, ["a", "b"], ordered=True,
        )
        fp_ba = compute_fingerprint(
            FailureClass.REPETITIVE_DELEGATION, ["b", "a"], ordered=True,
        )
        assert fp_ab != fp_ba, (
            "ordered=True must produce different fingerprints for A→B vs B→A"
        )

    def test_unordered_still_collapses_rotation_equivalents(self):
        """Cycles remain order-independent with the default ordered=False —
        ["a","b","c"] and ["c","b","a"] detected from different starting
        points should still share the same fingerprint."""
        fp1 = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["a", "b", "c"])
        fp2 = compute_fingerprint(
            FailureClass.CYCLIC_DELEGATION, ["c", "b", "a"], ordered=False,
        )
        assert fp1 == fp2

    def test_ordered_default_false_for_backward_compat(self):
        """Default must remain ordered=False so existing callers (cycles,
        SCCs, global rate) keep their existing fingerprints."""
        fp_default = compute_fingerprint(
            FailureClass.CYCLIC_DELEGATION, ["b", "a"],
        )
        fp_explicit = compute_fingerprint(
            FailureClass.CYCLIC_DELEGATION, ["b", "a"], ordered=False,
        )
        assert fp_default == fp_explicit


# ---------------------------------------------------------------------------
# CoordinationEvent.to_dict / to_json
# ---------------------------------------------------------------------------

def _minimal_event(**overrides) -> CoordinationEvent:
    base = dict(
        schema_version="0.1.0",
        event_id="evt-1",
        session_id="sess-1",
        timestamp=1000.0,
        event_type="coordination_failure",
        failure_class=FailureClass.CYCLIC_DELEGATION,
        severity=AlertSeverity.WARNING,
        coordination_fingerprint="sha256:abc123",
    )
    base.update(overrides)
    return CoordinationEvent(**base)


class TestToDict:

    def test_strips_none_fields(self):
        event = _minimal_event()
        d = event.to_dict()
        # Optional fields should be absent since they're None
        assert "topology" not in d
        assert "thresholds" not in d
        assert "provider_error" not in d
        assert "downstream_impact" not in d

    def test_converts_enums_to_values(self):
        event = _minimal_event()
        d = event.to_dict()
        assert d["failure_class"] == "cyclic_delegation"
        assert d["severity"] == "WARNING"

    def test_converts_tuples_to_lists(self):
        topology = Topology(
            agents_involved=("a", "b", "c"),
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=5,
            edge_frequency={"a->b": 5},
        )
        event = _minimal_event(topology=topology)
        d = event.to_dict()
        assert isinstance(d["topology"]["agents_involved"], list)
        assert d["topology"]["agents_involved"] == ["a", "b", "c"]

    def test_includes_populated_blocks(self):
        topology = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=10,
            edge_frequency={"a->b": 10},
        )
        event = _minimal_event(topology=topology)
        d = event.to_dict()
        assert "topology" in d
        assert d["topology"]["occurrence_count"] == 10

    def test_summary_placed_after_session_id(self):
        """summary must appear immediately after session_id in the dict output."""
        event = _minimal_event(summary="test summary")
        d = event.to_dict()
        keys = list(d.keys())
        session_idx = keys.index("session_id")
        summary_idx = keys.index("summary")
        assert summary_idx == session_idx + 1

    def test_timestamp_iso_field_present(self):
        """to_dict() emits a human-readable ISO 8601 timestamp next to the
        raw Unix epoch float. Machine consumers keep using `timestamp`;
        human readers get `timestamp_iso` for free."""
        event = _minimal_event(timestamp=1775885833.5288827)
        d = event.to_dict()
        assert "timestamp_iso" in d
        iso = d["timestamp_iso"]
        assert isinstance(iso, str)
        # ISO 8601 with timezone offset (UTC → "+00:00") — presence is
        # enough; we don't pin the exact formatting.
        assert "+00:00" in iso or iso.endswith("Z")
        assert "T" in iso
        # Must NOT have lost the original float
        assert d["timestamp"] == 1775885833.5288827

    def test_timestamp_iso_placed_after_timestamp(self):
        """Field ordering: timestamp_iso should sit immediately after
        timestamp so human readers can see both when scanning the JSON."""
        event = _minimal_event()
        d = event.to_dict()
        keys = list(d.keys())
        ts_idx = keys.index("timestamp")
        iso_idx = keys.index("timestamp_iso")
        assert iso_idx == ts_idx + 1

    def test_timestamp_iso_handles_weird_input(self):
        """Defensive: if the timestamp float is garbage (e.g. NaN or
        absurdly large), to_dict() must not raise. The ISO conversion
        falls back to str() so the report still generates."""
        import math
        # NaN
        event = _minimal_event(timestamp=float("nan"))
        d = event.to_dict()
        assert "timestamp_iso" in d
        assert isinstance(d["timestamp_iso"], str)
        # Huge value (past epoch overflow on some platforms)
        event = _minimal_event(timestamp=1e18)
        d = event.to_dict()
        assert "timestamp_iso" in d


class TestToJson:

    def test_produces_valid_json(self):
        event = _minimal_event()
        json_str = event.to_json()
        parsed = json.loads(json_str)
        assert parsed["event_id"] == "evt-1"
        assert parsed["failure_class"] == "cyclic_delegation"


# ---------------------------------------------------------------------------
# AlertSeverity
# ---------------------------------------------------------------------------

class TestAlertSeverity:

    def test_from_string_warning(self):
        assert AlertSeverity.from_string("WARNING") == AlertSeverity.WARNING

    def test_from_string_lowercase(self):
        assert AlertSeverity.from_string("warning") == AlertSeverity.WARNING

    def test_from_string_critical(self):
        assert AlertSeverity.from_string("CRITICAL") == AlertSeverity.CRITICAL

    def test_from_string_info(self):
        assert AlertSeverity.from_string("INFO") == AlertSeverity.INFO


# ---------------------------------------------------------------------------
# FailureClass enum
# ---------------------------------------------------------------------------

class TestFailureClass:

    def test_has_all_eight_values(self):
        expected = {
            "cyclic_delegation",
            "repetitive_delegation",
            "token_velocity_anomaly",
            "cascade_failure",
            "authority_violation",
            "resource_exhaustion",
            "deadlock",
            "agent_stall",
        }
        actual = {fc.value for fc in FailureClass}
        assert actual == expected


# ---------------------------------------------------------------------------
# alert_to_coordination_event
# ---------------------------------------------------------------------------

class TestAlertToCoordinationEvent:

    def test_basic_wrapping(self):
        alert = Alert(
            pattern="cycle",
            severity="WARNING",
            details={"fingerprint": ("a", "b"), "rotations": 5},
            timestamp=1000.0,
        )
        event = alert_to_coordination_event(
            alert=alert,
            session_id="sess-1",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            agents=["a", "b"],
        )
        assert event.session_id == "sess-1"
        assert event.failure_class == FailureClass.CYCLIC_DELEGATION
        assert event.severity == AlertSeverity.WARNING
        assert event.timestamp == 1000.0
        assert event.coordination_fingerprint.startswith("sha256:")

    def test_fingerprint_from_topology(self):
        alert = Alert(pattern="cycle", severity="WARNING", details={}, timestamp=1000.0)
        topology = Topology(
            agents_involved=("x", "y", "z"),
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=5,
            edge_frequency={},
        )
        event = alert_to_coordination_event(
            alert=alert,
            session_id="sess-1",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            topology=topology,
        )
        expected_fp = compute_fingerprint(FailureClass.CYCLIC_DELEGATION, ["x", "y", "z"])
        assert event.coordination_fingerprint == expected_fp

    def test_fingerprint_from_alert_details(self):
        alert = Alert(
            pattern="edge_anomaly",
            severity="WARNING",
            details={"source": "a", "target": "b"},
            timestamp=1000.0,
        )
        event = alert_to_coordination_event(
            alert=alert,
            session_id="sess-1",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
        )
        expected_fp = compute_fingerprint(FailureClass.REPETITIVE_DELEGATION, ["a", "b"])
        assert event.coordination_fingerprint == expected_fp

    def test_summary_generated(self):
        alert = Alert(pattern="cycle", severity="WARNING", details={}, timestamp=1000.0)
        topology = Topology(
            agents_involved=("researcher", "analyst"),
            interaction_pattern="circular",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={},
        )
        event = alert_to_coordination_event(
            alert=alert,
            session_id="sess-1",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            topology=topology,
        )
        assert event.summary
        assert "researcher" in event.summary
        assert "5 rotations" in event.summary


# ---------------------------------------------------------------------------
# _build_summary formatting per failure class / interaction pattern
# ---------------------------------------------------------------------------

class TestSummaryFormatting:
    """Regression tests for _build_summary — make sure each failure_class +
    interaction_pattern combination renders a human-readable one-liner that
    accurately represents the topology (no misleading path-as-cycle, etc)."""

    def _make_event(self, failure_class, topology):
        alert = Alert(pattern="x", severity="WARNING", details={}, timestamp=1000.0)
        return alert_to_coordination_event(
            alert=alert,
            session_id="sess-1",
            failure_class=failure_class,
            topology=topology,
        )

    def test_circular_cycle_closes_the_loop(self):
        """Regression: cycle summaries must show the closing edge so they
        read as cycles, not linear paths. Before the fix, a 3-agent cycle
        rendered as 'A -> B -> C' instead of 'A -> B -> C -> A'."""
        topology = Topology(
            agents_involved=("planner", "researcher", "reviewer"),
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=5,
            edge_frequency={},
        )
        event = self._make_event(FailureClass.CYCLIC_DELEGATION, topology)
        # Must close the loop
        assert "planner -> researcher -> reviewer -> planner" in event.summary
        assert "5 rotations" in event.summary

    def test_two_node_cycle_closes_the_loop(self):
        """A 2-node cycle A<->B should render as 'A -> B -> A'."""
        topology = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="circular",
            agent_count=2,
            occurrence_count=3,
            edge_frequency={},
        )
        event = self._make_event(FailureClass.CYCLIC_DELEGATION, topology)
        assert "a -> b -> a" in event.summary

    def test_scc_renders_as_arrow_chain_like_cycles(self):
        """Regression: SCC-detected cycles used to render with set
        notation `{a, b, c}` and "strongly_connected_component" as the
        interaction_pattern. Users found this confusing — both kinds of
        cycles were the same coordination failure from their
        perspective. SCC events now use interaction_pattern="circular"
        and render as arrow chains, identical to incremental cycles.

        The "path" for SCC is the sorted agent list — not the exact
        traversal order (which the sweep doesn't know) but close enough
        for the user to identify WHICH agents are stuck."""
        topology = Topology(
            agents_involved=("a", "b", "c"),
            # Unified with Layer 3: "circular", not "strongly_connected_component"
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=4,
            edge_frequency={},
        )
        event = self._make_event(FailureClass.CYCLIC_DELEGATION, topology)
        # Arrow chain like any other cycle
        assert "a -> b -> c -> a" in event.summary
        assert "4 rotations" in event.summary
        # No jargon
        assert "strongly_connected_component" not in event.summary
        assert "cycle group" not in event.summary

    def test_repetitive_uses_linear_arrow(self):
        """One-directional repetitive edges DO have order — linear arrow is right."""
        topology = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=11,
            edge_frequency={"a->b": 11},
        )
        event = self._make_event(FailureClass.REPETITIVE_DELEGATION, topology)
        assert "a -> b" in event.summary
        # No loop-closing — repetitive is not a cycle
        assert "a -> b -> a" not in event.summary
        assert "11 events" in event.summary

    def test_resource_exhaustion_linear(self):
        topology = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="throttled",
            agent_count=2,
            occurrence_count=0,
            edge_frequency={},
        )
        event = self._make_event(FailureClass.RESOURCE_EXHAUSTION, topology)
        assert "Resource exhaustion" in event.summary
        assert "a -> b" in event.summary

    def test_empty_agents_fallback(self):
        """Defensive: empty agents_involved shouldn't crash the summary."""
        topology = Topology(
            agents_involved=(),
            interaction_pattern="circular",
            agent_count=0,
            occurrence_count=0,
            edge_frequency={},
        )
        event = self._make_event(FailureClass.CYCLIC_DELEGATION, topology)
        assert event.summary  # non-empty
        # Doesn't matter what it says as long as it doesn't crash


# ---------------------------------------------------------------------------
# dedupe_events_by_fingerprint
# ---------------------------------------------------------------------------

def _make_event(
    fingerprint: str,
    severity: str,
    timestamp: float,
    summary: str = "",
) -> CoordinationEvent:
    """Build a minimal CoordinationEvent for dedupe tests."""
    return CoordinationEvent(
        schema_version="0.1.0",
        event_id=f"evt-{fingerprint}-{severity}-{timestamp}",
        session_id="sess-1",
        timestamp=timestamp,
        event_type="coordination_failure",
        failure_class=FailureClass.CYCLIC_DELEGATION,
        severity=AlertSeverity.from_string(severity),
        coordination_fingerprint=fingerprint,
        summary=summary,
    )


class TestDedupeByFingerprint:

    def test_empty_list(self):
        assert dedupe_events_by_fingerprint([]) == []

    def test_single_event_preserved(self):
        e = _make_event("sha256:a", "WARNING", 1000.0)
        result = dedupe_events_by_fingerprint([e])
        assert len(result) == 1
        assert result[0] is e

    def test_warning_then_critical_keeps_critical(self):
        """Same fingerprint escalating WARNING -> CRITICAL keeps only CRITICAL."""
        warning = _make_event("sha256:a", "WARNING", 1000.0, summary="w")
        critical = _make_event("sha256:a", "CRITICAL", 1001.0, summary="c")
        result = dedupe_events_by_fingerprint([warning, critical])
        assert len(result) == 1
        assert result[0].severity == AlertSeverity.CRITICAL
        assert result[0].summary == "c"

    def test_critical_then_warning_keeps_critical(self):
        """Order doesn't matter — CRITICAL always wins over WARNING."""
        critical = _make_event("sha256:a", "CRITICAL", 1000.0)
        warning = _make_event("sha256:a", "WARNING", 1001.0)
        result = dedupe_events_by_fingerprint([critical, warning])
        assert len(result) == 1
        assert result[0].severity == AlertSeverity.CRITICAL

    def test_same_severity_keeps_latest(self):
        """Two WARNINGs for same fingerprint — latest timestamp wins."""
        old = _make_event("sha256:a", "WARNING", 1000.0, summary="old")
        new = _make_event("sha256:a", "WARNING", 1001.0, summary="new")
        result = dedupe_events_by_fingerprint([old, new])
        assert len(result) == 1
        assert result[0].summary == "new"

    def test_different_fingerprints_all_kept(self):
        """Events with different fingerprints all survive dedup."""
        a = _make_event("sha256:a", "WARNING", 1000.0)
        b = _make_event("sha256:b", "CRITICAL", 1001.0)
        c = _make_event("sha256:c", "WARNING", 1002.0)
        result = dedupe_events_by_fingerprint([a, b, c])
        fps = {e.coordination_fingerprint for e in result}
        assert fps == {"sha256:a", "sha256:b", "sha256:c"}

    def test_mixed_scenario(self):
        """Real-world pattern: cycle escalates + unrelated warning.

        Input:
          - cycle fp1 @ WARNING
          - edge fp2 @ WARNING
          - cycle fp1 @ CRITICAL (escalation)
          - edge fp3 @ WARNING
        Expected output:
          - cycle fp1 @ CRITICAL (deduped)
          - edge fp2 @ WARNING
          - edge fp3 @ WARNING
        Total: 3 events (not 4).
        """
        events = [
            _make_event("sha256:cycle1", "WARNING", 1000.0),
            _make_event("sha256:edge2", "WARNING", 1001.0),
            _make_event("sha256:cycle1", "CRITICAL", 1002.0),
            _make_event("sha256:edge3", "WARNING", 1003.0),
        ]
        result = dedupe_events_by_fingerprint(events)
        assert len(result) == 3
        by_fp = {e.coordination_fingerprint: e for e in result}
        assert by_fp["sha256:cycle1"].severity == AlertSeverity.CRITICAL
        assert by_fp["sha256:edge2"].severity == AlertSeverity.WARNING
        assert by_fp["sha256:edge3"].severity == AlertSeverity.WARNING

    def test_does_not_mutate_input(self):
        """Dedupe is a pure function — input list is not modified."""
        events = [
            _make_event("sha256:a", "WARNING", 1000.0),
            _make_event("sha256:a", "CRITICAL", 1001.0),
        ]
        original_length = len(events)
        dedupe_events_by_fingerprint(events)
        assert len(events) == original_length

    def test_accepts_generator_input(self):
        """Dedupe iterates the input once — generators work correctly."""
        events_gen = (
            _make_event(f"sha256:{fp}", sev, ts)
            for fp, sev, ts in [("a", "WARNING", 1000.0), ("a", "CRITICAL", 1001.0), ("b", "WARNING", 1002.0)]
        )
        result = dedupe_events_by_fingerprint(events_gen)
        # 2 unique fingerprints: "a" (deduped to CRITICAL) and "b"
        assert len(result) == 2


# ---------------------------------------------------------------------------
# inhibit_subsumed_events
# ---------------------------------------------------------------------------

def _make_event_with_agents(
    failure_class: FailureClass,
    agents: tuple[str, ...],
    pattern: str = "circular",
    severity: str = "WARNING",
) -> CoordinationEvent:
    """Build a CoordinationEvent with a populated topology for inhibition tests."""
    topology = Topology(
        agents_involved=agents,
        interaction_pattern=pattern,
        agent_count=len(agents),
        occurrence_count=5,
        edge_frequency={},
    )
    alert = Alert(
        pattern="x",
        severity=severity,
        details={},
        timestamp=1000.0,
    )
    return alert_to_coordination_event(
        alert=alert,
        session_id="sess",
        failure_class=failure_class,
        topology=topology,
    )


class TestInhibitSubsumedEvents:
    """The alert-inhibition pattern: when a cycle is detected, the
    repetitive-edge symptoms of that cycle are suppressed in the summary
    view. Modeled after Prometheus Alertmanager's inhibit_rules."""

    def test_empty_list(self):
        assert inhibit_subsumed_events([]) == []

    def test_no_cycles_nothing_inhibited(self):
        """No CYCLIC_DELEGATION events → no inhibition."""
        events = [
            _make_event_with_agents(
                FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
                pattern="one_directional",
            ),
            _make_event_with_agents(
                FailureClass.REPETITIVE_DELEGATION, ("c", "d"),
                pattern="one_directional",
            ),
        ]
        result = inhibit_subsumed_events(events)
        assert len(result) == 2

    def test_cycle_inhibits_symptomatic_edges(self):
        """Classic case: cycle A->B->C->A inhibits the 3 edge anomalies."""
        cycle = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b", "c"),
            pattern="circular", severity="CRITICAL",
        )
        edge_ab = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        edge_bc = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("b", "c"),
            pattern="one_directional",
        )
        edge_ca = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("c", "a"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events([cycle, edge_ab, edge_bc, edge_ca])
        assert len(result) == 1
        assert result[0].failure_class == FailureClass.CYCLIC_DELEGATION

    def test_cycle_does_not_inhibit_unrelated_repetitive(self):
        """An edge outside the cycle's agents stays."""
        cycle = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b", "c"),
        )
        unrelated = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("x", "y"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events([cycle, unrelated])
        assert len(result) == 2

    def test_two_node_cycle_inhibits_its_edge(self):
        """A <-> B cycle should inhibit the A->B repetitive event."""
        cycle = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b"),
        )
        edge = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events([cycle, edge])
        assert len(result) == 1
        assert result[0].failure_class == FailureClass.CYCLIC_DELEGATION

    def test_scc_cycle_also_inhibits(self):
        """SCC-detected and incrementally-detected cycles BOTH use
        interaction_pattern="circular" in the unified output. Inhibition
        matches on failure_class + agents_involved — the detection
        pipeline doesn't matter. Regression: before unification, SCC
        events carried interaction_pattern="strongly_connected_component"
        and users got a second user-visible name for the same thing."""
        scc = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b", "c"),
            pattern="circular",  # unified — was "strongly_connected_component"
        )
        edge = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events([scc, edge])
        assert len(result) == 1

    def test_cycle_does_not_inhibit_resource_exhaustion(self):
        """RESOURCE_EXHAUSTION is a different kind of failure — not a
        symptom of the cycle. Must survive inhibition."""
        cycle = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b"),
        )
        rate_limit = _make_event_with_agents(
            FailureClass.RESOURCE_EXHAUSTION, ("a", "b"),
            pattern="throttled",
        )
        result = inhibit_subsumed_events([cycle, rate_limit])
        assert len(result) == 2

    def test_multiple_cycles_inhibit_independently(self):
        """Two separate cycles, each inhibiting its own edges."""
        cycle_abc = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b", "c"),
        )
        cycle_xy = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("x", "y"),
        )
        edge_bc = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("b", "c"),
            pattern="one_directional",
        )
        edge_xy = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("x", "y"),
            pattern="one_directional",
        )
        unrelated = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("m", "n"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events(
            [cycle_abc, cycle_xy, edge_bc, edge_xy, unrelated]
        )
        # Both cycles survive, the unrelated edge survives, 2 edges suppressed
        assert len(result) == 3
        classes = {e.failure_class for e in result}
        assert FailureClass.CYCLIC_DELEGATION in classes
        assert FailureClass.REPETITIVE_DELEGATION in classes
        # The only repetitive should be ("m", "n")
        reps = [e for e in result if e.failure_class == FailureClass.REPETITIVE_DELEGATION]
        assert len(reps) == 1
        assert reps[0].topology.agents_involved == ("m", "n")

    def test_does_not_mutate_input(self):
        """Pure function — input list is not modified."""
        cycle = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b"),
        )
        edge = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        events = [cycle, edge]
        original_len = len(events)
        inhibit_subsumed_events(events)
        assert len(events) == original_len

    def test_cycle_without_topology_ignored(self):
        """Defensive: cycles missing topology don't crash the inhibitor
        and don't inhibit anything (no agents to compare against)."""
        broken_cycle = CoordinationEvent(
            schema_version="0.1.0",
            event_id="e1",
            session_id="s",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="error",
            topology=None,  # no topology
        )
        edge = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events([broken_cycle, edge])
        # The edge is kept because the broken cycle has no agents to match
        assert len(result) == 2

    def test_accepts_generator_input(self):
        """Regression: the function iterates twice (cycles collection + main
        loop). Previously it silently returned [] if given a generator
        because the second iteration saw an exhausted generator."""
        cycle = _make_event_with_agents(
            FailureClass.CYCLIC_DELEGATION, ("a", "b", "c"),
        )
        edge_inside = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        edge_outside = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("x", "y"),
            pattern="one_directional",
        )
        # Pass as a generator, not a list
        result = inhibit_subsumed_events(e for e in [cycle, edge_inside, edge_outside])
        # Should get cycle + edge_outside (edge_inside suppressed)
        assert len(result) == 2
        # Confirm the right ones survived
        classes = {e.failure_class for e in result}
        assert FailureClass.CYCLIC_DELEGATION in classes
        reps = [e for e in result if e.failure_class == FailureClass.REPETITIVE_DELEGATION]
        assert len(reps) == 1
        assert reps[0].topology.agents_involved == ("x", "y")

    def test_accepts_generator_with_no_cycles(self):
        """Regression: generator input with NO cycles should return all
        events (early-return path). Before the fix, it returned list(events)
        which exhausts the generator correctly — but still worth testing."""
        edge1 = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("a", "b"),
            pattern="one_directional",
        )
        edge2 = _make_event_with_agents(
            FailureClass.REPETITIVE_DELEGATION, ("c", "d"),
            pattern="one_directional",
        )
        result = inhibit_subsumed_events(e for e in [edge1, edge2])
        assert len(result) == 2


# ---------------------------------------------------------------------------
# Regression guards — fields that must NOT exist in v0.1.0
# ---------------------------------------------------------------------------

class TestRegressionGuards:

    def test_coordination_event_has_no_cost_impact(self):
        """v0.1.0 intentionally has no cost_impact field."""
        field_names = {f.name for f in dataclasses.fields(CoordinationEvent)}
        assert "cost_impact" not in field_names

    def test_coordination_event_has_no_risk_assessment(self):
        """v0.1.0 removed risk_assessment from CoordinationEvent."""
        field_names = {f.name for f in dataclasses.fields(CoordinationEvent)}
        assert "risk_assessment" not in field_names

    def test_coordination_event_has_no_recommendations(self):
        """v0.1.0 removed recommendations from CoordinationEvent."""
        field_names = {f.name for f in dataclasses.fields(CoordinationEvent)}
        assert "recommendations" not in field_names

    def test_provider_error_has_no_provider_field(self):
        """v0.1.0 removed the provider field from ProviderError."""
        field_names = {f.name for f in dataclasses.fields(ProviderError)}
        assert "provider" not in field_names
        assert "error_type" in field_names
        assert "retry_after_seconds" in field_names

    def test_no_removed_classes_in_schema(self):
        """CostImpact, RiskAssessment, Recommendation must not exist in schema."""
        import agentsonar._core.schema as schema
        assert not hasattr(schema, "CostImpact")
        assert not hasattr(schema, "RiskAssessment")
        assert not hasattr(schema, "Recommendation")

    def test_topology_has_no_detection_method(self):
        """v0.1.0 removed detection_method from Topology — it leaked
        internal layer names ("incremental" / "scc_sweep") into public
        JSON output. The `interaction_pattern` field carries the same
        distinction in user-facing terms."""
        field_names = {f.name for f in dataclasses.fields(Topology)}
        assert "detection_method" not in field_names

    def test_topology_has_no_delegation_depth(self):
        """v0.1.0 renamed delegation_depth → agent_count. "Depth" implied
        a nested structure that doesn't exist; "agent count" is what the
        number literally is."""
        field_names = {f.name for f in dataclasses.fields(Topology)}
        assert "delegation_depth" not in field_names
        assert "agent_count" in field_names


# ---------------------------------------------------------------------------
# Topology field rename + removal: user-visible output
# ---------------------------------------------------------------------------

class TestTopologyOutputFields:
    """The public JSON output must NOT leak the old field names, and
    must include the new `agent_count` instead."""

    def _make_topology_event(self):
        topology = Topology(
            agents_involved=("a", "b", "c"),
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=5,
            edge_frequency={"a->b": 5, "b->c": 5, "c->a": 5},
        )
        return _minimal_event(topology=topology)

    def test_topology_dict_includes_agent_count(self):
        d = self._make_topology_event().to_dict()
        assert "agent_count" in d["topology"]
        assert d["topology"]["agent_count"] == 3

    def test_topology_dict_has_no_delegation_depth(self):
        """Regression: the old `delegation_depth` key must not appear in
        the serialized output — users shouldn't see both names."""
        d = self._make_topology_event().to_dict()
        assert "delegation_depth" not in d["topology"]

    def test_topology_dict_has_no_detection_method(self):
        """Regression: `detection_method` was removed from the schema.
        JSON consumers will never see "incremental" or "scc_sweep" in
        the output."""
        d = self._make_topology_event().to_dict()
        assert "detection_method" not in d["topology"]

    def test_topology_agent_count_matches_agents_length(self):
        """Cycle and edge builders should produce consistent agent_count
        values (= len(agents_involved)). This is a design invariant test —
        any builder that sets a different value would break it."""
        from agentsonar._core.engine import DetectionEngine
        from agentsonar._core.models import InteractionEvent

        engine = DetectionEngine({
            "file_output": False, "console_output": False,
            "warning_threshold": 1, "critical_threshold": 3,
            "hard_weight_limit": 2.0, "per_edge_limit": 1000,
        })
        now = 1000.0
        # Trip a cycle (3 agents) and a one-directional edge (2 agents)
        for i in range(8):
            engine.ingest(InteractionEvent("a", "b", now + i * 0.5))
            engine.ingest(InteractionEvent("b", "c", now + i * 0.5 + 0.1))
            engine.ingest(InteractionEvent("c", "a", now + i * 0.5 + 0.2))

        events = engine.get_recent_events()
        for ev in events:
            if ev.topology is None:
                continue
            expected = len(ev.topology.agents_involved)
            assert ev.topology.agent_count == expected, (
                f"agent_count={ev.topology.agent_count} does not match "
                f"len(agents_involved)={expected} for {ev.failure_class.value}"
            )
