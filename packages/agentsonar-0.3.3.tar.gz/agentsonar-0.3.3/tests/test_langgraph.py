"""
Tests for the LangGraph integration adapter.

Skipped if langchain-core isn't installed (the callback raises a
RuntimeError at instantiation time in that case — we catch it and skip
at the module level so the rest of the suite still runs on a minimal
install).
"""
from __future__ import annotations

import time

import pytest

# Skip the whole module if langchain-core isn't available. The callback
# explicitly raises RuntimeError at instantiation, so we detect that and
# skip collection here rather than scattering skip markers on every test.
langchain_core = pytest.importorskip("langchain_core")

from agentsonar._integrations.langgraph_callback import (  # noqa: E402
    AgentSonarCallback,
    _MonitoredGraph,
    monitor,
)

# Disable file and console output for all tests
_TEST_CONFIG = {"file_output": False, "console_output": False}


def _chain_start(cb: AgentSonarCallback, node: str, step: int) -> None:
    """Simulate a LangGraph on_chain_start event for a node."""
    cb.on_chain_start(
        serialized={"name": node},
        inputs={},
        metadata={"langgraph_node": node, "langgraph_step": step},
    )


def _chain_start_no_meta(cb: AgentSonarCallback) -> None:
    """Simulate a graph-level on_chain_start with no node metadata."""
    cb.on_chain_start(
        serialized={"name": "LangGraph"},
        inputs={},
        metadata={},
    )


# -----------------------------------------------------------------------
# Linear pipeline (healthy — no alerts)
# -----------------------------------------------------------------------

class TestLinearPipeline:

    def test_linear_pipeline_no_alerts(self):
        """A -> B -> C -> D produces 3 edges, zero alerts."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "researcher", step=1)
        _chain_start(cb, "analyst", step=2)
        _chain_start(cb, "writer", step=3)
        _chain_start(cb, "editor", step=4)

        summary = cb.get_summary()
        assert summary["total_events"] == 3
        assert summary["alerts_raised"] == 0
        assert summary["edge_counts"] == {
            "researcher->analyst": 1,
            "analyst->writer": 1,
            "writer->editor": 1,
        }

    def test_linear_pipeline_graph_structure(self):
        """Verify the NetworkX graph has correct nodes and edges."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "a", step=1)
        _chain_start(cb, "b", step=2)
        _chain_start(cb, "c", step=3)

        graph = cb.engine.graph
        assert set(graph.nodes()) == {"a", "b", "c"}
        assert graph.has_edge("a", "b")
        assert graph.has_edge("b", "c")
        assert not graph.has_edge("a", "c")


# -----------------------------------------------------------------------
# Cycle detection
# -----------------------------------------------------------------------

class TestCycleDetection:

    def test_cycle_detected(self):
        """A -> B -> A -> B -> A should trigger cycle-related alerts."""
        cb = AgentSonarCallback(config={
            **_TEST_CONFIG,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        nodes = ["researcher", "writer", "researcher", "writer", "researcher",
                 "writer", "researcher", "writer", "researcher", "writer"]
        for i, node in enumerate(nodes):
            _chain_start(cb, node, step=i + 1)

        summary = cb.get_summary()
        assert summary["alerts_raised"] >= 1
        assert "researcher->writer" in summary["edge_counts"]
        assert "writer->researcher" in summary["edge_counts"]

    def test_three_node_cycle(self):
        """A -> B -> C -> A should form a 3-node cycle."""
        cb = AgentSonarCallback(config={
            **_TEST_CONFIG,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        nodes = ["a", "b", "c", "a", "b", "c", "a", "b", "c", "a"]
        for i, node in enumerate(nodes):
            _chain_start(cb, node, step=i + 1)

        summary = cb.get_summary()
        assert summary["edge_counts"]["a->b"] >= 3
        assert summary["edge_counts"]["b->c"] >= 3
        assert summary["edge_counts"]["c->a"] >= 3


# -----------------------------------------------------------------------
# Metadata handling
# -----------------------------------------------------------------------

class TestMetadataHandling:

    def test_skips_events_without_node_metadata(self):
        """Events without langgraph_node in metadata should be ignored."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start_no_meta(cb)
        _chain_start_no_meta(cb)
        _chain_start_no_meta(cb)

        summary = cb.get_summary()
        assert summary["total_events"] == 0
        assert cb._previous_node is None

    def test_skips_none_metadata(self):
        """Events with metadata=None should be ignored."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        cb.on_chain_start(serialized={"name": "x"}, inputs={}, metadata=None)
        assert cb._previous_node is None

    def test_first_node_no_edge(self):
        """First chain_start sets previous_node but creates no edge."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "researcher", step=1)

        assert cb._previous_node == "researcher"
        summary = cb.get_summary()
        assert summary["total_events"] == 0

    def test_step_tracked(self):
        """langgraph_step should be stored on the callback."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "a", step=5)
        assert cb._current_step == 5


# -----------------------------------------------------------------------
# Self-loop prevention
# -----------------------------------------------------------------------

class TestSelfLoop:

    def test_same_node_repeated_no_self_edge(self):
        """A -> A -> A should not create self-loop edges."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "researcher", step=1)
        _chain_start(cb, "researcher", step=2)
        _chain_start(cb, "researcher", step=3)

        summary = cb.get_summary()
        assert summary["total_events"] == 0
        assert len(summary["edge_counts"]) == 0


# -----------------------------------------------------------------------
# monitor() wrapper
# -----------------------------------------------------------------------

class _FakeGraph:
    """Mock LangGraph CompiledGraph for testing monitor()."""

    def __init__(self):
        self.last_config = None

    def invoke(self, input, config=None, **kwargs):
        self.last_config = config
        return {"result": "ok"}

    def stream(self, input, config=None, **kwargs):
        self.last_config = config
        return iter([{"result": "ok"}])


class TestMonitor:

    def test_monitor_returns_wrapper(self):
        graph = _FakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)
        assert isinstance(wrapped, _MonitoredGraph)
        assert hasattr(wrapped, "sonar")

    def test_monitor_injects_callback(self):
        graph = _FakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)
        wrapped.invoke({"input": "test"})

        assert graph.last_config is not None
        callbacks = graph.last_config.get("callbacks", [])
        assert any(isinstance(cb, AgentSonarCallback) for cb in callbacks)

    def test_monitor_merges_with_existing_callbacks(self):
        """User's callbacks must be preserved, not overwritten."""
        graph = _FakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)

        class UserCallback:
            pass

        user_cb = UserCallback()
        wrapped.invoke({"input": "test"}, config={"callbacks": [user_cb]})

        callbacks = graph.last_config["callbacks"]
        assert user_cb in callbacks
        assert any(isinstance(cb, AgentSonarCallback) for cb in callbacks)
        assert len(callbacks) == 2

    def test_monitor_no_existing_config(self):
        """monitor works when user passes no config at all."""
        graph = _FakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)
        wrapped.invoke({"input": "test"})

        callbacks = graph.last_config["callbacks"]
        assert len(callbacks) == 1
        assert isinstance(callbacks[0], AgentSonarCallback)

    def test_monitor_proxies_attributes(self):
        """Unknown attributes should proxy to the wrapped graph."""
        graph = _FakeGraph()
        graph.custom_attr = "hello"
        wrapped = monitor(graph, config=_TEST_CONFIG)
        assert wrapped.custom_attr == "hello"


# -----------------------------------------------------------------------
# Lifecycle
# -----------------------------------------------------------------------

class TestLifecycle:

    def test_shutdown_closes_logger(self):
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "a", step=1)
        _chain_start(cb, "b", step=2)
        cb.shutdown()
        assert cb.engine.logger._closed

    def test_get_summary_structure(self):
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "a", step=1)
        _chain_start(cb, "b", step=2)

        summary = cb.get_summary()
        assert "total_events" in summary
        assert "edge_counts" in summary
        assert "alerts_raised" in summary
        assert "alerts" in summary
        assert isinstance(summary["alerts"], list)

    def test_chain_end_is_noop(self):
        """on_chain_end should not affect state."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)
        _chain_start(cb, "a", step=1)
        cb.on_chain_end(outputs={"result": "done"})
        assert cb._previous_node == "a"

    def test_no_phantom_edge_across_runs(self):
        """Reusing a callback across invoke() calls must not create phantom edges."""
        cb = AgentSonarCallback(config=_TEST_CONFIG)

        # Run 1: A -> B
        _chain_start(cb, "a", step=1)
        _chain_start(cb, "b", step=2)
        assert cb._previous_node == "b"

        # Graph-level start event (no langgraph_node) signals new invoke()
        _chain_start_no_meta(cb)
        assert cb._previous_node is None

        # Run 2: C -> D — should NOT create a B->C edge
        _chain_start(cb, "c", step=1)
        _chain_start(cb, "d", step=2)

        summary = cb.get_summary()
        assert "a->b" in summary["edge_counts"]
        assert "c->d" in summary["edge_counts"]
        assert "b->c" not in summary["edge_counts"]
        assert summary["total_events"] == 2


# -----------------------------------------------------------------------
# monitor() async wrappers — ainvoke + astream
# -----------------------------------------------------------------------

class _AsyncFakeGraph:
    """Mock LangGraph CompiledGraph exposing async invoke/stream.

    Records the config passed to each call so tests can verify
    AgentSonar's callback was merged in correctly.
    """

    def __init__(self):
        self.last_ainvoke_config = None
        self.last_astream_config = None

    async def ainvoke(self, input, config=None, **kwargs):
        self.last_ainvoke_config = config
        return {"result": "async-ok", "input": input}

    async def astream(self, input, config=None, **kwargs):
        """Async generator mimicking LangGraph's streaming interface.

        Yields three chunks so the test can verify the wrapper passes
        every value through rather than eagerly collecting them.
        """
        self.last_astream_config = config
        yield {"chunk": 1, "input": input}
        yield {"chunk": 2, "input": input}
        yield {"chunk": 3, "input": input}


class TestMonitorAsyncWrappers:
    """Regression tests for the async paths on `monitor()` / `_MonitoredGraph`.

    These paths exist to support LangGraph's async API
    (`graph.ainvoke`, `graph.astream`) — they were added without
    dedicated tests and have a latent risk of breaking on a LangGraph
    version bump. These tests pin the behavior so regressions show
    up before users do.
    """

    def test_ainvoke_merges_user_callbacks(self):
        """`monitor().ainvoke(...)` must preserve user callbacks the
        same way the sync `invoke(...)` path does."""
        import asyncio

        graph = _AsyncFakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)

        class UserCallback:
            pass

        user_cb = UserCallback()

        async def run():
            return await wrapped.ainvoke(
                {"input": "hello"},
                config={"callbacks": [user_cb]},
            )

        result = asyncio.run(run())
        assert result["result"] == "async-ok"

        callbacks = graph.last_ainvoke_config["callbacks"]
        # Both survive
        assert user_cb in callbacks
        assert any(isinstance(cb, AgentSonarCallback) for cb in callbacks)
        assert len(callbacks) == 2

    def test_ainvoke_with_no_config(self):
        """ainvoke with no user config must still auto-inject AgentSonar."""
        import asyncio

        graph = _AsyncFakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)

        async def run():
            return await wrapped.ainvoke({"input": "hi"})

        asyncio.run(run())
        callbacks = graph.last_ainvoke_config["callbacks"]
        assert len(callbacks) == 1
        assert isinstance(callbacks[0], AgentSonarCallback)

    def test_astream_yields_all_chunks(self):
        """`async for chunk in wrapped.astream(...)` must iterate EVERY
        chunk the underlying graph yields. Regression guard: it's
        easy to accidentally eagerly-collect or await an async
        generator which would either yield nothing or fail outright."""
        import asyncio

        graph = _AsyncFakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)

        async def run():
            chunks = []
            async for chunk in wrapped.astream({"input": "stream"}):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        assert len(result) == 3, f"expected 3 chunks, got {len(result)}"
        # Chunks arrived in order
        assert result[0]["chunk"] == 1
        assert result[1]["chunk"] == 2
        assert result[2]["chunk"] == 3
        # Input was passed through
        for chunk in result:
            assert chunk["input"] == {"input": "stream"}

    def test_astream_merges_user_callbacks(self):
        """astream must also merge callbacks — not just ainvoke."""
        import asyncio

        graph = _AsyncFakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)

        class UserCallback:
            pass

        user_cb = UserCallback()

        async def run():
            chunks = []
            async for chunk in wrapped.astream(
                {"input": "stream"},
                config={"callbacks": [user_cb]},
            ):
                chunks.append(chunk)
            return chunks

        asyncio.run(run())
        callbacks = graph.last_astream_config["callbacks"]
        assert user_cb in callbacks
        assert any(isinstance(cb, AgentSonarCallback) for cb in callbacks)
        assert len(callbacks) == 2

    def test_astream_is_not_coroutine(self):
        """Paranoid regression check: calling `wrapped.astream(...)`
        must return something you can `async for` over — i.e. an
        async generator, NOT a coroutine. If someone accidentally
        slaps `async` on the wrapper method definition, it becomes
        a coroutine that returns an async gen and callers would
        need to `await` before iterating."""
        import inspect
        graph = _AsyncFakeGraph()
        wrapped = monitor(graph, config=_TEST_CONFIG)

        result = wrapped.astream({"input": "x"})
        # Must be an async iterator, not a coroutine
        assert not inspect.iscoroutine(result), (
            "astream wrapper returned a coroutine — callers can't "
            "use `async for` on it without awaiting first"
        )
        assert inspect.isasyncgen(result), (
            f"expected async generator, got {type(result).__name__}"
        )
