"""
Round-4 audit regression tests.

Round 4 was a run-examples-and-read-the-output-files audit. It found
3 real issues; this file pins each with a regression test.

Bug list:

  1. `_build_edge_anomaly_event` and `_build_rate_limit_event` hardcode
     `agent_count=2` on the Topology block. For self-loop delegations
     (src == tgt) this silently overcounts: a single agent doing
     recursive self-delegation gets reported as 2 agents in every
     user-facing report (HTML, JSON). Fix: compute `len({src, tgt})`
     so self-loops render as agent_count=1 and normal edges stay at 2.

  2. `AlertSeverity.from_string` crashes with `AttributeError` on
     None input and `ValueError` on unknown strings. It's called from
     `_fallback_event` — the fault-isolation path that's supposed to
     produce a minimal CoordinationEvent when a real builder throws.
     If the upstream Alert has a novel or missing severity, the
     fallback itself would explode, defeating its whole purpose.
     Fix: unknown/None severities degrade to INFO (still captured,
     still surfaced, just marked non-actionable).

  3. `_build_rate_limit_event` inherited the generic
     `_build_summary` output ("Resource exhaustion: src -> tgt")
     for BOTH per-edge and global rate limits. Global alerts
     therefore rendered as "Resource exhaustion: A -> B" when the
     user's real problem was system-wide throughput — the
     `A -> B` triggering edge was a red herring. Fix: rate-limit
     summaries now explicitly say "Global rate limit exceeded ..."
     or "Per-edge rate limit exceeded ..." so the scope is
     unambiguous.
"""
from __future__ import annotations

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import Alert, InteractionEvent
from agentsonar._core.schema import (
    AlertSeverity,
    FailureClass,
    alert_to_coordination_event,
)


# ---------------------------------------------------------------------------
# Bug 1: self-loop agent_count = 1, not 2
# ---------------------------------------------------------------------------

def test_self_loop_edge_anomaly_agent_count_is_1():
    """A recursive self-delegating agent shows up as 1 agent, not 2."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
        "hard_weight_limit": 5,
    })
    try:
        ts = 1000.0
        for i in range(20):
            engine.ingest(InteractionEvent("solo_agent", "solo_agent", ts + i * 0.01))

        events = engine.get_recent_events()
        repetitive = [
            e for e in events
            if e.failure_class == FailureClass.REPETITIVE_DELEGATION
        ]
        assert len(repetitive) > 0, "expected at least one self-loop repetitive event"

        for e in repetitive:
            assert e.topology is not None
            assert e.topology.agent_count == 1, (
                f"self-loop should have agent_count=1, got "
                f"{e.topology.agent_count} for agents {e.topology.agents_involved}"
            )
            # agents_involved should still show both sides of the directed
            # edge — the duplicate-ness IS the signal for a self-loop.
            assert e.topology.agents_involved == ("solo_agent", "solo_agent")
    finally:
        engine.shutdown()


def test_normal_edge_anomaly_agent_count_still_2():
    """Regression guard: non-self-loop edges still report agent_count=2."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
        "hard_weight_limit": 5,
    })
    try:
        ts = 1000.0
        for i in range(20):
            engine.ingest(InteractionEvent("alice", "bob", ts + i * 0.01))

        events = engine.get_recent_events()
        repetitive = [
            e for e in events
            if e.failure_class == FailureClass.REPETITIVE_DELEGATION
        ]
        assert len(repetitive) > 0
        for e in repetitive:
            assert e.topology is not None
            assert e.topology.agent_count == 2, (
                f"directed edge should still be agent_count=2, got {e.topology.agent_count}"
            )
    finally:
        engine.shutdown()


def test_self_loop_rate_limit_agent_count_is_1():
    """Per-edge rate limit on a self-loop also reports agent_count=1."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "per_edge_limit": 3,
        "global_limit": 100,
    })
    try:
        ts = 1000.0
        for i in range(10):
            engine.ingest(InteractionEvent("solo", "solo", ts + i * 0.01))

        events = engine.get_recent_events()
        rate_events = [
            e for e in events
            if e.failure_class == FailureClass.RESOURCE_EXHAUSTION
        ]
        # At least one per-edge rate limit event fired
        assert len(rate_events) > 0
        per_edge = [
            e for e in rate_events
            if e.provider_error and e.provider_error.error_type == "rate_limit_exceeded"
        ]
        assert len(per_edge) > 0, "expected per-edge rate limit event"
        for e in per_edge:
            assert e.topology is not None
            assert e.topology.agent_count == 1, (
                f"self-loop rate limit should have agent_count=1, got "
                f"{e.topology.agent_count}"
            )
    finally:
        engine.shutdown()


# ---------------------------------------------------------------------------
# Bug 2: AlertSeverity.from_string defensive path
# ---------------------------------------------------------------------------

def test_alert_severity_from_string_none_degrades_to_info():
    """None input must NOT crash — degrades to INFO."""
    result = AlertSeverity.from_string(None)
    assert result == AlertSeverity.INFO


def test_alert_severity_from_string_unknown_degrades_to_info():
    """Unknown severity string must NOT crash — degrades to INFO."""
    assert AlertSeverity.from_string("EMERGENCY") == AlertSeverity.INFO
    assert AlertSeverity.from_string("") == AlertSeverity.INFO
    assert AlertSeverity.from_string("critical_but_typoed") == AlertSeverity.INFO


def test_alert_severity_from_string_case_insensitive():
    """Valid severities are still accepted case-insensitively."""
    assert AlertSeverity.from_string("warning") == AlertSeverity.WARNING
    assert AlertSeverity.from_string("Warning") == AlertSeverity.WARNING
    assert AlertSeverity.from_string("WARNING") == AlertSeverity.WARNING
    assert AlertSeverity.from_string("info") == AlertSeverity.INFO
    assert AlertSeverity.from_string("CRITICAL") == AlertSeverity.CRITICAL


def test_alert_severity_non_string_degrades_to_info():
    """Defensive against non-string inputs that happen to coerce."""
    # int doesn't have `.upper()` but `str(1).upper() == "1"` which is unknown
    assert AlertSeverity.from_string(1) == AlertSeverity.INFO
    # Object without sensible str
    class Weird:
        def __str__(self):
            return "???"
    assert AlertSeverity.from_string(Weird()) == AlertSeverity.INFO


def test_fallback_event_tolerates_broken_severity():
    """The fallback event builder can't itself explode on bad severity.

    Craft an Alert with a novel severity and push it through the
    fault-isolation path. Before the fix, this would crash inside
    `_fallback_event` and the outer try/except in `_ingest_locked`
    would swallow it — but NO event would be appended to
    `_recent_events`. After the fix, a fallback event is built with
    severity=INFO and appended normally.
    """
    alert = Alert(
        pattern="custom_pattern",
        severity="SURPRISE",  # novel
        details={"x": 1},
        timestamp=1000.0,
    )
    ev = alert_to_coordination_event(
        alert=alert,
        session_id="test",
        failure_class=FailureClass.CYCLIC_DELEGATION,
        agents=["a", "b"],
    )
    assert ev.severity == AlertSeverity.INFO
    assert ev.failure_class == FailureClass.CYCLIC_DELEGATION


# ---------------------------------------------------------------------------
# Bug 3: rate limit summary distinguishes per-edge from global
# ---------------------------------------------------------------------------

def test_global_rate_limit_summary_says_global():
    """Global rate limit summary must not be confused with per-edge."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        # Tight global, relaxed per-edge — forces global fire path
        "per_edge_limit": 99999,
        "global_limit": 5,
        "window_size": 60.0,
    })
    try:
        ts = 1000.0
        # Fire 20 events across many distinct edges — nothing breaks
        # per-edge, but global limit trips.
        for i in range(20):
            engine.ingest(InteractionEvent(f"src{i}", f"dst{i}", ts + i * 0.01))

        events = engine.get_recent_events()
        global_events = [
            e for e in events
            if e.failure_class == FailureClass.RESOURCE_EXHAUSTION
            and e.provider_error
            and e.provider_error.error_type == "global_rate_exceeded"
        ]
        assert len(global_events) >= 1, "expected at least one global rate alert"

        for e in global_events:
            # The summary must make the global scope unambiguous —
            # the old generic "Resource exhaustion: A -> B" was the bug.
            assert "Global rate limit exceeded" in e.summary, (
                f"global summary wrong: {e.summary!r}"
            )
            # Triggering edge still appears, just as context
            assert "triggered by" in e.summary
    finally:
        engine.shutdown()


def test_per_edge_rate_limit_summary_says_per_edge():
    """Per-edge rate limit summary is also clearer now."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "per_edge_limit": 3,
        "global_limit": 99999,
        "window_size": 60.0,
    })
    try:
        ts = 1000.0
        for i in range(20):
            engine.ingest(InteractionEvent("hot_src", "hot_tgt", ts + i * 0.01))

        events = engine.get_recent_events()
        per_edge_events = [
            e for e in events
            if e.failure_class == FailureClass.RESOURCE_EXHAUSTION
            and e.provider_error
            and e.provider_error.error_type == "rate_limit_exceeded"
        ]
        assert len(per_edge_events) >= 1

        for e in per_edge_events:
            assert "Per-edge rate limit exceeded" in e.summary
            assert "hot_src -> hot_tgt" in e.summary
    finally:
        engine.shutdown()


def test_global_rate_limit_fingerprint_still_collapses():
    """Regression guard: the summary changes must NOT break fingerprint
    collapsing. Multiple global events must still share one fingerprint
    so dedupe keeps the summary view clean.
    """
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "per_edge_limit": 99999,
        "global_limit": 5,
        "window_size": 60.0,
    })
    try:
        ts = 1000.0
        for i in range(30):
            engine.ingest(InteractionEvent(f"src{i}", f"dst{i}", ts + i * 0.01))

        events = engine.get_recent_events()
        global_events = [
            e for e in events
            if e.failure_class == FailureClass.RESOURCE_EXHAUSTION
            and e.provider_error
            and e.provider_error.error_type == "global_rate_exceeded"
        ]
        if len(global_events) >= 2:
            # All global events share one fingerprint
            fps = {e.coordination_fingerprint for e in global_events}
            assert len(fps) == 1, (
                f"global rate events should collapse to one fingerprint, "
                f"got {len(fps)}"
            )
    finally:
        engine.shutdown()
