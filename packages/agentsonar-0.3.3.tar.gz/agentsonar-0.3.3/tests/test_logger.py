"""
Unit tests for SonarLogger.

Tests file output (JSONL), console output (stderr), level filtering,
session lifecycle, and fault tolerance.
"""
from __future__ import annotations

import json
import os
import time

import pytest

from agentsonar._output.terminal import SonarLogger
from agentsonar._core.models import Alert


@pytest.fixture
def log_dir(tmp_path):
    """Provide a temporary directory for log files.

    This is the PARENT of `agentsonar_logs/` — SonarLogger will create
    `<log_dir>/agentsonar_logs/run-<ts>-<id>/` inside it and write the
    per-run files there. Tests use the helpers below to locate the
    run directory without having to know the exact name.
    """
    return str(tmp_path)


def _find_logs_root(log_dir: str) -> str:
    """Return the path to the `agentsonar_logs/` directory."""
    root = os.path.join(log_dir, "agentsonar_logs")
    assert os.path.isdir(root), (
        f"agentsonar_logs/ was never created inside {log_dir} — "
        "did file_output=True and did the logger actually open files?"
    )
    return root


def _find_run_dir(log_dir: str) -> str:
    """Return the absolute path to the single run directory for this test.

    Assumes exactly ONE run directory exists (the test's own). If you
    run the logger multiple times in one test, use the run_dir attribute
    on the SonarLogger instance directly instead of calling this helper.
    """
    root = _find_logs_root(log_dir)
    runs = [
        name for name in os.listdir(root)
        if name.startswith("run-") and os.path.isdir(os.path.join(root, name))
    ]
    assert len(runs) == 1, (
        f"Expected exactly 1 run directory under {root}, found {runs}"
    )
    return os.path.join(root, runs[0])


def _find_jsonl_log(log_dir: str) -> str:
    """Return the path to `timeline.jsonl` inside the run directory."""
    path = os.path.join(_find_run_dir(log_dir), "timeline.jsonl")
    assert os.path.isfile(path), f"timeline.jsonl missing at {path}"
    return path


def _find_alerts_log(log_dir: str) -> str:
    """Return the path to `alerts.log` inside the run directory."""
    path = os.path.join(_find_run_dir(log_dir), "alerts.log")
    assert os.path.isfile(path), f"alerts.log missing at {path}"
    return path


def _read_log_lines(log_dir: str) -> list[dict]:
    """Parse the JSONL log file into dicts."""
    path = _find_jsonl_log(log_dir)
    lines = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                lines.append(json.loads(line))
    return lines


def _read_alerts_log(log_dir: str) -> list[str]:
    """Return raw text lines from the human-readable alerts log."""
    path = _find_alerts_log(log_dir)
    with open(path, encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f if line.strip()]


# -----------------------------------------------------------------------
# File creation and naming
# -----------------------------------------------------------------------

class TestFileCreation:

    def test_creates_session_directory_with_both_logs(self, log_dir):
        """With file_output=True, a session directory is created under
        `agentsonar_logs/` and contains both `timeline.jsonl` and
        `alerts.log` with fixed filenames. The directory name follows
        the new human-readable format:

            run-YYYY-MM-DD_HH-MM-SS-adjective-noun

        e.g. `run-2026-04-11_06-48-40-brave-otter`. Both the timestamp
        and the Docker-style memorable slug are present.
        """
        import re as _re
        logger = SonarLogger(output_dir=log_dir, console_output=False)
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        root = _find_logs_root(log_dir)
        runs = [
            name for name in os.listdir(root)
            if name.startswith("run-") and os.path.isdir(os.path.join(root, name))
        ]
        assert len(runs) == 1, f"expected 1 run dir, got {runs}"
        run_name = runs[0]

        # Run directory name format: run-YYYY-MM-DD_HH-MM-SS-adj-noun
        pattern = _re.compile(
            r"^run-\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}-[a-z]+-[a-z]+$"
        )
        assert pattern.match(run_name), (
            f"run dir name {run_name!r} does not match "
            "run-YYYY-MM-DD_HH-MM-SS-adjective-noun"
        )

        # Both fixed-name files exist inside the run dir
        run_dir = os.path.join(root, run_name)
        assert os.path.isfile(os.path.join(run_dir, "timeline.jsonl"))
        assert os.path.isfile(os.path.join(run_dir, "alerts.log"))

        # logger.run_dir attribute points at the same directory
        assert os.path.samefile(logger.run_dir, run_dir)

    def test_no_session_dir_when_file_output_disabled(self, log_dir):
        """file_output=False → no agentsonar_logs/ directory is created
        at all. Tests that disable file output shouldn't see any files
        appear on disk."""
        logger = SonarLogger(output_dir=log_dir, file_output=False, console_output=False)
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()
        assert not os.path.exists(os.path.join(log_dir, "agentsonar_logs"))
        assert logger.run_dir is None
        assert logger.logs_root is None

    def test_creates_output_dir(self, tmp_path):
        """Parent directories for `output_dir` are created automatically
        even when several levels deep — matches the behavior users
        expect from file-logging libraries."""
        nested = str(tmp_path / "deep" / "nested" / "logs")
        logger = SonarLogger(output_dir=nested, console_output=False)
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()
        assert os.path.isdir(nested)
        assert os.path.isdir(os.path.join(nested, "agentsonar_logs"))

    def test_writes_latest_pointer(self, log_dir):
        """A plain text `latest` file at the logs_root contains the
        current run's directory basename."""
        logger = SonarLogger(output_dir=log_dir, console_output=False)
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        latest_path = os.path.join(log_dir, "agentsonar_logs", "latest")
        assert os.path.isfile(latest_path), "latest pointer file missing"
        content = latest_path_text = open(latest_path, encoding="utf-8").read().strip()
        # The pointer holds the run dir basename (relative, not absolute)
        assert content == os.path.basename(logger.run_dir)

    def test_writes_self_excluding_gitignore(self, log_dir):
        """agentsonar_logs/.gitignore is auto-written containing `*` so
        users never accidentally commit their logs. Trick borrowed
        from pytest-cache."""
        logger = SonarLogger(output_dir=log_dir, console_output=False)
        logger.log("INFO", "test", {})
        logger.close()

        gitignore_path = os.path.join(log_dir, "agentsonar_logs", ".gitignore")
        assert os.path.isfile(gitignore_path)
        content = open(gitignore_path, encoding="utf-8").read()
        assert "*" in content

    def test_custom_gitignore_is_preserved(self, log_dir):
        """If the user already customized .gitignore inside
        agentsonar_logs/, we must NOT overwrite it."""
        root = os.path.join(log_dir, "agentsonar_logs")
        os.makedirs(root, exist_ok=True)
        custom_content = "# custom user content — do not overwrite\n!important.json\n"
        with open(os.path.join(root, ".gitignore"), "w", encoding="utf-8") as f:
            f.write(custom_content)

        logger = SonarLogger(output_dir=log_dir, console_output=False)
        logger.log("INFO", "test", {})
        logger.close()

        content = open(os.path.join(root, ".gitignore"), encoding="utf-8").read()
        assert content == custom_content, (
            "custom .gitignore was overwritten"
        )

    def test_session_id_produces_deterministic_slug(self):
        """When the engine passes its session_id, the run dir's slug
        is deterministic from that id. Two loggers with the same
        session_id produce runs with the same slug — correlatable
        across reruns, tests, and cross-session debugging."""
        from agentsonar._output._slug import generate_slug
        # Compute the expected slug directly from the public function
        expected_slug = generate_slug("a1b2c3d4e5f67890")

        import tempfile as _tempfile
        with _tempfile.TemporaryDirectory() as dir1:
            logger1 = SonarLogger(
                output_dir=dir1,
                console_output=False,
                session_id="a1b2c3d4e5f67890",
            )
            run1 = logger1.run_dir
            logger1.close()

        with _tempfile.TemporaryDirectory() as dir2:
            logger2 = SonarLogger(
                output_dir=dir2,
                console_output=False,
                session_id="a1b2c3d4e5f67890",
            )
            run2 = logger2.run_dir
            logger2.close()

        # Both run dirs must END with the exact same slug
        assert run1 is not None and run2 is not None
        assert run1.endswith(f"-{expected_slug}"), (
            f"run1 {run1} does not end with slug {expected_slug}"
        )
        assert run2.endswith(f"-{expected_slug}"), (
            f"run2 {run2} does not end with slug {expected_slug}"
        )

    def test_different_session_ids_produce_different_slugs(self):
        """Two DIFFERENT session_ids should produce different slugs in
        almost every case. We use two known session_ids that map to
        different slugs to verify the correlation pipe is working."""
        from agentsonar._output._slug import generate_slug
        s1 = "aaaaaaaaaaaaaaaa"
        s2 = "ffffffffffffffff"
        slug1 = generate_slug(s1)
        slug2 = generate_slug(s2)
        assert slug1 != slug2, (
            f"different session_ids {s1}/{s2} produced same slug {slug1}"
        )

    def test_multiple_runs_create_distinct_directories(self, log_dir):
        """Running the SDK twice in the same `log_dir` must create two
        separate run directories, with `latest` pointing at the newer
        one. This is the core of the session-directory promise."""
        import time as _time
        logger1 = SonarLogger(
            output_dir=log_dir, console_output=False, session_id="aaaaaa",
        )
        first_run_dir = logger1.run_dir
        logger1.close()

        # Sleep past the 1ms resolution boundary so the second run
        # gets a different timestamp. (The short id would differ even
        # without this, but an explicit sleep makes the test
        # independent of id collision luck.)
        _time.sleep(0.01)

        logger2 = SonarLogger(
            output_dir=log_dir, console_output=False, session_id="bbbbbb",
        )
        second_run_dir = logger2.run_dir
        logger2.close()

        assert first_run_dir != second_run_dir
        assert os.path.isdir(first_run_dir)
        assert os.path.isdir(second_run_dir)

        # The latest pointer must now point at the SECOND run
        latest = open(
            os.path.join(log_dir, "agentsonar_logs", "latest"),
            encoding="utf-8",
        ).read().strip()
        assert latest == os.path.basename(second_run_dir)


class TestRetention:
    """Keep-last-N retention — the bounded-disk-use promise.

    These tests create many runs in a single test directory and
    verify that only the configured number survive the retention
    sweep. The sweep runs on each SonarLogger creation (after the
    new run dir is made), so the CURRENT run is always kept.
    """

    # All retention tests pass EXPLICIT session_ids so each run
    # produces a deterministic (and distinct) slug. Without this,
    # a ~0.1% collision chance when generating random slugs for 4
    # runs in a row makes the test flaky under random test seed.
    # Real users get random slugs via uuid4 — that's fine — but
    # tests need determinism.
    _RETENTION_SESSION_IDS = [
        "a" * 16, "b" * 16, "c" * 16, "d" * 16, "e" * 16,
        "f" * 16, "0" * 16, "1" * 16,
    ]

    def test_retention_prunes_to_keep_runs(self, log_dir):
        """Create 5 runs with keep_runs=3. After each creation, the
        sweep should leave exactly 3 run directories in logs_root."""
        import time as _time
        root = os.path.join(log_dir, "agentsonar_logs")

        for i in range(5):
            logger = SonarLogger(
                output_dir=log_dir,
                console_output=False,
                keep_runs=3,
                session_id=self._RETENTION_SESSION_IDS[i],
            )
            logger.close()
            # No sleep — explicit distinct session_ids guarantee
            # distinct slugs, so all 5 runs land in distinct
            # directories even within the same second.

        runs = sorted(
            name for name in os.listdir(root)
            if name.startswith("run-")
        )
        assert len(runs) == 3, (
            f"expected 3 runs after pruning, found {len(runs)}: {runs}"
        )

    def test_retention_zero_disables_pruning(self, log_dir):
        """keep_runs=0 means 'never prune' — runs accumulate forever."""
        import time as _time
        root = os.path.join(log_dir, "agentsonar_logs")

        for i in range(5):
            logger = SonarLogger(
                output_dir=log_dir,
                console_output=False,
                keep_runs=0,
                session_id=self._RETENTION_SESSION_IDS[i],
            )
            logger.close()
            # No sleep — this test only counts, doesn't check order.

        runs = [
            name for name in os.listdir(root)
            if name.startswith("run-")
        ]
        assert len(runs) == 5

    def test_retention_keeps_newest_runs(self, log_dir):
        """When the sweep prunes, it keeps the N MOST RECENT runs
        (not the oldest). Directory names lead with ISO timestamps
        so lex sort == chronological sort."""
        import time as _time
        root = os.path.join(log_dir, "agentsonar_logs")

        run_dirs = []
        for i in range(5):
            logger = SonarLogger(
                output_dir=log_dir,
                console_output=False,
                keep_runs=2,
                session_id=self._RETENTION_SESSION_IDS[i],
            )
            run_dirs.append(os.path.basename(logger.run_dir))
            logger.close()
            _time.sleep(1.1)

        surviving = sorted(
            name for name in os.listdir(root)
            if name.startswith("run-")
        )
        # The 2 survivors should be the last 2 run_dirs we created
        expected = sorted(run_dirs[-2:])
        assert surviving == expected

    def test_retention_from_env_var(self, log_dir, monkeypatch):
        """AGENTSONAR_KEEP_RUNS env var is honored when no explicit
        keep_runs arg is passed. Explicit arg overrides the env var."""
        monkeypatch.setenv("AGENTSONAR_KEEP_RUNS", "2")
        import time as _time
        root = os.path.join(log_dir, "agentsonar_logs")

        for i in range(4):
            logger = SonarLogger(
                output_dir=log_dir,
                console_output=False,
                session_id=self._RETENTION_SESSION_IDS[i],
            )
            logger.close()
            # No sleep — count-only test, doesn't check order.

        runs = [
            name for name in os.listdir(root)
            if name.startswith("run-")
        ]
        assert len(runs) == 2

    def test_explicit_keep_runs_overrides_env_var(self, log_dir, monkeypatch):
        """When both env var and explicit arg are set, the arg wins."""
        monkeypatch.setenv("AGENTSONAR_KEEP_RUNS", "2")
        import time as _time
        root = os.path.join(log_dir, "agentsonar_logs")

        for i in range(5):
            logger = SonarLogger(
                output_dir=log_dir,
                console_output=False,
                keep_runs=4,  # explicit arg — should beat env var's 2
                session_id=self._RETENTION_SESSION_IDS[i],
            )
            logger.close()
            # No sleep — count-only test, doesn't check order.

        runs = [
            name for name in os.listdir(root)
            if name.startswith("run-")
        ]
        assert len(runs) == 4

    def test_retention_never_deletes_current_run(self, log_dir):
        """Regression: with slug-based naming, a newly-created run
        can have an alphabetically-early slug compared to older runs
        in the same second. A naive "sort by name desc, delete the
        tail" retention sweep would then delete the current run's
        own directory — on Windows that silently fails because of
        open file handles (the test we're pinning); on Linux it
        creates a dangling directory entry with orphaned file
        handles. The sweep must explicitly exclude `self.run_dir`
        from the deletion candidate pool.
        """
        import re as _re
        root = os.path.join(log_dir, "agentsonar_logs")

        # Pre-seed logs_root with 4 run directories whose slugs sort
        # LEXICOGRAPHICALLY LATER than anything starting with "a".
        # Then create a real run whose slug starts with "a". A naive
        # retention sweep with keep_runs=2 would see 5 candidates,
        # sort desc [z,y,x,w,a-new], keep [z,y], delete [x,w,a-new] —
        # deleting the newly-created run. With the self-protect
        # fix, a-new is excluded from the candidate pool.
        os.makedirs(root)
        preseed_names = [
            "run-2020-01-01_00-00-00-zulu-zebra",
            "run-2020-01-01_00-00-00-yankee-yak",
            "run-2020-01-01_00-00-00-xray-ox",
            "run-2020-01-01_00-00-00-whiskey-wolf",
        ]
        for name in preseed_names:
            os.makedirs(os.path.join(root, name))

        # Create a real logger — its slug will come from session_id "a"*16
        # which maps to "clear-canyon" (alphabetically earlier than zulu,
        # yankee, xray, whiskey).
        logger = SonarLogger(
            output_dir=log_dir,
            console_output=False,
            keep_runs=2,
            session_id="a" * 16,
        )
        # Write a test line so the files have content
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        # The logger's run dir MUST still exist and be readable
        assert os.path.isdir(logger.run_dir), (
            f"current run dir {logger.run_dir} was deleted by retention"
        )
        # Its files must also still exist
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))
        assert os.path.isfile(os.path.join(logger.run_dir, "alerts.log"))

        # Retention should have pruned the pre-seeded dirs down to 1 —
        # keep_runs=2 means keep 2 total, and the current run occupies
        # one of those slots, so only 1 pre-seeded dir survives.
        run_dirs = sorted(
            name for name in os.listdir(root)
            if name.startswith("run-")
        )
        assert len(run_dirs) == 2  # current run + 1 preserved preseed
        assert os.path.basename(logger.run_dir) in run_dirs

    def test_collision_appends_numeric_suffix(self, log_dir):
        """Regression: if two runs in the same second happen to produce
        the same slug (rare with 4096 options but possible with ~16k
        tries per day), the directory creation must NOT silently merge
        them into the same dir. A numeric suffix `-1`, `-2`, ...
        disambiguates without data loss.

        We simulate the collision by pre-creating the target dir
        BEFORE the logger runs, forcing the collision path to fire.
        """
        from agentsonar._output._slug import generate_slug
        from datetime import datetime as _dt
        root = os.path.join(log_dir, "agentsonar_logs")
        os.makedirs(root)

        session_id = "a" * 16
        slug = generate_slug(session_id)
        timestamp = _dt.now().strftime("%Y-%m-%d_%H-%M-%S")
        blocker_name = f"run-{timestamp}-{slug}"
        blocker_dir = os.path.join(root, blocker_name)
        os.makedirs(blocker_dir)
        # Drop a sentinel file in the blocker so we can verify it
        # wasn't touched by the new run.
        sentinel = os.path.join(blocker_dir, "sentinel.txt")
        with open(sentinel, "w") as f:
            f.write("BLOCKER")

        # Now create a logger with the same session_id. Its
        # computed run_name will collide with the blocker, and the
        # collision loop should append `-1`.
        logger = SonarLogger(
            output_dir=log_dir,
            console_output=False,
            keep_runs=0,
            session_id=session_id,
        )
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        # The blocker is untouched
        assert os.path.isfile(sentinel)
        assert open(sentinel).read() == "BLOCKER"

        # The new run landed in a distinct directory
        assert logger.run_dir != blocker_dir
        assert os.path.basename(logger.run_dir).startswith(f"{blocker_name}-")
        # And it contains the expected files
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))

    def test_retention_ignores_unrelated_directories(self, log_dir):
        """User directories inside agentsonar_logs/ that don't match
        the run-* pattern must NEVER be touched by the retention
        sweep, even if we'd otherwise prune them."""
        import time as _time
        root = os.path.join(log_dir, "agentsonar_logs")
        os.makedirs(root, exist_ok=True)
        # Drop a user-managed directory into logs_root
        user_dir = os.path.join(root, "my_manual_notes")
        os.makedirs(user_dir)
        with open(os.path.join(user_dir, "notes.txt"), "w") as f:
            f.write("do not delete")

        for i in range(5):
            logger = SonarLogger(
                output_dir=log_dir,
                console_output=False,
                keep_runs=2,
                session_id=self._RETENTION_SESSION_IDS[i],
            )
            logger.close()
            # No sleep needed — explicit session_ids guarantee slug uniqueness.

        # User dir must still be there
        assert os.path.isdir(user_dir)
        assert os.path.isfile(os.path.join(user_dir, "notes.txt"))
        # And we still pruned down to 2 run dirs
        runs = [
            name for name in os.listdir(root)
            if name.startswith("run-")
        ]
        assert len(runs) == 2


# -----------------------------------------------------------------------
# JSONL format
# -----------------------------------------------------------------------

class TestJSONLFormat:

    def test_jsonl_format(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("INFO", "test_event", {"key": "value"})
        logger.close()
        lines = _read_log_lines(log_dir)
        assert len(lines) == 1
        record = lines[0]
        assert "ts" in record
        assert record["level"] == "INFO"
        assert record["event"] == "test_event"
        assert record["data"] == {"key": "value"}

    def test_timestamp_format(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("INFO", "test", {})
        logger.close()
        lines = _read_log_lines(log_dir)
        ts = lines[0]["ts"]
        assert ts.endswith("Z")
        assert "T" in ts

    def test_timestamp_has_microsecond_precision(self, log_dir):
        """Regression: the JSONL `ts` field used to have millisecond
        precision (3 digits after the decimal). It now carries microsecond
        precision (6 digits) so two events in the same millisecond still
        order correctly and users can see exact ingest timing.

        Format: `YYYY-MM-DDTHH:MM:SS.ffffffZ` — .f is exactly 6 digits.
        """
        import re
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("INFO", "test", {})
        logger.close()
        lines = _read_log_lines(log_dir)
        ts = lines[0]["ts"]
        # Six digits of fractional seconds + trailing Z
        pattern = r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z$"
        assert re.match(pattern, ts), (
            f"expected microsecond precision timestamp, got {ts!r}"
        )


# -----------------------------------------------------------------------
# Log level filtering
# -----------------------------------------------------------------------

class TestLogLevelFilter:

    def test_log_level_warning_suppresses_debug_and_info(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="WARNING")
        logger.log("DEBUG", "debug_event", {})
        logger.log("INFO", "info_event", {})
        logger.log("WARNING", "warning_event", {})
        logger.log("CRITICAL", "critical_event", {})
        logger.close()
        lines = _read_log_lines(log_dir)
        events = [l["event"] for l in lines]
        assert "debug_event" not in events
        assert "info_event" not in events
        assert "warning_event" in events
        assert "critical_event" in events

    def test_log_level_debug_shows_all(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("DEBUG", "d", {})
        logger.log("INFO", "i", {})
        logger.log("WARNING", "w", {})
        logger.log("CRITICAL", "c", {})
        logger.close()
        lines = _read_log_lines(log_dir)
        assert len(lines) == 4


# -----------------------------------------------------------------------
# Delegation logging
# -----------------------------------------------------------------------

class TestDelegationLogging:

    def test_delegation_logging(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_delegation("researcher", "analyst", edge_count=3, delegation_number=5)
        logger.close()
        lines = _read_log_lines(log_dir)
        assert len(lines) == 1
        assert lines[0]["event"] == "delegation"
        assert lines[0]["data"]["source"] == "researcher"
        assert lines[0]["data"]["target"] == "analyst"
        assert lines[0]["data"]["edge_count"] == 3
        assert lines[0]["data"]["delegation_number"] == 5


# -----------------------------------------------------------------------
# Alert logging
# -----------------------------------------------------------------------

class TestAlertLogging:

    def test_alert_logging_uses_severity(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        alert = Alert(
            pattern="cycle",
            severity="WARNING",
            details={"fingerprint": ("a", "b"), "rotations": 5},
        )
        logger.log_alert(alert)
        logger.close()
        lines = _read_log_lines(log_dir)
        assert len(lines) == 1
        assert lines[0]["level"] == "WARNING"
        assert lines[0]["event"] == "alert"
        assert lines[0]["data"]["pattern"] == "cycle"

    def test_critical_alert_logged_as_critical(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        alert = Alert(
            pattern="rate_limit_exceeded",
            severity="CRITICAL",
            details={"source": "a", "target": "b", "estimated_rate": 11.0},
        )
        logger.log_alert(alert)
        logger.close()
        lines = _read_log_lines(log_dir)
        assert lines[0]["level"] == "CRITICAL"


# -----------------------------------------------------------------------
# Session lifecycle
# -----------------------------------------------------------------------

class TestSessionLifecycle:

    def test_session_start_and_end(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_session_start(session_id="test123", framework="crewai", agents=["a", "b"])
        logger.log_session_end({
            "total_events": 10,
            "alerts_raised": 2,
            "edge_counts": {"a->b": 5},
            "alerts": [],
        })
        lines = _read_log_lines(log_dir)
        assert lines[0]["event"] == "session_start"
        assert lines[0]["data"]["session_id"] == "test123"
        assert lines[0]["data"]["framework"] == "crewai"
        assert lines[-1]["event"] == "session_end"
        assert lines[-1]["data"]["total_events"] == 10

    def test_session_end_closes_file(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_session_start()
        logger.log_session_end({"total_events": 0, "alerts_raised": 0, "edge_counts": {}, "alerts": []})
        assert logger._closed is True

    def test_session_end_banner_shows_output_directory(self, log_dir, capsys):
        """Regression: the banner used to only mention `Log file: ...`
        (and that line overflowed the box border when the filename was
        long). Now it prints an `Output directory:` block below the
        box showing the run dir once and the filenames of every file
        in it in a tree layout."""
        logger = SonarLogger(output_dir=log_dir, console_output=True)
        logger.log_session_start()
        logger.log_session_end({
            "total_events": 1, "alerts_raised": 0,
            "edge_counts": {"a->b": 1}, "alerts": [],
        })
        captured = capsys.readouterr()
        # New header wording
        assert "Output directory:" in captured.err
        # The run dir path appears on its own line
        assert logger.run_dir in captured.err
        # Both log file basenames are listed in the tree
        assert "timeline.jsonl" in captured.err
        assert "alerts.log" in captured.err
        # And the tip pointing at the `latest` pointer
        assert "latest" in captured.err

    def test_session_end_banner_shows_report_basenames(self, log_dir, capsys):
        """Regression: when shutdown auto-exports JSON + HTML reports,
        their filenames must appear in the tree too so the user knows
        all 4 files landed in the run dir."""
        logger = SonarLogger(output_dir=log_dir, console_output=True)
        logger.log_session_start()
        # Fake report paths pointing inside the run dir — the banner
        # just uses basenames, so the parent directory doesn't need
        # to match perfectly for this test.
        fake_json = os.path.join(logger.run_dir, "report.json")
        fake_html = os.path.join(logger.run_dir, "report.html")
        logger.log_session_end(
            {
                "total_events": 1, "alerts_raised": 0,
                "edge_counts": {"a->b": 1}, "alerts": [],
            },
            report_paths={"json": fake_json, "html": fake_html},
        )
        captured = capsys.readouterr()
        # The fixed filenames appear in the tree output
        assert "report.json" in captured.err
        assert "report.html" in captured.err

    def test_session_end_banner_no_width_overflow(self, log_dir, capsys):
        """Regression: the old banner put the log filename INSIDE the
        48-char box. Long filenames pushed past the right border and
        broke the box alignment. Now filenames go below the box so
        there's no line inside the box that can overflow."""
        logger = SonarLogger(output_dir=log_dir, console_output=True)
        logger.log_session_start()
        logger.log_session_end({
            "total_events": 1, "alerts_raised": 0,
            "edge_counts": {"a->b": 1}, "alerts": [],
        })
        captured = capsys.readouterr()
        # Every line inside the box (lines starting with ║) must be
        # the same length — that's what a properly-aligned ASCII box
        # looks like. Collect all box lines and assert they all match.
        box_lines = [
            l for l in captured.err.splitlines()
            if l.startswith("\u2551")  # ║
        ]
        assert len(box_lines) >= 5  # header + rows
        widths = {len(l) for l in box_lines}
        assert len(widths) == 1, (
            f"box rows have inconsistent widths {widths} — right border overflow"
        )


# -----------------------------------------------------------------------
# Crash safety
# -----------------------------------------------------------------------

class TestCrashSafety:

    def test_file_survives_crash(self, log_dir):
        """Verify JSONL file has content before close() — flush after every write."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("INFO", "before_crash", {"msg": "important"})
        path = _find_jsonl_log(log_dir)
        with open(path, encoding="utf-8") as f:
            content = f.read()
        assert "before_crash" in content
        logger.close()


# -----------------------------------------------------------------------
# Console output
# -----------------------------------------------------------------------

class TestConsoleOutput:

    def test_console_output_to_stderr(self, log_dir, capsys):
        logger = SonarLogger(output_dir=log_dir, console_output=True, log_level="DEBUG")
        logger.log("INFO", "test_console", {"msg": "hello"})
        logger.close()
        captured = capsys.readouterr()
        assert captured.out == ""
        assert "SONAR" in captured.err

    def test_no_console_when_disabled(self, log_dir, capsys):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()
        captured = capsys.readouterr()
        assert captured.err == ""


# -----------------------------------------------------------------------
# Context manager
# -----------------------------------------------------------------------

class TestContextManager:

    def test_context_manager_closes(self, log_dir):
        with SonarLogger(output_dir=log_dir, console_output=False) as logger:
            logger.log("INFO", "test", {})
        assert logger._closed is True

    def test_double_close_safe(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False)
        logger.close()
        logger.close()


# -----------------------------------------------------------------------
# Alert resolved logging
# -----------------------------------------------------------------------

class TestAlertResolved:

    def test_alert_resolved_logging(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_alert_resolved(
            pattern="cycle",
            fingerprint=("a", "b"),
            total_rotations=18,
            duration_seconds=105.5,
        )
        logger.close()
        lines = _read_log_lines(log_dir)
        assert lines[0]["event"] == "alert_resolved"
        assert lines[0]["data"]["total_rotations"] == 18
        assert lines[0]["data"]["duration_seconds"] == 105.5


# -----------------------------------------------------------------------
# Alerts log (human-readable, signal-only)
# -----------------------------------------------------------------------

class TestAlertsLog:

    def test_allowlisted_events_appear_in_alerts_log(self, log_dir):
        """Formal alerts and lifecycle events go to the alerts log."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_session_start()
        logger.log_alert(Alert(
            pattern="cycle",
            severity="WARNING",
            details={"cycle_path": ["a", "b"], "rotations": 5},
        ))
        logger.log_alert(Alert(
            pattern="edge_anomaly",
            severity="CRITICAL",
            details={"source": "a", "target": "b", "event_count": 15, "rotations": 15},
        ))
        logger.log_alert_resolved(
            pattern="cycle",
            fingerprint=("a", "b"),
            total_rotations=18,
            duration_seconds=105.5,
        )
        logger.close()

        lines = _read_alerts_log(log_dir)
        assert len(lines) == 4
        joined = "\n".join(lines)
        assert "session started" in joined
        assert "cycle" in joined
        assert "edge_anomaly" in joined
        assert "RESOLVED" in joined

    def test_noise_events_excluded_from_alerts_log(self, log_dir):
        """delegation, graph_update, anomaly_detected, scc_sweep are skipped."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_delegation("a", "b", edge_count=1, delegation_number=1)
        logger.log_graph_update("a", "b", edge_count=1)
        logger.log_anomaly_detected({"source": "a", "target": "b", "weight": 11})
        logger.log_scc_sweep([{"fingerprint": ("scc", "a", "b")}])
        logger.close()

        lines = _read_alerts_log(log_dir)
        assert len(lines) == 0

    def test_alerts_log_has_event_count(self, log_dir):
        """Edge anomaly alerts show the event count (not just source->target)."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_alert(Alert(
            pattern="edge_anomaly",
            severity="CRITICAL",
            details={"source": "planner", "target": "researcher", "event_count": 15, "rotations": 15},
        ))
        logger.close()

        lines = _read_alerts_log(log_dir)
        assert len(lines) == 1
        assert "15 events" in lines[0]
        assert "planner -> researcher" in lines[0]

    def test_alerts_log_excluded_by_file_output_false(self, log_dir):
        """file_output=False disables BOTH the JSONL log and the alerts log."""
        logger = SonarLogger(output_dir=log_dir, file_output=False, console_output=False)
        logger.log_alert(Alert(
            pattern="cycle",
            severity="WARNING",
            details={"cycle_path": ["a", "b"], "rotations": 5},
        ))
        logger.close()
        # No agentsonar_logs directory should have been created at all
        assert not os.path.exists(os.path.join(log_dir, "agentsonar_logs"))

    def test_alerts_log_survives_crash(self, log_dir):
        """Flushed after every write — content visible before close()."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log_alert(Alert(
            pattern="cycle",
            severity="CRITICAL",
            details={"cycle_path": ["a", "b"], "rotations": 15},
        ))
        path = _find_alerts_log(log_dir)
        with open(path, encoding="utf-8") as f:
            content = f.read()
        assert "CRITICAL" in content
        assert "cycle" in content
        logger.close()

    def test_rate_limit_hit_formatted_cleanly(self, log_dir):
        """Regression: rate_limit_hit used to fall through to the JSON dump
        fallback because _format_console had no custom case for it."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        alert = Alert(
            pattern="rate_limit_exceeded",
            severity="CRITICAL",
            details={
                "source": "planner",
                "target": "researcher",
                "estimated_rate": 11.0,
                "limit": 5,
                "window_size": 60.0,
            },
        )
        logger.log_rate_limit_hit(alert)
        logger.close()

        lines = _read_alerts_log(log_dir)
        assert len(lines) == 1
        line = lines[0]
        assert "CRITICAL" in line
        assert "rate_limit_exceeded" in line
        assert "planner -> researcher" in line
        assert "rate: 11.0" in line
        assert "limit: 5" in line
        assert "{" not in line
        assert "}" not in line

    def test_global_rate_limit_formatted_without_agents(self, log_dir):
        """Global rate limit alerts have no source/target — formatter must
        handle that variant without crashing."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        alert = Alert(
            pattern="global_rate_exceeded",
            severity="CRITICAL",
            details={
                "estimated_rate": 201.0,
                "limit": 200,
                "window_size": 60.0,
            },
        )
        logger.log_rate_limit_hit(alert)
        logger.close()

        lines = _read_alerts_log(log_dir)
        assert len(lines) == 1
        line = lines[0]
        assert "CRITICAL" in line
        assert "global_rate_exceeded" in line
        assert "201.0" in line
        assert "200" in line
        assert "{" not in line

    def test_anomaly_detected_formatted_cleanly(self, log_dir):
        """Regression: anomaly_detected used to fall through to JSON dump."""
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        line = logger._format_console(
            "WARNING",
            "anomaly_detected",
            {"source": "a", "target": "b", "event_count": 11, "weight": 11.0},
            "12:34:56",
        )
        assert "a -> b" in line
        assert "11 events" in line
        assert "{" not in line
        logger.close()

    def test_stderr_suppresses_anomaly_detected(self, log_dir, capsys):
        """Regression: raw `anomaly_detected` signals used to flood stderr
        with `anomaly: a->b (N events)` lines right next to the formal
        `WARNING edge_anomaly` alert that followed them. The user saw
        the same information twice, once as a precursor and once as
        the formal alert. anomaly_detected now stays in the JSONL log
        (for forensic debugging) but NEVER reaches stderr."""
        logger = SonarLogger(
            output_dir=log_dir, console_output=True, log_level="DEBUG",
        )
        # Fire an anomaly_detected event directly
        logger.log_anomaly_detected({
            "source": "a", "target": "b", "event_count": 11, "weight": 11.0,
        })
        logger.close()
        captured = capsys.readouterr()
        # The anomaly line MUST NOT appear on stderr
        assert "anomaly: a -> b" not in captured.err
        # But it MUST be present in the JSONL log
        lines = _read_log_lines(log_dir)
        events = [l["event"] for l in lines]
        assert "anomaly_detected" in events

    def test_stderr_suppresses_cycle_detected(self, log_dir, capsys):
        """Regression: `cycle_detected` used to stream to stderr as a
        heads-up before the AlertStateManager decided whether to emit a
        formal WARNING/CRITICAL alert. Users saw `cycle found: [...]`
        immediately followed by `WARNING cycle: [...]` — duplicate
        information. Same fix as anomaly_detected: JSONL only, no stderr."""
        logger = SonarLogger(
            output_dir=log_dir, console_output=True, log_level="DEBUG",
        )
        logger.log_cycle_detected(
            cycle_path=["a", "b", "c"], rotations=1,
        )
        logger.close()
        captured = capsys.readouterr()
        # The raw heads-up must NOT appear on stderr
        assert "cycle found" not in captured.err
        # But still in the JSONL log
        lines = _read_log_lines(log_dir)
        events = [l["event"] for l in lines]
        assert "cycle_detected" in events

    def test_stderr_still_shows_formal_alerts(self, log_dir, capsys):
        """Counter-test: the events we DIDN'T suppress still reach
        stderr. Without this guard, we might accidentally widen the
        suppression list and hide actionable alerts too."""
        logger = SonarLogger(
            output_dir=log_dir, console_output=True, log_level="DEBUG",
        )
        logger.log_alert(Alert(
            pattern="cycle",
            severity="WARNING",
            details={"cycle_path": ["a", "b", "c"], "rotations": 5},
        ))
        logger.close()
        captured = capsys.readouterr()
        # Formal alerts DO appear on stderr
        assert "WARNING" in captured.err
        assert "cycle" in captured.err

    def test_stderr_prefix_has_millisecond_precision(self, log_dir):
        """Regression: the stderr [SONAR HH:MM:SS] prefix used to be
        second-level precision, so two events emitted in the same second
        appeared identical to the naked eye. It now uses millisecond
        precision: [SONAR HH:MM:SS.mmm]."""
        import re
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        logger.log("INFO", "test", {"key": "value"})
        logger.close()

        # Read the JSONL log to get a record — we can't easily capture
        # stderr from the log() helper, but we can exercise the prefix
        # builder directly via _format_console. The format string for
        # ts_short is computed inside log() right before _format_console
        # is called, so we rebuild the prefix manually using the same
        # code path and assert the regex.
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        ts_short = now.strftime("%H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        line = logger._format_console("INFO", "session_start", {"session_id": "abc"}, ts_short)
        # [SONAR HH:MM:SS.mmm] session started (id: abc)
        prefix_pattern = r"^\[SONAR \d{2}:\d{2}:\d{2}\.\d{3}\]"
        assert re.match(prefix_pattern, line), (
            f"expected stderr prefix with ms precision, got: {line!r}"
        )


# -----------------------------------------------------------------------
# Direct formatter unit tests — exercise every custom case in _format_console
# -----------------------------------------------------------------------

class TestFormatConsole:
    """Unit tests for SonarLogger._format_console to catch regressions in
    individual event type formatting."""

    @pytest.fixture
    def fmt(self, log_dir):
        logger = SonarLogger(output_dir=log_dir, console_output=False, log_level="DEBUG")
        yield logger._format_console
        logger.close()

    def test_delegation(self, fmt):
        line = fmt("DEBUG", "delegation",
                   {"source": "a", "target": "b", "delegation_number": 7},
                   "12:00:00")
        assert "a -> b" in line
        assert "#7" in line
        assert "{" not in line

    def test_session_start(self, fmt):
        line = fmt("INFO", "session_start", {"session_id": "abc123"}, "12:00:00")
        assert "session started" in line
        assert "abc123" in line
        assert "{" not in line

    def test_session_end(self, fmt):
        line = fmt(
            "INFO",
            "session_end",
            {"total_delegations": 42, "total_alerts": 7},
            "12:00:00",
        )
        assert "session ended" in line
        assert "42" in line
        assert "7" in line
        assert "{" not in line

    def test_cycle_detected(self, fmt):
        line = fmt(
            "INFO",
            "cycle_detected",
            {"cycle_path": ["a", "b", "c"], "rotations": 1},
            "12:00:00",
        )
        assert "a -> b -> c" in line
        assert "1 rotations" in line
        assert "cycle found" in line

    def test_cycle_detected_empty_path(self, fmt):
        """Defensive — if somehow cycle_path is empty, formatter shouldn't crash."""
        line = fmt("INFO", "cycle_detected", {"cycle_path": [], "rotations": 0}, "12:00:00")
        assert line
        assert "{" not in line

    def test_scc_sweep(self, fmt):
        line = fmt("DEBUG", "scc_sweep", {"components": [{"a": 1}, {"b": 2}]}, "12:00:00")
        assert "2 components" in line

    def test_alert_cycle_warning(self, fmt):
        line = fmt(
            "WARNING",
            "alert",
            {
                "pattern": "cycle",
                "severity": "WARNING",
                "cycle_path": ["x", "y", "z"],
                "rotations": 5,
            },
            "12:00:00",
        )
        assert "WARNING" in line
        assert "cycle" in line
        assert "x -> y -> z -> x" in line  # closed loop format
        assert "5 rotations" in line

    def test_alert_edge_anomaly_critical(self, fmt):
        line = fmt(
            "CRITICAL",
            "alert",
            {
                "pattern": "edge_anomaly",
                "severity": "CRITICAL",
                "source": "a",
                "target": "b",
                "event_count": 15,
            },
            "12:00:00",
        )
        assert "CRITICAL" in line
        assert "edge_anomaly" in line
        assert "a -> b" in line
        assert "15 events" in line

    def test_alert_resolved(self, fmt):
        line = fmt(
            "INFO",
            "alert_resolved",
            {
                "pattern": "cycle",
                "fingerprint": ["a", "b"],
                "duration_seconds": 120.5,
            },
            "12:00:00",
        )
        assert "RESOLVED" in line
        assert "cycle" in line
        assert "120.5" in line

    def test_rate_limit_hit_per_edge(self, fmt):
        line = fmt(
            "CRITICAL",
            "rate_limit_hit",
            {
                "pattern": "rate_limit_exceeded",
                "source": "a",
                "target": "b",
                "estimated_rate": 11.0,
                "limit": 5,
            },
            "12:00:00",
        )
        assert "CRITICAL" in line
        assert "rate_limit_exceeded" in line
        assert "a -> b" in line
        assert "rate: 11.0" in line
        assert "limit: 5" in line

    def test_rate_limit_hit_global(self, fmt):
        """Global variant has no source/target."""
        line = fmt(
            "CRITICAL",
            "rate_limit_hit",
            {
                "pattern": "global_rate_exceeded",
                "estimated_rate": 201.0,
                "limit": 200,
            },
            "12:00:00",
        )
        assert "CRITICAL" in line
        assert "global_rate_exceeded" in line
        assert "201.0" in line
        assert "200" in line
        assert "->" not in line

    def test_unknown_event_falls_through(self, fmt):
        """Unknown events use the fallback JSON dump — not pretty but not broken."""
        line = fmt("INFO", "unknown_event_type", {"foo": "bar"}, "12:00:00")
        assert "unknown_event_type" in line
        assert "foo" in line

    def test_alert_scc_shows_agents(self, fmt):
        """Regression: SCC alerts carry an `agents` list (not cycle_path or
        source/target). The alert formatter used to have no branch for them."""
        line = fmt(
            "WARNING",
            "alert",
            {
                "pattern": "scc_cycle",
                "severity": "WARNING",
                "agents": ["planner", "researcher", "reviewer"],
                "size": 3,
                "rotations": 5,
                "fingerprint": ["scc", "planner", "researcher", "reviewer"],
            },
            "12:00:00",
        )
        assert "WARNING" in line
        assert "scc_cycle" in line
        assert "planner" in line
        assert "researcher" in line
        assert "reviewer" in line
        assert "5 rotations" in line
        assert "{'pattern'" not in line
        assert '"pattern"' not in line

    def test_alert_scc_critical(self, fmt):
        """SCC alerts also work at CRITICAL level."""
        line = fmt(
            "CRITICAL",
            "alert",
            {
                "pattern": "scc_cycle",
                "severity": "CRITICAL",
                "agents": ["a", "b"],
                "rotations": 20,
            },
            "12:00:00",
        )
        assert "CRITICAL" in line
        assert "scc_cycle" in line
        assert "a" in line
        assert "b" in line
        assert "20 rotations" in line

    def test_alert_scc_empty_agents(self, fmt):
        """Defensive: empty agents list shouldn't crash the formatter."""
        line = fmt(
            "WARNING",
            "alert",
            {
                "pattern": "scc_cycle",
                "severity": "WARNING",
                "agents": [],
                "rotations": 0,
            },
            "12:00:00",
        )
        assert line
        assert "scc_cycle" in line
