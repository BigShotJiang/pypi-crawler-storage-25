"""
Cross-platform correctness tests.

Pins behavior that would typically only break on one OS — Windows
filename rules, Linux case-sensitive paths, macOS HFS normalization,
UTF-8 encoding defaults, long path handling. Runs on every platform
CI (Linux + macOS + Windows) but most tests exercise platform-specific
quirks like "colons aren't legal in Windows filenames".

Organization
------------
  TestFilenameRules       — run dir names don't contain OS-hostile chars
  TestEncoding            — explicit UTF-8 everywhere, no locale dependence
  TestPathJoining         — no hardcoded separators, os.path.join everywhere
  TestUnicodePaths        — Unicode in log_dir, agent names, session_ids
  TestLongPaths           — Windows MAX_PATH (260) awareness
  TestFileTypeProbing     — detects dir-vs-file confusion gracefully
"""
from __future__ import annotations

import json
import os
import platform
import sys

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent
from agentsonar._output.terminal import SonarLogger
from agentsonar._output.html_report import events_to_html
from agentsonar._output.json_export import events_to_json


# -------------------------------------------------------------------
# Filename rules (OS-hostile characters)
# -------------------------------------------------------------------

class TestFilenameRules:
    """Characters forbidden in Windows filenames: `< > : " / \\ | ? *`
    plus the device names (CON, PRN, AUX, NUL, COM1..COM9, LPT1..LPT9).

    Our run directory format is `run-YYYY-MM-DD_HH-MM-SS-slug`, which
    uses hyphens and underscores only — no colons, no spaces, no
    reserved characters. Assert that property over many generated
    run dir names so a future format change that introduces a colon
    (say) is caught immediately.
    """

    _FORBIDDEN_CHARS = set('<>:"/\\|?*')
    _RESERVED_BASENAMES = frozenset({
        "con", "prn", "aux", "nul",
        "com1", "com2", "com3", "com4", "com5", "com6", "com7", "com8", "com9",
        "lpt1", "lpt2", "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9",
    })

    def test_run_dir_name_has_no_forbidden_characters(self, tmp_path):
        """Build several run dirs with different session_ids and
        assert every one is free of Windows-hostile characters."""
        session_ids = [
            "aaaaaaaa" * 2,
            "bbbbbbbb" * 2,
            "12345678" * 2,
            "deadbeef" * 2,
        ]
        for sid in session_ids:
            logger = SonarLogger(
                output_dir=str(tmp_path),
                console_output=False,
                keep_runs=0,
                session_id=sid,
            )
            run_name = os.path.basename(logger.run_dir)
            bad = self._FORBIDDEN_CHARS & set(run_name)
            assert not bad, (
                f"run dir name {run_name!r} contains forbidden chars: {bad}"
            )
            logger.close()

    def test_run_dir_name_is_not_a_windows_reserved_name(self, tmp_path):
        """The slug generator could theoretically produce a basename
        that matches a Windows reserved device name. Check that the
        full run dir name (which has the `run-...` prefix) can't
        trigger this regardless of slug."""
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        run_name = os.path.basename(logger.run_dir)
        # Windows compares reserved names case-insensitively, ignoring
        # extensions. The `run-` prefix makes a perfect match impossible
        # (no reserved name starts with "run-"), but verify.
        assert run_name.lower() not in self._RESERVED_BASENAMES
        logger.close()

    def test_logs_root_name_has_no_forbidden_characters(self, tmp_path):
        """The `agentsonar_logs/` top-level directory name is also
        free of Windows-hostile characters. Pins the constant."""
        logger = SonarLogger(
            output_dir=str(tmp_path), console_output=False, keep_runs=0,
        )
        assert "agentsonar_logs" in logger.logs_root
        bad = self._FORBIDDEN_CHARS & set("agentsonar_logs")
        assert not bad
        logger.close()


# -------------------------------------------------------------------
# Encoding
# -------------------------------------------------------------------

class TestEncoding:
    """Every file write must use explicit UTF-8 encoding.

    Without `encoding="utf-8"`, Python's `open()` uses the locale
    encoding, which is cp1252 on Windows by default. cp1252 can't
    represent emoji or most non-Latin characters, so any agent name
    with a non-Latin character would crash the JSONL write on
    Windows. Tests here verify the encoding is respected across
    every output channel.
    """

    def test_jsonl_log_accepts_unicode(self, tmp_path):
        """JSONL log must accept emoji + CJK + Cyrillic + Arabic
        in event data without encoding errors, even on Windows."""
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            log_level="DEBUG",
            keep_runs=0,
        )
        logger.log("INFO", "test", {
            "emoji": "🤖",
            "chinese": "分析师",
            "cyrillic": "планировщик",
            "arabic": "مراجع",
            "zero_width": "a\u200bb",
            "combining": "é",
            "surrogate_pair_display": "𝓗𝓮𝓵𝓵𝓸",
        })
        logger.close()

        # File must exist, contain the Unicode, and re-parse cleanly
        path = os.path.join(logger.run_dir, "timeline.jsonl")
        with open(path, encoding="utf-8") as f:
            content = f.read()
        assert "🤖" in content
        assert "分析师" in content
        assert "планировщик" in content
        assert "مراجع" in content
        # Re-parse as JSONL to verify it's not corrupt
        for line in content.splitlines():
            if line.strip():
                json.loads(line)

    def test_html_report_accepts_unicode(self, tmp_path):
        """HTML report export must preserve Unicode through events_to_html."""
        from agentsonar._core.schema import (
            CoordinationEvent, Topology, FailureClass, AlertSeverity,
        )
        topo = Topology(
            agents_involved=("🤖-bot", "分析师"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={"🤖-bot->分析师": 5},
        )
        event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-unicode",
            session_id="sess-unicode",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:unicode",
            topology=topo,
            summary="Unicode test: 🤖 → 分析师",
        )
        html = events_to_html([event])
        # All Unicode characters survive the render
        assert "🤖" in html
        assert "分析师" in html

    def test_stdin_encoding_independence(self, tmp_path, monkeypatch):
        """JSONL output must not depend on `sys.stdin.encoding` or
        `locale.getpreferredencoding()`. Simulate a broken locale
        and verify writes still work."""
        # Pretend we're on a legacy Windows machine where the system
        # default encoding is cp1252 (can't encode emoji)
        import locale as _locale
        monkeypatch.setattr(_locale, "getpreferredencoding", lambda *a: "cp1252")

        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
        )
        logger.log("INFO", "emoji-test", {"data": "🌙 ☀️ 🚨"})
        logger.close()

        path = os.path.join(logger.run_dir, "timeline.jsonl")
        content = open(path, encoding="utf-8").read()
        assert "🌙" in content
        assert "☀️" in content
        assert "🚨" in content


# -------------------------------------------------------------------
# Path joining
# -------------------------------------------------------------------

class TestPathJoining:
    """No hardcoded `/` or `\\` separators anywhere in the code that
    builds user-visible paths. All path construction must go through
    `os.path.join`, `os.path.basename`, etc. so the separators are
    platform-correct."""

    def test_run_dir_uses_platform_separator(self, tmp_path):
        """The run_dir attribute on the logger must contain the
        native path separator (os.sep) for the current platform."""
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        # On Windows os.sep == "\\"; elsewhere "/"
        # Verify the path uses the native separator consistently
        assert logger.run_dir is not None
        assert os.sep in logger.run_dir
        logger.close()

    def test_log_dir_with_trailing_separator(self, tmp_path):
        """`log_dir` ending in a trailing separator (Unix `/` or
        Windows `\\`) should still work — `os.path.join` and
        `os.makedirs` handle both. Users typing paths like
        `./my_logs/` shouldn't be surprised."""
        trailing = str(tmp_path) + os.sep
        logger = SonarLogger(
            output_dir=trailing,
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        assert logger.run_dir is not None
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))

    def test_log_dir_with_parent_traversal_component(self, tmp_path):
        """`log_dir` containing `..` is a weird but valid input —
        it should resolve to the actual target directory, not crash."""
        nested = tmp_path / "child" / ".." / "real_child"
        # Make sure 'real_child' doesn't exist yet
        real = tmp_path / "real_child"
        assert not real.exists()

        logger = SonarLogger(
            output_dir=str(nested),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        # The real directory should now exist
        assert real.exists() or (tmp_path / "real_child").exists()


# -------------------------------------------------------------------
# Unicode paths
# -------------------------------------------------------------------

class TestUnicodePaths:
    """Unicode in log_dir paths, agent names, session_ids. This
    historically broke on Windows + Python 2.x and on some older
    Linux filesystems with non-UTF-8 locales. Modern Python 3 should
    handle all of these; these tests are regression guards."""

    def test_unicode_in_log_dir(self, tmp_path):
        """Non-ASCII directory name for log_dir — must work on every OS."""
        unicode_dir = tmp_path / "日志_logs_🌙"
        logger = SonarLogger(
            output_dir=str(unicode_dir),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        assert logger.run_dir is not None
        assert unicode_dir.exists()
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))

    def test_unicode_session_id(self, tmp_path):
        """Non-hex, non-ASCII session_ids must still produce a valid
        slug. The slug module UTF-8 encodes the seed before hashing
        so this works for any input, but let's pin it in a test."""
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="会话_🌙_id",
        )
        assert logger.run_dir is not None
        # The run dir name should be pure ASCII (slug-safe) even with
        # a Unicode session_id
        run_name = os.path.basename(logger.run_dir)
        assert run_name.isascii(), (
            f"run dir name {run_name!r} should be ASCII-safe even with "
            "a Unicode session_id"
        )
        logger.close()

    def test_unicode_agent_names_through_engine(self, tmp_path):
        """Every layer of the detection pipeline + all 4 output
        artifacts tolerate Unicode agent names."""
        engine = DetectionEngine({
            "log_dir": str(tmp_path),
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        import time
        now = time.time()
        # Deliberate cycle with Unicode agent names
        for i in range(10):
            engine.ingest(InteractionEvent("🤖", "分析师", now + i * 0.1))
            engine.ingest(InteractionEvent("分析师", "🤖", now + i * 0.1 + 0.05))
        engine.shutdown()

        run_dir = engine.logger.run_dir
        assert run_dir is not None
        # All 4 files present
        for name in ("timeline.jsonl", "alerts.log", "report.json", "report.html"):
            assert os.path.isfile(os.path.join(run_dir, name))

        # JSON report parses cleanly and contains the Unicode names
        with open(os.path.join(run_dir, "report.json"), encoding="utf-8") as f:
            data = json.load(f)
        assert len(data) >= 1
        serialized = json.dumps(data, ensure_ascii=False)
        assert "🤖" in serialized or "分析师" in serialized


# -------------------------------------------------------------------
# Long paths
# -------------------------------------------------------------------

class TestLongPaths:
    """Windows MAX_PATH is 260 characters (including drive letter,
    colons, and final null). The `\\\\?\\` prefix disables the limit
    but Python's open() doesn't always use it automatically.

    Our run dir names add ~40 characters to the log_dir path, plus
    filenames another ~15, so the absolute path can approach MAX_PATH
    for users whose log_dir is already deeply nested. Test with a
    log_dir that's 150+ characters and verify the logger still opens
    files correctly."""

    def test_deeply_nested_log_dir(self, tmp_path):
        """log_dir path ~150 chars + our ~60-char run dir = ~210
        char absolute paths. Well under Windows MAX_PATH but verifies
        the deep-nesting path works."""
        nested = tmp_path
        # Build up ~150 chars of nested directories
        for segment in ["alpha_team", "production", "experiment_42",
                        "multi_agent_runs", "crew_alpha", "session_data"]:
            nested = nested / segment
        nested.mkdir(parents=True, exist_ok=True)

        logger = SonarLogger(
            output_dir=str(nested),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        assert logger.run_dir is not None
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))

    def test_short_log_dir_works_fine(self, tmp_path):
        """Baseline: a short log_dir path works — guards against
        accidental regressions where we hardcode a minimum path depth."""
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        logger.close()
        assert logger.run_dir is not None


# -------------------------------------------------------------------
# Platform detection smoke test
# -------------------------------------------------------------------

class TestPlatformMetadata:
    """Quick smoke test that assertions about the running platform
    make sense. If these fail, something's deeply wrong with the
    test environment."""

    def test_running_on_known_platform(self):
        system = platform.system()
        assert system in {"Windows", "Linux", "Darwin", "Java"}, (
            f"unexpected platform: {system}"
        )

    def test_sys_platform_matches_os_name(self):
        """sys.platform and os.name should agree on what we're on."""
        if sys.platform == "win32":
            assert os.name == "nt"
        elif sys.platform.startswith("linux"):
            assert os.name == "posix"
        elif sys.platform == "darwin":
            assert os.name == "posix"
