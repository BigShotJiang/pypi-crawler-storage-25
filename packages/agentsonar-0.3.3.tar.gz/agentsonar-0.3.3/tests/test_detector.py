"""
Integration tests for the full DetectionEngine (all 5 layers working together).

No LLM calls — feeds InteractionEvent objects directly into the engine.
"""
import os
import time

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent
from agentsonar._core.schema import FailureClass

# Disable file and console output for all engine tests to avoid log file litter
_TEST_CONFIG = {"file_output": False, "console_output": False}


def _engine(overrides: dict | None = None) -> DetectionEngine:
    """Create a DetectionEngine with file/console output disabled."""
    config = dict(_TEST_CONFIG)
    if overrides:
        config.update(overrides)
    return DetectionEngine(config)


def _event(src: str, tgt: str, ts: float | None = None) -> InteractionEvent:
    return InteractionEvent(
        source_agent=src,
        target_agent=tgt,
        timestamp=ts if ts is not None else time.time(),
    )


def _event_with_tokens(src: str, tgt: str, tokens: int, ts: float | None = None) -> InteractionEvent:
    return InteractionEvent(
        source_agent=src,
        target_agent=tgt,
        timestamp=ts if ts is not None else time.time(),
        metadata={"tokens": tokens},
    )


# -----------------------------------------------------------------------
# Clean scenarios (no alerts expected)
# -----------------------------------------------------------------------

class TestCleanScenarios:

    def test_sequential_no_delegations(self):
        engine = _engine()
        summary = engine.get_summary()
        assert summary["total_events"] == 0
        assert summary["alerts_raised"] == 0

    def test_single_delegation_no_alert(self):
        engine = _engine()
        alerts = engine.ingest(_event("manager", "researcher"))
        assert len(alerts) == 0

    def test_few_delegations_no_alert(self):
        """A handful of normal delegations shouldn't trigger anything."""
        engine = _engine({"warning_threshold": 5, "critical_threshold": 15})
        now = 1000.0
        engine.ingest(_event("manager", "researcher", now))
        engine.ingest(_event("manager", "analyst", now + 1))
        alerts = engine.ingest(_event("researcher", "analyst", now + 2))
        assert len(alerts) == 0


# -----------------------------------------------------------------------
# Cycle detection through the engine
# -----------------------------------------------------------------------

class TestEngineCycleDetection:

    def test_cycle_detected_via_engine(self):
        """A->B->A cycle should eventually trigger an alert through AlertStateManager."""
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        all_alerts = []
        for i in range(10):
            all_alerts.extend(engine.ingest(_event("a", "b", now + i * 0.5)))
            all_alerts.extend(engine.ingest(_event("b", "a", now + i * 0.5 + 0.25)))
        cycle_alerts = [a for a in all_alerts if a.pattern == "cycle"]
        assert len(cycle_alerts) >= 1

    def test_no_cycle_in_chain(self):
        """A->B->C with no back-edge produces no cycle alerts."""
        engine = _engine({"hard_weight_limit": 100.0})
        now = 1000.0
        engine.ingest(_event("a", "b", now))
        alerts = engine.ingest(_event("b", "c", now + 1))
        cycle_alerts = [a for a in alerts if a.pattern == "cycle"]
        assert len(cycle_alerts) == 0

    def test_cycle_log_message_deduplicated(self):
        """The 'cycle found' log message should fire only once per cycle fingerprint.

        Without dedup, a 3-agent cycle running for many iterations would
        flood the terminal with duplicate 'cycle found' messages.
        """
        engine = _engine({
            "warning_threshold": 100,  # high so no formal alerts fire
            "critical_threshold": 200,
            "hard_weight_limit": 1000.0,
        })
        now = 1000.0
        # Create a 3-agent cycle and traverse it 5 times
        for i in range(5):
            engine.ingest(_event("a", "b", now + i * 1.0))
            engine.ingest(_event("b", "c", now + i * 1.0 + 0.1))
            engine.ingest(_event("c", "a", now + i * 1.0 + 0.2))

        # The cycle fingerprint should only be logged once
        assert len(engine._logged_cycles) == 1
        assert ("a", "b", "c") in engine._logged_cycles


# -----------------------------------------------------------------------
# Rate limit circuit breaker through the engine
# -----------------------------------------------------------------------

class TestEngineRateLimit:

    def test_rate_limit_fires_on_burst(self):
        """Rapid-fire delegations on one edge should trigger circuit breaker."""
        engine = _engine({
            "per_edge_limit": 5,
            "window_size": 60.0,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        all_alerts = []
        for i in range(10):
            all_alerts.extend(engine.ingest(_event("a", "b", now + i * 0.1)))
        rate_alerts = [a for a in all_alerts if a.pattern == "rate_limit_exceeded"]
        assert len(rate_alerts) >= 1
        assert rate_alerts[0].severity == "CRITICAL"

    def test_rate_limit_early_return_does_not_crash(self):
        """Regression: Layer 1 early-return must not reference undefined self.alerts."""
        engine = _engine({
            "per_edge_limit": 2,
            "window_size": 60.0,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        # First 2 events are fine, 3rd triggers per-edge limit
        engine.ingest(_event("a", "b", now))
        engine.ingest(_event("a", "b", now + 1))
        alerts = engine.ingest(_event("a", "b", now + 2))
        # Should return the rate limit alert, not crash
        assert len(alerts) == 1
        assert alerts[0].pattern == "rate_limit_exceeded"
        # Summary should also reflect it
        summary = engine.get_summary()
        assert summary["alerts_raised"] >= 1


# -----------------------------------------------------------------------
# Loop scenario simulation (13+ one-directional delegations)
# -----------------------------------------------------------------------

class TestLoopScenario:

    def test_loop_13_delegations_produces_alerts(self):
        """Simulates the loop scenario: 13+ one-directional Researcher->Analyst."""
        engine = _engine({
            "warning_threshold": 3,
            "critical_threshold": 7,
            "hard_weight_limit": 5.0,
            "per_edge_limit": 50,
        })
        now = 1000.0
        all_alerts = []
        for i in range(13):
            all_alerts.extend(engine.ingest(_event("researcher", "analyst", now + i)))
        assert len(all_alerts) >= 1
        summary = engine.get_summary()
        assert summary["edge_counts"]["researcher->analyst"] == 13


# -----------------------------------------------------------------------
# Token waste tracking
# -----------------------------------------------------------------------

class TestTokenTracking:

    def test_token_waste_accumulated(self):
        engine = _engine()
        now = 1000.0
        for i in range(5):
            engine.ingest(_event_with_tokens("a", "b", 100, now + i))
        summary = engine.get_summary()
        assert summary["total_estimated_token_waste"] == 500


# -----------------------------------------------------------------------
# Engine summary structure
# -----------------------------------------------------------------------

class TestEngineSummary:

    def test_summary_structure(self):
        engine = _engine()
        engine.ingest(_event("a", "b"))
        engine.increment_iteration()
        summary = engine.get_summary()
        assert summary["total_events"] == 1
        assert summary["iteration_count"] == 1
        assert "a->b" in summary["edge_counts"]
        assert isinstance(summary["alerts"], list)

    def test_bug1_get_summary_does_not_close_logger(self):
        """Bug 1 regression: get_summary() must not close the logger."""
        engine = _engine()
        engine.ingest(_event("a", "b"))
        engine.get_summary()
        # Logger should still be open — subsequent ingest + get_summary should work
        engine.ingest(_event("b", "c"))
        summary = engine.get_summary()
        assert summary["total_events"] == 2
        assert not engine.logger._closed

    def test_shutdown_closes_logger(self):
        """shutdown() should close the logger, not get_summary()."""
        engine = _engine()
        engine.ingest(_event("a", "b"))
        engine.shutdown()
        assert engine.logger._closed

    def test_shutdown_idempotent(self):
        """Calling shutdown() twice is a no-op the second time."""
        engine = _engine()
        engine.ingest(_event("a", "b"))
        engine.shutdown()
        # Second call should not raise, not do work, and not flip any state
        engine.shutdown()
        assert engine.logger._closed
        assert engine._shutdown_requested

    def test_shutdown_runs_final_check_recoveries(self, tmp_path):
        """Regression: `check_recoveries()` only fires from inside the
        ingest path. A workload that goes idle (crew finishes, no more
        events) would never get its RESOLVED alerts because no fresh
        events trigger the recovery check. shutdown() now runs a final
        sweep so idle alerts get their RESOLVED notification before
        the logger closes.
        """
        import time as _time
        # Short resolve_after_seconds so the test doesn't need to sleep
        engine = _engine({
            "log_dir": str(tmp_path),
            "file_output": True,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
            "resolve_after_seconds": 0.01,
        })
        now = 1000.0
        # Fire a WARNING cycle alert
        for i in range(5):
            engine.ingest(_event("a", "b", now + i * 0.1))
            engine.ingest(_event("b", "a", now + i * 0.1 + 0.05))

        # One of the alerts in the tracked set should now be ACTIVE
        tracked = engine._alert_mgr._tracked
        assert any(
            t.state in ("ACTIVE", "ESCALATED") for t in tracked.values()
        ), "expected at least one active tracked alert before shutdown"

        # Wait out the resolve_after_seconds quiet period
        _time.sleep(0.05)

        engine.shutdown()

        # After shutdown, all tracked alerts must be RESOLVED
        assert all(
            t.state == "RESOLVED" for t in tracked.values()
        ), "expected all tracked alerts to be RESOLVED after shutdown"

        # And the alerts log (inside the run dir) must contain the
        # resolved entries. Walk into the new agentsonar_logs/ layout
        # to find the per-run alerts.log.
        run_dir = engine.logger.run_dir
        assert run_dir is not None
        alerts_path = os.path.join(run_dir, "alerts.log")
        assert os.path.isfile(alerts_path)
        content = open(alerts_path, encoding="utf-8").read()
        assert "RESOLVED" in content

    def test_shutdown_recoveries_recorded_in_summary(self, tmp_path):
        """The final recovery sweep must increment `alerts_raised` so
        the session-end summary banner shows the full count including
        the final RESOLVED alerts."""
        import time as _time
        engine = _engine({
            "log_dir": str(tmp_path),
            "file_output": False,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
            "resolve_after_seconds": 0.01,
        })
        now = 1000.0
        for i in range(5):
            engine.ingest(_event("a", "b", now + i * 0.1))
            engine.ingest(_event("b", "a", now + i * 0.1 + 0.05))
        alert_count_before_shutdown = engine._alert_count

        _time.sleep(0.05)
        engine.shutdown()

        # Shutdown should have added at least one RESOLVED alert
        assert engine._alert_count > alert_count_before_shutdown, (
            f"shutdown did not add any RESOLVED alerts "
            f"(before={alert_count_before_shutdown}, after={engine._alert_count})"
        )

    def test_shutdown_does_not_resolve_active_workload(self, tmp_path):
        """Counter-test: if the workload is still active at shutdown
        (events just happened), `check_recoveries()` should NOT
        resolve anything because `now - last_activity_time` is tiny.
        Marking active alerts RESOLVED at shutdown would be misleading."""
        import time as _time
        engine = _engine({
            "log_dir": str(tmp_path),
            "file_output": False,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
            # Long quiet period so shutdown's `now` is NOT past it
            "resolve_after_seconds": 3600.0,
        })
        now = _time.time()
        for i in range(5):
            engine.ingest(_event("a", "b", now + i * 0.001))
            engine.ingest(_event("b", "a", now + i * 0.001 + 0.0005))

        engine.shutdown()

        # All tracked alerts should still be ACTIVE/ESCALATED — we
        # did NOT resolve them at shutdown because they're still hot.
        tracked = engine._alert_mgr._tracked
        assert all(
            t.state in ("ACTIVE", "ESCALATED") for t in tracked.values()
        ), "shutdown incorrectly marked live alerts as RESOLVED"

    def test_shutdown_latch_prevents_double_work(self):
        """Regression: concurrent shutdown() calls must be serialized so
        only one caller emits log_session_end. The _shutdown_requested
        latch is set atomically inside the lock."""
        import threading
        engine = _engine()
        engine.ingest(_event("a", "b"))

        log_session_end_calls = [0]
        original = engine.logger.log_session_end

        # *args/**kwargs so the wrapper stays compatible if the
        # log_session_end signature grows more optional params
        # (e.g. report_paths was added in a later change — before
        # that this wrapper was a simple `def counting_wrapper(summary)`
        # which broke when the engine started passing report_paths).
        def counting_wrapper(*args, **kwargs):
            log_session_end_calls[0] += 1
            original(*args, **kwargs)

        engine.logger.log_session_end = counting_wrapper

        # Spawn 5 threads that all try to shut down simultaneously
        threads = [threading.Thread(target=engine.shutdown) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Exactly one thread should have reached log_session_end
        assert log_session_end_calls[0] == 1, (
            f"expected 1 log_session_end call, got {log_session_end_calls[0]}"
        )
        assert engine._shutdown_requested


# -----------------------------------------------------------------------
# CoordinationEvent integration — the new schema layer
# -----------------------------------------------------------------------

class TestCoordinationEventIntegration:

    def test_cycle_produces_coordination_event(self):
        """A->B->A cycle should produce a CYCLIC_DELEGATION CoordinationEvent."""
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        for i in range(10):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))

        events = engine.get_recent_events()
        cycle_events = [e for e in events if e.failure_class == FailureClass.CYCLIC_DELEGATION]
        assert len(cycle_events) >= 1
        ev = cycle_events[0]
        assert ev.topology is not None
        assert ev.topology.interaction_pattern == "circular"
        assert ev.coordination_fingerprint.startswith("sha256:")
        assert ev.summary  # non-empty
        assert ev.session_id == engine.session_id
        # Regression guard: the old detection_method field was removed
        # from the schema (it leaked internal layer names into public JSON).
        assert not hasattr(ev.topology, "detection_method")

    def test_global_rate_limit_attributes_triggering_event(self):
        """Global rate alerts don't include source/target in details.

        Regression: _build_rate_limit_event must fall back to the currently-
        ingested event's src/tgt so the CoordinationEvent still has meaningful
        attribution. Also verifies error_type reflects the global variant.
        """
        engine = _engine({
            "per_edge_limit": 1000,
            "global_limit": 5,
            "window_size": 60.0,
            "hard_weight_limit": 1000.0,
        })
        now = 1000.0
        # Distinct edges so per-edge limit never fires
        edges = [("src" + str(i), "tgt" + str(i)) for i in range(8)]
        for i, (s, t) in enumerate(edges):
            engine.ingest(_event(s, t, now + i * 0.1))

        events = engine.get_recent_events()
        rate_events = [e for e in events if e.failure_class == FailureClass.RESOURCE_EXHAUSTION]
        assert len(rate_events) >= 1
        ev = rate_events[0]
        # Agents must be the triggering event's src/tgt, NOT "unknown"
        assert ev.topology is not None
        assert ev.topology.agents_involved[0] != "unknown"
        assert ev.topology.agents_involved[1] != "unknown"
        # error_type distinguishes global from per-edge
        assert ev.provider_error is not None
        assert ev.provider_error.error_type == "global_rate_exceeded"

    def test_rate_limit_produces_resource_exhaustion_event(self):
        """Burst delegations should produce a RESOURCE_EXHAUSTION event."""
        engine = _engine({
            "per_edge_limit": 2,
            "window_size": 60.0,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        for i in range(10):
            engine.ingest(_event("a", "b", now + i * 0.1))

        events = engine.get_recent_events()
        rate_events = [e for e in events if e.failure_class == FailureClass.RESOURCE_EXHAUSTION]
        assert len(rate_events) >= 1
        ev = rate_events[0]
        assert ev.provider_error is not None
        assert ev.provider_error.error_type == "rate_limit_exceeded"
        # Regression guard: no provider field
        assert not hasattr(ev.provider_error, "provider")
        assert ev.downstream_impact is not None
        assert "b" in ev.downstream_impact.blocked_agents

    def test_repetitive_produces_one_directional_event(self):
        """One-directional hammering should produce REPETITIVE_DELEGATION."""
        engine = _engine({
            "warning_threshold": 3,
            "critical_threshold": 7,
            "hard_weight_limit": 5.0,
            "per_edge_limit": 50,
        })
        now = 1000.0
        for i in range(13):
            engine.ingest(_event("a", "b", now + i * 1.0))

        events = engine.get_recent_events()
        rep_events = [e for e in events if e.failure_class == FailureClass.REPETITIVE_DELEGATION]
        assert len(rep_events) >= 1
        ev = rep_events[0]
        assert ev.topology is not None
        assert ev.topology.interaction_pattern == "one_directional"
        # A directed edge involves 2 agents (src, tgt). The old
        # delegation_depth field was 1 here (meaning "one hop"); the new
        # agent_count is 2 (meaning "two agents participating") which is
        # more intuitive and consistent with cycles.
        assert ev.topology.agent_count == 2
        assert ev.topology.agents_involved == ("a", "b")
        # Regression guard: event has no cost_impact attribute
        assert not hasattr(ev, "cost_impact")
        # Regression guard: the old delegation_depth field was renamed.
        assert not hasattr(ev.topology, "delegation_depth")

    def test_fingerprint_stable_across_rotations(self):
        """Same cycle agents should produce the same fingerprint every time."""
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        for i in range(8):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))

        events = engine.get_recent_events()
        cycle_fps = {
            e.coordination_fingerprint
            for e in events
            if e.failure_class == FailureClass.CYCLIC_DELEGATION
        }
        # All cycle events should share the same fingerprint
        assert len(cycle_fps) == 1

    def test_get_recent_events_bounded(self):
        """_recent_events must respect _MAX_RECENT_EVENTS bound."""
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 2,
            "hard_weight_limit": 1.0,
            "per_edge_limit": 100,
            "window_size": 1.0,  # window large enough to avoid rate limit
        })
        # Shrink the bound so we can exercise it without thousands of events
        engine._MAX_RECENT_EVENTS = 10
        now = 1000.0
        # Create 50 distinct repetitive anomaly events (each on a different edge)
        for i in range(50):
            engine.ingest(_event(f"src{i}", f"tgt{i}", now + i))
            engine.ingest(_event(f"src{i}", f"tgt{i}", now + i + 0.1))

        events = engine.get_recent_events()
        assert len(events) <= 10

    def test_scc_path_produces_coordination_event(self):
        """Layer 5 (PeriodicSCCAnalyzer) must produce a CoordinationEvent via _build_scc_event.

        The default SCC interval is too long to fire in short tests, so force it
        to run on every event via scc_interval_events=1. Build a 2-agent cycle
        then keep ingesting to let the SCC sweep fire.
        """
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 1000.0,
            "per_edge_limit": 1000,
            "scc_interval_seconds": 0.0,
            "scc_interval_events": 1,
        })
        now = 1000.0
        # Build an A<->B cycle, then keep events flowing so the SCC detects it
        for i in range(12):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))

        # The SCC sweep DID run (forced via scc_interval_events=1) and
        # produced at least one CoordinationEvent through the shared
        # _build_scc_event pipeline. From the user's perspective there's
        # no way to distinguish SCC-detected from incrementally-detected
        # cycles in the output — both have interaction_pattern="circular"
        # and failure_class=CYCLIC_DELEGATION. We can't filter on a
        # user-visible field to isolate "the SCC one", so instead we
        # assert Layer 5's internal state moved, AND we verify we got
        # cycle events with the expected agents.
        assert engine._scc.last_run_time > 0, "Layer 5 SCC sweep did not run"

        events = engine.get_recent_events()
        cycle_events = [
            e for e in events
            if e.failure_class == FailureClass.CYCLIC_DELEGATION
            and e.topology is not None
        ]
        assert len(cycle_events) >= 1, "expected at least one cyclic event"
        # Both detection pipelines produce interaction_pattern="circular"
        # (unified output). "strongly_connected_component" was jargon.
        for ev in cycle_events:
            assert ev.topology.interaction_pattern == "circular"

        # Find the {a, b} cycle specifically
        ab_events = [
            e for e in cycle_events
            if set(e.topology.agents_involved) == {"a", "b"}
        ]
        assert len(ab_events) >= 1
        ev = ab_events[0]
        assert ev.topology.agent_count == 2
        # Every cycle event gets a valid sha256 fingerprint
        assert ev.coordination_fingerprint.startswith("sha256:")

    def test_event_building_failure_fallback(self, monkeypatch):
        """If a builder raises, engine returns a minimal fallback event."""
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })

        def broken_builder(cycle_info, alert):
            raise RuntimeError("simulated schema build failure")

        monkeypatch.setattr(engine, "_build_cycle_event", broken_builder)

        now = 1000.0
        for i in range(8):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))

        events = engine.get_recent_events()
        cycle_events = [e for e in events if e.failure_class == FailureClass.CYCLIC_DELEGATION]
        assert len(cycle_events) >= 1
        # Fallback events include the error text in summary
        fallback = cycle_events[0]
        assert fallback.coordination_fingerprint.startswith("error:")
        assert "cyclic_delegation" in fallback.coordination_fingerprint
        assert "schema build failed" in fallback.summary

    def test_fallback_events_have_unique_fingerprints(self, monkeypatch):
        """Regression: multiple builder failures must produce events with
        UNIQUE coordination_fingerprints so dedupe doesn't collapse them
        into a single row. Before the fix, all fallbacks shared the literal
        string "error" and the deduped report showed only the first one,
        hiding every subsequent builder failure from the user."""
        engine = _engine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })

        def broken_cycle(cycle_info, alert):
            raise RuntimeError("cycle builder broken")

        def broken_edge(anomaly, alert):
            raise RuntimeError("edge builder broken")

        monkeypatch.setattr(engine, "_build_cycle_event", broken_cycle)
        monkeypatch.setattr(engine, "_build_edge_anomaly_event", broken_edge)

        now = 1000.0
        # Traverse a cycle AND hammer a one-directional edge — both builders
        # should fire and both should take the fallback path
        for i in range(10):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))

        events = engine.get_recent_events()
        fallbacks = [
            e for e in events
            if e.coordination_fingerprint.startswith("error:")
        ]
        assert len(fallbacks) >= 2, "expected multiple fallbacks across builders"
        fingerprints = {e.coordination_fingerprint for e in fallbacks}
        # Every fallback must have a distinct fingerprint
        assert len(fingerprints) == len(fallbacks), (
            "fallback fingerprints collided — dedupe would collapse distinct failures"
        )

        # And in the deduped summary, every fallback survives
        from agentsonar._core.schema import dedupe_events_by_fingerprint
        deduped = dedupe_events_by_fingerprint(events)
        deduped_fallbacks = [
            e for e in deduped
            if e.coordination_fingerprint.startswith("error:")
        ]
        assert len(deduped_fallbacks) == len(fallbacks)

    def test_repetitive_directional_events_stay_distinct(self):
        """Regression: A→B repetitive spam and B→A repetitive spam are two
        distinct directed problems. Before the fix, the fingerprint sorted
        agents alphabetically and both directions collapsed into one event
        in the deduped report, losing visibility into one direction.

        This test deliberately picks agent names where the sort order
        would cause a collision: ("b","a") sorts differently from ("a","b")
        but they'd hash to the same thing without ordered=True.
        """
        engine = _engine({
            "warning_threshold": 3,
            "critical_threshold": 7,
            "hard_weight_limit": 4.0,
            "per_edge_limit": 1000,
            "half_life_seconds": 5.0,
        })
        now = 1000.0
        # Phase 1: hammer a→b (no b→a yet, so no cycle)
        for i in range(8):
            engine.ingest(_event("a", "b", now + i * 0.1))
        # Phase 2: hammer b→a — THIS creates the cycle, but the repetitive
        # events from Phase 1 already fired and are in the buffer
        for i in range(8):
            engine.ingest(_event("b", "a", now + 100 + i * 0.1))

        events = engine.get_recent_events()
        rep_events = [
            e for e in events
            if e.failure_class == FailureClass.REPETITIVE_DELEGATION
        ]
        ab_events = [
            e for e in rep_events
            if e.topology and e.topology.agents_involved == ("a", "b")
        ]
        ba_events = [
            e for e in rep_events
            if e.topology and e.topology.agents_involved == ("b", "a")
        ]
        if ab_events and ba_events:
            fp_ab = ab_events[0].coordination_fingerprint
            fp_ba = ba_events[0].coordination_fingerprint
            assert fp_ab != fp_ba, (
                "A→B and B→A repetitive events must have different fingerprints — "
                "they're distinct directed problems, not symptoms of one issue"
            )

    def test_shutdown_auto_exports_json_and_html(self, tmp_path):
        """Regression: shutdown() auto-generates JSON + HTML reports when
        file_output is enabled, giving zero-config users the full output
        set without writing a single extra line. This is what lets the
        README-minimal example produce HTML/JSON reports with nothing
        more than `AgentSonarCallback(); graph.invoke(); shutdown()`.
        """
        engine = DetectionEngine({
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
            "log_dir": str(tmp_path),
            "console_output": False,
            # file_output defaults True, and auto_export_on_shutdown
            # defaults to file_output's value — so auto-export is ON.
        })
        now = 1000.0
        for i in range(10):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))
        engine.shutdown()

        # Expect all 4 files (report.json/html + timeline/alerts) inside
        # the per-run session directory under agentsonar_logs/
        run_dir = engine.logger.run_dir
        assert run_dir is not None
        run_files = sorted(os.listdir(run_dir))
        assert "report.json" in run_files, (
            f"report.json missing from run dir; found {run_files}"
        )
        assert "report.html" in run_files, (
            f"report.html missing from run dir; found {run_files}"
        )
        assert "timeline.jsonl" in run_files
        assert "alerts.log" in run_files

        # The report must actually contain the cycle events (not be empty)
        import json
        with open(os.path.join(run_dir, "report.json")) as f:
            data = json.load(f)
        cycle_events = [e for e in data if e["failure_class"] == "cyclic_delegation"]
        assert len(cycle_events) >= 1

    def test_file_output_false_disables_auto_export(self, tmp_path):
        """Regression: auto-export must default to off when file_output
        is explicitly disabled. Tests that pass file_output=False should
        NOT be surprised by a session directory appearing."""
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "log_dir": str(tmp_path),
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        for i in range(6):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))
        engine.shutdown()

        # No agentsonar_logs directory at all
        assert not os.path.exists(os.path.join(str(tmp_path), "agentsonar_logs"))
        assert engine.logger.run_dir is None

    def test_auto_export_on_shutdown_explicit_opt_in(self, tmp_path):
        """Regression: `auto_export_on_shutdown=True` with
        `file_output=False` is an unusual combination — reports need
        a directory to live in, and we don't create one when file
        output is disabled. Under the new session-dir layout, this
        combo produces NO reports (auto-export has nothing to write
        into) and no log files. The engine should not crash.

        If users want JSON/HTML without stderr/JSONL, they should
        call `export_json()`/`export_html()` explicitly — not rely
        on this combination."""
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "log_dir": str(tmp_path),
            "auto_export_on_shutdown": True,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        for i in range(6):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))
        engine.shutdown()

        # No session dir, so no reports — but no crash either.
        assert not os.path.exists(os.path.join(str(tmp_path), "agentsonar_logs"))

    def test_auto_export_on_shutdown_explicit_opt_out(self, tmp_path):
        """Regression: users can suppress auto-export even with
        file_output=True by setting auto_export_on_shutdown=False.
        Under the new layout, the run directory IS created (because
        file_output=True) and the log files are written inside it,
        but the JSON/HTML reports are NOT generated."""
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": str(tmp_path),
            "auto_export_on_shutdown": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
        })
        now = 1000.0
        for i in range(6):
            engine.ingest(_event("a", "b", now + i * 0.5))
            engine.ingest(_event("b", "a", now + i * 0.5 + 0.25))
        engine.shutdown()

        run_dir = engine.logger.run_dir
        assert run_dir is not None
        files = sorted(os.listdir(run_dir))
        # Log files yes, reports no
        assert "timeline.jsonl" in files
        assert "alerts.log" in files
        assert "report.json" not in files
        assert "report.html" not in files

    def test_auto_export_failure_does_not_crash_shutdown(self, tmp_path, monkeypatch):
        """Fault isolation: if the report exporters raise, shutdown must
        still complete cleanly — the logger must still close and the
        engine must still report _shutdown_requested=True."""
        engine = DetectionEngine({
            "log_dir": str(tmp_path),
            "console_output": False,
        })
        engine.ingest(_event("a", "b"))

        # Monkeypatch both exporters to raise
        def boom_json(*args, **kwargs):
            raise RuntimeError("simulated disk failure")

        def boom_html(*args, **kwargs):
            raise RuntimeError("simulated disk failure")

        import agentsonar._output.json_export as je
        import agentsonar._output.html_report as he
        monkeypatch.setattr(je, "export_json", boom_json)
        monkeypatch.setattr(he, "export_html", boom_html)

        # Must not raise
        engine.shutdown()
        assert engine._shutdown_requested
        assert engine.logger._closed

    def test_per_edge_rate_limits_directional(self):
        """Regression: per-edge rate limits for A→B and B→A must produce
        distinct fingerprints. Before the fix, both directions sorted to
        the same key and only one appeared in the deduped report."""
        engine = _engine({
            "per_edge_limit": 2,
            "global_limit": 10000,
            "window_size": 60.0,
            "hard_weight_limit": 1000.0,
        })
        now = 1000.0
        for i in range(5):
            engine.ingest(_event("a", "b", now + i * 0.1))
        for i in range(5):
            engine.ingest(_event("b", "a", now + 10 + i * 0.1))

        events = engine.get_recent_events()
        rate_events = [
            e for e in events
            if e.failure_class == FailureClass.RESOURCE_EXHAUSTION
        ]
        ab_fps = {
            e.coordination_fingerprint
            for e in rate_events
            if e.topology and e.topology.agents_involved == ("a", "b")
        }
        ba_fps = {
            e.coordination_fingerprint
            for e in rate_events
            if e.topology and e.topology.agents_involved == ("b", "a")
        }
        if ab_fps and ba_fps:
            assert ab_fps.isdisjoint(ba_fps), (
                "a→b and b→a per-edge rate limits shared a fingerprint — "
                "deduped summaries would hide one of them"
            )
