"""
Stress tests + edge-case coverage for the full SDK.

This file hunts the bugs that only appear under load, concurrent
access, weird inputs, or filesystem corner cases. It's the backstop
against the "it works on my machine" failure mode.

Scope
-----
  * Memory bounds under sustained ingest
  * Concurrent ingest + shutdown
  * Retention under concurrent logger creation
  * NaN / Infinity / None / edge-case numeric inputs
  * Unicode + long strings in agent names
  * Filesystem corruption (pre-existing `latest`/`.gitignore` as dirs)
  * XSS defense in HTML (every user-field escaped)
  * File descriptor leaks on partial failure
  * Rate limiter defensive validation

Some tests in this file EXPECT current implementation to pass even
under adversarial conditions. If one fails, we've found a real bug
that needs a fix in the production code, not a test relaxation.
"""
from __future__ import annotations

import json
import math
import os
import threading
import time

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import Alert, InteractionEvent
from agentsonar._core.detectors.rate_limiter import SlidingWindowLimiter
from agentsonar._core.schema import (
    AlertSeverity,
    CoordinationEvent,
    FailureClass,
    Topology,
)
from agentsonar._output.terminal import SonarLogger
from agentsonar._output.html_report import events_to_html
from agentsonar._output.json_export import events_to_json


# ---------------------------------------------------------------------
# Memory bounds — _recent_alerts / _recent_events must not grow
# unbounded even under sustained alert generation.
# ---------------------------------------------------------------------

class TestMemoryBounds:
    """The engine declares `_MAX_RECENT_ALERTS = 200` and
    `_MAX_RECENT_EVENTS = 200` as hard caps. These tests verify the
    caps are enforced on EVERY code path that appends, not just the
    full ingest path. Layer 1's early-return path and the shutdown
    recovery sweep were historically leaky."""

    def test_layer1_early_return_bounds_recent_alerts(self, tmp_path):
        """Regression: Layer 1 early-returns on rate-limit fire and
        extends `_recent_alerts` WITHOUT passing through the post-layer
        trim at line ~350. Under a pathological workload where EVERY
        ingest fires the rate limiter (tight window + low reset ratio
        so hysteresis re-arms constantly), every call rides the
        early-return path and the list grows unbounded.

        The fix: the early-return path must enforce the same cap as
        the non-early-return path.
        """
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "per_edge_limit": 1,
            "window_size": 0.001,  # 1ms — rolls over every event
            "hard_weight_limit": 100.0,
            "reset_ratio": 0.01,   # aggressive re-arm
        })
        engine._MAX_RECENT_ALERTS = 5
        now = time.time()
        # 2000 events in a pathological configuration — every one
        # rides the Layer 1 early-return path
        for i in range(2000):
            engine.ingest(InteractionEvent("a", "b", now + i * 0.002))

        assert len(engine._recent_alerts) <= engine._MAX_RECENT_ALERTS, (
            f"_recent_alerts grew past cap on Layer 1 early-return path: "
            f"len={len(engine._recent_alerts)}, cap={engine._MAX_RECENT_ALERTS}"
        )
        engine.shutdown()

    def test_shutdown_recoveries_respect_cap(self, tmp_path):
        """Regression: shutdown() extends `_recent_alerts` with final
        recovery alerts from `check_recoveries()` without applying the
        _MAX_RECENT_ALERTS cap. If a long-running session generated
        many alerts AND many recoveries, shutdown would push the list
        over the cap without trimming.
        """
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
            "resolve_after_seconds": 0.01,
        })
        engine._MAX_RECENT_ALERTS = 5

        # Generate many distinct alerts so check_recoveries has many
        # to emit. Each distinct edge pair gets its own AlertStateManager
        # entry that will resolve on shutdown.
        now = 1000.0
        for i in range(20):
            for _ in range(5):  # 5 events per pair to get past warning threshold
                engine.ingest(InteractionEvent(f"src{i}", f"tgt{i}", now + i * 0.1))

        # Wait out the quiet period so recoveries fire
        time.sleep(0.05)

        engine.shutdown()
        # After shutdown, _recent_alerts must still respect the cap
        assert len(engine._recent_alerts) <= engine._MAX_RECENT_ALERTS, (
            f"_recent_alerts past cap after shutdown: "
            f"len={len(engine._recent_alerts)}, cap={engine._MAX_RECENT_ALERTS}"
        )

    def test_recent_events_bounded_under_heavy_load(self, tmp_path):
        """10k distinct events must not grow `_recent_events` past
        its cap. The cap is re-checked on every append, so this is
        a regression guard against someone removing the trim."""
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 1.0,
            "per_edge_limit": 100_000,
            "scc_interval_events": 100_000,  # don't fire SCC
        })
        engine._MAX_RECENT_EVENTS = 50
        now = time.time()
        for i in range(500):
            engine.ingest(InteractionEvent(f"a{i}", f"b{i}", now + i * 0.001))

        assert len(engine._recent_events) <= engine._MAX_RECENT_EVENTS
        engine.shutdown()


# ---------------------------------------------------------------------
# Concurrency — multiple threads ingesting and shutting down
# ---------------------------------------------------------------------

class TestConcurrency:

    def test_concurrent_ingest_does_not_lose_events(self, tmp_path):
        """10 threads each ingesting 200 events = 2000 events total.
        The engine lock serializes access; after all threads join,
        `_event_count` must equal exactly 2000."""
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "hard_weight_limit": 100_000.0,
            "per_edge_limit": 100_000,
            "scc_interval_events": 100_000,
        })
        now = time.time()

        def worker(thread_id: int) -> None:
            for i in range(200):
                engine.ingest(InteractionEvent(
                    f"t{thread_id}_src",
                    f"t{thread_id}_tgt",
                    now + i * 0.001,
                ))

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        summary = engine.get_summary()
        assert summary["total_events"] == 2000
        engine.shutdown()

    def test_concurrent_shutdown_and_ingest(self, tmp_path):
        """Shutdown racing with active ingest. Must not deadlock and
        must not raise. Post-shutdown ingest calls may be dropped
        silently (because the lock/latch prevents writes) but must
        not crash."""
        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "hard_weight_limit": 100_000.0,
            "per_edge_limit": 100_000,
        })
        now = time.time()
        stop_event = threading.Event()

        def ingester():
            i = 0
            while not stop_event.is_set():
                try:
                    engine.ingest(InteractionEvent("a", "b", now + i * 0.001))
                except Exception:
                    # Fault isolation — ingest must never raise
                    raise AssertionError("ingest raised during shutdown race")
                i += 1
                if i > 10_000:
                    break

        thread = threading.Thread(target=ingester)
        thread.start()
        time.sleep(0.01)  # let ingest get going
        engine.shutdown()
        stop_event.set()
        thread.join(timeout=5.0)
        assert not thread.is_alive(), "ingester thread hung after shutdown"

    def test_concurrent_loggers_do_not_corrupt_latest(self, tmp_path):
        """5 SonarLoggers created back-to-back with explicit distinct
        session_ids. The `latest` file must always contain exactly
        one valid run dir basename after the dust settles."""
        session_ids = [
            "aaaaaaaa" * 2,
            "bbbbbbbb" * 2,
            "cccccccc" * 2,
            "dddddddd" * 2,
            "eeeeeeee" * 2,
        ]
        run_dirs: list[str] = []
        for sid in session_ids:
            logger = SonarLogger(
                output_dir=str(tmp_path),
                console_output=False,
                keep_runs=0,
                session_id=sid,
            )
            run_dirs.append(os.path.basename(logger.run_dir))
            logger.close()

        latest_path = os.path.join(str(tmp_path), "agentsonar_logs", "latest")
        assert os.path.isfile(latest_path)
        content = open(latest_path, encoding="utf-8").read().strip()
        # The latest pointer should name ONE of the runs we created
        # (typically the last one, but any is acceptable if the OS
        # reordered).
        assert content in run_dirs, (
            f"latest pointer {content!r} is not any of our runs: {run_dirs}"
        )


# ---------------------------------------------------------------------
# NaN / Infinity / exotic numeric inputs
# ---------------------------------------------------------------------

class TestExoticNumerics:
    """Detection layers and output modules should tolerate numeric
    edge cases without producing invalid JSON or crashing."""

    def test_json_export_rejects_nan(self):
        """JSON specification disallows NaN/Infinity. The events_to_json
        helper must produce strict-compliant JSON even when a detail
        dict somehow contains NaN — either by converting to null or
        by raising a clear error. It must NOT silently emit `NaN` as
        a bareword token (Python's default json.dumps behavior)."""
        topo = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={"a->b": 5},
        )
        event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-nan",
            session_id="sess-nan",
            timestamp=float("nan"),  # NaN as the timestamp
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:nan",
            topology=topo,
            summary="nan test",
        )

        result = events_to_json([event])
        # Strict JSON parsers reject NaN. Standard json.loads accepts
        # it by default, but a STRICT parser would reject. Check that
        # the output either:
        #   (a) omits NaN entirely (converted to null), OR
        #   (b) passes strict mode
        # The default behavior — bareword "NaN" in the output — is NOT
        # ok because it produces unparseable JSON for strict consumers.
        assert "NaN" not in result, (
            "JSON output contains bareword NaN — invalid JSON per RFC 8259"
        )
        assert "Infinity" not in result
        assert "-Infinity" not in result

    def test_json_export_rejects_infinity(self):
        topo = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={"a->b": 5},
        )
        event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-inf",
            session_id="sess-inf",
            timestamp=float("inf"),
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:inf",
            topology=topo,
            summary="inf test",
        )
        result = events_to_json([event])
        assert "Infinity" not in result

    def test_html_export_tolerates_nan_timestamp(self):
        """Same defense in HTML export — NaN must not crash or produce
        malformed output."""
        topo = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={"a->b": 5},
        )
        event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-nan",
            session_id="sess-nan",
            timestamp=float("nan"),
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:nan",
            topology=topo,
            summary="nan test",
        )
        # Must not raise
        result = events_to_html([event])
        assert result.startswith("<!DOCTYPE html>")

    def test_rate_limiter_rejects_negative_window_size(self):
        """Regression: negative window_size produced nonsense rate
        estimates because `elapsed / window_size` went negative.
        Must raise at construction time, not silently misbehave."""
        with pytest.raises(ValueError):
            SlidingWindowLimiter(window_size=-1.0)

    def test_rate_limiter_rejects_zero_window_size(self):
        """Zero window_size is a degenerate configuration — every
        check() would report infinite rate. Raise instead."""
        with pytest.raises(ValueError):
            SlidingWindowLimiter(window_size=0.0)

    def test_rate_limiter_rejects_negative_limits(self):
        """Negative per_edge_limit or global_limit is meaningless."""
        with pytest.raises(ValueError):
            SlidingWindowLimiter(per_edge_limit=-1)
        with pytest.raises(ValueError):
            SlidingWindowLimiter(global_limit=-1)


# ---------------------------------------------------------------------
# Filesystem corruption: pre-existing latest/.gitignore as directories
# ---------------------------------------------------------------------

class TestFilesystemCorruption:
    """Defensive tests against users (or adversaries, or buggy
    install scripts) creating directories with the same names the
    logger expects to write as files."""

    def test_latest_as_directory_is_handled(self, tmp_path):
        """If `agentsonar_logs/latest` already exists as a directory
        (somebody did `mkdir -p agentsonar_logs/latest/subdir`),
        SonarLogger must not crash. Writing the pointer will fail
        silently — that's acceptable degraded behavior — but the
        session directory creation and log writes must still succeed."""
        logs_root = os.path.join(str(tmp_path), "agentsonar_logs")
        os.makedirs(os.path.join(logs_root, "latest"))  # pre-existing dir

        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        # Core file logging must still work
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        # Session dir should exist and contain the log files
        assert logger.run_dir is not None
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))
        assert os.path.isfile(os.path.join(logger.run_dir, "alerts.log"))

    def test_gitignore_as_directory_is_handled(self, tmp_path):
        """Same test for `.gitignore`: if a user pre-created it as
        a directory, the logger must not crash."""
        logs_root = os.path.join(str(tmp_path), "agentsonar_logs")
        os.makedirs(os.path.join(logs_root, ".gitignore"))

        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )
        logger.log("INFO", "test", {"msg": "hello"})
        logger.close()

        assert logger.run_dir is not None
        assert os.path.isfile(os.path.join(logger.run_dir, "timeline.jsonl"))

    def test_partial_session_open_failure_closes_first_file(self, tmp_path, monkeypatch):
        """Regression: if the second open() in `_open_session_files`
        raises after the first succeeds, the first file's descriptor
        would leak. The fix explicitly closes the first file on the
        exception path.

        We monkey-patch `open` to succeed on the first call
        (timeline.jsonl) and raise on the second (alerts.log). The
        test then asserts that the first file's fd is closed rather
        than left dangling as an open attribute on the logger.
        """
        import builtins
        real_open = builtins.open
        opened_files: list = []
        call_count = [0]

        def fake_open(path, mode="r", *args, **kwargs):
            call_count[0] += 1
            if "agentsonar_logs" in str(path) and "alerts.log" in str(path):
                # Second open — raise to simulate a partial failure
                raise OSError("simulated disk failure")
            f = real_open(path, mode, *args, **kwargs)
            if "timeline.jsonl" in str(path):
                opened_files.append(f)
            return f

        monkeypatch.setattr(builtins, "open", fake_open)

        # Logger init should catch the raised OSError in its outer
        # except block and degrade to console-only mode (run_dir=None)
        logger = SonarLogger(
            output_dir=str(tmp_path),
            console_output=False,
            keep_runs=0,
            session_id="a" * 16,
        )

        # Every timeline.jsonl file that was opened must now be closed
        for f in opened_files:
            assert f.closed, (
                "timeline.jsonl file descriptor leaked after "
                "alerts.log open() raised"
            )

        # The logger should have fallen back to console-only mode
        assert logger.run_dir is None
        assert logger._file is None
        assert logger._alerts_file is None
        logger.close()


# ---------------------------------------------------------------------
# Unicode + extreme string inputs
# ---------------------------------------------------------------------

class TestUnicodeAndLongStrings:

    def test_unicode_agent_names_flow_through_engine(self, tmp_path):
        """Agent names with emoji, CJK, RTL text must not crash any
        layer of the pipeline."""
        engine = DetectionEngine({
            "log_dir": str(tmp_path),
            "console_output": False,
        })
        now = time.time()
        # Mix of Unicode: emoji, Chinese, Arabic (RTL), Russian
        engine.ingest(InteractionEvent("🤖-bot", "planner-агент", now))
        engine.ingest(InteractionEvent("planner-агент", "分析师", now + 0.1))
        engine.ingest(InteractionEvent("分析师", "مراجع", now + 0.2))

        summary = engine.get_summary()
        assert summary["total_events"] == 3
        engine.shutdown()

        # Run dir must still be created + files readable
        assert logger_still_has_outputs(engine.logger.run_dir)

    def test_unicode_seed_produces_valid_slug(self):
        """Slug generator with Unicode seed must still return a valid
        ASCII slug (SHA-256 of UTF-8 bytes, no funny business)."""
        from agentsonar._output._slug import generate_slug
        slug = generate_slug("你好世界🌍")
        assert slug.isascii()
        assert "-" in slug

    def test_very_long_agent_name(self, tmp_path):
        """Agent names of 1000 characters must not break anything."""
        engine = DetectionEngine({
            "log_dir": str(tmp_path),
            "console_output": False,
        })
        long_name = "a" * 1000
        now = time.time()
        engine.ingest(InteractionEvent(long_name, "b", now))
        engine.ingest(InteractionEvent("b", long_name, now + 0.1))

        summary = engine.get_summary()
        assert summary["total_events"] == 2
        engine.shutdown()


def logger_still_has_outputs(run_dir) -> bool:
    """Helper: assert all 4 files for a session still exist."""
    if run_dir is None:
        return False
    return all(
        os.path.isfile(os.path.join(run_dir, name))
        for name in ("timeline.jsonl", "alerts.log", "report.json", "report.html")
    )


# ---------------------------------------------------------------------
# XSS defense in HTML export
# ---------------------------------------------------------------------

class TestHtmlEscaping:
    """Every user-provided string rendered to HTML must be escaped.
    Regression test for every code path that renders event content."""

    @pytest.fixture
    def xss_event(self) -> CoordinationEvent:
        """An event whose every string field contains HTML metacharacters."""
        malicious = '<script>alert("xss")</script>'
        topo = Topology(
            agents_involved=(f"a{malicious}", f"b{malicious}"),
            interaction_pattern=f"circular{malicious}",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={f"a{malicious}->b{malicious}": 5},
        )
        return CoordinationEvent(
            schema_version="0.1.0",
            event_id=f"evt{malicious}",
            session_id=f"sess{malicious}",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            severity=AlertSeverity.CRITICAL,
            coordination_fingerprint=f"sha256{malicious}",
            topology=topo,
            summary=f"Summary{malicious}",
        )

    def test_no_unescaped_script_tag_in_rendered_html(self, xss_event):
        """The literal string `<script>` must NEVER appear in the
        rendered HTML. Every user field must pass through html.escape
        so `<` becomes `&lt;`."""
        html = events_to_html([xss_event])
        # The literal bytes `<script>` must not appear anywhere
        # except in the tooltip (which uses double quotes, so the
        # actual injection vector is `title="...` — same escaping
        # rules apply).
        assert "<script>alert" not in html, (
            "Unescaped <script> tag found in HTML output — XSS possible"
        )
        # But the ESCAPED form must appear (since the malicious
        # strings ARE in the event data, they should show up
        # visually as text)
        assert "&lt;script&gt;" in html

    def test_no_onerror_handler_in_rendered_html(self):
        """Another common XSS vector — an `<img src=x onerror=...>`
        attribute must not survive as rendered HTML."""
        topo = Topology(
            agents_involved=('<img src=x onerror="alert(1)">', "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={"a->b": 5},
        )
        event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-xss",
            session_id="sess-xss",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:xss",
            topology=topo,
            summary="img-onerror test",
        )
        html = events_to_html([event])
        # Literal `<img src=` must not appear as HTML
        assert "<img src=x" not in html
        # Escaped form must be present
        assert "&lt;img src=x" in html
