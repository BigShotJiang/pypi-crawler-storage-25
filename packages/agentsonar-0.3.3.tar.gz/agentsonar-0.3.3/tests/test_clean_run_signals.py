"""
Clean-run signal regression tests.

When a run completes without any WARNING / CRITICAL coordination
alerts, design partners should see an explicit positive confirmation
in every output channel:

  * HTML report  — a green "clean-run" banner with "No coordination
                   failures detected" text (replaces the old gray
                   "No coordination events detected." placeholder).
  * JSONL        — the final `session_end` record carries explicit
                   `clean_run: true`, `warning_count: 0`,
                   `critical_count: 0`, and a human-readable
                   `message` field.
  * stderr       — a single green confirmation line printed below
                   the summary banner (only on clean runs).

The contrapositive must also hold: when alerts DID fire, the
`clean_run` field must be false and the `message` must count the
severities.
"""
from __future__ import annotations

import json
import os
import tempfile

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent
from agentsonar._output.html_report import events_to_html


# ---------------------------------------------------------------------------
# HTML clean-run banner
# ---------------------------------------------------------------------------

# The <div class="clean-run"> wrapper is the RENDERED banner. The
# string "clean-run" also appears in <style> CSS selectors, so tests
# that want to know "is the banner actually shown?" must match the
# rendered `<div class="clean-run">` element — not the bare word.
_BANNER_DIV = '<div class="clean-run">'


def test_html_clean_run_banner_shows_on_empty_events():
    html = events_to_html([])
    assert _BANNER_DIV in html
    assert "No coordination failures detected" in html


def test_html_clean_run_banner_hides_when_alerts_present():
    """Regression: if there ARE WARNING/CRITICAL events, the banner
    must NOT show — we show the cards instead. Otherwise users
    would see the banner AND the cards, and the banner would be a
    lie."""
    engine = DetectionEngine({
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        ts = 1000.0
        for i in range(20):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        events = engine.get_recent_events()
        html = events_to_html(events)
        assert "No coordination failures detected" not in html
        assert _BANNER_DIV not in html
    finally:
        engine.shutdown()


# ---------------------------------------------------------------------------
# HTML comments stripped
# ---------------------------------------------------------------------------

def test_html_report_has_no_explanatory_comments():
    """The rendered HTML must not leak the internal `<!-- -->`
    explanation blocks that used to document theme-toggle,
    generated-at timestamp, raw JSON view, and localStorage logic.
    Design partners who "view source" the report should see clean
    markup, not AgentSonar's internal rationale.
    """
    html = events_to_html([])
    # `<!DOCTYPE html>` is fine — that's a declaration, not a comment.
    # What we're scanning for is opaque HTML explanation blocks.
    forbidden_phrases = [
        "Set the initial theme BEFORE the stylesheet",
        "Theme toggle — renders the icon",
        "Generated-at timestamp. Explicit UTC",
        "Raw JSON view. Same payload",
        "Theme tokens. Everything below",
    ]
    for phrase in forbidden_phrases:
        assert phrase not in html, (
            f"internal comment phrase leaked into rendered HTML: {phrase!r}"
        )


# ---------------------------------------------------------------------------
# JSONL clean-run marker on the final session_end record
# ---------------------------------------------------------------------------

def _read_session_end_record(run_dir: str) -> dict:
    """Helper: return the session_end record from timeline.jsonl."""
    with open(os.path.join(run_dir, "timeline.jsonl"), encoding="utf-8") as f:
        records = [json.loads(line) for line in f if line.strip()]
    for rec in records:
        if rec.get("event") == "session_end":
            return rec
    raise AssertionError("no session_end record found in timeline.jsonl")


def test_jsonl_clean_run_marker_true_on_clean_run():
    with tempfile.TemporaryDirectory() as td:
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": td,
            # High thresholds so the small burst below can't fire any alert
            "warning_threshold": 1000,
            "critical_threshold": 10000,
            "per_edge_limit": 99999,
            "global_limit": 99999,
        })
        # A small handful of events — no alerts
        ts = 1000.0
        engine.ingest(InteractionEvent("a", "b", ts))
        engine.ingest(InteractionEvent("b", "c", ts + 0.01))
        run_dir = engine.logger.run_dir
        engine.shutdown()

        rec = _read_session_end_record(run_dir)
        data = rec["data"]
        assert data["clean_run"] is True
        assert data["warning_count"] == 0
        assert data["critical_count"] == 0
        assert data["total_alerts"] == 0
        assert "No coordination failures detected" in data["message"]


def test_jsonl_clean_run_marker_false_when_alerts_fire():
    with tempfile.TemporaryDirectory() as td:
        engine = DetectionEngine({
            "file_output": True,
            "console_output": False,
            "log_dir": td,
            "warning_threshold": 3,
            "critical_threshold": 5,
            "per_edge_limit": 99999,
            "global_limit": 99999,
        })
        ts = 1000.0
        # Drive a cycle past the WARNING threshold
        for i in range(10):
            engine.ingest(InteractionEvent("a", "b", ts + i * 0.01))
            engine.ingest(InteractionEvent("b", "a", ts + i * 0.01 + 0.005))
        run_dir = engine.logger.run_dir
        engine.shutdown()

        rec = _read_session_end_record(run_dir)
        data = rec["data"]
        assert data["clean_run"] is False
        assert data["warning_count"] + data["critical_count"] >= 1
        assert "No coordination failures detected" not in data["message"]
        # Message should mention severity breakdown
        assert "WARNING" in data["message"] or "CRITICAL" in data["message"]
