"""
Mid-execution host-safety regression tests.

These tests deliberately BREAK AgentSonar internals AFTER a
successful construction and prove that the host application keeps
running. Construction-time safety is covered in `test_host_safety.py`;
this file is about the harder case — what happens when something
inside the SDK blows up during the actual graph/crew execution.

Every test in this module:
  1. Constructs a working AgentSonar integration.
  2. Monkey-patches a specific internal method to always raise.
  3. Drives a host workload through the integration.
  4. Asserts the host workload completed successfully regardless.

If any of these fail, AgentSonar shipped a regression that can
crash user applications mid-run.

Scenarios covered:

  1. engine.ingest raises → on_chain_start / on_tool_start
     swallow it and continue.
  2. SonarLogger.log raises on every event → engine.ingest still
     returns cleanly.
  3. The detection pipeline (`_ingest_locked`) raises →
     outer ingest catch-all drops the event.
  4. Auto-export (JSON/HTML) raises → shutdown completes cleanly.
  5. check_recoveries raises → shutdown completes cleanly.
  6. log_session_end raises → shutdown still closes the logger.
  7. The `_MonitoredGraph._merge_config` path is bypassed when
     merge fails — the user's original config flows through.
  8. Real end-to-end: a LangGraph graph wrapped in `monitor()`
     where the engine is forcibly broken mid-run still completes.

And the kill-switch scenario:
  9. AGENTSONAR_DISABLED=1 → integrations return a _NoOpEngine
     with no construction side-effects.
"""
from __future__ import annotations

import os
from typing import Any, Literal

import pytest
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from typing_extensions import Annotated, TypedDict
import operator

from agentsonar import AgentSonarCallback, monitor
from agentsonar._core.models import InteractionEvent
from agentsonar._core.noop_engine import _NoOpEngine
from agentsonar._integrations._safe_engine import build_engine_safely


# ---------------------------------------------------------------------------
# Reusable workloads
# ---------------------------------------------------------------------------

class _State(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    iteration: int


def _build_cycle_graph():
    """3-node cycle graph that completes in a bounded number of loops.

    Exactly the kind of workload AgentSonar is designed to monitor,
    but compiled WITHOUT `monitor()` so tests can wrap it explicitly.
    """
    def planner(s: _State):
        return {"messages": [AIMessage(content="plan")]}

    def researcher(s: _State):
        return {"messages": [AIMessage(content="research")]}

    def reviewer(s: _State):
        return {
            "messages": [AIMessage(content="revise")],
            "iteration": s.get("iteration", 0) + 1,
        }

    def loop(s: _State) -> Literal["planner", "__end__"]:
        return END if s.get("iteration", 0) >= 3 else "planner"

    b = StateGraph(_State)
    b.add_node("planner", planner)
    b.add_node("researcher", researcher)
    b.add_node("reviewer", reviewer)
    b.add_edge(START, "planner")
    b.add_edge("planner", "researcher")
    b.add_edge("researcher", "reviewer")
    b.add_conditional_edges("reviewer", loop)
    return b.compile()


def _run(wrapped) -> Any:
    """Drive the cycle graph to completion."""
    return wrapped.invoke(
        {"messages": [HumanMessage(content="go")], "iteration": 0},
        config={"recursion_limit": 50},
    )


# ---------------------------------------------------------------------------
# 1. engine.ingest raises → host graph still runs
# ---------------------------------------------------------------------------

def test_ingest_raising_does_not_crash_host_graph():
    """Monkeypatch `engine.ingest` to always raise. The host graph
    must still invoke to completion."""
    graph = _build_cycle_graph()
    wrapped = monitor(graph)

    def _boom(*args, **kwargs):
        raise RuntimeError("simulated detection pipeline failure")

    wrapped.sonar.engine.ingest = _boom  # type: ignore[assignment]

    # Host graph should run to completion. LangChain catches callback
    # errors at the manager level (they land in its own logger), so
    # even a raise inside on_chain_start doesn't escape — but the
    # more important test is the AgentSonar-level one: we want
    # `on_chain_start` itself to NOT propagate the error even in
    # the edge case where LangChain's callback manager would.
    result = _run(wrapped)
    assert result["iteration"] == 3
    wrapped.shutdown()


def test_ingest_raising_on_chain_start_swallows_internally():
    """The callback's own try/except must catch the injected raise
    from engine.ingest, not rely on LangChain's callback manager."""
    graph = _build_cycle_graph()
    wrapped = monitor(graph)

    def _boom(*args, **kwargs):
        raise RuntimeError("simulated boom")

    wrapped.sonar.engine.ingest = _boom  # type: ignore[assignment]

    # Direct call — bypass LangChain's callback manager entirely.
    # If our on_chain_start does not catch, this raises.
    wrapped.sonar.on_chain_start(
        serialized={}, inputs={},
        metadata={"langgraph_node": "a"},
        run_id="r1",
    )
    wrapped.sonar.on_chain_start(
        serialized={}, inputs={},
        metadata={"langgraph_node": "b"},
        run_id="r1", parent_run_id="r1",
    )
    wrapped.shutdown()


# ---------------------------------------------------------------------------
# 2. SonarLogger.log raises → engine.ingest still completes
# ---------------------------------------------------------------------------

def test_logger_raising_does_not_break_ingest():
    """Inject a broken logger into the engine and prove ingest returns
    cleanly. Mirrors "disk fills up mid-run"."""
    sonar = AgentSonarCallback()
    try:
        original_log = sonar.engine.logger.log

        def _boom(*args, **kwargs):
            raise IOError("disk full")

        sonar.engine.logger.log = _boom  # type: ignore[assignment]

        # Drive some events through — none of these should raise
        for i in range(20):
            result = sonar.engine.ingest(
                InteractionEvent("a", "b", 1000.0 + i * 0.01)
            )
            assert isinstance(result, list)

        sonar.engine.logger.log = original_log  # type: ignore[assignment]
    finally:
        sonar.shutdown()


def test_logger_every_method_raising_does_not_break_ingest():
    """Replace EVERY log_* method on the logger with a raiser and
    confirm ingest still drops events cleanly."""
    sonar = AgentSonarCallback()
    try:
        def _boom(*args, **kwargs):
            raise RuntimeError("logger exploded")

        for method in [
            "log", "log_delegation", "log_graph_update", "log_alert",
            "log_alert_resolved", "log_cycle_detected",
            "log_anomaly_detected", "log_rate_limit_hit",
            "log_scc_sweep",
        ]:
            setattr(sonar.engine.logger, method, _boom)

        for i in range(30):
            sonar.engine.ingest(
                InteractionEvent(f"a{i % 3}", f"b{i % 3}", 1000.0 + i * 0.01)
            )
    finally:
        # shutdown itself must survive the broken logger
        sonar.shutdown()


# ---------------------------------------------------------------------------
# 3. _ingest_locked raises (the pipeline layer below ingest)
# ---------------------------------------------------------------------------

def test_ingest_locked_raising_is_caught_by_outer_guard():
    """Override `_ingest_locked` to always raise. The outer `ingest()`
    must catch it and return an empty list."""
    sonar = AgentSonarCallback()
    try:
        def _boom(*args, **kwargs):
            raise RuntimeError("pipeline exploded")

        sonar.engine._ingest_locked = _boom  # type: ignore[assignment]

        for i in range(10):
            result = sonar.engine.ingest(
                InteractionEvent("a", "b", 1000.0 + i)
            )
            assert result == []
    finally:
        sonar.shutdown()


# ---------------------------------------------------------------------------
# 4. Auto-export raises → shutdown() still completes
# ---------------------------------------------------------------------------

def test_auto_export_raising_does_not_break_shutdown(tmp_path):
    """Inject a broken `_auto_export_reports`. shutdown() must
    complete cleanly — file handles still released."""
    sonar = AgentSonarCallback(config={"log_dir": str(tmp_path)})
    try:
        def _boom(*args, **kwargs):
            raise RuntimeError("export exploded")

        sonar.engine._auto_export_reports = _boom  # type: ignore[assignment]

        # Drive some events so there's actually something to export
        for i in range(5):
            sonar.engine.ingest(InteractionEvent("a", "b", 1000.0 + i))
    finally:
        # shutdown() must not raise even though export is broken
        sonar.shutdown()
        # Idempotent
        sonar.shutdown()


# ---------------------------------------------------------------------------
# 5. check_recoveries raises → shutdown() still completes
# ---------------------------------------------------------------------------

def test_check_recoveries_raising_does_not_break_shutdown():
    sonar = AgentSonarCallback()
    try:
        def _boom(*args, **kwargs):
            raise RuntimeError("recovery sweep exploded")

        sonar.engine._alert_mgr.check_recoveries = _boom  # type: ignore[assignment]
    finally:
        sonar.shutdown()
        sonar.shutdown()


# ---------------------------------------------------------------------------
# 6. log_session_end raises → shutdown() still closes the logger
# ---------------------------------------------------------------------------

def test_log_session_end_raising_still_closes_logger(tmp_path):
    sonar = AgentSonarCallback(config={"log_dir": str(tmp_path)})
    try:
        def _boom(*args, **kwargs):
            raise RuntimeError("session_end exploded")

        sonar.engine.logger.log_session_end = _boom  # type: ignore[assignment]
    finally:
        sonar.shutdown()
        # Logger should be closed even though session_end raised.
        # The close() fallback in shutdown() handles this.
        assert sonar.engine.logger._closed is True


# ---------------------------------------------------------------------------
# 7. merge_config bypassed when merge fails
# ---------------------------------------------------------------------------

def test_merge_config_failing_passes_user_config_through():
    """Force `_merge_config` to raise and confirm user config
    flows through the wrapper untouched."""
    graph = _build_cycle_graph()
    wrapped = monitor(graph)

    def _boom(config):
        raise RuntimeError("merge exploded")

    wrapped._merge_config = _boom  # type: ignore[assignment]

    # Host graph MUST still run — but without AgentSonar callback
    # attached because merge failed. Wait, actually — if _merge_config
    # itself is replaced with a raiser, the outer code in invoke()
    # calls _merge_config(config) which raises. That's a bug in the
    # test — monitor's invoke() is supposed to call _merge_config
    # safely. Let me verify the contract here:
    #
    # _merge_config INTERNALLY wraps in try/except. If we override
    # the entire method with a raiser, we're testing a different
    # scenario: "what if the merge helper is fundamentally broken?"
    #
    # The right behavior: `_MonitoredGraph.invoke` should also
    # catch a mid-merge raise and pass the original config through.
    # Let's assert that.
    try:
        result = _run(wrapped)
        assert result["iteration"] == 3
    finally:
        wrapped.shutdown()


# ---------------------------------------------------------------------------
# 8. Full end-to-end: engine forcibly broken mid-run
# ---------------------------------------------------------------------------

def test_end_to_end_broken_engine_mid_run():
    """The canonical test: a real graph, AgentSonar wired in via
    monitor(), engine ingest replaced with a raiser BEFORE the
    graph runs. Host graph must still complete."""
    graph = _build_cycle_graph()
    wrapped = monitor(graph)

    call_count = [0]
    original_ingest = wrapped.sonar.engine.ingest

    def _maybe_boom(event):
        call_count[0] += 1
        if call_count[0] > 2:
            raise RuntimeError("simulated mid-run engine failure")
        return original_ingest(event)

    wrapped.sonar.engine.ingest = _maybe_boom  # type: ignore[assignment]

    result = _run(wrapped)
    assert result["iteration"] == 3, (
        "host graph must complete even after engine.ingest started raising"
    )
    # And shutdown must clean up without complaining
    wrapped.shutdown()


# ---------------------------------------------------------------------------
# 9. AGENTSONAR_DISABLED kill switch
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("value", ["1", "true", "yes", "on", "ENABLED", "True"])
def test_disabled_env_var_short_circuits_to_noop(monkeypatch, value):
    monkeypatch.setenv("AGENTSONAR_DISABLED", value)
    engine = build_engine_safely({"per_edge_limit": 99999})
    assert isinstance(engine, _NoOpEngine)
    # Construction side-effects MUST NOT have happened — no log files,
    # no session directory, no banners.
    assert engine.logger.run_dir is None


def test_disabled_env_var_respected_by_callback(monkeypatch):
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
    sonar = AgentSonarCallback()
    assert isinstance(sonar.engine, _NoOpEngine)
    sonar.on_chain_start(
        serialized={}, inputs={},
        metadata={"langgraph_node": "a"}, run_id="r1",
    )
    sonar.shutdown()


def test_disabled_env_var_respected_by_monitor(monkeypatch):
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
    graph = _build_cycle_graph()
    wrapped = monitor(graph)
    assert isinstance(wrapped.sonar.engine, _NoOpEngine)
    result = _run(wrapped)
    assert result["iteration"] == 3
    wrapped.shutdown()


@pytest.mark.parametrize("value", ["0", "false", "no", "off", "", "maybe"])
def test_disabled_env_var_non_truthy_keeps_sdk_enabled(monkeypatch, value):
    monkeypatch.setenv("AGENTSONAR_DISABLED", value)
    engine = build_engine_safely({})
    # Real engine, not noop
    assert not isinstance(engine, _NoOpEngine)
    engine.shutdown()


def test_no_disabled_env_var_keeps_sdk_enabled(monkeypatch):
    monkeypatch.delenv("AGENTSONAR_DISABLED", raising=False)
    engine = build_engine_safely({})
    assert not isinstance(engine, _NoOpEngine)
    engine.shutdown()


# ---------------------------------------------------------------------------
# 10. Total obliteration — every engine and logger method replaced
#     with a raiser, and the host graph still runs.
# ---------------------------------------------------------------------------

def test_every_engine_and_logger_method_raising_host_still_runs():
    """The most extreme test: monkeypatch EVERY public method on
    both the engine and the logger to raise. The host graph must
    still complete, and shutdown() must not raise.

    This simulates a catastrophic SDK failure during execution —
    perhaps from a corrupt import, a broken patch, or a subtle
    future bug that manifests as every ingest path raising.
    Host safety is the absolute-last-line-of-defense guarantee
    and this test pins it.
    """
    graph = _build_cycle_graph()
    wrapped = monitor(graph)

    def _boom(*args, **kwargs):
        raise RuntimeError("obliterated")

    # Break every engine method the integration layer touches
    for method in [
        "ingest",
        "get_summary",
        "get_recent_events",
        "shutdown",
        "increment_iteration",
    ]:
        setattr(wrapped.sonar.engine, method, _boom)

    # Break every logger method the engine + integrations touch
    for method in [
        "log",
        "log_delegation",
        "log_graph_update",
        "log_alert",
        "log_alert_resolved",
        "log_cycle_detected",
        "log_anomaly_detected",
        "log_rate_limit_hit",
        "log_scc_sweep",
        "log_session_start",
        "log_session_end",
        "close",
    ]:
        setattr(wrapped.sonar.engine.logger, method, _boom)

    # Host graph MUST complete
    result = _run(wrapped)
    assert result["iteration"] == 3

    # shutdown() must not raise even with everything broken
    wrapped.shutdown()


# ---------------------------------------------------------------------------
# 11. Graceful degradation when networkx is missing / broken at import
# ---------------------------------------------------------------------------

def test_build_engine_safely_degrades_when_networkx_import_fails(monkeypatch):
    """Simulate a broken `networkx` install by patching the engine
    module's NetworkX import path to fail. `build_engine_safely`
    must catch the ImportError and return a `_NoOpEngine`.
    """
    # Make the lazy import of DetectionEngine fail by injecting a
    # broken module into sys.modules for agentsonar._core.engine.
    # This mimics what happens if a future version of networkx
    # removes a function we depend on, or if the install is
    # partially corrupted.
    import sys

    real_engine_module = sys.modules.get("agentsonar._core.engine")
    try:
        class _BrokenModule:
            def __getattr__(self, name):
                raise ImportError("simulated networkx failure")

        sys.modules["agentsonar._core.engine"] = _BrokenModule()  # type: ignore[assignment]

        engine = build_engine_safely({})
        assert isinstance(engine, _NoOpEngine)
        # And the engine is fully usable in degraded mode
        assert engine.ingest(None) == []
        engine.shutdown()
    finally:
        # Restore the real module so other tests aren't affected
        if real_engine_module is not None:
            sys.modules["agentsonar._core.engine"] = real_engine_module
        else:
            sys.modules.pop("agentsonar._core.engine", None)
