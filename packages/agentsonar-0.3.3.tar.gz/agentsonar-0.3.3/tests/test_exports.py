"""
Tests for the JSON and HTML export functions, focusing on the dedupe behavior.
"""
from __future__ import annotations

import json
import os

import pytest

from agentsonar._core.schema import (
    AlertSeverity,
    CoordinationEvent,
    FailureClass,
)
from agentsonar._output.html_report import events_to_html, export_html
from agentsonar._output.json_export import events_to_json, export_json


def _event(fingerprint: str, severity: str, timestamp: float) -> CoordinationEvent:
    return CoordinationEvent(
        schema_version="0.1.0",
        event_id=f"e-{fingerprint}-{severity}-{timestamp}",
        session_id="sess-1",
        timestamp=timestamp,
        event_type="coordination_failure",
        failure_class=FailureClass.CYCLIC_DELEGATION,
        severity=AlertSeverity.from_string(severity),
        coordination_fingerprint=fingerprint,
        summary=f"{severity} at {timestamp}",
    )


@pytest.fixture
def events_with_escalation():
    """Cycle WARNING->CRITICAL + one unrelated warning. 3 events total, 2 unique."""
    return [
        _event("sha256:cycle1", "WARNING", 1000.0),
        _event("sha256:other", "WARNING", 1001.0),
        _event("sha256:cycle1", "CRITICAL", 1002.0),
    ]


# -----------------------------------------------------------------------
# export_json
# -----------------------------------------------------------------------

class TestExportJsonDedupe:

    def test_dedupe_on_by_default(self, tmp_path, events_with_escalation):
        path = export_json(events_with_escalation, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        # 3 events in → 2 unique fingerprints out
        assert len(data) == 2
        severities = {e["severity"] for e in data}
        assert severities == {"CRITICAL", "WARNING"}

    def test_dedupe_off_preserves_all(self, tmp_path, events_with_escalation):
        path = export_json(
            events_with_escalation,
            output_dir=str(tmp_path),
            dedupe=False,
        )
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        # All 3 state transitions preserved
        assert len(data) == 3

    def test_events_to_json_dedupes(self, events_with_escalation):
        """String-returning variant also dedupes by default."""
        s = events_to_json(events_with_escalation)
        data = json.loads(s)
        assert len(data) == 2

    def test_events_to_json_dedupe_off(self, events_with_escalation):
        s = events_to_json(events_with_escalation, dedupe=False)
        data = json.loads(s)
        assert len(data) == 3


# -----------------------------------------------------------------------
# export_html
# -----------------------------------------------------------------------

class TestExportHtmlDedupe:

    def test_dedupe_on_by_default(self, tmp_path, events_with_escalation):
        path = export_html(events_with_escalation, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            html_content = f.read()
        assert html_content.count('class="event critical"') == 1
        assert html_content.count('class="event warning"') == 1
        assert ">2</strong>Total Events" in html_content
        assert ">1</strong>Critical" in html_content
        assert ">1</strong>Warning" in html_content

    def test_dedupe_off_preserves_all(self, tmp_path, events_with_escalation):
        path = export_html(
            events_with_escalation,
            output_dir=str(tmp_path),
            dedupe=False,
        )
        with open(path, encoding="utf-8") as f:
            html_content = f.read()
        assert html_content.count('class="event critical"') == 1
        assert html_content.count('class="event warning"') == 2
        assert ">3</strong>Total Events" in html_content
        assert ">2</strong>Warning" in html_content

    def test_events_to_html_dedupes(self, events_with_escalation):
        html_content = events_to_html(events_with_escalation)
        assert html_content.count('class="event critical"') == 1
        assert html_content.count('class="event warning"') == 1

    def test_dedupe_true_sorts_by_severity(self, tmp_path):
        """Summary view: CRITICAL-first for quick scanning."""
        import re
        events = [
            _event("sha256:a", "WARNING", 1000.0),
            _event("sha256:b", "CRITICAL", 2000.0),
            _event("sha256:c", "WARNING", 3000.0),
            _event("sha256:d", "CRITICAL", 4000.0),
        ]
        path = export_html(events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            html_content = f.read()
        badges = re.findall(r'class="badge (critical|warning)"', html_content)
        assert badges == ["critical", "critical", "warning", "warning"]

    def test_dedupe_false_preserves_chronological_order(self, tmp_path):
        """Timeline view: preserve input order so the user can trace what
        happened when. Regression test — the HTML renderer used to sort
        by severity even with dedupe=False, breaking the timeline view."""
        import re
        events = [
            _event("sha256:a", "WARNING", 1000.0),
            _event("sha256:b", "CRITICAL", 2000.0),
            _event("sha256:c", "WARNING", 3000.0),
            _event("sha256:d", "CRITICAL", 4000.0),
        ]
        path = export_html(events, output_dir=str(tmp_path), dedupe=False)
        with open(path, encoding="utf-8") as f:
            html_content = f.read()
        badges = re.findall(r'class="badge (critical|warning)"', html_content)
        assert badges == ["warning", "critical", "warning", "critical"]

    def test_events_to_html_dedupe_false_preserves_order(self):
        """Same as above but for the string-returning variant."""
        import re
        events = [
            _event("sha256:a", "WARNING", 1000.0),
            _event("sha256:b", "CRITICAL", 2000.0),
            _event("sha256:c", "WARNING", 3000.0),
        ]
        html_content = events_to_html(events, dedupe=False)
        badges = re.findall(r'class="badge (critical|warning)"', html_content)
        assert badges == ["warning", "critical", "warning"]


# -----------------------------------------------------------------------
# Real-world regression: engine-produced escalation
# -----------------------------------------------------------------------

class TestEngineEscalationDedupe:
    """When the engine produces WARNING then CRITICAL for the same cycle,
    the deduped report should show ONE event (the CRITICAL one)."""

    def test_cycle_escalation_collapses(self, tmp_path):
        from agentsonar._core.engine import DetectionEngine
        from agentsonar._core.models import InteractionEvent

        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "hard_weight_limit": 100.0,
            "per_edge_limit": 1000,
        })
        now = 1000.0
        for i in range(10):
            engine.ingest(InteractionEvent("a", "b", now + i * 0.5))
            engine.ingest(InteractionEvent("b", "a", now + i * 0.5 + 0.25))

        all_events = engine.get_recent_events()
        cycle_events = [
            e for e in all_events
            if e.failure_class == FailureClass.CYCLIC_DELEGATION
        ]
        assert len(cycle_events) >= 2  # at least one WARNING + one CRITICAL

        path = export_json(all_events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        cycle_in_report = [
            e for e in data
            if e["failure_class"] == "cyclic_delegation"
        ]
        assert len(cycle_in_report) == 1
        assert cycle_in_report[0]["severity"] == "CRITICAL"

    def test_global_rate_limit_events_dedupe_to_one(self, tmp_path):
        """Regression: global_rate_exceeded is a system-wide problem
        and the deduped report must show exactly ONE event for it.

        Two sources of "multiple raw events" this test previously
        relied on:
          1. Fingerprint collision across triggering edges (fixed
             earlier by making global-rate use agents=[] constant).
          2. Machine-gun re-firing on every event over the threshold
             (fixed now by SlidingWindowLimiter hysteresis).

        With hysteresis, the first breach fires once and subsequent
        events in the same window are suppressed — which is the
        correct circuit-breaker behavior. To still verify fingerprint
        sharing, we force a window rollover between two breaches by
        jumping past `window_size` on the second burst.
        """
        from agentsonar._core.engine import DetectionEngine
        from agentsonar._core.models import InteractionEvent

        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "per_edge_limit": 1000,
            "global_limit": 5,
            "window_size": 10.0,  # short so we can roll over
            "hard_weight_limit": 1000.0,
        })
        now = 1000.0
        # First burst: 9 events over distinct edges — trips global limit once.
        first_burst_edges = [
            ("a1", "b1"), ("a2", "b2"), ("a3", "b3"),
            ("a4", "b4"), ("a5", "b5"), ("a6", "b6"),
            ("a7", "b7"), ("a8", "b8"), ("a9", "b9"),
        ]
        for i, (s, t) in enumerate(first_burst_edges):
            engine.ingest(InteractionEvent(s, t, now + i * 0.1))

        # Jump past the window so hysteresis clears and the next
        # burst can fire again — this produces a second raw event
        # in _recent_events so we can verify fingerprint sharing.
        second_burst_start = now + 30.0
        second_burst_edges = [
            ("c1", "d1"), ("c2", "d2"), ("c3", "d3"),
            ("c4", "d4"), ("c5", "d5"), ("c6", "d6"),
            ("c7", "d7"), ("c8", "d8"), ("c9", "d9"),
        ]
        for i, (s, t) in enumerate(second_burst_edges):
            engine.ingest(InteractionEvent(s, t, second_burst_start + i * 0.1))

        events = engine.get_recent_events()
        raw_rate = [e for e in events if e.failure_class == FailureClass.RESOURCE_EXHAUSTION]
        # Expect exactly 2 raw events — one per burst, thanks to hysteresis
        assert len(raw_rate) == 2, (
            f"expected exactly 2 raw events (one per burst), got {len(raw_rate)}"
        )
        # Both must share the same fingerprint (global-rate constant)
        fingerprints = {e.coordination_fingerprint for e in raw_rate}
        assert len(fingerprints) == 1, (
            f"expected 1 shared fingerprint for global rate, got {len(fingerprints)}"
        )

        # And in the deduped summary, the 2 raw events collapse to 1
        path = export_json(events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        rate_in_report = [e for e in data if e["failure_class"] == "resource_exhaustion"]
        assert len(rate_in_report) == 1
        assert rate_in_report[0]["provider_error"]["error_type"] == "global_rate_exceeded"

    def test_per_edge_rate_limits_dedupe_per_edge(self, tmp_path):
        """Each per-edge rate limit firing is its own problem. Two different
        edges hitting the limit must produce TWO distinct events in the
        report, not one."""
        from agentsonar._core.engine import DetectionEngine
        from agentsonar._core.models import InteractionEvent

        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "per_edge_limit": 2,
            "global_limit": 10000,
            "window_size": 60.0,
            "hard_weight_limit": 1000.0,
        })
        now = 1000.0
        for i in range(5):
            engine.ingest(InteractionEvent("a", "b", now + i * 0.1))
        for i in range(5):
            engine.ingest(InteractionEvent("c", "d", now + 10 + i * 0.1))

        events = engine.get_recent_events()
        raw_rate = [e for e in events if e.failure_class == FailureClass.RESOURCE_EXHAUSTION]
        # Exactly 2 under hysteresis — each edge fires once, then the
        # tripped latch suppresses further fires on the same window.
        assert len(raw_rate) == 2
        fingerprints = {e.coordination_fingerprint for e in raw_rate}
        assert len(fingerprints) == 2

        path = export_json(events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        rate_in_report = [e for e in data if e["failure_class"] == "resource_exhaustion"]
        assert len(rate_in_report) == 2
        for e in rate_in_report:
            assert e["provider_error"]["error_type"] == "rate_limit_exceeded"

    def test_repetitive_symptoms_inhibited_under_cycle(self, tmp_path):
        """End-to-end: a 3-node cycle + hot-edge anomalies on each edge
        must collapse to a single CYCLIC_DELEGATION event in the report.
        The 3 REPETITIVE_DELEGATION symptoms are inhibited under the
        cycle root cause."""
        from agentsonar._core.engine import DetectionEngine
        from agentsonar._core.models import InteractionEvent

        engine = DetectionEngine({
            "file_output": False,
            "console_output": False,
            "warning_threshold": 5,
            "critical_threshold": 15,
            "hard_weight_limit": 5.0,
            "per_edge_limit": 1000,
        })
        now = 1000.0
        for i in range(20):
            engine.ingest(InteractionEvent("planner", "researcher", now + i * 0.1))
            engine.ingest(InteractionEvent("researcher", "reviewer", now + i * 0.1 + 0.03))
            engine.ingest(InteractionEvent("reviewer", "planner", now + i * 0.1 + 0.06))

        all_events = engine.get_recent_events()
        raw_cycles = [e for e in all_events if e.failure_class == FailureClass.CYCLIC_DELEGATION]
        raw_reps = [e for e in all_events if e.failure_class == FailureClass.REPETITIVE_DELEGATION]
        assert len(raw_cycles) >= 1
        assert len(raw_reps) >= 1

        path = export_json(all_events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        cycle_in_report = [e for e in data if e["failure_class"] == "cyclic_delegation"]
        rep_in_report = [e for e in data if e["failure_class"] == "repetitive_delegation"]

        assert len(cycle_in_report) == 1
        assert len(rep_in_report) == 0

        path_raw = export_json(
            all_events, path=str(tmp_path / "raw.json"), dedupe=False,
        )
        with open(path_raw, encoding="utf-8") as f:
            data_raw = json.load(f)
        raw_reps_in_file = [e for e in data_raw if e["failure_class"] == "repetitive_delegation"]
        assert len(raw_reps_in_file) >= 1


# -----------------------------------------------------------------------
# Empty events handling
# -----------------------------------------------------------------------

class TestEmptyEvents:
    """Edge case: exporting with zero events must not crash."""

    def test_export_json_empty(self, tmp_path):
        path = export_json([], output_dir=str(tmp_path))
        assert os.path.exists(path)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        assert data == []

    def test_events_to_json_empty(self):
        assert json.loads(events_to_json([])) == []

    def test_export_html_empty(self, tmp_path):
        path = export_html([], output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            html_content = f.read()
        # Clean-run banner instead of the old gray "No events" placeholder
        assert "No coordination failures detected" in html_content
        assert "clean-run" in html_content
        # The empty-run HTML skips the count-chips summary entirely —
        # users don't need a "0 Critical / 0 Warning" chip row on a
        # clean run. The green banner IS the summary. The CSS class
        # name still appears in <style>; the chip ROW is what we're
        # checking for, which is gated by `data-severity="..."`.
        assert 'data-severity="all"' not in html_content
        assert html_content.startswith("<!DOCTYPE html>")
        assert "</html>" in html_content

    def test_events_to_html_empty(self):
        html_content = events_to_html([])
        assert "No coordination failures detected" in html_content
        assert "clean-run" in html_content


# -----------------------------------------------------------------------
# Explicit path handling
# -----------------------------------------------------------------------

class TestExplicitPath:
    """Regression: explicit `path=` must create parent directories so the
    user doesn't hit FileNotFoundError when the folder doesn't exist yet."""

    def test_json_explicit_path_used_verbatim(self, tmp_path):
        custom = tmp_path / "my_custom.json"
        result = export_json([], path=str(custom))
        assert result == str(custom)
        assert custom.exists()

    def test_html_explicit_path_used_verbatim(self, tmp_path):
        custom = tmp_path / "my_custom.html"
        result = export_html([], path=str(custom))
        assert result == str(custom)
        assert custom.exists()

    def test_json_explicit_path_creates_parent_dir(self, tmp_path):
        """Parent dir doesn't exist — export_json must create it."""
        nested = tmp_path / "reports" / "daily" / "report.json"
        assert not nested.parent.exists()
        result = export_json([], path=str(nested))
        assert nested.exists()
        assert result == str(nested)

    def test_html_explicit_path_creates_parent_dir(self, tmp_path):
        nested = tmp_path / "reports" / "daily" / "report.html"
        assert not nested.parent.exists()
        result = export_html([], path=str(nested))
        assert nested.exists()
        assert result == str(nested)

    def test_json_explicit_path_in_cwd(self, tmp_path, monkeypatch):
        """Bare filename (no dir component) writes to cwd, no crash from os.makedirs('')."""
        monkeypatch.chdir(tmp_path)
        result = export_json([], path="bare.json")
        assert (tmp_path / "bare.json").exists()


# -----------------------------------------------------------------------
# Dedupe interaction with INFO filter
# -----------------------------------------------------------------------

class TestDedupeInfoInteraction:
    """When a fingerprint has both WARNING and INFO events, dedupe keeps
    WARNING (higher severity). When only INFO events exist, they survive
    dedupe but are then filtered out by the HTML renderer."""

    def test_warning_wins_over_info_same_fingerprint(self, tmp_path):
        events = [
            _event("sha256:x", "WARNING", 1000.0),
            _event("sha256:x", "INFO", 2000.0),
        ]
        path = export_json(events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        assert len(data) == 1
        assert data[0]["severity"] == "WARNING"

    def test_html_filters_info_after_dedupe(self, tmp_path):
        """INFO events that survive dedupe get filtered by the HTML renderer."""
        events = [
            _event("sha256:only_info", "INFO", 1000.0),
            _event("sha256:real", "WARNING", 2000.0),
        ]
        path = export_html(events, output_dir=str(tmp_path))
        with open(path, encoding="utf-8") as f:
            html_content = f.read()
        assert html_content.count('class="event warning"') == 1
        assert html_content.count('class="event critical"') == 0
        assert ">1</strong>Total Events" in html_content
        assert ">1</strong>Warning" in html_content


# -----------------------------------------------------------------------
# Topology rendering in HTML — user-facing labels and unit suffixes
# -----------------------------------------------------------------------

class TestHtmlTopologyRendering:
    """Regression tests for the topology <kv> block in the HTML report.
    Users previously saw confusing labels ("depth", "method") and
    unit-less numbers ("15" with no indication of what unit) — these
    tests pin the fixed labels in place."""

    def _event_with_topology(self) -> CoordinationEvent:
        from agentsonar._core.schema import Topology
        topology = Topology(
            agents_involved=("planner", "researcher", "reviewer"),
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=16,
            edge_frequency={
                "planner->researcher": 16,
                "researcher->reviewer": 16,
                "reviewer->planner": 16,
            },
        )
        return CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-topology",
            session_id="sess-1",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:topology",
            topology=topology,
            summary="test event",
        )

    def test_html_has_no_method_label(self):
        """Regression: the HTML report used to show `method: incremental`
        or `method: scc_sweep` — internal layer names leaked into the
        public output. Removed in favor of `interaction_pattern`."""
        html_content = events_to_html([self._event_with_topology()])
        assert '<div class="k">method</div>' not in html_content

    def test_html_has_no_depth_label(self):
        """Regression: `depth` was the old label for `delegation_depth`.
        Renamed to `agent count` to make the meaning obvious."""
        html_content = events_to_html([self._event_with_topology()])
        assert '<div class="k">depth</div>' not in html_content

    def test_html_shows_agent_count_label(self):
        """The new `agent count` label appears in the topology block."""
        html_content = events_to_html([self._event_with_topology()])
        assert '<div class="k">agent count</div>' in html_content
        # And the value renders alongside it
        assert '<div class="v">3</div>' in html_content

    def test_html_edge_frequency_has_events_unit(self):
        """Regression: edge counts used to render as a bare number
        (`<div class="v">16</div>`) which could be mistaken for minutes
        or any other unit. They now append "events" (with a non-breaking
        space) so the unit is always explicit."""
        html_content = events_to_html([self._event_with_topology()])
        # At least one edge from the fixture must render with the unit
        assert "16&nbsp;events" in html_content
        # And all three should appear
        assert html_content.count("16&nbsp;events") == 3

    def test_html_shows_pattern_label(self):
        """Pattern label is still present — we didn't accidentally drop it
        when cleaning up."""
        html_content = events_to_html([self._event_with_topology()])
        assert '<div class="k">pattern</div>' in html_content
        assert "circular" in html_content

    def test_html_fingerprint_has_label_and_tooltip(self):
        """Regression: the coordination fingerprint used to render as a
        bare `sha256:...` string with no context, and users had no idea
        what it meant. It now renders with a visible "fingerprint" label
        and a hover tooltip explaining what it is."""
        html_content = events_to_html([self._event_with_topology()])
        # Visible label
        assert '<span class="fingerprint-label"' in html_content
        assert ">fingerprint</span>" in html_content
        # Explanatory tooltip (title attribute)
        assert 'title="Stable hash of the failure pattern' in html_content
        assert "dedupe" in html_content.lower()
        # The actual fingerprint value still renders alongside it
        assert "sha256:topology" in html_content

    def test_html_shows_session_id_and_event_id(self):
        """Regression: the HTML card header used to only show severity,
        failure class, summary, and fingerprint. Users couldn't correlate
        events back to a specific session or deep-link to an event.
        Now each card shows both session_id and event_id with labels."""
        html_content = events_to_html([self._event_with_topology()])
        # Both IDs render with explicit labels (not just the bare values)
        assert ">session</span>" in html_content
        assert ">event id</span>" in html_content
        # The actual values appear in the output
        assert "sess-1" in html_content
        assert "evt-topology" in html_content

    def test_html_ids_have_explanatory_tooltips(self):
        """Both session and event-id labels carry title= tooltips
        explaining what each id is useful for — so readers don't have
        to guess or open the docs."""
        html_content = events_to_html([self._event_with_topology()])
        # Session tooltip mentions the JSONL log correlation
        assert 'title="Unique identifier for the AgentSonar run' in html_content
        assert "session_start" in html_content
        # Event-id tooltip mentions deep-linking
        assert 'title="UUID unique to this specific CoordinationEvent' in html_content

    def test_html_failure_class_has_tooltip(self):
        """Regression: the failure class label used to be bare text.
        New users saw `cyclic_delegation` and had no idea what it meant
        without reading the README. Now hovering the label shows a
        definition inline. One tooltip per failure class name,
        sourced from _FAILURE_CLASS_DESCRIPTIONS."""
        html_content = events_to_html([self._event_with_topology()])
        # Failure class is wrapped in a span with a tooltip
        assert '<span class="failure-class"' in html_content
        # Tooltip content mentions something specific to cyclic_delegation
        # (the word "loop" appears in the description)
        assert "stuck in a loop" in html_content

    def test_html_failure_class_tooltip_per_failure_type(self):
        """Each distinct failure class gets its OWN tooltip text —
        repetitive_delegation's tooltip should differ from
        cyclic_delegation's. This catches accidentally sharing the
        same description for different classes."""
        from agentsonar._core.schema import Topology
        rep_topology = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=11,
            edge_frequency={"a->b": 11},
        )
        rep_event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-rep",
            session_id="sess-1",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:rep",
            topology=rep_topology,
            summary="rep",
        )
        html_content = events_to_html([rep_event])
        # Repetitive's description mentions "without making progress"
        assert "without making progress" in html_content

    def test_html_supports_dark_mode(self):
        """Regression: the HTML report had hardcoded light-mode colors
        (#f4f4f6 body, #fff cards, #1a1a1a text). Now it uses CSS custom
        properties with a `[data-theme="dark"]` override and
        `prefers-color-scheme: dark` respect via an inline head script."""
        html_content = events_to_html([self._event_with_topology()])

        # color-scheme hint for browsers (form controls, scrollbars)
        assert "color-scheme: light dark" in html_content

        # CSS variables defined for both themes
        assert "--bg:" in html_content
        assert "--fg:" in html_content
        # Dark theme override block
        assert '[data-theme="dark"]' in html_content

        # body uses var(--bg) not hardcoded hex
        # (We check for `background: var(--bg)` and the absence of
        # the old `background: #f4f4f6` literal.)
        assert "background: var(--bg)" in html_content
        assert "background: #f4f4f6" not in html_content
        assert "color: #1a1a1a" not in html_content

    def test_html_has_theme_toggle_button(self):
        """The toggle button is visible in the rendered HTML with its
        own aria-label and tooltip explaining what it does."""
        html_content = events_to_html([self._event_with_topology()])

        assert 'class="theme-toggle"' in html_content
        assert 'id="theme-toggle"' in html_content
        assert 'aria-label="Toggle color theme"' in html_content
        # Tooltip mentions localStorage persistence
        assert "localStorage" in html_content
        # Button script wires up the click handler
        assert 'addEventListener("click"' in html_content

    def test_html_sets_initial_theme_before_paint(self):
        """Best practice: the theme-loading script must run in <head>
        BEFORE the body renders, so the user never sees a flash of
        light theme on dark-mode systems. This test checks that the
        initial theme script is in the <head> block (before </head>)."""
        html_content = events_to_html([self._event_with_topology()])
        head_end = html_content.index("</head>")
        head_content = html_content[:head_end]

        # The theme-setting script must live in <head>
        assert "data-theme" in head_content
        # It should read the OS preference
        assert "prefers-color-scheme: dark" in head_content
        # And read from localStorage
        assert 'localStorage.getItem("agentsonar-theme")' in head_content

    def test_html_theme_toggle_persists_to_localstorage(self):
        """The click handler writes to localStorage so the user's
        preference carries across runs."""
        html_content = events_to_html([self._event_with_topology()])
        # localStorage.setItem call for the toggle action
        assert 'localStorage.setItem("agentsonar-theme"' in html_content

    def test_html_generated_at_is_explicit_utc(self):
        """Regression: the 'Generated at' meta line used to render in
        local time (`2026-04-11 06:38:09`), which was ambiguous across
        timezones. It now renders as explicit UTC ISO 8601 with the
        timezone marker spelled out."""
        import re as _re
        html_content = events_to_html([self._event_with_topology()])

        # Must contain a <time> element with a proper ISO 8601 datetime
        # attribute ending in +00:00 (UTC offset).
        match = _re.search(
            r'<time\s+datetime="(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+00:00)"',
            html_content,
        )
        assert match is not None, (
            "Generated at timestamp is missing or not in UTC ISO 8601 form"
        )

        # The visible text must include the "UTC" suffix so readers
        # don't have to inspect the datetime attribute to know the zone
        assert "UTC</time>" in html_content

    def test_html_generated_at_has_tooltip(self):
        """The <time> element carries a tooltip explaining why UTC."""
        html_content = events_to_html([self._event_with_topology()])
        assert 'title="UTC ISO 8601 timestamp' in html_content

    def test_html_no_local_time_format_regression(self):
        """Regression guard: the old format was `YYYY-MM-DD HH:MM:SS`
        (no T separator, no timezone). Ensure no line matching that
        pattern appears near the 'Generated at' text."""
        import re as _re
        html_content = events_to_html([self._event_with_topology()])
        # Find the Generated at region
        idx = html_content.index("Generated at")
        # Look at a reasonable slice after it
        region = html_content[idx:idx + 500]
        # The ambiguous local-time format `2026-04-11 06:38:09` (space
        # separator, no zone) must NOT appear in that region.
        ambiguous = _re.search(
            r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?![+\-\d])",
            region,
        )
        assert ambiguous is None, (
            f"Ambiguous local-time format still present: {ambiguous.group(0)!r}"
        )


class TestHtmlRawJsonView:
    """The HTML report embeds a collapsible raw-JSON block containing
    the same data `export_json()` writes to the sidecar `.json` file.
    Users who want the machine-readable event payload don't have to
    open a second file — they can expand the block in the HTML and
    copy it to their clipboard."""

    def _mixed_events(self) -> list[CoordinationEvent]:
        """Build 2 events — one cyclic, one repetitive — so we have
        enough data to assert against in the embedded JSON."""
        from agentsonar._core.schema import Topology
        cycle_topology = Topology(
            agents_involved=("planner", "researcher", "reviewer"),
            interaction_pattern="circular",
            agent_count=3,
            occurrence_count=15,
            edge_frequency={
                "planner->researcher": 15,
                "researcher->reviewer": 15,
                "reviewer->planner": 15,
            },
        )
        cycle = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-cycle",
            session_id="sess-1",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.CYCLIC_DELEGATION,
            severity=AlertSeverity.CRITICAL,
            coordination_fingerprint="sha256:cycle",
            topology=cycle_topology,
            summary="Cyclic delegation detected: planner -> researcher -> reviewer -> planner (15 rotations)",
        )
        rep_topology = Topology(
            agents_involved=("validator", "worker"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=11,
            edge_frequency={"validator->worker": 11},
        )
        rep = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-rep",
            session_id="sess-1",
            timestamp=1001.0,
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:rep",
            topology=rep_topology,
            summary="Repetitive delegation detected: validator -> worker (11 events)",
        )
        return [cycle, rep]

    def test_html_has_raw_json_details_block(self):
        """The <details class="json-view"> block is present in every
        rendered report, collapsed by default."""
        html_content = events_to_html(self._mixed_events())
        assert '<details class="json-view">' in html_content
        assert "Raw JSON" in html_content
        assert 'id="json-block"' in html_content

    def test_html_raw_json_contains_all_displayed_events(self):
        """Every event that appears as a card must also appear in the
        embedded JSON block. Match on event_id which is guaranteed
        unique. JSON is HTML-escaped inside the <pre> so assertions
        check both escaped and unescaped forms."""
        events = self._mixed_events()
        html_content = events_to_html(events)
        for event in events:
            # The event_id appears in the JSON somewhere
            assert event.event_id in html_content, (
                f"event_id {event.event_id} missing from JSON block"
            )

    def test_html_raw_json_matches_export_json_output(self):
        """The embedded JSON must be byte-identical to what export_json
        (with default dedupe=True) would produce — same payload, same
        dedupe/inhibit pipeline, so users can rely on either route
        interchangeably."""
        import json as _json
        from agentsonar._output.json_export import events_to_json
        events = self._mixed_events()

        html_content = events_to_html(events)
        json_string = events_to_json(events)

        # Parse the JSON_string so we can compare by value rather than
        # by string match (the HTML version is HTML-escaped in place).
        expected_payload = _json.loads(json_string)
        assert len(expected_payload) == 2
        # Every event id from the canonical JSON export appears in the
        # HTML's embedded JSON block
        for e in expected_payload:
            assert e["event_id"] in html_content

    def test_html_raw_json_block_is_collapsed_by_default(self):
        """<details> has no `open` attribute so the block starts
        collapsed — users see cards first, JSON is an escape hatch."""
        import re as _re
        html_content = events_to_html(self._mixed_events())
        # Find the json-view details tag and check it doesn't have open
        match = _re.search(
            r'<details class="json-view"([^>]*)>',
            html_content,
        )
        assert match is not None
        attributes = match.group(1)
        assert "open" not in attributes, (
            "json-view details block should be collapsed by default"
        )

    def test_html_has_json_copy_button(self):
        """The JSON block has a 'Copy JSON' button + status indicator
        so users can grab the payload with one click."""
        html_content = events_to_html(self._mixed_events())
        assert 'id="json-copy-btn"' in html_content
        assert "Copy JSON" in html_content
        assert 'id="json-copy-status"' in html_content
        # JS uses navigator.clipboard.writeText or legacy fallback
        assert "navigator.clipboard" in html_content
        assert "execCommand" in html_content  # fallback path

    def test_html_raw_json_properly_escaped(self):
        """The embedded JSON must be HTML-escaped so special characters
        in summaries or agent names can't break out of the <pre> block
        and inject arbitrary HTML. Test with an event whose summary
        contains `<`, `>`, and `&`."""
        from agentsonar._core.schema import Topology
        topo = Topology(
            agents_involved=("agent<x>", "agent&y"),
            interaction_pattern="one_directional",
            agent_count=2,
            occurrence_count=5,
            edge_frequency={"agent<x>->agent&y": 5},
        )
        evt = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-injection",
            session_id="sess-1",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.REPETITIVE_DELEGATION,
            severity=AlertSeverity.WARNING,
            coordination_fingerprint="sha256:inj",
            topology=topo,
            summary="<script>alert('xss')</script>",
        )
        html_content = events_to_html([evt])

        # Raw special characters from the summary must NOT appear
        # verbatim inside the json-block — they should be escaped.
        json_block_start = html_content.index('id="json-block"')
        json_block_end = html_content.index("</pre>", json_block_start)
        json_region = html_content[json_block_start:json_block_end]

        # The raw string "<script>" must not appear literally
        assert "<script>" not in json_region
        # But the HTML-escaped form is fine
        assert "&lt;script&gt;" in json_region or "&amp;lt;script" in json_region
        # The escaped ampersand variant of `agent&y` must be present
        assert "agent&amp;y" in json_region

    def test_html_failure_class_tooltip_resource_exhaustion(self):
        from agentsonar._core.schema import Topology
        rate_topology = Topology(
            agents_involved=("a", "b"),
            interaction_pattern="throttled",
            agent_count=2,
            occurrence_count=0,
            edge_frequency={"a->b": 20},
        )
        rate_event = CoordinationEvent(
            schema_version="0.1.0",
            event_id="evt-rate",
            session_id="sess-1",
            timestamp=1000.0,
            event_type="coordination_failure",
            failure_class=FailureClass.RESOURCE_EXHAUSTION,
            severity=AlertSeverity.CRITICAL,
            coordination_fingerprint="sha256:rate",
            topology=rate_topology,
            summary="rate",
        )
        html_content = events_to_html([rate_event])
        # Resource exhaustion's description mentions "faster than it can handle"
        assert "faster than it can handle" in html_content
