"""
Host-safety regression tests — the "observer must never crash the
observed system" prime directive.

AgentSonar is an observability SDK. If ANY of its code paths raise
into the host application — bad config, missing files, broken
detectors, unexpected types, race conditions, interpreter shutdown —
the host's LLM calls, graph execution, and business logic must
keep running. Detection degrades; the host never does.

Every test in this module asserts that a specific failure mode
does NOT propagate into the host. If any of these fail, it's a
P0 bug: AgentSonar shipped a regression that can crash user
applications.

The failure modes covered:

  1. `AgentSonarCallback()` with bad config (negative rate limit,
     NaN window_size, unknown keys).
  2. `AgentSonarCallback()` with a non-dict config (string, list,
     int, class instance).
  3. `monitor()` with bad config — wrapper construction must
     succeed and the wrapped graph must still be invokable.
  4. `_MonitoredGraph._merge_config` with exotic user callback
     shapes (single handler, dict, string, None-of-None).
  5. `engine.ingest()` with None, garbage strings, objects without
     the required attributes.
  6. `on_chain_start` with garbage metadata (non-dict, None, dict
     with wrong shape).
  7. Double-shutdown, triple-shutdown, shutdown-then-ingest.
  8. Listener construction when CrewAI super().__init__ explodes
     (simulated via monkeypatch).
  9. `get_summary()` / `get_recent_events()` on a degraded engine.
 10. Every path returns an empty-but-valid result instead of
     raising, so downstream code that expects `.alerts_raised` /
     `.get("alerts", [])` still works.
"""
from __future__ import annotations

import logging

import pytest

from agentsonar import AgentSonarCallback, monitor
from agentsonar._core.models import InteractionEvent
from agentsonar._core.noop_engine import _NoOpEngine


# ---------------------------------------------------------------------------
# 1. Bad config values
# ---------------------------------------------------------------------------

BAD_CONFIGS = [
    {"per_edge_limit": -1},
    {"per_edge_limit": 0},
    {"global_limit": -5},
    {"window_size": -10},
    {"window_size": float("nan")},
    {"window_size": float("inf")},
]


@pytest.mark.parametrize("bad_config", BAD_CONFIGS)
def test_callback_with_bad_config_does_not_raise(bad_config):
    """Bad config values MUST fall back to _NoOpEngine, not crash."""
    sonar = AgentSonarCallback(config=bad_config)
    assert isinstance(sonar.engine, _NoOpEngine), (
        f"expected _NoOpEngine fallback for {bad_config}, "
        f"got {type(sonar.engine).__name__}"
    )
    # And every public method still works
    sonar.on_chain_start(serialized={}, inputs={}, metadata={"langgraph_node": "a"})
    summary = sonar.get_summary()
    assert summary.get("degraded") is True
    sonar.shutdown()
    sonar.shutdown()  # idempotent


def test_callback_bad_config_logs_warning(caplog):
    """Degradation must log at WARNING level so users see something."""
    with caplog.at_level(logging.WARNING, logger="agentsonar"):
        AgentSonarCallback(config={"per_edge_limit": -1})
    messages = [r.message for r in caplog.records]
    assert any("degraded" in m.lower() for m in messages), (
        f"expected a degraded-mode warning, got: {messages}"
    )


# ---------------------------------------------------------------------------
# 2. Non-dict config
# ---------------------------------------------------------------------------

NON_DICT_CONFIGS = [
    "bogus",
    [1, 2, 3],
    42,
    object(),
]


@pytest.mark.parametrize("bad_config", NON_DICT_CONFIGS)
def test_callback_with_non_dict_config_falls_back_to_defaults(bad_config):
    """Non-dict config should be silently normalized to an empty dict,
    giving a real DetectionEngine with defaults. Host must never see
    an exception from the constructor."""
    sonar = AgentSonarCallback(config=bad_config)
    # Non-dict configs succeed (normalized to {} → defaults), so the
    # engine is a REAL DetectionEngine, not a NoOp. The key property
    # is that construction did not raise.
    assert hasattr(sonar, "engine")
    assert hasattr(sonar.engine, "ingest")
    sonar.shutdown()


# ---------------------------------------------------------------------------
# 3. monitor() fault isolation
# ---------------------------------------------------------------------------

def _build_tiny_graph():
    """Minimal 1-node graph for host-safety probes."""
    from typing_extensions import TypedDict
    from langgraph.graph import END, START, StateGraph

    class _S(TypedDict):
        x: int

    def _n(s):
        return {"x": 1}

    b = StateGraph(_S)
    b.add_node("n", _n)
    b.add_edge(START, "n")
    b.add_edge("n", END)
    return b.compile()


@pytest.mark.parametrize("bad_config", BAD_CONFIGS)
def test_monitor_with_bad_config_returns_working_wrapper(bad_config):
    """monitor() must NEVER raise, and the wrapped graph must still
    be invokable even when AgentSonar is in degraded mode."""
    graph = _build_tiny_graph()
    wrapped = monitor(graph, config=bad_config)
    # Construction did not raise
    assert wrapped is not None
    # Wrapped graph is still fully functional
    result = wrapped.invoke({"x": 0})
    assert result["x"] == 1
    wrapped.shutdown()


def test_monitor_invoke_preserves_existing_callbacks_on_bad_config():
    """A user who passes their own callback must still see it fire,
    even when AgentSonar is degraded."""
    graph = _build_tiny_graph()
    wrapped = monitor(graph, config={"per_edge_limit": -1})

    # Mock user callback that just counts invocations
    from langchain_core.callbacks import BaseCallbackHandler
    fire_count = [0]

    class _UserCB(BaseCallbackHandler):
        def on_chain_start(self, *a, **k):
            fire_count[0] += 1

    wrapped.invoke({"x": 0}, config={"callbacks": [_UserCB()]})
    assert fire_count[0] >= 1, "user's callback must still fire"
    wrapped.shutdown()


def test_monitor_with_exotic_callbacks_does_not_mangle_user_error():
    """If the user passes something LangGraph would reject (e.g. a
    string as callbacks), AgentSonar must NOT make it worse — we pass
    the user's config through untouched and let LangGraph surface its
    own error."""
    graph = _build_tiny_graph()
    wrapped = monitor(graph)

    # Capture vanilla LangGraph's error first
    try:
        graph.invoke({"x": 0}, config={"callbacks": "wat"})
    except Exception as baseline:
        baseline_type = type(baseline).__name__

    # With monitor: should raise the SAME error type (LangGraph's own)
    with pytest.raises(Exception) as excinfo:
        wrapped.invoke({"x": 0}, config={"callbacks": "wat"})
    assert type(excinfo.value).__name__ == baseline_type, (
        f"monitor mangled the user's error: baseline={baseline_type}, "
        f"monitored={type(excinfo.value).__name__}"
    )
    wrapped.shutdown()


# ---------------------------------------------------------------------------
# 4. Engine.ingest fault isolation
# ---------------------------------------------------------------------------

def test_ingest_none_does_not_raise():
    sonar = AgentSonarCallback()
    try:
        result = sonar.engine.ingest(None)
        assert result == []
    finally:
        sonar.shutdown()


def test_ingest_garbage_string_does_not_raise():
    sonar = AgentSonarCallback()
    try:
        result = sonar.engine.ingest("not an event")
        assert result == []
    finally:
        sonar.shutdown()


def test_ingest_object_missing_attrs_does_not_raise():
    sonar = AgentSonarCallback()
    try:
        class _Bogus:
            pass
        result = sonar.engine.ingest(_Bogus())
        assert result == []
    finally:
        sonar.shutdown()


# ---------------------------------------------------------------------------
# 5. on_chain_start fault isolation
# ---------------------------------------------------------------------------

BAD_METADATA = [
    None,
    {},
    {"langgraph_node": None},
    {"langgraph_node": 42},
    {"langgraph_node": "a", "langgraph_step": "not_an_int"},
    [1, 2, 3],     # not a dict at all
    "bogus",
    object(),
]


@pytest.mark.parametrize("meta", BAD_METADATA)
def test_on_chain_start_with_bad_metadata_does_not_raise(meta):
    sonar = AgentSonarCallback()
    try:
        sonar.on_chain_start(
            serialized={},
            inputs={},
            metadata=meta,
            run_id="r1",
            parent_run_id=None,
        )
    finally:
        sonar.shutdown()


# ---------------------------------------------------------------------------
# 6. Double + triple shutdown, post-shutdown ingest
# ---------------------------------------------------------------------------

def test_triple_shutdown_is_idempotent():
    sonar = AgentSonarCallback()
    sonar.shutdown()
    sonar.shutdown()
    sonar.shutdown()


def test_ingest_after_shutdown_does_not_raise():
    sonar = AgentSonarCallback()
    sonar.shutdown()
    result = sonar.engine.ingest(InteractionEvent("a", "b", 1000.0))
    assert result == []


def test_get_summary_after_shutdown_returns_valid_dict():
    sonar = AgentSonarCallback()
    sonar.shutdown()
    s = sonar.get_summary()
    # Must be a dict, and must have the well-known keys so downstream
    # dashboards / parsers don't trip on .get("alerts_raised")
    assert isinstance(s, dict)
    assert "alerts_raised" in s
    assert "alerts" in s


# ---------------------------------------------------------------------------
# 7. _NoOpEngine degraded-mode contract
# ---------------------------------------------------------------------------

def test_noop_engine_surface_matches_degraded_callback():
    """_NoOpEngine must expose every method the integration layer
    touches, with the exact same signatures, so a degraded callback
    is indistinguishable from a working one at the call-site level."""
    eng = _NoOpEngine()
    assert hasattr(eng, "session_id")
    assert hasattr(eng, "logger")
    assert eng.ingest(None) == []
    eng.increment_iteration()
    assert eng.iteration_count == 1
    s = eng.get_summary()
    assert s["degraded"] is True
    assert eng.get_recent_events() == []
    eng.shutdown()
    eng.shutdown()  # idempotent


def test_noop_engine_logger_is_noop_compatible():
    """Every log_* method the engine + integrations touch must exist
    on _NoOpLogger and be callable with positional or keyword args."""
    eng = _NoOpEngine()
    # The methods that the real engine's ingest path calls via
    # log_actions. If this list drifts, auto-export will crash
    # on a degraded engine during shutdown.
    for method in [
        "log_session_start", "log_session_end",
        "log_delegation", "log_graph_update",
        "log_alert", "log_alert_resolved",
        "log_cycle_detected", "log_anomaly_detected",
        "log_rate_limit_hit", "log_scc_sweep",
    ]:
        fn = getattr(eng.logger, method)
        fn()  # no args
        fn("positional")
        fn(kw="value")


# ---------------------------------------------------------------------------
# 8. Full end-to-end: simulate a real graph crash-recovery path
# ---------------------------------------------------------------------------

def test_monitored_graph_still_runs_when_engine_fully_degraded():
    """The most important end-to-end test: a user with bad config
    runs their graph and everything still works. No crash, results
    come back, shutdown cleanly."""
    graph = _build_tiny_graph()
    wrapped = monitor(graph, config={"window_size": float("nan")})
    assert isinstance(wrapped.sonar.engine, _NoOpEngine)
    result = wrapped.invoke({"x": 0})
    assert result["x"] == 1
    summary = wrapped.get_summary()
    assert summary.get("degraded") is True
    wrapped.shutdown()
