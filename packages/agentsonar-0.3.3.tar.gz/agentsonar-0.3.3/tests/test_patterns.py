"""
Unit tests for individual pattern detectors (Layers 1-5).

No LLM calls — tests each layer in isolation.
"""
import time

import networkx as nx
import pytest

from agentsonar._core.models import Alert, CycleInfo, InteractionEvent
from agentsonar._core.detectors.rate_limiter import SlidingWindowLimiter
from agentsonar._core.detectors.repetitive_detector import ExponentialDecayDetector
from agentsonar._core.detectors.cycle_detector import CycleDetector
from agentsonar._core.detectors.alert_state import AlertStateManager
from agentsonar._core.detectors.scc_analyzer import PeriodicSCCAnalyzer


def _event(src: str, tgt: str, ts: float | None = None) -> InteractionEvent:
    return InteractionEvent(
        source_agent=src,
        target_agent=tgt,
        timestamp=ts if ts is not None else time.time(),
    )


def _build_graph(edges: list[tuple[str, str, int]]) -> nx.DiGraph:
    """Build a DiGraph from (src, dst, count) triples."""
    g = nx.DiGraph()
    for src, dst, count in edges:
        g.add_edge(src, dst, count=count, total_tokens=0)
    return g


# =======================================================================
# Layer 1: SlidingWindowLimiter
# =======================================================================

class TestSlidingWindowLimiter:

    def test_no_alert_under_limit(self):
        limiter = SlidingWindowLimiter(window_size=60.0, per_edge_limit=5, global_limit=20)
        now = 1000.0
        for i in range(4):
            result = limiter.check("a", "b", now + i)
        assert result is None

    def test_per_edge_alert_over_limit(self):
        limiter = SlidingWindowLimiter(window_size=60.0, per_edge_limit=5, global_limit=200)
        now = 1000.0
        alert = None
        for i in range(10):
            alert = limiter.check("a", "b", now + i)
            if alert:
                break
        assert alert is not None
        assert alert.severity == "CRITICAL"
        assert alert.pattern == "rate_limit_exceeded"

    def test_global_limit_alert(self):
        limiter = SlidingWindowLimiter(window_size=60.0, per_edge_limit=100, global_limit=5)
        now = 1000.0
        # Spread across different edges to avoid per-edge limit
        edges = [("a", "b"), ("c", "d"), ("e", "f"), ("g", "h"), ("i", "j"), ("k", "l")]
        alert = None
        for i, (s, t) in enumerate(edges):
            alert = limiter.check(s, t, now + i)
            if alert and alert.pattern == "global_rate_exceeded":
                break
        assert alert is not None
        assert alert.pattern == "global_rate_exceeded"

    def test_window_rollover_resets(self):
        limiter = SlidingWindowLimiter(window_size=10.0, per_edge_limit=5, global_limit=200)
        now = 1000.0
        # Fire 4 events in first window
        for i in range(4):
            limiter.check("a", "b", now + i)
        # Jump past the window — previous events should decay
        result = limiter.check("a", "b", now + 20.0)
        assert result is None

    def test_reset_clears_state(self):
        limiter = SlidingWindowLimiter(window_size=60.0, per_edge_limit=3, global_limit=200)
        now = 1000.0
        for i in range(3):
            limiter.check("a", "b", now + i)
        limiter.reset()
        result = limiter.check("a", "b", now + 10)
        assert result is None

    # -----------------------------------------------------------------
    # Hysteresis / anti-flap (half-open circuit-breaker pattern)
    # -----------------------------------------------------------------

    def test_hysteresis_suppresses_machine_gun_firing(self):
        """Regression: without hysteresis, every single event over the
        limit produced a fresh CRITICAL alert — a "machine gun" pattern
        flagged as the #1 rate-limiter anti-pattern by Prometheus and
        Datadog. With hysteresis (half-open circuit breaker), the first
        breach fires exactly ONCE and every subsequent event on the
        same window is suppressed until the rate cools."""
        limiter = SlidingWindowLimiter(
            window_size=60.0, per_edge_limit=5, global_limit=1000,
        )
        now = 1000.0
        alerts = []
        # Burst 20 events on a single edge — old behavior was 15+ alerts,
        # new behavior is exactly 1 (the first breach).
        for i in range(20):
            alert = limiter.check("a", "b", now + i * 0.01)
            if alert is not None:
                alerts.append(alert)
        assert len(alerts) == 1, (
            f"expected 1 alert (hysteresis), got {len(alerts)} — "
            "the rate limiter is machine-gun firing"
        )
        assert alerts[0].severity == "CRITICAL"
        assert alerts[0].pattern == "rate_limit_exceeded"

    def test_hysteresis_suppresses_global_machine_gun(self):
        """Same anti-flap behavior for the global rate limit."""
        limiter = SlidingWindowLimiter(
            window_size=60.0, per_edge_limit=1000, global_limit=5,
        )
        now = 1000.0
        alerts = []
        # 20 events spread across distinct edges so per-edge never trips;
        # global should fire ONCE then stay silent.
        for i in range(20):
            alert = limiter.check(f"src{i}", f"tgt{i}", now + i * 0.01)
            if alert is not None:
                alerts.append(alert)
        assert len(alerts) == 1
        assert alerts[0].pattern == "global_rate_exceeded"

    def test_hysteresis_rearms_after_window_rollover(self):
        """A fresh window is a natural re-arm point. After the window
        rolls over, the limiter is a clean slate — a new burst should
        fire a fresh alert even though the previous window had already
        fired. Without this, the user would only get one alert per run
        even for long-lived workloads."""
        limiter = SlidingWindowLimiter(
            window_size=10.0, per_edge_limit=5, global_limit=1000,
        )
        now = 1000.0
        # First burst: trips and fires
        alerts = []
        for i in range(10):
            alert = limiter.check("a", "b", now + i * 0.1)
            if alert is not None:
                alerts.append(alert)
        assert len(alerts) == 1

        # Wait past the window_size so the window rolls over
        rollover_time = now + 25.0
        for i in range(10):
            alert = limiter.check("a", "b", rollover_time + i * 0.1)
            if alert is not None:
                alerts.append(alert)
        assert len(alerts) == 2, (
            f"expected 2 alerts (one per window), got {len(alerts)} — "
            "the limiter did not re-arm on window rollover"
        )

    def test_reset_ratio_validates_range(self):
        """Defensive: reset_ratio must be a proper fraction."""
        with pytest.raises(ValueError):
            SlidingWindowLimiter(reset_ratio=0.0)
        with pytest.raises(ValueError):
            SlidingWindowLimiter(reset_ratio=1.0)
        with pytest.raises(ValueError):
            SlidingWindowLimiter(reset_ratio=1.5)

    def test_alert_details_include_reset_ratio(self):
        """The fired alert's details should record the reset_ratio used,
        so downstream consumers can reason about the suppression window."""
        limiter = SlidingWindowLimiter(
            window_size=60.0, per_edge_limit=5, global_limit=1000,
            reset_ratio=0.8,
        )
        now = 1000.0
        alert = None
        for i in range(10):
            alert = limiter.check("a", "b", now + i * 0.01)
            if alert:
                break
        assert alert is not None
        assert alert.details.get("reset_ratio") == 0.8


# =======================================================================
# Layer 2: ExponentialDecayDetector
# =======================================================================

class TestExponentialDecayDetector:

    def test_single_event_no_anomaly(self):
        decay = ExponentialDecayDetector(hard_weight_limit=10.0)
        now = 1000.0
        decay.record_event("a", "b", now)
        result = decay.check_anomaly("a", "b", now)
        assert result is None  # weight=1.0, well under limit

    def test_hard_limit_triggers(self):
        decay = ExponentialDecayDetector(
            half_life_seconds=600.0,  # long decay so weight accumulates
            hard_weight_limit=5.0,
        )
        now = 1000.0
        result = None
        for i in range(10):
            decay.record_event("a", "b", now + i * 0.1)
            result = decay.check_anomaly("a", "b", now + i * 0.1)
            if result:
                break
        assert result is not None
        assert result["trigger"] == "hard_limit"

    def test_weight_decays_over_time(self):
        decay = ExponentialDecayDetector(half_life_seconds=1.0)
        now = 1000.0
        decay.record_event("a", "b", now)
        # Weight right after event
        w1 = decay.get_current_weight("a", "b", now)
        # Weight after 2 half-lives (should be ~0.25)
        w2 = decay.get_current_weight("a", "b", now + 2.0)
        assert w2 < w1 * 0.5

    def test_zscore_triggers_with_enough_edges(self):
        decay = ExponentialDecayDetector(
            half_life_seconds=600.0,
            z_score_threshold=2.0,
            hard_weight_limit=1000.0,  # very high so we test z-score path only
            min_edges_for_zscore=3,
        )
        now = 1000.0
        # Create 5 baseline edges with 1 event each (more edges = more stable stats)
        for pair in [("x", "y"), ("p", "q"), ("m", "n"), ("r", "s"), ("u", "v")]:
            decay.record_event(pair[0], pair[1], now)
        # Hammer one edge heavily — should stand out statistically
        for i in range(50):
            decay.record_event("a", "b", now + i * 0.1)
        result = decay.check_anomaly("a", "b", now + 5.0)
        assert result is not None
        assert result["trigger"] == "z_score"

    def test_no_anomaly_for_unknown_edge(self):
        decay = ExponentialDecayDetector()
        result = decay.check_anomaly("x", "y", 1000.0)
        assert result is None

    def test_get_weight_for_unknown_edge(self):
        decay = ExponentialDecayDetector()
        assert decay.get_current_weight("x", "y", 1000.0) == 0.0

    def test_reset_clears_state(self):
        decay = ExponentialDecayDetector(half_life_seconds=600.0)
        decay.record_event("a", "b", 1000.0)
        decay.reset()
        assert decay.get_current_weight("a", "b", 1000.0) == 0.0

    def test_reset_clears_total_event_counter(self):
        """Regression: the z-score warm-up gate uses a running total
        of events across all edges. reset() must clear it along with
        the per-edge state, or a second run on the same detector would
        use stale warm-up state."""
        decay = ExponentialDecayDetector(
            half_life_seconds=600.0, hard_weight_limit=1000.0,
            min_edges_for_zscore=3, min_total_events=5,
        )
        for i in range(10):
            decay.record_event("a", "b", 1000.0 + i * 0.1)
        assert decay._total_events == 10
        decay.reset()
        assert decay._total_events == 0

    # -----------------------------------------------------------------
    # Z-score warm-up gates (false-positive prevention)
    # -----------------------------------------------------------------

    def test_zscore_warmup_gates_tiny_total_events(self):
        """Regression: the z-score path used to fire on as few as 3
        distinct edges with 1 event each. That's statistically
        meaningless — the variance is trivially zero and a hot edge
        stands out by 0σ (or ∞σ when std==0). The new
        `min_total_events` gate requires a minimum cumulative sample
        count before z-score activates, matching Apache Beam's 20-50
        sample convention for streaming anomaly detection."""
        decay = ExponentialDecayDetector(
            half_life_seconds=600.0,
            z_score_threshold=2.0,
            hard_weight_limit=1000.0,
            min_edges_for_zscore=3,
            min_total_events=20,
        )
        now = 1000.0
        # 3 baseline edges (satisfies min_edges) with 1 event each,
        # plus 3 events on the "hot" edge. Total = 6, well under
        # min_total_events=20, so the z-score path MUST NOT fire.
        for pair in [("x", "y"), ("p", "q"), ("m", "n")]:
            decay.record_event(pair[0], pair[1], now)
        for i in range(3):
            decay.record_event("a", "b", now + i * 0.1)
        result = decay.check_anomaly("a", "b", now + 1.0)
        assert result is None, (
            "z-score fired before min_total_events warm-up satisfied — "
            "this is the tiny-sample false-positive the gate prevents"
        )

    def test_zscore_warmup_activates_after_enough_events(self):
        """Once both warm-up gates are satisfied, the z-score path
        activates normally and fires on hot edges."""
        decay = ExponentialDecayDetector(
            half_life_seconds=600.0,
            z_score_threshold=2.0,
            hard_weight_limit=1000.0,
            min_edges_for_zscore=3,
            min_total_events=10,
        )
        now = 1000.0
        # 5 baseline edges
        for pair in [("x", "y"), ("p", "q"), ("m", "n"), ("r", "s"), ("u", "v")]:
            decay.record_event(pair[0], pair[1], now)
        # Hammer one edge — need enough events to cross min_total_events=10
        # (we already have 5 from baseline, need 5+ more)
        for i in range(20):
            decay.record_event("a", "b", now + i * 0.1)
        result = decay.check_anomaly("a", "b", now + 5.0)
        assert result is not None, (
            "z-score did NOT fire even though warm-up gates are satisfied"
        )
        assert result["trigger"] == "z_score"

    def test_hard_limit_bypasses_warmup_gates(self):
        """The hard_weight_limit trigger is per-edge, so it doesn't
        depend on cross-edge statistics. It MUST fire even during the
        warm-up period — otherwise a runaway edge right at the start
        of a session would go undetected."""
        decay = ExponentialDecayDetector(
            half_life_seconds=600.0,
            hard_weight_limit=5.0,
            min_edges_for_zscore=100,  # z-score path effectively disabled
            min_total_events=10000,
        )
        now = 1000.0
        # Just hammer one edge — no baseline, no warm-up satisfied
        result = None
        for i in range(10):
            decay.record_event("a", "b", now + i * 0.1)
            result = decay.check_anomaly("a", "b", now + i * 0.1)
            if result:
                break
        assert result is not None, (
            "hard_weight_limit failed to fire during warm-up period"
        )
        assert result["trigger"] == "hard_limit"

    def test_min_total_events_default_is_twenty(self):
        """Pin the v0.1.0 default so accidental downgrades are caught."""
        decay = ExponentialDecayDetector()
        assert decay.min_total_events == 20
        assert decay.min_edges_for_zscore == 10


# =======================================================================
# Layer 3: CycleDetector
# =======================================================================

class TestCycleDetector:

    def test_no_cycle_in_chain(self):
        graph = _build_graph([("a", "b", 1), ("b", "c", 1)])
        detector = CycleDetector()
        result = detector.check(graph, _event("b", "c"))
        assert result is None

    def test_two_node_cycle(self):
        graph = _build_graph([("a", "b", 1), ("b", "a", 1)])
        detector = CycleDetector()
        result = detector.check(graph, _event("b", "a"))
        assert result is not None
        assert isinstance(result, CycleInfo)
        assert set(result.fingerprint) == {"a", "b"}

    def test_three_node_cycle(self):
        graph = _build_graph([("a", "b", 1), ("b", "c", 1), ("c", "a", 1)])
        detector = CycleDetector()
        result = detector.check(graph, _event("c", "a"))
        assert result is not None
        assert set(result.fingerprint) == {"a", "b", "c"}

    def test_rotation_count(self):
        graph = _build_graph([("a", "b", 5), ("b", "a", 3)])
        detector = CycleDetector()
        result = detector.check(graph, _event("b", "a"))
        assert result is not None
        assert result.rotations == 3  # min(5, 3)

    def test_no_cycle_single_edge(self):
        graph = _build_graph([("a", "b", 1)])
        detector = CycleDetector()
        result = detector.check(graph, _event("a", "b"))
        assert result is None

    def test_no_crash_on_empty_graph(self):
        graph = nx.DiGraph()
        detector = CycleDetector()
        result = detector.check(graph, _event("a", "b"))
        assert result is None


# =======================================================================
# Layer 4: AlertStateManager
# =======================================================================

class TestAlertStateManager:

    def test_no_alert_below_warning(self):
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        result = mgr.process(("a", "b"), rotations=3, pattern="cycle", now=1000.0)
        assert result is None

    def test_warning_at_threshold(self):
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        result = mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        assert result is not None
        assert result.severity == "WARNING"

    def test_escalation_to_critical(self):
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        # Between warning and critical — silent
        result = mgr.process(("a", "b"), rotations=10, pattern="cycle", now=1001.0)
        assert result is None
        # At critical threshold
        result = mgr.process(("a", "b"), rotations=15, pattern="cycle", now=1002.0)
        assert result is not None
        assert result.severity == "CRITICAL"

    def test_fast_path_critical_on_first_detection(self):
        """When the FIRST detection is already at or past critical_threshold,
        fire CRITICAL directly. Skips the WARNING-then-CRITICAL ratchet
        that would otherwise need a second ingest to escalate.

        Regression target: batch / static-graph scenarios (OMA dependsOn DAG,
        CrewAI hierarchical) where the cycle is detected only ONCE — there's
        no second ingest later for the state machine to escalate on.
        Without the fast path, those scenarios never reach CRITICAL even
        when thresholds make it intuitively expected."""
        mgr = AlertStateManager(warning_threshold=1, critical_threshold=1)
        # First detection AT critical_threshold should fire CRITICAL.
        result = mgr.process(("a", "b"), rotations=1, pattern="cycle", now=1000.0)
        assert result is not None
        assert result.severity == "CRITICAL", (
            f"expected fast-path CRITICAL, got {result.severity}"
        )

    def test_fast_path_critical_with_high_rotation_first_detection(self):
        """Even with the default thresholds (warning=5, critical=15), if the
        first ingest already shows rotations=20 (e.g. a long-paused process
        resumes and finds an existing cycle), fast-path CRITICAL kicks in
        instead of firing WARNING and waiting for another ingest."""
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        result = mgr.process(("a", "b"), rotations=20, pattern="cycle", now=1000.0)
        assert result is not None
        assert result.severity == "CRITICAL"

    def test_warning_path_unchanged_for_normal_thresholds(self):
        """Sanity: the standard ratchet still works for the common case
        (warning=5, critical=15) when rotations crosses warning first."""
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        # First ingest at rotation=5 — fires WARNING, NOT CRITICAL
        result = mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        assert result is not None
        assert result.severity == "WARNING"

    def test_re_alert_after_interval(self):
        mgr = AlertStateManager(
            warning_threshold=5, critical_threshold=15, re_alert_interval=10
        )
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        mgr.process(("a", "b"), rotations=15, pattern="cycle", now=1001.0)
        # Below re-alert interval
        result = mgr.process(("a", "b"), rotations=20, pattern="cycle", now=1002.0)
        assert result is None
        # At re-alert interval (15 + 10 = 25)
        result = mgr.process(("a", "b"), rotations=25, pattern="cycle", now=1003.0)
        assert result is not None
        assert result.severity == "CRITICAL"

    def test_no_duplicate_between_thresholds(self):
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        # Same rotations — should not re-alert
        result = mgr.process(("a", "b"), rotations=8, pattern="cycle", now=1001.0)
        assert result is None

    def test_recovery_after_quiet_period(self):
        mgr = AlertStateManager(
            warning_threshold=5, critical_threshold=15, resolve_after_seconds=10.0
        )
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        # Wait for quiet period
        recoveries = mgr.check_recoveries(1020.0)
        assert len(recoveries) == 1
        assert recoveries[0].severity == "INFO"
        assert "resolved" in recoveries[0].details["message"]

    def test_regression_after_recovery(self):
        mgr = AlertStateManager(
            warning_threshold=5, critical_threshold=15, resolve_after_seconds=10.0
        )
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        mgr.check_recoveries(1020.0)  # resolve it
        # Now it regresses
        result = mgr.process(("a", "b"), rotations=6, pattern="cycle", now=1030.0)
        assert result is not None
        assert result.severity == "WARNING"
        assert result.details.get("regression") is True

    def test_independent_fingerprints(self):
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        r1 = mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        r2 = mgr.process(("c", "d"), rotations=5, pattern="cycle", now=1000.0)
        assert r1 is not None
        assert r2 is not None

    def test_reset_clears_state(self):
        mgr = AlertStateManager(warning_threshold=5, critical_threshold=15)
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        mgr.reset()
        # After reset, same fingerprint treated as new
        result = mgr.process(("a", "b"), rotations=5, pattern="cycle", now=2000.0)
        assert result is not None


# =======================================================================
# Layer 5: PeriodicSCCAnalyzer
# =======================================================================

class TestPeriodicSCCAnalyzer:

    def test_skips_before_interval(self):
        scc = PeriodicSCCAnalyzer(interval_seconds=10.0, interval_events=50)
        graph = _build_graph([("a", "b", 1), ("b", "a", 1)])
        # First event — neither time nor count threshold met
        result = scc.maybe_run(graph, 1000.0)
        # First run should actually fire (last_run_time=0, so time diff > 10)
        # Let's set it up properly
        scc.last_run_time = 1000.0
        scc.events_since_last_run = 0
        result = scc.maybe_run(graph, 1005.0)
        assert result is None  # only 5s and 1 event

    def test_runs_after_event_interval(self):
        scc = PeriodicSCCAnalyzer(interval_seconds=1000.0, interval_events=3)
        graph = _build_graph([("a", "b", 2), ("b", "a", 2)])
        scc.last_run_time = 1000.0
        for _ in range(2):
            scc.maybe_run(graph, 1001.0)
        result = scc.maybe_run(graph, 1001.0)  # 3rd event
        assert result is not None
        assert len(result) == 1
        # Fingerprint has "scc" prefix to avoid collision with CycleDetector
        assert result[0]["fingerprint"] == ("scc", "a", "b")

    def test_runs_after_time_interval(self):
        scc = PeriodicSCCAnalyzer(interval_seconds=10.0, interval_events=1000)
        graph = _build_graph([("a", "b", 3), ("b", "c", 3), ("c", "a", 3)])
        scc.last_run_time = 1000.0
        result = scc.maybe_run(graph, 1015.0)
        assert result is not None
        assert len(result) == 1
        assert result[0]["fingerprint"] == ("scc", "a", "b", "c")
        assert result[0]["min_rotations"] == 3

    def test_ignores_single_node_sccs(self):
        scc = PeriodicSCCAnalyzer(interval_seconds=0.0, interval_events=1)
        graph = _build_graph([("a", "b", 1)])  # no cycle, each node is its own SCC
        result = scc.maybe_run(graph, 1000.0)
        assert result is not None
        assert len(result) == 0  # single-node SCCs filtered out

    def test_reset_clears_counters(self):
        scc = PeriodicSCCAnalyzer(interval_seconds=10.0, interval_events=50)
        scc.last_run_time = 999.0
        scc.events_since_last_run = 40
        scc.reset()
        assert scc.last_run_time == 0.0
        assert scc.events_since_last_run == 0

    def test_scc_fingerprint_has_prefix(self):
        """Bug 5 regression: SCC fingerprints must differ from CycleDetector's."""
        scc = PeriodicSCCAnalyzer(interval_seconds=0.0, interval_events=1)
        graph = _build_graph([("a", "b", 1), ("b", "a", 1)])
        result = scc.maybe_run(graph, 1000.0)
        assert result is not None
        fp = result[0]["fingerprint"]
        assert fp[0] == "scc", "SCC fingerprint must start with 'scc' prefix"


# =======================================================================
# Bug regression tests
# =======================================================================

class TestBugRegressions:

    def test_bug2_global_counter_incremented_on_per_edge_fire(self):
        """Bug 2: Global counter must be incremented even when per-edge fires."""
        limiter = SlidingWindowLimiter(window_size=60.0, per_edge_limit=2, global_limit=100)
        now = 1000.0
        # Fire 3 events — first 2 are fine, 3rd triggers per-edge alert
        limiter.check("a", "b", now)
        limiter.check("a", "b", now + 1)
        alert = limiter.check("a", "b", now + 2)
        assert alert is not None
        # Global counter should have been incremented for all 3 events
        # If the old bug existed, global would only have 2 counts
        assert limiter._global.current_count == 3

    def test_bug3_regression_detects_increased_rotations(self):
        """Bug 3: Regression must fire when rotations increase above previous_rotations."""
        mgr = AlertStateManager(
            warning_threshold=5, critical_threshold=15, resolve_after_seconds=10.0
        )
        # Trigger warning at rotations=5
        mgr.process(("a", "b"), rotations=5, pattern="cycle", now=1000.0)
        # Advance rotations to 8
        mgr.process(("a", "b"), rotations=8, pattern="cycle", now=1001.0)
        # Resolve
        mgr.check_recoveries(1020.0)
        # Regression at rotations=9 — higher than previous_rotations (8)
        # but NOT higher than last_alert_rotations (5). The old dead-code
        # bug meant only last_alert_rotations was checked.
        result = mgr.process(("a", "b"), rotations=9, pattern="cycle", now=1030.0)
        assert result is not None
        assert result.severity == "WARNING"
        assert result.details.get("regression") is True

    def test_bug6_self_loop_ignored(self):
        """Bug 6: Agent delegating to itself should not produce a cycle."""
        graph = _build_graph([("a", "a", 5)])
        detector = CycleDetector()
        result = detector.check(graph, _event("a", "a"))
        assert result is None
