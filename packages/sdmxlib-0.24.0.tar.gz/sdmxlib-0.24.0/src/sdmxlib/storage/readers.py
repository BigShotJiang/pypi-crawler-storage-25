"""Read SDMX domain objects from DuckDB relational tables.

Reconstructs domain objects from the fully relational schema.
No JSON parsing.  Each artefact type has a dedicated reader
that issues SQL queries and constructs the attrs object.

Example::

    from sdmxlib.storage import schema, readers

    conn = duckdb.connect("store.duckdb")
    cl = readers.get_artefact(conn, codelist_urn)  # LazyCodelist
    cm = readers.code_map(conn, codelist_urn, lang="en")  # {code_id: label}
"""

from typing import Any, cast

import duckdb

from sdmxlib.model.annotations import Annotation, Annotations
from sdmxlib.model.binding import DataflowBinding
from sdmxlib.model.category import Categorisation, Category, CategoryScheme
from sdmxlib.model.codelist import Code, Codelist
from sdmxlib.model.collections import ItemList
from sdmxlib.model.concept import Concept, ConceptScheme
from sdmxlib.model.constraint import (
    ConstraintAttachment,
    CubeRegion,
    DataConstraint,
    KeyValue,
)
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.datastructure import (
    AttachmentLevel,
    Attribute,
    DataStructure,
    Dimension,
    Group,
    Measure,
    MeasureDimension,
    TimeDimension,
)
from sdmxlib.model.hierarchy import HierarchicalCode, Hierarchy, Level
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.mapping import CodelistMap, CodeMap, StructureSet
from sdmxlib.model.metadataflow import Metadataflow
from sdmxlib.model.metadataset import (
    MetadataSet,
    ReportedAttribute,
    ReportedAttributeValue,
)
from sdmxlib.model.metadatastructure import MetadataAttribute, MetadataStructure
from sdmxlib.model.organisation import (
    Agency,
    AgencyScheme,
    Contact,
    DataProvider,
    DataProviderScheme,
)
from sdmxlib.model.provision import ProvisionAgreement
from sdmxlib.model.ref import Ref
from sdmxlib.model.representation import Facet
from sdmxlib.model.urn import SdmxUrn
from sdmxlib.storage.writers import _CLASS_TO_NAME

# Reverse map: type_name -> Python class
_TYPE_REGISTRY: dict[str, type] = {v: k for k, v in _CLASS_TO_NAME.items()}


# ── Shared helpers ──────────────────────────────────────────────────────


def _map_to_istring(m: dict[str, str] | None) -> InternationalString:
    """Convert a DuckDB MAP result to InternationalString."""
    if not m:
        return InternationalString()
    return InternationalString.of(m)


def _read_istring(
    conn: duckdb.DuckDBPyConnection,
    owner_urn: str,
    field: str,
) -> InternationalString:
    """Read an InternationalString from localized_text."""
    rows = conn.execute(
        """
        SELECT lang, text FROM localized_text
        WHERE owner_urn = ? AND field = ?
        """,
        [owner_urn, field],
    ).fetchall()
    if not rows:
        return InternationalString()
    return InternationalString.of(dict(rows))


def _read_annotations(
    conn: duckdb.DuckDBPyConnection,
    owner_urn: str,
) -> Annotations:
    """Read annotations and their text for any annotated entity."""
    rows = conn.execute(
        """
        SELECT id, annotation_id, title, annotation_type, url
        FROM annotation
        WHERE owner_urn = ?
        ORDER BY ordinal
        """,
        [owner_urn],
    ).fetchall()
    if not rows:
        return Annotations()
    result: list[Annotation] = []
    for row in rows:
        db_id, ann_id, title, ann_type, url = row
        text_rows = conn.execute(
            "SELECT lang, text FROM annotation_text WHERE annotation_id = ?",
            [db_id],
        ).fetchall()
        text = InternationalString.of(dict(text_rows)) if text_rows else InternationalString()
        result.append(Annotation(id=ann_id, title=title, type=ann_type, url=url, text=text))
    return Annotations(result)


def _read_spine(conn: duckdb.DuckDBPyConnection, urn: str) -> dict[str, Any] | None:
    """Read artefact metadata from the spine table."""
    row = conn.execute(
        """
        SELECT artefact_type, agency_id, resource_id, version, is_final,
               valid_from, valid_to
        FROM artefact WHERE urn = ?
        """,
        [urn],
    ).fetchone()
    if row is None:
        return None
    return {
        "artefact_type": row[0],
        "agency_id": row[1],
        "resource_id": row[2],
        "version": row[3],
        "is_final": row[4],
        "valid_from": row[5],
        "valid_to": row[6],
    }


# ── Per-type readers ────────────────────────────────────────────────────


def _read_codelist_eager(conn: duckdb.DuckDBPyConnection, urn: str) -> Codelist | None:
    """Read a full Codelist with all codes materialized."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    rows = conn.execute(
        """
        SELECT code_urn, code_id, parent_id, name, description
        FROM code WHERE codelist_urn = ?
        ORDER BY position
        """,
        [urn],
    ).fetchall()

    codes: list[Code] = []
    for row in rows:
        code_urn, code_id, parent_id, name_map, desc_map = row
        code_anns = _read_annotations(conn, code_urn)
        codes.append(
            Code(
                id=code_id,
                parent_id=parent_id,
                name=_map_to_istring(name_map),
                description=_map_to_istring(desc_map),
                annotations=code_anns,
            )
        )

    return Codelist(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        annotations=anns,
        codes=codes,
    )


def _to_float(v: Any) -> float | None:
    """Convert a DB value to float, returning None if absent."""
    return float(v) if v is not None else None


def _build_representation(
    repr_kind: str | None,
    codelist_urn: str | None,
    text_type: str | None,
    min_length: int | None,
    max_length: int | None,
    min_value: str | None,
    max_value: str | None,
    decimals: int | None,
    pattern: str | None,
    is_sequence: bool | None,
    start_value: str | None,
    end_value: str | None,
) -> Any:
    """Build a representation (Ref[Codelist] or Facet) from component row fields."""
    if repr_kind == "enumeration" and codelist_urn:
        return Ref[Codelist].unresolved(SdmxUrn.parse(codelist_urn))
    if repr_kind == "facet":
        return Facet(
            type=text_type,
            min_length=min_length,
            max_length=max_length,
            min_value=_to_float(min_value),
            max_value=_to_float(max_value),
            decimals=decimals,
            pattern=pattern,
            is_sequence=is_sequence,
            start_value=_to_float(start_value),
            end_value=_to_float(end_value),
        )
    return None


def _component_urn(dsd_urn: str, comp_type: str, comp_id: str) -> str:
    """Synthetic URN for a DSD component (mirrors writers._make_item_urn)."""
    parsed = SdmxUrn.parse(dsd_urn)
    return str(
        SdmxUrn.make(
            DataStructure,
            package=parsed.package,
            artefact_class=comp_type,
            agency=parsed.agency,
            id=parsed.id,
            version=parsed.version,
            item_id=comp_id,
        )
    )


def _deserialize_component(row: tuple[Any, ...], annotations: Annotations) -> tuple[str, Any]:
    """Deserialize a dsd_component row into (comp_type, component_object)."""
    (
        comp_id,
        comp_type,
        _position,
        concept_urn_str,
        repr_kind,
        codelist_urn,
        text_type,
        min_length,
        max_length,
        min_value,
        max_value,
        decimals,
        pattern,
        is_sequence,
        start_value,
        end_value,
        usage_status,
        attachment_level,
        _attachment_group,
        _measure_usage,
    ) = row

    concept_ref = Ref[Concept].unresolved(SdmxUrn.parse(concept_urn_str)) if concept_urn_str else None
    representation = _build_representation(
        repr_kind,
        codelist_urn,
        text_type,
        min_length,
        max_length,
        min_value,
        max_value,
        decimals,
        pattern,
        is_sequence,
        start_value,
        end_value,
    )

    match comp_type:
        case "TimeDimension":
            return comp_type, TimeDimension(
                id=comp_id,
                concept=concept_ref,
                representation=representation if isinstance(representation, Facet) else None,
                annotations=annotations,
            )
        case "MeasureDimension":
            return comp_type, MeasureDimension(
                id=comp_id,
                concept=concept_ref,
                representation=representation,
                annotations=annotations,
            )
        case "Attribute":
            attachment = AttachmentLevel(attachment_level) if attachment_level else None
            return comp_type, Attribute(
                id=comp_id,
                concept=concept_ref,
                representation=representation,
                usage=usage_status,
                attachment=attachment,
                annotations=annotations,
            )
        case "Measure":
            return comp_type, Measure(
                id=comp_id,
                concept=concept_ref,
                representation=representation,
                annotations=annotations,
            )
        case _:
            return "Dimension", Dimension(
                id=comp_id,
                concept=concept_ref,
                representation=representation,
                annotations=annotations,
            )


def _read_groups(conn: duckdb.DuckDBPyConnection, urn: str) -> list[Group]:
    """Read DSD groups and their dimension memberships."""
    group_rows = conn.execute(
        "SELECT group_id FROM dsd_group WHERE dsd_urn = ?",
        [urn],
    ).fetchall()
    groups: list[Group] = []
    for (group_id,) in group_rows:
        dim_rows = conn.execute(
            "SELECT dimension_id FROM group_dimension WHERE dsd_urn = ? AND group_id = ?",
            [urn, group_id],
        ).fetchall()
        groups.append(Group(id=group_id, dimension_ids=[r[0] for r in dim_rows]))
    return groups


def _read_data_structure(conn: duckdb.DuckDBPyConnection, urn: str) -> DataStructure | None:
    """Read a DataStructure from dsd_component rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    comp_rows = conn.execute(
        """
        SELECT component_id, component_type, position, concept_urn,
               repr_kind, codelist_urn, text_type, min_length, max_length,
               min_value, max_value, decimals, pattern, is_sequence,
               start_value, end_value,
               usage_status, attachment_level, attachment_group,
               measure_usage
        FROM dsd_component
        WHERE dsd_urn = ?
        ORDER BY position
        """,
        [urn],
    ).fetchall()

    dimensions: list[Dimension] = []
    time_dim: TimeDimension | None = None
    measure_dim: MeasureDimension | None = None
    attributes: list[Attribute] = []
    measures: list[Measure] = []

    for row in comp_rows:
        comp_id_raw, comp_type_raw = row[0], row[1]
        # "Dimension" is the default fallback in _deserialize_component, so any
        # unknown row falls back to that path — match it here for the URN too.
        urn_class = (
            comp_type_raw
            if comp_type_raw
            in {
                "TimeDimension",
                "MeasureDimension",
                "Attribute",
                "Measure",
            }
            else "Dimension"
        )
        comp_anns = _read_annotations(conn, _component_urn(urn, urn_class, comp_id_raw))
        comp_type, comp = _deserialize_component(row, comp_anns)
        match comp_type:
            case "Dimension":
                dimensions.append(comp)
            case "TimeDimension":
                time_dim = comp
            case "MeasureDimension":
                measure_dim = comp
            case "Attribute":
                attributes.append(comp)
            case "Measure":
                measures.append(comp)

    groups = _read_groups(conn, urn)

    return DataStructure(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        annotations=anns,
        dimensions=dimensions,
        time_dimension=time_dim,
        measure_dimension=measure_dim,
        attributes=attributes,
        measures=measures,
        groups=groups or None,
    )


def _read_dataflow(conn: duckdb.DuckDBPyConnection, urn: str) -> Dataflow | None:
    """Read a Dataflow from spine + dataflow extension."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    row = conn.execute("SELECT dsd_urn FROM dataflow WHERE urn = ?", [urn]).fetchone()
    structure_ref = None
    if row and row[0]:
        structure_ref = Ref[DataStructure].unresolved(SdmxUrn.parse(row[0]))

    return Dataflow(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        annotations=anns,
        structure=structure_ref,
    )


def _read_concept_scheme(conn: duckdb.DuckDBPyConnection, urn: str) -> ConceptScheme | None:
    """Read a ConceptScheme from spine + concept rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    rows = conn.execute(
        """
        SELECT concept_urn, concept_id, name, description,
               repr_kind, repr_codelist_urn, repr_text_type,
               repr_min_length, repr_max_length
        FROM concept WHERE scheme_urn = ?
        ORDER BY position
        """,
        [urn],
    ).fetchall()

    concepts: list[Concept] = []
    for row in rows:
        (c_urn, c_id, c_name, c_desc, repr_kind, repr_cl_urn, repr_text_type, repr_min_length, repr_max_length) = row

        core_repr = None
        if repr_kind == "enumeration" and repr_cl_urn:
            core_repr = Ref[Codelist].unresolved(SdmxUrn.parse(repr_cl_urn))
        elif repr_kind == "facet":
            core_repr = Facet(
                type=repr_text_type,
                min_length=repr_min_length,
                max_length=repr_max_length,
            )

        c_anns = _read_annotations(conn, c_urn)
        concepts.append(
            Concept(
                id=c_id,
                name=_map_to_istring(c_name),
                description=_map_to_istring(c_desc),
                core_representation=core_repr,
                annotations=c_anns,
            )
        )

    return ConceptScheme(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        annotations=anns,
        concepts=concepts,
    )


def _read_hierarchy(conn: duckdb.DuckDBPyConnection, urn: str) -> "Hierarchy | None":
    """Read a Hierarchy from spine + hierarchy_node rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    # SDMX 3.1: read Level definitions
    level_rows = conn.execute(
        """
        SELECT level_id, name, description
        FROM hierarchy_level WHERE hierarchy_urn = ?
        ORDER BY level_idx
        """,
        [urn],
    ).fetchall()
    levels: list[Level] = []
    levels_by_id: dict[str, Level] = {}
    for lv_row in level_rows:
        lv_id, lv_name, lv_desc = lv_row
        lv = Level(
            id=lv_id,
            name=_map_to_istring(lv_name),
            description=_map_to_istring(lv_desc),
        )
        levels.append(lv)
        levels_by_id[lv_id] = lv

    rows = conn.execute(
        """
        SELECT node_urn, node_id, parent_node_id, code_urn, level_id,
               name, description, valid_from, valid_to
        FROM hierarchy_node WHERE hierarchy_urn = ?
        """,
        [urn],
    ).fetchall()

    nodes_by_id: dict[str, HierarchicalCode] = {}
    children_map: dict[str | None, list[str]] = {}

    for row in rows:
        node_urn, node_id, parent_id, code_urn_str, level_id, n_name, n_desc, vf, vt = row
        code_ref = None
        if code_urn_str:
            code_ref = Ref[Code].unresolved(SdmxUrn.parse(code_urn_str))

        level: Level | None = None
        if level_id and level_id in levels_by_id:
            level = levels_by_id[level_id]

        node_anns = _read_annotations(conn, node_urn)
        node = HierarchicalCode(
            id=node_id,
            code=code_ref,
            name=_map_to_istring(n_name),
            description=_map_to_istring(n_desc),
            children=[],
            annotations=node_anns,
            valid_from=vf,
            valid_to=vt,
            level=level,
        )
        nodes_by_id[node_id] = node
        children_map.setdefault(parent_id, []).append(node_id)

    # Build tree
    for parent_id, child_ids in children_map.items():
        if parent_id is not None and parent_id in nodes_by_id:
            parent = nodes_by_id[parent_id]
            parent.children = ItemList([nodes_by_id[cid] for cid in child_ids])

    root_ids = children_map.get(None, [])
    tree = ItemList([nodes_by_id[rid] for rid in root_ids])

    return Hierarchy(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        annotations=anns,
        levels=levels,
        tree=tree,
    )


def _read_data_constraint(conn: duckdb.DuckDBPyConnection, urn: str) -> "DataConstraint | None":
    """Read a DataConstraint from relational tables."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    cc_row = conn.execute("SELECT constraint_type FROM data_constraint WHERE urn = ?", [urn]).fetchone()
    constraint_type = cc_row[0] if cc_row else "Allowed"

    # Attachment from artefact_ref
    ref_rows = conn.execute(
        "SELECT target_urn, role FROM artefact_ref WHERE source_urn = ?",
        [urn],
    ).fetchall()
    df_ref = None
    dsd_ref = None
    pa_ref = None
    for target_urn, role in ref_rows:
        parsed = SdmxUrn.parse(target_urn)
        match role:
            case "attachment_dataflow":
                df_ref = Ref[Dataflow].unresolved(parsed)
            case "attachment_dsd":
                dsd_ref = Ref[DataStructure].unresolved(parsed)
            case "attachment_provision":
                pa_ref = Ref[ProvisionAgreement].unresolved(parsed)

    attachment = ConstraintAttachment(
        dataflow=df_ref,
        data_structure=dsd_ref,
        provision_agreement=pa_ref,
    )

    # Regions
    region_rows = conn.execute(
        "SELECT region_idx, is_included FROM cube_region WHERE constraint_urn = ? ORDER BY region_idx",
        [urn],
    ).fetchall()
    regions: list[CubeRegion] = []
    for region_idx, is_included in region_rows:
        kv_rows = conn.execute(
            """
            SELECT component_id, value FROM region_key_value
            WHERE constraint_urn = ? AND region_idx = ?
            """,
            [urn, region_idx],
        ).fetchall()
        keys_map: dict[str, set[str]] = {}
        for comp_id, val in kv_rows:
            keys_map.setdefault(comp_id, set()).add(val)
        keys = tuple(KeyValue(dimension_id=k, values=frozenset(v)) for k, v in keys_map.items())
        regions.append(CubeRegion(include=is_included, keys=keys))

    return DataConstraint(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        constraint_type=constraint_type,
        attachment=attachment,
        regions=tuple(regions),
        annotations=anns,
    )


def _read_category_scheme(conn: duckdb.DuckDBPyConnection, urn: str) -> "CategoryScheme | None":
    """Read a CategoryScheme from spine + category rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    rows = conn.execute(
        """
        SELECT category_urn, category_id, parent_id, name, description
        FROM category WHERE scheme_urn = ?
        ORDER BY position
        """,
        [urn],
    ).fetchall()

    cats_by_id: dict[str, Category] = {}
    children_map: dict[str | None, list[str]] = {}

    for row in rows:
        cat_urn, cat_id, parent_id, c_name, c_desc = row
        cat_anns = _read_annotations(conn, cat_urn)
        cat = Category(
            id=cat_id,
            name=_map_to_istring(c_name),
            description=_map_to_istring(c_desc),
            categories=[],
            annotations=cat_anns,
        )
        cats_by_id[cat_id] = cat
        children_map.setdefault(parent_id, []).append(cat_id)

    for parent_id, child_ids in children_map.items():
        if parent_id is not None and parent_id in cats_by_id:
            cats_by_id[parent_id].categories = ItemList([cats_by_id[cid] for cid in child_ids])

    root_ids = children_map.get(None, [])
    root_categories = ItemList([cats_by_id[rid] for rid in root_ids])

    return CategoryScheme(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        categories=root_categories,
        annotations=anns,
    )


def _read_categorisation(conn: duckdb.DuckDBPyConnection, urn: str) -> "Categorisation | None":
    """Read a Categorisation from spine + extension."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    row = conn.execute("SELECT source_urn, target_urn FROM categorisation WHERE urn = ?", [urn]).fetchone()
    source_ref = Ref[object].unresolved(SdmxUrn.parse(row[0])) if row and row[0] else None
    target_ref = Ref[object].unresolved(SdmxUrn.parse(row[1])) if row and row[1] else None

    return Categorisation(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        annotations=anns,
        source=source_ref,
        target=target_ref,
    )


def _read_provision_agreement(conn: duckdb.DuckDBPyConnection, urn: str) -> "ProvisionAgreement | None":
    """Read a ProvisionAgreement from spine + extension."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    row = conn.execute(
        "SELECT dataflow_urn, data_provider_urn FROM provision_agreement WHERE urn = ?", [urn]
    ).fetchone()
    df_ref = Ref[Dataflow].unresolved(SdmxUrn.parse(row[0])) if row and row[0] else None
    dp_ref = Ref[object].unresolved(SdmxUrn.parse(row[1])) if row and row[1] else None

    return ProvisionAgreement(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        annotations=anns,
        dataflow=df_ref,
        data_provider=dp_ref,
    )


def _read_agency_scheme(conn: duckdb.DuckDBPyConnection, urn: str) -> "AgencyScheme | None":
    """Read an AgencyScheme from spine + agency + agency_contact."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    rows = conn.execute(
        "SELECT agency_urn, agency_id, parent_id, name, description FROM agency WHERE scheme_urn = ?",
        [urn],
    ).fetchall()

    agencies: list[Agency] = []
    for row in rows:
        ag_urn, ag_id, _parent_id, ag_name, ag_desc = row
        # Contacts
        contact_rows = conn.execute(
            """
            SELECT contact_name, department, role, phones, uris, emails
            FROM agency_contact WHERE agency_urn = ?
            ORDER BY ordinal
            """,
            [ag_urn],
        ).fetchall()
        contacts = [
            Contact(
                name=_map_to_istring(cr[0]),
                department=_map_to_istring(cr[1]),
                role=_map_to_istring(cr[2]),
                phones=tuple(cr[3] or []),
                uris=tuple(cr[4] or []),
                emails=tuple(cr[5] or []),
            )
            for cr in contact_rows
        ]

        ag_anns = _read_annotations(conn, ag_urn)
        agencies.append(
            Agency(
                id=ag_id,
                name=_map_to_istring(ag_name),
                description=_map_to_istring(ag_desc),
                contacts=tuple(contacts),
                annotations=ag_anns,
            )
        )

    return AgencyScheme(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        agencies=agencies,
        annotations=anns,
    )


def _read_data_provider_scheme(conn: duckdb.DuckDBPyConnection, urn: str) -> "DataProviderScheme | None":
    """Read a DataProviderScheme from spine + data_provider rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    rows = conn.execute(
        "SELECT provider_urn, provider_id, name, description FROM data_provider WHERE scheme_urn = ?",
        [urn],
    ).fetchall()

    providers: list[DataProvider] = []
    for row in rows:
        p_urn, p_id, p_name, p_desc = row
        p_anns = _read_annotations(conn, p_urn)
        providers.append(
            DataProvider(
                id=p_id,
                name=_map_to_istring(p_name),
                description=_map_to_istring(p_desc),
                annotations=p_anns,
            )
        )

    return DataProviderScheme(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        providers=providers,
        annotations=anns,
    )


def _read_structure_set(conn: duckdb.DuckDBPyConnection, urn: str) -> "StructureSet | None":
    """Read a StructureSet from spine + codelist_map + code_map_entry."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    map_rows = conn.execute(
        "SELECT id, source_codelist_urn, target_codelist_urn FROM codelist_map WHERE structure_set_urn = ?",
        [urn],
    ).fetchall()

    cl_maps: list[CodelistMap] = []
    for map_id, src_cl_urn, tgt_cl_urn in map_rows:
        source_ref = Ref[Codelist].unresolved(SdmxUrn.parse(src_cl_urn)) if src_cl_urn else None
        target_ref = Ref[Codelist].unresolved(SdmxUrn.parse(tgt_cl_urn)) if tgt_cl_urn else None

        entry_rows = conn.execute(
            """
            SELECT source_code_id, target_code_id FROM code_map_entry
            WHERE structure_set_urn = ? AND map_id = ?
            """,
            [urn, map_id],
        ).fetchall()
        maps = tuple(CodeMap(source_id=s, target_id=t) for s, t in entry_rows)

        cl_maps.append(
            CodelistMap(
                id=map_id,
                source=source_ref,
                target=target_ref,
                maps=maps,
            )
        )

    return StructureSet(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        codelist_maps=tuple(cl_maps),
        annotations=anns,
    )


# ── MetadataStructure / MetadataSet readers ────────────────────────────


def _read_metadata_structure(conn: duckdb.DuckDBPyConnection, urn: str) -> "MetadataStructure | None":
    """Read a MetadataStructure from spine + metadata_attribute rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    rows = conn.execute(
        """
        SELECT attribute_urn, attribute_id, parent_attribute_id, position,
               concept_urn, repr_kind, codelist_urn, text_type,
               min_length, max_length, min_value, max_value,
               decimals, pattern, is_sequence, start_value, end_value,
               min_occurs, max_occurs, is_presentational
        FROM metadata_attribute
        WHERE msd_urn = ?
        ORDER BY position
        """,
        [urn],
    ).fetchall()

    nodes_by_id: dict[str, MetadataAttribute] = {}
    children_map: dict[str | None, list[str]] = {}

    for row in rows:
        (
            attr_urn,
            attr_id,
            parent_id,
            _position,
            concept_urn_str,
            repr_kind,
            codelist_urn,
            text_type,
            min_length,
            max_length,
            min_value,
            max_value,
            decimals,
            pattern,
            is_sequence,
            start_value,
            end_value,
            min_occurs,
            max_occurs,
            is_presentational,
        ) = row

        concept_ref = Ref[Concept].unresolved(SdmxUrn.parse(concept_urn_str)) if concept_urn_str else None
        representation = _build_representation(
            repr_kind,
            codelist_urn,
            text_type,
            min_length,
            max_length,
            min_value,
            max_value,
            decimals,
            pattern,
            is_sequence,
            start_value,
            end_value,
        )
        attr_anns = _read_annotations(conn, attr_urn)

        node = MetadataAttribute(
            id=attr_id,
            concept=concept_ref,
            representation=representation,
            min_occurs=min_occurs,
            max_occurs=max_occurs,
            is_presentational=is_presentational,
            annotations=attr_anns,
        )
        nodes_by_id[attr_id] = node
        children_map.setdefault(parent_id, []).append(attr_id)

    for parent_id, child_ids in children_map.items():
        if parent_id is not None and parent_id in nodes_by_id:
            nodes_by_id[parent_id].children = ItemList([nodes_by_id[cid] for cid in child_ids])

    root_ids = children_map.get(None, [])
    attributes = ItemList([nodes_by_id[rid] for rid in root_ids])

    return MetadataStructure(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        annotations=anns,
        attributes=attributes,
    )


def _build_reported_value(
    value_kind: str | None,
    scalar: str | None,
    i18n: dict[str, str] | None,
) -> ReportedAttributeValue | None:
    """Reconstruct one ReportedAttribute.value from its row fields."""
    if value_kind is None:
        return None
    if value_kind == "i18n":
        return _map_to_istring(i18n)
    return scalar


def _strip_sibling_index(segment: str) -> tuple[str, int]:
    """Split a path segment ``id`` or ``id[N]`` into (id, sibling_index)."""
    if segment.endswith("]") and "[" in segment:
        bare, _, rest = segment.rpartition("[")
        return bare, int(rest[:-1])
    return segment, 0


def _build_reported_tree(
    rows: list[tuple[str, int, str | None, str | None, dict[str, str] | None]],
) -> ItemList[ReportedAttribute]:
    """Reconstruct a ReportedAttribute tree from metadata_value rows.

    Rows are ``(attribute_path, sibling_index, value_kind, scalar, i18n)``.
    Paths are dot-joined attribute ids; repeated siblings carry an
    ``[N]`` suffix on the segment, e.g. ``"QUALITY.NOTE[1]"``.
    """
    # Materialise nodes by full path (with [N] suffixes) so the tree structure
    # is unambiguous even with sibling repetition.
    nodes: dict[str, ReportedAttribute] = {}
    # Order roots and child appends by first-seen path.
    seen_paths: list[str] = []

    def ensure_node(path: str) -> ReportedAttribute:
        if path in nodes:
            return nodes[path]
        leaf_segment = path.rsplit(".", 1)[-1]
        leaf_id, _ = _strip_sibling_index(leaf_segment)
        node = ReportedAttribute(id=leaf_id)
        nodes[path] = node
        seen_paths.append(path)
        return node

    # Walk every prefix so presentational ancestors materialise too.
    all_paths: set[str] = set()
    for path, _idx, _kind, _scalar, _i18n in rows:
        parts = path.split(".")
        for depth in range(1, len(parts) + 1):
            all_paths.add(".".join(parts[:depth]))

    for path in sorted(all_paths, key=lambda p: (p.count("."), p)):
        ensure_node(path)
        if "." in path:
            parent_path, _ = path.rsplit(".", 1)
            parent = nodes[parent_path]
            if not any(c is nodes[path] for c in parent.children):
                parent.children = ItemList([*parent.children, nodes[path]])

    for path, _idx, kind, scalar, i18n in rows:
        node = nodes[path]
        node.value = _build_reported_value(kind, scalar, i18n)

    roots = [node for path, node in nodes.items() if "." not in path]
    return ItemList(roots)


def _read_metadataflow(conn: duckdb.DuckDBPyConnection, urn: str) -> "Metadataflow | None":
    """Read a Metadataflow from spine + metadataflow extension."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    row = conn.execute("SELECT msd_urn FROM metadataflow WHERE urn = ?", [urn]).fetchone()
    structure_ref = None
    if row and row[0]:
        structure_ref = Ref[MetadataStructure].unresolved(SdmxUrn.parse(row[0]))

    return Metadataflow(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        annotations=anns,
        structure=structure_ref,
    )


def _read_metadata_set(conn: duckdb.DuckDBPyConnection, urn: str) -> "MetadataSet | None":
    """Read a MetadataSet from spine + metadata_set + targets + values."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")
    anns = _read_annotations(conn, urn)

    set_row = conn.execute("SELECT structure_urn, structure_kind FROM metadata_set WHERE urn = ?", [urn]).fetchone()
    if set_row is None:
        return None
    structure_urn, structure_kind = set_row
    parsed_structure_urn = SdmxUrn.parse(structure_urn)
    structure_ref: Ref[MetadataStructure] | Ref[Metadataflow] = (
        Ref[Metadataflow].unresolved(cast("SdmxUrn[Metadataflow]", parsed_structure_urn))
        if structure_kind == "Metadataflow"
        else Ref[MetadataStructure].unresolved(cast("SdmxUrn[MetadataStructure]", parsed_structure_urn))
    )

    target_rows = conn.execute(
        """
        SELECT target_urn FROM metadata_target
        WHERE set_urn = ?
        ORDER BY ordinal
        """,
        [urn],
    ).fetchall()
    targets = [Ref[Any].unresolved(SdmxUrn.parse(t[0])) for t in target_rows]

    value_rows = conn.execute(
        """
        SELECT attribute_path, sibling_index, value_kind, scalar, i18n
        FROM metadata_value
        WHERE set_urn = ?
        """,
        [urn],
    ).fetchall()
    attributes = _build_reported_tree(value_rows)

    return MetadataSet(
        id=meta["resource_id"],
        maintainer=Agency(id=meta["agency_id"]),
        structure=structure_ref,
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        annotations=anns,
        targets=targets,
        attributes=attributes,
    )


# ── DataflowBinding reader ──────────────────────────────────────────────


def _read_dataflow_binding(conn: duckdb.DuckDBPyConnection, urn: str) -> DataflowBinding | None:
    """Read a DataflowBinding from spine + dataflow_binding rows."""
    meta = _read_spine(conn, urn)
    if meta is None:
        return None

    row = conn.execute(
        """
        SELECT dataflow_urn, table_location, partition_layout,
               dimension_column_map, measure_column_map, attribute_column_map,
               structural_version, binding_source_registry,
               materialized_at, bound_at, series_attributes_location
        FROM dataflow_binding WHERE urn = ?
        """,
        [urn],
    ).fetchone()
    if row is None:
        return None

    (
        dataflow_urn_str,
        table_location,
        partition_layout,
        dim_map,
        meas_map,
        attr_map,
        structural_version,
        binding_source_registry,
        materialized_at,
        bound_at,
        series_attributes_location,
    ) = row

    return DataflowBinding(
        dataflow=Ref[Dataflow].unresolved(SdmxUrn.parse(dataflow_urn_str)),
        table_location=table_location,
        partition_layout=tuple(partition_layout or ()),
        dimension_column_map=dict(dim_map or {}),
        measure_column_map=dict(meas_map or {}),
        attribute_column_map=dict(attr_map or {}),
        structural_version=structural_version,
        source_registry=binding_source_registry,
        materialized_at=materialized_at,
        bound_at=bound_at,
        series_attributes_location=series_attributes_location,
    )


# ── Public API ──────────────────────────────────────────────────────────

_READER_DISPATCH: dict[str, Any] = {
    "Codelist": _read_codelist_eager,
    "DataStructure": _read_data_structure,
    "Dataflow": _read_dataflow,
    "ConceptScheme": _read_concept_scheme,
    "Hierarchy": _read_hierarchy,
    "DataConstraint": _read_data_constraint,
    "CategoryScheme": _read_category_scheme,
    "Categorisation": _read_categorisation,
    "ProvisionAgreement": _read_provision_agreement,
    "AgencyScheme": _read_agency_scheme,
    "DataProviderScheme": _read_data_provider_scheme,
    "StructureSet": _read_structure_set,
    "MetadataStructure": _read_metadata_structure,
    "Metadataflow": _read_metadataflow,
    "MetadataSet": _read_metadata_set,
    "DataflowBinding": _read_dataflow_binding,
}


def get_artefact(
    conn: duckdb.DuckDBPyConnection,
    urn: str,
    *,
    eager: bool = False,
) -> Any | None:
    """Look up an artefact by URN string.

    For Codelists, returns a ``LazyCodelist`` by default. Pass
    ``eager=True`` to get a real ``Codelist`` with all codes loaded.

    Returns ``None`` if the URN is not in the store.
    """
    row = conn.execute(
        "SELECT artefact_type FROM artefact WHERE urn = ?",
        [urn],
    ).fetchone()
    if row is None:
        return None

    artefact_type = row[0]

    if artefact_type == "Codelist" and not eager:
        return make_lazy_codelist(conn, urn)
    if artefact_type == "Hierarchy" and not eager:
        return make_lazy_hierarchy(conn, urn)

    reader = _READER_DISPATCH.get(artefact_type)
    return reader(conn, urn) if reader is not None else None


def get_all(
    conn: duckdb.DuckDBPyConnection,
    artefact_type: type,
    *,
    eager: bool = False,
) -> list[Any]:
    """Return all artefacts of a given type."""
    type_name = _CLASS_TO_NAME.get(artefact_type)
    if type_name is None:
        return []

    rows = conn.execute(
        "SELECT urn FROM artefact WHERE artefact_type = ?",
        [type_name],
    ).fetchall()

    return [obj for (urn_str,) in rows if (obj := get_artefact(conn, urn_str, eager=eager)) is not None]


# ── LazyCodelist construction ───────────────────────────────────────────


def make_lazy_codelist(conn: duckdb.DuckDBPyConnection, urn: str) -> Any:
    """Construct a LazyCodelist from spine + localized_text."""
    from sdmxlib.storage.lazy import LazyCodelist  # noqa: PLC0415

    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")

    return LazyCodelist(
        urn=urn,
        conn=conn,
        id=meta["resource_id"],
        agency=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
    )


def make_lazy_hierarchy(conn: duckdb.DuckDBPyConnection, urn: str) -> Any:
    """Construct a LazyHierarchy from spine + localized_text + hierarchy_meta + levels.

    No flattening, no node materialisation, no Ref resolution. Returns
    ``None`` when the spine row is absent.
    """
    from sdmxlib.model.hierarchy import Level  # noqa: PLC0415
    from sdmxlib.storage.lazy import LazyHierarchy  # noqa: PLC0415

    meta = _read_spine(conn, urn)
    if meta is None:
        return None
    name = _read_istring(conn, urn, "name")
    desc = _read_istring(conn, urn, "description")

    is_leveled_row = conn.execute(
        "SELECT is_leveled FROM hierarchy_meta WHERE urn = ?",
        [urn],
    ).fetchone()
    is_leveled = bool(is_leveled_row[0]) if is_leveled_row is not None else False

    level_rows = conn.execute(
        """
        SELECT level_id, name, description
        FROM hierarchy_level
        WHERE hierarchy_urn = ?
        ORDER BY level_idx
        """,
        [urn],
    ).fetchall()
    levels = tuple(
        Level(id=str(r[0]), name=_map_to_istring(r[1]), description=_map_to_istring(r[2])) for r in level_rows
    )

    return LazyHierarchy(
        urn=urn,
        conn=conn,
        id=meta["resource_id"],
        agency=Agency(id=meta["agency_id"]),
        version=meta["version"],
        name=name,
        description=desc,
        is_final=meta["is_final"],
        is_leveled=is_leveled,
        levels=levels,
    )


# ── Direct SQL helpers ──────────────────────────────────────────────────


def code_map(
    conn: duckdb.DuckDBPyConnection,
    codelist_urn: str,
    *,
    lang: str,
) -> dict[str, str]:
    """Return ``{code_id: label}`` for a codelist via direct SQL.

    Uses MAP column subscript — works for any language without
    upfront configuration.
    """
    rows = conn.execute(
        f"""
        SELECT code_id, name['{lang}'] AS label
        FROM code
        WHERE codelist_urn = ?
        ORDER BY position
        """,
        [codelist_urn],
    ).fetchall()
    return {r[0]: r[1] for r in rows if r[1] is not None}


def code_map_for_dsd(
    conn: duckdb.DuckDBPyConnection,
    dsd_urn: str,
    *,
    lang: str,
) -> dict[str, dict[str, str]]:
    """Return ``{component_id: {code_id: label}}`` for all enumerated components.

    Single JOIN query — no N+1.
    """
    rows = conn.execute(
        f"""
        SELECT dc.component_id, c.code_id, c.name['{lang}'] AS label
        FROM dsd_component dc
        JOIN code c ON dc.codelist_urn = c.codelist_urn
        WHERE dc.dsd_urn = ?
          AND dc.codelist_urn IS NOT NULL
        ORDER BY dc.component_id, c.position
        """,
        [dsd_urn],
    ).fetchall()

    result: dict[str, dict[str, str]] = {}
    for comp_id, code_id, label in rows:
        if label is not None:
            result.setdefault(comp_id, {})[code_id] = label
    return result
