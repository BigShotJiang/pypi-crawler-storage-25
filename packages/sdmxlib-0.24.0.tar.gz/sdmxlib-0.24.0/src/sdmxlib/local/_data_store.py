"""DuckDBDataStore — DuckDB-backed implementation of :class:`DataStore`.

Path-style: ``DuckDBDataStore(uri)`` is a cheap value object; the DuckDB
connection opens on ``open()`` / ``__enter__`` and closes on exit.

For the common case where a :class:`~sdmxlib.local.Registry` and the
data store share a single DuckDB session (so SQL can join SDMX codelists
to observation rows without cross-connection plumbing), use the
:meth:`from_registry` classmethod.

External catalogs (DuckLake, raw Parquet, S3 via httpfs) can be
``ATTACH``-ed at open time so cross-database joins work without
file-handle juggling.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Self

import duckdb
import polars as pl

from sdmxlib.model.binding import DataflowBinding

if TYPE_CHECKING:
    import pyarrow as pa

    from sdmxlib.local._registry import Registry
    from sdmxlib.rest import ComponentFilter


class DuckDBDataStore:
    """A :class:`~sdmxlib.data_store.DataStore` backed by DuckDB.

    Two construction paths:

    1. ``DuckDBDataStore(uri)`` — Path-style. Opens its own DuckDB
       connection at ``open()`` / ``__enter__`` time. Use when the data
       store stands alone (no registry sharing).
    2. ``DuckDBDataStore.from_registry(reg, attach=, extensions=)`` —
       reuses a :class:`Registry`'s connection so the SDMX structural
       side and the observation side share a single DuckDB session.
       Lazy codelists keep working across queries, and queries can join
       across the two without cross-connection plumbing.

    The ``attach`` / ``extensions`` knobs configure the DuckDB session
    at open time. ``attach`` maps ``alias → ATTACH spec`` (each executed
    as ``ATTACH <spec> AS <alias>``); ``extensions`` INSTALL+LOAD the
    listed extensions before any ATTACH.

    Example::

        with sl.Registry("sdmx.duckdb") as reg:
            store = sl.DuckDBDataStore.from_registry(
                reg,
                attach={"lake": "ducklake:'catalog.duckdb' (READ_ONLY)"},
                extensions=["ducklake"],
            )
            df = store.query(binding, where=["REF_AREA = ?"], params=["CA"])
    """

    def __init__(
        self,
        uri: str | Path,
        *,
        attach: dict[str, str] | None = None,
        extensions: list[str] | None = None,
    ) -> None:
        self._uri: Path = Path(uri) if isinstance(uri, str) else uri
        self._attach = attach
        self._extensions = extensions
        self._registry: Registry | None = None
        self._conn: duckdb.DuckDBPyConnection | None = None
        self._owns_connection = True

    @property
    def uri(self) -> Path:
        """The URI this data store references. Available before opening."""
        return self._uri

    @property
    def connection(self) -> duckdb.DuckDBPyConnection:
        """The shared DuckDB connection.

        Raises:
            RuntimeError: If the data store hasn't been opened.
        """
        if self._conn is None:
            msg = (
                f"DuckDBDataStore({self._uri!r}) is not open. Use it as a context "
                "manager (``with DuckDBDataStore(uri) as store: ...``) or call "
                "``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._conn

    @property
    def registry(self) -> Registry | None:
        """The :class:`Registry` whose connection is shared, or ``None``.

        Set when the data store was constructed via :meth:`from_registry`;
        ``None`` for standalone Path-style construction.
        """
        return self._registry

    def open(self) -> Self:
        """Open the DuckDB connection and apply ``extensions`` + ``attach``.

        Idempotent within a single open/close cycle.
        """
        if self._conn is not None:
            return self
        self._conn = duckdb.connect(str(self._uri))
        self._owns_connection = True
        self._configure_session()
        return self

    @classmethod
    def from_registry(
        cls,
        registry: Registry,
        *,
        attach: dict[str, str] | None = None,
        extensions: list[str] | None = None,
    ) -> Self:
        """Wrap a :class:`Registry`'s open connection.

        The data store does NOT take ownership of the connection — closing
        the data store leaves the registry's connection open. The registry
        must already be open (i.e. inside its ``with`` block).

        Args:
            registry: An open :class:`Registry`. Its connection is reused.
            attach: ``alias → ATTACH spec`` mapping. Executed at open time.
            extensions: DuckDB extensions to INSTALL+LOAD before any ATTACH.
        """
        instance = cls.__new__(cls)
        instance._uri = registry.uri  # noqa: SLF001 — alternate constructor sets private state
        instance._attach = attach  # noqa: SLF001
        instance._extensions = extensions  # noqa: SLF001
        instance._registry = registry  # noqa: SLF001
        instance._conn = registry.connection  # noqa: SLF001
        instance._owns_connection = False  # noqa: SLF001
        instance._configure_session()  # noqa: SLF001
        return instance

    def _configure_session(self) -> None:
        """Apply the configured extensions + ATTACH specs to the live connection."""
        if self._conn is None:
            return
        if self._extensions:
            for ext in self._extensions:
                self._conn.execute(f"INSTALL {_sql_identifier(ext)}")
                self._conn.execute(f"LOAD {_sql_identifier(ext)}")
            # Loading extensions can change the search_path; reset to
            # ``sdmx`` so any colocated Registry's internal queries stay clean.
            self._conn.execute("SET search_path = 'sdmx'")
        if self._attach:
            for alias, spec in self._attach.items():
                self._conn.execute(f"ATTACH {spec} AS {_sql_identifier(alias)}")
            self._conn.execute("SET search_path = 'sdmx'")

    def __enter__(self) -> Self:
        if self._conn is None:
            self.open()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the database connection (only if we own it)."""
        if self._conn is not None and self._owns_connection:
            self._conn.close()
        self._conn = None

    # ── DataStore protocol ───────────────────────────────────────────────

    def query(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> pl.DataFrame:
        """Run a SELECT against ``binding.table_location``.

        Filter clauses use SDMX dimension/measure ids; the binding's
        column maps determine the physical column names. For v1 we
        assume identity mapping (SDMX id == physical column) — when
        non-identity mappings are needed, this method is the seam to
        wire in the rename.

        When ``binding.series_attributes_location`` is set, the sidecar
        table is LEFT JOINed on the columns common to both tables (found
        via DuckDB ``DESCRIBE``). This is what makes
        ``binding.attribute_column_map`` columns reachable when the
        attributes live on a sibling table rather than denormalised into
        the fact table.
        """
        conn = self.connection
        sql, sql_params = _build_query(
            conn=conn,
            binding=binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=limit,
        )
        cur = conn.execute(sql, sql_params)
        col_names = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchall()
        if not rows:
            return pl.DataFrame(schema=col_names)
        return pl.from_records(rows, schema=col_names, orient="row")

    def query_stream(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        chunk_rows: int = 10_000,
    ) -> Iterator[pa.RecordBatch]:
        """Stream the same scan as :meth:`query` as Arrow record batches.

        Uses DuckDB's Arrow integration (``to_arrow_reader``) so peak
        memory stays roughly proportional to ``chunk_rows`` rather than
        the full result size. See :meth:`sdmxlib.DataStore.query_stream`.
        """
        conn = self.connection
        sql, sql_params = _build_query(
            conn=conn,
            binding=binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=None,
        )
        reader = conn.execute(sql, sql_params).to_arrow_reader(chunk_rows)
        yield from reader


# ── SQL helpers ─────────────────────────────────────────────────────────


def _build_query(
    *,
    conn: duckdb.DuckDBPyConnection,
    binding: DataflowBinding,
    where: list[str] | None,
    params: list[object] | None,
    component_filter: ComponentFilter | None,
    columns: list[str] | None,
    order_by: str | None,
    limit: int | None,
) -> tuple[str, list[object]]:
    """Build a parameterised SELECT + parameter list against the binding's table(s).

    Table names come from the binding (sdmxlib-controlled artefact) and
    are interpolated as-is. WHERE clauses are interpolated as-is too
    (callers compose them) but their values must be passed via ``params``
    for parameterisation — never f-stringed.

    When ``binding.series_attributes_location`` is set, the sidecar table
    is LEFT JOINed on the columns common to both tables. When
    ``component_filter`` is provided, it is translated to additional
    ``col IN (?, ?, ...)`` fragments via the binding's dimension and
    attribute column maps and ANDed in.
    """
    cols_sql = ", ".join(columns) if columns else "*"
    main = binding.table_location
    sidecar = binding.series_attributes_location
    if sidecar is None:
        sql = f"SELECT {cols_sql} FROM {main}"
    else:
        join_keys = _shared_columns(conn, main, sidecar)
        if not join_keys:
            msg = (
                f"DataflowBinding.series_attributes_location {sidecar!r} "
                f"shares no columns with {main!r}; cannot derive JOIN keys"
            )
            raise ValueError(msg)
        keys_sql = ", ".join(join_keys)
        sql = f"SELECT {cols_sql} FROM {main} LEFT JOIN {sidecar} USING ({keys_sql})"

    fragments = list(where or [])
    sql_params: list[object] = list(params or [])
    if component_filter is not None:
        cf_fragments, cf_params = component_filter.to_where_clauses(
            binding.dimension_column_map,
            binding.attribute_column_map,
        )
        fragments.extend(cf_fragments)
        sql_params.extend(cf_params)

    if fragments:
        sql += " WHERE " + " AND ".join(fragments)
    if order_by:
        sql += f" ORDER BY {order_by}"
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    return sql, sql_params


def _describe_columns(conn: duckdb.DuckDBPyConnection, table: str) -> list[str]:
    """Return column names for ``table`` via DuckDB ``DESCRIBE``."""
    rows = conn.execute(f"DESCRIBE {table}").fetchall()
    return [str(r[0]) for r in rows]


def _shared_columns(conn: duckdb.DuckDBPyConnection, table_a: str, table_b: str) -> list[str]:
    """Columns present in both tables, in ``table_a`` order."""
    cols_b = set(_describe_columns(conn, table_b))
    return [c for c in _describe_columns(conn, table_a) if c in cols_b]


def _sql_identifier(name: str) -> str:
    """Escape a SQL identifier (extension name, ATTACH alias).

    DuckDB identifiers are case-insensitive and may contain alphanumerics
    and underscores. Reject anything else to avoid SQL injection through
    extension/alias names.
    """
    if not name or not all(c.isalnum() or c == "_" for c in name):
        msg = f"Invalid SQL identifier: {name!r}"
        raise ValueError(msg)
    return name
