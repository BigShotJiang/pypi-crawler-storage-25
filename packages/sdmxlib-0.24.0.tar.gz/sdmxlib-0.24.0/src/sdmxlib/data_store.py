"""DataStore — Protocol for the data plane behind a federated catalog.

A :class:`DataStore` answers "give me observation rows for this binding,
filtered by these components." Implementations wrap whatever underlying
storage they like — DuckDB + DuckLake, raw Parquet on S3, Iceberg,
Spark — and present the same interface to
:class:`~sdmxlib.catalog.FederatedCatalog`.

The Protocol is minimal on purpose: a single ``query()`` method that
takes a :class:`~sdmxlib.model.binding.DataflowBinding` plus standard
filter/projection arguments and returns a Polars DataFrame.

The store is **data-only** — it knows nothing about codelists, labels,
or DSDs. Result annotation (joining labels onto code columns) is the
:class:`FederatedCatalog`'s job, since only the catalog has the
structural side.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Protocol, runtime_checkable

import polars as pl

from sdmxlib.model.binding import DataflowBinding

if TYPE_CHECKING:
    import pyarrow as pa

    from sdmxlib.rest import ComponentFilter


@runtime_checkable
class SqlRelation(Protocol):
    """A lazy single-column relation usable inside ``WHERE col IN (...)``.

    Producers (typically :class:`~sdmxlib.model.code_query.CodeQuery`)
    expose their compiled SELECT as a ``(sql, params)`` pair. The
    streaming-query SQL builder splices the SQL inline as a subquery
    and concatenates the params with the outer query's binds, so a
    50k-row hierarchy traversal becomes one ``IN (SELECT ...)`` clause
    with no parameter explosion.

    The subquery's tables must be visible on the data store's
    connection. For :class:`~sdmxlib.local.DuckDBDataStore` (which
    shares its connection with :class:`~sdmxlib.local.Registry`),
    codelist relations compose automatically because both sides see
    the same ``sdmx.code`` table.
    """

    def to_sql(self) -> tuple[str, list[object]]:
        """Return ``(sql, params)`` — a SELECT producing a single column."""
        ...


@runtime_checkable
class DataStore(Protocol):
    """Read-side contract for the data plane.

    Implementations must accept a :class:`DataflowBinding` and translate
    it (plus filter/projection arguments) into a backend-specific scan.
    """

    def query(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> pl.DataFrame:
        """Run a filtered, projected scan against the binding's table.

        Args:
            binding: Resolves to the table location and column maps.
            where: List of SQL WHERE-clause fragments (joined with AND).
                Use SDMX dimension/measure ids as column references —
                the binding handles any rename to the physical column.
            params: Positional parameters interpolated into the WHERE
                fragments via the backend's parameterisation. Must be
                separately passed (not f-stringed) to avoid SQL injection.
            component_filter: Optional :class:`~sdmxlib.rest.ComponentFilter`
                parsed from an SDMX REST dotted key plus ``c[...]=...``
                query params. Translated to additional WHERE-IN clauses
                against ``binding.dimension_column_map`` and
                ``binding.attribute_column_map``; ANDed with any
                caller-supplied ``where`` fragments.
            columns: Optional projection. ``None`` = all columns. Names
                are SDMX-side; binding maps them to physical columns.
            order_by: Optional SQL ORDER BY clause (e.g.
                ``"OBS_VALUE DESC NULLS LAST"``).
            limit: Optional row cap.

        Returns:
            A Polars DataFrame with one row per observation. Columns are
            named on the SDMX side (mapped from physical via the binding).
        """
        ...

    def query_stream(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        chunk_rows: int = 10_000,
    ) -> Iterator[pa.RecordBatch]:
        """Same scan as :meth:`query` but streamed in Arrow record batches.

        Lets bulk callers process or stream a result of arbitrary size in
        bounded memory — peak RSS is roughly ``chunk_rows * row_bytes``
        rather than ``num_rows * row_bytes``. The natural sink is a
        format writer (e.g. :func:`sdmxlib.formats.sdmx_csv.write_sdmx_csv`).

        Args:
            binding: As :meth:`query`.
            where: As :meth:`query`.
            params: As :meth:`query`.
            component_filter: As :meth:`query`.
            columns: As :meth:`query`.
            order_by: As :meth:`query`. Note that ordering may force the
                backend to materialise everything before streaming.
            chunk_rows: Target number of rows per emitted batch.

        Yields:
            One :class:`pyarrow.RecordBatch` at a time, in scan order.
        """
        ...
