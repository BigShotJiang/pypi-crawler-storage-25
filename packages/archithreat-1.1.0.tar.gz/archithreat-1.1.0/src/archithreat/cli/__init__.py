"""archithreat CLI shell."""
