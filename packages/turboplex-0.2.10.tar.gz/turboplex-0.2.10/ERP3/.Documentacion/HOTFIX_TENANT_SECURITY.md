Plan de Ejecución: Blindaje de Tenant y Preparación de Schemas🎯 ObjetivoCerrar fugas de aceite: Denormalizar empresa_id en tablas hijas.Activar RLS Nivel Dios: Configurar el motor para que Postgres sea el guardia final.Latencia de Schemas: Dejar el terreno listo para CRM-{name} / ERP-{name}.🏗️ Fase 1: Denormalización de Tablas Hijas (Base de Datos)Ejecutar mediante migración de Alembic para asegurar consistencia.1.1 Modificación de Modelos (models.py)Añadir empresa_id a las siguientes entidades:DetalleVentaMovimientoContableDocumentoTributarioDetalle1.2 Script de Migración SQL (Quirúrgico)No basta con añadir la columna; hay que poblarla antes de hacerla NOT NULL.SQL-- Ejemplo para detalles_venta
ALTER TABLE detalles_venta ADD COLUMN empresa_id UUID;

-- Poblado masivo mediante JOIN con la tabla padre
UPDATE detalles_venta d
SET empresa_id = v.empresa_id
FROM ventas v
WHERE d.venta_id = v.id;

-- Ahora sí, restricción de seguridad
ALTER TABLE detalles_venta ALTER COLUMN empresa_id SET NOT NULL;
CREATE INDEX idx_detalles_venta_empresa_id ON detalles_venta(empresa_id);
🛡️ Fase 2: Implementación de RLS Nativo (PostgreSQL)Esto se agrega en el script de migración para activar la seguridad en el motor.2.1 Activación de PolíticasSQL-- Ejecutar para cada tabla con empresa_id
ALTER TABLE ventas ENABLE ROW LEVEL SECURITY;
ALTER TABLE ventas FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation_policy ON ventas
    USING (empresa_id = current_setting('app.current_empresa_id')::UUID)
    WITH CHECK (empresa_id = current_setting('app.current_empresa_id')::UUID);
🧠 Fase 3: Backend - El Inyector de Contexto (database.py)Modificar el listener de la sesión para que siempre "setee" el tenant en Postgres.3.1 After Begin EventPython@event.listens_for(Session, "after_begin")
def set_postgres_session_context(session, transaction, connection):
    empresa_id = session.info.get("empresa_id")
    if empresa_id:
        # Esto activa el RLS de la Fase 2
        connection.execute(text(f"SET LOCAL app.current_empresa_id = '{empresa_id}'"))
    elif not session.info.get("allow_no_tenant"):
        # Bloqueo total si no hay contexto
        raise PermissionError("Acceso a base de datos sin contexto de empresa activo.")
🧬 Fase 4: Preparación para "Digievolución" (Schemas Latentes)Para permitir los esquemas CRM- y ERP- en el futuro.4.1 Utilidad de Routing de EsquemasCrear un helper en app/core/tenant_handler.py:Pythondef get_tenant_search_path(empresa_slug: str, is_premium: bool = False):
    if is_premium:
        return f'"CRM-{empresa_slug}", "ERP-{empresa_slug}", public'
    return "public"
4.2 Punto de Inyección en la ConexiónEn el generador de sesión (get_db), dejar el espacio para el search_path:Python# Latente: 
# if user.has_premium_schema:
#    db.execute(text(f"SET search_path TO {get_tenant_search_path(empresa_slug, True)}"))
🚥 Fase 5: Verificación de IntegridadTestAcciónResultado EsperadoAislamientoLogin con Empresa A e intentar ver ID de Empresa B.404 Not Found o Permission Denied.Tablas HijasConsulta directa a detalles_venta sin JOIN.Solo devuelve filas de la empresa activa.Async WorkersEjecutar un worker sin pasarle el UUID.Debe fallar inmediatamente (Fail-Fast).⚠️ Notas de Seguridad Extrema:No usar Strings: Asegúrate de que el UUID se pase siempre como objeto UUID para evitar inyección SQL en el SET LOCAL.Ruff/Mypy: Ejecutar después de los cambios para asegurar que la nueva columna empresa_id esté mapeada en todos los esquemas Pydantic de salida.

## Estado (Aplicado)

- Fase 1 (Alembic): 9c4d2a1b7e3f_denormalize_empresa_id_child_tables
  - Agrega empresa_id + FK + índice en: detalles_venta, movimientos_contables, documentos_tributarios_detalles
  - Backfill por JOIN desde tablas padre: ventas, asientos_contables, documentos_tributarios
- Fase 2 (Alembic): 0b7e2c1d9a4f_enable_rls_tenant_isolation_policy
  - Activa RLS y crea tenant_isolation_policy en: ventas, detalles_venta, asientos_contables, movimientos_contables, documentos_tributarios, documentos_tributarios_detalles
  - Política UUID-safe con nullif(current_setting(...), '')::uuid y bypass controlado por app.allow_no_tenant='1'
- Fase 3 (Backend): listener after_begin setea app.current_empresa_id y app.allow_no_tenant vía set_config parametrizado (sin interpolación de strings)
  - Se fuerza boundary de transacción en deps (rollback al cerrar bloques allow_no_tenant) para evitar que el bypass quede “pegado” en el mismo transaction scope
- Fase 4 (Preparación): helper get_tenant_search_path agregado en app/core/tenancy.py (no activado por defecto)
- Alembic (Unificación de Heads): f81134d0d5ad_merge_multiple_heads
  - Mergepoint que une 0b7e2c1d9a4f y a4c2b1d0e9f3
  - alembic upgrade head vuelve a ser lineal y determinista



------------------------------------------------------------------


Objetivo

- Construir el Mapa de Ownership del Portal y verificar las 3 invariantes:
  1. toda query relevante va tenant-scoped por empresa_id ,
  2. el filtrado por sucursal vive en el módulo dueño ,
  3. en addons/portal/ no queda ningún import desde core_modules.*.models .
Scope

- Revisar backend/app/addons/portal/** (imports y queries).
- Revisar portal_contracts.py de Ventas/Facturación/CRM contra invariantes (tenant + sucursal).
- Entregar lista exacta de violaciones y plan de corrección.
Trade-offs

- Quitar core_modules.*.models desde addons/portal implica mover parte de la lógica de quotes.py y auth.py a contratos (más “surface” público en módulos, menos acoplamiento y menos goteras).
- Puede crecer crm/portal_contracts.py ; si se acerca a 600 líneas, el plan debe partirlo (paquete/archivo dedicado).
## Resultado de verificación (Invariant #3)
Hoy aún quedan 2 imports prohibidos en addons/portal :

- backend/app/addons/portal/routers/quotes.py importa CRM models:
   quotes.py
- backend/app/addons/portal/routers/auth.py importa Sistema models ( Empresa ):
   auth.py
Fuera de eso, no aparece ningún otro import ... core_modules.*.models dentro de backend/app/addons/portal/ (según búsqueda global por patrones de import).

## Verificación de contratos (Invariantes #1 y #2)
Ventas – OK (tenant-scoped)

- get_cliente_rut y cliente_exists filtran por Cliente.empresa_id == empresa_id .
   ventas/portal_contracts.py
Facturación – OK (tenant + sucursal)

- Filtra por DocumentoTributario.empresa_id == empresa_id y aplica sucursal vía Venta.sucursal_id cuando allowed_sucursal_ids no es None .
   facturacion/portal_contracts.py
CRM – OK (tenant + sucursal)

- Cotizacion.empresa_id == empresa_id + OportunidadVenta.cliente_id == cliente_id y sucursal vía OportunidadVenta.sucursal_id cuando corresponde.
   crm/portal_contracts.py
## Mapa de Ownership (Portal)
- Addon Portal (dueño de tablas addon)
  
  - portal_users , portal_payment_notifications (lectura/escritura desde portal).
  - Endpoints admin operan sobre estas tablas: admin.py
- Módulo CRM (dueño de cotizaciones, oportunidades, documentos CRM)
  
  - Accesos “documentales” ya pasan por contrato: documents_quotes.py
- Módulo Facturación (dueño de DTEs)
  
  - Listado/obtención para portal ya pasan por contrato: documents_dtes.py
- Módulo Ventas (dueño de Cliente y rut)
  
  - Portal obtiene rut vía contrato: ventas/portal_contracts.py
## Plan para eliminar los 2 imports restantes (sin aplicar todavía)
1. Portal Auth : reemplazar db.query(Empresa) en auth.py por una función nueva en app/core_modules/sistema/portal_contracts.py , por ejemplo:
   
   - get_empresa_for_portal_login(db, *, empresa_codigo) -> (empresa_id, is_active)
   - El addon solo consume el contrato y deja de importar Empresa .
2. Portal Quotes : mover TODA la lógica que hoy toca crm_models.* (incluye Cotizacion , DocumentoCRM , OportunidadVenta , CotizacionItem , enums, joinedload, cambios de estado) desde quotes.py a app/core_modules/crm/portal_contracts.py (o dividirlo si crece):
   
   - list_cotizaciones_for_portal(...)
   - get_cotizacion_detalle_for_portal(...) (con items)
   - update_borrador_cliente_for_portal(...)
   - enviar_propuesta_cliente_for_portal(...)
   - rechazar_item_cliente_for_portal(...)
   - aceptar_cotizacion_crear_oc_for_portal(...) (recibe stored_path + metadata; crea DocumentoCRM y actualiza estados)
   - El addon se queda con: validación superficial, upload a storage, y llamada al contrato (sin modelos).
3. (Opcional, pero recomendado para “donde va cada quien”): en portal/models.py hoy hay relationship("app.core_modules....models.X") (no es import, pero sí acopla el addon al modelo ajeno). Si quieres “pureza” máxima del addon, se eliminan esas relationships y se dejan solo FKs.
Si confirmas con “Proceed” o “Go” , aplico el refactor de auth.py + quotes.py y dejo addons/portal con cero imports desde core_modules.*.models , manteniendo las invariantes tenant/sucursal en los contratos.

## Simulacro HA Local (Master/Replica/Audit en localhost)

- Master (escrituras): DATABASE_URL -> erp3_db
- Replica (lecturas): REPLICA_DATABASE_URL -> db_replica_local
- Audit/Mirror (auditoría separada, fallback silencioso): AUDIT_DATABASE_URL -> db_espejo_local
- Sync inicial (clonado Master -> Replica): backend/scripts/sync_simulated_dbs.py (soporta --pg-dump/--pg-restore o POSTGRES_BIN)

## CORE-DDI (Empaque Técnico)

- Script one-off: /.one-off-scripts/pack_core_ddi.py
- Incluye: DDL completo, auditoría puntual, captura de RLS/policies, backend_core, frontend_logic
- Sello: Fecha/Hora UTC + Git HEAD en README_TECNICO.md; FILE_TREE.txt y HASHES.txt
- Seguridad: escaneo de posibles secretos con abort por defecto (flag --allow-secrets para continuar)
