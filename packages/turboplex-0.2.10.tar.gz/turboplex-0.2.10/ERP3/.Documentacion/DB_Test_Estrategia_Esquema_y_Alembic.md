# Estrategia para DB de Pruebas (`erp3_test`) y Alembic

## 1. Contexto Actual

- Base principal: `erp3_db` (o similar) ya tiene todas las tablas creadas y evolucionadas históricamente.
- Base de pruebas: `erp3_test`, recién creada.
- Alembic:
  - Hay migraciones recientes (ej. `initial_uuid_schema`), centradas en UUID/UUIDv7 y ajustes nuevos.
  - No existe una migración “baseline” que cree todas las tablas core desde cero.
- Suite de tests:
  - Usa `TEST_DATABASE_URL` apuntando a `erp3_test`.
  - El fixture `setup_db` en `backend/tests/conftest.py` actualmente:
    - **NO** ejecuta `Base.metadata.create_all`.
    - Limpia datos con `TRUNCATE` para mantener la DB consistente entre tests.

Problema visible en los tests:

- Al ejecutar `test_core_integration.py::test_core_flow` se obtiene:

  ```text
  psycopg2.errors.UndefinedTable: no existe la relación «metodos_pago»
  ```

- Es decir, en `erp3_test` **no existe** la tabla `metodos_pago` (ni quizá otras tablas core).

---

## 2. Objetivo

- Tener una **DB de pruebas (`erp3_test`) estable**, lista para ejecutar la suite de tests sin errores de:
  - `UndefinedTable` (tablas inexistentes).
  - Permisos básicos (SELECT/INSERT/UPDATE/DELETE).
- A medio plazo, **alinear Alembic** para que pueda reconstruir una DB nueva desde cero usando solo migraciones, sin depender de `Base.metadata.create_all` en código de producción ni de scripts puntuales.

---

## 3. Problemas Identificados

1. **Esquema incompleto en `erp3_test`**
   - Alembic solo crea las partes nuevas (uuid, ajustes específicos).
   - Muchas tablas core se crearon originalmente con `Base.metadata.create_all` sobre la base “vieja”.

2. **Tests esperando DB “como producción”**
   - El fixture ya no crea tablas; asume que `erp3_test` ya tiene todo el esquema.
   - Esto es correcto conceptualmente, pero exige que el bootstrap de la DB de test se haga antes.

3. **Migraciones Alembic parciales**
   - No existe una revisión “baseline_full_schema” que describa todas las tablas actuales.
   - `alembic upgrade head` sobre una DB vacía **no** levanta todo el ERP.

---

## 4. Opción A (Pragmática): Bootstrap de Esquema en `erp3_test` con `Base.metadata.create_all`

### 4.1. Idea

- Ejecutar **una sola vez** un script de bootstrap sobre `erp3_test` que:
  - Conecte a `postgresql://erp3_test_admin:...@localhost/erp3_test`.
  - Llame a `Base.metadata.create_all(bind=engine)`.
- A partir de ahí:
  - `erp3_test` tendrá todas las tablas (incluyendo `metodos_pago`).
  - Los tests solo harán TRUNCATE entre ejecuciones.

### 4.2. Pasos Propuestos

1. Crear script one-off en `backend/.one-off-scripts/bootstrap_test_schema.py`:

   ```python
   import os
   from sqlalchemy import create_engine
   from app.core.database import Base

   def main():
       url = os.getenv(
           "TEST_BOOTSTRAP_URL",
           "postgresql://erp3_test_admin:erp3_test_admin@localhost/erp3_test",
       )
       engine = create_engine(url, future=True)
       try:
           Base.metadata.create_all(bind=engine)
       finally:
           engine.dispose()

   if __name__ == "__main__":
       main()
   ```

2. Ejecutarlo desde `backend/`:

   ```powershell
   $env:TEST_BOOTSTRAP_URL = 'postgresql://erp3_test_admin:erp3_test_admin@localhost/erp3_test'
   .\.venv\Scripts\python .one-off-scripts\bootstrap_test_schema.py
   ```

3. Eliminar el script (o marcarlo para cleanup) según política de `.one-off-scripts`.

4. Verificar con un test:

   ```powershell
   $env:TEST_DATABASE_URL = 'postgresql://erp3_test_admin:erp3_test_admin@localhost/erp3_test'
   $env:SYSTEM_STARTUP    = '1'
   .\.venv\Scripts\python -m pytest tests\test_core_integration.py::test_core_flow -q
   ```

### 4.3. Trade-offs

**Pros**

- Rápido y efectivo: en pocos pasos, `erp3_test` se parece a `erp3_db` a nivel de esquema.
- Los tests siguen usando TRUNCATE, sin DDL costoso en cada test.
- No rompe producción ni requiere reescribir migraciones existentes.

**Contras**

- El esquema inicial de `erp3_test` no queda 100% descrito en Alembic.
- Repetir el proceso para otra DB nueva requiere volver a ejecutar el script (o documentarlo bien).

---

## 5. Opción B (Estructural): Baseline Completa en Alembic

### 5.1. Idea

- Crear una migración Alembic “baseline” que describa todo el esquema actual.
- A futuro, cualquier DB nueva se genera solo con:

  ```bash
  alembic upgrade head
  ```

### 5.2. Pasos Propuestos (conceptuales)

1. Verificar que `alembic/env.py` use:

   ```python
   from app.core.database import Base
   target_metadata = Base.metadata
   ```

2. Crear una DB totalmente vacía (por ejemplo `erp3_baseline`).

3. Generar migración baseline:

   ```bash
   # Usando DATABASE_URL apuntando a erp3_baseline
   alembic revision --autogenerate -m "baseline_full_schema"
   ```

   - Esto inspecciona `Base.metadata` y genera `op.create_table(...)` para todas las tablas.

4. Revisar a mano la migración generada:
   - Confirmar nombres de tablas, FKs, tipos, índices.
   - Ajustar cualquier detalle manualmente si es necesario.

5. Aplicar a DB nuevas:

   ```bash
   alembic upgrade head
   ```

6. Para la DB ya existente (`erp3_db`):
   - No ejecutar la migración (para no duplicar tablas).
   - Usar:

     ```bash
     alembic stamp head
     ```

     para marcar que está “a la altura” de ese esquema.

### 5.3. Trade-offs

**Pros**

- A largo plazo, arquitectura más limpia: todas las DB se levantan solo con Alembic.
- Fácil creación de entornos nuevos (demo, staging, tests) sin scripts auxiliares.

**Contras**

- Más trabajo inicial:
  - Revisar el autogenerate completo.
  - Asegurar que no haya divergencias con la DB en producción.
- Riesgo de inconsistencias si la migración baseline no refleja perfectamente la DB real.

---

## 6. Recomendación

### Corto Plazo (para estabilizar tests ahora)

- Adoptar **Opción A (Bootstrap de Esquema en `erp3_test`)**:
  - Ejecutar `Base.metadata.create_all` una sola vez sobre `erp3_test` mediante script one-off. Este bootstrap ya fue ejecutado en el entorno local usando `backend/.one-off-scripts/bootstrap_test_schema.py`.
  - Mantener el fixture `setup_db` con TRUNCATE y sin DDL.
  - Validar con herramientas auxiliares que el esquema realmente exista: actualmente, la inspección directa de `erp3_test` muestra solo la tabla `alembic_version` en el esquema `public`, lo que indica que `create_all` no ha materializado aún las tablas de dominio (como `metodos_pago`) y requiere revisar permisos del rol de prueba o el contexto de imports.
  - El script de bootstrap fue ajustado para importar explícitamente los módulos de modelos de todos los core modules (`sistema`, `ventas`, `finanzas`, `compras`, `crm`, `facturacion`, `rrhh`, `ti`, `legal`, `service_engine`, `webhooks`, `auditoria`, `billing`) antes de llamar a `Base.metadata.create_all`, garantizando que el metadata conozca todas las tablas definidas.
  - La suite de pruebas deja de ejecutar `Base.metadata.drop_all` en el fixture `setup_db`; se mantiene limpieza por `TRUNCATE ... CASCADE` para preservar el esquema creado en `erp3_test` y evitar errores `UndefinedTable` entre tests.
  - Los esquemas Pydantic de `CierreCaja` en `finanzas.schemas` se alinean con el dominio: `sucursal_id`, `usuario_id`, `empresa_id` e `id` pasan a ser `UUID`, permitiendo que la API de apertura/cierre de caja reciba y devuelva identificadores UUID coherentes con los modelos SQLAlchemy y con los tests de integración.
  - Para habilitar ventas en el flujo de integración, se agregó un paso de “Ingreso de Stock” en `tests/test_core_integration.py` mediante `POST /api/v1/ventas/ajuste-stock`. Se ajustó `StockAdjustmentCreate` para aceptar `UUID` en `producto_id` y `bodega_id`.
  - Se alinearon esquemas de `Gasto` (`finanzas.schemas`) a `UUID` para `proveedor_id`, `sucursal_id`, `metodo_pago_id`, `id` y `empresa_id`. Se robusteció `crear_egreso` para no fallar si la contabilidad no está inicializada.
  - Se corrigieron tipos en `ventas.schemas.Cliente` y en `ventas.api.delete_cliente` para aceptar `UUID`, evitando errores de serialización/validación en la prueba de auditoría.
  - Migración final UUID: Se eliminaron `Union[UUID, int, str]` en esquemas de Venta, Cliente y Producto. Todos los IDs y FKs relevantes son ahora `UUID` puro. Se actualizaron también `InventarioGlobalItem.producto_id` y `StockAdjustmentCreate` a `UUID`.
  - Rutas (Path Params): `ventas.api.delete_venta` y `ventas.api.delete_cliente` ahora tipan `id: UUID` en la firma.
  - Test de humo: `tests/test_core_integration.py` usa `jsonable_encoder` al crear el cliente temporal en la prueba de auditoría, evitando el error de serialización de `UUID` en el lado cliente del TestClient.
  - Resultado: `test_core_flow` en verde. Advertencias contables por Plan de Cuentas ausente no bloquean el flujo. 
  - Taller / Orden de Servicio: Los esquemas Pydantic de `OrdenServicio` e `HistorialOrdenServicio` se migraron a `UUID` puro para todos sus IDs (`id`, `venta_id`, `orden_servicio_id`, `usuario_id`). El endpoint de actualización de estado `/api/v1/ventas/ordenes-servicio/{id}/estado` ahora recibe `id: UUID` y el servicio asociado opera también con `UUID`, manteniendo el test de integración `test_core_flow` en verde tras la migración.
  - Enfocar esfuerzos en:
    - Errores de RLS / tenant (`Tenant context missing`).
    - Errores funcionales (reglas de negocio, seguridad SaaS, etc.).
    - Ajustes de UUID/UUIDv7 en tests restantes (pricing, RRHH, verticales).

### Medio Plazo (higiene de migraciones)

- Planificar **Opción B (Baseline Alembic)** como tarea aparte:
  - Solo cuando el código y la base de producción estén en un estado estable.
  - Hacerlo con pruebas cuidadosas en una DB vacía antes de tocar entornos reales.
  - Documentar claramente:
    - Cómo crear una nueva DB desde cero con Alembic.
    - Qué hacer con DBs existentes (`stamp head`).

---

## 7. Resumen Ejecutivo

- **Problema raíz**: `erp3_test` no tiene todas las tablas core; Alembic actual no cubre la creación completa del esquema.
- **Acción rápida recomendada**: script one-off que ejecute `Base.metadata.create_all` sobre `erp3_test`, luego dejar que los tests solo limpien datos.
- **Acción estructural futura**: diseñar una migración Alembic “baseline_full_schema” para que cualquier nueva DB se pueda construir únicamente vía `alembic upgrade head`.
