🛠️ Instrucción de Configuración: "Delegación y Segregación de Funciones (SoD)"
Objetivo: Permitir que el Administrador (ADM) delegue la carga masiva a perfiles operativos y de auditoría, manteniendo el control final.

1. Backend: Segregación por Rol.codigo (empresa activa)
Archivo: backend/app/core_modules/inventario/stock/api.py

Endpoints y reglas:
- POST /api/v1/inventario/stock/massive/upload: permitido para ADM, OPS, AUD
- POST /api/v1/inventario/stock/massive/validate: permitido para ADM, OPS, AUD
- GET  /api/v1/inventario/stock/massive/staging-summary: permitido para ADM, OPS, AUD
- GET  /api/v1/inventario/stock/massive/staging-errors: permitido para ADM, OPS, AUD
- POST /api/v1/inventario/stock/massive/apply: exclusivo para ADM

Nota operativa (Soporte):
- Roles globales SUPERADMIN / DEVELOPER / ADMIN pueden ejecutar upload/validate/monitoreo para soporte.
- El apply sigue siendo exclusivo para Rol.codigo == ADM de la empresa activa.
- Monitoreo incluye staging-summary y staging-errors, con el mismo esquema de permisos que upload/validate.

2. Mapeo de Roles de Empresa
ADM (Administrador): Tiene los 3 permisos (upload, validate, apply).

OPS (Operaciones/Jefe Logística): Tiene upload y validate. (Prepara el terreno).

AUD (Auditoría): Tiene upload, validate y acceso de lectura al monitor de errores. No tiene apply.

3. Lógica del Endpoint en stock/api.py
Refactorizar POST /massive/apply:

Debe requerir estrictamente Rol.codigo == ADM para la empresa activa.

Si un AUD o OPS intenta llamar a este endpoint, el sistema debe responder: "403: Requiere autorización de Gerencia (ADM) para aplicar cambios a producción".

4. Interfaz de Usuario Inteligente (Frontend)
Archivo: frontend/src/views/inventory/InventarioGlobal.vue

Lógica de Botones:

Botón "Subir Excel": Visible para ADM, OPS y AUD.

Botón "Validar": Visible para ADM, OPS y AUD.

Botón "Confirmar y Aplicar": Únicamente visible y habilitado para ADM.

Nota técnica (rendimiento):
- La validación se ejecuta por lotes (batch) para evitar timeouts en archivos grandes (ej. 23k filas).
- El endpoint /massive/validate procesa hasta N filas por llamada; el frontend repite hasta que pending=0.
