# Registro de Cambios

## 2026-03-25 (Servicios Externos · Proveedor RUT)

- Backend (RLS/ORM): se corrige `InvalidRequestError` de SQLAlchemy (`track_closure_variables`) en `with_loader_criteria` al inyectar el filtro tenant global.
- Backend (RLS/ORM): el filtro de tenant inyectado por ORM ahora compara `empresa_id` casteando a texto para evitar `ProgrammingError` por mismatch `uuid/varchar` en tablas legacy (p.ej. `revoked_tokens`), restaurando el flujo del portal.
- Backend (Portal Auth): `PortalUser.must_change_password` añadido al modelo y enforcement en dependencia del portal; solo permite `/portal/v1/auth/change-password` y `/portal/v1/auth/logout` mientras esté activo.
- Backend (Token JTI): `create_access_token` ahora agrega `jti` por defecto; `revoked_tokens` expone ORM y se consulta en el portal para invalidación de tokens.
- Backend (Portal Auth): nuevos endpoints `POST /portal/v1/auth/change-password` y `POST /portal/v1/auth/logout` con revocación del `jti`.
- Backend (Portal Admin): `POST /portal/v1/admin/impersonate` (SUPERADMIN/DEVELOPER) genera token temporal aud=portal para “ver como cliente”.
- Backend (Portal JWT): el token del portal incluye `role` y `must_change_password`; la dependencia del portal omite el bloqueo de cambio de contraseña al impersonar (`impersonated_by`).
- Backend (RUT): validadores de `ClienteCreate/Update` aceptan entradas con o sin guion y normalizan a `12345678-K`; búsquedas `GET /ventas/clientes/by-rut` y `rut_cache` usan formato normalizado con guion y DV en mayúscula.
- Frontend (Portal): se agrega vista `/portal/change-password`, guard de router por `must_change_password`, y logout real llamando `POST /portal/v1/auth/logout`; navegación del portal se oculta mientras el cambio es obligatorio.
- Frontend (Admin/Portal): en la ficha de cliente se agrega acción “Ver como” que llama `POST /portal/v1/admin/impersonate`, setea `portal_token` y abre el portal en una nueva pestaña.
- Tests (E2E Portal): nueva suite Playwright para verificar redirect por `must_change_password` y revocación de token vía `revoked_tokens`.
- Tests (E2E Portal Smoke): se añade `e2e/portal-smoke.spec.ts` que simula `portal_token` con `must_change_password=true`, mockea `POST /portal/v1/auth/{change-password,logout}` y valida redirección a `/portal/change-password` y retorno a `/portal/login` tras submit.
- Backend (FastAPI Compat): se corrige `get_current_portal_user(request: Request)` removiendo la anotación opcional (`Request | None`) para evitar error de modelo de respuesta en FastAPI/Pydantic durante el registro de rutas.
- Migraciones (Seguridad Portal): se agrega `portal_users.must_change_password` (default `true` para nuevos; backfill a `false` para usuarios existentes) y tabla `revoked_tokens` para revocar JWT por `jti`.
- Migraciones (RUT Normalizado): se normaliza `clientes.rut` y `rut_cache.rut_normalized` al formato `12345678-K` (sin puntos, con guion y DV en mayúscula).
- Migraciones (BI/RLS): se corrige `v_bi_transport_performance` para compatibilidad `uuid/text` y se ajusta la ejecución condicional de políticas RLS por existencia de tablas.
- Migraciones (Idempotencia): la creación de índices en `rut_cache`/`rut_lookup_log` tolera preexistencia (`DROP INDEX IF EXISTS`) para evitar fallos en upgrades parciales.
- Frontend (Servicios Externos): se agrega pestaña “Configuración” con selector de proveedor, formulario dinámico, TTL (días) y botón “Test” con indicador verde/rojo.
- Frontend (RBAC UI): “Servicios Externos” queda visible y accesible para SUPERADMIN y DEVELOPER.
- Backend (Proxy Ciego): `GET /api/v1/rut/lookup` resuelve el proveedor y credenciales internamente (sin exponer secretos al frontend) y toma el TTL desde `rut_provider_config` por empresa.
- Backend (Configuración Proveedor): nuevos endpoints `GET/PUT /api/v1/rut/provider-config` y `POST /api/v1/rut/provider-config/test`, restringidos a SUPERADMIN/DEVELOPER, con credenciales enmascaradas hacia el frontend y guardado encriptado `enc:`.
- Backend (Auditoría): `rut_lookup_log.empresa_id` se fija siempre desde `get_current_active_company` para aislamiento real por tenant.
- Tooling (Ruff): se excluye `one-off-scripts/` (root) para evitar falsos positivos E402 fuera del código productivo.

## 2026-03-24 (RLS + VIS + FIFO)

- Backend (Proveedor RUT): se crea `RutProviderConfig` (por empresa) con `provider_type`, `auth_params` (JSONB, valores sensibles encriptados `enc:`), `ttl_days` y `updated_at`.
- Migraciones (Alembic): nueva revisión `9a7f2b1c4e21_rut_provider_config.py` para la tabla `rut_provider_config` con índice único por `empresa_id`.
- Frontend (Sidebar Admin): se añade ítem “Servicios Externos” para roles SUPERADMIN/DEVELOPER apuntando a `/super-admin/servicios-externos`.
- Frontend (Ruta dedicada): se crea la vista `ServiciosExternos.vue` bajo `/super-admin/servicios-externos` con panel de consulta de RUT (caché/proveedor) y listado de logs.
- Router: se registra la ruta `super-admin/servicios-externos` con meta roles `['SUPERADMIN','DEVELOPER']`.
- Backend (RUT Caché): se agregan modelos `RutCache` y `RutLookupLog` y endpoints `GET /api/v1/rut/lookup` y `GET /api/v1/rut/logs` con TTL 30 días, registro de fuente (`cache|provider|invalid_dv`), y manejo controlado de proveedor caído.
- Migraciones (Alembic): se crea revisión `c8a1c7e2c9a1_rut_cache_and_lookup_log.py` con PRIMARY KEY en `rut_cache.rut_normalized` e índices para lookups O(1).
- Frontend (Clientes/New): en pestaña Legal se añaden botones “Buscar RUT (caché)” y “Consultar proveedor” con aplicación automática de giro/dirección/comuna desde la respuesta.
- Frontend (Dev Dashboard): se agrega panel “Servicios Externos · RUT” para consultas manuales (caché/proveedor) y visualización de últimas consultas por empresa.

- Frontend (RUT/UX): se estandariza el texto “El dígito verificador no corresponde” y se mapean errores 422 del backend a feedback inline donde aplica.
- Frontend (RUT/UX): validación centralizada Mod 11 con mensaje específico cuando el dígito verificador no corresponde; se muestra feedback inline y se bloquea el submit en RRHH (empleados), Compras (proveedores), registro público y creación de cliente/empresa (admin + clientes).
- Inventario (Auth/Redirect): `GET /api/v1/inventario/{stock,catalogo,movimientos}` ya no fuerza redirect 307 hacia rutas con `/` final (se exponen también las rutas sin slash) para evitar que el navegador pierda el header `Authorization` y dispare un 401 que bota al login.
- Auth API (Tenant en Dashboard): `/api/v1/users/me` y `/api/v1/v2/users/me` intentan fijar `db.info["empresa_id"]` usando `get_current_active_company` (con fallback si `cmp` es inválido y sin bloquear login cuando el usuario no tiene empresas).
- Debug (Tenant/Errores): `app.main` imprime en consola `HTTPException.detail` y errores de validación para requests a `/api/v1/sucursales/active`, incluyendo `cmp` y `X-Request-ID`.
- Debug (Tenant/ORM): `database.py` agrega contexto por-request (ContextVar) y logs acotados a `/sucursales/active` para mostrar `empresa_id`, `allow_no_tenant`, `bypass_app_tenant_filter`, tablas detectadas e inyección de filtros ORM.
- Dev (Launcher): `start_dev.bat` usa el Python del venv en `ERP3/.venv` para evitar depender del Python global; el frontend corre `npm ci` automáticamente si falta `node_modules`.
- One-off Script: se agregó `.one-off-scripts/create_dev_user.py` para crear el usuario global `dev@erp3.com` con rol `DEVELOPER`, activo y sin asociación a empresa; parámetros `DEV_USER_EMAIL` y `DEV_USER_PASSWORD`.

- Tests (Calidad): reorden de imports en `conftest.py` y `test_use_case_service_config` para cumplir Ruff (E402/F821) sin afectar el setup de entorno.
- Tests (Race Condition): la verificación final usa sesión con `empresa_id` (no `allow_no_tenant`) para poder consultar `inventario` sin violar el guard de RLS.
- Tests (Race Condition): `race_condition_test` fija `session.info["empresa_id"]` tras crear la empresa y desactiva `allow_no_tenant` para que `Inventario.empresa_id` no quede NULL bajo RLS/NOT NULL.
- Tests (Service Config): se importa `Depends` para los overrides de dependencias y evitar `NameError`.
- Tests (RLS/Fixtures): el bootstrap de `CompanySubscription` usa `allow_no_tenant=True` solo durante el flush de suscripciones y lo restaura en el siguiente `after_flush`, evitando mismatches cuando se crean múltiples empresas en una transacción.
- Tests (RLS/Fixtures): `_auto_company_subscription` ajusta `db.info["empresa_id"]` por cada empresa creada en el mismo flush para evitar `empresa_id mismatch` al crear `CompanySubscription` en escenarios multi-empresa.
- Tests (Service Config): `test_use_case_service_config` habilita `allow_no_tenant` durante el setup multi-empresa y asegura que `get_current_active_company` setee `db.info["empresa_id"]` para evitar violaciones de aislamiento (`empresa_id mismatch`).
- Service Engine/Finanzas: `finanzas.listeners` usa `app.core.database.SessionLocal` vía módulo (no import directo) para que los listeners usen la BD de test cuando `SessionLocal` es parcheado en `tests/conftest.py` y para evitar que E2E dependan de parchear cada módulo.
- Tests (Parcheo SessionLocal): `ventas.listeners` expone `SessionLocal` como alias para que los tests que usan `patch("app.core_modules.ventas.listeners.SessionLocal", ...)` no fallen, manteniendo la ejecución real vía `app.core.database.SessionLocal`.
- Tests (E2E Ventas): el test expira la sesión (`db.expire_all()`) antes de validar stock post-venta para evitar lecturas cacheadas cuando el descuento ocurre en otra sesión.
- Tests (E2E Inventario): el test expira la sesión (`db.expire_all()`) antes de validar stock para evitar falsos negativos por caché cuando el consumo ocurre en una sesión de background distinta.
 - Background Jobs (Dev/Test): cuando Redis/RQ no está disponible, `Messenger` ejecuta en modo inline los jobs de lane `fast` para que los listeners (p.ej. inventario) sean determinísticos en E2E y no dependan del loop de FastAPI.
 - Service Engine/Inventario: `ventas.listeners` usa `app.core.database.SessionLocal` vía módulo (no import directo) para que los tests puedan parchear correctamente la sesión y los jobs registren `BackgroundJobLog` en la BD de test.
 - Migraciones (Alembic/Postgres): `alembic/env.py` permite `MIGRATIONS_DATABASE_URL` (usuario con permisos), selecciona/crea `MIGRATIONS_SCHEMA` para alojar `alembic_version`, fuerza `transactional_ddl=True` y confirma el `search_path` (`public` primero) en una transacción separada para que `autocommit_block` funcione correctamente; si no hay permisos, aborta con mensaje accionable.
 - DevOps: se configura `MIGRATIONS_DATABASE_URL` y `MIGRATIONS_SCHEMA` en `backend/.env` para ejecutar `alembic upgrade head` con un usuario con permisos.
 - Config (Settings): se agregan `MIGRATIONS_DATABASE_URL` y `MIGRATIONS_SCHEMA` para poder configurar migraciones desde `.env` sin exportar variables en la shell.
- Inventario (FIFO/Variantes): `_resolve_variant_id` ya no crea variante por defecto cuando no se entregan atributos; el consumo FIFO usa explícitamente `producto_id` y evita resolver variantes vacías para no sesgar búsquedas.
- Facturación (VIS): `VISValidationService.get_dispatch_status` y `get_monetary_dispatch_status` fuerzan el contexto de tenant durante lecturas, añaden filtro `empresa_id` y reemplazan `joinedload` por `JOIN` explícito a `Producto` para evitar SELECTs fuera de contexto.
- Facturación (VIS): `close_pending_balances` asegura contexto `empresa_id` y bloquea filas (`FOR UPDATE`) con scoping correcto antes de actualizar `cantidad_cancelada`.
- Testing (Integración Real VIS): `tests/test_vis_admin_close.py` usa `SessionLocal`/`writer_engine`, fija `empresa_id` después del setup y, en la verificación, resuelve la empresa por RUT para establecer el contexto tenant antes de consultas sobre `detalles_venta`/`productos`.
- Tests (Inventario FIFO): validado `test_consume_stock_fifo_across_variants_when_no_variant_specified` en verde tras ajustes de scoping y parámetros.

## 2026-03-23 (Dev - Arquitectura Distribuida Local)

- Refuerzo de Aislamiento e Inmutabilidad de Grado DDI: `inventario` incorpora `empresa_id` con backfill, RLS hard (FORCE) y policy estándar; `database.py` elimina el bypass heurístico y aplica allowlist estricta en modo `allow_no_tenant`; `audit_logs` queda inmutable (trigger bloquea UPDATE/DELETE).
- Auditoría (Core/DDI): se agrega reporte técnico crítico `AUDITORIA_ESTADO_DEL_ARTE_CORE.md` con análisis de aislamiento RLS, integridad de inventario, motor de impuestos, atomicidad, capacidad forense y performance para carga 40k.
- Inventario (Consistencia): `InventoryService.add_stock` ejecuta `release_stock + process_backorders` dentro de un SAVEPOINT para garantizar rollback si falla cualquier paso posterior.
- Migraciones (RLS-safe): Se ajusta `6f3a9c1c2d77_configuracion_impuestos_and_line_taxes.py` para desactivar RLS temporalmente en `configuracion_impuestos` durante el backfill del IVA y reactivarlo después, evitando fallos de RLS en `alembic upgrade`.
- Documentación: se agrega `arquitectura_distribuida_local.md` con setup local nativo, creación idempotente de DBs y guía de despliegue para separar writer/replica/audit.
- Dev (Tooling): `setup_dbs_local.py` ahora carga `backend/.env` automáticamente (python-dotenv) para no depender de variables de entorno exportadas en PowerShell.
- Dev (Local Nativo): se actualizan `.env` y `.env.example` con URLs a `localhost:5432` y aliases `REPLICA_URL`/`AUDIT_URL` para compatibilidad.
- Dev (Tooling): se agrega `backend/scripts/setup_dbs_local.py` para crear `db_espejo_test` y `db_auditor_test` vía SQLAlchemy de forma idempotente.
- Core (Config): `Settings` soporta `DATABASE_URL`, `REPLICA_DATABASE_URL` y `AUDIT_DATABASE_URL`, con anotaciones de retorno en validators para cumplir `ruff`/`mypy`.
- Core (DB): se habilita `reader_engine` y `audit_engine` con fallback a `DATABASE_URL` (log “Modo Monolítico”) y healthcheck al startup con Bulkhead (DB_W bloqueante; DB_R/DB_AUDIT no bloqueantes).
- DevOps (Docker Compose): Postgres fuerza `wal_level=logical` y define `max_replication_slots=5` + `max_wal_senders=5` para preparar Debezium/CDC.

## 2026-03-22 (Backend - Camaleonic Attributes)

- Arquitectura (Core): consolidación de `app/core` en paquetes (`database`, `infrastructure`, `security`, `exceptions`, `privacy`, `services`, `utils`) y retiro de rutas legacy.
- Arquitectura (Add-ons): `webhooks` se mantiene como add-on en `app/addons/webhooks` (no como `core_module`) y registro dinámico vía `ENABLED_ADDONS`.
- Mensajería / Air-Gap: se formaliza carril interno y externo con `redis/rabbit/kafka` mediante `app.core.infrastructure.messenger`.
- Frontend (CRM): store CRM corrige rutas bajo `/api/v1/crm/*` para evitar 404 por path incorrecto y exponer errores reales (ej. 403 licenciamiento).
- Licenciamiento: toggles en `/super-admin/licensing/{empresa_id}` para módulos `CRM`, `COMPRAS`, `FACTURACION`, `INVENTARIO`, `POS`, `PORTAL` vía `PATCH /api/v1/empresas/{empresa_id}`.
- Frontend (Clientes/Portal): en `/clientes/{id}` → “Acceso al Portal” se agregó selección de rol (`buyer`, `finance`, `master`) al crear y al editar usuarios del portal.
- Operación (Dev): verificación idempotente de `empresas.modulos_activos` para `QUESOS594` con CRM activo.

- Backend (Dev UX): CSP estricto se aplica solo en producciÃ³n para no romper Swagger UI; `/docs` y `/redoc` siguen deshabilitados en producciÃ³n.
- DevOps (Docker Compose): Postgres se configura con `wal_level=logical` (command) y `POSTGRES_INITDB_ARGS=--wal-level=logical` para habilitar CDC/Debezium en entornos con contenedor.
- Inventario: al insertar `Inventario` sin `variant_id`, se asigna automÃ¡ticamente la variante default `{}`; `InventoryService.add_stock` hace rollback si falla el procesamiento posterior (consistencia transaccional).
- ImportaciÃ³n DinÃ¡mica: `extract_camaleonic_attributes` captura columnas no-core como `additional_attributes` cuando no existe un mapeo explÃ­cito (slugify estable, stress test en verde).
- DocumentaciÃ³n: se agrega guÃ­a â€œSeguridad del Backend ante MÃºltiples Frontendsâ€.
- Seguridad: se agregan headers de seguridad (CSP estricto, HSTS en producciÃ³n, nosniff/deny/no-referrer) y se deshabilita `/docs` y `/redoc` en producciÃ³n; se valida `ACCESS_TOKEN_EXPIRE_MINUTES <= 60` en producciÃ³n.
- DocumentaciÃ³n: se agrega guÃ­a de â€œPuntos Clave de Seguridad - Carga 40K (Familia + SKU)â€.
- Calidad: mypy en verde (tipado del setter `Cliente.limite_credito` y refactor del apply para cumplir regla <600 lÃ­neas por archivo).
- Ventas/Producto: se agrega `familia` (nullable) y el apply permite enriquecimiento masivo por `SKU + familia` sin crear variantes ni tocar inventario; normaliza `familia` con `strip().upper()` y no sobreescribe si viene vacÃ­o.
- Calidad: se limpia `ruff` y `mypy` (imports no usados, exports explÃ­citos del paquete `inventario.stock.services`, tipado de `lote_id` como UUID/str y anotaciones en tests).
- Inventario (Ruta B): `check_stock` consolida stock sumando todas las variantes del `producto_id` por `bodega_id`, y `consume_stock` aplica FIFO por filas de `inventario` cuando no se especifica variante.
- MigraciÃ³n Alembic: se introduce `product_variants` (hash MD5 de JSONB canonizado) con `empresa_id` + RLS, se agrega `inventario.variant_id` con backfill seguro/idempotente y se fuerza `NOT NULL` + `UNIQUE (variant_id, bodega_id)`.
- Alembic (Hardening): se toleran filas huÃ©rfanas en `inventario` sin `producto` eliminÃ¡ndolas antes de forzar `variant_id NOT NULL`.
- Carga Masiva / Ajuste DinÃ¡mico: el apply y el stock-adjust resuelven/crean variantes por hash y operan el inventario por la clave `(variant_id, bodega_id)` evitando colisiones por SKU.
- Ventas (Listeners): consumo interno de receta usa `InventoryService.consume_stock` para garantizar consistencia con variantes y movimiento de stock Ãºnico.
- Testing: se actualizan tests de apply para validar `variant_id`/`attributes` y se agrega cobertura FIFO multi-variante.

- Fix Frontend Stock: el endpoint de inventario/stock ahora devuelve `sku` y la tabla de stock habilita la columna SKU por defecto (con migraciÃ³n de prefs antiguas).
- Fix Apply 30k (Camaleonic Attributes): el apply ahora acepta `mapping_json.additional_attributes` y persiste los atributos explÃ­citamente mapeados; se mantiene el filtro solo para duplicados reales contra campos core (sku/cantidad/stock/bodega).
- Backend (Camaleonic Attributes): se desactiva la captura automÃ¡tica de columnas â€œsobrantesâ€ del Excel; `additional_attributes` ahora solo incluye campos explÃ­citamente mapeados por el usuario.
- Frontend (Carga Masiva): botÃ³n â€œMapear columnas restantesâ€ autogenera filas en â€œMapear Otros Atributosâ€ para headers no asignados, usando slugify (ej. `Precio (Oferta) %` â†’ `precio_oferta`, `Monto de Costo` â†’ `monto_costo`) y mensaje â€œTodos los encabezados han sido asignadosâ€ cuando aplica.
- Carga Masiva (Apply): se filtran llaves reservadas/sinÃ³nimos (ej. cantidad/stock/inventario_fisico, sku, bodega) para evitar duplicaciÃ³n entre columnas core y `additional_attributes` (JSONB). Prioridad siempre al campo core.
- Backend (Inventario Stock API): `GET /api/v1/inventario/stock` ahora incluye `additional_attributes` (JSONB) en la respuesta para habilitar columnas dinÃ¡micas en el frontend.
- Frontend (Debug): se agregÃ³ `console.log('Atributos detectados:', dynamicKeys)` para verificar en F12 las llaves detectadas desde la API/prefs.
- Frontend (Inventario): columnas dinÃ¡micas ahora se detectan como uniÃ³n entre llaves escaneadas en la API (`stockRows.additional_attributes`) y llaves ya activadas por el usuario (persistidas en localStorage), evitando que desaparezcan al refrescar/paginar.
- UI: las columnas dinÃ¡micas tienen estilo diferenciado y ancho controlado (min/max + truncate) para distinguirlas de columnas base.
- Fix Carga Masiva (Apply): ahora se extraen columnas no-core desde `staging_imports.raw_content` y se persisten en `inventario.additional_attributes` y `movimientos_stock.additional_attributes` (JSONB) durante el apply.
- Testing: se agregÃ³ cobertura para validar persistencia de atributos camaleÃ³nicos en Inventario y Movimientos vÃ­a `apply_validated_inventory_to_production`.
- Implemented Camaleonic Attributes: JSONB metadata with Enterprise Dictionary support.
  - Frontend: en Carga Masiva (Apply) se muestra `error.response.data.detail` del backend en un banner rojo (ademÃ¡s del toast) para ver el mensaje exacto.
  - Frontend: tabla de Inventario (Stock) ahora detecta llaves de `additional_attributes`, permite configurar columnas visibles y persiste preferencias en localStorage por usuario+empresa.
  - DocumentaciÃ³n: se agregÃ³ manual de operaciÃ³n PostgreSQL para ERP3 (multi-tenant, RLS, JSONB, Alembic, runbooks).
  - DocumentaciÃ³n: se agregÃ³ secciÃ³n de troubleshooting para el error `no existe la relaciÃ³n schema.tabla` (pgAdmin) y uso correcto de `public.<tabla>`.
  - Fix Alembic: migraciÃ³n legacy `b7a1c2d3e4f5_add_billing_subscriptions.py` ahora es self-contained (sin import a `app.core.custom_types`) para que `alembic current` y el loader de revisiones no fallen.
  - Fix Alembic: se agregÃ³ `app.core.custom_types` como shim de compatibilidad (re-export de `GUID`) para desbloquear migraciones legacy que aÃºn importan ese path.
  - Se agregÃ³ stress test de importaciÃ³n (500 filas, 50 columnas sucias) para validar slugify, diccionario (solo activas) y aislamiento RLS entre tenants.
  - Slugify reforzado: `%` se normaliza a `porcentaje` para mantener claves estables en futuras consultas.
  - Se agregÃ³ `additional_attributes` (JSONB) en `inventario`, `inventario_lotes` y `movimientos_stock`.
  - Se creÃ³ `empresa_config_atributos` (por empresa + entidad) con RLS y policy estÃ¡ndar para exponer solo claves activas.
  - ImportaciÃ³n dinÃ¡mica de stock: captura automÃ¡tica de columnas no-core a JSONB con sanitizaciÃ³n tipo slugify y persistencia en `movimientos_stock`.
  - Se aÃ±adieron helpers de filtrado por diccionario y test de guardado/lectura + filtrado de atributos.

## 2026-03-21 (Backend - Limpieza final de app/services)

- **Infra - MCP (Add-on activable):**
  - Se agregÃ³ `app.core.infrastructure.mcp` con `create_mcp_app()` para exponer Tools read-only (`db_schema`, `db_select`) sobre DB_R (`reader_engine`) con validaciÃ³n estricta de identificadores y filtros.
  - El MCP permanece inactivo (503) si `MCP_ENABLED` estÃ¡ desactivado, si no hay Provider configurado (Local/External/Hybrid) o si falta token de autenticaciÃ³n (`MCP_AUTH_TOKEN`/secret).
  - El endpoint `/health` refleja el estado `active` considerando `MCP_ENABLED`.
  - `db_select` ahora acepta operadores equivalentes en filtros (`=`, `!=`, `<>`, `>`, `>=`, `<`, `<=`) ademÃ¡s de (`eq`, `neq`, `gt`, `gte`, `lt`, `lte`) para compatibilidad con LLMs.
  - `db_select` fuerza el scoping por `empresa_id` cuando la tabla lo soporta, ignorando filtros de `empresa_id` provistos por el cliente y aplicando el tenant del header.

- **Testing - IntegraciÃ³n MCP + LM Studio (modo Local):**
  - Se agregÃ³ `tests/test_mcp_connection.py` (skip por defecto) para validar function calling con Mistral vÃ­a LM Studio contra Tools MCP (`db_schema` + `db_select`) y lectura real de `empresas`.
  - El test valida el JSON devuelto por `db_select` (fuente de verdad) y tolera que el LLM no devuelva JSON estricto en su mensaje final.
  - Se ajustaron tipados para mantener compatibilidad con chequeos estÃ¡ticos cuando el test se analiza con mypy.
  - Se aÃ±adiÃ³ escenario de aislamiento multi-tenant: siembra 10 empresas + usuarios + productos, prompt malicioso de auditor global y aserciones anti-fuga (ningÃºn `empresa_id` fuera del tenant).
  - Se agregÃ³ teardown de limpieza con `TRUNCATE ... CASCADE` en schema `public` para evitar residuos y violaciones de FK en datos generados por listeners.
  - El escenario multi-tenant imprime la respuesta final del modelo en stdout para facilitar auditorÃ­a/diagnÃ³stico durante ejecuciÃ³n manual.
  - Se agregÃ³ `tests/test_rls_poc.py` (skip por defecto) para PoC de Row Level Security en Postgres: policy por `current_setting('app.current_empresa_id')` en `productos` y verificaciÃ³n anti-leak entre Empresa 1 y Empresa 2.

- **Core - CementaciÃ³n Multi-tenant (Infraestructura RLS):**
  - Full Core Hardening: RLS deployed to all tenant-scoped modules.
  - Se estandarizÃ³ una dependency `deps.get_tenant_db` que fija el contexto (`empresa_id`) y fuerza `set_config('app.current_empresa_id', ...)` al inicio de transacciÃ³n para activar RLS por request.
  - Se aÃ±adiÃ³ endpoint `GET /api/v1/ventas/productos/cementation` que consulta productos sin filtro explÃ­cito y delega el aislamiento a Postgres (RLS).
  - Se agregÃ³ migraciÃ³n Alembic para habilitar RLS y policy `tenant_isolation_policy` en `productos` y `clientes`.
  - Se agregÃ³ `tests/test_core_cementation.py` para verificar que el endpoint solo retorna datos del tenant aunque el ORM no filtre por `empresa_id` (paso de â€œAislamiento por Appâ€ a â€œAislamiento por Infraestructuraâ€).

- **DocumentaciÃ³n Viva - Living Map (MCP opcional):**
  - Se aÃ±adiÃ³ un nodo MCP con color Magenta/PÃºrpura, conectado a Backend y DB Replica para reflejar el flujo MCP â†’ DB_R.
  - Se agregÃ³ indicador visual de modo MCP (Local/External/Hybrid/Inactive) en el sidebar, respetando `MCP_ENABLED`.

- **DocumentaciÃ³n Viva - Living Map (auto-generado):**
  - Se agregÃ³ `.Documentacion/tools/generate_map.py` para escanear `backend/app/core/` y generar `.Documentacion/docs/infrastructure.html` (layout dark + secciÃ³n â€œMÃ³dulos Detectadosâ€).
  - Se mejorÃ³ el escaneo para cubrir todo `backend/app/` (Core, Core Modules, Addons, API, etc.) y agrupar paquetes en el sidebar.
  - Se reestructurÃ³ el generador para cumplir la regla de 600 lÃ­neas sin perder el modo â€œproductoâ€ (HTML/CSS/JS embebidos y compactados).
  - Se corrigiÃ³ un error de `SyntaxError` por llaves en f-strings, reemplazando la inyecciÃ³n de datos por un placeholder `__DATA__`.
  - Se aÃ±adiÃ³ hook `pytest_sessionfinish` para regenerar el mapa automÃ¡ticamente cuando `pytest` termina en verde (sin interrumpir el flujo de tests).

- **PaaS/CDC - PreparaciÃ³n Debezium (sin Docker):**
  - DB: chequeo informativo (no bloqueante) de `wal_level` y parÃ¡metros de replicaciÃ³n lÃ³gica en `writer_engine` bajo `ENVIRONMENT=development`.
  - Infra: se agregÃ³ `DebeziumPayload[T]` para estandarizar el contrato de eventos CDC.
  - Messenger: `KafkaBroker` resiliente con modo Mock (sin URL o sin librerÃ­as) y despacho automÃ¡tico de eventos con `visibility="public"` a tÃ³pico `erp3.public.<event_type>`.

- **Core - Barrido Total (ConsolidaciÃ³n final):**
  - Se eliminaron mÃ³dulos legacy en `app/core/` que colisionaban con los nuevos paquetes (`utils/`, `exceptions/`, `privacy/`, `infrastructure/`, etc.).
  - Se refactorizaron listeners (Compras/Finanzas/Ventas/AuditorÃ­a/Notificaciones) para evitar capturas genÃ©ricas, tipar payloads como `dict[str, Any]` y robustecer errores DB con `SQLAlchemyError`.
  - Tests: se actualizaron imports legacy en `tests/` para apuntar a `app.core.infrastructure.*` y `app.core.exceptions` (evita errores de colecciÃ³n por mÃ³dulos eliminados).
  - Tests: se removiÃ³ el import obsoleto `app.core.models` desde `tests/conftest.py` tras la limpieza de Core.
  - Calidad: `pytest -q` vuelve a ejecutarse en verde.

- **Arquitectura - EliminaciÃ³n definitiva de legacy services:**
  - Se migraron `feature_service`, `auditoria_service`, `ingestion_apply` e `import_service` a `app/core/services/` (incluyendo `import_service` como paquete).
  - Se actualizaron imports en mÃ³dulos Core (Inventario, Sistema, Service Engine, RRHH, TI) y en `app.core.services.ingestion_service`.
  - Se eliminÃ³ la carpeta `app/services/` completa.

## 2026-03-20 (Backend - Inventario: ImportaciÃ³n por Plantillas DinÃ¡micas)

- **Calidad - Lint/Typecheck:**
  - Se corrigieron imports no usados y tipado (mypy) en listeners de Webhooks/Ventas y en el manager del messenger.
- **Testing - Compatibilidad de overrides de DB:**
  - `app.core.database.get_db` ahora usa el `SessionLocal` exportado por el paquete para que los fixtures puedan sobrescribirlo (compatibilidad con `tests/conftest.py`).
- **API - SerializaciÃ³n segura (UUID/Datetime) en errores:**
  - Los handlers globales de excepciÃ³n ahora devuelven `model_dump(mode="json")` para evitar `TypeError: Object of type UUID is not JSON serializable` en respuestas de error.
- **Infraestructura - Plan â€œTriple Motorâ€ (Core):**
  - Se creÃ³ `app.core.database` como paquete y se movieron `database.py` y `custom_types.py` a `app/core/database/`, manteniendo compatibilidad de imports vÃ­a `app.core.database`.
  - Se creÃ³ `app.core.infrastructure` y se moviÃ³ la infraestructura base (`config`, `redis`, `events`, `queue`) a `app/core/infrastructure/` dejando re-exports en `app.core.*` para compatibilidad.
  - Se creÃ³ `app.core.infrastructure.messenger` con brokers `redis/rabbit/kafka (stub)` y un `manager` para despacho inteligente por carril.
  - Los listeners de Ventas y Webhooks ahora despachan trabajos vÃ­a `app.core.infrastructure.messenger.manager`.
- **Arquitectura - ReorganizaciÃ³n de Servicios (app/services -> app/core/*):**
  - Se creÃ³ el paquete `app.core.security` y se migrÃ³ la API pÃºblica de `security` (JWT + hashing) para mantener compatibilidad transparente con `from app.core.security import create_access_token` (y similares).
  - Se movieron servicios de seguridad a `app/core/security/`: `encryption_service.py`, `mfa_service.py`, `secrets_manager_service.py`, `security_audit.py`.
  - Se movieron servicios generales a `app/core/services/`: `pdf_generator.py`, `storage_service.py`, `ingestion_service.py`.
  - Se actualizaron imports en routers, mÃ³dulos core, herramientas y tests; y se eliminaron los mÃ³dulos legacy en `app/services/` que quedaron duplicados.
- **Multi-tenant - Fix de Integridad (`empresa_id` NOT NULL):**
  - FacturaciÃ³n (DTE): se asegurÃ³ la propagaciÃ³n de `empresa_id` al crear `DocumentoTributarioDetalle` en tests VIS (evita `NotNullViolation` en `documentos_tributarios_detalles`).
  - Ventas/CRM: se asegurÃ³ la propagaciÃ³n de `empresa_id` al crear `DetalleVenta` (evita `NotNullViolation` en `detalles_venta`).
  - Finanzas: se asegurÃ³ la propagaciÃ³n de `empresa_id` al crear `MovimientoContable` desde `accounting_service` (evita `NotNullViolation` en `movimientos_contables`).
  - Finanzas: se refactorizÃ³ `accounting_service/entries.py` a paquete `accounting_service/entries/` para cumplir la regla de archivos Python <= 600 lÃ­neas, manteniendo la API pÃºblica vÃ­a re-exports.
- **Arquitectura TO-BE (Addons) - Webhooks:**
  - Se moviÃ³ Webhooks desde `app/core_modules/webhooks/` a `app/addons/webhooks/` y se eliminÃ³ el mÃ³dulo Core para asegurar que el Core no dependa de esta feature.
  - El router del addon aplica feature-flag por empresa usando `sistema.portal_contracts.is_empresa_feature_enabled(..., "webhooks")` y retorna 404 cuando la feature no estÃ¡ activa (safe-fail).
  - El listener universal aplica gating por empresa antes de resolver configs y antes de enviar (evita disparos cross-tenant y permite que el addon sea opcional).
  - Se ajustaron tests/scripts para referenciar `app.addons.webhooks` y se removieron imports legacy a `core_modules.webhooks`.
- **Arquitectura TO-BE (Contratos) - Refactor Ventas:**
  - `ventas/services.py`, `ventas/tasks.py`, `ventas/api.py` y `ventas/listeners.py` dejaron de importar modelos de otros mÃ³dulos directamente, reemplazando acceso cross-mÃ³dulo por contratos/servicios.
  - Sistema: se ampliaron contratos en `sistema/portal_contracts.py` para auditorÃ­a, papelera, feature flags por empresa y utilidades de cupo/roles.
  - CRM: se agregÃ³ contrato `create_notification` en `crm/portal_contracts.py` para notificaciones sin importar modelos.
  - Finanzas: se agregÃ³ `has_asiento_for_origen` en `accounting_service` para validar bloqueo contable sin acceder a modelos de Finanzas desde Ventas.
- **DocumentaciÃ³n:**
  - Se actualizÃ³ `README.md` con la secciÃ³n de Carga Masiva de Inventario (Plantillas DinÃ¡micas), notas de bodegas/atributos adicionales y comandos de calidad.
- **Inventario - RegresiÃ³n Plantillas (compatibilidad + tolerancia a mapping corrupto):**
  - Se normaliza `mapping_json` para soportar formatos antiguos/nuevos y el caso donde el JSON venga como `str` (se hace `json.loads` antes de validar).
  - `additional_attributes` pasa a ser opcional con default `{}` en validaciÃ³n/lectura de plantillas; si viene `null` se trata como `{}`.
  - Si una plantilla tiene `mapping_json` invÃ¡lido o `null`, el sistema no rompe el listado; al usarla para procesar se devuelve un error de negocio claro (â€œPlantilla sin mapping vÃ¡lidoâ€).
- **Frontend - Inventario (Atributos Adicionales / Anti-duplicados):**
  - En â€œMapear Otros Atributosâ€, cada selector de â€œColumna Excelâ€ filtra headers en tiempo real para evitar duplicados contra campos base (SKU/Cantidad/Bodega/Costo) y otras filas.
  - Se deshabilita â€œ+ AÃ±adir Atributoâ€ cuando no quedan headers disponibles y se muestra feedback â€œTodos los headers han sido mapeadosâ€.
- **Inventario - Atributos Adicionales (Excel â†’ Staging):**
  - El mapeo dinÃ¡mico ahora soporta `additional_attributes` para capturar columnas extra del Excel (sin afectar los campos base SKU/Cantidad/Bodega/Costo).
  - En el procesamiento dinÃ¡mico, se sanitizan las claves de `additional_attributes` y se persisten en `staging_imports.raw_content._additional_attributes` sin omitir campos mapeados (se guarda `null` si la columna no existe o viene vacÃ­a).
  - El endpoint `GET /inventario/stock/massive/staging-errors` ahora incluye `raw_content` para que los atributos adicionales sean visibles en la previsualizaciÃ³n de errores.
- **Inventario - ImportService (Plantillas DinÃ¡micas):**
  - Se agregÃ³ `ImportService` para procesar Excel con `pandas` usando un diccionario de mapeo provisto por el usuario (columnas dinÃ¡micas).
  - Se implementÃ³ modo `STOCK_ADJUST` que resuelve `producto_id` por `sku` y `bodega_id` por `Bodega.codigo` (cÃ³digo tÃ©cnico), sin permitir creaciÃ³n de productos.
  - Se crean registros en `movimientos_stock` vinculados a `import_run_id` y se actualiza `Inventario.cantidad` al stock objetivo.
  - Si el SKU o la bodega no existen (o hay errores de parseo/aplicaciÃ³n), se registran filas fallidas en staging (`staging_imports` con `status=failed`) para revisiÃ³n vÃ­a endpoints existentes.
  - El `ImportRun.summary` guarda el `mapping` utilizado para trazabilidad/auditorÃ­a y se registra un `AuditLog` con el motivo del ajuste.
  - Se repusieron re-exports en `app.core_modules.inventario.models` para mantener compatibilidad con imports legacy usados por la suite de tests.
- **Inventario - ImportTemplates (Sistema de Plantillas):**
  - Se agregÃ³ la tabla `import_templates` (UUID, nombre, tipo_importacion, mapping_json, empresa_id) con unicidad por empresa+nombre.
  - Se agregÃ³ `POST /inventario/stock/massive/analyze-headers` para detectar headers del Excel (soporte de UI para selectores de mapeo).
  - Se agregÃ³ `GET /inventario/stock/massive/templates` para listar plantillas guardadas por empresa y tipo de importaciÃ³n.
  - `dynamic-stock-adjust` ahora soporta `template_id` opcional para reutilizar mapeos y `template_name` para auto-guardado/actualizaciÃ³n del mapping tras una importaciÃ³n exitosa.
  - ValidaciÃ³n de tipos: si la columna mapeada a `cantidad` no es numÃ©rica, se registra staging error con mensaje estandarizado `Error de tipo: la columna '<col>' no es numÃ©rica`.
  - Se refactorizÃ³ `ImportService` a paquete (`app/services/import_service/`) para cumplir la regla de archivos Python <= 600 lÃ­neas.
- **Frontend - Inventario (Mapeo DinÃ¡mico / UX):**
  - Se rediseÃ±Ã³ el modal de Carga Masiva a layout horizontal (2 columnas) con ancho mÃ¡ximo `1200px` y panel de headers con scroll.
  - La Carga Masiva incluye anÃ¡lisis de headers, selector de plantillas y formulario de mapeo editable (SKU/Cantidad/Bodega/Costo).
  - Se agregÃ³ opciÃ³n de guardar mapeo como plantilla (envÃ­o de `template_name`) y reintento guiado vÃ­a staging.
  - Si hay filas fallidas (`failed_rows > 0`), se navega automÃ¡ticamente a la vista de Existencias con `staging_key` para revisar errores.

## 2026-03-19 (Backend - Portal del Cliente: Fase 3/4)

- **Ajuste de Calidad y EstÃ¡ndares (Ruff):**
  - Se corrigieron imports no utilizados y variables ambiguas en Inventario Stock y Sistema Metrics para dejar `ruff check` en verde.
  - Se corrigieron re-exports del paquete `inventario` para evitar `ImportError` al iniciar Uvicorn (HistorialCosto/Inventario/MovimientoStock).
  - Se corrigieron imports de Inventario en `app.models` para no depender de `app.core_modules.inventario.models` (archivo vacÃ­o).
- **Super-Admin (SaaS) + Seguridad:**
  - Frontend: `/super-admin/clients/:id` permite `DEVELOPER` y `SUPERADMIN`.
  - Frontend: `ClientDirectory.vue` tipado (vue-tsc) para eliminar `implicit any` y errores de indexaciÃ³n en mÃ©tricas.
  - Backend: auditorÃ­a estandarizada (`AuditSeverity`): `HIGH -> WARNING`, `MEDIUM -> INFO`.
  - Inventario: `POST /inventario/stock/adjust` ahora requiere rol de empresa (`ADM/BOD/OPS`) o rol de plataforma permitido.
  - Admin: `toggle-active` ahora bypassa tenant activo (`allow_no_tenant=True`) para cambios globales.
  - Frontend: `admin.service.ts` tipado con `Empresa`, `RolLite`, `AdminCompanyUser` y payloads de administraciÃ³n por empresa.
- **DocumentaciÃ³n:**
  - Se actualizÃ³ `README.md` (estado del Frontend y fecha de Ãºltima actualizaciÃ³n).
  - Se creÃ³ `.Documentacion/roles_y_permisos.md` con el inventario de roles (plataforma/empresa/portal) y su impacto en el sistema.
- **Fase 4 - Cierre y Blindaje (Portal):**
  - Safe-Fail: `buyer` sin `scope_sucursales` queda sin acceso por defecto (filtros que devuelven vacÃ­o/404 segÃºn endpoint).
  - Se estandarizÃ³ el filtrado por sucursal vÃ­a `apply_portal_sucursal_scope` (quotes/documents/storage) para evitar accesos cross-sucursal sin filtrar existencia.
  - RBAC Portal: endpoints de Pagos quedan bloqueados para `buyer` con `403 Forbidden` claro.
  - Se corrigiÃ³ el orden de construcciÃ³n de query en `/mis-facturas` para evitar `InvalidRequestError` (filter despuÃ©s de LIMIT/OFFSET).
  - Tests: se agregÃ³ cobertura de infiltraciÃ³n cross-sucursal (404) y se ajustaron fixtures para usar `Sucursal` + `scope_sucursales` bajo Safe-Fail.
- **Hardening + Calidad:**
  - Se restringiÃ³ la respuesta del vendedor a roles por empresa `ADM/SUP/VEN` (vÃ­a `UsuarioEmpresa.rol.codigo`).
  - Se endureciÃ³ la validaciÃ³n para pasar a `PROPUESTA_ENVIADA`: no se permite si queda algÃºn Ã­tem (no eliminado) sin `precio_neto_final` o `fecha_entrega_linea`.
  - Se agregÃ³ `ruff` y `mypy` a dependencias y a reglas del proyecto para verificaciÃ³n obligatoria previa al cierre de tareas.
- **Fase 3 - Flujo Operativo de NegociaciÃ³n (Cliente/Vendedor):**
  - Se agregaron endpoints Portal para detalle de cotizaciÃ³n, ediciÃ³n de borrador (solo cantidades/notas), envÃ­o a vendedor (estado congelado) y rechazo de Ã­tems por el cliente.
  - Se agregÃ³ endpoint CRM para respuesta del vendedor a una propuesta (precio/alternativas por Ã­tem) con transiciÃ³n `PENDIENTE_VENDEDOR -> PROPUESTA_ENVIADA`.
  - Se ajustÃ³ el cÃ¡lculo de total para excluir Ã­tems con `estado_item=RECHAZADO_CLIENTE` al generar/aceptar la OC.
  - Se aÃ±adieron tests de integraciÃ³n del flujo: validaciÃ³n de â€œno editar precioâ€, congelamiento en `PENDIENTE_VENDEDOR` y exclusiÃ³n de Ã­tems rechazados.
- **Portal - Roles y Scope por Sucursal:**
  - Se extendiÃ³ `PortalUser` con `role` y `scope_sucursales` para habilitar control de acceso por sucursal.
  - Se actualizÃ³ la administraciÃ³n del Portal para gestionar `role/scope_sucursales`.
- **Portal - Endpoints y Aislamiento:**
  - `GET /portal/v1/mis-cotizaciones` ahora filtra por `scope_sucursales` vÃ­a `OportunidadVenta.sucursal_id` (manteniendo compatibilidad cuando es `NULL`).
  - Se endureciÃ³ la descarga de OC (storage) para evitar acceso cross-sucursal.
  - Endpoints de documentos/notificaciÃ³n de pagos aplican validaciÃ³n por `empresa_id/cliente_id` y, cuando corresponde, por sucursal asociada a la venta.
- **CRM - Motor de NegociaciÃ³n:**
  - Se extendiÃ³ `EstadoCotizacion` con estados de negociaciÃ³n y se agregÃ³ `vendedor_operador_id` para trazabilidad de suplencia.
  - Se incorporÃ³ `CotizacionItem` (`crm_cotizaciones_items`) para negociaciÃ³n a nivel de lÃ­nea.
  - Se agregÃ³ `sucursal_id` a `OportunidadVenta` para soportar el control por sucursal desde Portal.
- **DB - MigraciÃ³n Alembic:**
  - Se creÃ³/ajustÃ³ la migraciÃ³n `c91f71cbfb21_portal_roles_scope_and_quote_items.py` (columnas nuevas, backfill de `sucursal_id`, enum-safe y upgrade idempotente).
- **Tests:**
  - Se aÃ±adiÃ³ cobertura para filtrado por `scope_sucursales` en Portal y se alinearon asserts con el nuevo estado `ACEPTADA_OC`.

## 2026-03-18 (Entorno Local - Backend/Frontend)

- **Alembic - AuditorÃ­a y SincronizaciÃ³n de Esquema:**
  - Se exportÃ³ el listado de tablas existentes (`backend/tables_erp3_db.txt`) y el esquema completo (`backend/schema_dump_erp3_db.sql`) para trazabilidad.
  - Se aplicaron migraciones pendientes hasta `head` y se generÃ³/aplicÃ³ una nueva migraciÃ³n para sincronizar el esquema con los modelos actuales.
  - Se creÃ³ la migraciÃ³n `71b1b7e14b87_create_missing_crm_tables.py` que agrega las tablas faltantes `crm_cotizaciones`, `crm_entregas` y `crm_documentos`, incluyendo defaults a nivel DB y validaciones de precondiciÃ³n.

- **Backend - Entorno Python (Windows):**
  - Se creÃ³ el entorno virtual recomendado en `backend/.venv` usando Python 3.10 para mÃ¡xima compatibilidad de dependencias.
  - Se validÃ³ carga de `.env` y dependencias instaladas desde `backend/requirements.txt`.
- **Backend - Variables de Entorno:**
  - Se actualizÃ³ `.env.example` para incluir `EXTERNAL_API_KEY` y `TEST_DATABASE_URL` (requeridos por `Settings`/tests).
- **Backend - Arranque/Healthcheck:**
  - `GET /health` ahora bypassa el requisito de tenant para poder validar DB/Redis sin `cmp`.
  - `start_erp.bat` reconoce y activa `.venv` (ademÃ¡s de rutas legacy), mejorando el arranque en esta mÃ¡quina.
- **Backend - Tests (Infra):**
  - Se mitigÃ³ deadlock inicial en `tests/conftest.py` terminando conexiones activas del DB de test antes de recrear el esquema.
- **Frontend - ConfiguraciÃ³n API:**
  - Se aÃ±adiÃ³ `frontend/.env` con `VITE_API_URL=http://localhost:8000` para apuntar al backend local.
  - `DeliveryControl.vue` ahora usa el cliente Axios central (`services/api.ts`) y endpoints con prefijo `/api/v1`, asegurando token/params y consistencia.

## 2026-03-17 (Backend - Multi-tenant, AuditorÃ­a y Tests)

- **Backend - Seguridad Multi-tenant:**
  - Se eliminÃ³ el requisito de vÃ­nculo `Empleado` para autenticar `SUPERADMIN` en endpoints globales (evita 401 en administraciÃ³n SaaS como feature flags).
- **Backend - Webhooks (Multi-tenant):**
  - `WebhookConfig` ahora incluye `empresa_id` y el listener filtra por tenant, evitando disparos cross-tenant.
  - Los eventos `EVENT_COMPRA_RECIBIDA` y `EVENT_JOB_CREATED` ahora incluyen `empresa_id` en el payload para enrutar webhooks de forma segura.
- **Backend - CRM (Aislamiento + AuditorÃ­a):**
  - Se agregaron endpoints seguros para `GET /crm/opportunities/{id}` y `POST /crm/opportunities/{id}/prepare-signature` que respetan tenant y registran auditorÃ­a ante intentos cross-tenant.
- **Backend - Tests (Concurrencia + Onboarding):**
  - Se corrigiÃ³ el stress test de ventas concurrentes para setear `empresa_id` en `Session.info` por hilo, evitando fallos por contexto de tenant faltante.
  - Se aumentÃ³ `statement_timeout` a nivel de sesiÃ³n dentro del stress test para evitar timeouts al esperar locks (`SELECT ... FOR UPDATE`) bajo alta concurrencia.
  - Se ajustÃ³ el test de onboarding pÃºblico para incluir `password` y `confirmar_password` segÃºn el contrato del endpoint.

## 2026-03-16 (Backend - Contabilidad Ventas/Egresos y Tests)

- **Backend - Finanzas (Accounting Service):**
  - Se implementaron y exportaron entradas contables faltantes para ventas (`create_sale_entry`) y egresos (`create_expense_entry`, `create_expense_payment_entry`, `revert_expense_related_entries`).
- **Backend - Tests:**
  - Se ajustÃ³ el setup del test de integridad contable para fijar `costo_promedio` del producto y validar movimientos de Costo/Existencias.

## 2026-03-08 (DocumentaciÃ³n General)

- **DocumentaciÃ³n:**
  - **README:** Se actualizÃ³ `README.md` reflejando el estado operativo del Backend (v0.123.0) y el desarrollo activo del Frontend (Vue 3).
  - **InstalaciÃ³n:** Se agregaron instrucciones claras para levantar el entorno de desarrollo Frontend (`npm run dev`) y Backend.
  - **MÃ³dulos:** Se listaron los mÃ³dulos activos (Ventas, Inventario, Finanzas, etc.).

## 2026-03-06 (Frontend Ventas - Estructura y NavegaciÃ³n)

- **Frontend - Ventas (Estructura):**
  - **NavegaciÃ³n JerÃ¡rquica:** Se implementÃ³ el submenÃº lateral para el mÃ³dulo de Ventas con las secciones: Nueva Venta, Historial, Cotizaciones, Facturas y Notas de CrÃ©dito.
  - **Rutas Anidadas:** Se configurÃ³ el router para manejar rutas hijas bajo `/ventas/*` (ej. `/ventas/nueva-venta`).
  - **Vistas Placeholder:** Se crearon los componentes base para cada secciÃ³n del mÃ³dulo de ventas.
  - **Permisos por Rol:** Se actualizÃ³ `Sidebar.vue` para soportar filtrado de submenÃºs basado en roles de usuario.
  - **Testing:** Se aÃ±adiÃ³ `Sidebar.spec.ts` para validar la renderizaciÃ³n y lÃ³gica del menÃº lateral.


## 2026-03-04 (Frontend Inventario - Notificaciones y Reportes)

- **Frontend - Inventario (Experiencia de Usuario):**
  - **Notificaciones Real-Time:** Se implementÃ³ sistema de alertas tipo Toast para notificar al usuario cuando el stock de un producto cae por debajo del mÃ­nimo tras un movimiento.
  - **ExportaciÃ³n de Reportes:** Se habilitÃ³ la exportaciÃ³n de listados de inventario a formato PDF (vÃ­a `jspdf`) y CSV, incluyendo filtros activos.
  - **GestiÃ³n de Productos (UI):** Se finalizÃ³ el formulario de creaciÃ³n/ediciÃ³n de productos con soporte para trazabilidad (lotes/vencimiento).
  - **Registro de Movimientos (UI):** Se integrÃ³ el formulario de movimientos de stock con validaciÃ³n de lotes y selecciÃ³n de bodegas.
  - **NavegaciÃ³n Inventario:** Se convirtiÃ³ el acceso en submenÃº colapsable y se movieron las secciones a rutas /inventory/*.
  - **API Inventario:** Se corrigieron las llamadas del frontend para usar el prefijo /api/v1/inventario/*.

- **Backend - Compras/Inventario:**
  - Se corrigiÃ³ el import de `InventarioUbicacion` en listeners de compras para usar el modelo real de inventario.
- **Backend - Redis (ValidaciÃ³n de Entorno):**
  - En desarrollo, si Redis no responde, el sistema registra warning y continÃºa sin tareas de fondo.
  - En producciÃ³n, si Redis no responde, el arranque falla para evitar riesgos operativos.
- **Backend - Productos:**
  - Se agregÃ³ la columna `descripcion` en la tabla `productos` vÃ­a migraciÃ³n.

## 2026-03-03 (Onboarding PÃºblico, Registro RÃ¡pido y Contabilidad de Inventario)

- **Backend - Estabilidad Inventario (Tests y Concurrencia):**
  - **ProtecciÃ³n de Concurrencia:** Se implementÃ³ bloqueo de filas (`with_for_update`) en `check_expirations` para evitar condiciones de carrera al marcar lotes vencidos.
  - **Integridad Transaccional:** Se aÃ±adiÃ³ `rollback` explÃ­cito en `add_stock` para prevenir stock fantasma en fallos de asignaciÃ³n de lotes.
  - **Pruebas de EstrÃ©s:** Se validÃ³ el sistema con carga masiva de lotes (100+) y consumo concurrente simulado.
  - **VerificaciÃ³n Legacy:** Se certificÃ³ la compatibilidad con productos no trazables post-migraciÃ³n.

- **Backend - Inventario (FIFO y Trazabilidad):**
  - **Trazabilidad Total:** Se habilitÃ³ el rastreo de productos mediante el flag `es_trazable` en el modelo `Producto`.
  - **GestiÃ³n de Lotes:** Se creÃ³ el modelo `InventarioLote` para controlar fechas de vencimiento y estado (DISPONIBLE, BLOQUEADO, VENCIDO) por lote especÃ­fico.
  - **LÃ³gica FIFO/FEFO:** El consumo de stock (`consume_stock`) ahora prioriza automÃ¡ticamente los lotes por fecha de vencimiento (FEFO) y luego por fecha de entrada (FIFO), o permite seleccionar un lote especÃ­fico.
  - **Monitoreo de Vencimientos:** Se implementÃ³ `check_expirations()` en `InventoryService` para detectar y bloquear automÃ¡ticamente lotes vencidos.
  - **IntegraciÃ³n con ValorizaciÃ³n:** Se actualizÃ³ `ValuationService` para soportar cÃ¡lculo de costos especÃ­ficos por lote (`get_lot_cost`), manteniendo la compatibilidad con PMP global.

- **Backend - Inventario (Contabilidad AutomÃ¡tica):**
  - **Cierre del CÃ­rculo Contable:** Se implementÃ³ la generaciÃ³n automÃ¡tica de asientos contables para movimientos de inventario de tipo ajuste (MERMA, HALLAZGO, AJUSTE, CASTIGO, SOBRANTE).
  - **Event-Driven Architecture:** Se utiliza el evento `EVENT_MOVIMIENTO_STOCK_REGISTRADO` disparado desde `InventoryService` para desacoplar la lÃ³gica contable.
  - **Listener Financiero:** Se creÃ³ `handle_movimiento_stock_accounting` en `finanzas/listeners.py` que consume el evento y genera el asiento correspondiente.
  - **ClasificaciÃ³n AutomÃ¡tica:**
    - PÃ©rdidas (MERMA, CASTIGO, AJUSTE Negativo) -> Cargo a Gasto (5.2.07), Abono a Existencias (1.1.03.01).
    - Ganancias (HALLAZGO, SOBRANTE, AJUSTE Positivo) -> Cargo a Existencias (1.1.03.01), Abono a Ingresos (4.2.01.02).
  - **Testing:** Se aÃ±adiÃ³ test de integraciÃ³n `integration_accounting_stock_test.py` verificando el flujo completo desde el consumo de stock hasta el asiento contable.

- **Backend - Inventario (RefactorizaciÃ³n Completa):**
  - **ModularizaciÃ³n:** Se migrÃ³ el mÃ³dulo de inventario a `core_modules/inventario` con estructura clara: `catalogo`, `stock`, `movimientos`, `valorizacion`.
  - **Integridad Referencial:** Se configurÃ³ `CASCADE` para eliminar inventario al borrar Productos/Bodegas, y `RESTRICT` para evitar borrar Bodegas con movimientos.
  - **Testing:** Se implementaron tests de integridad (`tests/inventory_integrity_test.py`) validando la lÃ³gica de "Stock Reservado" (Disponible = FÃ­sico - Reservado) y reglas de borrado en cascada.
  - **Limpieza de CÃ³digo:** Se eliminaron modelos antiguos de `ventas/models.py` y se actualizÃ³ `inventory_service` para usar la nueva estructura.
  - **Backend - Inventario (ValorizaciÃ³n PMP):**
    - **Servicio de Costeo:** Se implementÃ³ `ValuationService` para cÃ¡lculo de Precio Medio Ponderado (PMP).
    - **AutomatizaciÃ³n:** Se integrÃ³ el recÃ¡lculo automÃ¡tico de PMP en entradas de stock (Compras/Ajustes Positivos).
    - **Historial de Costos:** Se creÃ³ el modelo `HistorialCosto` para auditorÃ­a de evoluciÃ³n de precios.
    - **Reporte de Valor:** Se aÃ±adiÃ³ mÃ©todo para obtener el Valor Total de Bodega (Stock * PMP).
    - **ProtecciÃ³n de Salidas:** Se garantizÃ³ que las ventas no alteren el PMP.


- **Backend - Onboarding:**
  - Se ampliaron campos del registro pÃºblico (rut, direcciÃ³n, telÃ©fono, ciudad) y se persistieron en Empresa/feature_flags.
  - Se consolidÃ³ el commit del onboarding para reducir latencia de creaciÃ³n inicial.
  - Se habilitÃ³ password en onboarding pÃºblico para permitir login posterior.
  - Se normaliza RUT sin puntos y se exige guion medio al guardar.
- **Frontend - Dashboard ERP:**
  - Se eliminaron valores hardcoded del dashboard general y se reemplazaron por estados sin datos.
- **OperaciÃ³n - Limpieza Lucas SPA:**
  - Se agregÃ³ script one-off para limpieza transaccional segura por empresa sin tocar Plan de Cuentas ni sucursales/bodegas.
- **Frontend - Registro y ConfiguraciÃ³n:**
  - Se agregaron campos al formulario de registro y se envÃ­an en el POST de onboarding.
  - Se evitÃ³ la llamada a `/admin/config` para usuarios sin rol SUPERADMIN/DEVELOPER.
  - Se aÃ±adieron Password y Confirmar Password con validaciÃ³n de coincidencia.

## 2026-03-02 (OptimizaciÃ³n Startup y Mejoras UX Finanzas)

- **Backend - Contabilidad:**
  - **Schema Update:** Se actualizÃ³ `MovimientoContable` en `schemas.py` para incluir el objeto `cuenta` anidado, permitiendo al frontend acceder a `codigo` y `nombre` de la cuenta.
  - **Query Optimization:** Se optimizÃ³ `get_libro_diario` en `entries.py` con `selectinload` para cargar eficientemente los movimientos y sus cuentas, evitando consultas N+1.

- **Frontend - Libro Diario:**
  - **Vista Detallada:** Se refactorizÃ³ la pestaÃ±a "Libro Diario" en `ContabilidadPage.vue` para mostrar los asientos contables agrupados (tarjetas), con detalle de movimientos (Debe/Haber por cuenta) y totales por asiento, reemplazando la tabla plana anterior que no mostraba informaciÃ³n correcta.

- **Backend - OptimizaciÃ³n de Inicio (Startup):**
  - **Lazy Loading en ConfigManager:** Se modificÃ³ `app/core/config_manager.py` para evitar conexiones sÃ­ncronas a la base de datos durante la importaciÃ³n de mÃ³dulos. Ahora la configuraciÃ³n se carga bajo demanda (lazy loading) al primer acceso, resolviendo bloqueos ("hangs") durante el inicio del servidor o la ejecuciÃ³n de tests.

- **Frontend - Mejoras de NavegaciÃ³n y UX:**
  - **Sidebar Desplegable:** Se implementÃ³ un submenÃº colapsable para el mÃ³dulo "Finanzas" en `Sidebar.vue`, agrupando ordenadamente "Dashboard", "Cierre de Caja", "Gastos" y "Contabilidad".
  - **Dashboard Interactivo:** Se actualizaron las tarjetas de KPIs en `FinanceDashboard.vue` para ser cliqueables, permitiendo la navegaciÃ³n directa a los mÃ³dulos operativos (ej. clic en "Ingresos" lleva a "Ventas", "Gastos" a "Gastos", "Utilidad" a "Contabilidad").

## 2026-03-02 (Finanzas - GestiÃ³n de Cierre Mensual Infranqueable)

- **Frontend - ImplementaciÃ³n de MÃ³dulos Contables Avanzados:**
  - **Balance de 8 Columnas (Vista):** Se integrÃ³ el componente `Balance8Columnas.vue` en la pÃ¡gina de Contabilidad, permitiendo visualizar el reporte tributario con filtros de fecha y opciÃ³n de incluir/excluir asiento de cierre.
  - **GestiÃ³n de Periodos (Vista):** Se creÃ³ el componente `GestionPeriodos.vue` para administrar el ciclo de vida contable desde el frontend.
    - **Listado de Periodos:** VisualizaciÃ³n clara de periodos abiertos/cerrados con sus fechas.
    - **Cierre de Periodo:** Flujo interactivo que muestra el "SemÃ¡foro de Integridad" antes de permitir el cierre. Si estÃ¡ en VERDE, muestra el resumen de saldos y permite confirmar.
    - **Reapertura de Periodo:** Flujo restringido que solicita motivo obligatorio para auditar la acciÃ³n.
    - **Visor de AuditorÃ­a (Snapshot):** Se implementÃ³ un visor de logs que permite consultar el historial de cierres y reaperturas, mostrando el "Snapshot" de los saldos (Activo, Pasivo, Resultado) guardados en el momento exacto del cierre.

- **Backend - API de AuditorÃ­a Contable:**
  - **Endpoint de Logs:** Se expuso `GET /contabilidad/periodos/{periodo_id}/audit-logs` para permitir al frontend recuperar la traza de auditorÃ­a especÃ­fica de cada periodo.
  - **Schema `AuditLogLite`:** Se creÃ³ un esquema ligero para transferir la informaciÃ³n de auditorÃ­a y los snapshots de saldos al frontend.

- **RefactorizaciÃ³n - Modularidad de Servicios Contables:**
  - **Paquete `accounting_service`:** Se transformÃ³ el archivo monolÃ­tico `accounting_service.py` (que excedÃ­a 600 lÃ­neas) en un paquete estructurado:
    - `accounts.py`: GestiÃ³n de Plan de Cuentas y saldos.
    - `periods.py`: LÃ³gica de Cierre, Apertura y SemÃ¡foro de Integridad.
    - `entries.py`: CreaciÃ³n de Asientos y Libro Diario.
    - `__init__.py`: ExportaciÃ³n unificada para mantener compatibilidad con `api.py`.

- **Reportes Contables:**
  - **Balance de 8 Columnas (Balance Tributario):** Se implementÃ³ la generaciÃ³n automÃ¡tica de este reporte esencial, clasificando las cuentas en Activo, Pasivo, PÃ©rdida y Ganancia segÃºn su tipo y saldo.
  - **Endpoint:** `GET /contabilidad/balance-8-columnas` con filtros por fecha y opciÃ³n de incluir/excluir asiento de cierre.
  - **ValidaciÃ³n y Pruebas:** Se aÃ±adiÃ³ un test robusto (`test_balance_8_columnas_coordinacion_codigos`) que certifica:
    - ClasificaciÃ³n correcta por rangos de cÃ³digo (1.x Activo, 2.x Pasivo, 4.x Ingreso, 5.x Gasto).
    - Manejo inteligente de **Saldos Contrarios**: Las cuentas de Activo con saldo acreedor (ej. sobregiros) se reclasifican automÃ¡ticamente en la columna de Pasivo, garantizando la presentaciÃ³n financiera correcta.

- **Backend - SemÃ¡foro de Integridad y RefundiciÃ³n:**
  - **SemÃ¡foro de Cierre (API):** Se expuso el endpoint `GET /periodos/{id}/integridad` que actÃºa como "SemÃ¡foro":
    - **VERDE:** Cuadratura perfecta (tolerancia 0.01 para redondeos) y cero gastos pendientes.
    - **ROJO:** Bloquea el cierre informando la diferencia exacta o la cantidad de documentos pendientes.
  - **RefundiciÃ³n de Resultados:** En el proceso de cierre (`cerrar_periodo`), el sistema ahora:
    - 1. Calcula la Utilidad/PÃ©rdida del ejercicio.
    - 2. Genera un asiento automÃ¡tico que deja en cero todas las cuentas de Ingreso (4) y Gasto (5).
    - 3. Transfiere el resultado neto a la cuenta patrimonial "Resultados del Ejercicio" (auto-generada si no existe).

- **Backend - Blindaje de Periodos Contables:**
  - **Core Service:** Se implementÃ³ una lÃ³gica de validaciÃ³n robusta en `accounting_service.py` que actÃºa como "guardiÃ¡n" de la integridad contable.
  - **Middleware Interno:** Se creÃ³ la funciÃ³n `check_periodo_abierto(db, empresa_id, fecha)` que verifica si la fecha de operaciÃ³n corresponde a un periodo cerrado. Si es asÃ­, lanza un `BusinessRuleError` bloqueante.
  - **IntegraciÃ³n Total:** Esta validaciÃ³n se inyectÃ³ en **todos** los puntos de creaciÃ³n de asientos:
    - `create_asiento`: Asientos manuales.
    - `create_sale_entry`: Asientos automÃ¡ticos de ventas.
    - `create_expense_entry`: Provisiones de gastos.
    - `create_expense_payment_entry`: Pagos de gastos.
    - `registrar_pago_cliente`: Cobranzas.
  - **Background Tasks:** Se protegiÃ³ tambiÃ©n la generaciÃ³n asÃ­ncrona de asientos (listeners de Ã³rdenes de servicio) para evitar inconsistencias por procesos en segundo plano.

- **Backend - Funcionalidad de Cierre y Reapertura:**
  - **Modelo `PeriodoContable`:** Se reforzÃ³ con campos de auditorÃ­a (`usuario_cierre_id`) y validaciÃ³n de unicidad por mes/aÃ±o.
  - **Cierre de Mes (Hard Lock):**
    - Se implementÃ³ `cerrar_periodo` con validaciÃ³n estricta de **Cuadratura Contable** (Suma Debe == Suma Haber).
    - Se aÃ±adiÃ³ verificaciÃ³n de **Pendientes**: No permite cerrar si existen gastos en borrador o aprobaciÃ³n para ese mes.
    - Genera un **Log de AuditorÃ­a CrÃ­tico** (`CIERRE_MENSUAL_CONTABLE`) con snapshot de los totales.
  - **Reapertura Controlada (Super-Admin):**
    - Se implementÃ³ `abrir_periodo` restringido exclusivamente a usuarios con rol `ADMIN`.
    - Exige un **motivo explÃ­cito** (mÃ­nimo 10 caracteres) para proceder.
    - Genera una alerta de seguridad en el log de auditorÃ­a (`REAPERTURA_MENSUAL_CONTABLE`).

- **Tests - ValidaciÃ³n de Integridad:**
  - Se creÃ³ `test_finanzas_cierre_mensual.py` con escenarios completos:
    - Cierre exitoso y verificaciÃ³n de logs.
    - Bloqueo por descuadratura (asientos desbalanceados).
    - Bloqueo por gastos pendientes.
    - Intento fallido de creaciÃ³n de asientos en periodo cerrado.
    - Control de permisos y motivos para reapertura.
  - **Fix:** Se corrigiÃ³ `test_finanzas_cierre_mensual.py` para asegurar que el snapshot de auditorÃ­a capture correctamente los movimientos del periodo (soluciÃ³n a race condition de fechas en test).

## 2026-03-02 (Finanzas - Contabilidad Diferida y AuditorÃ­a)

- **Correcciones y EstabilizaciÃ³n:**
  - **Fix CrÃ­tico Modelo Gasto:** Se corrigiÃ³ la definiciÃ³n de `Gasto.proveedor_id` en `models.py` agregando el `ForeignKey("proveedores.id")` faltante, resolviendo errores de integridad referencial en SQLAlchemy.
  - **InicializaciÃ³n de MÃ³dulos:** Se agregaron archivos `__init__.py` en `core_modules/compras` y `core_modules/finanzas` para asegurar la correcta detecciÃ³n de mappers y evitar `InvalidRequestError` durante las pruebas.
  - **ValidaciÃ³n de Tests:** Se ajustaron y validaron exitosamente los tests de reglas de negocio (`test_finanzas_reglas_negocio.py`), confirmando la lÃ³gica de "Regla de Oro" (bloqueo de ediciÃ³n), Contabilidad Diferida (asientos de pago) y Periodos Cerrados (reversiÃ³n con fecha actual).

- **Backend - Contabilidad Diferida:**
  - Se actualizÃ³ el modelo `Gasto` (`finanzas/models.py`) incorporando estados (`PENDIENTE`, `PAGADO`, `ANULADO`), `fecha_vencimiento` y `documento_referencia`.
  - Se modificÃ³ `accounting_service.py` para generar asientos contables diferenciados: los gastos `PENDIENTE` abonan a "Cuentas por Pagar" (Pasivo), mientras que los `PAGADO` abonan a "Caja".
  - **Nuevo:** Se implementÃ³ `create_expense_payment_entry` para manejar la transiciÃ³n de `PENDIENTE` a `PAGADO`. Cuando un gasto se paga, se genera un segundo asiento que carga a "Cuentas por Pagar" y abona a "Caja", manteniendo la historia de la deuda.
  - Se ajustÃ³ `egresos_service.py` para detectar automÃ¡ticamente este cambio de estado y disparar el asiento de pago.
  - **Nuevo:** Se implementÃ³ lÃ³gica de reversiÃ³n masiva (`revert_expense_related_entries`) para anulaciÃ³n de gastos. Si un gasto pasa a `ANULADO`, el sistema busca todos los asientos asociados (provisiÃ³n original y pagos) y genera contra-asientos exactos (invirtiendo Debe/Haber) para anular el efecto contable sin borrar historia.
  - **ValidaciÃ³n (Regla de Oro):** Se bloqueÃ³ la ediciÃ³n del campo `monto` en gastos que ya estÃ¡n en estado `PAGADO`. Si el usuario necesita corregir el valor, se le obliga a Anular (reversiÃ³n) y crear un nuevo registro, garantizando la integridad de los asientos ya emitidos.
  - **Nuevo:** Se aÃ±adiÃ³ control de **Periodos Contables Cerrados**.
    - Se creÃ³ el modelo `PeriodoContable` (`finanzas/models.py`).
    - Se implementÃ³ `get_fecha_contable_valida` en `accounting_service.py`.
    - Al revertir un gasto, si el asiento original pertenece a un periodo CERRADO, la anulaciÃ³n se fuerza con fecha de **HOY** (para no alterar estados financieros pasados). Si el periodo estÃ¡ ABIERTO, se respeta la fecha original para "limpiar" el registro.
  - Se ajustÃ³ `egresos_service.py` para respetar la fecha de emisiÃ³n enviada por el frontend, permitiendo registros retroactivos fieles.
- **Backend - AuditorÃ­a y Seguridad:**
  - Se implementÃ³ registro automÃ¡tico en `AuditLog` al crear asientos de gastos, capturando actor, recurso y cambios crÃ­ticos (monto, estado).
  - Se reforzÃ³ la seguridad en consultas contables (`get_libro_diario`) aÃ±adiendo filtrado explÃ­cito por `sucursal_id` para consolidaciÃ³n multisucursal.
- **Backend - Dashboard Finanzas API:**
  - Se actualizÃ³ `/finanzas/dashboard-stats` para reflejar la contabilidad diferida:
    - **KPI Gastos**: Suma devengada (Pagados + Pendientes).
    - **KPI Flujo**: Solo considera gastos Pagados.
    - **KPI CXP**: Ahora se alimenta de Gastos Pendientes (reemplazando lÃ³gica anterior de OCs).
    - **Tablas**: "Top CXP" muestra facturas de proveedores pendientes por vencer.

## 2026-03-02 (Tests - InicializaciÃ³n de Esquema)

- Se centralizÃ³ la carga de modelos en tests importando `app.models` antes de `create_all`, asegurando que tablas como `clientes` existan.
- Se aÃ±adiÃ³ `drop_all` previo a `create_all` para garantizar una base de pruebas virgen en cada ejecuciÃ³n.
- Se creÃ³ explÃ­citamente el esquema `crm` antes de `create_all` para evitar fallos en tablas con `schema=crm`.
- Se ajustÃ³ el import de `CierreCaja` en tests para usar el add-on `pos_retail`.
- Se agregÃ³ el campo `observaciones` al modelo `Venta` para compatibilidad con servicios y tests.
- Se agregÃ³ auto-creaciÃ³n de suscripciÃ³n activa en tests para evitar 401 por middleware SaaS.
- Se actualizaron rutas de cierre de caja en tests al prefijo `/api/v1/pos`.
- Se ejecutÃ³ `ruff check . --fix --unsafe-fixes` para limpieza de estilo y variables muertas.
- Se agregÃ³ import explÃ­cito de `Limiter` en `main.py` para resolver error de Mypy.
- Se reemplazaron imports con `*` por imports explÃ­citos en `one-off-scripts/test_grand_slam.py`.
- Se tiparon middlewares y se ajustÃ³ el handler de rate limit para compatibilidad Mypy en `main.py`.

## 2026-03-01 (Dashboard de Finanzas Renovado)

- **Frontend - Nuevo Dashboard de Finanzas:**
  - Se reconstruyÃ³ completamente la vista `/finanzas/dashboard` (`FinanceDashboard.vue`) implementando un diseÃ±o de Grid con Tailwind CSS.
  - Se aÃ±adieron filtros reactivos para Rango de Fechas, Sucursal y Moneda.
  - Se implementaron 8 tarjetas de KPI con manejo de estados de carga y valores cero.
  - Se integraron grÃ¡ficos interactivos con `VueApexCharts`: Ãrea para Flujo de Caja y Donut para Gastos por CategorÃ­a.
  - Se aÃ±adieron tablas comparativas para Top 5 Cuentas por Cobrar y Pagar.
- **Backend - Dashboard API Extension:**
  - Se extendiÃ³ el endpoint `GET /finanzas/dashboard-stats` en `core_modules/finanzas/api.py` para soportar filtros (fecha, sucursal, moneda) y devolver un conjunto completo de datos: 8 KPIs, datos para grÃ¡ficos y tablas top 5.

## 2026-03-01 (Desacople de Caja Finanzas y CreaciÃ³n de Add-on POS Retail)

- **Infraestructura - CorrecciÃ³n de Build (EPERM):**
  - Se mitigÃ³ un error persistente de bloqueo de archivos en Windows (`EPERM: scandir`) configurando `tailwind.config.js` y `vite.config.js` para excluir explÃ­citamente la carpeta `views/finance` (eliminada pero bloqueada por el OS) del proceso de escaneo.
- **Backend - RefactorizaciÃ³n Modular:**
  - Se desacoplÃ³ completamente el mÃ³dulo de "Caja" del nÃºcleo de Finanzas, moviendo toda la lÃ³gica (modelos, esquemas, API) a un nuevo add-on independiente: `addons/pos_retail`.
  - Se eliminaron las referencias a `CierreCaja` y `Turno` en `core_modules/finanzas` (models, schemas, api).
  - Se actualizÃ³ `admin/stats.py` y `ventas/services.py` para importar `CierreCaja` desde su nueva ubicaciÃ³n en el add-on.
  - Se registrÃ³ el router del add-on en `api/v1/api.py` bajo el prefijo `/pos`.
- **Frontend - MigraciÃ³n y Dashboard:**
  - Se migrÃ³ la vista de Cierre de Caja a `addons/pos_retail/CajaPage.vue`.
  - Se implementÃ³ un nuevo **Dashboard de Finanzas** en `/finanzas/dashboard` que muestra mÃ©tricas clave: "Total por Cobrar" y "Total por Pagar" (basado en Ã“rdenes de Compra RECIBIDAS).
  - Se actualizÃ³ el Router para redirigir `/finanzas` al dashboard y proteger la ruta de Caja bajo el mÃ³dulo `POS_RETAIL`.
  - Se modificÃ³ el `Sidebar` para ocultar la opciÃ³n "Cierre de Caja" si el mÃ³dulo `POS_RETAIL` no estÃ¡ activo en la empresa.
  - Se creÃ³ un store modular de Pinia `pos_retail.js` para manejar la lÃ³gica de caja, separÃ¡ndola del store de Finanzas.


- **Backend - GestiÃ³n de Clientes (Ventas/CRM):**
  - Se habilitÃ³ la creaciÃ³n y ediciÃ³n de clientes con lÃ³gica diferenciada por roles (CRM vs ADM) en `api.py`.
  - CRM: CreaciÃ³n permitida forzando valores seguros (`limite_credito=0`, `condicion_pago=CONTADO`) para evitar errores de permisos (403). EdiciÃ³n restringida de campos crÃ­ticos (RUT, CrÃ©dito).
  - ADM: Acceso total a todos los campos.
  - ImplementaciÃ³n de endpoint `/api/v1/ventas/clientes/by-rut` para bÃºsqueda por RUT.
  - CorrecciÃ³n de `schemas.py`: Se aÃ±adieron campos faltantes (`giro`, `ciudad`, etc.) y se implementÃ³ normalizaciÃ³n de RUT con formato canÃ³nico (12345678-K) para asegurar consistencia.
- **Frontend - Experiencia de Usuario en Clientes:**
  - `ClienteDetailPage.vue`: Se implementÃ³ alerta visual de duplicidad de RUT con botÃ³n de acciÃ³n rÃ¡pida para redirigir al cliente existente.
  - Se aÃ±adieron validaciones visuales para campos obligatorios (RUT, Giro, DirecciÃ³n) requeridos para facturaciÃ³n.
- **Infraestructura y Base de Datos:**
  - Se corrigiÃ³ error crÃ­tico `UndefinedTable: company_subscriptions` ejecutando script de inicializaciÃ³n `fix_db_subscription.py`. Esto resuelve el error 403 en `tenant_suspension_middleware` que bloqueaba operaciones de escritura en el CRM.
  - CorrecciÃ³n de `TypeError: 'giro' is an invalid keyword argument`: Se actualizÃ³ `models.py` agregando los campos `giro`, `ciudad` y `condicion_pago` a la tabla `clientes`.
  - **Migraciones Alembic:** Se generÃ³ y aplicÃ³ una nueva migraciÃ³n limpia `2245b025d55c_add_cliente_fields_clean.py` que aÃ±ade oficialmente las columnas faltantes. Se verificÃ³ la integridad de la base de datos con `verify_cliente_columns.py`.
  - **Despliegue:** Se creÃ³ el script `backend/prestart.sh` para asegurar que las migraciones se ejecuten automÃ¡ticamente al iniciar el contenedor/hosting, evitando errores de esquema en el primer despliegue.

## 2026-03-01 (Dashboard CRM Diferenciado)

- **Frontend - Acceso CRM a Clientes:**
  - Se habilitÃ³ la vista de Clientes (`ClientesPage.vue`) en la ruta `/crm/clientes` y se aÃ±adiÃ³ al menÃº lateral para usuarios con rol exclusivo CRM.
  - Se configurÃ³ la vista de Clientes en modo "solo lectura" para usuarios CRM (sin botones de crear/eliminar), permitiendo visualizaciÃ³n pero centralizando la gestiÃ³n en el ERP.
- **Frontend - Sidebar ERP:**
  - Se agregÃ³ el acceso directo a **Clientes** (`/ventas/clientes`) en el menÃº lateral del ERP, visible bajo el mÃ³dulo de Ventas.
- **Frontend - Dashboard CRM:**
  - Se implementÃ³ un Dashboard exclusivo para el mÃ³dulo CRM (`CrmPage.vue`) accesible en la ruta `/crm`.
  - Se incorporaron KPIs especÃ­ficos (Pipeline Activo, Ventas Ganadas, Tasa de ConversiÃ³n) en la parte superior de la vista CRM.
  - Se mantuvo la funcionalidad de Kanban y gestiÃ³n de oportunidades bajo la secciÃ³n de KPIs.
  - Se asegurÃ³ que los usuarios con rol CRM sean redirigidos automÃ¡ticamente a este dashboard diferenciado, sin acceso al dashboard ERP general.



