# Módulo de Auditoría - ERP3

**Última actualización**: 2026-02-11

---

## Descripción

El módulo de Auditoría proporciona un sistema de registro inmutable de eventos críticos del sistema, permitiendo trazabilidad completa de acciones sensibles.

---

## Características

- **Registro automático** de eventos críticos mediante listeners
- **Niveles de severidad**: INFO, WARNING, CRITICAL
- **Trazabilidad completa**: Actor, recurso afectado, cambios realizados
- **Registro de IP** para seguridad
- **Soporte para suplantación** (impersonation tracking)

---

## Modelo de Datos

### AuditLog

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `actor_id` | Integer FK | Usuario que ejecutó la acción |
| `impersonated_user_id` | Integer FK | Usuario suplantado (si aplica) |
| `action` | String | Acción realizada (ej: UPDATE_MODULES) |
| `resource` | String | Recurso afectado (ej: Empresa:1) |
| `severity` | Enum | INFO, WARNING, CRITICAL |
| `changes` | JSON | Cambios before/after |
| `ip_address` | String | IP del cliente |
| `created_at` | DateTime | Timestamp del evento |

---

## Eventos Auditados

### Eventos Críticos (CRITICAL)

- Rotación de credenciales Power BI
- Cambios en módulos activos de empresa
- Eliminación de datos importantes
- Cambios en roles de usuario

### Eventos de Advertencia (WARNING)

- Intentos de acceso no autorizado
- Cambios en configuración de empresa

### Eventos Informativos (INFO)

- Login exitoso
- Creación de registros
- Actualización de datos estándar

---

## Integración con Sistema de Eventos

El módulo se suscribe a **todos los eventos** del sistema mediante el EventDispatcher:

```python
# auditoria/listeners.py
from app.core.events import event_dispatcher, EVENT_ORDEN_FINALIZADA

async def on_orden_finalizada(event_data: dict):
    """Registra en audit log cuando se finaliza una orden"""
    # Lógica de auditoría
    pass

def register_listeners():
    event_dispatcher.subscribe(EVENT_ORDEN_FINALIZADA, on_orden_finalizada)
```

---

## Uso

### Registro Manual

```python
from app.services.security_audit import security_audit
from app.core_modules.sistema.models import AuditSeverity

security_audit.log(
    db=db,
    actor_id=current_user.id,
    action="UPDATE_EMPRESA",
    resource=f"Empresa:{empresa_id}",
    severity=AuditSeverity.CRITICAL,
    changes={"before": {...}, "after": {...}},
    request=request
)
```

### Consulta de Logs

```python
# Obtener logs de un usuario
logs = db.query(AuditLog)\
    .filter(AuditLog.actor_id == user_id)\
    .order_by(AuditLog.created_at.desc())\
    .all()

# Obtener logs críticos
critical_logs = db.query(AuditLog)\
    .filter(AuditLog.severity == AuditSeverity.CRITICAL)\
    .all()
```

---

## Mejores Prácticas

1. **Registrar acciones sensibles**: Cambios en permisos, datos financieros, configuración
2. **Incluir contexto suficiente**: Usar el campo `changes` para documentar qué cambió
3. **Severidad apropiada**: Usar CRITICAL solo para acciones de alto riesgo
4. **No registrar datos sensibles**: Evitar passwords en el campo `changes`

---

## Soft Delete y Recuperación

El sistema implementa **Soft Delete** para prevenir la pérdida accidental de datos críticos.

### Mecanismo

- **Columna `is_deleted`**: Booleano que indica si el registro está eliminado (True) o activo (False).
- **Columna `deleted_at`**: Timestamp de cuándo ocurrió la eliminación.
- **Mixins**: `SoftDeleteMixin` (en `app.core.mixins`) proporciona la funcionalidad estándar.

### Tablas con Soft Delete

- `clientes` (Clientes)
- `productos` (Productos)
- `ventas` (Ventas)
- `detalles_venta` (Detalles de Venta)
- `ordenes_servicio` (Órdenes de Servicio)

### Restauración de Datos

Los modelos con Soft Delete exponen un método `restore()`:

```python
# Ejemplo de restauración
cliente = db.query(Cliente).filter(Cliente.id == 1).first()
if cliente.is_deleted:
    cliente.restore(db)  # Resetea is_deleted=False y deleted_at=None
    # Automáticamente genera un log de auditoría (RESTORE)
```

---

## Replicación y Respaldos

### Replicación de Auditoría (Streaming Log)

El sistema implementa una replicación asíncrona de los logs de auditoría a un servidor externo para garantizar redundancia y no afectar el rendimiento de las operaciones principales (ventas).

- **Mecanismo**: `app.tasks.audit_sync.sync_audit_log_to_external`
- **Trigger**: Listener `after_commit` en la sesión de base de datos.
- **Cola**: Redis Task Queue (`default`).

### Respaldo Automático (Dump)

Se ha configurado un script para la generación de respaldos automáticos y su subida a la nube.

- **Script**: `backend/scripts/backup_and_upload.py`
- **Frecuencia Sugerida**: Cada 1 hora (configurar en Cron/Task Scheduler).
- **Destinos Soportados**: S3, Google Drive (requiere configuración de credenciales).

---

## Recursos Adicionales

- [Arquitectura del Sistema](arquitectura_sistema.md)
- [Guía de Worker Background Jobs](Guia_Worker_Background_Jobs.md)
