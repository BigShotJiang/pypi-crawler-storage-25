# Portal Cliente — Instrucción Frontend

## Contexto
Construir página frontend Vue 3 del Portal del Cliente.
Es un frontend SEPARADO del ERP, con su propio login y token.

## Base URL
/api/v1/portal/v1

## Auth
POST /auth/login
Body: { "empresa_codigo": "QUESOS594", "email": "...", "password": "..." }
Respuesta: { "access_token": "...", "token_type": "bearer" }
Token tiene aud="portal" — diferente al token del ERP interno.

## Axios setup
```js
const api = axios.create({ baseURL: "/api/v1/portal/v1" })
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("portal_token")
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})
```

## Vistas a construir (en orden)

### 1. Login
- empresa_codigo + email + password
- Guarda token en localStorage

### 2. Mis Cotizaciones
- GET /mis-cotizaciones
- Lista con estado, monto, fecha

### 3. Detalle Cotización
- GET /cotizaciones/{id}
- PUT /cotizaciones/{id}/borrador (editar cantidades)
- POST /cotizaciones/{id}/enviar-propuesta
- POST /cotizaciones/{id}/items/{item_id}/rechazar
- POST /cotizaciones/{id}/aceptar (upload PDF de OC)

### 4. Mis Facturas
- GET /mis-facturas
- GET /dtes/{id}/pdf
- GET /dtes/{id}/xml

### 5. Pagos (solo rol master/finance, NO buyer)
- POST /facturas/{id}/notificar-pago
- POST /registrar-pago

## Reglas importantes
- Roles: buyer y master ven cotizaciones
- Solo master/finance puede registrar pagos
- /admin/* NO usar desde este frontend
- Storage en modo local: GET /storage/download?path=...
- Storage en modo S3: usar URL firmada del endpoint

## Lo que NO debe mostrar
- Stock disponible — nunca
- Precios de costo — nunca
- Datos de otros clientes — RLS lo bloquea en backend