# Módulo de Facturación - ERP3

**Última actualización**: 2026-02-06

---

## Descripción

Módulo para generación de documentos tributarios electrónicos (DTE) según normativa SII Chile.

---

## Características

- Generación de Facturas Electrónicas (DTE 33)
- Generación de Boletas Electrónicas (DTE 39)
- Notas de Crédito y Débito
- Integración con SII
- Timbrado electrónico

---

## Tipos de Documentos

| Código | Tipo | Descripción |
|--------|------|-------------|
| 33 | Factura Electrónica | Para ventas a empresas |
| 39 | Boleta Electrónica | Para ventas a consumidor final |
| 56 | Nota de Débito | Aumenta monto de factura |
| 61 | Nota de Crédito | Disminuye monto de factura |

---

## Flujo de Facturación

```mermaid
sequenceDiagram
    participant V as Venta
    participant F as Módulo Facturación
    participant SII as SII
    participant DB as Base de Datos
    
    V->>F: Solicitar factura
    F->>F: Generar XML DTE
    F->>F: Firmar digitalmente
    F->>SII: Enviar DTE
    SII->>F: Validar y timbrar
    F->>DB: Guardar DTE
    F->>V: PDF + XML
```

---

## API

### Generar Factura

```http
POST /api/v1/facturacion/generar
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "venta_id": 123,
  "tipo_documento": "FACTURA_ELECTRONICA"
}
```

---

## Configuración

Requiere certificado digital del SII:

```env
SII_CERT_PATH=/path/to/cert.pfx
SII_CERT_PASSWORD=password
SII_AMBIENTE=CERTIFICACION  # o PRODUCCION
```

---

## Recursos Adicionales

- [SII - Facturación Electrónica](https://www.sii.cl/factura_electronica/)
