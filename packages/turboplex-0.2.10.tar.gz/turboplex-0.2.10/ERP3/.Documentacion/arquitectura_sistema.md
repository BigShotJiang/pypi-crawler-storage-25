﻿# Arquitectura del Sistema ERP3

**Última actualización**: 2026-03-22

---

## Visión General

ERP3 opera como monolito modular con separación estricta entre:
- **Core** (infraestructura transversal)
- **Core Modules** (dominios de negocio)
- **Add-ons** (extensiones opcionales)

Pilares vigentes:
- Modularidad por dominio
- Multi-tenant con `empresa_id` + RLS
- Mensajería por carriles con contexto **Air-Gap**
- Integraciones opcionales desacopladas (Portal, POS, Webhooks, MCP)

---

## Capas

1. **Presentación**: Vue 3 + Pinia + Router
2. **API**: FastAPI (`app/api`)
3. **Negocio**: `app/core_modules/*`
4. **Core**: `app/core/*` (database, infrastructure, security, exceptions, privacy, services, utils)
5. **Datos**: PostgreSQL + Alembic

---

## Estructura Backend (actual)

```text
backend/app/
  api/
  core/
    database/
    infrastructure/
      messenger/        # redis/rabbit/kafka
      mcp/              # opcional
    security/
    exceptions/
    privacy/
    services/
    utils/
  core_modules/
    sistema/
    ventas/
    finanzas/
    compras/
    crm/
    facturacion/
    inventario/
    rrhh/
    ti/
    service_engine/
    auditoria/
    notificaciones/
    analytics/
    billing/
    legal/
  addons/
    portal/
    pos_retail/
    webhooks/
  main.py
```

---

## Sistema Multi-tenant

- Toda operación es tenant-scoped por `empresa_id`.
- El contexto tenant se fija por request y se propaga a servicios/jobs.
- RLS refuerza aislamiento en tablas tenant-scoped.

---

## Mensajería y Air-Gap (estado vigente)

### Carriles
- **Redis**: cola rápida / jobs livianos.
- **RabbitMQ**: mensajería interna con confirmación.
- **Kafka**: salida pública/event streaming/CDC.

### Criterio Air-Gap
- El **Core** no depende de consumidores externos.
- Publicación hacia exterior por carril de eventos (Kafka) y add-ons.
- Integraciones externas no bloquean operaciones transaccionales del Core.

```mermaid
graph LR
  API[API/Core Modules] --> REDIS[(Redis)]
  API --> RABBIT[(RabbitMQ)]
  API --> KAFKA[(Kafka)]
  RABBIT --> W[Workers internos]
  REDIS --> W
  KAFKA --> EXT[Consumidores externos / Espejo]
  W --> DB[(PostgreSQL)]
```

---

## Eventos e Integraciones

- Eventos de dominio se despachan desde módulos de negocio.
- Add-on **Webhooks** opera fuera de Core (`app/addons/webhooks`).
- MCP es opcional y de sólo lectura según configuración.

---

## Seguridad

- Autenticación JWT + RBAC
- Restricción por módulos/feature flags por empresa
- Auditoría transversal de eventos críticos

---

## Referencias

- `CORE_MODULES.md`
- `ARQUITECTURA_CORE_MODULOS_ADDONS.md`
- `changelog.md`
