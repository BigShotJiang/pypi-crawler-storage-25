# 🚀 Guía de Inicio Rápido: ERP3

Este documento detalla los pasos necesarios para levantar el entorno de desarrollo completo (Backend + Frontend) en una máquina local.

## 📋 Requisitos Previos

- **Python 3.13+**: Para el backend.
- **Node.js 18+ y npm**: Para el frontend.
- **Git**: Para control de versiones.
- **Terminal**: PowerShell (Windows) o Bash (Linux/Mac).

---

## 🐍 1. Backend (FastAPI)

El backend maneja la lógica de negocio, base de datos y API.

### Configuración Inicial (Solo la primera vez)

1.  Navegar al directorio del backend:
    ```powershell
    cd e:\ERP3\backend
    ```

2.  Crear entorno virtual:
    ```powershell
    python -m venv .venv
    ```

3.  Activar entorno virtual:
    ```powershell
    # Windows (PowerShell)
    .\.venv\Scripts\Activate
    ```

4.  Instalar dependencias:
    ```powershell
    pip install -r requirements.txt
    ```

### Ejecución del Servidor

Para iniciar el servidor de desarrollo con recarga automática (hot-reload):

```powershell
# Asegúrate de estar en e:\ERP3\backend y tener el venv activado
python -m uvicorn app.main:app --reload
```

- **URL API**: [http://localhost:8000/api/v1](http://localhost:8000/api/v1)
- **Documentación Interactiva (Swagger)**: [http://localhost:8000/docs](http://localhost:8000/docs)

---

## 🎨 2. Frontend (Vue 3 + Tailwind)

El frontend es el Dashboard Técnico y la interfaz de usuario.

### Configuración Inicial (Solo la primera vez)

1.  Navegar al directorio del frontend:
    ```powershell
    cd e:\ERP3\frontend
    ```

2.  Instalar dependencias de Node:
    ```powershell
    npm install
    ```

### Ejecución del Servidor de Desarrollo

Para iniciar el servidor de Vite con recarga rápida:

```powershell
# Asegúrate de estar en e:\ERP3\frontend
npm run dev
```

- **URL Dashboard**: [http://localhost:5173/](http://localhost:5173/)

---

## 🛠️ Solución de Problemas Comunes

### Error: "La ejecución de scripts está deshabilitada en este sistema"
Si al activar el entorno virtual en PowerShell recibes este error, ejecuta:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Error: "ModuleNotFoundError" en Backend
Asegúrate de que el entorno virtual está activado (`(.venv)` debe aparecer al inicio de tu línea de comandos). Si persiste, reinstala dependencias: `pip install -r requirements.txt`.

### Error: Conexión rechazada en Frontend
Si el frontend no carga datos, verifica que el backend esté corriendo en el puerto 8000 y que no haya errores en la consola del backend.
