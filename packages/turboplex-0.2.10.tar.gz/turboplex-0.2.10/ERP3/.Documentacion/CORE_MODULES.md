﻿﻿﻿﻿# Módulos del Core (ERP3)

Este documento resume el estado actual de módulos Core y Add-ons del proyecto ERP3.

## 1. Service Engine (`app/core_modules/service_engine`)
- Orquestación de flujos por plantillas (workflow por industria).
- Formularios y metadata dinámica por estado.

## 2. Finanzas (`app/core_modules/finanzas`)
- Contabilidad, asientos, periodos, egresos y cierre mensual.
- Servicios contables desacoplados por paquetes.

## 3. Ventas (`app/core_modules/ventas`)
- Ciclo comercial y documentos asociados.
- Integración con inventario/finanzas vía contratos/eventos.

## 4. RRHH (`app/core_modules/rrhh`)
- Gestión de personal, asistencia y procesos de nómina.

## 5. TI (`app/core_modules/ti`)
- Gestión de activos y soporte operativo interno.

## 6. Sistema (`app/core_modules/sistema`)
- Seguridad, autenticación, usuarios, empresas/sucursales y features.
- Contratos transversales para módulos y add-ons.

## 7. CRM (`app/core_modules/crm`)
- Oportunidades, pipeline, cotizaciones, entregas y notificaciones.
- Contratos para consumo seguro desde add-ons (ej. portal).

## 8. Compras (`app/core_modules/compras`)
- Proveedores, órdenes de compra y recepción.

## 9. Facturación (`app/core_modules/facturacion`)
- DTE, folios/CAF e integración tributaria.

## 10. Inventario (`app/core_modules/inventario`)
- Catálogo, stock, movimientos y valorización.
- Soporte de variantes y atributos dinámicos.

## 11. Módulos Core transversales adicionales
- `auditoria`
- `notificaciones`
- `analytics`
- `billing`
- `legal`

## 12. Add-ons (fuera de Core)
- **Portal**: `app/addons/portal`
- **POS Retail**: `app/addons/pos_retail`
- **Webhooks**: `app/addons/webhooks`

## Notas de licenciamiento
- Base operativa: `CORE`, `VENTAS`, `FINANZAS`, `RRHH`, `TI`, `SISTEMA`.
- Módulos activables por empresa: `CRM`, `COMPRAS`, `FACTURACION`, `INVENTARIO`.
- Add-ons activables por empresa/feature: `PORTAL`, `POS`, `WEBHOOKS`.
