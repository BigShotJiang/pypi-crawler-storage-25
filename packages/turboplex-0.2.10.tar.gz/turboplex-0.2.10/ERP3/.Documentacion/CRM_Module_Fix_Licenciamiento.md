﻿# CRM Module Fix + Licenciamiento UI

## Contexto
- Empresa de prueba: queso SPRA (QUESOS594)
- UUID: 019c9d2b-53b0-7884-bc8b-5800d1d5cbc6
- Problema: CRM da 404 en todos sus endpoints
- Causa raÃ­z: CRM no estÃ¡ en modulos_activos de la empresa

## Estado actual de la DB
modulos_activos actual:
["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA", "CRM", "COMPRAS", "FACTURACION", "INVENTARIO", "POS", "PORTAL"]

Estado actual: módulos comerciales y add-ons de licenciamiento ya habilitados en ambiente de desarrollo.

Tabla usuarios_empresas tiene:
- usuario_id
- empresa_id  
- roi_id (no rol_empresa â€” ojo con esto)
- is_default

## Fix inmediato (ya aplicar en dev)
```sql
UPDATE empresas
SET modulos_activos = modulos_activos || '["CRM"]'::jsonb
WHERE codigo = 'QUESOS594';
```

## Problema 2 â€” 403 se convierte en 404
SegÃºn anÃ¡lisis del IDE:
- get_current_active_company devuelve 403 cuando mÃ³dulo no estÃ¡ activo
- Pero el frontend recibe 404
- Hay un exception handler que estÃ¡ transformando 403 â†’ 404
- Buscar en main.py o en los exception handlers globales
- Corregir para que 403 llegue como 403 al frontend

## Tarea principal â€” UI de Licenciamiento
PÃ¡gina: /super-admin/licensing/{empresa_id}
Estado actual: solo muestra Plan Standard/Enterprise y BI credentials
Lo que falta: panel de mÃ³dulos activables

### MÃ³dulos a implementar como toggles:
| MÃ³dulo | Clave en modulos_activos | DescripciÃ³n |
|--------|--------------------------|-------------|
| CRM | CRM | Pipeline, cotizaciones, entregas |
| Compras | COMPRAS | Ã“rdenes de compra, proveedores |
| FacturaciÃ³n | FACTURACION | DTE, CAF, SII |
| Inventario avanzado | INVENTARIO | Lotes, ubicaciones, trazabilidad |
| POS Retail | POS | Caja rÃ¡pida, cierre de caja |
| Portal cliente | PORTAL | Acceso externo para clientes |

### Endpoint existente para actualizar:
PATCH /api/v1/empresas/{empresa_id}
- Verificar que acepta modulos_activos en el body
- Si no lo acepta, agregar al schema Pydantic

### Comportamiento esperado del toggle:
- ON â†’ agrega el mÃ³dulo al array JSONB
- OFF â†’ lo remueve del array
- Cambio inmediato, sin recarga de pÃ¡gina
- Mostrar quÃ© mÃ³dulos estÃ¡n incluidos en cada plan (Standard vs Enterprise)

## Tarea secundaria â€” roi_id en usuarios_empresas
- La columna se llama roi_id no rol_empresa
- Verificar quÃ© tabla define los roles (probablemente tabla roles o similar)
- Asegurarse que el frontend de gestiÃ³n de usuarios muestra el rol correcto
- El IDE ya mostrÃ³ que u.role existe en tabla usuarios â€” 
  verificar si ese es el campo correcto o si roi_id apunta a otra tabla

## Archivos probables a modificar
- frontend/src/views/admin/LicenciamientoView.vue (o similar)
- app/core_modules/sistema/ (schema de empresa)
- app/core/deps.py (fix 403â†’404)
- main.py (revisar exception handlers)

## InstrucciÃ³n corta 
Leer este documento completo. 
Prioridad 1: aplicar el UPDATE de modulos_activos para QUESOS594.
Prioridad 2: encontrar dÃ³nde se transforma 403 en 404 y corregirlo.
Prioridad 3: construir los toggles de mÃ³dulos en la pÃ¡gina de licenciamiento http://localhost:5173/super-admin/licensing/{uuid}
usando PATCH /api/v1/empresas/{empresa_id}. 
Verificar primero que ese endpoint acepta modulos_activos en el body 
antes de construir el frontend.
