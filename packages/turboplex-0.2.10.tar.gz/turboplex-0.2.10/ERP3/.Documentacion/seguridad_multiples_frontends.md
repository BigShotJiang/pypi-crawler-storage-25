# Seguridad del Backend ante Múltiples Frontends

## Idea Central

- El frontend no es una frontera de seguridad.
- El backend decide acceso por identidad (usuario), tenant (empresa) y permisos (roles/scopes), no por “qué frontend llama”.

## Mecanismo Actual en ERP3

### Autenticación (JWT Bearer)

- El backend usa tokens JWT enviados en el header `Authorization: Bearer <token>`.
- El token se obtiene desde el endpoint de login `/api/v1/login/access-token`.

### Selección de Empresa (Tenant)

- La empresa activa se resuelve con prioridad:
  - `?cmp=CODIGO_EMPRESA` si se provee.
  - Empresa default del usuario.
  - Primera empresa asociada disponible.
- Una vez resuelta, el backend fija el contexto `empresa_id` en la sesión DB para aislar queries y habilitar RLS en Postgres cuando aplica.

### Autorización (RBAC)

- Las operaciones se autorizan por rol del usuario y su vinculación a la empresa (`UsuarioEmpresa -> Rol`).
- El backend debe responder con `403`/`404` según corresponda cuando el usuario no esté autorizado, sin filtrar datos de otro tenant.

## Qué Pasa si un Cliente Pide su Propio Frontend

- No cambia la seguridad base del backend.
- El nuevo frontend solo se convierte en “otro cliente” que debe:
  - Autenticarse (obtener JWT).
  - Llamar a la API con `Authorization: Bearer ...`.
  - Enviar `?cmp=...` cuando requiera operar en una empresa específica (si el usuario tiene más de una).

## Controles Imprescindibles para Soportar Varios Frontends

### 1. CORS (solo aplica a navegadores)

- CORS es un control del navegador, no un control de acceso real del backend.
- En ERP3 se usa una allowlist de orígenes permitidos en `ALLOWED_HOSTS` (configuración) para:
  - Permitir que el JS del frontend pueda llamar a la API desde su dominio.
  - Evitar llamadas cross-origin desde orígenes no autorizados en navegadores.
- Agregar un nuevo frontend implica agregar su origen (ej. `https://clienteX.tudominio.com`) a la allowlist del backend.

### 2. Headers Requeridos

- `Authorization: Bearer <token>` (obligatorio para recursos protegidos).
- `Content-Type: application/json` (cuando aplica).
- Opcionales según feature:
  - `X-Request-ID` (trazabilidad)
  - `X-Support-Mode: true` (modo soporte cuando el backend lo exija)

### 3. Tenant Seguro (Empresa)

- Nunca confiar en un `empresa_id` enviado por el frontend como “fuente de verdad”.
- El backend debe validar que el usuario pertenece a la empresa solicitada por `?cmp=...`.
- Las queries deben estar acotadas por `empresa_id` (y si hay RLS, debe estar correctamente activado en la conexión).

### 4. Rate Limiting y Abuso

- Independiente del frontend, el backend debe proteger endpoints sensibles (login, apply masivo, etc.) con rate limiting.
- Un segundo frontend no debe permitir que un cliente “robe” capacidad de rate limit de otro tenant (idealmente rate limit por usuario/empresa).

### 5. Auditoría

- Registrar eventos críticos: intentos cross-tenant, acciones sensibles, y operaciones masivas.
- Mantener consistencia de logs para investigar incidentes sin depender del frontend.

## Checklist Operativo (Cuando Aparezca un Segundo Frontend)

- Definir el/los orígenes del nuevo frontend (dominios exactos).
- Agregar orígenes a la allowlist (`ALLOWED_HOSTS`) en backend (producción sin comodines amplios).
- Validar que el frontend use `Authorization: Bearer ...` y que renueve token cuando expire.
- Validar que el frontend envíe `?cmp=...` solo cuando corresponda y que el backend lo valide contra `UsuarioEmpresa`.
- Confirmar que endpoints críticos estén rate limited.
- Verificar que en DB esté activo el aislamiento por tenant (filtros `empresa_id` y/o RLS).

## Nota sobre Cookies/Sesión (Para Futuro)

- Si en algún momento se migra a cookies/sesión, se debe agregar protección CSRF (obligatoria en ese modelo).
- Con JWT Bearer en header, CSRF es mucho menos relevante; el foco pasa a robo de token (XSS/almacenamiento inseguro).

## Mitigación de XSS y Robo de JWT

### Content Security Policy (CSP)

- El backend entrega un header `Content-Security-Policy` estricto para reducir superficie de XSS en navegadores.
- En producción, `/docs` y `/redoc` quedan deshabilitados para evitar que herramientas de documentación requieran CSP más permisivo.

### Sanitización y Renderizado de Inputs

- Sanitizar/escapar cualquier input del usuario antes de renderizarlo como HTML.
- Evitar `innerHTML` y equivalentes; preferir renderizado seguro por template/JS framework.

### Expiración de JWT

- El `exp` del JWT debe ser corto (máximo 60 minutos).
- En ERP3 el valor se controla con `ACCESS_TOKEN_EXPIRE_MINUTES` y en producción el backend no arranca si excede 60.

