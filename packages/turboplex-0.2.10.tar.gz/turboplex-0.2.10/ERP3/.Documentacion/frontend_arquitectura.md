# Frontend Vue3 ERP3 — Arquitectura y Estado

## Stack Tecnológico
- **Framework:** Vue 3 (Composition API con `<script setup>`)
- **Build:** Vite 5.x con proxy → `http://localhost:8000`
- **Estilos:** Tailwind CSS v4.1.18 con `@tailwindcss/postcss`
- **Estado:** Pinia (stores: auth, empresa, ventas, finanzas, billing, crm, holding)
- **HTTP:** Axios con interceptors JWT + `?cmp=CODIGO` automático
- **Gráficos:** ApexCharts via `vue3-apexcharts`
- **Notificaciones:** vue-toastification
- **Iconos:** @phosphor-icons/vue

## Estructura del Proyecto
```
src/
├── services/
│   └── api.js            — Axios + JWT + ?cmp automático + errores 401/403/429/504
├── stores/
│   ├── auth.js           — Login, logout, me()
│   ├── empresa.js        — Empresa activa, módulos activos, sucursales
│   ├── ventas.js         — Clientes, órdenes de servicio, POS
│   ├── finanzas.js       — Caja, gastos, proveedores, contabilidad
│   ├── billing.js        — Estado suscripción
│   ├── crm.js            — Oportunidades (useCRMStore)
│   └── holding.js        — Holding/subsidiarias
├── components/
│   ├── Sidebar.vue       — Menú dinámico por módulos activos + collapse + Proveedores
│   └── ui/
│       ├── KpiCard.vue   — Tarjeta KPI con color, trend, skeleton
│       ├── DataTable.vue — Tabla con slots por columna + skeleton
│       ├── Modal.vue     — Modal con Teleport + backdrop
│       └── Badge.vue     — Badge success/warning/error/info/neutral
├── views/
│   ├── Login.vue                          — Autenticación 2 paneles
│   ├── Dashboard.vue                      — KPIs + gráfico ApexCharts
│   ├── ModuloStub.vue                     — Stub reutilizable (ya no usado en rutas principales)
│   ├── public/RegisterPage.vue            — Onboarding empresa nueva
│   ├── ventas/ClientesPage.vue            — CRUD clientes
│   ├── ventas/OrdenesServicioPage.vue     — Tablero Kanban 4 estados
│   ├── ventas/PosPage.vue                 — POS con carrito + IVA
│   ├── finanzas/CajaPage.vue              — Apertura/cierre turno caja
│   ├── finanzas/GastosPage.vue            — CRUD gastos + filtro tipo
│   ├── finanzas/ContabilidadPage.vue      — Balance/PCU/Libro Diario
│   ├── finanzas/ProveedoresPage.vue       — CRUD proveedores + datos bancarios [NUEVO]
│   ├── rrhh/RrhhPage.vue                  — Empleados CRUD + Liquidaciones con preview [COMPLETO]
│   ├── crm/CrmPage.vue                    — Pipeline Kanban 3 columnas + firma digital [COMPLETO]
│   ├── ti/TiPage.vue                      — Job logs backend + estado sistema
│   ├── facturacion/FacturacionPage.vue    — CAFs SII listado + carga XML validada [NUEVO]
│   ├── legal/LegalPage.vue                — Documentos legales filtrable por estado [NUEVO]
│   ├── analytics/AnalyticsPage.vue        — KPIs + gráficos + top productos + export PDF [NUEVO]
│   └── configuracion/ConfiguracionPage.vue — Sucursales CRUD + Módulos toggle + Métodos pago [NUEVO]
├── router/index.js        — Lazy loading + guards auth/rol + TODAS las rutas reales
├── layout/
│   ├── ClientLayout.vue   — Layout principal con Sidebar
│   └── AdminLayout.vue    — Layout SuperAdmin
├── style.css              — Design system (CSS nativo, compatible Tailwind v4)
└── main.js                — Plugins: Pinia, Router, ApexCharts, Toast
```

## Funcionalidades por Módulo

| Módulo | Vista | Estado |
|---|---|---|
| Auth | Login + RegisterPage | ✅ Completo |
| Dashboard | Dashboard.vue | ✅ KPIs + gráfico |
| Ventas POS | PosPage.vue | ✅ Completo |
| Clientes | ClientesPage.vue | ✅ CRUD |
| Órdenes Servicio | OrdenesServicioPage.vue | ✅ Kanban |
| Finanzas Caja | CajaPage.vue | ✅ Apertura/Cierre |
| Gastos | GastosPage.vue | ✅ CRUD |
| Contabilidad | ContabilidadPage.vue | ✅ Balance/PCU/Libro |
| Proveedores | ProveedoresPage.vue | ✅ CRUD + bancario |
| RRHH | RrhhPage.vue | ✅ Empleados + Liquidaciones |
| CRM | CrmPage.vue | ✅ Kanban + firma digital |
| Facturación | FacturacionPage.vue | ✅ CAFs SII |
| Legal | LegalPage.vue | ✅ Documentos filtrable |
| Analytics | AnalyticsPage.vue | ✅ KPIs + gráficos + PDF |
| Configuración | ConfiguracionPage.vue | ✅ Sucursales + Módulos toggle |
| TI | TiPage.vue | ✅ Job logs |

## Design System (style.css)
Clases CSS nativas (NO @apply por incompatibilidad Tailwind v4):
- `.glass-card` — Glassmorphism dark
- `.btn-primary`, `.btn-secondary`, `.btn-danger` — Botones
- `.input-base`, `.label-base` — Formularios
- `.badge-{success,warning,error,info,neutral}` — Estados
- `.erp-table` — Tablas con estilos dark premium
- `.page-title`, `.section-header` — Layout de páginas

## Multi-tenancy
- `?cmp=CODIGO` se inyecta automáticamente en cada request via interceptor Axios
- `empresaStore.codigoActivo` contiene el código de la empresa activa
- `empresaStore.modulosActivos` controla qué ítems del Sidebar son visibles
- El Sidebar filtra el menú dinámicamente según `tieneModulo(modulo)`

## Autenticación
- JWT en `localStorage.token`
- Guard en router: carga usuario si hay token y no hay user en store
- Redirección post-login por rol: SUPERADMIN/DEVELOPER → `/dev-dashboard`, resto → `/dashboard`

## Estado del Build
```
npm run build → ✓ built in 17.23s (1655 módulos) — Exit code: 0
```

## Inventario (Alto Rendimiento)
- **Vista:** `src/views/inventory/InventarioGlobal.vue`
- **Objetivo:** navegación instantánea sobre ~23k registros sin bloquear UI.
- **Scroll Infinito:** se usa `IntersectionObserver` con un centinela al final del contenedor scrollable para pedir la siguiente página sin escuchar eventos de scroll en cada pixel.
- **Virtual Scrolling (windowing):** se renderiza solo la “ventana” visible de filas (altura fija + overscan) para mantener el DOM pequeño aunque se hayan cargado miles de registros.
- **Sincronización de URL (silenciosa):** `window.history.pushState` actualiza `?page=` y `?bodega=` sin recargar. `popstate` rehidrata el estado al navegar atrás/adelante.
- **Estado global de bodega:** `bodega=ALL` es el default y representa consolidado global (se omite `bodega_id` en el request). Al cambiar bodega se limpia el estado y se reinicia el scroll desde arriba de forma atómica.
- **Contrato backend:** los endpoints de inventario devuelven `X-Total-Count` en headers para que el frontend conozca el total sin procesar el payload completo (requiere CORS con `expose_headers=["X-Total-Count"]`).

## Pruebas E2E (Playwright)
- **Config:** `frontend/playwright.config.ts`
- **Specs:** `frontend/e2e/*.spec.ts`
- **Selectores estables:** se usan `data-testid` en `InventarioGlobal.vue` para evitar tests frágiles por cambios de estilos.
- **Cómo correr (dev):**
  - Levantar backend + frontend (ej.: `start_dev.bat`)
  - En `frontend/`:
    - `npm i`
    - `npx playwright install chromium`
    - `E2E_EMAIL=... E2E_PASSWORD=... npm run e2e`
