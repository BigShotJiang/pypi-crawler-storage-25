ryzen notebook

- Usuario : admin@erp3.com
- Contraseña : admin123
- Empresa : Empresa Principal (Código: MAIN )


- dev@erp3.com Contraseña actualizada a dev123 . http://localhost:5173/dev-login
- admin@erp3.com Contraseña actualizada a admin123 .


multi@erp3.com / admin123

