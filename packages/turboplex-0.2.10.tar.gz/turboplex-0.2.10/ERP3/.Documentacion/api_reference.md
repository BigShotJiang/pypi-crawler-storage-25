# Referencia de API - ERP3

**Última actualización**: 2026-02-06

---

## 📋 Tabla de Contenidos

- [Información General](#información-general)
- [Autenticación](#autenticación)
- [Módulo Sistema](#módulo-sistema)
- [Módulo Ventas](#módulo-ventas)
- [Módulo Finanzas](#módulo-finanzas)
- [Módulo RRHH](#módulo-rrhh)
- [Módulo TI](#módulo-ti)
- [Módulo Facturación](#módulo-facturación)
- [Módulo Compras](#módulo-compras)
- [Background Jobs](#background-jobs)
- [Códigos de Error](#códigos-de-error)

---

## Información General

### Base URL

**Desarrollo**: `http://localhost:8000`  
**Producción**: `https://api.erp3.com` (pendiente)

### Versionado

Todos los endpoints están bajo el prefijo `/api/v1`

### Formato de Respuesta

Todas las respuestas son en formato JSON.

```json
{
  "id": 1,
  "nombre": "Ejemplo",
  "created_at": "2026-02-06T10:00:00"
}
```

### Documentación Interactiva

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

---

## Autenticación

### Obtener Token de Acceso

```http
POST /api/v1/login/access-token
Content-Type: application/x-www-form-urlencoded
```

**Parámetros**:
- `username` (string, required): Email del usuario
- `password` (string, required): Contraseña

**Respuesta Exitosa (200)**:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

**Ejemplo cURL**:
```bash
curl -X POST "http://localhost:8000/api/v1/login/access-token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@erp3.com&password=admin123"
```

### Usar Token en Requests

Incluir el token en el header `Authorization`:

```http
GET /api/v1/dashboard
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Obtener Usuario Actual

```http
GET /api/v1/users/me
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
{
  "id": 1,
  "email": "admin@erp3.com",
  "nombre": "Administrador",
  "role": "ADMIN",
  "empresa_id": 1,
  "sucursal_id": 1,
  "is_active": true
}
```

---

## Módulo Sistema

### Dashboard

```http
GET /api/v1/dashboard
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
{
  "mensaje": "Cargando dashboard para: Mi Empresa",
  "empresa_id": 1,
  "empresa_codigo": "EMP001",
  "user_role": "ADMIN",
  "user_email": "admin@erp3.com"
}
```

### Listar Empresas

```http
GET /api/v1/empresas?skip=0&limit=100
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
[
  {
    "id": 1,
    "rut": "76123456-7",
    "razon_social": "Mi Empresa S.A.",
    "nombre": "Mi Empresa",
    "codigo": "EMP001",
    "plan": "PREMIUM",
    "is_active": true,
    "bodegas_count": 3
  }
]
```

### Actualizar Empresa

```http
PATCH /api/v1/empresas/{empresa_id}
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "nombre": "Nueva Razón Social",
  "plan": "ENTERPRISE",
  "pwr_bi_enabled": true
}
```

**Respuesta (200)**: Objeto Empresa actualizado

### Obtener Ubicaciones (Sucursales y Bodegas)

```http
GET /api/v1/locations
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
[
  {
    "id": 1,
    "nombre": "Sucursal Centro",
    "codigo": "SUC001",
    "bodegas": [
      {
        "id": 1,
        "nombre": "Bodega Principal",
        "codigo": "BOD001"
      }
    ]
  }
]
```

### Rotar Credenciales Power BI

```http
POST /api/v1/empresas/{empresa_id}/rotate-bi-credentials
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
{
  "message": "Credenciales generadas correctamente",
  "credentials": {
    "host": "db.erp3.com",
    "port": 5432,
    "database": "erp3_db",
    "username": "bi_user_empresa_1",
    "password": "xK9#mP2$vL5@qR8!"
  },
  "warning": "Guarde estas credenciales. La contraseña no será visible nuevamente."
}
```

---

## Módulo Ventas

> **Nota**: Requiere módulo `VENTAS` activo en el contrato de la empresa.

### Crear Venta

```http
POST /api/v1/ventas
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "cliente_id": 1,
  "sucursal_id": 1,
  "metodo_pago_id": 1,
  "detalles": [
    {
      "producto_id": 5,
      "cantidad": 2,
      "precio_unitario": 15000
    }
  ],
  "observaciones": "Venta al contado"
}
```

**Respuesta (201)**:
```json
{
  "id": 123,
  "folio": "V-00123",
  "fecha": "2026-02-06T10:30:00",
  "total": 30000,
  "cliente_id": 1,
  "vendedor_id": 1,
  "detalles": [...]
}
```

### Listar Ventas

```http
GET /api/v1/ventas?skip=0&limit=50
Authorization: Bearer {token}
```

### Actualizar Estado de Orden de Servicio

```http
PUT /api/v1/ordenes-servicio/{id}/estado
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "estado": "EN_PROCESO",
  "observacion": "Iniciando proceso de lavado"
}
```

**Estados válidos**: `RECEPCIONADO`, `EN_PROCESO`, `LISTO_RETIRO`, `ENTREGADO`

---

## Módulo Finanzas

> **Nota**: Requiere módulo `FINANZAS` activo en el contrato de la empresa.

### Proveedores

#### Crear Proveedor

```http
POST /api/v1/proveedores
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "rut": "76987654-3",
  "razon_social": "Proveedor XYZ Ltda.",
  "giro": "Comercio al por mayor",
  "direccion": "Av. Principal 123",
  "telefono": "+56912345678",
  "email": "contacto@proveedorxyz.cl"
}
```

#### Listar Proveedores

```http
GET /api/v1/proveedores?skip=0&limit=100
Authorization: Bearer {token}
```

### Gastos

#### Crear Gasto

```http
POST /api/v1/gastos
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "descripcion": "Compra de insumos de oficina",
  "monto": 50000,
  "categoria": "OPERACIONAL",
  "sucursal_id": 1,
  "proveedor_id": 3
}
```

> **Nota**: Genera automáticamente asiento contable con IVA Crédito Fiscal.

#### Listar Gastos

```http
GET /api/v1/gastos?skip=0&limit=100
Authorization: Bearer {token}
```

### Cierre de Caja

#### Abrir Caja

```http
POST /api/v1/cierres-caja/abrir
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "sucursal_id": 1,
  "monto_inicial": 50000
}
```

#### Cerrar Caja

```http
POST /api/v1/cierres-caja/{cierre_id}/cerrar
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "monto_real_fisico": 245000
}
```

**Respuesta (200)**:
```json
{
  "id": 10,
  "fecha_apertura": "2026-02-06T08:00:00",
  "fecha_cierre": "2026-02-06T18:00:00",
  "monto_inicial": 50000,
  "ventas_totales_sistema": 195000,
  "monto_real_fisico": 245000,
  "diferencia": 0
}
```

### Contabilidad

#### Inicializar Plan de Cuentas

```http
POST /api/v1/contabilidad/init-pcu
Authorization: Bearer {token}
```

Inicializa el Plan de Cuentas Único (PCU) chileno para la empresa.

#### Listar Cuentas Contables

```http
GET /api/v1/contabilidad/cuentas?skip=0&limit=1000
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
[
  {
    "id": 1,
    "codigo": "1.1.01.01",
    "nombre": "Caja",
    "tipo": "ACTIVO",
    "nivel": 4,
    "es_imputable": true
  }
]
```

#### Crear Asiento Contable

```http
POST /api/v1/contabilidad/asientos
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "fecha": "2026-02-06",
  "glosa": "Asiento de prueba",
  "movimientos": [
    {
      "cuenta_id": 1,
      "debe": 100000,
      "haber": 0
    },
    {
      "cuenta_id": 15,
      "debe": 0,
      "haber": 100000
    }
  ]
}
```

> **Nota**: El asiento debe estar balanceado (Debe = Haber).

#### Libro Diario

```http
GET /api/v1/contabilidad/libro-diario?fecha_inicio=2026-01-01&fecha_fin=2026-01-31
Authorization: Bearer {token}
```

#### Libro Auxiliar (Compras/Ventas)

```http
GET /api/v1/contabilidad/libro-auxiliar?tipo=VENTAS&mes=1&anio=2026
Authorization: Bearer {token}
```

**Parámetros**:
- `tipo`: `VENTAS` o `COMPRAS`
- `mes`: 1-12
- `anio`: Año fiscal

#### Balance General

```http
GET /api/v1/contabilidad/balance-general?anio=2026
Authorization: Bearer {token}
```

---

## Módulo RRHH

> **Nota**: Requiere módulo `RRHH` activo. Roles permitidos: `ADMIN`, `SUPERADMIN`, `DEVELOPER`, `MANAGER_RRHH`.

### Empleados

#### Crear Empleado

```http
POST /api/v1/empleados
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "rut": "12345678-9",
  "nombre": "Juan",
  "apellido": "Pérez",
  "email": "juan.perez@empresa.cl",
  "telefono": "+56987654321",
  "cargo": "Operario",
  "sueldo_base": 500000,
  "tipo_contrato": "INDEFINIDO",
  "fecha_ingreso": "2026-01-15",
  "tipo_afp": "CAPITAL",
  "sistema_salud": "FONASA",
  "especialidades": ["LAVADO_SECO", "PLANCHADO"],
  "costo_hora": 3500
}
```

#### Listar Empleados

```http
GET /api/v1/empleados?skip=0&limit=100
Authorization: Bearer {token}
```

### Asistencia

#### Registrar Entrada

```http
POST /api/v1/empleados/asistencia/entrada
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "empleado_id": 5,
  "fecha": "2026-02-06"
}
```

#### Registrar Salida

```http
POST /api/v1/empleados/asistencia/salida
Authorization: Bearer {token}
Content-Type: application/json
```

### Liquidaciones de Sueldo

#### Preview de Liquidación

```http
POST /api/v1/empleados/liquidaciones/preview
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "empleado_id": 5,
  "mes": 1,
  "anio": 2026
}
```

**Respuesta (200)**:
```json
{
  "empleado": {...},
  "periodo": "2026-01",
  "haberes_imponibles": 550000,
  "haberes_no_imponibles": 50000,
  "total_haberes": 600000,
  "descuentos_legales": 120000,
  "liquido_a_pagar": 480000,
  "detalle": {...}
}
```

#### Confirmar Liquidación

```http
POST /api/v1/empleados/liquidaciones/confirmar
Authorization: Bearer {token}
Content-Type: application/json
```

> **Nota**: Genera automáticamente asiento contable.

---

## Módulo TI

> **Nota**: Requiere módulo `TI` activo. Roles permitidos: `ADMIN`, `DEVELOPER`.

### Activos TI

#### Crear Activo

```http
POST /api/v1/ti/activos
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "tipo": "LAPTOP",
  "marca": "Dell",
  "modelo": "Latitude 5520",
  "numero_serie": "SN123456789",
  "fecha_compra": "2026-01-10",
  "valor_compra": 800000,
  "asignado_a_id": 5,
  "estado": "EN_USO"
}
```

#### Listar Activos

```http
GET /api/v1/ti/activos?skip=0&limit=100
Authorization: Bearer {token}
```

---

## Módulo Facturación

> **Nota**: Requiere módulo `FACTURACION` activo.

### Generar Factura Electrónica

```http
POST /api/v1/facturacion/generar
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "venta_id": 123,
  "tipo_documento": "FACTURA_ELECTRONICA"
}
```

---

## Módulo Compras

### Órdenes de Compra

#### Crear Orden de Compra

```http
POST /api/v1/compras/ordenes
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "proveedor_id": 3,
  "fecha_entrega_estimada": "2026-02-15",
  "detalles": [
    {
      "producto_id": 10,
      "cantidad": 50,
      "precio_unitario": 5000
    }
  ]
}
```

#### Recepcionar Orden de Compra

```http
POST /api/v1/compras/ordenes/{id}/recepcionar
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "ubicacion_wms_id": 5,
  "observaciones": "Recepción completa"
}
```

> **Nota**: Dispara eventos:
> - Incrementa stock en ubicación WMS
> - Genera asiento contable (Debe: Existencias, Haber: Proveedores)

---

## Background Jobs

### Generar Reporte PDF

```http
POST /api/v1/jobs/generar-reporte-pdf
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "tipo_reporte": "VENTAS_MENSUAL",
  "mes": 1,
  "anio": 2026
}
```

**Respuesta (202)**:
```json
{
  "job_id": "abc123-def456",
  "status": "queued",
  "message": "Reporte encolado para procesamiento"
}
```

### Verificar Estado de Job

```http
GET /api/v1/jobs/{job_id}/status
Authorization: Bearer {token}
```

**Respuesta (200)**:
```json
{
  "job_id": "abc123-def456",
  "status": "finished",
  "result": {
    "file_url": "/reports/ventas_2026_01.pdf"
  }
}
```

---

## Códigos de Error

### Códigos HTTP

| Código | Significado | Descripción |
|--------|-------------|-------------|
| 200 | OK | Solicitud exitosa |
| 201 | Created | Recurso creado exitosamente |
| 202 | Accepted | Solicitud aceptada (procesamiento asíncrono) |
| 400 | Bad Request | Datos inválidos |
| 401 | Unauthorized | Token inválido o expirado |
| 403 | Forbidden | Sin permisos para el recurso |
| 404 | Not Found | Recurso no encontrado |
| 422 | Unprocessable Entity | Error de validación |
| 500 | Internal Server Error | Error del servidor |

### Formato de Error

```json
{
  "detail": "Descripción del error"
}
```

### Errores Comunes

#### Token Expirado

```json
{
  "detail": "Could not validate credentials"
}
```

**Solución**: Obtener nuevo token con `/login/access-token`

#### Módulo No Contratado

```json
{
  "detail": "Módulo no contratado o inactivo"
}
```

**Solución**: Verificar que la empresa tenga el módulo activo en `ContratoModulo`

#### Permisos Insuficientes

```json
{
  "detail": "No autorizado"
}
```

**Solución**: Verificar que el rol del usuario tenga acceso al endpoint

---

## Mejores Prácticas

### Paginación

Usar parámetros `skip` y `limit` para listas grandes:

```http
GET /api/v1/ventas?skip=0&limit=50
```

### Filtros por Fecha

Usar formato ISO 8601:

```http
GET /api/v1/contabilidad/libro-diario?fecha_inicio=2026-01-01T00:00:00&fecha_fin=2026-01-31T23:59:59
```

### Rate Limiting

> **Nota**: Implementación pendiente. Se recomienda no exceder 100 requests/minuto.

---

## Webhooks

El sistema puede notificar eventos a URLs externas (n8n, Zapier).

Ver documentación completa en [Webhooks_Module.md](Webhooks_Module.md).

---

## Recursos Adicionales

- [Arquitectura del Sistema](arquitectura_sistema.md)
- [Modelos de Datos](modelos_datos.md)
- [Guía de Configuración de Industrias](guia_configuracion_industrias.md)
