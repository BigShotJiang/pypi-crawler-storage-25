# Módulo de Notificaciones - ERP3

**Última actualización**: 2026-02-06

---

## Descripción

Sistema de alertas y notificaciones en tiempo real para eventos críticos del sistema.

---

## Características

- **Alertas de stock crítico**: Cuando el inventario baja del mínimo
- **Notificaciones de eventos**: Órdenes finalizadas, pagos recibidos
- **Múltiples canales**: Email, SMS, Push notifications
- **Priorización**: Urgente, Normal, Baja

---

## Tipos de Notificaciones

### Stock Crítico

Se dispara cuando:
- Stock actual < Stock mínimo
- Stock proyectado (considerando órdenes en proceso) < Stock mínimo

### Eventos de Negocio

- Orden de servicio lista para retiro
- Pago recibido
- Factura generada
- Liquidación de sueldo confirmada

---

## Integración con Eventos

```python
# notificaciones/listeners.py
from app.core.events import event_dispatcher, EVENT_STOCK_CRITICO

async def on_stock_critico(event_data: dict):
    """Envía notificación cuando stock es crítico"""
    producto = event_data['producto']
    bodega = event_data['bodega']
    
    # Enviar email al encargado de bodega
    send_email(
        to=bodega.encargado_email,
        subject=f"Alerta: Stock crítico de {producto.nombre}",
        body=f"El stock actual es {event_data['stock_actual']}"
    )

def register_listeners():
    event_dispatcher.subscribe(EVENT_STOCK_CRITICO, on_stock_critico)
```

---

## Configuración

```env
# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=notificaciones@erp3.com
SMTP_PASSWORD=password

# SMS (Twilio)
TWILIO_ACCOUNT_SID=ACxxxxx
TWILIO_AUTH_TOKEN=xxxxx
TWILIO_PHONE_NUMBER=+56912345678
```

---

## API

### Enviar Notificación Manual

```http
POST /api/v1/notificaciones/enviar
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "tipo": "EMAIL",
  "destinatario": "usuario@empresa.cl",
  "asunto": "Notificación importante",
  "mensaje": "Contenido del mensaje"
}
```

---

## Recursos Adicionales

- [Sistema de Eventos](arquitectura_sistema.md#sistema-de-eventos)
