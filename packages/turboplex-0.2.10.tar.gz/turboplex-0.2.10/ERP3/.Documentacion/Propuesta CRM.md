# 🏗️ Arquitectura del CRM "Blindado"

Esta propuesta define los pilares funcionales y técnicos para el nuevo módulo CRM, integrando el análisis de arquitectura para garantizar escalabilidad y robustez (SOLID, DRY, ACID).

---

## 1. Gestión de Identidad y Territorio

### 📄 Definición Funcional
- **Filtro de Integridad:** Registro basado estrictamente en **RUT único** para evitar duplicados y el caos contable de "Juan Pérez" vs "J. Pérez".
- **Identificadores Únicos (UUIDv7):** Aunque el RUT es la clave de negocio visible, todos los registros utilizan internamente **UUIDv7** (time-sortable) como Primary Key para optimizar la indexación en base de datos y facilitar la replicación distribuida.
- **Estructura Multizona:** Capacidad de gestionar un Cliente Corporativo con múltiples sucursales, asignando vendedores específicos por zona geográfica (ej. Vendedor A -> Calama, Vendedor B -> Santiago).
- **Propiedad de Cartera:** Los leads y clientes son activos de la **Empresa**, pero con visibilidad restringida (RLS) para el vendedor asignado ("Mi Cartera").

### 🔎 Análisis Técnico (Senior Architect Review)
- **✅ Pros:**
  - El uso del RUT como "Primary Key Lógica" garantiza integridad referencial cruzada con el ERP y evita la fragmentación de la deuda.
  - **UUIDv7:** Al ser ordenable por tiempo, reduce la fragmentación de índices B-Tree en PostgreSQL comparado con UUIDv4 aleatorio, mejorando el rendimiento de inserción a gran escala.
  - La separación de "Cliente" (Razón Social) y "Sucursal" (Punto de Venta) permite análisis de rentabilidad granular.
- **⚠️ Desafíos/Riesgos:**
  - **Experiencia de Usuario:** Un bloqueo estricto por RUT puede frustrar al vendedor si el cliente ya existe en otra zona.
- **🛡️ Mitigación:**
  - Implementar **Soft-Match** en frontend: Advertir "Este RUT ya existe en Zona Norte" en lugar de bloquear, permitiendo solicitar traspaso o compartir cuenta.

---

## 2. El Motor de Precios (La "Verdad del CRM")

### 📄 Definición Funcional
- **Listas Privadas:** Cada vendedor tiene acceso a su propia lista de precios o condiciones.
- **Lógica de Descuento ($X^{-5\%}$):** El CRM calcula el precio final basado en reglas (volumen, perfil), respetando un "piso" de rentabilidad.
- **Traspaso Directo (Inmutabilidad):** El precio pactado en el CRM viaja como un **valor estático** al ERP. El ERP **no recalcula** impuestos ni descuentos, evitando diferencias de redondeo ("The Penny Test").

### 🔎 Análisis Técnico (Senior Architect Review)
- **✅ Pros:**
  - **Single Source of Truth:** Elimina la discrepancia "Cotización vs Factura". Lo que ve el cliente es lo que se factura.
  - Cumple **SRP (Single Responsibility Principle):** El CRM negocia, el ERP contabiliza.
- **❌ Contras (Arquitectura de Datos):**
  - La propuesta original de "Listas Privadas Físicas" por vendedor escala mal ($O(n \times m)$). Si hay 10k productos y 50 vendedores, son 500k registros redundantes.
- **🛡️ Solución Propuesta (DRY):**
  - Implementar **Patrón de Políticas (Policy Pattern):** Usar una Lista Base + Modificadores Dinámicos (`BasePrice * SalesRepModifier`). Es $O(1)$ en almacenamiento y más fácil de mantener.

---

## 3. El Semáforo Financiero y "Visto Bueno"

### 📄 Definición Funcional
- **Validación de Crédito:** Dashboard en tiempo real de `Cupo Disponible` vs `Deuda Total` (Facturas + Órdenes en Curso).
- **Bypass de Operación:** Si el cliente está en "Rojo", el sistema bloquea. Un Supervisor (ADM) puede autorizar una **Excepción por Monto**.
- **Despachos Parciales:** Una excepción de $5MM permite múltiples despachos (ej. $2MM + $3MM) hasta agotar el saldo autorizado, sin pedir permiso nuevamente.
- **Respaldo Legal:** Obligatoriedad de adjuntar PDF (Carta de Compromiso) para auditoría legal.

### 🔎 Análisis Técnico (Senior Architect Review)
- **✅ Pros:**
  - Agilidad operativa sin perder control financiero. Reduce el "cuello de botella" de gerencia.
- **⚠️ Riesgo Crítico (Race Conditions):**
  - En un entorno concurrente, dos vendedores podrían consumir el mismo saldo de excepción simultáneamente si no se controla (ej. Autorizado $5MM, ambos despachan $3MM al mismo tiempo -> Deuda real $6MM).
- **🛡️ Solución Técnica (ACID):**
  - Implementar **Atomic Locks** o `SELECT FOR UPDATE` en la tabla de control de excepciones al momento de descontar el cupo. Transacciones atómicas obligatorias.

---

## 4. Flujos de Venta Inteligentes

### 📄 Definición Funcional
- **Venta de Mesón:** Interfaz simplificada ("Fricción Cero") para clientes de paso, capturando solo datos mínimos (Nombre/Celular) para engrosar la base de leads.
- **Conversión Atómica:** Botón único para transformar `Prospecto` -> `Cliente` + `Orden de Venta`, migrando todo el historial de interacciones.
- **Motivos de Pérdida:** Campo obligatorio al cerrar una oportunidad perdida (Business Intelligence).

### 🔎 Análisis Técnico (Senior Architect Review)
- **✅ Pros:**
  - Mejora la calidad de datos (Data Enrichment) progresiva.
  - Facilita el análisis de conversión (Funnel Analysis).

---

## 5. Eficiencia de Datos (Pilar Anti-Saturación)

### 📄 Definición Funcional
- **Timeline Limpio:** Registro de interacciones (llamadas, notas) en texto plano ligero.
- **Gestión Documental:** Los archivos pesados (PDFs, Imágenes) se almacenan en Object Storage (R2/S3), guardando solo la referencia (URL) en la BD.

### 🔎 Análisis Técnico (Senior Architect Review)
- **✅ Pros:**
  - Mantiene la base de datos ligera y rápida (Performance).
  - Reduce costos de backup y almacenamiento transaccional.

---

## 6. Garantías de Operación y Seguridad

### 📄 Definición Funcional
- **Idempotencia Crítica:** Todo envío de Orden de Venta desde el CRM al ERP debe incluir un `request_id` único (UUIDv7) para evitar duplicación de cargos ante fallos de red o reintentos automáticos.
- **Trazabilidad de Precios:** Registro histórico inmutable (Audit Log) de cualquier cambio en los modificadores de precio, permitiendo justificar variaciones de margen ante Gerencia.
- **Alertas de Excepción:** Notificaciones automáticas al ADM cuando el saldo de una excepción de crédito alcance el **80% de consumo**.
- **Workflow de Colaboración:** En caso de coincidencia de RUT (Soft-Match), habilitar un flujo formal de "Solicitud de Traspaso" o "Venta Compartida" con aprobación de supervisor, transformando el bloqueo en una oportunidad de colaboración.

### 🔎 Análisis Técnico (Senior Architect Review)
- **✅ Pros:**
  - **Robustez (Idempotencia):** Esencial en sistemas distribuidos. Previene el clásico error de "doble facturación" cuando el frontend reintenta un POST fallido.
  - **Compliance:** La trazabilidad de precios es vital para auditorías internas y prevención de fraude.
  - **Proactividad:** Las alertas permiten actuar antes de que el vendedor se quede bloqueado nuevamente.
- **⚠️ Desafíos:**
  - **Overhead:** Registrar cada cambio de precio puede generar mucho volumen de datos.
- **🛡️ Mitigación:**
  - Usar una tabla dedicada `precio_audit_log` con particionamiento mensual o retención limitada (ej. 1 año) si el volumen es excesivo.
