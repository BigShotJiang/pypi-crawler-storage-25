🛠️ Ticket de Implementación: "Módulo de Carga Masiva Segura (RBAC)"
Objetivo: Exponer el INGESTION_ENGINE (motor de staging) a través de una UI protegida por el rol ADM de empresa.

1. Backend: El Endpoint de Entrada (FastAPI)
Archivo: backend/app/core_modules/inventario/stock/api.py

Nuevos Endpoints (scoped a empresa activa + RBAC ADM):
- POST /api/v1/inventario/stock/massive/upload
- POST /api/v1/inventario/stock/massive/validate
- POST /api/v1/inventario/stock/massive/apply
- GET  /api/v1/inventario/stock/massive/staging-summary
- GET  /api/v1/inventario/stock/massive/staging-errors

Lógica:
1. Validar que el Rol.codigo de la empresa activa sea ADM (backend: resolve_user_role_code). Si no, 403.
2. Upload: recibir file (UploadFile) y cargar bytes a staging con ingestion_service.ingest_excel_bytes_to_staging(..., filename=staging_key).
3. Devolver staging_key (UUIDv7) + file_hash (sha256) para idempotencia/auditoría.
4. Validation: procesar staging → validated/failed vía ingestion_service.process_staging_to_production(..., source_filename=staging_key).
5. Apply: aplicar SOLO filas validated del staging_key con ingestion_service.apply_validated_inventory_to_production(..., source_filename=staging_key, file_hash=...).

2. Frontend: El Botón "Admin-Only" (Vue.js)
Archivo: frontend/src/views/inventory/InventarioGlobal.vue

Cambio:
1. Inyectar el botón de "Carga Masiva" (dark-mode) en el toolbar de la pestaña Stock.
2. Guardia de Vista: v-if="empresaStore.rolEmpresaActual === 'ADM'".
3. UI: reutilizar el Modal existente (frontend/src/components/ui/Modal.vue) para el flujo Upload → Validation → Apply, mostrando resumen y errores del staging.

3. Integración con Staging (Motor de 26 archivos)
Al terminar la carga al endpoint, el sistema debe redirigir (o mostrar) una vista de "Monitor de Importación".

Esta vista leerá de la tabla staging_imports para mostrarle al ADM si hay filas con error (RUTs inválidos, bodegas no existentes en sus 15 nodos, etc.) antes de presionar el botón final de "Confirmar y Aplicar a Producción".

4. Prueba de Validación (Playwright)
Test E2E: Crear un caso de prueba donde:

Un usuario BOD intenta entrar a la URL de carga (debe fallar/no ver el botón).

Un usuario ADM sube un Excel de prueba, valida los datos en Staging y aplica los cambios.

Verificar que el Stock en las 15 bodegas se actualice correctamente.
