# Configuración del Proyecto ERP3

**Última actualización**: 2026-02-22 00:00

---

## 🗄️ Base de Datos

### PostgreSQL

**Servidor**: localhost:5432  
**Estado**: ✅ Operativo

#### Base de Datos Principal
```
Nombre: erp3_db
Owner: erp3_user
Encoding: UTF-8
Estado: Conectada y Operativa
```

#### Credenciales de Aplicación
```
Usuario: erp3_user
Contraseña: erp3_pass_2026
Connection String: postgresql://erp3_user:erp3_pass_2026@localhost:5432/erp3_db
```

#### Configuración de Pool de Conexiones
Para garantizar la estabilidad en entornos de producción (hosting externo) y evitar "Gone Away" errors:

- `pool_pre_ping`: `True` (Verificación de salud antes de usar conexión)
- `pool_recycle`: `3600` (Reciclaje de conexiones cada 1 hora)
- `pool_size`: `20` (Conexiones activas)
- `max_overflow`: `10` (Exceso temporal permitido)

#### Credenciales de Superusuario
```
Usuario: postgres
Contraseña: keita_Izumi
```

> ⚠️ **IMPORTANTE**: Estas credenciales son para desarrollo. Cambiar en producción.

---

## 🔧 Backend (FastAPI)

### Configuración General

**Framework**: FastAPI 0.122.0  
**Python**: 3.13.3  
**Servidor**: Uvicorn 0.38.0  
**Puerto**: 8000  
**Host**: 0.0.0.0

### Variables de Entorno (.env)

```env
DATABASE_URL=postgresql://erp3_user:erp3_pass_2026@localhost:5432/erp3_db
SECRET_KEY=4x-8BZCx3pr3I8hl3tfxoy5rJx0MUYesdicBfzHMmDA
```

### Configuración CORS

Orígenes permitidos:
- `http://localhost:3000`
- `http://localhost:5173`

### Endpoints Disponibles

| Endpoint | Método | Descripción | Estado |
|----------|--------|-------------|--------|
| `/` | GET | Información del API | ✅ |
| `/health` | GET | Health check (DB + Redis) | ✅ |

### Seguridad y RBAC

- Aislamiento multi-tenant: inyección automática de empresa_id en consultas ORM.
- Mixin TenantAware disponible para modelos con empresa_id.
- RBAC por roles y scopes: dependencias ScopesChecker y CombinedGuard para rutas.
- Operaciones contables críticas protegidas con scope `finanzas:ledger:post`.
- Aprobación de Órdenes de Compra protegida con rol/scope (`compras:approve`).
- Gestión de Webhooks protegida con scope `webhooks:manage` y auditada en `AuditLog`.
| `/docs` | GET | Documentación Swagger | ✅ |
| `/redoc` | GET | Documentación ReDoc | ✅ |
| `/api/v1/*` | - | Endpoints de API v1 | 📝 Pendiente |

### Estructura de Directorios

```
backend/
├── app/
│   ├── api/
│   │   ├── v1/
│   │   │   └── endpoints/     # Endpoints de API
│   │   └── deps.py            # Dependencias
│   ├── core/
│   │   ├── config.py          # Configuración
│   │   ├── database.py        # Conexión DB
│   │   └── security.py        # JWT y seguridad
│   ├── models/                # Modelos SQLAlchemy
│   ├── schemas/               # Schemas Pydantic
│   ├── services/              # Lógica de negocio
│   └── main.py                # Aplicación principal
├── alembic/                   # Migraciones
├── .env                       # Variables de entorno
└── requirements.txt           # Dependencias Python
```

---

## 🎨 Frontend

### Estado Actual
✅ **Operativo (Vue 3 + Vite)**

- **Framework**: Vue 3 (Composition API)
- **Store**: Pinia
- **Router**: Vue Router
- **Estilos**: Tailwind CSS
- **Puerto Desarrollo**: 5173
- **Portal Técnico**: `/dev-dashboard` (Ojo de Dios)

### Estructura Principal
```
frontend/
├── src/
│   ├── components/
│   │   ├── dev/            # Componentes de Dev Portal
│   │   └── ...
│   ├── views/
│   │   ├── DevDashboard.vue
│   │   └── ...
│   ├── services/
│   │   ├── admin.service.js
│   │   └── ...
│   └── stores/
└── ...
```

### Opciones Propuestas

#### Opción 1: Vue 3 + Vite (Recomendado)
- Framework: Vue 3
- Build tool: Vite
- Router: Vue Router
- State: Pinia
- HTTP Client: Axios
- Puerto: 5173

#### Opción 2: Recuperar existente
- Pendiente de ubicación del backup

---

## 🔐 Seguridad

### JWT (JSON Web Tokens)

**Algoritmo**: HS256  
**Expiración**: 30 minutos  
**Secret Key**: Configurado en `.env` (OBLIGATORIO para persistencia)

### Logging

**Configuración**: Automática basada en ENVIRONMENT
- **Dev**: DEBUG (StreamHandler)
- **Prod**: INFO (StreamHandler)

### Hashing de Contraseñas

**Algoritmo**: bcrypt  
**Librería**: passlib

### Recomendaciones

- ✅ `.env` no debe estar en el repositorio
- ✅ Agregar `.env` al `.gitignore`
- ✅ Crear `.env.example` sin valores sensibles
- ⚠️ Cambiar SECRET_KEY en producción
- ⚠️ Usar variables de entorno en producción
- ⚠️ Implementar rate limiting

---

## 🚀 Comandos de Desarrollo

### Backend

**Iniciar servidor**:
```bash
cd backend
python -m uvicorn app.main:app --reload
```

**Crear base de datos**:
```bash
cd backend
python create_db.py
```

**Migraciones** (cuando se configuren):
```bash
cd backend
alembic revision --autogenerate -m "Descripción"
alembic upgrade head
```

### Frontend (cuando se implemente)

**Instalar dependencias**:
```bash
cd frontend
npm install
```

**Iniciar desarrollo**:
```bash
cd frontend
npm run dev
```

**Build producción**:
```bash
cd frontend
npm run build
```

---

## 📦 Dependencias Principales

### Backend (Python)

```
fastapi>=0.110.0
uvicorn[standard]>=0.29.0
sqlalchemy>=2.0.29
alembic>=1.13.1
psycopg2-binary>=2.9.9
pydantic>=2.7.0
pydantic-settings>=2.2.0
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
python-dotenv>=1.0.1
```

### Frontend (cuando se implemente)

```json
{
  "vue": "^3.x",
  "vite": "^5.x",
  "vue-router": "^4.x",
  "pinia": "^2.x",
  "axios": "^1.x"
}
```

---

## 🌐 URLs del Proyecto

### Desarrollo

| Servicio | URL | Estado |
|----------|-----|--------|
| Backend API | http://localhost:8000 | ✅ |
| Swagger Docs | http://localhost:8000/docs | ✅ |
| ReDoc | http://localhost:8000/redoc | ✅ |
| Frontend | http://localhost:5173 | ⚠️ Pendiente |
| PostgreSQL | localhost:5432 | ✅ |

### Producción
⚠️ Pendiente de configuración

---

## 🔧 Solución de Problemas

### Error de Codificación UTF-8
**Síntoma**: `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xf3`  
**Causa**: Mensajes de error en español de PostgreSQL que `psycopg2` intenta decodificar como UTF-8 en Windows.
**Solución**: 
1. Usar credenciales correctas (evita el mensaje de error de autenticación).
2. Forzar encoding UTF-8 en consola (opcional).
**Script**: `backend/create_db.py` (Maneja la excepción y prueba credenciales)

### No se puede conectar a PostgreSQL
**Verificar**:
1. PostgreSQL está corriendo: `netstat -an | findstr :5432`
2. Credenciales correctas en `.env`
3. Base de datos existe: `psql -U postgres -l`

### Backend no inicia
**Verificar**:
1. Variables de entorno en `.env`
2. Dependencias instaladas: `pip list`
3. Puerto 8000 disponible

---

## 📝 Notas Adicionales

### Archivos Importantes

- **NO commitear**: `.env`, `__pycache__/`, `.venv/`
- **Sí commitear**: `.env.example`, `requirements.txt`, `alembic/`

### Próximos Pasos

1. ✅ Backend funcionando
2. ✅ Base de datos creada
3. 📝 Crear modelos de datos
4. 📝 Configurar Alembic
5. 📝 Implementar endpoints de API
6. 📝 Crear frontend
7. 📝 Integrar frontend con backend

---

## 🆘 Soporte

Para problemas o dudas:
1. Revisar este documento de configuración
2. Consultar `changelog.md` para cambios recientes
3. Verificar logs del servidor
4. Revisar documentación de FastAPI: https://fastapi.tiangolo.com
