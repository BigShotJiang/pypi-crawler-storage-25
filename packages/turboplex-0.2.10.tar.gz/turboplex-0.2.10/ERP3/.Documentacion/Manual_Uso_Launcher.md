# Manual de Uso - ERP3 System Launcher

## Descripción General
El script `start_erp.bat` es una herramienta de automatización diseñada para simplificar el inicio del entorno de desarrollo del backend de ERP3. Permite alternar rápidamente entre un modo ligero para programación y un modo completo para demostraciones y pruebas de integración.

**Ubicación del script**: `backend/start_erp.bat`

---

## Requisitos Previos

1.  **Python 3.10+**: Debe estar instalado y agregado al PATH.
2.  **Entorno Virtual**: Se recomienda tener el entorno virtual activado o las dependencias instaladas (`pip install -r requirements.txt`).
3.  **Docker Desktop** (Solo para Modo Demo): Debe estar instalado y ejecutándose para levantar Redis.

---

## Modos de Operación

Al ejecutar el script (`.\start_erp.bat`), verá un menú interactivo con dos opciones:

### Opción [1] - Modo Programación (Solo API)
**Perfil**: Desarrollo ágil, bajo consumo de recursos.

*   **Qué hace**:
    *   Inicia únicamente el servidor API (`uvicorn`).
    *   No levanta servicios en segundo plano (Redis/Workers).
*   **Cuándo usarlo**:
    *   Desarrollo de endpoints.
    *   Corrección de bugs lógicos.
    *   Tareas que no requieren auditoría diferida ni colas de tareas.
*   **Comportamiento**:
    *   La ventana de la terminal se mantiene abierta mostrando los logs de la API.
    *   Presione `Ctrl+C` para detener.

### Opción [2] - Modo Demo (Full Stack con Docker)
**Perfil**: Pruebas de integración, simulación de producción, demos.

*   **Qué hace**:
    1.  **Redis (Docker)**: Verifica si existe el contenedor `erp3-redis`. Si no existe, lo crea y ejecuta en el puerto `6379`. Si ya existe, lo inicia.
    2.  **RQ Worker**: Abre una nueva ventana de terminal y ejecuta el worker de colas (`rq worker`). Este proceso escucha tareas de auditoría y reportes.
    3.  **API Server**: Inicia la API en la ventana principal.
*   **Cuándo usarlo**:
    *   Verificar **Replicación de Auditoría**.
    *   Probar **Respaldos Automáticos**.
    *   Validar flujos asíncronos (envío de correos, generación de reportes pesados).
*   **Comportamiento**:
    *   Se abrirán múltiples ventanas.
    *   La API se conecta automáticamente al Redis gestionado por Docker (`localhost:6379`).

---

## Solución de Problemas Frecuentes

### 1. "Docker no se reconoce como un comando interno"
*   **Causa**: Docker Desktop no está instalado o no está en el PATH de Windows.
*   **Solución**: Instale Docker Desktop y reinicie la terminal.

### 2. "Error conectando a Redis" en el Worker
*   **Causa**: El contenedor Docker no pudo iniciar o el puerto 6379 está ocupado por otro servicio.
*   **Solución**:
    *   Verifique que Docker Desktop esté corriendo (icono de la ballena en la barra de tareas).
    *   Ejecute `docker ps` para ver si `erp3-redis` está activo.

### 3. El Worker se cierra inmediatamente
*   **Causa**: Probablemente no encuentra la conexión a Redis.
*   **Solución**: Asegúrese de seleccionar la opción [2] y esperar unos segundos a que el script confirme "Contenedor iniciado correctamente" antes de que se lance el worker.

---

## Comandos Útiles de Mantenimiento

Si desea limpiar el entorno de Docker manualmente:

```powershell
# Detener el contenedor
docker stop erp3-redis

# Eliminar el contenedor (para recrearlo limpio)
docker rm erp3-redis
```

## Inicio rápido (Frontend + Backend)

En la raíz del proyecto:

```powershell
.\start_dev.bat
```

front-end
npm run dev

backend
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
