# Módulo CRM (Customer Relationship Management)

## Descripción General
El módulo CRM permite gestionar el ciclo de vida de las ventas desde la prospección hasta el cierre, integrándose nativamente con los módulos de Ventas, Inventario y Finanzas del ERP.

## Arquitectura de Datos

### 1. Modelos Principales (`app/core_modules/crm/models.py`)

*   **Embudo (`crm_embudos`)**: Define el flujo de trabajo (ej: "Venta Corporativa").
*   **Etapa (`crm_etapas`)**: Etapas del embudo (ej: "Prospecto", "Negociación"). Incluye probabilidad de cierre.
*   **OportunidadVenta (`crm_oportunidades`)**: La entidad central. Vincula Cliente + Embudo + Monto + Productos.
    *   **Multimoneda**: Soporta `moneda` (UF, USD, CLP) y `monto_estimado`.
    *   **Crédito**: Incluye `estado_credito` (PENDIENTE, APROBADO, BLOQUEADO) y `fecha_inicio_analisis_credito` para control de riesgos.
    *   **Productos**: Relación con `Productos` a través de `DetalleOportunidad` (`crm_detalle_oportunidad`).
    *   **Bodega**: `bodega_id` almacena la bodega donde se reservó el stock durante la solicitud de crédito.
*   **Actividad (`crm_actividades`)**: Bitácora de interacciones (Llamadas, Reuniones, Correos).
*   **OportunidadComentario (`crm_oportunidad_comentarios`)**: Historial de comentarios, especialmente motivos de rechazo de crédito.
*   **Notification (`crm_notifications`)**: Alertas para usuarios (ej: retrasos en aprobación de crédito, rechazos).

### 2. Servicios (`app/core_modules/crm/services.py`)

*   **CRMService**: Lógica de negocio.
    *   `request_credit_approval(oportunidad_id, bodega_id)`:
        1.  Cambia estado de crédito a **PENDIENTE**.
        2.  Registra fecha de inicio de análisis.
        3.  **Reserva Stock** automáticamente llamando a `InventoryService` y guarda `bodega_id`.
    *   `reject_credit_approval(oportunidad_id, comentario)`:
        1.  Cambia estado a **BLOQUEADO**.
        2.  Guarda el motivo en `OportunidadComentarios`.
        3.  **Libera Stock** reservado usando `bodega_id`.
        4.  Envía **Notificación** inmediata al vendedor.
    *   `convert_opportunity_to_sale(oportunidad_id)`:
        1.  Valida estado y existencia.
        2.  Obtiene tasa de cambio vigente.
        3.  Crea registro en `ventas`.
        4.  **Consume Stock Reservado** (convierte reserva en salida física definitiva).
        5.  Actualiza estado a `GANADA`.

## Integración con Inventario
El CRM interactúa directamente con el `InventoryService` para asegurar disponibilidad:
*   Al solicitar aprobación de crédito (`PENDIENTE`), se reserva el stock físico de los productos asociados en una bodega específica.
*   Esto previene que se venda el mismo stock mientras se evalúa el riesgo crediticio.
*   Si se rechaza el crédito (`BLOQUEADO`), el stock se libera automáticamente para otros clientes.

## Tareas en Segundo Plano (Worker)
*   **Alerta de Retraso de Crédito (`check_credit_approval_delays`)**:
    *   Ejecutada periódicamente por el Worker.
    *   Busca oportunidades en estado `PENDIENTE` por más de 30 minutos.
    *   Genera una notificación interna (`Notification`) para el vendedor/supervisor.

## Flujo de Trabajo Típico

1.  Vendedor crea una **OportunidadVenta** y agrega productos (`DetalleOportunidad`).
2.  Solicita **Aprobación de Crédito**:
    *   Estado pasa a `PENDIENTE`.
    *   Stock se reserva.
3.  **Finanzas evalúa**:
    *   **Aprueba**: Estado `APROBADO`. Vendedor puede cerrar la venta.
    *   **Rechaza**: Llama a `reject_credit_approval` con motivo. Estado `BLOQUEADO`, stock liberado, vendedor notificado.
    *   **Demora**: Si > 30 min, se genera alerta automática.
4.  Al convertir a **Venta**, se consolida la transacción y se consume la reserva de stock.
