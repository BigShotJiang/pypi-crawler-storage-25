﻿# ðŸ”— MÃ³dulo de Webhooks (IntegraciÃ³n Universal)

Este mÃ³dulo permite la integraciÃ³n en tiempo real del ERP con sistemas externos (n8n, Zapier, Make) mediante el envÃ­o de notificaciones HTTP (Webhooks) ante cualquier evento del sistema.

## ðŸ—ï¸ Arquitectura

UbicaciÃ³n: `app/addons/webhooks/`

### Componentes

1.  **Modelo `WebhookConfig`**:
    *   Almacena la configuraciÃ³n de destinos.
    *   Campos: `event_name` (e.g., `EVENT_COMPRA_RECIBIDA`), `url` (Endpoint externo), `secret_key` (Seguridad).

2.  **Listener Universal (`listeners.py`)**:
    *   Utiliza la nueva capacidad `subscribe_all` del `EventDispatcher`.
    *   Intercepta **todos** los eventos que ocurren en el ERP.
    *   Verifica si existen webhooks activos para ese evento y los ejecuta.

### ðŸš€ Mecanismo de EnvÃ­o

El envÃ­o de webhooks estÃ¡ diseÃ±ado para **no bloquear** el flujo principal del ERP (Non-blocking I/O).

1.  **DetecciÃ³n**: El listener recibe un evento.
2.  **Consulta**: Busca configuraciones en DB (usando `run_in_executor` para no bloquear el Event Loop).
3.  **EnvÃ­o AsÃ­ncrono**: Utiliza `httpx` para enviar peticiones HTTP POST en paralelo (`asyncio.gather`).

### ðŸ”’ Seguridad

Para garantizar que los datos recibidos por el sistema externo provienen realmente del ERP, se incluyen encabezados de seguridad firmados:

*   `X-ERP3-Event`: El nombre del evento que originÃ³ la llamada.
*   `X-ERP3-Secret`: La clave secreta configurada para ese webhook especÃ­fico.

### Ejemplo de ConfiguraciÃ³n (n8n)

Para integrar con n8n:
1.  Crear un nodo "Webhook" en n8n (MÃ©todo POST).
2.  Registrar la URL generada en la tabla `webhooks_config` del ERP asociada al evento deseado (ej. `EVENT_NUEVO_CLIENTE`).
3.  Configurar un `secret_key` en el ERP.
4.  En n8n, usar un nodo "If" para validar que `Header: x-erp3-secret` coincida con la clave.

## ðŸš¨ Eventos de Sistema (Alertas CrÃ­ticas)

AdemÃ¡s de los eventos de negocio, el sistema dispara eventos automÃ¡ticos de infraestructura que pueden ser capturados por webhooks para monitoreo (DevOps/SRE):

### 1. PÃ¡nico de Base de Datos
*   **Evento**: `SYSTEM_ALERT_DB_PANIC` / `SYSTEM_ALERT_DB_TIMEOUT`
*   **Origen**: `app.core.database` (SQLAlchemy Listener)
*   **Disparador**: PÃ©rdida de conexiÃ³n, timeouts o errores fatales en el motor de base de datos.
*   **Payload**:
    ```json
    {
      "error_type": "OperationalError",
      "message": "server closed the connection unexpectedly",
      "timestamp": "2024-01-25T10:00:00",
      "severity": "CRITICAL",
      "source": "database.listener"
    }
    ```

### 2. Seguridad SuperAdmin
*   **Evento**: `SECURITY_ALERT_SUPERADMIN_FAILED_LOGIN`
*   **Origen**: `app.api.v1.login`
*   **Disparador**: Intento de inicio de sesiÃ³n con contraseÃ±a incorrecta en una cuenta con rol `SUPERADMIN`.
*   **Payload**:
    ```json
    {
      "user_email": "admin@erp3.com",
      "ip_address": "192.168.1.50",
      "timestamp": "2024-01-25T10:05:00",
      "severity": "CRITICAL",
      "details": "Intento de inicio de sesiÃ³n fallido..."
    }
    ```



