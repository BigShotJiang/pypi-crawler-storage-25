# Certificación de Pruebas de Integración - Fase 2
**Fecha:** 2026-02-10  
**Versión:** 1.0  
**Responsable:** Arquitectura de Sistema ERP3

Este documento certifica que los principios operativos de inventario y las reglas de negocio críticas para la integración CRM/Ventas han sido implementados y validados exitosamente mediante pruebas automatizadas de extremo a extremo.

## Resumen de Resultados

| ID | Escenario de Prueba | Estado | Observación |
|----|---------------------|--------|-------------|
| 1 | **Prueba de la "Talla 42"** (Aislamiento de Historial) | ✅ APROBADO | Las cotizaciones CRM no generaron ningún registro en `movimientos_stock` ni alteraron el saldo `inventario`. Ruido eliminado. |
| 2 | **Cliente Presencial** (Bypass de Stock) | ✅ APROBADO | El sistema detectó stock insuficiente, liberó automáticamente una reserva vencida (>24h) y permitió la venta nueva en la misma transacción atómica. |
| 3 | **Sustitución con Memoria** | ✅ APROBADO | La conversión de oportunidad registró la línea original como "Cancelada" y vinculó el producto sustituto mediante `sustituye_a_id`, permitiendo trazabilidad de demanda insatisfecha. |
| 4 | **Redondeo CLP y Tasa Muerta** | ✅ APROBADO | Se validó la alerta de tasa desactualizada (`rate_is_stale=True`). Se confirmó que la conversión a Venta en CLP fuerza redondeo matemático a entero (ej. 15000.44 -> 15000). |

## Detalle de Ejecución

### 1. Aislamiento Total del Inventario
*   **Acción:** Se crearon 3 Oportunidades (Cotizaciones) para el producto "Botin Talla 42".
*   **Validación:**
    *   Movimientos iniciales: 1 (Carga inicial)
    *   Movimientos finales: 1
    *   Stock Disponible: Intacto (10 unidades).
*   **Conclusión:** El CRM es invisible para la gestión física de inventarios hasta el momento de la venta real.

### 2. Prioridad Presencial (Bypass)
*   **Escenario:** Producto crítico "Ultimo Par" con stock=0 físico (1 reservado por venta antigua).
*   **Ejecución:** Intento de venta nueva activó el protocolo `release_stale_reservations`.
*   **Resultado:** 
    *   La reserva "OLD-..." fue conservada y marcada como **PENDIENTE_SIN_STOCK** (Estado de Espera).
    *   La Orden de Servicio asociada pasó a estado **EN_ESPERA_STOCK**.
    *   El stock fue revertido y re-asignado a la venta "NEW-..." en la misma transacción.
    *   **Cumplimiento:** Se respeta la regla de "No borrar historial" y se permite re-asignación futura.

### 3. Sustitución Inteligente
*   **Escenario:** Quiebre de stock en "Prod A", sustitución por "Prod B".
*   **Registro en Base de Datos:**
    *   `DetalleVenta` (Prod A): `cantidad=1`, `cantidad_cancelada=1`.
    *   `DetalleVenta` (Prod B): `cantidad=1`, `sustituye_a_id=<ID_Prod_A>`.
*   **Valor:** Permite reportes exactos de ventas perdidas por quiebre de stock vs. ventas salvadas por gestión comercial.

### 4. Integridad Financiera
*   **Alerta de Tasa:** El sistema identificó correctamente una tasa UF con >24h de antigüedad como `stale`.
*   **Redondeo CLP:**
    *   Precio Original (CRM): 15000.44
    *   Precio Final (Venta): 15000 (Integer/Decimal sin fracción)
    *   **Cumplimiento:** Adherencia total a normativa de no usar decimales en documentos finales CLP.

---
**Certificado generado automáticamente tras la ejecución exitosa de `one-off-scripts/verify_fase2_full.py`.**
