# Módulo de Sistema - ERP3

**Última actualización**: 2026-03-02

---

## Descripción

El módulo Sistema es el núcleo del ERP, gestionando la infraestructura multi-tenant, inventario, bodegas y seguridad.

---

## Componentes Principales

### 1. Multi-Tenancy

Gestión de la jerarquía organizacional:

```
Empresa
  └── Sucursal
        └── Bodega
              └── Ubicación (WMS)
```

**Características**:
- Aislamiento completo de datos por empresa
- Soporte para múltiples sucursales por empresa
- Gestión de bodegas y ubicaciones (WMS-Lite)

### 2. Gestión de Usuarios

- **Autenticación**: JWT con expiración configurable
- **Roles**: DEVELOPER, SUPERADMIN, ADMIN, MANAGER_*, USER
- **Multi-empresa**: Un usuario puede pertenecer a múltiples empresas

### 3. Inventario y Bodegas

#### WMS-Lite (Warehouse Management System)

Sistema ligero de gestión de ubicaciones:

- **Ubicaciones**: Estantes, pasillos, niveles
- **Inventario por ubicación**: Trazabilidad exacta
- **Picking FIFO**: Descuento automático desde ubicación más antigua

#### Alertas de Stock

- **Stock crítico**: Alerta cuando stock < stock_mínimo
- **Stock proyectado**: Considera órdenes en proceso

### 4. Métodos de Pago

Catálogo global de métodos de pago que cada empresa puede activar/desactivar:

- Efectivo
- Transferencia
- Tarjeta de Crédito
- Tarjeta de Débito

### 5. Feature Flags (Pilar 10)

Sistema de activación selectiva de funcionalidades por empresa (Tenant).

- **Almacenamiento**: Columna JSONB `feature_flags` en tabla `empresas`.
- **Gestión**: Endpoint `POST /api/v1/sistema/features/toggle` (SuperAdmin).
- **Uso**: `feature_service.is_enabled("KEY", empresa)`.
- **Performance**: Optimizado para leer del objeto `Empresa` en memoria sin consultas extra.

### 6. Suscripciones y Onboarding

- **Suscripción inicial**: `setup-client` asigna el Plan Trial por defecto a nuevas empresas, con 30 días.
- **Empresa MAIN**: Se crea/actualiza una suscripción de 100 años y nunca se reduce por re-seed.
- **Middleware resiliente**: Durante onboarding, el bloqueo por suscripción se omite para `setup-client` y `public/onboarding`.

### 7. Seguridad Avanzada (Pilar 9 - Hardening)

Módulo opcional de seguridad robusta (Ley 21.663) activable por Feature Flag `mfa_module`.

#### Autenticación Multifactor (MFA)
- **Implementación**: TOTP (Time-based One-Time Password) estándar (Google Authenticator, Authy).
- **Flujo de Login**:
  1. Login usuario/password -> Token temporal `scope="mfa_pending"`.
  2. Verificación OTP -> Token final `scope="access_token"`.
- **Enforcement**:
  - **Administrativo**: El administrador de la empresa puede forzar el uso de MFA para usuarios específicos (`mfa_enforced`).
  - **Setup Forzado**: Si un usuario obligado no tiene MFA configurado, recibe un token `scope="mfa_setup"` que solo permite acceder a la configuración de MFA.
- **Blindaje**: El middleware de seguridad (`deps.get_current_user`) bloquea activamente cualquier request a módulos de negocio (Ventas, Finanzas) si el token tiene scope `mfa_pending`.

---

## Modelos Principales

Ver [Modelos de Datos - Módulo Sistema](modelos_datos.md#módulo-sistema)

---

## API Endpoints

### Autenticación

- `POST /api/v1/login/access-token` - Obtener token
- `GET /api/v1/users/me` - Usuario actual

### Empresas

- `GET /api/v1/empresas` - Listar empresas
- `PATCH /api/v1/empresas/{id}` - Actualizar empresa
- `POST /api/v1/empresas/{id}/rotate-bi-credentials` - Rotar credenciales BI

### Ubicaciones

- `GET /api/v1/locations` - Obtener sucursales y bodegas

---

## Configuración Multi-Tenant

Cada request incluye el contexto de empresa:

```python
from app.api.deps import get_current_context

@router.get("/productos")
def get_productos(ctx: RequestContext = Depends(get_current_context)):
    # ctx.empresa_id está disponible
    productos = db.query(Producto)\
        .filter(Producto.empresa_id == ctx.empresa_id)\
        .all()
    return productos
```

---

## Seguridad

### Control de Acceso

```python
from app.api.deps import role_required

@router.get("/admin/settings")
@role_required(["ADMIN", "DEVELOPER"])
def get_settings():
    # Solo accesible por ADMIN o DEVELOPER
    pass
```

### Validación de Módulos

```python
from app.api.deps import check_module_access

router = APIRouter(
    dependencies=[Depends(check_module_access("VENTAS"))]
)
```

---

## Recursos Adicionales

- [Arquitectura Multi-Tenant](arquitectura_sistema.md#sistema-multi-tenant)
- [API Reference](api_reference.md#módulo-sistema)
- [Modelos de Datos](modelos_datos.md#módulo-sistema)
