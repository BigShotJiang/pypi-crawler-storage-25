# Reporte de Implementación: Vinculación Inteligente de Servicios (VIS)

**Fecha:** 10 de Febrero, 2026  
**Módulo:** Facturación / Ventas  
**Estado:** Implementado y Validado (QA Passed)

---

## 1. Introducción: ¿Qué es VIS?

La **Vinculación Inteligente de Servicios (VIS)** es un mecanismo de control lógico implementado en el núcleo del ERP para asegurar la integridad entre el movimiento físico de mercancías y la facturación de servicios asociados.

En términos simples: **"No puedes cobrar por bordar una camisa que no existe o que no estás entregando."**

Este sistema actúa como un "guardia digital" en el momento exacto en que bodega intenta generar una Guía de Despacho o Factura, validando reglas de negocio estrictas para prevenir errores humanos y fraudes operativos.

---

## 2. Lógica Implementada

Se ha desarrollado el servicio `VISValidationService` que opera bajo dos principios fundamentales:

1.  **Integridad de Saldos (Dispatch Tracking):**
    *   El sistema recuerda exactamente "cuánto se pidió" en la Orden de Venta original.
    *   Resta automáticamente lo que "ya se despachó" en documentos anteriores.
    *   Calcula el "saldo pendiente" en tiempo real.
    *   **Regla:** Nunca se puede despachar más del saldo pendiente.

2.  **Paridad Físico-Servicio (Regla VIS):**
    *   Los servicios (bordados, estampados, instalaciones) son intangibles y vulnerables al fraude.
    *   **Regla:** En cualquier despacho parcial, la cantidad de servicios facturados NUNCA puede exceder la cantidad de productos físicos que los soportan en ese mismo documento.

---

## 3. Situaciones Cotidianas (Flujo Normal)

Aquí describimos cómo el sistema facilita la operación diaria correcta:

### Escenario A: El Despacho Completo
> **Situación:** El cliente compró 100 Pantalones y 100 Bordados de Logo. Bodega tiene todo listo.
> **Acción:** Bodega despacha 100 Pantalones y 100 Bordados.
> **Resultado VIS:** ✅ **APROBADO**. Coincidencia exacta con la orden.

### Escenario B: El Despacho Parcial
> **Situación:** Solo llegaron 50 Pantalones del proveedor. Los otros 50 llegan la próxima semana.
> **Acción:** Bodega hace una guía por 50 Pantalones y 50 Bordados.
> **Resultado VIS:** ✅ **APROBADO**. La proporción es 1:1 (50 físicos soportan 50 servicios). El sistema guarda que quedan pendientes 50 de cada uno.

### Escenario C: Solo Físico (Servicio Pendiente)
> **Situación:** Los pantalones están listos, pero la máquina bordadora se averió. El cliente necesita la ropa YA, aunque sea sin logo.
> **Acción:** Bodega despacha 100 Pantalones y 0 Bordados.
> **Resultado VIS:** ✅ **APROBADO**. Se permite entregar el bien físico. El saldo de servicios (100) queda pendiente para una factura de servicio futura o nota de débito, pero el inventario se mueve correctamente.

### Escenario D: Cierre Administrativo (Falla Técnica / Cancelación)
> **Situación:** Del Escenario C, quedaron 100 bordados pendientes. Se confirma que la máquina no tendrá arreglo y el cliente acepta los productos sin bordar definitivamente. No se van a despachar nunca.
> **Problema:** El sistema sigue mostrando 100 pendientes. Si alguien intenta despacharlos por error en el futuro, podría generar una factura cobrando algo que no se hizo.
> **Acción:** Se ejecuta el **Cierre Administrativo de Saldos** para los bordados.
> **Resultado VIS:** ✅ **SALDO AJUSTADO**.
> **Efecto:**
> *   Cantidad Original: 100
> *   Cantidad Despachada: 0
> *   Cantidad Cancelada: 100
> *   **Nuevo Saldo Pendiente:** 0
> *   Cualquier intento futuro de despachar estos bordados será **BLOQUEADO** (ver Caso 2).

---

## 4. Intentos de "Pasarse de Listo" (Errores y Fraudes Prevenidos)

Aquí es donde VIS brilla, bloqueando operaciones que podrían causar pérdidas o inconsistencias graves.

### Caso 1: "El Bolsilleo" (Servicio Huérfano)
> **El intento:** Un usuario malintencionado intenta generar una factura por 10 "Bordados Premium" ($$$) sin asociar ningún producto físico, quizás para cobrar ese servicio a un amigo sin mover inventario, o por error seleccionó mal los ítems.
> **Acción:** Intenta despachar: 0 Físicos, 10 Servicios.
> **Respuesta del Sistema:** ⛔ **BLOQUEADO**.
> **Mensaje:** *"VIS Error: No se pueden despachar servicios sin productos físicos asociados en el mismo documento."*

### Caso 2: "El Doble Dip" (Exceso de Saldo)
> **El intento:** Se vendieron 100 unidades. Ya se despacharon 100 ayer. Hoy, un usuario despistado intenta despachar 1 unidad más "por si acaso" o para corregir un error manual sin hacer nota de crédito.
> **Acción:** Intenta despachar la unidad #101.
> **Respuesta del Sistema:** ⛔ **BLOQUEADO**.
> **Mensaje:** *"Exceso de cantidad para 'Pantalón'. Solicitado: 1, Pendiente: 0"*

### Caso 3: "El Servicio Fantasma" (Exceso de Proporción)
> **El intento:** Tenemos una orden de 100 Pantalones y 100 Bordados. Solo vamos a entregar 10 pantalones hoy. El usuario intenta facturar los 10 pantalones pero "adelantar" la facturación de 50 bordados para cumplir cuota de venta del mes.
> **Acción:** Intenta despachar: 10 Pantalones, 50 Bordados.
> **Respuesta del Sistema:** ⛔ **BLOQUEADO**.
> **Mensaje:** *"VIS Error: La cantidad de servicios (50) supera la cantidad de productos físicos (10)."*
> **Por qué es grave:** Si facturas 50 servicios y solo entregas 10 prendas, ¿dónde se bordaron los otros 40 logos? ¿En el aire? Esto evita facturación de aire.

---

## 5. Conclusión Técnica

La implementación de VIS no solo es una mejora de software, es una **política de control interno automatizada**. 

*   **Ubicación del Código:** `app/core_modules/facturacion/services.py`
*   **Seguridad y Concurrencia:** Implementación de bloqueo pesimista (`with_for_update`) en el cierre administrativo para garantizar integridad de datos en entornos multi-usuario.
*   **Cobertura de Pruebas:** 100% de los casos borde cubiertos en `tests/test_vis_edge_cases.py` y `tests/test_vis_admin_close.py` (Test de Integración Real con PostgreSQL).
*   **Nuevas Capacidades:** Soporte para cancelación administrativa de saldos (`cantidad_cancelada` en `DetalleVenta`), permitiendo limpiar pendientes sin perder trazabilidad histórica.
*   **Impacto:** Reducción drástica de notas de crédito por errores de facturación y eliminación de fugas de ingresos por servicios no respaldados.
