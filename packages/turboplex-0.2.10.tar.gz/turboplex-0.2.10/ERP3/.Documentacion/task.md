# Task: Frontend Vue3 ERP3

## Fase 1: Setup del Proyecto
- [x] Proyecto Vue3 + Vite + Pinia + Vue Router ya existe en `e:/ERP3/frontend`
- [x] Tailwind CSS v4 ya configurado
- [x] Vite con proxy al backend `:8000` ya configurado
- [x] Axios con interceptor JWT configurado en `src/services/api.js`
- [x] Stores Pinia implementados: `auth`, `empresa`, `ventas`, `finanzas`, `crm`, `billing`
- [x] Componentes UI Base: `KpiCard`, `DataTable`, `Modal`, `Badge` en `src/components/ui/`

## Fase 2: Capa Base Compartida
- [x] `src/services/api.js` — Axios con interceptors (JWT Bearer + ?cmp automático)
- [x] `src/stores/auth.js` — Pinia: gestión de token, usuario, impersonation
- [x] `src/layout/ClientLayout.vue` — Shell principal con Sidebar + Header + RouterView
- [x] `src/layout/AdminLayout.vue` — Layout para panel SaaS SuperAdmin
- [x] `src/router/index.js` — Rutas protegidas con Vue Router y meta-guards

## Fase 3: Módulo Auth
- [x] `src/views/Login.vue` — Formulario de login
- [x] `src/views/public/RegisterPage.vue` — Onboarding público (crear empresa)
- [ ] `src/views/auth/ChangePassword.vue` — Cambio de contraseña obligatorio (Pendiente)

## Fase 4: Dashboard
- [x] `src/views/Dashboard.vue` — KPIs principales y accesos directos
- [x] `src/components/dashboard/SalesChart.vue` — Gráfico de ventas
- [x] `src/components/dashboard/ServiceOrdersWidget.vue` — Widget de órdenes de servicio

## Fase 5: Módulo Ventas
- [x] `src/views/ventas/PosPage.vue` — Punto de Venta (POS)
- [x] `src/views/ventas/OrdenesServicioPage.vue` — Gestión de órdenes de servicio
- [x] `src/views/ventas/ClientesPage.vue` — Directorio de clientes
- [x] `src/views/inventory/InventoryDashboard.vue` — Panel de Inventario y Stock

## Fase 6: Módulo Finanzas
- [x] `src/views/finanzas/CajaPage.vue` — Control de Caja (Apertura/Cierre)
- [x] `src/views/finanzas/GastosPage.vue` — Gestión de Gastos y Egresos
- [x] `src/views/finanzas/ContabilidadPage.vue` — Visión general contable
- [x] `src/views/finance/FinanceDashboard.vue` — Dashboard financiero
- [ ] `src/views/finanzas/contabilidad/LibroDiario.vue` — Detalle libro diario (Pendiente)

## Fase 7: Módulo Compras (Migrado)
- [x] `src/views/compras/ProveedoresPage.vue` — Gestión de Proveedores (Migrado desde Finanzas)
- [x] `src/views/compras/OrdenesCompraPage.vue` — Gestión de Órdenes de Compra (Implementado con backend, aprobación y recepción)

## Fase 8: Módulo RRHH
- [x] `src/views/rrhh/RrhhPage.vue` — Gestión general RRHH
- [x] `src/views/hr/HRDashboard.vue` — Dashboard de recursos humanos

## Fase 9: Módulo CRM
- [x] `src/views/crm/CrmPage.vue` — Gestión de relaciones con clientes (Expandido con Actividades y Comentarios)
- [x] `src/views/crm/PipelineView.vue` — Vista de oportunidades
- [x] Ampliar backend CRM (Implementado Pipelines, Tareas, Notas y Tests)
- [x] Schema CRM Fase 1: Modelos (CrmCliente, CrmExcepcionCredito), Lógica de Consumo de Cupo y Sincronización UPSERT
- [x] Adición de tabla 'table_crm' en esquema public (Solicitud Usuario)


## Fase 10: Módulo Facturación
- [x] `src/views/facturacion/FacturacionPage.vue` — Emisión y gestión de DTEs
- [x] `src/views/admin/FacturacionCaf.vue` — Gestión de CAFs (Admin)

## Fase 11: Módulos TI y Legal
- [x] `src/views/ti/TiPage.vue` — Panel de gestión TI
- [x] `src/views/legal/LegalPage.vue` — Gestión de documentos legales

## Fase 12: Analytics
- [x] `src/views/analytics/AnalyticsPage.vue` — Reportes y métricas avanzadas

## Fase 13: Configuración del Sistema
- [x] `src/views/configuracion/ConfiguracionPage.vue` — Configuración general de la empresa
- [ ] `src/views/configuracion/UsuariosPage.vue` — Gestión detallada de usuarios y roles

## Fase 14: Panel SuperAdmin (SaaS)
- [x] `src/views/DevDashboard.vue` — Dashboard técnico (Ojo de Dios)
- [x] `src/views/admin/ClientDirectory.vue` — Directorio de tenants
- [x] `src/views/admin/Licensing.vue` — Gestión de licencias y planes
- [x] `src/views/admin/PluginManager.vue` — Gestión de plugins
- [x] `src/views/admin/DebugConsole.vue` — Consola de depuración y SQL Profiler

## Fase 15: Verificación y QA
- [ ] Levantar frontend con `npm run dev` y confirmar carga correcta
- [ ] Verificar Login contra backend real
- [ ] Verificar Dashboard con datos reales
- [ ] Verificar flujo POS (crear venta)
- [ ] Validar migración de Proveedores a módulo Compras en UI
