1. Definir el "Contrato" de Importación (Backend)
Dile al IDE que cree un Enum para los tipos de importación. Esto evita que el código se vuelva un espagueti de if/else.

Python
# app/models/enums.py
class ImportType(str, Enum):
    CATALOG_ONLY = "CATALOG_ONLY"   # Solo crea SKUs (sin stock)
    STOCK_ADJUST = "STOCK_ADJUST"   # Solo ajusta cantidades (requiere SKU existente)
    FULL_LOAD = "FULL_LOAD"         # Crea producto y asigna stock inicial
2. El Esquema de Mapeo Dinámico
Instruye al IDE para que la tabla import_configs (o el esquema de validación) use un mapeo flexible. Así el Auditor puede decidir qué columna del Excel va a qué campo de la DB.

Python
# Sugerencia de estructura JSON para el mapeo
{
    "target_table": "movimientos_stock",
    "mapping": {
        "sku": "Código de producto",       # Columna A del Excel
        "cantidad": "CANTIDAD DISPONIBLE", # Columna C
        "bodega": "Almacén",               # Columna F
        "costo": "Monto de costo financiero" # Columna L (¡Para arreglar el $0!)
    }
}
3. La Lógica de "No Destrucción" (Conflict Prevention)
Esta es la instrucción más importante para el IDE: "Si el tipo es STOCK_ADJUST, usa un patrón de UPSERT o Validación de Existencia".

Paso A: Validar que el SKU y la Bodega existan antes de procesar.

Paso B: En lugar de un INSERT ciego, el sistema debe calcular la diferencia.

Ejemplo: Si DB_Stock = 100 y Excel_Stock = 120, el sistema debe generar un movimiento de +20 con el import_run_id correspondiente.

4. Mantener la Trazabilidad (Audit Logs)
Dile al IDE: "Asegúrate de que cada ajuste use la función create_audit_log que ya tenemos".

El campo changes del log debe incluir el motivo del ajuste (ej: "Ajuste Masivo vía Plantilla Auditor").