# Backend ERP3 – 10 pilares para pasar de 80% a 95% de madurez

Este documento resume diez ejes concretos de mejora para llevar el backend de ERP3
desde un nivel actual aproximado de 75–80% de madurez hacia un 90–95% comparable
con productos enterprise muy pulidos.

Cada punto indica situación actual, riesgo asociado y beneficio al cerrarlo.

---

## 1. Homogeneización completa de UUID/UUIDv7 en todos los módulos

- **Estado**  
  - COMPLETADO (2026-02-23). IDs homogenizados a UUID/UUIDv7 en dominios core y bordes relevantes, suite de tests en verde (90 passed, 1 skipped).
- **Estado previo**  
  - Núcleo y módulos principales usan UUID/UUIDv7 de forma consistente (Empresa, Usuario, muchas tablas core).
  - Persisten islotes con `int` o mezclas en RRHH, Finanzas y algunos bordes de CRM/API.
- **Riesgo**  
  - Inconsistencias en integraciones internas.
  - Dificulta trazabilidad global basada en UUIDv7 y complica migraciones futuras.
- **Beneficio al cerrarlo**  
  - Identidad uniforme en todo el dominio.
  - Cronología unificada (uuidv7) para auditoría y BI.
  - Menos “pegamento” ad–hoc en servicios inter–módulo.

---

## 2. Cura definitiva de Decimales en todos los flujos monetarios

- **Estado**  
  - COMPLETADO (2026-02-23). Flujos monetarios críticos migrados a `Decimal` end-to-end (CRM, Facturación, Finanzas, Ventas, Analytics, listeners) y montos finales en CLP expuestos como enteros donde corresponde.
- **Estado previo**  
-  - Buena disciplina de `Decimal` en Finanzas y partes de Ventas/Compras.
-  - Aún hay calculadoras mixtas (`float`/`Decimal`), especialmente en RRHH e inventario.
- **Riesgo**  
  - Desajustes mínimos que, al acumularse, generan diferencias contables y problemas con SII/CLP entero.
- **Beneficio al cerrarlo**  
  - Cálculos monetarios deterministas y auditables.
  - Menos sorpresas en cierres de caja, conciliaciones y reporting.

---

## 3. Limpieza total de tipos y mypy en servicios core

- **Estado actual**  
  - Muchas funciones clave ya tipadas (`db: Session`, `UUID`, `Decimal`).
  - Hay todavía `no-untyped-def`, `Any` y errores pendientes en servicios de Finanzas, Compras, Ventas, RRHH y algunos helpers de infraestructura.
- **Riesgo**  
  - Refactors peligrosos al no tener red estática.
  - Errores de tipos que solo aparecen en producción bajo casos borde.
- **Beneficio al cerrarlo**  
  - Confianza alta al refactorizar dominios grandes.
  - Menos bugs sutiles, especialmente en flujos complejos (VIS, cierres, ajustes contables).

---

## 4. Refactor de módulos gigantes en paquetes más pequeños

- **Estado actual**  
  - Algunos archivos superan el límite ideal (p. ej. `sistema/api.py` con >700 líneas).
  - Mucha lógica mezclada (Auth, Sistema, Admin, BI, etc.) en pocas unidades de despliegue.
- **Riesgo**  
  - Aumenta la fricción para entender, testear y modificar comportamientos específicos.
  - Riesgo de regresiones al tocar partes no aisladas.
- **Beneficio al cerrarlo**  
  - Paquetes por dominio (ej. `sistema/auth_api.py`, `sistema/admin_api.py`, `sistema/bi_api.py`).
  - Archivos por debajo de 600 líneas, respetando tu estándar y facilitando mantenibilidad.

---

## 5. Contratos de API y respuestas uniformes (BaseResponse)

- **Estado actual**  
  - Muchas rutas devuelven modelos Pydantic ricos.
  - No todas usan una envoltura uniforme tipo `BaseResponse` (data + meta + errores); algunos endpoints viejos responden “raw”.
- **Riesgo**  
  - Frontend y terceros deben tratar casos especiales por endpoint.
  - Más difícil instrumentar métricas y errores a nivel de borde si no hay formato estándar.
- **Beneficio al cerrarlo**  
  - Contrato de API homogéneo: éxito, error, paginación, metadatos.
  - Facilita SDKs clientes y reduce código condicional en frontend/integraciones.

---

## 6. Resiliencia y Background Jobs (Pilar en progreso)

- **Estado actual**  
  - Handlers HTTP unificados con `BaseResponse` y `MetaPayload` (incluye `duration_ms`).
  - Nuevo módulo `error_utils` centraliza el mapeo de errores de dominio (`CREDIT_LIMIT_EXCEEDED`, `STOCK_UNAVAILABLE`, etc.) y lo hace agnóstico al protocolo.
  - `wrap_background_task` permite envolver tareas de fondo con `request_id` interno, medición de `duration_ms` y logging estructurado del resultado.
  - Endpoint de prueba `/v2/test/async-error` genera una tarea fallida que dispara un `BusinessRuleError` y registra el error con el mismo contrato que HTTP.
  - Test de resiliencia valida que el log contenga el código `STOCK_UNAVAILABLE` cuando una tarea de fondo falla.
  - Tabla `background_job_logs` persiste los resultados de cada tarea (task_name, status, duration_ms, error_code, error_detail) usando UUIDv7 como clave primaria.
  - Endpoint `/v2/test/jobs-history` expone el historial de tareas de fondo con filtros por `status`, `task_name` y límite de registros.
  - Endpoint `/v2/sistema/jobs-stats` mejorado: ahora entrega un desglose detallado por tarea (`tasks`: total, success, errors) para facilitar la construcción de dashboards de estado.
  - Sistema de Alerta Temprana (Spike Detection): `wrap_background_task` monitorea fallos consecutivos y emite una alerta crítica (`SYSTEM_ALERT: BACKGROUND_JOB_SPIKE`) si una tarea falla ≥5 veces en 15 minutos.
- **Riesgo**  
  - Aún no existe una Dead Letter Queue (DLQ) persistente para jobs irrecuperables.
  - No hay panel dedicado para inspeccionar y reintentar jobs fallidos más allá de los logs.
- **Beneficio al cerrarlo**  
  - Observabilidad homogénea entre errores sincrónicos (HTTP) y asincrónicos (background tasks), con rastro persistente en base de datos.
  - Base sólida para añadir DLQ, métricas avanzadas y panel de jobs fallidos sin romper contratos actuales.

---

## 7. Estrategia de timeouts y resiliencia de base de datos

- **Estado**  
  - COMPLETADO (2026-02-24). Estrategia integral de resiliencia implementada: timeouts de BD, middleware HTTP, consistencia eventual en flujos pesados y observabilidad de jobs en background.
- **Estado previo**  
  - `statement_timeout=10000` configurado en el engine principal de PostgreSQL y en el engine de tests (`conftest.py`), garantizando cancelación automática de queries lentas.
  - `error_utils` mapea ahora explícitamente `sqlalchemy.exc.TimeoutError` y `sqlalchemy.exc.OperationalError` a códigos de dominio `DATABASE_TIMEOUT` / `DATABASE_ERROR`, reutilizando el mismo sobre de error v2.
  - Middleware global de timeout HTTP (15s) añadido en `app/main.py`, usado para evitar requests colgadas en entornos productivos.
  - Test de estrés `tests/test_database_timeout_resilience.py` usando `pg_sleep(15)` que valida que las operaciones contra PostgreSQL fallan de forma controlada (500/504 con código de error de base de datos) y no quedan bloqueadas indefinidamente.
- **Riesgo**  
  - Bajo alta carga, algunas operaciones muy pesadas o que encadenan integraciones externas podrían recibir un 504 en lugar de completar, por lo que se debe revisar y ajustar timeouts específicos por módulo si es necesario.
- **Beneficio al cerrarlo**  
  - Timeouts razonables y homogéneos para lecturas/escrituras de base de datos, con mapeo consistente a errores de dominio.
  - Menos riesgo de “meltdown” por recursos agotados y mejor capacidad de observabilidad ante problemas de base de datos.
  - En flujos pesados (Service Engine, auditoría, contabilidad, inventario y notificaciones), los efectos secundarios se ejecutan ahora en background usando consistencia eventual, priorizando que los endpoints respondan rápido (200) sin bloquearse por tareas largas o dependencias externas.
  - Endpoint `/v2/test/jobs-history` expone el historial de tareas de fondo con filtros por `status`, `task_name` y límite de registros.
  - Endpoint `/v2/sistema/jobs-stats` mejorado: ahora entrega un desglose detallado por tarea (`tasks`: total, success, errors) para facilitar la construcción de dashboards de estado.
  - Sistema de Alerta Temprana (Spike Detection): `wrap_background_task` monitorea fallos consecutivos y emite una alerta crítica (`SYSTEM_ALERT: BACKGROUND_JOB_SPIKE`) si una tarea falla ≥5 veces en 15 minutos.

---

## 8. Cobertura de pruebas end-to-end en flujos críticos de negocio

- **Estado actual**  
  - Muy buenos tests de integración por módulo (ventas, finanzas, VIS, multi-tenant).
  - Ya existen scripts “de guerra” (logistics_war, sales_concurrency, stress_compras).
- **Riesgo**  
  - Algunos flujos full-stack (ej. del CRM a documentos tributarios y contabilidad) no están completamente cubiertos de punta a punta.
- **Beneficio al cerrarlo**  
  - Poder correr un set corto de E2E que valide: ventas completas, VIS, documentos tributarios, cierres contables, RRHH básico.
  - Más seguridad antes de releases gordos o cambios de esquema.

---

## 9. Hardening de seguridad avanzada y rotación de credenciales
 
- **Estado**  
  - COMPLETADO (2026-02-24). Infraestructura de seguridad robustecida:
    - **Gestor de Secretos Centralizado**: `SystemSecret` model y `SecretsManagerService` con encriptación Fernet (AES).
    - **Rotación Segura**: Endpoint `POST /sistema/rotate-secrets` protegido por rol SUPERADMIN.
    - **Rate Limiting Global**: Implementado con `slowapi` (5 req/min) en endpoints sensibles (`/login`, `/rotate-secrets`) para mitigar fuerza bruta.
    - **Auditoría CRITICAL**: Rotación y acceso a secretos generan AuditLogs de severidad CRITICAL sin exponer valores sensibles.
    - **Tests de Hardening**: Suite `tests/test_security_hardening.py` valida bloqueo de fuerza bruta y acceso RBAC.
- **Estado previo**  
  - RBAC y multi-tenant muy sólidos; alertas de seguridad (superadmin login fallido, etc.).
  - Endpoint de rotación de credenciales BI implementado y documentado.
- **Riesgo**  
  - Rotación de otros secretos (API keys externas, llaves de firma) aún depende más de configuración manual que de flujos controlados.
- **Beneficio al cerrarlo**  
  - Procedimientos estandarizados para rotar claves sensibles (R2, integraciones externas, firma digital).
  - Menos deuda operativa y mejor postura de seguridad a largo plazo.

---

## 10. Tooling de despliegue seguro y feature flags de dominio

- **Estado actual**  
  - Infra de migraciones con Alembic consolidada.
  - Entorno local bien documentado, pero los mecanismos de “activar módulo” o “lanzar feature” están más ligados a configuración manual.
- **Riesgo**  
  - Activar grandes cambios de dominio (nuevos módulos, nuevas reglas VIS, nuevas validaciones) sin capa de toggles aumenta riesgo en producción.
- **Beneficio al cerrarlo**  
  - Feature flags por dominio/módulo (ej. activar nuevo flujo VIS solo en ciertas empresas).
  - Despliegues más seguros, con rollback lógico sin necesidad de aplicar migraciones inversas de inmediato.

