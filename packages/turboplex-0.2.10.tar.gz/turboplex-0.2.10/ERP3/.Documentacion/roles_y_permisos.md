# Roles y Permisos (ERP3)

Este documento describe los roles existentes en ERP3 y su impacto práctico en el sistema. En ERP3 hay tres “capas” de roles que se combinan:

1) **Rol de plataforma (global)**: `Usuario.role` (aplica a toda la instalación).
2) **Rol por empresa**: `UsuarioEmpresa.rol.codigo` (aplica dentro de una empresa específica).
3) **Rol de Portal del Cliente**: `PortalUser.role` (aplica al Portal del Cliente).

## 1) Roles de Plataforma (Usuario.role)

Estos roles se evalúan principalmente en:
- Backend: dependencias de autorización en `app/api/deps.py` (role checks) y APIs de administración.
- Frontend: guard de rutas y `meta.roles` en el router.

| Rol | Dónde impacta | Impacto principal |
|---|---|---|
| `DEVELOPER` | Frontend Router (`/dev-dashboard`, `/super-admin/*`), Backend (bypass en ciertas dependencias) | Acceso a paneles de desarrollo/super-admin; suele permitir operar incluso si no hay rol por empresa explícito en algunos endpoints administrativos o de mantenimiento. |
| `SUPERADMIN` | Frontend Router (`/dev-dashboard`, `/super-admin/*`), Backend (bypass en ciertas dependencias) | Acceso a funciones globales (multi-tenant / SaaS). Similar a `DEVELOPER` en permisos de alto nivel. |
| `ADMIN` | Backend (creación de empresa/admin inicial, Portal Admin pagos, bypass parcial en inventario) | Administración a nivel plataforma/cliente; habilita endpoints administrativos específicos (p. ej. administración de pagos del Portal). |
| `TI_ADMIN` | Backend (módulo TI) | Habilita acceso al módulo TI (además de `SUPERADMIN/DEVELOPER/ADMIN_SAAS/ADMIN`). |
| `RRHH_ADMIN` | Backend (módulo RRHH, según endpoints) | Rol reservado para RRHH; uso depende de los endpoints del módulo y su configuración de acceso. |
| `ADMIN_SAAS` | Backend (módulos RRHH/TI) | Rol de negocio para administración SaaS; habilita módulos como RRHH/TI según configuración. |
| `MANAGER_RRHH` | Backend (módulo RRHH) | Rol de negocio para operar RRHH (además de `ADMIN_SAAS/SUPERADMIN/DEVELOPER/ADMIN`). |
| `USER` | Backend/Frontend (base) | Rol estándar. El acceso real a módulos y operaciones depende normalmente del rol por empresa y del módulo habilitado en la empresa. |

Notas:
- Algunos módulos aplican control adicional por “módulo contratado” a nivel empresa (ver sección 4).
- En ciertos endpoints se permite bypass por roles de plataforma (ej. `SUPERADMIN/DEVELOPER/ADMIN`) aunque no exista un rol por empresa en esa compañía.

## 2) Roles por Empresa (UsuarioEmpresa.rol.codigo)

Estos roles son registros por empresa en la tabla `roles` y se asignan a usuarios mediante `UsuarioEmpresa`.

| Código | Nombre (referencial) | Dónde impacta | Impacto principal |
|---|---|---|---|
| `ADM` | Administrador Único de Empresa | Administración de usuarios por empresa; operaciones sensibles | Máximo permiso dentro de una empresa. Se usa como rol por defecto al crear empresa y al vincular usuarios. |
| `SUP` | Supervisor | Operación general / aprobaciones | Permisos elevados operativos; en CRM se permite responder propuestas en ciertos flujos. |
| `VEN` | Vendedor | Ventas / CRM | Permite operar funcionalidades de ventas; en CRM se permite responder propuestas en ciertos flujos. |
| `BOD` | Bodeguero | Inventario/stock, Portal Admin | Orientado a inventario físico; puede estar explícitamente bloqueado para administrar Portal Users. |
| `CON` | Contador | Finanzas/contabilidad | Acceso a funcionalidades contables/financieras según endpoints del módulo. |
| `CRM` | Usuario CRM | Restricción transversal por módulos | “CRM-only”: el sistema restringe el acceso a módulos fuera de `CRM` y `CORE`. |
| `BACKOFFICE` | Backoffice | Administración/operación interna | Permisos de backoffice (según endpoints). |
| `AUD` | Auditor | Auditoría/lectura | Accesos de auditoría (según endpoints). |
| `OPS` | Operaciones | Operación/inventario | Permisos operacionales; usado en ciertas operaciones de inventario (ajustes). |

Notas:
- La creación/aceptación de códigos de rol por empresa está limitada a un set permitido en APIs administrativas (por ejemplo: `ADM/SUP/VEN/BOD/CON/CRM/BACKOFFICE/AUD/OPS`).
- El rol por empresa se resuelve típicamente consultando `UsuarioEmpresa` para la empresa activa y comparando `rol.codigo`.

## 3) Roles del Portal del Cliente (PortalUser.role)

Estos roles aplican únicamente al Portal del Cliente (`PortalUser`) y se combinan con el alcance por sucursal (`scope_sucursales`).

| Rol Portal | Alcance por sucursal | Impacto principal |
|---|---|---|
| `master` | Sin restricción (`scope_sucursales = null`) | Acceso total dentro del Portal para el cliente asociado. |
| `buyer` | Restringido por `scope_sucursales` (si existe) | Acceso a cotizaciones y documentos según alcance; se bloquean endpoints de pagos (403) en varias rutas del Portal. |
| `finance` | Restringido por `scope_sucursales` (si existe) | En general se permite operar con notificaciones/comprobantes de pagos (según endpoints) además de lectura de documentos. |

Notas:
- Si `scope_sucursales` está vacío, el comportamiento es “fail-safe”: el Portal queda sin resultados/accesos a recursos scopiados (evita acceso cross-sucursal).
- La capa Portal es independiente del rol de plataforma: no usa `Usuario.role`, usa `PortalUser.role`.

## 4) Reglas transversales relevantes

### 4.1 Acceso por módulo contratado (Empresa.modulos_activos)

Algunos routers aplican una dependencia que:
1) verifica que la empresa tiene el módulo habilitado, y
2) aplica restricciones por rol por empresa.

Caso especial:
- Si el usuario tiene rol por empresa `CRM`, se restringe el acceso a módulos distintos de `CRM` y `CORE`.

### 4.2 Rutas y UI (Frontend)

Ejemplos visibles:
- `/dev-dashboard`: requiere `SUPERADMIN` o `DEVELOPER`.
- `/super-admin/*`: requiere `SUPERADMIN` o `DEVELOPER` (y algunas subrutas son `DEVELOPER`-only).
- CRM en frontend usa `meta.roles` como `['ADMIN', 'VENDEDOR']` en ciertas rutas (ver nota de consistencia).

## 5) Nota de consistencia (CRM: `VENDEDOR`)

Actualmente aparecen referencias a `VENDEDOR` (por ejemplo, en rutas del frontend y en allowlists del backend CRM) como si fuese un rol de plataforma.

Esto convive con el rol por empresa `VEN` (vendedor), que es el código formal por empresa.

Recomendación operativa:
- Tratar `VENDEDOR` como un rol de plataforma “legacy/pendiente de alinear” y preferir `VEN` (rol por empresa) para permisos de negocio dentro de una empresa.

