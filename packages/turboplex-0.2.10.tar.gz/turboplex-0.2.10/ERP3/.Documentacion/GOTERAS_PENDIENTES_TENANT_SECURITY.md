# Goteras Pendientes — Tenant Security (Backlog)

Este documento lista riesgos/goteras potenciales que pueden provocar:
- **Falsos positivos**: fuga de datos entre empresas (cross-tenant).
- **Falsos negativos**: flujos legítimos que se rompen por RLS / contexto de tenant incompleto.

Contexto: el hotfix actual cerró la fuga crítica en tablas objetivo (ventas/finanzas/facturación) mediante:
- Denormalización `empresa_id` en tablas hijas críticas.
- RLS nativo en Postgres + `FORCE ROW LEVEL SECURITY` + policy `tenant_isolation_policy`.
- Inyección del contexto `app.current_empresa_id` en cada transacción (y bypass explícito con `allow_no_tenant`).

## 1) Tablas multi-tenant fuera del set RLS

Riesgo: tablas con datos sensibles que aún no están bajo RLS o no tienen `empresa_id` consistente.

- [ ] Inventariar tablas “tenant-scoped” por módulo (CRM, Compras, RRHH, Auditoría, Notificaciones, Webhooks, Archivos/adjuntos, etc.).
- [ ] Identificar tablas sin `empresa_id` (o con `nullable=True`) que deberían ser `NOT NULL`.
- [ ] Priorizar por exposición vía API y criticidad del dato (PII / financiero / documentos tributarios).

## 2) SQL crudo / bypass del filtro ORM

Riesgo: consultas con `text()` / SQL manual pueden saltar el scoping ORM; si el contexto de Postgres no está seteado, se rompe o filtra.

- [ ] Auditar `text(` / `execute(` / SQL manual en módulos multi-tenant.
- [ ] Exigir que SQL crudo dependa de RLS (y por ende de `app.current_empresa_id`) o incluya `WHERE empresa_id = :empresa_id`.
- [ ] Revisar endpoints de reporting/exports que tienden a usar SQL agregado manual.

## 3) Workers / Background Jobs sin `empresa_id`

Riesgo: tareas asíncronas pueden ejecutar sin `db.info["empresa_id"]`:
- rompe flujos (falso negativo) si RLS bloquea,
- o abre fuga si se usa `allow_no_tenant` indebidamente.

- [ ] Asegurar que cada job reciba `empresa_id` explícito como UUID.
- [ ] Validar fail-fast: si un job es tenant-scoped y no trae `empresa_id`, debe fallar inmediatamente.
- [ ] Revisar colas “globales” (mantenimientos, reintentos, sincronizaciones) y distinguir tenant-scoped vs platform-scoped.

## 4) Super-admin / soporte y el bypass `allow_no_tenant`

Riesgo: “arreglos rápidos” que activan bypass en endpoints de negocio.

- [ ] Auditar usos de `allow_no_tenant` y acotarlo a flujos administrativos controlados.
- [ ] Asegurar que el bypass quede trazable (audit log) y no sea accesible por roles no-plataforma.
- [ ] Revisar que el boundary transaccional evite que el bypass quede “pegado” en la misma conexión.

## 5) Falsos negativos típicos por RLS (flujos legítimos)

Áreas frecuentes donde el RLS endurecido puede romper procesos si falta el contexto correcto:

- [ ] Reportes/agregados multi-sucursal: confirmar que siempre llevan `empresa_id` (y no usan joins que dependan de datos cross-tenant).
- [ ] Conciliaciones / cierres contables: revisar servicios que operan en batch.
- [ ] Integraciones (webhooks/ETL/export): validar que no intenten leer múltiples empresas sin bypass explícito.
- [ ] Operaciones de backoffice que recorren empresas: deben hacerlo con `allow_no_tenant` explícito y segmentando por empresa.

## 6) Cobertura de pruebas de aislamiento

Riesgo: regresiones silenciosas al agregar nuevos modelos/tablas.

- [ ] Expandir pruebas de aislamiento por módulo: crear Empresa A/B y validar no lectura/actualización cross-tenant por ID.
- [ ] Agregar un “smoke test” estándar que cubra las tablas más críticas por release.
- [ ] Verificar que la serialización de UUID (logs/JSON) no rompa observabilidad ni produzca fallas runtime.

