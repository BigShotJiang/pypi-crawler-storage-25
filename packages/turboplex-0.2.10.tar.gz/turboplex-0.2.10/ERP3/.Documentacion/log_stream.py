from fastapi import APIRouter
import random
from datetime import datetime

# Metadatos para la Consola Universal
MODULE_TYPE = "utility"
MODULE_NAME = "Log Stream"
MODULE_UI_CONFIG = {
    "tab_name": "Log Stream",
    "component": "GenericDebugPlugin",
    "icon": "PhTerminalWindow",
    "order": 10,
    "layout_config": {
        "type": "table",
        "data_url": "/api/v1/debug/logs/stream",
        "columns": [
            {"key": "timestamp", "label": "Hora"},
            {"key": "level", "label": "Nivel"},
            {"key": "message", "label": "Mensaje"},
            {"key": "module", "label": "Módulo"}
        ],
        "actions": [
            {
                "label": "Ver Detalle",
                "icon": "PhEye",
                "color": "blue",
                "api_method": "GET",
                "api_url": "/api/v1/debug/logs/detail/{id}",
                "confirm_message": "Ver detalle del log {id}?"
            }
        ]
    }
}

router = APIRouter(prefix="/api/v1/debug/logs", tags=["Utility"])

# Simulación de logs recientes
def generate_logs():
    levels = ["INFO", "WARNING", "ERROR", "DEBUG"]
    modules = ["auth", "ventas", "db", "system"]
    messages = [
        "Usuario autenticado",
        "Error de conexión a DB",
        "Venta registrada",
        "Cache invalidado",
        "Backup completado"
    ]
    
    logs = []
    for i in range(20):
        logs.append({
            "id": f"log_{i}",
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "level": random.choice(levels),
            "message": random.choice(messages),
            "module": random.choice(modules)
        })
    return logs

@router.get("/stream")
def get_log_stream():
    """Retorna los últimos logs del sistema."""
    return generate_logs()

@router.get("/detail/{log_id}")
def get_log_detail(log_id: str):
    return {"status": "ok", "detail": f"Detalle completo del log {log_id}"}
