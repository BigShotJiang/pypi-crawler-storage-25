# Modelos de Datos - ERP3

**Última actualización**: 2026-02-06

---

## 📋 Tabla de Contenidos

- [Diagrama General](#diagrama-general)
- [Módulo Sistema](#módulo-sistema)
- [Módulo Ventas](#módulo-ventas)
- [Módulo Finanzas](#módulo-finanzas)
- [Módulo RRHH](#módulo-rrhh)
- [Módulo Compras](#módulo-compras)
- [Convenciones](#convenciones)

---

## Diagrama General

### Relaciones Multi-Tenant

```mermaid
erDiagram
    Empresa ||--o{ Sucursal : tiene
    Empresa ||--o{ Usuario : pertenece
    Empresa ||--o{ ContratoModulo : contrata
    Sucursal ||--o{ Bodega : contiene
    Bodega ||--o{ Ubicacion : organiza
    
    Empresa {
        int id PK
        string rut UK
        string nombre
        string codigo UK
        json modulos_activos
        bool pwr_bi_enabled
    }
    
    Sucursal {
        int id PK
        int empresa_id FK
        string nombre
        string codigo
        string direccion
    }
    
    Bodega {
        int id PK
        int sucursal_id FK
        string nombre
        string codigo
        bool is_active
    }
    
    Ubicacion {
        int id PK
        int bodega_id FK
        string nombre
        string zona
        string pasillo
        int capacidad_maxima
    }
```

---

## Módulo Sistema

### Usuario

**Tabla**: `usuarios`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `email` | String UK | Email del usuario |
| `hashed_password` | String | Contraseña hasheada (bcrypt) |
| `is_active` | Boolean | Usuario activo |
| `role` | String | Rol: DEVELOPER, ADMIN, SUPERADMIN, USER |
| `created_at` | DateTime | Fecha de creación |

**Relaciones**:
- `empresas_asociadas` → UsuarioEmpresa (many-to-many)

### Empresa

**Tabla**: `empresas`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `nombre` | String | Razón social |
| `rut` | String UK | RUT de la empresa |
| `codigo` | String UK | Código corto (ej: EMP001) |
| `modulos_activos` | JSON | Array de módulos contratados |
| `pwr_bi_enabled` | Boolean | Power BI habilitado |
| `pwr_bi_config` | JSON | Configuración de BI |
| `created_at` | DateTime | Fecha de creación |

**Relaciones**:
- `sucursales` → Sucursal (one-to-many)
- `usuarios_asociados` → UsuarioEmpresa (many-to-many)

### Sucursal

**Tabla**: `sucursales`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa propietaria |
| `nombre` | String | Nombre de la sucursal |
| `codigo` | String | Código (ej: SUC001) |
| `direccion` | String | Dirección física |
| `created_at` | DateTime | Fecha de creación |

**Relaciones**:
- `empresa` → Empresa
- `bodegas` → Bodega (one-to-many)

### Bodega

**Tabla**: `bodegas`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `sucursal_id` | Integer FK | Sucursal propietaria |
| `nombre` | String | Nombre de la bodega |
| `codigo` | String | Código (ej: BOD001) |
| `is_active` | Boolean | Bodega activa |
| `created_at` | DateTime | Fecha de creación |

**Relaciones**:
- `sucursal` → Sucursal
- `ubicaciones` → Ubicacion (one-to-many)
- `inventario` → Inventario (one-to-many)

### Ubicacion (WMS)

**Tabla**: `ubicaciones`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `bodega_id` | Integer FK | Bodega propietaria |
| `nombre` | String | Nombre (ej: Estante A1) |
| `zona` | String | Zona de la bodega |
| `pasillo` | String | Pasillo |
| `nivel` | String | Nivel del estante |
| `capacidad_maxima` | Integer | Capacidad (0 = ilimitado) |

**Relaciones**:
- `bodega` → Bodega
- `inventario_items` → InventarioUbicacion (one-to-many)

---

## Módulo Ventas

### Diagrama de Relaciones

```mermaid
erDiagram
    Venta ||--o{ DetalleVenta : contiene
    Venta ||--o| OrdenServicio : genera
    Venta }o--|| Cliente : para
    Venta }o--|| Sucursal : en
    Venta }o--|| Usuario : vendedor
    DetalleVenta }o--|| Producto : item
    OrdenServicio ||--o{ HistorialOrdenServicio : historial
    Producto ||--o| Receta : tiene
    Receta ||--o{ InsumoReceta : requiere
    
    Venta {
        int id PK
        datetime fecha
        string folio
        decimal total
        int cliente_id FK
        int sucursal_id FK
        int vendedor_id FK
        int empresa_id FK
    }
    
    DetalleVenta {
        int id PK
        int venta_id FK
        int producto_id FK
        int cantidad
        decimal precio_unitario
        decimal subtotal
        bool es_servicio
    }
    
    OrdenServicio {
        int id PK
        int venta_id FK
        enum estado
        datetime fecha_recepcion
        datetime fecha_entrega_prometida
        string observaciones_custodia
    }
```

### Cliente

**Tabla**: `clientes`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa propietaria |
| `nombre` | String | Nombre del cliente |
| `rut` | String | RUT del cliente |
| `email` | String | Email de contacto |
| `telefono` | String | Teléfono |
| `direccion` | String | Dirección |

### Producto

**Tabla**: `productos`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa propietaria |
| `nombre` | String | Nombre del producto |
| `sku` | String | SKU (único por empresa) |
| `precio` | Numeric(10,2) | Precio base |
| `tipo_producto` | String | ALMACENABLE, SERVICIO, CONSUMIBLE |
| `is_active` | Boolean | Producto activo |

**Constraint**: Unique (`sku`, `empresa_id`)

### Venta

**Tabla**: `ventas`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `sucursal_id` | Integer FK | Sucursal donde se realizó |
| `cliente_id` | Integer FK | Cliente |
| `vendedor_id` | Integer FK | Usuario vendedor |
| `fecha` | DateTime | Fecha de la venta |
| `folio` | String | Folio de la venta |
| `total` | Numeric(10,2) | Total de la venta |
| `cierre_caja_id` | Integer FK | Cierre de caja asociado |

### OrdenServicio

**Tabla**: `ordenes_servicio`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `venta_id` | Integer FK UK | Venta asociada |
| `estado` | Enum | RECEPCIONADO, EN_PROCESO, LISTO_RETIRO, ENTREGADO |
| `fecha_recepcion` | DateTime | Fecha de recepción |
| `fecha_entrega_prometida` | DateTime | Fecha prometida |
| `fecha_entrega_real` | DateTime | Fecha real de entrega |
| `observaciones_custodia` | String | Observaciones |

### Inventario

**Tabla**: `inventario`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `producto_id` | Integer FK | Producto |
| `bodega_id` | Integer FK | Bodega |
| `cantidad` | Integer | Stock actual |
| `stock_minimo` | Integer | Stock mínimo |
| `updated_at` | DateTime | Última actualización |

### Receta (Consumo de Insumos)

**Tabla**: `recetas`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `producto_servicio_id` | Integer FK UK | Producto servicio |
| `nombre` | String | Nombre de la receta |

**Tabla**: `insumos_receta`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `receta_id` | Integer FK | Receta |
| `producto_insumo_id` | Integer FK | Producto insumo |
| `cantidad` | Numeric(10,4) | Cantidad requerida |
| `unidad_medida` | String | ML, GR, UN |

---

## Módulo Finanzas

### Diagrama Contable

```mermaid
erDiagram
    AsientoContable ||--o{ MovimientoContable : contiene
    MovimientoContable }o--|| CuentaContable : afecta
    CuentaContable ||--o{ CuentaContable : hijas
    Gasto }o--|| AsientoContable : genera
    Venta }o--|| AsientoContable : genera
    
    AsientoContable {
        int id PK
        int numero
        datetime fecha
        string glosa
        string origen
        int origen_id
        string estado
        int empresa_id FK
    }
    
    MovimientoContable {
        int id PK
        int asiento_id FK
        int cuenta_id FK
        decimal debe
        decimal haber
    }
    
    CuentaContable {
        int id PK
        string codigo
        string nombre
        string tipo_cuenta
        int nivel
        bool es_imputable
        int padre_id FK
    }
```

### CuentaContable (Plan de Cuentas)

**Tabla**: `cuentas_contables`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `codigo` | String | Código (ej: 1.1.01.01) |
| `nombre` | String | Nombre de la cuenta |
| `tipo_cuenta` | String | ACTIVO, PASIVO, PATRIMONIO, INGRESO, GASTO |
| `nivel` | Integer | Nivel jerárquico (1-4) |
| `es_imputable` | Boolean | Puede recibir movimientos |
| `padre_id` | Integer FK | Cuenta padre |

### AsientoContable

**Tabla**: `asientos_contables`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `numero` | Integer | Número correlativo anual |
| `fecha` | DateTime | Fecha del asiento |
| `glosa` | String | Descripción |
| `origen` | String | VENTAS, COMPRAS, MANUAL, CIERRE, NOMINA |
| `origen_id` | Integer | ID del documento origen |
| `tipo_documento` | String | Tipo DTE (33, 39, 56) |
| `folio_documento` | String | Folio del documento |
| `rut_tercero` | String | RUT del tercero |
| `estado` | String | BORRADOR, CONFIRMADO, ANULADO |

### MovimientoContable

**Tabla**: `movimientos_contables`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `asiento_id` | Integer FK | Asiento |
| `cuenta_id` | Integer FK | Cuenta contable |
| `debe` | Numeric(14,2) | Monto debe |
| `haber` | Numeric(14,2) | Monto haber |
| `sucursal_id` | Integer FK | Centro de costo |

**Constraint**: Debe = Haber en cada asiento

### Gasto

**Tabla**: `gastos`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `sucursal_id` | Integer FK | Sucursal |
| `proveedor_id` | Integer FK | Proveedor |
| `descripcion` | String | Descripción del gasto |
| `monto` | Numeric(10,2) | Monto total |
| `categoria` | String | OPERACIONAL, ADMINISTRATIVO, etc. |
| `fecha` | DateTime | Fecha del gasto |
| `metodo_pago_id` | Integer FK | Método de pago |
| `asiento_id` | Integer FK | Asiento generado |

### CierreCaja

**Tabla**: `cierres_caja`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `sucursal_id` | Integer FK | Sucursal |
| `usuario_id` | Integer FK | Cajero |
| `fecha_apertura` | DateTime | Apertura |
| `fecha_cierre` | DateTime | Cierre |
| `monto_inicial` | Numeric(10,2) | Fondo inicial |
| `ventas_totales_sistema` | Numeric(10,2) | Total según sistema |
| `monto_real_fisico` | Numeric(10,2) | Efectivo contado |
| `diferencia` | Numeric(10,2) | Diferencia (Real - Esperado) |

---

## Módulo RRHH

### Empleado

**Tabla**: `empleados`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `rut` | String | RUT del empleado |
| `nombre` | String | Nombre |
| `apellido` | String | Apellido |
| `email` | String | Email |
| `telefono` | String | Teléfono |
| `cargo` | String | Cargo |
| `sueldo_base` | Numeric(10,2) | Sueldo base |
| `tipo_contrato` | String | INDEFINIDO, PLAZO_FIJO, HONORARIOS |
| `fecha_ingreso` | Date | Fecha de ingreso |
| `tipo_afp` | String | AFP (CAPITAL, PROVIDA, etc.) |
| `sistema_salud` | String | FONASA, ISAPRE |
| `especialidades` | JSON | Array de especialidades |
| `costo_hora` | Numeric(10,2) | Costo por hora |
| `estado_disponibilidad` | String | DISPONIBLE, EN_TURNO, VACACIONES |
| `is_active` | Boolean | Empleado activo |

### Asistencia

**Tabla**: `asistencias`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empleado_id` | Integer FK | Empleado |
| `fecha` | Date | Fecha del turno |
| `hora_entrada` | Time | Hora de entrada |
| `hora_salida` | Time | Hora de salida |
| `hora_inicio_colacion` | Time | Inicio colación |
| `hora_fin_colacion` | Time | Fin colación |
| `horas_trabajadas` | Numeric(5,2) | Horas trabajadas |
| `horas_extras` | Numeric(5,2) | Horas extras |

### LiquidacionSueldo

**Tabla**: `liquidaciones_sueldo`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empleado_id` | Integer FK | Empleado |
| `empresa_id` | Integer FK | Empresa |
| `mes` | Integer | Mes (1-12) |
| `anio` | Integer | Año |
| `sueldo_base` | Numeric(10,2) | Sueldo base |
| `gratificacion` | Numeric(10,2) | Gratificación legal |
| `horas_extras` | Numeric(10,2) | Pago horas extras |
| `total_haberes_imponibles` | Numeric(10,2) | Total imponible |
| `total_haberes_no_imponibles` | Numeric(10,2) | Total no imponible |
| `descuento_afp` | Numeric(10,2) | Descuento AFP |
| `descuento_salud` | Numeric(10,2) | Descuento salud (7%) |
| `descuento_cesantia` | Numeric(10,2) | Seguro cesantía |
| `impuesto_unico` | Numeric(10,2) | Impuesto único |
| `total_descuentos` | Numeric(10,2) | Total descuentos |
| `liquido_a_pagar` | Numeric(10,2) | Líquido a pagar |
| `estado` | String | PREVIEW, CONFIRMADA |
| `asiento_id` | Integer FK | Asiento contable |

---

## Módulo Compras

### Proveedor

**Tabla**: `proveedores`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `rut` | String | RUT del proveedor |
| `razon_social` | String | Razón social |
| `giro` | String | Giro comercial |
| `direccion` | String | Dirección |
| `telefono` | String | Teléfono |
| `email` | String | Email |
| `is_active` | Boolean | Proveedor activo |

### OrdenCompra

**Tabla**: `ordenes_compra`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa |
| `proveedor_id` | Integer FK | Proveedor |
| `fecha_emision` | DateTime | Fecha de emisión |
| `fecha_entrega_estimada` | Date | Entrega estimada |
| `fecha_recepcion` | DateTime | Fecha de recepción |
| `estado` | String | PENDIENTE, RECIBIDA, CANCELADA |
| `total` | Numeric(10,2) | Total de la OC |
| `observaciones` | String | Observaciones |

### OrdenCompraDetalle

**Tabla**: `ordenes_compra_detalle`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `orden_compra_id` | Integer FK | Orden de compra |
| `producto_id` | Integer FK | Producto |
| `cantidad` | Integer | Cantidad solicitada |
| `precio_unitario` | Numeric(10,2) | Precio unitario |
| `subtotal` | Numeric(10,2) | Subtotal |

---

## Convenciones

### Nomenclatura

- **Tablas**: snake_case plural (ej: `ordenes_compra`)
- **Columnas**: snake_case (ej: `fecha_entrega`)
- **Primary Keys**: `id` (Integer autoincremental)
- **Foreign Keys**: `{tabla_singular}_id` (ej: `empresa_id`)

### Timestamps

Todas las tablas principales incluyen:
- `created_at`: DateTime con `server_default=func.now()`
- `updated_at`: DateTime con `onupdate=func.now()` (opcional)

### Multi-Tenancy

Todas las tablas de datos de negocio incluyen:
- `empresa_id`: Foreign Key a `empresas`
- Índice en `empresa_id` para optimizar queries

### Soft Delete

No se implementa soft delete. Los registros eliminados se mueven a `papelera_reciclaje`.

### JSON Fields

Campos JSON se usan para:
- `modulos_activos` (Empresa): Array de códigos de módulos
- `especialidades` (Empleado): Array de tags
- `pwr_bi_config` (Empresa): Configuración dinámica
- `changes` (AuditLog): Cambios before/after

### Tipos Numéricos

- **Montos**: `Numeric(10, 2)` - hasta 99,999,999.99
- **Montos contables**: `Numeric(14, 2)` - hasta 999,999,999,999.99
- **Cantidades**: `Integer`
- **Cantidades decimales**: `Numeric(10, 4)` (recetas)

---

## Migraciones

Las migraciones se gestionan con **Alembic**.

### Comandos Útiles

```bash
# Generar migración automática
alembic revision --autogenerate -m "Descripción"

# Aplicar migraciones
alembic upgrade head

# Revertir última migración
alembic downgrade -1
```

### Ubicación

`backend/alembic/versions/`

---

## Recursos Adicionales

- [Arquitectura del Sistema](arquitectura_sistema.md)
- [API Reference](api_reference.md)
- [Documentación de Módulos](./)
