# Especificación de Soporte Multimoneda e Integraciones

## Resumen
Implementación del módulo `ExternalIntegrationService` para la gestión de tasas de cambio (UF, USD, UTM) y su integración con el ciclo de ventas y facturación (VIS).

## Componentes

### 1. Modelo de Datos
*   **ExchangeRates** (`finanzas`): Tabla para almacenar tasas de cambio con timestamp de actualización.
*   **Venta** (`ventas`): Nuevos campos `moneda` (CLP, UF, USD) y `tipo_cambio`.

### 2. Servicios
*   **ExternalIntegrationService** (`integraciones`):
    *   `process_external_rates(json_data, api_key)`: Endpoint seguro para actualización batch de tasas.
    *   Validación de API Key y mapeo de claves externas (ej: 'dolar' -> 'USD').
    *   Persistencia transaccional.

*   **VISValidationService** (`facturacion`):
    *   `get_monetary_dispatch_status(venta_id)`: Extensión de VIS para valorar saldos pendientes según la tasa de cambio vigente al momento de la consulta.
    *   **Cumplimiento Normativo (SII)**: Los montos finales en CLP se redondean estrictamente a entero (`int(round(val))`).
    *   **Alerta de Desactualización**: Incluye warnings si la tasa utilizada tiene una antigüedad mayor a 24 horas.

### 3. API
*   **Endpoint**: `POST /api/v1/integraciones/rates`
*   **Seguridad**: Requiere `api_key` configurada en `Settings` (Variable de entorno).
*   **Payload**:
    ```json
    {
        "api_key": "...",
        "rates": { "uf": 38000.5, "dolar": 950 }
    }
    ```

## Integración con VIS
El sistema ahora permite emitir Órdenes de Venta en monedas extranjeras o indexadas (UF).
*   **Regla de Negocio**: Aunque la venta se pacte en UF, el saldo pendiente se recalcula dinámicamente en CLP para efectos de facturación y visualización, utilizando la última tasa registrada.
*   **Persistencia**: Las tasas se guardan en base de datos, garantizando consistencia entre reinicios del servidor.

## Pruebas (Test Suite)
Archivo: `tests/test_external_integration.py`
1.  **Seguridad**: Rechazo de requests con API Key inválida (401).
2.  **Persistencia**: Verificación de escritura en DB mediante conexiones independientes.
3.  **Integración VIS**: Simulación de fluctuación de moneda (UF) y verificación de impacto en valoración de despacho (incluyendo redondeo CLP).
4.  **Robustez**: Manejo de errores ante datos mal formados o valores negativos.
