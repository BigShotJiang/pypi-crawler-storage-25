# Módulo de Ventas e Inventario

## Resumen
Este módulo gestiona el catálogo de productos, el inventario por bodegas/sucursales y el proceso de ventas.

## Tipos de Producto
El sistema soporta diferentes tipos de productos para adaptarse a modelos de negocio híbridos (Venta de bienes + Servicios), como una Lavandería.

### Clasificación (`tipo_producto`)
1. **ALMACENABLE** (Default)
   - **Comportamiento**: Control estricto de stock.
   - **Venta**: Genera `MovimientoStock` (resta inventario).
   - **Ejemplos**: Detergente en botella, Ropa, Bebidas.

2. **SERVICIO**
   - **Comportamiento**: No tiene stock físico.
   - **Venta**: NO genera `MovimientoStock`. Se registra la venta financiera pero no afecta bodegas. Genera automáticamente una **Orden de Servicio**.
   - **Ejemplos**: Lavado de Edredón, Planchado, Desmanchado, Delivery.

3. **CONSUMIBLE**
   - **Comportamiento**: Se compra y gasta, pero no se inventaria unidad a unidad en la venta final (opcional).
   - **Uso**: Insumos internos (bolsas, tickets).

## Flujo de Venta
1. **Creación**: Se recibe una lista de productos.
2. **Contexto de Caja**:
   - El sistema busca automáticamente si el usuario tiene un **Cierre de Caja** abierto en la sucursal actual.
   - Si existe, la venta se vincula a ese cierre. Si no, se permite la venta (configurable) pero queda huérfana de sesión.
3. **Verificación**: Se valida que el producto exista y esté activo.
4. **Stock**:
   - Si es `ALMACENABLE`: Se descuenta de la bodega predeterminada de la sucursal. Se genera un `MovimientoStock` y se actualiza `Inventario`.
   - Si es `SERVICIO`: Se omite el descuento de stock.
5. **Operaciones Diferidas**:
   - Si la venta incluye servicios o se solicita explícitamente, se genera una **Orden de Servicio** en estado `RECEPCIONADO`.
6. **Registro**: Se guarda el detalle de venta, el total financiero y la orden asociada.

## Seguridad y Robustez (Locking)
Para garantizar la integridad financiera, se han implementado mecanismos de bloqueo (Locking):

### Bloqueo de Eliminación
- **Regla**: No se puede eliminar una venta (`DELETE /api/v1/ventas/{id}`) si está asociada a un **Cierre de Caja FINALIZADO**.
- **Excepción**: Si la caja sigue abierta, la venta puede eliminarse (Soft Delete o Hard Delete según configuración), permitiendo correcciones operativas inmediatas.
- **Respuesta**: Intento de borrado bloqueado retorna `403 Forbidden` (BusinessRuleError).

## Operaciones Diferidas (Orden de Servicio)
Para negocios de servicios (ej. Lavanderías, Reparaciones), la venta no termina con el pago. Se inicia un flujo operativo gestionado por la entidad `OrdenServicio`.

### Estados del Flujo
1. **RECEPCIONADO**: El cliente entregó las prendas/items. Se genera automáticamente al vender un servicio.
2. **EN_PROCESO**: El servicio está siendo ejecutado (Lavado, Planchado, etc.).
3. **LISTO_RETIRO**: El proceso terminó y el item está en custodia esperando al cliente.
4. **ENTREGADO**: El cliente retiró sus items. Marca el fin del ciclo operativo.

### Trazabilidad
- **Historial**: Cada cambio de estado genera un registro en `HistorialOrdenServicio`.
- **Cross-Module**: Se registra el ID del usuario de RRHH que ejecutó el cambio, permitiendo auditoría y métricas de productividad por empleado.
- **Datos Legales**: Soporta `fecha_entrega_prometida` y `observaciones_custodia` (cumplimiento Ley del Consumidor).

## Inventario Global
La vista de inventario global filtra y muestra el stock actual calculado en base a los movimientos. Al no generar movimientos para servicios, estos no "ensucian" el reporte con stocks negativos.

## Recetas y Consumo de Insumos
El sistema permite vincular un producto de tipo `SERVICIO` con uno o más productos de tipo `CONSUMIBLE` a través de **Recetas**. Esto permite calcular automáticamente el costo y consumo de materiales necesarios para ejecutar un servicio.

### Modelo de Datos
- **Receta**: Vinculación 1 a 1 con un `Producto` (Servicio).
- **InsumoReceta**: Lista de insumos requeridos, definiendo `cantidad` y `unidad_medida` (ej. 100 ML de Detergente).

### Flujo de Cálculo
Al vender un servicio con receta asociada, los servicios de monitoreo (como `InventoryAlertService`) pueden proyectar el consumo real de insumos basándose en las órdenes activas, sin necesidad de descontar stock manualmente en cada operación.

## Sistema WMS-Lite (Gestión de Ubicaciones)
El módulo de inventario ha evolucionado hacia un sistema WMS (Warehouse Management System) ligero, permitiendo conocer no solo *cuánto* stock hay, sino *dónde* está físicamente.

### Modelo de Datos
- **Ubicacion**: Define una posición física dentro de una Bodega (ej. "Estante A1", "Pasillo 3"). Campos: `zona`, `pasillo`, `nivel`, `capacidad_maxima`.
- **InventarioUbicacion**: Relación muchos a muchos entre Productos y Ubicaciones. Permite tener el mismo insumo distribuido en múltiples lugares.

### Estrategia de Picking (FIFO)
El sistema implementa una lógica de salida inteligente basada en **FIFO (First In, First Out)**:
1. Al confirmarse el consumo (Estado `LISTO_RETIRO`), el sistema busca todas las ubicaciones que contienen el insumo.
2. Ordena las ubicaciones por antigüedad (`updated_at` ascendente).
3. Consume el stock de la ubicación más antigua primero. Si se agota, continúa con la siguiente hasta cubrir la necesidad.
4. Mantiene sincronizado el stock agregado (tabla `Inventario`) para consultas rápidas.

## Alertas de Stock Proyectado
Para evitar quiebres de stock en negocios de alta rotación (como lavanderías industriales), se implementó un sistema de alertas predictivas.

### Lógica de Alerta
El sistema cruza tres variables en tiempo real:
1. **Stock Físico**: Cantidad real en bodegas.
2. **Consumo Proyectado**: Cantidad comprometida en Órdenes de Servicio en curso (`EN_PROCESO`).
3. **Stock Mínimo**: Umbral de seguridad definido por producto (`stock_minimo` en `Inventario`).

**Fórmula Crítica**:
`Estado CRITICO` si `(Stock Físico - Consumo Proyectado) < Stock Mínimo`

### Notificación
Endpoint dedicado (`GET /api/v1/inventario/alertas`) que alimenta banners en el Frontend cuando se detectan insumos en riesgo de quiebre inminente.

## Escudo de Certificaciones (Control de Calidad)
Sistema de bloqueo y alertas para productos que requieren certificaciones vigentes (ej. EPP, Químicos).

### Modelo `ProductoCertificacion`
Vinculado a productos, almacena:
- `numero_resolucion`: ID de la norma.
- `fecha_emision` y `fecha_vencimiento`.
- `organismo_certificador`.
- `documento_url`: Respaldo digital (PDF).

### Reglas de Negocio
1. **Bloqueo de Salida**: `InventoryService` verifica la vigencia antes de cualquier consumo de stock. Si `fecha_actual > fecha_vencimiento`, se lanza `BusinessRuleError` y se bloquea la operación.
2. **Alertas Preventivas**: Un Worker (RQ) revisa diariamente los vencimientos. Si quedan menos de 30 días, genera una `Notification` para los administradores.

### Verificación de Links (Link Health)
Para asegurar que los respaldos digitales (`documento_url`) sigan accesibles:
- **Validación Automática**: Un Worker verifica periódicamente si los links retornan un estado HTTP válido (200 OK).
- **Campos de Auditoría**: 
    - `is_link_active`: Estado del último chequeo.
    - `last_link_check`: Fecha y hora de la última verificación.
- **Lógica**: Se utiliza un método `HEAD` (o `GET` liviano) para minimizar el tráfico. Si un link falla, se marca como inactivo pero no bloquea la operación (soft warning).

## Gestión de Clientes
Se ha implementado un endpoint para listar los clientes de la empresa actual, con soporte para paginación y filtrado por RLS.

### Endpoints
- `GET /api/v1/ventas/clientes/`: Retorna la lista de clientes activos.
  - **Parámetros**: `skip` (offset), `limit` (cantidad).
  - **Seguridad**: Filtra automáticamente por `empresa_id` del usuario autenticado.
