# Guía de Deployment - ERP3

**Última actualización**: 2026-02-06

---

## Requisitos del Servidor

### Hardware Mínimo

- **CPU**: 2 cores
- **RAM**: 4 GB
- **Disco**: 20 GB SSD
- **Red**: 100 Mbps

### Hardware Recomendado (Producción)

- **CPU**: 4+ cores
- **RAM**: 8+ GB
- **Disco**: 50+ GB SSD
- **Red**: 1 Gbps

### Software

- **OS**: Ubuntu 22.04 LTS (recomendado) o Windows Server 2019+
- **Python**: 3.10+
- **PostgreSQL**: 15+
- **Node.js**: 18+ LTS
- **Redis**: 7+ (para background jobs)
- **Nginx**: 1.18+ (reverse proxy)

---

## Configuración de Producción

### 1. Base de Datos (PostgreSQL)

#### Instalación

```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
```

#### Crear Base de Datos

```bash
sudo -u postgres psql

CREATE DATABASE erp3_db;
CREATE USER erp3_user WITH ENCRYPTED PASSWORD 'STRONG_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON DATABASE erp3_db TO erp3_user;
\q
```

#### Configuración de Acceso

Editar `/etc/postgresql/15/main/pg_hba.conf`:

```
# Permitir conexiones locales
local   erp3_db    erp3_user    md5
host    erp3_db    erp3_user    127.0.0.1/32    md5
```

Reiniciar PostgreSQL:

```bash
sudo systemctl restart postgresql
```

---

### 2. Backend (FastAPI)

#### Clonar Repositorio

```bash
git clone https://github.com/tu-org/erp3.git
cd erp3/backend
```

#### Crear Entorno Virtual

```bash
python3 -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows
```

#### Instalar Dependencias

```bash
pip install -r requirements.txt
```

#### Configurar Variables de Entorno

Crear archivo `.env` en `backend/`:

```env
# Base de Datos
DATABASE_URL=postgresql://erp3_user:STRONG_PASSWORD_HERE@localhost:5432/erp3_db

# Seguridad
SECRET_KEY=GENERATE_RANDOM_SECRET_KEY_HERE
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Entorno
ENVIRONMENT=production
PROJECT_NAME=ERP3
VERSION=1.0.0

# CORS (Ajustar según dominio)
BACKEND_CORS_ORIGINS=["https://app.erp3.com"]

# Redis (Background Jobs)
REDIS_URL=redis://localhost:6379/0
```

**Generar SECRET_KEY**:

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

#### Ejecutar Migraciones

```bash
alembic upgrade head
```

#### Inicializar Datos

```bash
python seed_data.py
```

---

### 3. Redis (Background Jobs)

#### Instalación

```bash
sudo apt install redis-server
sudo systemctl enable redis-server
sudo systemctl start redis-server
```

#### Verificar

```bash
redis-cli ping
# Respuesta: PONG
```

---

### 4. Servidor de Aplicación (Gunicorn + Uvicorn)

#### Instalar Gunicorn

```bash
pip install gunicorn
```

#### Crear Servicio Systemd

Crear archivo `/etc/systemd/system/erp3-api.service`:

```ini
[Unit]
Description=ERP3 FastAPI Application
After=network.target postgresql.service redis.service

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/var/www/erp3/backend
Environment="PATH=/var/www/erp3/backend/.venv/bin"
ExecStart=/var/www/erp3/backend/.venv/bin/gunicorn app.main:app \
    --workers 4 \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind 127.0.0.1:8000 \
    --access-logfile /var/log/erp3/access.log \
    --error-logfile /var/log/erp3/error.log

[Install]
WantedBy=multi-user.target
```

#### Crear Directorio de Logs

```bash
sudo mkdir -p /var/log/erp3
sudo chown www-data:www-data /var/log/erp3
```

#### Habilitar e Iniciar Servicio

```bash
sudo systemctl daemon-reload
sudo systemctl enable erp3-api
sudo systemctl start erp3-api
sudo systemctl status erp3-api
```

---

### 5. Worker de Background Jobs (RQ)

#### Crear Servicio Systemd

Crear archivo `/etc/systemd/system/erp3-worker.service`:

```ini
[Unit]
Description=ERP3 RQ Worker
After=network.target redis.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/erp3/backend
Environment="PATH=/var/www/erp3/backend/.venv/bin"
ExecStart=/var/www/erp3/backend/.venv/bin/python worker.py

[Install]
WantedBy=multi-user.target
```

#### Habilitar e Iniciar

```bash
sudo systemctl daemon-reload
sudo systemctl enable erp3-worker
sudo systemctl start erp3-worker
```

---

### 6. Frontend (Vue 3)

#### Build de Producción

```bash
cd frontend
npm install
npm run build
```

Esto genera archivos estáticos en `frontend/dist/`.

#### Copiar Archivos al Servidor

```bash
sudo mkdir -p /var/www/erp3/frontend
sudo cp -r dist/* /var/www/erp3/frontend/
sudo chown -R www-data:www-data /var/www/erp3/frontend
```

---

### 7. Nginx (Reverse Proxy)

#### Instalación

```bash
sudo apt install nginx
```

#### Configuración

Crear archivo `/etc/nginx/sites-available/erp3`:

```nginx
server {
    listen 80;
    server_name app.erp3.com;

    # Redirigir HTTP a HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name app.erp3.com;

    # Certificados SSL (Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/app.erp3.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/app.erp3.com/privkey.pem;

    # Frontend (Vue SPA)
    location / {
        root /var/www/erp3/frontend;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Swagger Docs
    location /docs {
        proxy_pass http://127.0.0.1:8000;
    }

    location /redoc {
        proxy_pass http://127.0.0.1:8000;
    }
}
```

#### Habilitar Sitio

```bash
sudo ln -s /etc/nginx/sites-available/erp3 /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

### 8. SSL/TLS (Let's Encrypt)

#### Instalar Certbot

```bash
sudo apt install certbot python3-certbot-nginx
```

#### Obtener Certificado

```bash
sudo certbot --nginx -d app.erp3.com
```

#### Renovación Automática

Certbot configura un cron job automáticamente. Verificar:

```bash
sudo certbot renew --dry-run
```

---

## Monitoreo y Logs

### Ver Logs del Backend

```bash
sudo journalctl -u erp3-api -f
# o
tail -f /var/log/erp3/error.log
```

### Ver Logs del Worker

```bash
sudo journalctl -u erp3-worker -f
```

### Ver Logs de Nginx

```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

---

## Backup y Recuperación

### Backup de Base de Datos

#### Script de Backup

Crear `/usr/local/bin/backup-erp3-db.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/erp3"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="erp3_db_$DATE.sql.gz"

mkdir -p $BACKUP_DIR

pg_dump -U erp3_user erp3_db | gzip > $BACKUP_DIR/$FILENAME

# Mantener solo últimos 7 días
find $BACKUP_DIR -name "erp3_db_*.sql.gz" -mtime +7 -delete

echo "Backup completado: $FILENAME"
```

#### Cron Job (Backup Diario)

```bash
sudo chmod +x /usr/local/bin/backup-erp3-db.sh
sudo crontab -e

# Agregar línea:
0 2 * * * /usr/local/bin/backup-erp3-db.sh
```

### Restaurar Backup

```bash
gunzip < /var/backups/erp3/erp3_db_YYYYMMDD_HHMMSS.sql.gz | \
    psql -U erp3_user erp3_db
```

---

## Actualización de la Aplicación

### 1. Actualizar Código

```bash
cd /var/www/erp3
sudo -u www-data git pull origin main
```

### 2. Backend

```bash
cd backend
source .venv/bin/activate
pip install -r requirements.txt
alembic upgrade head
sudo systemctl restart erp3-api
sudo systemctl restart erp3-worker
```

### 3. Frontend

```bash
cd frontend
npm install
npm run build
sudo cp -r dist/* /var/www/erp3/frontend/
```

---

## Seguridad

### Firewall (UFW)

```bash
sudo ufw allow 22/tcp   # SSH
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp  # HTTPS
sudo ufw enable
```

### PostgreSQL

- Usar contraseñas fuertes
- Restringir acceso solo a localhost
- Habilitar SSL para conexiones remotas

### Aplicación

- Cambiar `SECRET_KEY` en producción
- Usar HTTPS obligatorio
- Implementar rate limiting
- Mantener dependencias actualizadas

---

## Troubleshooting

### Backend no inicia

```bash
# Ver logs
sudo journalctl -u erp3-api -n 50

# Verificar puerto
sudo netstat -tlnp | grep 8000

# Verificar permisos
ls -la /var/www/erp3/backend
```

### Error de conexión a BD

```bash
# Verificar PostgreSQL
sudo systemctl status postgresql

# Probar conexión
psql -U erp3_user -d erp3_db -h localhost
```

### Worker no procesa jobs

```bash
# Verificar Redis
redis-cli ping

# Ver logs del worker
sudo journalctl -u erp3-worker -f
```

---

## Recursos Adicionales

- [FastAPI Deployment](https://fastapi.tiangolo.com/deployment/)
- [Gunicorn Docs](https://docs.gunicorn.org/)
- [Nginx Docs](https://nginx.org/en/docs/)
- [PostgreSQL Docs](https://www.postgresql.org/docs/)
