
## Implementación Actual (Backend v1)

### ✅ 1. Aislamiento Total (CRM vs Inventario)
- **Implementación**: Modelo `OpportunityLine` separado de `DetalleVenta`.
- **Lógica**: Las líneas de oportunidad (CRM) **NO** tocan la tabla `inventarios` ni `movimientos_stock`. Solo al ejecutar `CRMService.convert_opportunity_to_sale` se valida stock y se generan los registros de venta reales.

### ✅ 2. Liberación de Reservas (Prioridad Presencial)
- **Implementación**: Función `release_stale_reservations(hours_threshold)` en Ventas.
- **Lógica**: Identifica ventas/reservas antiguas (ej: > 24h) en estado "RECEPCIONADO" y ejecuta una anulación controlada que:
  1. Reversa los movimientos de stock (Devolución a Bodega).
  2. Libera la disponibilidad para venta inmediata.

### ✅ 3. Sustitución Inteligente (Stock Break Handling)
- **Implementación**: 
  - Campo `sustituye_a_id` en `DetalleVenta` (Self-referential FK).
  - Parámetro `substitutions` en conversión de CRM.
- **Lógica**: Si al convertir una oportunidad falta stock de Producto A, y se provee sustituto B:
  1. Se crea línea A con `cantidad_cancelada = total` (Registro de demanda insatisfecha).
  2. Se crea línea B (Sustituto) activa, vinculada a la línea A.
  3. El stock se descuenta solo del producto B.
