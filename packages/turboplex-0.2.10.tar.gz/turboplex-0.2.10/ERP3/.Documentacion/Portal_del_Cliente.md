# Portal del Cliente (Add-on) — Plan técnico y estado

## Resumen

El “Portal del Cliente” es un add-on orientado a clientes externos, con acceso restringido y aislación multi-tenant estricta, para consultar documentos y ejecutar acciones acotadas (aceptación de cotización subiendo OC, notificación/registro de pagos, descargas seguras).

## Fases

### Fase 1 — Backend multi-tenant (infraestructura + API)

Objetivo: crear la infraestructura de acceso y endpoints seguros para que un cliente externo solo vea sus propios datos, aislados por `empresa_id`.

### Fase 2 — Frontend portal (PWA ligera)

Objetivo: interfaz móvil simple con dashboards, documentos, timeline de pedidos y módulo de pagos.

### 🚀 Fase 3 — El "Motor de Negociación" (Esteroides de Venta)

**Objetivo:** Transformar la cotización estática en un objeto de diálogo transaccional e interactivo entre el Vendedor y el Cliente, con responsabilidades claras por estado.

#### 1. Ciclo de Vida y Propiedad de Datos (Máquina de Estados)
Para evitar errores financieros, la edición de campos se restringe según el estado de la cotización:

* **Estado: `BORRADOR_CLIENTE`**
    * **Responsable:** Cliente (Comprador).
    * **Acciones:** Agregar `producto_id`, definir `cantidad` y escribir `notas_tecnicas` (especificaciones).
    * **Precios:** El sistema muestra un "Precio Referencial" (Lista Base).

* **Estado: `PENDIENTE_VENDEDOR`** (Gatillado al "Enviar a Cotizar")
    * **Responsable:** Vendedor (ERP Interno).
    * **Acciones (Esteroides):** * **Matriz de Precios:** El vendedor aplica el `precio_neto_final` real (Convenio Sucursal > Cliente > Lista).
        * **Gestión de Quiebres:** Si no hay stock, setea un `producto_sugerido_id`.
        * **Logística:** Fija la `fecha_entrega_linea` por cada ítem.

* **Estado: `PROPUESTA_ENVIADA`**
    * **Responsable:** Cliente (Portal).
    * **Acciones:** El cliente revisa la oferta técnica y comercial.
    * **Control:** Puede **Rechazar/Eliminar** líneas (si el precio o el sugerido no le convence), pero **no puede editar los precios** impuestos por el vendedor.

* **Estado: `ACEPTADA_OC`**
    * **Acción:** El cliente sube el PDF de la Orden de Compra. El registro se bloquea (ReadOnly) y se sincroniza con el módulo de Pedidos del ERP.

#### 2. Estructura del Modelo de Datos (`crm_cotizaciones_items`)
El modelo debe soportar esta "doble entrada" de información:

| Campo | Origen | Editable por | Función |
| :--- | :--- | :--- | :--- |
| `producto_id` | Cliente | Cliente | Producto solicitado originalmente. |
| `cantidad` | Cliente | Ambos | Cantidad (el vendedor puede ajustar por empaque). |
| `notas_tecnicas` | Cliente | Cliente | Instrucciones (ej: "Corte especial", "Bordado logo"). |
| `producto_sugerido_id` | Vendedor | Vendedor | Reemplazo ofrecido por falta de stock. |
| `precio_neto_final` | Vendedor | Vendedor | Precio real de cierre de la transacción. |
| `fecha_entrega_linea` | Vendedor | Vendedor | Compromiso de entrega por producto. |
| `estado_item` | Sistema | Ambos | Enum: `solicitado`, `sugerido`, `rechazado_cliente`. |

#### 3. Lógica de Precios (Price Resolver)
El backend debe implementar un servicio de resolución de precios con la siguiente jerarquía de búsqueda:
1. **Prioridad 1:** Convenio Específico por Sucursal (`sucursal_id`).
2. **Prioridad 2:** Convenio Global por Cliente (`cliente_id`).
3. **Prioridad 3:** Lista de Precios Base del Sistema.

### Fase 4 — Jerarquía de Poder (Roles del Cliente)

Para soportar empresas cliente con múltiples departamentos, el Portal deja de ser un acceso único para convertirse en una estructura de roles basada en permisos sobre el `cliente_id`.

#### 1. Definición de Roles y Claims (JWT)
Se añaden los siguientes perfiles al modelo `PortalUser`:

* **Perfil "DUEÑO / MASTER" (is_master: true):**
    * **Acceso:** Visibilidad total cross-sucursal.
    * **Dashboard:** Vista gerencial con "Deuda Total Vencida" (consolidado de todas sus razones sociales) y "Pedidos en Tránsito".
    * **Nota:** No necesita aprobar digitalmente; su rol es de supervisión y control de gastos.

* **Perfil "COMPRADOR" (role: 'buyer'):**
    * **Acceso:** Limitado a su propia gestión y sucursales asignadas.
    * **Funciones:** Crear solicitudes de cotización, negociar ítems (Fase 3) y subir OCs.
    * **Restricción:** No puede ver facturas de otras áreas ni la deuda financiera global de la empresa, solo sus pedidos.

* **Perfil "CONTADOR / PAGOS" (role: 'finance'):**
    * **Acceso:** Módulo de Finanzas y Pagos.
    * **Funciones:** Ver estados de cuenta, descargar DTEs (Facturas/Notas de Crédito) y registrar comprobantes de pago.
    * **Restricción:** No tiene acceso a la creación o edición de cotizaciones operativas.


#### 2. Flujo Operativo Real
1. El **Comprador** obtiene la aprobación de su Jefe (vía interna/física).
2. El **Comprador** digita la solicitud en el Portal.
3. El **Vendedor** ajusta precios/stock (Fase 3).
4. El **Comprador** acepta la propuesta final y sube la OC.
5. El **Master** puede entrar en cualquier momento a ver cuánto se ha gastado y qué pedidos vienen en camino.    

#### 3. Ajustes al Modelo de Datos (Jerarquía)
- **Tabla `portal_users`**: 
    - Columna `role` (Enum: 'master', 'buyer', 'finance').
    - Columna `scope_sucursales` (JSON/Array): Lista de IDs de sucursales a las que tiene acceso (si es vacío y no es master, solo ve la principal).
- **Lógica de Filtro (RDL - Row Data Level)**:
    - Todas las queries al backend deben interceptar el `sub` del JWT y aplicar: 
      `WHERE cliente_id = :cid AND (is_master OR sucursal_id ANY(:scope_sucursales))`

🛠️ Ajustes al Modelo de Datos (Para el IDE)
Para implementar esto, el IDE deberá modificar las tablas existentes de la Fase 1:

portal_users: Agregar role (COMPRADOR, CONTADOR, DUEÑO).

crm_cotizaciones_items:

producto_sugerido_id (FK a productos).

notas_tecnicas (Text).

fecha_entrega_linea (Date).

estado_item (Enum: PENDIENTE, ACEPTADO, RECHAZADO).

crm_cotizaciones:

vendedor_operador_id (FK a usuarios ERP para suplencias).



## Restricciones (seguridad y producto)

1. Multi-tenant estricto usando `empresa_id`.
2. El cliente externo no debe tener acceso a endpoints administrativos del ERP.
3. Flujo requerido: Cotizar → recibir ajuste del vendedor → aceptar subiendo PDF de OC → ver historial (facturas/guías/OC) → notificar pago por transferencia subiendo comprobante.

## Modelo de acceso (invitados)

- `PortalUser` vinculado a una `Empresa`.
- Rol esperado: `ROLE_CLIENT` (lectura sobre documentos propios, escritura limitada a subir OC/comprobantes).

## Flujo de negocio (alto nivel)

1. Cliente inicia sesión en el portal.
2. Consulta cotizaciones asociadas a su contexto (`empresa_id` + identidad del cliente).
3. Acepta cotización subiendo PDF de OC (se persiste path/metadata; no se expone almacenamiento crudo).
4. Consulta historial consolidado de documentos (DTE + OC) con URLs de descarga seguras.
5. Notifica/Registra pago por transferencia (sube comprobante; se generan notificaciones internas para backoffice).

## Estado actual (Fase 1 — Backend)

- Tabla `portal_users` creada (migración + modelo `PortalUser`) con `UNIQUE (empresa_id, email)` para permitir múltiples usuarios por cliente.
- Auth del portal agregado: `POST /api/v1/portal/v1/auth/login` emite JWT con `aud="portal"` y claims `empresa_id`/`cliente_id`.
- Endpoint portal agregado: `GET /api/v1/portal/v1/mis-cotizaciones` (filtro estricto `empresa_id` + `cliente_id`).
- Endpoint portal agregado: `POST /api/v1/portal/v1/cotizaciones/{cotizacion_id}/aceptar` (upload OC PDF máx 2MB, guarda solo path en `crm_documentos`).
- Endpoint portal agregado: `GET /api/v1/portal/v1/mis-facturas` (DTE tipo 33/34 por defecto, filtro estricto `empresa_id` + `cliente_id`/`rut`).
- Endpoint portal agregado: `POST /api/v1/portal/v1/facturas/{dte_id}/notificar-pago` (upload comprobante PDF/JPG/PNG máx 2MB, guarda solo path en `portal_payment_notifications`).
- Endpoint portal agregado: `POST /api/v1/portal/v1/registrar-pago` (multipart: `dte_ids[]`, `monto`, `numero_operacion`, `banco`, `comprobante`; valida pertenencia de todos los DTEs antes de crear notificaciones).
- Endpoints admin de usuarios del portal (requiere `?cmp=empresa.codigo`):
  - RBAC: permite gestión a usuarios con rol por empresa `ADM` o `VEN` (vía `UsuarioEmpresa.rol.codigo`), bloqueando explícitamente `BOD`. También permite override por rol global `SUPERADMIN`/`DEVELOPER`/`ADMIN`.
  - Multi-tenant: los endpoints usan la misma sesión DB que resuelve `cmp` para asegurar `tenant context` consistente (evita `Tenant context missing for ORM execution`).
  - Crear: `POST /api/v1/portal/v1/admin/users`
  - Listar: `GET /api/v1/portal/v1/admin/users?cliente_id=...`
  - Ver: `GET /api/v1/portal/v1/admin/users/{portal_user_id}`
  - Activar/Desactivar: `PATCH /api/v1/portal/v1/admin/users/{portal_user_id}`
  - Reset password: `POST /api/v1/portal/v1/admin/users/{portal_user_id}/reset-password`
  - Eliminar: `DELETE /api/v1/portal/v1/admin/users/{portal_user_id}`
- Endpoints admin pagos agregados (`ADMIN`-only, requiere `?cmp=empresa.codigo`): listar notificaciones (filtro por estado) y aprobar/rechazar lote por `pago_batch_id`.
- Endpoints de descarga agregados:
  - `/portal/v1/cotizaciones/{id}/oc-url`
  - `/portal/v1/pagos/{id}/comprobante-url`
  - `/portal/v1/storage/download` (scoped por `empresa_id` + `cliente_id`)
- Descarga de DTE agregada:
  - `/portal/v1/dtes/{dte_id}/pdf`
  - `/portal/v1/dtes/{dte_id}/xml`
  - (scoped por `empresa_id` + `cliente_id`/`rut`; entrega binario desde la BD)
- Historial consolidado agregado: `/portal/v1/historial-documentos` (unifica DTE + OC con URLs de descarga).
- Ajuste interno: generación de URL de descarga usa querystring (`?path=...`) para compatibilidad con FastAPI `url_for`.
- Refactor: `api.py` queda como entrypoint y el resto se organiza en `app/addons/portal/routers` (`auth`/`quotes`/`documents`/`admin`) para mantener archivos bajo 600 líneas.
- Tests portal separados en suite dedicada: `backend/tests/test_portal_multitenant.py` y `backend/tests/test_portal_admin.py` (manteniendo aislación multi-tenant).
- Tests agregados: `backend/tests/test_portal_historial.py` (historial consolidado y descarga DTE).
- Higiene: formateo Black aplicado al add-on portal y tests; import no usado removido en `portal/api.py` (ruff OK en scope portal).
- Seguridad: para pagos, RBAC se mantiene `ADMIN`-only. Para usuarios del portal, RBAC se alinea a gestión comercial/administrativa (`ADM`/`VEN`) y bloquea `BOD`.

## Estado actual (Fase 2 — Frontend)

- Rutas dedicadas al portal: `/portal/login` y `/portal/documentos` (guard separado del ERP interno).
- Store Pinia portal auth: token aislado en `localStorage` (`portal_token`) + claims mínimos del JWT (`empresa_id`, `cliente_id`, `sub`).
- Cliente Axios portal: `baseURL: /api/v1/portal/v1`, interceptor agrega `Authorization: Bearer ...`, 401 hace logout y redirige a `/portal/login`.
- Vista “Centro de Documentos”: consume `GET /historial-documentos`, tabla responsive y descargas por blob para:
  - DTE: `GET /dtes/{id}/pdf`
  - OC: `GET /storage/download?path=...`

## ERP Interno — Gestión multi-usuario (Acceso al Portal)

- En la ficha de Cliente (ERP interno), se agrega la sección “Acceso al Portal” para administrar múltiples `PortalUser` por cliente.
- Visibilidad/edición restringida a roles por empresa `ADM` o `VEN` (y override por roles globales).
- UI incluye: listado por `cliente_id`, creación de accesos, toggle de estado, reset de contraseña (“Llave”) y eliminación con confirmación.

## Notas de despliegue (CRM opcional)

- El endpoint `/portal/v1/historial-documentos` incluye OCs si existen las tablas CRM (`crm_documentos` y `crm_oportunidades`). En entornos sin CRM/migraciones, el historial retorna solo DTEs para evitar errores por tablas inexistentes.

## Infraestructura y auditoría

- Read/Write routing en SQLAlchemy: `writer_engine`/`reader_engine` con `READ_DATABASE_URL` (SELECTs van a reader salvo transacción explícita o tras primera escritura en la request).
- Session Vars para auditoría: se setea `app.current_user_id` (transaction-local) desde sesión/auth para que triggers puedan leer `current_setting('app.current_user_id', true)`.
