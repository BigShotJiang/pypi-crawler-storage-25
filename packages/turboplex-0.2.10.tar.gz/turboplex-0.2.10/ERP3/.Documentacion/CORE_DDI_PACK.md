# CORE-DDI — Empaque Técnico (pack_core_ddi.py)

Este documento describe el script one-off [.one-off-scripts/pack_core_ddi.py](file:///c:/GitHub/ERP3/.one-off-scripts/pack_core_ddi.py), cuya finalidad es generar una carpeta externa “CORE-DDI” con evidencia técnica del diseño y la lógica propia del ERP, excluyendo dependencias y secretos.

## Objetivo

- Generar una “caja negra” reproducible del estado actual del proyecto para fines de DDI/peritaje.
- Exportar diseño de base de datos (DDL) sin datos.
- Copiar únicamente lógica propietaria seleccionada (backend y frontend).
- Generar evidencias forenses (sello de tiempo, árbol de archivos, hashes SHA-256).
- Prevenir filtración de credenciales mediante un escaneo heurístico de palabras clave.

## Salida (estructura de la carpeta CORE-DDI)

El script crea una carpeta de salida con esta estructura:

- database/
  - schema_full.sql: DDL completo del esquema (tablas, constraints, FK, etc.)
  - rls_policies.sql: extracto de sentencias relacionadas a RLS y Policies
  - auditoria.sql: DDL de la tabla de auditoría (si existe)
- backend_core/: subconjunto del backend con lógica propia (según globs)
- frontend_logic/: subconjunto del frontend con lógica propia (según globs)
- README_TECNICO.md: resumen + sello forense
- FILE_TREE.txt: listado plano de archivos dentro del CORE-DDI
- HASHES.txt: SHA-256 por archivo dentro del CORE-DDI

## Vista rápida de Estructura de DB (view_db_structure.py)

Para una documentación rápida de la estructura y seguridad de la base, usa:

- Script: /.one-off-scripts/view_db_structure.py
- Genera: db_tablas_y_relaciones.sql, db_rls_policies.sql, db_motor_auditoria.sql, SUMMARY.txt
- Ejemplo:
  - `python .one-off-scripts\view_db_structure.py --output-dir "C:\Core\DB_View" --pg-bin "C:\Program Files\PostgreSQL\18\bin" --audit-table audit_logs`

## Requisitos

- Python disponible en PATH.
- PostgreSQL tools:
  - pg_dump.exe accesible vía PATH, o
  - `--pg-bin "C:\Program Files\PostgreSQL\XX\bin"`, o
  - `--pg-dump "C:\...\pg_dump.exe"`
- DATABASE_URL:
  - Por defecto se lee desde `backend/.env` (clave `DATABASE_URL=`), o
  - se puede proveer explícitamente con `--source-db-url`.
- Git (opcional): si existe `git` en el entorno y el repo tiene commits, se inserta el HEAD en el README.

## Uso (Windows PowerShell)

Ejemplo típico:

```powershell
cd C:\GitHub\ERP3
python .one-off-scripts\pack_core_ddi.py `
  --output-dir "C:\Core\CORE-DDI_Snapshot_2026" `
  --pg-bin "C:\Program Files\PostgreSQL\18\bin"
```

Usando una tabla de auditoría específica:

```powershell
python .one-off-scripts\pack_core_ddi.py `
  --output-dir "C:\Core\CORE-DDI_Snapshot_2026" `
  --pg-bin "C:\Program Files\PostgreSQL\18\bin" `
  --audit-table audit_logs
```

## Flags soportadas

- `--output-dir` (requerido): carpeta destino. Si existe, se borra y se regenera.
- `--source-db-url`: URL DB origen para generar DDL (si no, toma `DATABASE_URL` desde `backend/.env`).
- `--pg-bin`: carpeta bin de PostgreSQL para resolver `pg_dump.exe`.
- `--pg-dump`: ruta explícita a `pg_dump.exe`.
- `--include-backend`: globs separados por coma para seleccionar qué copiar desde `backend/`.
- `--include-frontend`: globs separados por coma para seleccionar qué copiar desde la raíz del repo hacia `frontend_logic/`.
- `--audit-table`: nombre de la tabla de auditoría a exportar a `database/auditoria.sql` (opcional).
- `--allow-secrets`: no aborta aunque encuentre coincidencias de “secretos”.
- `--self-destruct`: programa auto-borrado del script 2s después de terminar.

## Export DDL (sin datos)

El script ejecuta `pg_dump --schema-only` contra `DATABASE_URL` y escribe `database/schema_full.sql`.

Características:

- No incluye datos.
- No incluye owner/privilegios (`--no-owner --no-privileges`) para evitar filtrar configuración local.
- Usa URL libpq (convierte `postgresql+psycopg2://` a `postgresql://`).

## RLS y Policies (multi-tenant)

Para evidenciar la “inteligencia” de aislamiento, el script genera `database/rls_policies.sql` extrayendo líneas del `schema_full.sql` que contengan:

- `ROW LEVEL SECURITY`
- `CREATE POLICY`
- `ALTER POLICY`

Esto permite entregar al DDI un extracto focalizado de seguridad, sin tener que inspeccionar el DDL completo.

## Auditoría (tabla específica)

El archivo `database/auditoria.sql` se genera con:

- `pg_dump --schema-only --table=<audit_table>`

Si la tabla no existe, el script:

- no falla por defecto,
- deja `auditoria.sql` vacío,
- imprime un aviso.

## Sello forense (README + hashes)

`README_TECNICO.md` incluye:

- Fecha/Hora de generación en UTC.
- Git HEAD (si está disponible; si no, `N/A`).

`HASHES.txt` contiene el SHA-256 de cada archivo empaquetado dentro del CORE-DDI, útil para:

- detectar alteraciones posteriores,
- demostrar integridad del snapshot.

## Escaneo preventivo de secretos

El script escanea archivos de texto copiados dentro del CORE-DDI buscando estas palabras clave:

- `API_KEY`, `PASSWORD`, `SECRET_KEY`, `TOKEN`, `PRIVATE_KEY`

Comportamiento:

- Por defecto: si encuentra coincidencias, aborta y borra la carpeta de salida.
- Con `--allow-secrets`: continúa y solo advierte por consola.

Este escaneo es heurístico (puede marcar falsos positivos). Para un paquete estricto para DDI, se recomienda ejecutar sin `--allow-secrets` y corregir/excluir las coincidencias reales.

## Troubleshooting

**Error: “can't open file ... .one-off-scripts\.one-off-scripts\pack_core_ddi.py”**

- Estás ejecutando el comando desde el directorio incorrecto.
- Solución: ejecuta desde la raíz del repo `C:\GitHub\ERP3` y usa la ruta:
  - `python .one-off-scripts\pack_core_ddi.py ...`

**Error: “pg_dump: error: no matching tables were found”**

- La tabla indicada por `--audit-table` no existe.
- Solución: cambia `--audit-table` al nombre real o déjalo vacío; el script continúa y genera `auditoria.sql` vacío.

**Abort por secretos**

- El escaneo encontró palabras clave. Revisa los archivos listados, elimina hardcodes o ajusta qué se copia.
- Si necesitas generar el snapshot igual para inspección interna: usa `--allow-secrets`.
