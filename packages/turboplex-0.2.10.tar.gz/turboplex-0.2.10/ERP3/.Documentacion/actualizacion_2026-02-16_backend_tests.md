Fecha: 2026-02-16

Cambios aplicados (backend/tests):
- tests/test_core_integration.py: Se usa jsonable_encoder en payloads para serializar UUIDs.
- tests/conftest.py: setup_db evita drop_all/create_all y realiza limpieza con TRUNCATE; se fuerza allow_no_tenant en sesiones de prueba.

Acciones de base de datos (erp3_test):
- Migraciones Alembic aplicadas con éxito.
- Intento de ajustar ownership/privilegios vía scripts en .one-off-scripts (requiere superusuario). Operación falló por credenciales.

Siguiente paso sugerido:
- Ejecutar en pgAdmin (como superusuario): transferir OWNER y GRANT sobre esquema public a erp3_test_admin; luego reejecutar subset de pruebas.
