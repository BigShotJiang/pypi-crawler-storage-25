# Configuración de Timeouts para PostgreSQL

## Problema
Los timeouts de conexión y queries no están configurados, lo que puede causar que queries lentas bloqueen el sistema indefinidamente.

## Solución Manual

Editar el archivo `backend/app/core/database.py` en la línea 27-32:

### Código Actual
```python
else:
    # PostgreSQL optimized settings
    engine_args.update({
        "pool_size": 20,
        "max_overflow": 10,
        "pool_timeout": 30,
        "pool_recycle": 3600,
    })
```

### Código Actualizado
```python
else:
    # PostgreSQL optimized settings
    engine_args.update({
        "pool_size": 20,
        "max_overflow": 10,
        "pool_timeout": 30,
        "pool_recycle": 3600,
        "connect_args": {
            "connect_timeout": 10,  # Timeout de conexión: 10 segundos
            "options": "-c statement_timeout=30000"  # Timeout de queries: 30 segundos
        }
    })
```

## Beneficios
- Conexiones que tardan más de 10 segundos se cancelan automáticamente
- Queries que tardan más de 30 segundos se cancelan automáticamente
- Previene bloqueos indefinidos del sistema
