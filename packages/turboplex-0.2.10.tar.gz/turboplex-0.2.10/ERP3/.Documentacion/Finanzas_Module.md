# Módulo de Finanzas y Contabilidad

## Descripción General
El módulo de Finanzas ha sido actualizado para cumplir con la normativa contable chilena (SII). Incluye un Plan de Cuentas (PCU) jerárquico, contabilidad de partida doble, y generación automática de asientos para Ventas (Boletas/Facturas) y Gastos.

## Características Principales

### 1. Plan de Cuentas (PCU)
- Estructura jerárquica estándar (Activo, Pasivo, Patrimonio, Ingresos, Gastos).
- Soporte para 4 niveles de profundidad (ej. 1.1.01.01).
- Inicialización automática mediante endpoint o servicio.

### 2. Automatización Contable
- **Ventas**: Al crear una venta, se genera automáticamente un asiento contable:
  - **Debe**: Caja/Banco (Total)
  - **Haber**: IVA Débito Fiscal (19%)
  - **Haber**: Ingresos por Venta (Neto)
- **Gastos**: Al registrar un gasto, se genera su asiento:
  - **Debe**: Cuenta de Gasto (Neto)
  - **Debe**: IVA Crédito Fiscal (19%)
  - **Haber**: Caja/Banco (Total)

### 3. Reportes SII
- **Libro Diario**: Listado cronológico de todos los asientos confirmados.
- **Libro de Ventas**: Registro auxiliar para declaración de IVA (F29).
- **Libro de Compras**: Registro auxiliar de gastos y compras con derecho a crédito fiscal.
- **Balance General**: Estado financiero de 8 columnas (simplificado) mostrando saldos de cuentas.

### 4. Estándar de Cálculo de IVA y Schemas de Salida
- Todo desglose `Neto/IVA/Total` usa la función compartida `calculate_taxes_from_total` del módulo de Finanzas, que obtiene la tasa de IVA desde el parámetro global `IVA_RATE` (tabla `parametros_globales`, scope GLOBAL) o, en su defecto, desde `config_manager` (`IVA_RATE`) y luego `settings.CHILE_IVA_RATE`, aplicando redondeo al peso (ROUND_HALF_UP) y manteniendo la suma exacta en CLP (ej: 10.000 → 8.403 + 1.597).
- Los asientos automáticos de Ventas y Gastos utilizan este mismo desglose para garantizar consistencia entre API, contabilidad y reportes SII, respetando que los montos finales en CLP sean enteros según normativa SII.
- Los endpoints de Ventas que exponen documentos comerciales usan `BaseResponse[VentaOut]` como contrato estándar; `VentaOut` incluye ahora `monto_neto` y `monto_iva` derivados del `total` y calculados con la misma lógica centralizada de IVA.

## Endpoints API

### Contabilidad
- `POST /api/v1/finanzas/contabilidad/init-pcu`: Inicializa el PCU para la empresa.
- `GET /api/v1/finanzas/contabilidad/cuentas`: Lista el plan de cuentas.
- `GET /api/v1/finanzas/contabilidad/libro-diario`: Obtiene asientos por rango de fecha.
- `GET /api/v1/finanzas/contabilidad/libro-auxiliar?tipo=VENTAS|COMPRAS`: Obtiene libros auxiliares.
- `GET /api/v1/finanzas/contabilidad/balance-general?anio=YYYY`: Obtiene el balance anual.

### Gastos
- `POST /api/v1/finanzas/gastos/`: Crea un gasto y su asiento contable asociado.

## Modelo de Datos
- **CuentaContable**: Definición del PCU.
- **AsientoContable**: Cabecera de la transacción (fecha, glosa, origen).
- **MovimientoContable**: Detalle (Debe/Haber) vinculado a una cuenta.
