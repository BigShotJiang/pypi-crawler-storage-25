# 📦 Módulo de Compras (Procurement)

Este módulo gestiona el ciclo completo de abastecimiento, desde la creación de proveedores hasta la recepción de mercancía y su impacto financiero.

## 🏗️ Arquitectura

Ubicación: `app/core_modules/compras/`

### Modelos de Datos (`models.py`)

1.  **Proveedor (`Proveedor`)**:
    *   Gestión de terceros con datos comerciales (RUT, Razón Social, Plazo Pago).
    *   Vinculado a `Empresa` (Multitenancy).

2.  **Orden de Compra (`OrdenCompra`)**:
    *   Documento central del flujo.
    *   Estados: `BORRADOR` -> `ENVIADA` -> `PARCIAL` -> `RECIBIDA` -> `CANCELADA`.
    *   Relación con `Sucursal` y `Bodega` de destino.

3.  **Detalle de OC (`OrdenCompraDetalle`)**:
    *   Items individuales de la orden (Insumos/Productos).

### 🔄 Flujo de Eventos & Integración

El módulo utiliza el `EventDispatcher` para orquestar acciones en otros sistemas sin acoplamiento directo.

#### Evento: `EVENT_COMPRA_RECIBIDA`

Se dispara cuando una OC cambia al estado `RECIBIDA`.

1.  **Impacto WMS (Inventario)**:
    *   **Listener**: `app/core_modules/compras/listeners.py`
    *   **Acción**: Incrementa el stock físico en la `Ubicacion` específica de la bodega.
    *   **Registro**: Crea un `MovimientoStock` de tipo `ENTRADA_COMPRA`.

2.  **Impacto Financiero (Contabilidad)**:
    *   **Listener**: `app/core_modules/finanzas/listeners.py`
    *   **Acción**: Genera un Asiento Contable automático.
        *   **Debe**: Cuenta de Existencias (Activo) - Aumenta valor inventario.
        *   **Haber**: Cuenta Proveedores (Pasivo) - Registra la deuda.

### 🛠️ Servicios Clave

*   **`recepcionar_orden(orden_id)`**: Valida la OC y dispara el evento de recepción.
*   **`get_deuda_proveedor(rut)`**: (En Finanzas) Calcula el saldo pendiente de pago a un proveedor basado en los asientos generados.

## 👥 Gestión de Proveedores

- Endpoints CRUD en `/api/v1/compras/proveedores/`.
- Permite crear, listar, actualizar y eliminar (soft delete) proveedores.
- **Nota de Migración**: Anteriormente los proveedores se gestionaban en el módulo `Finanzas` (`/api/v1/proveedores/`). Esos endpoints han sido marcados como obsoletos (`deprecated`) y redirigen a los nuevos en `Compras`.

## 🧾 Aprobación de Orden de Compra

- Endpoint: `POST /api/v1/compras/ordenes-compra/{orden_id}/aprobar`
- Autorización: Guard combinado que permite `ADM` o el scope `compras:approve` (modo `any`).
- Respuesta: DTO Pydantic `OrdenCompra` (UUID-native; `ConfigDict(from_attributes=True)`).
- Comportamiento:
  - Cambia estado de `BORRADOR` a `ENVIADA` (o valida que no esté `RECIBIDA/CANCELADA`).
  - Emite evento `orden_compra.aprobada` con payload incluyendo `empresa_id`, `orden_compra_id`, `proveedor_id`, `sucursal_id`, `bodega_id`, `usuario_id` y `total`.
- Auditoría RBAC:
  - Si el usuario carece de rol/scope requerido, se devuelve `403` y se registra `AuditLog` con acción `RBAC_ROLE_SCOPE_DENIED` indicando `empresa_id`, `required_roles`, `required_scopes`, `user_role` y `user_scopes`.
