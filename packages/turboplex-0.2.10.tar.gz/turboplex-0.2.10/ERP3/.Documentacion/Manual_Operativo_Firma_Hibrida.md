# Manual Operativo: Sistema de Firma Híbrida (Papel y Digital)

**Fecha:** 12-02-2026
**Versión:** 1.1
**Módulo:** CRM / Legal / Despacho

## 1. Visión General
El sistema ERP3 implementa un modelo de **Firma Híbrida** para la entrega de productos y servicios. Este modelo permite operar flexiblemente tanto en escenarios tradicionales (papel) como modernos (digital/ClaveÚnica), manteniendo siempre la integridad y trazabilidad legal de los documentos.

## 2. Flujo 1: Firma Manual (Guía de Despacho en Papel)
Este flujo está diseñado para entregas físicas donde el cliente firma un documento impreso, o como respaldo ante fallas de conectividad.

### 2.1 Proceso
1.  **Preparación:** El vendedor solicita "Preparar Firma" desde el CRM.
    *   *Validación:* El sistema verifica Crédito Aprobado y Stock Reservado.
2.  **Generación de Documento Seguro:**
    *   El backend genera un PDF profesional ("Guía de Despacho Electrónica").
    *   **Seguridad:** Se incrusta un Código QR de validación y un **Hash de Integridad (SHA-256)** visible en el pie de página.
    *   El PDF se almacena en Cloudflare R2 (nube) o localmente.
3.  **Impresión:**
    *   El usuario previsualiza el PDF en el navegador.
    *   Se imprime el documento físico.
4.  **Confirmación:**
    *   El usuario confirma la acción en el sistema.
    *   El estado de la oportunidad cambia a **`ESPERANDO_FIRMA_MANUAL`**.

### 2.2 Medidas de Seguridad en Papel
A diferencia de una impresión común, nuestras guías incluyen:
*   **Código QR:** Apunta a una URL única de validación (`/validate/doc/{id}`).
*   **Hash de Integridad:** Una cadena alfanumérica impresa (SHA-256) que representa el contenido matemático del documento (ID + Monto + Fecha). Si alguien altera los montos en el papel, el hash no coincidirá con el registro del sistema.

## 3. Flujo 2: Firma Digital (ClaveÚnica - Roadmap)
Este flujo elimina el papel y utiliza la identidad digital del estado (Chile).

### 3.1 Proceso Proyectado
1.  **Escaneo:** El cliente o transportista escanea el QR de la guía (en tablet o celular).
2.  **Redirección:** El dispositivo abre el portal de ClaveÚnica.
3.  **Autenticación:** El cliente ingresa su RUN y Clave.
4.  **Firma Electrónica:**
    *   ClaveÚnica confirma la identidad.
    *   El sistema estampa una firma digital criptográfica en el PDF.
    *   El estado cambia automáticamente a **`FIRMADO`** (o `GANADA`).

## 4. Componentes del Sistema

### 4.1 Backend
*   **Servicio PDF (`app/services/pdf_generator.py`):** Motor de renderizado vectorial que crea documentos PDF ligeros y seguros con `reportlab` y `qrcode`.
*   **Integridad (`CRMService`):** Calcula hashes SHA-256 antes de guardar para garantizar que lo que se ve es lo que se firma.
*   **Almacenamiento (R2):** Repositorio inmutable de documentos legales.

### 4.2 Frontend
*   **DeliveryControl (`src/components/crm/DeliveryControl.vue`):** Panel de control para el vendedor. Permite:
    *   Generar Guía (API).
    *   Visualizar PDF (Iframe seguro).
    *   Imprimir (Nativo).
    *   Confirmar entrega manual.
    *   **Corregir/Anular:** Permite revertir el proceso en caso de errores antes de la firma.

## 5. Manejo de Errores y Anulaciones
El sistema contempla la posibilidad de errores humanos (ej. impresión defectuosa, datos incorrectos en la guía) antes de la firma final.

### 5.1 Flujo de Corrección
1.  **Detección:** El vendedor nota un error en el documento impreso o en la previsualización.
2.  **Acción:** Presiona el botón **"Corregir/Anular"** (icono rojo) en el panel `DeliveryControl`.
    *   Este botón solo está disponible mientras la oportunidad no esté `GANADA` (Firmada).
3.  **Anulación en Backend (`POST /void-document`):**
    *   El sistema busca todos los documentos legales en estado `PENDIENTE` asociados a la oportunidad.
    *   Cambia su estado a **`ANULADO`**.
    *   **Versionamiento en R2:** Los archivos físicos en la nube NO se borran ni sobrescriben. Se mantienen como evidencia histórica de lo generado, garantizando auditoría completa. Al generar una nueva guía, se crea un nuevo archivo con un UUID diferente.
4.  **Reinicio:** La oportunidad vuelve automáticamente al estado **`ABIERTA`**.
5.  **Regeneración:** El vendedor puede editar los datos y volver a iniciar el flujo de firma.

## 6. Estados de Oportunidad Relacionados
*   **`ABIERTA`**: En negociación / Corrección.
*   **`ESPERANDO_FIRMA`**: Documento generado, listo para firmar (digital o papel).
*   **`ESPERANDO_FIRMA_MANUAL`**: Documento impreso y entregado para firma física.
*   **`GANADA`**: Firma validada y proceso cerrado.
