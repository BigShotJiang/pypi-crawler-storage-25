# Puntos Clave de Seguridad - Carga 40K (Familia + SKU)

## 1. Protección de Identidad (Idempotencia)

- El sistema usa un `file_hash`. Si subes el mismo archivo exacto dos veces, se bloqueará por seguridad.
- Para reintentar tras una corrección, cambia el nombre del archivo.

## 2. Política de "Solo Actualización"

- El Excel de Familias NO crea productos nuevos.
- Si un SKU no existe en la DB, el sistema lo ignora y lanza un aviso.
- Esto evita ensuciar el catálogo con basura.

## 3. Normalización de Datos

- Las familias se guardan automáticamente en MAYÚSCULAS y sin espacios extra (`.strip().upper()`).
- Esto evita tener duplicados como "Calzado" y "CALZADO".

## 4. Integridad del Inventario

- La ruta de "Enriquecimiento" es independiente.
- Actualizar la familia no toca el stock, no crea variantes y no genera movimientos de almacén.

## 5. Validación de Errores

- El proceso no se detiene si encuentra un SKU fallido.
- Loguea el error y continúa con la siguiente fila para asegurar que el grueso de las 40k filas se procese.

## 6. Protección de Datos Existentes

- Si una celda de `familia` viene vacía en el Excel, el sistema no borrará la familia que ya tenga el producto en la base de datos.

