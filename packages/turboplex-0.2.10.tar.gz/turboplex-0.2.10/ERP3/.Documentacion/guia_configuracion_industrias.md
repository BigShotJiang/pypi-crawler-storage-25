# Guía de Configuración de Industrias (Service Engine)

Este documento explica cómo configurar nuevas **Plantillas de Industria** (Industry Templates) en el Service Engine de ERP3.

El Service Engine es un motor **agnóstico** que se adapta a diferentes industrias mediante configuraciones JSON/Python definidas en `app/core_modules/service_engine/industry_templates.py`.

## 1. Conceptos Clave

- **Workflow (Flujo de Trabajo)**: Define los estados por los que pasa una Orden de Servicio (ej: `RECIBIDO` -> `LAVADO` -> `ENTREGADO`).
- **Metadata Schema**: Un esquema JSON Schema que define qué datos extra se deben capturar al crear una orden (ej: `patente`, `kilometraje`, `color_prenda`).
- **Transiciones**: Reglas que dictan qué cambios de estado son válidos.

## 2. Ubicación del Archivo

Todas las plantillas se definen en:
`backend/app/core_modules/service_engine/industry_templates.py`

## 3. Cómo Agregar una Nueva Industria

Para agregar una nueva configuración de industria (ej: "Reparación de Celulares"), simplemente añade un nuevo diccionario al archivo `industry_templates.py`.

### Ejemplo: Reparación de Celulares

```python
CELULARES_TEMPLATE = {
    "name": "Servicio Técnico Celulares",
    "description": "Flujo para reparación de dispositivos móviles",
    "workflow": {
        "steps": [
            "RECEPCION",
            "DIAGNOSTICO",
            "ESPERA_REPUESTO",
            "REPARACION",
            "PRUEBAS_QA",
            "LISTO_RETIRO",
            "ENTREGADO"
        ],
        "transitions": {
            "RECEPCION": ["DIAGNOSTICO"],
            "DIAGNOSTICO": ["ESPERA_REPUESTO", "REPARACION", "LISTO_RETIRO"],
            "ESPERA_REPUESTO": ["REPARACION"],
            "REPARACION": ["PRUEBAS_QA"],
            "PRUEBAS_QA": ["LISTO_RETIRO", "REPARACION"], # Si falla QA, vuelve a reparación
            "LISTO_RETIRO": ["ENTREGADO"]
        }
    },
    "metadata_schema": {
        "type": "object",
        "properties": {
            "marca": {"type": "string", "title": "Marca"},
            "modelo": {"type": "string", "title": "Modelo"},
            "imei": {"type": "string", "title": "IMEI / Serie"},
            "patron_desbloqueo": {"type": "string", "title": "Patrón/PIN"},
            "falla_reportada": {"type": "string", "title": "Falla Reportada"},
            "incluye_cargador": {"type": "boolean", "title": "Deja Cargador"}
        },
        "required": ["marca", "modelo", "falla_reportada"]
    }
}
```

## 4. Activación

Una vez definida la plantilla, el frontend (o la API) puede consumirla para renderizar formularios dinámicos basados en el `metadata_schema` y guiar el flujo de estados según las `transitions`.

No se requiere reinicio del servidor si se modifica solo la configuración (dependiendo de la estrategia de caché), pero se recomienda reiniciar para asegurar que los nuevos templates estén disponibles.
