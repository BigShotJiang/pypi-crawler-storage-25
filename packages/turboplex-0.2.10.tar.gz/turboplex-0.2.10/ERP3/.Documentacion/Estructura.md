# 📂 Estructura del Proyecto ERP3

Este documento detalla la organización de archivos y directorios del proyecto, explicando el propósito de cada componente clave.

```graphql
ERP3/
├── .Documentacion/             # Documentación centralizada del proyecto
│   ├── changelog.md            # Registro de cambios cronológico
│   ├── CORE_MODULES.md         # Definición de módulos del núcleo
│   ├── configuracion.md        # Guías de configuración y despliegue
│   └── Estructura.md           # Este archivo (mapa del proyecto)
│
├── backend/                    # API RESTful con FastAPI
│   ├── .venv/                  # Entorno virtual de Python
│   ├── .one-off-scripts/       # Scripts de utilidad de un solo uso
│   ├── app/                    # Código fuente principal
│   │   ├── api/                # Router principal y dependencias
│   │   │   ├── v1/             # Versionado de la API
│   │   │   │   ├── admin/      # Endpoints de administración global (SaaS)
│   │   │   │   └── ...
│   │   │   └── deps.py         # Dependencias (Auth, DB, Contexto)
│   │   │
│   │   ├── core/               # Configuración central
│   │   │   ├── audit.py        # Auditoría base
│   │   │   ├── config.py       # Variables de entorno
│   │   │   ├── database.py     # SessionLocal y Engine
│   │   │   ├── events.py       # Bus de eventos interno
│   │   │   ├── exceptions.py   # Excepciones globales
│   │   │   ├── logging_config.py # Configuración de logs
│   │   │   ├── security.py     # JWT y hashing
│   │   │   ├── telemetry.py    # OpenTelemetry/Tracing
│   │   │   └── uuid_utils.py   # Utilidades para UUIDv7 (Cronología)
│   │   │
│   │   ├── core_modules/       # Módulos Transversales del ERP
│   │   │   ├── auditoria/      # Logs de Auditoría Universal
│   │   │   ├── compras/        # Abastecimiento y Proveedores
│   │   │   ├── crm/            # Gestión de Relaciones con Clientes
│   │   │   ├── facturacion/    # DTE y Firma Digital
│   │   │   ├── finanzas/       # Motor de Precios, Egresos, Caja
│   │   │   ├── integraciones/  # Conectores externos
│   │   │   ├── legal/          # Documentos legales y contratos
│   │   │   ├── notificaciones/ # Sistema de Alertas
│   │   │   ├── rrhh/           # Gestión de Personal
│   │   │   ├── service_engine/ # Motor de Servicios Industriales
│   │   │   ├── sistema/        # Bodegas, Multi-tenant, Seguridad
│   │   │   ├── ti/             # Activos TI
│   │   │   ├── ventas/         # POS, Ventas, Clientes
│   │   │   └── webhooks/       # Integración Externa (n8n/Zapier)
│   │   │
│   │   ├── models/             # Modelos ORM Globales/Legacy
│   │   ├── schemas/            # Esquemas Pydantic Globales/Legacy
│   │   ├── services/           # Servicios transversales (Auditoría)
│   │   └── main.py             # Punto de entrada (FastAPI app)
│   │
│   ├── tests/                  # Pruebas de integración y unitarias
│   ├── alembic/                # Migraciones de base de datos
│   └── requirements.txt        # Dependencias del backend
│
└── frontend/                   # Interfaz de Usuario (Vue 3 + Vite)
    ├── src/
    │   ├── components/         # Componentes reutilizables
    │   │   └── dev/            # Widgets técnicos (Monitor, Precios)
    │   ├── layout/             # Plantillas de diseño (Admin, Client)
    │   ├── router/             # Configuración de Vue Router
    │   ├── services/           # Capa de comunicación API (Axios)
    │   ├── stores/             # Gestión de Estado (Pinia)
    │   │   ├── auth.js         # Lógica de sesión y roles
    │   │   └── holding.js      # Datos de empresas y licencias
    │   └── views/              # Páginas de la aplicación
    │       ├── admin/          # Vistas de Super Admin (SaaS)
    │       ├── Dashboard.vue   # Dashboard principal
    │       └── DevDashboard.vue # Dashboard técnico
    ├── index.html              # Punto de entrada HTML
    ├── package.json            # Dependencias del frontend
    └── vite.config.js          # Configuración de Vite
```

## 🧩 Descripción de Módulos

### Backend (`/app`)

El backend se ha reestructurado en una arquitectura modular para facilitar la escalabilidad:

- **core_modules/**: Contiene la lógica de negocio fundamental compartida por todas las industrias.
  - *Compras*: Gestión de proveedores, órdenes de compra y recepción de inventario (WMS).
  - *Finanzas*: Control monetario centralizado, contabilidad automática y tesorería.
  - *Sistema*: Gestión de infraestructura, bodegas, seguridad y multitenancy.
  - *Webhooks*: Sistema de integración universal para notificaciones externas en tiempo real.
  - *Auditoría*: Registro inmutable de eventos críticos del sistema.
  - *CRM*: Gestión de pipeline de ventas y oportunidades.
  - *Legal*: Gestión de documentos legales y firmas digitales.
  - *Service Engine*: Motor de orquestación de servicios con templates industriales dinámicos.
  - *Facturación*: Emisión de DTEs y comunicación con SII.
- **core/**: Configuración técnica inmutable (BD, Seguridad, UUIDv7 Utils).

### Frontend (`/frontend`)

Aplicación SPA moderna construida con Vue 3:

- **Stores (Pinia)**: Manejo centralizado del estado de sesión y datos del holding.
- **Router**: Navegación protegida por roles (`DEVELOPER`, `SUPERADMIN`).
- **Views**:
  - *Admin*: Herramientas de gestión SaaS (Licenciamiento, Métricas).
  - *Dev*: Herramientas de diagnóstico técnico.

---

## 📋 Convenciones de Código

### Nomenclatura

#### Backend (Python)

- **Archivos**: `snake_case.py`
- **Clases**: `PascalCase` (ej: `OrdenServicio`, `CuentaContable`)
- **Funciones/Métodos**: `snake_case` (ej: `get_current_user`, `create_venta`)
- **Constantes**: `UPPER_SNAKE_CASE` (ej: `EVENT_ORDEN_FINALIZADA`)
- **Variables privadas**: `_leading_underscore`

#### Frontend (JavaScript/Vue)

- **Archivos de componentes**: `PascalCase.vue` (ej: `Dashboard.vue`)
- **Archivos de servicios**: `camelCase.js` (ej: `api.js`)
- **Stores**: `camelCase.js` (ej: `auth.js`)
- **Funciones**: `camelCase` (ej: `fetchVentas`, `createAsiento`)
- **Constantes**: `UPPER_SNAKE_CASE`

### Organización de Módulos

Cada módulo en `core_modules/` debe seguir esta estructura:

```
modulo/
├── __init__.py          # Exporta router y metadata
├── models.py            # Modelos SQLAlchemy
├── schemas.py           # Esquemas Pydantic (validación)
├── api.py               # Endpoints FastAPI
├── services.py          # Lógica de negocio
├── listeners.py         # Listeners de eventos (opcional)
└── README.md            # Documentación del módulo (opcional)
```

### Responsabilidades por Archivo

- **`models.py`**: Solo definiciones de tablas SQLAlchemy, sin lógica de negocio
- **`schemas.py`**: Validación de entrada/salida, transformaciones simples
- **`api.py`**: Routing, validación de permisos, orquestación de servicios
- **`services.py`**: Lógica de negocio compleja, transacciones, cálculos

---

## 🏗️ Arquitectura por Capas

### Capa de Presentación (Frontend)

```
Usuario → Vue Components → Pinia Store → Axios → Backend API
```

**Responsabilidades**:
- Renderizado de UI
- Validación de formularios (básica)
- Gestión de estado local
- Navegación

### Capa de API (Backend)

```
Request → Router → Dependencies → Service → Database
                    ↓
                Auth/Permisos
```

**Responsabilidades**:
- Autenticación y autorización
- Validación de entrada (Pydantic)
- Orquestación de servicios
- Serialización de respuestas

### Capa de Servicios

**Responsabilidades**:
- Lógica de negocio compleja
- Transacciones de base de datos
- Dispatch de eventos
- Cálculos y transformaciones

### Capa de Datos

**Responsabilidades**:
- Persistencia
- Integridad referencial
- Constraints y validaciones a nivel DB

---

## 🔧 Responsabilidades Detalladas de Módulos Core

### Sistema

**Propósito**: Infraestructura multi-tenant y gestión de recursos base

**Responsabilidades**:
- Multi-tenancy (Empresa → Sucursal → Bodega)
- Autenticación y autorización (JWT, RBAC)
- Gestión de usuarios y roles
- WMS-Lite (ubicaciones de bodega)
- Métodos de pago globales
- Papelera de reciclaje (soft delete)

**Modelos principales**: `Usuario`, `Empresa`, `Sucursal`, `Bodega`, `Ubicacion`

### Ventas

**Propósito**: Gestión comercial y punto de venta

**Responsabilidades**:
- Gestión de clientes
- Catálogo de productos/servicios
- Proceso de ventas (POS)
- Órdenes de servicio (flujo operativo)
- Inventario por bodega
- Recetas (consumo de insumos)
- Movimientos de stock

**Modelos principales**: `Cliente`, `Producto`, `Venta`, `OrdenServicio`, `Inventario`

**Eventos emitidos**:
- `EVENT_VENTA_CREADA`
- `EVENT_ORDEN_FINALIZADA`
- `EVENT_STOCK_CRITICO`

### Finanzas

**Propósito**: Control financiero y contabilidad

**Responsabilidades**:
- Plan de cuentas contables (PCU)
- Asientos contables automáticos
- Libro mayor y auxiliares
- Gastos y egresos
- Cierres de caja
- Motor de precios dinámico
- Integración con DTE (Facturación)

**Modelos principales**: `CuentaContable`, `AsientoContable`, `MovimientoContable`, `Gasto`, `CierreCaja`

**Eventos escuchados**:
- `EVENT_VENTA_CREADA` → Genera asiento contable
- `EVENT_GASTO_CREADO` → Genera asiento contable

### Compras

**Propósito**: Abastecimiento y gestión de proveedores

**Responsabilidades**:
- Gestión de proveedores
- Órdenes de compra
- Recepción de mercadería
- Integración con inventario
- Trazabilidad de compras

**Modelos principales**: `Proveedor`, `OrdenCompra`, `OrdenCompraDetalle`

**Eventos emitidos**:
- `EVENT_COMPRA_RECIBIDA` → Actualiza inventario

### RRHH

**Propósito**: Gestión de recursos humanos

**Responsabilidades**:
- Gestión de empleados
- Control de asistencia
- Liquidaciones de sueldo (Chile)
- Cálculo de AFP, Salud, Impuestos
- Especialidades y disponibilidad
- Integración con contabilidad (nómina)

**Modelos principales**: `Empleado`, `Asistencia`, `LiquidacionSueldo`

**Eventos emitidos**:
- `EVENT_LIQUIDACION_CONFIRMADA` → Genera asiento contable

### CRM

**Propósito**: Gestión de relaciones con clientes y pipeline comercial

**Responsabilidades**:
- Pipeline de oportunidades (Kanban)
- Seguimiento de leads
- Historial de interacciones
- Integración con Ventas y Presupuestos

**Modelos principales**: `Oportunidad`, `Etapa`, `Actividad`

### Legal

**Propósito**: Gestión documental y firmas

**Responsabilidades**:
- Generación de contratos (PDF)
- Firmas digitales (Simple/Avanzada)
- Custodia de documentos firmados
- Versionamiento de documentos

**Modelos principales**: `Contrato`, `Firma`, `PlantillaLegal`

### Service Engine

**Propósito**: Motor de ejecución de servicios industriales

**Responsabilidades**:
- Orquestación de flujos de trabajo dinámicos
- Templates por industria (JSON)
- Validación de pasos y estados
- Captura de datos en terreno

**Modelos principales**: `ServiceOrder`, `ServiceStep`, `IndustryTemplate`

### Facturación

**Propósito**: Documentos tributarios electrónicos (SII Chile)

**Responsabilidades**:
- Generación de DTE (33, 39, 56, 61)
- Firma digital
- Envío al SII
- Timbrado electrónico
- Almacenamiento de XML/PDF

**Modelos principales**: `DocumentoTributario`

### TI

**Propósito**: Gestión de activos tecnológicos

**Responsabilidades**:
- Inventario de hardware/software
- Asignación a empleados
- Ciclo de vida de activos
- Depreciación

**Modelos principales**: `ActivoTI`

### Auditoría

**Propósito**: Trazabilidad y seguridad

**Responsabilidades**:
- Registro inmutable de eventos críticos
- Tracking de cambios (before/after)
- Registro de IP y usuario
- Soporte para impersonation

**Modelos principales**: `AuditLog`

**Eventos escuchados**: `*` (todos los eventos)

### Notificaciones

**Propósito**: Alertas y comunicación

**Responsabilidades**:
- Alertas de stock crítico
- Notificaciones de eventos de negocio
- Múltiples canales (Email, SMS, Push)
- Priorización de mensajes

**Eventos escuchados**:
- `EVENT_STOCK_CRITICO`
- `EVENT_ORDEN_LISTA_RETIRO`

### Webhooks

**Propósito**: Integración externa

**Responsabilidades**:
- Envío de eventos a sistemas externos (n8n, Zapier)
- Configuración de webhooks por empresa
- Retry automático en caso de fallo

**Eventos escuchados**: `*` (todos los eventos)

---

## 🎯 Patrones de Arquitectura Utilizados

### 1. Repository Pattern

Separación entre lógica de negocio y acceso a datos:

```python
# services.py
class VentaService:
    def create_venta(self, db: Session, venta_data: VentaCreate):
        # Lógica de negocio
        venta = Venta(**venta_data.dict())
        db.add(venta)
        db.commit()
        return venta
```

### 2. Dependency Injection

FastAPI inyecta dependencias automáticamente:

```python
@router.get("/ventas")
def get_ventas(
    db: Session = Depends(get_db),
    ctx: RequestContext = Depends(get_current_context)
):
    # db y ctx son inyectados
    pass
```

### 3. Event-Driven Architecture

Módulos se comunican mediante eventos:

```python
# Emisor
event_dispatcher.dispatch("EVENT_VENTA_CREADA", {
    "venta_id": venta.id,
    "total": venta.total
})

# Receptor (en otro módulo)
def on_venta_creada(event_data: dict):
    # Generar asiento contable
    pass
```

### 4. Plugin Architecture

Carga dinámica de verticales:

```python
# main.py
def load_verticals(app: FastAPI):
    for module in discover_verticals():
        if is_safe(module):
            app.include_router(module.router)
```

### 5. Multi-Tenancy Pattern

Aislamiento de datos por empresa:

```python
# Todos los queries filtran por empresa_id
productos = db.query(Producto)\
    .filter(Producto.empresa_id == ctx.empresa_id)\
    .all()
```

---

## 📦 Mejores Prácticas

### Backend

1. **Siempre usar contexto**: Obtener `empresa_id` del contexto, nunca del request body
2. **Validar permisos**: Usar decoradores `@role_required` y `check_module_access`
3. **Emitir eventos**: Para acciones importantes que otros módulos necesiten conocer
4. **Transacciones**: Usar `db.commit()` solo al final de operaciones complejas
5. **Logging**: Usar `logger.info/error` para trazabilidad

### Frontend

1. **Composables**: Extraer lógica reutilizable a composables
2. **Lazy loading**: Cargar rutas de forma perezosa
3. **Error handling**: Manejar errores de API de forma consistente
4. **State management**: Usar Pinia para estado compartido, no props drilling
5. **Componentes pequeños**: Mantener componentes enfocados en una responsabilidad

### Base de Datos

1.  **Identificadores**: Usar **UUIDv7** como clave primaria estándar para todos los modelos nuevos (permite ordenamiento cronológico natural).
2.  **Índices**: Agregar índices a foreign keys y campos de búsqueda frecuente
3.  **Constraints**: Usar constraints de DB para integridad
4.  **Migraciones**: Nunca editar migraciones ya aplicadas
5.  **Nomenclatura**: Seguir convenciones snake_case

---

## 🔄 Flujo de Desarrollo

### Agregar Nueva Funcionalidad

1. **Planificar**: Definir modelos, schemas y endpoints
2. **Modelos**: Crear/actualizar modelos en `models.py`
3. **Migración**: Generar migración con Alembic
4. **Schemas**: Definir validación en `schemas.py`
5. **Servicios**: Implementar lógica en `services.py`
6. **API**: Crear endpoints en `api.py`
7. **Eventos**: Emitir/escuchar eventos si es necesario
8. **Frontend**: Crear/actualizar componentes y vistas
9. **Documentar**: Actualizar documentación relevante

### Crear Nueva Vertical

Ver [Guía de Desarrollo de Plugins](guia_desarrollo_plugins.md)

---

## 📚 Recursos Adicionales

- [Arquitectura del Sistema](arquitectura_sistema.md)
- [API Reference](api_reference.md)
- [Modelos de Datos](modelos_datos.md)
- [Guía de Desarrollo de Plugins](guia_desarrollo_plugins.md)

---

**Última actualización**: 2026-02-13
