# Super-Admin Dashboard (Ojo de Dios) & Dev Portal

## Descripción General
Dashboard técnico exclusivo para usuarios con rol `SUPERADMIN` (y `DEVELOPER`) que permite una visión global de la actividad del sistema ERP3 a través de todos los Tenants. Se accede a través de la ruta frontend `/dev-dashboard`.

## Endpoints Principales

### 1. Global Timeline (Ojo de Dios)
`GET /api/v1/admin/stats/global-timeline`

**Funcionalidades:**
1. **Cronología UUIDv7**: Aprovecha la estructura de los UUIDv7 para extraer fechas de creación directamente de los IDs.
2. **Resumen Diario**: 
   - Conteo de empresas creadas en el día actual (UTC).
   - Lista detallada con timestamps extraídos del UUID.
3. **Actividad Reciente**: 
   - Últimos movimientos registrados en `AuditLog` en tiempo real.
4. **Salud del Sistema**:
   - Agregación de logs por severidad (INFO, WARNING, CRITICAL).

### 2. Monitor de Sesiones Activas
`GET /api/v1/admin/stats/active-sessions`
`DELETE /api/v1/admin/stats/sessions/{session_id}`

**Funcionalidades:**
- **Visualización en Tiempo Real**: Lista de usuarios activos basada en actividad reciente (Login AuditLogs de últimas 24h).
- **Filtrado por Rol**: Capacidad de filtrar visualización por rol (ej. solo `SUPERADMIN`).
- **Gestión de Sesiones**: Posibilidad de terminar sesiones forzosamente (Simulado en logs).

### 3. Herramientas de Desarrollo (Nuclear Reset)
`POST /api/v1/admin/debug/nuclear-reset`

**Funcionalidades:**
- **Reset Completo**: Ejecuta scripts de limpieza (`reset_db.py`) y re-inicialización (`auto_onboarding.py`).
- **Seguridad**: Solo disponible en entorno de Desarrollo (`ENVIRONMENT=development`) y rol `DEVELOPER`.
- **UI**: Botón "Nuclear Reset" en `DevDashboard.vue`.

## Sistema de Alertas y Monitoreo (Webhooks)

Se han implementado listeners automáticos para eventos críticos que disparan Webhooks de Pánico:

1. **DB Connection Panic**:
   - Evento: `SYSTEM_ALERT_DB_PANIC` / `SYSTEM_ALERT_DB_TIMEOUT`
   - Disparador: Excepciones `TimeoutError` o `DatabaseError` en SQLAlchemy Engine.
   - Configuración: `pool_pre_ping=True`, `pool_recycle=3600` para estabilidad en hostings externos.

2. **Seguridad SuperAdmin**:
   - Evento: `SECURITY_ALERT_SUPERADMIN_FAILED_LOGIN`
   - Disparador: Fallo de contraseña en cuenta con rol `SUPERADMIN`.
   - Payload: Incluye IP y Email para auditoría inmediata.

## Implementación Frontend

### Componentes Clave
- **DevDashboard.vue**: Vista principal que integra los widgets.
- **SessionMonitor.vue**: Widget específico para el listado y gestión de sesiones.
- **Admin Service**: `services/admin.service.js` centraliza las llamadas a la API de administración.

### Detalle de Alertas Críticas
- **Botón en “Alertas Crit.”**: Acceso directo al bloque de detalle.
- **Detalle en la misma vista**: Lista de eventos críticos con timestamp relativo.
- **Fuente de datos**: `GET /api/v1/admin/stats/system-events-sanitized` para mensajes anonimizados.

### Seguridad y Rutas
- **Ruta**: `/dev-dashboard` (Normalizada desde `/dev_loggin`).
- **Protección**: `meta: { requiresDeveloper: true }` en Vue Router.
- **RBAC**: El backend valida estrictamente el rol `SUPERADMIN` para todos los endpoints de este módulo.

## Gestión de Clientes (Super-Admin)

### Rutas Frontend
- **Directorio**: `/super-admin/clients`
- **Detalle de empresa**: `/super-admin/clients/{empresa_id}`

### Endpoints
- **Listar empresas**: `GET /api/v1/empresas` (requiere `SUPERADMIN`/`DEVELOPER`)
- **Suspender/Activar empresa**: `POST /api/v1/admin/empresas/{empresa_id}/toggle-active`
- **Listar usuarios de una empresa**: `GET /api/v1/admin/empresas/{empresa_id}/users`
- **Vincular usuario existente a empresa**: `POST /api/v1/admin/empresas/{empresa_id}/users/link-existing`
- **Cambiar rol de usuario en empresa**: `PATCH /api/v1/admin/empresas/{empresa_id}/users/{user_id}/role`
- **Severidad de auditoría**: estos endpoints registran en `AuditLog` usando `AuditSeverity.INFO` (valores válidos del enum: `INFO`, `WARNING`, `CRITICAL`).

## Detalles Técnicos
- **UUID Utils**: `app.core.uuid_utils` provee funciones para extraer timestamps y generar rangos de búsqueda basados en bits de tiempo de UUIDv7.
- **Optimización**: Consultas optimizadas para evitar Full Table Scans usando rangos de IDs.
