Mantenimiento de Base de Datos — Guía Operativa (Reset Nuclear)

Resumen
- El “Reset Nuclear” borra el esquema público de la base de datos y ejecuta el auto-onboarding. Es destructivo. Solo para entornos de desarrollo/local bajo control del equipo.

Ubicación y artefactos
- Script principal: /.one-off-scripts/nuclear-reset.ps1
- Scripts llamados: backend/scripts/reset_db.py y backend/scripts/auto_onboarding.py
- Log: /.one-off-scripts/nuclear-reset.log
- Pendientes de limpieza: /.one-off-scripts/pending-cleanup.txt

Requisitos de entorno
- Acceso a la red/host: si el servidor está detrás de VPN corporativa, debes estar conectado a la VPN y tener acceso al host donde corre la app/DB.
- PowerShell:
  - Política de ejecución: abre PowerShell como Administrador y asegúrate de permitir la ejecución de scripts locales (por ejemplo: Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned).
  - Si la política es estricta, puedes invocar la ejecución por sesión con bypass: powershell -ExecutionPolicy Bypass -File .\.one-off-scripts\nuclear-reset.ps1
- Python:
  - Tener Python accesible en PATH o usa el intérprete del entorno virtual (venv\Scripts\python) desde la carpeta backend.
- Variables de entorno:
  - backend/.env debe definir al menos DATABASE_URL y ENVIRONMENT. En desarrollo suele ser ENVIRONMENT=development.
  - Si existe REDIS_URL u otras integraciones, no afectan el reset en sí, pero verifica que no dependan del estado de DB durante la ejecución.

Uso básico
1) Posiciónate en la raíz del repositorio (donde residen backend y .one-off-scripts).
2) Ejecuta:
   .\.one-off-scripts\nuclear-reset.ps1
3) Confirmaciones interactivas:
   - Primera confirmación: “¿Seguro que deseas resetear la base de datos? (si/no)”.
   - Segunda confirmación: escribe literalmente BORRAR TODO.
4) El script llamará a reset_db.py y luego a auto_onboarding.py, registrando el proceso en nuclear-reset.log.
5) Al terminar, intentará auto-eliminarse tras 2 segundos. Si la eliminación falla, agregará su ruta a pending-cleanup.txt para limpieza manual posterior.

Bandera -Force
- Propósito: permitir el reset en escenarios no locales o cuando ENVIRONMENT no sea “development”. Esta bandera ignora los bloqueos preventivos, pero mantiene las confirmaciones interactivas.
- Cuándo usarla: excepcionalmente (por ejemplo, en un entorno de laboratorio controlado, fuera de producción, con respaldos verificados y una ventana de cambio formal).
- Ejemplo de uso:
  .\.one-off-scripts\nuclear-reset.ps1 -Force

Políticas y salvaguardas
- Prohibido en producción: por defecto, el script bloquea ejecución si ENVIRONMENT=production o si DATABASE_URL no apunta a localhost/127.0.0.1.
- Confirmaciones dobles: se exige confirmación simple y confirmación de frase (“BORRAR TODO”) para minimizar errores humanos.
- Auditoría local: siempre se escribe nuclear-reset.log con marcas de tiempo, pasos y resultados.

Cómo regenerar el script si se auto-eliminó
Opción A — Recuperar desde control de versiones
- Si el repositorio está versionado (git), restaurar el archivo con:
  git checkout -- .one-off-scripts/nuclear-reset.ps1

Opción B — Recrear manualmente desde esta guía
1) Crea el archivo .one-off-scripts\nuclear-reset.ps1
2) Copia este contenido mínimo funcional:

   param(
       [switch]$Force
   )
   $ErrorActionPreference = "Stop"
   $scriptPath = $MyInvocation.MyCommand.Path
   $scriptsDir = Split-Path -Parent $scriptPath
   $repoRoot = Split-Path -Parent $scriptsDir
   $backendDir = Join-Path $repoRoot "backend"
   $envFile = Join-Path $backendDir ".env"
   $logFile = Join-Path $scriptsDir "nuclear-reset.log"
   $pendingCleanup = Join-Path $scriptsDir "pending-cleanup.txt"
   function Write-Log { param([string]$m) $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"; "$ts $m" | Tee-Object -FilePath $logFile -Append | Out-Null }
   function Get-VarFromEnvFile {
       param([string]$key)
       if (-not (Test-Path $envFile)) { return $null }
       $line = Select-String -Path $envFile -Pattern "^\s*$key\s*=" -SimpleMatch | Select-Object -First 1
       if (-not $line) { return $null }
       $val = $line.Line.Split("=",2)[1].Trim().Trim('"').Trim("'")
       return $val
   }
   $environment = $env:ENVIRONMENT
   if (-not $environment) { $environment = Get-VarFromEnvFile "ENVIRONMENT" }
   if (-not $environment) { $environment = "development" }
   $databaseUrl = $env:DATABASE_URL
   if (-not $databaseUrl) { $databaseUrl = Get-VarFromEnvFile "DATABASE_URL" }
   Write-Log "Starting nuclear reset"
   Write-Log "ENVIRONMENT=$environment"
   if ($environment.ToLower() -eq "production" -and -not $Force) {
       Write-Log "Blocked in production without --Force"
       Write-Host "Bloqueado: entorno production. Usa --Force bajo tu responsabilidad."
       exit 1
   }
   if ($databaseUrl -and $databaseUrl -notmatch "localhost|127\.0\.0\.1" -and -not $Force) {
       Write-Log "Blocked non-local DATABASE_URL without --Force"
       Write-Host "Bloqueado: DATABASE_URL no es local. Usa --Force bajo tu responsabilidad."
       exit 1
   }
   $ans1 = Read-Host "¿Seguro que deseas resetear la base de datos? (si/no)"
   if (@("si","sí","yes","y") -notcontains $ans1.ToLower()) {
       Write-Log "Abortado en primera confirmación"
       Write-Host "Abortado"
       exit 1
   }
   $ans2 = Read-Host "Escribe BORRAR TODO para continuar"
   if ($ans2 -ne "BORRAR TODO") {
       Write-Log "Abortado en segunda confirmación"
       Write-Host "Abortado"
       exit 1
   }
   $resetScript = Join-Path (Join-Path $backendDir "scripts") "reset_db.py"
   $onboardingScript = Join-Path (Join-Path $backendDir "scripts") "auto_onboarding.py"
   if (-not (Test-Path $resetScript)) { Write-Log "reset_db.py missing"; Write-Host "Falta reset_db.py"; exit 1 }
   if (-not (Test-Path $onboardingScript)) { Write-Log "auto_onboarding.py missing"; Write-Host "Falta auto_onboarding.py"; exit 1 }
   Write-Log "Running reset_db.py"
   pushd $backendDir
   try {
       python $resetScript
       if ($LASTEXITCODE -ne 0) { throw "reset_db.py failed with code $LASTEXITCODE" }
       Write-Log "reset_db.py ok"
   } catch {
       Write-Log "reset_db.py error: $_"
       popd
       exit 1
   }
   Write-Log "Running auto_onboarding.py"
   try {
       python $onboardingScript
       if ($LASTEXITCODE -ne 0) { throw "auto_onboarding.py failed with code $LASTEXITCODE" }
       Write-Log "auto_onboarding.py ok"
   } catch {
       Write-Log "auto_onboarding.py error: $_"
       popd
       exit 1
   }
   popd
   Write-Log "Sequence completed"
   Start-Sleep -Seconds 2
   try {
       Remove-Item -LiteralPath $scriptPath -Force
   } catch {
       "$scriptPath" | Out-File -FilePath $pendingCleanup -Append -Encoding utf8
   }

3) Guarda el archivo, verifica permisos de ejecución y prueba en entorno local.

Solución de problemas
- Error de política de ejecución: usa PowerShell como Administrador y establece RemoteSigned o ejecuta con -ExecutionPolicy Bypass.
- Python no encontrado: usa la ruta del intérprete del venv (por ejemplo, backend\\venv\\Scripts\\python) o añade Python a PATH.
- Acceso a DB denegado: valida credenciales en backend/.env (DATABASE_URL) y conectividad (firewall, VPN, puerto).
- Script no se auto-elimina: revisa pending-cleanup.txt y elimina manualmente la ruta listada cuando sea seguro.

Buenas prácticas previas al reset
- Respaldos: guarda un backup reciente de la base de datos.
- Ventana de cambio: coordina con el equipo para minimizar impacto en otros desarrolladores.
- Comunicación: avisa en el canal interno antes y después del procedimiento.
