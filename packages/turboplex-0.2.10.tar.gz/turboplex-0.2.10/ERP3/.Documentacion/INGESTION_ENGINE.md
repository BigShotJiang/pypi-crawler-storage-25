🏗️ Blueprint: Motor de Ingesta Inteligente (Staging-First)
1. El Concepto "Cero Riesgo"
Para procesar archivos de oficina (Excel/CSV) sin corromper la base de datos productiva, el sistema utilizará una Zona de Cuarentena (Staging). Nada toca las tablas de productos o clientes sin antes ser validado y transformado en esta zona.

2. Flujo de Trabajo (Pipeline)
Paso A: Ingesta Bruta (The Dump)
Acción: El sistema lee el Excel usando pandas con tipos de datos str para todo.

Destino: Tabla staging_imports.

Seguridad: Se guarda la fila completa como un objeto JSON en la columna raw_content.
   - Se agrega `"_row_number"` para rastrear la fila original del Excel/CSV (header=1, primera fila de datos=2).

Paso B: El Traductor (Mapping Layer)
Lógica: El motor buscará coincidencias por nombre de columna (ej: "Código" -> "sku").

Paso C: Sanitización (The Cleanser) - REGLA CHILE V2
Se aplican filtros de "normalización chilena" estrictos:

RUT (Formato Estándar): 12.345.678-k ➔ 12345678-K.

Lógica: Eliminar todos los puntos, eliminar espacios, asegurar guion antes del DV, convertir 'k' a 'K'.

Moneda: $ 1.500,00 ➔ 1500.00 (Limpieza de símbolos y conversión a Decimal).

Texto: Limpieza de espacios al inicio/final y asegurar soporte total de ñ y °.

3. Manejo de Errores (Resiliencia)
Transaccionalidad: Carga por bloques (Bulk). Si una fila falla, se revierte solo ese bloque y se loguea en error_log.

Idempotencia: Detectar duplicados por SKU o RUT antes de insertar en tablas finales.


## 🛠️ Protocolo de Implementación para el Agente

### Fase 1: Infraestructura de Datos (Base de Datos)
1. **Modelado:** Definir la clase `StagingImport` en `backend/app/models/staging.py`.
   - Incluir `status` (String) con default `pending` para filtrar pendientes/procesadas/fallidas.
2. **Migración:** Ejecutar `alembic revision --autogenerate -m "create_staging_table"`. **Verificar:** Que la columna `raw_content` sea de tipo `JSONB` (Postgres) o `JSON` (SQLite).

### Fase 2: Lógica de Procesamiento (Services)
1. **Scanner Utility:** Crear `backend/app/utils/formatters.py` con las funciones:
   - `format_rut_chile(raw_rut)`: Implementar regex para llegar al formato `XXXXXXXX-Y`.
   - `format_currency_chile(raw_value)`: Limpiar símbolos y retornar `Decimal`.
2. **Bulk Ingestion:** Crear servicio que use `pandas.read_excel(file, dtype=str)` para evitar truncado de ceros a la izquierda en SKUs o RUTs.

### Fase 3: Mapping & Cleansing (Inventario)
1. **Mapping Inventario (mínimo viable):**
   - `Código de artículo` → `sku`
   - `Nombre del producto` → `name`
   - `Física disponible` → `stock`
2. **Cleansing Chile (Normalizer):** utilidades para limpiar RUTs y Monedas (y parseo robusto de enteros para stock).
3. **Estados por fila:** `pending` → `validated` si pasa, o `failed` con `error_log` estructurado.

### Fase 4: Carga Productiva (Inventario)
1. **Upsert Producto por SKU (normalizado):**
   - Si no existe en `productos`, se crea (scoped por `empresa_id`).
   - Si existe, se actualiza `nombre`.
2. **Stock Multi-Bodega Dinámica:**
   - Se toma la bodega desde la columna del archivo (por defecto `Almacén`, configurable via `warehouse_column`).
   - Resolución por tenant: se busca `Bodega.codigo_externo` (join con `Sucursal.empresa_id`).
   - Auto-creación: si no existe la bodega para la empresa, se crea automáticamente en la sucursal por defecto usando el código como `codigo_externo`.
   - Fallback: si una fila no trae bodega, se aplica a la bodega default (ej. `Bodega Central`).
   - Ajuste: se ajusta el inventario a “stock objetivo” (stock absoluto) registrando un movimiento por delta en la bodega correspondiente.
3. **Trazabilidad del run:**
   - Se crea un registro `ImportRun` por ejecución con:
     - `filename`, `file_hash`, `bodega_id`, `status` y `summary`.
   - Idempotencia: si existe un `ImportRun` `COMPLETED` con el mismo `file_hash` para la misma `empresa_id`, el apply se rechaza como duplicado.
   - Se persiste en `movimientos_stock.import_run_id` (FK lógica al `ImportRun.id`).

### Fase 5: Pruebas de Resiliencia (Terremoto Grado 10)
1. **Test de Caracteres:** Validar que el nombre "Piñón 1/2°" se guarde y recupere sin corrupción.
2. **Test de Volumen:** Procesar un archivo de >1000 filas y medir el tiempo de respuesta (usar `bulk_insert_mappings` de SQLAlchemy).
3. **Test de Errores:** Insertar un RUT mal formado a propósito y verificar que el error se escriba en `error_log` sin detener el resto del archivo.

## 🏁 Criterio de Aceptación (Definición de Hecho)
- El comando `alembic upgrade head` se ejecuta sin errores.
- Se puede consultar la tabla `staging_imports` y ver la data original del Excel en formato JSON.
- El RUT resultante de la transformación siempre tiene 1 guion y 0 puntos.

## 🧪 Script de prueba (carga real a staging)
- Ejecutar: `python backend/app/tools/test_real_import.py --file "C:\\GitHub\\ERP3\\Inventario disponible_639045295401493012.xlsx"`
- Nota: el script crea una `Empresa` de prueba usando `allow_no_tenant` y luego fija `db.info["empresa_id"]` para que la carga y los SELECT queden aislados por tenant.
- Nota: el script fuerza `echo=False` en los engines para que la consola muestre el progreso sin el spam de SQLAlchemy.

## ☢️ Test de estrés (Bomba H)
- Ejecutar: `python backend/app/tools/test_bomb_inventory.py`
