# Manual de Conexión a Power BI - ERP3

Este documento detalla los pasos para conectar Microsoft Power BI Desktop al módulo de Inteligencia de Negocios de ERP3, específicamente para el reporte de Rendimiento de Transporte.

## 1. Requisitos Previos

*   Tener instalado **Microsoft Power BI Desktop**.
    *   [Descargar Aquí](https://powerbi.microsoft.com/es-es/desktop/)

## 2. Credenciales de Conexión

Para la empresa **Mining Corp**, utilice las siguientes credenciales de acceso de solo lectura:

| Parámetro | Valor |
| :--- | :--- |
| **Tipo de Base de Datos** | PostgreSQL |
| **Servidor** | *Solicitar IP al Administrador* (Local: `localhost`) |
| **Base de Datos** | `erp3_db` |
| **Usuario** | `bi_user_empresa_22` |
| **Contraseña** | `rUxJIqGhOFsKhB7s` |

> **Nota de Seguridad**: Este usuario tiene permisos estrictamente limitados para leer solo la vista de reportes de su empresa. No tiene acceso a tablas críticas ni puede modificar datos.

## 3. Instrucciones Paso a Paso

### Paso 1: Iniciar Conexión
1. Abra Power BI Desktop.
2. En la cinta de opciones "Inicio", haga clic en **Obtener datos** (Get Data) y seleccione **Más...**
3. En el buscador, escriba `PostgreSQL`.
4. Seleccione **Base de datos PostgreSQL** y haga clic en **Conectar**.

### Paso 2: Configurar Servidor
1. En la ventana que aparece, ingrese los datos:
    *   **Servidor**: La IP o Host del servidor ERP3.
    *   **Base de datos**: `erp3_db`
2. **Modo de Conectividad de Datos**:
    *   Seleccione **Importar** si desea trabajar rápido en memoria y actualizar periódicamente.
    *   Seleccione **DirectQuery** si necesita ver los datos en tiempo real cada vez que interactúa con el reporte.
3. Haga clic en **Aceptar**.

### Paso 3: Autenticación
1. Power BI solicitará credenciales. **Importante**: Seleccione la pestaña **Base de datos** a la izquierda (NO use "Windows" ni "Cuenta de Microsoft").
2. Ingrese el **Nombre de usuario** (`bi_user_empresa_22`) y la **Contraseña** (`rUxJIqGhOFsKhB7s`).
3. Haga clic en **Conectar**.
    *   *Si aparece una advertencia sobre cifrado/certificados, haga clic en Aceptar para continuar.*

### Paso 4: Selección de Datos
1. Se abrirá la ventana "Navegador".
2. Despliegue la carpeta de la base de datos `erp3_db` -> `public`.
3. Busque y marque la casilla de la vista: **`v_bi_transport_performance`**.
4. Verá una vista previa de los datos (IDs, Status, Distancia, Litros, Costo Real, etc.).
5. Haga clic en el botón **Cargar**.

## 4. Uso de los Datos
Una vez cargados, tendrá disponible la tabla `v_bi_transport_performance` para crear gráficos.

**Ejemplo de KPI: Costo por Kilómetro ($/KM)**
Para calcular este indicador, cree una **Nueva Medida** en Power BI con la siguiente fórmula DAX:

```dax
Costo por KM = DIVIDE(SUM(v_bi_transport_performance[costo_real]), SUM(v_bi_transport_performance[distancia_km]), 0)
```

## 5. Solución de Problemas Frecuentes

*   **Error: "No se pudo conectar al servidor remote"**: Verifique que está conectado a la VPN de la empresa o que su IP está permitida en el firewall del servidor.
*   **Error: "La tabla está vacía"**: Verifique que está usando el usuario `bi_user_empresa_22`. Si usa otro usuario, la seguridad a nivel de fila (RLS) podría estar ocultando los datos.
*   **Valores en Cero**: Si ve distancias o costos en 0, es posible que los operarios no hayan ingresado la metadata completa al finalizar la orden. El sistema ahora valida esto para nuevas órdenes, pero órdenes antiguas pueden tener datos incompletos.
