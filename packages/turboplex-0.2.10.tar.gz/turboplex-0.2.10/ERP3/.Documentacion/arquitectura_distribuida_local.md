# Arquitectura Distribuida Local (Postgres) — ERP3

Este documento resume la configuración actual para simular una arquitectura distribuida en local (modo nativo sobre el SO, sin Docker Desktop) y cómo llevarla a despliegue cuando se requiera separar las conexiones.

## 1) Objetivo

- Tener una base principal (writer) para operaciones de escritura.
- Tener una base “espejo/réplica” para lecturas (preferida cuando exista).
- Tener una base de auditoría para eventos/logs (separación lógica inicial).
- Mantener fallback seguro: si no existen las URLs nuevas, el sistema opera en “Modo Monolítico” (todo apunta a la DB principal) con logs informativos.

## 2) Variables de entorno (canónicas y aliases)

### Variables canónicas (recomendadas)

- `DATABASE_URL`: conexión principal (writer). Obligatoria.
- `REPLICA_DATABASE_URL`: conexión a réplica/espejo (reader). Opcional.
- `AUDIT_DATABASE_URL`: conexión a auditoría. Opcional.
- `TEST_DATABASE_URL`: DB dedicada para pytest. Opcional (recomendado).

### Aliases (compatibilidad / conveniencia)

- `REPLICA_URL`: alias de `REPLICA_DATABASE_URL`.
- `AUDIT_URL`: alias de `AUDIT_DATABASE_URL`.

Regla: si `REPLICA_DATABASE_URL`/`AUDIT_DATABASE_URL` vienen vacías pero existen `REPLICA_URL`/`AUDIT_URL`, el backend las copia automáticamente.

## 3) Configuración local (Postgres nativo en Windows)

En `backend/.env` (ejemplo con puerto explícito):

```env
ENVIRONMENT=development

DATABASE_URL=postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost:5432/erp3_db
REPLICA_DATABASE_URL=postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost:5432/db_espejo_test
AUDIT_DATABASE_URL=postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost:5432/db_auditor_test

REPLICA_URL=postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost:5432/db_espejo_test
AUDIT_URL=postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost:5432/db_auditor_test

TEST_DATABASE_URL=postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost:5432/erp3_test
```

Nota: si tu Postgres local usa otro puerto, reemplaza `5432` por el correspondiente.

## 4) Creación idempotente de DBs (local)

### Opción A — psql (idempotente con \\gexec)

Conéctate a la base `postgres`:

```powershell
psql -U erp3_user -h localhost -p 5432 -d postgres -v ON_ERROR_STOP=1
```

Luego ejecuta:

```sql
SELECT format('CREATE DATABASE %I', 'db_espejo_test')
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'db_espejo_test')\gexec;

SELECT format('CREATE DATABASE %I', 'db_auditor_test')
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'db_auditor_test')\gexec;
```

### Opción B — Python (recomendado)

Existe un script idempotente:

- `backend/scripts/setup_dbs_local.py`

Características:

- Lee `backend/.env` automáticamente (si python-dotenv está instalado).
- Conecta a `postgres` (DB admin) usando el mismo host/puerto/credenciales de `DATABASE_URL`.
- Crea `db_espejo_test` y `db_auditor_test` si no existen.

Ejecución:

```powershell
cd backend
./.venv/Scripts/python.exe scripts/setup_dbs_local.py
```

Si prefieres pasar el DSN explícito:

```powershell
./.venv/Scripts/python.exe scripts/setup_dbs_local.py --database-url "postgresql+psycopg2://usuario:clave@localhost:5432/erp3_db"
```

Troubleshooting:

- Si ves “Falta DATABASE_URL”, significa que no se cargó `.env` y no pasaste `--database-url`.
- Si ves `OperationalError`, suele ser:
  - Postgres no está arriba.
  - Host/puerto incorrecto.
  - Usuario/clave no existen.
  - El usuario no tiene privilegio `CREATEDB` (o no es superuser).

## 5) Comportamiento del backend (Bulkhead + fallback)

### Fallback “Modo Monolítico”

- Si `REPLICA_DATABASE_URL` (o alias) no está configurada, el reader apunta a `DATABASE_URL`.
- Si `AUDIT_DATABASE_URL` (o alias) no está configurada, audit apunta a `DATABASE_URL`.

En ambos casos se emite `logger.info` indicando “Modo Monolítico”.

### Healthcheck al startup (Bulkhead Pattern)

En el arranque de FastAPI se valida conectividad a las 3 DBs:

- DB_W (writer): si falla, el proceso aborta (no se puede operar sin la bodega).
- DB_R (replica/reader): si falla, se loguea warning y se continúa.
- DB_AUDIT: si falla, se loguea warning y se continúa.

Esto permite degradación controlada: el core debe seguir operando aun si la réplica o auditoría están caídas.

## 6) Logical Replication (Debezium/CDC)

Para Debezium/CDC, Postgres debe estar configurado con:

- `wal_level = logical`
- `max_replication_slots >= 5` (mínimo recomendado)
- `max_wal_senders >= 5` (mínimo recomendado)

En modo local nativo, tú configuras esto en `postgresql.conf`. El backend solo hace checks informativos en desarrollo (logs).

## 7) Cómo llevar esto a despliegue (staging/producción)

### 7.1 Checklist mínimo de variables

En el entorno (CI/CD, PaaS, VM, Kubernetes, etc.) define:

- `DATABASE_URL`: apunta a la DB principal (writer).
- `REPLICA_DATABASE_URL`: apunta a la réplica/reader (si existe). Si no, omítela y quedas en “Modo Monolítico”.
- `AUDIT_DATABASE_URL`: apunta a la DB de auditoría (si existe). Si no, omítela y quedas en “Modo Monolítico”.

Opcionalmente (no recomendado como estándar): usar `REPLICA_URL`/`AUDIT_URL` como aliases.

### 7.2 Estrategia de rollout (sin downtime)

1) Despliega el backend con el soporte multi-URI (ya está listo).
2) Mantén `REPLICA_DATABASE_URL`/`AUDIT_DATABASE_URL` vacías en producción inicialmente:
   - Verás logs de “Modo Monolítico”.
   - El sistema opera igual que antes (todo en la principal).
3) Cuando tengas la réplica operativa:
   - Define `REPLICA_DATABASE_URL` apuntando al reader.
   - Verifica en logs del startup que DB_R responde.
4) Cuando tengas auditoría separada:
   - Define `AUDIT_DATABASE_URL`.
   - Verifica en logs del startup que DB_AUDIT responde.

### 7.3 Consideraciones de seguridad/ops

- No versionar credenciales: usar variables de entorno/secret manager.
- El usuario de DB para el backend no necesita privilegios de superuser; para el script de creación sí se requiere `CREATEDB` (recomendado usar un usuario admin solo para setup).
- Monitoreo: si DB_R cae, el backend seguirá operando; conviene alertar por warnings de startup o healthchecks internos.

## 8) Dónde se refleja esto en el repo

- `.env` local: `backend/.env`
- Plantilla: `backend/.env.example`
- Setup idempotente de DBs: `backend/scripts/setup_dbs_local.py`
- Configuración de Settings: `backend/app/core/infrastructure/config.py`
- Engines + fallback + healthcheck: `backend/app/core/database/database.py`
- Startup hook: `backend/app/main.py`
