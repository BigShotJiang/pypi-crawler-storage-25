MEMORÁNDUM DE REFORMA ESTRUCTURAL: PROYECTO "IMPUESTO DINÁMICO"
PARA: El Dev del Coleto de Cuero y el IDE.
DE: Consultoría Legal Gemini (Tu Abogado de Propiedad Intelectual).
ASUNTO: Desacoplamiento de Tasas Impositivas para Escalabilidad Internacional.
1. MANDATO TÉCNICO: DESTRUIR EL "19%" HARDCODED
El "otro yo" debe buscar cada instancia donde el número 0.19 o 1.19 esté escrito directamente en el código de backend (backend_core). Ese es un riesgo legal de "rigidez arquitectónica".
Instrucción: Crear una tabla config.impuestos_regionales (o similar) que sea la única fuente de verdad.
Garantía RLS: Esta tabla DEBE heredar la tenant_isolation_policy que ya registramos. Ninguna empresa debe poder "ver" o "usar" la tasa de otra por accidente si el usuario no tiene los permisos.
2. MIGRACIÓN DE DATOS: "FOTO AL MOMENTO"
Para que los libros contables sean válidos ante cualquier auditoría (SII, DIAN o AFIP), no basta con calcular el IVA en el frontend.
Instrucción: Modificar los modelos de Venta y DocumentoTributario para que almacenen la tasa vigente al momento de la firma.
Justificación: Si en 2027 el IVA sube al 20%, una factura de 2026 debe seguir diciendo 19% en la base de datos, no recalcularse dinámicamente al consultar el registro.
3. COMPATIBILIDAD CON EL DDI
Dile al desarrollador que este cambio no invalida el registro actual. Estamos añadiendo "flexibilidad paramétrica". La invención (el multi-tenant con RLS y la auditoría inmutable) sigue siendo la misma.
Acción: Una vez que termine la modificación, debe volver a ejecutar el script pack_core_ddi.py. El nuevo HASHES.txt será nuestra prueba de que la evolución del software mantiene la genealogía del original.
4. EL RETO "COLOMBIA" (Retenciones)
Adviértele que el IVA es solo el principio. El sistema debe permitir múltiples impuestos por línea de detalle.
Instrucción: El schema_full.sql debe evolucionar de tener un campo iva_monto a una tabla relacionada documentos_impuestos para que quepan el IVA, el Impuesto al Consumo o el ICA colombiano sin romper el Core.
19→
20→ACTUALIZACIÓN TÉCNICA (2026-03-23)
21→- Se creó la tabla multi‑tenant con RLS: configuracion_impuestos (fuente de verdad), tasa Numeric(12,4).
22→- Se agregó snapshot inmutable en ventas: campo iva_tasa_aplicada (Numeric(12,4)).
23→- Se habilitó múltiples impuestos por línea:
24→  - detalles_venta_impuestos (por detalle de venta).
25→  - documentos_tributarios_detalle_impuestos (por línea de DTE).
26→- Se reemplazaron hardcodes 0.19/1.19 por lectura de configuración; cálculos con Decimal y Numeric(12,4) en intermedios.
27→- Redondeo: intermedios a 4 decimales; total final a 0 decimales (CLP) o 2 decimales (USD).
28→- RLS aplicado con tenant_isolation_policy en todas las tablas nuevas.
29→- Backfill: se insertó IVA 19% activo por empresa si no existía.
30→
31→NOTA CONFIG (2026-03-23)
32→- Ajuste Settings (extra='ignore') para tolerar variables extra en .env durante migraciones y tests.
