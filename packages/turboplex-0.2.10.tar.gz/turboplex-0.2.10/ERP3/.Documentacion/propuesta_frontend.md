# 🖥️ Propuesta de Frontend — ERP3

> Basado en el análisis completo del backend. El sistema es **multi-tenant**: cada empresa opera bajo el parámetro `?cmp=CODIGO`. Autenticación JWT Bearer. Roles: `SUPERADMIN`, `ADMIN`, `USER`. Roles por empresa: `ADM`, `SUP`, `VEN`, `BOD`, `CON`.

---

## 🗺️ Mapa de Rutas (Router Vue)

```mermaid
graph TD
    A["/login"] --> B["/dashboard?cmp=CODIGO"]
    A --> REG["/registro — Onboarding Público"]
    B --> V["/ventas"]
    B --> F["/finanzas"]
    B --> C["/compras"]
    B --> RH["/rrhh"]
    B --> CRM["/crm"]
    B --> FAC["/facturacion"]
    B --> TI["/ti"]
    B --> LEG["/legal"]
    B --> ANA["/analytics"]
    B --> CFG["/configuracion"]
    V --> V1["Punto de Venta"]
    V --> V2["Órdenes de Servicio"]
    V --> V3["Clientes"]
    V --> V4["Productos / Stock"]
    F --> F1["Gastos / Egresos"]
    F --> F2["Cierre de Caja"]
    F --> F3["Proveedores"]
    F --> F4["Contabilidad"]
    F4 --> F4a["Plan de Cuentas PCU"]
    F4 --> F4b["Asientos Contables"]
    F4 --> F4c["Libro Diario"]
    F4 --> F4d["Balance General"]
    C --> C1["Órdenes de Compra"]
    CFG --> CFG1["Sucursales y Bodegas"]
    CFG --> CFG2["Métodos de Pago"]
    CFG --> CFG3["Usuarios y Roles"]
    CFG --> CFG4["Feature Flags"]
```

---

## 🔐 1. Pantalla de Login + Onboarding

### `POST /api/v1/login/access-token`
### `POST /api/v1/public/onboarding`

#### Pantalla Login
| Campo | Tipo | Descripción |
|---|---|---|
| Email | Input text | username del OAuth2 |
| Contraseña | Input password | Oculta/visible toggle |
| Botón "Iniciar Sesión" | Button | Tasa limitada 5/min |
| Link "Registrar empresa" | Link → /registro | Flujo público |

> [!IMPORTANT]
> El token JWT se guarda en `localStorage`. Todas las peticiones posteriores requieren `Authorization: Bearer <token>`. El `cmp=CODIGO` de empresa debe almacenarse también para enviarlo en cada request.

#### Pantalla Onboarding (`/registro`)
Formulario de 1 paso que llama a `/public/onboarding`:
- Nombre del dueño
- Email
- Nombre de la empresa
- Tipo de negocio (select)

Al completar → el backend crea automáticamente: **Empresa + Sucursal "Casa Matriz" + Bodega Central + Métodos de pago (Efectivo)**. Redirige a `/dashboard?cmp=CODIGO`.

---

## 📊 2. Dashboard Principal

### `GET /api/v1/dashboard?cmp=CODIGO`

Pantalla central con:

```
┌─────────────────────────────────────────────────────────────┐
│  SIDEBAR          │  HEADER: "Empresa Demo S.A." | [DEMO123] │
│  ───────          │  ─────────────────────────────────────── │
│  🏠 Dashboard     │  ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  💰 Ventas        │  │ Ventas   │ │ Gastos   │ │ Caja     │ │
│  💹 Finanzas      │  │ del Día  │ │ del Mes  │ │ Abierta  │ │
│  🛒 Compras       │  │ $2.45M   │ │ $890K    │ │ ✓ Activa │ │
│  👥 RRHH          │  └──────────┘ └──────────┘ └──────────┘ │
│  🤝 CRM           │                                          │
│  🧾 Facturación   │  [Gráfico: Ventas vs Gastos - 6 meses]  │
│  💻 TI            │                                          │
│  ⚖️ Legal         │  [Tabla: Últimas Ventas]                 │
│  📈 Analytics     │  [Tabla: Órdenes de Servicio Pendientes] │
│  ⚙️ Config        │                                          │
└─────────────────────────────────────────────────────────────┘
```

**Componentes clave:**
- `KpiCard.vue` — tarjeta de métrica con ícono, valor, comparativa vs mes anterior
- `SalesChart.vue` — línea ventas + área gastos (Chart.js / ApexCharts)
- `RecentSalesTable.vue` — últimas 10 ventas con estado
- `ServiceOrdersWidget.vue` — órdenes en estado "En Proceso" o "Pendiente"

---

## 💰 3. Módulo Ventas

### APIs disponibles:
- `POST /api/v1/ventas/` — crear venta
- `DELETE /api/v1/ventas/{id}` — eliminar venta
- `PUT /api/v1/ventas/ordenes-servicio/{id}/estado` — actualizar estado OS
- `POST /api/v1/ventas/clientes/` — crear cliente
- `DELETE /api/v1/ventas/clientes/{id}` — eliminar cliente
- `POST /api/v1/ventas/ajuste-stock` — ajustar stock (FIFO)

### Pantallas:

#### 3.1 Punto de Venta (`/ventas/pos`)
Interfaz tipo POS (Point of Sale) en pantalla dividida:
- **Izquierda:** catálogo de productos con búsqueda y filtro por categoría
- **Derecha:** carrito de compra, selector de cliente, método de pago (de `/metodos-pago?cmp=CODIGO`), total y botón "Cobrar"

#### 3.2 Órdenes de Servicio (`/ventas/ordenes`)
Tablero Kanban con columnas:
```
[Recepcionado] → [En Proceso] → [Listo] → [Entregado]
```
Cada tarjeta muestra: número OS, cliente, producto, fecha. Drag & drop llama a `PUT /ordenes-servicio/{id}/estado`.

#### 3.3 Clientes (`/ventas/clientes`)
Tabla CRUD con: nombre, RUT/DNI, email, teléfono, historial de compras (botón).

#### 3.4 Inventario / Stock (`/ventas/stock`)
Tabla de productos con stock actual. Botón "Ajuste de Stock" abre modal con campos: producto, tipo (ENTRADA/SALIDA), cantidad, motivo.

---

## 💹 4. Módulo Finanzas

### 4.1 Cierre de Caja (`/finanzas/caja`)

Flujo de dos estados:
```
[Sin caja abierta] → Botón "Abrir Turno" → POST /cierres-caja/abrir
                                          ↓ (caja activa)
                               Muestra: ventas del turno, gastos efectivo
                                          ↓
                               Botón "Cerrar Turno" → POST /cierres-caja/{id}/cerrar
                               Pide: monto físico real → muestra diferencia (sobrante/faltante)
```

> [!WARNING]
> Solo roles con scope `finanzas:ledger:post` pueden abrir/cerrar caja. El frontend debe ocultar estos botones según el rol del usuario logueado.

#### 4.2 Gastos / Egresos (`/finanzas/gastos`)
Tabla con filtros de fecha y sucursal. CRUD completo. Al crear un gasto → el backend genera automáticamente un asiento contable.

#### 4.3 Proveedores (`/finanzas/proveedores`)
Lista de proveedores con: nombre, RUT, email, teléfono. CRUD.

#### 4.4 Contabilidad (`/finanzas/contabilidad`)
Sección con 4 sub-vistas (tabs):

| Tab | Endpoint | Vista |
|---|---|---|
| Plan de Cuentas | `GET /contabilidad/cuentas` | Árbol jerárquico de cuentas (código + nombre) |
| Asientos | `GET /contabilidad/asientos` | Tabla con débito/crédito por línea |
| Libro Diario | `GET /contabilidad/libro-diario` | Filtro por rango de fecha, tabla exportable |
| Balance General | `GET /contabilidad/balance-general` | Filtro por año, tabla en 8 columnas estilo chileno |
| Libro Auxiliar | `GET /contabilidad/libro-auxiliar` | Filtros: tipo (VENTAS/COMPRAS), mes, año |

> [!NOTE]
> El botón "Inicializar PCU Chileno" (`POST /contabilidad/init-pcu`) solo se muestra si el plan de cuentas está vacío. Se usa una sola vez al configurar la empresa.

---

## 🛒 5. Módulo Compras

### APIs:
- `GET /api/v1/compras/ordenes-compra` — listar OC
- `POST /api/v1/compras/ordenes-compra/{id}/aprobar` — aprobar (solo `ADM` o scope `compras:approve`)

#### Pantalla Principal (`/compras`)
Tabla de Órdenes de Compra con estados: `BORRADOR → ENVIADA → RECIBIDA / CANCELADA`.

Botón "Aprobar" solo visible para rol `ADM`. Al aprobar → dispara evento `orden_compra.aprobada` en el backend (que a su vez notifica al módulo de finanzas/inventario vía event system).

---

## 👥 6. Módulo RRHH (`/rrhh`)

Endpoints en `/api/v1/empleados/`. Pantallas:
- **Listado de empleados** — tabla con nombre, cargo, supervisor, estado activo
- **Ficha de empleado** — datos personales, empresa asociada, rol dentro de la empresa
- **Crear/Editar empleado** — formulario con relación supervisor (árbol de jerarquía)

---

## 🤝 7. Módulo CRM (`/crm`)

Gestión de relaciones con clientes. Pantallas esperadas:
- Pipeline de oportunidades (Kanban o lista)
- Historial de interacciones
- Actividades pendientes (seguimientos)

---

## 🧾 8. Facturación (`/facturacion`)

- Emisión de documentos tributarios (boletas, facturas)
- Historial de documentos emitidos
- Descarga en PDF (el backend ya tiene soporte de PDF según archivos de storage)

---

## 💻 9. TI (`/ti`)

Módulo de soporte interno. Posibles pantallas:
- Tickets de soporte o incidencias
- Inventario de activos tecnológicos
- Estado de servicios / health del sistema

> [!NOTE]
> El endpoint `GET /health` retorna estado de **Base de Datos** y **Redis** en tiempo real. Un panel de salud del sistema es ideal aquí.

---

## ⚖️ 10. Legal (`/legal`)

- Contratos y documentos legales de la empresa
- Vencimientos y alertas de renovación

---

## 📈 11. Analytics (`/analytics`)

Panel de métricas avanzadas:
- MRR (Monthly Recurring Revenue) por módulo activo
- Métricas de uso por empresa
- Exportación de reportes

---

## ⚙️ 12. Configuración del Sistema (`/configuracion`)

### 12.1 Sucursales y Bodegas
- Árbol: `Empresa → Sucursales → Bodegas → Ubicaciones (WMS Lite)`
- CRUD de cada nivel

### 12.2 Métodos de Pago
- Listado de métodos activos para la empresa (`GET /metodos-pago`)
- Toggle por método (Efectivo, Transferencia, Tarjeta Débito/Crédito)

### 12.3 Usuarios y Roles
- Tabla de usuarios de la empresa con su rol (`ADM/SUP/VEN/BOD/CON`)
- Crear usuario, asignar rol, activar/desactivar

### 12.4 Módulos Activos
- Tarjetas de módulos disponibles (VENTAS, FINANZAS, RRHH, TI, CRM, etc.)
- Toggle para activar/desactivar módulo para la empresa

### 12.5 Feature Flags
- Tabla de flags booleanos por empresa (`feature_flags` JSON en Empresa)
- Editor de flags para habilitar/deshabilitar características experimentales

---

## 🏗️ Arquitectura del Frontend

```mermaid
graph TD
    subgraph "Vue 3 + Vite"
        MAIN["main.js\n(Vue App + Pinia + Router)"]
        ROUTER["router/index.js\n(Rutas por módulo, guards de auth)"]
        STORES["stores/\nauth.js | empresa.js | ventas.js | finanzas.js"]
        SERVICES["services/\napi.js (axios interceptors con token + cmp)"]
        VIEWS["views/\n(una por módulo)"]
        COMPONENTS["components/\nKpiCard | DataTable | Modal | SideBar | Toast"]
    end
    MAIN --> ROUTER
    MAIN --> STORES
    ROUTER --> VIEWS
    VIEWS --> COMPONENTS
    VIEWS --> STORES
    STORES --> SERVICES
    SERVICES -->|JWT Bearer + ?cmp=| BACKEND["FastAPI Backend\n:8000/api/v1/"]
```

---

## 🔑 Consideraciones Clave para el Frontend

| Tema                 | Detalle                                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| **Multi-tenant**     | El `?cmp=CODIGO` debe enviarse en CADA request. Guardarlo en `pinia store` y añadirlo como query param via axios interceptor. |
| **Timeout**          | El backend tiene timeout de 15s por request. Mostrar spinner con cancelación.                                                 |
| **Suspensión**       | Si la suscripción venció, el backend devuelve `403` en mutaciones. Mostrar banner "Empresa en modo lectura".                  |
| **Rate Limit**       | Login tiene límite de 5/min. Mostrar mensaje amigable ante error 429.                                                         |
| **RBAC**             | Ocultar botones según rol. Ej: "Aprobar OC" solo para `ADM`. Usar computed con el rol del store.                              |
| **Módulos Activos**  | Cada empresa tiene `modulos_activos[]`. El sidebar solo muestra módulos que existen en ese array.                             |
| **Versiones de API** | Existen endpoints `/v2/` con envelope `{success, data, error, meta}`. Preferir v2.                                            |

---

## 📦 Stack Tecnológico Recomendado (Frontend)

| Tecnología | Uso |
|---|---|
| **Vue 3** + Composition API | Framework principal (ya existe en `/frontend`) |
| **Pinia** | Estado global (auth, empresa activa, módulos) |
| **Vue Router 4** | Navegación con guards de autenticación |
| **Axios** | HTTP client con interceptors (token + cmp) |
| **ApexCharts / Chart.js** | Gráficos del dashboard y analytics |
| **TailwindCSS** | Estilos (ya configurado en el proyecto) |
| **Vue Toastification** | Notificaciones (errores de API, éxitos) |
| **VueUse** | Utilidades reactivas (useLocalStorage, etc.) |

