# AUDITORIA_ESTADO_DEL_ARTE_CORE — Estado del Arte del Núcleo (ERP3)

Fecha: 2026-03-23  
Rol: Arquitectura de Sistemas + Pentest Ético (análisis crítico)  
Contexto: Robustez del núcleo ante carga masiva (~40.000 productos/SKUs) y operación multi-tenant en Chile (DDI).

## 0) Resumen Ejecutivo (lectura de 2 minutos)

Este núcleo tiene “gorilas” fuertes en:

- RLS/tenant context a nivel Postgres (set_config) y validación en ORM al hacer flush.
- Guardián anti-servicio en Kardex (doble capa: lógica de aplicación + trigger DB).
- Snapshot de IVA aplicado en Venta y cálculo con precisión intermedia 4 decimales.
- Auditoría por listeners (SQLAlchemy) y “bulkhead” para DB de auditoría.

Pero también tiene puntos ciegos relevantes:

- Existen caminos de bypass de aislamiento (flags `allow_no_tenant`, `bypass_app_tenant_filter` y bypass por substrings en SQL) que, si se usan mal o se exponen, abren riesgo cross-tenant.
- Algunas tablas críticas no tienen `empresa_id` (ej. `inventario`), por lo que el aislamiento depende de joins/convenciones y no de RLS directo. Esto es un riesgo estructural (multi-tenant “por disciplina”).
- La auditoría actual es fuerte como bitácora, pero no es WORM (no hay garantías criptográficas/DB-level anti-borrado). Un usuario con privilegios DB puede borrar y no hay “huella indestructible” garantizada.
- En performance 40k: el filtro multi-tenant por `with_loader_criteria` iterando sobre todos los mappers puede volverse costoso; y las operaciones de stock (`SELECT ... FOR UPDATE`) + triggers de snapshot pueden generar contención bajo concurrencia alta.

## 1) Metodología (qué revisé)

- Tenant context y RLS: [deps.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/api/deps.py), [database.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/database/database.py), migraciones Alembic y políticas.
- Inventario: [inventory_service.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/inventory_service.py), [stock_ops.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/stock_ops.py), modelos [inventario/stock/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/models.py) y [movimientos/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/movimientos/models.py), migración [7e9b0c3d1abc](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/alembic/versions/7e9b0c3d1abc_stock_snapshot_and_guards.py).
- Impuestos y ventas: [finanzas/services.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/finanzas/services.py), [finanzas/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/finanzas/models.py), [ventas/services.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/services.py), [ventas/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/models.py), utilitario [tax_utils.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/logic/tax_utils.py) y migración [6f3a9c1c2d77](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/alembic/versions/6f3a9c1c2d77_configuracion_impuestos_and_line_taxes.py).
- Auditoría: listeners [core/audit.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/audit.py), modelo [AuditLog](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/sistema/models.py), y logger de seguridad [security_audit.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/security/security_audit.py).
- Carga masiva: pipeline staging + apply en [ingestion_service.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/services/ingestion_service.py), [apply_inventory.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/services/ingestion_apply/apply_inventory.py) y endpoint [inventario/stock/api.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/api.py).

## 2) Seguridad y Aislamiento (Gorilas de Tenant)

### 2.1 Diseño actual (capas)

**Capa A — Postgres RLS (hard gate):**
- Políticas (ejemplo típico en migraciones) usan variables de sesión:
  - `app.allow_no_tenant`
  - `app.current_empresa_id`
- En runtime, esas variables se setean en el hook `after_begin` de SQLAlchemy: [database.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/database/database.py#L346-L373).

**Capa B — Filtro ORM automático (soft gate pero útil):**
- Listener `do_orm_execute` aplica `with_loader_criteria` a toda clase ORM que tenga atributo `empresa_id`: [database.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/database/database.py#L286-L344).

**Capa C — Validación de escritura (flush guard):**
- Listener `before_flush` fuerza `empresa_id` a `tenant` o aborta por mismatch: [database.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/database/database.py#L376-L407).

**Selector de tenant:**
- `get_current_active_company` decide empresa por `?cmp=` o default y luego setea `db.info["empresa_id"]`: [deps.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/api/deps.py#L263-L410).
- `get_tenant_db` además ejecuta `set_config(...)` en la conexión: [deps.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/api/deps.py#L412-L443).

### 2.2 Fortalezas (qué está bien blindado)

- Si `allow_no_tenant` está en `False` y falta `empresa_id`, la sesión falla en operaciones sensibles:
  - `do_orm_execute` lanza `RuntimeError("Tenant context missing...")`.
  - `after_begin` lanza `PermissionError("Acceso a base de datos sin contexto de empresa...")`.
- Para tablas con `empresa_id` y RLS activo, el aislamiento es de “DB-first”: aunque el código olvide filtrar, Postgres puede bloquear.

### 2.3 Puntos ciegos / posibles brechas (lo crítico)

**Brecha 1 — Bypass por heurística de SQL (alto riesgo si se filtra a producción):**
- En `do_orm_execute` hay un bypass que desactiva el filtro multi-tenant si el SQL string contiene substrings:
  - `exempt_tables = ("settings", "configuraciones", "verticals")` y luego `if any(t in stmt_str for t in exempt_tables): bypass_rls = True`
  - Referencia: [database.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/database/database.py#L299-L316)
- Esto es frágil: una query legítima que contenga “configuraciones” (o un atacante que logre influir en el statement) puede desactivar el filtro ORM.
- Recomendación: reemplazar heurística por allowlist estricta por modelo/tabla y por contexto (solo “startup/system”). No basarse en substrings.

**Brecha 2 — `allow_no_tenant=True` es un “modo dios” real:**
- `get_current_user` y `get_current_active_company` elevan temporalmente `allow_no_tenant` para buscar al usuario/empresa antes de setear el tenant: [deps.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/api/deps.py#L164-L215) y [deps.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/api/deps.py#L263-L356).
- Si algún endpoint queda con `allow_no_tenant=True` por error, o si se reusa la sesión fuera del patrón esperado, el aislamiento se degrada.
- Riesgo adicional: tareas en background o scripts internos que manipulen `SessionLocal()` con `allow_no_tenant=True` pueden leer/escribir cross-tenant si no hay RLS fuerte.

**Brecha 3 — Tablas sin `empresa_id` no pueden ser “gorila RLS”:**
- Ejemplo: `inventario` NO tiene `empresa_id` ([inventario/stock/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/models.py#L51-L78)).
- Consecuencia:
  - El filtro ORM automático no aplica (porque chequea `hasattr(cls, "empresa_id")`).
  - Postgres RLS no puede aislar por empresa (a menos que haya otra estrategia: vistas, joins forzados o FK con RLS en tablas padre + `security_barrier`).
- Esto obliga a “aislamiento por disciplina”: cada query debe filtrar vía joins/propiedad derivada. Es el tipo de punto ciego que aparece bajo presión (features nuevas / import masivo).

**Brecha 4 — Auditoría global sin empresa_id:**
- `audit_logs` no incluye `empresa_id`: [models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/sistema/models.py#L287-L323).
- Si hay endpoints que exponen audit_logs sin filtrar por tenant (o con allow_no_tenant), el riesgo es fuga de trazas entre empresas.

### 2.4 Calificación del gorila (Aislamiento)

- Fuerza: **7/10**
- Motivo: buena base (session vars + before_flush), pero con bypass heurístico y tablas sin `empresa_id` el aislamiento no es “estanco” en todo el core.

## 3) Integridad de Inventario (El Guardián)

### 3.1 Guardián ALMACENABLE vs SERVICIO (doble capa)

**Capa aplicación (regla explícita):**
- Al intentar ingresar stock con `release_stock`, si `Producto.tipo_producto == "SERVICIO"` se lanza error: [stock_ops.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/stock_ops.py#L415-L425).
- En ventas, solo se descuenta stock cuando `tipo_producto == "ALMACENABLE"` y no es servicio: [ventas/services.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/services.py#L222-L274).

**Capa base de datos (anti-bypass):**
- Trigger `trg_guard_servicio_movimiento` en `movimientos_stock` impide insertar movimientos si el producto es SERVICIO: [7e9b0c3d1abc](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/alembic/versions/7e9b0c3d1abc_stock_snapshot_and_guards.py#L43-L68).
- Esta es una defensa correcta: incluso si alguien intenta insertar un movimiento directo (por bug o import), Postgres rechaza.

### 3.2 Stock negativo (qué ocurre)

**Vía aplicación (normal):**
- `consume_stock` valida stock disponible y falla si no alcanza: [stock_ops.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/stock_ops.py#L214-L263).
- Bajo concurrencia: usa `SELECT ... FOR UPDATE` sobre inventario/lotes para evitar carreras dentro de la transacción: [stock_ops.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/stock_ops.py#L250-L297).

**Vía “entrada manual por DB” (pentest):**
- No vi un `CHECK (cantidad >= 0)` en `inventario` o `inventario_lotes`.
- Si un operador DB hace `UPDATE inventario SET cantidad=-10`, Postgres lo permitiría (salvo constraints no visibles aquí).
- Consecuencia: el sistema lo detectaría solo de manera indirecta (por inconsistencias posteriores) y no en el momento del UPDATE.

Recomendación: agregar constraints y/o triggers de integridad:
- `inventario.cantidad >= 0`
- `inventario.cantidad_reservada >= 0`
- `inventario.cantidad_reservada <= inventario.cantidad`
- `inventario_lotes.cantidad >= 0`

### 3.3 Atomicidad en Inventario (bug real ya observado)

- Escenario real observado en tests: si `release_stock()` ejecutaba y luego fallaba `process_backorders()`, el stock quedaba aplicado.
- Endurecimiento aplicado: `InventoryService.add_stock` usa SAVEPOINT con `db.begin_nested()` para rollback parcial seguro: [inventory_service.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/inventory_service.py#L190-L230).
- Esto mejora integridad bajo fallos lógicos (excepción Python) dentro de una transacción mayor.

### 3.4 Calificación del gorila (Inventario)

- Fuerza: **8/10**
- Motivo: buen diseño transaccional y lock; trigger anti-servicio es clave. Debilidad principal: ausencia de constraints anti-negativo en tablas base (riesgo “operador DB” o herramientas ETL).

## 4) Motor de Impuestos y Ventas

### 4.1 Jerarquía de impuestos (IVA, retenciones, cargos)

**Fuente de verdad por empresa:**
- `configuracion_impuestos` define tasas vigentes por empresa: [finanzas/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/finanzas/models.py#L199-L220).
- `get_impuesto_rate` prioriza DB por empresa y cae a legacy/global: [finanzas/services.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/finanzas/services.py#L86-L160).

**Impuestos por línea (múltiples):**
- Modelo `DetalleVentaImpuesto` almacena `codigo_impuesto`, `tasa_aplicada`, `base_monto`, `monto_impuesto` con 4 decimales: [ventas/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/models.py#L248-L265).
- Construcción de entradas: [tax_utils.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/logic/tax_utils.py#L1-L58).

### 4.2 Precisión decimal (4+ posiciones) y redondeo CLP

- La tasa se normaliza a 4 decimales (`0.0001`).
- Se calcula base con 4 decimales y luego se redondea a CLP según regla (half-up): [finanzas/services.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/finanzas/services.py#L86-L207).
- Puntos ciegos:
  - Hay doble cálculo de `neto_decimal` en `calculate_taxes_from_total` (se recalcula con `total_int`), lo cual puede ser intencional pero conviene documentar para evitar divergencias por refactor.
  - En multi-impuesto, se devuelve `iva` como suma de impuestos, lo cual semánticamente puede confundir si hay retenciones (no es “IVA”, es “sumatoria impuestos”).

### 4.3 Snapshot inmutable (no retroactivo)

- En `Venta` existe `iva_tasa_aplicada` como snapshot de la tasa aplicada en el momento de la transacción: [ventas/models.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/models.py#L142-L208).
- En `create_venta`, la tasa vigente se lee y se asigna a `venta.iva_tasa_aplicada`: [ventas/services.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/ventas/services.py#L276-L290).
- Propiedades `monto_neto` y `monto_iva` calculan usando esa tasa snapshoteada cuando existe.

Punto ciego:
- No hay un enforcement DB-level que impida cambiar `iva_tasa_aplicada` posteriormente (depende de permisos y disciplina).
- Recomendación: trigger que bloquee UPDATE de ese campo después de confirmación/estado; o reglas en servicio + auditoría CRITICAL si cambia.

### 4.4 Calificación del gorila (Impuestos/Ventas)

- Fuerza: **7.5/10**
- Motivo: snapshot + precision 4 decimales es sólido. Debilidades: semántica `iva` en multi-impuesto y ausencia de enforcement inmutable DB-level.

## 5) Atomicidad y Resiliencia (Gorilas de Integridad)

### 5.1 Escenario: corte de energía en producto 39.999 de una carga 40k

Hay dos “tipos” de atomicidad posibles:

**Modo A — Todo o nada (una transacción para los 40k):**
- Ventaja: cero “basura” parcial.
- Desventaja: locks largos, riesgo de rollback caro y timeouts; alto impacto en operación concurrente.

**Modo B — Saga / Checkpoints (commit por chunks):**
- Ventaja: el sistema progresa, fallos se acotan a un chunk; mejor para 40k.
- Desventaja: no es todo-o-nada; se requiere idempotencia y capacidad de reintento/reconciliación.

El núcleo actualmente se acerca más a **Modo B** en ingesta:

- `ingest_records_to_staging` inserta en chunks y hace `db.commit()` por chunk; ante error intenta fallback por fila: [ingestion_service.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/services/ingestion_service.py#L204-L275).
- `apply_validated_inventory_to_production` en inventario hace varios `commit()` durante el flujo (creación de ImportRun, aplicación de stock, actualización de estado final): [apply_inventory.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/services/ingestion_apply/apply_inventory.py#L338-L404).

Interpretación pentest:
- Un corte a la mitad deja el sistema en un estado “coherente por etapas” si:
  - el `ImportRun` refleja `STARTED/FAILED`,
  - las operaciones aplicadas son idempotentes y auditables,
  - y existe un proceso de reintento/repair.
- Sin idempotencia fuerte, el riesgo es duplicar movimientos de stock o crear productos parcialmente.

Recomendación: endurecer el apply como saga formal:
- `ImportRun` + `file_hash` ya existen (buena base).
- Agregar:
  - claves idempotentes por SKU/bodega/variant + import_run_id,
  - “guard” para evitar re-aplicar si ya se aplicó (por ejemplo, registrar “applied_at” por staging row),
  - y un comando “repair/retry failed rows”.

### 5.2 Calificación del gorila (Atomicidad)

- Fuerza: **6.5/10**
- Motivo: para operación real y 40k, el enfoque por chunks es correcto, pero hoy es más “pragmático” que “formalmente transaccional”. Se necesita saga/idempotencia explícita para ser a prueba de corte de energía.

## 6) Capacidad Forense (Gorilas de Auditoría)

### 6.1 Auditoría actual (qué se registra y cómo)

**AuditLog por listeners (automático):**
- Listener crea entradas en `audit_logs` en insert/update/delete usando el mismo `connection.execute(...)`: [core/audit.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/audit.py#L25-L113).
- Ventaja: corre dentro de la misma transacción; si la transacción falla, el audit insert también falla.

**Replicación a DB_AUDIT (bulkhead):**
- Logs pendientes se acumulan en `session.info["pending_audit_logs"]` y se intentan escribir al `audit_engine` post-commit; si no está disponible, fallback silencioso con warning: [core/audit.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/audit.py#L136-L170).

**SecurityAudit explícito (eventos críticos):**
- `SecurityAudit.log` inserta y commitea de inmediato: [security_audit.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/security/security_audit.py#L26-L66).
- Riesgo: commit separado puede “desacoplar” el log del fallo del negocio; para incidentes es aceptable, pero hay que entenderlo.

### 6.2 ¿Podemos reconstruir una venta + movimiento de stock si alguien borra?

Situación actual:
- `audit_logs` guarda diffs “before/after”, pero no es inmutable a nivel DB.
- No hay evidencia en este análisis de:
  - triggers `BEFORE DELETE` que impidan borrar audit_logs,
  - políticas de permisos DB (solo append),
  - ni hashing encadenado (ledger) para detectar manipulación.

Conclusión:
- **Con privilegios DB suficientes, un actor puede borrar o alterar huellas.**
- Con privilegios de aplicación (sin DB), sí hay trazabilidad razonable.

Recomendación “DDI-grade”:
- Convertir auditoría en WORM lógico:
  - Denegar DELETE/UPDATE en `audit_logs` a roles de app.
  - Trigger que bloquee UPDATE/DELETE.
  - Firma encadenada (hash(prev_hash + payload + timestamp)) para detectar alteración.

### 6.3 Calificación del gorila (Forense)

- Fuerza: **6/10**
- Motivo: hay auditoría amplia y replicación, pero no hay “indestructibilidad” criptográfica/DB-level. Para DDI, se recomienda upgrade de inmutabilidad.

## 7) Análisis de Fatiga de Material (Performance 40k)

### 7.1 Cuellos de botella teóricos (operación masiva)

**Bottleneck A — Filtro multi-tenant en cada SELECT (coste O(n_mappers)):**
- `do_orm_execute` recorre todos los mappers registrados y aplica `with_loader_criteria` si tienen `empresa_id`: [database.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core/database/database.py#L323-L344).
- Con un core grande, esto puede:
  - aumentar el tiempo de compilación/ejecución de query,
  - dificultar optimizaciones del planner,
  - y amplificar latencia en endpoints de lectura.

**Bottleneck B — Contención por locks en inventario bajo alta concurrencia:**
- Stock usa `SELECT ... FOR UPDATE` sobre filas de inventario y lotes: [stock_ops.py](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/app/core_modules/inventario/stock/services/stock_ops.py#L250-L297).
- Con 40k SKUs, el volumen no es el único factor; el factor real es “hot keys” (muchas operaciones sobre las mismas bodegas/variants).
- Riesgo: waits y deadlocks si múltiples transacciones tocan lotes y filas en distinto orden.

**Bottleneck C — Trigger de snapshot por cada movimiento:**
- La migración crea trigger `AFTER INSERT ON movimientos_stock` que hace upsert a `stock_diario_snapshot`: [7e9b0c3d1abc](file:///c:/Users/keita_pc/Documents/trae_projects/ERP3/backend/alembic/versions/7e9b0c3d1abc_stock_snapshot_and_guards.py#L70-L110).
- En cargas masivas esto puede generar:
  - alta escritura adicional (1 trigger write por movimiento),
  - contención en el índice unique `uq_stock_diario_snapshot_key`.

**Bottleneck D — Auditoría por listeners en inserciones masivas:**
- Listeners audit por cada INSERT/UPDATE/DELETE de ORM pueden duplicar el volumen de escrituras (tabla audit_logs).
- Si el import masivo usa ORM normal (no bulk), el costo es significativo.

### 7.2 Índices y diseño (observado)

- Muchos FK están indexados (`index=True`) en modelos de stock/movimientos, lo cual ayuda.
- Pero “inventario” no tiene `empresa_id`, por lo que no hay índice compuesto típico `(empresa_id, producto_id, bodega_id)`; dependerá de `variant_id` y otros accesos.

### 7.3 Calificación del gorila (Performance 40k)

- Fuerza: **6.5/10**
- Motivo: hay una ruta de ingesta por staging y bulk insert (bueno). Aun así, el costo de auditoría + triggers + locks puede volverse dominante bajo 40k con concurrencia real.

## 8) Recomendaciones Prioritarias (orientadas a DDI Chile)

1) Eliminar bypass heurístico por substrings del filtro tenant y reemplazarlo por allowlist estricta.
2) Denormalizar `empresa_id` en tablas críticas sin tenant (mínimo: `inventario`, `inventario_lotes`, snapshot tables) o reemplazar acceso por vistas con `security_barrier` + RLS en padre.
3) Endurecer “inmutabilidad”:
   - `venta.iva_tasa_aplicada` y tablas de impuestos por línea (bloquear cambios post-estado).
4) Auditoría WORM:
   - Bloquear DELETE/UPDATE en audit_logs para roles de aplicación.
   - Hash encadenado para detectar manipulación.
5) Performance:
   - Reducir costo de `do_orm_execute` (no aplicar criterio a todos los mappers indiscriminadamente).
   - Para cargas masivas, usar bulk ops controladas y desactivar auditoría/trigger bajo modo import (con evidencia).

## 9) Conclusión

El core está bien encaminado para operación real en Chile: aislamiento multi-tenant “casi DB-first”, inventario con guardianes sólidos y motor de impuestos con snapshot. Para una entrega DDI fuerte y para sostener 40k SKUs sin degradación o brechas, conviene cerrar tres frentes: aislamiento sin bypass, tenant IDs en todas las tablas críticas, y auditoría verdaderamente inmutable.

