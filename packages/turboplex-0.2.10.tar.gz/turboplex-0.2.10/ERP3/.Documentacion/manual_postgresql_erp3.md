# Manual PostgreSQL (ERP3)

Este documento es un manual de consulta para operar y diagnosticar la base de datos PostgreSQL del proyecto ERP3, con foco en multi-tenant (`empresa_id`), RLS, JSONB (“atributos camaleónicos”), Alembic y runbooks de mantenimiento.

## Índice

- 1. Modelo mental (ERP3)
- 2. Contexto de tenant (session vars)
- 3. RLS (Row Level Security)
- 4. Mapa de tablas (inventario, movimientos, valorización)
- 5. Inspección de esquema (columnas, índices, FK)
- 6. JSONB (consultas, performance, riesgos)
- 7. Runbooks (purga/reset, borrados grandes, seguridad)
- 8. Alembic/Migraciones (fallos comunes)
- 9. Performance & mantenimiento (VACUUM, locks, bloat)
- 10. CDC/Debezium (wal_level)
- 11. Checklist de seguridad multi-tenant

---

## 1) Modelo mental (ERP3)

- PostgreSQL es la fuente de verdad de datos; la app debe reforzar integridad, pero el aislamiento multi-tenant se apoya en RLS cuando está habilitado.
- Multi-tenant:
  - Tablas tenant-scoped suelen tener `empresa_id`.
  - Otras tablas “pertenecen” a la empresa vía relaciones (ej. `inventario` se asocia a empresa por `bodegas -> sucursales -> empresa_id`).
- Atributos camaleónicos:
  - Campos dinámicos se almacenan como `JSONB` en `additional_attributes`.
  - Existe diccionario por empresa para controlar qué claves se exponen (UI limpia).

---

## 2) Contexto de tenant (session vars)

Este proyecto usa variables de sesión para activar el tenant en PostgreSQL:

- `app.current_empresa_id`: UUID en string del tenant activo.
- `app.allow_no_tenant`: bypass de mantenimiento/tests. Si es `'1'`, la policy permite operar sin tenant.

### 2.1 Setear contexto (recomendado antes de cualquier query tenant-scoped)

```sql
SELECT set_config('app.allow_no_tenant', '0', true);
SELECT set_config('app.current_empresa_id', '019c9d2b-53b0-7884-bc8b-5800d1d5cbc6', true);
```

### 2.2 Ver el contexto activo

```sql
SELECT
  current_setting('app.current_empresa_id', true) AS empresa_id,
  current_setting('app.allow_no_tenant', true) AS allow_no_tenant;
```

### 2.3 Fallos típicos

- “No hay datos” cuando sí existen: `app.current_empresa_id` no está seteado o apunta a otra empresa.
- “Demasiados datos” (grave): alguien dejó `app.allow_no_tenant = '1'` en un ambiente donde no corresponde.

---

## 3) RLS (Row Level Security)

### 3.1 Ver si una tabla tiene RLS habilitado/forzado

```sql
SELECT
  c.relname AS table,
  c.relrowsecurity AS rls_enabled,
  c.relforcerowsecurity AS rls_forced
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('movimientos_stock', 'empresa_config_atributos');
```

### 3.2 Listar policies de una tabla

```sql
SELECT polname, polcmd, polqual, polwithcheck
FROM pg_policy
WHERE polrelid = 'movimientos_stock'::regclass;
```

### 3.3 Patrón de policy esperado (tenant_isolation_policy)

El patrón estándar suele filtrar por `empresa_id` usando:

- `empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid`
- bypass opcional por `current_setting('app.allow_no_tenant', true) = '1'`

### 3.4 Cosas que “no deberían pasar” pero pueden pasar

- RLS activado sin policy: puede bloquear todo o dejar comportamientos inesperados.
- RLS no forzado (`FORCE` off): roles privilegiados podrían saltarse restricciones.
- Contexto de tenant seteado tarde (después de ejecutar queries): fuga o lecturas vacías.

---

## 4) Mapa de tablas relevantes (inventario)

### 4.1 Inventario (stock)

- `inventario`: stock agregado por `producto_id` + `bodega_id`.
- `inventario_lotes`: stock por lote (trazabilidad), por `producto_id` + `bodega_id` + `lote_codigo`.
- `inventario_ubicacion`: stock por ubicación (`ubicacion_id`), sin `empresa_id` directo.

### 4.2 Movimientos (ledger)

- `movimientos_stock`: ledger de movimientos, con `empresa_id` y `additional_attributes JSONB`.

### 4.3 Valorización (PMP)

- `historial_costos`: evolución de PMP. Se asocia por `producto_id` (y opcionalmente `movimiento_id`).

### 4.4 Diccionario de atributos (UI)

- `empresa_config_atributos`: define claves visibles por `empresa_id` + `entidad`, con `activo` boolean.

### 4.5 Importación (plantillas)

- `import_templates`: plantillas por empresa con `mapping_json (JSONB)`.

---

## 5) Inspección del esquema (columnas, índices, constraints)

### 5.0 Error común: “no existe la relación schema.tabla” (pgAdmin)

En PostgreSQL, una “relación” es una tabla/vista. El error:

> ERROR: no existe la relación «inventario.inventario»

normalmente significa que estás apuntando a un **schema equivocado**.

- En ERP3, las tablas suelen vivir en el schema `public`.
- `inventario` suele ser el nombre de la tabla, no el schema.
- Si ejecutas `FROM "inventario"."inventario"` estás diciendo “tabla `inventario` dentro del schema `inventario`”.

Cómo verificar rápido dónde están las tablas:

```sql
SELECT schemaname, tablename
FROM pg_tables
WHERE tablename IN ('inventario','productos','bodegas','sucursales')
ORDER BY schemaname, tablename;
```

Ejemplo correcto (schema `public`):

```sql
SELECT
  p.sku,
  p.nombre,
  i.additional_attributes
FROM public.inventario AS i
JOIN public.productos  AS p ON p.id = i.producto_id
JOIN public.bodegas    AS b ON b.id = i.bodega_id
JOIN public.sucursales AS s ON s.id = b.sucursal_id
WHERE s.empresa_id = '019c9d2b-53b0-7884-bc8b-5800d1d5cbc6'::uuid
LIMIT 5;
```

### 5.1 Ver columnas

```sql
SELECT
  table_name,
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN (
    'inventario',
    'inventario_lotes',
    'inventario_ubicacion',
    'movimientos_stock',
    'empresa_config_atributos',
    'historial_costos',
    'import_templates'
  )
ORDER BY table_name, ordinal_position;
```

### 5.2 Ver índices

```sql
SELECT tablename, indexname, indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename IN (
    'inventario',
    'inventario_lotes',
    'inventario_ubicacion',
    'movimientos_stock',
    'empresa_config_atributos',
    'historial_costos',
    'import_templates'
  )
ORDER BY tablename, indexname;
```

### 5.3 Ver foreign keys

```sql
SELECT
  tc.table_name,
  tc.constraint_name,
  kcu.column_name,
  ccu.table_name AS foreign_table,
  ccu.column_name AS foreign_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage ccu
  ON ccu.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_schema = 'public'
  AND tc.table_name IN (
    'inventario',
    'inventario_lotes',
    'inventario_ubicacion',
    'movimientos_stock',
    'empresa_config_atributos',
    'historial_costos',
    'import_templates'
  )
ORDER BY tc.table_name, tc.constraint_name;
```

---

## 6) JSONB (“atributos camaleónicos”)

### 6.1 Consultar por clave/valor (búsqueda simple)

```sql
SELECT *
FROM movimientos_stock
WHERE empresa_id = :empresa_id
  AND additional_attributes->>'color' = 'Rojo';
```

### 6.2 Verificar existencia de clave

```sql
SELECT *
FROM movimientos_stock
WHERE empresa_id = :empresa_id
  AND additional_attributes ? 'talla';
```

### 6.3 Consultas por contención (`@>`)

```sql
SELECT *
FROM movimientos_stock
WHERE empresa_id = :empresa_id
  AND additional_attributes @> '{"color":"Rojo"}'::jsonb;
```

### 6.4 Slugify y estabilidad de claves

Buenas prácticas para claves JSONB:

- Solo minúsculas, `_`, números: `color_del_producto`, `precio_venta_porcentaje`.
- Evitar espacios, acentos, símbolos, caracteres de control.
- Evitar claves con significado peligroso: aunque JSONB lo permita, no conviene persistir claves “raras”.

### 6.5 Riesgos operativos (cosas que podrían pasar)

- Crecimiento ilimitado de JSONB → filas pesadas, bloat, queries lentas.
- Queries sin índices sobre JSONB → full scans.
- Keys inconsistentes por cambios de normalización → dificultad para reportes.

### 6.6 Índices recomendados (cuando haya volumen real)

- Índice general GIN:

```sql
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_movimientos_stock_additional_attributes_gin
ON movimientos_stock USING gin (additional_attributes);
```

- Índice por key específica:

```sql
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_movimientos_stock_attr_color
ON movimientos_stock ((additional_attributes->>'color'))
WHERE empresa_id IS NOT NULL;
```

---

## 7) Runbooks (operaciones delicadas)

### 7.1 Reset de stock vs Purga total

- Reset de stock:
  - elimina estado actual (`inventario`, `inventario_lotes`, `inventario_ubicacion`)
  - conserva auditoría (`movimientos_stock`, `historial_costos`)
- Purga total:
  - elimina también `movimientos_stock` y/o `historial_costos` (si el objetivo es borrar evidencia operativa del tenant)

### 7.2 Purga de inventario por empresa (patrón seguro)

Siempre:
- `BEGIN;` + conteos previos
- deletes en orden (hijos → padres)
- `COMMIT;` solo si los conteos posteriores son correctos

Ejemplo (empresa por UUID):

```sql
BEGIN;

SELECT set_config('app.allow_no_tenant', '0', true);
SELECT set_config('app.current_empresa_id', :empresa_id, true);

DELETE FROM inventario_ubicacion iu
USING ubicaciones u, bodegas b, sucursales s
WHERE iu.ubicacion_id = u.id
  AND u.bodega_id = b.id
  AND b.sucursal_id = s.id
  AND s.empresa_id = :empresa_id::uuid;

DELETE FROM inventario_lotes l
USING bodegas b, sucursales s
WHERE l.bodega_id = b.id
  AND b.sucursal_id = s.id
  AND s.empresa_id = :empresa_id::uuid;

DELETE FROM inventario i
USING bodegas b, sucursales s
WHERE i.bodega_id = b.id
  AND b.sucursal_id = s.id
  AND s.empresa_id = :empresa_id::uuid;

COMMIT;
```

### 7.3 Borrados grandes (cuando no quieres locks largos)

- Borrar por lotes (batch delete) usando `ctid` o rangos por fecha/id.
- Evitar `DELETE` masivo en horario productivo.
- Después de borrado grande: `VACUUM (ANALYZE)` en tablas afectadas.

---

## 8) Alembic/Migraciones (fallos comunes)

### 8.1 Por qué `alembic current` puede fallar

Alembic carga módulos de migraciones. Si una migración importa un módulo removido (path legacy), puede romper el loader.

Mitigaciones recomendadas:
- migraciones self-contained (tipos definidos dentro del archivo de migración)
- evitar imports a módulos “de app” que cambian con frecuencia

---

## 9) Performance & mantenimiento

### 9.1 VACUUM / ANALYZE

```sql
VACUUM (ANALYZE) movimientos_stock;
VACUUM (ANALYZE) inventario;
VACUUM (ANALYZE) inventario_lotes;
```

### 9.2 Diagnóstico de locks

```sql
SELECT
  pid,
  state,
  wait_event_type,
  wait_event,
  query
FROM pg_stat_activity
WHERE state <> 'idle';
```

### 9.3 Señales de bloat

- tablas grandes con pocos datos “reales”
- queries degradan con el tiempo
- autovacuum insuficiente

---

## 10) CDC / Debezium (wal_level)

Si aparece:

> Debezium/CDC requiere wal_level=logical (actual=replica).

Significa:
- No se podrá usar CDC lógico (Debezium) si el parámetro no está en `logical`.
- No necesariamente rompe el ERP, pero sí pipelines/eventos CDC.

---

## 11) Checklist de seguridad multi-tenant

- Tablas tenant-scoped:
  - tienen `empresa_id`
  - tienen RLS habilitado + policy correcta
  - `FORCE ROW LEVEL SECURITY` habilitado cuando aplique
- Operaciones de mantenimiento:
  - no usar `allow_no_tenant=1` salvo casos controlados
  - aun con bypass, siempre filtrar por `empresa_id` explícito
- JSONB:
  - keys normalizadas (slugify) para evitar inconsistencias/encoding y facilitar consultas
