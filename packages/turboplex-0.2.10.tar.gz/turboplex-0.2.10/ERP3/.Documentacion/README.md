# Documentación ERP3

Bienvenido a la documentación completa del sistema ERP3, un sistema ERP modular diseñado con arquitectura moderna y escalable.

---

## 📚 Índice General

### Documentación de Arquitectura

- **[Arquitectura del Sistema](arquitectura_sistema.md)** - Visión general de la arquitectura, patrones de diseño y sistema de eventos
- **[API Reference](api_reference.md)** - Documentación completa de todos los endpoints REST
- **[Modelos de Datos](modelos_datos.md)** - Esquema de base de datos con diagramas ER
- **[Frontend Architecture](frontend_arquitectura.md)** - Arquitectura del cliente Vue 3
- **[Deployment](deployment.md)** - Guía de despliegue en producción

### Documentación de Módulos Core

- **[Sistema](Sistema_Module.md)** - Multi-tenancy, inventario, bodegas y seguridad
- **[Ventas](Ventas_Module.md)** - POS, órdenes de servicio y gestión comercial
- **[Finanzas](Finanzas_Module.md)** - Contabilidad, motor de precios y egresos
- **[Compras](Compras_Module.md)** - Procurement, proveedores y WMS
- **[RRHH](RRHH_Module.md)** - Gestión de personal y liquidaciones
- **[Facturación](Facturacion_Module.md)** - Documentos tributarios electrónicos (DTE)
- **[TI](TI_Module.md)** - Gestión de activos tecnológicos
- **[Auditoría](Auditoria_Module.md)** - Sistema de logs y trazabilidad
- **[Notificaciones](Notificaciones_Module.md)** - Alertas y notificaciones
- **[Webhooks](Webhooks_Module.md)** - Integración externa (n8n/Zapier)

### Guías Técnicas

- **[Guía de Inicio Rápido](guia_inicio_rapido.md)** - Primeros pasos con el sistema
- **[Guía de Configuración de Industrias](guia_configuracion_industrias.md)** - Crear plantillas para nuevas verticales
- **[Guía de Worker y Background Jobs](Guia_Worker_Background_Jobs.md)** - Procesamiento asíncrono con Redis/RQ

### Configuración y Estructura

- **[Configuración](configuracion.md)** - Configuración del proyecto (BD, backend, frontend)
- **[Estructura](Estructura.md)** - Organización de archivos y directorios

### Otros Documentos

- **[Changelog](changelog.md)** - Registro de cambios del proyecto
- **[Ideas](ideas.txt)** - Ideas y mejoras futuras
- **[Informes de Pruebas](informe_estabilidad_tests.md)** - Resultados de testing

---

## 🚀 Inicio Rápido

### Para Desarrolladores

1. **Leer primero**: [Guía de Inicio Rápido](guia_inicio_rapido.md)
2. **Entender la arquitectura**: [Arquitectura del Sistema](arquitectura_sistema.md)
3. **Configurar entorno**: [Configuración](configuracion.md)
4. **Explorar API**: [API Reference](api_reference.md)

### Para Administradores

1. **Deployment**: [Guía de Deployment](deployment.md)
2. **Configuración**: [Configuración](configuracion.md)
3. **Módulos disponibles**: Ver documentación de cada módulo

---

## 🏗️ Arquitectura General

```mermaid
graph TB
    subgraph Frontend
        Vue[Vue 3 + Vite]
        Pinia[Pinia Stores]
    end
    
    subgraph Backend
        FastAPI[FastAPI]
        Events[Event System]
        Plugins[Plugin System]
    end
    
    subgraph Data
        PostgreSQL[(PostgreSQL)]
        Redis[(Redis)]
    end
    
    Vue --> FastAPI
    Pinia --> Vue
    FastAPI --> Events
    FastAPI --> Plugins
    FastAPI --> PostgreSQL
    FastAPI --> Redis
```

---

## 📦 Módulos del Sistema

### Módulos Core (Transversales)

Módulos fundamentales disponibles para todas las verticales:

- **Sistema**: Multi-tenancy, inventario, bodegas
- **Finanzas**: Contabilidad, precios, egresos
- **Ventas**: POS, órdenes de servicio
- **Compras**: Procurement, proveedores
- **RRHH**: Gestión de personal
- **Facturación**: DTE (SII Chile)
- **TI**: Activos tecnológicos
- **Auditoría**: Logs de seguridad
- **Notificaciones**: Alertas
- **Webhooks**: Integración externa

### Verticales (Específicas de Negocio)

Módulos especializados por industria:

- **Lavandería**: Gestión de órdenes de lavado (ejemplo implementado)
- **Hotel**: (Pendiente)
- **Estampado**: (Pendiente)

---

## 🔑 Características Principales

### Multi-Tenancy

Soporte nativo para múltiples empresas con aislamiento completo de datos.

```
Empresa → Sucursal → Bodega → Ubicación
```

### Sistema de Eventos

Arquitectura basada en eventos para desacoplar módulos:

```python
event_dispatcher.dispatch("EVENT_ORDEN_FINALIZADA", data)
# → Finanzas genera asiento contable
# → Inventario descuenta stock
# → Auditoría registra evento
```

### Contabilidad Automática

Generación automática de asientos contables según normativa SII Chile.

---

## 🛠️ Stack Tecnológico

### Backend

- **Framework**: FastAPI 0.122.0
- **ORM**: SQLAlchemy 2.0+
- **Migraciones**: Alembic
- **Base de Datos**: PostgreSQL 15+
- **Background Jobs**: Redis + RQ
- **Python**: 3.10+

### Frontend

- **Framework**: Vue 3
- **Build Tool**: Vite 5.x
- **Router**: Vue Router 4.x
- **State**: Pinia 2.x
- **HTTP**: Axios
- **Styling**: Tailwind CSS

---

## 📖 Convenciones

### Código

- **Backend**: PEP 8 (Python)
- **Frontend**: Vue 3 Composition API
- **Commits**: Conventional Commits

### Base de Datos

- **Tablas**: snake_case plural
- **Columnas**: snake_case
- **Foreign Keys**: `{tabla}_id`

### API

- **Versionado**: `/api/v1/`
- **Autenticación**: JWT Bearer Token
- **Formato**: JSON

---

## 🤝 Contribuir

### Agregar un Nuevo Módulo

1. Crear directorio en `backend/app/core_modules/{modulo}/`
2. Implementar modelos, schemas, services, api
3. Registrar listeners en `main.py`
4. Documentar en `.Documentacion/{Modulo}_Module.md`

### Agregar una Vertical

Ver [Guía de Desarrollo de Plugins](guia_desarrollo_plugins.md)

---

## 📞 Soporte

Para problemas o dudas:

1. Revisar documentación relevante
2. Consultar [Changelog](changelog.md) para cambios recientes
3. Verificar logs del servidor
4. Consultar documentación oficial de tecnologías:
   - [FastAPI](https://fastapi.tiangolo.com)
   - [Vue 3](https://vuejs.org)
   - [SQLAlchemy](https://www.sqlalchemy.org)

---

## 📄 Licencia

[Especificar licencia del proyecto]

---

**Última actualización**: 2026-02-06
