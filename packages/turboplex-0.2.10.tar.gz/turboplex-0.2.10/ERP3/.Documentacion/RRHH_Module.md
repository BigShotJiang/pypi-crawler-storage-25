# Módulo RRHH (Core)

El módulo de Recursos Humanos (`core_modules/rrhh`) provee la gestión centralizada del capital humano para todas las empresas del holding.

## Modelo de Datos: Empleado

El modelo `Empleado` es la entidad central y ha sido diseñado para ser agnóstico a la industria, permitiendo flexibilidad mediante etiquetado y configuración de costos.

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer | Identificador único |
| `nombres` | String | Nombres del empleado |
| `apellidos` | String | Apellidos del empleado |
| `rut` | String | Identificador nacional (Módulo 11, guion obligatorio, puntos opcionales) |
| `cargo` | String | Nombre del cargo (ej. "Gerente", "Operario") |
| `especialidades` | JSON | Lista de etiquetas de habilidades (ej. `["PLANCHADO", "CHOFER"]`) |
| `tipo_contrato` | String | `INDEFINIDO`, `PLAZO_FIJO`, `HONORARIOS` |
| `costo_hora` | Numeric | Costo base para cálculos de producción y rentabilidad |
| `estado_disponibilidad` | String | Estado operativo actual: `DISPONIBLE`, `EN_TURNO`, `VACACIONES` |
| `usuario_id` | FK | Vinculación opcional con cuenta de usuario de sistema |
| `empresa_id` | FK | Empresa a la que pertenece el contrato |

En la vista de empleados, los campos `nombres`, `apellidos` y `rut` se muestran en columnas separadas.

La vinculación de `usuario_id` se realiza por TI y puede crear un Usuario si no existe.

La activación o vinculación de usuario se realiza desde TI.

### Campos Legales (Chile)
| Campo | Tipo | Descripción |
|-------|------|-------------|
| `rut` | String | RUT con dígito verificador, guion obligatorio y puntos opcionales |
| `sueldo_base` | Numeric | Base imponible mensual |
| `tipo_afp` | String | Nombre de la AFP (ej. HABITAT, MODELO) |
| `sistema_salud` | String | FONASA o ISAPRE |
| `fecha_ingreso` | Date | Para cálculo de vacaciones y antigüedad |

## Gestión de Asistencia y Turnos (Chile)
Implementación de control de asistencia compatible con normativa chilena (40/44 horas).

| Campo | Descripción |
|-------|-------------|
| `entrada/salida` | Marca de tiempo real |
| `colacion_inicio/fin` | Tiempo de descanso no imputable a jornada |
| `horas_extras` | Cálculo automático semanal (>44h) con recargo 50% |

## Motor de Liquidaciones (Chile)
Sistema de remuneraciones adaptado a legislación local.

### Estructura de Haberes y Descuentos
- **Haberes Imponibles**: Sueldo base, gratificación legal (25% tope 4.75 IMM), horas extras, bonos.
- **Haberes No Imponibles**: Movilización, Colación.
- **Descuentos Legales**: AFP (Tasa dinámica), Salud (7%), Seguro Cesantía (0.6%), Impuesto Único.

### Integración Contable
Generación automática de asiento contable centralizado por liquidación:
- **Debe**: Gasto Remuneraciones (Total Haberes).
- **Haber**: Sueldos por Pagar (Líquido).
- **Haber**: Leyes Sociales por Pagar (Descuentos Legales).

## Uso en Industrias

### Filtrado por Habilidades
Las configuraciones de industria (como Lavandería) no deben definir sus propios roles de empleado. En su lugar, deben filtrar los empleados del Core usando el campo `especialidades`.

**Ejemplo (Lavandería):**
Para asignar una tarea de planchado, la lógica de negocio consulta:
```python
empleados_planchado = db.query(Empleado).filter(
    Empleado.empresa_id == empresa_id,
    Empleado.estado_disponibilidad == "DISPONIBLE"
).all()
# Filtrado en Python por JSON
candidatos = [e for e in empleados_planchado if "PLANCHADO" in e.especialidades]
```

### Cálculo de Costos
El campo `costo_hora` permite a los módulos de Producción o Servicios estimar márgenes reales sin acceder a planillas de sueldo completas.
