🛠️ Módulo Core: Vinculación Inteligente de Servicios (VIS)
Objetivo General
Eliminar la discrepancia entre la venta de intangibles (servicios) y la salida de tangibles (mercadería), asegurando que todo cobro adicional esté respaldado por una Orden de Venta (OV) base.

1. El Concepto: "Servicios Dependientes"
En lugar de tratar un servicio (como el bordado ) como un producto suelto, el sistema lo clasifica como un Servicio Dependiente de Orden.


Regla: Ningún servicio de valor agregado puede ser despachado en una Guía si no existe una OV que defina su presupuesto y cantidad máxima.

2. Arquitectura de Datos (Agnóstica)

Cabecera de Control: La Guía de Despacho siempre hereda los límites de la Orden de Venta referenciada.

Validación Cruzada (Cruce de Stock vs. Servicio):

Si se intenta despachar un servicio (ej. "Bordado Pecho" ), el sistema suma todas las unidades físicas del documento (ej. 10 Overoles, 45 Poleras, 25 Chalecos = 80 prendas ).


Filtro de Integridad: Si la cantidad del servicio (ej. 229 ) supera la cantidad física de productos o el máximo permitido en la OV, el sistema bloquea la transacción.

3. Flujo Operativo Universal
Captura de OV: El cliente solicita 100 productos y 100 servicios asociados.

Despacho Parcial: El bodeguero despacha 20 productos físicos.

Sugerencia de Servicio: El ERP sugiere automáticamente añadir solo 20 servicios de bordado a esa Guía específica.

Cierre de Saldo: El sistema descuenta del "Saldo Pendiente" de la OV tanto el producto como el servicio.

4. Ventajas para Cualquier Empresa (Escalabilidad)

Seguridad: Evita que operarios o vendedores inflen cantidades de servicios para beneficio personal (el "bolsilleo").

Auditoría: Permite saber exactamente qué orden generó cada cobro, sin importar si la empresa vende ropa, repuestos o servicios técnicos.


Consistencia Financiera: Asegura que el Total Neto y el IVA cuadren exactamente con lo pactado en la OV, evitando errores manuales de digitación.