📜 Directiva de Reingeniería: Identidad de Variantes y Stock Consolidado
Contexto: El sistema actual colapsa variantes de productos porque usa el SKU como identificador único de inventario. Vamos a migrar a una arquitectura de Variantes por Contenido (JSONB Hash).

Objetivo: Implementar una tabla de product_variants y vincular el inventario a estas, garantizando que 30k+ registros con el mismo SKU pero distintos atributos persistan correctamente.

1. Migración de Base de Datos (Alembic)
Crear Tabla product_variants:

id: UUID (PK).

producto_id: UUID (FK a productos).

hash_identity: String (Índice Único). Resultado de md5(canonized_jsonb_attributes).

attributes: JSONB.

sku_variant: String (Opcional, para SKUs específicos de variante).

Modificar Tabla inventario:

Añadir variant_id (FK a product_variants).

IMPORTANTE: Eliminar cualquier restricción UNIQUE antigua que solo considere (producto_id, bodega_id) o (sku, bodega_id).

Crear nueva restricción UNIQUE compuesta: (variant_id, bodega_id).

2. Lógica de Negocio en el Backend (ingestion_apply.py y Servicios)
Canonización de JSONB: Antes de guardar o comparar, los atributos deben ordenarse alfabéticamente por llave para que el Hash sea consistente.

Flujo del Apply Masivo:

Fase de Variantes: Por cada fila del Excel, calcular el Hash. Si no existe una product_variant con ese producto_id y hash_identity, crearla.

Fase de Inventario: Vincular la fila al variant_id correspondiente.

Resolución de Conflictos: Si la combinación (variant_id, bodega_id) ya existe, realizar UPDATE de cantidad. Si no, INSERT.

Optimización: Usar un caché temporal de variantes durante el proceso de los 30k registros para evitar miles de queries SELECT a la DB.

3. Frontend y API
StockRead DTO: La API debe devolver el id de la fila de inventario, el sku del producto base y los attributes de la variante.

DataGrid: El frontend debe usar el id de inventario como :key única para permitir que se rendericen múltiples filas del mismo SKU con distintos atributos.

4. Integridad y Seguridad
Generar el script de migración con alembic revision --autogenerate.

Asegurar que los datos existentes se migren a la tabla de variantes (Data Migration) para no perder el stock actual.

Criterio de Aceptación: Una carga de 30,656 registros debe resultar en 30,656 registros (o los que correspondan a variantes únicas) sin errores de "Llave duplicada" y sin sobreescrituras accidentales.


5. Data Migration Strategy (Legacy to Variant):

El script de Alembic debe incluir una función upgrade que:

Recorra la tabla inventario actual.

Por cada fila, cree una entrada en product_variants extrayendo el JSONB existente.

Actualice el variant_id en la tabla inventario.

Solo después de que todos los datos estén vinculados, se deben activar los NOT NULL y las UNIQUE CONSTRAINTS.