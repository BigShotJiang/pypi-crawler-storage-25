# Implementación Técnica: Backend Firma Digital y Storage Cloudflare R2

**Fecha:** 12-02-2026
**Estado:** Implementado y Verificado (Backend)

## 1. Resumen
Se ha completado la implementación del circuito de backend para la fase de "Preparación de Firma Digital". Esto incluye la creación del endpoint seguro, la integración con Cloudflare R2 para almacenamiento eficiente y la lógica de validación de negocio.

## 2. Componentes Implementados

### 2.1 Endpoint `POST /crm/opportunities/{id}/prepare-signature`
Este endpoint es el punto de entrada para iniciar el proceso de firma.
*   **Ruta:** `app/core_modules/crm/api.py`
*   **Validaciones de Negocio:**
    1.  **Crédito Aprobado:** La oportunidad debe tener `estado_credito='APROBADO'`.
    2.  **Stock Reservado:** Debe existir una `bodega_id` asignada (reserva de stock efectiva).
*   **Acciones:**
    1.  Genera un PDF placeholder (simulando el documento legal).
    2.  Calcula el hash SHA-256 del documento para integridad (`hash_integridad`).
    3.  Sube el documento al Storage (R2 o Local).
    4.  Crea el registro en `legal_documentos` con estado `PENDIENTE`.
    5.  Actualiza la oportunidad a `ESPERANDO_FIRMA`.
*   **Retorno:** URL pre-firmada (Presigned URL) válida por 15 minutos para visualización inmediata en Frontend.

### 2.2 Servicio de Almacenamiento (StorageService) Híbrido
Se refactorizó `app/services/storage_service.py` para soportar un modo híbrido robusto.
*   **Prioridad R2:** Si las credenciales de Cloudflare R2 existen en `.env`, el sistema usa R2 automáticamente.
*   **Fallback Local:** Si no hay credenciales, usa el sistema de archivos local (`/storage_files`), permitiendo desarrollo offline.
*   **Zero Egress Cost:** Se configuró el cliente `boto3` para usar el endpoint específico de la cuenta R2 (`https://{ACCOUNT_ID}.r2.cloudflarestorage.com`). Esto asegura que las descargas via Presigned URL sean internas de la red de Cloudflare (o gratuitas según política R2) y no generen costos de egreso excesivos.
*   **Seguridad:** Todos los objetos se suben con `ACL='private'`.

### 2.3 Configuración de Credenciales
El sistema requiere las siguientes variables en `.env` para producción:
```ini
R2_BUCKET_NAME=erp-bucket
R2_ACCOUNT_ID=97a0...         # ID de la cuenta Cloudflare
R2_API_TOKEN=tI1v...          # Token para administración (opcional para runtime)
R2_ACCESS_KEY_ID=9d32...      # S3 Access Key (Lectura/Escritura)
R2_SECRET_ACCESS_KEY=d7ac...  # S3 Secret Key
```

## 3. Integridad de Datos
Para garantizar que el documento firmado no sea alterado:
1.  **Hash al Crear:** Se calcula SHA-256 del PDF generado y se guarda en `legal_documentos.hash_integridad`.
2.  **Verificación:** El script de integridad (`final_integrity_check.py`) descarga el archivo, recalcula el hash y lo compara con la BD.

## 4. Verificación y Testing
Se creó el script `one-off-scripts/final_integrity_check.py` que realiza una prueba End-to-End:
1.  Crea una oportunidad de prueba.
2.  Intenta firmar sin requisitos (Falla 400 OK).
3.  Aprueba crédito y asigna bodega.
4.  Ejecuta `prepare-signature`.
5.  Valida existencia del archivo en R2/Local.
6.  Descarga y valida Hash SHA-256 contra la base de datos.

**Resultado:** `CONEXIÓN LEGAL ASEGURADA - HASH VÁLIDO`
