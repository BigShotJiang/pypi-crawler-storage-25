# 🧠 Base de Conocimiento ERP3 (Obsidian Vault)

¡Bienvenido! Has abierto la documentación de ERP3 en **Obsidian**. Esta carpeta está estructurada para funcionar como tu "segundo cerebro" para el proyecto.

## 🚀 ¿Cómo usar esto?
1.  **Abre Obsidian**.
2.  Selecciona **"Open folder as vault"**.
3.  Elige la carpeta: `e:\ERP3\.Documentacion`.
4.  ¡Listo! Ahora puedes navegar gráficamente.

---

## 🗺️ Mapa de Contenido (MOC)

### 🏛️ Arquitectura & Núcleo
- [[Arquitectura_Sistema]] - Visión general y patrones.
- [[Estructura]] - Organización de carpetas del proyecto.
- [[CORE_MODULES]] - Definición de los módulos base.
- [[Backend_Madurez_10_Pilares]] - Estado de madurez del sistema (10 Pilares).
- [[modelos_datos]] - Esquema de Base de Datos.

### 🧩 Módulos Principales
- [[Sistema_Module]] - Multi-tenant, Auth, Config.
- [[Ventas_Module]] - Motor de ventas y servicios.
- [[Finanzas_Module]] - Contabilidad y tesorería.
- [[Compras_Module]] - Adquisiciones y stock.
- [[RRHH_Module]] - Recursos Humanos.
- [[Facturacion_Module]] - Integración DTE.
- [[Auditoria_Module]] - Logs y seguridad.

### 💡 Guías y Manuales
- [[guia_inicio_rapido]] - Para nuevos desarrolladores.
- [[Guia_Worker_Background_Jobs]] - Manejo de tareas asíncronas.
- [[guia_configuracion_industrias]] - Cómo extender el ERP con plantillas.
- [[MANUAL_CONEXION_POWERBI]] - Business Intelligence.

### 🛡️ Seguridad y Auditoría
- [[AUDITORIA_SEGURIDAD]] - Protocolos de seguridad.
- [[Pilar8_CoberturaE2E]] - Estrategia de Testing (Penny Test, Race Conditions).
- [[reporte de auditoria]] - Logs recientes.

---

## ⚡ Tips de Obsidian para este Vault

> [!TIP] Vista de Gráfico (Graph View)
> Presiona `Ctrl+G` para ver cómo se interconectan los módulos. Los nodos más grandes son los documentos más referenciados (probablemente `Sistema_Module` o `Estructura`).

> [!TIP] Búsqueda Rápida
> Presiona `Ctrl+O` para saltar a cualquier archivo (ej: escribe "ventas" para ir al módulo de ventas).

> [!TIP] Canvas
> Intenta crear un nuevo **Canvas** en Obsidian y arrastra los archivos `Ventas_Module.md` y `Finanzas_Module.md` para visualizar sus interacciones en un pizarrón infinito.
