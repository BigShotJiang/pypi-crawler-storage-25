# Análisis de Viabilidad Técnica: Vinculación Inteligente de Servicios (VIS)

## 1. Resumen Ejecutivo
**Estatus: VIABLE**
La arquitectura actual de ERP3 (backend Python/FastAPI + PostgreSQL) posee las bases estructurales necesarias para implementar la funcionalidad VIS descrita en `idea_futura.md`. Los modelos de datos (`Venta`, `DocumentoTributario`, `Producto`) ya cuentan con las relaciones clave (`ForeignKeys`) y atributos (`es_servicio`) requeridos, minimizando la necesidad de cambios drásticos en el esquema de base de datos.

El esfuerzo principal radicaría en la **Capa de Lógica de Negocio**, específicamente en la creación de validadores previos a la emisión de DTEs.

## 2. Infraestructura Existente (Lo que ya tenemos)

La inspección del código revela que los "cimientos" están listos:

### A. Trazabilidad DTE -> Orden de Venta
El modelo `DocumentoTributario` ya cuenta con el campo `venta_id`, lo que permite vincular cualquier Guía de Despacho (Tipo 52) o Factura a su Orden de Venta (OV) original.
*   **Código:** [facturacion/models.py:L100](file:///e:/ERP3/backend/app/core_modules/facturacion/models.py#L100) -> `venta_id = Column(Integer, ForeignKey('ventas.id'), ...)`

### B. Identificación de Servicios
El sistema ya distingue claramente entre productos físicos y servicios, tanto a nivel de catálogo como de transacción:
*   **Catálogo:** `Producto` tiene `tipo_producto='SERVICIO'` ([ventas/models.py:L51](file:///e:/ERP3/backend/app/core_modules/ventas/models.py#L51)).
*   **Transacción:** `DetalleVenta` tiene el flag `es_servicio` ([ventas/models.py:L108](file:///e:/ERP3/backend/app/core_modules/ventas/models.py#L108)). Esto permite iterar sobre las líneas de una venta y separar tangibles de intangibles fácilmente.

### C. Soporte DTE Unificado
El modelo `DocumentoTributario` es agnóstico al tipo de documento (soporta Tipo 52 Guía Despacho), lo que facilita aplicar la regla de validación a cualquier documento de salida.

## 3. Componentes Faltantes (Lo que habría que construir)

Para materializar la idea, se requiere desarrollar tres componentes lógicos que hoy no existen:

### A. Calculadora de Saldos Pendientes ("Dispatch Tracking")
Actualmente, no existe una función rápida que diga "¿Cuánto falta por despachar de la OV #100?".
*   **Requerimiento:** Crear un servicio que, dado un `venta_id`, sume todas las cantidades ya despachadas en DTEs previos (filtrando por aquellos válidos en SII) y las reste de la cantidad original de la OV.

### B. Interceptor de Validación ("The Gatekeeper")
Se necesita un *middleware* o servicio de validación que se ejecute **antes** de guardar un nuevo `DocumentoTributario`.
*   **Lógica a implementar:**
    ```python
    def validar_despacho_servicios(venta_id, items_a_despachar):
        # 1. Obtener límites de la OV (Presupuesto y Cantidad Máxima)
        # 2. Calcular total de físicos en este despacho
        # 3. Calcular total de servicios en este despacho
        # 4. Si servicios > fisicos OR servicios > saldo_pendiente_ov:
        #       Raise Error("Intento de despacho no autorizado (VIS Rule #1)")
    ```

### C. Sugeridor de Cantidades (Frontend/Backend)
Un endpoint que, al seleccionar una OV para despachar, pre-llene la Guía de Despacho calculando la proporción correcta.
*   *Ejemplo:* Si despacho 20 pantalones, el endpoint sugiere automáticamente 20 servicios de bordado, evitando el ingreso manual propenso a errores ("bolsilleo").

## 4. Conclusión y Recomendación
La idea es **técnicamente sólida y de bajo riesgo arquitectónico**. No requiere migraciones complejas de base de datos, solo la implementación de lógica de control en la capa de servicios de `facturacion` y `ventas`.

**Recomendación de Implementación Futura:**
Integrar esta lógica en el momento de creación del borrador del DTE (`POST /api/v1/facturacion/dte/draft`), retornando alertas bloqueantes al frontend si se violan las reglas de integridad VIS.
