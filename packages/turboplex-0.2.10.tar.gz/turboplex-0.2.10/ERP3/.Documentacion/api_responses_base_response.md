BaseResponse y estandarización de respuestas API
===============================================

Este documento resume el nuevo esquema genérico de respuesta para la API, alineado con el hallazgo 3.1 (multi-tenant por empresa_id) y 6.1 (manejo consistente de errores).

Esquema genérico
----------------

Se introducen tres modelos en la capa core:

- ErrorPayload: describe el error de dominio o técnico.
- MetaPayload: incluye contexto transversal (request_id, empresa_id, módulo, rls_scope).
- BaseResponse[T]: envoltorio genérico que contiene success, data, error y meta.

Ejemplo de definición (simplificado):

    class ErrorPayload(BaseModel):
        code: str
        message: str
        details: Optional[Dict[str, Any]] = None

    class MetaPayload(BaseModel):
        request_id: Optional[str] = None
        empresa_id: Optional[str] = None
        module: Optional[str] = None
        rls_scope: Optional[str] = None
        extra: Optional[Dict[str, Any]] = None

    class BaseResponse(GenericModel, Generic[T]):
        success: bool
        data: Optional[T] = None
        error: Optional[ErrorPayload] = None
        meta: Optional[MetaPayload] = None

Ejemplo aplicado a Ventas
-------------------------

El endpoint de creación de venta ahora usa BaseResponse[Venta] como contrato de salida.

Ejemplo de respuesta de éxito:

    {
      "success": true,
      "data": {
        "id": "uuid-venta",
        "empresa_id": "uuid-empresa",
        "total": 1224,
        "estado": "EMITIDA"
      },
      "error": null,
      "meta": {
        "request_id": "018f2a5a-5aa4-7b1a-9c23-8b74f0c39f12",
        "empresa_id": "uuid-empresa",
        "module": "VENTAS",
        "rls_scope": "empresa",
        "extra": null
      }
    }

Ejemplo conceptual para Herrería
--------------------------------

Una futura vertical de Herrería puede usar el mismo esquema sin acoplar el núcleo:

    {
      "success": true,
      "data": {
        "id": "uuid-pedido",
        "empresa_id": "uuid-empresa",
        "codigo": "HER-2026-0001",
        "estado": "EN_PRODUCCION",
        "items": [
          {"sku": "PERNO-1/2", "cantidad": 100},
          {"sku": "PLACA-ACERO-6MM", "cantidad": 12}
        ]
      },
      "error": null,
      "meta": {
        "request_id": "018f2a5a-5aa4-7b1a-9c23-8b74f0c39f34",
        "empresa_id": "uuid-empresa",
        "module": "HERRERIA",
        "rls_scope": "empresa",
        "extra": {
          "lead_time_estimado_dias": 3
        }
      }
    }

Manejo de errores con BaseResponse
----------------------------------

Los manejadores globales de excepciones ahora devuelven BaseResponse[dict] con success=false, error poblado y meta.request_id.

Notas sobre CORS y ALLOWED_HOSTS
--------------------------------

Se introduce la lista `ALLOWED_HOSTS` en configuración (`app/core/config.py`) con valores por defecto de desarrollo (localhost y puertos típicos). Esta lista reemplaza el uso de `BACKEND_CORS_ORIGINS` en el middleware CORS (`app/main.py`), permitiendo:

- Validación estricta en producción (no se permiten comodines amplios, lista obligatoria).
- Compatibilidad retroactiva: si se define `BACKEND_CORS_ORIGINS`, se usa como respaldo para `ALLOWED_HOSTS` hasta completar la migración.
