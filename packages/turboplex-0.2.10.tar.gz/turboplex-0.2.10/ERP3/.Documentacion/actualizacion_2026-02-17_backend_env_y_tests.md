Fecha: 2026-02-17

## 1. Objetivo de la jornada

- Dejar la **suite completa de tests del backend en verde** (exit code 0).
- Normalizar la **configuración de entorno (.env)** para que:
  - Sea coherente entre máquinas (Acer y Torre).
  - No requiera exportar variables manualmente para correr tests.
- Estabilizar la **DB de pruebas** (`erp3_test`) y el **fixture global de tests**.

---

## 2. Problemas que se encontraron

1. **Esquema incompleto / inestable en `erp3_test`**
   - Tests que daban `UndefinedTable` y `DatatypeMismatch` (UUID vs INTEGER).
   - Parte del esquema se creaba con `Base.metadata.create_all`, otra parte vía Alembic, otra nunca llegaba a crearse en la DB de test.

2. **Conexiones a la DB inconsistentes en tests de integración “reales”**
   - Algunos tests (ej. VIS, integraciones) usaban directamente `settings.DATABASE_URL` o creaban su propio `engine` sin respetar `TEST_DATABASE_URL`.
   - Resultado: errores `InsufficientPrivilege` o uso de una base distinta de `erp3_test`.

3. **conftest.py demasiado frágil**
   - Existían versiones anteriores que:
     - No cargaban bien todos los modelos antes de `create_all`.
     - Ejecutaban DDL costoso o `drop_all/create_all` en cada test.
   - El bootstrap de columnas “extra” (`ALTER TABLE ... ADD COLUMN IF NOT EXISTS`) corría antes de que las tablas estuvieran creadas.

4. **Confusión de configuración en `.env`**
   - `.env` tenía variables duplicadas:
     - `SECRET_KEY` y `DATABASE_URL` definidas dos veces con valores distintos.
   - Variables no declaradas en `Settings`:
     - `TEST_DATABASE_NAME`, `USE_REDIS` -> provocaban `extra_forbidden` en Pydantic Settings.
   - Había un `.env.backup` con valores antiguos (`dev_secret_key_123`, `erp3_user/erp3_db`) y un `.env.example` con ejemplos genéricos.

5. **Ruido de Redis / background jobs**
   - Al correr tests, el import de `app.core.queue` intentaba conectar a Redis y mostraba warnings ruidosos.

---

## 3. Cambios clave en `tests/conftest.py`

Archivo: `backend/tests/conftest.py`

1. **Carga de entorno con `python-dotenv`**
   - Se agregó:
     - `from dotenv import load_dotenv`
     - `BACKEND_DIR = os.path.dirname(os.path.dirname(__file__))`
     - `load_dotenv(os.path.join(BACKEND_DIR, ".env"))`
   - Efecto:
     - Tanto en Acer como en Torre, los tests leen automáticamente el `.env` local sin necesidad de exportar variables.

2. **Selección robusta de URL de DB de test**
   - Función `_select_test_database_url()`:
     - Orden de candidatos:
       1. `TEST_DATABASE_URL` (si existe).
       2. `DATABASE_URL` del entorno.
       3. Valores encontrados en `.env`, `.env.backup`, `.env.example`.
       4. `DEFAULT_TEST_DATABASE_URL = postgresql://postgres:postgres@localhost/erp3_test`.
     - Para cada candidato:
       - Normaliza el **nombre de la base** al valor `TEST_DATABASE_NAME` (por defecto `erp3_test`).
       - Verifica conexión con `_try_connect`.
       - Si la DB no existe, la crea usando privilegios de `postgres` cuando el usuario lo permite.
   - Resultado:
     - La suite siempre usa **la misma DB de test**, aislada (`erp3_test`), aunque en `.env` la `DATABASE_URL` apunte a otra base de desarrollo.

3. **Asignación global de `DATABASE_URL` para el proceso de tests**
   - Una vez seleccionada la URL final:
     - `TEST_DATABASE_URL = _select_test_database_url()`
     - `os.environ["DATABASE_URL"] = TEST_DATABASE_URL`
   - Efecto:
     - Cualquier código que lea `settings.DATABASE_URL` durante los tests termina usando la DB de test.
     - Minimiza sorpresas con tests que crean sus propios engines.

4. **Creación de esquema y columnas “bootstrap”**
   - Se asegura el orden correcto:
     1. `Base.metadata.create_all(bind=engine)` sobre la DB de test.
     2. Luego, en una conexión AUTOCOMMIT:
        - `ALTER TABLE empresas ...` para columnas:
          - `is_active`, `grace_period_days`, `modulos_activos`, `pwr_bi_enabled`, `pwr_bi_config`, `limite_cupo_maximo`.
        - `ALTER TABLE clientes ADD COLUMN IF NOT EXISTS _limite_credito numeric(14,2)`
        - `ALTER TABLE usuarios_empresas ADD COLUMN IF NOT EXISTS rol_id uuid`
   - Efecto:
     - Se eliminan errores `UndefinedTable` en los `ALTER`.

5. **Fixture de limpieza por TRUNCATE**
   - Fixture `setup_db`:
     - Ejecuta `_truncate_all_tables(conn)` antes de cada test.
     - Usa `session_replication_role = 'replica'` para truncar con menos restricciones y luego lo restaura.
   - Fixture `db`:
     - Crea una sesión por test con `allow_no_tenant = True`.
     - Al finalizar, vuelve a truncar todas las tablas para dejar la DB limpia.
   - Efecto:
     - La estructura de la DB de test **no se toca** entre tests, solo se limpian datos.

6. **Mock de Redis en tests**
   - `app.core.queue.task_queue` es reemplazado por un `MagicMock`.
   - Se evita que los tests fallen o se cuelguen por falta de Redis real.

---

## 4. Correcciones en tests específicos

### 4.1. `tests/test_vis_admin_close.py`

- Problema:
  - Usaba `settings.DATABASE_URL` directamente, lo que podía apuntar a una DB distinta de `erp3_test`.
- Ajuste:
  - Al normalizar `DATABASE_URL` desde `conftest.py` hacia la DB de test, este test ahora se ejecuta contra `erp3_test`.
- Resultado:
  - `test_integration_postgres_admin_close` en verde, verificando:
    - Persistencia real de datos.
    - Tipos correctos (UUIDs, numerics).
    - Cierre administrativo VIS actualiza correctamente los saldos.

### 4.2. `tests/test_pagos_cliente.py`

- Problema:
  - `setup_pagos_con_roles` generaba datos con identificadores fijos (`PAGOS_TEST`, correos estáticos), lo que podía chocar entre ejecuciones y producir estados intermedios donde el saldo inicial no era el esperado.
- Ajustes:
  - Se genera una empresa, sucursal y cliente con sufijo aleatorio (UUID recortado) por cada ejecución del setup.
  - Se asegura que:
    - Se crean roles estándar, incluyendo `BACKOFFICE` y `AUD`.
    - Se vinculan usuarios `CON` y `VEN` a la empresa con los roles correctos.
  - El test de permisos:
    - `test_vendedor_no_puede_registrar_pago` confirma que:
      - El saldo inicial del cliente es 1000.
      - El intento de pago por usuario Vendedor lanza `BusinessRuleError`.
- Resultado:
  - Tests de pagos estables y aislados entre sí.

### 4.3. `tests/final_boss_erp_test.py`

- Problema:
  - El usuario `final.boss@erp.test` no estaba vinculado a la empresa mediante `UsuarioEmpresa` ni tenía rol `ADM`.
  - Dado el RBAC actual, ciertas operaciones (pagos, contabilidad) requieren que el usuario pertenezca a la empresa.
- Ajustes:
  - Se crea (si no existe) un rol `ADM` para la empresa `FINAL_BOSS_ERP`.
  - Se crea (si no existe) el vínculo `UsuarioEmpresa` para `final.boss@erp.test` con ese rol.
- Resultado:
  - `test_final_boss_erp_flow` recorre todo el flujo (ventas contado/crédito, anulaciones, cambios de producto, pagos finales) manteniendo:
    - Integridad contable (Debe-Haber = 0).
    - Registros de auditoría consistentes.

---

## 5. Normalización de `.env` en Acer

Archivo: `backend/.env`

### 5.1. Estado final

```env
ENVIRONMENT=development
API_V1_PREFIX=/api/v1
SECRET_KEY=K4v2J9p!fQ3sLm8Z@t0wXz7YbC6dR1hP
DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost/erp3_dev
RATE_LIMIT_ENABLED=False
REDIS_URL=redis://localhost:6379/0
```

### 5.2. Limpieza realizada

- Eliminados:
  - Duplicados de `SECRET_KEY`, `DATABASE_URL`, `REDIS_URL`.
  - Variables no contempladas en `Settings`:
    - `TEST_DATABASE_NAME`, `USE_REDIS`.
- Mantenido:
  - `.env.backup` como referencia histórica:
    - Contiene el estado previo con `dev_secret_key_123` y `erp3_user/erp3_db`.
  - `.env.example` como plantilla genérica para nuevos entornos.

### 5.3. Recomendación para la Torre

- Copiar el `.env` de Acer como base y ajustar únicamente:
  - `DATABASE_URL` apuntando a la base de dev de la Torre:
    - Ejemplo: `postgresql+psycopg2://postgres:postgres@localhost/erp3_dev_torre`
  - Opcionalmente, decidir si `SECRET_KEY` será:
    - Igual (para entornos dev coherentes).
    - Distinta (para aislar más los entornos).

---

## 6. Resultado final

- Suite completa de tests:
  - 62 tests en verde, exit code 0.
  - Incluyendo:
    - Flujos VIS, VIS edge cases, VIS logic.
    - Core integration (ventas, contabilidad básica).
    - Security SaaS (aislamiento de tenant).
    - Superadmin Dashboard, verticales, RBAC avanzado.

- Flujo de trabajo simplificado:
  - Para correr tests:
    - `cd E:\ERP3\backend`
    - `.venv\Scripts\python.exe -m pytest -vv -s`
  - Para levantar API:
    - `.venv\Scripts\uvicorn app.main:app --reload`
  - Sin necesidad de exportar manualmente `DATABASE_URL` o `TEST_DATABASE_URL`; `conftest.py` y `python-dotenv` se encargan de la selección y normalización.

---

## 7. Lecciones aprendidas (el “suplicio” en una página)

1. **DB de tests ≠ DB de dev**  
   - Debe tener su propio ciclo de vida, pero con un esquema completo y estable.

2. **conftest.py es infraestructura crítica**  
   - Ahí se decide:
     - Qué DB se usa.
     - Cómo se limpia.
     - Qué mocks se aplican (Redis, colas, etc.).

3. **.env debe ser simple y único**  
   - Un valor por variable.
   - Sin claves “extra” que Pydantic no conozca.

4. **Tests de integración “reales” deben respetar el entorno de test**  
   - Aunque creen engines manualmente, deben terminar usando la DB de test, no la de desarrollo/producción.

5. **RBAC y multi-tenant afectan incluso a tests “locales”**  
   - Si el usuario no pertenece a la empresa o no tiene el rol adecuado, los tests deben reflejarlo (y arreglar los datos, no bajar las reglas).

En resumen: el “suplicio” sirvió para dejar una base de pruebas robusta, reproducible, y un flujo de trabajo mucho más sencillo para el futuro tú (y para el tú de la Torre).

---

## 8. Mini guía rápida: levantar backend en otra máquina (Torre)

### 8.1. Preparar entorno

1. Clonar o copiar el proyecto a la Torre en una ruta equivalente (idealmente `E:\ERP3`).
2. Crear y activar el entorno virtual en `E:\ERP3\backend`:
   - `python -m venv .venv`
   - `.\.venv\Scripts\activate`
3. Instalar dependencias:
   - `cd E:\ERP3\backend`
   - `pip install -r requirements.txt`

### 8.2. Configurar `.env` en la Torre

1. Copiar `backend\.env` desde Acer a la Torre.
2. Editar `backend\.env` en la Torre y ajustar solo:
   - `DATABASE_URL` para apuntar a la base de desarrollo de la Torre, por ejemplo:
     - `DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost/erp3_dev_torre`
3. Decidir la `SECRET_KEY`:
   - Opción simple: usar la misma que en Acer:
     - `SECRET_KEY=K4v2J9p!fQ3sLm8Z@t0wXz7YbC6dR1hP`
   - Opción aislada: definir otra clave fuerte y larga solo para la Torre.

### 8.3. Verificar base de datos y Redis

1. Asegurarse de que PostgreSQL esté corriendo en la Torre y que exista la base `erp3_dev_torre` (o la que se haya configurado en `DATABASE_URL`).
2. (Opcional pero recomendado) Tener Redis disponible:
   - Local o en Docker (por ejemplo `redis://localhost:6379/0`).
   - Si Redis no está disponible en la Torre, la app seguirá arrancando, pero:
     - Se verá un warning de Redis.
     - Los background jobs (cola RQ) no funcionarán en ese entorno.

### 8.4. Correr tests completos en la Torre

Desde `E:\ERP3\backend`:

- `.\.venv\Scripts\python.exe -m pytest -vv -s`

Detalles importantes:

- `tests/conftest.py` se encarga de:
  - Cargar el `.env` con `python-dotenv`.
  - Seleccionar y, si es necesario, crear la base de datos de pruebas.
  - Forzar que toda la suite use la DB de test aislada, no la de dev.
- No es necesario exportar variables de entorno manualmente.

### 8.5. Levantar la API en la Torre

Desde `E:\ERP3\backend`:

- `.\.venv\Scripts\uvicorn app.main:app --reload`

Luego abrir en el navegador:

- Documentación interactiva:
  - `http://127.0.0.1:8000/docs`
- Health check:
  - `http://127.0.0.1:8000/health`

---

## 9. Política de bases PostgreSQL en entorno local

Objetivo: tener claro qué base se usa para qué, y cómo crear una DB “limpia” para emular un despliegue, sin romper tests ni desarrollo diario.

### 9.1. Roles de cada base (Acer)

- `erp3_test`
  - Uso: **exclusivo** para la suite de tests (`pytest`).
  - Control:
    - `tests/conftest.py` fuerza a que todos los tests usen esta base.
    - Se crea/ajusta automáticamente si es necesario.
    - Limpieza entre tests mediante `TRUNCATE ... CASCADE`, sin tocar el esquema.

- `erp3_dev`
  - Uso: base de datos de **desarrollo diario** para la API local.
  - Configuración:
    - Definida en `backend/.env`:
      - `DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost/erp3_dev`
  - La API levantada con `uvicorn app.main:app --reload` usa esta base.

- `erp3_db` (legado)
  - Uso: histórico / legacy.
  - Puede contener estados antiguos de esquema o datos de pruebas viejas.
  - Recomendación: mantener solo como referencia; no apuntar la API ni los tests aquí.

- `mini_erp_dev` (experimental)
  - Uso: base usada para pruebas anteriores tipo “mini ERP”.
  - Recomendación:
    - Si ya no se usa, se puede eliminar desde pgAdmin para reducir ruido.
    - Si se mantiene, documentar en este archivo para qué escenario específico sirve.

### 9.2. Reglas de oro

1. **Nunca apuntar tests a `erp3_dev` o `erp3_db`**
   - Los tests deben ser destructivos respecto a datos, pero no respecto a entornos de trabajo reales.
   - `erp3_test` es el único objetivo de la suite de pytest.

2. **La API de desarrollo no debe usar `erp3_test`**
   - Evita mezclar tráfico real de desarrollo con datos generados por la suite de pruebas.
   - Mantener la API usando siempre la DB de dev (`erp3_dev` o equivalente).

3. **Antes de borrar una base, revisar:**
   - `DATABASE_URL` actual en `.env`.
   - Si algún script one-off o configuración en otra máquina la está usando.

### 9.3. Crear una DB limpia para emular despliegue

Supongamos que se quiere simular un servidor nuevo con una base vacía llamada `erp3_clean`.

1. **Crear la DB en PostgreSQL**
   - En pgAdmin:
     - New Database → Name: `erp3_clean`.
     - Owner: usuario que se utilizará en `DATABASE_URL` (por ejemplo `postgres`).

2. **Ajustar temporalmente `DATABASE_URL` en `.env`**
   - Cambiar:
     - `DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost/erp3_dev`
   - Por:
     - `DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost/erp3_clean`

3. **Construir el esquema en `erp3_clean`**
   - Opción actual (pragmática):
     1. Ejecutar migraciones:
        - `cd E:\ERP3\backend`
        - `.\.venv\Scripts\python.exe -m alembic upgrade head`
     2. Si falta parte del esquema (por no existir baseline completa en Alembic):
        - Ejecutar un script one-off que llame a `Base.metadata.create_all(bind=engine)` sobre `erp3_clean` **una sola vez**.
   - Esto simula lo que hoy se necesita para poner un entorno nuevo en pie.

4. **Probar la API contra `erp3_clean`**
   - Con el `.env` apuntando a `erp3_clean`:
     - `cd E:\ERP3\backend`
     - `.\.venv\Scripts\uvicorn app.main:app --reload`
   - Verificar:
     - `/health`
     - `/docs`
     - Flujos básicos (login, alguna venta simple, etc.).

5. **Volver a la DB de dev normal**
   - Restituir en `.env`:
     - `DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost/erp3_dev`
   - Reiniciar la API si está levantada.

### 9.4. Emulación de despliegue en otra máquina (Torre)

En la Torre se puede repetir la misma estrategia:

1. Crear las bases equivalentes:
   - `erp3_test` (test).
   - `erp3_dev_torre` (dev).
   - `erp3_clean_torre` (emulación de despliegue).

2. Copiar el código y el `.env` desde Acer, ajustando solamente:
   - `DATABASE_URL` para la base de dev o de despliegue que se quiera probar.

3. Ejecutar:
   - `alembic upgrade head` sobre la base limpia.
   - La API con `uvicorn` apuntando a esa base.

Así, cada máquina puede emular su propio “servidor nuevo” sin tocar ni romper la DB de pruebas (`erp3_test`) ni la DB de trabajo diario (`erp3_dev`).

### 9.5. Script one-off para provisionar DB limpia

- Ubicación: `/.one-off-scripts/provision_db_clean.ps1`
- Qué hace:
  - Crea la base (si no existe) y corre `alembic upgrade head` apuntando a esa DB.
  - Opcionalmente aplica un seed mínimo idempotente (empresa `BOOTSTRAP_CO` + roles ADM/SUP/VEN/BOD/CON).
- Uso:
  - Abrir PowerShell y ejecutar desde cualquier carpeta:
    - `E:\ERP3\.one-off-scripts\provision_db_clean.ps1 -DatabaseName erp3_clean -Seed`
  - El script se auto‑elimina tras 2s. Si no puede, deja rastro en:
    - `/.one-off-scripts/pending-cleanup.txt`

### 9.6. Guardrail de tests (DB de pruebas)

- Archivo: `backend/tests/test_guardrail_pytest_db.py`
- Garantiza que durante pytest la `DATABASE_URL` apunte a **`erp3_test`**.
- Si algún cambio futuro rompe esta garantía, la suite fallará de inmediato con un mensaje claro.

---

## 10. Cambios aplicados hoy (post “go”)

- Se añadió un **guardrail de base de datos en pytest**:
  - Archivo: `backend/tests/test_guardrail_pytest_db.py`
  - Verifica que `settings.DATABASE_URL` contenga `erp3_test` durante la suite.
  - Validado con: `1 passed in ~6s`.
- Se actualizó **backend/.env.example**:
  - Variables válidas y coherentes con `Settings` (Pydantic).
  - Notas opcionales para Storage.
- Se creó **script one‑off de provisionado**:
  - `/.one-off-scripts/provision_db_clean.py` (núcleo en Python).
  - `/.one-off-scripts/provision_db_clean.ps1` (wrapper PowerShell con auto‑delete y registro en `pending-cleanup.txt`).
  - Capaz de crear `erp3_clean`, ejecutar `alembic upgrade head` y aplicar seed mínimo idempotente (`BOOTSTRAP_CO` + roles estándar).
- Se documentó el uso del script y el guardrail en esta guía (secciones 9.5 y 9.6).

---

## 11. Próximos pasos sugeridos

- Agregar un **smoke test de despliegue** contra `erp3_clean`:
  - Verificar `/health`, autenticación básica y creación mínima de entidad (Empresa o Producto).
  - Ejecutable al vuelo apuntando `DATABASE_URL` a la DB limpia.
- Opcional: **Seed ampliado por entorno** (solo dev):
  - Usuarios demo con roles y una venta simple para QA rápido.
  - Mantenerlo fuera de producción y de `erp3_test`.
- Pipeline de **verificación local**:
  - Tarea que ejecute: `alembic upgrade head` en DB vacía + smoke test + rollback a `erp3_dev`.

---

## 12. Smoke Test de despliegue (implementado)

- Archivo: `backend/tests/smoke/test_deploy_smoke.py`
- Comportamiento:
  - Solo corre si existe `DEPLOY_SMOKE_DB_URL` en el entorno.
  - Se conecta a esa URL y verifica la existencia de tablas núcleo: `empresas`, `usuarios`, `roles`.
- Ejecución ejemplo:
  - `cd E:\ERP3\backend`
  - `setx DEPLOY_SMOKE_DB_URL "postgresql+psycopg2://postgres:postgres@localhost/erp3_clean"`
  - `.\.venv\Scripts\python.exe -m pytest -q tests/smoke/test_deploy_smoke.py`
- Propósito:
  - Validar rápidamente que una DB recién provisionada tiene el esquema mínimo esencial.

---

## 13. Seed ampliado Dev (implementado)

- Script Python: `/.one-off-scripts/seed_dev_demo.py`
- Wrapper PowerShell: `/.one-off-scripts/seed_dev_demo.ps1` (auto‑delete con registro en `pending-cleanup.txt` si falla)
- Qué crea (idempotente):
  - Empresa `DEMO_CO`
  - Roles estándar: ADM, SUP, VEN, BOD, CON
  - Usuario admin `demo.admin@erp.local` vinculado a `DEMO_CO` con rol ADM
  - Sucursal `SUCURSAL_DEMO`
  - Método de pago `CASH`
- Ejecución:
  - PowerShell (preferido): `E:\ERP3\.one-off-scripts\seed_dev_demo.ps1`
  - Alternativa: `cd E:\ERP3\backend` y `.\.venv\Scripts\python.exe ..\.one-off-scripts\seed_dev_demo.py`
- Notas:
  - El script habilita `allow_no_tenant` en la sesión para ejecutar sin contexto de empresa.
  - No afecta `erp3_test`. Usar solo en entornos dev (`erp3_dev` o `erp3_clean`).

---

## 14. Smoke /health contra DB limpia (implementado)

- Script Python: `/.one-off-scripts/smoke_health_deploy.py`
- Wrapper PowerShell: `/.one-off-scripts/smoke_health_deploy.ps1`
- Qué hace:
  - Usa `DATABASE_URL` del entorno para configurar la app.
  - Importa `app.main`, construye un `TestClient` y llama a `/health`.
  - Falla con código de salida `1` si el status != 200.
- Ejecución típica (contra `erp3_clean`):
  - `E:\ERP3\.one-off-scripts\smoke_health_deploy.ps1 -DatabaseUrl "postgresql+psycopg2://postgres:postgres@localhost/erp3_clean"`
  - Modo silencioso pero persistente (no auto‑borra el .ps1): añadir `-KeepScript`.
- Resultado esperado:
  - Mensaje `Smoke /health OK sobre DB: ...` y body `{"status": "healthy"}`.
- Notas:
  - Se ven warnings si Redis no está disponible (esperado en entornos sin Redis).
  - `ConfigManager` puede loggear errores si la tabla `settings` está vacía, pero esto no impide que `/health` responda 200.

