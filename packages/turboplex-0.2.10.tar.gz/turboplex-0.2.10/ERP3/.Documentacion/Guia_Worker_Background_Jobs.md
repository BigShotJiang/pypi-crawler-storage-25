# Guía del Worker y Procesos en Segundo Plano (Background Jobs)

## Descripción General
El sistema ERP3 utiliza un mecanismo de **colas de tareas** para procesar operaciones pesadas o de larga duración fuera del ciclo de vida de la petición HTTP principal. Esto garantiza que la interfaz de usuario permanezca ágil y que el servidor no se bloquee.

La arquitectura se basa en:
- **Redis**: Almacén de datos en memoria utilizado como broker de mensajes.
- **RQ (Redis Queue)**: Librería ligera de Python para encolar y procesar trabajos.
- **Worker**: Proceso independiente que consume tareas de la cola.

## Componentes

### 1. Worker (`app/worker.py`)
Es el script encargado de escuchar la cola y ejecutar las tareas. Debe ejecutarse en un proceso separado (o terminal) paralelo al servidor API principal.

**Ubicación:** [worker.py](file:///e:/ERP3/backend/app/worker.py)

```python
# Ejemplo simplificado de ejecución
python app/worker.py
```

### 2. Configuración (`app/core/queue.py` y `app/core/redis.py`)
Gestiona la conexión a Redis mediante un `ConnectionPool` centralizado en `app/core/redis.py` y la instanciación de la cola `default` en `app/core/queue.py`. Si Redis no está disponible, el sistema captura la excepción para evitar que la aplicación falle al iniciarse (aunque las tareas en segundo plano no funcionarán).

**Ubicación:** [queue.py](file:///e:/ERP3/backend/app/core/queue.py), [redis.py](file:///e:/ERP3/backend/app/core/redis.py)

### 3. Definición de Tareas (`app/tasks/`)
Las tareas son funciones Python estándar. Se recomienda agruparlas en módulos dentro de `app/tasks/`.

**Ejemplo:** [reportes.py](file:///e:/ERP3/backend/app/tasks/reportes.py)
```python
def generar_reporte_mensual_pdf(reporte_id, usuario_id):
    # Lógica pesada aquí...
    pass
```

### 4. Encolado de Tareas (Endpoints y Listeners)
Desde los endpoints de la API y algunos listeners de eventos (Webhooks y Notificaciones), se importa `task_queue` y se utiliza el método `enqueue` o `enqueue_in` para despachar trabajos con soporte de idempotencia y reintentos con backoff exponencial.

**Ejemplo:** [background_jobs.py](file:///e:/ERP3/backend/app/api/v1/endpoints/background_jobs.py)
```python
job = task_queue.enqueue(
    generar_reporte_mensual_pdf,
    reporte_id=reporte_id,
    usuario_id=usuario_id
)
```

## Guía de Uso

### Prerrequisitos
1. **Servidor Redis**: Debe estar ejecutándose.
   - Local: `redis-server` (Puerto 6379 por defecto).
   - URL Configurable en `.env` o `config.py`: `REDIS_URL`.

### Pasos para agregar una nueva tarea
1. **Crear la función**: Define la lógica en un archivo dentro de `app/tasks/`.
2. **Crear el endpoint**: En tu router, importa la función y `task_queue`.
3. **Encolar**: Llama a `task_queue.enqueue(tu_funcion, args...)`.
4. **Reiniciar Worker**: Si modificas el código de las tareas, debes reiniciar el proceso `python app/worker.py` para que cargue los cambios.

### Monitoreo
El worker imprime logs en la consola estándar usando la configuración de logging de la aplicación.
- `[WORKER] Iniciando...`
- `[WORKER] Completado...`

## Solución de Problemas
- **Redis Connection Error**: Verifica que Redis esté corriendo y la `REDIS_URL` sea correcta.
- **Job no se ejecuta**: Asegúrate de que el proceso `worker.py` esté activo y escuchando la cola correcta (`default`).
- **ImportError en Worker**: El worker necesita tener acceso al contexto de la aplicación. `app/worker.py` ya incluye `from app.tasks import ...` para precargar módulos si es necesario.
