# Módulo de TI (Activos Tecnológicos) - ERP3

**Última actualización**: 2026-02-06

---

## Descripción

Gestión de activos tecnológicos internos de la empresa (hardware y software).

---

## Características

- **Inventario de activos**: Laptops, desktops, servidores, licencias
- **Asignación a empleados**: Trazabilidad de quién usa qué
- **Ciclo de vida**: Compra, asignación, mantenimiento, baja
- **Depreciación**: Cálculo automático de depreciación

---

## Tipos de Activos

| Tipo | Descripción | Ejemplos |
|------|-------------|----------|
| LAPTOP | Computador portátil | Dell Latitude, MacBook Pro |
| DESKTOP | Computador de escritorio | HP EliteDesk, iMac |
| SERVER | Servidor | Dell PowerEdge, HP ProLiant |
| NETWORK | Equipamiento de red | Switch, Router, Firewall |
| PRINTER | Impresora | HP LaserJet, Epson |
| LICENSE | Licencia de software | Office 365, Adobe CC |
| MOBILE | Dispositivo móvil | iPhone, Samsung Galaxy |

---

## Modelo de Datos

### ActivoTI

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | Integer PK | Identificador único |
| `empresa_id` | Integer FK | Empresa propietaria |
| `tipo` | String | Tipo de activo |
| `marca` | String | Marca |
| `modelo` | String | Modelo |
| `numero_serie` | String | Número de serie |
| `fecha_compra` | Date | Fecha de compra |
| `valor_compra` | Numeric | Valor de compra |
| `asignado_a_id` | Integer FK | Empleado asignado |
| `estado` | String | DISPONIBLE, EN_USO, MANTENIMIENTO, BAJA |
| `observaciones` | String | Observaciones |

---

## API

### Vincular Usuario a Empleado (TI)

Permite vincular un Empleado creado por RRHH a un Usuario existente o crear uno nuevo.
El rol se sugiere automáticamente según el `cargo` del empleado.

```http
PUT /api/v1/ti/empleados/{empleado_id}/link-user
Authorization: Bearer {token}
Content-Type: application/json
```

**Body (usuario existente)**:
```json
{
  "usuario_id": "uuid"
}
```

**Body (crear usuario)**:
```json
{
  "email": "usuario@empresa.cl",
  "password": "clave_segura"
}
```

### Operación en TI

La página de TI muestra la lista de empleados y permite activar o vincular su usuario desde ahí.

### Crear Activo

```http
POST /api/v1/ti/activos
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "tipo": "LAPTOP",
  "marca": "Dell",
  "modelo": "Latitude 5520",
  "numero_serie": "SN123456789",
  "fecha_compra": "2026-01-10",
  "valor_compra": 800000,
  "estado": "DISPONIBLE"
}
```

### Asignar a Empleado

```http
PATCH /api/v1/ti/activos/{id}/asignar
Authorization: Bearer {token}
Content-Type: application/json
```

**Body**:
```json
{
  "empleado_id": 5
}
```

### Listar Activos

```http
GET /api/v1/ti/activos?skip=0&limit=100
Authorization: Bearer {token}
```

---

## Control de Acceso

**Roles permitidos**: `ADMIN`, `DEVELOPER`, `MANAGER_TI`

```python
from app.api.deps import role_required

@router.get("/ti/activos")
@role_required(["ADMIN", "DEVELOPER", "MANAGER_TI"])
def get_activos():
    pass
```

---

## Reportes

### Activos por Tipo

```sql
SELECT tipo, COUNT(*) as cantidad, SUM(valor_compra) as valor_total
FROM activos_ti
WHERE empresa_id = :empresa_id
GROUP BY tipo
```

### Activos Asignados

```sql
SELECT a.*, e.nombre, e.apellido
FROM activos_ti a
JOIN empleados e ON a.asignado_a_id = e.id
WHERE a.empresa_id = :empresa_id AND a.estado = 'EN_USO'
```

---

## Recursos Adicionales

- [API Reference](api_reference.md#módulo-ti)
- [Modelos de Datos](modelos_datos.md)
