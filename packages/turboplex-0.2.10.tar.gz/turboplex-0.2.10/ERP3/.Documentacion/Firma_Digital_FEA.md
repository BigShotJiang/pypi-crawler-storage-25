# Firma Digital con ClaveÚnica (FEA)

## Objetivo
Implementar el uso de **Firma Electrónica Avanzada (FEA)** mediante ClaveÚnica para validar la entrega de productos y servicios. Esto garantiza que quien recibe es quien dice ser, proporcionando un respaldo legal robusto ante disputas.

## Seguridad y Arquitectura

### Identificadores Únicos (UUID)
Utilizamos **UUID (Universally Unique Identifier)** versión 4 para los identificadores de los documentos legales (`legal_documentos.id`).
*   **Colisiones**: La probabilidad de colisión es astronómicamente baja.
*   **Seguridad**: No son secuenciales, lo que impide adivinar IDs de otros documentos.
*   **Integridad**: Permiten generar nombres de archivo únicos en el almacenamiento en la nube sin riesgo de sobreescritura.

### Aislamiento Multitenant
Cada documento está estrictamente vinculado a un `tenant_id` (Empresa).
*   Las consultas a la base de datos siempre filtran por `tenant_id`.
*   La estructura de almacenamiento en R2 segrega los archivos por tenant.

## Estrategia de Almacenamiento (R2/S3)
Para garantizar escalabilidad masiva y organización lógica, los archivos PDF firmados se almacenan siguiendo esta estructura de carpetas:

`/tenant_{id}/rut_{cliente}/{año}/{mes}/{uuid}.pdf`

*   **tenant_{id}**: Aislamiento a nivel de directorio raíz.
*   **rut_{cliente}**: Agrupación por cliente para facilitar auditorías o exportaciones.
*   **{año}/{mes}**: Particionamiento temporal para evitar directorios con millones de archivos.
*   **{uuid}.pdf**: Nombre de archivo único e inmutable.

## Flujo Futuro de Firma

1.  **Generación del Documento**: El sistema genera un PDF con los detalles de la entrega/venta.
2.  **Código QR**: Se estampa un QR único en el documento físico o digital.
3.  **Escaneo**: El repartidor o vendedor escanea el QR con la App Móvil.
4.  **Redirección a ClaveÚnica**: El cliente es redirigido al portal de autenticación de ClaveÚnica.
5.  **Autenticación**: El cliente ingresa su RUN y Clave.
6.  **Firma**: ClaveÚnica valida la identidad.
7.  **Webhook de Confirmación**: ClaveÚnica notifica a nuestro backend con el token de éxito y los datos del firmante.
8.  **Sellado**: El backend descarga el certificado de firma, estampa la firma digital en el PDF, calcula el `hash_integridad` y actualiza el estado a `FIRMADO`.
9.  **Auditoría**: Se guarda el JSON con la metadata de la firma (`info_firma`) incluyendo el RUT verificado.
