# ROADMAP OFFLINE & SECURITY

## 1. Fundamento de Identidad (UUIDv7 como pilar de Offline)

- Toda entidad crítica del dominio (Empresas, Usuarios, Sucursales, Bodegas, Productos, Clientes, Ventas, Detalles, Cierres de Caja, Gastos, Órdenes de Servicio e Historiales) utiliza identificadores UUIDv7 generados en la capa de backend.
- UUIDv7 incorpora un componente temporal ordenable, lo que permite:
  - Reconstruir la secuencia de eventos de negocio incluso cuando provienen de múltiples nodos offline.
  - Resolver conflictos por orden lógico sin depender de autoincrementales ni de relojes perfectamente sincronizados.
- En modo Offline, el agente local puede crear registros completos (Clientes, Ventas, OS) sin coordinar con el servidor:
  - Los IDs se generan localmente de forma determinista y sin colisiones.
  - Al sincronizar, el backend sólo valida reglas de negocio y consistencia referencial; no necesita “re-mapear” IDs ni ejecutar procesos de reconciliación costosos.
- Esta arquitectura elimina el clásico cuello de botella de los enteros autoincrementales y habilita una sincronización eventual consistente, incluso con múltiples dispositivos trabajando sobre el mismo tenant.

## 2. Estrategia de Seguridad (Rust + Python)

- El *core* de reglas de negocio se implementa en Python, pero el plan estratégico es empaquetar los componentes más sensibles dentro de librerías Rust expuestas vía PyO3/Maturin:
  - Rust provee binarios compilados, difíciles de revertir, lo que protege la propiedad intelectual frente a agentes offline desplegados en infra del cliente.
  - La semántica de ownership y el borrow checker garantizan seguridad de memoria en módulos críticos (cifrado local, colas offline, reconciliación de datos).
- Modelo de empaquetado:
  - Módulos de negocio Python se encapsulan detrás de un *facade* Rust.
  - El agente offline habla con una API Rust (FFI o bindings nativos), reduciendo la exposición del código fuente.
  - Se priorizan en Rust:
    - Generación y validación de UUIDv7.
    - Cifrado/descifrado de payloads.
    - Aplicación de reglas de consolidación/sincronización.
- Beneficios clave:
  - Mayor resistencia a ingeniería inversa que un agente puramente Python.
  - Menor superficie de ataque en memoria (sin *buffer overflows* típicos de C/C++) gracias a Rust.

## 3. Capa de Resiliencia (Módulo de Continuidad Crítica)

- Objetivo: garantizar operación continua del ERP en condiciones de conectividad degradada o inexistente.
- El “Módulo de Continuidad Crítica” se compone de:
  - **Cola de Operaciones Offline**:
    - Cada acción de negocio (ventas, creación/edición de clientes, órdenes de servicio) se persiste localmente como evento firmado y cifrado.
    - Los eventos incluyen metadatos mínimos: UUIDv7, tipo de operación, checksum y timestamp.
  - **Almacén Cifrado Local**:
    - Uso de cifrado simétrico fuerte (ej. AES-GCM) con claves derivadas de credenciales/tenant, nunca almacenadas en texto plano.
    - Datos PII y financieros permanecen legibles sólo para el backend autorizado.
  - **Motor de Sincronización Asíncrona**:
    - Reintentos exponenciales y control de backoff cuando el enlace es inestable.
    - Aplicación de reglas de idempotencia basadas en UUIDv7 (no hay re‑creación de la misma venta/OS).
    - Resolución de conflictos basada en:
      - Orden temporal (timestamp embebido en UUIDv7).
      - Políticas de dominio (último cambio gana, versión más alta, etc.).
- La capa de resiliencia opera de forma transparente para el usuario final: el sistema “se pone al día” cuando vuelve la conectividad, sin requerir intervención manual.

### 3.1 Advertencias sobre Gestión de Conflictos

- UUIDv7 resuelve la colisión de IDs, pero **no elimina por sí mismo los conflictos de negocio**:
  - Dos agentes offline pueden modificar el mismo recurso (cliente, OS, stock) con intenciones distintas.
  - La política de resolución (quién gana, cómo se mergean campos) debe definirse explícitamente por dominio.
- Recomendaciones:
  - Modelar reglas de conflicto por tipo de entidad:
    - Clientes: último cambio gana en campos de contacto; bloques especiales para RUT y estado de crédito.
    - Ventas: operaciones idempotentes, evitar “editar ventas” y preferir eventos compensatorios.
    - Órdenes de Servicio: priorizar cambios de estado válidos según la máquina de estados (no permitir regresiones ilegales).
  - Diseñar una **traza auditable** de conflictos resueltos:
    - Registrar qué agente propuso cada cambio.
    - Conservar el “before/after” para auditoría y soporte.
  - Mantener UX clara:
    - En casos límite (conflictos no resolubles automáticamente), ofrecer flujos guiados para que un usuario autorizado tome la decisión final.

## 4. Diferenciación Competitiva frente a Sistemas Legacy

- Sistemas como RANDOM o Dafontana suelen depender de:
  - Identificadores autoincrementales centralizados en la base de datos.
  - Clientes pesados o VPNs que asumen conectividad continua con el servidor.
  - Esquemas de replicación complejos y frágiles para escenarios offline.
- Nuestra propuesta se diferencia en:
  - **Agente local ligero**:
    - No requiere stack completo de base de datos ni servidor pesado instalado en el cliente.
    - Se ejecuta como servicio pequeño (Rust + Python embebido) con footprint mínimo.
  - **Sincronización guiada por UUIDv7**:
    - No hay “ventanas ciegas” de numeración ni riesgo de colisión de folios internos.
    - La cronología de eventos se reconstruye fácilmente sin depender del reloj del sistema.
  - **Seguridad por diseño**:
    - Capa criptográfica obligatoria en todo almacenamiento local.
    - Lógica de negocio empaquetada en binarios Rust, reduciendo fuga de know‑how.
  - **Agilidad operativa**:
    - El agente puede desplegarse por tenant, por sucursal o incluso por dispositivo, adaptándose a topologías distribuidas sin rediseñar la arquitectura central.

## 5. Estado Actual del Backend

- Tras la migración completa a UUIDv7 en todos los módulos core (Sistema, Ventas, Finanzas, Inventario, Taller/OS):
  - El backend es **AI‑Ready**:
    - Esquemas consistentes y normalizados facilitan la generación de asistentes, herramientas de análisis y pruebas automáticas.
    - La trazabilidad vía UUIDv7 permite reconstruir historias de negocio para modelos de ML sin depender de claves secuenciales.
  - El backend es **Offline‑Ready**:
    - Toda la identidad está basada en identificadores generables localmente sin bloqueo de base de datos.
    - Los endpoints y esquemas de API aceptan/retornan UUIDs de forma homogénea, reduciendo fricción al conectar agentes offline.
    - Módulos sensibles (Caja, Ventas, Taller, Finanzas) ya operan con reglas independientes de autoincrementales, lo que habilita el siguiente paso: implementar el agente local sobre Rust + Python y la capa de Continuidad Crítica descrita en este roadmap.

### 5.1 Recomendación de MVP Offline

- Para reducir riesgo y validar la arquitectura, el primer hito debe ser un **MVP de Offline enfocado en Caja + Ventas**:
  - Alcance funcional:
    - Apertura y cierre de caja con conteo físico local.
    - Registro de ventas simples con impacto en stock y generación de OS básica.
    - Persistencia offline de movimientos de caja/ventas y posterior sincronización con el backend.
  - Beneficios:
    - Cubre el flujo más crítico de ingresos (ventas diarias en sucursal).
    - Permite probar en producción controlada la cola offline, el cifrado local y la reconciliación basada en UUIDv7.
    - Ofrece feedback temprano de usuarios sobre UX en modo desconectado antes de extender el modelo a módulos más complejos (compras, CRM avanzado, RRHH).
