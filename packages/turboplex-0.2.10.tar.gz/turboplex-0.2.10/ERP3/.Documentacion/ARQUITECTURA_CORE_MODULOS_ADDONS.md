﻿# Arquitectura: Core + MÃ³dulos + Addons (AS-IS vs TO-BE)

Este documento describe:
- **AS-IS (hoy):** cÃ³mo estÃ¡ estructurado ERP3 en la prÃ¡ctica.
- **TO-BE (objetivo):** cÃ³mo deberÃ­a verse una estructura limpia con **Core**, **MÃ³dulos** y **Addons**.

## 1) AS-IS (CÃ³mo estÃ¡ hoy)

ERP3 funciona como un **monolito modular**:
- Un backend Ãºnico (app FastAPI) con mÃ³dulos por dominio.
- Un frontend Ãºnico (SPA) que consume el API.
- Una base de datos Ãºnica (Postgres) con multi-tenant por `empresa_id` (reforzado con RLS en tablas crÃ­ticas).

### 1.1 Backend (estructura actual tÃ­pica)

Patrones que se observan:
- `app/core/...` concentra infraestructura transversal (DB, tenancy, auth, utilidades).
- `app/core_modules/<dominio>/...` agrupa mÃ³dulos de negocio (Inventario, Ventas, Finanzas, FacturaciÃ³n, Sistema, etc.).
- Existen servicios transversales y scripts de soporte.

Riesgos del AS-IS si no se formaliza:
- Acoplamiento entre mÃ³dulos por imports directos de modelos/servicios de otros dominios.
- SQL crudo o â€œatajosâ€ que saltan reglas tenant-scoped.
- DuplicaciÃ³n de lÃ³gica transversal (validaciones, auditorÃ­a, permisos).

### 1.2 Frontend (estructura actual tÃ­pica)

- Vistas por Ã¡rea funcional y servicios API centralizados.
- Paneles â€œsuper-adminâ€ conviven con pantallas de operaciÃ³n.

Riesgos del AS-IS:
- Reglas de permisos replicadas/dispersas en UI.
- Dependencias implÃ­citas con flujos multi-tenant (empresa activa).

## 2) Principios de DiseÃ±o (Reglas duras)

### 2.1 Regla de dependencias (direcciÃ³n Ãºnica)

Objetivo: evitar acoplamiento y mantener lÃ­mites de dominio.

- **Core** no depende de mÃ³dulos de negocio.
- **MÃ³dulos** dependen del Core, no entre sÃ­ de forma libre.
- **Addons** dependen del Core y â€œse enchufanâ€ a MÃ³dulos por puntos de extensiÃ³n.

### 2.2 Multi-tenant como regla de Core

- Toda operaciÃ³n de negocio es **tenant-scoped** por `empresa_id`.
- En requests, `empresa_id` se resuelve del contexto (empresa activa).
- En background jobs, `empresa_id` se pasa como parÃ¡metro obligatorio.
- Cualquier bypass (`allow_no_tenant`) es explÃ­cito, acotado y trazable.

## 3) TO-BE (CÃ³mo deberÃ­a verse)

La arquitectura objetivo separa:
- **Core (plataforma):** infraestructura transversal y contratos.
- **MÃ³dulos (dominios):** casos de uso y reglas de negocio por Ã¡rea.
- **Addons (extensiones):** capacidades opcionales que agregan comportamiento sin â€œromperâ€ el Core.

### 3.1 Core (Plataforma)

Core deberÃ­a contener exclusivamente:
- DB/session, transacciones, migraciones, tenancy (incluye RLS y contexto).
- Auth/RBAC, auditorÃ­a/eventos, configuraciÃ³n, errores estÃ¡ndar.
- Interfaces/contratos para integraciones (notificaciones, webhooks, storage, pagos, etc.).

Estructura sugerida:

```text
backend/app/core/
  auth/
  database/
  tenancy/
  audit/
  events/
  config/
  errors/
  utils/
```

Reglas:
- El Core expone **interfaces** y helpers; no reglas de negocio.
- Si algo â€œaplica a todosâ€ (auditorÃ­a, permisos, tenancy), va aquÃ­.

### 3.2 MÃ³dulos (Dominios)

Cada mÃ³dulo debe ser dueÃ±o de:
- Sus modelos (entidades del dominio).
- Sus schemas/DTOs.
- Sus servicios (casos de uso).
- Sus endpoints (API).

Estructura sugerida por mÃ³dulo:

```text
backend/app/modules/<modulo>/
  api/
  models/
  schemas/
  services/
  repositories/
  policies/
  __init__.py
```

Reglas:
- Un mÃ³dulo no debe leer/escribir tablas de otro mÃ³dulo â€œpor debajoâ€.
- Si necesita informaciÃ³n de otro mÃ³dulo:
  - opciÃ³n A: consumir un **service API interno** (funciÃ³n expuesta).
  - opciÃ³n B: usar un **contrato** (interface) definido en Core + implementaciÃ³n en el mÃ³dulo dueÃ±o.

### 3.3 Addons (Extensiones)

Addon = paquete opcional que agrega comportamiento por:
- hooks/eventos,
- feature flags,
- providers configurables.

Estructura estÃ¡ndar (implementada):

```text
backend/app/addons/<addon>/
  models.py
  schemas.py
  services.py
  router.py       (punto Ãºnico de entrada de APIRouter)
  routers/        (opcional: subrouters internos del addon)
  api.py          (shim temporal DEPRECATED; re-export de router.py)
  __init__.py
```

Reglas:
- El addon no modifica el Core.
- El addon no introduce imports circulares con mÃ³dulos.
- El addon no importa `app.core_modules.<x>.models` directamente; usa contratos/servicios pÃºblicos del mÃ³dulo dueÃ±o.
- El Core y los mÃ³dulos nunca importan desde `app.addons.*`.

#### 3.3.1 Registro dinÃ¡mico de routers (implementado)

- El Core registra routers de addons desde `app.addons.<addon>.router` sin `include_router` manual por addon.
- `main.py` incluye routers habilitados usando `settings.ENABLED_ADDONS` y un loader central en `app/addons/__init__.py`.
- Cada addon debe exponer un objeto `router` en `router.py` (y cualquier subrouter se agrega ahÃ­ o vÃ­a un agregador interno).

#### 3.3.2 Contratos entre Addon â‡„ MÃ³dulos (implementado)

- Cuando un addon necesita leer datos de un mÃ³dulo, consume funciones explÃ­citas en `app/core_modules/<dominio>/portal_contracts.py`.
- Estos contratos encapsulan los joins/filtrado por sucursal y garantizan propagaciÃ³n de `empresa_id` sin â€œgoteraâ€ de contexto.
- El addon `portal` no importa `core_modules.*.models`: login y cotizaciones se resuelven vÃ­a contratos de `sistema` y `crm`.

#### 3.3.3 Tenancy y RLS en tablas de Addons (implementado)

- Todas las tablas de addons son tenant-scoped por `empresa_id`.
- Se aplica `ENABLE/FORCE RLS` + `tenant_isolation_policy` (idÃ©ntica al hotfix) en:
  - `portal_users`
  - `portal_payment_notifications`
  - `cierres_caja`

## 4) Matriz de Dependencias (QuiÃ©n puede llamar a quiÃ©n)

| Capa | Puede depender de | No puede depender de |
|------|-------------------|----------------------|
| Core | librerÃ­as externas, sÃ­ mismo | mÃ³dulos, addons |
| MÃ³dulos | Core, librerÃ­as externas | otros mÃ³dulos (directo) salvo contratos explÃ­citos |
| Addons | Core, contratos pÃºblicos de mÃ³dulos | acceso directo a tablas internas de mÃ³dulos |
| API (routers) | servicios del mismo mÃ³dulo, Core | SQL directo a tablas de otros mÃ³dulos |

## 5) Puntos de extensiÃ³n recomendados

Para habilitar addons sin acoplar:
- Eventos de dominio (p.ej. `venta_creada`, `inventario_ajustado`, `dte_emitido`).
- Hooks de pipeline (p.ej. `before_confirm_sale`, `after_confirm_sale`).
- Providers: `NotificationProvider`, `StorageProvider`, `WebhookDispatcher`.

## 6) Plan de migraciÃ³n incremental (sin big-bang)

1) **Congelar el Core actual**: declarar quÃ© queda dentro de Core y quÃ© sale.
2) **Definir fronteras por mÃ³dulo** (inventario/ventas/finanzas/facturaciÃ³n/sistema).
3) **EstÃ¡ndar de imports**: prohibir imports cross-mÃ³dulo de `models` (salvo contrato).
4) **Introducir contracts/adapters** para dependencias inevitables.
5) **Addons**: mover integraciones opcionales a paquetes `addons/` (por evento/hook).
6) **Cobertura de aislamiento**: tests cross-tenant por mÃ³dulo antes/despuÃ©s.

## 7) Checklist de arquitectura (control continuo)

- [ ] No hay imports directos `moduleA.models` desde `moduleB` (sin contrato).
- [ ] Casos de uso requieren `empresa_id` explÃ­cito o via contexto.
- [ ] Background jobs incluyen `empresa_id` y fallan si falta.
- [ ] SQL crudo estÃ¡ limitado y se apoya en RLS/tenant filter.
- [ ] Addons se integran por hooks/eventos/providers, no por â€œparchesâ€ al Core.




--------------------------------------------------


ðŸ› ï¸ El Plan: ExtracciÃ³n de Add-ons al "TO-BE"
Para que un Add-on sea realmente un Add-on y no "espagueti", debe cumplir la regla de oro: El Core no sabe que el Add-on existe, pero el Add-on sabe cÃ³mo usar el Core.

1. UbicaciÃ³n EstÃ¡ndar
Crea una carpeta raÃ­z (si no existe) fuera de core_modules:

backend/app/addons/<nombre_addon>/

Dentro, cada Addon debe tener su propia estructura mÃ­nima: models.py, schemas.py, services.py y router.py.

2. La "Prueba de Fuego" del Import
Para verificar que no hay espagueti, haz este check mental:

Mal: from app.core_modules.ventas.models import Venta (Acoplamiento fuerte).

Bien: El Addon usa un "Contract" o una utilidad del Core para obtener lo que necesita, o recibe los datos vÃ­a Eventos (ej. un webhook interno o un hook).

3. Registro DinÃ¡mico (El "Enchufe")
Para que el Addon funcione sin tocar el main.py cada vez:

En app/addons/__init__.py, podrÃ­as tener una lista de ENABLED_ADDONS.

El main.py recorre esa lista y carga los routers automÃ¡ticamente. AsÃ­, instalar un Addon es solo aÃ±adir una lÃ­nea a una lista, no programar de nuevo el inicio de la app.


ðŸ“‹ GuÃ­a de Movimiento (Para aÃ±adir al pie de tu MD de Arquitectura)
Si quieres dejar esto documentado en tu archivo ARQUITECTURA_CORE_MODULOS_ADDONS.md, pega este bloque al final para que cualquier proceso futuro sepa cÃ³mo operar:

Markdown
## ðŸ› ï¸ Protocolo de MigraciÃ³n de Addons (QuirÃºrgico)

Para mover un componente al espacio de `addons/`, se deben seguir estos pasos tÃ©cnicos:

1. **Aislamiento de Directorio**: Mover archivos a `app/addons/{addon_name}/`.
2. **Saneamiento de Dependencias**: 
   - Los Addons pueden importar del `Core`.
   - Los Addons **NO** pueden importar `models` de `core_modules` directamente (usar Services).
   - El `Core` y los `core_modules` **NUNCA** deben importar nada de un `Addon`.
3. **InyecciÃ³n de Tenancy**: Todo modelo de Addon debe heredar la lÃ³gica de `empresa_id` y activar RLS en Postgres (ver `GOTERAS_PENDIENTES_TENANT_SECURITY.md`).
4. **Auto-Discovery**: El Addon debe exponer un `router` en su `__init__.py` para ser cargado dinÃ¡micamente por la aplicaciÃ³n principal.
âš ï¸ QuÃ© vigilar mientras el IDE trabaja:
Rutas de Alembic: Al mover los modelos de los Addons, es posible que Alembic crea que las tablas "desaparecieron" y quiera borrarlas. Verifica las migraciones antes de aplicarlas; solo deberÃ­an ser cambios de ubicaciÃ³n de clases, no de tablas.

Referencias Circulares: El espagueti suele esconder imports circulares. Al mover los Addons a una carpeta limpia, el IDE detectarÃ¡ estos errores de inmediato. No los ignores, es el momento de romper esos vÃ­nculos.


## Estado verificado 2026-03-22

### Core Modules actualmente presentes
- `sistema`, `ventas`, `finanzas`, `compras`, `crm`, `facturacion`, `inventario`, `rrhh`, `ti`, `service_engine`, `auditoria`, `notificaciones`, `analytics`, `billing`, `legal`.

### Add-ons actualmente presentes
- `portal`
- `pos_retail`
- `webhooks`

### Ajustes de consistencia
- `webhooks` ya no se considera `core_module`; se mantiene como add-on en `app/addons/webhooks`.
- La carga de add-ons sigue siendo dinámica desde `app/addons/__init__.py` según `ENABLED_ADDONS`.
