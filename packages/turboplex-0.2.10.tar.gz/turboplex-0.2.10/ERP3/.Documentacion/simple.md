
GET
ObtenerDatos v2
https://rut.simpleapi.cl/v2/17096073-4
Este endpoint permite obtener la información de un contribuyente a partir de su RUT, consultando datos en el SII.

No lleva body.

Parámetros de búsqueda:

Los Parámetros de búsqueda, deben ser indicados en el endpoint, de la siguiente manera: https://rut.simpleapi.cl/v2/{RUT}

Ejemplo:

https://rut.simpleapi.cl/v2/17096073-4

Este endpoint busca la información que tiene disponible el SII del RUT a consultar. Por lo general toma entre 5 a 15 segundos traer la información. Es posible que si el SII presenta intermitencias, el endpoint falle.

Nuestros sistemas actualizan todos los domingos por la noche, los correos electrónicos de los contribuyemtes a nivel nacional.

Respuesta Exitosa

En caso de que el RUT exista en al menos alguna fuente de datos, se retorna un objeto JSON con los siguientes campos:

View More
Plain Text
{
  "rut": "string",
  "razonSocial": "string",
  "actividadesEconomicas": [
    {
      "codigo": "string",
      "descripcion": "string",
      "categoria": "string",
      "afectaIVA": bool,
      "fecha": "string" //dd-MM-yyyy
    }
  ],
  "correoIntercambio": "string",
  "domicilios": [
    {
      "direccion": "string",
      "ciudad": "string",
      "comuna": "string"
    }
  ],
  "presentaInicioActividades": bool,
  "fechaInicioActividades": "string", //dd-MM-yyyy
  "esEmpresaMenorTamano": bool,
  "webFacturacion": "string"
}
Respuestas de Error

400 Bad Request
Se devuelve cuando el RUT es inválido o no existe en el SII.

Ejemplo:

No hay registros del RUT 23318775-5 en el SII

401 Unauthorized
Cuando las credenciales (API Key) no son válidas o el usuario no tiene suscripción habilitada para esta API

500 Internal Server Error
Si ocurre algún error inesperado en la ejecución (excepciones internas, timeout, etc.), se retorna un mensaje del tipo:

"Error al obtener información del RUT"

AUTHORIZATION
API Key
This request is using API Key from collectionSimple API
Example Request
ObtenerDatos V2
curl
curl --location 'https://rut.simpleapi.cl/v2/17096073-4'
200 OK
Example Response
Body
Headers (5)
View More
json
{
  "rut": "17096073-4",
  "razonSocial": "GONZALO ALEJANDRO BUSTAMANTE BANADOS",
  "actividadesEconomicas": [
    {
      "codigo": "960909",
      "descripcion": "OTRAS ACTIVIDADES DE SERVICIOS PERSONALES N.C.P.",
      "categoria": "Segunda",
      "afectaIVA": false,
      "fecha": "30-03-2010"
    }
  ],
  "correoIntercambio": "gonzalo.bustamante.b@gmail.com",
  "domicilios": [
    {
      "direccion": "DIRECCIÓN DE PRUEBA 7878",
      "ciudad": "",
      "comuna": "PUENTE ALTO"
    },
    {
      "direccion": "LOS AROMOS 104",
      "ciudad": "IQUIQUE",
      "comuna": "ALTO HOSPICIO"
    }
  ],
  "presentaInicioActividades": true,
  "fechaInicioActividades": "30-03-2010",
  "esEmpresaMenorTamano": false,
  "webFacturacion": ""
}
Suscripción
AUTHORIZATION
API Key
This folder is using API Key from collectionSimple API
GET
Status
https://api.simpleapi.cl/api/v1/suscripcion/status
Este endpoint permite conocer el status de la suscripción. No requiere parámetros. Solo autenticación.

AUTHORIZATION
API Key
Key
Authorization

Value
<value>