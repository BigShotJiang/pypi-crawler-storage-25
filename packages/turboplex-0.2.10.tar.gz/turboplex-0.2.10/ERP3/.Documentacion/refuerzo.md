procede con el Refuerzo de Élite del Core (Ventas/Inventario/Finanzas). Sigue estas especificaciones técnicas detalladas:

1. Unificación de Caminos (InventoryService)
Acción: Asegura que toda mutación de stock (altas, bajas, transferencias) pase obligatoriamente por InventoryService.

Regla: Queda prohibido instanciar MovimientoStock o modificar la tabla stock_bodega directamente desde otros servicios o APIs. El servicio debe ser el único poseedor de la lógica del 'Guardián de Inventario'.

2. Robustez y Transaccionalidad
Atomicidad: Envuelve los flujos de create_venta y ajuste_stock en bloques transaccionales @transactional (o el decorador/contexto que uses). Si falla la inserción de un solo impuesto o un solo movimiento de stock, toda la operación debe hacer rollback. No queremos 'ventas huérfanas' sin impuestos o sin stock.

Idempotencia: Añade soporte para request_id (UUID) en los endpoints de creación masiva. El sistema debe ignorar peticiones duplicadas con el mismo ID para evitar duplicar stock o ventas si la conexión falla.

3. Snapshots y Cierre de Periodos (El Búnker)
Modelo de Snapshot: Crea la tabla stock_diario_snapshot(id, fecha, producto_id, bodega_id, cantidad, costo_pmp, empresa_id).

Lógica: Implementa una función que pueda capturar la 'foto' del inventario. Esto servirá para que los reportes de valorización sean instantáneos.

Bloqueo Contable: Implementa un guard en los servicios de Ventas e Inventario que verifique si la fecha de la operación pertenece a un 'Periodo Cerrado'. Si el periodo está cerrado, lanza PeriodoBloqueadoError.

4. Constraints de Base de Datos
Hard-Guard: Añade mediante Alembic un CHECK constraint en la tabla productos: tipo_producto IN ('ALMACENABLE', 'SERVICIO', 'CONSUMIBLE').

Protección SQL: Si es posible, añade un Trigger a nivel de DB que impida insertar filas en movimientos_stock si el producto_id asociado es de tipo SERVICIO. (Doble capa de seguridad).

5. Refactor de Tipado (mypy)
Targeted Cleaning: No limpies los 105 errores aún, pero SÍ deja en strict total los archivos: stock_ops.py, tax_utils.py y inventory_service.py. Usa Optional[] explícitos y anotaciones de retorno -> None o -> Decimal según corresponda."