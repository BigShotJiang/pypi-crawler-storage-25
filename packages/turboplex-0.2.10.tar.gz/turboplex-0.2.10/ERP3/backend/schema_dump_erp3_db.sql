--
-- PostgreSQL database dump
--

\restrict 6TVRNxdXTVVjHnX7KF5BN7h8fA3JSZlTxcATzRQKJu6sTA3fIv4Gz1qTBnS3ge5

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: crm; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA crm;


--
-- Name: codigodisposiciondraenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.codigodisposiciondraenum AS ENUM (
    'OK',
    'DUPLICADO',
    'DANADO'
);


--
-- Name: estadocredito; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadocredito AS ENUM (
    'PENDIENTE',
    'APROBADO',
    'BLOQUEADO'
);


--
-- Name: estadodocumento; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadodocumento AS ENUM (
    'PENDIENTE',
    'FIRMADO',
    'ANULADO'
);


--
-- Name: estadodraenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadodraenum AS ENUM (
    'BORRADOR',
    'POSTEADO'
);


--
-- Name: estadogastoenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadogastoenum AS ENUM (
    'PENDIENTE',
    'PAGADO',
    'ANULADO'
);


--
-- Name: estadoloteenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadoloteenum AS ENUM (
    'DISPONIBLE',
    'BLOQUEADO',
    'VENCIDO'
);


--
-- Name: estadooportunidad; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadooportunidad AS ENUM (
    'ABIERTA',
    'GANADA',
    'PERDIDA',
    'ESPERANDO_FIRMA',
    'ESPERANDO_FIRMA_MANUAL'
);


--
-- Name: estadoordenservicioenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadoordenservicioenum AS ENUM (
    'RECEPCIONADO',
    'EN_PROCESO',
    'LISTO_RETIRO',
    'ENTREGADO',
    'CANCELADO',
    'EN_ESPERA_STOCK',
    'RESERVADO'
);


--
-- Name: estadoventaenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estadoventaenum AS ENUM (
    'COMPLETADA',
    'PENDIENTE',
    'ANULADA',
    'PENDIENTE_SIN_STOCK'
);


--
-- Name: tipoactividad; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tipoactividad AS ENUM (
    'LLAMADA',
    'EMAIL',
    'REUNION',
    'NOTA'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clientes; Type: TABLE; Schema: crm; Owner: -
--

CREATE TABLE crm.clientes (
    id uuid NOT NULL,
    rut character varying NOT NULL,
    razon_social character varying NOT NULL,
    vendedor_id uuid,
    zona_id uuid,
    estado_comercial character varying,
    empresa_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: excepciones_credito; Type: TABLE; Schema: crm; Owner: -
--

CREATE TABLE crm.excepciones_credito (
    id uuid NOT NULL,
    cliente_rut character varying NOT NULL,
    monto_autorizado numeric(14,0) NOT NULL,
    monto_consumido numeric(14,0) NOT NULL,
    documento_respaldo_url character varying,
    autorizado_por uuid,
    fecha_expiracion timestamp with time zone,
    version integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: politicas_precio; Type: TABLE; Schema: crm; Owner: -
--

CREATE TABLE crm.politicas_precio (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    usuario_id uuid NOT NULL,
    factor numeric(5,4) NOT NULL,
    empresa_id uuid NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: precio_audit_log; Type: TABLE; Schema: crm; Owner: -
--

CREATE TABLE crm.precio_audit_log (
    id uuid NOT NULL,
    oportunidad_id uuid,
    producto_id uuid,
    precio_anterior numeric(14,2),
    precio_nuevo numeric(14,2),
    usuario_id uuid,
    "timestamp" timestamp with time zone DEFAULT now(),
    razon_cambio character varying
);


--
-- Name: activos_ti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activos_ti (
    id uuid NOT NULL,
    marca character varying NOT NULL,
    modelo character varying NOT NULL,
    numero_serie character varying NOT NULL,
    sucursal_id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: asientos_contables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asientos_contables (
    id uuid NOT NULL,
    numero integer,
    fecha timestamp with time zone NOT NULL,
    glosa character varying NOT NULL,
    origen character varying NOT NULL,
    origen_id character varying,
    tipo_documento character varying,
    folio_documento character varying,
    rut_tercero character varying,
    razon_social_tercero character varying,
    estado character varying,
    metodo_pago character varying,
    empresa_id uuid NOT NULL,
    sucursal_id uuid,
    usuario_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: asistencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asistencias (
    id uuid NOT NULL,
    empleado_id uuid NOT NULL,
    fecha date NOT NULL,
    entrada timestamp without time zone,
    salida timestamp without time zone,
    colacion_inicio timestamp without time zone,
    colacion_fin timestamp without time zone,
    horas_trabajadas numeric(5,2),
    horas_extras_calculadas numeric(5,2),
    comentario character varying,
    turno_planificado_id uuid
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    actor_id uuid,
    impersonated_user_id uuid,
    action character varying NOT NULL,
    resource character varying NOT NULL,
    severity character varying,
    changes json,
    ip_address character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: background_job_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.background_job_logs (
    id uuid NOT NULL,
    task_name character varying NOT NULL,
    status character varying NOT NULL,
    request_id character varying NOT NULL,
    duration_ms integer,
    error_code character varying,
    error_detail json,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: bodegas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bodegas (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    codigo character varying,
    sucursal_id uuid NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    updated_at timestamp with time zone
);


--
-- Name: business_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_audit_logs (
    id uuid NOT NULL,
    usuario_id uuid,
    accion character varying NOT NULL,
    modulo character varying NOT NULL,
    referencia_id character varying,
    cambios json,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: cierres_caja; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cierres_caja (
    id uuid NOT NULL,
    fecha_apertura timestamp with time zone NOT NULL,
    fecha_cierre timestamp with time zone,
    monto_inicial numeric(10,2) NOT NULL,
    ventas_totales_sistema numeric(10,2) NOT NULL,
    monto_real_fisico numeric(10,2),
    diferencia numeric(10,2),
    sucursal_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    empresa_id uuid NOT NULL
);


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    email character varying,
    telefono character varying,
    direccion character varying,
    rut character varying,
    empresa_id uuid NOT NULL,
    _limite_credito numeric(14,2),
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    giro character varying,
    ciudad character varying,
    condicion_pago character varying
);


--
-- Name: company_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_subscriptions (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: crm_actividades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_actividades (
    id uuid NOT NULL,
    tipo public.tipoactividad,
    resumen character varying NOT NULL,
    descripcion text,
    fecha_vencimiento timestamp with time zone,
    oportunidad_id uuid NOT NULL,
    usuario_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: crm_comentarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_comentarios (
    id uuid NOT NULL,
    oportunidad_id uuid NOT NULL,
    usuario_id uuid,
    comentario text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: crm_embudos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_embudos (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    descripcion character varying,
    is_active boolean,
    empresa_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: crm_etapas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_etapas (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    orden integer NOT NULL,
    probabilidad_exito integer NOT NULL,
    embudo_id uuid NOT NULL
);


--
-- Name: crm_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_notifications (
    id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    jefe_id uuid,
    mensaje character varying NOT NULL,
    link_documento character varying,
    leido boolean,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: crm_oportunidad_detalles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_oportunidad_detalles (
    id uuid NOT NULL,
    oportunidad_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario numeric(14,2) NOT NULL
);


--
-- Name: crm_oportunidades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_oportunidades (
    id uuid NOT NULL,
    titulo character varying NOT NULL,
    monto_estimado numeric(14,2) NOT NULL,
    moneda character varying NOT NULL,
    fecha_cierre timestamp with time zone,
    estado public.estadooportunidad,
    estado_credito public.estadocredito,
    cliente_id uuid,
    etapa_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    bodega_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    razon_perdida character varying
);


--
-- Name: cuentas_contables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cuentas_contables (
    id uuid NOT NULL,
    codigo character varying NOT NULL,
    nombre character varying NOT NULL,
    tipo_cuenta character varying NOT NULL,
    nivel integer NOT NULL,
    es_imputable boolean,
    padre_id uuid,
    empresa_id uuid NOT NULL
);


--
-- Name: detalles_venta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalles_venta (
    id uuid NOT NULL,
    venta_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    es_servicio boolean,
    cantidad_cancelada integer NOT NULL,
    sustituye_a_id uuid,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: documentos_tributarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentos_tributarios (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    tipo_dte integer NOT NULL,
    folio integer NOT NULL,
    fecha_emision date NOT NULL,
    fecha_vencimiento date,
    receptor_rut character varying(12),
    receptor_razon_social character varying(255),
    receptor_giro character varying(100),
    receptor_direccion character varying(255),
    receptor_comuna character varying(50),
    receptor_ciudad character varying(50),
    monto_neto numeric(12,2) NOT NULL,
    monto_exento numeric(12,2) NOT NULL,
    monto_iva numeric(12,2) NOT NULL,
    monto_total numeric(12,2) NOT NULL,
    referencia_tipo_dte integer,
    referencia_folio integer,
    referencia_fecha date,
    referencia_razon character varying(255),
    estado_sii character varying(20) NOT NULL,
    fecha_envio_sii timestamp without time zone,
    track_id_sii character varying(50),
    fecha_respuesta_sii timestamp without time zone,
    glosa_rechazo_sii text,
    xml_firmado text,
    pdf_cedible bytea,
    cliente_id uuid,
    venta_id uuid,
    usuario_emisor_id uuid,
    fecha_creacion timestamp with time zone,
    notas_internas text
);


--
-- Name: documentos_tributarios_detalles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentos_tributarios_detalles (
    id uuid NOT NULL,
    dte_id uuid NOT NULL,
    numero_linea integer NOT NULL,
    tipo_codigo character varying(10),
    codigo_item character varying(50),
    nombre_item character varying(250) NOT NULL,
    descripcion_item text,
    cantidad numeric(12,4) NOT NULL,
    unidad_medida character varying(10),
    precio_unitario numeric(12,2) NOT NULL,
    pct_descuento numeric(5,2),
    monto_descuento numeric(12,2),
    monto_item numeric(12,2) NOT NULL
);


--
-- Name: empleados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.empleados (
    id uuid NOT NULL,
    rut character varying NOT NULL,
    cargo character varying NOT NULL,
    fecha_ingreso date,
    especialidades json NOT NULL,
    tipo_contrato character varying,
    sueldo_base numeric(10,0),
    costo_hora numeric(10,2),
    estado_disponibilidad character varying,
    tipo_afp character varying,
    sistema_salud character varying,
    usuario_id uuid,
    empresa_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    updated_at timestamp with time zone,
    nombres character varying,
    apellidos character varying
);


--
-- Name: empresas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.empresas (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    rut character varying,
    codigo character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    is_active boolean NOT NULL,
    grace_period_days integer NOT NULL,
    limite_cupo_maximo numeric(14,2) NOT NULL,
    modulos_activos json NOT NULL,
    pwr_bi_enabled boolean,
    pwr_bi_config json,
    feature_flags json DEFAULT '{}'::json NOT NULL
);


--
-- Name: empresas_metodos_pago; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.empresas_metodos_pago (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    metodo_pago_id uuid NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: folios_sii; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folios_sii (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    tipo_dte integer NOT NULL,
    desde integer NOT NULL,
    hasta integer NOT NULL,
    fecha_autorizacion date NOT NULL,
    archivo_xml text NOT NULL,
    nombre_archivo character varying(255),
    estado character varying(20),
    ultimo_folio_usado integer,
    alerta_stock integer,
    usuario_carga_id uuid NOT NULL,
    fecha_carga timestamp with time zone
);


--
-- Name: gastos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gastos (
    id uuid NOT NULL,
    descripcion character varying NOT NULL,
    monto numeric(10,2) NOT NULL,
    fecha timestamp with time zone,
    categoria character varying NOT NULL,
    proveedor_id uuid,
    sucursal_id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    metodo_pago_id uuid NOT NULL,
    asiento_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    fecha_vencimiento timestamp with time zone,
    estado public.estadogastoenum NOT NULL,
    documento_referencia character varying
);


--
-- Name: historial_costos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historial_costos (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    costo_anterior numeric(14,4) NOT NULL,
    costo_nuevo numeric(14,4) NOT NULL,
    movimiento_id uuid,
    tipo_movimiento character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: historial_orden_servicio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historial_orden_servicio (
    id uuid NOT NULL,
    orden_servicio_id uuid NOT NULL,
    estado_anterior character varying,
    estado_nuevo character varying NOT NULL,
    fecha_cambio timestamp without time zone NOT NULL,
    usuario_id uuid NOT NULL,
    observacion character varying
);


--
-- Name: insumos_receta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.insumos_receta (
    id uuid NOT NULL,
    receta_id uuid NOT NULL,
    producto_insumo_id uuid NOT NULL,
    cantidad numeric(10,4) NOT NULL
);


--
-- Name: inventario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventario (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    bodega_id uuid NOT NULL,
    cantidad integer NOT NULL,
    cantidad_reservada integer NOT NULL,
    stock_minimo integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: inventario_lotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventario_lotes (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    bodega_id uuid NOT NULL,
    lote_codigo character varying NOT NULL,
    fecha_entrada timestamp with time zone DEFAULT now() NOT NULL,
    fecha_vencimiento timestamp with time zone,
    cantidad integer NOT NULL,
    estado public.estadoloteenum NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: inventario_ubicacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventario_ubicacion (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    ubicacion_id uuid NOT NULL,
    cantidad integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: job_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_orders (
    id uuid NOT NULL,
    description character varying,
    empresa_id uuid NOT NULL,
    sucursal_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: legal_documentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.legal_documentos (
    id uuid NOT NULL,
    oportunidad_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    fecha_creacion timestamp with time zone DEFAULT now() NOT NULL,
    fecha_firma timestamp with time zone,
    ruta_archivo character varying NOT NULL,
    ruta_archivo_firmado character varying,
    hash_integridad character varying,
    estado public.estadodocumento NOT NULL,
    info_firma json
);


--
-- Name: liquidaciones_sueldo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liquidaciones_sueldo (
    id uuid NOT NULL,
    empleado_id uuid NOT NULL,
    mes integer NOT NULL,
    anio integer NOT NULL,
    fecha_emision date,
    sueldo_base numeric(10,0),
    gratificacion_legal numeric(10,0),
    horas_extras_monto numeric(10,0),
    bonos_imponibles numeric(10,0),
    movilizacion numeric(10,0),
    colacion numeric(10,0),
    otros_no_imponibles numeric(10,0),
    total_haberes numeric(10,0),
    total_imponible numeric(10,0),
    afp_monto numeric(10,0),
    salud_monto numeric(10,0),
    seguro_cesantia numeric(10,0),
    impuesto_unico numeric(10,0),
    total_descuentos numeric(10,0),
    sueldo_liquido numeric(10,0),
    estado character varying,
    asiento_contable_id uuid
);


--
-- Name: metodos_pago; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metodos_pago (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    codigo character varying NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: movimientos_contables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.movimientos_contables (
    id uuid NOT NULL,
    asiento_id uuid NOT NULL,
    cuenta_id uuid NOT NULL,
    debe numeric(14,2) NOT NULL,
    haber numeric(14,2) NOT NULL,
    sucursal_id uuid
);


--
-- Name: movimientos_stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.movimientos_stock (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    bodega_id uuid NOT NULL,
    cantidad integer NOT NULL,
    tipo character varying NOT NULL,
    fecha timestamp without time zone NOT NULL,
    empresa_id uuid NOT NULL,
    costo_unitario numeric(14,4),
    lote_id uuid
);


--
-- Name: orden_compra_detalles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orden_compra_detalles (
    id uuid NOT NULL,
    orden_compra_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL
);


--
-- Name: ordenes_compra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordenes_compra (
    id uuid NOT NULL,
    folio character varying,
    fecha_emision timestamp with time zone NOT NULL,
    fecha_recepcion timestamp with time zone,
    estado character varying,
    total_neto numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    proveedor_id uuid NOT NULL,
    sucursal_id uuid NOT NULL,
    bodega_id uuid,
    empresa_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: ordenes_servicio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordenes_servicio (
    id uuid NOT NULL,
    venta_id uuid NOT NULL,
    fecha_recepcion timestamp without time zone NOT NULL,
    fecha_entrega_prometida timestamp without time zone,
    fecha_entrega_real timestamp without time zone,
    estado public.estadoordenservicioenum NOT NULL,
    observaciones_custodia text,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: papelera_reciclaje; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.papelera_reciclaje (
    id uuid NOT NULL,
    tabla_origen character varying NOT NULL,
    empresa_id uuid,
    company_code character varying,
    ejecutado_por_id uuid,
    payload json NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: parametros_globales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parametros_globales (
    id uuid NOT NULL,
    empresa_id uuid,
    llave character varying NOT NULL,
    valor character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: payment_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_receipts (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    amount_clp integer NOT NULL,
    paid_at timestamp with time zone DEFAULT now(),
    new_expires_at timestamp with time zone NOT NULL
);


--
-- Name: periodos_contables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periodos_contables (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    nombre character varying NOT NULL,
    fecha_inicio timestamp with time zone NOT NULL,
    fecha_fin timestamp with time zone NOT NULL,
    cerrado boolean NOT NULL,
    fecha_cierre timestamp with time zone,
    usuario_cierre_id uuid
);


--
-- Name: precios_productos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.precios_productos (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    sucursal_id uuid,
    tipo_cliente character varying,
    precio numeric(10,2) NOT NULL,
    empresa_id uuid NOT NULL
);


--
-- Name: producto_certificaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.producto_certificaciones (
    id uuid NOT NULL,
    producto_id uuid NOT NULL,
    numero_resolucion character varying NOT NULL,
    fecha_emision date NOT NULL,
    fecha_vencimiento date NOT NULL,
    organismo_certificador character varying NOT NULL,
    documento_url character varying,
    is_link_active boolean,
    last_link_check timestamp without time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: productos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productos (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    sku character varying NOT NULL,
    precio numeric(10,2) NOT NULL,
    tipo_producto character varying NOT NULL,
    is_active boolean,
    empresa_id uuid NOT NULL,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    descripcion text,
    costo_promedio numeric(14,4) DEFAULT 0 NOT NULL,
    es_trazable boolean DEFAULT false NOT NULL
);


--
-- Name: proveedores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proveedores (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    razon_social character varying,
    rut character varying,
    giro character varying,
    telefono character varying,
    email character varying,
    direccion character varying,
    plazo_pago_dias integer,
    empresa_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: recepciones_dra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recepciones_dra (
    id uuid NOT NULL,
    folio_documento character varying NOT NULL,
    estado public.estadodraenum NOT NULL,
    proveedor_id uuid NOT NULL,
    orden_compra_id uuid,
    empresa_id uuid NOT NULL,
    sucursal_id uuid NOT NULL,
    bodega_id uuid NOT NULL,
    fecha_creacion timestamp with time zone DEFAULT now() NOT NULL,
    fecha_posteo timestamp with time zone,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: recepciones_dra_lineas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recepciones_dra_lineas (
    id uuid NOT NULL,
    dra_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    cantidad_recibida integer NOT NULL,
    cantidad_aceptada integer NOT NULL,
    cantidad_rechazada integer NOT NULL,
    codigo_disposicion public.codigodisposiciondraenum NOT NULL,
    glosa_rechazo character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ck_dra_cantidades_balance CHECK (((cantidad_aceptada + cantidad_rechazada) = cantidad_recibida))
);


--
-- Name: recetas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recetas (
    id uuid NOT NULL,
    producto_final_id uuid NOT NULL,
    nombre character varying
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    codigo character varying NOT NULL,
    nombre character varying NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: service_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_orders (
    id uuid NOT NULL,
    job_order_id uuid,
    workflow_id uuid,
    estado character varying,
    metadata jsonb,
    total_estimado integer,
    neto integer,
    iva integer,
    empresa_id uuid NOT NULL,
    sucursal_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    venta_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: service_status_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_status_config (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    states jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: service_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_workflows (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description character varying,
    config jsonb,
    empresa_id uuid
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key character varying NOT NULL,
    value jsonb NOT NULL,
    type character varying NOT NULL,
    description text
);


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid NOT NULL,
    name character varying NOT NULL,
    price_clp integer NOT NULL,
    user_limit integer NOT NULL,
    branch_limit integer NOT NULL,
    is_active boolean
);


--
-- Name: sucursales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sucursales (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    codigo character varying,
    direccion character varying,
    empresa_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: system_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_secrets (
    key character varying NOT NULL,
    encrypted_value character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid
);


--
-- Name: table_crm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_crm (
    id uuid NOT NULL,
    nombre character varying,
    descripcion character varying,
    empresa_id uuid NOT NULL
);


--
-- Name: tipos_turno; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tipos_turno (
    id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    nombre character varying NOT NULL,
    hora_inicio character varying NOT NULL,
    hora_fin character varying NOT NULL,
    color_hex character varying
);


--
-- Name: turnos_planificados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.turnos_planificados (
    id uuid NOT NULL,
    empleado_id uuid NOT NULL,
    tipo_turno_id uuid NOT NULL,
    fecha date NOT NULL
);


--
-- Name: ubicaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ubicaciones (
    id uuid NOT NULL,
    nombre character varying NOT NULL,
    zona character varying NOT NULL,
    pasillo character varying,
    nivel character varying,
    capacidad_maxima integer,
    bodega_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id uuid NOT NULL,
    email character varying NOT NULL,
    hashed_password character varying NOT NULL,
    is_active boolean,
    role character varying,
    supervisor_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    updated_at timestamp with time zone,
    mfa_enabled boolean,
    mfa_secret character varying,
    mfa_recovery_codes json,
    mfa_enforced boolean
);


--
-- Name: usuarios_empresas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios_empresas (
    usuario_id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    rol_id uuid,
    is_default boolean
);


--
-- Name: ventas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ventas (
    id uuid NOT NULL,
    fecha timestamp without time zone NOT NULL,
    folio character varying,
    total numeric(10,2) NOT NULL,
    moneda character varying NOT NULL,
    tipo_cambio numeric(10,2) NOT NULL,
    estado public.estadoventaenum NOT NULL,
    cliente_id uuid NOT NULL,
    sucursal_id uuid NOT NULL,
    vendedor_id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    cierre_caja_id uuid,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    observaciones text
);


--
-- Name: webhooks_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_config (
    id uuid NOT NULL,
    event_name character varying NOT NULL,
    url character varying NOT NULL,
    secret_key character varying,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: excepciones_credito excepciones_credito_pkey; Type: CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.excepciones_credito
    ADD CONSTRAINT excepciones_credito_pkey PRIMARY KEY (id);


--
-- Name: politicas_precio politicas_precio_pkey; Type: CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.politicas_precio
    ADD CONSTRAINT politicas_precio_pkey PRIMARY KEY (id);


--
-- Name: precio_audit_log precio_audit_log_pkey; Type: CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.precio_audit_log
    ADD CONSTRAINT precio_audit_log_pkey PRIMARY KEY (id);


--
-- Name: activos_ti activos_ti_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activos_ti
    ADD CONSTRAINT activos_ti_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: asientos_contables asientos_contables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asientos_contables
    ADD CONSTRAINT asientos_contables_pkey PRIMARY KEY (id);


--
-- Name: asistencias asistencias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: background_job_logs background_job_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.background_job_logs
    ADD CONSTRAINT background_job_logs_pkey PRIMARY KEY (id);


--
-- Name: bodegas bodegas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodegas
    ADD CONSTRAINT bodegas_pkey PRIMARY KEY (id);


--
-- Name: business_audit_logs business_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_audit_logs
    ADD CONSTRAINT business_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: cierres_caja cierres_caja_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cierres_caja
    ADD CONSTRAINT cierres_caja_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: company_subscriptions company_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_subscriptions
    ADD CONSTRAINT company_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: crm_actividades crm_actividades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_actividades
    ADD CONSTRAINT crm_actividades_pkey PRIMARY KEY (id);


--
-- Name: crm_comentarios crm_comentarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_comentarios
    ADD CONSTRAINT crm_comentarios_pkey PRIMARY KEY (id);


--
-- Name: crm_embudos crm_embudos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_embudos
    ADD CONSTRAINT crm_embudos_pkey PRIMARY KEY (id);


--
-- Name: crm_etapas crm_etapas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_etapas
    ADD CONSTRAINT crm_etapas_pkey PRIMARY KEY (id);


--
-- Name: crm_notifications crm_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_notifications
    ADD CONSTRAINT crm_notifications_pkey PRIMARY KEY (id);


--
-- Name: crm_oportunidad_detalles crm_oportunidad_detalles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidad_detalles
    ADD CONSTRAINT crm_oportunidad_detalles_pkey PRIMARY KEY (id);


--
-- Name: crm_oportunidades crm_oportunidades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidades
    ADD CONSTRAINT crm_oportunidades_pkey PRIMARY KEY (id);


--
-- Name: cuentas_contables cuentas_contables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cuentas_contables
    ADD CONSTRAINT cuentas_contables_pkey PRIMARY KEY (id);


--
-- Name: detalles_venta detalles_venta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_venta
    ADD CONSTRAINT detalles_venta_pkey PRIMARY KEY (id);


--
-- Name: documentos_tributarios_detalles documentos_tributarios_detalles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios_detalles
    ADD CONSTRAINT documentos_tributarios_detalles_pkey PRIMARY KEY (id);


--
-- Name: documentos_tributarios documentos_tributarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios
    ADD CONSTRAINT documentos_tributarios_pkey PRIMARY KEY (id);


--
-- Name: empleados empleados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empleados
    ADD CONSTRAINT empleados_pkey PRIMARY KEY (id);


--
-- Name: empresas_metodos_pago empresas_metodos_pago_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empresas_metodos_pago
    ADD CONSTRAINT empresas_metodos_pago_pkey PRIMARY KEY (id);


--
-- Name: empresas empresas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: folios_sii folios_sii_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folios_sii
    ADD CONSTRAINT folios_sii_pkey PRIMARY KEY (id);


--
-- Name: gastos gastos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_pkey PRIMARY KEY (id);


--
-- Name: historial_costos historial_costos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historial_costos
    ADD CONSTRAINT historial_costos_pkey PRIMARY KEY (id);


--
-- Name: historial_orden_servicio historial_orden_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historial_orden_servicio
    ADD CONSTRAINT historial_orden_servicio_pkey PRIMARY KEY (id);


--
-- Name: insumos_receta insumos_receta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insumos_receta
    ADD CONSTRAINT insumos_receta_pkey PRIMARY KEY (id);


--
-- Name: inventario_lotes inventario_lotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario_lotes
    ADD CONSTRAINT inventario_lotes_pkey PRIMARY KEY (id);


--
-- Name: inventario inventario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_pkey PRIMARY KEY (id);


--
-- Name: inventario_ubicacion inventario_ubicacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario_ubicacion
    ADD CONSTRAINT inventario_ubicacion_pkey PRIMARY KEY (id);


--
-- Name: job_orders job_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_orders
    ADD CONSTRAINT job_orders_pkey PRIMARY KEY (id);


--
-- Name: legal_documentos legal_documentos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_documentos
    ADD CONSTRAINT legal_documentos_pkey PRIMARY KEY (id);


--
-- Name: liquidaciones_sueldo liquidaciones_sueldo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones_sueldo
    ADD CONSTRAINT liquidaciones_sueldo_pkey PRIMARY KEY (id);


--
-- Name: metodos_pago metodos_pago_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metodos_pago
    ADD CONSTRAINT metodos_pago_pkey PRIMARY KEY (id);


--
-- Name: movimientos_contables movimientos_contables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_contables
    ADD CONSTRAINT movimientos_contables_pkey PRIMARY KEY (id);


--
-- Name: movimientos_stock movimientos_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_pkey PRIMARY KEY (id);


--
-- Name: orden_compra_detalles orden_compra_detalles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orden_compra_detalles
    ADD CONSTRAINT orden_compra_detalles_pkey PRIMARY KEY (id);


--
-- Name: ordenes_compra ordenes_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_compra
    ADD CONSTRAINT ordenes_compra_pkey PRIMARY KEY (id);


--
-- Name: ordenes_servicio ordenes_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_pkey PRIMARY KEY (id);


--
-- Name: papelera_reciclaje papelera_reciclaje_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.papelera_reciclaje
    ADD CONSTRAINT papelera_reciclaje_pkey PRIMARY KEY (id);


--
-- Name: parametros_globales parametros_globales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametros_globales
    ADD CONSTRAINT parametros_globales_pkey PRIMARY KEY (id);


--
-- Name: payment_receipts payment_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_pkey PRIMARY KEY (id);


--
-- Name: periodos_contables periodos_contables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodos_contables
    ADD CONSTRAINT periodos_contables_pkey PRIMARY KEY (id);


--
-- Name: precios_productos precios_productos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.precios_productos
    ADD CONSTRAINT precios_productos_pkey PRIMARY KEY (id);


--
-- Name: producto_certificaciones producto_certificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.producto_certificaciones
    ADD CONSTRAINT producto_certificaciones_pkey PRIMARY KEY (id);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);


--
-- Name: recepciones_dra_lineas recepciones_dra_lineas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra_lineas
    ADD CONSTRAINT recepciones_dra_lineas_pkey PRIMARY KEY (id);


--
-- Name: recepciones_dra recepciones_dra_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra
    ADD CONSTRAINT recepciones_dra_pkey PRIMARY KEY (id);


--
-- Name: recetas recetas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recetas
    ADD CONSTRAINT recetas_pkey PRIMARY KEY (id);


--
-- Name: recetas recetas_producto_final_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recetas
    ADD CONSTRAINT recetas_producto_final_id_key UNIQUE (producto_final_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: service_orders service_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_pkey PRIMARY KEY (id);


--
-- Name: service_status_config service_status_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_status_config
    ADD CONSTRAINT service_status_config_pkey PRIMARY KEY (id);


--
-- Name: service_workflows service_workflows_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_workflows
    ADD CONSTRAINT service_workflows_name_key UNIQUE (name);


--
-- Name: service_workflows service_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_workflows
    ADD CONSTRAINT service_workflows_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: subscription_plans subscription_plans_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_name_key UNIQUE (name);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: sucursales sucursales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sucursales
    ADD CONSTRAINT sucursales_pkey PRIMARY KEY (id);


--
-- Name: system_secrets system_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_secrets
    ADD CONSTRAINT system_secrets_pkey PRIMARY KEY (key);


--
-- Name: table_crm table_crm_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_crm
    ADD CONSTRAINT table_crm_pkey PRIMARY KEY (id);


--
-- Name: tipos_turno tipos_turno_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipos_turno
    ADD CONSTRAINT tipos_turno_pkey PRIMARY KEY (id);


--
-- Name: turnos_planificados turnos_planificados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turnos_planificados
    ADD CONSTRAINT turnos_planificados_pkey PRIMARY KEY (id);


--
-- Name: ubicaciones ubicaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ubicaciones
    ADD CONSTRAINT ubicaciones_pkey PRIMARY KEY (id);


--
-- Name: documentos_tributarios uq_dte_empresa_tipo_folio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios
    ADD CONSTRAINT uq_dte_empresa_tipo_folio UNIQUE (empresa_id, tipo_dte, folio);


--
-- Name: productos uq_producto_sku_empresa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT uq_producto_sku_empresa UNIQUE (sku, empresa_id);


--
-- Name: usuarios_empresas usuarios_empresas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_empresas
    ADD CONSTRAINT usuarios_empresas_pkey PRIMARY KEY (usuario_id, empresa_id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: ventas ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_pkey PRIMARY KEY (id);


--
-- Name: webhooks_config webhooks_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_config
    ADD CONSTRAINT webhooks_config_pkey PRIMARY KEY (id);


--
-- Name: ix_crm_clientes_empresa_id; Type: INDEX; Schema: crm; Owner: -
--

CREATE INDEX ix_crm_clientes_empresa_id ON crm.clientes USING btree (empresa_id);


--
-- Name: ix_crm_clientes_rut; Type: INDEX; Schema: crm; Owner: -
--

CREATE UNIQUE INDEX ix_crm_clientes_rut ON crm.clientes USING btree (rut);


--
-- Name: ix_crm_excepciones_credito_cliente_rut; Type: INDEX; Schema: crm; Owner: -
--

CREATE INDEX ix_crm_excepciones_credito_cliente_rut ON crm.excepciones_credito USING btree (cliente_rut);


--
-- Name: ix_crm_politicas_precio_empresa_id; Type: INDEX; Schema: crm; Owner: -
--

CREATE INDEX ix_crm_politicas_precio_empresa_id ON crm.politicas_precio USING btree (empresa_id);


--
-- Name: ix_crm_politicas_precio_usuario_id; Type: INDEX; Schema: crm; Owner: -
--

CREATE INDEX ix_crm_politicas_precio_usuario_id ON crm.politicas_precio USING btree (usuario_id);


--
-- Name: ix_activos_ti_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activos_ti_empresa_id ON public.activos_ti USING btree (empresa_id);


--
-- Name: ix_activos_ti_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activos_ti_id ON public.activos_ti USING btree (id);


--
-- Name: ix_activos_ti_numero_serie; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_activos_ti_numero_serie ON public.activos_ti USING btree (numero_serie);


--
-- Name: ix_activos_ti_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activos_ti_sucursal_id ON public.activos_ti USING btree (sucursal_id);


--
-- Name: ix_asientos_contables_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asientos_contables_empresa_id ON public.asientos_contables USING btree (empresa_id);


--
-- Name: ix_asientos_contables_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asientos_contables_id ON public.asientos_contables USING btree (id);


--
-- Name: ix_asientos_contables_numero; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asientos_contables_numero ON public.asientos_contables USING btree (numero);


--
-- Name: ix_asientos_contables_rut_tercero; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asientos_contables_rut_tercero ON public.asientos_contables USING btree (rut_tercero);


--
-- Name: ix_asientos_contables_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asientos_contables_sucursal_id ON public.asientos_contables USING btree (sucursal_id);


--
-- Name: ix_asistencias_empleado_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asistencias_empleado_id ON public.asistencias USING btree (empleado_id);


--
-- Name: ix_asistencias_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asistencias_fecha ON public.asistencias USING btree (fecha);


--
-- Name: ix_asistencias_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asistencias_id ON public.asistencias USING btree (id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_actor_id ON public.audit_logs USING btree (actor_id);


--
-- Name: ix_audit_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_id ON public.audit_logs USING btree (id);


--
-- Name: ix_audit_logs_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_severity ON public.audit_logs USING btree (severity);


--
-- Name: ix_background_job_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_background_job_logs_created_at ON public.background_job_logs USING btree (created_at);


--
-- Name: ix_background_job_logs_error_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_background_job_logs_error_code ON public.background_job_logs USING btree (error_code);


--
-- Name: ix_background_job_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_background_job_logs_id ON public.background_job_logs USING btree (id);


--
-- Name: ix_background_job_logs_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_background_job_logs_request_id ON public.background_job_logs USING btree (request_id);


--
-- Name: ix_background_job_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_background_job_logs_status ON public.background_job_logs USING btree (status);


--
-- Name: ix_background_job_logs_task_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_background_job_logs_task_name ON public.background_job_logs USING btree (task_name);


--
-- Name: ix_bodegas_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bodegas_codigo ON public.bodegas USING btree (codigo);


--
-- Name: ix_bodegas_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bodegas_id ON public.bodegas USING btree (id);


--
-- Name: ix_bodegas_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bodegas_is_deleted ON public.bodegas USING btree (is_deleted);


--
-- Name: ix_bodegas_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bodegas_nombre ON public.bodegas USING btree (nombre);


--
-- Name: ix_bodegas_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bodegas_sucursal_id ON public.bodegas USING btree (sucursal_id);


--
-- Name: ix_business_audit_logs_accion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_audit_logs_accion ON public.business_audit_logs USING btree (accion);


--
-- Name: ix_business_audit_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_audit_logs_id ON public.business_audit_logs USING btree (id);


--
-- Name: ix_business_audit_logs_modulo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_audit_logs_modulo ON public.business_audit_logs USING btree (modulo);


--
-- Name: ix_business_audit_logs_referencia_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_audit_logs_referencia_id ON public.business_audit_logs USING btree (referencia_id);


--
-- Name: ix_business_audit_logs_usuario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_audit_logs_usuario_id ON public.business_audit_logs USING btree (usuario_id);


--
-- Name: ix_cierres_caja_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cierres_caja_empresa_id ON public.cierres_caja USING btree (empresa_id);


--
-- Name: ix_cierres_caja_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cierres_caja_id ON public.cierres_caja USING btree (id);


--
-- Name: ix_cierres_caja_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cierres_caja_sucursal_id ON public.cierres_caja USING btree (sucursal_id);


--
-- Name: ix_cierres_caja_usuario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cierres_caja_usuario_id ON public.cierres_caja USING btree (usuario_id);


--
-- Name: ix_clientes_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clientes_email ON public.clientes USING btree (email);


--
-- Name: ix_clientes_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clientes_empresa_id ON public.clientes USING btree (empresa_id);


--
-- Name: ix_clientes_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clientes_id ON public.clientes USING btree (id);


--
-- Name: ix_clientes_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clientes_is_deleted ON public.clientes USING btree (is_deleted);


--
-- Name: ix_clientes_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clientes_nombre ON public.clientes USING btree (nombre);


--
-- Name: ix_clientes_rut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clientes_rut ON public.clientes USING btree (rut);


--
-- Name: ix_company_subscriptions_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_subscriptions_empresa_id ON public.company_subscriptions USING btree (empresa_id);


--
-- Name: ix_company_subscriptions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_subscriptions_id ON public.company_subscriptions USING btree (id);


--
-- Name: ix_crm_actividades_oportunidad_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_actividades_oportunidad_id ON public.crm_actividades USING btree (oportunidad_id);


--
-- Name: ix_crm_comentarios_oportunidad_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_comentarios_oportunidad_id ON public.crm_comentarios USING btree (oportunidad_id);


--
-- Name: ix_crm_embudos_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_embudos_empresa_id ON public.crm_embudos USING btree (empresa_id);


--
-- Name: ix_crm_embudos_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_embudos_id ON public.crm_embudos USING btree (id);


--
-- Name: ix_crm_etapas_embudo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_etapas_embudo_id ON public.crm_etapas USING btree (embudo_id);


--
-- Name: ix_crm_etapas_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_etapas_id ON public.crm_etapas USING btree (id);


--
-- Name: ix_crm_notifications_usuario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_notifications_usuario_id ON public.crm_notifications USING btree (usuario_id);


--
-- Name: ix_crm_oportunidad_detalles_oportunidad_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidad_detalles_oportunidad_id ON public.crm_oportunidad_detalles USING btree (oportunidad_id);


--
-- Name: ix_crm_oportunidades_cliente_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidades_cliente_id ON public.crm_oportunidades USING btree (cliente_id);


--
-- Name: ix_crm_oportunidades_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidades_empresa_id ON public.crm_oportunidades USING btree (empresa_id);


--
-- Name: ix_crm_oportunidades_etapa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidades_etapa_id ON public.crm_oportunidades USING btree (etapa_id);


--
-- Name: ix_crm_oportunidades_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidades_id ON public.crm_oportunidades USING btree (id);


--
-- Name: ix_crm_oportunidades_titulo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidades_titulo ON public.crm_oportunidades USING btree (titulo);


--
-- Name: ix_crm_oportunidades_usuario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crm_oportunidades_usuario_id ON public.crm_oportunidades USING btree (usuario_id);


--
-- Name: ix_cuentas_contables_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cuentas_contables_codigo ON public.cuentas_contables USING btree (codigo);


--
-- Name: ix_cuentas_contables_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cuentas_contables_empresa_id ON public.cuentas_contables USING btree (empresa_id);


--
-- Name: ix_cuentas_contables_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cuentas_contables_id ON public.cuentas_contables USING btree (id);


--
-- Name: ix_detalles_venta_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_detalles_venta_id ON public.detalles_venta USING btree (id);


--
-- Name: ix_detalles_venta_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_detalles_venta_is_deleted ON public.detalles_venta USING btree (is_deleted);


--
-- Name: ix_detalles_venta_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_detalles_venta_producto_id ON public.detalles_venta USING btree (producto_id);


--
-- Name: ix_detalles_venta_venta_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_detalles_venta_venta_id ON public.detalles_venta USING btree (venta_id);


--
-- Name: ix_documentos_tributarios_detalles_dte_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_detalles_dte_id ON public.documentos_tributarios_detalles USING btree (dte_id);


--
-- Name: ix_documentos_tributarios_detalles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_detalles_id ON public.documentos_tributarios_detalles USING btree (id);


--
-- Name: ix_documentos_tributarios_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_empresa_id ON public.documentos_tributarios USING btree (empresa_id);


--
-- Name: ix_documentos_tributarios_folio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_folio ON public.documentos_tributarios USING btree (folio);


--
-- Name: ix_documentos_tributarios_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_id ON public.documentos_tributarios USING btree (id);


--
-- Name: ix_documentos_tributarios_receptor_rut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_receptor_rut ON public.documentos_tributarios USING btree (receptor_rut);


--
-- Name: ix_documentos_tributarios_tipo_dte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documentos_tributarios_tipo_dte ON public.documentos_tributarios USING btree (tipo_dte);


--
-- Name: ix_empleados_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empleados_empresa_id ON public.empleados USING btree (empresa_id);


--
-- Name: ix_empleados_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empleados_id ON public.empleados USING btree (id);


--
-- Name: ix_empleados_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empleados_is_deleted ON public.empleados USING btree (is_deleted);


--
-- Name: ix_empleados_rut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empleados_rut ON public.empleados USING btree (rut);


--
-- Name: ix_empresas_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_empresas_codigo ON public.empresas USING btree (codigo);


--
-- Name: ix_empresas_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empresas_id ON public.empresas USING btree (id);


--
-- Name: ix_empresas_metodos_pago_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empresas_metodos_pago_id ON public.empresas_metodos_pago USING btree (id);


--
-- Name: ix_empresas_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_empresas_nombre ON public.empresas USING btree (nombre);


--
-- Name: ix_empresas_rut; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_empresas_rut ON public.empresas USING btree (rut);


--
-- Name: ix_folio_empresa_tipo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_folio_empresa_tipo ON public.folios_sii USING btree (empresa_id, tipo_dte);


--
-- Name: ix_folios_sii_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_folios_sii_empresa_id ON public.folios_sii USING btree (empresa_id);


--
-- Name: ix_folios_sii_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_folios_sii_id ON public.folios_sii USING btree (id);


--
-- Name: ix_gastos_asiento_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_asiento_id ON public.gastos USING btree (asiento_id);


--
-- Name: ix_gastos_categoria; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_categoria ON public.gastos USING btree (categoria);


--
-- Name: ix_gastos_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_empresa_id ON public.gastos USING btree (empresa_id);


--
-- Name: ix_gastos_estado; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_estado ON public.gastos USING btree (estado);


--
-- Name: ix_gastos_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_id ON public.gastos USING btree (id);


--
-- Name: ix_gastos_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_is_deleted ON public.gastos USING btree (is_deleted);


--
-- Name: ix_gastos_metodo_pago_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_metodo_pago_id ON public.gastos USING btree (metodo_pago_id);


--
-- Name: ix_gastos_proveedor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_proveedor_id ON public.gastos USING btree (proveedor_id);


--
-- Name: ix_gastos_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gastos_sucursal_id ON public.gastos USING btree (sucursal_id);


--
-- Name: ix_historial_costos_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historial_costos_id ON public.historial_costos USING btree (id);


--
-- Name: ix_historial_costos_movimiento_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historial_costos_movimiento_id ON public.historial_costos USING btree (movimiento_id);


--
-- Name: ix_historial_costos_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historial_costos_producto_id ON public.historial_costos USING btree (producto_id);


--
-- Name: ix_historial_orden_servicio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historial_orden_servicio_id ON public.historial_orden_servicio USING btree (id);


--
-- Name: ix_historial_orden_servicio_orden_servicio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_historial_orden_servicio_orden_servicio_id ON public.historial_orden_servicio USING btree (orden_servicio_id);


--
-- Name: ix_insumos_receta_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_insumos_receta_id ON public.insumos_receta USING btree (id);


--
-- Name: ix_insumos_receta_producto_insumo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_insumos_receta_producto_insumo_id ON public.insumos_receta USING btree (producto_insumo_id);


--
-- Name: ix_insumos_receta_receta_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_insumos_receta_receta_id ON public.insumos_receta USING btree (receta_id);


--
-- Name: ix_inventario_bodega_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_bodega_id ON public.inventario USING btree (bodega_id);


--
-- Name: ix_inventario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_id ON public.inventario USING btree (id);


--
-- Name: ix_inventario_lotes_bodega_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_lotes_bodega_id ON public.inventario_lotes USING btree (bodega_id);


--
-- Name: ix_inventario_lotes_fecha_vencimiento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_lotes_fecha_vencimiento ON public.inventario_lotes USING btree (fecha_vencimiento);


--
-- Name: ix_inventario_lotes_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_lotes_id ON public.inventario_lotes USING btree (id);


--
-- Name: ix_inventario_lotes_lote_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_lotes_lote_codigo ON public.inventario_lotes USING btree (lote_codigo);


--
-- Name: ix_inventario_lotes_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_lotes_producto_id ON public.inventario_lotes USING btree (producto_id);


--
-- Name: ix_inventario_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_producto_id ON public.inventario USING btree (producto_id);


--
-- Name: ix_inventario_ubicacion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_ubicacion_id ON public.inventario_ubicacion USING btree (id);


--
-- Name: ix_inventario_ubicacion_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_ubicacion_producto_id ON public.inventario_ubicacion USING btree (producto_id);


--
-- Name: ix_inventario_ubicacion_ubicacion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventario_ubicacion_ubicacion_id ON public.inventario_ubicacion USING btree (ubicacion_id);


--
-- Name: ix_job_orders_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_job_orders_id ON public.job_orders USING btree (id);


--
-- Name: ix_liquidaciones_sueldo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_liquidaciones_sueldo_id ON public.liquidaciones_sueldo USING btree (id);


--
-- Name: ix_metodos_pago_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_metodos_pago_codigo ON public.metodos_pago USING btree (codigo);


--
-- Name: ix_metodos_pago_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_metodos_pago_id ON public.metodos_pago USING btree (id);


--
-- Name: ix_metodos_pago_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_metodos_pago_nombre ON public.metodos_pago USING btree (nombre);


--
-- Name: ix_movimientos_contables_asiento_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_contables_asiento_id ON public.movimientos_contables USING btree (asiento_id);


--
-- Name: ix_movimientos_contables_cuenta_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_contables_cuenta_id ON public.movimientos_contables USING btree (cuenta_id);


--
-- Name: ix_movimientos_contables_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_contables_id ON public.movimientos_contables USING btree (id);


--
-- Name: ix_movimientos_contables_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_contables_sucursal_id ON public.movimientos_contables USING btree (sucursal_id);


--
-- Name: ix_movimientos_stock_bodega_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_stock_bodega_id ON public.movimientos_stock USING btree (bodega_id);


--
-- Name: ix_movimientos_stock_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_stock_empresa_id ON public.movimientos_stock USING btree (empresa_id);


--
-- Name: ix_movimientos_stock_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_stock_id ON public.movimientos_stock USING btree (id);


--
-- Name: ix_movimientos_stock_lote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_stock_lote_id ON public.movimientos_stock USING btree (lote_id);


--
-- Name: ix_movimientos_stock_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_movimientos_stock_producto_id ON public.movimientos_stock USING btree (producto_id);


--
-- Name: ix_orden_compra_detalles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orden_compra_detalles_id ON public.orden_compra_detalles USING btree (id);


--
-- Name: ix_orden_compra_detalles_orden_compra_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orden_compra_detalles_orden_compra_id ON public.orden_compra_detalles USING btree (orden_compra_id);


--
-- Name: ix_orden_compra_detalles_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orden_compra_detalles_producto_id ON public.orden_compra_detalles USING btree (producto_id);


--
-- Name: ix_ordenes_compra_bodega_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_bodega_id ON public.ordenes_compra USING btree (bodega_id);


--
-- Name: ix_ordenes_compra_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_empresa_id ON public.ordenes_compra USING btree (empresa_id);


--
-- Name: ix_ordenes_compra_estado; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_estado ON public.ordenes_compra USING btree (estado);


--
-- Name: ix_ordenes_compra_folio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_folio ON public.ordenes_compra USING btree (folio);


--
-- Name: ix_ordenes_compra_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_id ON public.ordenes_compra USING btree (id);


--
-- Name: ix_ordenes_compra_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_is_deleted ON public.ordenes_compra USING btree (is_deleted);


--
-- Name: ix_ordenes_compra_proveedor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_proveedor_id ON public.ordenes_compra USING btree (proveedor_id);


--
-- Name: ix_ordenes_compra_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_sucursal_id ON public.ordenes_compra USING btree (sucursal_id);


--
-- Name: ix_ordenes_compra_usuario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_compra_usuario_id ON public.ordenes_compra USING btree (usuario_id);


--
-- Name: ix_ordenes_servicio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_servicio_id ON public.ordenes_servicio USING btree (id);


--
-- Name: ix_ordenes_servicio_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ordenes_servicio_is_deleted ON public.ordenes_servicio USING btree (is_deleted);


--
-- Name: ix_ordenes_servicio_venta_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ordenes_servicio_venta_id ON public.ordenes_servicio USING btree (venta_id);


--
-- Name: ix_papelera_reciclaje_company_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_papelera_reciclaje_company_code ON public.papelera_reciclaje USING btree (company_code);


--
-- Name: ix_papelera_reciclaje_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_papelera_reciclaje_id ON public.papelera_reciclaje USING btree (id);


--
-- Name: ix_parametros_globales_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parametros_globales_empresa_id ON public.parametros_globales USING btree (empresa_id);


--
-- Name: ix_parametros_globales_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parametros_globales_id ON public.parametros_globales USING btree (id);


--
-- Name: ix_parametros_globales_llave; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_parametros_globales_llave ON public.parametros_globales USING btree (llave);


--
-- Name: ix_payment_receipts_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_receipts_empresa_id ON public.payment_receipts USING btree (empresa_id);


--
-- Name: ix_payment_receipts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_receipts_id ON public.payment_receipts USING btree (id);


--
-- Name: ix_periodos_contables_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_periodos_contables_empresa_id ON public.periodos_contables USING btree (empresa_id);


--
-- Name: ix_periodos_contables_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_periodos_contables_id ON public.periodos_contables USING btree (id);


--
-- Name: ix_precios_productos_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_precios_productos_empresa_id ON public.precios_productos USING btree (empresa_id);


--
-- Name: ix_precios_productos_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_precios_productos_id ON public.precios_productos USING btree (id);


--
-- Name: ix_precios_productos_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_precios_productos_producto_id ON public.precios_productos USING btree (producto_id);


--
-- Name: ix_precios_productos_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_precios_productos_sucursal_id ON public.precios_productos USING btree (sucursal_id);


--
-- Name: ix_precios_productos_tipo_cliente; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_precios_productos_tipo_cliente ON public.precios_productos USING btree (tipo_cliente);


--
-- Name: ix_producto_certificaciones_fecha_vencimiento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_producto_certificaciones_fecha_vencimiento ON public.producto_certificaciones USING btree (fecha_vencimiento);


--
-- Name: ix_producto_certificaciones_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_producto_certificaciones_id ON public.producto_certificaciones USING btree (id);


--
-- Name: ix_producto_certificaciones_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_producto_certificaciones_is_deleted ON public.producto_certificaciones USING btree (is_deleted);


--
-- Name: ix_producto_certificaciones_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_producto_certificaciones_producto_id ON public.producto_certificaciones USING btree (producto_id);


--
-- Name: ix_productos_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_productos_empresa_id ON public.productos USING btree (empresa_id);


--
-- Name: ix_productos_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_productos_id ON public.productos USING btree (id);


--
-- Name: ix_productos_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_productos_is_deleted ON public.productos USING btree (is_deleted);


--
-- Name: ix_productos_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_productos_nombre ON public.productos USING btree (nombre);


--
-- Name: ix_productos_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_productos_sku ON public.productos USING btree (sku);


--
-- Name: ix_proveedores_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_proveedores_empresa_id ON public.proveedores USING btree (empresa_id);


--
-- Name: ix_proveedores_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_proveedores_id ON public.proveedores USING btree (id);


--
-- Name: ix_proveedores_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_proveedores_is_deleted ON public.proveedores USING btree (is_deleted);


--
-- Name: ix_proveedores_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_proveedores_nombre ON public.proveedores USING btree (nombre);


--
-- Name: ix_proveedores_rut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_proveedores_rut ON public.proveedores USING btree (rut);


--
-- Name: ix_recepciones_dra_bodega_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_bodega_id ON public.recepciones_dra USING btree (bodega_id);


--
-- Name: ix_recepciones_dra_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_empresa_id ON public.recepciones_dra USING btree (empresa_id);


--
-- Name: ix_recepciones_dra_estado; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_estado ON public.recepciones_dra USING btree (estado);


--
-- Name: ix_recepciones_dra_folio_documento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_folio_documento ON public.recepciones_dra USING btree (folio_documento);


--
-- Name: ix_recepciones_dra_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_id ON public.recepciones_dra USING btree (id);


--
-- Name: ix_recepciones_dra_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_is_deleted ON public.recepciones_dra USING btree (is_deleted);


--
-- Name: ix_recepciones_dra_lineas_codigo_disposicion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_lineas_codigo_disposicion ON public.recepciones_dra_lineas USING btree (codigo_disposicion);


--
-- Name: ix_recepciones_dra_lineas_dra_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_lineas_dra_id ON public.recepciones_dra_lineas USING btree (dra_id);


--
-- Name: ix_recepciones_dra_lineas_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_lineas_id ON public.recepciones_dra_lineas USING btree (id);


--
-- Name: ix_recepciones_dra_lineas_producto_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_lineas_producto_id ON public.recepciones_dra_lineas USING btree (producto_id);


--
-- Name: ix_recepciones_dra_orden_compra_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_orden_compra_id ON public.recepciones_dra USING btree (orden_compra_id);


--
-- Name: ix_recepciones_dra_proveedor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_proveedor_id ON public.recepciones_dra USING btree (proveedor_id);


--
-- Name: ix_recepciones_dra_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recepciones_dra_sucursal_id ON public.recepciones_dra USING btree (sucursal_id);


--
-- Name: ix_recetas_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recetas_id ON public.recetas USING btree (id);


--
-- Name: ix_roles_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_codigo ON public.roles USING btree (codigo);


--
-- Name: ix_roles_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_empresa_id ON public.roles USING btree (empresa_id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_service_orders_estado; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_orders_estado ON public.service_orders USING btree (estado);


--
-- Name: ix_service_orders_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_orders_id ON public.service_orders USING btree (id);


--
-- Name: ix_service_status_config_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_status_config_empresa_id ON public.service_status_config USING btree (empresa_id);


--
-- Name: ix_service_status_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_status_config_id ON public.service_status_config USING btree (id);


--
-- Name: ix_service_workflows_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_workflows_id ON public.service_workflows USING btree (id);


--
-- Name: ix_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_settings_key ON public.settings USING btree (key);


--
-- Name: ix_subscription_plans_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_subscription_plans_id ON public.subscription_plans USING btree (id);


--
-- Name: ix_sucursales_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sucursales_codigo ON public.sucursales USING btree (codigo);


--
-- Name: ix_sucursales_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sucursales_empresa_id ON public.sucursales USING btree (empresa_id);


--
-- Name: ix_sucursales_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sucursales_id ON public.sucursales USING btree (id);


--
-- Name: ix_sucursales_nombre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sucursales_nombre ON public.sucursales USING btree (nombre);


--
-- Name: ix_system_secrets_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_secrets_key ON public.system_secrets USING btree (key);


--
-- Name: ix_table_crm_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_table_crm_empresa_id ON public.table_crm USING btree (empresa_id);


--
-- Name: ix_tipos_turno_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tipos_turno_empresa_id ON public.tipos_turno USING btree (empresa_id);


--
-- Name: ix_tipos_turno_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tipos_turno_id ON public.tipos_turno USING btree (id);


--
-- Name: ix_turnos_planificados_empleado_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_turnos_planificados_empleado_id ON public.turnos_planificados USING btree (empleado_id);


--
-- Name: ix_turnos_planificados_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_turnos_planificados_fecha ON public.turnos_planificados USING btree (fecha);


--
-- Name: ix_turnos_planificados_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_turnos_planificados_id ON public.turnos_planificados USING btree (id);


--
-- Name: ix_ubicaciones_bodega_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ubicaciones_bodega_id ON public.ubicaciones USING btree (bodega_id);


--
-- Name: ix_ubicaciones_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ubicaciones_id ON public.ubicaciones USING btree (id);


--
-- Name: ix_usuarios_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_usuarios_email ON public.usuarios USING btree (email);


--
-- Name: ix_usuarios_empresas_rol_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_usuarios_empresas_rol_id ON public.usuarios_empresas USING btree (rol_id);


--
-- Name: ix_usuarios_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_usuarios_id ON public.usuarios USING btree (id);


--
-- Name: ix_usuarios_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_usuarios_is_deleted ON public.usuarios USING btree (is_deleted);


--
-- Name: ix_ventas_cierre_caja_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_cierre_caja_id ON public.ventas USING btree (cierre_caja_id);


--
-- Name: ix_ventas_cliente_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_cliente_id ON public.ventas USING btree (cliente_id);


--
-- Name: ix_ventas_empresa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_empresa_id ON public.ventas USING btree (empresa_id);


--
-- Name: ix_ventas_folio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_folio ON public.ventas USING btree (folio);


--
-- Name: ix_ventas_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_id ON public.ventas USING btree (id);


--
-- Name: ix_ventas_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_is_deleted ON public.ventas USING btree (is_deleted);


--
-- Name: ix_ventas_sucursal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_sucursal_id ON public.ventas USING btree (sucursal_id);


--
-- Name: ix_ventas_vendedor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ventas_vendedor_id ON public.ventas USING btree (vendedor_id);


--
-- Name: ix_webhooks_config_event_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhooks_config_event_name ON public.webhooks_config USING btree (event_name);


--
-- Name: ix_webhooks_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhooks_config_id ON public.webhooks_config USING btree (id);


--
-- Name: clientes clientes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.clientes
    ADD CONSTRAINT clientes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: clientes clientes_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.clientes
    ADD CONSTRAINT clientes_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES public.usuarios(id);


--
-- Name: excepciones_credito excepciones_credito_autorizado_por_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.excepciones_credito
    ADD CONSTRAINT excepciones_credito_autorizado_por_fkey FOREIGN KEY (autorizado_por) REFERENCES public.usuarios(id);


--
-- Name: excepciones_credito excepciones_credito_cliente_rut_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.excepciones_credito
    ADD CONSTRAINT excepciones_credito_cliente_rut_fkey FOREIGN KEY (cliente_rut) REFERENCES crm.clientes(rut);


--
-- Name: politicas_precio politicas_precio_empresa_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.politicas_precio
    ADD CONSTRAINT politicas_precio_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: politicas_precio politicas_precio_usuario_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.politicas_precio
    ADD CONSTRAINT politicas_precio_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: precio_audit_log precio_audit_log_oportunidad_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.precio_audit_log
    ADD CONSTRAINT precio_audit_log_oportunidad_id_fkey FOREIGN KEY (oportunidad_id) REFERENCES public.crm_oportunidades(id);


--
-- Name: precio_audit_log precio_audit_log_producto_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.precio_audit_log
    ADD CONSTRAINT precio_audit_log_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: precio_audit_log precio_audit_log_usuario_id_fkey; Type: FK CONSTRAINT; Schema: crm; Owner: -
--

ALTER TABLE ONLY crm.precio_audit_log
    ADD CONSTRAINT precio_audit_log_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: activos_ti activos_ti_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activos_ti
    ADD CONSTRAINT activos_ti_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: activos_ti activos_ti_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activos_ti
    ADD CONSTRAINT activos_ti_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: asientos_contables asientos_contables_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asientos_contables
    ADD CONSTRAINT asientos_contables_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: asientos_contables asientos_contables_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asientos_contables
    ADD CONSTRAINT asientos_contables_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: asientos_contables asientos_contables_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asientos_contables
    ADD CONSTRAINT asientos_contables_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: asistencias asistencias_empleado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_empleado_id_fkey FOREIGN KEY (empleado_id) REFERENCES public.empleados(id);


--
-- Name: asistencias asistencias_turno_planificado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_turno_planificado_id_fkey FOREIGN KEY (turno_planificado_id) REFERENCES public.turnos_planificados(id);


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.usuarios(id);


--
-- Name: audit_logs audit_logs_impersonated_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_impersonated_user_id_fkey FOREIGN KEY (impersonated_user_id) REFERENCES public.usuarios(id);


--
-- Name: bodegas bodegas_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodegas
    ADD CONSTRAINT bodegas_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: cierres_caja cierres_caja_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cierres_caja
    ADD CONSTRAINT cierres_caja_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: cierres_caja cierres_caja_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cierres_caja
    ADD CONSTRAINT cierres_caja_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: cierres_caja cierres_caja_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cierres_caja
    ADD CONSTRAINT cierres_caja_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: clientes clientes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: company_subscriptions company_subscriptions_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_subscriptions
    ADD CONSTRAINT company_subscriptions_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: company_subscriptions company_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_subscriptions
    ADD CONSTRAINT company_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: crm_actividades crm_actividades_oportunidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_actividades
    ADD CONSTRAINT crm_actividades_oportunidad_id_fkey FOREIGN KEY (oportunidad_id) REFERENCES public.crm_oportunidades(id);


--
-- Name: crm_actividades crm_actividades_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_actividades
    ADD CONSTRAINT crm_actividades_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: crm_comentarios crm_comentarios_oportunidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_comentarios
    ADD CONSTRAINT crm_comentarios_oportunidad_id_fkey FOREIGN KEY (oportunidad_id) REFERENCES public.crm_oportunidades(id);


--
-- Name: crm_comentarios crm_comentarios_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_comentarios
    ADD CONSTRAINT crm_comentarios_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: crm_embudos crm_embudos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_embudos
    ADD CONSTRAINT crm_embudos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: crm_etapas crm_etapas_embudo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_etapas
    ADD CONSTRAINT crm_etapas_embudo_id_fkey FOREIGN KEY (embudo_id) REFERENCES public.crm_embudos(id);


--
-- Name: crm_notifications crm_notifications_jefe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_notifications
    ADD CONSTRAINT crm_notifications_jefe_id_fkey FOREIGN KEY (jefe_id) REFERENCES public.usuarios(id);


--
-- Name: crm_notifications crm_notifications_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_notifications
    ADD CONSTRAINT crm_notifications_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: crm_oportunidad_detalles crm_oportunidad_detalles_oportunidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidad_detalles
    ADD CONSTRAINT crm_oportunidad_detalles_oportunidad_id_fkey FOREIGN KEY (oportunidad_id) REFERENCES public.crm_oportunidades(id);


--
-- Name: crm_oportunidad_detalles crm_oportunidad_detalles_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidad_detalles
    ADD CONSTRAINT crm_oportunidad_detalles_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: crm_oportunidades crm_oportunidades_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidades
    ADD CONSTRAINT crm_oportunidades_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id);


--
-- Name: crm_oportunidades crm_oportunidades_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidades
    ADD CONSTRAINT crm_oportunidades_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: crm_oportunidades crm_oportunidades_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidades
    ADD CONSTRAINT crm_oportunidades_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: crm_oportunidades crm_oportunidades_etapa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidades
    ADD CONSTRAINT crm_oportunidades_etapa_id_fkey FOREIGN KEY (etapa_id) REFERENCES public.crm_etapas(id);


--
-- Name: crm_oportunidades crm_oportunidades_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_oportunidades
    ADD CONSTRAINT crm_oportunidades_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: cuentas_contables cuentas_contables_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cuentas_contables
    ADD CONSTRAINT cuentas_contables_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: cuentas_contables cuentas_contables_padre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cuentas_contables
    ADD CONSTRAINT cuentas_contables_padre_id_fkey FOREIGN KEY (padre_id) REFERENCES public.cuentas_contables(id);


--
-- Name: detalles_venta detalles_venta_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_venta
    ADD CONSTRAINT detalles_venta_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: detalles_venta detalles_venta_sustituye_a_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_venta
    ADD CONSTRAINT detalles_venta_sustituye_a_id_fkey FOREIGN KEY (sustituye_a_id) REFERENCES public.detalles_venta(id);


--
-- Name: detalles_venta detalles_venta_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_venta
    ADD CONSTRAINT detalles_venta_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id);


--
-- Name: documentos_tributarios documentos_tributarios_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios
    ADD CONSTRAINT documentos_tributarios_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: documentos_tributarios_detalles documentos_tributarios_detalles_dte_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios_detalles
    ADD CONSTRAINT documentos_tributarios_detalles_dte_id_fkey FOREIGN KEY (dte_id) REFERENCES public.documentos_tributarios(id);


--
-- Name: documentos_tributarios documentos_tributarios_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios
    ADD CONSTRAINT documentos_tributarios_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: documentos_tributarios documentos_tributarios_usuario_emisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios
    ADD CONSTRAINT documentos_tributarios_usuario_emisor_id_fkey FOREIGN KEY (usuario_emisor_id) REFERENCES public.usuarios(id);


--
-- Name: documentos_tributarios documentos_tributarios_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_tributarios
    ADD CONSTRAINT documentos_tributarios_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id);


--
-- Name: empleados empleados_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empleados
    ADD CONSTRAINT empleados_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: empleados empleados_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empleados
    ADD CONSTRAINT empleados_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: empresas_metodos_pago empresas_metodos_pago_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empresas_metodos_pago
    ADD CONSTRAINT empresas_metodos_pago_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: empresas_metodos_pago empresas_metodos_pago_metodo_pago_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.empresas_metodos_pago
    ADD CONSTRAINT empresas_metodos_pago_metodo_pago_id_fkey FOREIGN KEY (metodo_pago_id) REFERENCES public.metodos_pago(id);


--
-- Name: folios_sii folios_sii_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folios_sii
    ADD CONSTRAINT folios_sii_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: folios_sii folios_sii_usuario_carga_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folios_sii
    ADD CONSTRAINT folios_sii_usuario_carga_id_fkey FOREIGN KEY (usuario_carga_id) REFERENCES public.usuarios(id);


--
-- Name: gastos gastos_asiento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_asiento_id_fkey FOREIGN KEY (asiento_id) REFERENCES public.asientos_contables(id);


--
-- Name: gastos gastos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: gastos gastos_metodo_pago_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_metodo_pago_id_fkey FOREIGN KEY (metodo_pago_id) REFERENCES public.metodos_pago(id);


--
-- Name: gastos gastos_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: gastos gastos_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: historial_costos historial_costos_movimiento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historial_costos
    ADD CONSTRAINT historial_costos_movimiento_id_fkey FOREIGN KEY (movimiento_id) REFERENCES public.movimientos_stock(id) ON DELETE SET NULL;


--
-- Name: historial_costos historial_costos_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historial_costos
    ADD CONSTRAINT historial_costos_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE CASCADE;


--
-- Name: historial_orden_servicio historial_orden_servicio_orden_servicio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historial_orden_servicio
    ADD CONSTRAINT historial_orden_servicio_orden_servicio_id_fkey FOREIGN KEY (orden_servicio_id) REFERENCES public.ordenes_servicio(id);


--
-- Name: historial_orden_servicio historial_orden_servicio_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historial_orden_servicio
    ADD CONSTRAINT historial_orden_servicio_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: insumos_receta insumos_receta_producto_insumo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insumos_receta
    ADD CONSTRAINT insumos_receta_producto_insumo_id_fkey FOREIGN KEY (producto_insumo_id) REFERENCES public.productos(id);


--
-- Name: insumos_receta insumos_receta_receta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insumos_receta
    ADD CONSTRAINT insumos_receta_receta_id_fkey FOREIGN KEY (receta_id) REFERENCES public.recetas(id);


--
-- Name: inventario inventario_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id) ON DELETE CASCADE;


--
-- Name: inventario_lotes inventario_lotes_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario_lotes
    ADD CONSTRAINT inventario_lotes_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id) ON DELETE CASCADE;


--
-- Name: inventario_lotes inventario_lotes_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario_lotes
    ADD CONSTRAINT inventario_lotes_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE CASCADE;


--
-- Name: inventario inventario_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE CASCADE;


--
-- Name: inventario_ubicacion inventario_ubicacion_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario_ubicacion
    ADD CONSTRAINT inventario_ubicacion_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE CASCADE;


--
-- Name: inventario_ubicacion inventario_ubicacion_ubicacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario_ubicacion
    ADD CONSTRAINT inventario_ubicacion_ubicacion_id_fkey FOREIGN KEY (ubicacion_id) REFERENCES public.ubicaciones(id) ON DELETE CASCADE;


--
-- Name: job_orders job_orders_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_orders
    ADD CONSTRAINT job_orders_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: job_orders job_orders_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_orders
    ADD CONSTRAINT job_orders_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: job_orders job_orders_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_orders
    ADD CONSTRAINT job_orders_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: legal_documentos legal_documentos_oportunidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_documentos
    ADD CONSTRAINT legal_documentos_oportunidad_id_fkey FOREIGN KEY (oportunidad_id) REFERENCES public.crm_oportunidades(id);


--
-- Name: liquidaciones_sueldo liquidaciones_sueldo_empleado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones_sueldo
    ADD CONSTRAINT liquidaciones_sueldo_empleado_id_fkey FOREIGN KEY (empleado_id) REFERENCES public.empleados(id);


--
-- Name: movimientos_contables movimientos_contables_asiento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_contables
    ADD CONSTRAINT movimientos_contables_asiento_id_fkey FOREIGN KEY (asiento_id) REFERENCES public.asientos_contables(id);


--
-- Name: movimientos_contables movimientos_contables_cuenta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_contables
    ADD CONSTRAINT movimientos_contables_cuenta_id_fkey FOREIGN KEY (cuenta_id) REFERENCES public.cuentas_contables(id);


--
-- Name: movimientos_contables movimientos_contables_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_contables
    ADD CONSTRAINT movimientos_contables_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: movimientos_stock movimientos_stock_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id) ON DELETE RESTRICT;


--
-- Name: movimientos_stock movimientos_stock_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id) ON DELETE CASCADE;


--
-- Name: movimientos_stock movimientos_stock_lote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_lote_id_fkey FOREIGN KEY (lote_id) REFERENCES public.inventario_lotes(id);


--
-- Name: movimientos_stock movimientos_stock_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE RESTRICT;


--
-- Name: orden_compra_detalles orden_compra_detalles_orden_compra_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orden_compra_detalles
    ADD CONSTRAINT orden_compra_detalles_orden_compra_id_fkey FOREIGN KEY (orden_compra_id) REFERENCES public.ordenes_compra(id);


--
-- Name: orden_compra_detalles orden_compra_detalles_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orden_compra_detalles
    ADD CONSTRAINT orden_compra_detalles_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: ordenes_compra ordenes_compra_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_compra
    ADD CONSTRAINT ordenes_compra_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id);


--
-- Name: ordenes_compra ordenes_compra_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_compra
    ADD CONSTRAINT ordenes_compra_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: ordenes_compra ordenes_compra_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_compra
    ADD CONSTRAINT ordenes_compra_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: ordenes_compra ordenes_compra_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_compra
    ADD CONSTRAINT ordenes_compra_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: ordenes_compra ordenes_compra_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_compra
    ADD CONSTRAINT ordenes_compra_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: ordenes_servicio ordenes_servicio_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes_servicio
    ADD CONSTRAINT ordenes_servicio_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id);


--
-- Name: parametros_globales parametros_globales_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametros_globales
    ADD CONSTRAINT parametros_globales_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: payment_receipts payment_receipts_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: payment_receipts payment_receipts_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: periodos_contables periodos_contables_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodos_contables
    ADD CONSTRAINT periodos_contables_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: periodos_contables periodos_contables_usuario_cierre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodos_contables
    ADD CONSTRAINT periodos_contables_usuario_cierre_id_fkey FOREIGN KEY (usuario_cierre_id) REFERENCES public.usuarios(id);


--
-- Name: precios_productos precios_productos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.precios_productos
    ADD CONSTRAINT precios_productos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: precios_productos precios_productos_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.precios_productos
    ADD CONSTRAINT precios_productos_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: precios_productos precios_productos_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.precios_productos
    ADD CONSTRAINT precios_productos_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: producto_certificaciones producto_certificaciones_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.producto_certificaciones
    ADD CONSTRAINT producto_certificaciones_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: productos productos_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: proveedores proveedores_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: recepciones_dra recepciones_dra_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra
    ADD CONSTRAINT recepciones_dra_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id);


--
-- Name: recepciones_dra recepciones_dra_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra
    ADD CONSTRAINT recepciones_dra_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: recepciones_dra_lineas recepciones_dra_lineas_dra_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra_lineas
    ADD CONSTRAINT recepciones_dra_lineas_dra_id_fkey FOREIGN KEY (dra_id) REFERENCES public.recepciones_dra(id);


--
-- Name: recepciones_dra_lineas recepciones_dra_lineas_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra_lineas
    ADD CONSTRAINT recepciones_dra_lineas_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: recepciones_dra recepciones_dra_orden_compra_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra
    ADD CONSTRAINT recepciones_dra_orden_compra_id_fkey FOREIGN KEY (orden_compra_id) REFERENCES public.ordenes_compra(id);


--
-- Name: recepciones_dra recepciones_dra_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra
    ADD CONSTRAINT recepciones_dra_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: recepciones_dra recepciones_dra_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recepciones_dra
    ADD CONSTRAINT recepciones_dra_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: recetas recetas_producto_final_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recetas
    ADD CONSTRAINT recetas_producto_final_id_fkey FOREIGN KEY (producto_final_id) REFERENCES public.productos(id);


--
-- Name: roles roles_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: service_orders service_orders_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: service_orders service_orders_job_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_job_order_id_fkey FOREIGN KEY (job_order_id) REFERENCES public.job_orders(id);


--
-- Name: service_orders service_orders_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: service_orders service_orders_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: service_orders service_orders_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: service_orders service_orders_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id);


--
-- Name: service_orders service_orders_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.service_workflows(id);


--
-- Name: service_status_config service_status_config_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_status_config
    ADD CONSTRAINT service_status_config_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: service_workflows service_workflows_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_workflows
    ADD CONSTRAINT service_workflows_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: sucursales sucursales_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sucursales
    ADD CONSTRAINT sucursales_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: system_secrets system_secrets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_secrets
    ADD CONSTRAINT system_secrets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.usuarios(id);


--
-- Name: table_crm table_crm_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_crm
    ADD CONSTRAINT table_crm_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: tipos_turno tipos_turno_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipos_turno
    ADD CONSTRAINT tipos_turno_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: turnos_planificados turnos_planificados_empleado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turnos_planificados
    ADD CONSTRAINT turnos_planificados_empleado_id_fkey FOREIGN KEY (empleado_id) REFERENCES public.empleados(id);


--
-- Name: turnos_planificados turnos_planificados_tipo_turno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turnos_planificados
    ADD CONSTRAINT turnos_planificados_tipo_turno_id_fkey FOREIGN KEY (tipo_turno_id) REFERENCES public.tipos_turno(id);


--
-- Name: ubicaciones ubicaciones_bodega_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ubicaciones
    ADD CONSTRAINT ubicaciones_bodega_id_fkey FOREIGN KEY (bodega_id) REFERENCES public.bodegas(id);


--
-- Name: usuarios_empresas usuarios_empresas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_empresas
    ADD CONSTRAINT usuarios_empresas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: usuarios_empresas usuarios_empresas_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_empresas
    ADD CONSTRAINT usuarios_empresas_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id);


--
-- Name: usuarios_empresas usuarios_empresas_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_empresas
    ADD CONSTRAINT usuarios_empresas_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: usuarios usuarios_supervisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_supervisor_id_fkey FOREIGN KEY (supervisor_id) REFERENCES public.usuarios(id);


--
-- Name: ventas ventas_cierre_caja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_cierre_caja_id_fkey FOREIGN KEY (cierre_caja_id) REFERENCES public.cierres_caja(id);


--
-- Name: ventas ventas_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: ventas ventas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES public.empresas(id);


--
-- Name: ventas ventas_sucursal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_sucursal_id_fkey FOREIGN KEY (sucursal_id) REFERENCES public.sucursales(id);


--
-- Name: ventas ventas_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES public.usuarios(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 6TVRNxdXTVVjHnX7KF5BN7h8fA3JSZlTxcATzRQKJu6sTA3fIv4Gz1qTBnS3ge5

