-- Script para crear usuario de solo lectura para BI (Business Intelligence)
-- Base de datos objetivo: erp3_db

-- 1. Crear el rol si no existe
DO
$do$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'n_bi_readonly') THEN

      CREATE ROLE n_bi_readonly WITH LOGIN PASSWORD 'Bi_ReadOnly_2026!';
   END IF;
END
$do$;

-- 2. Asignar permisos de conexión a la base de datos
GRANT CONNECT ON DATABASE erp3_db TO n_bi_readonly;

-- 3. Asignar uso del esquema public
GRANT USAGE ON SCHEMA public TO n_bi_readonly;

-- 4. Asignar permisos de lectura (SELECT) a todas las tablas y secuencias ACTUALES
GRANT SELECT ON ALL TABLES IN SCHEMA public TO n_bi_readonly;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO n_bi_readonly;

-- 5. Configurar permisos automáticos para FUTURAS tablas y secuencias
-- Nota: Esto aplica a los objetos creados por el usuario que ejecuta este script.
-- Se recomienda ejecutar este script con el usuario dueño del esquema (ej. erp3_user).
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO n_bi_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON SEQUENCES TO n_bi_readonly;

-- Si se ejecuta como superusuario pero las tablas las crea otro usuario (ej. erp3_user),
-- descomentar y ajustar las siguientes líneas:
-- ALTER DEFAULT PRIVILEGES FOR ROLE erp3_user IN SCHEMA public GRANT SELECT ON TABLES TO n_bi_readonly;
-- ALTER DEFAULT PRIVILEGES FOR ROLE erp3_user IN SCHEMA public GRANT SELECT ON SEQUENCES TO n_bi_readonly;
