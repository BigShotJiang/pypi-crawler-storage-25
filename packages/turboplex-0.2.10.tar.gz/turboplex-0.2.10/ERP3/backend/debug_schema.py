from app.core.database import engine
from sqlalchemy import inspect


def check_schema():
    inspector = inspect(engine)

    # Check tables
    tables = inspector.get_table_names()
    print(f"Tablas encontradas: {tables}")

    if "empresas" in tables:
        columns = [c["name"] for c in inspector.get_columns("empresas")]
        print(f"\nColumnas en 'empresas': {columns}")

        missing = []
        for col in ["pwr_bi_enabled", "pwr_bi_config"]:
            if col not in columns:
                missing.append(col)

        if missing:
            print(f"\n[ALERTA] Faltan columnas en 'empresas': {missing}")
        else:
            print("\n[OK] Todas las columnas de PowerBI existen en 'empresas'.")

    if "audit_logs" in tables:
        print("\n[OK] Tabla 'audit_logs' existe.")
    else:
        print("\n[ALERTA] Tabla 'audit_logs' NO existe.")


if __name__ == "__main__":
    check_schema()
