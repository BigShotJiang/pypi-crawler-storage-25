import sys
import os
from datetime import datetime, timedelta, timezone

# Add backend directory to path so we can import app modules
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from app.core.database import SessionLocal, engine, Base
from app.core_modules.billing.models import CompanySubscription, SubscriptionPlan
from app.core_modules.sistema.models import Empresa

def fix_db():
    print("Creating missing tables...")
    # This will create tables for imported models if they don't exist
    Base.metadata.create_all(bind=engine)
    print("Tables check/creation done.")

    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        # 1. Ensure SubscriptionPlan 'Enterprise' exists
        plan_name = "Enterprise"
        plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.name == plan_name).first()
        if not plan:
            print(f"Creating plan '{plan_name}'...")
            plan = SubscriptionPlan(
                name=plan_name,
                price_clp=50000,
                user_limit=10,
                branch_limit=5,
                is_active=True
            )
            db.add(plan)
            db.commit()
            db.refresh(plan)
            print(f"Plan '{plan_name}' created with ID: {plan.id}")
        else:
            print(f"Plan '{plan_name}' already exists.")

        # 2. Find Company 'QUESO964'
        company_code = "QUESO964"
        empresa = db.query(Empresa).filter(Empresa.codigo == company_code).first()
        if not empresa:
            print(f"Company '{company_code}' not found! Creating dummy company...")
            # Create dummy company if not exists (though user implied it exists)
            empresa = Empresa(
                nombre="Empresa Queso Test",
                codigo=company_code,
                rut="99.999.999-K",
                is_active=True
            )
            db.add(empresa)
            db.commit()
            db.refresh(empresa)
            print(f"Company '{company_code}' created with ID: {empresa.id}")
        else:
            print(f"Company '{company_code}' found with ID: {empresa.id}")

        # 3. Create/Update Subscription
        subscription = db.query(CompanySubscription).filter(CompanySubscription.empresa_id == empresa.id).first()
        expires_at = datetime.now(timezone.utc) + timedelta(days=365) # 1 year from now

        if not subscription:
            print(f"Creating active subscription for '{company_code}'...")
            subscription = CompanySubscription(
                empresa_id=empresa.id,
                plan_id=plan.id,
                expires_at=expires_at
            )
            db.add(subscription)
            db.commit()
            print("Subscription created successfully.")
        else:
            print(f"Subscription for '{company_code}' already exists. Updating expiration...")
            subscription.expires_at = expires_at
            subscription.plan_id = plan.id
            db.add(subscription)
            db.commit()
            print("Subscription updated successfully.")

    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    fix_db()
