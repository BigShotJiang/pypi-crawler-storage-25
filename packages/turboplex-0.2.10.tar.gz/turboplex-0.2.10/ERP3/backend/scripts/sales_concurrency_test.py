import sys
import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.database import SessionLocal
from app.core_modules.ventas import models, services
from app.core_modules.sistema.models import Empresa, Usuario, Bodega, Sucursal
from app.core_modules.ventas.schemas import VentaCreate, DetalleVentaCreate
from app.core.exceptions import BusinessRuleError

# Configuration
TOTAL_REQUESTS = 500  # Total number of purchase attempts
MAX_WORKERS = 50  # Max concurrent threads (simulated users)
INITIAL_STOCK = 10  # Only 10 items available!
PRODUCT_PRICE = 1000

print("\n" + "=" * 60)
print("🔥  SALES CONCURRENCY STRESS TEST  🔥")
print("=" * 60)
print(
    f"Scenario: {TOTAL_REQUESTS} requests ({MAX_WORKERS} concurrent) fighting for {INITIAL_STOCK} items."
)
print("Goal: Ensure Stock never drops below 0.")
print("-" * 60 + "\n")


def setup_test_data():
    db = SessionLocal()
    try:
        # 1. Get or Create Company
        empresa = db.query(Empresa).filter(Empresa.codigo == "DEMO").first()
        if not empresa:
            print("❌ Demo company not found. Run onboarding first.")
            return None

        # 2. Get User
        user = db.query(Usuario).filter(Usuario.email == "admin@demo.cl").first()

        # 3. Get Sucursal & Bodega
        sucursal = db.query(Sucursal).filter(Sucursal.empresa_id == empresa.id).first()
        bodega = db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()

        # 4. Create Test Product
        sku = f"TEST-STRESS-{uuid.uuid4().hex[:6]}"
        producto = models.Producto(
            nombre="Producto Stress Test",
            sku=sku,
            precio=PRODUCT_PRICE,
            empresa_id=empresa.id,
            is_active=True,
        )
        db.add(producto)
        db.flush()

        # 5. Set Initial Stock
        inventario = models.Inventario(
            producto_id=producto.id,
            bodega_id=bodega.id,
            cantidad=INITIAL_STOCK,
            cantidad_reservada=0,
            stock_minimo=0,
        )
        db.add(inventario)

        # 6. Create Dummy Client
        cliente = models.Cliente(
            nombre="Cliente Stress", rut="1-9", empresa_id=empresa.id
        )
        db.add(cliente)

        db.commit()

        print("✅ Setup Complete.")
        print(f"   Producto: {producto.nombre} (ID: {producto.id})")
        print(f"   Bodega:   {bodega.nombre} (ID: {bodega.id})")
        print(f"   Stock:    {INITIAL_STOCK}")

        return {
            "empresa_id": empresa.id,
            "usuario_id": user.id,
            "sucursal_id": sucursal.id,
            "producto_id": producto.id,
            "cliente_id": cliente.id,
            "bodega_id": bodega.id,
        }

    except Exception as e:
        print(f"❌ Setup Failed: {e}")
        db.rollback()
        return None
    finally:
        db.close()


stats = {"sold": 0, "rejected": 0, "errors": []}
stats_lock = threading.Lock()


def attempt_purchase(data):
    db = SessionLocal()
    try:
        # Prepare Venta Data
        detalle = DetalleVentaCreate(
            producto_id=data["producto_id"],
            cantidad=1,
            precio_unitario=PRODUCT_PRICE,
            subtotal=PRODUCT_PRICE,
        )

        venta_in = VentaCreate(
            cliente_id=data["cliente_id"],
            sucursal_id=data["sucursal_id"],
            folio=f"STRESS-{uuid.uuid4().hex[:8]}",
            detalles=[detalle],
            metodo_pago_id=None,  # Not needed for this test
        )

        # Execute Service
        # This calls create_venta -> inventory_service.reserve_stock
        services.create_venta(db, venta_in, data["usuario_id"], data["empresa_id"])

        db.commit()

        with stats_lock:
            stats["sold"] += 1

    except BusinessRuleError:
        # Expected error: "No hay stock suficiente"
        db.rollback()
        with stats_lock:
            stats["rejected"] += 1

    except Exception as e:
        db.rollback()
        with stats_lock:
            stats["errors"].append(str(e))
    finally:
        db.close()


def verify_final_stock(data):
    db = SessionLocal()
    try:
        inv = (
            db.query(models.Inventario)
            .filter(
                models.Inventario.producto_id == data["producto_id"],
                models.Inventario.bodega_id == data["bodega_id"],
            )
            .first()
        )

        real_stock = inv.cantidad - inv.cantidad_reservada
        return inv.cantidad, inv.cantidad_reservada, real_stock
    finally:
        db.close()


def run_test():
    data = setup_test_data()
    if not data:
        return

    print("\n🚀 Starting Attack...")
    start_time = time.time()

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [
            executor.submit(attempt_purchase, data) for _ in range(TOTAL_REQUESTS)
        ]
        for _ in as_completed(futures):
            pass

    duration = time.time() - start_time

    # Verification
    phys, res, avail = verify_final_stock(data)

    print("\n" + "=" * 60)
    print("📊  RESULTS")
    print("=" * 60)
    print(f"Time:             {duration:.2f}s")
    print(f"Successful Sales: {stats['sold']}")
    print(f"Rejected Sales:   {stats['rejected']}")
    print(f"Unexpected Errors:{len(stats['errors'])}")
    print("-" * 30)
    print(f"Initial Stock:    {INITIAL_STOCK}")
    print(f"Final Physical:   {phys}")
    print(f"Final Reserved:   {res}")
    print(f"Final Available:  {avail}")
    print("=" * 60)

    if len(stats["errors"]) > 0:
        print("\n⚠️ Errors:")
        for e in stats["errors"][:5]:
            print(f" - {e}")

    if avail < 0:
        print("\n❌ CRITICAL FAIL: Stock is negative! Race condition exists.")
    elif stats["sold"] > INITIAL_STOCK:
        print("\n❌ FAIL: Sold more than available.")
    elif stats["sold"] + stats["rejected"] != TOTAL_REQUESTS:
        # Note: this might happen if unknown errors occurred
        print("\n⚠️ Warning: Sum of sold + rejected != total requests")
    else:
        print("\n✨ SUCCESS: Stock logic held under fire.")


if __name__ == "__main__":
    run_test()
