
file_path = r"e:\ERP3\backend\alembic\versions\162e4ccb9ce6_uuid7_remaining_modules.py"

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# Replace the line to add server_default=None
# We look for the string we added previously
old_str = "postgresql_using=\"'00000000-0000-0000-0000-000000000000'::uuid\","
new_str = "postgresql_using=\"'00000000-0000-0000-0000-000000000000'::uuid\", server_default=None,"

new_content = content.replace(old_str, new_str)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(new_content)

print("Migration file updated successfully with server_default=None.")
