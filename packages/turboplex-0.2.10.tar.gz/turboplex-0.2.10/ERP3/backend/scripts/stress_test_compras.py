import os
import sys
import time
import asyncio
from pathlib import Path
from typing import List, Tuple, Dict, Any
from uuid import UUID
from decimal import Decimal

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
import httpx


backend_root = Path(__file__).resolve().parents[1]
if str(backend_root) not in sys.path:
    sys.path.insert(0, str(backend_root))

load_dotenv(backend_root / ".env")
STRESS_DB_URL = os.getenv("TEST_DATABASE_URL") or os.getenv("DATABASE_URL")
if "TEST_DATABASE_URL" in os.environ:
    os.environ.pop("TEST_DATABASE_URL")

from app.core.config import settings
from app.core_modules.sistema.models import (
    Empresa,
    Usuario,
    UsuarioEmpresa,
    Sucursal,
    Bodega,
    Rol,
    AuditLog,
)
from app.core_modules.compras.models import Proveedor, OrdenCompra
from app.addons.webhooks.models import WebhookConfig
from app.core.queue import task_queue
from app.core.security import create_access_token


def get_engine_and_sessionmaker() -> Tuple[Any, Any]:
    db_url = STRESS_DB_URL
    if not db_url:
        raise RuntimeError(
            "DATABASE_URL or TEST_DATABASE_URL must be set for stress_test_compras"
        )
    if db_url.startswith("postgresql+psycopg2://"):
        db_url = db_url.replace("postgresql+psycopg2://", "postgresql://")
    engine = create_engine(db_url, future=True)
    SessionLocal = sessionmaker(
        bind=engine, autoflush=False, autocommit=False, future=True
    )
    return engine, SessionLocal


def set_allow_no_tenant(db: Session) -> None:
    try:
        db.info["allow_no_tenant"] = True
    except Exception:
        pass


def ensure_webhook_config_for_oc_aprobada(db: Session) -> None:
    set_allow_no_tenant(db)
    existing = (
        db.query(WebhookConfig)
        .filter(WebhookConfig.event_name == "orden_compra.aprobada")
        .first()
    )
    if existing:
        return
    url = os.getenv(
        "N8N_OC_APROBADA_URL",
        "http://localhost:5678/webhook/orden_compra_aprobada_stress",
    )
    config = WebhookConfig(
        event_name="orden_compra.aprobada",
        url=url,
        secret_key=None,
        is_active=True,
    )
    db.add(config)
    db.commit()


def bootstrap_compras_stress(
    db: Session,
) -> Tuple[Empresa, Usuario, Sucursal, Bodega, Proveedor, Rol]:
    set_allow_no_tenant(db)
    empresa = (
        db.query(Empresa)
        .filter(Empresa.codigo.like("CMP_STRESS_%"))
        .order_by(Empresa.created_at.asc())
        .first()
    )
    if empresa is None:
        empresa = Empresa(
            nombre="STRESS_COMPRAS",
            codigo="CMP_STRESS_1",
            is_active=True,
        )
        db.add(empresa)
        db.flush()
    roles_map: Dict[str, Rol] = {}
    role_specs = [
        ("ADM", "Administrador"),
        ("SUP", "Supervisor"),
        ("VEN", "Vendedor"),
        ("BOD", "Bodega"),
        ("CON", "Contador"),
        ("BACKOFFICE", "Backoffice"),
        ("AUD", "Auditor"),
    ]
    for code, nombre in role_specs:
        rol = (
            db.query(Rol)
            .filter(Rol.empresa_id == empresa.id, Rol.codigo == code)
            .first()
        )
        if rol is None:
            rol = Rol(
                empresa_id=empresa.id,
                codigo=code,
                nombre=nombre,
                is_active=True,
            )
            db.add(rol)
            db.flush()
        roles_map[code] = rol
    adm_email = "stress_compras_adm@local.test"
    adm = db.query(Usuario).filter(Usuario.email == adm_email).first()
    if adm is None:
        adm = Usuario(
            email=adm_email,
            hashed_password="not_used_stress",
            is_active=True,
            role="ADMIN",
        )
        db.add(adm)
        db.flush()
    adm_link = (
        db.query(UsuarioEmpresa)
        .filter(
            UsuarioEmpresa.usuario_id == adm.id,
            UsuarioEmpresa.empresa_id == empresa.id,
        )
        .first()
    )
    if adm_link is None:
        adm_link = UsuarioEmpresa(
            usuario_id=adm.id,
            empresa_id=empresa.id,
            rol_id=roles_map["ADM"].id,
            is_default=True,
        )
        db.add(adm_link)
    else:
        if adm_link.rol_id != roles_map["ADM"].id:
            adm_link.rol_id = roles_map["ADM"].id
        if not adm_link.is_default:
            adm_link.is_default = True
    sucursal = (
        db.query(Sucursal)
        .filter(Sucursal.empresa_id == empresa.id)
        .order_by(Sucursal.created_at.asc())
        .first()
    )
    if sucursal is None:
        sucursal = Sucursal(
            nombre="CMP_STRESS_SUC",
            codigo=f"{empresa.codigo}-SUC",
            direccion="STRESS",
            empresa_id=empresa.id,
        )
        db.add(sucursal)
        db.flush()
    bodega = (
        db.query(Bodega)
        .filter(Bodega.sucursal_id == sucursal.id)
        .order_by(Bodega.created_at.asc())
        .first()
    )
    if bodega is None:
        bodega = Bodega(
            nombre="CMP_STRESS_BOD",
            codigo=f"{empresa.codigo}-BOD",
            sucursal_id=sucursal.id,
            is_active=True,
        )
        db.add(bodega)
        db.flush()
    proveedor = (
        db.query(Proveedor)
        .filter(
            Proveedor.empresa_id == empresa.id,
            Proveedor.nombre == "STRESS_PROV_COMPRAS",
        )
        .first()
    )
    if proveedor is None:
        proveedor = Proveedor(
            nombre="STRESS_PROV_COMPRAS",
            empresa_id=empresa.id,
        )
        db.add(proveedor)
        db.flush()
    db.commit()
    db.refresh(empresa)
    db.refresh(adm)
    db.refresh(sucursal)
    db.refresh(bodega)
    db.refresh(proveedor)
    return empresa, adm, sucursal, bodega, proveedor, roles_map["ADM"]


def create_ordenes_compra(
    db: Session,
    empresa: Empresa,
    adm: Usuario,
    sucursal: Sucursal,
    bodega: Bodega,
    proveedor_id: UUID,
    total: int = 100,
) -> List[UUID]:
    set_allow_no_tenant(db)
    ids: List[UUID] = []
    for i in range(total):
        oc = OrdenCompra(
            folio=f"STRESS_OC_{i+1}",
            proveedor_id=proveedor_id,
            sucursal_id=sucursal.id,
            bodega_id=bodega.id,
            empresa_id=empresa.id,
            usuario_id=adm.id,
            estado="BORRADOR",
            total_neto=Decimal("10000.00"),
            total=Decimal("10000.00"),
        )
        db.add(oc)
        db.flush()
        ids.append(oc.id)
    db.commit()
    return ids


def count_webhook_jobs() -> int | None:
    if task_queue is None:
        return None
    try:
        jobs = task_queue.jobs
        count = 0
        for job in jobs:
            func_name = str(getattr(job, "func_name", ""))
            if "webhooks.listeners.deliver_webhook_job" in func_name:
                count += 1
        return count
    except Exception:
        return None


def count_audit_logs(db: Session) -> int:
    set_allow_no_tenant(db)
    return db.query(AuditLog).count()


async def approve_orders_async(
    order_ids: List[UUID],
    token: str,
    empresa_codigo: str,
    base_url: str,
) -> Dict[str, Any]:
    semaphore = asyncio.Semaphore(20)
    async with httpx.AsyncClient(base_url=base_url, timeout=10.0) as client:
        async def worker(orden_id: UUID) -> Tuple[int, float, str | None]:
            url = f"/compras/ordenes-compra/{orden_id}/aprobar?cmp={empresa_codigo}"
            async with semaphore:
                start = time.perf_counter()
                try:
                    response = await client.post(
                        url,
                        headers={"Authorization": f"Bearer {token}"},
                    )
                    elapsed = time.perf_counter() - start
                    return response.status_code, elapsed, None
                except Exception as exc:
                    elapsed = time.perf_counter() - start
                    return 0, elapsed, str(exc)

        tasks = [worker(oid) for oid in order_ids]
        results = await asyncio.gather(*tasks)
    success = 0
    unexpected_403 = 0
    error_500 = 0
    other_errors = 0
    latencies: List[float] = []
    errors: List[str] = []
    for code, elapsed, err in results:
        if code == 200:
            success += 1
            latencies.append(elapsed)
        elif code == 403:
            unexpected_403 += 1
        elif code >= 500:
            error_500 += 1
        else:
            other_errors += 1
        if err:
            errors.append(err)
    avg_ms = 0.0
    if latencies:
        avg_ms = (sum(latencies) / len(latencies)) * 1000.0
    return {
        "total_requests": len(order_ids),
        "success": success,
        "unexpected_403": unexpected_403,
        "error_500": error_500,
        "other_errors": other_errors,
        "avg_latency_ms": avg_ms,
        "errors": errors,
    }


def cleanup_stress_compras_data(db: Session) -> None:
    set_allow_no_tenant(db)
    db.query(OrdenCompra).filter(OrdenCompra.folio.like("STRESS_OC_%")).delete(
        synchronize_session=False
    )
    proveedores = (
        db.query(Proveedor)
        .filter(Proveedor.nombre == "STRESS_PROV_COMPRAS")
        .all()
    )
    for proveedor in proveedores:
        db.delete(proveedor)
    db.commit()


def run() -> None:
    print("============================================================")
    print("STRESS TEST COMPRAS: APROBACION DE ORDENES DE COMPRA")
    print("============================================================")
    engine, SessionLocal = get_engine_and_sessionmaker()
    db_setup = SessionLocal()
    try:
        empresa, adm, sucursal, bodega, proveedor, rol_adm = bootstrap_compras_stress(
            db_setup
        )
        ensure_webhook_config_for_oc_aprobada(db_setup)
        baseline_logs = count_audit_logs(db_setup)
    finally:
        db_setup.close()
    db_orders = SessionLocal()
    try:
        order_ids = create_ordenes_compra(
            db_orders, empresa, adm, sucursal, bodega, proveedor.id, 100
        )
    finally:
        db_orders.close()
    before_webhooks = count_webhook_jobs()
    token = create_access_token(adm.id)
    base_url = f"http://localhost:8000{settings.API_V1_PREFIX}"
    print("Lanzando rafaga de aprobaciones...")
    start_wall = time.perf_counter()
    results = asyncio.run(
        approve_orders_async(order_ids, token, empresa.codigo, base_url)
    )
    end_wall = time.perf_counter()
    db_final = SessionLocal()
    try:
        final_logs = count_audit_logs(db_final)
    finally:
        db_final.close()
    after_webhooks = count_webhook_jobs()
    audit_delta = final_logs - baseline_logs
    processing_duration = None
    if (
        before_webhooks is not None
        and after_webhooks is not None
        and after_webhooks > before_webhooks
    ):
        print("Esperando a que n8n/worker procesen la cola de Webhooks...")
        processing_start = time.perf_counter()
        max_wait = float(os.getenv("STRESS_WEBHOOK_MAX_WAIT_SECONDS", "60"))
        while True:
            time.sleep(1.0)
            current_jobs = count_webhook_jobs()
            elapsed = time.perf_counter() - processing_start
            if current_jobs is None:
                break
            if current_jobs <= before_webhooks:
                processing_duration = elapsed
                break
            if elapsed >= max_wait:
                processing_duration = elapsed
                break
    print("------------------------------------------------------------")
    print("RESUMEN HTTP")
    print("------------------------------------------------------------")
    print(f"Total requests: {results['total_requests']}")
    print(f"Success 200: {results['success']}")
    print(f"Unexpected 403: {results['unexpected_403']}")
    print(f"Error 500+: {results['error_500']}")
    print(f"Other errors: {results['other_errors']}")
    print(f"Average latency (ms): {results['avg_latency_ms']:.2f}")
    print(f"Total wall-clock time (s): {end_wall - start_wall:.2f}")
    print("------------------------------------------------------------")
    print("VALIDACION DE INFRAESTRUCTURA")
    print("------------------------------------------------------------")
    print(f"AuditLog entries delta: {audit_delta}")
    if before_webhooks is not None and after_webhooks is not None:
        print(f"Redis Webhook Jobs before: {before_webhooks}")
        print(f"Redis Webhook Jobs after:  {after_webhooks}")
        print(f"Redis Webhook Jobs delta:  {after_webhooks - before_webhooks}")
        if processing_duration is not None:
            print(
                f"Tiempo hasta procesar cola Webhooks (s): {processing_duration:.2f}"
            )
    else:
        print("Redis Webhook Jobs: Redis/task_queue no disponible")
    db_cleanup = SessionLocal()
    try:
        cleanup_stress_compras_data(db_cleanup)
    finally:
        db_cleanup.close()
        engine.dispose()
    print("------------------------------------------------------------")
    print("Stress test finalizado.")
    print("------------------------------------------------------------")


if __name__ == "__main__":
    run()
