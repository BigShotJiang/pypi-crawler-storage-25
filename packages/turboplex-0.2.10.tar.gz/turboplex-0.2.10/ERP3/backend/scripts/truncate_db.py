import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from sqlalchemy import text
from app.core.database import engine


def truncate_all_tables():
    print("Starting database truncation (Dev Mode)...")
    with engine.begin() as conn:
        # Get all table names in public schema
        result = conn.execute(
            text("SELECT tablename FROM pg_tables WHERE schemaname = 'public'")
        )
        tables = [row[0] for row in result.fetchall()]

        # Exclude alembic_version to preserve migration history
        if "alembic_version" in tables:
            tables.remove("alembic_version")

        if not tables:
            print("No business tables found to truncate.")
            return

        print(f"Found {len(tables)} tables to truncate.")

        # Truncate all tables with CASCADE
        # We use quotes to handle case sensitivity if any, though usually lowercase in PG
        tables_str = ", ".join([f'"{t}"' for t in tables])
        conn.execute(text(f"TRUNCATE TABLE {tables_str} CASCADE"))

        print("All business tables truncated successfully.")


if __name__ == "__main__":
    truncate_all_tables()
