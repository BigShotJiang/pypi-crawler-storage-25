import sys
import os

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.database import SessionLocal, Base, engine
from app.core.security import get_password_hash
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    UsuarioEmpresa,
    Sucursal,
    MetodoPago,
    Bodega,
    EmpresaMetodoPago,
    Rol,
)


def auto_onboarding():
    print("Starting Auto Onboarding...")

    # Ensure schema exists after reset
    try:
        Base.metadata.create_all(bind=engine)
    except Exception:
        pass
    db = SessionLocal()
    try:
        db.info["allow_no_tenant"] = True
    except Exception:
        pass

    try:
        # 1. Check if demo company exists
        demo_code = "DEMO"
        existing_company = db.query(Empresa).filter(Empresa.codigo == demo_code).first()

        if existing_company:
            print(
                f"Company {demo_code} already exists (ID: {existing_company.id}). Skipping creation."
            )
            return

        # 2. Create Demo Superadmin User
        email = "admin@demo.cl"
        password = "admin"

        user = db.query(Usuario).filter(Usuario.email == email).first()
        if not user:
            print(f"Creating user {email}...")
            user = Usuario(
                email=email,
                hashed_password=get_password_hash(password),
                role="SUPERADMIN",
                is_active=True,
            )
            db.add(user)
            db.commit()
            db.refresh(user)
            print(f"User created with ID: {user.id}")
        else:
            print(f"User {email} exists with ID: {user.id}")

        # 3. Create Company
        print("Creating company...")
        empresa = Empresa(
            nombre="Empresa Demo Limitada",
            codigo=demo_code,
            rut="76.123.456-7",
            modulos_activos=["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA"],
            pwr_bi_enabled=False,
            pwr_bi_config={},
        )
        db.add(empresa)
        db.commit()
        db.refresh(empresa)
        print(f"Company created with ID: {empresa.id}")

        # 4. Seed default roles for company
        existing_roles = {
            r.codigo for r in db.query(Rol).filter(Rol.empresa_id == empresa.id).all()
        }
        default_roles = [
            ("ADM", "Administrador Único de Empresa"),
            ("SUP", "Supervisor"),
            ("VEN", "Vendedor"),
            ("BOD", "Bodeguero"),
            ("CON", "Contador"),
        ]
        for codigo, nombre in default_roles:
            if codigo in existing_roles:
                continue
            rol = Rol(
                empresa_id=empresa.id,
                codigo=codigo,
                nombre=nombre,
                is_active=True,
            )
            db.add(rol)
        db.commit()

        # 5. Link User -> Company as ADM
        rol_adm = (
            db.query(Rol)
            .filter(Rol.empresa_id == empresa.id, Rol.codigo == "ADM")
            .first()
        )
        link = UsuarioEmpresa(
            usuario_id=user.id,
            empresa_id=empresa.id,
            rol_id=rol_adm.id if rol_adm else None,
            is_default=True,
        )
        db.add(link)

        # 6. Create Branch (Sucursal)
        sucursal = Sucursal(
            nombre="Casa Matriz",
            codigo=f"{demo_code}-MAT",
            direccion="Av. Demo 123",
            empresa_id=empresa.id,
        )
        db.add(sucursal)
        db.commit()
        db.refresh(sucursal)
        print(f"Branch created with ID: {sucursal.id}")

        # 7. Create Warehouse (Bodega)
        bodega = Bodega(
            nombre="Bodega Central",
            codigo=f"{demo_code}-BOD-01",
            sucursal_id=sucursal.id,
            is_active=True,
            is_deleted=False,
        )
        db.add(bodega)
        db.commit()
        db.refresh(bodega)
        print(f"Warehouse created with ID: {bodega.id}")

        # 8. Create Payment Methods (if needed)
        # Assuming MetodoPago table might be empty or pre-filled.
        # Let's create a default cash method if not exists
        efectivo = db.query(MetodoPago).filter(MetodoPago.codigo == "EFECTIVO").first()
        if not efectivo:
            efectivo = MetodoPago(nombre="Efectivo", codigo="EFECTIVO", is_active=True)
            db.add(efectivo)
            db.commit()
            db.refresh(efectivo)

        emp_metodo = EmpresaMetodoPago(
            empresa_id=empresa.id, metodo_pago_id=efectivo.id, is_active=True
        )
        db.add(emp_metodo)
        db.commit()
        print("Payment methods configured.")

        print("\nAuto Onboarding Completed Successfully!")
        print(f"Demo Superadmin User: {email} / {password}")
        print(f"Company ID (UUID): {empresa.id}")

    except Exception as e:
        db.rollback()
        print(f"Error during onboarding: {e}")
        raise e
    finally:
        db.close()


if __name__ == "__main__":
    auto_onboarding()
