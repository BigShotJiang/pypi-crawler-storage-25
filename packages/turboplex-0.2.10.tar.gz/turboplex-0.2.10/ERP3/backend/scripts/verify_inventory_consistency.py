import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from app.core.database import SessionLocal
from sqlalchemy import text

def check_integrity():
    session = SessionLocal()
    session.info["allow_no_tenant"] = True
    try:
        print(">>> Iniciando Verificación de Integridad de Inventario (SQL Directo)...")
        
        # 1. Verificar Inventarios Huérfanos (Sin Producto)
        result = session.execute(text("""
            SELECT count(*) FROM inventario i 
            LEFT JOIN productos p ON i.producto_id = p.id 
            WHERE p.id IS NULL
        """)).scalar()
        if result > 0:
            print(f"[ERROR] Se encontraron {result} registros de Inventario sin Producto asociado (Huérfanos).")
        else:
            print("[OK] No hay inventarios huérfanos de Producto.")

        # 2. Verificar Inventarios Huérfanos (Sin Bodega)
        result = session.execute(text("""
            SELECT count(*) FROM inventario i 
            LEFT JOIN bodegas b ON i.bodega_id = b.id 
            WHERE b.id IS NULL
        """)).scalar()
        if result > 0:
            print(f"[ERROR] Se encontraron {result} registros de Inventario sin Bodega asociada (Huérfanos).")
        else:
            print("[OK] No hay inventarios huérfanos de Bodega.")

        # 3. Verificar Stock Negativo (Alerta)
        result = session.execute(text("""
            SELECT count(*) FROM inventario 
            WHERE cantidad < 0 OR cantidad_reservada < 0
        """)).scalar()
        if result > 0:
            print(f"[WARN] Se encontraron {result} registros con stock físico o reservado negativo.")
        else:
            print("[OK] No hay stocks negativos.")

        # 4. Verificar Integridad de Movimientos (Sin Producto)
        result = session.execute(text("""
            SELECT count(*) FROM movimientos_stock m
            LEFT JOIN productos p ON m.producto_id = p.id
            WHERE p.id IS NULL
        """)).scalar()
        if result > 0:
            print(f"[ERROR] Se encontraron {result} movimientos sin Producto asociado.")
        else:
            print("[OK] Todos los movimientos tienen Producto válido.")

        # 5. Verificar Integridad de Movimientos (Sin Bodega)
        result = session.execute(text("""
            SELECT count(*) FROM movimientos_stock m
            LEFT JOIN bodegas b ON m.bodega_id = b.id
            WHERE b.id IS NULL
        """)).scalar()
        if result > 0:
            print(f"[ERROR] Se encontraron {result} movimientos sin Bodega asociada.")
        else:
            print("[OK] Todos los movimientos tienen Bodega válida.")

        print(">>> Verificación Completada.")
        
    except Exception as e:
        print(f"[CRITICAL] Error durante la verificación: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    check_integrity()
