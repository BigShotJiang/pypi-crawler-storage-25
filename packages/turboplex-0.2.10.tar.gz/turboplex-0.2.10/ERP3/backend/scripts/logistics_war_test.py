import os
import time
import random
import uuid
from collections import defaultdict
from typing import List, Tuple, Dict, Optional
from pathlib import Path
import sys
from concurrent.futures import ThreadPoolExecutor
import threading
from decimal import Decimal, ROUND_HALF_UP

from dotenv import load_dotenv
from sqlalchemy import create_engine, func
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import IntegrityError, OperationalError

backend_root = Path(__file__).resolve().parents[1]
if str(backend_root) not in sys.path:
    sys.path.insert(0, str(backend_root))

load_dotenv(backend_root / ".env")
STRESS_DB_URL = os.getenv("TEST_DATABASE_URL") or os.getenv("DATABASE_URL")
if "TEST_DATABASE_URL" in os.environ:
    os.environ.pop("TEST_DATABASE_URL")

from app.models import Empresa, Usuario, UsuarioEmpresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto, Inventario
from app.core_modules.finanzas.models import AsientoContable, MovimientoContable, CuentaContable


def get_engine_and_sessionmaker():
    db_url = STRESS_DB_URL
    if not db_url:
        raise RuntimeError("DATABASE_URL or TEST_DATABASE_URL must be set for logistics war test")
    if db_url.startswith("postgresql+psycopg2://"):
        db_url = db_url.replace("postgresql+psycopg2://", "postgresql://")
    engine = create_engine(db_url, future=True, isolation_level="SERIALIZABLE")
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    return engine, SessionLocal


def cleanup_logistics_products(db: Session):
    productos = (
        db.query(Producto)
        .filter(Producto.nombre.like("LOGI_PROD_%"))
        .all()
    )
    if not productos:
        return
    producto_ids = [p.id for p in productos]
    db.query(Inventario).filter(Inventario.producto_id.in_(producto_ids)).delete(
        synchronize_session=False
    )
    db.query(Producto).filter(Producto.id.in_(producto_ids)).delete(
        synchronize_session=False
    )
    db.flush()


def cleanup_logistics_movements(db: Session):
    lateral_asientos_ids = [
        row.id
        for row in db.query(AsientoContable.id).filter(
            AsientoContable.glosa.like("LOGI_LATERAL%")
        )
    ]
    if not lateral_asientos_ids:
        return
    db.query(MovimientoContable).filter(
        MovimientoContable.asiento_id.in_(lateral_asientos_ids)
    ).delete(synchronize_session=False)
    db.query(AsientoContable).filter(
        AsientoContable.id.in_(lateral_asientos_ids)
    ).delete(synchronize_session=False)
    db.flush()


def get_or_create_empresa(db: Session, nombre: str, rut_base: int) -> Empresa:
    empresa = db.query(Empresa).filter(Empresa.nombre == nombre).first()
    if empresa:
        return empresa
    rut = f"{rut_base}-{rut_base % 10}"
    codigo = nombre.replace("LOGI_", "")[:10]
    empresa = Empresa(nombre=nombre, rut=rut, codigo=codigo, is_active=True)
    db.add(empresa)
    db.flush()
    return empresa


def get_or_create_sucursal_bodega(db: Session, empresa: Empresa) -> Tuple[Sucursal, Bodega]:
    sucursal = (
        db.query(Sucursal)
        .filter(Sucursal.empresa_id == empresa.id)
        .order_by(Sucursal.id.asc())
        .first()
    )
    if not sucursal:
        sucursal = Sucursal(
            nombre=f"SUC_{empresa.nombre}",
            empresa_id=empresa.id,
            direccion="LOGI_TEST",
        )
        db.add(sucursal)
        db.flush()
    bodega = (
        db.query(Bodega)
        .filter(Bodega.sucursal_id == sucursal.id)
        .order_by(Bodega.id.asc())
        .first()
    )
    if not bodega:
        bodega = Bodega(
            nombre=f"BOD_{empresa.nombre}",
            sucursal_id=sucursal.id,
        )
        db.add(bodega)
        db.flush()
    return sucursal, bodega


def get_or_create_master_user(db: Session) -> Usuario:
    email = "logistics_master@holding.test"
    user = db.query(Usuario).filter(Usuario.email == email).first()
    if user:
        return user
    user = Usuario(
        email=email,
        hashed_password="not_used_logistics",
        is_active=True,
        role="ADMIN",
    )
    db.add(user)
    db.flush()
    return user


def bootstrap_logistics_companies(db: Session):
    cleanup_logistics_products(db)
    hub_names = ["LOGI_HUB_ALFA", "LOGI_HUB_BETA", "LOGI_HUB_GAMMA"]
    store_names = [f"LOGI_TIENDA_{i:02d}" for i in range(1, 10)]
    hubs: List[Empresa] = []
    stores: List[Empresa] = []
    base_rut = 7700000
    for idx, name in enumerate(hub_names, start=1):
        empresa = get_or_create_empresa(db, name, base_rut + idx)
        hubs.append(empresa)
    for idx, name in enumerate(store_names, start=1):
        empresa = get_or_create_empresa(db, name, base_rut + 100 + idx)
        stores.append(empresa)
    hub_bodegas: Dict[uuid.UUID, uuid.UUID] = {}
    store_bodegas: Dict[uuid.UUID, uuid.UUID] = {}
    for hub in hubs:
        _, bodega = get_or_create_sucursal_bodega(db, hub)
        hub_bodegas[hub.id] = bodega.id
    for store in stores:
        _, bodega = get_or_create_sucursal_bodega(db, store)
        store_bodegas[store.id] = bodega.id
    master_user = get_or_create_master_user(db)
    for empresa in hubs + stores:
        link = (
            db.query(UsuarioEmpresa)
            .filter(
                UsuarioEmpresa.usuario_id == master_user.id,
                UsuarioEmpresa.empresa_id == empresa.id,
            )
            .first()
        )
        if not link:
            link = UsuarioEmpresa(usuario_id=master_user.id, empresa_id=empresa.id)
            db.add(link)
    return hubs, stores, hub_bodegas, store_bodegas, master_user


def create_logistics_catalog_and_stock(
    db: Session,
    hubs: List[Empresa],
    hub_bodegas: Dict[uuid.UUID, uuid.UUID],
):
    total_created = 0
    hub_codes = {
        hubs[0].id: "ALFA",
        hubs[1].id: "BETA",
        hubs[2].id: "GAMMA",
    }
    for hub in hubs:
        code = hub_codes[hub.id]
        bodega_id = hub_bodegas[hub.id]
        for i in range(1, 201):
            name = f"LOGI_PROD_{code}_{i:03d}"
            sku = f"LOGI-{code}-{i:03d}"
            producto = (
                db.query(Producto)
                .filter(Producto.empresa_id == hub.id, Producto.sku == sku)
                .first()
            )
            if not producto:
                producto = Producto(
                    nombre=name,
                    sku=sku,
                    precio=random.randint(1000, 100000) / 100,
                    tipo_producto="ALMACENABLE",
                    empresa_id=hub.id,
                    is_active=True,
                )
                db.add(producto)
                db.flush()
                total_created += 1
            inv = (
                db.query(Inventario)
                .filter(
                    Inventario.producto_id == producto.id,
                    Inventario.bodega_id == bodega_id,
                )
                .first()
            )
            if not inv:
                if code == "GAMMA":
                    cantidad = 20
                else:
                    cantidad = random.randint(1000, 5000)
                inv = Inventario(
                    producto_id=producto.id,
                    bodega_id=bodega_id,
                    cantidad=cantidad,
                    cantidad_reservada=0,
                )
                db.add(inv)
    print(f"Logistics catalog products created: {total_created}")


def ensure_account(
    db: Session,
    empresa_id: uuid.UUID,
    codigo: str,
    nombre: str,
) -> CuentaContable:
    cuenta = (
        db.query(CuentaContable)
        .filter(
            CuentaContable.empresa_id == empresa_id,
            CuentaContable.codigo == codigo,
        )
        .first()
    )
    if cuenta:
        return cuenta
    try:
        cuenta = CuentaContable(
            codigo=codigo,
            nombre=nombre,
            tipo_cuenta="OTROS",
            nivel=4,
            es_imputable=True,
            empresa_id=empresa_id,
        )
        db.add(cuenta)
        db.flush()
        return cuenta
    except IntegrityError:
        db.rollback()
        cuenta = (
            db.query(CuentaContable)
            .filter(
                CuentaContable.empresa_id == empresa_id,
                CuentaContable.codigo == codigo,
            )
            .first()
        )
        if not cuenta:
            raise
        return cuenta


def get_master_user(db: Session) -> Optional[Usuario]:
    email = "logistics_master@holding.test"
    return db.query(Usuario).filter(Usuario.email == email).first()


def get_or_create_product_for_empresa(
    db: Session,
    empresa_id: uuid.UUID,
    sku: str,
    template: Producto,
) -> Producto:
    prod = (
        db.query(Producto)
        .filter(Producto.empresa_id == empresa_id, Producto.sku == sku)
        .first()
    )
    if prod:
        return prod
    try:
        prod = Producto(
            nombre=template.nombre,
            sku=sku,
            precio=template.precio,
            tipo_producto=template.tipo_producto,
            empresa_id=empresa_id,
            is_active=True,
        )
        db.add(prod)
        db.flush()
        return prod
    except IntegrityError:
        db.rollback()
        prod = (
            db.query(Producto)
            .filter(Producto.empresa_id == empresa_id, Producto.sku == sku)
            .first()
        )
        if not prod:
            raise
        return prod


def find_stock_candidate(
    db: Session,
    empresa_ids: List[uuid.UUID],
    sku: str,
    min_qty: int,
) -> Optional[Tuple[uuid.UUID, uuid.UUID]]:
    for empresa_id in empresa_ids:
        inv = (
            db.query(Inventario)
            .join(Producto, Inventario.producto_id == Producto.id)
            .join(Bodega, Inventario.bodega_id == Bodega.id)
            .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
            .filter(
                Sucursal.empresa_id == empresa_id,
                Producto.sku == sku,
                Inventario.cantidad >= min_qty,
            )
            .order_by(func.random())
            .first()
        )
        if inv:
            return empresa_id, inv.bodega_id
    return None


def find_stock_in_holding(
    db: Session,
    sku: str,
    empresa_tienda_id: uuid.UUID,
    hub_ids: List[uuid.UUID],
    store_ids: List[uuid.UUID],
    min_qty: int,
) -> Optional[Tuple[uuid.UUID, uuid.UUID, str]]:
    own_candidate = find_stock_candidate(db, [empresa_tienda_id], sku, min_qty)
    if own_candidate:
        empresa_id, bodega_id = own_candidate
        return empresa_id, bodega_id, "SELF"
    hub_candidate = find_stock_candidate(db, hub_ids, sku, min_qty)
    if hub_candidate:
        empresa_id, bodega_id = hub_candidate
        return empresa_id, bodega_id, "HUB"
    other_stores = [e for e in store_ids if e != empresa_tienda_id]
    if other_stores:
        store_candidate = find_stock_candidate(db, other_stores, sku, min_qty)
        if store_candidate:
            empresa_id, bodega_id = store_candidate
            return empresa_id, bodega_id, "STORE"
    return None


def execute_lateral_transfer(
    db: Session,
    empresa_origen_id: uuid.UUID,
    bodega_origen_id: uuid.UUID,
    empresa_destino_id: uuid.UUID,
    bodega_destino_id: uuid.UUID,
    sku: str,
    cantidad: int,
    source_kind: str,
) -> bool:
    master_user = get_master_user(db)
    if not master_user:
        raise RuntimeError("Missing master user for logistics transfer")
    prod_origen = (
        db.query(Producto)
        .filter(Producto.empresa_id == empresa_origen_id, Producto.sku == sku)
        .first()
    )
    if not prod_origen:
        raise RuntimeError("Origin product not found for logistics transfer")
    prod_destino = get_or_create_product_for_empresa(db, empresa_destino_id, sku, prod_origen)
    inv_origen = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == prod_origen.id,
            Inventario.bodega_id == bodega_origen_id,
        )
        .with_for_update()
        .first()
    )
    if not inv_origen or inv_origen.cantidad < cantidad:
        raise RuntimeError("Insufficient origin stock for logistics transfer")
    inv_destino = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == prod_destino.id,
            Inventario.bodega_id == bodega_destino_id,
        )
        .with_for_update()
        .first()
    )
    if not inv_destino:
        inv_destino = Inventario(
            producto_id=prod_destino.id,
            bodega_id=bodega_destino_id,
            cantidad=0,
            cantidad_reservada=0,
        )
    base_cost_unit = (Decimal(prod_origen.precio) * Decimal("0.6")).quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )
    base_cost = (base_cost_unit * Decimal(cantidad)).quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )
    if source_kind == "STORE":
        transfer_cost = (base_cost * Decimal("1.2")).quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP,
        )
    else:
        transfer_cost = base_cost
    inv_origen.cantidad -= cantidad
    inv_destino.cantidad += cantidad
    db.add(inv_origen)
    db.add(inv_destino)
    cuenta_inv_origen = ensure_account(
        db,
        empresa_origen_id,
        "1.9.50",
        "Inventario Logística",
    )
    cuenta_interco_origen = ensure_account(
        db,
        empresa_origen_id,
        "8.9.50",
        "Intercompany Logística",
    )
    cuenta_ingreso_interco = ensure_account(
        db,
        empresa_origen_id,
        "7.9.50",
        "Ingreso Intercompany Logística",
    )
    cuenta_inv_destino = ensure_account(
        db,
        empresa_destino_id,
        "1.9.50",
        "Inventario Logística",
    )
    cuenta_interco_destino = ensure_account(
        db,
        empresa_destino_id,
        "8.9.50",
        "Intercompany Logística",
    )
    asiento_origen = AsientoContable(
        glosa=f"LOGI_LATERAL_OUT_{sku}",
        origen="LOGI_LATERAL_OUT",
        origen_id=str(prod_origen.id),
        estado="CONFIRMADO",
        empresa_id=empresa_origen_id,
        usuario_id=master_user.id,
    )
    db.add(asiento_origen)
    db.flush()
    mov_interco_cargo = MovimientoContable(
        asiento_id=asiento_origen.id,
        cuenta_id=cuenta_interco_origen.id,
        debe=base_cost,
        haber=Decimal("0.00"),
    )
    mov_inv_credito = MovimientoContable(
        asiento_id=asiento_origen.id,
        cuenta_id=cuenta_inv_origen.id,
        debe=Decimal("0.00"),
        haber=base_cost,
    )
    db.add(mov_interco_cargo)
    db.add(mov_inv_credito)
    if transfer_cost > base_cost:
        spread = (transfer_cost - base_cost).quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP,
        )
        mov_interco_spread = MovimientoContable(
            asiento_id=asiento_origen.id,
            cuenta_id=cuenta_interco_origen.id,
            debe=spread,
            haber=Decimal("0.00"),
        )
        mov_ingreso = MovimientoContable(
            asiento_id=asiento_origen.id,
            cuenta_id=cuenta_ingreso_interco.id,
            debe=Decimal("0.00"),
            haber=spread,
        )
        db.add(mov_interco_spread)
        db.add(mov_ingreso)
    asiento_destino = AsientoContable(
        glosa=f"LOGI_LATERAL_IN_{sku}",
        origen="LOGI_LATERAL_IN",
        origen_id=str(prod_destino.id),
        estado="CONFIRMADO",
        empresa_id=empresa_destino_id,
        usuario_id=master_user.id,
    )
    db.add(asiento_destino)
    db.flush()
    mov_inv_debe = MovimientoContable(
        asiento_id=asiento_destino.id,
        cuenta_id=cuenta_inv_destino.id,
        debe=transfer_cost,
        haber=Decimal("0.00"),
    )
    mov_interco_haber = MovimientoContable(
        asiento_id=asiento_destino.id,
        cuenta_id=cuenta_interco_destino.id,
        debe=Decimal("0.00"),
        haber=transfer_cost,
    )
    db.add(mov_inv_debe)
    db.add(mov_interco_haber)
    return True


def simulate_retail_order(
    db: Session,
    tienda_ids: List[uuid.UUID],
    hub_ids: List[uuid.UUID],
    store_bodegas: Dict[uuid.UUID, uuid.UUID],
) -> Tuple[bool, bool]:
    if not tienda_ids:
        return False, False
    tienda_id = random.choice(tienda_ids)
    producto_hub = (
        db.query(Producto)
        .filter(Producto.empresa_id.in_(hub_ids), Producto.nombre.like("LOGI_PROD_%"))
        .order_by(func.random())
        .first()
    )
    if not producto_hub:
        return False, False
    sku = producto_hub.sku
    cantidad = random.randint(1, 5)
    candidato_prop = find_stock_candidate(db, [tienda_id], sku, cantidad)
    if candidato_prop:
        empresa_id, bodega_id = candidato_prop
        inv = (
            db.query(Inventario)
            .filter(
                Inventario.producto_id == producto_hub.id,
                Inventario.bodega_id == bodega_id,
            )
            .with_for_update()
            .first()
        )
        if inv and inv.cantidad >= cantidad:
            inv.cantidad -= cantidad
            db.add(inv)
            db.flush()
            return True, False
    candidate = find_stock_in_holding(
        db,
        sku,
        tienda_id,
        hub_ids,
        tienda_ids,
        cantidad,
    )
    if not candidate:
        return False, False
    empresa_origen_id, bodega_origen_id, source_kind = candidate
    bodega_destino_id = store_bodegas[tienda_id]
    execute_lateral_transfer(
        db,
        empresa_origen_id,
        bodega_origen_id,
        tienda_id,
        bodega_destino_id,
        sku,
        cantidad,
        source_kind,
    )
    return True, True


def verify_logistics_intercompany_balances(db: Session, empresa_ids: List[uuid.UUID]):
    movimientos = (
        db.query(MovimientoContable, AsientoContable, CuentaContable)
        .join(AsientoContable, MovimientoContable.asiento_id == AsientoContable.id)
        .join(CuentaContable, MovimientoContable.cuenta_id == CuentaContable.id)
        .filter(
            AsientoContable.empresa_id.in_(empresa_ids),
            CuentaContable.codigo == "8.9.50",
            AsientoContable.glosa.like("LOGI_LATERAL_%"),
        )
        .all()
    )
    balances: Dict[uuid.UUID, Decimal] = defaultdict(lambda: Decimal("0.00"))
    for mov, asiento, cuenta in movimientos:
        empresa_id = asiento.empresa_id
        debe = Decimal(mov.debe or 0)
        haber = Decimal(mov.haber or 0)
        balances[empresa_id] += debe - haber
    total = sum(balances.values(), Decimal("0.00"))
    print("Logistics intercompany balances per empresa (debe - haber):")
    for emp_id, saldo in balances.items():
        print(f"  Empresa {emp_id}: {saldo:.2f}")
    print(f"Logistics intercompany global balance: {total:.2f}")
    if abs(total) < Decimal("0.01"):
        print("OK: Logistics intercompany accounts globally balanced.")
    else:
        print("WARNING: Logistics intercompany accounts not balanced at holding level.")


def count_hub_exhaustion(db: Session, hubs: List[Empresa]) -> int:
    exhausted = 0
    for hub in hubs:
        total_stock = (
            db.query(func.sum(Inventario.cantidad))
            .join(Producto, Inventario.producto_id == Producto.id)
            .filter(
                Producto.empresa_id == hub.id,
                Producto.nombre.like("LOGI_PROD_%"),
            )
            .scalar()
            or 0
        )
        if total_stock == 0:
            exhausted += 1
    return exhausted


def run_logistics_war(
    SessionLocal,
    hub_ids: List[uuid.UUID],
    store_ids: List[uuid.UUID],
    hub_bodegas: Dict[uuid.UUID, uuid.UUID],
    store_bodegas: Dict[uuid.UUID, uuid.UUID],
):
    bursts = [8000, 16000, 32000]
    for total in bursts:
        stats = {
            "orders": 0,
            "success": 0,
            "lateral": 0,
        }
        lock = threading.Lock()

        def worker():
            db = SessionLocal()
            db.info["allow_no_tenant"] = True
            try:
                ok, lateral = False, False
                for attempt in range(5):
                    try:
                        ok, lateral = simulate_retail_order(db, store_ids, hub_ids, store_bodegas)
                        if ok:
                            db.commit()
                        else:
                            db.rollback()
                        break
                    except OperationalError as e:
                        msg = str(e)
                        if "could not serialize access" in msg:
                            db.rollback()
                            db.expunge_all()
                            time.sleep(random.uniform(0.01, 0.05))
                            continue
                        db.rollback()
                        raise
                    except Exception:
                        db.rollback()
                        ok, lateral = False, False
                        break
                with lock:
                    stats["orders"] += 1
                    if ok:
                        stats["success"] += 1
                    if lateral and ok:
                        stats["lateral"] += 1
            except Exception:
                pass
            finally:
                db.close()

        print(f"=== Logistics Burst {total} orders ===")
        start = time.perf_counter()
        with ThreadPoolExecutor(max_workers=8) as executor:
            for _ in range(total):
                executor.submit(worker)
        end = time.perf_counter()
        elapsed = end - start
        print(f"Total orders: {stats['orders']}")
        print(f"Successful orders: {stats['success']}")
        print(f"Lost orders: {stats['orders'] - stats['success']}")
        print(f"Total Lateral Transfers: {stats['lateral']}")
        print(f"Burst time (s): {elapsed:.2f}")
        db = SessionLocal()
        db.info["allow_no_tenant"] = True
        hubs = db.query(Empresa).filter(Empresa.id.in_(hub_ids)).all()
        exhausted_hubs = count_hub_exhaustion(db, hubs)
        print(f"Hub Exhaustion: {exhausted_hubs} hubs fully out of exclusive stock")
        verify_logistics_intercompany_balances(db, hub_ids + store_ids)
        db.close()
        print("Cooling down 10 seconds...")
        time.sleep(10)


def main():
    engine, SessionLocal = get_engine_and_sessionmaker()
    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        print("Bootstrapping logistics companies...")
        with db.begin():
            hubs, stores, hub_bodegas, store_bodegas, master_user = bootstrap_logistics_companies(db)
            print("Creating logistics catalog and initial stock...")
            create_logistics_catalog_and_stock(db, hubs, hub_bodegas)
            print("Cleaning previous logistics lateral movements...")
            cleanup_logistics_movements(db)
            hub_ids = [h.id for h in hubs]
            store_ids = [s.id for s in stores]
    finally:
        db.close()
    try:
        run_logistics_war(SessionLocal, hub_ids, store_ids, hub_bodegas, store_bodegas)
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()
