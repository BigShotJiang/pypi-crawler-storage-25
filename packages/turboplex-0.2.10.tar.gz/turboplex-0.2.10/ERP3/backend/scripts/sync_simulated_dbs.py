from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from sqlalchemy.engine.url import make_url


def _try_load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    backend_root = Path(__file__).resolve().parents[1]
    env_path = backend_root / ".env"
    if env_path.exists():
        load_dotenv(env_path)


def _resolve_tool_path(tool: str, *, explicit: str | None, pg_bin: str | None) -> str:
    if explicit:
        return explicit
    env_key = f"PG_{tool.upper()}_PATH"
    env_value = os.getenv(env_key)
    if env_value:
        return env_value
    if pg_bin:
        candidate = str(Path(pg_bin) / f"{tool}.exe")
        return candidate
    return tool


def _safe_url(url: str) -> str:
    return make_url(url).render_as_string(hide_password=True)


def _as_libpq_url(url: str) -> str:
    parsed = make_url(url)
    if parsed.get_backend_name() == "postgresql":
        try:
            parsed = parsed.set(drivername="postgresql")
        except Exception:
            rendered = parsed.render_as_string(hide_password=False)
            return rendered.replace("postgresql+psycopg2://", "postgresql://")
    return parsed.render_as_string(hide_password=False)


def _run(cmd: list[str]) -> None:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        stdout = (proc.stdout or "").strip()
        stderr = (proc.stderr or "").strip()
        details = "\n".join(x for x in (stdout, stderr) if x)
        raise RuntimeError(details or f"Command failed: {' '.join(cmd)}")


def main() -> int:
    _try_load_dotenv()
    parser = argparse.ArgumentParser(
        prog="sync_simulated_dbs",
        description="Clona esquema+datos desde DATABASE_URL hacia REPLICA_DATABASE_URL (simulacro HA local).",
    )
    parser.add_argument(
        "--source-url",
        default=os.getenv("DATABASE_URL", ""),
        help="URL origen (master). Si se omite, usa env DATABASE_URL.",
    )
    parser.add_argument(
        "--dest-url",
        default=os.getenv("REPLICA_DATABASE_URL", ""),
        help="URL destino (replica). Si se omite, usa env REPLICA_DATABASE_URL.",
    )
    parser.add_argument(
        "--pg-dump",
        default=None,
        help="Ruta explícita a pg_dump.exe (override).",
    )
    parser.add_argument(
        "--pg-restore",
        default=None,
        help="Ruta explícita a pg_restore.exe (override).",
    )
    parser.add_argument(
        "--pg-bin",
        default=os.getenv("POSTGRES_BIN", None),
        help="Directorio bin/ de PostgreSQL (ej: C:\\Program Files\\PostgreSQL\\15\\bin).",
    )
    parser.add_argument(
        "--schema-only",
        action="store_true",
        help="Clona solo esquema (sin datos).",
    )
    args = parser.parse_args()

    if not args.source_url or not args.dest_url:
        print("Falta source/dest URL. Usa --source-url/--dest-url o variables env.", file=sys.stderr)
        return 2

    pg_dump = _resolve_tool_path("pg_dump", explicit=args.pg_dump, pg_bin=args.pg_bin)
    pg_restore = _resolve_tool_path(
        "pg_restore", explicit=args.pg_restore, pg_bin=args.pg_bin
    )

    safe_source = _safe_url(args.source_url)
    safe_dest = _safe_url(args.dest_url)
    print(f"Origen:  {safe_source}")
    print(f"Destino: {safe_dest}")
    print(f"pg_dump: {pg_dump}")
    print(f"pg_restore: {pg_restore}")

    libpq_source_url = _as_libpq_url(args.source_url)
    libpq_dest_url = _as_libpq_url(args.dest_url)

    with tempfile.TemporaryDirectory() as tmpdir:
        dump_file = str(Path(tmpdir) / "erp3_master.dump")

        dump_cmd = [
            pg_dump,
            "--format=custom",
            "--no-owner",
            "--no-privileges",
            f"--file={dump_file}",
            libpq_source_url,
        ]
        if args.schema_only:
            dump_cmd.insert(1, "--schema-only")

        restore_cmd = [
            pg_restore,
            "--clean",
            "--if-exists",
            "--no-owner",
            "--no-privileges",
            f"--dbname={libpq_dest_url}",
            dump_file,
        ]

        print("Ejecutando dump...")
        _run(dump_cmd)
        print("Ejecutando restore...")
        _run(restore_cmd)
        print("OK: réplica sincronizada (simulacro).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
