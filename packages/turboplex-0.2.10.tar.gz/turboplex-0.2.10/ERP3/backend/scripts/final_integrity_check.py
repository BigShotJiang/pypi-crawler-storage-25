import sys
import os
import time
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.config import settings
from app.models import Empresa


def check_integrity():
    print("Running Final Integrity Check (UUIDv7 Chronology)...")

    engine = create_engine(str(settings.DATABASE_URL))
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        # Create 3 companies with a small delay
        ids = []
        for i in range(3):
            emp = Empresa(
                nombre=f"Test Chrono {i}", codigo=f"TEST-{i}", modulos_activos=[]
            )
            session.add(emp)
            session.commit()
            session.refresh(emp)
            ids.append(emp.id)
            print(f"Created {i}: {emp.id}")
            time.sleep(0.1)  # Ensure measurable time difference

        # Verify order
        # UUIDv7 are sortable as strings or bytes
        sorted_ids = sorted(ids)
        if ids == sorted_ids:
            print("SUCCESS: UUIDs are chronologically ordered.")
        else:
            print("FAILURE: UUIDs are NOT in order.")
            print(f"Original: {ids}")
            print(f"Sorted:   {sorted_ids}")

        # Clean up
        for i in ids:
            session.execute(text(f"DELETE FROM empresas WHERE id = '{i}'"))
        session.commit()
        print("Cleanup completed.")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        session.close()


if __name__ == "__main__":
    from sqlalchemy import text

    check_integrity()
