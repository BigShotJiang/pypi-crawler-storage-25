import os
import glob

versions_dir = r"e:\ERP3\backend\alembic\versions"
files = glob.glob(os.path.join(versions_dir, "*.py"))

print(f"Deleting {len(files)} migration files...")
for f in files:
    try:
        os.remove(f)
        print(f"Deleted {os.path.basename(f)}")
    except Exception as e:
        print(f"Error deleting {f}: {e}")

print("Cleanup complete.")
