import os
import time
import random
import uuid
from collections import defaultdict
from typing import List, Tuple, Dict
from pathlib import Path
import sys
from concurrent.futures import ThreadPoolExecutor
import threading

from dotenv import load_dotenv
from sqlalchemy import create_engine, func
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import OperationalError, IntegrityError

backend_root = Path(__file__).resolve().parents[1]
if str(backend_root) not in sys.path:
    sys.path.insert(0, str(backend_root))

load_dotenv(backend_root / ".env")
STRESS_DB_URL = os.getenv("TEST_DATABASE_URL") or os.getenv("DATABASE_URL")
if "TEST_DATABASE_URL" in os.environ:
    os.environ.pop("TEST_DATABASE_URL")

from app.models import Empresa, Usuario, UsuarioEmpresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto, Inventario
from app.core_modules.finanzas.models import AsientoContable, MovimientoContable, CuentaContable


def get_engine_and_sessionmaker():
    db_url = STRESS_DB_URL
    if not db_url:
        raise RuntimeError("DATABASE_URL or TEST_DATABASE_URL must be set for stress test")
    if db_url.startswith("postgresql+psycopg2://"):
        db_url = db_url.replace("postgresql+psycopg2://", "postgresql://")
    engine = create_engine(db_url, future=True)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    return engine, SessionLocal


def cleanup_stress_data(db: Session):
    empresas = (
        db.query(Empresa)
        .filter(Empresa.nombre.like("STRESS_EMPRESA_%"))
        .all()
    )
    if not empresas:
        return
    empresa_ids = [e.id for e in empresas]
    productos = (
        db.query(Producto)
        .filter(Producto.nombre.like("STRESS_PROD_%"), Producto.empresa_id.in_(empresa_ids))
        .all()
    )
    producto_ids = [p.id for p in productos]
    if producto_ids:
        db.query(Inventario).filter(Inventario.producto_id.in_(producto_ids)).delete(
            synchronize_session=False
        )
    bodegas = (
        db.query(Bodega)
        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
        .filter(Bodega.nombre.like("STRESS_BOD_%"), Sucursal.empresa_id.in_(empresa_ids))
        .all()
    )
    bodega_ids = [b.id for b in bodegas]
    if bodegas:
        db.query(Bodega).filter(Bodega.id.in_(bodega_ids)).delete(synchronize_session=False)
    if productos:
        db.query(Producto).filter(Producto.id.in_(producto_ids)).delete(
            synchronize_session=False
        )
    db.commit()


def bootstrap_companies_and_holding(db: Session) -> Tuple[List[Empresa], List[Empresa], Usuario]:
    cleanup_stress_data(db)
    empresas: List[Empresa] = []
    for idx in range(1, 13):
        nombre = f"STRESS_EMPRESA_{idx}"
        empresa = db.query(Empresa).filter(Empresa.nombre == nombre).first()
        if not empresa:
            rut = f"{7600000 + idx}-{idx % 10}"
            codigo = f"STRESS_{idx:02d}"
            empresa = Empresa(nombre=nombre, rut=rut, codigo=codigo, is_active=True)
            db.add(empresa)
            db.flush()
        empresas.append(empresa)
    db.commit()
    for empresa in empresas:
        suc = (
            db.query(Sucursal)
            .filter(Sucursal.empresa_id == empresa.id)
            .order_by(Sucursal.id.asc())
            .first()
        )
        if not suc:
            suc = Sucursal(
                nombre=f"SUC_STRESS_{empresa.nombre}",
                empresa_id=empresa.id,
                direccion="TEST",
            )
            db.add(suc)
    db.commit()
    holding_empresas = empresas[:4]
    master_email = "stress_master@holding.test"
    master_user = db.query(Usuario).filter(Usuario.email == master_email).first()
    if not master_user:
        master_user = Usuario(
            email=master_email,
            hashed_password="not_used_stress",
            is_active=True,
            role="ADMIN",
        )
        db.add(master_user)
        db.flush()
    for empresa in holding_empresas:
        link = (
            db.query(UsuarioEmpresa)
            .filter(
                UsuarioEmpresa.usuario_id == master_user.id,
                UsuarioEmpresa.empresa_id == empresa.id,
            )
            .first()
        )
        if not link:
            link = UsuarioEmpresa(usuario_id=master_user.id, empresa_id=empresa.id)
            db.add(link)
    db.commit()
    return empresas, holding_empresas, master_user


def distribute_warehouses(empresas: List[Empresa]) -> Dict[uuid.UUID, int]:
    distribution = [15, 10, 10, 8, 8, 7, 6, 6, 4, 3, 2, 1]
    mapping: Dict[uuid.UUID, int] = {}
    for empresa, count in zip(empresas, distribution):
        mapping[empresa.id] = count
    return mapping


def create_warehouses_and_inventory(db: Session, empresas: List[Empresa]):
    distribution = distribute_warehouses(empresas)
    for empresa in empresas:
        sucursal = (
            db.query(Sucursal)
            .filter(Sucursal.empresa_id == empresa.id)
            .order_by(Sucursal.id.asc())
            .first()
        )
        bodega_count = distribution.get(empresa.id, 1)
        bodegas: List[Bodega] = []
        for i in range(bodega_count):
            nombre = f"STRESS_BOD_{empresa.id}_{i+1}"
            bodega = db.query(Bodega).filter(Bodega.nombre == nombre).first()
            if not bodega:
                bodega = Bodega(
                    nombre=nombre,
                    sucursal_id=sucursal.id,
                )
                db.add(bodega)
                db.flush()
            bodegas.append(bodega)
        for i in range(500):
            prod_name = f"STRESS_PROD_{empresa.id}_{i+1}"
            sku = f"STRESSSKU-{empresa.id}-{i+1}"
            producto = (
                db.query(Producto)
                .filter(Producto.sku == sku, Producto.empresa_id == empresa.id)
                .first()
            )
            if not producto:
                producto = Producto(
                    nombre=prod_name,
                    sku=sku,
                    precio=random.randint(1000, 100000) / 100,
                    tipo_producto="ALMACENABLE",
                    empresa_id=empresa.id,
                    is_active=True,
                )
                db.add(producto)
                db.flush()
            for bodega in bodegas:
                inv = (
                    db.query(Inventario)
                    .filter(
                        Inventario.producto_id == producto.id,
                        Inventario.bodega_id == bodega.id,
                    )
                    .first()
                )
                if not inv:
                    inv = Inventario(
                        producto_id=producto.id,
                        bodega_id=bodega.id,
                        cantidad=random.randint(1000, 5000),
                        cantidad_reservada=0,
                    )
                    db.add(inv)
        db.commit()


def ensure_intercompany_account(db: Session, empresa_id: uuid.UUID) -> CuentaContable:
    cuenta = (
        db.query(CuentaContable)
        .filter(
            CuentaContable.empresa_id == empresa_id,
            CuentaContable.codigo == "8.9.99",
        )
        .first()
    )
    if cuenta:
        return cuenta
    cuenta = CuentaContable(
        codigo="8.9.99",
        nombre="Intercompañía Holding Stress",
        tipo_cuenta="OTROS",
        nivel=4,
        es_imputable=True,
        empresa_id=empresa_id,
    )
    db.add(cuenta)
    db.flush()
    db.commit()
    return cuenta


def ensure_account(
    db: Session,
    empresa_id: uuid.UUID,
    codigo: str,
    nombre: str,
) -> CuentaContable:
    cuenta = (
        db.query(CuentaContable)
        .filter(
            CuentaContable.empresa_id == empresa_id,
            CuentaContable.codigo == codigo,
        )
        .first()
    )
    if cuenta:
        return cuenta
    cuenta = CuentaContable(
        codigo=codigo,
        nombre=nombre,
        tipo_cuenta="OTROS",
        nivel=4,
        es_imputable=True,
        empresa_id=empresa_id,
    )
    db.add(cuenta)
    db.flush()
    return cuenta


def pick_random_product_for_company(db: Session, empresa_id: uuid.UUID) -> Producto:
    return (
        db.query(Producto)
        .filter(
            Producto.empresa_id == empresa_id,
            Producto.nombre.like("STRESS_PROD_%"),
        )
        .order_by(func.random())
        .first()
    )


def pick_bodega_with_stock(db: Session, empresa_id: uuid.UUID, producto_id: uuid.UUID) -> Bodega:
    inv = (
        db.query(Inventario)
        .join(Bodega, Inventario.bodega_id == Bodega.id)
        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
        .filter(
            Sucursal.empresa_id == empresa_id,
            Inventario.producto_id == producto_id,
            Inventario.cantidad > 5,
        )
        .order_by(func.random())
        .first()
    )
    if not inv:
        return None
    return db.query(Bodega).filter(Bodega.id == inv.bodega_id).first()


def simulate_intercompany_transfer(
    db: Session,
    holding_empresa_ids: List[uuid.UUID],
) -> Tuple[uuid.UUID, uuid.UUID, float] | None:
    if len(holding_empresa_ids) < 2:
        return None
    master_email = "stress_master@holding.test"
    master_user = (
        db.query(Usuario)
        .filter(Usuario.email == master_email)
        .first()
    )
    if not master_user:
        return None
    empresas_ids = list(holding_empresa_ids)
    empresa_origen_id = random.choice(empresas_ids)
    empresa_destino_id = random.choice([e for e in empresas_ids if e != empresa_origen_id])
    prod_origen = pick_random_product_for_company(db, empresa_origen_id)
    if not prod_origen:
        return None
    sku = prod_origen.sku
    prod_destino = (
        db.query(Producto)
        .filter(Producto.empresa_id == empresa_destino_id, Producto.sku == sku)
        .first()
    )
    if not prod_destino:
        try:
            prod_destino = Producto(
                nombre=prod_origen.nombre,
                sku=sku,
                precio=prod_origen.precio,
                tipo_producto="ALMACENABLE",
                empresa_id=empresa_destino_id,
                is_active=True,
            )
            db.add(prod_destino)
            db.flush()
        except IntegrityError:
            db.rollback()
            prod_destino = (
                db.query(Producto)
                .filter(Producto.empresa_id == empresa_destino_id, Producto.sku == sku)
                .first()
            )
            if not prod_destino:
                raise
    bodega_origen = pick_bodega_with_stock(db, empresa_origen_id, prod_origen.id)
    if not bodega_origen:
        return None
    bodega_destino = (
        db.query(Bodega)
        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
        .filter(Sucursal.empresa_id == empresa_destino_id)
        .order_by(func.random())
        .first()
    )
    if not bodega_destino:
        return None
    cantidad = random.randint(1, 5)
    inv_origen = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == prod_origen.id,
            Inventario.bodega_id == bodega_origen.id,
        )
        .with_for_update()
        .first()
    )
    if not inv_origen or inv_origen.cantidad < cantidad:
        return None
    inv_origen.cantidad -= cantidad
    db.add(inv_origen)
    inv_destino = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == prod_destino.id,
            Inventario.bodega_id == bodega_destino.id,
        )
        .with_for_update()
        .first()
    )
    if not inv_destino:
        inv_destino = Inventario(
            producto_id=prod_destino.id,
            bodega_id=bodega_destino.id,
            cantidad=0,
            cantidad_reservada=0,
        )
    inv_destino.cantidad += cantidad
    db.add(inv_destino)
    monto = float(prod_origen.precio) * cantidad
    cuenta_origen = ensure_intercompany_account(db, empresa_origen_id)
    cuenta_destino = ensure_intercompany_account(db, empresa_destino_id)
    asiento_origen = AsientoContable(
        glosa=f"STRESS_INTERCO_OUT_{sku}",
        origen="INTERCO_ORIGEN",
        origen_id=str(prod_origen.id),
        estado="CONFIRMADO",
        empresa_id=empresa_origen_id,
        usuario_id=master_user.id,
    )
    db.add(asiento_origen)
    db.flush()
    mov_origen = MovimientoContable(
        asiento_id=asiento_origen.id,
        cuenta_id=cuenta_origen.id,
        debe=0,
        haber=monto,
    )
    db.add(mov_origen)
    asiento_destino = AsientoContable(
        glosa=f"STRESS_INTERCO_IN_{sku}",
        origen="INTERCO_DESTINO",
        origen_id=str(prod_destino.id),
        estado="CONFIRMADO",
        empresa_id=empresa_destino_id,
        usuario_id=master_user.id,
    )
    db.add(asiento_destino)
    db.flush()
    mov_destino = MovimientoContable(
        asiento_id=asiento_destino.id,
        cuenta_id=cuenta_destino.id,
        debe=monto,
        haber=0,
    )
    db.add(mov_destino)
    db.commit()
    return empresa_origen_id, empresa_destino_id, monto


def simulate_internal_stock_movement(db: Session, empresa_ids: List[uuid.UUID]) -> bool:
    empresa_id = random.choice(empresa_ids)
    producto = pick_random_product_for_company(db, empresa_id)
    if not producto:
        return False
    bodega = pick_bodega_with_stock(db, empresa_id, producto.id)
    if not bodega:
        return False
    inv = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == producto.id,
            Inventario.bodega_id == bodega.id,
        )
        .with_for_update()
        .first()
    )
    if not inv or inv.cantidad < 2:
        return False
    delta = random.randint(1, 2)
    inv.cantidad -= delta
    db.add(inv)
    db.commit()
    return True


def simulate_external_purchase(db: Session, empresa_ids: List[uuid.UUID]) -> bool:
    if not empresa_ids:
        return False
    empresa_id = random.choice(empresa_ids)
    producto = pick_random_product_for_company(db, empresa_id)
    if not producto:
        return False
    bodega = pick_bodega_with_stock(db, empresa_id, producto.id)
    if not bodega:
        bodega = (
            db.query(Bodega)
            .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
            .filter(Sucursal.empresa_id == empresa_id)
            .order_by(func.random())
            .first()
        )
        if not bodega:
            return False
    cantidad = random.randint(5, 20)
    inv = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == producto.id,
            Inventario.bodega_id == bodega.id,
        )
        .with_for_update()
        .first()
    )
    if not inv:
        inv = Inventario(
            producto_id=producto.id,
            bodega_id=bodega.id,
            cantidad=0,
            cantidad_reservada=0,
        )
    costo_unitario = float(producto.precio) * 0.6
    monto = costo_unitario * cantidad
    inv.cantidad += cantidad
    db.add(inv)
    master_email = "stress_master@holding.test"
    master_user = (
        db.query(Usuario)
        .filter(Usuario.email == master_email)
        .first()
    )
    if not master_user:
        return False
    cuenta_inventario = ensure_account(
        db,
        empresa_id,
        "1.9.99",
        "Inventario Stress",
    )
    cuenta_proveedores = ensure_account(
        db,
        empresa_id,
        "2.9.99",
        "Proveedores Stress",
    )
    asiento = AsientoContable(
        glosa=f"STRESS_COMPRA_EXT_{producto.sku}",
        origen="COMPRA_EXT",
        origen_id=str(producto.id),
        estado="CONFIRMADO",
        empresa_id=empresa_id,
        usuario_id=master_user.id,
    )
    db.add(asiento)
    db.flush()
    mov_inv = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_inventario.id,
        debe=monto,
        haber=0,
    )
    mov_prov = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_proveedores.id,
        debe=0,
        haber=monto,
    )
    db.add(mov_inv)
    db.add(mov_prov)
    db.commit()
    return True


def simulate_external_sale(db: Session, empresa_ids: List[uuid.UUID]) -> bool:
    if not empresa_ids:
        return False
    empresa_id = random.choice(empresa_ids)
    producto = pick_random_product_for_company(db, empresa_id)
    if not producto:
        return False
    bodega = pick_bodega_with_stock(db, empresa_id, producto.id)
    if not bodega:
        return False
    inv = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == producto.id,
            Inventario.bodega_id == bodega.id,
        )
        .with_for_update()
        .first()
    )
    if not inv or inv.cantidad < 2:
        return False
    cantidad = random.randint(1, 5)
    if inv.cantidad < cantidad:
        return False
    precio_unitario = float(producto.precio)
    monto_venta = precio_unitario * cantidad
    monto_costo = monto_venta * 0.6
    inv.cantidad -= cantidad
    db.add(inv)
    master_email = "stress_master@holding.test"
    master_user = (
        db.query(Usuario)
        .filter(Usuario.email == master_email)
        .first()
    )
    if not master_user:
        return False
    cuenta_inventario = ensure_account(
        db,
        empresa_id,
        "1.9.99",
        "Inventario Stress",
    )
    cuenta_ventas = ensure_account(
        db,
        empresa_id,
        "7.9.99",
        "Ventas Stress",
    )
    cuenta_costo_ventas = ensure_account(
        db,
        empresa_id,
        "5.9.99",
        "Costo de Ventas Stress",
    )
    cuenta_caja = ensure_account(
        db,
        empresa_id,
        "1.1.99",
        "Caja Stress",
    )
    asiento = AsientoContable(
        glosa=f"STRESS_VENTA_EXT_{producto.sku}",
        origen="VENTA_EXT",
        origen_id=str(producto.id),
        estado="CONFIRMADO",
        empresa_id=empresa_id,
        usuario_id=master_user.id,
    )
    db.add(asiento)
    db.flush()
    mov_caja = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_caja.id,
        debe=monto_venta,
        haber=0,
    )
    mov_ventas = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_ventas.id,
        debe=0,
        haber=monto_venta,
    )
    mov_costo = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_costo_ventas.id,
        debe=monto_costo,
        haber=0,
    )
    mov_inv = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_inventario.id,
        debe=0,
        haber=monto_costo,
    )
    db.add(mov_caja)
    db.add(mov_ventas)
    db.add(mov_costo)
    db.add(mov_inv)
    db.commit()
    return True


def consolidate_stock(db: Session, empresa_ids: List[uuid.UUID], sku: str) -> float:
    productos = (
        db.query(Producto)
        .filter(Producto.empresa_id.in_(empresa_ids), Producto.sku == sku)
        .all()
    )
    producto_ids = [p.id for p in productos]
    if not producto_ids:
        return 0.0
    total = (
        db.query(func.sum(Inventario.cantidad))
        .filter(Inventario.producto_id.in_(producto_ids))
        .scalar()
        or 0
    )
    return float(total)


def calculate_gross_profit(db: Session, empresa_ids: List[uuid.UUID]) -> float:
    if not empresa_ids:
        print("Holding Gross Profit: 0.00")
        return 0.0
    movimientos = (
        db.query(MovimientoContable, CuentaContable, AsientoContable)
        .join(AsientoContable, MovimientoContable.asiento_id == AsientoContable.id)
        .join(CuentaContable, MovimientoContable.cuenta_id == CuentaContable.id)
        .filter(
            AsientoContable.empresa_id.in_(empresa_ids),
            AsientoContable.glosa.like("STRESS_VENTA_EXT_%"),
            CuentaContable.codigo.in_(["7.9.99", "5.9.99"]),
        )
        .all()
    )
    ventas_total = 0.0
    costo_total = 0.0
    for mov, cuenta, asiento in movimientos:
        if cuenta.codigo == "7.9.99":
            ventas_total += float(mov.haber or 0) - float(mov.debe or 0)
        elif cuenta.codigo == "5.9.99":
            costo_total += float(mov.debe or 0) - float(mov.haber or 0)
    utilidad_bruta = ventas_total - costo_total
    print(f"Holding Gross Profit: {utilidad_bruta:.2f}")
    return utilidad_bruta


def verify_intercompany_balances(db: Session, empresa_ids: List[uuid.UUID]):
    movimientos = (
        db.query(MovimientoContable, AsientoContable, CuentaContable)
        .join(AsientoContable, MovimientoContable.asiento_id == AsientoContable.id)
        .join(CuentaContable, MovimientoContable.cuenta_id == CuentaContable.id)
        .filter(
            AsientoContable.empresa_id.in_(empresa_ids),
            CuentaContable.codigo == "8.9.99",
            AsientoContable.glosa.like("STRESS_INTERCO_%"),
        )
        .all()
    )
    balances = defaultdict(float)
    for mov, asiento, cuenta in movimientos:
        empresa_id = asiento.empresa_id
        debe = float(mov.debe or 0)
        haber = float(mov.haber or 0)
        balances[empresa_id] += debe - haber
    total = sum(balances.values())
    print("Intercompany balances per empresa (debe - haber):")
    for emp_id, saldo in balances.items():
        print(f"  Empresa {emp_id}: {saldo:.2f}")
    print(f"Intercompany global balance: {total:.2f}")
    if abs(total) < 0.01:
        print("OK: Intercompany accounts globally balanced.")
    else:
        print("WARNING: Intercompany accounts not balanced at holding level.")


def verify_isolation(db: Session, empresa_aislada_id: uuid.UUID | None):
    if not empresa_aislada_id:
        return
    empresa_aislada = db.query(Empresa).filter(Empresa.id == empresa_aislada_id).first()
    if not empresa_aislada:
        return
    productos = (
        db.query(Producto)
        .filter(Producto.empresa_id == empresa_aislada.id)
        .all()
    )
    otros = (
        db.query(Producto)
        .filter(
            Producto.empresa_id != empresa_aislada.id,
            Producto.nombre.like("STRESS_PROD_%"),
        )
        .all()
    )
    print(f"Empresa aislada: {empresa_aislada.nombre}")
    print(f"Productos propios: {len(productos)}")
    print(f"Productos stress en otras empresas: {len(otros)}")


def run_transactions(
    SessionLocal,
    empresa_ids: List[uuid.UUID],
    holding_empresa_ids: List[uuid.UUID],
    total_transactions: int,
):
    stats = {
        "success": 0,
        "deadlock": 0,
        "concurrency_error": 0,
        "other_error": 0,
    }
    intercompany_balances: Dict[uuid.UUID, float] = defaultdict(float)
    latencies_internal: List[float] = []
    latencies_interco: List[float] = []
    error_messages: List[str] = []
    lock = threading.Lock()

    def worker(i: int):
        db: Session = SessionLocal()
        db.info["allow_no_tenant"] = True
        try:
            r = random.random()
            if r < 0.2:
                start_t = time.perf_counter()
                try:
                    ok = simulate_external_purchase(db, holding_empresa_ids)
                    with lock:
                        if ok:
                            stats["success"] += 1
                        else:
                            stats["other_error"] += 1
                except OperationalError as e:
                    msg = str(e).lower()
                    with lock:
                        if "deadlock" in msg:
                            stats["deadlock"] += 1
                        else:
                            stats["concurrency_error"] += 1
                        error_messages.append(str(e))
                except Exception as e:
                    with lock:
                        stats["other_error"] += 1
                        error_messages.append(str(e))
                finally:
                    elapsed = time.perf_counter() - start_t
                    with lock:
                        latencies_internal.append(elapsed)
            elif r < 0.7:
                start_t = time.perf_counter()
                try:
                    ok = simulate_external_sale(db, holding_empresa_ids)
                    with lock:
                        if ok:
                            stats["success"] += 1
                        else:
                            stats["other_error"] += 1
                except OperationalError as e:
                    msg = str(e).lower()
                    with lock:
                        if "deadlock" in msg:
                            stats["deadlock"] += 1
                        else:
                            stats["concurrency_error"] += 1
                        error_messages.append(str(e))
                except Exception as e:
                    with lock:
                        stats["other_error"] += 1
                        error_messages.append(str(e))
                finally:
                    elapsed = time.perf_counter() - start_t
                    with lock:
                        latencies_internal.append(elapsed)
            else:
                start_t = time.perf_counter()
                try:
                    result = simulate_intercompany_transfer(db, holding_empresa_ids)
                    if result:
                        origen_id, destino_id, monto = result
                        with lock:
                            intercompany_balances[origen_id] -= monto
                            intercompany_balances[destino_id] += monto
                        with lock:
                            stats["success"] += 1
                    else:
                        with lock:
                            stats["other_error"] += 1
                except OperationalError as e:
                    msg = str(e).lower()
                    with lock:
                        if "deadlock" in msg:
                            stats["deadlock"] += 1
                        else:
                            stats["concurrency_error"] += 1
                        error_messages.append(str(e))
                except Exception as e:
                    with lock:
                        stats["other_error"] += 1
                        error_messages.append(str(e))
                finally:
                    elapsed = time.perf_counter() - start_t
                    with lock:
                        latencies_interco.append(elapsed)
        finally:
            db.close()

    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=8) as executor:
        for i in range(total_transactions):
            executor.submit(worker, i)
    end = time.perf_counter()
    total_time = end - start
    avg_ms = (total_time / total_transactions) * 1000 if total_transactions else 0
    print("=== Stress Test Summary ===")
    print(f"Total transactions: {total_transactions}")
    print(f"Success: {stats['success']}")
    print(f"Deadlocks: {stats['deadlock']}")
    print(f"Concurrency errors: {stats['concurrency_error']}")
    print(f"Other errors: {stats['other_error']}")
    print(f"Total time (s): {total_time:.2f}")
    print(f"Avg per transaction (ms): {avg_ms:.2f}")

    def describe_latencies(values: List[float], label: str):
        if not values:
            print(f"{label}: sin datos")
            return
        data = sorted(values)
        n = len(data)
        avg = (sum(data) / n) * 1000.0
        def percentile(q: float) -> float:
            if n == 1:
                return data[0] * 1000.0
            idx = int(q * (n - 1))
            return data[idx] * 1000.0
        p95 = percentile(0.95)
        p99 = percentile(0.99)
        print(
            f"{label}: avg={avg:.2f} ms, p95={p95:.2f} ms, p99={p99:.2f} ms"
        )

    print("Latency report:")
    describe_latencies(latencies_internal, "Internal movements")
    describe_latencies(latencies_interco, "Intercompany transfers")

    if error_messages:
        seen: List[str] = []
        for msg in reversed(error_messages):
            if msg not in seen:
                seen.append(msg)
            if len(seen) >= 3:
                break
        print("Last distinct error messages (up to 3):")
        for msg in seen:
            print("-", msg)

    print("Intercompany balance aggregation (in-memory):")
    for emp_id, saldo in intercompany_balances.items():
        print(f"  Empresa {emp_id}: {saldo:.2f}")


def main():
    engine, SessionLocal = get_engine_and_sessionmaker()
    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        print("Bootstrapping companies and holding...")
        empresas, holding_empresas, master_user = bootstrap_companies_and_holding(db)
        empresa_ids = [e.id for e in empresas]
        holding_ids = [e.id for e in holding_empresas]
        empresa_aislada_id = empresas[11].id if len(empresas) >= 12 else None
        print("Creating warehouses and inventory...")
        create_warehouses_and_inventory(db, empresas)
        db.close()
        bursts = [2000, 4000, 6000, 8000, 12000, 20000]
        for total in bursts:
            print(f"=== Burst {total} transactions ===")
            run_transactions(SessionLocal, empresa_ids, holding_ids, total)
            db = SessionLocal()
            db.info["allow_no_tenant"] = True
            print("Holding gross profit for current state:")
            calculate_gross_profit(db, holding_ids)
            print("Verifying intercompany accounting balances...")
            verify_intercompany_balances(db, holding_ids)
            print("Verifying isolation for Empresa 12...")
            verify_isolation(db, empresa_aislada_id)
            db.close()
            print("Cooling down 10 seconds...")
            time.sleep(10)
    finally:
        db.close()
        engine.dispose()


if __name__ == "__main__":
    main()

