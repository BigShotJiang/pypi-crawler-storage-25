import sys
from pathlib import Path

# Add backend to path
sys.path.append(str(Path(__file__).parent.parent))

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Usuario, Rol, UsuarioEmpresa

def seed_roles():
    db = SessionLocal()
    try:
        # 1. Find Company
        company_code = 'QUESOS594'
        # Habilitar allow_no_tenant para encontrar la empresa sin contexto
        db.info["allow_no_tenant"] = True
        
        empresa = db.query(Empresa).filter(Empresa.codigo == company_code).first()
        if not empresa:
            print(f"Empresa {company_code} not found.")
            return

        print(f"Found Company: {empresa.nombre} ({empresa.id})")

        # 2. Find User (Try to find a superadmin or developer or specific email)
        # Try to find the user explicitly if known, otherwise fallback to SUPERADMIN
        # Assuming the user running this is likely a developer or using the main admin account
        user = db.query(Usuario).filter(Usuario.email.ilike('%admin%')).first()
        if not user:
            user = db.query(Usuario).filter(Usuario.role.in_(['SUPERADMIN', 'DEVELOPER'])).first()
        
        if not user:
            # Fallback: get any user to assign
            user = db.query(Usuario).first()
            if not user:
                print("No users found in DB.")
                return
        
        print(f"Selected User: {user.email} (Global Role: {user.role})")

        # 3. Create Roles
        # We need to ensure roles exist for THIS company
        roles_data = [
            {"codigo": "ADM", "nombre": "Administrador"},
            {"codigo": "CRM", "nombre": "CRM"},
            {"codigo": "VEN", "nombre": "Vendedor"},
        ]
        
        roles_map = {}
        for r_data in roles_data:
            rol = db.query(Rol).filter(Rol.empresa_id == empresa.id, Rol.codigo == r_data["codigo"]).first()
            if not rol:
                rol = Rol(
                    empresa_id=empresa.id,
                    codigo=r_data["codigo"],
                    nombre=r_data["nombre"],
                    is_active=True
                )
                db.add(rol)
                print(f"Created Role: {rol.codigo}")
            else:
                print(f"Role exists: {rol.codigo}")
            # Add to session to get ID
            db.flush() 
            roles_map[r_data["codigo"]] = rol

        # 4. Link User to Company with ADM role
        link = db.query(UsuarioEmpresa).filter(
            UsuarioEmpresa.usuario_id == user.id,
            UsuarioEmpresa.empresa_id == empresa.id
        ).first()

        target_role = roles_map["ADM"] # Assign ADM by default as requested "asignar a mi usuario principal"

        if link:
            print(f"User already linked. Current Role ID: {link.rol_id}")
            if link.rol_id != target_role.id:
                link.rol_id = target_role.id
                db.add(link)
                print(f"Updated Role to: {target_role.codigo}")
            else:
                print("Role is already ADM.")
        else:
            link = UsuarioEmpresa(
                usuario_id=user.id,
                empresa_id=empresa.id,
                rol_id=target_role.id,
                is_default=True
            )
            db.add(link)
            print(f"Linked User to Company with Role: {target_role.codigo}")

        db.commit()
        print("Seed completed successfully.")

    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    seed_roles()
