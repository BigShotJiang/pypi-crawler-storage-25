import sys
import os
from datetime import datetime
from decimal import Decimal
from uuid import uuid4
from dotenv import load_dotenv

# Setup paths and load env
backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(backend_path)
load_dotenv(os.path.join(backend_path, ".env"))

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Usuario
# Import dependent modules to ensure mappers are registered
from app.core_modules.finanzas import models as fin_models
from app.core_modules.finanzas.accounting_service import entries

def verify_libro_diario():
    db = SessionLocal()
    try:
        print("1. Setting up test data...")
        # Create Dummy Company
        empresa_id = uuid4()
        
        # Set tenant context for the session manually
        db.info["empresa_id"] = empresa_id
        
        # Generate random RUT to avoid unique constraint violations
        import random
        random_rut = f"{random.randint(10, 99)}.{random.randint(100, 999)}.{random.randint(100, 999)}-{random.randint(0, 9)}"

        empresa = Empresa(
            id=empresa_id,
            rut=random_rut,
            nombre=f"Test Libro Diario Corp {uuid4().hex[:8]}",
            codigo=f"TEST_LD_{uuid4().hex[:4]}",
            is_active=True
        )
        db.add(empresa)
        
        # Create Dummy User
        usuario_id = uuid4()
        usuario = Usuario(
            id=usuario_id,
            email=f"test_ld_{uuid4()}@example.com",
            hashed_password="pw",
            role="ADMIN",
            is_active=True
        )
        db.add(usuario)
        
        # Create Dummy Accounts
        cuenta_caja = fin_models.CuentaContable(
            empresa_id=empresa_id,
            codigo="1.1.01.01",
            nombre="Caja",
            tipo_cuenta="ACTIVO",
            nivel=4,
            es_imputable=True
        )
        cuenta_capital = fin_models.CuentaContable(
            empresa_id=empresa_id,
            codigo="3.1.01.01",
            nombre="Capital Social",
            tipo_cuenta="PATRIMONIO",
            nivel=4,
            es_imputable=True
        )
        db.add(cuenta_caja)
        db.add(cuenta_capital)
        db.flush()
        
        # Create Asiento
        asiento = fin_models.AsientoContable(
            fecha=datetime.now(),
            glosa="Asiento de Prueba Libro Diario",
            origen="MANUAL",
            estado="CONFIRMADO",
            empresa_id=empresa_id,
            usuario_id=usuario_id
        )
        db.add(asiento)
        db.flush()
        
        # Create Movimientos
        mov_debe = fin_models.MovimientoContable(
            asiento_id=asiento.id,
            cuenta_id=cuenta_caja.id,
            debe=Decimal("1000.00"),
            haber=Decimal("0.00")
        )
        mov_haber = fin_models.MovimientoContable(
            asiento_id=asiento.id,
            cuenta_id=cuenta_capital.id,
            debe=Decimal("0.00"),
            haber=Decimal("1000.00")
        )
        db.add(mov_debe)
        db.add(mov_haber)
        db.commit()
        
        print("2. Calling get_libro_diario...")
        # Call the service function
        fecha_inicio = datetime(datetime.now().year, 1, 1)
        fecha_fin = datetime(datetime.now().year, 12, 31)
        
        results = entries.get_libro_diario(db, empresa_id, fecha_inicio, fecha_fin)
        
        print(f"3. Verifying results (Found {len(results)} entries)...")
        assert len(results) > 0
        
        asiento_res = results[0]
        print(f"   Asiento: {asiento_res.glosa}")
        
        print("4. Verifying nested 'cuenta' loading...")
        for mov in asiento_res.movimientos:
            print(f"   - Movimiento {mov.debe} | {mov.haber}")
            # This access should NOT trigger a lazy load query if selectinload worked
            # But we can't easily verify that without SQL logging.
            # However, we CAN verify that mov.cuenta is present and correct.
            assert mov.cuenta is not None
            print(f"     -> Cuenta Loaded: {mov.cuenta.codigo} - {mov.cuenta.nombre}")
            
        print("\n✅ SUCCESS: Libro Diario query returns nested accounts correctly.")
        
    except Exception as e:
        print(f"\n❌ FAILURE: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Cleanup
        db.rollback()
        db.close()

if __name__ == "__main__":
    verify_libro_diario()
