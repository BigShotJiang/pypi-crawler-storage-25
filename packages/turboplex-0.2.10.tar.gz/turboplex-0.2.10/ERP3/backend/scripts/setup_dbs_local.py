from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url
from sqlalchemy.exc import OperationalError, SQLAlchemyError


def _try_load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    backend_root = Path(__file__).resolve().parents[1]
    env_path = backend_root / ".env"
    if env_path.exists():
        load_dotenv(env_path)


def _resolve_admin_url(database_url: str) -> str:
    url = make_url(database_url)
    if url.get_backend_name() != "postgresql":
        raise ValueError("Este script solo soporta PostgreSQL.")
    admin_url = url.set(database="postgres")
    return admin_url.render_as_string(hide_password=False)


def _validate_db_name(db_name: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_]+", db_name):
        raise ValueError("db_name inválido (solo letras, números y guión bajo).")
    return db_name


def _create_db_if_missing(admin_url: str, db_name: str) -> None:
    db_name = _validate_db_name(db_name)
    engine = create_engine(admin_url, isolation_level="AUTOCOMMIT", pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            exists = conn.execute(
                text("SELECT 1 FROM pg_database WHERE datname = :name"),
                {"name": db_name},
            ).scalar()
            if exists == 1:
                print(f"{db_name}: OK (ya existe)")
                return
            conn.execute(text(f'CREATE DATABASE "{db_name}"'))
            print(f"{db_name}: CREADA")
    finally:
        engine.dispose()


def main() -> int:
    _try_load_dotenv()
    parser = argparse.ArgumentParser(
        prog="setup_dbs_local",
        description="Crea bases de datos de soporte (espejo/auditoría) en Postgres local de forma idempotente.",
    )
    parser.add_argument(
        "--database-url",
        default=os.getenv("DATABASE_URL", ""),
        help="URL base de conexión (si se omite, usa env DATABASE_URL).",
    )
    parser.add_argument(
        "--db-espejo",
        default="db_espejo_test",
        help="Nombre de la base de datos espejo.",
    )
    parser.add_argument(
        "--db-auditor",
        default="db_auditor_test",
        help="Nombre de la base de datos de auditoría.",
    )
    args = parser.parse_args()

    if not args.database_url:
        print(
            "Falta DATABASE_URL (flag --database-url o variable de entorno).",
            file=sys.stderr,
        )
        return 2

    try:
        admin_url = _resolve_admin_url(args.database_url)
        safe_admin_url = make_url(admin_url).render_as_string(hide_password=True)
        print(f"Conectando a: {safe_admin_url}")
        _create_db_if_missing(admin_url, args.db_espejo)
        _create_db_if_missing(admin_url, args.db_auditor)
        return 0
    except OperationalError as exc:
        print(
            "Error: No se pudo conectar a Postgres. Verifica credenciales/host/puerto y que el servicio esté arriba.",
            file=sys.stderr,
        )
        print(f"Detalle: {exc}", file=sys.stderr)
        return 1
    except (ValueError, SQLAlchemyError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
