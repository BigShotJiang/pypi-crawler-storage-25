import sys
import os

# Ensure backend is in path
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from sqlalchemy import text
from app.core.database import engine

def add_columns():
    print("STARTING add_columns script...", flush=True)
    try:
        with engine.connect() as conn:
            print("Connected to database.", flush=True)
            
            # 1. Giro
            print("Attempting to add 'giro'...", flush=True)
            try:
                conn.execute(text("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS giro VARCHAR"))
                print("Executed ADD COLUMN giro.", flush=True)
            except Exception as e:
                print(f"Error adding giro: {e}", flush=True)

            # 2. Ciudad
            print("Attempting to add 'ciudad'...", flush=True)
            try:
                conn.execute(text("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS ciudad VARCHAR"))
                print("Executed ADD COLUMN ciudad.", flush=True)
            except Exception as e:
                print(f"Error adding ciudad: {e}", flush=True)

            # 3. Condicion Pago
            print("Attempting to add 'condicion_pago'...", flush=True)
            try:
                conn.execute(text("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS condicion_pago VARCHAR DEFAULT 'CONTADO'"))
                print("Executed ADD COLUMN condicion_pago.", flush=True)
            except Exception as e:
                print(f"Error adding condicion_pago: {e}", flush=True)

            print("Committing transaction...", flush=True)
            conn.commit()
            print("Transaction committed.", flush=True)

    except Exception as e:
        print(f"CRITICAL ERROR: {e}", flush=True)
        sys.exit(1)
    
    print("FINISHED add_columns script.", flush=True)

if __name__ == "__main__":
    add_columns()
