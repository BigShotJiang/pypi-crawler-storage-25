
file_path = r"e:\ERP3\backend\alembic\versions\162e4ccb9ce6_uuid7_remaining_modules.py"

with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

new_lines = []
in_upgrade = False
helper_injected = False

helper_code = """    def safe_alter_column(table_name, column_name, **kwargs):
        existing_type = kwargs.get('existing_type')
        if 'type_' in kwargs:
            # Drop default first
            op.alter_column(table_name, column_name, server_default=None, existing_type=existing_type)
        op.alter_column(table_name, column_name, **kwargs)

"""

for line in lines:
    if "def upgrade() -> None:" in line:
        in_upgrade = True
        new_lines.append(line)
        continue

    if in_upgrade and not helper_injected:
        # Inject helper code after the docstring if present, or just at the start
        if '"""' in line or "'''" in line:
            new_lines.append(line)
            continue
        # Assuming typical structure, inject now
        new_lines.append(helper_code)
        helper_injected = True

    if in_upgrade and "op.alter_column" in line:
        line = line.replace("op.alter_column", "safe_alter_column")

    if "def downgrade() -> None:" in line:
        in_upgrade = False

    new_lines.append(line)

with open(file_path, "w", encoding="utf-8") as f:
    f.writelines(new_lines)

print("Migration file updated with safe_alter_column helper.")
