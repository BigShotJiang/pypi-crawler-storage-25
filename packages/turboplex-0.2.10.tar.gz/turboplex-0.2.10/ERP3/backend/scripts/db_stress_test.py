import sys
import os
import time
import threading
import random
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import text
from app.core.database import SessionLocal, engine
from app.core.config import settings

# Configuration
CONCURRENT_USERS = 50  # Simulate 50 simultaneous users
TOTAL_REQUESTS = 500  # Total queries to run
DELAY_BETWEEN_REQUESTS = 0.05  # Slight delay to simulate real traffic

print("\n" + "=" * 60)
print("🔥  DATABASE CONNECTION POOL STRESS TEST  🔥")
print("=" * 60)
print(f"Environment: {settings.ENVIRONMENT}")
print(f"Database URL: {settings.DATABASE_URL.split('@')[-1]}")  # Hide credentials
print(
    f"Pool Settings: Size={engine.pool.size() if hasattr(engine.pool, 'size') else 'Dynamic'}, Overflow={engine.pool._max_overflow if hasattr(engine.pool, '_max_overflow') else 'Dynamic'}"
)
print(
    f"Simulating {CONCURRENT_USERS} concurrent users executing {TOTAL_REQUESTS} total requests..."
)
print("-" * 60 + "\n")

# Stats
stats = {"success": 0, "failed": 0, "errors": [], "total_time": 0}
stats_lock = threading.Lock()


def simulate_user_request(request_id):
    """
    Simulates a single user request:
    1. Opens DB session
    2. Runs a query (SELECT 1)
    3. Simulates processing time
    4. Closes session
    """
    start_time = time.time()
    session = SessionLocal()

    try:
        # Simulate work - Force SQL execution
        # Use a simple query that hits the DB
        result = session.execute(text("SELECT 1")).scalar()

        # Verify result
        if result != 1:
            raise Exception("Query returned unexpected result")

        # Simulate some processing time (0-100ms)
        time.sleep(random.uniform(0, 0.1))

        # Commit (even for SELECT, to test transaction lifecycle)
        session.commit()

        duration = time.time() - start_time

        with stats_lock:
            stats["success"] += 1
            stats["total_time"] += duration

        return True

    except Exception as e:
        session.rollback()
        with stats_lock:
            stats["failed"] += 1
            stats["errors"].append(str(e))
        return False

    finally:
        session.close()


def run_stress_test():
    start_test = time.time()

    with ThreadPoolExecutor(max_workers=CONCURRENT_USERS) as executor:
        futures = [
            executor.submit(simulate_user_request, i) for i in range(TOTAL_REQUESTS)
        ]

        # Wait for all
        for _ in as_completed(futures):
            pass

    total_duration = time.time() - start_test
    avg_latency = (
        (stats["total_time"] / stats["success"]) * 1000 if stats["success"] > 0 else 0
    )

    print("\n" + "=" * 60)
    print("📊  TEST RESULTS")
    print("=" * 60)
    print(f"Total Duration:   {total_duration:.2f} seconds")
    print(f"Requests/Sec:     {TOTAL_REQUESTS / total_duration:.2f} req/s")
    print(f"Avg Latency:      {avg_latency:.2f} ms")
    print("-" * 30)
    print(f"✅ Success:       {stats['success']}")
    print(f"❌ Failed:        {stats['failed']}")
    print("=" * 60)

    if stats["failed"] > 0:
        print("\n⚠️  Unique Errors Encountered:")
        unique_errors = set(stats["errors"])
        for err in unique_errors:
            print(f" - {err}")
    else:
        print("\n✨  Pool Stability Confirmed: No dropped connections.")


if __name__ == "__main__":
    run_stress_test()
