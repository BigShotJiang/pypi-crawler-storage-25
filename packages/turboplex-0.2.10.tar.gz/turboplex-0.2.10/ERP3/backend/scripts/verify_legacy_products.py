import sys
import os
from datetime import datetime
from decimal import Decimal

# Add backend directory to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto
from app.core_modules.sistema.models import Empresa, Bodega, Sucursal
from app.core_modules.inventario.stock.services import InventoryService
from app.core_modules.inventario.valorizacion.services import ValuationService
from app.core_modules.inventario.stock.models import Inventario
import uuid

def verify_legacy_products():
    print(">>> Verificando Productos Legacy (No Trazables)...")
    
    db = SessionLocal()
    # Allow operations without tenant middleware for this script
    db.info["allow_no_tenant"] = True
    
    try:
        suffix = str(uuid.uuid4())[:8]
        
        # 1. Setup Data
        print(f"Creating test data with suffix {suffix}...")
        empresa = Empresa(nombre=f"Empresa Legacy {suffix}", rut=f"LEGACY-{suffix}", codigo=f"EMP_L_{suffix}")
        db.add(empresa)
        db.commit()
        
        sucursal = Sucursal(nombre=f"Sucursal Legacy {suffix}", empresa_id=empresa.id, direccion="Legacy St")
        db.add(sucursal)
        db.commit()
        
        bodega = Bodega(nombre=f"Bodega Legacy {suffix}", sucursal_id=sucursal.id)
        db.add(bodega)
        db.commit()
        
        # 2. Create Non-Traceable Product
        producto = Producto(
            nombre=f"Prod Legacy {suffix}",
            sku=f"LEGACY_{suffix}",
            precio=1000,
            es_trazable=False, # Legacy behavior
            empresa_id=empresa.id,
            costo_promedio=0
        )
        db.add(producto)
        db.commit()
        
        print("Product created successfully.")
        
        # 3. Add Stock (No Lot)
        print("Adding stock (100 units @ $500)...")
        InventoryService.add_stock(
            db, producto.id, bodega.id, 100, "COMPRA", empresa.id, costo_unitario=Decimal(500)
        )
        
        # Check Stock
        inv = db.query(Inventario).filter_by(producto_id=producto.id, bodega_id=bodega.id).first()
        assert inv.cantidad == 100, f"Stock mismatch. Expected 100, got {inv.cantidad}"
        print(f"Stock added. Current: {inv.cantidad}")
        
        # Check PMP
        db.refresh(producto)
        assert producto.costo_promedio == 500, f"PMP mismatch. Expected 500, got {producto.costo_promedio}"
        print(f"PMP verified: {producto.costo_promedio}")
        
        # 4. Add More Stock (Different Cost)
        print("Adding stock (100 units @ $700)...")
        InventoryService.add_stock(
            db, producto.id, bodega.id, 100, "COMPRA", empresa.id, costo_unitario=Decimal(700)
        )
        
        # PMP should be (100*500 + 100*700) / 200 = 600
        db.refresh(producto)
        assert producto.costo_promedio == 600, f"PMP mismatch. Expected 600, got {producto.costo_promedio}"
        print(f"PMP updated correctly: {producto.costo_promedio}")
        
        # 5. Consume Stock (No Lot)
        print("Consuming stock (50 units)...")
        InventoryService.consume_stock(
            db, producto.id, bodega.id, 50, "VENTA", empresa.id
        )
        db.commit()
        
        # Check Stock
        db.refresh(inv)
        assert inv.cantidad == 150, f"Stock mismatch after consumption. Expected 150, got {inv.cantidad}"
        print(f"Stock consumed. Remaining: {inv.cantidad}")
        
        # PMP should remain 600
        db.refresh(producto)
        assert producto.costo_promedio == 600, f"PMP mismatch after sale. Expected 600, got {producto.costo_promedio}"
        print("PMP remained stable after sale.")
        
        print("\n>>> VERIFICACION EXITOSA: El flujo legacy funciona correctamente.")
        
    except Exception as e:
        print(f"\n>>> ERROR CRITICO: {e}")
        db.rollback()
        sys.exit(1)
    finally:
        db.close()

if __name__ == "__main__":
    verify_legacy_products()
