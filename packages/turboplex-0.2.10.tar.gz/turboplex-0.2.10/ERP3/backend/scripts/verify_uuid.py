import sys
import os
from sqlalchemy import create_engine, inspect

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.config import settings


def verify_uuids():
    print("Verifying UUIDv7 schema...")

    engine = create_engine(str(settings.DATABASE_URL))
    inspector = inspect(engine)

    tables = inspector.get_table_names()

    uuid_tables = []
    skipped_tables = [
        "alembic_version",
        "exchange_rates",
        "spatial_ref_sys",
    ]  # expected non-uuid or system tables

    for table in tables:
        if table in skipped_tables:
            continue

        pk_constraint = inspector.get_pk_constraint(table)
        pk_columns = pk_constraint.get("constrained_columns", [])

        if not pk_columns:
            print(f"WARNING: Table {table} has no primary key.")
            continue

        pk_col_name = pk_columns[0]
        columns = inspector.get_columns(table)

        pk_col = next((c for c in columns if c["name"] == pk_col_name), None)

        if not pk_col:
            print(f"ERROR: Could not find column info for {table}.{pk_col_name}")
            continue

        type_str = str(pk_col["type"])

        if "UUID" in type_str or "GUID" in type_str:
            uuid_tables.append(table)
        else:
            print(
                f"FAILURE: Table {table} PK {pk_col_name} is type {type_str}, expected UUID."
            )

    print(f"\nVerified {len(uuid_tables)} tables with UUID primary keys.")

    if len(uuid_tables) > 20:  # Arbitrary threshold to ensure we checked enough
        print("SUCCESS: Schema verification passed.")
    else:
        print("WARNING: Low number of verified tables.")


if __name__ == "__main__":
    verify_uuids()
