import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from sqlalchemy import text
from app.core.database import engine

def drop_columns():
    print("Connecting to database...")
    try:
        with engine.connect() as conn:
            print("Dropping columns from 'clientes' table...")
            
            # giro
            try:
                conn.execute(text("ALTER TABLE clientes DROP COLUMN IF EXISTS giro"))
                print("Column 'giro' dropped.")
            except Exception as e:
                print(f"Error dropping 'giro': {e}")

            # ciudad
            try:
                conn.execute(text("ALTER TABLE clientes DROP COLUMN IF EXISTS ciudad"))
                print("Column 'ciudad' dropped.")
            except Exception as e:
                print(f"Error dropping 'ciudad': {e}")

            # condicion_pago
            try:
                conn.execute(text("ALTER TABLE clientes DROP COLUMN IF EXISTS condicion_pago"))
                print("Column 'condicion_pago' dropped.")
            except Exception as e:
                print(f"Error dropping 'condicion_pago': {e}")
            
            conn.commit()
            print("Columns dropped successfully.")

    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        sys.exit(1)

if __name__ == "__main__":
    drop_columns()
