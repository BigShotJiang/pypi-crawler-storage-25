import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.database import SessionLocal
from app.models import Empresa

db = SessionLocal()
empresas = db.query(Empresa).all()
for e in empresas:
    print(f"{e.id}: {e.codigo} - {e.nombre}")
