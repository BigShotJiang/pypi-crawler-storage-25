import sys
import os

# Add backend directory to path so we can import app modules
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Rol

def add_crm_role():
    db: Session = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        empresas = db.query(Empresa).all()
        print(f"Found {len(empresas)} companies.")
        
        for empresa in empresas:
            print(f"Checking company: {empresa.nombre} ({empresa.codigo})")
            
            # Check if CRM role exists
            crm_role = db.query(Rol).filter(
                Rol.empresa_id == empresa.id,
                Rol.codigo == "CRM"
            ).first()
            
            if not crm_role:
                print(f"  Adding CRM role to {empresa.nombre}...")
                new_role = Rol(
                    empresa_id=empresa.id,
                    codigo="CRM",
                    nombre="Usuario CRM",
                    is_active=True
                )
                db.add(new_role)
            else:
                print(f"  CRM role already exists for {empresa.nombre}.")
        
        db.commit()
        print("Done!")
        
    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    add_crm_role()
