import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from sqlalchemy import inspect
from app.core.database import engine

def verify_columns():
    print("Inspecting 'clientes' table columns...")
    inspector = inspect(engine)
    columns = [col['name'] for col in inspector.get_columns('clientes')]
    
    required_columns = ['giro', 'ciudad', 'condicion_pago']
    missing = []
    found = []
    
    print(f"\nCurrent columns in 'clientes': {', '.join(columns)}")
    print("-" * 50)
    
    for col in required_columns:
        if col in columns:
            found.append(col)
            print(f"[OK] Column '{col}' exists.")
        else:
            missing.append(col)
            print(f"[ERROR] Column '{col}' MISSING!")
            
    print("-" * 50)
    if missing:
        print(f"VERIFICATION FAILED. Missing columns: {missing}")
        sys.exit(1)
    else:
        print("VERIFICATION SUCCESS. All required columns are present.")

if __name__ == "__main__":
    verify_columns()
