import sys
import os

# Add backend directory to path to import app modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.core.security import get_password_hash
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal, MetodoPago
from app.core_modules.sistema.models import Bodega, EmpresaMetodoPago


def create_tenant():
    print("\n" + "=" * 50)
    print("🎨  SaaS Tenant Onboarding - The Artist's Canvas  🎨")
    print("=" * 50 + "\n")

    db: Session = SessionLocal()

    try:
        # 1. Company Details
        print("--- 1. Datos de la Nueva Empresa ---")
        nombre = input("Nombre de la Empresa (ej. Ferretería Don Juan): ").strip()
        codigo = input("Código Único (ej. FDJ): ").strip().upper()
        rut = input("RUT (opcional): ").strip() or None

        if db.query(Empresa).filter(Empresa.codigo == codigo).first():
            print(f"\n❌ Error: La empresa con código '{codigo}' ya existe.")
            return

        # 2. Admin User
        print("\n--- 2. Usuario Administrador ---")
        email = input("Email del Admin (existente o nuevo): ").strip()

        user = db.query(Usuario).filter(Usuario.email == email).first()
        if user:
            print(f"✅ Usuario encontrado: {user.email}")
        else:
            print("🆕 Creando nuevo usuario administrador...")
            password = input("Contraseña temporal: ").strip()
            user = Usuario(
                email=email,
                hashed_password=get_password_hash(password),
                role="ADMIN",
                is_active=True,
            )
            db.add(user)
            db.flush()  # Get ID

        # 3. Create Structure
        print("\n--- 3. Construyendo Infraestructura Base ---")

        # Empresa
        empresa = Empresa(
            nombre=nombre,
            codigo=codigo,
            rut=rut,
            modulos_activos=[
                "CORE",
                "VENTAS",
                "FINANZAS",
                "RRHH",
                "TI",
                "SISTEMA",
            ],  # Default full suite
        )
        db.add(empresa)
        db.flush()

        # Link User -> Empresa
        link = UsuarioEmpresa(
            usuario_id=user.id,
            empresa_id=empresa.id,
            is_default=True,  # Make this the default for the user if it's their first
        )
        db.add(link)

        # Sucursal Default
        sucursal = Sucursal(
            nombre="Casa Matriz",
            codigo=f"{codigo}-MATRIZ",
            direccion="Dirección Principal",
            empresa_id=empresa.id,
        )
        db.add(sucursal)
        db.flush()

        # Bodega Default
        bodega = Bodega(
            nombre="Bodega Principal",
            codigo=f"{codigo}-BOD-01",
            sucursal_id=sucursal.id,
            is_active=True,
        )
        db.add(bodega)

        # 4. Configs (Metodos de Pago)
        print("⚙️  Configurando defaults...")
        metodos = db.query(MetodoPago).filter(MetodoPago.is_active).all()
        for m in metodos:
            emp_metodo = EmpresaMetodoPago(
                empresa_id=empresa.id, metodo_pago_id=m.id, is_active=True
            )
            db.add(emp_metodo)

        db.commit()

        print("\n" + "=" * 50)
        print("✅  ¡Tenant Creado Exitosamente!  🚀")
        print("=" * 50)
        print(f"Empresa: {nombre} ({codigo})")
        print(f"Admin:   {email}")
        print(f"URL:     http://localhost:3000?cmp={codigo}")
        print("=" * 50 + "\n")

    except Exception as e:
        db.rollback()
        print(f"\n❌ Error Critical: {str(e)}")
    finally:
        db.close()


if __name__ == "__main__":
    create_tenant()
