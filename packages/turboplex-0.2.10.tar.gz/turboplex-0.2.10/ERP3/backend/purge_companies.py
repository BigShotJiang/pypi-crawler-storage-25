import sys
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Agregar el directorio actual al path para importar modulos de la app
sys.path.append(os.getcwd())

from app.core.config import settings
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    UsuarioEmpresa,
    EmpresaMetodoPago,
    OrdenServicio,
)
from app.core_modules.ventas.models import (
    Venta,
    MovimientoStock,
    Inventario,
    Producto,
    Cliente,
    DetalleVenta,
)
from app.core_modules.finanzas.models import CierreCaja, Gasto, PrecioProducto
from app.core_modules.compras.models import Proveedor
from app.core_modules.rrhh.models import Empleado
from app.core_modules.service_engine.models import ServiceOrder, JobOrder

# Configuración
COMPANIES_TO_DELETE = [
    "Test Core Integration Inc.",
    "Laundry Inc",
    "Pricing Test Corp",
    "Empresa Principal",
    "Empresa Secundaria",
    "Test RBAC Corp",
    "Core Only Corp",
]


def purge_companies():
    print("--- Iniciando Purga de Empresas ---")

    engine = create_engine(settings.DATABASE_URL)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()

    try:
        print("Iniciando purga de empresas...")
        for company_name in COMPANIES_TO_DELETE:
            company = db.query(Empresa).filter(Empresa.nombre == company_name).first()
            if not company:
                print(f"Empresa '{company_name}' no encontrada. Saltando.")
                continue

            print(f"Purgando empresa: {company.nombre} (ID: {company.id})")

            # 1. Eliminar Movimientos de Stock
            deleted_movs = (
                db.query(MovimientoStock)
                .filter(MovimientoStock.empresa_id == company.id)
                .delete()
            )
            print(f"  - Eliminados {deleted_movs} movimientos de stock")

            # 2. Eliminar Inventario y Bodegas (Inventario no tiene empresa_id directo)
            sucursales = (
                db.query(Sucursal).filter(Sucursal.empresa_id == company.id).all()
            )
            for sucursal in sucursales:
                bodegas = (
                    db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).all()
                )
                for bodega in bodegas:
                    deleted_inv = (
                        db.query(Inventario)
                        .filter(Inventario.bodega_id == bodega.id)
                        .delete()
                    )
                    print(
                        f"    - Eliminados {deleted_inv} registros de inventario en bodega {bodega.nombre}"
                    )
                    db.delete(bodega)
                print(f"  - Eliminadas bodegas de sucursal {sucursal.nombre}")

            # 2.5 Eliminar ServiceOrders (Service Engine)
            # Primero eliminamos por empresa_id
            deleted_tickets_comp = (
                db.query(ServiceOrder)
                .filter(ServiceOrder.empresa_id == company.id)
                .delete()
            )

            # JobOrders
            deleted_jobs = (
                db.query(JobOrder).filter(JobOrder.empresa_id == company.id).delete()
            )

            # Luego eliminamos tickets que referencien a productos de esta empresa (casos de inconsistencia)
            product_ids_query = db.query(Producto.id).filter(
                Producto.empresa_id == company.id
            )
            deleted_tickets_prod = (
                db.query(ServiceOrder)
                .filter(ServiceOrder.producto_id.in_(product_ids_query))
                .delete(synchronize_session=False)
            )

            print(
                f"  - Eliminados {deleted_tickets_comp + deleted_tickets_prod} service orders y {deleted_jobs} job orders"
            )

            # 3. Eliminar Detalle de Ventas
            venta_ids_query = db.query(Venta.id).filter(Venta.empresa_id == company.id)
            deleted_detalles = (
                db.query(DetalleVenta)
                .filter(DetalleVenta.venta_id.in_(venta_ids_query))
                .delete(synchronize_session=False)
            )
            print(f"  - Eliminados {deleted_detalles} detalles de venta")

            # 3.1 Eliminar Ventas
            deleted_ventas = (
                db.query(Venta).filter(Venta.empresa_id == company.id).delete()
            )
            print(f"  - Eliminadas {deleted_ventas} ventas")

            # 3.1 Eliminar Precios de Productos
            deleted_precios = (
                db.query(PrecioProducto)
                .filter(PrecioProducto.empresa_id == company.id)
                .delete()
            )
            print(f"  - Eliminados {deleted_precios} precios de productos")

            # 4. Eliminar Productos
            deleted_productos = (
                db.query(Producto).filter(Producto.empresa_id == company.id).delete()
            )
            print(f"  - Eliminados {deleted_productos} productos")

            # 5. Eliminar Clientes
            deleted_clientes = (
                db.query(Cliente).filter(Cliente.empresa_id == company.id).delete()
            )
            print(f"  - Eliminados {deleted_clientes} clientes")

            # 5.05 Eliminar Empleados (RRHH)
            deleted_empleados = (
                db.query(Empleado).filter(Empleado.empresa_id == company.id).delete()
            )
            print(f"  - Eliminados {deleted_empleados} empleados")

            # 5.1 Eliminar Gastos
            deleted_gastos = (
                db.query(Gasto).filter(Gasto.empresa_id == company.id).delete()
            )
            print(f"  - Eliminados {deleted_gastos} gastos")

            # 5.2 Eliminar Cierres de Caja
            deleted_cierres = (
                db.query(CierreCaja)
                .filter(CierreCaja.empresa_id == company.id)
                .delete()
            )
            print(f"  - Eliminados {deleted_cierres} cierres de caja")

            # 5.3 Eliminar Proveedores
            deleted_proveedores = (
                db.query(Proveedor).filter(Proveedor.empresa_id == company.id).delete()
            )
            print(f"  - Eliminados {deleted_proveedores} proveedores")

            # 6. Eliminar Configuraciones de Pago
            deleted_payments = (
                db.query(EmpresaMetodoPago)
                .filter(EmpresaMetodoPago.empresa_id == company.id)
                .delete()
            )
            print(f"  - Eliminados {deleted_payments} métodos de pago")

            # 7. Eliminar Ordenes de Servicio
            deleted_orders = (
                db.query(OrdenServicio)
                .filter(OrdenServicio.empresa_id == company.id)
                .delete()
            )
            print(f"  - Eliminadas {deleted_orders} órdenes de servicio")

            # 8. Eliminar Asociaciones de Usuarios
            deleted_users = (
                db.query(UsuarioEmpresa)
                .filter(UsuarioEmpresa.empresa_id == company.id)
                .delete()
            )
            print(f"  - Eliminadas {deleted_users} asociaciones de usuarios")

            # 9. Eliminar Sucursales (Bodegas ya fueron eliminadas en paso 2)
            for sucursal in sucursales:
                db.delete(sucursal)
            print(f"  - Eliminadas {len(sucursales)} sucursales")

            # 10. Eliminar Empresa
            db.delete(company)
            print(f"Empresa '{company_name}' eliminada correctamente.")

            db.commit()

        print("Purga completada exitosamente.")

    except Exception as e:
        db.rollback()
        print(f"\n❌ Error durante la purga: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    purge_companies()
