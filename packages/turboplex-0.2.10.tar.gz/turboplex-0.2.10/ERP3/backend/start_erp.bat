@echo off
TITLE ERP3 Launcher
CLS
ECHO ==========================================
ECHO       ERP3 - SYSTEM LAUNCHER
ECHO ==========================================
ECHO.
ECHO Seleccione el modo de inicio:
ECHO.
ECHO [1] Modo Programacion (Solo API)
ECHO     - Ideal para desarrollo ligero
ECHO     - Solo levanta Uvicorn (FastAPI)
ECHO.
ECHO [2] Modo Demo (Full Stack con Docker)
ECHO     - Ideal para probar Auditoria y Respaldos
ECHO     - Levanta Redis en Docker (Contenedor 'erp3-redis')
ECHO     - Levanta RQ Worker (Nueva ventana)
ECHO     - Levanta Uvicorn (Esta ventana)
ECHO.
ECHO ==========================================
SET /P M="Seleccione una opcion (1 o 2): "

REM --- CONFIGURACION DE ENTORNO VIRTUAL ---
ECHO.
ECHO Configurando entorno...
IF EXIST ".venv\Scripts\activate.bat" (
    ECHO Activando entorno virtual (./.venv)...
    CALL .venv\Scripts\activate.bat
) ELSE IF EXIST "..\.venv\Scripts\activate.bat" (
    ECHO Activando entorno virtual (../.venv)...
    CALL ..\.venv\Scripts\activate.bat
) ELSE IF EXIST ".venv310\Scripts\activate.bat" (
    ECHO Activando entorno virtual (./.venv310)...
    CALL .venv310\Scripts\activate.bat
) ELSE IF EXIST "..\.venv310\Scripts\activate.bat" (
    ECHO Activando entorno virtual (../.venv310)...
    CALL ..\.venv310\Scripts\activate.bat
) ELSE IF EXIST "venv\Scripts\activate.bat" (
    ECHO Activando entorno virtual (./venv)...
    CALL venv\Scripts\activate.bat
) ELSE IF EXIST "..\venv\Scripts\activate.bat" (
    ECHO Activando entorno virtual (../venv)...
    CALL ..\venv\Scripts\activate.bat
) ELSE (
    ECHO ADVERTENCIA: No se encontro carpeta venv.
    ECHO Asegurese de que Python y las dependencias esten en el PATH global
    ECHO o que la carpeta venv exista en backend/ o en la raiz del proyecto.
    PAUSE
)

IF "%M%"=="1" GOTO PROGRAMACION
IF "%M%"=="2" GOTO DEMO
GOTO END

:PROGRAMACION
ECHO.
ECHO Iniciando API en modo desarrollo...
ECHO Presione Ctrl+C para detener.
uvicorn app.main:app --reload
GOTO END

:DEMO
ECHO.
ECHO Verificando Docker...
docker info >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    ECHO.
    ECHO [ERROR CRITICO] Docker Desktop no esta corriendo o no esta instalado.
    ECHO Por favor inicie Docker Desktop y vuelva a intentarlo.
    PAUSE
    GOTO END
)

ECHO.
ECHO 1. Gestionando Redis en Docker...
REM Intentar iniciar el contenedor existente
docker start erp3-redis >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    ECHO Contenedor 'erp3-redis' no encontrado. Creando y ejecutando nuevo contenedor...
    docker run -d --name erp3-redis -p 6379:6379 redis
) ELSE (
    ECHO Contenedor 'erp3-redis' iniciado correctamente.
)

ECHO Verificando estado de Redis...
:WAIT_REDIS
timeout /t 2 >nul
docker exec erp3-redis redis-cli ping >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    ECHO Esperando a que Redis responda PONG...
    GOTO WAIT_REDIS
)
ECHO Redis esta LISTO y respondiendo.

ECHO.
ECHO 2. Iniciando RQ Worker...
ECHO El worker se conectara a localhost:6379 (mapeado desde Docker)

REM Determinar ruta de activacion para el Worker
SET "ACTIVATE_SCRIPT="
IF EXIST ".venv\Scripts\activate.bat" SET "ACTIVATE_SCRIPT=.venv\Scripts\activate.bat"
IF EXIST "..\.venv\Scripts\activate.bat" SET "ACTIVATE_SCRIPT=..\.venv\Scripts\activate.bat"
IF EXIST ".venv310\Scripts\activate.bat" SET "ACTIVATE_SCRIPT=.venv310\Scripts\activate.bat"
IF EXIST "..\.venv310\Scripts\activate.bat" SET "ACTIVATE_SCRIPT=..\.venv310\Scripts\activate.bat"
IF EXIST "venv\Scripts\activate.bat" SET "ACTIVATE_SCRIPT=venv\Scripts\activate.bat"
IF EXIST "..\venv\Scripts\activate.bat" SET "ACTIVATE_SCRIPT=..\venv\Scripts\activate.bat"

IF DEFINED ACTIVATE_SCRIPT (
    start "RQ Worker" cmd /k "call %ACTIVATE_SCRIPT% & rq worker high default low"
) ELSE (
    ECHO [ADVERTENCIA] No se encontro script de activacion. Intentando usar Python global...
    start "RQ Worker" cmd /k "rq worker high default low"
)
timeout /t 2 >nul

ECHO.
ECHO 3. Iniciando API...
ECHO Presione Ctrl+C para detener la API.
ECHO Nota: Para detener Redis, ejecute 'docker stop erp3-redis' manualmente.
uvicorn app.main:app --reload
GOTO END

:END
PAUSE
