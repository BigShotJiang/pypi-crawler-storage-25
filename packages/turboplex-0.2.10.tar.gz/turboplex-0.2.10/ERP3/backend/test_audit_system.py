import asyncio
import logging
from unittest.mock import MagicMock, patch

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_audit_integration():
    print("--- Testing Audit Module Integration ---")

    # Mock dependencies
    with patch(
        "app.core_modules.auditoria.listeners.SessionLocal"
    ) as mock_session_audit:
        # Setup DB Mock
        mock_db = MagicMock()
        mock_session_audit.return_value = mock_db

        # Import Listener Logic
        from app.core_modules.auditoria.listeners import handle_audit_orden_finalizada

        # Prepare Event Data
        event_data = {
            "orden_id": 12345,
            "usuario_id": 42,
            "timestamp": "2023-10-27T10:00:00",
        }

        print(f"🚀 Triggering Audit Listener with data: {event_data}")

        # Execute Listener Directly (Simulating Event Dispatch)
        await handle_audit_orden_finalizada(event_data)

        # Verification
        # Check if DB add/commit was called
        if mock_db.add.called:
            # Inspect the object passed to add()
            args, _ = mock_db.add.call_args
            audit_entry = args[0]

            print("✅ Audit Log entry created")
            print(f"   - User ID: {audit_entry.usuario_id}")
            print(f"   - Action: {audit_entry.accion}")
            print(f"   - Module: {audit_entry.modulo}")
            print(f"   - Reference ID: {audit_entry.referencia_id}")
            print(f"   - Changes (JSON): {audit_entry.cambios}")

            if (
                audit_entry.accion == "ORDEN_FINALIZADA"
                and audit_entry.usuario_id == 42
            ):
                print("✅ Audit Data Correct")
            else:
                print("❌ Audit Data Mismatch")
        else:
            print("❌ DB Add not called")


if __name__ == "__main__":
    asyncio.run(test_audit_integration())
