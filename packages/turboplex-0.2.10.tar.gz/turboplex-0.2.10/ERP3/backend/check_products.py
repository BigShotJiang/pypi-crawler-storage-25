from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto


def check():
    db = SessionLocal()
    try:
        products = db.query(Producto).all()
        print(f"Product IDs: {[p.id for p in products]}")
    finally:
        db.close()


if __name__ == "__main__":
    check()
