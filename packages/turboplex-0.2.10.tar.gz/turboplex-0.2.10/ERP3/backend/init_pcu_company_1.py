import sys
import os
from decimal import Decimal

# Add backend directory to path
backend_path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(backend_path)

from app.core.database import SessionLocal

# Import ALL models to ensure relationships are registered correctly

from app.core_modules.sistema.models import Empresa, Sucursal, Bodega, Usuario
from app.core_modules.compras.models import Proveedor, OrdenCompra, OrdenCompraDetalle
from app.core_modules.ventas.models import Producto


def seed_compras():
    print("--- Seeding Compras Module Data ---")
    db = SessionLocal()
    try:
        # 1. Get Context (Empresa MAIN, Sucursal, Bodega, Usuario)
        # Try to find ALPHA or MAIN or First available
        empresa = db.query(Empresa).filter(Empresa.codigo == "ALPHA").first()
        if not empresa:
            empresa = db.query(Empresa).filter(Empresa.codigo == "MAIN").first()
        if not empresa:
            empresa = db.query(Empresa).first()

        if not empresa:
            print("❌ No Company found. Run seed_data.py first.")
            return

        sucursal = db.query(Sucursal).filter(Sucursal.empresa_id == empresa.id).first()
        if not sucursal:
            print(f"❌ Sucursal not found for empresa {empresa.nombre}.")
            return

        bodega = db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
        usuario = db.query(Usuario).filter(Usuario.email == "admin@erp3.com").first()

        if not (sucursal and bodega and usuario):
            # Try to fetch ANY sucursal/bodega if specific ones don't exist
            if not sucursal:
                sucursal = (
                    db.query(Sucursal).filter(Sucursal.empresa_id == empresa.id).first()
                )
            if not bodega and sucursal:
                bodega = (
                    db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
                )

            if not (sucursal and bodega and usuario):
                print(
                    f"❌ Missing dependencies: Sucursal={bool(sucursal)}, Bodega={bool(bodega)}, User={bool(usuario)}"
                )
                return

        print(
            f"Context: Empresa={empresa.nombre}, Sucursal={sucursal.nombre}, Bodega={bodega.nombre}"
        )

        # 2. Create Providers
        providers_data = [
            {
                "nombre": "Detergentes Industriales SA",
                "razon_social": "Detergentes Industriales S.A.",
                "rut": "76.888.111-K",
                "giro": "Venta de Detergentes Industriales",
                "direccion": "Av. Industrial 123, Santiago",
                "plazo_pago_dias": 30,
            },
            {
                "nombre": "Insumos de Limpieza Ltda",
                "razon_social": "Comercial Insumos de Limpieza Ltda.",
                "rut": "76.999.222-K",
                "giro": "Distribuidora de Artículos de Aseo",
                "direccion": "Calle Limpia 456, Providencia",
                "plazo_pago_dias": 15,
            },
        ]

        proveedores_map = {}
        for p_data in providers_data:
            prov = (
                db.query(Proveedor)
                .filter(
                    Proveedor.rut == p_data["rut"], Proveedor.empresa_id == empresa.id
                )
                .first()
            )
            if not prov:
                prov = Proveedor(**p_data, empresa_id=empresa.id)
                db.add(prov)
                db.commit()
                db.refresh(prov)
                print(f"✅ Proveedor created: {prov.nombre}")
            else:
                print(f"ℹ️ Proveedor exists: {prov.nombre}")
            proveedores_map[prov.rut] = prov

        # 3. Create Products (Detergents) if not exist
        products_data = [
            {"nombre": "Detergente Industrial 20L", "sku": "DET-20L", "precio": 45000},
            {"nombre": "Suavizante Textil 10L", "sku": "SUAV-10L", "precio": 28000},
        ]

        productos_map = {}
        for prod_data in products_data:
            prod = (
                db.query(Producto)
                .filter(
                    Producto.sku == prod_data["sku"], Producto.empresa_id == empresa.id
                )
                .first()
            )
            if not prod:
                prod = Producto(
                    **prod_data,
                    tipo_producto="CONSUMIBLE",
                    empresa_id=empresa.id,
                    is_active=True,
                )
                db.add(prod)
                db.commit()
                db.refresh(prod)
                print(f"✅ Producto created: {prod.nombre}")
            else:
                print(f"ℹ️ Producto exists: {prod.nombre}")
            productos_map[prod.sku] = prod

        # 4. Create Orden de Compra (Example)
        # OC to Detergentes Industriales SA
        prov = proveedores_map["76.888.111-K"]
        oc_folio = "OC-2024-001"

        oc = (
            db.query(OrdenCompra)
            .filter(OrdenCompra.folio == oc_folio, OrdenCompra.empresa_id == empresa.id)
            .first()
        )
        if not oc:
            oc = OrdenCompra(
                folio=oc_folio,
                proveedor_id=prov.id,
                sucursal_id=sucursal.id,
                bodega_id=bodega.id,
                empresa_id=empresa.id,
                usuario_id=usuario.id,
                estado="ENVIADA",
                total_neto=0,  # Will calc below
                total=0,
            )
            db.add(oc)
            db.commit()
            db.refresh(oc)

            # Add Details
            detalles = [
                {
                    "sku": "DET-20L",
                    "cantidad": 10,
                    "precio": 40000,
                },  # Buying cheaper than sell price
                {"sku": "SUAV-10L", "cantidad": 5, "precio": 25000},
            ]

            total_neto = 0
            for det in detalles:
                prod = productos_map[det["sku"]]
                subtotal = det["cantidad"] * det["precio"]
                total_neto += subtotal

                detalle = OrdenCompraDetalle(
                    orden_compra_id=oc.id,
                    producto_id=prod.id,
                    cantidad=det["cantidad"],
                    precio_unitario=det["precio"],
                    subtotal=subtotal,
                )
                db.add(detalle)

            # Update Totals
            oc.total_neto = total_neto
            oc.total = total_neto * Decimal("1.19")  # IVA 19%

            db.commit()
            print(f"✅ Orden Compra created: {oc.folio} (Total: {oc.total})")
        else:
            print(f"ℹ️ Orden Compra exists: {oc.folio}")

    except Exception as e:
        print(f"❌ Error seeding compras: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    seed_compras()
