import sys
import os
from sqlalchemy import text

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.core.database import engine


def create_view():
    sql = """
    CREATE OR REPLACE VIEW v_bi_transport_performance AS
    SELECT 
        jo.empresa_id,
        jo.id AS job_order_id,
        so.id AS service_order_id,
        so.estado AS status,
        -- Extract metadata fields safely. Cast to numeric for calculations.
        COALESCE(NULLIF(so.metadata->>'distancia_km', '')::numeric, 0) AS distancia_km,
        COALESCE(NULLIF(so.metadata->>'litros_combustible', '')::numeric, 0) AS litros_combustible,
        
        ac.id AS asiento_id,
        
        -- Costo Real: Suma del DEBE de los movimientos asociados al asiento.
        -- Asumimos que el asiento de consumo tiene DEBE en cuenta de Gasto/Costo.
        COALESCE(SUM(mc.debe), 0) AS costo_real
        
    FROM service_orders so
    JOIN job_orders jo ON so.job_order_id = jo.id
    -- Link con Contabilidad
    -- El listener usa origen='SERVICE_ENGINE' y origen_id=so.id
    LEFT JOIN asientos_contables ac ON ac.origen_id = so.id AND ac.origen = 'SERVICE_ENGINE'
    LEFT JOIN movimientos_contables mc ON mc.asiento_id = ac.id
    
    WHERE 
        -- RLS Logic embedded in View
        -- Admin/App users see all. BI users see only their company.
        (
            CURRENT_USER IN ('postgres', 'erp3_user') 
            OR 
            jo.empresa_id = (
                SELECT NULLIF(regexp_replace(CURRENT_USER, 'bi_user_empresa_', ''), CURRENT_USER)::int
            )
        )
    
    GROUP BY jo.empresa_id, jo.id, so.id, ac.id, so.estado, so.metadata;
    """

    try:
        with engine.connect() as conn:
            conn.execute(text(sql))
            conn.commit()
        print(
            "✅ View v_bi_transport_performance created successfully with embedded RLS."
        )
    except Exception as e:
        print(f"❌ Error creating view: {e}")


if __name__ == "__main__":
    create_view()
