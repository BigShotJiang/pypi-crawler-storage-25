import sys
import psycopg2

DB_NAME = "erp3_db"
DB_USER = "erp3_user"
DB_PASS = "erp3_pass_2026"
DB_HOST = "localhost"
DB_PORT = "5432"


def check_connection():
    print(f"Checking connection to {DB_NAME} as {DB_USER}...")
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT
        )
        conn.close()
        print("SUCCESS: Connection established successfully.")
        return True
    except psycopg2.OperationalError as e:
        print(f"FAILURE: Could not connect to {DB_NAME}.")
        print(e)
        return False


if __name__ == "__main__":
    if check_connection():
        sys.exit(0)
    else:
        sys.exit(1)
