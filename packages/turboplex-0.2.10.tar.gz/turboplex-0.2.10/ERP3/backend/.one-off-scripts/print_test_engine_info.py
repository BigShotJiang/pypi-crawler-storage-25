import os
import sys
from sqlalchemy import inspect

backend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if backend_dir not in sys.path:
    sys.path.append(backend_dir)

os.environ.setdefault(
    "TEST_DATABASE_URL",
    "postgresql://erp3_test_admin:erp3_test_admin@localhost/erp3_test",
)
os.environ.setdefault("TEST_DATABASE_NAME", "erp3_test")

import tests.conftest as c

print("URL:", c.TEST_DATABASE_URL)
ins = inspect(c.engine)
tables = ins.get_table_names(schema="public")
print("Tables count:", len(tables))
print("Has metodos_pago:", "metodos_pago" in tables)
print("Sample:", sorted(tables)[:15])
