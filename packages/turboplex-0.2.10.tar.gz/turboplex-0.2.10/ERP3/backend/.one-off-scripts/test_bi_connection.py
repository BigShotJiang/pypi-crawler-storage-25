import sys
import os
import secrets
import string
from sqlalchemy import text, create_engine

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.core.database import SessionLocal, engine
from app.core_modules.sistema.models import Empresa


def test_bi():
    db = SessionLocal()
    try:
        # 1. Find the Mining Company created by test_mining_scenario.py
        company = (
            db.query(Empresa)
            .filter(Empresa.nombre.ilike("%Mining Corp%"))
            .order_by(Empresa.id.desc())
            .first()
        )

        if not company:
            print("❌ Mining company not found. Run test_mining_scenario.py first.")
            return

        print(f"🏢 Testing BI for Company: {company.nombre} (ID: {company.id})")

        # 2. Ensure BI is enabled
        if not company.pwr_bi_enabled:
            print("   Enabling Power BI module...")
            company.pwr_bi_enabled = True
            db.commit()

        # 3. Create BI User (Simulating the API logic)
        db_user = f"bi_user_empresa_{company.id}"
        safe_alphabet = string.ascii_letters + string.digits
        db_password = "".join(secrets.choice(safe_alphabet) for i in range(16))

        print(f"🔑 Generating Credentials for {db_user}...")

        # Admin connection to create role
        try:
            with engine.connect().execution_options(
                isolation_level="AUTOCOMMIT"
            ) as conn:
                # Check existence
                exists = conn.execute(
                    text("SELECT 1 FROM pg_roles WHERE rolname=:user"),
                    {"user": db_user},
                ).scalar()

                if exists:
                    conn.execute(
                        text(f"ALTER ROLE {db_user} WITH PASSWORD '{db_password}'")
                    )
                else:
                    conn.execute(
                        text(
                            f"CREATE ROLE {db_user} WITH LOGIN PASSWORD '{db_password}' NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION"
                        )
                    )

                db_name = engine.url.database
                conn.execute(text(f"GRANT CONNECT ON DATABASE {db_name} TO {db_user}"))
                conn.execute(text(f"GRANT USAGE ON SCHEMA public TO {db_user}"))
                # Match API logic: Grant only on View
                conn.execute(
                    text(f"GRANT SELECT ON v_bi_transport_performance TO {db_user}")
                )
                print("   User configured in DB (View Access Only).")

        except Exception as e:
            print(f"❌ Error creating DB user: {e}")
            return

        # 4. Connect as BI User
        print(f"🔌 Connecting as {db_user}...")

        # Construct BI URL
        str(engine.url)
        # SQLAlchemy URL object modification
        bi_url = engine.url.set(username=db_user, password=db_password)

        bi_engine = create_engine(bi_url)

        try:
            with bi_engine.connect() as conn:
                print("   Connection Successful!")

                # 5. Query the View
                query = text(
                    "SELECT * FROM v_bi_transport_performance WHERE empresa_id = :eid"
                )
                result = conn.execute(query, {"eid": company.id})
                rows = result.fetchall()

                print(f"\n📊 BI Report Data ({len(rows)} rows):")
                print("-" * 80)
                print(
                    f"{'SO ID':<10} | {'Status':<15} | {'Dist (km)':<10} | {'Litros':<10} | {'Costo ($)':<12} | {'$/KM':<10}"
                )
                print("-" * 80)

                for row in rows:
                    # Access by name or index
                    so_id = row.service_order_id
                    status = row.status
                    dist = row.distancia_km
                    litros = row.litros_combustible
                    costo = row.costo_real

                    kpi = 0
                    if dist and float(dist) > 0 and costo:
                        kpi = float(costo) / float(dist)

                    print(
                        f"{so_id:<10} | {status:<15} | {str(dist):<10} | {str(litros):<10} | {str(costo):<12} | {kpi:.2f}"
                    )

                print("-" * 80)

                if len(rows) > 0:
                    print("✅ BI Test Passed: Data retrieved and KPIs calculated.")
                else:
                    print(
                        "⚠️ BI Test Warning: No data found (Did you run the mining scenario?)"
                    )

        except Exception as e:
            print(f"❌ BI Connection/Query Failed: {e}")
            # Check if it's a permission error
            if "permission denied" in str(e).lower():
                print("   -> Permission Error. Check GRANT statements.")

    except Exception as e:
        print(f"❌ General Error: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    test_bi()
