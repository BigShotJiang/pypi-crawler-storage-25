import sys
import os
from sqlalchemy import text

# Asegurar que el paquete 'app' esté en el PYTHONPATH
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app.core.database import SessionLocal, engine
from app.core.config import settings
from app.core_modules.sistema.models import Usuario


def main():
    email = sys.argv[1] if len(sys.argv) > 1 else "admin@demo.cl"
    print(f"DATABASE_URL={settings.DATABASE_URL}")

    # Verificar conexión a la DB
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        print("DB_OK: Conexión exitosa.")
    except Exception as e:
        print(f"DB_FAIL: {e}")
        return 2

    # Verificar existencia de usuario por email
    db = SessionLocal()
    try:
        # Bypass RLS para consultas administrativas globales
        try:
            db.info["allow_no_tenant"] = True
            db.info["system_startup"] = True
        except Exception:
            pass
        count = db.query(Usuario).filter(Usuario.email == email).count()
        print(f"USER_CHECK: {email} -> {count} encontrado(s)")
        return 0
    except Exception as e:
        print(f"USER_FAIL: {e}")
        return 3
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
