from sqlalchemy import create_engine, inspect

DATABASE_URL = "postgresql://postgres:keita@localhost:5432/erp3_db"


def list_tables():
    engine = create_engine(DATABASE_URL)
    inspector = inspect(engine)
    print("Tablas existentes:")
    for table_name in inspector.get_table_names():
        print(f"- {table_name}")


if __name__ == "__main__":
    list_tables()
