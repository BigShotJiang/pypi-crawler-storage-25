import sys
from pathlib import Path

# Add backend to sys.path
backend_path = Path(__file__).parent.parent
sys.path.append(str(backend_path))

from app.core.database import SessionLocal
from app.core_modules.service_engine.models import ServiceWorkflow

# Import other models to avoid mapping errors
from sqlalchemy import func


def clean_duplicates():
    db = SessionLocal()
    try:
        # Find duplicates
        duplicates = (
            db.query(ServiceWorkflow.name, func.count(ServiceWorkflow.id))
            .group_by(ServiceWorkflow.name)
            .having(func.count(ServiceWorkflow.id) > 1)
            .all()
        )

        for name, count in duplicates:
            print(f"Found {count} entries for '{name}'")
            # Get all entries
            workflows = (
                db.query(ServiceWorkflow)
                .filter(ServiceWorkflow.name == name)
                .order_by(ServiceWorkflow.id.desc())
                .all()
            )
            # Keep the latest one (first in list because desc), delete others
            to_delete = workflows[1:]
            for wf in to_delete:
                print(f"Deleting duplicate ID {wf.id}")
                db.delete(wf)

        db.commit()
        print("Duplicates cleaned.")
    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    clean_duplicates()
