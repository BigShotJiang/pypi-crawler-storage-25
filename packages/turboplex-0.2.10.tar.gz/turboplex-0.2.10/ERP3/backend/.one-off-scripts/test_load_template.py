import sys
from pathlib import Path

# Add backend to sys.path
backend_path = Path(__file__).parent.parent
sys.path.append(str(backend_path))

from app.core.database import SessionLocal
from app.core_modules.service_engine.services import ServiceEngineService
from app.core_modules.sistema.models import Empresa

# Import other models to ensure they are registered in SQLAlchemy
import uuid


def test_template_loading():
    db = SessionLocal()
    try:
        # 1. Create a test company
        unique_code = f"TEST_CORP_{uuid.uuid4().hex[:8]}"
        company = Empresa(
            nombre="Test Industries Inc.",
            codigo=unique_code,
            modulos_activos=["CORE", "SERVICE_ENGINE"],
        )
        db.add(company)
        db.commit()
        db.refresh(company)
        print(f"Created company: {company.nombre} (ID: {company.id})")

        # 2. Iterate through all supported templates
        templates_to_test = ["transporte", "mecanica", "estampados", "lavanderia"]
        created_workflows = []

        for template_key in templates_to_test:
            print(f"Initializing '{template_key}' workflow...")
            wf = ServiceEngineService.initialize_industry_workflow(
                db, company.id, template_key
            )
            created_workflows.append(wf)
            print(f"Workflow Created: {wf.name}")

            # Basic validation
            steps = wf.config["workflow"]["steps"]
            if template_key == "transporte":
                assert "SOLICITUD_RECIBIDA" in steps
            elif template_key == "mecanica":
                assert "RECEPCION_VEHICULO" in steps
            elif template_key == "estampados":
                assert "DISENO_RECIBIDO" in steps
            elif template_key == "lavanderia":
                assert "RECIBIDO" in steps

        # 3. Verify retrieval
        workflows = ServiceEngineService.get_workflow_by_company(db, company.id)
        print(f"Total workflows for company: {len(workflows)}")
        assert len(workflows) == 4

        print("SUCCESS: Templates loaded correctly.")

        # Cleanup
        for wf in created_workflows:
            db.delete(wf)
        db.delete(company)
        db.commit()
        print("Cleanup complete.")

    except Exception as e:
        print(f"ERROR: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    test_template_loading()
