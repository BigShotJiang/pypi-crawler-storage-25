import os
import sys
from sqlalchemy import create_engine, text


def main():
    target_db = os.getenv("TARGET_DB_NAME", "erp3_test")
    target_role = os.getenv("TARGET_ROLE", "erp3_test_admin")
    admin_url = os.getenv(
        "ADMIN_DATABASE_URL", "postgresql://postgres:postgres@localhost/postgres"
    )

    # Ensure DB owner
    admin_engine = create_engine(admin_url, isolation_level="AUTOCOMMIT", future=True)
    try:
        with admin_engine.connect() as conn:
            conn.execute(
                text(f'ALTER DATABASE "{target_db}" OWNER TO "{target_role}";')
            )
            conn.execute(
                text(f'GRANT CONNECT ON DATABASE "{target_db}" TO "{target_role}";')
            )
    finally:
        admin_engine.dispose()

    # Operate inside target database
    target_url = admin_url.rsplit("/", 1)[0] + f"/{target_db}"
    target_engine = create_engine(target_url, isolation_level="AUTOCOMMIT", future=True)
    try:
        with target_engine.connect() as conn:
            conn.execute(text(f'GRANT USAGE ON SCHEMA public TO "{target_role}";'))
            conn.execute(text(f'ALTER SCHEMA public OWNER TO "{target_role}";'))

            conn.execute(
                text(f'''
DO $$
DECLARE r RECORD;
BEGIN
  -- Tables
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'public'
  LOOP
    EXECUTE format('ALTER TABLE public.%I OWNER TO "{target_role}";', r.tablename);
  END LOOP;
  -- Sequences
  FOR r IN SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = 'public'
  LOOP
    EXECUTE format('ALTER SEQUENCE public.%I OWNER TO "{target_role}";', r.sequence_name);
  END LOOP;
END;
$$;
''')
            )

            conn.execute(
                text(
                    f'GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES ON ALL TABLES IN SCHEMA public TO "{target_role}";'
                )
            )
            conn.execute(
                text(
                    f'GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO "{target_role}";'
                )
            )
            conn.execute(
                text(
                    f'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES ON TABLES TO "{target_role}";'
                )
            )
            conn.execute(
                text(
                    f'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO "{target_role}";'
                )
            )
    finally:
        target_engine.dispose()


if __name__ == "__main__":
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)
