import psycopg2

DB_NAME = "erp3_db"
DB_USER = "erp3_user"
DB_PASS = "erp3_pass_2026"
DB_HOST = "localhost"
DB_PORT = "5432"


def list_tables():
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT
        )
        cur = conn.cursor()
        cur.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';"
        )
        tables = cur.fetchall()
        conn.close()
        print("Tables found:")
        for table in tables:
            print(f"- {table[0]}")
        return [t[0] for t in tables]
    except Exception as e:
        print(f"Error: {e}")
        return []


if __name__ == "__main__":
    tables = list_tables()
    if "job_orders" in tables:
        print("Table 'job_orders' EXISTS.")
    else:
        print("Table 'job_orders' DOES NOT EXIST.")
