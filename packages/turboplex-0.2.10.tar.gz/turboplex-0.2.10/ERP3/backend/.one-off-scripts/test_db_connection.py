import psycopg2
from sqlalchemy import create_engine

# Prueba directa con psycopg2
dsn = "postgresql://erp3_user:erp3_pass_2026@localhost:5432/erp3_db"
print(f"Probando conexión con psycopg2 DSN: {dsn}")
try:
    conn = psycopg2.connect(dsn)
    print("Conexión psycopg2 exitosa")
    conn.close()
except Exception as e:
    print(f"Error psycopg2: {e}")

# Prueba con SQLAlchemy
print("\nProbando conexión con SQLAlchemy")
try:
    engine = create_engine(dsn)
    with engine.connect() as conn:
        print("Conexión SQLAlchemy exitosa")
except Exception as e:
    print(f"Error SQLAlchemy: {e}")
