import psycopg2

DB_NAME = "erp3_db"
DB_USER = "erp3_user"
DB_PASS = "erp3_pass_2026"
DB_HOST = "localhost"
DB_PORT = "5432"


def drop_alembic_version():
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT
        )
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS alembic_version;")
        conn.commit()
        conn.close()
        print("Table 'alembic_version' dropped successfully.")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    drop_alembic_version()
