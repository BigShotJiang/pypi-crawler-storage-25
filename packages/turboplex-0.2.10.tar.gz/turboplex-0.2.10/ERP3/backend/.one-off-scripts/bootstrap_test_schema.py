import os
import sys
import logging
from sqlalchemy import create_engine, text, inspect


def main() -> None:
    backend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    if backend_dir not in sys.path:
        sys.path.append(backend_dir)

    # Verbose SQL de SQLAlchemy
    logging.basicConfig(level=logging.INFO)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.INFO)

    # Importar Base y todos los modelos core para poblar Base.metadata
    from app.core.database import Base  # noqa: F401
    from app.core_modules.sistema import models as sistema_models  # noqa: F401
    from app.core_modules.ventas import models as ventas_models  # noqa: F401
    from app.core_modules.finanzas import models as finanzas_models  # noqa: F401
    from app.core_modules.compras import models as compras_models  # noqa: F401
    from app.core_modules.crm import models as crm_models  # noqa: F401
    from app.core_modules.facturacion import models as facturacion_models  # noqa: F401
    from app.core_modules.rrhh import models as rrhh_models  # noqa: F401
    from app.core_modules.ti import models as ti_models  # noqa: F401
    from app.core_modules.legal import models as legal_models  # noqa: F401
    from app.core_modules.service_engine import models as service_engine_models  # noqa: F401
    from app.core_modules.webhooks import models as webhooks_models  # noqa: F401
    from app.core_modules.auditoria import models as auditoria_models  # noqa: F401
    from app.core_modules.billing import models as billing_models  # noqa: F401

    url = os.getenv(
        "TEST_BOOTSTRAP_URL",
        "postgresql://erp3_test_admin:erp3_test_admin@localhost/erp3_test",
    )
    engine = create_engine(url, future=True)
    try:
        # Print de control: tablas detectadas por el metadata
        tablas_metadata = sorted(list(Base.metadata.tables.keys()))
        print(f"Tablas detectadas en Metadata: {tablas_metadata}")

        Base.metadata.create_all(bind=engine)

        # Prueba de fuego: DDL crudo
        with engine.begin() as conn:
            conn.execute(text("CREATE TABLE IF NOT EXISTS prueba_manual (id int)"))

        # Verificación posterior: listar tablas en public
        insp = inspect(engine)
        tablas_public = insp.get_table_names(schema="public")
        print(f"Tablas presentes en public: {sorted(tablas_public)}")
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()
