import sys
import os
import random
import asyncio
from sqlalchemy.orm import joinedload

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Usuario
from app.core_modules.service_engine.models import JobOrder, ServiceOrder
from app.core_modules.ventas.models import Producto
from app.core_modules.finanzas.listeners import handle_service_update_accounting


async def inject_data():
    db = SessionLocal()
    try:
        print("💉 Injecting Demo Data for BI Report...")

        # 1. Find Mining Corp
        company = (
            db.query(Empresa)
            .filter(Empresa.nombre.ilike("%Mining Corp%"))
            .order_by(Empresa.id.desc())
            .first()
        )
        if not company:
            print("❌ Mining Corp not found. Run test_mining_scenario.py first.")
            return

        print(f"   Company: {company.nombre}")

        # 2. Find Transport Product
        producto = (
            db.query(Producto)
            .filter(
                Producto.empresa_id == company.id, Producto.nombre.ilike("%Transporte%")
            )
            .options(joinedload(Producto.receta))
            .first()
        )

        if not producto:
            print("❌ Transport Product not found.")
            return

        print(f"   Product: {producto.nombre}")

        # Determine Base Recipe Qty (Diesel per Unit)
        # We assume the first insumo is the fuel
        base_litros_per_unit = 50.0  # Fallback
        if producto.receta and producto.receta.insumos:
            base_litros_per_unit = float(producto.receta.insumos[0].cantidad)

        print(f"   Base Fuel Consumption: {base_litros_per_unit} L/unit")

        # 3. Create Job Order Container
        user = db.query(Usuario).filter(Usuario.email.ilike("%miner%")).first()
        if not user:
            # Fallback to any user
            user = db.query(Usuario).first()

        # Find a branch
        sucursal = company.sucursales[0] if company.sucursales else None
        if not sucursal:
            print("❌ No Branch found.")
            return

        job = JobOrder(
            description="Lote Demo BI Transporte",
            empresa_id=company.id,
            sucursal_id=sucursal.id,
            usuario_id=user.id,
        )
        db.add(job)
        db.flush()

        # 4. Create 10 Service Orders
        for i in range(1, 11):
            # Random Data
            dist_km = random.randint(50, 300)

            # Efficiency factor (km/L): e.g. 2.5 km/L -> 0.4 L/km
            # Let's say trucks do between 2 and 4 km/L
            efficiency = random.uniform(2.0, 4.0)
            litros = round(dist_km / efficiency, 2)

            # Calculate Qty for Accounting
            # We want Accounting Cost to match Litros used.
            # Cost = Qty * Base_Litros * Price
            # We want Qty * Base_Litros = Litros
            # So Qty = Litros / Base_Litros
            qty_accounting = round(litros / base_litros_per_unit, 4)

            meta = {
                "distancia_km": dist_km,
                "litros_combustible": litros,
                "qty": qty_accounting,  # Drive the accounting logic
                "observaciones": f"Ruta simulada #{i}",
            }

            so = ServiceOrder(
                job_order_id=job.id,
                empresa_id=company.id,
                sucursal_id=sucursal.id,
                usuario_id=user.id,
                producto_id=producto.id,
                status="PENDING",
                metadata_info=meta,
                total_estimado=int(producto.precio),
            )
            db.add(so)
            db.flush()

            # 5. Transition to COMPLETED
            so.status = "COMPLETED"
            db.add(so)
            db.commit()  # Commit so listener can find it

            # Trigger Accounting
            await handle_service_update_accounting(
                {
                    "service_order_id": so.id,
                    "status": "COMPLETED",
                    "usuario_id": user.id,
                }
            )

            print(
                f"   ✅ Created SO #{so.id}: {dist_km}km, {litros}L, Qty={qty_accounting}"
            )

        print("🎉 Data Injection Complete.")

    except Exception as e:
        print(f"❌ Error: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    asyncio.run(inject_data())
