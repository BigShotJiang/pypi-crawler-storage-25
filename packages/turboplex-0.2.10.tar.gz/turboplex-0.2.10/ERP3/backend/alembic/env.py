from logging.config import fileConfig

from sqlalchemy import text
from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

import importlib
import os
import pkgutil
import sys

# Agregar el directorio raíz al path para importar app
sys.path.insert(0, os.getcwd())

from app.core.config import settings
from app.core.database import Base

# Importar todos los modelos para que Alembic los detecte
def _import_models_from(pkg_name: str) -> None:
    pkg = importlib.import_module(pkg_name)
    for mod in pkgutil.walk_packages(pkg.__path__, pkg.__name__ + "."):
        if mod.name.endswith(".models"):
            importlib.import_module(mod.name)


_import_models_from("app.core_modules")
_import_models_from("app.addons")

def _quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _select_postgres_schema_for_migrations(connection) -> str | None:
    def has_create_priv(schema: str) -> bool:
        try:
            return bool(
                connection.execute(
                    text("SELECT has_schema_privilege(current_user, :schema, 'CREATE')"),
                    {"schema": schema},
                ).scalar()
            )
        except Exception:
            return False

    candidates: list[str] = []
    db_user: str | None = None
    try:
        u = connection.execute(text("SELECT current_user")).scalar()
        if isinstance(u, str) and u.strip():
            db_user = u.strip()
    except Exception:
        db_user = None
    try:
        raw = connection.execute(text("SHOW search_path")).scalar()
        if isinstance(raw, str) and raw.strip():
            for part in raw.split(","):
                schema = part.strip()
                if schema.startswith('"') and schema.endswith('"') and len(schema) >= 2:
                    schema = schema[1:-1]
                if schema == "$user" and db_user:
                    schema = db_user
                if schema in ("pg_catalog", "information_schema"):
                    continue
                if schema:
                    candidates.append(schema)
    except Exception:
        pass

    for schema in candidates:
        if has_create_priv(schema):
            return schema

    desired = settings.MIGRATIONS_SCHEMA or os.getenv("MIGRATIONS_SCHEMA") or "erp3_migrations"
    try:
        can_create_schema = bool(
            connection.execute(
                text(
                    "SELECT has_database_privilege(current_user, current_database(), 'CREATE')"
                )
            ).scalar()
        )
    except Exception:
        can_create_schema = False

    if can_create_schema:
        try:
            connection.execute(
                text(f"CREATE SCHEMA IF NOT EXISTS {_quote_ident(desired)} AUTHORIZATION current_user")
            )
        except Exception:
            pass
        if has_create_priv(desired):
            return desired

    try:
        row = connection.execute(
            text(
                """
                SELECT nspname
                FROM pg_namespace
                WHERE nspname NOT LIKE 'pg_%'
                  AND nspname <> 'information_schema'
                  AND has_schema_privilege(current_user, nspname, 'CREATE')
                ORDER BY (nspname = 'public') DESC, nspname
                LIMIT 1
                """
            )
        ).first()
        if row and isinstance(row[0], str) and row[0]:
            return row[0]
    except Exception:
        pass

    return None


# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Sobrescribir la URL de la base de datos con la configuración de la app
migrations_url = os.getenv("MIGRATIONS_DATABASE_URL") or str(settings.DATABASE_URL)
if settings.MIGRATIONS_DATABASE_URL:
    migrations_url = settings.MIGRATIONS_DATABASE_URL
config.set_main_option("sqlalchemy.url", migrations_url)

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    version_schema = settings.MIGRATIONS_SCHEMA or os.getenv("MIGRATIONS_SCHEMA")
    configure_kwargs: dict[str, object] = {
        "url": url,
        "target_metadata": target_metadata,
        "literal_binds": True,
        "dialect_opts": {"paramstyle": "named"},
        "transactional_ddl": True,
    }
    if version_schema:
        configure_kwargs["version_table_schema"] = version_schema
    context.configure(**configure_kwargs)

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        version_schema: str | None = None
        if connection.dialect.name == "postgresql":
            version_schema = _select_postgres_schema_for_migrations(connection)
            if not version_schema:
                desired = (
                    settings.MIGRATIONS_SCHEMA
                    or os.getenv("MIGRATIONS_SCHEMA")
                    or "erp3_migrations"
                )
                raise RuntimeError(
                    "No se encontró un schema con privilegios CREATE para ejecutar migraciones. "
                    "Opciones: (1) proveer un usuario con permisos via MIGRATIONS_DATABASE_URL "
                    "o (2) crear/otorgar permisos en un schema y apuntar MIGRATIONS_SCHEMA. "
                    f"Sugerido: crear schema {desired} y otorgar USAGE+CREATE al usuario de conexión."
                )
            has_public = bool(
                connection.execute(
                    text(
                        "SELECT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'public')"
                    )
                ).scalar()
            )
            parts: list[str] = []
            if has_public:
                parts.append(_quote_ident("public"))
            if version_schema != "public":
                parts.append(_quote_ident(version_schema))
            if parts:
                connection.execute(text("SET search_path TO " + ", ".join(parts)))
            if connection.in_transaction():
                connection.commit()
        configure_kwargs: dict[str, object] = {
            "connection": connection,
            "target_metadata": target_metadata,
            "include_schemas": True,
            "transactional_ddl": True,
        }
        if version_schema:
            configure_kwargs["version_table_schema"] = version_schema
        context.configure(**configure_kwargs)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
