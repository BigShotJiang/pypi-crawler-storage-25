"""inventario add empresa_id and enable RLS hard

Revision ID: 3c8a1f7d2b90
Revises: 7e9b0c3d1abc
Create Date: 2026-03-24

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "3c8a1f7d2b90"
down_revision: Union[str, None, Sequence[str]] = "7e9b0c3d1abc"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _disable_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    op.add_column(
        "inventario",
        sa.Column("empresa_id", sa.dialects.postgresql.UUID(as_uuid=True), nullable=True),
    )

    op.execute(
        """
        UPDATE inventario i
        SET empresa_id = p.empresa_id
        FROM productos p
        WHERE i.producto_id = p.id
          AND i.empresa_id IS NULL
        """
    )
    op.execute("DELETE FROM inventario WHERE empresa_id IS NULL")

    op.alter_column("inventario", "empresa_id", nullable=False)
    op.create_foreign_key(
        "fk_inventario_empresa_id_empresas",
        "inventario",
        "empresas",
        ["empresa_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_index(
        "ix_inventario_empresa_id",
        "inventario",
        ["empresa_id"],
        unique=False,
    )
    op.create_index(
        "ix_inventario_empresa_variant_bodega",
        "inventario",
        ["empresa_id", "variant_id", "bodega_id"],
        unique=False,
    )

    _enable_rls("inventario")


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    _disable_rls("inventario")
    op.drop_index("ix_inventario_empresa_variant_bodega", table_name="inventario")
    op.drop_index("ix_inventario_empresa_id", table_name="inventario")
    op.drop_constraint(
        "fk_inventario_empresa_id_empresas", "inventario", type_="foreignkey"
    )
    op.drop_column("inventario", "empresa_id")

