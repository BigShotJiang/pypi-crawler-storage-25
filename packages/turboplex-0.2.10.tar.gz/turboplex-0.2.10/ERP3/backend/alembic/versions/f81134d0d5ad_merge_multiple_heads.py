"""Merge multiple heads

Revision ID: f81134d0d5ad
Revises: 0b7e2c1d9a4f, a4c2b1d0e9f3
Create Date: 2026-03-20 10:48:15.831819

"""
from typing import Sequence, Union


# revision identifiers, used by Alembic.
revision: str = 'f81134d0d5ad'
down_revision: Union[str, Sequence[str], None] = ('0b7e2c1d9a4f', 'a4c2b1d0e9f3')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
