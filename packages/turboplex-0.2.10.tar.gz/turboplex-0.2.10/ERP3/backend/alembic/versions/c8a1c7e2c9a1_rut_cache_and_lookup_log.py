"""Create rut_cache and rut_lookup_log tables

Revision ID: c8a1c7e2c9a1
Revises: f81134d0d5ad
Create Date: 2026-03-25
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

# revision identifiers, used by Alembic.
revision = 'c8a1c7e2c9a1'
down_revision = 'f81134d0d5ad'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'rut_cache',
        sa.Column('rut_normalized', sa.String(), primary_key=True, index=True),
        sa.Column('razon_social', sa.Text(), nullable=True),
        sa.Column('actividades_economicas', JSONB, nullable=True),
        sa.Column('domicilios', JSONB, nullable=True),
        sa.Column('presenta_inicio', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('fecha_inicio', sa.String(), nullable=True),
        sa.Column('es_pyme', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('web_facturacion', sa.String(), nullable=True),
        sa.Column('provider_name', sa.String(), nullable=True),
        sa.Column('last_refreshed_at', sa.DateTime(), nullable=True),
        sa.Column('ttl_expires_at', sa.DateTime(), nullable=True),
    )
    op.execute(sa.text("DROP INDEX IF EXISTS ix_rut_cache_rut_normalized"))
    op.create_index('ix_rut_cache_rut_normalized', 'rut_cache', ['rut_normalized'], unique=True)

    op.create_table(
        'rut_lookup_log',
        sa.Column('id', sa.String(), primary_key=True),
        sa.Column('rut_normalized', sa.String(), nullable=False, index=True),
        sa.Column('user_id', sa.String(), nullable=True),
        sa.Column('empresa_id', sa.String(), nullable=True),
        sa.Column('source', sa.String(), nullable=False),
        sa.Column('provider_name', sa.String(), nullable=True),
        sa.Column('http_status', sa.String(), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
    )
    op.execute(sa.text("DROP INDEX IF EXISTS ix_rut_lookup_log_rut_normalized"))
    op.create_index('ix_rut_lookup_log_rut_normalized', 'rut_lookup_log', ['rut_normalized'])


def downgrade():
    op.drop_index('ix_rut_lookup_log_rut_normalized', table_name='rut_lookup_log')
    op.drop_table('rut_lookup_log')
    op.drop_index('ix_rut_cache_rut_normalized', table_name='rut_cache')
    op.drop_table('rut_cache')
