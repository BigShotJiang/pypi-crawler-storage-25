"""add_import_run_id_to_movimientos_stock

Revision ID: f2a8c4d91b3a
Revises: fe536e8553e1
Create Date: 2026-03-19 12:25:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app

# revision identifiers, used by Alembic.
revision: str = "f2a8c4d91b3a"
down_revision: Union[str, Sequence[str], None] = "fe536e8553e1"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "movimientos_stock",
        sa.Column("import_run_id", app.core.custom_types.GUID(), nullable=True),
    )
    op.create_index(
        op.f("ix_movimientos_stock_import_run_id"),
        "movimientos_stock",
        ["import_run_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_movimientos_stock_import_run_id"), table_name="movimientos_stock")
    op.drop_column("movimientos_stock", "import_run_id")

