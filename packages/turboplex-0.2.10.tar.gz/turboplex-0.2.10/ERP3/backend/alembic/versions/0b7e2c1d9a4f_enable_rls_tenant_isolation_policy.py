"""enable_rls_tenant_isolation_policy

Revision ID: 0b7e2c1d9a4f
Revises: 9c4d2a1b7e3f
Create Date: 2026-03-20 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0b7e2c1d9a4f"
down_revision: Union[str, Sequence[str], None] = "9c4d2a1b7e3f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _disable_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return
    for table_name in [
        "ventas",
        "detalles_venta",
        "asientos_contables",
        "movimientos_contables",
        "documentos_tributarios",
        "documentos_tributarios_detalles",
    ]:
        _enable_rls(table_name)


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return
    for table_name in [
        "documentos_tributarios_detalles",
        "documentos_tributarios",
        "movimientos_contables",
        "asientos_contables",
        "detalles_venta",
        "ventas",
    ]:
        _disable_rls(table_name)

