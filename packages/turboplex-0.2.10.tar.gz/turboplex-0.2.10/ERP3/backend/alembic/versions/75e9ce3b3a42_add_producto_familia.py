"""add_producto_familia

Revision ID: 75e9ce3b3a42
Revises: 2f0a9d8c7b61
Create Date: 2026-03-22 12:38:37.011373

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = '75e9ce3b3a42'
down_revision: Union[str, Sequence[str], None] = '2f0a9d8c7b61'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column('productos', sa.Column('familia', sa.String(), nullable=True))


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('productos', 'familia')
