"""create_portal_payment_notifications

Revision ID: aa12bb34cc56
Revises: d4c6f1a9b3e2
Create Date: 2026-03-17 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app


revision: str = "aa12bb34cc56"
down_revision: Union[str, Sequence[str], None] = "d4c6f1a9b3e2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "portal_payment_notifications",
        sa.Column("id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("cliente_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("dte_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("comprobante_path", sa.String(), nullable=False),
        sa.Column("comprobante_mime_type", sa.String(), nullable=True),
        sa.Column(
            "estado",
            sa.String(),
            nullable=False,
            server_default=sa.text("'PENDIENTE'"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=True,
            server_default=sa.text("now()"),
        ),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["cliente_id"], ["clientes.id"]),
        sa.ForeignKeyConstraint(["dte_id"], ["documentos_tributarios.id"]),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_portal_payment_notifications_cliente_id"),
        "portal_payment_notifications",
        ["cliente_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_portal_payment_notifications_dte_id"),
        "portal_payment_notifications",
        ["dte_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_portal_payment_notifications_empresa_id"),
        "portal_payment_notifications",
        ["empresa_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_portal_payment_notifications_id"),
        "portal_payment_notifications",
        ["id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_portal_payment_notifications_id"), table_name="portal_payment_notifications")
    op.drop_index(op.f("ix_portal_payment_notifications_empresa_id"), table_name="portal_payment_notifications")
    op.drop_index(op.f("ix_portal_payment_notifications_dte_id"), table_name="portal_payment_notifications")
    op.drop_index(op.f("ix_portal_payment_notifications_cliente_id"), table_name="portal_payment_notifications")
    op.drop_table("portal_payment_notifications")
