"""add_portal_payment_metadata

Revision ID: 7f1a2c3d4e5f
Revises: aa12bb34cc56
Create Date: 2026-03-18 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app

revision: str = "7f1a2c3d4e5f"
down_revision: Union[str, Sequence[str], None] = "aa12bb34cc56"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "portal_payment_notifications",
        sa.Column("pago_batch_id", app.core.custom_types.GUID(), nullable=True),
    )
    op.add_column(
        "portal_payment_notifications",
        sa.Column("monto", sa.Numeric(18, 2), nullable=True),
    )
    op.add_column(
        "portal_payment_notifications",
        sa.Column("numero_operacion", sa.String(), nullable=True),
    )
    op.add_column(
        "portal_payment_notifications",
        sa.Column("banco", sa.String(), nullable=True),
    )
    op.create_index(
        op.f("ix_portal_payment_notifications_pago_batch_id"),
        "portal_payment_notifications",
        ["pago_batch_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        op.f("ix_portal_payment_notifications_pago_batch_id"),
        table_name="portal_payment_notifications",
    )
    op.drop_column("portal_payment_notifications", "banco")
    op.drop_column("portal_payment_notifications", "numero_operacion")
    op.drop_column("portal_payment_notifications", "monto")
    op.drop_column("portal_payment_notifications", "pago_batch_id")
