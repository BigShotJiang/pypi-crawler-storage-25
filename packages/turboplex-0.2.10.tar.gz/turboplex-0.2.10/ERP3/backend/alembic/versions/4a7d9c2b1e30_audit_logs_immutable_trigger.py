"""audit_logs immutable trigger (block UPDATE/DELETE)

Revision ID: 4a7d9c2b1e30
Revises: 3c8a1f7d2b90
Create Date: 2026-03-24

"""

from typing import Sequence, Union

from alembic import op


revision: str = "4a7d9c2b1e30"
down_revision: Union[str, None, Sequence[str]] = "3c8a1f7d2b90"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    op.execute(
        """
        CREATE OR REPLACE FUNCTION audit_logs_immutable()
        RETURNS trigger AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                RAISE EXCEPTION 'audit_logs es inmutable: DELETE prohibido' USING ERRCODE = '42501';
                RETURN OLD;
            END IF;
            IF TG_OP = 'UPDATE' THEN
                RAISE EXCEPTION 'audit_logs es inmutable: UPDATE prohibido' USING ERRCODE = '42501';
                RETURN NEW;
            END IF;
            RAISE EXCEPTION 'audit_logs es inmutable' USING ERRCODE = '42501';
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        DROP TRIGGER IF EXISTS trg_audit_logs_immutable ON audit_logs;
        CREATE TRIGGER trg_audit_logs_immutable
        BEFORE UPDATE OR DELETE ON audit_logs
        FOR EACH ROW
        EXECUTE FUNCTION audit_logs_immutable();
        """
    )


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    op.execute("DROP TRIGGER IF EXISTS trg_audit_logs_immutable ON audit_logs;")
    op.execute("DROP FUNCTION IF EXISTS audit_logs_immutable();")

