"""portal_roles_scope_and_quote_items

Revision ID: c91f71cbfb21
Revises: 71b1b7e14b87
Create Date: 2026-03-18 22:18:17.750980

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
import app


# revision identifiers, used by Alembic.
revision: str = 'c91f71cbfb21'
down_revision: Union[str, Sequence[str], None] = '71b1b7e14b87'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    portal_user_cols = {c["name"] for c in inspector.get_columns("portal_users")}
    if "role" not in portal_user_cols:
        op.add_column(
            "portal_users",
            sa.Column(
                "role", sa.String(), server_default=sa.text("'buyer'"), nullable=False
            ),
        )
    if "scope_sucursales" not in portal_user_cols:
        op.add_column(
            "portal_users",
            sa.Column(
                "scope_sucursales",
                postgresql.JSONB(astext_type=sa.Text()),
                server_default=sa.text("'[]'::jsonb"),
                nullable=True,
            ),
        )

    crm_oportunidades_cols = {c["name"] for c in inspector.get_columns("crm_oportunidades")}
    if "sucursal_id" not in crm_oportunidades_cols:
        op.add_column(
            "crm_oportunidades",
            sa.Column("sucursal_id", app.core.custom_types.GUID(), nullable=True),
        )
    crm_oportunidades_indexes = {
        i["name"] for i in inspector.get_indexes("crm_oportunidades")
    }
    if op.f("ix_crm_oportunidades_sucursal_id") not in crm_oportunidades_indexes:
        op.create_index(
            op.f("ix_crm_oportunidades_sucursal_id"),
            "crm_oportunidades",
            ["sucursal_id"],
            unique=False,
        )
    crm_oportunidades_fks = {
        fk.get("name") for fk in inspector.get_foreign_keys("crm_oportunidades")
    }
    if "fk_crm_oportunidades_sucursal_id_sucursales" not in crm_oportunidades_fks:
        op.create_foreign_key(
            "fk_crm_oportunidades_sucursal_id_sucursales",
            "crm_oportunidades",
            "sucursales",
            ["sucursal_id"],
            ["id"],
        )

    op.execute(
        """
        UPDATE crm_oportunidades o
        SET sucursal_id = b.sucursal_id
        FROM bodegas b
        WHERE o.sucursal_id IS NULL
          AND o.bodega_id IS NOT NULL
          AND b.id = o.bodega_id
        """
    )
    op.execute(
        """
        UPDATE crm_oportunidades o
        SET sucursal_id = s.id
        FROM (
          SELECT DISTINCT ON (empresa_id) empresa_id, id
          FROM sucursales
          ORDER BY empresa_id, created_at ASC
        ) s
        WHERE o.sucursal_id IS NULL
          AND o.empresa_id = s.empresa_id
        """
    )

    crm_cotizaciones_cols = {c["name"] for c in inspector.get_columns("crm_cotizaciones")}
    if "vendedor_operador_id" not in crm_cotizaciones_cols:
        op.add_column(
            "crm_cotizaciones",
            sa.Column(
                "vendedor_operador_id", app.core.custom_types.GUID(), nullable=True
            ),
        )
    crm_cotizaciones_indexes = {i["name"] for i in inspector.get_indexes("crm_cotizaciones")}
    if op.f("ix_crm_cotizaciones_vendedor_operador_id") not in crm_cotizaciones_indexes:
        op.create_index(
            op.f("ix_crm_cotizaciones_vendedor_operador_id"),
            "crm_cotizaciones",
            ["vendedor_operador_id"],
            unique=False,
        )
    crm_cotizaciones_fks = {fk.get("name") for fk in inspector.get_foreign_keys("crm_cotizaciones")}
    if "fk_crm_cotizaciones_vendedor_operador_id_usuarios" not in crm_cotizaciones_fks:
        op.create_foreign_key(
            "fk_crm_cotizaciones_vendedor_operador_id_usuarios",
            "crm_cotizaciones",
            "usuarios",
            ["vendedor_operador_id"],
            ["id"],
        )

    def enum_value_exists(enum_name: str, value: str) -> bool:
        exists = bind.execute(
            sa.text(
                """
                SELECT 1
                FROM pg_type t
                JOIN pg_enum e ON t.oid = e.enumtypid
                WHERE t.typname = :enum_name
                  AND e.enumlabel = :enum_value
                LIMIT 1
                """
            ),
            {"enum_name": enum_name, "enum_value": value},
        ).scalar()
        return exists is not None

    with op.get_context().autocommit_block():
        for new_value in [
            "BORRADOR_CLIENTE",
            "PENDIENTE_VENDEDOR",
            "PROPUESTA_ENVIADA",
            "ACEPTADA_OC",
        ]:
            if not enum_value_exists("estadocotizacion", new_value):
                bind.execute(
                    sa.text(f"ALTER TYPE estadocotizacion ADD VALUE '{new_value}'")
                )

    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'estadoitemcotizacion') THEN
                CREATE TYPE estadoitemcotizacion AS ENUM ('SOLICITADO', 'SUGERIDO', 'RECHAZADO_CLIENTE');
            END IF;
        END$$;
        """
    )
    estado_item_enum = postgresql.ENUM(
        "SOLICITADO",
        "SUGERIDO",
        "RECHAZADO_CLIENTE",
        name="estadoitemcotizacion",
        create_type=False,
    )

    if not inspector.has_table("crm_cotizaciones_items"):
        op.create_table(
            "crm_cotizaciones_items",
            sa.Column("id", app.core.custom_types.GUID(), nullable=False),
            sa.Column("cotizacion_id", app.core.custom_types.GUID(), nullable=False),
            sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=False),
            sa.Column("producto_id", app.core.custom_types.GUID(), nullable=False),
            sa.Column(
                "cantidad", sa.Integer(), nullable=False, server_default=sa.text("1")
            ),
            sa.Column("notas_tecnicas", sa.Text(), nullable=True),
            sa.Column(
                "producto_sugerido_id", app.core.custom_types.GUID(), nullable=True
            ),
            sa.Column("precio_neto_final", sa.Numeric(14, 2), nullable=True),
            sa.Column("fecha_entrega_linea", sa.Date(), nullable=True),
            sa.Column(
                "estado_item",
                estado_item_enum,
                nullable=False,
                server_default=sa.text("'SOLICITADO'::estadoitemcotizacion"),
            ),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=True,
                server_default=sa.text("now()"),
            ),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
            sa.ForeignKeyConstraint(["cotizacion_id"], ["crm_cotizaciones.id"]),
            sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
            sa.ForeignKeyConstraint(["producto_id"], ["productos.id"]),
            sa.ForeignKeyConstraint(["producto_sugerido_id"], ["productos.id"]),
            sa.PrimaryKeyConstraint("id"),
        )
    crm_cotizaciones_items_indexes = (
        {i["name"] for i in inspector.get_indexes("crm_cotizaciones_items")}
        if inspector.has_table("crm_cotizaciones_items")
        else set()
    )
    if op.f("ix_crm_cotizaciones_items_id") not in crm_cotizaciones_items_indexes:
        op.create_index(
            op.f("ix_crm_cotizaciones_items_id"),
            "crm_cotizaciones_items",
            ["id"],
            unique=False,
        )
    if op.f("ix_crm_cotizaciones_items_cotizacion_id") not in crm_cotizaciones_items_indexes:
        op.create_index(
            op.f("ix_crm_cotizaciones_items_cotizacion_id"),
            "crm_cotizaciones_items",
            ["cotizacion_id"],
            unique=False,
        )
    if op.f("ix_crm_cotizaciones_items_empresa_id") not in crm_cotizaciones_items_indexes:
        op.create_index(
            op.f("ix_crm_cotizaciones_items_empresa_id"),
            "crm_cotizaciones_items",
            ["empresa_id"],
            unique=False,
        )
    if op.f("ix_crm_cotizaciones_items_producto_id") not in crm_cotizaciones_items_indexes:
        op.create_index(
            op.f("ix_crm_cotizaciones_items_producto_id"),
            "crm_cotizaciones_items",
            ["producto_id"],
            unique=False,
        )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f("ix_crm_cotizaciones_items_producto_id"), table_name="crm_cotizaciones_items")
    op.drop_index(op.f("ix_crm_cotizaciones_items_empresa_id"), table_name="crm_cotizaciones_items")
    op.drop_index(op.f("ix_crm_cotizaciones_items_cotizacion_id"), table_name="crm_cotizaciones_items")
    op.drop_index(op.f("ix_crm_cotizaciones_items_id"), table_name="crm_cotizaciones_items")
    op.drop_table("crm_cotizaciones_items")

    op.drop_constraint(
        "fk_crm_cotizaciones_vendedor_operador_id_usuarios",
        "crm_cotizaciones",
        type_="foreignkey",
    )
    op.drop_index(
        op.f("ix_crm_cotizaciones_vendedor_operador_id"),
        table_name="crm_cotizaciones",
    )
    op.drop_column("crm_cotizaciones", "vendedor_operador_id")

    op.drop_index(op.f("ix_crm_oportunidades_sucursal_id"), table_name="crm_oportunidades")
    op.drop_constraint(
        "fk_crm_oportunidades_sucursal_id_sucursales",
        "crm_oportunidades",
        type_="foreignkey",
    )
    op.drop_column("crm_oportunidades", "sucursal_id")

    op.drop_column("portal_users", "scope_sucursales")
    op.drop_column("portal_users", "role")
