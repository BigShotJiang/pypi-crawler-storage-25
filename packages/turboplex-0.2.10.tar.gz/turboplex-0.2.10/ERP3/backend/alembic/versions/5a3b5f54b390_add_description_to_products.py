"""add_description_to_products

Revision ID: 5a3b5f54b390
Revises: 93f2dc8feeee
Create Date: 2026-03-04 13:54:38.359879

"""
from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = '5a3b5f54b390'
down_revision: Union[str, Sequence[str], None] = '93f2dc8feeee'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.execute("ALTER TABLE productos ADD COLUMN IF NOT EXISTS descripcion TEXT")


def downgrade() -> None:
    """Downgrade schema."""
    op.execute("ALTER TABLE productos DROP COLUMN IF EXISTS descripcion")
