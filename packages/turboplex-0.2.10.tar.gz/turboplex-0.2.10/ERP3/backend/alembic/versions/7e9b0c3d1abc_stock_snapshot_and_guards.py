"""stock diario snapshot table, constraints and triggers

Revision ID: 7e9b0c3d1abc
Revises: 6f3a9c1c2d77, 75e9ce3b3a42
Create Date: 2026-03-23
"""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = "7e9b0c3d1abc"
down_revision: Union[str, None, Sequence[str]] = ("6f3a9c1c2d77", "75e9ce3b3a42")
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "stock_diario_snapshot",
        sa.Column("id", sa.dialects.postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("fecha", sa.Date(), nullable=False, index=True),
        sa.Column("empresa_id", sa.dialects.postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("producto_id", sa.dialects.postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("variant_id", sa.dialects.postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("bodega_id", sa.dialects.postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("cantidad", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("cantidad_reservada", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.UniqueConstraint(
            "fecha", "empresa_id", "producto_id", "variant_id", "bodega_id", name="uq_stock_diario_snapshot_key"
        ),
    )

    # CHECK: movimientos_stock.cantidad != 0
    op.create_check_constraint(
        "ck_movimientos_stock_cantidad_non_zero",
        "movimientos_stock",
        condition="cantidad <> 0",
    )

    # Trigger: anti-servicio en movimientos_stock
    op.execute(
        """
        CREATE OR REPLACE FUNCTION fn_guard_servicio_movimiento()
        RETURNS trigger AS $$
        DECLARE
            tipo TEXT;
        BEGIN
            SELECT tipo_producto INTO tipo FROM productos WHERE id = NEW.producto_id;
            IF upper(coalesce(tipo, '')) = 'SERVICIO' THEN
                RAISE EXCEPTION 'No se permiten movimientos de stock para productos de tipo SERVICIO';
            END IF;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        DROP TRIGGER IF EXISTS trg_guard_servicio_movimiento ON movimientos_stock;
        CREATE TRIGGER trg_guard_servicio_movimiento
        BEFORE INSERT ON movimientos_stock
        FOR EACH ROW
        EXECUTE FUNCTION fn_guard_servicio_movimiento();
        """
    )

    # Trigger: upsert incremental de stock_diario_snapshot
    op.execute(
        """
        CREATE OR REPLACE FUNCTION fn_update_stock_diario_snapshot()
        RETURNS trigger AS $$
        DECLARE
            d DATE := CAST(NEW.fecha AS DATE);
            v UUID;
        BEGIN
            -- Intentar resolver variant_id por la combinación producto+bodega actual en inventario
            -- Si no se encuentra, se deja null-safe y solo se actualiza por producto (fallback)
            SELECT i.variant_id INTO v
            FROM inventario i
            WHERE i.producto_id = NEW.producto_id AND i.bodega_id = NEW.bodega_id
            ORDER BY i.updated_at DESC NULLS LAST, i.id DESC
            LIMIT 1;

            INSERT INTO stock_diario_snapshot AS s (
                id, fecha, empresa_id, producto_id, variant_id, bodega_id, cantidad, cantidad_reservada, created_at
            )
            VALUES (
                gen_random_uuid(), d, NEW.empresa_id, NEW.producto_id, COALESCE(v, gen_random_uuid()), NEW.bodega_id,
                NEW.cantidad, 0, now()
            )
            ON CONFLICT (fecha, empresa_id, producto_id, variant_id, bodega_id)
            DO UPDATE SET
                cantidad = s.cantidad + EXCLUDED.cantidad;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        DROP TRIGGER IF EXISTS trg_update_stock_diario_snapshot ON movimientos_stock;
        CREATE TRIGGER trg_update_stock_diario_snapshot
        AFTER INSERT ON movimientos_stock
        FOR EACH ROW
        EXECUTE FUNCTION fn_update_stock_diario_snapshot();
        """
    )


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS trg_update_stock_diario_snapshot ON movimientos_stock;")
    op.execute("DROP FUNCTION IF EXISTS fn_update_stock_diario_snapshot();")
    op.execute("DROP TRIGGER IF EXISTS trg_guard_servicio_movimiento ON movimientos_stock;")
    op.execute("DROP FUNCTION IF EXISTS fn_guard_servicio_movimiento();")
    op.drop_constraint("ck_movimientos_stock_cantidad_non_zero", "movimientos_stock", type_="check")
    op.drop_table("stock_diario_snapshot")

