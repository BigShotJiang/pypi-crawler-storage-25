"""Create rut_provider_config table

Revision ID: 9a7f2b1c4e21
Revises: c8a1c7e2c9a1
Create Date: 2026-03-25
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

# revision identifiers, used by Alembic.
revision = '9a7f2b1c4e21'
down_revision = 'c8a1c7e2c9a1'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'rut_provider_config',
        sa.Column('empresa_id', sa.String(), primary_key=True),
        sa.Column('provider_type', sa.String(), nullable=False),
        sa.Column('auth_params', JSONB, nullable=False),
        sa.Column('ttl_days', sa.Integer(), nullable=False, server_default=sa.text('30')),
        sa.Column('updated_at', sa.DateTime(), nullable=True, server_default=sa.text('now()')),
    )
    op.create_index('ix_rut_provider_config_empresa_id', 'rut_provider_config', ['empresa_id'], unique=True)


def downgrade():
    op.drop_index('ix_rut_provider_config_empresa_id', table_name='rut_provider_config')
    op.drop_table('rut_provider_config')
