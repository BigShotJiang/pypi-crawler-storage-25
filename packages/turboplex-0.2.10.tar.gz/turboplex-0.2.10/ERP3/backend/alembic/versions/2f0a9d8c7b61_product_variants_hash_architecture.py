"""product_variants_hash_architecture

Revision ID: 2f0a9d8c7b61
Revises: 1f4c9a2b7d11
Create Date: 2026-03-22 00:00:00.000000

"""

from __future__ import annotations

import hashlib
import json
import uuid
from typing import Any, Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "2f0a9d8c7b61"
down_revision: Union[str, Sequence[str], None] = "1f4c9a2b7d11"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _canonical_json(obj: Any) -> str:
    if obj is None:
        return "{}"
    if not isinstance(obj, dict):
        return "{}"
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _md5_hex(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    op.execute(
        """
        CREATE TABLE IF NOT EXISTS product_variants (
            id uuid PRIMARY KEY,
            empresa_id uuid NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
            producto_id uuid NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
            hash_identity text NOT NULL,
            attributes jsonb NOT NULL DEFAULT '{}'::jsonb,
            sku_variant text NULL,
            created_at timestamptz NOT NULL DEFAULT now(),
            updated_at timestamptz NOT NULL DEFAULT now()
        )
        """
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS ix_product_variants_empresa_id ON product_variants (empresa_id)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS ix_product_variants_producto_id ON product_variants (producto_id)"
    )
    op.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_product_variants_producto_hash ON product_variants (producto_id, hash_identity)"
    )
    _enable_rls("product_variants")

    op.execute("ALTER TABLE inventario ADD COLUMN IF NOT EXISTS variant_id uuid")
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1
                FROM pg_constraint
                WHERE conname = 'fk_inventario_variant_id'
            ) THEN
                ALTER TABLE inventario
                ADD CONSTRAINT fk_inventario_variant_id
                FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE;
            END IF;
        END
        $$;
        """
    )
    op.execute("CREATE INDEX IF NOT EXISTS ix_inventario_variant_id ON inventario (variant_id)")

    product_variants_table = sa.table(
        "product_variants",
        sa.column("id", postgresql.UUID(as_uuid=True)),
        sa.column("empresa_id", postgresql.UUID(as_uuid=True)),
        sa.column("producto_id", postgresql.UUID(as_uuid=True)),
        sa.column("hash_identity", sa.Text()),
        sa.column("attributes", postgresql.JSONB()),
        sa.column("sku_variant", sa.Text()),
    )

    conn = bind
    rows = (
        conn.execute(
            sa.text(
                """
                SELECT inv.id as inventario_id, inv.producto_id, p.empresa_id, inv.additional_attributes
                FROM inventario inv
                JOIN productos p ON p.id = inv.producto_id
                """
            )
        )
        .mappings()
        .all()
    )

    variant_key_to_payload: dict[tuple[uuid.UUID, str], dict[str, Any]] = {}
    inventario_updates: list[dict[str, Any]] = []

    for r in rows:
        inventario_id = uuid.UUID(str(r["inventario_id"]))
        producto_id = uuid.UUID(str(r["producto_id"]))
        empresa_id = uuid.UUID(str(r["empresa_id"]))
        attrs = r.get("additional_attributes") or {}
        canonical = _canonical_json(attrs)
        hash_identity = _md5_hex(canonical)
        variant_uuid = uuid.uuid5(uuid.NAMESPACE_URL, f"{producto_id}:{hash_identity}")
        variant_key = (producto_id, hash_identity)
        if variant_key not in variant_key_to_payload:
            variant_key_to_payload[variant_key] = {
                "id": variant_uuid,
                "empresa_id": empresa_id,
                "producto_id": producto_id,
                "hash_identity": hash_identity,
                "attributes": attrs,
                "sku_variant": None,
            }
        inventario_updates.append(
            {"inventario_id": inventario_id, "variant_id": variant_uuid}
        )

    if variant_key_to_payload:
        insert_stmt = (
            postgresql.insert(product_variants_table)
            .values(list(variant_key_to_payload.values()))
            .on_conflict_do_nothing(index_elements=["producto_id", "hash_identity"])
        )
        conn.execute(insert_stmt)

    if inventario_updates:
        conn.execute(
            sa.text(
                """
                UPDATE inventario
                SET variant_id = :variant_id
                WHERE id = :inventario_id
                  AND variant_id IS NULL
                """
            ),
            inventario_updates,
        )

    op.execute(
        """
        WITH ranked AS (
            SELECT
                id,
                variant_id,
                bodega_id,
                row_number() OVER (PARTITION BY variant_id, bodega_id ORDER BY id ASC) AS rn,
                sum(cantidad) OVER (PARTITION BY variant_id, bodega_id) AS sum_cantidad,
                sum(cantidad_reservada) OVER (PARTITION BY variant_id, bodega_id) AS sum_reservada,
                min(stock_minimo) OVER (PARTITION BY variant_id, bodega_id) AS min_stock
            FROM inventario
            WHERE variant_id IS NOT NULL
        )
        UPDATE inventario i
        SET
            cantidad = r.sum_cantidad,
            cantidad_reservada = r.sum_reservada,
            stock_minimo = r.min_stock
        FROM ranked r
        WHERE i.id = r.id
          AND r.rn = 1
        """
    )
    op.execute(
        """
        WITH ranked AS (
            SELECT
                id,
                row_number() OVER (PARTITION BY variant_id, bodega_id ORDER BY id ASC) AS rn
            FROM inventario
            WHERE variant_id IS NOT NULL
        )
        DELETE FROM inventario i
        USING ranked r
        WHERE i.id = r.id
          AND r.rn > 1
        """
    )

    op.execute(
        """
        DELETE FROM inventario i
        WHERE i.variant_id IS NULL
          AND NOT EXISTS (
            SELECT 1
            FROM productos p
            WHERE p.id = i.producto_id
          )
        """
    )

    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM inventario WHERE variant_id IS NULL) THEN
                RAISE EXCEPTION 'Backfill incompleto: existen filas inventario.variant_id NULL';
            END IF;
        END
        $$;
        """
    )
    op.execute("ALTER TABLE inventario ALTER COLUMN variant_id SET NOT NULL")
    op.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_inventario_variant_bodega ON inventario (variant_id, bodega_id)"
    )


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    op.execute("DROP INDEX IF EXISTS uq_inventario_variant_bodega")
    op.execute("ALTER TABLE inventario ALTER COLUMN variant_id DROP NOT NULL")
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1
                FROM pg_constraint
                WHERE conname = 'fk_inventario_variant_id'
            ) THEN
                ALTER TABLE inventario DROP CONSTRAINT fk_inventario_variant_id;
            END IF;
        END
        $$;
        """
    )
    op.execute("DROP INDEX IF EXISTS ix_inventario_variant_id")
    op.execute("ALTER TABLE inventario DROP COLUMN IF EXISTS variant_id")

    op.execute("DROP INDEX IF EXISTS uq_product_variants_producto_hash")
    op.execute("DROP INDEX IF EXISTS ix_product_variants_producto_id")
    op.execute("DROP INDEX IF EXISTS ix_product_variants_empresa_id")
    op.execute('DROP TABLE IF EXISTS "product_variants"')
