"""full_core_hardening_rls_sales_stock_contacts

Revision ID: e3a7c2f1b9d4
Revises: d1e2f3a4b5c6
Create Date: 2026-03-21 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
from sqlalchemy import text

revision: str = "e3a7c2f1b9d4"
down_revision: Union[str, Sequence[str], None] = "d1e2f3a4b5c6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(table_name: str) -> bool:
    bind = op.get_bind()
    return (
        bind.execute(text("SELECT to_regclass(:tname) IS NOT NULL"), {"tname": f"public.{table_name}"})
        .scalar()
        is True
    )


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _disable_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(f'ALTER TABLE "{table_name}" NO FORCE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    table_names = [
        "ventas",
        "ventas_items",
        "detalles_venta",
        "stock_movimientos",
        "movimientos_stock",
        "clientes_contactos",
    ]
    for table_name in table_names:
        if _table_exists(table_name):
            _enable_rls(table_name)


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    table_names = [
        "clientes_contactos",
        "movimientos_stock",
        "stock_movimientos",
        "detalles_venta",
        "ventas_items",
        "ventas",
    ]
    for table_name in table_names:
        if _table_exists(table_name):
            _disable_rls(table_name)

