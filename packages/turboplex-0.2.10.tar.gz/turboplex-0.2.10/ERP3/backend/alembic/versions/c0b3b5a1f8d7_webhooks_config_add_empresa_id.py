"""webhooks_config_add_empresa_id

Revision ID: c0b3b5a1f8d7
Revises: 5a3b5f54b390
Create Date: 2026-03-17 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app


# revision identifiers, used by Alembic.
revision: str = "c0b3b5a1f8d7"
down_revision: Union[str, Sequence[str], None] = "5a3b5f54b390"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "webhooks_config",
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=True),
    )
    op.create_index(
        op.f("ix_webhooks_config_empresa_id"),
        "webhooks_config",
        ["empresa_id"],
        unique=False,
    )
    op.create_foreign_key(
        "fk_webhooks_config_empresa_id_empresas",
        "webhooks_config",
        "empresas",
        ["empresa_id"],
        ["id"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "fk_webhooks_config_empresa_id_empresas", "webhooks_config", type_="foreignkey"
    )
    op.drop_index(op.f("ix_webhooks_config_empresa_id"), table_name="webhooks_config")
    op.drop_column("webhooks_config", "empresa_id")
