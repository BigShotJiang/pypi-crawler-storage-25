"""add_billing_subscriptions

Revision ID: b7a1c2d3e4f5
Revises: 2245b025d55c
Create Date: 2026-03-02 10:15:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID as PG_UUID


class GUID(sa.types.TypeDecorator):
    impl = sa.CHAR
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(PG_UUID())
        return dialect.type_descriptor(sa.CHAR(36))


revision: str = "b7a1c2d3e4f5"
down_revision: Union[str, Sequence[str], None] = "2245b025d55c"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "subscription_plans",
        sa.Column("id", GUID(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column(
            "price_clp", sa.Integer(), server_default=sa.text("0"), nullable=False
        ),
        sa.Column(
            "user_limit", sa.Integer(), server_default=sa.text("1"), nullable=False
        ),
        sa.Column(
            "branch_limit", sa.Integer(), server_default=sa.text("1"), nullable=False
        ),
        sa.Column(
            "is_active", sa.Boolean(), server_default=sa.text("true"), nullable=True
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )
    op.create_index(
        op.f("ix_subscription_plans_id"),
        "subscription_plans",
        ["id"],
        unique=False,
    )
    op.create_table(
        "company_subscriptions",
        sa.Column("id", GUID(), nullable=False),
        sa.Column("empresa_id", GUID(), nullable=False),
        sa.Column("plan_id", GUID(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
        sa.ForeignKeyConstraint(["plan_id"], ["subscription_plans.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_company_subscriptions_id"),
        "company_subscriptions",
        ["id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_company_subscriptions_empresa_id"),
        "company_subscriptions",
        ["empresa_id"],
        unique=False,
    )
    op.create_table(
        "payment_receipts",
        sa.Column("id", GUID(), nullable=False),
        sa.Column("empresa_id", GUID(), nullable=False),
        sa.Column("plan_id", GUID(), nullable=False),
        sa.Column(
            "amount_clp", sa.Integer(), server_default=sa.text("0"), nullable=False
        ),
        sa.Column(
            "paid_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("new_expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
        sa.ForeignKeyConstraint(["plan_id"], ["subscription_plans.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_payment_receipts_id"),
        "payment_receipts",
        ["id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_payment_receipts_empresa_id"),
        "payment_receipts",
        ["empresa_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_payment_receipts_empresa_id"), table_name="payment_receipts")
    op.drop_index(op.f("ix_payment_receipts_id"), table_name="payment_receipts")
    op.drop_table("payment_receipts")
    op.drop_index(
        op.f("ix_company_subscriptions_empresa_id"),
        table_name="company_subscriptions",
    )
    op.drop_index(op.f("ix_company_subscriptions_id"), table_name="company_subscriptions")
    op.drop_table("company_subscriptions")
    op.drop_index(op.f("ix_subscription_plans_id"), table_name="subscription_plans")
    op.drop_table("subscription_plans")
