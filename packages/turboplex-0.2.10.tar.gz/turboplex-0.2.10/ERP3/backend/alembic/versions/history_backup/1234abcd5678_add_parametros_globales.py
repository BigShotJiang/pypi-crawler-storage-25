from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

import app.core.custom_types


# revision identifiers, used by Alembic.
revision: str = "1234abcd5678"
down_revision: Union[str, None] = "4a8143ec4b04"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "parametros_globales",
        sa.Column("id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=True),
        sa.Column("llave", sa.String(), nullable=False),
        sa.Column("valor", sa.String(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_parametros_globales_empresa_id"),
        "parametros_globales",
        ["empresa_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_parametros_globales_llave"),
        "parametros_globales",
        ["llave"],
        unique=False,
    )
    op.create_unique_constraint(
        "uq_parametros_globales_empresa_llave",
        "parametros_globales",
        ["empresa_id", "llave"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_parametros_globales_empresa_llave",
        "parametros_globales",
        type_="unique",
    )
    op.drop_index(
        op.f("ix_parametros_globales_llave"),
        table_name="parametros_globales",
    )
    op.drop_index(
        op.f("ix_parametros_globales_empresa_id"),
        table_name="parametros_globales",
    )
    op.drop_table("parametros_globales")

