"""configuracion_impuestos_and_line_taxes

Revision ID: 6f3a9c1c2d77
Revises: 0b7e2c1d9a4f
Create Date: 2026-03-23 00:00:00.000000
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "6f3a9c1c2d77"
down_revision: Union[str, Sequence[str], None] = "0b7e2c1d9a4f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _disable_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    # Tabla de configuración de impuestos por empresa (fuente de verdad)
    op.create_table(
        "configuracion_impuestos",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("empresa_id", postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("codigo", sa.String(length=30), nullable=False, index=True),
        sa.Column("nombre", sa.String(length=120), nullable=True),
        sa.Column("tasa", sa.Numeric(12, 4), nullable=False),
        sa.Column("vigente_desde", sa.Date(), nullable=True),
        sa.Column("vigente_hasta", sa.Date(), nullable=True),
        sa.Column("activo", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"], ondelete="CASCADE"),
    )
    op.create_index(
        "ix_config_impuestos_emp_cod_vig",
        "configuracion_impuestos",
        ["empresa_id", "codigo", "vigente_desde"],
        unique=False,
    )
    _enable_rls("configuracion_impuestos")

    # Columna snapshot en ventas
    op.add_column("ventas", sa.Column("iva_tasa_aplicada", sa.Numeric(12, 4), nullable=True))

    # Tabla impuestos por detalle de venta (múltiples impuestos por línea)
    op.create_table(
        "detalles_venta_impuestos",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("empresa_id", postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("detalle_venta_id", postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("impuesto_config_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("codigo_impuesto", sa.String(length=30), nullable=False),
        sa.Column("tasa_aplicada", sa.Numeric(12, 4), nullable=False),
        sa.Column("base_monto", sa.Numeric(14, 4), nullable=False, server_default=sa.text("0")),
        sa.Column("monto_impuesto", sa.Numeric(14, 4), nullable=False, server_default=sa.text("0")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["detalle_venta_id"], ["detalles_venta.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["impuesto_config_id"], ["configuracion_impuestos.id"], ondelete="SET NULL"),
    )
    _enable_rls("detalles_venta_impuestos")

    # Tabla impuestos por detalle de DTE
    op.create_table(
        "documentos_tributarios_detalle_impuestos",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("empresa_id", postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("dte_detalle_id", postgresql.UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("codigo_impuesto", sa.String(length=30), nullable=False),
        sa.Column("tasa_aplicada", sa.Numeric(12, 4), nullable=False),
        sa.Column("base_monto", sa.Numeric(14, 4), nullable=False, server_default=sa.text("0")),
        sa.Column("monto_impuesto", sa.Numeric(14, 4), nullable=False, server_default=sa.text("0")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(
            ["dte_detalle_id"], ["documentos_tributarios_detalles.id"], ondelete="CASCADE"
        ),
    )
    _enable_rls("documentos_tributarios_detalle_impuestos")

    # Backfill sencillo: crear IVA 19% activo por empresa si no existe
    _disable_rls("configuracion_impuestos")
    try:
        op.execute(
            """
            INSERT INTO configuracion_impuestos (id, empresa_id, codigo, nombre, tasa, vigente_desde, activo, created_at)
            SELECT gen_random_uuid(), e.id, 'IVA', 'Impuesto al Valor Agregado', 0.19, current_date, true, now()
            FROM empresas e
            WHERE NOT EXISTS (
                SELECT 1 FROM configuracion_impuestos ci
                WHERE ci.empresa_id = e.id AND ci.codigo = 'IVA' AND ci.activo = true
            )
            """
        )
    finally:
        _enable_rls("configuracion_impuestos")


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return
    _disable_rls("documentos_tributarios_detalle_impuestos")
    _disable_rls("detalles_venta_impuestos")
    _disable_rls("configuracion_impuestos")
    op.drop_table("documentos_tributarios_detalle_impuestos")
    op.drop_table("detalles_venta_impuestos")
    op.drop_index("ix_config_impuestos_emp_cod_vig", table_name="configuracion_impuestos")
    op.drop_table("configuracion_impuestos")
    op.drop_column("ventas", "iva_tasa_aplicada")
