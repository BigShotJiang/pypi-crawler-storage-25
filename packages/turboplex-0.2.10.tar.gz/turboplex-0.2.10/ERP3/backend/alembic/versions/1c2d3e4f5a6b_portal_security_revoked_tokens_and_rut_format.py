"""Portal security: must_change_password + revoked_tokens; normalize RUT formats

Revision ID: 1c2d3e4f5a6b
Revises: 17f1dc7bb512, 9a7f2b1c4e21, b1a2c3d4e5f6
Create Date: 2026-03-25
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "1c2d3e4f5a6b"
down_revision: Union[str, Sequence[str], None] = (
    "17f1dc7bb512",
    "9a7f2b1c4e21",
    "b1a2c3d4e5f6",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "portal_users",
        sa.Column(
            "must_change_password",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("true"),
        ),
    )
    op.execute(sa.text("UPDATE portal_users SET must_change_password = false"))

    op.create_table(
        "revoked_tokens",
        sa.Column("jti", sa.String(), primary_key=True),
        sa.Column("audience", sa.String(), nullable=False),
        sa.Column("subject", sa.String(), nullable=True),
        sa.Column("empresa_id", sa.String(), nullable=True),
        sa.Column("cliente_id", sa.String(), nullable=True),
        sa.Column(
            "revoked_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_revoked_tokens_expires_at", "revoked_tokens", ["expires_at"])

    op.execute(
        sa.text(
            """
            UPDATE clientes
            SET rut = (
                LEFT(UPPER(REGEXP_REPLACE(rut, '[^0-9kK]', '', 'g')), LENGTH(UPPER(REGEXP_REPLACE(rut, '[^0-9kK]', '', 'g'))) - 1)
                || '-'
                || RIGHT(UPPER(REGEXP_REPLACE(rut, '[^0-9kK]', '', 'g')), 1)
            )
            WHERE rut IS NOT NULL
              AND rut <> ''
              AND LENGTH(UPPER(REGEXP_REPLACE(rut, '[^0-9kK]', '', 'g'))) >= 2
            """
        )
    )

    op.execute(
        sa.text(
            """
            DELETE FROM rut_cache a
            USING rut_cache b
            WHERE a.rut_normalized NOT LIKE '%-%'
              AND b.rut_normalized = (
                LEFT(UPPER(REGEXP_REPLACE(a.rut_normalized, '[^0-9kK]', '', 'g')), LENGTH(UPPER(REGEXP_REPLACE(a.rut_normalized, '[^0-9kK]', '', 'g'))) - 1)
                || '-'
                || RIGHT(UPPER(REGEXP_REPLACE(a.rut_normalized, '[^0-9kK]', '', 'g')), 1)
              )
            """
        )
    )
    op.execute(
        sa.text(
            """
            UPDATE rut_cache
            SET rut_normalized = (
                LEFT(UPPER(REGEXP_REPLACE(rut_normalized, '[^0-9kK]', '', 'g')), LENGTH(UPPER(REGEXP_REPLACE(rut_normalized, '[^0-9kK]', '', 'g'))) - 1)
                || '-'
                || RIGHT(UPPER(REGEXP_REPLACE(rut_normalized, '[^0-9kK]', '', 'g')), 1)
            )
            WHERE rut_normalized IS NOT NULL
              AND rut_normalized <> ''
              AND LENGTH(UPPER(REGEXP_REPLACE(rut_normalized, '[^0-9kK]', '', 'g'))) >= 2
              AND rut_normalized NOT LIKE '%-%'
            """
        )
    )


def downgrade() -> None:
    op.drop_index("ix_revoked_tokens_expires_at", table_name="revoked_tokens")
    op.drop_table("revoked_tokens")
    op.drop_column("portal_users", "must_change_password")
