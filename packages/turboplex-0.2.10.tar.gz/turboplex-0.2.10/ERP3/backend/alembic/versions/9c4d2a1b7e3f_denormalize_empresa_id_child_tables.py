"""denormalize_empresa_id_child_tables

Revision ID: 9c4d2a1b7e3f
Revises: f2a8c4d91b3a
Create Date: 2026-03-20 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app

# revision identifiers, used by Alembic.
revision: str = "9c4d2a1b7e3f"
down_revision: Union[str, Sequence[str], None] = "f2a8c4d91b3a"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "detalles_venta",
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=True),
    )
    op.create_foreign_key(
        "fk_detalles_venta_empresa_id_empresas",
        "detalles_venta",
        "empresas",
        ["empresa_id"],
        ["id"],
    )
    op.execute(
        """
        UPDATE detalles_venta d
        SET empresa_id = v.empresa_id
        FROM ventas v
        WHERE d.venta_id = v.id AND d.empresa_id IS NULL
        """
    )
    op.alter_column("detalles_venta", "empresa_id", nullable=False)
    op.create_index(
        op.f("ix_detalles_venta_empresa_id"),
        "detalles_venta",
        ["empresa_id"],
        unique=False,
    )

    op.add_column(
        "movimientos_contables",
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=True),
    )
    op.create_foreign_key(
        "fk_movimientos_contables_empresa_id_empresas",
        "movimientos_contables",
        "empresas",
        ["empresa_id"],
        ["id"],
    )
    op.execute(
        """
        UPDATE movimientos_contables m
        SET empresa_id = a.empresa_id
        FROM asientos_contables a
        WHERE m.asiento_id = a.id AND m.empresa_id IS NULL
        """
    )
    op.alter_column("movimientos_contables", "empresa_id", nullable=False)
    op.create_index(
        op.f("ix_movimientos_contables_empresa_id"),
        "movimientos_contables",
        ["empresa_id"],
        unique=False,
    )

    op.add_column(
        "documentos_tributarios_detalles",
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=True),
    )
    op.create_foreign_key(
        "fk_documentos_tributarios_detalles_empresa_id_empresas",
        "documentos_tributarios_detalles",
        "empresas",
        ["empresa_id"],
        ["id"],
    )
    op.execute(
        """
        UPDATE documentos_tributarios_detalles d
        SET empresa_id = dt.empresa_id
        FROM documentos_tributarios dt
        WHERE d.dte_id = dt.id AND d.empresa_id IS NULL
        """
    )
    op.alter_column("documentos_tributarios_detalles", "empresa_id", nullable=False)
    op.create_index(
        op.f("ix_documentos_tributarios_detalles_empresa_id"),
        "documentos_tributarios_detalles",
        ["empresa_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        op.f("ix_documentos_tributarios_detalles_empresa_id"),
        table_name="documentos_tributarios_detalles",
    )
    op.drop_constraint(
        "fk_documentos_tributarios_detalles_empresa_id_empresas",
        "documentos_tributarios_detalles",
        type_="foreignkey",
    )
    op.drop_column("documentos_tributarios_detalles", "empresa_id")

    op.drop_index(
        op.f("ix_movimientos_contables_empresa_id"),
        table_name="movimientos_contables",
    )
    op.drop_constraint(
        "fk_movimientos_contables_empresa_id_empresas",
        "movimientos_contables",
        type_="foreignkey",
    )
    op.drop_column("movimientos_contables", "empresa_id")

    op.drop_index(op.f("ix_detalles_venta_empresa_id"), table_name="detalles_venta")
    op.drop_constraint(
        "fk_detalles_venta_empresa_id_empresas",
        "detalles_venta",
        type_="foreignkey",
    )
    op.drop_column("detalles_venta", "empresa_id")

