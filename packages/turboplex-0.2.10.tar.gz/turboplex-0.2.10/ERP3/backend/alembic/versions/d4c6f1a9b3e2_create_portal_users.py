"""create_portal_users

Revision ID: d4c6f1a9b3e2
Revises: c0b3b5a1f8d7
Create Date: 2026-03-17 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app


revision: str = "d4c6f1a9b3e2"
down_revision: Union[str, Sequence[str], None] = "c0b3b5a1f8d7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "portal_users",
        sa.Column("id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("cliente_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("email", sa.String(), nullable=False),
        sa.Column("hashed_password", sa.String(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=True,
            server_default=sa.text("now()"),
        ),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["cliente_id"], ["clientes.id"]),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("empresa_id", "email", name="uq_portal_users_empresa_email"),
    )
    op.create_index(op.f("ix_portal_users_cliente_id"), "portal_users", ["cliente_id"], unique=False)
    op.create_index(op.f("ix_portal_users_empresa_id"), "portal_users", ["empresa_id"], unique=False)
    op.create_index(op.f("ix_portal_users_email"), "portal_users", ["email"], unique=False)
    op.create_index(op.f("ix_portal_users_id"), "portal_users", ["id"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_portal_users_id"), table_name="portal_users")
    op.drop_index(op.f("ix_portal_users_email"), table_name="portal_users")
    op.drop_index(op.f("ix_portal_users_empresa_id"), table_name="portal_users")
    op.drop_index(op.f("ix_portal_users_cliente_id"), table_name="portal_users")
    op.drop_table("portal_users")
