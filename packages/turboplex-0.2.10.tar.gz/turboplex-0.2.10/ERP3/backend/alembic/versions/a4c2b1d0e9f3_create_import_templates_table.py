"""create_import_templates_table

Revision ID: a4c2b1d0e9f3
Revises: d7a3c1f2e8b9
Create Date: 2026-03-20 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
import app


revision: str = "a4c2b1d0e9f3"
down_revision: Union[str, Sequence[str], None] = "d7a3c1f2e8b9"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    import_template_type = postgresql.ENUM(
        "CATALOG",
        "STOCK_ADJUST",
        name="import_template_type",
        create_type=False,
    )
    import_template_type.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "import_templates",
        sa.Column("id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("nombre", sa.String(), nullable=False),
        sa.Column("tipo_importacion", import_template_type, nullable=False),
        sa.Column("mapping_json", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("empresa_id", "nombre", name="uq_import_templates_empresa_nombre"),
    )

    op.create_index(op.f("ix_import_templates_id"), "import_templates", ["id"], unique=False)
    op.create_index(op.f("ix_import_templates_empresa_id"), "import_templates", ["empresa_id"], unique=False)
    op.create_index(op.f("ix_import_templates_tipo_importacion"), "import_templates", ["tipo_importacion"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_import_templates_tipo_importacion"), table_name="import_templates")
    op.drop_index(op.f("ix_import_templates_empresa_id"), table_name="import_templates")
    op.drop_index(op.f("ix_import_templates_id"), table_name="import_templates")
    op.drop_table("import_templates")

    import_template_type = postgresql.ENUM(
        "CATALOG",
        "STOCK_ADJUST",
        name="import_template_type",
        create_type=False,
    )
    import_template_type.drop(op.get_bind(), checkfirst=True)

