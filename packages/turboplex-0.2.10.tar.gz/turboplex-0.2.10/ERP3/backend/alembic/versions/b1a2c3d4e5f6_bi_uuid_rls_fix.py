from typing import Sequence, Union
from alembic import op
from sqlalchemy import text

revision: str = "b1a2c3d4e5f6"
down_revision: Union[str, Sequence[str], None] = "e3a7c2f1b9d4"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _create_or_replace_view() -> None:
    op.execute(
        """
        CREATE OR REPLACE VIEW public.v_bi_transport_performance AS
        SELECT jo.empresa_id,
               jo.id AS job_order_id,
               so.id AS service_order_id,
               so.estado AS status,
               COALESCE(NULLIF(so.metadata ->> 'distancia_km', '')::numeric, 0::numeric) AS distancia_km,
               COALESCE(NULLIF(so.metadata ->> 'litros_combustible', '')::numeric, 0::numeric) AS litros_combustible,
               ac.id AS asiento_id,
               COALESCE(sum(mc.debe), 0::numeric) AS costo_real
        FROM service_orders so
        JOIN job_orders jo ON so.job_order_id = jo.id
        LEFT JOIN asientos_contables ac ON ac.origen_id = so.id::text AND ac.origen::text = 'SERVICE_ENGINE'::text
        LEFT JOIN movimientos_contables mc ON mc.asiento_id = ac.id
        WHERE
          (CURRENT_USER = ANY (ARRAY['postgres'::name, 'erp3_user'::name]))
          OR (
            CURRENT_USER::text LIKE 'bi_user_empresa_%'
            AND jo.empresa_id::text = REPLACE(CURRENT_USER::text, 'bi_user_empresa_', '')
          )
        GROUP BY jo.empresa_id, jo.id, so.id, ac.id, so.estado, so.metadata;
        """
    )


def _enable_rls_with_bi_user_exception(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
            OR (
                CURRENT_USER::text LIKE 'bi_user_empresa_%'
                AND empresa_id = REPLACE(CURRENT_USER::text, 'bi_user_empresa_', '')::uuid
            )
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
            OR (
                CURRENT_USER::text LIKE 'bi_user_empresa_%'
                AND empresa_id = REPLACE(CURRENT_USER::text, 'bi_user_empresa_', '')::uuid
            )
        )
        """
    )
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(getattr(bind, "dialect", None), "name", None) != "postgresql":
        return
    _create_or_replace_view()
    for table_name in [
        "ventas",
        "detalles_venta",
        "asientos_contables",
        "movimientos_contables",
        "documentos_tributarios",
        "documentos_tributarios_detalles",
        "ventas_items",
        "stock_movimientos",
        "movimientos_stock",
        "clientes_contactos",
    ]:
        exists = bind.execute(
            text("SELECT to_regclass(:tname) IS NOT NULL"),
            {"tname": f"public.{table_name}"},
        ).scalar()
        if exists:
            _enable_rls_with_bi_user_exception(table_name)


def _restore_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )
    op.execute(f'ALTER TABLE "{table_name}" NO FORCE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(getattr(bind, "dialect", None), "name", None) != "postgresql":
        return
    for table_name in [
        "clientes_contactos",
        "movimientos_stock",
        "stock_movimientos",
        "documentos_tributarios_detalles",
        "documentos_tributarios",
        "movimientos_contables",
        "asientos_contables",
        "detalles_venta",
        "ventas_items",
        "ventas",
    ]:
        exists = bind.execute(
            text("SELECT to_regclass(:tname) IS NOT NULL"),
            {"tname": f"public.{table_name}"},
        ).scalar()
        if exists:
            _restore_rls(table_name)
