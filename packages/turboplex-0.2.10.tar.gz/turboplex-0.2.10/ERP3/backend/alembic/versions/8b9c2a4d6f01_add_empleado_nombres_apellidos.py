"""add_empleado_nombres_apellidos

Revision ID: 8b9c2a4d6f01
Revises: 759d6d312265
Create Date: 2026-02-27 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "8b9c2a4d6f01"
down_revision: Union[str, Sequence[str], None] = "759d6d312265"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("empleados", sa.Column("nombres", sa.String(), nullable=True))
    op.add_column("empleados", sa.Column("apellidos", sa.String(), nullable=True))


def downgrade() -> None:
    op.drop_column("empleados", "apellidos")
    op.drop_column("empleados", "nombres")
