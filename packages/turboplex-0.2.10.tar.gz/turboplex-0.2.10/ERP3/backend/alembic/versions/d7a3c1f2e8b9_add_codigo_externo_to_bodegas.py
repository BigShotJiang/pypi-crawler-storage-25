"""add_codigo_externo_to_bodegas

Revision ID: d7a3c1f2e8b9
Revises: c3d44c9d0f12
Create Date: 2026-03-19 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "d7a3c1f2e8b9"
down_revision: Union[str, Sequence[str], None] = "c3d44c9d0f12"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("bodegas", sa.Column("codigo_externo", sa.String(), nullable=True))
    op.create_index(
        "ix_bodegas_codigo_externo",
        "bodegas",
        ["codigo_externo"],
        unique=False,
    )
    op.create_index(
        "ix_bodegas_sucursal_id_codigo_externo",
        "bodegas",
        ["sucursal_id", "codigo_externo"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_bodegas_sucursal_id_codigo_externo", table_name="bodegas")
    op.drop_index("ix_bodegas_codigo_externo", table_name="bodegas")
    op.drop_column("bodegas", "codigo_externo")

