"""enable_rls_addon_tables

Revision ID: c2a5d0f9b1aa
Revises: f81134d0d5ad
Create Date: 2026-03-20 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op


revision: str = "c2a5d0f9b1aa"
down_revision: Union[str, Sequence[str], None] = "f81134d0d5ad"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _disable_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    for table_name in [
        "cierres_caja",
        "portal_users",
        "portal_payment_notifications",
    ]:
        _enable_rls(table_name)


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    for table_name in [
        "portal_payment_notifications",
        "portal_users",
        "cierres_caja",
    ]:
        _disable_rls(table_name)

