"""camaleonic_attributes_jsonb_dictionary

Revision ID: 1f4c9a2b7d11
Revises: e3a7c2f1b9d4
Create Date: 2026-03-22 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
import uuid


class GUID(sa.types.TypeDecorator):
    impl = sa.CHAR
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(PG_UUID())
        return dialect.type_descriptor(sa.CHAR(36))

    def process_bind_param(self, value, dialect):
        if value is None:
            return value
        if dialect.name == "postgresql":
            return str(value)
        if not isinstance(value, uuid.UUID):
            return str(uuid.UUID(str(value)))
        return str(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return value
        if not isinstance(value, uuid.UUID):
            try:
                value = uuid.UUID(str(value))
            except (ValueError, TypeError, AttributeError):
                pass
        return value


revision: str = "1f4c9a2b7d11"
down_revision: Union[str, Sequence[str], None] = "e3a7c2f1b9d4"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _enable_rls(table_name: str) -> None:
    op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(
        f"""
        CREATE POLICY tenant_isolation_policy ON "{table_name}"
        USING (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        WITH CHECK (
            current_setting('app.allow_no_tenant', true) = '1'
            OR empresa_id = nullif(current_setting('app.current_empresa_id', true), '')::uuid
        )
        """
    )


def _disable_rls(table_name: str) -> None:
    op.execute(f'DROP POLICY IF EXISTS tenant_isolation_policy ON "{table_name}"')
    op.execute(f'ALTER TABLE "{table_name}" NO FORCE ROW LEVEL SECURITY')
    op.execute(f'ALTER TABLE "{table_name}" DISABLE ROW LEVEL SECURITY')


def upgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    jsonb_default = sa.text("'{}'::jsonb")

    op.add_column(
        "inventario",
        sa.Column(
            "additional_attributes",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default=jsonb_default,
        ),
    )
    op.add_column(
        "movimientos_stock",
        sa.Column(
            "additional_attributes",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default=jsonb_default,
        ),
    )
    op.add_column(
        "inventario_lotes",
        sa.Column(
            "additional_attributes",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default=jsonb_default,
        ),
    )

    op.create_table(
        "empresa_config_atributos",
        sa.Column("id", GUID(), nullable=False),
        sa.Column("empresa_id", GUID(), sa.ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False),
        sa.Column("entidad", sa.String(length=50), nullable=False),
        sa.Column("nombre_atributo", sa.String(length=120), nullable=False),
        sa.Column("label_visible", sa.String(length=160), nullable=False),
        sa.Column("activo", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "empresa_id",
            "entidad",
            "nombre_atributo",
            name="uq_empresa_config_atributos_empresa_entidad_nombre",
        ),
    )
    op.create_index(
        "ix_empresa_config_atributos_empresa_id",
        "empresa_config_atributos",
        ["empresa_id"],
        unique=False,
    )
    op.create_index(
        "ix_empresa_config_atributos_empresa_entidad",
        "empresa_config_atributos",
        ["empresa_id", "entidad"],
        unique=False,
    )

    _enable_rls("empresa_config_atributos")

    op.alter_column("inventario", "additional_attributes", server_default=None)
    op.alter_column("movimientos_stock", "additional_attributes", server_default=None)
    op.alter_column("inventario_lotes", "additional_attributes", server_default=None)


def downgrade() -> None:
    bind = op.get_bind()
    if getattr(bind, "dialect", None) is None or bind.dialect.name != "postgresql":
        return

    _disable_rls("empresa_config_atributos")
    op.drop_index("ix_empresa_config_atributos_empresa_entidad", table_name="empresa_config_atributos")
    op.drop_index("ix_empresa_config_atributos_empresa_id", table_name="empresa_config_atributos")
    op.drop_table("empresa_config_atributos")

    op.drop_column("inventario_lotes", "additional_attributes")
    op.drop_column("movimientos_stock", "additional_attributes")
    op.drop_column("inventario", "additional_attributes")
