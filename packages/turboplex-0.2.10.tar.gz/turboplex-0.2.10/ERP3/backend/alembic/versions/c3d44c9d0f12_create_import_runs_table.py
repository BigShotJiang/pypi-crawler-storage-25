"""create_import_runs_table

Revision ID: c3d44c9d0f12
Revises: f2a8c4d91b3a
Create Date: 2026-03-19 13:05:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
import app


revision: str = "c3d44c9d0f12"
down_revision: Union[str, Sequence[str], None] = "f2a8c4d91b3a"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    import_run_status = postgresql.ENUM(
        "STARTED",
        "COMPLETED",
        "FAILED",
        name="import_run_status",
        create_type=False,
    )
    import_run_status.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "import_runs",
        sa.Column("id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("empresa_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("bodega_id", app.core.custom_types.GUID(), nullable=False),
        sa.Column("filename", sa.String(), nullable=True),
        sa.Column("file_hash", sa.String(), nullable=False),
        sa.Column("status", import_run_status, nullable=False, server_default=sa.text("'STARTED'")),
        sa.Column("summary", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["empresa_id"], ["empresas.id"]),
        sa.ForeignKeyConstraint(["bodega_id"], ["bodegas.id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_index(op.f("ix_import_runs_id"), "import_runs", ["id"], unique=False)
    op.create_index(op.f("ix_import_runs_empresa_id"), "import_runs", ["empresa_id"], unique=False)
    op.create_index(op.f("ix_import_runs_bodega_id"), "import_runs", ["bodega_id"], unique=False)
    op.create_index(op.f("ix_import_runs_file_hash"), "import_runs", ["file_hash"], unique=False)
    op.create_index(op.f("ix_import_runs_status"), "import_runs", ["status"], unique=False)

    op.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_import_runs_empresa_filehash_completed "
        "ON import_runs (empresa_id, file_hash) "
        "WHERE status = 'COMPLETED'"
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ux_import_runs_empresa_filehash_completed")
    op.drop_index(op.f("ix_import_runs_status"), table_name="import_runs")
    op.drop_index(op.f("ix_import_runs_file_hash"), table_name="import_runs")
    op.drop_index(op.f("ix_import_runs_bodega_id"), table_name="import_runs")
    op.drop_index(op.f("ix_import_runs_empresa_id"), table_name="import_runs")
    op.drop_index(op.f("ix_import_runs_id"), table_name="import_runs")
    op.drop_table("import_runs")

    import_run_status = postgresql.ENUM(
        "STARTED",
        "COMPLETED",
        "FAILED",
        name="import_run_status",
        create_type=False,
    )
    import_run_status.drop(op.get_bind(), checkfirst=True)
