# Guía de Migraciones Alembic (ERP3)

## Prerrequisitos
- Python instalado (se recomienda usar el venv local si existe).
- Acceso a la base de datos con privilegios suficientes para crear/alterar objetos y, en Postgres, CREATE en el schema de versiones.
- Variables de entorno:
  - `MIGRATIONS_DATABASE_URL`: URL de conexión para migraciones (si no se define, se usa `settings.DATABASE_URL`).
  - `MIGRATIONS_SCHEMA`: schema donde se guarda la tabla de versiones (por defecto `erp3_migrations`).

## Selección de Base y Schema
- `backend/alembic/env.py` fuerza la URL con `MIGRATIONS_DATABASE_URL` o `settings.DATABASE_URL`.
- En Postgres, el script:
  - Detecta un schema con privilegio CREATE (vía `SHOW search_path` y verificación de permisos).
  - Si no encuentra, intenta crear `erp3_migrations` (o el indicado por `MIGRATIONS_SCHEMA`) y lo usa para la tabla `alembic_version`.
  - Ajusta `search_path` a `public,<schema_de_versiones>`.

## Comandos Básicos
En PowerShell (Windows):

Usando venv local del backend si existe:
```powershell
Set-Location c:\GitHub\ERP3\backend
.\.venv\Scripts\python.exe -m alembic -c alembic.ini revision -m "mensaje de cambio"
.\.venv\Scripts\python.exe -m alembic -c alembic.ini upgrade head
```

Usando el launcher `py` (con versión opcional):
```powershell
Set-Location c:\GitHub\ERP3\backend
$env:MIGRATIONS_DATABASE_URL = "postgresql+psycopg2://user:pass@host/db"
$env:MIGRATIONS_SCHEMA = "erp3_migrations"
py -3.11 -m alembic -c alembic.ini revision -m "mensaje de cambio"
py -3.11 -m alembic -c alembic.ini upgrade head
```

Fallback con `python` del PATH:
```powershell
Set-Location c:\GitHub\ERP3\backend
python -m alembic -c alembic.ini revision -m "mensaje de cambio"
python -m alembic -c alembic.ini upgrade head
```

## Flujo de Trabajo
1. Crear la revisión:
   - Ejecuta `alembic revision -m "mensaje"`.
   - Se creará un archivo en `backend/alembic/versions/` con `upgrade()` y `downgrade()`.
2. Editar la revisión:
   - Implementa cambios de esquema dentro de `upgrade()` y su reversa en `downgrade()`.
   - Para vistas, usa siempre `CREATE OR REPLACE VIEW`.
3. Ejecutar migraciones:
   - `alembic upgrade headcd` para aplicar todo lo pendiente.
   - `alembic downgrade -1` para revertir la última.
   - `alembic stamp head` si necesitas marcar el estado sin ejecutar cambios (con precaución).

## Pautas del Proyecto
- UUIDv7:
  - Claves primarias deben usar `uuid6.uuid7` (ver modelos y tipos GUID).
- RLS (Row Level Security):
  - Las políticas deben contemplar el aislamiento por `empresa_id` y excepciones aprobadas.
  - Ejemplo de excepción BI: permitir acceso a roles `bi_user_empresa_{uuid}` comparando `CURRENT_USER` y `empresa_id`.
- Vistas BI:
  - Filtrado por usuario:
    - `WHERE empresa_id = REPLACE(CURRENT_USER::text, 'bi_user_empresa_', '')::uuid`
    - Protege con `CURRENT_USER LIKE 'bi_user_empresa_%'` para evitar casts inválidos.
- Auditoría:
  - Si `DISABLE_AUDIT_DB=1`, la auditoría se rutea al Writer (Master) y no a DB espejo.
- Réplica para BI:
  - El servicio BI respeta `BI_USE_REPLICA=1` para devolver host/port de la réplica sin cambiar lógica del frontend.

## Verificación
- Confirma la tabla de versiones:
  - `SELECT * FROM erp3_migrations.alembic_version;` (o el schema definido en `MIGRATIONS_SCHEMA`).
- Revisa logs de Alembic (configurados en `alembic.ini`) y del app al iniciar.
- Si existe monitoreo en la app, los endpoints de métricas deben reflejar `PENDING`/`APPLIED` según las versiones.

## Problemas Comunes
- Permisos insuficientes:
  - Error por falta de CREATE en schema: definir `MIGRATIONS_DATABASE_URL` con un usuario con permisos, o otorgarlos en el schema elegido.
  - Si no existe `public`, el script ajusta `search_path` con el schema de versiones.
- Conflictos de RLS:
  - Asegura que las políticas nuevas no bloqueen operaciones de migración (usar `USING`/`WITH CHECK` correctos).
- Vistas dependientes:
  - Al cambiar tablas base, actualizar las vistas con `CREATE OR REPLACE VIEW` en la misma revisión.

## Ejemplo Completo
```powershell
Set-Location c:\GitHub\ERP3\backend
$env:MIGRATIONS_DATABASE_URL = "postgresql+psycopg2://erp3_admin:***@127.0.0.1/erp3_db"
$env:MIGRATIONS_SCHEMA = "erp3_migrations"
py -m alembic -c alembic.ini revision -m "bi: filtro por CURRENT_USER bi_user_empresa UUID"
# Edita el archivo en backend/alembic/versions/<rev>_bi_uuid_fix.py
py -m alembic -c alembic.ini upgrade head
```
