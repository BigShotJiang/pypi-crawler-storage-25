# Changelog

## [2026-02-23] - UUID-Native ERP Core

### Changed
- Migrated remaining service signatures and background jobs to use UUID/UUIDv7 identifiers:
  - `app/api/deps.py` operational context (`verify_operational_context`) now receives `UUID` for `sucursal_id` y `bodega_id`.
  - Facturación VIS services (`VISValidationService`) now operan exclusivamente con `venta_id: UUID`.
  - Finanzas Intercompany (`process_intercompany_transaction`) usa `venta_id: UUID` y `user_id: UUID` alineado con `Venta` y `Usuario`.
  - Background jobs y tareas (`trigger_report_generation`, `generar_reporte_mensual_pdf`) reciben `usuario_id: UUID`.
- Webhooks Admin API alineado con modelos UUID:
  - Endpoints de configuración ahora exponen `WebhookConfigOut` (Pydantic) con `id: UUID` y timestamps.
  - Esquema `webhooks/schemas.py` agregado para desacoplar ORM de la capa HTTP.
- Stress scripts actualizados a flujo UUID-native:
  - `scripts/stress_test_compras.py` usa `UUID` para `OrdenCompra.id` y `Proveedor.id`, manteniendo compatibilidad con RBAC ADM/SUP/BACKOFFICE/AUD.

### Verified
- Full `pytest` suite ejecutada sobre esquema consolidado UUID+Decimal: todos los tests en verde.
- Tests de integración claves:
  - `tests/test_core_integration.py` (Plan $0: caja, stock, ventas, cierre de caja) en verde con IDs UUID.
  - `tests/test_intercompany.py` validando espejo de ventas/OC Intercompany con IDs UUID.
- Barrido de firmas residuales `*_id: int` en código de aplicación:
  - No quedan `empresa_id`, `sucursal_id`, `bodega_id`, `venta_id`, `usuario_id` tipados como `int` en servicios, APIs ni background jobs de producción.

### Status
- ERP backend ya opera 100% UUID-Native en:
  - Modelos SQLAlchemy (`GUID` + `uuid6.uuid7` como PK).
  - Esquemas Pydantic y endpoints FastAPI.
  - Servicios de dominio, RBAC, métricas, cache e integración Intercompany.

## [2026-02-13] - SaaS Security Hardening

### Added
- **Test**: `tests/test_saas_security.py` validates cross-tenant isolation (Data Leakage Prevention).
  - Confirms User from Company B cannot access/modify resources of Company A.
  - Verifies Audit Logs for `UNAUTHORIZED_ACCESS_ATTEMPT` and `UNAUTHORIZED_SIGNATURE_ATTEMPT`.
- **Test**: `tests/test_aumentar_cupo_temporal.py` extended role bootstrap to include `BACKOFFICE` and `AUD` as operational/read-only roles without credit privileges, keeping credit authorization restricted to `ADM` and `SUP`.

### Security
- **CRM Module**: Enforced strict tenant isolation in `api.py`.
  - Protected Endpoints: `read_opportunity`, `create_opportunity`, `convert_opportunity`, `prepare_signature`, `confirm_print`, `upload_signed_document`, `void_document`.
  - Added `SecurityAudit.log` with HIGH/CRITICAL severity for unauthorized cross-tenant attempts.
  - Implemented "Security by Obscurity" (Returning 404 instead of 403 to avoid leaking resource existence).
 - **RBAC Skills**: Added `.trae/skills/erp-security-rbac` and `.trae/skills/erp-multi-tenant-safety` to encode RBAC and multi-tenant isolation rules, including explicit classification of `BACKOFFICE` and `AUD` as operational/read-only roles without credit authorization.

## [2026-02-06] - Schema Synchronization & Mining Scenario

### Added
- **Script**: `.one-off-scripts/test_mining_scenario.py` created to validate:
  - Mining company workflow (JobOrder + 2 ServiceOrders).
  - 'Transporte' template dynamic loading.
  - `EVENT_SERVICE_UPDATE` emission on 'COMPLETED' status.
  - Automatic `AsientoContable` generation (Cost of Sales vs Inventory).
- **Database**:
  - `recetas` and `insumos_receta` tables added via Alembic revision `3199e59a11fb`.
  - `estadoordenservicio` ENUM type explicitly handled in migration.
  - `CuentaContable` (1.1.03.01, 5.1.01) required for Service Engine accounting integration.

### Fixed
- **Service Engine**:
  - `finanzas.listeners.py`: Fixed payload status key mismatch (`status` vs `new_status`) to ensure accounting triggers.
  - `services.py`: Fixed unique constraint violation for ServiceWorkflow naming by appending `company_id`.
- **Tests**:
  - `test_mining_scenario.py`: Resolved duplicate account creation and listener connectivity.

### Verified
- **Mining Scenario**:
  - Successfully generated Asiento Contable #1 for Service Order #7.
  - Validated Cost calculation: 50,000,000 (50L Diesel * 1000 units * 1000 CLP/L).
