from fastapi import Request, Response
from typing import Callable, List
from jose import jwt, JWTError
import re
from app.core.config import settings
from app.core.database import SessionLocal
from app.core_modules.sistema.models import Usuario, AuditLog, AuditSeverity

SENSITIVE_PATTERNS: List[re.Pattern] = [
    re.compile(r"^/api/v1/ventas/clientes($|/.*)"),
    re.compile(r"^/api/v1/ventas($|/.*)"),
    re.compile(r"^/api/v1/crm($|/.*)"),
]


def _path_is_sensitive(path: str) -> bool:
    for p in SENSITIVE_PATTERNS:
        if p.match(path):
            return True
    return False


async def privacy_middleware(request: Request, call_next: Callable) -> Response:
    path = request.url.path
    if not _path_is_sensitive(path):
        return await call_next(request)

    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return await call_next(request)
    token = auth.replace("Bearer ", "", 1).strip()

    user_id = None
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        user_id = payload.get("sub")
    except JWTError:
        return await call_next(request)

    if not user_id:
        return await call_next(request)

    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        user = db.query(Usuario).filter(Usuario.id == user_id).first()
        if not user:
            return await call_next(request)

        if user.role == "SUPERADMIN":
            support_mode = (
                request.headers.get("X-Support-Mode", "false").lower() == "true"
            )
            if not support_mode:
                from fastapi.responses import JSONResponse

                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": "Acceso restringido por Privacidad: habilite Modo de Soporte con auditoría (X-Support-Mode: true)"
                    },
                )
            cmp = request.query_params.get("cmp", None)
            audit = AuditLog(
                actor_id=user.id,
                action="SUPPORT_MODE_ACCESS",
                resource=f"Empresa:{cmp or 'desconocida'}",
                severity=AuditSeverity.WARNING,
                changes={"path": path},
            )
            db.add(audit)
            db.commit()
    finally:
        db.close()

    return await call_next(request)
