from sqlalchemy.orm import declared_attr, Mapped, mapped_column
from uuid import UUID


class TenantAware:
    @declared_attr
    def empresa_id(cls) -> Mapped[UUID]:
        return mapped_column()


def get_tenant_search_path(empresa_slug: str, is_premium: bool = False) -> str:
    if is_premium:
        return f'"CRM-{empresa_slug}", "ERP-{empresa_slug}", public'
    return "public"
