from typing import List, Set, Optional
from fastapi import Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from app.api.deps import get_current_user, get_current_active_company, get_db
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    UsuarioEmpresa,
    Rol,
    AuditLog,
    AuditSeverity,
)
from .scopes import get_scopes_for_role


def resolve_user_role_code(db: Session, user_id, empresa_id) -> Optional[str]:
    assoc = (
        db.query(UsuarioEmpresa, Rol)
        .join(Rol, UsuarioEmpresa.rol_id == Rol.id)
        .filter(UsuarioEmpresa.usuario_id == user_id, UsuarioEmpresa.empresa_id == empresa_id)
        .first()
    )
    if assoc:
        return assoc[1].codigo
    return None


def get_user_scopes(db: Session, user_id, empresa_id) -> Set[str]:
    code = resolve_user_role_code(db, user_id, empresa_id)
    if not code:
        return set()
    return get_scopes_for_role(code)


def _register_rbac_audit_entry(
    db: Session,
    request: Request,
    user: Usuario,
    company: Empresa,
    action: str,
    required_roles: Optional[List[str]],
    required_scopes: Optional[List[str]],
    user_role_code: str,
    user_scopes: Set[str],
) -> None:
    try:
        log = AuditLog(
            actor_id=getattr(user, "id", None),
            action=action,
            resource=f"{request.method} {request.url.path}",
            severity=AuditSeverity.CRITICAL,
            changes={
                "empresa_id": str(getattr(company, "id", "")),
                "required_roles": required_roles or [],
                "required_scopes": required_scopes or [],
                "user_role": user_role_code,
                "user_scopes": sorted(list(user_scopes)),
            },
            ip_address=request.client.host if request and request.client else None,
        )
        db.add(log)
        db.commit()
    except Exception:
        db.rollback()


class ScopesChecker:
    def __init__(self, required_scopes: List[str], mode: str = "all"):
        self.required_scopes = required_scopes
        self.mode = mode

    def __call__(
        self,
        current_user: Usuario = Depends(get_current_user),
        current_company: Empresa = Depends(get_current_active_company),
        db: Session = Depends(get_db),
        request: Request = None,
    ):
        user_scopes = get_user_scopes(db, current_user.id, current_company.id)
        role_code = resolve_user_role_code(db, current_user.id, current_company.id) or ""
        if self.mode == "any":
            ok = any(s in user_scopes for s in self.required_scopes)
        else:
            ok = all(s in user_scopes for s in self.required_scopes)
        if not ok and not user_scopes and not role_code:
            legacy_role = getattr(current_user, "role", "")
            if legacy_role in ("ADMIN", "SUPERADMIN", "DEVELOPER"):
                return current_user
        if not ok:
            if request is not None:
                _register_rbac_audit_entry(
                    db=db,
                    request=request,
                    user=current_user,
                    company=current_company,
                    action="RBAC_SCOPE_DENIED",
                    required_roles=None,
                    required_scopes=self.required_scopes,
                    user_role_code=role_code,
                    user_scopes=user_scopes,
                )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Operación no permitida por scopes",
            )
        return current_user


class CombinedGuard:
    def __init__(self, roles: Optional[List[str]] = None, scopes: Optional[List[str]] = None, mode: str = "any"):
        self.roles = roles or []
        self.scopes = scopes or []
        self.mode = mode

    def __call__(
        self,
        current_user: Usuario = Depends(get_current_user),
        current_company: Empresa = Depends(get_current_active_company),
        db: Session = Depends(get_db),
        request: Request = None,
    ):
        role_code = resolve_user_role_code(db, current_user.id, current_company.id) or ""
        scopes = get_user_scopes(db, current_user.id, current_company.id)
        role_ok = role_code in self.roles if self.roles else False
        if self.scopes:
            scopes_ok = any(s in scopes for s in self.scopes)
        else:
            scopes_ok = False
        if self.roles and self.scopes and self.mode == "all":
            allowed = role_ok and scopes_ok
        elif self.roles and self.scopes and self.mode == "any":
            allowed = role_ok or scopes_ok
        elif self.roles and not self.scopes:
            allowed = role_ok
        elif self.scopes and not self.roles:
            allowed = scopes_ok
        else:
            allowed = False
        if not allowed and not role_code and not scopes:
            legacy_role = getattr(current_user, "role", "")
            if legacy_role in ("ADMIN", "SUPERADMIN", "DEVELOPER"):
                return current_user
        if not allowed:
            if request is not None:
                _register_rbac_audit_entry(
                    db=db,
                    request=request,
                    user=current_user,
                    company=current_company,
                    action="RBAC_ROLE_SCOPE_DENIED",
                    required_roles=self.roles,
                    required_scopes=self.scopes,
                    user_role_code=role_code,
                    user_scopes=scopes,
                )
            else:
                try:
                    log = AuditLog(
                        actor_id=getattr(current_user, "id", None),
                        action="RBAC_ROLE_SCOPE_DENIED",
                        resource="RBAC_CHECK",
                        severity=AuditSeverity.WARNING,
                        changes={
                            "empresa_id": str(getattr(current_company, "id", "")),
                            "required_roles": self.roles,
                            "required_scopes": self.scopes,
                            "user_role": role_code,
                            "user_scopes": sorted(list(scopes)),
                        },
                        ip_address=None,
                    )
                    db.add(log)
                    db.commit()
                except Exception:
                    db.rollback()
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Acceso denegado por política RBAC",
            )
        return current_user
