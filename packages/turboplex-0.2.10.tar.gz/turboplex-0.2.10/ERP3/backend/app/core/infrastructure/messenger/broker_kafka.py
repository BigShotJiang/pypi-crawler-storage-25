import logging
import os
from typing import Any, Callable, Optional

from app.core.infrastructure.serializer import safe_json_dumps


def enqueue(
    func: Callable[..., Any],
    *args: Any,
    delay_seconds: int | None = None,
    job_id: str | None = None,
    **kwargs: Any,
) -> str | None:
    return None


logger = logging.getLogger(__name__)


class KafkaBroker:
    def __init__(self, bootstrap_servers: Optional[str] = None) -> None:
        self._bootstrap_servers = (
            bootstrap_servers
            or os.getenv("KAFKA_URL")
            or os.getenv("KAFKA_BOOTSTRAP_SERVERS")
        )
        self._producer: Any = None

    def publish(self, topic: str, payload: Any) -> bool:
        if not self._bootstrap_servers:
            logger.info(
                "KafkaBroker(Mock) publish topic=%s payload=%s",
                topic,
                payload,
            )
            return False

        encoded = self._encode(payload)

        producer = self._get_producer()
        if producer is None:
            logger.info(
                "KafkaBroker(Mock) publish topic=%s servers=%s payload=%s",
                topic,
                self._bootstrap_servers,
                payload,
            )
            return False

        try:
            if hasattr(producer, "produce"):
                producer.produce(topic, value=encoded)
                if hasattr(producer, "poll"):
                    producer.poll(0)
            else:
                producer.send(topic, value=encoded)
                if hasattr(producer, "flush"):
                    producer.flush(timeout=0.2)
            return True
        except Exception as exc:
            logger.warning(
                "Kafka publish falló (modo mock activado) topic=%s error=%s",
                topic,
                exc,
            )
            logger.info(
                "KafkaBroker(Mock) publish topic=%s servers=%s payload=%s",
                topic,
                self._bootstrap_servers,
                payload,
            )
            return False

    def _encode(self, payload: Any) -> bytes:
        try:
            if hasattr(payload, "model_dump"):
                payload = payload.model_dump(mode="json")
        except Exception:
            pass
        try:
            return safe_json_dumps(payload).encode("utf-8")
        except Exception:
            return str(payload).encode("utf-8")

    def _get_producer(self) -> Any:
        if self._producer is not None:
            return self._producer
        try:
            from confluent_kafka import Producer

            self._producer = Producer({"bootstrap.servers": self._bootstrap_servers})
            return self._producer
        except Exception:
            pass
        try:
            from kafka import KafkaProducer

            self._producer = KafkaProducer(bootstrap_servers=self._bootstrap_servers)
            return self._producer
        except Exception as exc:
            logger.warning(
                "Kafka no disponible (sin librería o configuración). Usando Mock. %s",
                exc,
            )
            self._producer = None
            return None


kafka_broker = KafkaBroker()
