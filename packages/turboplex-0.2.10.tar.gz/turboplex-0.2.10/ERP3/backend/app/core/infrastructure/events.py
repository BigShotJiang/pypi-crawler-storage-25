import asyncio
import logging
from typing import Any, Awaitable, Callable, Dict, List


logger = logging.getLogger(__name__)


class EventDispatcher:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[Any], Awaitable[None]]]] = {}
        self._global_subscribers: List[Callable[[str, Any], Awaitable[None]]] = []

    def subscribe(self, event_type: str, callback: Callable[[Any], Awaitable[None]]):
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)
        logger.info(f"Subscribed to event: {event_type}")

    def subscribe_all(self, callback: Callable[[str, Any], Awaitable[None]]):
        self._global_subscribers.append(callback)
        logger.info("Subscribed to ALL events")

    async def dispatch(self, event_type: str, data: Any):
        tasks = []

        for global_cb in self._global_subscribers:
            tasks.append(self._safe_execute_global(global_cb, event_type, data))

        if event_type in self._subscribers:
            for cb in self._subscribers[event_type]:
                tasks.append(self._safe_execute(cb, data))

        if not tasks:
            logger.debug(f"No subscribers for event: {event_type}")
            return

        logger.info(f"Dispatching event: {event_type} with data: {data}")
        await asyncio.gather(*tasks)

    async def _safe_execute(self, callback: Callable[[Any], Awaitable[None]], data: Any):
        try:
            await callback(data)
        except Exception as e:
            logger.error(f"Error processing event inside listener: {e}", exc_info=True)

    async def _safe_execute_global(
        self,
        callback: Callable[[str, Any], Awaitable[None]],
        event_type: str,
        data: Any,
    ):
        try:
            await callback(event_type, data)
        except Exception as e:
            logger.error(
                f"Error processing global event inside listener: {e}", exc_info=True
            )


event_dispatcher = EventDispatcher()
