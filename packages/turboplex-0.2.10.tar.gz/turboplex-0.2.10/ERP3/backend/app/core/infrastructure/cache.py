"""
Cache Layer con Redis para ERP3
Proporciona decoradores y utilidades para cachear resultados de funciones costosas
"""

import json
import hashlib
from functools import wraps
from typing import Callable, Any, Optional
from uuid import UUID
import redis
from app.core.config import settings
from app.core.infrastructure.serializer import CustomJSONEncoder
import logging

logger = logging.getLogger(__name__)

redis_client: Optional[redis.Redis] = None


def get_redis_client() -> Optional[redis.Redis]:
    """Obtiene el cliente Redis, con fallback si no está disponible"""
    global redis_client

    if redis_client is None:
        try:
            redis_client = redis.from_url(
                settings.REDIS_URL,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            redis_client.ping()
            logger.info("✅ Conexión a Redis establecida")
        except Exception as e:
            logger.warning(f"⚠️  Redis no disponible: {e}. Cache deshabilitado.")
            redis_client = None

    return redis_client


def _generate_cache_key(func_name: str, args: tuple, kwargs: dict) -> str:
    """Genera una clave única para la función y sus argumentos"""
    key_data = {"func": func_name, "args": args, "kwargs": kwargs}
    key_str = json.dumps(key_data, sort_keys=True, cls=CustomJSONEncoder)
    key_hash = hashlib.blake2b(key_str.encode(), digest_size=16).hexdigest()
    return f"cache:{func_name}:{key_hash}"


def cache_result(ttl: int = 3600, key_prefix: Optional[str] = None):
    """
    Decorador para cachear resultados de funciones

    Args:
        ttl: Tiempo de vida del cache en segundos (default: 1 hora)
        key_prefix: Prefijo personalizado para la clave (opcional)

    Ejemplo:
        @cache_result(ttl=1800)
        def get_plan_cuentas(empresa_id: UUID):
            return db.query(CuentaContable).filter_by(empresa_id=empresa_id).all()
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            client = get_redis_client()

            if client is None:
                return func(*args, **kwargs)

            func_name = key_prefix or f"{func.__module__}.{func.__name__}"
            cache_key = _generate_cache_key(func_name, args, kwargs)

            try:
                cached_value = client.get(cache_key)
                if cached_value is not None:
                    logger.debug(f"🎯 Cache HIT: {func_name}")
                    return json.loads(cached_value)

                logger.debug(f"❌ Cache MISS: {func_name}")
                result = func(*args, **kwargs)

                client.setex(cache_key, ttl, json.dumps(result, cls=CustomJSONEncoder))

                return result

            except Exception as e:
                logger.error(f"Error en cache para {func_name}: {e}")
                return func(*args, **kwargs)

        return wrapper

    return decorator


def invalidate_cache(pattern: str):
    """
    Invalida todas las claves de cache que coincidan con el patrón

    Args:
        pattern: Patrón de búsqueda (ej: "cache:get_plan_cuentas:*")

    Ejemplo:
        invalidate_cache("cache:get_plan_cuentas:*")
    """
    client = get_redis_client()
    if client is None:
        return

    try:
        keys = client.keys(pattern)
        if keys:
            client.delete(*keys)
            logger.info(f"🗑️  Invalidadas {len(keys)} claves de cache: {pattern}")
    except Exception as e:
        logger.error(f"Error al invalidar cache {pattern}: {e}")


def invalidate_empresa_cache(empresa_id: UUID, resource: str):
    """
    Invalida cache específico de una empresa y recurso

    Args:
        empresa_id: ID de la empresa
        resource: Recurso a invalidar (ej: "plan_cuentas", "productos")

    Ejemplo:
        invalidate_empresa_cache(1, "plan_cuentas")
    """
    pattern = f"cache:*{resource}*{empresa_id}*"
    invalidate_cache(pattern)


def clear_all_cache():
    """Limpia TODO el cache (usar con precaución)"""
    client = get_redis_client()
    if client is None:
        return

    try:
        client.flushdb()
        logger.warning("⚠️  TODO el cache ha sido limpiado")
    except Exception as e:
        logger.error(f"Error al limpiar cache: {e}")


def cache_plan_cuentas(empresa_id: UUID, data: Any, ttl: int = 3600):
    """Cachea el plan de cuentas de una empresa"""
    client = get_redis_client()
    if client is None:
        return

    try:
        key = f"cache:plan_cuentas:{empresa_id}"
        client.setex(key, ttl, json.dumps(data, cls=CustomJSONEncoder))
        logger.info(f"💾 Plan de cuentas cacheado para empresa {empresa_id}")
    except Exception as e:
        logger.error(f"Error al cachear plan de cuentas: {e}")


def get_cached_plan_cuentas(empresa_id: UUID) -> Optional[Any]:
    """Obtiene el plan de cuentas cacheado"""
    client = get_redis_client()
    if client is None:
        return None

    try:
        key = f"cache:plan_cuentas:{empresa_id}"
        cached = client.get(key)
        if cached:
            logger.debug(
                f"🎯 Plan de cuentas obtenido del cache para empresa {empresa_id}"
            )
            return json.loads(cached)
    except Exception as e:
        logger.error(f"Error al obtener plan de cuentas del cache: {e}")

    return None


def cache_productos(empresa_id: UUID, data: Any, ttl: int = 1800):
    """Cachea el catálogo de productos de una empresa"""
    client = get_redis_client()
    if client is None:
        return

    try:
        key = f"cache:productos:{empresa_id}"
        client.setex(key, ttl, json.dumps(data, cls=CustomJSONEncoder))
        logger.info(f"💾 Catálogo de productos cacheado para empresa {empresa_id}")
    except Exception as e:
        logger.error(f"Error al cachear productos: {e}")


def get_cached_productos(empresa_id: UUID) -> Optional[Any]:
    """Obtiene el catálogo de productos cacheado"""
    client = get_redis_client()
    if client is None:
        return None

    try:
        key = f"cache:productos:{empresa_id}"
        cached = client.get(key)
        if cached:
            logger.debug(f"🎯 Productos obtenidos del cache para empresa {empresa_id}")
            return json.loads(cached)
    except Exception as e:
        logger.error(f"Error al obtener productos del cache: {e}")

    return None
