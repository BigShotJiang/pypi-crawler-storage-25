from rq import Queue

from app.core.infrastructure.config import settings
from app.core.infrastructure.redis import get_redis_client, validate_redis_connection


redis_conn = None
task_queue = None
try:
    if validate_redis_connection():
        redis_conn = get_redis_client()
        task_queue = Queue("default", connection=redis_conn)
except Exception as e:
    print(
        f"Warning: Could not connect to Redis at {settings.REDIS_URL}. Background jobs will fail. Error: {e}"
    )
    raise
