from decimal import Decimal
import os
from typing import List

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    API_V1_PREFIX: str = "/api/v1"
    PROJECT_NAME: str = "ERP Core"
    VERSION: str = "1.0.0"

    DATABASE_URL: str
    REPLICA_DATABASE_URL: str | None = None
    AUDIT_DATABASE_URL: str | None = None
    REPLICA_URL: str | None = None
    AUDIT_URL: str | None = None
    TEST_DATABASE_URL: str | None = None
    MIGRATIONS_DATABASE_URL: str | None = None
    MIGRATIONS_SCHEMA: str | None = None

    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:8000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:5174",
        "http://127.0.0.1:8000",
    ]
    ALLOWED_HOSTS: List[str] = [
        "http://localhost",
        "http://127.0.0.1",
        "http://localhost:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:5174",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]

    ENVIRONMENT: str = "development"

    REDIS_URL: str = "redis://localhost:6379/0"

    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_PER_MINUTE: int = 100

    API_ENVELOPE_V2: bool = False

    METRICS_ENABLED: bool = True
    SENTRY_DSN: str | None = None
    SENTRY_TRACES_SAMPLE_RATE: float = 0.0
    SENTRY_ENVIRONMENT: str | None = None

    CHILE_IMM_MENSUAL_CLP: Decimal = Decimal("500000")
    CHILE_GRATIFICACION_TOPE_INMM: Decimal = Decimal("4.75")
    CHILE_JORNADA_SEMANAL_DEFAULT: int = 44
    CHILE_UF_VALOR_REFERENCIA_CLP: Decimal = Decimal("38000")

    EXTERNAL_API_KEY: str

    STORAGE_MODE: str = "local"
    LOCAL_STORAGE_PATH: str = "storage_files"

    R2_BUCKET_NAME: str = ""
    R2_ACCOUNT_ID: str = ""
    R2_API_TOKEN: str = ""
    R2_ACCESS_KEY_ID: str = ""
    R2_SECRET_ACCESS_KEY: str = ""
    R2_ENDPOINT_URL: str = ""
    R2_REGION_NAME: str = "auto"

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True, extra="ignore")

    @model_validator(mode="after")
    def validate_security(self) -> "Settings":
        if self.REPLICA_DATABASE_URL is None and self.REPLICA_URL:
            self.REPLICA_DATABASE_URL = self.REPLICA_URL
        if self.AUDIT_DATABASE_URL is None and self.AUDIT_URL:
            self.AUDIT_DATABASE_URL = self.AUDIT_URL
        if self.ENVIRONMENT.lower() == "production":
            if not self.SECRET_KEY or self.SECRET_KEY.strip() == "":
                raise ValueError("SECRET_KEY es obligatorio en producción")
            if not self.DATABASE_URL or self.DATABASE_URL.strip() == "":
                raise ValueError("DATABASE_URL es obligatorio en producción")
            if not self.EXTERNAL_API_KEY or self.EXTERNAL_API_KEY.strip() == "":
                raise ValueError("EXTERNAL_API_KEY es obligatorio en producción")
            if self.ACCESS_TOKEN_EXPIRE_MINUTES <= 0:
                raise ValueError("ACCESS_TOKEN_EXPIRE_MINUTES debe ser > 0 en producción")
            if self.ACCESS_TOKEN_EXPIRE_MINUTES > 60:
                raise ValueError(
                    "ACCESS_TOKEN_EXPIRE_MINUTES debe ser <= 60 en producción"
                )
            insecure_api_keys = {"secure_api_key_123", "dev_dummy", "test_key"}
            if self.EXTERNAL_API_KEY in insecure_api_keys:
                raise ValueError(
                    "EXTERNAL_API_KEY no puede usar un valor de prueba en producción"
                )
            if self.STORAGE_MODE == "s3":
                if not self.R2_BUCKET_NAME:
                    raise ValueError(
                        "R2_BUCKET_NAME es obligatorio en producción cuando STORAGE_MODE='s3'"
                    )
                if not self.R2_ACCESS_KEY_ID or not self.R2_SECRET_ACCESS_KEY:
                    raise ValueError(
                        "Credenciales R2/S3 son obligatorias en producción cuando STORAGE_MODE='s3'"
                    )
            if self.REDIS_URL.startswith("redis://localhost"):
                raise ValueError("REDIS_URL no debe apuntar a localhost en producción")
        return self

    @model_validator(mode="after")
    def validate_cors(self) -> "Settings":
        raw = os.getenv("ALLOWED_HOSTS")
        if raw and isinstance(raw, str):
            parsed = [h.strip() for h in raw.split(",") if h.strip()]
            if parsed:
                self.ALLOWED_HOSTS = parsed
        elif self.BACKEND_CORS_ORIGINS and isinstance(self.BACKEND_CORS_ORIGINS, list):
            if not self.ALLOWED_HOSTS:
                self.ALLOWED_HOSTS = self.BACKEND_CORS_ORIGINS
        env = self.ENVIRONMENT.lower()
        if env == "production":
            if not self.ALLOWED_HOSTS:
                raise ValueError("ALLOWED_HOSTS es obligatorio en producción")
            for host in self.ALLOWED_HOSTS:
                if host in ("*", "http://*", "https://*"):
                    raise ValueError(
                        "ALLOWED_HOSTS no puede contener comodines amplios en producción"
                    )
        return self

    @model_validator(mode="after")
    def validate_sentry(self) -> "Settings":
        env = self.ENVIRONMENT.lower()
        if self.SENTRY_DSN:
            if self.SENTRY_TRACES_SAMPLE_RATE <= 0:
                if env == "staging":
                    self.SENTRY_TRACES_SAMPLE_RATE = 0.2
                elif env == "production":
                    self.SENTRY_TRACES_SAMPLE_RATE = 0.1
                else:
                    self.SENTRY_TRACES_SAMPLE_RATE = 0.0
            if not self.SENTRY_ENVIRONMENT:
                self.SENTRY_ENVIRONMENT = self.ENVIRONMENT
        return self


settings = Settings()
