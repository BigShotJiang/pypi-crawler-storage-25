from typing import Any, Dict, Generic, Optional, TypeVar, List
from pydantic import BaseModel
from pydantic.generics import GenericModel


class ErrorPayload(BaseModel):
    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class MetaPayload(BaseModel):
    request_id: Optional[str] = None
    empresa_id: Optional[str] = None
    module: Optional[str] = None
    rls_scope: Optional[str] = None
    timestamp: Optional[str] = None
    duration_ms: Optional[int] = None
    page: Optional["PageMeta"] = None
    extra: Optional[Dict[str, Any]] = None


T = TypeVar("T")


class BaseResponse(GenericModel, Generic[T]):
    success: bool
    data: Optional[T] = None
    error: Optional[ErrorPayload] = None
    meta: Optional[MetaPayload] = None


class PageMeta(BaseModel):
    page: int
    size: int
    total_items: int
    total_pages: int
    has_next: bool
    has_prev: bool


U = TypeVar("U")


class PagedResponse(GenericModel, Generic[U]):
    success: bool
    data: List[U]
    error: Optional[ErrorPayload] = None
    meta: MetaPayload
