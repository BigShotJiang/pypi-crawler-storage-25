from datetime import timedelta
from typing import Any, Callable

from rq import Queue

from app.core.infrastructure.redis import get_redis_client, validate_redis_connection


_queue: Queue | None = None


def _get_queue() -> Queue | None:
    global _queue
    if _queue is not None:
        return _queue
    if not validate_redis_connection():
        return None
    redis_conn = get_redis_client()
    _queue = Queue("critical", connection=redis_conn)
    return _queue


def enqueue(
    func: Callable[..., Any],
    *args: Any,
    delay_seconds: int | None = None,
    job_id: str | None = None,
    **kwargs: Any,
) -> str | None:
    queue = _get_queue()
    if queue is None:
        return None
    if delay_seconds is not None and delay_seconds > 0:
        job = queue.enqueue_in(
            timedelta(seconds=delay_seconds),
            func,
            *args,
            job_id=job_id,
            **kwargs,
        )
        return job.id
    job = queue.enqueue(func, *args, job_id=job_id, **kwargs)
    return job.id
