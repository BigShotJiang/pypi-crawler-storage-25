import logging
import os
from typing import Any, Callable

import redis

from app.core.infrastructure.config import settings


logger = logging.getLogger(__name__)


_pool = redis.ConnectionPool.from_url(
    settings.REDIS_URL,
    max_connections=20,
    socket_connect_timeout=2,
    socket_timeout=2,
    retry_on_timeout=True,
)


def get_redis_client(*, decode_responses: bool = False) -> redis.Redis:
    return redis.Redis(connection_pool=_pool, decode_responses=decode_responses)


def _is_production_env() -> bool:
    env = (settings.ENVIRONMENT or "").lower()
    env_override = (os.getenv("ENV") or "").lower()
    return env == "production" or env_override == "production"


def validate_redis_connection() -> bool:
    try:
        client = get_redis_client()
        client.ping()
        return True
    except Exception as exc:
        if _is_production_env():
            logger.error("Redis no disponible en producción: %s", exc)
            raise
        logger.warning("Modo Local: Tareas de fondo desactivadas")
        logger.warning("Redis no disponible: %s", exc)
        return False


def compute_backoff_delay(
    attempt: int, base_seconds: int = 5, max_seconds: int = 300
) -> int:
    if attempt < 1:
        attempt = 1
    delay = base_seconds * (2 ** (attempt - 1))
    return max_seconds if delay > max_seconds else delay


def idempotent_task(
    task_id_builder: Callable[..., str], ttl_seconds: int = 86400
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            task_id = task_id_builder(*args, **kwargs)
            client: redis.Redis | None
            try:
                client = get_redis_client()
            except Exception as exc:
                logger.warning(
                    "Idempotencia deshabilitada, error obteniendo Redis: %s", exc
                )
                client = None
            if client is not None:
                try:
                    exists = client.get(f"task-id:{task_id}")
                    if exists:
                        logger.info(
                            "Tarea idempotente ignorada por clave existente: %s", task_id
                        )
                        return None
                except Exception as exc:
                    logger.warning(
                        "Error verificando idempotencia en Redis para %s: %s",
                        task_id,
                        exc,
                    )
            result = func(*args, **kwargs)
            if client is not None:
                try:
                    client.set(f"task-id:{task_id}", "1", ex=ttl_seconds, nx=True)
                except Exception as exc:
                    logger.warning(
                        "Error registrando idempotencia en Redis para %s: %s",
                        task_id,
                        exc,
                    )
            return result

        return wrapper

    return decorator
