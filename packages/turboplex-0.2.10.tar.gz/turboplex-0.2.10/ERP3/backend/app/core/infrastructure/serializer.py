import json
from datetime import datetime, date
from decimal import Decimal
from uuid import UUID
from typing import Any, Dict, Generic, Literal, Optional, TypeVar

from pydantic.generics import GenericModel


class CustomJSONEncoder(json.JSONEncoder):
    """
    Encoder robusto para serializar objetos de SQLAlchemy y tipos complejos.
    Soporta: datetime, date, Decimal, UUID, bytes.
    """

    def default(self, obj: Any) -> Any:
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()

        if isinstance(obj, Decimal):
            return str(obj)

        if isinstance(obj, UUID):
            return str(obj)

        if isinstance(obj, bytes):
            try:
                return obj.decode("utf-8")
            except Exception:
                return str(obj)

        if hasattr(obj, "__dict__"):
            return obj.__dict__

        return super().default(obj)


def safe_json_dumps(data: Any) -> str:
    """Helper para serializar usando el encoder customizado"""
    return json.dumps(data, cls=CustomJSONEncoder, ensure_ascii=False)


T = TypeVar("T")


class DebeziumPayload(GenericModel, Generic[T]):
    op: Literal["c", "u", "d", "r"]
    before: Optional[T] = None
    after: Optional[T] = None
    source: Optional[Dict[str, Any]] = None
    ts_ms: Optional[int] = None
    transaction: Optional[Dict[str, Any]] = None
