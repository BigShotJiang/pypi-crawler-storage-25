from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any, Literal, Sequence
from uuid import UUID

from fastapi import Depends, FastAPI, Header, HTTPException, Request, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import inspect, text
from sqlalchemy.orm import Session, sessionmaker

from app.core.database import reader_engine
from app.core.security.encryption_service import EncryptionService
from app.core.security.secrets_manager_service import secrets_manager
from app.core_modules.sistema.models import ParametroGlobal


MCPMode = Literal["Local", "External", "Hybrid", "Inactive"]


class ToolSchemaRequest(BaseModel):
    tables: list[str] | None = None
    include_columns: bool = True
    include_primary_key: bool = True

    model_config = ConfigDict(extra="forbid")


ToolFilterOp = Literal[
    "eq",
    "=",
    "neq",
    "!=",
    "<>",
    "gt",
    ">",
    "gte",
    ">=",
    "lt",
    "<",
    "lte",
    "<=",
    "like",
    "ilike",
    "in",
]


class ToolFilter(BaseModel):
    column: str
    op: ToolFilterOp = "eq"
    value: Any

    model_config = ConfigDict(extra="forbid")


class ToolOrderBy(BaseModel):
    column: str
    direction: Literal["asc", "desc"] = "asc"

    model_config = ConfigDict(extra="forbid")


class ToolSelectRequest(BaseModel):
    table: str
    columns: list[str] | None = None
    filters: list[ToolFilter] | None = None
    order_by: list[ToolOrderBy] | None = None
    limit: int = Field(default=100, ge=1, le=500)

    model_config = ConfigDict(extra="forbid")


class MCPToolDef(BaseModel):
    name: str
    description: str
    input_schema: dict[str, Any]

    model_config = ConfigDict(extra="forbid")


class MCPToolsResponse(BaseModel):
    tools: list[MCPToolDef]

    model_config = ConfigDict(extra="forbid")


@dataclass(frozen=True)
class ResolvedConfig:
    enabled: bool
    auth_token_present: bool
    local_endpoint_url: str | None
    openai_api_key_present: bool
    anthropic_api_key_present: bool

    @property
    def mode(self) -> MCPMode:
        has_local = bool(self.local_endpoint_url)
        has_external = self.openai_api_key_present or self.anthropic_api_key_present
        if has_local and has_external:
            return "Hybrid"
        if has_local:
            return "Local"
        if has_external:
            return "External"
        return "Inactive"

    @property
    def active(self) -> bool:
        return self.enabled and self.auth_token_present and self.mode != "Inactive"


_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _is_truthy(raw: str | None) -> bool:
    if raw is None:
        return False
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _is_safe_ident(name: str) -> bool:
    return bool(_IDENT_RE.match(name))


def _q(ident: str) -> str:
    if not _is_safe_ident(ident):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Identificador inválido: {ident}",
        )
    return f'"{ident}"'


def _reader_session_for_empresa(empresa_id: UUID) -> Session:
    ReaderSessionLocal = sessionmaker(bind=reader_engine, autocommit=False, autoflush=False)
    db = ReaderSessionLocal()
    db.info["empresa_id"] = empresa_id
    return db


def _get_empresa_id(x_empresa_id: str = Header(..., alias="X-Empresa-Id")) -> UUID:
    try:
        return UUID(str(x_empresa_id))
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Header X-Empresa-Id debe ser un UUID válido",
        )


def _get_auth_token(
    authorization: str | None = Header(default=None, alias="Authorization"),
    x_mcp_token: str | None = Header(default=None, alias="X-MCP-Token"),
) -> str | None:
    if x_mcp_token:
        return x_mcp_token.strip()
    if authorization and authorization.lower().startswith("bearer "):
        return authorization.split(" ", 1)[1].strip()
    return None


def _resolve_auth_token(db: Session | None, empresa_id: UUID | None) -> str | None:
    env_token = os.getenv("MCP_AUTH_TOKEN")
    if env_token:
        return env_token.strip()

    if db is not None:
        try:
            val = secrets_manager.get_secret(db=db, key="MCP_AUTH_TOKEN", actor_id=None)
            if val:
                return val.strip()
        except Exception:
            pass

    if db is not None and empresa_id is not None:
        try:
            param = (
                db.query(ParametroGlobal)
                .filter(
                    ParametroGlobal.empresa_id == empresa_id,
                    ParametroGlobal.llave == "MCP_AUTH_TOKEN",
                )
                .first()
            )
            if param and param.valor:
                raw = str(param.valor)
                if raw.startswith("enc:"):
                    dec = EncryptionService.decrypt(raw.removeprefix("enc:"))
                    if dec:
                        return dec.strip()
                return raw.strip()
        except Exception:
            pass

    return None


def _get_param(db: Session, empresa_id: UUID, key: str) -> str | None:
    param = (
        db.query(ParametroGlobal)
        .filter(ParametroGlobal.empresa_id == empresa_id, ParametroGlobal.llave == key)
        .first()
    )
    if not param or not param.valor:
        return None
    raw = str(param.valor)
    if raw.startswith("enc:"):
        return EncryptionService.decrypt(raw.removeprefix("enc:"))
    return raw


def _resolve_config(db: Session, empresa_id: UUID) -> ResolvedConfig:
    enabled_raw = _get_param(db, empresa_id, "MCP_ENABLED") or os.getenv("MCP_ENABLED")
    enabled = _is_truthy(enabled_raw)

    local_endpoint_url = (
        _get_param(db, empresa_id, "MCP_LOCAL_ENDPOINT_URL")
        or os.getenv("MCP_LOCAL_ENDPOINT_URL")
    )

    openai_key = _get_param(db, empresa_id, "MCP_OPENAI_API_KEY") or secrets_manager.get_secret(
        db=db, key="MCP_OPENAI_API_KEY", actor_id=None
    )
    if not openai_key:
        openai_key = os.getenv("MCP_OPENAI_API_KEY")

    anthropic_key = _get_param(
        db, empresa_id, "MCP_ANTHROPIC_API_KEY"
    ) or secrets_manager.get_secret(db=db, key="MCP_ANTHROPIC_API_KEY", actor_id=None)
    if not anthropic_key:
        anthropic_key = os.getenv("MCP_ANTHROPIC_API_KEY")

    auth_token = _resolve_auth_token(db=db, empresa_id=empresa_id)

    return ResolvedConfig(
        enabled=enabled,
        auth_token_present=bool(auth_token),
        local_endpoint_url=(local_endpoint_url.strip() if local_endpoint_url else None),
        openai_api_key_present=bool(openai_key and str(openai_key).strip()),
        anthropic_api_key_present=bool(anthropic_key and str(anthropic_key).strip()),
    )


def _require_active(config: ResolvedConfig) -> None:
    if not config.enabled:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MCP inactivo: MCP_ENABLED desactivado",
        )
    if not config.auth_token_present:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MCP inactivo: falta configuración de autenticación",
        )
    if config.mode == "Inactive":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MCP inactivo: no hay Providers configurados",
        )


def _require_request_auth(
    token_in_request: str | None,
    token_expected: str | None,
) -> None:
    if not token_expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MCP inactivo: falta configuración de autenticación",
        )
    if not token_in_request or token_in_request != token_expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No autorizado",
        )


def _tool_db_schema(db: Session, req: ToolSchemaRequest) -> dict[str, Any]:
    insp = inspect(reader_engine)
    tables = insp.get_table_names()
    selected = tables
    if req.tables:
        safe = []
        for t in req.tables:
            if not _is_safe_ident(t):
                continue
            if t in tables:
                safe.append(t)
        selected = safe

    out: dict[str, Any] = {"tables": []}
    for t in selected:
        entry: dict[str, Any] = {"name": t}
        if req.include_primary_key:
            try:
                pk = insp.get_pk_constraint(t) or {}
                entry["primary_key"] = pk.get("constrained_columns") or []
            except Exception:
                entry["primary_key"] = []
        if req.include_columns:
            cols = insp.get_columns(t) or []
            entry["columns"] = [
                {
                    "name": c.get("name"),
                    "type": str(c.get("type")),
                    "nullable": bool(c.get("nullable", True)),
                }
                for c in cols
            ]
        out["tables"].append(entry)
    return out


def _tool_db_select(db: Session, empresa_id: UUID, req: ToolSelectRequest) -> dict[str, Any]:
    insp = inspect(reader_engine)
    if not _is_safe_ident(req.table):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Tabla inválida"
        )
    table_names = insp.get_table_names()
    if req.table not in table_names:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Tabla no encontrada"
        )

    columns_info = insp.get_columns(req.table) or []
    known_cols = {c.get("name") for c in columns_info if c.get("name")}
    has_empresa_id = "empresa_id" in known_cols

    cols = req.columns or ["*"]
    if cols != ["*"]:
        for c in cols:
            if c not in known_cols:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Columna inválida: {c}",
                )

    select_cols = "*"
    if cols != ["*"]:
        select_cols = ", ".join(_q(c) for c in cols)

    where_parts: list[str] = []
    params: dict[str, Any] = {}

    filters: list[ToolFilter] = list(req.filters or [])
    if has_empresa_id:
        filters = [f for f in filters if f.column != "empresa_id"]
        filters.append(ToolFilter(column="empresa_id", op="eq", value=empresa_id))

    for idx, f in enumerate(filters):
        if f.column not in known_cols:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Columna inválida en filtro: {f.column}",
            )
        col_sql = _q(f.column)
        key = f"p{idx}"
        op = f.op
        if op == "=":
            op = "eq"
        elif op in {"!=", "<>"}:
            op = "neq"
        elif op == ">":
            op = "gt"
        elif op == ">=":
            op = "gte"
        elif op == "<":
            op = "lt"
        elif op == "<=":
            op = "lte"

        if op == "eq":
            where_parts.append(f"{col_sql} = :{key}")
            params[key] = f.value
        elif op == "neq":
            where_parts.append(f"{col_sql} <> :{key}")
            params[key] = f.value
        elif op == "gt":
            where_parts.append(f"{col_sql} > :{key}")
            params[key] = f.value
        elif op == "gte":
            where_parts.append(f"{col_sql} >= :{key}")
            params[key] = f.value
        elif op == "lt":
            where_parts.append(f"{col_sql} < :{key}")
            params[key] = f.value
        elif op == "lte":
            where_parts.append(f"{col_sql} <= :{key}")
            params[key] = f.value
        elif op == "like":
            where_parts.append(f"{col_sql} LIKE :{key}")
            params[key] = f.value
        elif op == "ilike":
            where_parts.append(f"{col_sql} ILIKE :{key}")
            params[key] = f.value
        elif op == "in":
            if not isinstance(f.value, Sequence) or isinstance(f.value, (str, bytes)):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Filtro 'in' requiere lista",
                )
            where_parts.append(f"{col_sql} = ANY(:{key})")
            params[key] = list(f.value)
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Operador inválido: {f.op}",
            )

    order_clause = ""
    if req.order_by:
        order_sql = []
        for ob in req.order_by:
            if ob.column not in known_cols:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Columna inválida en order_by: {ob.column}",
                )
            dir_sql = "ASC" if ob.direction == "asc" else "DESC"
            order_sql.append(f"{_q(ob.column)} {dir_sql}")
        if order_sql:
            order_clause = " ORDER BY " + ", ".join(order_sql)

    where_clause = ""
    if where_parts:
        where_clause = " WHERE " + " AND ".join(where_parts)

    sql = f"SELECT {select_cols} FROM {_q(req.table)}{where_clause}{order_clause} LIMIT {int(req.limit)}"
    rows = db.execute(text(sql), params).mappings().all()
    return {"rows": jsonable_encoder(list(rows))}


def create_mcp_app() -> FastAPI:
    app = FastAPI(title="ERP3 MCP Server", version="1.0.0")

    @app.get("/health")
    def health() -> Any:
        enabled = _is_truthy(os.getenv("MCP_ENABLED"))
        has_auth_token = bool(os.getenv("MCP_AUTH_TOKEN"))
        has_local = bool(os.getenv("MCP_LOCAL_ENDPOINT_URL"))
        has_external = bool(os.getenv("MCP_OPENAI_API_KEY") or os.getenv("MCP_ANTHROPIC_API_KEY"))
        if has_local and has_external:
            mode: MCPMode = "Hybrid"
        elif has_local:
            mode = "Local"
        elif has_external:
            mode = "External"
        else:
            mode = "Inactive"
        return {
            "status": "ok",
            "mode": mode,
            "active": bool(enabled and has_auth_token and mode != "Inactive"),
        }

    @app.get("/v1/tools", response_model=MCPToolsResponse)
    def list_tools(
        empresa_id: UUID = Depends(_get_empresa_id),
        token_in_request: str | None = Depends(_get_auth_token),
    ) -> MCPToolsResponse:
        db = _reader_session_for_empresa(empresa_id)
        try:
            config = _resolve_config(db, empresa_id)
            _require_active(config)
            token_expected = _resolve_auth_token(db=db, empresa_id=empresa_id)
            _require_request_auth(token_in_request, token_expected)
        finally:
            db.close()

        tools = [
            MCPToolDef(
                name="db_schema",
                description="Devuelve el esquema (tablas/columnas) desde DB_R (réplica).",
                input_schema=ToolSchemaRequest.model_json_schema(),
            ),
            MCPToolDef(
                name="db_select",
                description="Ejecuta un SELECT controlado (sin SQL libre) sobre DB_R (réplica).",
                input_schema=ToolSelectRequest.model_json_schema(),
            ),
        ]
        return MCPToolsResponse(tools=tools)

    @app.post("/v1/tools/db_schema")
    def run_db_schema(
        payload: ToolSchemaRequest,
        empresa_id: UUID = Depends(_get_empresa_id),
        token_in_request: str | None = Depends(_get_auth_token),
    ) -> Any:
        db = _reader_session_for_empresa(empresa_id)
        try:
            config = _resolve_config(db, empresa_id)
            _require_active(config)
            token_expected = _resolve_auth_token(db=db, empresa_id=empresa_id)
            _require_request_auth(token_in_request, token_expected)
            out = _tool_db_schema(db, payload)
        finally:
            db.close()
        return out

    @app.post("/v1/tools/db_select")
    def run_db_select(
        payload: ToolSelectRequest,
        empresa_id: UUID = Depends(_get_empresa_id),
        token_in_request: str | None = Depends(_get_auth_token),
    ) -> Any:
        db = _reader_session_for_empresa(empresa_id)
        try:
            config = _resolve_config(db, empresa_id)
            _require_active(config)
            token_expected = _resolve_auth_token(db=db, empresa_id=empresa_id)
            _require_request_auth(token_in_request, token_expected)
            out = _tool_db_select(db, empresa_id, payload)
        finally:
            db.close()
        return out

    @app.exception_handler(Exception)
    async def unhandled_exc_handler(request: Request, exc: Exception) -> Any:
        if isinstance(exc, HTTPException):
            return JSONResponse(
                status_code=exc.status_code,
                content=jsonable_encoder({"detail": exc.detail}),
                headers=exc.headers,
            )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "Error interno MCP"},
        )

    return app
