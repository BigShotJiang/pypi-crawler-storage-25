import asyncio
from dataclasses import dataclass
from typing import Any, Callable, Literal

from . import broker_kafka, broker_rabbit, broker_redis
from app.core.infrastructure.events import event_dispatcher
from app.core.infrastructure.redis import validate_redis_connection
from fastapi.encoders import jsonable_encoder


Lane = Literal["fast", "critical", "stream"]
Mode = Literal["rq", "thread", "inline"]


@dataclass(frozen=True)
class DispatchResult:
    mode: Mode
    lane: Lane
    job_id: str | None


class Messenger:
    def enqueue(
        self,
        func: Callable[..., Any],
        *args: Any,
        lane: Lane = "fast",
        delay_seconds: int | None = None,
        job_id: str | None = None,
        **kwargs: Any,
    ) -> DispatchResult:
        broker = self._select_broker(lane)
        job = broker.enqueue(
            func,
            *args,
            delay_seconds=delay_seconds,
            job_id=job_id,
            **kwargs,
        )
        if job is not None:
            return DispatchResult(mode="rq", lane=lane, job_id=job)
        return self._fallback(func, *args, lane=lane, **kwargs)

    def can_enqueue(self, lane: Lane = "fast") -> bool:
        if lane in {"fast", "critical"}:
            try:
                return validate_redis_connection()
            except Exception:
                return False
        return False

    def _select_broker(self, lane: Lane) -> Any:
        if lane == "critical":
            return broker_rabbit
        if lane == "stream":
            return broker_kafka
        return broker_redis

    def _fallback(
        self, func: Callable[..., Any], *args: Any, lane: Lane, **kwargs: Any
    ) -> DispatchResult:
        if lane == "fast":
            func(*args, **kwargs)
            return DispatchResult(mode="inline", lane=lane, job_id=None)
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            func(*args, **kwargs)
            return DispatchResult(mode="inline", lane=lane, job_id=None)
        loop.create_task(asyncio.to_thread(func, *args, **kwargs))
        return DispatchResult(mode="thread", lane=lane, job_id=None)


messenger = Messenger()

_public_dispatch_registered = False


def _is_public_event(data: Any) -> bool:
    if isinstance(data, dict):
        return data.get("visibility") == "public"
    return False


async def _publish_public_event(event_type: str, data: Any) -> None:
    if not _is_public_event(data):
        return
    try:
        payload = {"event_type": event_type, "data": jsonable_encoder(data)}
    except Exception:
        payload = {"event_type": event_type, "data": str(data)}
    topic = f"erp3.public.{event_type}"
    await asyncio.to_thread(broker_kafka.kafka_broker.publish, topic, payload)


def _register_public_dispatch() -> None:
    global _public_dispatch_registered
    if _public_dispatch_registered:
        return
    event_dispatcher.subscribe_all(_publish_public_event)
    _public_dispatch_registered = True


_register_public_dispatch()
