from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.core.database.models import Setting
import logging
from typing import Optional, Union
from typing import Dict, List

logger = logging.getLogger(__name__)

ConfigValue = Union[Dict[str, object], List[object], str, int, float, bool, None]


class ConfigManager:
    _instance: Optional["ConfigManager"] = None
    _cache: Dict[str, ConfigValue] = {}

    def __new__(cls) -> "ConfigManager":
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
            cls._instance._loaded = False
        return cls._instance

    @staticmethod
    def _new_db_session() -> Session:
        db: Session = SessionLocal()
        db.info["allow_no_tenant"] = True
        return db

    def _load_settings(self) -> None:
        if self._loaded:
            return

        db = self._new_db_session()
        try:
            settings = db.query(Setting).all()
            for s in settings:
                self._cache[s.key] = s.value
            logger.info(f"ConfigManager loaded {len(settings)} settings.")
            self._loaded = True
        except Exception as e:
            logger.error(f"Error loading settings: {e}")
        finally:
            db.close()

    def get_setting(
        self, key: str, default: Optional[ConfigValue] = None
    ) -> Optional[ConfigValue]:
        if not self._loaded:
            self._load_settings()

        if key in self._cache:
            return self._cache[key]

        db = self._new_db_session()
        try:
            setting = db.query(Setting).filter(Setting.key == key).first()
            if setting:
                self._cache[key] = setting.value
                return setting.value
        except Exception as e:
            logger.error(f"Error fetching setting {key}: {e}")
        finally:
            db.close()

        return default

    def set_setting(
        self, key: str, value: ConfigValue, type_str: str, description: Optional[str] = None
    ) -> None:
        db = self._new_db_session()
        try:
            setting = db.query(Setting).filter(Setting.key == key).first()
            if not setting:
                setting = Setting(key=key)
                db.add(setting)

            setting.value = value
            setting.type = type_str
            if description:
                setting.description = description

            db.commit()
            self._cache[key] = value
            logger.info(f"Setting updated: {key} = {value}")
        except Exception as e:
            logger.error(f"Error setting config {key}: {e}")
            db.rollback()
        finally:
            db.close()

    def refresh(self) -> None:
        self._load_settings()


config_manager: ConfigManager = ConfigManager()
