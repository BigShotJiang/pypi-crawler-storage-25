import asyncio
import logging
import os
from contextvars import ContextVar, Token
from datetime import datetime
from typing import Any, Iterator

from sqlalchemy import String, bindparam, cast, create_engine, event, event as _sa_event, text
from sqlalchemy.exc import DatabaseError
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import (
    Session as SASession,
    sessionmaker,
    with_loader_criteria,
)
from sqlalchemy.pool import StaticPool
from sqlalchemy.sql.dml import Delete, Insert, Update
from sqlalchemy.sql.elements import BindParameter, ColumnElement
from sqlalchemy.sql.schema import Table
from sqlalchemy.sql.selectable import Alias, CTE, Join, Subquery, Select

from app.core.infrastructure.config import settings


engine_args: dict[str, Any] = {
    "pool_pre_ping": True,
    "echo": settings.ENVIRONMENT == "development",
}

if "sqlite" in settings.DATABASE_URL:
    engine_args["connect_args"] = {"check_same_thread": False}
    engine_args["poolclass"] = StaticPool
else:
    engine_args.update(
        {
            "pool_size": 20,
            "max_overflow": 10,
            "pool_timeout": 30,
            "pool_recycle": 3600,
            "connect_args": {"options": "-c statement_timeout=10000"},
        }
    )

_writer_database_url = settings.DATABASE_URL
_reader_database_url = (
    settings.REPLICA_DATABASE_URL
    or os.getenv("REPLICA_DATABASE_URL")
    or os.getenv("REPLICA_URL")
    or os.getenv("READ_DATABASE_URL")
    or _writer_database_url
)
_audit_database_url = (
    settings.AUDIT_DATABASE_URL
    or os.getenv("AUDIT_DATABASE_URL")
    or os.getenv("AUDIT_URL")
    or _writer_database_url
)
_disable_audit_db = (
    getattr(settings, "DISABLE_AUDIT_DB", None)
    or os.getenv("DISABLE_AUDIT_DB")
    or os.getenv("AUDIT_DB_DISABLED")
)

logger = logging.getLogger(__name__)
if _reader_database_url == _writer_database_url:
    logger.info(
        "Modo Monolítico: REPLICA_DATABASE_URL no configurada (lecturas apuntan a DATABASE_URL)."
    )
if _audit_database_url == _writer_database_url:
    logger.info(
        "Modo Monolítico: AUDIT_DATABASE_URL no configurada (auditoría apunta a DATABASE_URL)."
    )

_request_context: ContextVar[dict[str, Any] | None] = ContextVar(
    "erp3_request_context", default=None
)


def set_request_context(ctx: dict[str, Any]) -> Token[dict[str, Any] | None]:
    return _request_context.set(ctx)


def reset_request_context(token: Token[dict[str, Any] | None]) -> None:
    _request_context.reset(token)


def get_request_context() -> dict[str, Any] | None:
    return _request_context.get()


def check_logical_replication(engine: Any) -> bool:
    try:
        dialect_name = getattr(getattr(engine, "dialect", None), "name", None)
        if dialect_name != "postgresql":
            return False
    except Exception:
        return False

    try:
        with engine.connect() as conn:
            wal_level = conn.execute(text("SHOW wal_level")).scalar()
            max_replication_slots = conn.execute(
                text("SHOW max_replication_slots")
            ).scalar()
            max_wal_senders = conn.execute(text("SHOW max_wal_senders")).scalar()

        logger.info(
            "Postgres logical replication settings: wal_level=%s max_replication_slots=%s max_wal_senders=%s",
            wal_level,
            max_replication_slots,
            max_wal_senders,
        )

        if str(wal_level).lower() != "logical":
            logger.warning(
                "Debezium/CDC requiere wal_level=logical (actual=%s).",
                wal_level,
            )

        try:
            slots = int(max_replication_slots)
        except Exception:
            slots = 0
        if slots < 5:
            logger.warning(
                "Debezium/CDC requiere max_replication_slots >= 5 (actual=%s).",
                max_replication_slots,
            )

        try:
            senders = int(max_wal_senders)
        except Exception:
            senders = 0
        if senders < 5:
            logger.warning(
                "Debezium/CDC recomienda max_wal_senders >= 5 (actual=%s).",
                max_wal_senders,
            )

        return True
    except Exception as exc:
        logger.warning(
            "No se pudo chequear wal_level (CDC/Debezium) de forma informativa: %s",
            exc,
        )
        return False


writer_engine = create_engine(_writer_database_url, **engine_args)
if settings.ENVIRONMENT == "development":
    check_logical_replication(writer_engine)
reader_engine = create_engine(_reader_database_url, **engine_args)
audit_engine = (
    writer_engine
    if (_disable_audit_db and str(_disable_audit_db).strip().lower() in {"1", "true", "yes"})
    else create_engine(_audit_database_url, **engine_args)
)


def _db_error_listener(context: Any) -> None:
    from app.core.infrastructure.events import event_dispatcher

    exception = context.original_exception
    error_str = str(exception).lower()

    event_type = None
    severity = "CRITICAL"

    if (
        isinstance(exception, TimeoutError)
        or "timeout" in error_str
        or "timed out" in error_str
    ):
        event_type = "SYSTEM_ALERT_DB_TIMEOUT"
    elif isinstance(exception, DatabaseError):
        event_type = "SYSTEM_ALERT_DB_PANIC"

    if event_type:
        logger.error(f"[DB-CRITICAL] {event_type} detectado: {exception}")

        payload = {
            "error_type": type(exception).__name__,
            "message": str(exception),
            "timestamp": datetime.now().isoformat(),
            "severity": severity,
            "source": "database.listener",
            "details": "Error crítico de base de datos detectado por SQLAlchemy Listener.",
        }

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(event_dispatcher.dispatch(event_type, payload))
        except RuntimeError:
            logger.warning(f"No async loop available to dispatch {event_type} event.")
        except Exception as e:
            logger.error(f"Error dispatching {event_type} event: {e}")


event.listen(writer_engine, "handle_error", _db_error_listener)
event.listen(reader_engine, "handle_error", _db_error_listener)
event.listen(audit_engine, "handle_error", _db_error_listener)

if settings.ENVIRONMENT == "development":
    _route_logger = logging.getLogger("erp3.db.route")

    def _tag_engine(engine: Any, tag: str) -> None:
        @_sa_event.listens_for(engine, "connect")
        def _on_connect(dbapi_connection: Any, connection_record: Any) -> None:
            try:
                connection_record.info["erp3_db_tag"] = tag
            except Exception:
                pass

        @_sa_event.listens_for(engine, "before_cursor_execute")
        def _before_cursor_execute(
            conn: Any,
            cursor: Any,
            statement: str,
            parameters: Any,
            context: Any,
            executemany: bool,
        ) -> None:
            try:
                stmt = " ".join(statement.split())
                if len(stmt) > 400:
                    stmt = stmt[:400] + "..."
                _route_logger.info("%s %s", tag, stmt)
            except Exception:
                _route_logger.info("%s <statement>", tag)

    _tag_engine(writer_engine, "[DB_WRITE]")
    _tag_engine(reader_engine, "[DB_READ]")
    _tag_engine(audit_engine, "[DB_AUDIT_DISABLED]" if (audit_engine is writer_engine) else "[DB_AUDIT]")


class TestAwareSession(SASession):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

    def get_bind(
        self, mapper: Any | None = None, clause: Any | None = None, **kw: Any
    ) -> Any:
        if self.info.get("force_writer", False):
            return writer_engine
        if self.info.get("has_written", False):
            return writer_engine

        if self._flushing or self.new or self.dirty or self.deleted:
            self.info["has_written"] = True
            return writer_engine

        if clause is None:
            return writer_engine

        if isinstance(clause, (Insert, Update, Delete)):
            self.info["has_written"] = True
            return writer_engine

        if isinstance(clause, Select):
            tx = self.get_transaction()
            origin = getattr(tx, "origin", None) if tx is not None else None
            origin_name = getattr(origin, "name", None) if origin is not None else None
            if origin_name in {"BEGIN", "BEGIN_NESTED"}:
                return writer_engine
            return reader_engine

        return writer_engine


SessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=writer_engine, class_=TestAwareSession
)


class Base(DeclarativeBase):
    pass


def get_db() -> Iterator[SASession]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def validate_database_connections() -> None:
    def _ping(engine: Any, name: str) -> None:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

    try:
        _ping(writer_engine, "DB_W")
        logger.info("DB_W OK (writer).")
    except Exception as exc:
        logger.error("DB_W FALLÓ (writer). Startup abortado: %s", exc)
        raise

    try:
        _ping(reader_engine, "DB_R")
        logger.info("DB_R OK (replica/reader).")
    except Exception as exc:
        logger.warning("DB_R FALLÓ (replica/reader). Bulkhead: se continúa. Error=%s", exc)

    try:
        _ping(audit_engine, "DB_AUDIT")
        logger.info("DB_AUDIT OK (auditoría).")
    except Exception as exc:
        logger.warning(
            "DB_AUDIT FALLÓ (auditoría). Bulkhead: se continúa. Error=%s", exc
        )


@_sa_event.listens_for(SASession, "do_orm_execute")
def _add_tenant_filter(execute_state: Any) -> None:
    session = execute_state.session
    ctx = get_request_context()
    request_path = session.info.get("request_path")
    if not isinstance(request_path, str) or not request_path:
        request_path = str((ctx or {}).get("path") or "")
    request_cmp = session.info.get("request_cmp")
    if not isinstance(request_cmp, str) or not request_cmp:
        request_cmp = str((ctx or {}).get("cmp") or "")
    request_id = session.info.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        request_id = str((ctx or {}).get("request_id") or "")
    is_debug_endpoint = "/sucursales/active" in request_path

    try:
        bind = session.get_bind() if hasattr(session, "get_bind") else session.bind
        if bind is not None:
            dialect_name = getattr(bind, "dialect", None)
            if dialect_name:
                name = getattr(dialect_name, "name", None)
                if name == "sqlite":
                    return
    except Exception:
        pass

    no_tenant_select_allowlist_unscoped = frozenset(
        {
            "usuarios",
            "usuarios_empresas",
            "empresas",
            "roles",
            "subscription_plans",
            "settings",
            "configuraciones",
            "verticals",
            "audit_logs",
            "business_audit_logs",
        }
    )
    tenant_scoped_tables = frozenset(
        {
            getattr(mapper.class_, "__tablename__", "")
            for mapper in Base.registry.mappers
            if hasattr(mapper.class_, "empresa_id")
            and isinstance(getattr(mapper.class_, "__tablename__", None), str)
        }
    )

    def _walk_from_clause(from_clause: Any, out: set[str]) -> None:
        if from_clause is None:
            return
        if isinstance(from_clause, Join):
            _walk_from_clause(from_clause.left, out)
            _walk_from_clause(from_clause.right, out)
            return
        if isinstance(from_clause, (Alias, Subquery, CTE)):
            element = getattr(from_clause, "element", None)
            if element is not None:
                _walk_statement(element, out)
            return
        if isinstance(from_clause, Table):
            out.add(from_clause.name)
            return
        name = getattr(from_clause, "name", None)
        if isinstance(name, str) and name:
            out.add(name)

    def _walk_statement(stmt: Any, out: set[str]) -> None:
        get_final_froms = getattr(stmt, "get_final_froms", None)
        if not callable(get_final_froms):
            return
        for f in get_final_froms() or []:
            _walk_from_clause(f, out)

    def _log_tenant_debug(
        *,
        level: int,
        msg: str,
        table_names: set[str] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        if not is_debug_endpoint:
            return
        payload: dict[str, Any] = {
            "path": request_path,
            "cmp": request_cmp or None,
            "request_id": request_id or None,
            "empresa_id": str(session.info.get("empresa_id") or ""),
            "allow_no_tenant": bool(session.info.get("allow_no_tenant", False)),
            "bypass_app_tenant_filter": bool(
                session.info.get("bypass_app_tenant_filter", False)
            ),
        }
        if table_names is not None:
            payload["tables"] = sorted(table_names)
        if extra:
            payload.update(extra)
        logging.getLogger("erp3.tenant_debug").log(level, "%s %s", msg, payload)

    def _is_column(obj: Any) -> bool:
        return isinstance(obj, ColumnElement) and hasattr(obj, "table")

    def _is_empresa_id_column(obj: Any) -> bool:
        name = getattr(obj, "name", None) or getattr(obj, "key", None)
        return isinstance(name, str) and name == "empresa_id"

    def _has_empresa_id_predicate(expr: Any) -> bool:
        if expr is None:
            return False
        left = getattr(expr, "left", None)
        right = getattr(expr, "right", None)
        if left is not None and right is not None:
            if _is_empresa_id_column(left) and (isinstance(right, BindParameter) or not _is_column(right)):
                return True
            if _is_empresa_id_column(right) and (isinstance(left, BindParameter) or not _is_column(left)):
                return True
        for child in expr.get_children() if hasattr(expr, "get_children") else []:
            if _has_empresa_id_predicate(child):
                return True
        return False

    tenant = session.info.get("empresa_id", None)
    if tenant is None:
        table_names: set[str] = set()
        try:
            _walk_statement(execute_state.statement, table_names)
        except Exception:
            table_names = set()
        if session.info.get("allow_no_tenant", False):
            if not execute_state.is_select:
                _log_tenant_debug(
                    level=logging.ERROR,
                    msg="Tenant guard: escritura sin contexto de empresa",
                    table_names=table_names,
                )
                raise RuntimeError(
                    "Tenant context missing for ORM execution (no-tenant mode only allows SELECT)"
                )
            if not table_names:
                return
            forbidden = sorted(
                {
                    t
                    for t in table_names
                    if t not in no_tenant_select_allowlist_unscoped
                    and t not in tenant_scoped_tables
                }
            )
            if forbidden:
                _log_tenant_debug(
                    level=logging.ERROR,
                    msg="Tenant guard: SELECT no-tenant bloqueado por tablas fuera de allowlist",
                    table_names=table_names,
                    extra={"forbidden": forbidden},
                )
                raise RuntimeError(
                    f"Tenant context missing for ORM execution (no-tenant SELECT not allowed on tables={forbidden})"
                )
            scoped_used = sorted(
                {
                    t
                    for t in table_names
                    if t in tenant_scoped_tables and t not in no_tenant_select_allowlist_unscoped
                }
            )
            if scoped_used and not _has_empresa_id_predicate(
                getattr(execute_state.statement, "whereclause", None)
            ):
                _log_tenant_debug(
                    level=logging.ERROR,
                    msg="Tenant guard: SELECT no-tenant requiere filtro empresa_id explícito",
                    table_names=table_names,
                    extra={"scoped_used": scoped_used},
                )
                raise RuntimeError(
                    f"Tenant context missing for ORM execution (no-tenant SELECT on tables={scoped_used} requires empresa_id filter)"
                )
            return
        _log_tenant_debug(
            level=logging.ERROR,
            msg="Tenant guard: falta contexto de empresa",
            table_names=table_names,
        )
        raise RuntimeError("Tenant context missing for ORM execution")

    if execute_state.is_select and not session.info.get("bypass_app_tenant_filter", False):
        rls_debug = os.getenv("RLS_DEBUG", "0") in ("1", "true", "TRUE", "yes", "YES")
        table_names: set[str] = set()
        try:
            _walk_statement(execute_state.statement, table_names)
        except Exception:
            table_names = set()
        applied_count = 0
        applied_sample: list[str] = []
        tenant_param = bindparam("_erp3_tenant_id", value=str(tenant), type_=String)
        try:
            for mapper in Base.registry.mappers:
                cls = mapper.class_
                if hasattr(cls, "empresa_id"):
                    execute_state.statement = execute_state.statement.options(
                        with_loader_criteria(
                            cls,
                            lambda obj: cast(obj.empresa_id, String) == tenant_param,
                            include_aliases=True,
                            track_closure_variables=False,
                        )
                    )
                    applied_count += 1
                    if len(applied_sample) < 30:
                        applied_sample.append(getattr(cls, "__tablename__", cls.__name__))
            _log_tenant_debug(
                level=logging.INFO,
                msg="Tenant filters: inyección ORM activa",
                table_names=table_names,
                extra={
                    "applied_mappers_count": applied_count,
                    "applied_mappers_sample": applied_sample,
                },
            )
            if rls_debug and applied_count:
                logging.getLogger("erp3.rls").info(
                    f"RLS inject: empresa_id={tenant} on tables={applied_sample}"
                )
        except Exception:
            raise


@_sa_event.listens_for(SASession, "after_begin")
def _set_current_user_id_session_var(
    session: SASession, transaction: Any, connection: Any
) -> None:
    if connection.dialect.name != "postgresql":
        return
    allow_no_tenant = bool(session.info.get("allow_no_tenant", False))
    connection.execute(
        text("SELECT set_config('app.allow_no_tenant', :val, true)"),
        {"val": "1" if allow_no_tenant else "0"},
    )
    empresa_id = session.info.get("empresa_id")
    if empresa_id:
        connection.execute(
            text("SELECT set_config('app.current_empresa_id', :eid, true)"),
            {"eid": str(empresa_id)},
        )
    elif allow_no_tenant:
        connection.execute(text("SELECT set_config('app.current_empresa_id', '', true)"))
    else:
        raise PermissionError("Acceso a base de datos sin contexto de empresa activo.")
    user_id = session.info.get("current_user_id") or session.info.get("user_id")
    if not user_id:
        return
    connection.execute(
        text("SELECT set_config('app.current_user_id', :uid, true)"),
        {"uid": str(user_id)},
    )


@_sa_event.listens_for(SASession, "before_flush")
def _validate_tenant_on_flush(session: SASession, flush_context: Any, instances: Any) -> None:
    try:
        bind = session.get_bind() if hasattr(session, "get_bind") else session.bind
        if bind is not None:
            dialect_name = getattr(bind, "dialect", None)
            if dialect_name:
                name = getattr(dialect_name, "name", None)
                if name == "sqlite":
                    return
    except Exception:
        pass
    if session.info.get("allow_no_tenant", False):
        return
    session.info["force_writer"] = True
    tenant = session.info.get("empresa_id", None)
    if tenant is None:
        raise RuntimeError("Tenant context missing on flush")

    new_empresas_ids = {
        getattr(obj, "id", None)
        for obj in session.new
        if getattr(obj, "__tablename__", None) == "empresas"
    }

    def _check(obj: Any) -> None:
        if hasattr(obj, "empresa_id"):
            eid = getattr(obj, "empresa_id", None)
            if eid is None:
                setattr(obj, "empresa_id", tenant)
            elif eid != tenant and eid not in new_empresas_ids:
                raise RuntimeError("Tenant isolation violation: empresa_id mismatch")

    for obj in session.new:
        _check(obj)
    for obj in session.dirty:
        _check(obj)


engine = writer_engine
