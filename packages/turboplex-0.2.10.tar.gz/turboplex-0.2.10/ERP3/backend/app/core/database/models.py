from sqlalchemy import String, Text, Integer
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import DateTime, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
from typing import Union
from datetime import datetime


JsonValue = Union[dict[str, object], list[object], str, int, float, bool, None]


class Setting(Base):
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String, primary_key=True, index=True)
    value: Mapped[JsonValue] = mapped_column(JSONB, nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)


class RutCache(Base):
    __tablename__ = "rut_cache"

    rut_normalized: Mapped[str] = mapped_column(String, primary_key=True, index=True)
    razon_social: Mapped[str | None] = mapped_column(Text, nullable=True)
    actividades_economicas: Mapped[JsonValue | None] = mapped_column(JSONB, nullable=True)
    domicilios: Mapped[JsonValue | None] = mapped_column(JSONB, nullable=True)
    presenta_inicio: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    fecha_inicio: Mapped[str | None] = mapped_column(String, nullable=True)
    es_pyme: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    web_facturacion: Mapped[str | None] = mapped_column(String, nullable=True)
    provider_name: Mapped[str | None] = mapped_column(String, nullable=True)
    last_refreshed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    ttl_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class RutLookupLog(Base):
    __tablename__ = "rut_lookup_log"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    rut_normalized: Mapped[str] = mapped_column(String, index=True, nullable=False)
    user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    empresa_id: Mapped[str | None] = mapped_column(String, nullable=True)
    source: Mapped[str] = mapped_column(String, nullable=False)  # cache | provider | invalid_dv
    provider_name: Mapped[str | None] = mapped_column(String, nullable=True)
    http_status: Mapped[int | None] = mapped_column(String, nullable=True)
    success: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)


class RutProviderConfig(Base):
    __tablename__ = "rut_provider_config"

    empresa_id: Mapped[str] = mapped_column(String, primary_key=True, index=True)
    provider_type: Mapped[str] = mapped_column(String, nullable=False)
    auth_params: Mapped[JsonValue] = mapped_column(JSONB, nullable=False)
    ttl_days: Mapped[int] = mapped_column(Integer, nullable=False, default=30)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, default=datetime.utcnow)


class RevokedToken(Base):
    __tablename__ = "revoked_tokens"

    jti: Mapped[str] = mapped_column(String, primary_key=True)
    audience: Mapped[str] = mapped_column(String, nullable=False)
    subject: Mapped[str | None] = mapped_column(String, nullable=True)
    empresa_id: Mapped[str | None] = mapped_column(String, nullable=True)
    cliente_id: Mapped[str | None] = mapped_column(String, nullable=True)
    revoked_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
