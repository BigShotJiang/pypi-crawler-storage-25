from collections.abc import Iterator

from sqlalchemy.orm import Session as SASession

from . import database as _database
from .custom_types import GUID

Base = _database.Base
TestAwareSession = _database.TestAwareSession
engine = _database.engine
reader_engine = _database.reader_engine
writer_engine = _database.writer_engine
audit_engine = _database.audit_engine
validate_database_connections = _database.validate_database_connections

SessionLocal = _database.SessionLocal


def get_db() -> Iterator[SASession]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


__all__ = [
    "GUID",
    "Base",
    "SessionLocal",
    "TestAwareSession",
    "engine",
    "reader_engine",
    "writer_engine",
    "audit_engine",
    "validate_database_connections",
    "get_db",
]
