from app.core.database.custom_types import GUID

__all__ = ["GUID"]
