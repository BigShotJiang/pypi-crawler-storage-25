import json
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import event, inspect
from sqlalchemy.orm import Session
from app.core.database import Base, SessionLocal, audit_engine, writer_engine
from app.core.infrastructure.serializer import safe_json_dumps
from app.core_modules.sistema.models import AuditLog
import app.core.infrastructure.queue as queue_module
from app.tasks.audit_sync import sync_audit_log_to_external
import logging

logger = logging.getLogger(__name__)


def get_current_user_id(session: Any) -> Optional[Any]:
    """
    Intenta obtener el ID del usuario actual desde la sesión.
    Esto requiere que el endpoint inyecte 'user_id' en session.info['user_id'].
    """
    if hasattr(session, "info") and "user_id" in session.info:
        return session.info["user_id"]
    return None


def json_serializer(obj: Any) -> str:
    if isinstance(obj, datetime):
        return obj.isoformat()
    return str(obj)


def create_audit_entry(mapper: Any, connection: Any, target: Any, action: str) -> None:
    # Evitar auditar la tabla de auditoría
    if isinstance(target, AuditLog):
        return

    session = Session.object_session(target)
    user_id = get_current_user_id(session)

    # Identify record ID
    pk = list(mapper.primary_key)[0]
    record_id = str(getattr(target, pk.name))

    changes = {}

    if action == "INSERT":
        for attr in mapper.column_attrs:
            if hasattr(target, attr.key):
                new_val = getattr(target, attr.key)
                if new_val is not None:
                    changes[attr.key] = [None, new_val]

    elif action == "UPDATE":
        state = inspect(target)
        for attr in mapper.column_attrs:
            hist = state.get_history(attr.key, True)
            if hist.has_changes():
                old_val = hist.deleted[0] if hist.deleted else None
                new_val = hist.added[0] if hist.added else None
                changes[attr.key] = [old_val, new_val]

        # Detect Soft Delete
        if "is_deleted" in changes:
            old_del, new_del = changes["is_deleted"]
            if not old_del and new_del:
                action = "DELETE (SOFT)"
            elif old_del and not new_del:
                action = "RESTORE"

    elif action == "DELETE":
        state = inspect(target)
        for attr in mapper.column_attrs:
            if hasattr(target, attr.key):
                val = getattr(target, attr.key)
                changes[attr.key] = [val, None]

    if not changes and action == "UPDATE":
        return

    # Insert directly via connection to avoid Session loop
    # We use the Core table object to do a raw insert
    audit_table = AuditLog.__table__

    # Prepare data
    audit_data = {
        "resource": f"{target.__tablename__}:{record_id}",
        "action": action,
        "changes": json.loads(safe_json_dumps(changes)),
        "actor_id": user_id,
        "created_at": datetime.utcnow(),
        "severity": "INFO",
    }

    connection.execute(audit_table.insert().values(**audit_data))

    # Encolar replicación asíncrona (Streaming Replication)
    # Guardamos en session.info para encolar SOLO si el commit es exitoso
    if session:
        if not hasattr(session, "info"):
            session.info = {}

        pending = session.info.get("pending_audit_logs", [])
        pending.append(audit_data)
        session.info["pending_audit_logs"] = pending


def _log_async_protection_paused(reason: str) -> None:
    """
    Registra un evento de sistema cuando falla la cola de Redis y
    se desactiva la protección asíncrona de replicación de auditoría.
    """
    db = SessionLocal()
    try:
        entry = AuditLog(
            actor_id=None,
            impersonated_user_id=None,
            action="AUDIT_ASYNC_PROTECTION_PAUSED",
            resource="SYSTEM:ASYNC_PROTECTION",
            severity="CRITICAL",
            changes={"reason": str(reason)},
            ip_address=None,
        )
        db.add(entry)
        db.commit()
        logger.critical(
            "[AUDIT] Protección asíncrona pausada por fallo en Redis/task queue"
        )
    except Exception as e:
        db.rollback()
        logger.error(
            f"[AUDIT] Error registrando evento de sistema AUDIT_ASYNC_PROTECTION_PAUSED: {e}"
        )
    finally:
        db.close()


def register_audit_listeners() -> None:
    """
    Registra los listeners de SQLAlchemy para auditoría.
    """

    def _try_write_audit_logs_to_audit_db(logs: list[dict[str, Any]]) -> None:
        try:
            if str(getattr(audit_engine, "url", "")) == str(getattr(writer_engine, "url", "")):
                return
        except Exception:
            return

        try:
            with audit_engine.begin() as conn:
                for log_data in logs:
                    conn.execute(
                        AuditLog.__table__.insert().values(
                            actor_id=log_data.get("actor_id"),
                            impersonated_user_id=log_data.get("impersonated_user_id"),
                            action=log_data.get("action"),
                            resource=log_data.get("resource"),
                            severity=log_data.get("severity", "INFO"),
                            changes=log_data.get("changes"),
                            ip_address=log_data.get("ip_address"),
                            created_at=log_data.get("created_at") or datetime.utcnow(),
                        )
                    )
        except Exception as exc:
            logger.warning("DB_AUDIT no disponible. Silent fallback: %s", exc)

    @event.listens_for(Session, "after_commit")
    def after_commit(session):
        """
        Listener que se ejecuta después de un commit exitoso.
        Encola las tareas de replicación de logs de auditoría.
        """
        if hasattr(session, "info") and "pending_audit_logs" in session.info:
            logs = session.info["pending_audit_logs"]
            if logs:
                _try_write_audit_logs_to_audit_db(logs)
                if queue_module.task_queue:
                    count = 0
                    for log_data in logs:
                        try:
                            queue_module.task_queue.enqueue(
                                sync_audit_log_to_external, log_data
                            )
                            count += 1
                        except Exception as e:
                            logger.error(f"Error enqueuing audit log: {e}")
                            queue_module.task_queue = None
                            _log_async_protection_paused(str(e))
                            break
                    if count > 0:
                        logger.info(f"Enqueued {count} audit logs for replication.")
                else:
                    logger.warning(
                        "Task queue not available. Skipping audit replication."
                    )

            # Limpiar la lista para evitar duplicados en commits subsecuentes de la misma sesión
            session.info["pending_audit_logs"] = []

    @event.listens_for(Base, "after_insert", propagate=True)
    def after_insert(mapper, connection, target):
        create_audit_entry(mapper, connection, target, "INSERT")

    @event.listens_for(Base, "after_update", propagate=True)
    def after_update(mapper, connection, target):
        create_audit_entry(mapper, connection, target, "UPDATE")

    @event.listens_for(Base, "after_delete", propagate=True)
    def after_delete(mapper, connection, target):
        create_audit_entry(mapper, connection, target, "DELETE")
