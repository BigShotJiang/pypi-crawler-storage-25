import uuid
from datetime import datetime, timezone, timedelta


def get_timestamp_from_uuidv7(uuid_obj: uuid.UUID) -> datetime:
    ts_ms = uuid_obj.int >> 80
    return datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)


def get_uuidv7_range_for_date(target_date: datetime) -> tuple[uuid.UUID, uuid.UUID]:
    if target_date.tzinfo is None:
        target_date = target_date.replace(tzinfo=timezone.utc)

    start_of_day = target_date.replace(hour=0, minute=0, second=0, microsecond=0)
    end_of_day = start_of_day + timedelta(days=1) - timedelta(microseconds=1)

    ts_start = int(start_of_day.timestamp() * 1000)
    ts_end = int(end_of_day.timestamp() * 1000)

    min_uuid_int = (ts_start << 80) | (7 << 76) | (2 << 62)

    max_rand_a = 0xFFF
    max_rand_b = (1 << 62) - 1

    max_uuid_int = (
        (ts_end << 80) | (7 << 76) | (max_rand_a << 64) | (2 << 62) | max_rand_b
    )

    return uuid.UUID(int=min_uuid_int), uuid.UUID(int=max_uuid_int)
