from sqlalchemy import Column, DateTime, Boolean
from sqlalchemy.sql import func
from datetime import datetime
from sqlalchemy.orm import Session


class SoftDeleteMixin:
    is_deleted = Column(Boolean, default=False, nullable=False, index=True)
    deleted_at = Column(DateTime, nullable=True)

    def soft_delete(self, db: Session) -> None:
        self.is_deleted = True
        self.deleted_at = datetime.utcnow()
        db.add(self)

    def restore(self, db: Session) -> None:
        self.is_deleted = False
        self.deleted_at = None
        db.add(self)


class TimestampMixin:
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
