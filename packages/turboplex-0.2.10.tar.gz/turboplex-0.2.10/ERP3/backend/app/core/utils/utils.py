import re
from urllib.parse import urlparse
from decimal import Decimal, ROUND_HALF_UP


def aplicar_ley_redondeo(monto: float) -> int:
    """
    Aplica la Ley de Redondeo (Chile) para pagos en efectivo.
    Regla:
    - Terminaciones 1, 2, 3, 4, 5 -> Redondea hacia abajo (a 0)
    - Terminaciones 6, 7, 8, 9    -> Redondea hacia arriba (a 10)

    El monto primero se redondea al entero más cercano (ROUND_HALF_UP)
    antes de aplicar la lógica de terminación.
    """
    if monto is None:
        return 0

    val = Decimal(str(monto))
    entero = int(val.quantize(Decimal("1"), rounding=ROUND_HALF_UP))

    resto = entero % 10

    if resto == 0:
        return entero

    if 1 <= resto <= 5:
        return entero - resto
    return entero + (10 - resto)


def clean_rut(rut: str) -> str:
    if not rut:
        return ""
    cleaned = re.sub(r"[^0-9kK]", "", rut)
    return cleaned.upper()


def validate_rut(rut: str) -> bool:
    if not rut:
        return False
    raw = re.sub(r"\s+", "", rut)
    if not re.match(r"^\d[\d.]*-[\dkK]$", raw):
        return False
    rut = clean_rut(rut)
    if not rut or len(rut) < 2:
        return False

    body = rut[:-1]
    dv = rut[-1]

    if not body.isdigit():
        return False

    suma = 0
    multiplo = 2

    for char in reversed(body):
        suma += int(char) * multiplo
        multiplo += 1
        if multiplo > 7:
            multiplo = 2

    expected_dv_int = 11 - (suma % 11)

    if expected_dv_int == 11:
        expected_dv = "0"
    elif expected_dv_int == 10:
        expected_dv = "K"
    else:
        expected_dv = str(expected_dv_int)

    return dv == expected_dv


def validate_url_format(url: str) -> bool:
    if not url:
        return False
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc]) and result.scheme in [
            "http",
            "https",
        ]
    except Exception:
        return False
