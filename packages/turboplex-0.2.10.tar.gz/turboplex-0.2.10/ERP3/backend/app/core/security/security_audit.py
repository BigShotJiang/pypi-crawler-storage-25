import logging
from typing import Any, Dict, Optional
from uuid import UUID

from fastapi import Request
from sqlalchemy.orm import Session

from app.core_modules.sistema import models

logger = logging.getLogger(__name__)


class SecurityAudit:
    @staticmethod
    def _normalize_changes(value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, dict):
            return {k: SecurityAudit._normalize_changes(v) for k, v in value.items()}
        if isinstance(value, list):
            return [SecurityAudit._normalize_changes(v) for v in value]
        if isinstance(value, UUID):
            return str(value)
        return value

    @staticmethod
    def log(
        db: Session,
        actor_id: UUID,
        action: str,
        resource: str,
        severity: str = "INFO",
        changes: Optional[Dict[str, Any]] = None,
        impersonated_user_id: Optional[UUID] = None,
        request: Request | None = None,
    ) -> models.AuditLog:
        ip_address = None
        if request:
            ip_address = request.client.host

        if action == "LOGIN_AS" and not impersonated_user_id:
            raise ValueError(
                "impersonated_user_id is mandatory for LOGIN_AS action"
            )

        normalized_changes = SecurityAudit._normalize_changes(changes)

        audit_entry = models.AuditLog(
            actor_id=actor_id,
            impersonated_user_id=impersonated_user_id,
            action=action,
            resource=resource,
            severity=severity,
            changes=normalized_changes,
            ip_address=ip_address,
        )

        db.add(audit_entry)
        db.commit()
        db.refresh(audit_entry)

        if severity == "CRITICAL":
            SecurityAudit._trigger_critical_alert(audit_entry)

        return audit_entry

    @staticmethod
    def _trigger_critical_alert(entry: models.AuditLog) -> None:
        incident_report = {
            "timestamp": str(entry.created_at) if entry.created_at else "Now",
            "severity": "CRITICAL",
            "type": "SECURITY_INCIDENT",
            "action": entry.action,
            "resource": entry.resource,
            "actor_id": str(entry.actor_id),
            "ip_address": entry.ip_address,
            "details": entry.changes,
            "legal_context": "Ley 21.663 Art. 4 - Notificación Obligatoria de Incidentes",
        }

        logger.critical(
            f"🚨 [LEY 21.663] INCIDENTE CRÍTICO DETECTADO: {incident_report}"
        )


security_audit = SecurityAudit()
