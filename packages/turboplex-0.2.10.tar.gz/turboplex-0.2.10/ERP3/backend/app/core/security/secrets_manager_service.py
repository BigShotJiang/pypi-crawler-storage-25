import base64
from typing import Optional, cast
from uuid import UUID

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core_modules.sistema.models import AuditSeverity, SystemSecret

from .security_audit import security_audit


class SecretsManagerService:
    def __init__(self) -> None:
        self._fernet = self._get_fernet()

    def _get_fernet(self) -> Fernet:
        salt = b"erp3_system_secrets_salt_v1"
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(settings.SECRET_KEY.encode()))
        return Fernet(key)

    def rotate_secret(
        self, db: Session, key: str, new_value: str, actor_id: UUID
    ) -> SystemSecret:
        encrypted_value_bytes = cast(bytes, self._fernet.encrypt(new_value.encode()))
        encrypted_value = encrypted_value_bytes.decode()

        secret = db.query(SystemSecret).filter(SystemSecret.key == key).first()
        if not secret:
            secret = SystemSecret(key=key)
            db.add(secret)

        secret.encrypted_value = encrypted_value
        secret.updated_by = actor_id
        db.commit()
        db.refresh(secret)

        security_audit.log(
            db=db,
            actor_id=actor_id,
            action="ROTATE_SECRET",
            resource=f"SystemSecret:{key}",
            severity=AuditSeverity.CRITICAL,
            changes={"key": key, "status": "ROTATED"},
        )

        return secret

    def get_secret(
        self, db: Session, key: str, actor_id: Optional[UUID] = None
    ) -> Optional[str]:
        secret = db.query(SystemSecret).filter(SystemSecret.key == key).first()
        if not secret:
            return None

        try:
            decrypted_value_bytes = cast(
                bytes, self._fernet.decrypt(secret.encrypted_value.encode())
            )
            decrypted_value = decrypted_value_bytes.decode()
        except Exception as exc:
            raise HTTPException(status_code=500, detail="Error decrypting secret") from exc

        if actor_id:
            security_audit.log(
                db=db,
                actor_id=actor_id,
                action="READ_SECRET",
                resource=f"SystemSecret:{key}",
                severity=AuditSeverity.CRITICAL,
                changes={"key": key, "status": "ACCESSED"},
            )

        return decrypted_value


secrets_manager = SecretsManagerService()
