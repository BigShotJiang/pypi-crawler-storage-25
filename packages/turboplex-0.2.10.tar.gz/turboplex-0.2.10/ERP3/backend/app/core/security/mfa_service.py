import secrets
import string
from typing import List, cast

import pyotp


class MFAService:
    @staticmethod
    def generate_secret() -> str:
        return cast(str, pyotp.random_base32())

    @staticmethod
    def get_provisioning_uri(
        secret: str, email: str, issuer_name: str = "ERP3"
    ) -> str:
        uri = pyotp.totp.TOTP(secret).provisioning_uri(name=email, issuer_name=issuer_name)
        return cast(str, uri)

    @staticmethod
    def verify_totp(secret: str, code: str) -> bool:
        totp = pyotp.TOTP(secret)
        return cast(bool, totp.verify(code))

    @staticmethod
    def generate_recovery_codes(
        count: int = 10, length: int = 10
    ) -> List[str]:
        alphabet = string.ascii_letters + string.digits
        codes = []
        for _ in range(count):
            code = "".join(secrets.choice(alphabet) for _ in range(length))
            codes.append(code.upper())
        return codes
