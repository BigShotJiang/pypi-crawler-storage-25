import base64
from typing import cast

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from app.core.config import settings


class EncryptionService:
    _fernet = None

    @classmethod
    def get_fernet(cls) -> Fernet:
        if cls._fernet is None:
            salt = b"erp3_user_data_encryption_salt_v1"
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(settings.SECRET_KEY.encode()))
            cls._fernet = Fernet(key)
        return cls._fernet

    @classmethod
    def encrypt(cls, data: str) -> str | None:
        if not data:
            return None
        encrypted = cast(bytes, cls.get_fernet().encrypt(data.encode()))
        return encrypted.decode()

    @classmethod
    def decrypt(cls, token: str) -> str | None:
        if not token:
            return None
        try:
            decrypted = cast(bytes, cls.get_fernet().decrypt(token.encode()))
            return decrypted.decode()
        except Exception:
            return None
