"""
Excepciones personalizadas para ERP3
Proporciona excepciones con estructura estandarizada
"""

from typing import Any, Dict, Optional
from fastapi import HTTPException, status
from uuid import UUID


class ERPException(HTTPException):
    """Excepción base para el sistema ERP"""

    def __init__(
        self,
        status_code: int,
        error_code: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        super().__init__(status_code=status_code, detail=message)


class ValidationError(ERPException):
    """Error de validación de datos"""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            error_code="VALIDATION_ERROR",
            message=message,
            details=details,
        )


class AuthenticationError(ERPException):
    """Error de autenticación"""

    def __init__(self, message: str = "No autenticado"):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            error_code="AUTHENTICATION_ERROR",
            message=message,
        )


class AuthorizationError(ERPException):
    """Error de autorización/permisos"""

    def __init__(
        self, message: str = "No autorizado", details: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            error_code="AUTHORIZATION_ERROR",
            message=message,
            details=details,
        )


class ResourceNotFoundError(ERPException):
    """Recurso no encontrado"""

    def __init__(self, resource: str, resource_id: Any):
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="RESOURCE_NOT_FOUND",
            message=f"{resource} no encontrado",
            details={"resource": resource, "id": resource_id},
        )


class BusinessRuleError(ERPException):
    """Error de regla de negocio"""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            error_code="BUSINESS_RULE_ERROR",
            message=message,
            details=details,
        )


class InsufficientStock(BusinessRuleError):
    def __init__(self, message: str = "No hay stock suficiente.", details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, details=details)


class PeriodoBloqueadoError(BusinessRuleError):
    def __init__(
        self,
        message: str = "Operación denegada: el periodo contable se encuentra cerrado.",
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message=message, details=details)


class ModuleNotActiveError(ERPException):
    """Módulo no activo para la empresa"""

    def __init__(self, module_code: str):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            error_code="MODULE_NOT_ACTIVE",
            message=f"Módulo {module_code} no está activo para esta empresa",
            details={"module_code": module_code},
        )


class CompanyNotActiveError(ERPException):
    """Empresa no activa"""

    def __init__(self, empresa_id: UUID):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            error_code="COMPANY_NOT_ACTIVE",
            message="La empresa no está activa",
            details={"empresa_id": empresa_id},
        )


class UserNotInCompanyError(ERPException):
    """Usuario no pertenece a la empresa"""

    def __init__(self, user_id: UUID, empresa_id: UUID):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            error_code="USER_NOT_IN_COMPANY",
            message="El usuario no pertenece a esta empresa",
            details={"user_id": user_id, "empresa_id": empresa_id},
        )


class DatabaseError(ERPException):
    """Error de base de datos"""

    def __init__(self, message: str = "Error de base de datos"):
        super().__init__(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="DATABASE_ERROR",
            message=message,
        )


class ExternalServiceError(ERPException):
    """Error en servicio externo (SII, Email, etc)"""

    def __init__(self, service: str, message: str):
        super().__init__(
            status_code=status.HTTP_502_BAD_GATEWAY,
            error_code="EXTERNAL_SERVICE_ERROR",
            message=f"Error en servicio {service}: {message}",
            details={"service": service},
        )


class RateLimitExceededError(ERPException):
    """Límite de tasa excedido"""

    def __init__(self, retry_after: int):
        super().__init__(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            error_code="RATE_LIMIT_EXCEEDED",
            message="Límite de peticiones excedido",
            details={"retry_after": retry_after},
        )
