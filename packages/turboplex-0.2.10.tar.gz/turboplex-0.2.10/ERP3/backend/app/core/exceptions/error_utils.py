from typing import Any, Dict, Optional, Tuple
from datetime import datetime
from uuid import uuid4
from time import perf_counter
import logging
import json
from fastapi import HTTPException, status
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import TimeoutError as SATimeoutError, OperationalError
from app.core.infrastructure.api_schemas import BaseResponse, ErrorPayload, MetaPayload
from app.core.exceptions.exceptions import ERPException, BusinessRuleError
from app.core.database import SessionLocal
from app.core_modules.sistema.models import BackgroundJobLog

logger = logging.getLogger("background_tasks")


def compute_duration_ms(start_time: Optional[float]) -> Optional[int]:
    if not isinstance(start_time, (int, float)):
        return None
    try:
        return int((perf_counter() - start_time) * 1000)
    except Exception:
        return None


def map_business_error_code(exc: ERPException) -> str:
    if isinstance(exc, BusinessRuleError):
        msg = exc.message or ""
        if "Límite de crédito excedido" in msg:
            return "CREDIT_LIMIT_EXCEEDED"
        if "No hay stock suficiente" in msg:
            return "STOCK_UNAVAILABLE"
        if "BLOQUEO DE CALIDAD" in msg:
            return "QUALITY_BLOCK"
        return "BUSINESS_RULE_ERROR"
    return exc.error_code


def build_erp_error_envelope(
    exc: ERPException,
    path: str,
    start_time: Optional[float] = None,
    duration_ms: Optional[int] = None,
) -> Tuple[int, BaseResponse[Dict[str, Any]]]:
    request_id = str(uuid4())
    final_duration = duration_ms if duration_ms is not None else compute_duration_ms(
        start_time
    )
    code = map_business_error_code(exc)
    details: Dict[str, Any] = {
        **(exc.details or {}),
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "path": path,
    }
    error = ErrorPayload(code=code, message=exc.message, details=details)
    meta = MetaPayload(request_id=request_id, duration_ms=final_duration)
    payload = BaseResponse[Dict[str, Any]](
        success=False,
        data=None,
        error=error,
        meta=meta,
    )
    return exc.status_code, payload


def build_http_error_envelope(
    exc: HTTPException,
    path: str,
    start_time: Optional[float],
) -> Tuple[int, BaseResponse[Dict[str, Any]]]:
    request_id = str(uuid4())
    duration_ms = compute_duration_ms(start_time)
    error = ErrorPayload(
        code="HTTP_ERROR",
        message=str(exc.detail) if exc.detail else "HTTP error",
        details={
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "path": path,
            "status_code": exc.status_code,
        },
    )
    meta = MetaPayload(request_id=request_id, duration_ms=duration_ms)
    payload = BaseResponse[Dict[str, Any]](
        success=False,
        data=None,
        error=error,
        meta=meta,
    )
    return exc.status_code, payload


def build_validation_error_envelope(
    exc: RequestValidationError,
    path: str,
    start_time: Optional[float],
) -> Tuple[int, BaseResponse[Dict[str, Any]]]:
    request_id = str(uuid4())
    duration_ms = compute_duration_ms(start_time)
    errors = []
    for err in exc.errors():
        item = dict(err)
        ctx = item.get("ctx")
        if isinstance(ctx, dict):
            safe_ctx = {}
            for key, value in ctx.items():
                try:
                    json.dumps(value)
                    safe_ctx[key] = value
                except TypeError:
                    safe_ctx[key] = str(value)
            item["ctx"] = safe_ctx
        errors.append(item)
    error = ErrorPayload(
        code="VALIDATION_ERROR",
        message="Error de validación",
        details={
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "path": path,
            "errors": errors,
        },
    )
    meta = MetaPayload(request_id=request_id, duration_ms=duration_ms)
    payload = BaseResponse[Dict[str, Any]](
        success=False,
        data=None,
        error=error,
        meta=meta,
    )
    return status.HTTP_422_UNPROCESSABLE_ENTITY, payload


def build_generic_error_envelope(
    exc: Exception,
    path: str,
    start_time: Optional[float],
) -> Tuple[int, BaseResponse[Dict[str, Any]]]:
    request_id = str(uuid4())
    duration_ms = compute_duration_ms(start_time)
    details: Dict[str, Any] = {}
    details["type"] = type(exc).__name__
    details["timestamp"] = datetime.utcnow().isoformat() + "Z"
    details["path"] = path
    code = "INTERNAL_SERVER_ERROR"
    message = "Error interno del servidor"

    if isinstance(exc, SATimeoutError):
        code = "DATABASE_TIMEOUT"
        message = "La base de datos no respondió a tiempo"
    elif isinstance(exc, OperationalError):
        err_str = str(exc).lower()
        if "timeout" in err_str or "statement timeout" in err_str:
            code = "DATABASE_TIMEOUT"
            message = "La base de datos no respondió a tiempo"
        else:
            code = "DATABASE_ERROR"
            message = "Error de base de datos"

    error = ErrorPayload(code=code, message=message, details=details)
    meta = MetaPayload(request_id=request_id, duration_ms=duration_ms)
    payload = BaseResponse[Dict[str, Any]](
        success=False,
        data=None,
        error=error,
        meta=meta,
    )
    logger.error(
        {
            "kind": "unhandled_exception",
            "path": path,
            "request_id": request_id,
            "duration_ms": duration_ms,
            "error": error.model_dump(),
        }
    )
    return status.HTTP_500_INTERNAL_SERVER_ERROR, payload


def build_background_error_envelope(
    exc: Exception,
    task_name: str,
    duration_ms: int,
) -> BaseResponse[Dict[str, Any]]:
    path = f"background:{task_name}"
    if isinstance(exc, ERPException):
        _, envelope = build_erp_error_envelope(
            exc=exc,
            path=path,
            start_time=None,
            duration_ms=duration_ms,
        )
        return envelope
    _, envelope = build_generic_error_envelope(
        exc=exc,
        path=path,
        start_time=None,
    )
    return envelope


def wrap_background_task(
    func: Any,
    task_name: Optional[str] = None,
) -> Any:
    name = task_name or getattr(func, "__name__", "background_task")

    def wrapper(*args: Any, **kwargs: Any) -> None:
        request_id = str(uuid4())
        start = perf_counter()
        status_value = "SUCCESS"
        duration_ms: Optional[int] = None
        envelope: Optional[BaseResponse[Dict[str, Any]]] = None
        try:
            func(*args, **kwargs)
            duration_ms = int((perf_counter() - start) * 1000)
            status_value = "SUCCESS"
            logger.info(
                {
                    "kind": "background_task",
                    "task": name,
                    "request_id": request_id,
                    "duration_ms": duration_ms,
                    "success": True,
                }
            )
        except Exception as exc:
            duration_ms = int((perf_counter() - start) * 1000)
            status_value = "ERROR"
            envelope = build_background_error_envelope(
                exc=exc,
                task_name=name,
                duration_ms=duration_ms,
            )
            logger.error(
                {
                    "kind": "background_task",
                    "task": name,
                    "request_id": request_id,
                    "duration_ms": duration_ms,
                    "success": False,
                    "error": envelope.error.model_dump()
                    if envelope.error
                    else None,
                    "meta": envelope.meta.model_dump() if envelope.meta else None,
                }
            )
        try:
            db = SessionLocal()
            db.info["allow_no_tenant"] = True
            try:
                log = BackgroundJobLog(
                    task_name=name,
                    status=status_value,
                    request_id=request_id,
                    duration_ms=duration_ms,
                    error_code=envelope.error.code
                    if envelope and envelope.error
                    else None,
                    error_detail=envelope.error.details
                    if envelope and envelope.error
                    else None,
                )
                db.add(log)
                db.commit()

                if status_value == "ERROR":
                    from datetime import timedelta, timezone

                    start_window = datetime.now(timezone.utc) - timedelta(minutes=15)
                    fail_count = (
                        db.query(BackgroundJobLog)
                        .filter(
                            BackgroundJobLog.task_name == name,
                            BackgroundJobLog.status == "ERROR",
                            BackgroundJobLog.created_at >= start_window,
                        )
                        .count()
                    )
                    if fail_count >= 5:
                        logger.critical(
                            {
                                "kind": "SYSTEM_ALERT",
                                "alert_type": "BACKGROUND_JOB_SPIKE",
                                "message": f"High failure rate for task '{name}': {fail_count} failures in last 15m",
                                "task": name,
                                "fail_count": fail_count,
                                "window_minutes": 15,
                            }
                        )

            except Exception as e:
                db.rollback()
                logger.error(
                    {
                        "kind": "background_task_log_error",
                        "task": name,
                        "request_id": request_id,
                        "error": str(e),
                    }
                )
            finally:
                db.close()
        except Exception as e:
            logger.error(
                {
                    "kind": "background_task_log_error",
                    "task": name,
                    "request_id": request_id,
                    "error": str(e),
                }
            )

    return wrapper
