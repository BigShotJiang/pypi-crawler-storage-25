import json
import logging
import os
from typing import Any, Optional
from uuid import UUID

from fastapi import BackgroundTasks
from sqlalchemy.inspection import inspect
from sqlalchemy.orm import Session

from app.core.infrastructure.serializer import safe_json_dumps
from app.core_modules.sistema.models import PapeleraReciclaje


logger = logging.getLogger(__name__)


def replicar_a_espejo(sql: str, params: tuple[Any, ...]) -> None:
    mirror_url = os.getenv("MIRROR_DATABASE_URL")
    if not mirror_url:
        return
    try:
        import psycopg2

        conn = psycopg2.connect(mirror_url)
        cursor = conn.cursor()
        cursor.execute(sql, params)
        conn.commit()
        cursor.close()
        conn.close()
        logger.info("[MIRROR] Replicación exitosa a DB espejo.")
    except Exception as e:
        logger.error(f"[MIRROR] Error replicando borrado: {e}")


def archivar_y_borrar(
    db: Session,
    objeto: Any,
    background_tasks: Optional[BackgroundTasks] = None,
    ejecutado_por_id: Optional[UUID] = None,
    empresa_id: Optional[UUID] = None,
    company_code: Optional[str] = None,
) -> None:
    try:
        mapper = inspect(objeto.__class__)
        tabla_origen = mapper.persist_selectable.name
        data = {c.key: getattr(objeto, c.key) for c in mapper.column_attrs}
        payload_json = json.loads(safe_json_dumps(data))

        papelera = PapeleraReciclaje(
            tabla_origen=tabla_origen,
            empresa_id=empresa_id,
            company_code=company_code,
            ejecutado_por_id=ejecutado_por_id,
            payload=payload_json,
        )
        db.add(papelera)
        db.flush()
        db.delete(objeto)
        db.commit()

        if os.getenv("MIRROR_DATABASE_URL") and background_tasks:
            sql = """
                INSERT INTO papelera_reciclaje 
                (tabla_origen, empresa_id, company_code, ejecutado_por_id, payload, created_at) 
                VALUES (%s, %s, %s, %s, %s, NOW())
            """
            payload_str = safe_json_dumps(payload_json)
            params = (
                tabla_origen,
                empresa_id,
                company_code,
                ejecutado_por_id,
                payload_str,
            )
            background_tasks.add_task(replicar_a_espejo, sql, params)
    except Exception as e:
        db.rollback()
        raise e
