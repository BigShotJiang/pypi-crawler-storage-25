from __future__ import annotations

from typing import Any, cast
from uuid import UUID

import uuid6
from sqlalchemy import select
from sqlalchemy.orm import Session


def apply_stock_updates(
    *,
    db: Session,
    empresa_id: UUID,
    import_run_id: UUID,
    default_bodega_id: UUID,
    existing_by_sku: dict[str, Any],
    desired_by_sku_bodega_variant: dict[tuple[str, str, str], dict[str, Any]],
    bodegas_by_codigo_externo: dict[str, Any],
    variant_id_by_key_seed: dict[tuple[UUID, str], UUID] | None = None,
) -> tuple[
    int,
    int,
    dict[str, int],
    dict[str, int],
    list[dict[str, Any]],
]:
    from app.core_modules.inventario.stock.models import Inventario, ProductVariant
    from app.core_modules.inventario.stock.services import InventoryService
    from sqlalchemy.dialects.postgresql import insert as pg_insert

    errors: list[dict[str, Any]] = []
    movements = 0
    stock_updates = 0
    movements_by_bodega_codigo: dict[str, int] = {}
    stock_updates_by_bodega_codigo: dict[str, int] = {}

    product_ids = [p.id for p in existing_by_sku.values()]

    desired_variant_payloads: dict[tuple[UUID, str], dict[str, Any]] = {}
    for (sku, _bodega_key, hash_identity), desired in desired_by_sku_bodega_variant.items():
        product = existing_by_sku.get(sku)
        if product is None:
            continue
        desired_variant_payloads[(product.id, hash_identity)] = {
            "empresa_id": empresa_id,
            "producto_id": product.id,
            "hash_identity": hash_identity,
            "attributes": cast(dict[str, Any], desired.get("additional_attributes") or {}),
        }

    existing_variants: list[ProductVariant] = []
    if desired_variant_payloads:
        all_hashes = sorted({h for (_pid, h) in desired_variant_payloads.keys()})
        existing_variants = (
            db.execute(
                select(ProductVariant).where(
                    ProductVariant.producto_id.in_(product_ids),
                    ProductVariant.hash_identity.in_(all_hashes),
                )
            )
            .scalars()
            .all()
        )
    variant_id_by_key: dict[tuple[UUID, str], UUID] = {
        (v.producto_id, cast(str, v.hash_identity)): v.id for v in existing_variants
    }
    if variant_id_by_key_seed:
        variant_id_by_key.update(variant_id_by_key_seed)

    missing_variant_rows: list[dict[str, Any]] = []
    for key, payload in desired_variant_payloads.items():
        if key in variant_id_by_key:
            continue
        missing_variant_rows.append(
            {
                "id": uuid6.uuid7(),
                "empresa_id": payload["empresa_id"],
                "producto_id": payload["producto_id"],
                "hash_identity": payload["hash_identity"],
                "attributes": payload["attributes"],
                "sku_variant": None,
            }
        )
    if missing_variant_rows:
        db.execute(
            pg_insert(ProductVariant)
            .values(missing_variant_rows)
            .on_conflict_do_nothing(index_elements=[ProductVariant.producto_id, ProductVariant.hash_identity])
        )
        db.flush()

        refreshed_variants = (
            db.execute(
                select(ProductVariant).where(
                    ProductVariant.producto_id.in_(product_ids),
                    ProductVariant.hash_identity.in_(
                        sorted({r["hash_identity"] for r in missing_variant_rows})
                    ),
                )
            )
            .scalars()
            .all()
        )
        for v in refreshed_variants:
            variant_id_by_key[(v.producto_id, cast(str, v.hash_identity))] = v.id

    bodega_ids_to_lock = {default_bodega_id} | {b.id for b in bodegas_by_codigo_externo.values()}
    needed_variant_ids = sorted({vid for vid in variant_id_by_key.values()})
    inv_rows: list[Inventario] = []
    if needed_variant_ids:
        inv_rows = (
            db.execute(
                select(Inventario)
                .where(
                    Inventario.bodega_id.in_(list(bodega_ids_to_lock)),
                    Inventario.variant_id.in_(needed_variant_ids),
                )
                .with_for_update()
            )
            .scalars()
            .all()
        )
    inv_by_variant_bodega: dict[tuple[UUID, UUID], Inventario] = {
        (inv.variant_id, inv.bodega_id): inv for inv in inv_rows
    }

    for (sku, bodega_key, hash_identity), desired in desired_by_sku_bodega_variant.items():
        product = existing_by_sku.get(sku)
        if product is None:
            errors.append(
                {
                    "kind": "apply_stock_failed",
                    "sku": sku,
                    "row_number": desired.get("row_number"),
                    "error": "Producto no resuelto post-upsert",
                }
            )
            continue
        try:
            if getattr(product, "es_trazable", False):
                raise ValueError("Producto trazable requiere lotes para ajustar stock")

            if bodega_key == "(DEFAULT)":
                row_bodega_id = default_bodega_id
                bodega_codigo_externo = "(DEFAULT)"
            else:
                bodega = bodegas_by_codigo_externo.get(bodega_key)
                if bodega is None:
                    raise ValueError(f"Bodega no resuelta: {bodega_key}")
                row_bodega_id = bodega.id
                bodega_codigo_externo = bodega_key

            incoming_attrs = cast(dict[str, Any], desired.get("additional_attributes") or {})
            variant_id = variant_id_by_key.get((product.id, hash_identity))
            if variant_id is None:
                raise ValueError("Variante no resuelta post-upsert")

            inv_key = (variant_id, row_bodega_id)
            inv = inv_by_variant_bodega.get(inv_key)
            desired_stock = int(desired["stock"])
            if inv is not None and desired_stock < int(inv.cantidad_reservada):
                raise ValueError("Stock objetivo menor que cantidad reservada")

            current_stock = int(inv.cantidad) if inv is not None else 0
            delta = desired_stock - current_stock
            if delta != 0:
                if delta > 0:
                    InventoryService.release_stock(
                        db,
                        product.id,
                        row_bodega_id,
                        delta,
                        "IMPORT_AJUSTE",
                        empresa_id,
                        costo_unitario=None,
                        variant_id=variant_id,
                        attributes=incoming_attrs,
                        import_run_id=import_run_id,
                        additional_attributes=incoming_attrs,
                    )
                else:
                    InventoryService.consume_stock(
                        db,
                        product.id,
                        row_bodega_id,
                        abs(delta),
                        "IMPORT_AJUSTE",
                        empresa_id,
                        reference_id=str(import_run_id),
                        lote_id=None,
                        variant_id=variant_id,
                        attributes=incoming_attrs,
                        import_run_id=import_run_id,
                        additional_attributes=incoming_attrs,
                    )
                if inv is None:
                    inv = (
                        db.execute(
                            select(Inventario).where(
                                Inventario.variant_id == variant_id,
                                Inventario.bodega_id == row_bodega_id,
                            )
                        )
                        .scalars()
                        .first()
                    )
                    if inv is not None:
                        inv_by_variant_bodega[inv_key] = inv
                stock_updates += 1
                movements += 1
                movements_by_bodega_codigo[bodega_codigo_externo] = movements_by_bodega_codigo.get(
                    bodega_codigo_externo, 0
                ) + 1
                stock_updates_by_bodega_codigo[bodega_codigo_externo] = stock_updates_by_bodega_codigo.get(
                    bodega_codigo_externo, 0
                ) + 1
        except Exception as e:
            errors.append(
                {
                    "kind": "apply_stock_failed",
                    "sku": sku,
                    "row_number": desired.get("row_number"),
                    "error": str(e),
                }
            )

    return (
        stock_updates,
        movements,
        movements_by_bodega_codigo,
        stock_updates_by_bodega_codigo,
        errors,
    )

