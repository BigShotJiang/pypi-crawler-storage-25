from __future__ import annotations

from typing import Any, cast
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session


def ensure_default_sucursal_and_bodega(
    *,
    db: Session,
    empresa_id: UUID,
    bodega_id: UUID | None,
) -> tuple[Any, UUID]:
    from app.core_modules.sistema.models import Bodega, Sucursal

    sucursal = (
        db.execute(
            select(Sucursal)
            .where(Sucursal.empresa_id == empresa_id)
            .order_by(Sucursal.created_at.asc())
            .limit(1)
        )
        .scalars()
        .first()
    )
    if sucursal is None:
        sucursal = Sucursal(
            nombre="Sucursal Principal",
            codigo="SUC-01",
            direccion=None,
            empresa_id=empresa_id,
        )
        db.add(sucursal)
        db.flush()

    default_bodega_id = bodega_id
    if default_bodega_id is None:
        bodega = (
            db.execute(
                select(Bodega)
                .where(Bodega.sucursal_id == sucursal.id)
                .order_by(Bodega.created_at.asc())
                .limit(1)
            )
            .scalars()
            .first()
        )
        if bodega is None:
            bodega = Bodega(
                nombre="Bodega Central",
                codigo="BOD-CENTRAL",
                codigo_externo="BOD-CENTRAL",
                sucursal_id=sucursal.id,
                is_active=True,
            )
            db.add(bodega)
            db.flush()
        default_bodega_id = cast(UUID, bodega.id)

    return sucursal, default_bodega_id


def ensure_bodegas_by_codigo_externo(
    *,
    db: Session,
    empresa_id: UUID,
    sucursal_id: UUID,
    codigos_externos: set[str],
) -> tuple[dict[str, Any], int]:
    from app.core_modules.sistema.models import Bodega, Sucursal

    bodegas_by_codigo_externo: dict[str, Any] = {}
    created_bodegas = 0
    if not codigos_externos:
        return bodegas_by_codigo_externo, created_bodegas

    existing_bodegas = (
        db.execute(
            select(Bodega)
            .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
            .where(
                Sucursal.empresa_id == empresa_id,
                Bodega.codigo_externo.in_(sorted(codigos_externos)),
            )
            .order_by(Bodega.created_at.asc())
        )
        .scalars()
        .all()
    )
    for b in existing_bodegas:
        if b.codigo_externo and b.codigo_externo not in bodegas_by_codigo_externo:
            bodegas_by_codigo_externo[b.codigo_externo] = b

    missing = [c for c in sorted(codigos_externos) if c not in bodegas_by_codigo_externo]
    for codigo_externo in missing:
        bodega = Bodega(
            nombre=codigo_externo,
            codigo=codigo_externo,
            codigo_externo=codigo_externo,
            sucursal_id=sucursal_id,
            is_active=True,
        )
        db.add(bodega)
        db.flush()
        bodegas_by_codigo_externo[codigo_externo] = bodega
        created_bodegas += 1

    return bodegas_by_codigo_externo, created_bodegas


def fetch_products_by_sku(
    *,
    db: Session,
    empresa_id: UUID,
    skus: list[str],
) -> dict[str, Any]:
    from app.core_modules.ventas.models import Producto

    if not skus:
        return {}

    existing_products = (
        db.execute(
            select(Producto).where(
                Producto.empresa_id == empresa_id,
                Producto.sku.in_(skus),
            )
        )
        .scalars()
        .all()
    )
    return {cast(str, p.sku): p for p in existing_products}

