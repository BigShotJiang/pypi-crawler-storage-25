from __future__ import annotations

from io import BytesIO
import re
import unicodedata
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Iterable, Literal
from uuid import UUID

import pandas as pd
import uuid6
from sqlalchemy.orm import Session

from app.models.staging import StagingImport


class ChileanNormalizer:
    @staticmethod
    def normalize_text(value: Any) -> str:
        if value is None:
            return ""
        return str(value).strip()

    @staticmethod
    def normalize_rut(value: Any) -> str:
        raw = ChileanNormalizer.normalize_text(value)
        if raw == "":
            raise ValueError("RUT vacío")
        cleaned = raw.replace(".", "").replace(" ", "").upper()
        if "-" in cleaned:
            parts = cleaned.split("-", 1)
            num = parts[0]
            dv = parts[1]
        else:
            num = cleaned[:-1]
            dv = cleaned[-1:]

        num = re.sub(r"[^0-9]", "", num)
        dv = re.sub(r"[^0-9K]", "", dv)
        if num == "" or dv == "":
            raise ValueError("RUT inválido")
        if not re.fullmatch(r"[0-9K]", dv):
            raise ValueError("DV inválido")
        return f"{num}-{dv}"

    @staticmethod
    def normalize_currency(value: Any) -> Decimal:
        if value is None:
            raise ValueError("Moneda vacía")
        if isinstance(value, (int, float, Decimal)):
            try:
                return Decimal(str(value))
            except InvalidOperation as e:
                raise ValueError("Moneda inválida") from e

        raw = ChileanNormalizer.normalize_text(value)
        if raw == "":
            raise ValueError("Moneda vacía")
        s = raw.replace("$", "").replace(" ", "")
        s = re.sub(r"[^0-9,.\-]", "", s)

        if "," in s and "." in s:
            s = s.replace(".", "").replace(",", ".")
        elif "," in s:
            last = s.rfind(",")
            decimals = len(s) - last - 1
            if 1 <= decimals <= 2:
                s = s.replace(".", "").replace(",", ".")
            else:
                s = s.replace(",", "")
        elif "." in s:
            last = s.rfind(".")
            decimals = len(s) - last - 1
            if 1 <= decimals <= 2:
                s = s.replace(",", "")
            else:
                s = s.replace(".", "")

        try:
            return Decimal(s)
        except InvalidOperation as e:
            raise ValueError("Moneda inválida") from e

    @staticmethod
    def parse_int(value: Any) -> int:
        if value is None:
            raise ValueError("Entero vacío")
        if isinstance(value, bool):
            raise ValueError("Entero inválido")
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if pd.isna(value):
                raise ValueError("Entero vacío")
            if float(int(value)) != float(value):
                raise ValueError("Entero con decimales")
            return int(value)
        if isinstance(value, Decimal):
            if value != value.to_integral_value():
                raise ValueError("Entero con decimales")
            return int(value)

        raw = ChileanNormalizer.normalize_text(value)
        if raw == "":
            raise ValueError("Entero vacío")
        s = raw.replace(" ", "")
        s = re.sub(r"[^0-9,.\-]", "", s)
        d = ChileanNormalizer.normalize_currency(s)
        if d != d.to_integral_value():
            raise ValueError("Entero con decimales")
        return int(d)


def _to_jsonable_cell(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, float) and pd.isna(value):
        return None
    if pd.isna(value):
        return None
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, (str, int, bool)):
        return value
    return str(value)


def _normalize_record(raw: dict[str, Any], row_number: int) -> dict[str, Any]:
    normalized: dict[str, Any] = {"_row_number": row_number}
    for k, v in raw.items():
        if k is None:
            continue
        key = str(k).strip()
        if key == "":
            continue
        normalized[key] = _to_jsonable_cell(v)
    return normalized


def _chunked(items: list[dict[str, Any]], chunk_size: int) -> Iterable[list[dict[str, Any]]]:
    for i in range(0, len(items), chunk_size):
        yield items[i : i + chunk_size]


def ingest_excel_bytes_to_staging(
    *,
    db: Session,
    empresa_id: UUID,
    content: bytes,
    filename: str | None = None,
    sheet_name: str | int | None = 0,
    header: int = 0,
    chunk_size: int = 1000,
    progress: Callable[[int, int], None] | None = None,
) -> int:
    df = pd.read_excel(BytesIO(content), dtype=str, sheet_name=sheet_name, header=header)
    if not isinstance(df, pd.DataFrame):
        raise ValueError("sheet_name debe referenciar una sola hoja (no dict de hojas)")

    records: list[dict[str, Any]] = []
    for idx, raw in enumerate(df.to_dict(orient="records")):
        excel_row_number = header + 2 + idx
        records.append(_normalize_record(raw, excel_row_number))

    return ingest_records_to_staging(
        db=db,
        empresa_id=empresa_id,
        records=records,
        filename=filename,
        source_type="excel",
        chunk_size=chunk_size,
        progress=progress,
    )


def ingest_csv_bytes_to_staging(
    *,
    db: Session,
    empresa_id: UUID,
    content: bytes,
    filename: str | None = None,
    encoding: str = "utf-8",
    header: int = 0,
    chunk_size: int = 1000,
    progress: Callable[[int, int], None] | None = None,
) -> int:
    text = content.decode(encoding, errors="replace")
    df = pd.read_csv(BytesIO(text.encode("utf-8")), dtype=str, header=header)

    records: list[dict[str, Any]] = []
    for idx, raw in enumerate(df.to_dict(orient="records")):
        csv_row_number = header + 2 + idx
        records.append(_normalize_record(raw, csv_row_number))

    return ingest_records_to_staging(
        db=db,
        empresa_id=empresa_id,
        records=records,
        filename=filename,
        source_type="csv",
        chunk_size=chunk_size,
        progress=progress,
    )


def ingest_records_to_staging(
    *,
    db: Session,
    empresa_id: UUID,
    records: list[dict[str, Any]],
    filename: str | None,
    source_type: str,
    chunk_size: int = 1000,
    progress: Callable[[int, int], None] | None = None,
) -> int:
    total = len(records)
    inserted = 0
    for chunk in _chunked(records, chunk_size):
        try:
            mappings: list[dict[str, Any]] = [
                {
                    "id": uuid6.uuid7(),
                    "empresa_id": empresa_id,
                    "source_filename": filename,
                    "source_type": source_type,
                    "status": "pending",
                    "raw_content": record,
                    "error_log": None,
                }
                for record in chunk
            ]
            db.bulk_insert_mappings(StagingImport.__mapper__, mappings)
            db.commit()
            inserted += len(chunk)
            if progress:
                progress(inserted, total)
        except Exception as e:
            db.rollback()
            for record in chunk:
                try:
                    row = StagingImport(
                        id=uuid6.uuid7(),
                        empresa_id=empresa_id,
                        source_filename=filename,
                        source_type=source_type,
                        status="pending",
                        raw_content=record,
                        error_log=None,
                    )
                    db.add(row)
                    db.commit()
                    inserted += 1
                    if progress:
                        progress(inserted, total)
                except Exception as row_exc:
                    db.rollback()
                    failed = StagingImport(
                        id=uuid6.uuid7(),
                        empresa_id=empresa_id,
                        source_filename=filename,
                        source_type=source_type,
                        status="failed",
                        raw_content={"_row_number": record.get("_row_number")},
                        error_log={
                            "kind": "staging_insert_failed",
                            "error": str(row_exc),
                            "bulk_error": str(e),
                        },
                    )
                    db.add(failed)
                    db.commit()
                    inserted += 1
                    if progress:
                        progress(inserted, total)
    return inserted


def _normalize_header(value: Any) -> str:
    s = str(value or "").strip().lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"\s+", " ", s)
    return s


def _get_raw_value(raw_content: dict[str, Any], source_column: str) -> Any:
    wanted = _normalize_header(source_column)
    for k, v in raw_content.items():
        if _normalize_header(k) == wanted:
            return v
    return None


def process_staging_to_production(
    *,
    db: Session,
    empresa_id: UUID,
    limit: int = 500,
    template: Literal["inventario"] = "inventario",
    source_filename: str | None = None,
) -> dict[str, int]:
    prev_tenant = db.info.get("empresa_id", None)
    db.info["empresa_id"] = empresa_id
    try:
        if template != "inventario":
            raise ValueError("Template no soportado")

        q = db.query(StagingImport).filter(
            StagingImport.empresa_id == empresa_id,
            StagingImport.status == "pending",
        )
        if source_filename:
            q = q.filter(StagingImport.source_filename == source_filename)
        rows = q.order_by(StagingImport.created_at.asc()).limit(limit).all()

        validated = 0
        failed = 0
        updates: list[dict[str, Any]] = []

        for row in rows:
            raw = dict(row.raw_content or {})
            row_number = raw.get("_row_number")
            errors: list[dict[str, Any]] = []

            sku_raw = _get_raw_value(raw, "Código de artículo")
            name_raw = _get_raw_value(raw, "Nombre del producto")
            stock_raw = _get_raw_value(raw, "Física disponible")
            familia_raw = _get_raw_value(raw, "familia")

            sku = ChileanNormalizer.normalize_text(sku_raw)
            name = ChileanNormalizer.normalize_text(name_raw)
            familia = ChileanNormalizer.normalize_text(familia_raw)
            has_stock = stock_raw is not None and ChileanNormalizer.normalize_text(stock_raw) != ""
            has_familia = familia != ""
            if sku == "":
                errors.append(
                    {
                        "code": "missing_required",
                        "field": "sku",
                        "source_column": "Código de artículo",
                        "message": "SKU requerido",
                    }
                )
            if has_stock and name == "":
                errors.append(
                    {
                        "code": "missing_required",
                        "field": "name",
                        "source_column": "Nombre del producto",
                        "message": "Nombre requerido",
                    }
                )

            if not has_stock and not has_familia:
                errors.append(
                    {
                        "code": "missing_required",
                        "field": "stock",
                        "source_column": "Física disponible",
                        "message": "Stock requerido",
                    }
                )
            elif has_stock:
                try:
                    ChileanNormalizer.parse_int(stock_raw)
                except Exception as e:
                    errors.append(
                        {
                            "code": "invalid_type",
                            "field": "stock",
                            "source_column": "Física disponible",
                            "message": f"Stock inválido: {str(e)}",
                        }
                    )

            if errors:
                failed += 1
                updates.append(
                    {
                        "id": row.id,
                        "status": "failed",
                        "error_log": {
                            "kind": "validation_failed",
                            "template": template,
                            "row_number": row_number,
                            "errors": errors,
                        },
                    }
                )
            else:
                validated += 1
                updates.append({"id": row.id, "status": "validated", "error_log": None})

        if updates:
            db.bulk_update_mappings(StagingImport.__mapper__, updates)
            db.commit()

        return {"processed": len(rows), "validated": validated, "failed": failed}
    finally:
        if prev_tenant is None:
            db.info.pop("empresa_id", None)
        else:
            db.info["empresa_id"] = prev_tenant


def apply_validated_inventory_to_production(
    *,
    db: Session,
    empresa_id: UUID,
    import_run_id: UUID | None = None,
    bodega_id: UUID | None = None,
    filename: str | None = None,
    file_hash: str | None = None,
    warehouse_column: str = "Almacén",
    limit: int | None = None,
    source_filename: str | None = None,
    mapping_json: dict[str, Any] | None = None,
) -> dict[str, Any]:
    from app.core.services.ingestion_apply import apply_validated_inventory_to_production as _impl

    return _impl(
        db=db,
        empresa_id=empresa_id,
        import_run_id=import_run_id,
        bodega_id=bodega_id,
        filename=filename,
        file_hash=file_hash,
        warehouse_column=warehouse_column,
        limit=limit,
        source_filename=source_filename,
        mapping_json=mapping_json,
    )
