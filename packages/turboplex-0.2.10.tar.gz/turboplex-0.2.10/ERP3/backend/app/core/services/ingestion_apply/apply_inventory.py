from __future__ import annotations

import hashlib
import json
import logging
from decimal import Decimal
from typing import Any, cast
from uuid import UUID

import uuid6
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.services.ingestion_apply.normalize import (
    normalize_bodega_codigo_externo,
    normalize_familia,
    normalize_sku,
)
from app.core.services.ingestion_apply.helpers import (
    ensure_bodegas_by_codigo_externo,
    ensure_default_sucursal_and_bodega,
    fetch_products_by_sku,
)
from app.models.staging import StagingImport

logger = logging.getLogger(__name__)


def apply_validated_inventory_to_production(
    *,
    db: Session,
    empresa_id: UUID,
    import_run_id: UUID | None = None,
    bodega_id: UUID | None = None,
    filename: str | None = None,
    file_hash: str | None = None,
    warehouse_column: str = "Almacén",
    limit: int | None = None,
    source_filename: str | None = None,
    mapping_json: dict[str, Any] | None = None,
) -> dict[str, Any]:
    from app.core.exceptions import BusinessRuleError
    from app.core.services.ingestion_service import ChileanNormalizer, _get_raw_value
    from app.core.services.import_service.stock_adjust_utils import (
        extract_camaleonic_attributes,
        parse_additional_attributes,
        normalize_column_name,
        slugify_additional_key,
    )

    prev_tenant = db.info.get("empresa_id", None)
    db.info["empresa_id"] = empresa_id
    try:
        if not file_hash:
            raise ValueError("file_hash requerido para auditoría/idempotencia")

        import_run_id = import_run_id or uuid6.uuid7()

        from app.core_modules.ventas.models import Producto
        from app.models.staging import ImportRun, ImportRunStatus

        def _canonicalize_additional_attributes(attrs: dict[str, Any] | None) -> str:
            if not attrs:
                return "{}"
            return json.dumps(attrs, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

        def _hash_identity(attrs: dict[str, Any] | None) -> str:
            canonical = _canonicalize_additional_attributes(attrs)
            return hashlib.md5(canonical.encode("utf-8")).hexdigest()

        sucursal, default_bodega_id = ensure_default_sucursal_and_bodega(
            db=db, empresa_id=empresa_id, bodega_id=bodega_id
        )

        existing_completed = (
            db.execute(
                select(ImportRun)
                .where(
                    ImportRun.empresa_id == empresa_id,
                    ImportRun.file_hash == file_hash,
                    ImportRun.status == ImportRunStatus.COMPLETED,
                )
                .limit(1)
            )
            .scalars()
            .first()
        )
        if existing_completed is not None:
            raise BusinessRuleError(
                "Importación duplicada: el archivo ya fue aplicado (COMPLETED)",
                details={
                    "empresa_id": str(empresa_id),
                    "file_hash": file_hash,
                    "existing_import_run_id": str(existing_completed.id),
                },
            )

        import_run = ImportRun(
            id=import_run_id,
            empresa_id=empresa_id,
            bodega_id=default_bodega_id,
            filename=filename,
            file_hash=file_hash,
            status=ImportRunStatus.STARTED,
            summary=None,
        )
        db.add(import_run)
        db.commit()
        db.refresh(import_run)

        staging_query = (
            select(StagingImport)
            .where(
                StagingImport.empresa_id == empresa_id,
                StagingImport.status == "validated",
            )
            .order_by(StagingImport.created_at.asc())
        )
        if source_filename:
            staging_query = staging_query.where(StagingImport.source_filename == source_filename)
        if limit is not None:
            staging_query = staging_query.limit(limit)
        staging_rows = db.execute(staging_query).scalars().all()

        desired_by_sku: dict[str, dict[str, Any]] = {}
        desired_by_sku_bodega_variant: dict[tuple[str, str, str], dict[str, Any]] = {}
        familia_by_sku: dict[str, str] = {}
        row_number_by_sku_for_familia: dict[str, int | None] = {}

        raw_rows_by_bodega_codigo: dict[str, int] = {}
        bodega_codigos_externos: set[str] = set()
        errors: list[dict[str, Any]] = []
        movements = 0
        created_products = 0
        created_bodegas = 0
        updated_product_skus: set[str] = set()
        explicit_additional_mapping = parse_additional_attributes(mapping_json or {})

        for row in staging_rows:
            raw = dict(row.raw_content or {})
            row_number = cast(int | None, raw.get("_row_number"))
            try:
                sku_raw = _get_raw_value(raw, "Código de artículo")
                name_raw = _get_raw_value(raw, "Nombre del producto")
                stock_raw = _get_raw_value(raw, "Física disponible")
                almacen_raw = _get_raw_value(raw, warehouse_column)
                familia_raw = _get_raw_value(raw, "familia")

                sku = normalize_sku(sku_raw)
                if sku == "":
                    raise ValueError("SKU vacío")

                familia = normalize_familia(familia_raw)
                if familia is not None:
                    familia_by_sku[sku] = familia
                    row_number_by_sku_for_familia[sku] = row_number

                has_stock = stock_raw is not None and ChileanNormalizer.normalize_text(stock_raw) != ""
                if not has_stock:
                    continue

                name = ChileanNormalizer.normalize_text(name_raw)
                if name == "":
                    raise ValueError("Nombre vacío")
                if len(name) > 512:
                    name = name[:512]
                stock = ChileanNormalizer.parse_int(stock_raw)
                bodega_codigo_externo = normalize_bodega_codigo_externo(almacen_raw)

                core_excel_columns = {
                    normalize_column_name("Código de artículo"),
                    normalize_column_name("Nombre del producto"),
                    normalize_column_name("Física disponible"),
                    normalize_column_name(warehouse_column),
                    normalize_column_name("familia"),
                }
                additional_attributes = extract_camaleonic_attributes(
                    raw,
                    core_excel_columns=core_excel_columns,
                    explicit_mapping=explicit_additional_mapping or None,
                )
                reserved_labels = {
                    "id",
                    "producto_id",
                    "bodega_id",
                    "sku",
                    "codigo",
                    "código",
                    "codigo de artículo",
                    "código de artículo",
                    "codigo articulo",
                    "nombre",
                    "producto",
                    "nombre del producto",
                    "cantidad",
                    "stock",
                    "inventario fisico",
                    "inventario físico",
                    "inventario_fisico",
                    "fisica disponible",
                    "física disponible",
                    "cantidad_reservada",
                    "stock_minimo",
                    "almacen",
                    "almacén",
                    "bodega",
                    "bodega codigo",
                    "bodega código",
                    "bodega codigo externo",
                    "bodega código externo",
                    "familia",
                    normalize_column_name(warehouse_column),
                }
                reserved_keys = {slugify_additional_key(x) for x in reserved_labels if slugify_additional_key(x)}
                if additional_attributes and reserved_keys:
                    filtered: dict[str, Any] = {}
                    for k, v in additional_attributes.items():
                        if k in reserved_keys:
                            continue
                        filtered[k] = v
                    additional_attributes = filtered

                if bodega_codigo_externo != "":
                    bodega_codigos_externos.add(bodega_codigo_externo)
                    raw_rows_by_bodega_codigo[bodega_codigo_externo] = raw_rows_by_bodega_codigo.get(
                        bodega_codigo_externo, 0
                    ) + 1
                else:
                    raw_rows_by_bodega_codigo["(DEFAULT)"] = raw_rows_by_bodega_codigo.get("(DEFAULT)", 0) + 1

                desired_by_sku[sku] = {
                    "sku": sku,
                    "name": name,
                    "row_number": row_number,
                }
                bodega_key = bodega_codigo_externo or "(DEFAULT)"
                hash_identity = _hash_identity(additional_attributes)
                sku_bodega_variant_key = (sku, bodega_key, hash_identity)
                desired_by_sku_bodega_variant[sku_bodega_variant_key] = {
                    "sku": sku,
                    "name": name,
                    "stock": stock,
                    "row_number": row_number,
                    "bodega_codigo_externo": bodega_codigo_externo,
                    "additional_attributes": additional_attributes,
                    "hash_identity": hash_identity,
                }
            except Exception as e:
                errors.append(
                    {
                        "kind": "apply_input_invalid",
                        "row_number": row_number,
                        "error": str(e),
                    }
                )

        all_skus = sorted(set(desired_by_sku.keys()) | set(familia_by_sku.keys()))
        if not all_skus:
            import_run.status = ImportRunStatus.COMPLETED
            import_run.summary = {
                "created": 0,
                "updated": 0,
                "failed": len(errors),
                "movements": 0,
                "bodegas": {
                    "created": 0,
                    "affected": [],
                    "rows_by_codigo_externo": raw_rows_by_bodega_codigo,
                },
            }
            db.add(import_run)
            db.commit()
            return {
                "import_run_id": str(import_run_id),
                "bodega_id": str(default_bodega_id),
                "created_products": 0,
                "updated_products": 0,
                "stock_updates": 0,
                "errors": errors,
            }

        bodegas_by_codigo_externo, created_bodegas = ensure_bodegas_by_codigo_externo(
            db=db,
            empresa_id=empresa_id,
            sucursal_id=sucursal.id,
            codigos_externos=bodega_codigos_externos,
        )

        existing_by_sku: dict[str, Producto] = fetch_products_by_sku(
            db=db, empresa_id=empresa_id, skus=all_skus
        )

        inventory_skus = list(desired_by_sku.keys())
        for sku in inventory_skus:
            desired = desired_by_sku[sku]
            product = existing_by_sku.get(sku)
            desired_name = cast(str, desired["name"])
            if product is None:
                product = Producto(
                    nombre=desired_name,
                    sku=sku,
                    descripcion=None,
                    precio=Decimal("0.00"),
                    costo_promedio=Decimal("0.0000"),
                    tipo_producto="ALMACENABLE",
                    is_active=True,
                    es_trazable=False,
                    empresa_id=empresa_id,
                )
                db.add(product)
                db.flush()
                existing_by_sku[sku] = product
                created_products += 1
            else:
                if product.nombre != desired_name:
                    product.nombre = desired_name
                    db.add(product)
                    updated_product_skus.add(sku)

        for sku, familia in familia_by_sku.items():
            product = existing_by_sku.get(sku)
            if product is None:
                logger.warning(
                    "Enriquecimiento familia: SKU no existe en DB, se omite",
                    extra={"sku": sku, "row_number": row_number_by_sku_for_familia.get(sku)},
                )
                continue
            if getattr(product, "familia", None) != familia:
                product.familia = familia
                db.add(product)
                updated_product_skus.add(sku)

        if not desired_by_sku_bodega_variant:
            db.commit()
            import_run.status = ImportRunStatus.COMPLETED
            import_run.summary = {
                "created": created_products,
                "updated": len(updated_product_skus),
                "failed": len(errors),
                "movements": 0,
                "bodegas": {
                    "created": created_bodegas,
                    "affected": [],
                    "rows_by_codigo_externo": raw_rows_by_bodega_codigo,
                },
            }
            db.add(import_run)
            db.commit()
            return {
                "import_run_id": str(import_run_id),
                "bodega_id": str(default_bodega_id),
                "created_products": created_products,
                "updated_products": len(updated_product_skus),
                "stock_updates": 0,
                "errors": errors,
            }

        from app.core.services.ingestion_apply.apply_stock import apply_stock_updates

        (
            stock_updates,
            movements,
            movements_by_bodega_codigo,
            stock_updates_by_bodega_codigo,
            stock_errors,
        ) = apply_stock_updates(
            db=db,
            empresa_id=empresa_id,
            import_run_id=import_run_id,
            default_bodega_id=default_bodega_id,
            existing_by_sku=existing_by_sku,
            desired_by_sku_bodega_variant=desired_by_sku_bodega_variant,
            bodegas_by_codigo_externo=bodegas_by_codigo_externo,
        )
        errors.extend(stock_errors)

        db.commit()
        import_run.status = ImportRunStatus.COMPLETED
        affected_codigos = sorted(list(bodega_codigos_externos))
        import_run.summary = {
            "created": created_products,
            "updated": len(updated_product_skus),
            "failed": len(errors),
            "movements": movements,
            "bodegas": {
                "created": created_bodegas,
                "affected": affected_codigos,
                "rows_by_codigo_externo": raw_rows_by_bodega_codigo,
                "movements_by_codigo_externo": movements_by_bodega_codigo,
                "stock_updates_by_codigo_externo": stock_updates_by_bodega_codigo,
            },
        }
        db.add(import_run)
        db.commit()

        return {
            "import_run_id": str(import_run_id),
            "bodega_id": str(default_bodega_id),
            "created_products": created_products,
            "updated_products": len(updated_product_skus),
            "stock_updates": stock_updates,
            "errors": errors,
        }
    finally:
        if prev_tenant is None:
            db.info.pop("empresa_id", None)
        else:
            db.info["empresa_id"] = prev_tenant
