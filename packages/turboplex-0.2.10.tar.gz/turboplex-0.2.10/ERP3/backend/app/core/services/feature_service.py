from typing import cast

from sqlalchemy.orm import Session

from app.core_modules.sistema.models import Empresa


class FeatureService:
    """
    Pilar 10: Feature Flags Service.
    Gestiona la activación de funcionalidades por empresa (Tenant).
    """

    def is_enabled(self, feature_key: str, empresa: Empresa) -> bool:
        """
        Verifica si una feature está activada para una empresa específica.

        Optimización:
        - Accede directamente al objeto Empresa ya cargado en memoria (Session/Request).
        - feature_flags es un campo JSONB, por lo que el acceso es rápido.
        - No realiza consultas adicionales a la DB si 'empresa' ya está hidratado.
        """
        if not empresa or not empresa.feature_flags:
            return False
        flags = empresa.feature_flags
        if isinstance(flags, dict):
            return bool(flags.get(feature_key, False))
        return False

    def toggle_feature(
        self, db: Session, empresa_id: str, feature_key: str, enabled: bool
    ) -> dict[str, bool] | None:
        """
        Activa o desactiva una feature para una empresa.
        Requiere rol SUPERADMIN (validado en el endpoint).
        """
        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        if not empresa:
            return None
        raw_flags = empresa.feature_flags
        if isinstance(raw_flags, dict):
            current_flags = cast(dict[str, bool], dict(raw_flags))
        else:
            current_flags = {}
        current_flags[feature_key] = enabled
        empresa.feature_flags = current_flags
        db.add(empresa)
        db.commit()
        db.refresh(empresa)
        return current_flags


feature_service = FeatureService()
