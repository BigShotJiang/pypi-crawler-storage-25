from __future__ import annotations

import re
from typing import Any


def normalize_sku(value: Any) -> str:
    from app.core.services.ingestion_service import ChileanNormalizer

    s = ChileanNormalizer.normalize_text(value)
    s = re.sub(r"\s+", " ", s)
    return s.upper()


def normalize_bodega_codigo_externo(value: Any) -> str:
    s = str(value or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s.upper()


def normalize_familia(value: Any) -> str | None:
    s = str(value or "").strip()
    if s == "":
        return None
    s = re.sub(r"\s+", " ", s)
    return s.upper()

