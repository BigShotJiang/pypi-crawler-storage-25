from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from uuid import UUID

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError
from app.core_modules.sistema.models import Bodega, Sucursal
from app.core.services.ingestion_service import ChileanNormalizer


@dataclass(frozen=True)
class StockAdjustMapping:
    sku: str
    cantidad: str
    bodega_codigo: str
    costo_unitario: str | None


@dataclass(frozen=True)
class StockAdjustParsedRow:
    row_number: int
    sku: str
    cantidad_objetivo: int
    bodega_codigo: str
    costo_unitario: Decimal | None
    raw: dict[str, Any]


def normalize_column_name(value: Any) -> str:
    return str(value or "").strip()


def normalize_sku(value: Any) -> str:
    s = ChileanNormalizer.normalize_text(value)
    s = re.sub(r"\s+", " ", s)
    return s.upper()


def normalize_bodega_codigo(value: Any) -> str:
    s = str(value or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s.upper()


def to_jsonable_cell(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, float) and pd.isna(value):
        return None
    if isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return str(value)
    return str(value)


def df_to_records_with_row_numbers(df: pd.DataFrame, header: int) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for idx, raw in enumerate(df.to_dict(orient="records")):
        excel_row_number = header + 2 + idx
        normalized: dict[str, Any] = {"_row_number": excel_row_number}
        for k, v in dict(raw or {}).items():
            key = normalize_column_name(k)
            if key == "":
                continue
            normalized[key] = to_jsonable_cell(v)
        out.append(normalized)
    return out


def parse_sheet_name(value: str | int | None) -> str | int | None:
    if value is None:
        return 0
    if isinstance(value, int):
        return value
    s = str(value).strip()
    if s == "":
        return 0
    if s.isdigit():
        return int(s)
    return s


def parse_mapping(payload: Any) -> StockAdjustMapping:
    if not isinstance(payload, dict):
        raise ValueError("mapping debe ser un objeto JSON (dict)")

    sku_col = normalize_column_name(payload.get("sku"))
    qty_col = normalize_column_name(payload.get("cantidad"))
    bodega_col = normalize_column_name(payload.get("bodega_codigo") or payload.get("bodega"))
    costo_col = normalize_column_name(payload.get("costo_unitario") or payload.get("costo")) or None

    missing: list[str] = []
    if sku_col == "":
        missing.append("sku")
    if qty_col == "":
        missing.append("cantidad")
    if bodega_col == "":
        missing.append("bodega_codigo")
    if missing:
        raise ValueError(f"mapping incompleto. Faltan: {', '.join(missing)}")

    return StockAdjustMapping(
        sku=sku_col,
        cantidad=qty_col,
        bodega_codigo=bodega_col,
        costo_unitario=costo_col,
    )


def normalize_stock_adjust_mapping_json(payload: Any) -> dict[str, Any]:
    if payload is None:
        return {}

    raw: Any = payload
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return {}

    if not isinstance(raw, dict):
        return {}

    if isinstance(raw.get("base"), dict):
        base = dict(raw.get("base") or {})
        rest = {k: v for k, v in raw.items() if k != "base"}
        raw = {**base, **rest}

    if raw.get("additional_attributes") is None:
        meta = raw.get("metadata")
        if isinstance(meta, dict) and isinstance(meta.get("additional_attributes"), (dict, list)):
            raw["additional_attributes"] = meta.get("additional_attributes")
        else:
            raw["additional_attributes"] = {}

    if isinstance(raw.get("additional_attributes"), list):
        raw["additional_attributes"] = parse_additional_attributes(raw)
    elif not isinstance(raw.get("additional_attributes"), dict):
        raw["additional_attributes"] = {}

    return raw


def sanitize_additional_key(value: Any) -> str:
    s = unicodedata.normalize("NFKC", str(value or ""))
    s = re.sub(r"[\x00-\x1F\x7F]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def slugify_additional_key(value: Any) -> str:
    s = unicodedata.normalize("NFKD", str(value or ""))
    s = s.encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[\x00-\x1F\x7F]", "", s)
    s = s.replace("%", " porcentaje ")
    s = s.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def extract_camaleonic_attributes(
    raw_row: dict[str, Any],
    *,
    core_excel_columns: set[str],
    explicit_mapping: dict[str, str] | None = None,
) -> dict[str, Any]:
    used: set[str] = set()
    out: dict[str, Any] = {}

    mapping = explicit_mapping or {}
    if mapping:
        for raw_key, excel_col in mapping.items():
            key = slugify_additional_key(raw_key)
            if key == "":
                continue
            base = key
            i = 2
            while key in used:
                key = f"{base}_{i}"
                i += 1
            used.add(key)
            out[key] = to_jsonable_cell(raw_row.get(excel_col))
        return out

    for excel_col, value in raw_row.items():
        if excel_col in core_excel_columns:
            continue
        if excel_col == "_row_number":
            continue
        key = slugify_additional_key(excel_col)
        if key == "":
            continue
        base = key
        i = 2
        while key in used:
            key = f"{base}_{i}"
            i += 1
        used.add(key)
        out[key] = to_jsonable_cell(value)

    return out


def parse_additional_attributes(payload: Any) -> dict[str, str]:
    if not isinstance(payload, dict):
        return {}

    raw = payload.get("additional_attributes")
    if raw is None and isinstance(payload.get("metadata"), dict):
        raw = payload.get("metadata", {}).get("additional_attributes")

    if raw is None:
        return {}

    out: dict[str, str] = {}
    if isinstance(raw, dict):
        for k, v in raw.items():
            key = sanitize_additional_key(k)
            col = normalize_column_name(v)
            out[key] = col
        return out

    if isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict):
                continue
            key = sanitize_additional_key(item.get("erp_name") or item.get("name"))
            col = normalize_column_name(item.get("excel_column") or item.get("column"))
            out[key] = col
        return out

    return {}


def extract_additional_attributes(raw_row: dict[str, Any], mapping: dict[str, str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for erp_name, excel_col in mapping.items():
        if excel_col == "":
            out[erp_name] = None
            continue
        out[erp_name] = to_jsonable_cell(raw_row.get(excel_col))
    return out


def ensure_columns_exist(df: pd.DataFrame, mapping: StockAdjustMapping) -> None:
    columns = set(str(c) for c in df.columns)
    required = {mapping.sku, mapping.cantidad, mapping.bodega_codigo}
    if mapping.costo_unitario:
        required.add(mapping.costo_unitario)
    missing = [c for c in sorted(required) if c not in columns]
    if missing:
        raise ValueError(f"Columnas requeridas no presentes en Excel: {missing}")


def resolve_fallback_bodega_id(db: Session, empresa_id: UUID) -> UUID:
    bodega = (
        db.execute(
            select(Bodega)
            .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
            .where(Sucursal.empresa_id == empresa_id)
            .order_by(Bodega.created_at.asc())
            .limit(1)
        )
        .scalars()
        .first()
    )
    if bodega is None:
        raise BusinessRuleError("No hay bodegas en la empresa para registrar la importación")
    return bodega.id
