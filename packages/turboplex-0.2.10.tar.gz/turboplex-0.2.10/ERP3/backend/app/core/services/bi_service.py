import os
import secrets
import string
from typing import Any
from uuid import UUID
from fastapi import HTTPException, Request
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.core.database import writer_engine, reader_engine
from app.core_modules.sistema.models import Empresa, Usuario, AuditSeverity
from app.core_modules.sistema.schemas import RotateBICredentialsResponse, PowerBICredentials
from app.core.security.security_audit import security_audit


def _schema_exists(conn: Any, name: str) -> bool:
    try:
        result = conn.execute(
            text("SELECT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = :n)"),
            {"n": name},
        )
        return bool(result.scalar())
    except Exception:
        return False


def rotate_bi_credentials(
    db: Session,
    empresa_id: UUID,
    current_user: Usuario,
    request: Request,
) -> RotateBICredentialsResponse:
    db_user = f"bi_user_empresa_{empresa_id}"
    safe_alphabet = string.ascii_letters + string.digits
    db_password = "".join(secrets.choice(safe_alphabet) for _ in range(16))

    try:
        with writer_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            exists = conn.execute(
                text("SELECT 1 FROM pg_roles WHERE rolname=:user"), {"user": db_user}
            ).scalar()

            if exists:
                conn.execute(text(f"ALTER ROLE {db_user} WITH PASSWORD '{db_password}'"))
            else:
                conn.execute(
                    text(
                        f"CREATE ROLE {db_user} WITH LOGIN PASSWORD '{db_password}' "
                        "NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION"
                    )
                )

            db_name = writer_engine.url.database or "erp3_db"
            conn.execute(text(f"GRANT CONNECT ON DATABASE {db_name} TO {db_user}"))
            conn.execute(text(f"GRANT USAGE ON SCHEMA public TO {db_user}"))
            if _schema_exists(conn, "crm"):
                conn.execute(text(f"GRANT USAGE ON SCHEMA crm TO {db_user}"))
            if _schema_exists(conn, "inventario"):
                conn.execute(text(f"GRANT USAGE ON SCHEMA inventario TO {db_user}"))
            conn.execute(text(f"GRANT SELECT ON v_bi_transport_performance TO {db_user}"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")

    use_replica = os.getenv("BI_USE_REPLICA", "").strip() in {"1", "true", "TRUE"}
    base_engine = reader_engine if use_replica else writer_engine

    setattr(
        empresa,
        "pwr_bi_config",
        {
            "db_host": base_engine.url.host or "localhost",
            "db_port": base_engine.url.port or 5432,
            "db_name": base_engine.url.database or "erp3_db",
            "db_user": db_user,
            "last_rotation": "now()",
            "target": "replica" if use_replica else "master",
        },
    )

    security_audit.log(
        db=db,
        actor_id=current_user.id,
        action="ROTATE_BI_CREDENTIALS",
        resource=f"Empresa:{empresa_id}",
        severity=AuditSeverity.CRITICAL,
        changes={"db_user": db_user, "action": "Password Rotation / User Creation"},
        request=request,
    )

    db.add(empresa)
    db.commit()

    return RotateBICredentialsResponse(
        message="Credenciales generadas correctamente",
        credentials=PowerBICredentials(
            host=base_engine.url.host or "localhost",
            port=base_engine.url.port or 5432,
            database=base_engine.url.database or "erp3_db",
            username=db_user,
            password=db_password,
        ),
        warning="Guarde estas credenciales. La contraseña no será visible nuevamente.",
    )
