import io
import qrcode
from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
    Image,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from datetime import datetime
from decimal import Decimal
from app.core_modules.finanzas.services import get_iva_rate, round_clp


class PDFGenerator:
    @staticmethod
    def generate_delivery_guide(
        opportunity, items, validation_url: str, doc_hash: str
    ) -> io.BytesIO:
        """
        Genera un PDF profesional tipo Guía de Despacho con QR de validación.
        """
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer, pagesize=LETTER, topMargin=1.5 * cm, bottomMargin=1.5 * cm
        )
        elements = []
        styles = getSampleStyleSheet()
        header_text = """
        <b>ERP3 ENTERPRISE S.A.</b><br/>
        RUT: 76.543.210-K<br/>
        Av. Providencia 1234, Of. 505<br/>
        Santiago, Chile<br/>
        Tel: +56 2 2333 4444
        """
        p_header = Paragraph(header_text, styles["Normal"])
        guide_box_text = f"""
        <font size=14><b>R.U.T.: 76.543.210-K</b></font><br/><br/>
        <font size=16 color="red"><b>GUÍA DE DESPACHO</b></font><br/>
        <font size=16 color="red"><b>ELECTRÓNICA</b></font><br/><br/>
        <font size=14><b>Nº {opportunity.id:06d}</b></font>
        """
        p_guide_box = Paragraph(
            guide_box_text,
            ParagraphStyle(
                name="GuideBox", parent=styles["Normal"], alignment=TA_CENTER
            ),
        )

        header_table = Table([[p_header, p_guide_box]], colWidths=[12 * cm, 7 * cm])
        header_table.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    (
                        "BOX",
                        (1, 0),
                        (1, 0),
                        1.5,
                        colors.red,
                    ),
                    ("LEFTPADDING", (1, 0), (1, 0), 10),
                    ("RIGHTPADDING", (1, 0), (1, 0), 10),
                    ("TOPPADDING", (1, 0), (1, 0), 10),
                    ("BOTTOMPADDING", (1, 0), (1, 0), 10),
                ]
            )
        )
        elements.append(header_table)
        elements.append(Spacer(1, 1 * cm))
        fecha_emision = datetime.now().strftime("%d de %B del %Y")
        client_name = (
            opportunity.cliente.nombre if opportunity.cliente else "Cliente General"
        )
        client_rut = opportunity.cliente.rut if opportunity.cliente else "N/A"
        client_address = getattr(
            opportunity.cliente, "direccion", "Dirección no registrada"
        )
        bodega_name = (
            opportunity.bodega_id if opportunity.bodega_id else "Central"
        )

        client_data = [
            [f"Señor(es): {client_name}", f"Fecha Emisión: {fecha_emision}"],
            [f"RUT: {client_rut}", f"Bodega Origen: {bodega_name}"],
            [f"Dirección: {client_address}", f"Oportunidad Ref: #{opportunity.id}"],
            ["Giro: Venta de Insumos", "Condición Pago: Crédito 30 días"],
        ]

        client_table = Table(client_data, colWidths=[12 * cm, 7 * cm])
        client_table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 0), (-1, -1), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    (
                        "GRID",
                        (0, 0),
                        (-1, -1),
                        0.5,
                        colors.grey,
                    ),
                    ("BACKGROUND", (0, 0), (-1, -1), colors.whitesmoke),
                ]
            )
        )
        elements.append(client_table)
        elements.append(Spacer(1, 1 * cm))
        data = [
            ["Código", "Descripción", "Cantidad", "Unidad", "Precio Unit.", "Total"]
        ]

        total_neto = 0
        if items:
            for item in items:
                codigo = getattr(item, "codigo", "N/A")
                desc = getattr(item, "descripcion", "Producto Sin Nombre")
                cant = getattr(item, "cantidad", 0)
                precio = getattr(item, "precio_unitario", 0)
                total = cant * precio
                total_neto += total

                data.append(
                    [
                        codigo,
                        desc[:40],
                        f"{cant}",
                        "UN",
                        f"${precio:,.0f}",
                        f"${total:,.0f}",
                    ]
                )
        else:
            data.append(
                [
                    "GEN-001",
                    f"Servicios Profesionales - {opportunity.titulo}",
                    "1",
                    "GL",
                    f"${opportunity.monto_estimado:,.0f}",
                    f"${opportunity.monto_estimado:,.0f}",
                ]
            )
            total_neto = opportunity.monto_estimado

        iva_rate = get_iva_rate()
        iva = round_clp(Decimal(total_neto) * iva_rate)
        total_final = round_clp(Decimal(total_neto) + Decimal(iva))
        iva_percent = int(iva_rate * 100)
        items_table = Table(
            data, colWidths=[2.5 * cm, 8 * cm, 2 * cm, 1.5 * cm, 2.5 * cm, 2.5 * cm]
        )
        items_table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("ALIGN", (0, 0), (-1, 0), "CENTER"),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                    ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                ]
            )
        )
        elements.append(items_table)
        elements.append(Spacer(1, 0.5 * cm))
        totals_data = [
            ["", "Neto:", f"${total_neto:,.0f}"],
            ["", f"I.V.A. ({iva_percent}%):", f"${iva:,.0f}"],
            ["", "TOTAL:", f"${total_final:,.0f}"],
        ]
        totals_table = Table(totals_data, colWidths=[13 * cm, 3 * cm, 3 * cm])
        totals_table.setStyle(
            TableStyle(
                [
                    ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                    ("FONTNAME", (1, 2), (-1, 2), "Helvetica-Bold"),
                    ("LINEABOVE", (1, 2), (-1, 2), 1, colors.black),
                ]
            )
        )
        elements.append(totals_table)
        elements.append(Spacer(1, 2 * cm))
        qr = qrcode.QRCode(box_size=10, border=1)
        qr.add_data(validation_url)
        qr.make(fit=True)
        img_qr = qr.make_image(fill_color="black", back_color="white")
        qr_buffer = io.BytesIO()
        img_qr.save(qr_buffer, format="PNG")
        qr_buffer.seek(0)

        qr_image = Image(qr_buffer, width=3 * cm, height=3 * cm)
        footer_text = f"""
        <b>Timbre Electrónico ERP3</b><br/>
        Resolución Exenta SII N° 80 de 2014<br/>
        Verifique documento: {validation_url}<br/><br/>
        <font size=7 color="grey">Integrity Hash (SHA-256):<br/>{doc_hash}</font>
        """
        p_footer = Paragraph(footer_text, styles["Normal"])

        footer_table = Table([[qr_image, p_footer]], colWidths=[4 * cm, 12 * cm])
        footer_table.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ]
            )
        )
        elements.append(footer_table)
        doc.build(elements)
        buffer.seek(0)
        return buffer
