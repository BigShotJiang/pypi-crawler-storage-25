import os
import shutil
import uuid
import logging
from datetime import datetime
from typing import Optional, BinaryIO
from uuid import UUID
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core_modules.legal.models import DocumentoLegal, EstadoDocumento

logger = logging.getLogger(__name__)

try:
    import boto3

    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False


class StorageService:
    """
    Servicio de abstracción de almacenamiento (Local / S3-R2).
    """

    def __init__(self):
        self.mode = "local"

        has_r2_creds = (
            bool(settings.R2_ACCOUNT_ID)
            and bool(settings.R2_ACCESS_KEY_ID)
            and bool(settings.R2_SECRET_ACCESS_KEY)
        )

        has_endpoint = bool(settings.R2_ENDPOINT_URL)

        if has_r2_creds or (has_endpoint and settings.R2_ACCESS_KEY_ID):
            if settings.STORAGE_MODE == "s3" or has_r2_creds:
                self.mode = "s3"

        self.local_path = settings.LOCAL_STORAGE_PATH
        self.bucket_name = settings.R2_BUCKET_NAME
        self.s3_client = None

        if self.mode == "s3":
            if not BOTO3_AVAILABLE:
                logger.error(
                    "boto3 is required for S3 storage mode but is not installed. Falling back to local."
                )
                self.mode = "local"
            else:
                try:
                    endpoint_url = settings.R2_ENDPOINT_URL
                    if not endpoint_url and settings.R2_ACCOUNT_ID:
                        endpoint_url = (
                            f"https://{settings.R2_ACCOUNT_ID}.r2.cloudflarestorage.com"
                        )

                    self.s3_client = boto3.client(
                        "s3",
                        endpoint_url=endpoint_url,
                        aws_access_key_id=settings.R2_ACCESS_KEY_ID,
                        aws_secret_access_key=settings.R2_SECRET_ACCESS_KEY,
                        region_name=settings.R2_REGION_NAME,
                    )
                    logger.info(
                        f"StorageService initialized in S3/R2 mode (Bucket: {self.bucket_name})"
                    )
                except Exception as e:
                    logger.error(
                        f"Failed to initialize S3 client: {e}. Falling back to local."
                    )
                    self.mode = "local"

        if self.mode == "local":
            os.makedirs(self.local_path, exist_ok=True)
            logger.info(
                f"StorageService initialized in LOCAL mode (Path: {self.local_path})"
            )

    def _generate_path(self, tenant_id: UUID, rut_cliente: str, uuid_str: str) -> str:
        """
        Genera el path dinámico: tenant_{id}/rut_{cliente}/{año}/{mes}/{uuid}.pdf
        """
        now = datetime.now()
        year = now.strftime("%Y")
        month = now.strftime("%m")
        safe_rut = rut_cliente.replace("/", "-").replace("\\", "-")
        return f"tenant_{tenant_id}/rut_{safe_rut}/{year}/{month}/{uuid_str}.pdf"

    def upload_file(self, file_obj: BinaryIO, path: str) -> str:
        """
        Sube un archivo al almacenamiento configurado.
        Retorna el path relativo almacenado.
        """
        if self.mode == "s3" and self.s3_client:
            try:
                file_obj.seek(0)
                self.s3_client.upload_fileobj(
                    file_obj, self.bucket_name, path, ExtraArgs={"ACL": "private"}
                )
                logger.info(f"File uploaded to S3: {path}")
                return path
            except Exception as e:
                logger.error(f"Error uploading to S3: {e}")
                raise
        else:
            full_path = os.path.join(self.local_path, path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            file_obj.seek(0)
            with open(full_path, "wb") as buffer:
                shutil.copyfileobj(file_obj, buffer)

            logger.info(f"File saved locally: {full_path}")
            return path

    def generate_presigned_url(self, path: str, expiration_minutes: int = 15) -> str:
        """
        Genera una URL pre-firmada (temporal) para acceder al archivo.
        """
        if self.mode == "s3" and self.s3_client:
            try:
                response = self.s3_client.generate_presigned_url(
                    "get_object",
                    Params={"Bucket": self.bucket_name, "Key": path},
                    ExpiresIn=expiration_minutes * 60,
                )
                return response
            except Exception as e:
                logger.error(f"Error generating presigned URL: {e}")
                raise
        else:
            return f"http://localhost:8000/api/v1/storage/download?path={path}&token=mock_token"

    def register_legal_document(
        self,
        db: Session,
        file_obj: BinaryIO,
        oportunidad_id: UUID,
        tenant_id: UUID,
        rut_cliente: str,
        info_firma: Optional[dict] = None,
        hash_integridad: Optional[str] = None,
    ) -> DocumentoLegal:
        """
        Registra un documento legal: sube el archivo y crea el registro en DB.
        """
        doc_uuid = uuid.uuid4()
        path = self._generate_path(tenant_id, rut_cliente, str(doc_uuid))

        try:
            self.upload_file(file_obj, path)
        except Exception as e:
            logger.error(f"Failed to upload file for document {doc_uuid}: {e}")
            raise RuntimeError("Failed to store document file.")

        nuevo_documento = DocumentoLegal(
            id=doc_uuid,
            oportunidad_id=oportunidad_id,
            tenant_id=tenant_id,
            ruta_archivo=path,
            estado=EstadoDocumento.PENDIENTE,
            info_firma=info_firma,
            hash_integridad=hash_integridad,
        )

        db.add(nuevo_documento)
        db.commit()
        db.refresh(nuevo_documento)

        return nuevo_documento
