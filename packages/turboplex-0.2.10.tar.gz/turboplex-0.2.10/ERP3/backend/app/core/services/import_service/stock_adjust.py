from __future__ import annotations

import hashlib
import json
import re
from decimal import Decimal
from enum import Enum
from io import BytesIO
from typing import Any, cast
from uuid import UUID

import pandas as pd
import uuid6
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError
from app.core_modules.inventario.stock.models import Inventario, ProductVariant
from app.core_modules.sistema.models import AuditLog, Bodega, Sucursal
from app.core_modules.ventas.models import Producto
from app.core.services.ingestion_service import ChileanNormalizer
from app.core.services.import_service.stock_adjust_utils import (
    StockAdjustParsedRow,
    df_to_records_with_row_numbers,
    ensure_columns_exist,
    extract_camaleonic_attributes,
    normalize_bodega_codigo,
    normalize_column_name,
    normalize_sku,
    normalize_stock_adjust_mapping_json,
    parse_additional_attributes,
    parse_mapping,
    parse_sheet_name,
    resolve_fallback_bodega_id,
)
from app.models.staging import (
    ImportRun,
    ImportRunStatus,
    ImportTemplate,
    ImportTemplateType,
    StagingImport,
)
from sqlalchemy.dialects.postgresql import insert as pg_insert


def _canonicalize_additional_attributes(attrs: dict[str, Any] | None) -> str:
    if not attrs:
        return "{}"
    return json.dumps(attrs, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _hash_identity(attrs: dict[str, Any] | None) -> str:
    canonical = _canonicalize_additional_attributes(attrs)
    return hashlib.md5(canonical.encode("utf-8")).hexdigest()


class ImportMode(str, Enum):
    STOCK_ADJUST = "STOCK_ADJUST"


class ImportService:
    @staticmethod
    def stock_adjust_from_excel_dynamic_template(
        *,
        db: Session,
        empresa_id: UUID,
        content: bytes,
        mapping: dict[str, Any] | None = None,
        template_id: UUID | None = None,
        template_name: str | None = None,
        filename: str | None = None,
        sheet_name: str | int | None = 0,
        header: int = 0,
        staging_key: str | None = None,
        actor_id: UUID | None = None,
        reason: str | None = None,
    ) -> dict[str, Any]:
        prev_tenant = db.info.get("empresa_id", None)
        db.info["empresa_id"] = empresa_id
        try:
            mapping_source = "manual"
            used_mapping = mapping
            used_template_id: UUID | None = None
            used_template_name = (template_name or "").strip() or None
            if template_id is not None:
                template = (
                    db.execute(
                        select(ImportTemplate).where(
                            ImportTemplate.id == template_id,
                            ImportTemplate.empresa_id == empresa_id,
                        )
                    )
                    .scalars()
                    .first()
                )
                if template is None:
                    raise BusinessRuleError(
                        "Plantilla no encontrada", details={"template_id": str(template_id)}
                    )
                used_mapping = normalize_stock_adjust_mapping_json(template.mapping_json)
                mapping_source = "template"
                used_template_id = template.id
                used_template_name = template.nombre

            if used_mapping is None:
                raise ValueError("Debe proporcionar mapping_json o template_id")

            used_mapping = normalize_stock_adjust_mapping_json(used_mapping)
            try:
                parsed_mapping = parse_mapping(used_mapping)
            except ValueError as e:
                if mapping_source == "template":
                    raise BusinessRuleError(
                        "Plantilla sin mapping válido",
                        details={
                            "template_id": str(used_template_id)
                            if used_template_id
                            else None,
                            "error": str(e),
                        },
                    ) from e
                raise
            additional_mapping = parse_additional_attributes(used_mapping)
            used_staging_key = staging_key or f"DYNINV-{uuid6.uuid7().hex}"
            used_sheet = parse_sheet_name(sheet_name)

            df = pd.read_excel(BytesIO(content), sheet_name=used_sheet, header=header)
            if not isinstance(df, pd.DataFrame):
                raise ValueError("sheet_name debe referenciar una sola hoja (no dict de hojas)")
            df.columns = [normalize_column_name(c) for c in df.columns]
            ensure_columns_exist(df, parsed_mapping)

            file_hash = hashlib.sha256(content).hexdigest()
            existing_completed = (
                db.execute(
                    select(ImportRun)
                    .where(
                        ImportRun.empresa_id == empresa_id,
                        ImportRun.file_hash == file_hash,
                        ImportRun.status == ImportRunStatus.COMPLETED,
                    )
                    .limit(1)
                )
                .scalars()
                .first()
            )
            if existing_completed is not None:
                raise BusinessRuleError(
                    "Importación duplicada: el archivo ya fue aplicado (COMPLETED)",
                    details={
                        "empresa_id": str(empresa_id),
                        "file_hash": file_hash,
                        "existing_import_run_id": str(existing_completed.id),
                    },
                )

            import_run_id = uuid6.uuid7()
            fallback_bodega_id = resolve_fallback_bodega_id(db, empresa_id)
            run = ImportRun(
                id=import_run_id,
                empresa_id=empresa_id,
                bodega_id=fallback_bodega_id,
                filename=filename,
                file_hash=file_hash,
                status=ImportRunStatus.STARTED,
                summary={
                    "mode": ImportMode.STOCK_ADJUST.value,
                    "mapping": used_mapping,
                    "mapping_source": mapping_source,
                    "staging_key": used_staging_key,
                    "sheet_name": used_sheet,
                    "header": header,
                    "reason": reason,
                    "actor_id": str(actor_id) if actor_id else None,
                    "template_id": str(used_template_id) if used_template_id else None,
                    "template_name": used_template_name,
                },
            )
            db.add(run)
            db.commit()
            db.refresh(run)

            records = df_to_records_with_row_numbers(df, header)

            parsed_rows: list[StockAdjustParsedRow] = []
            row_errors: list[dict[str, Any]] = []
            core_excel_columns: set[str] = {
                parsed_mapping.sku,
                parsed_mapping.cantidad,
                parsed_mapping.bodega_codigo,
            }
            if parsed_mapping.costo_unitario:
                core_excel_columns.add(parsed_mapping.costo_unitario)

            for raw in records:
                row_number = int(raw.get("_row_number") or 0) or None
                additional_attrs = extract_camaleonic_attributes(
                    raw,
                    core_excel_columns=core_excel_columns,
                    explicit_mapping=additional_mapping,
                )
                raw_enriched = dict(raw)
                raw_enriched["_additional_attributes"] = additional_attrs
                try:
                    sku = normalize_sku(raw_enriched.get(parsed_mapping.sku))
                    if sku == "":
                        raise ValueError("SKU vacío")
                    bodega_codigo = normalize_bodega_codigo(
                        raw_enriched.get(parsed_mapping.bodega_codigo)
                    )
                    if bodega_codigo == "":
                        raise ValueError("Bodega código vacío")
                    cantidad_cell = raw_enriched.get(parsed_mapping.cantidad)
                    try:
                        cantidad_objetivo = ChileanNormalizer.parse_int(cantidad_cell)
                    except Exception as e:
                        s = str(cantidad_cell or "")
                        if re.search(r"[A-Za-zÁÉÍÓÚáéíóúÑñ]", s):
                            raise ValueError(
                                f"Error de tipo: la columna '{parsed_mapping.cantidad}' no es numérica"
                            ) from e
                        raise
                    if cantidad_objetivo < 0:
                        raise ValueError("Cantidad objetivo no puede ser negativa")
                    costo_unitario: Decimal | None = None
                    if parsed_mapping.costo_unitario:
                        costo_raw = raw_enriched.get(parsed_mapping.costo_unitario)
                        if costo_raw is not None and str(costo_raw).strip() != "":
                            costo_unitario = ChileanNormalizer.normalize_currency(costo_raw)
                    parsed_rows.append(
                        StockAdjustParsedRow(
                            row_number=int(row_number) if row_number else 0,
                            sku=sku,
                            cantidad_objetivo=cantidad_objetivo,
                            bodega_codigo=bodega_codigo,
                            costo_unitario=costo_unitario,
                            raw=raw_enriched,
                        )
                    )
                except Exception as e:
                    row_errors.append(
                        {
                            "row_number": row_number,
                            "kind": "row_parse_failed",
                            "error": str(e),
                            "raw": raw_enriched,
                        }
                    )

            sku_set = sorted({r.sku for r in parsed_rows})
            bodega_code_set = sorted({r.bodega_codigo for r in parsed_rows})

            products_by_sku: dict[str, Producto] = {}
            if sku_set:
                products = (
                    db.execute(
                        select(Producto).where(
                            Producto.empresa_id == empresa_id,
                            func.upper(Producto.sku).in_(sku_set),
                        )
                    )
                    .scalars()
                    .all()
                )
                for p in products:
                    if p.sku and p.sku not in products_by_sku:
                        products_by_sku[p.sku.upper()] = p

            bodegas_by_codigo: dict[str, Bodega] = {}
            if bodega_code_set:
                bodegas = (
                    db.execute(
                        select(Bodega)
                        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
                        .where(
                            Sucursal.empresa_id == empresa_id,
                            func.upper(Bodega.codigo).in_(bodega_code_set),
                        )
                    )
                    .scalars()
                    .all()
                )
                for b in bodegas:
                    if b.codigo:
                        bodegas_by_codigo[b.codigo.upper()] = b

            staging_error_mappings: list[dict[str, Any]] = []
            valid_rows: list[tuple[StockAdjustParsedRow, Producto, Bodega]] = []
            for r in parsed_rows:
                product = products_by_sku.get(r.sku)
                if product is None:
                    staging_error_mappings.append(
                        {
                            "id": uuid6.uuid7(),
                            "empresa_id": empresa_id,
                            "source_filename": used_staging_key,
                            "source_type": "dynamic_stock_adjust",
                            "status": "failed",
                            "raw_content": {"_row_number": r.row_number, **(r.raw or {})},
                            "error_log": {
                                "kind": "sku_not_found",
                                "sku": r.sku,
                                "row_number": r.row_number,
                            },
                        }
                    )
                    continue
                bodega = bodegas_by_codigo.get(r.bodega_codigo)
                if bodega is None:
                    staging_error_mappings.append(
                        {
                            "id": uuid6.uuid7(),
                            "empresa_id": empresa_id,
                            "source_filename": used_staging_key,
                            "source_type": "dynamic_stock_adjust",
                            "status": "failed",
                            "raw_content": {"_row_number": r.row_number, **(r.raw or {})},
                            "error_log": {
                                "kind": "bodega_not_found",
                                "bodega_codigo": r.bodega_codigo,
                                "row_number": r.row_number,
                            },
                        }
                    )
                    continue
                valid_rows.append((r, product, bodega))

            for err in row_errors:
                raw_err = err.get("raw")
                staging_error_mappings.append(
                    {
                        "id": uuid6.uuid7(),
                        "empresa_id": empresa_id,
                        "source_filename": used_staging_key,
                        "source_type": "dynamic_stock_adjust",
                        "status": "failed",
                        "raw_content": raw_err
                        if isinstance(raw_err, dict)
                        else {"_row_number": err.get("row_number")},
                        "error_log": err,
                    }
                )

            product_ids = sorted({p.id for _, p, _ in valid_rows}) if valid_rows else []
            bodega_ids = sorted({b.id for _, _, b in valid_rows}) if valid_rows else []

            desired_variant_payloads: dict[tuple[UUID, str], dict[str, Any]] = {}
            for r, product, _bodega in valid_rows:
                attrs = cast(dict[str, Any], (r.raw or {}).get("_additional_attributes") or {})
                hash_identity = _hash_identity(attrs)
                desired_variant_payloads[(product.id, hash_identity)] = {
                    "empresa_id": empresa_id,
                    "producto_id": product.id,
                    "hash_identity": hash_identity,
                    "attributes": attrs,
                }

            existing_variants: list[ProductVariant] = []
            if desired_variant_payloads:
                existing_variants = (
                    db.execute(
                        select(ProductVariant).where(
                            ProductVariant.producto_id.in_(product_ids),
                            ProductVariant.hash_identity.in_(sorted({h for (_pid, h) in desired_variant_payloads.keys()})),
                        )
                    )
                    .scalars()
                    .all()
                )
            variant_id_by_key: dict[tuple[UUID, str], UUID] = {
                (v.producto_id, cast(str, v.hash_identity)): v.id for v in existing_variants
            }

            missing_variant_rows: list[dict[str, Any]] = []
            for (pid, hid), payload in desired_variant_payloads.items():
                if (pid, hid) in variant_id_by_key:
                    continue
                missing_variant_rows.append(
                    {
                        "id": uuid6.uuid7(),
                        "empresa_id": payload["empresa_id"],
                        "producto_id": payload["producto_id"],
                        "hash_identity": payload["hash_identity"],
                        "attributes": payload["attributes"],
                        "sku_variant": None,
                    }
                )
            if missing_variant_rows:
                db.execute(
                    pg_insert(ProductVariant)
                    .values(missing_variant_rows)
                    .on_conflict_do_nothing(index_elements=[ProductVariant.producto_id, ProductVariant.hash_identity])
                )
                db.flush()
                refreshed = (
                    db.execute(
                        select(ProductVariant).where(
                            ProductVariant.producto_id.in_(product_ids),
                            ProductVariant.hash_identity.in_(sorted({r["hash_identity"] for r in missing_variant_rows})),
                        )
                    )
                    .scalars()
                    .all()
                )
                for v in refreshed:
                    variant_id_by_key[(v.producto_id, cast(str, v.hash_identity))] = v.id

            inv_by_key: dict[tuple[UUID, UUID], Inventario] = {}
            if bodega_ids and variant_id_by_key:
                existing_inventario = (
                    db.execute(
                        select(Inventario).where(
                            Inventario.variant_id.in_(sorted({vid for vid in variant_id_by_key.values()})),
                            Inventario.bodega_id.in_(bodega_ids),
                        )
                    )
                    .scalars()
                    .all()
                )
                for inv in existing_inventario:
                    inv_by_key[(inv.variant_id, inv.bodega_id)] = inv

            movements_created = 0
            stock_updates = 0
            affected_bodegas: set[str] = set()
            apply_errors: list[dict[str, Any]] = []
            template_action: str | None = None
            saved_template_id: UUID | None = used_template_id

            from app.core_modules.inventario.stock.services import InventoryService
            for r, product, bodega in valid_rows:
                try:
                    attrs = cast(dict[str, Any], (r.raw or {}).get("_additional_attributes") or {})
                    hash_identity = _hash_identity(attrs)
                    variant_id = variant_id_by_key.get((product.id, hash_identity))
                    if variant_id is None:
                        raise ValueError("Variante no resuelta")

                    inv_key = (variant_id, bodega.id)
                    inv = inv_by_key.get(inv_key)

                    desired_stock = int(r.cantidad_objetivo)
                    if inv is not None and desired_stock < int(inv.cantidad_reservada):
                        raise ValueError("Stock objetivo menor que cantidad reservada")

                    current_stock = int(inv.cantidad) if inv is not None else 0
                    delta = desired_stock - current_stock
                    if delta != 0:
                        if delta > 0:
                            InventoryService.release_stock(
                                db,
                                product.id,
                                bodega.id,
                                delta,
                                "IMPORT_AJUSTE",
                                empresa_id,
                                costo_unitario=r.costo_unitario,
                                variant_id=variant_id,
                                attributes=attrs,
                                import_run_id=import_run_id,
                                additional_attributes=attrs,
                            )
                        else:
                            InventoryService.consume_stock(
                                db,
                                product.id,
                                bodega.id,
                                abs(delta),
                                "IMPORT_AJUSTE",
                                empresa_id,
                                reference_id=str(import_run_id),
                                lote_id=None,
                                variant_id=variant_id,
                                attributes=attrs,
                                import_run_id=import_run_id,
                                additional_attributes=attrs,
                            )
                        if inv is None:
                            # refresh cache after first movement creates the row
                            inv = (
                                db.execute(
                                    select(Inventario).where(
                                        Inventario.variant_id == variant_id,
                                        Inventario.bodega_id == bodega.id,
                                    )
                                )
                                .scalars()
                                .first()
                            )
                            if inv is not None:
                                inv_by_key[inv_key] = inv
                        movements_created += 1
                        stock_updates += 1
                        affected_bodegas.add((bodega.codigo or "").upper())
                except Exception as e:
                    apply_errors.append(
                        {
                            "row_number": r.row_number,
                            "kind": "apply_failed",
                            "sku": r.sku,
                            "bodega_codigo": r.bodega_codigo,
                            "error": str(e),
                        }
                    )
                    staging_error_mappings.append(
                        {
                            "id": uuid6.uuid7(),
                            "empresa_id": empresa_id,
                            "source_filename": used_staging_key,
                            "source_type": "dynamic_stock_adjust",
                            "status": "failed",
                            "raw_content": {"_row_number": r.row_number, **(r.raw or {})},
                            "error_log": {
                                "kind": "apply_failed",
                                "sku": r.sku,
                                "bodega_codigo": r.bodega_codigo,
                                "row_number": r.row_number,
                                "error": str(e),
                            },
                        }
                    )

            if staging_error_mappings:
                db.bulk_insert_mappings(StagingImport.__mapper__, staging_error_mappings)

            db.commit()

            if mapping_source == "manual" and used_template_name and used_mapping:
                existing = (
                    db.execute(
                        select(ImportTemplate).where(
                            ImportTemplate.empresa_id == empresa_id,
                            func.lower(ImportTemplate.nombre) == used_template_name.lower(),
                        )
                    )
                    .scalars()
                    .first()
                )
                if existing is None:
                    existing = ImportTemplate(
                        id=uuid6.uuid7(),
                        empresa_id=empresa_id,
                        nombre=used_template_name,
                        tipo_importacion=ImportTemplateType.STOCK_ADJUST,
                        mapping_json=normalize_stock_adjust_mapping_json(used_mapping),
                    )
                    db.add(existing)
                    template_action = "created"
                else:
                    existing.tipo_importacion = ImportTemplateType.STOCK_ADJUST
                    existing.mapping_json = normalize_stock_adjust_mapping_json(used_mapping)
                    db.add(existing)
                    template_action = "updated"
                db.commit()
                saved_template_id = existing.id

            run.status = ImportRunStatus.COMPLETED
            run.summary = {
                "mode": ImportMode.STOCK_ADJUST.value,
                "mapping": used_mapping,
                "mapping_source": mapping_source,
                "staging_key": used_staging_key,
                "sheet_name": used_sheet,
                "header": header,
                "reason": reason,
                "actor_id": str(actor_id) if actor_id else None,
                "template_id": str(saved_template_id) if saved_template_id else None,
                "template_name": used_template_name,
                "template_action": template_action,
                "rows_total": len(records),
                "rows_parsed_ok": len(parsed_rows),
                "movements_created": movements_created,
                "stock_updates": stock_updates,
                "failed_rows": len(staging_error_mappings),
                "affected_bodegas_codigo": sorted([c for c in affected_bodegas if c]),
                "apply_errors": apply_errors[:200],
            }
            db.add(run)
            db.add(
                AuditLog(
                    actor_id=actor_id,
                    impersonated_user_id=None,
                    action="STOCK_ADJUST_TEMPLATE_IMPORT",
                    resource=f"Empresa:{empresa_id} ImportRun:{import_run_id}",
                    severity="INFO",
                    changes={
                        "reason": reason,
                        "import_run_id": str(import_run_id),
                        "staging_key": used_staging_key,
                        "mapping": used_mapping,
                        "template_id": str(saved_template_id) if saved_template_id else None,
                        "template_name": used_template_name,
                    },
                    ip_address=None,
                )
            )
            db.commit()

            return {
                "import_run_id": str(import_run_id),
                "staging_key": used_staging_key,
                "file_hash": file_hash,
                "rows_total": len(records),
                "movements_created": movements_created,
                "stock_updates": stock_updates,
                "failed_rows": len(staging_error_mappings),
                "template_id": str(saved_template_id) if saved_template_id else None,
                "template_action": template_action,
            }
        except Exception as e:
            db.rollback()
            try:
                run = (
                    db.execute(
                        select(ImportRun).where(
                            ImportRun.empresa_id == empresa_id,
                            ImportRun.file_hash == hashlib.sha256(content).hexdigest(),
                            ImportRun.status == ImportRunStatus.STARTED,
                        )
                    )
                    .scalars()
                    .first()
                )
                if run is not None:
                    run.status = ImportRunStatus.FAILED
                    run.summary = {
                        "mode": ImportMode.STOCK_ADJUST.value,
                        "mapping": mapping,
                        "staging_key": staging_key,
                        "error": str(e),
                    }
                    db.add(run)
                    db.commit()
            except Exception:
                db.rollback()
            raise
        finally:
            if prev_tenant is None:
                db.info.pop("empresa_id", None)
            else:
                db.info["empresa_id"] = prev_tenant
