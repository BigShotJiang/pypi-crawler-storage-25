"""
Métricas de Prometheus para observabilidad
"""

from prometheus_client import (
    Counter,
    Histogram,
    Gauge,
    generate_latest,
    CONTENT_TYPE_LATEST,
)
from fastapi import Request, Response
from typing import Callable, Dict, Any
from uuid import UUID
import time
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)

# ============================================================================
# MÉTRICAS HTTP
# ============================================================================

http_requests_total = Counter(
    "http_requests_total",
    "Total de requests HTTP",
    ["method", "endpoint", "status_code"],
)

http_request_duration_seconds = Histogram(
    "http_request_duration_seconds",
    "Duración de requests HTTP en segundos",
    ["method", "endpoint"],
    buckets=(0.01, 0.05, 0.1, 0.5, 1.0, 2.5, 5.0, 10.0),
)

http_errors_total = Counter(
    "http_errors_total", "Total de errores HTTP", ["method", "endpoint", "error_type"]
)

http_requests_by_company_total = Counter(
    "http_requests_by_company_total",
    "Total de requests HTTP por empresa (tenant)",
    ["empresa", "method", "endpoint", "status_code"],
)

http_errors_by_company_total = Counter(
    "http_errors_by_company_total",
    "Total de errores HTTP por empresa (tenant)",
    ["empresa", "method", "endpoint", "error_type"],
)

http_request_company_duration_seconds = Histogram(
    "http_request_company_duration_seconds",
    "Duración de requests HTTP por empresa (tenant) en segundos",
    ["empresa", "method", "endpoint"],
    buckets=(0.01, 0.05, 0.1, 0.5, 1.0, 2.5, 5.0, 10.0),
)

# ============================================================================
# MÉTRICAS DE NEGOCIO
# ============================================================================

ventas_total = Counter("ventas_total", "Total de ventas creadas", ["empresa_id"])

ventas_monto_total = Counter(
    "ventas_monto_total", "Monto total de ventas", ["empresa_id"]
)

ordenes_servicio_total = Counter(
    "ordenes_servicio_total", "Total de órdenes de servicio", ["empresa_id", "estado"]
)

asientos_contables_total = Counter(
    "asientos_contables_total",
    "Total de asientos contables generados",
    ["empresa_id", "origen"],
)

# ============================================================================
# MÉTRICAS DE SISTEMA
# ============================================================================

active_users = Gauge("active_users", "Usuarios activos actualmente")

cache_hits_total = Counter("cache_hits_total", "Total de cache hits", ["resource"])

cache_misses_total = Counter(
    "cache_misses_total", "Total de cache misses", ["resource"]
)

background_jobs_total = Counter(
    "background_jobs_total", "Total de background jobs", ["job_type", "status"]
)

# ============================================================================
# MIDDLEWARE
# ============================================================================

_company_perf: Dict[str, Dict[str, Any]] = defaultdict(
    lambda: {"requests": 0.0, "errors": 0.0, "duration_sum": 0.0}
)


async def metrics_middleware(
    request: Request, call_next: Callable[[Request], Any]
) -> Response:
    """Middleware para capturar métricas de requests"""

    if request.url.path == "/metrics":
        return await call_next(request)

    method = request.method
    endpoint = request.url.path
    empresa = request.query_params.get("cmp", "unknown")

    start_time = time.time()

    try:
        response_any = await call_next(request)
        response = response_any
        status_code = response.status_code

        duration = time.time() - start_time
        http_request_duration_seconds.labels(method=method, endpoint=endpoint).observe(
            duration
        )
        http_requests_total.labels(
            method=method, endpoint=endpoint, status_code=status_code
        ).inc()
        http_request_company_duration_seconds.labels(
            empresa=empresa, method=method, endpoint=endpoint
        ).observe(duration)
        http_requests_by_company_total.labels(
            empresa=empresa, method=method, endpoint=endpoint, status_code=status_code
        ).inc()

        perf = _company_perf[empresa]
        perf["requests"] += 1
        perf["duration_sum"] += duration

        if status_code >= 400:
            error_type = "client_error" if status_code < 500 else "server_error"
            http_errors_total.labels(
                method=method, endpoint=endpoint, error_type=error_type
            ).inc()
            http_errors_by_company_total.labels(
                empresa=empresa, method=method, endpoint=endpoint, error_type=error_type
            ).inc()
            _company_perf[empresa]["errors"] += 1

        return response

    except Exception:
        duration = time.time() - start_time
        http_request_duration_seconds.labels(method=method, endpoint=endpoint).observe(
            duration
        )
        http_errors_total.labels(
            method=method, endpoint=endpoint, error_type="exception"
        ).inc()
        http_request_company_duration_seconds.labels(
            empresa=empresa, method=method, endpoint=endpoint
        ).observe(duration)
        http_errors_by_company_total.labels(
            empresa=empresa, method=method, endpoint=endpoint, error_type="exception"
        ).inc()
        _company_perf[empresa]["requests"] += 1
        _company_perf[empresa]["errors"] += 1
        _company_perf[empresa]["duration_sum"] += duration
        raise


# ============================================================================
# FUNCIONES DE UTILIDAD
# ============================================================================


def record_venta(empresa_id: UUID, monto: float) -> None:
    """Registra una venta en las métricas"""
    ventas_total.labels(empresa_id=str(empresa_id)).inc()
    ventas_monto_total.labels(empresa_id=str(empresa_id)).inc(monto)


def record_orden_servicio(empresa_id: UUID, estado: str) -> None:
    """Registra una orden de servicio en las métricas"""
    ordenes_servicio_total.labels(empresa_id=str(empresa_id), estado=estado).inc()


def record_asiento_contable(empresa_id: UUID, origen: str) -> None:
    """Registra un asiento contable en las métricas"""
    asientos_contables_total.labels(empresa_id=str(empresa_id), origen=origen).inc()


def get_company_perf_snapshot() -> Dict[str, Dict[str, float]]:
    """Devuelve un snapshot de rendimiento por empresa"""
    snapshot = {}
    for empresa, data in _company_perf.items():
        reqs = data["requests"]
        errs = data["errors"]
        dur = data["duration_sum"]
        snapshot[empresa] = {
            "requests": reqs,
            "errors": errs,
            "error_rate": (errs / reqs) if reqs > 0 else 0.0,
            "avg_duration_ms": (dur / reqs * 1000) if reqs > 0 else 0.0,
        }
    return snapshot


def get_metrics() -> Response:
    """Devuelve las métricas actuales en formato Prometheus"""
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
