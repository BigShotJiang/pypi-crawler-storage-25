import time
import logging
from sqlalchemy import event
from sqlalchemy.engine import Engine

telemetry_logger = logging.getLogger("db_telemetry")
handler = logging.StreamHandler()
handler.setFormatter(
    logging.Formatter("[%(asctime)s] [DB-TELEMETRY] %(levelname)s: %(message)s")
)
telemetry_logger.addHandler(handler)
telemetry_logger.setLevel(logging.INFO)

SLOW_QUERY_THRESHOLD = 0.5


def setup_db_telemetry(engine: Engine):
    """
    Instala hooks en el engine de SQLAlchemy para medir tiempos de consulta.
    """

    @event.listens_for(engine, "before_cursor_execute")
    def before_cursor_execute(
        conn, cursor, statement, parameters, context, executemany
    ):
        conn.info.setdefault("query_start_time", []).append(time.time())

    @event.listens_for(engine, "after_cursor_execute")
    def after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
        total_time = time.time() - conn.info["query_start_time"].pop(-1)

        if total_time > SLOW_QUERY_THRESHOLD:
            telemetry_logger.warning(
                f"Consulta LENTA detectada ({total_time:.4f}s):\n"
                f"Query: {statement}\n"
                f"Params: {parameters}"
            )
