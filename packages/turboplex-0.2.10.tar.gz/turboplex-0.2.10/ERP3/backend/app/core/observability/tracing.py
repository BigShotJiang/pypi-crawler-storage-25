from typing import Optional
from fastapi import FastAPI
from app.core.config import settings


def init_tracing(app: FastAPI) -> None:
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter,
        )
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
    except Exception:
        return
    resource = Resource.create(
        {"service.name": "erp3-backend", "service.environment": settings.ENVIRONMENT}
    )
    provider = TracerProvider(resource=resource)
    endpoint = None
    exporter: Optional[OTLPSpanExporter] = None
    if endpoint:
        exporter = OTLPSpanExporter(endpoint=endpoint)
    tracer_provider = provider
    if exporter:
        tracer_provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(tracer_provider)
    FastAPIInstrumentor.instrument_app(app, tracer_provider=tracer_provider)
    HTTPXClientInstrumentor().instrument(tracer_provider=tracer_provider)


def set_tenant_span_attribute(empresa_id) -> None:
    try:
        from opentelemetry import trace
        span = trace.get_current_span()
        if span:
            span.set_attribute("tenant.id", str(empresa_id))
    except Exception:
        pass
