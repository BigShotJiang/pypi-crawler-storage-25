import logging
import sys
from app.core.config import settings


def setup_logging() -> None:
    """
    Configura el logging estructurado para la aplicación.
    Reemplaza el handler por defecto de uvicorn/fastapi para unificar formatos.
    """
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    log_level = logging.DEBUG if settings.ENVIRONMENT == "development" else logging.INFO

    logging.basicConfig(
        level=log_level, format=log_format, handlers=[logging.StreamHandler(sys.stdout)]
    )

    logging.getLogger("uvicorn.access").setLevel(logging.INFO)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

    logger = logging.getLogger("erp3.core")
    logger.info(f"Logging configurado. Nivel: {logging.getLevelName(log_level)}")
