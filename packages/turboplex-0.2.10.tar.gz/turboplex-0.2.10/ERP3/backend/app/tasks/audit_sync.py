import time
import logging
from app.core.config import settings

logger = logging.getLogger(__name__)


def sync_audit_log_to_external(audit_data: dict):
    """
    Tarea en segundo plano para enviar logs de auditoría a un servidor externo.
    Simula una replicación 'Streaming' a nivel de aplicación.
    """
    external_url = getattr(
        settings, "AUDIT_MIRROR_URL", "https://audit-mirror.example.com/api/logs"
    )
    getattr(settings, "AUDIT_MIRROR_API_KEY", "dummy-key")

    try:
        # Simulación de latencia de red (para demostrar que no bloquea el hilo principal)
        # En producción, esto sería una request real.
        logger.info(
            f"Replicando log {audit_data.get('resource')} - {audit_data.get('action')} a {external_url}..."
        )

        # headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        # response = requests.post(external_url, json=audit_data, headers=headers, timeout=5)
        # response.raise_for_status()

        # Simulamos éxito
        time.sleep(0.1)
        logger.info("Replicación exitosa.")
        return True
    except Exception as e:
        logger.error(f"Error replicando audit log: {e}")
        # Aquí podríamos implementar reintentos (retry) con RQ
        return False
