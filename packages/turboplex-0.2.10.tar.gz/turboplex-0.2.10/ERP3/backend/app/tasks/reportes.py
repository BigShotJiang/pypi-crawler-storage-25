import time
import logging
from uuid import UUID

logger = logging.getLogger(__name__)


def generar_reporte_mensual_pdf(reporte_id: str, usuario_id: UUID):
    """
    Tarea de ejemplo que simula la generación de un PDF pesado.
    """
    logger.info(
        f"[WORKER] Iniciando generación de reporte PDF {reporte_id} para usuario {usuario_id}..."
    )

    # Simular proceso pesado
    time.sleep(5)

    # Aquí iría la lógica real con ReportLab o similar

    logger.info(f"[WORKER] Reporte {reporte_id} generado exitosamente.")
    return f"Reporte {reporte_id} completado."
