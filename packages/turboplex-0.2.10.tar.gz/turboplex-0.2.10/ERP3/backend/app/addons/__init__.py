from __future__ import annotations

import os
from importlib import import_module

from fastapi import FastAPI
from fastapi.routing import APIRouter


DEFAULT_ENABLED_ADDONS: tuple[str, ...] = ("pos_retail", "portal")


def _iter_enabled_addon_names() -> list[str]:
    raw = os.getenv("ENABLED_ADDONS")
    if raw is None:
        return list(DEFAULT_ENABLED_ADDONS)
    names = [part.strip() for part in raw.split(",") if part.strip()]
    return names or list(DEFAULT_ENABLED_ADDONS)


def _load_addon_router(name: str) -> APIRouter:
    mod = import_module(f"app.addons.{name}.router")
    init_addon = getattr(mod, "init_addon", None)
    if callable(init_addon):
        init_addon()
    router = getattr(mod, "router", None)
    if router is None:
        raise RuntimeError(
            f"Addon '{name}' no expone 'router' en app.addons.{name}.router"
        )
    return router


def get_enabled_addon_routers() -> list[APIRouter]:
    routers: list[APIRouter] = []
    for name in _iter_enabled_addon_names():
        routers.append(_load_addon_router(name))
    return routers


def include_enabled_addon_routers(app: FastAPI, api_prefix: str) -> None:
    for router in get_enabled_addon_routers():
        app.include_router(router, prefix=api_prefix)

