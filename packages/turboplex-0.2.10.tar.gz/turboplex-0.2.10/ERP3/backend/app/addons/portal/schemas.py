from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, EmailStr, ConfigDict


class PortalLoginRequest(BaseModel):
    empresa_codigo: str
    email: EmailStr
    password: str

    model_config = ConfigDict(extra="forbid")


class PortalFileUrlRead(BaseModel):
    url: str

    model_config = ConfigDict(extra="forbid")


class PortalUserAdminCreate(BaseModel):
    cliente_id: UUID
    email: EmailStr
    password: str
    is_active: bool = True
    role: Literal["master", "buyer", "finance"] = "buyer"
    scope_sucursales: list[UUID] | None = None

    model_config = ConfigDict(extra="forbid")


class PortalUserAdminUpdate(BaseModel):
    is_active: bool | None = None
    role: Literal["master", "buyer", "finance"] | None = None
    scope_sucursales: list[UUID] | None = None

    model_config = ConfigDict(extra="forbid")


class PortalUserAdminResetPassword(BaseModel):
    password: str

    model_config = ConfigDict(extra="forbid")

class PortalChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

    model_config = ConfigDict(extra="forbid")


class PortalUserAdminRead(BaseModel):
    id: UUID
    empresa_id: UUID
    cliente_id: UUID
    email: EmailStr
    is_active: bool
    last_login_at: datetime | None = None
    role: Literal["master", "buyer", "finance"]
    scope_sucursales: list[UUID] | None = None
    created_at: datetime
    updated_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class PortalDocumentoTributarioRead(BaseModel):
    id: UUID
    empresa_id: UUID
    folio: int
    fecha_emision: date
    fecha_vencimiento: date | None = None
    receptor_rut: str | None = None
    receptor_razon_social: str | None = None
    monto_total: Decimal
    estado_sii: str
    fecha_creacion: datetime

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class PortalPaymentNotificationRead(BaseModel):
    id: UUID
    empresa_id: UUID
    cliente_id: UUID
    dte_id: UUID
    pago_batch_id: UUID | None = None
    monto: Decimal | None = None
    numero_operacion: str | None = None
    banco: str | None = None
    comprobante_path: str
    comprobante_mime_type: str | None = None
    estado: str
    created_at: datetime
    updated_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class PortalPaymentBatchStatusUpdateRequest(BaseModel):
    estado: Literal["APROBADA", "RECHAZADA"]

    model_config = ConfigDict(extra="forbid")


class PortalPaymentBatchStatusUpdateResult(BaseModel):
    pago_batch_id: UUID
    estado: Literal["APROBADA", "RECHAZADA"]
    updated_count: int

    model_config = ConfigDict(extra="forbid")


class PortalHistorialItemRead(BaseModel):
    tipo: Literal["DTE", "OC"]
    fecha: datetime

    dte_id: UUID | None = None
    tipo_dte: int | None = None
    folio: int | None = None
    pdf_url: str | None = None
    xml_url: str | None = None

    crm_documento_id: UUID | None = None
    oportunidad_id: UUID | None = None
    nombre_archivo: str | None = None
    file_url: str | None = None

    model_config = ConfigDict(extra="forbid")


class PortalQuoteDraftItemUpdate(BaseModel):
    item_id: UUID
    cantidad: int | None = None
    notas_tecnicas: str | None = None

    model_config = ConfigDict(extra="forbid")


class PortalQuoteDraftUpdateRequest(BaseModel):
    items: list[PortalQuoteDraftItemUpdate]

    model_config = ConfigDict(extra="forbid")
