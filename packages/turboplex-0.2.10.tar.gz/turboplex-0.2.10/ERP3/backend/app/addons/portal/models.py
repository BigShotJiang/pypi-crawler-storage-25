from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    JSON,
    Numeric,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
import uuid6

from app.core.database import Base, GUID
from app.core.utils.mixins import TimestampMixin


class PortalUser(Base, TimestampMixin):
    __tablename__ = "portal_users"
    __table_args__ = (
        UniqueConstraint("empresa_id", "email", name="uq_portal_users_empresa_email"),
    )

    id: Mapped[UUID] = mapped_column(
        GUID, primary_key=True, index=True, default=uuid6.uuid7
    )

    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    cliente_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("clientes.id"), nullable=False, index=True
    )

    email = Column(String, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    last_login_at = Column(DateTime(timezone=True), nullable=True)
    role = Column(String, nullable=False, default="buyer")
    scope_sucursales = Column(JSON, nullable=True)
    must_change_password = Column(Boolean, default=True, nullable=False)

    empresa = relationship("app.core_modules.sistema.models.Empresa")
    cliente = relationship("app.core_modules.ventas.models.Cliente")


class PortalPaymentNotification(Base, TimestampMixin):
    __tablename__ = "portal_payment_notifications"

    id: Mapped[UUID] = mapped_column(
        GUID, primary_key=True, index=True, default=uuid6.uuid7
    )

    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    cliente_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("clientes.id"), nullable=False, index=True
    )
    dte_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("documentos_tributarios.id"), nullable=False, index=True
    )

    pago_batch_id: Mapped[UUID | None] = mapped_column(GUID, nullable=True, index=True)
    monto = Column(Numeric(18, 2), nullable=True)
    numero_operacion = Column(String, nullable=True)
    banco = Column(String, nullable=True)

    comprobante_path = Column(String, nullable=False)
    comprobante_mime_type = Column(String, nullable=True)
    estado = Column(String, nullable=False, default="PENDIENTE")

    empresa = relationship("app.core_modules.sistema.models.Empresa")
    cliente = relationship("app.core_modules.ventas.models.Cliente")
    dte = relationship("app.core_modules.facturacion.models.DocumentoTributario")
