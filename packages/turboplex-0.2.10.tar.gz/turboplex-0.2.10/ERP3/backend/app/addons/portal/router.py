from fastapi import APIRouter

from app.addons.portal.routers.admin import router as admin_router
from app.addons.portal.routers.auth import router as auth_router
from app.addons.portal.routers.documents import router as documents_router
from app.addons.portal.routers.quotes import router as quotes_router

router = APIRouter(prefix="/portal/v1", tags=["Portal"])

router.include_router(auth_router)
router.include_router(quotes_router)
router.include_router(documents_router)
router.include_router(admin_router)

