"""DEPRECATED: usar app.addons.portal.router.

Este archivo se mantiene temporalmente como shim para no romper imports existentes.
"""

from app.addons.portal import router as portal_router

router = portal_router.router
