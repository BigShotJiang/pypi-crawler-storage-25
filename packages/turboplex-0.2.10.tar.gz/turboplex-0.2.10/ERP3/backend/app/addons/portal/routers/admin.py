from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import desc
from sqlalchemy.orm import Session

from app.addons.portal import schemas as portal_schemas
from app.addons.portal.models import PortalPaymentNotification, PortalUser
from app.api import deps
from app.core import security
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts
from app.core_modules.ventas import portal_contracts as ventas_portal_contracts
from app.core_modules.sistema import schemas as sistema_schemas
from datetime import timedelta

router = APIRouter(tags=["Portal Admin"])

ALLOWED_PORTAL_ADMIN_COMPANY_ROLES = {"ADM", "VEN"}
BLOCKED_PORTAL_ADMIN_COMPANY_ROLES = {"BOD"}
PORTAL_PAYMENTS_ADMIN_ONLY_ROLES = [
    deps.UserRole.ADMIN,
]

def portal_users_admin_required(
    db: Session = Depends(deps.get_db),
    current_user=Depends(deps.get_current_user),
    current_company=Depends(deps.get_current_active_company),
):
    if current_user.role in {
        deps.UserRole.SUPERADMIN,
        deps.UserRole.DEVELOPER,
        deps.UserRole.ADMIN,
    }:
        return current_user

    codigo = sistema_portal_contracts.get_usuario_empresa_rol_codigo(
        db, usuario_id=current_user.id, empresa_id=current_company.id
    )

    if codigo in BLOCKED_PORTAL_ADMIN_COMPANY_ROLES:
        raise HTTPException(status_code=403, detail="No autorizado")

    if codigo not in ALLOWED_PORTAL_ADMIN_COMPANY_ROLES:
        raise HTTPException(status_code=403, detail="No autorizado")

    return current_user


@router.get(
    "/admin/users/{portal_user_id}",
    response_model=portal_schemas.PortalUserAdminRead,
)
def get_portal_user_admin(
    portal_user_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user=Depends(portal_users_admin_required),
    current_company=Depends(deps.get_current_active_company),
) -> PortalUser:
    record = (
        db.query(PortalUser)
        .filter(
            PortalUser.id == portal_user_id, PortalUser.empresa_id == current_company.id
        )
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="PortalUser no encontrado")
    return record


@router.post(
    "/admin/users",
    response_model=portal_schemas.PortalUserAdminRead,
    status_code=201,
)
def create_portal_user_admin(
    payload: portal_schemas.PortalUserAdminCreate,
    db: Session = Depends(deps.get_db),
    current_user=Depends(portal_users_admin_required),
    current_company=Depends(deps.get_current_active_company),
) -> PortalUser:
    if not ventas_portal_contracts.cliente_exists(
        db, empresa_id=current_company.id, cliente_id=payload.cliente_id
    ):
        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    existing = (
        db.query(PortalUser)
        .filter(
            PortalUser.empresa_id == current_company.id,
            PortalUser.email == payload.email,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail="Ya existe un PortalUser con ese email en esta empresa",
        )

    record = PortalUser(
        empresa_id=current_company.id,
        cliente_id=payload.cliente_id,
        email=str(payload.email),
        hashed_password=security.get_password_hash(payload.password),
        is_active=payload.is_active,
        role=payload.role,
        scope_sucursales=(
            None
            if payload.role == "master"
            else (
                [str(sid) for sid in payload.scope_sucursales]
                if payload.scope_sucursales
                else None
            )
        ),
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get(
    "/admin/users",
    response_model=list[portal_schemas.PortalUserAdminRead],
)
def list_portal_users_admin(
    cliente_id: UUID | None = Query(None),
    limit: int = Query(200, gt=0, le=500),
    db: Session = Depends(deps.get_db),
    current_user=Depends(portal_users_admin_required),
    current_company=Depends(deps.get_current_active_company),
) -> list[PortalUser]:
    query = db.query(PortalUser).filter(PortalUser.empresa_id == current_company.id)
    if cliente_id:
        query = query.filter(PortalUser.cliente_id == cliente_id)
    return query.order_by(desc(PortalUser.created_at)).limit(limit).all()


@router.patch(
    "/admin/users/{portal_user_id}",
    response_model=portal_schemas.PortalUserAdminRead,
)
def update_portal_user_admin(
    portal_user_id: UUID,
    payload: portal_schemas.PortalUserAdminUpdate,
    db: Session = Depends(deps.get_db),
    current_user=Depends(portal_users_admin_required),
    current_company=Depends(deps.get_current_active_company),
) -> PortalUser:
    record = (
        db.query(PortalUser)
        .filter(
            PortalUser.id == portal_user_id, PortalUser.empresa_id == current_company.id
        )
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="PortalUser no encontrado")

    updates = payload.model_dump(exclude_unset=True)
    if updates.get("is_active") is not None:
        record.is_active = updates["is_active"]
    if updates.get("role") is not None:
        record.role = updates["role"]
        if record.role == "master":
            record.scope_sucursales = None

    if "scope_sucursales" in updates:
        if record.role == "master":
            record.scope_sucursales = None
        else:
            scope = updates["scope_sucursales"]
            record.scope_sucursales = [str(sid) for sid in scope] if scope else None

    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.post(
    "/admin/users/{portal_user_id}/reset-password",
    response_model=portal_schemas.PortalUserAdminRead,
)
def reset_portal_user_password_admin(
    portal_user_id: UUID,
    payload: portal_schemas.PortalUserAdminResetPassword,
    db: Session = Depends(deps.get_db),
    current_user=Depends(portal_users_admin_required),
    current_company=Depends(deps.get_current_active_company),
) -> PortalUser:
    record = (
        db.query(PortalUser)
        .filter(
            PortalUser.id == portal_user_id, PortalUser.empresa_id == current_company.id
        )
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="PortalUser no encontrado")

    record.hashed_password = security.get_password_hash(payload.password)
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.delete(
    "/admin/users/{portal_user_id}",
    status_code=204,
)
def delete_portal_user_admin(
    portal_user_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user=Depends(portal_users_admin_required),
    current_company=Depends(deps.get_current_active_company),
) -> None:
    record = (
        db.query(PortalUser)
        .filter(PortalUser.id == portal_user_id, PortalUser.empresa_id == current_company.id)
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="PortalUser no encontrado")
    db.delete(record)
    db.commit()


@router.get(
    "/admin/pagos/notificaciones",
    response_model=list[portal_schemas.PortalPaymentNotificationRead],
)
def list_portal_payment_notifications_admin(
    estado: str | None = Query(None),
    limit: int = Query(100, gt=0, le=500),
    db: Session = Depends(deps.get_db),
    current_user=deps.role_required(PORTAL_PAYMENTS_ADMIN_ONLY_ROLES),
    current_company=Depends(deps.get_current_active_company),
) -> list[PortalPaymentNotification]:
    query = db.query(PortalPaymentNotification).filter(
        PortalPaymentNotification.empresa_id == current_company.id
    )
    if estado:
        query = query.filter(PortalPaymentNotification.estado == estado)
    query = query.order_by(desc(PortalPaymentNotification.created_at)).limit(limit)
    return query.all()


@router.patch(
    "/admin/pagos/lotes/{pago_batch_id}",
    response_model=portal_schemas.PortalPaymentBatchStatusUpdateResult,
)
def update_portal_payment_batch_status_admin(
    pago_batch_id: UUID,
    payload: portal_schemas.PortalPaymentBatchStatusUpdateRequest,
    db: Session = Depends(deps.get_db),
    current_user=deps.role_required(PORTAL_PAYMENTS_ADMIN_ONLY_ROLES),
    current_company=Depends(deps.get_current_active_company),
) -> portal_schemas.PortalPaymentBatchStatusUpdateResult:
    records = (
        db.query(PortalPaymentNotification)
        .filter(
            PortalPaymentNotification.empresa_id == current_company.id,
            PortalPaymentNotification.pago_batch_id == pago_batch_id,
        )
        .all()
    )
    if not records:
        raise HTTPException(status_code=404, detail="Lote no encontrado")

    for r in records:
        r.estado = payload.estado
        db.add(r)

    db.commit()
    return portal_schemas.PortalPaymentBatchStatusUpdateResult(
        pago_batch_id=pago_batch_id,
        estado=payload.estado,
        updated_count=len(records),
    )


@router.post(
    "/admin/impersonate",
    response_model=sistema_schemas.Token,
)
def impersonate_portal_user(
    portal_user_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user=Depends(deps.get_current_superadmin),
    current_company=Depends(deps.get_current_active_company),
) -> sistema_schemas.Token:
    record = (
        db.query(PortalUser)
        .filter(
            PortalUser.id == portal_user_id,
            PortalUser.empresa_id == current_company.id,
        )
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="PortalUser no encontrado")

    access_token_expires = timedelta(minutes=15)
    token = security.create_access_token(
        subject=record.id,
        expires_delta=access_token_expires,
        extra_claims={
            "aud": "portal",
            "empresa_id": str(record.empresa_id),
            "cliente_id": str(record.cliente_id),
            "role": record.role,
            "must_change_password": False,
            "impersonated_by": str(current_user.id),
        },
    )
    return sistema_schemas.Token(access_token=token, token_type="bearer")
