from io import BytesIO
from uuid import UUID

import uuid6
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from sqlalchemy.orm import Session

from app.addons.portal.deps import (
    get_current_portal_user,
    get_portal_allowed_sucursal_ids,
)
from app.addons.portal.models import PortalUser
from app.addons.portal import schemas as portal_schemas
from app.core.database import get_db
from app.core_modules.crm import schemas as crm_schemas
from app.core_modules.crm import portal_contracts as crm_portal_contracts
from app.core.services.storage_service import StorageService

router = APIRouter()


@router.get(
    "/mis-cotizaciones",
    response_model=list[crm_schemas.QuoteRead],
    tags=["Portal"],
)
def mis_cotizaciones(
    limit: int = Query(100, gt=0, le=200),
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> list[crm_schemas.QuoteRead]:
    if portal_user.role not in {"buyer", "master"}:
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    return crm_portal_contracts.list_cotizaciones_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        allowed_sucursal_ids=allowed_sucursales,
        limit=limit,
    )



@router.get(
    "/cotizaciones/{cotizacion_id}",
    response_model=crm_schemas.QuoteDetailRead,
    tags=["Portal"],
)
def cotizacion_detalle(
    cotizacion_id: UUID,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> object:
    if portal_user.role not in {"buyer", "master"}:
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    quote = crm_portal_contracts.get_cotizacion_detail_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        allowed_sucursal_ids=allowed_sucursales,
        cotizacion_id=cotizacion_id,
    )
    if not quote:
        raise HTTPException(status_code=404, detail="Cotización no encontrada")
    return quote


@router.put(
    "/cotizaciones/{cotizacion_id}/borrador",
    response_model=crm_schemas.QuoteDetailRead,
    tags=["Portal"],
)
def actualizar_borrador_cliente(
    cotizacion_id: UUID,
    payload: portal_schemas.PortalQuoteDraftUpdateRequest,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> object:
    if portal_user.role not in {"buyer", "master"}:
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    try:
        return crm_portal_contracts.update_quote_draft_for_portal(
            db,
            empresa_id=portal_user.empresa_id,
            cliente_id=portal_user.cliente_id,
            allowed_sucursal_ids=allowed_sucursales,
            cotizacion_id=cotizacion_id,
            updates=[
                crm_portal_contracts.PortalQuoteItemUpdate(
                    item_id=u.item_id, cantidad=u.cantidad, notas_tecnicas=u.notas_tecnicas
                )
                for u in payload.items
            ],
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post(
    "/cotizaciones/{cotizacion_id}/enviar-propuesta",
    response_model=crm_schemas.QuoteRead,
    tags=["Portal"],
)
def enviar_propuesta_cliente(
    cotizacion_id: UUID,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> object:
    if portal_user.role not in {"buyer", "master"}:
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    try:
        return crm_portal_contracts.send_quote_proposal_for_portal(
            db,
            empresa_id=portal_user.empresa_id,
            cliente_id=portal_user.cliente_id,
            allowed_sucursal_ids=allowed_sucursales,
            cotizacion_id=cotizacion_id,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post(
    "/cotizaciones/{cotizacion_id}/items/{item_id}/rechazar",
    response_model=crm_schemas.QuoteDetailRead,
    tags=["Portal"],
)
def rechazar_item_cliente(
    cotizacion_id: UUID,
    item_id: UUID,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> object:
    if portal_user.role not in {"buyer", "master"}:
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    try:
        return crm_portal_contracts.reject_quote_item_for_portal(
            db,
            empresa_id=portal_user.empresa_id,
            cliente_id=portal_user.cliente_id,
            allowed_sucursal_ids=allowed_sucursales,
            cotizacion_id=cotizacion_id,
            item_id=item_id,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post(
    "/cotizaciones/{cotizacion_id}/aceptar",
    response_model=crm_schemas.QuoteRead,
    tags=["Portal"],
)
async def aceptar_cotizacion(
    cotizacion_id: UUID,
    oc_file: UploadFile = File(...),
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> object:
    if portal_user.role not in {"buyer", "master"}:
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)

    content = await oc_file.read()
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Archivo excede 2MB")
    if not content.startswith(b"%PDF"):
        raise HTTPException(status_code=400, detail="Archivo debe ser PDF")

    storage = StorageService()
    file_id = uuid6.uuid7()
    path = (
        f"portal/{portal_user.empresa_id}/clientes/{portal_user.cliente_id}/"
        f"cotizaciones/{cotizacion_id}/oc/{file_id}.pdf"
    )
    stored_path = storage.upload_file(BytesIO(content), path)
    try:
        return crm_portal_contracts.accept_quote_with_oc_for_portal(
            db,
            empresa_id=portal_user.empresa_id,
            cliente_id=portal_user.cliente_id,
            allowed_sucursal_ids=allowed_sucursales,
            cotizacion_id=cotizacion_id,
            stored_path=stored_path,
            original_filename=oc_file.filename or f"oc_{file_id}.pdf",
            mime_type=oc_file.content_type,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
