from __future__ import annotations

from pathlib import Path
from urllib.parse import quote
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.addons.portal.deps import get_current_portal_user, get_portal_allowed_sucursal_ids
from app.addons.portal.models import PortalUser
from app.core.database import get_db
from app.core_modules.crm import portal_contracts as crm_portal_contracts
from app.core.services.storage_service import StorageService


router = APIRouter()


def safe_local_full_path(storage: StorageService, relative_path: str) -> str:
    base = Path(storage.local_path).resolve()
    target = (base / relative_path).resolve()
    if base not in target.parents and base != target:
        raise HTTPException(status_code=400, detail="Path inválido")
    return str(target)


def build_download_url(request: Request, relative_path: str) -> str:
    base = str(request.url_for("portal_storage_download"))
    return f"{base}?path={quote(relative_path)}"


@router.get("/storage/download", name="portal_storage_download", tags=["Portal"])
def portal_storage_download(
    path: str,
    request: Request,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
):
    expected_prefix = (
        f"portal/{portal_user.empresa_id}/clientes/{portal_user.cliente_id}/"
    )
    if not path.startswith(expected_prefix):
        raise HTTPException(status_code=404, detail="Archivo no encontrado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    if "/cotizaciones/" in path and "/oc/" in path:
        parts = path.split("/cotizaciones/", 1)[1]
        quote_id = parts.split("/", 1)[0]
        try:
            quote_uuid = UUID(quote_id)
        except Exception:
            raise HTTPException(status_code=404, detail="Archivo no encontrado")

        quote = crm_portal_contracts.get_cotizacion_for_portal(
            db,
            empresa_id=portal_user.empresa_id,
            cliente_id=portal_user.cliente_id,
            allowed_sucursal_ids=allowed_sucursales,
            cotizacion_id=quote_uuid,
        )
        if not quote:
            raise HTTPException(status_code=404, detail="Archivo no encontrado")

    storage = StorageService()
    if storage.mode == "s3":
        raise HTTPException(
            status_code=400, detail="Descarga directa no disponible en modo S3"
        )

    full_path = safe_local_full_path(storage, path)
    file_path = Path(full_path)
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(status_code=404, detail="Archivo no encontrado")

    content_type = "application/octet-stream"
    if path.endswith(".pdf"):
        content_type = "application/pdf"
    elif path.endswith(".png"):
        content_type = "image/png"
    elif path.endswith(".jpg") or path.endswith(".jpeg"):
        content_type = "image/jpeg"

    return FileResponse(
        str(file_path), media_type=content_type, filename=file_path.name
    )

