from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.addons.portal import schemas as portal_schemas
from app.addons.portal.models import PortalUser
from app.core import security
from app.core.config import settings
from app.core.database import get_db
from app.core_modules.sistema import schemas as sistema_schemas
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts
from app.addons.portal.deps import get_current_portal_user
from app.core.database.models import RevokedToken
from jose import jwt

router = APIRouter()


@router.post("/auth/login", response_model=sistema_schemas.Token, tags=["Portal Auth"])
def portal_login(
    payload: portal_schemas.PortalLoginRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> sistema_schemas.Token:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        result = sistema_portal_contracts.get_empresa_for_portal_login(
            db, empresa_codigo=payload.empresa_codigo
        )
        if not result:
            raise HTTPException(status_code=400, detail="Empresa no encontrada")
        empresa_id, empresa_is_active = result
        if not empresa_is_active:
            raise HTTPException(status_code=400, detail="Empresa no encontrada")

        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant

        db.info["empresa_id"] = empresa_id

        portal_user = (
            db.query(PortalUser)
            .filter(
                PortalUser.empresa_id == empresa_id,
                PortalUser.email == payload.email,
            )
            .first()
        )
        if not portal_user or not portal_user.is_active:
            raise HTTPException(status_code=400, detail="Email o password incorrecto")

        if not security.verify_password(payload.password, portal_user.hashed_password):
            raise HTTPException(status_code=400, detail="Email o password incorrecto")

        portal_user.last_login_at = datetime.now(timezone.utc)
        db.add(portal_user)
        db.commit()

        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        token = security.create_access_token(
            subject=portal_user.id,
            expires_delta=access_token_expires,
            extra_claims={
                "aud": "portal",
                "empresa_id": str(portal_user.empresa_id),
                "cliente_id": str(portal_user.cliente_id),
                "role": portal_user.role,
                "must_change_password": bool(portal_user.must_change_password),
            },
        )
        return sistema_schemas.Token(access_token=token, token_type="bearer")
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router.post("/auth/change-password", tags=["Portal Auth"])
def portal_change_password(
    payload: portal_schemas.PortalChangePasswordRequest,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> dict:
    if not security.verify_password(payload.current_password, portal_user.hashed_password):
        raise HTTPException(status_code=400, detail="Password actual incorrecto")
    portal_user.hashed_password = security.get_password_hash(payload.new_password)
    portal_user.must_change_password = False
    db.add(portal_user)
    db.commit()
    return {"message": "Password actualizado"}


@router.post("/auth/logout", tags=["Portal Auth"])
def portal_logout(
    request: Request,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> dict:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token inválido")
    token = auth.replace("Bearer ", "", 1).strip()
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
            audience="portal",
        )
    except Exception:
        raise HTTPException(status_code=401, detail="Token inválido")
    jti = payload.get("jti")
    exp = payload.get("exp")
    if not jti:
        raise HTTPException(status_code=400, detail="Token sin JTI")
    exists = db.query(RevokedToken).filter(RevokedToken.jti == str(jti)).first()
    if not exists:
        rec = RevokedToken(
            jti=str(jti),
            audience="portal",
            subject=str(portal_user.id),
            empresa_id=str(portal_user.empresa_id),
            cliente_id=str(portal_user.cliente_id),
            expires_at=datetime.fromtimestamp(exp, tz=timezone.utc) if exp else None,
        )
        db.add(rec)
        db.commit()
    return {"message": "Logout exitoso"}
