"""DEPRECATED: este módulo se mantiene como agregador de subrouters.

Se separó para cumplir el límite de 600 líneas y para minimizar imports a core_modules
desde el addon portal.
"""

from fastapi import APIRouter

from app.addons.portal.routers.documents_dtes import router as dtes_router
from app.addons.portal.routers.documents_payments import router as payments_router
from app.addons.portal.routers.documents_quotes import router as quotes_router
from app.addons.portal.routers.documents_storage import router as storage_router


router = APIRouter()

router.include_router(quotes_router)
router.include_router(payments_router)
router.include_router(dtes_router)
router.include_router(storage_router)
