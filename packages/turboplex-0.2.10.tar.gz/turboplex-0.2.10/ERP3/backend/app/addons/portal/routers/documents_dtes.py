from __future__ import annotations

from datetime import datetime, time, timezone
from uuid import UUID

from sqlalchemy import inspect
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.addons.portal import schemas as portal_schemas
from app.addons.portal.deps import get_current_portal_user, get_portal_allowed_sucursal_ids
from app.addons.portal.models import PortalUser
from app.addons.portal.routers.documents_storage import build_download_url
from app.core.database import get_db
from app.core_modules.crm import portal_contracts as crm_portal_contracts
from app.core_modules.facturacion import portal_contracts as facturacion_portal_contracts
from app.core_modules.ventas import portal_contracts as ventas_portal_contracts
from app.core.services.storage_service import StorageService


router = APIRouter()


def to_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def get_portal_receptor_rut(db: Session, portal_user: PortalUser) -> str:
    try:
        return ventas_portal_contracts.get_cliente_rut(
            db, empresa_id=portal_user.empresa_id, cliente_id=portal_user.cliente_id
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get(
    "/mis-facturas",
    response_model=list[portal_schemas.PortalDocumentoTributarioRead],
    tags=["Portal"],
)
def mis_facturas(
    limit: int = Query(100, gt=0, le=200),
    include_boletas: bool = Query(False),
    include_guias: bool = Query(False),
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
):
    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)

    tipos = [33, 34]
    if include_boletas:
        tipos.append(39)
    if include_guias:
        tipos.append(52)

    return facturacion_portal_contracts.list_dtes_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        tipos=tipos,
        limit=limit,
    )


@router.get(
    "/dtes/{dte_id}/pdf",
    name="portal_dte_pdf_download",
    tags=["Portal"],
)
def download_dte_pdf(
    dte_id: UUID,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> Response:
    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)

    dte = facturacion_portal_contracts.get_dte_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        dte_id=dte_id,
    )
    if not dte:
        raise HTTPException(status_code=404, detail="DTE no encontrado")
    if not dte.pdf_cedible:
        raise HTTPException(status_code=404, detail="PDF no disponible")

    filename = f"DTE_{dte.tipo_dte}_{dte.folio}.pdf"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(
        content=dte.pdf_cedible, media_type="application/pdf", headers=headers
    )


@router.get(
    "/dtes/{dte_id}/xml",
    name="portal_dte_xml_download",
    tags=["Portal"],
)
def download_dte_xml(
    dte_id: UUID,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> Response:
    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)

    dte = facturacion_portal_contracts.get_dte_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        dte_id=dte_id,
    )
    if not dte:
        raise HTTPException(status_code=404, detail="DTE no encontrado")
    if not dte.xml_firmado:
        raise HTTPException(status_code=404, detail="XML no disponible")

    filename = f"DTE_{dte.tipo_dte}_{dte.folio}.xml"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    content = dte.xml_firmado.encode("utf-8")
    return Response(content=content, media_type="application/xml", headers=headers)


@router.get(
    "/historial-documentos",
    response_model=list[portal_schemas.PortalHistorialItemRead],
    tags=["Portal"],
)
def historial_documentos(
    request: Request,
    limit: int = Query(200, gt=0, le=500),
    include_boletas: bool = Query(False),
    include_guias: bool = Query(True),
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> list[portal_schemas.PortalHistorialItemRead]:
    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)

    tipos = [33, 34]
    if include_boletas:
        tipos.append(39)
    if include_guias:
        tipos.append(52)

    dtes = facturacion_portal_contracts.list_dtes_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        tipos=tipos,
        limit=limit,
    )

    base_prefix = f"portal/{portal_user.empresa_id}/clientes/{portal_user.cliente_id}/cotizaciones/"
    inspector = inspect(db.get_bind())
    has_crm_docs = inspector.has_table("crm_documentos")
    has_crm_opps = inspector.has_table("crm_oportunidades")
    ocs = []
    if has_crm_docs and has_crm_opps:
        ocs = crm_portal_contracts.list_oc_documents_for_portal(
            db,
            empresa_id=portal_user.empresa_id,
            cliente_id=portal_user.cliente_id,
            allowed_sucursal_ids=allowed_sucursales,
            base_prefix=base_prefix,
            limit=limit,
        )

    items: list[portal_schemas.PortalHistorialItemRead] = []

    storage = StorageService()
    for dte in dtes:
        fecha = to_utc(datetime.combine(dte.fecha_emision, time.min))
        pdf_url = None
        if dte.pdf_cedible:
            pdf_url = str(request.url_for("portal_dte_pdf_download", dte_id=str(dte.id)))
        xml_url = None
        if dte.xml_firmado:
            xml_url = str(request.url_for("portal_dte_xml_download", dte_id=str(dte.id)))

        items.append(
            portal_schemas.PortalHistorialItemRead(
                tipo="DTE",
                fecha=fecha,
                dte_id=dte.id,
                tipo_dte=dte.tipo_dte,
                folio=dte.folio,
                pdf_url=pdf_url,
                xml_url=xml_url,
            )
        )

    for doc in ocs:
        if not doc.url_archivo:
            continue
        if storage.mode == "s3":
            file_url = storage.generate_presigned_url(doc.url_archivo)
        else:
            file_url = build_download_url(request, doc.url_archivo)

        items.append(
            portal_schemas.PortalHistorialItemRead(
                tipo="OC",
                fecha=to_utc(doc.created_at),
                crm_documento_id=doc.id,
                oportunidad_id=doc.oportunidad_id,
                nombre_archivo=doc.nombre_archivo,
                file_url=file_url,
            )
        )

    items.sort(key=lambda i: i.fecha, reverse=True)
    return items[:limit]

