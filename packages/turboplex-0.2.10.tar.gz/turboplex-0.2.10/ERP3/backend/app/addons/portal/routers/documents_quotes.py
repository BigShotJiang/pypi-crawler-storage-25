from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.addons.portal import schemas as portal_schemas
from app.addons.portal.deps import get_current_portal_user, get_portal_allowed_sucursal_ids
from app.addons.portal.models import PortalUser
from app.addons.portal.routers.documents_storage import build_download_url
from app.core.database import get_db
from app.core_modules.crm import portal_contracts as crm_portal_contracts
from app.core.services.storage_service import StorageService


router = APIRouter()


@router.get(
    "/cotizaciones/{cotizacion_id}/oc-url",
    response_model=portal_schemas.PortalFileUrlRead,
    tags=["Portal"],
)
def cotizacion_oc_url(
    cotizacion_id: UUID,
    request: Request,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> portal_schemas.PortalFileUrlRead:
    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    quote = crm_portal_contracts.get_cotizacion_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        allowed_sucursal_ids=allowed_sucursales,
        cotizacion_id=cotizacion_id,
    )
    if not quote:
        raise HTTPException(status_code=404, detail="Cotización no encontrada")

    expected_prefix = (
        f"portal/{portal_user.empresa_id}/clientes/{portal_user.cliente_id}/"
        f"cotizaciones/{quote.id}/oc/"
    )
    doc = crm_portal_contracts.get_latest_oc_document_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        oportunidad_id=quote.oportunidad_id,
        expected_prefix=expected_prefix,
    )
    if not doc or not doc.url_archivo:
        raise HTTPException(status_code=404, detail="OC no encontrada")

    storage = StorageService()
    if storage.mode == "s3":
        return portal_schemas.PortalFileUrlRead(
            url=storage.generate_presigned_url(doc.url_archivo)
        )
    return portal_schemas.PortalFileUrlRead(url=build_download_url(request, doc.url_archivo))

