from uuid import UUID
from typing import Any
from datetime import datetime, timezone

from fastapi import Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy import false, or_
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.addons.portal.models import PortalUser
from app.core.database.models import RevokedToken

reusable_oauth2_portal = OAuth2PasswordBearer(
    tokenUrl=f"{settings.API_V1_PREFIX}/portal/v1/auth/login"
)


def get_current_portal_user(
    request: Request,
    db: Session = Depends(get_db),
    token: str = Depends(reusable_oauth2_portal),
) -> PortalUser:
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
            audience="portal",
        )
        sub = payload.get("sub")
        empresa_id = payload.get("empresa_id")
        jti = payload.get("jti")
        impersonated_by = payload.get("impersonated_by")
        if not sub or not empresa_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido",
                headers={"WWW-Authenticate": "Bearer"},
            )
        db.info["current_user_id"] = str(sub)
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        user_uuid = UUID(str(sub))
        empresa_uuid = UUID(str(empresa_id))
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )

    current_tenant = db.info.get("empresa_id", None)
    if current_tenant is None:
        db.info["empresa_id"] = empresa_uuid
    elif current_tenant != empresa_uuid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if jti:
        revoked = (
            db.query(RevokedToken)
            .filter(RevokedToken.jti == str(jti))
            .first()
        )
        if revoked and (revoked.expires_at is None or revoked.expires_at > datetime.now(timezone.utc)):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido",
                headers={"WWW-Authenticate": "Bearer"},
            )

    user = (
        db.query(PortalUser)
        .filter(
            PortalUser.id == user_uuid,
            PortalUser.empresa_id == empresa_uuid,
        )
        .first()
    )
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales inválidas",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if user.must_change_password and not impersonated_by:
        path = request.url.path if request else ""
        allowed = [
            f"{settings.API_V1_PREFIX}/portal/v1/auth/change-password",
            f"{settings.API_V1_PREFIX}/portal/v1/auth/logout",
        ]
        if path not in allowed:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Debe cambiar su contraseña",
            )
    return user


def get_portal_allowed_sucursal_ids(
    db: Session, portal_user: PortalUser
) -> list[UUID] | None:
    if portal_user.role == "master":
        return None

    scope = portal_user.scope_sucursales or []
    if scope:
        return [UUID(str(sid)) for sid in scope]
    return []


def apply_portal_sucursal_scope(
    query: Any, allowed_sucursales: list[UUID] | None, sucursal_col: Any
) -> Any:
    if allowed_sucursales is None:
        return query
    if not allowed_sucursales:
        return query.filter(false())
    return query.filter(or_(sucursal_col.is_(None), sucursal_col.in_(allowed_sucursales)))
