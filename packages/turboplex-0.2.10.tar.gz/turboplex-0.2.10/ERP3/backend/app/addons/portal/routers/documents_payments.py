from __future__ import annotations

from decimal import Decimal
from io import BytesIO
from uuid import UUID

import uuid6
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from sqlalchemy.orm import Session

from app.addons.portal import schemas as portal_schemas
from app.addons.portal.deps import get_current_portal_user, get_portal_allowed_sucursal_ids
from app.addons.portal.models import PortalPaymentNotification, PortalUser
from app.addons.portal.routers.documents_storage import build_download_url
from app.core.database import get_db
from app.core_modules.facturacion import portal_contracts as facturacion_portal_contracts
from app.core_modules.ventas import portal_contracts as ventas_portal_contracts
from app.core.services.storage_service import StorageService


router = APIRouter()


def detect_upload_ext_and_mime(
    content: bytes, content_type: str | None
) -> tuple[str, str | None]:
    if content.startswith(b"%PDF"):
        return "pdf", "application/pdf"
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png", "image/png"
    if content.startswith(b"\xff\xd8\xff"):
        return "jpg", "image/jpeg"
    if content_type in {"application/pdf", "image/png", "image/jpeg"}:
        if content_type == "application/pdf":
            return "pdf", content_type
        if content_type == "image/png":
            return "png", content_type
        if content_type == "image/jpeg":
            return "jpg", content_type
    return "", content_type


def get_portal_receptor_rut(db: Session, portal_user: PortalUser) -> str:
    try:
        return ventas_portal_contracts.get_cliente_rut(
            db, empresa_id=portal_user.empresa_id, cliente_id=portal_user.cliente_id
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get(
    "/pagos/{notification_id}/comprobante-url",
    response_model=portal_schemas.PortalFileUrlRead,
    tags=["Portal"],
)
def pago_comprobante_url(
    notification_id: UUID,
    request: Request,
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> portal_schemas.PortalFileUrlRead:
    if portal_user.role == "buyer":
        raise HTTPException(status_code=403, detail="No autorizado")

    record = (
        db.query(PortalPaymentNotification)
        .filter(
            PortalPaymentNotification.id == notification_id,
            PortalPaymentNotification.empresa_id == portal_user.empresa_id,
            PortalPaymentNotification.cliente_id == portal_user.cliente_id,
        )
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="Notificación no encontrada")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)
    dte = facturacion_portal_contracts.get_dte_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        dte_id=record.dte_id,
    )
    if not dte:
        raise HTTPException(status_code=404, detail="Notificación no encontrada")

    storage = StorageService()
    if storage.mode == "s3":
        return portal_schemas.PortalFileUrlRead(
            url=storage.generate_presigned_url(record.comprobante_path)
        )
    return portal_schemas.PortalFileUrlRead(
        url=build_download_url(request, record.comprobante_path)
    )


@router.post(
    "/facturas/{dte_id}/notificar-pago",
    response_model=portal_schemas.PortalPaymentNotificationRead,
    tags=["Portal"],
)
async def notificar_pago(
    dte_id: UUID,
    comprobante: UploadFile = File(...),
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> PortalPaymentNotification:
    if portal_user.role == "buyer":
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)
    dte = facturacion_portal_contracts.get_dte_for_portal(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        dte_id=dte_id,
    )
    if not dte:
        raise HTTPException(status_code=404, detail="Factura no encontrada")

    content = await comprobante.read()
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Archivo excede 2MB")

    ext, detected_mime = detect_upload_ext_and_mime(content, comprobante.content_type)
    if ext not in {"pdf", "png", "jpg"}:
        raise HTTPException(status_code=400, detail="Tipo de archivo no permitido")

    storage = StorageService()
    file_id = uuid6.uuid7()
    path = (
        f"portal/{portal_user.empresa_id}/clientes/{portal_user.cliente_id}/"
        f"facturas/{dte.id}/pagos/{file_id}.{ext}"
    )
    stored_path = storage.upload_file(BytesIO(content), path)

    notification = PortalPaymentNotification(
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        dte_id=dte.id,
        comprobante_path=stored_path,
        comprobante_mime_type=detected_mime or comprobante.content_type,
        estado="PENDIENTE",
    )
    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification


@router.post(
    "/registrar-pago",
    response_model=list[portal_schemas.PortalPaymentNotificationRead],
    tags=["Portal"],
)
async def registrar_pago(
    dte_ids: list[UUID] = Form(...),
    monto: Decimal = Form(...),
    numero_operacion: str = Form(...),
    banco: str = Form(...),
    comprobante: UploadFile = File(...),
    db: Session = Depends(get_db),
    portal_user: PortalUser = Depends(get_current_portal_user),
) -> list[PortalPaymentNotification]:
    if portal_user.role == "buyer":
        raise HTTPException(status_code=403, detail="No autorizado")

    allowed_sucursales = get_portal_allowed_sucursal_ids(db, portal_user)
    receptor_rut = get_portal_receptor_rut(db, portal_user)

    unique_dte_ids = list(dict.fromkeys(dte_ids))
    if not unique_dte_ids:
        raise HTTPException(status_code=400, detail="Debe incluir al menos un DTE")
    if len(unique_dte_ids) > 50:
        raise HTTPException(status_code=400, detail="Máximo 50 DTEs por solicitud")
    if monto <= 0:
        raise HTTPException(status_code=400, detail="Monto inválido")

    dtes_list = facturacion_portal_contracts.list_dtes_for_portal_by_ids(
        db,
        empresa_id=portal_user.empresa_id,
        cliente_id=portal_user.cliente_id,
        receptor_rut=receptor_rut,
        allowed_sucursal_ids=allowed_sucursales,
        dte_ids=unique_dte_ids,
    )
    if len(dtes_list) != len(unique_dte_ids):
        raise HTTPException(status_code=404, detail="Uno o más DTEs no encontrados")

    content = await comprobante.read()
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Archivo excede 2MB")

    ext, detected_mime = detect_upload_ext_and_mime(content, comprobante.content_type)
    if ext not in {"pdf", "png", "jpg"}:
        raise HTTPException(status_code=400, detail="Tipo de archivo no permitido")

    storage = StorageService()
    batch_id = uuid6.uuid7()
    path = (
        f"portal/{portal_user.empresa_id}/clientes/{portal_user.cliente_id}/"
        f"pagos/{batch_id}/comprobante.{ext}"
    )
    stored_path = storage.upload_file(BytesIO(content), path)

    notifications: list[PortalPaymentNotification] = []
    for dte_uuid in unique_dte_ids:
        notifications.append(
            PortalPaymentNotification(
                empresa_id=portal_user.empresa_id,
                cliente_id=portal_user.cliente_id,
                dte_id=dte_uuid,
                pago_batch_id=batch_id,
                monto=monto,
                numero_operacion=numero_operacion,
                banco=banco,
                comprobante_path=stored_path,
                comprobante_mime_type=detected_mime or comprobante.content_type,
                estado="PENDIENTE",
            )
        )

    db.add_all(notifications)
    db.commit()
    for n in notifications:
        db.refresh(n)
    return notifications

