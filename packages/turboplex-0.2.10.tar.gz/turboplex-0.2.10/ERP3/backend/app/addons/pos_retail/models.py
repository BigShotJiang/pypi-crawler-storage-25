from sqlalchemy import Column, ForeignKey, DateTime, Numeric
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.sql import func
from app.core.database import Base, GUID
from uuid import UUID
from typing import Optional
from decimal import Decimal
import uuid6

class CierreCaja(Base):
    __tablename__ = "cierres_caja"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    fecha_apertura = Column(DateTime(timezone=True), default=func.now(), nullable=False)
    fecha_cierre = Column(DateTime(timezone=True), nullable=True)

    monto_inicial: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0.00, nullable=False)
    ventas_totales_sistema: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=0.00, nullable=False)
    monto_real_fisico: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    diferencia: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)

    # Foreign Keys
    sucursal_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)
    usuario_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("usuarios.id"), nullable=False, index=True
    )  # Who performed the closure (or opening)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Relationships
    sucursal = relationship(
        "app.core_modules.sistema.models.Sucursal", backref="cierres_caja"
    )
    usuario = relationship(
        "app.core_modules.sistema.models.Usuario", backref="cierres_realizados"
    )
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="cierres_caja"
    )
