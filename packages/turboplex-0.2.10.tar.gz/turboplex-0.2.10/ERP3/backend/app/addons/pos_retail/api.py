"""DEPRECATED: usar app.addons.pos_retail.router.

Este archivo se mantiene temporalmente como shim para no romper imports existentes.
"""

from app.addons.pos_retail import router as pos_router

router = pos_router.router
