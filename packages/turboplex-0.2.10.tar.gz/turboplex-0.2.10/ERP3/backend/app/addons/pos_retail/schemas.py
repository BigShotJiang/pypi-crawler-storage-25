from typing import Optional
from pydantic import BaseModel, ConfigDict
from decimal import Decimal
from datetime import datetime
from uuid import UUID

# --- CierreCaja Schemas ---

class CierreCajaBase(BaseModel):
    sucursal_id: UUID
    monto_inicial: Decimal


class CierreCajaCreate(CierreCajaBase):
    pass


class CierreCajaClose(BaseModel):
    monto_real_fisico: Decimal


class CierreCajaInDBBase(CierreCajaBase):
    id: UUID
    fecha_apertura: datetime
    fecha_cierre: Optional[datetime] = None
    ventas_totales_sistema: Decimal
    monto_real_fisico: Optional[Decimal] = None
    diferencia: Optional[Decimal] = None
    usuario_id: UUID
    empresa_id: UUID

    model_config = ConfigDict(from_attributes=True)


class CierreCaja(CierreCajaInDBBase):
    pass
