from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api import deps
from app.core.auth.rbac import ScopesChecker
from app.addons.pos_retail import models, schemas, services


router = APIRouter(prefix="/pos")


@router.post(
    "/cierres-caja/abrir",
    response_model=schemas.CierreCaja,
    tags=["POS Retail"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:post"], mode="all"))],
)
def open_cierre_caja(
    *,
    db: Session = Depends(deps.get_db),
    cierre_in: schemas.CierreCajaCreate,
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    try:
        cierre = services.abrir_cierre_caja(
            db=db,
            cierre_in=cierre_in,
            usuario_id=current_user.id,
            empresa_id=current_company.id,
        )
        return schemas.CierreCaja.model_validate(cierre)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post(
    "/cierres-caja/{cierre_id}/cerrar",
    response_model=schemas.CierreCaja,
    tags=["POS Retail"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:post"], mode="all"))],
)
def close_cierre_caja(
    *,
    cierre_id: UUID,
    cierre_close: schemas.CierreCajaClose,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    cierre = (
        db.query(models.CierreCaja)
        .filter(models.CierreCaja.id == cierre_id, models.CierreCaja.empresa_id == current_company.id)
        .first()
    )
    if not cierre:
        raise HTTPException(status_code=404, detail="Cierre de caja no encontrado")

    try:
        cierre = services.cerrar_cierre_caja(
            db=db,
            cierre=cierre,
            cierre_close=cierre_close,
            empresa_id=current_company.id,
        )
        return schemas.CierreCaja.model_validate(cierre)
    except ValueError as exc:
        msg = str(exc)
        if msg in {"Cierre de caja no encontrado"}:
            raise HTTPException(status_code=404, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc
