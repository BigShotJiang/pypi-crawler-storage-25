from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.addons.pos_retail import models, schemas
from app.core_modules.finanzas import pos_contracts as finanzas_pos_contracts
from app.core_modules.ventas import pos_contracts as ventas_pos_contracts


def abrir_cierre_caja(
    *,
    db: Session,
    cierre_in: schemas.CierreCajaCreate,
    usuario_id: UUID,
    empresa_id: UUID,
) -> models.CierreCaja:
    existing = (
        db.query(models.CierreCaja)
        .filter(
            and_(
                models.CierreCaja.usuario_id == usuario_id,
                models.CierreCaja.sucursal_id == cierre_in.sucursal_id,
                models.CierreCaja.fecha_cierre.is_(None),
                models.CierreCaja.empresa_id == empresa_id,
            )
        )
        .first()
    )
    if existing:
        raise ValueError(
            "Ya existe una caja abierta para este usuario en esta sucursal."
        )

    cierre = models.CierreCaja(
        **cierre_in.model_dump(),
        usuario_id=usuario_id,
        empresa_id=empresa_id,
        fecha_apertura=datetime.now(),
        ventas_totales_sistema=Decimal("0.00"),
    )
    db.add(cierre)
    db.commit()
    db.refresh(cierre)
    return cierre


def cerrar_cierre_caja(
    *,
    db: Session,
    cierre: models.CierreCaja,
    cierre_close: schemas.CierreCajaClose,
    empresa_id: UUID,
) -> models.CierreCaja:
    if cierre.empresa_id != empresa_id:
        raise ValueError("Cierre de caja no encontrado")
    if cierre.fecha_cierre:
        raise ValueError("Esta caja ya está cerrada")

    closing_time = datetime.now()

    ventas_total = ventas_pos_contracts.sum_ventas_total_no_asignadas(
        db,
        empresa_id=empresa_id,
        sucursal_id=cierre.sucursal_id,
        vendedor_id=cierre.usuario_id,
        fecha_inicio=cierre.fecha_apertura,
        fecha_fin=closing_time,
    )
    ventas_pos_contracts.asignar_ventas_a_cierre(
        db,
        empresa_id=empresa_id,
        sucursal_id=cierre.sucursal_id,
        vendedor_id=cierre.usuario_id,
        fecha_inicio=cierre.fecha_apertura,
        fecha_fin=closing_time,
        cierre_id=cierre.id,
    )

    gastos_total = finanzas_pos_contracts.sum_gastos_efectivo(
        db,
        empresa_id=empresa_id,
        sucursal_id=cierre.sucursal_id,
        fecha_inicio=cierre.fecha_apertura,
        fecha_fin=closing_time,
    )

    cierre.fecha_cierre = closing_time
    cierre.ventas_totales_sistema = ventas_total
    cierre.monto_real_fisico = cierre_close.monto_real_fisico

    esperado = cierre.monto_inicial + ventas_total - gastos_total
    cierre.diferencia = cierre.monto_real_fisico - esperado

    db.add(cierre)
    db.commit()
    db.refresh(cierre)
    return cierre

