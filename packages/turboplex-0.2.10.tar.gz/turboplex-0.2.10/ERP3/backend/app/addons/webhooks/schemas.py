from typing import Optional
from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class WebhookConfigBase(BaseModel):
    event_name: str
    url: str
    secret_key: Optional[str] = None
    is_active: bool = True


class WebhookConfigCreate(WebhookConfigBase):
    pass


class WebhookConfigUpdate(BaseModel):
    event_name: Optional[str] = None
    url: Optional[str] = None
    secret_key: Optional[str] = None
    is_active: Optional[bool] = None


class WebhookConfigOut(WebhookConfigBase):
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)

