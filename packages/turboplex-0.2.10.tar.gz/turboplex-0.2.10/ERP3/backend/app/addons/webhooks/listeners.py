import asyncio
import json
import logging
from typing import Any, List, cast

import httpx
from uuid import UUID
from fastapi.encoders import jsonable_encoder
from app.core.infrastructure.events import event_dispatcher
from app.core.database import SessionLocal
from app.core.infrastructure.messenger.manager import messenger
from app.core.infrastructure.redis import compute_backoff_delay, idempotent_task
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts
from .models import WebhookConfig


logger = logging.getLogger(__name__)


def _parse_uuid(value: Any) -> UUID | None:
    if isinstance(value, UUID):
        return value
    if isinstance(value, str):
        try:
            return UUID(value)
        except Exception:
            return None
    return None


def _extract_empresa_id(data: Any) -> UUID | None:
    if isinstance(data, dict):
        return _parse_uuid(data.get("empresa_id"))
    return _parse_uuid(getattr(data, "empresa_id", None))


def get_webhooks_for_event(event_type: str, empresa_id: UUID) -> List[WebhookConfig]:
    db = SessionLocal()
    try:
        db.info["empresa_id"] = empresa_id
        if not sistema_portal_contracts.is_empresa_feature_enabled(
            db, empresa_id=empresa_id, feature_key="webhooks"
        ):
            return []
        return (
            db.query(WebhookConfig)
            .filter(
                WebhookConfig.empresa_id == empresa_id,
                WebhookConfig.event_name == event_type,
                WebhookConfig.is_active,
            )
            .all()
        )
    except Exception as e:
        logger.error(f"Error fetching webhooks for {event_type}: {e}")
        return []
    finally:
        db.close()


def _build_webhook_task_id(
    empresa_id: Any, config_id: Any, event_type: str, payload: dict[str, Any]
) -> str:
    payload_str = json.dumps(payload, sort_keys=True)
    return f"webhook:{empresa_id}:{config_id}:{event_type}:{hash(payload_str)}"


@idempotent_task(
    lambda empresa_id, config_id, event_type, payload, attempt=1, max_attempts=5: _build_webhook_task_id(
        empresa_id, config_id, event_type, payload
    )
)
def deliver_webhook_job(
    empresa_id: Any,
    config_id: Any,
    event_type: str,
    payload: dict[str, Any],
    attempt: int = 1,
    max_attempts: int = 5,
) -> None:
    db = SessionLocal()
    try:
        empresa_uuid = _parse_uuid(empresa_id)
        if empresa_uuid is None:
            return
        db.info["empresa_id"] = empresa_uuid
        if not sistema_portal_contracts.is_empresa_feature_enabled(
            db, empresa_id=empresa_uuid, feature_key="webhooks"
        ):
            return
        config = (
            db.query(WebhookConfig)
            .filter(
                WebhookConfig.id == config_id,
                WebhookConfig.empresa_id == empresa_uuid,
            )
            .first()
        )
        if not config or not config.is_active:
            return
        headers = {
            "Content-Type": "application/json",
            "X-ERP3-Event": event_type,
            "User-Agent": "ERP3-Webhook-Service",
        }
        if config.secret_key:
            headers["X-ERP3-Secret"] = config.secret_key
        try:
            response = httpx.post(
                config.url, json=payload, headers=headers, timeout=10.0
            )
        except Exception as exc:
            logger.error(
                "Failed to send webhook to %s on attempt %s: %s",
                config.url,
                attempt,
                exc,
            )
            response = None
        if response is None or response.status_code >= 500:
            if attempt < max_attempts and messenger.can_enqueue("critical"):
                delay = compute_backoff_delay(attempt)
                messenger.enqueue(
                    deliver_webhook_job,
                    empresa_id,
                    config_id,
                    event_type,
                    payload,
                    attempt + 1,
                    max_attempts,
                    lane="critical",
                    delay_seconds=delay,
                )
            return
        if response.status_code >= 400:
            logger.warning(
                "Webhook %s returned status %s: %s",
                config.url,
                response.status_code,
                response.text,
            )
        else:
            logger.info(
                "Webhook %s delivered successfully on attempt %s",
                config.url,
                attempt,
            )
    finally:
        db.close()


async def handle_global_event(event_type: str, data: Any) -> None:
    empresa_id = _extract_empresa_id(data)
    if empresa_id is None:
        return
    try:
        loop = asyncio.get_running_loop()
        webhooks = await loop.run_in_executor(
            None, get_webhooks_for_event, event_type, empresa_id
        )
    except RuntimeError:
        webhooks = get_webhooks_for_event(event_type, empresa_id)
    if not webhooks:
        return
    try:
        payload = cast(dict[str, Any], jsonable_encoder(data))
    except Exception as e:
        logger.error(f"Error serializing event data for webhook: {e}")
        payload = {"error": "serialization_failed", "raw_str": str(data)}
    if messenger.can_enqueue("fast"):
        for wh in webhooks:
            messenger.enqueue(
                deliver_webhook_job,
                str(empresa_id),
                wh.id,
                event_type,
                payload,
                1,
                5,
                lane="fast",
            )
        return
    async with httpx.AsyncClient() as client:
        tasks = []
        for wh in webhooks:
            headers = {
                "Content-Type": "application/json",
                "X-ERP3-Event": event_type,
                "User-Agent": "ERP3-Webhook-Service",
            }
            if wh.secret_key:
                headers["X-ERP3-Secret"] = wh.secret_key
            tasks.append(
                client.post(wh.url, json=payload, headers=headers, timeout=10.0)
            )
        if not tasks:
            return
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        for wh, resp in zip(webhooks, responses):
            if isinstance(resp, BaseException):
                logger.error("Failed to send webhook to %s: %s", wh.url, resp)
                continue
            response = cast(httpx.Response, resp)
            if response.status_code >= 400:
                logger.warning(
                    "Webhook %s returned status %s: %s",
                    wh.url,
                    response.status_code,
                    response.text,
                )
            else:
                logger.info("Webhook %s delivered successfully.", wh.url)


def register_listeners() -> None:
    event_dispatcher.subscribe_all(handle_global_event)
    logger.info("Universal Webhook Listener registered.")
