from typing import Any, List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api import deps
from app.core.auth.rbac import ScopesChecker
from app.core.database import get_db
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts

from app.addons.webhooks.models import WebhookConfig
from app.addons.webhooks import schemas
from app.addons.webhooks import listeners as webhooks_listeners


def init_addon() -> None:
    webhooks_listeners.register_listeners()


def require_webhooks_enabled(
    db: Session = Depends(get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    if not sistema_portal_contracts.is_empresa_feature_enabled(
        db, empresa_id=current_company.id, feature_key="webhooks"
    ):
        raise HTTPException(status_code=404, detail="Recurso no encontrado")
    return current_company


router = APIRouter(
    prefix="/webhooks",
    tags=["Webhooks"],
    dependencies=[Depends(ScopesChecker(["webhooks:manage"], mode="all"))],
)


@router.get("/config", response_model=List[schemas.WebhookConfigOut])
def list_webhooks(
    db: Session = Depends(get_db),
    current_company: Any = Depends(require_webhooks_enabled),
) -> List[schemas.WebhookConfigOut]:
    return (
        db.query(WebhookConfig)
        .filter(WebhookConfig.empresa_id == current_company.id)
        .all()
    )


@router.post("/config", response_model=schemas.WebhookConfigOut)
def create_webhook(
    event_name: str,
    url: str,
    secret_key: str | None = None,
    db: Session = Depends(get_db),
    current_company: Any = Depends(require_webhooks_enabled),
) -> schemas.WebhookConfigOut:
    config = WebhookConfig(
        empresa_id=current_company.id,
        event_name=event_name,
        url=url,
        secret_key=secret_key,
    )
    db.add(config)
    db.commit()
    db.refresh(config)
    return config


@router.put("/config/{config_id}", response_model=schemas.WebhookConfigOut)
def update_webhook(
    config_id: UUID,
    event_name: str | None = None,
    url: str | None = None,
    secret_key: str | None = None,
    is_active: bool | None = None,
    db: Session = Depends(get_db),
    current_company: Any = Depends(require_webhooks_enabled),
) -> schemas.WebhookConfigOut:
    config = (
        db.query(WebhookConfig)
        .filter(
            WebhookConfig.id == config_id,
            WebhookConfig.empresa_id == current_company.id,
        )
        .first()
    )
    if not config:
        raise HTTPException(status_code=404, detail="Webhook no encontrado")
    if event_name is not None:
        config.event_name = event_name
    if url is not None:
        config.url = url
    if secret_key is not None:
        config.secret_key = secret_key
    if is_active is not None:
        config.is_active = is_active
    db.add(config)
    db.commit()
    db.refresh(config)
    return config


@router.delete("/config/{config_id}")
def delete_webhook(
    config_id: UUID,
    db: Session = Depends(get_db),
    current_company: Any = Depends(require_webhooks_enabled),
) -> Any:
    config = (
        db.query(WebhookConfig)
        .filter(
            WebhookConfig.id == config_id,
            WebhookConfig.empresa_id == current_company.id,
        )
        .first()
    )
    if not config:
        raise HTTPException(status_code=404, detail="Webhook no encontrado")
    db.delete(config)
    db.commit()
    return {"ok": True}
