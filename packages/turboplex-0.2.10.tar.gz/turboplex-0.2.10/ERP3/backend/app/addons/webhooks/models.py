from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import Mapped
from app.core.database import Base, GUID
from uuid import UUID
import uuid6


class WebhookConfig(Base):
    __tablename__ = "webhooks_config"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=True, index=True
    )
    event_name = Column(String, index=True, nullable=False)
    url = Column(String, nullable=False)
    secret_key = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
