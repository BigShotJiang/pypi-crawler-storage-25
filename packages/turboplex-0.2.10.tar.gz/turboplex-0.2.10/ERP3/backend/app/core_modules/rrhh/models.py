from sqlalchemy import (
    Column,
    Integer,
    String,
    Date,
    ForeignKey,
    DateTime,
    JSON,
    Numeric,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship, Mapped
from app.core.database import Base, GUID
from app.core.utils.mixins import SoftDeleteMixin, TimestampMixin
from uuid import UUID
import uuid6


class Empleado(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "empleados"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombres = Column(String, nullable=True)
    apellidos = Column(String, nullable=True)
    rut = Column(String, index=True, nullable=False)
    cargo = Column(String, nullable=False)
    fecha_ingreso = Column(Date, nullable=True)

    # Nuevas mejoras para operatividad (Lavandería y otros)
    especialidades = Column(
        JSON, default=list, nullable=False
    )  # e.g. ["PLANCHADO", "CHOFER"]
    tipo_contrato = Column(
        String, default="INDEFINIDO"
    )  # INDEFINIDO, PLAZO_FIJO, HONORARIOS
    sueldo_base = Column(Numeric(10, 0), default=500000)  # Sueldo Base Mensual
    costo_hora = Column(
        Numeric(10, 2), default=0
    )  # Costo base para cálculos operativos
    estado_disponibilidad = Column(
        String, default="DISPONIBLE"
    )  # DISPONIBLE, VACACIONES, LICENCIA

    # Datos Legales Chile
    tipo_afp = Column(
        String, nullable=True
    )  # HABITAT, PROVIDA, MODELO, PLANVITAL, CAPITAL, CUPRUM, UNO
    sistema_salud = Column(
        String, nullable=True
    )  # FONASA, ISAPRE_CONSALUD, ISAPRE_BANMEDICA, etc.

    usuario_id = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Updated paths to core_modules.sistema
    usuario = relationship(
        "app.core_modules.sistema.models.Usuario", backref="empleado_perfil"
    )
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="empleados"
    )


class Asistencia(Base):
    __tablename__ = "asistencias"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empleado_id = Column(GUID, ForeignKey("empleados.id"), nullable=False, index=True)
    fecha = Column(Date, nullable=False, index=True)

    entrada = Column(DateTime, nullable=True)
    salida = Column(DateTime, nullable=True)

    colacion_inicio = Column(DateTime, nullable=True)
    colacion_fin = Column(DateTime, nullable=True)

    horas_trabajadas = Column(Numeric(5, 2), default=0)  # Horas efectivas
    horas_extras_calculadas = Column(Numeric(5, 2), default=0)  # Calculadas automatico

    comentario = Column(String, nullable=True)

    empleado = relationship("Empleado", backref="asistencias")
    # Link opcional al turno planificado (para comparar planificado vs real)
    turno_planificado_id = Column(
        GUID, ForeignKey("turnos_planificados.id"), nullable=True
    )


class TipoTurno(Base):
    __tablename__ = "tipos_turno"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    nombre = Column(String, nullable=False)  # "Mañana", "Tarde", "Noche"
    hora_inicio = Column(String, nullable=False)  # "08:00"
    hora_fin = Column(String, nullable=False)  # "16:00"
    color_hex = Column(String, default="#3B82F6")  # Para UI

    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="tipos_turno"
    )


class PlanificacionTurno(Base):
    __tablename__ = "turnos_planificados"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empleado_id = Column(GUID, ForeignKey("empleados.id"), nullable=False, index=True)
    tipo_turno_id = Column(GUID, ForeignKey("tipos_turno.id"), nullable=False)
    fecha = Column(Date, nullable=False, index=True)

    empleado = relationship("Empleado", backref="turnos_planificados")
    tipo_turno = relationship("TipoTurno")


class LiquidacionSueldo(Base):
    __tablename__ = "liquidaciones_sueldo"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empleado_id = Column(GUID, ForeignKey("empleados.id"), nullable=False)
    mes = Column(Integer, nullable=False)
    anio = Column(Integer, nullable=False)
    fecha_emision = Column(Date, default=func.now())

    # Haberes Imponibles
    sueldo_base = Column(Numeric(10, 0), default=0)
    gratificacion_legal = Column(Numeric(10, 0), default=0)
    horas_extras_monto = Column(Numeric(10, 0), default=0)
    bonos_imponibles = Column(Numeric(10, 0), default=0)

    # Haberes No Imponibles
    movilizacion = Column(Numeric(10, 0), default=0)
    colacion = Column(Numeric(10, 0), default=0)
    otros_no_imponibles = Column(Numeric(10, 0), default=0)

    total_haberes = Column(Numeric(10, 0), default=0)
    total_imponible = Column(Numeric(10, 0), default=0)

    # Descuentos Legales
    afp_monto = Column(Numeric(10, 0), default=0)
    salud_monto = Column(Numeric(10, 0), default=0)
    seguro_cesantia = Column(Numeric(10, 0), default=0)
    impuesto_unico = Column(Numeric(10, 0), default=0)

    total_descuentos = Column(Numeric(10, 0), default=0)

    # Resultado
    sueldo_liquido = Column(Numeric(10, 0), default=0)

    estado = Column(String, default="BORRADOR")  # BORRADOR, CONFIRMADO
    asiento_contable_id = Column(GUID, nullable=True)  # ID Referencia a Finanzas

    empleado = relationship("Empleado", backref="liquidaciones")
