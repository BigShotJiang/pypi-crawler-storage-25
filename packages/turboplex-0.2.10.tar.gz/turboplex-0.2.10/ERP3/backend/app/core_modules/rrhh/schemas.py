from typing import Optional, List
from uuid import UUID
from datetime import date, datetime
from decimal import Decimal
from pydantic import BaseModel, ConfigDict, field_validator
from app.core.utils import validate_rut, clean_rut


class EmpleadoBase(BaseModel):
    nombres: Optional[str] = None
    apellidos: Optional[str] = None
    rut: Optional[str] = None
    cargo: Optional[str] = None
    fecha_ingreso: Optional[date] = None
    usuario_id: Optional[UUID] = None

    # Nuevos campos
    especialidades: Optional[List[str]] = []
    tipo_contrato: Optional[str] = "INDEFINIDO"
    sueldo_base: Optional[Decimal] = Decimal("500000.0")
    costo_hora: Optional[Decimal] = Decimal("0.0")
    estado_disponibilidad: Optional[str] = "DISPONIBLE"

    # Datos Legales Chile
    tipo_afp: Optional[str] = None
    sistema_salud: Optional[str] = None


class EmpleadoCreate(EmpleadoBase):
    nombres: str
    apellidos: str
    rut: str
    cargo: str

    @field_validator("nombres", "apellidos")
    @classmethod
    def validate_nombre_campos(cls, v: str) -> str:
        value = v.strip()
        if not value:
            raise ValueError("Campo requerido")
        return value

    @field_validator("rut")
    @classmethod
    def validate_rut_chil(cls, v: str) -> str:
        if not validate_rut(v):
            raise ValueError("RUT inválido")
        return clean_rut(v)


class EmpleadoUpdate(EmpleadoBase):
    pass


class Empleado(EmpleadoBase):
    id: UUID
    empresa_id: UUID
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Asistencia Schemas
class AsistenciaBase(BaseModel):
    fecha: date
    entrada: Optional[datetime] = None
    salida: Optional[datetime] = None
    colacion_inicio: Optional[datetime] = None
    colacion_fin: Optional[datetime] = None
    comentario: Optional[str] = None


class AsistenciaCreate(AsistenciaBase):
    empleado_id: UUID


class AsistenciaUpdate(BaseModel):
    entrada: Optional[datetime] = None
    salida: Optional[datetime] = None
    colacion_inicio: Optional[datetime] = None
    colacion_fin: Optional[datetime] = None
    comentario: Optional[str] = None


class Asistencia(AsistenciaBase):
    id: UUID
    empleado_id: UUID
    horas_trabajadas: Decimal
    horas_extras_calculadas: Decimal
    turno_planificado_id: Optional[UUID] = None

    model_config = ConfigDict(from_attributes=True)


# Turnos Schemas
class TipoTurnoBase(BaseModel):
    nombre: str
    hora_inicio: str  # Format HH:MM
    hora_fin: str  # Format HH:MM
    color_hex: Optional[str] = "#3B82F6"


class TipoTurnoCreate(TipoTurnoBase):
    pass


class TipoTurno(TipoTurnoBase):
    id: UUID
    empresa_id: UUID
    model_config = ConfigDict(from_attributes=True)


class PlanificacionTurnoBase(BaseModel):
    fecha: date
    tipo_turno_id: UUID


class PlanificacionTurnoCreate(PlanificacionTurnoBase):
    empleado_id: UUID


class PlanificacionTurno(PlanificacionTurnoBase):
    id: UUID
    empleado_id: UUID
    # Relationship nesting optional depending on depth required
    model_config = ConfigDict(from_attributes=True)


class ParametrosDescuentos(BaseModel):
    tasa_afp: Optional[Decimal] = None
    isapre_uf: Optional[Decimal] = None
    fonasa_porcentaje: Optional[Decimal] = None
    tasa_afc: Optional[Decimal] = None


class LiquidacionSueldoBase(BaseModel):
    mes: int
    anio: int

    sueldo_base: Decimal
    gratificacion_legal: Decimal
    horas_extras_monto: Decimal
    bonos_imponibles: Decimal

    movilizacion: Decimal
    colacion: Decimal
    otros_no_imponibles: Decimal

    afp_monto: Decimal
    salud_monto: Decimal
    seguro_cesantia: Decimal
    impuesto_unico: Decimal

    total_haberes: Optional[Decimal] = None
    total_descuentos_legales: Optional[Decimal] = None
    alcance_liquido: Optional[Decimal] = None


class LiquidacionSueldoCreate(LiquidacionSueldoBase):
    empleado_id: UUID
    jornada_semanal: Optional[int] = None
    parametros_descuentos: Optional[ParametrosDescuentos] = None


class LiquidacionSueldo(LiquidacionSueldoBase):
    id: UUID
    empleado_id: UUID
    fecha_emision: date

    total_haberes: Decimal
    total_imponible: Decimal
    total_descuentos: Decimal
    sueldo_liquido: Decimal

    estado: str
    asiento_contable_id: Optional[UUID] = None

    model_config = ConfigDict(from_attributes=True)
