from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, Any, cast
from uuid import UUID

from app.core_modules.rrhh import models, schemas
from app.core_modules.finanzas import accounting_service
from app.core.config import settings

AFP_RATES = {
    "CAPITAL": Decimal("0.1144"),
    "CUPRUM": Decimal("0.1144"),
    "HABITAT": Decimal("0.1127"),
    "MODELO": Decimal("0.1058"),
    "PLANVITAL": Decimal("0.1116"),
    "PROVIDA": Decimal("0.1145"),
    "UNO": Decimal("0.1069"),
}
DEFAULT_AFP_RATE = Decimal("0.11")  # 10% + 1% comision promedio

# Tabla Impuesto Único 2025 (Valores en UTM)
# Estructura: (Desde, Hasta, Factor, Cantidad a Rebajar (en UTM))
# Fuente: SII
TAX_BRACKETS_UTM = [
    (Decimal("0"), Decimal("13.5"), Decimal("0.00"), Decimal("0.00")),
    (Decimal("13.5"), Decimal("30"), Decimal("0.04"), Decimal("0.54")),
    (Decimal("30"), Decimal("50"), Decimal("0.08"), Decimal("1.74")),
    (Decimal("50"), Decimal("70"), Decimal("0.135"), Decimal("4.49")),
    (Decimal("70"), Decimal("90"), Decimal("0.23"), Decimal("11.14")),
    (Decimal("90"), Decimal("120"), Decimal("0.304"), Decimal("17.80")),
    (Decimal("120"), Decimal("310"), Decimal("0.35"), Decimal("23.32")),
    (Decimal("310"), Decimal("999999"), Decimal("0.40"), Decimal("38.82")),
]


def round_peso(value: Decimal) -> Decimal:
    return value.to_integral_value(rounding=ROUND_HALF_UP)


def get_utm_value(mes: int, anio: int) -> Decimal:
    """
    Retorna el valor de la UTM para el mes/año dado.
    TODO: Conectar con tabla de IndicadoresEconomicos en BD.
    Por ahora, retorna valores proyectados 2025-2026.
    """
    # Valor base Enero 2025 aprox
    base_utm = Decimal("67000")

    # Simulación de inflación mensual pequeña
    delta_meses = (anio - 2025) * 12 + (mes - 1)
    if delta_meses < 0:
        delta_meses = 0

    return base_utm + (Decimal("500") * Decimal(delta_meses))


def calculate_impuesto_unico(base_tributable: Decimal, utm: Decimal) -> Decimal:
    """
    Calcula el Impuesto Único de Segunda Categoría.
    Formula: (Base Tributable * Factor) - Rebaja
    """
    if base_tributable <= 0:
        return Decimal(0)

    base_en_utm = base_tributable / utm

    factor = Decimal(0)
    rebaja_utm = Decimal(0)

    for desde, hasta, fac, reb in TAX_BRACKETS_UTM:
        if desde <= base_en_utm < hasta:
            factor = fac
            rebaja_utm = reb
            break

    impuesto = (base_tributable * factor) - (rebaja_utm * utm)
    impuesto_redondeado = impuesto.to_integral_value(rounding=ROUND_HALF_UP)
    return max(Decimal(0), impuesto_redondeado)


def get_afp_rate(tipo_afp: str) -> Decimal:
    if not tipo_afp:
        return DEFAULT_AFP_RATE
    return AFP_RATES.get(tipo_afp.upper(), DEFAULT_AFP_RATE)


def register_attendance(
    db: Session, asistencia_in: schemas.AsistenciaCreate
) -> models.Asistencia:
    """
    Registra entrada/salida y calcula horas trabajadas.
    """
    # Buscar si ya existe registro para ese día
    existing = (
        db.query(models.Asistencia)
        .filter(
            models.Asistencia.empleado_id == asistencia_in.empleado_id,
            models.Asistencia.fecha == asistencia_in.fecha,
        )
        .first()
    )

    if existing:
        existing_any = cast(Any, existing)
        if asistencia_in.entrada:
            existing_any.entrada = asistencia_in.entrada
        if asistencia_in.salida:
            existing_any.salida = asistencia_in.salida
        if asistencia_in.colacion_inicio:
            existing_any.colacion_inicio = asistencia_in.colacion_inicio
        if asistencia_in.colacion_fin:
            existing_any.colacion_fin = asistencia_in.colacion_fin

        recalculate_daily_hours(existing)
        db.commit()
        db.refresh(existing)
        return existing

    # Create new
    asistencia = models.Asistencia(
        empleado_id=asistencia_in.empleado_id,
        fecha=asistencia_in.fecha,
        entrada=asistencia_in.entrada,
        salida=asistencia_in.salida,
        colacion_inicio=asistencia_in.colacion_inicio,
        colacion_fin=asistencia_in.colacion_fin,
        comentario=asistencia_in.comentario,
    )
    recalculate_daily_hours(asistencia)
    db.add(asistencia)
    db.commit()
    db.refresh(asistencia)
    return asistencia


def recalculate_daily_hours(asistencia: models.Asistencia) -> None:
    """
    Calcula horas trabajadas descontando colación.
    """
    if asistencia.entrada and asistencia.salida:
        total_time = (asistencia.salida - asistencia.entrada).total_seconds() / 3600

        colacion_time = 0
        if asistencia.colacion_inicio and asistencia.colacion_fin:
            colacion_time = (
                asistencia.colacion_fin - asistencia.colacion_inicio
            ).total_seconds() / 3600

        # Si no marcó colación pero trabajó más de 9 horas, asumir 1 hora? No, ser estricto.

        net_hours = max(0, total_time - colacion_time)
        asistencia_any = cast(Any, asistencia)
        asistencia_any.horas_trabajadas = Decimal(net_hours).quantize(Decimal("0.01"))
    else:
        asistencia_any = cast(Any, asistencia)
        asistencia_any.horas_trabajadas = Decimal("0")


def calculate_weekly_overtime(
    db: Session, empleado_id: UUID, fecha_inicio_semana: date
) -> Decimal:
    """
    Calcula horas extras semanales (> 44 horas).
    """
    fecha_fin_semana = fecha_inicio_semana + timedelta(days=6)

    asistencias = (
        db.query(models.Asistencia)
        .filter(
            models.Asistencia.empleado_id == empleado_id,
            models.Asistencia.fecha >= fecha_inicio_semana,
            models.Asistencia.fecha <= fecha_fin_semana,
        )
        .all()
    )

    total_horas = sum(a.horas_trabajadas for a in asistencias)
    limite_legal = Decimal(str(settings.CHILE_JORNADA_SEMANAL_DEFAULT))

    horas_extras = max(Decimal(0), total_horas - limite_legal)

    # Distribuir horas extras (simplificado: se guardan en el último día o se devuelve el total)
    # Aquí solo retornamos el total para uso en payroll
    return horas_extras


def calculate_payroll_preview(
    db: Session,
    empleado_id: UUID,
    mes: int,
    anio: int,
    movilizacion: Decimal = Decimal(0),
    colacion: Decimal = Decimal(0),
    bonos: Decimal = Decimal(0),
    jornada_semanal: Optional[int] = None,
    parametros_descuentos: Optional[schemas.ParametrosDescuentos] = None,
) -> schemas.LiquidacionSueldoBase:

    empleado = db.query(models.Empleado).get(empleado_id)
    if not empleado:
        raise ValueError("Empleado no encontrado")

    raw_sueldo_base = empleado.sueldo_base or Decimal("0")
    sueldo_base: Decimal = cast(Decimal, raw_sueldo_base)

    total_horas_mes_raw = (
        db.query(func.sum(models.Asistencia.horas_trabajadas))
        .filter(
            models.Asistencia.empleado_id == empleado_id,
            func.extract("month", models.Asistencia.fecha) == mes,
            func.extract("year", models.Asistencia.fecha) == anio,
        )
        .scalar()
    )
    total_horas_mes: Decimal = cast(Decimal, total_horas_mes_raw or Decimal("0"))

    jornada = jornada_semanal or settings.CHILE_JORNADA_SEMANAL_DEFAULT
    jornada_decimal = Decimal(jornada)
    horas_mensuales_normales = jornada_decimal * Decimal("4.33")
    horas_extras_cant = Decimal("0")
    if horas_mensuales_normales > 0:
        horas_extras_cant = max(Decimal(0), total_horas_mes - horas_mensuales_normales)
    valor_hora_ordinaria = Decimal("0")
    if horas_mensuales_normales > 0:
        valor_hora_ordinaria = (sueldo_base / horas_mensuales_normales).quantize(
            Decimal("1"), rounding=ROUND_HALF_UP
        )
    valor_hora_extra = (valor_hora_ordinaria * Decimal("1.5")).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )
    monto_horas_extras = (horas_extras_cant * valor_hora_extra).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )

    imm = Decimal(str(settings.CHILE_IMM_MENSUAL_CLP))
    tope_inmm = Decimal(str(settings.CHILE_GRATIFICACION_TOPE_INMM))
    tope_anual = tope_inmm * imm
    tope_mensual = tope_anual / Decimal("12")
    base_grat = sueldo_base + monto_horas_extras + bonos
    gratificacion = base_grat * Decimal("0.25")
    if gratificacion > tope_mensual:
        gratificacion = tope_mensual
    gratificacion = round_peso(gratificacion)

    otros_no_imponibles = Decimal("0")
    total_imponible = sueldo_base + gratificacion + monto_horas_extras + bonos

    tasa_afp_frac = None
    if parametros_descuentos and parametros_descuentos.tasa_afp is not None:
        tasa_afp_frac = parametros_descuentos.tasa_afp / Decimal("100")
    else:
        tipo_afp = cast(str, empleado.tipo_afp) if empleado.tipo_afp is not None else ""
        tasa_afp_frac = get_afp_rate(tipo_afp)
    afp_monto = round_peso(total_imponible * tasa_afp_frac)

    monto_salud_base = sueldo_base * Decimal("0.07")
    salud_monto_calc = monto_salud_base
    if parametros_descuentos:
        if parametros_descuentos.isapre_uf is not None:
            plan_clp = (
                parametros_descuentos.isapre_uf * settings.CHILE_UF_VALOR_REFERENCIA_CLP
            )
            salud_monto_calc = max(monto_salud_base, plan_clp)
        elif parametros_descuentos.fonasa_porcentaje is not None:
            tasa_fonasa = parametros_descuentos.fonasa_porcentaje / Decimal("100")
            salud_monto_calc = sueldo_base * tasa_fonasa
    salud_monto = round_peso(salud_monto_calc)

    seguro_cesantia = Decimal("0")
    tasa_afc_frac = None
    if parametros_descuentos and parametros_descuentos.tasa_afc is not None:
        tasa_afc_frac = parametros_descuentos.tasa_afc / Decimal("100")
    elif empleado.tipo_contrato == "INDEFINIDO":
        tasa_afc_frac = Decimal("0.006")
    if tasa_afc_frac is not None:
        seguro_cesantia = round_peso(total_imponible * tasa_afc_frac)

    utm_mes = get_utm_value(mes, anio)
    base_tributable = total_imponible - afp_monto - salud_monto - seguro_cesantia
    impuesto_unico = calculate_impuesto_unico(base_tributable, utm_mes)

    total_haberes = (
        sueldo_base
        + gratificacion
        + monto_horas_extras
        + bonos
        + movilizacion
        + colacion
        + otros_no_imponibles
    )
    total_descuentos_legales = afp_monto + salud_monto + seguro_cesantia
    alcance_liquido = total_haberes - total_descuentos_legales

    return schemas.LiquidacionSueldoBase(
        mes=mes,
        anio=anio,
        sueldo_base=sueldo_base,
        gratificacion_legal=gratificacion,
        horas_extras_monto=monto_horas_extras,
        bonos_imponibles=bonos,
        movilizacion=movilizacion,
        colacion=colacion,
        otros_no_imponibles=otros_no_imponibles,
        afp_monto=afp_monto,
        salud_monto=salud_monto,
        seguro_cesantia=seguro_cesantia,
        impuesto_unico=impuesto_unico,
        total_haberes=total_haberes,
        total_descuentos_legales=total_descuentos_legales,
        alcance_liquido=alcance_liquido,
    )


def confirm_payroll(
    db: Session, liquidacion_data: schemas.LiquidacionSueldoCreate, usuario_id: UUID
) -> models.LiquidacionSueldo:

    preview = calculate_payroll_preview(
        db,
        liquidacion_data.empleado_id,
        liquidacion_data.mes,
        liquidacion_data.anio,
        liquidacion_data.movilizacion,
        liquidacion_data.colacion,
        liquidacion_data.bonos_imponibles,
        liquidacion_data.jornada_semanal,
        liquidacion_data.parametros_descuentos,
    )

    total_haberes = (
        preview.sueldo_base
        + preview.gratificacion_legal
        + preview.horas_extras_monto
        + preview.bonos_imponibles
        + preview.movilizacion
        + preview.colacion
    )

    total_imponible = (
        preview.sueldo_base
        + preview.gratificacion_legal
        + preview.horas_extras_monto
        + preview.bonos_imponibles
    )

    total_descuentos = (
        preview.afp_monto
        + preview.salud_monto
        + preview.seguro_cesantia
        + preview.impuesto_unico
    )

    sueldo_liquido = total_haberes - total_descuentos

    liquidacion = models.LiquidacionSueldo(
        empleado_id=liquidacion_data.empleado_id,
        mes=liquidacion_data.mes,
        anio=liquidacion_data.anio,
        sueldo_base=preview.sueldo_base,
        gratificacion_legal=preview.gratificacion_legal,
        horas_extras_monto=preview.horas_extras_monto,
        bonos_imponibles=preview.bonos_imponibles,
        movilizacion=preview.movilizacion,
        colacion=preview.colacion,
        otros_no_imponibles=preview.otros_no_imponibles,
        total_haberes=total_haberes,
        total_imponible=total_imponible,
        afp_monto=preview.afp_monto,
        salud_monto=preview.salud_monto,
        seguro_cesantia=preview.seguro_cesantia,
        impuesto_unico=preview.impuesto_unico,
        total_descuentos=total_descuentos,
        sueldo_liquido=sueldo_liquido,
        estado="CONFIRMADO",
    )
    db.add(liquidacion)
    db.flush()

    # 3. Integración Contable
    empleado = db.query(models.Empleado).get(liquidacion_data.empleado_id)
    if empleado is None:
        raise ValueError("Empleado no encontrado para liquidación")
    empresa_id = empleado.empresa_id
    sucursal_id = empleado.sucursal_id

    asiento = accounting_service.create_payroll_entry(
        db,
        liquidacion.id,
        f"EMP-{empleado.id}",  # Nombre o RUT
        total_haberes,
        total_descuentos,
        sueldo_liquido,
        sucursal_id,
        empresa_id,
        usuario_id,
    )

    if asiento:
        liquidacion.asiento_contable_id = asiento.id

    db.commit()
    db.refresh(liquidacion)
    return liquidacion
