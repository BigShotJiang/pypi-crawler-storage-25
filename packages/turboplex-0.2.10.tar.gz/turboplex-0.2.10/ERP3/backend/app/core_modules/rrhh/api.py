from typing import Any, List, cast
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from app.api import deps
from app.core.services import auditoria_service
from . import models, schemas, services

# Import System Models
from app.core_modules.sistema.models import Usuario, Empresa
from app.core.infrastructure.api_schemas import BaseResponse

router = APIRouter(dependencies=[Depends(deps.check_module_access("RRHH"))])

# ADMIN_SAAS y MANAGER_RRHH son los roles de negocio.
# SUPERADMIN y DEVELOPER se incluyen para mantenimiento y soporte.
ALLOWED_ROLES = [
    deps.UserRole.ADMIN_SAAS,
    deps.UserRole.MANAGER_RRHH,
    deps.UserRole.SUPERADMIN,
    deps.UserRole.DEVELOPER,
    deps.UserRole.ADMIN,
]


@router.get("/", response_model=List[schemas.Empleado])
def read_empleados(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Retrieve empleados.
    """
    empleados = (
        db.query(models.Empleado)
        .filter(models.Empleado.empresa_id == current_company.id)
        .offset(skip)
        .limit(limit)
        .all()
    )
    return empleados


# --- ASISTENCIA ---


@router.post("/asistencias/", response_model=schemas.Asistencia)
def create_asistencia(
    *,
    db: Session = Depends(deps.get_db),
    asistencia_in: schemas.AsistenciaCreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Registra asistencia (Entrada/Salida) para un empleado.
    """
    # Verificar que empleado pertenece a empresa
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == asistencia_in.empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(
            status_code=404, detail="Empleado no encontrado en esta empresa"
        )

    return services.register_attendance(db, asistencia_in)


@router.get("/asistencias/{empleado_id}", response_model=List[schemas.Asistencia])
def read_asistencias(
    empleado_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene historial de asistencia de un empleado.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")

    return (
        db.query(models.Asistencia)
        .filter(models.Asistencia.empleado_id == empleado_id)
        .all()
    )


# --- TURNOS (GESTIÓN) ---


@router.post("/turnos/tipos", response_model=schemas.TipoTurno)
def create_tipo_turno(
    *,
    db: Session = Depends(deps.get_db),
    turno_in: schemas.TipoTurnoCreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Crea un nuevo Tipo de Turno (ej. Mañana, Tarde, Noche).
    """
    tipo_turno = models.TipoTurno(
        **turno_in.model_dump(), empresa_id=current_company.id
    )
    db.add(tipo_turno)
    db.commit()
    db.refresh(tipo_turno)
    return tipo_turno


@router.get("/turnos/tipos", response_model=List[schemas.TipoTurno])
def read_tipos_turno(
    db: Session = Depends(deps.get_db),
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Lista todos los tipos de turno de la empresa.
    """
    return (
        db.query(models.TipoTurno)
        .filter(models.TipoTurno.empresa_id == current_company.id)
        .all()
    )


@router.post("/turnos/asignar", response_model=schemas.PlanificacionTurno)
def asignar_turno(
    *,
    db: Session = Depends(deps.get_db),
    plan_in: schemas.PlanificacionTurnoCreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Asigna un turno específico a un empleado en una fecha.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == plan_in.empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")

    # Verificar que el tipo de turno pertenece a la empresa (o es genérico si se permitiera)
    tipo_turno = (
        db.query(models.TipoTurno)
        .filter(
            models.TipoTurno.id == plan_in.tipo_turno_id,
            models.TipoTurno.empresa_id == current_company.id,
        )
        .first()
    )

    if not tipo_turno:
        raise HTTPException(status_code=404, detail="Tipo de Turno no válido")

    # Verificar si ya existe turno para esa fecha (Actualizar o Crear)
    existing_plan = (
        db.query(models.PlanificacionTurno)
        .filter(
            models.PlanificacionTurno.empleado_id == plan_in.empleado_id,
            models.PlanificacionTurno.fecha == plan_in.fecha,
        )
        .first()
    )

    if existing_plan:
        existing_any = cast(Any, existing_plan)
        existing_any.tipo_turno_id = plan_in.tipo_turno_id
        db.add(existing_plan)
        db.commit()
        db.refresh(existing_plan)
        return existing_plan

    new_plan = models.PlanificacionTurno(
        empleado_id=plan_in.empleado_id,
        tipo_turno_id=plan_in.tipo_turno_id,
        fecha=plan_in.fecha,
    )
    db.add(new_plan)
    db.commit()
    db.refresh(new_plan)
    return new_plan


@router.get(
    "/turnos/planificacion/{empleado_id}",
    response_model=List[schemas.PlanificacionTurno],
)
def read_planificacion(
    empleado_id: UUID,
    start_date: str,  # YYYY-MM-DD
    end_date: str,  # YYYY-MM-DD
    db: Session = Depends(deps.get_db),
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene la planificación de turnos de un empleado en un rango de fechas.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")

    return (
        db.query(models.PlanificacionTurno)
        .filter(
            models.PlanificacionTurno.empleado_id == empleado_id,
            models.PlanificacionTurno.fecha >= start_date,
            models.PlanificacionTurno.fecha <= end_date,
        )
        .all()
    )


# --- LIQUIDACIONES ---


@router.post(
    "/liquidaciones/preview", response_model=BaseResponse[schemas.LiquidacionSueldoBase]
)
def preview_liquidacion(
    *,
    db: Session = Depends(deps.get_db),
    liquidacion_in: schemas.LiquidacionSueldoCreate,  # Usamos Create para input params
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Calcula una pre-visualización de la liquidación de sueldo.
    No guarda en DB.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == liquidacion_in.empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")

    preview = services.calculate_payroll_preview(
        db,
        liquidacion_in.empleado_id,
        liquidacion_in.mes,
        liquidacion_in.anio,
        liquidacion_in.movilizacion,
        liquidacion_in.colacion,
        liquidacion_in.bonos_imponibles,
        liquidacion_in.jornada_semanal,
        liquidacion_in.parametros_descuentos,
    )
    return BaseResponse(success=True, data=preview)


@router.post("/liquidaciones/", response_model=BaseResponse[schemas.LiquidacionSueldo])
def create_liquidacion(
    *,
    db: Session = Depends(deps.get_db),
    liquidacion_in: schemas.LiquidacionSueldoCreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Genera y CONFIRMA una liquidación de sueldo.
    Genera asiento contable automáticamente.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == liquidacion_in.empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")

    # Verificar si ya existe liquidacion confirmada para ese mes
    existing = (
        db.query(models.LiquidacionSueldo)
        .filter(
            models.LiquidacionSueldo.empleado_id == liquidacion_in.empleado_id,
            models.LiquidacionSueldo.mes == liquidacion_in.mes,
            models.LiquidacionSueldo.anio == liquidacion_in.anio,
            models.LiquidacionSueldo.estado == "CONFIRMADO",
        )
        .first()
    )

    if existing:
        raise HTTPException(
            status_code=400,
            detail="Ya existe una liquidación confirmada para este periodo",
        )

    liquidacion = services.confirm_payroll(db, liquidacion_in, current_user.id)
    return BaseResponse(success=True, data=liquidacion)


@router.post("/", response_model=schemas.Empleado)
def create_empleado(
    *,
    db: Session = Depends(deps.get_db),
    empleado_in: schemas.EmpleadoCreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Create new empleado.
    El campo usuario_id se ignora en la creación por RRHH. Debe ser vinculado por TI.
    """
    # Forzar usuario_id a None para que RRHH no pueda asignarlo directamente
    # TI debe hacerlo mediante proceso de aprobación/vinculación
    empleado_data = empleado_in.model_dump()
    if "usuario_id" in empleado_data:
        del empleado_data["usuario_id"]

    allowed_fields = [
        "nombres",
        "apellidos",
        "rut",
        "cargo",
        "fecha_ingreso",
        "especialidades",
        "tipo_contrato",
        "sueldo_base",
        "costo_hora",
        "estado_disponibilidad",
        "tipo_afp",
        "sistema_salud",
    ]
    empleado_payload = {field: empleado_data.get(field) for field in allowed_fields}
    empleado = models.Empleado(**empleado_payload, empresa_id=current_company.id)
    db.add(empleado)
    db.commit()
    db.refresh(empleado)
    return empleado


@router.put("/{empleado_id}", response_model=schemas.Empleado)
def update_empleado(
    *,
    db: Session = Depends(deps.get_db),
    empleado_id: UUID,
    empleado_in: schemas.EmpleadoUpdate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Update an empleado.
    RRHH no puede modificar usuario_id.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado not found")

    update_data = empleado_in.model_dump(exclude_unset=True)

    # Seguridad: RRHH no puede alterar la vinculación de usuario
    if "usuario_id" in update_data:
        del update_data["usuario_id"]

    for field, value in update_data.items():
        setattr(empleado, field, value)

    db.add(empleado)
    db.commit()
    db.refresh(empleado)
    return empleado


@router.delete("/{empleado_id}", response_model=schemas.Empleado)
def delete_empleado(
    *,
    db: Session = Depends(deps.get_db),
    empleado_id: UUID,
    background_tasks: BackgroundTasks,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Delete an empleado.
    """
    empleado = (
        db.query(models.Empleado)
        .filter(
            models.Empleado.id == empleado_id,
            models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado not found")

    auditoria_service.archivar_y_borrar(
        db=db,
        objeto=empleado,
        background_tasks=background_tasks,
        ejecutado_por_id=current_user.id,
        empresa_id=current_company.id,
        company_code=getattr(current_company, "codigo", None),
    )
    return empleado
