from sqlalchemy.orm import Session
from app.core_modules.crm.models import CrmCliente
from app.core_modules.ventas.models import Cliente as PublicCliente

class CRMClientSyncService:
    """
    Servicio de Sincronización CRM -> Public (ERP)
    Patrón: UPSERT basado en RUT (Business Key)
    """

    @staticmethod
    def sync_to_public(db: Session, crm_cliente: CrmCliente) -> PublicCliente:
        """
        Sincroniza un cliente del esquema CRM hacia el esquema Public (Ventas/Contabilidad).
        - Si el RUT existe en la empresa: Actualiza/Adopta.
        - Si no existe: Crea nuevo.
        """
        if not crm_cliente.rut:
            raise ValueError("El cliente CRM debe tener RUT para sincronizar con ERP.")

        # 1. Buscar existencia en Public.Clientes por RUT y Empresa
        # Nota: La unicidad del RUT es por Empresa en el ERP multi-tenant usualmente,
        # aunque crm.clientes.rut es unique global segun el modelo actual, 
        # public.clientes suele ser por tenant. Asumiremos búsqueda por tenant.
        
        public_cliente = (
            db.query(PublicCliente)
            .filter(
                PublicCliente.rut == crm_cliente.rut,
                PublicCliente.empresa_id == crm_cliente.empresa_id
            )
            .first()
        )

        if public_cliente:
            # UPDATE (Adopción / Actualización de datos maestros)
            # Solo actualizamos datos que el CRM domina y que son seguros de cambiar
            if public_cliente.nombre != crm_cliente.razon_social:
                public_cliente.nombre = crm_cliente.razon_social
            
            # Aquí se podrían sincronizar más campos si existieran en ambos (direccion, etc.)
            # public_cliente.direccion = crm_cliente.direccion 
            
            db.add(public_cliente)
            # No hacemos commit aquí para permitir transacciones mayores
            db.flush()
            return public_cliente
        else:
            # INSERT
            new_public_cliente = PublicCliente(
                nombre=crm_cliente.razon_social,
                rut=crm_cliente.rut,
                empresa_id=crm_cliente.empresa_id,
                # Otros campos por defecto
                email=None, 
                telefono=None,
                direccion=None
            )
            db.add(new_public_cliente)
            db.flush()
            return new_public_cliente
