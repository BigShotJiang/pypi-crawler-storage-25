from datetime import datetime, timedelta
from typing import Optional, Any, cast
from uuid import UUID
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.core_modules.crm.models import (
    Embudo,
    Etapa,
    OportunidadVenta,
    EstadoCredito,
    OportunidadComentario,
    Notification,
    CrmExcepcionCredito,
    CrmCliente,
)
from app.core_modules.sistema.models import Usuario, UsuarioEmpresa, Rol, Bodega, Sucursal
from app.core_modules.finanzas.models_rates import ExchangeRates
from app.core_modules.ventas.inventory_service import InventoryService
from app.core_modules.finanzas.accounting_service import get_cliente_credit_balance
from app.core_modules.ventas.models import Cliente
from app.core_modules.crm.schemas import CrmEstadoCredito


class CRMServiceCredito:
    @staticmethod
    def consumir_cupo_excepcion(
        db: Session,
        cliente_rut: str,
        monto: Decimal,
        request_id: Optional[UUID] = None,
    ) -> CrmExcepcionCredito:
        """
        Consume cupo de una excepción de crédito activa.
        - Usa Locking Pesimista (with_for_update) para evitar condiciones de carrera.
        - Valida que monto_consumido + monto <= monto_autorizado.
        - Actualiza el saldo de forma atómica.
        
        :param request_id: UUIDv7 único de la transacción para idempotencia (Future impl: Check against consumption log)
        """
        # 1. Buscar la excepción activa para este RUT con bloqueo de escritura
        # Se asume que solo hay una excepción activa por cliente a la vez (o se toma la más reciente/válida)
        stmt = (
            select(CrmExcepcionCredito)
            .where(
                CrmExcepcionCredito.cliente_rut == cliente_rut,
                # CrmExcepcionCredito.fecha_expiracion >= datetime.now(), # Si existiera logica de expiracion
                # CrmExcepcionCredito.estado == 'ACTIVA' # Si existiera estado
            )
            .with_for_update()  # SELECT ... FOR UPDATE
        )
        excepcion = db.execute(stmt).scalar_one_or_none()

        if not excepcion:
            raise HTTPException(
                status_code=404, 
                detail=f"No existe excepción de crédito activa para el cliente {cliente_rut}"
            )

        # 2. Validar Cupo Disponible
        nuevo_consumido = excepcion.monto_consumido + monto
        if nuevo_consumido > excepcion.monto_autorizado:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Cupo insuficiente. Autorizado: {excepcion.monto_autorizado}, "
                    f"Consumido: {excepcion.monto_consumido}, Intento: {monto}"
                )
            )

        # 3. Actualizar Saldo
        excepcion.monto_consumido = nuevo_consumido
        # excepcion.version += 1 # SQLAlchemy lo maneja si está configurado en mapper, o manual aquí
        
        # 4. Alerta de Consumo > 80% (Pilar 6 - Garantías de Operación)
        if excepcion.monto_autorizado > 0:
            percentage = nuevo_consumido / excepcion.monto_autorizado
            if percentage >= Decimal("0.8"):
                # Buscar Cliente para obtener empresa_id
                stmt_cliente = select(CrmCliente).where(CrmCliente.rut == cliente_rut)
                cliente = db.execute(stmt_cliente).scalar_one_or_none()
                
                if cliente:
                    # Buscar Admins de la empresa
                    stmt_admins = (
                        select(Usuario)
                        .join(UsuarioEmpresa, Usuario.id == UsuarioEmpresa.usuario_id)
                        .join(Rol, UsuarioEmpresa.rol_id == Rol.id)
                        .where(
                            UsuarioEmpresa.empresa_id == cliente.empresa_id,
                            Rol.codigo == "ADM",
                            Usuario.is_active
                        )
                    )
                    admins = db.execute(stmt_admins).scalars().all()
                    
                    for admin in admins:
                        msg = (
                            f"ALERTA CRÉDITO: Cliente {cliente.razon_social} ({cliente_rut}) "
                            f"ha consumido {int(percentage*100)}% de su excepción "
                            f"(${nuevo_consumido:,.0f} / ${excepcion.monto_autorizado:,.0f})"
                        )
                        notif = Notification(
                            mensaje=msg,
                            usuario_id=admin.id,
                            link_documento=excepcion.documento_respaldo_url,
                            leido=False
                        )
                        db.add(notif)

        # TODO: Registrar request_id en tabla de consumos para idempotencia futura
        
        db.add(excepcion)
        db.flush() # Persistir cambio en transacción actual
        return excepcion

    @staticmethod
    def get_estado_credito(
        db: Session,
        crm_cliente_id: UUID,
        empresa_id: UUID
    ) -> CrmEstadoCredito:
        """
        Calcula el estado de crédito en tiempo real consultando el ERP (Accounting Service).
        """
        # 1. Obtener Cliente CRM
        crm_cliente = db.query(CrmCliente).filter(
            CrmCliente.id == crm_cliente_id,
            CrmCliente.empresa_id == empresa_id
        ).first()
        
        if not crm_cliente:
             raise HTTPException(status_code=404, detail="Cliente CRM no encontrado")
             
        # 2. Buscar Cliente ERP (Public Schema)
        erp_cliente = db.query(Cliente).filter(
            Cliente.rut == crm_cliente.rut,
            Cliente.empresa_id == empresa_id
        ).first()
        
        limite_credito = Decimal(0)
        saldo_utilizado = Decimal(0)
        
        if erp_cliente:
            limite_credito = erp_cliente.limite_credito or Decimal(0)
            # 3. Consultar Deuda Real (ERP Accounting)
            saldo_utilizado = get_cliente_credit_balance(db, empresa_id, erp_cliente)
        
        # 4. Verificar Excepciones Activas
        excepcion = db.query(CrmExcepcionCredito).filter(
            CrmExcepcionCredito.cliente_rut == crm_cliente.rut
        ).first()
        
        tiene_excepcion = False
        monto_excepcion = Decimal(0)
        
        if excepcion:
            # Check expiration if set
            if not excepcion.fecha_expiracion or excepcion.fecha_expiracion.replace(tzinfo=None) >= datetime.now():
                tiene_excepcion = True
                # Available exception amount
                monto_excepcion = excepcion.monto_autorizado - excepcion.monto_consumido
                if monto_excepcion < 0:
                    monto_excepcion = Decimal(0)
                
        # 5. Calculate Logic
        disponible_base = limite_credito - saldo_utilizado
        disponible_total = disponible_base + monto_excepcion
        
        estado = EstadoCredito.PENDIENTE # Default
        if disponible_total < 0:
            estado = EstadoCredito.BLOQUEADO
        elif disponible_total >= 0:
            estado = EstadoCredito.APROBADO
            
        return CrmEstadoCredito(
            limite_credito=limite_credito,
            monto_utilizado=saldo_utilizado,
            monto_disponible=disponible_total,
            estado=estado,
            tiene_excepcion=tiene_excepcion,
            monto_excepcion=monto_excepcion
        )

    @staticmethod
    def create_default_pipeline(db: Session, empresa_id: UUID) -> Embudo:
        embudo = Embudo(
            nombre="Pipeline Estándar",
            descripcion="Flujo de ventas general",
            empresa_id=empresa_id,
        )
        db.add(embudo)
        db.flush()

        etapas = [
            Etapa(
                nombre="Prospecto", orden=1, probabilidad_exito=10, embudo_id=embudo.id
            ),
            Etapa(
                nombre="Calificado",
                orden=2,
                probabilidad_exito=30,
                embudo_id=embudo.id,
            ),
            Etapa(
                nombre="Propuesta",
                orden=3,
                probabilidad_exito=60,
                embudo_id=embudo.id,
            ),
            Etapa(
                nombre="Negociación",
                orden=4,
                probabilidad_exito=80,
                embudo_id=embudo.id,
            ),
            Etapa(
                nombre="Cierre Ganado",
                orden=5,
                probabilidad_exito=100,
                embudo_id=embudo.id,
            ),
        ]
        db.add_all(etapas)
        db.commit()
        return embudo

    @staticmethod
    def check_exchange_rate_staleness(
        db: Session, currency_code: str, hours_threshold: int = 24
    ) -> bool:
        if currency_code == "CLP":
            return False

        rate_entry = (
            db.query(ExchangeRates)
            .filter(ExchangeRates.currency_code == currency_code)
            .first()
        )

        if not rate_entry:
            return True

        if not rate_entry.updated_at:
            return True

        limit_date = datetime.now(rate_entry.updated_at.tzinfo) - timedelta(
            hours=hours_threshold
        )
        return rate_entry.updated_at < limit_date

    @staticmethod
    def request_credit_approval(
        db: Session, oportunidad_id: UUID, bodega_id: UUID
    ) -> OportunidadVenta:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        if oportunidad.estado_credito == EstadoCredito.APROBADO:
            raise HTTPException(status_code=400, detail="El crédito ya está aprobado")

        if oportunidad.estado_credito == EstadoCredito.PENDIENTE:
            pass
        else:
            for detalle in oportunidad.detalles:
                InventoryService.reserve_stock(
                    db=db,
                    producto_id=detalle.producto_id,
                    bodega_id=bodega_id,
                    cantidad=detalle.cantidad,
                )

            oportunidad.bodega_id = bodega_id

        bodega_sucursal_id = (
            db.query(Bodega.sucursal_id)
            .join(Sucursal, Sucursal.id == Bodega.sucursal_id)
            .filter(Bodega.id == bodega_id, Sucursal.empresa_id == oportunidad.empresa_id)
            .scalar()
        )
        if not bodega_sucursal_id:
            raise HTTPException(status_code=400, detail="Bodega inválida")
        oportunidad.sucursal_id = bodega_sucursal_id

        oportunidad_any = cast(Any, oportunidad)
        oportunidad_any.estado_credito = EstadoCredito.PENDIENTE
        oportunidad_any.fecha_inicio_analisis_credito = datetime.now()

        db.add(oportunidad)
        db.commit()
        db.refresh(oportunidad)
        return oportunidad

    @staticmethod
    def reject_credit_approval(
        db: Session,
        oportunidad_id: UUID,
        comentario: str,
        usuario_id: Optional[UUID] = None,
    ) -> OportunidadVenta:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        if oportunidad.estado_credito == EstadoCredito.BLOQUEADO:
            pass

        if oportunidad.bodega_id:
            for detalle in oportunidad.detalles:
                InventoryService.release_reservation(
                    db=db,
                    producto_id=detalle.producto_id,
                    bodega_id=oportunidad.bodega_id,
                    cantidad=detalle.cantidad,
                )

        oportunidad_any = cast(Any, oportunidad)
        oportunidad_any.estado_credito = EstadoCredito.BLOQUEADO
        oportunidad_any.bodega_id = None

        nuevo_comentario = OportunidadComentario(
            oportunidad_id=oportunidad.id, usuario_id=usuario_id, comentario=comentario
        )
        db.add(nuevo_comentario)

        msg = (
            f"Tu solicitud de crédito para la Oportunidad #{oportunidad.id} ha sido "
            f"RECHAZADA. Motivo: {comentario}"
        )
        notificacion = Notification(
            usuario_id=oportunidad.usuario_id,
            jefe_id=usuario_id,
            mensaje=msg,
            link_documento=f"/crm/opportunities/{oportunidad.id}",
            leido=False,
        )
        db.add(notificacion)

        db.add(oportunidad)
        db.commit()
        db.refresh(oportunidad)
        return oportunidad

    @staticmethod
    def update_credit_status(
        db: Session, oportunidad_id: UUID, nuevo_estado: EstadoCredito
    ) -> OportunidadVenta:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        if nuevo_estado == EstadoCredito.BLOQUEADO:
            if oportunidad.bodega_id:
                for detalle in oportunidad.detalles:
                    InventoryService.release_reservation(
                        db=db,
                        producto_id=detalle.producto_id,
                        bodega_id=oportunidad.bodega_id,
                        cantidad=detalle.cantidad,
                    )
                oportunidad.bodega_id = None

        oportunidad_any = cast(Any, oportunidad)
        oportunidad_any.estado_credito = nuevo_estado

        db.add(oportunidad)
        db.commit()
        db.refresh(oportunidad)
        return oportunidad

