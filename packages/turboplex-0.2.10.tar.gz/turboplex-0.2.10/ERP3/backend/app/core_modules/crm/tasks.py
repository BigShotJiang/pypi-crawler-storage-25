import logging
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.core_modules.crm.models import OportunidadVenta, EstadoCredito, Notification

logger = logging.getLogger(__name__)


def check_credit_approval_delays():
    """
    Tarea programada (Worker) para verificar retrasos en aprobación de crédito.
    Busca oportunidades en estado PENDIENTE con más de 30 minutos de antigüedad.
    Genera una notificación (alerta) para el supervisor o admin.
    """
    logger.info("Iniciando chequeo de retrasos en aprobación de crédito...")

    db: Session = SessionLocal()
    try:
        limit_time = datetime.now() - timedelta(minutes=30)

        delayed_opportunities = (
            db.query(OportunidadVenta)
            .filter(
                OportunidadVenta.estado_credito == EstadoCredito.PENDIENTE,
                OportunidadVenta.fecha_inicio_analisis_credito < limit_time,
            )
            .all()
        )

        if not delayed_opportunities:
            logger.info("No se encontraron aprobaciones de crédito retrasadas.")
            return

        for opp in delayed_opportunities:
            logger.warning(
                f"Oportunidad ID {opp.id} tiene retraso en aprobación de crédito (>30 min)."
            )

            # Crear Notificación en el sistema
            # Asumimos que notificamos al Owner de la oportunidad o a un Admin
            # Por simplicidad, notificamos al Owner

            msg = f"ALERTA: La aprobación de crédito para la Oportunidad #{opp.id} (Cliente: {opp.cliente_id}) ha excedido los 30 minutos."

            # Verificar si ya existe una notificación reciente para no spammear?
            # Por ahora creamos una nueva.

            notification = Notification(
                usuario_id=opp.usuario_id,
                mensaje=msg,
                link_documento=f"/crm/opportunities/{opp.id}",
                leido=False,
            )
            db.add(notification)

        db.commit()
        logger.info(f"Se generaron {len(delayed_opportunities)} alertas de retraso.")

    except Exception as e:
        logger.error(f"Error en check_credit_approval_delays: {e}")
        db.rollback()
    finally:
        db.close()
