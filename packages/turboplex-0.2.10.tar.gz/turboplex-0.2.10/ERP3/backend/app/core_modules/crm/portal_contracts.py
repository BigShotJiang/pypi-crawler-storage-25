from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from uuid import UUID

from sqlalchemy import desc, false, or_
from sqlalchemy.orm import Session, joinedload

from app.core_modules.crm import models as crm_models


@dataclass(frozen=True)
class PortalQuoteItemUpdate:
    item_id: UUID
    cantidad: int | None = None
    notas_tecnicas: str | None = None


def _apply_sucursal_scope(query, allowed_sucursal_ids: list[UUID] | None, col):
    if allowed_sucursal_ids is None:
        return query
    if not allowed_sucursal_ids:
        return query.filter(false())
    return query.filter(or_(col.is_(None), col.in_(allowed_sucursal_ids)))


def _get_quote_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
    with_items: bool,
) -> crm_models.Cotizacion | None:
    query = (
        db.query(crm_models.Cotizacion)
        .join(
            crm_models.OportunidadVenta,
            crm_models.Cotizacion.oportunidad_id == crm_models.OportunidadVenta.id,
        )
        .filter(
            crm_models.Cotizacion.id == cotizacion_id,
            crm_models.Cotizacion.empresa_id == empresa_id,
            crm_models.OportunidadVenta.cliente_id == cliente_id,
        )
    )
    query = _apply_sucursal_scope(
        query, allowed_sucursal_ids, crm_models.OportunidadVenta.sucursal_id
    )
    if with_items:
        query = query.options(joinedload(crm_models.Cotizacion.items))
    return query.first()


def _ensure_quote_items_from_opportunity(
    db: Session, quote: crm_models.Cotizacion
) -> bool:
    if quote.items:
        return False

    opp = (
        db.query(crm_models.OportunidadVenta)
        .options(joinedload(crm_models.OportunidadVenta.detalles))
        .filter(
            crm_models.OportunidadVenta.id == quote.oportunidad_id,
            crm_models.OportunidadVenta.empresa_id == quote.empresa_id,
        )
        .first()
    )
    if not opp or not opp.detalles:
        return False

    for det in opp.detalles:
        quote.items.append(
            crm_models.CotizacionItem(
                cotizacion_id=quote.id,
                empresa_id=quote.empresa_id,
                producto_id=det.producto_id,
                cantidad=det.cantidad,
                notas_tecnicas=None,
                estado_item=crm_models.EstadoItemCotizacion.SOLICITADO,
            )
        )
    return True


def _compute_total_from_items(quote: crm_models.Cotizacion) -> Decimal | None:
    if not quote.items:
        return None
    if not any(item.precio_neto_final is not None for item in quote.items):
        return None
    total = Decimal("0")
    for item in quote.items:
        if item.estado_item == crm_models.EstadoItemCotizacion.RECHAZADO_CLIENTE:
            continue
        if item.precio_neto_final is None:
            continue
        total += Decimal(str(item.precio_neto_final)) * Decimal(item.cantidad or 0)
    return total


def get_cotizacion_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
) -> crm_models.Cotizacion | None:
    return _get_quote_for_portal(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        allowed_sucursal_ids=allowed_sucursal_ids,
        cotizacion_id=cotizacion_id,
        with_items=False,
    )


def get_cotizacion_detail_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
) -> crm_models.Cotizacion | None:
    quote = _get_quote_for_portal(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        allowed_sucursal_ids=allowed_sucursal_ids,
        cotizacion_id=cotizacion_id,
        with_items=True,
    )
    if not quote:
        return None
    changed = _ensure_quote_items_from_opportunity(db, quote)
    if changed:
        db.add(quote)
        db.commit()
        db.refresh(quote)
    return quote


def list_cotizaciones_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    limit: int,
) -> list[crm_models.Cotizacion]:
    query = (
        db.query(crm_models.Cotizacion)
        .join(
            crm_models.OportunidadVenta,
            crm_models.Cotizacion.oportunidad_id == crm_models.OportunidadVenta.id,
        )
        .filter(
            crm_models.Cotizacion.empresa_id == empresa_id,
            crm_models.OportunidadVenta.cliente_id == cliente_id,
        )
    )
    query = _apply_sucursal_scope(
        query, allowed_sucursal_ids, crm_models.OportunidadVenta.sucursal_id
    )
    return query.order_by(desc(crm_models.Cotizacion.created_at)).limit(limit).all()


def update_quote_draft_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
    updates: list[PortalQuoteItemUpdate],
) -> crm_models.Cotizacion:
    quote = _get_quote_for_portal(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        allowed_sucursal_ids=allowed_sucursal_ids,
        cotizacion_id=cotizacion_id,
        with_items=True,
    )
    if not quote:
        raise LookupError("Cotización no encontrada")

    if quote.estado == crm_models.EstadoCotizacion.ENVIADA:
        quote.estado = crm_models.EstadoCotizacion.BORRADOR_CLIENTE
        quote.version = (quote.version or 1) + 1
    elif quote.estado != crm_models.EstadoCotizacion.BORRADOR_CLIENTE:
        raise ValueError("Cotización no editable por el cliente")

    _ensure_quote_items_from_opportunity(db, quote)
    if not quote.items:
        raise ValueError("Cotización no tiene ítems para editar")

    items_by_id = {item.id: item for item in quote.items}
    for upd in updates:
        item = items_by_id.get(upd.item_id)
        if not item:
            raise LookupError("Ítem no encontrado")
        if upd.cantidad is not None:
            if upd.cantidad <= 0:
                raise ValueError("Cantidad inválida")
            item.cantidad = upd.cantidad
        if upd.notas_tecnicas is not None:
            item.notas_tecnicas = upd.notas_tecnicas

    db.add(quote)
    db.commit()
    db.refresh(quote)
    return quote


def send_quote_proposal_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
) -> crm_models.Cotizacion:
    quote = _get_quote_for_portal(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        allowed_sucursal_ids=allowed_sucursal_ids,
        cotizacion_id=cotizacion_id,
        with_items=True,
    )
    if not quote:
        raise LookupError("Cotización no encontrada")

    if quote.estado != crm_models.EstadoCotizacion.BORRADOR_CLIENTE:
        raise ValueError("Cotización no está en borrador cliente")

    if not quote.items:
        raise ValueError("Cotización no tiene ítems para enviar")

    quote.estado = crm_models.EstadoCotizacion.PENDIENTE_VENDEDOR
    quote.version = (quote.version or 1) + 1
    db.add(quote)
    db.commit()
    db.refresh(quote)
    return quote


def reject_quote_item_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
    item_id: UUID,
) -> crm_models.Cotizacion:
    quote = _get_quote_for_portal(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        allowed_sucursal_ids=allowed_sucursal_ids,
        cotizacion_id=cotizacion_id,
        with_items=True,
    )
    if not quote:
        raise LookupError("Cotización no encontrada")

    if quote.estado != crm_models.EstadoCotizacion.PROPUESTA_ENVIADA:
        raise ValueError("Cotización no permite rechazo de ítems")

    item = next((x for x in quote.items if x.id == item_id), None)
    if not item:
        raise LookupError("Ítem no encontrado")

    item.estado_item = crm_models.EstadoItemCotizacion.RECHAZADO_CLIENTE
    quote.version = (quote.version or 1) + 1
    new_total = _compute_total_from_items(quote)
    if new_total is not None:
        quote.total = new_total

    db.add(quote)
    db.commit()
    db.refresh(quote)
    return quote


def accept_quote_with_oc_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    cotizacion_id: UUID,
    stored_path: str,
    original_filename: str,
    mime_type: str | None,
) -> crm_models.Cotizacion:
    quote = _get_quote_for_portal(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        allowed_sucursal_ids=allowed_sucursal_ids,
        cotizacion_id=cotizacion_id,
        with_items=True,
    )
    if not quote:
        raise LookupError("Cotización no encontrada")

    if quote.estado not in {
        crm_models.EstadoCotizacion.ENVIADA,
        crm_models.EstadoCotizacion.PROPUESTA_ENVIADA,
    }:
        raise ValueError("Cotización no está disponible para aceptación")

    _ensure_quote_items_from_opportunity(db, quote)
    new_total = _compute_total_from_items(quote)
    if new_total is not None:
        if new_total <= 0:
            raise ValueError("Debe aceptar al menos un ítem con precio asignado")
        quote.total = new_total

    doc = crm_models.DocumentoCRM(
        oportunidad_id=quote.oportunidad_id,
        empresa_id=empresa_id,
        nombre_archivo=original_filename,
        url_archivo=stored_path,
        mime_type=mime_type,
        estado=crm_models.EstadoDocumento.PENDIENTE,
        subido_por_id=None,
    )
    quote.estado = crm_models.EstadoCotizacion.ACEPTADA_OC

    db.add_all([doc, quote])
    db.commit()
    db.refresh(quote)
    return quote


def get_latest_oc_document_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    oportunidad_id: UUID,
    expected_prefix: str,
) -> crm_models.DocumentoCRM | None:
    return (
        db.query(crm_models.DocumentoCRM)
        .filter(
            crm_models.DocumentoCRM.empresa_id == empresa_id,
            crm_models.DocumentoCRM.oportunidad_id == oportunidad_id,
            crm_models.DocumentoCRM.url_archivo.isnot(None),
            crm_models.DocumentoCRM.url_archivo.startswith(expected_prefix),
        )
        .order_by(desc(crm_models.DocumentoCRM.created_at))
        .first()
    )


def list_oc_documents_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    allowed_sucursal_ids: list[UUID] | None,
    base_prefix: str,
    limit: int,
) -> list[crm_models.DocumentoCRM]:
    query = (
        db.query(crm_models.DocumentoCRM)
        .join(
            crm_models.OportunidadVenta,
            crm_models.DocumentoCRM.oportunidad_id == crm_models.OportunidadVenta.id,
        )
        .filter(
            crm_models.DocumentoCRM.empresa_id == empresa_id,
            crm_models.OportunidadVenta.cliente_id == cliente_id,
            crm_models.DocumentoCRM.url_archivo.isnot(None),
            crm_models.DocumentoCRM.url_archivo.startswith(base_prefix),
            crm_models.DocumentoCRM.url_archivo.contains("/oc/"),
        )
        .order_by(desc(crm_models.DocumentoCRM.created_at))
    )
    query = _apply_sucursal_scope(
        query, allowed_sucursal_ids, crm_models.OportunidadVenta.sucursal_id
    )
    return query.limit(limit).all()


def create_notification(
    db: Session,
    *,
    usuario_id: UUID,
    mensaje: str,
    link_documento: str | None = None,
    leido: bool = False,
) -> UUID:
    notif = crm_models.Notification(
        usuario_id=usuario_id,
        mensaje=mensaje,
        link_documento=link_documento,
        leido=leido,
    )
    db.add(notif)
    db.flush()
    return notif.id
