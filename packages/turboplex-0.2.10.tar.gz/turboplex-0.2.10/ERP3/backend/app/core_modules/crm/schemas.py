from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Dict
from uuid import UUID
from datetime import datetime, date
from app.core_modules.crm.models import EstadoOportunidad, EstadoCredito, TipoActividad
from decimal import Decimal


class OportunidadConvert(BaseModel):
    sucursal_id: UUID
    request_id: Optional[UUID] = None  # Idempotencia


# -----------------------------------------------------------------------------
# DETALLES OPORTUNIDAD
# -----------------------------------------------------------------------------
class DetalleOportunidadBase(BaseModel):
    producto_id: UUID
    cantidad: int
    precio_unitario: Decimal


class DetalleOportunidadCreate(DetalleOportunidadBase):
    pass


class DetalleOportunidadRead(DetalleOportunidadBase):
    id: UUID
    subtotal: Decimal

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# ACTIVIDADES (TAREAS/NOTAS)
# -----------------------------------------------------------------------------
class ActividadBase(BaseModel):
    tipo: TipoActividad
    resumen: str
    descripcion: Optional[str] = None
    fecha_vencimiento: Optional[datetime] = None
    oportunidad_id: UUID
    usuario_id: Optional[UUID] = None


class ActividadCreate(ActividadBase):
    pass


class ActividadRead(ActividadBase):
    id: UUID
    created_at: datetime

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# COMENTARIOS
# -----------------------------------------------------------------------------
class ComentarioBase(BaseModel):
    comentario: str
    oportunidad_id: UUID


class ComentarioCreate(ComentarioBase):
    pass


class ComentarioRead(ComentarioBase):
    id: UUID
    usuario_id: Optional[UUID]
    created_at: datetime

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# ETAPAS
# -----------------------------------------------------------------------------
class EtapaBase(BaseModel):
    nombre: str
    orden: int = 0
    probabilidad_exito: int = 10


class EtapaCreate(EtapaBase):
    embudo_id: UUID


class EtapaRead(EtapaBase):
    id: UUID
    embudo_id: UUID

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# ESTADO DE CRÉDITO
# -----------------------------------------------------------------------------
class CrmEstadoCredito(BaseModel):
    limite_credito: Decimal
    monto_utilizado: Decimal
    monto_disponible: Decimal
    estado: EstadoCredito
    tiene_excepcion: bool = False
    monto_excepcion: Decimal = Decimal(0)

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# EMBUDOS (PIPELINES)
# -----------------------------------------------------------------------------
class EmbudoBase(BaseModel):
    nombre: str
    descripcion: Optional[str] = None
    empresa_id: UUID
    is_active: bool = True


class EmbudoCreate(EmbudoBase):
    pass


class EmbudoRead(EmbudoBase):
    id: UUID
    created_at: datetime
    etapas: List[EtapaRead] = []

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# OPORTUNIDADES
# -----------------------------------------------------------------------------
class OportunidadBase(BaseModel):
    titulo: str
    monto_estimado: Decimal
    moneda: str
    cliente_id: UUID
    etapa_id: UUID
    usuario_id: UUID
    empresa_id: UUID


class OportunidadCreate(OportunidadBase):
    detalles: List[DetalleOportunidadCreate] = []


class OportunidadUpdate(BaseModel):
    titulo: Optional[str] = None
    monto_estimado: Optional[Decimal] = None
    moneda: Optional[str] = None
    etapa_id: Optional[UUID] = None
    estado: Optional[EstadoOportunidad] = None
    razon_perdida: Optional[str] = None
    estado_credito: Optional[EstadoCredito] = None
    bodega_id: Optional[UUID] = None


class OportunidadRead(OportunidadBase):
    id: UUID
    estado: EstadoOportunidad
    razon_perdida: Optional[str]
    estado_credito: EstadoCredito
    fecha_cierre: Optional[datetime]
    created_at: datetime
    updated_at: Optional[datetime]
    detalles: List[DetalleOportunidadRead] = []
    actividades: List[ActividadRead] = []
    comentarios: List[ComentarioRead] = []
    bodega_id: Optional[UUID]
    
    # Extra field for warnings
    rate_is_stale: Optional[bool] = False

    class Config:
        from_attributes = True


class ConversionRequest(BaseModel):
    sucursal_id: UUID
    substitutions: Optional[Dict[UUID, UUID]] = None


class NotificationRead(BaseModel):
    id: UUID
    mensaje: str
    link_documento: Optional[str]
    leido: bool
    created_at: datetime
    jefe_id: Optional[UUID]  # Reference to sender/supervisor

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# CLIENTES CRM
# -----------------------------------------------------------------------------
class CrmClienteBase(BaseModel):
    rut: str
    razon_social: str
    vendedor_id: Optional[UUID] = None
    zona_id: Optional[UUID] = None
    estado_comercial: Optional[str] = "PROSPECTO"
    empresa_id: UUID


class CrmClienteCreate(CrmClienteBase):
    pass


class CrmClienteUpdate(BaseModel):
    razon_social: Optional[str] = None
    vendedor_id: Optional[UUID] = None
    zona_id: Optional[UUID] = None
    estado_comercial: Optional[str] = None


class CrmClienteRead(CrmClienteBase):
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# PRODUCTOS CRM (Read-Only con Stock y Precios Dinámicos)
# -----------------------------------------------------------------------------
class CrmProductoRead(BaseModel):
    id: UUID
    nombre: str
    sku: str
    precio_lista: Decimal  # Precio Base ERP
    precio_calculado: Decimal  # Precio Final (con política aplicada)
    factor_politica: Optional[Decimal] = Decimal(1.0)
    nombre_politica: Optional[str] = None
    
    stock_disponible: Decimal = Decimal(0)
    moneda: str = "CLP"

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# SHARED WORKFLOW ENUMS (API/UI CONTRACT ALIGNMENT)
# -----------------------------------------------------------------------------
class WorkflowEnums(BaseModel):
    opportunity_status: List[str]
    activity_status: List[str]
    quote_status: List[str]
    delivery_status: List[str]
    document_status: List[str]


# -----------------------------------------------------------------------------
# QUOTES
# -----------------------------------------------------------------------------
class QuoteItemBase(BaseModel):
    cotizacion_id: UUID
    empresa_id: UUID
    producto_id: UUID
    cantidad: int = 1
    notas_tecnicas: Optional[str] = None
    producto_sugerido_id: Optional[UUID] = None
    precio_neto_final: Optional[Decimal] = None
    fecha_entrega_linea: Optional[date] = None
    estado_item: str = "SOLICITADO"


class QuoteItemRead(QuoteItemBase):
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class QuoteBase(BaseModel):
    oportunidad_id: UUID
    empresa_id: UUID
    version: int = 1
    estado: str = "BORRADOR"
    moneda: str = "CLP"
    total: Decimal = Decimal("0")
    validez_hasta: Optional[datetime] = None
    notas: Optional[str] = None


class QuoteCreate(QuoteBase):
    pass


class QuoteUpdate(BaseModel):
    estado: Optional[str] = None
    total: Optional[Decimal] = None
    validez_hasta: Optional[datetime] = None
    notas: Optional[str] = None


class QuoteRead(QuoteBase):
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class QuoteDetailRead(QuoteRead):
    items: List[QuoteItemRead] = []


class QuoteVendorItemResponseUpdate(BaseModel):
    item_id: UUID
    precio_neto_final: Decimal
    producto_sugerido_id: Optional[UUID] = None
    fecha_entrega_linea: date
    estado_item: Optional[str] = None

    model_config = ConfigDict(extra="forbid")


class QuoteVendorResponseRequest(BaseModel):
    items: List[QuoteVendorItemResponseUpdate]
    delete_item_ids: Optional[List[UUID]] = None

    model_config = ConfigDict(extra="forbid")


# -----------------------------------------------------------------------------
# DELIVERIES
# -----------------------------------------------------------------------------
class DeliveryBase(BaseModel):
    oportunidad_id: UUID
    empresa_id: UUID
    estado: str = "PENDIENTE"
    referencia_externa: Optional[str] = None
    observacion: Optional[str] = None
    fecha_estimada: Optional[datetime] = None
    fecha_entrega: Optional[datetime] = None


class DeliveryCreate(DeliveryBase):
    pass


class DeliveryUpdate(BaseModel):
    estado: Optional[str] = None
    referencia_externa: Optional[str] = None
    observacion: Optional[str] = None
    fecha_estimada: Optional[datetime] = None
    fecha_entrega: Optional[datetime] = None


class DeliveryRead(DeliveryBase):
    id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# DOCUMENTS
# -----------------------------------------------------------------------------
class DocumentBase(BaseModel):
    oportunidad_id: UUID
    empresa_id: UUID
    nombre_archivo: str
    url_archivo: Optional[str] = None
    mime_type: Optional[str] = None
    estado: str = "PENDIENTE"


class DocumentCreate(DocumentBase):
    pass


class DocumentUpdate(BaseModel):
    estado: Optional[str] = None
    url_archivo: Optional[str] = None
    mime_type: Optional[str] = None


class DocumentRead(DocumentBase):
    id: UUID
    firmado_en: Optional[datetime] = None
    subido_por_id: Optional[UUID] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# -----------------------------------------------------------------------------
# KPI SNAPSHOT
# -----------------------------------------------------------------------------
class CrmKpiSnapshot(BaseModel):
    total_opportunities: int
    abierta: int
    ganada: int
    perdida: int
    total_pipeline: Decimal
    total_ganado: Decimal
    conversion_rate: float
