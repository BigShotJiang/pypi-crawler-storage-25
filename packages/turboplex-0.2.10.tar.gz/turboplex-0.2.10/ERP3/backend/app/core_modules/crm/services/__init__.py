from typing import Optional, Dict
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.ventas.models import Venta
from .credito import CRMServiceCredito
from .firma import CRMServiceFirma
from .cliente_sync import CRMClientSyncService
from .venta import convert_opportunity_to_sale as _convert_opportunity_to_sale

__all__ = ["CRMService", "convert_opportunity_to_sale", "CRMClientSyncService"]


class CRMService(CRMServiceCredito, CRMServiceFirma, CRMClientSyncService):
    @staticmethod
    def convert_opportunity_to_sale(
        db: Session,
        oportunidad_id: UUID,
        sucursal_id: UUID,
        substitutions: Optional[Dict[UUID, UUID]] = None,
        request_id: Optional[UUID] = None,
    ) -> Venta:
        return _convert_opportunity_to_sale(
            db=db,
            oportunidad_id=oportunidad_id,
            sucursal_id=sucursal_id,
            substitutions=substitutions,
            request_id=request_id,
        )


convert_opportunity_to_sale = _convert_opportunity_to_sale

