from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Date,
    ForeignKey,
    Numeric,
    Enum as SAEnum,
    Text
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship, Mapped
from app.core.database import Base, GUID
from uuid import UUID
import uuid6
import enum


# -----------------------------------------------------------------------------
# ENUMS
# -----------------------------------------------------------------------------
class EstadoOportunidad(str, enum.Enum):
    ABIERTA = "ABIERTA"
    GANADA = "GANADA"
    PERDIDA = "PERDIDA"
    ESPERANDO_FIRMA = "ESPERANDO_FIRMA"
    ESPERANDO_FIRMA_MANUAL = "ESPERANDO_FIRMA_MANUAL"


class TipoActividad(str, enum.Enum):
    LLAMADA = "LLAMADA"
    EMAIL = "EMAIL"
    REUNION = "REUNION"
    NOTA = "NOTA"


class EstadoCredito(str, enum.Enum):
    PENDIENTE = "PENDIENTE"
    APROBADO = "APROBADO"
    BLOQUEADO = "BLOQUEADO"


# -----------------------------------------------------------------------------
# EMBUDO & ETAPAS (PIPELINE & STAGES)
# -----------------------------------------------------------------------------
class Embudo(Base):
    __tablename__ = "crm_embudos"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, nullable=False)
    descripcion = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)

    # Multi-tenancy
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relations
    # empresa relation is usually defined on Empresa side or via backref there
    etapas = relationship(
        "Etapa",
        back_populates="embudo",
        order_by="Etapa.orden",
        cascade="all, delete-orphan",
    )


class Etapa(Base):
    __tablename__ = "crm_etapas"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, nullable=False)
    orden = Column(Integer, default=0, nullable=False)
    probabilidad_exito = Column(Integer, default=10, nullable=False)  # 0-100%

    embudo_id: Mapped[UUID] = Column(GUID, ForeignKey("crm_embudos.id"), nullable=False, index=True)

    # Relations
    embudo = relationship("Embudo", back_populates="etapas")
    oportunidades = relationship("OportunidadVenta", back_populates="etapa")


# -----------------------------------------------------------------------------
# OPORTUNIDAD DE VENTA
# -----------------------------------------------------------------------------
class OportunidadVenta(Base):
    __tablename__ = "crm_oportunidades"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    titulo = Column(String, index=True, nullable=False)

    # Financials (Multimoneda)
    monto_estimado = Column(Numeric(14, 2), default=0.00, nullable=False)
    moneda = Column(String, default="CLP", nullable=False) # CLP, USD

    # Relations
    cliente_id: Mapped[UUID] = Column(GUID, ForeignKey("clientes.id"), nullable=True, index=True) # Public cliente
    # Note: We might want to link to CrmCliente later, but for now it links to Public Client or undefined?
    # Actually schema says cliente_id: UUID.
    # In legacy CRM it linked to public.clientes.
    
    etapa_id: Mapped[UUID] = Column(GUID, ForeignKey("crm_etapas.id"), nullable=False, index=True)
    usuario_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=False, index=True)
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    bodega_id: Mapped[UUID] = Column(GUID, ForeignKey("bodegas.id"), nullable=True)
    sucursal_id: Mapped[UUID | None] = Column(
        GUID, ForeignKey("sucursales.id"), nullable=True, index=True
    )

    # Status
    estado = Column(SAEnum(EstadoOportunidad), default=EstadoOportunidad.ABIERTA)
    razon_perdida = Column(String, nullable=True) # Motivo de pérdida (BI)
    estado_credito = Column(SAEnum(EstadoCredito), default=EstadoCredito.PENDIENTE)

    # Timestamps
    fecha_cierre = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relations
    etapa = relationship("Etapa", back_populates="oportunidades")
    detalles = relationship("DetalleOportunidad", back_populates="oportunidad", cascade="all, delete-orphan")
    actividades = relationship("Actividad", back_populates="oportunidad", cascade="all, delete-orphan")
    comentarios = relationship("OportunidadComentario", back_populates="oportunidad", cascade="all, delete-orphan")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")


class DetalleOportunidad(Base):
    __tablename__ = "crm_oportunidad_detalles"

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    oportunidad_id: Mapped[UUID] = Column(GUID, ForeignKey("crm_oportunidades.id"), nullable=False, index=True)
    producto_id: Mapped[UUID] = Column(GUID, ForeignKey("productos.id"), nullable=False)
    
    cantidad = Column(Integer, default=1, nullable=False)
    precio_unitario = Column(Numeric(14, 2), default=0.00, nullable=False)
    
    # Relations
    oportunidad = relationship("OportunidadVenta", back_populates="detalles")
    
    @property
    def subtotal(self):
        return self.cantidad * self.precio_unitario


class Actividad(Base):
    __tablename__ = "crm_actividades"

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    oportunidad_id: Mapped[UUID] = Column(GUID, ForeignKey("crm_oportunidades.id"), nullable=False, index=True)
    usuario_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    
    tipo = Column(SAEnum(TipoActividad), default=TipoActividad.NOTA)
    resumen = Column(String, nullable=False)
    descripcion = Column(Text, nullable=True)
    fecha_vencimiento = Column(DateTime(timezone=True), nullable=True)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relations
    oportunidad = relationship("OportunidadVenta", back_populates="actividades")


class OportunidadComentario(Base):
    __tablename__ = "crm_comentarios"

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    oportunidad_id: Mapped[UUID] = Column(GUID, ForeignKey("crm_oportunidades.id"), nullable=False, index=True)
    usuario_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    
    comentario = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relations
    oportunidad = relationship("OportunidadVenta", back_populates="comentarios")


class Notification(Base):
    __tablename__ = "crm_notifications"
    
    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    mensaje = Column(String, nullable=False)
    link_documento = Column(String, nullable=True)
    leido = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    usuario_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=False, index=True)
    jefe_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True)


# -----------------------------------------------------------------------------
# NEW SCHEMA FASE 1 MODELS (BLINDADO)
# -----------------------------------------------------------------------------
class CrmCliente(Base):
    __tablename__ = "clientes"
    __table_args__ = {"schema": "crm"}

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    rut = Column(String, unique=True, index=True, nullable=False)
    razon_social = Column(String, nullable=False)
    
    # Optional references
    vendedor_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    zona_id: Mapped[UUID] = Column(GUID, nullable=True) # Placeholder for Zona model if exists
    
    estado_comercial = Column(String, default="PROSPECTO") # prospecto, activo, bloqueado
    
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class CrmExcepcionCredito(Base):
    __tablename__ = "excepciones_credito"
    __table_args__ = {"schema": "crm"}

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    
    # Link by RUT as requested, or ID? Instructions said "Vincular por cliente_rut"
    cliente_rut = Column(String, ForeignKey("crm.clientes.rut"), nullable=False, index=True)
    
    monto_autorizado = Column(Numeric(14, 0), default=0, nullable=False)
    monto_consumido = Column(Numeric(14, 0), default=0, nullable=False)
    
    documento_respaldo_url = Column(String, nullable=True)
    autorizado_por: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    fecha_expiracion = Column(DateTime(timezone=True), nullable=True)
    
    version = Column(Integer, default=1) # Optimistic locking
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class CrmPrecioAuditLog(Base):
    __tablename__ = "precio_audit_log"
    __table_args__ = {"schema": "crm"}

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    
    oportunidad_id: Mapped[UUID] = Column(GUID, ForeignKey("crm_oportunidades.id"), nullable=True)
    producto_id: Mapped[UUID] = Column(GUID, ForeignKey("productos.id"), nullable=True)
    
    precio_anterior = Column(Numeric(14, 2), nullable=True)
    precio_nuevo = Column(Numeric(14, 2), nullable=True)
    
    usuario_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    
    razon_cambio = Column(String, nullable=True)


class CrmPoliticaPrecio(Base):
    """
    Implementación del Patrón de Políticas de Precio (Propuesta CRM - Sección 2).
    Define modificadores de precio base asignados a vendedores.
    Precio Final = Precio Base * Factor
    """
    __tablename__ = "politicas_precio"
    __table_args__ = {"schema": "crm"}

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    nombre = Column(String, nullable=False)  # Ej: "Nivel Senior", "Zona Norte"
    usuario_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=False, index=True)
    factor = Column(Numeric(5, 4), default=1.0000, nullable=False)  # Ej: 0.9500 para 5% desc
    
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


# -----------------------------------------------------------------------------
# PUBLIC SCHEMA TABLES (REQUESTED BY USER)
# -----------------------------------------------------------------------------
class TableCrm(Base):
    __tablename__ = "table_crm"
    # No schema arg -> goes to public schema by default

    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)
    nombre = Column(String, nullable=True)
    descripcion = Column(String, nullable=True)
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)


# -----------------------------------------------------------------------------
# QUOTES / DELIVERIES / DOCUMENTS / KPI SUPPORT
# -----------------------------------------------------------------------------
class EstadoCotizacion(str, enum.Enum):
    BORRADOR = "BORRADOR"
    BORRADOR_CLIENTE = "BORRADOR_CLIENTE"
    PENDIENTE_VENDEDOR = "PENDIENTE_VENDEDOR"
    PROPUESTA_ENVIADA = "PROPUESTA_ENVIADA"
    ENVIADA = "ENVIADA"
    APROBADA = "APROBADA"
    ACEPTADA_OC = "ACEPTADA_OC"
    RECHAZADA = "RECHAZADA"
    VENCIDA = "VENCIDA"


class EstadoItemCotizacion(str, enum.Enum):
    SOLICITADO = "SOLICITADO"
    SUGERIDO = "SUGERIDO"
    RECHAZADO_CLIENTE = "RECHAZADO_CLIENTE"


class EstadoEntrega(str, enum.Enum):
    PENDIENTE = "PENDIENTE"
    EN_PREPARACION = "EN_PREPARACION"
    EN_RUTA = "EN_RUTA"
    ENTREGADA = "ENTREGADA"
    INCIDENCIA = "INCIDENCIA"


class EstadoDocumento(str, enum.Enum):
    PENDIENTE = "PENDIENTE"
    SUBIDO = "SUBIDO"
    FIRMADO = "FIRMADO"
    RECHAZADO = "RECHAZADO"


class Cotizacion(Base):
    __tablename__ = "crm_cotizaciones"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    oportunidad_id: Mapped[UUID] = Column(
        GUID, ForeignKey("crm_oportunidades.id"), nullable=False, index=True
    )
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    vendedor_operador_id: Mapped[UUID | None] = Column(
        GUID, ForeignKey("usuarios.id"), nullable=True, index=True
    )
    version = Column(Integer, default=1, nullable=False)
    estado = Column(SAEnum(EstadoCotizacion), default=EstadoCotizacion.BORRADOR, nullable=False)
    moneda = Column(String, default="CLP", nullable=False)
    total = Column(Numeric(14, 2), default=0, nullable=False)
    validez_hasta = Column(DateTime(timezone=True), nullable=True)
    notas = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    items = relationship(
        "CotizacionItem", back_populates="cotizacion", cascade="all, delete-orphan"
    )
    vendedor_operador = relationship("app.core_modules.sistema.models.Usuario")


class CotizacionItem(Base):
    __tablename__ = "crm_cotizaciones_items"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    cotizacion_id: Mapped[UUID] = Column(
        GUID, ForeignKey("crm_cotizaciones.id"), nullable=False, index=True
    )
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    producto_id: Mapped[UUID] = Column(
        GUID, ForeignKey("productos.id"), nullable=False, index=True
    )
    cantidad = Column(Integer, default=1, nullable=False)
    notas_tecnicas = Column(Text, nullable=True)

    producto_sugerido_id: Mapped[UUID | None] = Column(
        GUID, ForeignKey("productos.id"), nullable=True
    )
    precio_neto_final = Column(Numeric(14, 2), nullable=True)
    fecha_entrega_linea = Column(Date, nullable=True)
    estado_item = Column(SAEnum(EstadoItemCotizacion), default=EstadoItemCotizacion.SOLICITADO, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    cotizacion = relationship("Cotizacion", back_populates="items")
    producto = relationship(
        "app.core_modules.ventas.models.Producto", foreign_keys=[producto_id]
    )
    producto_sugerido = relationship(
        "app.core_modules.ventas.models.Producto", foreign_keys=[producto_sugerido_id]
    )


class SeguimientoEntrega(Base):
    __tablename__ = "crm_entregas"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    oportunidad_id: Mapped[UUID] = Column(
        GUID, ForeignKey("crm_oportunidades.id"), nullable=False, index=True
    )
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    estado = Column(SAEnum(EstadoEntrega), default=EstadoEntrega.PENDIENTE, nullable=False)
    referencia_externa = Column(String, nullable=True)
    observacion = Column(Text, nullable=True)
    fecha_estimada = Column(DateTime(timezone=True), nullable=True)
    fecha_entrega = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class DocumentoCRM(Base):
    __tablename__ = "crm_documentos"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    oportunidad_id: Mapped[UUID] = Column(
        GUID, ForeignKey("crm_oportunidades.id"), nullable=False, index=True
    )
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    nombre_archivo = Column(String, nullable=False)
    url_archivo = Column(String, nullable=True)
    mime_type = Column(String, nullable=True)
    estado = Column(SAEnum(EstadoDocumento), default=EstadoDocumento.PENDIENTE, nullable=False)
    firmado_en = Column(DateTime(timezone=True), nullable=True)
    subido_por_id: Mapped[UUID] = Column(GUID, ForeignKey("usuarios.id"), nullable=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
