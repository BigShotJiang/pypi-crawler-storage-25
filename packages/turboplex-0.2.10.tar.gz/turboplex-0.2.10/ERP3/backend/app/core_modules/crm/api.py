from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List, Any, Optional
from uuid import UUID
from datetime import datetime
from app.core.database import get_db
from app.core_modules.crm import schemas, services, models
from app.core_modules.ventas.schemas import Venta as VentaSchema
from app.core_modules.ventas import models as ventas_models
from app.core_modules.ventas.inventory_service import InventoryService
from decimal import Decimal

from app.api import deps
from app.core_modules.sistema.models import Usuario, Empresa, Sucursal
from app.core.security.security_audit import SecurityAudit

router = APIRouter()


ALLOWED_CRM_ROLES = {"ADMIN", "VENDEDOR", "SUPERADMIN", "DEVELOPER", "USER"}


def _ensure_crm_role(current_user: Usuario) -> None:
    if current_user.role not in ALLOWED_CRM_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Rol sin permisos para operar en CRM",
        )


# -----------------------------------------------------------------------------
# NOTIFICATIONS
# -----------------------------------------------------------------------------
@router.get("/notifications", response_model=List[schemas.NotificationRead], tags=["CRM"])
def get_notifications(
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    unread_only: bool = False,
) -> List[schemas.NotificationRead]:
    """
    Obtener notificaciones del usuario actual.
    """
    query = db.query(models.Notification).filter(
        models.Notification.usuario_id == current_user.id
    )
    if unread_only:
        query = query.filter(not models.Notification.leido)

    rows = query.order_by(models.Notification.created_at.desc()).all()
    return [schemas.NotificationRead.model_validate(r) for r in rows]


# -----------------------------------------------------------------------------
# PIPELINES (EMBUDOS)
# -----------------------------------------------------------------------------
@router.get("/pipelines/", response_model=List[schemas.EmbudoRead], tags=["CRM Config"])
def list_pipelines(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Listar embudos de la empresa activa.
    """
    pipelines = (
        db.query(models.Embudo)
        .filter(models.Embudo.empresa_id == current_company.id)
        .order_by(models.Embudo.nombre)
        .all()
    )
    return pipelines


@router.post("/pipelines/", response_model=schemas.EmbudoRead, tags=["CRM Config"])
def create_pipeline(
    pipeline_in: schemas.EmbudoCreate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    """
    Crear nuevo embudo.
    """
    if pipeline_in.empresa_id != current_company.id:
         raise HTTPException(status_code=400, detail="Empresa ID mismatch")

    pipeline = models.Embudo(**pipeline_in.model_dump())
    db.add(pipeline)
    db.commit()
    db.refresh(pipeline)
    return pipeline


@router.post("/pipelines/{pipeline_id}/stages", response_model=schemas.EtapaRead, tags=["CRM Config"])
def create_stage(
    pipeline_id: UUID,
    stage_in: schemas.EtapaBase,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Agregar etapa a un embudo.
    """
    pipeline = db.query(models.Embudo).filter(
        models.Embudo.id == pipeline_id,
        models.Embudo.empresa_id == current_company.id
    ).first()
    
    if not pipeline:
        raise HTTPException(status_code=404, detail="Embudo no encontrado")

    stage = models.Etapa(
        embudo_id=pipeline_id,
        **stage_in.model_dump()
    )
    db.add(stage)
    db.commit()
    db.refresh(stage)
    return stage


# -----------------------------------------------------------------------------
# OPPORTUNITIES
# -----------------------------------------------------------------------------
@router.get("/opportunities", response_model=List[schemas.OportunidadRead], tags=["CRM"])
def list_opportunities(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    skip: int = 0,
    limit: int = 100,
) -> List[schemas.OportunidadRead]:
    """
    Listar oportunidades de la empresa activa.
    """
    rows = (
        db.query(models.OportunidadVenta)
        .filter(models.OportunidadVenta.empresa_id == current_company.id)
        .order_by(desc(models.OportunidadVenta.created_at))
        .offset(skip)
        .limit(limit)
        .all()
    )
    return rows


@router.get("/opportunities/{id}", response_model=schemas.OportunidadRead, tags=["CRM"])
def get_opportunity(
    id: UUID,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtener detalle de oportunidad.
    """
    opp = db.query(models.OportunidadVenta).filter(
        models.OportunidadVenta.id == id,
        models.OportunidadVenta.empresa_id == current_company.id
    ).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")
    return opp


@router.post("/opportunities/", response_model=schemas.OportunidadRead, tags=["CRM"])
def create_opportunity(
    opp_in: schemas.OportunidadCreate,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_user),
) -> schemas.OportunidadRead:
    # Security Check: User must belong to the target company
    user_company_ids = [assoc.empresa_id for assoc in current_user.empresas_asociadas]
    if opp_in.empresa_id not in user_company_ids:
        SecurityAudit.log(
            db=db,
            actor_id=current_user.id,
            action="UNAUTHORIZED_CREATE_ATTEMPT",
            resource=f"Empresa:{opp_in.empresa_id}",
            severity="HIGH",
            changes={
                "target_company": str(opp_in.empresa_id),
                "user_companies": [str(uid) for uid in user_company_ids],
            },
        )
        raise HTTPException(
            status_code=403,
            detail="No tiene permiso para crear oportunidades en esta empresa",
        )

    # Basic creation logic
    opp_data = opp_in.model_dump(exclude={"detalles"})
    default_sucursal_id = (
        db.query(Sucursal.id)
        .filter(Sucursal.empresa_id == opp_in.empresa_id)
        .order_by(Sucursal.created_at.asc())
        .scalar()
    )
    if default_sucursal_id:
        opp_data["sucursal_id"] = default_sucursal_id
    opp = models.OportunidadVenta(
        **opp_data,
        estado=models.EstadoOportunidad.ABIERTA,
    )
    db.add(opp)
    db.flush()

    for detalle in opp_in.detalles:
        db_detalle = models.DetalleOportunidad(
            oportunidad_id=opp.id,
            producto_id=detalle.producto_id,
            cantidad=detalle.cantidad,
            precio_unitario=detalle.precio_unitario,
        )
        db.add(db_detalle)

    db.commit()
    db.refresh(opp)
    return opp


@router.patch("/opportunities/{id}", response_model=schemas.OportunidadRead, tags=["CRM"])
def update_opportunity(
    id: UUID,
    opp_in: schemas.OportunidadUpdate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Actualizar oportunidad.
    """
    opp = db.query(models.OportunidadVenta).filter(
        models.OportunidadVenta.id == id,
        models.OportunidadVenta.empresa_id == current_company.id
    ).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

    update_data = opp_in.model_dump(exclude_unset=True)
    
    # Validation: Razon perdida is mandatory if status is LOST (Pilar 4 - Flujos Inteligentes)
    if update_data.get("estado") == models.EstadoOportunidad.PERDIDA:
        if not update_data.get("razon_perdida") and not opp.razon_perdida:
            raise HTTPException(
                status_code=400, 
                detail="Debe indicar el motivo de pérdida (razon_perdida) al cerrar la oportunidad como PERDIDA."
            )

    for field, value in update_data.items():
        setattr(opp, field, value)

    db.add(opp)
    db.commit()
    db.refresh(opp)
    return opp


@router.post("/opportunities/{id}/convert", response_model=VentaSchema, tags=["CRM"])
def convert_opportunity(
    id: UUID,
    convert_in: schemas.OportunidadConvert,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    """
    Convertir Oportunidad Ganada a Venta (Integración ERP).
    - Idempotente (request_id)
    - Genera Venta, Asiento y DTE
    """
    # 1. Validar acceso a la oportunidad
    opp = db.query(models.OportunidadVenta).filter(
        models.OportunidadVenta.id == id,
        models.OportunidadVenta.empresa_id == current_company.id
    ).first()
    
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

    # 2. Ejecutar servicio de conversión
    # Nota: services.convert_opportunity_to_sale maneja la lógica de negocio
    # incluyendo validaciones de estado, stock y creación de registros ERP.
    venta = services.convert_opportunity_to_sale(
        db=db,
        oportunidad_id=id,
        sucursal_id=convert_in.sucursal_id,
        substitutions=None, # Future implementation
        request_id=convert_in.request_id,
    )
    
    return venta


# -----------------------------------------------------------------------------
# CLIENTES CRM
# -----------------------------------------------------------------------------
@router.post("/clients/", response_model=schemas.CrmClienteRead, tags=["CRM Clients"])
def create_crm_client(
    client_in: schemas.CrmClienteCreate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    """
    Crear Cliente en CRM y Sincronizar con ERP (Public Schema).
    """
    if client_in.empresa_id != current_company.id:
        raise HTTPException(status_code=400, detail="Empresa ID mismatch")

    # 1. Crear en CRM
    crm_client = models.CrmCliente(**client_in.model_dump())
    db.add(crm_client)
    db.flush()

    # 2. Sincronizar con ERP (Public Schema)
    # Esto asegura que el cliente exista en el ERP para facturación/ventas futuras
    try:
        services.CRMService.sync_to_public(db=db, crm_cliente=crm_client)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    db.commit()
    db.refresh(crm_client)
    return crm_client


@router.get("/clients/", response_model=List[schemas.CrmClienteRead], tags=["CRM Clients"])
def list_crm_clients(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    skip: int = 0,
    limit: int = 100,
) -> Any:
    """
    Listar Clientes del CRM.
    """
    clients = (
        db.query(models.CrmCliente)
        .filter(models.CrmCliente.empresa_id == current_company.id)
        .order_by(models.CrmCliente.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return clients


@router.get("/clients/{id}/credit-status", response_model=schemas.CrmEstadoCredito, tags=["CRM Clients"])
def get_client_credit_status(
    id: UUID,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    """
    Obtener estado de crédito del cliente (Semáforo Financiero).
    Consulta en tiempo real la deuda en ERP (Contabilidad).
    """
    return services.CRMServiceCredito.get_estado_credito(
        db=db,
        crm_cliente_id=id,
        empresa_id=current_company.id
    )


# -----------------------------------------------------------------------------
# PRODUCTOS (READ-ONLY + STOCK)
# -----------------------------------------------------------------------------
@router.get("/products/", response_model=List[schemas.CrmProductoRead], tags=["CRM Products"])
def list_crm_products(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
    skip: int = 0,
    limit: int = 100,
    q: Optional[str] = None,
    sucursal_id: Optional[UUID] = None,
) -> Any:
    """
    Listar productos disponibles para la venta (desde ERP).
    Incluye stock disponible calculado en tiempo real.
    Aplica Política de Precios del vendedor (si existe).
    - Si se envía `sucursal_id`, filtra el stock por esa sucursal.
    - Si no, muestra el stock global de la empresa.
    """
    # 1. Fetch products
    query = db.query(ventas_models.Producto).filter(
        ventas_models.Producto.empresa_id == current_company.id,
        ventas_models.Producto.is_active
    )
    
    if q:
        query = query.filter(
            (ventas_models.Producto.nombre.ilike(f"%{q}%")) | 
            (ventas_models.Producto.sku.ilike(f"%{q}%"))
        )

    products = query.order_by(ventas_models.Producto.nombre).offset(skip).limit(limit).all()

    # 2. Bulk fetch stock
    stock_map = InventoryService.get_stock_for_company(
        db=db, 
        empresa_id=current_company.id,
        sucursal_id=sucursal_id
    )

    # 3. Fetch Price Policy for current user (Policy Pattern)
    policy = db.query(models.CrmPoliticaPrecio).filter(
        models.CrmPoliticaPrecio.usuario_id == current_user.id,
        models.CrmPoliticaPrecio.empresa_id == current_company.id,
        models.CrmPoliticaPrecio.is_active
    ).first()

    factor = policy.factor if policy else Decimal(1.0)
    policy_name = policy.nombre if policy else None

    results = []
    for p in products:
        stock = stock_map.get(p.id, Decimal(0))
        
        # Calculate dynamic price
        precio_lista = p.precio
        precio_calculado = precio_lista * factor
        
        item = schemas.CrmProductoRead(
            id=p.id,
            nombre=p.nombre,
            sku=p.sku,
            precio_lista=precio_lista,
            precio_calculado=precio_calculado,
            factor_politica=factor,
            nombre_politica=policy_name,
            stock_disponible=stock,
            moneda="CLP"
        )
        results.append(item)

    return results


# -----------------------------------------------------------------------------
# ACTIVITIES (TASKS/NOTES)
# -----------------------------------------------------------------------------
@router.post("/activities/", response_model=schemas.ActividadRead, tags=["CRM Activities"])
def create_activity(
    activity_in: schemas.ActividadCreate,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    """
    Crear actividad (nota, llamada, reunión).
    """
    # Verify opportunity access
    opp = db.query(models.OportunidadVenta).filter(models.OportunidadVenta.id == activity_in.oportunidad_id).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")
    
    # Check if user has access to this opportunity's company
    user_company_ids = [assoc.empresa_id for assoc in current_user.empresas_asociadas]
    if opp.empresa_id not in user_company_ids:
        raise HTTPException(status_code=403, detail="No tiene acceso a esta oportunidad")

    activity_data = activity_in.model_dump()
    if not activity_data.get("usuario_id"):
        activity_data["usuario_id"] = current_user.id

    activity = models.Actividad(**activity_data)
    db.add(activity)
    db.commit()
    db.refresh(activity)
    return activity


@router.get("/activities/", response_model=List[schemas.ActividadRead], tags=["CRM Activities"])
def list_activities(
    oportunidad_id: UUID,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    """
    Listar actividades de una oportunidad.
    """
    # Verify opportunity access
    opp = db.query(models.OportunidadVenta).filter(models.OportunidadVenta.id == oportunidad_id).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")
    
    user_company_ids = [assoc.empresa_id for assoc in current_user.empresas_asociadas]
    if opp.empresa_id not in user_company_ids:
         raise HTTPException(status_code=403, detail="No tiene acceso a esta oportunidad")

    activities = (
        db.query(models.Actividad)
        .filter(models.Actividad.oportunidad_id == oportunidad_id)
        .order_by(desc(models.Actividad.created_at))
        .all()
    )
    return activities


# -----------------------------------------------------------------------------
# COMMENTS
# -----------------------------------------------------------------------------
@router.post("/opportunities/{id}/comments", response_model=schemas.ComentarioRead, tags=["CRM Comments"])
def add_comment(
    id: UUID,
    comment_in: schemas.ComentarioBase,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    """
    Agregar comentario a oportunidad.
    """
    opp = db.query(models.OportunidadVenta).filter(models.OportunidadVenta.id == id).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")
    
    user_company_ids = [assoc.empresa_id for assoc in current_user.empresas_asociadas]
    if opp.empresa_id not in user_company_ids:
         raise HTTPException(status_code=403, detail="No tiene acceso a esta oportunidad")

    comment = models.OportunidadComentario(
        oportunidad_id=id,
        usuario_id=current_user.id,
        comentario=comment_in.comentario
    )
    db.add(comment)
    db.commit()
    db.refresh(comment)
    return comment


# -----------------------------------------------------------------------------
# WORKFLOW ENUMS CONTRACT
# -----------------------------------------------------------------------------
@router.get("/workflow/enums", response_model=schemas.WorkflowEnums, tags=["CRM Config"])
def get_workflow_enums(
    current_user: Usuario = Depends(deps.get_current_user),
) -> schemas.WorkflowEnums:
    _ensure_crm_role(current_user)
    return schemas.WorkflowEnums(
        opportunity_status=[s.value for s in models.EstadoOportunidad],
        activity_status=[s.value for s in models.TipoActividad],
        quote_status=[s.value for s in models.EstadoCotizacion],
        delivery_status=[s.value for s in models.EstadoEntrega],
        document_status=[s.value for s in models.EstadoDocumento],
    )


# -----------------------------------------------------------------------------
# QUOTES
# -----------------------------------------------------------------------------
@router.get("/quotes/", response_model=List[schemas.QuoteRead], tags=["CRM Quotes"])
def list_quotes(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
    oportunidad_id: Optional[UUID] = None,
    limit: int = 100,
) -> Any:
    _ensure_crm_role(current_user)
    q = db.query(models.Cotizacion).filter(models.Cotizacion.empresa_id == current_company.id)
    if oportunidad_id:
        q = q.filter(models.Cotizacion.oportunidad_id == oportunidad_id)
    return q.order_by(desc(models.Cotizacion.created_at)).limit(limit).all()


@router.post("/quotes/", response_model=schemas.QuoteRead, tags=["CRM Quotes"])
def create_quote(
    quote_in: schemas.QuoteCreate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    if quote_in.empresa_id != current_company.id:
        raise HTTPException(status_code=400, detail="Empresa ID mismatch")
    quote = models.Cotizacion(**quote_in.model_dump())
    db.add(quote)
    db.commit()
    db.refresh(quote)
    return quote


@router.patch("/quotes/{quote_id}", response_model=schemas.QuoteRead, tags=["CRM Quotes"])
def update_quote(
    quote_id: UUID,
    quote_in: schemas.QuoteUpdate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    quote = db.query(models.Cotizacion).filter(
        models.Cotizacion.id == quote_id,
        models.Cotizacion.empresa_id == current_company.id,
    ).first()
    if not quote:
        raise HTTPException(status_code=404, detail="Cotización no encontrada")
    for field, value in quote_in.model_dump(exclude_unset=True).items():
        setattr(quote, field, value)
    db.add(quote)
    db.commit()
    db.refresh(quote)
    return quote


# -----------------------------------------------------------------------------
# DELIVERIES
# -----------------------------------------------------------------------------
@router.get("/deliveries/", response_model=List[schemas.DeliveryRead], tags=["CRM Deliveries"])
def list_deliveries(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
    oportunidad_id: Optional[UUID] = None,
    limit: int = 100,
) -> Any:
    _ensure_crm_role(current_user)
    q = db.query(models.SeguimientoEntrega).filter(models.SeguimientoEntrega.empresa_id == current_company.id)
    if oportunidad_id:
        q = q.filter(models.SeguimientoEntrega.oportunidad_id == oportunidad_id)
    return q.order_by(desc(models.SeguimientoEntrega.created_at)).limit(limit).all()


@router.post("/deliveries/", response_model=schemas.DeliveryRead, tags=["CRM Deliveries"])
def create_delivery(
    delivery_in: schemas.DeliveryCreate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    if delivery_in.empresa_id != current_company.id:
        raise HTTPException(status_code=400, detail="Empresa ID mismatch")
    record = models.SeguimientoEntrega(**delivery_in.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.patch("/deliveries/{delivery_id}", response_model=schemas.DeliveryRead, tags=["CRM Deliveries"])
def update_delivery(
    delivery_id: UUID,
    delivery_in: schemas.DeliveryUpdate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    record = db.query(models.SeguimientoEntrega).filter(
        models.SeguimientoEntrega.id == delivery_id,
        models.SeguimientoEntrega.empresa_id == current_company.id,
    ).first()
    if not record:
        raise HTTPException(status_code=404, detail="Seguimiento no encontrado")
    for field, value in delivery_in.model_dump(exclude_unset=True).items():
        setattr(record, field, value)
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


# -----------------------------------------------------------------------------
# DOCUMENTS
# -----------------------------------------------------------------------------
@router.get("/documents/", response_model=List[schemas.DocumentRead], tags=["CRM Documents"])
def list_documents(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
    oportunidad_id: Optional[UUID] = None,
    limit: int = 100,
) -> Any:
    _ensure_crm_role(current_user)
    q = db.query(models.DocumentoCRM).filter(models.DocumentoCRM.empresa_id == current_company.id)
    if oportunidad_id:
        q = q.filter(models.DocumentoCRM.oportunidad_id == oportunidad_id)
    return q.order_by(desc(models.DocumentoCRM.created_at)).limit(limit).all()


@router.post("/documents/", response_model=schemas.DocumentRead, tags=["CRM Documents"])
def create_document(
    doc_in: schemas.DocumentCreate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    if doc_in.empresa_id != current_company.id:
        raise HTTPException(status_code=400, detail="Empresa ID mismatch")
    record = models.DocumentoCRM(
        **doc_in.model_dump(),
        subido_por_id=current_user.id,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.patch("/documents/{document_id}", response_model=schemas.DocumentRead, tags=["CRM Documents"])
def update_document(
    document_id: UUID,
    doc_in: schemas.DocumentUpdate,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    record = db.query(models.DocumentoCRM).filter(
        models.DocumentoCRM.id == document_id,
        models.DocumentoCRM.empresa_id == current_company.id,
    ).first()
    if not record:
        raise HTTPException(status_code=404, detail="Documento no encontrado")
    updates = doc_in.model_dump(exclude_unset=True)
    if updates.get("estado") == models.EstadoDocumento.FIRMADO.value:
        record.firmado_en = datetime.utcnow()
    for field, value in updates.items():
        setattr(record, field, value)
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


# -----------------------------------------------------------------------------
# REPORTS / KPI SNAPSHOT
# -----------------------------------------------------------------------------
@router.get("/reports/kpis", response_model=schemas.CrmKpiSnapshot, tags=["CRM Reports"])
def crm_kpis(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    opps = db.query(models.OportunidadVenta).filter(
        models.OportunidadVenta.empresa_id == current_company.id
    ).all()
    total = len(opps)
    abierta = len([o for o in opps if o.estado == models.EstadoOportunidad.ABIERTA])
    ganada = len([o for o in opps if o.estado == models.EstadoOportunidad.GANADA])
    perdida = len([o for o in opps if o.estado == models.EstadoOportunidad.PERDIDA])
    total_pipeline = sum((Decimal(str(o.monto_estimado or 0)) for o in opps if o.estado == models.EstadoOportunidad.ABIERTA), Decimal("0"))
    total_ganado = sum((Decimal(str(o.monto_estimado or 0)) for o in opps if o.estado == models.EstadoOportunidad.GANADA), Decimal("0"))
    closed = ganada + perdida
    rate = float((ganada / closed) * 100) if closed else 0.0
    return schemas.CrmKpiSnapshot(
        total_opportunities=total,
        abierta=abierta,
        ganada=ganada,
        perdida=perdida,
        total_pipeline=total_pipeline,
        total_ganado=total_ganado,
        conversion_rate=rate,
    )
