import hashlib
import io
from datetime import datetime
from typing import Any, Dict, Optional, BinaryIO, cast
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core_modules.crm.models import (
    OportunidadVenta,
    EstadoOportunidad,
    EstadoCredito,
    OportunidadComentario,
)
from app.core_modules.legal.models import DocumentoLegal, EstadoDocumento
from app.core_modules.ventas.models import Venta
from app.core.services.pdf_generator import PDFGenerator
from app.core.services.storage_service import StorageService
from .venta import convert_opportunity_to_sale


class CRMServiceFirma:
    @staticmethod
    def prepare_signature(db: Session, oportunidad_id: UUID) -> Dict[str, Any]:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        oportunidad_any = cast(Any, oportunidad)

        if oportunidad.estado_credito != EstadoCredito.APROBADO:
            raise HTTPException(status_code=400, detail="El crédito no está aprobado")

        if not oportunidad.bodega_id:
            raise HTTPException(
                status_code=400, detail="No hay stock reservado (Falta bodega_id)"
            )

        validation_url = f"https://erp3-frontend.com/validate/doc/{oportunidad.id}"

        data_string = (
            f"{oportunidad.id}|{oportunidad.monto_estimado}|"
            f"{datetime.now().isoformat()}"
        )
        doc_hash = hashlib.sha256(data_string.encode()).hexdigest()

        pdf_buffer = PDFGenerator.generate_delivery_guide(
            opportunity=oportunidad,
            items=oportunidad.detalles,
            validation_url=validation_url,
            doc_hash=doc_hash,
        )

        pdf_content = pdf_buffer.getvalue()

        file_hash_sha256 = hashlib.sha256(pdf_content).hexdigest()

        file_obj = io.BytesIO(pdf_content)

        storage_cls: Any = StorageService
        storage: Any = storage_cls()
        rut_cliente = oportunidad.cliente.rut if oportunidad.cliente else "unknown_rut"

        documento = storage.register_legal_document(
            db=db,
            file_obj=file_obj,
            oportunidad_id=oportunidad.id,
            tenant_id=oportunidad.empresa_id,
            rut_cliente=rut_cliente,
            hash_integridad=file_hash_sha256,
        )

        oportunidad_any.estado = EstadoOportunidad.ESPERANDO_FIRMA
        db.add(oportunidad)
        db.commit()

        presigned_url = storage.generate_presigned_url(
            cast(str, documento.ruta_archivo)
        )

        return {
            "documento_id": str(documento.id),
            "presigned_url": presigned_url,
            "doc_hash": doc_hash,
        }

    @staticmethod
    def void_document(
        db: Session, oportunidad_id: UUID, usuario_id: Optional[UUID] = None
    ) -> OportunidadVenta:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        oportunidad_any = cast(Any, oportunidad)

        if oportunidad.estado == EstadoOportunidad.GANADA:
            raise HTTPException(
                status_code=400,
                detail=(
                    "No se puede anular un documento de una oportunidad ya "
                    "Ganada/Firmada"
                ),
            )

        documentos_pendientes = (
            db.query(DocumentoLegal)
            .filter(
                DocumentoLegal.oportunidad_id == oportunidad_id,
                DocumentoLegal.estado == EstadoDocumento.PENDIENTE,
            )
            .all()
        )

        if not documentos_pendientes and oportunidad.estado not in [
            EstadoOportunidad.ESPERANDO_FIRMA,
            EstadoOportunidad.ESPERANDO_FIRMA_MANUAL,
        ]:
            pass

        for doc in documentos_pendientes:
            doc_any = cast(Any, doc)
            doc_any.estado = EstadoDocumento.ANULADO
            db.add(doc)

        oportunidad_any.estado = EstadoOportunidad.ABIERTA

        comentario = (
            f"Documento anulado por usuario {usuario_id or 'Desconocido'}. "
            f"Oportunidad devuelta a edición."
        )
        nuevo_comentario = OportunidadComentario(
            oportunidad_id=oportunidad.id, usuario_id=usuario_id, comentario=comentario
        )
        db.add(nuevo_comentario)

        db.commit()
        db.refresh(oportunidad)
        return oportunidad

    @staticmethod
    def confirm_manual_print(db: Session, oportunidad_id: UUID) -> OportunidadVenta:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        if oportunidad.estado != EstadoOportunidad.ESPERANDO_FIRMA:
            raise HTTPException(
                status_code=400,
                detail=(
                    "La oportunidad no está esperando firma "
                    "(Debe preparar firma primero)"
                ),
            )

        oportunidad_any = cast(Any, oportunidad)
        oportunidad_any.estado = EstadoOportunidad.ESPERANDO_FIRMA_MANUAL
        db.add(oportunidad)
        db.commit()
        db.refresh(oportunidad)
        return oportunidad

    @staticmethod
    def upload_signed_document(
        db: Session,
        oportunidad_id: UUID,
        file_obj: BinaryIO,
        filename: str,
        sucursal_id: UUID,
    ) -> Venta:
        oportunidad = (
            db.query(OportunidadVenta)
            .filter(OportunidadVenta.id == oportunidad_id)
            .first()
        )
        if not oportunidad:
            raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

        if oportunidad.estado not in [
            EstadoOportunidad.ESPERANDO_FIRMA,
            EstadoOportunidad.ESPERANDO_FIRMA_MANUAL,
        ]:
            raise HTTPException(
                status_code=400, detail="La oportunidad no está esperando firma"
            )

        documento = (
            db.query(DocumentoLegal)
            .filter(
                DocumentoLegal.oportunidad_id == oportunidad_id,
                DocumentoLegal.estado == EstadoDocumento.PENDIENTE,
            )
            .order_by(DocumentoLegal.fecha_creacion.desc())
            .first()
        )

        if not documento:
            raise HTTPException(
                status_code=404,
                detail=(
                    "No se encontró un documento legal pendiente para esta "
                    "oportunidad"
                ),
            )

        storage_cls: Any = StorageService
        storage: Any = storage_cls()
        ext = filename.split(".")[-1] if "." in filename else "pdf"
        doc_uuid = str(documento.id)
        rut_cliente = oportunidad.cliente.rut if oportunidad.cliente else "unknown_rut"

        now = datetime.now()
        year = now.strftime("%Y")
        month = now.strftime("%m")
        safe_rut = rut_cliente.replace("/", "-").replace("\\", "-")
        path_signed = (
            f"tenant_{oportunidad.empresa_id}/rut_{safe_rut}/"
            f"{year}/{month}/{doc_uuid}_signed.{ext}"
        )

        try:
            storage.upload_file(file_obj, path_signed)
        except Exception as e:
            raise HTTPException(
                status_code=500, detail=f"Error al subir archivo firmado: {str(e)}"
            )

        doc_any = cast(Any, documento)
        doc_any.ruta_archivo_firmado = path_signed
        doc_any.estado = EstadoDocumento.FIRMADO
        doc_any.fecha_firma = datetime.now()
        db.add(documento)

        venta = convert_opportunity_to_sale(
            db=db, oportunidad_id=oportunidad_id, sucursal_id=sucursal_id
        )

        return venta
