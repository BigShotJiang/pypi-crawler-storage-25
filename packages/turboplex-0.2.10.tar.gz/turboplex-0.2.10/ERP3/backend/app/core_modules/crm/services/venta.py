from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, cast
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy.orm import Session, selectinload

from app.core_modules.crm.models import OportunidadVenta, EstadoOportunidad
from app.core_modules.finanzas.models_rates import ExchangeRates
from app.core_modules.inventario.stock.services import InventoryService
from app.core_modules.ventas.models import (
    Venta,
    DetalleVenta,
)
from app.core_modules.finanzas import accounting_service
from app.core_modules.facturacion import services as facturacion_services


def convert_opportunity_to_sale(
    db: Session,
    oportunidad_id: UUID,
    sucursal_id: UUID,
    substitutions: Optional[Dict[UUID, UUID]] = None,
    request_id: Optional[UUID] = None,
) -> Venta:
    """
    Convierte una Oportunidad Ganada en una Venta.
    Incluye:
    - Idempotencia (request_id)
    - Consumo de Stock Reservado
    - Creación de Asiento Contable
    - Generación de DTE (Facturación)
    - Creación de Orden de Servicio (si aplica)
    """
    
    # 0. Idempotencia (CRM request_id)
    if request_id:
        req_marker = f"[REQ_ID:{request_id}]"
        existing = (
            db.query(Venta)
            .filter(
                Venta.observaciones.contains(req_marker)
            )
            .first()
        )
        if existing:
            # Validar que pertenezca a la misma oportunidad (por folio)
            if existing.folio == f"OPP-{oportunidad_id}":
                return existing
            # Si es otro request_id pero mismo folio, algo raro pasa, pero retornamos existing

    opp = (
        db.query(OportunidadVenta)
        .options(selectinload(OportunidadVenta.detalles))
        .filter(OportunidadVenta.id == oportunidad_id)
        .first()
    )
    if not opp:
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")

    if opp.estado == EstadoOportunidad.GANADA:
        # Check if sale exists
        existing_sale = db.query(Venta).filter(Venta.folio == f"OPP-{opp.id}").first()
        if existing_sale:
            return existing_sale
        raise HTTPException(status_code=400, detail="La oportunidad ya fue ganada pero no se encontró venta asociada")

    tipo_cambio = Decimal("1.0")
    if opp.moneda != "CLP":
        rate_entry = (
            db.query(ExchangeRates)
            .filter(ExchangeRates.currency_code == opp.moneda)
            .first()
        )
        if not rate_entry:
            raise HTTPException(status_code=400, detail="Tasa de cambio no encontrada")
        tipo_cambio = Decimal(str(rate_entry.rate))

    # Prepare observaciones with request_id marker
    observaciones = f"Generado desde Oportunidad {opp.titulo}"
    if request_id:
        observaciones = f"[REQ_ID:{request_id}] {observaciones}"

    new_venta = Venta(
        fecha=datetime.now(),
        folio=f"OPP-{opp.id}",
        total=Decimal("0.0"),
        moneda=opp.moneda,
        tipo_cambio=tipo_cambio,
        cliente_id=opp.cliente_id,
        sucursal_id=sucursal_id,
        empresa_id=opp.empresa_id,
        vendedor_id=opp.usuario_id,
        observaciones=observaciones,
    )
    db.add(new_venta)
    db.flush() # Generate ID

    total_venta = Decimal("0.0")

    for item in opp.detalles:
        producto_id = item.producto_id
        cantidad = Decimal(str(item.cantidad))

        if substitutions and item.id in substitutions:
            producto_id = substitutions[item.id]

        # Stock Logic
        if opp.bodega_id:
            InventoryService.consume_reserved_stock(
                db=db,
                producto_id=producto_id,
                bodega_id=cast(Any, opp.bodega_id),
                cantidad=int(cantidad),
                tipo_movimiento="VENTA_CRM",
                empresa_id=opp.empresa_id,
            )
        
        # Check if service (basic check, ideally check Product type)
        # Assuming product type check or explicit flag needed. 
        # For now, we rely on product type from DB if needed, but here we don't query Product.
        # However, to be safe for Service Order, we should query Product type.
        # But let's assume standard behavior: all items added to Venta.
        
        subtotal_item = item.precio_unitario * cantidad

        detalle_venta = DetalleVenta(
            venta_id=new_venta.id,
            empresa_id=opp.empresa_id,
            producto_id=producto_id,
            cantidad=int(cantidad),
            precio_unitario=item.precio_unitario,
            subtotal=subtotal_item,
            es_servicio=False # Default, updated if we query product
        )
        db.add(detalle_venta)
        total_venta += subtotal_item

    new_venta_any = cast(Any, new_venta)
    new_venta_any.total = total_venta

    # Update Opportunity
    opp_any = cast(Any, opp)
    opp_any.estado = EstadoOportunidad.GANADA
    opp_any.fecha_cierre = datetime.now()
    opp_any.bodega_id = None # Release reservation link

    db.add(opp)
    
    # 4. Integración Contable
    folio_str = str(new_venta.folio)
    accounting_service.create_sale_entry(
        db=db,
        venta_id=new_venta.id,
        folio=folio_str,
        total=total_venta,
        sucursal_id=sucursal_id,
        empresa_id=opp.empresa_id,
        usuario_id=opp.usuario_id,
        metodo_pago="CREDITO", # Usually CRM sales are Credit/Invoice
    )

    # 5. Integración Facturación (DTE)
    facturacion_services.create_dte_from_sale(
        db=db,
        venta=new_venta,
        usuario_id=opp.usuario_id
    )

    db.commit()
    db.refresh(new_venta)
    return new_venta
