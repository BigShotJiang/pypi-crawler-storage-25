from typing import Any
from uuid import UUID
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.orm import joinedload

from app.api import deps
from app.core.auth.rbac import resolve_user_role_code
from app.core.database import get_db
from app.core_modules.crm import models, schemas, services
from app.core_modules.sistema.models import Empresa, Usuario
from app.core.security.security_audit import SecurityAudit

router = APIRouter()

ALLOWED_CRM_ROLES = {"ADMIN", "VENDEDOR", "SUPERADMIN", "DEVELOPER", "USER"}


def _ensure_crm_role(current_user: Usuario) -> None:
    if current_user.role not in ALLOWED_CRM_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Rol sin permisos para operar en CRM",
        )


def _ensure_vendor_response_company_role(
    db: Session, current_user: Usuario, current_company: Empresa
) -> None:
    codigo = resolve_user_role_code(db, current_user.id, current_company.id) or ""
    if codigo not in {"ADM", "SUP", "VEN"}:
        raise HTTPException(status_code=403, detail="No autorizado")


def _ensure_quote_items_from_opportunity(db: Session, quote: models.Cotizacion) -> None:
    if quote.items:
        return
    opp = (
        db.query(models.OportunidadVenta)
        .options(joinedload(models.OportunidadVenta.detalles))
        .filter(
            models.OportunidadVenta.id == quote.oportunidad_id,
            models.OportunidadVenta.empresa_id == quote.empresa_id,
        )
        .first()
    )
    if not opp or not opp.detalles:
        return
    for det in opp.detalles:
        quote.items.append(
            models.CotizacionItem(
                cotizacion_id=quote.id,
                empresa_id=quote.empresa_id,
                producto_id=det.producto_id,
                cantidad=det.cantidad,
                notas_tecnicas=None,
                estado_item=models.EstadoItemCotizacion.SOLICITADO,
            )
        )


def _compute_total_from_items(quote: models.Cotizacion) -> Decimal | None:
    if not quote.items:
        return None
    if not any(item.precio_neto_final is not None for item in quote.items):
        return None
    total = Decimal("0")
    for item in quote.items:
        if item.estado_item == models.EstadoItemCotizacion.RECHAZADO_CLIENTE:
            continue
        if item.precio_neto_final is None:
            continue
        total += Decimal(str(item.precio_neto_final)) * Decimal(item.cantidad or 0)
    return total


def _with_allow_no_tenant(db: Session) -> Any:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    return prev_allow_no_tenant


def _restore_allow_no_tenant(db: Session, prev_allow_no_tenant: Any) -> None:
    if prev_allow_no_tenant is None:
        db.info.pop("allow_no_tenant", None)
    else:
        db.info["allow_no_tenant"] = prev_allow_no_tenant


def _audit_cross_tenant_attempt(
    *,
    db: Session,
    current_user: Usuario,
    current_company: Empresa,
    action: str,
    oportunidad_id: UUID,
) -> None:
    prev_allow_no_tenant = _with_allow_no_tenant(db)
    try:
        opp_any_tenant = (
            db.query(models.OportunidadVenta)
            .filter(models.OportunidadVenta.id == oportunidad_id)
            .first()
        )
    finally:
        _restore_allow_no_tenant(db, prev_allow_no_tenant)

    if not opp_any_tenant:
        return

    if opp_any_tenant.empresa_id == current_company.id:
        return

    user_company_ids = [assoc.empresa_id for assoc in (current_user.empresas_asociadas or [])]
    SecurityAudit.log(
        db=db,
        actor_id=current_user.id,
        action=action,
        resource=f"OportunidadVenta:{oportunidad_id}",
        severity="WARNING",
        changes={
            "target_company": str(opp_any_tenant.empresa_id),
            "current_company": str(current_company.id),
            "user_companies": [str(x) for x in user_company_ids],
        },
    )


@router.get("/opportunities/{id}", response_model=schemas.OportunidadRead)
def get_opportunity_secure(
    id: UUID,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    opp = (
        db.query(models.OportunidadVenta)
        .filter(
            models.OportunidadVenta.id == id,
            models.OportunidadVenta.empresa_id == current_company.id,
        )
        .first()
    )
    if not opp:
        _audit_cross_tenant_attempt(
            db=db,
            current_user=current_user,
            current_company=current_company,
            action="UNAUTHORIZED_ACCESS_ATTEMPT",
            oportunidad_id=id,
        )
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")
    return opp


@router.post("/opportunities/{id}/prepare-signature")
def prepare_signature_secure(
    id: UUID,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    opp = (
        db.query(models.OportunidadVenta)
        .filter(
            models.OportunidadVenta.id == id,
            models.OportunidadVenta.empresa_id == current_company.id,
        )
        .first()
    )
    if not opp:
        _audit_cross_tenant_attempt(
            db=db,
            current_user=current_user,
            current_company=current_company,
            action="UNAUTHORIZED_SIGNATURE_ATTEMPT",
            oportunidad_id=id,
        )
        raise HTTPException(status_code=404, detail="Oportunidad no encontrada")
    return services.CRMService.prepare_signature(db=db, oportunidad_id=id)


@router.put("/quotes/{quote_id}/respuesta", response_model=schemas.QuoteDetailRead)
def responder_cotizacion(
    quote_id: UUID,
    payload: schemas.QuoteVendorResponseRequest,
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Any:
    _ensure_crm_role(current_user)
    _ensure_vendor_response_company_role(db, current_user, current_company)
    quote = (
        db.query(models.Cotizacion)
        .options(joinedload(models.Cotizacion.items))
        .filter(
            models.Cotizacion.id == quote_id,
            models.Cotizacion.empresa_id == current_company.id,
        )
        .first()
    )
    if not quote:
        raise HTTPException(status_code=404, detail="Cotización no encontrada")
    if quote.estado != models.EstadoCotizacion.PENDIENTE_VENDEDOR:
        raise HTTPException(status_code=400, detail="Cotización no está pendiente de vendedor")

    _ensure_quote_items_from_opportunity(db, quote)
    if not quote.items:
        raise HTTPException(status_code=400, detail="Cotización no tiene ítems para responder")

    delete_ids = set(payload.delete_item_ids or [])
    if delete_ids:
        items_by_id = {item.id: item for item in quote.items}
        for item_id in delete_ids:
            item = items_by_id.get(item_id)
            if not item:
                raise HTTPException(status_code=404, detail="Ítem no encontrado para eliminar")
            db.delete(item)
        quote.items = [item for item in quote.items if item.id not in delete_ids]

    if not quote.items:
        raise HTTPException(status_code=400, detail="Cotización no puede quedar sin ítems")

    items_by_id = {item.id: item for item in quote.items}
    for upd in payload.items:
        item = items_by_id.get(upd.item_id)
        if not item:
            raise HTTPException(status_code=404, detail="Ítem no encontrado")
        if upd.precio_neto_final <= 0:
            raise HTTPException(status_code=400, detail="Precio inválido")
        item.precio_neto_final = upd.precio_neto_final
        item.producto_sugerido_id = upd.producto_sugerido_id
        item.fecha_entrega_linea = upd.fecha_entrega_linea
        if upd.estado_item is not None:
            if upd.estado_item not in {"SOLICITADO", "SUGERIDO"}:
                raise HTTPException(status_code=400, detail="Estado de ítem inválido")
            item.estado_item = models.EstadoItemCotizacion(upd.estado_item)

    missing_fields = []
    for item in quote.items:
        if item.estado_item == models.EstadoItemCotizacion.RECHAZADO_CLIENTE:
            continue
        if item.precio_neto_final is None:
            missing_fields.append(str(item.id))
            continue
        if item.fecha_entrega_linea is None:
            missing_fields.append(str(item.id))
            continue
    if missing_fields:
        raise HTTPException(
            status_code=400,
            detail="No se puede enviar propuesta: existen ítems sin precio o fecha de entrega",
        )

    quote.vendedor_operador_id = current_user.id
    quote.estado = models.EstadoCotizacion.PROPUESTA_ENVIADA
    quote.version = (quote.version or 1) + 1

    new_total = _compute_total_from_items(quote)
    if new_total is not None:
        quote.total = new_total

    db.add(quote)
    db.commit()
    db.refresh(quote)
    return quote
