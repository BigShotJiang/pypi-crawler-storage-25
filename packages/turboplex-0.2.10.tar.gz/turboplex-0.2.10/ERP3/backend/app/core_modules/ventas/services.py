from typing import Optional, Dict, Any, cast
from datetime import datetime
from decimal import Decimal
import json
from uuid import UUID
from sqlalchemy import text
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.core_modules.ventas import schemas, models
from app.core_modules.inventario.stock.services import InventoryService
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts
from app.core_modules.finanzas import accounting_service
from app.core_modules.facturacion import services as facturacion_services
from app.core.infrastructure.serializer import safe_json_dumps
from app.core.exceptions import ResourceNotFoundError, BusinessRuleError
from app.core_modules.ventas.logic.tax_utils import build_line_tax_entries, apply_rounding_diff_to_highest


def create_stock_adjustment(
    db: Session,
    adjustment_in: schemas.StockAdjustmentCreate,
    usuario_id: UUID,
    empresa_id: UUID,
) -> int:
    """
    Crea un ajuste de stock (entrada o salida).
    Si es entrada (cantidad > 0), dispara el motor de re-asignación FIFO.
    """
    if adjustment_in.cantidad > 0:
        # Entrada: Trigger FIFO
        return InventoryService.add_stock(
            db,
            adjustment_in.producto_id,
            adjustment_in.bodega_id,
            adjustment_in.cantidad,
            adjustment_in.tipo_movimiento,
            empresa_id,
        )
    elif adjustment_in.cantidad < 0:
        # Salida: Consumo
        InventoryService.consume_stock(
            db,
            adjustment_in.producto_id,
            adjustment_in.bodega_id,
            abs(adjustment_in.cantidad),
            adjustment_in.tipo_movimiento,
            empresa_id,
        )
        db.commit()
        return 0
    return 0


def create_cliente(
    db: Session, cliente_in: schemas.ClienteCreate, empresa_id: UUID
) -> models.Cliente:
    # 1. Check Anti-Duplicados (RUT)
    if cliente_in.rut:
        existing = (
            db.query(models.Cliente)
            .filter(
                models.Cliente.rut == cliente_in.rut,
                models.Cliente.empresa_id == empresa_id
            )
            .first()
        )
        if existing:
            raise BusinessRuleError(f"El RUT ya pertenece al cliente: {existing.nombre}")

    cliente_data = cliente_in.model_dump(exclude={"empresa_id"})
    cliente = models.Cliente(**cliente_data, empresa_id=empresa_id)
    db.add(cliente)
    db.commit()
    db.refresh(cliente)
    return cliente


def update_cliente(
    db: Session,
    cliente_id: UUID,
    cliente_in: schemas.ClienteUpdate,
    empresa_id: UUID,
) -> models.Cliente:
    cliente = (
        db.query(models.Cliente)
        .filter(models.Cliente.id == cliente_id, models.Cliente.empresa_id == empresa_id)
        .first()
    )
    if not cliente:
        raise ResourceNotFoundError(resource="Cliente", resource_id=cliente_id)

    update_data = cliente_in.model_dump(exclude_unset=True)
    
    # Check RUT duplicate if changing
    if "rut" in update_data and update_data["rut"] != cliente.rut:
        new_rut = update_data["rut"]
        if new_rut:
            existing = (
                db.query(models.Cliente)
                .filter(
                    models.Cliente.rut == new_rut,
                    models.Cliente.empresa_id == empresa_id,
                    models.Cliente.id != cliente_id
                )
                .first()
            )
            if existing:
                raise BusinessRuleError(f"El RUT ya pertenece al cliente: {existing.nombre}")

    for field, value in update_data.items():
        setattr(cliente, field, value)

    db.add(cliente)
    db.commit()
    db.refresh(cliente)
    return cliente



def delete_cliente(
    db: Session, cliente_id: UUID, empresa_id: UUID, usuario_id: Optional[UUID] = None
) -> None:
    cliente = (
        db.query(models.Cliente)
        .filter(
            models.Cliente.id == cliente_id, models.Cliente.empresa_id == empresa_id
        )
        .first()
    )
    if not cliente:
        raise ResourceNotFoundError(resource="Cliente", resource_id=cliente_id)

    # Papelera Logic
    data = {c.name: getattr(cliente, c.name) for c in models.Cliente.__table__.columns}
    payload_json = json.loads(safe_json_dumps(data))

    sistema_portal_contracts.create_papelera_entry(
        db,
        tabla_origen="clientes",
        empresa_id=empresa_id,
        ejecutado_por_id=usuario_id,
        payload=payload_json,
    )

    cast(Any, cliente).soft_delete(db)
    db.commit()


def create_venta(
    db: Session, venta_in: schemas.VentaCreate, usuario_id: UUID, empresa_id: UUID
) -> models.Venta:
    current_tenant = db.info.get("empresa_id", None)
    if current_tenant is None:
        db.info["empresa_id"] = empresa_id
    elif current_tenant != empresa_id:
        raise RuntimeError("Tenant isolation violation: empresa_id mismatch")

    # Atomic Transaction Wrapper
    # Although standard practice is to rely on route transaction, we enforce atomicity here for critical logic.
    # Note: If the caller (route) has already started a transaction, nested commit might be tricky unless using savepoints.
    # However, SQLAlchemy Session is usually one-per-request. If we rollback, we rollback everything in the session.
    # We will assume we can manage the transaction flow here for this specific "Macro Service".

    try:
        # 0. Idempotencia (CRM request_id)
        if venta_in.request_id:
            req_marker = f"[REQ_ID:{venta_in.request_id}]"
            existing = (
                db.query(models.Venta)
                .filter(
                    models.Venta.empresa_id == empresa_id,
                    models.Venta.observaciones.contains(req_marker)
                )
                .first()
            )
            if existing:
                return existing
            
            # Append marker to observaciones
            current_obs = venta_in.observaciones or ""
            venta_in.observaciones = f"{req_marker} {current_obs}".strip()

        # 1. Validar Bodega Default (para stock)
        bodega_default = None
        try:
            bodega_default = InventoryService.get_bodega_default(
                db, venta_in.sucursal_id
            )
        except ResourceNotFoundError:
            # Si no se encuentra bodega, seguimos, pero fallaremos si intentamos descontar stock
            pass

        venta = models.Venta(
            fecha=datetime.now(),
            cliente_id=venta_in.cliente_id,
            sucursal_id=venta_in.sucursal_id,
            vendedor_id=usuario_id,
            empresa_id=empresa_id,
            folio=venta_in.folio,
            estado=models.EstadoVentaEnum.COMPLETADA,  # Asumimos completada por defecto
            observaciones=venta_in.observaciones,
        )

        total_venta = Decimal("0")

        detalles_input = []
        # 2. Procesar Detalles
        for detalle_in in venta_in.detalles:
            producto = (
                db.query(models.Producto)
                .filter(models.Producto.id == detalle_in.producto_id)
                .first()
            )
            if not producto:
                raise ResourceNotFoundError(
                    resource="Producto", resource_id=detalle_in.producto_id
                )

            # Usar precio override si existe, sino precio de lista
            precio_unitario = detalle_in.precio_unitario if detalle_in.precio_unitario is not None else producto.precio
            cantidad_dec = Decimal(str(detalle_in.cantidad))
            subtotal = precio_unitario * cantidad_dec
            total_venta = total_venta + subtotal

            detalle = models.DetalleVenta(
                empresa_id=empresa_id,
                producto_id=detalle_in.producto_id,
                cantidad=detalle_in.cantidad,
                precio_unitario=precio_unitario,
                subtotal=subtotal,
                es_servicio=detalle_in.es_servicio,
            )
            venta.detalles.append(detalle)
            impuestos_list = []
            if getattr(detalle_in, "impuestos", None):
                for imp in detalle_in.impuestos:
                    impuestos_list.append(
                        {
                            "codigo": imp.codigo,
                            "tasa": Decimal(str(imp.tasa)).quantize(Decimal("0.0001")),
                            "tipo": (imp.tipo or "CARGO").upper(),
                        }
                    )
            else:
                from app.core_modules.finanzas.services import get_impuesto_rate
                iva_rate = get_impuesto_rate(db, empresa_id, "IVA")
                impuestos_list.append(
                    {"codigo": "IVA", "tasa": Decimal(str(iva_rate)).quantize(Decimal("0.0001")), "tipo": "CARGO"}
                )
            detalles_input.append((detalle, impuestos_list, subtotal))

            # 3. Descontar Stock si aplica
            if producto.tipo_producto == "ALMACENABLE" and not detalle_in.es_servicio:
                if not bodega_default:
                    raise BusinessRuleError(
                        "No se encontró bodega por defecto para descontar stock en esta sucursal."
                    )

                # Usamos consume_stock directo (Select For Update Protected)
                InventoryService.consume_stock(
                    db=db,
                    producto_id=producto.id,
                    bodega_id=bodega_default.id,
                    cantidad=detalle_in.cantidad,
                    tipo_movimiento="VENTA",
                    empresa_id=empresa_id,
                )

        venta.total = total_venta
        # Snapshot de tasa aplicada (inmutable)
        from app.core_modules.finanzas.services import get_impuesto_rate
        tasa_iva = get_impuesto_rate(db, empresa_id, "IVA")
        venta.iva_tasa_aplicada = tasa_iva

        metodo_pago = getattr(venta_in, "metodo_pago", "CONTADO") or "CONTADO"
        if metodo_pago == "CREDITO":
            cliente = (
                db.query(models.Cliente)
                .filter(
                    models.Cliente.id == venta_in.cliente_id,
                    models.Cliente.empresa_id == empresa_id,
                )
                .first()
            )
            if not cliente:
                raise ResourceNotFoundError(
                    resource="Cliente", resource_id=venta_in.cliente_id
                )

            saldo_pendiente = accounting_service.get_cliente_credit_balance(
                db=db,
                empresa_id=empresa_id,
                cliente=cliente,
            )
            if saldo_pendiente + venta.total > cliente.limite_credito:
                raise BusinessRuleError("Límite de crédito excedido para el cliente.")
        db.add(venta)
        db.flush()

        for det, impuestos_list, subtotal in detalles_input:
            entries = build_line_tax_entries(empresa_id, det, impuestos_list, subtotal)
            for e in entries:
                db.add(e)

        apply_rounding_diff_to_highest(venta.detalles, total_venta)
        for det in venta.detalles:
            db.add(det)

        # 4. Crear Orden de Servicio si aplica
        if venta_in.orden_servicio:
            orden = models.OrdenServicio(
                venta_id=venta.id,
                fecha_entrega_prometida=venta_in.orden_servicio.fecha_entrega_prometida,
                observaciones_custodia=venta_in.orden_servicio.observaciones_custodia,
                estado=models.EstadoOrdenServicioEnum.RECEPCIONADO,
            )
            db.add(orden)

            # Historial inicial
            historial = models.HistorialOrdenServicio(
                orden_servicio=orden,
                estado_anterior=None,
                estado_nuevo=models.EstadoOrdenServicioEnum.RECEPCIONADO.value,
                usuario_id=usuario_id,
                observacion="Creación inicial",
            )
            db.add(historial)

        # 5. Integración Contable: Crear Asiento
        # Dispara evento automático al módulo de Finanzas
        folio_val = cast(Optional[str], venta.folio)
        folio_str: str = folio_val if folio_val is not None else str(venta.id)
        accounting_service.create_sale_entry(
            db=db,
            venta_id=venta.id,
            folio=folio_str,
            total=total_venta,
            sucursal_id=venta.sucursal_id,
            empresa_id=empresa_id,
            usuario_id=usuario_id,
            metodo_pago=metodo_pago,
        )

        # 5.1 Integración Facturación: Generar DTE
        # Se genera documento tributario automáticamente
        facturacion_services.create_dte_from_sale(
            db=db,
            venta=venta,
            usuario_id=usuario_id
        )

        # 6. Integración Sistema: Auditoría para DevDashboard (Ingresos Hoy)
        sistema_portal_contracts.create_audit_log(
            db,
            actor_id=usuario_id,
            action="VENTA_CONFIRMADA",
            resource=f"Venta:{venta.id}",
            severity="INFO",
            changes={"total": str(venta.total), "folio": venta.folio},
            ip_address=None,  # Could be passed if available
        )

        # Confirmar Transacción Atómica
        db.commit()
        db.refresh(venta)
        return venta

    except Exception as e:
        db.rollback()
        raise e


def _validate_venta_lock_status(
    db: Session, venta: models.Venta, empresa_id: UUID
) -> None:
    """
    Verifica si la venta está bloqueada por un cierre de caja.
    """
    locked_by_cierre = False

    # Si ya tiene un cierre asignado, está bloqueada
    if venta.cierre_caja_id:
        locked_by_cierre = True
    else:
        cierre_exists = (
            db.execute(
                text(
                    """
                    SELECT 1
                    FROM cierres_caja
                    WHERE empresa_id = :empresa_id
                      AND sucursal_id = :sucursal_id
                      AND usuario_id = :usuario_id
                      AND fecha_apertura <= :venta_fecha
                      AND fecha_cierre IS NOT NULL
                      AND fecha_cierre >= :venta_fecha
                    LIMIT 1
                    """
                ),
                {
                    "empresa_id": empresa_id,
                    "sucursal_id": venta.sucursal_id,
                    "usuario_id": venta.vendedor_id,
                    "venta_fecha": venta.fecha,
                },
            ).first()
            is not None
        )
        if cierre_exists:
            locked_by_cierre = True

    asiento_exists = accounting_service.has_asiento_for_origen(
        db,
        empresa_id=empresa_id,
        origen="VENTAS",
        origen_id=str(venta.id),
    )

    if locked_by_cierre or asiento_exists:
        raise HTTPException(
            status_code=403,
            detail="No se puede eliminar una venta bloqueada o contabilizada",
        )


def delete_venta(db: Session, venta_id: UUID, empresa_id: UUID) -> None:
    venta = (
        db.query(models.Venta)
        .filter(models.Venta.id == venta_id, models.Venta.empresa_id == empresa_id)
        .first()
    )
    if not venta:
        raise ResourceNotFoundError(resource="Venta", resource_id=venta_id)

    _validate_venta_lock_status(db, venta, empresa_id)

    # Restaurar stock (Reverso simplificado)
    try:
        bodega_default = InventoryService.get_bodega_default(db, venta.sucursal_id)
        for detalle in venta.detalles:
            if (
                detalle.producto.tipo_producto == "ALMACENABLE"
                and not detalle.es_servicio
            ):
                InventoryService.add_stock(
                    db=db,
                    producto_id=detalle.producto_id,
                    bodega_id=bodega_default.id,
                    cantidad=detalle.cantidad,
                    tipo_movimiento="ANULACION_VENTA",
                    empresa_id=empresa_id,
                )
    except Exception:
        # Si falla restauración de stock (ej. bodega borrada), loggeamos pero permitimos borrado venta?
        # Por ahora fallamos estricto.
        raise

    cast(Any, venta).soft_delete(db)
    db.commit()


def aumentar_cupo_temporal(
    db: Session,
    cliente_id: UUID,
    nuevo_monto: Decimal,
    motivo: str,
    usuario_id: UUID,
    empresa_id: UUID,
) -> Dict[str, Any]:
    if nuevo_monto is None or nuevo_monto <= Decimal("0"):
        raise BusinessRuleError("El monto de aumento debe ser mayor a cero.")

    motivo_limpio = (motivo or "").strip()
    if len(motivo_limpio) < 10:
        raise BusinessRuleError("El motivo proporcionado es demasiado corto.")

    # Validar que el usuario pertenece a la empresa y tiene rol autorizado (ADM o SUP)
    rol_codigo = sistema_portal_contracts.get_usuario_empresa_rol_codigo(
        db, usuario_id=usuario_id, empresa_id=empresa_id
    )
    if not rol_codigo:
        raise BusinessRuleError("El usuario no pertenece a la empresa del cliente.")

    if rol_codigo not in ("ADM", "SUP"):
        raise BusinessRuleError(
            "El usuario no tiene permisos para autorizar aumentos de cupo."
        )

    cliente = db.query(models.Cliente).filter(models.Cliente.id == cliente_id).first()
    if not cliente:
        raise ResourceNotFoundError(resource="Cliente", resource_id=cliente_id)

    if cliente.empresa_id != empresa_id:
        raise BusinessRuleError(
            "El cliente pertenece a otra empresa diferente a la del usuario."
        )

    limite_cupo_maximo = sistema_portal_contracts.get_empresa_limite_cupo_maximo(
        db, empresa_id=empresa_id
    )
    if limite_cupo_maximo is None:
        raise ResourceNotFoundError(resource="Empresa", resource_id=empresa_id)

    monto_anterior = cliente.limite_credito
    nuevo_total = monto_anterior + nuevo_monto

    if nuevo_total > limite_cupo_maximo:
        raise BusinessRuleError(
            "El nuevo límite excede el máximo permitido para la empresa."
        )

    cliente.limite_credito = nuevo_total
    db.add(cliente)

    changes = {
        "cliente_id": str(cliente_id),
        "monto_anterior": str(monto_anterior),
        "nuevo_monto": str(nuevo_total),
        "diferencia": str(nuevo_monto),
        "motivo": motivo_limpio,
    }

    audit_log_id = sistema_portal_contracts.create_audit_log(
        db,
        actor_id=usuario_id,
        action="AUMENTO_CUPO_CREDITO",
        resource=f"Cliente:{cliente_id}",
        severity="INFO",
        changes=changes,
        ip_address=None,
    )

    db.commit()
    db.refresh(cliente)

    return {
        "exito": True,
        "cliente": {
            "id": cliente.id,
            "limite_credito": int(round(cliente.limite_credito)),
        },
        "audit_log_id": audit_log_id,
    }


async def update_orden_servicio_state(
    db: Session,
    orden_id: UUID,
    nuevo_estado: str,
    usuario_id: UUID,
    observacion: Optional[str] = None,
) -> models.OrdenServicio:
    orden = (
        db.query(models.OrdenServicio)
        .filter(models.OrdenServicio.id == orden_id)
        .first()
    )
    if not orden:
        raise ResourceNotFoundError(resource="OrdenServicio", resource_id=orden_id)

    estado_anterior = orden.estado.value if orden.estado else None
    cast(Any, orden).estado = nuevo_estado

    if nuevo_estado == models.EstadoOrdenServicioEnum.ENTREGADO.value:
        cast(Any, orden).fecha_entrega_real = datetime.now()

    # Historial
    historial = models.HistorialOrdenServicio(
        orden_servicio_id=orden.id,
        estado_anterior=estado_anterior,
        estado_nuevo=nuevo_estado,
        usuario_id=usuario_id,
        observacion=observacion,
    )
    db.add(historial)
    db.commit()
    db.refresh(orden)
    return orden
