from app.core_modules.inventario.stock.services import InventoryService as NewInventoryService
import logging

logger = logging.getLogger(__name__)

logger.warning("DEPRECATED: app.core_modules.ventas.inventory_service is deprecated. Use app.core_modules.inventario.stock.services instead.")

InventoryService = NewInventoryService
