from typing import Optional, List, Any
from enum import Enum
from pydantic import BaseModel, ConfigDict, field_validator
from decimal import Decimal
from datetime import datetime
from uuid import UUID
from app.core.utils import validate_rut, clean_rut


# --- Cliente Schemas ---
class ClienteBase(BaseModel):
    nombre: Optional[str] = None
    email: Optional[str] = None
    telefono: Optional[str] = None
    direccion: Optional[str] = None
    rut: Optional[str] = None
    giro: Optional[str] = None
    ciudad: Optional[str] = None
    limite_credito: Optional[Decimal] = None
    condicion_pago: Optional[str] = "CONTADO"
    empresa_id: Optional[UUID] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class ClienteCreate(ClienteBase):
    nombre: str

    @field_validator("rut")
    @classmethod
    def validate_rut_chil(cls, v: Optional[str]) -> Optional[str]:
        if not v:
            return v
        raw = clean_rut(v)
        if len(raw) < 2:
            raise ValueError("RUT inválido")
        formatted = f"{raw[:-1]}-{raw[-1].upper()}"
        if not validate_rut(formatted):
            raise ValueError("RUT inválido")
        return formatted


class ClienteUpdate(ClienteBase):
    model_config = ConfigDict(from_attributes=True, extra="forbid")

    @field_validator("rut")
    @classmethod
    def validate_rut_chil(cls, v: Optional[str]) -> Optional[str]:
        if not v:
            return v
        raw = clean_rut(v)
        if len(raw) < 2:
            raise ValueError("RUT inválido")
        formatted = f"{raw[:-1]}-{raw[-1].upper()}"
        if not validate_rut(formatted):
            raise ValueError("RUT inválido")
        return formatted


class ClienteInDBBase(ClienteBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True, extra="forbid")


class Cliente(ClienteInDBBase):
    model_config = ConfigDict(from_attributes=True, extra="forbid")


# --- Producto Schemas ---
class ProductoBase(BaseModel):
    nombre: Optional[str] = None
    sku: Optional[str] = None
    descripcion: Optional[str] = None  # Agregado para soportar el campo en la BD
    precio: float = 0.0
    costo_promedio: float = 0.0
    tipo_producto: Optional[str] = "ALMACENABLE"  # Nuevo campo en API
    is_active: Optional[bool] = True
    es_trazable: Optional[bool] = False
    empresa_id: Optional[UUID] = None

    model_config = ConfigDict(from_attributes=True, extra="ignore")

    @field_validator("precio", "costo_promedio", mode="before")
    @classmethod
    def round_decimals(cls, v: Any) -> float:
        try:
            if v is None:
                return 0.0
            
            # Convertir a float si es string o decimal
            val = float(v)
            
            # Si el resultado es NaN o Infinito, limpiar a 0.0
            import math
            if math.isnan(val) or math.isinf(val):
                return 0.0
                
            return round(val, 2)
        except (ValueError, TypeError):
            return 0.0


class ProductoCreate(ProductoBase):
    nombre: str
    sku: str
    tipo_producto: str = "ALMACENABLE"

    model_config = ConfigDict(from_attributes=True, extra="ignore")


class ProductoUpdate(ProductoBase):
    model_config = ConfigDict(from_attributes=True, extra="ignore")


class ProductoInDBBase(ProductoBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True, extra="ignore")


class Producto(ProductoInDBBase):
    
    # Agregar Configuración de Schema para Swagger
    model_config = ConfigDict(
        from_attributes=True,
        extra="ignore",
        json_schema_extra={
            "example": {
                "nombre": "Producto Ejemplo",
                "sku": "SKU-123",
                "descripcion": "Descripción del producto",
                "precio": 19990.00,
                "costo_promedio": 12500.50,
                "tipo_producto": "ALMACENABLE",
                "is_active": True,
                "es_trazable": False,
                "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "empresa_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
            }
        }
    )


# --- Orden de Servicio Schemas ---
class EstadoOrdenServicioEnum(str, Enum):
    RECEPCIONADO = "RECEPCIONADO"
    EN_PROCESO = "EN_PROCESO"
    LISTO_RETIRO = "LISTO_RETIRO"
    ENTREGADO = "ENTREGADO"


class HistorialOrdenServicioBase(BaseModel):
    estado_anterior: Optional[str] = None
    estado_nuevo: str
    fecha_cambio: datetime
    usuario_id: UUID
    observacion: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class HistorialOrdenServicio(HistorialOrdenServicioBase):
    id: UUID
    orden_servicio_id: UUID
    model_config = ConfigDict(from_attributes=True, extra="forbid")


class OrdenServicioBase(BaseModel):
    fecha_entrega_prometida: Optional[datetime] = None
    observaciones_custodia: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class OrdenServicioCreate(OrdenServicioBase):
    model_config = ConfigDict(from_attributes=True, extra="forbid")


class OrdenServicioUpdate(BaseModel):
    estado: Optional[EstadoOrdenServicioEnum] = None
    observacion: Optional[str] = None  # Para el historial

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class OrdenServicio(OrdenServicioBase):
    id: UUID
    venta_id: UUID
    estado: EstadoOrdenServicioEnum
    fecha_recepcion: datetime
    fecha_entrega_real: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


# --- Venta Schemas ---
class DetalleVentaBase(BaseModel):
    producto_id: UUID
    cantidad: int
    es_servicio: bool = False  # Nuevo campo para input explicito (opcional)
    precio_unitario: Optional[Decimal] = None  # Override de precio (ej. descuentos o precisión)

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class ImpuestoDetalleIn(BaseModel):
    codigo: str
    tasa: Decimal
    tipo: Optional[str] = "CARGO"

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class DetalleVentaCreate(DetalleVentaBase):
    impuestos: Optional[List[ImpuestoDetalleIn]] = None
    model_config = ConfigDict(from_attributes=True, extra="forbid")


class DetalleVenta(DetalleVentaBase):
    id: UUID
    venta_id: UUID
    precio_unitario: Decimal
    subtotal: Decimal
    es_servicio: bool
    model_config = ConfigDict(from_attributes=True, extra="forbid")


class VentaBase(BaseModel):
    cliente_id: UUID
    sucursal_id: UUID
    folio: Optional[str] = None
    metodo_pago: Optional[str] = "CONTADO"
    metodo_pago_id: Optional[UUID] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class VentaCreate(VentaBase):
    detalles: List[DetalleVentaCreate]
    # Datos opcionales para crear Orden de Servicio al mismo tiempo
    orden_servicio: Optional[OrdenServicioCreate] = None
    observaciones: Optional[str] = None

    # Idempotencia
    request_id: Optional[UUID] = None  # UUIDv7 para evitar duplicados

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class Venta(VentaBase):
    id: UUID
    fecha: datetime
    total: Decimal
    vendedor_id: UUID
    empresa_id: UUID
    cierre_caja_id: Optional[UUID] = None
    detalles: List[DetalleVenta] = []
    orden_servicio: Optional[OrdenServicio] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class VentaOut(Venta):
    monto_neto: int
    monto_iva: int
    model_config = ConfigDict(from_attributes=True, extra="forbid")


# --- Inventario Global Schemas ---
class InventarioGlobalItem(BaseModel):
    producto_id: UUID
    sku: str
    producto_nombre: str
    tipo_producto: str  # Added field
    bodega_nombre: str
    sucursal_nombre: str
    fisica_disponible: int
    fisica_reservada: int

    model_config = ConfigDict(from_attributes=True, extra="forbid")


# --- Stock Adjustment Schema ---
class StockAdjustmentCreate(BaseModel):
    producto_id: UUID
    bodega_id: UUID
    cantidad: int  # Puede ser positivo o negativo, pero add_stock maneja positivo.
    # Para negativo (disminución), add_stock no sirve si solo suma.
    # InventoryService.add_stock llama a release_stock que SUMA.
    # Si es ajuste negativo, deberíamos llamar a consume_stock.
    # El usuario dijo "Trigger de Entrada ... vía Orden de Compra o Ajuste".
    # Asumiremos Ajuste POSITIVO (entrada) dispara el trigger.
    # Ajuste NEGATIVO (salida) no libera backorders.
    tipo_movimiento: str = "AJUSTE"
    observacion: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")
