from decimal import Decimal
from typing import Any, Dict, List, Sequence, Tuple
from uuid import UUID

from app.core_modules.ventas.models import DetalleVenta, DetalleVentaImpuesto


def compute_base_and_taxes(subtotal: Decimal, impuestos: List[Dict[str, Any]]) -> Tuple[Decimal, List[Dict[str, Any]]]:
    cargos = [i for i in impuestos if (i.get("tipo") or "").upper() == "CARGO"]
    factor = Decimal("1.0")
    for i in cargos:
        factor *= Decimal("1") + Decimal(str(i["tasa"]))
    if factor == Decimal("0"):
        factor = Decimal("1.0")
    base_monto = (Decimal(str(subtotal)) / factor).quantize(Decimal("0.0001"))
    out: List[Dict[str, Any]] = []
    for imp in impuestos:
        tasa = Decimal(str(imp["tasa"])).quantize(Decimal("0.0001"))
        monto_impuesto = (base_monto * tasa).quantize(Decimal("0.0001"))
        out.append(
            {
                "codigo": imp["codigo"],
                "tasa": tasa,
                "tipo": (imp.get("tipo") or "CARGO").upper(),
                "monto_impuesto": monto_impuesto,
            }
        )
    return base_monto, out


def build_line_tax_entries(
    empresa_id: UUID, det: DetalleVenta, impuestos: List[Dict[str, Any]], subtotal: Decimal
) -> List[DetalleVentaImpuesto]:
    base_monto, items = compute_base_and_taxes(subtotal, impuestos)
    entries: List[DetalleVentaImpuesto] = []
    for imp in items:
        entries.append(
            DetalleVentaImpuesto(
                empresa_id=empresa_id,
                detalle_venta_id=det.id,
                impuesto_config_id=None,
                codigo_impuesto=imp["codigo"],
                tasa_aplicada=imp["tasa"],
                base_monto=base_monto,
                monto_impuesto=imp["monto_impuesto"],
            )
        )
    return entries


def apply_rounding_diff_to_highest(detalles: Sequence[DetalleVenta], total: Decimal) -> None:
    total_clp = Decimal(str(total)).quantize(Decimal("1"))
    sum_clp = Decimal("0")
    for d in detalles:
        sum_clp += Decimal(str(d.subtotal)).quantize(Decimal("1"))
    diff = total_clp - sum_clp
    if diff in (Decimal("1"), Decimal("-1")) and detalles:
        highest = max(detalles, key=lambda d: Decimal(str(d.subtotal)))
        highest.subtotal = Decimal(str(highest.subtotal)) + diff
