from typing import Any
from decimal import Decimal
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api import deps
from app.core.exceptions import ResourceNotFoundError
from app.core.infrastructure.api_schemas import BaseResponse, MetaPayload
from app.core_modules.ventas import schemas, services
from app.core_modules.ventas.models import Venta, OrdenServicio, Producto, Cliente
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts
from app.core.utils import clean_rut

router = APIRouter()


def get_current_role(db: Session, user_id: UUID, company_id: UUID) -> str:
    return (
        sistema_portal_contracts.get_usuario_empresa_rol_codigo(
            db, usuario_id=user_id, empresa_id=company_id
        )
        or ""
    )


@router.post("/", response_model=BaseResponse[schemas.VentaOut], tags=["Ventas"])
def create_venta(
    venta_in: schemas.VentaCreate,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    venta = services.create_venta(
        db=db,
        venta_in=venta_in,
        usuario_id=current_user.id,
        empresa_id=current_company.id,
    )
    meta = MetaPayload(
        empresa_id=str(current_company.id), module="VENTAS", rls_scope="empresa"
    )
    return BaseResponse[schemas.VentaOut](
        success=True, data=venta, error=None, meta=meta
    )


@router.delete("/{id}", tags=["Ventas"])
def delete_venta(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Eliminar una venta (Solo si no está bloqueada por cierre de caja).
    """
    services.delete_venta(db=db, venta_id=id, empresa_id=current_company.id)
    return {"message": "Venta eliminada"}


@router.put(
    "/ordenes-servicio/{id}/estado",
    response_model=schemas.OrdenServicio,
    tags=["Operaciones"],
)
async def update_orden_servicio_state(
    id: UUID,
    status_update: schemas.OrdenServicioUpdate,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Actualiza el estado de una Orden de Servicio (Recepcionado -> En Proceso -> Listo -> Entregado).
    Registra trazabilidad del usuario que realiza la acción.
    """
    # Verificar que la OS pertenezca a la empresa (via Venta)
    orden = (
        db.query(OrdenServicio)
        .join(Venta)
        .filter(OrdenServicio.id == id, Venta.empresa_id == current_company.id)
        .first()
    )

    if not orden:
        raise ResourceNotFoundError(resource="OrdenServicio", resource_id=id)

    if status_update.estado is None:
        raise HTTPException(status_code=400, detail="Estado requerido")

    return await services.update_orden_servicio_state(
        db=db,
        orden_id=id,
        nuevo_estado=status_update.estado.value,
        usuario_id=current_user.id,
        observacion=status_update.observacion,
    )


@router.get("/clientes/by-rut", response_model=schemas.Cliente, tags=["Clientes"])
def get_cliente_by_rut(
    rut: str,
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Buscar cliente por RUT en la empresa actual.
    Retorna 404 si no existe.
    """
    # Normalizar RUT (opcional, si el frontend envía sucio)
    # Asumimos que la búsqueda debe ser exacta o normalizada
    # Si el frontend envía '12.345.678-k', y en DB está '12345678-K'
    # Usaremos clean_rut si es necesario, pero mejor buscar directo si ya viene limpio
    # O mejor, usar clean_rut aquí para asegurar
    try:
        raw = clean_rut(rut)
        if len(raw) < 2:
            raise ValueError()
        normalized_rut = f"{raw[:-1]}-{raw[-1].upper()}"
    except Exception:
        normalized_rut = rut

    cliente = (
        db.query(Cliente)
        .filter(Cliente.rut == normalized_rut, Cliente.empresa_id == current_company.id)
        .first()
    )
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    return cliente


@router.post("/clientes/", response_model=schemas.Cliente, tags=["Clientes"])
def create_cliente(
    cliente_in: schemas.ClienteCreate,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Crear un nuevo cliente.
    Reglas:
    - CRM: Puede crear, pero limite_credito se fuerza a 0 y condicion_pago a CONTADO.
    - ADM: Puede crear con todos los campos.
    """
    rol = get_current_role(db, current_user.id, current_company.id)
    
    if rol == "CRM":
        # Forzar valores seguros para CRM
        cliente_in.limite_credito = Decimal("0.00")
        cliente_in.condicion_pago = "CONTADO"
        # No bloqueamos direccion ni otros campos informativos

    return services.create_cliente(
        db=db, cliente_in=cliente_in, empresa_id=current_company.id
    )


@router.patch("/clientes/{id}", response_model=schemas.Cliente, tags=["Clientes"])
def update_cliente(
    id: UUID,
    cliente_in: schemas.ClienteUpdate,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Actualizar un cliente.
    Reglas:
    - CRM: No puede editar RUT, Límite Crédito, Condiciones Pago.
    - ADM: Puede editar todo.
    """
    rol = get_current_role(db, current_user.id, current_company.id)
    
    # Campos críticos que CRM no puede tocar
    if rol == "CRM":
        update_data = cliente_in.model_dump(exclude_unset=True)
        forbidden_updates = []
        if "rut" in update_data:
            forbidden_updates.append("rut")
        if "limite_credito" in update_data:
            forbidden_updates.append("limite_credito")
        if "condicion_pago" in update_data:
            forbidden_updates.append("condicion_pago")
        
        if forbidden_updates:
            raise HTTPException(
                status_code=403,
                detail=f"El rol CRM no puede editar campos críticos: {', '.join(forbidden_updates)}"
            )

    return services.update_cliente(
        db=db, cliente_id=id, cliente_in=cliente_in, empresa_id=current_company.id
    )



@router.get("/clientes/", response_model=list[schemas.Cliente], tags=["Clientes"])
def list_clientes(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Listar clientes de la empresa actual.
    """
    return (
        db.query(Cliente)
        .filter(Cliente.empresa_id == current_company.id)
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.get("/productos/", response_model=list[schemas.Producto], tags=["Productos"])
def list_productos(
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Listar productos de la empresa actual.
    """
    productos = (
        db.query(Producto)
        .filter(Producto.empresa_id == current_company.id)
        .all()
    )
    return productos


@router.get(
    "/productos/cementation",
    response_model=list[schemas.Producto],
    tags=["Productos"],
)
def list_productos_cementation(db: Session = Depends(deps.get_tenant_db)) -> Any:
    return db.query(Producto).all()


@router.get("/clientes/{id}", response_model=schemas.Cliente, tags=["Clientes"])
def get_cliente(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtener detalle de un cliente.
    """
    cliente = (
        db.query(Cliente)
        .filter(Cliente.id == id, Cliente.empresa_id == current_company.id)
        .first()
    )
    if not cliente:
        raise ResourceNotFoundError(resource="Cliente", resource_id=id)
    return cliente


@router.delete("/clientes/{id}", tags=["Clientes"])
def delete_cliente(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Eliminar un cliente.
    """
    services.delete_cliente(
        db=db, cliente_id=id, empresa_id=current_company.id, usuario_id=current_user.id
    )
    return {"message": "Cliente eliminado"}


@router.post("/ajuste-stock", response_model=int, tags=["Inventario"])
def create_stock_adjustment(
    adjustment_in: schemas.StockAdjustmentCreate,
    db: Session = Depends(deps.get_db),
    current_user: Any = Depends(deps.get_current_user),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Any:
    """
    Crear un ajuste de stock (entrada o salida).
    Si es entrada, dispara el motor de re-asignación FIFO para órdenes pendientes (PENDIENTE_SIN_STOCK).
    Retorna la cantidad de órdenes reactivadas.
    """
    return services.create_stock_adjustment(
        db=db,
        adjustment_in=adjustment_in,
        usuario_id=current_user.id,
        empresa_id=current_company.id,
    )
