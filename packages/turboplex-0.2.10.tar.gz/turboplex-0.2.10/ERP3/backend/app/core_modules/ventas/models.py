from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Date,
    ForeignKey,
    Numeric,
    Text,
    Enum as SAEnum,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from datetime import datetime
from decimal import Decimal
from app.core.database import Base, GUID
from app.core.utils.mixins import SoftDeleteMixin, TimestampMixin
from uuid import UUID
from typing import Optional
import uuid6
import enum


# -----------------------------------------------------------------------------
# ENUMS
# -----------------------------------------------------------------------------
class EstadoOrdenServicioEnum(str, enum.Enum):
    RECEPCIONADO = "RECEPCIONADO"
    EN_PROCESO = "EN_PROCESO"
    LISTO_RETIRO = "LISTO_RETIRO"
    ENTREGADO = "ENTREGADO"
    CANCELADO = "CANCELADO"
    EN_ESPERA_STOCK = "EN_ESPERA_STOCK"
    RESERVADO = "RESERVADO"


class EstadoVentaEnum(str, enum.Enum):
    COMPLETADA = "COMPLETADA"
    PENDIENTE = "PENDIENTE"
    ANULADA = "ANULADA"
    PENDIENTE_SIN_STOCK = "PENDIENTE_SIN_STOCK"


# -----------------------------------------------------------------------------
# CLIENTE
# -----------------------------------------------------------------------------
class Cliente(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "clientes"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, index=True, nullable=False)
    email = Column(String, index=True, nullable=True)
    telefono = Column(String, nullable=True)
    direccion = Column(String, nullable=True)
    rut = Column(String, index=True, nullable=True)
    giro = Column(String, nullable=True)
    ciudad = Column(String, nullable=True)
    condicion_pago = Column(String, nullable=True, default="CONTADO")

    # Multi-tenancy
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Relations
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="clientes"
    )
    _limite_credito: Mapped[Optional[Decimal]] = Column(Numeric(14, 2), nullable=True)

    @property
    def limite_credito(self) -> Decimal:
        value = getattr(self, "_limite_credito", None)
        if value is None:
            return Decimal("1000000.00")
        return Decimal(str(value))

    @limite_credito.setter
    def limite_credito(self, value: Optional[Decimal | str | int | float]) -> None:
        if value is None:
            self._limite_credito = None
        else:
            self._limite_credito = Decimal(str(value))


# -----------------------------------------------------------------------------
# PRODUCTO
# -----------------------------------------------------------------------------
class Producto(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "productos"
    __table_args__ = (
        UniqueConstraint("sku", "empresa_id", name="uq_producto_sku_empresa"),
    )

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, index=True, nullable=False)
    sku = Column(String, index=True, nullable=False)
    descripcion = Column(Text, nullable=True)
    familia = Column(String, nullable=True)
    precio: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    costo_promedio = Column(Numeric(14, 4), default=0.0000, nullable=False)  # PMP Calculation
    tipo_producto = Column(String, default="ALMACENABLE", nullable=False)  # ALMACENABLE, SERVICIO, CONSUMIBLE
    is_active = Column(Boolean, default=True)
    es_trazable = Column(Boolean, default=False, nullable=False)  # FIFO / Lotes

    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Relations
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="productos"
    )
    receta = relationship("Receta", uselist=False, back_populates="producto_final")
    certificaciones = relationship(
        "ProductoCertificacion", back_populates="producto", cascade="all, delete-orphan"
    )


# -----------------------------------------------------------------------------
# CERTIFICACIONES (ESCUDO DE CALIDAD)
# -----------------------------------------------------------------------------
class ProductoCertificacion(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "producto_certificaciones"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id"), nullable=False, index=True)

    numero_resolucion = Column(String, nullable=False)
    fecha_emision = Column(Date, nullable=False)
    fecha_vencimiento = Column(Date, nullable=False, index=True)
    organismo_certificador = Column(String, nullable=False)
    documento_url = Column(String, nullable=True)  # Link al PDF

    # Link Health Check
    is_link_active = Column(Boolean, default=True)  # Assumed true until checked
    last_link_check = Column(DateTime, nullable=True)

    # Relations
    producto = relationship("Producto", back_populates="certificaciones")


# -----------------------------------------------------------------------------
# VENTA
# -----------------------------------------------------------------------------
class Venta(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "ventas"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    fecha = Column(DateTime, default=datetime.utcnow, nullable=False)
    folio = Column(String, index=True, nullable=True)  # Optional folio
    total: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"), nullable=False)
    observaciones = Column(Text, nullable=True)

    # Moneda
    moneda = Column(String, default="CLP", nullable=False)  # CLP, UF, USD
    tipo_cambio: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("1.00"), nullable=False)

    # Snapshot de la tasa de IVA aplicada en el momento de la transacción (inmutable)
    iva_tasa_aplicada: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 4), nullable=True)

    # Estado
    estado: Mapped[EstadoVentaEnum] = mapped_column(
        SAEnum(EstadoVentaEnum), default=EstadoVentaEnum.COMPLETADA, nullable=False
    )

    # Foreign Keys
    cliente_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("clientes.id"), nullable=False, index=True)
    sucursal_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)
    vendedor_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("usuarios.id"), nullable=False, index=True)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    cierre_caja_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("cierres_caja.id"), nullable=True, index=True
    )

    # Relationships
    cliente = relationship("Cliente", backref="ventas")
    sucursal = relationship(
        "app.core_modules.sistema.models.Sucursal", backref="ventas"
    )
    vendedor = relationship(
        "app.core_modules.sistema.models.Usuario", backref="ventas_realizadas"
    )
    empresa = relationship("app.core_modules.sistema.models.Empresa", backref="ventas")
    detalles = relationship(
        "DetalleVenta",
        back_populates="venta",
        cascade="all, delete-orphan",
        foreign_keys="[DetalleVenta.venta_id]",
    )
    orden_servicio = relationship(
        "OrdenServicio",
        uselist=False,
        back_populates="venta",
        cascade="all, delete-orphan",
    )

    @property
    def monto_neto(self) -> int:
        from app.core_modules.finanzas.services import calculate_taxes_from_total

        total = self.total or Decimal("0")
        tasa = self.iva_tasa_aplicada if self.iva_tasa_aplicada is not None else None
        desglose = calculate_taxes_from_total(Decimal(str(total)), tasa=tasa)
        return desglose["neto"]

    @property
    def monto_iva(self) -> int:
        from app.core_modules.finanzas.services import calculate_taxes_from_total

        total = self.total or Decimal("0")
        tasa = self.iva_tasa_aplicada if self.iva_tasa_aplicada is not None else None
        desglose = calculate_taxes_from_total(Decimal(str(total)), tasa=tasa)
        return desglose["iva"]


class DetalleVenta(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "detalles_venta"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    venta_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("ventas.id"), nullable=False, index=True)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id"), nullable=False, index=True)
    cantidad = Column(Integer, nullable=False)
    precio_unitario: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    subtotal: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)

    # Flag para identificar items que requieren servicio/custodia
    es_servicio = Column(Boolean, default=False)

    # Campo para Cierre Administrativo (VIS)
    cantidad_cancelada = Column(Integer, default=0, nullable=False)

    # Sustitución Inteligente
    sustituye_a_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("detalles_venta.id"), nullable=True
    )

    # Relationships
    venta = relationship("Venta", back_populates="detalles", foreign_keys=[venta_id])
    producto = relationship("Producto")
    sustituye_a = relationship(
        "DetalleVenta", remote_side=[id], backref="sustituciones"
    )


class DetalleVentaImpuesto(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "detalles_venta_impuestos"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    detalle_venta_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("detalles_venta.id"), nullable=False, index=True)
    impuesto_config_id: Mapped[Optional[UUID]] = mapped_column(GUID, ForeignKey("configuracion_impuestos.id"), nullable=True, index=True)
    codigo_impuesto = Column(String(30), nullable=False)
    tasa_aplicada: Mapped[Decimal] = mapped_column(Numeric(12, 4), nullable=False)
    base_monto: Mapped[Decimal] = mapped_column(Numeric(14, 4), nullable=False, default=0)
    monto_impuesto: Mapped[Decimal] = mapped_column(Numeric(14, 4), nullable=False, default=0)

    # Relationships
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    detalle = relationship("DetalleVenta")


# -----------------------------------------------------------------------------
# ORDEN DE SERVICIO (TALLER/CUSTODIA)
# -----------------------------------------------------------------------------
class OrdenServicio(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "ordenes_servicio"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    venta_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("ventas.id"), nullable=False, unique=True, index=True
    )

    fecha_recepcion = Column(DateTime, default=datetime.utcnow, nullable=False)
    fecha_entrega_prometida = Column(DateTime, nullable=True)
    fecha_entrega_real = Column(DateTime, nullable=True)

    estado: Mapped[EstadoOrdenServicioEnum] = mapped_column(
        SAEnum(EstadoOrdenServicioEnum),
        default=EstadoOrdenServicioEnum.RECEPCIONADO,
        nullable=False,
    )
    observaciones_custodia = Column(Text, nullable=True)

    # Relations
    venta = relationship("Venta", back_populates="orden_servicio")
    historial = relationship(
        "HistorialOrdenServicio",
        back_populates="orden_servicio",
        cascade="all, delete-orphan",
    )


class HistorialOrdenServicio(Base):
    __tablename__ = "historial_orden_servicio"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    orden_servicio_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("ordenes_servicio.id"), nullable=False, index=True
    )

    estado_anterior = Column(String, nullable=True)
    estado_nuevo = Column(String, nullable=False)
    fecha_cambio = Column(DateTime, default=datetime.utcnow, nullable=False)
    usuario_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("usuarios.id"), nullable=False)
    observacion = Column(String, nullable=True)

    # Relations
    orden_servicio = relationship("OrdenServicio", back_populates="historial")
    usuario = relationship("app.core_modules.sistema.models.Usuario")











# -----------------------------------------------------------------------------
# PRODUCCION / RECETAS
# -----------------------------------------------------------------------------
class Receta(Base):
    __tablename__ = "recetas"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    producto_final_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("productos.id"), nullable=False, unique=True
    )
    nombre = Column(String, nullable=True)

    producto_final = relationship("Producto", back_populates="receta")
    insumos = relationship(
        "InsumoReceta", back_populates="receta", cascade="all, delete-orphan"
    )


class InsumoReceta(Base):
    __tablename__ = "insumos_receta"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    receta_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("recetas.id"), nullable=False, index=True)
    producto_insumo_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("productos.id"), nullable=False, index=True
    )
    cantidad: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False)

    receta = relationship("Receta", back_populates="insumos")
    producto_insumo = relationship("Producto")
