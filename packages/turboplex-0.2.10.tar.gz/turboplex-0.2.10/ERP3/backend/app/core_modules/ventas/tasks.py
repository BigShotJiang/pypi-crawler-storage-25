from app.core.database import SessionLocal
from app.core_modules.ventas.models import ProductoCertificacion
from app.core_modules.crm import portal_contracts as crm_portal_contracts
from app.core_modules.sistema import portal_contracts as sistema_portal_contracts
from app.core.utils import validate_url_format
from datetime import date, timedelta, datetime
import logging
import requests

logger = logging.getLogger(__name__)


def check_certification_links_health():
    """
    Tarea programada (Daily/Weekly) para verificar que los links de certificaciones sigan activos.
    """
    db = SessionLocal()
    try:
        logger.info("Running check_certification_links_health...")

        # Get all certs with a URL
        certs = (
            db.query(ProductoCertificacion)
            .filter(
                ProductoCertificacion.documento_url is not None,
                ProductoCertificacion.documento_url != "",
                not ProductoCertificacion.is_deleted,
            )
            .all()
        )

        if not certs:
            logger.info("No certifications with URLs to check.")
            return

        for cert in certs:
            url = cert.documento_url
            if not validate_url_format(url):
                logger.warning(f"Invalid URL format for cert {cert.id}: {url}")
                cert.is_link_active = False
                cert.last_link_check = datetime.utcnow()
                continue

            try:
                # HEAD request is lighter, but some servers block it or return 405.
                # We try HEAD, if fails, try GET with stream=True to avoid downloading body.
                response = requests.head(url, timeout=10, allow_redirects=True)

                if response.status_code >= 400:
                    # Retry with GET stream
                    response = requests.get(url, timeout=10, stream=True)
                    response.close()  # Close connection immediately

                is_active = response.status_code < 400

            except requests.RequestException as e:
                logger.warning(f"Link check failed for cert {cert.id} ({url}): {e}")
                is_active = False

            # Update status
            if cert.is_link_active != is_active:
                logger.info(f"Cert {cert.id} link status changed to {is_active}")

            cert.is_link_active = is_active
            cert.last_link_check = datetime.utcnow()

        db.commit()
        logger.info(f"Checked {len(certs)} certification links.")

    except Exception as e:
        logger.error(f"Error checking certification links: {e}")
        db.rollback()
    finally:
        db.close()


def check_certifications_expiration():
    """
    Tarea programada (Daily) para verificar vencimientos de certificaciones.
    Genera alertas si quedan menos de 30 días.
    """
    db = SessionLocal()
    try:
        today = date.today()
        limit_date = today + timedelta(days=30)

        logger.info("Running check_certifications_expiration...")

        # Buscar certificaciones que vencen en los próximos 30 días
        # y que NO estén eliminadas
        certs = (
            db.query(ProductoCertificacion)
            .filter(
                ProductoCertificacion.fecha_vencimiento >= today,
                ProductoCertificacion.fecha_vencimiento <= limit_date,
                not ProductoCertificacion.is_deleted,
            )
            .all()
        )

        if not certs:
            logger.info("No certifications expiring soon.")
            return

        # Identificar destinatarios (Admins o encargados de Calidad)
        # Por defecto notificamos a todos los usuarios con rol ADMIN
        admin_ids = sistema_portal_contracts.list_platform_admin_user_ids(db)
        if not admin_ids:
            logger.warning("No admins found to notify about certifications.")
            # Fallback: log critical
            for cert in certs:
                logger.critical(
                    f"CERTIFICACION POR VENCER: {cert.numero_resolucion} - Prod ID {cert.producto_id} - Vence: {cert.fecha_vencimiento}"
                )
            return

        count = 0
        for cert in certs:
            days_left = (cert.fecha_vencimiento - today).days
            msg = (
                f"ALERTA CALIDAD: Certificación {cert.numero_resolucion} del producto #{cert.producto_id} "
                f"vence en {days_left} días ({cert.fecha_vencimiento}). Renovar urgente."
            )

            # Evitar spam: Verificar si ya existe notificación hoy para este certificado?
            # Por simplicidad, generamos la alerta. El worker corre una vez al día.

            for admin_id in admin_ids:
                crm_portal_contracts.create_notification(
                    db,
                    usuario_id=admin_id,
                    mensaje=msg,
                    link_documento=cert.documento_url or f"/productos/{cert.producto_id}",
                    leido=False,
                )
            count += 1

        db.commit()
        logger.info(
            f"Generated {count} certification alerts for {len(admin_ids)} admins."
        )

    except Exception as e:
        logger.error(f"Error checking certifications: {e}")
        db.rollback()
    finally:
        db.close()
