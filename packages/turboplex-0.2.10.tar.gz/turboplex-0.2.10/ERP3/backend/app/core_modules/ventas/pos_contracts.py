from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy import and_, func
from sqlalchemy.orm import Session

from app.core_modules.ventas.models import Venta


def sum_ventas_total_no_asignadas(
    db: Session,
    *,
    empresa_id: UUID,
    sucursal_id: UUID,
    vendedor_id: UUID,
    fecha_inicio: datetime,
    fecha_fin: datetime,
) -> Decimal:
    total = (
        db.query(func.sum(Venta.total))
        .filter(
            and_(
                Venta.empresa_id == empresa_id,
                Venta.sucursal_id == sucursal_id,
                Venta.vendedor_id == vendedor_id,
                Venta.fecha >= fecha_inicio,
                Venta.fecha <= fecha_fin,
                Venta.cierre_caja_id.is_(None),
            )
        )
        .scalar()
    )
    return total or Decimal("0.00")


def asignar_ventas_a_cierre(
    db: Session,
    *,
    empresa_id: UUID,
    sucursal_id: UUID,
    vendedor_id: UUID,
    fecha_inicio: datetime,
    fecha_fin: datetime,
    cierre_id: UUID,
) -> int:
    updated = (
        db.query(Venta)
        .filter(
            and_(
                Venta.empresa_id == empresa_id,
                Venta.sucursal_id == sucursal_id,
                Venta.vendedor_id == vendedor_id,
                Venta.fecha >= fecha_inicio,
                Venta.fecha <= fecha_fin,
                Venta.cierre_caja_id.is_(None),
            )
        )
        .update({Venta.cierre_caja_id: cierre_id}, synchronize_session=False)
    )
    return int(updated or 0)

