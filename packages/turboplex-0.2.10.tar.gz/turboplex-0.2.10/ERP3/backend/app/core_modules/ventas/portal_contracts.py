from __future__ import annotations

from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.ventas.models import Cliente


def get_cliente_rut(
    db: Session, *, empresa_id: UUID, cliente_id: UUID
) -> str:
    rut = (
        db.query(Cliente.rut)
        .filter(Cliente.id == cliente_id, Cliente.empresa_id == empresa_id)
        .scalar()
    )
    if not rut:
        raise ValueError("Cliente no encontrado")
    return str(rut)


def cliente_exists(db: Session, *, empresa_id: UUID, cliente_id: UUID) -> bool:
    return (
        db.query(Cliente.id)
        .filter(Cliente.id == cliente_id, Cliente.empresa_id == empresa_id)
        .first()
        is not None
    )

