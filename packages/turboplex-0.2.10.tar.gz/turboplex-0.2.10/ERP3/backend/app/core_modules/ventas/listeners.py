from app.core.infrastructure.events import event_dispatcher
import app.core.database as coredb
from app.core_modules.ventas import models
from sqlalchemy import text
from app.core_modules.inventario.stock import models as stock_models
from app.core_modules.inventario.stock.services import InventoryService
from app.core_modules.service_engine.models import ServiceOrder
from app.core.exceptions import wrap_background_task
from app.core.infrastructure.messenger.manager import messenger
from typing import Any
import logging
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)

SessionLocal = coredb.SessionLocal


def _service_update_inventory_worker(data: dict[str, Any]) -> None:
    if data.get("status") != "COMPLETED":
        return
    service_order_id = data.get("service_order_id")
    if not service_order_id:
        return
    db = coredb.SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        order = (
            db.query(ServiceOrder).filter(ServiceOrder.id == service_order_id).first()
        )
        if not order:
            logger.error(f"ServiceOrder {service_order_id} not found in listener")
            return
    
        logger.info(f"Processing ServiceOrder {service_order_id} for inventory. Sucursal: {order.sucursal_id}")

        bodega = InventoryService.get_bodega_default(db, order.sucursal_id)
        if not bodega:
            logger.error(f"No bodega found for sucursal {order.sucursal_id}")
            return
        bodega_id = bodega.id
        
        items_to_process = []
        if order.venta:
            logger.info("Order has Venta linked")
            for detalle in order.venta.detalles:
                items_to_process.append(
                    {"producto": detalle.producto, "qty": float(detalle.cantidad)}
                )
        elif order.producto:
            logger.info(f"Order has direct Product linked: {order.producto_id}")
            qty = 1.0
            if order.metadata_info and isinstance(order.metadata_info, dict):
                try:
                    qty = float(order.metadata_info.get("qty", 1.0))
                except (TypeError, ValueError):
                    qty = 1.0
            logger.info(f"Processing qty: {qty}")
            items_to_process.append({"producto": order.producto, "qty": qty})
        else:
            logger.warning("Order has no Venta and no Producto linked")

        for item in items_to_process:
            producto = item["producto"]
            qty_servicios = item["qty"]
            if producto and producto.receta:
                logger.info(f"Product {producto.id} has recipe {producto.receta.id}")
                for insumo in producto.receta.insumos:
                    qty_insumo = float(insumo.cantidad) * qty_servicios
                    qty_int = int(qty_insumo)
                    logger.info(f"Consuming insumo {insumo.producto_insumo_id}. Qty calculated: {qty_insumo} -> {qty_int}")
                    if qty_int == 0:
                        continue

                    InventoryService.consume_stock(
                        db=db,
                        producto_id=insumo.producto_insumo_id,
                        bodega_id=bodega_id,
                        cantidad=qty_int,
                        tipo_movimiento="CONSUMO_INTERNO",
                        empresa_id=order.empresa_id,
                        reference_id=str(service_order_id),
                    )
        db.commit()
        logger.info(f"Inventario descontado para ServiceOrder #{service_order_id}")
    except (SQLAlchemyError, TypeError, ValueError) as exc:
        logger.error(
            "Error descontando inventario para ServiceOrder #%s: %s",
            service_order_id,
            exc,
        )
        db.rollback()
    finally:
        db.close()


_service_update_inventory_task = wrap_background_task(
    _service_update_inventory_worker,
    task_name="service_engine.service_update_inventory",
)

def service_update_inventory_job(data: dict[str, Any]) -> None:
    _service_update_inventory_task(data)


async def handle_service_update_inventory(data: dict[str, Any]) -> None:
    if data.get("status") != "COMPLETED":
        return
    if not data.get("service_order_id"):
        return
    messenger.enqueue(service_update_inventory_job, data, lane="fast")


async def handle_orden_finalizada_inventory(data: dict[str, Any]) -> None:
    """
    Listener para descontar inventario (WMS) cuando una Orden de Servicio finaliza.
    """
    orden_id = data.get("orden_id")
    # usuario_id = data.get("usuario_id") # Not used directly in inventory logic currently, but good to have

    if not orden_id:
        logger.error("Event data missing orden_id")
        return

    db = coredb.SessionLocal()
    try:
        orden = (
            db.query(models.OrdenServicio)
            .filter(models.OrdenServicio.id == orden_id)
            .first()
        )
        if not orden or not orden.venta:
            return

        bodega = InventoryService.get_bodega_default(db, orden.venta.sucursal_id)
        bodega_id = bodega.id

        for detalle in orden.venta.detalles:
            producto = detalle.producto
            if producto and producto.receta:
                qty_servicios = float(detalle.cantidad)
                for insumo in producto.receta.insumos:
                    # Calculate quantity
                    qty_insumo = float(insumo.cantidad) * qty_servicios
                    qty_int = int(qty_insumo)  # Stock is Integer based

                    if qty_int == 0:
                        continue

                    InventoryService.consume_stock(
                        db=db,
                        producto_id=insumo.producto_insumo_id,
                        bodega_id=bodega_id,
                        cantidad=qty_int,
                        tipo_movimiento="CONSUMO_INTERNO",
                        empresa_id=orden.venta.empresa_id,
                        reference_id=str(orden_id),
                    )

                    # WMS-Lite Logic: Descuento inteligente por Ubicación (FIFO)
                    qty_remaining = qty_int

                    ubicaciones_stock = (
                        db.query(stock_models.InventarioUbicacion)
                        .filter(
                            stock_models.InventarioUbicacion.ubicacion_id.in_(
                                [
                                    row[0]
                                    for row in db.execute(
                                        text(
                                            "SELECT id FROM ubicaciones WHERE bodega_id = :bodega_id"
                                        ),
                                        {"bodega_id": bodega_id},
                                    ).all()
                                ]
                            ),
                            stock_models.InventarioUbicacion.producto_id
                            == insumo.producto_insumo_id,
                            stock_models.InventarioUbicacion.cantidad > 0,
                        )
                        .order_by(stock_models.InventarioUbicacion.updated_at.asc())
                        .all()
                    )

                    for loc_inv in ubicaciones_stock:
                        if qty_remaining <= 0:
                            break

                        if loc_inv.cantidad >= qty_remaining:
                            loc_inv.cantidad -= qty_remaining
                            qty_remaining = 0
                        else:
                            # Consumir todo lo de esta ubicación y seguir
                            qty_remaining -= loc_inv.cantidad
                            loc_inv.cantidad = 0

        db.commit()
        logger.info(f"Inventario descontado para Orden #{orden_id}")

    except (SQLAlchemyError, TypeError, ValueError) as exc:
        logger.error("Error descontando inventario para Orden #%s: %s", orden_id, exc)
        db.rollback()
    finally:
        db.close()


def register_listeners() -> None:
    event_dispatcher.subscribe(
        "EVENT_ORDEN_FINALIZADA", handle_orden_finalizada_inventory
    )
    event_dispatcher.subscribe(
        "service_engine.order.update", handle_service_update_inventory
    )
