from sqlalchemy import Column, String, DateTime, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import Mapped
from app.core.database import Base, GUID
from uuid import UUID
import uuid6


class AuditLog(Base):
    __tablename__ = "business_audit_logs"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    usuario_id = Column(
        GUID, index=True, nullable=True
    )  # Puede ser NULL si es una acción del sistema
    accion = Column(
        String, index=True, nullable=False
    )  # Ej: 'ORDEN_FINALIZADA', 'STOCK_UPDATE'
    modulo = Column(String, index=True, nullable=False)  # Ej: 'VENTAS', 'INVENTARIO'
    referencia_id = Column(
        String, index=True, nullable=True
    )  # ID del objeto afectado (ej. Orden ID)
    cambios = Column(JSON, nullable=True)  # Snapshot de los datos o diff
    created_at = Column(DateTime(timezone=True), server_default=func.now())
