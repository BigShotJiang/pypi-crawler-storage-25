from typing import Any
from app.core.infrastructure.events import event_dispatcher
from app.core.database import SessionLocal
from app.core_modules.auditoria.models import AuditLog
from app.core.exceptions import wrap_background_task
import logging
import asyncio
import json
from uuid import UUID
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)


def safe_json_encoder(obj: Any) -> str:
    if isinstance(obj, UUID):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _service_update_audit_worker(data: dict[str, Any]) -> None:
    service_order_id = data.get("service_order_id")
    usuario_id = data.get("usuario_id")
    if not service_order_id:
        return
    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        log_entry = AuditLog(
            usuario_id=usuario_id,
            accion=f"SERVICE_ORDER_UPDATE_{data.get('status')}",
            modulo="SERVICE_ENGINE",
            referencia_id=str(service_order_id),
            cambios=json.loads(json.dumps(data, default=safe_json_encoder)),
        )
        db.add(log_entry)
        db.commit()
        logger.info(
            f"[AUDITORIA] Evento registrado: SERVICE_ORDER_UPDATE (Order #{service_order_id})"
        )
    except (SQLAlchemyError, TypeError, ValueError) as exc:
        logger.error(
            "Error registrando auditoría para ServiceOrder #%s: %s",
            service_order_id,
            exc,
        )
        db.rollback()
    finally:
        db.close()


_service_update_audit_task = wrap_background_task(
    _service_update_audit_worker,
    task_name="service_engine.service_update_audit",
)


async def handle_service_update_audit(data: dict[str, Any]) -> None:
    if not data.get("service_order_id"):
        return
    asyncio.create_task(asyncio.to_thread(_service_update_audit_task, data))


async def handle_audit_orden_finalizada(data: dict[str, Any]) -> None:
    """
    Listener de Auditoría: Registra cuando una Orden finaliza.
    """
    orden_id = data.get("orden_id")
    usuario_id = data.get("usuario_id")

    if not orden_id:
        return

    db = SessionLocal()
    try:
        log_entry = AuditLog(
            usuario_id=usuario_id,
            accion="ORDEN_FINALIZADA",
            modulo="VENTAS",
            referencia_id=str(orden_id),
            cambios=json.loads(json.dumps(data, default=safe_json_encoder)),  # Guardamos todo el payload del evento
        )
        db.add(log_entry)
        db.commit()
        logger.info(
            f"[AUDITORIA] Evento registrado: ORDEN_FINALIZADA (Orden #{orden_id})"
        )
    except (SQLAlchemyError, TypeError, ValueError) as exc:
        logger.error("Error registrando auditoría para Orden #%s: %s", orden_id, exc)
        db.rollback()
    finally:
        db.close()


def register_listeners() -> None:
    event_dispatcher.subscribe("EVENT_ORDEN_FINALIZADA", handle_audit_orden_finalizada)
    event_dispatcher.subscribe(
        "service_engine.order.update", handle_service_update_audit
    )
