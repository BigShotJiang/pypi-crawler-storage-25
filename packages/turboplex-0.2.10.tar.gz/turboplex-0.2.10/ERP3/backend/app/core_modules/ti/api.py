from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException, Body, BackgroundTasks
from sqlalchemy.orm import Session
from app.api import deps
from app.core.services import auditoria_service
from . import models, schemas

# Cross-module imports
from app.core_modules.rrhh import models as rrhh_models, schemas as rrhh_schemas
from app.core_modules.sistema.models import Usuario, Empresa, Rol, UsuarioEmpresa
from app.core import security
from uuid import UUID

router = APIRouter(dependencies=[Depends(deps.check_module_access("TI"))])

# TI module exclusive to TI_ADMIN, SUPERADMIN and ADMIN_SAAS
ALLOWED_ROLES = [
    deps.UserRole.TI_ADMIN,
    deps.UserRole.SUPERADMIN,
    deps.UserRole.ADMIN_SAAS,
    deps.UserRole.ADMIN,
    deps.UserRole.DEVELOPER,
]


def resolve_role_code_from_cargo(cargo: str) -> str:
    value = (cargo or "").strip().lower()
    if any(key in value for key in ["admin", "administrador", "gerent"]):
        return "ADM"
    if any(key in value for key in ["supervisor", "jefe", "coordinador"]):
        return "SUP"
    if any(key in value for key in ["bodega", "almacen", "warehouse", "logistica"]):
        return "BOD"
    if any(key in value for key in ["contab", "contador", "finanzas"]):
        return "CON"
    if "crm" in value:
        return "CRM"
    if any(key in value for key in ["auditor", "auditoria"]):
        return "AUD"
    if any(key in value for key in ["backoffice", "back office", "ti", "sistemas"]):
        return "BACKOFFICE"
    return "VEN"


def resolve_or_create_role(db: Session, empresa_id: UUID, codigo: str) -> Rol:
    rol = (
        db.query(Rol)
        .filter(Rol.empresa_id == empresa_id, Rol.codigo == codigo)
        .first()
    )
    if rol:
        return rol
    nombres = {
        "ADM": "Administrador Único de Empresa",
        "SUP": "Supervisor",
        "VEN": "Vendedor",
        "BOD": "Bodeguero",
        "CON": "Contador",
        "CRM": "CRM",
        "BACKOFFICE": "Backoffice",
        "AUD": "Auditor",
    }
    rol = Rol(
        empresa_id=empresa_id,
        codigo=codigo,
        nombre=nombres.get(codigo, codigo),
        is_active=True,
    )
    db.add(rol)
    db.flush()
    return rol

# --- Activos TI Management ---


@router.get("/activos-ti", response_model=List[schemas.ActivoTI])
def read_activos_ti(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Retrieve activos TI.
    """
    activos = (
        db.query(models.ActivoTI)
        .filter(models.ActivoTI.empresa_id == current_company.id)
        .offset(skip)
        .limit(limit)
        .all()
    )
    return activos


@router.post("/activos-ti", response_model=schemas.ActivoTI)
def create_activo_ti(
    *,
    db: Session = Depends(deps.get_db),
    activo_in: schemas.ActivoTICreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Create new activo TI.
    """
    activo = models.ActivoTI(**activo_in.model_dump(), empresa_id=current_company.id)
    db.add(activo)
    db.commit()
    db.refresh(activo)
    return activo


@router.put("/activos-ti/{activo_id}", response_model=schemas.ActivoTI)
def update_activo_ti(
    *,
    db: Session = Depends(deps.get_db),
    activo_id: UUID,
    activo_in: schemas.ActivoTIUpdate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Update an activo TI.
    """
    activo = (
        db.query(models.ActivoTI)
        .filter(
            models.ActivoTI.id == activo_id,
            models.ActivoTI.empresa_id == current_company.id,
        )
        .first()
    )
    if not activo:
        raise HTTPException(status_code=404, detail="ActivoTI not found")

    update_data = activo_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(activo, field, value)

    db.add(activo)
    db.commit()
    db.refresh(activo)
    return activo


@router.delete("/activos-ti/{activo_id}", response_model=schemas.ActivoTI)
def delete_activo_ti(
    *,
    db: Session = Depends(deps.get_db),
    activo_id: UUID,
    background_tasks: BackgroundTasks,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Delete an activo TI.
    """
    activo = (
        db.query(models.ActivoTI)
        .filter(
            models.ActivoTI.id == activo_id,
            models.ActivoTI.empresa_id == current_company.id,
        )
        .first()
    )
    if not activo:
        raise HTTPException(status_code=404, detail="ActivoTI not found")

    auditoria_service.archivar_y_borrar(
        db=db,
        objeto=activo,
        background_tasks=background_tasks,
        ejecutado_por_id=current_user.id,
        empresa_id=current_company.id,
        company_code=getattr(current_company, "codigo", None),
    )
    return activo


# --- User Linking Management ---


@router.put("/empleados/{empleado_id}/link-user", response_model=rrhh_schemas.Empleado)
def link_empleado_usuario(
    *,
    db: Session = Depends(deps.get_db),
    empleado_id: UUID,
    payload: schemas.EmpleadoUsuarioLinkRequest = Body(...),
    current_user: Usuario = Depends(deps.RoleChecker(ALLOWED_ROLES)),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Vincula un Empleado existente con un Usuario del sistema.
    Esta operación es exclusiva de TI para completar el alta técnica.
    """
    # 1. Verificar Empleado
    empleado = (
        db.query(rrhh_models.Empleado)
        .filter(
            rrhh_models.Empleado.id == empleado_id,
            rrhh_models.Empleado.empresa_id == current_company.id,
        )
        .first()
    )

    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado not found")

    if empleado.usuario_id:
        return empleado

    usuario = None
    if payload.usuario_id:
        usuario = db.query(Usuario).filter(Usuario.id == payload.usuario_id).first()
        if not usuario:
            raise HTTPException(status_code=404, detail="Usuario not found")
    else:
        if not payload.email or not payload.password:
            raise HTTPException(status_code=400, detail="Email y password son obligatorios")
        existing = db.query(Usuario).filter(Usuario.email == payload.email).first()
        if existing and not existing.is_active:
            raise HTTPException(status_code=400, detail="Usuario inactivo")
        if existing:
            usuario = existing
        else:
            usuario = Usuario(
                email=payload.email,
                hashed_password=security.get_password_hash(payload.password),
                role="USER",
                is_active=True,
            )
            db.add(usuario)
            db.flush()

    role_code = resolve_role_code_from_cargo(empleado.cargo)
    if payload.rol_codigo:
        role_code = payload.rol_codigo.strip().upper()
        allowed = {"ADM", "SUP", "VEN", "BOD", "CON", "BACKOFFICE", "AUD", "CRM"}
        if role_code not in allowed:
            raise HTTPException(status_code=400, detail="Rol no permitido")
    rol = resolve_or_create_role(db, current_company.id, role_code)
    link = (
        db.query(UsuarioEmpresa)
        .filter(
            UsuarioEmpresa.usuario_id == usuario.id,
            UsuarioEmpresa.empresa_id == current_company.id,
        )
        .first()
    )
    if not link:
        link = UsuarioEmpresa(
            usuario_id=usuario.id,
            empresa_id=current_company.id,
            rol_id=rol.id,
            is_default=True,
        )
        db.add(link)
    elif link.rol_id != rol.id:
        link.rol_id = rol.id

    empleado.usuario_id = usuario.id
    db.add(empleado)
    db.commit()
    db.refresh(empleado)

    return empleado
