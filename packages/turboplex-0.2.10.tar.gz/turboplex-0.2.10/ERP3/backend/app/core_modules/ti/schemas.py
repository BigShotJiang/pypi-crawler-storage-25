from typing import Optional
from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, ConfigDict, EmailStr


class ActivoTIBase(BaseModel):
    marca: Optional[str] = None
    modelo: Optional[str] = None
    numero_serie: Optional[str] = None
    sucursal_id: Optional[UUID] = None


class ActivoTICreate(ActivoTIBase):
    marca: str
    modelo: str
    numero_serie: str
    sucursal_id: UUID


class ActivoTIUpdate(ActivoTIBase):
    pass


class ActivoTI(ActivoTIBase):
    id: UUID
    empresa_id: UUID
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class EmpleadoUsuarioLinkRequest(BaseModel):
    usuario_id: Optional[UUID] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    rol_codigo: Optional[str] = None

    model_config = ConfigDict(extra="forbid")
