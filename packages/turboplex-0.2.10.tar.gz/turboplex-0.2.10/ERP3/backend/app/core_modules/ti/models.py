from sqlalchemy import Column, String, ForeignKey, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship, Mapped
from app.core.database import Base, GUID
from uuid import UUID
import uuid6


class ActivoTI(Base):
    __tablename__ = "activos_ti"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    marca = Column(String, nullable=False)
    modelo = Column(String, nullable=False)
    numero_serie = Column(String, unique=True, index=True, nullable=False)

    sucursal_id = Column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Updated paths to core_modules.sistema
    sucursal = relationship(
        "app.core_modules.sistema.models.Sucursal", backref="activos_ti"
    )
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="activos_ti"
    )
