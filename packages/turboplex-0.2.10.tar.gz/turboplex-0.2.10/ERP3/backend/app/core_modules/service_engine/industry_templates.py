"""
Industry Templates Configuration
Defines default Workflows and Metadata Schemas for supported industries.
"""

TRANSPORTE_TEMPLATE = {
    "name": "Transporte Standard",
    "description": "Flujo de trabajo para empresas de transporte y logística",
    "workflow": {
        "steps": [
            "SOLICITUD_RECIBIDA",
            "ASIGNADO_CHOFER",
            "EN_TRANSITO",
            "EN_DESTINO",
            "COMPLETADO",
            "CANCELADO",
            "INCIDENCIA",
        ],
        "transitions": {
            "SOLICITUD_RECIBIDA": ["ASIGNADO_CHOFER", "CANCELADO"],
            "ASIGNADO_CHOFER": ["EN_TRANSITO", "CANCELADO"],
            "EN_TRANSITO": ["EN_DESTINO", "INCIDENCIA"],
            "EN_DESTINO": ["COMPLETADO", "INCIDENCIA"],
            "INCIDENCIA": ["EN_TRANSITO", "CANCELADO", "COMPLETADO"],
        },
    },
    "metadata_schema": {
        "type": "object",
        "properties": {
            "origen": {"type": "string", "title": "Dirección de Origen"},
            "destino": {"type": "string", "title": "Dirección de Destino"},
            "peso_carga_kg": {"type": "number", "title": "Peso Carga (kg)"},
            "patente_vehiculo": {"type": "string", "title": "Patente Vehículo"},
            "chofer_id": {"type": "integer", "title": "ID Chofer"},
            "tipo_carga": {
                "type": "string",
                "enum": ["GENERAL", "PELIGROSA", "FRAGIL", "REFRIGERADA"],
            },
        },
        "required": ["origen", "destino", "tipo_carga"],
    },
}

MECANICA_TEMPLATE = {
    "name": "Mecánica Automotriz",
    "description": "Flujo para talleres mecánicos y servicios automotrices",
    "workflow": {
        "steps": [
            "RECEPCION_VEHICULO",
            "DIAGNOSTICO",
            "ESPERA_REPUESTOS",
            "EN_REPARACION",
            "CONTROL_CALIDAD",
            "LISTO_RETIRO",
            "ENTREGADO",
        ],
        "transitions": {
            "RECEPCION_VEHICULO": ["DIAGNOSTICO"],
            "DIAGNOSTICO": ["ESPERA_REPUESTOS", "EN_REPARACION", "LISTO_RETIRO"],
            "ESPERA_REPUESTOS": ["EN_REPARACION"],
            "EN_REPARACION": ["CONTROL_CALIDAD"],
            "CONTROL_CALIDAD": ["LISTO_RETIRO", "EN_REPARACION"],
            "LISTO_RETIRO": ["ENTREGADO"],
        },
    },
    "metadata_schema": {
        "type": "object",
        "properties": {
            "patente": {"type": "string", "title": "Patente"},
            "marca": {"type": "string", "title": "Marca"},
            "modelo": {"type": "string", "title": "Modelo"},
            "ano": {"type": "integer", "title": "Año"},
            "kilometraje": {"type": "integer", "title": "Kilometraje"},
            "nivel_combustible": {
                "type": "string",
                "enum": ["RESERVA", "1/4", "1/2", "3/4", "LLENO"],
            },
            "danos_previos": {
                "type": "string",
                "title": "Daños Previos / Observaciones Visuales",
            },
        },
        "required": ["patente", "marca", "modelo"],
    },
}

ESTAMPADOS_TEMPLATE = {
    "name": "Estampados y Serigrafía",
    "description": "Flujo de producción para estampados, bordados y personalización",
    "workflow": {
        "steps": [
            "DISENO_RECIBIDO",
            "APROBACION_DISENO",
            "PREPARACION_MATRICES",
            "PRODUCCION",
            "SECADO_CURADO",
            "CONTROL_CALIDAD",
            "EMPAQUETADO",
            "ENTREGADO",
        ],
        "transitions": {
            "DISENO_RECIBIDO": ["APROBACION_DISENO"],
            "APROBACION_DISENO": ["PREPARACION_MATRICES", "PRODUCCION"],
            "PREPARACION_MATRICES": ["PRODUCCION"],
            "PRODUCCION": ["SECADO_CURADO"],
            "SECADO_CURADO": ["CONTROL_CALIDAD"],
            "CONTROL_CALIDAD": ["EMPAQUETADO", "PRODUCCION"],
            "EMPAQUETADO": ["ENTREGADO"],
        },
    },
    "metadata_schema": {
        "type": "object",
        "properties": {
            "tipo_tela": {"type": "string", "title": "Tipo de Tela"},
            "color_base": {"type": "string", "title": "Color Base Prenda"},
            "ubicacion": {
                "type": "string",
                "enum": ["PECHO", "ESPALDA", "MANGA", "BOLSILLO"],
            },
            "tecnica": {
                "type": "string",
                "enum": ["SERIGRAFIA", "DTF", "SUBLIMACION", "BORDADO", "VINILO"],
            },
            "cantidad_colores": {"type": "integer", "title": "Cantidad de Colores"},
            "archivo_diseno_url": {"type": "string", "title": "URL Archivo Diseño"},
        },
        "required": ["tipo_tela", "tecnica", "ubicacion"],
    },
}

LAVANDERIA_TEMPLATE = {
    "name": "Lavandería Industrial",
    "description": "Flujo estándar para lavandería y tintorería",
    "workflow": {
        "steps": [
            "RECIBIDO",
            "CLASIFICACION",
            "LAVADO",
            "SECADO",
            "PLANCHADO",
            "EMPAQUETADO",
            "LISTO",
            "ENTREGADO",
        ],
        "transitions": {
            "RECIBIDO": ["CLASIFICACION"],
            "CLASIFICACION": ["LAVADO"],
            "LAVADO": ["SECADO"],
            "SECADO": ["PLANCHADO", "EMPAQUETADO"],
            "PLANCHADO": ["EMPAQUETADO"],
            "EMPAQUETADO": ["LISTO"],
            "LISTO": ["ENTREGADO"],
        },
    },
    "metadata_schema": {
        "type": "object",
        "properties": {
            "peso_kg": {"type": "number", "title": "Peso (kg)"},
            "tipo_lavado": {
                "type": "string",
                "enum": ["AGUA", "SECO", "PLANCHADO_SOLO"],
            },
            "numero_prendas": {"type": "integer", "title": "Número de Prendas"},
            "color_predominante": {"type": "string", "title": "Color Predominante"},
            "manchas_visibles": {"type": "boolean", "title": "Tiene Manchas Visibles"},
            "observaciones": {"type": "string", "title": "Observaciones"},
        },
        "required": ["peso_kg", "tipo_lavado"],
    },
}

INDUSTRY_TEMPLATES = {
    "transporte": TRANSPORTE_TEMPLATE,
    "mecanica": MECANICA_TEMPLATE,
    "estampados": ESTAMPADOS_TEMPLATE,
    "lavanderia": LAVANDERIA_TEMPLATE,
}
