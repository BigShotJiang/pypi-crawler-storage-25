from typing import Optional, Dict, Any, List
from pydantic import BaseModel, ConfigDict
from datetime import datetime
from uuid import UUID
from app.core_modules.ventas.schemas import Producto
from pydantic import Field

# -----------------------------------------------------------------------------
# Service Order (Generic)
# -----------------------------------------------------------------------------


class ServiceOrderBase(BaseModel):
    producto_id: UUID
    sucursal_id: UUID
    # Metadata holds vertical-specific fields (e.g. peso_kg, tipo_lavado)
    metadata_info: Dict[str, Any] = {}
    observaciones: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class ServiceOrderCreate(ServiceOrderBase):
    model_config = ConfigDict(from_attributes=True, extra="forbid")


class ServiceOrderUpdate(BaseModel):
    status: str
    observaciones: Optional[str] = None
    metadata_info: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class ServiceOrder(ServiceOrderBase):
    id: UUID
    status: str
    empresa_id: UUID
    usuario_id: UUID
    job_order_id: Optional[UUID] = None

    total_estimado: int
    neto: Optional[int] = 0
    iva: Optional[int] = 0

    venta_id: Optional[UUID] = None
    producto: Optional[Producto] = None

    created_at: datetime
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(
        from_attributes=True, populate_by_name=True, extra="forbid"
    )


# -----------------------------------------------------------------------------
# Job Order
# -----------------------------------------------------------------------------


class JobOrderBase(BaseModel):
    description: Optional[str] = None
    sucursal_id: UUID

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class JobOrderCreate(JobOrderBase):
    # Initial service orders to create with the Job Order
    service_orders: List[ServiceOrderCreate] = []

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class JobOrder(JobOrderBase):
    id: UUID
    empresa_id: UUID
    usuario_id: UUID
    created_at: datetime
    updated_at: Optional[datetime] = None
    service_orders: List[ServiceOrder] = []

    model_config = ConfigDict(from_attributes=True, extra="forbid")


# -----------------------------------------------------------------------------
# Service Status Config
# -----------------------------------------------------------------------------


class ServiceStatusConfigUpdate(BaseModel):
    states: List[str] = Field(default_factory=list)

    model_config = ConfigDict(from_attributes=True, extra="forbid")


class ServiceStatusConfigRead(BaseModel):
    empresa_id: UUID
    states: List[str]
    updated_at: Optional[datetime] = None
    extra_features: Optional[Dict[str, Any]] = None
    
    model_config = ConfigDict(from_attributes=True, extra="forbid")
