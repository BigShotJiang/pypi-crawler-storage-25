from typing import Any
from sqlalchemy.orm import Session
from uuid import UUID
from app.core_modules.service_engine.models import ServiceOrder, ServiceWorkflow
from app.core_modules.service_engine.industry_templates import INDUSTRY_TEMPLATES
from fastapi import HTTPException
import logging

logger = logging.getLogger(__name__)


class ServiceEngineService:
    @staticmethod
    def initialize_industry_workflow(
        db: Session, company_id: UUID, industry_key: str
    ) -> ServiceWorkflow:
        """
        Initializes or updates the ServiceWorkflow for a company based on an industry template.

        Args:
            db: Database session
            company_id: ID of the company
            industry_key: Key of the industry template (e.g., 'transporte', 'mecanica')

        Returns:
            The created or updated ServiceWorkflow instance.
        """
        if industry_key not in INDUSTRY_TEMPLATES:
            valid_keys = ", ".join(INDUSTRY_TEMPLATES.keys())
            raise HTTPException(
                status_code=400,
                detail=f"Invalid industry key: {industry_key}. Valid keys are: {valid_keys}",
            )

        template = INDUSTRY_TEMPLATES[industry_key]

        # Check if workflow already exists for this company
        # For simplicity, we assume one primary workflow per company for now,
        # or we could search by name if we support multiple.
        # Let's search by name matching the template name to allow re-initialization

        # Ensure unique name per company to avoid UniqueConstraint violation
        workflow_name = f"{template['name']} ({industry_key.upper()}) - {company_id}"

        existing_workflow = (
            db.query(ServiceWorkflow)
            .filter(
                ServiceWorkflow.empresa_id == company_id,
                ServiceWorkflow.name == workflow_name,
            )
            .first()
        )

        if existing_workflow:
            logger.info(
                f"Updating existing workflow '{workflow_name}' for company {company_id}"
            )
            existing_workflow.config = template["workflow"]
            # We could also update metadata schema if we stored it in the DB,
            # currently ServiceWorkflow only has 'config' which usually holds workflow steps.
            # If we want to store metadata schema, we might need a column for it or store it in config.
            # Let's check the model again.

            # Model has: config = Column(JSONB, default={}) # Definition of states and transitions
            # It seems 'config' is intended for the workflow definition.
            # Where do we store the metadata schema?
            # The prompt asked for "esquemas de Metadata".
            # Ideally, the ServiceWorkflow should hold the schema too so the frontend knows what to render.
            # I will store the metadata schema inside the 'config' JSONB as well, under a 'metadata_schema' key.

            config_data = {
                "workflow": template["workflow"],
                "metadata_schema": template["metadata_schema"],
            }
            existing_workflow.config = config_data
            existing_workflow.description = template["description"]

        else:
            logger.info(
                f"Creating new workflow '{workflow_name}' for company {company_id}"
            )
            config_data = {
                "workflow": template["workflow"],
                "metadata_schema": template["metadata_schema"],
            }

            new_workflow = ServiceWorkflow(
                name=workflow_name,
                description=template["description"],
                config=config_data,
                empresa_id=company_id,
            )
            db.add(new_workflow)
            existing_workflow = new_workflow

        db.commit()
        db.refresh(existing_workflow)
        return existing_workflow

    @staticmethod
    def get_workflow_by_company(db: Session, company_id: UUID):
        """
        Retrieves the workflows configured for a company.
        """
        return (
            db.query(ServiceWorkflow)
            .filter(ServiceWorkflow.empresa_id == company_id)
            .all()
        )

    @staticmethod
    def get_service_order_context(
        db: Session, *, service_order_id: UUID
    ) -> dict[str, Any] | None:
        order = (
            db.query(ServiceOrder).filter(ServiceOrder.id == service_order_id).first()
        )
        if not order:
            return None
        return {
            "id": order.id,
            "empresa_id": order.empresa_id,
            "sucursal_id": order.sucursal_id,
            "usuario_id": order.usuario_id,
            "producto_id": order.producto_id,
            "venta_id": order.venta_id,
            "status": order.status,
            "metadata_info": order.metadata_info,
        }
