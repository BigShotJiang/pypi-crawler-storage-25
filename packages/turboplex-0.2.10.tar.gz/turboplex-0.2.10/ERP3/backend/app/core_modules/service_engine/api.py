from typing import Any, List
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from decimal import Decimal
from app.api import deps
from . import models, schemas
from app.core_modules.finanzas import services as finanzas_services
from app.core.infrastructure.events import event_dispatcher
from app.core.services.feature_service import feature_service

# Define generic events
EVENT_SERVICE_UPDATE = "service_engine.order.update"
EVENT_JOB_CREATED = "service_engine.job.created"

router = APIRouter()

# -----------------------------------------------------------------------------
# Service Engine API
# -----------------------------------------------------------------------------


@router.get(
    "/service-engine/status-config", response_model=schemas.ServiceStatusConfigRead
)
def get_status_config(
    db: Session = Depends(deps.get_db),
    current_company=Depends(deps.get_current_active_company),
):
    cfg = (
        db.query(models.ServiceStatusConfig)
        .filter(models.ServiceStatusConfig.empresa_id == current_company.id)
        .first()
    )
    if not cfg:
        return {"empresa_id": current_company.id, "states": [], "updated_at": None}
    
    # Pilar 10: Feature Flag Check
    extra = None
    if feature_service.is_enabled("EXTENDED_SERVICE_CONFIG", current_company):
        extra = {"experimental_mode": True, "beta_features": ["auto_assign", "smart_routing"]}
        
    return {
        "empresa_id": current_company.id,
        "states": cfg.states,
        "updated_at": cfg.updated_at,
        "extra_features": extra
    }


@router.post(
    "/service-engine/status-config", response_model=schemas.ServiceStatusConfigRead
)
def set_status_config(
    update: schemas.ServiceStatusConfigUpdate,
    db: Session = Depends(deps.get_db),
    current_user=Depends(deps.get_current_user),
    current_company=Depends(deps.get_current_active_company),
):
    if current_user.role not in ["ADMIN", "ADMIN_SAAS", "SUPERADMIN", "DEVELOPER"]:
        raise HTTPException(status_code=403, detail="No autorizado")
    states = [s.strip() for s in update.states if s and s.strip()]
    if len(states) < 2:
        raise HTTPException(status_code=400, detail="Debe definir al menos 2 estados")
    cfg = (
        db.query(models.ServiceStatusConfig)
        .filter(models.ServiceStatusConfig.empresa_id == current_company.id)
        .first()
    )
    if not cfg:
        cfg = models.ServiceStatusConfig(empresa_id=current_company.id, states=states)
        db.add(cfg)
    else:
        cfg.states = states
        db.add(cfg)
    db.commit()
    db.refresh(cfg)
    return {
        "empresa_id": current_company.id,
        "states": cfg.states,
        "updated_at": cfg.updated_at,
    }


@router.post("/job-orders", response_model=schemas.JobOrder)
async def create_job_order(
    *,
    db: Session = Depends(deps.get_db),
    job_in: schemas.JobOrderCreate,
    current_user=Depends(deps.get_current_user),
    current_company=Depends(deps.get_current_active_company),
) -> Any:
    """
    Creates a new Job Order (OT) which can contain multiple Service Orders.
    """
    # 1. Create Job Order
    job_order = models.JobOrder(
        description=job_in.description,
        sucursal_id=job_in.sucursal_id,
        empresa_id=current_company.id,
        usuario_id=current_user.id,
    )
    db.add(job_order)
    db.flush()  # Get ID

    # 2. Create Service Orders
    created_services = []
    for svc_in in job_in.service_orders:
        # Calculate price (Generic Logic via Finanzas)
        precio_unitario = finanzas_services.get_current_price(
            db=db,
            producto_id=svc_in.producto_id,
            sucursal_id=svc_in.sucursal_id,
            tipo_cliente=None,
        )

        # Calculate Total.
        # Note: 'peso_kg' is now in metadata. We need to know how to calculate based on metadata.
        # For now, we assume 'qty' or 'amount' key in metadata, or fallback to 1.
        # Laundry specific logic: metadata['peso_kg']
        qty = 1.0
        if svc_in.metadata_info and "peso_kg" in svc_in.metadata_info:
            qty = float(svc_in.metadata_info["peso_kg"])

        total_bruto = int(precio_unitario * Decimal(str(qty)))
        desglose = finanzas_services.calculate_taxes_from_total(Decimal(total_bruto))

        # Prepare metadata with observations
        meta = svc_in.metadata_info or {}
        if svc_in.observaciones:
            meta["observaciones"] = svc_in.observaciones

        service_order = models.ServiceOrder(
            job_order_id=job_order.id,
            producto_id=svc_in.producto_id,
            sucursal_id=svc_in.sucursal_id,
            metadata_info=meta,
            empresa_id=current_company.id,
            usuario_id=current_user.id,
            status="RECIBIDO",  # Default start state
            total_estimado=desglose["total"],
            neto=desglose["neto"],
            iva=desglose["iva"],
        )
        db.add(service_order)
        created_services.append(service_order)

    db.commit()
    db.refresh(job_order)

    # Dispatch Event
    await event_dispatcher.dispatch(
        EVENT_JOB_CREATED, {"empresa_id": current_company.id, "job_order_id": job_order.id}
    )

    return job_order


@router.patch("/service-orders/{id}/status", response_model=schemas.ServiceOrder)
async def update_service_status(
    *,
    db: Session = Depends(deps.get_db),
    id: UUID,
    status_update: schemas.ServiceOrderUpdate,
    current_company=Depends(deps.get_current_active_company),
) -> Any:
    """
    Updates the status of a specific Service Order.
    """
    service_order = (
        db.query(models.ServiceOrder)
        .filter(
            models.ServiceOrder.id == id,
            models.ServiceOrder.empresa_id == current_company.id,
        )
        .options(
            joinedload(models.ServiceOrder.workflow),
            joinedload(models.ServiceOrder.producto),
        )
        .first()
    )

    if not service_order:
        raise HTTPException(status_code=404, detail="Service Order not found")

    # Validation for Transport Services
    # If transitioning to COMPLETED, ensure critical metadata exists.
    # We identify Transport services by Workflow Name or Product Name.
    is_transport = False
    if service_order.workflow and "transporte" in service_order.workflow.name.lower():
        is_transport = True
    elif (
        service_order.producto and "transporte" in service_order.producto.nombre.lower()
    ):
        is_transport = True

    if is_transport and status_update.status == "COMPLETED":
        # Merge current and new metadata to check
        current_meta = (
            dict(service_order.metadata_info) if service_order.metadata_info else {}
        )
        if status_update.metadata_info:
            current_meta.update(status_update.metadata_info)

        # Check distancia_km
        dist = current_meta.get("distancia_km")
        if not dist:
            raise HTTPException(
                status_code=400,
                detail="Validación Fallida: El servicio de transporte requiere 'distancia_km' para ser completado.",
            )
        try:
            if float(dist) <= 0:
                raise ValueError
        except Exception:
            raise HTTPException(
                status_code=400,
                detail="Validación Fallida: 'distancia_km' debe ser un número mayor a 0.",
            )

    old_status = service_order.status
    service_order.status = status_update.status

    if status_update.observaciones:
        # Update observations in metadata
        current_meta = (
            dict(service_order.metadata_info) if service_order.metadata_info else {}
        )
        current_meta["observaciones"] = status_update.observaciones
        service_order.metadata_info = current_meta

    if status_update.metadata_info:
        # Merge additional metadata
        current_meta = (
            dict(service_order.metadata_info) if service_order.metadata_info else {}
        )
        current_meta.update(status_update.metadata_info)
        service_order.metadata_info = current_meta

    db.commit()
    db.refresh(service_order)

    # Dispatch Event
    await event_dispatcher.dispatch(
        EVENT_SERVICE_UPDATE,
        {
            "empresa_id": current_company.id,
            "service_order_id": service_order.id,
            "old_status": old_status,
            "new_status": service_order.status,
            "status": service_order.status,
        },
    )

    return service_order


@router.get("/service-orders", response_model=List[schemas.ServiceOrder])
def list_service_orders(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    status: str = None,
    current_company=Depends(deps.get_current_active_company),
) -> Any:
    query = db.query(models.ServiceOrder).filter(
        models.ServiceOrder.empresa_id == current_company.id
    )
    if status:
        query = query.filter(models.ServiceOrder.status == status)
    return query.offset(skip).limit(limit).all()
