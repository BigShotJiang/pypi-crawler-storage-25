from sqlalchemy import (
    Column,
    Integer,
    String,
    ForeignKey,
    DateTime,
    func,
)
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.dialects.postgresql import JSONB
from app.core.database import Base, GUID
from typing import Optional
from uuid import UUID
import uuid6


class ServiceWorkflow(Base):
    __tablename__ = "service_workflows"
    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    name = Column(String, unique=True, nullable=False)
    description = Column(String, nullable=True)
    config = Column(JSONB, default={})  # Definition of states and transitions
    empresa_id: Mapped[Optional[UUID]] = Column(
        GUID, ForeignKey("empresas.id"), nullable=True
    )


class JobOrder(Base):
    __tablename__ = "job_orders"
    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    description = Column(String, nullable=True)

    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False)
    sucursal_id = Column(GUID, ForeignKey("sucursales.id"), nullable=False)
    usuario_id = Column(GUID, ForeignKey("usuarios.id"), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    service_orders = relationship("ServiceOrder", back_populates="job_order")
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")
    usuario = relationship("app.core_modules.sistema.models.Usuario")


class ServiceOrder(Base):
    __tablename__ = "service_orders"  # Renamed from tickets_lavanderia

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    job_order_id = Column(GUID, ForeignKey("job_orders.id"), nullable=True)
    workflow_id = Column(GUID, ForeignKey("service_workflows.id"), nullable=True)

    # Generic Status (formerly 'estado')
    status = Column("estado", String, index=True, default="PENDING")

    # Universal Metadata (replaces specific columns like peso_kg, tipo_lavado)
    metadata_info = Column("metadata", JSONB, default={})

    # Specific columns kept for mapping/compatibility if needed, but intended to be in metadata
    # We rely on Alembic to migrate data to metadata

    # Financials
    total_estimado = Column(Integer, default=0)
    neto = Column(Integer, default=0)
    iva = Column(Integer, default=0)

    # Links
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False)
    sucursal_id = Column(GUID, ForeignKey("sucursales.id"), nullable=False)
    usuario_id = Column(GUID, ForeignKey("usuarios.id"), nullable=False)
    producto_id = Column(GUID, ForeignKey("productos.id"), nullable=False)
    venta_id = Column(GUID, ForeignKey("ventas.id"), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    job_order = relationship("JobOrder", back_populates="service_orders")
    workflow = relationship("ServiceWorkflow")
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")
    usuario = relationship("app.core_modules.sistema.models.Usuario")
    producto = relationship("app.core_modules.ventas.models.Producto")
    venta = relationship("app.core_modules.ventas.models.Venta")


class ServiceStatusConfig(Base):
    __tablename__ = "service_status_config"
    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    states = Column(JSONB, nullable=False, default=[])
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
