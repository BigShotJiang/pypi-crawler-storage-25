from typing import Any, List, Optional
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, ConfigDict
from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session
from app.api import deps
from app.core_modules.inventario.movimientos.models import MovimientoStock
from app.core_modules.ventas.models import Producto
from app.core_modules.sistema.models import Bodega, Sucursal, Empresa, Usuario

class MovimientoRead(BaseModel):
    id: UUID
    producto_id: UUID
    bodega_id: UUID
    cantidad: int
    tipo_movimiento: str
    fecha: datetime
    usuario_id: Optional[UUID]
    producto_nombre: Optional[str] = None
    bodega_nombre: Optional[str] = None
    usuario_nombre: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, extra="ignore")

router = APIRouter()

@router.get("", response_model=List[MovimientoRead], include_in_schema=False)
@router.get("/", response_model=List[MovimientoRead])
def read_movements(
    response: Response,
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    producto_id: UUID = Query(None),
    bodega_id: UUID = Query(None),
    tipo: str = Query(None),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    query = db.query(MovimientoStock)

    if producto_id:
        query = query.filter(MovimientoStock.producto_id == producto_id)
    if bodega_id:
        query = query.filter(MovimientoStock.bodega_id == bodega_id)
    if tipo:
        query = query.filter(MovimientoStock.tipo_movimiento == tipo)

    query = (
        query.join(Bodega)
        .join(Sucursal)
        .join(Producto)
        .outerjoin(Usuario)
        .filter(Sucursal.empresa_id == current_company.id)
    )

    total_count = query.count()
    response.headers["X-Total-Count"] = str(total_count)

    movements = query.order_by(MovimientoStock.fecha.desc()).offset(skip).limit(limit).all()
    
    result = []
    for mov in movements:
        # Check if relationships are loaded or accessible
        # MovimientoStock should have relationships defined to Producto, Bodega, Usuario
        result.append({
            "id": mov.id,
            "producto_id": mov.producto_id,
            "bodega_id": mov.bodega_id,
            "cantidad": mov.cantidad,
            "tipo_movimiento": mov.tipo_movimiento,
            "fecha": mov.fecha,
            "usuario_id": mov.usuario_id,
            "producto_nombre": mov.producto.nombre if mov.producto else None,
            "bodega_nombre": mov.bodega.nombre if mov.bodega else None,
            "usuario_nombre": mov.usuario.email if mov.usuario else None, # Assuming email or nombre
        })
    return result
