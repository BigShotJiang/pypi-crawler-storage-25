from __future__ import annotations

import hashlib
import json
from typing import Any, cast
from uuid import UUID

import uuid6
from sqlalchemy.orm import Session

from app.core_modules.inventario.stock.models import ProductVariant


def canonicalize_attributes(attrs: dict[str, Any] | None) -> str:
    if not attrs:
        return "{}"
    return json.dumps(attrs, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def hash_identity(attrs: dict[str, Any] | None) -> str:
    canonical = canonicalize_attributes(attrs)
    return hashlib.md5(canonical.encode("utf-8")).hexdigest()


def resolve_or_create_variant_id(
    db: Session,
    *,
    producto_id: UUID,
    empresa_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
) -> UUID:
    hid = hash_identity(attributes)

    if empresa_id is None:
        from app.core_modules.ventas.models import Producto

        producto = db.query(Producto).filter(Producto.id == producto_id).first()
        if producto is None:
            raise ValueError("Producto no encontrado para resolver empresa_id")
        empresa_id = producto.empresa_id

    existing = (
        db.query(ProductVariant)
        .filter(
            ProductVariant.producto_id == producto_id,
            ProductVariant.hash_identity == hid,
        )
        .first()
    )
    if existing is not None:
        return cast(UUID, existing.id)

    variant = ProductVariant(
        id=uuid6.uuid7(),
        empresa_id=empresa_id,
        producto_id=producto_id,
        hash_identity=hid,
        attributes=attributes or {},
        sku_variant=None,
    )
    db.add(variant)
    db.flush()
    return cast(UUID, variant.id)
