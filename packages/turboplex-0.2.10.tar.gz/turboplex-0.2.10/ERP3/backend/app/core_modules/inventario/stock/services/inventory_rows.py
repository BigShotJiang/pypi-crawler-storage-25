from __future__ import annotations

from uuid import UUID
from typing import Optional, cast

from sqlalchemy.orm import Session

from app.core_modules.inventario.stock.models import Inventario


def list_inventario_rows_fifo(
    db: Session,
    *,
    empresa_id: UUID,
    variant_id: Optional[UUID],
    producto_id: Optional[UUID],
    bodega_id: UUID,
    for_update: bool,
) -> list[Inventario]:
    q = db.query(Inventario).filter(
        Inventario.empresa_id == empresa_id, Inventario.bodega_id == bodega_id
    )
    if variant_id is not None:
        q = q.filter(Inventario.variant_id == variant_id)
    elif producto_id is not None:
        q = q.filter(Inventario.producto_id == producto_id)
    q = q.order_by(Inventario.id.asc())
    if for_update:
        q = q.with_for_update()
    return cast(list[Inventario], q.all())
