from sqlalchemy.orm import Session
from sqlalchemy import func
from decimal import Decimal
from app.core_modules.ventas.models import Producto
from app.core_modules.inventario.stock.models import Inventario
from app.core_modules.inventario.valorizacion.models import HistorialCosto
from app.core_modules.inventario.movimientos.models import MovimientoStock
import logging

logger = logging.getLogger(__name__)

class ValuationService:
    def __init__(self, db: Session):
        self.db = db

    def calcular_nuevo_pmp(self, producto_id: str, cantidad_entrada: int, costo_entrada: Decimal, movimiento_id: str = None, tipo_movimiento: str = "ENTRADA"):
        """
        Recalcula el Precio Medio Ponderado (PMP) tras una entrada de stock.
        Formula: ((Stock_Anterior * PMP_Anterior) + (Cant_Entrada * Costo_Entrada)) / (Stock_Anterior + Cant_Entrada)
        
        NOTA: Se asume que el stock físico YA fue actualizado con la cantidad de entrada.
        Por tanto: Stock_Anterior = Stock_Actual - Cant_Entrada
        """
        producto = self.db.query(Producto).filter(Producto.id == producto_id).first()
        if not producto:
            logger.error(f"Producto {producto_id} no encontrado para valoración")
            return

        # Obtener Stock Total Actual (Suma de todas las bodegas)
        stock_actual = self.db.query(func.sum(Inventario.cantidad)).filter(Inventario.producto_id == producto_id).scalar() or 0
        
        # Como el movimiento ya sumó al stock, restamos para obtener el "Stock Anterior"
        # Si es el primer movimiento, stock_actual == cantidad_entrada
        stock_anterior = stock_actual - cantidad_entrada
        
        costo_anterior = producto.costo_promedio or Decimal(0)
        costo_entrada = Decimal(str(costo_entrada)) # Asegurar Decimal

        # Validación básica para evitar división por cero o inconsistencias
        if stock_actual <= 0:
            # Si por alguna razón el stock es 0 o negativo tras la entrada,
            # y es una entrada positiva, algo raro pasa con el inventario previo.
            # Asumiremos el costo de entrada como nuevo PMP si el stock es positivo.
            if cantidad_entrada > 0:
                nuevo_pmp = costo_entrada
            else:
                nuevo_pmp = costo_anterior
        else:
            if stock_anterior < 0:
                # Stock negativo previo (venta en descubierto), corrección
                stock_anterior = 0
            
            valor_anterior = Decimal(stock_anterior) * costo_anterior
            valor_entrada = Decimal(cantidad_entrada) * costo_entrada
            
            nuevo_pmp = (valor_anterior + valor_entrada) / Decimal(stock_actual)

        # Actualizar Producto
        producto.costo_promedio = nuevo_pmp
        self.db.add(producto)
        
        # Registrar Historial
        historial = HistorialCosto(
            producto_id=producto_id,
            costo_anterior=costo_anterior,
            costo_nuevo=nuevo_pmp,
            movimiento_id=movimiento_id,
            tipo_movimiento=tipo_movimiento
        )
        self.db.add(historial)
        
        logger.info(f"PMP Actualizado Producto {producto.sku}: {costo_anterior} -> {nuevo_pmp} (Stock: {stock_actual})")
        
        return nuevo_pmp

    def get_valor_total_bodega(self, bodega_id: str = None):
        """
        Calcula el valor monetario total del inventario (Stock * PMP).
        Si se especifica bodega_id, filtra por esa bodega.
        """
        query = self.db.query(
            Inventario.cantidad,
            Producto.costo_promedio
        ).join(Producto, Inventario.producto_id == Producto.id)
        
        if bodega_id:
            query = query.filter(Inventario.bodega_id == bodega_id)
            
        resultados = query.all()
        
        valor_total = sum([Decimal(inv.cantidad) * (inv.costo_promedio or 0) for inv in resultados])
        return valor_total

    def get_lot_cost(self, lote_id: str) -> Decimal:
        """
        Calcula el costo unitario específico de un lote basado en sus entradas.
        Si hubo múltiples entradas para el mismo lote, calcula un promedio ponderado.
        """
        movimientos = self.db.query(MovimientoStock).filter(
            MovimientoStock.lote_id == lote_id,
            MovimientoStock.cantidad > 0
        ).all()
        
        if not movimientos:
            return Decimal(0)
            
        total_cost = sum(Decimal(m.cantidad) * (m.costo_unitario or Decimal(0)) for m in movimientos)
        total_qty = sum(m.cantidad for m in movimientos)
        
        if total_qty == 0:
            return Decimal(0)
            
        return total_cost / Decimal(total_qty)

    def procesar_movimiento(self, movimiento: MovimientoStock):
        """
        Método orquestador llamado por triggers o servicios de inventario.
        Solo recalculamos PMP si es una ENTRADA o COMPRA positiva.
        Las SALIDAS no afectan el PMP.
        """
        if movimiento.tipo in ["COMPRA", "ENTRADA", "AJUSTE_POSITIVO"] and movimiento.cantidad > 0:
            if movimiento.costo_unitario is not None:
                self.calcular_nuevo_pmp(
                    producto_id=movimiento.producto_id,
                    cantidad_entrada=movimiento.cantidad,
                    costo_entrada=movimiento.costo_unitario,
                    movimiento_id=movimiento.id,
                    tipo_movimiento=movimiento.tipo
                )
            else:
                logger.warning(f"Movimiento {movimiento.id} de tipo {movimiento.tipo} sin costo unitario. No se actualiza PMP.")
