from typing import Any, List
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api import deps
from app.core_modules.inventario.catalogo import schemas, services
from app.core_modules.sistema.models import Empresa

router = APIRouter()

@router.get("", response_model=List[schemas.ProductoRead], include_in_schema=False)
@router.get("/", response_model=List[schemas.ProductoRead])
def read_products(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return services.get_products(db, current_company.id, skip=skip, limit=limit)

@router.post("", response_model=schemas.ProductoRead, include_in_schema=False)
@router.post("/", response_model=schemas.ProductoRead)
def create_product(
    product_in: schemas.ProductoCreate,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return services.create_product(db, product_in, current_company.id)

@router.get("/{id}", response_model=schemas.ProductoRead)
def read_product(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    product = services.get_product(db, id, current_company.id)
    if not product:
        raise HTTPException(status_code=404, detail="Producto not found")
    return product

@router.put("/{id}", response_model=schemas.ProductoRead)
def update_product(
    id: UUID,
    product_in: schemas.ProductoUpdate,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return services.update_product(db, id, product_in, current_company.id)

@router.delete("/{id}")
def delete_product(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    services.delete_product(db, id, current_company.id)
    return {"message": "Producto deleted"}
