from typing import Optional, List
from uuid import UUID
from sqlalchemy.orm import Session
from app.core.exceptions import ResourceNotFoundError, BusinessRuleError
from app.core_modules.ventas.models import Producto
from app.core_modules.inventario.catalogo import schemas

def get_products(db: Session, empresa_id: UUID, skip: int = 0, limit: int = 100) -> List[Producto]:
    return (
        db.query(Producto)
        .filter(Producto.empresa_id == empresa_id, Producto.is_deleted.is_(False))
        .offset(skip)
        .limit(limit)
        .all()
    )

def get_product(db: Session, producto_id: UUID, empresa_id: UUID) -> Optional[Producto]:
    return (
        db.query(Producto)
        .filter(Producto.id == producto_id, Producto.empresa_id == empresa_id)
        .first()
    )

def create_product(db: Session, product_in: schemas.ProductoCreate, empresa_id: UUID) -> Producto:
    # Check SKU uniqueness
    existing = (
        db.query(Producto)
        .filter(Producto.sku == product_in.sku, Producto.empresa_id == empresa_id)
        .first()
    )
    if existing:
        raise BusinessRuleError(f"El SKU {product_in.sku} ya existe.")

    product_data = product_in.model_dump()
    product = Producto(**product_data, empresa_id=empresa_id)
    db.add(product)
    db.commit()
    db.refresh(product)
    return product

def update_product(
    db: Session, producto_id: UUID, product_in: schemas.ProductoUpdate, empresa_id: UUID
) -> Producto:
    product = get_product(db, producto_id, empresa_id)
    if not product:
        raise ResourceNotFoundError(resource="Producto", resource_id=producto_id)

    update_data = product_in.model_dump(exclude_unset=True)
    
    # Check SKU if changing
    if "sku" in update_data and update_data["sku"] != product.sku:
        existing = (
            db.query(Producto)
            .filter(Producto.sku == update_data["sku"], Producto.empresa_id == empresa_id)
            .first()
        )
        if existing:
            raise BusinessRuleError(f"El SKU {update_data['sku']} ya existe.")

    for field, value in update_data.items():
        setattr(product, field, value)

    db.add(product)
    db.commit()
    db.refresh(product)
    return product

def delete_product(db: Session, producto_id: UUID, empresa_id: UUID) -> None:
    product = get_product(db, producto_id, empresa_id)
    if not product:
        raise ResourceNotFoundError(resource="Producto", resource_id=producto_id)
    
    # Soft delete via Mixin or manual
    # Assuming SoftDeleteMixin is used which intercepts delete?
    # Or we should use db.delete(product) if soft delete is handled by ORM event or mixin logic
    # The model inherits SoftDeleteMixin. Usually this means we set deleted_at.
    # Let's check SoftDeleteMixin implementation if possible, but usually db.delete works if cascade is configured or we just set deleted_at.
    # The standard way with SoftDeleteMixin is often just db.delete(obj) if the session is configured to soft-delete, OR we manually set deleted_at.
    # Let's try db.delete() first, if it fails or hard deletes, we fix.
    # Actually, SoftDeleteMixin usually requires manual `deleted_at` setting unless there's a session extension.
    # Let's set deleted_at manually to be safe.
    from datetime import datetime
    product.deleted_at = datetime.utcnow()
    db.add(product)
    db.commit()
