from typing import Any

from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Numeric, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship, Mapped, mapped_column
from datetime import datetime
from app.core.database import Base, GUID
from uuid import UUID
import uuid6

class MovimientoStock(Base):
    __tablename__ = "movimientos_stock"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id", ondelete="RESTRICT"), nullable=False, index=True)
    bodega_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("bodegas.id", ondelete="RESTRICT"), nullable=False, index=True)
    cantidad: Mapped[int] = mapped_column(
        Integer, nullable=False
    )  # Negative for sales, positive for purchases/returns
    costo_unitario = Column(Numeric(14, 4), nullable=True)  # Cost at the moment of movement
    tipo = Column(String, nullable=False)  # 'VENTA', 'COMPRA', 'AJUSTE', etc.
    fecha = Column(DateTime, default=datetime.utcnow, nullable=False)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False, index=True
    )
    import_run_id: Mapped[UUID | None] = mapped_column(GUID, nullable=True, index=True)
    additional_attributes: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
    )
    
    # Traceability
    lote_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("inventario_lotes.id"), nullable=True, index=True)

    # Relationships
    # Using explicit string references
    producto = relationship("app.core_modules.ventas.models.Producto", backref="movimientos_stock") # Changed backref from 'movimientos' to avoid conflict if any
    bodega = relationship("app.core_modules.sistema.models.Bodega")
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    lote = relationship("app.core_modules.inventario.stock.models.InventarioLote", backref="movimientos")
