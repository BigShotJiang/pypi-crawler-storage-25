from typing import Any, List
from uuid import UUID
import hashlib
import json
from io import BytesIO

import pandas as pd
import uuid6
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Response, UploadFile, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.api import deps
from app.core.auth.rbac import resolve_user_role_code
from app.core_modules.inventario.stock import schemas, services, models
from app.core_modules.ventas.models import Producto
from app.core_modules.sistema.models import Bodega, Sucursal, Empresa
from app.models.staging import ImportTemplate, ImportTemplateType, StagingImport
from app.core.services import ingestion_service
from app.core.services.import_service import ImportService

router = APIRouter()


def require_company_role(
    allowed_codes: set[str],
    *,
    detail: str = "No autorizado",
    allow_platform_roles: bool = True,
) -> Any:
    def _dep(
        db: Session = Depends(deps.get_db),
        current_user: Any = Depends(deps.get_current_user),
        current_company: Empresa = Depends(deps.get_current_active_company),
    ) -> Any:
        if allow_platform_roles and getattr(current_user, "role", None) in {
            deps.UserRole.SUPERADMIN,
            deps.UserRole.DEVELOPER,
            deps.UserRole.ADMIN,
        }:
            return current_user
        code = (resolve_user_role_code(db, current_user.id, current_company.id) or "").upper()
        if code not in allowed_codes:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail)
        return current_user

    return Depends(_dep)


class MassiveUploadResponse(BaseModel):
    staging_key: str
    original_filename: str | None
    file_hash: str
    rows_inserted: int

    model_config = ConfigDict(extra="forbid")


class MassiveValidateRequest(BaseModel):
    staging_key: str
    limit: int = 5_000

    model_config = ConfigDict(extra="forbid")


class MassiveValidateResponse(BaseModel):
    processed: int
    validated: int
    failed: int

    model_config = ConfigDict(extra="forbid")


class MassiveApplyRequest(BaseModel):
    staging_key: str
    file_hash: str
    warehouse_column: str = "Almacén"
    limit: int | None = None
    mapping_json: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid")


class MassiveApplyResponse(BaseModel):
    import_run_id: str
    bodega_id: str
    created_products: int
    updated_products: int
    stock_updates: int
    failed_rows: int

    model_config = ConfigDict(extra="forbid")


@router.post("/massive/analyze-headers", response_model=List[str])
async def massive_analyze_headers(
    file: UploadFile = File(...),
    sheet_name: str | None = Form("0"),
    header: int = Form(0),
    db: Session = Depends(deps.get_db),
    _current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role(
        {"ADM", "OPS", "AUD"},
        detail="Requiere autorización (ADM/OPS/AUD) para analizar plantillas",
        allow_platform_roles=True,
    ),
) -> Any:
    content = await file.read()
    try:
        used_sheet: str | int | None = sheet_name
        if used_sheet is not None:
            s = str(used_sheet).strip()
            if s.isdigit():
                used_sheet = int(s)
            elif s == "":
                used_sheet = 0
            else:
                used_sheet = s
        else:
            used_sheet = 0

        df = pd.read_excel(BytesIO(content), sheet_name=used_sheet, header=header, nrows=0)
        if not isinstance(df, pd.DataFrame):
            raise ValueError("sheet_name debe referenciar una sola hoja")
        headers = [str(c).strip() for c in df.columns]
        headers = [h for h in headers if h != ""]
        return headers
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)) from e


@router.get("/massive/templates", response_model=List[schemas.ImportTemplateRead])
def massive_list_templates(
    tipo_importacion: str | None = Query("STOCK_ADJUST"),
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role(
        {"ADM", "OPS", "AUD"},
        detail="Requiere autorización (ADM/OPS/AUD) para listar plantillas",
        allow_platform_roles=True,
    ),
) -> Any:
    tipo: ImportTemplateType | None = None
    if tipo_importacion is not None and str(tipo_importacion).strip() != "":
        try:
            tipo = ImportTemplateType(str(tipo_importacion).strip())
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)) from e

    query = db.query(ImportTemplate).filter(ImportTemplate.empresa_id == current_company.id)
    if tipo is not None:
        query = query.filter(ImportTemplate.tipo_importacion == tipo)
    return query.order_by(func.lower(ImportTemplate.nombre).asc()).all()


@router.post("/massive/dynamic-stock-adjust", response_model=schemas.DynamicStockAdjustResponse)
async def massive_dynamic_stock_adjust(
    file: UploadFile = File(...),
    mapping_json: str | None = Form(None),
    template_id: str | None = Form(None),
    template_name: str | None = Form(None),
    sheet_name: str | None = Form("0"),
    header: int = Form(0),
    reason: str | None = Form(None),
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Any = require_company_role(
        {"ADM", "OPS", "AUD"},
        detail="Requiere autorización (ADM/OPS/AUD) para aplicar ajustes vía plantilla",
        allow_platform_roles=True,
    ),
) -> Any:
    content = await file.read()
    if not mapping_json and not template_id:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Debe proporcionar mapping_json o template_id",
        )

    parsed_template_id: UUID | None = None
    if template_id:
        try:
            parsed_template_id = UUID(template_id)
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)) from e

    mapping: dict[str, Any] | None = None
    try:
        if mapping_json:
            mapping = json.loads(mapping_json)
            mapping = schemas.StockAdjustMappingJson.model_validate(mapping).model_dump()
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)) from e

    result = ImportService.stock_adjust_from_excel_dynamic_template(
        db=db,
        empresa_id=current_company.id,
        content=content,
        mapping=mapping,
        template_id=parsed_template_id,
        template_name=template_name,
        filename=file.filename,
        sheet_name=sheet_name,
        header=header,
        staging_key=f"DYNINV-{uuid6.uuid7().hex}",
        actor_id=getattr(current_user, "id", None),
        reason=reason,
    )
    return result


class MassiveStagingSummary(BaseModel):
    pending: int
    validated: int
    failed: int

    model_config = ConfigDict(extra="forbid")


class MassiveStagingErrorRow(BaseModel):
    id: str
    row_number: int | None
    error_log: dict[str, Any] | None
    raw_content: dict[str, Any] | None

    model_config = ConfigDict(extra="forbid")


@router.get("/bodegas", response_model=List[schemas.BodegaRead])
def read_bodegas(
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return (
        db.query(Bodega)
        .join(Sucursal)
        .filter(Sucursal.empresa_id == current_company.id)
        .all()
    )

@router.get("", response_model=List[schemas.StockRead], include_in_schema=False)
@router.get("/", response_model=List[schemas.StockRead])
def read_stock(
    response: Response,
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    bodega_id: UUID = Query(None),
    producto_id: UUID = Query(None),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    query = db.query(models.Inventario)

    if bodega_id:
        query = query.filter(models.Inventario.bodega_id == bodega_id)
    if producto_id:
        query = query.filter(models.Inventario.producto_id == producto_id)

    query = (
        query.join(Bodega)
        .join(Sucursal)
        .join(models.ProductVariant, models.Inventario.variant_id == models.ProductVariant.id)
        .join(Producto)
        .filter(Sucursal.empresa_id == current_company.id)
    )

    total_count = query.count()
    response.headers["X-Total-Count"] = str(total_count)

    stock_items = query.offset(skip).limit(limit).all()
    
    # Map to schema manually or let Pydantic handle it if fields match
    # Schema expects producto_nombre and bodega_nombre which are not on Inventario directly
    result = []
    for item in stock_items:
        result.append({
            "id": item.id,
            "sku": item.producto.sku if item.producto else None,
            "producto_id": item.producto_id,
            "variant_id": item.variant_id,
            "bodega_id": item.bodega_id,
            "cantidad": item.cantidad,
            "cantidad_reservada": item.cantidad_reservada,
            "stock_minimo": item.stock_minimo,
            "producto_nombre": item.producto.nombre if item.producto else None,
            "bodega_nombre": item.bodega.nombre if item.bodega else None,
            "additional_attributes": (item.variant.attributes if item.variant else {}) or {},
        })
    return result


@router.post("/massive/upload", response_model=MassiveUploadResponse)
async def massive_upload_inventory(
    file: UploadFile = File(...),
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role({"ADM", "OPS", "AUD"}, allow_platform_roles=True),
) -> Any:
    content = await file.read()
    file_hash = hashlib.sha256(content).hexdigest()
    staging_key = f"INV-{uuid6.uuid7().hex}"
    inserted = ingestion_service.ingest_excel_bytes_to_staging(
        db=db,
        empresa_id=current_company.id,
        content=content,
        filename=staging_key,
    )
    return {
        "staging_key": staging_key,
        "original_filename": file.filename,
        "file_hash": file_hash,
        "rows_inserted": inserted,
    }


@router.post("/massive/validate", response_model=MassiveValidateResponse)
def massive_validate_inventory(
    payload: MassiveValidateRequest,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role({"ADM", "OPS", "AUD"}, allow_platform_roles=True),
) -> Any:
    limit = int(payload.limit or 0)
    if limit <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="limit inválido")
    if limit > 10_000:
        limit = 10_000
    summary = ingestion_service.process_staging_to_production(
        db=db,
        empresa_id=current_company.id,
        limit=limit,
        template="inventario",
        source_filename=payload.staging_key,
    )
    return summary


@router.get("/massive/staging-summary", response_model=MassiveStagingSummary)
def massive_staging_summary(
    staging_key: str,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role({"ADM", "OPS", "AUD"}, allow_platform_roles=True),
) -> Any:
    counts = (
        db.query(StagingImport.status, func.count(StagingImport.id))
        .filter(
            StagingImport.empresa_id == current_company.id,
            StagingImport.source_filename == staging_key,
        )
        .group_by(StagingImport.status)
        .all()
    )
    mapped = {status: int(cnt) for status, cnt in counts}
    return {
        "pending": mapped.get("pending", 0),
        "validated": mapped.get("validated", 0),
        "failed": mapped.get("failed", 0),
    }


@router.get("/massive/staging-errors", response_model=list[MassiveStagingErrorRow])
def massive_staging_errors(
    staging_key: str,
    skip: int = 0,
    limit: int = 200,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role({"ADM", "OPS", "AUD"}, allow_platform_roles=True),
) -> Any:
    rows = (
        db.query(StagingImport)
        .filter(
            StagingImport.empresa_id == current_company.id,
            StagingImport.source_filename == staging_key,
            StagingImport.status == "failed",
        )
        .order_by(StagingImport.created_at.asc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    out: list[dict[str, Any]] = []
    for row in rows:
        raw = dict(row.raw_content or {})
        out.append(
            {
                "id": str(row.id),
                "row_number": raw.get("_row_number"),
                "error_log": row.error_log,
                "raw_content": raw,
            }
        )
    return out


@router.post("/massive/apply", response_model=MassiveApplyResponse)
def massive_apply_inventory(
    payload: MassiveApplyRequest,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role(
        {"ADM"},
        detail="Requiere autorización de Gerencia (ADM) para aplicar cambios a producción",
        allow_platform_roles=False,
    ),
) -> Any:
    result = ingestion_service.apply_validated_inventory_to_production(
        db=db,
        empresa_id=current_company.id,
        filename=payload.staging_key,
        file_hash=payload.file_hash,
        warehouse_column=payload.warehouse_column,
        limit=payload.limit,
        source_filename=payload.staging_key,
        mapping_json=payload.mapping_json,
    )
    failed_rows = len(result.get("errors") or [])
    return {
        "import_run_id": str(result.get("import_run_id")),
        "bodega_id": str(result.get("bodega_id")),
        "created_products": int(result.get("created_products") or 0),
        "updated_products": int(result.get("updated_products") or 0),
        "stock_updates": int(result.get("stock_updates") or 0),
        "failed_rows": failed_rows,
    }

@router.post("/adjust")
def adjust_stock(
    adjustment: schemas.StockAdjustmentCreate,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    _current_user: Any = require_company_role({"ADM", "BOD", "OPS"}, allow_platform_roles=True),
) -> Any:
    if adjustment.cantidad > 0:
        services.InventoryService.add_stock(
            db,
            adjustment.producto_id,
            adjustment.bodega_id,
            adjustment.cantidad,
            adjustment.tipo_movimiento,
            current_company.id,
            costo_unitario=adjustment.costo_unitario,
            lote_codigo=adjustment.lote_codigo,
            fecha_vencimiento=adjustment.fecha_vencimiento
        )
    elif adjustment.cantidad < 0:
        services.InventoryService.consume_stock(
            db,
            adjustment.producto_id,
            adjustment.bodega_id,
            abs(adjustment.cantidad),
            adjustment.tipo_movimiento,
            current_company.id,
            lote_id=adjustment.lote_id
        )
    else:
        return {"message": "No change"}
    
    db.commit()
    return {"message": "Stock adjusted successfully"}

@router.get("/lotes/{producto_id}", response_model=List[schemas.InventarioLoteRead])
def read_lotes(
    producto_id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return (
        db.query(models.InventarioLote)
        .join(Bodega)
        .join(Sucursal)
        .filter(
            models.InventarioLote.producto_id == producto_id,
            Sucursal.empresa_id == current_company.id
        )
        .all()
    )
