from datetime import datetime
from typing import Any

from sqlalchemy import (
    Column,
    Integer,
    String,
    ForeignKey,
    DateTime,
    Enum as SAEnum,
    UniqueConstraint,
    text,
    event,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship, Mapped, mapped_column, backref, Session
from sqlalchemy.sql import func
from app.core.database import Base, GUID
from uuid import UUID
import uuid6
import enum

class EstadoLoteEnum(str, enum.Enum):
    DISPONIBLE = "DISPONIBLE"
    BLOQUEADO = "BLOQUEADO"
    VENCIDO = "VENCIDO"

class ProductVariant(Base):
    __tablename__ = "product_variants"
    __table_args__ = (
        UniqueConstraint("producto_id", "hash_identity", name="uq_product_variant_producto_hash"),
    )

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False, index=True)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id", ondelete="CASCADE"), nullable=False, index=True)

    hash_identity: Mapped[str] = mapped_column(String, nullable=False, index=True)
    attributes: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
    )
    sku_variant: Mapped[str | None] = mapped_column(String, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now(), nullable=False)

    producto = relationship("app.core_modules.ventas.models.Producto", backref=backref("variants", cascade="all, delete-orphan"))

class Inventario(Base):
    __tablename__ = "inventario"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False, index=True)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id", ondelete="CASCADE"), nullable=False, index=True)
    variant_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("product_variants.id", ondelete="CASCADE"), nullable=False, index=True)
    bodega_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("bodegas.id", ondelete="CASCADE"), nullable=False, index=True)

    cantidad: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cantidad_reservada: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    stock_minimo: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
    additional_attributes: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
    )
    updated_at = Column(
        DateTime(timezone=True), onupdate=func.now(), server_default=func.now()
    )

    # Relaciones
    # Usamos string path completo para evitar importaciones circulares y asegurar resolución
    producto = relationship(
        "app.core_modules.ventas.models.Producto",
        backref=backref("inventario_bodegas", cascade="all, delete-orphan")
    )
    variant = relationship("app.core_modules.inventario.stock.models.ProductVariant", backref=backref("inventarios", cascade="all, delete-orphan"))
    bodega = relationship(
        "app.core_modules.sistema.models.Bodega",
        backref=backref("inventario_stock", cascade="all, delete-orphan")
    )

class InventarioUbicacion(Base):
    __tablename__ = "inventario_ubicacion"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id", ondelete="CASCADE"), nullable=False, index=True)
    ubicacion_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("ubicaciones.id", ondelete="CASCADE"), nullable=False, index=True
    )
    cantidad: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    updated_at = Column(
        DateTime(timezone=True), onupdate=func.now(), server_default=func.now()
    )

    producto = relationship("app.core_modules.ventas.models.Producto")
    ubicacion = relationship("app.core_modules.sistema.models.Ubicacion")

class InventarioLote(Base):
    __tablename__ = "inventario_lotes"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id", ondelete="CASCADE"), nullable=False, index=True)
    bodega_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("bodegas.id", ondelete="CASCADE"), nullable=False, index=True)
    
    lote_codigo: Mapped[str] = mapped_column(String, index=True, nullable=False)
    fecha_entrada: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    fecha_vencimiento: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    
    cantidad: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    additional_attributes: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
    )
    
    estado: Mapped[EstadoLoteEnum] = mapped_column(
        SAEnum(EstadoLoteEnum), default=EstadoLoteEnum.DISPONIBLE, nullable=False
    )
    
    # Metadata
    created_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), onupdate=func.now()
    )

    # Relaciones
    producto = relationship("app.core_modules.ventas.models.Producto", backref="lotes")
    bodega = relationship("app.core_modules.sistema.models.Bodega", backref="lotes")


@event.listens_for(Session, "before_flush")
def _ensure_default_variant_id(
    session: Session, flush_context: object, instances: object
) -> None:
    for obj in session.new:
        if not isinstance(obj, Inventario):
            continue
        if getattr(obj, "variant_id", None) is not None:
            continue
        if getattr(obj, "producto_id", None) is None:
            continue

        from app.core_modules.inventario.stock.services.variants import hash_identity
        from app.core_modules.ventas.models import Producto

        hid = hash_identity({})
        existing = (
            session.query(ProductVariant)
            .filter(
                ProductVariant.producto_id == obj.producto_id,
                ProductVariant.hash_identity == hid,
            )
            .first()
        )
        if existing is not None:
            obj.variant_id = existing.id
            continue

        producto = session.query(Producto).filter(Producto.id == obj.producto_id).first()
        if producto is None:
            continue

        variant = ProductVariant(
            id=uuid6.uuid7(),
            empresa_id=producto.empresa_id,
            producto_id=obj.producto_id,
            hash_identity=hid,
            attributes={},
            sku_variant=None,
        )
        session.add(variant)
        obj.variant_id = variant.id
