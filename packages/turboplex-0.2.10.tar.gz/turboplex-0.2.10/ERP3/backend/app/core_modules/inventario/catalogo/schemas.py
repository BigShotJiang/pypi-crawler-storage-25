from typing import Optional, List, Any
from pydantic import BaseModel, ConfigDict, field_validator
import math
from uuid import UUID

class ProductoBase(BaseModel):
    nombre: Optional[str] = None
    sku: Optional[str] = None
    descripcion: Optional[str] = None
    precio: float = 0.0  # Cambiado a float directo con default
    costo_promedio: float = 0.0
    tipo_producto: Optional[str] = "ALMACENABLE"
    is_active: Optional[bool] = True
    es_trazable: Optional[bool] = False

    # CAMBIO CLAVE: Cambiar "forbid" a "ignore" para evitar el error 422
    # si el Acer envía campos extra como 'created_at'.
    model_config = ConfigDict(from_attributes=True, extra="ignore")

    @field_validator("precio", "costo_promedio", mode="before")
    @classmethod
    def round_decimals(cls, v: Any) -> float: # Forzamos que devuelva float
        try:
            if v is None:
                return 0.0
            
            # Convertir a float si es string o decimal
            val = float(v)
            
            # Si el resultado es NaN o Infinito, limpiar a 0.0
            if math.isnan(val) or math.isinf(val):
                return 0.0
                
            return round(val, 2)
        except (ValueError, TypeError):
            return 0.0

class ProductoCreate(ProductoBase):
    nombre: str
    sku: str
    # Eliminamos la repetición para que use la lógica de la base

class ProductoUpdate(ProductoBase):
    # Permitimos que todo sea opcional en el update pero con la validación de arriba
    nombre: Optional[str] = None
    sku: Optional[str] = None

class ProductoRead(ProductoBase):
    id: UUID
    empresa_id: UUID

class ProductoList(BaseModel):
    data: List[ProductoRead]
    total: int
