from __future__ import annotations

import logging
from datetime import datetime, timedelta
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.inventario.stock.models import EstadoLoteEnum, InventarioLote
from app.core_modules.sistema.models import Bodega, Sucursal

logger = logging.getLogger(__name__)


def check_expirations(db: Session, empresa_id: UUID) -> list[dict[str, object]]:
    hoy = datetime.now()
    limite_alerta = hoy + timedelta(days=180)

    expired_lots = (
        db.query(InventarioLote)
        .join(Bodega)
        .join(Sucursal)
        .filter(
            Sucursal.empresa_id == empresa_id,
            InventarioLote.estado != EstadoLoteEnum.VENCIDO,
            InventarioLote.fecha_vencimiento < hoy,
        )
        .with_for_update()
        .all()
    )
    for lote in expired_lots:
        lote.estado = EstadoLoteEnum.VENCIDO
        db.add(lote)

    db.commit()

    expiring_soon = (
        db.query(InventarioLote)
        .join(Bodega)
        .join(Sucursal)
        .filter(
            Sucursal.empresa_id == empresa_id,
            InventarioLote.estado == EstadoLoteEnum.DISPONIBLE,
            InventarioLote.fecha_vencimiento <= limite_alerta,
            InventarioLote.fecha_vencimiento >= hoy,
        )
        .all()
    )

    alerts: list[dict[str, object]] = []
    for lote in expiring_soon:
        days_left = (
            (lote.fecha_vencimiento.replace(tzinfo=None) - hoy).days
            if lote.fecha_vencimiento
            else 0
        )
        alerts.append(
            {
                "lote_id": str(lote.id),
                "lote_codigo": lote.lote_codigo,
                "producto_id": str(lote.producto_id),
                "bodega_id": str(lote.bodega_id),
                "fecha_vencimiento": lote.fecha_vencimiento.isoformat() if lote.fecha_vencimiento else None,
                "dias_restantes": days_left,
            }
        )
    return alerts
