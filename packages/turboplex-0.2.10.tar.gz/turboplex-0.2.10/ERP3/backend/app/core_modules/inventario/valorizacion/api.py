from typing import Any
from uuid import UUID
from decimal import Decimal
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.api import deps
from app.core_modules.inventario.valorizacion.services import ValuationService
from app.core_modules.inventario.valorizacion.models import HistorialCosto
from app.core_modules.sistema.models import Empresa, Bodega, Sucursal

router = APIRouter()

@router.get("/total")
def get_total_valuation(
    bodega_id: UUID = Query(None),
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    service = ValuationService(db)
    # Filter by company?
    # get_valor_total_bodega doesn't filter by company internally, it relies on bodega_id.
    # If bodega_id is None, it sums ALL inventory in DB (bad for multi-tenant).
    # I should update get_valor_total_bodega to accept company_id or filter by company.
    # Or I filter bodegas by company first.
    
    # Correct approach:
    # 1. Get bodegas of company
    bodegas = db.query(Bodega).join(Sucursal).filter(Sucursal.empresa_id == current_company.id).all()
    bodega_ids = [b.id for b in bodegas]
    
    if bodega_id:
        if bodega_id not in bodega_ids:
             return {"total_value": 0} # Or error
        return {"total_value": service.get_valor_total_bodega(str(bodega_id))}
    
    total = Decimal(0)
    for bid in bodega_ids:
        total += service.get_valor_total_bodega(str(bid))
        
    return {"total_value": total}

@router.get("/history/{producto_id}")
def get_cost_history(
    producto_id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    # Verify product belongs to company
    # ...
    return db.query(HistorialCosto).filter(HistorialCosto.producto_id == producto_id).order_by(HistorialCosto.fecha_registro.desc()).all()
