from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.inventario.stock.services import certification
from app.core_modules.inventario.stock.services.backorders import get_bodega_default, process_backorders
from app.core_modules.inventario.stock.services.company_stock import get_stock_for_company, get_stock_summary
from app.core_modules.inventario.stock.services.expirations import check_expirations
from app.core_modules.inventario.stock.services.stock_ops import (
    check_stock,
    consume_reserved_stock,
    consume_stock,
    release_reservation,
    release_stock,
    reserve_stock,
)
from app.core_modules.sistema.models import Bodega


class InventoryService:
    @staticmethod
    def get_bodega_default(db: Session, sucursal_id: UUID) -> Bodega:
        return get_bodega_default(db, sucursal_id)

    @staticmethod
    def get_stock_for_company(db: Session, empresa_id: UUID, sucursal_id: Optional[UUID] = None) -> dict[UUID, Decimal]:
        return get_stock_for_company(db, empresa_id, sucursal_id)

    @staticmethod
    def get_stock_summary(db: Session, producto_id: UUID, empresa_id: UUID) -> Decimal:
        return get_stock_summary(db, producto_id, empresa_id)

    @staticmethod
    def validate_certification(db: Session, producto_id: UUID) -> None:
        certification.validate_certification(db, producto_id)
        return None

    @staticmethod
    def check_stock(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad_requerida: int,
        *,
        empresa_id: UUID,
        variant_id: UUID | None = None,
        attributes: dict[str, object] | None = None,
    ) -> bool:
        return check_stock(
            db,
            producto_id,
            bodega_id,
            cantidad_requerida,
            empresa_id=empresa_id,
            variant_id=variant_id,
            attributes=None if attributes is None else dict(attributes),
        )

    @staticmethod
    def reserve_stock(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad: int,
        *,
        empresa_id: UUID,
        variant_id: UUID | None = None,
        attributes: dict[str, object] | None = None,
    ) -> None:
        reserve_stock(
            db,
            producto_id,
            bodega_id,
            cantidad,
            empresa_id=empresa_id,
            variant_id=variant_id,
            attributes=None if attributes is None else dict(attributes),
        )
        return None

    @staticmethod
    def release_reservation(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad: int,
        *,
        empresa_id: UUID,
        variant_id: UUID | None = None,
        attributes: dict[str, object] | None = None,
    ) -> None:
        release_reservation(
            db,
            producto_id,
            bodega_id,
            cantidad,
            empresa_id=empresa_id,
            variant_id=variant_id,
            attributes=None if attributes is None else dict(attributes),
        )
        return None

    @staticmethod
    def consume_reserved_stock(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad: int,
        tipo_movimiento: str,
        empresa_id: UUID,
    ) -> None:
        consume_reserved_stock(
            db,
            producto_id,
            bodega_id,
            cantidad,
            tipo_movimiento,
            empresa_id,
        )
        return None

    @staticmethod
    def consume_stock(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad: int,
        tipo_movimiento: str,
        empresa_id: UUID,
        reference_id: Optional[str] = None,
        lote_id: UUID | str | None = None,
        *,
        variant_id: UUID | None = None,
        attributes: dict[str, object] | None = None,
        import_run_id: UUID | None = None,
        additional_attributes: dict[str, object] | None = None,
    ) -> None:
        from app.core_modules.finanzas.accounting_service.periods import check_periodo_abierto

        check_periodo_abierto(db, empresa_id, datetime.now())
        consume_stock(
            db,
            producto_id,
            bodega_id,
            cantidad,
            tipo_movimiento,
            empresa_id,
            reference_id,
            lote_id,
            variant_id=variant_id,
            attributes=None if attributes is None else dict(attributes),
            import_run_id=import_run_id,
            additional_attributes=None if additional_attributes is None else dict(additional_attributes),
        )
        return None

    @staticmethod
    def release_stock(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad: int,
        tipo_movimiento: str,
        empresa_id: UUID,
        costo_unitario: Optional[Decimal] = None,
        lote_codigo: Optional[str] = None,
        fecha_vencimiento: Optional[datetime] = None,
        *,
        variant_id: UUID | None = None,
        attributes: dict[str, object] | None = None,
        import_run_id: UUID | None = None,
        additional_attributes: dict[str, object] | None = None,
    ) -> None:
        release_stock(
            db,
            producto_id,
            bodega_id,
            cantidad,
            tipo_movimiento,
            empresa_id,
            costo_unitario=costo_unitario,
            lote_codigo=lote_codigo,
            fecha_vencimiento=fecha_vencimiento,
            variant_id=variant_id,
            attributes=None if attributes is None else dict(attributes),
            import_run_id=import_run_id,
            additional_attributes=None if additional_attributes is None else dict(additional_attributes),
        )
        return None

    @staticmethod
    def add_stock(
        db: Session,
        producto_id: UUID,
        bodega_id: UUID,
        cantidad: int,
        tipo_movimiento: str,
        empresa_id: UUID,
        costo_unitario: Optional[Decimal] = None,
        lote_codigo: Optional[str] = None,
        fecha_vencimiento: Optional[datetime] = None,
    ) -> int:
        from app.core.exceptions import BusinessRuleError
        from app.core_modules.finanzas.accounting_service.periods import check_periodo_abierto
        from app.core_modules.ventas.models import Producto

        check_periodo_abierto(db, empresa_id, datetime.now())
        producto = db.query(Producto).filter(Producto.id == producto_id).first()
        if producto and producto.es_trazable:
            if not lote_codigo or not fecha_vencimiento:
                raise BusinessRuleError(
                    f"El producto '{producto.nombre}' es trazable. Debe especificar Lote y Fecha de Vencimiento."
                )

        with db.begin_nested():
            release_stock(
                db,
                producto_id,
                bodega_id,
                cantidad,
                tipo_movimiento,
                empresa_id,
                costo_unitario=costo_unitario,
                lote_codigo=lote_codigo,
                fecha_vencimiento=fecha_vencimiento,
            )
            reactivated = InventoryService.process_backorders(
                db, producto_id, bodega_id, empresa_id
            )
            return reactivated

    @staticmethod
    def process_backorders(db: Session, producto_id: UUID, bodega_id: UUID, empresa_id: UUID) -> int:
        return process_backorders(db, producto_id, bodega_id, empresa_id)

    @staticmethod
    def check_expirations(db: Session, empresa_id: UUID) -> list[dict[str, object]]:
        return check_expirations(db, empresa_id)
