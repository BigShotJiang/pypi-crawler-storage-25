from fastapi import APIRouter
from app.core_modules.inventario.catalogo import api as catalogo
from app.core_modules.inventario.stock import api as stock
from app.core_modules.inventario.movimientos import api as movimientos
from app.core_modules.inventario.valorizacion import api as valorizacion

router = APIRouter()

router.include_router(catalogo.router, prefix="/catalogo", tags=["Inventario - Catálogo"])
router.include_router(stock.router, prefix="/stock", tags=["Inventario - Stock"])
router.include_router(movimientos.router, prefix="/movimientos", tags=["Inventario - Movimientos"])
router.include_router(valorizacion.router, prefix="/valorizacion", tags=["Inventario - Valorización"])
