import json
from typing import Any, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from decimal import Decimal
from uuid import UUID
from datetime import datetime

class StockAdjustmentCreate(BaseModel):
    producto_id: UUID
    bodega_id: UUID
    cantidad: int
    tipo_movimiento: str  # ENTRADA, SALIDA, COMPRA, VENTA, MERMA, etc.
    costo_unitario: Optional[Decimal] = None
    lote_codigo: Optional[str] = None
    fecha_vencimiento: Optional[datetime] = None
    lote_id: Optional[UUID] = None  # For specific lot consumption
    observacion: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")

class StockRead(BaseModel):
    id: UUID
    sku: Optional[str] = None
    producto_id: UUID
    variant_id: UUID
    bodega_id: UUID
    cantidad: int
    cantidad_reservada: int
    stock_minimo: int
    producto_nombre: Optional[str] = None
    bodega_nombre: Optional[str] = None
    additional_attributes: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(from_attributes=True, extra="ignore")

class InventarioLoteRead(BaseModel):
    id: UUID
    lote_codigo: str
    fecha_vencimiento: Optional[datetime]
    estado: str
    cantidad: int
    bodega_id: UUID

    model_config = ConfigDict(from_attributes=True, extra="ignore")

class BodegaRead(BaseModel):
    id: UUID
    nombre: str
    codigo: Optional[str] = None
    codigo_externo: Optional[str] = None
    sucursal_id: UUID

    model_config = ConfigDict(from_attributes=True, extra="ignore")


class DynamicStockAdjustResponse(BaseModel):
    import_run_id: str
    staging_key: str
    file_hash: str
    rows_total: int
    movements_created: int
    stock_updates: int
    failed_rows: int
    template_id: str | None = None
    template_action: str | None = None

    model_config = ConfigDict(extra="forbid")


class ImportTemplateRead(BaseModel):
    id: UUID
    nombre: str
    tipo_importacion: str
    mapping_json: dict[str, Any] | None = None

    model_config = ConfigDict(from_attributes=True, extra="ignore")

    @field_validator("mapping_json", mode="before")
    @classmethod
    def _coerce_mapping_json(cls, v: Any) -> dict[str, Any] | None:
        if v is None:
            return None
        raw: Any = v
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except Exception:
                return None
        if not isinstance(raw, dict):
            return None
        if isinstance(raw.get("base"), dict):
            base = dict(raw.get("base") or {})
            rest = {k: vv for k, vv in raw.items() if k != "base"}
            raw = {**base, **rest}
        if raw.get("additional_attributes") is None:
            meta = raw.get("metadata")
            if isinstance(meta, dict) and isinstance(meta.get("additional_attributes"), dict):
                raw["additional_attributes"] = meta.get("additional_attributes")
            else:
                raw["additional_attributes"] = {}
        if not isinstance(raw.get("additional_attributes"), dict):
            raw["additional_attributes"] = {}
        return raw


class StockAdjustMappingJson(BaseModel):
    sku: str
    cantidad: str
    bodega_codigo: str | None = None
    bodega: str | None = None
    costo_unitario: str | None = None
    costo: str | None = None
    additional_attributes: dict[str, str] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _normalize(cls, v: Any) -> Any:
        if v is None:
            return {"additional_attributes": {}}
        raw: Any = v
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except Exception:
                return {"additional_attributes": {}}
        if not isinstance(raw, dict):
            return {"additional_attributes": {}}
        if isinstance(raw.get("base"), dict):
            base = dict(raw.get("base") or {})
            rest = {k: vv for k, vv in raw.items() if k != "base"}
            raw = {**base, **rest}
        if raw.get("additional_attributes") is None:
            meta = raw.get("metadata")
            if isinstance(meta, dict) and isinstance(meta.get("additional_attributes"), dict):
                raw["additional_attributes"] = meta.get("additional_attributes")
            else:
                raw["additional_attributes"] = {}
        if not isinstance(raw.get("additional_attributes"), dict):
            raw["additional_attributes"] = {}
        if "bodega_codigo" not in raw and "bodega" in raw:
            raw["bodega_codigo"] = raw.get("bodega")
        if "costo_unitario" not in raw and "costo" in raw:
            raw["costo_unitario"] = raw.get("costo")
        return raw
