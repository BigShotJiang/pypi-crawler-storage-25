from app.core_modules.inventario.stock.services.inventory_service import InventoryService

__all__ = ["InventoryService"]
