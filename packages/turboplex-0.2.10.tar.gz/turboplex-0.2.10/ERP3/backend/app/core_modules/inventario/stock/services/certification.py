from __future__ import annotations

import logging
from datetime import date
from uuid import UUID

from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError
from app.core_modules.ventas.models import ProductoCertificacion

logger = logging.getLogger(__name__)


def validate_certification(db: Session, producto_id: UUID) -> None:
    cert = (
        db.query(ProductoCertificacion)
        .filter(ProductoCertificacion.producto_id == producto_id)
        .filter(not ProductoCertificacion.is_deleted)
        .order_by(ProductoCertificacion.fecha_vencimiento.desc())
        .first()
    )
    if cert and cert.fecha_vencimiento < date.today():
        logger.warning(
            "Intento de salida de producto %s con certificación vencida (%s)",
            producto_id,
            cert.fecha_vencimiento,
        )
        raise BusinessRuleError(
            f"BLOQUEO DE CALIDAD: El producto tiene una certificación vencida el {cert.fecha_vencimiento}. Contacte a Calidad."
        )
