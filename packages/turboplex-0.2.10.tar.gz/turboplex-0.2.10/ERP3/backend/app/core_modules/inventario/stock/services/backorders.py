from __future__ import annotations

import logging
from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError
from app.core_modules.crm.models import Notification
from app.core_modules.inventario.stock.services.stock_ops import check_stock, consume_stock, release_stock
from app.core_modules.sistema.models import Bodega
from app.core_modules.ventas.models import (
    DetalleVenta,
    EstadoOrdenServicioEnum,
    EstadoVentaEnum,
    HistorialOrdenServicio,
    Venta,
)

logger = logging.getLogger(__name__)


def get_bodega_default(db: Session, sucursal_id: UUID) -> Bodega:
    from app.core_modules.sistema.models import Bodega as BodegaModel

    bodega = db.query(BodegaModel).filter(BodegaModel.sucursal_id == sucursal_id).first()
    if not bodega:
        from app.core.exceptions import ResourceNotFoundError

        raise ResourceNotFoundError(resource="Bodega", resource_id=f"sucursal_{sucursal_id}")
    return bodega


def add_stock(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad: int,
    tipo_movimiento: str,
    empresa_id: UUID,
    costo_unitario: Optional[Decimal] = None,
    lote_codigo: Optional[str] = None,
    fecha_vencimiento: Optional[datetime] = None,
) -> int:
    from app.core_modules.ventas.models import Producto

    producto = db.query(Producto).filter(Producto.id == producto_id).first()
    if producto and producto.es_trazable:
        if not lote_codigo or not fecha_vencimiento:
            raise BusinessRuleError(
                f"El producto '{producto.nombre}' es trazable. Debe especificar Lote y Fecha de Vencimiento."
            )

    release_stock(
        db,
        producto_id,
        bodega_id,
        cantidad,
        tipo_movimiento,
        empresa_id,
        costo_unitario=costo_unitario,
        lote_codigo=lote_codigo,
        fecha_vencimiento=fecha_vencimiento,
    )

    reactivated = process_backorders(db, producto_id, bodega_id, empresa_id)
    return reactivated


def process_backorders(db: Session, producto_id: UUID, bodega_id: UUID, empresa_id: UUID) -> int:
    ventas_en_espera = (
        db.query(Venta)
        .join(DetalleVenta)
        .filter(
            Venta.estado == EstadoVentaEnum.PENDIENTE_SIN_STOCK,
            Venta.empresa_id == empresa_id,
            DetalleVenta.producto_id == producto_id,
        )
        .order_by(Venta.fecha.asc())
        .all()
    )

    reactivated_count = 0
    for venta in ventas_en_espera:
        can_fulfill = True
        bodega_venta = get_bodega_default(db, venta.sucursal_id)
        if bodega_venta.id != bodega_id:
            continue

        for detalle in venta.detalles:
            if detalle.producto.tipo_producto == "ALMACENABLE":
                if not check_stock(
                    db,
                    detalle.producto_id,
                    bodega_venta.id,
                    detalle.cantidad,
                    empresa_id=empresa_id,
                ):
                    can_fulfill = False
                    break

        if not can_fulfill:
            continue

        for detalle in venta.detalles:
            if detalle.producto.tipo_producto == "ALMACENABLE":
                consume_stock(
                    db,
                    detalle.producto_id,
                    bodega_venta.id,
                    detalle.cantidad,
                    "REASIGNACION_FIFO",
                    empresa_id,
                    variant_id=None,
                    attributes=None,
                )

        venta.estado = EstadoVentaEnum.PENDIENTE
        if venta.orden_servicio:
            venta.orden_servicio.estado = EstadoOrdenServicioEnum.RESERVADO
            historial = HistorialOrdenServicio(
                orden_servicio_id=venta.orden_servicio.id,
                estado_anterior=EstadoOrdenServicioEnum.EN_ESPERA_STOCK,
                estado_nuevo=EstadoOrdenServicioEnum.RESERVADO,
                fecha_cambio=datetime.now(),
                usuario_id=venta.vendedor_id,
                observacion="Stock asignado automáticamente (Motor FIFO)",
            )
            db.add(historial)

        db.add(venta)
        reactivated_count += 1

        try:
            folio_venta = venta.folio or str(venta.id)
            cliente_nombre = venta.cliente.nombre if venta.cliente else "Cliente Desconocido"
            notif_vendedor = Notification(
                usuario_id=venta.vendedor_id,
                mensaje=f"Venta #{folio_venta} - Cliente: {cliente_nombre} - reactivada por asignación FIFO.",
                link_documento=f"/ventas/{venta.id}",
                leido=False,
            )
            db.add(notif_vendedor)

            vendedor = venta.vendedor
            if vendedor and vendedor.supervisor_id:
                notif_jefe = Notification(
                    usuario_id=vendedor.supervisor_id,
                    jefe_id=venta.vendedor_id,
                    mensaje=f"Atención: Venta #{folio_venta} - Cliente: {cliente_nombre} - de {vendedor.email} ha sido reactivada.",
                    link_documento=f"/ventas/{venta.id}",
                    leido=False,
                )
                db.add(notif_jefe)
        except Exception as e:
            logger.error("ERROR NOTIFICACION: %s", e)

    return reactivated_count
