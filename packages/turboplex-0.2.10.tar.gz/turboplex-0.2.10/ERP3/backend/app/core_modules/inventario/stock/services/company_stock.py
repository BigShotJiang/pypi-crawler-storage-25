from __future__ import annotations

from decimal import Decimal
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.inventario.stock.models import Inventario
from app.core_modules.sistema.models import Bodega, Sucursal


def get_stock_for_company(db: Session, empresa_id: UUID, sucursal_id: Optional[UUID] = None) -> dict[UUID, Decimal]:
    query = (
        db.query(
            Inventario.producto_id,
            Inventario.cantidad,
            Inventario.cantidad_reservada,
        )
        .join(Bodega, Inventario.bodega_id == Bodega.id)
        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
        .filter(Sucursal.empresa_id == empresa_id)
    )
    if sucursal_id:
        query = query.filter(Sucursal.id == sucursal_id)

    rows = query.all()
    stock_map: dict[UUID, Decimal] = {}
    for r in rows:
        disponible = Decimal(r.cantidad) - Decimal(r.cantidad_reservada)
        stock_map[r.producto_id] = stock_map.get(r.producto_id, Decimal(0)) + disponible
    return stock_map


def get_stock_summary(db: Session, producto_id: UUID, empresa_id: UUID) -> Decimal:
    rows = (
        db.query(Inventario.cantidad, Inventario.cantidad_reservada)
        .join(Bodega, Inventario.bodega_id == Bodega.id)
        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
        .filter(Sucursal.empresa_id == empresa_id, Inventario.producto_id == producto_id)
        .all()
    )
    total = Decimal(0)
    for r in rows:
        total += Decimal(r.cantidad) - Decimal(r.cantidad_reservada)
    return total
