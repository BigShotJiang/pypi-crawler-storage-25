from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from decimal import Decimal
from typing import Any, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError, InsufficientStock, ResourceNotFoundError
from app.core.infrastructure.events import event_dispatcher
from app.core_modules.inventario.movimientos.models import MovimientoStock
from app.core_modules.inventario.stock.models import EstadoLoteEnum, Inventario, InventarioLote
from app.core_modules.inventario.stock.services.inventory_rows import list_inventario_rows_fifo
from app.core_modules.inventario.stock.services.variants import resolve_or_create_variant_id

logger = logging.getLogger(__name__)


def _ensure_bodega_in_empresa(db: Session, *, bodega_id: UUID, empresa_id: UUID) -> None:
    from app.core_modules.sistema.models import Bodega as BodegaModel, Sucursal as SucursalModel

    ok = (
        db.query(BodegaModel.id)
        .join(SucursalModel, SucursalModel.id == BodegaModel.sucursal_id)
        .filter(BodegaModel.id == bodega_id, SucursalModel.empresa_id == empresa_id)
        .first()
        is not None
    )
    if not ok:
        raise BusinessRuleError("Bodega no pertenece a la empresa.")


def _resolve_variant_id(
    db: Session,
    *,
    producto_id: UUID,
    empresa_id: UUID,
    variant_id: UUID | None,
    attributes: dict[str, Any] | None,
) -> UUID:
    if variant_id is not None:
        return variant_id
    return resolve_or_create_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        attributes=attributes or {},
    )


def check_stock(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad_requerida: int,
    *,
    empresa_id: UUID,
    variant_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
) -> bool:
    _ensure_bodega_in_empresa(db, bodega_id=bodega_id, empresa_id=empresa_id)
    resolved_variant_id = _resolve_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        variant_id=variant_id,
        attributes=attributes,
    )
    rows = list_inventario_rows_fifo(
        db,
        empresa_id=empresa_id,
        variant_id=resolved_variant_id,
        producto_id=producto_id,
        bodega_id=bodega_id,
        for_update=False,
    )
    disponible_total = sum((r.cantidad - r.cantidad_reservada) for r in rows)
    return int(disponible_total) >= int(cantidad_requerida)


def reserve_stock(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad: int,
    *,
    empresa_id: UUID,
    variant_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
) -> None:
    _ensure_bodega_in_empresa(db, bodega_id=bodega_id, empresa_id=empresa_id)
    resolved_variant_id = _resolve_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        variant_id=variant_id,
        attributes=attributes,
    )
    rows = list_inventario_rows_fifo(
        db,
        empresa_id=empresa_id,
        variant_id=resolved_variant_id,
        producto_id=producto_id,
        bodega_id=bodega_id,
        for_update=True,
    )
    if not rows:
        raise ResourceNotFoundError(resource="Inventario", resource_id=f"{producto_id}-{bodega_id}")

    remaining = int(cantidad)
    disponible_total = sum((r.cantidad - r.cantidad_reservada) for r in rows)
    if int(disponible_total) < remaining:
        raise InsufficientStock(
            f"No hay stock suficiente. Disponible: {disponible_total}, Solicitado: {cantidad}"
        )

    for r in rows:
        if remaining <= 0:
            break
        disponible = int(r.cantidad - r.cantidad_reservada)
        if disponible <= 0:
            continue
        take = min(disponible, remaining)
        r.cantidad_reservada += take
        db.add(r)
        remaining -= take


def release_reservation(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad: int,
    *,
    empresa_id: UUID,
    variant_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
) -> None:
    _ensure_bodega_in_empresa(db, bodega_id=bodega_id, empresa_id=empresa_id)
    resolved_variant_id = _resolve_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        variant_id=variant_id,
        attributes=attributes,
    )
    rows = list_inventario_rows_fifo(
        db,
        empresa_id=empresa_id,
        variant_id=resolved_variant_id,
        producto_id=producto_id,
        bodega_id=bodega_id,
        for_update=True,
    )
    remaining = int(cantidad)
    for r in rows:
        if remaining <= 0:
            break
        if r.cantidad_reservada <= 0:
            continue
        take = min(int(r.cantidad_reservada), remaining)
        r.cantidad_reservada -= take
        db.add(r)
        remaining -= take


def consume_reserved_stock(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad: int,
    tipo_movimiento: str,
    empresa_id: UUID,
    *,
    variant_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
    import_run_id: UUID | None = None,
    additional_attributes: dict[str, Any] | None = None,
) -> None:
    _ensure_bodega_in_empresa(db, bodega_id=bodega_id, empresa_id=empresa_id)
    resolved_variant_id = _resolve_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        variant_id=variant_id,
        attributes=attributes,
    )
    rows = list_inventario_rows_fifo(
        db,
        empresa_id=empresa_id,
        variant_id=resolved_variant_id,
        producto_id=producto_id,
        bodega_id=bodega_id,
        for_update=True,
    )
    if not rows:
        raise ResourceNotFoundError(resource="Inventario", resource_id=f"{producto_id}-{bodega_id}")

    reserved_total = sum(int(r.cantidad_reservada) for r in rows)
    if reserved_total < int(cantidad):
        logger.warning(
            "Intentando consumir %s de reserva, pero solo hay %s reservados.",
            cantidad,
            reserved_total,
        )

    movimiento = MovimientoStock(
        producto_id=producto_id,
        bodega_id=bodega_id,
        cantidad=-int(cantidad),
        tipo=tipo_movimiento,
        empresa_id=empresa_id,
        import_run_id=import_run_id,
        additional_attributes=additional_attributes or {},
    )
    db.add(movimiento)

    remaining = int(cantidad)
    for r in rows:
        if remaining <= 0:
            break
        if r.cantidad_reservada <= 0:
            continue
        take = min(int(r.cantidad_reservada), remaining)
        r.cantidad -= take
        r.cantidad_reservada -= take
        db.add(r)
        remaining -= take


def consume_stock(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad: int,
    tipo_movimiento: str,
    empresa_id: UUID,
    reference_id: Optional[str] = None,
    lote_id: UUID | str | None = None,
    *,
    variant_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
    import_run_id: UUID | None = None,
    additional_attributes: dict[str, Any] | None = None,
) -> None:
    from app.core_modules.inventario.stock.services.certification import validate_certification

    _ensure_bodega_in_empresa(db, bodega_id=bodega_id, empresa_id=empresa_id)
    validate_certification(db, producto_id)

    from app.core_modules.ventas.models import Producto

    producto = (
        db.query(Producto)
        .filter(Producto.id == producto_id, Producto.empresa_id == empresa_id)
        .first()
    )
    costo_actual = producto.costo_promedio if producto else 0

    resolved_variant_id = _resolve_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        variant_id=variant_id,
        attributes=attributes,
    )
    rows = list_inventario_rows_fifo(
        db,
        empresa_id=empresa_id,
        variant_id=resolved_variant_id,
        producto_id=producto_id,
        bodega_id=bodega_id,
        for_update=True,
    )
    if not rows:
        raise InsufficientStock(
            f"No hay stock suficiente. Producto {producto_id} no existe en bodega {bodega_id}."
        )

    disponible_total = sum((r.cantidad - r.cantidad_reservada) for r in rows)
    if int(disponible_total) < int(cantidad):
        raise InsufficientStock(
            f"No hay stock suficiente. Disponible: {disponible_total}, Solicitado: {cantidad}"
        )

    if producto and producto.es_trazable:
        remaining_qty = int(cantidad)
        used_lots: list[dict[str, Any]] = []

        if lote_id:
            lote_uuid = UUID(lote_id) if isinstance(lote_id, str) else lote_id
            target_lote = (
                db.query(InventarioLote)
                .filter(InventarioLote.id == lote_uuid, InventarioLote.estado == EstadoLoteEnum.DISPONIBLE)
                .with_for_update()
                .first()
            )
            if not target_lote:
                raise BusinessRuleError(f"Lote {lote_id} no encontrado o no disponible.")
            if target_lote.cantidad < remaining_qty:
                raise BusinessRuleError(
                    f"Stock insuficiente en Lote {target_lote.lote_codigo}. Disponible: {target_lote.cantidad}"
                )
            target_lote.cantidad -= remaining_qty
            db.add(target_lote)
            used_lots.append({"lote_id": target_lote.id, "qty": remaining_qty, "costo": costo_actual})
            remaining_qty = 0
        else:
            available_lots = (
                db.query(InventarioLote)
                .filter(
                    InventarioLote.producto_id == producto_id,
                    InventarioLote.bodega_id == bodega_id,
                    InventarioLote.estado == EstadoLoteEnum.DISPONIBLE,
                    InventarioLote.cantidad > 0,
                )
                .order_by(InventarioLote.fecha_vencimiento.asc().nulls_last(), InventarioLote.fecha_entrada.asc())
                .with_for_update()
                .all()
            )
            total_lot_stock = sum(int(lote.cantidad) for lote in available_lots)
            if total_lot_stock < int(cantidad):
                raise BusinessRuleError(
                    f"Inconsistencia: Stock global disponible pero falta stock en lotes. Requerido: {cantidad}, Lotes: {total_lot_stock}"
                )
            for lote in available_lots:
                if remaining_qty <= 0:
                    break
                take = min(int(lote.cantidad), remaining_qty)
                lote.cantidad -= take
                remaining_qty -= take
                db.add(lote)
                used_lots.append({"lote_id": lote.id, "qty": take, "costo": costo_actual})
            if remaining_qty > 0:
                raise BusinessRuleError("Error interno: No se pudo asignar stock de lotes")

        for usage in used_lots:
            movimiento = MovimientoStock(
                producto_id=producto_id,
                bodega_id=bodega_id,
                cantidad=-int(usage["qty"]),
                tipo=tipo_movimiento,
                empresa_id=empresa_id,
                costo_unitario=usage["costo"],
                lote_id=usage["lote_id"],
                import_run_id=import_run_id,
                additional_attributes=additional_attributes or {},
            )
            db.add(movimiento)
            payload = {
                "tipo_movimiento": tipo_movimiento,
                "producto_id": str(producto_id),
                "bodega_id": str(bodega_id),
                "cantidad": -int(usage["qty"]),
                "costo_unitario": float(usage["costo"]) if usage["costo"] else 0.0,
                "empresa_id": str(empresa_id),
                "timestamp": datetime.now().isoformat(),
                "reference_id": reference_id,
                "lote_id": str(usage["lote_id"]) if usage["lote_id"] else None,
            }
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(event_dispatcher.dispatch("EVENT_MOVIMIENTO_STOCK_REGISTRADO", payload))
            except RuntimeError:
                pass

        remaining_to_apply = int(cantidad)
        for r in rows:
            if remaining_to_apply <= 0:
                break
            take = min(int(r.cantidad), remaining_to_apply)
            r.cantidad -= take
            db.add(r)
            remaining_to_apply -= take

        return

    movimiento = MovimientoStock(
        producto_id=producto_id,
        bodega_id=bodega_id,
        cantidad=-int(cantidad),
        tipo=tipo_movimiento,
        empresa_id=empresa_id,
        costo_unitario=costo_actual,
        lote_id=None,
        import_run_id=import_run_id,
        additional_attributes=additional_attributes or {},
    )
    db.add(movimiento)

    payload = {
        "tipo_movimiento": tipo_movimiento,
        "producto_id": str(producto_id),
        "bodega_id": str(bodega_id),
        "cantidad": -int(cantidad),
        "costo_unitario": float(costo_actual) if costo_actual else 0.0,
        "empresa_id": str(empresa_id),
        "timestamp": datetime.now().isoformat(),
        "reference_id": reference_id,
        "lote_id": None,
    }
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(event_dispatcher.dispatch("EVENT_MOVIMIENTO_STOCK_REGISTRADO", payload))
    except RuntimeError:
        pass

    remaining = int(cantidad)
    for r in rows:
        if remaining <= 0:
            break
        disponible = int(r.cantidad - r.cantidad_reservada)
        if disponible <= 0:
            continue
        take = min(disponible, remaining)
        r.cantidad -= take
        db.add(r)
        remaining -= take


def release_stock(
    db: Session,
    producto_id: UUID,
    bodega_id: UUID,
    cantidad: int,
    tipo_movimiento: str,
    empresa_id: UUID,
    costo_unitario: Optional[Decimal] = None,
    lote_codigo: Optional[str] = None,
    fecha_vencimiento: Optional[datetime] = None,
    *,
    variant_id: UUID | None = None,
    attributes: dict[str, Any] | None = None,
    import_run_id: UUID | None = None,
    additional_attributes: dict[str, Any] | None = None,
) -> None:
    from app.core_modules.ventas.models import Producto

    _ensure_bodega_in_empresa(db, bodega_id=bodega_id, empresa_id=empresa_id)
    producto = (
        db.query(Producto)
        .filter(Producto.id == producto_id, Producto.empresa_id == empresa_id)
        .first()
    )
    if producto and producto.tipo_producto == "SERVICIO":
        raise BusinessRuleError("No se puede almacenar un servicio")

    resolved_variant_id = _resolve_variant_id(
        db,
        producto_id=producto_id,
        empresa_id=empresa_id,
        variant_id=variant_id,
        attributes=attributes,
    )
    inventario = (
        db.query(Inventario)
        .filter(
            Inventario.empresa_id == empresa_id,
            Inventario.variant_id == resolved_variant_id,
            Inventario.bodega_id == bodega_id,
        )
        .with_for_update()
        .first()
    )
    if inventario is None:
        inventario = Inventario(
            empresa_id=empresa_id,
            producto_id=producto_id,
            variant_id=resolved_variant_id,
            bodega_id=bodega_id,
            cantidad=0,
            cantidad_reservada=0,
            stock_minimo=10,
            additional_attributes=additional_attributes or attributes or {},
        )
        db.add(inventario)
        db.flush()

    used_lote_id = None
    if lote_codigo:
        lote = (
            db.query(InventarioLote)
            .filter(
                InventarioLote.producto_id == producto_id,
                InventarioLote.bodega_id == bodega_id,
                InventarioLote.lote_codigo == lote_codigo,
            )
            .with_for_update()
            .first()
        )
        if lote is None:
            lote = InventarioLote(
                producto_id=producto_id,
                bodega_id=bodega_id,
                lote_codigo=lote_codigo,
                fecha_vencimiento=fecha_vencimiento,
                cantidad=0,
                estado=EstadoLoteEnum.DISPONIBLE,
            )
            db.add(lote)
            db.flush()
        else:
            if fecha_vencimiento:
                lote.fecha_vencimiento = fecha_vencimiento
        lote.cantidad += int(cantidad)
        used_lote_id = lote.id
        db.add(lote)

    movimiento = MovimientoStock(
        producto_id=producto_id,
        bodega_id=bodega_id,
        cantidad=int(cantidad),
        tipo=tipo_movimiento,
        empresa_id=empresa_id,
        costo_unitario=costo_unitario,
        lote_id=used_lote_id,
        import_run_id=import_run_id,
        additional_attributes=additional_attributes or {},
    )
    db.add(movimiento)

    inventario.cantidad += int(cantidad)
    db.add(inventario)
    db.flush()

    if costo_unitario is not None and int(cantidad) > 0:
        from app.core_modules.inventario.valorizacion.services import ValuationService

        val_service = ValuationService(db)
        val_service.procesar_movimiento(movimiento)

    payload = {
        "tipo_movimiento": tipo_movimiento,
        "producto_id": str(producto_id),
        "bodega_id": str(bodega_id),
        "cantidad": int(cantidad),
        "costo_unitario": float(costo_unitario) if costo_unitario else 0.0,
        "empresa_id": str(empresa_id),
        "timestamp": datetime.now().isoformat(),
    }
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(event_dispatcher.dispatch("EVENT_MOVIMIENTO_STOCK_REGISTRADO", payload))
    except RuntimeError:
        pass
