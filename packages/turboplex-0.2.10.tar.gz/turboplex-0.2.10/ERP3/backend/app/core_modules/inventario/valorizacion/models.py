from sqlalchemy import Column, String, ForeignKey, DateTime, Numeric
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.sql import func
from app.core.database import Base, GUID
from uuid import UUID
import uuid6

class HistorialCosto(Base):
    """
    Registro de la evolución del Precio Medio Ponderado (PMP).
    Fundamental para auditoría de valorización de inventario.
    """
    __tablename__ = "historial_costos"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    
    producto_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("productos.id", ondelete="CASCADE"), nullable=False, index=True
    )
    
    costo_anterior = Column(Numeric(14, 4), nullable=False)
    costo_nuevo = Column(Numeric(14, 4), nullable=False)
    
    movimiento_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("movimientos_stock.id", ondelete="SET NULL"), nullable=True, index=True
    )
    
    tipo_movimiento = Column(String, nullable=True) # Para auditoría rápida sin join
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relaciones
    producto = relationship("app.core_modules.ventas.models.Producto", backref="historial_costos")
    movimiento = relationship("app.core_modules.inventario.movimientos.models.MovimientoStock")
