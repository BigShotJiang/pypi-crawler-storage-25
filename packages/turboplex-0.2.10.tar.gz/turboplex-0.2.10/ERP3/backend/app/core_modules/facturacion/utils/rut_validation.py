from itertools import cycle
import re


def clean_rut(rut: str) -> str:
    """Elimina puntos y guiones del RUT y lo convierte a mayúsculas."""
    if not rut:
        return ""
    return rut.replace(".", "").replace("-", "").upper()


def format_rut(rut: str) -> str:
    """Formatea un RUT limpio o sucio a formato 12.345.678-K."""
    rut = clean_rut(rut)
    if not rut or len(rut) < 2:
        return rut

    dv = rut[-1]
    cuerpo = rut[:-1]

    # Formatear cuerpo con puntos
    cuerpo_fmt = "{:,}".format(int(cuerpo)).replace(",", ".")
    return f"{cuerpo_fmt}-{dv}"


def validate_rut(rut: str) -> bool:
    """
    Valida un RUT chileno usando el algoritmo de módulo 11.
    Acepta RUT con o sin puntos, pero requiere guión.
    """
    if not rut:
        return False
    raw = re.sub(r"\s+", "", rut)
    if not re.match(r"^\d[\d.]*-[\dkK]$", raw):
        return False
    rut = clean_rut(rut)
    if not rut or len(rut) < 2:
        return False

    cuerpo = rut[:-1]
    dv = rut[-1]

    # Validar que el cuerpo sea numérico
    if not cuerpo.isdigit():
        return False

    # Calcular DV esperado
    reversed_digits = map(int, reversed(cuerpo))
    factors = cycle(range(2, 8))
    s = sum(d * f for d, f in zip(reversed_digits, factors))
    mod = 11 - (s % 11)

    if mod == 11:
        expected_dv = "0"
    elif mod == 10:
        expected_dv = "K"
    else:
        expected_dv = str(mod)

    return dv == expected_dv
