from sqlalchemy import (
    Column,
    Integer,
    String,
    ForeignKey,
    Numeric,
    DateTime,
    Date,
    Text,
    Index,
    LargeBinary,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship, Mapped
from datetime import date, datetime
from app.core.database import Base, GUID
from uuid import UUID
import uuid6

# =================================================================
# GESTIÓN DE FOLIOS (CAF)
# =================================================================


class FolioSII(Base):
    """
    Almacena los rangos de folios autorizados por el SII (CAF).
    Se cargan desde archivos XML proporcionados por el usuario.
    """

    __tablename__ = "folios_sii"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    tipo_dte = Column(Integer, nullable=False)  # 33, 39, 52, 61, etc.
    desde = Column(Integer, nullable=False)
    hasta = Column(Integer, nullable=False)
    fecha_autorizacion = Column(Date, nullable=False)

    # Archivo CAF
    archivo_xml = Column(
        Text, nullable=False
    )  # Contenido XML del CAF (Base64 o Raw Text)
    nombre_archivo = Column(String(255), nullable=True)

    # Estado y Uso
    estado = Column(String(20), default="ACTIVO")  # ACTIVO, AGOTADO, VENCIDO
    ultimo_folio_usado = Column(Integer, default=0)
    alerta_stock = Column(Integer, default=50)  # Alerta cuando queden X folios

    # Auditoría de Carga
    usuario_carga_id = Column(GUID, ForeignKey("usuarios.id"), nullable=False)
    fecha_carga = Column(DateTime(timezone=True), default=datetime.now)

    # Relaciones
    # Usar strings literales para evitar dependencias circulares y problemas de orden de carga
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="folios_sii"
    )
    usuario_carga = relationship("app.core_modules.sistema.models.Usuario")

    __table_args__ = (Index("ix_folio_empresa_tipo", "empresa_id", "tipo_dte"),)


# =================================================================
# DOCUMENTOS TRIBUTARIOS ELECTRÓNICOS (DTE)
# =================================================================


class DocumentoTributario(Base):
    """
    Modelo unificado para TODOS los Documentos Tributarios Electrónicos chilenos.
    """

    __tablename__ = "documentos_tributarios"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    tipo_dte = Column(Integer, nullable=False, index=True)  # 33, 34, 39, 52, 56, 61
    folio = Column(Integer, nullable=False, index=True)

    # ============ Fechas ============
    fecha_emision = Column(Date, nullable=False, default=date.today)
    fecha_vencimiento = Column(Date, nullable=True)

    # ============ Receptor (Cliente) ============
    receptor_rut = Column(String(12), nullable=True, index=True)
    receptor_razon_social = Column(String(255), nullable=True)
    receptor_giro = Column(String(100), nullable=True)
    receptor_direccion = Column(String(255), nullable=True)
    receptor_comuna = Column(String(50), nullable=True)
    receptor_ciudad = Column(String(50), nullable=True)

    # ============ Montos ============
    monto_neto = Column(Numeric(12, 2), nullable=False, default=0)
    monto_exento = Column(Numeric(12, 2), nullable=False, default=0)
    monto_iva = Column(Numeric(12, 2), nullable=False, default=0)
    monto_total = Column(Numeric(12, 2), nullable=False)

    # ============ Referencias (para NC y ND) ============
    referencia_tipo_dte = Column(Integer, nullable=True)
    referencia_folio = Column(Integer, nullable=True)
    referencia_fecha = Column(Date, nullable=True)
    referencia_razon = Column(String(255), nullable=True)

    # ============ Estado SII ============
    estado_sii = Column(String(20), nullable=False, default="PENDIENTE")
    # Estados: PENDIENTE, ENVIADO, ACEPTADO, RECHAZADO, ANULADO
    fecha_envio_sii = Column(DateTime, nullable=True)
    track_id_sii = Column(String(50), nullable=True)
    fecha_respuesta_sii = Column(DateTime, nullable=True)
    glosa_rechazo_sii = Column(Text, nullable=True)

    # ============ Documentos Digitales ============
    xml_firmado = Column(Text, nullable=True)
    pdf_cedible = Column(LargeBinary, nullable=True)

    # ============ Referencias Internas ============
    cliente_id = Column(GUID, ForeignKey("clientes.id"), nullable=True)
    venta_id = Column(GUID, ForeignKey("ventas.id"), nullable=True)

    # ============ Auditoría ============
    usuario_emisor_id = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    fecha_creacion = Column(DateTime(timezone=True), default=datetime.now)
    notas_internas = Column(Text, nullable=True)

    # ============ Relaciones ============
    empresa = relationship("app.core_modules.sistema.models.Empresa", backref="dtes")
    cliente = relationship("app.core_modules.ventas.models.Cliente")
    venta = relationship("app.core_modules.ventas.models.Venta")
    usuario_emisor = relationship("app.core_modules.sistema.models.Usuario")
    detalles = relationship(
        "DocumentoTributarioDetalle", backref="dte", cascade="all, delete-orphan"
    )

    __table_args__ = (
        UniqueConstraint(
            "empresa_id", "tipo_dte", "folio", name="uq_dte_empresa_tipo_folio"
        ),
    )


class DocumentoTributarioDetalle(Base):
    __tablename__ = "documentos_tributarios_detalles"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    dte_id = Column(
        GUID, ForeignKey("documentos_tributarios.id"), nullable=False, index=True
    )

    numero_linea = Column(Integer, nullable=False)
    tipo_codigo = Column(String(10), default="INT1")
    codigo_item = Column(String(50), nullable=True)
    nombre_item = Column(String(250), nullable=False)
    descripcion_item = Column(Text, nullable=True)

    cantidad = Column(Numeric(12, 4), nullable=False)
    unidad_medida = Column(String(10), default="UNID")
    precio_unitario = Column(Numeric(12, 2), nullable=False)
    pct_descuento = Column(Numeric(5, 2), default=0)
    monto_descuento = Column(Numeric(12, 2), default=0)

    monto_item = Column(Numeric(12, 2), nullable=False)  # Subtotal línea


class DocumentoTributarioDetalleImpuesto(Base):
    __tablename__ = "documentos_tributarios_detalle_impuestos"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    dte_detalle_id: Mapped[UUID] = Column(GUID, ForeignKey("documentos_tributarios_detalles.id"), nullable=False, index=True)
    codigo_impuesto = Column(String(30), nullable=False)
    tasa_aplicada = Column(Numeric(12, 4), nullable=False)
    base_monto = Column(Numeric(14, 4), nullable=False, default=0)
    monto_impuesto = Column(Numeric(14, 4), nullable=False, default=0)
