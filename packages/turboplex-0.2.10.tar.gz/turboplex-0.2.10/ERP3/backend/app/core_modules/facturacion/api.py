from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from datetime import date
from app.core.database import get_db
from app.core_modules.sistema.models import Usuario, Empresa
from app.core_modules.facturacion.models import FolioSII
from app.core_modules.facturacion.utils.caf_validator import validar_caf
from app.api import deps
import logging

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/facturacion",
    tags=["Facturacion"],
    dependencies=[
        Depends(deps.RoleChecker(["ADMIN", "SUPERADMIN"])),
        Depends(deps.check_module_access("FACTURACION")),
    ],
)


@router.post("/caf/upload", summary="Subir archivo CAF (XML)")
async def upload_caf(
    tipo_dte: int,
    file: UploadFile = File(...),
    current_user: Usuario = Depends(deps.get_current_user),
    db: Session = Depends(get_db),
):
    """
    Sube un archivo CAF (Código de Autorización de Folios) XML.
    Valida:
    1. Formato XML válido.
    2. RUT de la empresa coincide con el CAF.
    3. Tipo de DTE coincide.
    4. Firma digital del CAF (RSASK).
    """

    # 1. Leer contenido
    content = await file.read()
    xml_str = content.decode("ISO-8859-1")  # SII usa esta codificación, a veces UTF-8

    # 2. Obtener empresa del usuario
    empresa = db.query(Empresa).filter(Empresa.id == current_user.empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=400, detail="Usuario no tiene empresa asignada")

    try:
        # 3. Validar CAF
        rango = validar_caf(xml_str, empresa.rut, tipo_dte)

        # 4. Verificar si ya existe un CAF para este rango (evitar duplicados)
        # Opcional: Permitir solapamiento o no. Por seguridad, avisar.
        existe = (
            db.query(FolioSII)
            .filter(
                FolioSII.empresa_id == empresa.id,
                FolioSII.tipo_dte == tipo_dte,
                FolioSII.desde == rango["desde"],
                FolioSII.hasta == rango["hasta"],
            )
            .first()
        )

        if existe:
            raise HTTPException(
                status_code=409, detail="Este archivo CAF ya fue cargado anteriormente"
            )

        # 5. Guardar en Base de Datos
        nuevo_folio = FolioSII(
            empresa_id=empresa.id,
            tipo_dte=tipo_dte,
            desde=rango["desde"],
            hasta=rango["hasta"],
            fecha_autorizacion=date.today(),  # Debería extraerse del CAF (FA) si existe
            archivo_xml=xml_str,  # Guardamos el XML crudo para firmar después
            nombre_archivo=file.filename,
            usuario_carga_id=current_user.id,
            estado="ACTIVO",
            ultimo_folio_usado=rango["desde"] - 1,  # Inicializar antes del primer folio
        )

        db.add(nuevo_folio)
        db.commit()
        db.refresh(nuevo_folio)

        return {
            "message": "CAF cargado exitosamente",
            "rango": rango,
            "folio_id": nuevo_folio.id,
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        # Log error real
        logger.error(f"Error cargando CAF: {e}")
        raise HTTPException(
            status_code=500, detail="Error interno procesando el archivo CAF"
        )


@router.get("/caf", summary="Listar CAFs de la empresa")
def list_cafs(
    tipo_dte: int = None,
    current_user: Usuario = Depends(deps.get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(FolioSII).filter(FolioSII.empresa_id == current_user.empresa_id)

    if tipo_dte:
        query = query.filter(FolioSII.tipo_dte == tipo_dte)

    cafs = query.order_by(FolioSII.id.desc()).all()

    return [
        {
            "id": caf.id,
            "tipo_dte": caf.tipo_dte,
            "desde": caf.desde,
            "hasta": caf.hasta,
            "disponibles": caf.hasta - caf.ultimo_folio_usado,
            "estado": caf.estado,
            "fecha_carga": caf.fecha_carga,
            "usuario": caf.usuario_carga.email,
        }
        for caf in cafs
    ]
