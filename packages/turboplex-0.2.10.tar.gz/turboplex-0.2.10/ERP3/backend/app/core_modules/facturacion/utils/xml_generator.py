import lxml.etree as ET
from datetime import datetime
from typing import Optional

from app.core_modules.facturacion.models import (
    DocumentoTributario,
)
from app.core_modules.sistema.models import Empresa
from app.core_modules.facturacion.utils.caf_validator import extraer_datos_caf
from app.core_modules.facturacion.utils.dte_signer import firmar_datos_ted


def _crear_elemento(
    parent: ET.Element, tag: str, text: Optional[str] = None
) -> ET.Element:
    """Helper para crear elementos XML con texto opcional."""
    elem = ET.SubElement(parent, tag)
    if text is not None:
        elem.text = str(text)
    return elem


def generar_ted(dte: DocumentoTributario, empresa: Empresa, caf_xml: str) -> ET.Element:
    """
    Genera el Timbre Electrónico DTE (TED).

    El TED es un XML firmado incrustado en el DTE que contiene los datos clave (DD).
    Se firma con la llave privada del CAF (RSASK).
    """
    try:
        # 1. Extraer datos del CAF usando la utilidad validada
        datos_caf = extraer_datos_caf(caf_xml)
        caf_node = datos_caf["caf_node"]
        rsask_text = datos_caf["rsask_text"]

        # Preparar llave privada PEM
        if "-----BEGIN RSA PRIVATE KEY-----" not in rsask_text:
            pk_pem = f"-----BEGIN RSA PRIVATE KEY-----\n{rsask_text}\n-----END RSA PRIVATE KEY-----"
        else:
            pk_pem = rsask_text

    except Exception as e:
        raise ValueError(f"Error procesando CAF para TED: {e}")

    # 2. Construir Datos del Documento (DD)
    ted = ET.Element("TED", version="1.0")
    dd = ET.SubElement(ted, "DD")

    _crear_elemento(dd, "RE", empresa.rut)
    _crear_elemento(dd, "TD", str(dte.tipo_dte))
    _crear_elemento(dd, "F", str(dte.folio))
    _crear_elemento(dd, "FE", dte.fecha_emision.strftime("%Y-%m-%d"))
    _crear_elemento(dd, "RR", dte.receptor_rut)
    _crear_elemento(dd, "RSR", (dte.receptor_razon_social or "")[:40])
    _crear_elemento(dd, "MNT", str(int(dte.monto_total)))

    # Agregar items resumen (solo el primero para el timbre según norma simplificada)
    if dte.detalles:
        item = dte.detalles[0]
        it1 = ET.SubElement(dd, "IT1")
        _crear_elemento(it1, "Detalle", item.nombre_item[:40])
    else:
        it1 = ET.SubElement(dd, "IT1")
        _crear_elemento(it1, "Detalle", "Sin Detalle")

    # Copiar nodo CAF completo dentro de DD
    dd.append(caf_node)

    # TSTED: Timestamp generación timbre
    _crear_elemento(dd, "TSTED", datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))

    # 3. Firmar el nodo DD (Timbre)
    firma_ted = firmar_datos_ted(dd, pk_pem)

    frmt = _crear_elemento(ted, "FRMT", firma_ted)
    frmt.set("algoritmo", "SHA1withRSA")

    return ted


def generar_xml_dte(
    dte: DocumentoTributario,
    empresa: Empresa,
    caf_xml: Optional[str] = None,
    transporte: Optional[dict] = None,
) -> bytes:
    """
    Genera el XML para un Documento Tributario Electrónico (DTE).

    Args:
        dte: Objeto DocumentoTributario con sus detalles cargados.
        empresa: Objeto Empresa emisora.
        caf_xml: String XML del archivo CAF (Código Autorización Folios). Requerido para timbraje.
        transporte: Diccionario con datos de transporte (solo para Guías de Despacho).
                   Keys: ind_traslado, patente, rut_transportista, rut_chofer, nombre_chofer,
                         dir_dest, cmna_dest, ciudad_dest.

    Returns:
        bytes: XML generado (codificado en ISO-8859-1, estándar SII).
    """

    # Raíz del documento (sin el wrapper <DTE> ni Signature por ahora)
    # ID es obligatorio para la firma: "F{Folio}T{TipoDTE}" es un formato común pero no estricto
    doc_id = f"F{dte.folio}T{dte.tipo_dte}"
    root = ET.Element("Documento", ID=doc_id)

    # =================================================================
    # ENCABEZADO
    # =================================================================
    encabezado = ET.SubElement(root, "Encabezado")

    # Identificación del DTE (IdDoc)
    iddoc = ET.SubElement(encabezado, "IdDoc")
    _crear_elemento(iddoc, "TipoDTE", str(dte.tipo_dte))
    _crear_elemento(iddoc, "Folio", str(dte.folio))
    _crear_elemento(iddoc, "FchEmis", dte.fecha_emision.strftime("%Y-%m-%d"))

    if dte.tipo_dte == 52:  # Guía Despacho
        _crear_elemento(
            iddoc, "TipoDespacho", "2"
        )  # 2: Despacho por cuenta del vendedor a instalaciones del cliente (Default)
        _crear_elemento(
            iddoc,
            "IndTraslado",
            transporte.get("ind_traslado", "1") if transporte else "1",
        )  # 1: Operación constituye venta

    # Emisor
    emisor = ET.SubElement(encabezado, "Emisor")
    _crear_elemento(emisor, "RUTEmisor", empresa.rut)
    _crear_elemento(emisor, "RznSoc", empresa.razon_social[:100])
    _crear_elemento(emisor, "GiroEmis", empresa.giro[:80])
    # _crear_elemento(emisor, "Acteco", str(empresa.acteco_principal)) # Pendiente agregar a modelo Empresa
    _crear_elemento(emisor, "DirOrigen", empresa.direccion[:60])
    _crear_elemento(emisor, "CmnaOrigen", empresa.comuna[:20])
    _crear_elemento(
        emisor,
        "CiudadOrigen",
        empresa.ciudad[:20] if empresa.ciudad else empresa.comuna[:20],
    )

    # Receptor
    receptor = ET.SubElement(encabezado, "Receptor")
    _crear_elemento(receptor, "RUTRecep", dte.receptor_rut)
    _crear_elemento(receptor, "RznSocRecep", dte.receptor_razon_social[:100])
    _crear_elemento(receptor, "GiroRecep", dte.receptor_giro[:40])
    _crear_elemento(receptor, "DirRecep", dte.receptor_direccion[:60])
    _crear_elemento(receptor, "CmnaRecep", dte.receptor_comuna[:20])
    _crear_elemento(receptor, "CiudadRecep", dte.receptor_ciudad[:20])

    # Transporte (Solo Guía)
    if dte.tipo_dte == 52 and transporte:
        transp = ET.SubElement(encabezado, "Transporte")
        _crear_elemento(transp, "Patente", transporte.get("patente"))
        _crear_elemento(transp, "RUTTrans", transporte.get("rut_transportista"))

        chofer = ET.SubElement(transp, "Chofer")
        _crear_elemento(chofer, "RUTChofer", transporte.get("rut_chofer"))
        _crear_elemento(chofer, "NombreChofer", transporte.get("nombre_chofer"))

        _crear_elemento(transp, "DirDest", transporte.get("dir_dest"))
        _crear_elemento(transp, "CmnaDest", transporte.get("cmna_dest"))
        _crear_elemento(transp, "CiudadDest", transporte.get("ciudad_dest"))

    # Totales
    totales = ET.SubElement(encabezado, "Totales")
    if dte.monto_neto > 0:
        _crear_elemento(totales, "MntNeto", str(int(dte.monto_neto)))
    if dte.monto_exento > 0:
        _crear_elemento(totales, "MntExe", str(int(dte.monto_exento)))

    if dte.tipo_dte != 34:  # Exenta no lleva IVA
        _crear_elemento(totales, "TasaIVA", "19")
        _crear_elemento(totales, "IVA", str(int(dte.monto_iva)))

    _crear_elemento(totales, "MntTotal", str(int(dte.monto_total)))

    # =================================================================
    # DETALLES
    # =================================================================
    for i, detalle in enumerate(dte.detalles):
        det = ET.SubElement(root, "Detalle")
        _crear_elemento(det, "NroLinDet", str(i + 1))

        cdg = ET.SubElement(det, "CdgItem")
        _crear_elemento(cdg, "TpoCodigo", detalle.tipo_codigo)
        _crear_elemento(cdg, "VlrCodigo", detalle.codigo_item)

        _crear_elemento(det, "NmbItem", detalle.nombre_item[:80])
        # _crear_elemento(det, "DscItem", detalle.descripcion_item) # Opcional

        _crear_elemento(det, "QtyItem", f"{detalle.cantidad:.4f}")
        _crear_elemento(det, "UnmdItem", detalle.unidad_medida[:4])
        _crear_elemento(det, "PrcItem", f"{detalle.precio_unitario:.2f}")

        if detalle.monto_descuento > 0:
            _crear_elemento(det, "DescuentoPct", f"{detalle.pct_descuento:.2f}")
            _crear_elemento(det, "DescuentoMonto", str(int(detalle.monto_descuento)))

        _crear_elemento(det, "MontoItem", str(int(detalle.monto_item)))

    # =================================================================
    # REFERENCIAS
    # =================================================================
    if dte.referencia_folio:
        ref = ET.SubElement(root, "Referencia")
        _crear_elemento(ref, "NroLinRef", "1")
        _crear_elemento(ref, "TpoDocRef", str(dte.referencia_tipo_dte))
        _crear_elemento(ref, "FolioRef", str(dte.referencia_folio))
        _crear_elemento(
            ref,
            "FchRef",
            dte.referencia_fecha.strftime("%Y-%m-%d") if dte.referencia_fecha else "",
        )
        _crear_elemento(ref, "RazonRef", dte.referencia_razon or "Referencia Documento")

    # =================================================================
    # TIMBRE ELECTRÓNICO (TED)
    # =================================================================
    if caf_xml:
        ted_element = generar_ted(dte, empresa, caf_xml)
        root.append(ted_element)

    # Retornar XML sin firmar (se firma externamente con firmar_dte)
    # Usamos ISO-8859-1 según norma SII
    return ET.tostring(root, encoding="ISO-8859-1", xml_declaration=False)
