from lxml import etree
from signxml import XMLSigner, methods
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
import base64


def firmar_datos_ted(elemento_xml: object, private_key_pem: str) -> str:
    """
    Firma el contenido de un elemento XML (para TED) usando una llave privada RSA.
    Retorna la firma en Base64.

    Args:
        elemento_xml: Elemento ElementTree o lxml a firmar (DD)
        private_key_pem: Llave privada en formato PEM string
    """
    # 1. Canonicalizar el elemento DD
    # El SII requiere C14N (Canonical XML)
    if not isinstance(elemento_xml, (etree._Element, etree._ElementTree)):
        # Convertir de xml.etree a lxml si es necesario
        # (Asumimos que viene como xml.etree.ElementTree.Element)
        import xml.etree.ElementTree as ET

        xml_str = ET.tostring(elemento_xml, encoding="iso-8859-1")
        elemento_xml = etree.fromstring(xml_str)

    # Canonicalizar
    # Ojo: SII usa ISO-8859-1. La canonicalización suele ser UTF-8.
    # Para el TED, se firma la representación canónica de DD.
    c14n_bytes = etree.tostring(
        elemento_xml, method="c14n", exclusive=False, with_comments=False
    )

    # 2. Cargar llave privada
    private_key = serialization.load_pem_private_key(
        private_key_pem.encode(), password=None, backend=default_backend()
    )

    # 3. Firmar (SHA1withRSA)
    signature = private_key.sign(c14n_bytes, padding.PKCS1v15(), hashes.SHA1())

    # 4. Retornar Base64
    return base64.b64encode(signature).decode()


class LegacyXMLSigner(XMLSigner):
    def check_deprecated_methods(self):
        # SII Chile requiere SHA1, ignoramos la advertencia de seguridad
        pass


def firmar_dte(xml_content: bytes, p12_path: str, password: str) -> bytes:
    """
    Firma un documento XML DTE según el estándar SII.

    Args:
        xml_content: Contenido XML del DTE (bytes).
        p12_path: Ruta al archivo .p12 con la firma digital.
        password: Contraseña del archivo .p12.

    Returns:
        XML firmado en bytes.
    """

    # 1. Cargar llave privada y certificado desde P12
    with open(p12_path, "rb") as f:
        p12_data = f.read()

    private_key, certificate, additional_certificates = (
        pkcs12.load_key_and_certificates(
            p12_data, password.encode() if password else None
        )
    )

    # Convertir certificado a PEM string para signxml
    cert_pem = certificate.public_bytes(serialization.Encoding.PEM).decode()
    key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()

    # 2. Parsear XML
    root = etree.fromstring(xml_content)

    # Obtener el ID del documento para la referencia
    # El estándar SII usa ID en el tag Documento, ej: <Documento ID="F33T33">
    doc_id = root.get("ID")
    if not doc_id:
        raise ValueError("El elemento raíz Documento no tiene atributo ID")

    reference_uri = f"#{doc_id}"

    # 3. Firmar
    # SII usa RSA-SHA1
    signer = LegacyXMLSigner(
        method=methods.enveloped,
        signature_algorithm="rsa-sha1",
        digest_algorithm="sha1",
        c14n_algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315",
    )

    signed_root = signer.sign(
        root, key=key_pem, cert=cert_pem, reference_uri=reference_uri
    )

    return etree.tostring(signed_root, encoding="ISO-8859-1")
