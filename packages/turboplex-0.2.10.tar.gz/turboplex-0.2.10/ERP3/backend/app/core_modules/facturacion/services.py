from typing import List, Dict, Any
from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy.orm import Session
from fastapi import HTTPException
from uuid import UUID
import random

from app.core_modules.facturacion.models import (
    DocumentoTributario,
)
from app.core_modules.ventas.models import Venta, DetalleVenta, Producto

from app.core_modules.finanzas.models_rates import ExchangeRates
from app.core_modules.finanzas.services import round_clp, calculate_taxes_from_total


class VISValidationService:
    """
    Servicio de Validación para Vinculación Inteligente de Servicios (VIS).
    Asegura que no se despachen servicios sin respaldo físico o por sobre lo ordenado.
    """

    @staticmethod
    def get_monetary_dispatch_status(db: Session, venta_id: UUID) -> Dict[str, Any]:
        """
        Calcula el estado de despacho de una Orden de Venta INCLUYENDO valoración monetaria.
        Utiliza las tasas de cambio vigentes si la venta no es en CLP.
        """
        status = VISValidationService.get_dispatch_status(db, venta_id)

        venta = db.query(Venta).filter(Venta.id == venta_id).first()
        if not venta:
            return status

        # Forzar contexto tenant durante cálculos dependientes de relaciones
        prev_tenant = db.info.get("empresa_id", None)
        prev_no_tenant = db.info.get("allow_no_tenant", False)
        db.info["empresa_id"] = venta.empresa_id
        db.info["allow_no_tenant"] = False
        try:
            rate = Decimal("1")
            currency = getattr(venta, "moneda", "CLP")
            rate_warning = None
            rate_age_hours = 0

            if currency != "CLP":
                rate_obj = (
                    db.query(ExchangeRates)
                    .filter(ExchangeRates.currency_code == currency)
                    .first()
                )
                if rate_obj:
                    rate = Decimal(str(rate_obj.rate))
                    if rate_obj.updated_at:
                        last_update = rate_obj.updated_at
                        if last_update.tzinfo is None:
                            pass

                        now = (
                            datetime.now(timezone.utc)
                            if last_update.tzinfo
                            else datetime.now()
                        )

                        diff = now - last_update
                        rate_age_hours = diff.total_seconds() / 3600

                        if rate_age_hours > 24:
                            rate_warning = f"Tasa de cambio desactualizada (hace {int(rate_age_hours)} horas)"

            for sku, data in status.items():
                detalles = (
                    db.query(DetalleVenta)
                    .join(Producto)
                    .filter(
                        DetalleVenta.venta_id == venta_id,
                        Producto.sku == sku,
                    )
                    .all()
                )

                unit_price_dec = Decimal("0")
                if detalles:
                    unit_price_dec = Decimal(str(detalles[0].precio_unitario))

                remaining_qty_dec = Decimal(str(data["remaining"]))

                value_original_dec = remaining_qty_dec * unit_price_dec

                value_clp_raw = value_original_dec * rate
                value_clp = round_clp(value_clp_raw)

                data["monetary_value"] = {
                    "currency": currency,
                    "rate_used": float(rate),
                    "rate_age_hours": round(rate_age_hours, 1),
                    "warning": rate_warning,
                    "unit_price": float(unit_price_dec),
                    "total_original": float(value_original_dec),
                    "total_clp": value_clp,
                }

            return status
        finally:
            db.info["allow_no_tenant"] = prev_no_tenant
            if prev_tenant is None:
                db.info.pop("empresa_id", None)
            else:
                db.info["empresa_id"] = prev_tenant

    @staticmethod
    def get_dispatch_status(db: Session, venta_id: UUID) -> Dict[str, Any]:
        """
        Calcula el estado de despacho de una Orden de Venta.
        Retorna lo ordenado, lo despachado y el saldo pendiente.
        """
        venta = db.query(Venta).filter(Venta.id == venta_id).first()
        if not venta:
            raise ValueError(f"Venta con ID {venta_id} no encontrada.")
        empresa_id = venta.empresa_id

        prev_tenant = db.info.get("empresa_id", None)
        prev_no_tenant = db.info.get("allow_no_tenant", False)
        db.info["empresa_id"] = empresa_id
        db.info["allow_no_tenant"] = False
        try:
            detalles_venta = (
                db.query(
                    DetalleVenta.cantidad,
                    DetalleVenta.cantidad_cancelada,
                    DetalleVenta.es_servicio,
                    Producto.sku,
                    Producto.nombre,
                    Producto.tipo_producto,
                )
                .join(Producto, DetalleVenta.producto_id == Producto.id)
                .filter(
                    DetalleVenta.venta_id == venta_id,
                    DetalleVenta.empresa_id == empresa_id,
                )
                .all()
            )
            ordered_items = {}

            for (
                cantidad,
                cantidad_cancelada,
                es_servicio,
                sku,
                producto_nombre,
                producto_tipo,
            ) in detalles_venta:
                if sku not in ordered_items:
                    ordered_items[sku] = {
                        "ordered_qty": 0,
                        "cancelled_qty": 0,
                        "is_service": es_servicio or producto_tipo == "SERVICIO",
                        "product_name": producto_nombre,
                    }
                ordered_items[sku]["ordered_qty"] += cantidad
                ordered_items[sku]["cancelled_qty"] += cantidad_cancelada or 0

            previous_dtes = (
                db.query(DocumentoTributario)
                .filter(
                    DocumentoTributario.venta_id == venta_id,
                    DocumentoTributario.empresa_id == empresa_id,
                )
                .all()
            )

            dispatched_items = {sku: 0 for sku in ordered_items}

            for dte in previous_dtes:
                for det in dte.detalles:
                    sku = det.codigo_item
                    if sku in dispatched_items:
                        dispatched_items[sku] += det.cantidad
                    elif sku:
                        dispatched_items[sku] = det.cantidad

            status = {}
            for sku, data in ordered_items.items():
                dispatched = dispatched_items.get(sku, 0)
                cancelled = data["cancelled_qty"]

                remaining = max(0, data["ordered_qty"] - dispatched - cancelled)

                status[sku] = {
                    "ordered": data["ordered_qty"],
                    "dispatched": dispatched,
                    "cancelled": cancelled,
                    "remaining": remaining,
                    "is_service": data["is_service"],
                    "product_name": data["product_name"],
                }

            return status
        finally:
            db.info["allow_no_tenant"] = prev_no_tenant
            if prev_tenant is None:
                db.info.pop("empresa_id", None)
            else:
                db.info["empresa_id"] = prev_tenant

    @staticmethod
    def validate_dispatch(
        db: Session, venta_id: UUID, items_to_dispatch: List[Dict[str, Any]]
    ) -> bool:
        """
        Valida si el despacho propuesto cumple con las reglas VIS.

        items_to_dispatch: Lista de dicts con keys: 'codigo_item' (sku), 'cantidad'.

        Reglas:
        1. Cantidad a despachar <= Saldo Pendiente de la OV.
        2. (VIS) Total Servicios en Despacho <= Total Físicos en Despacho.
        """

        dispatch_status = VISValidationService.get_dispatch_status(db, venta_id)

        current_physical_qty = 0.0
        current_service_qty = 0.0

        for item in items_to_dispatch:
            sku = item.get("codigo_item")
            qty = float(item.get("cantidad", 0))

            if not sku or qty <= 0:
                continue

            if sku not in dispatch_status:
                producto = db.query(Producto).filter(Producto.sku == sku).first()
                is_service = False
                if producto:
                    is_service = producto.tipo_producto == "SERVICIO"

                if is_service:
                    raise HTTPException(
                        status_code=400,
                        detail=f"VIS Error: Servicio '{sku}' no pertenece a la Orden de Venta #{venta_id}.",
                    )

                current_physical_qty += qty
                continue

            item_status = dispatch_status[sku]

            if qty > item_status["remaining"]:
                raise HTTPException(
                    status_code=400,
                    detail=f"Exceso de cantidad para '{item_status['product_name']}'. Solicitado: {qty}, Pendiente: {item_status['remaining']}",
                )

            if item_status["is_service"]:
                current_service_qty += qty
            else:
                current_physical_qty += qty

        if current_service_qty > 0:
            if current_physical_qty == 0:
                raise HTTPException(
                    status_code=400,
                    detail="VIS Error: No se pueden despachar servicios sin productos físicos asociados en el mismo documento.",
                )

            if current_service_qty > current_physical_qty:
                raise HTTPException(
                    status_code=400,
                    detail=f"VIS Error: La cantidad de servicios ({current_service_qty}) supera la cantidad de productos físicos ({current_physical_qty}).",
                )

        return True

    @staticmethod
    def close_pending_balances(
        db: Session, venta_id: UUID, sku_to_close: str
    ) -> Dict[str, Any]:
        """
        Realiza el Cierre Administrativo de Saldos para un ítem específico de la OV.
        Marca el saldo pendiente como 'cancelado' sin eliminar la línea original.
        """
        status_map = VISValidationService.get_dispatch_status(db, venta_id)

        if sku_to_close not in status_map:
            raise HTTPException(
                status_code=404,
                detail=f"Item {sku_to_close} no encontrado en la Orden #{venta_id}",
            )

        item_status = status_map[sku_to_close]
        remaining = item_status["remaining"]

        if remaining <= 0:
            raise HTTPException(
                status_code=400,
                detail=f"El item {sku_to_close} no tiene saldo pendiente para cerrar.",
            )

        venta = db.query(Venta).filter(Venta.id == venta_id).first()
        empresa_id = venta.empresa_id if venta else None

        prev_tenant = db.info.get("empresa_id", None)
        prev_no_tenant = db.info.get("allow_no_tenant", False)
        if empresa_id:
            db.info["empresa_id"] = empresa_id
        db.info["allow_no_tenant"] = False
        try:
            detalles = (
                db.query(DetalleVenta)
                .join(Producto)
                .filter(
                    DetalleVenta.venta_id == venta_id,
                    (DetalleVenta.empresa_id == empresa_id) if empresa_id else True,
                    Producto.sku == sku_to_close,
                )
                .with_for_update()
                .all()
            )
        finally:
            db.info["allow_no_tenant"] = prev_no_tenant
            if prev_tenant is None:
                db.info.pop("empresa_id", None)
            else:
                db.info["empresa_id"] = prev_tenant

        qty_to_cancel = remaining

        for det in detalles:
            if qty_to_cancel <= 0:
                break

            current_cancelled = getattr(det, "cantidad_cancelada", 0)
            space_in_line = det.cantidad - current_cancelled

            cancel_here = min(qty_to_cancel, space_in_line)

            det.cantidad_cancelada = current_cancelled + cancel_here
            qty_to_cancel -= cancel_here

            db.add(det)

        if qty_to_cancel > 0:
            pass

        db.commit()

        return {
            "msg": f"Cierre administrativo exitoso para {sku_to_close}",
            "previous_remaining": remaining,
            "new_remaining": 0,
            "cancelled_total": item_status["cancelled"] + remaining,
        }


def normalize_dte_amounts(
    moneda: str,
    monto_neto: Decimal,
    monto_exento: Decimal,
    monto_iva: Decimal,
    monto_total: Decimal,
) -> Dict[str, Decimal]:
    moneda = moneda or "CLP"
    monto_neto = Decimal(str(monto_neto or 0))
    monto_exento = Decimal(str(monto_exento or 0))
    monto_iva = Decimal(str(monto_iva or 0))
    monto_total = Decimal(str(monto_total or 0))

    if moneda == "CLP":
        exento_int = Decimal(round_clp(monto_exento))
        taxable_total = monto_neto + monto_iva
        taxable_total_int = Decimal(round_clp(taxable_total))
        taxes = calculate_taxes_from_total(taxable_total_int)
        neto_int = Decimal(taxes["neto"])
        iva_int = Decimal(taxes["iva"])
        total_int = neto_int + iva_int + exento_int
        return {
            "monto_neto": neto_int,
            "monto_exento": exento_int,
            "monto_iva": iva_int,
            "monto_total": total_int,
        }

    return {
        "monto_neto": monto_neto,
        "monto_exento": monto_exento,
        "monto_iva": monto_iva,
        "monto_total": monto_total,
    }


def create_dte_from_sale(
    db: Session,
    venta: Venta,
    usuario_id: UUID,
    tipo_dte: int = 39,  # Boleta Electrónica por defecto
) -> DocumentoTributario:
    """
    Crea un Documento Tributario (DTE) a partir de una Venta confirmada.
    Este es un placeholder funcional para cumplir con el flujo E2E.
    En producción, requeriría asignación de folios SII, firma digital, etc.
    """
    # Calcular montos (simplificado, asumiendo todo afecto por ahora o mixto)
    total = venta.total
    # Desglosar IVA usando la tasa aplicada a la venta (snapshot) o configuración vigente
    from app.core_modules.finanzas.services import get_impuesto_rate
    tasa = None
    if getattr(venta, "iva_tasa_aplicada", None) is not None:
        tasa = Decimal(str(venta.iva_tasa_aplicada))
    else:
        tasa = get_impuesto_rate(db, venta.empresa_id, "IVA")
    tasa = Decimal(str(tasa))

    neto_preciso = (Decimal(str(total)) / (Decimal("1") + tasa)).quantize(Decimal("0.0001"))
    iva_preciso = (Decimal(str(total)) - neto_preciso).quantize(Decimal("0.0001"))
    neto = neto_preciso
    iva = iva_preciso
    
    # Redondear a enteros para CLP
    neto_int = int(round(neto))
    iva_int = int(round(iva))
    total_int = int(round(total))
    
    # Ajuste por redondeo
    if neto_int + iva_int != total_int:
        # Ajustar neto para cuadrar
        neto_int = total_int - iva_int

    folio_simulado = random.randint(100000000, 2147483647)

    dte = DocumentoTributario(
        empresa_id=venta.empresa_id,
        tipo_dte=tipo_dte,
        folio=folio_simulado,  # Placeholder random para evitar colisiones en tests
        fecha_emision=datetime.now().date(),
        receptor_rut=venta.cliente.rut if venta.cliente else "66666666-6",
        receptor_razon_social=venta.cliente.nombre if venta.cliente else "Cliente Generico",
        receptor_direccion=venta.cliente.direccion if venta.cliente else "Sin Direccion",
        monto_neto=neto_int,
        monto_exento=0,
        monto_iva=iva_int,
        monto_total=total_int,
        venta_id=venta.id,
        cliente_id=venta.cliente_id,
        usuario_emisor_id=usuario_id,
        estado_sii="PENDIENTE", # Estado interno
    )
    
    db.add(dte)
    # No hacemos commit aquí, dejamos que la transacción padre lo haga
    return dte
