from __future__ import annotations

from uuid import UUID

from sqlalchemy import false, or_
from sqlalchemy.orm import Session

from app.core_modules.facturacion.models import DocumentoTributario
from app.core_modules.ventas.models import Venta


def get_dte_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    receptor_rut: str,
    allowed_sucursal_ids: list[UUID] | None,
    dte_id: UUID,
) -> DocumentoTributario | None:
    query = (
        db.query(DocumentoTributario)
        .outerjoin(Venta, Venta.id == DocumentoTributario.venta_id)
        .filter(
            DocumentoTributario.id == dte_id,
            DocumentoTributario.empresa_id == empresa_id,
            or_(
                DocumentoTributario.cliente_id == cliente_id,
                DocumentoTributario.receptor_rut == receptor_rut,
            ),
        )
    )
    if allowed_sucursal_ids is not None:
        if not allowed_sucursal_ids:
            query = query.filter(false())
        else:
            query = query.filter(
                or_(Venta.sucursal_id.is_(None), Venta.sucursal_id.in_(allowed_sucursal_ids))
            )
    return query.first()


def list_dtes_for_portal(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    receptor_rut: str,
    allowed_sucursal_ids: list[UUID] | None,
    tipos: list[int],
    limit: int,
):
    query = (
        db.query(DocumentoTributario)
        .outerjoin(Venta, Venta.id == DocumentoTributario.venta_id)
        .filter(
            DocumentoTributario.empresa_id == empresa_id,
            DocumentoTributario.tipo_dte.in_(tipos),
            or_(
                DocumentoTributario.cliente_id == cliente_id,
                DocumentoTributario.receptor_rut == receptor_rut,
            ),
        )
        .order_by(DocumentoTributario.fecha_emision.desc(), DocumentoTributario.folio.desc())
    )
    if allowed_sucursal_ids is not None:
        if not allowed_sucursal_ids:
            query = query.filter(false())
        else:
            query = query.filter(
                or_(Venta.sucursal_id.is_(None), Venta.sucursal_id.in_(allowed_sucursal_ids))
            )
    return query.limit(limit).all()


def list_dtes_for_portal_by_ids(
    db: Session,
    *,
    empresa_id: UUID,
    cliente_id: UUID,
    receptor_rut: str,
    allowed_sucursal_ids: list[UUID] | None,
    dte_ids: list[UUID],
):
    if not dte_ids:
        return []
    query = (
        db.query(DocumentoTributario)
        .outerjoin(Venta, Venta.id == DocumentoTributario.venta_id)
        .filter(
            DocumentoTributario.id.in_(dte_ids),
            DocumentoTributario.empresa_id == empresa_id,
            or_(
                DocumentoTributario.cliente_id == cliente_id,
                DocumentoTributario.receptor_rut == receptor_rut,
            ),
        )
    )
    if allowed_sucursal_ids is not None:
        if not allowed_sucursal_ids:
            query = query.filter(false())
        else:
            query = query.filter(
                or_(Venta.sucursal_id.is_(None), Venta.sucursal_id.in_(allowed_sucursal_ids))
            )
    return query.all()

