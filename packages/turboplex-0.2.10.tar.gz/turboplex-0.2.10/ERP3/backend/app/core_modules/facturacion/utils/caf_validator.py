import logging
from lxml import etree
from typing import Dict, Any
from app.core_modules.facturacion.utils.rut_validation import clean_rut

logger = logging.getLogger(__name__)


def _parse_caf_root(caf_xml_content: str) -> etree.Element:
    """Helper para parsear el XML del CAF."""
    if isinstance(caf_xml_content, str):
        parser = etree.XMLParser(recover=True)
        # Aseguramos que sea bytes para lxml
        return etree.fromstring(caf_xml_content.encode("utf-8"), parser=parser)
    else:
        return etree.fromstring(caf_xml_content)


def validar_caf(
    caf_xml_content: str, rut_empresa: str, tipo_dte: int
) -> Dict[str, int]:
    """
    Parsea y valida un archivo CAF (Código de Autorización de Folios).

    Args:
        caf_xml_content: Contenido XML del CAF (string)
        rut_empresa: RUT de la empresa emisora (formato 12345678-9)
        tipo_dte: Tipo de DTE esperado (int)

    Returns:
        Dict con {'desde': int, 'hasta': int} si es válido.

    Raises:
        ValueError: Si el CAF es inválido o no coincide con los datos.
    """
    try:
        root = _parse_caf_root(caf_xml_content)

        # Buscar nodo DA (Datos Autorización)
        da_node = root.find(".//DA")
        if da_node is None:
            # Intentar buscar con namespace si falla
            # A veces el SII incluye xmlns="http://www.sii.cl/SiiDte"
            ns = {"sii": "http://www.sii.cl/SiiDte"}
            da_node = root.find(".//sii:DA", namespaces=ns)

        if da_node is None:
            raise ValueError("Estructura CAF inválida: No se encontró nodo DA")

        # 1. Validar RUT Emisor
        re_node = da_node.find("RE")
        if re_node is None:
            raise ValueError("CAF inválido: No contiene RUT Emisor (RE)")

        rut_caf = clean_rut(re_node.text)
        rut_empresa_norm = clean_rut(rut_empresa)

        if rut_caf != rut_empresa_norm:
            raise ValueError(
                f"CAF no corresponde a la empresa. RUT CAF: {rut_caf}, RUT Empresa: {rut_empresa_norm} (original: {rut_empresa})"
            )

        # 2. Validar Tipo DTE
        td_node = da_node.find("TD")
        if td_node is None:
            raise ValueError("CAF inválido: No contiene Tipo DTE (TD)")

        tipo_caf = int(td_node.text.strip())
        if tipo_caf != tipo_dte:
            raise ValueError(
                f"CAF no corresponde al Tipo DTE. CAF: {tipo_caf}, Esperado: {tipo_dte}"
            )

        # 3. Validar Llave Privada (RSASK)
        rsask_node = da_node.find("RSASK")
        if rsask_node is None:
            raise ValueError(
                "CAF inválido: No contiene llave privada (RSASK) para generar Timbre Electrónico"
            )

        # 4. Extraer Rango
        rng_node = da_node.find("RNG")
        if rng_node is None:
            raise ValueError("CAF inválido: No contiene rango de folios (RNG)")

        desde = int(rng_node.find("D").text.strip())
        hasta = int(rng_node.find("H").text.strip())

        return {"desde": desde, "hasta": hasta}

    except etree.XMLSyntaxError as e:
        raise ValueError(f"Error de sintaxis XML en CAF: {str(e)}")
    except ValueError as e:
        raise e
    except Exception as e:
        raise ValueError(f"Error inesperado procesando CAF: {str(e)}")


def extraer_datos_caf(caf_xml_content: str) -> Dict[str, Any]:
    """
    Extrae los datos necesarios del CAF para generar el Timbre Electrónico (TED).

    Args:
        caf_xml_content: Contenido XML del CAF.

    Returns:
        Dict con keys:
            - 'caf_node': Elemento lxml <CAF> listo para insertar
            - 'rsask_text': Texto de la llave privada
    """
    root = _parse_caf_root(caf_xml_content)

    # Extraer nodo completo CAF para insertar en el timbre
    # Normalmente el XML del CAF tiene <AUTORIZACION><CAF>...</CAF>...</AUTORIZACION>
    caf_node = root.find(".//CAF")
    if caf_node is None:
        # Intentar con namespace
        ns = {"sii": "http://www.sii.cl/SiiDte"}
        caf_node = root.find(".//sii:CAF", namespaces=ns)

    if caf_node is None:
        raise ValueError("No se encontró nodo <CAF> en el archivo")

    # Extraer llave privada
    rsask_node = root.find(".//RSASK")
    if rsask_node is None:
        ns = {"sii": "http://www.sii.cl/SiiDte"}
        rsask_node = root.find(".//sii:RSASK", namespaces=ns)

    if rsask_node is None:
        raise ValueError("No se encontró nodo <RSASK> en el archivo")

    return {"caf_node": caf_node, "rsask_text": rsask_node.text.strip()}
