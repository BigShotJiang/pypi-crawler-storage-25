from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.database import get_db
from app.core_modules.legal.models import DocumentoLegal, EstadoDocumento
from app.core_modules.legal import schemas

router = APIRouter()


@router.get(
    "/documents", response_model=List[schemas.DocumentoLegalRead], tags=["Legal"]
)
def list_documents(
    estado: Optional[EstadoDocumento] = None,
    oportunidad_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    """
    Lista todos los documentos legales generados con filtros opcionales.
    """
    query = db.query(DocumentoLegal)

    if estado:
        query = query.filter(DocumentoLegal.estado == estado)

    if oportunidad_id:
        query = query.filter(DocumentoLegal.oportunidad_id == oportunidad_id)

    return query.order_by(DocumentoLegal.fecha_creacion.desc()).all()
