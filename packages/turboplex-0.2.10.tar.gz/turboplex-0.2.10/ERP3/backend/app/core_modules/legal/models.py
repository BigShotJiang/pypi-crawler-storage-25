from sqlalchemy import (
    Column,
    String,
    DateTime,
    ForeignKey,
    Enum as SAEnum,
    JSON,
)
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.sql import func
import enum
from app.core.database import Base, GUID
from uuid import UUID
import uuid6


# Enum para el estado del documento
class EstadoDocumento(str, enum.Enum):
    PENDIENTE = "PENDIENTE"
    FIRMADO = "FIRMADO"
    ANULADO = "ANULADO"


class DocumentoLegal(Base):
    __tablename__ = "legal_documentos"

    # ID: UUID generado automáticamente
    id: Mapped[UUID] = Column(GUID, primary_key=True, default=uuid6.uuid7)

    # Relación con OportunidadVenta
    oportunidad_id = Column(GUID, ForeignKey("crm_oportunidades.id"), nullable=False)

    # Definimos la relación con string para evitar importaciones circulares inmediatas
    oportunidad = relationship(
        "app.core_modules.crm.models.OportunidadVenta", backref="documentos_legales"
    )

    # Campos de Auditoría
    tenant_id = Column(GUID, nullable=False)  # Para multitenancy
    fecha_creacion = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    fecha_firma = Column(DateTime(timezone=True), nullable=True)

    # Campos Técnicos
    ruta_archivo = Column(
        String, nullable=False
    )  # Path en R2/Local (Generado por sistema)
    ruta_archivo_firmado = Column(
        String, nullable=True
    )  # Path en R2/Local (Subido firmado/escaneado)
    hash_integridad = Column(String, nullable=True)  # Para el sello digital
    estado = Column(
        SAEnum(EstadoDocumento), default=EstadoDocumento.PENDIENTE, nullable=False
    )

    # Metadata
    info_firma = Column(
        JSON, nullable=True
    )  # RUT del firmante y otros datos de ClaveÚnica
