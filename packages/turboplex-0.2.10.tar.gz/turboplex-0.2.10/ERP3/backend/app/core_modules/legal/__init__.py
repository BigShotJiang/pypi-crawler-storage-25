from .models import DocumentoLegal, EstadoDocumento

__all__ = [
    "DocumentoLegal",
    "EstadoDocumento",
]
