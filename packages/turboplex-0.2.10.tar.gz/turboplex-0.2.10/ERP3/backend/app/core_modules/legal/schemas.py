from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from uuid import UUID
from app.core_modules.legal.models import EstadoDocumento


class DocumentoLegalBase(BaseModel):
    estado: EstadoDocumento
    ruta_archivo: str
    ruta_archivo_firmado: Optional[str] = None
    hash_integridad: Optional[str] = None
    fecha_firma: Optional[datetime] = None
    tenant_id: UUID


class DocumentoLegalRead(DocumentoLegalBase):
    id: UUID
    oportunidad_id: UUID
    fecha_creacion: datetime

    class Config:
        from_attributes = True
