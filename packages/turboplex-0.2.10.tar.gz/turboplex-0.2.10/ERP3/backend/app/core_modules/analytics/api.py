from datetime import datetime, timezone, timedelta
from typing import Any, Dict
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session
from app.api import deps
from . import services
import io

router = APIRouter(prefix="/analytics", tags=["Analytics"])


def _parse_date(s: str) -> datetime:
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        raise HTTPException(
            status_code=400, detail="Formato de fecha inválido. Use ISO 8601."
        )


@router.get("/summary")
def summary(
    start_date: str = Query(..., description="Fecha inicio ISO 8601"),
    end_date: str = Query(..., description="Fecha fin ISO 8601"),
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Dict[str, Any]:
    start = _parse_date(start_date)
    end = _parse_date(end_date)
    sales = services.sales_summary(db, current_company.id, start, end)
    status_counts = services.services_by_status(db, current_company.id, start, end)
    top = services.top_products(db, current_company.id, start, end, limit=5)
    return {
        "range": {"start": start.isoformat(), "end": end.isoformat()},
        "sales": sales,
        "services_by_status": status_counts,
        "top_products": top,
    }


@router.get("/daily-sales")
def daily_sales(
    days: int = Query(7, ge=1, le=31),
    reference_date: str = Query(
        None, description="Fecha referencia ISO; si no, hoy UTC"
    ),
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Dict[str, Any]:
    ref = _parse_date(reference_date) if reference_date else datetime.now(timezone.utc)
    start = ref - timedelta(days=days - 1)
    data = services.daily_sales(db, current_company.id, start, days)
    return {"series": data}


@router.get("/income-expense")
def income_expense(
    days: int = Query(14, ge=1, le=60),
    reference_date: str = Query(None),
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Dict[str, Any]:
    ref = _parse_date(reference_date) if reference_date else datetime.now(timezone.utc)
    start = ref - timedelta(days=days - 1)
    data = services.daily_income_expense(db, current_company.id, start, days)
    return {"series": data}


@router.get("/export/pdf")
def export_pdf(
    start_date: str = Query(...),
    end_date: str = Query(...),
    db: Session = Depends(deps.get_db),
    current_company: Any = Depends(deps.get_current_active_company),
) -> Response:
    start = _parse_date(start_date)
    end = _parse_date(end_date)
    summary_data = summary(start_date, end_date, db, current_company)  # reuse
    # Generar un PDF simple con los números clave
    # Reusar PDFGenerator con una plantilla mínima
    # Creamos un objeto mock para opportunity/items para usar el layout, pero mejor generar propio PDF liviano
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
    )
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=LETTER)
    styles = getSampleStyleSheet()
    elements = []
    elements.append(
        Paragraph(f"Reporte de Métricas - {current_company.nombre}", styles["Title"])
    )
    elements.append(
        Paragraph(f"Rango: {start.isoformat()} a {end.isoformat()}", styles["Normal"])
    )
    elements.append(Spacer(1, 12))
    sales = summary_data["sales"]
    tbl = Table(
        [
            ["Total Bruto", f"${sales['total_bruto']:,.0f}"],
            ["Total Neto", f"${sales['total_neto']:,.0f}"],
            ["Ticket Promedio", f"${sales['ticket_promedio']:,.0f}"],
        ],
        colWidths=[200, 200],
    )
    tbl.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke),
            ]
        )
    )
    elements.append(tbl)
    elements.append(Spacer(1, 12))
    elements.append(Paragraph("Top Productos/Servicios", styles["Heading2"]))
    top_rows = [["Producto/Servicio", "Monto"]] + [
        [p["name"], f"${p['amount']:,.0f}"] for p in summary_data["top_products"]
    ]
    top_tbl = Table(top_rows, colWidths=[260, 140])
    top_tbl.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    elements.append(top_tbl)
    elements.append(Spacer(1, 12))
    elements.append(Paragraph("Servicios por Estado", styles["Heading2"]))
    status_rows = [["Estado", "Cantidad"]] + [
        [k, v] for k, v in summary_data["services_by_status"].items()
    ]
    st_tbl = Table(status_rows, colWidths=[260, 140])
    st_tbl.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    elements.append(st_tbl)
    doc.build(elements)
    buffer.seek(0)
    pdf_bytes = buffer.read()
    headers = {
        "Content-Disposition": f"attachment; filename=bi_resumen_{start.date()}_{end.date()}.pdf"
    }
    return Response(content=pdf_bytes, media_type="application/pdf", headers=headers)
