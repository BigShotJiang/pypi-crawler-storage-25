from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from app.core_modules.ventas.models import Venta, DetalleVenta, Producto
from app.core_modules.service_engine.models import ServiceOrder
from app.core.utils import get_uuidv7_range_for_date
from app.core_modules.finanzas.models import Gasto
from decimal import Decimal


def _uuidv7_bounds(start: datetime, end: datetime):
    start_uuid_min, _ = get_uuidv7_range_for_date(start)
    _, end_uuid_max = get_uuidv7_range_for_date(end)
    return start_uuid_min, end_uuid_max


def sales_summary(db: Session, empresa_id, start: datetime, end: datetime):
    # Filtros por tiempo (fecha y UUIDv7 para mejor índice temporal)
    start_uuid, end_uuid = _uuidv7_bounds(start, end)
    q_base = db.query(Venta).filter(
        Venta.empresa_id == empresa_id,
        Venta.id >= start_uuid,
        Venta.id <= end_uuid,
        Venta.fecha >= start,
        Venta.fecha <= end,
    )
    total_bruto = (
        db.query(func.coalesce(func.sum(Venta.total), 0))
        .filter(q_base.whereclause)
        .scalar()
    )
    neto = (
        db.query(func.coalesce(func.sum(DetalleVenta.subtotal), 0))
        .join(Venta, DetalleVenta.venta_id == Venta.id)
        .filter(
            Venta.empresa_id == empresa_id,
            Venta.id >= start_uuid,
            Venta.id <= end_uuid,
            Venta.fecha >= start,
            Venta.fecha <= end,
        )
        .scalar()
    )
    ticket_promedio = (
        db.query(func.coalesce(func.avg(Venta.total), 0))
        .filter(q_base.whereclause)
        .scalar()
    )
    # Egresos en rango
    egresos_total = (
        db.query(func.coalesce(func.sum(Gasto.monto), 0))
        .filter(
            Gasto.empresa_id == empresa_id, Gasto.fecha >= start, Gasto.fecha <= end
        )
        .scalar()
    )
    utilidad_neta = (neto or 0) - (egresos_total or 0)
    return {
        "total_bruto": total_bruto or Decimal("0"),
        "total_neto": neto or Decimal("0"),
        "ticket_promedio": ticket_promedio or Decimal("0"),
        "egresos_total": egresos_total or Decimal("0"),
        "utilidad_neta": utilidad_neta or Decimal("0"),
    }


def top_products(
    db: Session, empresa_id, start: datetime, end: datetime, limit: int = 5
):
    start_uuid, end_uuid = _uuidv7_bounds(start, end)
    rows = (
        db.query(
            Producto.nombre,
            func.coalesce(func.sum(DetalleVenta.subtotal), 0).label("monto"),
        )
        .join(DetalleVenta, DetalleVenta.producto_id == Producto.id)
        .join(Venta, DetalleVenta.venta_id == Venta.id)
        .filter(
            Venta.empresa_id == empresa_id,
            Venta.id >= start_uuid,
            Venta.id <= end_uuid,
            Venta.fecha >= start,
            Venta.fecha <= end,
        )
        .group_by(Producto.nombre)
        .order_by(desc("monto"))
        .limit(limit)
        .all()
    )
    return [{"name": r[0], "amount": r[1]} for r in rows]


def services_by_status(db: Session, empresa_id, start: datetime, end: datetime):
    start_uuid, end_uuid = _uuidv7_bounds(start, end)
    rows = (
        db.query(ServiceOrder.status, func.count(ServiceOrder.id))
        .filter(
            ServiceOrder.empresa_id == empresa_id,
            ServiceOrder.id >= start_uuid,
            ServiceOrder.id <= end_uuid,
            ServiceOrder.created_at >= start,
            ServiceOrder.created_at <= end,
        )
        .group_by(ServiceOrder.status)
        .all()
    )
    return {status or "DESCONOCIDO": count for status, count in rows}


def daily_sales(db: Session, empresa_id, start: datetime, days: int = 7):
    data = []
    for i in range(days):
        day = start + timedelta(days=i)
        day_start = day.replace(
            hour=0, minute=0, second=0, microsecond=0, tzinfo=day.tzinfo
        )
        day_end = day_start + timedelta(days=1) - timedelta(microseconds=1)
        summary = sales_summary(db, empresa_id, day_start, day_end)
        data.append(
            {
                "date": day_start.date().isoformat(),
                "total_bruto": summary["total_bruto"],
            }
        )
    return data


def daily_income_expense(db: Session, empresa_id, start: datetime, days: int = 14):
    data = []
    for i in range(days):
        day = start + timedelta(days=i)
        day_start = day.replace(
            hour=0, minute=0, second=0, microsecond=0, tzinfo=day.tzinfo
        )
        day_end = day_start + timedelta(days=1) - timedelta(microseconds=1)
        start_uuid, end_uuid = _uuidv7_bounds(day_start, day_end)
        ingresos = (
            db.query(func.coalesce(func.sum(Venta.total), 0))
            .filter(
                Venta.empresa_id == empresa_id,
                Venta.id >= start_uuid,
                Venta.id <= end_uuid,
                Venta.fecha >= day_start,
                Venta.fecha <= day_end,
            )
            .scalar()
            or 0
        )
        gastos = (
            db.query(func.coalesce(func.sum(Gasto.monto), 0))
            .filter(
                Gasto.empresa_id == empresa_id,
                Gasto.fecha >= day_start,
                Gasto.fecha <= day_end,
            )
            .scalar()
            or 0
        )
        data.append(
            {
                "date": day_start.date().isoformat(),
                "ingresos": ingresos,
                "gastos": gastos,
            }
        )
    return data
