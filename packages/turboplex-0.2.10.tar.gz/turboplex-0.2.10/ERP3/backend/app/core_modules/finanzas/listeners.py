from typing import Any

from app.core.infrastructure.events import event_dispatcher
import app.core.database as coredb
from app.core_modules.ventas.models import OrdenServicio
from app.core_modules.service_engine.models import ServiceOrder
from app.core_modules.compras.models import OrdenCompra
from app.core_modules.sistema.models import Usuario, UsuarioEmpresa
from app.core_modules.finanzas import models as finanzas_models
from app.core_modules.finanzas.accounting_service import check_periodo_abierto
from app.core.exceptions import BusinessRuleError, wrap_background_task
from datetime import datetime
from decimal import Decimal
import logging
import asyncio
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)

SessionLocal = coredb.SessionLocal


def _service_update_accounting_worker(data: dict[str, Any]) -> None:
    if data.get("status") != "COMPLETED":
        return
    service_order_id = data.get("service_order_id")
    usuario_id = data.get("usuario_id")
    if not service_order_id:
        return
    db = coredb.SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        order = (
            db.query(ServiceOrder).filter(ServiceOrder.id == service_order_id).first()
        )
        if not order:
            return
        total_costo = Decimal("0")
        if order.venta:
            for detalle in order.venta.detalles:
                producto = detalle.producto
                if producto and producto.receta:
                    qty_servicios = Decimal(str(detalle.cantidad))
                    for insumo in producto.receta.insumos:
                        insumo_producto = insumo.producto_insumo
                        qty_insumo = Decimal(str(insumo.cantidad)) * qty_servicios
                        precio_insumo = Decimal(str(insumo_producto.precio))
                        costo_item = precio_insumo * qty_insumo
                        total_costo += costo_item
        elif order.producto:
            producto = order.producto
            if producto and producto.receta:
                qty_servicios = Decimal("1")
                if order.metadata_info:
                    for key in [
                        "peso_kg",
                        "cantidad",
                        "qty",
                        "numero_prendas",
                        "peso_carga_kg",
                    ]:
                        if key in order.metadata_info:
                            try:
                                val = order.metadata_info[key]
                                val_dec = Decimal(str(val))
                                if val_dec > 0:
                                    qty_servicios = val_dec
                                    break
                            except (TypeError, ValueError):
                                pass
                for insumo in producto.receta.insumos:
                    insumo_producto = insumo.producto_insumo
                    qty_insumo = Decimal(str(insumo.cantidad)) * qty_servicios
                    precio_insumo = Decimal(str(insumo_producto.precio))
                    costo_item = precio_insumo * qty_insumo
                    total_costo += costo_item
        if total_costo > 0:
            cuenta_existencias = (
                db.query(finanzas_models.CuentaContable)
                .filter(
                    finanzas_models.CuentaContable.codigo == "1.1.03.01",
                    finanzas_models.CuentaContable.empresa_id == order.empresa_id,
                )
                .first()
            )
            cuenta_costo = (
                db.query(finanzas_models.CuentaContable)
                .filter(
                    finanzas_models.CuentaContable.codigo == "5.1.01",
                    finanzas_models.CuentaContable.empresa_id == order.empresa_id,
                )
                .first()
            )
            if not (cuenta_existencias and cuenta_costo):
                logger.error("No se encontraron cuentas contables (1.1.03.01 o 5.1.01)")
                return
            empresa_id = order.empresa_id
            sucursal_id = order.sucursal_id

            # Validar periodo contable
            try:
                check_periodo_abierto(db, empresa_id, datetime.now())
            except BusinessRuleError as exc:
                logger.error(
                    "No se puede generar asiento para ServiceOrder #%s: Periodo Cerrado. %s",
                    order.id,
                    exc,
                )
                return

            asiento = finanzas_models.AsientoContable(
                fecha=datetime.now(),
                glosa=f"Consumo Insumos ServiceOrder #{order.id}",
                origen="SERVICE_ENGINE",
                origen_id=order.id,
                estado="CONFIRMADO",
                empresa_id=empresa_id,
                usuario_id=usuario_id or order.usuario_id,
            )
            db.add(asiento)
            db.flush()
            mov_debe = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_costo.id,
                debe=total_costo,
                haber=0,
                sucursal_id=sucursal_id,
            )
            mov_haber = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_existencias.id,
                debe=0,
                haber=total_costo,
                sucursal_id=sucursal_id,
            )
            db.add(mov_debe)
            db.add(mov_haber)
            db.commit()
            logger.info(
                f"Asiento contable generado para ServiceOrder #{service_order_id}"
            )
    except (SQLAlchemyError, BusinessRuleError, TypeError, ValueError) as exc:
        logger.error(
            "Error generando contabilidad para ServiceOrder #%s: %s",
            service_order_id,
            exc,
        )
        db.rollback()
    finally:
        db.close()


_service_update_accounting_task = wrap_background_task(
    _service_update_accounting_worker,
    task_name="service_engine.service_update_accounting",
)


async def handle_service_update_accounting(data: dict[str, Any]) -> None:
    if data.get("status") != "COMPLETED":
        return
    if not data.get("service_order_id"):
        return
    asyncio.create_task(asyncio.to_thread(_service_update_accounting_task, data))


async def handle_orden_finalizada_accounting(data: dict[str, Any]) -> None:
    """
    Listener para generar asientos contables cuando una Orden de Servicio finaliza.
    """
    orden_id = data.get("orden_id")
    usuario_id = data.get("usuario_id")

    if not orden_id:
        logger.error("Event data missing orden_id")
        return

    db = coredb.SessionLocal()
    try:
        orden = db.query(OrdenServicio).filter(OrdenServicio.id == orden_id).first()
        if not orden or not orden.venta:
            return

        total_costo = Decimal("0")

        # Recalcular costo (Lógica extraída de ventas/services.py)
        # Nota: Idealmente el costo debería venir calculado o ser un servicio compartido,
        # pero para desacoplar, replicamos la lectura de insumos o llamamos a un helper.
        # Por ahora replicamos la lógica de cálculo de costo.

        for detalle in orden.venta.detalles:
            producto = detalle.producto
            if producto and producto.receta:
                qty_servicios = Decimal(str(detalle.cantidad))
                for insumo in producto.receta.insumos:
                    insumo_producto = insumo.producto_insumo
                    qty_insumo = Decimal(str(insumo.cantidad)) * qty_servicios

                    # Calcular Costo (Precio * Cantidad)
                    precio_insumo = Decimal(str(insumo_producto.precio))
                    costo_item = precio_insumo * qty_insumo
                    total_costo += costo_item

        if total_costo > 0:
            # Obtener cuentas contables
            cuenta_existencias = (
                db.query(finanzas_models.CuentaContable)
                .filter(finanzas_models.CuentaContable.codigo == "1.1.03.01")
                .first()
            )
            cuenta_costo = (
                db.query(finanzas_models.CuentaContable)
                .filter(finanzas_models.CuentaContable.codigo == "5.1.01")
                .first()
            )

            if not (cuenta_existencias and cuenta_costo):
                logger.error("No se encontraron cuentas contables (1.1.03.01 o 5.1.01)")
                return

            asiento = finanzas_models.AsientoContable(
                fecha=datetime.now(),
                glosa=f"Consumo Insumos OS #{orden.id}",
                origen="VENTAS_OS",
                origen_id=orden.id,
                estado="CONFIRMADO",
                empresa_id=orden.venta.empresa_id,
                usuario_id=usuario_id,
            )
            db.add(asiento)
            db.flush()

            # DEBE: Costo de Ventas
            mov_debe = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=orden.venta.empresa_id,
                cuenta_id=cuenta_costo.id,
                debe=total_costo,
                haber=0,
                sucursal_id=orden.venta.sucursal_id,
            )
            # HABER: Existencias
            mov_haber = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=orden.venta.empresa_id,
                cuenta_id=cuenta_existencias.id,
                debe=0,
                haber=total_costo,
                sucursal_id=orden.venta.sucursal_id,
            )
            db.add(mov_debe)
            db.add(mov_haber)
            db.commit()
            logger.info(f"Asiento contable generado para Orden #{orden_id}")

    except (SQLAlchemyError, TypeError, ValueError) as e:
        logger.error("Error generando contabilidad para Orden #%s: %s", orden_id, e)
        db.rollback()
    finally:
        db.close()


async def handle_compra_recibida_accounting(data: dict[str, Any]) -> None:
    """
    Listener para generar asientos contables cuando se recibe una Orden de Compra.
    DEBE: Existencias (Activo)
    HABER: Proveedores (Pasivo)
    """
    orden_id = data.get("orden_id")
    # El evento no trae usuario_id explícito a veces, usaremos el de la OC o uno por defecto

    if not orden_id:
        logger.error("[FINANZAS] Event data missing orden_id for compra")
        return

    db = SessionLocal()
    try:
        orden = db.query(OrdenCompra).filter(OrdenCompra.id == orden_id).first()
        if not orden:
            logger.error(f"[FINANZAS] Orden Compra {orden_id} no encontrada")
            return

        if orden.total <= 0:
            logger.warning(
                f"[FINANZAS] Orden Compra {orden_id} tiene total 0, se omite contabilidad"
            )
            return

        # 1. Obtener Cuentas
        # Existencias (Misma que consumo: 1.1.03.01 - Materias Primas/Insumos)
        cuenta_existencias = (
            db.query(finanzas_models.CuentaContable)
            .filter(finanzas_models.CuentaContable.codigo == "1.1.03.01")
            .first()
        )
        # Proveedores Nacionales (2.1.01.01) - Si no existe, buscamos genérico 2.1.01
        cuenta_proveedores = (
            db.query(finanzas_models.CuentaContable)
            .filter(finanzas_models.CuentaContable.codigo == "2.1.01.01")
            .first()
        )
        if not cuenta_proveedores:
            cuenta_proveedores = (
                db.query(finanzas_models.CuentaContable)
                .filter(finanzas_models.CuentaContable.codigo == "2.1.01")
                .first()
            )

        if not (cuenta_existencias and cuenta_proveedores):
            logger.error(
                f"[FINANZAS] Faltan cuentas contables. Existencias: {bool(cuenta_existencias)}, Proveedores: {bool(cuenta_proveedores)}"
            )
            return

        # 2. Crear Asiento
        asiento = finanzas_models.AsientoContable(
            fecha=datetime.now(),
            glosa=f"Recepción OC #{orden.folio} - {orden.proveedor.razon_social}",
            origen="COMPRAS",
            origen_id=orden.id,
            estado="CONFIRMADO",
            rut_tercero=orden.proveedor.rut,
            razon_social_tercero=orden.proveedor.razon_social,
            empresa_id=orden.empresa_id,
            sucursal_id=orden.sucursal_id,
            usuario_id=orden.usuario_id,
        )
        db.add(asiento)
        db.flush()

        # 3. Crear Movimientos
        # DEBE: Existencias (Aumenta Activo)
        mov_debe = finanzas_models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=orden.empresa_id,
            cuenta_id=cuenta_existencias.id,
            debe=orden.total,  # Usamos Total (Bruto) o Neto?
            # Generalmente:
            # Neto -> Existencias
            # IVA -> IVA Crédito Fiscal
            # Total -> Proveedores
            # Por simplicidad del requerimiento "Debe: Existencias, Haber: Proveedores", usaré el Total en existencias si no se pide desglose de IVA.
            # El usuario dijo: "Debe: Cuenta de Existencias... Haber: Cuentas por Pagar".
            # Si hay IVA, técnicamente debería desglosarse, pero seguiré la instrucción simple "Aumenta el valor del inventario" (asumiendo costo total o simplificación).
            # Dado que ERP3 parece tener IVA (visto en seed), lo correcto es separar IVA.
            # Pero el usuario pidió explícitamente SIMPLE.
            # Voy a usar Total para Existencias por ahora para cumplir "Aumenta el valor del inventario" con el monto de la deuda.
            # O mejor: Neto a Existencias, IVA a IVA Crédito, Total a Proveedores.
            # Revisando instrucción: "Debe: Cuenta de Existencias... Haber: Cuentas por Pagar". No menciona IVA.
            # Voy a poner TODO en Existencias para cumplir estrictamente "Debe: Existencias - Haber: Proveedores".
            haber=0,
            sucursal_id=orden.sucursal_id,
        )

        # HABER: Proveedores (Aumenta Pasivo)
        mov_haber = finanzas_models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=orden.empresa_id,
            cuenta_id=cuenta_proveedores.id,
            debe=0,
            haber=orden.total,
            sucursal_id=orden.sucursal_id,
        )

        db.add(mov_debe)
        db.add(mov_haber)
        db.commit()
        logger.info(
            f"[FINANZAS] Asiento generado para OC #{orden.folio}. Monto: {orden.total}"
        )

    except (SQLAlchemyError, TypeError, ValueError) as e:
        logger.error("[FINANZAS] Error en asiento OC %s: %s", orden_id, e, exc_info=True)
        db.rollback()
    finally:
        db.close()


async def handle_movimiento_stock_accounting(data: dict[str, Any]) -> None:
    """
    Listener para generar asientos contables por ajustes de inventario (Mermas, Hallazgos).
    """
    tipo_movimiento = data.get("tipo_movimiento")
    
    # Solo nos interesan ajustes que afectan resultados
    if tipo_movimiento not in ["MERMA", "HALLAZGO", "AJUSTE", "CASTIGO", "SOBRANTE"]:
        return

    empresa_id = data.get("empresa_id")
    producto_id = data.get("producto_id")
    cantidad = Decimal(str(data.get("cantidad", 0)))
    costo_unitario = Decimal(str(data.get("costo_unitario", 0)))
    
    if cantidad == 0 or costo_unitario == 0:
        logger.warning(f"[FINANZAS] Movimiento {tipo_movimiento} con monto 0 (Cant: {cantidad}, Costo: {costo_unitario}). Se omite asiento.")
        return

    monto_total = abs(cantidad * costo_unitario)
    
    db = coredb.SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        # Validar periodo contable
        try:
            check_periodo_abierto(db, empresa_id, datetime.now())
        except BusinessRuleError as e:
            logger.error(
                "[FINANZAS] Periodo cerrado para movimiento %s: %s",
                tipo_movimiento,
                e,
            )
            return

        # Buscar Cuentas
        # 1. Existencias (Activo)
        cuenta_existencias = (
            db.query(finanzas_models.CuentaContable)
            .filter(
                finanzas_models.CuentaContable.codigo == "1.1.03.01",
                finanzas_models.CuentaContable.empresa_id == empresa_id
            )
            .first()
        )
        
        if not cuenta_existencias:
            logger.error(f"[FINANZAS] No existe cuenta de Existencias (1.1.03.01) para empresa {empresa_id}")
            return

        # Determinar cuentas de contrapartida según tipo
        cuenta_contrapartida = None
        es_perdida = False # Si es True: Gasto al DEBE, Existencias al HABER. Si False: Existencias al DEBE, Ingreso al HABER.

        if tipo_movimiento in ["MERMA", "CASTIGO"] or (tipo_movimiento == "AJUSTE" and cantidad < 0):
            # Es una PÉRDIDA de inventario
            es_perdida = True
            # Buscar cuenta de Gasto (Pérdida por Mermas)
            cuenta_contrapartida = (
                db.query(finanzas_models.CuentaContable)
                .filter(
                    finanzas_models.CuentaContable.codigo == "5.2.07", # Pérdida por Mermas
                    finanzas_models.CuentaContable.empresa_id == empresa_id
                )
                .first()
            )
            if not cuenta_contrapartida:
                 # Fallback a "Otros Gastos" si no existe específica
                cuenta_contrapartida = (
                    db.query(finanzas_models.CuentaContable)
                    .filter(
                        finanzas_models.CuentaContable.codigo.like("5.%"), # Algún gasto
                        finanzas_models.CuentaContable.empresa_id == empresa_id
                    )
                    .first()
                )
        
        elif tipo_movimiento in ["HALLAZGO", "SOBRANTE"] or (tipo_movimiento == "AJUSTE" and cantidad > 0):
            # Es una GANANCIA de inventario (Hallazgo)
            es_perdida = False
            # Buscar cuenta de Ingreso (Sobrantes de Inventario)
            cuenta_contrapartida = (
                db.query(finanzas_models.CuentaContable)
                .filter(
                    finanzas_models.CuentaContable.codigo == "4.2.01.02", # Sobrantes
                    finanzas_models.CuentaContable.empresa_id == empresa_id
                )
                .first()
            )
             # Fallback a "Otros Ingresos"
            if not cuenta_contrapartida:
                 cuenta_contrapartida = (
                    db.query(finanzas_models.CuentaContable)
                    .filter(
                        finanzas_models.CuentaContable.codigo == "4.2.01", # Otros Ingresos
                        finanzas_models.CuentaContable.empresa_id == empresa_id
                    )
                    .first()
                )

        if not cuenta_contrapartida:
            logger.error(f"[FINANZAS] No se encontró cuenta de contrapartida para {tipo_movimiento}")
            return

        # Buscar un usuario para asociar al asiento (Admin o primero disponible)
        usuario_sistema = db.query(Usuario).join(UsuarioEmpresa).filter(UsuarioEmpresa.empresa_id == empresa_id).first()
        if not usuario_sistema:
             # Fallback: intentar buscar un usuario admin global o lanzar error
             pass

        # Crear Asiento
        asiento = finanzas_models.AsientoContable(
            fecha=datetime.now(),
            glosa=f"Ajuste Inventario: {tipo_movimiento} - Prod {producto_id}",
            origen="INVENTARIO",
            origen_id=data.get("reference_id") or producto_id, # Idealmente el ID del movimiento, pero no viene en payload
            estado="CONFIRMADO",
            empresa_id=empresa_id,
            sucursal_id=None, # Podríamos buscar la sucursal por bodega_id si fuera necesario
            usuario_id=usuario_sistema.id if usuario_sistema else None
        )
        db.add(asiento)
        db.flush()

        if es_perdida:
            # PÉRDIDA:
            # DEBE: Gasto (Contrapartida)
            # HABER: Existencias (Activo disminuye)
            mov_debe = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_contrapartida.id,
                debe=monto_total,
                haber=0
            )
            mov_haber = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_existencias.id,
                debe=0,
                haber=monto_total
            )
        else:
            # GANANCIA:
            # DEBE: Existencias (Activo aumenta)
            # HABER: Ingreso (Contrapartida)
            mov_debe = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_existencias.id,
                debe=monto_total,
                haber=0
            )
            mov_haber = finanzas_models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_contrapartida.id,
                debe=0,
                haber=monto_total
            )

        db.add(mov_debe)
        db.add(mov_haber)
        db.commit()
        logger.info(f"[FINANZAS] Asiento generado por {tipo_movimiento}: {monto_total}")

    except (SQLAlchemyError, TypeError, ValueError) as e:
        logger.error(
            "[FINANZAS] Error generando asiento para movimiento stock: %s",
            e,
            exc_info=True,
        )
        db.rollback()
    finally:
        db.close()


def register_listeners() -> None:
    event_dispatcher.subscribe(
        "EVENT_ORDEN_FINALIZADA", handle_orden_finalizada_accounting
    )
    event_dispatcher.subscribe(
        "service_engine.order.update", handle_service_update_accounting
    )
    event_dispatcher.subscribe(
        "EVENT_COMPRA_RECIBIDA", handle_compra_recibida_accounting
    )
    event_dispatcher.subscribe(
        "EVENT_MOVIMIENTO_STOCK_REGISTRADO", handle_movimiento_stock_accounting
    )
