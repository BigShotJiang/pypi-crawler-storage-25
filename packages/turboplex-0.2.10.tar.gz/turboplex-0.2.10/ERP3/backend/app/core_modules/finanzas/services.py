from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from typing import Optional, Dict, cast
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from uuid import UUID
from app.core.config import settings
from app.core.infrastructure.config_manager import config_manager
from app.core.database import SessionLocal
from app.core_modules.sistema.models import ParametroGlobal
from app.core_modules.finanzas.models import (
    PrecioProducto,
    MovimientoContable,
    AsientoContable,
    CuentaContable,
)
from app.core_modules.ventas.models import Producto


def get_current_price(
    db: Session, producto_id: UUID, sucursal_id: UUID, tipo_cliente: Optional[str] = None
) -> Decimal:
    """
    Calcula el precio vigente de un producto aplicando reglas de especificidad:
    1. Precio Específico (Sucursal + Tipo Cliente)
    2. Precio Sucursal (Sucursal + Default Cliente)
    3. Precio Global Cliente (Global + Tipo Cliente)
    4. Precio Global Base (Global + Default Cliente)
    5. Precio Base del Producto
    """

    # Buscamos todos los precios candidatos en una sola consulta
    precios = (
        db.query(PrecioProducto)
        .filter(
            PrecioProducto.producto_id == producto_id,
            or_(
                PrecioProducto.sucursal_id == sucursal_id,
                PrecioProducto.sucursal_id.is_(None),
            ),
            or_(
                PrecioProducto.tipo_cliente == tipo_cliente,
                PrecioProducto.tipo_cliente.is_(None),
            ),
        )
        .all()
    )

    best_price: Optional[Decimal] = None
    best_score = -1

    # Check for forced Intercompany Override
    is_intercompany = tipo_cliente == "INTERCOMPANY"

    for p in precios:
        score = 0
        if p.sucursal_id == sucursal_id:
            score += 2
        if tipo_cliente and p.tipo_cliente == tipo_cliente:
            score += 1
            if is_intercompany:
                score += 10  # Massive boost for explicit Intercompany rule
        elif p.tipo_cliente is None:
            # Neutral score for default client type
            pass
        else:
            # Mismatching client type
            continue

        if score > best_score:
            best_score = score
            best_price = cast(Decimal, p.precio)

    if best_price is not None:
        return best_price

    # Fallback: Base Product Price
    # IF Intercompany and no specific price found -> Cost + 0% logic?
    # Since we don't track explicit "Cost" in Producto, we return Base Price.
    # Users should configure a PrecioProducto with tipo_cliente="INTERCOMPANY" and price = Cost.

    producto = db.query(Producto).filter(Producto.id == producto_id).first()
    if producto:
        return producto.precio

    return Decimal(0)


def round_peso(value: Decimal) -> Decimal:
    return value.to_integral_value(rounding=ROUND_HALF_UP)


def round_clp(amount: Decimal) -> int:
    return int(round_peso(amount))


def get_impuesto_rate(db: Optional[Session], empresa_id: Optional[UUID], codigo: str = "IVA") -> Decimal:
    """
    Obtiene la tasa vigente del impuesto 'codigo' desde configuracion_impuestos.
    Intermedio con 4 decimales; fallback a ParametroGlobal/env si no existe configuración.
    """
    try:
        from app.core_modules.finanzas.models import ConfiguracionImpuesto
    except Exception:
        ConfiguracionImpuesto = None

    # Preferir lectura por empresa si tenemos contexto y el modelo está disponible
    if db is not None and empresa_id is not None and ConfiguracionImpuesto is not None:
        row = (
            db.query(ConfiguracionImpuesto)
            .filter(
                ConfiguracionImpuesto.empresa_id == empresa_id,
                ConfiguracionImpuesto.codigo == codigo,
                ConfiguracionImpuesto.activo.is_(True),
            )
            .order_by(ConfiguracionImpuesto.vigente_desde.desc().nullslast())
            .first()
        )
        if row and getattr(row, "tasa", None) is not None:
            try:
                return Decimal(str(row.tasa)).quantize(Decimal("0.0001"))
            except (InvalidOperation, Exception):
                pass

    # Fallback global: ParametroGlobal (legacy)
    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        param = (
            db.query(ParametroGlobal)
            .filter(
                ParametroGlobal.empresa_id.is_(None),
                ParametroGlobal.llave == f"{codigo}_RATE",
            )
            .first()
        )
        if param and param.valor is not None:
            try:
                return Decimal(str(param.valor)).quantize(Decimal("0.0001"))
            except Exception:
                pass
    finally:
        db.close()

    raw = config_manager.get_setting(f"{codigo}_RATE", None)
    if raw is not None:
        try:
            return Decimal(str(raw)).quantize(Decimal("0.0001"))
        except Exception:
            pass
    env_raw = getattr(settings, "CHILE_IVA_RATE", None) if codigo == "IVA" else None
    if env_raw is not None:
        try:
            return Decimal(str(env_raw)).quantize(Decimal("0.0001"))
        except Exception:
            pass
    return Decimal("0.1900")


def get_iva_rate(db: Optional[Session] = None, empresa_id: Optional[UUID] = None) -> Decimal:
    return get_impuesto_rate(db, empresa_id, "IVA")


def calculate_taxes_from_total(
    total: Decimal,
    *,
    tasa: Optional[Decimal] = None,
    tasas: Optional[list[Decimal]] = None,
    tipos: Optional[list[str]] = None,
) -> Dict[str, int]:
    total_int = round_clp(Decimal(str(total)))
    if tasas and len(tasas) > 0:
        cargos = []
        for t in tasas:
            cargos.append(Decimal(str(t)).quantize(Decimal("0.0001")))
        tipos_norm = tipos or ["CARGO"] * len(cargos)
        factor = Decimal("1.0")
        for i, t in enumerate(cargos):
            if tipos_norm[i].upper() == "CARGO":
                factor *= Decimal("1") + t
        if factor == Decimal("0"):
            factor = Decimal("1.0")
        neto_dec = (Decimal(total_int) / factor).quantize(Decimal("0.0001"))
        neto = round_clp(neto_dec)
        impuestos_int = []
        for i, t in enumerate(cargos):
            if tipos_norm[i].upper() == "CARGO":
                imp_dec = (neto_dec * t).quantize(Decimal("0.0001"))
                impuestos_int.append(round_clp(imp_dec))
            else:
                imp_dec = (neto_dec * t).quantize(Decimal("0.0001"))
                impuestos_int.append(round_clp(imp_dec))
        iva_sum = sum(impuestos_int)
        return {"neto": neto, "iva": iva_sum, "total": total_int, "impuestos": impuestos_int}
    iva_rate = tasa if tasa is not None else get_impuesto_rate(None, None, "IVA")
    iva_rate = Decimal(str(iva_rate)).quantize(Decimal("0.0001"))
    neto_decimal = Decimal(str(total)) / (Decimal("1") + iva_rate)
    neto_decimal = neto_decimal.quantize(Decimal("0.0001"))
    neto = round_clp(neto_decimal)
    total_int = round_clp(Decimal(str(total)))
    neto_decimal = Decimal(total_int) / (Decimal("1") + iva_rate)
    neto_decimal = neto_decimal.quantize(Decimal("0.0001"))
    neto = round_clp(neto_decimal)
    neto_iva = total_int - neto
    return {"neto": neto, "iva": neto_iva, "total": total_int}


def aplicar_redondeo_ley_10_pesos(monto: Decimal) -> Decimal:
    monto = Decimal(str(monto or 0))
    entero = round_clp(monto)
    resto = entero % 10
    if resto >= 5:
        return Decimal(entero + (10 - resto))
    return Decimal(entero - resto)


def get_deuda_proveedor(db: Session, rut_proveedor: str) -> Decimal:
    """
    Calcula la deuda actual con un proveedor basándose en los movimientos contables
    de cuentas de PASIVO asociados a asientos con ese RUT.

    Deuda = Suma(Haber) - Suma(Debe)
    """
    # Join Movimiento -> Asiento -> Cuenta
    # Filter by RUT and Account Type (PASIVO or code start with 2)

    result = (
        db.query(func.sum(MovimientoContable.haber - MovimientoContable.debe))
        .join(AsientoContable, MovimientoContable.asiento_id == AsientoContable.id)
        .join(CuentaContable, MovimientoContable.cuenta_id == CuentaContable.id)
        .filter(
            AsientoContable.rut_tercero == rut_proveedor,
            AsientoContable.estado == "CONFIRMADO",
            or_(
                CuentaContable.tipo_cuenta == "PASIVO", CuentaContable.codigo.like("2%")
            ),
        )
        .scalar()
    )

    return result if result else Decimal(0)
