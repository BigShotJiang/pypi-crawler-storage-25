from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy import and_, func
from sqlalchemy.orm import Session

from app.core_modules.finanzas.models import Gasto
from app.core_modules.sistema.models import MetodoPago


def sum_gastos_efectivo(
    db: Session,
    *,
    empresa_id: UUID,
    sucursal_id: UUID,
    fecha_inicio: datetime,
    fecha_fin: datetime,
) -> Decimal:
    total = (
        db.query(func.sum(Gasto.monto))
        .join(MetodoPago, Gasto.metodo_pago_id == MetodoPago.id)
        .filter(
            and_(
                Gasto.empresa_id == empresa_id,
                Gasto.sucursal_id == sucursal_id,
                Gasto.fecha >= fecha_inicio,
                Gasto.fecha <= fecha_fin,
                MetodoPago.codigo == "EFECTIVO",
            )
        )
        .scalar()
    )
    return total or Decimal("0.00")

