from enum import Enum
from typing import Optional, List, Union
from pydantic import BaseModel, ConfigDict, field_validator
from decimal import Decimal
from datetime import datetime
from uuid import UUID
from app.core.utils import validate_rut, clean_rut

# --- Enums ---

class EstadoGastoEnum(str, Enum):
    PENDIENTE = "PENDIENTE"
    PAGADO = "PAGADO"
    ANULADO = "ANULADO"


# --- Proveedor Schemas ---


class ProveedorBase(BaseModel):
    nombre: str
    rut: Optional[str] = None
    telefono: Optional[str] = None
    email: Optional[str] = None
    direccion: Optional[str] = None


class ProveedorCreate(ProveedorBase):
    @field_validator("rut")
    @classmethod
    def validate_rut_chil(cls, v: Optional[str]) -> Optional[str]:
        if not v:
            return v
        if not validate_rut(v):
            raise ValueError("RUT inválido")
        return clean_rut(v)


class ProveedorUpdate(ProveedorBase):
    pass


class ProveedorInDBBase(ProveedorBase):
    id: UUID
    empresa_id: UUID
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class PeriodoContableBase(BaseModel):
    nombre: str
    fecha_inicio: datetime
    fecha_fin: datetime
    cerrado: bool = False
    fecha_cierre: Optional[datetime] = None


class PeriodoContable(PeriodoContableBase):
    id: UUID
    empresa_id: UUID
    usuario_cierre_id: Optional[UUID] = None

    model_config = ConfigDict(from_attributes=True)


class AuditLogLite(BaseModel):
    id: UUID
    actor_id: UUID
    action: str
    changes: Optional[dict] = None
    created_at: datetime
    
    model_config = ConfigDict(from_attributes=True)


class IntegridadPeriodo(BaseModel):
    estado: str  # "VERDE" | "ROJO"
    cuadratura_ok: bool
    diferencia: Decimal
    total_debe: Decimal
    total_haber: Decimal
    gastos_pendientes: int
    mensaje: str

    model_config = ConfigDict(from_attributes=True)


class Proveedor(ProveedorInDBBase):
    pass


# --- Gasto Schemas ---


class GastoBase(BaseModel):
    descripcion: str
    monto: Decimal
    categoria: str
    proveedor_id: Optional[Union[UUID, int, str]] = None
    sucursal_id: Union[UUID, int, str]
    metodo_pago_id: Union[UUID, int, str]
    fecha: Optional[datetime] = None
    fecha_vencimiento: Optional[datetime] = None
    documento_referencia: Optional[str] = None
    estado: Optional[EstadoGastoEnum] = EstadoGastoEnum.PAGADO


class GastoCreate(GastoBase):
    pass


class GastoUpdate(BaseModel):
    descripcion: Optional[str] = None
    monto: Optional[Decimal] = None
    categoria: Optional[str] = None
    proveedor_id: Optional[Union[UUID, int, str]] = None
    sucursal_id: Optional[Union[UUID, int, str]] = None
    metodo_pago_id: Optional[Union[UUID, int, str]] = None
    fecha: Optional[datetime] = None
    fecha_vencimiento: Optional[datetime] = None
    documento_referencia: Optional[str] = None
    estado: Optional[EstadoGastoEnum] = None


class GastoInDBBase(GastoBase):
    id: UUID
    empresa_id: UUID
    fecha: datetime
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    asiento_id: Optional[Union[UUID, int, str]] = None

    model_config = ConfigDict(from_attributes=True)


class Gasto(GastoInDBBase):
    pass


# --- Contabilidad Schemas ---


# Cuenta Contable
class CuentaContableBase(BaseModel):
    codigo: str
    nombre: str
    tipo_cuenta: str
    nivel: int
    es_imputable: bool = True
    padre_id: Optional[UUID] = None


class CuentaContableCreate(CuentaContableBase):
    pass


class CuentaContableUpdate(BaseModel):
    nombre: Optional[str] = None
    es_imputable: Optional[bool] = None


class CuentaContable(CuentaContableBase):
    id: UUID
    empresa_id: UUID

    model_config = ConfigDict(from_attributes=True)


# Movimiento Contable
class MovimientoContableBase(BaseModel):
    cuenta_id: UUID
    debe: Decimal
    haber: Decimal
    sucursal_id: Optional[UUID] = None


class MovimientoContableCreate(MovimientoContableBase):
    pass


class MovimientoContable(MovimientoContableBase):
    id: UUID
    asiento_id: UUID
    cuenta: Optional[CuentaContable] = None

    model_config = ConfigDict(from_attributes=True)


# Asiento Contable
class AsientoContableBase(BaseModel):
    fecha: datetime
    glosa: str
    origen: str
    origen_id: Optional[int] = None
    estado: str = "CONFIRMADO"
    sucursal_id: Optional[int] = None


class AsientoContableCreate(AsientoContableBase):
    movimientos: List[MovimientoContableCreate]


class AsientoContable(AsientoContableBase):
    id: UUID
    numero: Optional[int] = None
    empresa_id: UUID
    usuario_id: UUID
    created_at: datetime
    movimientos: List[MovimientoContable] = []

    model_config = ConfigDict(from_attributes=True)


# --- Reportes Contables Schemas ---


class LibroAuxiliarItem(BaseModel):
    fecha: datetime
    tipo_documento: str  # Boleta, Factura, etc.
    folio: Optional[str] = None
    rut_contraparte: Optional[str] = None  # Cliente o Proveedor
    razon_social: Optional[str] = None
    monto_neto: Decimal
    monto_iva: Decimal
    monto_total: Decimal

    model_config = ConfigDict(from_attributes=True)


class BalanceItem(BaseModel):
    cuenta_codigo: str
    cuenta_nombre: str
    saldo_anterior: Decimal = Decimal("0.00")
    debitos: Decimal = Decimal("0.00")
    creditos: Decimal = Decimal("0.00")
    saldo_final: Decimal = Decimal("0.00")

    model_config = ConfigDict(from_attributes=True)


class Balance8ColumnasItem(BaseModel):
    codigo: str
    nombre: str
    tipo: str
    suma_debe: Decimal
    suma_haber: Decimal
    saldo_deudor: Decimal
    saldo_acreedor: Decimal
    activo: Decimal
    pasivo: Decimal
    perdida: Decimal
    ganancia: Decimal


class Balance8ColumnasResponse(BaseModel):
    detalle: List[Balance8ColumnasItem]
    totales: dict[str, Decimal]


class FacturaOut(BaseModel):
    folio: str
    monto_neto: Decimal
    monto_iva: Decimal
    monto_total: Decimal

    model_config = ConfigDict(from_attributes=True)
