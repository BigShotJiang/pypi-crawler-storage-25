from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.finanzas import models
from app.core_modules.finanzas.accounting_service.accounts import (
    get_cuenta_by_codigo,
    init_pcu_chileno,
)


def ensure_tenant(db: Session, empresa_id: UUID) -> None:
    current_tenant = db.info.get("empresa_id", None)
    if current_tenant is None:
        db.info["empresa_id"] = empresa_id
        return
    if current_tenant != empresa_id:
        raise RuntimeError("Tenant isolation violation: empresa_id mismatch")


def get_required_cuenta(db: Session, codigo: str, empresa_id: UUID) -> models.CuentaContable:
    cuenta = get_cuenta_by_codigo(db, codigo, empresa_id)
    if not cuenta:
        init_pcu_chileno(db, empresa_id)
        cuenta = get_cuenta_by_codigo(db, codigo, empresa_id)
    if not cuenta:
        raise ValueError(f"Cuenta contable no encontrada: {codigo}")
    return cuenta
