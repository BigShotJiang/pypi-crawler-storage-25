from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session, selectinload

from app.core_modules.finanzas import models
from app.core_modules.finanzas.accounting_service.entries.utils import (
    ensure_tenant,
    get_required_cuenta,
)
from app.core_modules.finanzas.accounting_service.accounts import get_cuenta_by_codigo
from app.core_modules.finanzas.accounting_service.periods import (
    check_periodo_abierto,
    get_fecha_contable_valida,
)


def create_expense_entry(
    db: Session,
    gasto_id: UUID,
    descripcion: str,
    total: Decimal,
    categoria: str,
    sucursal_id: UUID,
    empresa_id: UUID,
    usuario_id: UUID,
) -> models.AsientoContable:
    ensure_tenant(db, empresa_id)
    total_dec = Decimal(str(total))
    fecha = datetime.now()
    check_periodo_abierto(db, empresa_id, fecha)

    categoria_norm = (categoria or "").strip().lower()
    if "arriend" in categoria_norm:
        codigo_gasto = "5.2.02"
    elif "remuner" in categoria_norm or "suel" in categoria_norm:
        codigo_gasto = "5.2.01"
    elif "insum" in categoria_norm:
        codigo_gasto = "5.2.04"
    else:
        codigo_gasto = "5.2.06"

    cuenta_gasto = get_required_cuenta(db, codigo_gasto, empresa_id)
    cuenta_caja = get_required_cuenta(db, "1.1.01.01", empresa_id)

    asiento = models.AsientoContable(
        fecha=fecha,
        glosa=f"Gasto: {descripcion}",
        origen="GASTOS",
        origen_id=str(gasto_id),
        estado="CONFIRMADO",
        empresa_id=empresa_id,
        sucursal_id=sucursal_id,
        usuario_id=usuario_id,
    )
    db.add(asiento)
    db.flush()

    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_gasto.id,
            debe=total_dec,
            haber=Decimal("0.00"),
            sucursal_id=sucursal_id,
        )
    )
    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_caja.id,
            debe=Decimal("0.00"),
            haber=total_dec,
            sucursal_id=sucursal_id,
        )
    )

    return asiento


def create_expense_payment_entry(
    db: Session,
    gasto_id: UUID,
    monto: Decimal,
    sucursal_id: UUID,
    empresa_id: UUID,
    usuario_id: UUID,
) -> models.AsientoContable:
    from app.core_modules.finanzas import models as fin_models

    ensure_tenant(db, empresa_id)
    gasto = (
        db.query(fin_models.Gasto)
        .filter(fin_models.Gasto.id == gasto_id, fin_models.Gasto.empresa_id == empresa_id)
        .first()
    )
    descripcion = gasto.descripcion if gasto else str(gasto_id)

    monto_dec = Decimal(str(monto))
    fecha = datetime.now()
    check_periodo_abierto(db, empresa_id, fecha)

    cuenta_proveedores = get_cuenta_by_codigo(db, "2.1.01.01", empresa_id) or get_cuenta_by_codigo(
        db, "2.1.01", empresa_id
    )
    if not cuenta_proveedores:
        raise ValueError("Cuenta proveedores no encontrada (2.1.01.01 / 2.1.01)")
    cuenta_caja = get_required_cuenta(db, "1.1.01.01", empresa_id)

    asiento = models.AsientoContable(
        fecha=fecha,
        glosa=f"Pago de Deuda Gasto: {descripcion}",
        origen="GASTOS_PAGO",
        origen_id=str(gasto_id),
        estado="CONFIRMADO",
        empresa_id=empresa_id,
        sucursal_id=sucursal_id,
        usuario_id=usuario_id,
    )
    db.add(asiento)
    db.flush()

    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_proveedores.id,
            debe=monto_dec,
            haber=Decimal("0.00"),
            sucursal_id=sucursal_id,
        )
    )
    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_caja.id,
            debe=Decimal("0.00"),
            haber=monto_dec,
            sucursal_id=sucursal_id,
        )
    )

    return asiento


def revert_expense_related_entries(
    db: Session,
    gasto_id: UUID,
    empresa_id: UUID,
    usuario_id: UUID,
) -> list[models.AsientoContable]:
    ensure_tenant(db, empresa_id)
    origen_id = str(gasto_id)
    originales = (
        db.query(models.AsientoContable)
        .options(selectinload(models.AsientoContable.movimientos))
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.origen_id == origen_id,
            models.AsientoContable.estado == "CONFIRMADO",
        )
        .all()
    )

    reversos: list[models.AsientoContable] = []
    for asiento in originales:
        fecha_reversion = get_fecha_contable_valida(db, empresa_id, asiento.fecha)
        check_periodo_abierto(db, empresa_id, fecha_reversion)

        reversion = models.AsientoContable(
            fecha=fecha_reversion,
            glosa=f"ANULACIÓN: {asiento.glosa}",
            origen=asiento.origen,
            origen_id=asiento.origen_id,
            estado="CONFIRMADO",
            empresa_id=empresa_id,
            sucursal_id=asiento.sucursal_id,
            usuario_id=usuario_id,
            metodo_pago=asiento.metodo_pago,
            rut_tercero=asiento.rut_tercero,
            razon_social_tercero=asiento.razon_social_tercero,
            tipo_documento=asiento.tipo_documento,
            folio_documento=asiento.folio_documento,
        )
        db.add(reversion)
        db.flush()

        for mov in asiento.movimientos:
            db.add(
                models.MovimientoContable(
                    asiento_id=reversion.id,
                    empresa_id=empresa_id,
                    cuenta_id=mov.cuenta_id,
                    debe=Decimal(str(mov.haber or 0)),
                    haber=Decimal(str(mov.debe or 0)),
                    sucursal_id=mov.sucursal_id,
                )
            )

        asiento.estado = "ANULADO"
        db.add(asiento)
        reversos.append(reversion)

    return reversos
