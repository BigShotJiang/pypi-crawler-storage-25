from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.finanzas import models, schemas
from app.core_modules.finanzas.accounting_service.periods import check_periodo_abierto
from app.core_modules.finanzas.accounting_service.entries.utils import ensure_tenant


def create_asiento(
    db: Session,
    asiento_in: schemas.AsientoContableCreate,
    usuario_id: UUID,
    empresa_id: UUID,
) -> models.AsientoContable:
    ensure_tenant(db, empresa_id)
    check_periodo_abierto(db, empresa_id, asiento_in.fecha)

    total_debe = sum(m.debe for m in asiento_in.movimientos)
    total_haber = sum(m.haber for m in asiento_in.movimientos)
    if abs(total_debe - total_haber) > Decimal("0.01"):
        raise ValueError(
            f"Asiento desbalanceado: Debe {total_debe} != Haber {total_haber}"
        )

    asiento = models.AsientoContable(
        fecha=asiento_in.fecha,
        glosa=asiento_in.glosa,
        origen=asiento_in.origen,
        origen_id=asiento_in.origen_id,
        estado=asiento_in.estado,
        sucursal_id=asiento_in.sucursal_id,
        usuario_id=usuario_id,
        empresa_id=empresa_id,
    )
    db.add(asiento)
    db.flush()

    for mov_in in asiento_in.movimientos:
        mov = models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=mov_in.cuenta_id,
            debe=mov_in.debe,
            haber=mov_in.haber,
            sucursal_id=mov_in.sucursal_id,
        )
        db.add(mov)

    db.commit()
    db.refresh(asiento)
    return asiento


def has_asiento_for_origen(
    db: Session,
    *,
    empresa_id: UUID,
    origen: str,
    origen_id: str,
) -> bool:
    ensure_tenant(db, empresa_id)
    return (
        db.query(models.AsientoContable.id)
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.origen == origen,
            models.AsientoContable.origen_id == origen_id,
        )
        .first()
        is not None
    )
