from enum import Enum
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Numeric, Boolean, Date, Enum as SAEnum
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.sql import func, text
from app.core.database import Base, GUID
from app.core_modules.ventas.models import Producto
from app.core.utils.mixins import SoftDeleteMixin
from uuid import UUID
from typing import Optional
from decimal import Decimal
import uuid6


class EstadoGastoEnum(str, Enum):
    PENDIENTE = "PENDIENTE"
    PAGADO = "PAGADO"
    ANULADO = "ANULADO"


class Gasto(Base, SoftDeleteMixin):
    __tablename__ = "gastos"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    descripcion = Column(String, nullable=False)
    monto: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    fecha = Column(DateTime(timezone=True), default=func.now())
    fecha_vencimiento = Column(DateTime(timezone=True), nullable=True)  # Para Cuentas por Pagar
    categoria = Column(
        String, index=True, nullable=False
    )  # Arriendo, Insumos, Sueldos, etc.
    
    estado: Mapped[EstadoGastoEnum] = mapped_column(
        SAEnum(EstadoGastoEnum), default=EstadoGastoEnum.PAGADO, nullable=False, index=True
    )
    documento_referencia = Column(String, nullable=True) # Factura, Boleta, etc.

    # Foreign Keys
    proveedor_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("proveedores.id"), nullable=True, index=True
    )
    sucursal_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    metodo_pago_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("metodos_pago.id"), nullable=False, index=True
    )
    asiento_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("asientos_contables.id"), nullable=True, index=True
    )

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    proveedor = relationship("app.core_modules.compras.models.Proveedor", backref="gastos")
    sucursal = relationship(
        "app.core_modules.sistema.models.Sucursal", backref="gastos"
    )
    empresa = relationship("app.core_modules.sistema.models.Empresa", backref="gastos")
    metodo_pago = relationship("app.core_modules.sistema.models.MetodoPago")
    asiento = relationship("AsientoContable")



class PrecioProducto(Base):
    __tablename__ = "precios_productos"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    producto_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("productos.id"), nullable=False, index=True)
    sucursal_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("sucursales.id"), nullable=True, index=True
    )  # Null = Global price
    tipo_cliente = Column(String, nullable=True, index=True)  # Null = Default price
    precio: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)

    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Relationships
    producto = relationship(Producto)
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")
    empresa = relationship("app.core_modules.sistema.models.Empresa")


class PeriodoContable(Base):
    __tablename__ = "periodos_contables"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    nombre = Column(String, nullable=False) # e.g. "2026-01"
    fecha_inicio = Column(DateTime(timezone=True), nullable=False)
    fecha_fin = Column(DateTime(timezone=True), nullable=False)
    cerrado = Column(Boolean, default=False, nullable=False)
    fecha_cierre = Column(DateTime(timezone=True), nullable=True)
    usuario_cierre_id: Mapped[Optional[UUID]] = mapped_column(GUID, ForeignKey("usuarios.id"), nullable=True)

    # Relationships
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    usuario_cierre = relationship("app.core_modules.sistema.models.Usuario")


# -----------------------------------------------------------------------------
# CONTABILIDAD (NUEVO CORE)
# -----------------------------------------------------------------------------


class CuentaContable(Base):
    __tablename__ = "cuentas_contables"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    codigo = Column(String, index=True, nullable=False)  # e.g. "1.1.01"
    nombre = Column(String, nullable=False)
    tipo_cuenta = Column(
        String, nullable=False
    )  # ACTIVO, PASIVO, PATRIMONIO, INGRESO, GASTO
    nivel = Column(Integer, nullable=False)  # 1, 2, 3, 4...
    es_imputable = Column(
        Boolean, default=True
    )  # True si puede recibir movimientos (nodo hoja)

    padre_id: Mapped[Optional[UUID]] = mapped_column(GUID, ForeignKey("cuentas_contables.id"), nullable=True)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Relationships
    padre = relationship("CuentaContable", remote_side=[id], backref="hijas")
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    movimientos = relationship("MovimientoContable", back_populates="cuenta")


class AsientoContable(Base):
    __tablename__ = "asientos_contables"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    numero = Column(Integer, index=True, nullable=True)  # Correlativo anual
    fecha = Column(DateTime(timezone=True), default=func.now(), nullable=False)
    glosa = Column(String, nullable=False)

    # Origen (Polimorfismo simple)
    origen = Column(String, nullable=False)  # VENTAS, COMPRAS, MANUAL, SUELDOS
    origen_id = Column(String, nullable=True)  # ID del origen (puede ser UUID o Int)

    # Campos para Libros Auxiliares (DTE)
    tipo_documento = Column(String, nullable=True)  # 33, 39, 56, etc.
    folio_documento = Column(String, nullable=True)
    rut_tercero = Column(String, index=True, nullable=True)
    razon_social_tercero = Column(String, nullable=True)

    estado = Column(String, default="CONFIRMADO")  # BORRADOR, CONFIRMADO, ANULADO
    metodo_pago = Column(String, nullable=True)

    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    sucursal_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("sucursales.id"), nullable=True, index=True
    )  # Opcional, para filtro
    usuario_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("usuarios.id"), nullable=False
    )  # Quien generó el asiento

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")
    usuario = relationship("app.core_modules.sistema.models.Usuario")
    movimientos = relationship(
        "MovimientoContable", back_populates="asiento", cascade="all, delete-orphan"
    )


class MovimientoContable(Base):
    __tablename__ = "movimientos_contables"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    asiento_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("asientos_contables.id"), nullable=False, index=True
    )
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    cuenta_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("cuentas_contables.id"), nullable=False, index=True
    )

    debe: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=0.00, nullable=False)
    haber: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=0.00, nullable=False)

    # Centro de Costo / Sucursal Específica para este movimiento
    sucursal_id: Mapped[Optional[UUID]] = mapped_column(GUID, ForeignKey("sucursales.id"), nullable=True, index=True)

    # Relationships
    asiento = relationship("AsientoContable", back_populates="movimientos")
    cuenta = relationship("CuentaContable", back_populates="movimientos")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")


# -----------------------------------------------------------------------------
# CONFIGURACIÓN DE IMPUESTOS (FUENTE DE VERDAD)
# -----------------------------------------------------------------------------
class ConfiguracionImpuesto(Base):
    __tablename__ = "configuracion_impuestos"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    codigo = Column(String(30), nullable=False, index=True)  # Ej: IVA, RET_2CAT
    nombre = Column(String(120), nullable=True)
    tasa: Mapped[Decimal] = mapped_column(Numeric(12, 4), nullable=False)
    vigente_desde = Column(Date, nullable=True)
    vigente_hasta = Column(Date, nullable=True)
    activo = Column(Boolean, nullable=False, server_default=text("true"))

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    empresa = relationship("app.core_modules.sistema.models.Empresa")

