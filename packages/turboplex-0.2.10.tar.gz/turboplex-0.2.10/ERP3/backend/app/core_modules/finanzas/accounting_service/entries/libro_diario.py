from datetime import datetime
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import Session, selectinload

from app.core_modules.finanzas import models
from app.core_modules.finanzas.accounting_service.entries.utils import ensure_tenant


def get_libro_diario(
    db: Session,
    empresa_id: UUID,
    fecha_inicio: datetime,
    fecha_fin: datetime,
    sucursal_id: Optional[UUID] = None,
) -> list[models.AsientoContable]:
    ensure_tenant(db, empresa_id)
    query = (
        db.query(models.AsientoContable)
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.estado == "CONFIRMADO",
            models.AsientoContable.fecha >= fecha_inicio,
            models.AsientoContable.fecha <= fecha_fin,
        )
        .options(
            selectinload(models.AsientoContable.movimientos).selectinload(
                models.MovimientoContable.cuenta
            )
        )
    )

    if sucursal_id:
        query = query.filter(models.AsientoContable.sucursal_id == sucursal_id)

    return query.order_by(
        models.AsientoContable.fecha.asc(), models.AsientoContable.id.asc()
    ).all()
