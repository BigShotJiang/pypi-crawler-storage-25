from typing import List, Any, Dict, cast, Optional
from datetime import datetime, date
from uuid import UUID
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.api import deps
from app.core.infrastructure.events import event_dispatcher
from app.core.auth.rbac import ScopesChecker, resolve_user_role_code, get_user_scopes
from app.core_modules.finanzas import models, schemas, accounting_service
from app.core_modules.finanzas.egresos_service import (
    crear_egreso,
    listar_egresos,
    actualizar_egreso,
    eliminar_egreso,
)
from app.core_modules.compras import models as compras_models
from app.core_modules.compras import schemas as compras_schemas
from app.core_modules.ventas import models as ventas_models
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    AuditLog,
    AuditSeverity,
)

router = APIRouter(dependencies=[Depends(deps.check_module_access("FINANZAS"))])


# -----------------------------------------------------------------------------
# DASHBOARD
# -----------------------------------------------------------------------------
@router.get("/finanzas/dashboard-stats", tags=["Dashboard"])
def get_dashboard_stats(
    fecha_inicio: Optional[date] = Query(None),
    fecha_fin: Optional[date] = Query(None),
    sucursal_id: Optional[UUID] = Query(None),
    moneda: Optional[str] = Query(None),
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene estadísticas avanzadas para el dashboard de finanzas.
    """
    # Filtros base
    filters_ventas = [ventas_models.Venta.empresa_id == current_company.id]
    filters_compras = [compras_models.OrdenCompra.empresa_id == current_company.id]
    filters_gastos = [
        models.Gasto.empresa_id == current_company.id,
        models.Gasto.estado != models.EstadoGastoEnum.ANULADO
    ]

    if sucursal_id:
        filters_ventas.append(ventas_models.Venta.sucursal_id == sucursal_id)
        filters_compras.append(compras_models.OrdenCompra.sucursal_id == sucursal_id)
        filters_gastos.append(models.Gasto.sucursal_id == sucursal_id)
    
    if moneda:
        filters_ventas.append(ventas_models.Venta.moneda == moneda)

    # Filtros de Fecha (Rango)
    if fecha_inicio:
        filters_ventas.append(func.date(ventas_models.Venta.fecha) >= fecha_inicio)
        filters_compras.append(func.date(compras_models.OrdenCompra.fecha_emision) >= fecha_inicio)
        filters_gastos.append(func.date(models.Gasto.fecha) >= fecha_inicio)
    
    if fecha_fin:
        filters_ventas.append(func.date(ventas_models.Venta.fecha) <= fecha_fin)
        filters_compras.append(func.date(compras_models.OrdenCompra.fecha_emision) <= fecha_fin)
        filters_gastos.append(func.date(models.Gasto.fecha) <= fecha_fin)

    # 1. KPIs
    # Ingresos (Ventas Completadas)
    ingresos = (
        db.query(func.sum(ventas_models.Venta.total))
        .filter(*filters_ventas, ventas_models.Venta.estado == ventas_models.EstadoVentaEnum.COMPLETADA)
        .scalar()
        or Decimal("0.00")
    )

    # Gastos (Total Gastos Devengados: PAGADO + PENDIENTE)
    gastos = (
        db.query(func.sum(models.Gasto.monto))
        .filter(*filters_gastos, models.Gasto.estado.in_([models.EstadoGastoEnum.PAGADO, models.EstadoGastoEnum.PENDIENTE]))
        .scalar()
        or Decimal("0.00")
    )

    # CXC (Ventas Pendientes - Saldo Vivo en el periodo)
    cxc = (
        db.query(func.sum(ventas_models.Venta.total))
        .filter(*filters_ventas, ventas_models.Venta.estado == ventas_models.EstadoVentaEnum.PENDIENTE)
        .scalar()
        or Decimal("0.00")
    )

    # CXP (Gastos Pendientes de Pago)
    cxp = (
        db.query(func.sum(models.Gasto.monto))
        .filter(*filters_gastos, models.Gasto.estado == models.EstadoGastoEnum.PENDIENTE)
        .scalar()
        or Decimal("0.00")
    )

    # Cálculos derivados
    utilidad = ingresos - gastos
    margen = (utilidad / ingresos * 100) if ingresos > 0 else Decimal("0.00")
    
    # Flujo Real (Ingresos Reales - Gastos Pagados)
    gastos_pagados = (
        db.query(func.sum(models.Gasto.monto))
        .filter(*filters_gastos, models.Gasto.estado == models.EstadoGastoEnum.PAGADO)
        .scalar()
        or Decimal("0.00")
    )
    flujo = ingresos - gastos_pagados  # Cash Flow Neto Real
    variacion = Decimal("0.00")  # Placeholder para lógica compleja de periodo anterior

    # 2. Gráficos
    # Cash Flow (Diario)
    # Agrupar ingresos y gastos PAGADOS por día
    chart_ingresos = (
        db.query(func.date(ventas_models.Venta.fecha).label("fecha"), func.sum(ventas_models.Venta.total))
        .filter(*filters_ventas, ventas_models.Venta.estado == ventas_models.EstadoVentaEnum.COMPLETADA)
        .group_by(func.date(ventas_models.Venta.fecha))
        .all()
    )
    chart_gastos = (
        db.query(func.date(models.Gasto.fecha).label("fecha"), func.sum(models.Gasto.monto))
        .filter(*filters_gastos, models.Gasto.estado == models.EstadoGastoEnum.PAGADO)
        .group_by(func.date(models.Gasto.fecha))
        .all()
    )

    # Fusionar series temporalmente
    timeline_data = {}
    for fecha, monto in chart_ingresos:
        f_str = str(fecha)
        if f_str not in timeline_data:
            timeline_data[f_str] = {"ingresos": 0, "gastos": 0}
        timeline_data[f_str]["ingresos"] = float(monto)
    
    for fecha, monto in chart_gastos:
        f_str = str(fecha)
        if f_str not in timeline_data:
            timeline_data[f_str] = {"ingresos": 0, "gastos": 0}
        timeline_data[f_str]["gastos"] = float(monto)
    
    # Ordenar por fecha
    chart_cash_flow = sorted([{"fecha": k, **v} for k, v in timeline_data.items()], key=lambda x: x["fecha"])

    # Gastos por Categoría (Devengado)
    chart_gastos_cat = (
        db.query(models.Gasto.categoria, func.sum(models.Gasto.monto))
        .filter(*filters_gastos, models.Gasto.estado.in_([models.EstadoGastoEnum.PAGADO, models.EstadoGastoEnum.PENDIENTE]))
        .group_by(models.Gasto.categoria)
        .all()
    )
    chart_gastos_categoria = [{"categoria": c, "monto": float(m)} for c, m in chart_gastos_cat]

    # 3. Tablas (Top 5)
    # Top CXC (Ventas Pendientes más antiguas)
    top_cxc_data = (
        db.query(ventas_models.Venta)
        .filter(*filters_ventas, ventas_models.Venta.estado == ventas_models.EstadoVentaEnum.PENDIENTE)
        .order_by(ventas_models.Venta.fecha.asc())
        .limit(5)
        .all()
    )
    # Serializar básico
    top_cxc = []
    for v in top_cxc_data:
        cliente_nombre = v.cliente.nombre if v.cliente else "Desconocido"
        top_cxc.append({
            "id": str(v.id),
            "entidad": cliente_nombre,
            "folio": v.folio or "S/F",
            "fecha": v.fecha,
            "monto": v.total
        })

    # Top CXP (Gastos Pendientes más antiguos)
    top_cxp_data = (
        db.query(models.Gasto)
        .filter(*filters_gastos, models.Gasto.estado == models.EstadoGastoEnum.PENDIENTE)
        .order_by(models.Gasto.fecha_vencimiento.asc().nulls_last(), models.Gasto.fecha.asc())
        .limit(5)
        .all()
    )
    top_cxp = []
    for g in top_cxp_data:
        proveedor_nombre = g.proveedor.nombre if g.proveedor else "Desconocido"
        fecha_mostrar = g.fecha_vencimiento or g.fecha
        top_cxp.append({
            "id": str(g.id),
            "entidad": proveedor_nombre,
            "folio": g.documento_referencia or "S/F",
            "fecha": fecha_mostrar,
            "monto": g.monto
        })

    return {
        "kpis": {
            "ingresos": ingresos,
            "gastos": gastos,
            "utilidad": utilidad,
            "margen": margen,
            "cxc": cxc,
            "cxp": cxp,
            "flujo": flujo,
            "variacion": variacion
        },
        "charts": {
            "cash_flow": chart_cash_flow,
            "gastos_categoria": chart_gastos_categoria
        },
        "tables": {
            "top_cxc": top_cxc,
            "top_cxp": top_cxp
        }
    }


# -----------------------------------------------------------------------------
# PROVEEDORES
# -----------------------------------------------------------------------------
@router.post(
    "/proveedores/",
    response_model=compras_schemas.Proveedor,
    tags=["Proveedores"],
    deprecated=True,
    description="Deprecated: Use /api/v1/compras/proveedores/ instead",
)
def create_proveedor(
    *,
    db: Session = Depends(deps.get_db),
    proveedor_in: compras_schemas.ProveedorCreate,
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    proveedor = compras_models.Proveedor(
        **proveedor_in.model_dump(), empresa_id=current_company.id
    )
    db.add(proveedor)
    db.commit()
    db.refresh(proveedor)
    return proveedor


@router.get(
    "/proveedores/",
    response_model=List[compras_schemas.Proveedor],
    tags=["Proveedores"],
    deprecated=True,
    description="Deprecated: Use /api/v1/compras/proveedores/ instead",
)
def read_proveedores(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return (
        db.query(compras_models.Proveedor)
        .filter(compras_models.Proveedor.empresa_id == current_company.id)
        .offset(skip)
        .limit(limit)
        .all()
    )


# -----------------------------------------------------------------------------
# GASTOS
# -----------------------------------------------------------------------------
@router.post("/gastos/", response_model=schemas.Gasto, tags=["Gastos"])
def create_gasto(
    *,
    db: Session = Depends(deps.get_db),
    gasto_in: schemas.GastoCreate,
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Registra un gasto y genera automáticamente su asiento contable.
    """
    gasto = crear_egreso(
        db=db,
        gasto_in=gasto_in,
        empresa_id=current_company.id,
        usuario_id=current_user.id,
    )
    return gasto


@router.get("/gastos/", response_model=List[schemas.Gasto], tags=["Gastos"])
def read_gastos(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    return listar_egresos(db, current_company.id, skip, limit)


@router.put("/gastos/{gasto_id}", response_model=schemas.Gasto, tags=["Gastos"])
def update_gasto(
    gasto_id: UUID,
    payload: schemas.GastoUpdate,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    gasto = actualizar_egreso(db, gasto_id, current_company.id, payload, current_user.id)
    if not gasto:
        raise HTTPException(status_code=404, detail="Gasto no encontrado")
    return gasto


@router.delete("/gastos/{gasto_id}", tags=["Gastos"])
def delete_gasto(
    gasto_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_get_current_user)
    if False
    else Depends(deps.get_current_user),  # keep import
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Dict[str, bool]:
    ok = eliminar_egreso(db, gasto_id, current_company.id)
    if not ok:
        raise HTTPException(status_code=404, detail="Gasto no encontrado")
    return {"ok": True}


# -----------------------------------------------------------------------------
# CONTABILIDAD
# -----------------------------------------------------------------------------


@router.post("/contabilidad/init-pcu", tags=["Contabilidad"])
def init_pcu(
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Inicializa el Plan de Cuentas Chileno para la empresa actual.
    """
    accounting_service.init_pcu_chileno(db, current_company.id)
    return {"msg": "Plan de cuentas inicializado correctamente"}


@router.get(
    "/contabilidad/cuentas",
    response_model=List[schemas.CuentaContable],
    tags=["Contabilidad"],
)
def read_cuentas(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 1000,
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene el plan de cuentas.
    """
    cuentas = (
        db.query(models.CuentaContable)
        .filter(models.CuentaContable.empresa_id == current_company.id)
        .order_by(models.CuentaContable.codigo.asc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return cuentas


@router.post(
    "/contabilidad/asientos",
    response_model=schemas.AsientoContable,
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:post"], mode="all"))],
)
def create_asiento(
    *,
    db: Session = Depends(deps.get_db),
    asiento_in: schemas.AsientoContableCreate,
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Crea un nuevo asiento contable.
    """
    try:
        asiento = accounting_service.create_asiento(
            db, asiento_in, current_user.id, current_company.id
        )
        return asiento
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get(
    "/contabilidad/asientos",
    response_model=List[schemas.AsientoContable],
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:post"], mode="all"))],
)
def read_asientos(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Lista los asientos contables.
    """
    asientos = (
        db.query(models.AsientoContable)
        .filter(models.AsientoContable.empresa_id == current_company.id)
        .order_by(models.AsientoContable.fecha.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return asientos


@router.get(
    "/contabilidad/libro-diario",
    response_model=List[schemas.AsientoContable],
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:post"], mode="all"))],
)
def read_libro_diario(
    fecha_inicio: datetime,
    fecha_fin: datetime,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene el Libro Diario (Asientos confirmados en rango).
    """
    return accounting_service.get_libro_diario(
        db, current_company.id, fecha_inicio, fecha_fin
    )


@router.get(
    "/contabilidad/libro-auxiliar",
    response_model=List[schemas.LibroAuxiliarItem],
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:post"], mode="all"))],
)
def read_libro_auxiliar(
    tipo: str = Query(..., description="VENTAS o COMPRAS"),
    mes: int = Query(..., ge=1, le=12),
    anio: int = Query(..., ge=2000, le=2100),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene el Libro Auxiliar de Compras o Ventas para un mes/año.
    """
    if tipo not in ["VENTAS", "COMPRAS"]:
        raise HTTPException(status_code=400, detail="Tipo debe ser VENTAS o COMPRAS")

    return accounting_service.get_libro_auxiliar(
        db, current_company.id, tipo, mes, anio
    )


@router.get(
    "/contabilidad/balance-8-columnas",
    response_model=schemas.Balance8ColumnasResponse,
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:ledger:read"], mode="all"))],
)
def read_balance_8_columnas(
    fecha_inicio: Optional[date] = Query(None),
    fecha_fin: Optional[date] = Query(None),
    incluir_cierre: bool = Query(False),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene el Balance Tributario de 8 Columnas.
    """
    dt_inicio = datetime.combine(fecha_inicio, datetime.min.time()) if fecha_inicio else None
    dt_fin = datetime.combine(fecha_fin, datetime.max.time()) if fecha_fin else None
    
    return accounting_service.generate_balance_8_columns(
        db, 
        current_company.id, 
        dt_inicio, 
        dt_fin, 
        incluir_cierre
    )


@router.get(
    "/contabilidad/periodos/{periodo_id}/integridad",
    response_model=schemas.IntegridadPeriodo,
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:period:read"], mode="all"))],
)
def check_integridad(
    periodo_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Verifica la integridad del periodo (Semáforo) antes del cierre.
    """
    return accounting_service.check_integridad_periodo(
        db, current_company.id, periodo_id
    )


@router.post(
    "/contabilidad/periodos/{periodo_id}/cierre",
    response_model=schemas.PeriodoContable,
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:period:close"], mode="all"))],
)
def cerrar_periodo(
    periodo_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Ejecuta el Cierre Mensual (The Hard Lock).
    """
    return accounting_service.cerrar_periodo(
        db, current_company.id, periodo_id, current_user.id
    )


@router.post(
    "/contabilidad/periodos/{periodo_id}/reapertura",
    response_model=schemas.PeriodoContable,
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:period:reopen"], mode="all"))],
)
def reabrir_periodo(
    periodo_id: UUID,
    motivo: str = Query(..., min_length=10, description="Motivo explícito para la reapertura"),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Reapertura de Periodo (Super-Admin Only).
    """
    return accounting_service.abrir_periodo(
        db, current_company.id, periodo_id, current_user.id, motivo
    )


@router.get(
    "/contabilidad/periodos/{periodo_id}/audit-logs",
    response_model=List[schemas.AuditLogLite],
    tags=["Contabilidad"],
    dependencies=[Depends(ScopesChecker(["finanzas:period:read"], mode="all"))],
)
def get_periodo_audit_logs(
    periodo_id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtiene los logs de auditoría asociados a un periodo contable.
    """
    logs = (
        db.query(AuditLog)
        .filter(AuditLog.resource == f"PeriodoContable:{periodo_id}")
        .order_by(AuditLog.created_at.desc())
        .all()
    )
    return logs


@router.post(
    "/compras/ordenes-compra/{orden_id}/aprobar",
    response_model=compras_schemas.OrdenCompra,
    tags=["Compras"],
    deprecated=True,
    description="Deprecated: Use /api/v1/compras/ordenes-compra/{orden_id}/aprobar instead",
)
async def approve_orden_compra(
    orden_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    required_roles = ["ADM"]
    required_scopes = ["compras:approve"]
    role_code = resolve_user_role_code(db, current_user.id, current_company.id) or ""
    scopes = get_user_scopes(db, current_user.id, current_company.id)
    allowed = role_code in required_roles or any(s in scopes for s in required_scopes)
    if not allowed:
        log = AuditLog(
            actor_id=current_user.id,
            action="RBAC_ROLE_SCOPE_DENIED",
            resource=f"POST /compras/ordenes-compra/{orden_id}/aprobar",
            severity=AuditSeverity.CRITICAL,
            changes={
                "empresa_id": str(current_company.id),
                "required_roles": required_roles,
                "required_scopes": required_scopes,
                "user_role": role_code,
                "user_scopes": sorted(list(scopes)),
            },
            ip_address=None,
        )
        db.add(log)
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acceso denegado por política RBAC",
        )
    orden = (
        db.query(compras_models.OrdenCompra)
        .filter(
            compras_models.OrdenCompra.id == orden_id,
            compras_models.OrdenCompra.empresa_id == current_company.id,
        )
        .first()
    )
    if not orden:
        raise HTTPException(status_code=404, detail="Orden de compra no encontrada")
    if orden.estado in ["RECIBIDA", "CANCELADA"]:
        raise HTTPException(
            status_code=400,
            detail="No se puede aprobar una orden de compra finalizada",
        )
    orden_any = cast(Any, orden)
    orden_any.estado = "ENVIADA"
    db.add(orden)
    db.commit()
    db.refresh(orden)
    payload = {
        "empresa_id": current_company.id,
        "orden_compra_id": orden.id,
        "estado": orden.estado,
        "total": orden.total,
        "proveedor_id": orden.proveedor_id,
        "sucursal_id": orden.sucursal_id,
        "bodega_id": orden.bodega_id,
        "usuario_id": current_user.id,
    }
    await event_dispatcher.dispatch("orden_compra.aprobada", payload)
    return compras_schemas.OrdenCompra.model_validate(orden)
