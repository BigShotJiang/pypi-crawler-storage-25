from sqlalchemy.orm import Session
from fastapi import HTTPException
from uuid import UUID
from app.core_modules.ventas.models import Venta
from app.core_modules.compras.models import OrdenCompra, OrdenCompraDetalle, Proveedor
from app.core_modules.sistema.models import Empresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto


def process_intercompany_transaction(db: Session, venta_id: UUID, user_id: UUID):
    """
    Analiza una Venta aprobada. Si el Cliente pertenece al mismo Holding (coincidencia de RUT con otra Empresa),
    genera automáticamente la Orden de Compra espejo en la empresa destino.
    """

    # 1. Obtener Venta y Validar
    venta = db.query(Venta).filter(Venta.id == venta_id).first()
    if not venta:
        raise HTTPException(status_code=404, detail="Venta no encontrada")

    cliente = venta.cliente
    if not cliente.rut:
        return None  # No se puede validar Intercompany sin RUT

    source_company = venta.empresa

    # 2. Buscar si el RUT del Cliente corresponde a una Empresa interna (que no sea la misma de origen)
    target_company = (
        db.query(Empresa)
        .filter(Empresa.rut == cliente.rut, Empresa.id != source_company.id)
        .first()
    )

    if not target_company:
        return None  # No es una venta Intercompany

    # 3. Validar Configuración Intercompany en Destino
    # Necesitamos encontrar a la Empresa Origen como Proveedor en la Empresa Destino
    if not source_company.rut:
        raise HTTPException(
            status_code=400,
            detail=f"La empresa origen {source_company.nombre} no tiene RUT configurado.",
        )

    proveedor_mirror = (
        db.query(Proveedor)
        .filter(
            Proveedor.empresa_id == target_company.id,
            Proveedor.rut == source_company.rut,
        )
        .first()
    )

    if not proveedor_mirror:
        # Opcional: Auto-crear proveedor si no existe?
        # Por seguridad, mejor pedir configuración previa.
        raise HTTPException(
            status_code=400,
            detail=f"Error Intercompany: La empresa {source_company.nombre} (RUT {source_company.rut}) no está registrada como Proveedor en {target_company.nombre}.",
        )

    # 4. Determinar Sucursal y Bodega de Destino
    # Por defecto, usamos la Sucursal Principal y su Bodega Principal de la empresa destino
    # En una implementación avanzada, esto podría venir parametrizado en la Venta (e.g. "Dirección de Despacho" mapeada a Sucursal)

    target_sucursal = (
        db.query(Sucursal)
        .filter(Sucursal.empresa_id == target_company.id)
        .order_by(Sucursal.id.asc())
        .first()
    )
    if not target_sucursal:
        raise HTTPException(
            status_code=400,
            detail=f"La empresa destino {target_company.nombre} no tiene sucursales.",
        )

    target_bodega = (
        db.query(Bodega)
        .filter(Bodega.sucursal_id == target_sucursal.id)
        .order_by(Bodega.id.asc())
        .first()
    )
    if not target_bodega:
        raise HTTPException(
            status_code=400,
            detail=f"La sucursal destino {target_sucursal.nombre} no tiene bodegas.",
        )

    # 5. Generar Orden de Compra (OC)
    nueva_oc = OrdenCompra(
        folio=f"AUTO-IC-{venta.id}",  # Referencia a la venta original
        proveedor_id=proveedor_mirror.id,
        sucursal_id=target_sucursal.id,
        bodega_id=target_bodega.id,
        empresa_id=target_company.id,
        usuario_id=user_id,  # El usuario que aprobó la venta "crea" la OC
        estado="RECIBIDA",  # Asumimos recepción automática? O PENDIENTE?
        # Si es transferencia, usualmente implica movimiento físico.
        # "Generación de Espejo... al aprobar".
        # Si ponemos RECIBIDA, aumentamos stock inmediatamente.
        # Si ponemos PENDIENTE, alguien debe recepcionar.
        # El usuario pidió "Generar... Una OC". Dejemosla en PENDIENTE para proceso formal, o RECIBIDA si es automatización total.
        # Dado "Lean", y "Transferencia", a menudo se quiere inmediatez. Pero "OC" implica documento.
        # Vamos a dejarla como "PENDIENTE" para que Bodega destino confirme la recepción (control de inventario).
        total=venta.total,
    )
    db.add(nueva_oc)
    db.flush()  # Para tener ID

    # 6. Generar Detalles OC
    for det_venta in venta.detalles:
        # Necesitamos encontrar el Producto equivalente en la empresa destino
        # Match por SKU
        sku_origen = det_venta.producto.sku

        producto_destino = (
            db.query(Producto)
            .filter(
                Producto.empresa_id == target_company.id, Producto.sku == sku_origen
            )
            .first()
        )

        if not producto_destino:
            raise HTTPException(
                status_code=400,
                detail=f"Error Intercompany: El producto SKU {sku_origen} no existe en la empresa destino {target_company.nombre}.",
            )

        detalle_oc = OrdenCompraDetalle(
            orden_compra_id=nueva_oc.id,
            producto_id=producto_destino.id,
            cantidad=det_venta.cantidad,
            precio_unitario=det_venta.precio_unitario,  # Transferimos al mismo precio de la venta
            subtotal=det_venta.subtotal,
        )
        db.add(detalle_oc)

    # Nota: No movemos stock aquí porque la OC queda PENDIENTE.
    # Cuando se apruebe la OC, se aumentará el stock en target_bodega.

    return nueva_oc
