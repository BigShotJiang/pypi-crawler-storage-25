from datetime import datetime, timezone
from decimal import Decimal
from typing import List, Optional, cast
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.finanzas import models, schemas, accounting_service
from app.core.infrastructure.events import event_dispatcher
from app.core.infrastructure.config_manager import config_manager
from app.core_modules.crm.models import Notification
from app.core.exceptions import BusinessRuleError
import asyncio


def crear_egreso(
    db: Session, gasto_in: schemas.GastoCreate, empresa_id: UUID, usuario_id: UUID
) -> models.Gasto:
    monto_dec_in: Decimal = Decimal(str(gasto_in.monto))
    gasto_data = gasto_in.model_dump()
    if not gasto_data.get("fecha"):
        gasto_data["fecha"] = datetime.now(timezone.utc)

    gasto = models.Gasto(
        **gasto_data, empresa_id=empresa_id
    )
    db.add(gasto)
    db.flush()

    try:
        descripcion_str = cast(str, gasto.descripcion)
        categoria_str = cast(str, gasto.categoria)
        sucursal_uuid = cast(UUID, gasto.sucursal_id)
        asiento = accounting_service.create_expense_entry(
            db=db,
            gasto_id=gasto.id,
            descripcion=descripcion_str,
            total=monto_dec_in,
            categoria=categoria_str,
            sucursal_id=sucursal_uuid,
            empresa_id=empresa_id,
            usuario_id=usuario_id,
        )
    except Exception:
        asiento = None
    if asiento:
        gasto_any = cast(object, gasto)
        gasto_any.asiento_id = asiento.id
        db.add(gasto)
    db.commit()
    db.refresh(gasto)

    # Notificación por egreso alto (Ojo de Dios)
    try:
        umbral = Decimal(
            str(config_manager.get_setting("ALERTA_EGRESO_UMBRAL", default="1000000"))
        )  # 1M CLP default
    except Exception:
        umbral = Decimal("1000000")
    monto_dec = monto_dec_in

    if monto_dec >= umbral:
        # Crear notificación al usuario actual (y despacho de evento global para webhooks)
        notif = Notification(
            usuario_id=usuario_id,
            mensaje=f"ALERTA: Egreso elevado registrado (${monto_dec:,.0f}) - {gasto.categoria}",
            link_documento=f"/finance/egresos?cmp={empresa_id}",
            leido=False,
        )
        db.add(notif)
        db.commit()

        payload = {
            "empresa_id": empresa_id,
            "gasto_id": str(gasto.id),
            "monto": float(monto_dec),
            "categoria": gasto.categoria,
            "descripcion": gasto.descripcion,
            "threshold": float(umbral),
            "severity": "WARNING",
        }
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                event_dispatcher.dispatch("FINANZAS_EGRESO_MAYOR_UMBRAL", payload)
            )
        except RuntimeError:
            pass

    return gasto


def listar_egresos(
    db: Session, empresa_id: UUID, skip: int = 0, limit: int = 100
) -> List[models.Gasto]:
    return (
        db.query(models.Gasto)
        .filter(models.Gasto.empresa_id == empresa_id)
        .order_by(models.Gasto.fecha.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


def actualizar_egreso(
    db: Session, gasto_id: UUID, empresa_id: UUID, payload: schemas.GastoUpdate, usuario_id: UUID
) -> Optional[models.Gasto]:
    gasto = (
        db.query(models.Gasto)
        .filter(models.Gasto.id == gasto_id, models.Gasto.empresa_id == empresa_id)
        .first()
    )
    if not gasto:
        return None
    
    # Estado anterior para detectar transición
    estado_anterior = gasto.estado
    
    # REGLA DE ORO: Si ya está PAGADO, no se puede editar el MONTO.
    # El usuario debe anular (que revierte) y crear uno nuevo.
    new_monto = payload.monto
    if estado_anterior == models.EstadoGastoEnum.PAGADO and new_monto is not None:
        # Comparamos Decimales con seguridad
        if Decimal(str(new_monto)) != gasto.monto:
            raise BusinessRuleError(
                "No se puede editar el monto de un gasto PAGADO. "
                "Por favor, anule el gasto (lo que revertirá los asientos) y cree uno nuevo."
            )

    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(gasto, k, v)
    
    # Lógica de Transición de Estado: PENDIENTE -> PAGADO
    if estado_anterior == models.EstadoGastoEnum.PENDIENTE and gasto.estado == models.EstadoGastoEnum.PAGADO:
        # Generar segundo asiento (Pago de deuda)
        # Debe: Pasivo (CxP) / Haber: Caja
        accounting_service.create_expense_payment_entry(
            db=db,
            gasto_id=gasto.id,
            monto=gasto.monto,
            sucursal_id=gasto.sucursal_id,
            empresa_id=empresa_id,
            usuario_id=usuario_id
        )

    # Lógica de Anulación: CUALQUIER ESTADO -> ANULADO
    if estado_anterior != models.EstadoGastoEnum.ANULADO and gasto.estado == models.EstadoGastoEnum.ANULADO:
        # Revertir todos los asientos asociados (Provisiones y Pagos)
        accounting_service.revert_expense_related_entries(
            db=db,
            gasto_id=gasto.id,
            empresa_id=empresa_id,
            usuario_id=usuario_id
        )

    db.add(gasto)
    db.commit()
    db.refresh(gasto)
    return gasto


def eliminar_egreso(db: Session, gasto_id: UUID, empresa_id: UUID) -> bool:
    gasto = (
        db.query(models.Gasto)
        .filter(models.Gasto.id == gasto_id, models.Gasto.empresa_id == empresa_id)
        .first()
    )
    if not gasto:
        return False
    db.delete(gasto)
    db.commit()
    return True
