from decimal import Decimal
from typing import Dict, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.finanzas import models
from app.core_modules.ventas.models import Cliente


def init_pcu_chileno(db: Session, empresa_id: UUID) -> None:
    """
    Inicializa el Plan de Cuentas Estándar Chileno (Simplificado) para una empresa.
    """
    existing_accounts = (
        db.query(models.CuentaContable)
        .filter(models.CuentaContable.empresa_id == empresa_id)
        .all()
    )

    # Estructura PCU Base
    # (Codigo, Nombre, Tipo, Nivel, PadreCodigo, EsImputable)
    pcu_data = [
        # ACTIVO
        ("1", "ACTIVO", "ACTIVO", 1, None, False),
        ("1.1", "ACTIVO CORRIENTE", "ACTIVO", 2, "1", False),
        ("1.1.01", "Disponible", "ACTIVO", 3, "1.1", False),
        ("1.1.01.01", "Caja", "ACTIVO", 4, "1.1.01", True),
        ("1.1.01.02", "Banco", "ACTIVO", 4, "1.1.01", True),
        ("1.1.02", "Clientes y Deudores", "ACTIVO", 3, "1.1", False),
        ("1.1.02.01", "Clientes Nacionales", "ACTIVO", 4, "1.1.02", True),
        ("1.1.03", "Existencias", "ACTIVO", 3, "1.1", False),
        ("1.1.03.01", "Mercaderías", "ACTIVO", 4, "1.1.03", True),
        ("1.1.04", "Impuestos Recuperables", "ACTIVO", 3, "1.1", False),
        ("1.1.04.01", "IVA Crédito Fiscal", "ACTIVO", 4, "1.1.04", True),
        ("1.2", "ACTIVO NO CORRIENTE", "ACTIVO", 2, "1", False),
        ("1.2.01", "Propiedad Planta y Equipo", "ACTIVO", 3, "1.2", False),
        ("1.2.01.01", "Maquinaria y Equipo", "ACTIVO", 4, "1.2.01", True),
        ("1.2.01.02", "Muebles y Útiles", "ACTIVO", 4, "1.2.01", True),
        # PASIVO
        ("2", "PASIVO", "PASIVO", 1, None, False),
        ("2.1", "PASIVO CORRIENTE", "PASIVO", 2, "2", False),
        ("2.1.01", "Cuentas por Pagar", "PASIVO", 3, "2.1", False),
        ("2.1.01.01", "Proveedores Nacionales", "PASIVO", 4, "2.1.01", True),
        ("2.1.02", "Impuestos por Pagar", "PASIVO", 3, "2.1", False),
        ("2.1.02.01", "IVA Débito Fiscal", "PASIVO", 4, "2.1.02", True),
        ("2.1.02.02", "Impuesto a la Renta", "PASIVO", 4, "2.1.02", True),
        ("2.1.02.03", "Retenciones 2da Categoría", "PASIVO", 4, "2.1.02", True),
        # PATRIMONIO
        ("3", "PATRIMONIO", "PATRIMONIO", 1, None, False),
        ("3.1", "Capital", "PATRIMONIO", 2, "3", False),
        ("3.1.01", "Capital Pagado", "PATRIMONIO", 3, "3.1", True),
        ("3.2", "Resultados", "PATRIMONIO", 2, "3", False),
        ("3.2.01", "Utilidad del Ejercicio", "PATRIMONIO", 3, "3.2", True),
        ("3.2.02", "Pérdida del Ejercicio", "PATRIMONIO", 3, "3.2", True),
        # INGRESOS
        ("4", "INGRESOS", "INGRESO", 1, None, False),
        ("4.1", "Ingresos de Explotación", "INGRESO", 2, "4", False),
        ("4.1.01", "Ventas", "INGRESO", 3, "4.1", False),
        ("4.1.01.01", "Ventas Lavandería", "INGRESO", 4, "4.1.01", True),
        ("4.1.01.02", "Ventas Productos", "INGRESO", 4, "4.1.01", True),
        ("4.2", "Otros Ingresos", "INGRESO", 2, "4", False),
        ("4.2.01", "Ingresos Diversos", "INGRESO", 3, "4.2", False),
        (
            "4.2.01.99",
            "Diferencias por Redondeo (Ingreso)",
            "INGRESO",
            4,
            "4.2.01",
            True,
        ),
        # GASTOS
        ("5", "GASTOS", "GASTO", 1, None, False),
        ("5.1", "Costos de Explotación", "GASTO", 2, "5", False),
        ("5.1.01", "Costo de Ventas", "GASTO", 3, "5.1", True),
        ("5.2", "Gastos de Administración y Ventas", "GASTO", 2, "5", False),
        ("5.2.01", "Remuneraciones", "GASTO", 3, "5.2", True),
        ("5.2.02", "Arriendos", "GASTO", 3, "5.2", True),
        ("5.2.01.99", "Diferencias por Redondeo (Gasto)", "GASTO", 4, "5.2.01", True),
        # PASIVO - RRHH
        ("2.1.03", "Remuneraciones y Leyes Sociales", "PASIVO", 3, "2.1", False),
        ("2.1.03.01", "Sueldos por Pagar", "PASIVO", 4, "2.1.03", True),
        ("2.1.03.02", "Instituciones Previsionales", "PASIVO", 4, "2.1.03", True),
        ("5.2.03", "Servicios Básicos", "GASTO", 3, "5.2", True),
        ("5.2.04", "Insumos de Aseo", "GASTO", 3, "5.2", True),
        ("5.2.05", "Mantención Equipos", "GASTO", 3, "5.2", True),
        ("5.2.06", "Otros Gastos Generales", "GASTO", 3, "5.2", True),
        ("5.2.07", "Pérdida por Mermas y Castigos", "GASTO", 3, "5.2", True),
        ("4.2.01.02", "Sobrantes de Inventario", "INGRESO", 4, "4.2.01", True),
    ]

    created_accounts: Dict[str, models.CuentaContable] = {
        a.codigo: a for a in existing_accounts if a.codigo
    }
    created_count = 0

    for codigo, nombre, tipo, nivel, padre_codigo, es_imputable in pcu_data:
        if codigo in created_accounts:
            continue

        padre_id = None
        if padre_codigo:
            padre_obj = created_accounts.get(padre_codigo)
            if padre_obj:
                padre_id = padre_obj.id

        cuenta = models.CuentaContable(
            codigo=codigo,
            nombre=nombre,
            tipo_cuenta=tipo,
            nivel=nivel,
            es_imputable=es_imputable,
            padre_id=padre_id,
            empresa_id=empresa_id,
        )
        db.add(cuenta)
        db.flush()
        created_accounts[codigo] = cuenta
        created_count += 1

    if created_count:
        db.commit()


def get_cuenta_by_codigo(
    db: Session, codigo: str, empresa_id: UUID
) -> Optional[models.CuentaContable]:
    return (
        db.query(models.CuentaContable)
        .filter(
            models.CuentaContable.codigo == codigo,
            models.CuentaContable.empresa_id == empresa_id,
        )
        .first()
    )


def _get_or_create_cuenta_resultados(db: Session, empresa_id: UUID) -> models.CuentaContable:
    """
    Busca o crea la cuenta de Patrimonio 'Resultados del Ejercicio' (3.0.00).
    """
    cuenta = (
        db.query(models.CuentaContable)
        .filter(
            models.CuentaContable.empresa_id == empresa_id,
            models.CuentaContable.nombre.ilike("%Resultado del Ejercicio%"),
            models.CuentaContable.tipo_cuenta == "PATRIMONIO"
        )
        .first()
    )
    
    if not cuenta:
        # Fallback: Buscar por código 3.0.00
        cuenta = (
            db.query(models.CuentaContable)
            .filter(
                models.CuentaContable.empresa_id == empresa_id,
                models.CuentaContable.codigo == "3.0.00"
            )
            .first()
        )
        
    if not cuenta:
        # Crear cuenta si no existe
        cuenta = models.CuentaContable(
            empresa_id=empresa_id,
            codigo="3.0.00",
            nombre="Resultados del Ejercicio",
            tipo_cuenta="PATRIMONIO",
            nivel=1,
            es_imputable=True
        )
        db.add(cuenta)
        db.flush()
        
    return cuenta


def get_cliente_credit_balance(
    db: Session, empresa_id: UUID, cliente: Cliente
) -> Decimal:
    cuenta_clientes = get_cuenta_by_codigo(db, "1.1.02.01", empresa_id)
    if not cuenta_clientes:
        return Decimal("0.00")

    q = (
        db.query(models.MovimientoContable.debe, models.MovimientoContable.haber)
        .join(
            models.AsientoContable,
            models.MovimientoContable.asiento_id == models.AsientoContable.id,
        )
        .filter(
            models.MovimientoContable.cuenta_id == cuenta_clientes.id,
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.estado == "CONFIRMADO",
        )
    )

    if cliente.rut:
        q = q.filter(models.AsientoContable.rut_tercero == str(cliente.rut))
    else:
        q = q.filter(models.AsientoContable.razon_social_tercero == cliente.nombre)

    rows = q.all()
    total_debe = sum(Decimal(str(r.debe or 0)) for r in rows)
    total_haber = sum(Decimal(str(r.haber or 0)) for r in rows)
    return total_debe - total_haber
