from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from uuid import UUID

from sqlalchemy.orm import Session, selectinload

from app.core_modules.finanzas import models
from app.core_modules.finanzas.accounting_service.entries.utils import (
    ensure_tenant,
    get_required_cuenta,
)
from app.core_modules.finanzas.accounting_service.accounts import get_cuenta_by_codigo
from app.core_modules.finanzas.accounting_service.periods import check_periodo_abierto


def create_sale_entry(
    db: Session,
    venta_id: UUID,
    folio: str,
    total: Decimal,
    sucursal_id: UUID,
    empresa_id: UUID,
    usuario_id: UUID,
    metodo_pago: str = "CONTADO",
) -> models.AsientoContable:
    from app.core_modules.ventas import models as ventas_models

    ensure_tenant(db, empresa_id)
    total_dec = Decimal(str(total))
    fecha = datetime.now()
    check_periodo_abierto(db, empresa_id, fecha)

    cuenta_ventas = get_required_cuenta(db, "4.1.01.01", empresa_id)
    cuenta_iva_df = get_required_cuenta(db, "2.1.02.01", empresa_id)
    cuenta_caja = get_required_cuenta(db, "1.1.01.01", empresa_id)
    cuenta_clientes = get_cuenta_by_codigo(db, "1.1.02.01", empresa_id)
    cuenta_banco = get_cuenta_by_codigo(db, "1.1.01.02", empresa_id)

    metodo_pago_norm = (metodo_pago or "CONTADO").upper()
    if metodo_pago_norm == "CREDITO":
        cuenta_debe = cuenta_clientes or cuenta_caja
    elif metodo_pago_norm in {"TRANSFERENCIA", "BANCO"}:
        cuenta_debe = cuenta_banco or cuenta_caja
    else:
        cuenta_debe = cuenta_caja

    debe_principal = total_dec
    redondeo_debe = Decimal("0.00")
    redondeo_haber = Decimal("0.00")

    if metodo_pago_norm == "EFECTIVO" and cuenta_debe.id == cuenta_caja.id:
        debe_principal = total_dec.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        diferencia = (debe_principal - total_dec).quantize(Decimal("0.01"))
        if diferencia > Decimal("0.00"):
            redondeo_haber = diferencia
        elif diferencia < Decimal("0.00"):
            redondeo_debe = abs(diferencia)

    venta = (
        db.query(ventas_models.Venta)
        .options(
            selectinload(ventas_models.Venta.cliente),
            selectinload(ventas_models.Venta.detalles).selectinload(
                ventas_models.DetalleVenta.producto
            ),
        )
        .filter(ventas_models.Venta.id == venta_id)
        .first()
    )

    from app.core_modules.finanzas.services import get_impuesto_rate
    tasa = None
    if venta and getattr(venta, "iva_tasa_aplicada", None) is not None:
        tasa = Decimal(str(venta.iva_tasa_aplicada))
    else:
        tasa = get_impuesto_rate(db, empresa_id, "IVA")
    tasa = Decimal(str(tasa))

    neto_preciso = (total_dec / (Decimal("1") + tasa)).quantize(Decimal("0.0001"))
    neto = neto_preciso.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    iva = (total_dec - neto).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    try:
        total_int = total_dec.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        sum_lines = Decimal("0")
        if venta:
            for det in venta.detalles:
                sum_lines += Decimal(str(det.subtotal)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        diff = (total_int - sum_lines)
        if diff in (Decimal("1"), Decimal("-1")):
            iva = (iva + diff).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            neto = (total_dec - iva).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except Exception:
        pass

    # venta ya cargada arriba

    razon_social = None
    rut = None
    costo_total = Decimal("0.00")
    if venta and venta.cliente:
        razon_social = venta.cliente.nombre
        rut_val = getattr(venta.cliente, "rut", None)
        rut = str(rut_val) if rut_val else None

    if venta:
        for det in venta.detalles:
            prod = det.producto
            if not prod:
                continue
            tipo = str(getattr(prod, "tipo_producto", "") or "").upper()
            if tipo == "SERVICIO":
                continue
            qty = Decimal(str(getattr(det, "cantidad", 0) or 0))
            costo_unit = Decimal(str(getattr(prod, "costo_promedio", 0) or 0))
            costo_total += costo_unit * qty

    costo_total = round(costo_total, 2)

    asiento = models.AsientoContable(
        fecha=fecha,
        glosa=f"Venta {folio}",
        origen="VENTAS",
        origen_id=str(venta_id),
        estado="CONFIRMADO",
        empresa_id=empresa_id,
        sucursal_id=sucursal_id,
        usuario_id=usuario_id,
        metodo_pago=metodo_pago_norm,
        rut_tercero=rut,
        razon_social_tercero=razon_social,
        folio_documento=folio,
    )
    db.add(asiento)
    db.flush()

    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_debe.id,
            debe=debe_principal,
            haber=Decimal("0.00"),
            sucursal_id=sucursal_id,
        )
    )
    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_ventas.id,
            debe=Decimal("0.00"),
            haber=neto,
            sucursal_id=sucursal_id,
        )
    )
    db.add(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_iva_df.id,
            debe=Decimal("0.00"),
            haber=iva,
            sucursal_id=sucursal_id,
        )
    )

    if redondeo_debe > Decimal("0.00"):
        cuenta_redondeo_gasto = get_required_cuenta(db, "5.2.01.99", empresa_id)
        db.add(
            models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_redondeo_gasto.id,
                debe=redondeo_debe,
                haber=Decimal("0.00"),
                sucursal_id=sucursal_id,
            )
        )

    if redondeo_haber > Decimal("0.00"):
        cuenta_redondeo_ingreso = get_required_cuenta(db, "4.2.01.99", empresa_id)
        db.add(
            models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_redondeo_ingreso.id,
                debe=Decimal("0.00"),
                haber=redondeo_haber,
                sucursal_id=sucursal_id,
            )
        )

    if costo_total > 0:
        cuenta_existencias = get_required_cuenta(db, "1.1.03.01", empresa_id)
        cuenta_costo = get_required_cuenta(db, "5.1.01", empresa_id)
        db.add(
            models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_costo.id,
                debe=costo_total,
                haber=Decimal("0.00"),
                sucursal_id=sucursal_id,
            )
        )
        db.add(
            models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_existencias.id,
                debe=Decimal("0.00"),
                haber=costo_total,
                sucursal_id=sucursal_id,
            )
        )

    return asiento
