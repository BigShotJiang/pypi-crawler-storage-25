from datetime import datetime
from decimal import Decimal
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError, PeriodoBloqueadoError
from app.core_modules.finanzas import models, schemas
from app.core_modules.sistema.models import AuditLog, AuditSeverity, Usuario
from app.core_modules.finanzas.accounting_service.accounts import _get_or_create_cuenta_resultados
from app.core_modules.finanzas.accounting_service import reports


def check_periodo_abierto(db: Session, empresa_id: UUID, fecha_operacion: datetime) -> None:
    """
    Verifica si la fecha de una transacción cae en un periodo ya bloqueado.
    Lanza BusinessRuleError si el periodo está cerrado.
    """
    periodo_cerrado = (
        db.query(models.PeriodoContable)
        .filter(
            models.PeriodoContable.empresa_id == empresa_id,
            models.PeriodoContable.cerrado.is_(True),
            models.PeriodoContable.fecha_inicio <= fecha_operacion,
            models.PeriodoContable.fecha_fin >= fecha_operacion
        )
        .first()
    )

    if periodo_cerrado:
        mes_anio = fecha_operacion.strftime("%m/%Y")
        raise PeriodoBloqueadoError(
            f"Operación denegada: El periodo contable de {mes_anio} "
            "se encuentra CERRADO. No se permiten nuevos movimientos."
        )


def get_fecha_contable_valida(db: Session, empresa_id: UUID, fecha_original: datetime) -> datetime:
    """
    Determina la fecha contable para una reversión/anulación.
    Si la fecha original pertenece a un periodo CERRADO, devuelve HOY.
    Si el periodo está ABIERTO, devuelve la fecha original (para anular limpiamente).
    """
    # Buscar si existe un periodo cerrado que cubra la fecha_original
    periodo_cerrado = (
        db.query(models.PeriodoContable)
        .filter(
            models.PeriodoContable.empresa_id == empresa_id,
            models.PeriodoContable.cerrado.is_(True),
            models.PeriodoContable.fecha_inicio <= fecha_original,
            models.PeriodoContable.fecha_fin >= fecha_original
        )
        .first()
    )

    if periodo_cerrado:
        # Periodo cerrado: No tocar el pasado. Usar fecha actual.
        return datetime.now()
    
    # Periodo abierto: Permitir backdating para "limpiar" el registro original
    return fecha_original


def check_integridad_periodo(
    db: Session,
    empresa_id: UUID,
    periodo_id: UUID
) -> schemas.IntegridadPeriodo:
    """
    Verifica si el periodo cumple con las condiciones para ser cerrado.
    Retorna el estado del Semáforo de Integridad.
    """
    periodo = (
        db.query(models.PeriodoContable)
        .filter(models.PeriodoContable.id == periodo_id, models.PeriodoContable.empresa_id == empresa_id)
        .first()
    )

    if not periodo:
        raise HTTPException(status_code=404, detail="Periodo contable no encontrado")

    # 1. Validación de Cuadratura
    resumen = (
        db.query(
            func.sum(models.MovimientoContable.debe).label("total_debe"),
            func.sum(models.MovimientoContable.haber).label("total_haber")
        )
        .join(models.AsientoContable)
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.estado == "CONFIRMADO",
            models.AsientoContable.fecha >= periodo.fecha_inicio,
            models.AsientoContable.fecha <= periodo.fecha_fin
        )
        .first()
    )

    total_debe = resumen.total_debe or Decimal("0.00")
    total_haber = resumen.total_haber or Decimal("0.00")
    diferencia = total_debe - total_haber
    cuadratura_ok = abs(diferencia) <= Decimal("0.01")

    # 2. Validación de Gastos Pendientes
    gastos_pendientes = (
        db.query(models.Gasto)
        .filter(
            models.Gasto.empresa_id == empresa_id,
            models.Gasto.estado == models.EstadoGastoEnum.PENDIENTE,
            models.Gasto.fecha >= periodo.fecha_inicio,
            models.Gasto.fecha <= periodo.fecha_fin
        )
        .count()
    )

    estado = "VERDE"
    mensaje = "El periodo está cuadrado y listo para cerrar."

    if not cuadratura_ok:
        estado = "ROJO"
        mensaje = f"Descuadratura detectada. Diferencia: {diferencia}"
    elif gastos_pendientes > 0:
        estado = "ROJO"
        mensaje = f"Existen {gastos_pendientes} gastos pendientes."
    
    return schemas.IntegridadPeriodo(
        estado=estado,
        cuadratura_ok=cuadratura_ok,
        diferencia=diferencia,
        total_debe=total_debe,
        total_haber=total_haber,
        gastos_pendientes=gastos_pendientes,
        mensaje=mensaje
    )


def cerrar_periodo(
    db: Session,
    empresa_id: UUID,
    periodo_id: UUID,
    usuario_id: UUID
) -> models.PeriodoContable:
    """
    Ejecuta el Cierre Mensual (The Hard Lock).
    Realiza validaciones de cuadratura y gastos pendientes antes de bloquear el periodo.
    """
    periodo = (
        db.query(models.PeriodoContable)
        .filter(models.PeriodoContable.id == periodo_id, models.PeriodoContable.empresa_id == empresa_id)
        .first()
    )

    if not periodo:
        raise HTTPException(status_code=404, detail="Periodo contable no encontrado")

    if periodo.cerrado:
        raise BusinessRuleError("El periodo ya se encuentra cerrado.")

    # 1. Validación de Cuadratura (Suma(Debe) == Suma(Haber))
    # Consideramos solo asientos confirmados dentro del rango de fechas
    resumen = (
        db.query(
            func.sum(models.MovimientoContable.debe).label("total_debe"),
            func.sum(models.MovimientoContable.haber).label("total_haber")
        )
        .join(models.AsientoContable)
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.estado == "CONFIRMADO",
            models.AsientoContable.fecha >= periodo.fecha_inicio,
            models.AsientoContable.fecha <= periodo.fecha_fin
        )
        .first()
    )

    total_debe = resumen.total_debe or Decimal("0.00")
    total_haber = resumen.total_haber or Decimal("0.00")

    if abs(total_debe - total_haber) > Decimal("0.01"):
        raise BusinessRuleError(
            f"Imposible cerrar periodo: Descuadratura detectada. "
            f"Debe: {total_debe}, Haber: {total_haber}, Diferencia: {total_debe - total_haber}"
        )

    # 2. Validación de Asientos/Gastos Pendientes
    # Verificar que no existan gastos en estado PENDIENTE en el periodo
    gastos_pendientes = (
        db.query(models.Gasto)
        .filter(
            models.Gasto.empresa_id == empresa_id,
            models.Gasto.estado == models.EstadoGastoEnum.PENDIENTE,
            models.Gasto.fecha >= periodo.fecha_inicio,
            models.Gasto.fecha <= periodo.fecha_fin
        )
        .count()
    )

    if gastos_pendientes > 0:
        raise BusinessRuleError(
            f"Imposible cerrar periodo: Existen {gastos_pendientes} gastos pendientes de pago o aprobación."
        )

    # 2.5 Cierre de Cuentas de Resultado
    # Calcular totales por cuenta de Ingreso y Gasto
    cuentas_resultado = (
        db.query(
            models.CuentaContable.id,
            models.CuentaContable.tipo_cuenta,
            func.sum(models.MovimientoContable.debe).label("total_debe"),
            func.sum(models.MovimientoContable.haber).label("total_haber")
        )
        .join(models.MovimientoContable.cuenta)
        .join(models.MovimientoContable.asiento)
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.estado == "CONFIRMADO",
            models.AsientoContable.fecha >= periodo.fecha_inicio,
            models.AsientoContable.fecha <= periodo.fecha_fin,
            models.CuentaContable.tipo_cuenta.in_(["INGRESO", "GASTO"])
        )
        .group_by(models.CuentaContable.id, models.CuentaContable.tipo_cuenta)
        .all()
    )

    resultado_ejercicio = Decimal(0)

    if cuentas_resultado:
        movimientos_cierre = []
        total_ingresos = Decimal(0)
        total_gastos = Decimal(0)
        
        # Buscar cuenta de Patrimonio "Resultados del Ejercicio"
        cuenta_resultados = _get_or_create_cuenta_resultados(db, empresa_id)

        for cta_id, tipo, debe, haber in cuentas_resultado:
            debe = debe or Decimal(0)
            haber = haber or Decimal(0)
            saldo = debe - haber
            
            if saldo == 0:
                continue

            # Para cerrar:
            # Si saldo > 0 (Deudor/Gasto), necesitamos Acreditar (Haber)
            # Si saldo < 0 (Acreedor/Ingreso), necesitamos Debitar (Debe)
            monto_cierre = abs(saldo)
            
            if tipo == "INGRESO":
                total_ingresos += (haber - debe)
            elif tipo == "GASTO":
                total_gastos += (debe - haber)

            mov = models.MovimientoContable(
                empresa_id=empresa_id,
                cuenta_id=cta_id,
                debe=monto_cierre if saldo < 0 else 0,
                haber=monto_cierre if saldo > 0 else 0,
                sucursal_id=None
            )
            movimientos_cierre.append(mov)

        # Calcular Resultado
        resultado_ejercicio = total_ingresos - total_gastos
        
        # Asiento final de cuadratura contra Patrimonio
        if resultado_ejercicio != 0:
            mov_resultado = models.MovimientoContable(
                empresa_id=empresa_id,
                cuenta_id=cuenta_resultados.id,
                debe=abs(resultado_ejercicio) if resultado_ejercicio < 0 else 0,
                haber=abs(resultado_ejercicio) if resultado_ejercicio > 0 else 0,
                sucursal_id=None
            )
            movimientos_cierre.append(mov_resultado)

        if movimientos_cierre:
            asiento_cierre = models.AsientoContable(
                empresa_id=empresa_id,
                usuario_id=usuario_id,
                fecha=periodo.fecha_fin.replace(hour=23, minute=59, second=59),
                glosa=f"Cierre de Cuentas de Resultado - {periodo.nombre}",
                origen="CIERRE",
                estado="CONFIRMADO",
                movimientos=movimientos_cierre
            )
            db.add(asiento_cierre)
            db.flush()

    # 3. El Sello (Lock & Audit)
    periodo.cerrado = True
    periodo.fecha_cierre = datetime.now()
    periodo.usuario_cierre_id = usuario_id
    
    # 3.1 Generar Snapshot de Totales para Auditoría (El mes cerró con $X)
    # Usamos el balance de 8 columnas para tener los totales finales del periodo
    # Excluimos el asiento de cierre (que mueve todo a patrimonio) para ver la foto operativa
    balance_snapshot = reports.generate_balance_8_columns(
        db, 
        empresa_id, 
        periodo.fecha_inicio, 
        periodo.fecha_fin, 
        incluir_cierre=False
    )
    totales_snapshot = balance_snapshot.get("totales", {})

    # Crear Log de Auditoría Especial
    audit_log = AuditLog(
        actor_id=usuario_id,
        action="CIERRE_MENSUAL_CONTABLE",
        resource=f"PeriodoContable:{periodo.id}",
        changes={
            "periodo": periodo.nombre,
            "periodo_id": str(periodo.id),
            "total_debe": str(totales_snapshot.get("suma_debe", "0.00")),
            "total_haber": str(totales_snapshot.get("suma_haber", "0.00")),
            "total_activo": str(totales_snapshot.get("activo", "0.00")),
            "total_pasivo": str(totales_snapshot.get("pasivo", "0.00")),
            "total_perdida": str(totales_snapshot.get("perdida", "0.00")),
            "total_ganancia": str(totales_snapshot.get("ganancia", "0.00")),
            "resultado_ejercicio": str(resultado_ejercicio),
            "timestamp": str(datetime.now())
        },
        ip_address="INTERNAL",
        severity=AuditSeverity.CRITICAL # High importance event
    )
    
    db.add(periodo)
    db.add(audit_log)
    db.commit()
    db.refresh(periodo)
    
    return periodo


def abrir_periodo(
    db: Session,
    empresa_id: UUID,
    periodo_id: UUID,
    usuario_solicitante_id: UUID,
    motivo: str
) -> models.PeriodoContable:
    """
    Reapertura de Periodo (Super-Admin Only).
    Requiere un motivo explícito y genera una alerta de seguridad.
    """
    if not motivo or len(motivo.strip()) < 10:
        raise BusinessRuleError("Se requiere un motivo explícito y detallado para reabrir un periodo.")

    periodo = (
        db.query(models.PeriodoContable)
        .filter(models.PeriodoContable.id == periodo_id, models.PeriodoContable.empresa_id == empresa_id)
        .first()
    )

    if not periodo:
        raise HTTPException(status_code=404, detail="Periodo contable no encontrado")

    if not periodo.cerrado:
        raise BusinessRuleError("El periodo no está cerrado.")

    # 1. Validación de Super-Admin
    usuario = db.query(Usuario).filter(Usuario.id == usuario_solicitante_id).first()
    if not usuario or usuario.role != "ADMIN": # Asumiendo "ADMIN" es el rol de SuperAdmin/Platform Admin
        # También podría ser un rol específico dentro de la empresa, pero "Super-Admin" suele ser global.
        # Si fuera rol de empresa: verificar Rol.codigo == 'ADM' y permisos especiales.
        # Por seguridad, restringimos a Platform Admin o lógica custom.
        # Ajustar según definición exacta de "Super-Admin" en el proyecto.
        raise BusinessRuleError("Acceso denegado: Solo administradores de plataforma pueden reabrir periodos.")

    # 2. Re-Apertura
    periodo.cerrado = False
    periodo.fecha_cierre = None
    periodo.usuario_cierre_id = None
    
    # 3. Audit Log de Seguridad
    audit_log = AuditLog(
        actor_id=usuario_solicitante_id,
        action="REAPERTURA_MENSUAL_CONTABLE",
        resource=f"PeriodoContable:{periodo.id}",
        changes={
            "periodo": periodo.nombre,
            "periodo_id": str(periodo.id),
            "motivo": motivo,
            "timestamp": str(datetime.now())
        },
        ip_address="INTERNAL",
        severity=AuditSeverity.CRITICAL # Security Alert
    )

    db.add(periodo)
    db.add(audit_log)
    db.commit()
    db.refresh(periodo)

    return periodo
