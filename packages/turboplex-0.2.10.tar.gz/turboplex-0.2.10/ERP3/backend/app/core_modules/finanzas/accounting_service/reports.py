from typing import Optional, Any, Dict
from uuid import UUID
from datetime import datetime
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func, case, and_

from app.core_modules.finanzas import models
from app.core_modules.finanzas import schemas

def generate_balance_8_columns(
    db: Session,
    empresa_id: UUID,
    fecha_inicio: Optional[datetime] = None,
    fecha_fin: Optional[datetime] = None,
    incluir_cierre: bool = False
) -> Dict[str, Any]:
    """
    Genera el Balance Tributario de 8 Columnas.
    
    Columnas:
    1. Total Debitos
    2. Total Creditos
    3. Saldo Deudor
    4. Saldo Acreedor
    5. Activo
    6. Pasivo
    7. Perdida
    8. Ganancia
    """
    
    # Filtros base para Movimientos
    filters = [
        models.AsientoContable.empresa_id == empresa_id,
        models.AsientoContable.estado == "CONFIRMADO"
    ]
    
    if fecha_inicio:
        filters.append(models.AsientoContable.fecha >= fecha_inicio)
    if fecha_fin:
        filters.append(models.AsientoContable.fecha <= fecha_fin)
        
    if not incluir_cierre:
        filters.append(models.AsientoContable.origen != "CIERRE")

    # Query Agregada
    # Agrupamos por Cuenta
    query = (
        db.query(
            models.CuentaContable.codigo,
            models.CuentaContable.nombre,
            models.CuentaContable.tipo_cuenta,
            func.sum(models.MovimientoContable.debe).label("suma_debe"),
            func.sum(models.MovimientoContable.haber).label("suma_haber")
        )
        .join(models.MovimientoContable, models.MovimientoContable.cuenta_id == models.CuentaContable.id)
        .join(models.AsientoContable, models.MovimientoContable.asiento_id == models.AsientoContable.id)
        .filter(*filters)
        .group_by(
            models.CuentaContable.id,
            models.CuentaContable.codigo,
            models.CuentaContable.nombre,
            models.CuentaContable.tipo_cuenta
        )
        .order_by(models.CuentaContable.codigo)
    )
    
    rows = query.all()
    
    report_data = []
    
    totales = {
        "suma_debe": Decimal(0),
        "suma_haber": Decimal(0),
        "saldo_deudor": Decimal(0),
        "saldo_acreedor": Decimal(0),
        "activo": Decimal(0),
        "pasivo": Decimal(0),
        "perdida": Decimal(0),
        "ganancia": Decimal(0),
    }

    for r in rows:
        suma_debe = r.suma_debe or Decimal(0)
        suma_haber = r.suma_haber or Decimal(0)
        
        # 1 & 2: Sumas
        # (Ya calculadas)
        
        # 3 & 4: Saldos
        saldo_deudor = Decimal(0)
        saldo_acreedor = Decimal(0)
        
        if suma_debe > suma_haber:
            saldo_deudor = suma_debe - suma_haber
        else:
            saldo_acreedor = suma_haber - suma_debe
            
        # 5-8: Clasificacion (Inventario / Resultado)
        activo = Decimal(0)
        pasivo = Decimal(0)
        perdida = Decimal(0)
        ganancia = Decimal(0)
        
        tipo = r.tipo_cuenta.upper()
        
        # Logica de Clasificacion
        # Activos
        if tipo == "ACTIVO":
            if saldo_deudor > 0:
                activo = saldo_deudor
            if saldo_acreedor > 0:
                pasivo = saldo_acreedor

        # Pasivos y Patrimonio
        elif tipo in ["PASIVO", "PATRIMONIO"]:
            if saldo_acreedor > 0:
                pasivo = saldo_acreedor
            if saldo_deudor > 0:
                activo = saldo_deudor

        # Resultados Pérdida (Gastos)
        elif tipo == "GASTO":
            if saldo_deudor > 0:
                perdida = saldo_deudor
            if saldo_acreedor > 0:
                ganancia = saldo_acreedor

        # Resultados Ganancia (Ingresos)
        elif tipo == "INGRESO":
            if saldo_acreedor > 0:
                ganancia = saldo_acreedor
            if saldo_deudor > 0:
                perdida = saldo_deudor

        # Agregar fila
        row = {
            "codigo": r.codigo,
            "nombre": r.nombre,
            "tipo": tipo,
            "suma_debe": suma_debe,
            "suma_haber": suma_haber,
            "saldo_deudor": saldo_deudor,
            "saldo_acreedor": saldo_acreedor,
            "activo": activo,
            "pasivo": pasivo,
            "perdida": perdida,
            "ganancia": ganancia
        }
        report_data.append(row)
        
        # Acumular Totales
        totales["suma_debe"] += suma_debe
        totales["suma_haber"] += suma_haber
        totales["saldo_deudor"] += saldo_deudor
        totales["saldo_acreedor"] += saldo_acreedor
        totales["activo"] += activo
        totales["pasivo"] += pasivo
        totales["perdida"] += perdida
        totales["ganancia"] += ganancia

    return {
        "detalle": report_data,
        "totales": totales
    }


def get_balance_general(
    db: Session,
    empresa_id: UUID,
    year: int,
) -> list[schemas.BalanceItem]:
    fecha_inicio = datetime(year, 1, 1)
    fecha_fin = datetime(year, 12, 31, 23, 59, 59, 999999)

    rows = (
        db.query(
            models.CuentaContable.codigo.label("codigo"),
            models.CuentaContable.nombre.label("nombre"),
            models.CuentaContable.tipo_cuenta.label("tipo_cuenta"),
            func.coalesce(
                func.sum(
                    case(
                        (models.AsientoContable.fecha < fecha_inicio, models.MovimientoContable.debe),
                        else_=0,
                    )
                ),
                0,
            ).label("debe_anterior"),
            func.coalesce(
                func.sum(
                    case(
                        (models.AsientoContable.fecha < fecha_inicio, models.MovimientoContable.haber),
                        else_=0,
                    )
                ),
                0,
            ).label("haber_anterior"),
            func.coalesce(
                func.sum(
                    case(
                        (
                            and_(
                                models.AsientoContable.fecha >= fecha_inicio,
                                models.AsientoContable.fecha <= fecha_fin,
                            ),
                            models.MovimientoContable.debe,
                        ),
                        else_=0,
                    )
                ),
                0,
            ).label("debe_periodo"),
            func.coalesce(
                func.sum(
                    case(
                        (
                            and_(
                                models.AsientoContable.fecha >= fecha_inicio,
                                models.AsientoContable.fecha <= fecha_fin,
                            ),
                            models.MovimientoContable.haber,
                        ),
                        else_=0,
                    )
                ),
                0,
            ).label("haber_periodo"),
        )
        .join(models.MovimientoContable, models.MovimientoContable.cuenta_id == models.CuentaContable.id)
        .join(models.AsientoContable, models.MovimientoContable.asiento_id == models.AsientoContable.id)
        .filter(
            models.AsientoContable.empresa_id == empresa_id,
            models.AsientoContable.estado == "CONFIRMADO",
            models.CuentaContable.empresa_id == empresa_id,
            models.CuentaContable.tipo_cuenta.in_(["ACTIVO", "PASIVO", "PATRIMONIO"]),
        )
        .group_by(
            models.CuentaContable.id,
            models.CuentaContable.codigo,
            models.CuentaContable.nombre,
            models.CuentaContable.tipo_cuenta,
        )
        .order_by(models.CuentaContable.codigo)
        .all()
    )

    items: list[schemas.BalanceItem] = []
    for r in rows:
        debe_anterior = Decimal(str(r.debe_anterior or 0))
        haber_anterior = Decimal(str(r.haber_anterior or 0))
        debe_periodo = Decimal(str(r.debe_periodo or 0))
        haber_periodo = Decimal(str(r.haber_periodo or 0))

        tipo = (r.tipo_cuenta or "").upper()
        if tipo in ["PASIVO", "PATRIMONIO"]:
            saldo_anterior = haber_anterior - debe_anterior
            saldo_final = saldo_anterior + haber_periodo - debe_periodo
        else:
            saldo_anterior = debe_anterior - haber_anterior
            saldo_final = saldo_anterior + debe_periodo - haber_periodo

        if (
            abs(saldo_anterior) <= Decimal("0.00")
            and abs(debe_periodo) <= Decimal("0.00")
            and abs(haber_periodo) <= Decimal("0.00")
        ):
            continue

        items.append(
            schemas.BalanceItem(
                cuenta_codigo=r.codigo,
                cuenta_nombre=r.nombre,
                saldo_anterior=saldo_anterior,
                debitos=debe_periodo,
                creditos=haber_periodo,
                saldo_final=saldo_final,
            )
        )

    return items
