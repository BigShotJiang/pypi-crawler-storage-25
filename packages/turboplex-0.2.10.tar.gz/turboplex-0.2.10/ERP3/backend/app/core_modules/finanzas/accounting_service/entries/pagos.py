from datetime import datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy.orm import Session

from app.core.exceptions import BusinessRuleError
from app.core_modules.finanzas import models
from app.core_modules.finanzas.accounting_service.entries.utils import (
    ensure_tenant,
    get_required_cuenta,
)
from app.core_modules.finanzas.accounting_service.periods import check_periodo_abierto
from app.core_modules.sistema.models import Rol, UsuarioEmpresa
from app.core_modules.ventas.models import Cliente


def registrar_pago_cliente(
    db: Session,
    empresa_id: UUID,
    cliente_id: UUID,
    sucursal_id: UUID,
    usuario_id: UUID,
    monto: Decimal,
    metodo_pago: str = "EFECTIVO",
) -> models.AsientoContable:
    ensure_tenant(db, empresa_id)
    usuario_empresa = (
        db.query(UsuarioEmpresa)
        .join(Rol, UsuarioEmpresa.rol_id == Rol.id)
        .filter(
            UsuarioEmpresa.usuario_id == usuario_id,
            UsuarioEmpresa.empresa_id == empresa_id,
        )
        .first()
    )
    if not usuario_empresa:
        raise BusinessRuleError("Usuario no asociado a la empresa.")
    if usuario_empresa.rol.codigo == "VEN":
        raise BusinessRuleError("No tiene permisos para registrar pagos de clientes.")

    cliente = (
        db.query(Cliente)
        .filter(Cliente.id == cliente_id, Cliente.empresa_id == empresa_id)
        .first()
    )
    if not cliente:
        raise ValueError("Cliente no encontrado.")

    monto_dec = Decimal(str(monto)).quantize(Decimal("0.01"))
    fecha = datetime.now()
    check_periodo_abierto(db, empresa_id, fecha)

    cuenta_caja = get_required_cuenta(db, "1.1.01.01", empresa_id)
    cuenta_clientes = get_required_cuenta(db, "1.1.02.01", empresa_id)

    metodo_pago_norm = (metodo_pago or "").strip().upper()
    caja_debe = monto_dec
    redondeo_debe = Decimal("0.00")

    if metodo_pago_norm == "EFECTIVO":
        pesos = int(monto_dec)
        caja_pesos = pesos - (pesos % 10)
        caja_debe = Decimal(caja_pesos).quantize(Decimal("0.01"))
        redondeo_debe = (monto_dec - caja_debe).quantize(Decimal("0.01"))

    asiento = models.AsientoContable(
        fecha=fecha,
        glosa=f"Pago Cliente: {cliente.nombre}",
        origen="PAGO_CLIENTE",
        origen_id=str(cliente.id),
        estado="CONFIRMADO",
        empresa_id=empresa_id,
        sucursal_id=sucursal_id,
        usuario_id=usuario_id,
        metodo_pago=metodo_pago_norm or metodo_pago,
        rut_tercero=str(getattr(cliente, "rut", None)) if getattr(cliente, "rut", None) else None,
        razon_social_tercero=cliente.nombre,
    )
    db.add(asiento)
    db.flush()

    movimientos: list[models.MovimientoContable] = []
    movimientos.append(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_caja.id,
            debe=caja_debe,
            haber=Decimal("0.00"),
            sucursal_id=sucursal_id,
        )
    )
    movimientos.append(
        models.MovimientoContable(
            asiento_id=asiento.id,
            empresa_id=empresa_id,
            cuenta_id=cuenta_clientes.id,
            debe=Decimal("0.00"),
            haber=monto_dec,
            sucursal_id=sucursal_id,
        )
    )

    if redondeo_debe > Decimal("0.00"):
        cuenta_redondeo_gasto = get_required_cuenta(db, "5.2.01.99", empresa_id)
        movimientos.append(
            models.MovimientoContable(
                asiento_id=asiento.id,
                empresa_id=empresa_id,
                cuenta_id=cuenta_redondeo_gasto.id,
                debe=redondeo_debe,
                haber=Decimal("0.00"),
                sucursal_id=sucursal_id,
            )
        )

    total_debe = sum(Decimal(str(m.debe or 0)) for m in movimientos)
    total_haber = sum(Decimal(str(m.haber or 0)) for m in movimientos)
    if abs(total_debe - total_haber) > Decimal("0.01"):
        raise ValueError(
            f"Asiento desbalanceado: Debe {total_debe} != Haber {total_haber}"
        )

    for mov in movimientos:
        db.add(mov)

    db.commit()
    db.refresh(asiento)
    return asiento
