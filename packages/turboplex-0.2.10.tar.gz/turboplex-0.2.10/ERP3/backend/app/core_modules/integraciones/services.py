from sqlalchemy.orm import Session
from fastapi import HTTPException
from typing import Dict, Any
from app.core_modules.finanzas.models_rates import ExchangeRates

from app.core.config import settings


class ExternalIntegrationService:
    """
    Servicio de Integración con Fuentes Externas (Multi-moneda).
    """

    @staticmethod
    def process_external_rates(db: Session, json_data: Dict[str, Any], api_key: str):
        """
        Procesa tasas de cambio externas y las actualiza en PostgreSQL.
        """
        # 1. Validación de Seguridad
        if api_key != settings.EXTERNAL_API_KEY:
            raise HTTPException(status_code=401, detail="Unauthorized: Invalid API Key")

        if not json_data:
            raise HTTPException(status_code=400, detail="Invalid JSON data")

        # 2. Mapeo de Monedas
        # Map input keys (e.g. mindicador.cl) to internal codes
        currency_map = {"uf": "UF", "dolar": "USD", "utm": "UTM"}

        try:
            for key, value in json_data.items():
                code = currency_map.get(key.lower())
                if code:
                    # Validar valor positivo
                    rate_val = float(value)
                    if rate_val < 0:
                        raise ValueError(f"Negative rate for {code}")

                    # Upsert
                    rate_entry = (
                        db.query(ExchangeRates)
                        .filter(ExchangeRates.currency_code == code)
                        .first()
                    )
                    if not rate_entry:
                        rate_entry = ExchangeRates(currency_code=code, rate=rate_val)
                        db.add(rate_entry)
                    else:
                        rate_entry.rate = rate_val

            db.commit()

        except (ValueError, TypeError) as e:
            db.rollback()
            raise HTTPException(
                status_code=400, detail=f"Invalid data format: {str(e)}"
            )
        except Exception as e:
            db.rollback()
            raise HTTPException(status_code=500, detail=f"Internal Error: {str(e)}")

        return {"message": "Rates updated successfully"}
