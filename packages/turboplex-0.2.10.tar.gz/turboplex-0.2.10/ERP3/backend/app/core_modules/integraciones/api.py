from fastapi import APIRouter, Depends, Body, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
from app.api import deps
from app.core_modules.integraciones.services import ExternalIntegrationService

router = APIRouter()


@router.post("/rates", status_code=200)
def update_exchange_rates(
    payload: Dict[str, Any] = Body(...),
    api_key: str = Body(
        ..., embed=True
    ),  # Expects JSON {"payload": {...}, "api_key": "..."} or query param? Service takes separate args.
    # Let's align with the service: it takes json_data and api_key.
    # We'll expect a single JSON body: { "rates": {...}, "api_key": "..." }
    db: Session = Depends(deps.get_db),
):
    """
    Webhook para actualizar tasas de cambio desde fuente externa.
    Payload esperado:
    {
        "api_key": "secret",
        "rates": {
            "uf": 38000.5,
            "dolar": 950.2,
            "utm": 64000
        }
    }
    """
    # Extract from body manually or via Pydantic model?
    # Using Dict for flexibility as defined in service

    # Check if user sent flat structure or nested
    # The service expects json_data to be the dictionary of rates

    incoming_key = payload.get("api_key")
    rates_data = payload.get("rates")

    if not incoming_key:
        raise HTTPException(status_code=400, detail="Missing api_key")

    if not rates_data:
        raise HTTPException(status_code=400, detail="Missing rates data")

    return ExternalIntegrationService.process_external_rates(
        db, rates_data, incoming_key
    )
