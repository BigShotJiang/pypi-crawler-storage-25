from sqlalchemy import (
    Column,
    Integer,
    String,
    ForeignKey,
    DateTime,
    Numeric,
    Enum as SAEnum,
    CheckConstraint,
)
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.sql import func
from app.core.database import Base, GUID
from app.core.utils.mixins import SoftDeleteMixin
from uuid import UUID
import uuid6
import enum


class Proveedor(Base, SoftDeleteMixin):
    __tablename__ = "proveedores"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, index=True, nullable=False)
    razon_social = Column(String, nullable=True)  # Added as per request
    rut = Column(String, index=True, nullable=True)  # Tax ID
    giro = Column(String, nullable=True)  # Added as per request
    telefono = Column(String, nullable=True)
    email = Column(String, nullable=True)
    direccion = Column(String, nullable=True)
    plazo_pago_dias = Column(Integer, default=30)  # Added as per request

    # Multi-tenancy
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="proveedores"
    )


class OrdenCompra(Base, SoftDeleteMixin):
    __tablename__ = "ordenes_compra"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    folio = Column(String, index=True, nullable=True)  # Factura Externa / OC Interna
    fecha_emision = Column(DateTime(timezone=True), default=func.now(), nullable=False)
    fecha_recepcion = Column(DateTime(timezone=True), nullable=True)

    # Estado: BORRADOR, ENVIADA, PARCIAL, RECIBIDA, CANCELADA
    estado = Column(String, default="BORRADOR", index=True)

    total_neto = Column(Numeric(10, 2), default=0.00, nullable=False)
    total = Column(
        Numeric(10, 2), default=0.00, nullable=False
    )  # Total Bruto (Neto + IVA)

    # Foreign Keys
    proveedor_id = Column(
        GUID, ForeignKey("proveedores.id"), nullable=False, index=True
    )
    sucursal_id = Column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)
    bodega_id = Column(
        GUID, ForeignKey("bodegas.id"), nullable=True, index=True
    )  # Donde ingresa el stock
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    usuario_id = Column(
        GUID, ForeignKey("usuarios.id"), nullable=False, index=True
    )  # Quien creo la OC

    # Relationships
    proveedor = relationship("Proveedor", backref="ordenes_compra")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")
    bodega = relationship("app.core_modules.sistema.models.Bodega")
    empresa = relationship(
        "app.core_modules.sistema.models.Empresa", backref="ordenes_compra"
    )
    usuario = relationship("app.core_modules.sistema.models.Usuario")

    detalles = relationship(
        "OrdenCompraDetalle",
        back_populates="orden_compra",
        cascade="all, delete-orphan",
    )


class OrdenCompraDetalle(Base):
    __tablename__ = "orden_compra_detalles"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    orden_compra_id = Column(
        GUID, ForeignKey("ordenes_compra.id"), nullable=False, index=True
    )
    producto_id = Column(GUID, ForeignKey("productos.id"), nullable=False, index=True)
    cantidad = Column(Integer, nullable=False)
    precio_unitario = Column(Numeric(10, 2), nullable=False)
    subtotal = Column(Numeric(10, 2), nullable=False)

    # Relationships
    orden_compra = relationship("OrdenCompra", back_populates="detalles")
    producto = relationship("app.core_modules.ventas.models.Producto")


class EstadoDRAEnum(str, enum.Enum):
    BORRADOR = "BORRADOR"
    POSTEADO = "POSTEADO"


class CodigoDisposicionDRAEnum(str, enum.Enum):
    OK = "OK"
    DUPLICADO = "DUPLICADO"
    DANADO = "DAÑADO"


class RecepcionDRA(Base, SoftDeleteMixin):
    __tablename__ = "recepciones_dra"

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    folio_documento = Column(String, nullable=False, index=True)
    estado = Column(
        SAEnum(EstadoDRAEnum),
        default=EstadoDRAEnum.BORRADOR,
        nullable=False,
        index=True,
    )

    proveedor_id = Column(
        GUID, ForeignKey("proveedores.id"), nullable=False, index=True
    )
    orden_compra_id = Column(
        GUID, ForeignKey("ordenes_compra.id"), nullable=True, index=True
    )
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    sucursal_id = Column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)
    bodega_id = Column(GUID, ForeignKey("bodegas.id"), nullable=False, index=True)

    fecha_creacion = Column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    fecha_posteo = Column(DateTime(timezone=True), nullable=True)

    proveedor = relationship("Proveedor", backref="recepciones_dra")
    orden_compra = relationship("OrdenCompra")
    empresa = relationship("app.core_modules.sistema.models.Empresa")
    sucursal = relationship("app.core_modules.sistema.models.Sucursal")
    bodega = relationship("app.core_modules.sistema.models.Bodega")

    lineas = relationship(
        "LineaDRA", back_populates="dra", cascade="all, delete-orphan"
    )


class LineaDRA(Base):
    __tablename__ = "recepciones_dra_lineas"
    __table_args__ = (
        CheckConstraint(
            "cantidad_aceptada + cantidad_rechazada = cantidad_recibida",
            name="ck_dra_cantidades_balance",
        ),
    )

    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    dra_id = Column(GUID, ForeignKey("recepciones_dra.id"), nullable=False, index=True)
    producto_id = Column(GUID, ForeignKey("productos.id"), nullable=False, index=True)

    cantidad_recibida = Column(Integer, nullable=False)
    cantidad_aceptada = Column(Integer, nullable=False)
    cantidad_rechazada = Column(Integer, nullable=False)

    codigo_disposicion = Column(
        SAEnum(CodigoDisposicionDRAEnum),
        default=CodigoDisposicionDRAEnum.OK,
        nullable=False,
        index=True,
    )
    glosa_rechazo = Column(String, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    dra = relationship("RecepcionDRA", back_populates="lineas")
    producto = relationship("app.core_modules.ventas.models.Producto")
