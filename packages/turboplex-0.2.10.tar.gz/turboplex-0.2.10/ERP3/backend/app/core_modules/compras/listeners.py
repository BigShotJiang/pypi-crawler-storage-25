import logging
from typing import Any, Dict, cast
from uuid import UUID
from app.core.database import SessionLocal
from app.core.infrastructure.events import event_dispatcher
from app.core_modules.compras.models import OrdenCompra
from app.core_modules.inventario.stock.models import InventarioUbicacion
from app.core_modules.ventas.inventory_service import InventoryService
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)


async def handle_compra_recibida(data: Dict[str, Any]) -> None:
    """
    Listener para evento EVENT_COMPRA_RECIBIDA.
    Incrementa stock en Inventario (Bodega) e InventarioUbicacion (WMS).
    Registra MovimientoStock.

    Data esperada: {"orden_id": int, "ubicacion_id": int}
    """
    orden_id = data.get("orden_id")
    ubicacion_id = data.get("ubicacion_id")

    if not orden_id or not ubicacion_id:
        logger.error(f"[COMPRAS] Datos insuficientes para procesar recepción: {data}")
        return

    db = SessionLocal()
    try:
        orden = db.query(OrdenCompra).filter(OrdenCompra.id == orden_id).first()
        if not orden:
            logger.error(f"[COMPRAS] Orden de Compra ID {orden_id} no encontrada.")
            return

        if orden.estado != "RECIBIDA":
            logger.warning(
                f"[COMPRAS] Orden {orden_id} no está en estado RECIBIDA (Estado: {orden.estado})."
            )
            # Podríamos retornar o procesar igual, pero asumimos que el evento es la verdad.
            # Si el evento se disparó, es porque se recibió.

        logger.info(
            f"[COMPRAS] Procesando recepción OC #{orden.folio} (ID: {orden_id}) en Ubicación {ubicacion_id}"
        )

        total_reactivated = 0

        for detalle in orden.detalles:
            # 1. Actualizar Stock Detallado (WMS - Ubicación)
            # Nota: Hacemos esto antes de llamar a add_stock para que se commitee junto (ya que add_stock hace commit)
            inv_ubicacion = (
                db.query(InventarioUbicacion)
                .filter(
                    InventarioUbicacion.ubicacion_id == ubicacion_id,
                    InventarioUbicacion.producto_id == detalle.producto_id,
                )
                .first()
            )

            if not inv_ubicacion:
                inv_ubicacion = InventarioUbicacion(
                    ubicacion_id=ubicacion_id,
                    producto_id=detalle.producto_id,
                    cantidad=0,
                )
                db.add(inv_ubicacion)

            inv_ubicacion.cantidad += detalle.cantidad
            db.add(inv_ubicacion)

            # 2. Actualizar Stock Global + Movimiento + Trigger FIFO
            # InventoryService.add_stock se encarga de:
            # - Actualizar Inventario (Bodega)
            # - Crear MovimientoStock
            # - Ejecutar process_backorders (FIFO)
            # - Hacer db.commit()

            reactivated = InventoryService.add_stock(
                db,
                detalle.producto_id,
                cast(UUID, orden.bodega_id),
                detalle.cantidad,
                "COMPRA",
                orden.empresa_id,
            )
            total_reactivated += reactivated

        # El commit final ya no es estrictamente necesario si add_stock commiteó,
        # pero por seguridad si hubo cambios pendientes no cubiertos:
        db.commit()

        logger.info(
            f"[COMPRAS] Recepción completada exitosamente para OC #{orden.folio}. Órdenes reactivadas: {total_reactivated}"
        )

    except (SQLAlchemyError, ValueError, TypeError) as e:
        logger.error(
            f"[COMPRAS] Error procesando recepción OC {orden_id}: {e}", exc_info=True
        )
        db.rollback()
    finally:
        db.close()


def register_listeners() -> None:
    event_dispatcher.subscribe("EVENT_COMPRA_RECIBIDA", handle_compra_recibida)
