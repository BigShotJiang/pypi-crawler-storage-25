from typing import Any, List, Optional, cast
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from app.api import deps
from app.core.infrastructure.api_schemas import BaseResponse, MetaPayload
from app.core_modules.compras import schemas, services, models
from app.core_modules.sistema.models import Usuario, Empresa, AuditLog, AuditSeverity
from app.core.auth.rbac import resolve_user_role_code, get_user_scopes
from app.core.infrastructure.events import event_dispatcher

router = APIRouter()

@router.post("/ordenes-compra/", response_model=BaseResponse[schemas.OrdenCompra], tags=["Compras"])
def create_orden_compra(
    orden_in: schemas.OrdenCompraCreate,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Crear una nueva Orden de Compra.
    """
    orden = services.create_orden_compra(
        db=db,
        orden_in=orden_in,
        usuario_id=current_user.id,
        empresa_id=current_company.id,
    )
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.OrdenCompra](
        success=True, data=orden, meta=meta
    )


@router.post(
    "/ordenes-compra/{orden_id}/aprobar",
    response_model=BaseResponse[schemas.OrdenCompra],
    tags=["Compras"],
)
async def approve_orden_compra(
    orden_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Aprobar una Orden de Compra (Cambia estado a ENVIADA y dispara eventos).
    """
    required_roles = ["ADM"]
    required_scopes = ["compras:approve"]
    role_code = resolve_user_role_code(db, current_user.id, current_company.id) or ""
    scopes = get_user_scopes(db, current_user.id, current_company.id)
    allowed = role_code in required_roles or any(s in scopes for s in required_scopes)
    if not allowed:
        log = AuditLog(
            actor_id=current_user.id,
            action="RBAC_ROLE_SCOPE_DENIED",
            resource=f"POST /compras/ordenes-compra/{orden_id}/aprobar",
            severity=AuditSeverity.CRITICAL,
            changes={
                "empresa_id": str(current_company.id),
                "required_roles": required_roles,
                "required_scopes": required_scopes,
                "user_role": role_code,
                "user_scopes": sorted(list(scopes)),
            },
            ip_address=None,
        )
        db.add(log)
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acceso denegado por política RBAC",
        )
    orden = (
        db.query(models.OrdenCompra)
        .filter(
            models.OrdenCompra.id == orden_id,
            models.OrdenCompra.empresa_id == current_company.id,
        )
        .first()
    )
    if not orden:
        raise HTTPException(status_code=404, detail="Orden de compra no encontrada")
    if orden.estado in ["RECIBIDA", "CANCELADA"]:
        raise HTTPException(
            status_code=400,
            detail="No se puede aprobar una orden de compra finalizada",
        )
    orden_any = cast(Any, orden)
    orden_any.estado = "ENVIADA"
    db.add(orden)
    db.commit()
    db.refresh(orden)
    payload = {
        "empresa_id": current_company.id,
        "orden_compra_id": orden.id,
        "estado": orden.estado,
        "total": orden.total,
        "proveedor_id": orden.proveedor_id,
        "sucursal_id": orden.sucursal_id,
        "bodega_id": orden.bodega_id,
        "usuario_id": current_user.id,
    }
    await event_dispatcher.dispatch("orden_compra.aprobada", payload)
    
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.OrdenCompra](
        success=True, data=orden, meta=meta
    )


# -----------------------------------------------------------------------------
# PROVEEDORES
# -----------------------------------------------------------------------------
@router.post("/proveedores/", response_model=BaseResponse[schemas.Proveedor], tags=["Proveedores"])
def create_proveedor(
    proveedor_in: schemas.ProveedorCreate,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Crear un nuevo Proveedor.
    """
    proveedor = services.create_proveedor(
        db=db, proveedor_in=proveedor_in, empresa_id=current_company.id
    )
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.Proveedor](success=True, data=proveedor, meta=meta)


@router.get("/proveedores/", response_model=BaseResponse[List[schemas.Proveedor]], tags=["Proveedores"])
def list_proveedores(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Listar Proveedores.
    """
    proveedores = services.list_proveedores(
        db=db, empresa_id=current_company.id, skip=skip, limit=limit
    )
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[List[schemas.Proveedor]](success=True, data=proveedores, meta=meta)


@router.get("/proveedores/{id}", response_model=BaseResponse[schemas.Proveedor], tags=["Proveedores"])
def get_proveedor(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtener detalle de un Proveedor.
    """
    proveedor = services.get_proveedor(db=db, proveedor_id=id, empresa_id=current_company.id)
    if not proveedor:
        raise HTTPException(status_code=404, detail="Proveedor no encontrado")
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.Proveedor](success=True, data=proveedor, meta=meta)


@router.put("/proveedores/{id}", response_model=BaseResponse[schemas.Proveedor], tags=["Proveedores"])
def update_proveedor(
    id: UUID,
    proveedor_in: schemas.ProveedorUpdate,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Actualizar un Proveedor.
    """
    try:
        proveedor = services.update_proveedor(
            db=db, proveedor_id=id, proveedor_in=proveedor_in, empresa_id=current_company.id
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.Proveedor](success=True, data=proveedor, meta=meta)


@router.delete("/proveedores/{id}", response_model=BaseResponse[schemas.Proveedor], tags=["Proveedores"])
def delete_proveedor(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Eliminar un Proveedor (Soft Delete).
    """
    try:
        proveedor = services.delete_proveedor(
            db=db, proveedor_id=id, empresa_id=current_company.id
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.Proveedor](success=True, data=proveedor, meta=meta)


@router.get("/ordenes-compra/", response_model=BaseResponse[List[schemas.OrdenCompra]], tags=["Compras"])
def list_ordenes_compra(
    skip: int = 0,
    limit: int = 100,
    proveedor_id: Optional[UUID] = Query(None),
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Listar Órdenes de Compra.
    """
    ordenes = services.list_ordenes_compra(
        db=db,
        empresa_id=current_company.id,
        skip=skip,
        limit=limit,
        proveedor_id=proveedor_id,
    )
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[List[schemas.OrdenCompra]](
        success=True, data=ordenes, meta=meta
    )

@router.get("/ordenes-compra/{id}", response_model=BaseResponse[schemas.OrdenCompra], tags=["Compras"])
def get_orden_compra(
    id: UUID,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Obtener detalle de una Orden de Compra.
    """
    orden = services.get_orden_compra(db=db, orden_id=id, empresa_id=current_company.id)
    if not orden:
        raise HTTPException(status_code=404, detail="Orden de Compra no encontrada")
    
    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.OrdenCompra](
        success=True, data=orden, meta=meta
    )

@router.put("/ordenes-compra/{id}", response_model=BaseResponse[schemas.OrdenCompra], tags=["Compras"])
def update_orden_compra(
    id: UUID,
    orden_in: schemas.OrdenCompraUpdate,
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Actualizar una Orden de Compra.
    """
    try:
        orden = services.update_orden_compra(
            db=db,
            orden_id=id,
            orden_in=orden_in,
            empresa_id=current_company.id,
        )
    except ValueError as e:
         raise HTTPException(status_code=404, detail=str(e))

    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.OrdenCompra](
        success=True, data=orden, meta=meta
    )

@router.post("/ordenes-compra/{id}/recepcionar", response_model=BaseResponse[schemas.OrdenCompra], tags=["Compras"])
async def recepcionar_orden(
    id: UUID,
    ubicacion_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Recepcionar una Orden de Compra (Cambia estado a RECIBIDA y dispara eventos).
    """
    try:
        # Note: recepcionar_orden is async in services.py
        orden = await services.recepcionar_orden(
            db=db,
            orden_id=id,
            ubicacion_id=ubicacion_id,
            usuario_id=current_user.id
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    meta = MetaPayload(module="COMPRAS", rls_scope="empresa")
    return BaseResponse[schemas.OrdenCompra](
        success=True, data=orden, meta=meta
    )
