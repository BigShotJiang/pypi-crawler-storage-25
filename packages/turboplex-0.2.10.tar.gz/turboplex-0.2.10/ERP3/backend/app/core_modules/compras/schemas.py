from typing import Optional, List
from pydantic import BaseModel, ConfigDict, field_validator
from decimal import Decimal
from datetime import datetime
from app.core.utils import validate_rut, clean_rut
from uuid import UUID

# --- Proveedor Schemas ---


class ProveedorBase(BaseModel):
    nombre: str  # Deprecated? Or used as internal name? Model has both.
    razon_social: Optional[str] = None
    rut: Optional[str] = None
    giro: Optional[str] = None
    telefono: Optional[str] = None
    email: Optional[str] = None
    direccion: Optional[str] = None
    plazo_pago_dias: Optional[int] = 30


class ProveedorCreate(ProveedorBase):
    @field_validator("rut")
    @classmethod
    def validate_rut_chil(cls, v: Optional[str]) -> Optional[str]:
        if not v:
            return v
        if not validate_rut(v):
            raise ValueError("RUT inválido")
        return clean_rut(v)


class ProveedorUpdate(ProveedorBase):
    pass


class ProveedorInDBBase(ProveedorBase):
    id: UUID
    empresa_id: UUID
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class Proveedor(ProveedorInDBBase):
    pass


# --- OrdenCompra Schemas ---


class OrdenCompraDetalleBase(BaseModel):
    producto_id: Optional[UUID] = None
    descripcion: Optional[str] = None
    cantidad: int
    precio_unitario: Decimal


class OrdenCompraDetalleCreate(OrdenCompraDetalleBase):
    pass


class OrdenCompraDetalle(OrdenCompraDetalleBase):
    id: UUID
    orden_compra_id: UUID
    subtotal: Decimal

    model_config = ConfigDict(from_attributes=True)


class OrdenCompraBase(BaseModel):
    proveedor_id: UUID
    sucursal_id: UUID
    bodega_id: Optional[UUID] = None
    folio: Optional[str] = None
    observacion: Optional[str] = None


class OrdenCompraCreate(OrdenCompraBase):
    detalles: List[OrdenCompraDetalleCreate]


class OrdenCompraUpdate(BaseModel):
    estado: Optional[str] = None
    folio: Optional[str] = None
    fecha_recepcion: Optional[datetime] = None


class OrdenCompra(OrdenCompraBase):
    id: UUID
    fecha_emision: datetime
    fecha_recepcion: Optional[datetime] = None
    estado: str
    total_neto: Decimal
    total: Decimal
    empresa_id: UUID
    usuario_id: UUID
    detalles: List[OrdenCompraDetalle] = []

    model_config = ConfigDict(from_attributes=True)


class LineaDRABase(BaseModel):
    producto_id: UUID
    cantidad_recibida: int
    cantidad_aceptada: int
    cantidad_rechazada: int
    codigo_disposicion: str = "OK"
    glosa_rechazo: Optional[str] = None


class LineaDRACreate(LineaDRABase):
    pass


class LineaDRA(LineaDRABase):
    id: UUID
    dra_id: UUID
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class RecepcionDRABase(BaseModel):
    proveedor_id: UUID
    empresa_id: UUID
    sucursal_id: UUID
    bodega_id: UUID
    folio_documento: str
    orden_compra_id: Optional[UUID] = None


class RecepcionDRACreate(RecepcionDRABase):
    lineas: List[LineaDRACreate]


class RecepcionDRA(RecepcionDRABase):
    id: UUID
    estado: str
    fecha_creacion: datetime
    fecha_posteo: Optional[datetime] = None
    lineas: List[LineaDRA] = []

    model_config = ConfigDict(from_attributes=True)
