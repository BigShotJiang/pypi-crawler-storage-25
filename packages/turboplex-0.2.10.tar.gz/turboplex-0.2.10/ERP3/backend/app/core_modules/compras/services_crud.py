from datetime import datetime
from decimal import Decimal
from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.compras.models import OrdenCompra, OrdenCompraDetalle
from app.core_modules.compras.schemas import OrdenCompraCreate, OrdenCompraUpdate


def create_orden_compra(
    db: Session, orden_in: OrdenCompraCreate, usuario_id: UUID, empresa_id: UUID
) -> OrdenCompra:
    db_orden = OrdenCompra(
        proveedor_id=orden_in.proveedor_id,
        sucursal_id=orden_in.sucursal_id,
        bodega_id=orden_in.bodega_id,
        folio=orden_in.folio,
        # observacion=orden_in.observacion, # Model doesn't have observacion yet, check model definition again
        empresa_id=empresa_id,
        usuario_id=usuario_id,
        fecha_emision=datetime.now(),
        estado="BORRADOR",
        total_neto=0,
        total=0,
    )
    db.add(db_orden)
    db.flush()  # Generate ID

    total_neto = Decimal(0)
    for detalle_in in orden_in.detalles:
        subtotal = detalle_in.cantidad * detalle_in.precio_unitario
        db_detalle = OrdenCompraDetalle(
            orden_compra_id=db_orden.id,
            producto_id=detalle_in.producto_id,
            # descripcion=detalle_in.descripcion, # Model check
            cantidad=detalle_in.cantidad,
            precio_unitario=detalle_in.precio_unitario,
            subtotal=subtotal,
        )
        db.add(db_detalle)
        total_neto += subtotal

    db_orden.total_neto = total_neto
    # Impuesto desde configuración por empresa (Decimal, 4 decimales)
    from app.core_modules.finanzas.services import get_impuesto_rate
    tasa = get_impuesto_rate(db, empresa_id, "IVA")
    factor = (Decimal("1") + Decimal(str(tasa)))
    db_orden.total = (Decimal(str(total_neto)) * factor).quantize(Decimal("0.01"))

    db.commit()
    db.refresh(db_orden)
    return db_orden


def get_orden_compra(
    db: Session, orden_id: UUID, empresa_id: UUID
) -> Optional[OrdenCompra]:
    return (
        db.query(OrdenCompra)
        .filter(OrdenCompra.id == orden_id, OrdenCompra.empresa_id == empresa_id)
        .first()
    )


def list_ordenes_compra(
    db: Session,
    empresa_id: UUID,
    skip: int = 0,
    limit: int = 100,
    proveedor_id: Optional[UUID] = None,
) -> List[OrdenCompra]:
    query = db.query(OrdenCompra).filter(OrdenCompra.empresa_id == empresa_id)
    if proveedor_id:
        query = query.filter(OrdenCompra.proveedor_id == proveedor_id)
    return query.offset(skip).limit(limit).all()


def update_orden_compra(
    db: Session, orden_id: UUID, orden_in: OrdenCompraUpdate, empresa_id: UUID
) -> OrdenCompra:
    orden = get_orden_compra(db, orden_id, empresa_id)
    if not orden:
        raise ValueError(f"Orden de Compra {orden_id} no encontrada")

    orden_data = orden_in.model_dump(exclude_unset=True)
    for field, value in orden_data.items():
        setattr(orden, field, value)

    db.add(orden)
    db.commit()
    db.refresh(orden)
    return orden
