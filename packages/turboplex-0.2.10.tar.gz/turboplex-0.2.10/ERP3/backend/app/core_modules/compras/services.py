from sqlalchemy.orm import Session
from datetime import datetime
from typing import Any, Optional, cast
from uuid import UUID
from app.core.infrastructure.events import event_dispatcher
from app.core_modules.compras.models import (
    OrdenCompra,
    OrdenCompraDetalle,
    RecepcionDRA,
    CodigoDisposicionDRAEnum,
    EstadoDRAEnum,
    Proveedor,
)
from app.core_modules.compras.schemas import (
    OrdenCompraCreate,
    OrdenCompraUpdate,
    ProveedorCreate,
    ProveedorUpdate,
)
from typing import List
from decimal import Decimal
from app.core_modules.ventas.inventory_service import InventoryService
import logging

logger = logging.getLogger(__name__)


async def recepcionar_orden(
    db: Session, orden_id: UUID, ubicacion_id: UUID, usuario_id: UUID
) -> OrdenCompra:
    orden = db.query(OrdenCompra).filter(OrdenCompra.id == orden_id).first()
    if not orden:
        raise ValueError(f"Orden de Compra {orden_id} no encontrada")

    if orden.estado == "RECIBIDA":
        raise ValueError(f"Orden de Compra {orden_id} ya fue recibida")

    # Update State
    orden_any = cast(Any, orden)
    orden_any.estado = "RECIBIDA"
    orden_any.fecha_recepcion = datetime.now()
    # orden.usuario_recepcion_id = usuario_id # Si tuviéramos este campo

    db.commit()
    db.refresh(orden)

    logger.info(
        f"Orden de Compra {orden_id} marcada como RECIBIDA. Disparando evento..."
    )

    # Dispatch Event
    empresa_id = getattr(orden, "empresa_id", None)
    await event_dispatcher.dispatch(
        "EVENT_COMPRA_RECIBIDA",
        {
            "empresa_id": str(empresa_id) if empresa_id else None,
            "orden_id": orden.id,
            "ubicacion_id": ubicacion_id,
        },
    )

    return orden


def validar_duplicidad_dra(
    db: Session,
    empresa_id: UUID,
    proveedor_id: UUID,
    folio_documento: str,
    dra_id: Optional[UUID] = None,
) -> Optional[RecepcionDRA]:
    query = db.query(RecepcionDRA).filter(
        RecepcionDRA.empresa_id == empresa_id,
        RecepcionDRA.proveedor_id == proveedor_id,
        RecepcionDRA.folio_documento == folio_documento,
    )
    if dra_id:
        query = query.filter(RecepcionDRA.id != dra_id)
    return query.first()


def aplicar_sugerencia_duplicado_dra(dra: RecepcionDRA) -> None:
    for linea in dra.lineas:
        linea.cantidad_aceptada = 0
        linea.cantidad_rechazada = linea.cantidad_recibida
        linea.codigo_disposicion = CodigoDisposicionDRAEnum.DUPLICADO
        if not linea.glosa_rechazo:
            linea.glosa_rechazo = "Documento duplicado (folio + proveedor)"


def procesar_dra(db: Session, dra_id: UUID, usuario_id: UUID) -> RecepcionDRA:
    dra = db.query(RecepcionDRA).filter(RecepcionDRA.id == dra_id).first()
    if not dra:
        raise ValueError(f"RecepcionDRA {dra_id} no encontrada")
    if dra.estado != EstadoDRAEnum.BORRADOR:
        raise ValueError("La RecepcionDRA ya fue procesada")

    duplicada = validar_duplicidad_dra(
        db=db,
        empresa_id=dra.empresa_id,
        proveedor_id=cast(UUID, dra.proveedor_id),
        folio_documento=str(dra.folio_documento),
        dra_id=dra.id,
    )
    if duplicada:
        aplicar_sugerencia_duplicado_dra(dra)

    dra_any = cast(Any, dra)

    if not dra.bodega_id:
        if dra.orden_compra and dra.orden_compra.bodega_id:
            dra.bodega_id = dra.orden_compra.bodega_id
        else:
            if not dra.sucursal_id:
                raise ValueError("RecepcionDRA sin bodega ni sucursal asociada")
            bodega_default = InventoryService.get_bodega_default(
                db, cast(UUID, dra.sucursal_id)
            )
            dra_any.bodega_id = bodega_default.id

    for linea in dra.lineas:
        if linea.cantidad_aceptada > 0:
                InventoryService.add_stock(
                db=db,
                producto_id=linea.producto_id,
                    bodega_id=cast(UUID, dra.bodega_id),
                cantidad=linea.cantidad_aceptada,
                tipo_movimiento="DRA_RECEPCION",
                empresa_id=dra.empresa_id,
            )

    dra_any.estado = EstadoDRAEnum.POSTEADO
    dra_any.fecha_posteo = datetime.now()
    db.add(dra)
    db.commit()
    db.refresh(dra)
    return dra


def create_orden_compra(
    db: Session, orden_in: OrdenCompraCreate, usuario_id: UUID, empresa_id: UUID
) -> OrdenCompra:
    db_orden = OrdenCompra(
        proveedor_id=orden_in.proveedor_id,
        sucursal_id=orden_in.sucursal_id,
        bodega_id=orden_in.bodega_id,
        folio=orden_in.folio,
        # observacion=orden_in.observacion, # Model doesn't have observacion yet, check model definition again
        empresa_id=empresa_id,
        usuario_id=usuario_id,
        fecha_emision=datetime.now(),
        estado="BORRADOR",
        total_neto=0,
        total=0,
    )
    db.add(db_orden)
    db.flush()  # Generate ID

    total_neto = Decimal(0)
    for detalle_in in orden_in.detalles:
        subtotal = detalle_in.cantidad * detalle_in.precio_unitario
        db_detalle = OrdenCompraDetalle(
            orden_compra_id=db_orden.id,
            producto_id=detalle_in.producto_id,
            # descripcion=detalle_in.descripcion, # Model check
            cantidad=detalle_in.cantidad,
            precio_unitario=detalle_in.precio_unitario,
            subtotal=subtotal,
        )
        db.add(db_detalle)
        total_neto += subtotal

    db_orden.total_neto = total_neto
    # Impuesto desde configuración por empresa (Decimal, 4 decimales)
    from app.core_modules.finanzas.services import get_impuesto_rate
    tasa = get_impuesto_rate(db, empresa_id, "IVA")
    factor = (Decimal("1") + Decimal(str(tasa)))
    total_bruto = (Decimal(str(total_neto)) * factor).quantize(Decimal("0.01"))
    db_orden.total = total_bruto

    db.commit()
    db.refresh(db_orden)
    return db_orden


def get_orden_compra(
    db: Session, orden_id: UUID, empresa_id: UUID
) -> Optional[OrdenCompra]:
    return (
        db.query(OrdenCompra)
        .filter(OrdenCompra.id == orden_id, OrdenCompra.empresa_id == empresa_id)
        .first()
    )


def list_ordenes_compra(
    db: Session,
    empresa_id: UUID,
    skip: int = 0,
    limit: int = 100,
    proveedor_id: Optional[UUID] = None,
) -> List[OrdenCompra]:
    query = db.query(OrdenCompra).filter(OrdenCompra.empresa_id == empresa_id)
    if proveedor_id:
        query = query.filter(OrdenCompra.proveedor_id == proveedor_id)
    return query.offset(skip).limit(limit).all()


def update_orden_compra(
    db: Session, orden_id: UUID, orden_in: OrdenCompraUpdate, empresa_id: UUID
) -> OrdenCompra:
    orden = get_orden_compra(db, orden_id, empresa_id)
    if not orden:
        raise ValueError(f"Orden de Compra {orden_id} no encontrada")

    orden_any = cast(Any, orden)
    if orden_in.folio is not None:
        orden_any.folio = orden_in.folio
    if orden_in.estado is not None:
        orden_any.estado = orden_in.estado
    if orden_in.fecha_recepcion is not None:
        orden_any.fecha_recepcion = orden_in.fecha_recepcion

    db.commit()
    db.refresh(orden)
    return orden


# -----------------------------------------------------------------------------
# PROVEEDORES
# -----------------------------------------------------------------------------
def create_proveedor(
    db: Session, proveedor_in: ProveedorCreate, empresa_id: UUID
) -> Proveedor:
    proveedor = Proveedor(
        **proveedor_in.model_dump(), empresa_id=empresa_id
    )
    db.add(proveedor)
    db.commit()
    db.refresh(proveedor)
    return proveedor


def get_proveedor(
    db: Session, proveedor_id: UUID, empresa_id: UUID
) -> Optional[Proveedor]:
    return (
        db.query(Proveedor)
        .filter(
            Proveedor.id == proveedor_id,
            Proveedor.empresa_id == empresa_id,
            Proveedor.is_deleted.is_(False),
        )
        .first()
    )


def list_proveedores(
    db: Session, empresa_id: UUID, skip: int = 0, limit: int = 100
) -> List[Proveedor]:
    return (
        db.query(Proveedor)
        .filter(Proveedor.empresa_id == empresa_id, Proveedor.is_deleted.is_(False))
        .offset(skip)
        .limit(limit)
        .all()
    )


def update_proveedor(
    db: Session, proveedor_id: UUID, proveedor_in: ProveedorUpdate, empresa_id: UUID
) -> Proveedor:
    proveedor = get_proveedor(db, proveedor_id, empresa_id)
    if not proveedor:
        raise ValueError(f"Proveedor {proveedor_id} no encontrado")

    proveedor_data = proveedor_in.model_dump(exclude_unset=True)
    for field, value in proveedor_data.items():
        setattr(proveedor, field, value)

    db.add(proveedor)
    db.commit()
    db.refresh(proveedor)
    return proveedor


def delete_proveedor(db: Session, proveedor_id: UUID, empresa_id: UUID) -> Proveedor:
    proveedor = get_proveedor(db, proveedor_id, empresa_id)
    if not proveedor:
        raise ValueError(f"Proveedor {proveedor_id} no encontrado")

    proveedor.soft_delete(db)
    db.commit()
    return proveedor
