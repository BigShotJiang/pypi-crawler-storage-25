from sqlalchemy import Column, String, Integer, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship, Mapped
from app.core.database import Base, GUID
from uuid import UUID
import uuid6
from sqlalchemy.sql import func


class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"
    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    name = Column(String, unique=True, nullable=False)
    price_clp = Column(Integer, nullable=False, default=0)
    user_limit = Column(Integer, nullable=False, default=1)
    branch_limit = Column(Integer, nullable=False, default=1)
    is_active = Column(Boolean, default=True)


class CompanySubscription(Base):
    __tablename__ = "company_subscriptions"
    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    plan_id = Column(GUID, ForeignKey("subscription_plans.id"), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    plan = relationship("SubscriptionPlan")


class PaymentReceipt(Base):
    __tablename__ = "payment_receipts"
    id: Mapped[UUID] = Column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = Column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    plan_id = Column(GUID, ForeignKey("subscription_plans.id"), nullable=False)
    amount_clp = Column(Integer, nullable=False, default=0)
    paid_at = Column(DateTime(timezone=True), server_default=func.now())
    new_expires_at = Column(DateTime(timezone=True), nullable=False)
    plan = relationship("SubscriptionPlan")
