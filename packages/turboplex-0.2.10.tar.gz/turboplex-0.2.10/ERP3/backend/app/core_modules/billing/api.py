from datetime import datetime, timedelta
import math
from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api import deps
from . import models, schemas

router = APIRouter()


@router.get(
    "/billing/plans", response_model=List[schemas.SubscriptionPlan], tags=["Billing"]
)
def list_plans(
    db: Session = Depends(deps.get_db),
):
    return (
        db.query(models.SubscriptionPlan)
        .filter(models.SubscriptionPlan.is_active)
        .all()
    )


@router.get(
    "/billing/subscription/status",
    response_model=schemas.SubscriptionStatus,
    tags=["Billing"],
)
def get_status(
    db: Session = Depends(deps.get_db),
    current_company=Depends(deps.get_current_active_company),
):
    sub = (
        db.query(models.CompanySubscription)
        .filter(models.CompanySubscription.empresa_id == current_company.id)
        .first()
    )
    if not sub:
        return {
            "active": False,
            "next_due_date": None,
            "plan": None,
            "state": "expired",
            "grace_days_remaining": 0,
        }
    now = datetime.utcnow()
    if sub.expires_at and sub.expires_at > now:
        return {
            "active": True,
            "next_due_date": sub.expires_at,
            "plan": sub.plan,
            "state": "active",
            "grace_days_remaining": 0,
        }
    grace_days = getattr(current_company, "grace_period_days", 5) or 5
    grace_limit = (sub.expires_at or now) + timedelta(days=grace_days)
    if now <= grace_limit:
        remaining_seconds = (grace_limit - now).total_seconds()
        remaining_days = max(1, math.ceil(remaining_seconds / 86400))
        return {
            "active": False,
            "next_due_date": sub.expires_at,
            "plan": sub.plan,
            "state": "grace",
            "grace_days_remaining": remaining_days,
        }
    return {
        "active": False,
        "next_due_date": sub.expires_at,
        "plan": sub.plan,
        "state": "expired",
        "grace_days_remaining": 0,
    }


@router.post(
    "/billing/subscription/simulate-payment",
    response_model=schemas.SimulatePaymentResponse,
    tags=["Billing"],
)
def simulate_payment(
    db: Session = Depends(deps.get_db),
    current_company=Depends(deps.get_current_active_company),
):
    plan = (
        db.query(models.SubscriptionPlan)
        .filter(models.SubscriptionPlan.is_active)
        .order_by(models.SubscriptionPlan.price_clp.asc())
        .first()
    )
    if not plan:
        plan = models.SubscriptionPlan(
            name="Starter", price_clp=0, user_limit=3, branch_limit=1, is_active=True
        )
        db.add(plan)
        db.flush()
    sub = (
        db.query(models.CompanySubscription)
        .filter(models.CompanySubscription.empresa_id == current_company.id)
        .first()
    )
    now = datetime.utcnow()
    if not sub:
        sub = models.CompanySubscription(
            empresa_id=current_company.id, plan_id=plan.id, expires_at=now
        )
        db.add(sub)
        db.flush()
    base = sub.expires_at if sub.expires_at and sub.expires_at > now else now
    new_exp = base + timedelta(days=30)
    sub.plan_id = plan.id
    sub.expires_at = new_exp
    receipt = models.PaymentReceipt(
        empresa_id=current_company.id,
        plan_id=plan.id,
        amount_clp=plan.price_clp,
        new_expires_at=new_exp,
    )
    db.add(sub)
    db.add(receipt)
    db.commit()
    db.refresh(receipt)
    return {"receipt_id": receipt.id, "new_expires_at": new_exp}
