from pydantic import BaseModel, ConfigDict
from typing import Optional
from datetime import datetime
from uuid import UUID


class SubscriptionPlan(BaseModel):
    id: UUID
    name: str
    price_clp: int
    user_limit: int
    branch_limit: int
    model_config = ConfigDict(from_attributes=True)


class SubscriptionStatus(BaseModel):
    active: bool
    next_due_date: Optional[datetime] = None
    plan: Optional[SubscriptionPlan] = None
    state: str = "active"
    grace_days_remaining: int = 0


class SimulatePaymentResponse(BaseModel):
    receipt_id: UUID
    new_expires_at: datetime
