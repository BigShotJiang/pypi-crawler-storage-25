from typing import List, cast, Dict

from fastapi import APIRouter, Depends, BackgroundTasks, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func, case, or_

from uuid import UUID
from datetime import datetime, timedelta, timezone

from pydantic import EmailStr

from app.api import deps
from app.core_modules.sistema import schemas
from app.core.infrastructure.api_schemas import BaseResponse
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    Sucursal,
    Bodega,
    MetodoPago,
    EmpresaMetodoPago,
    BackgroundJobLog,
)
from app.core_modules.ventas import models as ventas_models
from app.core_modules.ventas import schemas as ventas_schemas
from app.core_modules.inventario.stock import models as stock_models
from app.core.exceptions import BusinessRuleError
from app.core.exceptions import wrap_background_task

router = APIRouter()


@router.get(
    "/dashboard",
    response_model=schemas.DashboardResponse,
    tags=["Sistema"],
)
def get_dashboard(
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> schemas.DashboardResponse:
    return schemas.DashboardResponse(
        mensaje=f"Cargando dashboard para: {current_company.nombre}",
        empresa_id=current_company.id,
        empresa_codigo=cast(str, current_company.codigo),
        user_role=cast(str, current_user.role),
        user_email=cast(EmailStr, current_user.email),
    )

@router.get(
    "/v2/dashboard",
    response_model=BaseResponse[schemas.DashboardResponse],
    tags=["Sistema"],
)
def get_dashboard_v2(
    current_user: Usuario = Depends(deps.get_current_user),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> BaseResponse[schemas.DashboardResponse]:
    data = schemas.DashboardResponse(
        mensaje=f"Cargando dashboard para: {current_company.nombre}",
        empresa_id=current_company.id,
        empresa_codigo=cast(str, current_company.codigo),
        user_role=cast(str, current_user.role),
        user_email=cast(EmailStr, current_user.email),
    )
    return BaseResponse(success=True, data=data)


@router.get(
    "/locations",
    response_model=List[schemas.SucursalLocation],
    tags=["Sistema"],
)
def get_company_locations(
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> List[schemas.SucursalLocation]:
    sucursales = (
        db.query(Sucursal)
        .filter(Sucursal.empresa_id == current_company.id)
        .options(joinedload(getattr(Sucursal, "bodegas")))
        .all()
    )

    result: List[schemas.SucursalLocation] = []
    for suc in sucursales:
        bodegas = getattr(suc, "bodegas", [])
        bodegas_data = [
            schemas.BodegaLocation(
                id=b.id,
                nombre=cast(str, b.nombre),
                codigo=cast(str, b.codigo),
            )
            for b in bodegas
            if b.is_active
        ]
        result.append(
            schemas.SucursalLocation(
                id=suc.id,
                nombre=cast(str, suc.nombre),
                codigo=cast(str, suc.codigo),
                bodegas=bodegas_data,
            )
        )

    return result


@router.get(
    "/inventario/global",
    response_model=List[ventas_schemas.InventarioGlobalItem],
    tags=["Ventas"],
)
def get_inventario_global(
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
    sucursal_id: UUID | None = Query(None),
    bodega_id: UUID | None = Query(None),
    tipo_producto: str | None = Query(None),
    search: str | None = Query(None),
) -> List[ventas_schemas.InventarioGlobalItem]:
    query = (
        db.query(
            stock_models.Inventario,
            ventas_models.Producto,
            Bodega,
            Sucursal,
        )
        .join(
            ventas_models.Producto,
            stock_models.Inventario.producto_id == ventas_models.Producto.id,
        )
        .join(Bodega, stock_models.Inventario.bodega_id == Bodega.id)
        .join(Sucursal, Bodega.sucursal_id == Sucursal.id)
        .filter(
            ventas_models.Producto.empresa_id == current_company.id,
            Sucursal.empresa_id == current_company.id,
        )
    )

    if sucursal_id:
        query = query.filter(Sucursal.id == sucursal_id)
    if bodega_id:
        query = query.filter(Bodega.id == bodega_id)
    if tipo_producto:
        query = query.filter(ventas_models.Producto.tipo_producto == tipo_producto)
    if search:
        like = f"%{search}%"
        query = query.filter(
            or_(
                ventas_models.Producto.nombre.ilike(like),
                ventas_models.Producto.sku.ilike(like),
            )
        )

    rows = query.order_by(ventas_models.Producto.nombre.asc()).all()
    result = [
        ventas_schemas.InventarioGlobalItem(
            producto_id=producto.id,
            sku=cast(str, producto.sku),
            producto_nombre=cast(str, producto.nombre),
            tipo_producto=cast(str, producto.tipo_producto),
            bodega_nombre=cast(str, bodega.nombre),
            sucursal_nombre=cast(str, sucursal.nombre),
            fisica_disponible=int(inventario.cantidad)
            - int(inventario.cantidad_reservada),
            fisica_reservada=int(inventario.cantidad_reservada),
        )
        for inventario, producto, bodega, sucursal in rows
    ]
    return result


@router.get(
    "/v2/locations",
    response_model=BaseResponse[List[schemas.SucursalLocation]],
    tags=["Sistema"],
)
def get_company_locations_v2(
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
    current_user: Usuario = Depends(deps.get_current_user),
) -> BaseResponse[List[schemas.SucursalLocation]]:
    sucursales = (
        db.query(Sucursal)
        .filter(Sucursal.empresa_id == current_company.id)
        .options(joinedload(getattr(Sucursal, "bodegas")))
        .all()
    )
    result: List[schemas.SucursalLocation] = []
    for suc in sucursales:
        bodegas = getattr(suc, "bodegas", [])
        bodegas_data = [
            schemas.BodegaLocation(
                id=b.id,
                nombre=cast(str, b.nombre),
                codigo=cast(str, b.codigo),
            )
            for b in bodegas
            if b.is_active
        ]
        result.append(
            schemas.SucursalLocation(
                id=suc.id,
                nombre=cast(str, suc.nombre),
                codigo=cast(str, suc.codigo),
                bodegas=bodegas_data,
            )
        )
    return BaseResponse(success=True, data=result)


@router.get(
    "/v2/test/async-error",
    response_model=BaseResponse[Dict[str, str]],
    tags=["Sistema"],
)
def trigger_async_error(
    background_tasks: BackgroundTasks,
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> BaseResponse[Dict[str, str]]:
    def task_fail() -> None:
        raise BusinessRuleError("No hay stock suficiente para la tarea de prueba.")

    background_tasks.add_task(
        wrap_background_task(task_fail, task_name="test_async_business_error")
    )
    return BaseResponse(success=True, data={"status": "scheduled"})


@router.get(
    "/v2/test/jobs-history",
    response_model=BaseResponse[List[schemas.BackgroundJobLogOut]],
    tags=["Sistema"],
)
def get_jobs_history(
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
    status: str | None = Query(None),
    task_name: str | None = Query(None),
    limit: int = Query(50, gt=0, le=200),
) -> BaseResponse[List[schemas.BackgroundJobLogOut]]:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        query = db.query(BackgroundJobLog).order_by(
            BackgroundJobLog.created_at.desc()
        )
        if status:
            query = query.filter(BackgroundJobLog.status == status)
        if task_name:
            query = query.filter(BackgroundJobLog.task_name == task_name)
        logs = query.limit(limit).all()
        data = [schemas.BackgroundJobLogOut.model_validate(log) for log in logs]
        return BaseResponse(success=True, data=data)
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router.get(
    "/v2/sistema/jobs-stats",
    response_model=BaseResponse[Dict[str, object]],
    tags=["Sistema"],
)
def get_jobs_stats(
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> BaseResponse[Dict[str, object]]:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        now = datetime.now(timezone.utc)
        since = now - timedelta(hours=24)
        base_q = db.query(BackgroundJobLog).filter(
            BackgroundJobLog.created_at >= since
        )
        total_24h = base_q.count()
        success_24h = base_q.filter(BackgroundJobLog.status == "SUCCESS").count()
        errors_24h = base_q.filter(BackgroundJobLog.status == "ERROR").count()

        most_failing_task: str | None = None
        if errors_24h > 0:
            row = (
                db.query(
                    BackgroundJobLog.task_name,
                    func.count(BackgroundJobLog.id).label("cnt"),
                )
                .filter(
                    BackgroundJobLog.created_at >= since,
                    BackgroundJobLog.status == "ERROR",
                )
                .group_by(BackgroundJobLog.task_name)
                .order_by(func.count(BackgroundJobLog.id).desc())
                .first()
            )
            if row is not None:
                most_failing_task = row[0]

        # Breakdown per task
        tasks_stats = []
        rows = (
            db.query(
                BackgroundJobLog.task_name,
                func.count(BackgroundJobLog.id).label("total"),
                func.sum(
                    case((BackgroundJobLog.status == "ERROR", 1), else_=0)
                ).label("errors"),
            )
            .filter(BackgroundJobLog.created_at >= since)
            .group_by(BackgroundJobLog.task_name)
            .all()
        )
        for r in rows:
            t_total = r.total
            t_errors = r.errors or 0
            t_success = t_total - t_errors
            tasks_stats.append({
                "name": r.task_name,
                "total_24h": t_total,
                "success_24h": t_success,
                "errors_24h": t_errors,
            })

        data: Dict[str, object] = {
            "total_24h": total_24h,
            "success_24h": success_24h,
            "errors_24h": errors_24h,
            "most_failing_task": most_failing_task,
            "tasks": tasks_stats,
        }
        return BaseResponse(success=True, data=data)
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant

@router.get(
    "/metodos-pago", response_model=List[schemas.MetodoPago], tags=["Sistema"]
)
def listar_metodos_pago(
    db: Session = Depends(deps.get_db),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> List[MetodoPago]:
    links = (
        db.query(EmpresaMetodoPago)
        .filter(
            EmpresaMetodoPago.empresa_id == current_company.id,
            EmpresaMetodoPago.is_active,
        )
        .all()
    )
    ids = [link.metodo_pago_id for link in links if link.metodo_pago_id]
    if not ids:
        efectivo = db.query(MetodoPago).filter(MetodoPago.codigo == "EFECTIVO").first()
        return [efectivo] if efectivo else []
    metodos = db.query(MetodoPago).filter(MetodoPago.id.in_(ids)).all()
    return metodos
