from typing import Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from uuid import UUID

from app.api import deps
from app.core.database import get_db
from app.core.services.feature_service import feature_service
from app.core_modules.sistema.models import Usuario

router = APIRouter()

class FeatureToggleRequest(BaseModel):
    empresa_id: UUID
    feature_key: str
    enabled: bool

@router.post("/features/toggle", status_code=200)
def toggle_feature(
    payload: FeatureToggleRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> Any:
    """
    Pilar 10: Activa o desactiva una feature flag para una empresa específica.
    Rol requerido: SUPERADMIN.
    """
    result = feature_service.toggle_feature(
        db=db,
        empresa_id=str(payload.empresa_id),
        feature_key=payload.feature_key,
        enabled=payload.enabled
    )
    
    if result is None:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
        
    return {
        "message": "Feature flag updated successfully",
        "empresa_id": payload.empresa_id,
        "feature": payload.feature_key,
        "enabled": payload.enabled,
        "current_flags": result
    }
