from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from sqlalchemy.orm import Session

from app.core_modules.sistema.models import (
    AuditLog,
    AuditSeverity,
    Empresa,
    EmpresaConfigAtributo,
    PapeleraReciclaje,
    Rol,
    Usuario,
    UsuarioEmpresa,
)


def get_usuario_empresa_rol_codigo(
    db: Session, *, usuario_id: UUID, empresa_id: UUID
) -> str | None:
    association = (
        db.query(UsuarioEmpresa)
        .join(Rol, UsuarioEmpresa.rol_id == Rol.id, isouter=True)
        .filter(
            UsuarioEmpresa.usuario_id == usuario_id,
            UsuarioEmpresa.empresa_id == empresa_id,
        )
        .first()
    )
    return association.rol.codigo if association and association.rol else None


def get_empresa_for_portal_login(
    db: Session, *, empresa_codigo: str
) -> tuple[UUID, bool] | None:
    row = (
        db.query(Empresa.id, Empresa.is_active)
        .filter(Empresa.codigo == empresa_codigo)
        .first()
    )
    if not row:
        return None
    empresa_id, is_active = row
    return empresa_id, bool(is_active)


def list_platform_admin_user_ids(db: Session) -> list[UUID]:
    rows = db.query(Usuario.id).filter(Usuario.role == "ADMIN").all()
    return [row[0] for row in rows]


def get_empresa_limite_cupo_maximo(db: Session, *, empresa_id: UUID) -> Decimal | None:
    row = (
        db.query(Empresa.limite_cupo_maximo)
        .filter(Empresa.id == empresa_id)
        .first()
    )
    if not row:
        return None
    return Decimal(str(row[0]))


def create_papelera_entry(
    db: Session,
    *,
    tabla_origen: str,
    empresa_id: UUID | None,
    ejecutado_por_id: UUID | None,
    payload: dict,
) -> UUID:
    papelera = PapeleraReciclaje(
        tabla_origen=tabla_origen,
        empresa_id=empresa_id,
        ejecutado_por_id=ejecutado_por_id,
        payload=payload,
    )
    db.add(papelera)
    db.flush()
    return papelera.id


def create_audit_log(
    db: Session,
    *,
    actor_id: UUID | None,
    action: str,
    resource: str,
    severity: AuditSeverity | str = AuditSeverity.INFO,
    changes: dict | None = None,
    ip_address: str | None = None,
) -> UUID:
    audit_log = AuditLog(
        actor_id=actor_id,
        action=action,
        resource=resource,
        severity=str(severity),
        changes=changes,
        ip_address=ip_address,
    )
    db.add(audit_log)
    db.flush()
    return audit_log.id


def is_empresa_feature_enabled(
    db: Session,
    *,
    empresa_id: UUID,
    feature_key: str,
) -> bool:
    row = db.query(Empresa.modulos_activos, Empresa.feature_flags).filter(
        Empresa.id == empresa_id
    ).first()
    if not row:
        return False
    modulos_activos, feature_flags = row
    modulos = modulos_activos or []
    flags = feature_flags or {}
    key = (feature_key or "").strip()
    candidates = {
        key,
        key.lower(),
        key.upper(),
        f"{key}_enabled",
        f"{key.lower()}_enabled",
        f"{key.upper()}_ENABLED",
    }
    if any(bool(flags.get(k)) for k in candidates):
        return True
    if key and key.upper() in {str(m).upper() for m in modulos}:
        return True
    return False


def get_empresa_config_atributos_activos(
    db: Session,
    *,
    empresa_id: UUID,
    entidad: str,
) -> dict[str, str]:
    rows = (
        db.query(EmpresaConfigAtributo.nombre_atributo, EmpresaConfigAtributo.label_visible)
        .filter(
            EmpresaConfigAtributo.empresa_id == empresa_id,
            EmpresaConfigAtributo.entidad == entidad,
            EmpresaConfigAtributo.activo.is_(True),
        )
        .all()
    )
    return {str(nombre): str(label) for nombre, label in rows if nombre}


def filtrar_additional_attributes_por_diccionario(
    db: Session,
    *,
    empresa_id: UUID,
    entidad: str,
    additional_attributes: dict[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(additional_attributes, dict) or not additional_attributes:
        return {}
    activos = set(get_empresa_config_atributos_activos(db, empresa_id=empresa_id, entidad=entidad).keys())
    if not activos:
        return {}
    return {k: v for k, v in additional_attributes.items() if k in activos}


def build_additional_attributes_visibles_payload(
    db: Session,
    *,
    empresa_id: UUID,
    entidad: str,
    additional_attributes: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    if not isinstance(additional_attributes, dict) or not additional_attributes:
        return []
    dic = get_empresa_config_atributos_activos(db, empresa_id=empresa_id, entidad=entidad)
    if not dic:
        return []
    out: list[dict[str, Any]] = []
    for k, v in additional_attributes.items():
        label = dic.get(k)
        if not label:
            continue
        out.append({"key": k, "label": label, "value": v})
    return out
