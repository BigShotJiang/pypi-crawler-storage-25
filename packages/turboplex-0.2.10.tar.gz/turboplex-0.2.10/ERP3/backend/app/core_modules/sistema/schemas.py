from typing import Optional, List, Any
from pydantic import BaseModel, EmailStr, ConfigDict
from datetime import datetime
from uuid import UUID


# --- Empresa Schemas ---
class EmpresaBase(BaseModel):
    nombre: Optional[str] = None
    codigo: Optional[str] = None
    rut: Optional[str] = None
    grace_period_days: Optional[int] = 5
    is_active: Optional[bool] = True
    modulos_activos: Optional[List[str]] = [
        "CORE",
        "VENTAS",
        "FINANZAS",
        "RRHH",
        "TI",
        "SISTEMA",
    ]
    pwr_bi_enabled: Optional[bool] = False
    pwr_bi_config: Optional[Any] = {}
    
    # Feature Flags
    feature_flags: Optional[Any] = {}

    @property
    def permitir_pagos_efectivo(self) -> bool:
        # Check if POS module is active in modulos_activos list
        # We assume "POS" or "CAJA" or "VENTAS_POS" is the key. 
        # Standard list: ["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA"]
        # User said "considera el módulo de Caja como un Add-on opcional".
        # Let's check for "POS" or "CAJA" in modulos_activos.
        is_pos_active = False
        if self.modulos_activos:
            # "POS_RETAIL" is used in Frontend Sidebar. "POS" or "CAJA" might be used in DB.
            is_pos_active = any(m in self.modulos_activos for m in ["POS", "CAJA", "POS_RETAIL"])
        
        if not is_pos_active:
            return False

        if self.feature_flags:
             # Default True if not specified, or False? 
             # Usually cash is allowed by default, unless disabled.
             # User said "Agrega... un switch", implying it might be off by default or configurable.
             # Let's assume default True for now, but respect flag.
             return self.feature_flags.get("permitir_pagos_efectivo", True)
        return True


class EmpresaCreate(EmpresaBase):
    nombre: str
    codigo: str


class EmpresaUpdate(EmpresaBase):
    pass


class EmpresaInDBBase(EmpresaBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True)


class Empresa(EmpresaInDBBase):
    bodegas_count: Optional[int] = 0


# --- Rol Schemas ---
class RolLite(BaseModel):
    id: UUID
    codigo: str
    nombre: str

    model_config = ConfigDict(from_attributes=True)


# --- UsuarioEmpresa Schemas ---
class UsuarioEmpresaBase(BaseModel):
    is_default: bool = False
    empresa_id: UUID


class UsuarioEmpresa(UsuarioEmpresaBase):
    empresa: Optional[Empresa] = None
    rol: Optional[RolLite] = None

    model_config = ConfigDict(from_attributes=True)


# --- Usuario Schemas ---
class UsuarioBase(BaseModel):
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = True
    role: str = "USER"
    nombre: Optional[str] = None
    mfa_enabled: bool = False
    mfa_enforced: bool = False


class UsuarioCreate(UsuarioBase):
    email: EmailStr
    password: str


class UsuarioUpdate(UsuarioBase):
    password: Optional[str] = None


class UsuarioInDBBase(UsuarioBase):
    id: Optional[UUID] = None
    model_config = ConfigDict(from_attributes=True)


class Usuario(UsuarioInDBBase):
    id: UUID
    empresas_asociadas: List[UsuarioEmpresa] = []


class AdminCompanyUser(BaseModel):
    id: UUID
    email: EmailStr
    is_active: bool
    platform_role: str
    company_role: Optional[RolLite] = None
    is_default: bool = False


class AdminLinkExistingUserRequest(BaseModel):
    email: EmailStr
    rol_codigo: str
    is_default: bool = False


class AdminSetCompanyUserRoleRequest(BaseModel):
    rol_codigo: str
    is_default: Optional[bool] = None


# --- Sucursal Schemas ---
class SucursalBase(BaseModel):
    nombre: Optional[str] = None
    codigo: Optional[str] = None
    direccion: Optional[str] = None
    empresa_id: Optional[UUID] = None


class SucursalCreate(SucursalBase):
    nombre: str
    codigo: str


class SucursalUpdate(SucursalBase):
    pass


class SucursalInDBBase(SucursalBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True)


class Sucursal(SucursalInDBBase):
    pass


# --- MetodoPago Schemas ---
class MetodoPagoBase(BaseModel):
    nombre: Optional[str] = None
    codigo: Optional[str] = None
    is_active: Optional[bool] = True


class MetodoPagoCreate(MetodoPagoBase):
    nombre: str
    codigo: str


class MetodoPagoUpdate(MetodoPagoBase):
    pass


class MetodoPagoInDBBase(MetodoPagoBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True)


class MetodoPago(MetodoPagoInDBBase):
    pass


# --- AuditLog Schemas ---
class AuditLogBase(BaseModel):
    action: str
    resource: str
    severity: str = "INFO"
    changes: Optional[Any] = None
    ip_address: Optional[str] = None


class AuditLogCreate(AuditLogBase):
    actor_id: UUID
    impersonated_user_id: Optional[UUID] = None


class AuditLog(AuditLogBase):
    id: UUID
    created_at: datetime
    actor_id: UUID

    model_config = ConfigDict(from_attributes=True)


class BackgroundJobLogOut(BaseModel):
    id: UUID
    task_name: str
    status: str
    request_id: str
    duration_ms: Optional[int] = None
    error_code: Optional[str] = None
    error_detail: Optional[Any] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# --- Auth Schemas ---
class Token(BaseModel):
    access_token: str
    token_type: str
    mfa_required: Optional[bool] = False
    mfa_setup_required: Optional[bool] = False
    temp_token: Optional[str] = None


class TokenPayload(BaseModel):
    sub: Optional[UUID] = None


class EmpresaLite(BaseModel):
    id: UUID
    codigo: str
    nombre: str


class PublicOnboardingResponse(BaseModel):
    access_token: str
    token_type: str
    empresa: EmpresaLite
    redirect_url: str


class SetupClientUsuarioLite(BaseModel):
    id: UUID
    email: EmailStr
    role: str


class SetupClientResponse(BaseModel):
    empresa: EmpresaLite
    usuario: SetupClientUsuarioLite


class DashboardResponse(BaseModel):
    mensaje: str
    empresa_id: UUID
    empresa_codigo: str
    user_role: str
    user_email: EmailStr


class BodegaLocation(BaseModel):
    id: UUID
    nombre: str
    codigo: str


class SucursalLocation(BaseModel):
    id: UUID
    nombre: str
    codigo: str
    bodegas: List[BodegaLocation]


class PowerBICredentials(BaseModel):
    host: str
    port: int
    database: str
    username: str
    password: str


class RotateBICredentialsResponse(BaseModel):
    message: str
    credentials: PowerBICredentials
    warning: str
