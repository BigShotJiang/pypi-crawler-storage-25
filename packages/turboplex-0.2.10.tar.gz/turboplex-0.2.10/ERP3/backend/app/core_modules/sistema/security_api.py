from typing import Any
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from app.api import deps
from app.core.database import get_db
from app.core.infrastructure.rate_limit import limiter
from app.core.security.secrets_manager_service import secrets_manager
from app.core_modules.sistema.models import Usuario

router = APIRouter()

class SecretRotationRequest(BaseModel):
    key: str = Field(..., description="Clave del secreto a rotar (ej. FIRMA_DIGITAL_PASSWORD)")
    new_value: str = Field(..., description="Nuevo valor del secreto")

@router.post("/rotate-secrets", status_code=200)
@limiter.limit("5/minute")
def rotate_secrets(
    request: Request,
    payload: SecretRotationRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> Any:
    """
    Rota un secreto del sistema de forma segura.
    
    Requisitos:
    - Rol: SUPERADMIN o DEVELOPER
    - Rate Limit: 5 peticiones por minuto por IP
    
    Efectos:
    - Actualiza el secreto encriptado en la base de datos.
    - Genera un AuditLog nivel CRITICAL.
    """
    secret = secrets_manager.rotate_secret(
        db=db,
        key=payload.key,
        new_value=payload.new_value,
        actor_id=current_user.id
    )
    
    return {
        "message": "Secret rotated successfully",
        "key": secret.key,
        "updated_at": secret.updated_at
    }
