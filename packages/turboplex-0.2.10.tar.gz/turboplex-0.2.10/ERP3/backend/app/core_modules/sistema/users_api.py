from typing import List, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session

from app.api import deps
from app.core.security import get_password_hash
from app.core_modules.sistema import schemas
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    UsuarioEmpresa,
    Rol,
    AuditSeverity,
)
from app.core.security.security_audit import security_audit

router = APIRouter()

# Admin roles allowed to manage users
ALLOWED_ROLES = [
    deps.UserRole.ADMIN,
    deps.UserRole.TI_ADMIN,
    deps.UserRole.SUPERADMIN,
    deps.UserRole.DEVELOPER,
]

@router.get("/users", response_model=List[schemas.Usuario], tags=["Users"])
def list_company_users(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    List users associated with the current company.
    """
    # Join UsuarioEmpresa to filter by company
    users = (
        db.query(Usuario)
        .join(UsuarioEmpresa)
        .filter(UsuarioEmpresa.empresa_id == current_company.id)
        .offset(skip)
        .limit(limit)
        .all()
    )
    return users

@router.patch("/users/{user_id}/mfa-enforcement", response_model=schemas.Usuario, tags=["Users"])
def toggle_mfa_enforcement(
    user_id: UUID,
    enforce: bool = Body(..., embed=True),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Enable or disable MFA enforcement for a specific user.
    When enabled, the user MUST set up MFA on next login if not already done.
    """
    # verify user belongs to company
    user_association = (
        db.query(UsuarioEmpresa)
        .filter(
            UsuarioEmpresa.usuario_id == user_id,
            UsuarioEmpresa.empresa_id == current_company.id
        )
        .first()
    )
    
    if not user_association:
        # Check if superadmin is accessing cross-tenant? No, adhere to current_company scope.
        raise HTTPException(status_code=404, detail="User not found in this company")

    user = db.query(Usuario).filter(Usuario.id == user_id).first()
    if not user:
         raise HTTPException(status_code=404, detail="User not found")

    if user.mfa_enforced == enforce:
        return user # No change

    # Log the change
    security_audit.log(
        db=db,
        actor_id=current_user.id,
        action="MFA_ENFORCEMENT_CHANGE",
        resource=f"Usuario:{user_id}",
        severity=AuditSeverity.WARNING,
        changes={
            "mfa_enforced": enforce,
            "previous": user.mfa_enforced,
            "enforced_by_company": str(current_company.id)
        }
    )

    user.mfa_enforced = enforce
    db.add(user)
    db.commit()
    db.refresh(user)
    
    return user

@router.post("/users", response_model=schemas.Usuario, status_code=201, tags=["Users"])
def create_user(
    *,
    db: Session = Depends(deps.get_db),
    user_in: schemas.UsuarioCreate,
    current_user: Usuario = deps.role_required(ALLOWED_ROLES),
    current_company: Empresa = Depends(deps.get_current_active_company),
) -> Any:
    """
    Create new user in the current company.
    """
    # 1. Check if user already exists globally
    user = db.query(Usuario).filter(Usuario.email == user_in.email).first()
    if user:
        # Check if already in this company
        user_empresa = db.query(UsuarioEmpresa).filter(
            UsuarioEmpresa.usuario_id == user.id,
            UsuarioEmpresa.empresa_id == current_company.id
        ).first()
        if user_empresa:
             raise HTTPException(
                status_code=400,
                detail="The user with this email already exists in this company.",
            )
        # If exists globally but not in company, we could link them, but for now let's keep it simple
        # and assume unique emails for new creation flow or require explicit linking endpoint.
        # To be safe, raise error.
        raise HTTPException(
            status_code=400,
            detail="The user with this email already exists in the system. Please use 'Add Existing User' feature (not implemented yet).",
        )

    # 2. Validate Role in Company
    # user_in.role contains the company role code (e.g. 'VEN', 'CRM', 'ADM')
    role_code = user_in.role
    target_role = db.query(Rol).filter(
        Rol.empresa_id == current_company.id,
        Rol.codigo == role_code
    ).first()
    
    if not target_role:
        # Fallback: check if it's a valid default role code and try to find it
        # But since we ran the migration script, it should be there.
        raise HTTPException(
            status_code=400,
            detail=f"Role '{role_code}' not found in this company.",
        )

    # 3. Create User (Global)
    user = Usuario(
        email=user_in.email,
        hashed_password=get_password_hash(user_in.password),
        nombre=user_in.nombre,
        is_active=True,
        role="USER", # Always create as standard user
        mfa_enabled=False,
        mfa_enforced=False
    )
    db.add(user)
    db.flush() # get ID

    # 4. Link to Company
    user_empresa = UsuarioEmpresa(
        usuario_id=user.id,
        empresa_id=current_company.id,
        rol_id=target_role.id,
        is_default=True
    )
    db.add(user_empresa)

    # 5. Audit Log
    security_audit.log(
        db=db,
        actor_id=current_user.id,
        action="USER_CREATE",
        resource=f"Usuario:{user.id}",
        severity=AuditSeverity.INFO,
        changes={
            "email": user.email,
            "company_role": role_code,
            "company_id": str(current_company.id)
        }
    )

    db.commit()
    db.refresh(user)
    return user
