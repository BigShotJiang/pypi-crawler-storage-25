from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session, joinedload

from app.api import deps
from app.core.services.bi_service import rotate_bi_credentials as bi_rotate
from app.core_modules.sistema import schemas
from app.core.infrastructure.api_schemas import PagedResponse, MetaPayload, PageMeta
from datetime import datetime, timezone
from app.core_modules.billing.models import CompanySubscription
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    Sucursal,
    UsuarioEmpresa,
    Rol,
    AuditSeverity,
)
from app.core.security.security_audit import security_audit

router = APIRouter()

_ADMIN_ALLOWED_COMPANY_ROLE_CODES = {
    "ADM",
    "SUP",
    "VEN",
    "BOD",
    "CON",
    "CRM",
    "BACKOFFICE",
    "AUD",
    "OPS",
}


def _resolve_or_create_role(db: Session, empresa_id: UUID, codigo: str) -> Rol:
    role_code = (codigo or "").strip().upper()
    if role_code not in _ADMIN_ALLOWED_COMPANY_ROLE_CODES:
        raise HTTPException(status_code=400, detail="Rol no permitido")

    rol = (
        db.query(Rol)
        .filter(Rol.empresa_id == empresa_id, Rol.codigo == role_code)
        .first()
    )
    if rol:
        return rol

    nombres = {
        "ADM": "Administrador Único de Empresa",
        "SUP": "Supervisor",
        "VEN": "Vendedor",
        "BOD": "Bodeguero",
        "CON": "Contador",
        "CRM": "Usuario CRM",
        "BACKOFFICE": "Backoffice",
        "AUD": "Auditor",
        "OPS": "Operaciones",
    }
    rol = Rol(
        empresa_id=empresa_id,
        codigo=role_code,
        nombre=nombres.get(role_code, role_code),
        is_active=True,
    )
    db.add(rol)
    db.flush()
    return rol


@router.get("/empresas", response_model=List[schemas.Empresa], tags=["Sistema"])
def listar_todas_las_empresas(
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
    skip: int = 0,
    limit: int = 100,
) -> List[Empresa]:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        empresas = (
            db.query(Empresa)
            .options(
                joinedload(getattr(Empresa, "sucursales")).joinedload(
                    getattr(Sucursal, "bodegas")
                )
            )
            .offset(skip)
            .limit(limit)
            .all()
        )
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant

    for emp in empresas:
        count = 0
        sucursales = getattr(emp, "sucursales", [])
        for suc in sucursales:
            bodegas = getattr(suc, "bodegas", [])
            count += len(bodegas)
        setattr(emp, "bodegas_count", count)
    return empresas

@router.get("/v2/empresas", response_model=PagedResponse[schemas.Empresa], tags=["Sistema"])
def listar_todas_las_empresas_v2(
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
    skip: int = 0,
    limit: int = 100,
) -> PagedResponse[schemas.Empresa]:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        total_items = db.query(Empresa).count()
        empresas = (
            db.query(Empresa)
            .options(
                joinedload(getattr(Empresa, "sucursales")).joinedload(
                    getattr(Sucursal, "bodegas")
                )
            )
            .offset(skip)
            .limit(limit)
            .all()
        )
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant

    for emp in empresas:
        count = 0
        sucursales = getattr(emp, "sucursales", [])
        for suc in sucursales:
            bodegas = getattr(suc, "bodegas", [])
            count += len(bodegas)
        setattr(emp, "bodegas_count", count)
    page = skip // limit if limit > 0 else 0
    total_pages = (total_items + limit - 1) // limit if limit > 0 else 1
    has_next = (skip + limit) < total_items
    has_prev = skip > 0
    meta = MetaPayload(
        timestamp=datetime.now(timezone.utc).isoformat(),
        page=PageMeta(
            page=page,
            size=limit,
            total_items=total_items,
            total_pages=total_pages,
            has_next=has_next,
            has_prev=has_prev,
        ),
    )
    return PagedResponse(success=True, data=empresas, meta=meta)


@router.post(
    "/admin/empresas/{empresa_id}/toggle-active",
    response_model=schemas.Empresa,
    tags=["Admin"],
)
def toggle_empresa_active(
    empresa_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> Empresa:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        if not empresa:
            raise HTTPException(status_code=404, detail="Empresa no encontrada")
        setattr(empresa, "is_active", not bool(empresa.is_active))
        db.add(empresa)
        db.commit()
        db.refresh(empresa)
        return empresa
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router.patch(
    "/empresas/{empresa_id}", response_model=schemas.Empresa, tags=["Sistema"]
)
def actualizar_empresa(
    empresa_id: UUID,
    empresa_in: schemas.EmpresaUpdate,
    request: Request,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Empresa:
    try:
        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        if not empresa:
            raise HTTPException(status_code=404, detail="Empresa no encontrada")

        update_data = empresa_in.model_dump(exclude_unset=True)
        changes: dict[str, dict[str, object]] = {"before": {}, "after": {}}
        has_changes = False

        for field, new_value in update_data.items():
            old_value = getattr(empresa, field)
            if old_value != new_value:
                changes["before"][field] = old_value
                changes["after"][field] = new_value
                has_changes = True
                setattr(empresa, field, new_value)

        if has_changes:
            db.add(empresa)
            db.commit()
            db.refresh(empresa)

            security_audit.log(
                db=db,
                actor_id=current_user.id,
                action="UPDATE_EMPRESA",
                resource=f"Empresa:{empresa_id}",
                severity=AuditSeverity.INFO,
                changes=changes,
                request=request,
            )

            if "grace_period_days" in update_data and changes["before"].get(
                "grace_period_days"
            ) != changes["after"].get("grace_period_days"):
                security_audit.log(
                    db=db,
                    actor_id=current_user.id,
                    action=(
                        f"SuperAdmin cambió días de gracia de Empresa "
                        f"{empresa.nombre} a "
                        f"[{changes['after']['grace_period_days']}] días"
                    ),
                    resource=f"Empresa:{empresa_id}",
                    severity=AuditSeverity.INFO,
                    changes={
                        "field": "grace_period_days",
                        "before": changes["before"].get("grace_period_days"),
                        "after": changes["after"].get("grace_period_days"),
                    },
                    request=request,
                )

        return empresa
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/empresas/{empresa_id}/rotate-bi-credentials", tags=["Sistema"])
def rotate_bi_credentials(
    empresa_id: UUID,
    request: Request,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user),
) -> schemas.RotateBICredentialsResponse:
    if current_user.role not in ["ADMIN", "DEVELOPER"]:
        raise HTTPException(status_code=403, detail="No autorizado")
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    if not empresa.pwr_bi_enabled:
        raise HTTPException(status_code=403, detail="BI Add-on not active for this tenant")
    sub = (
        db.query(CompanySubscription)
        .filter(CompanySubscription.empresa_id == empresa_id)
        .first()
    )
    now = datetime.utcnow()
    if not sub or not sub.expires_at or sub.expires_at <= now:
        raise HTTPException(status_code=403, detail="BI Add-on not active for this tenant")
    return bi_rotate(db=db, empresa_id=empresa_id, current_user=current_user, request=request)


@router.get(
    "/admin/empresas/{empresa_id}/users",
    response_model=List[schemas.AdminCompanyUser],
    tags=["Admin"],
)
def admin_list_company_users(
    empresa_id: UUID,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> List[schemas.AdminCompanyUser]:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        if not empresa:
            raise HTTPException(status_code=404, detail="Empresa no encontrada")

        links = (
            db.query(UsuarioEmpresa)
            .options(joinedload(UsuarioEmpresa.usuario), joinedload(UsuarioEmpresa.rol))
            .filter(UsuarioEmpresa.empresa_id == empresa_id)
            .all()
        )
        return [
            schemas.AdminCompanyUser(
                id=link.usuario.id,
                email=link.usuario.email,
                is_active=bool(link.usuario.is_active),
                platform_role=str(link.usuario.role or "USER"),
                company_role=link.rol,
                is_default=bool(link.is_default),
            )
            for link in links
            if link.usuario
        ]
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router.post(
    "/admin/empresas/{empresa_id}/users/link-existing",
    response_model=schemas.AdminCompanyUser,
    tags=["Admin"],
)
def admin_link_existing_user(
    empresa_id: UUID,
    payload: schemas.AdminLinkExistingUserRequest,
    request: Request,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> schemas.AdminCompanyUser:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        if not empresa:
            raise HTTPException(status_code=404, detail="Empresa no encontrada")

        user = db.query(Usuario).filter(Usuario.email == payload.email).first()
        if not user:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        role = _resolve_or_create_role(db, empresa_id, payload.rol_codigo)

        link = (
            db.query(UsuarioEmpresa)
            .options(joinedload(UsuarioEmpresa.rol))
            .filter(
                UsuarioEmpresa.usuario_id == user.id,
                UsuarioEmpresa.empresa_id == empresa_id,
            )
            .first()
        )

        created = False
        before_role = link.rol.codigo if link and link.rol else None
        before_default = bool(link.is_default) if link else False

        if not link:
            created = True
            link = UsuarioEmpresa(
                usuario_id=user.id,
                empresa_id=empresa_id,
                rol_id=role.id,
                is_default=bool(payload.is_default),
            )
            db.add(link)
        else:
            link.rol_id = role.id
            link.is_default = bool(payload.is_default)

        if payload.is_default:
            (
                db.query(UsuarioEmpresa)
                .filter(
                    UsuarioEmpresa.usuario_id == user.id,
                    UsuarioEmpresa.empresa_id != empresa_id,
                    UsuarioEmpresa.is_default.is_(True),
                )
                .update({UsuarioEmpresa.is_default: False})
            )

        security_audit.log(
            db=db,
            actor_id=current_user.id,
            action="ADMIN_LINK_EXISTING_USER",
            resource=f"Empresa:{empresa_id}",
            severity=AuditSeverity.INFO,
            changes={
                "email": str(payload.email),
                "link_created": created,
                "before": {"rol_codigo": before_role, "is_default": before_default},
                "after": {
                    "rol_codigo": role.codigo,
                    "is_default": bool(payload.is_default),
                },
            },
            request=request,
        )

        db.commit()
        db.refresh(link)
        db.refresh(user)
        if not link.rol:
            link = (
                db.query(UsuarioEmpresa)
                .options(joinedload(UsuarioEmpresa.rol))
                .filter(
                    UsuarioEmpresa.usuario_id == user.id,
                    UsuarioEmpresa.empresa_id == empresa_id,
                )
                .first()
            )
        return schemas.AdminCompanyUser(
            id=user.id,
            email=user.email,
            is_active=bool(user.is_active),
            platform_role=str(user.role or "USER"),
            company_role=link.rol if link else None,
            is_default=bool(link.is_default) if link else False,
        )
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router.patch(
    "/admin/empresas/{empresa_id}/users/{user_id}/role",
    response_model=schemas.AdminCompanyUser,
    tags=["Admin"],
)
def admin_set_company_user_role(
    empresa_id: UUID,
    user_id: UUID,
    payload: schemas.AdminSetCompanyUserRoleRequest,
    request: Request,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> schemas.AdminCompanyUser:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        if not empresa:
            raise HTTPException(status_code=404, detail="Empresa no encontrada")

        user = db.query(Usuario).filter(Usuario.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        link = (
            db.query(UsuarioEmpresa)
            .options(joinedload(UsuarioEmpresa.rol))
            .filter(
                UsuarioEmpresa.usuario_id == user_id,
                UsuarioEmpresa.empresa_id == empresa_id,
            )
            .first()
        )
        if not link:
            raise HTTPException(status_code=404, detail="Usuario no está asociado a la empresa")

        role = _resolve_or_create_role(db, empresa_id, payload.rol_codigo)

        before_role = link.rol.codigo if link.rol else None
        before_default = bool(link.is_default)

        link.rol_id = role.id

        if payload.is_default is not None:
            link.is_default = bool(payload.is_default)
            if payload.is_default:
                (
                    db.query(UsuarioEmpresa)
                    .filter(
                        UsuarioEmpresa.usuario_id == user_id,
                        UsuarioEmpresa.empresa_id != empresa_id,
                        UsuarioEmpresa.is_default.is_(True),
                    )
                    .update({UsuarioEmpresa.is_default: False})
                )

        security_audit.log(
            db=db,
            actor_id=current_user.id,
            action="ADMIN_SET_COMPANY_USER_ROLE",
            resource=f"Empresa:{empresa_id}",
            severity=AuditSeverity.INFO,
            changes={
                "user_id": str(user_id),
                "before": {"rol_codigo": before_role, "is_default": before_default},
                "after": {
                    "rol_codigo": role.codigo,
                    "is_default": bool(link.is_default),
                },
            },
            request=request,
        )

        db.add(link)
        db.commit()
        db.refresh(link)
        if not link.rol:
            link = (
                db.query(UsuarioEmpresa)
                .options(joinedload(UsuarioEmpresa.rol))
                .filter(
                    UsuarioEmpresa.usuario_id == user_id,
                    UsuarioEmpresa.empresa_id == empresa_id,
                )
                .first()
            )
        return schemas.AdminCompanyUser(
            id=user.id,
            email=user.email,
            is_active=bool(user.is_active),
            platform_role=str(user.role or "USER"),
            company_role=link.rol if link else None,
            is_default=bool(link.is_default) if link else False,
        )
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant
