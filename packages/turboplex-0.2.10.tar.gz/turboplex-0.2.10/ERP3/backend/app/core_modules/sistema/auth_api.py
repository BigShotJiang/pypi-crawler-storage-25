from typing import Optional, Callable, cast
from random import randint
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Request, Query
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr

from app.api import deps
from app.core import security
from app.core.config import settings
from app.core.exceptions import UserNotInCompanyError
from app.core_modules.sistema import schemas
from app.core.infrastructure.api_schemas import BaseResponse
from app.core_modules.sistema.models import (
    Usuario,
    Empresa,
    Sucursal,
    Bodega,
    MetodoPago,
    EmpresaMetodoPago,
    Rol,
    UsuarioEmpresa,
    AuditSeverity,
    AuditLog,
)
from app.core_modules.billing import models as billing_models
from app.core.security.mfa_service import MFAService
from app.core.security.security_audit import security_audit
from app.core.security.encryption_service import EncryptionService
from app.core.services.feature_service import feature_service
from app.core.infrastructure.rate_limit import limiter
from jose import jwt

router = APIRouter()

def _normalize_rut_for_storage(rut: Optional[str]) -> Optional[str]:
    if not rut:
        return None
    if "-" not in rut:
        raise HTTPException(status_code=400, detail="RUT debe incluir guion (-)")
    cleaned = rut.replace(".", "").upper().strip()
    return cleaned


class PublicOnboardingRequest(BaseModel):
    nombre_dueno: str
    email: EmailStr
    nombre_empresa: str
    tipo_negocio: str
    password: str
    confirmar_password: str
    rut: Optional[str] = None
    direccion: Optional[str] = None
    telefono: Optional[str] = None
    ciudad: Optional[str] = None


class SetupClientRequest(BaseModel):
    nombre_empresa: str
    rut: Optional[str] = None
    email_admin: EmailStr
    password: str


@router.post(
    "/public/onboarding",
    response_model=schemas.PublicOnboardingResponse,
    tags=["Public"],
)
@limiter.limit(f"{max(1, min(10, settings.RATE_LIMIT_PER_MINUTE))}/minute")
def public_onboarding(
    payload: PublicOnboardingRequest,
    request: Request,
    db: Session = Depends(deps.get_db),
) -> schemas.PublicOnboardingResponse:
    try:
        db.info["allow_no_tenant"] = True
    except Exception:
        pass

    existing = db.query(Usuario).filter(Usuario.email == payload.email).first()
    if existing and not existing.is_active:
        raise HTTPException(status_code=400, detail="Usuario inactivo")
    if payload.password != payload.confirmar_password:
        raise HTTPException(status_code=400, detail="Passwords no coinciden")
    if existing:
        user = existing
    else:
        user = Usuario(
            email=payload.email,
            hashed_password=security.get_password_hash(payload.password),
            role="ADMIN",
            is_active=True,
        )
        db.add(user)
        db.flush()

    base_code = "".join(ch for ch in payload.nombre_empresa.upper() if ch.isalnum())
    base_code = (base_code[:6] if base_code else "EMP") + str(randint(100, 999))
    empresa = Empresa(
        nombre=payload.nombre_empresa,
        codigo=base_code,
        modulos_activos=["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA"],
    )
    if payload.rut:
        empresa.rut = _normalize_rut_for_storage(payload.rut)
    db.add(empresa)
    db.flush()

    link = EmpresaMetodoPago(empresa_id=empresa.id, metodo_pago_id=None, is_active=True)

    efectivo = db.query(MetodoPago).filter(MetodoPago.codigo == "EFECTIVO").first()
    if not efectivo:
        efectivo = MetodoPago(nombre="Efectivo", codigo="EFECTIVO", is_active=True)
        db.add(efectivo)
        db.flush()
    setattr(link, "metodo_pago_id", efectivo.id)
    db.add(link)

    try:
        ue = UsuarioEmpresa(usuario_id=user.id, empresa_id=empresa.id, is_default=True)
        db.add(ue)
    except Exception:
        pass

    sucursal = Sucursal(
        nombre="Casa Matriz",
        codigo=f"{empresa.codigo}-MAT",
        direccion=None,
        empresa_id=empresa.id,
    )
    db.add(sucursal)
    db.flush()

    bodega = Bodega(
        nombre="Bodega Central",
        codigo=f"{empresa.codigo}-BOD-01",
        sucursal_id=sucursal.id,
        is_active=True,
    )
    db.add(bodega)

    feature_flags = empresa.feature_flags or {}
    onboarding_flags = dict(feature_flags.get("onboarding") or {})
    if payload.direccion:
        onboarding_flags["direccion"] = payload.direccion
    if payload.telefono:
        onboarding_flags["telefono"] = payload.telefono
    if payload.ciudad:
        onboarding_flags["ciudad"] = payload.ciudad
    if onboarding_flags:
        feature_flags["onboarding"] = onboarding_flags
        empresa.feature_flags = feature_flags

    audit = AuditLog(
        actor_id=None,
        action="Nuevo Prospecto de Cliente Registrado",
        resource=f"Empresa:{empresa.id}",
        severity=AuditSeverity.INFO,
        changes={
            "email": payload.email,
            "empresa": payload.nombre_empresa,
            "tipo": payload.tipo_negocio,
            "rut": payload.rut,
        },
        ip_address=request.client.host if request and request.client else None,
    )
    db.add(audit)

    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Empresa o Usuario ya existen")

    token = security.create_access_token(user.id)

    return schemas.PublicOnboardingResponse(
        access_token=token,
        token_type="bearer",
        empresa=schemas.EmpresaLite(
            id=empresa.id,
            codigo=cast(str, empresa.codigo),
            nombre=cast(str, empresa.nombre),
        ),
        redirect_url=f"/dashboard?cmp={empresa.codigo}",
    )


@router.post(
    "/admin/setup-client",
    response_model=schemas.SetupClientResponse,
    tags=["Admin"],
)
def setup_client(
    payload: SetupClientRequest,
    request: Request,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> schemas.SetupClientResponse:
    try:
        db.info["allow_no_tenant"] = True
    except Exception:
        pass

    existing_user = (
        db.query(Usuario).filter(Usuario.email == payload.email_admin).first()
    )
    if existing_user:
        raise HTTPException(status_code=400, detail="Usuario ya existe")

    if payload.rut:
        existing_empresa = db.query(Empresa).filter(Empresa.rut == payload.rut).first()
        if existing_empresa:
            raise HTTPException(status_code=400, detail="RUT ya existe")

    base_code = "".join(ch for ch in payload.nombre_empresa.upper() if ch.isalnum())
    base_code = base_code[:6] if base_code else "EMP"
    codigo = None
    for _ in range(5):
        candidate = f"{base_code}{randint(100, 999)}"
        if not db.query(Empresa).filter(Empresa.codigo == candidate).first():
            codigo = candidate
            break
    if not codigo:
        raise HTTPException(
            status_code=400, detail="No se pudo generar código de empresa"
        )

    empresa = Empresa(nombre=payload.nombre_empresa, rut=payload.rut, codigo=codigo)

    usuario = Usuario(
        email=payload.email_admin,
        hashed_password=security.get_password_hash(payload.password),
        role="ADMIN",
        is_active=True,
    )

    db.add(empresa)
    db.add(usuario)
    db.flush()

    existing_roles = {
        r.codigo for r in db.query(Rol).filter(Rol.empresa_id == empresa.id).all()
    }
    default_roles = [
        ("ADM", "Administrador Único de Empresa"),
        ("SUP", "Supervisor"),
        ("VEN", "Vendedor"),
        ("BOD", "Bodeguero"),
        ("CON", "Contador"),
        ("CRM", "Usuario CRM"),
    ]
    for codigo_rol, nombre_rol in default_roles:
        if codigo_rol in existing_roles:
            continue
        rol = Rol(
            empresa_id=empresa.id,
            codigo=codigo_rol,
            nombre=nombre_rol,
            is_active=True,
        )
        db.add(rol)
    db.flush()

    adm_role = (
        db.query(Rol).filter(Rol.empresa_id == empresa.id, Rol.codigo == "ADM").first()
    )

    link = UsuarioEmpresa(
        usuario_id=usuario.id,
        empresa_id=empresa.id,
        rol_id=adm_role.id if adm_role else None,
        is_default=True,
    )
    db.add(link)
    plan = (
        db.query(billing_models.SubscriptionPlan)
        .filter(
            billing_models.SubscriptionPlan.name == "Trial",
            billing_models.SubscriptionPlan.is_active,
        )
        .first()
    )
    if not plan:
        plan = billing_models.SubscriptionPlan(
            name="Trial",
            price_clp=0,
            user_limit=3,
            branch_limit=1,
            is_active=True,
        )
        db.add(plan)
        db.flush()
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(days=30)
    subscription = billing_models.CompanySubscription(
        empresa_id=empresa.id,
        plan_id=plan.id,
        created_at=now,
        expires_at=expires_at,
    )
    db.add(subscription)

    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Empresa o usuario ya existen")

    return schemas.SetupClientResponse(
        empresa=schemas.EmpresaLite(
            id=empresa.id,
            codigo=cast(str, empresa.codigo),
            nombre=cast(str, empresa.nombre),
        ),
        usuario=schemas.SetupClientUsuarioLite(
            id=usuario.id,
            email=cast(str, usuario.email),
            role=cast(str, usuario.role),
        ),
    )


@router.post("/login/access-token", response_model=schemas.Token, tags=["Auth"])
@limiter.limit("5/minute")
async def login_access_token(
    request: Request,
    background_tasks: BackgroundTasks,
    db: Session = Depends(deps.get_db),
    form_data: OAuth2PasswordRequestForm = Depends(),
) -> schemas.Token:
    try:
        db.info["allow_no_tenant"] = True
    except Exception:
        pass

    user = db.query(Usuario).filter(Usuario.email == form_data.username).first()

    if (
        not user
        and settings.ENVIRONMENT == "development"
        and form_data.username == "admin@demo.cl"
    ):
        try:
            from scripts.auto_onboarding import auto_onboarding

            auto_func = cast(Callable[[], None], auto_onboarding)
            auto_func()
            db.expire_all()
            user = db.query(Usuario).filter(Usuario.email == form_data.username).first()
        except Exception:
            user = None

    if not user:
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    if not security.verify_password(
        form_data.password, cast(str, user.hashed_password)
    ):
        if user.role == "SUPERADMIN":
            from app.core.infrastructure.events import event_dispatcher

            payload = {
                "user_email": user.email,
                "ip_address": request.client.host if request.client else "Unknown",
                "timestamp": datetime.now().isoformat(),
                "severity": "CRITICAL",
                "details": "Intento de inicio de sesión fallido para cuenta SUPERADMIN.",
            }

            background_tasks.add_task(
                event_dispatcher.dispatch,
                "SECURITY_ALERT_SUPERADMIN_FAILED_LOGIN",
                payload,
            )

        raise HTTPException(status_code=400, detail="Incorrect email or password")

    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    # MFA Support (Optional Module - Ley 21.663)
    # Check if MFA is required either by user choice or admin enforcement
    is_mfa_required = user.mfa_enabled or user.mfa_enforced
    
    if is_mfa_required:
        # If user hasn't set up MFA yet but it's enforced
        if user.mfa_enforced and not user.mfa_secret:
             # Create temp token for setup only
             temp_token_expires = timedelta(minutes=15)
             temp_token = security.create_access_token(
                user.id, 
                expires_delta=temp_token_expires,
                extra_claims={"scope": "mfa_setup"} # Scope for setup
            )
             return schemas.Token(
                access_token="", 
                token_type="bearer",
                mfa_required=True,
                mfa_setup_required=True, # New field
                temp_token=temp_token
            )
        
        # Standard MFA Verification flow
        temp_token_expires = timedelta(minutes=5)
        temp_token = security.create_access_token(
            user.id, 
            expires_delta=temp_token_expires,
            extra_claims={"scope": "mfa_pending"}
        )
        return schemas.Token(
            access_token="", 
            token_type="bearer",
            mfa_required=True,
            temp_token=temp_token
        )

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    token = security.create_access_token(user.id, expires_delta=access_token_expires)

    security_audit.log(
        db=db,
        actor_id=user.id,
        action="LOGIN",
        resource=f"Usuario:{user.id}",
        severity=AuditSeverity.INFO,
        changes=None,
        request=request,
    )

    return schemas.Token(access_token=token, token_type="bearer")


@router.get("/users/me", response_model=schemas.Usuario, tags=["Auth"])
def read_users_me(
    request: Request,
    db: Session = Depends(deps.get_db),
    cmp: Optional[str] = Query(None),
    current_user: Usuario = Depends(deps.get_current_user),
) -> Usuario:
    try:
        deps.get_current_active_company(
            request=request,
            cmp=cmp,
            current_user=current_user,
            db=db,
        )
    except UserNotInCompanyError:
        if cmp:
            try:
                deps.get_current_active_company(
                    request=request,
                    cmp=None,
                    current_user=current_user,
                    db=db,
                )
            except UserNotInCompanyError:
                pass
    return current_user


@router.get(
    "/users/me/companies",
    response_model=list[schemas.UsuarioEmpresa],
    tags=["Auth"],
)
def read_users_me_companies(
    current_user: Usuario = Depends(deps.get_current_user),
) -> list[schemas.UsuarioEmpresa]:
    return current_user.empresas_asociadas or []


@router.get("/v2/users/me", response_model=BaseResponse[schemas.Usuario], tags=["Auth"])
def read_users_me_v2(
    request: Request,
    db: Session = Depends(deps.get_db),
    cmp: Optional[str] = Query(None),
    current_user: Usuario = Depends(deps.get_current_user),
) -> BaseResponse[schemas.Usuario]:
    try:
        deps.get_current_active_company(
            request=request,
            cmp=cmp,
            current_user=current_user,
            db=db,
        )
    except UserNotInCompanyError:
        if cmp:
            try:
                deps.get_current_active_company(
                    request=request,
                    cmp=None,
                    current_user=current_user,
                    db=db,
                )
            except UserNotInCompanyError:
                pass
    return BaseResponse(success=True, data=current_user)


# -----------------------------------------------------------------------------
# MFA ENDPOINTS (Bonus Module - Ley 21.663)
# -----------------------------------------------------------------------------
class MFASetupResponse(BaseModel):
    secret: str
    provisioning_uri: str

class MFAEnableRequest(BaseModel):
    code: str
    secret: str

class MFAVerifyRequest(BaseModel):
    temp_token: str
    code: str

@router.post("/auth/mfa/setup", response_model=MFASetupResponse, tags=["Auth - MFA"])
def mfa_setup(
    current_user: Usuario = Depends(deps.get_current_user_mfa_setup),
    current_company: Empresa = Depends(deps.get_current_active_company_mfa_setup),
):
    """
    Genera un secreto MFA y URI para configurar una app autenticadora.
    Requiere que la empresa tenga activado el módulo 'mfa_module'.
    """
    if not feature_service.is_enabled("mfa_module", current_company):
        raise HTTPException(
            status_code=403, 
            detail="El módulo de Autenticación Multifactor (MFA) no está activado para esta empresa."
        )

    secret = MFAService.generate_secret()
    uri = MFAService.get_provisioning_uri(secret, current_user.email)
    return MFASetupResponse(secret=secret, provisioning_uri=uri)

@router.post("/auth/mfa/enable", response_model=bool, tags=["Auth - MFA"])
def mfa_enable(
    payload: MFAEnableRequest,
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_user_mfa_setup),
    current_company: Empresa = Depends(deps.get_current_active_company_mfa_setup),
):
    """
    Verifica un código TOTP y habilita MFA para el usuario.
    Requiere que la empresa tenga activado el módulo 'mfa_module'.
    """
    if not feature_service.is_enabled("mfa_module", current_company):
        raise HTTPException(
            status_code=403, 
            detail="El módulo de Autenticación Multifactor (MFA) no está activado para esta empresa."
        )

    if not MFAService.verify_totp(payload.secret, payload.code):
        raise HTTPException(status_code=400, detail="Código OTP inválido")
    
    # En producción esto debería estar encriptado (EncryptionAtRest)
    current_user.mfa_secret = EncryptionService.encrypt(payload.secret)
    current_user.mfa_enabled = True
    current_user.mfa_recovery_codes = MFAService.generate_recovery_codes()
    
    db.add(current_user)
    db.commit()
    
    security_audit.log(
        db=db,
        actor_id=current_user.id,
        action="MFA_ENABLED",
        resource=f"Usuario:{current_user.id}",
        severity=AuditSeverity.WARNING,
        changes={"mfa_enabled": True}
    )
    return True

@router.post("/auth/mfa/verify-login", response_model=schemas.Token, tags=["Auth - MFA"])
@limiter.limit("5/minute")
def mfa_verify_login(
    payload: MFAVerifyRequest,
    request: Request,
    db: Session = Depends(deps.get_db),
):
    """
    Segundo paso del login MFA. Verifica token temporal y código OTP.
    """
    try:
        # Decodificar token temporal
        token_payload = jwt.decode(payload.temp_token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id = token_payload.get("sub")
        scope = token_payload.get("scope")
        
        if scope != "mfa_pending":
             raise HTTPException(status_code=401, detail="Token inválido para verificación MFA")
    except Exception:
        raise HTTPException(status_code=401, detail="Token temporal inválido o expirado")

    # Bypass tenant check for user lookup
    try:
        db.info["allow_no_tenant"] = True
    except Exception:
        pass

    user = db.query(Usuario).filter(Usuario.id == user_id).first()
    if not user or not user.mfa_enabled:
        raise HTTPException(status_code=400, detail="MFA no habilitado o usuario no encontrado")

    decrypted_secret = EncryptionService.decrypt(user.mfa_secret)
    if not decrypted_secret or not MFAService.verify_totp(decrypted_secret, payload.code):
         security_audit.log(
            db=db,
            actor_id=user.id,
            action="LOGIN_MFA_FAILED",
            resource=f"Usuario:{user.id}",
            severity=AuditSeverity.WARNING,
            request=request
        )
         raise HTTPException(status_code=400, detail="Código OTP inválido")

    # Generar token real
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    token = security.create_access_token(user.id, expires_delta=access_token_expires)
    
    security_audit.log(
        db=db,
        actor_id=user.id,
        action="LOGIN_MFA_SUCCESS",
        resource=f"Usuario:{user.id}",
        severity=AuditSeverity.INFO,
        request=request
    )

    return schemas.Token(access_token=token, token_type="bearer")
