from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    ForeignKey,
    JSON,
    Numeric,
    UniqueConstraint,
    text,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship, Mapped, mapped_column
from typing import Optional
from uuid import UUID
from decimal import Decimal
from app.core.database import Base, GUID
from app.core.utils.mixins import SoftDeleteMixin, TimestampMixin
import uuid6
import enum


# -----------------------------------------------------------------------------
# USUARIO
# -----------------------------------------------------------------------------
class Usuario(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "usuarios"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    role = Column(String, default="USER")  # DEVELOPER, ADMIN, USER
    supervisor_id = Column(GUID, ForeignKey("usuarios.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relación con empresas
    empresas_asociadas = relationship("UsuarioEmpresa", back_populates="usuario")
    supervisor = relationship("Usuario", remote_side=[id], backref="subordinados")

    # MFA Support (Optional Module - Ley 21.663)
    mfa_enabled = Column(Boolean, default=False)  # User has setup MFA
    mfa_enforced = Column(Boolean, default=False)  # Admin requires MFA
    mfa_secret = Column(String, nullable=True)  # Base32 Secret
    mfa_recovery_codes = Column(JSON, nullable=True)  # List of recovery codes


class Empresa(Base):
    __tablename__ = "empresas"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, index=True, nullable=False)
    rut = Column(
        String, unique=True, index=True, nullable=True
    )  # Tax ID for Intercompany
    codigo = Column(
        String, unique=True, index=True, nullable=False
    )  # Para el parametro ?cmp=CODIGO
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True, nullable=False)
    grace_period_days = Column(Integer, default=5, nullable=False)
    limite_cupo_maximo: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("50000.00"), nullable=False
    )

    # JSONB support via generic JSON type
    modulos_activos = Column(
        JSON,
        default=["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA"],
        nullable=False,
    )

    # Pilar 10: Feature Flags por dominio/empresa
    feature_flags = Column(
        JSON,
        default={},
        nullable=False,
        server_default=text("'{}'::json"),
    )

    # Power BI Configuration
    pwr_bi_enabled = Column(Boolean, default=False)
    pwr_bi_config = Column(
        JSON, default={}, nullable=True
    )  # Stores { "db_user": "..." } (NO password here)

    # Relación con usuarios a través de la tabla intermedia
    usuarios_asociados = relationship("UsuarioEmpresa", back_populates="empresa")
    roles = relationship("Rol", back_populates="empresa", cascade="all, delete-orphan")


class Rol(Base):
    __tablename__ = "roles"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )
    codigo = Column(String, nullable=False, index=True)  # ADM, SUP, VEN
    nombre = Column(String, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    empresa = relationship("Empresa", back_populates="roles")
    usuarios_empresas = relationship("UsuarioEmpresa", back_populates="rol")


class UsuarioEmpresa(Base):
    __tablename__ = "usuarios_empresas"

    usuario_id = Column(GUID, ForeignKey("usuarios.id"), primary_key=True)
    empresa_id = Column(GUID, ForeignKey("empresas.id"), primary_key=True)
    rol_id = Column(GUID, ForeignKey("roles.id"), nullable=True, index=True)
    is_default = Column(Boolean, default=False)

    usuario = relationship("Usuario", back_populates="empresas_asociadas")
    empresa = relationship("Empresa", back_populates="usuarios_asociados")
    rol = relationship("Rol", back_populates="usuarios_empresas")


# -----------------------------------------------------------------------------
# SUCURSAL
# -----------------------------------------------------------------------------
class Sucursal(Base):
    __tablename__ = "sucursales"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, index=True, nullable=False)
    codigo = Column(
        String, index=True, nullable=True
    )  # Para identificar la sucursal (ej. SUC-01)
    direccion = Column(String, nullable=True)

    # Vinculación con Empresa
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relaciones
    empresa = relationship("Empresa", backref="sucursales")


# -----------------------------------------------------------------------------
# BODEGA
# -----------------------------------------------------------------------------
class Bodega(Base, SoftDeleteMixin, TimestampMixin):
    __tablename__ = "bodegas"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, index=True, nullable=False)
    codigo = Column(String, index=True, nullable=True)  # ej. BOD-MAIN
    codigo_externo = Column(String, index=True, nullable=True)

    # Vinculación con Sucursal
    sucursal_id = Column(GUID, ForeignKey("sucursales.id"), nullable=False, index=True)

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relaciones
    sucursal = relationship("Sucursal", backref="bodegas")
    ubicaciones = relationship(
        "Ubicacion", back_populates="bodega", cascade="all, delete-orphan"
    )


# -----------------------------------------------------------------------------
# UBICACION (WMS-Lite)
# -----------------------------------------------------------------------------
class Ubicacion(Base):
    __tablename__ = "ubicaciones"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, nullable=False)  # ej. "Estante A1"
    zona = Column(String, nullable=False)  # ej. "Bodega Principal"
    pasillo = Column(String, nullable=True)
    nivel = Column(String, nullable=True)
    capacidad_maxima = Column(Integer, default=0)  # 0 = Sin límite

    bodega_id = Column(GUID, ForeignKey("bodegas.id"), nullable=False, index=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relaciones
    bodega = relationship("Bodega", back_populates="ubicaciones")


# -----------------------------------------------------------------------------
# METODO PAGO
# -----------------------------------------------------------------------------
class MetodoPago(Base):
    """Catálogo global de métodos de pago (Efectivo, Transferencia, etc.)"""

    __tablename__ = "metodos_pago"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    nombre = Column(String, unique=True, index=True, nullable=False)
    codigo = Column(
        String, unique=True, index=True, nullable=False
    )  # ej. CASH, WIRE, CREDIT
    is_active = Column(Boolean, default=True)  # Switch global

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class EmpresaMetodoPago(Base):
    """Tabla intermedia para que cada empresa active/desactive métodos"""

    __tablename__ = "empresas_metodos_pago"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False)
    metodo_pago_id = Column(GUID, ForeignKey("metodos_pago.id"), nullable=False)
    is_active = Column(Boolean, default=True)  # Activado para ESTA empresa

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relaciones
    empresa = relationship("Empresa", backref="configuracion_pagos")
    metodo_pago = relationship("MetodoPago", backref="empresas_asociadas")


# -----------------------------------------------------------------------------
# PARAMETROS GLOBALES
# -----------------------------------------------------------------------------
class ParametroGlobal(Base):
    __tablename__ = "parametros_globales"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[Optional[UUID]] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=True, index=True
    )
    llave = Column(String, nullable=False, index=True)
    valor = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    empresa = relationship("Empresa", backref="parametros_globales")


# -----------------------------------------------------------------------------
# EMPRESA CONFIG ATRIBUTOS (Diccionario de Atributos Dinámicos)
# -----------------------------------------------------------------------------
class EmpresaConfigAtributo(Base):
    __tablename__ = "empresa_config_atributos"
    __table_args__ = (
        UniqueConstraint(
            "empresa_id",
            "entidad",
            "nombre_atributo",
            name="uq_empresa_config_atributos_empresa_entidad_nombre",
        ),
    )

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False, index=True
    )
    entidad = Column(String, nullable=False, index=True)
    nombre_atributo = Column(String, nullable=False)
    label_visible = Column(String, nullable=False)
    activo = Column(Boolean, default=True, nullable=False)

    empresa = relationship("Empresa", backref="config_atributos")


# -----------------------------------------------------------------------------
# PAPELERA RECICLAJE
# -----------------------------------------------------------------------------
class PapeleraReciclaje(Base):
    __tablename__ = "papelera_reciclaje"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    tabla_origen = Column(String, nullable=False)
    empresa_id: Mapped[Optional[UUID]] = mapped_column(GUID, nullable=True)
    company_code = Column(
        String, nullable=True, index=True
    )  # Código de empresa (ej. 'SEC', 'MAIN') para auditoría global
    ejecutado_por_id = Column(GUID, nullable=True)  # ID del usuario que borró
    payload = Column(JSON, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# -----------------------------------------------------------------------------
# AUDIT LOG (Bitácora de Seguridad)
# -----------------------------------------------------------------------------
class AuditSeverity(str, enum.Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    actor_id = Column(
        GUID, ForeignKey("usuarios.id"), nullable=True, index=True
    )  # Nullable for system actions
    impersonated_user_id = Column(
        GUID, ForeignKey("usuarios.id"), nullable=True
    )  # A quién suplantó (si aplica)

    action = Column(String, nullable=False, index=True)  # e.g. UPDATE_MODULES, LOGIN_AS
    resource = Column(String, nullable=False)  # e.g. Empresa:1, Venta:999
    severity = Column(
        String, default=AuditSeverity.INFO, index=True
    )  # INFO, WARNING, CRITICAL

    changes = Column(JSON, nullable=True)  # { "before": ..., "after": ... }
    ip_address = Column(String, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    actor = relationship("Usuario", foreign_keys=[actor_id])
    impersonated_user = relationship("Usuario", foreign_keys=[impersonated_user_id])


# -----------------------------------------------------------------------------
# SYSTEM SECRETS (Pilar 9: Hardening)
# -----------------------------------------------------------------------------
class SystemSecret(Base):
    __tablename__ = "system_secrets"

    key = Column(String, primary_key=True, index=True)  # ej. "FIRMA_DIGITAL_PASSWORD"
    encrypted_value = Column(String, nullable=False)
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    updated_by = Column(GUID, ForeignKey("usuarios.id"), nullable=True)

    # Relationships
    updater = relationship("Usuario", foreign_keys=[updated_by])


class BackgroundJobLog(Base):
    __tablename__ = "background_job_logs"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    task_name = Column(String, nullable=False, index=True)
    status = Column(String, nullable=False, index=True)
    request_id = Column(String, nullable=False, index=True)
    duration_ms = Column(Integer, nullable=True)
    error_code = Column(String, nullable=True, index=True)
    error_detail = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
