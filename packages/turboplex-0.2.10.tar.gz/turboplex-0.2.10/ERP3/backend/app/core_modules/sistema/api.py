from fastapi import APIRouter

from app.core_modules.sistema.auth_api import router as auth_router
from app.core_modules.sistema.admin_api import router as admin_router
from app.core_modules.sistema.metrics_api import router as metrics_router
from app.core_modules.sistema.security_api import router as security_router
from app.core_modules.sistema.features_api import router as features_router
from app.core_modules.sistema.users_api import router as users_router

router = APIRouter()
router.include_router(auth_router)
router.include_router(admin_router)
router.include_router(metrics_router)
router.include_router(users_router)
router.include_router(security_router, prefix="/sistema", tags=["Security Hardening"])
router.include_router(features_router, prefix="/sistema", tags=["Feature Flags"])
