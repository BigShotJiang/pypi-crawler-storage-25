import logging
from datetime import timedelta
from typing import Any
import asyncio

from app.core.infrastructure.events import event_dispatcher
from app.core.database import SessionLocal
from app.core.infrastructure.queue import task_queue
from app.core.infrastructure.redis import compute_backoff_delay, idempotent_task
from app.core_modules.ventas.models import OrdenServicio
from app.core.infrastructure.config_manager import config_manager
from decimal import Decimal
from sqlalchemy.exc import SQLAlchemyError


logger = logging.getLogger(__name__)


@idempotent_task(
    lambda data, attempt=1, max_attempts=3: f"notif:vip_sale:{data.get('orden_id')}"
)
def process_vip_sale_notification(
    data: dict[str, Any], attempt: int = 1, max_attempts: int = 3
) -> None:
    if not config_manager.get_setting("NOTIFICACIONES_ACTIVAS", default=True):
        return
    orden_id = data.get("orden_id")
    if not orden_id:
        return
    db = SessionLocal()
    try:
        orden = db.query(OrdenServicio).filter(OrdenServicio.id == orden_id).first()
        if orden and orden.venta:
            total_venta = orden.venta.total  # Decimal esperado desde el modelo
            vip_threshold = config_manager.get_setting(
                "VENTA_VIP_MINIMO", default=50000
            )
            if total_venta > Decimal(str(vip_threshold)):
                logger.warning(
                    "[NOTIFICACIÓN] ¡Venta de alto valor detectada! Orden ID: %s - Monto: %s (Umbral: %s)",
                    orden_id,
                    int(round(total_venta)),
                    int(vip_threshold),
                )
    except (SQLAlchemyError, TypeError, ValueError) as exc:
        logger.error(
            "Error verificando Venta VIP para Orden #%s en intento %s: %s",
            orden_id,
            attempt,
            exc,
        )
        if attempt < max_attempts and task_queue is not None:
            delay = compute_backoff_delay(attempt)
            task_queue.enqueue_in(
                timedelta(seconds=delay),
                process_vip_sale_notification,
                data,
                attempt + 1,
                max_attempts,
            )
    finally:
        db.close()


@idempotent_task(
    lambda data, attempt=1, max_attempts=3: f"notif:service_update:{data.get('service_order_id')}"
)
def process_service_update_notification(
    data: dict, attempt: int = 1, max_attempts: int = 3
) -> None:
    if not config_manager.get_setting("NOTIFICACIONES_ACTIVAS", default=True):
        return
    service_order_id = data.get("service_order_id")
    status = data.get("status")
    if not service_order_id:
        return
    try:
        logger.info(
            "[NOTIFICACIÓN] ServiceOrder #%s cambio de estado a %s (intento %s)",
            service_order_id,
            status,
            attempt,
        )
    except Exception as exc:
        logger.error(
            "Error notificando cambio de estado para ServiceOrder #%s en intento %s: %s",
            service_order_id,
            attempt,
            exc,
        )
        if attempt < max_attempts and task_queue is not None:
            delay = compute_backoff_delay(attempt)
            task_queue.enqueue_in(
                timedelta(seconds=delay),
                process_service_update_notification,
                data,
                attempt + 1,
                max_attempts,
            )


async def handle_vip_sale_notification(data: dict) -> None:
    if task_queue is not None:
        task_queue.enqueue(process_vip_sale_notification, data, 1, 3)
        return
    process_vip_sale_notification(data, 1, 3)


async def handle_service_update_notification(data: dict) -> None:
    if task_queue is not None:
        task_queue.enqueue(process_service_update_notification, data, 1, 3)
        return
    asyncio.create_task(
        asyncio.to_thread(process_service_update_notification, data, 1, 3)
    )


def register_listeners() -> None:
    event_dispatcher.subscribe("EVENT_ORDEN_FINALIZADA", handle_vip_sale_notification)
    event_dispatcher.subscribe(
        "service_engine.order.update", handle_service_update_notification
    )
