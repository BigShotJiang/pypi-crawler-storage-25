# Core Modules - Sistema
from app.core_modules.sistema.schemas import (
    Usuario,
    UsuarioCreate,
    UsuarioUpdate,
    Empresa,
    EmpresaCreate,
    EmpresaUpdate,
    Sucursal,
    SucursalCreate,
    SucursalUpdate,
    MetodoPago,
    MetodoPagoCreate,
    MetodoPagoUpdate,
)

# Core Modules - Ventas
from app.core_modules.ventas.schemas import (
    Cliente,
    ClienteCreate,
    ClienteUpdate,
    Producto,
    ProductoCreate,
    ProductoUpdate,
    Venta,
    VentaCreate,
    DetalleVenta,
)

# Core Modules - Finanzas
from app.core_modules.finanzas.schemas import (
    Proveedor,
    ProveedorCreate,
    ProveedorUpdate,
    Gasto,
    GastoCreate,
    GastoUpdate,
)

# Core Modules - POS Retail (Addon)
from app.addons.pos_retail.schemas import (
    CierreCaja,
    CierreCajaCreate,
    CierreCajaClose,
)

# Core Modules - RRHH
from app.core_modules.rrhh.schemas import Empleado, EmpleadoCreate, EmpleadoUpdate

# Core Modules - TI
from app.core_modules.ti.schemas import ActivoTI, ActivoTICreate, ActivoTIUpdate

# Core Modules - Service Engine
from app.core_modules.service_engine.schemas import (
    ServiceOrder,
    ServiceOrderCreate,
    ServiceOrderUpdate,
    JobOrder,
    JobOrderCreate,
)

# Verticals
# from app.verticals.lavanderia.schemas import TicketLavanderia, TicketLavanderiaCreate, TicketLavanderiaUpdate

# Legacy/Misc
from .token import Token, TokenPayload

__all__ = [
    "Usuario",
    "UsuarioCreate",
    "UsuarioUpdate",
    "Empresa",
    "EmpresaCreate",
    "EmpresaUpdate",
    "Sucursal",
    "SucursalCreate",
    "SucursalUpdate",
    "MetodoPago",
    "MetodoPagoCreate",
    "MetodoPagoUpdate",
    "Cliente",
    "ClienteCreate",
    "ClienteUpdate",
    "Producto",
    "ProductoCreate",
    "ProductoUpdate",
    "Venta",
    "VentaCreate",
    "DetalleVenta",
    "Proveedor",
    "ProveedorCreate",
    "ProveedorUpdate",
    "Gasto",
    "GastoCreate",
    "GastoUpdate",
    "CierreCaja",
    "CierreCajaCreate",
    "CierreCajaClose",
    "Empleado",
    "EmpleadoCreate",
    "EmpleadoUpdate",
    "ActivoTI",
    "ActivoTICreate",
    "ActivoTIUpdate",
    "ServiceOrder",
    "ServiceOrderCreate",
    "ServiceOrderUpdate",
    "JobOrder",
    "JobOrderCreate",
    "Token",
    "TokenPayload",
]
