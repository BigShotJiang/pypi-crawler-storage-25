from fastapi import APIRouter
from app.api.v1.endpoints import background_jobs
from app.api.v1.endpoints import rut_lookup
from app.api.v1.admin import stats as admin_stats
from app.api.v1.admin import config as admin_config
from app.api.v1.admin import debug as admin_debug

# Import new Core Module routers
from app.core_modules.sistema import api as sistema
from app.core_modules.ventas import api as ventas
from app.core_modules.finanzas import api as finanzas
from app.core_modules.rrhh import api as rrhh
from app.core_modules.ti import api as ti
from app.core_modules.facturacion import api as facturacion
from app.core_modules.service_engine import api as service_engine
from app.core_modules.integraciones import api as integraciones
from app.core_modules.crm import api as crm
from app.core_modules.crm import secure_api as crm_secure
from app.core_modules.legal import api as legal
from app.core_modules.billing import api as billing
from app.core_modules.analytics import api as analytics
from app.core_modules.compras import api as compras
from app.core_modules.inventario import api as inventario

api_router = APIRouter()
api_router.include_router(
    background_jobs.router, prefix="/jobs", tags=["background-jobs"]
)
api_router.include_router(
    rut_lookup.router, prefix="/rut", tags=["RUT"]
)
api_router.include_router(
    admin_stats.router, prefix="/admin/stats", tags=["admin-stats"]
)
api_router.include_router(
    admin_config.router, prefix="/admin", tags=["admin-config"]
)
api_router.include_router(
    admin_debug.router, prefix="/debug", tags=["debug"]
)

# -----------------------------------------------------------------------------
# CORE MODULES
# -----------------------------------------------------------------------------

# Sistema (includes Admin, Dashboard, Sucursales, Metodos Pago, Ordenes)
api_router.include_router(sistema.router)

# Ventas (includes Ventas, Productos, Clientes)
api_router.include_router(ventas.router, prefix="/ventas", tags=["Ventas"])

# CRM
api_router.include_router(crm_secure.router, prefix="/crm", tags=["CRM"])
api_router.include_router(crm.router, prefix="/crm", tags=["CRM"])

# Legal
api_router.include_router(legal.router, prefix="/legal", tags=["Legal"])

# Finanzas (includes Proveedores, Gastos, Cierres)
# Compras
api_router.include_router(compras.router, prefix="/compras", tags=["Compras"])
api_router.include_router(finanzas.router)

# RRHH
api_router.include_router(rrhh.router, prefix="/empleados", tags=["RRHH"])

# TI
api_router.include_router(ti.router, prefix="/ti", tags=["TI"])

# Facturacion
api_router.include_router(
    facturacion.router, prefix="/facturacion", tags=["Facturacion"]
)

# Integraciones
api_router.include_router(
    integraciones.router, prefix="/integraciones", tags=["Integraciones"]
)

# Service Engine
api_router.include_router(
    service_engine.router, prefix="/service-engine", tags=["Service Engine"]
)
api_router.include_router(billing.router)
api_router.include_router(analytics.router)

api_router.include_router(inventario.router, prefix="/inventario", tags=["Inventario"])
