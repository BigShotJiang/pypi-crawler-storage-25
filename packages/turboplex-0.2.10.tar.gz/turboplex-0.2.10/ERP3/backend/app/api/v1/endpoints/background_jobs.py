from fastapi import APIRouter, HTTPException
from uuid import UUID, uuid4
from app.core.infrastructure.queue import task_queue
from app.tasks.reportes import generar_reporte_mensual_pdf

router = APIRouter()


@router.post("/generar-reporte-pdf")
def trigger_report_generation(usuario_id: UUID):
    """
    Endpoint asíncrono que encola la tarea de generación de reporte.
    Responde inmediatamente 'Procesando...'.
    """
    if not task_queue:
        raise HTTPException(
            status_code=503, detail="Sistema de colas no disponible (Redis down?)"
        )

    reporte_id = str(uuid4())

    # Encolar tarea
    job = task_queue.enqueue(
        generar_reporte_mensual_pdf, reporte_id=reporte_id, usuario_id=usuario_id
    )

    return {
        "status": "Procesando...",
        "job_id": job.get_id(),
        "reporte_id": reporte_id,
        "message": "La tarea se está ejecutando en segundo plano.",
    }
