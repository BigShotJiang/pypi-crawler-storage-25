from typing import List, Any, Dict
from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.api import deps
from app.core.database import get_db
from app.core_modules.sistema.models import Usuario, Sucursal
from app.core_modules.ventas.models import Producto
import os
import gc
import platform

router = APIRouter()

@router.get("/sql/slow-queries", response_model=List[Dict[str, Any]])
def get_slow_queries(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> List[Dict[str, Any]]:
    """
    Returns currently running queries or recent slow queries from pg_stat_activity.
    Requires postgres superuser or monitor privileges to see all queries.
    """
    # Query pg_stat_activity for active queries > 100ms
    # Note: 'state' column might differ in older postgres versions, but usually 'active'
    try:
        sql = text("""
            SELECT 
                pid,
                usename,
                state,
                query,
                query_start,
                EXTRACT(EPOCH FROM (now() - query_start)) * 1000 as duration_ms
            FROM pg_stat_activity 
            WHERE state = 'active' 
            AND query NOT LIKE '%pg_stat_activity%'
            ORDER BY duration_ms DESC
            LIMIT 50;
        """)
        results = db.execute(sql).fetchall()
        
        data = []
        for row in results:
            data.append({
                "timestamp": row.query_start.timestamp() if row.query_start else datetime.now().timestamp(),
                "duration_ms": int(row.duration_ms) if row.duration_ms else 0,
                "query": row.query,
                "user": row.usename
            })
            
        return data
    except Exception:
        # Fallback for when pg_stat_activity is not accessible or other error
        return []

@router.get("/memory/stats")
def get_memory_stats(
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> Dict[str, Any]:
    stats = {
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "python_version": platform.python_version(),
        },
        "backend_pid": os.getpid(),
        "psutil_available": False,
        "system_memory": {},
        "process_memory": {},
        "garbage_collection": {
             "counts": {
                 "gen0": gc.get_count()[0],
                 "gen1": gc.get_count()[1],
                 "gen2": gc.get_count()[2]
             }
        }
    }
    
    try:
        import psutil
        stats["psutil_available"] = True
        vm = psutil.virtual_memory()
        stats["system_memory"] = {
            "total": vm.total,
            "available": vm.available,
            "percent": vm.percent,
            "used": vm.used,
            "free": vm.free
        }
        process = psutil.Process(os.getpid())
        mem_info = process.memory_info()
        stats["process_memory"] = {
            "rss": mem_info.rss,
            "vms": mem_info.vms,
            "cpu_percent": process.cpu_percent(interval=0.1)
        }
    except ImportError:
        # Fallback
        stats["system_memory"] = {"info": "psutil not installed"}
        
    return stats

@router.post("/memory/gc/collect")
def run_gc_collect(
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> Dict[str, Any]:
    n = gc.collect()
    return {"message": f"GC collected {n} objects", "collected": n}

@router.get("/available-modules", response_model=List[Dict[str, Any]])
def get_available_modules(
    current_user: Usuario = Depends(deps.get_current_superadmin),
) -> List[Dict[str, Any]]:
    return [
        {
            "id": "memory_inspector",
            "name": "Inspector de Memoria",
            "description": "Monitor de uso de memoria y Garbage Collection",
            "type": "utility",
            "ui_config": {
                "order": 1,
                "tab_name": "Memoria",
                "icon": "PhCpu",
                "component": "MemoryInspector"
            }
        },
        {
            "id": "sql_profiler",
            "name": "SQL Profiler",
            "description": "Análisis de consultas lentas y rendimiento de BD",
            "type": "utility",
            "ui_config": {
                "order": 2,
                "tab_name": "SQL",
                "icon": "PhDatabase",
                "component": "SQLProfiler"
            }
        }
    ]

@router.get("/sucursales-debug")

def get_sucursales_debug(
    company_override_id: str,
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
):
    try:
        sucursales = db.query(Sucursal).filter(Sucursal.empresa_id == company_override_id).all()
        return [{"id": str(s.id), "nombre": s.nombre, "codigo": s.codigo} for s in sucursales]
    except Exception:
        return []

@router.get("/productos-debug")
def get_productos_debug(
    company_override_id: str,
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
):
    try:
        productos = db.query(Producto).filter(Producto.empresa_id == company_override_id).all()
        return [{"id": str(p.id), "nombre": p.nombre, "sku": p.sku} for p in productos]
    except Exception:
        return []

@router.post("/pricing-test")
def pricing_test(
    producto_id: str,
    sucursal_id: str,
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
):
    try:
        from decimal import Decimal, ROUND_HALF_UP
        from app.core_modules.sistema.models import Sucursal
        from app.core_modules.finanzas.services import get_impuesto_rate
        producto = db.query(Producto).filter(Producto.id == producto_id).first()
        if not producto:
             return {"error": "Producto no encontrado"}
        
        suc = db.query(Sucursal).filter(Sucursal.id == sucursal_id).first()
        empresa_id = suc.empresa_id if suc else None

        tasa = get_impuesto_rate(db, empresa_id, "IVA")
        tasa = Decimal(str(tasa))
        neto = Decimal(str(producto.precio))
        iva = (neto * tasa).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total = (neto + iva).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        
        return {
            "breakdown": {
                "neto": int(neto),
                "iva": int(iva),
                "total": int(total)
            }
        }
    except Exception as e:
        return {"error": str(e)}
