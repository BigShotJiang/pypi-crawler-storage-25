from typing import Any, List, Dict, Optional, Callable, cast
import ast
import re
from pathlib import Path
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, text
from app.api import deps
from app.core.database import get_db
from app.core.utils import get_uuidv7_range_for_date, get_timestamp_from_uuidv7
from app.core_modules.sistema.models import AuditLog, Empresa, Usuario
from app.core_modules.billing.models import CompanySubscription
from app.core_modules.auditoria.models import AuditLog as BusinessAuditLog
from app.core_modules.ventas.models import Venta
from app.addons.pos_retail.models import CierreCaja
from app.core_modules.crm.models import OportunidadVenta
from app.core.observability.metrics import get_company_perf_snapshot
import logging
import time
import os

router = APIRouter()
logger = logging.getLogger(__name__)

_cache: Dict[str, Dict[str, Any]] = {}
_ttl_seconds = {"global_timeline": 15, "active_sessions": 10}

_RouteDecorator = Callable[..., Callable[[Callable[..., Any]], Callable[..., Any]]]
router_get = cast(_RouteDecorator, router.get)
router_delete = cast(_RouteDecorator, router.delete)


def _get_cache(key: str) -> Optional[Dict[str, Any]]:
    if "PYTEST_CURRENT_TEST" in os.environ:
        return None
    v = _cache.get(key)
    if not v:
        return None
    ttl = _ttl_seconds.get(key, 0)
    ts = v.get("ts")
    if not isinstance(ts, (int, float)):
        return None
    if time.time() - ts > ttl:
        return None
    return v.get("data")


def _set_cache(key: str, data: Any) -> None:
    if "PYTEST_CURRENT_TEST" in os.environ:
        return
    _cache[key] = {"ts": time.time(), "data": data}


@router_get("/active-sessions", response_model=List[Dict[str, Any]])
def get_active_sessions(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> List[Dict[str, Any]]:
    """
    Returns simulated active sessions based on recent login activity (last 24 hours).
    In a real system with Redis sessions, this would query Redis.
    Here we infer 'active' status from recent login AuditLogs.
    """
    # 1. Get Logins in last 24 hours
    since = datetime.now(timezone.utc) - timedelta(hours=24)

    # We want the LATEST login for each user
    # Subquery to find max created_at per actor_id for LOGIN actions

    # Simple approach: Get all LOGIN logs in last 24h, distinct by actor_id
    # Note: SQLAlchemy distinct() might vary by DB.
    # Let's fetch recent logins and process in python for simplicity/portability in this 'simulated' session view

    try:
        recent_logins = (
            db.query(AuditLog)
            .filter(AuditLog.action == "LOGIN", AuditLog.created_at >= since)
            .order_by(AuditLog.created_at.desc())
            .limit(100)
            .all()
        )
    except Exception as e:
        logger.error(f"[stats] error querying LOGIN logs: {e}")
        recent_logins = []

    sessions_map = {}

    for log in recent_logins:
        if not log.actor_id:
            continue
        actor_id_str = str(log.actor_id)
        if actor_id_str in sessions_map:
            continue
        user = db.query(Usuario).filter(Usuario.id == log.actor_id).first()
        if not user:
            continue
        sessions_map[actor_id_str] = {
            "session_id": str(log.id),
            "user_email": user.email,
            "is_admin": user.role in ["SUPERADMIN", "ADMIN"],
            "login_time": log.created_at.isoformat(),
            "ip_address": log.ip_address or "Unknown",
            "role": user.role,
        }
    if not sessions_map:
        logger.warning(
            "[stats] no LOGIN audit logs found for last 24h, returning synthetic session"
        )
        sessions_map[str(current_user.id)] = {
            "session_id": f"synthetic-{current_user.id}",
            "user_email": current_user.email,
            "is_admin": current_user.role in ["SUPERADMIN", "ADMIN"],
            "login_time": datetime.now(timezone.utc).isoformat(),
            "ip_address": "Unknown",
            "role": current_user.role,
        }

    data = list(sessions_map.values())
    logger.info(f"[stats] active_sessions count={len(data)} user={current_user.email}")
    return data


@router_get("/financial-health")
def get_financial_health_summary(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Resumen rápido: total de empresas, activas y en mora/suspendidas (vencidas + fuera de días de gracia).
    """
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        total = db.query(Empresa).count()
        active = db.query(Empresa).filter(Empresa.is_active).count()
        # Calcular en mora: empresas con suscripción expirada y fuera del período de gracia
        now = datetime.now(timezone.utc)
        delinquent = 0
        empresas = db.query(Empresa).all()
        subs = {s.empresa_id: s for s in db.query(CompanySubscription).all()}
        for e in empresas:
            sub = subs.get(e.id)
            expires_at = getattr(sub, "expires_at", None)
            grace_days = getattr(e, "grace_period_days", 5) or 5
            if not expires_at:
                # Sin suscripción: considerar en mora inmediata
                delinquent += 1
                continue
            grace_limit = expires_at + timedelta(days=grace_days)
            if now > grace_limit:
                delinquent += 1
        return {
            "total_companies": total,
            "active_companies": active,
            "delinquent_companies": delinquent,
        }
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router_get("/financial-delinquent-transitions")
def get_financial_delinquent_transitions(
    window_hours: int = 24,
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Cuenta cuántas empresas han pasado a estado 'en mora' en la ventana indicada.
    Se considera que una empresa entra en mora cuando now cruza expires_at + grace_period_days.
    """
    if window_hours <= 0:
        window_hours = 24
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(hours=window_hours)
        empresas = db.query(Empresa).all()
        subs = {s.empresa_id: s for s in db.query(CompanySubscription).all()}
        transitioned = 0
        for e in empresas:
            sub = subs.get(e.id)
            expires_at = getattr(sub, "expires_at", None)
            grace_days = getattr(e, "grace_period_days", 5) or 5
            if not expires_at:
                continue
            grace_limit = expires_at + timedelta(days=grace_days)
            if window_start <= grace_limit < now:
                transitioned += 1
        return {
            "window_hours": window_hours,
            "companies_entered_delinquent": transitioned,
            "timestamp_utc": now.isoformat(),
        }
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router_delete("/sessions/{session_id}")
def terminate_session(
    session_id: str,
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Simulates session termination. In a real JWT system, this might add the token to a blacklist.
    """
    # For now, just log that we 'terminated' it
    # Ideally we would blacklist the token jti if we were tracking it.
    # Since we are just viewing logs, we can't really 'kill' the session without a blacklist mechanism.
    # We will just return success to satisfy the frontend call.
    return {"message": "Session terminated (simulated)"}


@router_get("/global-timeline")
def get_global_timeline(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    c = _get_cache("global_timeline")
    if c is not None:
        logger.info("[stats] global_timeline served from cache")
        return c

    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    today = datetime.now(timezone.utc)
    companies_data: List[Dict[str, Any]] = []
    activity_data: List[Dict[str, Any]] = []
    health_summary = {"INFO": 0, "WARNING": 0, "CRITICAL": 0}
    module_volume: Dict[str, int] = {}

    try:
        uuid_start, uuid_end = get_uuidv7_range_for_date(today)
        companies_today = (
            db.query(Empresa)
            .filter(Empresa.id >= uuid_start, Empresa.id <= uuid_end)
            .all()
        )
        for comp in companies_today:
            try:
                created_at_from_uuid = get_timestamp_from_uuidv7(comp.id)
            except Exception as e:
                logger.error(
                    f"[stats] error decoding uuid timestamp for empresa {comp.id}: {e}"
                )
                created_at_from_uuid = None
            companies_data.append(
                {
                    "id": str(comp.id),
                    "nombre": comp.nombre,
                    "created_at_uuid": created_at_from_uuid.isoformat()
                    if created_at_from_uuid
                    else None,
                    "created_at_db": comp.created_at.isoformat()
                    if getattr(comp, "created_at", None)
                    else None,
                }
            )
    except Exception as e:
        logger.error(f"[stats] error loading companies_today: {e}")
        companies_data = []

    try:
        recent_activity = (
            db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(50).all()
        )
        for log in recent_activity:
            actor_str = (
                str(log.actor_id) if getattr(log, "actor_id", None) else "SYSTEM"
            )
            sev_obj = getattr(log, "severity", None)
            sev_val = getattr(sev_obj, "value", sev_obj)
            activity_data.append(
                {
                    "timestamp": log.created_at.isoformat()
                    if getattr(log, "created_at", None)
                    else None,
                    "action": getattr(log, "action", None),
                    "resource": getattr(log, "resource", None),
                    "severity": sev_val,
                    "actor_id": actor_str,
                }
            )
    except Exception as e:
        logger.error(f"[stats] error loading recent activity: {e}")
        activity_data = []

    try:
        rows = (
            db.query(AuditLog.severity, func.count(AuditLog.id))
            .group_by(AuditLog.severity)
            .all()
        )
        tmp = {"INFO": 0, "WARNING": 0, "CRITICAL": 0}
        for sev, cnt in rows:
            key = sev.value if hasattr(sev, "value") else sev
            if key in tmp:
                tmp[key] = cnt
        health_summary = tmp
    except Exception as e:
        logger.error(f"[stats] error computing health summary: {e}")
        health_summary = {"INFO": 0, "WARNING": 0, "CRITICAL": 0}

    try:
        bstats = (
            db.query(BusinessAuditLog.modulo, func.count(BusinessAuditLog.id))
            .group_by(BusinessAuditLog.modulo)
            .all()
        )
        mv: Dict[str, int] = {}
        for mod, cnt in bstats:
            if mod is None:
                mod = "DESCONOCIDO"
            mv[str(mod)] = cnt
        module_volume = mv
    except Exception as e:
        logger.error(f"[stats] error computing module volume: {e}")
        module_volume = {}

    data = {
        "resumen_dia": {
            "fecha": today.date().isoformat(),
            "empresas_creadas_hoy": len(companies_data),
            "detalle_empresas": companies_data,
        },
        "salud_sistema": {
            "alertas_severidad": health_summary,
            "volumen_por_modulo": module_volume,
        },
        "actividad_reciente": activity_data,
    }
    _set_cache("global_timeline", data)
    logger.info(
        f"[stats] global_timeline empresas_hoy={len(companies_data)} actividad={len(activity_data)}"
    )
    if prev_allow_no_tenant is None:
        db.info.pop("allow_no_tenant", None)
    else:
        db.info["allow_no_tenant"] = prev_allow_no_tenant
    return data


def _resolve_empresa_id_from_resource(
    db: Session, resource: Optional[str]
) -> Optional[str]:
    if not resource:
        return None
    try:
        if resource.startswith("Empresa:"):
            return resource.split(":", 1)[1]
        if resource.startswith("Venta:"):
            rid = resource.split(":", 1)[1]
            v = db.query(Venta).filter(Venta.id == rid).first()
            return str(v.empresa_id) if v else None
        if resource.startswith("CierreCaja:"):
            rid = resource.split(":", 1)[1]
            c = db.query(CierreCaja).filter(CierreCaja.id == rid).first()
            return str(c.empresa_id) if c else None
        if resource.startswith("OportunidadVenta:"):
            rid = resource.split(":", 1)[1]
            o = db.query(OportunidadVenta).filter(OportunidadVenta.id == rid).first()
            return str(o.empresa_id) if o else None
    except Exception:
        return None
    return None


def _categorize_event(action: str, severity: str) -> str:
    a = (action or "").upper()
    if "INTEGRACION" in a and "ERROR" in a:
        return "Error de integración contable"
    if "VENTA" in a:
        return "Transacción de venta"
    if "SUPPORT_MODE_ACCESS" in a:
        return "Acceso en Modo de Soporte"
    if "ROTATE_BI_CREDENTIALS" in a:
        return "Rotación de credenciales BI"
    if "ERROR" in a or severity == "CRITICAL":
        return "Error de sistema"
    if "UPDATE" in a:
        return "Actualización de configuración"
    return "Hito del sistema"


@router_get("/system-events-sanitized", response_model=Dict[str, Any])
def system_events_sanitized(
    limit: int = 50,
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Retorna eventos de sistema agregados y anonimizados (sin PII).
    Ejemplo: 'Tenant XYZ: Umbral de ventas diarias superado' o 'Tenant ABC: Error de integración contable'.
    """
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        logs = (
            db.query(AuditLog)
            .order_by(AuditLog.created_at.desc())
            .limit(limit)
            .all()
        )
        items = []
        for log in logs:
            resource = str(log.resource) if log.resource is not None else ""
            emp = resource.split(":", 1)[1] if resource.startswith("Empresa:") else None
            cat = _categorize_event(
                str(log.action), str(getattr(log.severity, "value", log.severity))
            )
            prefix = f"Tenant {emp}" if emp else "Administración general"
            items.append(
                {
                    "timestamp": log.created_at.isoformat() if log.created_at else None,
                    "message": f"{prefix}: {cat}",
                    "severity": log.severity,
                }
            )
        return {"events": items}
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


def _read_db_alembic_head(db: Session) -> str | None:
    try:
        row = db.execute(
            text("SELECT version_num FROM erp3_migrations.alembic_version LIMIT 1")
        ).first()
        return str(row[0]) if row and row[0] else None
    except Exception:
        try:
            row = db.execute(text("SELECT version_num FROM alembic_version LIMIT 1")).first()
            return str(row[0]) if row and row[0] else None
        except Exception:
            return None


def _parse_alembic_value(raw: str) -> Any:
    value = raw.strip()
    value = value.split("#", 1)[0].strip()
    if value.endswith(","):
        value = value[:-1].strip()
    try:
        return ast.literal_eval(value)
    except Exception:
        return None


def _parse_alembic_script(path: Path) -> Dict[str, Any] | None:
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None

    rev_match = re.search(
        r"(?m)^\s*revision\s*=\s*['\"]([^'\"]+)['\"]\s*$", content
    )
    if not rev_match:
        return None
    revision = rev_match.group(1).strip()

    down_match = re.search(r"(?m)^\s*down_revision\s*=\s*(.+)\s*$", content)
    down_raw = down_match.group(1) if down_match else "None"
    down_val = _parse_alembic_value(down_raw)
    if isinstance(down_val, str):
        down_revisions = [down_val]
    elif down_val is None:
        down_revisions = []
    elif isinstance(down_val, (tuple, list)):
        down_revisions = [str(x) for x in down_val if x is not None]
    else:
        down_revisions = []

    doc_match = re.search(r'(?s)^\s*"""(.*?)"""', content)
    name = revision
    if doc_match:
        first_line = doc_match.group(1).strip().splitlines()[0].strip()
        if first_line:
            name = first_line

    return {
        "id": revision,
        "name": name,
        "down_revisions": down_revisions,
        "file": path.name,
    }


@router_get("/alembic-migrations", response_model=Dict[str, Any])
def get_alembic_migrations(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        db_head = _read_db_alembic_head(db)
        backend_root = Path(__file__).resolve().parents[4]
        versions_dir = backend_root / "alembic" / "versions"

        scripts: list[Dict[str, Any]] = []
        if versions_dir.exists():
            for p in versions_dir.glob("*.py"):
                parsed = _parse_alembic_script(p)
                if parsed is not None:
                    scripts.append(parsed)

        by_id: Dict[str, Dict[str, Any]] = {s["id"]: s for s in scripts if "id" in s}
        applied: set[str] = set()
        if db_head and db_head in by_id:
            stack = [db_head]
            while stack:
                rid = stack.pop()
                if rid in applied:
                    continue
                applied.add(rid)
                for d in by_id.get(rid, {}).get("down_revisions", []):
                    if d:
                        stack.append(str(d))

        rows = []
        for s in scripts:
            rid = s["id"]
            rows.append(
                {
                    "id": rid,
                    "name": s.get("name") or rid,
                    "status": "success" if rid in applied else "pending",
                    "date": "-",
                }
            )

        rows.sort(key=lambda r: str(r.get("id", "")))
        return {"db_head": db_head, "migrations": rows}
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant


@router_get("/infra-performance", response_model=Dict[str, Any])
def infra_performance(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Enfocado en rendimiento por empresa:
    - requests, error_rate, avg_duration_ms.
    Sin PII; índice por empresa (cmp) proveniente del query param.
    """
    snapshot = get_company_perf_snapshot()
    # Detectar outliers básicos
    outliers = []
    for empresa, s in snapshot.items():
        if s["avg_duration_ms"] > 800 or s["error_rate"] > 0.05:
            outliers.append({"empresa": empresa, **s})
    return {"snapshot": snapshot, "outliers": outliers}
