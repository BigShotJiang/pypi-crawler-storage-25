from fastapi import APIRouter, Depends, Query, Body, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import os
import json
import uuid
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from pydantic import BaseModel

from app.api.deps import get_db, get_current_user, get_current_active_company, UserRole
from app.core.database.models import RutCache, RutLookupLog, RutProviderConfig
from app.core.security.encryption_service import EncryptionService
from app.core_modules.facturacion.utils.rut_validation import clean_rut, validate_rut, format_rut

router = APIRouter(tags=["RUT"])


def _normalize_rut(rut: str) -> str:
    cleaned = clean_rut(rut or "")
    if not cleaned or len(cleaned) < 2:
        return cleaned
    return f"{cleaned[:-1]}-{cleaned[-1].upper()}"


def _mask_secret(value: str | None) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    if len(raw) <= 8:
        return "••••"
    return f"{raw[:4]}{'•' * (len(raw) - 8)}{raw[-4:]}"


def _is_masked(value: str) -> bool:
    raw = str(value or "")
    return ("•" in raw) or ("*" in raw)


def _decrypt_maybe(value: str | None) -> str | None:
    if not value:
        return None
    raw = str(value)
    if raw.startswith("enc:"):
        return EncryptionService.decrypt(raw.removeprefix("enc:"))
    return raw


def _provider_call_simpleapi(
    rut_compact: str, api_key: str | None
) -> tuple[int, dict[str, object] | None]:
    key = (api_key or "").strip()
    if not key:
        return 500, {"detail": "Proveedor no configurado"}
    url = f"https://rut.simpleapi.cl/v2/{rut_compact}"
    req = Request(url, method="GET")
    req.add_header("Authorization", key)
    try:
        with urlopen(req, timeout=25) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                return 200, {"raw": body}
            if isinstance(data, dict):
                return 200, data
            return 200, {"data": data}
    except HTTPError as e:
        try:
            b = e.read().decode("utf-8", errors="replace")
        except Exception:
            b = ""
        return e.code, {"error": b or str(e)}
    except URLError as e:
        return 503, {"error": str(e)}


def _get_provider_config(db: Session, empresa_id: str) -> RutProviderConfig | None:
    return (
        db.query(RutProviderConfig)
        .filter(RutProviderConfig.empresa_id == str(empresa_id))
        .first()
    )


def _get_ttl_days(db: Session, empresa_id: str) -> int:
    cfg = _get_provider_config(db, empresa_id)
    if cfg and isinstance(cfg.ttl_days, int) and cfg.ttl_days > 0:
        return cfg.ttl_days
    return 30


def _resolve_simpleapi_key(db: Session, empresa_id: str) -> str | None:
    cfg = _get_provider_config(db, empresa_id)
    if cfg and isinstance(cfg.auth_params, dict):
        raw = cfg.auth_params.get("api_key")
        dec = _decrypt_maybe(raw if isinstance(raw, str) else None)
        if dec:
            return dec
    env_key = os.getenv("simpleapi_key") or os.getenv("SIMPLEAPI_KEY") or ""
    return env_key.strip() if env_key.strip() else None


@router.get("/lookup")
def rut_lookup(
    rut: str = Query(..., description="RUT a consultar"),
    refresh: bool = Query(False, description="Forzar consulta al proveedor"),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
    empresa=Depends(get_current_active_company),
):
    # Validación DV local
    if not validate_rut(rut):
        _log = RutLookupLog(
            id=str(uuid.uuid4()),
            rut_normalized=_normalize_rut(rut),
            user_id=str(getattr(user, "id", "")),
            empresa_id=str(getattr(empresa, "id", "")),
            source="invalid_dv",
            provider_name=None,
            http_status=str(400),
            success=False,
        )
        db.add(_log)
        db.commit()
        return {"status": "invalid_dv", "message": "El dígito verificador no corresponde"}

    rut_norm = _normalize_rut(rut)
    now = datetime.utcnow()
    empresa_id = str(getattr(empresa, "id", ""))
    ttl_days = _get_ttl_days(db, empresa_id)

    cached = db.query(RutCache).filter(RutCache.rut_normalized == rut_norm).first()
    if cached and cached.ttl_expires_at and cached.ttl_expires_at > now and not refresh:
        _log = RutLookupLog(
            id=str(uuid.uuid4()),
            rut_normalized=rut_norm,
            user_id=str(getattr(user, "id", "")),
            empresa_id=empresa_id,
            source="cache",
            provider_name=cached.provider_name,
            http_status=str(200),
            success=True,
        )
        db.add(_log)
        db.commit()
        return {
            "status": "cache_hit",
            "data": {
                "rut": format_rut(rut),
                "razonSocial": cached.razon_social,
                "actividadesEconomicas": cached.actividades_economicas or [],
                "domicilios": cached.domicilios or [],
                "presentaInicioActividades": cached.presenta_inicio,
                "fechaInicioActividades": cached.fecha_inicio,
                "esEmpresaMenorTamano": cached.es_pyme,
                "webFacturacion": cached.web_facturacion or "",
            },
        }

    # Autorización para refresh: roles que pueden forzar proveedor
    can_refresh = user.role in [UserRole.DEVELOPER, UserRole.SUPERADMIN, UserRole.ADMIN]
    if not can_refresh and refresh:
        return {"status": "cache_miss", "message": "Sin permiso para forzar proveedor"}

    # Provider call si refresh o miss sin TTL
    cleaned = clean_rut(rut)
    rut_for_provider = f"{cleaned[:-1]}-{cleaned[-1]}" if len(cleaned) >= 2 else format_rut(rut)
    provider_type = "simpleapi"
    api_key = _resolve_simpleapi_key(db, empresa_id)
    status_code, payload = _provider_call_simpleapi(rut_for_provider, api_key)
    if status_code == 200 and payload and isinstance(payload, dict) and "rut" in payload:
        cached = cached or RutCache(rut_normalized=rut_norm)
        cached.razon_social = payload.get("razonSocial") or None
        cached.actividades_economicas = payload.get("actividadesEconomicas") or []
        cached.domicilios = payload.get("domicilios") or []
        cached.presenta_inicio = bool(payload.get("presentaInicioActividades") or False)
        cached.fecha_inicio = payload.get("fechaInicioActividades") or None
        cached.es_pyme = bool(payload.get("esEmpresaMenorTamano") or False)
        cached.web_facturacion = payload.get("webFacturacion") or None
        cached.provider_name = provider_type
        cached.last_refreshed_at = now
        cached.ttl_expires_at = now + timedelta(days=ttl_days)
        db.add(cached)
        _log = RutLookupLog(
            id=str(uuid.uuid4()),
            rut_normalized=rut_norm,
            user_id=str(getattr(user, "id", "")),
            empresa_id=empresa_id,
            source="provider",
            provider_name=provider_type,
            http_status=str(status_code),
            success=True,
        )
        db.add(_log)
        db.commit()
        return {"status": "provider_hit", "data": payload}

    # Provider unavailable o límite
    _log = RutLookupLog(
        id=str(uuid.uuid4()),
        rut_normalized=rut_norm,
        user_id=str(getattr(user, "id", "")),
        empresa_id=empresa_id,
        source="provider",
        provider_name=provider_type,
        http_status=str(status_code),
        success=False,
    )
    db.add(_log)
    db.commit()
    return {
        "status": "provider_unavailable",
        "cache_status": "miss",
        "detail": payload,
    }


@router.get("/logs")
def rut_logs(
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
    empresa=Depends(get_current_active_company),
):
    # Últimos logs por empresa
    q = (
        db.query(RutLookupLog)
        .filter(RutLookupLog.empresa_id == str(getattr(empresa, "id", "")))
        .order_by(RutLookupLog.created_at.desc())
        .limit(limit)
        .all()
    )
    return {
        "items": [
            {
                "id": row.id,
                "rut": row.rut_normalized,
                "source": row.source,
                "provider": row.provider_name,
                "http_status": row.http_status,
                "success": row.success,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            }
            for row in q
        ]
    }


PROVIDER_SCHEMAS: dict[str, dict[str, object]] = {
    "simpleapi": {
        "label": "SimpleAPI RUT",
        "fields": [
            {"key": "api_key", "label": "API Key", "secret": True},
        ],
    }
}


def _ensure_superadmin_or_developer(user: object) -> None:
    role = getattr(user, "role", None)
    is_superadmin = role == UserRole.SUPERADMIN or str(role) == "SUPERADMIN"
    is_developer = role == UserRole.DEVELOPER or str(role) == "DEVELOPER"
    if not is_superadmin and not is_developer:
        raise HTTPException(status_code=403, detail="Solo SUPERADMIN/DEVELOPER puede acceder a la configuración")


class ProviderConfigUpsert(BaseModel):
    provider_type: str
    ttl_days: int = 30
    auth_params: dict[str, str] = {}


@router.get("/provider-config")
def get_provider_config(
    db: Session = Depends(get_db),
    user: object = Depends(get_current_user),
    empresa: object = Depends(get_current_active_company),
) -> dict[str, object]:
    _ensure_superadmin_or_developer(user)
    empresa_id = str(getattr(empresa, "id", ""))
    cfg = _get_provider_config(db, empresa_id)
    if cfg:
        provider_type = cfg.provider_type
        ttl_days = cfg.ttl_days
        auth_params = cfg.auth_params if isinstance(cfg.auth_params, dict) else {}
    else:
        provider_type = "simpleapi"
        ttl_days = 30
        auth_params = {}
    masked: dict[str, str] = {}
    schema = PROVIDER_SCHEMAS.get(provider_type) or PROVIDER_SCHEMAS["simpleapi"]
    fields = schema.get("fields", [])
    for field in fields if isinstance(fields, list) else []:
        key = str((field or {}).get("key"))
        is_secret = bool((field or {}).get("secret"))
        raw = auth_params.get(key)
        dec = _decrypt_maybe(raw if isinstance(raw, str) else None)
        masked[key] = _mask_secret(dec) if is_secret else (dec or "")
    return {
        "provider_type": provider_type,
        "ttl_days": ttl_days,
        "auth_params": masked,
        "provider_schemas": PROVIDER_SCHEMAS,
    }


@router.put("/provider-config")
def put_provider_config(
    payload: ProviderConfigUpsert = Body(...),
    db: Session = Depends(get_db),
    user: object = Depends(get_current_user),
    empresa: object = Depends(get_current_active_company),
) -> dict[str, object]:
    _ensure_superadmin_or_developer(user)
    empresa_id = str(getattr(empresa, "id", ""))
    cfg = _get_provider_config(db, empresa_id)
    if not cfg:
        cfg = RutProviderConfig(
            empresa_id=empresa_id,
            provider_type=payload.provider_type,
            auth_params={},
            ttl_days=int(payload.ttl_days or 30),
        )
        db.add(cfg)
        db.commit()
        db.refresh(cfg)

    provider_type = str(payload.provider_type or "").strip() or cfg.provider_type
    cfg.provider_type = provider_type
    cfg.ttl_days = int(payload.ttl_days or 30)
    cfg.updated_at = datetime.utcnow()

    schema = PROVIDER_SCHEMAS.get(provider_type) or PROVIDER_SCHEMAS["simpleapi"]
    existing = cfg.auth_params if isinstance(cfg.auth_params, dict) else {}
    new_auth: dict[str, object] = dict(existing)

    fields = schema.get("fields", [])
    for field in fields if isinstance(fields, list) else []:
        key = str((field or {}).get("key"))
        is_secret = bool((field or {}).get("secret"))
        incoming = str((payload.auth_params or {}).get(key, "") or "")
        if is_secret:
            if _is_masked(incoming):
                continue
            incoming = incoming.strip()
            if not incoming:
                new_auth[key] = ""
                continue
            enc = EncryptionService.encrypt(incoming)
            new_auth[key] = f"enc:{enc}" if enc else ""
        else:
            new_auth[key] = incoming

    cfg.auth_params = new_auth
    db.add(cfg)
    db.commit()
    db.refresh(cfg)

    return get_provider_config(db=db, user=user, empresa=empresa)


class ProviderConfigTestRequest(BaseModel):
    rut: str


@router.post("/provider-config/test")
def test_provider_config(
    payload: ProviderConfigTestRequest = Body(...),
    db: Session = Depends(get_db),
    user: object = Depends(get_current_user),
    empresa: object = Depends(get_current_active_company),
) -> dict[str, object]:
    _ensure_superadmin_or_developer(user)
    empresa_id = str(getattr(empresa, "id", ""))
    api_key = _resolve_simpleapi_key(db, empresa_id)
    cleaned = clean_rut(payload.rut)
    rut_for_provider = f"{cleaned[:-1]}-{cleaned[-1]}" if len(cleaned) >= 2 else format_rut(payload.rut)
    status_code, data = _provider_call_simpleapi(rut_for_provider, api_key)
    ok = bool(status_code == 200 and isinstance(data, dict) and data.get("rut"))
    return {"ok": ok, "status_code": status_code, "detail": data}
