from typing import Any, Dict
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api import deps
from app.core.database import get_db
from app.core.infrastructure.api_schemas import BaseResponse
from app.core_modules.sistema.models import ParametroGlobal, AuditLog, AuditSeverity, Usuario


router = APIRouter()


def _parse_decimal_string(value: str) -> str:
    try:
        Decimal(value)
        return value
    except Exception:
        raise HTTPException(status_code=400, detail="IVA_RATE debe ser un número decimal válido")


@router.get("/config", response_model=BaseResponse[Dict[str, Any]])
def get_admin_config(
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Any:
    db.info["allow_no_tenant"] = True
    iva_param = (
        db.query(ParametroGlobal)
        .filter(ParametroGlobal.empresa_id.is_(None), ParametroGlobal.llave == "IVA_RATE")
        .first()
    )
    data: Dict[str, Any] = {}
    if iva_param:
        data["IVA_RATE"] = iva_param.valor
    else:
        from app.core.infrastructure.config_manager import config_manager
        from app.core.config import settings

        raw = config_manager.get_setting("IVA_RATE", None)
        if raw is not None:
            data["IVA_RATE"] = raw
        else:
            data["IVA_RATE"] = getattr(settings, "CHILE_IVA_RATE", "0.19")

    return BaseResponse[Dict[str, Any]](success=True, data=data, message="Admin config cargada")


@router.post("/config", response_model=BaseResponse[Dict[str, Any]])
def update_admin_config(
    payload: Dict[str, Any],
    current_user: Usuario = Depends(deps.get_current_superadmin),
    db: Session = Depends(get_db),
) -> Any:
    db.info["allow_no_tenant"] = True
    iva_value = payload.get("IVA_RATE")
    if iva_value is None:
        raise HTTPException(status_code=400, detail="IVA_RATE es requerido")

    iva_str = _parse_decimal_string(str(iva_value))

    param = (
        db.query(ParametroGlobal)
        .filter(ParametroGlobal.empresa_id.is_(None), ParametroGlobal.llave == "IVA_RATE")
        .first()
    )
    before_value = param.valor if param else None

    if not param:
        param = ParametroGlobal(empresa_id=None, llave="IVA_RATE", valor=iva_str)
        db.add(param)
    else:
        param.valor = iva_str

    audit = AuditLog(
        actor_id=current_user.id,
        action="CONFIG_UPDATE",
        resource="GLOBAL:IVA_RATE",
        severity=AuditSeverity.INFO,
        changes={"before": before_value, "after": iva_str},
        ip_address=None,
    )
    db.add(audit)

    db.commit()
    db.refresh(param)

    return BaseResponse[Dict[str, Any]](
        success=True,
        data={"IVA_RATE": param.valor},
        message="Configuración actualizada",
    )
