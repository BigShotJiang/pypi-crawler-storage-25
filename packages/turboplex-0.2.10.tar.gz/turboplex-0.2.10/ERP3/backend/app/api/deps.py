from typing import Optional, List, Callable, Iterator, TypedDict, cast
from fastapi import Depends, HTTPException, status, Query, Request
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from pydantic import ValidationError
from sqlalchemy import text
from sqlalchemy.orm import Session, selectinload
from app.core.config import settings
from app.core.database import get_db as core_get_db
from app.core.observability.tracing import set_tenant_span_attribute
from app.core.infrastructure.events import event_dispatcher
from app.core_modules.sistema.models import Usuario, UsuarioEmpresa, Empresa, Sucursal
from app.core_modules.sistema.models import Bodega
from app.core.exceptions import (
    UserNotInCompanyError,
)
from uuid import UUID

reusable_oauth2 = OAuth2PasswordBearer(
    tokenUrl=f"{settings.API_V1_PREFIX}/login/access-token"
)


class UserRole:
    DEVELOPER = "DEVELOPER"
    SUPERADMIN = "SUPERADMIN"
    ADMIN = "ADMIN"
    RRHH_ADMIN = "RRHH_ADMIN"
    TI_ADMIN = "TI_ADMIN"
    ADMIN_SAAS = "ADMIN_SAAS"
    MANAGER_RRHH = "MANAGER_RRHH"
    USER = "USER"


# Reexport de get_db para compatibilidad con fixtures de testing (tipo explícito)
def _typed_get_db() -> Iterator[Session]:
    yield from core_get_db()


get_db: Callable[[], Iterator[Session]] = _typed_get_db


def get_current_user(
    db: Session = Depends(get_db), token: str = Depends(reusable_oauth2)
) -> Usuario:
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )

        # Security: Block MFA pending tokens from accessing regular resources
        if payload.get("scope") in ["mfa_pending", "mfa_setup"]:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="MFA authentication required",
                headers={"WWW-Authenticate": "Bearer"},
            )

        token_data = payload.get("sub")
        if token_data is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Could not validate credentials",
            )
        db.info["current_user_id"] = str(token_data)
        db.info["user_id"] = str(token_data)
    except (JWTError, ValidationError):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials",
        )

    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        user = (
            db.query(Usuario)
            .filter(Usuario.id == str(token_data))
            .options(
                selectinload(Usuario.empresas_asociadas).selectinload(
                    UsuarioEmpresa.empresa
                ),
                selectinload(Usuario.empresas_asociadas).selectinload(
                    UsuarioEmpresa.rol
                ),
            )
            .first()
        )
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    try:
        for association in user.empresas_asociadas or []:
            try:
                if association.empresa:
                    db.expunge(association.empresa)
            except Exception:
                pass
            try:
                if association.rol:
                    db.expunge(association.rol)
            except Exception:
                pass
            try:
                db.expunge(association)
            except Exception:
                pass
        db.expunge(user)
    except Exception:
        pass

    try:
        db.rollback()
    except Exception:
        pass
    return user


def get_current_user_mfa_setup(
    db: Session = Depends(get_db), token: str = Depends(reusable_oauth2)
) -> Usuario:
    """
    Dependency that allows users with 'mfa_setup' scope to access MFA setup endpoints.
    Regular tokens are also allowed.
    """
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )

        # Allow 'mfa_setup' scope specifically for this endpoint
        scope = payload.get("scope")
        if scope and scope not in ["mfa_setup"]:
            # If scope is 'mfa_pending', still block it here (should use verify-login)
            if scope == "mfa_pending":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="MFA authentication required",
                    headers={"WWW-Authenticate": "Bearer"},
                )

        token_data = payload.get("sub")
        if token_data is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Could not validate credentials",
            )
        db.info["current_user_id"] = str(token_data)
        db.info["user_id"] = str(token_data)
    except (JWTError, ValidationError):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials",
        )

    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    try:
        user = (
            db.query(Usuario)
            .filter(Usuario.id == str(token_data))
            .options(
                selectinload(Usuario.empresas_asociadas).selectinload(
                    UsuarioEmpresa.empresa
                ),
                selectinload(Usuario.empresas_asociadas).selectinload(
                    UsuarioEmpresa.rol
                ),
            )
            .first()
        )
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    try:
        for association in user.empresas_asociadas or []:
            try:
                if association.empresa:
                    db.expunge(association.empresa)
            except Exception:
                pass
            try:
                if association.rol:
                    db.expunge(association.rol)
            except Exception:
                pass
            try:
                db.expunge(association)
            except Exception:
                pass
        db.expunge(user)
    except Exception:
        pass

    try:
        db.rollback()
    except Exception:
        pass
    return user


class RoleChecker:
    def __init__(self, allowed_roles: List[str]):
        self.allowed_roles = allowed_roles

    def __call__(self, user: Usuario = Depends(get_current_user)) -> Usuario:
        if user.role not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operación no permitida. Se requiere uno de los siguientes roles: {self.allowed_roles}",
            )
        return user


def role_required(allowed_roles: List[str]):
    """
    Decorador de seguridad (Dependency factory) que verifica el rol del usuario.
    Uso: dependencies=[role_required(["ADMIN", "MANAGER"])]
    """
    return Depends(RoleChecker(allowed_roles))


def get_current_active_developer(
    current_user: Usuario = Depends(get_current_user),
) -> Usuario:
    if current_user.role != UserRole.DEVELOPER:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren privilegios de DEVELOPER para acceder a este recurso.",
        )
    return current_user


def get_current_superadmin(
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Usuario:
    if (
        current_user.role != UserRole.SUPERADMIN
        and current_user.role != UserRole.DEVELOPER
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren privilegios de SUPERADMIN o DEVELOPER para acceder a este recurso.",
        )
    return current_user


def get_current_active_company(
    request: Request,
    cmp: Optional[str] = Query(None, description="Código de la empresa (opcional)"),
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Empresa:
    """
    Lógica de selección de empresa (Context Selector) con validaciones reforzadas.
    Prioridad:
    1. URL param ?cmp=CODE
    2. Empresa Default del usuario

    Validaciones de seguridad:
    - Usuario pertenece a la empresa
    - Usuario tiene acceso activo (is_active)
    - Empresa está activa
    """

    # 1. Prioridad URL
    # Habilitar allow_no_tenant temporalmente para buscar la empresa
    # Esto es necesario porque aún no tenemos el contexto del tenant definido
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True

    try:
        if cmp:
            # Verificar acceso
            # Join UsuarioEmpresa y Empresa para verificar código y usuario
            association = (
                db.query(UsuarioEmpresa)
                .join(Empresa)
                .options(selectinload(UsuarioEmpresa.rol))  # Cargar rol para validación
                .filter(
                    UsuarioEmpresa.usuario_id == current_user.id, Empresa.codigo == cmp
                )
                .first()
            )

            if not association:
                # Auditoría de violación de aislamiento: intento de acceder a tenant ajeno
                try:
                    import asyncio

                    payload = {
                        "user_id": current_user.id,
                        "user_email": current_user.email,
                        "target_company_code": cmp,
                        "ip": (
                            request.client.host if request and request.client else None
                        ),
                        "geo": None,
                    }
                    loop = asyncio.get_running_loop()
                    loop.create_task(
                        event_dispatcher.dispatch(
                            "SECURITY_ALERT_TENANT_ISOLATION_VIOLATION", payload
                        )
                    )
                except Exception:
                    pass
                # Satisface tipado de excepción esperando UUID en segundo argumento
                raise UserNotInCompanyError(current_user.id, UUID(int=0))

            empresa = cast(Empresa, association.empresa)

            # Validación de compatibilidad Rol-Empresa (CRM)
            if association.rol and association.rol.codigo == "CRM":
                # Verificar si la empresa tiene módulo CRM activo
                # Si modules es None, asumimos ['CORE']
                modules = empresa.modulos_activos or []
                if "CRM" not in modules:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"Usuario con rol CRM no puede acceder a empresa '{empresa.nombre}' sin módulo CRM activo.",
                    )
        else:
            # 2. Prioridad Default
            # Buscar la marcada como default
            association = (
                db.query(UsuarioEmpresa)
                .options(selectinload(UsuarioEmpresa.rol))
                .filter(
                    UsuarioEmpresa.usuario_id == current_user.id,
                    UsuarioEmpresa.is_default,
                )
                .first()
            )

            # 3. Fallback: Primera empresa disponible
            if not association:
                association = (
                    db.query(UsuarioEmpresa)
                    .options(selectinload(UsuarioEmpresa.rol))
                    .filter(UsuarioEmpresa.usuario_id == current_user.id)
                    .first()
                )

            if not association:
                raise UserNotInCompanyError(current_user.id, UUID(int=0))

            empresa = cast(Empresa, association.empresa)

    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant

    # VALIDACIONES DE SEGURIDAD REFORZADAS

    # 1. Verificar que la empresa existe (debería existir por FK, pero por seguridad)
    if not empresa:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Empresa no encontrada"
        )

    # 2. Verificar que la empresa está activa (si tiene campo is_active)
    # Nota: El modelo Empresa no tiene is_active actualmente, pero es buena práctica
    # Si se agrega en el futuro, descomentar:
    # if hasattr(empresa, 'is_active') and not empresa.is_active:
    #     raise CompanyNotActiveError(empresa.id)

    # 3. Verificar que el usuario tiene acceso activo a esta empresa
    # (La asociación UsuarioEmpresa podría tener un campo is_active)
    # if hasattr(association, 'is_active') and not association.is_active:
    #     raise AuthorizationError(
    #         f"Acceso a empresa '{empresa.nombre}' desactivado para este usuario"
    #     )

    # Establecer el contexto de tenant en la sesión para RLS simulado
    try:
        db.info["empresa_id"] = empresa.id
    except Exception:
        pass
    try:
        set_tenant_span_attribute(empresa.id)
    except Exception:
        pass
    try:
        db.rollback()
    except Exception:
        pass
    return empresa


def get_tenant_db(
    db: Session = Depends(get_db),
    current_company: Empresa = Depends(get_current_active_company),
) -> Session:
    try:
        db.rollback()
    except Exception:
        pass
    db.info["empresa_id"] = current_company.id
    db.info["allow_no_tenant"] = False
    if db.get_bind().dialect.name == "postgresql":
        db.execute(text("SELECT set_config('app.allow_no_tenant', '0', true)"))
        db.execute(
            text("SELECT set_config('app.current_empresa_id', :eid, true)"),
            {"eid": str(current_company.id)},
        )
    return db


def get_current_active_company_mfa_setup(
    request: Request,
    cmp: Optional[str] = Query(None, description="Código de la empresa (opcional)"),
    current_user: Usuario = Depends(get_current_user_mfa_setup),
    db: Session = Depends(get_db),
) -> Empresa:
    """
    Variant of get_current_active_company that allows MFA setup scope.
    Required for MFA Setup/Enable endpoints when MFA is enforced.
    """
    # Reuse logic by calling the original function manually?
    # No, logic is inside the function body. Better to duplicate or extract common logic.
    # Duplicating for safety and speed to avoid refactoring risk.

    # 1. Prioridad URL
    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True

    try:
        if cmp:
            association = (
                db.query(UsuarioEmpresa)
                .join(Empresa)
                .filter(
                    UsuarioEmpresa.usuario_id == current_user.id, Empresa.codigo == cmp
                )
                .first()
            )

            if not association:
                raise UserNotInCompanyError(current_user.id, UUID(int=0))

            empresa = cast(Empresa, association.empresa)
        else:
            association = (
                db.query(UsuarioEmpresa)
                .filter(
                    UsuarioEmpresa.usuario_id == current_user.id,
                    UsuarioEmpresa.is_default,
                )
                .first()
            )

            if not association:
                association = (
                    db.query(UsuarioEmpresa)
                    .filter(UsuarioEmpresa.usuario_id == current_user.id)
                    .first()
                )

            if not association:
                raise UserNotInCompanyError(current_user.id, UUID(int=0))

            empresa = cast(Empresa, association.empresa)

    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant

    if not empresa:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Empresa no encontrada"
        )

    try:
        db.info["empresa_id"] = empresa.id
    except Exception:
        pass
    try:
        set_tenant_span_attribute(empresa.id)
    except Exception:
        pass
    try:
        db.rollback()
    except Exception:
        pass
    return empresa


def check_module_access(module_name: str) -> Callable[[Empresa], Empresa]:
    """
    Retorna una dependencia que valida si la empresa activa tiene contratado el módulo.
    Y si el rol del usuario es compatible con el módulo.
    """

    def _checker(
        current_company: Empresa = Depends(get_current_active_company),
        current_user: Usuario = Depends(get_current_user),
    ) -> Empresa:
        # Validar si el campo es nulo (aunque por default es ['CORE'])
        modules = current_company.modulos_activos
        if modules is None:
            modules = []

        # Si el módulo no está en la lista (y no es CORE, que siempre debería estar)
        if module_name not in modules and module_name != "CORE":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Acceso Denegado: La empresa '{current_company.nombre}' no tiene contratado el módulo '{module_name}'.",
            )

        # Validación de Rol de Usuario vs Módulo
        # Buscar el rol del usuario en esta empresa
        user_role = None
        for assoc in current_user.empresas_asociadas:
            if assoc.empresa_id == current_company.id:
                user_role = assoc.rol
                break

        # Si el usuario tiene rol CRM, restringir acceso a otros módulos
        if user_role and user_role.codigo == "CRM":
            if module_name not in ["CRM", "CORE"]:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Usuario con rol CRM no tiene acceso al módulo '{module_name}'.",
                )

        return current_company

    return _checker


class ValidatedContext(TypedDict):
    sucursal: Sucursal
    bodega: Optional[Bodega]


def verify_operational_context(
    sucursal_id: UUID,
    bodega_id: Optional[UUID] = None,
    current_company: Empresa = Depends(get_current_active_company),
    db: Session = Depends(get_db),
) -> ValidatedContext:
    """
    Verifica que la sucursal y la bodega (opcional) pertenezcan a la empresa activa.
    Esta dependencia debe usarse en endpoints que operan en un contexto físico específico.
    Retorna un diccionario con los objetos validados.
    """
    # 1. Verificar Sucursal
    sucursal = (
        db.query(Sucursal)
        .filter(Sucursal.id == sucursal_id, Sucursal.empresa_id == current_company.id)
        .first()
    )

    if not sucursal:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Sucursal {sucursal_id} no encontrada o no pertenece a la empresa activa.",
        )

    # 2. Verificar Bodega (si se proporciona)
    bodega: Optional[Bodega] = None
    if bodega_id:
        bodega = (
            db.query(Bodega)
            .filter(Bodega.id == bodega_id, Bodega.sucursal_id == sucursal.id)
            .first()
        )

        if not bodega:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Bodega {bodega_id} no encontrada o no pertenece a la sucursal {sucursal_id}.",
            )

    return {"sucursal": sucursal, "bodega": bodega}
