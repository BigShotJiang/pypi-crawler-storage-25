import logging
from rq import Worker, Queue, Connection
from app.core.config import settings
from app.core.infrastructure.redis import get_redis_client, validate_redis_connection

# Preload app modules to ensure tasks are discoverable

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

listen = ["default"]


def run_worker():
    if settings.SENTRY_DSN:
        try:
            import sentry_sdk
            from sentry_sdk.integrations.rq import RqIntegration
            sentry_sdk.init(
                dsn=settings.SENTRY_DSN,
                environment=settings.SENTRY_ENVIRONMENT or settings.ENVIRONMENT,
                traces_sample_rate=settings.SENTRY_TRACES_SAMPLE_RATE,
                integrations=[RqIntegration()],
                send_default_pii=False,
            )
        except Exception:
            pass
    if not validate_redis_connection():
        return
    conn = get_redis_client()

    with Connection(conn):
        worker = Worker(list(map(Queue, listen)))
        logger.info(f"Worker iniciado. Escuchando colas: {listen}")
        worker.work()


if __name__ == "__main__":
    run_worker()
