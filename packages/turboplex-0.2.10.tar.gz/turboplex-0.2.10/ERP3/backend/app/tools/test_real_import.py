from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import uuid6
from sqlalchemy.orm import Session

if TYPE_CHECKING:
    from app.core_modules.sistema.models import Empresa

backend_root = Path(__file__).resolve().parents[2]
if str(backend_root) not in sys.path:
    sys.path.insert(0, str(backend_root))


def _find_heaviest_inventory_file(search_root: Path) -> Path:
    candidates = list(search_root.glob("Inventario disponible_*.xlsx"))
    if not candidates:
        raise FileNotFoundError(
            f"No se encontraron archivos Inventario disponible_*.xlsx en {search_root}"
        )
    return max(candidates, key=lambda p: p.stat().st_size)


def _create_test_company(db: Session) -> Empresa:
    from app.core_modules.sistema.models import Empresa

    prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
    db.info["allow_no_tenant"] = True
    codigo = f"TST-ING-{uuid6.uuid7().hex[:10]}"
    empresa = Empresa(nombre="Empresa Test Ingesta", codigo=codigo)
    try:
        db.add(empresa)
        db.commit()
        db.refresh(empresa)
    finally:
        if prev_allow_no_tenant is None:
            db.info.pop("allow_no_tenant", None)
        else:
            db.info["allow_no_tenant"] = prev_allow_no_tenant
    return empresa


def main() -> int:
    from app.core.database import SessionLocal, reader_engine, writer_engine
    from app.models.staging import StagingImport
    from app.core.services.ingestion_service import ingest_excel_bytes_to_staging

    writer_engine.echo = False
    reader_engine.echo = False

    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine.Engine").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.pool").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.pool.impl").setLevel(logging.WARNING)

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--file",
        dest="file_path",
        type=str,
        default=None,
    )
    parser.add_argument(
        "--search-root",
        dest="search_root",
        type=str,
        default=str(backend_root.parent),
    )
    args = parser.parse_args()

    if args.file_path:
        inventory_file = Path(args.file_path)
    else:
        inventory_file = _find_heaviest_inventory_file(Path(args.search_root))

    if not inventory_file.exists():
        raise FileNotFoundError(f"Archivo no existe: {inventory_file}")

    content = inventory_file.read_bytes()

    db = SessionLocal()
    try:
        empresa = _create_test_company(db)
        db.info["empresa_id"] = empresa.id

        def progress(done: int, total: int) -> None:
            if done == total or (done % 5000) == 0:
                print(f"Progreso: {done}/{total}")

        inserted = ingest_excel_bytes_to_staging(
            db=db,
            empresa_id=empresa.id,
            content=content,
            filename=inventory_file.name,
            progress=progress,
        )

        total = (
            db.query(StagingImport)
            .filter(StagingImport.empresa_id == empresa.id)
            .count()
        )
        ok = (
            db.query(StagingImport)
            .filter(
                StagingImport.empresa_id == empresa.id,
                StagingImport.status == "pending",
            )
            .count()
        )
        failed = (
            db.query(StagingImport)
            .filter(
                StagingImport.empresa_id == empresa.id,
                StagingImport.status == "failed",
            )
            .count()
        )

        print(f"Archivo: {inventory_file} ({len(content)} bytes)")
        print(f"empresa_id: {empresa.id} (codigo={empresa.codigo})")
        print(f"Filas insertadas (staging_imports): {inserted}")
        print(f"Total en staging_imports (empresa): {total}")
        print(f"Exitosas (status=pending): {ok}")
        print(f"Fallidas (status=failed): {failed}")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
