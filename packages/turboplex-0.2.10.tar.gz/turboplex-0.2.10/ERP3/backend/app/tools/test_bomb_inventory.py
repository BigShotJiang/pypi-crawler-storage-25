from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import uuid6
from sqlalchemy import func

def main() -> int:
    backend_root = Path(__file__).resolve().parents[2]
    if str(backend_root) not in sys.path:
        sys.path.insert(0, str(backend_root))

    from app.core.database import SessionLocal, reader_engine, writer_engine
    from app.core_modules.sistema.models import Empresa
    from app.models.staging import StagingImport
    from app.core.services.ingestion_service import (
        ingest_excel_bytes_to_staging,
        process_staging_to_production,
        apply_validated_inventory_to_production,
    )

    writer_engine.echo = False
    reader_engine.echo = False

    file_path = Path(r"C:\GitHub\ERP3\test_bomb_inventory.xlsx")
    if not file_path.exists():
        raise FileNotFoundError(str(file_path))

    content = file_path.read_bytes()

    db = SessionLocal()
    try:
        prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
        db.info["allow_no_tenant"] = True
        try:
            empresa = Empresa(
                nombre="Empresa Bomb Inventory",
                codigo=f"TST-BOMB-{uuid6.uuid7().hex[:8]}",
            )
            db.add(empresa)
            db.commit()
            db.refresh(empresa)
        finally:
            if prev_allow_no_tenant is None:
                db.info.pop("allow_no_tenant", None)
            else:
                db.info["allow_no_tenant"] = prev_allow_no_tenant

        db.info["empresa_id"] = empresa.id

        def progress(done: int, total: int) -> None:
            if done == total or (done % 5000) == 0:
                print(f"Progreso (ingesta): {done}/{total}")

        inserted = ingest_excel_bytes_to_staging(
            db=db,
            empresa_id=empresa.id,
            content=content,
            filename=file_path.name,
            progress=progress,
        )

        summary = process_staging_to_production(
            db=db,
            empresa_id=empresa.id,
            limit=inserted,
            template="inventario",
        )

        validated_total = (
            db.query(func.count(StagingImport.id))
            .filter(
                StagingImport.empresa_id == empresa.id,
                StagingImport.status == "validated",
            )
            .scalar()
            or 0
        )
        failed_total = (
            db.query(func.count(StagingImport.id))
            .filter(
                StagingImport.empresa_id == empresa.id,
                StagingImport.status == "failed",
            )
            .scalar()
            or 0
        )
        failed_row = (
            db.query(StagingImport)
            .filter(
                StagingImport.empresa_id == empresa.id,
                StagingImport.status == "failed",
            )
            .order_by(StagingImport.created_at.asc())
            .first()
        )

        print(f"archivo={file_path} bytes={len(content)}")
        print(f"empresa_id={empresa.id} codigo={empresa.codigo}")
        print(f"rows_inserted={inserted}")
        print(f"processed={summary.get('processed')} validated={summary.get('validated')} failed={summary.get('failed')}")
        print(f"validated_total={validated_total} failed_total={failed_total}")
        print(f"example_error_log={(failed_row.error_log if failed_row else None)}")

        file_hash = hashlib.sha256(content).hexdigest()
        apply_summary = apply_validated_inventory_to_production(
            db=db,
            empresa_id=empresa.id,
            filename=file_path.name,
            file_hash=file_hash,
            limit=int(validated_total),
        )
        print(
            "apply_summary="
            + str(
                {
                    "import_run_id": apply_summary.get("import_run_id"),
                    "bodega_id": apply_summary.get("bodega_id"),
                    "created_products": apply_summary.get("created_products"),
                    "updated_products": apply_summary.get("updated_products"),
                    "stock_updates": apply_summary.get("stock_updates"),
                    "errors_count": len(apply_summary.get("errors") or []),
                }
            )
        )

        from app.models.staging import ImportRun

        run = (
            db.query(ImportRun)
            .filter(
                ImportRun.id == apply_summary.get("import_run_id"),
                ImportRun.empresa_id == empresa.id,
            )
            .first()
        )
        if not run:
            raise RuntimeError("ImportRun no encontrado")
        if str(run.bodega_id) != str(apply_summary.get("bodega_id")):
            raise RuntimeError("ImportRun.bodega_id no coincide con bodega aplicada")

        print(
            "import_run="
            + str(
                {
                    "id": str(run.id),
                    "empresa_id": str(run.empresa_id),
                    "bodega_id": str(run.bodega_id),
                    "status": str(run.status),
                    "file_hash": str(run.file_hash),
                    "summary": run.summary,
                }
            )
        )
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
