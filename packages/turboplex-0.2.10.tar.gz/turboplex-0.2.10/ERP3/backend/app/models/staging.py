import enum
from sqlalchemy import Column, ForeignKey, String, Enum as SAEnum, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID
import uuid6

from app.core.database import Base, GUID
from app.core.utils.mixins import TimestampMixin


class StagingImport(Base, TimestampMixin):
    __tablename__ = "staging_imports"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(
        GUID, ForeignKey("empresas.id"), nullable=False, index=True
    )

    source_filename = Column(String, nullable=True)
    source_type = Column(String, nullable=True)

    status = Column(String, nullable=False, default="pending", index=True)
    raw_content = Column(JSONB, nullable=False)
    error_log = Column(JSONB, nullable=True)

    empresa = relationship("app.core_modules.sistema.models.Empresa")


class ImportRunStatus(str, enum.Enum):
    STARTED = "STARTED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class ImportRun(Base, TimestampMixin):
    __tablename__ = "import_runs"

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    bodega_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("bodegas.id"), nullable=False, index=True)

    filename = Column(String, nullable=True)
    file_hash = Column(String, nullable=False, index=True)
    status = Column(SAEnum(ImportRunStatus, name="import_run_status"), nullable=False, default=ImportRunStatus.STARTED, index=True)
    summary = Column(JSONB, nullable=True)

    empresa = relationship("app.core_modules.sistema.models.Empresa")
    bodega = relationship("app.core_modules.sistema.models.Bodega")


class ImportTemplateType(str, enum.Enum):
    CATALOG = "CATALOG"
    STOCK_ADJUST = "STOCK_ADJUST"


class ImportTemplate(Base, TimestampMixin):
    __tablename__ = "import_templates"
    __table_args__ = (
        UniqueConstraint("empresa_id", "nombre", name="uq_import_templates_empresa_nombre"),
    )

    id: Mapped[UUID] = mapped_column(GUID, primary_key=True, index=True, default=uuid6.uuid7)
    empresa_id: Mapped[UUID] = mapped_column(GUID, ForeignKey("empresas.id"), nullable=False, index=True)
    nombre = Column(String, nullable=False)
    tipo_importacion = Column(
        SAEnum(ImportTemplateType, name="import_template_type"),
        nullable=False,
        index=True,
    )
    mapping_json = Column(JSONB, nullable=False)

    empresa = relationship("app.core_modules.sistema.models.Empresa")
