# Core
from app.core.database.models import Setting

# Core Modules - Sistema (Base)
from app.core_modules.sistema.models import (
    Usuario,
    UsuarioEmpresa,
    Empresa,
    Sucursal,
    Bodega,
    Ubicacion,
    MetodoPago,
    EmpresaMetodoPago,
    PapeleraReciclaje,
)

# Core Modules - Ventas
from app.core_modules.ventas.models import (
    Cliente,
    Producto,
    Venta,
    DetalleVenta,
    Receta,
    InsumoReceta,
    OrdenServicio,
)

# Core Modules - Inventario
from app.core_modules.inventario.movimientos.models import MovimientoStock
from app.core_modules.inventario.stock.models import Inventario, InventarioUbicacion

# Core Modules - Finanzas
from app.core_modules.finanzas.models import (
    Gasto,
    PrecioProducto,
    CuentaContable,
    AsientoContable,
    MovimientoContable,
)

# Core Modules - POS Retail (Addon)
from app.addons.pos_retail.models import CierreCaja

# Addons - Portal del Cliente
from app.addons.portal.models import PortalPaymentNotification, PortalUser

# Core Modules - Compras
from app.core_modules.compras.models import Proveedor, OrdenCompra, OrdenCompraDetalle

# Core Modules - RRHH
from app.core_modules.rrhh.models import (
    Empleado,
    Asistencia,
    TipoTurno,
    PlanificacionTurno,
    LiquidacionSueldo,
)

# Core Modules - TI
from app.core_modules.ti.models import ActivoTI

# Verticals
# from app.verticals.lavanderia.models import TicketLavanderia, EstadoPrenda

# Core Modules - Service Engine
from app.core_modules.service_engine.models import (
    ServiceOrder,
    JobOrder,
    ServiceWorkflow,
)

# Core Modules - Facturacion
from app.core_modules.facturacion.models import (
    DocumentoTributario,
    DocumentoTributarioDetalle,
    FolioSII,
)

# Core Modules - Auditoria
from app.core_modules.auditoria.models import AuditLog

# Core Modules - CRM
from app.core_modules.crm.models import (
    Embudo,
    Etapa,
    OportunidadVenta,
    DetalleOportunidad,
    Actividad,
    Notification,
    OportunidadComentario,
)

# Core Modules - Legal
from app.core_modules.legal.models import DocumentoLegal, EstadoDocumento

# Core Modules - Billing
from app.core_modules.billing.models import (
    SubscriptionPlan,
    CompanySubscription,
    PaymentReceipt,
)

from app.models.staging import StagingImport

__all__ = [
    "Setting",
    "Usuario",
    "UsuarioEmpresa",
    "Empresa",
    "Sucursal",
    "Bodega",
    "Ubicacion",
    "MetodoPago",
    "EmpresaMetodoPago",
    "PapeleraReciclaje",
    "Cliente",
    "Producto",
    "Venta",
    "DetalleVenta",
    "Receta",
    "InsumoReceta",
    "OrdenServicio",
    "Inventario",
    "InventarioUbicacion",
    "MovimientoStock",
    "Gasto",
    "PrecioProducto",
    "CuentaContable",
    "AsientoContable",
    "MovimientoContable",
    "CierreCaja",
    "PortalPaymentNotification",
    "PortalUser",
    "Proveedor",
    "OrdenCompra",
    "OrdenCompraDetalle",
    "Empleado",
    "Asistencia",
    "TipoTurno",
    "PlanificacionTurno",
    "LiquidacionSueldo",
    "ActivoTI",
    "ServiceOrder",
    "JobOrder",
    "ServiceWorkflow",
    "DocumentoTributario",
    "DocumentoTributarioDetalle",
    "FolioSII",
    "AuditLog",
    "Embudo",
    "Etapa",
    "OportunidadVenta",
    "DetalleOportunidad",
    "Actividad",
    "Notification",
    "OportunidadComentario",
    "DocumentoLegal",
    "EstadoDocumento",
    "SubscriptionPlan",
    "CompanySubscription",
    "PaymentReceipt",
    "StagingImport",
]
