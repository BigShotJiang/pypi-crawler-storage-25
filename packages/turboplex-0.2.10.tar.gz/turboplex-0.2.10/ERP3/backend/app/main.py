from fastapi import FastAPI, Request, status, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from app.core.config import settings
from app.core.database import SessionLocal, validate_database_connections
from app.core.database import database as db_database
from app.core.observability.logging_config import setup_logging
from app.core.exceptions import ERPException
from app.core.exceptions import (
    build_erp_error_envelope,
    build_http_error_envelope,
    build_validation_error_envelope,
    build_generic_error_envelope,
)
import os
import logging
from pathlib import Path
from datetime import datetime, timedelta, timezone
from uuid import uuid4
from app.core.observability.tracing import init_tracing
from app.core.infrastructure.redis import get_redis_client, validate_redis_connection
from time import perf_counter
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import text
import asyncio
from typing import Callable, Awaitable, cast

# Rate Limiting
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.core.infrastructure.rate_limit import limiter
from slowapi.util import get_remote_address

# Métricas
from app.core.observability.metrics import metrics_middleware, get_metrics
from app.core.privacy import privacy_middleware

from app.api.v1.api import api_router
from app.addons import include_enabled_addon_routers
from app.core.audit import register_audit_listeners
from app.core_modules.billing.models import CompanySubscription
from app.core_modules.compras import listeners as compras_listeners
from app.core_modules.auditoria import listeners as auditoria_listeners
from app.core_modules.finanzas import listeners as finanzas_listeners
from app.core_modules.notificaciones import listeners as notificaciones_listeners
from app.core_modules.sistema.models import AuditLog, AuditSeverity, Empresa
from app.core_modules.ventas import listeners as ventas_listeners

setup_logging()
logger = logging.getLogger(__name__)

# Importar modelos para asegurar que create_all los detecte
# ORDEN DE IMPORTACIÓN CRÍTICO:
# 1. Modelos Base (Sistema: Empresa, Usuario)
# 2. Modelos Core (Facturación, Ventas, etc. que dependen de Empresa)

# Registrar auditoría
register_audit_listeners()

# Crear app
_is_production = settings.ENVIRONMENT.lower() == "production"
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
    docs_url=None if _is_production else "/docs",
    redoc_url=None if _is_production else "/redoc",
)

# ============================================================================
# CORS — debe registrarse PRIMERO para que intercepte requests OPTIONS antes
# que cualquier otro middleware (orden LIFO en Starlette/FastAPI)
# ============================================================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS or ["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    expose_headers=["X-Total-Count", "X-Request-ID"],
    allow_headers=[
        "Authorization",
        "Content-Type",
        "X-Requested-With",
        "X-Support-Mode",
        "X-Request-ID",
    ],
)

# Configuración Rate Limiter Global (SlowApi)
app.state.limiter = limiter
app.add_exception_handler(
    RateLimitExceeded,
    cast(
        Callable[[Request, Exception], Response | Awaitable[Response]],
        _rate_limit_exceeded_handler,
    ),
)

if settings.SENTRY_DSN:
    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastApiIntegration
        from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration
        from sentry_sdk.integrations.rq import RqIntegration
        sentry_sdk.init(
            dsn=settings.SENTRY_DSN,
            environment=settings.SENTRY_ENVIRONMENT or settings.ENVIRONMENT,
            traces_sample_rate=settings.SENTRY_TRACES_SAMPLE_RATE,
            integrations=[FastApiIntegration(), SqlalchemyIntegration(), RqIntegration()],
            send_default_pii=False,
        )
    except Exception:
        pass

init_tracing(app)

_csp_value = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"


@app.middleware("http")
async def security_headers_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault(
        "Permissions-Policy", "geolocation=(), microphone=(), camera=()"
    )
    if _is_production:
        response.headers.setdefault("Content-Security-Policy", _csp_value)
        response.headers.setdefault(
            "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
        )
    return response


@app.on_event("startup")
async def validate_redis_on_startup() -> None:
    validate_redis_connection()


@app.on_event("startup")
async def validate_db_on_startup() -> None:
    validate_database_connections()


async def tenant_suspension_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    try:
        path = request.url.path or ""
        if path.endswith("/admin/setup-client") or path.endswith("/public/onboarding"):
            return await call_next(request)
        cmp = request.query_params.get("cmp")
        if cmp:
            db = SessionLocal()
            try:
                prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
                db.info["allow_no_tenant"] = True
                empresa = db.query(Empresa).filter(Empresa.codigo == cmp).first()
                if empresa:
                    # Evaluar suspensión en base a fecha de vencimiento + días de gracia
                    now = datetime.now(timezone.utc)
                    try:
                        sub = (
                            db.query(CompanySubscription)
                            .filter(CompanySubscription.empresa_id == empresa.id)
                            .first()
                        )
                    except SQLAlchemyError:
                        return await call_next(request)
                    expires_at = getattr(sub, "expires_at", None)
                    grace_days = getattr(empresa, "grace_period_days", 5) or 5
                    grace_limit = None
                    if expires_at:
                        grace_limit = expires_at + timedelta(days=grace_days)
                    else:
                        # Sin suscripción: considerar expirado y sin gracia (gracia desde ahora)
                        grace_limit = now
                    past_grace = now > grace_limit

                    if past_grace:
                        # Suspensión suave: permitir GET/HEAD/OPTIONS, bloquear mutaciones
                        method = request.method.upper()
                        if method in ("POST", "PUT", "DELETE", "PATCH"):
                            return JSONResponse(
                                status_code=status.HTTP_403_FORBIDDEN,
                                content={
                                    "detail": "Operación no permitida: Suscripción en modo lectura"
                                },
                            )
                        # GET/HEAD/OPTIONS pasan en modo lectura
            finally:
                if "prev_allow_no_tenant" in locals():
                    if prev_allow_no_tenant is None:
                        db.info.pop("allow_no_tenant", None)
                    else:
                        db.info["allow_no_tenant"] = prev_allow_no_tenant
                db.close()
    except Exception as e:
        logger.error(f"Error in tenant_suspension_middleware: {e}")
    response = await call_next(request)
    return response


@app.middleware("http")
async def timing_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    start = perf_counter()
    request.state.start_time = start
    response = await call_next(request)
    try:
        duration_ms = int((perf_counter() - start) * 1000)
        response.headers["X-Response-Time-ms"] = str(duration_ms)
    except Exception:
        pass
    return response


@app.middleware("http")
async def global_timeout_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    start = getattr(request.state, "start_time", None)
    try:
        return await asyncio.wait_for(call_next(request), timeout=15.0)
    except asyncio.TimeoutError as exc:
        _, envelope = build_generic_error_envelope(
            exc=exc,
            path=str(request.url.path),
            start_time=start,
        )
        return JSONResponse(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            content=envelope.model_dump(),
        )


# ============================================================================
# RATE LIMITING
# ============================================================================


def get_client_ip(request: Request) -> str:
    """
    En desarrollo permite forzar la IP vía header X-RateLimit-Test-IP
    para probar múltiples clientes desde localhost sin afectar producción.
    """
    if settings.ENVIRONMENT == "development":
        test_ip = request.headers.get("X-RateLimit-Test-IP")
        if test_ip:
            return test_ip
    return get_remote_address(request)


async def rate_limit_handler(request: Request, exc: RateLimitExceeded) -> Response:
    """
    Handler personalizado para 429 que registra un evento crítico en AuditLog
    con IP origen y recurso atacado, y luego delega en el handler de SlowAPI.
    """
    try:
        db = SessionLocal()
        try:
            ip = request.client.host if request.client else None
            path = request.url.path
            payload = {
                "method": request.method,
                "path": path,
                "ip": ip,
                "detail": str(getattr(exc, "detail", "")),
            }
            entry = AuditLog(
                actor_id=None,
                impersonated_user_id=None,
                action="RATE_LIMIT_EXCEEDED",
                resource=path,
                severity=AuditSeverity.CRITICAL,
                changes=payload,
                ip_address=ip,
            )
            db.add(entry)
            db.commit()
        except Exception as e:
            db.rollback()
            logger.error(f"[RATE_LIMIT] Error registrando AuditLog 429: {e}")
        finally:
            db.close()
    except Exception as e:
        logger.error(f"[RATE_LIMIT] Error en handler personalizado: {e}")

    response = _rate_limit_exceeded_handler(request, exc)
    if asyncio.iscoroutine(response):
        response = await response
    return response


if settings.RATE_LIMIT_ENABLED:
    limiter = Limiter(key_func=get_client_ip)
    app.state.limiter = limiter
    app.add_exception_handler(
        RateLimitExceeded,
        cast(
            Callable[[Request, Exception], Response | Awaitable[Response]],
            rate_limit_handler,
        ),
    )
    logger.info(
        f"✅ Rate limiting habilitado: {settings.RATE_LIMIT_PER_MINUTE} req/min"
    )
else:
    logger.info("⚠️  Rate limiting deshabilitado")

# ============================================================================
# EXCEPTION HANDLERS (Manejo de Errores Estandarizado)
# ============================================================================


@app.exception_handler(ERPException)
async def erp_exception_handler(request: Request, exc: ERPException) -> JSONResponse:
    start = getattr(request.state, "start_time", None)
    status_code, envelope = build_erp_error_envelope(
        exc=exc,
        path=str(request.url.path),
        start_time=start,
    )
    return JSONResponse(status_code=status_code, content=envelope.model_dump(mode="json"))


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    start = getattr(request.state, "start_time", None)
    status_code, envelope = build_generic_error_envelope(
        exc=exc,
        path=str(request.url.path),
        start_time=start,
    )
    return JSONResponse(status_code=status_code, content=envelope.model_dump(mode="json"))


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    start = getattr(request.state, "start_time", None)
    try:
        if "/sucursales/active" in str(request.url.path or ""):
            logger.error(
                "HTTPException detail=%s path=%s cmp=%s request_id=%s",
                exc.detail,
                str(request.url.path),
                request.query_params.get("cmp"),
                getattr(request.state, "request_id", None)
                or request.headers.get("X-Request-ID"),
            )
    except Exception:
        pass
    status_code, envelope = build_http_error_envelope(
        exc=exc,
        path=str(request.url.path),
        start_time=start,
    )
    return JSONResponse(status_code=status_code, content=envelope.model_dump(mode="json"))


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    start = getattr(request.state, "start_time", None)
    try:
        if "/sucursales/active" in str(request.url.path or ""):
            logger.error(
                "RequestValidationError errors=%s path=%s cmp=%s request_id=%s",
                exc.errors(),
                str(request.url.path),
                request.query_params.get("cmp"),
                getattr(request.state, "request_id", None)
                or request.headers.get("X-Request-ID"),
            )
    except Exception:
        pass
    status_code, envelope = build_validation_error_envelope(
        exc=exc,
        path=str(request.url.path),
        start_time=start,
    )
    return JSONResponse(status_code=status_code, content=envelope.model_dump(mode="json"))


# ============================================================================
# MIDDLEWARE
# ============================================================================

app.middleware("http")(privacy_middleware)
app.middleware("http")(tenant_suspension_middleware)

# Middleware de métricas (si está habilitado)
if settings.METRICS_ENABLED:
    app.middleware("http")(metrics_middleware)
    logger.info("✅ Métricas de Prometheus habilitadas")
else:
    logger.info("⚠️  Métricas deshabilitadas")

# CORS ya registrado al inicio del archivo (ver arriba)

# --- Dynamic Vertical Loading System ---
# REMOVED: Vestigial vertical loading system.
# Use app/core_modules/service_engine/industry_templates.py for vertical configurations.



# Health check
@app.get("/", tags=["General"])
def root() -> dict[str, object]:
    return {
        "message": f"{settings.PROJECT_NAME} - API funcionando",
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
    }


@app.get("/health", tags=["General"])
def health_check() -> dict[str, object]:
    db_ok = True
    db_err = None
    try:
        db = SessionLocal()
        try:
            prev_allow_no_tenant = db.info.get("allow_no_tenant", None)
            db.info["allow_no_tenant"] = True
            db.execute(text("SELECT 1"))
        finally:
            if "prev_allow_no_tenant" in locals():
                if prev_allow_no_tenant is None:
                    db.info.pop("allow_no_tenant", None)
                else:
                    db.info["allow_no_tenant"] = prev_allow_no_tenant
            db.close()
    except Exception as e:
        db_ok = False
        db_err = str(e)
    redis_ok = True
    redis_err = None
    try:
        r = get_redis_client()
        r.ping()
    except Exception as e:
        redis_ok = False
        redis_err = str(e)
    status_str = "ok" if db_ok and redis_ok else "error" if not db_ok and not redis_ok else "degraded"
    return {
        "status": status_str,
        "database": "ok" if db_ok else "error",
        "redis": "ok" if redis_ok else "error",
        "details": {"db_error": db_err, "redis_error": redis_err},
    }


# Endpoint de métricas de Prometheus
if settings.METRICS_ENABLED:

    @app.get("/metrics", tags=["Observability"])
    def metrics() -> Response:
        """Endpoint para Prometheus scraping"""
        return get_metrics()


@app.post("/admin/reload", tags=["System"])
def reload_server() -> dict[str, str]:
    """
    Dispara un reinicio suave del servidor (Graceful Reload) tocando un archivo monitoreado.
    Funciona cuando Uvicorn corre con --reload.
    """
    trigger_file = Path(__file__).parent / "reload_trigger.py"
    try:
        # Actualizar timestamp (touch) para disparar el watch de Uvicorn
        if not trigger_file.exists():
            trigger_file.touch()
        else:
            # En Windows a veces touch no es suficiente si el contenido no cambia,
            # pero utime suele funcionar para file watchers.
            # Si falla, podemos escribir un comentario.
            os.utime(trigger_file, None)

        return {
            "status": "reloading",
            "message": "Server reload triggered. Please wait a moment.",
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}





finanzas_listeners.register_listeners()
ventas_listeners.register_listeners()
notificaciones_listeners.register_listeners()
auditoria_listeners.register_listeners()
compras_listeners.register_listeners()
# ---------------------------------

# Importar routers principales
app.include_router(api_router, prefix=settings.API_V1_PREFIX)
include_enabled_addon_routers(app, api_prefix=settings.API_V1_PREFIX)

@app.middleware("http")
async def request_id_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    rid = request.headers.get("X-Request-ID")
    if not rid:
        rid = str(uuid4())
    try:
        request.state.request_id = rid
    except Exception:
        pass
    token = None
    try:
        token = db_database.set_request_context(
            {
                "request_id": rid,
                "path": str(request.url.path or ""),
                "cmp": request.query_params.get("cmp"),
            }
        )
    except Exception:
        token = None
    try:
        sentry_sdk.set_tag("request_id", rid)
    except Exception:
        pass
    try:
        response = await call_next(request)
        response.headers["X-Request-ID"] = rid
        return response
    finally:
        try:
            if token is not None:
                db_database.reset_request_context(token)
        except Exception:
            pass
