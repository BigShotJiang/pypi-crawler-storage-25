from app.core.database import engine
from sqlalchemy import text


def apply_migrations():
    with engine.connect() as connection:
        # 1. Crear tabla audit_logs si no existe
        print("Creando tabla 'audit_logs'...")
        connection.execute(
            text("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id SERIAL PRIMARY KEY,
                actor_id INTEGER NOT NULL REFERENCES usuarios(id),
                impersonated_user_id INTEGER REFERENCES usuarios(id),
                action VARCHAR NOT NULL,
                resource VARCHAR NOT NULL,
                severity VARCHAR DEFAULT 'INFO',
                changes JSONB,
                ip_address VARCHAR,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
            );
        """)
        )

        # 2. Agregar columnas a empresas si no existen
        print("Actualizando tabla 'empresas'...")
        try:
            connection.execute(
                text(
                    "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS pwr_bi_enabled BOOLEAN DEFAULT FALSE;"
                )
            )
            print("- Columna 'pwr_bi_enabled' agregada.")
        except Exception as e:
            print(f"- Error agregando 'pwr_bi_enabled': {e}")

        try:
            connection.execute(
                text(
                    "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS pwr_bi_config JSONB DEFAULT '{}';"
                )
            )
            print("- Columna 'pwr_bi_config' agregada.")
        except Exception as e:
            print(f"- Error agregando 'pwr_bi_config': {e}")

        connection.commit()
        print("\nMigración completada exitosamente.")


if __name__ == "__main__":
    apply_migrations()
