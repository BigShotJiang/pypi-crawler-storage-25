import sys
import os
import random
import string
import logging
from datetime import datetime, timedelta

# Disable SQLAlchemy logs
logging.basicConfig()
logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import SessionLocal
from app.core_modules.ventas.models import (
    Venta,
    DetalleVenta,
    Producto,
    Cliente,
    OrdenServicio,
    EstadoOrdenServicioEnum,
    EstadoVentaEnum,
    HistorialOrdenServicio,
)
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
    UsuarioEmpresa,
)
from app.core_modules.ventas.inventory_service import InventoryService

# Setup DB
db = SessionLocal()


def random_string(length=10):
    return "".join(random.choices(string.ascii_letters, k=length))


def run_fifo_test():
    print("=== INICIANDO TEST DE RE-ASIGNACION FIFO ===")

    # 1. Setup Data
    print("1. Creando Datos Base (Empresa, Sucursal, Bodega, Producto)...")
    empresa = Empresa(
        nombre=f"FIFO Test Corp {random_string()}",
        rut=f"55.{random.randint(100, 999)}.{random.randint(100, 999)}-5",
        codigo=f"FIFO_{random_string(4)}",
    )
    db.add(empresa)
    db.flush()

    sucursal = Sucursal(
        nombre="Sucursal FIFO", direccion="Calle FIFO 123", empresa_id=empresa.id
    )
    db.add(sucursal)
    db.flush()

    bodega = Bodega(nombre="Bodega FIFO", sucursal_id=sucursal.id)
    db.add(bodega)
    db.flush()

    usuario = Usuario(
        email=f"fifo_{random_string()}@test.com", hashed_password="hash", role="ADMIN"
    )
    db.add(usuario)
    db.flush()

    # Link user to company
    usuario_empresa = UsuarioEmpresa(
        usuario_id=usuario.id, empresa_id=empresa.id, is_default=True
    )
    db.add(usuario_empresa)
    db.flush()

    cliente = Cliente(nombre="Cliente Espera", empresa_id=empresa.id)
    db.add(cliente)
    db.flush()

    producto = Producto(
        nombre="Producto Escaso",
        sku=f"SKU-FIFO-{random_string(4)}",
        precio=1000,
        tipo_producto="ALMACENABLE",
        empresa_id=empresa.id,
    )
    db.add(producto)
    db.flush()

    # Asegurar Stock 0
    # No agregamos stock inicial

    # 2. Crear Venta en Estado PENDIENTE_SIN_STOCK
    print("2. Creando Venta en estado PENDIENTE_SIN_STOCK (Simulando espera)...")
    venta_espera = Venta(
        fecha=datetime.now(),
        folio="V-FIFO-001",
        total=1000,
        cliente_id=cliente.id,
        sucursal_id=sucursal.id,
        vendedor_id=usuario.id,
        empresa_id=empresa.id,
        estado=EstadoVentaEnum.PENDIENTE_SIN_STOCK,
    )
    db.add(venta_espera)
    db.flush()

    detalle = DetalleVenta(
        venta_id=venta_espera.id,
        producto_id=producto.id,
        cantidad=1,  # Necesita 1
        precio_unitario=1000,
        subtotal=1000,
        es_servicio=False,
    )
    db.add(detalle)

    os_espera = OrdenServicio(
        venta_id=venta_espera.id,
        estado=EstadoOrdenServicioEnum.EN_ESPERA_STOCK,
        fecha_recepcion=datetime.now(),
        fecha_entrega_prometida=datetime.now() + timedelta(days=1),
    )
    db.add(os_espera)
    db.commit()

    print(f"   -> Venta creada ID: {venta_espera.id}. Estado: {venta_espera.estado}")
    print(f"   -> OS Estado: {os_espera.estado}")

    # 3. Simular Entrada de Stock
    print("\n3. Simulando entrada de 5 unidades de stock...")
    cantidad_entrada = 5
    reactivadas = InventoryService.add_stock(
        db, producto.id, bodega.id, cantidad_entrada, "COMPRA_PROVEEDOR", empresa.id
    )

    print(f"   -> Stock ingresado. Órdenes reactivadas reportadas: {reactivadas}")

    # 4. Verificar Resultados
    print("\n4. Verificando Estados Finales...")
    db.expire_all()
    venta_check = db.query(Venta).get(venta_espera.id)
    os_check = db.query(OrdenServicio).get(os_espera.id)

    # Check Venta
    if venta_check.estado == EstadoVentaEnum.PENDIENTE:
        print("   ✅ CORRECTO: Venta pasó a estado PENDIENTE.")
    else:
        print(
            f"   ❌ ERROR: Venta en estado {venta_check.estado} (Esperado: PENDIENTE)"
        )

    # Check OS
    if os_check.estado == EstadoOrdenServicioEnum.RESERVADO:
        print("   ✅ CORRECTO: OS pasó a estado RESERVADO.")
    else:
        print(f"   ❌ ERROR: OS en estado {os_check.estado} (Esperado: RESERVADO)")

    # Check Stock Remanente
    # Entraron 5, se usó 1 -> Deberían quedar 4
    from app.core_modules.ventas.models import Inventario

    inv = (
        db.query(Inventario)
        .filter(
            Inventario.producto_id == producto.id, Inventario.bodega_id == bodega.id
        )
        .first()
    )
    if inv.cantidad == 4:
        print("   ✅ CORRECTO: Stock remanente es 4 (5 entrada - 1 asignado).")
    else:
        print(f"   ❌ ERROR: Stock remanente es {inv.cantidad} (Esperado: 4)")

    # Check Historial
    historial = (
        db.query(HistorialOrdenServicio)
        .filter(
            HistorialOrdenServicio.orden_servicio_id == os_check.id,
            HistorialOrdenServicio.estado_nuevo == EstadoOrdenServicioEnum.RESERVADO,
        )
        .first()
    )

    if historial:
        print(f"   ✅ CORRECTO: Historial registrado: '{historial.observacion}'")
    else:
        print("   ❌ ERROR: No se encontró registro en historial.")


if __name__ == "__main__":
    try:
        run_fifo_test()
    except Exception as e:
        print(f"❌ CRITICAL ERROR: {e}")
        import traceback

        traceback.print_exc()
