import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import SessionLocal

# Importar modelos necesarios para evitar errores de relaciones no resueltas
import app.core_modules.finanzas.models
import app.core_modules.compras.models
from app.core_modules.ventas.models import Cliente
from app.core_modules.sistema.models import AuditLog, Empresa, Usuario
import app.core.audit  # Important: Import to register event listeners


def run_verification():
    print("=== Iniciando Verificación de Auditoría y Soft Delete ===")

    # Activar listeners de auditoría
    app.core.audit.register_audit_listeners()

    db = SessionLocal()

    test_rut = "99999999-9"
    test_user_email = "audit_test_user@example.com"

    try:
        # 0. Setup Prerequisites (Empresa & Usuario)
        empresa = db.query(Empresa).first()
        if not empresa:
            print("Creando empresa temporal...")
            empresa = Empresa(nombre="Empresa Test", codigo="TEST", rut="999-9")
            db.add(empresa)
            db.commit()
            db.refresh(empresa)
        empresa_id = empresa.id

        usuario = db.query(Usuario).filter_by(email=test_user_email).first()
        if not usuario:
            print("Creando usuario temporal para auditoría...")
            usuario = Usuario(
                email=test_user_email,
                hashed_password="dummy_hash",
                role="TEST",
                is_active=True,
            )
            db.add(usuario)
            db.commit()
            db.refresh(usuario)
        user_id = usuario.id
        print(f"Usando Usuario ID: {user_id} para auditoría")

        # Simular contexto de usuario
        db.info["user_id"] = user_id

        # 1. Limpieza previa robusta
        existing = db.query(Cliente).filter_by(rut=test_rut).first()
        if existing:
            print(f"Limpiando cliente de prueba existente ID: {existing.id}")
            db.query(AuditLog).filter(
                AuditLog.resource == f"clientes:{existing.id}"
            ).delete()
            db.delete(existing)
            db.commit()

        # 2. Crear Cliente (INSERT)
        print("\n1. Creando Cliente de prueba...")
        cliente = Cliente(
            rut=test_rut,
            nombre="Cliente Auditoria Test",  # Corregido: nombre en vez de razon_social
            email="audit@test.com",
            telefono="+56999999999",
            direccion="Calle Falsa 123",
            empresa_id=empresa_id,  # Agregado campo obligatorio
            # Eliminados campos no existentes: comuna, region, giro
        )
        db.add(cliente)
        db.commit()
        db.refresh(cliente)
        print(f"   Cliente creado. ID: {cliente.id}")

        cliente_id = cliente.id

        # 2. Verificar Soft Delete
        print("\n2. Ejecutando Soft Delete...")
        cliente.soft_delete(db)
        db.commit()

        # Verificar estado en DB
        # Usamos una nueva consulta para asegurar que leemos de DB
        db.expire_all()
        cliente_deleted = db.query(Cliente).get(cliente_id)

        if cliente_deleted.is_deleted:
            print("   [OK] Cliente marcado como eliminado (is_deleted=True)")
            print(f"   Fecha eliminación: {cliente_deleted.deleted_at}")
        else:
            print("   [ERROR] Cliente NO marcado como eliminado")

        # 3. Verificar Restauración
        print("\n3. Ejecutando Restauración...")
        cliente_deleted.restore(db)
        db.commit()

        db.expire_all()
        cliente_restored = db.query(Cliente).get(cliente_id)

        if not cliente_restored.is_deleted and cliente_restored.deleted_at is None:
            print("   [OK] Cliente restaurado correctamente (is_deleted=False)")
        else:
            print("   [ERROR] Cliente NO restaurado correctamente")

        # 4. Verificar Logs de Auditoría
        print("\n4. Verificando Logs de Auditoría...")
        logs = (
            db.query(AuditLog)
            .filter(AuditLog.resource == f"clientes:{cliente_id}")
            .order_by(AuditLog.created_at)
            .all()
        )

        if not logs:
            print("   [ERROR] No se encontraron logs de auditoría")
        else:
            print(f"   Se encontraron {len(logs)} registros de log:")
            for log in logs:
                print(
                    f"   - [{log.action}] User: {log.actor_id} | Fecha: {log.created_at}"
                )
                print(f"     Cambios: {log.changes}")

            # Validar secuencia esperada: INSERT -> UPDATE (soft delete) -> UPDATE (restore)
            actions = [l.action for l in logs]
            if "INSERT" in actions and "DELETE (SOFT)" in actions:
                print("\n   [OK] Secuencia de auditoría detectada correctamente.")
            else:
                print(
                    f"\n   [WARNING] Secuencia de auditoría incompleta. Actions found: {actions}"
                )

    except Exception as e:
        print(f"\n[ERROR] Excepción durante la prueba: {e}")
        import traceback

        traceback.print_exc()
    finally:
        # Limpieza final
        if "db" in locals():
            db.rollback()  # Ensure rollback if pending transaction

        if "cliente" in locals() and cliente.id:
            print("\nLimpiando datos de prueba...")
            try:
                # Hard delete para no ensuciar
                db.query(AuditLog).filter(
                    AuditLog.resource == f"clientes:{cliente.id}"
                ).delete()
                db.query(Cliente).filter_by(id=cliente.id).delete()
                # Opcional: limpiar usuario de prueba
                if "user_id" in locals():
                    db.query(Usuario).filter_by(id=user_id).delete()
                db.commit()
            except Exception as e:
                print(f"Error limpiando: {e}")
                db.rollback()
        db.close()


if __name__ == "__main__":
    run_verification()
