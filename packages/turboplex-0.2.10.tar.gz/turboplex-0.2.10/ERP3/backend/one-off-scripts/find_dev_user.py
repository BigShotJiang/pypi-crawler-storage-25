import sys
import os

# Añadir el directorio actual al path para poder importar app
sys.path.append(os.getcwd())

from sqlalchemy import select
from app.core_modules.sistema.models import Usuario

def find_dev_users():
    # Intentar usar las credenciales de superusuario si el usuario erp3_user falla
    # (según create_db.py, postgres:erp3_pass_2026 suele funcionar)
    from sqlalchemy import create_engine
    super_url = "postgresql+psycopg2://postgres:erp3_pass_2026@localhost/erp3_db"
    engine = create_engine(super_url)
    from sqlalchemy.orm import sessionmaker
    SessionSuper = sessionmaker(bind=engine)
    db = SessionSuper()
    # IMPORTANTE: Permitir consultas sin tenant para tablas globales como Usuario
    db.info['allow_no_tenant'] = True 
    
    try:
        # Seleccionar columnas específicas para evitar errores con columnas faltantes en BD
        # Asumo que estas columnas básicas existen
        stmt = select(Usuario.id, Usuario.email, Usuario.role, Usuario.is_active).where(
            (Usuario.role.in_(['DEVELOPER', 'SUPERADMIN', 'ADMIN'])) |
            (Usuario.email.ilike('%dev%')) |
            (Usuario.email.ilike('%admin%'))
        )
        
        # Al seleccionar columnas individuales, el resultado es una lista de Row, no de objetos Usuario
        result = db.execute(stmt).all()

        if not result:
            print("No se encontraron usuarios DEV/ADMIN con los filtros específicos.")
            print("Listando TODOS los usuarios (columnas básicas):")
            stmt_all = select(Usuario.id, Usuario.email, Usuario.role, Usuario.is_active)
            all_users = db.execute(stmt_all).all()
            for row in all_users:
                 print(f"ID: {row.id} | Email: {row.email} | Role: {row.role} | Active: {row.is_active}")
            return

        print(f"Se encontraron {len(result)} usuarios potenciales de DEV/ADMIN:")
        for row in result:
            print(f"ID: {row.id}")
            print(f"Email: {row.email}")
            print(f"Role: {row.role}")
            print(f"Active: {row.is_active}")
            print("-" * 20)
            
    except Exception as e:
        print(f"Error al consultar la base de datos: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    find_dev_users()
