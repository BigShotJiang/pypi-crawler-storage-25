import sys
import os
import random
import string
import logging
from datetime import datetime

# Disable SQLAlchemy logs
logging.basicConfig()
logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import SessionLocal
from app.core_modules.ventas.models import (
    Venta,
    DetalleVenta,
    Producto,
    Cliente,
    EstadoVentaEnum,
)
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
)
from app.core_modules.crm.models import Notification
from app.core_modules.ventas.inventory_service import InventoryService

# Setup DB
db = SessionLocal()


def random_string(length=10):
    return "".join(random.choices(string.ascii_letters, k=length))


def run_notification_test():
    print("=== INICIANDO TEST DE NOTIFICACIONES PROACTIVAS (FIFO) ===")

    # 1. Setup Data
    print("1. Creando Jerarquía de Usuarios (Supervisor -> Vendedor)...")
    empresa = Empresa(
        nombre=f"Notif Test Corp {random_string()}",
        rut=f"66.{random.randint(100, 999)}.{random.randint(100, 999)}-6",
        codigo=f"NOTIF_{random_string(4)}",
    )
    db.add(empresa)
    db.flush()

    # Supervisor
    supervisor = Usuario(
        email=f"jefe_{random_string()}@test.com", hashed_password="hash", role="ADMIN"
    )
    db.add(supervisor)
    db.flush()

    # Vendedor (con supervisor asignado)
    vendedor = Usuario(
        email=f"vendedor_{random_string()}@test.com",
        hashed_password="hash",
        role="USER",
        supervisor_id=supervisor.id,
    )
    db.add(vendedor)
    db.flush()

    print(f"   -> Supervisor ID: {supervisor.id} ({supervisor.email})")
    print(
        f"   -> Vendedor ID: {vendedor.id} ({vendedor.email}) - Supervisor asignado: {vendedor.supervisor_id}"
    )

    # Infraestructura
    sucursal = Sucursal(
        nombre="Sucursal Notif", direccion="Calle Notif 123", empresa_id=empresa.id
    )
    db.add(sucursal)
    db.flush()

    bodega = Bodega(nombre="Bodega Notif", sucursal_id=sucursal.id)
    db.add(bodega)
    db.flush()

    producto = Producto(
        nombre="Producto Notificable",
        sku=f"SKU-NOTIF-{random_string(4)}",
        precio=5000,
        tipo_producto="ALMACENABLE",
        empresa_id=empresa.id,
    )
    db.add(producto)
    db.flush()

    cliente = Cliente(nombre="Cliente Notif", empresa_id=empresa.id)
    db.add(cliente)
    db.flush()

    # 2. Crear Venta en Espera
    print("\n2. Creando Venta en PENDIENTE_SIN_STOCK...")
    venta = Venta(
        fecha=datetime.now(),
        folio="V-NOTIF-001",
        total=5000,
        cliente_id=cliente.id,
        sucursal_id=sucursal.id,
        vendedor_id=vendedor.id,
        empresa_id=empresa.id,
        estado=EstadoVentaEnum.PENDIENTE_SIN_STOCK,
    )
    db.add(venta)
    db.flush()

    detalle = DetalleVenta(
        venta_id=venta.id,
        producto_id=producto.id,
        cantidad=1,
        precio_unitario=5000,
        subtotal=5000,
    )
    db.add(detalle)
    db.commit()

    print(f"   -> Venta creada ID: {venta.id}")

    # 3. Disparar Trigger FIFO (Entrada Stock)
    print("\n3. Ingresando Stock para disparar Trigger FIFO...")
    InventoryService.add_stock(db, producto.id, bodega.id, 10, "COMPRA", empresa.id)
    print("   -> Stock ingresado y procesado.")

    # 4. Verificar Notificaciones
    print("\n4. Verificando Tabla de Notificaciones...")

    # Check Notificacion Vendedor
    notif_v = (
        db.query(Notification)
        .filter(Notification.usuario_id == vendedor.id)
        .order_by(Notification.id.desc())
        .first()
    )
    if notif_v:
        print(f"   ✅ Vendedor notificado: '{notif_v.mensaje}' (ID: {notif_v.id})")
        # Validate content
        if "V-NOTIF-001" in notif_v.mensaje and "Cliente Notif" in notif_v.mensaje:
            print("      -> Contenido correcto: Incluye Folio y Cliente.")
        else:
            print(
                "      -> ❌ WARNING: Mensaje incompleto. Esperado Folio 'V-NOTIF-001' y Cliente 'Cliente Notif'."
            )
    else:
        print("   ❌ ERROR: Vendedor NO recibió notificación.")

    # Check Notificacion Supervisor
    notif_s = (
        db.query(Notification)
        .filter(Notification.usuario_id == supervisor.id)
        .order_by(Notification.id.desc())
        .first()
    )
    if notif_s:
        print(f"   ✅ Supervisor notificado: '{notif_s.mensaje}' (ID: {notif_s.id})")
        # Validate content
        if "V-NOTIF-001" in notif_s.mensaje and "Cliente Notif" in notif_s.mensaje:
            print("      -> Contenido correcto: Incluye Folio y Cliente.")
        else:
            print(
                "      -> ❌ WARNING: Mensaje incompleto. Esperado Folio 'V-NOTIF-001' y Cliente 'Cliente Notif'."
            )

        if notif_s.jefe_id == vendedor.id:
            print(
                "      -> Referencia 'jefe_id' correcta (apunta al vendedor subordinado)."
            )
        else:
            print(
                f"      -> WARNING: 'jefe_id' incorrecto: {notif_s.jefe_id} (Esperado: {vendedor.id})"
            )
    else:
        print("   ❌ ERROR: Supervisor NO recibió notificación.")


if __name__ == "__main__":
    try:
        run_notification_test()
    except Exception as e:
        print(f"❌ CRITICAL ERROR: {e}")
        import traceback

        traceback.print_exc()
