import sys
import os

# Add backend to path to import app modules
sys.path.append(os.getcwd())

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Usuario, Empresa, UsuarioEmpresa, Rol
from app.core.security import get_password_hash


def seed():
    db = SessionLocal()
    try:
        # Check if data exists
        # if db.query(Usuario).filter(Usuario.email == "admin@erp3.com").first():
        #    print("⚠️ Usuario admin@erp3.com ya existe.")
        #    return

        print("🌱 Verificando/Creando datos semilla...")

        # 1. Empresa
        # Verificar si existe empresa con codigo MAIN
        empresa = db.query(Empresa).filter(Empresa.codigo == "MAIN").first()
        if not empresa:
            empresa = Empresa(
                nombre="Empresa Principal",
                rut="11.111.111-1",
                codigo="MAIN",
                modulos_activos=[
                    "CORE",
                    "FINANZAS",
                    "RRHH",
                    "SISTEMA",
                    "TI",
                    "VENTAS",
                    "LAVANDERIA",
                ],
            )
            db.add(empresa)
            db.commit()
            db.refresh(empresa)
            print(f"✅ Empresa creada: {empresa.nombre} (ID: {empresa.id})")
        else:
            print(f"ℹ️ Empresa existente: {empresa.nombre}")

        # 1.b Seed default roles for empresa
        existing_roles = {
            r.codigo for r in db.query(Rol).filter(Rol.empresa_id == empresa.id).all()
        }
        default_roles = [
            ("ADM", "Administrador Único de Empresa"),
            ("SUP", "Supervisor"),
            ("VEN", "Vendedor"),
            ("BOD", "Bodeguero"),
            ("CON", "Contador"),
        ]
        for codigo, nombre in default_roles:
            if codigo in existing_roles:
                continue
            rol = Rol(
                empresa_id=empresa.id,
                codigo=codigo,
                nombre=nombre,
                is_active=True,
            )
            db.add(rol)
        db.commit()

        # 2. Usuario Admin (SaaS Client Admin)
        if not db.query(Usuario).filter(Usuario.email == "admin@erp3.com").first():
            user = Usuario(
                email="admin@erp3.com",
                hashed_password=get_password_hash("admin123"),
                is_active=True,
                role="ADMIN",
                # nombre="Administrador Cliente" # REMOVED: Field does not exist in Model
            )
            db.add(user)
            db.commit()
            db.refresh(user)
            print(f"✅ Usuario Cliente creado: {user.email} (Pass: admin123)")

            # Link to Empresa as ADM
            rol_adm = (
                db.query(Rol)
                .filter(Rol.empresa_id == empresa.id, Rol.codigo == "ADM")
                .first()
            )
            link = UsuarioEmpresa(
                usuario_id=user.id,
                empresa_id=empresa.id,
                rol_id=rol_adm.id if rol_adm else None,
                is_default=True,
            )
            db.add(link)
            db.commit()

        # 3. Usuario Developer (Super Admin / Dev)
        if not db.query(Usuario).filter(Usuario.email == "dev@erp3.com").first():
            dev_user = Usuario(
                email="dev@erp3.com",
                hashed_password=get_password_hash("dev123"),
                is_active=True,
                role="DEVELOPER",
                # nombre="Desarrollador Principal" # REMOVED: Field does not exist in Model
            )
            db.add(dev_user)
            db.commit()
            db.refresh(dev_user)
            print(f"✅ Usuario Developer creado: {dev_user.email} (Pass: dev123)")

            # Link Developer to MAIN empresa too (optional, but good for testing)
            dev_link = UsuarioEmpresa(
                usuario_id=dev_user.id, empresa_id=empresa.id, is_default=True
            )
            db.add(dev_link)
            db.commit()

    except Exception as e:
        print(f"❌ Error seeding data: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    seed()
