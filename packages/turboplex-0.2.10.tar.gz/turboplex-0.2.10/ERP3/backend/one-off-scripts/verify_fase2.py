import sys
import os

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

try:
    print("Verifying CRM API...")
    from app.core_modules.crm import api as crm_api
    from app.core_modules.crm import schemas as crm_schemas

    print("CRM API and Schemas imported.")

    print("Verifying Ventas Service modifications...")
    from app.core_modules.ventas import services as ventas_services
    import inspect

    # Check create_venta signature
    sig = inspect.signature(ventas_services.create_venta)
    print(f"create_venta signature: {sig}")

    # Check release_stale_reservations existence
    if hasattr(ventas_services, "release_stale_reservations"):
        print("release_stale_reservations found.")
    else:
        print("ERROR: release_stale_reservations NOT found.")

    print("Verifying CRM Service Staleness Check...")
    from app.core_modules.crm.services import CRMService

    if hasattr(CRMService, "check_exchange_rate_staleness"):
        print("check_exchange_rate_staleness found.")
    else:
        print("ERROR: check_exchange_rate_staleness NOT found.")

    print("Verification Complete.")

except ImportError as e:
    print(f"ImportError: {e}")
except Exception as e:
    print(f"Error: {e}")
