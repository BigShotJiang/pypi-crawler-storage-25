import sys
import os

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

try:
    # Check InventoryService
    from app.core_modules.ventas.inventory_service import InventoryService

    print("InventoryService imported successfully")

    # Check CRMService signature
    from app.core_modules.crm.services import CRMService
    import inspect

    sig = inspect.signature(CRMService.convert_opportunity_to_sale)
    print(f"CRMService.convert_opportunity_to_sale signature: {sig}")

    if "substitutions" in sig.parameters:
        print("SUCCESS: substitutions parameter found")
    else:
        print("FAILURE: substitutions parameter missing")

    # Check Release Reservations
    from app.core_modules.ventas.services import release_stale_reservations

    sig_rel = inspect.signature(release_stale_reservations)
    print(f"release_stale_reservations signature: {sig_rel}")

    print("Verification Script Finished Successfully")

except ImportError as e:
    print(f"ImportError: {e}")
except Exception as e:
    print(f"Error: {e}")
