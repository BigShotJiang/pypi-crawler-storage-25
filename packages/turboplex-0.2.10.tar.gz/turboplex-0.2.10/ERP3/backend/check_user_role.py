from app.core.database import SessionLocal
from app.models import Usuario

db = SessionLocal()
user = db.query(Usuario).filter(Usuario.email == "multi@erp3.com").first()
if user:
    print(f"User: {user.email}, Role: {user.role}")
else:
    print("User not found")
db.close()
