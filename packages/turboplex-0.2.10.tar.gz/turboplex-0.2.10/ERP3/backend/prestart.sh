#! /usr/bin/env bash

# Let the DB start
python -c "import time; time.sleep(2)"

# Run migrations
echo "Running migrations..."
alembic upgrade head
echo "Migrations finished."
