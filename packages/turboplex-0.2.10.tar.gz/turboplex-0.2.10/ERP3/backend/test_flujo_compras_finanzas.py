import asyncio
from decimal import Decimal
from datetime import datetime

from app.core.database import SessionLocal
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
    Ubicacion,
)
from app.core_modules.compras.models import Proveedor, OrdenCompra, OrdenCompraDetalle
from app.core_modules.compras.services import recepcionar_orden
from app.core_modules.finanzas.models import (
    CuentaContable,
    AsientoContable,
)
from app.core_modules.finanzas.services import get_deuda_proveedor
from app.core_modules.ventas.models import Producto, InventarioUbicacion
from app.core_modules.compras import listeners as compras_listeners
from app.core_modules.finanzas import listeners as finanzas_listeners

# Register Listeners explicitly for this script execution
compras_listeners.register_listeners()
finanzas_listeners.register_listeners()


async def run_test():
    print("--- Iniciando Prueba de Integración Compras -> Finanzas ---")
    db = SessionLocal()
    try:
        # 1. Setup Context
        empresa = db.query(Empresa).filter(Empresa.codigo == "MAIN").first()
        if not empresa:
            empresa = db.query(Empresa).first()

        if not empresa:
            print("❌ No empresa found. Run seed_data.py first.")
            return

        sucursal = db.query(Sucursal).filter(Sucursal.empresa_id == empresa.id).first()
        if not sucursal:
            print("❌ No Sucursal found.")
            return

        bodega = db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
        if not bodega:
            # Create Bodega if missing
            bodega = Bodega(
                nombre="Bodega Test Finanzas",
                codigo="BOD-TEST-FIN",
                sucursal_id=sucursal.id,
            )
            db.add(bodega)
            db.commit()
            print("✅ Bodega creada on-the-fly.")

        usuario = db.query(Usuario).first()

        # Ensure Ubicacion exists for WMS test
        ubicacion = db.query(Ubicacion).filter(Ubicacion.bodega_id == bodega.id).first()
        if not ubicacion:
            ubicacion = Ubicacion(
                bodega_id=bodega.id,
                nombre="A-01-01",
                zona="A",
                pasillo="01",
                nivel="01",
                capacidad_maxima=100,
            )
            db.add(ubicacion)
            db.commit()
            print(f"✅ Ubicación creada: {ubicacion.nombre}")

        # 2. Ensure Accounting Accounts exist
        cuenta_existencias = (
            db.query(CuentaContable)
            .filter(CuentaContable.codigo == "1.1.03.01")
            .first()
        )
        if not cuenta_existencias:
            cuenta_existencias = CuentaContable(
                codigo="1.1.03.01",
                nombre="Existencias Materia Prima",
                tipo_cuenta="ACTIVO",
                nivel=4,
                empresa_id=empresa.id,
            )
            db.add(cuenta_existencias)

        cuenta_proveedores = (
            db.query(CuentaContable)
            .filter(CuentaContable.codigo == "2.1.01.01")
            .first()
        )
        if not cuenta_proveedores:
            cuenta_proveedores = CuentaContable(
                codigo="2.1.01.01",
                nombre="Proveedores Nacionales",
                tipo_cuenta="PASIVO",
                nivel=4,
                empresa_id=empresa.id,
            )
            db.add(cuenta_proveedores)

        db.commit()

        # 3. Create Test Provider
        rut_test = "88.888.888-8"
        proveedor = db.query(Proveedor).filter(Proveedor.rut == rut_test).first()
        if not proveedor:
            proveedor = Proveedor(
                nombre="Proveedor Test Finanzas",
                razon_social="Proveedor Test SpA",
                rut=rut_test,
                giro="Pruebas",
                direccion="Calle Falsa 123",
                plazo_pago_dias=30,
                empresa_id=empresa.id,
            )
            db.add(proveedor)
            db.commit()
            print(f"✅ Proveedor creado: {proveedor.nombre}")

        # 4. Create Test Product
        producto = db.query(Producto).filter(Producto.sku == "TEST-FIN-01").first()
        if not producto:
            producto = Producto(
                nombre="Producto Test Finanzas",
                sku="TEST-FIN-01",
                precio=1000,
                empresa_id=empresa.id,
            )
            db.add(producto)
            db.commit()
            print(f"✅ Producto creado: {producto.nombre}")

        # 5. Create Orden de Compra ($100,000 Total)
        # We want Total = 100,000.
        # Let's say we buy 10 units at 10,000 each.
        cantidad = 10
        precio_unitario = 10000
        total_oc = cantidad * precio_unitario  # 100,000

        oc = OrdenCompra(
            folio=f"OC-TEST-{int(datetime.now().timestamp())}",
            proveedor_id=proveedor.id,
            sucursal_id=sucursal.id,
            bodega_id=bodega.id,
            empresa_id=empresa.id,
            usuario_id=usuario.id,
            estado="ENVIADA",
            total_neto=total_oc,  # Simplification: Neto = Total for this test
            total=total_oc,
        )
        db.add(oc)
        db.commit()

        detalle = OrdenCompraDetalle(
            orden_compra_id=oc.id,
            producto_id=producto.id,
            cantidad=cantidad,
            precio_unitario=precio_unitario,
            subtotal=total_oc,
        )
        db.add(detalle)
        db.commit()
        print(f"✅ OC creada: {oc.folio} con Total ${oc.total}")

        # 6. Capture Initial State
        stock_inicial = 0
        inv_ubicacion = (
            db.query(InventarioUbicacion)
            .filter(
                InventarioUbicacion.ubicacion_id == ubicacion.id,
                InventarioUbicacion.producto_id == producto.id,
            )
            .first()
        )
        if inv_ubicacion:
            stock_inicial = inv_ubicacion.cantidad

        deuda_inicial = get_deuda_proveedor(db, rut_test)

        print(f"📊 Estado Inicial -> Stock: {stock_inicial}, Deuda: ${deuda_inicial}")

        # 7. Execute Recepcion
        print("🚀 Recepcionando Orden...")
        await recepcionar_orden(db, oc.id, ubicacion.id, usuario.id)

        # 8. Verify Results
        # Re-query DB to get fresh data
        db.expire_all()

        # Check Stock
        inv_ubicacion_final = (
            db.query(InventarioUbicacion)
            .filter(
                InventarioUbicacion.ubicacion_id == ubicacion.id,
                InventarioUbicacion.producto_id == producto.id,
            )
            .first()
        )
        stock_final = inv_ubicacion_final.cantidad if inv_ubicacion_final else 0

        # Check Debt
        deuda_final = get_deuda_proveedor(db, rut_test)

        print(f"📊 Estado Final   -> Stock: {stock_final}, Deuda: ${deuda_final}")

        # Assertions
        stock_esperado = stock_inicial + cantidad
        if stock_final == stock_esperado:
            print("✅ Verificación Stock: CORRECTO")
        else:
            print(
                f"❌ Verificación Stock: FALLÓ (Esperado {stock_esperado}, Actual {stock_final})"
            )

        deuda_esperada = deuda_inicial + Decimal(total_oc)
        if deuda_final == deuda_esperada:
            print("✅ Verificación Deuda: CORRECTO")
        else:
            print(
                f"❌ Verificación Deuda: FALLÓ (Esperado {deuda_esperada}, Actual {deuda_final})"
            )

        # Verify Accounting Entry details
        asiento = (
            db.query(AsientoContable)
            .filter(
                AsientoContable.origen_id == oc.id, AsientoContable.origen == "COMPRAS"
            )
            .first()
        )
        if asiento:
            print(f"✅ Asiento Contable generado ID: {asiento.id}")
            for mov in asiento.movimientos:
                tipo = mov.cuenta.tipo_cuenta
                print(
                    f"   - Cuenta: {mov.cuenta.nombre} ({mov.cuenta.codigo}) [{tipo}] | Debe: {mov.debe} | Haber: {mov.haber}"
                )
        else:
            print("❌ No se encontró Asiento Contable")

    except Exception as e:
        print(f"❌ Error en test: {e}")
        import traceback

        traceback.print_exc()
    finally:
        db.close()


if __name__ == "__main__":
    asyncio.run(run_test())
