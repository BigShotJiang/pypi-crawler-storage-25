import asyncio
import os
import sys
from unittest.mock import AsyncMock
import uuid

async def run_test():
    print("--- Test Webhooks Integration ---")
    backend_path = os.path.dirname(os.path.abspath(__file__))
    if backend_path not in sys.path:
        sys.path.append(backend_path)

    from app.core.database import SessionLocal, Base, engine
    from app.addons.webhooks.models import WebhookConfig
    from app.addons.webhooks import listeners
    from app.core.events import event_dispatcher
    from app.core_modules.sistema.models import Empresa

    mock_post = AsyncMock()
    mock_post.status_code = 200
    mock_post.text = "OK"

    class MockClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

        async def post(self, *args, **kwargs):
            return await mock_post(*args, **kwargs)

    listeners.httpx.AsyncClient = MockClient
    listeners.register_listeners()

    # 1. Create Webhook Config
    db = SessionLocal()
    # Ensure tables exist
    Base.metadata.create_all(bind=engine)
    db.info["allow_no_tenant"] = True
    code = f"WEBHOOK_{uuid.uuid4().hex[:8].upper()}"
    empresa = Empresa(
        nombre=f"Empresa {code}",
        codigo=code,
        rut=f"99999999-{code[-1]}",
        feature_flags={"webhooks": True},
    )
    db.add(empresa)
    db.commit()
    db.refresh(empresa)
    db.info.pop("allow_no_tenant", None)
    db.info["empresa_id"] = empresa.id

    event_name = "TEST_EVENT_WEBHOOK"
    url = "https://n8n.example.com/webhook/test"
    secret = "my_secret_key_123"

    # Clean previous
    db.query(WebhookConfig).filter(
        WebhookConfig.empresa_id == empresa.id, WebhookConfig.event_name == event_name
    ).delete()

    wh = WebhookConfig(
        empresa_id=empresa.id, event_name=event_name, url=url, secret_key=secret
    )
    db.add(wh)
    db.commit()
    print(f"✅ Webhook Config created for {event_name}")

    # 2. Dispatch Event
    event_data = {"empresa_id": str(empresa.id), "message": "Hello n8n", "value": 42}
    print(f"📡 Dispatching event: {event_name}")

    # We must ensure the event loop is running and tasks are scheduled
    await event_dispatcher.dispatch(event_name, event_data)

    # Allow async tasks (asyncio.gather) to complete
    # dispatch awaits gather, so it should be done when dispatch returns
    # But just in case of background tasks
    await asyncio.sleep(0.5)

    # 3. Verify
    if mock_post.called:
        args, kwargs = mock_post.call_args
        print("✅ Webhook triggered!")
        print(f"   URL: {args[0]}")

        headers = kwargs.get("headers", {})
        print(f"   Headers: {headers}")
        print(f"   Body: {kwargs.get('json')}")

        # Verify Headers
        if headers.get("X-ERP3-Secret") == secret:
            print("✅ Secret Key verified")
        else:
            print(f"❌ Secret Key missing or incorrect: {headers.get('X-ERP3-Secret')}")

        if headers.get("X-ERP3-Event") == event_name:
            print("✅ Event Name Header verified")
        else:
            print("❌ Event Name Header incorrect")

    else:
        print("❌ Webhook NOT triggered")

    # Cleanup
    db.query(WebhookConfig).filter(
        WebhookConfig.empresa_id == empresa.id, WebhookConfig.event_name == event_name
    ).delete()
    db.commit()
    db.close()


if __name__ == "__main__":
    asyncio.run(run_test())
