from fastapi.testclient import TestClient
from app.main import app
from app.core.exceptions import BusinessRuleError
from app.core.infrastructure.api_schemas import BaseResponse, MetaPayload


@app.get("/__test_business_error")
def raise_business_error():
    raise BusinessRuleError("Límite de crédito excedido para el cliente.")


def test_business_error_envelope_matches_success(client: TestClient):
    success_envelope = BaseResponse[dict](
        success=True,
        data={},
        error=None,
        meta=MetaPayload(request_id="test", duration_ms=0),
    ).model_dump()
    response = client.get("/__test_business_error")
    body = response.json()
    assert response.status_code == 400
    assert set(body.keys()) == set(success_envelope.keys())
    assert body["success"] is False
    assert body["data"] is None
    assert body["error"]["code"] == "CREDIT_LIMIT_EXCEEDED"
    assert isinstance(body["meta"]["request_id"], str)
    assert isinstance(body["meta"]["duration_ms"], int)
    assert body["meta"]["duration_ms"] >= 0

