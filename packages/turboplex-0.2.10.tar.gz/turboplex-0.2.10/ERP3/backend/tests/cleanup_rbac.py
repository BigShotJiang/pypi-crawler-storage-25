import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from app.core.database import SessionLocal
from app.models import Usuario, Empresa, Empleado, UsuarioEmpresa


def cleanup():
    db = SessionLocal()
    try:
        print("Cleaning up RBAC test data...")
        empresa = db.query(Empresa).filter(Empresa.codigo == "TEST_RBAC").first()
        if empresa:
            # Delete employees
            db.query(Empleado).filter(Empleado.empresa_id == empresa.id).delete()

            # Delete association
            db.query(UsuarioEmpresa).filter(
                UsuarioEmpresa.empresa_id == empresa.id
            ).delete()

            # Delete company
            db.delete(empresa)
            db.commit()
            print("Company and related data deleted.")

        # Delete users
        emails = ["rrhh@test.com", "ti@test.com", "user@test.com", "super@test.com"]
        db.query(Usuario).filter(Usuario.email.in_(emails)).delete(
            synchronize_session=False
        )
        db.commit()
        print("Users deleted.")

    except Exception as e:
        print(f"Error cleaning up: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    cleanup()
