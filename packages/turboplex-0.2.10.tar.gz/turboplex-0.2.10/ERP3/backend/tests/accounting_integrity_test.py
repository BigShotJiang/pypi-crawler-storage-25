from decimal import Decimal
from typing import List, Tuple, Dict
from collections import defaultdict

import pytest

from app.core.database import SessionLocal
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
    UsuarioEmpresa,
)
from app.core_modules.finanzas.models import (
    AsientoContable,
    MovimientoContable,
)
from app.core_modules.finanzas.accounting_service import (
    init_pcu_chileno,
    get_cuenta_by_codigo,
)
from app.core_modules.ventas.models import Producto, Cliente, Venta
from app.core_modules.inventario.models import Inventario
from app.core_modules.inventario.stock.services.variants import resolve_or_create_variant_id
from app.core_modules.ventas.schemas import VentaCreate, DetalleVentaCreate
from app.core_modules.ventas import services as ventas_services


IVA_RATE = Decimal("0.19")
SALES_COUNT = 10


def setup_company_with_pcu() -> Tuple:
    session = SessionLocal()
    session.info["allow_no_tenant"] = True
    try:
        company = (
            session.query(Empresa).filter(Empresa.codigo == "ACCT_INTEGRITY").first()
        )
        if not company:
            company = Empresa(nombre="Accounting Integrity Co", codigo="ACCT_INTEGRITY")
            session.add(company)
            session.commit()
            session.refresh(company)

        user = session.query(Usuario).filter(Usuario.email == "acct@test.local").first()
        if not user:
            user = Usuario(
                email="acct@test.local", hashed_password="acct", is_active=True
            )
            session.add(user)
            session.commit()
            session.refresh(user)

        link = (
            session.query(UsuarioEmpresa)
            .filter(
                UsuarioEmpresa.usuario_id == user.id,
                UsuarioEmpresa.empresa_id == company.id,
            )
            .first()
        )
        if not link:
            link = UsuarioEmpresa(
                usuario_id=user.id, empresa_id=company.id, is_default=True
            )
            session.add(link)
            session.commit()

        sucursal = (
            session.query(Sucursal)
            .filter(
                Sucursal.nombre == "Sucursal ACCT", Sucursal.empresa_id == company.id
            )
            .first()
        )
        if not sucursal:
            sucursal = Sucursal(nombre="Sucursal ACCT", empresa_id=company.id)
            session.add(sucursal)
            session.commit()
            session.refresh(sucursal)

        bodega = session.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
        if not bodega:
            bodega = Bodega(nombre="Bodega ACCT", sucursal_id=sucursal.id)
            session.add(bodega)
            session.commit()
            session.refresh(bodega)

        producto = (
            session.query(Producto)
            .filter(Producto.sku == "SKU-ACCT", Producto.empresa_id == company.id)
            .first()
        )
        if not producto:
            producto = Producto(
                nombre="Producto Contable",
                sku="SKU-ACCT",
                precio=Decimal("119.00"),
                costo_promedio=Decimal("70.00"),
                empresa_id=company.id,
                tipo_producto="ALMACENABLE",
                is_active=True,
            )
            session.add(producto)
            session.commit()
            session.refresh(producto)

        variant_id = resolve_or_create_variant_id(
            session,
            producto_id=producto.id,
            empresa_id=company.id,
            attributes={},
        )
        inventario = (
            session.query(Inventario)
            .filter(
                Inventario.empresa_id == company.id,
                Inventario.producto_id == producto.id,
                Inventario.variant_id == variant_id,
                Inventario.bodega_id == bodega.id,
            )
            .first()
        )
        if not inventario:
            inventario = Inventario(
                empresa_id=company.id,
                producto_id=producto.id,
                variant_id=variant_id,
                bodega_id=bodega.id,
                cantidad=SALES_COUNT,
                cantidad_reservada=0,
            )
        else:
            inventario.empresa_id = company.id
            inventario.variant_id = variant_id
            inventario.cantidad = SALES_COUNT
            inventario.cantidad_reservada = 0
        session.add(inventario)

        cliente = (
            session.query(Cliente)
            .filter(Cliente.nombre == "Cliente ACCT", Cliente.empresa_id == company.id)
            .first()
        )
        if not cliente:
            cliente = Cliente(nombre="Cliente ACCT", empresa_id=company.id)
            session.add(cliente)
            session.commit()
            session.refresh(cliente)

        # Plan de Cuentas
        init_pcu_chileno(session, empresa_id=company.id)

        session.commit()
        return company.id, user.id, sucursal.id, producto.id, cliente.id
    finally:
        session.close()


def create_sale(db_session, company_id, user_id, sucursal_id, producto_id, cliente_id):
    venta_in = VentaCreate(
        cliente_id=cliente_id,
        sucursal_id=sucursal_id,
        detalles=[
            DetalleVentaCreate(
                producto_id=producto_id,
                cantidad=1,
                es_servicio=False,
            )
        ],
        orden_servicio=None,
    )
    venta = ventas_services.create_venta(
        db=db_session,
        venta_in=venta_in,
        usuario_id=user_id,
        empresa_id=company_id,
    )
    db_session.refresh(venta)
    return venta


@pytest.mark.asyncio
async def test_accounting_integrity_sales_and_ledger():
    company_id, user_id, sucursal_id, producto_id, cliente_id = setup_company_with_pcu()

    db = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        # Limpiar ventas previas de esta empresa para el conteo del test
        ventas_before = db.query(Venta).filter(Venta.empresa_id == company_id).count()

        # Ejecutar 10 ventas
        venta_ids: List = []
        for _ in range(SALES_COUNT):
            v = create_sale(
                db, company_id, user_id, sucursal_id, producto_id, cliente_id
            )
            venta_ids.append(v.id)

        # Validación 0: cantidad de ventas nuevas
        ventas_after = db.query(Venta).filter(Venta.empresa_id == company_id).count()
        assert ventas_after - ventas_before == SALES_COUNT

        # Códigos de cuentas relevantes
        cuenta_caja = get_cuenta_by_codigo(db, "1.1.01.01", company_id)  # Caja
        cuenta_iva_df = get_cuenta_by_codigo(
            db, "2.1.02.01", company_id
        )  # IVA Débito Fiscal
        cuenta_ventas = get_cuenta_by_codigo(db, "4.1.01.01", company_id)  # Ventas
        cuenta_existencias = get_cuenta_by_codigo(
            db, "1.1.03.01", company_id
        )  # Mercaderías
        cuenta_costo = get_cuenta_by_codigo(db, "5.1.01", company_id)  # Costo de Ventas

        assert cuenta_caja and cuenta_iva_df and cuenta_ventas

        # Recoger asientos de las ventas creadas
        venta_ids_str = [str(v) for v in venta_ids]
        asientos = (
            db.query(AsientoContable)
            .filter(
                AsientoContable.origen == "VENTAS",
                AsientoContable.empresa_id == company_id,
                AsientoContable.origen_id.in_(venta_ids_str),
            )
            .all()
        )
        assert len(asientos) == SALES_COUNT

        # Índices de movimientos por asiento
        movimientos = (
            db.query(MovimientoContable)
            .filter(MovimientoContable.asiento_id.in_([a.id for a in asientos]))
            .all()
        )

        {a.id: a for a in asientos}
        movs_por_asiento: Dict = defaultdict(list)
        for m in movimientos:
            movs_por_asiento[m.asiento_id].append(m)

        for asiento in asientos:
            movs = movs_por_asiento.get(asiento.id, [])
            assert any(m.cuenta_id == cuenta_caja.id and m.debe > 0 for m in movs), (
                "Falta movimiento de Caja (Debe)"
            )
            assert any(m.cuenta_id == cuenta_iva_df.id and m.haber > 0 for m in movs), (
                "Falta movimiento IVA DF (Haber)"
            )
            assert any(m.cuenta_id == cuenta_ventas.id and m.haber > 0 for m in movs), (
                "Falta movimiento Ventas (Haber)"
            )
            assert cuenta_existencias and cuenta_costo
            deb_cogs = sum(m.debe for m in movs if m.cuenta_id == cuenta_costo.id)
            hab_inv = sum(m.haber for m in movs if m.cuenta_id == cuenta_existencias.id)
            assert deb_cogs > 0 and hab_inv > 0, (
                "Faltan movimientos de costo e inventario"
            )
            assert deb_cogs == hab_inv, "Costo vs Inventario desbalanceado en asiento"

        costo_unitario = Decimal("70.00")
        expected_total_costo = costo_unitario * SALES_COUNT

        total_costo_debe = sum(
            m.debe for m in movimientos if m.cuenta_id == cuenta_costo.id
        )
        total_existencias_haber = sum(
            m.haber for m in movimientos if m.cuenta_id == cuenta_existencias.id
        )
        assert round(total_costo_debe, 2) == round(expected_total_costo, 2)
        assert total_costo_debe == total_existencias_haber

        # Validación 2: Partida Doble global (debe == haber)
        total_debe = sum(m.debe for m in movimientos)
        total_haber = sum(m.haber for m in movimientos)
        assert round(total_debe - total_haber, 2) == Decimal("0.00")

        # Validación 3: Consistencia en cuenta Ventas = suma(neto) de las 10 ventas
        ventas_objs = db.query(Venta).filter(Venta.id.in_(venta_ids)).all()
        expected_ventas_total = Decimal("0.00")
        for v in ventas_objs:
            total_dec = Decimal(str(v.total))
            neto = total_dec / (Decimal("1") + IVA_RATE)
            neto = round(neto, 2)
            expected_ventas_total += neto
        # Suma de movimientos en cuenta Ventas (haber)
        ventas_mov_sum = sum(
            m.haber for m in movimientos if m.cuenta_id == cuenta_ventas.id
        )
        assert round(ventas_mov_sum, 2) == round(expected_ventas_total, 2)

        # Reporte: Balance de Comprobación rápido (cuentas clave)
        balance: Dict[str, Decimal] = defaultdict(Decimal)
        cuentas_map = {
            cuenta_caja.id: "Caja 1.1.01.01",
            cuenta_iva_df.id: "IVA Débito 2.1.02.01",
            cuenta_ventas.id: "Ventas 4.1.01.01",
        }
        if cuenta_existencias:
            cuentas_map[cuenta_existencias.id] = "Existencias 1.1.03.01"
        if cuenta_costo:
            cuentas_map[cuenta_costo.id] = "Costo de Ventas 5.1.01"

        for m in movimientos:
            nombre = cuentas_map.get(m.cuenta_id, None)
            if not nombre:
                continue
            balance[nombre] += Decimal(str(m.debe)) - Decimal(str(m.haber))

        print("\n[Balance de Comprobación - Test]")
        for nombre, saldo in balance.items():
            print(f"  {nombre:<30} saldo: {saldo:>10.2f}")
        print(f"  {'Total Debe':<30} {total_debe:>10.2f}")
        print(f"  {'Total Haber':<30} {total_haber:>10.2f}")
        print(f"  {'Diferencia (Debe-Haber)':<30} {(total_debe - total_haber):>10.2f}")
    finally:
        db.close()
