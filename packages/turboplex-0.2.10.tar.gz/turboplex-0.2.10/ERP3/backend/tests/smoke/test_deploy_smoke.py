import os
import pytest
from sqlalchemy import create_engine, text


SMOKE_DB_URL = os.environ.get("DEPLOY_SMOKE_DB_URL")


@pytest.mark.skipif(
    not SMOKE_DB_URL, reason="DEPLOY_SMOKE_DB_URL no definido; smoke test deshabilitado"
)
def test_deploy_db_has_core_tables():
    engine = create_engine(SMOKE_DB_URL)
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
        rows = conn.execute(
            text(
                """
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema='public' 
                  AND table_name = ANY(:names)
                """
            ),
            {"names": ["empresas", "usuarios", "roles"]},
        ).fetchall()
        found = {r[0] for r in rows}
        assert {"empresas", "usuarios", "roles"}.issubset(found)
