from datetime import datetime
from decimal import Decimal
from app.core_modules.finanzas import accounting_service, models as fin_models
from app.core_modules.sistema.models import Empresa, Usuario, Sucursal


def test_fiscal_year_close_logic(db):
    """
    Verifica que los saldos de Activo/Pasivo se arrastren al año siguiente (Saldo Anterior),
    mientras que las cuentas de Resultado (Ingresos/Gastos) empiecen en 0.
    """
    # 0. Setup User
    usuario = Usuario(email="test@accounting.cl", hashed_password="pw", role="ADMIN")
    db.add(usuario)
    db.flush()

    # 1. Setup Company
    empresa = Empresa(
        rut="99999999-9", nombre="Test Accounting Corp", codigo="TEST_ACC"
    )
    db.add(empresa)
    db.flush()

    # 2. Setup Sucursal
    sucursal = Sucursal(nombre="Casa Matriz", codigo="SUC-01", empresa_id=empresa.id)
    db.add(sucursal)
    db.commit()  # Commit to get IDs

    # 3. Init PCU
    accounting_service.init_pcu_chileno(db, empresa.id)

    # Get Accounts
    caja = accounting_service.get_cuenta_by_codigo(
        db, "1.1.01.01", empresa.id
    )  # Activo
    gasto = accounting_service.get_cuenta_by_codigo(db, "5.2.06", empresa.id)  # Gasto
    capital = accounting_service.get_cuenta_by_codigo(
        db, "3.1.01", empresa.id
    )  # Patrimonio

    # 4. Create 2024 Movements
    # Asset: +1000
    # Equity: +1000
    asiento_2024 = fin_models.AsientoContable(
        fecha=datetime(2024, 6, 15),
        glosa="Aporte Capital 2024",
        origen="MANUAL",
        estado="CONFIRMADO",
        sucursal_id=sucursal.id,
        usuario_id=usuario.id,
        empresa_id=empresa.id,
    )
    db.add(asiento_2024)
    db.flush()

    db.add(
        fin_models.MovimientoContable(
            asiento_id=asiento_2024.id,
            empresa_id=empresa.id,
            cuenta_id=caja.id,
            debe=Decimal(1000),
            haber=0,
            sucursal_id=sucursal.id,
        )
    )
    db.add(
        fin_models.MovimientoContable(
            asiento_id=asiento_2024.id,
            empresa_id=empresa.id,
            cuenta_id=capital.id,
            debe=0,
            haber=Decimal(1000),
            sucursal_id=sucursal.id,
        )
    )

    # Expense: +200 (Paid from Caja)
    asiento_gasto_2024 = fin_models.AsientoContable(
        fecha=datetime(2024, 12, 20),
        glosa="Gasto 2024",
        origen="MANUAL",
        estado="CONFIRMADO",
        sucursal_id=sucursal.id,
        usuario_id=usuario.id,
        empresa_id=empresa.id,
    )
    db.add(asiento_gasto_2024)
    db.flush()

    db.add(
        fin_models.MovimientoContable(
            asiento_id=asiento_gasto_2024.id,
            empresa_id=empresa.id,
            cuenta_id=gasto.id,
            debe=Decimal(200),
            haber=0,
            sucursal_id=sucursal.id,
        )
    )
    db.add(
        fin_models.MovimientoContable(
            asiento_id=asiento_gasto_2024.id,
            empresa_id=empresa.id,
            cuenta_id=caja.id,
            debe=0,
            haber=Decimal(200),
            sucursal_id=sucursal.id,
        )
    )

    db.commit()

    # 4. Check Balance 2025
    balance_2025 = accounting_service.get_balance_general(db, empresa.id, 2025)

    # Map results by code
    balance_map = {item.cuenta_codigo: item for item in balance_2025}

    # 5. Assertions

    # Caja (Activo): Should have Opening Balance = 1000 - 200 = 800
    assert "1.1.01.01" in balance_map, "Caja deberia estar en el balance 2025"
    caja_2025 = balance_map["1.1.01.01"]
    assert caja_2025.saldo_anterior == Decimal(800), (
        f"Saldo anterior incorrecto: {caja_2025.saldo_anterior}"
    )
    assert caja_2025.debitos == 0  # No movement in 2025
    assert caja_2025.saldo_final == Decimal(800)

    # Capital (Patrimonio): Should have Opening Balance = 1000
    assert "3.1.01" in balance_map, "Capital deberia estar en el balance 2025"
    capital_2025 = balance_map["3.1.01"]
    assert capital_2025.saldo_anterior == Decimal(1000)

    # Gasto (Resultados): Should NOT be in balance or have 0 opening balance.
    assert "5.2.06" not in balance_map, "Gasto NO deberia aparecer en 2025 (saldo 0)"
