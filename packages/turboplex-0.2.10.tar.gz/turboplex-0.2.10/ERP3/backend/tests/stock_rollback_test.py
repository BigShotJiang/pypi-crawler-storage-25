import asyncio
import time
from decimal import Decimal
from typing import List, Tuple

import pytest

from app.core.database import SessionLocal
from app.core.exceptions import BusinessRuleError
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
    UsuarioEmpresa,
    AuditLog,
)
from app.core_modules.ventas.models import Producto, Cliente, Venta
from app.core_modules.inventario.models import Inventario
from app.core_modules.inventario.stock.services.variants import resolve_or_create_variant_id
from app.core_modules.ventas.schemas import VentaCreate, DetalleVentaCreate
from app.core_modules.ventas import services as ventas_services
from app.core_modules.finanzas.accounting_service import init_pcu_chileno


INITIAL_STOCK = 10
TOTAL_REQUESTS = 20


class TransactionCancelled(Exception):
    pass


def setup_rollback_context() -> Tuple:
    session = SessionLocal()
    session.info["allow_no_tenant"] = True
    try:
        company = (
            session.query(Empresa).filter(Empresa.codigo == "ROLLBACK_TEST").first()
        )
        if not company:
            company = Empresa(nombre="Rollback Test Company", codigo="ROLLBACK_TEST")
            session.add(company)
            session.commit()
            session.refresh(company)

        user = (
            session.query(Usuario)
            .filter(Usuario.email == "rollback_test@race.local")
            .first()
        )
        if not user:
            user = Usuario(
                email="rollback_test@race.local",
                hashed_password="rollback-hash",
                is_active=True,
            )
            session.add(user)
            session.commit()
            session.refresh(user)

        link = (
            session.query(UsuarioEmpresa)
            .filter(
                UsuarioEmpresa.usuario_id == user.id,
                UsuarioEmpresa.empresa_id == company.id,
            )
            .first()
        )
        if not link:
            link = UsuarioEmpresa(
                usuario_id=user.id,
                empresa_id=company.id,
                is_default=True,
            )
            session.add(link)
            session.commit()

        sucursal = (
            session.query(Sucursal)
            .filter(
                Sucursal.nombre == "Sucursal Rollback",
                Sucursal.empresa_id == company.id,
            )
            .first()
        )
        if not sucursal:
            sucursal = Sucursal(
                nombre="Sucursal Rollback",
                empresa_id=company.id,
            )
            session.add(sucursal)
            session.commit()
            session.refresh(sucursal)

        bodega = session.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
        if not bodega:
            bodega = Bodega(
                nombre="Bodega Rollback",
                sucursal_id=sucursal.id,
            )
            session.add(bodega)
            session.commit()
            session.refresh(bodega)

        producto = (
            session.query(Producto)
            .filter(
                Producto.sku == "SKU-ROLLBACK",
                Producto.empresa_id == company.id,
            )
            .first()
        )
        if not producto:
            producto = Producto(
                nombre="Producto Rollback",
                sku="SKU-ROLLBACK",
                precio=Decimal("100.00"),
                empresa_id=company.id,
                tipo_producto="ALMACENABLE",
                is_active=True,
            )
            session.add(producto)
            session.commit()
            session.refresh(producto)

        variant_id = resolve_or_create_variant_id(
            session,
            producto_id=producto.id,
            empresa_id=company.id,
            attributes={},
        )
        inventario = (
            session.query(Inventario)
            .filter(
                Inventario.empresa_id == company.id,
                Inventario.producto_id == producto.id,
                Inventario.variant_id == variant_id,
                Inventario.bodega_id == bodega.id,
            )
            .first()
        )
        if not inventario:
            inventario = Inventario(
                empresa_id=company.id,
                producto_id=producto.id,
                variant_id=variant_id,
                bodega_id=bodega.id,
                cantidad=INITIAL_STOCK,
                cantidad_reservada=0,
            )
        else:
            inventario.empresa_id = company.id
            inventario.variant_id = variant_id
            inventario.cantidad = INITIAL_STOCK
            inventario.cantidad_reservada = 0
        session.add(inventario)

        cliente = (
            session.query(Cliente)
            .filter(
                Cliente.nombre == "Cliente Rollback",
                Cliente.empresa_id == company.id,
            )
            .first()
        )
        if not cliente:
            cliente = Cliente(
                nombre="Cliente Rollback",
                empresa_id=company.id,
            )
            session.add(cliente)
            session.commit()
            session.refresh(cliente)

        init_pcu_chileno(session, empresa_id=company.id)

        session.commit()

        return company.id, user.id, sucursal.id, producto.id, cliente.id, bodega.id
    finally:
        session.close()


def should_cancel(index: int) -> bool:
    return index % 2 == 0


async def attempt_sale_with_rollback(
    index: int,
    company_id,
    user_id,
    sucursal_id,
    producto_id,
    cliente_id,
) -> Tuple[str, float]:
    start = time.perf_counter()

    def run_blocking() -> str:
        session = SessionLocal()
        session.info["allow_no_tenant"] = True
        try:
            venta_in = VentaCreate(
                cliente_id=cliente_id,
                sucursal_id=sucursal_id,
                folio=f"ROLLBACK-{index}",
                detalles=[
                    DetalleVentaCreate(
                        producto_id=producto_id,
                        cantidad=1,
                        es_servicio=False,
                    )
                ],
                orden_servicio=None,
            )

            original_commit = session.commit

            def commit_with_cancel():
                if should_cancel(index):
                    raise TransactionCancelled()
                return original_commit()

            session.commit = commit_with_cancel

            try:
                ventas_services.create_venta(
                    db=session,
                    venta_in=venta_in,
                    usuario_id=user_id,
                    empresa_id=company_id,
                )
                return "OK"
            except TransactionCancelled:
                session.rollback()
                return "CANCELLED"
            except BusinessRuleError:
                session.rollback()
                return "OUT_OF_STOCK"
            except Exception:
                session.rollback()
                return "ERROR"
            finally:
                session.commit = original_commit
        finally:
            session.close()

    status = await asyncio.to_thread(run_blocking)
    end = time.perf_counter()
    return status, end - start


@pytest.mark.asyncio
async def test_stock_rollback_concurrent_sales():
    (
        company_id,
        user_id,
        sucursal_id,
        producto_id,
        cliente_id,
        bodega_id,
    ) = setup_rollback_context()

    baseline_session = SessionLocal()
    baseline_session.info["allow_no_tenant"] = True
    try:
        ventas_before = (
            baseline_session.query(Venta).filter(Venta.empresa_id == company_id).count()
        )
    finally:
        baseline_session.close()

    tasks: List[asyncio.Task] = []
    for i in range(TOTAL_REQUESTS):
        tasks.append(
            asyncio.create_task(
                attempt_sale_with_rollback(
                    index=i,
                    company_id=company_id,
                    user_id=user_id,
                    sucursal_id=sucursal_id,
                    producto_id=producto_id,
                    cliente_id=cliente_id,
                )
            )
        )

    results = await asyncio.gather(*tasks)

    success_durations: List[float] = []
    cancelled_durations: List[float] = []
    out_of_stock_count = 0
    error_count = 0

    for status, duration in results:
        if status == "OK":
            success_durations.append(duration)
        elif status == "CANCELLED":
            cancelled_durations.append(duration)
        elif status == "OUT_OF_STOCK":
            out_of_stock_count += 1
        else:
            error_count += 1

    assert len(success_durations) == INITIAL_STOCK
    assert (
        len(cancelled_durations) + out_of_stock_count == TOTAL_REQUESTS - INITIAL_STOCK
    )
    assert error_count == 0

    verify_session = SessionLocal()
    verify_session.info["allow_no_tenant"] = True
    try:
        inventario = (
            verify_session.query(Inventario)
            .filter(
                Inventario.producto_id == producto_id,
                Inventario.bodega_id == bodega_id,
            )
            .first()
        )
        assert inventario is not None
        assert inventario.cantidad == 0

        ventas_after = (
            verify_session.query(Venta).filter(Venta.empresa_id == company_id).all()
        )
        assert len(ventas_after) - ventas_before == INITIAL_STOCK

        ventas_new = (
            verify_session.query(Venta)
            .filter(Venta.empresa_id == company_id)
            .order_by(Venta.fecha.desc())
            .limit(INITIAL_STOCK)
            .all()
        )

        venta_ids = [v.id for v in ventas_new]
        expected_resources = {f"Venta:{vid}" for vid in venta_ids}

        audit_logs = (
            verify_session.query(AuditLog)
            .filter(
                AuditLog.action == "VENTA_CONFIRMADA",
                AuditLog.resource.in_(list(expected_resources)),
            )
            .all()
        )
        assert len(audit_logs) == INITIAL_STOCK
    finally:
        verify_session.close()

    first_success = min(success_durations) if success_durations else 0.0
    delays = [d - first_success for d in cancelled_durations]
    avg_delay = sum(delays) / len(delays) if delays else 0.0
    max_delay = max(delays) if delays else 0.0

    print(
        f"\n[ROLLBACK] Éxitos: {len(success_durations)}, "
        f"canceladas antes de commit: {len(cancelled_durations)}, "
        f"out_of_stock: {out_of_stock_count}, errores: {error_count}"
    )
    print(
        f"[ROLLBACK] Promedio espera rechazo después del primer commit: {avg_delay:.4f}s, "
        f"máximo: {max_delay:.4f}s"
    )
