import os
import sys
import uuid
from datetime import datetime, timezone, timedelta
from typing import Generator

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text, event
import pytest
from sqlalchemy.orm import sessionmaker, Session
from dotenv import load_dotenv

from app.core.database import Base, get_db
import app.core.database as coredb
from app.core_modules.sistema import models as sistema_models
from app.core.config import settings
from app.core_modules.billing import models as billing_models
from app.core_modules.ventas import models as ventas_models
from app.core_modules.inventario import models as inventario_models
from app.addons.pos_retail import models as pos_retail_models
from app.addons.portal import models as portal_models
from app.core_modules.finanzas import models as finanzas_models
from app.core_modules.finanzas import models_rates as finanzas_rates_models
from app.core_modules.rrhh import models as rrhh_models
from app.core_modules.ti import models as ti_models
from app.core_modules.crm import models as crm_models
from app.core_modules.compras import models as compras_models
from app.core_modules.facturacion import models as facturacion_models
from app.core_modules.service_engine import models as service_engine_models
from app.addons.webhooks import models as webhooks_models
from app.core_modules.auditoria import models as auditoria_models
from app.models.staging import StagingImport

BACKEND_DIR = os.path.dirname(os.path.dirname(__file__))
load_dotenv(os.path.join(BACKEND_DIR, ".env"))

# Sanitizar variables no usadas por Settings estrictos en entorno de test
os.environ.pop("MIRROR_DATABASE_URL", None)
os.environ.setdefault("PGCLIENTENCODING", "UTF8")

_MODEL_REGISTRY = (
    sistema_models,
    billing_models,
    ventas_models,
    inventario_models,
    pos_retail_models,
    portal_models,
    finanzas_models,
    finanzas_rates_models,
    rrhh_models,
    ti_models,
    crm_models,
    compras_models,
    facturacion_models,
    service_engine_models,
    webhooks_models,
    auditoria_models,
    StagingImport,
)

TEST_TENANT_ID = os.getenv("TEST_TENANT_ID", "1")
TEST_DATABASE_NAME = os.getenv("TEST_DATABASE_NAME", "erp3_test")


TEST_DATABASE_URL = os.getenv(
    "TEST_DATABASE_URL",
    f"postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost/{TEST_DATABASE_NAME}",
)

print(f"DEBUG: TEST_DATABASE_URL={TEST_DATABASE_URL}")

os.environ["DATABASE_URL"] = TEST_DATABASE_URL

settings.DATABASE_URL = TEST_DATABASE_URL

engine = create_engine(
    TEST_DATABASE_URL,
    pool_pre_ping=True,
    connect_args={
        "options": "-c client_encoding=UTF8 -c statement_timeout=10000"
    },
    future=True,
)

TestingSessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=engine, future=True, expire_on_commit=False
)

with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
    try:
        conn.execute(
            text(
                "SELECT pg_terminate_backend(pid) "
                "FROM pg_stat_activity "
                "WHERE datname = current_database() AND pid <> pg_backend_pid();"
            )
        )
    except Exception:
        pass
    conn.execute(text("DROP SCHEMA IF EXISTS public CASCADE"))
    conn.execute(text("CREATE SCHEMA public"))
    conn.execute(text("CREATE SCHEMA IF NOT EXISTS crm"))

print(">>> creando esquema de test (Base.metadata.create_all)...")
Base.metadata.create_all(bind=engine)
print(">>> esquema de test creado")

with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
    print(">>> creando columnas bootstrap en empresas/clientes/usuarios_empresas...")
    conn.execute(text("SET lock_timeout = '2s'"))
    conn.execute(text("SET statement_timeout = '10s'"))
    conn.execute(
        text(
            "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT TRUE"
        )
    )
    conn.execute(
        text(
            "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS grace_period_days integer NOT NULL DEFAULT 5"
        )
    )
    conn.execute(
        text(
            'ALTER TABLE empresas ADD COLUMN IF NOT EXISTS modulos_activos json NOT NULL DEFAULT \'["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA"]\'::json'
        )
    )
    conn.execute(
        text(
            "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS pwr_bi_enabled boolean NOT NULL DEFAULT FALSE"
        )
    )
    conn.execute(
        text(
            "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS pwr_bi_config json DEFAULT '{}'::json"
        )
    )
    conn.execute(
        text(
            "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS limite_cupo_maximo numeric(14,2) NOT NULL DEFAULT 50000.00"
        )
    )
    conn.execute(
        text(
            "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS _limite_credito numeric(14,2)"
        )
    )
    conn.execute(
        text("ALTER TABLE usuarios_empresas ADD COLUMN IF NOT EXISTS rol_id uuid")
    )
    conn.execute(
        text(
            "ALTER TABLE asientos_contables ADD COLUMN IF NOT EXISTS metodo_pago varchar NULL"
        )
    )
    conn.execute(
        text(
            "ALTER TABLE empresas ADD COLUMN IF NOT EXISTS feature_flags json NOT NULL DEFAULT '{}'::json"
        )
    )

coredb.engine = engine
coredb.SessionLocal = TestingSessionLocal


def _ensure_active_subscription(session: Session, empresa: sistema_models.Empresa) -> None:
    plan = next(
        (
            obj
            for obj in session.new
            if isinstance(obj, billing_models.SubscriptionPlan) and obj.is_active
        ),
        None,
    )
    if not plan:
        plan = (
            session.query(billing_models.SubscriptionPlan)
            .filter(billing_models.SubscriptionPlan.is_active)
            .order_by(billing_models.SubscriptionPlan.price_clp.asc())
            .first()
        )
    if not plan:
        plan = billing_models.SubscriptionPlan(
            name="Starter", price_clp=0, user_limit=3, branch_limit=1, is_active=True
        )
        session.add(plan)

    existing = (
        session.query(billing_models.CompanySubscription)
        .filter(billing_models.CompanySubscription.empresa_id == empresa.id)
        .first()
    )
    if existing:
        return

    expires_at = datetime.now(timezone.utc) + timedelta(days=3650)
    subscription = billing_models.CompanySubscription(
        empresa_id=empresa.id, plan=plan, expires_at=expires_at
    )
    session.add(subscription)


@event.listens_for(Session, "after_flush")
def _auto_company_subscription(session: Session, flush_context) -> None:
    if session.info.get("creating_subscription"):
        prev_allow_no_tenant = session.info.pop("creating_subscription_prev_allow_no_tenant", None)
        if prev_allow_no_tenant is not None:
            session.info["allow_no_tenant"] = prev_allow_no_tenant
        session.info.pop("creating_subscription", None)
        return
    empresas = [obj for obj in session.new if isinstance(obj, sistema_models.Empresa)]
    if not empresas:
        return
    # Cambiar el contexto de tenant a la(s) nueva(s) empresa(s) creada(s)
    # para evitar conflictos de aislamiento al crear la suscripción inicial.
    prev_allow_no_tenant = session.info.get("allow_no_tenant", False)
    session.info["allow_no_tenant"] = True
    session.info["creating_subscription"] = True
    session.info["creating_subscription_prev_allow_no_tenant"] = prev_allow_no_tenant
    try:
        for empresa in empresas:
            session.info["empresa_id"] = empresa.id
            _ensure_active_subscription(session, empresa)
    finally:
        session.info["empresa_id"] = empresas[-1].id
        # Mantener el contexto en la última empresa creada para operaciones subsecuentes del test
        # (no restauramos prev_empresa para favorecer consistencia de tenant en el mismo flujo)


def _truncate_all_tables(conn):
    replication_role_set = False
    statement_timeout_set = False
    try:
        conn.execution_options(isolation_level="AUTOCOMMIT").execute(
            text("SET session_replication_role = 'replica';")
        )
        replication_role_set = True
    except Exception:
        replication_role_set = False
    try:
        conn.execution_options(isolation_level="AUTOCOMMIT").execute(
            text("SET statement_timeout = 0;")
        )
        statement_timeout_set = True
    except Exception:
        statement_timeout_set = False
    # Obtener listado de tablas del esquema público
    print(">>> truncando tablas del esquema public...")
    tables = conn.execute(
        text("""
        SELECT table_name FROM information_schema.tables 
        WHERE table_schema='public' AND table_type='BASE TABLE'
    """)
    ).fetchall()
    if tables:
        table_list = ", ".join(f'"public"."{t[0]}"' for t in tables)
        conn.execute(text(f"TRUNCATE {table_list} CASCADE;"))
    if replication_role_set:
        conn.execution_options(isolation_level="AUTOCOMMIT").execute(
            text("SET session_replication_role = 'origin';")
        )
    if statement_timeout_set:
        try:
            conn.execution_options(isolation_level="AUTOCOMMIT").execute(
                text("RESET statement_timeout;")
            )
        except Exception:
            pass
    print(">>> truncado OK")


@pytest.fixture(scope="function")
def setup_db():
    # Limpieza previa por si quedó basura de otro test
    with engine.connect() as conn:
        trans = conn.begin()
        try:
            _truncate_all_tables(conn)
            trans.commit()
        except Exception:
            trans.rollback()
            raise
    yield


@pytest.fixture(scope="function")
def db(setup_db):
    """
    Proporciona una sesión por test.
    Opción A: TRUNCATE al finalizar (robusto con sesiones externas).
    """
    connection = engine.connect()
    session = TestingSessionLocal(bind=connection)
    session.info["allow_no_tenant"] = True

    empresa = session.query(sistema_models.Empresa).first()
    if not empresa:
        suffix = str(uuid.uuid4())[:8]
        empresa = sistema_models.Empresa(nombre=f"Empresa Test {suffix}", codigo=f"TEST_{suffix}")
        session.add(empresa)
        session.commit()
        session.refresh(empresa)

    session.info["empresa_id"] = empresa.id
    session.info["allow_no_tenant"] = False

    yield session

    session.close()
    # Limpieza dura para siguientes tests
    trans = connection.begin()
    try:
        _truncate_all_tables(connection)
        trans.commit()
    except Exception:
        trans.rollback()
        raise
    finally:
        connection.close()


@pytest.fixture(scope="function")
def client(db) -> Generator:
    """
    Cliente de prueba FastAPI con la dependencia de BD sobrescrita.
    """
    from app.main import app as fastapi_app

    def override_get_db():
        try:
            yield db
        finally:
            pass

    fastapi_app.dependency_overrides[get_db] = override_get_db
    with TestClient(fastapi_app) as c:
        c.headers.update({"X-Tenant-Id": TEST_TENANT_ID})
        yield c
    fastapi_app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def cleanup_dependency_overrides():
    yield
    app_main = sys.modules.get("app.main")
    if app_main is not None and hasattr(app_main, "app"):
        app_main.app.dependency_overrides.clear()


def pytest_sessionfinish(session, exitstatus):
    if exitstatus != 0:
        return
    try:
        import os
        import subprocess
        from pathlib import Path

        repo_root = Path(BACKEND_DIR).parent
        script_path = repo_root / ".Documentacion" / "tools" / "generate_map.py"
        if not script_path.exists():
            return
        env = dict(os.environ)
        subprocess.run(
            [sys.executable, str(script_path)],
            cwd=str(repo_root),
            env=env,
            check=False,
        )
    except Exception:
        return
