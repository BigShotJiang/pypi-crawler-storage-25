import pytest
import asyncio
from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto
from app.core_modules.inventario.stock.services import InventoryService
from app.core_modules.finanzas import models as finanzas_models
from app.core_modules.finanzas import listeners as finanzas_listeners
from app.core_modules.sistema.models import Empresa, Bodega, Sucursal, Usuario
from decimal import Decimal
import uuid

@pytest.fixture(scope="module")
def db():
    session = SessionLocal()
    session.info["allow_no_tenant"] = True
    yield session
    session.close()

@pytest.fixture(scope="module")
def setup_data(db):
    suffix = str(uuid.uuid4())[:8]
    
    empresa = db.query(Empresa).filter(Empresa.rut.like(f"%{suffix}%")).first()
    if not empresa:
        empresa = Empresa(
            nombre=f"Empresa Integ {suffix}", 
            rut=f"888-{suffix}",
            codigo=f"EMP_{suffix}"
        )
        db.add(empresa)
        db.commit()

    sucursal = Sucursal(
        nombre=f"Sucursal Integ {suffix}", 
        empresa_id=empresa.id,
        direccion="Calle Test 123"
    )
    db.add(sucursal)
    db.commit()

    bodega = Bodega(
        nombre=f"Bodega Integ {suffix}",
        sucursal_id=sucursal.id
    )
    db.add(bodega)
    db.commit()
    db.refresh(bodega)

    usuario = Usuario(
        email=f"user_{suffix}@test.com",
        hashed_password="hashed_secret",
        is_active=True
    )
    db.add(usuario)
    db.commit()
    
    from app.core_modules.sistema.models import UsuarioEmpresa
    ue = UsuarioEmpresa(usuario_id=usuario.id, empresa_id=empresa.id, is_default=True)
    db.add(ue)
    db.commit()

    return {
        "empresa": empresa,
        "sucursal": sucursal,
        "bodega": bodega,
        "usuario": usuario,
        "suffix": suffix
    }

@pytest.mark.asyncio
async def test_merma_accounting_entry(db, setup_data):
    # Register listeners
    finanzas_listeners.register_listeners()
    
    # Setup data
    empresa = setup_data["empresa"]
    bodega = setup_data["bodega"]
    suffix = setup_data["suffix"]
    
    # Create Accounts (if not exist)
    cuenta_existencias = db.query(finanzas_models.CuentaContable).filter(
        finanzas_models.CuentaContable.codigo == "1.1.03.01",
        finanzas_models.CuentaContable.empresa_id == empresa.id
    ).first()
    
    if not cuenta_existencias:
        cuenta_existencias = finanzas_models.CuentaContable(
            codigo="1.1.03.01", nombre="Existencias", tipo_cuenta="ACTIVO", nivel=4, es_imputable=True, empresa_id=empresa.id
        )
        db.add(cuenta_existencias)

    cuenta_mermas = db.query(finanzas_models.CuentaContable).filter(
        finanzas_models.CuentaContable.codigo == "5.2.07",
        finanzas_models.CuentaContable.empresa_id == empresa.id
    ).first()
    
    if not cuenta_mermas:
        cuenta_mermas = finanzas_models.CuentaContable(
            codigo="5.2.07", nombre="Pérdida por Mermas", tipo_cuenta="GASTO", nivel=3, es_imputable=True, empresa_id=empresa.id
        )
        db.add(cuenta_mermas)
    
    db.commit()
    
    # Create Product
    producto = Producto(
        nombre=f"Prod Merma {suffix}",
        sku=f"MERMA_{suffix}",
        precio=500.0,
        empresa_id=empresa.id,
        tipo_producto="ALMACENABLE",
        costo_promedio=0
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)
    
    # Add initial stock (10 units @ 100)
    InventoryService.add_stock(
        db, producto.id, bodega.id, 10, "COMPRA", empresa.id, Decimal(100)
    )
    
    # Wait for async events (valuation)
    await asyncio.sleep(0.1)
    
    # Consume 2 units as MERMA
    # This should trigger EVENT_MOVIMIENTO_STOCK_REGISTRADO -> Listener -> Accounting Entry
    InventoryService.consume_stock(
        db, producto.id, bodega.id, 2, "MERMA", empresa.id
    )
    
    # Wait for async events (accounting)
    await asyncio.sleep(1.0)
    
    # Verify Accounting Entry
    # Need to query in a new transaction or refresh session to see changes committed by listener (which uses its own session)
    # But here we are sharing the same DB engine, so distinct sessions should see committed data.
    
    asiento = db.query(finanzas_models.AsientoContable).filter(
        finanzas_models.AsientoContable.glosa.like(f"%MERMA - Prod {producto.id}%"),
        finanzas_models.AsientoContable.empresa_id == empresa.id
    ).first()
    
    assert asiento is not None, "No se generó el asiento contable para la MERMA"
    assert asiento.empresa_id == empresa.id
    
    # Verify Movements
    movs = db.query(finanzas_models.MovimientoContable).filter(
        finanzas_models.MovimientoContable.asiento_id == asiento.id
    ).all()
    
    assert len(movs) == 2
    
    # Total Cost = 2 * 100 = 200
    total_cost = Decimal(200)
    
    # DEBE: Gasto (Mermas)
    debe = next((m for m in movs if m.cuenta_id == cuenta_mermas.id), None)
    assert debe is not None
    assert debe.debe == total_cost
    assert debe.haber == 0
    
    # HABER: Activo (Existencias)
    haber = next((m for m in movs if m.cuenta_id == cuenta_existencias.id), None)
    assert haber is not None
    assert haber.haber == total_cost
    assert haber.debe == 0

    print("✅ Test Integration Accounting-Stock Passed!")
