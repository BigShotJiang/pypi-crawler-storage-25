import asyncio
import time
from decimal import Decimal
from typing import List, Tuple

import pytest
from sqlalchemy.exc import TimeoutError as SATimeoutError, OperationalError

from app.core.database import SessionLocal
from app.core.exceptions import BusinessRuleError
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
    UsuarioEmpresa,
)
from app.core_modules.ventas.models import Producto, Cliente
from app.core_modules.inventario.models import Inventario
from app.core_modules.inventario.stock.services.variants import resolve_or_create_variant_id
from app.core_modules.ventas.schemas import VentaCreate, DetalleVentaCreate
from app.core_modules.ventas import services as ventas_services
from app.core_modules.finanzas.accounting_service import init_pcu_chileno


INITIAL_STOCK_PHASE1 = 1
CONCURRENT_REQUESTS_PHASE1 = 20
INITIAL_STOCK_PHASE2 = 100
TOTAL_SALES_PHASE2 = 1000


def setup_race_context(initial_stock: int, company_code: str, sku: str) -> Tuple:
    session = SessionLocal()
    session.info["allow_no_tenant"] = True
    try:
        company = session.query(Empresa).filter(Empresa.codigo == company_code).first()
        if not company:
            company = Empresa(nombre=company_code, codigo=company_code)
            session.add(company)
            session.commit()
            session.refresh(company)

        session.info["empresa_id"] = company.id
        session.info["allow_no_tenant"] = False

        user = (
            session.query(Usuario)
            .filter(Usuario.email == f"{company_code.lower()}@race.local")
            .first()
        )
        if not user:
            user = Usuario(
                email=f"{company_code.lower()}@race.local",
                hashed_password="race-hash",
                is_active=True,
            )
            session.add(user)
            session.commit()
            session.refresh(user)

        link = (
            session.query(UsuarioEmpresa)
            .filter(
                UsuarioEmpresa.usuario_id == user.id,
                UsuarioEmpresa.empresa_id == company.id,
            )
            .first()
        )
        if not link:
            link = UsuarioEmpresa(
                usuario_id=user.id,
                empresa_id=company.id,
                is_default=True,
            )
            session.add(link)
            session.commit()

        sucursal = (
            session.query(Sucursal)
            .filter(
                Sucursal.nombre == f"Sucursal {company_code}",
                Sucursal.empresa_id == company.id,
            )
            .first()
        )
        if not sucursal:
            sucursal = Sucursal(
                nombre=f"Sucursal {company_code}", empresa_id=company.id
            )
            session.add(sucursal)
            session.commit()
            session.refresh(sucursal)

        bodega = session.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
        if not bodega:
            bodega = Bodega(nombre=f"Bodega {company_code}", sucursal_id=sucursal.id)
            session.add(bodega)
            session.commit()
            session.refresh(bodega)

        producto = (
            session.query(Producto)
            .filter(
                Producto.sku == sku,
                Producto.empresa_id == company.id,
            )
            .first()
        )
        if not producto:
            producto = Producto(
                nombre=f"Producto {sku}",
                sku=sku,
                precio=Decimal("100.00"),
                empresa_id=company.id,
                tipo_producto="ALMACENABLE",
                is_active=True,
            )
            session.add(producto)
            session.commit()
            session.refresh(producto)

        variant_id = resolve_or_create_variant_id(
            session,
            producto_id=producto.id,
            empresa_id=company.id,
            attributes={},
        )
        inventario = (
            session.query(Inventario)
            .filter(
                Inventario.empresa_id == company.id,
                Inventario.producto_id == producto.id,
                Inventario.variant_id == variant_id,
                Inventario.bodega_id == bodega.id,
            )
            .first()
        )
        if not inventario:
            inventario = Inventario(
                empresa_id=company.id,
                producto_id=producto.id,
                variant_id=variant_id,
                bodega_id=bodega.id,
                cantidad=initial_stock,
                cantidad_reservada=0,
            )
        else:
            inventario.empresa_id = company.id
            inventario.variant_id = variant_id
            inventario.cantidad = initial_stock
            inventario.cantidad_reservada = 0
        session.add(inventario)

        cliente = (
            session.query(Cliente)
            .filter(
                Cliente.nombre == f"Cliente {company_code}",
                Cliente.empresa_id == company.id,
            )
            .first()
        )
        if not cliente:
            cliente = Cliente(nombre=f"Cliente {company_code}", empresa_id=company.id)
            session.add(cliente)
            session.commit()
            session.refresh(cliente)

        init_pcu_chileno(session, empresa_id=company.id)

        session.commit()

        return company.id, user.id, sucursal.id, producto.id, cliente.id, bodega.id
    finally:
        session.close()


async def attempt_sale(
    index: int,
    company_id,
    user_id,
    sucursal_id,
    producto_id,
    cliente_id,
) -> Tuple[str, float]:
    start = time.perf_counter()

    def run_blocking() -> str:
        session = SessionLocal()
        session.info["empresa_id"] = company_id
        session.info["allow_no_tenant"] = False
        try:
            venta_in = VentaCreate(
                cliente_id=cliente_id,
                sucursal_id=sucursal_id,
                folio=f"RACE-{index}",
                detalles=[
                    DetalleVentaCreate(
                        producto_id=producto_id,
                        cantidad=1,
                        es_servicio=False,
                    )
                ],
                orden_servicio=None,
            )
            try:
                ventas_services.create_venta(
                    db=session,
                    venta_in=venta_in,
                    usuario_id=user_id,
                    empresa_id=company_id,
                )
                return "OK"
            except BusinessRuleError:
                session.rollback()
                return "OUT_OF_STOCK"
            except (SATimeoutError, OperationalError):
                session.rollback()
                return "TIMEOUT"
            except Exception:
                session.rollback()
                return "ERROR"
        finally:
            session.close()

    status = await asyncio.to_thread(run_blocking)
    end = time.perf_counter()
    return status, end - start


@pytest.mark.asyncio
async def test_race_condition_single_unit():
    (
        company_id,
        user_id,
        sucursal_id,
        producto_id,
        cliente_id,
        bodega_id,
    ) = setup_race_context(
        INITIAL_STOCK_PHASE1,
        "RACE_PHASE1",
        "SKU-RACE-1",
    )

    tasks: List[asyncio.Task] = []
    for i in range(CONCURRENT_REQUESTS_PHASE1):
        tasks.append(
            asyncio.create_task(
                attempt_sale(
                    index=i,
                    company_id=company_id,
                    user_id=user_id,
                    sucursal_id=sucursal_id,
                    producto_id=producto_id,
                    cliente_id=cliente_id,
                )
            )
        )

    results = await asyncio.gather(*tasks)

    success_durations: List[float] = []
    fail_durations: List[float] = []
    timeout_count = 0
    error_count = 0

    for status, duration in results:
        if status == "OK":
            success_durations.append(duration)
        elif status == "OUT_OF_STOCK":
            fail_durations.append(duration)
        elif status == "TIMEOUT":
            timeout_count += 1
        else:
            error_count += 1

    assert len(success_durations) == 1
    assert len(fail_durations) + timeout_count == CONCURRENT_REQUESTS_PHASE1 - 1
    assert error_count == 0

    verify_session = SessionLocal()
    verify_session.info["empresa_id"] = company_id
    verify_session.info["allow_no_tenant"] = False
    try:
        inventario = (
            verify_session.query(Inventario)
            .filter(
                Inventario.producto_id == producto_id,
                Inventario.bodega_id == bodega_id,
            )
            .first()
        )
        assert inventario is not None
        assert inventario.cantidad == 0
    finally:
        verify_session.close()

    first_success = min(success_durations) if success_durations else 0.0
    delays = [d - first_success for d in fail_durations]
    avg_delay = sum(delays) / len(delays) if delays else 0.0
    max_delay = max(delays) if delays else 0.0

    print(
        f"\n[RACE P1] Éxitos: {len(success_durations)}, "
        f"fallos por stock: {len(fail_durations)}, errores: {error_count}"
    )
    print(
        f"[RACE P1] Promedio espera rechazo después del ganador: {avg_delay:.4f}s, "
        f"máximo: {max_delay:.4f}s"
    )


@pytest.mark.asyncio
async def test_race_condition_many_vs_stock():
    (
        company_id,
        user_id,
        sucursal_id,
        producto_id,
        cliente_id,
        bodega_id,
    ) = setup_race_context(
        INITIAL_STOCK_PHASE2,
        "RACE_PHASE2",
        "SKU-RACE-2",
    )

    tasks: List[asyncio.Task] = []
    for i in range(TOTAL_SALES_PHASE2):
        tasks.append(
            asyncio.create_task(
                attempt_sale(
                    index=i,
                    company_id=company_id,
                    user_id=user_id,
                    sucursal_id=sucursal_id,
                    producto_id=producto_id,
                    cliente_id=cliente_id,
                )
            )
        )

    results = await asyncio.gather(*tasks)

    success_count = 0
    fail_count = 0
    timeout_count = 0
    error_count = 0

    for status, _ in results:
        if status == "OK":
            success_count += 1
        elif status == "OUT_OF_STOCK":
            fail_count += 1
        elif status == "TIMEOUT":
            timeout_count += 1
        else:
            error_count += 1

    assert success_count <= INITIAL_STOCK_PHASE2
    assert success_count + fail_count + timeout_count == TOTAL_SALES_PHASE2
    assert error_count == 0

    verify_session = SessionLocal()
    verify_session.info["empresa_id"] = company_id
    verify_session.info["allow_no_tenant"] = False
    try:
        inventario = (
            verify_session.query(Inventario)
            .filter(
                Inventario.producto_id == producto_id,
                Inventario.bodega_id == bodega_id,
            )
            .first()
        )
        assert inventario is not None
        assert inventario.cantidad >= 0
        assert inventario.cantidad + success_count == INITIAL_STOCK_PHASE2
    finally:
        verify_session.close()
