import asyncio
import time
from decimal import Decimal
from typing import List, Tuple

import pytest
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.core.exceptions import BusinessRuleError
from app.core_modules.sistema.models import (
    Empresa,
    Sucursal,
    Bodega,
    Usuario,
    UsuarioEmpresa,
    AuditLog,
)
from app.core_modules.ventas.models import Producto, Cliente
from app.core_modules.inventario.models import Inventario
from app.core_modules.inventario.stock.services.variants import resolve_or_create_variant_id
from app.core_modules.ventas.schemas import VentaCreate, DetalleVentaCreate
from app.core_modules.ventas import services as ventas_services
from app.core_modules.finanzas.accounting_service import init_pcu_chileno


TOTAL_SALES = 500
INITIAL_STOCK = 300


def setup_stress_context(db: Session) -> Tuple:
    db.info["allow_no_tenant"] = True
    company = db.query(Empresa).filter(Empresa.codigo == "STRESS_UUID").first()
    if not company:
        company = Empresa(nombre="Stress UUID Company", codigo="STRESS_UUID")
        db.add(company)
        db.commit()
        db.refresh(company)

    user = db.query(Usuario).filter(Usuario.email == "stress_user@example.com").first()
    if not user:
        user = Usuario(
            email="stress_user@example.com",
            hashed_password="stress-hash",
            is_active=True,
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    link = (
        db.query(UsuarioEmpresa)
        .filter(
            UsuarioEmpresa.usuario_id == user.id,
            UsuarioEmpresa.empresa_id == company.id,
        )
        .first()
    )
    if not link:
        link = UsuarioEmpresa(
            usuario_id=user.id, empresa_id=company.id, is_default=True
        )
        db.add(link)
        db.commit()

    sucursal = (
        db.query(Sucursal)
        .filter(Sucursal.nombre == "Sucursal Stress", Sucursal.empresa_id == company.id)
        .first()
    )
    if not sucursal:
        sucursal = Sucursal(nombre="Sucursal Stress", empresa_id=company.id)
        db.add(sucursal)
        db.commit()
        db.refresh(sucursal)

    bodega = db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
    if not bodega:
        bodega = Bodega(nombre="Bodega Stress", sucursal_id=sucursal.id)
        db.add(bodega)
        db.commit()
        db.refresh(bodega)

    producto = (
        db.query(Producto)
        .filter(Producto.sku == "SKU-STRESS", Producto.empresa_id == company.id)
        .first()
    )
    if not producto:
        producto = Producto(
            nombre="Producto Stress",
            sku="SKU-STRESS",
            precio=Decimal("100.00"),
            empresa_id=company.id,
            tipo_producto="ALMACENABLE",
            is_active=True,
        )
        db.add(producto)
        db.commit()
        db.refresh(producto)

    variant_id = resolve_or_create_variant_id(
        db,
        producto_id=producto.id,
        empresa_id=company.id,
        attributes={},
    )
    inventario = (
        db.query(Inventario)
        .filter(
            Inventario.empresa_id == company.id,
            Inventario.producto_id == producto.id,
            Inventario.variant_id == variant_id,
            Inventario.bodega_id == bodega.id,
        )
        .first()
    )
    if not inventario:
        inventario = Inventario(
            empresa_id=company.id,
            producto_id=producto.id,
            variant_id=variant_id,
            bodega_id=bodega.id,
            cantidad=INITIAL_STOCK,
            cantidad_reservada=0,
        )
    else:
        inventario.empresa_id = company.id
        inventario.variant_id = variant_id
        inventario.cantidad = INITIAL_STOCK
        inventario.cantidad_reservada = 0
    db.add(inventario)

    cliente = (
        db.query(Cliente)
        .filter(Cliente.nombre == "Cliente Stress", Cliente.empresa_id == company.id)
        .first()
    )
    if not cliente:
        cliente = Cliente(nombre="Cliente Stress", empresa_id=company.id)
        db.add(cliente)
        db.commit()
        db.refresh(cliente)

    init_pcu_chileno(db, empresa_id=company.id)

    db.commit()

    return company.id, user.id, sucursal.id, producto.id, cliente.id, bodega.id


async def create_sale_concurrent(
    index: int,
    company_id,
    user_id,
    sucursal_id,
    producto_id,
    cliente_id,
) -> Tuple:
    start = time.perf_counter()

    def run_blocking():
        session = SessionLocal()
        session.info["empresa_id"] = company_id
        session.execute(text("SET statement_timeout TO 120000"))
        try:
            venta_in = VentaCreate(
                cliente_id=cliente_id,
                sucursal_id=sucursal_id,
                folio=f"STRESS-{index}",
                detalles=[
                    DetalleVentaCreate(
                        producto_id=producto_id,
                        cantidad=1,
                        es_servicio=False,
                    )
                ],
                orden_servicio=None,
            )
            try:
                venta = ventas_services.create_venta(
                    db=session,
                    venta_in=venta_in,
                    usuario_id=user_id,
                    empresa_id=company_id,
                )
                session.refresh(venta)
                return "OK", venta.id
            except BusinessRuleError:
                session.rollback()
                return "OUT_OF_STOCK", None
        finally:
            session.close()

    status, venta_id = await asyncio.to_thread(run_blocking)
    end = time.perf_counter()
    return status, venta_id, end - start


@pytest.mark.asyncio
async def test_sales_concurrency_uuid_puro():
    base_session = SessionLocal()
    base_session.info["allow_no_tenant"] = True
    try:
        (
            company_id,
            user_id,
            sucursal_id,
            producto_id,
            cliente_id,
            bodega_id,
        ) = setup_stress_context(base_session)
    finally:
        base_session.close()

    tasks: List[asyncio.Task] = []

    for i in range(TOTAL_SALES):
        task = asyncio.create_task(
            create_sale_concurrent(
                index=i,
                company_id=company_id,
                user_id=user_id,
                sucursal_id=sucursal_id,
                producto_id=producto_id,
                cliente_id=cliente_id,
            )
        )
        tasks.append(task)

    global_start = time.perf_counter()
    results = await asyncio.gather(*tasks)
    global_end = time.perf_counter()

    venta_ids: List = []
    durations_success: List[float] = []
    durations_failed: List[float] = []
    failures = 0

    for status, venta_id, duration in results:
        if status == "OK":
            venta_ids.append(venta_id)
            durations_success.append(duration)
        elif status == "OUT_OF_STOCK":
            failures += 1
            durations_failed.append(duration)
        else:
            pytest.fail(f"Estado inesperado en worker de venta: {status}")

    assert len(venta_ids) == 300
    assert failures == 200
    assert len(set(venta_ids)) == len(venta_ids)

    verify_session = SessionLocal()
    verify_session.info["empresa_id"] = company_id
    try:
        inventario = (
            verify_session.query(Inventario)
            .filter(
                Inventario.producto_id == producto_id, Inventario.bodega_id == bodega_id
            )
            .first()
        )
        assert inventario is not None
        assert inventario.cantidad == 0

        expected_resources = {f"Venta:{venta_id}" for venta_id in venta_ids}
        audit_logs = (
            verify_session.query(AuditLog)
            .filter(
                AuditLog.action == "VENTA_CONFIRMADA",
                AuditLog.resource.in_(list(expected_resources)),
            )
            .all()
        )
        assert len(audit_logs) == len(venta_ids) == 300
    finally:
        verify_session.close()

    avg_success = (
        sum(durations_success) / len(durations_success) if durations_success else 0.0
    )
    avg_failed = (
        sum(durations_failed) / len(durations_failed) if durations_failed else 0.0
    )
    total_time = global_end - global_start

    print(
        f"\n[STRESS] Ventas exitosas: {len(venta_ids)}/{TOTAL_SALES}, "
        f"fallidas por stock: {failures}"
    )
    print(f"[STRESS] Tiempo total: {total_time:.4f}s")
    print(
        f"[STRESS] Promedio éxito: {avg_success:.4f}s, "
        f"promedio rechazo stock: {avg_failed:.4f}s"
    )
    if avg_success > 0 and avg_failed > avg_success * 2:
        print(
            "[STRESS] ALERTA: Latencia aumenta significativamente "
            "cuando se rechaza por falta de stock."
        )
