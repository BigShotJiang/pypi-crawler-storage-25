import sys
import os
import uuid
from fastapi import Depends
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from app.main import app
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal, ServiceOrder
from app.core_modules.ventas.models import Producto
from app.core_modules.finanzas.models import AsientoContable
from app.api import deps

client = TestClient(app)


def setup_test_data(db: Session):
    prev_allow_no_tenant = db.info.get("allow_no_tenant", False)
    prev_empresa_id = db.info.get("empresa_id")
    db.info["allow_no_tenant"] = True
    db.info.pop("empresa_id", None)

    # Generate unique codes to avoid collision in dirty DBs
    suffix = str(uuid.uuid4())[:8]
    core_code = f"CORE_{suffix}"
    service_code = f"SRV_{suffix}"

    # Setup Company with CORE only
    company_core = Empresa(
        nombre=f"Core Only {suffix}", codigo=core_code, modulos_activos=["CORE"]
    )
    db.add(company_core)

    # Setup Company with SERVICE_ENGINE
    company_service = Empresa(
        nombre=f"Service Center {suffix}",
        codigo=service_code,
        modulos_activos=["CORE", "SERVICE_ENGINE"],
    )
    db.add(company_service)

    db.commit()
    db.refresh(company_core)
    db.refresh(company_service)

    # Setup User linked to both
    email_core = f"user_core_{suffix}@test.com"
    user_core = Usuario(email=email_core, hashed_password="x", role="USER")
    db.add(user_core)

    email_service = f"user_service_{suffix}@test.com"
    user_service = Usuario(email=email_service, hashed_password="x", role="USER")
    db.add(user_service)

    db.commit()
    db.refresh(user_core)
    db.refresh(user_service)

    # Link User Core
    db.add(
        UsuarioEmpresa(
            usuario_id=user_core.id, empresa_id=company_core.id, is_default=True
        )
    )

    # Link User Service
    db.add(
        UsuarioEmpresa(
            usuario_id=user_service.id, empresa_id=company_service.id, is_default=True
        )
    )

    # Create Sucursal for Service Center
    sucursal = Sucursal(
        nombre=f"Centro de Servicios {suffix}",
        direccion="Calle 123",
        empresa_id=company_service.id,
    )
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)

    # Create Product (Service)
    producto = Producto(
        nombre="Servicio Estandar",
        sku=f"SERV_{suffix}",
        precio=1500,
        tipo_producto="SERVICIO",
        empresa_id=company_service.id,
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)

    db.info["empresa_id"] = company_service.id
    db.info["allow_no_tenant"] = prev_allow_no_tenant
    if prev_empresa_id is not None:
        db.info["prev_empresa_id"] = prev_empresa_id

    return {
        "company_core": company_core,
        "company_service": company_service,
        "user_core": user_core,
        "user_service": user_service,
        "sucursal": sucursal,
        "producto": producto,
    }


def test_service_engine_flexible_config(db):
    """
    Caso de uso: Configuración de flujo de servicios complejo
    Valida que el motor de servicios (Service Engine) funcione correctamente
    con una configuración agnóstica, sin depender de módulos verticales hardcodeados.
    """
    try:
        data = setup_test_data(db)

        # Override deps
        app.dependency_overrides[deps.get_current_user] = lambda: data["user_service"]

        def override_service_company(db: Session = Depends(deps.get_db)):
            db.info["empresa_id"] = data["company_service"].id
            db.info["allow_no_tenant"] = False
            return data["company_service"]

        def override_core_company(db: Session = Depends(deps.get_db)):
            db.info["empresa_id"] = data["company_core"].id
            db.info["allow_no_tenant"] = False
            return data["company_core"]

        app.dependency_overrides[deps.get_current_active_company] = override_service_company
        # Override get_db to use the same session
        app.dependency_overrides[deps.get_db] = lambda: db

        print("\n--- Test 1: License Failure (CORE only) ---")
        # Temporarily switch company context
        app.dependency_overrides[deps.get_current_active_company] = override_core_company

        response = client.post(
            f"/api/v1/service-engine/job-orders?cmp={data['company_core'].codigo}",
            json={
                "description": "Intento fallido",
                "sucursal_id": str(data["sucursal"].id),
                "service_orders": [],
            },
        )
        if response.status_code == 403:
            print("✅ License check passed: 403 Forbidden for CORE company")
        else:
            print(
                f"⚠️ Warning: Expected 403, got {response.status_code}. Response: {response.text}"
            )

        print("\n--- Test 2: Create Job Order (Success) ---")
        # Switch back
        app.dependency_overrides[deps.get_current_active_company] = override_service_company

        payload = {
            "description": "Orden de Prueba Refactorizada",
            "sucursal_id": str(data["sucursal"].id),
            "service_orders": [
                {
                    "producto_id": str(data["producto"].id),
                    "sucursal_id": str(data["sucursal"].id),
                    "metadata_info": {"peso_kg": 5.0, "tipo_lavado": "AGUA"},
                    "observaciones": "Ropa delicada",
                }
            ],
        }

        response = client.post(
            f"/api/v1/service-engine/job-orders?cmp={data['company_service'].codigo}",
            json=payload,
        )

        assert response.status_code == 200, f"Error creating job order: {response.text}"
        job_data = response.json()
        print(f"✅ Job Order Created: ID {job_data['id']}")
        assert len(job_data["service_orders"]) == 1
        service_order_id = job_data["service_orders"][0]["id"]

        # Verify Metadata
        assert job_data["service_orders"][0]["metadata_info"]["peso_kg"] == 5.0

        print("\n--- Test 3: Update Status & Event Dispatch ---")
        # Update status to COMPLETED
        response = client.patch(
            f"/api/v1/service-engine/service-orders/{service_order_id}/status?cmp={data['company_service'].codigo}",
            json={
                "status": "COMPLETED",
                "observaciones": "Servicio finalizado con exito",
            },
        )
        assert response.status_code == 200, f"Error updating status: {response.text}"
        updated_order = response.json()
        assert updated_order["status"] == "COMPLETED"
        print("✅ Status Updated to COMPLETED")

        # Verify Side Effects (Accounting)
        # Wait a bit for async listener (though in tests it might run synchronously if config allows, or we wait)
        # In current setup, listeners are likely async.
        # But without a real async loop runner in TestClient for background tasks, they might not run unless explicitly awaited or if they run in same loop.
        # However, checking DB for side effects is best effort.

        order_db = (
            db.query(ServiceOrder).filter(ServiceOrder.id == service_order_id).first()
        )
        if order_db.venta_id:
            print(f"✅ ServiceOrder linked to Venta ID {order_db.venta_id}")
            # Check accounting
            asiento = (
                db.query(AsientoContable)
                .filter(
                    AsientoContable.origen == "SERVICE_ENGINE",
                    AsientoContable.origen_id == service_order_id,
                )
                .first()
            )
            if asiento:
                print(f"✅ Accounting Entry Created: ID {asiento.id}")
            else:
                print("ℹ️ Accounting Entry NOT Created (Listener didn't run or failed)")
        else:
            print(
                "ℹ️ ServiceOrder NOT linked to Venta (Accounting listener expected to skip)"
            )

    except Exception as e:
        print(f"❌ Test Failed: {e}")
        raise e
    finally:
        app.dependency_overrides = {}
