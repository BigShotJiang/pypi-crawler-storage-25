import pytest
import time
from decimal import Decimal
from sqlalchemy.orm import Session
from fastapi.testclient import TestClient
from fastapi import Depends
from unittest.mock import patch
from app.main import app
from app.core.database import SessionLocal
from app.api import deps
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto, Receta, InsumoReceta
from app.core_modules.inventario.models import Inventario, MovimientoStock
from app.core_modules.auditoria.models import AuditLog
from app.core_modules.sistema.models import BackgroundJobLog
from uuid import uuid4

client = TestClient(app)

@pytest.fixture(scope="function")
def inventory_audit_data(db):
    """
    Setup data for Inventory Audit Test.
    """
    # Permitir creación sin tenant
    db.info["allow_no_tenant"] = True

    suffix = str(uuid4())[:8]
    
    # 1. Company & User
    empresa = Empresa(nombre=f"E2E Audit {suffix}", codigo=f"E2E_AUDIT_{suffix}", modulos_activos=["SERVICE_ENGINE", "VENTAS", "AUDITORIA", "INVENTARIO"])
    db.add(empresa)
    
    email = f"audit_agent_{suffix}@test.com"
    usuario = Usuario(email=email, hashed_password="x", role="VEN", is_active=True)
    db.add(usuario)
    db.commit()
    db.refresh(empresa)
    db.refresh(usuario)

    db.info["empresa_id"] = empresa.id
    db.info["allow_no_tenant"] = False
    
    # Link
    db.add(UsuarioEmpresa(usuario_id=usuario.id, empresa_id=empresa.id, is_default=True))
    
    # 2. Branch & Warehouse
    sucursal = Sucursal(nombre=f"Sucursal Audit {suffix}", empresa_id=empresa.id)
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)
    
    bodega = Bodega(nombre=f"Bodega Audit {suffix}", sucursal_id=sucursal.id)
    db.add(bodega)
    db.commit()
    
    # 3. Products
    # Insumo with initial stock
    insumo = Producto(
        nombre=f"Insumo Audit {suffix}",
        sku=f"INS-A-{suffix}",
        precio=Decimal("500"), 
        tipo_producto="PRODUCTO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(insumo)
    
    servicio = Producto(
        nombre=f"Servicio Audit {suffix}",
        sku=f"SERV-A-{suffix}",
        precio=Decimal("8000"),
        tipo_producto="SERVICIO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(servicio)
    db.commit()
    
    # 4. Stock
    inventario = Inventario(
        producto_id=insumo.id,
        bodega_id=bodega.id,
        cantidad=100,
        cantidad_reservada=0
    )
    db.add(inventario)
    db.commit()
    
    # Setup Accounting Accounts
    from app.core_modules.finanzas import models as finanzas_models
    cuentas_data = [
        {"codigo": "1.1.03.01", "nombre": "Existencias", "tipo": "ACTIVO", "nivel": 4},
        {"codigo": "5.1.01", "nombre": "Costo de Ventas", "tipo": "GASTO", "nivel": 3},
    ]
    
    for c in cuentas_data:
        cuenta = db.query(finanzas_models.CuentaContable).filter(
            finanzas_models.CuentaContable.codigo == c["codigo"],
            finanzas_models.CuentaContable.empresa_id == empresa.id
        ).first()
        if not cuenta:
            cuenta = finanzas_models.CuentaContable(
                codigo=c["codigo"],
                nombre=c["nombre"],
                tipo_cuenta=c["tipo"],
                empresa_id=empresa.id,
                nivel=c["nivel"]
            )
            db.add(cuenta)
    db.commit()
    
    # 5. Recipe: 5 units of insumo per service
    receta = Receta(producto_final_id=servicio.id, nombre="Receta Audit")
    db.add(receta)
    db.commit()
    
    insumo_receta = InsumoReceta(
        receta_id=receta.id,
        producto_insumo_id=insumo.id,
        cantidad=Decimal("5.0")
    )
    db.add(insumo_receta)
    db.commit()
    
    yield {
        "db": db,
        "empresa": empresa,
        "usuario": usuario,
        "sucursal": sucursal,
        "servicio": servicio,
        "insumo": insumo,
        "bodega": bodega
    }
    
    db.close()

def wait_for_background_job(db: Session, task_name: str, min_created_at=None, timeout_sec=10):
    start_time = time.time()
    while time.time() - start_time < timeout_sec:
        query = db.query(BackgroundJobLog).filter(
            BackgroundJobLog.task_name == task_name,
            BackgroundJobLog.status == "SUCCESS"
        )
        if min_created_at:
            query = query.filter(BackgroundJobLog.created_at >= min_created_at)
            
        job = query.order_by(BackgroundJobLog.created_at.desc()).first()
        if job:
            return job
        time.sleep(0.5)
    return None

def test_e2e_inventory_audit_trail(inventory_audit_data, client):
    """
    Test E2E_Stock_Integrity: Inventory Audit Trail
    Verificar consumo de stock y rastro de auditoría.
    """
    data = inventory_audit_data
    db: Session = data["db"]
    empresa = data["empresa"]
    usuario = data["usuario"]
    sucursal = data["sucursal"]
    servicio = data["servicio"]
    insumo = data["insumo"]
    bodega = data["bodega"]
    
    # Override Auth & Context
    app.dependency_overrides[deps.get_current_user] = lambda: usuario
    
    def override_get_current_active_company(db: Session = Depends(deps.get_db)):
        db.info["empresa_id"] = empresa.id
        return empresa
    app.dependency_overrides[deps.get_current_active_company] = override_get_current_active_company

    # Mock SessionLocal for background listeners
    original_session_local = SessionLocal
    def session_factory_override():
        session = original_session_local()
        session.info["empresa_id"] = empresa.id
        session.info["allow_no_tenant"] = False
        return session
    
    patchers = [
        patch("app.core.database.SessionLocal", side_effect=session_factory_override),
        patch("app.core.infrastructure.config_manager.SessionLocal", side_effect=session_factory_override),
        patch("app.core_modules.auditoria.listeners.SessionLocal", side_effect=session_factory_override),
        patch("app.core.exceptions.error_utils.SessionLocal", side_effect=session_factory_override),
    ]
    for p in patchers:
        p.start()
    
    try:
        from datetime import datetime, timezone
        start_time = datetime.now(timezone.utc)
        
        # 1. Crear Job Order (Consuming Service)
        print("\n--- Paso 1: Crear Job Order ---")
        payload = {
            "description": "Audit Inventory Test",
            "sucursal_id": str(sucursal.id),
            "service_orders": [
                {
                    "producto_id": str(servicio.id),
                    "sucursal_id": str(sucursal.id),
                    "metadata_info": {"qty": 2}, # 2 services * 5 insumos = 10 units
                    "observaciones": "Test Audit"
                }
            ]
        }
        
        res_create = client.post("/api/v1/service-engine/job-orders", json=payload)
        assert res_create.status_code == 200, f"Error creating Job Order: {res_create.text}"
        job_data = res_create.json()
        service_order_id = job_data["service_orders"][0]["id"]
        print(f"✅ Job Order created. Service Order: {service_order_id}")
        
        # 2. Change status to COMPLETED (Triggers Inventory + Audit)
        print("\n--- Paso 2: Completar Orden ---")
        status_payload = {"status": "COMPLETED"}
        res_update = client.patch(
            f"/api/v1/service-engine/service-orders/{service_order_id}/status",
            json=status_payload
        )
        assert res_update.status_code == 200, f"Error completing order: {res_update.text}"
        print("✅ Order Completed")
        
        # 3. Wait for Background Jobs
        print("\n--- Paso 3: Esperar Background Jobs (Inventory & Audit) ---")
        # Inventory Job
        job_inv = wait_for_background_job(
            db, 
            task_name="service_engine.service_update_inventory",
            min_created_at=start_time,
            timeout_sec=15
        )
        assert job_inv is not None, "Background Job (Inventory) did not finish in time"
        print(f"✅ Inventory Job Success: {job_inv.id}")
        
        # Audit Job
        job_aud = wait_for_background_job(
            db, 
            task_name="service_engine.service_update_audit",
            min_created_at=start_time,
            timeout_sec=15
        )
        assert job_aud is not None, "Background Job (Audit) did not finish in time"
        print(f"✅ Audit Job Success: {job_aud.id}")
        
        db.expire_all()

        # 4. Check Inventory Decrease
        print("\n--- Paso 4: Validar Consumo de Stock ---")
        # Check MovimientoStock
        # Expected: -10 units (2 services * 5 per service)
        mov = db.query(MovimientoStock).filter(
            MovimientoStock.producto_id == insumo.id,
            MovimientoStock.tipo == "CONSUMO_INTERNO",
            MovimientoStock.cantidad == -10
        ).order_by(MovimientoStock.fecha.desc()).first()
        
        assert mov is not None, "MovimientoStock not found or incorrect quantity"
        print("✅ MovimientoStock Validado: -10 units")
        
        # Check current stock
        inv = db.query(Inventario).filter(
            Inventario.producto_id == insumo.id,
            Inventario.bodega_id == bodega.id
        ).first()
        assert inv.cantidad == 90, f"Current Stock {inv.cantidad} != Expected 90" # 100 - 10
        print("✅ Current Stock Validado: 90")
        
        # 5. Check Audit Trail
        print("\n--- Paso 5: Validar Rastro de Auditoría ---")
        # We expect an AuditLog linked to the Service Order ID
        audit_log = db.query(AuditLog).filter(
            AuditLog.referencia_id == str(service_order_id),
            AuditLog.modulo == "SERVICE_ENGINE",
            AuditLog.accion.like("SERVICE_ORDER_UPDATE%")
        ).first()
        
        assert audit_log is not None, "AuditLog for Service Order not found"
        print(f"✅ Audit Log found: {audit_log.id} - {audit_log.accion}")

    finally:
        for p in patchers:
            p.stop()
        app.dependency_overrides = {}
