import pytest
import time
from decimal import Decimal
from unittest.mock import patch
from sqlalchemy.orm import Session
from fastapi.testclient import TestClient
from fastapi import Depends
from app.main import app
from app.core.database import SessionLocal
from app.api import deps
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal
from app.core_modules.ventas.models import Producto, Receta, InsumoReceta
from app.core_modules.finanzas.models import AsientoContable, CuentaContable
from app.core_modules.sistema.models import BackgroundJobLog
from uuid import uuid4

client = TestClient(app)

@pytest.fixture(scope="module")
def service_e2e_data():
    """
    Setup data for Service Lifecycle E2E test.
    Includes Company, User, Branch, Accounting Plan, Product (Service + Input).
    """
    db = SessionLocal()
    # Permitir creación de empresa/usuario sin contexto de tenant
    db.info["allow_no_tenant"] = True

    suffix = str(uuid4())[:8]
    
    # 1. Company & User
    empresa = Empresa(nombre=f"E2E Service {suffix}", codigo=f"E2E_SERV_{suffix}", modulos_activos=["SERVICE_ENGINE", "FINANZAS", "VENTAS"])
    db.add(empresa)
    
    email = f"service_agent_{suffix}@test.com"
    usuario = Usuario(email=email, hashed_password="x", role="VEN", is_active=True)
    db.add(usuario)
    db.commit()
    db.refresh(empresa)
    db.refresh(usuario)

    db.info["empresa_id"] = empresa.id
    db.info["allow_no_tenant"] = False
    
    # Link
    db.add(UsuarioEmpresa(usuario_id=usuario.id, empresa_id=empresa.id, is_default=True))
    
    # 2. Branch
    sucursal = Sucursal(nombre=f"Lavanderia E2E {suffix}", empresa_id=empresa.id)
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)
    
    # 3. Accounting Plan (Minimal)
    cuenta_existencias = CuentaContable(
        codigo="1.1.03.01", nombre="Existencias", tipo_cuenta="ACTIVO", empresa_id=empresa.id, nivel=4
    )
    cuenta_costo = CuentaContable(
        codigo="5.1.01", nombre="Costo de Ventas", tipo_cuenta="GASTO", empresa_id=empresa.id, nivel=3
    )
    db.add(cuenta_existencias)
    db.add(cuenta_costo)
    db.commit()
    
    # 4. Products (Input & Service)
    insumo = Producto(
        nombre=f"Detergente E2E {suffix}",
        sku=f"INS-{suffix}",
        precio=Decimal("500"), # Cost per unit
        tipo_producto="PRODUCTO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(insumo)
    
    servicio = Producto(
        nombre=f"Lavado E2E {suffix}",
        sku=f"SERV-{suffix}",
        precio=Decimal("5000"),
        tipo_producto="SERVICIO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(servicio)
    db.commit()
    db.refresh(insumo)
    db.refresh(servicio)
    
    # 5. Recipe
    receta = Receta(producto_final_id=servicio.id, nombre="Receta Lavado Standard")
    db.add(receta)
    db.commit()
    db.refresh(receta)
    
    insumo_receta = InsumoReceta(
        receta_id=receta.id,
        producto_insumo_id=insumo.id,
        cantidad=Decimal("0.5") # 0.5 units of detergent per service
    )
    db.add(insumo_receta)
    db.commit()
    
    yield {
        "db": db,
        "empresa": empresa,
        "usuario": usuario,
        "sucursal": sucursal,
        "servicio": servicio,
        "insumo": insumo
    }
    
    db.close()

def wait_for_background_job(db: Session, task_name: str, min_created_at=None, timeout_sec=10):
    """
    Poll BackgroundJobLog looking for a SUCCESS task.
    """
    start_time = time.time()
    while time.time() - start_time < timeout_sec:
        query = db.query(BackgroundJobLog).filter(
            BackgroundJobLog.task_name == task_name,
            BackgroundJobLog.status == "SUCCESS"
        )
        if min_created_at:
            query = query.filter(BackgroundJobLog.created_at >= min_created_at)
            
        job = query.order_by(BackgroundJobLog.created_at.desc()).first()
        if job:
            return job
        time.sleep(0.5)
    return None

def test_e2e_service_lifecycle(service_e2e_data):
    """
    Flujo Crítico 2: Ciclo de vida de servicio + Background Job
    """
    data = service_e2e_data
    db: Session = data["db"]
    empresa = data["empresa"]
    usuario = data["usuario"]
    sucursal = data["sucursal"]
    servicio = data["servicio"]
    
    # Override Auth
    app.dependency_overrides[deps.get_current_user] = lambda: usuario
    
    def override_get_current_active_company(db: Session = Depends(deps.get_db)):
        db.info["empresa_id"] = empresa.id
        return empresa
        
    app.dependency_overrides[deps.get_current_active_company] = override_get_current_active_company

    # Mock SessionLocal in listeners to allow no tenant check or inject tenant if needed
    # Since the listener runs in background (or synchronous in test environment), 
    # it creates a new session. We need that session to have 'allow_no_tenant' = True
    original_session_local = SessionLocal
    def session_factory_override():
        session = original_session_local()
        session.info["empresa_id"] = empresa.id
        session.info["allow_no_tenant"] = False
        return session
    
    patchers = [
        patch("app.core.database.SessionLocal", side_effect=session_factory_override),
        patch("app.core.infrastructure.config_manager.SessionLocal", side_effect=session_factory_override),
        patch("app.core_modules.auditoria.listeners.SessionLocal", side_effect=session_factory_override),
        patch("app.core.exceptions.error_utils.SessionLocal", side_effect=session_factory_override),
    ]
    for p in patchers:
        p.start()
    
    try:
        from datetime import datetime, timezone
        start_time = datetime.now(timezone.utc)
        
        # Paso 1: Crear Job Order
        print("\n--- Paso 1: Crear Job Order ---")
        payload = {
            "description": "Orden E2E con Background Check",
            "sucursal_id": str(sucursal.id),
            "service_orders": [
                {
                    "producto_id": str(servicio.id),
                    "sucursal_id": str(sucursal.id),
                    "metadata_info": {"peso_kg": 10.0},
                    "observaciones": "Ropa muy sucia"
                }
            ]
        }
        
        # Using service-engine endpoint
        # Assuming path /api/v1/service-engine/job-orders based on test_vertical_laundry.py
        # But we need to add cmp query param if multi-tenant middleware requires it, 
        # or rely on dependency override. 
        # Dependency override handles `get_current_active_company`, 
        # but middleware might look at header/query. 
        # Let's try without cmp first, relying on dependency injection working (TestClient bypasses middleware usually? No, TestClient runs middleware).
        # But if we mocked deps.get_current_active_company, api endpoints using it will get our company.
        
        res_create = client.post("/api/v1/service-engine/job-orders", json=payload)
        assert res_create.status_code == 200, f"Error creando Job Order: {res_create.text}"
        job_data = res_create.json()
        job_id = job_data["id"]
        service_order_id = job_data["service_orders"][0]["id"]
        print(f"✅ Job Order creada: {job_id} (Service Order {service_order_id})")
        
        # Paso 2: Completar Orden (Trigger Background Job)
        print("\n--- Paso 2: Completar Orden ---")
        status_payload = {
            "status": "COMPLETED",
            "observaciones": "Listo para entrega"
        }
        res_update = client.patch(
            f"/api/v1/service-engine/service-orders/{service_order_id}/status",
            json=status_payload
        )
        assert res_update.status_code == 200, f"Error actualizando estado: {res_update.text}"
        print("✅ Estado actualizado a COMPLETED")
        
        # Paso 3: Esperar Background Job
        print("\n--- Paso 3: Esperar Background Job (Contabilidad) ---")
        # Task name found in listener: "service_engine.service_update_accounting"
        job = wait_for_background_job(
            db, 
            task_name="service_engine.service_update_accounting",
            min_created_at=start_time,
            timeout_sec=15
        )
        
        if job:
            print(f"✅ Job encontrado y exitoso: ID {job.id}, Duration {job.duration_ms}ms")
        else:
            # Fallback: check if accounting entry exists anyway (maybe sync execution?)
            # Or fail test if strict.
            print("⚠️ Job no encontrado en logs dentro del timeout. Verificando efecto secundario directo...")
        
        # Paso 4: Verificar Asiento Contable
        print("\n--- Paso 4: Verificar Asiento Contable ---")
        asiento = db.query(AsientoContable).filter(
            AsientoContable.origen == "SERVICE_ENGINE",
            AsientoContable.origen_id == str(service_order_id)
        ).first()
        
        assert asiento is not None, "No se generó Asiento Contable (Fallo de listener o configuración)"
        print(f"✅ Asiento Contable generado: ID {asiento.id}")
        
        # Verificar montos
        # Costo esperado: 0.5 (insumo) * 500 (precio insumo) * 1 (qty servicio default? metadata?)
        # Logic in listener: qty_insumo = insumo.cantidad * qty_servicios
        # Listener tries to find qty in metadata keys: peso_kg, cantidad, etc.
        # We sent "peso_kg": 10.0. 
        # So qty_servicios = 10.0
        # Insumo per unit = 0.5
        # Total insumo = 0.5 * 10.0 = 5.0 units
        # Cost = 5.0 * 500 = 2500
        
        total_debe = sum(m.debe for m in asiento.movimientos)
        assert total_debe == Decimal("2500"), f"Costo esperado 2500, obtenido {total_debe}"
        print(f"✅ Monto de costo correcto: {total_debe} (10kg * 0.5un * $500)")
        
        print("\n🎉 Flujo Crítico 2 (Ciclo de Vida Servicio) COMPLETADO")
        
    finally:
        for p in patchers:
            p.stop()
        app.dependency_overrides = {}
