import pytest
from unittest.mock import patch
from decimal import Decimal
from sqlalchemy.orm import Session
from fastapi import Depends
from app.main import app
from app.core.database import SessionLocal
from app.api import deps
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto
from app.core_modules.inventario.models import Inventario
from app.core_modules.facturacion.models import DocumentoTributario
from app.core_modules.finanzas.models import AsientoContable
from uuid import uuid4

@pytest.fixture(scope="function")
def e2e_data(db):
    """
    Setup data for E2E test.
    Create Company, User, Branch, Warehouse, Product with Stock.
    """
    # Permitir creación de empresa/usuario sin contexto de tenant
    db.info["allow_no_tenant"] = True
    
    suffix = str(uuid4())[:8]
    
    # 1. Company & User
    empresa = Empresa(nombre=f"E2E Sales {suffix}", codigo=f"E2E_SALES_{suffix}", modulos_activos=["VENTAS", "FINANZAS", "FACTURACION"])
    db.add(empresa)
    
    email = f"sales_agent_{suffix}@test.com"
    usuario = Usuario(email=email, hashed_password="x", role="VEN", is_active=True)
    db.add(usuario)
    db.commit()
    db.refresh(empresa)
    db.refresh(usuario)

    db.info["empresa_id"] = empresa.id
    db.info["allow_no_tenant"] = False
    
    # Link
    db.add(UsuarioEmpresa(usuario_id=usuario.id, empresa_id=empresa.id, is_default=True))
    
    # 2. Branch & Warehouse
    sucursal = Sucursal(nombre=f"Sucursal E2E {suffix}", empresa_id=empresa.id)
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)
    
    bodega = Bodega(nombre=f"Bodega E2E {suffix}", sucursal_id=sucursal.id)
    db.add(bodega)
    db.commit()
    db.refresh(bodega)
    
    # 3. Product & Stock
    producto = Producto(
        nombre=f"Producto E2E {suffix}",
        sku=f"SKU-E2E-{suffix}",
        precio=Decimal("10000"),
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)
    
    inventario = Inventario(
        producto_id=producto.id,
        bodega_id=bodega.id,
        cantidad=100,
        cantidad_reservada=0
    )
    db.add(inventario)
    db.commit()

    # 4. Accounting Plan (Required for Finance integration)
    from app.core_modules.finanzas.models import CuentaContable
    cuentas_data = [
        {"codigo": "1.1.01.01", "nombre": "Caja", "tipo": "ACTIVO", "nivel": 4}, # Pago
        {"codigo": "1.1.02.01", "nombre": "Clientes", "tipo": "ACTIVO", "nivel": 4}, # Credito
        {"codigo": "1.1.03.01", "nombre": "Existencias", "tipo": "ACTIVO", "nivel": 4}, # Inventario
        {"codigo": "5.1.01", "nombre": "Costo de Ventas", "tipo": "GASTO", "nivel": 3}, # Costo
        {"codigo": "4.1.01.01", "nombre": "Ventas", "tipo": "INGRESO", "nivel": 4}, # Ingreso
        {"codigo": "2.1.02.01", "nombre": "IVA Debito Fiscal", "tipo": "PASIVO", "nivel": 4}, # IVA
    ]
    
    for c in cuentas_data:
        cuenta = db.query(CuentaContable).filter(
            CuentaContable.codigo == c["codigo"],
            CuentaContable.empresa_id == empresa.id
        ).first()
        if not cuenta:
            cuenta = CuentaContable(
                codigo=c["codigo"],
                nombre=c["nombre"],
                tipo_cuenta=c["tipo"],
                empresa_id=empresa.id,
                nivel=c["nivel"]
                # is_active removed
            )
            db.add(cuenta)
    db.commit()
    
    yield {
        "db": db,
        "empresa": empresa,
        "usuario": usuario,
        "sucursal": sucursal,
        "bodega": bodega,
        "producto": producto,
        "suffix": suffix
    }

def test_e2e_sale_to_accounting(e2e_data, client):
    """
    Flujo Crítico 1: Venta Inmortal
    """
    data = e2e_data
    db: Session = data["db"]
    empresa = data["empresa"]
    usuario = data["usuario"]
    sucursal = data["sucursal"]
    producto = data["producto"]
    
    # Override Auth
    app.dependency_overrides[deps.get_current_user] = lambda: usuario
    
    def override_get_current_active_company(db: Session = Depends(deps.get_db)):
        db.info["empresa_id"] = empresa.id
        return empresa
        
    app.dependency_overrides[deps.get_current_active_company] = override_get_current_active_company
    
    # Patch global SessionLocal for background tasks/listeners
    original_session_local = SessionLocal
    def session_factory_override():
        session = original_session_local()
        session.info["empresa_id"] = empresa.id
        session.info["allow_no_tenant"] = False
        return session
    
    patchers = [
        patch("app.core.database.SessionLocal", side_effect=session_factory_override),
        patch("app.core.infrastructure.config_manager.SessionLocal", side_effect=session_factory_override),
        patch("app.core_modules.auditoria.listeners.SessionLocal", side_effect=session_factory_override),
        patch("app.core.exceptions.error_utils.SessionLocal", side_effect=session_factory_override),
    ]
    for p in patchers:
        p.start()

    try:
        # Paso 1: Crear Cliente
        print("\n--- Paso 1: Crear Cliente ---")
        cliente_payload = {
            "rut": "66666666-6", # Valid RUT
            "nombre": f"Cliente E2E {data['suffix']}",
            "direccion": "Calle Falsa 123",
            "email": "cliente@e2e.com",
            "telefono": "+56912345678"
        }
        # Assuming endpoint is at /api/v1/ventas/clientes/ based on previous search
        # Or checking api.py again... let's try standard path
        res_cliente = client.post("/api/v1/ventas/clientes/", json=cliente_payload)
        # If 404, maybe path is different. But let's assume standard modular structure
        assert res_cliente.status_code == 200, f"Error creando cliente: {res_cliente.text}"
        cliente_id = res_cliente.json()["id"]
        print(f"✅ Cliente creado: {cliente_id}")
        
        # Paso 2: Realizar Venta
        print("\n--- Paso 2: Realizar Venta ---")
        venta_payload = {
            "cliente_id": cliente_id,
            "sucursal_id": str(sucursal.id),
            "detalles": [
                {
                    "producto_id": str(producto.id),
                    "cantidad": 2,
                    "es_servicio": False
                }
            ],
            "orden_servicio": None,
            "metodo_pago": "CONTADO"
        }
        
        res_venta = client.post("/api/v1/ventas/", json=venta_payload)
        assert res_venta.status_code == 200, f"Error creando venta: {res_venta.text}"
        venta_data = res_venta.json()["data"]
        venta_id = venta_data["id"]
        print(f"✅ Venta creada: {venta_id}")
        
        # Paso 3: Verificar Stock
        print("\n--- Paso 3: Verificar Stock ---")
        # Re-fetch inventory
        db.expire_all()
        inv = db.query(Inventario).filter(
            Inventario.producto_id == producto.id,
            Inventario.bodega_id == data["bodega"].id
        ).first()
        assert inv.cantidad == 98, f"Stock esperado 98, obtenido {inv.cantidad}"
        print("✅ Stock descontado correctamente (100 -> 98)")
        
        # Paso 4: Verificar Documento Tributario
        print("\n--- Paso 4: Verificar DTE ---")
        # Depending on logic, DTE might be created async or sync. 
        # Usually created with Venta in standard flow.
        dte = db.query(DocumentoTributario).filter(
            DocumentoTributario.empresa_id == empresa.id,
            # We assume some linkage or just find latest
        ).order_by(DocumentoTributario.id.desc()).first()
        
        # If not linked directly, check logic. Usually Venta has references.
        # But let's check if a DTE exists for this amount/date.
        assert dte is not None, "No se encontró Documento Tributario"
        # Optional: check amount matches
        # total = 2 * 10000 = 20000. 
        # Assuming default IVA logic (19%), total should match.
        print(f"✅ DTE encontrado: ID {dte.id} Folio {dte.folio}")
        
        # Paso 5: Verificar Asiento Contable
        print("\n--- Paso 5: Verificar Asiento Contable ---")
        asiento = db.query(AsientoContable).filter(
            AsientoContable.origen == "VENTAS",
            AsientoContable.origen_id == str(venta_id)
        ).first()
        assert asiento is not None, "No se encontró Asiento Contable"
        
        # Verificar cuadratura
        debe = sum(m.debe for m in asiento.movimientos)
        haber = sum(m.haber for m in asiento.movimientos)
        assert debe == haber, f"Asiento descuadrado: Debe {debe} != Haber {haber}"
        print(f"✅ Asiento Contable encontrado y cuadrado: ID {asiento.id} (Total {debe})")
        
        print("\n🎉 Flujo Crítico 1 (Venta Inmortal) COMPLETADO")
        
    finally:
        for p in patchers:
            p.stop()
        app.dependency_overrides = {}
