import pytest
import asyncio
import httpx
from sqlalchemy.orm import Session
from fastapi import Depends
from app.main import app
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal
from app.core_modules.service_engine.models import ServiceOrder, JobOrder
from app.core_modules.ventas.models import Producto
from app.core_modules.finanzas.models import AsientoContable
from app.api import deps
from uuid import uuid4
from decimal import Decimal

# Base URL for async requests
BASE_URL = "http://test"

@pytest.fixture(scope="function")
def race_data(db):
    """
    Setup data for Race Condition Test.
    """
    db.info["allow_no_tenant"] = True
    suffix = str(uuid4())[:8]
    
    # 1. Company & User
    empresa = Empresa(nombre=f"Race Test {suffix}", codigo=f"RACE_{suffix}", modulos_activos=["SERVICE_ENGINE", "FINANZAS"])
    db.add(empresa)
    
    email = f"racer_{suffix}@test.com"
    usuario = Usuario(email=email, hashed_password="x", role="VEN", is_active=True)
    db.add(usuario)
    db.commit()
    db.refresh(empresa)
    db.refresh(usuario)
    
    # Link
    db.add(UsuarioEmpresa(usuario_id=usuario.id, empresa_id=empresa.id, is_default=True))
    
    # 2. Branch
    sucursal = Sucursal(nombre=f"Sucursal Race {suffix}", empresa_id=empresa.id)
    db.add(sucursal)
    db.commit()
    
    # 3. Service Product
    servicio = Producto(
        nombre=f"Servicio Race {suffix}",
        sku=f"SERV-R-{suffix}",
        precio=Decimal("5000"),
        tipo_producto="SERVICIO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(servicio)
    db.commit()

    # 4. Job Order -> Service Order
    job = JobOrder(
        description="Race Job",
        sucursal_id=sucursal.id,
        empresa_id=empresa.id,
        usuario_id=usuario.id
    )
    db.add(job)
    db.commit()

    service_order = ServiceOrder(
        job_order_id=job.id,
        producto_id=servicio.id,
        sucursal_id=sucursal.id,
        empresa_id=empresa.id,
        usuario_id=usuario.id,
        status="PENDING", # Initial state
        total_estimado=int(servicio.precio)
    )
    db.add(service_order)
    db.commit()
    db.refresh(service_order)

    return {
        "db": db,
        "empresa": empresa,
        "usuario": usuario,
        "service_order": service_order
    }

@pytest.mark.asyncio
async def test_race_condition_cancel_complete(race_data):
    """
    Test de Invariante de Estado: Intentar CANCEL y COMPLETE simultáneamente.
    Validación: Estado final consistente y sin efectos secundarios (asientos) si gana CANCEL.
    """
    data = race_data
    db = data["db"]
    empresa = data["empresa"]
    usuario = data["usuario"]
    service_order = data["service_order"]
    order_id = str(service_order.id)

    # Auth headers mock
    headers = {
        "X-Tenant-Id": str(empresa.id),
        "Authorization": "Bearer mock_token"
    }
    
    # Override Auth
    app.dependency_overrides[deps.get_current_user] = lambda: usuario
    
    # Override Company Context setter
    def override_get_company(db: Session = Depends(deps.get_db)):
        db.info["empresa_id"] = empresa.id
        db.info["rls_tenant_id"] = empresa.id
        db.info["rls_role"] = usuario.role
        return empresa

    app.dependency_overrides[deps.get_current_active_company] = override_get_company

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url=BASE_URL) as ac:
        url_status = f"/api/v1/service-engine/service-orders/{order_id}/status"
        
        # Payloads
        payload_complete = {"status": "COMPLETED"}
        payload_cancel = {"status": "CANCELLED"}
        
        # Fire both requests concurrently
        # We need to make sure they hit the server roughly at the same time
        task1 = ac.patch(url_status, json=payload_complete, headers=headers)
        task2 = ac.patch(url_status, json=payload_cancel, headers=headers)
        
        await asyncio.gather(task1, task2, return_exceptions=True)
        
    # Validation
    db.refresh(service_order)
    final_status = service_order.status
    print(f"Final Status: {final_status}")
    
    # Check AsientoContable
    asientos = db.query(AsientoContable).filter(
        AsientoContable.origen_id == str(service_order.id)
    ).all()
    
    if final_status == "CANCELLED":
        assert len(asientos) == 0, "Si se canceló, no debe haber asiento contable"
    elif final_status == "COMPLETED":
        # It might have completed successfully
        pass
        
    # Ensure state is one of the expected
    assert final_status in ["COMPLETED", "CANCELLED"]

    # Clean up overrides
    app.dependency_overrides = {}
