import pytest
import time
from decimal import Decimal
from sqlalchemy.orm import Session
from fastapi import Depends
from unittest.mock import patch
from app.main import app
from app.core.database import SessionLocal
from app.api import deps
from app.models import Usuario, Empresa, UsuarioEmpresa, Sucursal
from app.core_modules.ventas.models import Producto, Receta, InsumoReceta
from app.core_modules.finanzas.models import AsientoContable, CuentaContable
from app.core_modules.sistema.models import BackgroundJobLog
from uuid import uuid4

@pytest.fixture(scope="function")
def service_finance_data(db):
    """
    Setup data for Service -> Finance E2E test.
    """
    # Permitir creación sin tenant
    db.info["allow_no_tenant"] = True

    suffix = str(uuid4())[:8]
    
    # 1. Company & User
    empresa = Empresa(nombre=f"E2E Fin {suffix}", codigo=f"E2E_FIN_{suffix}", modulos_activos=["SERVICE_ENGINE", "FINANZAS", "VENTAS", "AUDITORIA"])
    db.add(empresa)
    
    email = f"fin_agent_{suffix}@test.com"
    usuario = Usuario(email=email, hashed_password="x", role="VEN", is_active=True)
    db.add(usuario)
    db.commit()
    db.refresh(empresa)
    db.refresh(usuario)
    
    # Link
    db.add(UsuarioEmpresa(usuario_id=usuario.id, empresa_id=empresa.id, is_default=True))
    
    # 2. Branch
    sucursal = Sucursal(nombre=f"Sucursal Fin {suffix}", empresa_id=empresa.id)
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)
    
    # 3. Accounting Plan
    cuentas_data = [
        {"codigo": "1.1.03.01", "nombre": "Existencias", "tipo": "ACTIVO", "nivel": 4},
        {"codigo": "5.1.01", "nombre": "Costo de Ventas", "tipo": "GASTO", "nivel": 3},
    ]
    
    for c in cuentas_data:
        cuenta = db.query(CuentaContable).filter(
            CuentaContable.codigo == c["codigo"],
            CuentaContable.empresa_id == empresa.id
        ).first()
        if not cuenta:
                cuenta = CuentaContable(
                    codigo=c["codigo"],
                    nombre=c["nombre"],
                    tipo_cuenta=c["tipo"],
                    empresa_id=empresa.id,
                    nivel=c["nivel"],
                    # is_active removed
                )
                db.add(cuenta)
    db.commit()
    
    # 4. Products (Input & Service)
    # Costo insumo: 1000
    insumo = Producto(
        nombre=f"Insumo Fin {suffix}",
        sku=f"INS-F-{suffix}",
        precio=Decimal("1000"), 
        tipo_producto="PRODUCTO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(insumo)
    
    servicio = Producto(
        nombre=f"Servicio Fin {suffix}",
        sku=f"SERV-F-{suffix}",
        precio=Decimal("10000"),
        tipo_producto="SERVICIO",
        empresa_id=empresa.id,
        is_active=True
    )
    db.add(servicio)
    db.commit()
    
    # 5. Recipe: 2 units of insumo per service
    receta = Receta(producto_final_id=servicio.id, nombre="Receta Fin")
    db.add(receta)
    db.commit()
    
    insumo_receta = InsumoReceta(
        receta_id=receta.id,
        producto_insumo_id=insumo.id,
        cantidad=Decimal("2.0")
    )
    db.add(insumo_receta)
    db.commit()
    
    yield {
        "db": db,
        "empresa": empresa,
        "usuario": usuario,
        "sucursal": sucursal,
        "servicio": servicio,
        "insumo": insumo
    }
    
def wait_for_background_job(db: Session, task_name: str, min_created_at=None, timeout_sec=10):
    start_time = time.time()
    while time.time() - start_time < timeout_sec:
        query = db.query(BackgroundJobLog).filter(
            BackgroundJobLog.task_name == task_name,
            BackgroundJobLog.status == "SUCCESS"
        )
        if min_created_at:
            query = query.filter(BackgroundJobLog.created_at >= min_created_at)
            
        job = query.order_by(BackgroundJobLog.created_at.desc()).first()
        if job:
            return job
        time.sleep(0.5)
    return None

def test_e2e_service_engine_to_finance(service_finance_data, client):
    """
    Test E2E_Core_Servicios: Service Engine -> Finance (Asiento Contable)
    Validación de Consistencia Eventual.
    """
    data = service_finance_data
    db: Session = data["db"]
    empresa = data["empresa"]
    usuario = data["usuario"]
    sucursal = data["sucursal"]
    servicio = data["servicio"]
    
    # Override Auth & Context
    app.dependency_overrides[deps.get_current_user] = lambda: usuario
    
    def override_get_current_active_company(db: Session = Depends(deps.get_db)):
        db.info["empresa_id"] = empresa.id
        return empresa
    app.dependency_overrides[deps.get_current_active_company] = override_get_current_active_company

    # Mock SessionLocal for background listeners (patched where used)
    original_session_local = SessionLocal
    def session_factory_override():
        session = original_session_local()
        session.info["empresa_id"] = empresa.id
        session.info["allow_no_tenant"] = False
        return session
    
    # Patch SessionLocal in all listener modules and error_utils
    patchers = [
        patch("app.core.database.SessionLocal", side_effect=session_factory_override),
        patch("app.core.infrastructure.config_manager.SessionLocal", side_effect=session_factory_override),
        patch("app.core_modules.finanzas.listeners.SessionLocal", side_effect=session_factory_override),
        patch("app.core_modules.ventas.listeners.SessionLocal", side_effect=session_factory_override),
        patch("app.core_modules.auditoria.listeners.SessionLocal", side_effect=session_factory_override),
        patch("app.core.exceptions.error_utils.SessionLocal", side_effect=session_factory_override),
    ]
    
    for p in patchers:
        p.start()
    
    try:
        from datetime import datetime, timezone
        start_time = datetime.now(timezone.utc)
        
        # 1. Crear Job Order
        print("\n--- Paso 1: Crear Job Order ---")
        payload = {
            "description": "Job Order Finance Test",
            "sucursal_id": str(sucursal.id),
            "service_orders": [
                {
                    "producto_id": str(servicio.id),
                    "sucursal_id": str(sucursal.id),
                    "metadata_info": {"qty": 1}, # 1 service
                    "observaciones": "Test Finance"
                }
            ]
        }
        
        res_create = client.post("/api/v1/service-engine/job-orders", json=payload)
        assert res_create.status_code == 200, f"Error creating Job Order: {res_create.text}"
        job_data = res_create.json()
        service_order_id = job_data["service_orders"][0]["id"]
        print(f"✅ Job Order created. Service Order: {service_order_id}")
        
        # 2. Change status to COMPLETED
        print("\n--- Paso 2: Completar Orden ---")
        status_payload = {"status": "COMPLETED"}
        res_update = client.patch(
            f"/api/v1/service-engine/service-orders/{service_order_id}/status",
            json=status_payload
        )
        assert res_update.status_code == 200, f"Error completing order: {res_update.text}"
        print("✅ Order Completed")
        
        # 3. Wait for Background Jobs (Accounting)
        print("\n--- Paso 3: Esperar Background Jobs ---")
        job_acc = wait_for_background_job(
            db, 
            task_name="service_engine.service_update_accounting",
            min_created_at=start_time,
            timeout_sec=15
        )
        assert job_acc is not None, "Background Job (Accounting) did not finish in time"
        print(f"✅ Accounting Job Success: {job_acc.id}")
        
        # 4. Check Final (Asiento Contable)
        print("\n--- Paso 4: Validar Asiento Contable ---")
        asiento = db.query(AsientoContable).filter(
            AsientoContable.origen == "SERVICE_ENGINE", 
            AsientoContable.origen_id == str(service_order_id)
        ).first()
        assert asiento is not None, "Asiento Contable not found"
        print(f"✅ Asiento Contable found: {asiento.id}")

        # Check Amount (1 Service * 2 Insumos * 1000 Price = 2000)
        total_expected = Decimal("2000")
        mov_debe = next((m for m in asiento.movimientos if m.debe > 0), None)
        assert mov_debe is not None, "Movimiento Debe not found"
        assert mov_debe.debe == total_expected, f"Asiento Debe {mov_debe.debe} != Expected {total_expected}"
        print(f"✅ Asiento Amount Validated: {mov_debe.debe}")

    finally:
        for p in patchers:
            p.stop()
        app.dependency_overrides = {}
