from fastapi.testclient import TestClient
from datetime import datetime, timezone, timedelta

from app.models import Usuario
from app.core_modules.sistema.models import AuditLog, AuditSeverity
from app.api import deps


def _make_superadmin(db):
    user = Usuario(
        email="super@test.com",
        hashed_password="hashed",
        role="DEVELOPER",
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def test_active_sessions_uses_login_logs(client: TestClient, db):
    superadmin = _make_superadmin(db)

    login_log = AuditLog(
        actor_id=superadmin.id,
        action="LOGIN",
        resource=f"Usuario:{superadmin.id}",
        severity=AuditSeverity.INFO,
        changes=None,
        ip_address="127.0.0.1",
    )
    login_log.created_at = datetime.now(timezone.utc) - timedelta(hours=1)
    db.add(login_log)
    db.commit()

    client.app.dependency_overrides[deps.get_current_user] = lambda: superadmin

    response = client.get("/api/v1/admin/stats/active-sessions")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 1
    emails = [s["user_email"] for s in data]
    assert superadmin.email in emails


def test_active_sessions_fallback_when_no_login_logs(client: TestClient, db):
    superadmin = _make_superadmin(db)
    client.app.dependency_overrides[deps.get_current_user] = lambda: superadmin

    response = client.get("/api/v1/admin/stats/active-sessions")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    session = data[0]
    assert session["user_email"] == superadmin.email
    assert session["session_id"].startswith("synthetic-")


def test_global_timeline_is_stable_across_calls(client: TestClient, db):
    superadmin = _make_superadmin(db)

    audit = AuditLog(
        actor_id=superadmin.id,
        action="TEST_METRIC",
        resource="Test:Metric",
        severity=AuditSeverity.INFO,
        changes=None,
        ip_address=None,
    )
    db.add(audit)
    db.commit()

    client.app.dependency_overrides[deps.get_current_user] = lambda: superadmin

    r1 = client.get("/api/v1/admin/stats/global-timeline")
    r2 = client.get("/api/v1/admin/stats/global-timeline")

    assert r1.status_code == 200
    assert r2.status_code == 200

    d1 = r1.json()
    d2 = r2.json()

    assert (
        d1["resumen_dia"]["empresas_creadas_hoy"]
        == d2["resumen_dia"]["empresas_creadas_hoy"]
    )
    assert len(d1["actividad_reciente"]) == len(d2["actividad_reciente"])
