from collections import defaultdict
from datetime import datetime
from decimal import Decimal
from typing import List, Tuple

from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.core.exceptions import BusinessRuleError
from app.core_modules.finanzas import accounting_service
from app.core_modules.finanzas import models as fin_models
from app.core_modules.sistema.models import (
    Empresa,
    Usuario,
    AuditLog,
    Sucursal,
    Bodega,
    UsuarioEmpresa,
    Rol,
)
from app.core_modules.ventas import models as ventas_models
from app.core_modules.ventas import services as ventas_services
from app.core_modules.ventas.inventory_service import InventoryService
from app.core_modules.ventas.schemas import DetalleVentaCreate, VentaCreate
from app.core_modules.finanzas.accounting_service import init_pcu_chileno


SALES_PRICE = Decimal("119.00")
COSTO_UNITARIO = Decimal("70.00")
IVA_RATE = Decimal("0.19")


def setup_company_context() -> Tuple:
    db: Session = SessionLocal()
    db.info["allow_no_tenant"] = True

    empresa = db.query(Empresa).filter(Empresa.codigo == "FINAL_BOSS_ERP").first()
    if not empresa:
        empresa = Empresa(
            nombre="Final Boss ERP",
            codigo="FINAL_BOSS_ERP",
        )
        db.add(empresa)
        db.commit()
        db.refresh(empresa)

    empresa.limite_cupo_maximo = Decimal("10000000.00")
    db.add(empresa)
    db.commit()

    usuario = db.query(Usuario).filter(Usuario.email == "final.boss@erp.test").first()
    if not usuario:
        usuario = Usuario(
            email="final.boss@erp.test",
            hashed_password="final-boss",
            is_active=True,
        )
        db.add(usuario)
        db.commit()
        db.refresh(usuario)
    rol_adm = (
        db.query(Rol).filter(Rol.empresa_id == empresa.id, Rol.codigo == "ADM").first()
    )
    if not rol_adm:
        rol_adm = Rol(
            empresa_id=empresa.id,
            codigo="ADM",
            nombre="Administrador Único de Empresa",
            is_active=True,
        )
        db.add(rol_adm)
        db.commit()
        db.refresh(rol_adm)
    link = (
        db.query(UsuarioEmpresa)
        .filter_by(usuario_id=usuario.id, empresa_id=empresa.id)
        .first()
    )
    if not link:
        link = UsuarioEmpresa(
            usuario_id=usuario.id,
            empresa_id=empresa.id,
            rol_id=rol_adm.id,
            is_default=True,
        )
        db.add(link)
        db.commit()

    sucursal = (
        db.query(Sucursal)
        .filter(
            Sucursal.empresa_id == empresa.id,
            Sucursal.nombre == "SUCURSAL_FINAL_BOSS",
        )
        .first()
    )
    if not sucursal:
        sucursal = Sucursal(
            nombre="SUCURSAL_FINAL_BOSS",
            codigo=f"{empresa.codigo}-FBOSS",
            empresa_id=empresa.id,
        )
        db.add(sucursal)
        db.commit()
        db.refresh(sucursal)

    bodega = db.query(Bodega).filter(Bodega.sucursal_id == sucursal.id).first()
    if not bodega:
        bodega = Bodega(
            nombre="Bodega Final Boss",
            codigo=f"{empresa.codigo}-BOD-FBOSS",
            sucursal_id=sucursal.id,
            is_active=True,
        )
        db.add(bodega)
        db.commit()
        db.refresh(bodega)

    producto_a = (
        db.query(ventas_models.Producto)
        .filter(
            ventas_models.Producto.empresa_id == empresa.id,
            ventas_models.Producto.sku == "SKU-FINAL-A",
        )
        .first()
    )
    if not producto_a:
        producto_a = ventas_models.Producto(
            nombre="Producto Final A",
            sku="SKU-FINAL-A",
            precio=SALES_PRICE,
            tipo_producto="ALMACENABLE",
            is_active=True,
            empresa_id=empresa.id,
        )
        db.add(producto_a)
        db.commit()
        db.refresh(producto_a)

    producto_b = (
        db.query(ventas_models.Producto)
        .filter(
            ventas_models.Producto.empresa_id == empresa.id,
            ventas_models.Producto.sku == "SKU-FINAL-B",
        )
        .first()
    )
    if not producto_b:
        producto_b = ventas_models.Producto(
            nombre="Producto Final B",
            sku="SKU-FINAL-B",
            precio=SALES_PRICE,
            tipo_producto="ALMACENABLE",
            is_active=True,
            empresa_id=empresa.id,
        )
        db.add(producto_b)
        db.commit()
        db.refresh(producto_b)

    InventoryService.add_stock(
        db=db,
        producto_id=producto_a.id,
        bodega_id=bodega.id,
        cantidad=200,
        tipo_movimiento="INIT_FINAL_A",
        empresa_id=empresa.id,
    )
    InventoryService.add_stock(
        db=db,
        producto_id=producto_b.id,
        bodega_id=bodega.id,
        cantidad=200,
        tipo_movimiento="INIT_FINAL_B",
        empresa_id=empresa.id,
    )

    cliente = (
        db.query(ventas_models.Cliente)
        .filter(
            ventas_models.Cliente.empresa_id == empresa.id,
            ventas_models.Cliente.nombre == "Cliente Final Boss",
        )
        .first()
    )
    if not cliente:
        cliente = ventas_models.Cliente(
            nombre="Cliente Final Boss",
            email="cliente.final@erp.test",
            empresa_id=empresa.id,
            rut="99.999.999-9",
        )
        db.add(cliente)
        db.commit()
        db.refresh(cliente)

    cliente.limite_credito = Decimal("10000000.00")

    init_pcu_chileno(db, empresa_id=empresa.id)

    db.commit()

    return (
        db,
        empresa.id,
        usuario.id,
        sucursal.id,
        bodega.id,
        producto_a.id,
        producto_b.id,
        cliente.id,
    )


def crear_venta(
    db: Session,
    empresa_id,
    usuario_id,
    sucursal_id,
    cliente_id,
    producto_id,
    metodo_pago: str,
) -> ventas_models.Venta:
    venta_in = VentaCreate(
        cliente_id=cliente_id,
        sucursal_id=sucursal_id,
        folio=None,
        metodo_pago=metodo_pago,
        detalles=[
            DetalleVentaCreate(
                producto_id=producto_id,
                cantidad=1,
                es_servicio=False,
            )
        ],
        orden_servicio=None,
    )
    venta = ventas_services.create_venta(
        db=db,
        venta_in=venta_in,
        usuario_id=usuario_id,
        empresa_id=empresa_id,
    )
    db.refresh(venta)
    return venta


def anular_venta(
    db: Session,
    empresa_id,
    venta_id,
    usuario_id,
):
    try:
        venta = (
            db.query(ventas_models.Venta)
            .filter(
                ventas_models.Venta.id == venta_id,
                ventas_models.Venta.empresa_id == empresa_id,
            )
            .first()
        )
        if not venta:
            raise BusinessRuleError("Venta no encontrada para anulación")

        bodega_default = InventoryService.get_bodega_default(db, venta.sucursal_id)
        for det in venta.detalles:
            if det.producto.tipo_producto == "ALMACENABLE" and not det.es_servicio:
                InventoryService.add_stock(
                    db=db,
                    producto_id=det.producto_id,
                    bodega_id=bodega_default.id,
                    cantidad=det.cantidad,
                    tipo_movimiento="ANULACION_VENTA",
                    empresa_id=empresa_id,
                )

        asiento_original = (
            db.query(fin_models.AsientoContable)
            .filter(
                fin_models.AsientoContable.empresa_id == empresa_id,
                fin_models.AsientoContable.origen == "VENTAS",
                fin_models.AsientoContable.origen_id == str(venta.id),
            )
            .first()
        )

        if asiento_original:
            asiento_reverso = fin_models.AsientoContable(
                fecha=datetime.now(),
                glosa=f"Anulación Venta {venta.id}",
                origen="ANULACION_VENTA",
                origen_id=venta.id,
                estado="CONFIRMADO",
                sucursal_id=asiento_original.sucursal_id,
                usuario_id=usuario_id,
                empresa_id=empresa_id,
                tipo_documento=asiento_original.tipo_documento,
                folio_documento=asiento_original.folio_documento,
                rut_tercero=asiento_original.rut_tercero,
                razon_social_tercero=asiento_original.razon_social_tercero,
            )
            db.add(asiento_reverso)
            db.flush()

            movimientos_originales = (
                db.query(fin_models.MovimientoContable)
                .filter(fin_models.MovimientoContable.asiento_id == asiento_original.id)
                .all()
            )
            for mov in movimientos_originales:
                db.add(
                    fin_models.MovimientoContable(
                        asiento_id=asiento_reverso.id,
                        empresa_id=empresa_id,
                        cuenta_id=mov.cuenta_id,
                        debe=mov.haber,
                        haber=mov.debe,
                        sucursal_id=mov.sucursal_id,
                    )
                )

        venta.estado = ventas_models.EstadoVentaEnum.ANULADA
        db.add(venta)
        db.commit()
    except Exception:
        db.rollback()
        raise


def cambio_producto(
    db: Session,
    empresa_id,
    venta_id,
    producto_nuevo_id,
    usuario_id,
):
    try:
        venta = (
            db.query(ventas_models.Venta)
            .filter(
                ventas_models.Venta.id == venta_id,
                ventas_models.Venta.empresa_id == empresa_id,
            )
            .first()
        )
        if not venta:
            raise BusinessRuleError("Venta no encontrada para cambio de producto")

        detalle = venta.detalles[0]
        producto_viejo = detalle.producto
        producto_nuevo = (
            db.query(ventas_models.Producto)
            .filter(
                ventas_models.Producto.id == producto_nuevo_id,
                ventas_models.Producto.empresa_id == empresa_id,
            )
            .first()
        )
        if not producto_nuevo:
            raise BusinessRuleError("Producto nuevo no encontrado")

        bodega_default = InventoryService.get_bodega_default(db, venta.sucursal_id)

        if producto_viejo.tipo_producto == "ALMACENABLE" and not detalle.es_servicio:
            InventoryService.add_stock(
                db=db,
                producto_id=producto_viejo.id,
                bodega_id=bodega_default.id,
                cantidad=detalle.cantidad,
                tipo_movimiento="CAMBIO_PRODUCTO_IN",
                empresa_id=empresa_id,
            )

        if producto_nuevo.tipo_producto == "ALMACENABLE" and not detalle.es_servicio:
            InventoryService.consume_stock(
                db=db,
                producto_id=producto_nuevo.id,
                bodega_id=bodega_default.id,
                cantidad=detalle.cantidad,
                tipo_movimiento="CAMBIO_PRODUCTO_OUT",
                empresa_id=empresa_id,
            )

        asiento_cambio = fin_models.AsientoContable(
            fecha=datetime.now(),
            glosa=f"Cambio de Producto Venta {venta.id}",
            origen="CAMBIO_PRODUCTO",
            origen_id=venta.id,
            estado="CONFIRMADO",
            sucursal_id=venta.sucursal_id,
            usuario_id=usuario_id,
            empresa_id=empresa_id,
            tipo_documento=None,
            folio_documento=None,
            rut_tercero=None,
            razon_social_tercero=None,
        )
        db.add(asiento_cambio)
        db.flush()

        cuenta_existencias = accounting_service.get_cuenta_by_codigo(
            db, "1.1.03.01", empresa_id
        )
        if cuenta_existencias:
            total_costo = COSTO_UNITARIO * Decimal(str(detalle.cantidad))
            db.add(
                fin_models.MovimientoContable(
                    asiento_id=asiento_cambio.id,
                    empresa_id=empresa_id,
                    cuenta_id=cuenta_existencias.id,
                    debe=total_costo,
                    haber=0,
                    sucursal_id=venta.sucursal_id,
                )
            )
            db.add(
                fin_models.MovimientoContable(
                    asiento_id=asiento_cambio.id,
                    empresa_id=empresa_id,
                    cuenta_id=cuenta_existencias.id,
                    debe=0,
                    haber=total_costo,
                    sucursal_id=venta.sucursal_id,
                )
            )

        detalle.producto_id = producto_nuevo.id
        db.add(detalle)
        db.commit()
    except Exception:
        db.rollback()
        raise


def _compute_balance_comprobacion(
    db: Session, empresa_id
) -> Tuple[dict, Decimal, Decimal]:
    movimientos = (
        db.query(fin_models.MovimientoContable)
        .join(fin_models.AsientoContable)
        .filter(fin_models.AsientoContable.empresa_id == empresa_id)
        .all()
    )

    balance = defaultdict(Decimal)
    for mov in movimientos:
        cuenta = (
            db.query(fin_models.CuentaContable)
            .filter(fin_models.CuentaContable.id == mov.cuenta_id)
            .first()
        )
        if not cuenta:
            continue
        balance[cuenta.codigo] += Decimal(str(mov.debe or 0)) - Decimal(
            str(mov.haber or 0)
        )

    total_debe = sum(Decimal(str(m.debe or 0)) for m in movimientos)
    total_haber = sum(Decimal(str(m.haber or 0)) for m in movimientos)
    return balance, total_debe, total_haber


def _validate_audit_log_timeline(db: Session, empresa_id):
    logs: List[AuditLog] = db.query(AuditLog).order_by(AuditLog.created_at.asc()).all()
    last_ts = None
    for log in logs:
        if last_ts is not None:
            assert log.created_at >= last_ts
        last_ts = log.created_at


def _print_balance(balance: dict):
    print("\n=== BALANCE DE COMPROBACION FINAL BOSS ===")
    for codigo in sorted(balance.keys()):
        print(f"{codigo}: {balance[codigo]:.2f}")


def test_final_boss_erp_flow():
    (
        db,
        empresa_id,
        usuario_id,
        sucursal_id,
        bodega_id,
        producto_a_id,
        producto_b_id,
        cliente_id,
    ) = setup_company_context()

    try:
        operaciones = 0
        ventas_credito: List[ventas_models.Venta] = []
        ventas_contado: List[ventas_models.Venta] = []

        for _ in range(30):
            v = crear_venta(
                db=db,
                empresa_id=empresa_id,
                usuario_id=usuario_id,
                sucursal_id=sucursal_id,
                cliente_id=cliente_id,
                producto_id=producto_a_id,
                metodo_pago="CONTADO",
            )
            ventas_contado.append(v)
            operaciones += 1

        for _ in range(5):
            v = crear_venta(
                db=db,
                empresa_id=empresa_id,
                usuario_id=usuario_id,
                sucursal_id=sucursal_id,
                cliente_id=cliente_id,
                producto_id=producto_a_id,
                metodo_pago="CREDITO",
            )
            ventas_credito.append(v)
            operaciones += 1

        venta_extra_credito = crear_venta(
            db=db,
            empresa_id=empresa_id,
            usuario_id=usuario_id,
            sucursal_id=sucursal_id,
            cliente_id=cliente_id,
            producto_id=producto_a_id,
            metodo_pago="CREDITO",
        )
        ventas_credito.append(venta_extra_credito)
        operaciones += 1

        for v in ventas_contado[:10]:
            anular_venta(
                db=db,
                empresa_id=empresa_id,
                venta_id=v.id,
                usuario_id=usuario_id,
            )
            operaciones += 1

        for v in ventas_credito[:10]:
            cambio_producto(
                db=db,
                empresa_id=empresa_id,
                venta_id=v.id,
                producto_nuevo_id=producto_b_id,
                usuario_id=usuario_id,
            )
            operaciones += 1

        while operaciones < 100:
            crear_venta(
                db=db,
                empresa_id=empresa_id,
                usuario_id=usuario_id,
                sucursal_id=sucursal_id,
                cliente_id=cliente_id,
                producto_id=producto_a_id,
                metodo_pago="CONTADO",
            )
            operaciones += 1

        balance, total_debe, total_haber = _compute_balance_comprobacion(db, empresa_id)
        assert round(total_debe - total_haber, 2) == Decimal("0.00")

        cuenta_clientes = accounting_service.get_cuenta_by_codigo(
            db, "1.1.02.01", empresa_id
        )
        saldo_clientes_antes = Decimal("0.00")
        if cuenta_clientes:
            saldo_clientes_antes = balance.get(cuenta_clientes.codigo, Decimal("0.00"))
            assert saldo_clientes_antes >= Decimal("0.00")

        if cuenta_clientes and saldo_clientes_antes > Decimal("0.00"):
            accounting_service.registrar_pago_cliente(
                db=db,
                empresa_id=empresa_id,
                cliente_id=cliente_id,
                sucursal_id=sucursal_id,
                usuario_id=usuario_id,
                monto=saldo_clientes_antes,
                metodo_pago="EFECTIVO",
            )

            balance, total_debe, total_haber = _compute_balance_comprobacion(
                db, empresa_id
            )
            assert round(total_debe - total_haber, 2) == Decimal("0.00")

            saldo_clientes_despues = balance.get(
                cuenta_clientes.codigo, Decimal("0.00")
            )
            assert saldo_clientes_despues <= saldo_clientes_antes

        _validate_audit_log_timeline(db, empresa_id)

        _print_balance(balance)
    finally:
        db.close()
