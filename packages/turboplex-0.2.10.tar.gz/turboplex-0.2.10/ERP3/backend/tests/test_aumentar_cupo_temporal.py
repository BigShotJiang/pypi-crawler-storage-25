from decimal import Decimal
from uuid import uuid4

import pytest

from app.core.database import SessionLocal
from app.core_modules.sistema.models import (
    Empresa,
    Usuario,
    AuditLog,
    UsuarioEmpresa,
    Rol,
)
from app.core_modules.ventas.models import Cliente
from app.core_modules.ventas import services as ventas_services
from app.core.exceptions import ResourceNotFoundError, BusinessRuleError


def setup_cliente_credito():
    db = SessionLocal()
    db.info["allow_no_tenant"] = True

    empresa = db.query(Empresa).filter(Empresa.codigo == "CUPO_TEMPORAL_TEST").first()
    if not empresa:
        empresa = Empresa(
            nombre="Empresa Cupo Temporal",
            codigo="CUPO_TEMPORAL_TEST",
        )
        db.add(empresa)
        db.commit()
        db.refresh(empresa)

    usuario = (
        db.query(Usuario).filter(Usuario.email == "cupo.temporal@test.local").first()
    )
    if not usuario:
        usuario = Usuario(
            email="cupo.temporal@test.local",
            hashed_password="cupo-temporal",
            is_active=True,
        )
        db.add(usuario)
        db.commit()
        db.refresh(usuario)

    existing_roles = {
        r.codigo for r in db.query(Rol).filter(Rol.empresa_id == empresa.id).all()
    }
    default_roles = [
        ("ADM", "Administrador Único de Empresa"),
        ("SUP", "Supervisor"),
        ("VEN", "Vendedor"),
        ("BOD", "Bodeguero"),
        ("CON", "Contador"),
        ("BACKOFFICE", "Backoffice (operaciones internas sin crédito)"),
        ("AUD", "Auditor (solo lectura / revisión)"),
    ]
    for codigo, nombre in default_roles:
        if codigo in existing_roles:
            continue
        rol = Rol(
            empresa_id=empresa.id,
            codigo=codigo,
            nombre=nombre,
            is_active=True,
        )
        db.add(rol)
    db.commit()

    rol_sup = (
        db.query(Rol).filter(Rol.empresa_id == empresa.id, Rol.codigo == "SUP").first()
    )

    link = (
        db.query(UsuarioEmpresa)
        .filter(
            UsuarioEmpresa.usuario_id == usuario.id,
            UsuarioEmpresa.empresa_id == empresa.id,
        )
        .first()
    )
    if not link:
        link = UsuarioEmpresa(
            usuario_id=usuario.id,
            empresa_id=empresa.id,
            rol_id=rol_sup.id if rol_sup else None,
            is_default=True,
        )
        db.add(link)
        db.commit()

    cliente = (
        db.query(Cliente)
        .filter(
            Cliente.empresa_id == empresa.id,
            Cliente.nombre == "Cliente Cupo Temporal",
        )
        .first()
    )
    if not cliente:
        cliente = Cliente(
            nombre="Cliente Cupo Temporal",
            email="cliente.cupo@test.local",
            empresa_id=empresa.id,
        )
        db.add(cliente)
        db.commit()
        db.refresh(cliente)

    cliente.limite_credito = Decimal("10000.00")
    db.add(cliente)
    db.commit()
    db.refresh(cliente)

    return db, empresa.id, usuario.id, cliente.id


def setup_cross_tenant_sup():
    db = SessionLocal()
    db.info["allow_no_tenant"] = True

    empresa_a = Empresa(nombre="Empresa A", codigo="EMP_A")
    empresa_b = Empresa(nombre="Empresa B", codigo="EMP_B")
    db.add(empresa_a)
    db.add(empresa_b)
    db.commit()
    db.refresh(empresa_a)
    db.refresh(empresa_b)

    default_roles = [
        ("ADM", "Administrador Único de Empresa"),
        ("SUP", "Supervisor"),
        ("VEN", "Vendedor"),
        ("BOD", "Bodeguero"),
        ("CON", "Contador"),
        ("BACKOFFICE", "Backoffice (operaciones internas sin crédito)"),
        ("AUD", "Auditor (solo lectura / revisión)"),
    ]
    for empresa in (empresa_a, empresa_b):
        for codigo, nombre in default_roles:
            rol = Rol(
                empresa_id=empresa.id,
                codigo=codigo,
                nombre=nombre,
                is_active=True,
            )
            db.add(rol)
    db.commit()

    usuario_sup_a = Usuario(
        email="sup_a@test.local",
        hashed_password="sup",
        is_active=True,
    )
    db.add(usuario_sup_a)
    db.commit()
    db.refresh(usuario_sup_a)

    rol_sup_a = (
        db.query(Rol)
        .filter(Rol.empresa_id == empresa_a.id, Rol.codigo == "SUP")
        .first()
    )
    link_sup_a = UsuarioEmpresa(
        usuario_id=usuario_sup_a.id,
        empresa_id=empresa_a.id,
        rol_id=rol_sup_a.id if rol_sup_a else None,
        is_default=True,
    )
    db.add(link_sup_a)
    db.commit()

    cliente_b = Cliente(
        nombre="Cliente Empresa B",
        email="cliente.b@test.local",
        empresa_id=empresa_b.id,
    )
    db.add(cliente_b)
    db.commit()
    db.refresh(cliente_b)

    return db, empresa_a.id, empresa_b.id, usuario_sup_a.id, cliente_b.id


def test_aumentar_cupo_temporal_exitoso():
    db, empresa_id, usuario_id, cliente_id = setup_cliente_credito()
    try:
        response = ventas_services.aumentar_cupo_temporal(
            db=db,
            cliente_id=cliente_id,
            nuevo_monto=Decimal("5000.00"),
            motivo="Carta de Compromiso aprobada",
            usuario_id=usuario_id,
            empresa_id=empresa_id,
        )

        assert response["exito"] is True
        assert "cliente" in response
        assert "audit_log_id" in response

        cliente_data = response["cliente"]
        assert str(cliente_id) == str(cliente_data["id"])

        cliente_db = db.query(Cliente).filter(Cliente.id == cliente_id).first()
        assert cliente_db is not None
        assert cliente_db.limite_credito == Decimal("15000.00")

        audit = (
            db.query(AuditLog).filter(AuditLog.id == response["audit_log_id"]).first()
        )
        assert audit is not None
        assert audit.action == "AUMENTO_CUPO_CREDITO"
        assert audit.resource == f"Cliente:{cliente_id}"
        assert audit.changes is not None
        assert audit.changes["cliente_id"] == str(cliente_id)
        assert Decimal(str(audit.changes["monto_anterior"])) == Decimal("10000.00")
        assert Decimal(str(audit.changes["nuevo_monto"])) == Decimal("15000.00")
        assert Decimal(str(audit.changes["diferencia"])) == Decimal("5000.00")
        assert audit.changes["motivo"] == "Carta de Compromiso aprobada"
    finally:
        db.close()


def test_aumentar_cupo_temporal_cliente_inexistente():
    db, empresa_id, usuario_id, _ = setup_cliente_credito()
    try:
        with pytest.raises(ResourceNotFoundError):
            ventas_services.aumentar_cupo_temporal(
                db=db,
                cliente_id=uuid4(),
                nuevo_monto=Decimal("1000.00"),
                motivo="Motivo válido para prueba",
                usuario_id=usuario_id,
                empresa_id=empresa_id,
            )
    finally:
        db.close()


@pytest.mark.parametrize("monto", [Decimal("0.00"), Decimal("-10.00")])
def test_aumentar_cupo_temporal_monto_invalido(monto):
    db, empresa_id, usuario_id, cliente_id = setup_cliente_credito()
    try:
        with pytest.raises(BusinessRuleError):
            ventas_services.aumentar_cupo_temporal(
                db=db,
                cliente_id=cliente_id,
                nuevo_monto=monto,
                motivo="Motivo válido para prueba",
                usuario_id=usuario_id,
                empresa_id=empresa_id,
            )
    finally:
        db.close()


@pytest.mark.parametrize("motivo", ["", "muy corto", "  espacios  "])
def test_aumentar_cupo_temporal_motivo_invalido(motivo):
    db, empresa_id, usuario_id, cliente_id = setup_cliente_credito()
    try:
        with pytest.raises(BusinessRuleError):
            ventas_services.aumentar_cupo_temporal(
                db=db,
                cliente_id=cliente_id,
                nuevo_monto=Decimal("1000.00"),
                motivo=motivo,
                usuario_id=usuario_id,
                empresa_id=empresa_id,
            )
    finally:
        db.close()


def test_aumentar_cupo_temporal_excede_limite_maximo():
    db, empresa_id, usuario_id, cliente_id = setup_cliente_credito()
    try:
        cliente = db.query(Cliente).filter(Cliente.id == cliente_id).first()
        cliente.limite_credito = Decimal("49000.00")
        db.add(cliente)
        db.commit()

        with pytest.raises(BusinessRuleError):
            ventas_services.aumentar_cupo_temporal(
                db=db,
                cliente_id=cliente_id,
                nuevo_monto=Decimal("2000.00"),
                motivo="Intento de superar límite permitido",
                usuario_id=usuario_id,
                empresa_id=empresa_id,
            )
    finally:
        db.close()


def test_sup_no_puede_aumentar_cupo_de_otro_tenant():
    db, empresa_a_id, empresa_b_id, usuario_sup_id, cliente_b_id = (
        setup_cross_tenant_sup()
    )
    try:
        with pytest.raises(BusinessRuleError):
            ventas_services.aumentar_cupo_temporal(
                db=db,
                cliente_id=cliente_b_id,
                nuevo_monto=Decimal("1000.00"),
                motivo="Solicitud de aumento desde otra empresa",
                usuario_id=usuario_sup_id,
                empresa_id=empresa_a_id,
            )
    finally:
        db.close()
