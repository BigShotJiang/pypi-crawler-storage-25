import pytest
from datetime import datetime, timedelta
from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto
from app.core_modules.sistema.models import Empresa, Bodega, Sucursal
from app.core_modules.inventario.stock.services import InventoryService
from app.core_modules.inventario.stock.models import InventarioLote, EstadoLoteEnum, Inventario
from app.core.exceptions import BusinessRuleError
import uuid

@pytest.fixture(scope="module")
def db():
    session = SessionLocal()
    session.info["allow_no_tenant"] = True
    session.expire_on_commit = False
    yield session
    session.close()

@pytest.fixture(scope="module")
def setup_traceability_data(db):
    suffix = str(uuid.uuid4())[:8]
    
    # Create Empresa
    empresa = Empresa(nombre=f"Empresa Traz {suffix}", rut=f"777-{suffix}", codigo=f"EMP_T_{suffix}")
    db.add(empresa)
    db.commit()
    db.info["empresa_id"] = empresa.id
    db.info["allow_no_tenant"] = False

    # Create Sucursal & Bodega
    sucursal = Sucursal(nombre=f"Sucursal Traz {suffix}", empresa_id=empresa.id, direccion="Calle Test 777")
    db.add(sucursal)
    db.commit()
    
    bodega = Bodega(nombre=f"Bodega Traz {suffix}", sucursal_id=sucursal.id)
    db.add(bodega)
    db.commit()

    # Create Trazable Product
    producto = Producto(
        nombre=f"Prod Trazable {suffix}",
        sku=f"PROD_T_{suffix}",
        precio=1000,
        es_trazable=True,
        empresa_id=empresa.id
    )
    db.add(producto)
    db.commit()

    return {
        "empresa": empresa,
        "bodega": bodega,
        "producto": producto,
        "suffix": suffix
    }

def test_traceability_required(db, setup_traceability_data):
    # Try adding stock without lot/expiry for trazable product
    with pytest.raises(BusinessRuleError) as excinfo:
        InventoryService.add_stock(
            db=db,
            producto_id=setup_traceability_data["producto"].id,
            bodega_id=setup_traceability_data["bodega"].id,
            cantidad=10,
            tipo_movimiento="COMPRA",
            empresa_id=setup_traceability_data["empresa"].id
        )
    assert "trazable" in str(excinfo.value)

def test_add_stock_with_lot(db, setup_traceability_data):
    lote_code = "LOTE-001"
    expiry = datetime.now() + timedelta(days=365)
    
    InventoryService.add_stock(
        db=db,
        producto_id=setup_traceability_data["producto"].id,
        bodega_id=setup_traceability_data["bodega"].id,
        cantidad=10,
        tipo_movimiento="COMPRA",
        empresa_id=setup_traceability_data["empresa"].id,
        lote_codigo=lote_code,
        fecha_vencimiento=expiry
    )
    
    # Verify InventarioLote
    lote = db.query(InventarioLote).filter_by(lote_codigo=lote_code).first()
    assert lote is not None
    assert lote.cantidad == 10
    assert lote.estado == EstadoLoteEnum.DISPONIBLE

def test_check_expirations(db, setup_traceability_data):
    # Create an expired lot manually (or via add_stock with past date)
    lote_expired_code = "LOTE-EXP-001"
    past_date = datetime.now() - timedelta(days=1)
    
    # We use add_stock but force past date
    # Note: add_stock usually allows past dates if not validating entry logic strictness
    InventoryService.add_stock(
        db=db,
        producto_id=setup_traceability_data["producto"].id,
        bodega_id=setup_traceability_data["bodega"].id,
        cantidad=5,
        tipo_movimiento="COMPRA",
        empresa_id=setup_traceability_data["empresa"].id,
        lote_codigo=lote_expired_code,
        fecha_vencimiento=past_date
    )
    
    # Run check_expirations
    InventoryService.check_expirations(db, setup_traceability_data["empresa"].id)
    
    # Verify lot status changed to VENCIDO
    lote = db.query(InventarioLote).filter_by(lote_codigo=lote_expired_code).first()
    assert lote.estado == EstadoLoteEnum.VENCIDO

def test_fifo_consumption(db, setup_traceability_data):
    # Setup: Add two lots
    prod_id = setup_traceability_data["producto"].id
    bodega_id = setup_traceability_data["bodega"].id
    empresa_id = setup_traceability_data["empresa"].id
    
    # Lot 1: Expiring soon (FEFO priority)
    lote1_code = "LOTE-FIFO-1"
    expiry1 = datetime.now() + timedelta(days=10)
    InventoryService.add_stock(db, prod_id, bodega_id, 10, "COMPRA", empresa_id, 
                             lote_codigo=lote1_code, fecha_vencimiento=expiry1)
                             
    # Lot 2: Expiring later
    lote2_code = "LOTE-FIFO-2"
    expiry2 = datetime.now() + timedelta(days=20)
    InventoryService.add_stock(db, prod_id, bodega_id, 10, "COMPRA", empresa_id, 
                             lote_codigo=lote2_code, fecha_vencimiento=expiry2)
                             
    # Act: Consume 15 units (Should take 10 from Lote 1 and 5 from Lote 2)
    InventoryService.consume_stock(db, prod_id, bodega_id, 15, "VENTA", empresa_id)
    db.flush() # Force flush to ensure objects are in identity map/DB
    
    # Assert
    lote1 = db.query(InventarioLote).filter_by(lote_codigo=lote1_code).first()
    lote2 = db.query(InventarioLote).filter_by(lote_codigo=lote2_code).first()
    
    assert lote1.cantidad == 0
    assert lote2.cantidad == 5
    
    # Check MovimientoStock
    from app.core_modules.inventario.movimientos.models import MovimientoStock
    
    print("\nDEBUG: All Movements in DB:")
    for m in db.query(MovimientoStock).all():
         print(f"Mov: id={m.id}, prod={m.producto_id}, lote={m.lote_id}, qty={m.cantidad}, tipo={m.tipo}")

    all_movs = db.query(MovimientoStock).filter(
        MovimientoStock.producto_id == prod_id,
        MovimientoStock.tipo == "VENTA"
    ).all()
    
    print(f"\nDEBUG: Found {len(all_movs)} VENTA movements for prod {prod_id}.")
    
    mov1 = db.query(MovimientoStock).filter(
        MovimientoStock.lote_id == lote1.id, 
        MovimientoStock.tipo == "VENTA"
    ).first()
    
    mov2 = db.query(MovimientoStock).filter(
        MovimientoStock.lote_id == lote2.id, 
        MovimientoStock.tipo == "VENTA"
    ).first()
    
    assert mov1 is not None, f"Movimiento for lote1 {lote1.id} not found"
    assert mov1.cantidad == -10
    
    assert mov2 is not None, f"Movimiento for lote2 {lote2.id} not found"
    assert mov2.cantidad == -5

def test_stress_check_expirations(db, setup_traceability_data):
    """
    Stress Test: Create 100 lots with mixed expiration dates.
    Verify check_expirations handles them correctly without concurrency errors.
    """
    import random
    
    prod_id = setup_traceability_data["producto"].id
    bodega_id = setup_traceability_data["bodega"].id
    empresa_id = setup_traceability_data["empresa"].id
    
    # 1. Create 100 Lots
    # 30 Expired
    # 30 Expiring Soon (< 6 months)
    # 40 Safe (> 6 months)
    
    print("\nDEBUG: Starting Stress Test (100 lots)...")
    
    lots_created = []
    
    for i in range(100):
        lote_code = f"LOTE-STRESS-{i:03d}"
        
        if i < 30:
            # Expired
            expiry = datetime.now() - timedelta(days=random.randint(1, 100))
        elif i < 60:
            # Expiring Soon
            expiry = datetime.now() + timedelta(days=random.randint(1, 170))
        else:
            # Safe
            expiry = datetime.now() + timedelta(days=random.randint(200, 500))
            
        InventoryService.add_stock(db, prod_id, bodega_id, 10, "COMPRA", empresa_id,
                                 lote_codigo=lote_code, fecha_vencimiento=expiry)
        lots_created.append({"code": lote_code, "expiry": expiry})
        
    db.commit()
    
    # 2. Run check_expirations
    alerts = InventoryService.check_expirations(db, empresa_id)
    
    # 3. Verify Results
    # Check Expired Lots (Should be VENCIDO)
    # Filter by prefix to avoid counting lots from previous tests
    expired_count = db.query(InventarioLote).filter(
        InventarioLote.producto_id == prod_id,
        InventarioLote.estado == EstadoLoteEnum.VENCIDO,
        InventarioLote.lote_codigo.like("LOTE-STRESS-%")
    ).count()
    
    assert expired_count == 30, f"Expected 30 expired lots, found {expired_count}"
    
    # Check Alerts (Should match expiring soon count ~30)
    # Filter alerts to only include stress test lots
    stress_alerts = [a for a in alerts if a["lote_codigo"].startswith("LOTE-STRESS-")]
    
    assert len(stress_alerts) == 30, f"Expected 30 alerts, found {len(stress_alerts)}"
    
    print(f"DEBUG: Stress Test Passed. 30 Expired, {len(alerts)} Alerts.")

def test_transaction_rollback_on_failure(db, setup_traceability_data):
    """
    Verify Transaction Consistency:
    If process_backorders fails (or any step after stock release), 
    the entire transaction (including stock addition) must be rolled back.
    """
    from unittest.mock import patch
    
    prod_id = setup_traceability_data["producto"].id
    bodega_id = setup_traceability_data["bodega"].id
    empresa_id = setup_traceability_data["empresa"].id
    
    initial_stock = 0
    inv = db.query(Inventario).filter_by(producto_id=prod_id, bodega_id=bodega_id).first()
    if inv:
        initial_stock = inv.cantidad
        
    # Mock process_backorders to raise an exception
    with patch('app.core_modules.inventario.stock.services.InventoryService.process_backorders') as mock_method:
        mock_method.side_effect = Exception("Simulated Failure in Backorders")
        
        try:
            InventoryService.add_stock(db, prod_id, bodega_id, 10, "COMPRA", empresa_id,
                                     lote_codigo="LOTE-FAIL", fecha_vencimiento=datetime.now())
            assert False, "Should have raised Exception"
        except Exception as e:
            assert str(e) == "Simulated Failure in Backorders"
            
    # Verify Rollback
    # Stock should be equal to initial_stock (no change)
    db.expire_all() # Clear session cache
    inv_after = db.query(Inventario).filter_by(producto_id=prod_id, bodega_id=bodega_id).first()
    
    current_stock = inv_after.cantidad if inv_after else 0
    assert current_stock == initial_stock, f"Rollback failed. Stock changed from {initial_stock} to {current_stock}"
    
    # Verify Lote was not created
    lote_fail = db.query(InventarioLote).filter_by(lote_codigo="LOTE-FAIL").first()
    assert lote_fail is None, "Rollback failed. Lote 'LOTE-FAIL' was created."

