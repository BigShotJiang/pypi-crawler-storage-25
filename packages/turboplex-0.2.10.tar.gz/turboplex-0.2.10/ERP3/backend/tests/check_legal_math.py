from decimal import Decimal, ROUND_HALF_UP


def round_peso(x: Decimal) -> int:
    return int(x.to_integral_value(rounding=ROUND_HALF_UP))


def main():
    sueldo_base = Decimal("1000000")
    jornada = Decimal("40")
    semanas_prom = Decimal("4.33")

    # Horas normales mensuales
    horas_norm_mes = jornada * semanas_prom  # 173.2

    # Valor hora ordinaria y extra (50%)
    valor_hora_ord = (sueldo_base / horas_norm_mes).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )  # 5,774
    valor_hora_extra = (valor_hora_ord * Decimal("1.5")).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )  # 8,661

    # Gratificación legal tope mensual con IMM=500.000
    imm = Decimal("500000")
    tope_anual = imm * Decimal("4.75")  # 2,375,000
    tope_mensual = (tope_anual / Decimal("12")).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )  # 197,917

    assert int(valor_hora_extra) == 8661, (
        f"Valor hora extra esperado 8661, obtenido {valor_hora_extra}"
    )
    assert int(tope_mensual) == 197917, (
        f"Tope gratificación esperado 197917, obtenido {tope_mensual}"
    )

    print("OK: valor_hora_extra=8661 y gratificacion_tope_mensual=197917")


if __name__ == "__main__":
    main()
