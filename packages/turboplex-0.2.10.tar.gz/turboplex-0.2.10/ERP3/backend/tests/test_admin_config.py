from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.main import app
from app.api import deps
from app.core_modules.sistema.models import Usuario, ParametroGlobal, AuditLog, AuditSeverity


client = TestClient(app)


def _make_superadmin(db: Session) -> Usuario:
    user = Usuario(
        email="config-superadmin@test.local",
        hashed_password="hashed",
        role="SUPERADMIN",
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def test_get_admin_config_defaults(db: Session):
    superadmin = _make_superadmin(db)
    client.app.dependency_overrides[deps.get_current_superadmin] = lambda: superadmin

    response = client.get("/api/v1/admin/config")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "IVA_RATE" in data["data"]

    client.app.dependency_overrides.clear()


def test_update_admin_config_creates_param_and_audit_log(db: Session):
    superadmin = _make_superadmin(db)
    client.app.dependency_overrides[deps.get_current_superadmin] = lambda: superadmin

    payload = {"IVA_RATE": "0.25"}
    response = client.post("/api/v1/admin/config", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body["data"]["IVA_RATE"] == "0.25"

    db_param = (
        db.query(ParametroGlobal)
        .filter(ParametroGlobal.empresa_id.is_(None), ParametroGlobal.llave == "IVA_RATE")
        .first()
    )
    assert db_param is not None
    assert db_param.valor == "0.25"

    audit = (
        db.query(AuditLog)
        .filter(
            AuditLog.actor_id == superadmin.id,
            AuditLog.action == "CONFIG_UPDATE",
            AuditLog.resource == "GLOBAL:IVA_RATE",
        )
        .order_by(AuditLog.created_at.desc())
        .first()
    )
    assert audit is not None
    assert audit.severity == AuditSeverity.INFO
    assert audit.changes is not None
    assert audit.changes.get("after") == "0.25"

    client.app.dependency_overrides.clear()

