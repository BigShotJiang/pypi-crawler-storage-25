import pytest
from sqlalchemy.exc import IntegrityError
from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto
from app.core_modules.inventario.stock.models import Inventario
from app.core_modules.inventario.movimientos.models import MovimientoStock
import uuid

@pytest.fixture(scope="module")
def db():
    session = SessionLocal()
    # Bypass tenant validation for integrity tests
    session.info["allow_no_tenant"] = True
    session.expire_on_commit = False
    yield session
    session.close()

@pytest.fixture(scope="module")
def setup_data(db):
    # Create unique codes for this test run
    suffix = str(uuid.uuid4())[:8]
    
    # 1. Create Empresa
    empresa = Empresa(
        nombre=f"Test Inventory Integrity {suffix}",
        codigo=f"INV_TEST_{suffix}",
        is_active=True
    )
    db.add(empresa)
    db.commit()
    db.refresh(empresa)
    db.info["empresa_id"] = empresa.id
    db.info["allow_no_tenant"] = False

    # 2. Create Sucursal
    sucursal = Sucursal(
        nombre=f"Sucursal Test {suffix}",
        empresa_id=empresa.id,
        direccion="Test Address"
    )
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)

    # 3. Create Bodega
    bodega = Bodega(
        nombre=f"Bodega Test {suffix}",
        sucursal_id=sucursal.id
    )
    db.add(bodega)
    db.commit()
    db.refresh(bodega)

    return {
        "empresa": empresa,
        "sucursal": sucursal,
        "bodega": bodega,
        "suffix": suffix
    }

def test_inventory_creation_and_stock_reservado(db, setup_data):
    """
    Test creation of inventory and 'Stock Reservado' logic.
    Ensures that physical stock and reserved stock are tracked correctly.
    """
    bodega = setup_data["bodega"]
    suffix = setup_data["suffix"]

    # Create Product
    producto = Producto(
        nombre=f"Prod Stock {suffix}",
        sku=f"PROD_STK_{suffix}",
        precio=100.0,
        empresa_id=setup_data["empresa"].id,
        tipo_producto="ALMACENABLE"
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)

    # Create Inventory
    inventario = Inventario(
        producto_id=producto.id,
        bodega_id=bodega.id,
        cantidad=100,  # Physical stock
        cantidad_reservada=0,
        stock_minimo=5
    )
    db.add(inventario)
    db.commit()
    db.refresh(inventario)

    # Verify initial state
    assert inventario.cantidad == 100
    assert inventario.cantidad_reservada == 0
    # Available stock should be physical - reserved
    assert (inventario.cantidad - inventario.cantidad_reservada) == 100

    # Simulate reservation (e.g., a sale is pending)
    inventario.cantidad_reservada = 20
    db.commit()
    db.refresh(inventario)

    # Verify reserved state
    assert inventario.cantidad == 100  # Physical stock hasn't moved yet
    assert inventario.cantidad_reservada == 20
    assert (inventario.cantidad - inventario.cantidad_reservada) == 80

    # Simulate sale confirmation (reduce physical, reduce reserved)
    inventario.cantidad -= 20
    inventario.cantidad_reservada -= 20
    db.commit()
    db.refresh(inventario)

    # Verify final state
    assert inventario.cantidad == 80
    assert inventario.cantidad_reservada == 0
    assert (inventario.cantidad - inventario.cantidad_reservada) == 80

def test_cascade_delete_product(db, setup_data):
    """
    Test that deleting a Product deletes its Inventory (CASCADE)
    BUT fails if there are Movements (RESTRICT).
    """
    bodega = setup_data["bodega"]
    empresa = setup_data["empresa"]
    suffix = setup_data["suffix"]

    # Create Product
    producto = Producto(
        nombre=f"Prod Cascade {suffix}",
        sku=f"PROD_CAS_{suffix}",
        precio=100.0,
        empresa_id=empresa.id,
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)

    # Create Inventory
    inventario = Inventario(
        producto_id=producto.id,
        bodega_id=bodega.id,
        cantidad=50
    )
    db.add(inventario)
    db.commit()
    db.refresh(inventario)

    # 1. Verify Inventory exists
    inv_check = db.query(Inventario).filter_by(id=inventario.id).first()
    assert inv_check is not None

    # 2. Create Movement (which should RESTRICT deletion)
    movimiento = MovimientoStock(
        producto_id=producto.id,
        bodega_id=bodega.id,
        empresa_id=empresa.id,
        cantidad=50,
        tipo="ENTRADA_INICIAL"
    )
    db.add(movimiento)
    db.commit()

    # 3. Try to delete Product -> Should FAIL due to Movement
    db.delete(producto)
    try:
        db.commit()
        pytest.fail("Should have raised IntegrityError due to RESTRICT on MovimientoStock")
    except IntegrityError:
        db.rollback() # Recover session

    # 4. Delete Movement manually
    db.delete(movimiento)
    db.commit()

    # 5. Delete Product -> Should SUCCEED now (Inventory should CASCADE)
    db.delete(producto)
    db.commit()

    # 6. Verify Inventory is GONE
    inv_check_after = db.query(Inventario).filter_by(id=inventario.id).first()
    assert inv_check_after is None

def test_cascade_delete_bodega(db, setup_data):
    """
    Test that deleting a Bodega deletes its Inventory (CASCADE)
    BUT fails if there are Movements (RESTRICT).
    """
    sucursal = setup_data["sucursal"]
    empresa = setup_data["empresa"]
    suffix = setup_data["suffix"]

    # Create a specific Bodega for this test to avoid affecting shared one
    bodega_temp = Bodega(
        nombre=f"Bodega Cascade {suffix}",
        sucursal_id=sucursal.id
    )
    db.add(bodega_temp)
    db.commit()
    db.refresh(bodega_temp)

    # Create Product
    producto = Producto(
        nombre=f"Prod Bodega Cascade {suffix}",
        sku=f"PROD_BOD_{suffix}",
        precio=100.0,
        empresa_id=empresa.id,
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)

    # Create Inventory
    inventario = Inventario(
        producto_id=producto.id,
        bodega_id=bodega_temp.id,
        cantidad=10
    )
    db.add(inventario)
    db.commit()

    # 1. Create Movement linked to Bodega
    movimiento = MovimientoStock(
        producto_id=producto.id,
        bodega_id=bodega_temp.id,
        empresa_id=empresa.id,
        cantidad=10,
        tipo="ENTRADA_TEST"
    )
    db.add(movimiento)
    db.commit()

    # 2. Try to delete Bodega -> Should FAIL due to Movement
    db.delete(bodega_temp)
    try:
        db.commit()
        pytest.fail("Should have raised IntegrityError due to RESTRICT on MovimientoStock")
    except IntegrityError:
        db.rollback()

    # 3. Delete Movement
    db.delete(movimiento)
    db.commit()

    # 4. Delete Bodega -> Should SUCCEED (Inventory CASCADE)
    db.delete(bodega_temp)
    db.commit()

    # 5. Verify Inventory is GONE
    inv_check = db.query(Inventario).filter_by(id=inventario.id).first()
    assert inv_check is None
