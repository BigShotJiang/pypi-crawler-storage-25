import sys

# Forzar codificación UTF-8 en stdout/stderr
sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

NEW_DB_NAME = "erp3_db"
APP_USER = "erp3_user"
APP_PASSWORD = "erp3_pass_2026"

# Lista de credenciales a probar para el superusuario 'postgres'
credentials_to_try = [
    ("postgres", "erp3_pass_2026"),
    ("postgres", "keita_Izumi"),
    ("postgres", "postgres"),
    ("postgres", "admin"),
    ("postgres", "root"),
    ("postgres", "1234"),
    ("postgres", "keita_Izumi"),
    ("postgres", ""),
]


def try_connect_and_create():
    conn = None

    print("Iniciando intentos de conexión con credenciales comunes...")

    for user, pwd in credentials_to_try:
        try:
            print(f"Probando usuario='{user}', password='{pwd}'...")
            dsn = f"postgresql://{user}:{pwd}@127.0.0.1:5432/postgres"

            # Intentamos conectar. Si falla la autenticación, lanzará excepción (posiblemente UnicodeDecodeError)
            conn = psycopg2.connect(dsn)
            conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

            print(f"¡ÉXITO! Conectado con user='{user}', password='{pwd}'")
            break
        except Exception as e:
            # Capturamos el error pero no lo imprimimos completo si es UnicodeDecodeError
            err_str = repr(e)
            if (
                "authentication" in err_str
                or "autenticaci" in err_str
                or "UnicodeDecodeError" in err_str
            ):
                print(f"Falló autenticación con {user}/{pwd}")
            else:
                print(f"Error desconocido con {user}/{pwd}: {err_str}")

    if not conn:
        print("CRÍTICO: No se pudo conectar a PostgreSQL con ninguna credencial común.")
        return False

    try:
        cursor = conn.cursor()

        # 1. Crear el usuario de la aplicación si no existe
        print(f"Configurando usuario de aplicación '{APP_USER}'...")
        try:
            cursor.execute(f"CREATE USER {APP_USER} WITH PASSWORD '{APP_PASSWORD}';")
            print(f"Usuario '{APP_USER}' creado.")
        except psycopg2.errors.DuplicateObject:
            print(f"Usuario '{APP_USER}' ya existe. Actualizando contraseña...")
            cursor.execute(f"ALTER USER {APP_USER} WITH PASSWORD '{APP_PASSWORD}';")

        # Darle permisos de superuser o creadb para evitar problemas futuros en desarrollo
        cursor.execute(f"ALTER USER {APP_USER} CREATEDB;")

        # 1.5 Terminar conexiones existentes
        print(f"Terminando conexiones a '{NEW_DB_NAME}'...")
        cursor.execute(f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '{NEW_DB_NAME}' AND pid <> pg_backend_pid();")

        # 2. Recrear la base de datos
        print(f"Borrando base de datos '{NEW_DB_NAME}' si existe...")
        cursor.execute(f"DROP DATABASE IF EXISTS {NEW_DB_NAME};")

        print(f"Creando base de datos '{NEW_DB_NAME}' con dueño '{APP_USER}'...")
        cursor.execute(
            f"CREATE DATABASE {NEW_DB_NAME} OWNER {APP_USER} ENCODING 'UTF8';"
        )

        print(f"¡Base de datos '{NEW_DB_NAME}' creada exitosamente!")

        cursor.close()
        conn.close()
        return True

    except Exception as e:
        print(f"ERROR durante la configuración de la BD: {repr(e)}")
        if conn:
            conn.close()
        return False


if __name__ == "__main__":
    if try_connect_and_create():
        print("PROCESO COMPLETADO EXITOSAMENTE.")
    else:
        print("PROCESO FALLIDO.")
        sys.exit(1)
