import asyncio
import logging
from unittest.mock import MagicMock, patch

# Configure logging to see output
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_event_system():
    print("--- Testing Event System (Full Integration) ---")

    # 1. Setup Environment
    with (
        patch(
            "app.core_modules.finanzas.listeners.SessionLocal"
        ) as mock_session_finanzas,
        patch("app.core_modules.ventas.listeners.SessionLocal") as mock_session_ventas,
        patch(
            "app.core_modules.notificaciones.listeners.SessionLocal"
        ) as mock_session_notificaciones,
    ):
        # Setup mocks
        mock_db_finanzas = MagicMock()
        mock_session_finanzas.return_value = mock_db_finanzas

        mock_db_ventas = MagicMock()
        mock_session_ventas.return_value = mock_db_ventas

        mock_db_notificaciones = MagicMock()
        mock_session_notificaciones.return_value = mock_db_notificaciones

        # Mock Order for Finanzas/Ventas
        mock_orden_standard = MagicMock()
        mock_orden_standard.id = 999
        mock_orden_standard.venta.empresa_id = 1
        mock_orden_standard.venta.sucursal_id = 1
        mock_orden_standard.venta.detalles = []

        # Mock Order for Notificaciones (VIP)
        mock_orden_vip = MagicMock()
        mock_orden_vip.id = 8888
        mock_orden_vip.venta.total = 100000  # VIP Amount > 50.000

        # Configure return values
        mock_db_finanzas.query.return_value.filter.return_value.first.return_value = (
            mock_orden_standard
        )
        mock_db_ventas.query.return_value.filter.return_value.first.return_value = (
            mock_orden_standard
        )
        mock_db_notificaciones.query.return_value.filter.return_value.first.return_value = mock_orden_vip

        # 2. Register Listeners
        from app.core_modules.finanzas import listeners as finanzas_listeners
        from app.core_modules.ventas import listeners as ventas_listeners
        from app.core_modules.notificaciones import (
            listeners as notificaciones_listeners,
        )
        from app.core.events import event_dispatcher

        finanzas_listeners.register_listeners()
        ventas_listeners.register_listeners()
        notificaciones_listeners.register_listeners()

        print("✅ Listeners Registered")

        # 3. Dispatch Event (VIP Sale)
        payload = {"orden_id": 8888, "usuario_id": 1}
        print(f"🚀 Dispatching EVENT_ORDEN_FINALIZADA (VIP) with payload: {payload}")

        # We capture logs to verify the warning
        with patch.object(logging.Logger, "warning") as mock_log_warning:
            await event_dispatcher.dispatch("EVENT_ORDEN_FINALIZADA", payload)

            # 4. Verification
            print("✅ Event Dispatched")

            # Check if Notificaciones Listener queried DB
            if mock_session_notificaciones.called:
                print("✅ Notificaciones Listener triggered (SessionLocal called)")
            else:
                print("❌ Notificaciones Listener NOT triggered")

            # Check for the specific log message
            # We look for any call to warning that contains the expected string
            vip_log_found = False
            for call in mock_log_warning.call_args_list:
                args, _ = call
                if "[NOTIFICACIÓN] ¡Venta de alto valor detectada!" in args[0]:
                    vip_log_found = True
                    print(f"✅ VIP Log Detected: {args[0]}")
                    break

            if not vip_log_found:
                print("❌ VIP Log NOT found")


if __name__ == "__main__":
    asyncio.run(test_event_system())
