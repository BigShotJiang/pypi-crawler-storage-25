# ERP3 - Sistema ERP Modular

Sistema ERP modular desarrollado con **FastAPI** (backend) y **Vue 3** (frontend).

---

## 🚀 Estado del Proyecto

| Componente | Estado | Versión | Detalles |
|------------|--------|---------|----------|
| **Backend** | ✅ Operativo | 0.123.0 | FastAPI + SQLAlchemy + Alembic |
| **Base de Datos** | ✅ Conectada | PostgreSQL 15+ | Configurada con script automático |
| **Frontend** | 🚧 En Desarrollo | 0.1.0 | Vue 3 + Pinia + TailwindCSS |

**Última actualización**: 2026-03-20

---

## 📋 Requisitos Previos

- **Python 3.10+** (Backend)
- **PostgreSQL 15+** (Base de Datos)
- **Node.js 18+** (Frontend)

---

## 🔧 Guía de Instalación

### 1. Backend (API)

```bash
cd backend
python -m venv .venv
# Activar entorno (Windows: .venv\Scripts\Activate.ps1 | Linux: source .venv/bin/activate)
pip install -r requirements.txt
python create_db.py
python -m uvicorn app.main:app --reload
```

### 2. Frontend (UI)

```bash
cd frontend
npm install
npm run dev
```

El frontend estará disponible en: [http://localhost:5173](http://localhost:5173)

---

## 📦 Carga Masiva de Inventario (Plantillas Dinámicas)

Flujo recomendado:

1. Seleccionar Excel y analizar headers.
2. Elegir una plantilla guardada o mapear manualmente (SKU, Cantidad, Bodega, Costo).
3. Procesar y revisar `staging_key` si existen filas fallidas.
4. Ejecutar Validation / Apply según permisos.

Notas importantes:

- **Bodega**: la columna mapeada debe contener el `Bodega.codigo` (código técnico) configurado en Sucursales/Bodegas.
- **Atributos adicionales**: se pueden mapear columnas extra del Excel (`additional_attributes`). Las claves se sanitizan, pero no se omiten; quedan disponibles en staging para auditoría/errores.

---

## ✅ Calidad (comandos)

Backend (desde `backend/` con `.venv` activo):

```bash
./.venv/Scripts/python.exe -m ruff check app/services/import_service app/core_modules/inventario/stock
./.venv/Scripts/python.exe -m pytest -q
```

Frontend (desde `frontend/`):

```bash
npm run typecheck
```

---

## 🧩 Módulos Activos

- **Ventas**: Gestión de ventas, cotizaciones, facturas y notas de crédito.
- **Inventario**: Control de stock, bodegas, movimientos y trazabilidad (lotes/vencimiento).
- **Finanzas**: Contabilidad, libro diario, balance de 8 columnas y gestión de gastos.
- **RRHH**: Gestión de recursos humanos.
- **CRM**: Gestión de clientes y oportunidades.
- **Compras**: Gestión de proveedores y órdenes de compra.

---

## 📂 Estructura del Proyecto

```
ERP3/
├── backend/            # API REST (FastAPI)
│   ├── app/            # Lógica de negocio y modelos
│   └── ...
├── frontend/           # Interfaz de Usuario (Vue 3)
│   ├── src/            # Componentes, Vistas y Stores
│   └── ...
└── .Documentacion/     # Documentación técnica y funcional
```
