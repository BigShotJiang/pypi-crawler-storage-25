import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

try:
    print("Attempting to import api_router...")
    print("Successfully imported api_router")
    
    print("Attempting to import models...")
    print("Successfully imported models")
    
    print("Attempting to import schemas...")
    print("Successfully imported schemas")
    
    print("Verification passed!")
except Exception as e:
    print(f"Verification failed: {e}")
    import traceback
    traceback.print_exc()
