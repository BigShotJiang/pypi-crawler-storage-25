from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api import deps
from app.core_modules.ventas.models import OrdenServicio, EstadoOrdenServicio

router = APIRouter(tags=["Inventory Alert"])

MODULE_NAME = "Inventory Alert Plugin"
MODULE_DESCRIPTION = "Estimación REAL de uso de detergente basado en Recetas"
MODULE_TYPE = "utility"

@router.get("/api/v1/inventory-alert")
def get_inventory_alert(db: Session = Depends(deps.get_db)):
    # 1. Get Orders in Process
    orders = db.query(OrdenServicio).filter(OrdenServicio.estado == EstadoOrdenServicio.EN_PROCESO).all()
    
    total_detergent_ml = 0.0
    orders_count = len(orders)
    
    for order in orders:
        # 2. Get the Sale Details linked to this Order
        if not order.venta:
            continue
            
        for detalle in order.venta.detalles:
            # 3. Check if Product has Recipe
            producto = detalle.producto
            if producto and producto.receta:
                # 4. Sum Ingredients
                cantidad_servicios = detalle.cantidad
                
                for insumo in producto.receta.insumos:
                    # We assume 'ML' unit is for liquid detergents/softeners
                    if insumo.unidad_medida == "ML":
                        total_detergent_ml += (float(insumo.cantidad) * cantidad_servicios)

    return {
        "orders_in_process": orders_count,
        "estimated_detergent_usage_ml": total_detergent_ml,
        "unit": "ml",
        "status": "active",
        "calculation_method": "recipe_based"
    }
