
import sys
import os
from dotenv import load_dotenv

# Add backend directory to path
backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'backend'))
sys.path.append(backend_path)

# Load .env file
load_dotenv(os.path.join(backend_path, '.env'))

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Usuario, UsuarioEmpresa, Rol
from app.core.security import get_password_hash

def create_multirut_data():
    db = SessionLocal()
    try:
        # 1. Create User
        email = "multi@erp3.com"
        user = db.query(Usuario).filter(Usuario.email == email).first()
        if not user:
            print(f"Creating user {email}...")
            user = Usuario(
                email=email,
                hashed_password=get_password_hash("admin123"),
                is_active=True,
                role="ADMIN" # SaaS Admin
            )
            db.add(user)
            db.commit()
            db.refresh(user)
        else:
            print(f"User {email} already exists.")

        # 2. Create 3 Companies
        companies_data = [
            {"rut": "76.111.111-1", "nombre": "Empresa Alpha Ltda", "codigo": "ALPHA"},
            {"rut": "76.222.222-2", "nombre": "Empresa Beta SpA", "codigo": "BETA"},
            {"rut": "76.333.333-3", "nombre": "Empresa Gamma SA", "codigo": "GAMMA"}
        ]

        for c_data in companies_data:
            company = db.query(Empresa).filter(Empresa.rut == c_data["rut"]).first()
            if not company:
                print(f"Creating company {c_data['nombre']}...")
                company = Empresa(
                    rut=c_data["rut"],
                    nombre=c_data["nombre"],
                    codigo=c_data["codigo"],
                    modulos_activos=["CORE", "VENTAS", "FINANZAS", "TI", "SISTEMA"] # Default modules
                )
                db.add(company)
                db.commit()
                db.refresh(company)

                # Seed default roles per company
                default_roles = [
                    ("ADM", "Administrador Único de Empresa"),
                    ("SUP", "Supervisor"),
                    ("VEN", "Vendedor"),
                    ("BOD", "Bodeguero"),
                    ("CON", "Contador"),
                ]
                for codigo, nombre in default_roles:
                    role = Rol(
                        empresa_id=company.id,
                        codigo=codigo,
                        nombre=nombre,
                        is_active=True,
                    )
                    db.add(role)
                db.commit()
            
            # 3. Associate User with Company
            assoc = db.query(UsuarioEmpresa).filter_by(usuario_id=user.id, empresa_id=company.id).first()
            if not assoc:
                print(f"Associating {user.email} with {company.nombre}...")
                assoc = UsuarioEmpresa(
                    usuario_id=user.id,
                    empresa_id=company.id,
                    is_default=(c_data["rut"] == "76.111.111-1") # Make Alpha default
                )
                db.add(assoc)
                db.commit()
            else:
                print(f"User already associated with {company.nombre}")

        print("Multi-RUT data created successfully.")

    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_multirut_data()
