import sys
import os
from dotenv import load_dotenv

# Add backend directory to path
backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'backend'))
sys.path.append(backend_path)

# Load .env
load_dotenv(os.path.join(backend_path, '.env'))

try:
    from app.verticals.lavanderia.schemas import TicketLavanderia
    print("Import successful")
    # Verify the field exists
    if 'producto' in TicketLavanderia.model_fields:
        print("Field 'producto' found in TicketLavanderia")
    else:
        print("Field 'producto' NOT found in TicketLavanderia")
        sys.exit(1)
except ImportError as e:
    print(f"Import failed: {e}")
    sys.exit(1)
except Exception as e:
    print(f"An error occurred: {e}")
    sys.exit(1)
