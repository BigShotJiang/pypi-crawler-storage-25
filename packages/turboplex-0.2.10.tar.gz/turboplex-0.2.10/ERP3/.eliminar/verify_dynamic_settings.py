import sys
import os
from dotenv import load_dotenv

# Add backend directory to path
backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'backend'))
sys.path.append(backend_path)

# Load .env file
load_dotenv(os.path.join(backend_path, '.env'))

from app.core.database import SessionLocal, engine, Base
# Import ALL models to ensure relationships are registered correctly
from app.core_modules.ventas import models as ventas_models
from app.core.models import Setting
from app.core.config_manager import config_manager
from app.core_modules.notificaciones.listeners import handle_vip_sale_notification
# from app.core_modules.ventas.models import OrdenServicio, Venta # Already imported via ventas_models
from unittest.mock import MagicMock, patch
import asyncio

# --- Seed Execution ---
def run_seed():
    print("--- 1. Ejecutando Seed de Settings ---")
    # Import the seed script logic directly or replicate relevant parts
    # Here we simulate what init_pcu_company_1.py does for settings
    db = SessionLocal()
    try:
        # Create table if not exists (in case it wasn't created yet)
        Base.metadata.create_all(bind=engine)

        settings_data = [
            {"key": "VENTA_VIP_MINIMO", "value": 50000, "type": "int", "desc": "Monto mínimo para considerar venta VIP"},
            {"key": "NOTIFICACIONES_ACTIVAS", "value": True, "type": "bool", "desc": "Switch maestro de notificaciones"},
            {"key": "DIAS_ALERTA_STOCK_PROYECTADO", "value": 7, "type": "int", "desc": "Días de proyección para alerta de stock"}
        ]

        for s_data in settings_data:
            setting = db.query(Setting).filter(Setting.key == s_data["key"]).first()
            if not setting:
                setting = Setting(key=s_data["key"], value=s_data["value"], type=s_data["type"], description=s_data["desc"])
                db.add(setting)
            else:
                setting.value = s_data["value"]
                setting.type = s_data["type"]
            db.commit()
        print("✅ Settings seeded in DB.")
    except Exception as e:
        print(f"❌ Error seeding: {e}")
        db.rollback()
    finally:
        db.close()

# --- Verification ---
def verify_config_manager():
    print("\n--- 2. Verificando ConfigManager ---")
    config_manager.refresh() # Force reload
    
    val_vip = config_manager.get_setting("VENTA_VIP_MINIMO")
    val_notif = config_manager.get_setting("NOTIFICACIONES_ACTIVAS")
    val_days = config_manager.get_setting("DIAS_ALERTA_STOCK_PROYECTADO")
    
    print(f"VENTA_VIP_MINIMO: {val_vip} (Expected: 50000)")
    print(f"NOTIFICACIONES_ACTIVAS: {val_notif} (Expected: True)")
    print(f"DIAS_ALERTA_STOCK_PROYECTADO: {val_days} (Expected: 7)")
    
    if val_vip == 50000 and val_notif is True and val_days == 7:
        print("✅ ConfigManager reads correctly.")
    else:
        print("❌ ConfigManager read failed.")

async def verify_listeners():
    print("\n--- 3. Verificando Listeners (Mock) ---")
    
    # Mock data
    mock_orden = MagicMock(spec=ventas_models.OrdenServicio)
    mock_orden.id = 999
    mock_orden.venta = MagicMock(spec=ventas_models.Venta)
    mock_orden.venta.total = 60000 # > 50000

    # Patch SessionLocal to return a mock session that returns our mock_orden
    with patch("app.core_modules.notificaciones.listeners.SessionLocal") as mock_session_cls:
        mock_db = MagicMock()
        mock_session_cls.return_value = mock_db
        mock_db.query.return_value.filter.return_value.first.return_value = mock_orden
        
        # Patch logger to verify output
        with patch("app.core_modules.notificaciones.listeners.logger") as mock_logger:
            # Case A: VIP Sale (60000 > 50000)
            await handle_vip_sale_notification({"orden_id": 999})
            
            if mock_logger.warning.called:
                print("✅ Notification triggered for VIP sale (60000 > 50000).")
            else:
                print("❌ Notification NOT triggered for VIP sale.")

            # Case B: Change Threshold to 100000
            print("   -> Changing threshold to 100000...")
            config_manager.set_setting("VENTA_VIP_MINIMO", 100000, "int")
            
            mock_logger.reset_mock()
            await handle_vip_sale_notification({"orden_id": 999})
            
            if not mock_logger.warning.called:
                print("✅ Notification correctly IGNORED (60000 < 100000).")
            else:
                print("❌ Notification triggered incorrectly after threshold increase.")

if __name__ == "__main__":
    run_seed()
    verify_config_manager()
    asyncio.run(verify_listeners())
