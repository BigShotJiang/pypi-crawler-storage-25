## Objetivo
Eliminar el renderizado de `$NaN` en la columna **PRECIO** de `/inventory/items` y dejar el formateo robusto frente a datos inválidos/incompletos.

## Causa probable
- La tabla de items usa el campo `precio_venta`.
- El render aplica `formatCurrency(value)` directamente.
- Si `value` llega como `undefined`, `null`, string vacío, o no numérico, el formateo termina mostrando `$NaN`.

## Cambios propuestos

### 1) Blindar el formateador de moneda
**Archivo:** `frontend/src/views/inventory/InventarioGlobal.vue`

- Ajustar `formatCurrency` para:
  - Normalizar con `const n = Number(value)`.
  - Si `!Number.isFinite(n)`, devolver fallback estable (`'$0'` o `'—'`, según criterio UI que ya use la vista).
  - Si es válido, formatear con `Intl.NumberFormat('es-CL', ...)`.

**Resultado esperado:** Nunca se renderiza `$NaN` aunque entren datos sucios.

---

### 2) Normalizar `precio_venta` al cargar productos
**Archivo:** `frontend/src/stores/inventario.ts`

- En `fetchProducts`, normalizar cada producto antes de guardarlo:
  - `precio_venta` -> número finito.
  - Si no es finito, asignar `0` (o `null` + fallback en UI; recomendación: `0` por consistencia con KPI/valorización).

**Resultado esperado:** El estado del store mantiene datos coherentes para toda la UI.

---

### 3) Verificar el punto de render de la columna precio
**Archivo:** `frontend/src/views/inventory/InventarioGlobal.vue`

- Confirmar que la columna `PRECIO` sigue leyendo `precio_venta`.
- Mantener template `#cell-precio_venta` usando el formateador blindado.

**Resultado esperado:** Sin cambios funcionales colaterales en columnas/acciones.

---

### 4) (Opcional defensivo) Normalización en servicio
**Archivo:** `frontend/src/services/inventario.service.ts`

- Mantener servicio tipado y sin lógica de UI.
- Solo si hay payload inconsistente frecuente, agregar helper mínimo de parseo antes de retornar datos.

**Resultado esperado:** Menor propagación de valores inválidos desde la capa de acceso.

## Validación / DoD
- En `/inventory/items`, una fila con precio inválido ya no muestra `$NaN`.
- `PRECIO` muestra valor numérico formateado o fallback definido.
- No rompe creación/edición de producto.
- `vue-tsc --noEmit` sin errores.
- `vite build` sin errores.

## Trazabilidad (paso → targets → verificación)
- **Paso 1** → `InventarioGlobal.vue` (`formatCurrency`) → comprobar que entradas inválidas no producen `NaN`.
- **Paso 2** → `stores/inventario.ts` (`fetchProducts`) → inspeccionar estado `products[].precio_venta` numérico.
- **Paso 3** → `InventarioGlobal.vue` (celda `#cell-precio_venta`) → validar render en tabla `/inventory/items`.
- **Paso 4** → typecheck/build → confirmar que el fix no introduce regresiones.

## Riesgos y mitigación
- **Riesgo:** ocultar datos corruptos de backend con fallback `0`.
- **Mitigación:** dejar fallback visual explícito si prefieres (`'—'`) y registrar warning en consola en desarrollo para detectar payloads inválidos.