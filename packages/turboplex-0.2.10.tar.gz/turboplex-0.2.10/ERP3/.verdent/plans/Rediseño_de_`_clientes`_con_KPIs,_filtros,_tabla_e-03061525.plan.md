## Objetivo

Transformar la vista `'/clientes'` para que se vea completa y útil desde el primer día, incorporando:

* navegación interna: **Todos los Clientes / Segmentos / Prospectos / Historial de Compras / Documentos**

* KPIs superiores

* toolbar de tabla (buscar, filtrar segmento, exportar CSV)

* empty state accionable

* filas enriquecidas

* drawer lateral con detalle del cliente (sin navegar a otra página)

***

## Alcance funcional

### 1) Navegación interna en `/clientes`

* Implementar Sideboard e `ClientesPage`:

  * `Todos los Clientes`

  * `Segmentos`

  * `Prospectos`

  * `Historial de Compras`

  * `Documentos`

* Primera versión:

  * **Todos los Clientes**: fully funcional (tabla + drawer)

  * Las otras pestañas: vistas funcionales mínimas (placeholder estructurado + métricas/listados básicos con datos existentes/fallback).

### 2) KPIs en cabecera

* 4 tarjetas:

  * `Total clientes`

  * `Activos`

  * `Ventas acumuladas`

  * `Clientes Premium`

* Cálculo desde `ventasStore.clientes` con fallback seguro cuando faltan campos.

* Formato monetario CLP consistente.

### 3) Toolbar de tabla

* Buscador por texto (nombre, rut, email, teléfono)

* Filtro por segmento (`Premium`, `Estándar`, `Básico`)

* Botón `Exportar CSV` sobre dataset filtrado

* Mantener botón `+ Nuevo Cliente`.

### 4) Empty state mejorado

* Reemplazar mensaje vacío simple por bloque accionable:

  * texto: `Aún no hay clientes — importa desde Excel o agrega el primero`

  * botón `Importar Excel` (primera iteración: acción stub / evento)

  * botón `Agregar primer cliente` (abre `/clientes/new`)

### 5) Filas de tabla enriquecidas

* En columna nombre:

  * avatar con iniciales

  * nombre + metadata corta

* Segmento con badge coloreado

* Estado activo/inactivo con punto de color + label

* `Última actividad` como fecha amigable

* Click en fila abre drawer de detalle.

### 6) Drawer lateral de detalle

* Abrir desde click en fila (sin `router.push`)

* Contenido por secciones:

  * Resumen cliente

  * Historial (actividad/compras recientes)

  * Contactos

  * Documentos

* Acciones dentro del drawer:

  * `Editar` (navega al detalle actual)

  * `Cerrar`

***

## Archivos a modificar

### Principal

* `frontend/src/views/ventas/ClientesPage.vue`

  * incorporar tabs, KPIs, toolbar, filtros, exportación, empty state avanzado

  * enriquecer render de filas

  * agregar estado/control del drawer y selected client

### Reutilizables UI

* `frontend/src/components/ui/DataTable.vue`

  * extender para soportar empty state custom por slot (sin romper uso actual)

  * mantener `row-click` tipado

### Utilidades

* `frontend/src/utils/export.ts`

  * reutilizar `exportToCSV` existente con mapeo de columnas de clientes

  * sin cambios de API pública salvo que sea necesario añadir helper opcional de normalización

### (Opcional recomendado) Nuevo componente

* `frontend/src/components/ventas/ClientDetailDrawer.vue`

  * encapsular drawer para mantener `ClientesPage` limpia

  * props tipadas del cliente seleccionado

  * emits: `close`, `edit`

***

## Modelo de datos de UI (derivado/fallback)

Como no todos los campos pueden venir del backend hoy, normalizar en frontend:

* `segmento`: `premium | estandar | basico` (derivado por reglas de negocio mínimas; fallback `basico`)

* `activo`: boolean (fallback `true`)

* `ultimaActividad`: fecha o `null` (fallback `—`)

* `ventasAcumuladas`: number (fallback `0`)

Esto permite una experiencia rica sin bloquear por disponibilidad total de backend.

***

## Estrategia de implementación

1. **Refactor controlado de** **`ClientesPage`**

   * separar estado de UI (tab activa, query, filtros, cliente seleccionado)

   * crear computeds: dataset enriquecido, dataset filtrado, KPIs, export rows

2. **Tabla enriquecida**

   * nuevas columnas: `cliente`, `segmento`, `estado`, `ultima_actividad`, `acciones`

   * mantener compatibilidad con acciones existentes (`editar`, `eliminar`)

3. **Drawer de detalle**

   * abrir/cerrar por estado local

   * contenido modular por bloques (historial/contactos/documentos)

4. **Empty state accionable**

   * slot/markup propio cuando dataset filtrado está vacío

5. **Pulido UX**

   * hover, jerarquía visual, badges, iconografía, accesibilidad básica

***

## Riesgos y mitigación

* **Campos faltantes en backend** → usar normalización/fallback sin romper UI.

* **Página demasiado grande** → extraer `ClientDetailDrawer.vue`.

* **Regresión en DataTable** → extensión backward-compatible por slot opcional.

***

## Verificación (DoD)

* `/clientes` muestra tabs y KPI cards aunque dataset esté vacío.

* Buscador + filtro segmento afectan la tabla correctamente.

* Export CSV descarga dataset filtrado.

* Empty state muestra mensaje y 2 acciones visibles.

* Click en fila abre drawer con datos del cliente seleccionado.

* `Editar` desde drawer navega al detalle actual.

* `npx vue-tsc --noEmit` sin errores.

* `npx vite build` sin errores.

***

## Trazabilidad (paso → targets → verificación)

* **Tabs + KPIs** → `ClientesPage.vue` → render correcto con/sin datos.

* **Toolbar + filtros + CSV** → `ClientesPage.vue`, `export.ts` → dataset filtrado/exportado consistente.

* **Tabla enriquecida** → `ClientesPage.vue`, `DataTable.vue` → badges/estado/actividad visibles.

* **Drawer detalle** → `ClientesPage.vue` + `ClientDetailDrawer.vue` (si se crea) → apertura/cierre/acciones OK.

* **Calidad** → typecheck/build → sin errores de TS/compilación.
