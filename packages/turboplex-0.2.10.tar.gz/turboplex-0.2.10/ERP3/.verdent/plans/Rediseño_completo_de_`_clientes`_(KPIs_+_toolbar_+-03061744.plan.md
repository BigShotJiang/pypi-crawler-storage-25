## Objetivo
Completar el rediseño de `'/clientes'` para que tenga una experiencia rica y operativa desde el primer día, manteniendo el esquema ya migrado de submódulos en sidebar.

## Alcance
Aplicar en `frontend/src/views/ventas/ClientesPage.vue`:
- KPIs superiores (4 tarjetas)
- Toolbar (búsqueda + filtro segmento + export CSV)
- Empty state accionable
- Tabla enriquecida (avatar, segmento, estado, última actividad)
- Drawer lateral de detalle al click en fila

Sin cambiar la arquitectura de rutas de submódulos ya creada (`/clientes/segmentos`, `/clientes/prospectos`, `/clientes/historial`, `/clientes/documentos`).

---

## Plan de implementación

### 1) Modelo de UI derivado para clientes
**Archivo:** `frontend/src/views/ventas/ClientesPage.vue`

Crear un mapper local `ClienteUI` (computed) que normalice campos faltantes del backend:
- `id`, `nombre`, `email`, `telefono`, `rut`
- `iniciales` (derivado del nombre)
- `segmento: 'Premium' | 'Estándar' | 'Básico'` (derivado/fallback)
- `activo: boolean` (fallback `true`)
- `ultimaActividad: string` (fecha amigable / `—`)
- `ventasAcumuladas: number` (fallback `0`)
- `premium: boolean`

Esto evita que la UI dependa de que todos los campos existan hoy en API.

---

### 2) KPIs arriba de la tabla
**Archivo:** `frontend/src/views/ventas/ClientesPage.vue`

Usar `KpiCard` para:
- Total clientes
- Activos
- Ventas acumuladas
- Clientes Premium

Con format CLP y fallback en cero.

---

### 3) Toolbar funcional
**Archivo:** `frontend/src/views/ventas/ClientesPage.vue`

Agregar:
- `searchQuery` (nombre, email, rut, teléfono)
- `segmentFilter` (`all | premium | estandar | basico`)
- botón `Exportar CSV` usando `exportToCSV` (`frontend/src/utils/export.ts`)

Dataset exportado = lista filtrada actual.

---

### 4) Empty state accionable
**Archivos:**
- `frontend/src/views/ventas/ClientesPage.vue`
- `frontend/src/components/ui/DataTable.vue` (extensión backward-compatible)

Agregar slot opcional `empty-state` en `DataTable` para personalizar vacío sin romper usos existentes.

En `ClientesPage` renderizar:
- mensaje: **“Aún no hay clientes — importa desde Excel o agrega el primero”**
- botón `Importar Excel` (acción inicial: toast/informativo)
- botón `Agregar el primero` (navega a `/clientes/new`)

---

### 5) Filas de tabla más ricas
**Archivo:** `frontend/src/views/ventas/ClientesPage.vue`

Columnas propuestas:
- Cliente (avatar + nombre + contacto)
- Segmento (badge color)
- Estado (punto verde/gris + texto)
- Última actividad
- Acciones

Mantener acción `Eliminar` según reglas actuales (`!empresaStore.esCrmOnly`).

---

### 6) Drawer lateral de detalle
**Archivo principal:** `frontend/src/views/ventas/ClientesPage.vue`
**Opcional extraíble:** `frontend/src/components/ventas/ClientDetailDrawer.vue`

Comportamiento:
- click en fila abre drawer derecho
- muestra resumen, historial breve, contactos, documentos (con fallback si falta data)
- acciones: `Editar` (navega a `/clientes/:id`) y `Cerrar`

---

## Archivos a tocar
- `frontend/src/views/ventas/ClientesPage.vue` (principal)
- `frontend/src/components/ui/DataTable.vue` (slot `empty-state`)
- `frontend/src/components/ventas/ClientDetailDrawer.vue` (si se extrae)
- `frontend/src/utils/export.ts` (solo reutilización; cambios mínimos si hacen falta)

---

## Criterios de aceptación (DoD)
- `/clientes` muestra KPIs, toolbar y tabla enriquecida.
- Búsqueda + filtro segmento funcionan en tiempo real.
- Export CSV descarga exactamente el conjunto filtrado.
- Empty state accionable visible cuando no hay datos.
- Click en fila abre drawer lateral con información del cliente.
- No se rompen rutas ya creadas de submódulos de clientes.
- `vue-tsc --noEmit` sin errores.
- `vite build` sin errores.

---

## Trazabilidad (paso → targets → verificación)
- **KPIs** → `ClientesPage.vue` → conteos/formatos correctos.
- **Toolbar + filtros + CSV** → `ClientesPage.vue` → coincidencia entre tabla y export.
- **Empty state custom** → `DataTable.vue` + `ClientesPage.vue` → slot funcionando y backward-compatible.
- **Tabla enriquecida + drawer** → `ClientesPage.vue` (o componente extraído) → apertura/cierre/acciones correctas.
- **Calidad** → typecheck/build → sin regresiones.

## Riesgos y mitigación
- **Datos incompletos backend**: mapper `ClienteUI` con fallback estricto.
- **Sobrecarga en una sola vista**: extraer drawer a componente dedicado si el archivo crece demasiado.
- **Regresión de DataTable**: slot opcional sin modificar API existente.