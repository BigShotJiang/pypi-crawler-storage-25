## Objetivo

Migrar los ~88 archivos del frontend (`src/`) de JavaScript a TypeScript con `strict: true`, sin romper la funcionalidad existente.

---

## Dependencias a instalar

```
npm install -D typescript vue-tsc @types/node
```

> `vue-tsc` es el type-checker oficial para Vue 3 + `<script setup lang="ts">`. No requiere `ts-node`.

---

## Fase 1 — Configuración (infraestructura TS)

### Archivos a crear

| Archivo | Descripción |
|---|---|
| `frontend/tsconfig.json` | Raíz: referencia a `tsconfig.app.json` y `tsconfig.node.json` |
| `frontend/tsconfig.app.json` | Config del código `src/` (`lib: ES2020`, `moduleResolution: bundler`, `strict: true`) |
| `frontend/tsconfig.node.json` | Config de `vite.config.ts` (`lib: ES2022`, `module: ESNext`) |
| `frontend/src/env.d.ts` | Tipos para `import.meta.env` (VITE_API_URL, etc.) |

### Archivos a renombrar

- `vite.config.js` → `vite.config.ts`

### `package.json` — agregar script

```json
"typecheck": "vue-tsc --noEmit"
```

---

## Fase 2 — Tipos de dominio (`src/types/`)

Crear un archivo por dominio. Todos los stores y servicios importarán desde aquí.

```
src/types/
├── index.ts          ← re-exporta todo
├── api.ts            ← ApiResponse<T>, AxiosErrorExt
├── auth.ts           ← User, Token, EmpresaAsociada
├── empresa.ts        ← Empresa, Sucursal, MetodoPago
├── ventas.ts         ← Cliente, Producto, OrdenServicio, Venta
├── finanzas.ts       ← Gasto, Cuenta, Asiento, Periodo, Balance8Col
├── inventario.ts     ← ProductoCatalogo, StockItem, Movimiento, Bodega, Valorizacion
├── compras.ts        ← Proveedor, OrdenCompra
├── crm.ts            ← Opportunity, Pipeline, Stage, Activity
├── holding.ts        ← Company, ModuleMap, ModuleKey
├── billing.ts        ← BillingStatus, Plan
└── router.ts         ← Augmentación de RouteMeta (requiresAuth, roles, modulo)
```

**Tipos clave a definir:**

- `ApiResponse<T>`: `{ data: T; detail?: string }`
- `User`: `{ id, email, role: 'SUPERADMIN' | 'DEVELOPER' | 'ADMIN' | 'USER', empresas_asociadas: EmpresaAsociada[] }`
- `EmpresaAsociada`: `{ empresa: Empresa; rol: { codigo: string }; is_default: boolean }`
- `RouteMeta` augmentation: `requiresAuth?: boolean; roles?: string[]; modulo?: string`

---

## Fase 3 — Archivos core (`.js` → `.ts`)

| Archivo original | Acción |
|---|---|
| `src/main.js` | → `main.ts` — tipar app, pinia, plugins |
| `src/router/index.js` | → `router/index.ts` — tipar `RouteRecordRaw`, augmentar `RouteMeta` |
| `src/services/api.js` | → `services/api.ts` — tipar interceptors, extender `AxiosRequestConfig` con `_retry` |
| `src/services/inventario.service.js` | → `services/inventario.service.ts` — tipar parámetros + **fix bug** (`updateProduct` no pasa `data` al body) |
| `src/services/admin.service.js` | → `services/admin.service.ts` — tipar retornos `Promise<AxiosResponse<T>>` |
| `src/utils/export.js` | → `utils/export.ts` — tipar `data: Record<string, unknown>[]` |

---

## Fase 4 — Stores (`.js` → `.ts`)

Todos los stores con **Options API** pasarán a tipar `state`, `getters` y `actions` explícitamente. Los de **Composition API** usarán `Ref<T>`.

| Store | API usada | Tipos principales |
|---|---|---|
| `stores/auth.ts` | Options | `User \| null`, `string \| null` |
| `stores/empresa.ts` | Options | `Empresa \| null`, `string[]`, `Sucursal[]` |
| `stores/ventas.ts` | Options | `Cliente[]`, `Producto[]`, `OrdenServicio[]` |
| `stores/finanzas.ts` | Options | `Gasto[]`, `Cuenta[]`, `Asiento[]` |
| `stores/compras.ts` | Options | `Proveedor[]`, `OrdenCompra[]` |
| `stores/crm.ts` | Options | `Opportunity[]`, `Pipeline[]`, `Stage[]` |
| `stores/inventario.ts` | Composition | `Ref<ProductoCatalogo[]>`, `Ref<StockItem[]>` |
| `stores/holding.ts` | Composition | `Ref<Company \| null>`, `Ref<Company[]>`, `ModuleMap` |
| `stores/billing.ts` | Composition | `Ref<BillingStatus>` |
| `stores/addons/pos_retail.ts` | Options | estado de caja |

---

## Fase 5 — Componentes Vue (`.vue`)

Para los **44 archivos `.vue`**, el cambio mínimo y más impactante es:

```diff
- <script setup>
+ <script setup lang="ts">
```

Adicionalmente, en los componentes con `defineProps` / `defineEmits` sin tipos, se agregarán las interfaces correspondientes. Prioridad:

1. **Componentes UI reutilizables** (`src/components/ui/*.vue`) — los más críticos por reuso: `KpiCard`, `DataTable`, `Modal`, `Badge`, `SalesChart`, `ServiceOrdersWidget`
2. **Layouts** (`AdminLayout.vue`, `ClientLayout.vue`)
3. **Views principales** (`Login.vue`, `Dashboard.vue`, `SelectCompany.vue`, y resto de views)
4. **Componentes de dominio** (`components/finanzas/`, `components/inventory/`, `components/admin/`, `components/dev/`)

---

## Flujo de dependencias

```mermaid
graph TD
    A[tsconfig + env.d.ts] --> B[src/types/]
    B --> C[services/*.ts]
    B --> D[stores/*.ts]
    C --> D
    D --> E[router/index.ts]
    D --> F[views/*.vue lang=ts]
    C --> F
    E --> G[main.ts]
    F --> G
```

---

## Fix de bug incluido

En `services/inventario.service.ts`, `updateProduct` actualmente hace:
```js
api.put(`/api/v1/inventario/catalogo/${id}`)  // ← falta el body
```
Se corregirá a:
```ts
api.put<ProductoCatalogo>(`/api/v1/inventario/catalogo/${id}`, data)
```

---

## Verificación (DoD)

| Check | Comando |
|---|---|
| Sin errores de tipos | `npm run typecheck` (`vue-tsc --noEmit`) |
| App compila en dev | `npm run dev` arranca sin errores |
| App compila para producción | `npm run build` sin errores |

---

## Resumen de archivos afectados

| Categoría | Cantidad |
|---|---|
| Nuevos (tsconfig, env.d.ts, types/) | ~17 |
| `.js` → `.ts` (renombrar + tipar) | ~14 |
| `.vue` (agregar `lang="ts"` + tipar props) | ~44 |
| `package.json` (nuevo script) | 1 |
| **Total** | **~76** |
