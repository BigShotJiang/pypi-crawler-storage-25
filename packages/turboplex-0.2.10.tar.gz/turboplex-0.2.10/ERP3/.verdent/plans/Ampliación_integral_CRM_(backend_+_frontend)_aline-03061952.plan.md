## Objetivo
Ampliar el CRM de forma integral (pipeline, oportunidades, actividades/tareas, comentarios, cotizaciones, entregas, firma/documentos, reportes/KPIs), manteniendo **alineación estricta Backend↔Frontend** y respetando tus restricciones críticas de compatibilidad, rutas, roles y contratos.

---

## Restricciones y reglas obligatorias (incorporadas al plan)

- **Compatibilidad de datos**:
  - Mantener estructura actual de productos: `sku`, `nombre`, `precio_venta` (fallback `precio`), `stock`.
  - No renombrar esos campos en servicios/API.
- **Rutas**:
  - No sobrescribir rutas existentes de Clientes ni Dashboard en `router/index.ts`.
  - Solo agregar rutas nuevas bajo el hijo que corresponda sin romper lo actual.
- **Tipos/archivos**:
  - Nuevos archivos en `.ts` o `.vue` con `<script setup lang="ts">`.
- **Seguridad**:
  - Toda ruta nueva con `meta.requiresAuth: true`.
  - Acceso inicial a roles: `admin` y `vendedor`.
- **Identidad de flujo**:
  - `order_id` para ventas rápidas/directas con prefijo obligatorio `NV-`.
- **Infraestructura HTTP**:
  - Reutilizar `src/services/api.ts`; no crear nueva instancia Axios.

---

## Alcance funcional (todo CRM, ordenado por módulos)

1. **Pipeline Kanban**
   - Estados configurables, drag&drop, WIP opcional por etapa, métricas por columna.
2. **Oportunidades**
   - CRUD completo, scoring, monto estimado, probabilidad, fechas de cierre, asignación responsable.
3. **Actividades/Tareas**
   - Llamadas/reuniones/tareas con vencimiento, estado, recordatorios.
4. **Comentarios y Timeline**
   - Hilo cronológico auditable por oportunidad/cliente.
5. **Cotizaciones**
   - Generación, versionado, aprobación/rechazo, conversión a venta.
6. **Seguimiento de entregas**
   - Estado operativo y trazabilidad postventa.
7. **Firma/Documentos**
   - Subida/validación de documentos, estado de firma, historial de cambios.
8. **Reportes/KPIs**
   - Conversión por etapa, tiempo de ciclo, forecast, productividad por vendedor.

---

## Alineación Backend ↔ Frontend (contrato único)

### 1) Contrato de dominio tipado (single source of truth)

**Backend (DTO/schemas):**
- Definir/estandarizar schemas para:
  - `Pipeline`, `Stage`, `Opportunity`, `Activity`, `Comment`, `Quote`, `DeliveryTracking`, `DocumentRecord`, `CrmKpiSnapshot`.
- Error envelope unificado (`detail`, `code`, `meta`) para todos los endpoints CRM.

**Frontend (`src/types/crm.ts` + servicios):**
- Reflejar 1:1 los DTO backend.
- Versionado de contrato en tipos (`v1`) y mapeo explícito cuando sea necesario.

### 2) Estados compartidos (workflow canónico)

Definir enums comunes para evitar desalineación:
- `OpportunityStatus`, `StageCode`, `ActivityStatus`, `QuoteStatus`, `DeliveryStatus`, `DocumentStatus`.
- Validaciones backend basadas en transición válida de estado.
- Frontend usa esos enums para UI, filtros y badges.

---

## Plan técnico por capas

## Fase A — Backend CRM Core

### A.1 Modelo y migraciones
- Crear/ajustar entidades y relaciones:
  - Oportunidades ↔ Actividades/Comentarios/Cotizaciones/Documentos/Entregas.
- Índices para búsquedas por `empresa`, `owner`, `status`, `updated_at`.
- Migraciones DB seguras sin romper datos existentes.

### A.2 Servicios de dominio
- Casos de uso:
  - crear/actualizar oportunidad
  - mover etapa
  - registrar actividad/comentario
  - generar/actualizar cotización
  - registrar documento/firma
  - actualizar tracking de entrega
- Reglas de negocio críticas:
  - validación de transición de estados
  - permisos por rol (`admin`, `vendedor`)
  - auditoría mínima por operación crítica.

### A.3 API REST
- Endpoints agrupados en módulo CRM:
  - `/crm/pipelines`, `/crm/stages`
  - `/crm/opportunities`
  - `/crm/activities`, `/crm/comments`
  - `/crm/quotes`
  - `/crm/deliveries`
  - `/crm/documents`
  - `/crm/reports/*`
- Respuesta consistente y paginación estándar en listados.

### A.4 Observabilidad y seguridad
- Logs estructurados en acciones críticas CRM.
- Trazabilidad de cambios (quién/qué/cuándo).
- Validación de acceso por empresa + rol.

---

## Fase B — Frontend CRM Experience

### B.1 Tipos y servicios
- Actualizar `src/types/crm.ts` con DTOs finales.
- Ajustar `src/services/*` para usar solo `src/services/api.ts`.
- Manejo homogéneo de errores (`friendlyMessage`, `detail`, códigos).

### B.2 Vistas principales
- `CrmPage` (overview + filtros + KPIs top).
- `PipelineView` (Kanban operativo, drag&drop, contadores por etapa).
- `OportunidadDetalleView` (timeline, tareas, comentarios, documentos, entrega).

### B.3 Submódulos UX
- Cotizaciones: listado + editor + estado.
- Entregas: tracking y bitácora.
- Documentos/firma: panel con historial y adjuntos.
- Reportes: KPIs por vendedor, etapa y período.

### B.4 Componentes reutilizables
- Badges de estado por workflow.
- Drawer/Modal de edición rápida.
- Filtros avanzados (segmento, owner, etapa, fecha, prioridad).

---

## Fase C — Alineación explícita API/UI

### C.1 Matriz de contrato
Crear matriz de trazabilidad (endpoint ↔ DTO backend ↔ tipo frontend ↔ vista):
- cada endpoint debe tener tipo TS asociado y vista consumidora.

### C.2 Validación de compatibilidad
- Tests de contrato (backend schema + frontend typing).
- Revisión de campos sensibles de compatibilidad:
  - `sku`, `nombre`, `precio_venta`/`precio`, `stock`.
- Mantener `NV-` para `order_id` en ventas rápidas/directas.

### C.3 Rutas y roles
- Rutas CRM nuevas con `meta.requiresAuth: true`.
- Roles permitidos: `admin`, `vendedor`.
- Sin romper rutas actuales de Clientes y Dashboard.

---

## Archivos objetivo (ubicaciones)

### Backend (referencial)
- `backend/app/api/.../crm*`
- `backend/app/services/crm*`
- `backend/app/models/crm*`
- `backend/alembic/versions/*crm*`
- `backend/app/schemas/crm*`

### Frontend
- `frontend/src/types/crm.ts`
- `frontend/src/services/*crm*` (o `nueva-venta.service.ts` cuando aplique)
- `frontend/src/views/crm/CrmPage.vue`
- `frontend/src/views/crm/PipelineView.vue`
- `frontend/src/views/crm/OportunidadDetalleView.vue`
- `frontend/src/router/index.ts` (solo adición no destructiva)

---

## Diagrama de alineación

```mermaid
graph LR
  FEViews[Frontend Views\nCrmPage/Pipeline/Detalle] --> FEServices[Frontend Services\napi.ts wrappers]
  FEServices --> API[FastAPI CRM Endpoints]
  API --> Domain[CRM Domain Services]
  Domain --> DB[(PostgreSQL)]
  API --> Schemas[DTO/Schemas]
  Schemas --> TypesTS[TS Types crm.ts]
  TypesTS --> FEViews
```

---

## DoD (criterios de terminado)

- Pipeline, oportunidades, actividades, comentarios, cotizaciones, entregas, documentos y KPIs operativos en backend y frontend.
- Contrato API/UI tipado y consistente (sin campos huérfanos).
- Roles y auth aplicados en rutas y endpoints (`admin`, `vendedor`).
- Compatibilidad preservada en campos críticos (`sku`, `nombre`, `precio_venta`/`precio`, `stock`).
- Prefijo `NV-` preservado en `order_id` de flujo directo.
- Sin regresión en rutas existentes de Clientes/Dashboard.
- Typecheck frontend y build exitosos; pruebas backend CRM pasando.

---

## Trazabilidad (paso → targets → verificación)

- **Dominio CRM backend** → models/services/schemas/api → tests de reglas de negocio + permisos.
- **Contrato compartido** → schemas backend + `types/crm.ts` → chequeo de correspondencia DTO↔TS.
- **UI CRM** → vistas/componentes CRM → validación de flujos E2E por módulo.
- **Rutas y seguridad** → `router/index.ts` + guards + meta → acceso correcto por rol.
- **Compatibilidad crítica** → servicios inventario/ventas rápida → validación de campos y prefijo `NV-`.
