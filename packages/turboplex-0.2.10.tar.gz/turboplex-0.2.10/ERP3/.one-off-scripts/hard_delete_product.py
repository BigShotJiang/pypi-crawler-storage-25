import sys
import os
from sqlalchemy import text
from sqlalchemy.orm import Session
from uuid import UUID

# Add backend directory to path to allow imports
backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
sys.path.append(backend_path)

# Load env vars before importing config
from dotenv import load_dotenv
env_path = os.path.join(backend_path, ".env")
if os.path.exists(env_path):
    print(f"Loading .env from: {env_path}")
    load_dotenv(env_path)
else:
    print(f"WARNING: .env not found at {env_path}")

from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto

def hard_delete_product(product_id_str: str):
    print(f"--- Starting Hard Delete Process for ID: {product_id_str} ---")
    
    db: Session = SessionLocal()
    try:
        # We need to bypass RLS or set a tenant context if RLS is active.
        # Let's try to set allow_no_tenant to True to bypass RLS checks for this admin operation.
        db.info["allow_no_tenant"] = True
        
        product_id = UUID(product_id_str)
        
        # Check if product exists (including soft deleted ones)
        # Using native SQL to avoid any ORM filtering issues
        check_sql = text("SELECT id, nombre, precio, is_deleted, empresa_id FROM productos WHERE id = :id")
        result = db.execute(check_sql, {"id": product_id}).fetchone()
        
        if not result:
            print(f"Product {product_id_str} NOT FOUND in database.")
            return

        print(f"Found Product: {result.nombre}")
        print(f"  ID: {result.id}")
        print(f"  Price: {result.precio}")
        print(f"  Is Deleted (Soft): {result.is_deleted}")
        print(f"  Empresa ID: {result.empresa_id}")
        
        # Perform Hard Delete
        print("\nPerforming HARD DELETE...")
        delete_sql = text("DELETE FROM productos WHERE id = :id")
        db.execute(delete_sql, {"id": product_id})
        db.commit()
        print(f"SUCCESS: Product {product_id_str} permanently deleted.")
        
        # Verify
        verify_result = db.execute(check_sql, {"id": product_id}).fetchone()
        if not verify_result:
            print("Verification: Product is GONE.")
        else:
            print("Verification FAILED: Product still exists!")
            
    except Exception as e:
        print(f"ERROR: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    # ID from conversation history: 019cba00-a8f1-737b-8f6c-6890775d250e
    target_id = "019cba00-a8f1-737b-8f6c-6890775d250e"
    
    # Allow command line argument override
    if len(sys.argv) > 1:
        target_id = sys.argv[1]
        
    hard_delete_product(target_id)
