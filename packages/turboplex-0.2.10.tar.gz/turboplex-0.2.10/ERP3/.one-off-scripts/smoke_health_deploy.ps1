Param(
    [string]$DatabaseUrl = "postgresql+psycopg2://postgres:postgres@localhost/erp3_clean",
    [switch]$KeepScript
)

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot   = Resolve-Path (Join-Path $ScriptRoot "..")
$BackendDir = Join-Path $RepoRoot "backend"

$PyExe = Join-Path $BackendDir ".venv\Scripts\python.exe"
if (-not (Test-Path $PyExe)) { $PyExe = "python" }

$env:DATABASE_URL = $DatabaseUrl
& $PyExe (Join-Path $RepoRoot ".one-off-scripts\smoke_health_deploy.py")

Start-Sleep -Seconds 2
if (-not $KeepScript.IsPresent) {
    try {
        Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force
    } catch {
        $PendingFile = Join-Path $RepoRoot ".one-off-scripts\pending-cleanup.txt"
        "$($MyInvocation.MyCommand.Path)" | Out-File -FilePath $PendingFile -Encoding utf8 -Append
    }
}

