param(
    [switch]$Force
)
$ErrorActionPreference = "Stop"
$scriptPath = $MyInvocation.MyCommand.Path
$scriptsDir = Split-Path -Parent $scriptPath
$repoRoot = Split-Path -Parent $scriptsDir
$backendDir = Join-Path $repoRoot "backend"
$envFile = Join-Path $backendDir ".env"
$logFile = Join-Path $scriptsDir "nuclear-reset.log"
$pendingCleanup = Join-Path $scriptsDir "pending-cleanup.txt"
function Write-Log { param([string]$m) $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"; "$ts $m" | Tee-Object -FilePath $logFile -Append | Out-Null }
function Get-VarFromEnvFile {
    param([string]$key)
    if (-not (Test-Path $envFile)) { return $null }
    $line = Select-String -Path $envFile -Pattern "^\s*$key\s*=" -SimpleMatch | Select-Object -First 1
    if (-not $line) { return $null }
    $val = $line.Line.Split("=",2)[1].Trim().Trim('"').Trim("'")
    return $val
}
$environment = $env:ENVIRONMENT
if (-not $environment) { $environment = Get-VarFromEnvFile "ENVIRONMENT" }
if (-not $environment) { $environment = "development" }
$databaseUrl = $env:DATABASE_URL
if (-not $databaseUrl) { $databaseUrl = Get-VarFromEnvFile "DATABASE_URL" }
Write-Log "Starting nuclear reset"
Write-Log "ENVIRONMENT=$environment"
if ($environment.ToLower() -eq "production" -and -not $Force) {
    Write-Log "Blocked in production without --Force"
    Write-Host "Bloqueado: entorno production. Usa --Force bajo tu responsabilidad."
    exit 1
}
if ($databaseUrl -and $databaseUrl -notmatch "localhost|127\.0\.0\.1" -and -not $Force) {
    Write-Log "Blocked non-local DATABASE_URL without --Force"
    Write-Host "Bloqueado: DATABASE_URL no es local. Usa --Force bajo tu responsabilidad."
    exit 1
}
$ans1 = Read-Host "¿Seguro que deseas resetear la base de datos? (si/no)"
if (@("si","sí","yes","y") -notcontains $ans1.ToLower()) {
    Write-Log "Abortado en primera confirmación"
    Write-Host "Abortado"
    exit 1
}
$ans2 = Read-Host "Escribe BORRAR TODO para continuar"
if ($ans2 -ne "BORRAR TODO") {
    Write-Log "Abortado en segunda confirmación"
    Write-Host "Abortado"
    exit 1
}
$resetScript = Join-Path (Join-Path $backendDir "scripts") "reset_db.py"
$onboardingScript = Join-Path (Join-Path $backendDir "scripts") "auto_onboarding.py"
if (-not (Test-Path $resetScript)) { Write-Log "reset_db.py missing"; Write-Host "Falta reset_db.py"; exit 1 }
if (-not (Test-Path $onboardingScript)) { Write-Log "auto_onboarding.py missing"; Write-Host "Falta auto_onboarding.py"; exit 1 }
Write-Log "Running reset_db.py"
pushd $backendDir
try {
    python $resetScript
    if ($LASTEXITCODE -ne 0) { throw "reset_db.py failed with code $LASTEXITCODE" }
    Write-Log "reset_db.py ok"
} catch {
    Write-Log "reset_db.py error: $_"
    popd
    exit 1
}
Write-Log "Running auto_onboarding.py"
try {
    python $onboardingScript
    if ($LASTEXITCODE -ne 0) { throw "auto_onboarding.py failed with code $LASTEXITCODE" }
    Write-Log "auto_onboarding.py ok"
} catch {
    Write-Log "auto_onboarding.py error: $_"
    popd
    exit 1
}
popd
Write-Log "Sequence completed"
Start-Sleep -Seconds 2
try {
    Remove-Item -LiteralPath $scriptPath -Force
} catch {
    "$scriptPath" | Out-File -FilePath $pendingCleanup -Append -Encoding utf8
}
