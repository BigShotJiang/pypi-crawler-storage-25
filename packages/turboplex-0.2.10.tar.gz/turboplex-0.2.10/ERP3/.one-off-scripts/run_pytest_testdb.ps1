Param(
    [switch]$SelfDelete,
    [string[]]$PytestArgs
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Split-Path -Parent $scriptDir
$backendPath = Join-Path $repoRoot "backend"

Write-Host "-> Using backend at: $backendPath"
if (-not (Test-Path $backendPath)) {
    Write-Error "Backend path not found: $backendPath"
    exit 2
}

Push-Location $backendPath

try {
    $orig = $env:DATABASE_URL
    $testUrl = "postgresql+psycopg2://erp3_user:erp3_pass_2026@localhost/erp3_test"
    Write-Host "-> Overriding DATABASE_URL for pytest:" $testUrl
    $env:DATABASE_URL = $testUrl

    $python = ".venv\Scripts\python.exe"
    if (-not (Test-Path $python)) {
        Write-Error "Python venv not found at $python"
        exit 3
    }

    $argsToPass = @("-m", "pytest", "-q")
    if ($PytestArgs -and $PytestArgs.Count -gt 0) {
        $argsToPass += $PytestArgs
    }

    & $python @argsToPass
    $code = $LASTEXITCODE
    Write-Host "-> Pytest finished with exit code: $code"
}
finally {
    if ($null -ne $orig -and $orig -ne "") {
        $env:DATABASE_URL = $orig
        Write-Host "-> DATABASE_URL restored to previous value"
    }
    else {
        Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue | Out-Null
        Write-Host "-> DATABASE_URL unset (was not previously defined)"
    }

    Pop-Location
}

if ($SelfDelete.IsPresent) {
    Start-Sleep -Seconds 2
    try {
        Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force
        Write-Host "-> Self-delete successful."
    }
    catch {
        $pending = Join-Path $scriptDir "pending-cleanup.txt"
        "FAILED TO DELETE: $($MyInvocation.MyCommand.Path) - $($_.Exception.Message)" | Out-File -FilePath $pending -Append -Encoding utf8
        Write-Warning "-> Could not self-delete. Logged path to $pending"
    }
}

Read-Host "pytest finished. Press Enter to close this window."

exit $code

