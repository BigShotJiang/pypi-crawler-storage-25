import os
import sys

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
load_dotenv(os.path.join(backend_path, ".env"))
sys.path.append(backend_path)

from app.core.config import settings
from app.core_modules.sistema.models import Empresa
from app.core_modules.ventas.models import (
    Venta,
    DetalleVenta,
    OrdenServicio,
    HistorialOrdenServicio,
)
from app.core_modules.finanzas.models import AsientoContable, MovimientoContable, Gasto
from app.core_modules.facturacion.models import (
    DocumentoTributario,
    DocumentoTributarioDetalle,
)
from app.addons.pos_retail.models import CierreCaja
from app.core_modules.compras.models import (
    OrdenCompra,
    OrdenCompraDetalle,
    RecepcionDRA,
    LineaDRA,
)
from app.core_modules.service_engine.models import ServiceOrder, JobOrder


def _delete_by_ids(db, model, id_field, ids):
    if not ids:
        return 0
    return (
        db.query(model)
        .filter(id_field.in_(ids))
        .delete(synchronize_session=False)
    )


def clean_lucas_spa_transactions():
    engine = create_engine(settings.DATABASE_URL)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    try:
        db.info["allow_no_tenant"] = True
        empresa = (
            db.query(Empresa)
            .filter(Empresa.nombre.ilike("%Lucas SPA%"))
            .first()
        )
        if not empresa:
            print("Empresa Lucas SPA no encontrada.")
            return

        empresa_id = empresa.id
        print(f"Limpieza transaccional para empresa: {empresa.nombre} ({empresa_id})")

        dte_ids = [
            row[0]
            for row in db.query(DocumentoTributario.id)
            .filter(DocumentoTributario.empresa_id == empresa_id)
            .all()
        ]
        deleted_dte_det = _delete_by_ids(
            db, DocumentoTributarioDetalle, DocumentoTributarioDetalle.dte_id, dte_ids
        )
        deleted_dte = (
            db.query(DocumentoTributario)
            .filter(DocumentoTributario.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        venta_ids = [
            row[0]
            for row in db.query(Venta.id).filter(Venta.empresa_id == empresa_id).all()
        ]
        orden_ids = [
            row[0]
            for row in db.query(OrdenServicio.id)
            .join(Venta, OrdenServicio.venta_id == Venta.id)
            .filter(Venta.empresa_id == empresa_id)
            .all()
        ]
        deleted_historial = _delete_by_ids(
            db, HistorialOrdenServicio, HistorialOrdenServicio.orden_servicio_id, orden_ids
        )
        deleted_ordenes = _delete_by_ids(db, OrdenServicio, OrdenServicio.id, orden_ids)
        deleted_detalles = _delete_by_ids(
            db, DetalleVenta, DetalleVenta.venta_id, venta_ids
        )
        deleted_ventas = (
            db.query(Venta)
            .filter(Venta.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        asiento_ids = [
            row[0]
            for row in db.query(AsientoContable.id)
            .filter(AsientoContable.empresa_id == empresa_id)
            .all()
        ]
        deleted_movs = _delete_by_ids(
            db, MovimientoContable, MovimientoContable.asiento_id, asiento_ids
        )
        deleted_asientos = (
            db.query(AsientoContable)
            .filter(AsientoContable.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        deleted_gastos = (
            db.query(Gasto)
            .filter(Gasto.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        deleted_cierres = (
            db.query(CierreCaja)
            .filter(CierreCaja.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        orden_compra_ids = [
            row[0]
            for row in db.query(OrdenCompra.id)
            .filter(OrdenCompra.empresa_id == empresa_id)
            .all()
        ]
        deleted_oc_det = _delete_by_ids(
            db, OrdenCompraDetalle, OrdenCompraDetalle.orden_compra_id, orden_compra_ids
        )
        deleted_oc = (
            db.query(OrdenCompra)
            .filter(OrdenCompra.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        dra_ids = [
            row[0]
            for row in db.query(RecepcionDRA.id)
            .filter(RecepcionDRA.empresa_id == empresa_id)
            .all()
        ]
        deleted_dra_lineas = _delete_by_ids(
            db, LineaDRA, LineaDRA.dra_id, dra_ids
        )
        deleted_dra = (
            db.query(RecepcionDRA)
            .filter(RecepcionDRA.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        deleted_service_orders = (
            db.query(ServiceOrder)
            .filter(ServiceOrder.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )
        deleted_job_orders = (
            db.query(JobOrder)
            .filter(JobOrder.empresa_id == empresa_id)
            .delete(synchronize_session=False)
        )

        db.commit()

        print("Resumen de eliminación:")
        print(f"- DocumentoTributarioDetalle: {deleted_dte_det}")
        print(f"- DocumentoTributario: {deleted_dte}")
        print(f"- HistorialOrdenServicio: {deleted_historial}")
        print(f"- OrdenServicio: {deleted_ordenes}")
        print(f"- DetalleVenta: {deleted_detalles}")
        print(f"- Venta: {deleted_ventas}")
        print(f"- MovimientoContable: {deleted_movs}")
        print(f"- AsientoContable: {deleted_asientos}")
        print(f"- Gasto: {deleted_gastos}")
        print(f"- CierreCaja: {deleted_cierres}")
        print(f"- OrdenCompraDetalle: {deleted_oc_det}")
        print(f"- OrdenCompra: {deleted_oc}")
        print(f"- LineaDRA: {deleted_dra_lineas}")
        print(f"- RecepcionDRA: {deleted_dra}")
        print(f"- ServiceOrder (service_engine): {deleted_service_orders}")
        print(f"- JobOrder (service_engine): {deleted_job_orders}")
    finally:
        db.close()


if __name__ == "__main__":
    clean_lucas_spa_transactions()
