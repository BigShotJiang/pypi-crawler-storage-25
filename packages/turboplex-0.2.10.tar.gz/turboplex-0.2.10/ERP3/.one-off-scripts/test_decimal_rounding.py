import json
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, ConfigDict, field_validator
from uuid import UUID
import uuid

# Simulating the Schema structure from schemas.py to test the validator logic in isolation first
class ProductoBase(BaseModel):
    nombre: Optional[str] = None
    sku: Optional[str] = None
    precio: Optional[Decimal] = None
    tipo_producto: Optional[str] = "ALMACENABLE"
    is_active: Optional[bool] = True
    empresa_id: Optional[UUID] = None
    costo_promedio: Optional[Decimal] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")

class ProductoInDBBase(ProductoBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True, extra="forbid")

class Producto(ProductoInDBBase):
    model_config = ConfigDict(from_attributes=True, extra="forbid")

    @field_validator("precio", "costo_promedio", mode="before")
    @classmethod
    def round_decimals(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        if v is not None:
            # If input is float, convert to string first to avoid precision issues before Decimal
            if isinstance(v, float):
                v = Decimal(str(v))
            elif not isinstance(v, Decimal):
                 v = Decimal(v)
            return round(v, 2)
        return v

def test_rounding():
    # Case 1: The user requested case "1500.50"
    p1 = Producto(
        id=uuid.uuid4(),
        nombre="Test Product",
        sku="TEST-001",
        precio=Decimal("1500.500000000000000001"),
        costo_promedio=Decimal("100.123456"),
        empresa_id=uuid.uuid4()
    )
    
    # Case 2: Float input
    p2 = Producto(
        id=uuid.uuid4(),
        nombre="Test Product Float",
        sku="TEST-002",
        precio=1500.50,
        costo_promedio=100.126, # Should round up to 100.13
        empresa_id=uuid.uuid4()
    )

    print("--- Test Results ---")
    json_output1 = p1.model_dump_json()
    print(f"Case 1 (Decimal input): {json_output1}")
    
    json_output2 = p2.model_dump_json()
    print(f"Case 2 (Float input):   {json_output2}")

    data1 = json.loads(json_output1)
    data2 = json.loads(json_output2)

    assert data1["precio"] == "1500.50" or data1["precio"] == 1500.5
    assert data1["costo_promedio"] == "100.12" or data1["costo_promedio"] == 100.12
    
    # Check strict 2 decimal places in JSON string representation is harder with default JSON encoder
    # but Pydantic with Decimal usually dumps as string or float depending on config.
    # Let's see the output.

if __name__ == "__main__":
    test_rounding()
