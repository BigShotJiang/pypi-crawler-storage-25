import sys
import os
from dotenv import load_dotenv

backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
sys.path.append(backend_path)

load_dotenv(os.path.join(backend_path, ".env"))

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Sucursal, Bodega
from app.core_modules.ventas.models import Producto, Inventario, Venta  # noqa: F401
from app.core_modules.finanzas.models import CierreCaja  # noqa: F401


def seed_company_details():
    db = SessionLocal()
    try:
        companies_data = [
            {
                "rut": "76.111.111-1",
                "sucursal": "Casa Matriz Santiago",
                "bodega": "Bodega Central",
                "productos": [
                    {"nombre": "Laptop Pro 14", "sku": "LP-14", "precio": 1200000, "stock": 50},
                    {"nombre": "Mouse Inalámbrico", "sku": "MS-WL", "precio": 25000, "stock": 200},
                    {"nombre": "Teclado Mecánico", "sku": "KB-MECH", "precio": 85000, "stock": 100},
                    {"nombre": "Monitor 27 4K", "sku": "MN-4K", "precio": 350000, "stock": 30},
                    {"nombre": "Docking Station", "sku": "DCK-USBC", "precio": 120000, "stock": 45},
                ],
            },
            {
                "rut": "76.222.222-2",
                "sucursal": "Mall Plaza",
                "bodega": "Bodega Tienda",
                "productos": [
                    {"nombre": "Camisa Formal", "sku": "CM-FRM", "precio": 35000, "stock": 500},
                    {"nombre": "Pantalón Dockers", "sku": "PN-DCK", "precio": 45000, "stock": 300},
                    {"nombre": "Zapatos Cuero", "sku": "ZP-CRO", "precio": 65000, "stock": 150},
                    {"nombre": "Corbata Seda", "sku": "CR-SDA", "precio": 15000, "stock": 200},
                    {"nombre": "Cinturón Cuero", "sku": "CN-CRO", "precio": 18000, "stock": 250},
                ],
            },
            {
                "rut": "76.333.333-3",
                "sucursal": "Planta Norte",
                "bodega": "Bodega Insumos",
                "productos": [
                    {"nombre": "Cemento 25kg", "sku": "CMT-25", "precio": 4500, "stock": 1000},
                    {"nombre": "Ladrillo Fiscal", "sku": "LDR-FSC", "precio": 350, "stock": 5000},
                    {"nombre": "Fierro Estriado 6mm", "sku": "FRR-6", "precio": 3200, "stock": 800},
                    {"nombre": "Arena Fina m3", "sku": "ARN-FN", "precio": 18000, "stock": 50},
                    {"nombre": "Grava 3/4 m3", "sku": "GRV-34", "precio": 22000, "stock": 40},
                ],
            },
        ]

        for c_data in companies_data:
            print(f"Processing details for {c_data['rut']}...")
            company = db.query(Empresa).filter(Empresa.rut == c_data["rut"]).first()
            if not company:
                print(f"Company {c_data['rut']} not found. Skipping.")
                continue

            sucursal = db.query(Sucursal).filter_by(
                empresa_id=company.id, nombre=c_data["sucursal"]
            ).first()
            if not sucursal:
                print(f"Creating Sucursal: {c_data['sucursal']}")
                sucursal = Sucursal(
                    nombre=c_data["sucursal"],
                    empresa_id=company.id,
                    direccion="Dirección Demo 123",
                )
                db.add(sucursal)
                db.commit()
                db.refresh(sucursal)
            else:
                print(f"Sucursal {c_data['sucursal']} exists.")

            bodega = db.query(Bodega).filter_by(
                sucursal_id=sucursal.id, nombre=c_data["bodega"]
            ).first()
            if not bodega:
                print(f"Creating Bodega: {c_data['bodega']}")
                bodega = Bodega(
                    nombre=c_data["bodega"],
                    sucursal_id=sucursal.id,
                    codigo=f"BOD-{company.codigo}",
                )
                db.add(bodega)
                db.commit()
                db.refresh(bodega)
            else:
                print(f"Bodega {c_data['bodega']} exists.")

            for p_data in c_data["productos"]:
                producto = db.query(Producto).filter_by(
                    empresa_id=company.id, sku=p_data["sku"]
                ).first()
                if not producto:
                    print(f"Creating Product: {p_data['nombre']}")
                    producto = Producto(
                        nombre=p_data["nombre"],
                        sku=p_data["sku"],
                        precio=p_data["precio"],
                        empresa_id=company.id,
                        is_active=True,
                    )
                    db.add(producto)
                    db.commit()
                    db.refresh(producto)

                inventario = db.query(Inventario).filter_by(
                    bodega_id=bodega.id, producto_id=producto.id
                ).first()
                if not inventario:
                    print(
                        f"Setting Initial Stock for {p_data['sku']}: {p_data['stock']}"
                    )
                    inventario = Inventario(
                        producto_id=producto.id,
                        bodega_id=bodega.id,
                        cantidad=p_data["stock"],
                    )
                    db.add(inventario)
                    db.commit()

        print("Seed details completed successfully.")
    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    seed_company_details()

