import sys
import os
import requests
import json  # noqa: F401
import hashlib  # noqa: F401
import time  # noqa: F401
from sqlalchemy.orm import Session  # noqa: F401
from dotenv import load_dotenv

backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
load_dotenv(os.path.join(backend_path, ".env"))

sys.path.append(backend_path)

from app.core.database import SessionLocal
from app.core_modules.crm.models import (
    OportunidadVenta,
    EstadoOportunidad,
    EstadoCredito,
    DetalleOportunidad,
    Embudo,
    Etapa,
)
from app.core_modules.sistema.models import Empresa, Usuario, Bodega, Sucursal
from app.core_modules.ventas.models import Producto, Cliente
from app.core_modules.legal.models import DocumentoLegal, EstadoDocumento
import app.core_modules.finanzas.models  # noqa: F401
import app.core_modules.compras.models  # noqa: F401
import app.core_modules.rrhh.models  # noqa: F401

API_URL = "http://localhost:8000/api/v1"
CRM_URL = f"{API_URL}/crm"
STORAGE_ROOT = os.path.join(backend_path, "storage_files")


class TestContext:
    def __init__(self):
        self.db = SessionLocal()
        self.opp_id = None
        self.bodega_id = None
        self.doc_id_1 = None
        self.doc_path_1 = None
        self.doc_id_2 = None

    def close(self):
        self.db.close()


def setup_test_data(ctx):
    print("[SETUP] Creating test data...")
    db = ctx.db

    empresa = db.query(Empresa).first()
    if not empresa:
        empresa = Empresa(nombre="Test Corp", rut="99.999.999-9")
        db.add(empresa)
        db.commit()

    usuario = db.query(Usuario).first()
    if not usuario:
        usuario = Usuario(
            email="test_cycle@test.com",
            password_hash="hash",
            empresa_id=empresa.id,
            rol="admin",
        )
        db.add(usuario)
        db.commit()

    cliente = db.query(Cliente).filter_by(rut="22.222.222-2").first()
    if not cliente:
        cliente = Cliente(
            nombre="Cliente Ciclo Completo",
            rut="22.222.222-2",
            empresa_id=empresa.id,
        )
        db.add(cliente)
        db.commit()

    producto = db.query(Producto).first()
    if not producto:
        producto = Producto(
            nombre="Producto Test",
            sku="TEST-001",
            precio=1000,
            empresa_id=empresa.id,
        )
        db.add(producto)
        db.commit()

    sucursal = db.query(Sucursal).first()
    if not sucursal:
        sucursal = Sucursal(
            nombre="Sucursal Test", codigo="SUC-TEST", empresa_id=empresa.id
        )
        db.add(sucursal)
        db.commit()

    bodega = db.query(Bodega).first()
    if not bodega:
        bodega = Bodega(nombre="Bodega Central", sucursal_id=sucursal.id)
        db.add(bodega)
        db.commit()
    ctx.bodega_id = bodega.id

    embudo = db.query(Embudo).first()
    if not embudo:
        embudo = Embudo(nombre="Ventas General", empresa_id=empresa.id)
        db.add(embudo)
        db.commit()

    etapa = db.query(Etapa).first()
    if not etapa:
        etapa = Etapa(
            nombre="Prospecto",
            orden=1,
            probabilidad_exito=10,
            embudo_id=embudo.id,
        )
        db.add(etapa)
        db.commit()

    opp = OportunidadVenta(
        titulo="Oportunidad Ciclo Completo + Anulación",
        monto_estimado=50000,
        moneda="CLP",
        cliente_id=cliente.id,
        usuario_id=usuario.id,
        empresa_id=empresa.id,
        etapa_id=etapa.id,
        estado=EstadoOportunidad.ABIERTA,
        estado_credito=EstadoCredito.PENDIENTE,
        bodega_id=None,
    )
    db.add(opp)
    db.commit()
    db.refresh(opp)

    detalle = DetalleOportunidad(
        oportunidad_id=opp.id,
        producto_id=producto.id,
        cantidad=5,
        precio_unitario=10000,
        subtotal=50000,
    )
    db.add(detalle)
    db.commit()

    ctx.opp_id = opp.id
    print(f"[SETUP] Created Opportunity ID: {ctx.opp_id}")


def run_lifecycle_test():
    ctx = TestContext()
    try:
        setup_test_data(ctx)

        print("\n[TEST 1] Intento de Firma sin Aprobación...")
        url_prepare = f"{CRM_URL}/opportunities/{ctx.opp_id}/prepare-signature"
        res = requests.post(url_prepare)
        if res.status_code == 400:
            print("✅ CORRECTO: Rechazado (400) por falta de aprobación.")
        else:
            print(f"❌ FALLO: Se esperaba 400, se obtuvo {res.status_code}")
            return

        print("\n[STEP 2] Simulando Aprobación de Crédito y Reserva de Stock...")
        opp = ctx.db.query(OportunidadVenta).get(ctx.opp_id)
        opp.estado_credito = EstadoCredito.APROBADO
        opp.bodega_id = ctx.bodega_id
        ctx.db.commit()

        print("\n[TEST 3] Generación de Guía (Intento 1)...")
        res = requests.post(url_prepare)
        if res.status_code == 200:
            data = res.json()
            ctx.doc_id_1 = data["documento_id"]
            print(f"✅ CORRECTO: Documento generado ID: {ctx.doc_id_1}")

            opp = ctx.db.query(OportunidadVenta).get(ctx.opp_id)
            if opp.estado == EstadoOportunidad.ESPERANDO_FIRMA:
                print("✅ Estado Oportunidad: ESPERANDO_FIRMA")
            else:
                print(f"❌ Estado Incorrecto: {opp.estado}")

            doc1 = ctx.db.query(DocumentoLegal).get(ctx.doc_id_1)
            ctx.doc_path_1 = doc1.ruta_archivo
        else:
            print(f"❌ FALLO: {res.text}")
            return

        print("\n[TEST 4] Anulación del Documento (Simulación de Error)...")
        url_void = f"{CRM_URL}/opportunities/{ctx.opp_id}/void-document"
        res = requests.post(url_void)

        if res.status_code == 200:
            print("✅ CORRECTO: Solicitud de anulación exitosa.")

            ctx.db.refresh(opp)
            if opp.estado == EstadoOportunidad.ABIERTA:
                print("✅ Estado Oportunidad: ABIERTA (Editable)")
            else:
                print(f"❌ Estado Incorrecto: {opp.estado}")

            ctx.db.expire_all()
            doc1 = ctx.db.query(DocumentoLegal).get(ctx.doc_id_1)
            if doc1.estado == EstadoDocumento.ANULADO:
                print("✅ Estado Documento 1: ANULADO")
            else:
                print(f"❌ Estado Doc 1 Incorrecto: {doc1.estado}")
        else:
            print(f"❌ FALLO al anular: {res.text}")
            return

        print("\n[TEST 5] Regeneración de Guía (Intento 2 - Corrección)...")
        if opp.estado_credito != EstadoCredito.APROBADO:
            print(f"⚠️ Aviso: Estado crédito cambió a {opp.estado_credito}. Restaurando...")
            opp.estado_credito = EstadoCredito.APROBADO
            ctx.db.commit()

        res = requests.post(url_prepare)
        if res.status_code == 200:
            data = res.json()
            ctx.doc_id_2 = data["documento_id"]
            print(f"✅ CORRECTO: Nuevo Documento generado ID: {ctx.doc_id_2}")

            if ctx.doc_id_1 == ctx.doc_id_2:
                print("❌ FALLO: El ID del documento no cambió (Sobrescritura detectada)")
            else:
                print("✅ Versionamiento: ID diferente confirmado.")

            doc2 = ctx.db.query(DocumentoLegal).get(ctx.doc_id_2)

            path1 = os.path.join(STORAGE_ROOT, ctx.doc_path_1)
            path2 = os.path.join(STORAGE_ROOT, doc2.ruta_archivo)

            if os.path.exists(path1):
                print(f"✅ Archivo Anulado existe (Evidencia): {ctx.doc_path_1}")
            else:
                print(
                    f"⚠️ Archivo Anulado NO encontrado en local (¿Usando R2?): {ctx.doc_path_1}"
                )

            if os.path.exists(path2):
                print(f"✅ Archivo Nuevo existe: {doc2.ruta_archivo}")
        else:
            print(f"❌ FALLO al regenerar: {res.text}")
            return

        print("\n[TEST 6] Confirmar Impresión...")
        url_confirm = f"{CRM_URL}/opportunities/{ctx.opp_id}/confirm-print"
        res = requests.post(url_confirm)

        if res.status_code == 200:
            ctx.db.refresh(opp)
            if opp.estado == EstadoOportunidad.ESPERANDO_FIRMA_MANUAL:
                print("✅ CORRECTO: Estado final ESPERANDO_FIRMA_MANUAL")
            else:
                print(f"❌ Estado Incorrecto: {opp.estado}")
        else:
            print(f"❌ FALLO al confirmar impresión: {res.text}")

        print("\n" + "=" * 50)
        print("RESUMEN: CICLO DE VIDA COMPLETO EXITOSO")
        print("=" * 50)
    except Exception as e:
        print(f"❌ ERROR CRÍTICO: {e}")
        import traceback

        traceback.print_exc()
    finally:
        ctx.close()


if __name__ == "__main__":
    run_lifecycle_test()

