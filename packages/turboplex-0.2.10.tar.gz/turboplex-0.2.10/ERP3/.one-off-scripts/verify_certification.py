
import sys
import os
from datetime import date, timedelta
import logging

# Add backend to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto, ProductoCertificacion, Inventario
from app.core_modules.sistema.models import Usuario, Bodega, Empresa
from app.core_modules.crm.models import Notification
from app.core_modules.ventas.inventory_service import InventoryService
from app.core_modules.ventas.tasks import check_certifications_expiration
from app.core.exceptions import BusinessRuleError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_verification():
    db = SessionLocal()
    try:
        logger.info("--- Starting Certification Shield Verification ---")

        # 1. Setup Data
        # Ensure Empresa exists
        empresa = db.query(Empresa).first()
        if not empresa:
            empresa = Empresa(nombre="Empresa Test", rut="11111111-1", codigo="EMP-TEST")
            db.add(empresa)
            db.commit()
            db.refresh(empresa)
        logger.info(f"Empresa ID: {empresa.id}")

        # Create or Get Product
        prod_sku = "TEST-CERT-SKU-001"
        producto = db.query(Producto).filter(Producto.sku == prod_sku).first()
        if not producto:
            producto = Producto(
                nombre="Producto Test Certificacion",
                sku=prod_sku,
                precio=1000,
                empresa_id=empresa.id,
                tipo_producto="ALMACENABLE"
            )
            db.add(producto)
            db.commit()
            db.refresh(producto)
        logger.info(f"Product ID: {producto.id}")

        # Create or Get Bodega
        bodega = db.query(Bodega).first()
        if not bodega:
            # Check if we have a sucursal first
            from app.core_modules.sistema.models import Sucursal
            sucursal = db.query(Sucursal).first()
            if not sucursal:
                sucursal = Sucursal(nombre="Sucursal Central", codigo="SUC-001", empresa_id=empresa.id)
                db.add(sucursal)
                db.commit()
                db.refresh(sucursal)
                
            bodega = Bodega(nombre="Bodega Central", sucursal_id=sucursal.id, codigo="BOD-001")
            db.add(bodega)
            db.commit()
            db.refresh(bodega)
        logger.info(f"Bodega ID: {bodega.id}")

        # Ensure Stock
        inventario = db.query(Inventario).filter(
            Inventario.producto_id == producto.id,
            Inventario.bodega_id == bodega.id
        ).first()
        if not inventario:
            inventario = Inventario(producto_id=producto.id, bodega_id=bodega.id, cantidad=100)
            db.add(inventario)
        else:
            inventario.cantidad = 100 # Reset stock
        db.commit()

        # Create Admin User for Notifications
        admin = db.query(Usuario).filter(Usuario.email == "admin_test@erp3.cl").first()
        if not admin:
            admin = Usuario(
                email="admin_test@erp3.cl",
                hashed_password="hash",
                role="ADMIN",
                is_active=True
            )
            db.add(admin)
            db.commit()
            db.refresh(admin)
        logger.info(f"Admin ID: {admin.id}")

        # Clean previous certifications for this product
        db.query(ProductoCertificacion).filter(ProductoCertificacion.producto_id == producto.id).delete()
        db.commit()

        # 2. Test Valid Certification Consumption
        logger.info("\n--- Test 1: Consumption with VALID certification ---")
        cert = ProductoCertificacion(
            producto_id=producto.id,
            numero_resolucion="RES-2026-001",
            fecha_emision=date.today() - timedelta(days=100),
            fecha_vencimiento=date.today() + timedelta(days=365), # Valid for a year
            organismo_certificador="ISP",
            documento_url="http://example.com/cert.pdf"
        )
        db.add(cert)
        db.commit()
        db.refresh(cert)

        try:
            InventoryService.consume_stock(
                db, producto.id, bodega.id, 1, "VENTA", 1
            )
            logger.info("SUCCESS: Stock consumed with valid certification.")
        except Exception as e:
            logger.error(f"FAILURE: Unexpected error with valid certification: {e}")
            raise

        # 3. Test Expired Certification Consumption
        logger.info("\n--- Test 2: Consumption with EXPIRED certification ---")
        cert.fecha_vencimiento = date.today() - timedelta(days=1) # Expired yesterday
        db.commit()

        try:
            InventoryService.consume_stock(
                db, producto.id, bodega.id, 1, "VENTA", 1
            )
            logger.error("FAILURE: Stock consumed despite expired certification!")
        except BusinessRuleError as e:
            logger.info(f"SUCCESS: Blocked correctly with error: {e}")
        except Exception as e:
            logger.error(f"FAILURE: Unexpected error type (expected BusinessRuleError): {type(e)} - {e}")

        # 4. Test Worker Notification
        logger.info("\n--- Test 3: Worker Notification for expiring certification ---")
        # Set expiration to 10 days from now (within 30 day window)
        cert.fecha_vencimiento = date.today() + timedelta(days=10)
        db.commit()

        # Clear previous notifications for this admin
        # (Optional, but helps verification)
        
        # Run Task
        check_certifications_expiration()

        # Check Notification
        notif = db.query(Notification).filter(
            Notification.usuario_id == admin.id,
            Notification.mensaje.like(f"%Certificación {cert.numero_resolucion}%")
        ).order_by(Notification.created_at.desc()).first()

        if notif:
            logger.info(f"SUCCESS: Notification found: {notif.mensaje}")
        else:
            logger.error("FAILURE: No notification found for expiring certification.")

        logger.info("\n--- Verification Completed ---")

    except Exception as e:
        logger.error(f"Verification Script Failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    run_verification()
