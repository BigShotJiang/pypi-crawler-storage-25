import os
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.core.security import get_password_hash
from app.core_modules.sistema.models import Usuario

def run() -> None:
    email = os.getenv("DEV_USER_EMAIL", "dev@erp3.com")
    password = os.getenv("DEV_USER_PASSWORD", "admin")
    db: Session = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        user = db.query(Usuario).filter(Usuario.email == email).first()
        if user:
            user.hashed_password = get_password_hash(password)
            user.role = "DEVELOPER"
            user.is_active = True
            user.mfa_enabled = False
            user.mfa_enforced = False
            db.add(user)
            db.commit()
            db.refresh(user)
            print(str(user.id))
            return
        user = Usuario(
            email=email,
            hashed_password=get_password_hash(password),
            role="DEVELOPER",
            is_active=True,
            mfa_enabled=False,
            mfa_enforced=False,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        print(str(user.id))
    finally:
        try:
            db.close()
        except Exception:
            pass

if __name__ == "__main__":
    run()
