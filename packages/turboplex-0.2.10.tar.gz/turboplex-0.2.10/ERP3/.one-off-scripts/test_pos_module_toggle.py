import sys
import os
from typing import List, Optional, Any
from pydantic import BaseModel

# Mocking the EmpresaBase schema structure to test the property logic
class EmpresaBase(BaseModel):
    modulos_activos: Optional[List[str]] = []
    feature_flags: Optional[Any] = {}

    @property
    def permitir_pagos_efectivo(self) -> bool:
        # Check if POS module is active in modulos_activos list
        # We assume "POS" or "CAJA" or "VENTAS_POS" is the key. 
        # Standard list: ["CORE", "VENTAS", "FINANZAS", "RRHH", "TI", "SISTEMA"]
        # User said "considera el módulo de Caja como un Add-on opcional".
        # Let's check for "POS" or "CAJA" in modulos_activos.
        is_pos_active = False
        if self.modulos_activos:
            is_pos_active = any(m in self.modulos_activos for m in ["POS", "CAJA", "POS_RETAIL"])
        
        if not is_pos_active:
            return False

        if self.feature_flags:
             # Default True if not specified, or False? 
             # Usually cash is allowed by default, unless disabled.
             # User said "Agrega... un switch", implying it might be off by default or configurable.
             # Let's assume default True for now, but respect flag.
             return self.feature_flags.get("permitir_pagos_efectivo", True)
        return True

def test_cases():
    print("Running POS Module Logic Tests...")
    
    # Case 1: POS Active, No Feature Flag (Default True)
    empresa1 = EmpresaBase(modulos_activos=["CORE", "VENTAS", "POS"])
    assert empresa1.permitir_pagos_efectivo == True, "Case 1 Failed: POS active should default to True"
    print("Case 1 Passed: POS active -> True")

    # Case 2: POS Active, Feature Flag True
    empresa2 = EmpresaBase(modulos_activos=["CORE", "POS"], feature_flags={"permitir_pagos_efectivo": True})
    assert empresa2.permitir_pagos_efectivo == True, "Case 2 Failed: POS active + Flag True should be True"
    print("Case 2 Passed: POS active + Flag True -> True")

    # Case 3: POS Active, Feature Flag False
    empresa3 = EmpresaBase(modulos_activos=["CORE", "POS"], feature_flags={"permitir_pagos_efectivo": False})
    assert empresa3.permitir_pagos_efectivo == False, "Case 3 Failed: POS active + Flag False should be False"
    print("Case 3 Passed: POS active + Flag False -> False")

    # Case 4: POS Inactive (Default Modules)
    empresa4 = EmpresaBase(modulos_activos=["CORE", "VENTAS", "FINANZAS"])
    assert empresa4.permitir_pagos_efectivo == False, "Case 4 Failed: POS inactive should be False"
    print("Case 4 Passed: POS inactive -> False")

    # Case 5: POS Inactive, but Feature Flag True (Should still be False because POS is required)
    empresa5 = EmpresaBase(modulos_activos=["CORE", "VENTAS"], feature_flags={"permitir_pagos_efectivo": True})
    assert empresa5.permitir_pagos_efectivo == False, "Case 5 Failed: POS inactive should override Flag True"
    print("Case 5 Passed: POS inactive + Flag True -> False")

    # Case 6: CAJA as alias
    empresa6 = EmpresaBase(modulos_activos=["CORE", "CAJA"])
    assert empresa6.permitir_pagos_efectivo == True, "Case 6 Failed: CAJA alias should work"
    print("Case 6 Passed: CAJA alias -> True")
    
    # Case 7: POS_RETAIL as alias (from frontend sidebar)
    empresa7 = EmpresaBase(modulos_activos=["CORE", "POS_RETAIL"])
    assert empresa7.permitir_pagos_efectivo == True, "Case 7 Failed: POS_RETAIL alias should work"
    print("Case 7 Passed: POS_RETAIL alias -> True")

    print("\nAll logic tests passed!")

if __name__ == "__main__":
    try:
        test_cases()
    except AssertionError as e:
        print(f"\nTest Failed: {e}")
        sys.exit(1)
