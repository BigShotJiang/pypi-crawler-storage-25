
import unittest
import os
import shutil
import io
import uuid
from unittest.mock import MagicMock, patch
from sqlalchemy.orm import Session

# Add backend to path
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

# Mock boto3 before importing storage_service if it's not installed or just to be safe
with patch.dict(os.environ, {
    "STORAGE_MODE": "local",
    "LOCAL_STORAGE_PATH": "test_storage",
    "DATABASE_URL": "sqlite:///:memory:",
    "SECRET_KEY": "test",
}):
    from app.services.storage_service import StorageService
    # Import app.models to ensure all mappers are registered
    from app.core_modules.legal.models import EstadoDocumento

class TestStorageService(unittest.TestCase):
    
    def setUp(self):
        self.service = StorageService()
        # Clean test storage
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")
        os.makedirs("test_storage")

    def tearDown(self):
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")

    def test_generate_path(self):
        tenant_id = 1
        rut = "12.345.678-9"
        uuid_str = str(uuid.uuid4())
        
        path = self.service._generate_path(tenant_id, rut, uuid_str)
        
        self.assertIn(f"tenant_{tenant_id}", path)
        self.assertIn("rut_12.345.678-9", path)
        self.assertTrue(path.endswith(f"{uuid_str}.pdf"))

    def test_upload_local(self):
        content = b"PDF CONTENT"
        file_obj = io.BytesIO(content)
        path = "test/file.pdf"
        
        saved_path = self.service.upload_file(file_obj, path)
        
        self.assertEqual(saved_path, path)
        full_path = os.path.join("test_storage", path)
        self.assertTrue(os.path.exists(full_path))
        
        with open(full_path, "rb") as f:
            self.assertEqual(f.read(), content)

    def test_register_legal_document(self):
        # Mock DB
        db = MagicMock(spec=Session)
        
        content = b"PDF CONTENT"
        file_obj = io.BytesIO(content)
        oportunidad_id = 100
        tenant_id = 1
        rut = "11.222.333-K"
        
        doc = self.service.register_legal_document(
            db=db,
            file_obj=file_obj,
            oportunidad_id=oportunidad_id,
            tenant_id=tenant_id,
            rut_cliente=rut
        )
        
        # Verify DB add/commit
        self.assertTrue(db.add.called)
        self.assertTrue(db.commit.called)
        self.assertTrue(db.refresh.called)
        
        # Verify Document Attributes
        self.assertEqual(doc.oportunidad_id, oportunidad_id)
        self.assertEqual(doc.tenant_id, tenant_id)
        self.assertEqual(doc.estado, EstadoDocumento.PENDIENTE)
        self.assertIn(f"tenant_{tenant_id}", doc.ruta_archivo)
        
        # Verify File Existence
        full_path = os.path.join("test_storage", doc.ruta_archivo)
        self.assertTrue(os.path.exists(full_path))

if __name__ == '__main__':
    unittest.main()
