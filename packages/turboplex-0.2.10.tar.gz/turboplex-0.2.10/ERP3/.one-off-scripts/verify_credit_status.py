import sys
import os
from decimal import Decimal
from datetime import datetime

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'backend'))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
from app.core_modules.sistema.models import Empresa, Usuario
from app.core_modules.ventas.models import Cliente
from app.core_modules.crm.models import CrmCliente, CrmExcepcionCredito
from app.core_modules.finanzas.models import CuentaContable, AsientoContable, MovimientoContable
from app.core_modules.crm.services.credito import CRMServiceCredito
from app.core_modules.crm.schemas import CrmEstadoCredito

# Database setup
engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
db = SessionLocal()

def verify_credit_status():
    print("Iniciando verificación de Estado de Crédito CRM -> ERP...")
    
    # Bypass tenant check for setup
    db.info["allow_no_tenant"] = True
    
    # 1. Setup Data
    empresa = Empresa(
        nombre="Empresa Test Credito",
        rut="77.777.777-7",
        codigo="TEST-CREDIT"
    )
    db.add(empresa)
    db.flush()

    usuario = Usuario(
        email="test@user.com",
        hashed_password="...",
        role="USER",
        is_active=True
    )
    db.add(usuario)
    db.commit()
    
    # 2. Setup Accounts (Plan de Cuentas minimo)
    # 1.1.02.01 = Clientes Nacionales (Activo)
    cuenta_clientes = CuentaContable(
        codigo="1.1.02.01",
        nombre="Clientes Nacionales",
        tipo_cuenta="ACTIVO",
        nivel=4,
        es_imputable=True,
        empresa_id=empresa.id
    )
    # 4.1.01.01 = Ventas (Ingreso)
    cuenta_ventas = CuentaContable(
        codigo="4.1.01.01",
        nombre="Ventas",
        tipo_cuenta="INGRESO",
        nivel=4,
        es_imputable=True,
        empresa_id=empresa.id
    )
    db.add_all([cuenta_clientes, cuenta_ventas])
    db.commit()
    
    # 3. Create Client (Synced)
    rut_cliente = "11.111.111-1"
    
    # ERP Client
    erp_cliente = Cliente(
        nombre="Cliente Test",
        rut=rut_cliente,
        empresa_id=empresa.id,
        _limite_credito=Decimal("10000.00")
    )
    db.add(erp_cliente)
    
    # CRM Client
    crm_cliente = CrmCliente(
        rut=rut_cliente,
        razon_social="Cliente Test",
        empresa_id=empresa.id,
        estado_comercial="ACTIVO"
    )
    db.add(crm_cliente)
    db.commit()
    
    # 4. Create Debt (Asiento Contable)
    # Venta de 1000. Debe Cliente, Haber Ventas.
    asiento = AsientoContable(
        glosa="Venta Test",
        origen="VENTAS",
        fecha=datetime.now(),
        empresa_id=empresa.id,
        usuario_id=usuario.id,
        estado="CONFIRMADO",
        rut_tercero=rut_cliente
    )
    db.add(asiento)
    db.flush()
    
    mov_debe = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_clientes.id,
        debe=Decimal("1000.00"),
        haber=Decimal("0.00")
    )
    mov_haber = MovimientoContable(
        asiento_id=asiento.id,
        cuenta_id=cuenta_ventas.id,
        debe=Decimal("0.00"),
        haber=Decimal("1000.00")
    )
    db.add_all([mov_debe, mov_haber])
    db.commit()
    
    # 5. Verify Credit Status
    print(f"Verificando estado para CRM Cliente {crm_cliente.id}...")
    try:
        estado: CrmEstadoCredito = CRMServiceCredito.get_estado_credito(
            db, crm_cliente.id, empresa.id
        )
        
        print(f"Límite Crédito: {estado.limite_credito}")
        print(f"Monto Utilizado: {estado.monto_utilizado}")
        print(f"Disponible: {estado.monto_disponible}")
        print(f"Estado: {estado.estado}")
        
        # Assertions
        assert estado.limite_credito == Decimal("10000.00")
        assert estado.monto_utilizado == Decimal("1000.00")
        assert estado.monto_disponible == Decimal("9000.00")
        assert estado.estado == "APROBADO"
        
        if estado.estado == "APROBADO":
             print("SUCCESS: Estado APROBADO correcto (Saldo positivo).")
        else:
             print(f"WARNING: Estado {estado.estado} (Esperado APROBADO)")

        # 6. Add Exception and Verify
        print("Agregando Excepción de Crédito...")
        excepcion = CrmExcepcionCredito(
            cliente_rut=rut_cliente,
            monto_autorizado=Decimal("5000.00"),
            monto_consumido=Decimal("1000.00"),
            version=1
        )
        db.add(excepcion)
        db.commit()
        
        estado_excepcion = CRMServiceCredito.get_estado_credito(
            db, crm_cliente.id, empresa.id
        )
        print(f"Disponible con Excepción: {estado_excepcion.monto_disponible}")
        print(f"Monto Excepción: {estado_excepcion.monto_excepcion}")
        
        assert estado_excepcion.tiene_excepcion is True
        assert estado_excepcion.monto_excepcion == Decimal("4000.00")
        # Base Available: 9000. Exception Available: 4000. Total: 13000.
        assert estado_excepcion.monto_disponible == Decimal("13000.00")
        print("SUCCESS: Verificación con excepción correcta.")

    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Cleanup
        print("Cleaning up...")
        # Delete movements, asiento, clients, accounts, company
        db.query(MovimientoContable).filter(MovimientoContable.asiento_id == asiento.id).delete()
        db.delete(asiento)
        if 'excepcion' in locals():
            db.delete(excepcion)
        db.delete(crm_cliente)
        db.delete(erp_cliente)
        db.delete(cuenta_clientes)
        db.delete(cuenta_ventas)
        db.delete(usuario)
        db.delete(empresa)
        db.commit()
        db.close()

if __name__ == "__main__":
    verify_credit_status()
