import sys
import os
from sqlalchemy.orm import Session  # noqa: F401
from dotenv import load_dotenv

backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
load_dotenv(os.path.join(backend_path, ".env"))

sys.path.append(backend_path)

from app.core.database import SessionLocal
from app.core_modules.crm.models import OportunidadVenta, EstadoCredito
from app.core_modules.crm.services import CRMService
import app.core_modules.legal.models  # noqa: F401
import app.core_modules.finanzas.models  # noqa: F401
import app.core_modules.ventas.models  # noqa: F401
import app.core_modules.rrhh.models  # noqa: F401
import app.core_modules.compras.models  # noqa: F401


def debug_service():
    print("Debugging CRMService.prepare_signature...")
    db = SessionLocal()
    try:
        opp_id = 6

        opp = db.query(OportunidadVenta).get(opp_id)
        if not opp:
            print(f"Opportunity {opp_id} not found.")
            return

        print(
            f"Opp: {opp.titulo}, Estado Crédito: {opp.estado_credito}, Bodega: {opp.bodega_id}"
        )

        if opp.estado_credito != EstadoCredito.APROBADO:
            print("Forcing Approval...")
            opp.estado_credito = EstadoCredito.APROBADO
            if not opp.bodega_id:
                opp.bodega_id = 1
            db.commit()

        print("Calling prepare_signature...")
        result = CRMService.prepare_signature(db, opp_id)
        print("Success!")
        print(result)
    except Exception:
        print("❌ Exception Caught:")
        import traceback

        traceback.print_exc()
    finally:
        db.close()


if __name__ == "__main__":
    debug_service()

