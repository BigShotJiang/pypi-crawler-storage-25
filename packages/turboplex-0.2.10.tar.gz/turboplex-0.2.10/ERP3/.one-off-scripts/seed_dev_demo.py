import sys
from pathlib import Path
from sqlalchemy.orm import Session

# Ensure backend is importable
BACKEND_DIR = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Rol, Usuario, UsuarioEmpresa, Sucursal, MetodoPago

def main():
    db: Session = SessionLocal()
    db.info["allow_no_tenant"] = True
    try:
        empresa = db.query(Empresa).filter(Empresa.codigo == "DEMO_CO").first()
        if not empresa:
            empresa = Empresa(nombre="Demo Company", codigo="DEMO_CO")
            db.add(empresa); db.commit(); db.refresh(empresa)

        def ensure_rol(codigo, nombre):
            r = db.query(Rol).filter(Rol.empresa_id == empresa.id, Rol.codigo == codigo).first()
            if not r:
                r = Rol(empresa_id=empresa.id, codigo=codigo, nombre=nombre)
                db.add(r); db.commit()
            return r

        rol_adm = ensure_rol("ADM", "Administrador")
        ensure_rol("SUP", "Supervisor")
        ensure_rol("VEN", "Vendedor")
        ensure_rol("BOD", "Bodega")
        ensure_rol("CON", "Contador")

        user = db.query(Usuario).filter(Usuario.email == "demo.admin@erp.local").first()
        if not user:
            user = Usuario(email="demo.admin@erp.local", hashed_password="demo", is_active=True)
            db.add(user); db.commit(); db.refresh(user)

        link = db.query(UsuarioEmpresa).filter(
            UsuarioEmpresa.usuario_id == user.id,
            UsuarioEmpresa.empresa_id == empresa.id
        ).first()
        if not link:
            link = UsuarioEmpresa(usuario_id=user.id, empresa_id=empresa.id, rol_id=rol_adm.id, is_default=True)
            db.add(link); db.commit()

        suc = db.query(Sucursal).filter(
            Sucursal.empresa_id == empresa.id,
            Sucursal.nombre == "SUCURSAL_DEMO"
        ).first()
        if not suc:
            suc = Sucursal(empresa_id=empresa.id, nombre="SUCURSAL_DEMO", codigo="DEMO-001")
            db.add(suc); db.commit()

        mp = db.query(MetodoPago).filter(MetodoPago.codigo == "CASH").first()
        if not mp:
            mp = MetodoPago(nombre="Efectivo", codigo="CASH", is_active=True)
            db.add(mp); db.commit()

        print("Seed dev DEMO aplicado (empresa, roles, usuario admin, sucursal, método de pago).")
    finally:
        db.close()

if __name__ == "__main__":
    main()
