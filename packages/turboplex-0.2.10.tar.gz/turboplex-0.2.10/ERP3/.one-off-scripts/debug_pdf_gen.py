import sys
import os
import io  # noqa: F401
from unittest.mock import MagicMock
from datetime import datetime  # noqa: F401

backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
sys.path.append(backend_path)

from app.services.pdf_generator import PDFGenerator


def test_pdf_generation():
    print("Testing PDF Generation with Mock Data...")

    opp = MagicMock()
    opp.id = 123
    opp.monto_estimado = 50000
    opp.titulo = "Test Opp"

    client = MagicMock()
    client.nombre = "Cliente Test"
    client.rut = "11.111.111-1"
    client.direccion = None
    opp.cliente = client
    opp.bodega_id = "Bodega Central"

    item1 = MagicMock()
    del item1.codigo
    del item1.descripcion
    item1.cantidad = 5
    item1.precio_unitario = 10000

    items = [item1]

    try:
        buffer = PDFGenerator.generate_delivery_guide(
            opportunity=opp,
            items=items,
            validation_url="http://test.com",
            doc_hash="hash123",
        )
        print("✅ PDF Generated Successfully")

        with open("debug_output.pdf", "wb") as f:
            f.write(buffer.getvalue())
    except TypeError as e:
        print(f"❌ TypeError Caught: {e}")
        import traceback

        traceback.print_exc()
    except Exception as e:
        print(f"❌ Other Error: {e}")
        import traceback

        traceback.print_exc()


if __name__ == "__main__":
    test_pdf_generation()

