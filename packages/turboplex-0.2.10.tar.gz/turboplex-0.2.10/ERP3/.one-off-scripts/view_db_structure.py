from __future__ import annotations

import argparse
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _backend_root() -> Path:
    return _repo_root() / "backend"


def _read_env_database_url() -> str | None:
    env_path = _backend_root() / ".env"
    if not env_path.exists():
        return None
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("DATABASE_URL="):
                return s.split("=", 1)[1].strip()
    except Exception:
        return None
    return None


def _as_libpq_url(url: str) -> str:
    if url.startswith("postgresql+psycopg2://"):
        return url.replace("postgresql+psycopg2://", "postgresql://", 1)
    return url


def _resolve_tool_path(tool: str, *, explicit: str | None, pg_bin: str | None) -> str:
    if explicit:
        return explicit
    env_key = f"PG_{tool.upper()}_PATH"
    v = os.getenv(env_key)
    if v:
        return v
    if pg_bin:
        return str(Path(pg_bin) / f"{tool}.exe")
    return tool


def _run(cmd: list[str]) -> None:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        details = "\n".join(x for x in (out, err) if x)
        raise RuntimeError(details or f"Command failed: {' '.join(cmd)}")


def _extract_rls_policies(schema_file: Path, dst_file: Path) -> None:
    lines = []
    try:
        for line in schema_file.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if "ROW LEVEL SECURITY" in s or "CREATE POLICY" in s or "ALTER POLICY" in s:
                lines.append(line)
    except Exception:
        pass
    dst_file.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def _git_head() -> str:
    try:
        proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(_repo_root()), capture_output=True, text=True)
        if proc.returncode == 0:
            return proc.stdout.strip()
    except Exception:
        pass
    return "N/A"


def _write_summary(dst: Path, db_url: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S %Z")
    head = _git_head()
    lines = [
        f"Sello UTC: {ts}",
        f"Git HEAD: {head}",
        f"Origen: {db_url}",
    ]
    dst.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(prog="view_db_structure", description="Documenta estructura de DB (DDL, RLS, auditoría).")
    parser.add_argument("--output-dir", required=True, help="Directorio de salida")
    parser.add_argument("--source-db-url", default=None, help="URL origen; si no, lee backend/.env")
    parser.add_argument("--pg-dump", default=None, help="Ruta a pg_dump.exe")
    parser.add_argument("--pg-bin", default=os.getenv("POSTGRES_BIN", None), help="Directorio bin de PostgreSQL")
    parser.add_argument("--audit-table", default="audit_logs", help="Tabla de auditoría a exportar (opcional)")
    args = parser.parse_args()

    out_dir = Path(args.output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    db_url = args.source_db_url or _read_env_database_url() or ""
    if not db_url:
        raise SystemExit("No se encontró DATABASE_URL. Usa --source-db-url o configura backend/.env")
    pg_dump = _resolve_tool_path("pg_dump", explicit=args.pg_dump, pg_bin=args.pg_bin)

    ddl_path = out_dir / "db_tablas_y_relaciones.sql"
    rls_path = out_dir / "db_rls_policies.sql"
    aud_path = out_dir / "db_motor_auditoria.sql"
    summary_path = out_dir / "SUMMARY.txt"

    src_url = _as_libpq_url(db_url)

    _run([pg_dump, "--schema-only", "--no-owner", "--no-privileges", f"--file={str(ddl_path)}", src_url])
    _extract_rls_policies(ddl_path, rls_path)

    if args.audit_table:
        try:
            _run([pg_dump, "--schema-only", "--no-owner", "--no-privileges", f"--table={args.audit_table}", f"--file={str(aud_path)}", src_url])
        except RuntimeError as e:
            if "no matching tables were found" in str(e).lower():
                aud_path.write_text("", encoding="utf-8")
                print(f"Aviso: tabla '{args.audit_table}' no encontrada; auditoría omitida")
            else:
                raise

    _write_summary(summary_path, db_url)
    print(f"OK. Revisa: {str(out_dir)}")


if __name__ == "__main__":
    main()
