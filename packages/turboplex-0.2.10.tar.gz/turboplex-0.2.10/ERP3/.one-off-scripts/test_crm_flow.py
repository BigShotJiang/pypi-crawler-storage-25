
import sys
import os

# Set environment variables BEFORE importing app modules
os.environ["DATABASE_URL"] = "sqlite:///./test.db"
os.environ["SECRET_KEY"] = "supersecretkey"
os.environ["ALGORITHM"] = "HS256"
os.environ["ACCESS_TOKEN_EXPIRE_MINUTES"] = "30"

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

from unittest.mock import MagicMock

# Import dependencies to satisfy SQLAlchemy mappers
try:
    import app.core_modules.compras.models
    import app.core_modules.finanzas.models
    import app.core_modules.ventas.models
    import app.core_modules.sistema.models
except ImportError:
    pass

from app.core_modules.crm.services import CRMService
from app.core_modules.crm.models import OportunidadVenta, EstadoCredito
from app.core_modules.ventas.inventory_service import InventoryService

def test_reject_credit_approval():
    print("Testing reject_credit_approval...")
    
    # Mock Session
    db = MagicMock()
    
    # Mock Data
    oportunidad = OportunidadVenta(id=1, estado_credito=EstadoCredito.PENDIENTE)
    # Mock relationship details
    # Need to mock relationship properly or just assign list
    detalle = MagicMock()
    detalle.producto_id = 100
    detalle.cantidad = 5
    detalle.id = 1
    
    oportunidad.detalles = [detalle]
    oportunidad.bodega_id = 10
    oportunidad.usuario_id = 5
    
    # Setup query return
    query_mock = MagicMock()
    filter_mock = MagicMock()
    filter_mock.first.return_value = oportunidad
    query_mock.filter.return_value = filter_mock
    db.query.return_value = query_mock
    
    # Mock InventoryService release_reservation
    # We need to patch it because it's a static method on a class
    # But since we imported the class, we can patch the method on the class
    original_release = InventoryService.release_reservation
    InventoryService.release_reservation = MagicMock()
    
    try:
        # Execute
        CRMService.reject_credit_approval(db, oportunidad_id=1, comentario="Riesgo alto")
        
        # Verify
        # 1. Check state change
        if oportunidad.estado_credito != EstadoCredito.BLOQUEADO:
            raise AssertionError(f"Expected BLOQUEADO, got {oportunidad.estado_credito}")
        
        if oportunidad.bodega_id is not None:
             raise AssertionError(f"Expected bodega_id to be None, got {oportunidad.bodega_id}")
        
        # 2. Check stock release
        InventoryService.release_reservation.assert_called_with(
            db=db, 
            producto_id=100, 
            bodega_id=10, 
            cantidad=5
        )
        print("Stock release called correctly.")
        
        # 3. Check db.add calls (should add comment, notification, opportunity)
        # minimal check: called at least 3 times
        if db.add.call_count < 3:
             raise AssertionError(f"Expected at least 3 db.add calls, got {db.add.call_count}")
        
        print("SUCCESS: reject_credit_approval passed all checks.")
        
    finally:
        # Restore original method
        InventoryService.release_reservation = original_release

if __name__ == "__main__":
    try:
        test_reject_credit_approval()
    except Exception as e:
        print(f"FAILED: {e}")
        # import traceback
        # traceback.print_exc()
        sys.exit(1)
