import sys
import os
from decimal import Decimal, ROUND_HALF_UP

# Mocking the function directly to test the logic as if it was imported
def aplicar_ley_redondeo(monto: float) -> int:
    """
    Aplica la Ley de Redondeo (Chile) para pagos en efectivo.
    Regla:
    - Terminaciones 1, 2, 3, 4, 5 -> Redondea hacia abajo (a 0)
    - Terminaciones 6, 7, 8, 9    -> Redondea hacia arriba (a 10)
    
    El monto primero se redondea al entero más cercano (ROUND_HALF_UP)
    antes de aplicar la lógica de terminación.
    """
    if monto is None:
        return 0
        
    # Paso 1: Redondear a entero (0 decimales) usando Half Up (0.5 sube)
    # Convertir a Decimal para precisión
    val = Decimal(str(monto))
    entero = int(val.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    
    # Paso 2: Aplicar regla de terminación
    resto = entero % 10
    
    if resto == 0:
        return entero
        
    if 1 <= resto <= 5:
        return entero - resto
    else:  # 6, 7, 8, 9
        return entero + (10 - resto)

def test_cases():
    cases = [
        (100, 100),
        (101, 100),
        (102, 100),
        (103, 100),
        (104, 100),
        (105, 100),
        (106, 110),
        (107, 110),
        (108, 110),
        (109, 110),
        (110, 110),
        # Decimals
        (99.1, 100), # 99 -> 100
        (99.5, 100), # 100 -> 100
        (99.6, 100), # 100 -> 100
        (90.5, 90), # 91 -> 90
        (90.6, 90), # 91 -> 90
        # Wait, let's trace 90.5
        # 90.5 -> round half up -> 91. 91 ends in 1 -> 90. Correct.
        # 90.4 -> 90 -> 90. Correct.
        # 95.5 -> 96. 96 ends in 6 -> 100.
        (95.5, 100),
        (95.4, 90), # 95 -> 90. (Wait, 95 ends in 5 -> 90). Correct.
        (1500.50, 1500), # 1501 -> 1500
        (1505.50, 1510), # 1506 -> 1510
    ]
    
    print("Running Ley de Redondeo Tests...")
    failures = 0
    for inp, expected in cases:
        result = aplicar_ley_redondeo(inp)
        status = "PASS" if result == expected else f"FAIL (Got {result})"
        print(f"Input: {inp} -> Expected: {expected} -> {status}")
        if result != expected:
            failures += 1
            
    if failures == 0:
        print("\nAll tests passed!")
    else:
        print(f"\n{failures} tests failed.")
        sys.exit(1)

if __name__ == "__main__":
    test_cases()
