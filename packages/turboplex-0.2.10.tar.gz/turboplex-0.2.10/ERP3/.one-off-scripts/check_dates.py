import os
import datetime

files = [
    r"backend\app\main.py",
    r"pyproject.toml",
    r"backend\requirements.txt",
    r".Documentacion\changelog.md"
]

dirs = [r"c:\GitHub\ERP3", r"E:\ERP3"]

for f in files:
    print(f"\n--- {f} ---")
    for d in dirs:
        path = os.path.join(d, f)
        if os.path.exists(path):
            mtime = os.path.getmtime(path)
            dt = datetime.datetime.fromtimestamp(mtime)
            size = os.path.getsize(path)
            print(f"{d}: {dt} (Size: {size} bytes)")
        else:
            print(f"{d}: No existe")
