from pydantic import BaseModel, field_validator, ConfigDict
from typing import Optional, Any

class Base(BaseModel):
    val: Optional[float] = None
    
    @field_validator("val", mode="before")
    @classmethod
    def check(cls, v: Any) -> Any:
        print(f"Validator running for {v}")
        if v is None:
            return 0.0
        return v

class Child(Base):
    val: float = 0.0

try:
    print("Test Child(val=None)")
    c = Child(val=None)
    print(f"Result: {c.val} type={type(c.val)}")
except Exception as e:
    print(f"Error: {e}")

try:
    print("Test Child(val=1.5)")
    c = Child(val=1.5)
    print(f"Result: {c.val} type={type(c.val)}")
except Exception as e:
    print(f"Error: {e}")
