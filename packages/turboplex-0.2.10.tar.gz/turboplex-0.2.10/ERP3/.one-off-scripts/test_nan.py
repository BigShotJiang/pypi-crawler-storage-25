
import math

try:
    v = float("NaN")
    print(f"float('NaN'): {v}")
    r = round(v, 2)
    print(f"round(NaN, 2): {r}")
    print(f"is nan: {math.isnan(r)}")
except Exception as e:
    print(e)
