import sys
import os

backend_path = os.path.join(os.path.dirname(__file__), "..", "backend")
sys.path.append(backend_path)

try:
    print("Attempting to import api_router...")
    from app.api.v1.api import api_router  # noqa: F401
    print("Successfully imported api_router")

    print("Attempting to import models...")
    from app.models import Usuario, Venta, TicketLavanderia  # noqa: F401
    print("Successfully imported models")

    print("Attempting to import schemas...")
    from app.schemas import UsuarioCreate, VentaCreate  # noqa: F401
    print("Successfully imported schemas")

    print("Verification passed!")
except Exception as e:
    print(f"Verification failed: {e}")
    import traceback

    traceback.print_exc()

