import os
import sys
from pathlib import Path
from fastapi.testclient import TestClient

BACKEND_DIR = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from app.main import app  # noqa: E402


def main():
    url = os.environ.get("DATABASE_URL")
    if not url:
        print("ERROR: DATABASE_URL no definido en el entorno para smoke health.")
        raise SystemExit(1)

    client = TestClient(app)
    resp = client.get("/health")
    if resp.status_code != 200:
        print(f"Smoke /health FALLÓ: status={resp.status_code}, body={resp.text}")
        raise SystemExit(1)

    print(f"Smoke /health OK sobre DB: {url}")
    print(resp.json())


if __name__ == "__main__":
    main()

