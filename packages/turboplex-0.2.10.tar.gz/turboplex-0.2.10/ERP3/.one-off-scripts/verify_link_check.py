
import sys
import os
from datetime import datetime
import logging

# Add backend to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

from app.core.database import SessionLocal
from app.core_modules.ventas.models import Producto, ProductoCertificacion
from app.core_modules.ventas.tasks import check_certification_links_health
from app.core.utils import validate_url_format

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_verification():
    db = SessionLocal()
    try:
        logger.info("--- Starting Link Health Check Verification ---")
        
        # Check if validation function works
        logger.info(f"Validating 'https://google.com': {validate_url_format('https://google.com')}")
        logger.info(f"Validating 'invalid-url': {validate_url_format('invalid-url')}")
        
        # Get a product
        producto = db.query(Producto).first()
        if not producto:
            logger.error("No product found. Please run verify_certification.py first to create data.")
            return

        # Create Cert with Valid URL
        cert_valid = ProductoCertificacion(
            producto_id=producto.id,
            numero_resolucion="TEST-LINK-VALID",
            fecha_emision=datetime.now().date(),
            fecha_vencimiento=datetime.now().date(),
            organismo_certificador="TEST",
            documento_url="https://www.google.com",
            is_link_active=False # Start as False to see if it updates to True
        )
        db.add(cert_valid)
        
        # Create Cert with Invalid URL (broken link)
        cert_invalid = ProductoCertificacion(
            producto_id=producto.id,
            numero_resolucion="TEST-LINK-INVALID",
            fecha_emision=datetime.now().date(),
            fecha_vencimiento=datetime.now().date(),
            organismo_certificador="TEST",
            documento_url="https://this-domain-does-not-exist-12345.com",
            is_link_active=True # Start as True to see if it updates to False
        )
        db.add(cert_invalid)
        
        # Create Cert with Bad Format
        cert_bad_format = ProductoCertificacion(
            producto_id=producto.id,
            numero_resolucion="TEST-LINK-BAD-FORMAT",
            fecha_emision=datetime.now().date(),
            fecha_vencimiento=datetime.now().date(),
            organismo_certificador="TEST",
            documento_url="not-a-url",
            is_link_active=True
        )
        db.add(cert_bad_format)
        
        db.commit()
        db.refresh(cert_valid)
        db.refresh(cert_invalid)
        db.refresh(cert_bad_format)
        
        ids = [cert_valid.id, cert_invalid.id, cert_bad_format.id]
        logger.info(f"Created certs: {ids}")
        
        # Run Task
        check_certification_links_health()
        
        # Verify Results
        db.refresh(cert_valid)
        db.refresh(cert_invalid)
        db.refresh(cert_bad_format)
        
        logger.info(f"Valid URL (Expected True): {cert_valid.is_link_active}")
        logger.info(f"Invalid URL (Expected False): {cert_invalid.is_link_active}")
        logger.info(f"Bad Format (Expected False): {cert_bad_format.is_link_active}")
        
        if cert_valid.is_link_active and not cert_invalid.is_link_active and not cert_bad_format.is_link_active:
            logger.info("SUCCESS: Link check logic verified.")
        else:
            logger.error("FAILURE: Link check logic incorrect.")
            
        # Cleanup
        db.query(ProductoCertificacion).filter(ProductoCertificacion.id.in_(ids)).delete(synchronize_session=False)
        db.commit()
        
    except Exception as e:
        logger.error(f"Verification Script Failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    run_verification()
