from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _backend_root() -> Path:
    return _repo_root() / "backend"


def _read_env_database_url() -> str | None:
    env_path = _backend_root() / ".env"
    if not env_path.exists():
        return None
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("DATABASE_URL="):
                return s.split("=", 1)[1].strip()
    except Exception:
        return None
    return None


def _as_libpq_url(url: str) -> str:
    if url.startswith("postgresql+psycopg2://"):
        return url.replace("postgresql+psycopg2://", "postgresql://", 1)
    return url


def _safe_url(url: str) -> str:
    if "@" not in url:
        return url
    try:
        pre, post = url.split("@", 1)
        if "://" in pre:
            scheme, rest = pre.split("://", 1)
            if ":" in rest:
                user, _ = rest.split(":", 1)
                return f"{scheme}://{user}:***@{post}"
            return f"{scheme}://***@{post}"
    except Exception:
        pass
    return url


def _resolve_tool_path(tool: str, *, explicit: str | None, pg_bin: str | None) -> str:
    if explicit:
        return explicit
    env_key = f"PG_{tool.upper()}_PATH"
    v = os.getenv(env_key)
    if v:
        return v
    if pg_bin:
        return str(Path(pg_bin) / f"{tool}.exe")
    return tool


def _run(cmd: list[str]) -> None:
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        details = "\n".join(x for x in (out, err) if x)
        raise RuntimeError(details or f"Command failed: {' '.join(cmd)}")


def _git_head() -> str:
    try:
        proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(_repo_root()), capture_output=True, text=True)
        if proc.returncode == 0:
            return proc.stdout.strip()
    except Exception:
        pass
    return "N/A"


def _write_readme(dst_dir: Path, *, arch: str, purpose: str, innovations: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S %Z")
    head = _git_head()
    content = []
    content.append(f"Sello de tiempo UTC: {ts}")
    content.append(f"Git HEAD: {head}")
    content.append("")
    content.append("Arquitectura")
    content.append(arch)
    content.append("")
    content.append("Propósito")
    content.append(purpose)
    content.append("")
    content.append("Innovaciones")
    content.append(innovations)
    (dst_dir / "README_TECNICO.md").write_text("\n".join(content) + "\n", encoding="utf-8")


def _walk_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*"):
        if p.is_file():
            yield p


def _write_file_tree(dst_dir: Path) -> None:
    lines = []
    base = dst_dir.resolve()
    for p in sorted(_walk_files(base)):
        rel = p.relative_to(base)
        lines.append(str(rel).replace("\\", "/"))
    (dst_dir / "FILE_TREE.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_hashes(dst_dir: Path) -> None:
    base = dst_dir.resolve()
    lines = []
    for p in sorted(_walk_files(base)):
        if p.name == "HASHES.txt":
            continue
        digest = _sha256_file(p)
        rel = p.relative_to(base)
        lines.append(f"{digest}  {str(rel).replace('\\', '/')}")
    (dst_dir / "HASHES.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _copy_matches(globs: list[str], src_root: Path, dst_root: Path) -> int:
    count = 0
    for pattern in globs:
        for p in src_root.glob(pattern):
            if p.is_dir():
                for f in p.rglob("*"):
                    if f.is_file():
                        rel = f.relative_to(src_root)
                        dest = dst_root / rel
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(str(f), str(dest))
                        count += 1
            elif p.is_file():
                rel = p.relative_to(src_root)
                dest = dst_root / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(p), str(dest))
                count += 1
    return count


def _scan_secrets(root: Path, allow: bool) -> None:
    kws = ["API_KEY", "PASSWORD", "SECRET_KEY", "TOKEN", "PRIVATE_KEY"]
    hits = []
    for p in _walk_files(root):
        try:
            if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".ico"}:
                continue
            txt = p.read_text(encoding="utf-8", errors="ignore")
            low = txt.upper()
            for k in kws:
                if k in low:
                    hits.append(str(p))
                    break
        except Exception:
            continue
    if hits and not allow:
        shutil.rmtree(root, ignore_errors=True)
        raise SystemExit("Se detectaron posibles secretos en archivos. Revisa y vuelve a ejecutar o usa --allow-secrets.")


def _extract_rls_policies(schema_file: Path, dst_file: Path) -> None:
    lines = []
    try:
        for line in schema_file.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if "ROW LEVEL SECURITY" in s or "CREATE POLICY" in s or "ALTER POLICY" in s:
                lines.append(line)
    except Exception:
        pass
    dst_file.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def _dump_schema(database_url: str, dst_db_dir: Path, *, pg_dump: str, schema_only: bool = True, audit_table: str | None = "db_auditor_test") -> None:
    dst_db_dir.mkdir(parents=True, exist_ok=True)
    src_url = _as_libpq_url(database_url)
    safe_src = _safe_url(database_url)
    schema_full = dst_db_dir / "schema_full.sql"
    auditoria = dst_db_dir / "auditoria.sql"
    rls_file = dst_db_dir / "rls_policies.sql"
    dump_cmd = [pg_dump, "--no-owner", "--no-privileges", "--schema-only" if schema_only else "--data-only", f"--file={str(schema_full)}", src_url]
    _run(dump_cmd)
    _extract_rls_policies(schema_full, rls_file)
    if audit_table:
        audit_cmd = [pg_dump, "--no-owner", "--no-privileges", "--schema-only", f"--table={audit_table}", f"--file={str(auditoria)}", src_url]
        try:
            _run(audit_cmd)
        except RuntimeError as e:
            msg = str(e)
            if "no matching tables were found" in msg.lower():
                auditoria.write_text("", encoding="utf-8")
                print(f"Aviso: tabla de auditoría '{audit_table}' no encontrada; se continúa sin auditoria.sql")
            else:
                raise
    print(f"DDL exportado desde {safe_src}")


def _build_defaults() -> tuple[list[str], list[str]]:
    b = [
        "app/core/database/**/*",
        "app/core/database/*",
        "app/core/tenancy.py",
        "app/core/tenant_handler.py",
        "app/core_modules/contabilidad/**/*",
        "app/core_modules/facturacion/**/*",
        "app/core_modules/ventas/**/*",
        "app/**/sii/**/*",
        "app/**/integrations/**/*",
    ]
    f = [
        "frontend/src/components/**/*",
        "frontend/src/store/**/*",
    ]
    return b, f


def main() -> int:
    parser = argparse.ArgumentParser(prog="pack_core_ddi", description="Empaqueta CORE-DDI sin dependencias ni datos.")
    parser.add_argument("--output-dir", required=True, help="Carpeta externa destino de CORE-DDI")
    parser.add_argument("--source-db-url", default=None, help="URL origen para DDL; si se omite, se lee de backend/.env")
    parser.add_argument("--pg-dump", default=None, help="Ruta a pg_dump.exe")
    parser.add_argument("--pg-bin", default=os.getenv("POSTGRES_BIN", None), help="Directorio bin de PostgreSQL")
    parser.add_argument("--include-backend", default=None, help="Globs backend separados por coma")
    parser.add_argument("--include-frontend", default=None, help="Globs frontend separados por coma")
    parser.add_argument("--audit-table", default="db_auditor_test", help="Nombre de la tabla de auditoría a extraer (opcional)")
    parser.add_argument("--allow-secrets", action="store_true", help="No abortar si se detectan posibles secretos")
    parser.add_argument("--self-destruct", action="store_true", help="Borrar este script 2s después de terminar")
    args = parser.parse_args()
    out_dir = Path(args.output_dir).resolve()
    if out_dir.exists():
        shutil.rmtree(out_dir, ignore_errors=True)
    (out_dir / "database").mkdir(parents=True, exist_ok=True)
    (out_dir / "backend_core").mkdir(parents=True, exist_ok=True)
    (out_dir / "frontend_logic").mkdir(parents=True, exist_ok=True)
    db_url = args.source_db_url or _read_env_database_url() or ""
    if not db_url:
        raise SystemExit("No se encontró DATABASE_URL. Usa --source-db-url o configura backend/.env")
    pg_dump = _resolve_tool_path("pg_dump", explicit=args.pg_dump, pg_bin=args.pg_bin)
    b_globs, f_globs = _build_defaults()
    if args.include_backend:
        b_globs = [s.strip() for s in args.include_backend.split(",") if s.strip()]
    if args.include_frontend:
        f_globs = [s.strip() for s in args.include_frontend.split(",") if s.strip()]
    _dump_schema(db_url, out_dir / "database", pg_dump=pg_dump, audit_table=args.audit_table)
    src_root = _backend_root()
    copied_b = _copy_matches(b_globs, src_root, out_dir / "backend_core")
    copied_f = _copy_matches(f_globs, _repo_root(), out_dir / "frontend_logic")
    _scan_secrets(out_dir, args.allow_secrets)
    _write_readme(out_dir, arch="FastAPI + PostgreSQL + Vue/React", purpose="ERP modular para mercado chileno", innovations="Auditoría inmutable y multi-tenant nativo con RLS")
    _write_file_tree(out_dir)
    _write_hashes(out_dir)
    print(f"OK CORE-DDI en {str(out_dir)}")
    print(f"Copiados backend_core: {copied_b}, frontend_logic: {copied_f}")
    if args.self_destruct:
        me = Path(__file__).resolve()
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["powershell", "-Command", f"Start-Sleep -Seconds 2; Remove-Item -Force \"{str(me)}\""], creationflags=0x08000000)
            else:
                subprocess.Popen(["bash", "-lc", f"sleep 2 && rm -f \"{str(me)}\""])
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
