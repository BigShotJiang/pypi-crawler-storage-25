from pydantic import BaseModel, ConfigDict, field_validator
from typing import Optional, Any
from decimal import Decimal
import math

class ProductoBase(BaseModel):
    precio: Optional[float] = None
    costo_promedio: Optional[float] = None

    model_config = ConfigDict(from_attributes=True, extra="forbid")

    @field_validator("precio", "costo_promedio", mode="before")
    @classmethod
    def round_decimals(cls, v: Any) -> Any:
        print(f"Validating: {v!r} type={type(v)}")
        if v is None:
            return 0.0
        if isinstance(v, str):
            try:
                v = float(v)
            except:
                return 0.0
        if isinstance(v, Decimal):
             v = float(v)
        
        if isinstance(v, float) and math.isnan(v):
            return 0.0

        return round(v, 2)

class ProductoCreate(ProductoBase):
    precio: Optional[float] = 0.0

class ProductoUpdate(ProductoBase):
    pass

# Test Cases
print("--- ProductoCreate Tests ---")
try:
    p1 = ProductoCreate(precio=None)
    print(f"None -> {p1.precio}")
except Exception as e:
    print(f"None Error: {e}")

try:
    p2 = ProductoCreate(precio="NaN")
    print(f"'NaN' -> {p2.precio}")
except Exception as e:
    print(f"'NaN' Error: {e}")

try:
    p3 = ProductoCreate(precio="invalid")
    print(f"'invalid' -> {p3.precio}")
except Exception as e:
    print(f"'invalid' Error: {e}")

try:
    p4 = ProductoCreate(precio=123.456)
    print(f"123.456 -> {p4.precio}")
except Exception as e:
    print(f"Float Error: {e}")

print("\n--- ProductoUpdate Tests ---")
try:
    u1 = ProductoUpdate(precio=None, costo_promedio=float("nan"))
    print(f"None/NaN -> precio={u1.precio}, costo={u1.costo_promedio}")
except Exception as e:
    print(f"Update Error: {e}")
