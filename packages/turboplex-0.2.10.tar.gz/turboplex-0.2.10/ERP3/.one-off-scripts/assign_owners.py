import os
import sys
import time
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url

def main():
    admin_url_env = os.getenv("ADMIN_DATABASE_URL")
    test_url_env = os.getenv("TEST_DATABASE_URL")
    if not admin_url_env or not test_url_env:
        print("ERROR: ADMIN_DATABASE_URL y TEST_DATABASE_URL son requeridas")
        return 2
    try:
        test_url = make_url(test_url_env)
        target_db = test_url.database
        new_owner = test_url.username
        admin_url = make_url(admin_url_env).set(database=target_db)
    except Exception as e:
        print(f"ERROR: No se pudo parsear URLs: {e}")
        return 2
    engine = create_engine(str(admin_url), future=True, pool_pre_ping=True)
    tables = ["settings", "empresas", "clientes", "usuarios_empresas"]
    try:
        with engine.begin() as conn:
            owners = conn.execute(text("""
                SELECT table_name, tableowner
                FROM pg_tables
                WHERE schemaname = 'public' AND table_name = ANY(:tabs)
            """), {"tabs": tables}).mappings().all()
            for t in tables:
                try:
                    conn.execute(text(f'ALTER TABLE IF EXISTS public."{t}" OWNER TO {new_owner}'))
                    print(f"[OK] OWNER {t} -> {new_owner}")
                except Exception as e:
                    print(f"[WARN] No se pudo cambiar OWNER de {t}: {e}")
            old_owners = {row["tableowner"] for row in owners if row["tableowner"] and row["tableowner"] != new_owner}
            for old in old_owners:
                try:
                    conn.execute(text(f'REASSIGN OWNED BY {old} TO {new_owner}'))
                    print(f"[OK] REASSIGN OWNED BY {old} TO {new_owner}")
                except Exception as e:
                    print(f"[WARN] REASSIGN OWNED BY {old} falló: {e}")
    except Exception as e:
        print(f"ERROR: Fallo durante reasignación: {e}")
        return 1
    return 0

if __name__ == "__main__":
    rc = main()
    script_path = os.path.abspath(__file__)
    time.sleep(2)
    try:
        os.remove(script_path)
    except Exception:
        try:
            pending = os.path.join(os.path.dirname(script_path), "pending-cleanup.txt")
            with open(pending, "a", encoding="utf-8") as f:
                f.write(script_path + "\n")
        except Exception:
            pass
    sys.exit(rc)
