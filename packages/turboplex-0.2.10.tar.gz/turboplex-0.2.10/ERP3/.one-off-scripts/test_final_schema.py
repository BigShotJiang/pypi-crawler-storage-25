from typing import Any
from uuid import uuid4
from pydantic import BaseModel, ConfigDict, field_validator
from decimal import Decimal
import math

# Mocking the updated schema structure from catalogo/schemas.py
class ProductoBase(BaseModel):
    precio: float | None = None
    costo_promedio: float | None = None
    
    model_config = ConfigDict(from_attributes=True)

    @field_validator("precio", "costo_promedio", mode="before")
    @classmethod
    def round_decimals(cls, v: Any) -> Any:
        try:
            if v is None:
                return 0.0
            if isinstance(v, str):
                try:
                    v = float(v)
                except:
                    return 0.0
            if isinstance(v, Decimal):
                 v = float(v)
            
            # Check for NaN
            if isinstance(v, float) and math.isnan(v):
                return 0.0

            return round(float(v), 2)
        except Exception:
            return 0.0

class ProductoRead(ProductoBase):
    id: str
    precio: float = 0.0
    costo_promedio: float = 0.0
    empresa_id: str

print("--- Test Output Schema ---")
try:
    # Simulate DB object with None values
    class DBObj:
        id = str(uuid4())
        precio = None
        costo_promedio = float("nan")
        empresa_id = str(uuid4())
    
    db_obj = DBObj()
    p = ProductoRead.model_validate(db_obj)
    print(f"Result from None/NaN: precio={p.precio} ({type(p.precio)}), costo={p.costo_promedio} ({type(p.costo_promedio)})")
    
except Exception as e:
    print(f"Error: {e}")
