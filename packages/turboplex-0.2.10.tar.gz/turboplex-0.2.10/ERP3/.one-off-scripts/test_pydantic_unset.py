from pydantic import BaseModel, ConfigDict
from typing import Optional

class M(BaseModel):
    x: float = 0.0
    y: Optional[str] = None
    model_config = ConfigDict(extra="ignore")

# Case 1: Default
m1 = M()
print(f"Default: {m1.model_dump(exclude_unset=True)}")

# Case 2: Explicit default value
m2 = M(x=0.0)
print(f"Explicit 0.0: {m2.model_dump(exclude_unset=True)}")

# Case 3: Explicit None (for Optional)
m3 = M(y=None)
print(f"Explicit None: {m3.model_dump(exclude_unset=True)}")

# Case 4: Extra field
try:
    m4 = M(extra_field="ignored")
    print(f"Extra field: {m4.model_dump(exclude_unset=True)}")
except Exception as e:
    print(f"Extra field error: {e}")
