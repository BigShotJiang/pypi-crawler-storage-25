import sys
import os
import requests
import json  # noqa: F401
import hashlib
from sqlalchemy import create_engine, text  # noqa: F401
from sqlalchemy.orm import sessionmaker  # noqa: F401
from dotenv import load_dotenv

backend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
load_dotenv(os.path.join(backend_path, ".env"))

sys.path.append(backend_path)

from app.core.database import SessionLocal
from app.core_modules.crm.models import (
    OportunidadVenta,
    EstadoOportunidad,
    EstadoCredito,
    DetalleOportunidad,
    Embudo,
    Etapa,
)
from app.core_modules.sistema.models import Empresa, Usuario, Bodega, Sucursal
from app.core_modules.ventas.models import Producto, Cliente
import app.core_modules.finanzas.models  # noqa: F401
import app.core_modules.compras.models  # noqa: F401
import app.core_modules.rrhh.models  # noqa: F401
from app.core_modules.legal.models import DocumentoLegal

API_URL = "http://localhost:8000/api/v1"
CRM_URL = f"{API_URL}/crm"
STORAGE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "backend", "storage_files"
)


def setup_test_data(db):
    print("[SETUP] Creating test data...")

    empresa = db.query(Empresa).first()
    if not empresa:
        empresa = Empresa(nombre="Test Corp", rut="99.999.999-9")
        db.add(empresa)
        db.commit()

    usuario = db.query(Usuario).first()
    if not usuario:
        usuario = Usuario(
            email="test@test.com", password_hash="hash", empresa_id=empresa.id, rol="admin"
        )
        db.add(usuario)
        db.commit()

    cliente = db.query(Cliente).filter_by(rut="11.111.111-1").first()
    if not cliente:
        cliente = Cliente(nombre="Cliente Test", rut="11.111.111-1", empresa_id=empresa.id)
        db.add(cliente)
        db.commit()

    producto = db.query(Producto).first()
    if not producto:
        producto = Producto(
            nombre="Producto Test",
            sku="TEST-001",
            precio=1000,
            empresa_id=empresa.id,
        )
        db.add(producto)
        db.commit()

    sucursal = db.query(Sucursal).first()
    if not sucursal:
        sucursal = Sucursal(
            nombre="Sucursal Test", codigo="SUC-TEST", empresa_id=empresa.id
        )
        db.add(sucursal)
        db.commit()

    bodega = db.query(Bodega).first()
    if not bodega:
        bodega = Bodega(nombre="Bodega Central", sucursal_id=sucursal.id)
        db.add(bodega)
        db.commit()

    embudo = db.query(Embudo).first()
    if not embudo:
        embudo = Embudo(nombre="Ventas General", empresa_id=empresa.id)
        db.add(embudo)
        db.commit()

    etapa = db.query(Etapa).first()
    if not etapa:
        etapa = Etapa(
            nombre="Prospecto",
            orden=1,
            probabilidad_exito=10,
            embudo_id=embudo.id,
        )
        db.add(etapa)
        db.commit()

    opp = OportunidadVenta(
        titulo="Oportunidad Integrity Check",
        monto_estimado=10000,
        moneda="CLP",
        cliente_id=cliente.id,
        usuario_id=usuario.id,
        empresa_id=empresa.id,
        etapa_id=etapa.id,
        estado=EstadoOportunidad.ABIERTA,
        estado_credito=EstadoCredito.PENDIENTE,
        bodega_id=None,
    )
    db.add(opp)
    db.commit()
    db.refresh(opp)

    detalle = DetalleOportunidad(
        oportunidad_id=opp.id,
        producto_id=producto.id,
        cantidad=10,
        precio_unitario=1000,
        subtotal=10000,
    )
    db.add(detalle)
    db.commit()

    print(f"[SETUP] Created Opportunity ID: {opp.id}")
    return opp.id, bodega.id


def run_integrity_check():
    db = SessionLocal()
    try:
        opp_id, bodega_id = setup_test_data(db)

        print("\n[TEST 1] Testing Prepare Signature WITHOUT Approval/Stock...")
        url = f"{CRM_URL}/opportunities/{opp_id}/prepare-signature"
        res = requests.post(url)

        if res.status_code == 400:
            print(f"SUCCESS: Rejected as expected. Status: {res.status_code}")
        else:
            print(f"FAILURE: Expected 400, got {res.status_code}")
            print(res.text)
            return

        print("\n[SETUP] Simulating Credit Approval and Stock Reservation...")
        opp = db.query(OportunidadVenta).get(opp_id)
        opp.estado_credito = EstadoCredito.APROBADO
        opp.bodega_id = bodega_id
        db.commit()

        print("\n[TEST 2] Testing Prepare Signature WITH Approval...")
        res = requests.post(url)

        if res.status_code == 200:
            data = res.json()
            doc_id = data["documento_id"]
            presigned_url = data["presigned_url"]
            print(f"SUCCESS: Signature Prepared. Doc ID: {doc_id}")
            print(f"Presigned URL: {presigned_url}")
        else:
            print(f"FAILURE: Expected 200, got {res.status_code}")
            print(res.text)
            return

        print("\n[TEST 3] Verifying File Integrity and Hash...")

        doc_record = (
            db.query(DocumentoLegal).filter(DocumentoLegal.id == doc_id).first()
        )
        if not doc_record:
            print("FAILURE: Document record not found in DB.")
            return

        db_hash = doc_record.hash_integridad
        file_path = doc_record.ruta_archivo

        print(f"DB Hash: {db_hash}")
        print(f"File Path: {file_path}")

        full_path = os.path.join(STORAGE_ROOT, file_path)
        if not os.path.exists(full_path):
            backend_root = os.path.abspath(
                os.path.join(os.path.dirname(__file__), "..", "backend")
            )
            full_path = os.path.join(backend_root, "storage_files", file_path)

        if not os.path.exists(full_path):
            print(f"FAILURE: File not found at {full_path}")
            return

        with open(full_path, "rb") as f:
            content = f.read()
            file_hash = hashlib.sha256(content).hexdigest()

        print(f"File Hash: {file_hash}")

        if db_hash == file_hash:
            print("\n" + "=" * 40)
            print("CONEXIÓN LEGAL ASEGURADA - HASH VÁLIDO")
            print("=" * 40)
        else:
            print("\nFAILURE: Hash mismatch!")
            print(f"Expected: {db_hash}")
            print(f"Actual:   {file_hash}")
    except Exception as e:
        print(f"ERROR: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    run_integrity_check()

