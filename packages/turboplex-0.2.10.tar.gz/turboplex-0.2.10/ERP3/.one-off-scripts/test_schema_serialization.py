from pydantic import BaseModel, Field, field_validator, ConfigDict
from decimal import Decimal
from typing import Optional, Any
import json

class TestSchema(BaseModel):
    precio: Optional[Decimal] = None
    
    model_config = ConfigDict(from_attributes=True)

    @field_validator("precio", mode="before")
    @classmethod
    def round_decimals(cls, v: Any) -> Any:
        if v is None:
            return Decimal("0.00")
        if isinstance(v, str):
            try:
                v = Decimal(v)
            except:
                return Decimal("0.00")
        if isinstance(v, (int, float)):
             v = Decimal(str(v))
        return round(v, 2)

try:
    data = TestSchema(precio="123.456")
    print(f"Value: {data.precio} Type: {type(data.precio)}")
    print(f"JSON: {data.model_dump_json()}")
    
    data_none = TestSchema(precio=None)
    print(f"None Value: {data_none.precio} Type: {type(data_none.precio)}")
    print(f"None JSON: {data_none.model_dump_json()}")
except Exception as e:
    print(f"Error: {e}")
