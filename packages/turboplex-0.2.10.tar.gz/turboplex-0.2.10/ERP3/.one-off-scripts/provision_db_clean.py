import os
import subprocess
from pathlib import Path
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url

def find_backend_dir() -> Path:
    here = Path(__file__).resolve().parent
    root = here.parent
    backend = root / "backend"
    if not backend.exists():
        raise RuntimeError(f"No se encontró el directorio backend en: {backend}")
    return backend

def load_env_database_url(backend_dir: Path) -> str:
    env_path = backend_dir / ".env"
    if not env_path.exists():
        raise RuntimeError(f"No se encontró backend/.env en {env_path}")
    for line in env_path.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("DATABASE_URL="):
            return line.split("=", 1)[1].strip()
    raise RuntimeError("DATABASE_URL no encontrado en backend/.env")

def ensure_database_exists(admin_url: str, db_name: str):
    admin_engine = create_engine(admin_url, pool_pre_ping=True)
    with admin_engine.begin() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM pg_database WHERE datname = :n"),
            {"n": db_name},
        ).scalar() is not None
        if not exists:
            conn.execute(text(f'CREATE DATABASE \"{db_name}\"'))

def run_alembic_upgrade(backend_dir: Path, target_url: str):
    env = os.environ.copy()
    env["DATABASE_URL"] = target_url
    py = backend_dir / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        py = "python"
    subprocess.check_call(
        [str(py), "-m", "alembic", "upgrade", "head"],
        cwd=str(backend_dir),
        env=env,
    )

def run_seed_minimo(backend_dir: Path, target_url: str):
    env = os.environ.copy()
    env["DATABASE_URL"] = target_url
    code = r"""
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.core_modules.sistema.models import Empresa, Rol
db: Session = SessionLocal()
try:
    empresa = db.query(Empresa).filter(Empresa.codigo == "BOOTSTRAP_CO").first()
    if not empresa:
        empresa = Empresa(nombre="Bootstrap Company", codigo="BOOTSTRAP_CO")
        db.add(empresa); db.commit(); db.refresh(empresa)
    def ensure_role(codigo, nombre):
        r = db.query(Rol).filter(Rol.empresa_id == empresa.id, Rol.codigo == codigo).first()
        if not r:
            r = Rol(empresa_id=empresa.id, codigo=codigo, nombre=nombre)
            db.add(r); db.commit()
    for c,n in [("ADM","Administrador"),("SUP","Supervisor"),("VEN","Vendedor"),("BOD","Bodega"),("CON","Contador")]:
        ensure_role(c,n)
    print("Seed mínimo aplicado con éxito.")
finally:
    db.close()
"""
    py = backend_dir / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        py = "python"
    subprocess.check_call([str(py), "-c", code], cwd=str(backend_dir), env=env)

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Provisionar DB limpia para despliegue")
    parser.add_argument("--db-name", default="erp3_clean", help="Nombre de la base a provisionar")
    parser.add_argument("--seed", action="store_true", help="Aplicar seed mínimo idempotente")
    args = parser.parse_args()
    backend_dir = find_backend_dir()
    base_url = load_env_database_url(backend_dir)
    url = make_url(base_url)
    target_url = str(url.set(database=args.db_name))
    admin_url = str(url.set(database="postgres"))
    print(f"Provisionando DB limpia: {args.db_name}")
    ensure_database_exists(admin_url, args.db_name)
    print("Ejecutando migraciones (alembic upgrade head)...")
    run_alembic_upgrade(backend_dir, target_url)
    if args.seed:
        print("Aplicando seed mínimo...")
        run_seed_minimo(backend_dir, target_url)
    print("Provisionamiento completado.")

if __name__ == "__main__":
    main()
