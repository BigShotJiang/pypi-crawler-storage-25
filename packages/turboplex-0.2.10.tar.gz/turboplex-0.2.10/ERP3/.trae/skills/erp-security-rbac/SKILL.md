---
name: "erp-security-rbac"
description: "Enforces ERP RBAC with ADM/SUP credit roles and operational BACKOFFICE/AUD. Invoke for security, roles, or credit changes."
---

# ERP Security RBAC

This skill enforces the standardized RBAC model for the ERP.

Use this skill whenever you:
- Add or modify roles or `Rol` records.
- Change logic related to `UsuarioEmpresa` (user–company links).
- Implement or update sensitive operations such as credit limit changes, destructive actions, or cross-user authorization flows.

## 1. Standard Role Set

The canonical roles for the ERP are:
- `ADM`: Single-company administrator with full authority.
- `SUP`: Supervisor with operational and credit authorization powers.
- `VEN`: Sales operator (no credit authorization).
- `BOD`: Warehouse operator (no credit authorization).
- `CON`: Accountant role (accounting operations, no credit authorization by default).
- `BACKOFFICE`: Operational backoffice role for internal processes, **no credit authorization**.
- `AUD`: Auditor role, focused on read/review capabilities, **no credit authorization**.

### 1.1 Role Categories

- **Credit-Authorized Roles**:
  - `ADM`, `SUP`
  - Only these roles may approve or execute operations that change customer credit limits (for example `aumentar_cupo_temporal`) or similar high-risk financial operations.

- **Operative/Read-Only Roles (no credit authority)**:
  - `VEN`, `BOD`, `CON`, `BACKOFFICE`, `AUD`
  - These roles may create or operate on day-to-day business objects according to their domain (sales, warehouse, accounting, backoffice flows), but **must never** be treated as having credit authorization powers.

Any new feature that introduces additional roles MUST clearly state whether they belong to the “Credit-Authorized” or “Operative/Read-Only” categories and adjust tests accordingly.

## 2. UsuarioEmpresa Invariants

- Every `UsuarioEmpresa` link MUST have:
  - `usuario_id` (UUID) referencing `Usuario`.
  - `empresa_id` (UUID) referencing `Empresa`.
  - `rol_id` (UUID) referencing `Rol`, **never null** in new logic and fixtures.
- When creating or updating `UsuarioEmpresa` entries:
  - Always resolve a valid `Rol` for the given company (per-empresa roles).
  - Ensure there is at most one `is_default=True` link per user per company, if this convention is used.

## 3. Rules for Sensitive Operations

Sensitive operations include, but are not limited to:
- Credit limit increases (`aumentar_cupo_temporal`).
- Mass cancellation of sales or financial documents.
- Operations that significantly affect financial risk or customer exposure.

For these operations, the skill enforces:
- The acting user must:
  - Be linked to the same `Empresa` as the target entity (e.g. client, sale).
  - Have a `UsuarioEmpresa.rol_id` whose `Rol.codigo` is either `ADM` or `SUP`.
- Users with roles `VEN`, `BOD`, `CON`, `BACKOFFICE` or `AUD` must NOT be allowed to:
  - Increase credit limits.
  - Authorize extraordinary risk operations.

When implementing or modifying such functions:
- Always query `UsuarioEmpresa` to ensure the user belongs to the target company.
- Always resolve `Rol` and verify `codigo in ("ADM", "SUP")` for credit-sensitive paths.
- Raise a business error (e.g. `BusinessRuleError`) or return HTTP 403 when the role is not authorized.

## 4. Testing Guidelines

When this skill is active, tests should:
- Seed all standard roles for each company:
  - `ADM`, `SUP`, `VEN`, `BOD`, `CON`, `BACKOFFICE`, `AUD`.
- Explicitly test:
  - Successful credit operations by `SUP`/`ADM`.
  - Rejected credit operations by `VEN`, `BOD`, `CON`, `BACKOFFICE`, `AUD`.
- Include cross-tenant scenarios where a `SUP` or `ADM` attempts to act on entities from another company and ensure the operation fails with the appropriate error.

