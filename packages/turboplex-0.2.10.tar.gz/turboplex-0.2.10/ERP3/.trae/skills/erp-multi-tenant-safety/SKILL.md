---
name: "erp-multi-tenant-safety"
description: "Enforces multi-tenant isolation and UUID-safe JSON. Invoke for data access, queries, or tenant-sensitive endpoints."
---

# ERP Multi-Tenant Safety

This skill enforces the multi-tenant isolation rules and safe UUID handling for the ERP.

Use this skill whenever you:
- Implement new endpoints that read or write tenant-specific data.
- Modify services or repositories that access shared tables.
- Work on logging, audit, or JSON serialization that involves UUID fields.

## 1. Multi-Tenant Isolation Rules

Core principles:
- No cross-tenant data access is allowed.
- All business operations must be scoped by `empresa_id`.
- Any attempt to access data from another tenant should result in:
  - Business error (e.g. `BusinessRuleError`) or
  - HTTP 404/403 as appropriate, without leaking the existence of foreign tenant data.

### 1.1 Query Scoping

When writing database queries in multi-tenant contexts:
- Always include `empresa_id` in filters for tenant-scoped entities such as:
  - `Cliente`, `Venta`, `OrdenServicio`, `AsientoContable`, and similar.
- Avoid global queries like:
  - `db.query(Model).all()` without tenant filters in multi-tenant modules.
- Ensure repositories and services accept `empresa_id` and propagate it down to the query layer.

Where global catalogs exist (e.g. shared configuration tables), document clearly why they are safe to read without `empresa_id`.

## 2. Session and Context Handling

- HTTP-level dependencies (e.g. `get_current_active_company`) must:
  - Resolve the active `Empresa` for the session.
  - Provide `empresa_id` to all underlying services.
- Services MUST NOT:
  - Infer company from unrelated data when `empresa_id` is already known.
  - Mix data across tenants in aggregates, reports, or dashboards.

If a temporary bypass exists (e.g. `allow_no_tenant` for setup or tests), it must be:
- Strictly limited to setup/bootstrap flows.
- Never used in normal business endpoints.

## 3. UUID Serialization and Logging

To ensure safe handling of UUIDs in logs and JSON responses:
- Always use the project’s standard JSON encoder:
  - For responses: FastAPI’s `jsonable_encoder` or equivalent helpers.
  - For logs/AuditLog: `CustomJSONEncoder` or a centralized serializer that knows how to handle UUID objects.
- Never rely on ad-hoc `str(uuid_obj)` without going through the agreed encoder for structures stored as JSON.

When adding or modifying logging:
- Ensure that UUIDs in `resource`, `changes`, or similar JSON fields are encoded via the shared encoder.
- Avoid logging raw cross-tenant identifiers in error messages that could leak sensitive information.

## 4. Testing Guidelines

When this skill is active, tests should:
- Create data for multiple companies and verify:
  - Users from company A cannot read or modify records of company B.
- For each new endpoint or service:
  - Add tests that confirm `empresa_id` is enforced in queries.
  - Add cross-tenant attempts that must fail without exposing foreign data.
- Include tests that:
  - Serialize responses and logs containing UUIDs.
  - Confirm that serialization uses the shared encoder and does not throw `TypeError` for UUID objects.

