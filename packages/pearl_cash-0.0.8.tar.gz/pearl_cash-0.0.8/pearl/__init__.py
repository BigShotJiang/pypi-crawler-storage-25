from __future__ import annotations

import json
import base64
from dataclasses import dataclass
from urllib.request import Request, urlopen
from urllib.error import HTTPError


DEFAULT_BASE_URL = "https://pearlcash.ai"
MICROCENTS_PER_DOLLAR = 100_000_000


@dataclass
class Charge:
    id: str
    user_id: str
    skill_id: str
    status: str
    amount: float
    currency: str
    description: str
    created_at: str


@dataclass
class ChargeResult:
    approved: bool
    charge: Charge
    status: int
    body: dict


class PearlError(Exception):
    def __init__(self, message: str, status: int):
        super().__init__(message)
        self.status = status


def _decode_jwt_subject(token: str) -> str | None:
    bearer = token.removeprefix("Bearer ")
    parts = bearer.split(".")
    if len(parts) != 3:
        return None
    padding = "=" * (4 - len(parts[1]) % 4)
    payload = json.loads(base64.urlsafe_b64decode(parts[1] + padding))
    return payload.get("sub")


class _Charges:
    def __init__(self, pearl: Pearl):
        self._pearl = pearl

    def create(
        self,
        *,
        user_id: str,
        amount: float,
        description: str,
        callback_url: str | None = None,
    ) -> Charge:
        body: dict = {
            "user_id": user_id,
            "amount": round(amount * MICROCENTS_PER_DOLLAR),
            "currency": "usd_microcents",
            "description": description,
        }
        if callback_url:
            body["callback_url"] = callback_url
        return self._pearl._request("POST", "/api/charges", body)

    def get(self, charge_id: str) -> Charge:
        return self._pearl._request("GET", f"/api/charges/{charge_id}")


class Pearl:
    def __init__(self, secret_key: str, *, base_url: str | None = None):
        self.secret_key = secret_key
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.charges = _Charges(self)

    def charge(
        self,
        *,
        amount: float,
        description: str,
        token: str | None = None,
        user_id: str | None = None,
        charge_id: str | None = None,
        callback_url: str | None = None,
    ) -> ChargeResult:
        uid = user_id or (token and _decode_jwt_subject(token))
        if not uid:
            raise PearlError("user_id or valid token required", 401)

        if charge_id:
            ch = self.charges.get(charge_id)
        else:
            ch = self.charges.create(
                user_id=uid,
                amount=amount,
                description=description,
                callback_url=callback_url,
            )

        if ch.status == "approved":
            return ChargeResult(approved=True, charge=ch, status=200, body={})

        if ch.status == "pending":
            return ChargeResult(
                approved=False,
                charge=ch,
                status=202,
                body={"message": "Awaiting user approval", "charge_id": ch.id},
            )

        return ChargeResult(
            approved=False,
            charge=ch,
            status=402,
            body={"error": "charge was rejected"},
        )

    def _request(self, method: str, path: str, body: dict | None = None) -> Charge:
        url = f"{self.base_url}{path}"
        data = json.dumps(body).encode() if body else None
        req = Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("X-Pearl-Secret", self.secret_key)

        try:
            with urlopen(req) as resp:
                result = json.loads(resp.read())
        except HTTPError as e:
            result = json.loads(e.read())
            raise PearlError(result.get("error", "Request failed"), e.code)

        d = result["data"]
        return Charge(
            id=d["id"],
            user_id=d["user_id"],
            skill_id=d["skill_id"],
            status=d["status"],
            amount=d["amount"] / MICROCENTS_PER_DOLLAR,
            currency=d["currency"],
            description=d["description"],
            created_at=d["created_at"],
        )
