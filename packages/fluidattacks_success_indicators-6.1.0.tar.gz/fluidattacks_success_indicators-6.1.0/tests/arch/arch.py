from arch_lint.dag import (
    DagMap,
)
from arch_lint.graph import (
    FullPathModule,
)
from fa_purity import (
    FrozenList,
)
from fluidattacks_etl_utils.typing import (
    TypeVar,
)

_T = TypeVar("_T")
_dag: dict[str, FrozenList[FrozenList[str] | str]] = {
    "fluidattacks_success_indicators": (
        "_cli",
        "_factory",
        "_core",
        "_db_client",
        "_logger",
    ),
    "fluidattacks_success_indicators._db_client": (
        "_client_1",
        "_core",
    ),
}


def raise_if_exception(item: _T | Exception) -> _T:
    if isinstance(item, Exception):
        raise item
    return item


def project_dag() -> DagMap:
    return raise_if_exception(DagMap.new(_dag))


def forbidden_allowlist() -> dict[FullPathModule, frozenset[FullPathModule]]:
    _raw: dict[str, frozenset[str]] = {}
    return {
        FullPathModule.assert_module(k): frozenset(FullPathModule.assert_module(i) for i in v)
        for k, v in _raw.items()
    }
