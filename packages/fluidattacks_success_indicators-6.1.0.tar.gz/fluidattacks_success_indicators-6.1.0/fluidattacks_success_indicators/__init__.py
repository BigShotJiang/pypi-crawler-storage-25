from fa_purity import (
    Unsafe,
)

from ._core import ChildJob, CompoundJob, IndicatorsClient, SingleJob
from ._db_client import JobName
from ._factory import ClientFactory
from ._logger import (
    set_logger,
)

__version__ = "6.1.0"

Unsafe.compute(set_logger(__name__, __version__))

__all__ = [
    "ChildJob",
    "ClientFactory",
    "CompoundJob",
    "IndicatorsClient",
    "JobName",
    "SingleJob",
]
