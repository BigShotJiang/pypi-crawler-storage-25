from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from fa_purity import (
    Cmd,
    ResultE,
    UnitType,
)

from ._db_client import (
    JobName,
)

if TYPE_CHECKING:
    from collections.abc import Callable

ChildJob = JobName


class SingleJob(Enum):
    audit_trail = "audit_trail"
    batch_etl = "batch_etl"
    ce_etl = "ce_etl"
    checkly_etl = "checkly_etl"
    cloudwatch_etl = "cloudwatch_etl"
    code_etl_compute_bills = "code_etl_compute_bills"
    delighted_etl = "delighted_etl"
    gitlab_dora_etl = "gitlab_dora_etl"
    quicksight_etl = "quicksight_etl"
    timedoctor_etl = "timedoctor_etl"
    timedoctor_backup = "timedoctor_backup"
    zoho_crm_etl = "zoho_crm_etl"
    zoho_crm_prepare = "zoho_crm_prepare"

    @staticmethod
    def decode(raw: str) -> ResultE[SingleJob]:
        try:
            return ResultE[SingleJob].success(SingleJob(raw))
        except ValueError as err:
            return ResultE[SingleJob].failure(err)


class CompoundJob(Enum):
    code_upload = "code_upload"
    dynamo_etl = "dynamo_etl"
    gitlab_etl = "gitlab_etl"

    @staticmethod
    def decode(raw: str) -> ResultE[CompoundJob]:
        try:
            return ResultE[CompoundJob].success(CompoundJob(raw))
        except ValueError as err:
            return ResultE[CompoundJob].failure(err)


@dataclass(frozen=True)
class IndicatorsClient:
    update_single_job: Callable[[SingleJob], Cmd[UnitType]]
    update_compound_job: Callable[[CompoundJob, ChildJob], Cmd[UnitType]]
