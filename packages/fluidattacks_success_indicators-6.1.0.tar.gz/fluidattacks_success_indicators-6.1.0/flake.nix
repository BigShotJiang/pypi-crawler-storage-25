{
  description = "Fluidattacks ETLs success indicators";

  inputs = {
    observes_flake_builder = {
      url = "git+ssh://git@gitlab.com/fluidattacks/universe?shallow=1&rev=81d72f6cf95bc5430f654e518e10e94a555fac15&dir=observes/common/std_flake_2";
    };
  };

  outputs =
    { self, ... }@inputs:
    let
      build_args =
        {
          system,
          python_version,
          nixpkgs,
          builders,
          scripts,
        }:
        import ./build {
          inherit nixpkgs builders scripts;
          src = import ./build/filter.nix nixpkgs.nix-filter self;
        };
    in
    {
      packages = inputs.observes_flake_builder.outputs.build build_args;
    };
}
