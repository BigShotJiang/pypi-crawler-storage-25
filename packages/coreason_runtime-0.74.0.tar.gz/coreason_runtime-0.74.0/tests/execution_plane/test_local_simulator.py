# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from coreason_runtime.execution_plane.local_simulator import (
    LocalRuntimeSimulator,
    SimulationNode,
)


def test_verify_dag_integrity_valid() -> None:
    # A -> B
    dag = {
        "node_a": SimulationNode(node_id="node_a", node_type="task", dependencies=[]),
        "node_b": SimulationNode(node_id="node_b", node_type="task", dependencies=["node_a"]),
    }
    report = LocalRuntimeSimulator.verify_dag_integrity(dag)
    assert report["valid"] is True
    assert report["has_cycle"] is False
    assert len(report["dangling_references"]) == 0
    assert report["topological_order"] == ["node_a", "node_b"]


def test_verify_dag_integrity_cycle() -> None:
    # A -> B -> A
    dag = {
        "node_a": SimulationNode(node_id="node_a", node_type="task", dependencies=["node_b"]),
        "node_b": SimulationNode(node_id="node_b", node_type="task", dependencies=["node_a"]),
    }
    report = LocalRuntimeSimulator.verify_dag_integrity(dag)
    assert report["valid"] is False
    assert report["has_cycle"] is True


def test_verify_dag_integrity_dangling() -> None:
    dag = {"node_a": SimulationNode(node_id="node_a", node_type="task", dependencies=["nonexistent"])}
    report = LocalRuntimeSimulator.verify_dag_integrity(dag)
    assert report["valid"] is False
    assert len(report["dangling_references"]) == 1


def test_simulate_execution_success() -> None:
    dag = {
        "node_a": SimulationNode(node_id="node_a", node_type="task", dependencies=[]),
        "node_b": SimulationNode(node_id="node_b", node_type="task", dependencies=["node_a"]),
    }
    result = LocalRuntimeSimulator.simulate_execution(dag)
    assert result.success is True
    assert result.executed_nodes == ["node_a", "node_b"]
    assert result.failed_nodes == []
    assert dag["node_a"].status == "COMPLETED"
    assert dag["node_b"].status == "COMPLETED"


def test_simulate_execution_invalid_dag() -> None:
    # Cycle
    dag = {
        "node_a": SimulationNode(node_id="node_a", node_type="task", dependencies=["node_b"]),
        "node_b": SimulationNode(node_id="node_b", node_type="task", dependencies=["node_a"]),
    }
    result = LocalRuntimeSimulator.simulate_execution(dag)
    assert result.success is False
    assert len(result.failed_nodes) == 2


def test_stitch_fractal_urns() -> None:
    parent = "urn:coreason:mesh:node-a"
    children = ["urn:coreason:capability:storage", "urn:coreason:capability:compute"]
    bindings = LocalRuntimeSimulator.stitch_fractal_urns(parent, children)
    assert bindings["urn:coreason:capability:storage"] == "urn:coreason:mesh:node-a:storage"
    assert bindings["urn:coreason:capability:compute"] == "urn:coreason:mesh:node-a:compute"
