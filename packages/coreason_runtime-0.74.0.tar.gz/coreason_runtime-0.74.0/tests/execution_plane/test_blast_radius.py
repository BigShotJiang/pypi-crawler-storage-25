# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Unit tests for the BlastRadiusCalculator."""

from coreason_runtime.execution_plane.blast_radius import BlastRadiusCalculator


def test_calculate_blast_radius_empty_or_missing() -> None:
    """Verify blast radius calculation with empty or missing node inputs."""
    graph: dict[str, list[str]] = {}
    result = BlastRadiusCalculator.calculate_blast_radius("missing_node", graph)
    assert result.defeated_node == "missing_node"
    assert len(result.affected_nodes) == 0
    assert result.cascade_depth == 0
    assert result.total_affected == 0


def test_calculate_blast_radius_single_node() -> None:
    """Verify blast radius calculation for a single node with no dependents."""
    graph: dict[str, list[str]] = {"node_a": []}
    result = BlastRadiusCalculator.calculate_blast_radius("node_a", graph)
    assert result.defeated_node == "node_a"
    assert len(result.affected_nodes) == 0
    assert result.cascade_depth == 0


def test_calculate_blast_radius_cascade() -> None:
    """Verify blast radius cascade path and defeasibility scoring downstream."""
    graph: dict[str, list[str]] = {
        "node_a": ["node_b"],
        "node_b": ["node_c"],
        "node_c": [],
    }
    result = BlastRadiusCalculator.calculate_blast_radius("node_a", graph)
    assert result.defeated_node == "node_a"
    assert result.affected_nodes == ["node_b", "node_c"]
    assert result.cascade_depth == 2
    assert result.total_affected == 2
    assert result.defeasibility_scores["node_a"] == 1.0
    assert result.defeasibility_scores["node_b"] == 0.5
    assert result.defeasibility_scores["node_c"] == 0.3333333333333333


def test_compute_defeasibility_score() -> None:
    """Verify computation of defeasibility scores relative to ancestor counts."""
    graph: dict[str, list[str]] = {
        "node_a": ["node_b"],
        "node_b": ["node_c"],
        "node_c": [],
    }
    score_c = BlastRadiusCalculator.compute_defeasibility_score("node_c", graph)
    # node_c has ancestors node_b and node_a (count = 2)
    # total nodes in graph = 3
    # 2/3 = 0.6666...
    assert 0.66 < score_c < 0.67

    score_a = BlastRadiusCalculator.compute_defeasibility_score("node_a", graph)
    # node_a has 0 ancestors
    assert score_a == 0.0
