# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Real tests for ExtismRunner and JIT compilation caching — no mocks."""

import hashlib
import os
from pathlib import Path

import pytest
from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent

from coreason_runtime.execution_plane.capability_allocator import ExtismRunner


def test_extism_runner_validation_success() -> None:
    """Verifies that loading with the correct SHA-256 hash succeeds and returns a warm cached plugin."""
    wasm_bytes = b"\x00asm\x01\x00\x00\x00"
    expected_hash = hashlib.sha256(wasm_bytes).hexdigest()

    plugin_1 = ExtismRunner.get_plugin(wasm_bytes, expected_hash)
    plugin_2 = ExtismRunner.get_plugin(wasm_bytes, expected_hash)

    assert plugin_1 is plugin_2


def test_extism_runner_hash_mismatch_fails() -> None:
    """Verifies that an incorrect hash immediately throws a TopologicalSeveranceEvent."""
    wasm_bytes = b"\x00asm\x01\x00\x00\x00"
    wrong_hash = "a" * 64

    with pytest.raises(TopologicalSeveranceEvent, match="WASM binary hash mismatch"):
        ExtismRunner.get_plugin(wasm_bytes, wrong_hash)


def test_wasmtime_cache_configuration_is_active() -> None:
    """Verifies that if the WASMTIME_CACHE environment variable is set, it points to a valid, existing config file."""
    from coreason_runtime.execution_plane.capability_allocator import _initialize_wasmtime_cache

    _initialize_wasmtime_cache()
    cache_env = os.environ.get("WASMTIME_CACHE")
    if cache_env is not None:
        cache_path = Path(cache_env)
        assert cache_path.exists()
        assert "[cache]" in cache_path.read_text(encoding="utf-8")
