# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest
from coreason_manifest.spec.ontology import (
    OntologicalVocabularyLookupIntent,
    OntologicalVocabularyLookupReceipt,
)

from coreason_runtime.execution import LocalRuntimeSimulator


class StatefulNodeIntent:
    """A helper intent model to verify DAG topological sorting and cycle detection."""

    def __init__(self, event_cid: str, dependencies: list[str]):
        self.event_cid = event_cid
        self.dependencies = dependencies


def test_simulator_single_intent_fallback() -> None:
    """Verifies that a single intent can be evaluated using fallback mock receipts."""
    simulator = LocalRuntimeSimulator(db_path=None)
    intent = OntologicalVocabularyLookupIntent(
        query_term="SNOMED-XYZ",
        target_domains=["Condition"],
        max_results=5,
    )

    receipt = simulator.evaluate_intent(intent)
    assert isinstance(receipt, OntologicalVocabularyLookupReceipt)
    assert len(receipt.results) == 1
    assert receipt.results[0].source_code == "SNOMED-XYZ"
    assert receipt.results[0].target_concept_name == "Mocked Clinical Term"


def test_simulator_intent_dag_sorting() -> None:
    """Verifies topological sorting and evaluation of sequential intents containing references."""
    simulator = LocalRuntimeSimulator(db_path=None)

    def handle_stateful(intent: StatefulNodeIntent) -> str:
        return f"Executed {intent.event_cid}"

    simulator._handlers[StatefulNodeIntent.__name__] = handle_stateful

    # Intent 1 has no dependencies
    intent1 = StatefulNodeIntent(
        event_cid="cid-first-node",
        dependencies=[],
    )

    # Intent 2 depends on Intent 1's event_cid
    intent2 = StatefulNodeIntent(
        event_cid="cid-second-node",
        dependencies=["cid-first-node"],
    )

    # We pass them out of order (2 before 1) and assert they are sorted and evaluated in correct order
    intents_sequence = [intent2, intent1]

    receipts = simulator.evaluate_intent_dag(intents_sequence)
    assert len(receipts) == 2
    assert receipts[0] == "Executed cid-first-node"
    assert receipts[1] == "Executed cid-second-node"


def test_simulator_cyclic_dependencies() -> None:
    """Verifies that evaluation raises ValueError when a cycle is present in the sequence."""
    simulator = LocalRuntimeSimulator(db_path=None)

    def handle_stateful(intent: StatefulNodeIntent) -> str:
        return "Executed"

    simulator._handlers[StatefulNodeIntent.__name__] = handle_stateful

    intent1 = StatefulNodeIntent(
        event_cid="cid-node-a",
        dependencies=["cid-node-b"],
    )

    intent2 = StatefulNodeIntent(
        event_cid="cid-node-b",
        dependencies=["cid-node-a"],
    )

    intents_sequence = [intent1, intent2]

    with pytest.raises(ValueError, match="Intent sequence has cyclic dependencies"):
        simulator.evaluate_intent_dag(intents_sequence)


def test_simulator_unregistered_intent() -> None:
    """Verifies that evaluating an unknown intent raises ValueError."""
    simulator = LocalRuntimeSimulator(db_path=None)

    class UnsupportedIntent:
        pass

    with pytest.raises(ValueError, match="No handler registered for intent type"):
        simulator.evaluate_intent(UnsupportedIntent())
