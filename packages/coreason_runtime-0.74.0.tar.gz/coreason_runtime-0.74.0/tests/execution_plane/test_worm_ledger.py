# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for the Merkle DAG WORM commit ledger (#323)."""

import pytest

from coreason_runtime.execution_plane.worm_ledger import (
    MerkleChainViolationError,
    WORMCommitLedger,
    canonicalize_state,
    compute_merkle_hash,
)


def test_canonicalize_state_deterministic() -> None:
    """Verify that canonicalization is deterministic regardless of dict ordering."""
    state_a = {"b": 2, "a": 1, "c": 3}
    state_b = {"a": 1, "c": 3, "b": 2}
    assert canonicalize_state(state_a) == canonicalize_state(state_b)


def test_canonicalize_state_stable_output() -> None:
    """Verify canonical output format."""
    state = {"key": "value", "number": 42}
    result = canonicalize_state(state)
    assert result == '{"key":"value","number":42}'


def test_compute_merkle_hash_chaining() -> None:
    """Verify hash chaining produces different hashes for different priors."""
    state = '{"key":"value"}'
    hash_a = compute_merkle_hash(state, "0" * 64)
    hash_b = compute_merkle_hash(state, "a" * 64)
    assert hash_a != hash_b
    assert len(hash_a) == 64  # SHA-256 hex digest


def test_worm_ledger_append_and_verify() -> None:
    """Test basic append and chain verification in memory-only mode."""
    ledger = WORMCommitLedger(db_path="/tmp/nonexistent_worm_test")

    # Force fallback mode
    ledger._lance_table = None

    assert ledger.length == 0
    assert ledger.last_hash == "0" * 64

    # Append state transitions
    hash1 = ledger.append("workflow-1", {"step": "initialize", "value": 1})
    assert len(hash1) == 64
    assert ledger.length == 1

    hash2 = ledger.append("workflow-1", {"step": "process", "value": 2})
    assert hash2 != hash1
    assert ledger.length == 2

    ledger.append("workflow-1", {"step": "finalize", "value": 3})
    assert ledger.length == 3

    # Verify the chain is intact
    assert ledger.verify_chain() is True


def test_worm_ledger_tamper_detection() -> None:
    """Test that tampering with the ledger is detected."""
    ledger = WORMCommitLedger(db_path="/tmp/nonexistent_worm_test_tamper")
    ledger._lance_table = None

    ledger.append("workflow-1", {"step": "first"})
    ledger.append("workflow-1", {"step": "second"})
    ledger.append("workflow-1", {"step": "third"})

    # Tamper with the middle entry
    ledger._fallback_log[1]["canonical_state"] = '{"step":"TAMPERED"}'

    with pytest.raises(MerkleChainViolationError) as exc_info:
        ledger.verify_chain()

    assert "Tamper detected" in str(exc_info.value)
    assert "SEC Rule 17a-4" in str(exc_info.value)


def test_worm_ledger_chain_break_detection() -> None:
    """Test that a broken prior_hash chain is detected."""
    ledger = WORMCommitLedger(db_path="/tmp/nonexistent_worm_test_break")
    ledger._lance_table = None

    ledger.append("workflow-1", {"step": "first"})
    ledger.append("workflow-1", {"step": "second"})

    # Break the chain by modifying prior_hash
    ledger._fallback_log[1]["prior_hash"] = "deadbeef" * 8

    with pytest.raises(MerkleChainViolationError) as exc_info:
        ledger.verify_chain()

    assert "Chain break" in str(exc_info.value) or "Tamper detected" in str(exc_info.value)


def test_worm_ledger_empty_verification() -> None:
    """Verify that an empty ledger passes verification."""
    ledger = WORMCommitLedger(db_path="/tmp/nonexistent_worm_test_empty")
    ledger._lance_table = None
    assert ledger.verify_chain() is True
