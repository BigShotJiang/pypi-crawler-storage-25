# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Unit tests for the AsyncTelemetryFlusher and EU AI Act telemetry enrichment."""

import asyncio
from pathlib import Path

import pytest

from coreason_runtime.api.telemetry_flusher import AsyncTelemetryFlusher, get_telemetry_flusher


def test_telemetry_flusher_record_enrichment(tmp_path: Path) -> None:
    """Verify that events are correctly enriched with EU AI Act regulatory audit fields."""
    flusher = AsyncTelemetryFlusher(output_dir=str(tmp_path), flush_interval=0.1)

    # Assert initial stats
    stats = flusher.stats
    assert stats["buffer_size"] == 0
    assert stats["total_flushed"] == 0
    assert stats["running"] is False
    assert stats["output_dir"] == str(tmp_path)

    # Record event without extra fields
    flusher.record({"event_type": "test_run", "val": 100})
    assert len(flusher._buffer) == 1

    event = flusher._buffer[0]
    assert event["event_type"] == "test_run"
    assert event["val"] == 100
    assert "ingestion_timestamp" in event
    assert "ai_act_traceability_id" in event
    assert event["ai_act_risk_class"] == "HIGH"
    assert event["inference_seed"] is None
    assert event["temperature"] is None

    # Record event with pre-defined risk class
    flusher.record({"event_type": "low_risk_run", "ai_act_risk_class": "MINIMAL"})
    assert len(flusher._buffer) == 2
    assert flusher._buffer[1]["ai_act_risk_class"] == "MINIMAL"


@pytest.mark.asyncio
async def test_telemetry_flusher_start_stop_flush(tmp_path: Path) -> None:
    """Verify flusher start/stop lifecycle and periodic flushing behavior."""
    flusher = AsyncTelemetryFlusher(output_dir=str(tmp_path), flush_interval=0.02)

    # Start the background tasks
    await flusher.start()
    assert flusher._running is True

    # Record a couple of events
    flusher.record({"event_type": "flush_1"})
    flusher.record({"event_type": "flush_2"})

    # Let the flush interval trigger
    await asyncio.sleep(0.05)

    # Stop the flusher (should perform a final flush)
    await flusher.stop()
    assert flusher._running is False

    # Check that events were flushed
    stats = flusher.stats
    assert stats["total_flushed"] == 2
    assert stats["buffer_size"] == 0

    # Verify file was written to disk
    files = list(tmp_path.glob("telemetry_*"))
    assert len(files) > 0


def test_singleton_telemetry_flusher() -> None:
    """Verify that get_telemetry_flusher returns a singleton instance."""
    flusher_a = get_telemetry_flusher()
    flusher_b = get_telemetry_flusher()
    assert flusher_a is flusher_b
