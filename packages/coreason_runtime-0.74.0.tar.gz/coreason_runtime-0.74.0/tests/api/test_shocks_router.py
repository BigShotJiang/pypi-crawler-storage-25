# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Unit tests for the Resilience Shocks API router."""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from temporalio.client import Client, WorkflowExecutionStatus

from coreason_runtime.api.shocks_router import shocks_router

app = FastAPI()
app.include_router(shocks_router)
client = TestClient(app)


class FakeWorkflowDescription:
    def __init__(self, status: WorkflowExecutionStatus) -> None:
        self.status = status


class FakeWorkflowHandle:
    def __init__(self, workflow_id: str, status: WorkflowExecutionStatus) -> None:
        self.workflow_id = workflow_id
        self.status = status
        self.signals: list[tuple[str, dict[str, str]]] = []

    async def describe(self) -> FakeWorkflowDescription:
        return FakeWorkflowDescription(self.status)

    async def signal(self, signal_name: str, payload: dict[str, str]) -> None:
        self.signals.append((signal_name, payload))


class FakeTemporalClient:
    def __init__(self, status: WorkflowExecutionStatus) -> None:
        self.status = status
        self.handles: dict[str, FakeWorkflowHandle] = {}

    def get_workflow_handle(self, workflow_id: str) -> FakeWorkflowHandle:
        handle = FakeWorkflowHandle(workflow_id, self.status)
        self.handles[workflow_id] = handle
        return handle


@pytest.mark.asyncio
async def test_emit_resilience_shock_success(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify that a resilience shock is successfully injected to a running workflow."""
    fake_client = FakeTemporalClient(WorkflowExecutionStatus.RUNNING)

    async def fake_connect(host: str) -> FakeTemporalClient:
        return fake_client

    monkeypatch.setattr(Client, "connect", fake_connect)

    response = client.post(
        "/api/v1/orchestration/shocks",
        json={"workflow_id": "wf-123", "reason": "High CPU usage", "severity": "critical"},
    )
    assert response.status_code == 200
    assert response.json() == {"status": "shock_injected", "workflow_id": "wf-123"}

    handle = fake_client.handles["wf-123"]
    assert len(handle.signals) == 1
    assert handle.signals[0] == ("resilience_shock", {"reason": "High CPU usage", "severity": "critical"})


@pytest.mark.asyncio
async def test_emit_resilience_shock_not_running(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify that injecting a shock fails if the workflow is not running."""
    fake_client = FakeTemporalClient(WorkflowExecutionStatus.COMPLETED)

    async def fake_connect(host: str) -> FakeTemporalClient:
        return fake_client

    monkeypatch.setattr(Client, "connect", fake_connect)

    response = client.post(
        "/api/v1/orchestration/shocks",
        json={"workflow_id": "wf-completed", "reason": "OOM", "severity": "critical"},
    )
    assert response.status_code == 410
    assert "not running" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_emit_resilience_shock_connect_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify that a connection failure returns a 500 error."""

    async def fake_connect_fail(host: str) -> None:
        raise ConnectionError("Could not resolve Temporal host")

    monkeypatch.setattr(Client, "connect", fake_connect_fail)

    response = client.post(
        "/api/v1/orchestration/shocks",
        json={"workflow_id": "wf-123", "reason": "Memory Leak", "severity": "critical"},
    )
    assert response.status_code == 500
    assert "failed to inject resilience shock" in response.json()["detail"].lower()
