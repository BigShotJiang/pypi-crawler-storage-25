# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any

import httpx
import pytest
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient
from httpx import ASGITransport

from coreason_runtime.api.capabilities import router as capabilities_router
from coreason_runtime.api.oracle import router as oracle_router

app = FastAPI()
app.include_router(capabilities_router)
app.include_router(oracle_router)

client = TestClient(app)


class MockWorkflowHandle:
    async def signal(self, signal_name: str, arg: Any | None = None) -> None:
        pass


class MockTemporalClient:
    def get_workflow_handle(self, _workflow_id: str) -> MockWorkflowHandle:
        return MockWorkflowHandle()

    @classmethod
    async def connect(cls, _host: str, **_kwargs: Any) -> "MockTemporalClient":
        return cls()


@pytest.fixture(autouse=True)
def mock_temporal_client(monkeypatch: pytest.MonkeyPatch) -> None:
    from temporalio.client import Client

    monkeypatch.setattr(Client, "connect", MockTemporalClient.connect)


@pytest.fixture(autouse=True)
def mock_asyncio_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    original_sleep = asyncio.sleep

    async def mock_sleep(delay: float) -> None:
        if delay >= 15.0:
            await original_sleep(10.0)
        else:
            await original_sleep(0.001)

    monkeypatch.setattr("asyncio.sleep", mock_sleep)

    async def mock_is_disconnected(self: Request) -> bool:
        return True

    monkeypatch.setattr(Request, "is_disconnected", mock_is_disconnected)


def test_get_capabilities() -> None:
    response = client.get("/api/v1/capabilities")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert "math_calculator" in data
    assert "string_processor" in data
    assert "shell_executor" in data


def test_execute_math_calculator() -> None:
    payload = {"toolName": "math_calculator", "intent": {"arguments": {"expression": "10 * 5 - 2"}}, "state": {}}
    response = client.post("/api/v1/capabilities/execute", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["output"]["result"] == 48
    assert "logs" in data
    assert "telemetry" in data
    assert "intent_hash" in data


def test_execute_string_processor() -> None:
    payload = {
        "toolName": "string_processor",
        "intent": {"arguments": {"text": "coreason", "action": "reverse"}},
        "state": {},
    }
    response = client.post("/api/v1/capabilities/execute", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["output"]["result"] == "nosaeroc"


def test_crystallize() -> None:
    payload = {"capability": "math_calculator", "state": "{}", "intent": "{}", "output": "48"}
    response = client.post("/api/v1/crystallize", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"


def test_kb_publish() -> None:
    payload = {"toolName": "math_calculator", "intent": "{}"}
    response = client.post("/api/v1/kb/publish", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"


def test_override_simulated() -> None:
    payload = {"workflowId": "wf-test-override", "correctedIntent": {"expression": "1 + 1"}}
    response = client.post("/api/v1/override", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert "simulated" in data["message"].lower() or "dispatched" in data["message"].lower()


def test_approve_simulated() -> None:
    payload = {"workflowId": "wf-test-approve", "attestation": "fido2_webauthn"}
    response = client.post("/api/v1/approve", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert "simulated" in data["message"].lower() or "dispatched" in data["message"].lower()


@pytest.mark.asyncio
async def test_telemetry_stream() -> None:
    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as async_client:
        async with async_client.stream("GET", "/api/v1/telemetry/stream") as response:
            assert response.status_code == 200
            assert "text/event-stream" in response.headers["content-type"]

            # Read the first few lines of the stream to verify events are received
            lines = []
            async for line in response.aiter_lines():
                if line:
                    lines.append(line)
                if len(lines) >= 3:
                    break

            assert len(lines) >= 2
            assert lines[0].startswith("data: ")


def test_oracle_submit_flat() -> None:
    payload = {
        "workflowId": "wf-oracle-flat-submit",
        "correctedIntent": {"action": "approve"},
        "receipt_type": "InterventionReceipt",
        "yield_type": "AgentResponse",
    }
    response = client.post("/api/v1/oracle/submit", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"


def test_oracle_resolve_flat() -> None:
    payload = {"workflowId": "wf-oracle-flat-resolve", "correctedIntent": {"action": "resolve"}}
    response = client.post("/api/v1/oracle/resolve", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "resolution_injected"
