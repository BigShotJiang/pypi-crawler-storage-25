# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.history_router import router

app = FastAPI()
app.include_router(router)
client = TestClient(app)


def test_query_historical_states_success() -> None:
    """Verify querying historical states returns deterministic telemetry."""
    response = client.get(
        "/api/v1/history/states?simulationId=sim-test-1&minTimestamp=1716388800000&maxTimestamp=1716388920000"
    )
    assert response.status_code == 200
    resp_json = response.json()
    assert resp_json["simulationId"] == "sim-test-1"
    assert "snapshots" in resp_json
    assert len(resp_json["snapshots"]) > 0
    first_snapshot = resp_json["snapshots"][0]
    assert "timestamp" in first_snapshot
    assert "tokenConfidence" in first_snapshot
    assert "ramBytesAllocated" in first_snapshot
    assert "cpuFuelBurned" in first_snapshot


def test_spawn_simulation_fork_success() -> None:
    """Verify that initiating a fork succeeds."""
    payload = {
        "sourceSimulationId": "sim-test-1",
        "branchPointTimestamp": 1716388800000,
        "forkName": "Alternative-Path",
    }
    response = client.post("/api/v1/history/simulations/fork", json=payload)
    assert response.status_code == 200
    resp_json = response.json()
    assert resp_json["sourceSimulationId"] == "sim-test-1"
    assert resp_json["forkName"] == "Alternative-Path"
    assert resp_json["status"] == "INITIATED"
    assert "forkSimulationId" in resp_json
