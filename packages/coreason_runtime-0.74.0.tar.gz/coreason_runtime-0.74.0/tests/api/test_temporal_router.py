# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Unit tests for the Temporal APIRouter workflow history resolution."""

from typing import Any

from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.temporal_router import get_temporal_client, temporal_router

app = FastAPI()
app.include_router(temporal_router)
client = TestClient(app)


class FakeWorkflowHistory:
    """Fake representation of Temporal WorkflowHistory snapshot."""

    def __init__(self, workflow_id: str, events: Any) -> None:
        self.workflow_id = workflow_id
        self._events = events

    def to_json_dict(self) -> dict[str, Any]:
        """Convert the history snapshot to a JSON compatible dictionary."""
        return {
            "events": self._events,
            "workflowId": self.workflow_id,
        }


class FakeWorkflowHandle:
    """Fake Temporal WorkflowHandle to simulate history resolution."""

    def __init__(
        self,
        workflow_id: str,
        events: Any = None,
        raise_rpc_error: bool = False,
        raise_unexpected: bool = False,
    ) -> None:
        self.workflow_id = workflow_id
        self._events = events or []
        self._raise_rpc_error = raise_rpc_error
        self._raise_unexpected = raise_unexpected

    async def fetch_history(self) -> FakeWorkflowHistory:
        """Simulate fetching workflow history."""
        import temporalio.service

        if self._raise_rpc_error:
            raise temporalio.service.RPCError(
                "Workflow execution not found",
                temporalio.service.RPCStatusCode.NOT_FOUND,
                b"WorkflowNotExists",
            )
        if self._raise_unexpected:
            raise RuntimeError("Substrate connection failure")
        return FakeWorkflowHistory(self.workflow_id, self._events)


class FakeTemporalClient:
    """Fake Temporal client connection."""

    def __init__(
        self,
        events: Any = None,
        raise_rpc_error: bool = False,
        raise_unexpected: bool = False,
    ) -> None:
        self._events = events
        self._raise_rpc_error = raise_rpc_error
        self._raise_unexpected = raise_unexpected

    def get_workflow_handle(self, workflow_id: str) -> FakeWorkflowHandle:
        """Resolve a handle for the given workflow."""
        return FakeWorkflowHandle(
            workflow_id=workflow_id,
            events=self._events,
            raise_rpc_error=self._raise_rpc_error,
            raise_unexpected=self._raise_unexpected,
        )


def test_retrieve_workflow_history_success() -> None:
    """Verify successful history retrieval for a valid workflow."""
    fake_client = FakeTemporalClient(events=[{"eventId": 1, "eventType": "WorkflowExecutionStarted"}])
    app.dependency_overrides[get_temporal_client] = lambda: fake_client
    try:
        response = client.get("/api/v1/temporal/workflows/wf-123/history")
        assert response.status_code == 200
        resp_json = response.json()
        assert resp_json["status"] == "success"
        assert resp_json["history"]["workflowId"] == "wf-123"
        assert resp_json["history"]["events"][0]["eventType"] == "WorkflowExecutionStarted"
    finally:
        app.dependency_overrides.clear()


def test_retrieve_workflow_history_not_found() -> None:
    """Verify that an RPCError maps to a 404 response."""
    fake_client = FakeTemporalClient(raise_rpc_error=True)
    app.dependency_overrides[get_temporal_client] = lambda: fake_client
    try:
        response = client.get("/api/v1/temporal/workflows/wf-404/history")
        assert response.status_code == 404
        resp_json = response.json()
        assert "not found" in resp_json["detail"].lower()
    finally:
        app.dependency_overrides.clear()


def test_retrieve_workflow_history_internal_error() -> None:
    """Verify that unexpected system exceptions map to a 500 response."""
    fake_client = FakeTemporalClient(raise_unexpected=True)
    app.dependency_overrides[get_temporal_client] = lambda: fake_client
    try:
        response = client.get("/api/v1/temporal/workflows/wf-500/history")
        assert response.status_code == 500
        resp_json = response.json()
        assert "internal" in resp_json["detail"].lower()
    finally:
        app.dependency_overrides.clear()
