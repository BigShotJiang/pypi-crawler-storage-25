# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Comprehensive tests for EnterpriseIdentityMiddleware.

Uses real JWT generation via authlib.jose with real RSA keys, respx for HTTP
interception (no unittest.mock), and httpx.AsyncClient with real ASGI transport.
"""

import time
from typing import Any

import httpx
import pytest
import respx
from authlib.jose import JsonWebKey, jwt
from httpx import ASGITransport
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from coreason_runtime.api.middleware import EnterpriseIdentityMiddleware

# ---------------------------------------------------------------------------
# Real RSA key pair for JWT generation
# ---------------------------------------------------------------------------
_RSA_KEY = JsonWebKey.generate_key("RSA", 2048, is_private=True)
_RSA_PUBLIC_JWK = _RSA_KEY.as_dict(is_private=False)
_JWKS_RESPONSE = {"keys": [_RSA_PUBLIC_JWK]}


def _make_jwt(
    claims: dict[str, Any] | None = None,
    *,
    expired: bool = False,
    key: Any = None,
) -> str:
    """Generate a real signed JWT using authlib.jose."""
    now = int(time.time())
    default_claims = {
        "iss": "https://idp.coreason.ai",
        "sub": "test-user-001",
        "aud": "coreason-runtime",
        "iat": now,
        "exp": now + 3600,
    }
    if expired:
        default_claims["exp"] = now - 3600
        default_claims["iat"] = now - 7200
    if claims:
        default_claims.update(claims)

    header = {"alg": "RS256", "kid": _RSA_KEY.as_dict().get("kid", "test-key")}
    signing_key = key if key is not None else _RSA_KEY
    return jwt.encode(header, default_claims, signing_key).decode("utf-8")


# ---------------------------------------------------------------------------
# Starlette app with middleware for testing
# ---------------------------------------------------------------------------


async def _protected_resume(request: Request) -> JSONResponse:
    """Endpoint behind the middleware."""
    identity = request.scope.get("coreason_identity")
    return JSONResponse({"status": "ok", "has_identity": identity is not None})


async def _protected_retract(request: Request) -> JSONResponse:
    """Another protected endpoint."""
    identity = request.scope.get("coreason_identity")
    return JSONResponse({"status": "ok", "has_identity": identity is not None})


async def _unprotected(request: Request) -> JSONResponse:
    """Endpoint NOT behind the middleware."""
    return JSONResponse({"status": "public"})


_routes = [
    Route("/api/v1/oracle/resume", _protected_resume, methods=["POST", "GET"]),
    Route("/api/v1/temporal/retract", _protected_retract, methods=["POST", "GET"]),
    Route("/api/v1/capabilities", _unprotected, methods=["GET"]),
    Route("/health", _unprotected, methods=["GET"]),
]

_raw_app = Starlette(routes=_routes)
_app = EnterpriseIdentityMiddleware(_raw_app)

OPA_URL = "http://localhost:8181/v1/data/coreason/authz/allow"
JWKS_URL = "http://localhost:8000/.well-known/jwks.json"


# ---------------------------------------------------------------------------
# Test: Non-HTTP scopes (e.g. lifespan) pass through
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_non_http_scope_passes_through() -> None:
    """Non-HTTP scopes (e.g. lifespan) should pass directly to the inner app."""
    # Starlette's lifespan scope type should pass through without auth checks.
    # We test this by using a simple GET on an unprotected route to verify the app works,
    # then verify that a non-http scope type would be forwarded.
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "public"}


# ---------------------------------------------------------------------------
# Test: Unprotected routes pass through without auth
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_unprotected_route_passes_through() -> None:
    """Routes not in protected_routes should pass through without JWT validation."""
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.get("/api/v1/capabilities")
        assert response.status_code == 200
        assert response.json() == {"status": "public"}


@pytest.mark.asyncio
async def test_unprotected_route_no_auth_header_needed() -> None:
    """Unprotected routes should work even without any Authorization header."""
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.get("/health")
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Test: Missing Authorization header on protected route
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_protected_route_missing_auth_header() -> None:
    """Protected routes without Authorization header should return 401."""
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.post("/api/v1/oracle/resume")
        assert response.status_code == 401
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"
        assert "Missing or invalid Authorization header" in data["details"]


# ---------------------------------------------------------------------------
# Test: Invalid Authorization header format
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_protected_route_invalid_auth_format_no_bearer() -> None:
    """Authorization header without 'Bearer ' prefix should return 401."""
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": "Basic dXNlcjpwYXNz"},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"
        assert "Missing or invalid Authorization header" in data["details"]


@pytest.mark.asyncio
async def test_protected_route_empty_auth_header() -> None:
    """Empty Authorization header should return 401."""
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": ""},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"


# ---------------------------------------------------------------------------
# Test: Expired JWT should return 401
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_expired_jwt() -> None:
    """An expired JWT should fail validation and return 401."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)

    # Create a fresh middleware instance so _jwks is not cached from other tests
    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt(expired=True)

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"
        assert "JWT Validation Failed" in data["details"]


# ---------------------------------------------------------------------------
# Test: Malformed JWT token should return 401
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_malformed_jwt() -> None:
    """A non-JWT string as Bearer token should fail validation and return 401."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": "Bearer not-a-valid-jwt-token"},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"
        assert "JWT Validation Failed" in data["details"]


# ---------------------------------------------------------------------------
# Test: JWT signed with wrong key should return 401
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_jwt_wrong_key() -> None:
    """A JWT signed with a different RSA key should fail JWKS validation."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    wrong_key = JsonWebKey.generate_key("RSA", 2048, is_private=True)
    token = _make_jwt(key=wrong_key)

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"


# ---------------------------------------------------------------------------
# Test: JWKS endpoint failure should return 401
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_jwks_endpoint_failure() -> None:
    """If the JWKS endpoint returns an error, JWT validation should fail with 401."""
    respx.get(JWKS_URL).respond(status_code=500, json={"error": "internal"})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 401


# ---------------------------------------------------------------------------
# Test: Valid JWT but OPA denies access → 403
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_opa_denies() -> None:
    """Valid JWT but OPA returns result=false should return 403."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    respx.post(OPA_URL).respond(json={"result": False})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 403
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"
        assert "OPA" in data["details"]


# ---------------------------------------------------------------------------
# Test: Valid JWT but OPA endpoint is unreachable → 403
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_opa_unreachable() -> None:
    """If OPA sidecar is unreachable, authorization should fail with 403."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    respx.post(OPA_URL).mock(side_effect=httpx.ConnectError("Connection refused"))

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 403
        data = response.json()
        assert data["error"] == "ManifestViolationReceipt"
        assert "OPA" in data["details"]


# ---------------------------------------------------------------------------
# Test: Valid JWT + OPA allows → 200 with identity injected
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_protected_route_valid_jwt_opa_allows() -> None:
    """Valid JWT with OPA allowing should pass through and inject identity."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    respx.post(OPA_URL).respond(json={"result": True})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert data["has_identity"] is True


# ---------------------------------------------------------------------------
# Test: Second protected route (retract) also works
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_retract_protected_route_valid_jwt_opa_allows() -> None:
    """The /api/v1/temporal/retract route is also protected."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    respx.post(OPA_URL).respond(json={"result": True})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(
            "/api/v1/temporal/retract",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["has_identity"] is True


# ---------------------------------------------------------------------------
# Test: Custom execution_taint in JWT claims is used
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_custom_execution_taint_in_jwt() -> None:
    """If the JWT contains execution_taint, that value should be used."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    opa_route = respx.post(OPA_URL).respond(json={"result": True})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    custom_taint = "spiffe://coreason.ai/ns/production/sa/operator"
    token = _make_jwt({"execution_taint": custom_taint})

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200

    # Verify OPA was called with the custom taint
    assert opa_route.called
    opa_request_body = opa_route.calls[0].request.content
    import json

    opa_input = json.loads(opa_request_body)
    assert opa_input["input"]["taint"] == custom_taint


# ---------------------------------------------------------------------------
# Test: Default execution_taint when not in JWT
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_default_execution_taint() -> None:
    """When JWT has no execution_taint, the default SPIFFE URI is used."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    opa_route = respx.post(OPA_URL).respond(json={"result": True})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()  # No execution_taint claim

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200

    import json

    opa_input = json.loads(opa_route.calls[0].request.content)
    assert opa_input["input"]["taint"] == "spiffe://coreason.ai/ns/default/sa/admin"


# ---------------------------------------------------------------------------
# Test: JWKS caching behavior
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_jwks_is_cached_after_first_fetch() -> None:
    """The JWKS should be fetched once and then cached for subsequent requests."""
    jwks_route = respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    respx.post(OPA_URL).respond(json={"result": True})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        # First request should fetch JWKS
        response1 = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response1.status_code == 200

        # Second request should use cached JWKS
        response2 = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response2.status_code == 200

    # JWKS endpoint should only be called once
    assert jwks_route.call_count == 1


# ---------------------------------------------------------------------------
# Test: OPA receives correct method and path in input
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_opa_receives_correct_method_and_path() -> None:
    """OPA input should contain the correct HTTP method and request path."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    opa_route = respx.post(OPA_URL).respond(json={"result": True})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )

    import json

    opa_input = json.loads(opa_route.calls[0].request.content)
    assert opa_input["input"]["method"] == "POST"
    assert opa_input["input"]["path"] == "/api/v1/oracle/resume"


# ---------------------------------------------------------------------------
# Test: OPA response missing 'result' key → treated as denial → 403
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_opa_response_missing_result_key() -> None:
    """If OPA response has no 'result' key, default is False → 403."""
    respx.get(JWKS_URL).respond(json=_JWKS_RESPONSE)
    respx.post(OPA_URL).respond(json={"decision_id": "abc123"})

    app = EnterpriseIdentityMiddleware(Starlette(routes=_routes))
    token = _make_jwt()

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/v1/oracle/resume",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 403


# ---------------------------------------------------------------------------
# Test: Protected route with subpath
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_protected_route_subpath_without_auth() -> None:
    """A subpath of a protected route should also be protected (startswith match)."""
    async with httpx.AsyncClient(transport=ASGITransport(app=_app), base_url="http://test") as client:
        response = await client.post("/api/v1/oracle/resume/extra")
        # Should still hit the auth check due to startswith matching
        assert response.status_code == 401
