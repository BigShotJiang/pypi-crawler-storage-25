# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Unit tests for the Semantic Discovery API router."""

from typing import Any

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.discovery_router import discovery_router

app = FastAPI()
app.include_router(discovery_router)
client = TestClient(app)


class FakeDiscoveryIndexer:
    def __init__(self, tenant_cid: str) -> None:
        self.tenant_cid = tenant_cid
        self.sync_called = False

    def sync_local_wasm(self) -> None:
        self.sync_called = True

    def search_capabilities(self, query: str, limit: int, tenant_cid: str) -> list[dict[str, Any]]:
        _ = (limit, tenant_cid)
        if query == "fail":
            raise RuntimeError("Database connection timed out")
        return [{"urn": "urn:coreason:test-capability", "score": 0.95}]


def test_discovery_search_success(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify successful semantic capability search."""
    monkeypatch.setattr("coreason_runtime.api.discovery_router.DiscoveryIndexer", FakeDiscoveryIndexer)

    response = client.post(
        "/api/v1/discovery/search",
        json={"query": "process files", "limit": 5, "tenant_cid": "test-tenant-123"},
    )
    assert response.status_code == 200
    assert response.json() == [{"urn": "urn:coreason:test-capability", "score": 0.95}]


def test_discovery_search_exception(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify that exceptions during search are mapped to a 500 error."""
    monkeypatch.setattr("coreason_runtime.api.discovery_router.DiscoveryIndexer", FakeDiscoveryIndexer)

    response = client.post(
        "/api/v1/discovery/search",
        json={"query": "fail", "limit": 5},
    )
    assert response.status_code == 500
    assert "Discovery search failed" in response.json()["detail"]
