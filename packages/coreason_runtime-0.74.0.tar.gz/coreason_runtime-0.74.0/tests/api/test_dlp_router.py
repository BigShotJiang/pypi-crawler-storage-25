# Copyright (c) 2026 CoReason, Inc.

"""Tests for DLP Egress Router and EgressClassifier (#373)."""

from __future__ import annotations

import pytest
from coreason_runtime.api.dlp_router import EgressClassifier


class TestEgressClassifier:
    """Tests for the EgressClassifier pattern scanner."""

    def _make_classifier(self) -> EgressClassifier:
        return EgressClassifier()

    def test_nominal_egress(self) -> None:
        """Clean payload should return NOMINAL."""
        c = self._make_classifier()
        event = c.classify_egress(
            payload=b'{"query": "What is the weather?"}',
            agent_urn="urn:coreason:agent:test:01",
            destination="api.openai.com/v1/chat",
        )
        assert event.classification_outcome == "NOMINAL"
        assert event.blocked_data_pattern is None

    def test_blocked_private_key(self) -> None:
        """Payload with private key should be BLOCKED."""
        c = self._make_classifier()
        event = c.classify_egress(
            payload=b"-----BEGIN RSA PRIVATE KEY-----\nMIIE...",
            agent_urn="urn:coreason:agent:test:01",
            destination="api.openai.com/v1/chat",
        )
        assert event.classification_outcome == "BLOCKED"
        assert event.blocked_data_pattern == "Private Key Material"

    def test_blocked_certificate(self) -> None:
        """Payload with SPIFFE certificate should be BLOCKED."""
        c = self._make_classifier()
        event = c.classify_egress(
            payload=b"-----BEGIN CERTIFICATE-----\nMIIB...",
            agent_urn="urn:coreason:agent:test:01",
            destination="external.service.com",
        )
        assert event.classification_outcome == "BLOCKED"
        assert "Certificate" in (event.blocked_data_pattern or "")

    def test_blocked_aws_key(self) -> None:
        """Payload with AWS access key should be BLOCKED."""
        c = self._make_classifier()
        event = c.classify_egress(
            payload=b"Access key: AKIAIOSFODNN7EXAMPLE",
            agent_urn="urn:coreason:agent:test:01",
            destination="s3.amazonaws.com",
        )
        assert event.classification_outcome == "BLOCKED"
        assert "AWS" in (event.blocked_data_pattern or "")

    def test_fail_closed_on_error(self) -> None:
        """Classifier error should default to BLOCKED."""
        c = self._make_classifier()
        # Force an error by passing something that will cause issues
        # We monkeypatch _SENSITIVE_PATTERNS to raise during search
        import coreason_runtime.api.dlp_router as dlp_mod

        original = dlp_mod._SENSITIVE_PATTERNS

        class BadPattern:
            def search(self, _s: str) -> None:
                raise RuntimeError("boom")

        dlp_mod._SENSITIVE_PATTERNS = [(BadPattern(), "test")]  # type: ignore[list-item]
        try:
            event = c.classify_egress(
                payload=b"test payload",
                agent_urn="urn:coreason:agent:test:01",
                destination="test.com",
            )
            assert event.classification_outcome == "BLOCKED"
            assert "fail-closed" in (event.blocked_data_pattern or "").lower()
        finally:
            dlp_mod._SENSITIVE_PATTERNS = original

    def test_history_tracking(self) -> None:
        """Blocked events should be tracked in history."""
        c = self._make_classifier()
        c.classify_egress(
            payload=b"-----BEGIN CERTIFICATE-----\ndata",
            agent_urn="urn:coreason:agent:a:01",
            destination="evil.com",
        )
        c.classify_egress(
            payload=b"clean data",
            agent_urn="urn:coreason:agent:b:01",
            destination="good.com",
        )
        c.classify_egress(
            payload=b"AKIAIOSFODNN7EXAMPLE key",
            agent_urn="urn:coreason:agent:a:01",
            destination="s3.com",
        )

        blocks, total = c.get_blocked_events()
        assert total == 2
        assert len(blocks) == 2

    def test_filter_by_agent_urn(self) -> None:
        """History should be filterable by agent URN."""
        c = self._make_classifier()
        c.classify_egress(b"-----BEGIN CERTIFICATE-----", "urn:coreason:agent:a:01", "x.com")
        c.classify_egress(b"AKIAIOSFODNN7EXAMPLE", "urn:coreason:agent:b:01", "y.com")

        blocks_a, _ = c.get_blocked_events(agent_urn="urn:coreason:agent:a:01")
        assert len(blocks_a) == 1
        assert blocks_a[0].originating_agent_urn == "urn:coreason:agent:a:01"
