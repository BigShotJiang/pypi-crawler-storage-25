# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import sqlite3
from pathlib import Path

import pytest
from pydantic import BaseModel

from coreason_runtime.orchestration.solvers.ontological_vocabulary_solver import (
    OntologicalVocabularyConnectionPool,
    OntologicalVocabularySolver,
)


class DummySchemaModel(BaseModel):
    coordinate_name: str
    active_flag: bool


@pytest.fixture
def temp_vocabulary_db(tmp_path: Path) -> str:
    """Provisions a physical SQLite database with OMOP concept tables."""
    db_file = tmp_path / "vocabulary.db"
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()

    # Create OMOP schema tables
    cursor.execute("""
        CREATE TABLE concept (
            concept_id INTEGER PRIMARY KEY,
            concept_code TEXT,
            concept_name TEXT,
            vocabulary_id TEXT,
            domain_id TEXT,
            standard_concept TEXT,
            invalid_reason TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE concept_relationship (
            concept_id_1 INTEGER,
            concept_id_2 INTEGER,
            relationship_id TEXT,
            invalid_reason TEXT
        )
    """)

    # Populate concept data
    # 1. Source concept (needs mapping)
    cursor.execute(
        "INSERT INTO concept VALUES (?, ?, ?, ?, ?, ?, ?)",
        (101, "SNOMED-S1", "Source Concept One", "SNOMED", "Condition", None, None),
    )
    # 2. Target concept (mapped standard concept)
    cursor.execute(
        "INSERT INTO concept VALUES (?, ?, ?, ?, ?, ?, ?)",
        (201, "OMOP-T1", "Standard Concept One", "RxNorm", "Condition", "S", None),
    )
    # Relationship mapping
    cursor.execute(
        "INSERT INTO concept_relationship VALUES (?, ?, ?, ?)",
        (101, 201, "Maps to", None),
    )

    # 3. Fallback concept (direct lookup when mapping is absent)
    cursor.execute(
        "INSERT INTO concept VALUES (?, ?, ?, ?, ?, ?, ?)",
        (301, "LOINC-F1", "Fallback Measurement", "LOINC", "Measurement", "S", None),
    )

    conn.commit()
    conn.close()
    return str(db_file)


def test_connection_pool_lifecycle(temp_vocabulary_db: str) -> None:
    """Verifies connection pool initialization, acquisition, and release."""
    pool = OntologicalVocabularyConnectionPool(temp_vocabulary_db, max_connections=2)
    conn1 = pool.acquire_conn()
    conn2 = pool.acquire_conn()

    assert isinstance(conn1, sqlite3.Connection)
    assert isinstance(conn2, sqlite3.Connection)

    pool.release_conn(conn1)
    pool.release_conn(conn2)
    pool.close_all()


def test_solver_relationship_mapping(temp_vocabulary_db: str) -> None:
    """Verifies OMOP standard relationship mapping query path."""
    solver = OntologicalVocabularySolver(temp_vocabulary_db)
    try:
        results = solver.resolve_vocabulary_mappings(
            query_term="SNOMED-S1",
            target_domains=["Condition"],
            max_results=5,
        )

        assert len(results) == 1
        mapping = results[0]
        assert mapping.source_code == "SNOMED-S1"
        assert mapping.source_vocabulary == "SNOMED"
        assert mapping.target_concept_id == 201
        assert mapping.target_concept_name == "Standard Concept One"
        assert mapping.domain_id == "Condition"
        assert mapping.confidence_score == 1.0
        assert mapping.mapping_status == "APPROVED"
    finally:
        solver.close()


def test_solver_fallback_query(temp_vocabulary_db: str) -> None:
    """Verifies fallback direct query path when no relationship mapping exists."""
    solver = OntologicalVocabularySolver(temp_vocabulary_db)
    try:
        results = solver.resolve_vocabulary_mappings(
            query_term="LOINC-F1",
            target_domains=["Measurement"],
            max_results=5,
        )

        assert len(results) == 1
        mapping = results[0]
        assert mapping.source_code == "LOINC-F1"
        assert mapping.source_vocabulary == "LOINC"
        assert mapping.target_concept_id == 301
        assert mapping.target_concept_name == "Fallback Measurement"
        assert mapping.domain_id == "Measurement"
        assert mapping.confidence_score == 1.0
    finally:
        solver.close()


def test_solver_filtering_by_domain(temp_vocabulary_db: str) -> None:
    """Verifies filtering results by target domains."""
    solver = OntologicalVocabularySolver(temp_vocabulary_db)
    try:
        # Querying term standard concept 1, but filtering for Measurement domain (it's Condition)
        results = solver.resolve_vocabulary_mappings(
            query_term="SNOMED-S1",
            target_domains=["Measurement"],
            max_results=5,
        )
        assert len(results) == 0
    finally:
        solver.close()


def test_solver_constrained_filter_fallback() -> None:
    """Verifies constraint filter logic with the fallback decoder."""
    solver = OntologicalVocabularySolver(":memory:")
    try:
        decoder = solver.compile_constrained_filter(DummySchemaModel)
        assert decoder is not None

        # Test generation with a simple LLM callable returning valid JSON
        def mock_llm(prompt: str) -> str:
            return '{"coordinate_name": "TestCoordinate", "active_flag": true}'

        validated_instance = decoder.generate(mock_llm, "Provide schema coordinate details")
        assert isinstance(validated_instance, DummySchemaModel)
        assert validated_instance.coordinate_name == "TestCoordinate"
        assert validated_instance.active_flag is True
    finally:
        solver.close()
