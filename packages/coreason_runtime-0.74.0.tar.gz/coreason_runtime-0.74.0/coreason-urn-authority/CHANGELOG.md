# Changelog

## [0.37.0](https://github.com/CoReason-AI/coreason-urn-authority/compare/v0.36.0...v0.37.0) (2026-05-22)


### Features

* **ceremony:** multi-signature keysigning ceremony endpoint ([#107](https://github.com/CoReason-AI/coreason-urn-authority/issues/107)) ([a0cf74f](https://github.com/CoReason-AI/coreason-urn-authority/commit/a0cf74f83387f30acd6fa19e4408c8ce801f04f4))

## [0.36.0](https://github.com/CoReason-AI/coreason-urn-authority/compare/v0.35.0...v0.36.0) (2026-05-22)


### Features

* **crypto:** EZKL zk-SNARK verifiers and public mesh ingestion ([#91](https://github.com/CoReason-AI/coreason-urn-authority/issues/91), [#97](https://github.com/CoReason-AI/coreason-urn-authority/issues/97), [#98](https://github.com/CoReason-AI/coreason-urn-authority/issues/98), [#103](https://github.com/CoReason-AI/coreason-urn-authority/issues/103)) ([9fe6625](https://github.com/CoReason-AI/coreason-urn-authority/commit/9fe6625c50b924ffb31ab9427385a37c4d350fb7))
* **ledger:** cryptographic genesis anchor with Ed25519 signing ([#92](https://github.com/CoReason-AI/coreason-urn-authority/issues/92)) ([dc2feea](https://github.com/CoReason-AI/coreason-urn-authority/commit/dc2feeafaaea37d09ea3911fe1daf175da9aca78))


### Bug Fixes

* **ci:** dynamic dependency resolution config for PyPI on runners ([ab0b232](https://github.com/CoReason-AI/coreason-urn-authority/commit/ab0b232093c2c0718ed7d4f3d72bb4720c311283))
* **ci:** handle policy-blocked release-please merge gracefully ([86ec4fe](https://github.com/CoReason-AI/coreason-urn-authority/commit/86ec4fe3778b8c569168cff9be38d969585d04d8))
* **ci:** remove GHCR_PAT fallback from release-please token ([966e2a6](https://github.com/CoReason-AI/coreason-urn-authority/commit/966e2a63cf9c8684436627c73554b13dcc06b12b))
* CRLF signature bypass, dead code cleanup, and SD-JWT validation ([#93](https://github.com/CoReason-AI/coreason-urn-authority/issues/93), [#105](https://github.com/CoReason-AI/coreason-urn-authority/issues/105), [#106](https://github.com/CoReason-AI/coreason-urn-authority/issues/106)) ([59f2b51](https://github.com/CoReason-AI/coreason-urn-authority/commit/59f2b51963ad0887f5ae646f4cb8554fc45cb121))
* **release:** prevent fromJSON parser error when release PR is empty ([f339606](https://github.com/CoReason-AI/coreason-urn-authority/commit/f339606b6154d888c973a3778ff53d26c58401fa))
* **security:** input validation, fail-closed auth, and insecure defaults (Sprint C) ([d67a797](https://github.com/CoReason-AI/coreason-urn-authority/commit/d67a79722c29bdb61fb18bc2f411c50a2dcbb3b0))


### Performance Improvements

* **loader:** file-mtime ledger cache and module-level URN pattern (Sprint D) ([ce819ba](https://github.com/CoReason-AI/coreason-urn-authority/commit/ce819ba6bc95e591277a39881f723d8bdc537b59))
