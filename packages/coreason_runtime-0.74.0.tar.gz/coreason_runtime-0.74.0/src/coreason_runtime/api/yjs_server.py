# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import logging

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

logger = logging.getLogger("yjs_server")

ws_app = FastAPI(title="Yjs CRDT Collaborative Synchronization Server")

# Map from room name -> set of active WebSockets
rooms: dict[str, set[WebSocket]] = {}


@ws_app.websocket("/{room_name}")
async def websocket_endpoint(websocket: WebSocket, room_name: str) -> None:
    await websocket.accept()
    if room_name not in rooms:
        rooms[room_name] = set()
    rooms[room_name].add(websocket)
    logger.info(f"Client connected to Yjs room: {room_name}. Total clients: {len(rooms[room_name])}")
    try:
        while True:
            # Handle binary and text frames
            message = await websocket.receive()
            msg_type = message.get("type", "")

            # Break cleanly on disconnect instead of re-entering receive()
            if msg_type == "websocket.disconnect":
                break

            if "bytes" in message:
                data = message["bytes"]
                # Broadcast bytes to all other clients in the same room
                disconnected: set[WebSocket] = set()
                for client in list(rooms[room_name]):
                    if client != websocket:
                        try:
                            await client.send_bytes(data)
                        except (WebSocketDisconnect, RuntimeError):
                            disconnected.add(client)
                rooms[room_name] -= disconnected
            elif "text" in message:
                data = message["text"]
                # Broadcast text to all other clients in the same room
                disconnected = set()
                for client in list(rooms[room_name]):
                    if client != websocket:
                        try:
                            await client.send_text(data)
                        except (WebSocketDisconnect, RuntimeError):
                            disconnected.add(client)
                rooms[room_name] -= disconnected
    except WebSocketDisconnect:
        logger.info(f"Client disconnected from Yjs room: {room_name}")
    except Exception as e:
        logger.error(f"WebSocket error in Yjs room '{room_name}': {e}")
    finally:
        if room_name in rooms:
            rooms[room_name].discard(websocket)
            if not rooms[room_name]:
                del rooms[room_name]
