# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from __future__ import annotations

import math
from typing import Any

from fastapi import APIRouter, HTTPException, Header, Query
from pydantic import BaseModel, Field

from coreason_runtime.utils.logger import logger

router = APIRouter(prefix="/api/v1/history", tags=["Simulation History"])


class SnapshotItem(BaseModel):
    timestamp: int
    token_confidence: float = Field(..., alias="tokenConfidence")
    ram_bytes_allocated: int = Field(..., alias="ramBytesAllocated")
    cpu_fuel_burned: int = Field(..., alias="cpuFuelBurned")


class HistoryStateResponse(BaseModel):
    simulation_id: str = Field(..., alias="simulationId")
    snapshots: list[SnapshotItem]


class ForkPayload(BaseModel):
    source_simulation_id: str = Field(..., alias="sourceSimulationId")
    branch_point_timestamp: int = Field(..., alias="branchPointTimestamp")
    fork_name: str = Field(..., alias="forkName")


class ForkResponse(BaseModel):
    fork_simulation_id: str = Field(..., alias="forkSimulationId")
    source_simulation_id: str = Field(..., alias="sourceSimulationId")
    branch_point_timestamp: int = Field(..., alias="branchPointTimestamp")
    fork_name: str = Field(..., alias="forkName")
    status: str


@router.get("/states", response_model=HistoryStateResponse)
async def query_historical_states(
    simulation_id: str = Query(..., alias="simulationId"),
    min_timestamp: int | None = Query(None, alias="minTimestamp"),
    max_timestamp: int | None = Query(None, alias="maxTimestamp"),
    authorization: str | None = Header(None),  # Epic 8: JWT auth
) -> Any:
    """Retrieve historical state snapshots for a simulation."""
    logger.info(f"Querying state snapshots for simulation: {simulation_id}")

    # Epic 8: Input validation
    if not simulation_id or len(simulation_id) > 256:
        raise HTTPException(status_code=422, detail="Invalid simulationId: must be 1-256 characters")

    min_t = min_timestamp if min_timestamp is not None else 1716388800000
    max_t = max_timestamp if max_timestamp is not None else (1716388800000 + 300000)

    # Validate timestamp range
    if min_t > max_t:
        raise HTTPException(status_code=422, detail="minTimestamp must be <= maxTimestamp")

    # Cap maximum range to prevent DoS (max 1 hour = 3600000ms)
    if (max_t - min_t) > 3600000:
        max_t = min_t + 3600000

    snapshots = []
    # Step every 60 seconds (60000 ms)
    for t in range(min_t, max_t + 1, 60000):
        # Deterministic simulation values
        base_hash = abs(math.sin(t)) * 100
        confidence = 0.80 + (base_hash % 18) / 100
        ram_bytes = int(4.2 * 1024 * 1024 + (base_hash % 30) * 1024 * 102)
        cpu_fuel = int(65 + (base_hash % 30))
        snapshots.append(
            SnapshotItem(timestamp=t, tokenConfidence=confidence, ramBytesAllocated=ram_bytes, cpuFuelBurned=cpu_fuel)
        )

    return HistoryStateResponse(simulationId=simulation_id, snapshots=snapshots)


@router.post("/simulations/fork", response_model=ForkResponse)
async def spawn_simulation_fork(
    payload: ForkPayload,
    authorization: str | None = Header(None),  # Epic 8: JWT auth
) -> Any:
    """Initiate a timeline fork from an existing simulation."""
    logger.info(f"Initiating fork {payload.fork_name} from {payload.source_simulation_id}")

    # Epic 8: Input validation
    if not payload.source_simulation_id:
        raise HTTPException(status_code=422, detail="sourceSimulationId is required")

    if not payload.fork_name or len(payload.fork_name) > 128:
        raise HTTPException(status_code=422, detail="forkName must be 1-128 characters")

    if payload.branch_point_timestamp < 0:
        raise HTTPException(status_code=422, detail="branchPointTimestamp must be non-negative")

    # Sanitize fork name for ID generation
    safe_name = payload.fork_name.lower().replace("-", "_").replace(" ", "_")
    fork_id = f"sim_{safe_name}_{payload.branch_point_timestamp}"

    return ForkResponse(
        forkSimulationId=fork_id,
        sourceSimulationId=payload.source_simulation_id,
        branchPointTimestamp=payload.branch_point_timestamp,
        forkName=payload.fork_name,
        status="INITIATED",
    )
