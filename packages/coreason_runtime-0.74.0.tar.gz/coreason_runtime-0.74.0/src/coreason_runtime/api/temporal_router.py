# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from coreason_runtime.utils.logger import logger

temporal_router = APIRouter(prefix="/api/v1/temporal", tags=["Temporal Manifold"])


class RetractionIntent(BaseModel):
    node_id: str = Field(..., alias="nodeId")
    intent: str


async def get_temporal_client() -> Any:
    """Establish and return a connection to the Temporal cluster.

    This implements dependency inversion, allowing mock-free fake clients to be injected
    during test execution.
    """
    from temporalio.client import Client

    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    return await Client.connect(temporal_host)


@temporal_router.post("/retract")
async def retract_state(payload: RetractionIntent) -> dict[str, str]:
    """Execute a Defeasible Retraction via temporal edge invalidation.

    Args:
        payload: Retraction request containing nodeId and intent.

    Returns:
        Status indicating whether the retraction was dispatched.
    """
    try:
        from temporalio.client import Client

        temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
        _client = await Client.connect(temporal_host)

        # Here we would typically signal a specific workflow or execute an activity
        # to commit the retracted nodes to the ledger. Since workflow_id is not
        # provided in the payload, this represents a swarm-level retraction or
        # targets a singleton temporal orchestrator.
        # For phase 2, we just ensure the endpoint is mathematically bounded.

        logger.info(f"Retraction triggered for node {payload.node_id}")
        return {"status": "success", "message": "Retraction dispatched successfully"}
    except Exception as e:
        logger.exception(f"Temporal manifold retraction failed for node {payload.node_id}")
        raise HTTPException(status_code=500, detail=f"Failed to reach Temporal Orchestrator: {e!s}") from e


@temporal_router.get("/workflows/{workflow_id}/history")
async def retrieve_workflow_history(
    workflow_id: str,
    client: Any = Depends(get_temporal_client),  # noqa: B008
) -> dict[str, Any]:
    """Retrieve the complete serialized history event sequence for a given workflow.

    Args:
        workflow_id: The unique identifier of the target workflow.
        client: The injected Temporal Client connection.

    Returns:
        A dictionary containing the status and the serialized history events.
    """
    import temporalio.service

    try:
        handle = client.get_workflow_handle(workflow_id)
        history = await handle.fetch_history()
        return {"status": "success", "history": history.to_json_dict()}
    except temporalio.service.RPCError as rpc_err:
        logger.warning(f"Temporal RPC error retrieving history for {workflow_id}: {rpc_err}")
        raise HTTPException(
            status_code=404,
            detail=f"Workflow history not found for ID '{workflow_id}': {rpc_err.message}",
        ) from rpc_err
    except Exception as e:
        logger.exception(f"Unexpected error fetching Temporal history for {workflow_id}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal system failure retrieving history: {e!s}",
        ) from e
