# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Asynchronous Event Log Flusher using Polars (#332).

Buffers telemetry events in a thread-safe queue and periodically flushes
them to disk as Parquet files using Polars for columnar efficiency. This
prevents thread blocking during high-velocity telemetry spikes.

Also implements EU AI Act regulatory audit fields (#326).
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any

from coreason_runtime.utils.logger import logger

# Default flush configuration
DEFAULT_FLUSH_INTERVAL_SECONDS = 5.0
DEFAULT_MAX_BUFFER_SIZE = 10_000
DEFAULT_OUTPUT_DIR = "registry/telemetry"


class AsyncTelemetryFlusher:
    """Thread-safe, non-blocking telemetry flusher with Polars (#332, #326).

    Architecture:
    - Events are pushed into a thread-safe deque (lock-free on CPython)
    - A background asyncio task periodically flushes the buffer to Parquet
    - EU AI Act fields are automatically injected into each event (#326)
    - Flush is Polars-native for zero-copy columnar writes
    """

    def __init__(
        self,
        output_dir: str | None = None,
        flush_interval: float = DEFAULT_FLUSH_INTERVAL_SECONDS,
        max_buffer_size: int = DEFAULT_MAX_BUFFER_SIZE,
    ) -> None:
        output_dir_val = output_dir or os.getenv("COREASON_TELEMETRY_DIR") or DEFAULT_OUTPUT_DIR
        self._output_dir = Path(output_dir_val)
        self._flush_interval = flush_interval
        self._max_buffer_size = max_buffer_size
        self._buffer: deque[dict[str, Any]] = deque(maxlen=max_buffer_size)
        self._lock = threading.Lock()
        self._flush_task: asyncio.Task[None] | None = None
        self._running = False
        self._total_flushed = 0
        self._total_dropped = 0

    def record(self, event: dict[str, Any]) -> None:
        """Record a telemetry event into the buffer (thread-safe, non-blocking).

        Automatically injects EU AI Act regulatory audit fields (#326):
        - ingestion_timestamp: When the event was recorded
        - ai_act_traceability_id: Unique ID for regulatory tracing
        - ai_act_risk_class: Default HIGH for all generative events
        """
        import uuid

        enriched = {
            **event,
            "ingestion_timestamp": time.time(),
            "ai_act_traceability_id": str(uuid.uuid4()),
            "ai_act_risk_class": event.get("ai_act_risk_class", "HIGH"),
        }

        # EU AI Act §26 — mandatory fields for high-risk AI systems (#326)
        if "inference_seed" not in enriched:
            enriched["inference_seed"] = None
        if "temperature" not in enriched:
            enriched["temperature"] = None
        if "logit_mask_exclusions" not in enriched:
            enriched["logit_mask_exclusions"] = None
        if "context_free_grammar" not in enriched:
            enriched["context_free_grammar"] = None

        try:
            self._buffer.append(enriched)
        except Exception:
            self._total_dropped += 1

    async def start(self) -> None:
        """Start the background flush loop."""
        if self._running:
            return
        self._running = True
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._flush_task = asyncio.create_task(self._flush_loop())
        logger.info(f"Telemetry flusher started: interval={self._flush_interval}s, output={self._output_dir}")

    async def stop(self) -> None:
        """Stop the flusher and perform a final flush."""
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._flush_task
        # Final flush
        await self._flush_buffer()
        logger.info(f"Telemetry flusher stopped. Total flushed: {self._total_flushed}")

    async def _flush_loop(self) -> None:
        """Periodic flush loop."""
        while self._running:
            await asyncio.sleep(self._flush_interval)
            await self._flush_buffer()

    async def _flush_buffer(self) -> None:
        """Flush the buffer to a Parquet file using Polars."""
        if not self._buffer:
            return

        # Drain the buffer atomically
        events: list[dict[str, Any]] = []
        while self._buffer:
            try:
                events.append(self._buffer.popleft())
            except IndexError:
                break

        if not events:
            return

        # Write to Parquet using Polars (#332)
        try:
            import polars as pl

            df = pl.DataFrame(events)
            timestamp = int(time.time() * 1000)
            output_path = self._output_dir / f"telemetry_{timestamp}.parquet"
            df.write_parquet(str(output_path))
            self._total_flushed += len(events)
            logger.debug(f"Flushed {len(events)} telemetry events to {output_path}")

        except ImportError:
            # Fallback: write as JSON lines
            import json

            timestamp = int(time.time() * 1000)
            output_path = self._output_dir / f"telemetry_{timestamp}.jsonl"
            with open(output_path, "w", encoding="utf-8") as f:
                f.writelines(json.dumps(event, default=str) + "\n" for event in events)
            self._total_flushed += len(events)
            logger.debug(f"Flushed {len(events)} telemetry events to {output_path} (JSON fallback)")

        except Exception as e:
            logger.error(f"Telemetry flush failed: {e}")
            # Re-insert events at the front of the buffer
            for event in reversed(events):
                self._buffer.appendleft(event)

    @property
    def stats(self) -> dict[str, Any]:
        """Return flusher statistics."""
        return {
            "buffer_size": len(self._buffer),
            "max_buffer_size": self._max_buffer_size,
            "total_flushed": self._total_flushed,
            "total_dropped": self._total_dropped,
            "running": self._running,
            "output_dir": str(self._output_dir),
        }


# Singleton flusher
_FLUSHER: AsyncTelemetryFlusher | None = None


def get_telemetry_flusher() -> AsyncTelemetryFlusher:
    """Get or create the singleton telemetry flusher."""
    global _FLUSHER
    if _FLUSHER is None:
        _FLUSHER = AsyncTelemetryFlusher()
    return _FLUSHER
