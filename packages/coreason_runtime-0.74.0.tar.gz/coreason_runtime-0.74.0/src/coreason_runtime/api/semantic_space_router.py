# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Semantic Vector Space Router — Belief Constellation Coordinates (#375).

Exposes 3D semantic vector coordinates for belief clusters to support
the <SemanticConstellationMap /> frontend component.
"""

from __future__ import annotations

import hashlib
import math
from typing import Any

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

semantic_space_router = APIRouter(prefix="/api/v1/topology", tags=["Semantic Topology"])


# ────────────────────────────────────────────────────────────────────
# Pydantic Models
# ────────────────────────────────────────────────────────────────────


class SemanticNode(BaseModel):
    id: str
    label: str
    x: float = Field(..., ge=-1.0, le=1.0)
    y: float = Field(..., ge=-1.0, le=1.0)
    z: float = Field(..., ge=-1.0, le=1.0)
    group: str
    weight: float = Field(..., ge=0.0, le=1.0)


class SemanticEdge(BaseModel):
    source: str
    target: str
    strength: float = Field(..., ge=0.0, le=1.0)


class SemanticSpaceResponse(BaseModel):
    space_id: str = Field(..., alias="spaceId")
    nodes: list[SemanticNode]
    edges: list[SemanticEdge]

    class Config:
        populate_by_name = True


# ────────────────────────────────────────────────────────────────────
# Deterministic Coordinate Generation
# ────────────────────────────────────────────────────────────────────


def _hash_coordinate(node_id: str, axis: int) -> float:
    """Generate a deterministic coordinate in [-1.0, 1.0] from node ID and axis index."""
    h = int(hashlib.sha256(f"{node_id}:{axis}".encode()).hexdigest()[:8], 16)
    # Map to [-1.0, 1.0]
    return math.sin(h) * 0.95  # Scale to 0.95 to avoid exact boundary


# ────────────────────────────────────────────────────────────────────
# Default Belief Constellation
# ────────────────────────────────────────────────────────────────────

_DEFAULT_CONCEPTS = [
    ("concept_epistemic_alignment", "Epistemic Alignment", "alignment", 0.95),
    ("concept_variational_free_energy", "Variational Free Energy", "inference", 0.88),
    ("concept_markov_blanket", "Markov Blanket", "inference", 0.91),
    ("concept_active_inference", "Active Inference", "policy", 0.93),
    ("concept_bayesian_surprise", "Bayesian Surprise", "learning", 0.85),
    ("concept_counterfactual_depth", "Counterfactual Depth", "planning", 0.82),
    ("concept_epistemic_value", "Epistemic Value", "alignment", 0.89),
]

_DEFAULT_EDGES = [
    ("concept_epistemic_alignment", "concept_variational_free_energy", 0.75),
    ("concept_variational_free_energy", "concept_markov_blanket", 0.85),
    ("concept_markov_blanket", "concept_active_inference", 0.90),
    ("concept_active_inference", "concept_bayesian_surprise", 0.70),
    ("concept_bayesian_surprise", "concept_counterfactual_depth", 0.65),
    ("concept_epistemic_alignment", "concept_epistemic_value", 0.80),
    ("concept_epistemic_value", "concept_active_inference", 0.72),
]


def _build_default_space(space_id: str = "belief_constellation_main") -> SemanticSpaceResponse:
    """Build the default belief constellation with deterministic coordinates."""
    nodes = [
        SemanticNode(
            id=cid,
            label=label,
            x=_hash_coordinate(cid, 0),
            y=_hash_coordinate(cid, 1),
            z=_hash_coordinate(cid, 2),
            group=group,
            weight=weight,
        )
        for cid, label, group, weight in _DEFAULT_CONCEPTS
    ]

    edges = [
        SemanticEdge(source=src, target=tgt, strength=s)
        for src, tgt, s in _DEFAULT_EDGES
    ]

    return SemanticSpaceResponse(spaceId=space_id, nodes=nodes, edges=edges)


# ────────────────────────────────────────────────────────────────────
# Endpoint
# ────────────────────────────────────────────────────────────────────


@semantic_space_router.get("/semantic-space", response_model=SemanticSpaceResponse)
async def query_semantic_space(
    space_id: str | None = Query(None, alias="spaceId"),
) -> Any:
    """Query the semantic coordinate map of active belief clusters."""
    sid = space_id or "belief_constellation_main"
    return _build_default_space(sid)
