# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Telemetry Router — SSE streaming, speculative decoding metrics,
active inference VFE, and Arrow-native egress (#309, #322, #331, #346, #347).

Provides:
- /api/telemetry/stream — SSE event stream with per-subscriber load shedding
- /api/telemetry/inference/speculative — Speculative decoding Valid@1 metrics
- /api/telemetry/inference/active — Active inference VFE policy coordinates
- /api/telemetry/arrow — Apache Arrow IPC batch export of telemetry events
- /api/telemetry/broker/stats — Broker health and subscriber statistics
"""

from __future__ import annotations

import time
import uuid
from collections.abc import AsyncGenerator
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from coreason_runtime.api.telemetry_broker import (
    EventPriority,
    SSEEvent,
    encode_arrow_batch,
    get_telemetry_broker,
)

telemetry_router = APIRouter(prefix="/api/telemetry", tags=["Telemetry"])

# In-memory metrics accumulators (reset per collection cycle)
_speculative_metrics: list[dict[str, Any]] = []
_active_inference_metrics: list[dict[str, Any]] = []


@telemetry_router.get("/stream")
async def sse_telemetry_stream(request: Request) -> StreamingResponse:
    """Real-time SSE telemetry stream (#333, #340).

    Clients connect and receive a continuous stream of telemetry events
    in text/event-stream format. Per-subscriber load shedding drops
    verbose events when queue pressure exceeds the configured threshold.
    """
    broker = get_telemetry_broker()
    subscriber_id = f"sse-{uuid.uuid4().hex[:8]}"

    async def event_generator() -> AsyncGenerator[bytes]:
        async for event in broker.subscribe(subscriber_id):
            if await request.is_disconnected():
                broker.unsubscribe(subscriber_id)
                break
            yield event.to_sse_bytes()

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@telemetry_router.post("/inference/speculative")
async def record_speculative_metrics(
    request: Request,
) -> JSONResponse:
    """Record speculative decoding metrics (#322, #331).

    Accepts a JSON payload with speculative decoding telemetry:
    - draft_tokens: Number of tokens drafted by the speculative model
    - accepted_tokens: Number of tokens accepted by the target model
    - valid_at_1: Boolean indicating if the first draft token was accepted
    - draft_model_latency_ms: Latency of the speculative model
    - target_model_latency_ms: Latency of the target model verification
    - batch_size: Number of sequences in the batch
    """
    body = await request.json()

    metric = {
        "timestamp": time.time(),
        "draft_tokens": body.get("draft_tokens", 0),
        "accepted_tokens": body.get("accepted_tokens", 0),
        "valid_at_1": body.get("valid_at_1", False),
        "acceptance_rate": (body.get("accepted_tokens", 0) / max(body.get("draft_tokens", 1), 1)),
        "draft_model_latency_ms": body.get("draft_model_latency_ms", 0),
        "target_model_latency_ms": body.get("target_model_latency_ms", 0),
        "batch_size": body.get("batch_size", 1),
        "speedup_ratio": (body.get("target_model_latency_ms", 1) / max(body.get("draft_model_latency_ms", 1), 0.001)),
    }

    _speculative_metrics.append(metric)

    # Emit to SSE broker for real-time streaming (#346)
    broker = get_telemetry_broker()
    import json

    await broker.publish(
        SSEEvent(
            event_type="speculative_decoding",
            data=json.dumps(metric),
            priority=EventPriority.METRIC,
        )
    )

    return JSONResponse({"status": "recorded", "acceptance_rate": metric["acceptance_rate"]})


@telemetry_router.get("/inference/speculative")
async def get_speculative_metrics() -> JSONResponse:
    """Retrieve accumulated speculative decoding metrics (#322, #331).

    Returns aggregated statistics and the last N individual metrics.
    """
    if not _speculative_metrics:
        return JSONResponse({"metrics": [], "summary": {}})

    total = len(_speculative_metrics)
    valid_at_1_count = sum(1 for m in _speculative_metrics if m.get("valid_at_1"))
    avg_acceptance = sum(m["acceptance_rate"] for m in _speculative_metrics) / total

    summary = {
        "total_batches": total,
        "valid_at_1_rate": round(valid_at_1_count / total, 4),
        "avg_acceptance_rate": round(avg_acceptance, 4),
        "avg_speedup_ratio": round(sum(m["speedup_ratio"] for m in _speculative_metrics) / total, 2),
    }

    # Return last 100 metrics
    return JSONResponse({"metrics": _speculative_metrics[-100:], "summary": summary})


@telemetry_router.post("/inference/active")
async def record_active_inference_metrics(
    request: Request,
) -> JSONResponse:
    """Record active inference policy coordinates and VFE metrics (#347).

    Accepts a JSON payload with active inference telemetry:
    - variational_free_energy: Current VFE value
    - expected_free_energy: EFE for the selected policy
    - policy_coordinates: The selected policy vector
    - epistemic_value: Information gain component
    - pragmatic_value: Reward/goal component
    """
    body = await request.json()

    metric = {
        "timestamp": time.time(),
        "variational_free_energy": body.get("variational_free_energy", 0),
        "expected_free_energy": body.get("expected_free_energy", 0),
        "policy_coordinates": body.get("policy_coordinates", []),
        "epistemic_value": body.get("epistemic_value", 0),
        "pragmatic_value": body.get("pragmatic_value", 0),
        "agent_id": body.get("agent_id", "unknown"),
    }

    _active_inference_metrics.append(metric)

    broker = get_telemetry_broker()
    import json

    await broker.publish(
        SSEEvent(
            event_type="active_inference",
            data=json.dumps(metric),
            priority=EventPriority.METRIC,
        )
    )

    return JSONResponse({"status": "recorded"})


@telemetry_router.get("/inference/active")
async def get_active_inference_metrics() -> JSONResponse:
    """Retrieve active inference VFE metrics (#347)."""
    return JSONResponse({"metrics": _active_inference_metrics[-100:], "count": len(_active_inference_metrics)})


@telemetry_router.get("/arrow")
async def arrow_telemetry_export() -> StreamingResponse:
    """Export all accumulated telemetry as Apache Arrow IPC (#309).

    Returns a binary Apache Arrow IPC stream containing all speculative
    decoding and active inference metrics in columnar format.
    """
    all_events = _speculative_metrics + _active_inference_metrics
    arrow_bytes = encode_arrow_batch(all_events)

    return StreamingResponse(
        iter([arrow_bytes]),
        media_type="application/vnd.apache.arrow.stream",
        headers={"Content-Disposition": "attachment; filename=telemetry.arrow"},
    )


@telemetry_router.get("/broker/stats")
async def broker_stats() -> JSONResponse:
    """Return SSE broker health and subscriber statistics (#340)."""
    broker = get_telemetry_broker()
    return JSONResponse(broker.stats)
