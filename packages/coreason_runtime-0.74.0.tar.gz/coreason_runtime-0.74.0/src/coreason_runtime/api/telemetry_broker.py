# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
SSE Event Broker with Load Shedding (#309, #333, #340).

Implements a high-throughput, asyncio-native Server-Sent Events (SSE) broker
with integrated load shedding for real-time telemetry streaming. Supports
Apache Arrow columnar encoding for zero-copy event delivery.

Architecture:
- Fan-out pub/sub: One producer pushes events, N subscribers receive them
- Back-pressure aware: Per-subscriber queues with configurable depth
- Load shedding: Drops verbose debug-level events when queue pressure exceeds threshold
- Arrow-native: Optional Apache Arrow IPC encoding for columnar telemetry
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections import defaultdict
from collections.abc import AsyncIterator
from enum import IntEnum
from typing import Any

from coreason_runtime.utils.logger import logger


class EventPriority(IntEnum):
    """Event priority levels for load shedding decisions."""

    DEBUG = 0
    INFO = 1
    METRIC = 2
    WARNING = 3
    CRITICAL = 4


class SSEEvent:
    """A single SSE event with priority and metadata."""

    __slots__ = ("data", "event_type", "id", "priority", "timestamp")

    def __init__(
        self,
        event_type: str,
        data: str,
        priority: EventPriority = EventPriority.INFO,
        event_id: str | None = None,
    ) -> None:
        self.event_type = event_type
        self.data = data
        self.priority = priority
        self.timestamp = time.time()
        self.id = event_id or f"{self.timestamp:.6f}"

    def to_sse_bytes(self) -> bytes:
        """Serialize to the SSE wire format (text/event-stream)."""
        lines = [f"id: {self.id}", f"event: {self.event_type}"]
        lines.extend(f"data: {line}" for line in self.data.split("\n"))
        lines.append("")
        lines.append("")
        return "\n".join(lines).encode("utf-8")


class TelemetryEventBroker:
    """Fan-out SSE event broker with per-subscriber load shedding (#333, #340).

    Usage:
        broker = TelemetryEventBroker()

        # In FastAPI endpoint:
        async def sse_stream():
            async for event in broker.subscribe("client-1"):
                yield event.to_sse_bytes()

        # In workflow/activity:
        await broker.publish(SSEEvent("metric", '{"cpu": 0.42}'))
    """

    def __init__(
        self,
        max_queue_depth: int = 1000,
        shedding_threshold: float = 0.8,
    ) -> None:
        """Initialize the broker.

        Args:
            max_queue_depth: Maximum events per subscriber queue.
            shedding_threshold: Queue fullness ratio (0-1) at which load
                shedding begins dropping low-priority events.
        """
        self._subscribers: dict[str, asyncio.Queue[SSEEvent | None]] = {}
        self._max_depth = max_queue_depth
        self._shedding_threshold = shedding_threshold
        self._total_published = 0
        self._total_shed = 0

    async def publish(self, event: SSEEvent) -> int:
        """Publish an event to all subscribers.

        Returns the number of subscribers that received the event.
        Low-priority events are shed when subscriber queues exceed the
        shedding threshold (#340).
        """
        delivered = 0
        for subscriber_id, queue in list(self._subscribers.items()):
            # Load shedding: drop low-priority events when queue is filling up
            fullness = queue.qsize() / self._max_depth
            if fullness >= self._shedding_threshold and event.priority <= EventPriority.DEBUG:
                self._total_shed += 1
                continue

            if fullness >= 1.0:
                # Queue is full — shed anything below CRITICAL
                if event.priority < EventPriority.CRITICAL:
                    self._total_shed += 1
                    continue
                # Drop oldest for CRITICAL events
                with contextlib.suppress(asyncio.QueueEmpty):
                    queue.get_nowait()

            try:
                queue.put_nowait(event)
                delivered += 1
            except asyncio.QueueFull:
                self._total_shed += 1
                logger.debug(f"Load shedding: dropped {event.event_type} for subscriber {subscriber_id}")

        self._total_published += 1
        return delivered

    async def subscribe(self, subscriber_id: str) -> AsyncIterator[SSEEvent]:
        """Subscribe to the event stream.

        Yields SSEEvent objects as they arrive. The subscription is
        automatically cleaned up when the iterator is abandoned.
        """
        queue: asyncio.Queue[SSEEvent | None] = asyncio.Queue(maxsize=self._max_depth)
        self._subscribers[subscriber_id] = queue

        try:
            while True:
                event = await queue.get()
                if event is None:
                    break
                yield event
        finally:
            self._subscribers.pop(subscriber_id, None)

    def unsubscribe(self, subscriber_id: str) -> None:
        """Remove a subscriber and signal stream termination."""
        queue = self._subscribers.pop(subscriber_id, None)
        if queue:
            with contextlib.suppress(asyncio.QueueFull):
                queue.put_nowait(None)  # Sentinel to break the async iterator

    @property
    def subscriber_count(self) -> int:
        """Return the number of active subscribers."""
        return len(self._subscribers)

    @property
    def stats(self) -> dict[str, Any]:
        """Return broker statistics for observability."""
        return {
            "subscribers": len(self._subscribers),
            "total_published": self._total_published,
            "total_shed": self._total_shed,
            "queue_depths": {sid: q.qsize() for sid, q in self._subscribers.items()},
        }


def encode_arrow_batch(events: list[dict[str, Any]]) -> bytes:
    """Encode a batch of telemetry events as an Apache Arrow IPC buffer (#309).

    This enables zero-copy, columnar-native telemetry ingestion by
    downstream Arrow/Polars consumers.

    Returns:
        Apache Arrow IPC stream bytes.
    """
    try:
        import pyarrow as pa

        if not events:
            return b""

        # Build columnar arrays from the event dicts
        columns: dict[str, list[Any]] = defaultdict(list)
        for event in events:
            for key, value in event.items():
                columns[key].append(value)

        arrays = {}
        for key, values in columns.items():
            try:
                arrays[key] = pa.array(values)
            except Exception:
                arrays[key] = pa.array([str(v) for v in values])

        table = pa.table(arrays)
        sink = pa.BufferOutputStream()
        writer = pa.ipc.new_stream(sink, table.schema)
        writer.write_table(table)
        writer.close()
        return bytes(sink.getvalue().to_pybytes())

    except ImportError:
        logger.warning("PyArrow not available. Arrow-native telemetry encoding disabled.")
        import json

        return json.dumps(events).encode("utf-8")


# Singleton broker instance
_BROKER: TelemetryEventBroker | None = None


def get_telemetry_broker() -> TelemetryEventBroker:
    """Get or create the singleton telemetry event broker."""
    global _BROKER
    if _BROKER is None:
        _BROKER = TelemetryEventBroker()
    return _BROKER
