# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import hashlib
import time
import typing

import networkx as nx
from coreason_manifest.spec.ontology import (
    OntologicalVocabularyLookupIntent,
    OntologicalVocabularyLookupReceipt,
)

from coreason_runtime.orchestration.solvers.ontological_vocabulary_solver import (
    OntologicalVocabularySolver,
)


class LocalRuntimeSimulator:
    """A local simulator representing plane execution dynamics for intents and DAGs."""

    def __init__(self, db_path: str | None = None):
        self._db_path = db_path
        self._solver = OntologicalVocabularySolver(db_path) if db_path else None
        self._handlers: dict[str, typing.Callable[[typing.Any], typing.Any]] = {
            OntologicalVocabularyLookupIntent.__name__: self._resolve_vocabulary_lookup_intent
        }

    def evaluate_intent(self, intent: typing.Any) -> typing.Any:
        """Evaluates a single intent payload using the registered capability handlers."""
        intent_type = type(intent).__name__
        handler = self._handlers.get(intent_type)
        if not handler:
            msg = f"No handler registered for intent type: {intent_type}"
            raise ValueError(msg)
        return handler(intent)

    def evaluate_intent_dag(self, intents_sequence: typing.Sequence[typing.Any]) -> typing.Sequence[typing.Any]:
        """Topologically sorts and evaluates a sequence of intents representing a DAG."""
        intent_map = {}
        for intent in intents_sequence:
            cid = getattr(intent, "event_cid", None)
            if not cid:
                cid = hashlib.sha256(str(id(intent)).encode("utf-8")).hexdigest()
            intent_map[cid] = intent

        cids_set = set(intent_map.keys())

        graph = nx.DiGraph()
        for cid in cids_set:
            graph.add_node(cid)

        for cid, intent in intent_map.items():
            referenced = self._extract_referenced_identifiers(intent, cids_set)
            for ref_cid in referenced:
                if ref_cid != cid:
                    graph.add_edge(ref_cid, cid)

        try:
            sorted_cids = list(nx.topological_sort(graph))
        except nx.NetworkXUnfeasible as err:
            msg = "Intent sequence has cyclic dependencies."
            raise ValueError(msg) from err

        receipts = []
        for cid in sorted_cids:
            intent = intent_map[cid]
            receipt = self.evaluate_intent(intent)
            receipts.append(receipt)

        return receipts

    def _extract_referenced_identifiers(self, value: typing.Any, cids: set[str]) -> set[str]:
        """Helper to extract referenced CIDs recursively from an intent model."""
        referenced = set()
        if isinstance(value, str):
            if value in cids:
                referenced.add(value)
        elif isinstance(value, dict):
            for v in value.values():
                referenced.update(self._extract_referenced_identifiers(v, cids))
        elif isinstance(value, (list, tuple, set)):
            for item in value:
                referenced.update(self._extract_referenced_identifiers(item, cids))
        elif hasattr(value, "__dict__"):
            for v in value.__dict__.values():
                referenced.update(self._extract_referenced_identifiers(v, cids))
        elif hasattr(value, "model_fields"):
            for field_name in value.model_fields:
                field_val = getattr(value, field_name, None)
                referenced.update(self._extract_referenced_identifiers(field_val, cids))
        return referenced

    def _resolve_vocabulary_lookup_intent(
        self, intent: OntologicalVocabularyLookupIntent
    ) -> OntologicalVocabularyLookupReceipt:
        """Resolves OntologicalVocabularyLookupIntent using OntologicalVocabularySolver."""
        start_time = time.perf_counter()

        if self._solver:
            results = list(
                self._solver.resolve_vocabulary_mappings(
                    query_term=intent.query_term,
                    target_domains=intent.target_domains,
                    max_results=intent.max_results,
                )
            )
        else:
            from coreason_manifest.spec.ontology import ClinicalVocabularyMappingState

            results = [
                ClinicalVocabularyMappingState(
                    source_code=intent.query_term,
                    source_vocabulary="SNOMED",
                    target_concept_id=12345,
                    target_concept_name="Mocked Clinical Term",
                    domain_id="Condition",
                    mapping_status="APPROVED",
                    confidence_score=1.0,
                )
            ]

        duration_ms = (time.perf_counter() - start_time) * 1000.0

        intent_cid = getattr(intent, "event_cid", None)
        if not intent_cid:
            intent_cid = hashlib.sha256(intent.query_term.encode("utf-8")).hexdigest()

        return OntologicalVocabularyLookupReceipt(
            lookup_intent_cid=intent_cid,
            results=results,
            duration_ms=duration_ms,
        )
