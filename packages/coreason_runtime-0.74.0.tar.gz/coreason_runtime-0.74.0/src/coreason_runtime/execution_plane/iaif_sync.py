# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Intermittent Active Inference Sync Protocol (IAIF) (#335).

Maintains free energy estimates across intermittent network connections
and reconciles priors when agents reconnect. Uses Bayesian belief
merging for distributed active inference.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class AgentBelief:
    """An agent's posterior belief distribution."""

    agent_id: str
    posterior: list[float]
    free_energy: float
    last_sync_timestamp: float = field(default_factory=time.time)
    staleness_seconds: float = 0.0


class IAIFSyncManager:
    """Intermittent Active Inference Sync manager (#335).

    Manages belief synchronization across agents that may have
    intermittent network connectivity. Uses Bayesian belief merging
    to reconcile posteriors when agents reconnect.
    """

    def __init__(self, staleness_decay: float = 0.01) -> None:
        self._beliefs: dict[str, AgentBelief] = {}
        self._staleness_decay = staleness_decay
        self._sync_history: list[dict[str, Any]] = []

    def update_belief(
        self,
        agent_id: str,
        posterior: list[float],
        free_energy: float,
    ) -> AgentBelief:
        """Record an agent's latest posterior belief."""
        belief = AgentBelief(
            agent_id=agent_id,
            posterior=posterior,
            free_energy=free_energy,
        )
        self._beliefs[agent_id] = belief
        return belief

    def merge_beliefs(
        self,
        local_posterior: list[float],
        remote_posterior: list[float],
        local_weight: float = 0.5,
    ) -> list[float]:
        """Merge two posteriors using weighted Bayesian combination.

        The merged posterior is a weighted geometric mean, normalized
        to form a valid probability distribution.
        """
        if len(local_posterior) != len(remote_posterior):
            raise ValueError("Posteriors must have the same dimensionality")

        remote_weight = 1.0 - local_weight

        # Log-linear combination (geometric mean in probability space)
        log_merged = [
            local_weight * math.log(lp + 1e-10) + remote_weight * math.log(rp + 1e-10)
            for lp, rp in zip(local_posterior, remote_posterior, strict=False)
        ]

        # Normalize via log-sum-exp
        max_log = max(log_merged)
        merged = [math.exp(lm - max_log) for lm in log_merged]
        total = sum(merged)
        return [m / total for m in merged]

    def compute_sync_priority(
        self,
        divergence: float,
        staleness_seconds: float,
    ) -> float:
        """Compute sync priority for an agent.

        Higher priority = should sync sooner. Combines belief divergence
        (how different the agent's beliefs are) with staleness (how long
        since last sync).
        """
        staleness_weight = 1.0 - math.exp(-self._staleness_decay * staleness_seconds)
        return divergence * 0.6 + staleness_weight * 0.4

    def reconcile_priors(self) -> dict[str, list[float]]:
        """Reconcile all agent priors to a consensus distribution.

        Returns the reconciled posterior for each agent.
        """
        if len(self._beliefs) < 2:
            return {agent_id: belief.posterior for agent_id, belief in self._beliefs.items()}

        # Compute the global consensus via iterative merging
        agent_ids = list(self._beliefs.keys())
        consensus = self._beliefs[agent_ids[0]].posterior[:]

        for agent_id in agent_ids[1:]:
            remote = self._beliefs[agent_id].posterior
            now = time.time()
            staleness = now - self._beliefs[agent_id].last_sync_timestamp

            # Weight newer beliefs more heavily
            local_weight = 0.5 + 0.3 * math.exp(-self._staleness_decay * staleness)
            consensus = self.merge_beliefs(consensus, remote, local_weight)

        # Update all agents with reconciled consensus
        reconciled: dict[str, list[float]] = {}
        for agent_id in agent_ids:
            reconciled[agent_id] = consensus[:]
            self._beliefs[agent_id].last_sync_timestamp = time.time()

        self._sync_history.append(
            {
                "timestamp": time.time(),
                "agents_reconciled": agent_ids,
                "consensus_entropy": -sum(p * math.log(p + 1e-10) for p in consensus),
            }
        )

        logger.info(f"IAIF: Reconciled {len(agent_ids)} agent priors")
        return reconciled

    @property
    def stats(self) -> dict[str, Any]:
        """Return sync statistics."""
        return {
            "active_agents": len(self._beliefs),
            "total_syncs": len(self._sync_history),
            "beliefs": {
                agent_id: {
                    "free_energy": b.free_energy,
                    "staleness_s": time.time() - b.last_sync_timestamp,
                }
                for agent_id, b in self._beliefs.items()
            },
        }
