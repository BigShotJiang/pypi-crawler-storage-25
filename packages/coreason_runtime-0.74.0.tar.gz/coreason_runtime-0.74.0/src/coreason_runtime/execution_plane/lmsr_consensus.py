# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
LMSR Consensus Engine (#306, #325, #337, #349).

Implements Hanson's Logarithmic Market Scoring Rule for multi-agent
prediction market consensus, dialectic debate rounds, and divergence
metrics for the CoReason adversarial market workflow.
"""

from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class MarketOutcome:
    """A single outcome in the prediction market."""

    outcome_id: str
    label: str
    shares: float = 0.0


@dataclass
class LMSRMarketMaker:
    """Hanson's Logarithmic Market Scoring Rule implementation (#306).

    The LMSR provides a bounded-loss automated market maker for
    multi-agent consensus aggregation. The liquidity parameter `b`
    controls the market's sensitivity to trades.
    """

    outcomes: list[MarketOutcome] = field(default_factory=list)
    b: float = 100.0  # Liquidity parameter
    price_history: list[dict[str, Any]] = field(default_factory=list)

    def cost_function(self, quantities: list[float]) -> float:
        """Compute the cost function C(q) = b * ln(sum(exp(q_i / b)))."""
        max_q = max(quantities) if quantities else 0
        scaled = [math.exp((q - max_q) / self.b) for q in quantities]
        return self.b * (max_q / self.b + math.log(sum(scaled)))

    def price(self, outcome_idx: int) -> float:
        """Compute the instantaneous price for an outcome.

        price_i = exp(q_i / b) / sum(exp(q_j / b))
        """
        quantities = [o.shares for o in self.outcomes]
        if not quantities:
            return 0.0
        max_q = max(quantities)
        exp_vals = [math.exp((q - max_q) / self.b) for q in quantities]
        total = sum(exp_vals)
        return exp_vals[outcome_idx] / total if total > 0 else 0.0

    def buy(self, outcome_idx: int, shares: float) -> float:
        """Buy shares for an outcome. Returns the cost of the trade."""
        quantities_before = [o.shares for o in self.outcomes]
        cost_before = self.cost_function(quantities_before)

        self.outcomes[outcome_idx].shares += shares
        quantities_after = [o.shares for o in self.outcomes]
        cost_after = self.cost_function(quantities_after)

        trade_cost = cost_after - cost_before

        # Record price history for telemetry
        self.price_history.append(
            {
                "timestamp": time.time(),
                "outcome_idx": outcome_idx,
                "shares": shares,
                "cost": trade_cost,
                "prices": [self.price(i) for i in range(len(self.outcomes))],
            }
        )

        return trade_cost

    def entropy(self) -> float:
        """Compute the Shannon entropy of the current market prices."""
        prices = [self.price(i) for i in range(len(self.outcomes))]
        return -sum(p * math.log(p + 1e-10) for p in prices)


@dataclass
class DebateArgument:
    """A single argument in a dialectic debate round."""

    agent_id: str
    position: str
    evidence: list[str] = field(default_factory=list)
    confidence: float = 0.5
    timestamp: float = field(default_factory=time.time)
    argument_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])


class DialecticDebateRound:
    """Structured multi-agent debate for consensus building (#325, #349).

    Agents submit arguments with evidence and confidence. The debate
    scorer evaluates argument strength and resolves consensus via
    the LMSR market mechanism.
    """

    def __init__(self, topic: str, b: float = 100.0) -> None:
        self.topic = topic
        self.arguments: list[DebateArgument] = []
        self.market = LMSRMarketMaker(b=b)
        self.round_id = uuid.uuid4().hex[:12]

    def submit_argument(
        self,
        agent_id: str,
        position: str,
        evidence: list[str] | None = None,
        confidence: float = 0.5,
    ) -> DebateArgument:
        """Submit an argument to the debate round."""
        arg = DebateArgument(
            agent_id=agent_id,
            position=position,
            evidence=evidence or [],
            confidence=confidence,
        )
        self.arguments.append(arg)

        # Ensure market has an outcome for this position
        position_idx = None
        for i, outcome in enumerate(self.market.outcomes):
            if outcome.label == position:
                position_idx = i
                break

        if position_idx is None:
            position_idx = len(self.market.outcomes)
            self.market.outcomes.append(MarketOutcome(outcome_id=arg.argument_id, label=position))

        # Trade confidence as shares
        self.market.buy(position_idx, confidence * 10)

        logger.debug(f"Debate {self.round_id}: Agent {agent_id} submitted '{position}' with confidence {confidence}")
        return arg

    def score_arguments(self) -> list[dict[str, Any]]:
        """Score all arguments based on evidence strength and market prices."""
        scores = []
        for arg in self.arguments:
            position_idx = next(
                (i for i, o in enumerate(self.market.outcomes) if o.label == arg.position),
                None,
            )
            market_price = self.market.price(position_idx) if position_idx is not None else 0.0
            evidence_weight = len(arg.evidence) * 0.1
            score = (arg.confidence * 0.4) + (market_price * 0.4) + (evidence_weight * 0.2)
            scores.append(
                {
                    "argument_id": arg.argument_id,
                    "agent_id": arg.agent_id,
                    "position": arg.position,
                    "score": round(score, 4),
                    "market_price": round(market_price, 4),
                }
            )
        return sorted(scores, key=lambda x: x["score"], reverse=True)

    def resolve_consensus(self) -> dict[str, Any]:
        """Resolve the debate to a consensus position."""
        scores = self.score_arguments()
        if not scores:
            return {"consensus": None, "confidence": 0.0}

        winning = scores[0]
        return {
            "consensus_position": winning["position"],
            "consensus_confidence": winning["score"],
            "market_entropy": self.market.entropy(),
            "total_arguments": len(self.arguments),
            "price_history": self.market.price_history,
        }


class ConsensusMetrics:
    """Multi-agent consensus divergence metrics (#337)."""

    @staticmethod
    def kl_divergence(p: list[float], q: list[float]) -> float:
        """Compute KL(P || Q) divergence."""
        return sum(pi * math.log((pi + 1e-10) / (qi + 1e-10)) for pi, qi in zip(p, q, strict=False))

    @staticmethod
    def jensen_shannon_divergence(beliefs: list[list[float]]) -> float:
        """Compute pairwise Jensen-Shannon divergence across agent beliefs."""
        if len(beliefs) < 2:
            return 0.0

        n = len(beliefs)
        # Compute mean distribution
        m = [sum(b[i] for b in beliefs) / n for i in range(len(beliefs[0]))]

        # JSD = average KL divergence from mean
        total_kl = sum(ConsensusMetrics.kl_divergence(b, m) for b in beliefs)
        return total_kl / n

    @staticmethod
    def entropy(distribution: list[float]) -> float:
        """Compute Shannon entropy H(P)."""
        return -sum(p * math.log(p + 1e-10) for p in distribution)

    @staticmethod
    def consensus_score(agent_beliefs: dict[str, list[float]]) -> dict[str, Any]:
        """Compute overall consensus score across agents."""
        beliefs = list(agent_beliefs.values())
        jsd = ConsensusMetrics.jensen_shannon_divergence(beliefs)
        avg_entropy = sum(ConsensusMetrics.entropy(b) for b in beliefs) / len(beliefs)

        return {
            "jensen_shannon_divergence": round(jsd, 6),
            "average_entropy": round(avg_entropy, 6),
            "consensus_strength": round(1.0 - min(jsd, 1.0), 4),
            "num_agents": len(agent_beliefs),
        }
