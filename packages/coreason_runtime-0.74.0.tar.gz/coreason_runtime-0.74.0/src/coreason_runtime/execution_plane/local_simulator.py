# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
LocalRuntimeSimulator — Fractal URN Stitching and DAG Verification (#329).

Provides local dry-run simulation of execution DAGs and fractal URN
hierarchical binding for capability composition.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class SimulationNode:
    """A node in the simulated execution DAG."""

    node_id: str
    node_type: str
    inputs: dict[str, Any] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)
    dependencies: list[str] = field(default_factory=list)
    status: str = "PENDING"


@dataclass
class SimulationResult:
    """Result of a DAG simulation."""

    success: bool
    executed_nodes: list[str]
    failed_nodes: list[str]
    execution_order: list[str]
    total_time_ms: float


class LocalRuntimeSimulator:
    """Local dry-run simulator for execution DAGs (#329)."""

    @staticmethod
    def verify_dag_integrity(
        dag: dict[str, SimulationNode],
    ) -> dict[str, Any]:
        """Verify a DAG has no cycles or dangling references.

        Returns a validation report.
        """
        dangling: list[str] = []
        for node_id, node in dag.items():
            dangling.extend(f"{node_id} → {dep}" for dep in node.dependencies if dep not in dag)

        # Cycle detection via topological sort (Kahn's algorithm)
        in_degree: dict[str, int] = dict.fromkeys(dag, 0)
        for node_id, node in dag.items():
            for dep in node.dependencies:
                if dep in in_degree:
                    in_degree[node_id] = in_degree.get(node_id, 0)

        # Build adjacency for Kahn's
        adj: dict[str, list[str]] = {node_id: [] for node_id in dag}
        for node_id, node in dag.items():
            for dep in node.dependencies:
                if dep in adj:
                    adj[dep].append(node_id)
                    in_degree[node_id] += 1

        queue: deque[str] = deque(node_id for node_id, degree in in_degree.items() if degree == 0)
        sorted_order: list[str] = []

        while queue:
            node_id = queue.popleft()
            sorted_order.append(node_id)
            for neighbor in adj.get(node_id, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        has_cycle = len(sorted_order) != len(dag)

        return {
            "valid": not has_cycle and not dangling,
            "has_cycle": has_cycle,
            "dangling_references": dangling,
            "topological_order": sorted_order if not has_cycle else [],
            "node_count": len(dag),
        }

    @staticmethod
    def simulate_execution(
        dag: dict[str, SimulationNode],
        inputs: dict[str, Any] | None = None,  # noqa: ARG004
    ) -> SimulationResult:
        """Simulate DAG execution in topological order (dry-run)."""
        import time

        start = time.perf_counter()

        integrity = LocalRuntimeSimulator.verify_dag_integrity(dag)
        if not integrity["valid"]:
            return SimulationResult(
                success=False,
                executed_nodes=[],
                failed_nodes=list(dag.keys()),
                execution_order=[],
                total_time_ms=0,
            )

        executed: list[str] = []
        failed: list[str] = []

        for node_id in integrity["topological_order"]:
            node = dag[node_id]
            try:
                node.status = "RUNNING"
                # Simulate: check dependencies are completed
                deps_met = all(dag[dep].status == "COMPLETED" for dep in node.dependencies if dep in dag)
                if deps_met:
                    node.status = "COMPLETED"
                    executed.append(node_id)
                else:
                    node.status = "BLOCKED"
                    failed.append(node_id)
            except Exception as e:
                node.status = "FAILED"
                failed.append(node_id)
                logger.warning(f"Simulation failure at {node_id}: {e}")

        elapsed = (time.perf_counter() - start) * 1000

        return SimulationResult(
            success=len(failed) == 0,
            executed_nodes=executed,
            failed_nodes=failed,
            execution_order=integrity["topological_order"],
            total_time_ms=round(elapsed, 2),
        )

    @staticmethod
    def stitch_fractal_urns(
        parent_urn: str,
        child_urns: list[str],
    ) -> dict[str, str]:
        """Create hierarchical URN bindings for fractal composition.

        Maps child URNs under a parent namespace, creating a fractal
        capability hierarchy.
        """
        bindings: dict[str, str] = {}
        for _i, child_urn in enumerate(child_urns):
            # Extract the leaf segment from the child URN
            leaf = child_urn.split(":")[-1] if ":" in child_urn else child_urn
            fractal_urn = f"{parent_urn}:{leaf}"
            bindings[child_urn] = fractal_urn

        logger.debug(f"Stitched {len(child_urns)} URNs under {parent_urn}")
        return bindings
