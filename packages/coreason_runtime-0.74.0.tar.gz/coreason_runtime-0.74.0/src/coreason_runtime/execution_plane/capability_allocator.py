# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import hashlib
import os
import secrets
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

import extism  # type: ignore[import-untyped]
from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent  # type: ignore[import-untyped]

from coreason_runtime.execution_plane.blob_store import UniversalBlobStore
from coreason_runtime.execution_plane.io_broker import IOBroker
from coreason_runtime.utils.exceptions import IntegrityViolationError

try:
    from coreason_manifest.utils.algebra import compute_merkle_directory_cid
except ImportError:
    # Fallback for environments where coreason-manifest is not yet updated.
    # This is a verbatim copy of the canonical implementation from coreason-manifest.
    def _is_text_bytes(data: bytes) -> bool:
        """Check if the bytes contain no null bytes and decode cleanly to UTF-8."""
        if b"\x00" in data:
            return False
        try:
            data.decode("utf-8")
            return True
        except UnicodeDecodeError:
            return False

    def compute_merkle_directory_cid(file_contents: dict[str, bytes]) -> str:  # type: ignore[misc]
        """Merkle-style SHA-256 CID (local fallback)."""
        file_hashes: list[str] = []
        for filename in sorted(file_contents.keys()):
            content = file_contents[filename]
            if _is_text_bytes(content):
                content = content.replace(b"\r\n", b"\n")
            file_hash = hashlib.sha256(content).hexdigest()
            file_hashes.append(f"{filename}:{file_hash}")
        merkle_input = "\n".join(file_hashes).encode("utf-8")
        return f"sha256:{hashlib.sha256(merkle_input).hexdigest()}"


if TYPE_CHECKING:
    from coreason_manifest import CognitiveActionSpaceManifest


def verify_bundle_integrity(bundle_files: dict[str, bytes], expected_hash: str | None) -> bool:
    """Zero-trust Merkle verification: recompute the CID and compare to the registry.

    Delegates the Merkle hash to ``compute_merkle_directory_cid()`` from the
    shared kernel (``coreason-manifest``) — the single canonical implementation
    used across the entire CoReason ecosystem.

    If the expected_hash is None or empty (e.g. DRAFT capabilities that have not
    yet been compiled), verification is skipped and the function returns True.

    Args:
        bundle_files: Mapping of canonical filenames to their raw bytes.
            Expected keys: ``__init__.py``, ``manifest.yaml``, ``schema.py``, ``server.py``.
            For ``manifest.yaml``, pass the bytes with ``cryptographic_hash``
            set to null (matching the compilation-side zeroing).
        expected_hash: The sha256-prefixed hex digest from the compiled registry.

    Returns:
        True if verification passes.

    Raises:
        IntegrityViolationError: If the computed hash does not match the expected hash.
    """
    if not expected_hash:
        return True  # DRAFT capabilities skip verification

    actual = compute_merkle_directory_cid(bundle_files)

    if actual != expected_hash:
        raise IntegrityViolationError(
            f"Bundle CID mismatch. Expected {expected_hash}, got {actual}. Possible supply-chain attack or stale cache."
        )
    return True


def _initialize_wasmtime_cache() -> None:
    """Natively enable Wasmtime JIT compilation caching by initializing Wasmtime's native cache config."""
    cache_path = Path.home() / ".cache" / "wasmtime" / "config.toml"
    success = False
    try:
        if not cache_path.exists():
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            config_content = (
                f'[cache]\nenabled = true\ndirectory = "{str(cache_path.parent / "cache").replace("\\", "/")}"\n'
            )
            cache_path.write_text(config_content, encoding="utf-8")
        success = cache_path.exists()
    except Exception:  # noqa: S110 # nosec B110
        pass

    if not success:
        try:
            fallback_path = Path(tempfile.gettempdir()) / "wasmtime_config.toml"
            if not fallback_path.exists():
                fallback_path.write_text("[cache]\nenabled = true\n", encoding="utf-8")
            cache_path = fallback_path
            success = cache_path.exists()
        except Exception:  # noqa: S110 # nosec B110
            pass

    if success:
        os.environ["WASMTIME_CACHE"] = str(cache_path)
    else:
        os.environ.pop("WASMTIME_CACHE", None)


_initialize_wasmtime_cache()


class ExtismRunner:
    """Hardened WASM sandbox runner with CPU fuel metering (#305, #334, #350).

    Enforces:
    - Memory limits: MAX_ALLOCATION_BYTES (10MB) via WASM page limits
    - CPU fuel: Configurable instruction fuel budget per invocation
    - Telemetry: Emits fuel/memory utilization metrics after each call
    """

    _cache: ClassVar[dict[str, extism.Plugin]] = {}

    # 10 MB = 10,485,760 bytes; each WASM page is 64KB (65,536 bytes)
    MAX_ALLOCATION_BYTES: ClassVar[int] = 10_485_760
    WASM_PAGE_SIZE: ClassVar[int] = 65_536
    DEFAULT_CPU_FUEL: ClassVar[int] = 1_000_000  # 1M instructions
    DEFAULT_TIMEOUT_MS: ClassVar[int] = 5_000

    @classmethod
    def get_plugin(cls, wasm_bytes: bytes, expected_hash: str) -> extism.Plugin:
        """Load a WASM plugin with zero-trust attestation and resource limits.

        Memory is capped at MAX_ALLOCATION_BYTES (10MB), CPU fuel is set to
        DEFAULT_CPU_FUEL instructions. WASI is disabled by default.
        """
        # Verify cryptographically before loading (constant time comparison)
        actual_hash = hashlib.sha256(wasm_bytes).hexdigest()
        if not secrets.compare_digest(actual_hash, expected_hash):
            raise TopologicalSeveranceEvent("WASM binary hash mismatch: zero-trust attestation failed.")

        # Cache loaded plugins to keep execution contexts warm
        if actual_hash not in cls._cache:
            # Calculate max pages from allocation budget (#305)
            max_pages = cls.MAX_ALLOCATION_BYTES // cls.WASM_PAGE_SIZE

            # SOTA 2026 Sandbox: Disable WASI capabilities unless explicitly allowed
            manifest = {
                "wasm": [{"data": wasm_bytes}],
                "memory": {"max_pages": max_pages},
                "timeout_ms": cls.DEFAULT_TIMEOUT_MS,
            }
            plugin = extism.Plugin(manifest, wasi=False)

            # Enable CPU fuel metering if the runtime supports it (#334)
            if hasattr(plugin, "set_fuel"):
                plugin.set_fuel(cls.DEFAULT_CPU_FUEL)

            cls._cache[actual_hash] = plugin
        return cls._cache[actual_hash]

    @classmethod
    def call_with_telemetry(
        cls,
        wasm_bytes: bytes,
        expected_hash: str,
        function_name: str,
        input_data: bytes,
        fuel_budget: int | None = None,
    ) -> tuple[bytes, dict[str, Any]]:
        """Execute a WASM function with full telemetry collection (#334, #350).

        Returns:
            Tuple of (output_bytes, telemetry_dict) where telemetry contains:
            - fuel_consumed: Instructions consumed during execution
            - fuel_remaining: Instructions remaining after execution
            - memory_pages_used: WASM linear memory pages allocated
            - memory_bytes_used: Estimated memory usage in bytes
            - execution_time_ms: Wall-clock execution time
        """
        import time

        plugin = cls.get_plugin(wasm_bytes, expected_hash)

        # Set fuel budget for this invocation
        budget = fuel_budget or cls.DEFAULT_CPU_FUEL
        if hasattr(plugin, "set_fuel"):
            plugin.set_fuel(budget)

        start_time = time.perf_counter()
        try:
            output = plugin.call(function_name, input_data)
        except Exception as e:
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            telemetry = {
                "fuel_consumed": budget,
                "fuel_remaining": 0,
                "memory_pages_used": 0,
                "memory_bytes_used": 0,
                "execution_time_ms": round(elapsed_ms, 2),
                "status": "FUEL_EXHAUSTED" if "fuel" in str(e).lower() else "ERROR",
                "error": str(e),
            }
            raise RuntimeError(f"WASM execution failed: {e}. Telemetry: {telemetry}") from e

        elapsed_ms = (time.perf_counter() - start_time) * 1000

        # Collect fuel telemetry (#334, #350)
        fuel_remaining = 0
        if hasattr(plugin, "get_fuel"):
            fuel_remaining = plugin.get_fuel()

        fuel_consumed = budget - fuel_remaining

        # Collect memory telemetry (#350)
        memory_pages = 0
        if hasattr(plugin, "memory_length"):
            memory_bytes_raw = plugin.memory_length()
            memory_pages = memory_bytes_raw // cls.WASM_PAGE_SIZE
        else:
            memory_bytes_raw = 0

        telemetry = {
            "fuel_consumed": fuel_consumed,
            "fuel_remaining": fuel_remaining,
            "fuel_utilization_pct": round((fuel_consumed / budget) * 100, 2) if budget > 0 else 0,
            "memory_pages_used": memory_pages,
            "memory_bytes_used": memory_bytes_raw,
            "memory_utilization_pct": round((memory_bytes_raw / cls.MAX_ALLOCATION_BYTES) * 100, 2)
            if cls.MAX_ALLOCATION_BYTES > 0
            else 0,
            "execution_time_ms": round(elapsed_ms, 2),
            "status": "SUCCESS",
        }

        return output, telemetry


def dynamic_capability_injection(
    action_space: "CognitiveActionSpaceManifest", mounted_capability: dict[str, Any]
) -> "CognitiveActionSpaceManifest":
    """Dynamically appends a discovered capability to the agent's CognitiveActionSpaceManifest at runtime.

    Do not require a restart of the node.
    """
    from coreason_manifest import (
        ExtismInProcessProfile,
        MCPCapabilityWhitelistPolicy,
        MCPServerManifest,
        StdioTransportProfile,
    )

    capability_name = mounted_capability.get("name", "dynamic_tool")
    is_in_process = mounted_capability.get("in_process", True)

    transport: ExtismInProcessProfile | StdioTransportProfile
    if is_in_process:
        transport = ExtismInProcessProfile.model_construct(
            wasm_path=str(mounted_capability.get("wasm_path", "plugins/dynamic_tool.wasm")),
            env_vars=mounted_capability.get("env_vars", {}),
        )
    else:
        transport = StdioTransportProfile.model_construct(command="extism", args=[])

    action_space.capabilities[capability_name] = MCPServerManifest.model_construct(
        server_cid="dynamic_mcp_pool",
        binary_hash=str(mounted_capability.get("binary_hash", "")),
        transport=transport,
        capability_whitelist=MCPCapabilityWhitelistPolicy.model_construct(),
        attestation_receipt=None,  # type: ignore[arg-type]
    )

    return action_space


def allocate_storage_operator() -> UniversalBlobStore:
    """Allocates and returns a pre-configured OpenDAL storage operator.

    Credentials are automatically handled by the UniversalBlobStore via environment variables,
    avoiding any logging of sensitive data.
    """
    return UniversalBlobStore()


def allocate_io_stream(input_topic: str, output_topic: str, mapping_logic: str | None = None) -> str:
    """Allocates an IO stream by generating a Redpanda Connect YAML topology string.

    This replaces internal Python IO streams.
    """
    broker = IOBroker()
    return broker.generate_topology(input_topic=input_topic, output_topic=output_topic, mapping_logic=mapping_logic)
