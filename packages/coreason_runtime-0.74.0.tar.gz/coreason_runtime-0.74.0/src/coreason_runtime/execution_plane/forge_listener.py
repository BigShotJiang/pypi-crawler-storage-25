# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Forge Event Listener — Asynchronous Epistemic Deficit Resolution (#289).

Decoupled listener that subscribes to forge completion events and resolves
epistemic deficits when capabilities become available. Uses asyncio.Event
for non-blocking waiting.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class EpistemicDeficit:
    """A recorded gap in the agent's capability space."""

    urn: str
    context: dict[str, Any]
    registered_at: float = field(default_factory=time.time)
    resolved: bool = False
    resolved_at: float | None = None


class ForgeEventListener:
    """Asynchronous listener for forge completion events (#289).

    When an agent encounters an epistemic deficit (missing capability),
    it registers the deficit and waits asynchronously for the forge to
    produce the required capability. This decouples the execution engine
    from the forge's generative pipeline.
    """

    def __init__(self) -> None:
        self._deficits: dict[str, EpistemicDeficit] = {}
        self._events: dict[str, asyncio.Event] = {}
        self._resolved_capabilities: dict[str, dict[str, Any]] = {}

    def register_deficit(self, urn: str, context: dict[str, Any] | None = None) -> EpistemicDeficit:
        """Register an epistemic deficit for a missing capability.

        Returns the deficit record for tracking.
        """
        deficit = EpistemicDeficit(urn=urn, context=context or {})
        self._deficits[urn] = deficit
        self._events[urn] = asyncio.Event()

        logger.info(f"Registered epistemic deficit for URN: {urn}")
        return deficit

    async def listen_for_capability(
        self,
        urn: str,
        timeout: float | None = 300.0,
    ) -> dict[str, Any] | None:
        """Wait asynchronously for a capability matching the URN.

        Returns the capability payload when resolved, or None on timeout.
        """
        if urn not in self._events:
            self.register_deficit(urn)

        event = self._events[urn]
        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
            return self._resolved_capabilities.get(urn)
        except TimeoutError:
            logger.warning(f"Timeout waiting for capability: {urn}")
            return None

    def notify_capability_ready(
        self,
        urn: str,
        capability_payload: dict[str, Any],
    ) -> bool:
        """Signal that a forge-produced capability is ready.

        Returns True if a deficit was resolved.
        """
        self._resolved_capabilities[urn] = capability_payload

        if urn in self._deficits:
            self._deficits[urn].resolved = True
            self._deficits[urn].resolved_at = time.time()

        if urn in self._events:
            self._events[urn].set()
            logger.info(f"Resolved epistemic deficit for URN: {urn}")
            return True

        return False

    @property
    def pending_deficits(self) -> list[EpistemicDeficit]:
        """Return all unresolved deficits."""
        return [d for d in self._deficits.values() if not d.resolved]

    @property
    def stats(self) -> dict[str, Any]:
        """Return listener statistics."""
        return {
            "total_deficits": len(self._deficits),
            "pending": len(self.pending_deficits),
            "resolved": sum(1 for d in self._deficits.values() if d.resolved),
        }
