# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Merkle DAG WORM (Write-Once Read-Many) Commit Ledger (#323).

Implements a tamper-evident cryptographic log compliant with SEC Rule 17a-4/204-2.
State transitions are Merkle-chained using SHA-256, forming an append-only DAG
where each entry references the hash of the prior entry. Any out-of-band mutation
is programmatically detectable by re-verifying the chain.

Uses LanceDB as the append-only commit store for high-performance columnar access.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from typing import Any

from coreason_runtime.utils.logger import logger

# Thread-safe singleton lock for the commit ledger
_LEDGER_LOCK = threading.Lock()
_LEDGER_INSTANCE: WORMCommitLedger | None = None


class MerkleChainViolationError(Exception):
    """Raised when tamper-evident Merkle chain verification fails.

    This indicates an out-of-band database mutation or replay attack
    that violates SEC Rule 17a-4/204-2 WORM storage compliance.
    """


def canonicalize_state(state: dict[str, Any]) -> str:
    """Produce a deterministic canonical representation of a state dict.

    Uses sorted JSON serialization with consistent formatting to ensure
    identical inputs always produce identical hash outputs, regardless
    of Python dict ordering or floating-point formatting.
    """
    return json.dumps(state, sort_keys=True, separators=(",", ":"), default=str)


def compute_merkle_hash(canonical_state: str, prior_hash: str) -> str:
    """Compute the Merkle chain hash: SHA-256(prior_hash || canonical_state).

    This creates an unbroken chain where each hash depends on all prior
    state transitions, making any retroactive modification detectable.
    """
    combined = f"{prior_hash}:{canonical_state}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()


class WORMCommitLedger:
    """Append-only commit ledger backed by LanceDB for tamper-evident state tracking.

    Each commit entry contains:
    - sequence_id: Monotonically increasing integer
    - workflow_id: The Temporal workflow that produced this state transition
    - merkle_hash: SHA-256(prior_hash || canonical_state)
    - prior_hash: The merkle_hash of the previous entry (genesis = "0" * 64)
    - canonical_state: The serialized state delta
    - timestamp: Unix epoch of the commit
    """

    GENESIS_HASH = "0" * 64

    def __init__(self, db_path: str | None = None) -> None:
        """Initialize the WORM ledger with a LanceDB backend.

        Falls back to an in-process append-only list if LanceDB is unavailable,
        ensuring the Merkle chain is always maintained even without persistence.
        """
        db_path_val = db_path or os.getenv("COREASON_WORM_LEDGER_PATH")
        self._db_path = db_path_val if db_path_val is not None else "registry/worm_ledger"
        self._last_hash: str = self.GENESIS_HASH
        self._sequence_id: int = 0
        self._lance_table: Any = None
        self._fallback_log: list[dict[str, Any]] = []
        self._initialized = False

        try:
            import lancedb  # type: ignore[import-untyped]
            import pyarrow as pa

            os.makedirs(self._db_path, exist_ok=True)
            db = lancedb.connect(self._db_path)

            schema = pa.schema(
                [
                    pa.field("sequence_id", pa.int64()),
                    pa.field("workflow_id", pa.string()),
                    pa.field("merkle_hash", pa.string()),
                    pa.field("prior_hash", pa.string()),
                    pa.field("canonical_state", pa.string()),
                    pa.field("timestamp", pa.float64()),
                ]
            )

            try:
                self._lance_table = db.open_table("worm_commits")
                # Recover last hash from existing ledger
                rows = self._lance_table.to_pandas()
                if len(rows) > 0:
                    last_row = rows.iloc[-1]
                    self._last_hash = str(last_row["merkle_hash"])
                    self._sequence_id = int(last_row["sequence_id"])
                    logger.info(
                        f"WORM Ledger recovered: {self._sequence_id} commits, last hash {self._last_hash[:16]}..."
                    )
            except Exception:
                self._lance_table = db.create_table("worm_commits", schema=schema)
                logger.info("WORM Ledger initialized: new LanceDB table created.")

            self._initialized = True

        except ImportError:
            logger.warning(
                "LanceDB not available. WORM ledger running in memory-only mode. "
                "Merkle chain integrity is maintained but not persisted to disk."
            )
            self._initialized = True

    def append(self, workflow_id: str, state_delta: dict[str, Any]) -> str:
        """Append a new state transition to the WORM ledger.

        Returns the new merkle_hash for the entry.
        Raises MerkleChainViolationError if the chain is broken.
        """
        canonical = canonicalize_state(state_delta)
        new_hash = compute_merkle_hash(canonical, self._last_hash)

        self._sequence_id += 1
        entry = {
            "sequence_id": self._sequence_id,
            "workflow_id": workflow_id,
            "merkle_hash": new_hash,
            "prior_hash": self._last_hash,
            "canonical_state": canonical,
            "timestamp": time.time(),
        }

        if self._lance_table is not None:
            try:
                import pyarrow as pa

                table = pa.table(
                    {k: [v] for k, v in entry.items()},
                    schema=pa.schema(
                        [
                            pa.field("sequence_id", pa.int64()),
                            pa.field("workflow_id", pa.string()),
                            pa.field("merkle_hash", pa.string()),
                            pa.field("prior_hash", pa.string()),
                            pa.field("canonical_state", pa.string()),
                            pa.field("timestamp", pa.float64()),
                        ]
                    ),
                )
                self._lance_table.add(table)
            except Exception as e:
                logger.error(f"Failed to persist WORM entry to LanceDB: {e}")
                self._fallback_log.append(entry)
        else:
            self._fallback_log.append(entry)

        self._last_hash = new_hash
        return new_hash

    def verify_chain(self) -> bool:
        """Verify the integrity of the entire Merkle chain.

        Returns True if the chain is valid. Raises MerkleChainViolationError
        if any entry has been tampered with.
        """
        entries = self._get_all_entries()
        if not entries:
            return True

        expected_prior = self.GENESIS_HASH
        for entry in entries:
            expected_hash = compute_merkle_hash(entry["canonical_state"], expected_prior)
            if entry["merkle_hash"] != expected_hash:
                raise MerkleChainViolationError(
                    f"Tamper detected at sequence {entry['sequence_id']}: "
                    f"expected hash {expected_hash[:16]}... but found {entry['merkle_hash'][:16]}... "
                    f"This violates SEC Rule 17a-4/204-2 WORM storage compliance."
                )
            if entry["prior_hash"] != expected_prior:
                raise MerkleChainViolationError(
                    f"Chain break at sequence {entry['sequence_id']}: "
                    f"prior_hash {entry['prior_hash'][:16]}... does not match "
                    f"expected {expected_prior[:16]}..."
                )
            expected_prior = entry["merkle_hash"]

        logger.info(f"WORM Merkle chain verified: {len(entries)} entries, chain intact.")
        return True

    @property
    def last_hash(self) -> str:
        """Return the hash of the most recent commit."""
        return self._last_hash

    @property
    def length(self) -> int:
        """Return the number of commits in the ledger."""
        return self._sequence_id

    def _get_all_entries(self) -> list[dict[str, Any]]:
        """Retrieve all entries from the ledger."""
        if self._lance_table is not None:
            try:
                from typing import cast

                df = self._lance_table.to_pandas()
                return cast("list[dict[str, Any]]", df.sort_values("sequence_id").to_dict("records"))
            except Exception as e:
                logger.warning(f"Failed to retrieve entries from LanceDB: {e}")
        return sorted(self._fallback_log, key=lambda x: x["sequence_id"])


def get_worm_ledger() -> WORMCommitLedger:
    """Get or create the singleton WORM commit ledger instance."""
    global _LEDGER_INSTANCE
    if _LEDGER_INSTANCE is None:
        with _LEDGER_LOCK:
            if _LEDGER_INSTANCE is None:
                _LEDGER_INSTANCE = WORMCommitLedger()
    return _LEDGER_INSTANCE
