# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Defeasible Cascade Blast Radius Calculator (#336).

Computes the propagation blast radius when a belief node is defeated
in the epistemic knowledge graph. Tracks cascade depth and affected
nodes for rollback planning.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from coreason_runtime.utils.logger import logger


@dataclass
class CascadeResult:
    """Result of a blast radius computation."""

    defeated_node: str
    affected_nodes: list[str]
    cascade_depth: int
    defeasibility_scores: dict[str, float]
    total_affected: int


class BlastRadiusCalculator:
    """Computes belief invalidation cascades in a knowledge graph (#336).

    When a belief node is defeated (e.g., new evidence contradicts it),
    all downstream nodes that depend on it may also be invalidated.
    This calculator performs a BFS traversal to determine the blast radius.
    """

    @staticmethod
    def calculate_blast_radius(
        defeated_node_cid: str,
        graph: dict[str, list[str]],
    ) -> CascadeResult:
        """Compute the blast radius of defeating a node.

        Args:
            defeated_node_cid: The CID of the node being defeated.
            graph: Adjacency list where keys are node CIDs and values
                   are lists of dependent node CIDs.

        Returns:
            CascadeResult with all affected nodes and cascade depth.
        """
        if defeated_node_cid not in graph:
            return CascadeResult(
                defeated_node=defeated_node_cid,
                affected_nodes=[],
                cascade_depth=0,
                defeasibility_scores={},
                total_affected=0,
            )

        visited: set[str] = set()
        queue: deque[tuple[str, int]] = deque([(defeated_node_cid, 0)])
        affected: list[str] = []
        max_depth = 0
        defeasibility: dict[str, float] = {}

        while queue:
            node, depth = queue.popleft()
            if node in visited:
                continue
            visited.add(node)
            if node != defeated_node_cid:
                affected.append(node)
            max_depth = max(max_depth, depth)

            # Defeasibility score decays with depth (closer = more affected)
            defeasibility[node] = 1.0 / (1.0 + depth)

            for dependent in graph.get(node, []):
                if dependent not in visited:
                    queue.append((dependent, depth + 1))

        logger.debug(f"Blast radius for {defeated_node_cid}: {len(affected)} nodes, depth {max_depth}")

        return CascadeResult(
            defeated_node=defeated_node_cid,
            affected_nodes=affected,
            cascade_depth=max_depth,
            defeasibility_scores=defeasibility,
            total_affected=len(affected),
        )

    @staticmethod
    def compute_defeasibility_score(
        node_cid: str,
        graph: dict[str, list[str]],
    ) -> float:
        """Compute how vulnerable a node is to cascade invalidation.

        A node with many ancestors that could be defeated has a high
        defeasibility score (0 = safe, 1 = highly vulnerable).
        """
        # Build reverse graph (predecessors)
        reverse_graph: dict[str, list[str]] = {}
        for parent, children in graph.items():
            for child in children:
                reverse_graph.setdefault(child, []).append(parent)

        # Count ancestors via BFS
        visited: set[str] = set()
        queue: deque[str] = deque([node_cid])
        ancestor_count = 0

        while queue:
            node = queue.popleft()
            if node in visited:
                continue
            visited.add(node)
            for predecessor in reverse_graph.get(node, []):
                if predecessor not in visited:
                    queue.append(predecessor)
                    ancestor_count += 1

        # Normalize: more ancestors = more vulnerable
        total_nodes = len(graph)
        return min(ancestor_count / max(total_nodes, 1), 1.0)
