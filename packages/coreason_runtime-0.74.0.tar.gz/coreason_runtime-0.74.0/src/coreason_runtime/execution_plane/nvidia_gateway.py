# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
NVIDIA Master Gateway and OpenShell Caging Actuator (#330).

Manages GPU resource allocation, scheduling, and process isolation
for active inference agents. Uses cgroup-style isolation for
GPU memory and compute partitioning.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class GPUSlice:
    """A GPU resource allocation for an agent."""

    agent_id: str
    memory_mb: int
    compute_pct: float
    allocated_at: float = field(default_factory=time.time)
    device_index: int = 0


@dataclass
class GPUMetrics:
    """GPU utilization metrics."""

    device_index: int
    total_memory_mb: int
    allocated_memory_mb: int
    free_memory_mb: int
    compute_utilization_pct: float
    active_slices: int


class NVIDIAMasterGateway:
    """GPU resource gateway for multi-agent scheduling (#330).

    Manages GPU memory and compute allocation across active inference
    agents. Prevents resource starvation and ensures fair scheduling.
    """

    def __init__(
        self,
        total_memory_mb: int = 24_576,  # 24GB default
        max_compute_pct: float = 100.0,
        num_devices: int = 1,
    ) -> None:
        self._total_memory_mb = total_memory_mb
        self._max_compute_pct = max_compute_pct
        self._num_devices = num_devices
        self._slices: dict[str, GPUSlice] = {}

    def allocate_gpu_slice(
        self,
        agent_id: str,
        memory_mb: int,
        compute_pct: float,
        device_index: int = 0,
    ) -> GPUSlice | None:
        """Allocate a GPU slice for an agent.

        Returns the allocation, or None if insufficient resources.
        """
        # Check available resources
        metrics = self.get_utilization_metrics(device_index)
        if metrics.free_memory_mb < memory_mb:
            logger.warning(
                f"GPU allocation denied for {agent_id}: requested {memory_mb}MB, available {metrics.free_memory_mb}MB"
            )
            return None

        remaining_compute = self._max_compute_pct - metrics.compute_utilization_pct
        if remaining_compute < compute_pct:
            logger.warning(
                f"GPU compute denied for {agent_id}: requested {compute_pct}%, available {remaining_compute}%"
            )
            return None

        gpu_slice = GPUSlice(
            agent_id=agent_id,
            memory_mb=memory_mb,
            compute_pct=compute_pct,
            device_index=device_index,
        )
        self._slices[agent_id] = gpu_slice

        logger.info(f"GPU allocated for {agent_id}: {memory_mb}MB, {compute_pct}% compute on device {device_index}")
        return gpu_slice

    def release_gpu_slice(self, agent_id: str) -> bool:
        """Release a GPU allocation for an agent."""
        if agent_id in self._slices:
            released = self._slices.pop(agent_id)
            logger.info(f"GPU released for {agent_id}: {released.memory_mb}MB, {released.compute_pct}% compute")
            return True
        return False

    def get_utilization_metrics(self, device_index: int = 0) -> GPUMetrics:
        """Get GPU utilization metrics for a device."""
        device_slices = [s for s in self._slices.values() if s.device_index == device_index]
        allocated_memory = sum(s.memory_mb for s in device_slices)
        compute_used = sum(s.compute_pct for s in device_slices)

        return GPUMetrics(
            device_index=device_index,
            total_memory_mb=self._total_memory_mb,
            allocated_memory_mb=allocated_memory,
            free_memory_mb=self._total_memory_mb - allocated_memory,
            compute_utilization_pct=compute_used,
            active_slices=len(device_slices),
        )


class OpenShellCagingActuator:
    """Process isolation for GPU agent caging (#330).

    Isolates agent GPU processes using configurable resource limits,
    preventing any single agent from monopolizing GPU resources.
    """

    def __init__(self, gateway: NVIDIAMasterGateway) -> None:
        self._gateway = gateway
        self._caged_agents: dict[str, dict[str, Any]] = {}

    def cage_agent(
        self,
        agent_id: str,
        memory_limit_mb: int,
        compute_limit_pct: float,
    ) -> dict[str, Any]:
        """Create an isolated cage for an agent's GPU processes."""
        gpu_slice = self._gateway.allocate_gpu_slice(agent_id, memory_limit_mb, compute_limit_pct)
        if not gpu_slice:
            return {"status": "DENIED", "agent_id": agent_id}

        cage = {
            "agent_id": agent_id,
            "memory_limit_mb": memory_limit_mb,
            "compute_limit_pct": compute_limit_pct,
            "status": "CAGED",
            "created_at": time.time(),
        }
        self._caged_agents[agent_id] = cage
        return cage

    def release_cage(self, agent_id: str) -> bool:
        """Release an agent's GPU cage."""
        if agent_id in self._caged_agents:
            self._gateway.release_gpu_slice(agent_id)
            del self._caged_agents[agent_id]
            return True
        return False

    @property
    def active_cages(self) -> list[dict[str, Any]]:
        """Return all active GPU cages."""
        return list(self._caged_agents.values())
