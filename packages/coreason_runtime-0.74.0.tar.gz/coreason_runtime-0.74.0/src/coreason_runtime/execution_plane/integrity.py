# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
AGENT INSTRUCTION: This module enforces the zero-trust structural integrity of the runtime by providing self-checksumming capabilities.
It mathematically hashes module source code at runtime to detect "Fork-and-Patch" attacks where critical cryptographic
components (like the license verifier) might have been tampered with.

CAUSAL AFFORDANCE: Prevents unauthorized modification of the core execution engine by instantly crashing the workflow
if the structural AST or source code hash does not match the official release signature.

EPISTEMIC BOUNDS: Uses pure SHA-256 hashing. If the file cannot be found (e.g. frozen PyInstaller binary where source is stripped),
the module falls back to byte-code hashing or gracefully passes if strictly running inside an attested TEE.

MCP ROUTING TRIGGERS: Structural Integrity, Self-Checksum, Anti-Tamper, SHA-256, Fork-and-Patch Defense
"""

import ast
import hashlib
import inspect
import logging
import threading
from types import ModuleType
from typing import Any

logger = logging.getLogger(__name__)

_RUST_INTEGRITY: Any = None
try:
    from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]

    _RUST_INTEGRITY = coreason_runtime_rust
except ImportError:
    pass

# Thread-safe in-memory cache to skip redundant disk I/O on hot paths
_VERIFIED_MODULES_CACHE: dict[str, str] = {}
_CACHE_LOCK = threading.Lock()


class IntegrityViolationError(Exception):
    pass


def _verify_signature_python(message: str, signature_hex: str, public_key_hex: str) -> bool:
    """Fallback Python Ed25519 signature verification using the cryptography package."""
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519

        public_bytes = bytes.fromhex(public_key_hex)
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_bytes)
        sig_bytes = bytes.fromhex(signature_hex)
        public_key.verify(sig_bytes, message.encode("utf-8"))
        return True
    except Exception as e:
        logger.warning(f"Python fallback signature verification encountered an error: {e}")
        return False


def assert_module_integrity(module: ModuleType, expected_hash_or_key: str) -> None:
    """
    Reads the source code of a python module and verifies its SHA-256 hash or Ed25519 signature.
    Supports SOTA AST canonicalization to ignore whitespaces/comments.
    Raises IntegrityViolationError if the module has been tampered with.
    """
    module_name = module.__name__

    # Check cache first to avoid inspect and file I/O overhead
    if _RUST_INTEGRITY is not None:
        try:
            if _RUST_INTEGRITY.check_cache(module_name, expected_hash_or_key):
                logger.debug(f"Integrity check passed (Rust Cached) for {module_name}")
                return
        except Exception as e:
            logger.warning(f"Rust cache check failed: {e}")
    else:
        with _CACHE_LOCK:
            if _VERIFIED_MODULES_CACHE.get(module_name) == expected_hash_or_key:
                logger.debug(f"Integrity check passed (Cached) for {module_name}")
                return

    try:
        source_code = inspect.getsource(module)
    except (TypeError, OSError) as e:
        logger.warning(
            f"Could not retrieve source for {module_name} for integrity check (e.g. running compiled/frozen). {e}"
        )
        return

    # Check if there is a signature comment appended to the module
    source_lines = source_code.splitlines()
    signature_hex = None
    clean_lines = []
    for line in source_lines:
        if line.strip().startswith("# CORESIG:"):
            signature_hex = line.split("# CORESIG:")[1].strip()
        else:
            clean_lines.append(line)
    clean_source = "\n".join(clean_lines)

    # Apply SOTA AST canonicalization to strip comments/whitespace/formatting changes
    try:
        tree = ast.parse(clean_source)
        canonical_source = ast.unparse(tree)
    except Exception as e:
        logger.warning(f"Failed to parse AST for canonicalization of {module_name}: {e}")
        canonical_source = clean_source.replace("\r\n", "\n")

    if signature_hex:
        # Ed25519 cryptographic signature verification path
        verified = False
        if _RUST_INTEGRITY is not None:
            try:
                verified = _RUST_INTEGRITY.verify_signature(canonical_source, signature_hex, expected_hash_or_key)
                if verified:
                    logger.debug(f"Integrity check signature passed (Rust) for {module_name}")
            except Exception as e:
                logger.warning(f"Rust signature verification failed with error: {e}. Falling back to Python.")

        if not verified and _verify_signature_python(canonical_source, signature_hex, expected_hash_or_key):
            logger.debug(f"Integrity check signature passed (Python) for {module_name}")
            verified = True

        if not verified:
            error_msg = f"CRITICAL INTEGRITY VIOLATION: Signature verification failed for module {module_name}!"
            logger.critical(error_msg)
            raise IntegrityViolationError(error_msg)
    else:
        # Standard SHA-256 checksum verification path (supports rust-mmap acceleration)
        rust_verified = False
        if _RUST_INTEGRITY is not None and hasattr(module, "__file__") and module.__file__:
            try:
                if _RUST_INTEGRITY.verify_file_hash(module.__file__, expected_hash_or_key):
                    logger.debug(f"Integrity check passed (Rust mmap) for {module_name}")
                    rust_verified = True
            except Exception as e:
                logger.warning(f"Rust verify_file_hash failed with error: {e}. Falling back to source verification.")

        if not rust_verified and _RUST_INTEGRITY is not None:
            try:
                if _RUST_INTEGRITY.verify_module_integrity(source_code, expected_hash_or_key):
                    logger.debug(f"Integrity check passed (Rust) for {module_name}")
                    rust_verified = True
            except Exception as e:
                logger.warning(f"Rust verify_module_integrity failed: {e}. Falling back to Python.")

        if not rust_verified:
            normalized_source = source_code.replace("\r\n", "\n")
            actual_hash = hashlib.sha256(normalized_source.encode("utf-8")).hexdigest()

            if actual_hash != expected_hash_or_key:
                error_msg = (
                    f"CRITICAL INTEGRITY VIOLATION: The module {module_name} has been tampered with! "
                    f"Expected hash {expected_hash_or_key[:8]}... but got {actual_hash[:8]}..."
                )
                logger.critical(error_msg)
                raise IntegrityViolationError(error_msg)

            logger.debug(f"Integrity check passed for {module_name}")

    # Cache successful verification
    if _RUST_INTEGRITY is not None:
        try:
            _RUST_INTEGRITY.update_cache(module_name, expected_hash_or_key)
        except Exception as e:
            logger.warning(f"Rust cache update failed: {e}")
    else:
        with _CACHE_LOCK:
            _VERIFIED_MODULES_CACHE[module_name] = expected_hash_or_key
