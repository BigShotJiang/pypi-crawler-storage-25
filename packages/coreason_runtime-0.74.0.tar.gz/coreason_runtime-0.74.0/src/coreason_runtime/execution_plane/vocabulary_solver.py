# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Ontological Vocabulary Solver with Logit-Constrained Decoding (#327).

Maps medical vocabulary terms between ontologies (SNOMED, ICD-10, LOINC,
RxNorm, OMOP) using trie-based prefix matching and logit masking to
constrain the decoder output to valid vocabulary codes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from coreason_runtime.utils.logger import logger


@dataclass
class VocabularyEntry:
    """A single term in a medical vocabulary."""

    code: str
    display: str
    vocabulary: str
    token_ids: list[int] = field(default_factory=list)


class TrieNode:
    """A node in the vocabulary trie for prefix matching."""

    __slots__ = ("children", "entries")

    def __init__(self) -> None:
        self.children: dict[str, TrieNode] = {}
        self.entries: list[VocabularyEntry] = []


class OntologicalVocabularySolver:
    """Logit-constrained decoder for medical vocabulary mapping (#327).

    Uses a trie-based vocabulary index to constrain decoder output
    to valid medical codes. Supports SNOMED CT, ICD-10, LOINC,
    RxNorm, and OMOP CDM vocabularies.
    """

    SUPPORTED_VOCABULARIES = frozenset(
        {
            "SNOMED",
            "ICD10CM",
            "ICD10PCS",
            "LOINC",
            "RxNorm",
            "CPT4",
            "HCPCS",
            "OMOP",
        }
    )

    def __init__(self) -> None:
        self._trie = TrieNode()
        self._entries: dict[str, VocabularyEntry] = {}

    def build_vocabulary_trie(
        self,
        vocabulary_entries: list[VocabularyEntry],
    ) -> int:
        """Build a trie index from vocabulary entries.

        Returns the number of entries indexed.
        """
        for entry in vocabulary_entries:
            self._entries[entry.code] = entry
            node = self._trie
            for char in entry.display.lower():
                if char not in node.children:
                    node.children[char] = TrieNode()
                node = node.children[char]
            node.entries.append(entry)

        logger.info(f"Built vocabulary trie with {len(vocabulary_entries)} entries")
        return len(vocabulary_entries)

    def prefix_search(self, prefix: str, max_results: int = 10) -> list[VocabularyEntry]:
        """Search the trie for entries matching a prefix."""
        node = self._trie
        for char in prefix.lower():
            if char not in node.children:
                return []
            node = node.children[char]

        # BFS to collect all entries under this prefix
        results: list[VocabularyEntry] = []
        queue = [node]
        while queue and len(results) < max_results:
            current = queue.pop(0)
            results.extend(current.entries[: max_results - len(results)])
            queue.extend(current.children.values())

        return results

    def apply_logit_mask(
        self,
        logits: np.ndarray,
        allowed_token_ids: list[int],
    ) -> np.ndarray:
        """Apply a logit mask to constrain decoder output.

        Sets all logits outside the allowed token set to -inf,
        forcing the decoder to only produce valid vocabulary codes.
        """
        mask = np.full_like(logits, -np.inf)
        for token_id in allowed_token_ids:
            if 0 <= token_id < len(mask):
                mask[token_id] = logits[token_id]
        return mask

    def resolve_vocabulary(
        self,
        term: str,
        source_vocab: str,
        target_vocab: str,
    ) -> list[dict[str, Any]]:
        """Map a term from source vocabulary to target vocabulary.

        Returns a ranked list of candidate mappings.
        """
        if source_vocab not in self.SUPPORTED_VOCABULARIES:
            raise ValueError(f"Unsupported source vocabulary: {source_vocab}")
        if target_vocab not in self.SUPPORTED_VOCABULARIES:
            raise ValueError(f"Unsupported target vocabulary: {target_vocab}")

        # Search for the term in the trie
        candidates = self.prefix_search(term, max_results=20)

        # Filter by target vocabulary
        target_candidates = [c for c in candidates if c.vocabulary == target_vocab]

        results = []
        for candidate in target_candidates:
            # Simple similarity score based on prefix match length
            common_len = 0
            for a, b in zip(term.lower(), candidate.display.lower(), strict=False):
                if a == b:
                    common_len += 1
                else:
                    break
            similarity = common_len / max(len(term), len(candidate.display))

            results.append(
                {
                    "code": candidate.code,
                    "display": candidate.display,
                    "vocabulary": candidate.vocabulary,
                    "similarity": round(similarity, 4),
                }
            )

        return sorted(results, key=lambda x: x["similarity"], reverse=True)
