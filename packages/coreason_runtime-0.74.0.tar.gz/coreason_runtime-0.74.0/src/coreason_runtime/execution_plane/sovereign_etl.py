# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Sovereign ETL Actuator for Federated Clinical Databases (#328).

Extracts data from FHIR R4 endpoints, transforms to OMOP CDM format,
and loads into LanceDB. All PHI processing occurs in-place with
zero external egress.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class FHIRResource:
    """A single FHIR R4 resource extracted from a clinical endpoint."""

    resource_type: str
    resource_id: str
    data: dict[str, Any]
    source_endpoint: str
    extracted_at: float = field(default_factory=time.time)


@dataclass
class OMOPRecord:
    """A record in OMOP CDM format."""

    domain: str
    concept_id: int
    concept_name: str
    source_value: str
    source_vocabulary: str
    person_id_hash: str  # PHI-safe: SHA-256 hash of patient ID


class SovereignETLActuator:
    """Federated clinical data ETL with zero-egress PHI guarantee (#328).

    Extracts from FHIR R4 → transforms to OMOP CDM → loads to LanceDB.
    All processing is sovereign (in-place), no PHI leaves the local mesh.
    """

    def __init__(self) -> None:
        self._extraction_log: list[dict[str, Any]] = []

    def extract_from_fhir(
        self,
        endpoint: str,
        resource_type: str,
        query: dict[str, str] | None = None,
    ) -> list[FHIRResource]:
        """Extract FHIR R4 resources from a clinical endpoint.

        In production, this would use httpx to query the FHIR server.
        This implementation provides the interface and PHI-safe logging.
        """
        logger.info(f"Extracting {resource_type} from {endpoint} (query: {query or 'all'})")

        # In production: httpx.get(f"{endpoint}/{resource_type}", params=query)
        # For now, return the extraction interface
        self._extraction_log.append(
            {
                "endpoint": endpoint,
                "resource_type": resource_type,
                "query": query,
                "timestamp": time.time(),
                "status": "INTERFACE_READY",
            }
        )

        return []

    def transform_to_omop(
        self,
        fhir_resources: list[FHIRResource],
    ) -> list[OMOPRecord]:
        """Transform FHIR R4 resources to OMOP CDM records.

        Maps FHIR resource types to OMOP domains:
        - Patient → Person
        - Condition → Condition Occurrence
        - MedicationRequest → Drug Exposure
        - Observation → Measurement
        - Procedure → Procedure Occurrence
        """
        fhir_to_omop_domain = {
            "Patient": "Person",
            "Condition": "Condition Occurrence",
            "MedicationRequest": "Drug Exposure",
            "Observation": "Measurement",
            "Procedure": "Procedure Occurrence",
            "DiagnosticReport": "Measurement",
            "Encounter": "Visit Occurrence",
        }

        records: list[OMOPRecord] = []

        for resource in fhir_resources:
            domain = fhir_to_omop_domain.get(resource.resource_type, "Observation")

            # PHI-safe: hash patient identifiers
            patient_ref = resource.data.get("subject", {}).get("reference", "")
            person_id_hash = hashlib.sha256(patient_ref.encode("utf-8")).hexdigest()

            record = OMOPRecord(
                domain=domain,
                concept_id=0,  # Requires vocabulary mapping
                concept_name=resource.data.get("code", {}).get("text", ""),
                source_value=resource.data.get("code", {}).get("coding", [{}])[0].get("code", "")
                if resource.data.get("code")
                else "",
                source_vocabulary=resource.data.get("code", {}).get("coding", [{}])[0].get("system", "")
                if resource.data.get("code")
                else "",
                person_id_hash=person_id_hash,
            )
            records.append(record)

        logger.info(f"Transformed {len(fhir_resources)} FHIR resources → {len(records)} OMOP records")
        return records

    def load_to_lancedb(
        self,
        omop_records: list[OMOPRecord],
        table_name: str = "omop_cdm",
    ) -> dict[str, Any]:
        """Load OMOP CDM records into LanceDB.

        Returns a summary of the load operation.
        """
        if not omop_records:
            return {"status": "NO_RECORDS", "count": 0}

        try:
            import lancedb  # type: ignore[import-untyped]

            db = lancedb.connect("registry/clinical_etl")
            data = [
                {
                    "domain": r.domain,
                    "concept_id": r.concept_id,
                    "concept_name": r.concept_name,
                    "source_value": r.source_value,
                    "source_vocabulary": r.source_vocabulary,
                    "person_id_hash": r.person_id_hash,
                }
                for r in omop_records
            ]

            if table_name in db.table_names():
                table = db.open_table(table_name)
                table.add(data)
            else:
                db.create_table(table_name, data)

            logger.info(f"Loaded {len(data)} records to LanceDB/{table_name}")
            return {"status": "SUCCESS", "count": len(data), "table": table_name}

        except ImportError:
            logger.warning("LanceDB not available. Records staged in memory.")
            return {
                "status": "STAGED_IN_MEMORY",
                "count": len(omop_records),
                "table": table_name,
            }
