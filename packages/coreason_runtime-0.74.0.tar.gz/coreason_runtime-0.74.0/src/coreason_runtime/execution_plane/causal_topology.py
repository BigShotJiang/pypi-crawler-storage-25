# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Causal Topology Engine — Do-Operator and Intervention Planning (#348).

Implements Pearl's do-calculus interventions on causal DAGs, invalidation
forecasting, and multi-step intervention execution planning.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any

from coreason_runtime.utils.logger import logger


@dataclass
class CausalNode:
    """A node in the causal DAG."""

    node_id: str
    value: Any = None
    parents: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)


@dataclass
class InterventionResult:
    """Result of a do-operator intervention."""

    target_variable: str
    intervention_value: Any
    invalidated_nodes: list[str]
    preserved_nodes: list[str]
    cascade_depth: int


class DoOperator:
    """Pearl's do-calculus intervention engine (#348).

    Executes do(X=x) operations on causal DAGs by mutilating the graph
    (removing all incoming edges to X) and computing the resulting
    interventional distribution.
    """

    @staticmethod
    def intervene(
        variable: str,
        value: Any,
        dag: dict[str, CausalNode],
    ) -> dict[str, CausalNode]:
        """Execute do(variable = value) on the causal DAG.

        Returns a mutilated graph where all incoming edges to the
        intervention target are removed (Pearl's graph surgery).
        """
        if variable not in dag:
            raise ValueError(f"Variable '{variable}' not found in causal DAG")

        # Deep copy the graph
        mutilated: dict[str, CausalNode] = {}
        for node_id, node in dag.items():
            mutilated[node_id] = CausalNode(
                node_id=node.node_id,
                value=node.value,
                parents=node.parents[:],
                children=node.children[:],
            )

        # Graph surgery: remove all incoming edges to the target
        target = mutilated[variable]
        for parent_id in target.parents:
            if parent_id in mutilated:
                mutilated[parent_id].children = [c for c in mutilated[parent_id].children if c != variable]
        target.parents = []
        target.value = value

        logger.debug(f"do({variable} = {value}): Mutilated graph, removed {len(dag[variable].parents)} incoming edges")

        return mutilated

    @staticmethod
    def compute_invalidation_forecast(
        intervention_variable: str,
        dag: dict[str, CausalNode],
    ) -> InterventionResult:
        """Forecast which nodes will be invalidated by an intervention.

        A node is invalidated if it is a descendant of the intervention
        target in the causal DAG.
        """
        if intervention_variable not in dag:
            return InterventionResult(
                target_variable=intervention_variable,
                intervention_value=None,
                invalidated_nodes=[],
                preserved_nodes=list(dag.keys()),
                cascade_depth=0,
            )

        # BFS to find all descendants
        visited: set[str] = set()
        queue: deque[tuple[str, int]] = deque([(intervention_variable, 0)])
        max_depth = 0
        invalidated: list[str] = []

        while queue:
            node_id, depth = queue.popleft()
            if node_id in visited:
                continue
            visited.add(node_id)
            max_depth = max(max_depth, depth)
            if node_id != intervention_variable:
                invalidated.append(node_id)

            for child_id in dag.get(node_id, CausalNode(node_id="")).children:
                if child_id not in visited:
                    queue.append((child_id, depth + 1))

        preserved = [n for n in dag if n not in visited]

        return InterventionResult(
            target_variable=intervention_variable,
            intervention_value=None,
            invalidated_nodes=invalidated,
            preserved_nodes=preserved,
            cascade_depth=max_depth,
        )


@dataclass
class InterventionStep:
    """A single step in a multi-step intervention plan."""

    variable: str
    value: Any
    order: int


class TopologicalInterventionPlan:
    """Multi-step causal intervention planner (#348).

    Executes a series of do-operator interventions in topological order,
    tracking cumulative invalidation across steps.
    """

    def __init__(self, dag: dict[str, CausalNode]) -> None:
        self._dag = dag
        self._steps: list[InterventionStep] = []
        self._execution_log: list[InterventionResult] = []

    def add_step(self, variable: str, value: Any) -> None:
        """Add an intervention step to the plan."""
        self._steps.append(
            InterventionStep(
                variable=variable,
                value=value,
                order=len(self._steps),
            )
        )

    def execute(self) -> list[InterventionResult]:
        """Execute all intervention steps in order.

        Returns a list of InterventionResults, one per step.
        """
        current_dag = self._dag
        results: list[InterventionResult] = []

        for step in self._steps:
            forecast = DoOperator.compute_invalidation_forecast(step.variable, current_dag)
            forecast.intervention_value = step.value

            current_dag = DoOperator.intervene(step.variable, step.value, current_dag)

            results.append(forecast)
            logger.info(
                f"Intervention step {step.order}: do({step.variable} = {step.value}), "
                f"invalidated {len(forecast.invalidated_nodes)} nodes"
            )

        self._execution_log = results
        return results

    @property
    def total_invalidated(self) -> int:
        """Total unique nodes invalidated across all steps."""
        all_invalidated: set[str] = set()
        for result in self._execution_log:
            all_invalidated.update(result.invalidated_nodes)
        return len(all_invalidated)
