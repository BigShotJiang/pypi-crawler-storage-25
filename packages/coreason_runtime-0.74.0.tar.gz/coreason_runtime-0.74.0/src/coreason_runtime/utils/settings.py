# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os

# --- Physical Infrastructure & Environment Constraints ---
# These are isolated from the logical `coreason-manifest` models as they
# control local machine constraints (e.g., WASM memory limits, socket connections).

COREASON_MEMORY_LATTICE_PAGES = int(os.getenv("COREASON_MEMORY_LATTICE_PAGES", "400"))
COREASON_COMPUTE_BUDGET = float(os.getenv("COREASON_COMPUTE_BUDGET", "200000.0"))
COREASON_SAMPLING_PROBABILITY = float(os.getenv("COREASON_SAMPLING_PROBABILITY", "1.0"))
COREASON_VECTOR_DIMENSIONS: int = int(os.environ.get("COREASON_VECTOR_DIMENSIONS", "1536"))
COREASON_KEEPALIVE_CONNECTIONS = int(os.getenv("COREASON_KEEPALIVE_CONNECTIONS", "20"))
COREASON_MAX_CONNECTIONS = int(os.getenv("COREASON_MAX_CONNECTIONS", "100"))
COREASON_TEMPORAL_HOST = os.getenv("TEMPORAL_HOST", "localhost:7233")
COREASON_TELEMETRY_BROKER_URL = os.getenv("TELEMETRY_BROKER_URL", "http://localhost:8000")
COREASON_PLUGINS_DIR: str = os.environ.get("COREASON_PLUGINS_DIR", "./plugins")
COREASON_MCP_PAYLOAD_LIMIT = int(os.getenv("COREASON_MCP_PAYLOAD_LIMIT", "10485760"))
COREASON_SUBGRAPH_TIMEOUT = float(os.getenv("COREASON_SUBGRAPH_TIMEOUT", "60.0"))


OUTLINES_MODEL = os.getenv("OUTLINES_MODEL", "Qwen/Qwen2.5-32B-Instruct-AWQ")
COREASON_VLLM_VRAM_UTILIZATION = float(os.getenv("COREASON_VLLM_VRAM_UTILIZATION", "0.9"))
COREASON_VLLM_MAX_MODEL_LEN = int(os.getenv("COREASON_VLLM_MAX_MODEL_LEN", "8192"))

COREASON_SPIFFE_ID = os.getenv("COREASON_SPIFFE_ID", "spiffe://coreason.ai/ns/default/sa/runtime")


class Settings:
    """System-wide configuration settings repository."""

    @property
    def spiffe_id(self) -> str:
        """Get the local SPIFFE identity."""
        return COREASON_SPIFFE_ID


def get_settings() -> Settings:
    """Retrieve settings repository instance."""
    return Settings()
