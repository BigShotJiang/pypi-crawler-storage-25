# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64
import os
import tempfile
from typing import Any, TypedDict

import jcs  # type: ignore[import-untyped]
import lancedb  # type: ignore[import-untyped]
import pyarrow as pa
import pyarrow.ipc as ipc
from cryptography.hazmat.primitives.asymmetric import ed25519
from neo4j import AsyncGraphDatabase
from temporalio import activity

from coreason_runtime.execution_plane.blob_store import UniversalBlobStore
from coreason_runtime.utils.logger import logger


class MigrationPayload(TypedDict):
    nodes: list[dict[str, Any]]
    relationships: list[dict[str, Any]]
    arrow_bytes: str  # Base64 encoded Arrow IPC stream
    metadata: dict[str, Any]


class MigrationRequestPayload(TypedDict, total=False):
    tenant_cid: str
    workflow_id: str
    snapshot_key: str
    target_task_queue: str
    signature: str


async def export_neo4j_graph(uri: str, user: str, password: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Fetch all nodes and relationships from the Neo4j instance."""
    driver = AsyncGraphDatabase.driver(uri, auth=(user, password))
    async with driver, driver.session() as session:
        # Fetch nodes
        result = await session.run("MATCH (n) RETURN labels(n) as labels, properties(n) as properties, n.uuid as uuid")
        nodes = [
            {
                "labels": list(record.get("labels", [])),
                "properties": dict(record.get("properties", {})),
                "uuid": record.get("uuid"),
            }
            async for record in result
        ]
        # Fetch relationships
        result = await session.run(
            "MATCH (s)-[r]->(t) RETURN s.uuid as source_uuid, t.uuid as target_uuid, type(r) as type, properties(r) as properties"
        )
        relationships = [
            {
                "source_uuid": record.get("source_uuid"),
                "target_uuid": record.get("target_uuid"),
                "type": record.get("type"),
                "properties": dict(record.get("properties", {})),
            }
            async for record in result
        ]
    return nodes, relationships


async def import_neo4j_graph(
    uri: str, user: str, password: str, nodes: list[dict[str, Any]], relationships: list[dict[str, Any]]
) -> None:
    """Clear database and reconstruct Neo4j graph from serialized payload."""
    driver = AsyncGraphDatabase.driver(uri, auth=(user, password))
    async with driver, driver.session() as session:
        await session.run("MATCH (n) DETACH DELETE n")

        # Recreate nodes
        for node in nodes:
            labels_str = ":".join(node["labels"])
            label_clause = f":{labels_str}" if labels_str else ""
            uuid = node["uuid"]
            query = f"CREATE (n{label_clause}) SET n = $props"
            props = dict(node["properties"])
            if uuid:
                props["uuid"] = uuid
            await session.run(query, props=props)

        # Recreate relationships
        for rel in relationships:
            if not rel["source_uuid"] or not rel["target_uuid"]:
                continue
            # Escape relationship type to prevent query syntax errors
            rel_type = rel["type"]
            query = (
                f"MATCH (s {{uuid: $source_uuid}}), (t {{uuid: $target_uuid}}) "
                f"CREATE (s)-[r:{rel_type}]->(t) SET r = $props"
            )
            await session.run(
                query, source_uuid=rel["source_uuid"], target_uuid=rel["target_uuid"], props=dict(rel["properties"])
            )


_cached_private_key = None


def _get_signing_key() -> ed25519.Ed25519PrivateKey:
    """Load the migration signing key from the environment.

    Raises RuntimeError if the key is not configured — ephemeral fallback
    keys are a security violation (#352).
    """
    global _cached_private_key
    env_key = os.environ.get("COREASON_MIGRATION_PRIVATE_KEY")
    if env_key:
        try:
            return ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(env_key))
        except Exception as e:
            raise RuntimeError(
                f"Failed to load COREASON_MIGRATION_PRIVATE_KEY: {e}. "
                "Verify the base64-encoded Ed25519 private key is correctly set."
            ) from e
    # Allow ephemeral keys ONLY in explicit test mode
    if os.environ.get("COREASON_TESTING") == "1":
        if _cached_private_key is None:
            logger.warning("Using ephemeral key for testing — NOT for production.")
            _cached_private_key = ed25519.Ed25519PrivateKey.generate()
        return _cached_private_key
    raise RuntimeError(
        "COREASON_MIGRATION_PRIVATE_KEY is not set. "
        "Ephemeral key generation is forbidden in production to prevent "
        "cross-node state deserialization failures and signature mismatches."
    )


@activity.defn(name="serialize_agent_state_activity")
async def serialize_agent_state_activity(payload: MigrationRequestPayload) -> dict[str, Any]:
    """Serialize the Neo4j graph memory and LanceDB vector store to OpenDAL."""
    tenant_cid = payload.get("tenant_cid", "default_tenant")
    workflow_id = payload.get("workflow_id", "default_workflow")
    snapshot_key = payload.get("snapshot_key", f"migration/{tenant_cid}/{workflow_id}.state")

    logger.info(f"Initiating agent state serialization for tenant: {tenant_cid}")

    # 1. Export Neo4j Graph Memory
    neo4j_uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user = os.getenv("NEO4J_USERNAME", "neo4j")
    neo4j_password = os.getenv("NEO4J_PASSWORD", "password")

    nodes, relationships = await export_neo4j_graph(neo4j_uri, neo4j_user, neo4j_password)

    # 2. Export LanceDB capabilities Table
    arrow_b64 = ""
    # In test environment, lancedb.connect may fail if mocked. Fallback gracefully.
    try:
        db_uri = os.environ.get("COREASON_LANCEDB_URI")
        if not db_uri:
            # Replicate standard local path structure
            db_uri = os.path.join(tempfile.gettempdir(), f"lancedb_{tenant_cid}")
            os.makedirs(db_uri, exist_ok=True)

        db = lancedb.connect(db_uri)
        if "capabilities" in db.list_tables():
            table = db.open_table("capabilities")
            arrow_table = table.to_arrow()
            sink = pa.BufferOutputStream()
            with ipc.new_stream(sink, arrow_table.schema) as writer:  # type: ignore[no-untyped-call]
                writer.write_table(arrow_table)
            arrow_b64 = base64.b64encode(sink.getvalue().to_pybytes()).decode("utf-8")
    except (OSError, pa.ArrowInvalid) as e:
        # Recoverable: LanceDB not configured or empty — acceptable for fresh installs
        logger.warning(f"LanceDB export skipped (non-critical): {e}")
    except Exception as e:
        # Non-recoverable: data corruption or unexpected failure — must surface
        raise RuntimeError(
            f"Critical LanceDB serialization failure for tenant {tenant_cid}: {e}. "
            "Vector state may be lost. Aborting migration."
        ) from e

    # 3. Package and Canonicalize using JCS
    migration_payload: MigrationPayload = {
        "nodes": nodes,
        "relationships": relationships,
        "arrow_bytes": arrow_b64,
        "metadata": {
            "tenant_cid": tenant_cid,
            "workflow_id": workflow_id,
        },
    }

    canonical_bytes = jcs.canonicalize(migration_payload)

    # 4. Sign package
    private_key = _get_signing_key()
    signature = private_key.sign(canonical_bytes)
    sig_b64 = base64.b64encode(signature).decode("utf-8")

    # 5. Write to OpenDAL via UniversalBlobStore
    blob_store = UniversalBlobStore()
    await blob_store.write_bytes(snapshot_key, canonical_bytes)

    logger.info(f"Agent state serialized successfully. Uploaded to {snapshot_key}")

    return {
        "snapshot_key": snapshot_key,
        "signature": sig_b64,
        "verification_key": base64.b64encode(private_key.public_key().public_bytes_raw()).decode("utf-8"),
    }


@activity.defn(name="rehydrate_agent_state_activity")
async def rehydrate_agent_state_activity(payload: MigrationRequestPayload) -> dict[str, Any]:
    """Fetch serialized agent state from OpenDAL, verify signature, and rehydrate databases."""
    tenant_cid = payload.get("tenant_cid", "default_tenant")
    workflow_id = payload.get("workflow_id", "default_workflow")
    snapshot_key = payload.get("snapshot_key", f"migration/{tenant_cid}/{workflow_id}.state")
    signature_b64 = payload.get("signature", "")

    logger.info(f"Initiating agent state rehydration from snapshot: {snapshot_key}")

    # 1. Read bytes from OpenDAL via UniversalBlobStore
    blob_store = UniversalBlobStore()
    canonical_bytes = await blob_store.read_bytes(snapshot_key)

    # 2. Verify signature
    # In test scenario, if signature verification is bypassed or using self-signed keys
    if signature_b64:
        try:
            public_key = _get_signing_key().public_key()
            signature = base64.b64decode(signature_b64)
            public_key.verify(signature, canonical_bytes)
            logger.info("Cryptographic signature verified successfully.")
        except Exception as e:
            logger.error(f"Cryptographic verification failed: {e}")
            raise RuntimeError("Causal Defeasible Quarantine: State signature mismatch.") from e

    # 3. Deserialize package
    import json

    state_package = json.loads(canonical_bytes.decode("utf-8"))

    # 4. Rehydrate Neo4j Graph Memory
    neo4j_uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user = os.getenv("NEO4J_USERNAME", "neo4j")
    neo4j_password = os.getenv("NEO4J_PASSWORD", "password")

    await import_neo4j_graph(
        neo4j_uri, neo4j_user, neo4j_password, state_package["nodes"], state_package["relationships"]
    )

    # 5. Rehydrate LanceDB capability Table
    arrow_b64 = state_package.get("arrow_bytes")
    if arrow_b64:
        try:
            arrow_bytes = base64.b64decode(arrow_b64)
            reader = ipc.open_stream(arrow_bytes)  # type: ignore[no-untyped-call]

            arrow_table = reader.read_all()

            db_uri = os.environ.get("COREASON_LANCEDB_URI")
            if not db_uri:
                db_uri = os.path.join(tempfile.gettempdir(), f"lancedb_{tenant_cid}")
                os.makedirs(db_uri, exist_ok=True)

            db = lancedb.connect(db_uri)
            db.create_table("capabilities", data=arrow_table, mode="overwrite")
        except (OSError, pa.ArrowInvalid) as e:
            # Recoverable: LanceDB not configured — acceptable on fresh target
            logger.warning(f"LanceDB rehydration skipped (non-critical): {e}")
        except Exception as e:
            # Non-recoverable: data corruption during rehydration — must surface
            raise RuntimeError(
                f"Critical LanceDB rehydration failure for tenant {tenant_cid}: {e}. "
                "Vector state cannot be restored. Aborting migration."
            ) from e

    logger.info("Agent state rehydration complete.")
    return {"rehydrated": True, "workflow_id": workflow_id}
