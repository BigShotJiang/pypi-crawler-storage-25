# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.utils import canonicalize
    from coreason_runtime.utils.exceptions import ManifestConformanceError


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class IntentElicitationExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow representing an Intent Elicitation Topology.

    AGENT INSTRUCTION: Handles VLM extraction mapping cyclical bounds. Yields to human
    oracles when epistemic entropy breaches the specified maximum.
    """

    def __init__(self) -> None:
        """Initialize IntentElicitationExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Intent Elicitation workflow."""

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow_start_time = workflow.now()

        workflow.logger.info("Starting IntentElicitationExecutionWorkflow")

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import IntentElicitationTopologyManifest

            manifest = IntentElicitationTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")

        entropy_threshold = 0.5  # Default heuristic threshold
        interrogation_rounds = manifest.max_clarification_loops + 1
        current_round = 0

        final_intent = {}
        oracle_feedback = None

        while current_round < interrogation_rounds:
            self.enforce_governance_limits(governance, workflow_start_time)

            if not manifest or not getattr(manifest, "nodes", None) or len(manifest.nodes) == 0:
                raise ManifestConformanceError("Empty manifest or nodes list.")

            extractor_id = (
                str(manifest.scanner_node_cid)
                if getattr(manifest, "scanner_node_cid", None) is not None
                else next(iter(sorted(manifest.nodes.keys())))
            )

            with workflow.unsafe.sandbox_unrestricted():
                node_payload = manifest_payload.get("nodes", {}).get(extractor_id)
                if not node_payload:
                    node_profile = manifest.nodes.get(extractor_id)
                    dump_func = getattr(node_profile, "model_dump", None)
                    node_payload = (
                        dump_func(mode="json")
                        if node_profile is not None and dump_func is not None
                        else {"type": "agent", "description": "VLM Extractor"}
                    )

            segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": node_payload,
                "round": current_round,
            }
            if oracle_feedback is not None:
                segregated_payload["oracle_feedback"] = oracle_feedback

            result = await workflow.execute_activity(
                "ExecuteNemoclawCognitiveActivity",
                args=[
                    {
                        "name": "deploy_cognitive_topology",
                        "arguments": {
                            "workflow_id": workflow.info().workflow_id,
                            "payload": segregated_payload,
                            "schema_to_request": (
                                "AutonomousAgentResponse"
                                if (
                                    segregated_payload.get("node_profile", {}).get("action_space_cid")
                                    if isinstance(segregated_payload, dict) and "node_profile" in segregated_payload
                                    else (
                                        segregated_payload.get("action_space_cid")
                                        if isinstance(segregated_payload, dict)
                                        else None
                                    )
                                )
                                else "AgentResponse"
                            ),
                        },
                    }
                ],
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=1),
            )

            usage = result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += result.get("cost", 0.0)
            await self.record_resource_utilization("result", usage, result.get("cost", 0.0))

            self.reconcile_state(
                {
                    "accumulated_tokens": self._accumulated_tokens,
                    "accumulated_cost": self._accumulated_cost,
                }
            )

            measured_entropy = result.get("outputs", {}).get("entropy", 0.0)
            if measured_entropy > entropy_threshold:
                workflow.logger.info(
                    f"Epistemic Entropy '{measured_entropy}' > threshold '{entropy_threshold}'. "
                    "Awaiting oracle override."
                )
                await workflow.wait_condition(
                    lambda: self._pending_oracle_override is not None or self._current_oracle_resolution is not None
                )

                if self._pending_oracle_override is not None:
                    final_intent = self._pending_oracle_override
                    self._pending_oracle_override = None
                    break
                oracle_feedback = self._current_oracle_resolution
                self._current_oracle_resolution = None
            else:
                final_intent = result
                break

            current_round += 1

        if not final_intent:
            raise ManifestConformanceError("Final intent is empty after clarification loops.")

        intent_hash = final_intent.get("intent_hash") if isinstance(final_intent, dict) else None
        if not intent_hash or intent_hash == "UNKNOWN_HASH":
            with workflow.unsafe.sandbox_unrestricted():
                import hashlib

                intent_hash = hashlib.sha256(canonicalize(final_intent)).hexdigest()
        success = final_intent.get("success", True) if final_intent else False

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, final_intent, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed IntentElicitationExecutionWorkflow")
        return {"status": "success", "rounds": current_round, "intent": final_intent}
