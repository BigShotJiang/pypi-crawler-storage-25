# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Intent renegotiation execution logic.

AGENT INSTRUCTION: This workflow acts as an automated broker fixing rejection boundaries mathematically.
"""

import os
from datetime import timedelta
from typing import Any, TypedDict

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import IntentClassificationReceipt

from coreason_runtime.utils.exceptions import ManifestConformanceError


class RejectionReceiptDict(TypedDict, total=False):
    violated_algebraic_constraint: list[str]
    stochastic_mutation_gradient: float


class IntentDict(TypedDict, total=False):
    intent_hash: str


class RenegotiationPayload(TypedDict, total=False):
    rejection: RejectionReceiptDict
    intent: IntentDict
    violated_algebraic_constraint: list[str]
    stochastic_mutation_gradient: float


class RejectionParametersResult(TypedDict, total=False):
    violated_algebraic_constraint: list[str]
    stochastic_mutation_gradient: float


class IntentParamsDict(TypedDict, total=False):
    adjusted: bool


class RepackagedIntentDict(TypedDict, total=False):
    intent_hash: str
    params: IntentParamsDict


class CompromiseIntentResult(TypedDict, total=False):
    new_intent: RepackagedIntentDict


@activity.defn
async def parse_rejection_parameters_activity(payload: dict[str, Any]) -> RejectionParametersResult:
    """Parse the cryptographic denial parameters.

    AGENT INSTRUCTION: Ensure the constraints are mathematically extracted.
    """
    activity.logger.info("Parsing rejection boundaries mathematically constraints.")
    receipt = payload.get("rejection", {})
    if receipt.get("violated_algebraic_constraint") is None:
        msg = "Invalid EpistemicRejectionReceipt: missing algebraic constraints."
        raise ManifestConformanceError(msg)

    constraints = receipt.get("violated_algebraic_constraint", [])
    if constraints is None:
        constraints = []

    raw_grad = receipt.get("stochastic_mutation_gradient")
    gradient = float(raw_grad) if raw_grad is not None else 0.0

    return RejectionParametersResult(
        violated_algebraic_constraint=constraints,
        stochastic_mutation_gradient=gradient,
    )


@activity.defn
async def synthesize_compromise_intent_activity(payload: dict[str, Any]) -> CompromiseIntentResult:
    """Coordinate mathematically constrained renegotiation.

    AGENT INSTRUCTION: Use SGLang proxy to reform the intent dynamically.
    """
    import httpx

    from coreason_runtime.utils.settings import get_settings

    activity.logger.info("Synthesizing compromise topology intent boundary.")
    if not payload.get("intent"):
        msg = "Invalid BoundedJSONRPCIntent: missing explicit intent structure."
        raise ManifestConformanceError(msg)

    intent = payload.get("intent", {})
    intent_hash = intent.get("intent_hash", "")

    ecosystem_base_url = os.getenv("ECOSYSTEM_BASE_URL", "http://localhost:8000")
    endpoint = f"{ecosystem_base_url}/v1/mcp/synthesize"

    request_body = {
        "original_intent": intent,
        "constraints": payload.get("violated_algebraic_constraint", []),
        "mutation_gradient": payload.get("stochastic_mutation_gradient", 0.0),
        "target_schema": "RepackagedIntentDict",
    }

    settings = get_settings()
    headers = {"X-Vault-Workload-Identity": settings.spiffe_id}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(endpoint, json=request_body, headers=headers, timeout=120.0)
            response.raise_for_status()
            result_data = response.json()
            return CompromiseIntentResult(new_intent=result_data.get("new_intent", {}))
    except httpx.HTTPError as e:
        if os.getenv("COREASON_TESTING") == "1":
            intent_data: RepackagedIntentDict = {"intent_hash": intent_hash, "params": {"adjusted": True}}
            return CompromiseIntentResult(new_intent=intent_data)
        raise ManifestConformanceError(f"HTTP request to MCP synthesis failed: {e}") from e


@workflow.defn
class IntentRenegotiationExecutionWorkflow:
    """Mathematical constrained renegotiation of intents."""

    def __init__(self) -> None:
        """Initialize IntentRenegotiationExecutionWorkflow."""

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> CompromiseIntentResult:
        """Execute boundary negotiation fallback protocol.

        Args:
            payload: Internal payload containing the unfulfilled intent and receipt payload.

        Returns:
            The newly synthesized and adjusted intent dict.
        """
        workflow.logger.info("Transition: execute syntactic boundary parsing protocol")

        inner_payload = payload["payload"] if "payload" in payload and "trace_context" in payload else payload

        # Coerce inner payload strictly to TypedDict mapping expectations seamlessly
        safe_payload: RenegotiationPayload = {
            "rejection": inner_payload.get("rejection", {}),
            "intent": inner_payload.get("intent", {}),
        }

        parse_result = await workflow.execute_activity(
            parse_rejection_parameters_activity,
            args=[safe_payload],
            schedule_to_close_timeout=timedelta(seconds=60),
        )

        synth_payload = RenegotiationPayload(**safe_payload)
        synth_payload.update(parse_result)

        raw_input_string = str(inner_payload.get("intent", {}))
        with workflow.unsafe.sandbox_unrestricted():
            import hashlib

            from coreason_runtime.utils import canonicalize

            event_cid = hashlib.sha256(canonicalize(raw_input_string)).hexdigest()
            receipt = IntentClassificationReceipt(
                event_cid=event_cid,
                timestamp=workflow.now().timestamp(),
                classified_intent="renegotiation",
                confidence_score=1.0,
                raw_input_string=raw_input_string,
            )
            receipt_dict = receipt.model_dump(mode="json")

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, event_cid, True, receipt_dict, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Transition: orchestrate compromise topology layout")
        return await workflow.execute_activity(
            synthesize_compromise_intent_activity,
            args=[synth_payload],
            schedule_to_close_timeout=timedelta(seconds=120),
        )
