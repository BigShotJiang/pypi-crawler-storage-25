# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

from typing import Any

from coreason_manifest.spec.ontology import EpistemicSOPManifest
from temporalio import workflow


@workflow.defn
class EpistemicSOPExecutionWorkflow:
    """Orchestrates an EpistemicSOPManifest across chronological constraints."""

    @workflow.run
    async def run(self, manifest_payload: dict[str, Any]) -> dict[str, Any]:
        """Executes cognitive steps in graph sequence.

        Resolves the topological path traversing the DAG.
        Sorts nodes mathematically by flow for standard SOP list execution.
        Applies simple DAG traversal starting from edge sources not heavily targeted.
        For each ordered node, executes the simulation step.
        """
        from pydantic import ValidationError
        from temporalio.exceptions import ApplicationError

        try:
            # Unpack the enveloped payload per the Naked Payload Ban execution invariant
            if "payload" in manifest_payload and "trace_context" in manifest_payload:
                inner_payload = manifest_payload["payload"]
            else:
                inner_payload = manifest_payload

            # Temporal JSON DataConverter degrades tuples to lists.
            # Restore tuples to maintain strict Pydantic architectural isomorphism.
            edges = inner_payload.get("chronological_flow_edges", [])
            inner_payload["chronological_flow_edges"] = [tuple(e) if isinstance(e, list) else e for e in edges]

            manifest = EpistemicSOPManifest.model_validate(inner_payload)
        except ValidationError as e:
            raise ApplicationError(
                f"Manifest validation failed: {e!s}", type="ManifestConformanceError", non_retryable=True
            ) from None

        chronological_edges: list[tuple[str, str]] = list(manifest.chronological_flow_edges)
        cognitive_steps = manifest.cognitive_steps

        executed_nodes = []

        if not chronological_edges and cognitive_steps:
            ordered_nodes = list(cognitive_steps.keys())
        else:
            ordered_nodes = []
            adjacency = dict(chronological_edges)

            sources = {src for src, _ in chronological_edges}
            targets = {tgt for _, tgt in chronological_edges}
            start_nodes = sources - targets

            if start_nodes:
                current = next(iter(sorted(start_nodes)))
                while current:
                    ordered_nodes.append(current)
                    current = adjacency.get(current)  # type: ignore[assignment]

        for step_id in ordered_nodes:
            cognitive_steps[step_id]

            executed_nodes.append(step_id)

        return {"status": "sop_execution_completed", "executed_nodes": executed_nodes}
