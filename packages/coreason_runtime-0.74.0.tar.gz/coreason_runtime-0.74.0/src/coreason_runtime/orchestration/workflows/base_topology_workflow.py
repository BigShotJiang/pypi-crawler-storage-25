# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import contextlib
from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState, TokenBurnReceipt
    from coreason_manifest.spec.ontology import BargeInInterruptEvent, EpistemicRejectionReceipt

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta


class BaseTopologyWorkflow:
    """An abstract deterministic workflow base for coreason-manifest topologies."""

    def verify_commercial_license(self, receipt_payload: dict[str, Any] | None) -> list[str]:
        """Validate a CommercialOverrideReceipt to unlock premium network/IP features."""
        import os

        from coreason_manifest.spec.ontology import CommercialOverrideReceipt

        import coreason_runtime.execution_plane.license_verifier as license_verifier_mod
        from coreason_runtime.execution_plane.integrity import assert_module_integrity
        from coreason_runtime.execution_plane.license_verifier import LicenseVerifier

        # Mathematically assert the structural integrity of the license verifier module
        # This acts as an anti-tamper measure against Fork-and-Patch attacks.
        expected_license_verifier_hash = "837e3fca7f730a227a8885ac09d1e5aea827e8a3b473bb79ea3867f1a646c28c"
        assert_module_integrity(license_verifier_mod, expected_license_verifier_hash)

        if not receipt_payload:
            return []

        try:
            # We skip rigid Pydantic validation if run inside the Temporal sandbox context restrictions,
            # but CommercialOverrideReceipt is designed to be sandbox-safe.
            receipt = CommercialOverrideReceipt.model_validate(receipt_payload)

            # Extract fingerprint from workflow context or environment
            local_fingerprint = os.getenv("COREASON_CLUSTER_FINGERPRINT", None)

            verifier = LicenseVerifier(local_fingerprint)
            return verifier.verify_and_apply(receipt)
        except Exception as e:
            from temporalio.workflow import _Runtime

            if _Runtime.maybe_current() is not None:
                workflow.logger.error(f"License verification failed during workflow initialization: {e}")
            else:
                import logging

                logging.getLogger(__name__).error(f"License verification failed during workflow initialization: {e}")
            return []

    def __init__(self) -> None:
        """Initialize BaseTopologyWorkflow."""
        self._current_state_envelope: ExecutionEnvelopeState[dict[str, Any]] | None = None
        self._pending_oracle_override: dict[str, Any] | None = None
        self._current_oracle_resolution: dict[str, Any] | None = None
        self._accumulated_tokens: int = 0
        self._accumulated_cost: float = 0.0
        self._is_interrupted: bool = False
        self._interrupt_disposition: str | None = None
        self._interrupt_event: dict[str, Any] | None = None
        self._shock_reason: str | None = None

    @workflow.signal(name="resilience_shock")
    async def resilience_shock(self, payload: dict[str, Any]) -> None:
        """Handle a ResilienceShock signal from an external observability platform.

        This signal triggers an immediate pause/halt of the workflow logic,
        allowing for sovereign external control over execution drift.
        """
        reason = payload.get("reason", "External Observability Alarm")
        severity = payload.get("severity", "critical")
        workflow.logger.error(f"RESILIENCE SHOCK RECEIVED: {reason} (Severity: {severity})")

        self._shock_reason = reason
        # We don't raise here because signals are handled asynchronously.
        # The workflow logic must check this flag or we raise in a way that
        # the main loop catches.

    @workflow.query(name="is_interrupted")
    def is_interrupted(self) -> bool:
        """Query if the workflow has received a barge-in interrupt."""
        return self._is_interrupted

    @workflow.signal(name="barge_in_interrupt")
    async def barge_in_interrupt(self, event_payload: dict[str, Any]) -> None:
        """Handle a BargeInInterruptEvent signaling premature probability wave collapse."""

        workflow.logger.warning("Barge-In Interrupt Signal Received! Halting generative sequences.")

        # Validating signal bounds using strictly typed ontology restrictions
        interrupt_event = BargeInInterruptEvent.model_validate(event_payload)

        self._is_interrupted = True
        self._interrupt_disposition = interrupt_event.epistemic_disposition
        self._interrupt_event = event_payload

        # State Management: Emit Rejection Receipt resolving logic dispositions
        with workflow.unsafe.sandbox_unrestricted():
            receipt = EpistemicRejectionReceipt(
                event_cid=f"rejection-event-{workflow.uuid4()}",
                timestamp=workflow.now().timestamp(),
                receipt_cid=f"rejection-{workflow.uuid4()}",
                failed_projection_cid=interrupt_event.target_event_cid,
                violated_algebraic_constraint=f"BargeInInterrupt forced wave collapse (Disposition: {self._interrupt_disposition})",
                kl_divergence_to_validity=1.0,
                stochastic_mutation_gradient="ABORT_SEQUENCE_IMMEDIATELY",
            )
            receipt_dict = receipt.model_dump(mode="json")

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[
                workflow.info().workflow_id,
                receipt.receipt_cid,
                False,
                {"barge_in": True, "payload": event_payload},
                receipt_dict,
            ],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

    async def record_resource_utilization(self, node_cid: str, usage: dict[str, Any], cost: float) -> None:
        """Commit a TokenBurnReceipt dynamically caching resource utilization state."""
        import hashlib

        try:
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)
        except AttributeError:
            input_tokens = 0
            output_tokens = usage.get("total_tokens", 0) if isinstance(usage, dict) else 0

        if input_tokens > 0 or output_tokens > 0 or cost > 0:
            import hashlib

            hashlib.sha256(workflow.info().workflow_id.encode("utf-8")).hexdigest()
            receipt = TokenBurnReceipt(
                event_cid=f"burn-{workflow.uuid4()}",
                timestamp=workflow.now().timestamp(),
                tool_invocation_cid=node_cid,
                input_tokens=int(input_tokens),
                output_tokens=int(output_tokens),
                burn_magnitude=int(cost),
            )
            await workflow.execute_activity(
                "RecordTokenBurnIOActivity",
                args=[workflow.info().workflow_id, receipt.model_dump(mode="json")],
                schedule_to_close_timeout=timedelta(minutes=1),
            )

    def reconcile_state(self, new_mutable_state: dict[str, Any]) -> None:
        """Reconcile the mutated state updates with Merkle chain verification (#323).

        Each state transition is SHA-256 chained with the prior state hash
        and appended to the WORM commit ledger for SEC 17a-4 compliance.
        """
        if self._current_state_envelope is None:
            msg = "No current state envelope available."
            raise ValueError(msg)

        for key in new_mutable_state:
            if key in self._current_state_envelope.state_vector.immutable_matrix:
                msg = f"CRITICAL STATE VIOLATION: Attempted to modify read-only context key '{key}'."
                raise ValueError(msg)

        import copy

        mut_mem_copy = copy.deepcopy(self._current_state_envelope.state_vector.mutable_matrix or {})
        for key, value in new_mutable_state.items():
            mut_mem_copy[key] = value

        new_state_vector = copy.deepcopy(self._current_state_envelope.state_vector)
        object.__setattr__(new_state_vector, "mutable_matrix", mut_mem_copy)
        object.__setattr__(self._current_state_envelope, "state_vector", new_state_vector)

        new_clock = self._current_state_envelope.trace_context.causal_clock + 1
        new_trace_context = copy.deepcopy(self._current_state_envelope.trace_context)
        object.__setattr__(new_trace_context, "causal_clock", new_clock)

        # Fix #323: Merkle DAG WORM chain — compute hash and append to ledger
        try:
            from coreason_runtime.execution_plane.worm_ledger import (
                canonicalize_state,
                compute_merkle_hash,
                get_worm_ledger,
            )

            canonical = canonicalize_state(new_mutable_state)
            prior_hash = getattr(new_trace_context, "prior_event_hash", "") or "0" * 64
            merkle_hash = compute_merkle_hash(canonical, prior_hash)
            object.__setattr__(new_trace_context, "prior_event_hash", merkle_hash)

            # Append to the WORM commit ledger (best-effort — don't crash the workflow)
            try:
                workflow_id = getattr(self, "_workflow_id", "unknown")
                ledger = get_worm_ledger()
                ledger.append(str(workflow_id), new_mutable_state)
            except Exception as e:
                workflow.logger.warning(f"WORM ledger append failed (non-fatal): {e}")

        except ImportError:
            workflow.logger.debug("WORM ledger module not available, skipping Merkle chain.")

        object.__setattr__(self._current_state_envelope, "trace_context", new_trace_context)

    def enforce_governance_limits(self, governance: dict[str, Any] | None, start_time: Any) -> None:
        """Enforces the economic constraints.

        Args:
            governance: The governance dictionary injected from the manifest.
            start_time: The start time of the workflow from `workflow.now()`.
        """
        if not governance:
            return

        max_global_tokens = governance.get("max_global_tokens")
        if max_global_tokens is not None and self._accumulated_tokens > max_global_tokens:
            msg = f"Global token budget breached: {self._accumulated_tokens} > {max_global_tokens}"
            raise ValueError(msg)

        max_budget_magnitude = governance.get("max_budget_magnitude")
        if max_budget_magnitude is not None and self._accumulated_cost > max_budget_magnitude:
            msg = f"Global budget magnitude breached: {self._accumulated_cost} > {max_budget_magnitude}"
            raise ValueError(msg)

        global_timeout_seconds = governance.get("global_timeout_seconds")
        if global_timeout_seconds is not None:
            elapsed_seconds = (workflow.now() - start_time).total_seconds()
            if elapsed_seconds > global_timeout_seconds:
                msg = f"Global TTL breached: {elapsed_seconds} > {global_timeout_seconds}"
                raise ValueError(msg)

    @workflow.query(name="get_current_state")
    def get_current_state(self) -> dict[str, Any]:
        """Query the current state of the workflow."""
        if self._current_state_envelope:
            return self._current_state_envelope.model_dump(mode="json")
        return {}

    @workflow.signal(name="apply_state_delta")
    async def apply_state_delta(self, delta_payload: dict[str, Any]) -> None:
        """Apply a CRDT state delta and echo the state."""
        workflow.logger.info("Received CRDT delta signal.")
        if self._current_state_envelope is None:
            msg = "Cannot apply state delta without an active envelope."
            raise ValueError(msg)

        self.reconcile_state(delta_payload)

        await workflow.execute_activity(
            "BroadcastStateEchoIOActivity",
            args=[workflow.info().workflow_id, self._current_state_envelope.model_dump(mode="json")],
            schedule_to_close_timeout=timedelta(seconds=10),
        )

    @workflow.signal(name="receive_oracle_override")
    def receive_oracle_override(self, corrected_intent: dict[str, Any]) -> None:
        """Receive the absolute ground-truth injection from the Oracle."""
        workflow.logger.info("Received Epistemic Injection (Oracle Override).")
        self._pending_oracle_override = corrected_intent

    @workflow.signal(name="inject_oracle_resolution")
    async def inject_oracle_resolution(self, payload: dict[str, Any]) -> None:
        """Inject the resolving priors from the human Oracle."""
        workflow.logger.info("Received Oracle resolution priors.")
        self._current_oracle_resolution = payload

    async def emit_mcp_ui_intent(
        self,
        intent_type: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Compile and emit an MCPClientIntent to the telemetry broker dynamically.

        Emits diagnostic UI intents without coupling to UI rendering code.
        """
        from datetime import timedelta

        ctx = context or {}
        mcp_intent = {"intent_type": intent_type, "raw_payload": ctx}

        # Emit to telemetry broker
        await workflow.execute_activity(
            "BroadcastStateEchoIOActivity",
            args=[
                workflow.info().workflow_id,
                {"type": "MCPClientIntent", "intent": mcp_intent},
            ],
            schedule_to_close_timeout=timedelta(seconds=10),
        )
        workflow.logger.info(f"Emitted MCPClientIntent ({intent_type}) as raw telemetry.")

    async def intercept_kinematic_intent(
        self,
        tool_name: str,
        intent_payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Intercept SpatialKinematicActionIntent before ROS2 actuation.

        If the target tool maps to a ros2_bridge MCP, dynamically injects
        a LifecycleTriggerEvent demanding a WetwareAttestationContract
        (biometric sign-off) from the on-site operator.

        Args:
            tool_name: The MCP tool name being invoked.
            intent_payload: The SpatialKinematicActionIntent dict.

        Returns:
            The intent payload (possibly enriched with attestation receipt)
            or raises if safety interlock is not met.
        """
        # Detect if this is a cyber-physical actuation target
        ros2_tool_prefixes = ("ros2_bridge", "execute_se3", "cyber_physical", "actuator")

        is_kinematic = any(tool_name.lower().startswith(prefix) for prefix in ros2_tool_prefixes)

        if not is_kinematic:
            return intent_payload

        workflow.logger.warning(
            f"⚠️ KINEMATIC SAFETY INTERLOCK: Physical actuation detected "
            f"for tool '{tool_name}'. Demanding WetwareAttestationContract."
        )

        # Emit a LifecycleTriggerEvent requesting biometric intervention
        await self.emit_mcp_ui_intent(
            intent_type="wetware_attestation",
            context={
                "tool_name": tool_name,
                "target_coordinate": intent_payload.get("target_coordinate"),
                "se3_transform": intent_payload.get("se3_transform"),
                "safety_level": "PHYSICAL_ACTUATION",
            },
        )

        # Halt: Wait for Oracle resolution (biometric sign-off)
        attestation = await self.enforce_physical_safety_interlock()

        if attestation is None:
            msg = (
                f"Physical Safety Interlock: WetwareAttestationContract not fulfilled "
                f"for tool '{tool_name}'. Actuation blocked."
            )
            raise PermissionError(msg)

        # Enrich the intent with the attestation receipt
        intent_payload["wetware_attestation"] = attestation
        intent_payload["safety_interlock_passed"] = True

        workflow.logger.info(
            f"✅ WetwareAttestationContract fulfilled for '{tool_name}'. Proceeding with physical actuation."
        )

        return intent_payload

    async def enforce_physical_safety_interlock(
        self,
        timeout_seconds: int = 300,
    ) -> dict[str, Any] | None:
        """Block execution until a WetwareAttestationContract is received.

        Waits for the Oracle to inject a resolution containing the
        biometric attestation. Times out after the specified duration.

        Args:
            timeout_seconds: Maximum wait time for human attestation.

        Returns:
            The attestation dict if fulfilled, None if timed out.
        """
        from datetime import timedelta

        workflow.logger.info(
            f"🔒 Physical Safety Interlock ENGAGED. Awaiting biometric attestation (timeout: {timeout_seconds}s)..."
        )

        # Clear any prior resolution
        self._current_oracle_resolution = None

        import asyncio

        # Wait for the Oracle to inject the attestation
        with contextlib.suppress(asyncio.TimeoutError):
            await workflow.wait_condition(
                lambda: self._current_oracle_resolution is not None,
                timeout=timedelta(seconds=timeout_seconds),
            )

        if self._current_oracle_resolution is None:
            workflow.logger.error("Physical Safety Interlock: Attestation timeout. Motor actuation BLOCKED.")
            return None

        attestation = self._current_oracle_resolution
        self._current_oracle_resolution = None

        # Log the InterventionReceipt to the Epistemic Ledger
        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[
                workflow.info().workflow_id,
                f"wetware-attestation-{int(workflow.now().timestamp())}",
                False,
                {"type": "WetwareAttestationContract", "attestation": attestation},
                {
                    "attestation_fulfilled": True,
                    "operator": (attestation or {}).get("operator_id", "unknown"),
                },
            ],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        return attestation
