# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import queue
import re
import sqlite3
import typing

import polars as pl
from coreason_manifest.spec.ontology import ClinicalVocabularyMappingState
from pydantic import BaseModel


class OntologicalVocabularyConnectionPool:
    """Manages a pool of active connection objects to query vocabulary tables."""

    def __init__(self, db_path: str, max_connections: int = 5):
        self._db_path = db_path
        self._max_connections = max_connections
        self._pool: queue.Queue[sqlite3.Connection] = queue.Queue(maxsize=max_connections)

        for _ in range(max_connections):
            conn = sqlite3.connect(self._db_path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            self._pool.put(conn)

    def acquire_conn(self) -> sqlite3.Connection:
        """Acquires a connection from the pool."""
        return self._pool.get(block=True, timeout=10.0)

    def release_conn(self, conn: sqlite3.Connection) -> None:
        """Returns a connection back to the pool."""
        self._pool.put(conn)

    def close_all(self) -> None:
        """Closes all connections in the pool."""
        while not self._pool.empty():
            try:
                conn = self._pool.get_nowait()
                conn.close()
            except queue.Empty:
                break


class OntologicalVocabularySolver:
    """A high-performance solver for clinical concept traversals and vocabularies."""

    def __init__(self, db_path: str):
        self._pool = OntologicalVocabularyConnectionPool(db_path)

    def resolve_vocabulary_mappings(
        self,
        query_term: str,
        target_domains: typing.Sequence[str],
        max_results: int = 10,
    ) -> typing.Sequence[ClinicalVocabularyMappingState]:
        """Resolves clinical concept mappings using SQL traversal and Polars filters."""
        conn = self._pool.acquire_conn()
        try:
            query = """
                SELECT
                    c1.concept_code AS source_code,
                    c1.vocabulary_id AS source_vocabulary,
                    c2.concept_id AS target_concept_id,
                    c2.concept_name AS target_concept_name,
                    c2.domain_id AS domain_id,
                    c2.standard_concept AS standard_concept
                FROM concept c1
                LEFT JOIN concept_relationship cr ON c1.concept_id = cr.concept_id_1 AND cr.relationship_id = 'Maps to' AND cr.invalid_reason IS NULL
                LEFT JOIN concept c2 ON cr.concept_id_2 = c2.concept_id AND c2.invalid_reason IS NULL
                WHERE (c1.concept_code = :term OR c1.concept_name LIKE :like_term) AND c1.invalid_reason IS NULL
            """

            cursor = conn.cursor()
            cursor.execute(query, {"term": query_term, "like_term": f"%{query_term}%"})
            rows = cursor.fetchall()

            # Ensure we only consider rows with mapping if they have a non-null target concept id
            valid_rows = [r for r in rows if r["target_concept_id"] is not None]

            if not valid_rows:
                query_fallback = """
                    SELECT
                        concept_code AS source_code,
                        vocabulary_id AS source_vocabulary,
                        concept_id AS target_concept_id,
                        concept_name AS target_concept_name,
                        domain_id AS domain_id,
                        standard_concept AS standard_concept
                    FROM concept
                    WHERE (concept_code = :term OR concept_name LIKE :like_term) AND invalid_reason IS NULL
                """
                cursor.execute(query_fallback, {"term": query_term, "like_term": f"%{query_term}%"})
                rows = cursor.fetchall()
            else:
                rows = valid_rows

            if not rows:
                return []

            records = [
                {
                    "source_code": str(r["source_code"]),
                    "source_vocabulary": str(r["source_vocabulary"]),
                    "target_concept_id": int(r["target_concept_id"]) if r["target_concept_id"] else None,
                    "target_concept_name": str(r["target_concept_name"]) if r["target_concept_name"] else "",
                    "domain_id": str(r["domain_id"]) if r["domain_id"] else "",
                    "standard_concept": str(r["standard_concept"]) if r["standard_concept"] else "",
                }
                for r in rows
            ]

            df = pl.DataFrame(records)
            df = df.filter(pl.col("target_concept_id").is_not_null())

            if target_domains:
                df = df.filter(pl.col("domain_id").is_in(target_domains))

            df = df.with_columns(
                pl.when(pl.col("standard_concept") == "S")
                .then(pl.lit(1.0))
                .otherwise(pl.lit(0.8))
                .alias("confidence_score")
            )

            df = df.unique(subset=["target_concept_id"])
            df = df.sort("target_concept_name")
            df_limit = df.head(max_results)

            return [
                ClinicalVocabularyMappingState(
                    source_code=row_dict["source_code"],
                    source_vocabulary=row_dict["source_vocabulary"],
                    target_concept_id=row_dict["target_concept_id"],
                    target_concept_name=row_dict["target_concept_name"],
                    domain_id=row_dict["domain_id"],
                    mapping_status="APPROVED",
                    confidence_score=row_dict["confidence_score"],
                )
                for row_dict in df_limit.to_dicts()
            ]

        finally:
            self._pool.release_conn(conn)

    def compile_constrained_filter(self, schema_model: type[BaseModel]) -> typing.Any:
        """Compiles a logit-constrained decoding or schema-matching validator using Outlines."""
        try:
            import outlines

            class OutlinesConstrainedDecoder:
                def __init__(self, model_class: type[BaseModel]):
                    self.model_class = model_class

                def generate(self, llm: typing.Any, prompt: str) -> typing.Any:
                    try:
                        generator = outlines.generator.Generator(llm, output_type=self.model_class)
                        return generator(prompt)
                    except Exception:
                        import json

                        raw_text = str(llm(prompt))
                        json_match = re.search(r"\{.*\}", raw_text, re.DOTALL)
                        if json_match:
                            raw_text = json_match.group(0)
                        return self.model_class.model_validate(json.loads(raw_text))

            return OutlinesConstrainedDecoder(schema_model)
        except Exception:

            class FallbackConstrainedDecoder:
                def __init__(self, model_class: type[BaseModel]):
                    self.model_class = model_class

                def generate(self, llm: typing.Any, prompt: str) -> typing.Any:
                    import json

                    raw_text = str(llm(prompt))
                    json_match = re.search(r"\{.*\}", raw_text, re.DOTALL)
                    if json_match:
                        raw_text = json_match.group(0)
                    return self.model_class.model_validate(json.loads(raw_text))

            return FallbackConstrainedDecoder(schema_model)

    def close(self) -> None:
        """Closes all resources."""
        self._pool.close_all()
