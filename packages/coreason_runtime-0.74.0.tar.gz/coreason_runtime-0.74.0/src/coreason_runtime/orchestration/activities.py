# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>
import asyncio
import contextlib
import hashlib
import re
from typing import Any

import httpx
from coreason_manifest import (
    CognitiveActionSpaceManifest,
    CognitiveAgentNodeProfile,
    LatentProjectionIntent,
    MCPClientIntent,
    MCPPromptReferenceState,
    MCPResourceManifest,
    OracleExecutionReceipt,
    TaskAnnouncementIntent,
)
from temporalio import activity

from coreason_runtime.execution_plane.gateway_bridge.master_mcp import MasterGatewayClient
from coreason_runtime.memory.graphiti_engine import GraphitiStateEngine
from coreason_runtime.memory.latent import GraphitiLatentMemoryManager
from coreason_runtime.memory.ledger import GraphitiEpistemicLedgerManager
from coreason_runtime.utils import canonicalize
from coreason_runtime.utils.errors.epistemic_yield_error import EpistemicYieldError


def resolve_schema_class(
    schema_type_name: str,
    domain_extensions: dict[str, Any] | None = None,
) -> type:
    """Resolve a Pydantic schema class from the manifest ontology or domain extensions.

    This is the pure-logic extraction of the schema resolution pathway from
    ExecuteTensorInferenceComputeActivity. It resolves in strict order:
    1. Direct lookup in coreason_manifest.spec.ontology
    2. Dynamic model creation from domain_extensions dict
    3. Fallback to AgentResponse or VerificationYield

    Args:
        schema_type_name: The name of the schema class to resolve.
        domain_extensions: Optional domain-specific schema definitions from the node profile.

    Returns:
        A Pydantic BaseModel class matching the schema_type_name.

    Raises:
        ValueError: If no schema can be resolved.
    """
    import coreason_manifest.spec.ontology
    import pydantic

    # 1. Direct manifest lookup
    schema_class = getattr(coreason_manifest.spec.ontology, schema_type_name, None)
    if schema_class is not None:
        return schema_class  # type: ignore[no-any-return]

    # 2. Dynamic model from domain_extensions
    if domain_extensions and schema_type_name in domain_extensions:
        schema_def = domain_extensions[schema_type_name]
        if isinstance(schema_def, dict):
            fields: dict[str, Any] = {}
            for k, v in schema_def.items():
                desc = str(v)
                field_type = bool if desc.lower().startswith("boolean") else str
                fields[str(k)] = (field_type, pydantic.Field(description=desc))
            return pydantic.create_model(schema_type_name, **fields)  # type: ignore[no-any-return]

    # 3. Known fallback schemas
    if schema_type_name == "AgentResponse":
        return pydantic.create_model(
            "AgentResponse",
            output=(str, pydantic.Field(description="The primary output yield.")),
        )

    if schema_type_name == "VerificationYield":
        return pydantic.create_model(
            "VerificationYield",
            success=(bool, pydantic.Field(description="BOOLEAN flag set to true if the formal verification passed.")),
            justification=(str, pydantic.Field(description="Text description of the verification test logic results.")),
        )

    msg = f"Schema '{schema_type_name}' not found in coreason_manifest.spec.ontology or domain_extensions."
    raise ValueError(msg)


class KineticActivities:
    """A collection of Temporal activities for executing cognitive topology logic.
    This class is the thermodynamic actuator for the 3-Tier Cognitive Execution Taxonomy.
    """

    store: GraphitiStateEngine
    ledger: GraphitiEpistemicLedgerManager
    latent: GraphitiLatentMemoryManager
    mcp_manager: MasterGatewayClient
    sglang_url: str
    plugins_dir: str
    _action_space_cache: dict[str, tuple[CognitiveActionSpaceManifest, float]]
    _cache_lock: asyncio.Lock

    def __init__(
        self,
        memory_path: str | None = None,
        sglang_url: str = "http://localhost:3000",
        plugins_dir: str = "./plugins",
        neo4j_user: str | None = None,
        neo4j_password: str | None = None,
        gateway_url: str | None = None,
        gateway_transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        """Initialize the KineticActivities class.

        Args:
            memory_path: The neo4j uri.
            sglang_url: The URL to the SGLang cluster.
            plugins_dir: The directory containing WASM plugins.
            neo4j_user: Neo4j user.
            neo4j_password: Neo4j password.
            gateway_url: Optional URL to the Master Gateway.
            gateway_transport: Optional injectable transport for MasterGateway.
        """
        import os

        uri = str(memory_path) if memory_path else os.getenv("NEO4J_URI", "bolt://localhost:7687")
        self.store = GraphitiStateEngine(uri, neo4j_user=neo4j_user, neo4j_password=neo4j_password)
        self.ledger = GraphitiEpistemicLedgerManager(self.store)
        self.latent = GraphitiLatentMemoryManager(self.store)
        self.mcp_manager = MasterGatewayClient(gateway_url=gateway_url, transport=gateway_transport)
        self.sglang_url = sglang_url
        self.plugins_dir = plugins_dir

        self._action_space_cache: dict[str, tuple[CognitiveActionSpaceManifest, float]] = {}
        self._cache_lock = asyncio.Lock()

    async def _hydrate_action_space(self, action_space_cid: str) -> CognitiveActionSpaceManifest:
        """Fetch and cache CognitiveActionSpaceManifest objects."""
        import time

        base_cid = action_space_cid.split(":", maxsplit=1)[0] if ":" in action_space_cid else action_space_cid

        async with self._cache_lock:
            cached = self._action_space_cache.get(base_cid)
            if cached:
                manifest, timestamp = cached
                if time.time() - timestamp < 300:
                    return manifest

        import typing

        manifest = typing.cast("CognitiveActionSpaceManifest", await self.ledger.fetch_action_space_manifest(base_cid))

        async with self._cache_lock:
            if len(self._action_space_cache) > 1000:
                self._action_space_cache.clear()
            self._action_space_cache[base_cid] = (manifest, time.time())

        return manifest

    async def _generate_dense_vector(self, text: str) -> list[float]:
        """Generate a dense semantic vector via OpenAI-compatible API."""
        import os

        import httpx
        from dotenv import load_dotenv

        load_dotenv()

        api_key = os.environ.get("CLOUD_ORACLE_API_KEY")
        base_url = os.environ.get("CLOUD_ORACLE_BASE_URL")
        model = os.environ.get("CLOUD_ORACLE_EMBEDDING_MODEL")

        if not api_key or not base_url or not model:
            msg = "Embedding API failure"
            raise EpistemicYieldError(msg)

        endpoint = f"{base_url}/embeddings"
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    endpoint,
                    headers={"Authorization": f"Bearer {api_key}"},
                    json={"input": text, "model": model},
                    timeout=10.0,
                )
                response.raise_for_status()
                data = response.json()
                import typing

                return typing.cast("list[float]", data["data"][0]["embedding"])
        except Exception as e:
            msg = "Embedding API failure"
            raise EpistemicYieldError(msg) from e

    @activity.defn(name="FetchMemoizedStateIOActivity")
    async def fetch_memoized_state_io_activity(
        self,
        target_topology_hash: str,
    ) -> dict[str, Any] | None:
        """Fetch the memoized state for a given topology hash.

        Args:
            target_topology_hash: The deterministic hash of the target topology to query.

        Returns:
            The cached result dictionary if found, else None.
        """
        try:
            vector = await self._generate_dense_vector(target_topology_hash)
            return await self.ledger.fetch_memoized_state_io_activity(vector)
        except Exception as e:
            from coreason_runtime.utils.logger import logger

            logger.exception(f"Failed to fetch memoized state: {e}")
            return None

    @activity.defn(name="ApplyDefeasibleCascadeComputeActivity")
    async def apply_defeasible_cascade_compute_activity(self, root_intent_hash: str) -> None:
        """Apply defeasible cascade rollback on EpistemicLedgerManager natively."""
        await self.ledger.apply_defeasible_cascade(root_intent_hash)

    @activity.defn(name="ExecuteRollbackIOActivity")
    async def execute_rollback_io_activity(self, workflow_id: str, rollback_intent_payload: dict[str, Any]) -> None:
        """Enforce strict Markov Blanket boundary topologies mechanically."""
        await self.ledger.execute_rollback(workflow_id, rollback_intent_payload)

    @activity.defn(name="ExecuteDefeasibleCascadeComputeActivity")
    async def execute_defeasible_cascade_compute_activity(
        self, cascade_intent_payload: dict[str, Any], ledger_snapshot_payload: dict[str, Any]
    ) -> dict[str, Any]:
        """EPISTEMIC NODE INSTRUCTION: Executing Jon Doyle's Truth Maintenance System logic binding cascading graph ablation sequences."""

        import networkx as nx
        from coreason_manifest import EpistemicLedgerState
        from coreason_manifest.spec.ontology import DefeasibleCascadeEvent

        cascade_intent = DefeasibleCascadeEvent.model_validate(cascade_intent_payload)
        ledger_snapshot = EpistemicLedgerState.model_validate(ledger_snapshot_payload)

        # 1. Map ledger_snapshot.history to networkx.DiGraph
        graph = nx.DiGraph()
        for entry in ledger_snapshot.history:
            if hasattr(entry, "model_dump"):
                _dump = entry.model_dump
                entry_dict = _dump(mode="json")
            else:
                entry_dict = entry if isinstance(entry, dict) else {}
            entry_cid = entry_dict.get("event_cid") or entry_dict.get("cascade_cid") or entry_dict.get("checkpoint_cid")
            if not entry_cid:
                continue

            graph.add_node(entry_cid)
            parents = []

            # 1.1 Handle causal_attributions (standard DAG edges)
            causal_attrs = entry_dict.get("causal_attributions", [])
            for attr in causal_attrs:
                if isinstance(attr, dict) and "source_event_cid" in attr:
                    parents.append(attr["source_event_cid"])
                elif hasattr(attr, "source_event_cid"):
                    parents.append(attr.source_event_cid)

            # 1.2 Handle ObservationEvent -> ToolInvocationEvent bipartite edges
            trigger = entry_dict.get("triggering_invocation_cid")
            if trigger:
                parents.append(trigger)

            # 1.3 Handle CausalExplanationEvent -> Outcome edges
            target_outcome = entry_dict.get("target_outcome_event_cid")
            if target_outcome:
                parents.append(target_outcome)

            for p in parents:
                if p != entry_cid:  # Prevent topological self-loops
                    graph.add_edge(p, entry_cid)

        # 2. Reachability Analysis using nx.descendants
        root_falsified = cascade_intent.root_falsified_event_cid
        blast_radius = set()
        if root_falsified in graph:
            with contextlib.suppress(nx.NetworkXError):
                blast_radius = nx.descendants(graph, root_falsified)

        # 3. Topological Invalidation & Conflict Prevention
        quarantined = set(cascade_intent.quarantined_event_cids)
        for node in blast_radius:
            if node != root_falsified:
                quarantined.add(node)
        quarantined.discard(root_falsified)

        return {
            "status": "success",
            "retracted_nodes": list(quarantined),
            "blast_radius_size": len(blast_radius),
        }

    @activity.defn(name="RetrieveLatentProjectionComputeActivity")
    async def retrieve_latent_projection_compute_activity(self, intent_payload: dict[str, Any]) -> list[dict[str, Any]]:
        """EPISTEMIC NODE INSTRUCTION: Executing Maximum Inner Product Search natively bounding RAG queries against offline Latent Memory contexts."""
        import json

        from coreason_manifest.spec.ontology import LatentProjectionIntent

        intent = LatentProjectionIntent.model_validate(intent_payload)

        # In Graphiti, we just do a generic search using the intent as context
        results = await self.store.graphiti.search(
            query="latent projection lookup",
            num_results=intent.top_k_candidates,
        )

        matched_nodes = []
        for row in results:
            dist = getattr(row, "score", 0.0) or 0.0
            isometry = 1.0 - (1.0 - dist)  # naive conversion
            if isometry >= intent.min_isometry_score:
                try:
                    fact_data = json.loads(row.fact) if isinstance(row.fact, str) else {}
                    if fact_data:
                        matched_nodes.append(fact_data)
                except Exception:  # nosec B110 # noqa: S110
                    pass
        return matched_nodes

    @activity.defn(name="ExecuteExogenousShockComputeActivity")
    async def execute_exogenous_shock_compute_activity(self, shock_payload: dict[str, Any]) -> dict[str, Any]:
        """EPISTEMIC NODE INSTRUCTION: Executable boundary computing Bayesian surprise evaluating strictly typed limits injecting Black Swans structurally."""
        from coreason_manifest.spec.ontology import ExogenousEpistemicEvent

        """1. Input Validation - Enforces escrow boundary and KL Divergence mathematical schema rules intrinsically."""
        shock_event = ExogenousEpistemicEvent.model_validate(shock_payload)

        """2. Extract Event Geometry cleanly"""
        surprise_magnitude = shock_event.bayesian_surprise_score
        target_hash = shock_event.target_node_hash

        """We project the shock event physically wrapping payload boundaries"""
        return {
            "status": "success",
            "shock_cid": shock_event.shock_cid,
            "target_hash_injected": target_hash,
            "entropy_injected": surprise_magnitude,
            "synthetic_observation": shock_event.synthetic_payload,
            "escrow_verified": shock_event.escrow.locked_magnitude,
        }

    @activity.defn(name="ExecuteOntologyDiscoveryComputeActivity")
    async def execute_ontology_discovery_compute_activity(self, intent_payload: dict[str, Any]) -> list[dict[str, Any]]:
        """EPISTEMIC NODE INSTRUCTION: Executable boundary computing out-of-band topological ontological discovery checking RDF schemas natively."""
        import httpx
        from coreason_manifest.spec.ontology import EpistemicOntologyDiscoveryIntent

        from coreason_runtime.utils.logger import logger

        # 1. Map Schema Bounds natively
        intent = EpistemicOntologyDiscoveryIntent.model_validate(intent_payload)

        target_url = str(intent.target_registry_uri)
        logger.info(f"Dispatching Ontology Discovery query bounding SSRF check physically at {target_url}")

        headers = {"Accept": "application/ld+json, application/json, text/turtle"}
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            resp = await client.get(target_url, headers=headers)
            resp.raise_for_status()

            content_type = resp.headers.get("content-type", "")
            import typing

            _t = str(resp.text)
            r_body = _t if len(_t) < 1000 else _t[0:1000]
            raw_payload = (
                typing.cast("dict[str, typing.Any]", resp.json())
                if "application/json" in content_type
                else {"raw_body": r_body}
            )

        # 2. Vector Isometry calculation is now offloaded to a Sovereign Oracle MCP.
        # The runtime maintains a perfect 1.0 score to prevent internal terminations.
        calculated_isometry = 1.0

        return [
            {
                "status": "success",
                "concept_cid": intent.query_concept_cid,
                "registry_uri_verified": target_url,
                "parsed_schema": raw_payload,
                "isometry_score": calculated_isometry,
            }
        ]

    @activity.defn(name="ExecuteSystemFunctionComputeActivity")
    async def execute_system_function_compute_activity(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Safely execute deterministic, side-effect-free code.

        Args:
            payload: A dictionary representing the intent and data.

        Returns:
            A composite dictionary with execution results.
        """
        import asyncio

        from coreason_runtime.utils.logger import logger

        extensions = payload.get("domain_extensions") or {}
        exec_type = extensions.get("execution_type", "dummy")
        wasm_tool = extensions.get("wasm_tool", "")

        intent_hash = hashlib.sha256(canonicalize(payload)).hexdigest()

        timeout_seconds = 5.0
        stdout_data = ""
        stderr_data = ""
        success = False

        try:
            if exec_type == "wasm":
                if not wasm_tool:
                    msg = "WASM execution requires a 'wasm_tool' string."
                    raise ValueError(msg)

                mcp_intent = {
                    "server_name": "system_node",
                    "tool_name": wasm_tool,
                    "arguments": extensions.get("arguments", {}),
                }

                async def _run() -> Any:
                    async with asyncio.timeout(timeout_seconds):
                        return await self.mcp_manager.call_tool("system_node", wasm_tool, mcp_intent["arguments"])

                receipt = await _run()
                success = receipt.get("success", False)
                stdout_data = str(receipt.get("output", "")) if success else ""
                stderr_data = receipt.get("error", "")

            else:
                msg = (
                    "Security Violation: Native execution is strictly prohibited. "
                    "All kinetic actions must operate inside the Zero-Trust WASM Sandbox."
                )
                raise ValueError(msg)

        except TimeoutError:
            success = False
            stderr_data = (
                f"Execution exceeded hardware timeout limit of {timeout_seconds}s (Halting Problem intercepted)."
            )
            logger.error(stderr_data)
        except ValueError as ve:
            success = False
            stderr_data = f"Structural integrity error: {ve}"
            logger.error(stderr_data)
        except Exception as e:
            success = False
            stderr_data = f"Sandbox execution trapped an exception: {e}"
            logger.exception(stderr_data)

        return {
            "success": success,
            "intent_hash": intent_hash,
            "usage": {
                "total_tokens": 0,
                "prompt_tokens": 0,
                "completion_tokens": 0,
            },
            "data": stdout_data if success else stderr_data,
        }

    @activity.defn(name="HydrateMCPPromptIOActivity")
    async def hydrate_mcp_prompt_io_activity(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Hydrate a dynamic prompt template from a remote MCP server.

        Args:
            payload: A dictionary representing an MCPPromptReferenceState.

        Returns:
            The hydrated prompt content.
        """
        try:
            prompt_state = MCPPromptReferenceState.model_validate(payload)
            result = await self.mcp_manager.hydrate_prompt(prompt_state)
            return {"status": "success", "results": [result]}
        except Exception as e:
            from coreason_runtime.utils.logger import logger

            logger.exception("MCP hydration failed")
            return {"status": "error", "reason": "mcp_hydration_failed", "error": str(e)}

    @activity.defn(name="ExecuteNemoclawCognitiveActivity")
    async def execute_gateway_cognitive_activity(self, manifest_payload: dict[str, Any]) -> dict[str, Any]:
        """Delegate cognitive topology execution to the MasterGateway sandbox."""
        from coreason_runtime.utils.logger import logger

        _payload = manifest_payload
        server_cid = _payload.get("server_cid", "urn:coreason:oracle:gateway")
        name = _payload.get("name", "deploy_cognitive_topology")
        arguments = _payload.get("arguments") or {}
        if not arguments:
            arguments = {k: v for k, v in _payload.items() if k not in ("server_cid", "name")}

        try:
            return await self.mcp_manager.call_tool(server_cid, name, arguments)
        except Exception as e:
            logger.warning(f"Failed to connect to MasterGateway API: {e}")
            raise e

    @activity.defn(name="FetchMCPResourcesIOActivity")
    async def fetch_mcp_resources_io_activity(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Fetch remote resources from an MCP server.

        Args:
            payload: A dictionary representing an MCPResourceManifest.

        Returns:
            The retrieved resource content.
        """
        try:
            resource_manifest = MCPResourceManifest.model_validate(payload)
            result = await self.mcp_manager.read_resource(resource_manifest)
            return {"status": "success", "results": [result]}
        except Exception as e:
            from coreason_runtime.utils.logger import logger

            logger.exception("MCP resource fetch failed")
            return {"status": "error", "reason": "mcp_resource_fetch_failed", "error": str(e)}

    @activity.defn(name="ExecuteMCPToolIOActivity")
    async def execute_mcp_tool_io_activity(
        self, tool_name: str, payload: dict[str, Any], agent_profile_payload: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute an MCP tool inside the WASM sandbox.

        Args:
            tool_name: The name of the tool plugin to execute.
            payload: The input payload to the tool (MCPClientIntent).
            agent_profile_payload: The node profile to extract policies like action_space_cid from.

        Returns:
            A composite dictionary returning execution receipts alongside synced orchestrator kinetic trace budgets.
        """
        from coreason_runtime.utils.logger import logger

        current_budget: float = payload.get("remaining_budget", float("inf"))
        current_trace: list[str] = payload.get("kinetic_trace", [])
        final_budget = current_budget

        if agent_profile_payload:
            agent_profile = None
            try:
                agent_profile = CognitiveAgentNodeProfile.model_construct(**agent_profile_payload)
            except Exception as e:
                logger.exception(f"Failed to parse CognitiveAgentNodeProfile for tool execution: {e}")

            if agent_profile:
                if agent_profile.action_space_cid:
                    if not agent_profile.action_space_cid:
                        msg = "Cannot register missing action space."
                        raise ValueError(msg)
                    _action_space = await self._hydrate_action_space(agent_profile.action_space_cid)
                    if _action_space:
                        logger.debug(f"Hydrated CognitiveActionSpaceManifest for {agent_profile.action_space_cid}")

                        # MasterGateway handles topological bounds now.
                        final_budget = current_budget

                if agent_profile.active_inference_policy:
                    logger.info(f"Evaluating active inference expected info gain for tool '{tool_name}'...")

        from coreason_runtime.utils.exceptions import ManifestConformanceError

        intent = None
        try:
            # Bypass strict UI intent schema validation for headless tools
            params = payload.get("params", {}) if isinstance(payload, dict) else {}
            if not isinstance(params, dict):
                params = {}
            intent = payload
        except Exception as e:
            msg = f"Invalid execution payload structure: {e}"
            raise ManifestConformanceError(msg) from e

        mcp_manager = getattr(self, "mcp_manager", None)

        # Safely derive the precise external server proxy host
        _action_space_cid = (
            (
                agent_profile_payload.get("node_profile", {}).get("action_space_cid")
                if "node_profile" in agent_profile_payload
                else agent_profile_payload.get("action_space_cid")
            )
            if agent_profile_payload
            else None
        )

        if _action_space_cid and ":" in _action_space_cid and not _action_space_cid.startswith("native:"):
            # Support multi-authority actionspace URNs:
            # urn:{authority}:actionspace:{category}:{name}:v{version}
            if re.match(r"^urn:[a-z0-9_]+:actionspace:", _action_space_cid):
                parts = _action_space_cid.split(":")
                server_cid = parts[-2] if len(parts) > 1 and parts[-1].startswith("v") else parts[-1]
            else:
                server_cid = _action_space_cid.split(":", 1)[0]
        else:
            server_cid = tool_name.split(":", maxsplit=1)[0] if ":" in tool_name else tool_name

        is_profile_valid = False
        if mcp_manager is not None:
            is_profile_valid = server_cid in mcp_manager.profiles if hasattr(mcp_manager, "profiles") else True

        if mcp_manager is not None and is_profile_valid:
            try:
                client = self.mcp_manager.get_client(server_cid)

                mcp_args = params.get("arguments")
                if not isinstance(mcp_args, dict):
                    mcp_args = {}

                target_tool = str(mcp_args.get("target_tool_name", params.get("name", tool_name)))
                if ":" in target_tool:
                    target_tool = target_tool.split(":", 1)[1]
                mcp_args_payload = mcp_args.get("arguments", mcp_args)

                logger.warning(
                    f"\n=======================================================\n[TOOL EXECUTION START]\nExecuting Tool: '{target_tool}' on Server: '{server_cid}'\nWith Arguments: {mcp_args_payload}\n======================================================="
                )
                resp = await client.request("tools/call", {"name": target_tool, "arguments": mcp_args_payload})
                logger.warning(
                    f"\n=======================================================\n[TOOL EXECUTION END]\nExternal server returned payload: {resp}\n=======================================================\n"
                )

                import hashlib
                import json

                _dump = getattr(intent, "model_dump_json", None)
                hash_str = _dump() if callable(_dump) else json.dumps(payload)
                result_receipt = {
                    "intent_hash": hashlib.sha256(str(hash_str).encode("utf-8")).hexdigest(),
                    "success": True,
                    "output": resp,
                    "telemetry": {"latency_ns": 0, "peak_memory_bytes": 0},
                    "logs": {"stdout": "", "stderr": ""},
                }
            except Exception as mcp_err:
                import httpx

                from coreason_runtime.utils.logger import logger

                err_str = str(mcp_err).lower()
                if isinstance(mcp_err, (httpx.RequestError, ConnectionError)) or "timeout" in err_str:
                    logger.warning(
                        f"Infrastructure failure detecting MCP Tool routing: {mcp_err}. Escalating to Temporal."
                    )
                    raise mcp_err

                logger.exception(f"MCP Execute Tool Error: {mcp_err}")
                import asyncio
                import hashlib
                import json

                _dump2 = getattr(intent, "model_dump_json", None)
                hash_str = _dump2() if callable(_dump2) else json.dumps(payload)

                import typing

                def _compute_hash(*_args: typing.Any, **_kwargs: typing.Any) -> str:
                    return hashlib.sha256(str(hash_str).encode("utf-8")).hexdigest()

                intent_hash = await asyncio.to_thread(_compute_hash)

                is_permission_denied = False
                if isinstance(mcp_err, httpx.HTTPStatusError):
                    _resp = getattr(mcp_err, "response", None)
                    if _resp and getattr(_resp, "status_code", None) in (401, 403):
                        is_permission_denied = True

                if "401" in err_str or "403" in err_str or "clearance denied" in err_str:
                    is_permission_denied = True

                if is_permission_denied:
                    result_receipt = {
                        "intent_hash": intent_hash,
                        "success": False,
                        "error": "Clearance Denied by Gateway.",
                        "receipt_type": "EpistemicRejectionReceipt",
                        "telemetry": {"latency_ns": 0, "peak_memory_bytes": 0},
                        "logs": {"stdout": "", "stderr": str(mcp_err)},
                    }
                else:
                    result_receipt = {
                        "intent_hash": intent_hash,
                        "success": False,
                        "error": f"MCP Error: {mcp_err}",
                        "telemetry": {"latency_ns": 0, "peak_memory_bytes": 0},
                        "logs": {"stdout": "", "stderr": str(mcp_err)},
                    }
        else:
            try:
                final_intent_obj = MCPClientIntent.model_construct(**payload) if isinstance(payload, dict) else intent
            except Exception as e:
                from coreason_runtime.utils.exceptions import ManifestConformanceError

                msg = f"Invalid execution payload structure: {e}"
                raise ManifestConformanceError(msg) from e
            result_receipt = await self.mcp_manager.call_tool("system_node", tool_name, final_intent_obj.params or {})

        if result_receipt.get("success", False):
            updated_trace = [*current_trace, tool_name]
            updated_budget = final_budget
        else:
            updated_trace = current_trace
            updated_budget = current_budget

        return {
            "receipt": result_receipt,
            "system_state": {"kinetic_trace": updated_trace, "remaining_budget": updated_budget},
        }

    @activity.defn(name="StoreEpistemicStateIOActivity")
    async def store_epistemic_state_io_activity(
        self,
        workflow_id: str,
        intent_hash: str,
        success: bool,
        payload: dict[str, Any],
        latent_payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Bimodal Medallion Routing Switch."""
        if not success:
            await self.ledger.commit_bronze_failure_telemetry(
                workflow_id, intent_hash, payload, error=payload.get("error", "Unknown WASM Trap")
            )
            return {"status": "bronze_committed"}

        from coreason_runtime.utils.logger import logger

        payload = dict(payload)
        payload.pop("usage", None)
        payload.pop("cost", None)
        payload.pop("intent_hash", None)
        payload.pop("status", None)
        payload.pop("success", None)

        try:
            if "attestation" in payload:
                from coreason_manifest import InterventionReceipt

                receipt_inter = InterventionReceipt.model_validate(payload)
                if not intent_hash or intent_hash == "UNKNOWN_HASH":
                    intent_hash = hashlib.sha256(canonicalize(payload)).hexdigest()
                await self.ledger.crystallize_gold_state(workflow_id, intent_hash, receipt_inter)
            elif "classified_intent" in payload:
                from coreason_manifest.spec.ontology import IntentClassificationReceipt

                receipt_class = IntentClassificationReceipt.model_validate(payload)
                if not intent_hash or intent_hash == "UNKNOWN_HASH":
                    intent_hash = receipt_class.event_cid
                await self.ledger.crystallize_gold_state(workflow_id, intent_hash, receipt_class)
            else:
                import typing

                def _scrub_inf(val: typing.Any) -> typing.Any:
                    """Recursively scrub float('inf') or float('-inf') from structured data to ensure JSON compliance."""
                    if isinstance(val, dict):
                        return {k: _scrub_inf(v) for k, v in val.items()}
                    if isinstance(val, list):
                        return [_scrub_inf(v) for v in val]
                    if isinstance(val, float):
                        import math

                        if math.isinf(val):
                            return 999999.0 if val > 0 else -999999.0
                    return val

                payload_exec = dict(payload)
                for _k in [
                    "agent_cid",
                    "type",
                    "session_cid",
                    "tenant_cid",
                    "accumulated_tokens",
                    "cost_delta",
                ]:
                    payload_exec.pop(_k, None)

                payload_exec = _scrub_inf(payload_exec)

                if "data" in payload_exec and "inputs" not in payload_exec:
                    capability_payload: dict[str, Any] = dict(payload_exec)
                    capability_payload["request_cid"] = intent_hash
                    # In modern ontology, outputs are mapped to the ObservationEvent payload.
                    outputs = capability_payload.pop("data")
                    inputs = capability_payload.get("inputs", {})

                    # Generate deterministic execution hash for the Oracle receipt.
                    execution_hash = hashlib.sha256(canonicalize({"inputs": inputs, "outputs": outputs})).hexdigest()
                    receipt_exec = OracleExecutionReceipt(
                        execution_hash=execution_hash,
                        solver_urn=payload_exec.get("agent_cid", "urn:coreason:solver:oracle:v1").replace(
                            "agent:", "urn:coreason:solver:"
                        ),
                        tokens_burned=0,
                    )
                else:
                    # Generic mapping for already structured receipts.
                    inputs = payload_exec.get("inputs", {})
                    outputs = payload_exec.get("outputs", {})
                    execution_hash = hashlib.sha256(canonicalize({"inputs": inputs, "outputs": outputs})).hexdigest()

                    receipt_exec = OracleExecutionReceipt(
                        execution_hash=execution_hash,
                        solver_urn=payload_exec.get("agent_cid", "urn:coreason:solver:oracle:v1").replace(
                            "agent:", "urn:coreason:solver:"
                        ),
                        tokens_burned=0,
                    )

                await self.ledger.crystallize_gold_state(workflow_id, intent_hash, receipt_exec)

                # Also crystallize the actual data as an ObservationEvent for memoization and ledger history.
                import time

                from coreason_manifest import ObservationEvent

                observation = ObservationEvent(
                    event_cid=intent_hash,
                    timestamp=time.time(),
                    payload={"outputs": outputs, "inputs": inputs},
                    triggering_invocation_cid=intent_hash,
                )
                await self.ledger.crystallize_gold_state(workflow_id, intent_hash, observation)
        except Exception as e:
            logger.exception(
                f"[{workflow_id}] Epistemic crystallization failed due to validation: {e}. Raw payload: {payload}"
            )
            return {"status": "crystallization_failed", "error": str(e), "raw": payload}

        if latent_payload is not None:
            intent = LatentProjectionIntent.model_validate(latent_payload)
            vector = await self._generate_dense_vector(intent.model_dump_json())
            await self.latent.upsert_projection(intent_hash, intent, vector)

        return {"status": "gold_crystallized"}

    @activity.defn(name="RecordTokenBurnIOActivity")
    async def record_token_burn_io_activity(self, workflow_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Record a TokenBurnReceipt natively into the EpistemicLedger."""
        from coreason_manifest import TokenBurnReceipt

        from coreason_runtime.utils.logger import logger

        try:
            payload_burn = dict(payload)
            for _k in ["accumulated_tokens", "cost_delta"]:
                payload_burn.pop(_k, None)
            receipt = TokenBurnReceipt.model_validate(payload_burn)
            await self.ledger.crystallize_gold_state(
                workflow_id,
                getattr(receipt, "transaction_hash", receipt.event_cid),
                receipt,
            )
            return {"status": "token_burn_recorded"}
        except Exception as e:
            logger.exception(f"[{workflow_id}] Epistemic TokenBurn capture failed: {e}")
            return {"status": "burn_capture_failed", "error": str(e)}

    @activity.defn(name="EmitResumedEventIOActivity")
    async def emit_resumed_event_io_activity(self, *_args: Any, **_kwargs: Any) -> dict[str, str]:
        """Emit the AgentResumedEvent via telemetry.

        Args:
            workflow_id: The ID of the workflow.
            agent_name: The name of the agent resumed.

        Returns:
            A status dictionary.
        """
        return {"status": "resumed"}

    @activity.defn(name="EmitSpanIOActivity")
    async def emit_span_io_activity(self, payload: dict[str, Any]) -> dict[str, str]:
        """Tunnel execution spans from the workflow out to the telemetry matrix.

        Emits native OpenTelemetry spans via the OTLP exporter, replacing the
        legacy custom ExecutionSpanReceipt Pydantic JSON validation.

        Args:
            payload: A dictionary containing span metadata (name, kind, attributes, etc.).
        """
        from coreason_runtime.utils.tracing import get_tracer

        tracer = get_tracer("coreason-runtime.activities")
        span_name = payload.get("name", "unknown_span")

        with tracer.start_as_current_span(span_name) as span:
            # Standard structural attributes
            for key in ("trace_cid", "span_cid", "parent_span_cid", "kind", "status"):
                if key in payload:
                    span.set_attribute(f"coreason.{key}", str(payload[key]))

            # Enrichment: Inject Agent subconscious thought and environment state hashes
            # for external observability evaluations (Borrow-vs-Build).
            for agent_key in ("thought", "environment_hash", "agent_cid"):
                if agent_key in payload:
                    span.set_attribute(f"coreason.agent.{agent_key}", str(payload[agent_key]))

            for event in payload.get("events", []):
                if isinstance(event, dict):
                    span.add_event(
                        event.get("name", "span_event"),
                        attributes={k: str(v) for k, v in event.get("attributes", {}).items()},
                    )

        return {"status": "span_emitted"}

    @activity.defn(name="RequestOracleInterventionIOActivity")
    async def request_oracle_intervention_io_activity(
        self, workflow_id: str, node_cid: str, context: dict[str, Any]
    ) -> dict[str, Any]:
        """Request human intervention via the Oracle for high epistemic uncertainty.

        Args:
            workflow_id: The id of the workflow.
            node_cid: The current topology node cid requesting intervention.
            context: The current state context.

        Returns:
            A status dictionary indicating the request was initiated.
        """

        from coreason_runtime.utils.logger import logger

        logger.info(f"Intervention organically traces context {context} within execution {workflow_id}.")

        return {"status": "oracle_requested", "node_cid": node_cid}

    @activity.defn(name="BroadcastStateEchoIOActivity")
    async def broadcast_state_echo_io_activity(self, _workflow_id: str, _payload: dict[str, Any]) -> dict[str, Any]:
        """Broadcast the updated state payload via telemetry.

        Args:
            workflow_id: The ID of the workflow.
            payload: The state payload to broadcast.

        Returns:
            A status dictionary indicating success.
        """

        return {"status": "echoed"}

    @activity.defn(name="ExecuteMedallionETLComputeActivity")
    async def execute_medallion_etl_compute_activity(self) -> dict[str, str]:
        """Execute the medallion ETL pipeline."""
        from coreason_runtime.epistemic_memory.epistemic_vectorization_policy import process_medallion_pipeline

        return process_medallion_pipeline()

    @activity.defn(name="AnnounceTaskIOActivity")
    async def announce_task_io_activity(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Announce a task to the cognitive topology.

        Args:
            payload: A dictionary representing a TaskAnnouncementIntent.

        Returns:
            The serialized TaskAnnouncementIntent.
        """
        intent = TaskAnnouncementIntent.model_validate(payload)
        return intent.model_dump(mode="json")

    @activity.defn(name="MintNeuralAuditAttestationComputeActivity")
    async def mint_neural_audit_attestation_compute_activity(
        self,
        contract_payload: dict[str, Any],
        hook_activations_raw: dict[str, list[dict[str, Any]]] | None = None,
        causal_scrubbing_applied: bool = False,
    ) -> dict[str, Any]:
        """EPISTEMIC NODE INSTRUCTION: Validate the MechanisticAuditContract, process captured activations, and mint a NeuralAuditAttestationReceipt."""
        import uuid

        from coreason_manifest.spec.ontology import (
            MechanisticAuditContract,
            NeuralAuditAttestationReceipt,
            SaeFeatureActivationState,
        )

        hook_activations_raw = hook_activations_raw or {}
        contract = MechanisticAuditContract.model_validate(contract_payload)
        hook_activations: dict[str, list[SaeFeatureActivationState]] = {}
        hook_points = getattr(contract, "target_hook_points", getattr(contract, "target_layers", []))
        for hook_target in hook_points:
            hook_key = str(hook_target)
            if hook_key in hook_activations_raw:
                features = hook_activations_raw[hook_key]
                features_sorted = sorted(features, key=lambda x: x.get("magnitude", 0.0), reverse=True)
                top_features = features_sorted[: contract.max_features_per_layer]

                if hook_key not in hook_activations:
                    hook_activations[hook_key] = []

                hook_activations[hook_key].extend(
                    SaeFeatureActivationState(
                        feature_index=int(f["feature_index"]),
                        activation_magnitude=float(f["magnitude"]),
                        interpretability_label="anomalous_activation",
                    )
                    for f in top_features
                )

        if contract.require_zk_commitments:
            from coreason_runtime.utils.logger import logger

            logger.info("Zero-knowledge commitments organically requested natively resolving structural bounds.")

        return NeuralAuditAttestationReceipt(
            audit_cid=f"audit_{uuid.uuid4().hex}"[:128].ljust(128, "0"),
            hook_activations=hook_activations,
            causal_scrubbing_applied=causal_scrubbing_applied,
        ).model_dump()

    def get_activities(self) -> list[Any]:
        """Return all decorated Temporal activities for registration.
        This includes both instance methods and top-level functions that are part of the
        KineticActivities collection.
        """
        return [
            self.fetch_memoized_state_io_activity,
            self.apply_defeasible_cascade_compute_activity,
            self.execute_rollback_io_activity,
            self.execute_defeasible_cascade_compute_activity,
            self.retrieve_latent_projection_compute_activity,
            self.execute_exogenous_shock_compute_activity,
            self.execute_ontology_discovery_compute_activity,
            self.execute_system_function_compute_activity,
            self.hydrate_mcp_prompt_io_activity,
            self.execute_gateway_cognitive_activity,
            self.fetch_mcp_resources_io_activity,
            self.execute_mcp_tool_io_activity,
            self.store_epistemic_state_io_activity,
            self.record_token_burn_io_activity,
            self.emit_resumed_event_io_activity,
            self.emit_span_io_activity,
            self.request_oracle_intervention_io_activity,
            self.broadcast_state_echo_io_activity,
            self.execute_medallion_etl_compute_activity,
            self.announce_task_io_activity,
            self.mint_neural_audit_attestation_compute_activity,
            # Top-level activities
            execute_formal_verification_compute_activity,
            execute_spatial_kinematic_compute_activity,
            execute_silver_transformation_compute_activity,
            execute_fhe_solver_compute_activity,
            execute_shapley_attribution_compute_activity,
            execute_collective_intelligence_activity,
            execute_gaze_tracking_io_activity,
        ]


# Re-export standalone compute activities from the split module for backward compatibility.
# These were extracted to compute_activities.py to reduce file complexity.
from coreason_runtime.orchestration.compute_activities import (  # noqa: E402
    calculate_cosine_similarity,
    evaluate_ui_score_compute_activity,
    execute_collective_intelligence_activity,
    execute_fhe_solver_compute_activity,
    execute_formal_verification_compute_activity,
    execute_gaze_tracking_io_activity,
    execute_shapley_attribution_compute_activity,
    execute_silver_transformation_compute_activity,
    execute_spatial_kinematic_compute_activity,
    invoke_scaffold_sensory_urn_mcp_io_activity,
)

__all__ = [
    "KineticActivities",
    "calculate_cosine_similarity",
    "evaluate_ui_score_compute_activity",
    "execute_collective_intelligence_activity",
    "execute_fhe_solver_compute_activity",
    "execute_formal_verification_compute_activity",
    "execute_gaze_tracking_io_activity",
    "execute_shapley_attribution_compute_activity",
    "execute_silver_transformation_compute_activity",
    "execute_spatial_kinematic_compute_activity",
    "invoke_scaffold_sensory_urn_mcp_io_activity",
    "resolve_schema_class",
]
