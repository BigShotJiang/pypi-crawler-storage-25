// Copyright (c) 2026 CoReason, Inc
//
// This software is proprietary and dual-licensed
// Licensed under the Prosperity Public License 3.0 (the "License")
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file
// Commercial use beyond a 30-day trial requires a separate license
//
// Source Code: <https://github.com/CoReason-AI/coreason-runtime>

#[cfg(feature = "pyo3")]
use pyo3::prelude::*;

static VERIFIED_CACHE: std::sync::OnceLock<dashmap::DashMap<String, String>> = std::sync::OnceLock::new();

fn decode_hex(s: &str) -> Result<Vec<u8>, &'static str> {
    if s.len() % 2 != 0 {
        return Err("Odd length hex string");
    }
    let mut res = Vec::with_capacity(s.len() / 2);
    for i in (0..s.len()).step_by(2) {
        let byte = u8::from_str_radix(&s[i..i + 2], 16).map_err(|_| "Invalid hex character")?;
        res.push(byte);
    }
    Ok(res)
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn check_cache(module_name: &str, expected_hash: &str) -> PyResult<bool> {
    let cache = VERIFIED_CACHE.get_or_init(dashmap::DashMap::new);
    if let Some(val) = cache.get(module_name) {
        return Ok(val.as_str() == expected_hash);
    }
    Ok(false)
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn update_cache(module_name: &str, expected_hash: &str) -> PyResult<()> {
    let cache = VERIFIED_CACHE.get_or_init(dashmap::DashMap::new);
    cache.insert(module_name.to_string(), expected_hash.to_string());
    Ok(())
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn clear_cache() -> PyResult<()> {
    let cache = VERIFIED_CACHE.get_or_init(dashmap::DashMap::new);
    cache.clear();
    Ok(())
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn verify_module_integrity(source_code: &str, expected_sha256: &str) -> PyResult<bool> {
    use sha2::{Digest, Sha256};
    let normalized = source_code.replace("\r\n", "\n");
    let mut hasher = Sha256::new();
    hasher.update(normalized.as_bytes());
    let actual_hash = format!("{:x}", hasher.finalize());
    Ok(actual_hash == expected_sha256)
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn verify_file_hash(file_path: &str, expected_sha256: &str) -> PyResult<bool> {
    use sha2::{Digest, Sha256};
    use memmap2::Mmap;
    use std::fs::File;

    let file = File::open(file_path)?;
    let mmap = unsafe { Mmap::map(&file)? };

    // Normalize CRLF to LF on the fly
    let mut normalized = Vec::with_capacity(mmap.len());
    let mut i = 0;
    while i < mmap.len() {
        if i + 1 < mmap.len() && mmap[i] == b'\r' && mmap[i + 1] == b'\n' {
            normalized.push(b'\n');
            i += 2;
        } else {
            normalized.push(mmap[i]);
            i += 1;
        }
    }

    let mut hasher = Sha256::new();
    hasher.update(&normalized);
    let actual_hash = format!("{:x}", hasher.finalize());
    Ok(actual_hash == expected_sha256)
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn verify_signature(message: &str, signature_hex: &str, public_key_hex: &str) -> PyResult<bool> {
    use ed25519_dalek::{Signature, Verifier, VerifyingKey};
    use std::convert::TryInto;

    let public_bytes = decode_hex(public_key_hex)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e))?;
    let signature_bytes = decode_hex(signature_hex)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e))?;

    let public_array: [u8; 32] = public_bytes.as_slice().try_into()
        .map_err(|_| pyo3::exceptions::PyValueError::new_err("Public key must be 32 bytes"))?;
    let signature_array: [u8; 64] = signature_bytes.as_slice().try_into()
        .map_err(|_| pyo3::exceptions::PyValueError::new_err("Signature must be 64 bytes"))?;

    let verifying_key = VerifyingKey::from_bytes(&public_array)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(format!("Invalid public key: {}", e)))?;
    let signature = Signature::from_bytes(&signature_array);

    let verified = verifying_key.verify(message.as_bytes(), &signature).is_ok();
    Ok(verified)
}

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn verify_signatures_parallel(
    messages: Vec<String>,
    signatures_hex: Vec<String>,
    public_key_hex: &str,
    py: Python<'_>,
) -> PyResult<Vec<bool>> {
    use ed25519_dalek::{Signature, Verifier, VerifyingKey};
    use std::convert::TryInto;
    use rayon::prelude::*;

    if messages.len() != signatures_hex.len() {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "Messages and signatures must have equal lengths",
        ));
    }

    let public_bytes = decode_hex(public_key_hex)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e))?;
    let public_array: [u8; 32] = public_bytes.as_slice().try_into()
        .map_err(|_| pyo3::exceptions::PyValueError::new_err("Public key must be 32 bytes"))?;

    let verifying_key = VerifyingKey::from_bytes(&public_array)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(format!("Invalid public key: {}", e)))?;

    let mut signatures = Vec::with_capacity(signatures_hex.len());
    for sig_hex in &signatures_hex {
        let sig_bytes = decode_hex(sig_hex)
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(e))?;
        let sig_array: [u8; 64] = sig_bytes.as_slice().try_into()
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("Signature must be 64 bytes"))?;
        let signature = Signature::from_bytes(&sig_array);
        signatures.push(signature);
    }

    let tasks: Vec<(String, Signature)> = messages.into_iter().zip(signatures.into_iter()).collect();

    // Release GIL and run in parallel
    let results = py.allow_threads(move || {
        tasks
            .par_iter()
            .map(|(msg, sig)| verifying_key.verify(msg.as_bytes(), sig).is_ok())
            .collect()
    });

    Ok(results)
}

#[cfg(feature = "pyo3")]
#[pymodule]
fn coreason_runtime_rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(check_cache, m)?)?;
    m.add_function(wrap_pyfunction!(update_cache, m)?)?;
    m.add_function(wrap_pyfunction!(clear_cache, m)?)?;
    m.add_function(wrap_pyfunction!(verify_module_integrity, m)?)?;
    m.add_function(wrap_pyfunction!(verify_file_hash, m)?)?;
    m.add_function(wrap_pyfunction!(verify_signature, m)?)?;
    m.add_function(wrap_pyfunction!(verify_signatures_parallel, m)?)?;
    Ok(())
}
