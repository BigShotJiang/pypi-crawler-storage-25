#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#
#   Copyright 2022-2026 Valory AG
#   Copyright 2018-2021 Fetch.AI Limited
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
# ------------------------------------------------------------------------------
"""Check aea dependencies."""

import copy
import dis
import importlib
import re
import sys
from collections import defaultdict
from functools import wraps
from importlib.machinery import ModuleSpec
from importlib.metadata import PackageNotFoundError, distribution
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    Generator,
    List,
    Optional,
    Set,
    Tuple,
    Union,
    cast,
)

# aea is imported lazily because dependencies-check uninstalls it at runtime.
crypto_registry = None  # type: ignore


def _ensure_lazy_imports() -> None:
    """Import aea lazily, adding source tree to sys.path if needed."""
    global crypto_registry  # pylint: disable=global-statement
    if crypto_registry is None:
        # Add the repo root to sys.path so aea can be found from source
        # even when it's not pip-installed
        repo_root = str(Path.cwd())
        if repo_root not in sys.path:
            sys.path.insert(0, repo_root)
        from aea.crypto.registries import (
            crypto_registry as _cr,  # pylint: disable=import-outside-toplevel
        )

        crypto_registry = _cr


AEA_ROOT_DIR = Path.cwd()
IGNORE: Set[str] = {"pkg_resources"}
DEP_NAME_RE = re.compile(r"(^[^=><\[]+)", re.I)  # type: ignore


def list_decorator(fn: Callable) -> Callable:
    """Wraps generator to return list."""

    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> List[Any]:
        return list(fn(*args, **kwargs))

    return wrapper


class DependenciesTool:
    """Tool to work with setup.py dependencies."""

    @staticmethod
    def get_package_files(package_name: str) -> List[Path]:
        """Get package files list."""
        try:
            dist = distribution(package_name)
        except PackageNotFoundError as e:
            raise ValueError(f"package {package_name} not found") from e
        files = dist.files or []
        return [Path(str(dist.locate_file(f))) for f in files]

    @staticmethod
    def clean_dependency_name(dependecy_specification: str) -> str:
        """Get dependency name from dependency specification."""
        match = DEP_NAME_RE.match(dependecy_specification)
        if not match:
            raise ValueError(f"Bad dependency specification: {dependecy_specification}")
        return match.groups()[0]


class ImportsTool:
    """Tool to work with 3rd part imports in source code."""

    @staticmethod
    def get_imports_for_file(pyfile: Union[str, Path]) -> List[str]:
        """Get all imported modules for python source file."""
        with open(pyfile, "r") as f:
            statements = f.read()
        instructions = dis.get_instructions(statements)  # type: ignore
        imports = []
        is_try_except_block = False
        for im in instructions:
            if "SETUP_FINALLY" in im.opname:
                is_try_except_block = True

            if "POP_EXCEPT" in im.opname:
                is_try_except_block = False

            if is_try_except_block:
                continue

            if "IMPORT" in im.opname:
                imports.append(im)

        grouped: Dict[str, List[str]] = defaultdict(list)
        for instr in imports:
            grouped[instr.opname].append(instr.argval)

        return grouped["IMPORT_NAME"]

    @staticmethod
    def get_module_file(module_name: str) -> str:
        """Get module source file name."""
        try:
            mod = importlib.import_module(module_name)
            return getattr(mod, "__file__", "")
        except (AttributeError, ModuleNotFoundError):
            return ""

    @staticmethod
    @list_decorator
    def list_all_pyfiles(
        root_path: Union[Path, str], pattern: str = "**/*.py"
    ) -> Generator:
        """List all python files in directory."""
        root_path = Path(root_path)
        for path in root_path.glob(pattern):
            yield path.relative_to(root_path)

    @classmethod
    @list_decorator
    def get_third_part_imports_for_file(cls, pyfile: str) -> Generator:
        """Get list of third part modules imported for source file."""
        imports = cls.get_imports_for_file(pyfile)
        for module_name in imports:
            pyfile = cls.get_module_file(module_name)
            if not pyfile:
                continue
            if "site-packages" not in Path(pyfile).parts:
                continue
            yield module_name, Path(pyfile)

    @classmethod
    @list_decorator
    def list_all_pyfiles_with_3rdpart_imports(
        cls, root_path: Union[str, Path], pattern: str = "**/*.py"
    ) -> Generator:
        """Get list of all python sources with 3rd party modules imported."""
        for pyfile in cls.list_all_pyfiles(root_path, pattern=pattern):
            mods = list(cls.get_third_part_imports_for_file(root_path / pyfile))
            if not mods:
                continue
            yield Path(pyfile), list(set(mods))


class CheckTool:
    """Tool to check imports in sources match dependencies in setup.py."""

    @classmethod
    def get_section_dependencies_from_setup(cls) -> Dict[str, Dict[str, List[Path]]]:
        """Get sections with dependencies with files lists."""
        spec = importlib.util.spec_from_file_location(
            "setup", str(AEA_ROOT_DIR / "setup.py")
        )
        setup = importlib.util.module_from_spec(cast(ModuleSpec, spec))
        sys.modules[cast(ModuleSpec, spec).name] = setup
        spec.loader.exec_module(setup)  # type: ignore

        sections_dependencies = copy.deepcopy(setup.all_extras)  # type: ignore
        sections_dependencies.pop("all")
        base = setup.base_deps  # type: ignore

        for crypto_id in crypto_registry.supported_ids:  # type: ignore
            if crypto_id == "fetchai":
                crypto_id = "fetch"
            if crypto_id in sections_dependencies:
                sections_dependencies.pop(crypto_id)
        sections_dependencies["base"] = base

        return cls.sections_dependencies_add_files(sections_dependencies)

    @staticmethod
    def sections_dependencies_add_files(
        sections_dependencies: Dict[str, List[str]],
    ) -> Dict[str, Dict[str, List[Path]]]:
        """Add packages file lists to dependencies in sections."""
        result: Dict[str, Dict[str, List[Path]]] = defaultdict(
            lambda: defaultdict(list)
        )
        for section, deps in sections_dependencies.items():
            for dep in deps:
                dep = DependenciesTool.clean_dependency_name(dep)
                result[section][dep] = DependenciesTool.get_package_files(dep)
        return result

    @classmethod
    def run(cls) -> None:
        """Run dependency check."""
        _ensure_lazy_imports()
        print("Dependencies check report:")
        print("==========================")
        files_and_modules = ImportsTool.list_all_pyfiles_with_3rdpart_imports(
            AEA_ROOT_DIR, pattern="aea/**/*.py"
        )

        sections_dependencies = cls.get_section_dependencies_from_setup()
        sections_imports = cls.make_sections_with_3rdpart_imports(
            files_and_modules, set(sections_dependencies.keys())
        )
        missed_deps_for_imports, deps_not_imported_directly = cls.check_imports(
            sections_imports, sections_dependencies
        )

        for section, unresolved_imports in missed_deps_for_imports.items():
            print(
                f"Section `{section}` unresolved imports: {', '.join(unresolved_imports)}"
            )

        if deps_not_imported_directly:
            if missed_deps_for_imports:
                print()
            print(
                f"Dependencies not imported in code directly: {', '.join(deps_not_imported_directly)}"
            )

        if missed_deps_for_imports or deps_not_imported_directly:
            sys.exit(1)
        else:
            print("All good!")

    @staticmethod
    def make_sections_with_3rdpart_imports(
        files_and_modules: List[Tuple[str, List[Tuple[str, Path]]]],
        section_names: Set[str],
    ) -> Dict[str, Set[Tuple[str, Path]]]:
        """Make sections with list of 3r part imports."""
        sections_imports: Dict[str, Set[Tuple[str, Path]]] = defaultdict(set)
        for pyfile, imports in files_and_modules:
            section_name = Path(pyfile).parts[1]

            if section_name not in section_names:
                section_name = "base"

            sections_imports[section_name].update(imports)

        return sections_imports

    @staticmethod
    def check_imports(
        sections_imports: Dict[str, Set[Tuple[str, Path]]],
        sections_dependencies: Dict[str, Dict[str, List[Path]]],
    ) -> Tuple[Dict[str, List[str]], List[str]]:
        """Find missing dependencies for imports and not imported dependencies."""

        def _find_dependency_for_module(
            dependencies: Dict[str, List[str]], pyfile: str
        ) -> Optional[str]:
            for package, files in dependencies.items():
                if pyfile in files:
                    return package
            return None

        sections_imports_packages: Dict[str, Dict[str, Optional[str]]] = defaultdict(
            dict
        )
        for section, modules in sections_imports.items():
            for module, pyfile in modules:
                package = _find_dependency_for_module(
                    sections_dependencies.get(section, {}), pyfile  # type: ignore
                )
                if module not in IGNORE:
                    sections_imports_packages[section][module] = package

        all_dependencies_set = set(
            sum((list(i.keys()) for _, i in sections_dependencies.items()), [])
        )
        used_dependencies_set = set(
            sum(
                [
                    list(section.values())
                    for section in sections_imports_packages.values()
                ],
                [],
            )
        )
        deps_not_imported_directly: List[str] = list(
            all_dependencies_set - used_dependencies_set
        )
        missed_deps_for_imports: Dict[str, List[str]] = {
            section: [k for k, v in modules.items() if v is None]
            for section, modules in sections_imports_packages.items()
            if None in modules.values()
        }
        return missed_deps_for_imports, deps_not_imported_directly


if __name__ == "__main__":
    CheckTool.run()
