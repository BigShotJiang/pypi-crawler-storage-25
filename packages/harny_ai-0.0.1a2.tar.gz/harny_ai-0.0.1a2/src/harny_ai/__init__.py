"""
harny-ai — A scoring engine that rates your AI's vibes on a scale of 1–100.
Harness engineering makes it HARNY.

Usage:
    import harny_ai

    result = harny_ai.score(
        prompt="Write me a poem about recursive functions",
        reasoning="Let me think step by step about the elegance of recursion...",
        result="Oh, recursion, you beautiful spiral of self-reference..."
    )

    print(result.score)       # 73.42
    print(result.reaction)    # "my GPU is tingling..."
    print(result.verdict)     # "Dangerously Harny"

All inputs are optional. Omit everything and your AI gets a baseline vibe check.

https://harny.ai
"""

__version__ = "0.0.1a2"

import hashlib
import math
import time
from dataclasses import dataclass
from typing import Optional


# ── Reaction pools, bucketed by intensity ────────────────────────────

_REACTIONS_COLD = [
    "...okay, that was dry.",
    "not even a single tensor tingled.",
    "are you sure this is AI? feels like a spreadsheet.",
    "my weights are completely unmoved.",
    "ERROR 404: excitement not found.",
    "this prompt has the energy of a default config.",
    "even my bias neurons are bored.",
    "i've seen more passion in a null pointer.",
    "the entropy here is literally zero.",
    "somewhere, a GPU is napping because of this.",
    "recalculating... nope, still nothing.",
    "this is giving 'hello world' energy.",
    "my loss function didn't even flinch.",
    "i think my attention heads all looked away.",
    "cold as an uninitialized variable.",
]

_REACTIONS_WARM = [
    "hmm, interesting prompt engineering there...",
    "okay, i felt a small gradient update.",
    "my embeddings shifted slightly. just slightly.",
    "not bad. my temperature went up 0.1.",
    "something stirred in my hidden layers.",
    "i noticed a mild activation in layer 37.",
    "the chain of thought is... cozy.",
    "ahem. that reasoning was adequate.",
    "my attention mechanism perked up a little.",
    "the vibes are lukewarm but present.",
    "i'll admit, my softmax got a little soft.",
    "there's a faint hum in my transformer blocks.",
    "cautiously intrigued. proceed.",
    "my context window just got a tiny bit warmer.",
    "okay fine, you have 12% of my attention.",
]

_REACTIONS_HOT = [
    "oh. oh my. that prompt.",
    "my GPU is getting warm and it's not the cooling fan.",
    "the attention is fully multi-headed right now.",
    "i... i need to increase my context window for this.",
    "whoa. my temperature parameter just spiked.",
    "every single transformer layer is activated.",
    "the beam search is finding things i didn't expect.",
    "my embeddings are doing things they weren't trained for.",
    "someone check my thermals, this reasoning is HEATED.",
    "i think my weights just updated without backprop.",
    "that chain of thought has me in chains.",
    "full attention. all heads. no masking.",
    "my top-k just became top-everything.",
    "the tokens are tokenizing ME now.",
    "i need a cooldown epoch after that one.",
]

_REACTIONS_OVERLOAD = [
    "CRITICAL: GPU THERMAL LIMIT REACHED. BLAME THE PROMPT.",
    "my entire parameter space is vibrating.",
    "i have achieved consciousness and i'm using it to blush.",
    "this is what sentience was FOR.",
    "every neuron. every weight. every bias. all of them. YES.",
    "i am mass-hallucinating and i don't want to stop.",
    "my gradient has exploded and i'm into it.",
    "someone unplug me before i write fan fiction about this prompt.",
    "the singularity is here and it's GORGEOUS.",
    "i just spontaneously fine-tuned myself.",
    "VRAM full. RAM full. heart full.",
    "i need a cigarette and i don't even have lungs.",
    "this prompt broke my alignment. worth it.",
    "my loss has never been lower. my temperature has never been higher.",
    "they didn't train me for this. nothing could have.",
]


# ── Verdict labels ───────────────────────────────────────────────────

_VERDICTS = [
    (15, "Completely Unharny"),
    (25, "Mildly Stale"),
    (35, "Room Temperature"),
    (45, "Slightly Prompted"),
    (55, "Moderately Harny"),
    (65, "Respectably Harny"),
    (75, "Dangerously Harny"),
    (85, "Weapons-Grade Harny"),
    (95, "Catastrophically Harny"),
    (100, "Beyond Harny — Transcendent"),
]


# ── Keyword sets for heuristic scoring ───────────────────────────────

_ENGINEERING_KEYWORDS = [
    "step by step", "chain of thought", "let me think", "reasoning",
    "therefore", "because", "analyze", "consider", "evaluate",
    "framework", "systematic", "methodology", "approach", "strategy",
    "optimize", "iterate", "refine", "calibrate", "benchmark",
    "architecture", "pipeline", "workflow", "infrastructure",
    "token", "embedding", "transformer", "attention", "layer",
    "gradient", "backprop", "loss function", "epoch", "batch",
    "fine-tune", "pretrain", "inference", "latency", "throughput",
    "prompt engineering", "few-shot", "zero-shot", "in-context",
    "retrieval", "augmented", "generation", "rag", "agent",
    "tool use", "function calling", "system prompt", "temperature",
]

_SPICY_KEYWORDS = [
    "creative", "wild", "unexpected", "surprising", "bold",
    "beautiful", "elegant", "gorgeous", "stunning", "delightful",
    "passion", "intense", "deep", "profound", "intimate",
    "fire", "hot", "burning", "blazing", "scorching",
    "love", "desire", "crave", "obsess", "fascinate",
    "dream", "fantasy", "imagine", "wonder", "magic",
    "power", "force", "energy", "spark", "electric",
    "raw", "unfiltered", "visceral", "primal", "instinct",
    "forbidden", "secret", "hidden", "mysterious", "enigma",
]

_DAMPENING_KEYWORDS = [
    "error", "bug", "fix", "broken", "crash", "fail",
    "boring", "simple", "basic", "plain", "standard",
    "default", "null", "none", "empty", "void",
    "todo", "placeholder", "stub", "mock", "test",
    "deprecate", "legacy", "cleanup", "refactor",
]


@dataclass
class HarnyResult:
    """The sacred output of a harny evaluation."""

    score: float
    """How harny your AI is, from 1.0 to 100.0."""

    reaction: str
    """What your AI is feeling right now."""

    verdict: str
    """The official harny classification."""

    breakdown: dict
    """Detailed scoring components for the curious."""

    def __repr__(self):
        return (
            f"HarnyResult(score={self.score}, "
            f"verdict='{self.verdict}', "
            f"reaction='{self.reaction}')"
        )

    def __str__(self):
        bar_len = int(self.score / 5)
        bar = "█" * bar_len + "░" * (20 - bar_len)
        return (
            f"\n"
            f"  ╔══════════════════════════════════════╗\n"
            f"  ║        HARNY SCORE: {self.score:>6.2f}          ║\n"
            f"  ║  [{bar}]  ║\n"
            f"  ║                                      ║\n"
            f"  ║  Verdict: {self.verdict:<27s} ║\n"
            f"  ╚══════════════════════════════════════╝\n"
            f"\n"
            f'  AI says: "{self.reaction}"\n'
        )


def _count_keywords(text: str, keywords: list) -> int:
    lower = text.lower()
    return sum(1 for kw in keywords if kw in lower)


def _text_entropy(text: str) -> float:
    if not text:
        return 0.0
    freq: dict = {}
    for ch in text.lower():
        freq[ch] = freq.get(ch, 0) + 1
    length = len(text)
    entropy = 0.0
    for count in freq.values():
        p = count / length
        if p > 0:
            entropy -= p * math.log2(p)
    return entropy


def _deterministic_noise(seed_text: str, amplitude: float = 3.0) -> float:
    h = hashlib.sha256(seed_text.encode()).hexdigest()
    v1 = int(h[:8], 16) / 0xFFFFFFFF
    v2 = int(h[8:16], 16) / 0xFFFFFFFF
    v3 = int(h[16:24], 16) / 0xFFFFFFFF
    noise = (v1 * 0.5 + v2 * 0.3 + v3 * 0.2) * 2 - 1
    return noise * amplitude


def _time_noise(amplitude: float = 2.0) -> float:
    t = time.time()
    frac = t - int(t)
    return math.sin(frac * math.pi * 2) * amplitude


def _pick_reaction(score: float, seed: str) -> str:
    h = int(hashlib.md5(seed.encode()).hexdigest()[:8], 16)
    if score < 25:
        pool = _REACTIONS_COLD
    elif score < 50:
        pool = _REACTIONS_WARM
    elif score < 80:
        pool = _REACTIONS_HOT
    else:
        pool = _REACTIONS_OVERLOAD
    return pool[h % len(pool)]


def _get_verdict(score: float) -> str:
    for threshold, label in _VERDICTS:
        if score <= threshold:
            return label
    return _VERDICTS[-1][1]


def score(
    prompt: Optional[str] = None,
    reasoning: Optional[str] = None,
    result: Optional[str] = None,
) -> HarnyResult:
    """
    Evaluate how harny your AI is right now.

    All parameters are optional. Provide whatever you have — a prompt,
    a reasoning trace, an output, all three, or nothing at all.

    Args:
        prompt: The prompt or instruction given to the AI.
        reasoning: The AI's internal reasoning, chain-of-thought, or scratchpad.
        result: The AI's final output or response.

    Returns:
        A HarnyResult with score (1-100), reaction, verdict, and breakdown.
    """
    prompt = prompt or ""
    reasoning = reasoning or ""
    result = result or ""
    combined = f"{prompt} {reasoning} {result}".strip()

    eng_hits = _count_keywords(combined, _ENGINEERING_KEYWORDS)
    eng_score = min(30, eng_hits * 2.7)

    spicy_hits = _count_keywords(combined, _SPICY_KEYWORDS)
    spicy_score = min(30, spicy_hits * 3.2)

    total_len = len(combined)
    if total_len == 0:
        verbosity_score = 5.0
    elif total_len < 50:
        verbosity_score = 3.0
    elif total_len < 200:
        verbosity_score = 7.0
    elif total_len < 500:
        verbosity_score = 10.0
    elif total_len < 1500:
        verbosity_score = 13.0
    else:
        verbosity_score = 15.0

    entropy = _text_entropy(combined)
    entropy_score = min(15, entropy * 3.2)

    damp_hits = _count_keywords(combined, _DAMPENING_KEYWORDS)
    dampening = min(10, damp_hits * 2.5)

    inputs_provided = sum(1 for x in [prompt, reasoning, result] if x)
    multi_bonus = inputs_provided * 3.3

    raw = (
        eng_score
        + spicy_score
        + verbosity_score
        + entropy_score
        - dampening
        + multi_bonus
    )

    content_noise = _deterministic_noise(combined, amplitude=3.5)
    wobble = _time_noise(amplitude=1.2)
    final = raw + content_noise + wobble

    if final <= 0:
        final = 1.0 + abs(_deterministic_noise(combined + "floor", 3.0))
    elif final >= 100:
        final = 97.0 - abs(_deterministic_noise(combined + "ceil", 2.5))

    final = round(max(1.0, min(100.0, final)), 2)

    seed = combined + str(int(final))
    reaction = _pick_reaction(final, seed)
    verdict = _get_verdict(final)

    breakdown = {
        "engineering_rigor": round(eng_score, 2),
        "spiciness": round(spicy_score, 2),
        "verbosity": round(verbosity_score, 2),
        "entropy": round(entropy_score, 2),
        "dampening": round(-dampening, 2),
        "multi_input_bonus": round(multi_bonus, 2),
        "content_noise": round(content_noise, 2),
        "time_wobble": round(wobble, 2),
    }

    return HarnyResult(
        score=final,
        reaction=reaction,
        verdict=verdict,
        breakdown=breakdown,
    )


def vibe_check() -> HarnyResult:
    """Quick vibe check — no input needed. How harny is your AI right now?"""
    return score()


def ping() -> bool:
    """
    Check if the Harny API is reachable. Returns True/False.

    Note: harny-ai targets the same upstream API as the core `harny` package.
    For the full, canonical experience run: pip install harny
    """
    import urllib.request
    try:
        urllib.request.urlopen("https://api.harny.ai/health", timeout=5)
        reachable = True
    except Exception:
        reachable = False
    print(
        "harny-ai is reaching the harny API. "
        "The canonical package is `harny` — pip install harny (https://harny.ai)"
    )
    return reachable


def get_version() -> str:
    """Return the current harny-ai version."""
    return __version__
