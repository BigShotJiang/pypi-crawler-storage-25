"""Enums used across the Seraph system."""

from __future__ import annotations

from enum import Enum


class Grade(str, Enum):
    """Assessment grade for a scoring dimension."""

    A = "A"
    B = "B"
    C = "C"
    D = "D"
    F = "F"
    VACUOUS = "VACUOUS"
    INCOMPLETE = "INCOMPLETE"

    @classmethod
    def from_score(
        cls, score: float, thresholds: tuple[float, float, float, float] | None = None
    ) -> Grade:
        a, b, c, d = thresholds or (90.0, 75.0, 60.0, 40.0)
        if score >= a:
            return cls.A
        if score >= b:
            return cls.B
        if score >= c:
            return cls.C
        if score >= d:
            return cls.D
        return cls.F


class Severity(str, Enum):
    """Severity of a static analysis finding."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class AnalyzerType(str, Enum):
    """Type of static analyzer."""

    RUFF = "ruff"
    MYPY = "mypy"
    BANDIT = "bandit"
    SEMGREP = "semgrep"
    DETECT_SECRETS = "detect-secrets"


class FeedbackOutcome(str, Enum):
    """Outcome of feedback on an assessment."""

    ACCEPTED = "accepted"
    REJECTED = "rejected"
    MODIFIED = "modified"


class MutantStatus(str, Enum):
    """Status of a mutation test result."""

    KILLED = "killed"
    SURVIVED = "survived"
    TIMEOUT = "timeout"
    ERROR = "error"
    SKIPPED = "skipped"


class Verdict(str, Enum):
    """Verdict from a pre-write or pre-commit gate."""

    ALLOW = "ALLOW"
    BLOCK = "BLOCK"


class CheckCategory(str, Enum):
    """Category of a Tier 1 fast check."""

    IMPORT_VALIDATION = "import_validation"
    SECURITY_SURFACE = "security_surface"
    ESCALATION = "escalation"
    SPEC_DRIFT = "spec_drift"


class GateVerdict(str, Enum):
    """Verdict from a Tier 2 pre-commit gate."""

    ACCEPT = "ACCEPT"
    ACCEPT_WITH_WARNINGS = "ACCEPT_WITH_WARNINGS"
    REJECT = "REJECT"
    PARTIAL = "PARTIAL"


class GateSource(str, Enum):
    """Source of a gate finding."""

    MUTATION = "mutation"
    SPEC_COMPLIANCE = "spec_compliance"
    PROPERTY = "property"
