def h1():
    print(
        """
#include<iostream>
#include<vector>
#include<stack>
#include<queue>
#include<omp.h>
using namespace std;

vector<int> graph[100];
bool visited[100];

void BFS(int start)
{
    queue<int> q;
    q.push(start);
    visited[start] = true;

    while(!q.empty()){
        int node = q.front();
        q.pop();
        cout<<node<<" ";

        #pragma omp parallel for
        for(int i = 0 ; i<graph[node].size() ; i++){
            int adj = graph[node][i];
            #pragma omp critical
            {
                if(!visited[adj])
                {
                    visited[adj] = true;
                    q.push(adj);
                }
            }
        }
    }
}

void DFS(int start){
    stack<int> st;
    st.push(start);
    

    while(!st.empty()){
        int node = st.top();
        st.pop();
        
        if(!visited[node]){
            visited[node] = true;
            cout << node <<" ";
            
            #pragma omp parallel for
            for(int i = 0 ; i<graph[node].size() ; i++)
            {
                int adj = graph[node][i];
                #pragma omp critical
                {
                    if(!visited[adj])
                    {
                        st.push(adj);
                    }
                }
            }
        }
    }
}

int main(){

    int n,m;
    cout<<"Enter nodes and edges:\n";
    cin>>n>>m;

    for(int i = 0 ; i<m ; i++){
        int u,v;
        cout<<"Enter edges:\n";
        cin>>u>>v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    for(int i =0 ; i<n ;  i++){
        visited[i] = false;
    }

    cout<<"BFS:";
    BFS(0);
    
    for(int i =0 ; i<n ;  i++){
        visited[i] = false;
    }

    cout<<"DFS:";
    DFS(0);

    return 0;
}
        """
    )

def h2():
        
        print(
            """
#include <iostream>
#include <omp.h>
#include <chrono>
using namespace std;
using namespace chrono;

/* ---------- PRINT ---------- */
void printArray(int arr[], int n) {
    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
}

/* ---------- SEQUENTIAL BUBBLE ---------- */
void bubbleSort(int arr[], int n) {
    for(int i = 0; i < n-1; i++)
        for(int j = 0; j < n-i-1; j++)
            if(arr[j] > arr[j+1])
                swap(arr[j], arr[j+1]);
}

/* ---------- PARALLEL BUBBLE ---------- */
void parallelBubbleSort(int arr[], int n) {
    for(int i = 0; i < n; i++) {
        int start = i % 2;

        #pragma omp parallel for
        for(int j = start; j < n-1; j += 2) {
            if(arr[j] > arr[j+1])
                swap(arr[j], arr[j+1]);
        }
    }
}

/* ---------- MERGE ---------- */
void merge(int arr[], int l, int m, int r) {
    int temp[1000];
    int i=l, j=m+1, k=0;

    while(i<=m && j<=r)
        temp[k++] = (arr[i] < arr[j]) ? arr[i++] : arr[j++];

    while(i<=m) temp[k++] = arr[i++];
    while(j<=r) temp[k++] = arr[j++];

    for(int i=0; i<k; i++)
        arr[l+i] = temp[i];
}

/* ---------- MERGE SORT ---------- */
void mergeSort(int arr[], int l, int r) {
    if(l < r) {
        int m = (l+r)/2;
        mergeSort(arr, l, m);
        mergeSort(arr, m+1, r);
        merge(arr, l, m, r);
    }
}

/* ---------- PARALLEL MERGE SORT ---------- */
void parallelMergeSort(int arr[], int l, int r) {
    if(l < r) {
        int m = (l+r)/2;

        #pragma omp parallel sections
        {
            #pragma omp section
            parallelMergeSort(arr, l, m);

            #pragma omp section
            parallelMergeSort(arr, m+1, r);
        }

        merge(arr, l, m, r);
    }
}

/* ---------- MAIN ---------- */
int main() {
    int n;
    cout << "Enter size: ";
    cin >> n;

    int original[1000];
    cout << "Enter elements:\n";
    for(int i=0;i<n;i++) cin >> original[i];

    int a[1000], b[1000];

    // -------- Bubble Sort --------
    for(int i=0;i<n;i++){ a[i]=original[i]; b[i]=original[i]; }

    auto t1 = high_resolution_clock::now();
    bubbleSort(a, n);
    auto t2 = high_resolution_clock::now();

    auto t3 = high_resolution_clock::now();
    parallelBubbleSort(b, n);
    auto t4 = high_resolution_clock::now();

    cout << "\nBubble Sort:\n";
    printArray(a, n);

    cout << "Sequential: "<< duration_cast<microseconds>(t2-t1).count() << " us\n";
    cout << "Parallel:   "<< duration_cast<microseconds>(t4-t3).count() << " us\n";

    // -------- Merge Sort --------
    for(int i=0;i<n;i++){ 
        a[i]=original[i]; b[i]=original[i];
    }

    auto t5 = high_resolution_clock::now();
    mergeSort(a, 0, n-1);
    auto t6 = high_resolution_clock::now();

    auto t7 = high_resolution_clock::now();
    parallelMergeSort(b, 0, n-1);
    auto t8 = high_resolution_clock::now();

    cout << "\nMerge Sort:\n";
    printArray(a, n);

    cout << "Sequential: " << duration_cast<microseconds>(t6-t5).count() << " us\n";
    cout << "Parallel:  " << duration_cast<microseconds>(t8-t7).count() << " us\n";

    return 0;
}
"""
        )

def h3():
    print(
        """
//HPC 3
#include <omp.h>
#include <iostream>
#include <chrono>
using namespace std::chrono;
using namespace std;

// Display Array
void displayArray(int nums[], int length)
{
    cout << "Nums: [";
    for (int i = 0; i < length; i++) {
        cout << nums[i];
        if (i != length - 1)
            cout << ", ";
    }
    cout << "]" << endl;
}

// Parallel Min Operation
void minOperation(int nums[], int length)
{
    int minValue = nums[0];
#pragma omp parallel for reduction(min : minValue)
    for (int i = 0; i < length; i++) {
        minValue = (nums[i] < minValue) ? nums[i] : minValue;
    }
    cout << "Min value: " << minValue << endl;
}

// Parallel Max Operation
void maxOperation(int nums[], int length)
{
    int maxValue = nums[0];
#pragma omp parallel for reduction(max : maxValue)
    for (int i = 0; i < length; i++) {
        maxValue = (nums[i] > maxValue) ? nums[i] : maxValue;
    }
    cout << "Max value: " << maxValue << endl;
}

// Parallel Sum Operation
void sumOperation(int nums[], int length)
{
    int sum = 0;
#pragma omp parallel for reduction(+ : sum)
    for (int i = 0; i < length; i++) {
        sum += nums[i];
    }
    cout << "Sum: " << sum << endl;
}

// Parallel Average Operation
void avgOperation(int nums[], int length)
{
    float sum = 0;
#pragma omp parallel for reduction(+ : sum)
    for (int i = 0; i < length; i++) {
        sum += nums[i];
    }
    cout << "Average: " << (sum / length) << endl;
}

// Main Function
int main()
{
    int nums[] = {4, 6, 3, 2, 6, 7, 9, 2, 1, 6, 5};
    int length = sizeof(nums) / sizeof(int);

    auto start = high_resolution_clock::now();

    displayArray(nums, length);
    minOperation(nums, length);
    maxOperation(nums, length);
    sumOperation(nums, length);
    avgOperation(nums, length);

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    cout << "\nExecution time: " << duration.count() << " microseconds" << endl;

    return 0;
}
""")
    
def d1():
    print(
        """
# Step 1: Import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# Step 2: Load dataset
df = pd.read_csv("1_boston_housing.csv")
df.columns = df.columns.str.replace('"', '')

# Step 3: Split features and target
X = df.drop("MEDV", axis=1)
y = df["MEDV"]

# Step 4: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Step 5: Feature Scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 6: Build Linear Regression Model (Single Layer NN)
model = Sequential()
model.add(Dense(1, input_shape=(X_train.shape[1],), activation='linear'))

# Step 7: Compile Model
model.compile(
    optimizer='adam',
    loss='mse',
    metrics=['mae']
)

# Step 8: Train Model
history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=16,
    validation_split=0.2,
    verbose=1
)

# Step 9: Evaluate Model
loss, mae = model.evaluate(X_test, y_test)
print("Test Loss (MSE):", loss)
print("Test MAE:", mae)

# Step 10: Predictions
y_pred = model.predict(X_test)

for i in range(5):
    print(f"Actual: {y_test.iloc[i]:.2f} | Predicted: {y_pred[i][0]:.2f}")

# Step 11: Plot Graph
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.legend()
plt.title("Loss Graph")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.show()
""")
    

def d2():
    print(
        """
from tensorflow.keras.datasets import imdb
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Embedding, Flatten
from tensorflow.keras.preprocessing.sequence import pad_sequences
import matplotlib.pyplot as plt

# Load dataset
(X_train, y_train), (X_test, y_test) = imdb.load_data(num_words=10000)

# Padding
X_train = pad_sequences(X_train, maxlen=200)
X_test = pad_sequences(X_test, maxlen=200)

# Model
model = Sequential()

model.add(Embedding(input_dim=10000, output_dim=32, input_length=200))
model.add(Flatten())
model.add(Dense(32, activation='relu'))
model.add(Dense(1, activation='sigmoid'))  # Binary classification

# Compile
model.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Train
history = model.fit(
    X_train,
    y_train,
    epochs=5,
    batch_size=32,
    validation_split=0.1
)

# Evaluate
loss, acc = model.evaluate(X_test, y_test)

print("Accuracy:", acc)

# Simple visual plot
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')

plt.title("Model Accuracy")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.legend()

plt.show()
""")
    
def d3():
    print(
        """
# 1. IMPORT LIBRARIES
import numpy as np
from tensorflow import keras
import matplotlib.pyplot as plt

# 2. LOAD DATASET
fashion_mnist = keras.datasets.fashion_mnist
(train_img, train_labels), (test_img, test_labels) = fashion_mnist.load_data()

# 3. NORMALIZE DATA
train_img = train_img / 255.0
test_img = test_img / 255.0

# CNN requires 3D input
train_img = train_img.reshape(-1, 28, 28, 1)
test_img = test_img.reshape(-1, 28, 28, 1)

# 4. CLASS NAMES
class_names = ['T-shirt/top','Trouser','Pullover','Dress','Coat','Sandal','Shirt','Sneaker','Bag','Ankle boot']

# 5. BUILD CNN MODEL
model = keras.Sequential([
    keras.Input(shape=(28, 28, 1)),
    keras.layers.Conv2D(32, (3,3), activation='relu'),
    keras.layers.MaxPooling2D((2,2)),
    keras.layers.Conv2D(64, (3,3), activation='relu'),
    keras.layers.MaxPooling2D((2,2)),
    keras.layers.Flatten(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])
 
# 6. COMPILE MODEL
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# 7. TRAIN MODEL
model.fit(train_img, train_labels, epochs=5)

# 8. EVALUATE MODEL
test_loss, test_acc = model.evaluate(test_img, test_labels)
print("\nTest Accuracy:", test_acc)

# 9. MAKE PREDICTIONS
predictions = model.predict(test_img)
predicted_labels = np.argmax(predictions, axis=1)

# 10. DISPLAY RESULTS
for i in range(8):
    plt.imshow(test_img[i].reshape(28,28), cmap='gray')
    plt.title(f"Predicted: {class_names[predicted_labels[i]]}")
    plt.axis('off')
    plt.show()
""")
    
def d4():
    print(
        """
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, SimpleRNN
from tensorflow.keras import Input

#2. Load Dataset
df = pd.read_csv("Google_Stock_Price.csv", thousands=',')

# Take Open column
data = df['Open'].values.reshape(-1, 1)
# Clean non-numeric values like 'GOOGL' / NaN from Open column, then scale
data = pd.to_numeric(df['Open'], errors='coerce').dropna().values.reshape(-1, 1)

scaler = MinMaxScaler(feature_range=(0,1))
data_scaled = scaler.fit_transform(data)

train_size = int(len(data_scaled) * 0.8)
train_data = data_scaled[:train_size]
test_data = data_scaled[train_size:]

def create_dataset(dataset):
    X = []
    y = []
    
    for i in range(60, len(dataset)):
        X.append(dataset[i-60:i, 0])
        y.append(dataset[i, 0])
    
    return np.array(X), np.array(y)

X_train, y_train = create_dataset(train_data)
X_test, y_test = create_dataset(test_data)

X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

model = Sequential([
    Input(shape=(60,1)),
    SimpleRNN(50, return_sequences=True),
    SimpleRNN(50), 
    Dense(1)
])

model.compile(optimizer='adam', loss='mean_squared_error')

model.fit(X_train, y_train, epochs=20, batch_size=32)

predicted = model.predict(X_test)
predicted = scaler.inverse_transform(predicted)
real = scaler.inverse_transform(y_test.reshape(-1,1))

plt.plot(real, color='red', label='Real Price')
plt.plot(predicted, color='blue', label='Predicted Price')
plt.title("Google Stock Price Prediction (RNN)")
plt.xlabel("Time")
plt.ylabel("Price")
plt.legend()
plt.show()
""")