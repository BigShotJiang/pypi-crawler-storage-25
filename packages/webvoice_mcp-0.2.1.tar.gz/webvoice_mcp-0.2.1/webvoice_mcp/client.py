"""HTTP client for the WebVoice REST API."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://webvoice.easytaskflow.app/api/v1"


class WebVoiceAuthClient:
    """Unauthenticated client for agent registration (email OTP)."""

    def __init__(self, base_url: str | None = None, timeout: float = 60.0):
        self.base_url = (base_url or os.environ.get("WEBVOICE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

    def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.base_url}/{path.lstrip('/')}"
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                url,
                headers={"Accept": "application/json", "Content-Type": "application/json"},
                json=body,
            )
        try:
            data = response.json()
        except json.JSONDecodeError:
            data = {"message": response.text[:500]}
        if response.status_code >= 400:
            msg = data.get("error") or data.get("message") or response.text[:300]
            raise WebVoiceAPIError(str(msg), status_code=response.status_code, payload=data)
        return data

    def send_registration_code(
        self,
        email: str,
        accept_privacy: bool = True,
        accept_terms: bool = True,
    ) -> dict[str, Any]:
        return self._post(
            "auth/send-code/",
            {
                "email": email.strip().lower(),
                "accept_privacy": accept_privacy,
                "accept_terms": accept_terms,
            },
        )

    def verify_registration_code(
        self,
        email: str,
        code: str,
        create_api_key: bool = True,
        api_key_name: str = "Agent",
    ) -> dict[str, Any]:
        return self._post(
            "auth/verify-code/",
            {
                "email": email.strip().lower(),
                "code": code.strip(),
                "accept_privacy": True,
                "accept_terms": True,
                "create_api_key": create_api_key,
                "api_key_name": api_key_name,
            },
        )


# Common Kokoro voice defaults when the agent omits voice id
DEFAULT_VOICES = {
    "it": "if_sara",
    "en": "af_sarah",
    "es": "ef_dora",
    "fr": "ff_siwis",
    "de": "bm_george",
}


class WebVoiceAPIError(Exception):
    def __init__(self, message: str, status_code: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload or {}


class WebVoiceClient:
    def __init__(self, api_key: str | None = None, base_url: str | None = None, timeout: float = 120.0):
        self.api_key = (api_key or os.environ.get("WEBVOICE_API_KEY") or "").strip()
        if not self.api_key:
            raise WebVoiceAPIError(
                "WEBVOICE_API_KEY is required. Create a key at WebVoice → API dashboard."
            )
        self.base_url = (base_url or os.environ.get("WEBVOICE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "X-API-Key": self.api_key,
            "Accept": "application/json",
        }

    def _request(self, method: str, path: str, **kwargs) -> dict[str, Any]:
        url = f"{self.base_url}/{path.lstrip('/')}"
        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(method, url, headers=self._headers(), **kwargs)
        try:
            data = response.json()
        except json.JSONDecodeError:
            data = {"message": response.text[:500]}
        if response.status_code >= 400:
            msg = data.get("message") or data.get("error") or response.text[:300]
            if isinstance(data.get("error"), dict):
                msg = data["error"].get("message") or msg
            raise WebVoiceAPIError(str(msg), status_code=response.status_code, payload=data)
        return data

    def status(self) -> dict[str, Any]:
        return self._request("GET", "status/")

    def onboarding(self) -> dict[str, Any]:
        return self._request("GET", "onboarding/")

    def create_api_key(self, name: str = "Agent") -> dict[str, Any]:
        return self._request("POST", "keys/", json={"name": name})

    def list_chat_models(self) -> dict[str, Any]:
        return self._request("GET", "chat/models/")

    def list_voices(self, language: str | None = None, provider: str | None = None) -> dict[str, Any]:
        params: dict[str, str] = {}
        if language:
            params["language"] = language
        if provider:
            params["provider"] = provider
        return self._request("GET", "voices/", params=params)

    def chat(
        self,
        messages: list[dict[str, Any]],
        model: str = "deepseek-v4-flash",
        provider: str | None = None,
        max_tokens: int = 2000,
        temperature: float = 0.7,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": False,
        }
        if provider:
            body["provider"] = provider
        if tools:
            body["tools"] = tools
        if tool_choice is not None:
            body["tool_choice"] = tool_choice
        return self._request("POST", "chat/completions/", json=body)

    def _resolve_voice(self, language: str, voice: str | None, provider: str | None) -> str:
        if voice and voice.strip():
            return voice.strip()
        default = DEFAULT_VOICES.get(language.split("-")[0].lower())
        if default:
            return default
        data = self.list_voices(language=language, provider=provider)
        voices = data.get("voices") or []
        if isinstance(voices, dict):
            for lang_voices in voices.values():
                if lang_voices:
                    return lang_voices[0].get("id") or lang_voices[0].get("voice_id") or ""
        elif voices:
            first = voices[0]
            return first.get("id") or first.get("voice_id") or ""
        raise WebVoiceAPIError(f"No default voice for language {language!r}; pass voice explicitly.")

    def tts(
        self,
        text: str,
        language: str = "it",
        voice: str | None = None,
        provider: str = "kokoro",
        speed: float = 0.9,
        output_path: str | None = None,
    ) -> dict[str, Any]:
        import base64

        voice_id = self._resolve_voice(language, voice, provider)
        data = self._request(
            "POST",
            "tts/",
            json={
                "text": text,
                "language": language,
                "voice": voice_id,
                "provider": provider,
                "speed": speed,
            },
        )
        audio_b64 = data.get("audio") or ""
        saved_path = None
        if output_path and audio_b64:
            path = Path(output_path).expanduser()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(base64.b64decode(audio_b64))
            saved_path = str(path.resolve())
        result = {
            "success": True,
            "format": data.get("format", "mp3"),
            "duration": data.get("duration"),
            "voice": voice_id,
            "provider": provider,
            "credits_used": data.get("credits_used"),
            "credits_remaining": data.get("credits_remaining"),
            "output_path": saved_path,
            "audio_base64_length": len(audio_b64),
        }
        if not saved_path and len(audio_b64) <= 8000:
            result["audio_base64"] = audio_b64
        elif not saved_path:
            result["note"] = (
                "Audio too large to inline; set output_path to save the MP3 file locally."
            )
        return result

    def stt(self, audio_path: str, language: str | None = None) -> dict[str, Any]:
        path = Path(audio_path).expanduser()
        if not path.is_file():
            raise WebVoiceAPIError(f"Audio file not found: {path}")
        suffix = path.suffix.lower() or ".mp3"
        data: dict[str, str] = {}
        if language and language not in ("", "auto"):
            data["language"] = language
        with httpx.Client(timeout=self.timeout) as client:
            with path.open("rb") as fh:
                response = client.post(
                    f"{self.base_url}/stt/",
                    headers=self._headers(),
                    files={"audio": (path.name, fh, "application/octet-stream")},
                    data=data,
                )
        try:
            payload = response.json()
        except json.JSONDecodeError:
            payload = {"message": response.text[:500]}
        if response.status_code >= 400:
            msg = payload.get("message") or payload.get("error") or response.text[:300]
            raise WebVoiceAPIError(str(msg), status_code=response.status_code, payload=payload)
        return payload

    def translate(
        self,
        text: str,
        target_language: str,
        source_language: str = "auto",
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "translation/",
            json={
                "text": text,
                "source_language": source_language,
                "target_language": target_language,
            },
        )

    def image(
        self,
        prompt: str,
        aspect_ratio: str | None = None,
        output_path: str | None = None,
    ) -> dict[str, Any]:
        import base64

        body: dict[str, Any] = {"prompt": prompt, "response_format": "base64"}
        if aspect_ratio:
            body["aspect_ratio"] = aspect_ratio
        data = self._request("POST", "image/", json=body)
        images = data.get("images") or ([data["image"]] if data.get("image") else [])
        saved_path = None
        if output_path and images:
            path = Path(output_path).expanduser()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(base64.b64decode(images[0]))
            saved_path = str(path.resolve())
        return {
            "success": True,
            "count": data.get("count", len(images)),
            "credits_used": data.get("credits_used"),
            "credits_remaining": data.get("credits_remaining"),
            "output_path": saved_path,
            "image_base64_length": len(images[0]) if images else 0,
        }
