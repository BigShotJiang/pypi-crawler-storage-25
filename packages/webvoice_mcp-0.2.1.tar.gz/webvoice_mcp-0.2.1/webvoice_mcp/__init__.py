"""WebVoice MCP server — connect Cursor and agents to WebVoice via stdio."""

__version__ = "0.1.0"
