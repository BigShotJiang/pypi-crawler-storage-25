"""WebVoice MCP server (stdio) — exposes REST API as MCP tools for Cursor and other agents."""
from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from webvoice_mcp.client import WebVoiceAPIError, WebVoiceAuthClient, WebVoiceClient

INSTRUCTIONS = """
WebVoice MCP connects Cursor (or any MCP client) to webvoice.easytaskflow.app using your API key.
Credits are billed on your WebVoice account (chat, TTS, STT, translation, images).

Typical voice agent flow:
1. webvoice_chat — reason with DeepSeek
2. webvoice_tts — speak the reply (set output_path to save MP3)
3. webvoice_stt — transcribe user audio from a local file path

Requires environment variable WEBVOICE_API_KEY (wv_…).
Registration (no key yet): webvoice_register_send_code → email OTP → webvoice_register_verify → api_key + Solana memo.
Optional: WEBVOICE_BASE_URL (default https://webvoice.easytaskflow.app/api/v1).
""".strip()

mcp = FastMCP(
    "WebVoice",
    instructions=INSTRUCTIONS,
    website_url="https://webvoice.easytaskflow.app",
)


def _client() -> WebVoiceClient:
    return WebVoiceClient()


def _json_result(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)


def _handle(exc: Exception) -> str:
    if isinstance(exc, WebVoiceAPIError):
        return _json_result({
            "error": str(exc),
            "status_code": exc.status_code,
            "details": exc.payload,
        })
    return _json_result({"error": str(exc)})


def _site_base() -> str:
    import os
    api = (os.environ.get("WEBVOICE_BASE_URL") or "https://webvoice.easytaskflow.app/api/v1").rstrip("/")
    if api.endswith("/api/v1"):
        return api[: -len("/api/v1")]
    return os.environ.get("WEBVOICE_SITE_URL", "https://webvoice.easytaskflow.app").rstrip("/")


@mcp.tool(
    name="webvoice_account_links",
    description=(
        "Signup, API keys, PayPal recharge, Solana top-up URLs, and credit balance. "
        "Use when the user or agent needs to register or buy credits."
    ),
)
def webvoice_account_links() -> str:
    try:
        base = _site_base()
        data = {
            "signup_login": f"{base}/accounts/login/",
            "api_keys": f"{base}/api/",
            "buy_credits_paypal": f"{base}/billing/purchase/",
            "solana_topup": f"{base}/billing/solana/",
            "note": "Solana page shows wallet + personal memo after login. API key required for MCP tools.",
        }
        try:
            data["status"] = _client().status()
        except Exception:
            pass
        return _json_result(data)
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_register_send_code",
    description=(
        "Start agent registration: send OTP to email. Requires accept_privacy and accept_terms. "
        "Next: read code from email, then call webvoice_register_verify."
    ),
)
def webvoice_register_send_code(
    email: str,
    accept_privacy: bool = True,
    accept_terms: bool = True,
) -> str:
    try:
        return _json_result(
            WebVoiceAuthClient().send_registration_code(email, accept_privacy, accept_terms)
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_register_verify",
    description=(
        "Complete registration with email OTP. Returns api_key (once), credits, Solana wallet + memo for top-up. "
        "Set WEBVOICE_API_KEY in MCP config after this."
    ),
)
def webvoice_register_verify(
    email: str,
    code: str,
    api_key_name: str = "Agent",
) -> str:
    try:
        return _json_result(
            WebVoiceAuthClient().verify_registration_code(
                email, code, create_api_key=True, api_key_name=api_key_name,
            )
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_onboarding",
    description="Get credits, Solana deposit wallet/memo, and recharge URLs (requires API key).",
)
def webvoice_onboarding() -> str:
    try:
        return _json_result(_client().onboarding())
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_status",
    description="Check WebVoice account credits and API key status.",
)
def webvoice_status() -> str:
    try:
        return _json_result(_client().status())
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_list_chat_models",
    description="List AI chat models available for your account (id, credits per request).",
)
def webvoice_list_chat_models() -> str:
    try:
        return _json_result(_client().list_chat_models())
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_list_voices",
    description="List TTS voices. Optional language (it, en, …) and provider (kokoro, google, …).",
)
def webvoice_list_voices(language: str = "", provider: str = "") -> str:
    try:
        return _json_result(
            _client().list_voices(
                language=language or None,
                provider=provider or None,
            )
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_chat",
    description=(
        "Chat completion via WebVoice (DeepSeek, OpenRouter, …). "
        "Pass messages as JSON array. Returns assistant content and/or tool_calls. "
        "Optional tools/tool_choice for agent function calling (DeepSeek & OpenRouter)."
    ),
)
def webvoice_chat(
    messages_json: str,
    model: str = "deepseek-v4-flash",
    provider: str = "",
    max_tokens: int = 2000,
    temperature: float = 0.7,
    tools_json: str = "",
    tool_choice: str = "",
) -> str:
    try:
        messages = json.loads(messages_json)
        if not isinstance(messages, list):
            raise ValueError("messages_json must be a JSON array")
        tools = json.loads(tools_json) if tools_json.strip() else None
        tc: str | dict[str, Any] | None = tool_choice.strip() or None
        if tc and tc.startswith("{"):
            tc = json.loads(tc)
        return _json_result(
            _client().chat(
                messages=messages,
                model=model,
                provider=provider or None,
                max_tokens=max_tokens,
                temperature=temperature,
                tools=tools,
                tool_choice=tc,
            )
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_tts",
    description=(
        "Text-to-speech. Default provider kokoro (local, 1 credit/10min). "
        "Set output_path to save MP3 on disk. Cloud providers cost 2 credits/10min."
    ),
)
def webvoice_tts(
    text: str,
    language: str = "it",
    voice: str = "",
    provider: str = "kokoro",
    speed: float = 0.9,
    output_path: str = "",
) -> str:
    try:
        return _json_result(
            _client().tts(
                text=text,
                language=language,
                voice=voice or None,
                provider=provider,
                speed=speed,
                output_path=output_path or None,
            )
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_stt",
    description="Speech-to-text from a local audio file path (.mp3, .wav, .m4a, .flac).",
)
def webvoice_stt(audio_path: str, language: str = "") -> str:
    try:
        return _json_result(
            _client().stt(audio_path=audio_path, language=language or None)
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_translate",
    description="Translate text between languages (DeepSeek). Uses account credits.",
)
def webvoice_translate(
    text: str,
    target_language: str,
    source_language: str = "auto",
) -> str:
    try:
        return _json_result(
            _client().translate(text, target_language, source_language)
        )
    except Exception as exc:
        return _handle(exc)


@mcp.tool(
    name="webvoice_image",
    description="Generate an image from a text prompt (MiniMax). Set output_path to save PNG/JPEG.",
)
def webvoice_image(
    prompt: str,
    aspect_ratio: str = "",
    output_path: str = "",
) -> str:
    try:
        return _json_result(
            _client().image(
                prompt=prompt,
                aspect_ratio=aspect_ratio or None,
                output_path=output_path or None,
            )
        )
    except Exception as exc:
        return _handle(exc)


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
