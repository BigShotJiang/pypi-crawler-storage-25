# Kokoro VoiceITA - App Python per Generazione Voce Locale

App Python per generare voce usando **Kokoro TTS** completamente in locale, con supporto per la voce "Sara".

## 🎯 Caratteristiche

- ✅ Generazione voce completamente locale (nessun invio dati a server esterni)
- ✅ Supporto per la voce "Sara" e altre voci Kokoro
- ✅ Controllo velocità e formato audio
- ✅ API semplice e intuitiva
- ✅ Gestione automatica delle voci disponibili

## 📋 Prerequisiti

1. **Python 3.9 - 3.12** (⚠️ Python 3.13+ non è supportato da kokoro-tts)
   - Se hai Python 3.13+, usa un ambiente virtuale con Python 3.12 o Docker
   - Vedi [README_PYTHON.md](README_PYTHON.md) per dettagli
2. **Server Kokoro TTS locale** - Vedi [COMANDI_SERVER.md](COMANDI_SERVER.md) per dettagli completi

### 🚀 Avvio Rapido del Server

**Metodo più semplice:** Usa lo script automatico incluso:

```bash
python start_server.py
```

Lo script proverà automaticamente diversi metodi per avviare il server.

### Opzioni Manuali

**Opzione 1: Docker (Consigliato)**

```bash
# Clona il repository Kokoro-FastAPI
git clone https://github.com/remsky/Kokoro-FastAPI.git
cd Kokoro-FastAPI

# Per CPU
cd docker/cpu
docker compose up --build

# Oppure per GPU (se disponibile)
cd docker/gpu
docker compose up --build
```

Il server sarà disponibile su `http://localhost:8880`

**Opzione 2: Server Locale Incluso (FastAPI)**

```bash
# Installa dipendenze server
pip install -r requirements-server.txt

# Installa backend TTS (scegli uno):
pip install kokoro-tts  # Richiede Python 3.9-3.12
# oppure
pip install pykokoro

# Avvia il server incluso
python kokoro_server.py
```

**Opzione 3: uvicorn (se hai Kokoro-FastAPI come modulo)**

```bash
pip install kokoro-fastapi
uvicorn kokoro_fastapi.app:app --host 0.0.0.0 --port 8880
```

📖 **Per maggiori dettagli, vedi [COMANDI_SERVER.md](COMANDI_SERVER.md)**

## 🚀 Installazione

1. **Clona o scarica questo progetto**

2. **Installa le dipendenze del CLIENT Python:**

```bash
# Per usare il client (sempre necessario)
pip install -r requirements.txt
```

3. **Installa il SERVER Kokoro TTS (scegli un'opzione):**

**Opzione A: Docker (Consigliato - Nessuna installazione Python)**
```bash
# Vedi COMANDI_SERVER.md per dettagli
git clone https://github.com/remsky/Kokoro-FastAPI.git
cd Kokoro-FastAPI/docker/cpu
docker compose up --build
```

**Opzione B: Python diretto**
```bash
# Installa il server Kokoro
pip install -r requirements-server.txt

# Oppure direttamente:
pip install kokoro-tts-cli
```

**Nota:** `requirements.txt` contiene solo le dipendenze del **client**. Il **server** è separato e può essere avviato con Docker (più semplice) o installato con `requirements-server.txt`.

## 💻 Utilizzo

### Utilizzo Base

```python
from kokoro_tts_client import KokoroTTSClient

# Crea il client
client = KokoroTTSClient()

# Genera audio con la voce Sara
client.generate_speech_file(
    text="Ciao! Sono Sara. Questo è un test.",
    output_file="output/sara_test.wav",
    voice="sara",  # Cerca automaticamente la voce Sara
    speed=1.0
)
```

### Esempio Completo

```python
from kokoro_tts_client import KokoroTTSClient

# Inizializza il client
client = KokoroTTSClient(base_url="http://localhost:8880")

# Verifica connessione
if client.check_connection():
    print("Server raggiungibile!")
    
    # Mostra voci disponibili
    voices = client.get_available_voices()
    print(f"Voci disponibili: {voices}")
    
    # Genera audio
    audio_data = client.generate_speech(
        text="Questo è un esempio di sintesi vocale.",
        voice="af_sarah",  # o "sara" per ricerca automatica
        output_file="output/esempio.wav",
        speed=1.0,
        response_format="wav"
    )
```

### Eseguire l'Esempio

```bash
python kokoro_tts_client.py
```

Questo eseguirà un esempio completo che:
- Verifica la connessione al server
- Mostra le voci disponibili
- Cerca la voce "Sara"
- Genera un audio di esempio

## 🎤 Voci Disponibili

Kokoro supporta molte voci con prefissi:
- `af_*` - Voci femminili (es. `af_sarah`, `af_bella`, `af_sky`)
- `am_*` - Voci maschili (es. `am_adam`)

La funzione `find_voice()` cerca automaticamente la voce "Sara" tra quelle disponibili.

## 📝 Parametri

### `generate_speech()`

- `text` (str): Testo da convertire in voce
- `voice` (str): Nome della voce (default: "af_sarah")
- `output_file` (str, opzionale): Percorso del file di output
- `speed` (float): Velocità di riproduzione (default: 1.0, range consigliato: 0.5-2.0)
- `response_format` (str): Formato audio - "wav", "mp3", "opus" (default: "wav")

## 📁 Struttura Progetto

```
kokoro_voiceita/
├── kokoro_tts_client.py  # Cliente principale
├── start_server.py       # Script per avviare il server
├── example_usage.py      # Esempi di utilizzo
├── config.py            # File di configurazione
├── requirements.txt      # Dipendenze Python
├── README.md            # Questa documentazione
├── COMANDI_SERVER.md    # Guida dettagliata per avviare il server
└── output/              # Directory per file audio generati (creata automaticamente)
```

## 🔧 Risoluzione Problemi

### Errore: "Impossibile connettersi al server"

1. Verifica che il server Kokoro TTS sia avviato
2. Controlla che l'URL sia corretto (default: `http://localhost:8880`)
3. Verifica che la porta non sia bloccata da firewall

### Voce "Sara" non trovata

- La funzione cerca automaticamente varianti come `af_sarah`, `af_sara`
- Puoi specificare direttamente l'ID della voce (es. `af_sarah`)
- Usa `get_available_voices()` per vedere tutte le voci disponibili

### Formato MP3 non funziona

- Assicurati che FFmpeg sia installato sul sistema
- Usa "wav" come formato se hai problemi

## 📚 Risorse

- [Kokoro TTS](https://kokorotts.net/)
- [Kokoro-FastAPI](https://github.com/remsky/Kokoro-FastAPI)
- [Documentazione Kokoro](https://docs.azerion.ai/)

## 📄 Licenza

Questo progetto è fornito come esempio. Verifica le licenze di Kokoro TTS per uso commerciale.

## 🤝 Contributi

Sentiti libero di aprire issue o pull request per miglioramenti!
