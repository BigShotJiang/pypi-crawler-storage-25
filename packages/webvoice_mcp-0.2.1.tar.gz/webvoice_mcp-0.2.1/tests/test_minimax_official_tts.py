"""
Test di integrazione: generazione audio via MiniMax API ufficiale (api.minimax.io / WebSocket T2A).

Richiede MINIMAX_API_KEY in ambiente o in config.py. Senza chiave il test viene saltato.

Modello TTS: usa ``MINIMAX_TTS_MODEL`` da settings, oppure override solo per questo test con
``MINIMAX_TTS_MODEL_TEST`` (override solo test) se il piano
non include il default.
"""
import os
import unittest

from django.conf import settings
from django.test import TestCase


def _minimax_key_configured() -> bool:
    return bool((getattr(settings, "MINIMAX_API_KEY", None) or "").strip())


def _plan_not_supported_error(exc: BaseException) -> bool:
    msg = str(exc).lower()
    return "token plan" in msg or "not support" in msg


@unittest.skipUnless(
    _minimax_key_configured(),
    "MINIMAX_API_KEY non configurata — imposta la chiave o salta questo test",
)
class MinimaxOfficialTTSGenerationTests(TestCase):
    """Genera un MP3 breve con il provider MiniMax ufficiale (``minimax_official``)."""

    def test_generate_speech_returns_mp3_bytes(self):
        from audio.minimax_official_tts_service import (
            DEFAULT_MINIMAX_TTS_MODEL,
            MinimaxOfficialTTSService,
        )

        svc = MinimaxOfficialTTSService()
        self.assertTrue(svc.enabled, "Servizio dovrebbe essere abilitato con API key")

        # Modello: env di test > settings > default HD
        model = (
            (os.environ.get("MINIMAX_TTS_MODEL_TEST") or "").strip()
            or (getattr(settings, "MINIMAX_TTS_MODEL", None) or "").strip()
            or DEFAULT_MINIMAX_TTS_MODEL
        )

        text = "Hello. This is an automated test of MiniMax official text to speech."
        try:
            mp3_bytes, sample_rate, duration = svc.generate_speech(
                text,
                voice="English_expressive_narrator",
                language="en",
                speed=1.0,
                trim=True,
                minimax_tts_model=model,
            )
        except ValueError as e:
            if _plan_not_supported_error(e):
                self.skipTest(
                    f"Piano MiniMax non include questo modello ({model!r}): {e}. "
                    "Prova MINIMAX_TTS_MODEL_TEST con un altro ID dalla console MiniMax."
                )
            raise

        self.assertIsInstance(mp3_bytes, bytes)
        self.assertGreater(len(mp3_bytes), 500, "MP3 dovrebbe avere dimensione > 500 byte")
        self.assertEqual(sample_rate, 32000)
        self.assertGreater(duration, 0.1, "Durata stimata > 0.1 s")

        # Magic bytes MP3 (frame sync)
        self.assertTrue(
            mp3_bytes[:2] == b"\xff\xfb" or mp3_bytes[:2] == b"\xff\xfa" or mp3_bytes[:3] == b"ID3",
            "Il file dovrebbe iniziare come MP3 valido",
        )
