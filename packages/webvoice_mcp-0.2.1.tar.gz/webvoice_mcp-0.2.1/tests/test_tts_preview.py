"""
Allineato a audio.views.tts_job_submit: text_preview non deve superare max_length 200 del DB.
"""
from django.test import TestCase


def compute_tts_text_preview(text: str) -> str:
    """Stessa logica di tts_job_submit (MySQL CharField 200)."""
    return (text[:199] + "…") if len(text) > 199 else text


class TtsTextPreviewTests(TestCase):
    def test_preview_never_exceeds_200_chars(self):
        for n in (0, 1, 50, 199, 200, 201, 5000):
            text = "a" * n
            if n == 0:
                text = ""
            preview = compute_tts_text_preview(text)
            self.assertLessEqual(
                len(preview),
                200,
                msg=f"n={n} len(preview)={len(preview)}",
            )

    def test_short_text_unchanged(self):
        self.assertEqual(compute_tts_text_preview("ciao"), "ciao")

    def test_long_text_truncates_with_ellipsis(self):
        t = "b" * 250
        p = compute_tts_text_preview(t)
        self.assertTrue(p.endswith("…"))
        self.assertEqual(len(p), 200)
