"""Tests for WebVoice MCP client (mocked HTTP)."""
from __future__ import annotations

import base64
from unittest.mock import MagicMock, patch

import pytest

from webvoice_mcp.client import WebVoiceAPIError, WebVoiceClient


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("WEBVOICE_API_KEY", "wv_test_key")
    monkeypatch.delenv("WEBVOICE_BASE_URL", raising=False)
    return WebVoiceClient()


def test_missing_api_key(monkeypatch):
    monkeypatch.delenv("WEBVOICE_API_KEY", raising=False)
    with pytest.raises(WebVoiceAPIError, match="WEBVOICE_API_KEY"):
        WebVoiceClient()


def test_status(client):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"success": True, "credits": 42.0}

    with patch("httpx.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client_cls.return_value.__enter__.return_value = mock_client
        mock_client.request.return_value = mock_response

        data = client.status()

    assert data["credits"] == 42.0
    call_args = mock_client.request.call_args
    assert call_args[0][0] == "GET"
    assert call_args[0][1].endswith("/status/")


def test_tts_saves_output(client, tmp_path):
    audio_bytes = b"fake-mp3"
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "success": True,
        "audio": base64.b64encode(audio_bytes).decode(),
        "format": "mp3",
        "duration": 1.5,
        "credits_used": 1.0,
        "credits_remaining": 99.0,
    }

    out = tmp_path / "out.mp3"

    with patch("httpx.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client_cls.return_value.__enter__.return_value = mock_client
        mock_client.request.return_value = mock_response

        result = client.tts("Ciao", language="it", voice="if_sara", output_path=str(out))

    assert result["output_path"] == str(out.resolve())
    assert out.read_bytes() == audio_bytes
    body = mock_client.request.call_args[1]["json"]
    assert body["voice"] == "if_sara"
    assert body["provider"] == "kokoro"


def test_tts_default_voice(client):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"success": True, "audio": "", "format": "mp3"}

    with patch("httpx.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client_cls.return_value.__enter__.return_value = mock_client
        mock_client.request.return_value = mock_response

        client.tts("Hello", language="it")

    body = mock_client.request.call_args[1]["json"]
    assert body["voice"] == "if_sara"


def test_chat(client):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"role": "assistant", "content": "Hi"}}],
    }

    with patch("httpx.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client_cls.return_value.__enter__.return_value = mock_client
        mock_client.request.return_value = mock_response

        data = client.chat(messages=[{"role": "user", "content": "Hello"}])

    assert data["choices"][0]["message"]["content"] == "Hi"
    body = mock_client.request.call_args[1]["json"]
    assert body["stream"] is False
    assert body["model"] == "deepseek-v4-flash"


def test_api_error(client):
    mock_response = MagicMock()
    mock_response.status_code = 402
    mock_response.text = "Insufficient credits"
    mock_response.json.return_value = {"message": "Insufficient credits"}

    with patch("httpx.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client_cls.return_value.__enter__.return_value = mock_client
        mock_client.request.return_value = mock_response

        with pytest.raises(WebVoiceAPIError, match="Insufficient credits") as exc:
            client.status()

    assert exc.value.status_code == 402


def test_stt_file_not_found(client):
    with pytest.raises(WebVoiceAPIError, match="not found"):
        client.stt("/nonexistent/audio.mp3")
