"""
Test per accounts.utils: cartelle media utente.
"""
import os
import tempfile

from django.contrib.auth.models import User
from django.test import TestCase, override_settings

from accounts.utils import (
    USER_MEDIA_SUBDIRS,
    audit_all_user_media_directories,
    ensure_all_users_media_directories,
    ensure_user_media_directories,
    list_missing_media_subdirs_for_user,
)


class EnsureUserMediaDirectoriesTests(TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    @override_settings(MEDIA_ROOT=None)
    def test_ensure_skips_without_media_root(self):
        user = User.objects.create_user(username="u1", email="u1@example.com", password="x")
        ensure_user_media_directories(user)
        # Nessun crash

    def test_ensure_creates_all_subdirs(self):
        with self.settings(MEDIA_ROOT=self.tmp.name):
            user = User.objects.create_user(username="u2", email="u2@example.com", password="x")
            ensure_user_media_directories(user)
            uid = str(user.pk)
            for sub in USER_MEDIA_SUBDIRS:
                path = os.path.join(self.tmp.name, sub, uid)
                self.assertTrue(os.path.isdir(path), msg=path)

    def test_list_missing_empty_after_ensure(self):
        with self.settings(MEDIA_ROOT=self.tmp.name):
            user = User.objects.create_user(username="u3", email="u3@example.com", password="x")
            ensure_user_media_directories(user)
            self.assertEqual(list_missing_media_subdirs_for_user(user), [])

    def test_list_missing_when_no_media_root_lists_all_subdir_names(self):
        with self.settings(MEDIA_ROOT=None):
            user = User.objects.create_user(username="u4", email="u4@example.com", password="x")
            missing = list_missing_media_subdirs_for_user(user)
            self.assertEqual(set(missing), set(USER_MEDIA_SUBDIRS))

    def test_audit_and_ensure_all(self):
        with self.settings(MEDIA_ROOT=self.tmp.name):
            User.objects.create_user(username="a", email="a@example.com", password="x")
            User.objects.create_user(username="b", email="b@example.com", password="x")
            r = ensure_all_users_media_directories()
            self.assertEqual(r["users_processed"], 2)
            audit = audit_all_user_media_directories()
            self.assertTrue(audit["configured"])
            self.assertEqual(audit["total_users"], 2)
            self.assertEqual(audit["users_with_gaps"], 0)
            self.assertEqual(audit["users_complete"], 2)
