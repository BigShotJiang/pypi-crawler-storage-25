"""Tests for agent registration API (stateless email OTP + API key)."""
import json
from decimal import Decimal
from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import Client, TestCase, override_settings

from accounts.models import OTPCode
from api.models import APIKey


@override_settings(
    SOLANA_DEPOSIT_ENABLED=True,
    SOLANA_DEPOSIT_WALLET="DepositWallet1111111111111111111111111111",
)
class AgentRegistrationAPITests(TestCase):
    def setUp(self):
        self.client = Client()
        self.json_headers = {'HTTP_ACCEPT': 'application/json'}

    def _post_json(self, url, payload):
        return self.client.post(
            url,
            data=json.dumps(payload),
            content_type='application/json',
            **self.json_headers,
        )

    @patch('accounts.views.send_otp_email', return_value=True)
    def test_send_code_json(self, _mock_mail):
        resp = self._post_json(
            '/api/v1/auth/send-code/',
            {
                'email': 'newagent@test.com',
                'accept_privacy': True,
                'accept_terms': True,
            },
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data['success'])
        self.assertTrue(data['is_new_user'])

    @patch('accounts.views.send_otp_email', return_value=True)
    def test_verify_creates_user_and_api_key_stateless(self, _mock_mail):
        email = 'agent2@test.com'
        self._post_json(
            '/api/v1/auth/send-code/',
            {'email': email, 'accept_privacy': True, 'accept_terms': True},
        )
        otp = OTPCode.objects.filter(email=email, used=False).latest('created_at')

        resp = self._post_json(
            '/api/v1/auth/verify-code/',
            {
                'email': email,
                'code': otp.code,
                'accept_privacy': True,
                'accept_terms': True,
                'create_api_key': True,
                'api_key_name': 'test-agent',
            },
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data['success'])
        self.assertTrue(data['is_new_user'])
        self.assertIn('api_key', data)
        self.assertTrue(data['api_key'].startswith('wv_'))
        self.assertIn('onboarding', data)
        self.assertIn('solana', data['onboarding'])
        self.assertTrue(data['onboarding']['solana']['available'])
        self.assertIn('memo_code', data['onboarding']['solana'])
        self.assertTrue(data['onboarding']['can_use_api'])

        user = User.objects.get(email=email)
        self.assertGreaterEqual(user.profile.credits, Decimal('20'))
        self.assertEqual(APIKey.objects.filter(user=user).count(), 1)

    def test_onboarding_requires_api_key(self):
        resp = self.client.get(
            '/api/v1/onboarding/',
            HTTP_ACCEPT='application/json',
        )
        self.assertEqual(resp.status_code, 401)

    @patch('accounts.views.send_otp_email', return_value=True)
    def test_onboarding_with_api_key(self, _mock_mail):
        email = 'agent3@test.com'
        self._post_json(
            '/api/v1/auth/send-code/',
            {'email': email, 'accept_privacy': True, 'accept_terms': True},
        )
        otp = OTPCode.objects.filter(email=email, used=False).latest('created_at')
        verify = self._post_json(
            '/api/v1/auth/verify-code/',
            {'email': email, 'code': otp.code, 'create_api_key': True},
        ).json()
        api_key = verify['api_key']

        resp = self.client.get(
            '/api/v1/onboarding/',
            HTTP_ACCEPT='application/json',
            HTTP_X_API_KEY=api_key,
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data['success'])
        self.assertIn('solana', data)

    @patch('accounts.views.send_otp_email', return_value=True)
    def test_verify_existing_user_not_marked_new_despite_session(self, _mock_mail):
        """Session is_new_user from another send-code must not flag returning users as new."""
        email = 'returning@test.com'
        User.objects.create_user(username='returning', email=email)
        User.objects.get(email=email).set_unusable_password()

        # Poison session: send-code for a different new email
        self._post_json(
            '/api/v1/auth/send-code/',
            {'email': 'other-new@test.com', 'accept_privacy': True, 'accept_terms': True},
        )
        otp = OTPCode.create_code(email, '127.0.0.1', validity_minutes=15)

        resp = self._post_json(
            '/api/v1/auth/verify-code/',
            {'email': email, 'code': otp.code, 'create_api_key': True},
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertFalse(data['is_new_user'])
        self.assertIn('api_key', data)

    @patch('billing.solana_deposits.get_or_create_deposit_account')
    @patch('accounts.views.send_otp_email', return_value=True)
    def test_onboarding_survives_missing_solana_tables(self, _mock_mail, mock_memo):
        from django.db.utils import ProgrammingError

        mock_memo.side_effect = ProgrammingError("Table doesn't exist")
        email = 'nosolana@test.com'
        self._post_json(
            '/api/v1/auth/send-code/',
            {'email': email, 'accept_privacy': True, 'accept_terms': True},
        )
        otp = OTPCode.objects.filter(email=email, used=False).latest('created_at')
        verify = self._post_json(
            '/api/v1/auth/verify-code/',
            {'email': email, 'code': otp.code, 'create_api_key': True},
        )
        self.assertEqual(verify.status_code, 200)
        onboarding = verify.json()['onboarding']
        self.assertIn('api_key', verify.json())
        self.assertFalse(onboarding['solana']['available'])
        self.assertTrue(onboarding['can_use_api'])
