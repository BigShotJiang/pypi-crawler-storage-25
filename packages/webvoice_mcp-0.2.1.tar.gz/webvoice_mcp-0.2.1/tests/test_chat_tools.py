"""
Tests for API chat tools / function calling helpers.
"""
from django.test import SimpleTestCase

from api.chat_tools import (
    merge_tool_calls_delta,
    normalize_messages,
    normalize_tool_choice,
    normalize_tools,
    parse_provider_completion_data,
    provider_supports_tools,
)
from admin_panel.models import ChatAIModel


class NormalizeToolsTests(SimpleTestCase):
    def test_normalize_tools_function(self):
        tools = normalize_tools([
            {
                'type': 'function',
                'function': {
                    'name': 'get_weather',
                    'description': 'Get weather',
                    'parameters': {
                        'type': 'object',
                        'properties': {'city': {'type': 'string'}},
                    },
                },
            },
        ])
        self.assertEqual(tools[0]['function']['name'], 'get_weather')

    def test_tool_choice_defaults_auto(self):
        self.assertEqual(normalize_tool_choice(None, [{'type': 'function', 'function': {'name': 'x'}}]), 'auto')


class NormalizeMessagesAgentTests(SimpleTestCase):
    def test_tool_message_allowed_with_tools(self):
        msgs = normalize_messages([
            {'role': 'user', 'content': 'Weather in Rome?'},
        ], tools=[{'type': 'function', 'function': {'name': 'get_weather'}}])
        self.assertEqual(msgs[-1]['role'], 'user')

    def test_assistant_tool_calls_and_tool_reply(self):
        msgs = normalize_messages([
            {'role': 'user', 'content': 'Weather in Rome?'},
            {
                'role': 'assistant',
                'content': None,
                'tool_calls': [{
                    'id': 'call_1',
                    'type': 'function',
                    'function': {'name': 'get_weather', 'arguments': '{"city":"Rome"}'},
                }],
            },
            {'role': 'tool', 'tool_call_id': 'call_1', 'content': '{"temp": 20}'},
        ], tools=[{'type': 'function', 'function': {'name': 'get_weather'}}])
        self.assertEqual(msgs[-1]['role'], 'tool')
        self.assertEqual(msgs[-2]['tool_calls'][0]['id'], 'call_1')


class ProviderToolsSupportTests(SimpleTestCase):
    def test_deepseek_supported(self):
        model = ChatAIModel(provider=ChatAIModel.PROVIDER_DEEPSEEK, model_id='deepseek-v4-flash')
        self.assertTrue(provider_supports_tools('deepseek-v4-flash', model))

    def test_openrouter_supported(self):
        model = ChatAIModel(provider=ChatAIModel.PROVIDER_OPENROUTER, model_id='openrouter:openai/gpt-4o-mini')
        self.assertTrue(provider_supports_tools('openrouter:openai/gpt-4o-mini', model))

    def test_groq_not_supported(self):
        model = ChatAIModel(provider=ChatAIModel.PROVIDER_GROQ, model_id='llama-3.1-8b-instant')
        self.assertFalse(provider_supports_tools('llama-3.1-8b-instant', model))


class ParseProviderCompletionTests(SimpleTestCase):
    def test_tool_calls_response(self):
        parsed = parse_provider_completion_data({
            'choices': [{
                'message': {
                    'role': 'assistant',
                    'content': None,
                    'tool_calls': [{
                        'id': 'call_abc',
                        'type': 'function',
                        'function': {'name': 'get_weather', 'arguments': '{}'},
                    }],
                },
                'finish_reason': 'tool_calls',
            }],
            'usage': {'prompt_tokens': 10, 'completion_tokens': 5, 'total_tokens': 15},
        })
        self.assertEqual(parsed['finish_reason'], 'tool_calls')
        self.assertEqual(len(parsed['tool_calls']), 1)


class MergeToolCallsDeltaTests(SimpleTestCase):
    def test_merge_streaming_tool_call(self):
        acc = merge_tool_calls_delta([], [{
            'index': 0,
            'id': 'call_1',
            'function': {'name': 'get_', 'arguments': '{"ci'},
        }])
        acc = merge_tool_calls_delta(acc, [{
            'index': 0,
            'function': {'name': 'weather', 'arguments': 'ty":"Rome"}'},
        }])
        self.assertEqual(acc[0]['function']['name'], 'get_weather')
        self.assertIn('Rome', acc[0]['function']['arguments'])
