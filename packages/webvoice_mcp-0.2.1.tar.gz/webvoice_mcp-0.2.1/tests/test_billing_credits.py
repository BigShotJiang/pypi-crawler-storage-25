"""
Test per billing.utils: calcolo crediti TTS/STT (logica pura).
"""
from decimal import Decimal

from django.test import TestCase, override_settings

from billing.utils import (
    calculate_stt_credits,
    calculate_tts_credits,
    is_paid_cloud_tts_provider,
    tts_max_text_length,
    validate_tts_text_length,
)


class CalculateTtsCreditsTests(TestCase):
    def test_up_to_10_minutes_one_credit_local(self):
        self.assertEqual(calculate_tts_credits(0, provider='kokoro'), Decimal("1"))
        self.assertEqual(calculate_tts_credits(60 * 10, provider='kokoro'), Decimal("1"))

    def test_above_10_minutes_extra_block_local(self):
        self.assertEqual(calculate_tts_credits(60 * 11, provider='kokoro'), Decimal("2"))

    def test_cloud_tts_double_credits(self):
        self.assertEqual(calculate_tts_credits(60 * 10, provider='google'), Decimal("2"))
        self.assertEqual(calculate_tts_credits(60 * 11, provider='inworld'), Decimal("4"))

    def test_paid_cloud_providers(self):
        for provider in ('google', 'inworld', 'inworld_mini', 'kokoro_fast', 'minimax_official'):
            self.assertTrue(is_paid_cloud_tts_provider(provider))
        self.assertFalse(is_paid_cloud_tts_provider('kokoro'))


@override_settings(
    TTS_CLOUD_MAX_TEXT_LENGTH=2000,
    PREMIUM_USER_MAX_TEXT_LENGTH=50000,
    FREE_USER_MAX_TEXT_LENGTH=5000,
)
class TtsTextLengthTests(TestCase):
    def test_cloud_cap_applies_to_premium(self):
        self.assertEqual(tts_max_text_length('google', has_active_subscription=True), 2000)
        self.assertEqual(tts_max_text_length('kokoro', has_active_subscription=True), 50000)

    def test_validate_cloud_rejects_long_text(self):
        ok, max_len, err = validate_tts_text_length('x' * 2001, 'google', True)
        self.assertFalse(ok)
        self.assertEqual(max_len, 2000)
        self.assertIn('cloud TTS', err)


class CalculateSttCreditsTests(TestCase):
    def test_under_one_minute_half_credit(self):
        self.assertEqual(calculate_stt_credits(30), Decimal("0.5"))

    def test_one_minute_or_more_at_least_one(self):
        self.assertEqual(calculate_stt_credits(60), Decimal("1"))

    def test_long_audio_ceil_blocks(self):
        self.assertEqual(calculate_stt_credits(60 * 10), Decimal("1"))
        self.assertEqual(calculate_stt_credits(60 * 11), Decimal("2"))
