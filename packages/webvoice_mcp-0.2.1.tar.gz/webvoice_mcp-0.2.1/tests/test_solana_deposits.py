"""Tests for Solana deposit parsing and crediting."""
from decimal import Decimal
from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import TestCase, override_settings

from billing.models import SolanaDepositAccount, SolanaDepositPayment
from billing.solana_deposits import (
    credits_for_usd,
    get_or_create_deposit_account,
    parse_deposit,
    process_signature,
)


SAMPLE_USDC_TX = {
    "slot": 100,
    "blockTime": 1700000000,
    "meta": {
        "err": None,
        "preTokenBalances": [],
        "postTokenBalances": [
            {
                "owner": "DepositWallet1111111111111111111111111111",
                "mint": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                "uiTokenAmount": {"uiAmountString": "5"},
            }
        ],
        "logMessages": ['Program log: Memo (len 10): "WVTEST1234"'],
    },
    "transaction": {
        "message": {
            "accountKeys": ["DepositWallet1111111111111111111111111111"],
            "instructions": [
                {"programId": "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr", "parsed": "WVTEST1234"},
            ],
        }
    },
}


SOLANA_SETTINGS = {
    "SOLANA_DEPOSIT_ENABLED": True,
    "SOLANA_DEPOSIT_WALLET": "DepositWallet1111111111111111111111111111",
    "SOLANA_ACCEPT_USDC": True,
    "SOLANA_ACCEPT_SOL": False,
    "SOLANA_CREDITS_PER_USD": Decimal("20"),
    "SOLANA_MIN_USDC": Decimal("1"),
}


@override_settings(**SOLANA_SETTINGS)
class SolanaDepositTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="soluser", email="sol@test.com", password="x")
        self.deposit_account = SolanaDepositAccount.objects.create(
            user=self.user, memo_code="WVTEST1234",
        )

    def test_parse_usdc_deposit(self):
        parsed = parse_deposit(SAMPLE_USDC_TX)
        self.assertEqual(parsed, (SolanaDepositPayment.USDC, Decimal("5"), "WVTEST1234"))

    def test_process_signature_credits_user(self):
        payment = process_signature("sig123456789", tx=SAMPLE_USDC_TX)
        self.assertIsNotNone(payment)
        self.assertEqual(payment.status, SolanaDepositPayment.CREDITED)
        self.assertEqual(payment.credits_granted, Decimal("100.00"))
        self.user.profile.refresh_from_db()
        self.assertEqual(self.user.profile.credits, Decimal("100.00"))

    def test_unmatched_memo(self):
        tx = {**SAMPLE_USDC_TX}
        tx["transaction"] = {
            "message": {
                "accountKeys": ["DepositWallet1111111111111111111111111111"],
                "instructions": [
                    {"programId": "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr", "parsed": "WVUNKNOWN9"},
                ],
            }
        }
        payment = process_signature("sig-unmatched", tx=tx)
        self.assertEqual(payment.status, SolanaDepositPayment.UNMATCHED)
        self.assertIsNone(payment.user)

    def test_get_or_create_deposit_account(self):
        acct = get_or_create_deposit_account(self.user)
        self.assertTrue(acct.memo_code.startswith("WV"))
        again = get_or_create_deposit_account(self.user)
        self.assertEqual(again.pk, acct.pk)

    @override_settings(SOLANA_CREDITS_PER_USD=Decimal("20.04"))
    def test_credits_for_usd(self):
        self.assertEqual(credits_for_usd(Decimal("5")), Decimal("100.20"))
