"""
Smoke test: le route principali risolvono (nessun NoReverseMatch).
"""
from django.test import TestCase
from django.urls import NoReverseMatch, reverse


class UrlReverseSmokeTests(TestCase):
    def test_core_named_routes_resolve(self):
        routes = [
            "accounts:login",
            "accounts:register",
            "admin_panel:home",
            "admin_panel:users",
            "admin_panel:user_media_folders",
            "logo",
            "manifest",
            "service_worker",
            "csrf_token_json",
        ]
        for name in routes:
            with self.subTest(name=name):
                try:
                    reverse(name)
                except NoReverseMatch as e:
                    self.fail(f"reverse({name!r}) failed: {e}")
