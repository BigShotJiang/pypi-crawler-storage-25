# (BETA) BitsXAI

## Model Agnostic XAI + RAI Middleware Layer Python Package | Bitstek.io

**Multi-Modal Explainable and Responsible AI Python Package -  V1**

A modular Python SDK for Explainable AI (XAI) and Responsible AI (RAI), combining model explainability, trust diagnostics, and multi-modal routing in a unified framework.

---

## Description

**Python SDK for modular Explainable & Responsible AI : model adapters, explainers, risk diagnostics, and multi-modal routing in one framework.**

---
## Developer

Developed and maintained by [@8bitjawad](https://github.com/8bitjawad)

# Overview

`This project` is designed to provide a structured framework for building, testing, and extending explainability and responsible AI workflows.

Instead of using isolated tools for explanations, fairness checks, and robustness analysis, the SDK unifies them under a layered architecture.

It provides:

* Explainability algorithms (SHAP, LIME, counterfactuals etc.)
* Responsible AI diagnostics (bias, drift, robustness)
* Pluggable model adapters for multiple modalities
* Routing/orchestration across components
* Visualization and reporting support

Supported modalities:

* Tabular models
* NLP 
* Vision Models
* LLMs
* Text-to-Image (TTI) models

---

# Why XAI/RAI Instead of Using Individual Libraries?

Libraries like SHAP or LIME solve explanation problems individually.

`This project` aims to provide:

* A unified SDK abstraction
* Explainability + Responsible AI in one system
* Multi-modal support via adapters
* Routing logic across models and modalities
* Extensible architecture for research and deployment
* LLM Explanations for ease of understanding

xai_rai combines explainability, responsible AI diagnostics, multi-modal orchestration, and unified result abstractions within a single extensible SDK.---

# Architecture

xai_rai follows a layered, result-centric architecture:

```text
Facade
↓
Pipeline
↓
Analyzers / Explainers
↓
Inference Engines / Adapters
↓
Unified Result Objects
↓
Charts / Reports / UI
---
```

# Core Features

## Explainability

* SHAP feature attribution
* LIME local explanations
* Counterfactual explanations
* Natural language narratives
* Multi-modal explanation pipelines

---

## Responsible AI

* Fairness diagnostics
* Population Stability Index (PSI) drift detection
* Robustness checks
* Confidence/anomaly scoring

---

# Usage
## Installation

### Base

```bash
pip install xai-rai
```
Text-to-Image
```bash
pip install xai-rai[tti]
```
Vision
```bash
pip install xai-rai[vision]
```
Full Installation
```bash
pip install xai-rai[full]
```

# Example Usage

## Quickstart — Text-to-Image XAI

````md id="jlwm8k" ```

```python
from PIL import Image

from xai_rai import TextToImageExplainer

explainer = TextToImageExplainer(
    device="cpu",
    enable_caption_analysis=True,
)

image = Image.open("generated.png")

result = explainer.explain(
    image=image,
    prompt="a futuristic cyberpunk city",
)

print(result.summary())
```

# Design Philosophy

The framework follows:

## Modular Architecture

Each concern lives in its own layer.

---

## Adapter Pattern

Models are accessed through standardized interfaces.

---

## Separation of Concerns

Explainability and Responsible AI diagnostics are distinct modules.

---

## Extensibility

New:

* modalities
* explainers
* diagnostics
* visualization layers

can be added without changing the whole system.

---

# Roadmap

## Current

- Tabular explainability
- NLP explainability
- Vision explainability
- LLM explainability
- Text-to-image explainability
- SHAP / LIME integration
- Counterfactual explanations
- Multi-modal result objects
- RAI diagnostics
- Trust / alignment analysis

---

# Example Use Cases

`xai_rai` can support:

* Explainable healthcare models
* Explainable and Responsible AI for Businesses
* Responsible AI and toxicity screens
---
# Public APIs

```python
from xai_rai import (
    TabularExplainer,
    VisionExplainer,
    NLPExplainer,
    LLMExplainer,
    TextToImageExplainer,
)
```
# Contribution

This project is currently in Beta and is being actively improved and worked on. If you wish to contribute, please follow the following guidelines:
Keep modules modular and loosely coupled
Follow the layered architecture
Add type hints where possible
Prefer result-centric APIs over raw dictionaries
Include lightweight tests for new features
Keep public APIs clean and stable

For major architectural changes or new modality integrations, open an issue/discussion first before implementing large changes.
