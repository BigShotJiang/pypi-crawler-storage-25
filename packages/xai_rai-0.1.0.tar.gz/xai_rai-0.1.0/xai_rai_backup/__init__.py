# from xai_rai.client import XAIClient
# from xai_rai.core.results import XAIResult, BatchXAIResult

# __all__ = ["XAIClient", "XAIResult", "BatchXAIResult"]

"""
xai_rai package

Lightweight package init.

Avoid importing heavy modules (shap, explainers, clients)
here to prevent import side effects.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]