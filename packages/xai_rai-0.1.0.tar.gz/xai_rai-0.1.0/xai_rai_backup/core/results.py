from dataclasses import dataclass, field
from typing import Optional, Any, Union
from numpy.typing import NDArray
import numpy as np
from datetime import datetime
from xai_rai.core.config import FeatureMapping

@dataclass
class XAIResult:
    prediction: Union[float, int, NDArray]
    confidence: Optional[float] = None
    feature_importance: dict[str, float] = field(default_factory=dict)
    top_factors: list[tuple[str, float]] = field(default_factory=list)
    shap_values: Optional[NDArray] = None
    lime_explanation: Optional[dict] = None
    raw_instance: Optional[NDArray] = None
    feature_values: dict[str, float] = field(default_factory=dict)
    narrative: Optional[str] = None
    prediction_label: Optional[str] = None
    counterfactuals: Optional[list[dict]] = None       # NEW: DiCE results

    def top_positive_factors(self, n: int = 5) -> list[tuple[str, float]]:
        return [(f, v) for f, v in self.top_factors if v > 0][:n]

    def top_negative_factors(self, n: int = 5) -> list[tuple[str, float]]:
        return [(f, v) for f, v in self.top_factors if v < 0][:n]

    def to_dict(self) -> dict[str, Any]:
        return {
            "prediction": self._serialize_prediction(self.prediction),
            "confidence": self.confidence,
            "prediction_label": self.prediction_label,
            "feature_importance": self.feature_importance,
            "top_factors": [(f, float(v)) for f, v in self.top_factors],
            "top_positive": [(f, float(v)) for f, v in self.top_positive_factors()],
            "top_negative": [(f, float(v)) for f, v in self.top_negative_factors()],
            "narrative": self.narrative,
            "feature_values": self.feature_values,
            "counterfactuals": self.counterfactuals,
        }

    def _serialize_prediction(self, pred: Any) -> Any:
        if np.isscalar(pred):
            return float(pred) if isinstance(pred, (np.floating, float)) else int(pred) if isinstance(pred, (np.integer, int)) else pred
        if hasattr(pred, "tolist"):
            return pred.tolist()
        return pred

    def to_ui_json(
        self,
        feature_mapping: Optional[FeatureMapping] = None,
        include_visual_data: bool = True,
    ) -> dict[str, Any]:
        fm = feature_mapping or FeatureMapping()

        top_factors_ui = []
        for feature, value in self.top_factors:
            label = fm.get_label(feature)
            feature_val = self.feature_values.get(feature, 0)
            top_factors_ui.append({
                "feature": feature,
                "label": label,
                "impact": float(value),
                "direction": "positive" if value > 0 else "negative",
                "value": float(feature_val),
                "description": fm.get_description(feature),
            })

        narrative = self.narrative or self._generate_simple_narrative(fm)

        result = {
            "meta": {
                "generated_at": datetime.utcnow().isoformat() + "Z",
                "model_type": "model-agnostic",
                "explanation_method": "SHAP+LIME",
            },
            "prediction": {
                "value": self._serialize_prediction(self.prediction),
                "label": self.prediction_label,
                "confidence": round(self.confidence, 4) if self.confidence else None,
            },
            "explanation": {
                "summary": narrative,
                "top_drivers": top_factors_ui[:5],
                "positive_factors": [
                    {"label": fm.get_label(f), "impact": float(v)}
                    for f, v in self.top_positive_factors(3)
                ],
                "negative_factors": [
                    {"label": fm.get_label(f), "impact": float(v)}
                    for f, v in self.top_negative_factors(3)
                ],
            },
            "feature_details": {
                "importance": {fm.get_label(f): float(v) for f, v in self.feature_importance.items()},
                "values": {fm.get_label(f): float(v) for f, v in self.feature_values.items()},
            },
        }

        # NEW: include counterfactuals if available
        if self.counterfactuals:
            result["counterfactuals"] = self.counterfactuals

        if include_visual_data:
            result["visualizations"] = self._build_visual_data(fm)

        return result

    def _generate_simple_narrative(self, fm: FeatureMapping) -> str:
        if not self.top_factors:
            return "No significant factors identified."

        top_positive = [(f, v) for f, v in self.top_factors if v > 0][:2]
        top_negative = [(f, v) for f, v in self.top_factors if v < 0][:2]
        parts = []

        if self.prediction_label:
            parts.append(f"Prediction: {self.prediction_label}")

        if top_positive:
            pos_parts = [fm.get_label(f) for f, _ in top_positive]
            parts.append(f"increased by {', '.join(pos_parts)}")

        if top_negative:
            neg_parts = [fm.get_label(f) for f, _ in top_negative]
            parts.append(f"decreased by {', '.join(neg_parts)}")

        if self.confidence:
            parts.append(f"({self.confidence:.0%} confidence)")

        return " | ".join(parts) if parts else "Prediction generated."

    def _build_visual_data(self, fm: FeatureMapping) -> dict[str, Any]:
        labels = [fm.get_label(f) for f, _ in self.top_factors]
        impacts = [float(v) for _, v in self.top_factors]
        colors = ["#22c55e" if v > 0 else "#ef4444" for v in impacts]

        return {
            "top_factors_bar": {
                "type": "bar",
                "labels": labels,
                "values": impacts,
                "colors": colors,
                "title": "Top Factors Impacting Prediction",
                "x_label": "Impact Score",
                "y_label": "Feature",
            },
            "importance_distribution": {
                "type": "bar",
                "labels": labels[:10],
                "values": [abs(v) for v in impacts[:10]],
                "title": "Feature Importance Magnitude",
            },
        }


@dataclass
class BatchXAIResult:
    results: list[XAIResult] = field(default_factory=list)
    aggregate_summary: Optional[dict] = None

    def to_ui_json(
        self,
        feature_mapping: Optional[FeatureMapping] = None,
        include_aggregates: bool = True,
    ) -> dict[str, Any]:
        fm = feature_mapping or FeatureMapping()

        individual_results = [
            r.to_ui_json(feature_mapping=fm, include_visual_data=False)
            for r in self.results
        ]

        output = {
            "meta": {
                "generated_at": datetime.utcnow().isoformat() + "Z",
                "batch_size": len(self.results),
                "model_type": "model-agnostic",
            },
            "results": individual_results,
        }

        if include_aggregates and self.aggregate_summary:
            output["aggregate_summary"] = {
                "feature_ranking": [
                    fm.get_label(f) for f in self.aggregate_summary.get("ranking", [])
                ],
                "mean_importance": {
                    fm.get_label(k): v
                    for k, v in self.aggregate_summary.get("mean_importance", {}).items()
                },
            }

        return output


