from dataclasses import dataclass, field
from typing import Optional

@dataclass
class XAIConfig:
    n_samples: int = 5000
    n_top_features: int = 10
    shap_kernel_samples: int = 1000
    lime_samples: int = 1000
    parallel: bool = False          # Disabled — KernelExplainer not thread-safe
    max_workers: int = 4
    seed: int = 42
    use_llm: bool = False
    llm_model: str = "arcee-ai/trinity-large-preview:free"
    llm_api_key: Optional[str] = None
    language: str = "en"
    cache_explanations: bool = True


@dataclass
class FeatureMapping:
    labels: dict[str, str] = field(default_factory=dict)
    descriptions: dict[str, str] = field(default_factory=dict)
    thresholds: dict[str, dict[str, float]] = field(default_factory=dict)

    def get_label(self, feature: str) -> str:
        return self.labels.get(feature, feature.replace("_", " ").title())

    def get_description(self, feature: str) -> str:
        return self.descriptions.get(feature, "")

    def get_threshold(self, feature: str, threshold_type: str) -> Optional[float]:
        return self.thresholds.get(feature, {}).get(threshold_type)
