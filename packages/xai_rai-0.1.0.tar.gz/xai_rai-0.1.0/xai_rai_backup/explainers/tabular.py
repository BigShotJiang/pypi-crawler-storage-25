import numpy as np
from typing import Callable, Optional, Any, Union
from numpy.typing import NDArray
from xai_rai.core.config import XAIConfig, FeatureMapping
from xai_rai.core.results import XAIResult, BatchXAIResult
from xai_rai.core.router import ExplainerRouter
from xai_rai.utils.cache import ExplanationCache
from xai_rai.adapters.llm import NarrativeGenerator
from xai_rai.explainers.counterfactuals import CounterfactualGenerator
from xai_rai.utils.helpers import (
    normalize_feature_name,
    normalize_lime_explanation,
    normalize_importance_values,
)

# FIX 4: Lazy optional import — LIME is only imported when actually needed.
# If lime is not installed, the module still loads fine as long as use_lime=False.
try:
    import lime
    import lime.lime_tabular
    _LIME_AVAILABLE = True
except ImportError:
    _LIME_AVAILABLE = False


class ModelAgnosticExplainer:
    def __init__(
        self,
        predict_fn: Callable[[NDArray], NDArray],
        background_data: NDArray,
        feature_names: Optional[list[str]] = None,
        feature_mapping: Optional[FeatureMapping] = None,
        class_names: Optional[list[str]] = None,
        task_type: str = "classification",
        config: Optional[XAIConfig] = None,
        model: Any = None,
    ):
        self.predict_fn = predict_fn
        self.background_data = np.asarray(background_data)
        self.feature_mapping = feature_mapping or FeatureMapping()
        self.task_type = task_type.lower()
        self.config = config or XAIConfig()
        self.model = model

        self.n_features = self.background_data.shape[1]

        if feature_names is None:
            self.feature_names = [f"feature_{i}" for i in range(self.n_features)]
        else:
            if len(feature_names) != self.n_features:
                raise ValueError(
                    f"feature_names length ({len(feature_names)}) must match "
                    f"n_features ({self.n_features})"
                )
            self.feature_names = feature_names

        self.class_names = class_names
        if self.task_type == "classification" and self.class_names is None:
            n_classes = self._infer_n_classes()
            self.class_names = [f"class_{i}" for i in range(n_classes)]

        self._shap_explainer = None
        self._shap_type = None
        self._lime_explainer = None
        self._narrative_generator = None
        self._cache = ExplanationCache() if self.config.cache_explanations else None
        self._cf_generator = None

        self._init_explainers()
        self._init_narrative_generator()

    def _infer_n_classes(self) -> int:
        sample = self.background_data[:1]
        pred = self.predict_fn(sample)
        if pred.ndim == 1:
            return 2
        return pred.shape[1]

    def _init_explainers(self) -> None:
        np.random.seed(self.config.seed)

        self._shap_explainer, self._shap_type = ExplainerRouter.get_explainer(
            model=self.model,
            predict_fn=self.predict_fn,
            background_data=self.background_data,
            config=self.config,
        )

        # FIX 4: Only initialize LIME explainer if lime is available and enabled in config.
        # Deferred to first call if use_lime is not set in config (handled in _compute_lime).
        if getattr(self.config, "use_lime", True):
            self._init_lime_explainer()

    def _init_lime_explainer(self) -> None:
        """Initialize LIME explainer. Raises clearly if lime is not installed."""
        if not _LIME_AVAILABLE:
            raise ImportError(
                "lime is required for LIME explanations. "
                "Install it with: pip install lime"
            )
        self._lime_explainer = lime.lime_tabular.LimeTabularExplainer(
            training_data=self.background_data,
            feature_names=self.feature_names,
            class_names=self.class_names,
            mode=self.task_type,
            random_state=self.config.seed,
        )

    def _init_narrative_generator(self) -> None:
        self._narrative_generator = NarrativeGenerator(
            feature_mapping=self.feature_mapping,
            use_llm=self.config.use_llm,
            api_key=self.config.llm_api_key,
            model=self.config.llm_model,
            language=self.config.language,
        )

    def init_counterfactuals(self) -> None:
        """
        Explicitly initialize DiCE counterfactual generator.
        Call this after construction if counterfactuals are needed.
        Kept separate since DiCE init is slow.
        """
        self._cf_generator = CounterfactualGenerator(
            model=self.model,
            predict_fn=self.predict_fn,
            background_data=self.background_data,
            feature_names=self.feature_names,
            task_type=self.task_type,
        )

    def explain_instance(
        self,
        instance: NDArray,
        n_top_factors: Optional[int] = None,
        use_shap: bool = True,
        use_lime: bool = True,
        generate_narrative: bool = True,
        generate_counterfactuals: bool = False,
        context: Optional[dict] = None,
    ) -> XAIResult:
        instance = np.asarray(instance)
        if instance.ndim == 2:
            instance = instance[0]
        elif instance.ndim != 1:
            raise ValueError(f"Invalid instance shape: {instance.shape}")

        if instance.shape[0] != self.n_features:
            raise ValueError(
                f"Instance has {instance.shape[0]} features, expected {self.n_features}"
            )
        if np.any(np.isnan(instance)):
            raise ValueError("Instance contains NaN values")
        if np.any(np.isinf(instance)):
            raise ValueError("Instance contains infinite values")

        # FIX 3: Use a stable bytes-based cache key instead of the raw array object.
        # array.tobytes() produces a deterministic hash key regardless of object identity.
        cache_key = instance.tobytes()
                
        if self._cache is not None:
            cached = self._cache.get(instance)
            if cached is not None:
                return cached

        n_top = n_top_factors or self.config.n_top_features

        prediction = self.predict_fn(instance.reshape(1, -1))[0]
        confidence = self._compute_confidence(prediction)
        prediction_label = self._get_prediction_label(prediction)

        # FIX 1+2: Derive the predicted class index once and pass it into _compute_shap
        # so SHAP output is always aligned to the actual predicted class, not hard-coded to 1.
        predicted_class_idx = self._get_predicted_class_idx(prediction)

        shap_result = self._compute_shap(instance, predicted_class_idx) if use_shap else None

        # FIX 4: Lazily initialize LIME on first use if it wasn't initialized at startup.
        if use_lime and self._lime_explainer is None:
            self._init_lime_explainer()
        lime_result = self._compute_lime(instance) if use_lime else None

        feature_importance = self._merge_importances(shap_result, lime_result)
        top_factors = sorted(
            feature_importance.items(),
            key=lambda x: abs(x[1]),
            reverse=True,
        )[:n_top]

        feature_values = {
            self.feature_names[i]: float(instance[i])
            for i in range(len(instance))
        }

        counterfactuals = None
        if generate_counterfactuals:
            if self._cf_generator is None:
                self.init_counterfactuals()
            counterfactuals = self._cf_generator.generate(instance)

        result = XAIResult(
            prediction=prediction,
            confidence=confidence,
            feature_importance=feature_importance,
            top_factors=top_factors,
            shap_values=shap_result["values"] if shap_result else None,
            lime_explanation=lime_result,
            raw_instance=instance,
            feature_values=feature_values,
            prediction_label=prediction_label,
            counterfactuals=counterfactuals,
        )

        if generate_narrative:
            result.narrative = self._narrative_generator.generate(result, context)

        if self._cache is not None:
            self._cache.set(instance, result)

        return result

    def explain_batch(
        self,
        instances: NDArray,
        n_top_factors: Optional[int] = None,
        use_shap: bool = True,
        use_lime: bool = True,
        generate_narrative: bool = True,
        compute_aggregates: bool = True,
    ) -> BatchXAIResult:
        instances = np.asarray(instances)
        n_top = n_top_factors or self.config.n_top_features

        results = []
        for instance in instances:
            result = self.explain_instance(
                instance,
                n_top_factors=n_top,
                use_shap=use_shap,
                use_lime=use_lime,
                generate_narrative=generate_narrative,
            )
            results.append(result)

        aggregate_summary = self._compute_aggregates(results) if compute_aggregates else None
        return BatchXAIResult(results=results, aggregate_summary=aggregate_summary)

    def _compute_aggregates(self, results: list[XAIResult]) -> dict[str, Any]:
        all_importance = np.zeros((len(results), self.n_features))

        for i, result in enumerate(results):
            shap_used = False
            if result.shap_values is not None:
                shap = np.asarray(result.shap_values)
                # At this point shap_values stored in XAIResult are already normalized
                # to (n_features,) by _compute_shap. Guard anyway for safety.
                if shap.ndim == 1 and shap.shape[0] == self.n_features:
                    all_importance[i] = np.abs(shap)
                    shap_used = True
                elif shap.ndim == 2 and shap.shape[1] == self.n_features:
                    # (n_samples, n_features) — take first row
                    all_importance[i] = np.abs(shap[0])
                    shap_used = True
                elif shap.ndim == 2 and shap.shape[0] == self.n_features:
                    # (n_features, n_classes) — max abs across classes
                    all_importance[i] = np.max(np.abs(shap), axis=1)
                    shap_used = True
                # Any other shape (e.g. (2,) stale binary probs): fall through

            if not shap_used:
                # Reliable fallback: feature_importance is always keyed by name
                for j, name in enumerate(self.feature_names):
                    if name in result.feature_importance:
                        all_importance[i, j] = abs(result.feature_importance[name])

        mean_importance = np.mean(all_importance, axis=0)
        std_importance = np.std(all_importance, axis=0)
        feature_ranking = np.argsort(mean_importance)[::-1]

        return {
            "mean_importance": {
                self.feature_names[i]: float(mean_importance[i])
                for i in range(self.n_features)
            },
            "std_importance": {
                self.feature_names[i]: float(std_importance[i])
                for i in range(self.n_features)
            },
            "ranking": [self.feature_names[i] for i in feature_ranking],
        }

    def _get_predicted_class_idx(self, prediction: Union[float, int, NDArray]) -> int:
        """
        Derive the predicted class index from a raw prediction.
        Used to select the correct SHAP slice for the actual predicted class.
        """
        pred_array = np.asarray(prediction)
        if pred_array.ndim == 0:
            # Scalar sigmoid output — threshold at 0.5
            return 1 if pred_array.item() > 0.5 else 0
        return int(np.argmax(pred_array))

    def _compute_shap(self, instance: NDArray, predicted_class_idx: int) -> dict:
        """
        Compute SHAP values and normalize to a 1D array of shape (n_features,)
        aligned to the predicted class.

        FIX 1: Uses predicted_class_idx instead of hard-coded index 1.
        FIX 2: Single linear normalization path — no duplicate isinstance/ndim guards.
        """
        instance_2d = instance.reshape(1, -1)

        if self._shap_type in ("tree", "linear"):
            shap_values = self._shap_explainer.shap_values(instance_2d)
        else:
            # KernelExplainer
            shap_values = self._shap_explainer.shap_values(
                instance_2d,
                nsamples=self.config.shap_kernel_samples,
            )

        # --- Single canonical normalization path ---
        # Step 1: Unwrap list output (one array per class from tree/kernel explainers).
        if isinstance(shap_values, list):
            # Select the slice for the predicted class; fall back to last if out of range.
            idx = min(predicted_class_idx, len(shap_values) - 1)
            shap_values = np.asarray(shap_values[idx])
        else:
            shap_values = np.asarray(shap_values)

        # Step 2: Squeeze leading sample dimension if present — (1, n_features) → (n_features,)
        if shap_values.ndim == 2 and shap_values.shape[0] == 1:
            shap_values = shap_values[0]

        # Step 3: Handle (1, n_features, n_classes) or (n_features, n_classes) tensor output.
        if shap_values.ndim == 3 and shap_values.shape[0] == 1:
            # (1, n_features, n_classes) → (n_features, n_classes)
            shap_values = shap_values[0]
        if shap_values.ndim == 2:
            # (n_features, n_classes) — select predicted class column
            col = min(predicted_class_idx, shap_values.shape[1] - 1)
            shap_values = shap_values[:, col]

        # Invariant: shap_values is now 1D with shape (n_features,)
        if shap_values.shape[0] != self.n_features:
            raise ValueError(
                f"SHAP normalization produced shape {shap_values.shape}, "
                f"expected ({self.n_features},). Check explainer output format."
            )

        abs_shap = np.abs(shap_values)
        top_indices = np.argsort(abs_shap)[::-1][: self.config.n_top_features]

        return {
            "values": shap_values,      # guaranteed (n_features,)
            "abs_values": abs_shap,
            "top_indices": top_indices,
        }

    def _compute_lime(self, instance: NDArray) -> dict:
        exp = self._lime_explainer.explain_instance(
            data_row=instance,
            predict_fn=self.predict_fn,
            num_features=self.n_features,
            num_samples=self.config.lime_samples,
        )

        lime_importance = normalize_lime_explanation(exp, self.feature_names)

        return {
            "explanation": exp,
            "importance": lime_importance,
            "local_pred": exp.local_pred,
        }

    def _compute_confidence(self, prediction: Union[float, int, NDArray]) -> Optional[float]:
        if self.task_type == "classification":
            pred_array = np.asarray(prediction)
            if pred_array.ndim == 0:
                pred_array = np.array([1 - pred_array.item(), pred_array.item()])
            return float(np.max(pred_array))
        return None

    def _get_prediction_label(self, prediction: Union[float, int, NDArray]) -> Optional[str]:
        if self.task_type == "classification":
            class_idx = self._get_predicted_class_idx(prediction)
            if self.class_names:
                return self.class_names[class_idx]
            return f"class_{class_idx}"
        return None

    def _merge_importances(
        self,
        shap_result: Optional[dict],
        lime_result: Optional[dict],
    ) -> dict[str, float]:
        """
        Merge SHAP and LIME importance scores.
        Both normalized to [-1, 1] before merging.
        SHAP weighted 0.7, LIME 0.3 (SHAP is more theoretically grounded).
        """
        shap_norm = None
        lime_norm = None

        if shap_result:
            raw = {
                self.feature_names[i]: float(shap_result["values"][i])
                for i in range(len(shap_result["values"]))
                if i < len(self.feature_names)
            }
            shap_norm = normalize_importance_values(raw)

        if lime_result:
            lime_norm = lime_result["importance"]

        if shap_norm and lime_norm:
            merged = {}
            all_keys = set(shap_norm) | set(lime_norm)
            for k in all_keys:
                s = shap_norm.get(k, 0.0)
                l = lime_norm.get(k, 0.0)
                merged[k] = s * 0.7 + l * 0.3
            return merged

        if shap_norm:
            return shap_norm

        if lime_norm:
            return lime_norm

        return {}