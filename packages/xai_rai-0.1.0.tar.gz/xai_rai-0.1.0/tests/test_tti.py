def test_tti_construction():

    from xai_rai import TextToImageExplainer

    explainer = TextToImageExplainer(
        device="cpu",
        enable_caption_analysis=False,
    )

    assert explainer is not None

from PIL import Image


def test_tti_explain():

    from xai_rai import TextToImageExplainer

    image = Image.new("RGB", (128, 128), color="red")

    explainer = TextToImageExplainer(
        device="cpu",
        enable_caption_analysis=False,
    )

    result = explainer.explain(
        image=image,
        prompt="a red square",
    )

    assert result is not None
    assert result.prompt == "a red square"