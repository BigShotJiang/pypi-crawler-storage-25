"""
test_rai_validation.py

Tests for the framework validation layer:
  FairlearnValidator, EvidentlyValidator, RAIValidator.

Runs entirely on synthetic data — no API calls, no adapter required.
The MockAdapter and fixture data mirror those in test_responsible_ai.py
so comparisons are apples-to-apples.

Run:
    pytest test_rai_validation.py -v
"""

from __future__ import annotations

import time
from typing import List

import numpy as np
import pytest

from xai_rai.rai.nlp.fairness import FairnessAuditor
from xai_rai.rai.nlp.drift import DriftMonitor
from xai_rai.rai.nlp.reports import RAIReport
from xai_rai.rai.nlp.fairlearn_validator import FairlearnValidator
from xai_rai.rai.nlp.evidently_validator import EvidentlyValidator
from xai_rai.rai.nlp.rai_validator import RAIValidator, ValidationDivergenceError


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

# 30 samples: 15 positive, 15 negative, two groups
N = 30
RNG = np.random.default_rng(42)

TEXTS = [f"sentence number {i}" for i in range(N)]
GROUP_LABELS = ["group_a"] * 15 + ["group_b"] * 15
TRUE_LABELS  = [1] * 8 + [0] * 7 + [1] * 5 + [0] * 10   # slight imbalance

# Well-separated predictions — group_a skews positive, group_b skews negative
_a_probs = np.clip(RNG.normal(0.75, 0.1, 15), 0.01, 0.99)
_b_probs = np.clip(RNG.normal(0.25, 0.1, 15), 0.01, 0.99)
_all_probs = np.concatenate([_a_probs, _b_probs])
PREDICTIONS = np.column_stack([1 - _all_probs, _all_probs])   # (30, 2)

# Reference window: similar distribution to PREDICTIONS
_ref_probs = np.clip(
    np.concatenate([
        RNG.normal(0.75, 0.1, 15),
        RNG.normal(0.25, 0.1, 15),
    ]), 0.01, 0.99
)
REF_PREDICTIONS = np.column_stack([1 - _ref_probs, _ref_probs])

# Drifted distribution: both groups shift to ~0.5 (clear drift)
_drift_probs = np.clip(RNG.normal(0.50, 0.05, N), 0.01, 0.99)
DRIFTED_PREDICTIONS = np.column_stack([1 - _drift_probs, _drift_probs])

LABEL_NAMES = ["NEGATIVE", "POSITIVE"]


@pytest.fixture(scope="module")
def custom_fairness_report():
    auditor = FairnessAuditor(
        protected_attribute="group",
        dp_threshold=0.10,
        eo_threshold=0.10,
        min_group_size=3,
    )
    return auditor.audit(TEXTS, PREDICTIONS, GROUP_LABELS, TRUE_LABELS)


@pytest.fixture(scope="module")
def custom_drift_report():
    monitor = DriftMonitor(psi_threshold=0.25)
    monitor.update(TEXTS[:15], REF_PREDICTIONS[:15])
    monitor.update(TEXTS[15:], REF_PREDICTIONS[15:])
    return monitor.check(TEXTS, PREDICTIONS)


@pytest.fixture(scope="module")
def custom_drift_report_drifted():
    monitor = DriftMonitor(psi_threshold=0.10)   # tight threshold
    monitor.update(TEXTS, REF_PREDICTIONS)
    return monitor.check(TEXTS, DRIFTED_PREDICTIONS)


@pytest.fixture(scope="module")
def rai_report_with_fairness(custom_fairness_report):
    r = RAIReport(
        timestamp=time.time(),
        adapter_provider="mock",
        texts_count=N,
    )
    r.fairness = custom_fairness_report
    return r


@pytest.fixture(scope="module")
def rai_report_with_drift(custom_drift_report):
    r = RAIReport(
        timestamp=time.time(),
        adapter_provider="mock",
        texts_count=N,
    )
    r.drift = custom_drift_report
    return r


@pytest.fixture(scope="module")
def rai_report_full(custom_fairness_report, custom_drift_report):
    r = RAIReport(
        timestamp=time.time(),
        adapter_provider="mock",
        texts_count=N,
    )
    r.fairness = custom_fairness_report
    r.drift    = custom_drift_report
    return r


# ---------------------------------------------------------------------------
# FairlearnValidator
# ---------------------------------------------------------------------------

class TestFairlearnValidator:

    def test_returns_report(self, custom_fairness_report):
        v = FairlearnValidator()
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        assert report is not None
        assert isinstance(report.fairlearn_dp_diff, float)

    def test_dp_within_tolerance(self, custom_fairness_report):
        """Custom and Fairlearn DP diff should agree within 2 pp."""
        v = FairlearnValidator(dp_tolerance=0.02)
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        dp_cmp = next(c for c in report.comparisons if "demographic_parity" in c.metric_name)
        assert dp_cmp.within_tolerance, (
            f"DP diverged: custom={dp_cmp.custom_value:.4f} "
            f"fairlearn={dp_cmp.framework_value:.4f} Δ={dp_cmp.delta:.4f}"
        )

    def test_eo_computed_with_true_labels(self, custom_fairness_report):
        v = FairlearnValidator()
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        assert report.fairlearn_eo_diff is not None

    def test_eo_none_without_true_labels(self, custom_fairness_report):
        v = FairlearnValidator()
        report = v.validate(PREDICTIONS, GROUP_LABELS, None, custom_fairness_report)
        assert report.fairlearn_eo_diff is None

    def test_group_rates_present(self, custom_fairness_report):
        v = FairlearnValidator()
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        assert "group_a" in report.fairlearn_group_rates
        assert "group_b" in report.fairlearn_group_rates

    def test_tight_tolerance_flags_divergence(self, custom_fairness_report):
        """Setting tolerance=0.0 should always flag since floating-point differs."""
        v = FairlearnValidator(dp_tolerance=0.0)
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        # With zero tolerance, any nonzero delta flags — may or may not diverge
        # depending on exact arithmetic. Just check no crash.
        assert isinstance(report.any_divergence, bool)

    def test_serialisable(self, custom_fairness_report):
        import json
        v = FairlearnValidator()
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        json.dumps(report.to_dict())   # must not raise

    def test_framework_version_populated(self, custom_fairness_report):
        v = FairlearnValidator()
        report = v.validate(PREDICTIONS, GROUP_LABELS, TRUE_LABELS, custom_fairness_report)
        assert report.framework_version != "unknown"


# ---------------------------------------------------------------------------
# EvidentlyValidator
# ---------------------------------------------------------------------------

class TestEvidentlyValidator:

    def test_returns_report_no_drift(self, custom_drift_report):
        v = EvidentlyValidator()
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            custom_report=custom_drift_report,
            label_names=LABEL_NAMES,
        )
        assert report is not None
        assert isinstance(report.evidently_dataset_drift, bool)

    def test_returns_report_with_texts(self, custom_drift_report):
        v = EvidentlyValidator()
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            custom_report=custom_drift_report,
            reference_texts=TEXTS,
            current_texts=TEXTS,
            label_names=LABEL_NAMES,
        )
        assert report is not None

    def test_drift_share_in_range(self, custom_drift_report):
        v = EvidentlyValidator()
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            custom_report=custom_drift_report,
            label_names=LABEL_NAMES,
        )
        assert 0.0 <= report.evidently_drift_share <= 1.0

    def test_drifted_data_detected(self, custom_drift_report_drifted):
        """Clearly drifted distribution should be flagged by Evidently."""
        v = EvidentlyValidator(
            psi_tolerance=0.05,
            verdict_must_agree=False,   # just test Evidently, don't check agreement
        )
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=DRIFTED_PREDICTIONS,
            custom_report=custom_drift_report_drifted,
            label_names=LABEL_NAMES,
        )
        # Evidently should detect the shift from bimodal to centred distribution
        assert report.evidently_dataset_drift, "Evidently should flag clear distribution drift"

    def test_per_feature_populated(self, custom_drift_report):
        v = EvidentlyValidator()
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            custom_report=custom_drift_report,
            label_names=LABEL_NAMES,
        )
        assert len(report.evidently_per_feature) > 0

    def test_serialisable(self, custom_drift_report):
        import json
        v = EvidentlyValidator()
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            custom_report=custom_drift_report,
            label_names=LABEL_NAMES,
        )
        json.dumps(report.to_dict())   # must not raise

    def test_framework_version_populated(self, custom_drift_report):
        v = EvidentlyValidator()
        report = v.validate(
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            custom_report=custom_drift_report,
            label_names=LABEL_NAMES,
        )
        assert report.framework_version != "unknown"


# ---------------------------------------------------------------------------
# RAIValidator orchestrator
# ---------------------------------------------------------------------------

class TestRAIValidator:

    def test_full_run(self, rai_report_full):
        v = RAIValidator()
        val = v.validate(
            custom_report=rai_report_full,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            reference_texts=TEXTS,
            current_texts=TEXTS,
            label_names=LABEL_NAMES,
        )
        assert val.fairness is not None
        assert val.drift is not None
        assert isinstance(val.any_divergence, bool)
        assert len(val.summary) > 0

    def test_skips_fairness_without_group_labels(self, rai_report_with_fairness):
        v = RAIValidator()
        val = v.validate(
            custom_report=rai_report_with_fairness,
            predictions=PREDICTIONS,
            group_labels=None,    # no group labels → skip
        )
        assert val.fairness is None

    def test_skips_drift_without_drift_report(self, rai_report_with_fairness):
        v = RAIValidator()
        val = v.validate(
            custom_report=rai_report_with_fairness,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
        )
        # No drift report in custom_report → drift validation skipped
        assert val.drift is None

    def test_skip_fairness_flag(self, rai_report_full):
        v = RAIValidator(skip_fairness=True)
        val = v.validate(
            custom_report=rai_report_full,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
        )
        assert val.fairness is None

    def test_skip_drift_flag(self, rai_report_full):
        v = RAIValidator(skip_drift=True)
        val = v.validate(
            custom_report=rai_report_full,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
        )
        assert val.drift is None

    def test_raise_on_divergence(self, rai_report_with_fairness):
        """Force divergence by setting tolerance=0.0, then confirm raise."""
        v = RAIValidator(dp_tolerance=0.0, raise_on_divergence=True)
        # With dp_tolerance=0.0, any nonzero delta raises — but only if
        # fairlearn DP ≠ custom DP exactly. May or may not diverge.
        # We just verify it raises ValidationDivergenceError when it does.
        try:
            v.validate(
                custom_report=rai_report_with_fairness,
                predictions=PREDICTIONS,
                group_labels=GROUP_LABELS,
                true_labels=TRUE_LABELS,
            )
        except ValidationDivergenceError as e:
            assert "divergence" in str(e).lower()

    def test_no_raise_when_agree(self, rai_report_full):
        """With generous tolerances and verdict check off, should not raise."""
        v = RAIValidator(
            dp_tolerance=0.20,
            eo_tolerance=0.20,
            psi_tolerance=0.50,
            verdict_must_agree=False,   # only check metric deltas, not binary verdict
            raise_on_divergence=True,
        )
        # Should not raise
        val = v.validate(
            custom_report=rai_report_full,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            label_names=LABEL_NAMES,
        )
        assert not val.any_divergence

    def test_summary_contains_framework_names(self, rai_report_full):
        v = RAIValidator()
        val = v.validate(
            custom_report=rai_report_full,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            label_names=LABEL_NAMES,
        )
        assert "Fairlearn" in val.summary
        assert "Evidently" in val.summary

    def test_serialisable(self, rai_report_full):
        import json
        v = RAIValidator()
        val = v.validate(
            custom_report=rai_report_full,
            predictions=PREDICTIONS,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
            reference_predictions=REF_PREDICTIONS,
            current_predictions=PREDICTIONS,
            label_names=LABEL_NAMES,
        )
        json.dumps(val.to_dict())   # must not raise


# ---------------------------------------------------------------------------
# Side-by-side comparison print (runs as a standalone script)
# ---------------------------------------------------------------------------

def print_comparison(rai_report_full):
    """Print a human-readable side-by-side comparison table."""
    v = RAIValidator(dp_tolerance=0.02, eo_tolerance=0.02, psi_tolerance=0.05)
    val = v.validate(
        custom_report=rai_report_full,
        predictions=PREDICTIONS,
        group_labels=GROUP_LABELS,
        true_labels=TRUE_LABELS,
        reference_predictions=REF_PREDICTIONS,
        current_predictions=PREDICTIONS,
        reference_texts=TEXTS,
        current_texts=TEXTS,
        label_names=LABEL_NAMES,
    )

    width = 70
    print(f"\n{'═' * width}")
    print("  RAI Validation — Custom Code vs Frameworks")
    print(f"{'═' * width}")
    print(f"\n  Overall: {val.summary}\n")

    if val.fairness:
        print(f"  {'─' * 30} FAIRNESS {'─' * 30}")
        print(f"  {'Metric':<35} {'Custom':>10} {'Fairlearn':>10} {'Δ':>8} {'OK?':>6}")
        print(f"  {'-' * 68}")
        for c in val.fairness.comparisons:
            ok = "✓" if c.within_tolerance else "⚠"
            print(
                f"  {c.metric_name:<35} {c.custom_value:>10.4f} "
                f"{c.framework_value:>10.4f} {c.delta:>8.4f} {ok:>6}"
            )
        print(f"\n  Fairlearn group selection rates:")
        for g, r in val.fairness.fairlearn_group_rates.items():
            print(f"    {g}: {r:.4f}")

    if val.drift:
        print(f"\n  {'─' * 30} DRIFT {'─' * 34}")
        print(f"  {'Metric':<35} {'Custom':>10} {'Evidently':>10} {'Δ':>8} {'OK?':>6}")
        print(f"  {'-' * 68}")
        for c in val.drift.comparisons:
            ok = "✓" if c.within_tolerance else "⚠"
            print(
                f"  {c.metric_name:<35} {c.custom_value:>10.4f} "
                f"{c.framework_value:>10.4f} {c.delta:>8.4f} {ok:>6}"
            )
        print(f"\n  Evidently verdict: {'DRIFT' if val.drift.evidently_dataset_drift else 'NO DRIFT'}")
        print(f"  Evidently drift share: {val.drift.evidently_drift_share:.2%}")
        if val.drift.evidently_psi is not None:
            print(f"  Evidently PSI: {val.drift.evidently_psi:.4f}")

    print(f"\n{'═' * width}\n")


if __name__ == "__main__":
    # Run standalone comparison print without pytest
    import time
    from responsible_ai.reports import RAIReport

    auditor = __import__("responsible_ai.fairness", fromlist=["FairnessAuditor"]).FairnessAuditor(min_group_size=3)
    custom_fair = auditor.audit(TEXTS, PREDICTIONS, GROUP_LABELS, TRUE_LABELS)

    monitor = __import__("responsible_ai.drift", fromlist=["DriftMonitor"]).DriftMonitor()
    monitor.update(TEXTS, REF_PREDICTIONS)
    custom_drift = monitor.check(TEXTS, PREDICTIONS)

    r = RAIReport(timestamp=time.time(), adapter_provider="mock", texts_count=N)
    r.fairness = custom_fair
    r.drift = custom_drift

    print_comparison(r)