def test_public_imports():

    from xai_rai import (
        TabularExplainer,
        VisionExplainer,
        NLPExplainer,
        LLMExplainer,
        TextToImageExplainer,
    )

    assert TabularExplainer is not None
    assert VisionExplainer is not None
    assert NLPExplainer is not None
    assert LLMExplainer is not None
    assert TextToImageExplainer is not None