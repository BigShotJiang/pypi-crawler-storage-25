import os
import numpy as np
import pytest
from unittest.mock import patch, Mock

from xai_rai.adapters.text_adapter import (
    BaseTextAdapter,
    LocalTextAdapter,
    HFTextAdapter,
    MAX_TOKENS
)

# ----------------------------
# Mock local classifier
# ----------------------------

def mock_classifier(text):

    text = text.lower()

    if "good" in text or "love" in text:
        return [
            {"label":"POSITIVE","score":0.9},
            {"label":"NEGATIVE","score":0.1}
        ]

    if "bad" in text or "hate" in text:
        return [
            {"label":"POSITIVE","score":0.1},
            {"label":"NEGATIVE","score":0.9}
        ]

    return [
        {"label":"POSITIVE","score":0.5},
        {"label":"NEGATIVE","score":0.5}
    ]


@pytest.fixture
def adapter():
    return LocalTextAdapter(fn=mock_classifier)


# --------------------------------
# 1. normalize tests
# --------------------------------

def test_normalize_empty(adapter):
    assert adapter.normalize("") == ""


def test_long_text_truncates(adapter):
    text = "word " * 1000
    out = adapter.normalize(text)
    assert len(out.split()) <= MAX_TOKENS


# --------------------------------
# 2. predict_proba contract
# --------------------------------

def test_predict_proba(adapter):

    probs = adapter.predict_proba("good movie")

    assert isinstance(probs, np.ndarray)
    assert probs.shape == (2,)
    np.testing.assert_allclose(
        probs.sum(),
        1.0,
        atol=1e-5
    )


# --------------------------------
# 3. predict output structure
# --------------------------------

def test_predict(adapter):

    pred = adapter.predict("good movie")

    assert "label" in pred
    assert "score" in pred
    assert "probs" in pred

    assert isinstance(pred["label"], str)
    assert isinstance(pred["score"], float)


# --------------------------------
# 4. logits finite + round trip
# --------------------------------

def test_predict_logits(adapter):

    probs = adapter.predict_proba("good movie")
    logits = adapter.predict_logits("good movie")

    assert np.isfinite(logits).all()

    recovered = 1/(1+np.exp(-logits))

    np.testing.assert_allclose(
        recovered,
        probs,
        atol=1e-5
    )


# --------------------------------
# 5. SHAP/LIME expected batch API
# --------------------------------

def test_batch_predict_contract(adapter):

    def batch_predict_proba(texts):
        return np.array(
            [adapter.predict_proba(t) for t in texts]
        )

    out = batch_predict_proba(
        ["good", "bad", "okay"]
    )

    assert out.shape == (3,2)
    assert out.dtype == float

    np.testing.assert_allclose(
        out.sum(axis=1),
        1.0,
        atol=1e-5
    )


# --------------------------------
# 6. Clipping protects 0/1 probs
# --------------------------------

def hard_classifier(text):
    return [
        {"label":"A","score":1.0},
        {"label":"B","score":0.0}
    ]


def test_logit_clipping():
    a = LocalTextAdapter(fn=hard_classifier)
    logits = a.predict_logits("anything")

    assert np.isfinite(logits).all()


# --------------------------------
# 7. Factory test
# --------------------------------

def test_factory():
    a = BaseTextAdapter.from_provider(
        "local",
        fn=mock_classifier
    )
    assert isinstance(a, LocalTextAdapter)


# --------------------------------
# 8. Mocked HF _query unit test
# --------------------------------

@patch("requests.post")
def test_hf_query_mock(mock_post):

    fake_response = Mock()

    fake_response.json.return_value = [[
        {"label":"POSITIVE","score":0.8},
        {"label":"NEGATIVE","score":0.2}
    ]]

    fake_response.raise_for_status.return_value = None

    mock_post.return_value = fake_response

    adapter = HFTextAdapter(
        hf_token="fake"
    )

    out = adapter.predict_proba("good")

    assert out.shape == (2,)
    np.testing.assert_allclose(
        out.sum(),
        1.0
    )


# --------------------------------
# 9 optional real integration test
# --------------------------------

@pytest.mark.skipif(
    not os.getenv("HF_TOKEN"),
    reason="No HF token"
)
def test_real_hf_integration():

    adapter = BaseTextAdapter.from_provider("hf")

    out = adapter.predict("I love this")

    assert "label" in out