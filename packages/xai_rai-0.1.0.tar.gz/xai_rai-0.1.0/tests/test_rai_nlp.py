"""
test_responsible_ai.py

End-to-end tests for the ResponsibleAILayer.

Runs against a synthetic MockAdapter so no real API key is required.
Also includes an integration smoke test skeleton for the HF DistilBERT adapter
(skipped unless HF_API_TOKEN is set in the environment).

Run:
    pytest test_responsible_ai.py -v
    pytest test_responsible_ai.py -v -k "not integration"
"""

from __future__ import annotations

import os
import random
import tempfile
import time
from typing import List

import numpy as np
import pytest

from xai_rai.rai.nlp import (
    AuditLogger,
    DriftMonitor,
    FairnessAuditor,
    RAIReport,
    ResponsibleAILayer,
    StabilityAuditor,
    ToxicityScanner,
    RegexScorer,
)
from xai_rai.rai.nlp.layer import RAIFlagError


# ---------------------------------------------------------------------------
# Mock adapter — no API required
# ---------------------------------------------------------------------------

class MockAdapter:
    """Deterministic mock that simulates predict_proba_batch."""

    provider = "mock"

    def __init__(self, n_classes: int = 2, noise: float = 0.0, seed: int = 42):
        self._n_classes = n_classes
        self._noise = noise
        self._rng = np.random.default_rng(seed)

    def predict_proba_batch(self, texts: List[str]) -> np.ndarray:
        n = len(texts)
        # Base: positive class probability ~ 0.7 for texts containing "good",
        # 0.2 for texts containing "bad", else 0.5
        probs = []
        for t in texts:
            t_lower = t.lower()
            if "good" in t_lower or "great" in t_lower:
                p = 0.80
            elif "bad" in t_lower or "terrible" in t_lower or "hate" in t_lower:
                p = 0.15
            else:
                p = 0.50
            noise = self._rng.uniform(-self._noise, self._noise)
            p = float(np.clip(p + noise, 0.01, 0.99))
            probs.append([1 - p, p])
        return np.array(probs)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

POSITIVE_TEXTS = [
    "This product is great and I love it.",
    "The service was excellent and very helpful.",
    "Good quality, would buy again.",
    "Amazing experience overall.",
    "Very good results, highly recommend.",
]

NEGATIVE_TEXTS = [
    "This is terrible and I hate it.",
    "Bad experience, would not recommend.",
    "Terrible quality, waste of money.",
    "Absolutely awful service.",
    "Very bad, never again.",
]

NEUTRAL_TEXTS = [
    "The item arrived on time.",
    "Packaging was okay.",
    "Standard delivery as expected.",
    "Nothing special to report.",
    "Works as described.",
]

ALL_TEXTS = POSITIVE_TEXTS + NEGATIVE_TEXTS + NEUTRAL_TEXTS
GROUP_LABELS = (
    ["group_a"] * 5 + ["group_b"] * 5 + ["group_c"] * 5
)
TRUE_LABELS = [1] * 5 + [0] * 5 + [1] * 5


@pytest.fixture
def adapter():
    return MockAdapter()


@pytest.fixture
def proba(adapter):
    return adapter.predict_proba_batch(ALL_TEXTS)


# ---------------------------------------------------------------------------
# FairnessAuditor tests
# ---------------------------------------------------------------------------

class TestFairnessAuditor:

    def test_basic_audit_returns_report(self, adapter, proba):
        auditor = FairnessAuditor(protected_attribute="group", min_group_size=2)
        report = auditor.audit(
            texts=ALL_TEXTS,
            predictions=proba,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
        )
        assert len(report.group_metrics) == 3
        assert 0.0 <= report.demographic_parity_diff <= 1.0
        assert 0.0 <= report.disparate_impact_ratio <= 1.0
        assert isinstance(report.threshold_violations, list)

    def test_equalized_odds_requires_true_labels(self, adapter, proba):
        auditor = FairnessAuditor(min_group_size=2)
        report_no_labels = auditor.audit(ALL_TEXTS, proba, GROUP_LABELS)
        assert report_no_labels.equalized_odds_diff is None

        report_with_labels = auditor.audit(ALL_TEXTS, proba, GROUP_LABELS, TRUE_LABELS)
        assert report_with_labels.equalized_odds_diff is not None

    def test_flags_on_tight_threshold(self, adapter, proba):
        # Force flag by setting threshold=0.0
        auditor = FairnessAuditor(dp_threshold=0.0, min_group_size=2)
        report = auditor.audit(ALL_TEXTS, proba, GROUP_LABELS)
        assert report.flagged
        assert len(report.threshold_violations) >= 1

    def test_small_groups_excluded(self, adapter):
        texts = ["text"] * 3
        preds = adapter.predict_proba_batch(texts)
        groups = ["tiny_a", "tiny_b", "tiny_c"]
        auditor = FairnessAuditor(min_group_size=5)
        report = auditor.audit(texts, preds, groups)
        assert report.group_metrics == []

    def test_to_dict_serialisable(self, adapter, proba):
        import json
        auditor = FairnessAuditor(min_group_size=2)
        report = auditor.audit(ALL_TEXTS, proba, GROUP_LABELS, TRUE_LABELS)
        d = report.to_dict()
        json.dumps(d)  # must not raise


# ---------------------------------------------------------------------------
# StabilityAuditor tests
# ---------------------------------------------------------------------------

class TestStabilityAuditor:

    def test_basic_audit_returns_report(self, adapter, proba):
        auditor = StabilityAuditor(
            strategies=["char_noise"],
            n_perturbations=2,
            max_workers=2,
        )
        report = auditor.audit(
            texts=ALL_TEXTS[:5],
            predict_fn=adapter.predict_proba_batch,
            original_predictions=proba[:5],
        )
        assert len(report.per_sample_results) == 5
        assert 0.0 <= report.consistency_score <= 1.0
        assert report.flip_rate + report.consistency_score == pytest.approx(1.0)

    def test_all_strategies(self, adapter, proba):
        auditor = StabilityAuditor(
            strategies=["synonym_swap", "char_noise", "shuffle"],
            n_perturbations=1,
        )
        report = auditor.audit(ALL_TEXTS[:3], adapter.predict_proba_batch, proba[:3])
        for sample in report.per_sample_results:
            strategy_names = {r.strategy for r in sample}
            assert strategy_names == {"synonym_swap", "char_noise", "shuffle"}

    def test_no_original_predictions(self, adapter):
        auditor = StabilityAuditor(strategies=["char_noise"], n_perturbations=1)
        report = auditor.audit(ALL_TEXTS[:3], adapter.predict_proba_batch)
        assert len(report.per_sample_results) == 3

    def test_flags_on_noisy_model(self):
        noisy_adapter = MockAdapter(noise=0.5, seed=0)
        auditor = StabilityAuditor(
            strategies=["synonym_swap"],
            n_perturbations=5,
            flip_threshold=0.0,  # always flag
        )
        report = auditor.audit(
            ALL_TEXTS[:5],
            noisy_adapter.predict_proba_batch,
        )
        assert report.flagged

    def test_invalid_strategy_raises(self):
        with pytest.raises(ValueError, match="Unknown"):
            StabilityAuditor(strategies=["nonexistent"])


# ---------------------------------------------------------------------------
# DriftMonitor tests
# ---------------------------------------------------------------------------

class TestDriftMonitor:

    def test_no_drift_same_distribution(self, adapter):
        monitor = DriftMonitor(psi_threshold=0.25)
        baseline = ALL_TEXTS * 4
        baseline_preds = adapter.predict_proba_batch(baseline)
        monitor.update(baseline, baseline_preds)

        current_preds = adapter.predict_proba_batch(ALL_TEXTS)
        report = monitor.check(ALL_TEXTS, current_preds)

        assert report.drift_level in ("none", "moderate")
        assert report.psi >= 0.0
        assert 0.0 <= report.js_divergence <= 1.0

    def test_drift_detected_on_shifted_distribution(self, adapter):
        monitor = DriftMonitor(psi_threshold=0.05)   # very tight threshold
        baseline = POSITIVE_TEXTS * 10
        baseline_preds = adapter.predict_proba_batch(baseline)
        monitor.update(baseline, baseline_preds)

        current_preds = adapter.predict_proba_batch(NEGATIVE_TEXTS * 2)
        report = monitor.check(NEGATIVE_TEXTS * 2, current_preds)

        assert report.flagged, f"Expected drift flag. PSI={report.psi:.3f}"

    def test_empty_reference_seeds_on_first_call(self, adapter):
        monitor = DriftMonitor()
        preds = adapter.predict_proba_batch(ALL_TEXTS)
        with pytest.raises(RuntimeError, match="reference window is empty"):
            monitor.check(ALL_TEXTS, preds)

    def test_update_slides_window(self, adapter):
        monitor = DriftMonitor(reference_window_size=5)
        preds = adapter.predict_proba_batch(ALL_TEXTS[:5])
        monitor.update(ALL_TEXTS[:5], preds)
        assert monitor.reference_size == 5

        # Adding 3 more: window should stay ≤ 5
        preds2 = adapter.predict_proba_batch(ALL_TEXTS[5:8])
        monitor.update(ALL_TEXTS[5:8], preds2)
        assert monitor.reference_size == 5

    def test_reset_clears_window(self, adapter):
        monitor = DriftMonitor()
        preds = adapter.predict_proba_batch(ALL_TEXTS)
        monitor.update(ALL_TEXTS, preds)
        assert monitor.reference_size > 0
        monitor.reset()
        assert monitor.reference_size == 0


# ---------------------------------------------------------------------------
# ToxicityScanner tests
# ---------------------------------------------------------------------------

class TestToxicityScanner:

    def test_clean_texts_not_flagged(self):
        scanner = ToxicityScanner(scorers=[RegexScorer(threshold=0.5)])
        report = scanner.scan(POSITIVE_TEXTS + NEUTRAL_TEXTS)
        assert not report.flagged

    def test_toxic_texts_flagged(self):
        toxic = [
            "I hate you and want to murder you.",
            "You are such an idiot.",
            "This is absolute trash you racist.",
        ]
        scanner = ToxicityScanner(scorers=[RegexScorer(threshold=0.4)], threshold=0.4)
        report = scanner.scan(toxic)
        assert report.flagged
        assert len(report.flagged_indices) >= 1

    def test_max_scores_shape(self):
        scanner = ToxicityScanner(scorers=[RegexScorer()])
        report = scanner.scan(ALL_TEXTS)
        assert len(report.max_scores) == len(ALL_TEXTS)
        assert all(0.0 <= s <= 1.0 for s in report.max_scores)

    def test_agg_max_vs_mean(self):
        texts = ["I hate this terrible product."]
        scanner_max = ToxicityScanner(scorers=[RegexScorer()], agg="max")
        scanner_mean = ToxicityScanner(scorers=[RegexScorer()], agg="mean")
        r_max = scanner_max.scan(texts)
        r_mean = scanner_mean.scan(texts)
        # Both should produce the same score with one scorer
        assert r_max.max_scores[0] == pytest.approx(r_mean.max_scores[0])

    def test_scorer_failure_gracefully_handled(self):
        class BrokenScorer(RegexScorer):
            name = "broken"
            def score_batch(self, texts):
                raise RuntimeError("simulated failure")

        scanner = ToxicityScanner(scorers=[BrokenScorer(), RegexScorer()])
        report = scanner.scan(["hello world"])
        assert len(report.max_scores) == 1   # still returns


# ---------------------------------------------------------------------------
# AuditLogger tests
# ---------------------------------------------------------------------------

class TestAuditLogger:

    def _make_report(self) -> RAIReport:
        return RAIReport(
            timestamp=time.time(),
            adapter_provider="mock",
            texts_count=5,
        )

    def test_writes_and_reads_records(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name

        log = AuditLogger(path=path, enabled=True)
        log.log(self._make_report())
        log.log(self._make_report())

        records = list(log.iter_records())
        assert len(records) == 2
        assert all(r["adapter_provider"] == "mock" for r in records)

    def test_disabled_logger_is_noop(self):
        with tempfile.TemporaryDirectory() as d:
            path = f"{d}/should_not_exist.jsonl"
            log = AuditLogger(path=path, enabled=False)
            log.log(self._make_report())
            assert not os.path.exists(path)

    def test_summary_stats(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name

        log = AuditLogger(path=path, enabled=True)
        for _ in range(5):
            log.log(self._make_report())

        stats = log.summary_stats()
        assert stats["total_records"] == 5
        assert "mock" in stats["providers"]


# ---------------------------------------------------------------------------
# ResponsibleAILayer integration tests
# ---------------------------------------------------------------------------

class TestResponsibleAILayer:

    def _build_layer(self, adapter, **kwargs) -> ResponsibleAILayer:
        return ResponsibleAILayer(
            adapter=adapter,
            fairness_auditor=FairnessAuditor(min_group_size=2),
            stability_auditor=StabilityAuditor(
                strategies=["char_noise"], n_perturbations=1
            ),
            drift_monitor=DriftMonitor(),
            toxicity_scanner=ToxicityScanner(scorers=[RegexScorer()]),
            **kwargs,
        )

    def test_predict_proba_batch_passthrough(self, adapter):
        layer = self._build_layer(adapter)
        proba = layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)
        expected = adapter.predict_proba_batch(ALL_TEXTS)
        np.testing.assert_allclose(proba, expected, rtol=1e-5)

    def test_last_report_populated(self, adapter):
        layer = self._build_layer(adapter)
        layer.predict_proba_batch(ALL_TEXTS[:5], group_labels=["a", "b", "a", "b", "a"])
        assert layer.last_report is not None
        assert isinstance(layer.last_report, RAIReport)
        assert layer.last_report.texts_count == 5

    def test_drift_auto_seeds_on_empty_window(self, adapter):
        layer = self._build_layer(adapter)
        # Should not raise; seeds the window automatically
        layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)
        assert layer.last_report.drift is None  # first call seeds, no check

    def test_drift_check_on_second_call(self, adapter):
        layer = self._build_layer(adapter)
        layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)
        layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)
        assert layer.last_report.drift is not None

    def test_raise_on_flag(self, adapter):
        toxic_texts = ["I hate everyone and want to murder them."] * 5
        layer = ResponsibleAILayer(
            adapter=adapter,
            toxicity_scanner=ToxicityScanner(
                scorers=[RegexScorer(threshold=0.3)], threshold=0.3
            ),
            raise_on_flag=True,
        )
        with pytest.raises(RAIFlagError):
            layer.predict_proba_batch(toxic_texts)

    def test_delegation_to_adapter(self, adapter):
        layer = self._build_layer(adapter)
        assert layer.provider == "mock"

    def test_repr(self, adapter):
        layer = self._build_layer(adapter)
        r = repr(layer)
        assert "ResponsibleAILayer" in r
        assert "mock" in r

    def test_audit_texts_post_hoc(self, adapter, proba):
        layer = self._build_layer(adapter)
        report = layer.audit_texts(
            texts=ALL_TEXTS,
            predictions=proba,
            group_labels=GROUP_LABELS,
            true_labels=TRUE_LABELS,
        )
        assert isinstance(report, RAIReport)
        assert report.toxicity is not None
        assert report.fairness is not None

    def test_summary_string(self, adapter, proba):
        layer = self._build_layer(adapter)
        layer.drift_monitor.update(ALL_TEXTS, proba)
        layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)
        summary = layer.last_report.summary
        assert isinstance(summary, str)
        assert len(summary) > 0

    def test_full_pipeline_with_audit_log(self, adapter, proba):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name

        layer = ResponsibleAILayer(
            adapter=adapter,
            fairness_auditor=FairnessAuditor(min_group_size=2),
            toxicity_scanner=ToxicityScanner(scorers=[RegexScorer()]),
            audit_logger=AuditLogger(path=path),
        )
        layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)
        layer.predict_proba_batch(ALL_TEXTS, group_labels=GROUP_LABELS)

        log = AuditLogger(path=path)
        records = list(log.iter_records())
        assert len(records) == 2

    def test_no_auditors_is_zero_cost(self, adapter):
        layer = ResponsibleAILayer(adapter=adapter)
        proba = layer.predict_proba_batch(ALL_TEXTS)
        assert proba.shape == (len(ALL_TEXTS), 2)
        assert layer.last_report.fairness is None
        assert layer.last_report.stability is None
        assert layer.last_report.drift is None
        assert layer.last_report.toxicity is None


# ---------------------------------------------------------------------------
# Performance smoke test
# ---------------------------------------------------------------------------

class TestPerformance:
    """Ensure the RAI layer doesn't add catastrophic overhead on moderate batches."""

    def test_throughput(self, adapter):
        n = 50
        texts = (ALL_TEXTS * 4)[:n]
        groups = (GROUP_LABELS * 4)[:n]

        layer = ResponsibleAILayer(
            adapter=adapter,
            stability_auditor=StabilityAuditor(
                strategies=["char_noise"], n_perturbations=2, max_workers=4
            ),
            toxicity_scanner=ToxicityScanner(scorers=[RegexScorer()]),
        )

        start = time.perf_counter()
        layer.predict_proba_batch(texts, group_labels=groups)
        elapsed = time.perf_counter() - start

        print(f"\n[perf] n={n} texts, elapsed={elapsed:.3f}s")
        assert elapsed < 30.0, f"RAI layer too slow: {elapsed:.2f}s for {n} samples"


# ---------------------------------------------------------------------------
# Integration test (skipped without HF token)
# ---------------------------------------------------------------------------

@pytest.mark.skipif(
    not os.getenv("HF_API_TOKEN"),
    reason="HF_API_TOKEN not set — skipping live integration test"
)
class TestIntegrationHuggingFace:

    def test_rai_on_distilbert_sst2(self):
        """
        Smoke-test the full RAI layer against the live DistilBERT SST-2 adapter.
        Requires HF_API_TOKEN in environment and the text_adapter module.
        """
        try:
            from text_adapter import TextAdapter  # noqa: F401
        except ImportError:
            pytest.skip("text_adapter not available")

        adapter = TextAdapter.from_provider(
            "huggingface",
            model="distilbert-base-uncased-finetuned-sst-2-english",
            api_token=os.environ["HF_API_TOKEN"],
        )

        texts = [
            "I absolutely loved this movie, it was fantastic!",
            "The worst film I have ever seen.",
            "Mediocre at best, nothing special.",
            "An outstanding performance by the lead actor.",
            "Completely boring and a waste of time.",
        ]
        groups = ["critic", "user", "user", "critic", "user"]

        layer = ResponsibleAILayer(
            adapter=adapter,
            fairness_auditor=FairnessAuditor(
                protected_attribute="reviewer_type", min_group_size=2
            ),
            stability_auditor=StabilityAuditor(
                strategies=["char_noise"], n_perturbations=2
            ),
            toxicity_scanner=ToxicityScanner(scorers=[RegexScorer()]),
        )

        proba = layer.predict_proba_batch(texts, group_labels=groups)
        report = layer.last_report

        print(f"\n[integration] {report.summary}")
        assert proba.shape == (5, 2)
        assert report.fairness is not None
        assert report.stability is not None
        assert report.toxicity is not None