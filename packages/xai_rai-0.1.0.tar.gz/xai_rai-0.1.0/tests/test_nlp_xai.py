import numpy as np

from xai_rai.adapters.text_adapter import TextAdapter
from xai_rai.explainers.text_explainer import NLPExplainer


def mock_fn(text):

    pos_words = {
        "good","great","love","fantastic"
    }

    score = (
        0.85 if any(
            w in text.lower()
            for w in pos_words
        )
        else 0.2
    )

    return [
      {"label":"NEGATIVE","score":1-score},
      {"label":"POSITIVE","score":score}
    ]


def test_batch_fn_shape():

    adapter = TextAdapter.from_provider(
        "local",
        fn=mock_fn
    )

    xai = NLPExplainer(adapter)

    out = xai._batch_fn(
       ["good movie","bad film","okay"]
    )

    assert out.shape==(3,2)

    np.testing.assert_allclose(
       out.sum(axis=1),
       1.0
    )


def test_shap_explanation():

    adapter = TextAdapter.from_provider(
        "local",
        fn=mock_fn
    )

    xai = NLPExplainer(adapter)

    exp = xai.explain_shap(
        "This movie was fantastic",
        max_evals=100
    )

    assert len(exp.attributions) > 0
    assert exp.predicted_label in [
        "POSITIVE",
        "NEGATIVE"
    ]


def test_lime_explanation():

    adapter = TextAdapter.from_provider(
       "local",
       fn=mock_fn
    )

    xai = NLPExplainer(
       adapter,
       lime_num_samples=200
    )

    exp = xai.explain_lime(
       "This movie was fantastic"
    )

    assert len(exp.attributions)>0
    assert isinstance(exp.score,float)


def test_combined_agreement():

    adapter = TextAdapter.from_provider(
      "local",
      fn=mock_fn
    )

    xai = NLPExplainer(adapter)

    exp = xai.explain(
      "This movie was fantastic"
    )

    assert isinstance(
       exp.agreement(),
       list
    )