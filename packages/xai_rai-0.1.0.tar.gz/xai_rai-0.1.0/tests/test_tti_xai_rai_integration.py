import os

import pytest
from PIL import Image

from xai_rai.adapters.text_to_image_adapter import (
    MultiSignalExplainer,
    make_hf_generate_fn,
)


def _mock_generate_fn(prompt: str) -> Image.Image:
    # Minimal fallback image for model-agnostic adapter contract testing.
    img = Image.new("RGB", (256, 256), color=(30, 30, 30))
    return img


def test_tti_adapter_model_agnostic_with_custom_generate_fn():
    explainer = MultiSignalExplainer(
        generate_fn=_mock_generate_fn,
        model_label="CustomCallableGenerator",
        mode="fast",
    )
    result = explainer.explain("a calm mountain lake at sunrise")

    assert result.prompt == "a calm mountain lake at sunrise"
    assert result.model_label == "CustomCallableGenerator"
    assert result.analysis_mode == "fast"
    assert isinstance(result.image_b64, str) and len(result.image_b64) > 0
    assert isinstance(result.word_attributions, list)
    assert isinstance(result.concept_scores, list)
    assert result.rai is not None


@pytest.mark.skipif(
    not os.getenv("RUN_TTI_HF_INTEGRATION"),
    reason="Set RUN_TTI_HF_INTEGRATION=1 to run local HuggingFace TTI test.",
)
def test_tti_hf_free_model_integration_fast_mode():
    # Free/open model from the project's TTI registry.
    generate_fn = make_hf_generate_fn(
        model_id="segmind/small-sd",
        seed=7,
        device="auto",
        low_memory=True,
    )

    explainer = MultiSignalExplainer(
        generate_fn=generate_fn,
        model_label="segmind/small-sd",
        mode="fast",
    )

    prompt = "a watercolor painting of a lighthouse during sunset"
    result = explainer.explain(prompt)

    assert result.prompt == prompt
    assert result.model_label == "segmind/small-sd"
    assert result.analysis_mode == "fast"
    assert isinstance(result.top_concepts, list)
    assert isinstance(result.image_b64, str) and len(result.image_b64) > 0
