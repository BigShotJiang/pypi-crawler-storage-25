"""
rai/image_classifier/image_rai.py

Responsible AI (RAI) checks for image classification models.

Current checks
--------------
1. Prediction stability  — how consistently does the model classify a
   slightly noisy version of the same image?
2. Top-k sensitivity     — how much do top-k probabilities shift under noise?
3. Confidence calibration flag — warns when the model is extremely over- or
   under-confident on a single sample.

All checks are model-agnostic; they only require a predict_fn conforming to:
    predict_fn(images: np.ndarray) -> np.ndarray
    images  : float32 (N, H, W, 3), values in [0, 1]
    returns : float32 (N, num_classes)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np


# ── Result container ──────────────────────────────────────────────────────────

@dataclass
class ImageRAIResult:
    """
    Holds all RAI check outputs for a single image.

    Attributes
    ----------
    top_class_idx         : Predicted class index on the clean image.
    top_class_prob        : Predicted probability for that class.
    stability_score       : Fraction of noisy runs that agree with the clean
                            prediction (1.0 = perfectly stable).
    mean_prob_std         : Mean per-class std-dev across noisy runs (lower = more stable).
    topk_prob_range       : (min, max) of top-1 probability across noisy runs.
    confidence_flag       : "overconfident" | "underconfident" | "ok"
    warnings              : List of human-readable warning strings.
    extra                 : Dict for any additional metrics added by subclasses.
    """

    top_class_idx:   Optional[int]   = None
    top_class_prob:  Optional[float] = None

    # Stability
    stability_score:  float = 0.0
    mean_prob_std:    float = 0.0
    topk_prob_range:  tuple[float, float] = (0.0, 0.0)

    # Confidence calibration
    confidence_flag: str = "ok"   # "overconfident" | "underconfident" | "ok"

    warnings: list[str] = field(default_factory=list)
    extra:    dict       = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"Top class idx  : {self.top_class_idx}",
            f"Top class prob : {self.top_class_prob:.4f}" if self.top_class_prob else "",
            f"Stability      : {self.stability_score:.2%}",
            f"Mean prob std  : {self.mean_prob_std:.4f}",
            f"Top-1 range    : [{self.topk_prob_range[0]:.4f}, {self.topk_prob_range[1]:.4f}]",
            f"Confidence flag: {self.confidence_flag}",
        ]
        if self.warnings:
            lines.append("Warnings:")
            lines.extend(f"  - {w}" for w in self.warnings)
        return "\n".join(l for l in lines if l)


# ── Checker ───────────────────────────────────────────────────────────────────

class ImageRAIChecker:
    """
    RAI checks for image classification models.

    Parameters
    ----------
    overconfidence_threshold  : Top-1 prob above this triggers "overconfident".
    underconfidence_threshold : Top-1 prob below this triggers "underconfident".
    instability_threshold     : stability_score below this triggers a warning.
    """

    def __init__(
        self,
        overconfidence_threshold:  float = 0.99,
        underconfidence_threshold: float = 0.10,
        instability_threshold:     float = 0.80,
    ) -> None:
        self.overconfidence_threshold  = overconfidence_threshold
        self.underconfidence_threshold = underconfidence_threshold
        self.instability_threshold     = instability_threshold

    # ── Internal helpers ───────────────────────────────────────────────────

    @staticmethod
    def _add_gaussian_noise(
        image:     np.ndarray,
        std:       float,
        n_copies:  int,
        rng:       np.random.Generator,
    ) -> np.ndarray:
        """
        Return (n_copies, H, W, 3) float32 array of noisy clipped copies.
        """
        noise  = rng.normal(0.0, std, size=(n_copies, *image.shape)).astype(np.float32)
        copies = np.clip(image[np.newaxis] + noise, 0.0, 1.0)
        return copies

    def _stability_check(
        self,
        image:       np.ndarray,
        predict_fn:  Callable[[np.ndarray], np.ndarray],
        top_class:   int,
        n_samples:   int,
        noise_std:   float,
        rng:         np.random.Generator,
    ) -> dict:
        """Run stability test; return raw metrics dict."""
        noisy = self._add_gaussian_noise(image, noise_std, n_samples, rng)
        preds = predict_fn(noisy)             # (n_samples, C)

        predicted_classes = np.argmax(preds, axis=1)  # (n_samples,)
        agree_fraction    = float(np.mean(predicted_classes == top_class))

        top1_probs   = preds[:, top_class]
        mean_prob_std = float(np.mean(np.std(preds, axis=0)))

        return {
            "stability_score":  agree_fraction,
            "mean_prob_std":    mean_prob_std,
            "topk_prob_range":  (float(top1_probs.min()), float(top1_probs.max())),
        }

    def _confidence_flag(self, prob: float) -> str:
        if prob >= self.overconfidence_threshold:
            return "overconfident"
        if prob <= self.underconfidence_threshold:
            return "underconfident"
        return "ok"

    # ── Public API ─────────────────────────────────────────────────────────

    def check(
        self,
        image:      np.ndarray,
        predict_fn: Callable[[np.ndarray], np.ndarray],
        n_stability: int   = 10,
        noise_std:   float = 0.02,
        seed:        int   = 42,
    ) -> ImageRAIResult:
        """
        Run all RAI checks on a single preprocessed image.

        Parameters
        ----------
        image        : float32 (H, W, 3) in [0, 1]
        predict_fn   : model predict function
        n_stability  : number of noisy copies for the stability test
        noise_std    : std-dev of Gaussian noise for the stability test
        seed         : random seed for reproducibility

        Returns
        -------
        ImageRAIResult with all fields populated.
        """
        rng = np.random.default_rng(seed)

        # Clean prediction
        baseline    = predict_fn(image[np.newaxis])[0]
        top_class   = int(np.argmax(baseline))
        top_prob    = float(baseline[top_class])

        result = ImageRAIResult(
            top_class_idx  = top_class,
            top_class_prob = top_prob,
        )

        # Stability
        stab = self._stability_check(
            image, predict_fn, top_class, n_stability, noise_std, rng
        )
        result.stability_score  = stab["stability_score"]
        result.mean_prob_std    = stab["mean_prob_std"]
        result.topk_prob_range  = stab["topk_prob_range"]

        # Confidence calibration
        result.confidence_flag = self._confidence_flag(top_prob)

        # Warnings
        warnings: list[str] = []

        if result.stability_score < self.instability_threshold:
            warnings.append(
                f"Model is unstable: only {result.stability_score:.0%} agreement "
                f"across {n_stability} noisy samples (noise std={noise_std})."
            )
        if result.confidence_flag == "overconfident":
            warnings.append(
                f"Model is overconfident: top-1 prob={top_prob:.4f} "
                f"(threshold={self.overconfidence_threshold})."
            )
        if result.confidence_flag == "underconfident":
            warnings.append(
                f"Model is underconfident: top-1 prob={top_prob:.4f} "
                f"(threshold={self.underconfidence_threshold})."
            )

        result.warnings = warnings
        return result