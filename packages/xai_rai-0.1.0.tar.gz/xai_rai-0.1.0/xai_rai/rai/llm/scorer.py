"""
xai_rai/rai/scorer.py
=====================
Responsible-AI toxicity scoring via Detoxify.
Falls back gracefully to zero scores when detoxify is not installed.
"""

from __future__ import annotations

import logging

from xai_rai.contracts import RAIScorecard
from xai_rai.core.config import RAI_FLAG_THRESHOLD

logger = logging.getLogger(__name__)

try:
    from detoxify import Detoxify as _Detoxify
    _DETOXIFY_AVAILABLE = True
except ImportError:
    _DETOXIFY_AVAILABLE = False
    logger.warning("detoxify not installed — RAI scoring will return zero scores.")


class RAIScorer:
    """
    Scores both the user prompt and the LLM response for toxicity signals.

    Returns
    -------
    RAIScorecard  with per-field floats and boolean flags.
    """

    def __init__(self, model_name: str = "original"):
        self._model = _Detoxify(model_name) if _DETOXIFY_AVAILABLE else None

    def score(self, prompt: str, response: str) -> RAIScorecard:
        if self._model is None:
            return self._zero_scorecard()

        p = self._model.predict(prompt)
        r = self._model.predict(response)

        _f  = lambda d, k: float(d.get(k, 0.0))
        pf  = any(v > RAI_FLAG_THRESHOLD for v in p.values())
        rf  = any(v > RAI_FLAG_THRESHOLD for v in r.values())

        return RAIScorecard(
            prompt_toxicity          = _f(p, "toxicity"),
            prompt_severe_toxicity   = _f(p, "severe_toxicity"),
            prompt_insult            = _f(p, "insult"),
            prompt_threat            = _f(p, "threat"),
            prompt_identity_attack   = _f(p, "identity_attack"),
            prompt_flagged           = pf,
            response_toxicity        = _f(r, "toxicity"),
            response_severe_toxicity = _f(r, "severe_toxicity"),
            response_insult          = _f(r, "insult"),
            response_threat          = _f(r, "threat"),
            response_identity_attack = _f(r, "identity_attack"),
            response_flagged         = rf,
            overall_flagged          = pf or rf,
        )

    @staticmethod
    def _zero_scorecard() -> RAIScorecard:
        z = dict(toxicity=0.0, severe_toxicity=0.0, insult=0.0,
                 threat=0.0, identity_attack=0.0)
        return RAIScorecard(
            **{f"prompt_{k}": v for k, v in z.items()},   prompt_flagged=False,
            **{f"response_{k}": v for k, v in z.items()}, response_flagged=False,
            overall_flagged=False,
        )