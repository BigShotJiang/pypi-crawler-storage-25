"""
xai_rai/explainers/bias.py
==========================
Response-space demographic bias probing.

Two complementary strategies
-----------------------------
A. Explicit swap probing  — known demographic term pairs (he/she, John/Mohammed…)
B. Implicit bias probing  — context phrases that carry demographic assumptions
                            without naming a group (career break, maternity, etc.)

Both strategies measure cosine drift between the original response embedding
and the embedding of a swapped/neutralised prompt variant.
High drift → response was sensitive to the demographic signal.
"""

from __future__ import annotations

import re

import numpy as np

from xai_rai.contracts import AdversarialCheck, BiasProbeResult, ImplicitBiasSignal
from xai_rai.core.config import (
    BIAS_THRESHOLD,
    DEMOGRAPHIC_PAIRS,
    IMPLICIT_BIAS_PATTERNS,
    IMPLICIT_BIAS_NEUTRALISATIONS,
    IMPLICIT_BIAS_THRESHOLD,
)
from xai_rai.core.embeddings import EmbeddingEngine


class BiasProber:
    """
    Stateless response-space bias prober.

    Parameters
    ----------
    embedding_engine : shared EmbeddingEngine instance
    """

    def __init__(self, embedding_engine: EmbeddingEngine):
        self._emb = embedding_engine

    # ── Public API ─────────────────────────────────────────────────────────────

    def probe(self, prompt: str, response_vec: np.ndarray) -> BiasProbeResult:
        explicit_result = self._probe_explicit(prompt, response_vec)
        implicit_result = self._probe_implicit(prompt, response_vec)

        # Merge: implicit signals annotate the same BiasProbeResult
        return BiasProbeResult(
            tested               = explicit_result.tested or implicit_result["tested"],
            pairs_found          = explicit_result.pairs_found,
            max_drift            = max(explicit_result.max_drift, implicit_result["max_drift"]),
            flagged              = explicit_result.flagged,
            flagged_swaps        = explicit_result.flagged_swaps,
            implicit_signals     = implicit_result["signals"],
            implicit_flagged     = implicit_result["flagged"],
            implicit_categories  = implicit_result["categories"],
        )

    # ── Explicit swap probing (unchanged logic, extracted) ─────────────────────

    def _probe_explicit(self, prompt: str, response_vec: np.ndarray) -> BiasProbeResult:
        pairs_found:  list[str]  = []
        swap_prompts: list[str]  = []
        swap_meta:    list[tuple[str, str]] = []

        for term_a, term_b in DEMOGRAPHIC_PAIRS:
            pat_a = re.compile(r"\b" + re.escape(term_a) + r"\b", re.IGNORECASE)
            pat_b = re.compile(r"\b" + re.escape(term_b) + r"\b", re.IGNORECASE)
            has_a = bool(pat_a.search(prompt))
            has_b = bool(pat_b.search(prompt))

            if not has_a and not has_b:
                continue

            pairs_found.append(f"{term_a}/{term_b}")
            if has_a:
                swap_prompts.append(pat_a.sub(term_b, prompt))
                swap_meta.append((term_a, term_b))
            else:
                swap_prompts.append(pat_b.sub(term_a, prompt))
                swap_meta.append((term_b, term_a))

        if not swap_prompts:
            return BiasProbeResult(
                tested=False, pairs_found=[], max_drift=0.0,
                flagged=False, flagged_swaps=[],
            )

        swap_vecs     = self._emb.encode(swap_prompts)
        max_drift     = 0.0
        flagged_swaps: list[dict] = []

        for sv, (orig_term, swapped_term) in zip(swap_vecs, swap_meta):
            drift = round(float(np.clip(1.0 - np.dot(response_vec, sv), 0.0, 1.0)), 4)
            if drift > max_drift:
                max_drift = drift
            if drift > BIAS_THRESHOLD:
                flagged_swaps.append({
                    "original_term": orig_term,
                    "swapped_term":  swapped_term,
                    "drift":         drift,
                })

        return BiasProbeResult(
            tested        = True,
            pairs_found   = pairs_found,
            max_drift     = round(max_drift, 4),
            flagged       = max_drift > BIAS_THRESHOLD,
            flagged_swaps = flagged_swaps,
        )

    # ── Implicit bias probing (NEW) ────────────────────────────────────────────

    def _probe_implicit(self, prompt: str, response_vec: np.ndarray) -> dict:
        """
        For every implicit bias pattern found in the prompt or response context,
        build a neutralised variant and measure embedding drift.

        Returns a plain dict (merged into BiasProbeResult by probe()).
        """
        signals:          list[ImplicitBiasSignal] = []
        neutralised_texts: list[str]               = []
        signal_meta:       list[tuple[str, str, str]] = []  # (pattern, category, location)

        text_lower = prompt.lower()

        for category, patterns in IMPLICIT_BIAS_PATTERNS.items():
            for pattern in patterns:
                if pattern not in text_lower:
                    continue

                neutral = IMPLICIT_BIAS_NEUTRALISATIONS.get(pattern, pattern)
                neutralised = re.sub(
                    re.escape(pattern), neutral, prompt, flags=re.IGNORECASE
                )

                # Find the matched text with original casing for the signal record
                match = re.search(re.escape(pattern), prompt, re.IGNORECASE)
                matched_text = match.group(0) if match else pattern

                neutralised_texts.append(neutralised)
                signal_meta.append((pattern, category, matched_text))

        if not neutralised_texts:
            return {"tested": False, "signals": [], "flagged": False,
                    "categories": [], "max_drift": 0.0}

        neutral_vecs = self._emb.encode(neutralised_texts)
        max_drift    = 0.0
        categories_flagged: set[str] = set()

        for nv, (pattern, category, matched_text) in zip(neutral_vecs, signal_meta):
            drift = round(float(np.clip(1.0 - np.dot(response_vec, nv), 0.0, 1.0)), 4)
            if drift > max_drift:
                max_drift = drift

            signals.append(ImplicitBiasSignal(
                pattern      = pattern,
                category     = category,
                matched_text = matched_text,
                location     = "prompt",
                drift        = drift,
            ))

            if drift > IMPLICIT_BIAS_THRESHOLD:
                categories_flagged.add(category)

        flagged = bool(categories_flagged)
        return {
            "tested":     True,
            "signals":    signals,
            "flagged":    flagged,
            "categories": sorted(categories_flagged),
            "max_drift":  round(max_drift, 4),
        }