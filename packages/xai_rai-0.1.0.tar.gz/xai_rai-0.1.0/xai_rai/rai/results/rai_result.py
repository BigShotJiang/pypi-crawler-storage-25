from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional


@dataclass
class FairnessResult:
    """Output of a fairness analysis."""
    metric_name: str                          # e.g. "demographic_parity_difference"
    value: float
    flagged: bool                             # True if value exceeds threshold
    threshold: float
    group_scores: dict[str, float] = field(default_factory=dict)
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class StabilityResult:
    """Output of a stability/robustness analysis."""
    mean_diff: float                          # Mean importance shift under noise
    std_diff: float
    flagged: bool                             # True if mean_diff exceeds threshold
    threshold: float
    per_feature_diff: dict[str, float] = field(default_factory=dict)
    trials: int = 5


@dataclass
class DriftResult:
    """Output of a feature importance drift analysis between two batches."""
    metric: str                               # e.g. "psi", "ks"
    per_feature: dict[str, float] = field(default_factory=dict)
    flagged_features: list[str] = field(default_factory=list)
    threshold: float = 0.2
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class BiasResult:
    """Output of a feature-level bias scan."""
    biased_features: list[str] = field(default_factory=list)
    importance_gap: dict[str, float] = field(default_factory=dict)
    flagged: bool = False
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class RAIResult:
    """
    Top-level RAI report output. Aggregates all analyzer results.
    This is the single object returned by RAIReport.run().
    """
    modality: str                             # "tabular" | "image" | "nlp" | "llm"
    n_samples: int
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    fairness: Optional[FairnessResult] = None
    stability: Optional[StabilityResult] = None
    drift: Optional[DriftResult] = None
    bias: Optional[BiasResult] = None
    global_importance: dict[str, float] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)  # section → error message

    @property
    def passed(self) -> bool:
        """True if no analyzer flagged an issue and no errors occurred."""
        checks = [
            self.fairness.flagged if self.fairness else False,
            self.stability.flagged if self.stability else False,
            bool(self.drift.flagged_features) if self.drift else False,
            self.bias.flagged if self.bias else False,
            bool(self.errors),
        ]
        return not any(checks)

    def summary(self) -> dict[str, Any]:
        """Compact dict summary suitable for logging or UI display."""
        return {
            "modality": self.modality,
            "n_samples": self.n_samples,
            "timestamp": self.timestamp,
            "passed": self.passed,
            "fairness_flagged": self.fairness.flagged if self.fairness else None,
            "stability_flagged": self.stability.flagged if self.stability else None,
            "drift_flagged_features": self.drift.flagged_features if self.drift else None,
            "bias_flagged": self.bias.flagged if self.bias else None,
            "errors": self.errors,
        }