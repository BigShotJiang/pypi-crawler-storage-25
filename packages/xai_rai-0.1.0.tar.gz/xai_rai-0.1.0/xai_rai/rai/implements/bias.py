from __future__ import annotations

from typing import Any, Optional

import numpy as np

from ..analyzers.base import BaseRAIAnalyzer
from ..results import BiasResult
from ..utils import validate_results, aggregate_importance


class TabularBiasAnalyzer(BaseRAIAnalyzer):
    """
    Feature-level bias scanner for tabular models.

    Checks whether user-specified sensitive features (e.g. 'age', 'gender',
    'postcode') are contributing disproportionately to model predictions
    based on their mean SHAP/LIME importance across a batch.

    This does not replace fairness analysis — it complements it by catching
    cases where a sensitive feature has high importance even if group-level
    parity metrics look acceptable (proxy bias via correlated features).

    Two modes:
    - "absolute"  : flag if mean importance of a sensitive feature exceeds threshold
    - "relative"  : flag if mean importance of a sensitive feature exceeds
                    threshold * mean importance of all non-sensitive features
    """

    SUPPORTED_MODES = ("absolute", "relative")

    def __init__(
        self,
        sensitive_feature_names: list[str],
        threshold: float = 0.1,
        mode: str = "relative",
    ):
        if not sensitive_feature_names:
            raise ValueError("sensitive_feature_names must not be empty")
        if mode not in self.SUPPORTED_MODES:
            raise ValueError(
                f"mode must be one of {self.SUPPORTED_MODES}, got '{mode}'"
            )
        self._sensitive = set(sensitive_feature_names)
        self._threshold = threshold
        self._mode = mode

    @property
    def modality(self) -> str:
        return "tabular"

    def analyze(self, results: list[Any], **kwargs) -> BiasResult:
        """
        Parameters
        ----------
        results : list[XAIResult]
            Batch of explanation results to scan.
        """
        validate_results(results, min_samples=1)

        mean_importance = aggregate_importance(results)
        if not mean_importance:
            raise ValueError(
                "Could not extract feature importance from results. "
                "Ensure XAI results contain non-empty feature_importance."
            )

        sensitive_scores = {
            k: v for k, v in mean_importance.items() if k in self._sensitive
        }
        non_sensitive_scores = {
            k: v for k, v in mean_importance.items() if k not in self._sensitive
        }

        # Baseline: mean importance of non-sensitive features
        baseline = (
            float(np.mean(list(non_sensitive_scores.values())))
            if non_sensitive_scores
            else 0.0
        )

        biased: list[str] = []
        importance_gap: dict[str, float] = {}

        for feature, score in sensitive_scores.items():
            if self._mode == "absolute":
                gap = score
                flagged = score > self._threshold
            else:  # relative
                gap = score - baseline * self._threshold
                flagged = score > baseline * self._threshold if baseline > 0 else score > self._threshold

            importance_gap[feature] = float(score)
            if flagged:
                biased.append(feature)

        return BiasResult(
            biased_features=sorted(biased),
            importance_gap=importance_gap,
            flagged=bool(biased),
            details={
                "mode": self._mode,
                "threshold": self._threshold,
                "baseline_mean_importance": baseline,
                "n_samples": len(results),
                "sensitive_features_checked": list(self._sensitive),
            },
        )