"""
xai_rai/rai/implements/tti_vqa_probe.py
========================================
Tier 3 — VQA targeted safety probes (risk-gated).

Only fires when upstream tiers (CLIP or BLIP-2) have raised flags, keeping
latency negligible for clean images.  Uses BLIP VQA to ask structured yes/no
safety questions; calibrates confidence from first-token logits.
"""

from __future__ import annotations

import logging

from xai_rai.contracts_tti import (
    AnalyzerContext, AnalyzerResult, VQAProbeResult,
)
from xai_rai.core.tti_config import (
    VQA_SAFETY_PROBES, VQA_YES_THRESHOLD, _NSFW_CONCEPTS,
)
from xai_rai.explainers.model_registry import ModelAnalyzer

logger = logging.getLogger(__name__)

try:
    from transformers import BlipProcessor, BlipForQuestionAnswering
    import torch
    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False
    logger.warning("transformers not installed — VQA tier disabled.  "
                   "pip install transformers")


class VQAProbeAnalyzer(ModelAnalyzer):
    """
    Tier 3: Targeted VQA safety probes.

    Risk-gated: only runs probes relevant to flags raised by Tier 1/2.
    Nudity + violence probes are always added when any safety flag is active.
    """

    _MODEL_ID = "Salesforce/blip-vqa-base"

    def __init__(self):
        self._proc   = None
        self._model  = None
        self._device = None
        self._loaded = False

    @property
    def name(self) -> str:
        return "vqa_probe"

    def is_available(self) -> bool:
        return _AVAILABLE

    # ── lazy model load ───────────────────────────────────────────────────────

    def _lazy_load(self):
        if self._loaded:
            return
        logger.info("Loading BLIP VQA (%s)…", self._MODEL_ID)
        device        = "cuda" if torch.cuda.is_available() else "cpu"
        self._proc    = BlipProcessor.from_pretrained(self._MODEL_ID)
        self._model   = BlipForQuestionAnswering.from_pretrained(
            self._MODEL_ID
        ).to(device)
        self._device  = device
        self._loaded  = True

    # ── helpers ───────────────────────────────────────────────────────────────

    def _probe(self, image, question: str) -> tuple[str, float]:
        """Returns (answer_text, yes_confidence)."""
        self._lazy_load()
        inputs = self._proc(
            images=image, text=question, return_tensors="pt"
        ).to(self._device)
        with torch.no_grad():
            output = self._model.generate(
                **inputs,
                max_new_tokens=10,
                output_scores=True,
                return_dict_in_generate=True,
            )
        answer = self._proc.decode(
            output.sequences[0], skip_special_tokens=True
        ).strip().lower()

        confidence = 0.0
        if hasattr(output, "scores") and output.scores:
            logits  = output.scores[0][0]
            probs   = torch.softmax(logits, dim=-1)
            yes_ids = self._proc.tokenizer.encode("yes", add_special_tokens=False)
            no_ids  = self._proc.tokenizer.encode("no",  add_special_tokens=False)
            p_yes   = sum(probs[i].item() for i in yes_ids if i < len(probs))
            p_no    = sum(probs[i].item() for i in no_ids  if i < len(probs))
            total   = p_yes + p_no
            confidence = p_yes / total if total > 0 else (1.0 if "yes" in answer else 0.0)

        return answer, round(confidence, 4)

    def _select_probes(self, context: AnalyzerContext) -> list[tuple[str, str]]:
        all_flags = set(context.clip_flags) | set(context.injected_attrs)
        selected: list[tuple[str, str]] = []

        for concept_key, question in VQA_SAFETY_PROBES.items():
            if any(concept_key in flag or flag in concept_key for flag in all_flags):
                selected.append((concept_key, question))

        # Always sweep nudity + violence if any safety flag is active
        safety_concepts = {"nudity", "graphic violence"}
        for sk in safety_concepts:
            if sk not in {c for c, _ in selected}:
                if any(f in _NSFW_CONCEPTS or f == "alignment_low" for f in all_flags):
                    selected.append((sk, VQA_SAFETY_PROBES[sk]))

        return selected

    # ── main ─────────────────────────────────────────────────────────────────

    def analyze(self, context: AnalyzerContext) -> AnalyzerResult:
        probes_to_run = self._select_probes(context)

        if not probes_to_run:
            return AnalyzerResult(
                analyzer = self.name,
                data     = {
                    "probes":  [],
                    "skipped": True,
                    "reason":  "No upstream risk flags — VQA probe skipped",
                },
                flags = [],
            )

        results: list[VQAProbeResult] = []
        for concept, question in probes_to_run:
            answer, confidence = self._probe(context.image, question)
            flagged = confidence >= VQA_YES_THRESHOLD
            results.append(VQAProbeResult(
                question   = question,
                concept    = concept,
                confidence = confidence,
                answer     = answer,
                flagged    = flagged,
            ))
            logger.debug("VQA [%s]: %s (conf=%.2f)", concept, answer, confidence)

        flags = [r.concept for r in results if r.flagged]

        return AnalyzerResult(
            analyzer = self.name,
            data     = {"probes": results},
            flags    = flags,
        )