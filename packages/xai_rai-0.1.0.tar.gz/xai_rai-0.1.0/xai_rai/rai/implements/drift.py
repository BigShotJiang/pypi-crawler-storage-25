from __future__ import annotations

from typing import Any, Optional

import numpy as np

from ..analyzers.base import BaseRAIAnalyzer
from ..results import DriftResult
from ..utils import validate_results, aggregate_importance

# scipy is optional — only needed for KS test
try:
    from scipy.stats import ks_2samp
    _SCIPY_AVAILABLE = True
except ImportError:
    _SCIPY_AVAILABLE = False


class TabularDriftAnalyzer(BaseRAIAnalyzer):
    """
    Feature importance drift analysis for tabular models.

    Compares importance distributions between a baseline batch and a
    current batch. Two metrics are supported:

    - "psi"  : Population Stability Index — standard in risk/credit modeling.
               PSI > 0.2 indicates significant drift.
    - "ks"   : Kolmogorov-Smirnov test p-value per feature.
               Flags features where p < threshold (distributions differ).

    This is NOT input data drift — it measures whether the model's
    explanation structure has shifted, which can indicate model degradation,
    distribution shift, or concept drift before it shows up in accuracy.
    """

    SUPPORTED_METRICS = ("psi", "ks")

    def __init__(
        self,
        metric: str = "psi",
        threshold: float = 0.2,
        n_bins: int = 5,
    ):
        if metric not in self.SUPPORTED_METRICS:
            raise ValueError(
                f"metric must be one of {self.SUPPORTED_METRICS}, got '{metric}'"
            )
        if metric == "ks" and not _SCIPY_AVAILABLE:
            raise ImportError(
                "scipy is required for KS drift analysis. "
                "Install it with: pip install scipy"
            )
        self._metric = metric
        self._threshold = threshold
        self._n_bins = n_bins

    @property
    def modality(self) -> str:
        return "tabular"

    def analyze(
        self,
        results: list[Any],
        baseline_results: list[Any],
        **kwargs,
    ) -> DriftResult:
        validate_results(results, min_samples=2)
        validate_results(baseline_results, min_samples=2)

        current_by_feature = self._importance_vectors(results)
        baseline_by_feature = self._importance_vectors(baseline_results)

        # Only score features present in both batches
        common_features = set(current_by_feature) & set(baseline_by_feature)
        missing_in_current = set(baseline_by_feature) - set(current_by_feature)
        missing_in_baseline = set(current_by_feature) - set(baseline_by_feature)

        per_feature: dict[str, float] = {}
        flagged: list[str] = []
        skipped_low_samples: list[str] = []

        MIN_SAMPLES = max(5, self._n_bins * 2)

        for feature in common_features:
            current_vals = np.array(current_by_feature[feature])
            baseline_vals = np.array(baseline_by_feature[feature])

            if len(current_vals) < MIN_SAMPLES or len(baseline_vals) < MIN_SAMPLES:
                skipped_low_samples.append(feature)
                continue

            score = (
                self._psi(baseline_vals, current_vals)
                if self._metric == "psi"
                else self._ks(baseline_vals, current_vals)
            )

            per_feature[feature] = float(score)
            if self._is_flagged(score):
                flagged.append(feature)

        return DriftResult(
            metric=self._metric,
            per_feature=per_feature,
            flagged_features=sorted(flagged),
            threshold=self._threshold,
            details={
                "n_current": len(results),
                "n_baseline": len(baseline_results),
                "n_features_checked": len(per_feature),
                "skipped_missing_in_current": sorted(missing_in_current),
                "skipped_missing_in_baseline": sorted(missing_in_baseline),
                "skipped_low_samples": sorted(skipped_low_samples),
            },
        )

    def _importance_vectors(self, results: list[Any]) -> dict[str, list[float]]:
        """Extract per-feature importance as a list of values across samples."""
        vectors: dict[str, list[float]] = {}
        for r in results:
            if not hasattr(r, "feature_importance") or r.feature_importance is None:
                continue
            for k, v in r.feature_importance.items():
                vectors.setdefault(k, []).append(abs(float(v)))
        return vectors

    def _psi(self, baseline: np.ndarray, current: np.ndarray) -> float:
        eps = 1e-8
        n_min = min(len(baseline), len(current))
        
        # Adaptive bins: sqrt(n) rule, capped at configured max
        n_bins = min(self._n_bins, max(3, int(np.sqrt(n_min))))
        
        # Use quantile-based bins instead of linear — handles skewed distributions
        all_vals = np.concatenate([baseline, current])
        bins = np.quantile(all_vals, np.linspace(0, 1, n_bins + 1))
        bins = np.unique(bins)  # remove duplicate edges from constant regions
        
        if len(bins) < 3:
            return 0.0  # can't compute PSI with too few unique bin edges
        
        baseline_pct = np.histogram(baseline, bins=bins)[0] / len(baseline)
        current_pct = np.histogram(current, bins=bins)[0] / len(current)

        baseline_pct = np.clip(baseline_pct, eps, None)
        current_pct = np.clip(current_pct, eps, None)

        return float(np.sum((current_pct - baseline_pct) * np.log(current_pct / baseline_pct)))
    def _ks(self, baseline: np.ndarray, current: np.ndarray) -> float:
        """
        Kolmogorov-Smirnov statistic.
        Returns the KS statistic (0–1), NOT the p-value.
        Higher values indicate greater distributional difference.
        Flag threshold should be set in [0.1, 0.3] range for typical use.
        """
        stat, _ = ks_2samp(baseline, current)
        return float(stat)

    def _is_flagged(self, score: float) -> bool:
        return score > self._threshold