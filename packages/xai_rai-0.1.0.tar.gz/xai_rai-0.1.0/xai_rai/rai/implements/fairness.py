from __future__ import annotations

from typing import Any, Optional

import numpy as np
from numpy.typing import NDArray

from ..analyzers.base import BaseRAIAnalyzer
from ..results import FairnessResult
from ..utils import validate_results, validate_labels, get_prediction_class

# Optional dep — only required if this analyzer is actually used
try:
    from fairlearn.metrics import demographic_parity_difference, equalized_odds_difference
    _FAIRLEARN_AVAILABLE = True
except ImportError:
    _FAIRLEARN_AVAILABLE = False


class TabularFairnessAnalyzer(BaseRAIAnalyzer):
    """
    Fairness analysis for tabular classification models.

    Computes demographic parity difference and optionally equalized odds
    difference using fairlearn. Flags results that exceed the threshold.

    Extend for image/NLP by subclassing BaseRAIAnalyzer directly — the
    metric computation will differ but the output contract (FairnessResult)
    stays the same.
    """

    SUPPORTED_METRICS = ("demographic_parity", "equalized_odds")

    def __init__(
        self,
        metric: str = "demographic_parity",
        threshold: float = 0.1,
    ):
        if metric not in self.SUPPORTED_METRICS:
            raise ValueError(
                f"metric must be one of {self.SUPPORTED_METRICS}, got '{metric}'"
            )
        if not _FAIRLEARN_AVAILABLE:
            raise ImportError(
                "fairlearn is required for fairness analysis. "
                "Install it with: pip install fairlearn"
            )
        self._metric = metric
        self._threshold = threshold

    @property
    def modality(self) -> str:
        return "tabular"

    def analyze(
        self,
        results: list[Any],
        y_true: NDArray,
        sensitive_features: NDArray,
        **kwargs,
    ) -> FairnessResult:
        """
        Parameters
        ----------
        results : list[XAIResult]
        y_true : array-like of ground-truth labels
        sensitive_features : array-like of group labels (e.g. gender, race)
        """
        validate_results(results, min_samples=2)
        y_true = np.asarray(y_true)
        sensitive_features = np.asarray(sensitive_features)
        if len(sensitive_features) != len(results):
            raise ValueError(
                f"sensitive_features length {len(sensitive_features)} "
                f"doesn't match results length {len(results)}"
            )
        validate_labels(y_true, results)

        y_pred = self._extract_predictions(results)
        print("\n=== FAIRNESS DEBUG ===")
        print("y_pred distribution:", np.unique(y_pred, return_counts=True))
        print("y_true distribution:", np.unique(y_true, return_counts=True))

        for group in np.unique(sensitive_features):
            mask = sensitive_features == group

            print(f"{group} positive prediction rate:",
                np.mean(y_pred[mask] == 1))

            print(f"{group} accuracy:",
                np.mean(y_true[mask] == y_pred[mask]))

        if self._metric == "demographic_parity":
            value = float(demographic_parity_difference(
                y_true=y_true,
                y_pred=y_pred,
                sensitive_features=sensitive_features,
            ))
            metric_name = "demographic_parity_difference"
        else:
            value = float(equalized_odds_difference(
                y_true=y_true,
                y_pred=y_pred,
                sensitive_features=sensitive_features,
            ))
            metric_name = "equalized_odds_difference"

        group_scores = self._per_group_accuracy(y_true, y_pred, sensitive_features)

        return FairnessResult(
            metric_name=metric_name,
            value=value,
            flagged=abs(value) > self._threshold,
            threshold=self._threshold,
            group_scores=group_scores,
            details={"metric": self._metric, "n_samples": len(results)},
        )

    def _extract_predictions(self, results: list[Any]) -> NDArray:
        preds = []
        for r in results:
            pred = get_prediction_class(r.prediction)
            pred = np.asarray(pred)  # normalise to ndarray first

            if pred.ndim == 1 and len(pred) > 1:
                # probability vector → argmax to get class index
                pred = int(np.argmax(pred))
            else:
                # scalar or 0-d array → extract the value directly
                pred = int(pred.item())

            preds.append(pred)
        return np.array(preds, dtype=int)
    def _per_group_accuracy(
        self,
        y_true: NDArray,
        y_pred: NDArray,
        sensitive_features: NDArray,
    ) -> dict[str, float]:
        scores = {}
        for group in np.unique(sensitive_features):
            mask = sensitive_features == group
            if mask.sum() == 0:
                continue
            scores[str(group)] = float(np.mean(y_true[mask] == y_pred[mask]))
        return scores