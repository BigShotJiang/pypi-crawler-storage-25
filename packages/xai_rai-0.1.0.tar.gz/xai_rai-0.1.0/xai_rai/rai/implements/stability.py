from __future__ import annotations

from typing import Any, Optional

import numpy as np
from numpy.typing import NDArray

from ..analyzers.base import BaseRAIAnalyzer
from ..results import StabilityResult
from ..utils import validate_results


class TabularStabilityAnalyzer(BaseRAIAnalyzer):
    """
    Robustness/stability analysis for tabular models.

    Perturbs a sample with calibrated Gaussian noise and measures how much
    the feature importance distribution shifts. A stable model should produce
    similar explanations for near-identical inputs.

    Noise is scaled relative to each feature's standard deviation in the
    background data so the perturbation is meaningful regardless of feature
    scale (age vs income vs binary flags all get appropriate noise levels).
    """

    def __init__(
        self,
        noise_factor: float = 0.01,
        trials: int = 10,
        threshold: float = 0.1,
        background_data: Optional[NDArray] = None,
    ):
        """
        Parameters
        ----------
        noise_factor : float
            Fraction of each feature's std to use as noise scale.
        trials : int
            Number of noisy perturbations per sample.
        threshold : float
            Mean normalized importance diff above which result is flagged.
        background_data : NDArray, optional
            Used to compute per-feature std for noise calibration.
            If None, absolute noise_factor is used instead.
        """
        if trials < 1:
            raise ValueError("trials must be >= 1")
        if noise_factor <= 0:
            raise ValueError("noise_factor must be > 0")

        self._noise_factor = noise_factor
        self._trials = trials
        self._threshold = threshold
        self._feature_stds: Optional[NDArray] = None

        if background_data is not None:
            bg = np.asarray(background_data)
            stds = np.std(bg, axis=0)
            # Avoid zero-std features (constant columns) blowing up
            self._feature_stds = np.where(stds > 0, stds, 1.0)

    @property
    def modality(self) -> str:
        return "tabular"

    def analyze(
        self,
        results: list[Any],        # unused — stability is per-sample via client
        client: Any,
        x: NDArray,
        **kwargs,
    ) -> StabilityResult:
        """
        Parameters
        ----------
        results : list[XAIResult]
            Not used directly; kept for interface consistency.
        client : XAIClient
            The XAI client used to generate explanations.
        x : NDArray
            Single sample (1D or 2D with batch dim 1) to test stability on.
        """
        x = np.asarray(x).flatten()

        base_result = client.explain(x.reshape(1, -1))
        base_importance = base_result.results[0].feature_importance  # ✅

        if not base_importance:
            raise ValueError(
                "Base explanation returned empty feature_importance. "
                "Check that the XAI client is configured correctly."
            )

        noise_scale = (
            self._feature_stds * self._noise_factor
            if self._feature_stds is not None
            else np.full(x.shape, self._noise_factor)
        )

        per_trial_diffs: list[dict[str, float]] = []

        for _ in range(self._trials):
            x_noisy = x + np.random.normal(0, noise_scale, size=x.shape)
            noisy_result = client.explain(x_noisy.reshape(1, -1))
            noisy_importance = noisy_result.results[0].feature_importance

            trial_diff = {
                k: abs(base_importance.get(k, 0.0) - noisy_importance.get(k, 0.0))
                for k in base_importance
            }
            per_trial_diffs.append(trial_diff)

        MIN_IMPORTANCE = 0.02 # ignore features with negligible base importance

        per_feature_diff = {
            k: float(np.mean([t.get(k, 0.0) for t in per_trial_diffs]))
            / max(abs(base_importance.get(k, 1.0)), MIN_IMPORTANCE)
            for k in base_importance
            if abs(base_importance.get(k, 0.0)) >= MIN_IMPORTANCE  # skip near-zero features
        }

        mean_diff = float(np.mean(list(per_feature_diff.values())))
        std_diff  = float(np.std(list(per_feature_diff.values())))

        return StabilityResult(
            mean_diff=mean_diff,
            std_diff=std_diff,
            flagged=mean_diff > self._threshold,
            threshold=self._threshold,
            per_feature_diff=per_feature_diff,
            trials=self._trials,
        )