"""
reports.py — Typed dataclasses for all RAI audit outputs.

All report objects are intentionally serialisable to dict/JSON so they can be
persisted directly by AuditLogger without custom encoders.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Fairness
# ---------------------------------------------------------------------------

@dataclass
class GroupMetrics:
    """Per-group classification metrics."""
    group: str
    n_samples: int
    positive_rate: float                      # P(ŷ=1 | group)
    true_positive_rate: Optional[float]       # recall — None if no labels supplied
    false_positive_rate: Optional[float]      # None if no labels supplied
    mean_confidence: float


@dataclass
class FairnessReport:
    """
    Fairness audit results.

    Attributes
    ----------
    group_metrics     : Per-group metrics list.
    demographic_parity_diff : max(positive_rate) - min(positive_rate).
    disparate_impact_ratio  : min / max positive-rate ratio (≥0.8 is typically
                              the "4/5ths rule" threshold).
    equalized_odds_diff     : max TPR gap across groups (None without labels).
    flagged               : True if any metric breaches a threshold.
    threshold_violations  : Human-readable list of violations.
    """
    group_metrics: List[GroupMetrics]
    demographic_parity_diff: float
    disparate_impact_ratio: float
    equalized_odds_diff: Optional[float]
    flagged: bool
    threshold_violations: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Stability
# ---------------------------------------------------------------------------

@dataclass
class PerturbationResult:
    """Outcome of a single perturbation trial."""
    strategy: str           # "synonym_swap" | "char_noise" | "shuffle"
    perturbed_text: str
    original_pred: int
    perturbed_pred: int
    label_flip: bool
    confidence_delta: float


@dataclass
class StabilityReport:
    """
    Stability audit results for a batch of texts.

    Attributes
    ----------
    per_sample_results  : Perturbation details per sample.
    flip_rate           : Fraction of samples where label changed under ≥1 perturbation.
    mean_confidence_delta : Average |conf_original - conf_perturbed|.
    consistency_score   : 1 - flip_rate (higher is better).
    flagged             : True if consistency_score < threshold.
    """
    per_sample_results: List[List[PerturbationResult]]   # [sample][perturbation]
    flip_rate: float
    mean_confidence_delta: float
    consistency_score: float
    flagged: bool

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Drift
# ---------------------------------------------------------------------------

@dataclass
class DriftReport:
    """
    Distribution drift report comparing current batch to reference window.

    Attributes
    ----------
    psi                 : Population Stability Index over label distribution.
                          <0.1 no drift, 0.1–0.25 moderate, >0.25 significant.
    js_divergence       : Jensen-Shannon divergence (0–1).
    feature_drift_score : Mean cosine distance between reference/current
                          TF-IDF centroids (None if tfidf unavailable).
    reference_size      : Number of samples in reference window.
    current_size        : Number of samples in current batch.
    flagged             : True if PSI > threshold.
    drift_level         : "none" | "moderate" | "significant".
    """
    psi: float
    js_divergence: float
    feature_drift_score: Optional[float]
    reference_size: int
    current_size: int
    flagged: bool
    drift_level: str       # "none" | "moderate" | "significant"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Toxicity
# ---------------------------------------------------------------------------

@dataclass
class ToxicityResult:
    """Per-sample toxicity scores from a single scorer."""
    scorer_name: str
    score: float            # 0–1
    flagged: bool
    categories: Dict[str, float] = field(default_factory=dict)   # optional sub-scores


@dataclass
class ToxicityReport:
    """
    Toxicity scan results for a batch of texts.

    Attributes
    ----------
    per_sample          : List[List[ToxicityResult]] — per scorer, per sample.
    max_scores          : Max toxicity score per sample across scorers.
    flagged_indices     : Sample indices that exceeded the threshold.
    flagged             : True if any sample was flagged.
    scorer_names        : Which scorers ran.
    """
    per_sample: List[List[ToxicityResult]]
    max_scores: List[float]
    flagged_indices: List[int]
    flagged: bool
    scorer_names: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Combined
# ---------------------------------------------------------------------------

@dataclass
class RAIReport:
    """
    Top-level Responsible AI report attached to every adapter call.

    Attributes
    ----------
    timestamp       : Unix epoch of the call.
    adapter_provider: Provider name from the underlying adapter.
    texts_count     : Number of texts processed.
    fairness        : FairnessReport (None if auditor not configured).
    stability       : StabilityReport (None if auditor not configured).
    drift           : DriftReport (None if monitor not configured).
    toxicity        : ToxicityReport (None if scanner not configured).
    any_flagged     : True if ANY sub-report raised a flag.
    summary         : Human-readable summary string.
    """
    timestamp: float
    adapter_provider: str
    texts_count: int
    fairness: Optional[FairnessReport] = None
    stability: Optional[StabilityReport] = None
    drift: Optional[DriftReport] = None
    toxicity: Optional[ToxicityReport] = None

    @property
    def any_flagged(self) -> bool:
        return any([
            self.fairness and self.fairness.flagged,
            self.stability and self.stability.flagged,
            self.drift and self.drift.flagged,
            self.toxicity and self.toxicity.flagged,
        ])

    @property
    def summary(self) -> str:
        parts = []
        if self.fairness:
            status = "⚠ FLAGGED" if self.fairness.flagged else "✓ OK"
            parts.append(f"Fairness {status} (DP_diff={self.fairness.demographic_parity_diff:.3f})")
        if self.stability:
            status = "⚠ FLAGGED" if self.stability.flagged else "✓ OK"
            parts.append(f"Stability {status} (consistency={self.stability.consistency_score:.3f})")
        if self.drift:
            status = "⚠ FLAGGED" if self.drift.flagged else "✓ OK"
            parts.append(f"Drift {status} (PSI={self.drift.psi:.3f}, level={self.drift.drift_level})")
        if self.toxicity:
            status = "⚠ FLAGGED" if self.toxicity.flagged else "✓ OK"
            n = len(self.toxicity.flagged_indices)
            parts.append(f"Toxicity {status} ({n}/{self.texts_count} samples flagged)")
        return " | ".join(parts) if parts else "No auditors configured."

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "adapter_provider": self.adapter_provider,
            "texts_count": self.texts_count,
            "any_flagged": self.any_flagged,
            "summary": self.summary,
            "fairness": self.fairness.to_dict() if self.fairness else None,
            "stability": self.stability.to_dict() if self.stability else None,
            "drift": self.drift.to_dict() if self.drift else None,
            "toxicity": self.toxicity.to_dict() if self.toxicity else None,
        }