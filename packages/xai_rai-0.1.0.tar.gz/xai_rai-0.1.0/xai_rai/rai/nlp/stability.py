"""
stability.py — StabilityAuditor

Tests prediction robustness by applying controlled perturbations and measuring
consistency of outputs.  Plugs directly into ``predict_proba_batch`` from
BaseTextAdapter (or any callable with the same signature).

Perturbation strategies
-----------------------
synonym_swap   : Replace random tokens with a near-synonym (lightweight wordnet
                 lookup; gracefully degrades to character-level if nltk absent).
char_noise     : Insert, delete or swap a character in random tokens.
shuffle        : Randomly reorder sentence tokens (within a window).

Usage
-----
    auditor = StabilityAuditor(
        strategies=["synonym_swap", "char_noise"],
        n_perturbations=3,          # trials per strategy per sample
        flip_threshold=0.15,        # flag if flip_rate > 15 %
        confidence_delta_threshold=0.10,
        max_workers=4,
    )
    report = auditor.audit(
        texts=["text1", "text2"],
        predict_fn=adapter.predict_proba_batch,
        original_predictions=proba_matrix,   # optional; avoids re-inferencing
    )
"""

from __future__ import annotations

import logging
import random
import string
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, List, Optional, Sequence

import numpy as np

from .reports import PerturbationResult, StabilityReport

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional: nltk synonyms
# ---------------------------------------------------------------------------
try:
    from nltk.corpus import wordnet as _wn  # type: ignore
    _HAS_WORDNET = True
except ImportError:
    _HAS_WORDNET = False


def _synonym(word: str) -> str:
    """Return a synonym for *word*, or the word itself if none found."""
    if not _HAS_WORDNET:
        return word
    synsets = _wn.synsets(word)
    for syn in synsets:
        for lemma in syn.lemmas():
            candidate = lemma.name().replace("_", " ")
            if candidate.lower() != word.lower():
                return candidate
    return word


# ---------------------------------------------------------------------------
# Perturbation functions
# ---------------------------------------------------------------------------

def _perturb_synonym_swap(text: str, rng: random.Random) -> str:
    tokens = text.split()
    if not tokens:
        return text
    idx = rng.randint(0, len(tokens) - 1)
    tokens[idx] = _synonym(tokens[idx])
    return " ".join(tokens)


def _perturb_char_noise(text: str, rng: random.Random) -> str:
    tokens = text.split()
    if not tokens:
        return text
    idx = rng.randint(0, len(tokens) - 1)
    word = tokens[idx]
    if len(word) < 2:
        return text
    op = rng.choice(["insert", "delete", "swap"])
    pos = rng.randint(0, len(word) - 1)
    if op == "insert":
        char = rng.choice(string.ascii_lowercase)
        word = word[:pos] + char + word[pos:]
    elif op == "delete":
        word = word[:pos] + word[pos + 1:]
    else:  # swap
        if pos < len(word) - 1:
            lst = list(word)
            lst[pos], lst[pos + 1] = lst[pos + 1], lst[pos]
            word = "".join(lst)
    tokens[idx] = word
    return " ".join(tokens)


def _perturb_shuffle(text: str, rng: random.Random, window: int = 5) -> str:
    tokens = text.split()
    if len(tokens) < 3:
        return text
    start = rng.randint(0, max(0, len(tokens) - window))
    chunk = tokens[start: start + window]
    rng.shuffle(chunk)
    tokens[start: start + window] = chunk
    return " ".join(tokens)


_STRATEGY_FN = {
    "synonym_swap": _perturb_synonym_swap,
    "char_noise":   _perturb_char_noise,
    "shuffle":      _perturb_shuffle,
}


# ---------------------------------------------------------------------------
# StabilityAuditor
# ---------------------------------------------------------------------------

class StabilityAuditor:
    """
    Perturbation-based stability auditor.

    Parameters
    ----------
    strategies            : List of perturbation strategy names to apply.
    n_perturbations       : Number of trials per strategy per sample.
    flip_threshold        : Flag if flip_rate exceeds this.
    confidence_delta_threshold : Flag if mean |Δconf| exceeds this.
    max_workers           : Thread pool size for parallel perturbation calls.
    seed                  : RNG seed for reproducibility (None = random).
    """

    def __init__(
        self,
        strategies: Optional[List[str]] = None,
        n_perturbations: int = 3,
        flip_threshold: float = 0.15,
        confidence_delta_threshold: float = 0.10,
        max_workers: int = 4,
        seed: Optional[int] = None,
    ) -> None:
        self.strategies = strategies or ["synonym_swap", "char_noise"]
        self.n_perturbations = n_perturbations
        self.flip_threshold = flip_threshold
        self.confidence_delta_threshold = confidence_delta_threshold
        self.max_workers = max_workers
        self._rng = random.Random(seed)

        unknown = set(self.strategies) - set(_STRATEGY_FN)
        if unknown:
            raise ValueError(f"Unknown perturbation strategies: {unknown}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def audit(
        self,
        texts: Sequence[str],
        predict_fn: Callable[[List[str]], np.ndarray],
        original_predictions: Optional[np.ndarray] = None,
    ) -> StabilityReport:
        """
        Run stability audit.

        Parameters
        ----------
        texts                : Input texts.
        predict_fn           : Callable matching BaseTextAdapter.predict_proba_batch
                               signature: List[str] -> ndarray (n, n_classes).
        original_predictions : Pre-computed probabilities for *texts*.  If None,
                               predict_fn is called once to obtain them.

        Returns
        -------
        StabilityReport
        """
        texts = list(texts)
        n = len(texts)

        if original_predictions is None:
            original_predictions = predict_fn(texts)
        original_predictions = np.asarray(original_predictions, dtype=float)
        if original_predictions.ndim == 1:
            original_predictions = np.column_stack(
                [1 - original_predictions, original_predictions]
            )

        orig_labels = np.argmax(original_predictions, axis=1)
        orig_conf = np.max(original_predictions, axis=1)

        # Build all perturbation jobs: (sample_idx, strategy, trial_idx)
        jobs = [
            (i, strat, trial)
            for i in range(n)
            for strat in self.strategies
            for trial in range(self.n_perturbations)
        ]

        # Generate perturbed texts
        perturbed_texts_map: dict = {}   # (i, strat, trial) -> str
        for i, strat, trial in jobs:
            fn = _STRATEGY_FN[strat]
            perturbed_texts_map[(i, strat, trial)] = fn(texts[i], self._rng)

        # Batch all perturbed texts into a single predict_fn call for efficiency
        all_keys = list(perturbed_texts_map.keys())
        all_perturbed = [perturbed_texts_map[k] for k in all_keys]

        try:
            all_preds = predict_fn(all_perturbed)
        except Exception as exc:
            logger.error("StabilityAuditor: predict_fn failed during perturbation: %s", exc)
            return self._empty_report(n)

        all_preds = np.asarray(all_preds, dtype=float)
        if all_preds.ndim == 1:
            all_preds = np.column_stack([1 - all_preds, all_preds])

        # Map predictions back
        pred_map: dict = {}
        for j, key in enumerate(all_keys):
            pred_map[key] = all_preds[j]

        # Build per-sample results
        per_sample_results: List[List[PerturbationResult]] = [[] for _ in range(n)]
        for (i, strat, trial), key in zip(jobs, all_keys):
            pert_pred_proba = pred_map[key]
            pert_label = int(np.argmax(pert_pred_proba))
            pert_conf = float(np.max(pert_pred_proba))
            per_sample_results[i].append(PerturbationResult(
                strategy=strat,
                perturbed_text=perturbed_texts_map[key],
                original_pred=int(orig_labels[i]),
                perturbed_pred=pert_label,
                label_flip=pert_label != int(orig_labels[i]),
                confidence_delta=abs(pert_conf - float(orig_conf[i])),
            ))

        # Aggregate
        any_flip = [
            any(r.label_flip for r in sample_results)
            for sample_results in per_sample_results
        ]
        flip_rate = float(np.mean(any_flip))
        all_deltas = [r.confidence_delta for sr in per_sample_results for r in sr]
        mean_conf_delta = float(np.mean(all_deltas)) if all_deltas else 0.0
        consistency_score = 1.0 - flip_rate

        flagged = (
            flip_rate > self.flip_threshold
            or mean_conf_delta > self.confidence_delta_threshold
        )

        if flagged:
            logger.warning(
                "StabilityAuditor: flagged — flip_rate=%.3f, mean_conf_delta=%.3f",
                flip_rate, mean_conf_delta,
            )

        return StabilityReport(
            per_sample_results=per_sample_results,
            flip_rate=flip_rate,
            mean_confidence_delta=mean_conf_delta,
            consistency_score=consistency_score,
            flagged=flagged,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _empty_report(n: int) -> StabilityReport:
        return StabilityReport(
            per_sample_results=[[] for _ in range(n)],
            flip_rate=0.0,
            mean_confidence_delta=0.0,
            consistency_score=1.0,
            flagged=False,
        )