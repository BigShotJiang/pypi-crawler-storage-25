"""
validation_reports.py — Typed dataclasses for RAI validation outputs.

These are comparison reports only — they never replace the primary RAIReport.
They answer: "does our custom code agree with the framework?"
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class MetricComparison:
    """
    Side-by-side comparison of a single scalar metric.

    Attributes
    ----------
    metric_name   : Human-readable metric name.
    custom_value  : Value from your custom RAI code.
    framework_value : Value from the external framework.
    delta         : abs(custom - framework).
    within_tolerance : True if delta <= tolerance.
    tolerance     : The threshold used.
    """
    metric_name: str
    custom_value: float
    framework_value: float
    delta: float
    within_tolerance: bool
    tolerance: float


@dataclass
class FairnessValidationReport:
    """
    Fairlearn vs custom FairnessAuditor comparison.

    Attributes
    ----------
    comparisons           : Per-metric comparison list.
    fairlearn_dp_diff     : Demographic parity difference per Fairlearn.
    fairlearn_eo_diff     : Equalized odds difference per Fairlearn (None if no labels).
    fairlearn_group_rates : Per-group selection rates from Fairlearn MetricFrame.
    any_divergence        : True if any metric exceeds tolerance.
    divergence_details    : Human-readable list of diverging metrics.
    framework_version     : fairlearn version used.
    """
    comparisons: List[MetricComparison]
    fairlearn_dp_diff: float
    fairlearn_eo_diff: Optional[float]
    fairlearn_group_rates: Dict[str, float]
    any_divergence: bool
    divergence_details: List[str]
    framework_version: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DriftValidationReport:
    """
    Evidently vs custom DriftMonitor comparison.

    Attributes
    ----------
    comparisons             : Per-metric comparison list.
    evidently_dataset_drift : Whether Evidently flagged dataset drift.
    evidently_drift_share   : Fraction of features Evidently flagged as drifted.
    evidently_psi           : PSI computed by Evidently (None if not available).
    evidently_per_feature   : Per-feature drift details from Evidently.
    any_divergence          : True if verdict (flagged/not) disagrees OR metric
                              delta exceeds tolerance.
    divergence_details      : Human-readable list of divergences.
    framework_version       : evidently version used.
    """
    comparisons: List[MetricComparison]
    evidently_dataset_drift: bool
    evidently_drift_share: float
    evidently_psi: Optional[float]
    evidently_per_feature: Dict[str, Any]
    any_divergence: bool
    divergence_details: List[str]
    framework_version: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ValidationReport:
    """
    Top-level validation report comparing custom RAI outputs against frameworks.

    Attributes
    ----------
    fairness  : FairnessValidationReport (None if not run).
    drift     : DriftValidationReport (None if not run).
    any_divergence : True if ANY sub-report found a divergence.
    summary   : Human-readable one-liner.
    """
    fairness: Optional[FairnessValidationReport] = None
    drift: Optional[DriftValidationReport] = None

    @property
    def any_divergence(self) -> bool:
        return any([
            self.fairness and self.fairness.any_divergence,
            self.drift and self.drift.any_divergence,
        ])

    @property
    def summary(self) -> str:
        parts = []
        if self.fairness:
            status = "⚠ DIVERGED" if self.fairness.any_divergence else "✓ AGREES"
            parts.append(f"Fairness {status} (Fairlearn)")
        if self.drift:
            status = "⚠ DIVERGED" if self.drift.any_divergence else "✓ AGREES"
            parts.append(f"Drift {status} (Evidently)")
        return " | ".join(parts) if parts else "No validators ran."

    def to_dict(self) -> Dict[str, Any]:
        return {
            "any_divergence": self.any_divergence,
            "summary": self.summary,
            "fairness": self.fairness.to_dict() if self.fairness else None,
            "drift": self.drift.to_dict() if self.drift else None,
        }