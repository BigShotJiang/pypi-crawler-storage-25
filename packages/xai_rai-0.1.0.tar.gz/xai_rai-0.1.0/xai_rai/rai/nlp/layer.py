"""
layer.py — ResponsibleAILayer

Single entry-point that wraps any BaseTextAdapter (or any object exposing
``predict_proba_batch``) and intercepts each call to run the configured
RAI auditors.

Design
------
- Zero-overhead when no auditors are configured.
- Each auditor is independently optional.
- The wrapped adapter's full interface is preserved via __getattr__ delegation.
- The last RAIReport is always accessible at ``.last_report``.
- An optional AuditLogger persists all reports.

Usage
-----
    from text_adapter import TextAdapter
    from responsible_ai import (
        ResponsibleAILayer, FairnessAuditor, StabilityAuditor,
        DriftMonitor, ToxicityScanner, RegexScorer, AuditLogger,
    )

    adapter = TextAdapter.from_provider("huggingface", ...)

    rai = ResponsibleAILayer(
        adapter=adapter,
        fairness_auditor=FairnessAuditor(protected_attribute="gender"),
        stability_auditor=StabilityAuditor(strategies=["char_noise", "synonym_swap"]),
        drift_monitor=DriftMonitor(reference_window_size=200),
        toxicity_scanner=ToxicityScanner(scorers=[RegexScorer()]),
        audit_logger=AuditLogger("logs/rai_audit.jsonl"),
        raise_on_flag=False,       # set True to hard-block flagged calls
    )

    # Warm up drift monitor (once, on a representative baseline)
    baseline_preds = adapter.predict_proba_batch(baseline_texts)
    rai.drift_monitor.update(baseline_texts, baseline_preds)

    # Normal usage — identical to calling adapter directly
    proba = rai.predict_proba_batch(
        texts,
        group_labels=["group_a", "group_b", ...],   # optional, for fairness
        true_labels=[1, 0, ...],                     # optional, for equalized odds
    )
    print(rai.last_report.summary)
"""

from __future__ import annotations

import logging
import time
from typing import List, Optional, Sequence

import numpy as np

from .audit import AuditLogger
from .drift import DriftMonitor
from .fairness import FairnessAuditor
from .reports import RAIReport
from .stability import StabilityAuditor
from .toxicity import ToxicityScanner

logger = logging.getLogger(__name__)


class RAIFlagError(RuntimeError):
    """Raised when ``raise_on_flag=True`` and any auditor flags a batch."""


class ResponsibleAILayer:
    """
    Production-grade RAI wrapper around any predict_proba_batch-compatible adapter.

    Parameters
    ----------
    adapter             : The underlying text adapter.  Must expose
                          ``predict_proba_batch(texts) -> ndarray``.
    fairness_auditor    : Optional FairnessAuditor.
    stability_auditor   : Optional StabilityAuditor.
    drift_monitor       : Optional DriftMonitor.
    toxicity_scanner    : Optional ToxicityScanner.
    audit_logger        : Optional AuditLogger for persistence.
    raise_on_flag       : If True, raise RAIFlagError when any flag fires.
    update_drift_window : If True, automatically update the drift monitor's
                          reference window after each call.
    """

    def __init__(
        self,
        adapter,
        fairness_auditor: Optional[FairnessAuditor] = None,
        stability_auditor: Optional[StabilityAuditor] = None,
        drift_monitor: Optional[DriftMonitor] = None,
        toxicity_scanner: Optional[ToxicityScanner] = None,
        audit_logger: Optional[AuditLogger] = None,
        raise_on_flag: bool = False,
        update_drift_window: bool = True,
    ) -> None:
        self._adapter = adapter
        self.fairness_auditor = fairness_auditor
        self.stability_auditor = stability_auditor
        self.drift_monitor = drift_monitor
        self.toxicity_scanner = toxicity_scanner
        self.audit_logger = audit_logger
        self.raise_on_flag = raise_on_flag
        self.update_drift_window = update_drift_window

        self.last_report: Optional[RAIReport] = None

    # ------------------------------------------------------------------
    # Core interception
    # ------------------------------------------------------------------

    def predict_proba_batch(
        self,
        texts: Sequence[str],
        group_labels: Optional[Sequence[str]] = None,
        true_labels: Optional[Sequence[int]] = None,
    ) -> np.ndarray:
        """
        Intercept predict_proba_batch, run all configured auditors, return
        the probability matrix unchanged.

        Extra keyword arguments
        -----------------------
        group_labels : Protected group membership per sample (for fairness).
        true_labels  : Ground-truth labels per sample (for equalized-odds).
        """
        texts = list(texts)

        # 1. Forward to underlying adapter
        proba = self._adapter.predict_proba_batch(texts)
        proba = np.asarray(proba, dtype=float)

        # 2. Determine provider name
        provider = getattr(self._adapter, "provider", None) or type(self._adapter).__name__

        report = RAIReport(
            timestamp=time.time(),
            adapter_provider=str(provider),
            texts_count=len(texts),
        )

        # 3. Toxicity (stateless — runs first, cheapest gate)
        if self.toxicity_scanner is not None:
            try:
                report.toxicity = self.toxicity_scanner.scan(texts)
            except Exception as exc:
                logger.error("ResponsibleAILayer: toxicity scan failed: %s", exc)

        # 4. Fairness (requires group_labels)
        if self.fairness_auditor is not None:
            if group_labels is None:
                logger.debug(
                    "ResponsibleAILayer: FairnessAuditor configured but no "
                    "group_labels provided — skipping fairness audit."
                )
            else:
                try:
                    report.fairness = self.fairness_auditor.audit(
                        texts=texts,
                        predictions=proba,
                        group_labels=group_labels,
                        true_labels=true_labels,
                    )
                except Exception as exc:
                    logger.error("ResponsibleAILayer: fairness audit failed: %s", exc)

        # 5. Stability (calls adapter again with perturbed texts)
        if self.stability_auditor is not None:
            try:
                report.stability = self.stability_auditor.audit(
                    texts=texts,
                    predict_fn=self._adapter.predict_proba_batch,
                    original_predictions=proba,
                )
            except Exception as exc:
                logger.error("ResponsibleAILayer: stability audit failed: %s", exc)

        # 6. Drift (stateful — requires pre-warmed reference window)
        if self.drift_monitor is not None:
            if self.drift_monitor.reference_size == 0:
                logger.warning(
                    "ResponsibleAILayer: DriftMonitor reference window is empty. "
                    "Seeding with current batch — no drift check this call."
                )
                self.drift_monitor.update(texts, proba)
            else:
                try:
                    report.drift = self.drift_monitor.check(texts, proba)
                    if self.update_drift_window:
                        self.drift_monitor.update(texts, proba)
                except Exception as exc:
                    logger.error("ResponsibleAILayer: drift check failed: %s", exc)

        # 7. Persist
        self.last_report = report
        if self.audit_logger is not None:
            self.audit_logger.log(report)

        # 8. Logging summary
        if report.any_flagged:
            logger.warning("ResponsibleAILayer: %s", report.summary)
        else:
            logger.debug("ResponsibleAILayer: %s", report.summary)

        # 9. Optionally hard-block
        if self.raise_on_flag and report.any_flagged:
            raise RAIFlagError(
                f"RAI flags raised: {report.summary}"
            )

        return proba

    # ------------------------------------------------------------------
    # Passthrough delegation
    # ------------------------------------------------------------------

    def __getattr__(self, name: str):
        """Delegate any attribute not on the layer to the underlying adapter."""
        return getattr(self._adapter, name)

    def __repr__(self) -> str:
        parts = []
        if self.fairness_auditor:
            parts.append("fairness")
        if self.stability_auditor:
            parts.append("stability")
        if self.drift_monitor:
            parts.append("drift")
        if self.toxicity_scanner:
            parts.append("toxicity")
        modules = ", ".join(parts) if parts else "none"
        provider = getattr(self._adapter, "provider", type(self._adapter).__name__)
        return f"<ResponsibleAILayer provider={provider} modules=[{modules}]>"

    # ------------------------------------------------------------------
    # Convenience: quick audit without intercepting adapter
    # ------------------------------------------------------------------

    def audit_texts(
        self,
        texts: Sequence[str],
        predictions: np.ndarray,
        group_labels: Optional[Sequence[str]] = None,
        true_labels: Optional[Sequence[int]] = None,
    ) -> RAIReport:
        """
        Run all auditors against pre-computed predictions without calling
        the adapter.  Useful for post-hoc analysis.

        Parameters
        ----------
        texts       : Input texts.
        predictions : Pre-computed probability matrix (n, n_classes).
        group_labels: Optional protected group labels.
        true_labels : Optional ground-truth labels.

        Returns
        -------
        RAIReport
        """
        texts = list(texts)
        predictions = np.asarray(predictions, dtype=float)
        provider = getattr(self._adapter, "provider", type(self._adapter).__name__)

        report = RAIReport(
            timestamp=time.time(),
            adapter_provider=str(provider),
            texts_count=len(texts),
        )

        if self.toxicity_scanner:
            report.toxicity = self.toxicity_scanner.scan(texts)

        if self.fairness_auditor and group_labels is not None:
            report.fairness = self.fairness_auditor.audit(
                texts=texts,
                predictions=predictions,
                group_labels=group_labels,
                true_labels=true_labels,
            )

        if self.stability_auditor:
            report.stability = self.stability_auditor.audit(
                texts=texts,
                predict_fn=self._adapter.predict_proba_batch,
                original_predictions=predictions,
            )

        if self.drift_monitor and self.drift_monitor.reference_size > 0:
            report.drift = self.drift_monitor.check(texts, predictions)

        self.last_report = report
        if self.audit_logger:
            self.audit_logger.log(report)

        return report