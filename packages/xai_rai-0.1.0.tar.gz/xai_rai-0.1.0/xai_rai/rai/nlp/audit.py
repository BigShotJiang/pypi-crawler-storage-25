"""
audit.py — AuditLogger

Writes RAIReport objects to a structured jsonlines file.
Thread-safe.  Zero-cost when disabled.

Usage
-----
    logger = AuditLogger(path="rai_audit.jsonl", enabled=True)
    logger.log(report)

    # Replay / query
    for record in logger.iter_records():
        if record["any_flagged"]:
            print(record["summary"])
"""

from __future__ import annotations

import json
import logging
import threading
from pathlib import Path
from typing import Generator, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .reports import RAIReport

_log = logging.getLogger(__name__)


class AuditLogger:
    """
    Append-only structured jsonlines audit logger.

    Parameters
    ----------
    path    : Path to the .jsonl file.  Created if it doesn't exist.
    enabled : Set to False to make all operations no-ops (useful in testing).
    """

    def __init__(self, path: str = "rai_audit.jsonl", enabled: bool = True) -> None:
        self.path = Path(path)
        self.enabled = enabled
        self._lock = threading.Lock()

        if enabled:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            _log.info("AuditLogger: writing to %s", self.path.resolve())

    def log(self, report: "RAIReport") -> None:
        """Append *report* to the audit log as a single JSON line."""
        if not self.enabled:
            return
        try:
            record = report.to_dict()
            line = json.dumps(record, default=_json_fallback) + "\n"
            with self._lock:
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(line)
        except Exception as exc:
            _log.error("AuditLogger: failed to write record: %s", exc)

    def iter_records(self) -> Generator[dict, None, None]:
        """Iterate over all audit records as dicts."""
        if not self.path.exists():
            return
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError as exc:
                        _log.warning("AuditLogger: malformed record skipped: %s", exc)

    def flagged_records(self) -> Generator[dict, None, None]:
        """Yield only records where any_flagged is True."""
        for record in self.iter_records():
            if record.get("any_flagged"):
                yield record

    def tail(self, n: int = 20) -> list:
        """Return the last *n* records."""
        return list(self.iter_records())[-n:]

    def summary_stats(self) -> dict:
        """Aggregate statistics over all logged records."""
        total = 0
        flagged = 0
        providers: dict = {}

        for rec in self.iter_records():
            total += 1
            if rec.get("any_flagged"):
                flagged += 1
            provider = rec.get("adapter_provider", "unknown")
            providers[provider] = providers.get(provider, 0) + 1

        return {
            "total_records": total,
            "flagged_records": flagged,
            "flag_rate": flagged / total if total else 0.0,
            "providers": providers,
        }


def _json_fallback(obj):
    """Handle numpy scalars and other non-serialisable types."""
    import numpy as np  # local import; numpy always available in this stack
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    return str(obj)