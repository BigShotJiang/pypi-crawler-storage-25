"""
responsible_ai — Production-grade RAI layer for BaseTextAdapter.

Modules
-------
fairness   : FairnessAuditor   — demographic parity, equalized odds, disparate impact
stability  : StabilityAuditor  — perturbation robustness, consistency score
drift      : DriftMonitor      — PSI, JS divergence, feature-space drift (ring buffer)
toxicity   : ToxicityScanner   — pluggable scorers (Detoxify, Perspective, Regex)
layer      : ResponsibleAILayer — single-entry wrapper around BaseTextAdapter
reports    : RAIReport, * dataclasses
audit      : AuditLogger       — structured jsonlines audit trail
"""

from .layer import ResponsibleAILayer
from .reports import RAIReport, FairnessReport, StabilityReport, DriftReport, ToxicityReport
from .fairness import FairnessAuditor
from .stability import StabilityAuditor
from .drift import DriftMonitor
from .toxicity import ToxicityScanner, RegexScorer
from .audit import AuditLogger
from .rai_validator import RAIValidator, ValidationDivergenceError
from .fairlearn_validator import FairlearnValidator
from .evidently_validator import EvidentlyValidator

__all__ = [
    "ResponsibleAILayer",
    "RAIReport",
    "FairnessReport",
    "StabilityReport",
    "DriftReport",
    "ToxicityReport",
    "FairnessAuditor",
    "StabilityAuditor",
    "DriftMonitor",
    "ToxicityScanner",
    "RegexScorer",
    "AuditLogger",
]
