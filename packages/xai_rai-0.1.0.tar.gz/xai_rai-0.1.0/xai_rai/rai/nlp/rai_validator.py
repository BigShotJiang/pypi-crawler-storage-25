"""
rai_validator.py — RAIValidator

Orchestrates FairlearnValidator and EvidentlyValidator into a single
comparison call. Sits completely outside the main RAI pipeline —
it reads RAIReport outputs but never writes to them.

Design principles
-----------------
1. Model-agnostic: accepts only numpy arrays, lists, and your RAIReport.
   No adapter, no explainer, no internal state crosses the boundary.
2. Internals-agnostic: custom code math is treated as a black box.
   The validator only reads .demographic_parity_diff, .flagged, etc.
3. Opt-in: each framework validator is independently optional.
   If fairlearn isn't installed, skip fairness validation silently.
4. Non-blocking: validation failures never raise in production.
   Use raise_on_divergence=True only in CI/testing.

Usage
-----
    from responsible_ai.rai_validator import RAIValidator

    validator = RAIValidator(
        dp_tolerance=0.02,
        eo_tolerance=0.02,
        psi_tolerance=0.05,
        verdict_must_agree=True,
        raise_on_divergence=False,     # set True in CI
    )

    # After running your main RAI layer:
    val_report = validator.validate(
        custom_report=rai.last_report,
        predictions=proba,
        group_labels=group_labels,
        true_labels=true_labels,
        reference_predictions=ref_preds,   # for drift
        current_predictions=proba,         # same as above in typical usage
        reference_texts=ref_texts,
        current_texts=texts,
        label_names=["NEGATIVE", "POSITIVE"],
    )

    print(val_report.summary)
    if val_report.any_divergence:
        for d in (val_report.fairness.divergence_details or []):
            print("  Fairness:", d)
        for d in (val_report.drift.divergence_details or []):
            print("  Drift:", d)
"""

from __future__ import annotations

import logging
from typing import List, Optional, Sequence

import numpy as np

from .validation_reports import ValidationReport

logger = logging.getLogger(__name__)


class ValidationDivergenceError(RuntimeError):
    """Raised when raise_on_divergence=True and a divergence is detected."""


class RAIValidator:
    """
    Orchestrates framework-based validation against your custom RAI outputs.

    Parameters
    ----------
    dp_tolerance        : Demographic parity diff tolerance vs Fairlearn.
    eo_tolerance        : Equalized odds diff tolerance vs Fairlearn.
    psi_tolerance       : PSI tolerance vs Evidently.
    verdict_must_agree  : Flag if Evidently and custom drift verdicts disagree.
    raise_on_divergence : Raise ValidationDivergenceError on any divergence.
                          Useful in CI gates. Default False.
    skip_fairness       : Disable fairness validation entirely.
    skip_drift          : Disable drift validation entirely.
    """

    def __init__(
        self,
        dp_tolerance: float = 0.02,
        eo_tolerance: float = 0.02,
        psi_tolerance: float = 0.05,
        verdict_must_agree: bool = True,
        raise_on_divergence: bool = False,
        skip_fairness: bool = False,
        skip_drift: bool = False,
    ) -> None:
        self.dp_tolerance = dp_tolerance
        self.eo_tolerance = eo_tolerance
        self.psi_tolerance = psi_tolerance
        self.verdict_must_agree = verdict_must_agree
        self.raise_on_divergence = raise_on_divergence
        self.skip_fairness = skip_fairness
        self.skip_drift = skip_drift

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(
        self,
        custom_report,
        predictions: np.ndarray,
        # Fairness inputs
        group_labels: Optional[Sequence[str]] = None,
        true_labels: Optional[Sequence[int]] = None,
        # Drift inputs
        reference_predictions: Optional[np.ndarray] = None,
        current_predictions: Optional[np.ndarray] = None,
        reference_texts: Optional[Sequence[str]] = None,
        current_texts: Optional[Sequence[str]] = None,
        label_names: Optional[List[str]] = None,
    ) -> ValidationReport:
        """
        Run all configured framework validators and return a ValidationReport.

        Parameters
        ----------
        custom_report         : RAIReport from your ResponsibleAILayer.
        predictions           : Probability matrix (n, n_classes) for current batch.
        group_labels          : Protected group per sample (for fairness).
        true_labels           : Ground-truth labels (for equalized odds).
        reference_predictions : Reference window probabilities (for drift).
        current_predictions   : Current batch probabilities (for drift).
                                Defaults to `predictions` if not supplied.
        reference_texts       : Reference texts for text-feature drift.
        current_texts         : Current texts.
        label_names           : Class names e.g. ["NEGATIVE", "POSITIVE"].

        Returns
        -------
        ValidationReport
        """
        val_report = ValidationReport()

        # ── Fairness validation ───────────────────────────────────────
        if (
            not self.skip_fairness
            and custom_report.fairness is not None
            and group_labels is not None
        ):
            val_report.fairness = self._run_fairness(
                predictions=predictions,
                group_labels=group_labels,
                true_labels=true_labels,
                custom_fairness=custom_report.fairness,
            )

        # ── Drift validation ──────────────────────────────────────────
        if (
            not self.skip_drift
            and custom_report.drift is not None
        ):
            ref_preds = (
                np.asarray(reference_predictions)
                if reference_predictions is not None
                else predictions    # fallback — less meaningful but won't crash
            )
            cur_preds = (
                np.asarray(current_predictions)
                if current_predictions is not None
                else predictions
            )
            val_report.drift = self._run_drift(
                reference_predictions=ref_preds,
                current_predictions=cur_preds,
                reference_texts=reference_texts,
                current_texts=current_texts,
                label_names=label_names,
                custom_drift=custom_report.drift,
            )

        # ── Log summary ───────────────────────────────────────────────
        if val_report.any_divergence:
            logger.warning("RAIValidator: %s", val_report.summary)
        else:
            logger.info("RAIValidator: %s", val_report.summary)

        # ── Optional hard raise ───────────────────────────────────────
        if self.raise_on_divergence and val_report.any_divergence:
            raise ValidationDivergenceError(
                f"RAI validation divergence detected: {val_report.summary}"
            )

        return val_report

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _run_fairness(self, predictions, group_labels, true_labels, custom_fairness):
        try:
            from .fairlearn_validator import FairlearnValidator
            v = FairlearnValidator(
                dp_tolerance=self.dp_tolerance,
                eo_tolerance=self.eo_tolerance,
            )
            return v.validate(
                predictions=predictions,
                group_labels=group_labels,
                true_labels=true_labels,
                custom_report=custom_fairness,
            )
        except ImportError:
            logger.warning(
                "RAIValidator: fairlearn not installed — skipping fairness validation. "
                "Install with: pip install fairlearn"
            )
            return None
        except Exception as exc:
            logger.error("RAIValidator: fairness validation failed: %s", exc)
            return None

    def _run_drift(
        self, reference_predictions, current_predictions,
        reference_texts, current_texts, label_names, custom_drift,
    ):
        try:
            from .evidently_validator import EvidentlyValidator
            v = EvidentlyValidator(
                psi_tolerance=self.psi_tolerance,
                verdict_must_agree=self.verdict_must_agree,
            )
            return v.validate(
                reference_predictions=reference_predictions,
                current_predictions=current_predictions,
                custom_report=custom_drift,
                reference_texts=reference_texts,
                current_texts=current_texts,
                label_names=label_names,
            )
        except ImportError:
            logger.warning(
                "RAIValidator: evidently not installed — skipping drift validation. "
                "Install with: pip install evidently"
            )
            return None
        except Exception as exc:
            logger.error("RAIValidator: drift validation failed: %s", exc)
            return None