"""
toxicity.py — ToxicityScanner

Pluggable toxicity detection layer.  Ships with two built-in scorers:

RegexScorer
    Zero-dependency regex baseline.  Fast, no GPU required.  Suitable for
    CI gates and environments without ML inference.

DetoxifyScorer
    Wraps the ``detoxify`` library (https://github.com/unitaryai/detoxify).
    Supports ``original``, ``unbiased``, and ``multilingual`` model variants.
    Install: ``pip install detoxify``

PerspectiveScorer
    Calls the Google Perspective API.
    Requires an API key.
    Install: ``pip install google-api-python-client``

Custom scorers
--------------
Subclass ``BaseToxicityScorer`` and implement ``score_batch``.

Usage
-----
    scanner = ToxicityScanner(
        scorers=[RegexScorer(), DetoxifyScorer(model_type="original")],
        threshold=0.70,
        agg="max",          # "max" | "mean" — how to combine scorer scores
    )
    report = scanner.scan(texts)
"""

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Sequence

import numpy as np

from .reports import ToxicityReport, ToxicityResult

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Base scorer
# ---------------------------------------------------------------------------

class BaseToxicityScorer(ABC):
    """Abstract base class for toxicity scorers."""

    name: str = "base"

    @abstractmethod
    def score_batch(self, texts: List[str]) -> List[ToxicityResult]:
        """
        Score a batch of texts.

        Parameters
        ----------
        texts : Input texts.

        Returns
        -------
        List[ToxicityResult] — one per text, using self.name as scorer_name.
        """


# ---------------------------------------------------------------------------
# RegexScorer — zero-dependency baseline
# ---------------------------------------------------------------------------

# Lightweight, deliberately coarse pattern set.
# In production, replace/extend with a curated vocabulary list.
_TOXIC_PATTERNS = [
    r"\b(hate|kill|murder|abuse|assault|harass)\b",
    r"\b(stupid|idiot|moron|imbecile|retard)\b",
    r"\b(slur|racist|bigot|sexist)\b",
    r"\b(porn|explicit|obscen)\b",
    r"\b(terroris[mt]|extremis[mt]|radicali[sz])\b",
]
_SEVERE_PATTERNS = [
    r"\b(suicide|self.?harm|self.?injury)\b",
    r"\b(bomb|explosive|detonate)\b",
    r"\b(rape|molest|pedophil)\b",
]

_COMPILED = [(re.compile(p, re.IGNORECASE), 0.5) for p in _TOXIC_PATTERNS]
_COMPILED_SEVERE = [(re.compile(p, re.IGNORECASE), 0.9) for p in _SEVERE_PATTERNS]


class RegexScorer(BaseToxicityScorer):
    """
    Regex-based toxicity scorer.

    Parameters
    ----------
    threshold : Per-sample score above which a sample is flagged.
    """

    name = "regex"

    def __init__(self, threshold: float = 0.50) -> None:
        self.threshold = threshold

    def score_batch(self, texts: List[str]) -> List[ToxicityResult]:
        results = []
        for text in texts:
            max_score = 0.0
            categories: Dict[str, float] = {}

            for pattern, score in _COMPILED:
                if pattern.search(text):
                    max_score = max(max_score, score)
                    categories[pattern.pattern] = score

            for pattern, score in _COMPILED_SEVERE:
                if pattern.search(text):
                    max_score = max(max_score, score)
                    categories[pattern.pattern] = score

            results.append(ToxicityResult(
                scorer_name=self.name,
                score=max_score,
                flagged=max_score >= self.threshold,
                categories=categories,
            ))
        return results


# ---------------------------------------------------------------------------
# DetoxifyScorer — wraps the detoxify library
# ---------------------------------------------------------------------------

class DetoxifyScorer(BaseToxicityScorer):
    """
    Scorer backed by the ``detoxify`` library.

    Parameters
    ----------
    model_type : "original" | "unbiased" | "multilingual"
    threshold  : Flag threshold (0–1).
    device     : "cpu" | "cuda" (passed to detoxify).
    """

    name = "detoxify"

    def __init__(
        self,
        model_type: str = "original",
        threshold: float = 0.70,
        device: str = "cpu",
    ) -> None:
        self.threshold = threshold
        try:
            from detoxify import Detoxify  # type: ignore
            self._model = Detoxify(model_type, device=device)
            logger.info("DetoxifyScorer: loaded model_type=%s on %s", model_type, device)
        except ImportError:
            raise ImportError(
                "DetoxifyScorer requires the 'detoxify' package. "
                "Install with: pip install detoxify"
            )

    def score_batch(self, texts: List[str]) -> List[ToxicityResult]:
        raw = self._model.predict(texts)
        # raw is dict: {category: List[float]}
        n = len(texts)
        results = []
        for i in range(n):
            categories = {k: float(v[i]) for k, v in raw.items()}
            score = max(categories.values()) if categories else 0.0
            results.append(ToxicityResult(
                scorer_name=self.name,
                score=score,
                flagged=score >= self.threshold,
                categories=categories,
            ))
        return results


# ---------------------------------------------------------------------------
# PerspectiveScorer — Google Perspective API
# ---------------------------------------------------------------------------

class PerspectiveScorer(BaseToxicityScorer):
    """
    Scorer backed by the Google Perspective API.

    Parameters
    ----------
    api_key       : Google Cloud API key with Perspective API enabled.
    threshold     : Flag threshold.
    attributes    : List of Perspective attributes to request.
    requests_per_second : Rate-limit guard (Perspective free tier = 1 QPS).
    """

    name = "perspective"

    _DEFAULT_ATTRIBUTES = [
        "TOXICITY", "SEVERE_TOXICITY", "INSULT", "THREAT",
        "IDENTITY_ATTACK", "PROFANITY",
    ]

    def __init__(
        self,
        api_key: str,
        threshold: float = 0.70,
        attributes: Optional[List[str]] = None,
        requests_per_second: float = 1.0,
    ) -> None:
        self.threshold = threshold
        self.attributes = attributes or self._DEFAULT_ATTRIBUTES
        self._rps = requests_per_second

        try:
            from googleapiclient import discovery  # type: ignore
            self._client = discovery.build(
                "commentanalyzer",
                "v1alpha1",
                developerKey=api_key,
                discoveryServiceUrl=(
                    "https://commentanalyzer.googleapis.com/$discovery/rest"
                    "?version=v1alpha1"
                ),
                static_discovery=False,
            )
        except ImportError:
            raise ImportError(
                "PerspectiveScorer requires google-api-python-client. "
                "Install with: pip install google-api-python-client"
            )

    def score_batch(self, texts: List[str]) -> List[ToxicityResult]:
        import time
        results = []
        delay = 1.0 / self._rps

        for text in texts:
            try:
                body = {
                    "comment": {"text": text},
                    "requestedAttributes": {attr: {} for attr in self.attributes},
                    "languages": ["en"],
                }
                resp = (
                    self._client.comments()
                    .analyze(body=body)
                    .execute()
                )
                scores_raw = resp.get("attributeScores", {})
                categories = {
                    k: float(v["summaryScore"]["value"])
                    for k, v in scores_raw.items()
                }
                score = categories.get("TOXICITY", 0.0)
                results.append(ToxicityResult(
                    scorer_name=self.name,
                    score=score,
                    flagged=score >= self.threshold,
                    categories=categories,
                ))
            except Exception as exc:
                logger.warning("PerspectiveScorer: API call failed for text: %s", exc)
                results.append(ToxicityResult(
                    scorer_name=self.name,
                    score=0.0,
                    flagged=False,
                    categories={"error": str(exc)},
                ))
            time.sleep(delay)

        return results


# ---------------------------------------------------------------------------
# ToxicityScanner — orchestrator
# ---------------------------------------------------------------------------

class ToxicityScanner:
    """
    Orchestrates one or more toxicity scorers over a batch of texts.

    Parameters
    ----------
    scorers   : List of BaseToxicityScorer instances.
    threshold : Default flag threshold (overridden per-scorer if they set their own).
    agg       : How to combine scores across scorers — "max" or "mean".
    """

    def __init__(
        self,
        scorers: Optional[List[BaseToxicityScorer]] = None,
        threshold: float = 0.70,
        agg: str = "max",
    ) -> None:
        self.scorers = scorers or [RegexScorer(threshold=threshold)]
        self.threshold = threshold
        self.agg = agg
        if agg not in ("max", "mean"):
            raise ValueError("agg must be 'max' or 'mean'")

    def scan(self, texts: Sequence[str]) -> ToxicityReport:
        """
        Run all scorers on *texts* and aggregate results.

        Parameters
        ----------
        texts : Input texts.

        Returns
        -------
        ToxicityReport
        """
        texts = list(texts)
        n = len(texts)

        # per_sample[i] = list of results from each scorer for sample i
        per_sample: List[List[ToxicityResult]] = [[] for _ in range(n)]

        for scorer in self.scorers:
            try:
                batch_results = scorer.score_batch(texts)
            except Exception as exc:
                logger.error(
                    "ToxicityScanner: scorer '%s' failed: %s", scorer.name, exc
                )
                batch_results = [
                    ToxicityResult(
                        scorer_name=scorer.name,
                        score=0.0,
                        flagged=False,
                        categories={"error": str(exc)},
                    )
                    for _ in range(n)
                ]
            for i, result in enumerate(batch_results):
                per_sample[i].append(result)

        # Aggregate scores per sample
        max_scores: List[float] = []
        for sample_results in per_sample:
            sample_scores = [r.score for r in sample_results]
            if not sample_scores:
                max_scores.append(0.0)
            elif self.agg == "max":
                max_scores.append(max(sample_scores))
            else:
                max_scores.append(float(np.mean(sample_scores)))

        flagged_indices = [i for i, s in enumerate(max_scores) if s >= self.threshold]
        flagged = len(flagged_indices) > 0

        if flagged:
            logger.warning(
                "ToxicityScanner: %d/%d samples flagged (threshold=%.2f)",
                len(flagged_indices), n, self.threshold,
            )

        return ToxicityReport(
            per_sample=per_sample,
            max_scores=max_scores,
            flagged_indices=flagged_indices,
            flagged=flagged,
            scorer_names=[s.name for s in self.scorers],
        )