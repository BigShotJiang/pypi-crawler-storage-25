"""
fairness.py — FairnessAuditor

Computes group-level fairness metrics on model predictions.

Supported metrics
-----------------
- Demographic Parity Difference  (DP_diff): max - min positive rate across groups.
- Disparate Impact Ratio         (DI):       min / max positive rate (4/5ths rule).
- Equalized Odds Difference      (EO_diff):  max |TPR_i - TPR_j| across group pairs.
                                              Requires ground-truth labels.
- False Positive Rate Difference             Same, for FPR.

Usage
-----
    auditor = FairnessAuditor(
        protected_attribute="gender",
        dp_threshold=0.10,      # flag if DP_diff > 0.10
        di_threshold=0.80,      # flag if DI < 0.80 (4/5ths rule)
        eo_threshold=0.10,      # flag if EO_diff > 0.10
    )
    report = auditor.audit(
        texts=["...", "..."],
        predictions=np.array([[0.1, 0.9], [0.7, 0.3]]),   # (n, n_classes) proba
        group_labels=["male", "female", ...],               # len == n
        true_labels=[1, 0, ...],                            # optional
    )
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Dict, List, Optional, Sequence

import numpy as np

from .reports import FairnessReport, GroupMetrics

logger = logging.getLogger(__name__)


class FairnessAuditor:
    """
    Model-agnostic fairness auditor.

    Parameters
    ----------
    protected_attribute : Descriptive name for the protected attribute (for logging).
    positive_class_idx  : Which column in the proba matrix is the "positive" class.
                          Defaults to -1 (last column, binary convention).
    dp_threshold        : Demographic Parity Difference threshold to flag.
    di_threshold        : Disparate Impact Ratio lower-bound to flag (4/5ths = 0.80).
    eo_threshold        : Equalized Odds Difference threshold (requires true_labels).
    min_group_size      : Groups smaller than this are excluded and warned.
    """

    def __init__(
        self,
        protected_attribute: str = "group",
        positive_class_idx: int = -1,
        dp_threshold: float = 0.10,
        di_threshold: float = 0.80,
        eo_threshold: float = 0.10,
        min_group_size: int = 5,
    ) -> None:
        self.protected_attribute = protected_attribute
        self.positive_class_idx = positive_class_idx
        self.dp_threshold = dp_threshold
        self.di_threshold = di_threshold
        self.eo_threshold = eo_threshold
        self.min_group_size = min_group_size

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def audit(
        self,
        texts: Sequence[str],
        predictions: np.ndarray,          # (n, n_classes)
        group_labels: Sequence[str],
        true_labels: Optional[Sequence[int]] = None,
    ) -> FairnessReport:
        """
        Run fairness audit.

        Parameters
        ----------
        texts       : Input texts (used for logging only).
        predictions : Probability matrix (n_samples, n_classes).
        group_labels: Protected group membership per sample.
        true_labels : Optional ground-truth labels for equalized-odds computation.

        Returns
        -------
        FairnessReport
        """
        predictions = np.asarray(predictions, dtype=float)
        if predictions.ndim == 1:
            predictions = np.column_stack([1 - predictions, predictions])

        pos_idx = self.positive_class_idx % predictions.shape[1]
        pos_proba = predictions[:, pos_idx]
        pred_labels = np.argmax(predictions, axis=1)

        groups: Dict[str, List[int]] = defaultdict(list)
        for i, g in enumerate(group_labels):
            groups[str(g)].append(i)

        # Filter small groups
        valid_groups = {
            g: idxs for g, idxs in groups.items()
            if len(idxs) >= self.min_group_size
        }
        skipped = set(groups) - set(valid_groups)
        if skipped:
            logger.warning(
                "FairnessAuditor: groups %s have < %d samples — excluded from audit.",
                skipped, self.min_group_size
            )

        if len(valid_groups) < 2:
            logger.warning("FairnessAuditor: fewer than 2 valid groups — skipping audit.")
            return self._empty_report()

        # Compute per-group metrics
        group_metric_list: List[GroupMetrics] = []
        pos_rates: List[float] = []

        tpr_map: Dict[str, float] = {}
        fpr_map: Dict[str, float] = {}

        for group, idxs in valid_groups.items():
            idxs_arr = np.array(idxs)
            grp_pos_proba = pos_proba[idxs_arr]
            grp_preds = pred_labels[idxs_arr]
            positive_rate = float(np.mean(grp_preds == pos_idx))
            mean_conf = float(np.mean(grp_pos_proba))
            pos_rates.append(positive_rate)

            tpr, fpr = None, None
            if true_labels is not None:
                grp_true = np.array(true_labels)[idxs_arr]
                pos_mask = grp_true == pos_idx
                neg_mask = ~pos_mask
                tpr = float(np.mean(grp_preds[pos_mask] == pos_idx)) if pos_mask.any() else None
                fpr = float(np.mean(grp_preds[neg_mask] == pos_idx)) if neg_mask.any() else None
                if tpr is not None:
                    tpr_map[group] = tpr
                if fpr is not None:
                    fpr_map[group] = fpr

            group_metric_list.append(GroupMetrics(
                group=group,
                n_samples=len(idxs),
                positive_rate=positive_rate,
                true_positive_rate=tpr,
                false_positive_rate=fpr,
                mean_confidence=mean_conf,
            ))

        # Aggregate metrics
        dp_diff = float(max(pos_rates) - min(pos_rates))
        di_ratio = float(min(pos_rates) / max(pos_rates)) if max(pos_rates) > 0 else 0.0

        eo_diff: Optional[float] = None
        if len(tpr_map) >= 2:
            tpr_vals = list(tpr_map.values())
            eo_diff = float(max(tpr_vals) - min(tpr_vals))

        # Threshold violations
        violations: List[str] = []
        if dp_diff > self.dp_threshold:
            violations.append(
                f"Demographic Parity Difference {dp_diff:.3f} > threshold {self.dp_threshold}"
            )
        if di_ratio < self.di_threshold:
            violations.append(
                f"Disparate Impact Ratio {di_ratio:.3f} < threshold {self.di_threshold} (4/5ths rule)"
            )
        if eo_diff is not None and eo_diff > self.eo_threshold:
            violations.append(
                f"Equalized Odds Difference {eo_diff:.3f} > threshold {self.eo_threshold}"
            )

        flagged = len(violations) > 0
        if flagged:
            for v in violations:
                logger.warning("FairnessAuditor [%s]: %s", self.protected_attribute, v)

        return FairnessReport(
            group_metrics=group_metric_list,
            demographic_parity_diff=dp_diff,
            disparate_impact_ratio=di_ratio,
            equalized_odds_diff=eo_diff,
            flagged=flagged,
            threshold_violations=violations,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _empty_report() -> FairnessReport:
        return FairnessReport(
            group_metrics=[],
            demographic_parity_diff=0.0,
            disparate_impact_ratio=1.0,
            equalized_odds_diff=None,
            flagged=False,
            threshold_violations=["Insufficient group data for audit"],
        )