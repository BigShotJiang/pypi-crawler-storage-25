"""
evidently_validator.py — EvidentlyValidator

Independently detects distribution drift using Evidently AI's DataDriftPreset
and compares the verdict and PSI against your custom DriftMonitor outputs.

Boundary contract (model-agnostic, internals-agnostic)
-------------------------------------------------------
Accepts ONLY plain numpy arrays, lists, and your DriftReport.
No adapter objects, no explainer objects, no RAIReport cross this boundary.

Tested against evidently 0.7.x (uses evidently.legacy.* module paths).
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

from .validation_reports import DriftValidationReport, MetricComparison

logger = logging.getLogger(__name__)


class EvidentlyValidator:
    """
    Validates custom DriftMonitor outputs against Evidently AI.

    Evidently works on tabular DataFrames, so we construct one from the
    prediction probability columns plus optional text-derived numeric features
    (token count, char count). Raw texts never enter Evidently — fully
    model-agnostic.

    Parameters
    ----------
    psi_tolerance       : Max allowed delta in PSI before flagging divergence.
    verdict_must_agree  : Flag divergence when custom and Evidently disagree on
                          whether drift occurred.
    drift_share_threshold : Evidently flags dataset drift when this fraction of
                          features drifts. Default 0.5 (Evidently default).
    stattest            : Stattest per feature. Default "psi".
    stattest_threshold  : Score threshold for the stattest.
    """

    def __init__(
        self,
        psi_tolerance: float = 0.05,
        verdict_must_agree: bool = True,
        drift_share_threshold: float = 0.5,
        stattest: str = "psi",
        stattest_threshold: float = 0.1,
    ) -> None:
        self.psi_tolerance = psi_tolerance
        self.verdict_must_agree = verdict_must_agree
        self.drift_share_threshold = drift_share_threshold
        self.stattest = stattest
        self.stattest_threshold = stattest_threshold
        self._evidently_version = self._get_version()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(
        self,
        reference_predictions: np.ndarray,
        current_predictions: np.ndarray,
        custom_report,
        reference_texts: Optional[Sequence[str]] = None,
        current_texts: Optional[Sequence[str]] = None,
        label_names: Optional[List[str]] = None,
    ) -> DriftValidationReport:
        """
        Run Evidently DataDriftPreset and compare against custom_report.

        Parameters
        ----------
        reference_predictions : Probability matrix for reference window.
        current_predictions   : Probability matrix for current batch.
        custom_report         : DriftReport from your DriftMonitor.
        reference_texts       : Optional texts → numeric length features only.
        current_texts         : Optional texts for current batch.
        label_names           : Class names for column labelling.
        """
        try:
            import pandas as pd
            # Evidently 0.7.x restructured to evidently.legacy.*
            from evidently.legacy.report import Report                   # type: ignore
            from evidently.legacy.metric_preset import DataDriftPreset   # type: ignore
        except ImportError:
            raise ImportError(
                "evidently>=0.7 is required for validation. "
                "Install with: pip install evidently"
            )

        ref_preds = np.asarray(reference_predictions, dtype=float)
        cur_preds = np.asarray(current_predictions, dtype=float)

        n_classes = ref_preds.shape[1] if ref_preds.ndim == 2 else 1
        if label_names is None:
            label_names = [f"class_{i}" for i in range(n_classes)]

        ref_df = self._build_dataframe(ref_preds, reference_texts, label_names, pd)
        cur_df = self._build_dataframe(cur_preds, current_texts, label_names, pd)

        report = Report(metrics=[
            DataDriftPreset(
                stattest=self.stattest,
                stattest_threshold=self.stattest_threshold,
                drift_share=self.drift_share_threshold,
            ),
        ])

        try:
            report.run(reference_data=ref_df, current_data=cur_df)
            result = report.as_dict()
        except Exception as exc:
            logger.error("EvidentlyValidator: report run failed: %s", exc)
            return self._error_report(str(exc))

        ev_dataset_drift, ev_drift_share, ev_per_feature = \
            self._parse_result(result)

        # PSI for primary positive-class column (last label by convention)
        primary_col = label_names[-1]
        ev_psi: Optional[float] = None
        col_data = ev_per_feature.get(primary_col, {})
        if col_data.get("drift_score") is not None:
            ev_psi = float(col_data["drift_score"])

        # ── Compare ───────────────────────────────────────────────────
        comparisons: List[MetricComparison] = []
        divergence_details: List[str] = []

        if ev_psi is not None and custom_report.psi is not None:
            psi_cmp = _make_comparison(
                "psi", custom_report.psi, ev_psi, self.psi_tolerance
            )
            comparisons.append(psi_cmp)
            if not psi_cmp.within_tolerance:
                divergence_details.append(
                    f"PSI — custom={custom_report.psi:.4f} "
                    f"evidently={ev_psi:.4f} Δ={psi_cmp.delta:.4f}"
                )

        if self.verdict_must_agree and custom_report.flagged != ev_dataset_drift:
            divergence_details.append(
                f"Drift verdict — custom={'FLAGGED' if custom_report.flagged else 'OK'} "
                f"evidently={'FLAGGED' if ev_dataset_drift else 'OK'}"
            )

        any_divergence = len(divergence_details) > 0
        if any_divergence:
            for d in divergence_details:
                logger.warning("EvidentlyValidator divergence: %s", d)
        else:
            logger.info("EvidentlyValidator: outputs agree")

        return DriftValidationReport(
            comparisons=comparisons,
            evidently_dataset_drift=ev_dataset_drift,
            evidently_drift_share=ev_drift_share,
            evidently_psi=ev_psi,
            evidently_per_feature=ev_per_feature,
            any_divergence=any_divergence,
            divergence_details=divergence_details,
            framework_version=self._evidently_version,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _build_dataframe(predictions, texts, label_names, pd):
        data: Dict[str, Any] = {}
        if predictions.ndim == 2:
            for i, name in enumerate(label_names):
                data[name] = predictions[:, i]
        else:
            data[label_names[0]] = predictions
        if texts is not None:
            data["text_token_count"] = [len(str(t).split()) for t in texts]
            data["text_char_count"]  = [len(str(t)) for t in texts]
        return pd.DataFrame(data)

    @staticmethod
    def _parse_result(result: dict):
        """
        Parse Evidently 0.7 report dict.
        DataDriftPreset emits two metrics:
          [0] DatasetDriftMetric  → top-level flags
          [1] DataDriftTable      → drift_by_columns with drift_score per col
        """
        dataset_drift = False
        drift_share   = 0.0
        per_feature: Dict[str, Any] = {}

        try:
            for metric in result.get("metrics", []):
                res = metric.get("result", {})

                # Top-level dataset flags (DatasetDriftMetric)
                if "dataset_drift" in res and "drift_by_columns" not in res:
                    dataset_drift = bool(res["dataset_drift"])
                    drift_share   = float(res.get("share_of_drifted_columns", 0.0))

                # Per-column details (DataDriftTable)
                for col, col_data in res.get("drift_by_columns", {}).items():
                    per_feature[col] = {
                        "drifted":     col_data.get("drift_detected", False),
                        "drift_score": col_data.get("drift_score", None),
                        "stattest":    col_data.get("stattest_name", None),
                        "threshold":   col_data.get("stattest_threshold", None),
                    }
        except Exception as exc:
            logger.warning("EvidentlyValidator: result parsing error: %s", exc)

        return dataset_drift, drift_share, per_feature

    def _error_report(self, msg: str) -> DriftValidationReport:
        return DriftValidationReport(
            comparisons=[],
            evidently_dataset_drift=False,
            evidently_drift_share=0.0,
            evidently_psi=None,
            evidently_per_feature={"error": msg},
            any_divergence=False,
            divergence_details=[f"Evidently run failed: {msg}"],
            framework_version=self._evidently_version,
        )

    @staticmethod
    def _get_version() -> str:
        try:
            import evidently
            return evidently.__version__
        except Exception:
            return "unknown"


def _make_comparison(name, custom, framework, tolerance) -> MetricComparison:
    delta = abs(custom - framework)
    return MetricComparison(
        metric_name=name,
        custom_value=custom,
        framework_value=framework,
        delta=delta,
        within_tolerance=delta <= tolerance,
        tolerance=tolerance,
    )