"""
drift.py — DriftMonitor

Detects distribution drift between a reference window and incoming batches.

Metrics
-------
PSI (Population Stability Index)
    Computed over the predicted label distribution.
    <0.10 → no drift, 0.10–0.25 → moderate, >0.25 → significant

Jensen-Shannon Divergence
    Symmetric, bounded [0,1].  Computed over full label probability vectors.

Feature-space drift
    Mean cosine distance between TF-IDF centroids of reference vs current
    texts.  Requires scikit-learn; silently skipped if unavailable.

Reference window
----------------
Maintained as an in-memory ring buffer of configurable size.  Thread-safe.
Automatically seeded on first ``update()`` call.

Usage
-----
    monitor = DriftMonitor(
        reference_window_size=500,
        psi_threshold=0.25,
        js_threshold=0.15,
        feature_drift_threshold=0.30,
    )

    # Warm up with baseline data
    monitor.update(baseline_texts, baseline_predictions)

    # Check new batch
    report = monitor.check(new_texts, new_predictions)
    monitor.update(new_texts, new_predictions)   # slide window forward
"""

from __future__ import annotations

import logging
import threading
from collections import deque
from typing import List, Optional, Sequence

import numpy as np

from .reports import DriftReport

logger = logging.getLogger(__name__)

# Optional TF-IDF
try:
    from sklearn.feature_extraction.text import TfidfVectorizer  # type: ignore
    _HAS_SKLEARN = True
except ImportError:
    _HAS_SKLEARN = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _label_distribution(predictions: np.ndarray, n_classes: int) -> np.ndarray:
    """Normalised count distribution over argmax labels."""
    labels = np.argmax(predictions, axis=1)
    counts = np.bincount(labels, minlength=n_classes).astype(float)
    total = counts.sum()
    return counts / total if total > 0 else counts


def _psi(p_ref: np.ndarray, p_cur: np.ndarray, eps: float = 1e-6) -> float:
    """Population Stability Index."""
    p_ref = np.clip(p_ref, eps, None)
    p_cur = np.clip(p_cur, eps, None)
    return float(np.sum((p_cur - p_ref) * np.log(p_cur / p_ref)))


def _js_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-10) -> float:
    """Jensen-Shannon divergence (base-2, bounded [0,1])."""
    p = p + eps
    q = q + eps
    p /= p.sum()
    q /= q.sum()
    m = 0.5 * (p + q)
    js = 0.5 * (np.sum(p * np.log2(p / m)) + np.sum(q * np.log2(q / m)))
    return float(np.clip(js, 0.0, 1.0))


def _mean_confidence_proba(predictions: np.ndarray) -> np.ndarray:
    """Return mean probability vector across samples."""
    return np.mean(predictions, axis=0)


# ---------------------------------------------------------------------------
# DriftMonitor
# ---------------------------------------------------------------------------

class DriftMonitor:
    """
    Stateful drift monitor with ring-buffer reference window.

    Parameters
    ----------
    reference_window_size    : Max samples to keep in reference window.
    psi_threshold            : PSI above this → flagged (0.25 = significant).
    js_threshold             : JS divergence above this → secondary flag.
    feature_drift_threshold  : Cosine-distance threshold for TF-IDF centroid drift.
    n_classes                : Number of output classes.  Auto-inferred on first update
                               if None.
    """

    def __init__(
        self,
        reference_window_size: int = 500,
        psi_threshold: float = 0.25,
        js_threshold: float = 0.15,
        feature_drift_threshold: float = 0.30,
        n_classes: Optional[int] = None,
    ) -> None:
        self.reference_window_size = reference_window_size
        self.psi_threshold = psi_threshold
        self.js_threshold = js_threshold
        self.feature_drift_threshold = feature_drift_threshold
        self._n_classes = n_classes

        # Ring buffers
        self._pred_buffer: deque = deque(maxlen=reference_window_size)
        self._text_buffer: deque = deque(maxlen=reference_window_size)
        self._tfidf: Optional[object] = None   # fitted TfidfVectorizer
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def reference_size(self) -> int:
        return len(self._pred_buffer)

    def update(
        self,
        texts: Sequence[str],
        predictions: np.ndarray,
    ) -> None:
        """
        Add new samples to the reference window (slides automatically).

        Parameters
        ----------
        texts       : Input texts for feature-space drift tracking.
        predictions : Probability matrix (n_samples, n_classes).
        """
        predictions = np.asarray(predictions, dtype=float)
        if predictions.ndim == 1:
            predictions = np.column_stack([1 - predictions, predictions])

        with self._lock:
            if self._n_classes is None:
                self._n_classes = predictions.shape[1]

            for i in range(len(texts)):
                self._pred_buffer.append(predictions[i])
                self._text_buffer.append(str(texts[i]))

            # Refit TF-IDF on updated window
            if _HAS_SKLEARN and len(self._text_buffer) >= 10:
                try:
                    vec = TfidfVectorizer(max_features=500, sublinear_tf=True)
                    vec.fit(list(self._text_buffer))
                    self._tfidf = vec
                except Exception as exc:
                    logger.debug("DriftMonitor: TF-IDF refit failed: %s", exc)

    def check(
        self,
        texts: Sequence[str],
        predictions: np.ndarray,
    ) -> DriftReport:
        """
        Compare current batch against reference window.

        Parameters
        ----------
        texts       : Incoming texts.
        predictions : Probability matrix (n_samples, n_classes).

        Returns
        -------
        DriftReport

        Raises
        ------
        RuntimeError if the reference window is empty (call ``update`` first).
        """
        predictions = np.asarray(predictions, dtype=float)
        if predictions.ndim == 1:
            predictions = np.column_stack([1 - predictions, predictions])

        with self._lock:
            if not self._pred_buffer:
                raise RuntimeError(
                    "DriftMonitor: reference window is empty. "
                    "Call monitor.update(baseline_texts, baseline_preds) first."
                )
            ref_preds = np.array(list(self._pred_buffer))
            ref_texts = list(self._text_buffer)
            n_classes = self._n_classes or predictions.shape[1]
            tfidf = self._tfidf

        # Label distribution drift
        ref_dist = _label_distribution(ref_preds, n_classes)
        cur_dist = _label_distribution(predictions, n_classes)
        psi = _psi(ref_dist, cur_dist)

        # JS divergence over mean probability vectors
        ref_mean_conf = _mean_confidence_proba(ref_preds)
        cur_mean_conf = _mean_confidence_proba(predictions)
        js = _js_divergence(ref_mean_conf, cur_mean_conf)

        # Feature-space drift via TF-IDF centroids
        feature_drift: Optional[float] = None
        if tfidf is not None:
            try:
                ref_mat = tfidf.transform(ref_texts)
                cur_mat = tfidf.transform(list(texts))
                ref_centroid = np.asarray(ref_mat.mean(axis=0)).flatten()
                cur_centroid = np.asarray(cur_mat.mean(axis=0)).flatten()
                # Cosine distance = 1 - cosine_similarity
                denom = (
                    np.linalg.norm(ref_centroid) * np.linalg.norm(cur_centroid)
                )
                if denom > 0:
                    feature_drift = float(
                        1.0 - np.dot(ref_centroid, cur_centroid) / denom
                    )
            except Exception as exc:
                logger.debug("DriftMonitor: feature drift computation failed: %s", exc)

        # Classify drift level
        if psi < 0.10:
            drift_level = "none"
        elif psi < 0.25:
            drift_level = "moderate"
        else:
            drift_level = "significant"

        flagged = (
            psi > self.psi_threshold
            or js > self.js_threshold
            or (feature_drift is not None and feature_drift > self.feature_drift_threshold)
        )

        if flagged:
            logger.warning(
                "DriftMonitor: flagged — PSI=%.3f, JS=%.3f, feature_drift=%s, level=%s",
                psi, js,
                f"{feature_drift:.3f}" if feature_drift is not None else "N/A",
                drift_level,
            )

        return DriftReport(
            psi=psi,
            js_divergence=js,
            feature_drift_score=feature_drift,
            reference_size=len(ref_preds),
            current_size=len(predictions),
            flagged=flagged,
            drift_level=drift_level,
        )

    def reset(self) -> None:
        """Clear the reference window."""
        with self._lock:
            self._pred_buffer.clear()
            self._text_buffer.clear()
            self._tfidf = None
        logger.info("DriftMonitor: reference window cleared.")