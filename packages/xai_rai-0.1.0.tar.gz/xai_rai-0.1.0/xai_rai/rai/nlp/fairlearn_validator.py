"""
fairlearn_validator.py — FairlearnValidator

Independently recomputes fairness metrics using Fairlearn's MetricFrame
and compares them against your custom FairnessAuditor outputs.

Boundary contract (model-agnostic, internals-agnostic)
-------------------------------------------------------
This module accepts ONLY plain Python/numpy primitives:
    - predictions  : np.ndarray  (n_samples, n_classes) or (n_samples,) binary
    - group_labels : Sequence[str]
    - true_labels  : Optional[Sequence[int]]
    - custom_report: FairnessReport  (read-only, never mutated)

No adapter objects, no explainer objects, no RAIReport ever cross this boundary.
Fairlearn is imported lazily so the rest of the RAI stack works without it.

Usage
-----
    from responsible_ai.fairlearn_validator import FairlearnValidator
    from responsible_ai.fairness import FairnessAuditor

    auditor   = FairnessAuditor(min_group_size=3)
    custom    = auditor.audit(texts, proba, group_labels, true_labels)

    validator = FairlearnValidator(dp_tolerance=0.02, eo_tolerance=0.02)
    val_report = validator.validate(
        predictions=proba,
        group_labels=group_labels,
        true_labels=true_labels,
        custom_report=custom,
    )
    print(val_report.summary if not val_report.any_divergence else val_report.divergence_details)
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Sequence

import numpy as np
from collections import Counter

from .validation_reports import (
    FairnessValidationReport,
    MetricComparison,
)

logger = logging.getLogger(__name__)


class FairlearnValidator:
    """
    Validates custom FairnessAuditor outputs against Fairlearn MetricFrame.

    Parameters
    ----------
    dp_tolerance  : Max allowed delta in demographic parity difference before
                    flagging divergence. Default 0.02 (2 percentage points).
    eo_tolerance  : Max allowed delta in equalized odds difference. Default 0.02.
    positive_class_idx : Which column is the positive class. Default -1 (last).
    """

    def __init__(
        self,
        dp_tolerance: float = 0.02,
        eo_tolerance: float = 0.02,
        positive_class_idx: int = -1,
        min_group_size: int = 5,
    ) -> None:
        self.dp_tolerance = dp_tolerance
        self.eo_tolerance = eo_tolerance
        self.positive_class_idx = positive_class_idx
        self.min_group_size = min_group_size
        self._fairlearn_version = self._get_version()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(
        self,
        predictions: np.ndarray,
        group_labels: Sequence[str],
        true_labels: Optional[Sequence[int]],
        custom_report,                          # FairnessReport — type-hinted loosely
                                                # to avoid circular import
    ) -> FairnessValidationReport:
        """
        Run Fairlearn MetricFrame and compare against custom_report.

        Parameters
        ----------
        predictions   : (n_samples, n_classes) probability matrix.
        group_labels  : Protected group per sample.
        true_labels   : Ground-truth labels (required for equalized odds).
        custom_report : FairnessReport from your FairnessAuditor.

        Returns
        -------
        FairnessValidationReport
        """
        try:
            from fairlearn.metrics import (  # type: ignore
                MetricFrame,
                selection_rate,
                true_positive_rate,
                false_positive_rate,
                demographic_parity_difference,
                equalized_odds_difference,
            )
        except ImportError:
            raise ImportError(
                "fairlearn is required for validation. "
                "Install with: pip install fairlearn"
            )

        predictions = np.asarray(predictions, dtype=float)
        if predictions.ndim == 2:
            pos_idx = self.positive_class_idx % predictions.shape[1]
            y_pred = (np.argmax(predictions, axis=1) == pos_idx).astype(int)
        else:
            y_pred = predictions.astype(int)

        groups = np.array([str(g) for g in group_labels])
        comparisons: List[MetricComparison] = []
        divergence_details: List[str] = []

        # ── Demographic Parity ────────────────────────────────────────
        y_true=np.array(true_labels) if true_labels is not None else y_pred
        fl_dp = float(demographic_parity_difference(
            y_true=y_true,
            y_pred=y_pred,
            sensitive_features=groups,
        ))

        # Per-group selection rates from MetricFrame
        mf_selection = MetricFrame(
            metrics=selection_rate,
            y_true=y_pred,
            y_pred=y_pred,
            sensitive_features=groups,
        )
        group_rates: Dict[str, float] = {
            str(k): float(v)
            for k, v in mf_selection.by_group.items()
        }

        dp_comparison = self._compare(
            "demographic_parity_difference",
            custom_value=custom_report.demographic_parity_diff,
            framework_value=fl_dp,
            tolerance=self.dp_tolerance,
        )
        comparisons.append(dp_comparison)
        if not dp_comparison.within_tolerance:
            divergence_details.append(
                f"DP diff — custom={custom_report.demographic_parity_diff:.4f} "
                f"fairlearn={fl_dp:.4f} Δ={dp_comparison.delta:.4f}"
            )

        # ── Equalized Odds ────────────────────────────────────────────
        fl_eo: Optional[float] = None
        if true_labels is not None:
            y_true = np.array(true_labels)
            try:
                fl_eo = float(equalized_odds_difference(
                    y_true=y_true,
                    y_pred=y_pred,
                    sensitive_features=groups,
                ))
                if custom_report.equalized_odds_diff is not None:
                    eo_comparison = self._compare(
                        "equalized_odds_difference",
                        custom_value=custom_report.equalized_odds_diff,
                        framework_value=fl_eo,
                        tolerance=self.eo_tolerance,
                    )
                    comparisons.append(eo_comparison)
                    if not eo_comparison.within_tolerance:
                        divergence_details.append(
                            f"EO diff — custom={custom_report.equalized_odds_diff:.4f} "
                            f"fairlearn={fl_eo:.4f} Δ={eo_comparison.delta:.4f}"
                        )
            except Exception as exc:
                logger.warning("FairlearnValidator: EO computation failed: %s", exc)

        any_divergence = len(divergence_details) > 0

        if any_divergence:
            for d in divergence_details:
                logger.warning("FairlearnValidator divergence: %s", d)
        else:
            logger.info(
                "FairlearnValidator: all metrics within tolerance "
                "(dp_tol=%.3f, eo_tol=%.3f)",
                self.dp_tolerance, self.eo_tolerance,
            )


        group_counts = Counter(group_labels)
        valid = {g: c for g, c in group_counts.items() if c >= self.min_group_size}
        if len(valid) < 2:
            logger.warning(
                "FairlearnValidator: insufficient group sizes %s — skipping validation.",
                dict(group_counts)
            )
            return FairnessValidationReport(
                comparisons=[],
                fairlearn_dp_diff=None,
                fairlearn_eo_diff=None,
                fairlearn_group_rates={},
                any_divergence=False,
                divergence_details=["Skipped: insufficient group sizes for meaningful audit"],
                framework_version=self._fairlearn_version,
            )

        return FairnessValidationReport(
            comparisons=comparisons,
            fairlearn_dp_diff=fl_dp,
            fairlearn_eo_diff=fl_eo,
            fairlearn_group_rates=group_rates,
            any_divergence=any_divergence,
            divergence_details=divergence_details,
            framework_version=self._fairlearn_version,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _compare(
        metric_name: str,
        custom_value: float,
        framework_value: float,
        tolerance: float,
    ) -> MetricComparison:
        delta = abs(custom_value - framework_value)
        return MetricComparison(
            metric_name=metric_name,
            custom_value=custom_value,
            framework_value=framework_value,
            delta=delta,
            within_tolerance=delta <= tolerance,
            tolerance=tolerance,
        )

    @staticmethod
    def _get_version() -> str:
        try:
            import fairlearn
            return fairlearn.__version__
        except Exception:
            return "unknown"