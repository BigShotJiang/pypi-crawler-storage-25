"""Utility functions for RAI module."""

from typing import Any, Optional
import numpy as np
from numpy.typing import NDArray


def validate_results(
    results: list[Any],
    min_samples: int = 1,
) -> None:
    """Validate that results list meets minimum sample requirement."""
    if not results:
        raise ValueError("Results list cannot be empty")
    if len(results) < min_samples:
        raise ValueError(
            f"Results must contain at least {min_samples} samples, got {len(results)}"
        )


def validate_labels(y_true: NDArray, results: list[Any]) -> None:
    """Validate that labels match the number of results."""
    y_true = np.asarray(y_true)
    if len(y_true) != len(results):
        raise ValueError(
            f"y_true length ({len(y_true)}) must match number of results ({len(results)})"
        )


def get_prediction_class(prediction: Any) -> Any:
    """Extract prediction class from prediction object."""
    if hasattr(prediction, "prediction_class"):
        return prediction.prediction_class
    if isinstance(prediction, dict) and "prediction_class" in prediction:
        return prediction["prediction_class"]
    return prediction


def aggregate_importance(results: list[Any]) -> dict[str, float]:
    """Aggregate feature importance across a batch of results."""
    if not results:
        return {}

    feature_totals: dict[str, list[float]] = {}
    for r in results:
        if not hasattr(r, "feature_importance") or r.feature_importance is None:
            continue
        for feature, importance in r.feature_importance.items():
            feature_totals.setdefault(feature, []).append(abs(float(importance)))

    return {
        feature: float(np.mean(scores))
        for feature, scores in feature_totals.items()
    }
