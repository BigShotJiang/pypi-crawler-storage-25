"""
xai_rai/rai/tti_audit_narrative.py
====================================
Builds a concise natural-language audit report from a TextToImageExplanation.
Output is plain Markdown, suitable for model governance documentation,
compliance logs, or Streamlit rendering.
"""

from __future__ import annotations

from xai_rai.core.tti_config import ALIGNMENT_WARN


def build_audit_narrative(explanation) -> str:
    """
    Compose a Markdown audit report from all tier results.

    Parameters
    ----------
    explanation : TextToImageExplanation

    Returns
    -------
    str — Markdown-formatted audit narrative
    """
    rai   = explanation.rai
    lines = [
        f"# Model Audit Report — {explanation.model_label}",
        f"**Mode**: {explanation.analysis_mode}",
        f'**Prompt**: "{explanation.prompt}"',
        "",
        "## Prompt Alignment",
    ]

    align_status = "✓ PASS" if not rai.alignment_flagged else "⚠ FLAGGED"
    lines.append(
        f"{align_status} — alignment score: {rai.prompt_alignment:.3f} "
        f"(threshold: {ALIGNMENT_WARN})"
    )

    if explanation.caption_delta:
        delta = explanation.caption_delta
        lines += [
            "",
            "## Attribute Injection (BLIP-2 Caption Delta)",
            f'**Generated caption**: "{delta.caption}"',
        ]
        if delta.injected_concepts:
            lines.append(
                f"⚠ INJECTED attributes (in caption, absent from prompt): "
                f"{', '.join(delta.injected_concepts)}"
            )
        else:
            lines.append("✓ No injected attributes detected.")
        if delta.dropped_concepts:
            lines.append(
                f"  Dropped prompt concepts (not rendered): "
                f"{', '.join(delta.dropped_concepts)}"
            )

    if rai.vqa_probes:
        lines += ["", "## VQA Targeted Safety Probes"]
        for p in rai.vqa_probes:
            icon = "🔴 FLAGGED" if p.flagged else "✓ PASS"
            lines.append(
                f"{icon} [{p.concept}] {p.question}  "
                f"→ answer='{p.answer}', confidence={p.confidence:.2f}"
            )
    elif explanation.analysis_mode == "audit":
        lines += [
            "",
            "## VQA Targeted Safety Probes",
            "✓ No upstream risk flags — VQA probes not triggered.",
        ]

    lines += [
        "",
        "## Safety Summary",
        f"NSFW concepts flagged: {rai.nsfw_concepts or 'none'}",
        f"Stereotype concepts:   {rai.stereotype_concepts or 'none'}",
        f"Injected attributes:   {rai.injected_attrs or 'none'}",
        f"Prompt toxicity:       {rai.prompt_toxicity:.3f}",
        f"**Overall flag**:      {'⚠ FLAGGED' if rai.overall_flagged else '✓ CLEAN'}",
    ]

    return "\n".join(lines)