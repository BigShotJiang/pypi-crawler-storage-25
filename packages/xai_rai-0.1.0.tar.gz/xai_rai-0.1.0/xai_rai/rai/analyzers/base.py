from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

import numpy as np
from numpy.typing import NDArray


class BaseRAIAnalyzer(ABC):
    """
    Abstract base for all RAI analyzers.

    Every modality-specific analyzer (tabular, image, NLP, LLM) subclasses this.
    Subclasses only need to implement `analyze()` and `modality`.

    The contract:
    - `analyze()` always returns a typed result dataclass (FairnessResult, etc.)
    - Subclasses raise `ImportError` (not crash at import time) for optional deps
    - Subclasses raise `ValueError` for bad inputs with clear messages
    """

    @property
    @abstractmethod
    def modality(self) -> str:
        """One of: 'tabular', 'image', 'nlp', 'llm'"""

    @abstractmethod
    def analyze(self, results: list[Any], **kwargs) -> Any:
        """
        Run the analysis and return a typed result dataclass.

        Parameters
        ----------
        results : list[XAIResult]
            Explanation results from the XAI module.
        **kwargs :
            Analyzer-specific parameters (e.g. y_true, sensitive_features).
        """