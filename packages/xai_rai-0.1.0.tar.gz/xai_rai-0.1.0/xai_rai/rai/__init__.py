"""
xai_rai.rai — Responsible AI module
=====================================

Public API
----------
Entrypoint:
    RAIReport               — orchestrates all analyzers, returns RAIResult

Analyzers (tabular):
    TabularFairnessAnalyzer — demographic parity / equalized odds
    TabularStabilityAnalyzer — robustness under input perturbation
    TabularDriftAnalyzer    — importance drift between batches (PSI / KS)
    TabularBiasAnalyzer     — sensitive feature importance scan

Base class (for extending to image / NLP / LLM):
    BaseRAIAnalyzer

Result types:
    RAIResult               — top-level report output
    FairnessResult
    StabilityResult
    DriftResult
    BiasResult

Quickstart
----------
    from xai_rai.rai import (
        RAIReport,
        TabularFairnessAnalyzer,
        TabularStabilityAnalyzer,
        TabularBiasAnalyzer,
    )

    report = RAIReport(
        fairness=TabularFairnessAnalyzer(metric="demographic_parity", threshold=0.1),
        stability=TabularStabilityAnalyzer(background_data=X_train, trials=10),
        bias=TabularBiasAnalyzer(sensitive_feature_names=["age", "gender"]),
    )
    result = report.run(
        client=xai_client,
        X=X_test,
        y_true=y_test,
        sensitive_features=gender_col,
    )
    print(result.summary())
    print(result.passed)
"""

from .report import RAIReport
from .analyzers import (
    BaseRAIAnalyzer,
    TabularFairnessAnalyzer,
    TabularStabilityAnalyzer,
    TabularDriftAnalyzer,
    TabularBiasAnalyzer,
)
from .results import (
    RAIResult,
    FairnessResult,
    StabilityResult,
    DriftResult,
    BiasResult,
)

__all__ = [
    "RAIReport",
    "BaseRAIAnalyzer",
    "TabularFairnessAnalyzer",
    "TabularStabilityAnalyzer",
    "TabularDriftAnalyzer",
    "TabularBiasAnalyzer",
    "RAIResult",
    "FairnessResult",
    "StabilityResult",
    "DriftResult",
    "BiasResult",
]