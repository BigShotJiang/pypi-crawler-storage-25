from __future__ import annotations

import logging
import traceback
from typing import Any, Optional

import numpy as np
from numpy.typing import NDArray

from .analyzers import (
    TabularFairnessAnalyzer,
    TabularStabilityAnalyzer,
    TabularDriftAnalyzer,
    TabularBiasAnalyzer,
)
from .results import RAIResult
from .utils import aggregate_importance, validate_results

logger = logging.getLogger(__name__)


class RAIReport:
    """
    Orchestrates all RAI analyzers and returns a single RAIResult.

    Each analyzer is optional — pass None to skip that section.
    Analyzer failures are caught per-section so one failure never
    silently corrupts or blocks the rest of the report.

    Usage
    -----
    Basic tabular report:

        report = RAIReport(
            fairness=TabularFairnessAnalyzer(metric="demographic_parity"),
            stability=TabularStabilityAnalyzer(background_data=X_train),
            bias=TabularBiasAnalyzer(sensitive_feature_names=["age", "gender"]),
        )
        result = report.run(
            client=xai_client,
            X=X_test,
            y_true=y_test,
            sensitive_features=gender_col,
        )
        print(result.summary())

    With drift (requires a baseline batch):

        report = RAIReport(
            drift=TabularDriftAnalyzer(metric="psi"),
        )
        result = report.run(
            client=xai_client,
            X=X_current,
            baseline_results=baseline_batch.results,
        )

    Extensibility
    -------------
    For image/NLP/LLM support, pass the relevant analyzer subclasses.
    RAIReport is modality-agnostic — it just calls `.analyze()` on whatever
    analyzer it receives, as long as it subclasses BaseRAIAnalyzer.
    """

    def __init__(
        self,
        fairness: Optional[TabularFairnessAnalyzer] = None,
        stability: Optional[TabularStabilityAnalyzer] = None,
        drift: Optional[TabularDriftAnalyzer] = None,
        bias: Optional[TabularBiasAnalyzer] = None,
        modality: str = "tabular",
    ):
        self._fairness = fairness
        self._stability = stability
        self._drift = drift
        self._bias = bias
        self._modality = modality

    def run(
        self,
        client: Any,
        X: NDArray,
        y_true: Optional[NDArray] = None,
        sensitive_features: Optional[NDArray] = None,
        baseline_results: Optional[list[Any]] = None,
        explain_kwargs: Optional[dict] = None,
    ) -> RAIResult:
        """
        Run all configured analyzers and return a RAIResult.

        Parameters
        ----------
        client : XAIClient
            The XAI client used to generate explanations.
        X : NDArray
            Input samples to explain and analyze.
        y_true : NDArray, optional
            Ground-truth labels. Required for fairness analysis.
        sensitive_features : NDArray, optional
            Group labels. Required for fairness analysis.
        baseline_results : list[XAIResult], optional
            Prior batch of results. Required for drift analysis.
        explain_kwargs : dict, optional
            Extra kwargs forwarded to client.explain().
        """
        X = np.asarray(X)
        explain_kwargs = explain_kwargs or {}
        errors: dict[str, str] = {}

        # --- Generate explanations ---
        try:
            batch = client.explain(X, **explain_kwargs)
            results = batch.results
            validate_results(results, min_samples=1)
        except Exception as e:
            logger.error("Explanation generation failed: %s", e)
            # Can't proceed without explanations
            return RAIResult(
                modality=self._modality,
                n_samples=len(X),
                errors={"explain": f"{type(e).__name__}: {e}"},
            )

        global_importance = aggregate_importance(results)

        rai = RAIResult(
            modality=self._modality,
            n_samples=len(results),
            global_importance=global_importance,
        )

        # --- Fairness ---
        if self._fairness is not None:
            if y_true is None or sensitive_features is None:
                errors["fairness"] = (
                    "Skipped: y_true and sensitive_features are required for fairness analysis."
                )
            else:
                try:
                    rai.fairness = self._fairness.analyze(
                        results=results,
                        y_true=y_true,
                        sensitive_features=sensitive_features,
                    )
                    logger.info(
                        "Fairness: %s=%.4f flagged=%s",
                        rai.fairness.metric_name,
                        rai.fairness.value,
                        rai.fairness.flagged,
                    )
                except Exception as e:
                    logger.error("Fairness analysis failed: %s", e)
                    errors["fairness"] = f"{type(e).__name__}: {e}"

        # --- Stability ---
        if self._stability is not None:
            try:
                rai.stability = self._stability.analyze(
                    results=results,
                    client=client,
                    x=X[0],
                )
                logger.info(
                    "Stability: mean_diff=%.4f flagged=%s",
                    rai.stability.mean_diff,
                    rai.stability.flagged,
                )
            except Exception as e:
                logger.error("Stability analysis failed: %s", e)
                errors["stability"] = f"{type(e).__name__}: {e}"

        # --- Drift ---
        if self._drift is not None:
            if baseline_results is None:
                errors["drift"] = (
                    "Skipped: baseline_results is required for drift analysis."
                )
            else:
                try:
                    rai.drift = self._drift.analyze(
                        results=results,
                        baseline_results=baseline_results,
                    )
                    logger.info(
                        "Drift: flagged_features=%s",
                        rai.drift.flagged_features,
                    )
                except Exception as e:
                    logger.error("Drift analysis failed: %s", e)
                    errors["drift"] = f"{type(e).__name__}: {e}"

        # --- Bias ---
        if self._bias is not None:
            try:
                rai.bias = self._bias.analyze(results=results)
                logger.info(
                    "Bias: biased_features=%s flagged=%s",
                    rai.bias.biased_features,
                    rai.bias.flagged,
                )
            except Exception as e:
                logger.error("Bias analysis failed: %s", e)
                errors["bias"] = f"{type(e).__name__}: {e}"

        rai.errors = errors
        return rai