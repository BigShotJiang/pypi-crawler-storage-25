"""
xai_rai/core/embeddings.py
==========================
Sentence embedding engine with a graceful Jaccard fallback when
sentence-transformers is not installed.
"""

from __future__ import annotations

import logging
import re

import numpy as np

logger = logging.getLogger(__name__)

try:
    from sentence_transformers import SentenceTransformer
    _SBERT_AVAILABLE = True
except ImportError:
    _SBERT_AVAILABLE = False
    logger.warning(
        "sentence-transformers not installed. "
        "Attribution will use word-overlap fallback. "
        "pip install sentence-transformers to enable semantic attribution."
    )


class EmbeddingEngine:
    """
    Thin wrapper around SentenceTransformer (or a bag-of-words fallback).

    Methods
    -------
    encode(texts)                         → np.ndarray  (N, D), L2-normalised
    batch_similarity_to_vector(texts, v)  → list[float] cosine sims in [0, 1]
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        if _SBERT_AVAILABLE:
            logger.info("Loading sentence-transformers (%s)…", model_name)
            self._model = SentenceTransformer(model_name)
            self._mode  = "sbert"
        else:
            self._model = None
            self._mode  = "jaccard"

    @property
    def mode(self) -> str:
        return self._mode

    def encode(self, texts: list[str]) -> np.ndarray:
        if self._mode == "sbert":
            return self._model.encode(texts, normalize_embeddings=True)
        return self._jaccard_encode(texts)

    def batch_similarity_to_vector(
        self, queries: list[str], reference_vec: np.ndarray
    ) -> list[float]:
        if not queries:
            return []
        return np.clip(self.encode(queries) @ reference_vec, 0.0, 1.0).tolist()

    # ── fallback ──────────────────────────────────────────────────────────────

    @staticmethod
    def _jaccard_encode(texts: list[str]) -> np.ndarray:
        vocab = sorted({w for t in texts for w in re.findall(r"\w+", t.lower())})
        idx   = {w: i for i, w in enumerate(vocab)}
        mat   = np.zeros((len(texts), len(vocab)), dtype=np.float32)
        for i, text in enumerate(texts):
            for w in re.findall(r"\w+", text.lower()):
                if w in idx:
                    mat[i, idx[w]] = 1.0
            norm = np.linalg.norm(mat[i])
            if norm > 0:
                mat[i] /= norm
        return mat