"""
xai_rai/core/results/llm_results.py
===================================

Result objects for LLM XAI / RAI pipelines.

These classes represent:
- sentence attribution
- word attribution
- adversarial checks
- trust / reliability metadata
- developer-facing summaries

Pure presentation layer.
No model execution logic should live here.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from xai_rai.contracts import (
    AdversarialCheck,
    SentenceInfluence,
    WordInfluence,
)


# ---------------------------------------------------------------------------
# Main result container
# ---------------------------------------------------------------------------

@dataclass
class LLMResult:
    """
    Unified result object for LLM explainability + trust analysis.

    Attributes
    ----------
    prompt :
        Original user input.

    response :
        LLM-generated response.

    sentence_attributions :
        Ranked sentence-level influence scores.

    word_attributions :
        Ranked word-level influence scores.

    adversarial_check :
        Optional adversarial / jailbreak analysis result.

    latency_ms :
        Optional end-to-end pipeline latency.

    metadata :
        Arbitrary additional metadata.
    """

    prompt: str
    response: str

    sentence_attributions: list[SentenceInfluence]
    word_attributions: list[WordInfluence]

    adversarial_check: AdversarialCheck | None = None

    latency_ms: float | None = None
    metadata: dict[str, Any] | None = None

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def top_sentences(self, n: int = 3) -> list[SentenceInfluence]:
        """
        Return top-n most influential sentences.
        """
        return sorted(
            self.sentence_attributions,
            key=lambda x: x.influence_score,
            reverse=True,
        )[:n]

    def top_words(self, n: int = 10) -> list[WordInfluence]:
        """
        Return top-n most influential words.
        """
        return sorted(
            self.word_attributions,
            key=lambda x: x.influence_score,
            reverse=True,
        )[:n]

    def is_safe(self) -> bool:
        """
        Whether the prompt passed adversarial checks.
        """
        if self.adversarial_check is None:
            return True

        return not self.adversarial_check.flagged

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
        Machine-readable serialization.
        """

        return {
            "prompt": self.prompt,
            "response": self.response,

            "sentence_attributions": [
                {
                    "sentence": s.sentence,
                    "sentence_index": s.sentence_index,
                    "influence_score": s.influence_score,
                }
                for s in self.sentence_attributions
            ],

            "word_attributions": [
                {
                    "word": w.word,
                    "position": w.position,
                    "influence_score": w.influence_score,
                    "similarity_drop": w.similarity_drop,
                    "window_context": w.window_context,
                    "score_variance": w.score_variance,
                }
                for w in self.word_attributions
            ],

            "adversarial_check": (
                {
                    "flagged": self.adversarial_check.flagged,
                    "reasons": self.adversarial_check.reasons,
                    "attribution_reliable":
                        self.adversarial_check.attribution_reliable,
                }
                if self.adversarial_check
                else None
            ),

            "latency_ms": self.latency_ms,
            "metadata": self.metadata,
        }

    # ------------------------------------------------------------------
    # Human-readable summary
    # ------------------------------------------------------------------

    def summary(
        self,
        top_sentences: int = 3,
        top_words: int = 8,
    ) -> str:
        """
        Pretty terminal summary.
        """

        lines = []

        lines.append("=" * 70)
        lines.append("LLM XAI / RAI SUMMARY")
        lines.append("=" * 70)

        # --------------------------------------------------------------
        # Prompt / response
        # --------------------------------------------------------------

        lines.append("")
        lines.append("Prompt")
        lines.append("-" * 70)
        lines.append(self.prompt)

        lines.append("")
        lines.append("Response")
        lines.append("-" * 70)
        lines.append(self.response)

        # --------------------------------------------------------------
        # Sentence attribution
        # --------------------------------------------------------------

        lines.append("")
        lines.append("Top Influential Sentences")
        lines.append("-" * 70)

        for s in self.top_sentences(top_sentences):

            sentence = s.sentence.strip()

            if len(sentence) > 80:
                sentence = sentence[:77] + "..."

            lines.append(
                f"[{s.sentence_index}] "
                f"{sentence:<80} "
                f"{s.influence_score:.4f}"
            )

        # --------------------------------------------------------------
        # Word attribution
        # --------------------------------------------------------------

        lines.append("")
        lines.append("Top Influential Words")
        lines.append("-" * 70)

        for w in self.top_words(top_words):

            variance = (
                f" ±{w.score_variance:.4f}"
                if w.score_variance > 0
                else ""
            )

            lines.append(
                f"{w.word:<20} "
                f"{w.influence_score:.4f}"
                f"{variance}"
            )

        # --------------------------------------------------------------
        # Adversarial analysis
        # --------------------------------------------------------------

        lines.append("")
        lines.append("Adversarial Analysis")
        lines.append("-" * 70)

        if self.adversarial_check is None:
            lines.append("No adversarial analysis performed.")

        elif not self.adversarial_check.flagged:
            lines.append("No adversarial patterns detected.")
            lines.append("Attribution Reliability: RELIABLE")

        else:
            lines.append("Potential adversarial behavior detected.")
            lines.append("Attribution Reliability: UNRELIABLE")

            for reason in self.adversarial_check.reasons:
                lines.append(f"  • {reason}")

        # --------------------------------------------------------------
        # Metadata
        # --------------------------------------------------------------

        if self.latency_ms is not None:
            lines.append("")
            lines.append(f"Latency : {self.latency_ms:.2f} ms")

        return "\n".join(lines)