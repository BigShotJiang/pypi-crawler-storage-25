from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass
class TokenAttribution:
    """
    Attribution scores for a single token/word.

    Attributes
    ----------
    token   : the word / sub-word string
    score   : signed attribution (positive → pushes toward `label`, negative → away)
    label   : the class this attribution is anchored to
    """
    token: str
    score: float
    label: str


@dataclass
class SHAPExplanation:
    """
    Full SHAP explanation for one input text.

    Attributes
    ----------
    text            : original (normalised) input
    predicted_label : top predicted class
    predicted_score : confidence for predicted_label
    attributions    : list[TokenAttribution] sorted by |score| descending
    base_values     : SHAP base values (expected model output) per class
    label_order     : class names in the order used by shap_values columns
    shap_values     : raw np.ndarray of shape (n_tokens, n_classes)
    """
    text: str
    predicted_label: str
    predicted_score: float
    attributions: list[TokenAttribution]
    base_values: np.ndarray
    label_order: list[str]
    shap_values: np.ndarray

    def top_tokens(self, n: int = 5, label: str | None = None) -> list[TokenAttribution]:
        """
        Return the top-n most influential tokens.

        Parameters
        ----------
        n     : number of tokens to return
        label : filter to a specific class label (defaults to predicted_label)
        """
        target = (label or self.predicted_label).upper()
        filtered = [a for a in self.attributions if a.label == target]
        return sorted(filtered, key=lambda a: abs(a.score), reverse=True)[:n]


@dataclass
class LIMEExplanation:
    """
    Full LIME explanation for one input text.

    Attributes
    ----------
    text            : original (normalised) input
    predicted_label : top predicted class
    predicted_score : confidence for predicted_label
    attributions    : list[TokenAttribution] sorted by |score| descending
    label_index     : integer index of the explained class
    intercept       : LIME local model intercept
    local_score     : LIME local model prediction for this instance
    score           : R² of local linear model (faithfulness proxy)
    """
    text: str
    predicted_label: str
    predicted_score: float
    attributions: list[TokenAttribution]
    label_index: int
    intercept: float
    local_score: float
    score: float  # R²

    @property
    def faithfulness_warnings(self) -> list[str]:
        """
        Returns a list of human-readable warnings when LIME's local linear
        model is a poor approximation of the real model at this input.

        Rules
        -----
        - R² < 0.3  : local linear fit is weak; attributions unreliable
        - local_pred outside [0, 1] : linear model extrapolated beyond
          probability space; weights may be distorted
        """
        warnings = []
        if self.score < 0.3:
            warnings.append(
                f"Low R² ({self.score:.3f} < 0.3): LIME local model is a poor fit — "
                "attributions may be unreliable. Consider increasing num_samples."
            )
        if not (0.0 <= self.local_score <= 1.0):
            warnings.append(
                f"local_pred={self.local_score:.4f} outside [0,1]: linear approximation "
                "extrapolated beyond probability space. Decision boundary is highly non-linear here."
            )
        return warnings

    def top_tokens(self, n: int = 5) -> list[TokenAttribution]:
        """Return top-n tokens by absolute attribution."""
        return sorted(self.attributions, key=lambda a: abs(a.score), reverse=True)[:n]


@dataclass
class CombinedExplanation:
    """Container returned by explain() when both methods are requested."""
    shap: SHAPExplanation
    lime: LIMEExplanation

    def agreement(self, n: int = 5, min_score: float = 1e-3) -> list[str]:
        """
        Tokens appearing in both SHAP and LIME top-n with |score| >= min_score.

        Parameters
        ----------
        n         : top-n tokens to consider from each method
        min_score : minimum absolute score threshold — filters near-zero
                    stopwords that inflate overlap counts (default 1e-3)
        """
        shap_top = {
            a.token.lower() for a in self.shap.top_tokens(n)
            if abs(a.score) >= min_score
        }
        lime_top = {
            a.token.lower() for a in self.lime.top_tokens(n)
            if abs(a.score) >= min_score
        }
        return sorted(shap_top & lime_top)

    def summary(self) -> str:
        lines = []

        lines.append(f"Prediction : {self.shap.predicted_label}")
        lines.append(f"Confidence : {self.shap.predicted_score:.2%}")

        lines.append("")
        lines.append("Top Tokens:")

        for token in self.shap.top_tokens(5):
            lines.append(
                f"  • {token.token}: {token.score:+.3f}"
            )

        return "\n".join(lines)