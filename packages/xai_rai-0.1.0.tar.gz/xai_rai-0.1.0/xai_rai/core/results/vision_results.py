"""
xai_rai/core/results/vision_results.py
======================================

Result objects for vision/image-classification XAI.

Pure presentation layer:
- summaries
- serialization
- metadata access
- figure saving

No model execution logic should live here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import matplotlib.figure
import numpy as np


@dataclass
class VisionResult:
    """
    Unified result object for image explainability.

    Attributes
    ----------
    rise_map :
        RISE saliency heatmap.

    rise_fig :
        RISE matplotlib visualization.

    rise_masks_used :
        Actual masks processed before convergence / stopping.

    occlusion_map :
        Occlusion saliency heatmap.

    occlusion_fig :
        Occlusion matplotlib visualization.

    agreement_score :
        Agreement between RISE and Occlusion maps.

    top_class_idx :
        Predicted class index.

    top_class_prob :
        Predicted class probability.

    extra :
        Additional metadata.
    """

    # ------------------------------------------------------------------
    # RISE
    # ------------------------------------------------------------------

    rise_map: Optional[np.ndarray] = None
    rise_fig: Optional[matplotlib.figure.Figure] = None
    rise_masks_used: Optional[int] = None

    # ------------------------------------------------------------------
    # Occlusion
    # ------------------------------------------------------------------

    occlusion_map: Optional[np.ndarray] = None
    occlusion_fig: Optional[matplotlib.figure.Figure] = None
    lime_map:        Optional[np.ndarray]              = None
    lime_fig:        Optional[matplotlib.figure.Figure] = None

    # ------------------------------------------------------------------
    # Cross-method trust
    # ------------------------------------------------------------------

    agreement_score: Optional[float] = None

    # ------------------------------------------------------------------
    # Prediction metadata
    # ------------------------------------------------------------------

    top_class_idx: Optional[int] = None
    top_class_prob: Optional[float] = None

    # Arbitrary metadata
    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @property
    def top_class_name(self) -> Optional[str]:
        """
        Human-readable class name if available.
        """
        return self.extra.get("top_class_name")

    def top_prediction(self) -> str:
        """
        Pretty prediction string.
        """

        if self.top_class_name:
            return (
                f"{self.top_class_name} "
                f"({self.top_class_prob:.2%})"
            )

        if self.top_class_idx is not None:
            return (
                f"class_{self.top_class_idx} "
                f"({self.top_class_prob:.2%})"
            )

        return "Unknown"

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
        Machine-readable serialization.

        NOTE:
        Figures/maps are intentionally excluded because they are
        large binary/image objects.
        """

        return {
            "top_class_idx": self.top_class_idx,
            "top_class_prob": self.top_class_prob,
            "top_class_name": self.top_class_name,

            "agreement_score": self.agreement_score,

            "rise_masks_used": self.rise_masks_used,

            "has_rise_map": self.rise_map is not None,
            "has_occlusion_map": self.occlusion_map is not None,

            "metadata": self.extra,
        }

    # ------------------------------------------------------------------
    # Figure export
    # ------------------------------------------------------------------

    def save_figures(
        self,
        directory: str | Path = "outputs",
        prefix: str = "xai",
    ) -> list[str]:
        """
        Save explanation figures to disk.

        Returns
        -------
        list[str]
            Paths of saved figures.
        """

        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)

        saved_paths = []

        # --------------------------------------------------------------
        # RISE
        # --------------------------------------------------------------

        if self.rise_fig is not None:

            path = directory / f"{prefix}_rise.png"

            self.rise_fig.savefig(
                path,
                bbox_inches="tight",
            )

            saved_paths.append(str(path))

        # --------------------------------------------------------------
        # Occlusion
        # --------------------------------------------------------------

        if self.occlusion_fig is not None:

            path = directory / f"{prefix}_occlusion.png"

            self.occlusion_fig.savefig(
                path,
                bbox_inches="tight",
            )

            saved_paths.append(str(path))

        return saved_paths

    # ------------------------------------------------------------------
    # Human-readable summary
    # ------------------------------------------------------------------

    def summary(self) -> str:
        """
        Pretty terminal summary.
        """

        lines = []

        lines.append("=" * 70)
        lines.append("VISION XAI SUMMARY")
        lines.append("=" * 70)

        # --------------------------------------------------------------
        # Prediction
        # --------------------------------------------------------------

        lines.append("")
        lines.append("Prediction")
        lines.append("-" * 70)

        lines.append(self.top_prediction())

        # --------------------------------------------------------------
        # Methods used
        # --------------------------------------------------------------

        lines.append("")
        lines.append("Methods")
        lines.append("-" * 70)

        if self.rise_map is not None:
            masks = (
                f" ({self.rise_masks_used} masks)"
                if self.rise_masks_used is not None
                else ""
            )

            lines.append(f"✓ RISE{masks}")

        if self.occlusion_map is not None:
            lines.append("✓ Occlusion")

        # --------------------------------------------------------------
        # Agreement
        # --------------------------------------------------------------

        if self.agreement_score is not None:

            lines.append("")
            lines.append("Cross-Method Agreement")
            lines.append("-" * 70)

            lines.append(
                f"{self.agreement_score:.4f}"
            )

            if self.agreement_score >= 0.7:
                lines.append(
                    "Strong agreement between explanation methods."
                )

            elif self.agreement_score >= 0.4:
                lines.append(
                    "Moderate agreement between explanation methods."
                )

            else:
                lines.append(
                    "Weak agreement — explanations may be unstable."
                )

        # --------------------------------------------------------------
        # Metadata
        # --------------------------------------------------------------

        if self.extra:

            lines.append("")
            lines.append("Metadata")
            lines.append("-" * 70)

            for k, v in self.extra.items():
                lines.append(f"{k}: {v}")

        return "\n".join(lines)

    def show(self) -> None:
        """
        Display all available explanation figures.
        """

        if self.rise_fig is not None:
            self.rise_fig.show()

        if self.occlusion_fig is not None:
            self.occlusion_fig.show()