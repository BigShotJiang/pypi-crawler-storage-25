"""
xai_rai/core/results/tti_results.py
====================================

Unified result objects for text-to-image explainability.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Optional
from xai_rai.explainers.tti_charts import (
    build_attribution_chart,
    build_concept_chart,
)


class TTIResult:
    """
    Unified text-to-image explanation result.

    Exposes:
    - word attributions
    - concept grounding
    - RAI scorecard
    - caption delta analysis
    - flags
    - helper summaries
    """

    def __init__(
        self,
        *,
        prompt: str,

        word_attributions=None,
        concept_scores=None,
        top_concepts=None,

        rai_scorecard=None,

        caption_delta=None,

        flags=None,

        metadata=None,
    ) -> None:

        self.prompt = prompt

        self.word_attributions = word_attributions or []
        self.concept_scores = concept_scores or []
        self.top_concepts = top_concepts or []

        self.rai = rai_scorecard

        self.caption_delta = caption_delta

        self.flags = flags or []

        self.metadata = metadata or {}
        self.attribution_chart: Optional[str] = None
        self.concept_chart: Optional[str] = None

    # ─────────────────────────────────────────────
    # Summaries
    # ─────────────────────────────────────────────

    def summary(self) -> str:
        """
        Human-readable explanation summary.
        """

        lines = []

        lines.append("=" * 70)
        lines.append("TEXT-TO-IMAGE XAI SUMMARY")
        lines.append("=" * 70)

        lines.append("")
        lines.append("Prompt")
        lines.append("-" * 70)
        lines.append(self.prompt)

        if self.top_concepts:
            lines.append("")
            lines.append("Top Concepts")
            lines.append("-" * 70)

            for concept in self.top_concepts[:5]:
                lines.append(f"• {concept}")

        if self.rai:
            lines.append("")
            lines.append("RAI Audit")
            lines.append("-" * 70)

            lines.append(
                f"Prompt Alignment: "
                f"{self.rai.prompt_alignment:.4f}"
            )

            if self.flags:
                lines.append("")
                lines.append("Flags")

                for flag in self.flags:
                    lines.append(f"⚠ {flag}")
            else:
                lines.append("No safety/alignment issues detected.")

        if self.caption_delta:
            lines.append("")
            lines.append("Caption Analysis")
            lines.append("-" * 70)

            lines.append(
                f"Generated Caption: "
                f"{self.caption_delta.caption}"
            )

            if self.caption_delta.injected_concepts:
                lines.append("")
                lines.append("Injected Concepts:")

                for c in self.caption_delta.injected_concepts:
                    lines.append(f"• {c}")

        return "\n".join(lines)

    # ─────────────────────────────────────────────
    # Convenience Helpers
    # ─────────────────────────────────────────────

    def flagged(self) -> bool:
        return bool(self.flags)

    def top_flag(self) -> Optional[str]:
        return self.flags[0] if self.flags else None

    def top_words(self, k: int = 5):
        return self.word_attributions[:k]

    def top_grounded_concepts(self, k: int = 5):
        return self.concept_scores[:k]
# ─────────────────────────────────────────────
# Charts
# ─────────────────────────────────────────────

    def build_charts(self) -> None:
        """
        Generate visual explanation charts.

        Charts are stored as base64 PNG strings.
        """

        if self.word_attributions:
            self.attribution_chart = build_attribution_chart(
                self.word_attributions
            )

        if self.concept_scores:
            self.concept_chart = build_concept_chart(
                self.concept_scores
            )
    # ─────────────────────────────────────────────
    # Serialization
    # ─────────────────────────────────────────────

    def to_dict(self) -> dict:
        """
        JSON-safe serialization.
        """

        return {
            "prompt": self.prompt,

            "word_attributions": [
                asdict(w) for w in self.word_attributions
            ],

            "concept_scores": [
                asdict(c) for c in self.concept_scores
            ],

            "top_concepts": self.top_concepts,
            "charts": {
                "attribution_chart": self.attribution_chart,
                "concept_chart": self.concept_chart,
            },

            "rai": (
                asdict(self.rai)
                if self.rai else None
            ),

            "caption_delta": (
                asdict(self.caption_delta)
                if self.caption_delta else None
            ),

            "flags": self.flags,

            "metadata": self.metadata,
        }

    def __repr__(self) -> str:
        return (
            f"TTIResult("
            f"flags={len(self.flags)}, "
            f"top_concepts={self.top_concepts[:3]}"
            f")"
        )