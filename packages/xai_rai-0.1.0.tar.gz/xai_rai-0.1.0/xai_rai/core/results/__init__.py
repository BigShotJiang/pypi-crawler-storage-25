"""Result model exports for backward-compatible imports."""

from xai_rai.core.results.results import BatchXAIResult, XAIResult
from xai_rai.core.results.llm_results import LLMResult
from xai_rai.core.results.nlp_results import (
    CombinedExplanation,
    LIMEExplanation,
    SHAPExplanation,
    TokenAttribution,
)
from xai_rai.core.results.vision_results import VisionResult

__all__ = [
    "XAIResult",
    "BatchXAIResult",
    "VisionResult",
    "LLMResult",
    "SHAPExplanation",
    "LIMEExplanation",
    "CombinedExplanation",
    "TokenAttribution",
]
