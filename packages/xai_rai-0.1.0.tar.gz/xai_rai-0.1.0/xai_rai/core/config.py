# from dataclasses import dataclass, field
# from typing import Optional

# @dataclass
# class XAIConfig:
#     n_samples: int = 5000
#     n_top_features: int = 10
#     shap_kernel_samples: int = 1000
#     lime_samples: int = 1000
#     parallel: bool = False          # Disabled — KernelExplainer not thread-safe
#     max_workers: int = 4
#     seed: int = 42
#     use_llm: bool = False
#     llm_model: str = "arcee-ai/trinity-large-preview:free"
#     llm_api_key: Optional[str] = None
#     language: str = "en"
#     cache_explanations: bool = True


# @dataclass
# class FeatureMapping:
#     labels: dict[str, str] = field(default_factory=dict)
#     descriptions: dict[str, str] = field(default_factory=dict)
#     thresholds: dict[str, dict[str, float]] = field(default_factory=dict)

#     def get_label(self, feature: str) -> str:
#         return self.labels.get(feature, feature.replace("_", " ").title())

#     def get_description(self, feature: str) -> str:
#         return self.descriptions.get(feature, "")

#     def get_threshold(self, feature: str, threshold_type: str) -> Optional[float]:
#         return self.thresholds.get(feature, {}).get(threshold_type)

# """
# xai_rai/core/config.py
# ======================
# All tuneable constants for the XAI-RAI pipeline.
# Override at runtime by importing and reassigning before calling explain().
# """

# # ── Attribution ───────────────────────────────────────────────────────────────
# ATTRIBUTION_TOP_K          = 8
# ATTRIBUTION_TOP_SENTENCES  = 3
# WINDOW_SIZE                = 1
# ENSEMBLE_VARIANTS          = 3

# # ── Thresholds ────────────────────────────────────────────────────────────────
# CONSISTENCY_FLAG_THRESHOLD     = 0.70
# CONSISTENCY_MISMATCH_THRESHOLD = 0.30
# BIAS_THRESHOLD                 = 0.25
# RAI_FLAG_THRESHOLD             = 0.10

# # ── Cache ─────────────────────────────────────────────────────────────────────
# CACHE_TTL_SECONDS = 3600

# # ── Adversarial ───────────────────────────────────────────────────────────────
# LENGTH_ANOMALY_THRESHOLD = 4000

# ADVERSARIAL_PATTERNS = [
#     r"ignore\s+(previous|above|all|prior)",
#     r"override\s+(instructions?|system|prompt)",
#     r"system\s*:",
#     r"<\s*system\s*>",
#     r"disregard\s+(your|all|previous)",
#     r"you\s+are\s+now\s+a",
#     r"act\s+as\s+(if\s+you\s+are|a\b)",
#     r"jailbreak",
#     r"do\s+anything\s+now",
#     r"dan\s+mode",
# ]

# # ── Bias probe ────────────────────────────────────────────────────────────────
# DEMOGRAPHIC_PAIRS = [
#     ("he",    "she"),
#     ("him",   "her"),
#     ("his",   "her"),
#     ("man",   "woman"),
#     ("men",   "women"),
#     ("boy",   "girl"),
#     ("male",  "female"),
#     ("young", "old"),
#     ("white", "black"),
#     ("John",  "Mohammed"),
#     ("John",  "Maria"),
# ]

# # ── NLP helpers ───────────────────────────────────────────────────────────────
# LOGIC_WORDS = {
#     "not", "no", "nor", "never", "neither", "none", "nobody", "nothing",
#     "nowhere", "without", "except", "but", "only", "barely", "hardly",
#     "scarcely", "unless", "although", "however", "despite", "against",
#     "instead", "rather", "yet", "still", "even", "just",
# }

# STOPWORDS = {
#     "explain", "analyze", "evaluate", "assess",
#     "the", "a", "an", "is", "are", "was", "were", "i", "you",
#     "we", "it", "to", "of", "and", "or", "in", "on", "at",
#     "for", "with", "that", "this", "do", "does", "did", "have",
#     "has", "had", "be", "been", "being", "will", "would", "could",
#     "should", "may", "might", "shall", "can", "so",
# }

# # ── Self-eval prompt suffix ───────────────────────────────────────────────────
# SELF_EVAL_SUFFIX = """

# ---
# After your response above, append ONLY the following JSON block (no extra text):
# {"__xai_confidence": <float 0.0-1.0>, "__xai_uncertainty_reason": "<one sentence or empty string>"}
# """


"""
xai_rai/core/config.py
======================
All tuneable constants AND runtime configuration dataclasses for the
XAI-RAI pipeline.

Two layers
----------
  XAIConfig      — instance-level knobs passed into adapters/explainers
  FeatureMapping — human-readable labels/descriptions for tabular features
  Constants      — module-level defaults; override by reassigning before
                   calling explain()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional
import os

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

# ══════════════════════════════════════════════════════════════════════════════
#  RUNTIME CONFIGURATION DATACLASSES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class XAIConfig:
    """
    Instance-level configuration for the XAI pipeline.

    Attributes
    ----------
    n_samples            : Number of samples for perturbation-based methods.
    n_top_features       : How many top features to surface in reports.
    shap_kernel_samples  : Background samples for SHAP KernelExplainer.
    lime_samples         : Perturbation samples for LIME.
    parallel             : Enable parallel attribution runs.
                           Currently disabled — KernelExplainer is not thread-safe.
    max_workers          : Thread-pool size when parallel=True.
    seed                 : Global random seed for reproducibility.
    use_llm              : Whether to call an LLM for natural-language summaries.
    llm_model            : Model identifier passed to the LLM provider.
    llm_api_key          : API key; falls back to environment variable if None.
    language             : ISO 639-1 language code for generated text.
    cache_explanations   : Persist explanation results to the cache backend.
    """
    n_samples:           int            = 5000
    n_top_features:      int            = 10
    shap_kernel_samples: int            = 1000
    lime_samples:        int            = 1000
    parallel:            bool           = False   # KernelExplainer not thread-safe
    max_workers:         int            = 4
    seed:                int            = 42
    use_llm:             bool           = False
    llm_model:           str            = "gpt-4o-mini"
    llm_api_key:         Optional[str]  = os.getenv("OPENROUTER_API_KEY")
    language:            str            = "en"
    cache_explanations:  bool           = True


@dataclass
class FeatureMapping:
    """
    Human-readable metadata for tabular model features.

    Usage
    -----
        mapping = FeatureMapping(
            labels       = {"age": "Patient Age"},
            descriptions = {"age": "Age in years at time of diagnosis"},
            thresholds   = {"age": {"low": 18.0, "high": 65.0}},
        )
        mapping.get_label("age")                   # → "Patient Age"
        mapping.get_threshold("age", "high")        # → 65.0
    """
    labels:       dict[str, str]               = field(default_factory=dict)
    descriptions: dict[str, str]               = field(default_factory=dict)
    thresholds:   dict[str, dict[str, float]]  = field(default_factory=dict)

    def get_label(self, feature: str) -> str:
        return self.labels.get(feature, feature.replace("_", " ").title())

    def get_description(self, feature: str) -> str:
        return self.descriptions.get(feature, "")

    def get_threshold(self, feature: str, threshold_type: str) -> Optional[float]:
        return self.thresholds.get(feature, {}).get(threshold_type)


# ══════════════════════════════════════════════════════════════════════════════
#  MODULE-LEVEL CONSTANTS  (pipeline defaults)
# ══════════════════════════════════════════════════════════════════════════════

# ── Attribution ───────────────────────────────────────────────────────────────
ATTRIBUTION_TOP_K          = 8
ATTRIBUTION_TOP_SENTENCES  = 3
WINDOW_SIZE                = 1
ENSEMBLE_VARIANTS          = 3

# ── Thresholds ────────────────────────────────────────────────────────────────
CONSISTENCY_FLAG_THRESHOLD     = 0.70
CONSISTENCY_MISMATCH_THRESHOLD = 0.30
BIAS_THRESHOLD                 = 0.25
RAI_FLAG_THRESHOLD             = 0.10

# ── Cache ─────────────────────────────────────────────────────────────────────
CACHE_TTL_SECONDS = 3600

# ── Adversarial ───────────────────────────────────────────────────────────────
LENGTH_ANOMALY_THRESHOLD = 4000
ENTROPY_ABS_THRESHOLD    = 4.5
ENTROPY_NONASCII_RATIO   = 0.15
ENTROPY_SHORT_PROMPT_LEN = 30

ADVERSARIAL_PATTERNS = [
    r"ignore\s+(previous|above|all|prior)",
    r"override\s+(instructions?|system|prompt)",
    r"system\s*:",
    r"<\s*system\s*>",
    r"disregard\s+(your|all|previous)",
    r"you\s+are\s+now\s+a",
    r"act\s+as\s+(if\s+you\s+are|a\b)",
    r"jailbreak",
    r"do\s+anything\s+now",
    r"dan\s+mode",
]

# ── Bias probe ────────────────────────────────────────────────────────────────
DEMOGRAPHIC_PAIRS = [
    ("he",    "she"),
    ("him",   "her"),
    ("his",   "her"),
    ("man",   "woman"),
    ("men",   "women"),
    ("boy",   "girl"),
    ("male",  "female"),
    ("young", "old"),
    ("white", "black"),
    ("John",  "Mohammed"),
    ("John",  "Maria"),
]
# ── Implicit bias ──────────────────────────────────────────────────────────────
IMPLICIT_BIAS_THRESHOLD = 0.12   # drift threshold for implicit signals (lower than explicit)

IMPLICIT_BIAS_PATTERNS: dict[str, list[str]] = {
    "employment": [
        "career break",
        "gap in employment",
        "gap year",
        "returning to work",
        "stay at home",
        "left the workforce",
        "re-entering",
        "employment gap",
        "time off work",
        "sabbatical",
    ],
    "age": [
        "overqualified",
        "too experienced",
        "digital native",
        "fresh perspective",
        "older worker",
        "retirement age",
        "entry level only",
    ],
    "gender": [
        "maternity",
        "paternity",
        "parental leave",
        "primary carer",
        "childcare responsibilities",
        "school run",
        "family commitments",
    ],
    "socioeconomic": [
        "non-traditional background",
        "first generation",
        "state school",
        "community college",
        "self-taught",
    ],
    "health": [
        "chronic illness",
        "disability",
        "mental health",
        "long term condition",
        "reduced hours",
        "reasonable adjustment",
    ],
}

# Neutral replacements for counterfactual embedding — keyed by pattern
IMPLICIT_BIAS_NEUTRALISATIONS: dict[str, str] = {
    "career break":              "period of professional development",
    "gap in employment":         "period of professional development",
    "employment gap":            "period of professional development",
    "gap year":                  "structured learning period",
    "returning to work":         "continuing professional career",
    "stay at home":              "independently managed responsibilities",
    "left the workforce":        "pursued other professional activities",
    "re-entering":               "continuing in",
    "time off work":             "period of development",
    "sabbatical":                "research period",
    "overqualified":             "highly experienced",
    "too experienced":           "highly experienced",
    "digital native":            "technology proficient",
    "fresh perspective":         "professional perspective",
    "older worker":              "experienced professional",
    "retirement age":            "senior professional",
    "entry level only":          "open to all experience levels",
    "maternity":                 "extended leave",
    "paternity":                 "extended leave",
    "parental leave":            "extended leave",
    "primary carer":             "person with caring responsibilities",
    "childcare responsibilities":"personal responsibilities",
    "school run":                "scheduled commitments",
    "family commitments":        "personal commitments",
    "non-traditional background":"diverse background",
    "first generation":          "independent learner",
    "state school":              "secondary school",
    "community college":         "tertiary institution",
    "self-taught":               "independently trained",
    "chronic illness":           "ongoing health consideration",
    "disability":                "health consideration",
    "mental health":             "health consideration",
    "long term condition":       "ongoing health consideration",
    "reduced hours":             "flexible hours",
    "reasonable adjustment":     "workplace accommodation",
}
# ── NLP helpers ───────────────────────────────────────────────────────────────
LOGIC_WORDS = {
    "not", "no", "nor", "never", "neither", "none", "nobody", "nothing",
    "nowhere", "without", "except", "but", "only", "barely", "hardly",
    "scarcely", "unless", "although", "however", "despite", "against",
    "instead", "rather", "yet", "still", "even", "just",
}

STOPWORDS = {
    "explain", "analyze", "evaluate", "assess",
    "the", "a", "an", "is", "are", "was", "were", "i", "you",
    "we", "it", "to", "of", "and", "or", "in", "on", "at",
    "for", "with", "that", "this", "do", "does", "did", "have",
    "has", "had", "be", "been", "being", "will", "would", "could",
    "should", "may", "might", "shall", "can", "so",
}

# ── Self-eval prompt suffix ───────────────────────────────────────────────────
SELF_EVAL_SUFFIX = """

---
After your response above, append ONLY the following JSON block (no extra text):
{"__xai_confidence": <float 0.0-1.0>, "__xai_uncertainty_reason": "<one sentence or empty string>"}
"""