"""xai_rai.core — internal infrastructure (config, cache, embeddings)."""

from xai_rai.core.cache import CacheBackend
from xai_rai.core.config import FeatureMapping, XAIConfig
from xai_rai.core.config import *          # noqa: F401,F403  (re-export all constants)
from xai_rai.core.embeddings import EmbeddingEngine

__all__ = ["CacheBackend", "EmbeddingEngine", "XAIConfig", "FeatureMapping"]