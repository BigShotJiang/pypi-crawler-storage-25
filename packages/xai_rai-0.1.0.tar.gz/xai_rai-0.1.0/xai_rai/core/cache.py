"""
xai_rai/core/cache.py
=====================
In-memory (default) or optional Redis cache for explanation results.
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Optional

from xai_rai.core.config import CACHE_TTL_SECONDS

logger = logging.getLogger(__name__)

try:
    import redis as _redis_lib
    _REDIS_AVAILABLE = True
except ImportError:
    _REDIS_AVAILABLE = False


class CacheBackend:
    """
    Pluggable cache for GenerativeExplanationResult JSON blobs.

    Usage
    -----
        cache = CacheBackend()                          # in-memory
        cache = CacheBackend("redis", "redis://...")    # Redis
    """

    def __init__(
        self,
        backend:   str = "memory",
        redis_url: str = "redis://localhost:6379/0",
    ):
        self._backend = backend
        self._mem: dict[str, str] = {}
        self._redis = None

        if backend == "redis":
            if not _REDIS_AVAILABLE:
                logger.warning("redis-py not installed — falling back to in-memory cache.")
                self._backend = "memory"
            else:
                try:
                    self._redis = _redis_lib.from_url(redis_url)
                    self._redis.ping()
                    logger.info("Redis cache connected: %s", redis_url)
                except Exception as exc:
                    logger.warning("Redis unavailable (%s) — falling back to in-memory.", exc)
                    self._backend = "memory"

    # ── public interface ──────────────────────────────────────────────────────

    def get(self, key: str) -> Optional[str]:
        if self._backend == "redis" and self._redis:
            val = self._redis.get(key)
            return val.decode() if val else None
        return self._mem.get(key)

    def set(self, key: str, value: str) -> None:
        if self._backend == "redis" and self._redis:
            self._redis.setex(key, CACHE_TTL_SECONDS, value)
        else:
            self._mem[key] = value

    def clear(self) -> None:
        if self._backend == "redis" and self._redis:
            self._redis.flushdb()
        else:
            self._mem.clear()

    # ── key construction ──────────────────────────────────────────────────────

    @staticmethod
    def make_key(prompt: str, system_prompt: str, history: list[dict]) -> str:
        raw = json.dumps(
            {"p": prompt, "s": system_prompt, "h": history},
            sort_keys=True,
            ensure_ascii=False,
        )
        return "xai:" + hashlib.sha256(raw.encode()).hexdigest()