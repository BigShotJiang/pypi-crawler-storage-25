import numpy as np
from typing import Callable, Any
from numpy.typing import NDArray
from xai_rai.core.config import XAIConfig
import shap


class ExplainerRouter:
    """
    Routes to the fastest appropriate SHAP explainer based on model type.
    Falls back to KernelExplainer for unknown/API-wrapped models.

    Speed tiers:
      TreeExplainer    ~100x faster than Kernel  (tree-based: RF, XGB, LGBM, etc.)
      LinearExplainer  ~10x faster than Kernel   (linear: LogReg, Ridge, etc.)
      KernelExplainer  baseline                   (any predict_fn)
    """

    @staticmethod
    def get_explainer(
        model: Any,
        predict_fn: Callable,
        background_data: NDArray,
        config: XAIConfig,
    ) -> tuple[Any, str]:
        """
        Returns (shap_explainer, explainer_type_str).
        model may be None for pure predict_fn usage.
        """
        if model is not None:
            # Try TreeExplainer first (fastest, exact)
            try:
                explainer = shap.TreeExplainer(model)
                # Validate it works
                explainer.shap_values(background_data[:1])
                return explainer, "tree"
            except Exception:
                pass

            # Try LinearExplainer
            try:
                if hasattr(model, "coef_"):
                    explainer = shap.LinearExplainer(model, background_data)
                    explainer.shap_values(background_data[:1])
                    return explainer, "linear"
            except Exception:
                pass

        # Fallback: KernelExplainer (model-agnostic, slowest)
        def predict_wrapper(X: NDArray) -> NDArray:
            result = predict_fn(X)
            if result.ndim == 1:
                return np.column_stack([1 - result, result])
            return result

        explainer = shap.KernelExplainer(
            predict_wrapper,
            background_data,
            nsamples=config.shap_kernel_samples,
            seed=config.seed,
        )
        return explainer, "kernel"

