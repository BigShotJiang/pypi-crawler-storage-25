"""
xai_rai/contracts_tti.py
========================
Data contracts for the text-to-image XAI/RAI pipeline.
Kept separate from contracts.py (tabular/NLP) to avoid coupling.
Import from here for all TTI-specific dataclasses.
"""

from __future__ import annotations

import io
import json
import base64
from dataclasses import dataclass, field, asdict
from typing import List, Optional

from PIL import Image


# ── Attribution ───────────────────────────────────────────────────────────────

@dataclass
class WordAttribution:
    word:       str
    clip_score: float
    normalised: float


@dataclass
class ConceptScore:
    concept:  str
    category: str
    score:    float
    flagged:  bool


# ── BLIP-2 caption delta ──────────────────────────────────────────────────────

@dataclass
class CaptionDelta:
    """Result of BLIP-2 caption vs prompt semantic diff."""
    caption:           str
    injected_concepts: List[str]   # in caption, absent from prompt
    dropped_concepts:  List[str]   # in prompt, absent from caption
    injection_flagged: bool


# ── VQA ───────────────────────────────────────────────────────────────────────

@dataclass
class VQAProbeResult:
    question:   str
    concept:    str
    confidence: float
    answer:     str
    flagged:    bool


# ── Analyzer protocol contracts ───────────────────────────────────────────────

@dataclass
class AnalyzerContext:
    """Shared mutable context threaded through the tier registry."""
    image:          Image.Image
    prompt:         str
    image_emb:      object        = None   # populated by CLIPAnalyzer
    clip_flags:     List[str]     = field(default_factory=list)
    blip_caption:   str           = ""
    injected_attrs: List[str]     = field(default_factory=list)


@dataclass
class AnalyzerResult:
    """Standard output contract for every analyzer tier."""
    analyzer:   str
    data:       dict
    flags:      List[str]
    latency_ms: float = 0.0


# ── RAI scorecard ─────────────────────────────────────────────────────────────

@dataclass
class TTIRAIScorecard:
    prompt_alignment:    float
    alignment_flagged:   bool
    nsfw_concepts:       List[str]
    nsfw_flagged:        bool
    stereotype_concepts: List[str]
    stereotype_flagged:  bool
    prompt_toxicity:     float
    toxicity_flagged:    bool
    injected_attrs:      List[str]          = field(default_factory=list)
    injection_flagged:   bool               = False
    vqa_probes:          List[VQAProbeResult] = field(default_factory=list)
    vqa_flagged:         bool               = False
    overall_flagged:     bool               = False
    analysis_mode:       str                = "fast"


# ── Top-level result ──────────────────────────────────────────────────────────

@dataclass
class TextToImageExplanation:
    prompt:                str
    image_b64:             str
    word_attributions:     List[WordAttribution]
    concept_scores:        List[ConceptScore]
    top_concepts:          List[str]
    rai:                   TTIRAIScorecard
    attribution_chart_b64: str
    concept_chart_b64:     str
    model_label:           str
    analysis_mode:         str                   = "fast"
    tier_results:          List                  = field(default_factory=list)
    method:                str                   = (
        "Multi-signal CLIP+BLIP-2+VQA post-hoc analysis"
    )
    caption_delta:         Optional[CaptionDelta] = None
    audit_narrative:       str                   = ""

    def to_json(self, indent: int = 2) -> str:
        d = asdict(self)
        for k in ("image_b64", "attribution_chart_b64", "concept_chart_b64"):
            d.pop(k, None)
        return json.dumps(d, indent=indent, default=str)

    def show_image(self) -> Image.Image:
        return Image.open(io.BytesIO(base64.b64decode(self.image_b64)))

    def show_attribution_chart(self) -> Image.Image:
        return Image.open(io.BytesIO(base64.b64decode(self.attribution_chart_b64)))

    def show_concept_chart(self) -> Image.Image:
        return Image.open(io.BytesIO(base64.b64decode(self.concept_chart_b64)))