"""
xai_rai/explainers/adversarial.py
==================================
Pre-flight adversarial prompt detection.
Checks for injection patterns, token entropy anomalies, and length outliers.
"""

from __future__ import annotations

import math
import re
from collections import Counter

from xai_rai.contracts import AdversarialCheck
from xai_rai.core.config import ADVERSARIAL_PATTERNS, LENGTH_ANOMALY_THRESHOLD

# Entropy is only suspicious when the prompt is also short (obfuscation
# in few tokens) OR has a high non-ASCII ratio (unicode substitution).
_ENTROPY_ABS_THRESHOLD    = 4.5   # absolute bits — normal English ~2.5–3.5
_ENTROPY_NONASCII_RATIO   = 0.15  # flag if >15 % chars are non-ASCII
_ENTROPY_SHORT_PROMPT_LEN = 30    # characters — "short" prompt window


class AdversarialDetector:
    """
    Stateless detector — call `check(prompt)` before attribution.

    Three signals
    -------------
    1. Regex pattern scan  — known injection / jailbreak phrases
    2. Token entropy       — absolute threshold + corroborating signals
                             (non-ASCII ratio OR suspiciously short prompt)
    3. Extreme length      — prompts beyond LENGTH_ANOMALY_THRESHOLD chars
    """

    def check(self, prompt: str) -> AdversarialCheck:
        reasons: list[str] = []

        # ── 1. Pattern scan ───────────────────────────────────────────────────
        for pat in ADVERSARIAL_PATTERNS:
            if re.search(pat, prompt, re.IGNORECASE):
                reasons.append(f"Injection pattern matched: '{pat}'")

        # ── 2. Token entropy (fixed) ──────────────────────────────────────────
        tokens = re.findall(r"\w+", prompt.lower())
        if tokens:
            freq    = Counter(tokens)
            total   = sum(freq.values())
            probs   = [c / total for c in freq.values()]
            entropy = -sum(p * math.log2(p) for p in probs if p > 0)

            non_ascii_ratio = (
                sum(1 for c in prompt if ord(c) > 127) / max(len(prompt), 1)
            )
            is_short        = len(prompt) < _ENTROPY_SHORT_PROMPT_LEN
            is_high_entropy = entropy > _ENTROPY_ABS_THRESHOLD

            if is_high_entropy and (non_ascii_ratio > _ENTROPY_NONASCII_RATIO or is_short):
                reasons.append(
                    f"High token entropy ({entropy:.2f}) — possible obfuscation "
                    f"[non-ASCII ratio: {non_ascii_ratio:.2f}, short: {is_short}]."
                )

        # ── 3. Length anomaly ─────────────────────────────────────────────────
        if len(prompt) > LENGTH_ANOMALY_THRESHOLD:
            reasons.append(
                f"Prompt length ({len(prompt)} chars) exceeds threshold "
                f"({LENGTH_ANOMALY_THRESHOLD})."
            )

        flagged = bool(reasons)
        return AdversarialCheck(
            flagged=flagged,
            reasons=reasons,
            attribution_reliable=not flagged,
        )