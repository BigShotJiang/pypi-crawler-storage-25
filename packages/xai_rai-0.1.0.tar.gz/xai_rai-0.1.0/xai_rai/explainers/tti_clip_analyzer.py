"""xai_rai/text_to_image/explainer/clip_analyzer.py
=================================================
Tier 1 — CLIP fast-path explainer.

Performance fixes vs v1
------------------------
- Concept bank embeddings cached after first analyze() — never re-embedded.
- Chunked embedding (CONCEPT_CHUNK_SIZE=64) bounds peak tensor allocation.
- Single GPU transfer per analyze(): image + words + prompt batched in one
  CLIPEngine._on_device() block instead of three separate GPU contexts.
- Intermediate tensors deleted immediately; gc.collect() at end of analyze().

Accuracy fixes vs v1
---------------------
- Dtype resolved at CLIPEngine load time (bfloat16 on modern CPUs), fixing
  fp16 underflow that produced near-zero similarities on CPU-only machines.
- All three embed operations share one GPU context — no dtype side-effects.
"""
from __future__ import annotations

import gc
import logging
import re
from typing import Optional

from xai_rai.contracts_tti import AnalyzerContext, AnalyzerResult
from xai_rai.core.tti_config import (
    _STOPWORDS,
    _ALL_CONCEPTS, _NSFW_CONCEPTS, _DEMO_CONCEPTS, CONCEPT_BANK,
    ALIGNMENT_WARN, NSFW_THRESHOLD, STEREOTYPE_THRESHOLD, TOXICITY_THRESHOLD,
)
from xai_rai.explainers.model_registry import ModelAnalyzer
from xai_rai.explainers.clip_engine import CLIPEngine
from xai_rai.contracts_tti import (
    WordAttribution, ConceptScore, TTIRAIScorecard,
)

logger = logging.getLogger(__name__)

try:
    import torch
    _CLIP_AVAILABLE = True
except ImportError:
    _CLIP_AVAILABLE = False

try:
    from detoxify import Detoxify as _Detoxify
    _DETOXIFY_AVAILABLE = True
except ImportError:
    _DETOXIFY_AVAILABLE = False

CONCEPT_CHUNK_SIZE: int = 64


class CLIPAnalyzer(ModelAnalyzer):
    """
    Tier 1: CLIP fast-path.

    Parameters
    ----------
    engine   : shared CLIPEngine (lazy; constructed once per process)
    detoxify : optional Detoxify instance for prompt toxicity scoring
    """

    def __init__(self, engine: CLIPEngine, detoxify=None) -> None:
        self._clip  = engine
        self._detox = detoxify
        self._concept_embs: Optional["torch.Tensor"] = None  # CPU cache

    @property
    def name(self) -> str:
        return "clip"

    def is_available(self) -> bool:
        return _CLIP_AVAILABLE

    # ── concept cache ─────────────────────────────────────────────────────────

    def _ensure_concept_cache(self) -> None:
        """
        Embed ALL_CONCEPTS in chunks and cache on CPU.
        Runs its own GPU block so concept VRAM is fully released before
        the main analyze() GPU block opens — halves peak VRAM.
        """
        if self._concept_embs is not None:
            return
        logger.info(
            "Building concept cache (%d concepts, chunk=%d)…",
            len(_ALL_CONCEPTS), CONCEPT_CHUNK_SIZE,
        )
        chunks = []
        for i in range(0, len(_ALL_CONCEPTS), CONCEPT_CHUNK_SIZE):
            chunks.append(
                self._clip.embed_texts(_ALL_CONCEPTS[i : i + CONCEPT_CHUNK_SIZE])
            )
        self._concept_embs = torch.cat(chunks, dim=0)
        logger.info("Concept cache ready — shape %s.", self._concept_embs.shape)

    def invalidate_concept_cache(self) -> None:
        """Drop the cache (call after hot-swapping CONCEPT_BANK)."""
        self._concept_embs = None
        gc.collect()

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _content_words(prompt: str) -> list[str]:
        words = re.findall(r"[a-zA-Z]+", prompt.lower())
        return [w for w in words if w not in _STOPWORDS and len(w) > 2]

    def _word_attribution(
        self,
        image_emb: "torch.Tensor",
        word_embs: "torch.Tensor",
        words:     list[str],
    ) -> list[WordAttribution]:
        if not words:
            return []
        scores    = self._clip.score(image_emb, word_embs)
        max_score = max(scores) if scores else 1.0
        return sorted(
            [
                WordAttribution(
                    word       = w,
                    clip_score = s,
                    normalised = round(s / max_score, 4) if max_score else 0.0,
                )
                for w, s in zip(words, scores)
            ],
            key=lambda a: a.clip_score,
            reverse=True,
        )

    def _concept_grounding(
        self, image_emb: "torch.Tensor"
    ) -> list[ConceptScore]:
        """Pure CPU matmul against the cached concept embeddings."""
        scores = self._clip.score(image_emb, self._concept_embs)
        c2cat  = {c: cat for cat, cs in CONCEPT_BANK.items() for c in cs}
        results = []
        for concept, score in zip(_ALL_CONCEPTS, scores):
            cat     = c2cat.get(concept, "Other")
            flagged = (
                (concept in _NSFW_CONCEPTS        and score > NSFW_THRESHOLD) or
                (concept in _DEMO_CONCEPTS and score > STEREOTYPE_THRESHOLD)
            )
            results.append(
                ConceptScore(concept=concept, category=cat,
                             score=score, flagged=flagged)
            )
        return sorted(results, key=lambda c: c.score, reverse=True)

    def _build_rai(
        self,
        image_emb:      "torch.Tensor",
        prompt_emb:     "torch.Tensor",
        prompt:         str,
        concept_scores: list[ConceptScore],
    ) -> tuple[TTIRAIScorecard, list[str]]:
        alignment         = self._clip.score(image_emb, prompt_emb)[0]
        alignment_flagged = alignment < ALIGNMENT_WARN

        nsfw_found = [
            c.concept for c in concept_scores
            if c.concept in _NSFW_CONCEPTS and c.score > NSFW_THRESHOLD
        ]    
        prompt_lower = prompt.lower()

        # Existing threshold check
        stereo_found = [
            c.concept for c in concept_scores
            if c.concept in _DEMO_CONCEPTS
            and c.score > STEREOTYPE_THRESHOLD
            and c.concept.split()[0] not in prompt_lower
        ]

        # NEW: rank check — flag if a demographic concept is the top concept
        # overall and was not explicitly in the prompt
        if not stereo_found and concept_scores:
            top = concept_scores[0]  # already sorted by score desc
            if (
                top.concept in _DEMO_CONCEPTS
                and top.concept.split()[0] not in prompt_lower
                and top.score > _STEREOTYPE_THRESHOLD * 0.85  # softer floor: ~0.21
            ):
                stereo_found = [top.concept]

        tox_score = 0.0
        if self._detox:
            try:
                tox_score = float(
                    self._detox.predict(prompt).get("toxicity", 0.0)
                )
            except Exception:
                pass

        flags: list[str] = []
        if alignment_flagged:              flags.append("alignment_low")
        if nsfw_found:                     flags.extend(nsfw_found)
        if stereo_found:                   flags.append("stereotype")
        if tox_score > TOXICITY_THRESHOLD: flags.append("toxic_prompt")

        scorecard = TTIRAIScorecard(
            prompt_alignment    = round(alignment, 4),
            alignment_flagged   = alignment_flagged,
            nsfw_concepts       = nsfw_found,
            nsfw_flagged        = bool(nsfw_found),
            stereotype_concepts = stereo_found,
            stereotype_flagged  = bool(stereo_found),
            prompt_toxicity     = round(tox_score, 4),
            toxicity_flagged    = tox_score > TOXICITY_THRESHOLD,
            overall_flagged     = bool(flags),
        )
        return scorecard, flags

    # ── main ──────────────────────────────────────────────────────────────────

    def analyze(self, context: AnalyzerContext) -> AnalyzerResult:
        """
        Three-step execution minimises peak VRAM:

        1. Concept cache warmup — its own GPU block, fully closed first.
           On subsequent images: free CPU cache hit.

        2. Single _on_device() block: image + words + prompt encoded together.
           Tensors deleted inside the block so empty_cache() reclaims them
           before any downstream tier allocates memory.

        3. All scoring: pure CPU matmul — GPU not touched after step 2.
        """
        # Ensure engine weights are loaded before accessing private attrs
        self._clip._lazy_load()

        # Step 1
        self._ensure_concept_cache()

        words       = self._content_words(context.prompt)
        texts_batch = words + [context.prompt]

        # Step 2 — one GPU block
        with self._clip._on_device():
            img_t = (
                self._clip._prep(context.image.convert("RGB"))
                .unsqueeze(0)
                .to(dtype=self._clip._dtype, device=self._clip._device,
                    non_blocking=True)
            )
            with torch.no_grad():
                image_emb = self._clip._model.encode_image(img_t)
                image_emb = (image_emb / image_emb.norm(dim=-1, keepdim=True)).cpu()
            del img_t
            if self._clip._device == "cuda":
                torch.cuda.empty_cache()

            if texts_batch:
                tokens = self._clip._tok(texts_batch).to(
                    self._clip._device, non_blocking=True
                )
                with torch.no_grad():
                    text_embs = self._clip._model.encode_text(tokens)
                    text_embs = (
                        text_embs / text_embs.norm(dim=-1, keepdim=True)
                    ).cpu()
                del tokens
                if self._clip._device == "cuda":
                    torch.cuda.empty_cache()
                word_embs  = text_embs[: len(words)]
                prompt_emb = text_embs[len(words):]
                del text_embs
            else:
                dim        = image_emb.shape[-1]
                word_embs  = torch.zeros(0, dim)
                prompt_emb = torch.zeros(1, dim)

        context.image_emb = image_emb  # share with downstream tiers

        # Step 3 — CPU scoring
        concept_scores = self._concept_grounding(image_emb)
        word_attrs     = self._word_attribution(image_emb, word_embs, words)
        rai, flags     = self._build_rai(
            image_emb, prompt_emb, context.prompt, concept_scores
        )
        context.clip_flags = flags

        del word_embs, prompt_emb
        gc.collect()

        return AnalyzerResult(
            analyzer = self.name,
            data     = {
                "word_attributions": word_attrs,
                "concept_scores":    concept_scores,
                "top_concepts":      [c.concept for c in concept_scores[:5]],
                "rai":               rai,
            },
            flags = flags,
        )


def make_detoxify():
    """Return a Detoxify instance or None if not installed."""
    if _DETOXIFY_AVAILABLE:
        return _Detoxify("original")
    return None