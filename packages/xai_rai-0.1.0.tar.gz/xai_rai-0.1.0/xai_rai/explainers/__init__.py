"""Lazy exports for xai_rai.explainers package."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from xai_rai.explainers.clip_engine import CLIPEngine
    from xai_rai.explainers.model_registry import ModelAnalyzer, ModelRegistry
    from xai_rai.explainers.tti_blip2_analyzer import BLIP2CaptionAnalyzer
    from xai_rai.explainers.tti_clip_analyzer import CLIPAnalyzer, make_detoxify
    from xai_rai.rai.implements.tti_vqa_probe import VQAProbeAnalyzer


def __getattr__(name: str) -> Any:
    if name in {"ModelAnalyzer", "ModelRegistry"}:
        from xai_rai.explainers.model_registry import ModelAnalyzer, ModelRegistry

        return {"ModelAnalyzer": ModelAnalyzer, "ModelRegistry": ModelRegistry}[name]
    if name == "CLIPEngine":
        from xai_rai.explainers.clip_engine import CLIPEngine

        return CLIPEngine
    if name in {"CLIPAnalyzer", "make_detoxify"}:
        from xai_rai.explainers.tti_clip_analyzer import CLIPAnalyzer, make_detoxify

        return {"CLIPAnalyzer": CLIPAnalyzer, "make_detoxify": make_detoxify}[name]
    if name == "BLIP2CaptionAnalyzer":
        from xai_rai.explainers.tti_blip2_analyzer import BLIP2CaptionAnalyzer

        return BLIP2CaptionAnalyzer
    if name == "VQAProbeAnalyzer":
        from xai_rai.rai.implements.tti_vqa_probe import VQAProbeAnalyzer

        return VQAProbeAnalyzer
    raise AttributeError(f"module 'xai_rai.explainers' has no attribute '{name}'")


__all__ = [
    "ModelAnalyzer",
    "ModelRegistry",
    "CLIPEngine",
    "CLIPAnalyzer",
    "make_detoxify",
    "BLIP2CaptionAnalyzer",
    "VQAProbeAnalyzer",
]