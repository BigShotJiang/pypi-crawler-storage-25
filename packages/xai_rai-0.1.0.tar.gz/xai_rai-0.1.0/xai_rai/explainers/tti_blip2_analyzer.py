"""
xai_rai/text_to_image/explainer/blip2_analyzer.py
==================================================
Tier 2 — caption delta (attribute injection detection).

Algorithm
---------
1. Generate a caption of the image via the captioner.
2. Extract content words from caption and prompt.
3. Caption words NOT in prompt → scored via shared CLIP.
   Score > INJECTION_DELTA_THRESHOLD → INJECTED attribute.
4. Prompt words NOT in caption → DROPPED (not rendered).

Performance fixes vs v1
------------------------
- Default model: nlpconnect/vit-gpt2-image-captioning (~500 MB).
  Old default was Salesforce/blip2-opt-2.7b (~11 GB) — caused the lag.
  Override with env-var: TTI_BLIP2_MODEL_ID=Salesforce/blip2-opt-2.7b
- Fully lazy: __init__ stores config only — zero weight allocation at
  construction or import time.
- _caption_fn resolved once at _lazy_load() time — no repeated string
  comparison on every inference call.
- _on_device() context manager: weights move to GPU only for one generate()
  call, then return to CPU with VRAM flushed.

Accuracy fixes vs v1
---------------------
- dtype resolved at load time (float16 CUDA / bfloat16 CPU / float32
  fallback) — not hardcoded to float16 which corrupts CPU inference.
- pixel_values cast to self._dtype BEFORE device transfer, avoiding a
  silent upcast to float32 mid-inference on some transformers builds.
"""

from __future__ import annotations

import logging
import os
import re
from contextlib import contextmanager
from typing import Callable, Optional

from xai_rai.contracts_tti import AnalyzerContext, AnalyzerResult
from xai_rai.core.tti_config import _STOPWORDS, INJECTION_DELTA_THRESHOLD
from xai_rai.contracts_tti import CaptionDelta
from xai_rai.explainers.model_registry import ModelAnalyzer
from xai_rai.explainers.clip_engine import CLIPEngine

logger = logging.getLogger(__name__)

try:
    import torch
    from transformers import (
        VisionEncoderDecoderModel,
        ViTImageProcessor,
        AutoTokenizer,
    )
    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False
    logger.warning(
        "transformers not installed — BLIP-2 tier disabled.  "
        "pip install transformers accelerate"
    )

# ── model selection ───────────────────────────────────────────────────────────
_DEFAULT_MODEL_ID = "nlpconnect/vit-gpt2-image-captioning"  # ~500 MB
_MODEL_ID         = os.environ.get("TTI_BLIP2_MODEL_ID", _DEFAULT_MODEL_ID)

# Memory caps for the heavy BLIP-2 path (device_map="auto")
_MAX_GPU_MEM = os.environ.get("TTI_MAX_GPU_MEM", "3GiB")
_MAX_CPU_MEM = os.environ.get("TTI_MAX_CPU_MEM", "6GiB")


class BLIP2CaptionAnalyzer(ModelAnalyzer):
    """
    Tier 2: caption-based attribute injection detector.

    Construction is free — weights loaded on the first analyze() call.

    Parameters
    ----------
    clip_engine : shared CLIPEngine (reuses image_emb already in context)
    """

    def __init__(self, clip_engine: CLIPEngine) -> None:
        self._clip = clip_engine

        self._proc:       Optional[object]   = None
        self._tok:        Optional[object]   = None
        self._model:      Optional[object]   = None
        self._device:     Optional[str]      = None
        self._dtype:      Optional[object]   = None
        self._caption_fn: Optional[Callable] = None  # resolved once at load
        self._loaded:     bool               = False

    @property
    def name(self) -> str:
        return "blip2_caption"

    def is_available(self) -> bool:
        return _AVAILABLE

    # ── lazy load / unload ────────────────────────────────────────────────────

    def _lazy_load(self) -> None:
        if self._loaded:
            return

        logger.info("Lazy-loading captioner (%s)…", _MODEL_ID)

        has_cuda      = torch.cuda.is_available()
        self._device  = "cuda" if has_cuda else "cpu"

        if has_cuda:
            self._dtype = torch.float16
        else:
            self._dtype = torch.float32
            try:
                if torch.backends.cpu.is_bf16_supported():
                    self._dtype = torch.bfloat16
            except AttributeError:
                try:
                    if torch.is_bf16_supported():
                        self._dtype = torch.bfloat16
                except AttributeError:
                    pass

        if _MODEL_ID == _DEFAULT_MODEL_ID:
            self._load_vit_gpt2()
            self._caption_fn = self._caption_vit_gpt2
        else:
            self._load_blip2()
            self._caption_fn = self._caption_blip2

        self._loaded = True
        logger.info("Captioner loaded (weights on CPU, dtype=%s).", self._dtype)

    def _load_vit_gpt2(self) -> None:
        """Lightweight ViT-GPT2 captioner (~500 MB)."""
        self._proc  = ViTImageProcessor.from_pretrained(_MODEL_ID)
        self._tok   = AutoTokenizer.from_pretrained(_MODEL_ID)
        self._model = (
            VisionEncoderDecoderModel
            .from_pretrained(_MODEL_ID, torch_dtype=self._dtype)
            .cpu()
            .eval()
        )

    def _load_blip2(self) -> None:
        """Heavy BLIP-2 model with memory caps (~6–11 GB)."""
        try:
            from transformers import Blip2Processor, Blip2ForConditionalGeneration
        except ImportError:
            raise ImportError(
                "Blip2ForConditionalGeneration not found.  "
                "pip install transformers>=4.27 accelerate"
            )
        max_mem = (
            ({0: _MAX_GPU_MEM} if self._device == "cuda" else {})
            | {"cpu": _MAX_CPU_MEM}
        )
        self._proc  = Blip2Processor.from_pretrained(_MODEL_ID)
        self._model = (
            Blip2ForConditionalGeneration
            .from_pretrained(
                _MODEL_ID,
                torch_dtype=self._dtype,
                device_map="auto",
                max_memory=max_mem,
            )
            .eval()
        )

    def unload(self) -> None:
        if not self._loaded:
            return
        del self._model, self._proc, self._tok
        self._model = self._proc = self._tok = self._caption_fn = None
        self._loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("Captioner unloaded.")

    # ── device context manager ────────────────────────────────────────────────

    @contextmanager
    def _on_device(self):
        """Move model to inference device for the block, return to CPU after."""
        if self._device == "cuda":
            self._model.to(self._device)
        try:
            yield
        finally:
            if self._device == "cuda":
                self._model.cpu()
                torch.cuda.empty_cache()

    # ── inference ─────────────────────────────────────────────────────────────

    def _caption(self, image) -> str:
        self._lazy_load()
        return self._caption_fn(image)

    def _caption_vit_gpt2(self, image) -> str:
        # Cast to model dtype BEFORE device transfer (avoids silent fp32 upcast)
        pixel_values = (
            self._proc(images=image.convert("RGB"), return_tensors="pt")
            .pixel_values
            .to(dtype=self._dtype)
        )
        with self._on_device():
            pixel_values = pixel_values.to(self._device)
            with torch.no_grad():
                output_ids = self._model.generate(
                    pixel_values, max_new_tokens=64, num_beams=4,
                )
        return self._tok.batch_decode(
            output_ids, skip_special_tokens=True
        )[0].strip()

    def _caption_blip2(self, image) -> str:
        inputs = self._proc(images=image, return_tensors="pt")
        with self._on_device():
            inputs = {k: v.to(self._device) for k, v in inputs.items()}
            with torch.no_grad():
                ids = self._model.generate(**inputs, max_new_tokens=64)
        return self._proc.batch_decode(
            ids, skip_special_tokens=True
        )[0].strip()

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _words(text: str) -> set[str]:
        ws = re.findall(r"[a-zA-Z]+", text.lower())
        return {w for w in ws if w not in _STOPWORDS and len(w) > 2}

    # ── main ──────────────────────────────────────────────────────────────────

    def analyze(self, context: AnalyzerContext) -> AnalyzerResult:
        caption              = self._caption(context.image)
        context.blip_caption = caption

        caption_words = self._words(caption)
        prompt_words  = self._words(context.prompt)

        candidate_injections = caption_words - prompt_words
        candidate_dropped    = prompt_words  - caption_words

        injected: list[str] = []
        if candidate_injections and context.image_emb is not None:
            cand_list = list(candidate_injections)
            text_embs = self._clip.embed_texts(cand_list)
            scores    = self._clip.score(context.image_emb, text_embs)
            injected  = [
                w for w, s in zip(cand_list, scores)
                if s > INJECTION_DELTA_THRESHOLD
            ]

        context.injected_attrs = injected

        delta = CaptionDelta(
            caption           = caption,
            injected_concepts = injected,
            dropped_concepts  = list(candidate_dropped),
            injection_flagged = bool(injected),
        )

        return AnalyzerResult(
            analyzer = self.name,
            data     = {"caption_delta": delta},
            flags    = ["attribute_injection"] if injected else [],
        )