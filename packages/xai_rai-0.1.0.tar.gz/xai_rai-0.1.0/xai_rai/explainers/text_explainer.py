"""
text_explainer.py
----------
Model-agnostic XAI for NLP classification, built on top of BaseTextAdapter.

Supported explainers
    - SHAP  : PartitionExplainer (token-level, fast for text)
              KernelExplainer   (model-agnostic fallback)
    - LIME  : LimeTextExplainer (local perturbation-based)

Install dependencies
    pip install shap lime

Quick start
    from text_adapter import TextAdapter
    from xai_nlp import NLPExplainer

    adapter  = TextAdapter.from_provider("local", fn=my_fn)
    explainer = NLPExplainer(adapter)

    # SHAP
    shap_result = explainer.explain_shap("This film was fantastic!")
    print(shap_result)

    # LIME
    lime_result = explainer.explain_lime("This film was fantastic!")
    print(lime_result)

    # Both at once
    result = explainer.explain("This film was fantastic!")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Literal

import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Return types
# ---------------------------------------------------------------------------

# @dataclass
# class TokenAttribution:
#     """
#     Attribution scores for a single token/word.

#     Attributes
#     ----------
#     token   : the word / sub-word string
#     score   : signed attribution (positive → pushes toward `label`, negative → away)
#     label   : the class this attribution is anchored to
#     """
#     token: str
#     score: float
#     label: str


# @dataclass
# class SHAPExplanation:
#     """
#     Full SHAP explanation for one input text.

#     Attributes
#     ----------
#     text            : original (normalised) input
#     predicted_label : top predicted class
#     predicted_score : confidence for predicted_label
#     attributions    : list[TokenAttribution] sorted by |score| descending
#     base_values     : SHAP base values (expected model output) per class
#     label_order     : class names in the order used by shap_values columns
#     shap_values     : raw np.ndarray of shape (n_tokens, n_classes)
#     """
#     text: str
#     predicted_label: str
#     predicted_score: float
#     attributions: list[TokenAttribution]
#     base_values: np.ndarray
#     label_order: list[str]
#     shap_values: np.ndarray

#     def top_tokens(self, n: int = 5, label: str | None = None) -> list[TokenAttribution]:
#         """
#         Return the top-n most influential tokens.

#         Parameters
#         ----------
#         n     : number of tokens to return
#         label : filter to a specific class label (defaults to predicted_label)
#         """
#         target = (label or self.predicted_label).upper()
#         filtered = [a for a in self.attributions if a.label == target]
#         return sorted(filtered, key=lambda a: abs(a.score), reverse=True)[:n]


# @dataclass
# class LIMEExplanation:
#     """
#     Full LIME explanation for one input text.

#     Attributes
#     ----------
#     text            : original (normalised) input
#     predicted_label : top predicted class
#     predicted_score : confidence for predicted_label
#     attributions    : list[TokenAttribution] sorted by |score| descending
#     label_index     : integer index of the explained class
#     intercept       : LIME local model intercept
#     local_score     : LIME local model prediction for this instance
#     score           : R² of local linear model (faithfulness proxy)
#     """
#     text: str
#     predicted_label: str
#     predicted_score: float
#     attributions: list[TokenAttribution]
#     label_index: int
#     intercept: float
#     local_score: float
#     score: float  # R²

#     @property
#     def faithfulness_warnings(self) -> list[str]:
#         """
#         Returns a list of human-readable warnings when LIME's local linear
#         model is a poor approximation of the real model at this input.

#         Rules
#         -----
#         - R² < 0.3  : local linear fit is weak; attributions unreliable
#         - local_pred outside [0, 1] : linear model extrapolated beyond
#           probability space; weights may be distorted
#         """
#         warnings = []
#         if self.score < 0.3:
#             warnings.append(
#                 f"Low R² ({self.score:.3f} < 0.3): LIME local model is a poor fit — "
#                 "attributions may be unreliable. Consider increasing num_samples."
#             )
#         if not (0.0 <= self.local_score <= 1.0):
#             warnings.append(
#                 f"local_pred={self.local_score:.4f} outside [0,1]: linear approximation "
#                 "extrapolated beyond probability space. Decision boundary is highly non-linear here."
#             )
#         return warnings

#     def top_tokens(self, n: int = 5) -> list[TokenAttribution]:
#         """Return top-n tokens by absolute attribution."""
#         return sorted(self.attributions, key=lambda a: abs(a.score), reverse=True)[:n]


# @dataclass
# class CombinedExplanation:
#     """Container returned by explain() when both methods are requested."""
#     shap: SHAPExplanation
#     lime: LIMEExplanation

#     def agreement(self, n: int = 5, min_score: float = 1e-3) -> list[str]:
#         """
#         Tokens appearing in both SHAP and LIME top-n with |score| >= min_score.

#         Parameters
#         ----------
#         n         : top-n tokens to consider from each method
#         min_score : minimum absolute score threshold — filters near-zero
#                     stopwords that inflate overlap counts (default 1e-3)
#         """
#         shap_top = {
#             a.token.lower() for a in self.shap.top_tokens(n)
#             if abs(a.score) >= min_score
#         }
#         lime_top = {
#             a.token.lower() for a in self.lime.top_tokens(n)
#             if abs(a.score) >= min_score
#         }
#         return sorted(shap_top & lime_top)

from xai_rai.core.results.nlp_results import SHAPExplanation, LIMEExplanation, CombinedExplanation, TokenAttribution
# ---------------------------------------------------------------------------
# Core explainer
# ---------------------------------------------------------------------------

class NLPExplainer:
    """
    Model-agnostic XAI wrapper for NLP classification.

    Wraps any BaseTextAdapter and exposes SHAP and LIME explanations
    through a consistent, provider-independent API.

    Parameters
    ----------
    adapter : BaseTextAdapter
        Any adapter from text_adapter.py (HF, OpenAI, Anthropic, Cohere, Local).
    shap_masker : str
        Token masker strategy for SHAP PartitionExplainer.
        "word"  → mask whole words with [MASK] token  (default, fast)
        "char"  → character-level masking
    lime_num_samples : int
        Number of perturbed samples LIME generates (default: 1000).
        Higher → more faithful but slower.
    lime_num_features : int
        Max features (tokens) LIME considers (default: 10).
    """

    def __init__(
        self,
        adapter,
        shap_masker: str = "word",
        lime_num_samples: int = 1000,
        lime_num_features: int = 10,
        remote_api: bool = False,
    ) -> None:
        self._adapter           = adapter
        self._shap_masker       = shap_masker
        self._lime_num_samples  = lime_num_samples
        self._lime_num_features = lime_num_features
        # remote_api=True: reduces SHAP max_evals default and LIME num_samples
        # automatically to avoid hundreds of sequential HTTP calls.
        self._remote_api        = remote_api

        # lazy-loaded explainer instances (avoid import cost at construction)
        self._shap_explainer  = None
        self._lime_explainer  = None
        self._shap_base_values: np.ndarray | None = None  # cached after first call

    # ------------------------------------------------------------------
    # Internal: batch predict function (shared by both explainers)
    # ------------------------------------------------------------------

    def _batch_fn(self, texts: list[str] | np.ndarray) -> np.ndarray:
        """
        Wraps adapter.predict_proba_batch.
        Guarantees shape (n_samples, n_classes) — never (n_samples, 1).
        SHAP will crash with an index error if n_classes < 2.
        """
        out = self._adapter.predict_proba_batch(texts)
        if out.ndim == 1:
            out = out.reshape(1, -1)
        if out.shape[1] == 1:
            # single-column response — pad with complement so shape is (n, 2)
            out = np.hstack([1 - out, out])
        return out

    # ------------------------------------------------------------------
    # SHAP
    # ------------------------------------------------------------------

    def _get_shap_explainer(self):
        if self._shap_explainer is not None:
            return self._shap_explainer

        try:
            import shap  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "shap is required for SHAP explanations. Install: pip install shap"
            ) from exc

        masker = shap.maskers.Text(mask_token="[MASK]")
        self._shap_explainer = shap.Explainer(
            self._batch_fn,
            masker,
            output_names=self._adapter.labels,
        )
        logger.info("SHAP PartitionExplainer initialised.")
        return self._shap_explainer

    def explain_shap(
        self,
        text: str,
        label: str | None = None,
        max_evals: int | None = None,
    ) -> SHAPExplanation:
        """
        Compute SHAP token attributions for a single text.

        Parameters
        ----------
        text      : input string
        label     : class to anchor attributions to (defaults to predicted class)
        max_evals : SHAP evaluation budget. Defaults to 100 for remote APIs,
                    500 for local. Higher → more accurate but slower.

        Returns
        -------
        SHAPExplanation
        """
        if max_evals is None:
            # Scale with token count: more tokens = more coalitions needed for
            # accurate Shapley values. Formula: base + 2 * n_tokens.
            # Capped lower for remote APIs to limit HTTP call volume.
            n_tokens  = len(text.split())
            base_evals = 100 if self._remote_api else 300
            max_evals  = min(base_evals + 2 * n_tokens, 100 if self._remote_api else 500)

        text       = self._adapter.normalize(text)
        prediction = self._adapter.predict(text)
        target     = (label or prediction["label"]).upper()

        explainer = self._get_shap_explainer()

        # batch_size=1 for remote APIs: SHAP sends 1 text at a time to _batch_fn
        # so each HTTP call carries as many perturbations as the API can handle.
        # For local models, larger batch_size amortises overhead.
        batch_size = 1 if self._remote_api else 50

        shap_values = explainer([text], max_evals=max_evals, batch_size=batch_size)

        # shap_values.values: shape (1, n_tokens, n_classes)
        raw = shap_values.values[0]  # (n_tokens, n_classes) or (n_tokens,)
        if raw.ndim == 1:
            raw = raw.reshape(-1, 1)

        values      = raw
        tokens      = shap_values.data[0]
        label_order = self._adapter.labels

        # Cache base values on first call — they represent the expected model
        # output over the background distribution and are identical for every
        # input with the same explainer. No need to print per-sentence.
        raw_base = np.atleast_1d(np.array(shap_values.base_values[0]))
        if self._shap_base_values is None:
            self._shap_base_values = raw_base
            logger.info(
                "SHAP base values (expected output): %s",
                dict(zip(label_order, raw_base.round(4))),
            )
        base_values = self._shap_base_values

        # Build attributions for ALL classes
        attributions: list[TokenAttribution] = []
        for class_idx, class_label in enumerate(label_order):
            col = values[:, class_idx] if values.shape[1] > class_idx else values[:, 0]
            for tok, score in zip(tokens, col):
                attributions.append(
                    TokenAttribution(token=tok, score=float(score), label=class_label)
                )

        # Sort: target-label attrs first by |score|, rest after
        attributions = sorted(
            attributions,
            key=lambda a: abs(a.score) if a.label == target else -1,
            reverse=True,
        )

        return SHAPExplanation(
            text=text,
            predicted_label=prediction["label"],
            predicted_score=prediction["score"],
            attributions=attributions,
            base_values=base_values,
            label_order=label_order,
            shap_values=values,
        )

    # ------------------------------------------------------------------
    # LIME
    # ------------------------------------------------------------------

    def _get_lime_explainer(self):
        if self._lime_explainer is not None:
            return self._lime_explainer

        try:
            from lime.lime_text import LimeTextExplainer  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "lime is required for LIME explanations. Install: pip install lime"
            ) from exc

        self._lime_explainer = LimeTextExplainer(
            class_names=self._adapter.labels,
            bow=True,           # bag-of-words perturbation — model-agnostic
            random_state=42,
        )
        logger.info("LIME LimeTextExplainer initialised.")
        return self._lime_explainer

    def explain_lime(
        self,
        text: str,
        label: str | None = None,
        num_samples: int | None = None,
        num_features: int | None = None,
    ) -> LIMEExplanation:
        """
        Compute LIME token attributions for a single text.

        Parameters
        ----------
        text         : input string
        label        : class to explain (defaults to predicted class)
        num_samples  : override default (remote: 100, local: 1000)
        num_features : override constructor default

        Returns
        -------
        LIMEExplanation
        """
        text       = self._adapter.normalize(text)
        prediction = self._adapter.predict(text)
        target     = (label or prediction["label"]).upper()
        label_idx  = self._adapter.labels.index(target)

        explainer    = self._get_lime_explainer()

        if num_samples is None:
            num_samples = 100 if self._remote_api else self._lime_num_samples
        num_features = num_features or self._lime_num_features

        lime_exp = explainer.explain_instance(
            text,
            self._batch_fn,
            labels=(label_idx,),
            num_samples=num_samples,
            num_features=num_features,
        )

        raw_attrs = lime_exp.as_list(label=label_idx)
        attributions = [
            TokenAttribution(token=tok, score=float(score), label=target)
            for tok, score in raw_attrs
        ]
        attributions = sorted(attributions, key=lambda a: abs(a.score), reverse=True)

        # LIME indexes local_pred by position in the `labels` tuple passed to
        # explain_instance, not by raw class index. We always pass labels=(label_idx,)
        # so the position is always 0.
        intercept   = float(lime_exp.intercept[label_idx])
        local_score = float(lime_exp.local_pred[0])
        r2_score    = float(lime_exp.score)

        return LIMEExplanation(
            text=text,
            predicted_label=prediction["label"],
            predicted_score=prediction["score"],
            attributions=attributions,
            label_index=label_idx,
            intercept=intercept,
            local_score=local_score,
            score=r2_score,
        )

    # ------------------------------------------------------------------
    # Combined
    # ------------------------------------------------------------------

    def explain(
        self,
        text: str,
        label: str | None = None,
        shap_max_evals: int = 500,
        lime_num_samples: int | None = None,
        lime_num_features: int | None = None,
    ) -> CombinedExplanation:
        """
        Run both SHAP and LIME and return a CombinedExplanation.

        Use .agreement(n) to see which tokens both methods agree on.
        """
        shap_exp = self.explain_shap(text, label=label, max_evals=shap_max_evals)
        lime_exp = self.explain_lime(
            text,
            label=label,
            num_samples=lime_num_samples,
            num_features=lime_num_features,
        )
        return CombinedExplanation(shap=shap_exp, lime=lime_exp)


# ---------------------------------------------------------------------------
# CLI smoke-test  (python xai_nlp.py)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    import sys
    import os
    sys.path.insert(0, os.path.dirname(__file__))

    logging.basicConfig(level=logging.INFO)

    # --- mock adapter (no API key needed) ---
    def _mock_fn(text: str) -> list[dict]:
        positive_words = {"fantastic", "great", "love", "good", "excellent", "amazing"}
        words = set(text.lower().split())
        score = 0.85 if positive_words & words else 0.2
        return [
            {"label": "NEGATIVE", "score": round(1 - score, 4)},
            {"label": "POSITIVE", "score": round(score, 4)},
        ]

    from text_adapter import TextAdapter
    adapter  = TextAdapter.from_provider("local", fn=_mock_fn)
    xai      = NLPExplainer(adapter, lime_num_samples=300, lime_num_features=6)
    text     = "This film was absolutely fantastic and the acting was great"

    print("\n=== SHAP ===")
    shap_exp = xai.explain_shap(text, max_evals=200)
    print(f"Predicted: {shap_exp.predicted_label} ({shap_exp.predicted_score:.3f})")
    print("Top 5 tokens:")
    for a in shap_exp.top_tokens(5):
        print(f"  {a.token:20s}  {a.score:+.4f}  [{a.label}]")

    print("\n=== LIME ===")
    lime_exp = xai.explain_lime(text)
    print(f"Predicted: {lime_exp.predicted_label} ({lime_exp.predicted_score:.3f})")
    print(f"Local R²: {lime_exp.score:.3f}  |  intercept: {lime_exp.intercept:.4f}")
    print("Top 5 tokens:")
    for a in lime_exp.top_tokens(5):
        print(f"  {a.token:20s}  {a.score:+.4f}  [{a.label}]")

    print("\n=== Combined agreement (top 5) ===")
    combined = xai.explain(text, shap_max_evals=200, lime_num_samples=300)
    print("Agreed tokens:", combined.agreement(5))