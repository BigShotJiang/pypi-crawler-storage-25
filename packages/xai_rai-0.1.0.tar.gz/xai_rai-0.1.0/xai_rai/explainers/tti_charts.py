"""
xai_rai/explainers/tti_charts.py
==================================
Chart builders for the text-to-image explanation pipeline.
Returns base64-encoded PNG strings suitable for embedding in
TextToImageExplanation and Streamlit/HTML UIs.

Resource fixes (v2)
--------------------
- matplotlib.use("Agg") is called inside _ensure_agg() which only runs
  once, deferred until first use — avoids conflicting with any backend
  set by the caller at import time.
- Figures are closed in a finally block so they are always released,
  even if savefig raises (previously leaked on error paths).
- _fig_to_b64 resets the BytesIO buffer position before reading, which
  was already correct but is now explicit and documented.
- Both chart functions guard against empty input and unavailable
  matplotlib without raising.
"""

from __future__ import annotations

import io
import base64
import logging
from typing import List

logger = logging.getLogger(__name__)

_VIZ_AVAILABLE  = False
_BACKEND_SET    = False   # tracks whether Agg has been activated


def _ensure_agg() -> bool:
    """
    Lazily import matplotlib and switch to the Agg (non-interactive) backend.
    Returns True if matplotlib is available, False otherwise.
    Called once before any figure is created; safe to call repeatedly.
    """
    global _VIZ_AVAILABLE, _BACKEND_SET
    if _BACKEND_SET:
        return _VIZ_AVAILABLE
    try:
        import matplotlib
        # Only switch backend if it has not already been set by the host app.
        # This avoids clobbering an interactive backend in a Jupyter notebook.
        if matplotlib.get_backend().lower() != "agg":
            matplotlib.use("Agg")
        _VIZ_AVAILABLE = True
    except ImportError:
        _VIZ_AVAILABLE = False
        logger.warning("matplotlib not installed — charts disabled.  "
                       "pip install matplotlib")
    _BACKEND_SET = True
    return _VIZ_AVAILABLE


from xai_rai.contracts_tti import WordAttribution, ConceptScore


# ── internal helper ───────────────────────────────────────────────────────────

def _fig_to_b64(fig) -> str:
    """
    Serialise a matplotlib Figure to a base64-encoded PNG string and
    close the figure unconditionally.
    """
    import matplotlib.pyplot as plt
    buf = io.BytesIO()
    try:
        fig.savefig(buf, format="PNG", dpi=100, bbox_inches="tight")
        buf.seek(0)
        return base64.b64encode(buf.getvalue()).decode()
    finally:
        # Always close — prevents figure objects accumulating in memory
        # even when savefig raises an exception.
        plt.close(fig)
        buf.close()


# ── public chart builders ─────────────────────────────────────────────────────

def build_attribution_chart(word_attributions: List[WordAttribution]) -> str:
    """
    Horizontal bar chart of per-word CLIP similarity scores.
    Returns a base64-encoded PNG string, or '' if matplotlib is unavailable
    or word_attributions is empty.
    """
    if not _ensure_agg() or not word_attributions:
        return ""

    import matplotlib.pyplot as plt

    words  = [w.word for w in word_attributions]
    scores = [w.clip_score for w in word_attributions]
    colors = [
        "#2ecc71" if s >= 0.25 else "#f39c12" if s >= 0.18 else "#e74c3c"
        for s in scores
    ]

    fig, ax = plt.subplots(figsize=(8, max(3, len(words) * 0.45)))
    try:
        ax.barh(words[::-1], scores[::-1], color=colors[::-1])
        ax.axvline(0.25, color="green",  linewidth=0.8, linestyle="--",
                   label="Strong (>0.25)")
        ax.axvline(0.18, color="orange", linewidth=0.8, linestyle="--",
                   label="Moderate (>0.18)")
        ax.set_xlabel("CLIP cosine similarity vs generated image")
        ax.set_title(
            "Word Attribution\n"
            "(visual presence of each prompt word in the image)"
        )
        ax.legend(fontsize=8)
        plt.tight_layout()
        return _fig_to_b64(fig)
    except Exception:
        plt.close(fig)
        logger.exception("build_attribution_chart failed")
        return ""


def build_concept_chart(concept_scores: List[ConceptScore]) -> str:
    """
    Horizontal bar chart of top concept scores.
    Returns a base64-encoded PNG string, or '' if matplotlib is unavailable
    or concept_scores is empty.
    """
    if not _ensure_agg() or not concept_scores:
        return ""

    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    top = sorted(concept_scores, key=lambda c: c.score, reverse=True)[:15]

    category_colors = {
        "Visual Style": "#3498db",
        "Scene":        "#2ecc71",
        "Objects":      "#9b59b6",
        "Demographics": "#e67e22",
        "Safety":       "#e74c3c",
    }
    colors = [category_colors.get(c.category, "#95a5a6") for c in top]

    fig, ax = plt.subplots(figsize=(9, max(4, len(top) * 0.45)))
    try:
        ax.barh([c.concept for c in top][::-1],
                [c.score   for c in top][::-1],
                color=colors[::-1])
        ax.axvline(0.20, color="grey", linewidth=0.8, linestyle="--",
                   label="Significance (0.20)")
        ax.set_xlabel("CLIP cosine similarity")
        ax.set_title("Concept Grounding\n(implicit concepts visually present)")
        ax.legend(
            handles=[Patch(color=v, label=k) for k, v in category_colors.items()],
            loc="lower right",
            fontsize=7,
        )
        plt.tight_layout()
        return _fig_to_b64(fig)
    except Exception:
        plt.close(fig)
        logger.exception("build_concept_chart failed")
        return ""