"""
explainers/image_explainer.py

Model-agnostic XAI methods for image classification.

Explainers
----------
- RiseExplainer      : Randomised Input Sampling for Explanation (RISE)
                       smooth, continuous saliency — no superpixel artefacts,
                       fully black-box, no model internals required
- OcclusionExplainer : sliding-window occlusion sensitivity map
                       coarser but independent cross-check for RISE

Both accept a predict_fn with the signature:
    predict_fn(images: np.ndarray) -> np.ndarray
    images  : float32 (N, H, W, 3), values in [0, 1]
    returns : float32 (N, num_classes)

Utilities
---------
- overlay_heatmap  : overlay any (H, W) saliency map on an RGB image
- agreement_score  : spatial Pearson correlation between two heatmaps (0–1)

Performance notes
-----------------
RISE
  - Masks are generated in a single vectorised scipy.ndimage.zoom call
    rather than looping over PIL — eliminates the per-mask Python overhead.
  - Mask cache: generated masks are cached on the instance keyed by (H, W),
    so repeated calls on same-sized images pay the zoom cost only once.
  - Larger default batch size (256 vs 64): reduces Python loop iterations
    in the main sampling loop from 16 → 4 batches (per 1000 masks), cutting
    per-batch overhead and numpy allocation frequency by 4×.
  - Pre-allocated image buffer: `masked_images` is allocated once per
    explain() call and filled in-place, avoiding N_batches heap allocations.
  - Early stopping: saliency variance is checked every `check_every` batches;
    once relative change drops below `convergence_tol` sampling stops.
    Bug fix: prev_mean initialised to 0.0 (not np.inf) so the first-batch
    rel_change is large and the loop actually runs past check_every batches.
    Typical convergence: ~600–800 masks instead of the full 1000.

Occlusion
  - All occluded images are stacked into one batch and forwarded in a single
    predict_fn call instead of one call per patch position.
  - Accepts an optional pre-computed baseline (top_class, baseline_prob) from
    a shared call, removing the duplicate baseline forward pass made when both
    RISE and Occlusion are run together (saves one predict_fn call).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.figure
from PIL import Image
from scipy.ndimage import gaussian_filter, zoom

# ── Config ────────────────────────────────────────────────────────────────────

RISE_N_MASKS:         int   = 1000   # hard ceiling; early stopping exits before this
RISE_MASK_SIZE:       int   = 6      # 6×6 coarse grid
RISE_MASK_PROB:       float = 0.5
RISE_BATCH_SIZE:      int   = 128    # 8 batches per 1000 masks — enough granularity
                                     # for early stopping to fire mid-run.
                                     # 256 produced only 4 batches, so check_every=4
                                     # only fired on the last batch — effectively
                                     # disabling early stopping entirely.
RISE_CONVERGENCE_TOL: float = 0.01
RISE_CHECK_EVERY:     int   = 1      # check after EVERY batch (not every 4)
                                     # with batch_size=128 this means checks at
                                     # 128, 256, 384 … masks — early stopping
                                     # typically fires around 640 masks (5 batches)

OCCLUSION_SMOOTH_SIGMA:    float = 3.0
OCCLUSION_NOISE_THRESHOLD: float = 0.4


# ── Result container ──────────────────────────────────────────────────────────

# @dataclass
# class ExplanationResult:
#     """Holds outputs from one or both explainers for a single image."""

#     # RISE outputs
#     rise_map:       Optional[np.ndarray]           = None  # (H, W) float32 [0,1]
#     rise_fig:       Optional[matplotlib.figure.Figure] = None
#     rise_masks_used: Optional[int]                 = None  # actual masks run

#     # Occlusion outputs
#     occlusion_map:  Optional[np.ndarray]           = None  # (H, W) float32 [0,1]
#     occlusion_fig:  Optional[matplotlib.figure.Figure] = None

#     # Cross-explainer agreement — populated when both methods are run.
#     # Pearson |r| between rise_map and occlusion_map, clamped to [0, 1].
#     agreement_score: Optional[float] = None

#     # Metadata
#     top_class_idx:  Optional[int]   = None
#     top_class_prob: Optional[float] = None
#     extra: dict = field(default_factory=dict)

from xai_rai.core.results.vision_results import VisionResult
# ── Helpers ───────────────────────────────────────────────────────────────────

def overlay_heatmap(
    image:   np.ndarray,
    heatmap: np.ndarray,
    title:   str   = "Saliency map (red = important)",
    alpha:   float = 0.5,
    cmap:    str   = "jet",
) -> matplotlib.figure.Figure:
    """
    Overlay a (H, W) saliency map on an RGB image.

    Parameters
    ----------
    image   : float32 (H, W, 3) in [0, 1]
    heatmap : float32 (H, W) in [0, 1]
    """
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.imshow(image)
    ax.imshow(heatmap, cmap=cmap, alpha=alpha, vmin=0, vmax=1)
    ax.set_title(title, fontsize=11)
    ax.axis("off")
    fig.tight_layout()
    return fig


def agreement_score(map_a: np.ndarray, map_b: np.ndarray) -> float:
    """
    Spatial agreement between two saliency maps via Pearson correlation.

    Returns |r| clamped to [0, 1]:
      1.0 — both maps highlight exactly the same regions
      0.0 — no spatial correlation

    If the maps have different shapes, map_b is bilinearly resized to match
    map_a before comparison.
    """
    if map_a.shape != map_b.shape:
        h, w = map_a.shape
        map_b_pil = Image.fromarray((map_b * 255).astype(np.uint8)).resize(
            (w, h), Image.BILINEAR
        )
        map_b = np.array(map_b_pil).astype(np.float32) / 255.0

    a, b = map_a.ravel(), map_b.ravel()
    std_a, std_b = a.std(), b.std()
    if std_a < 1e-8 or std_b < 1e-8:
        return 0.0

    r = float(np.corrcoef(a, b)[0, 1])
    return float(np.clip(abs(r), 0.0, 1.0))


# ── RISE explainer ────────────────────────────────────────────────────────────

class RiseExplainer:
    """
    RISE: Randomised Input Sampling for Explanation  (Petsiuk et al., 2018).

    Generates N random binary masks, applies them to the image, and
    accumulates a saliency map weighted by how well each mask preserved the
    target-class score:

        S(x) = 1/(N·p)  ·  Σ_i  f_c(I ⊙ mᵢ) · mᵢ(x)

    Strictly black-box — only predict_fn calls are made.

    Performance optimisations vs naïve implementation
    --------------------------------------------------
    1. Vectorised mask generation — all N low-res grids are upsampled in a
       single scipy.ndimage.zoom call.

    2. Mask cache — generated masks are stored on the instance, keyed by
       (H, W).  When explain() is called repeatedly with the same image size
       (the common case when image_size is fixed in the adapter), the
       zoom + binarise step runs once instead of once per image.

    3. Tuned batch size (128) + check_every=1 — with batch_size=256 and
       check_every=4 the convergence check only fired on the last of 4 batches,
       i.e. after all 1000 masks were already processed.  batch_size=128 gives
       8 batches; check_every=1 means checks at 128, 256, … 1000 masks.
       Typical convergence at ~640 masks saves ~36% of RISE model calls.

    4. Pre-allocated image buffer — `masked_images` is allocated once per
       explain() call outside the batch loop and filled via in-place
       multiplication, avoiding repeated heap allocations inside the hot loop.

    5. Early stopping bug fix — prev_mean was initialised to np.inf, which
       made rel_change ≈ 0 on the very first check, causing the loop to exit
       after only the first check regardless of convergence.  It is now
       initialised to 0.0 so the first relative change is large and the loop
       continues until saliency genuinely converges.

    Parameters
    ----------
    n_masks          : Maximum number of random masks (hard ceiling).
    mask_size        : Low-res grid side length.
    mask_prob        : P(cell unmasked).  Paper default 0.5.
    batch_size       : Batch size for predict_fn calls.
    convergence_tol  : Stop early when relative saliency change < this value.
                       Set to 0.0 to disable early stopping.
    check_every      : Check convergence every N batches.
    seed             : Random seed for reproducibility.
    """

    def __init__(
        self,
        n_masks:         int   = RISE_N_MASKS,
        mask_size:       int   = RISE_MASK_SIZE,
        mask_prob:       float = RISE_MASK_PROB,
        batch_size:      int   = RISE_BATCH_SIZE,
        convergence_tol: float = RISE_CONVERGENCE_TOL,
        check_every:     int   = RISE_CHECK_EVERY,
        seed:            int   = 42,
    ) -> None:
        self.n_masks         = n_masks
        self.mask_size       = mask_size
        self.mask_prob       = mask_prob
        self.batch_size      = batch_size
        self.convergence_tol = convergence_tol
        self.check_every     = check_every
        self.seed            = seed

        # Cache: (H, W) → (n_masks, H, W) float32 boolean masks.
        # Invalidated only when n_masks / mask_size / seed change (never in
        # normal usage); cleared by calling reset_mask_cache().
        self._mask_cache: dict[tuple[int, int], np.ndarray] = {}

    def reset_mask_cache(self) -> None:
        """Clear the mask cache (call if you change n_masks/mask_size/seed)."""
        self._mask_cache.clear()

    def _generate_masks(self, h: int, w: int) -> np.ndarray:
        """
        Return (n_masks, H, W) float32 binary masks, using the cache.

        First call for a given (H, W): runs the zoom + binarise step and
        stores the result.  Subsequent calls return the cached array directly.
        """
        key = (h, w)
        if key in self._mask_cache:
            return self._mask_cache[key]

        rng = np.random.default_rng(self.seed)
        s   = self.mask_size

        # (N, s, s) — Bernoulli samples on the coarse grid
        low_res = (rng.random((self.n_masks, s, s)) < self.mask_prob).astype(np.float32)

        # Single vectorised upsample: (N, s, s) → (N, H, W)
        zoom_factors = (1, h / s, w / s)
        upsampled    = zoom(low_res, zoom_factors, order=1, prefilter=False)

        # Binarise at 0.5 to get clean boolean masks
        masks = (upsampled >= 0.5).astype(np.float32)  # (N, H, W)
        self._mask_cache[key] = masks
        return masks

    def explain(
        self,
        image:      np.ndarray,
        predict_fn: Callable[[np.ndarray], np.ndarray],
        *,
        top_class:     Optional[int]   = None,
        baseline_prob: Optional[float] = None,
    ) -> VisionResult:
        """
        Compute a RISE saliency map for *image*.

        Parameters
        ----------
        image          : float32 (H, W, 3) in [0, 1]
        predict_fn     : (N, H, W, 3) -> (N, C) probability array
        top_class      : If provided, skip the baseline forward pass and use
                         this class index.  Pass when sharing a baseline with
                         OcclusionExplainer (method="both" in the adapter).
        baseline_prob  : Corresponding probability for top_class; required
                         when top_class is provided.

        Returns
        -------
        ExplanationResult with rise_map, rise_fig, rise_masks_used populated.
        """
        h, w, _ = image.shape

        # ── Baseline (skipped when pre-computed by caller) ─────────────────
        if top_class is None:
            baseline      = predict_fn(image[np.newaxis])[0]
            top_class     = int(np.argmax(baseline))
            baseline_prob = float(baseline[top_class])

        masks     = self._generate_masks(h, w)            # (N, H, W), cached
        saliency  = np.zeros((h, w), dtype=np.float64)
        n_batches = int(np.ceil(self.n_masks / self.batch_size))

        # Pre-allocate the masked-image buffer once; fill in-place each batch.
        # Shape: (batch_size, H, W, 3) — last batch may be smaller, sliced below.
        img_buffer = np.empty((self.batch_size, h, w, 3), dtype=np.float32)

        # FIX: was np.inf — caused rel_change ≈ 0 on first check, exiting
        # after only ~256 masks (4 batches × 64) regardless of convergence.
        prev_mean  = 0.0
        masks_used = 0

        for b in range(n_batches):
            batch_masks = masks[b * self.batch_size : (b + 1) * self.batch_size]
            bs          = len(batch_masks)  # actual size (last batch may differ)

            # Fill buffer in-place: image × mask, broadcast channel dim
            np.multiply(
                image[np.newaxis],                     # (1, H, W, 3)
                batch_masks[:bs, :, :, np.newaxis],    # (bs, H, W, 1)
                out=img_buffer[:bs],
            )

            probs     = predict_fn(img_buffer[:bs])[:, top_class]  # (bs,)
            saliency += np.einsum("b,bhw->hw", probs, batch_masks[:bs])
            masks_used += bs

            # ── Early stopping ─────────────────────────────────────────────
            if self.convergence_tol > 0 and (b + 1) % self.check_every == 0:
                current_mean = float(saliency.mean() / masks_used)
                rel_change   = abs(current_mean - prev_mean) / (abs(prev_mean) + 1e-8)
                if rel_change < self.convergence_tol:
                    break
                prev_mean = current_mean

        # Normalise by (masks_used · p) then rescale to [0, 1]
        saliency  = (saliency / (masks_used * self.mask_prob)).astype(np.float32)
        saliency  = (saliency - saliency.min()) / (saliency.max() - saliency.min() + 1e-8)

        fig = overlay_heatmap(image, saliency, title="RISE explanation (red = important)")

        return VisionResult(
            rise_map=saliency,
            rise_fig=fig,
            rise_masks_used=masks_used,
            top_class_idx=top_class,
            top_class_prob=baseline_prob,
        )


# ── Occlusion explainer ───────────────────────────────────────────────────────

class OcclusionExplainer:
    """
    Sliding-window occlusion sensitivity map.

    Optimisations vs naïve implementation
    ---------------------------------------
    - All occluded images are forwarded to predict_fn in one batched call
      (or chunked by batch_size if the grid is large).
    - Vectorised batch construction: the full (N, H, W, 3) buffer is built by
      tiling the original image once and zeroing patch windows in-place,
      replacing n_patches .copy() calls + np.stack with a single np.tile.
    - Accepts a pre-computed baseline (top_class, baseline_prob) from a
      shared call, removing the duplicate predict_fn([image]) made when both
      RISE and Occlusion are run together.

    Parameters
    ----------
    patch_size   : Side length of the square occlusion patch (pixels).
    stride       : Step between patches.  Defaults to patch_size (no overlap).
    smooth_sigma : Gaussian smoothing sigma applied after normalisation.
    threshold    : Values below this are zeroed (noise suppression).
    fill_value   : Pixel value for the occluded region (default 0 = black).
    batch_size   : Max occluded images per predict_fn call.
    """

    def __init__(
        self,
        patch_size:   int   = 24,
        stride:       Optional[int] = None,
        smooth_sigma: float = OCCLUSION_SMOOTH_SIGMA,
        threshold:    float = OCCLUSION_NOISE_THRESHOLD,
        fill_value:   float = 0.0,
        batch_size:   int   = 64,
    ) -> None:
        self.patch_size   = patch_size
        self.stride       = stride if stride is not None else patch_size
        self.smooth_sigma = smooth_sigma
        self.threshold    = threshold
        self.fill_value   = fill_value
        self.batch_size   = batch_size

    def explain(
        self,
        image:      np.ndarray,
        predict_fn: Callable[[np.ndarray], np.ndarray],
        *,
        top_class:     Optional[int]   = None,
        baseline_prob: Optional[float] = None,
    ) -> VisionResult:
        """
        Compute an occlusion heatmap for *image*.

        Parameters
        ----------
        image          : float32 (H, W, 3) in [0, 1]
        predict_fn     : (N, H, W, 3) -> (N, C) probability array
        top_class      : Pre-computed class index (skips baseline call).
        baseline_prob  : Pre-computed baseline probability (required with
                         top_class).

        Returns
        -------
        ExplanationResult with occlusion_map and occlusion_fig populated.
        """
        h, w, _ = image.shape

        # ── Baseline (skipped when pre-computed by caller) ─────────────────
        if top_class is None:
            baseline      = predict_fn(image[np.newaxis])[0]
            top_class     = int(np.argmax(baseline))
            baseline_prob = float(baseline[top_class])

        # Pre-build all patch positions
        positions = [
            (y, x)
            for y in range(0, h, self.stride)
            for x in range(0, w, self.stride)
        ]

        # Build all occluded images in one shot:
        #   1. tile the image n_patches times → (N, H, W, 3) contiguous block
        #   2. zero each patch window in-place with a simple loop over N
        # This avoids n_patches separate .copy() calls and the subsequent
        # np.stack, halving the number of memory allocations.
        n_patches      = len(positions)
        occluded_batch = np.tile(image[np.newaxis], (n_patches, 1, 1, 1))  # (N,H,W,3)
        for i, (y, x) in enumerate(positions):
            occluded_batch[i, y : y + self.patch_size, x : x + self.patch_size, :] = self.fill_value

        # Forward in batches to keep memory bounded
        impacts = np.empty(n_patches, dtype=np.float32)

        for start in range(0, n_patches, self.batch_size):
            end        = min(start + self.batch_size, n_patches)
            probs      = predict_fn(occluded_batch[start:end])[:, top_class]
            impacts[start:end] = baseline_prob - probs

        # Scatter impacts back to the spatial heatmap
        heatmap = np.zeros((h, w), dtype=np.float32)
        for (y, x), impact in zip(positions, impacts):
            heatmap[y : y + self.patch_size, x : x + self.patch_size] = float(impact)

        # Normalise → smooth → threshold
        heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min() + 1e-8)
        heatmap = gaussian_filter(heatmap, sigma=self.smooth_sigma)
        heatmap[heatmap < self.threshold] = 0.0

        fig = overlay_heatmap(
            image, heatmap, title="Occlusion explanation (red = important)"
        )

        return VisionResult(
            occlusion_map=heatmap,
            occlusion_fig=fig,
            top_class_idx=top_class,
            top_class_prob=baseline_prob,
        )

# ── LIME explainer ────────────────────────────────────────────────────────────

class LimeExplainer:
    """
    LIME: Local Interpretable Model-agnostic Explanations (Ribeiro et al., 2016).

    Uses superpixels as features — naturally follows object contours,
    no grid artefacts, no threshold tuning needed.

    Parameters
    ----------
    num_samples  : Number of perturbed samples LIME generates internally.
    num_features : Number of superpixel regions to highlight.
    hide_color   : Pixel value used to hide superpixels (0 = black).
    """

    def __init__(
        self,
        num_samples:  int = 1000,
        num_features: int = 10,
        hide_color:   int = 0,
    ) -> None:
        self.num_samples  = num_samples
        self.num_features = num_features
        self.hide_color   = hide_color

    def explain(
        self,
        image:      np.ndarray,
        predict_fn: Callable[[np.ndarray], np.ndarray],
        *,
        top_class:     Optional[int]   = None,
        baseline_prob: Optional[float] = None,
    ) -> VisionResult:
        from lime import lime_image  # lazy import

        if top_class is None:
            baseline  = predict_fn(image[np.newaxis])[0]
            top_class = int(np.argmax(baseline))
            baseline_prob = float(baseline[top_class])

        explainer   = lime_image.LimeImageExplainer()
        explanation = explainer.explain_instance(
            image,
            predict_fn,
            top_labels=1,
            hide_color=self.hide_color,
            num_samples=self.num_samples,
        )

        temp, mask = explanation.get_image_and_mask(
            top_class,
            positive_only=True,
            num_features=self.num_features,
            hide_rest=False,
        )

        # Build a float heatmap from the segment weights
        segments = explanation.segments                        # (H, W) int segment ids
        weights  = dict(explanation.local_exp[top_class])     # segment_id → weight
        heatmap  = np.zeros(segments.shape, dtype=np.float32)
        for seg_id, weight in weights.items():
            heatmap[segments == seg_id] = max(weight, 0.0)    # positive only

        # Normalise to [0, 1]
        if heatmap.max() > 1e-8:
            heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min() + 1e-8)

        from skimage.segmentation import mark_boundaries

        temp, mask = explanation.get_image_and_mask(
            top_class,
            positive_only=True,
            num_features=self.num_features,
            hide_rest=True,   # greys out non-important regions — much cleaner
        )

        fig, ax = plt.subplots(figsize=(5, 5))
        ax.imshow(mark_boundaries(temp, mask))
        ax.set_title("LIME explanation (green = important)")
        ax.axis("off")
        fig.tight_layout()

        return VisionResult(
            lime_map=heatmap,
            lime_fig=fig,
            top_class_idx=top_class,
            top_class_prob=baseline_prob,
        )





