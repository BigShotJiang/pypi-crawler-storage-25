"""
xai_rai/text_to_image/explainer/base.py
========================================
Abstract base protocol (ModelAnalyzer) and the ModelRegistry orchestrator.

Fixes vs v1
-----------
- ModelRegistry.run() is guarded by a threading.Lock so concurrent callers
  cannot race on shared AnalyzerContext state (image_emb, clip_flags, etc.
  are mutated in place; simultaneous writes corrupt results and produce
  wrong RAI flags).
- gc.collect() called once after all tiers complete — releases intermediate
  tensors tiers left behind without forcing a mid-pipeline pause.
- AnalyzerResult errors preserve tier name for diagnostics.
- registered_tiers property exposed alongside available_tiers.
"""

from __future__ import annotations

import gc
import logging
import threading
import time
from abc import ABC, abstractmethod

from xai_rai.contracts_tti import AnalyzerContext, AnalyzerResult

logger = logging.getLogger(__name__)


class ModelAnalyzer(ABC):
    """
    Base protocol for all TTI analysis tiers.

    Subclass, implement .name and .analyze(), then register with
    ModelRegistry.register().  Tiers communicate exclusively through
    the shared AnalyzerContext — they have no direct references to
    each other.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tier identifier used by MODE_TIERS routing."""
        ...

    @abstractmethod
    def analyze(self, context: AnalyzerContext) -> AnalyzerResult:
        """
        Run this tier's analysis.
        May read and mutate context (e.g. CLIPAnalyzer sets image_emb).
        """
        ...

    def is_available(self) -> bool:
        """Return False if required dependencies are missing — tier skipped."""
        return True


class ModelRegistry:
    """
    Ordered registry of ModelAnalyzer tiers.

    Thread safety
    -------------
    run() acquires a per-registry lock for the full duration of the pipeline.
    Concurrent calls are serialised, not parallelised — if you need true
    parallelism, create one ModelRegistry per thread/worker.
    """

    def __init__(self) -> None:
        self._tiers: list[ModelAnalyzer] = []
        self._lock  = threading.Lock()

    def register(self, analyzer: ModelAnalyzer) -> "ModelRegistry":
        """Append a tier. Returns self for chaining."""
        self._tiers.append(analyzer)
        return self

    def run(
        self,
        context:    AnalyzerContext,
        tier_names: list[str] | None = None,
    ) -> list[AnalyzerResult]:
        """
        Execute registered tiers in order under a threading lock.

        Parameters
        ----------
        context    : shared AnalyzerContext — mutated in place across tiers
        tier_names : whitelist — None means run all available tiers

        Notes
        -----
        A single gc.collect() runs after all tiers finish to promptly reclaim
        intermediate tensors without causing mid-pipeline GC pauses.
        """
        with self._lock:
            results: list[AnalyzerResult] = []

            for tier in self._tiers:
                if tier_names and tier.name not in tier_names:
                    continue
                if not tier.is_available():
                    logger.debug("Skipping unavailable tier: %s", tier.name)
                    continue

                t0 = time.perf_counter()
                try:
                    result = tier.analyze(context)
                except Exception as exc:
                    logger.warning(
                        "Tier %s failed: %s", tier.name, exc, exc_info=True
                    )
                    result = AnalyzerResult(
                        analyzer = tier.name,
                        data     = {"error": str(exc)},
                        flags    = [],
                    )
                result.latency_ms = round((time.perf_counter() - t0) * 1000, 1)
                results.append(result)

            gc.collect()
            return results

    @property
    def available_tiers(self) -> list[str]:
        return [t.name for t in self._tiers if t.is_available()]

    @property
    def registered_tiers(self) -> list[str]:
        return [t.name for t in self._tiers]