import numpy as np
from typing import Callable, Optional, Any
from numpy.typing import NDArray
import warnings
from xai_rai.core.config import XAIConfig, FeatureMapping
from xai_rai.core.results.results import XAIResult, BatchXAIResult
from xai_rai.core.router import ExplainerRouter
from xai_rai.utils.cache import ExplanationCache
from xai_rai.adapters.llm import NarrativeGenerator
# from xai_rai.explainers.counterfactuals import CounterfactualGenerator
import lime
from typing import Union
import pandas as pd
import dice_ml
import dice_ml.explainer_interfaces.dice_random as dr

class CounterfactualGenerator:
    """
    Generates counterfactual explanations using DiCE.
    "What feature values would flip the prediction?"

    Falls back gracefully if DiCE is not installed.
    """

    def __init__(
        self,
        model: Any,
        predict_fn: Callable,
        background_data: NDArray,
        feature_names: list[str],
        task_type: str = "classification",
    ):
        self.model = model
        self.predict_fn = predict_fn
        self.background_data = background_data
        self.feature_names = feature_names
        self.task_type = task_type
        self._dice = None
        self._available = self._init_dice()

    def _init_dice(self) -> bool:
        try:
            import dice_ml
            import pandas as pd

            df = pd.DataFrame(self.background_data, columns=self.feature_names)

            outcome_col = "target"
            preds = self.predict_fn(self.background_data)
            if preds.ndim > 1:
                preds = np.argmax(preds, axis=1)
            df[outcome_col] = preds.astype(int)

            data = dice_ml.Data(
                dataframe=df,
                continuous_features=self.feature_names,
                outcome_name=outcome_col,
            )

            # Use predict_fn as backend (model-agnostic)
            model_obj = dice_ml.Model(
                model=self,
                backend="sklearn",
                model_type="classifier" if self.task_type == "classification" else "regressor",
            )

            import dice_ml.explainer_interfaces.dice_random as dr
            self._dice = dice_ml.Dice(data, model_obj, method="random")
            return True

        except ImportError:
            warnings.warn(
                "DiCE not installed. Counterfactuals unavailable. "
                "Install with: pip install dice-ml"
            )
            return False
        except Exception as e:
            warnings.warn(f"DiCE init failed: {e}. Counterfactuals disabled.")
            return False

    # Required for DiCE sklearn backend
    def predict(self, X):
        return self.predict_fn(np.asarray(X))

    def generate(
        self,
        instance: NDArray,
        n_counterfactuals: int = 3,
        desired_class: Optional[int] = None,
    ) -> Optional[list[dict]]:
        """
        Generate counterfactual examples.

        Returns list of dicts showing what changes would flip the prediction,
        or None if DiCE unavailable.
        """
        if not self._available or self._dice is None:
            return None

        try:
            import pandas as pd

            instance_df = pd.DataFrame([instance], columns=self.feature_names)
            current_pred = self.predict_fn(instance.reshape(1, -1))[0]

            if desired_class is None:
                if self.task_type == "classification":
                    current_class = int(np.argmax(current_pred)) if hasattr(current_pred, "__len__") else int(current_pred > 0.5)
                    desired_class = 1 - current_class  # flip
                else:
                    desired_class = "opposite"

            cfs = self._dice.generate_counterfactuals(
                instance_df,
                total_CFs=n_counterfactuals,
                desired_class=desired_class,
            )

            cf_list = []
            for cf_instance in cfs.cf_examples_list[0].final_cfs_df.to_dict("records"):
                changes = {}
                for feat in self.feature_names:
                    orig_val = float(instance[self.feature_names.index(feat)])
                    cf_val = float(cf_instance.get(feat, orig_val))
                    if abs(orig_val - cf_val) > 1e-6:
                        changes[feat] = {
                            "original": orig_val,
                            "counterfactual": cf_val,
                            "delta": cf_val - orig_val,
                        }
                cf_list.append({
                    "changes": changes,
                    "n_changes": len(changes),
                })

            return cf_list

        except Exception as e:
            warnings.warn(f"Counterfactual generation failed: {e}")
            return None

