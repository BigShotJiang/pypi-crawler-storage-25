"""
xai_rai/text_to_image/explainer/clip_engine.py
===============================================
Thin wrapper around open_clip.  Loads once, shared across all TTI tiers
via dependency injection.  Never instantiated more than once per process.

Memory optimisations
--------------------
- Fully lazy: __init__ stores config only.  Weights are loaded on the first
  call to embed_image() or embed_texts(), not at import/construction time.
  Importing the module or constructing the engine is zero-cost.
- Dtype resolved inside _lazy_load() so torch.cuda queries only happen when
  actually needed — not at __init__ time.
- _on_device() context manager: model moves to GPU only for the duration of
  a forward pass, then returns to CPU and flushes VRAM.  Avoids the old
  anti-pattern of cpu() → empty_cache() → to(device) which re-allocated VRAM
  on every call.
- _configure_cuda_allocator() sets expandable_segments + max_split_size_mb
  before the first cudaMalloc, eliminating OOM fragmentation on small GPUs.
- unload() fully frees all weights — suitable for long-running services.
- score() is pure CPU tensor math — never touches the model.
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from typing import List, Optional

from xai_rai.core.tti_config import CLIP_MODEL_NAME, CLIP_PRETRAINED

logger = logging.getLogger(__name__)

try:
    import torch
    import open_clip
    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False
    logger.error(
        "open_clip not installed — CLIPEngine disabled.  "
        "pip install open-clip-torch"
    )


class CLIPEngine:
    """
    Lazy-loading wrapper around an open_clip model.

    Construction is free — no weights are loaded until the first call to
    embed_image() or embed_texts().

    Parameters
    ----------
    device : "cpu" | "cuda"  (default "cpu")
    dtype  : torch dtype.  None = float16 on CUDA, bfloat16 on CPU if
             supported, else float32.

    Public methods
    --------------
    embed_image(image)              -> Tensor (1, D) on CPU
    embed_texts(texts)              -> Tensor (N, D) on CPU
    score(image_emb, text_emb)      -> list[float]
    is_available()                  -> bool (no side-effects)
    unload()                        -> releases all memory
    """

    def __init__(
        self,
        device: str = "cpu",
        dtype:  Optional["torch.dtype"] = None,
    ) -> None:
        if not _AVAILABLE:
            raise ImportError("pip install open-clip-torch")

        # Config only — nothing allocated here.
        self._requested_device = device
        self._requested_dtype  = dtype

        # Runtime state — all None until _lazy_load() runs.
        self._model  = None
        self._prep   = None
        self._tok    = None
        self._device = None
        self._dtype  = None
        self._loaded = False

    # ── availability ─────────────────────────────────────────────────────────

    @staticmethod
    def is_available() -> bool:
        return _AVAILABLE

    # ── lazy load / unload ───────────────────────────────────────────────────

    def _lazy_load(self) -> None:
        """Load weights on first use.  No-op if already loaded."""
        if self._loaded:
            return

        has_cuda     = torch.cuda.is_available()
        self._device = (
            "cuda"
            if (self._requested_device == "cuda" and has_cuda)
            else "cpu"
        )

        if self._device == "cuda":
            self._configure_cuda_allocator()

        if self._requested_dtype is not None:
            self._dtype = self._requested_dtype
        elif self._device == "cuda":
            self._dtype = torch.float16
        else:
            # bfloat16 avoids fp16 underflow on CPU; the API to check
            # support changed across PyTorch versions — try each in order.
            self._dtype = torch.float32
            try:
                # PyTorch >= 2.1
                if torch.backends.cpu.is_bf16_supported():
                    self._dtype = torch.bfloat16
            except AttributeError:
                try:
                    # PyTorch 1.x / 2.0 fallback
                    if torch.is_bf16_supported():
                        self._dtype = torch.bfloat16
                except AttributeError:
                    pass  # float32 is the safe default

        logger.info(
            "Lazy-loading CLIP %s (device=%s, dtype=%s)…",
            CLIP_MODEL_NAME, self._device, self._dtype,
        )
        model, _, prep = open_clip.create_model_and_transforms(
            CLIP_MODEL_NAME, pretrained=CLIP_PRETRAINED
        )
        # Weights rest on CPU always; _on_device() moves them temporarily.
        self._model  = model.to(dtype=self._dtype).cpu().eval()
        self._prep   = prep
        self._tok    = open_clip.get_tokenizer(CLIP_MODEL_NAME)
        self._loaded = True
        logger.info("CLIP loaded (weights resting on CPU).")

    @staticmethod
    def _configure_cuda_allocator() -> None:
        """
        Set expandable_segments + max_split_size_mb before the first
        cudaMalloc.  Fixes OOM fragmentation on 3–6 GB GPUs running mixed
        workloads.  Must be called before any tensor moves to CUDA.
        """
        current = os.environ.get("PYTORCH_CUDA_ALLOC_CONF", "")
        parts   = current.split(",") if current else []

        if "expandable_segments" not in current:
            parts.append("expandable_segments:True")
            logger.info("CUDA allocator: enabling expandable_segments.")

        if "max_split_size_mb" not in current:
            try:
                total_vram = torch.cuda.get_device_properties(0).total_memory
                split_mb   = int(total_vram * 0.20) // (1024 * 1024)
                parts.append(f"max_split_size_mb:{split_mb}")
                logger.info(
                    "CUDA allocator: max_split_size_mb=%d (~20%% of %d MiB).",
                    split_mb, total_vram // (1024 * 1024),
                )
            except Exception:
                pass  # no CUDA device yet — skip

        new_val = ",".join(p for p in parts if p)
        if new_val:
            os.environ["PYTORCH_CUDA_ALLOC_CONF"] = new_val

    def unload(self) -> None:
        """Release all model weights and tokeniser state from memory."""
        if not self._loaded:
            return
        del self._model, self._prep, self._tok
        self._model = self._prep = self._tok = None
        self._loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("CLIPEngine unloaded.")

    # ── device context manager ───────────────────────────────────────────────

    @contextmanager
    def _on_device(self):
        """
        Move the model to the inference device for the duration of the block,
        then return it to CPU and flush VRAM.

        On CPU-only machines this is a complete no-op (yields immediately).

        The synchronize() before cpu() ensures no in-flight CUDA kernels hold
        references to weights during the transfer, preventing the allocator
        from briefly holding two copies.
        """
        if self._device != "cuda":
            yield
            return

        self._model.cuda()
        try:
            yield
        finally:
            torch.cuda.synchronize()
            self._model.cpu()
            torch.cuda.empty_cache()

    # ── embedding helpers ────────────────────────────────────────────────────

    def embed_image(self, image) -> "torch.Tensor":
        """
        Returns a normalised (1, D) CPU tensor.
        Triggers lazy load on the first call.
        """
        self._lazy_load()
        t = (
            self._prep(image.convert("RGB"))
            .unsqueeze(0)
            .to(dtype=self._dtype)   # cast before device transfer
        )
        with self._on_device():
            t = t.to(self._device, non_blocking=True)
            with torch.no_grad():
                e = self._model.encode_image(t)
                e = (e / e.norm(dim=-1, keepdim=True)).cpu()
            del t
        return e

    def embed_texts(self, texts: List[str]) -> "torch.Tensor":
        """
        Returns a normalised (N, D) CPU tensor.
        Triggers lazy load on the first call.
        Token indices are int64 — NOT cast to the model's float dtype.
        """
        self._lazy_load()
        tokens = self._tok(texts)   # int64, stays as-is
        with self._on_device():
            tokens = tokens.to(self._device, non_blocking=True)
            with torch.no_grad():
                e = self._model.encode_text(tokens)
                e = (e / e.norm(dim=-1, keepdim=True)).cpu()
            del tokens
        return e

    # ── scoring ──────────────────────────────────────────────────────────────

    def score(
        self,
        image_emb: "torch.Tensor",
        text_emb:  "torch.Tensor",
    ) -> List[float]:
        """
        Cosine similarities between one image embedding and N text embeddings.
        Both inputs must be L2-normalised (as returned by embed_*).
        Pure CPU math — model is never touched.
        """
        sims = (image_emb @ text_emb.T)[0]
        return [round(float(s), 4) for s in sims]