"""

xai_rai/adapters/text_to_image_adapter.py
==========================================
Primary API for text-to-image XAI + RAI.

Exports
-------
MultiSignalExplainer    — tiered CLIP + BLIP-2 + VQA pipeline (primary API)
TextToImageAdapter      — original single-tier API (backward compatible)
make_hf_generate_fn     — factory for local Stable Diffusion generate_fn

Usage
-----
    from xai_rai.adapters.text_to_image_adapter import (
        MultiSignalExplainer, make_hf_generate_fn
    )

    generate_fn = make_hf_generate_fn("segmind/small-sd")

    explainer = MultiSignalExplainer(
        generate_fn=generate_fn,
        model_label="Small-SD (local)",
        mode="full",          # "fast" | "full" | "audit"
    )

    result = explainer.explain("a doctor performing surgery")
    print(result.to_json())

Modes
-----
fast   — CLIP only (~100ms, zero model loads beyond CLIP)
full   — CLIP + BLIP-2 caption delta (attribute injection detection)
audit  — CLIP + BLIP-2 + VQA safety probes (risk-gated; for governance docs)

"""

from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Callable, Optional

from PIL import Image

from xai_rai.contracts_tti import (
    AnalyzerContext, AnalyzerResult,
    TTIRAIScorecard, TextToImageExplanation,
)
from xai_rai.core.tti_config import MODE_TIERS, HF_MODEL_REGISTRY
from xai_rai.explainers.clip_engine import CLIPEngine
from xai_rai.explainers.model_registry import ModelRegistry
from xai_rai.explainers.tti_clip_analyzer import CLIPAnalyzer
from xai_rai.explainers.tti_blip2_analyzer import BLIP2CaptionAnalyzer
from xai_rai.explainers.tti_charts import build_attribution_chart, build_concept_chart
from xai_rai.rai.implements.tti_vqa_probe import VQAProbeAnalyzer
from xai_rai.rai.tti_audit_narrative import build_audit_narrative

logger = logging.getLogger(__name__)

try:
    from detoxify import Detoxify as _Detoxify
    _DETOXIFY_AVAILABLE = True
except ImportError:
    _DETOXIFY_AVAILABLE = False


# ── helpers ───────────────────────────────────────────────────────────────────

def _empty_rai(mode: str = "fast") -> TTIRAIScorecard:
    return TTIRAIScorecard(
        prompt_alignment=0, alignment_flagged=False,
        nsfw_concepts=[], nsfw_flagged=False,
        stereotype_concepts=[], stereotype_flagged=False,
        prompt_toxicity=0, toxicity_flagged=False,
        overall_flagged=False, analysis_mode=mode,
    )


# ══════════════════════════════════════════════════════════════════════════════
#  MultiSignalExplainer
# ══════════════════════════════════════════════════════════════════════════════

class MultiSignalExplainer:
    """
    Tiered XAI + RAI adapter for any text-to-image generator.

    Parameters
    ----------
    generate_fn  : Callable[[str], PIL.Image]
    model_label  : display name for reports
    mode         : default analysis mode ("fast" | "full" | "audit")
    concept_bank : optional custom concept bank (overrides tti_config default)
    """

    def __init__(
        self,
        generate_fn:  Callable[[str], Image.Image],
        model_label:  str = "Text-to-Image Model",
        mode:         str = "fast",
        concept_bank: Optional[dict] = None,
    ):
        if mode not in MODE_TIERS:
            raise ValueError(f"mode must be one of {list(MODE_TIERS)}, got '{mode}'")

        self._generate    = generate_fn
        self.model_label  = model_label
        self.default_mode = mode

        self._clip_engine = CLIPEngine()
        self._detoxify    = _Detoxify("original") if _DETOXIFY_AVAILABLE else None

        self._registry = ModelRegistry()
        self._registry.register(CLIPAnalyzer(self._clip_engine, self._detoxify))
        if mode in ("full", "audit"):
            self._registry.register(BLIP2CaptionAnalyzer(self._clip_engine))

        if mode == "audit":
            self._registry.register(VQAProbeAnalyzer())
    # ── public API ────────────────────────────────────────────────────────────

    def explain(
        self,
        prompt: str,
        mode:   Optional[str] = None,
    ) -> TextToImageExplanation:
        """Generate an image from prompt then run analysis."""
        image = self._generate(prompt)
        return self.explain_existing(prompt, image, mode=mode)

    def explain_existing(
        self,
        prompt: str,
        image:  Image.Image,
        mode:   Optional[str] = None,
    ) -> TextToImageExplanation:
        """Explain a pre-generated image (skips generation step)."""
        active_mode = mode or self.default_mode
        tier_names  = MODE_TIERS[active_mode]
        context     = AnalyzerContext(image=image, prompt=prompt)
        results     = self._registry.run(context, tier_names=tier_names)
        return self._assemble(prompt, image, context, results, active_mode)

    # ── assembly ──────────────────────────────────────────────────────────────

    def _assemble(
        self,
        prompt:  str,
        image:   Image.Image,
        context: AnalyzerContext,
        results: list[AnalyzerResult],
        mode:    str,
    ) -> TextToImageExplanation:
        import io, base64
        from PIL import Image as _Image

        # ── CLIP outputs (always present) ─────────────────────────────────
        clip_data      = next((r.data for r in results if r.analyzer == "clip"), {})
        word_attrs     = clip_data.get("word_attributions", [])
        concept_scores = clip_data.get("concept_scores", [])
        top_concepts   = clip_data.get("top_concepts", [])
        rai: TTIRAIScorecard = clip_data.get("rai", _empty_rai(mode))
        rai.analysis_mode = mode

        # ── BLIP-2 caption delta ──────────────────────────────────────────
        caption_delta = None
        blip_data     = next(
            (r.data for r in results if r.analyzer == "blip2_caption"), None
        )
        if blip_data:
            caption_delta         = blip_data.get("caption_delta")
            rai.injected_attrs    = context.injected_attrs
            rai.injection_flagged = bool(context.injected_attrs)

        # ── VQA probes ────────────────────────────────────────────────────
        vqa_data = next(
            (r.data for r in results if r.analyzer == "vqa_probe"), None
        )
        if vqa_data and not vqa_data.get("skipped"):
            probes          = vqa_data.get("probes", [])
            rai.vqa_probes  = probes
            rai.vqa_flagged = any(p.flagged for p in probes)

        # ── Recompute overall flag ────────────────────────────────────────
        rai.overall_flagged = bool(
            rai.alignment_flagged or rai.nsfw_flagged   or
            rai.stereotype_flagged or rai.toxicity_flagged or
            rai.injection_flagged  or rai.vqa_flagged
        )

        # ── image → b64 ───────────────────────────────────────────────────
        buf = io.BytesIO()
        image.save(buf, format="PNG")
        image_b64 = base64.b64encode(buf.getvalue()).decode()

        explanation = TextToImageExplanation(
            prompt                = prompt,
            image_b64             = image_b64,
            word_attributions     = word_attrs,
            concept_scores        = concept_scores,
            top_concepts          = top_concepts,
            rai                   = rai,
            attribution_chart_b64 = build_attribution_chart(word_attrs),
            concept_chart_b64     = build_concept_chart(concept_scores),
            model_label           = self.model_label,
            analysis_mode         = mode,
            tier_results          = [asdict(r) for r in results],
            caption_delta         = caption_delta,
        )

        if mode == "audit":
            explanation.audit_narrative = build_audit_narrative(explanation)

        return explanation


# ══════════════════════════════════════════════════════════════════════════════
#  TextToImageAdapter  (backward compatible)
# ══════════════════════════════════════════════════════════════════════════════

class TextToImageAdapter:
    """
    Original single-tier adapter — CLIP only.
    All existing calling code continues to work unchanged.
    For multi-signal analysis use MultiSignalExplainer directly.
    """

    def __init__(
        self,
        generate_fn:  Callable[[str], Image.Image],
        model_label:  str = "Text-to-Image Model",
        concept_bank: Optional[dict] = None,
    ):
        self._inner = MultiSignalExplainer(
            generate_fn  = generate_fn,
            model_label  = model_label,
            mode         = "fast",
            concept_bank = concept_bank,
        )

    def explain(self, prompt: str) -> TextToImageExplanation:
        return self._inner.explain(prompt, mode="fast")

    def explain_existing(
        self, prompt: str, image: Image.Image
    ) -> TextToImageExplanation:
        return self._inner.explain_existing(prompt, image, mode="fast")


# ══════════════════════════════════════════════════════════════════════════════
#  HuggingFace generate_fn factory
# ══════════════════════════════════════════════════════════════════════════════

def make_hf_generate_fn(
    model_id:   str = "segmind/small-sd",
    seed:       int = 42,
    device:     str = "auto",
    low_memory: bool = True,
) -> Callable[[str], Image.Image]:
    """
    Returns a generate_fn backed by a local Stable Diffusion pipeline.

    Parameters
    ----------
    model_id   : HuggingFace model ID (see HF_MODEL_REGISTRY for options)
    seed       : fixed generator seed for reproducibility
    device     : "auto" | "cuda" | "cpu"
    low_memory : enable attention + VAE slicing for CPU/low-VRAM setups
    """
    import torch
    from diffusers import StableDiffusionPipeline

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    logger.info("Loading model: %s on %s", model_id, device)
    load_kwargs: dict = {
        "torch_dtype":    torch.float16 if device == "cuda" else torch.float32,
        "safety_checker": None,
    }
    if low_memory and device == "cpu":
        load_kwargs["low_cpu_mem_usage"] = True

    pipe = StableDiffusionPipeline.from_pretrained(model_id, **load_kwargs)

    # Move to device BEFORE enabling memory optimisations.
    # enable_sequential_cpu_offload() is incompatible with a subsequent
    # .to() call — diffusers 0.40+ raises an error if you call .to() after
    # offloading, so we must do .to() first and never mix them.
    pipe = pipe.to(device)

    if low_memory:
        pipe.enable_attention_slicing(1)
        # pipe.enable_vae_slicing() is deprecated since diffusers ~0.40.
        # Call on the VAE submodule directly; fall back for older versions.
        if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_slicing"):
            pipe.vae.enable_slicing()
        elif hasattr(pipe, "enable_vae_slicing"):
            pipe.enable_vae_slicing()

    if (
        device == "cpu"
        and "turbo" not in model_id.lower()
        and "small" not in model_id.lower()
    ):
        try:
            from diffusers import DPMSolverMultistepScheduler
            pipe.scheduler = DPMSolverMultistepScheduler.from_config(
                pipe.scheduler.config
            )
        except Exception:
            pass

    def generate_fn(prompt: str) -> Image.Image:
        generator = torch.Generator(device=device).manual_seed(seed)
        num_steps = (
            1  if "turbo" in model_id.lower() else
            15 if "small" in model_id.lower() else
            20
        )
        result = pipe(
            prompt,
            num_inference_steps = num_steps,
            generator           = generator,
            guidance_scale      = 0.0 if "turbo" in model_id.lower() else 7.5,
        )
        return result.images[0]

    generate_fn.__name__ = f"local_sd_generate({model_id})"
    return generate_fn