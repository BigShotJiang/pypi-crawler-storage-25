"""
text_adapter.py
---------------
Model-agnostic NLP text classification adapter for XAI/RAI pipelines.

Supported providers
    - HuggingFace Inference API  (provider="hf")
    - OpenAI                     (provider="openai")
    - Anthropic Claude           (provider="anthropic")
    - Cohere                     (provider="cohere")
    - Local / custom callable    (provider="local")

Quick start
    from text_adapter import TextAdapter

    adapter = TextAdapter.from_provider("hf", model_name="distilbert/distilbert-base-uncased-finetuned-sst-2-english")
    result  = adapter.predict("This movie was absolutely fantastic!")
    print(result)
    # {"label": "POSITIVE", "score": 0.998, "probs": {"NEGATIVE": 0.002, "POSITIVE": 0.998}}
"""

from __future__ import annotations

import abc
import logging
import os
import re
from typing import Callable

import numpy as np

logger = logging.getLogger(__name__)

MAX_TOKENS = 512  # crude word-level cap used by default normalizer

# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class BaseTextAdapter(abc.ABC):
    """
    Abstract base for NLP text-classification adapters.

    Concrete subclasses must implement:
        _query(text) -> list[dict]   # [{"label": str, "score": float}, ...]

    The shared methods (normalize, predict_proba, predict, predict_logits)
    are backend-independent and live here permanently.
    """

    # ------------------------------------------------------------------
    # Abstract interface — subclasses must override
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def _query(self, text: str) -> list[dict]:
        """
        Call the backend and return a flat list of classification results.

        Returns
        -------
        list of {"label": str, "score": float}
        e.g. [{"label": "POSITIVE", "score": 0.998}, {"label": "NEGATIVE", "score": 0.002}]
        """

    @abc.abstractmethod
    def _warmup(self) -> None:
        """Verify the backend is reachable and the model is loaded."""

    # ------------------------------------------------------------------
    # Label registry — populated by _warmup for dynamic backends (HF),
    # set in __init__ for static backends (OpenAI, Anthropic, Cohere, Local).
    # ------------------------------------------------------------------

    _labels: list[str] | None = None

    @property
    def labels(self) -> list[str]:
        if self._labels is None:
            raise RuntimeError(
                "labels not yet populated — call _warmup() or pass labels= in constructor."
            )
        return self._labels

    @labels.setter
    def labels(self, value: list[str] | None) -> None:
        self._labels = [l.upper() for l in value] if value else None

    # ------------------------------------------------------------------
    # Shared (backend-independent) methods
    # ------------------------------------------------------------------

    def normalize(self, text: str, max_words: int = MAX_TOKENS) -> str:
        """
        Light-weight text normalisation:
            • strip leading/trailing whitespace
            • collapse consecutive whitespace
            • truncate to `max_words` words (crude proxy for token limit)
        """
        text = text.strip()
        text = re.sub(r"\s+", " ", text)
        words = text.split()
        if len(words) > max_words:
            logger.debug("Text truncated from %d to %d words.", len(words), max_words)
        return " ".join(words[:max_words])

    def predict_proba(self, text: str) -> np.ndarray:
        """
        Return a probability vector sorted alphabetically by label.

        Returns
        -------
        np.ndarray of shape (n_classes,)
        """
        text    = self.normalize(text)
        results = self._query(text)
        results = sorted(results, key=lambda x: x["label"])
        return np.array([r["score"] for r in results], dtype=float)

    def predict(self, text: str) -> dict:
        """
        Return a rich prediction dict.

        Returns
        -------
        {
            "label": str,
            "score": float,
            "probs": {label: score, ...},
        }
        """
        text    = self.normalize(text)
        results = self._query(text)
        top     = max(results, key=lambda x: x["score"])
        return {
            "label": top["label"],
            "score": float(top["score"]),
            "probs": {r["label"]: float(r["score"]) for r in results},
        }

    def predict_logits(self, text: str) -> np.ndarray:
        """
        Approximate logits via log-odds: logit(p) = log(p / (1-p)).

        Returns
        -------
        np.ndarray of shape (n_classes,), same order as predict_proba
        """
        probs = self.predict_proba(text)
        probs = np.clip(probs, 1e-7, 1 - 1e-7)
        return np.log(probs / (1 - probs))

    def predict_proba_batch(self, texts: list[str] | np.ndarray) -> np.ndarray:
        """
        Batch inference — required by SHAP KernelExplainer and LIME LimeTextExplainer.

        Parameters
        ----------
        texts : list[str] or np.ndarray of str

        Returns
        -------
        np.ndarray of shape (n_samples, n_classes)
            Probabilities in alphabetical label order, consistent with predict_proba.
        """
        return np.array([self.predict_proba(str(t)) for t in texts], dtype=float)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @staticmethod
    def from_provider(provider: str, **kwargs) -> "BaseTextAdapter":
        """
        Factory that returns the correct adapter subclass.

        Parameters
        ----------
        provider : str
            One of: "hf", "openai", "anthropic", "cohere", "local"
        **kwargs
            Forwarded to the subclass constructor (model_name, api_key, …).

        Examples
        --------
        >>> adapter = BaseTextAdapter.from_provider("hf", model_name="distilbert/...")
        >>> adapter = BaseTextAdapter.from_provider("openai", model_name="gpt-4o-mini", labels=["positive","negative","neutral"])
        >>> adapter = BaseTextAdapter.from_provider("anthropic", model_name="claude-haiku-4-5-20251001", labels=["positive","negative"])
        >>> adapter = BaseTextAdapter.from_provider("cohere", model_name="embed-english-v3.0", labels=["positive","negative"])
        >>> adapter = BaseTextAdapter.from_provider("local", fn=my_function, labels=["pos","neg"])
        """
        registry = {
            "hf":        HFTextAdapter,
            "openai":    OpenAITextAdapter,
            "anthropic": AnthropicTextAdapter,
            "cohere":    CohereTextAdapter,
            "local":     LocalTextAdapter,
        }
        provider = provider.lower()
        if provider not in registry:
            raise ValueError(
                f"Unknown provider '{provider}'. "
                f"Choose from: {list(registry.keys())}"
            )
        return registry[provider](**kwargs)


# Convenience alias
TextAdapter = BaseTextAdapter


# ---------------------------------------------------------------------------
# Provider: HuggingFace Inference API
# ---------------------------------------------------------------------------

_HF_API_URL = "https://router.huggingface.co/hf-inference/models"


class HFTextAdapter(BaseTextAdapter):
    """
    HuggingFace Inference API adapter for text-classification models.
    No local torch / transformers installation required.

    Parameters
    ----------
    model_name : str
        Any HF text-classification model, e.g.
        "distilbert/distilbert-base-uncased-finetuned-sst-2-english"
    hf_token : str | None
        Bearer token; falls back to HF_TOKEN env var.
    """

    def __init__(
        self,
        model_name: str = "distilbert/distilbert-base-uncased-finetuned-sst-2-english",
        hf_token: str | None = None,
        **_,
    ) -> None:
        import requests  # lazy — only needed by this provider
        self._requests   = requests
        self.model_name  = model_name
        self._token      = hf_token or os.environ.get("HF_TOKEN", "")
        self._url        = f"{_HF_API_URL}/{model_name}"
        self._headers    = {
            "Authorization": f"Bearer {self._token}",
            "Content-Type":  "application/json",
        }
        self._warmup()

    def _warmup(self) -> None:
        results = self._query("warmup")
        # Infer labels dynamically from API response
        self.labels = sorted([r["label"] for r in results])
        logger.info("HFTextAdapter ready — model: %s | labels: %s", self.model_name, self._labels)

    def _query(self, text: str, _retries: int = 4) -> list[dict]:
        """Single-text query with exponential backoff on 5xx errors."""
        import time
        wait = 1.0
        for attempt in range(_retries):
            resp = self._requests.post(
                self._url,
                headers=self._headers,
                json={"inputs": text, "options": {"wait_for_model": True}},
            )
            if resp.status_code in (500, 502, 503, 429):
                if attempt < _retries - 1:
                    logger.debug("HF %s on attempt %d — retrying in %.1fs", resp.status_code, attempt + 1, wait)
                    time.sleep(wait)
                    wait *= 2
                    continue
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, list) and data and isinstance(data[0], list):
                return data[0]
            return data
        resp.raise_for_status()  # final raise if all retries exhausted

    def keep_warm(self) -> None:
        """
        Ping the model with a single request to prevent cold-start latency.
        Call before each expensive SHAP/LIME run.
        """
        try:
            self._query("ping")
            logger.debug("HF model keep-warm ping sent.")
        except Exception as exc:
            logger.warning("Keep-warm ping failed (non-fatal): %s", exc)

    def keep_warm_background(self, interval: float = 20.0):
        """
        Returns a context manager that pings the model every `interval` seconds
        in a background thread. Use around long SHAP/LIME calls to prevent
        HF from unloading the model mid-explanation.

        Usage
        -----
        with adapter.keep_warm_background():
            result = xai.explain_shap(text)
        """
        import threading

        class _KeepWarmContext:
            def __init__(ctx, adapter, interval):
                ctx._adapter  = adapter
                ctx._interval = interval
                ctx._stop     = threading.Event()
                ctx._thread   = None

            def __enter__(ctx):
                def _loop():
                    while not ctx._stop.wait(ctx._interval):
                        ctx._adapter.keep_warm()
                ctx._thread = threading.Thread(target=_loop, daemon=True)
                ctx._thread.start()
                return ctx

            def __exit__(ctx, *_):
                ctx._stop.set()
                ctx._thread.join(timeout=2)

        return _KeepWarmContext(self, interval)

    def _detect_batch_mode(self, sample: list) -> str:
        """
        Inspect a 2-text batch response and return the batch mode:
          "batch"    — full prob distribution per text (Shape A or splittable C)
          "top1"     — only top-1 label per text returned; must use per-request
        """
        n_classes = len(self._labels) if self._labels else 2

        # Shape A: [[results_text1], [results_text2]]
        if len(sample) == 2 and all(isinstance(d, list) for d in sample):
            return "batch"

        # Shape C splittable: [[r1c1, r1c2, r2c1, r2c2]]
        if (
            len(sample) == 1
            and isinstance(sample[0], list)
            and len(sample[0]) == 2 * n_classes
        ):
            return "batch"

        # Anything else (inner_len == n_texts, top-1 only) → per-request
        return "top1"

    def _query_batch(self, texts: list[str], chunk_size: int = 32) -> list[list[dict]]:
        """
        Batched HF call. If batch mode is top-1 only, uses ThreadPoolExecutor
        for concurrent per-request calls instead of sequential fallback.
        """
        n_classes   = len(self._labels) if self._labels else 2
        all_results: list[list[dict]] = []

        for start in range(0, len(texts), chunk_size):
            chunk = texts[start : start + chunk_size]
            resp  = self._requests.post(
                self._url,
                headers=self._headers,
                json={"inputs": chunk, "options": {"wait_for_model": True}},
            )
            resp.raise_for_status()
            data = resp.json()

            # Shape A ─────────────────────────────────────────────────────
            if (
                isinstance(data, list)
                and len(data) == len(chunk)
                and all(isinstance(d, list) for d in data)
            ):
                all_results.extend(data)
                continue

            # Shape C splittable ──────────────────────────────────────────
            if (
                isinstance(data, list)
                and len(data) == 1
                and isinstance(data[0], list)
                and len(data[0]) == len(chunk) * n_classes
            ):
                flat = data[0]
                for i in range(len(chunk)):
                    all_results.append(flat[i * n_classes : (i + 1) * n_classes])
                continue

            # top-1 or unknown → concurrent per-request ───────────────────
            logger.debug(
                "Batch returned top-1 only (inner_len=%s for %d texts); "
                "using concurrent per-request calls.",
                len(data[0]) if isinstance(data, list) and data and isinstance(data[0], list) else len(data),
                len(chunk),
            )
            all_results.extend(self._query_concurrent(chunk))

        return all_results

    def _query_concurrent(self, texts: list[str], max_workers: int = 8) -> list[list[dict]]:
        """
        Fire one request per text concurrently using ThreadPoolExecutor.
        Capped at max_workers=8. Only the first wave (max_workers texts) is
        staggered by 20ms to avoid burst; subsequent waves fire freely.
        Preserves input order.
        """
        import time
        from concurrent.futures import ThreadPoolExecutor

        results = [None] * len(texts)

        def _run(args):
            idx, text, delay = args
            if delay > 0:
                time.sleep(delay)
            return idx, self._query(text)

        # Stagger only the first wave to soften the initial burst
        jobs = [
            (i, t, (i % max_workers) * 0.02)   # 20ms stagger within each wave
            for i, t in enumerate(texts)
        ]
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            for idx, result in pool.map(_run, jobs):
                results[idx] = result
        return results

    def predict_proba_batch(self, texts: list[str] | np.ndarray) -> np.ndarray:
        """
        Batch inference. On first call detects whether HF returns full
        distributions or top-1 only, then uses true batching or concurrent
        per-request calls accordingly for all subsequent calls.
        """
        texts = [self.normalize(str(t)) for t in texts]

        # ── One-time mode detection ───────────────────────────────────────
        if not getattr(self, "_batch_mode", None) and len(texts) > 1:
            resp = self._requests.post(
                self._url,
                headers=self._headers,
                json={"inputs": texts[:2], "options": {"wait_for_model": True}},
            )
            resp.raise_for_status()
            sample = resp.json()
            self._batch_mode = self._detect_batch_mode(sample)
            logger.info(
                "HF batch mode detected: %s — %s",
                self._batch_mode,
                "true batching enabled" if self._batch_mode == "batch"
                else "top-1 only; using concurrent per-request calls",
            )

        # ── Concurrent shortcut if mode is known to be top-1 ─────────────
        if getattr(self, "_batch_mode", None) == "top1":
            results = self._query_concurrent(texts)
        else:
            results = self._query_batch(texts)

        rows = []
        for per_text in results:
            sorted_r = sorted(per_text, key=lambda x: x["label"])
            rows.append([r["score"] for r in sorted_r])
        return np.array(rows, dtype=float)


# ---------------------------------------------------------------------------
# Provider: OpenAI
# ---------------------------------------------------------------------------

class OpenAITextAdapter(BaseTextAdapter):
    """
    OpenAI adapter that performs zero-shot classification via chat completion.

    The model is prompted to pick one of the provided `labels` and return a
    JSON object with label probabilities (via logprobs or direct instruction).

    Parameters
    ----------
    model_name : str
        e.g. "gpt-4o-mini", "gpt-4o"
    labels : list[str]
        Class labels the model should choose from.
    api_key : str | None
        Falls back to OPENAI_API_KEY env var.
    """

    def __init__(
        self,
        model_name: str = "gpt-4o-mini",
        labels: list[str] | None = None,
        api_key: str | None = None,
        **_,
    ) -> None:
        try:
            from openai import OpenAI  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "openai package is required for OpenAITextAdapter. "
                "Install it with: pip install openai"
            ) from exc

        self.model_name = model_name
        self.labels     = labels or ["positive", "negative", "neutral"]
        self._client    = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY", ""))
        self._warmup()

    def _warmup(self) -> None:
        self._query("warmup")
        logger.info("OpenAITextAdapter ready — model: %s | labels: %s", self.model_name, self._labels)

    def _query(self, text: str) -> list[dict]:
        import json

        system_prompt = (
            "You are a text classification engine. "
            f"Classify the text into one of these labels: {self.labels}. "
            "Respond ONLY with a valid JSON object mapping each label to a "
            "probability (0-1) that sums to 1.0. "
            'Example: {"positive": 0.85, "negative": 0.10, "neutral": 0.05}'
        )
        response = self._client.chat.completions.create(
            model=self.model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": text},
            ],
            temperature=0,
        )
        raw  = response.choices[0].message.content.strip()
        data = json.loads(raw)
        return [{"label": k.upper(), "score": float(v)} for k, v in data.items()]


# ---------------------------------------------------------------------------
# Provider: Anthropic Claude
# ---------------------------------------------------------------------------

class AnthropicTextAdapter(BaseTextAdapter):
    """
    Anthropic Claude adapter for zero-shot text classification.

    Parameters
    ----------
    model_name : str
        e.g. "claude-haiku-4-5-20251001", "claude-sonnet-4-6"
    labels : list[str]
        Class labels.
    api_key : str | None
        Falls back to ANTHROPIC_API_KEY env var.
    max_tokens : int
        Max tokens for the completion response (default: 256).
    """

    def __init__(
        self,
        model_name: str = "claude-haiku-4-5-20251001",
        labels: list[str] | None = None,
        api_key: str | None = None,
        max_tokens: int = 256,
        **_,
    ) -> None:
        try:
            import anthropic  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "anthropic package is required for AnthropicTextAdapter. "
                "Install it with: pip install anthropic"
            ) from exc

        self.model_name  = model_name
        self.labels      = labels or ["positive", "negative", "neutral"]
        self._max_tokens = max_tokens
        self._client     = anthropic.Anthropic(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        )
        self._warmup()

    def _warmup(self) -> None:
        self._query("warmup")
        logger.info("AnthropicTextAdapter ready — model: %s | labels: %s", self.model_name, self._labels)

    def _query(self, text: str) -> list[dict]:
        import json

        prompt = (
            f"Classify the following text into one of these labels: {self.labels}.\n"
            "Respond ONLY with a valid JSON object mapping each label to a probability "
            "(0-1) that sums to 1.0. No explanation, no markdown, just JSON.\n"
            f'Example: {{"{self.labels[0]}": 0.85, "{self.labels[1] if len(self.labels) > 1 else self.labels[0]}": 0.15}}\n\n'
            f"Text: {text}"
        )
        message = self._client.messages.create(
            model=self.model_name,
            max_tokens=self._max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        raw  = message.content[0].text.strip()
        data = json.loads(raw)
        return [{"label": k.upper(), "score": float(v)} for k, v in data.items()]


# ---------------------------------------------------------------------------
# Provider: Cohere
# ---------------------------------------------------------------------------

class CohereTextAdapter(BaseTextAdapter):
    """
    Cohere adapter using the /classify endpoint.

    Parameters
    ----------
    model_name : str
        e.g. "embed-english-v3.0" or a fine-tuned classifier model ID.
    labels : list[str]
        Class labels for zero-shot classification.
    api_key : str | None
        Falls back to COHERE_API_KEY env var.
    examples : list[dict] | None
        Few-shot examples: [{"text": "...", "label": "..."}, ...].
        Required by Cohere classify endpoint; provide at least 2 per label.
    """

    def __init__(
        self,
        model_name: str = "embed-english-v3.0",
        labels: list[str] | None = None,
        api_key: str | None = None,
        examples: list[dict] | None = None,
        **_,
    ) -> None:
        try:
            import cohere  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "cohere package is required for CohereTextAdapter. "
                "Install it with: pip install cohere"
            ) from exc

        self.model_name = model_name
        self.labels     = labels or ["positive", "negative"]
        self._client    = cohere.Client(api_key=api_key or os.environ.get("COHERE_API_KEY", ""))
        self._examples  = examples or self._default_examples()
        self._warmup()

    def _default_examples(self) -> list[dict]:
        """Minimal fallback examples (2 per label) to satisfy Cohere's API."""
        defaults = {
            "positive": ["I love this!", "Great experience overall."],
            "negative": ["I hate this.", "Terrible experience."],
            "neutral":  ["It was okay.", "Nothing special."],
        }
        examples = []
        for label in self.labels:
            texts = defaults.get(label.lower(), [f"Example of {label}."] * 2)
            for t in texts[:2]:
                examples.append({"text": t, "label": label})
        return examples

    def _warmup(self) -> None:
        self._query("warmup")
        logger.info("CohereTextAdapter ready — model: %s | labels: %s", self.model_name, self._labels)

    def _query(self, text: str) -> list[dict]:
        from cohere import ClassifyExample  # type: ignore

        cohere_examples = [
            ClassifyExample(text=e["text"], label=e["label"])
            for e in self._examples
        ]
        response = self._client.classify(
            model=self.model_name,
            inputs=[text],
            examples=cohere_examples,
        )
        classification = response.classifications[0]
        return [
            {"label": label.upper(), "score": float(prob)}
            for label, prob in classification.labels.items()
        ]


# ---------------------------------------------------------------------------
# Provider: Local / custom callable
# ---------------------------------------------------------------------------

class LocalTextAdapter(BaseTextAdapter):
    """
    Wraps any callable that accepts a string and returns
    list[{"label": str, "score": float}].

    Useful for:
        • locally loaded HuggingFace pipelines
        • sklearn models with predict_proba
        • mock functions in tests

    Parameters
    ----------
    fn : Callable[[str], list[dict]]
        Your classification function.
    labels : list[str] | None
        Optional label list (informational only; fn drives actual labels).

    Example
    -------
    >>> from transformers import pipeline
    >>> pipe = pipeline("text-classification", model="distilbert/...")
    >>> def my_fn(text):
    ...     results = pipe(text)
    ...     return [{"label": r["label"], "score": r["score"]} for r in results]
    >>> adapter = LocalTextAdapter(fn=my_fn)
    """

    def __init__(
        self,
        fn: Callable[[str], list[dict]],
        labels: list[str] | None = None,
        **_,
    ) -> None:
        if not callable(fn):
            raise TypeError("`fn` must be a callable.")
        self._fn    = fn
        self.labels = labels  # may be None; populated from _warmup if not set
        self._warmup()

    def _warmup(self) -> None:
        result = self._query("warmup")
        if self._labels is None:
            self.labels = sorted([r["label"] for r in result])
        logger.info(
            "LocalTextAdapter ready — fn: %s | labels: %s",
            getattr(self._fn, "__name__", repr(self._fn)),
            self._labels,
        )

    def _query(self, text: str) -> list[dict]:
        result = self._fn(text)
        if not isinstance(result, list) or not all(
            isinstance(r, dict) and "label" in r and "score" in r for r in result
        ):
            raise ValueError(
                "Local fn must return list[{'label': str, 'score': float}]. "
                f"Got: {result!r}"
            )
        return result


# ---------------------------------------------------------------------------
# CLI smoke-test  (python text_adapter.py)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    logging.basicConfig(level=logging.INFO)

    # ---- Local mock demo (no API key needed) ----
    def _mock_fn(text: str) -> list[dict]:
        """Trivial rule-based stub for demonstration."""
        score = 0.9 if any(w in text.lower() for w in ("good", "great", "love", "fantastic")) else 0.2
        return [
            {"label": "POSITIVE", "score": score},
            {"label": "NEGATIVE", "score": round(1 - score, 4)},
        ]

    adapter = BaseTextAdapter.from_provider("local", fn=_mock_fn)
    result  = adapter.predict("This movie was absolutely fantastic!")
    print("\n=== Local adapter demo ===")
    print(json.dumps(result, indent=2))
    print("labels        :", adapter.labels)
    print("predict_proba :", adapter.predict_proba("This movie was absolutely fantastic!"))
    print("predict_logits:", adapter.predict_logits("This movie was absolutely fantastic!"))
    batch = adapter.predict_proba_batch(["Fantastic film!", "Terrible movie.", "It was okay."])
    print("batch shape   :", batch.shape)   # (3, 2)
    print("batch row sums:", batch.sum(axis=1))  # [1.0, 1.0, 1.0]