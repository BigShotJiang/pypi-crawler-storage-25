import json
import os
from typing import Optional
from xai_rai.core.config import FeatureMapping
from xai_rai.core.results.results import XAIResult


class NarrativeGenerator:
    def __init__(
        self,
        feature_mapping: Optional[FeatureMapping] = None,
        use_llm: bool = False,
        api_key: Optional[str] = None,
        model: str = "arcee-ai/trinity-large-preview:free",
        language: str = "en",
    ):
        self.feature_mapping = feature_mapping or FeatureMapping()
        self.use_llm = use_llm
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        self.model = model or os.getenv("OPENROUTER_MODEL", "arcee-ai/trinity-large-preview:free")
        self.language = language

    def generate(self, result: XAIResult, context: Optional[dict] = None) -> str:
        if self.use_llm and self.api_key:
            try:
                return self._generate_llm_narrative(result, context)
            except Exception:
                pass
        return self._generate_template_narrative(result, context)

    def _generate_template_narrative(self, result: XAIResult, context: Optional[dict] = None) -> str:
        fm = self.feature_mapping
        parts = []

        if result.prediction_label:
            parts.append(f"The model predicts: {result.prediction_label}.")

        if result.confidence:
            conf_level = "high" if result.confidence > 0.8 else "moderate" if result.confidence > 0.6 else "low"
            parts.append(f"Confidence level is {conf_level} ({result.confidence:.0%}).")

        if result.top_factors:
            top_pos = result.top_positive_factors(2)
            top_neg = result.top_negative_factors(2)

            if top_pos:
                pos_factors = [fm.get_label(f) for f, _ in top_pos]
                parts.append(f"Key factors increasing the prediction: {', '.join(pos_factors)}.")

            if top_neg:
                neg_factors = [fm.get_label(f) for f, _ in top_neg]
                parts.append(f"Key factors decreasing the prediction: {', '.join(neg_factors)}.")

        return " ".join(parts) if parts else "Prediction generated based on input features."

    def _generate_llm_narrative(self, result: XAIResult, context: Optional[dict] = None) -> str:
        import urllib.request

        top_factors = result.to_dict()["top_factors"][:5]
        feature_values = result.feature_values
        fm = self.feature_mapping

        factors_text = "\n".join([
            f"- {fm.get_label(f)}: {feature_values.get(f, 'N/A')} (impact: {v:+.3f})"
            for f, v in top_factors
        ])

        domain = context.get("domain", "general") if context else "general"
        audience = context.get("audience", "business") if context else "business"

        # FIXED: was a broken f-string in v1
        confidence_str = f"{result.confidence:.0%}" if result.confidence else "Not available"

        prompt = f"""You are an AI assistant that explains machine learning predictions in simple, business-friendly language.

Domain: {domain}
Audience: {audience} user

Prediction: {result.prediction_label or str(result.prediction)}
Confidence: {confidence_str}

Top factors influencing this prediction:
{factors_text}

Write a 2-3 sentence explanation that:
1. States the prediction clearly
2. Explains the main drivers in plain language
3. Avoids technical jargon
4. Is actionable and easy to understand

Keep it concise and professional."""

        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/local/xai-middleware",
        }

        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 150,
            "temperature": 0.7,
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")

        with urllib.request.urlopen(req, timeout=30) as response:
            result_data = json.loads(response.read().decode())
            return result_data["choices"][0]["message"]["content"].strip()

