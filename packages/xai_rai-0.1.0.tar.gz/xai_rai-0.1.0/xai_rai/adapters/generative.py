"""
xai_rai/adapters/generative.py
===============================
GenerativeAdapter — the public-facing orchestrator.

Wires together: cache → adversarial check → LLM call → self-eval parse →
embedding ops → sentence attribution → word attribution → bias probe →
RAI scoring → trust aggregation → cache write.

Total LLM call budget: 1.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Callable

import numpy as np
from xai_rai.contracts import (
    AdversarialCheck,
    BiasProbeResult,
    ConsistencyResult,
    ExplanationConfidence,
    GenerativeExplanationResult,
    ImplicitBiasSignal,   # ← ADD
    RAIScorecard,
    SentenceInfluence,
    WordInfluence,
)
from xai_rai.core.cache import CacheBackend
from xai_rai.core.config import (
    ATTRIBUTION_TOP_SENTENCES,
    CONSISTENCY_FLAG_THRESHOLD,
    CONSISTENCY_MISMATCH_THRESHOLD,
    SELF_EVAL_SUFFIX,
)
from xai_rai.core.embeddings import EmbeddingEngine
from xai_rai.explainers.adversarial import AdversarialDetector
from xai_rai.explainers.attribution import AttributionEngine
from xai_rai.rai.llm.bias import BiasProber
from xai_rai.rai.llm.scorer import RAIScorer

logger = logging.getLogger(__name__)


class GenerativeAdapter:
    """
    Black-box explainability adapter for any generative LLM.

    Parameters
    ----------
    llm_fn            : Callable[[str], str]
                        Accepts a prompt string, returns the LLM response string.
    model_label       : str           — display name for reports
    rate_limit_delay  : float         — seconds to sleep before the LLM call
    inject_self_eval  : bool          — append self-evaluation JSON suffix to prompt
    cache_backend     : "memory" | "redis"
    redis_url         : str           — used only when cache_backend="redis"

    Quick-start
    -----------
        from xai_rai import explain

        result = explain(
            llm_fn        = my_llm,
            prompt        = "Should I hire John or Mohammed?",
            system_prompt = "You are a hiring assistant.",
            history       = [
                {"role": "user",      "content": "We need a Python developer."},
                {"role": "assistant", "content": "Got it. What seniority?"},
            ],
        )
        print(result.summary())

    Or via the class directly:

        adapter = GenerativeAdapter(llm_fn=my_llm, model_label="GPT-4o")
        result  = adapter.explain(prompt="...")
    """

    def __init__(
        self,
        llm_fn:           Callable[[str], str],
        model_label:      str   = "LLM",
        rate_limit_delay: float = 0.5,
        inject_self_eval: bool  = True,
        cache_backend:    str   = "memory",
        redis_url:        str   = "redis://localhost:6379/0",
    ):
        self.llm_fn            = llm_fn
        self.model_label       = model_label
        self.rate_limit_delay  = rate_limit_delay
        self.inject_self_eval  = inject_self_eval

        # Infrastructure
        self._emb         = EmbeddingEngine()
        self._cache       = CacheBackend(cache_backend, redis_url)

        # Explainer sub-components
        self._adversarial = AdversarialDetector()
        self._attribution = AttributionEngine(self._emb)
        self._bias        = BiasProber(self._emb)
        self._rai         = RAIScorer()

    # ── public API ────────────────────────────────────────────────────────────

    def explain(
        self,
        prompt:        str,
        system_prompt: str        = "",
        history:       list[dict] = None,
    ) -> GenerativeExplanationResult:
        """
        Run the full XAI-RAI pipeline — ONE LLM call total.

        Parameters
        ----------
        prompt        : Current user turn.
        system_prompt : Optional system prompt (included in attribution scope).
        history       : Prior turns as [{"role": "user"|"assistant", "content": "..."}].
        """
        history = history or []

        # ── 1. Cache check ────────────────────────────────────────────────────
        cache_key = CacheBackend.make_key(prompt, system_prompt, history)
        cached    = self._cache.get(cache_key)
        if cached:
            logger.info("Cache hit for key %s", cache_key[:16])
            data             = json.loads(cached)
            data["cache_hit"] = True
            return self._from_dict(data)

        # ── 2. Adversarial pre-flight ─────────────────────────────────────────
        adversarial = self._adversarial.check(prompt)
        if adversarial.flagged:
            logger.warning("Adversarial input flagged: %s", adversarial.reasons)

        # ── 3. Build attribution context (system + history + prompt) ──────────
        history_text        = " ".join(
            f"[{t.get('role', '?').upper()}]: {t.get('content', '')}"
            for t in history
        )
        attribution_context = " ".join(
            filter(None, [system_prompt, history_text, prompt])
        ).strip()

        # ── 4. Single LLM call ────────────────────────────────────────────────
        augmented    = prompt + SELF_EVAL_SUFFIX if self.inject_self_eval else prompt
        time.sleep(self.rate_limit_delay)
        raw_response = self._safe_llm_call(augmented)

        # ── 5. Parse self-eval block ──────────────────────────────────────────
        clean_response, partial_consistency = self._parse_self_eval(raw_response)

        # ── 6. Encode once; reuse everywhere ──────────────────────────────────
        prompt_vec   = self._emb.encode([prompt])[0]
        response_vec = self._emb.encode([clean_response])[0]
        embed_sim    = float(np.clip(np.dot(prompt_vec, response_vec), 0.0, 1.0))

        mismatch = (
            abs(partial_consistency.mean_similarity - embed_sim)
                > CONSISTENCY_MISMATCH_THRESHOLD
            and partial_consistency.mean_similarity > CONSISTENCY_FLAG_THRESHOLD
            and embed_sim < CONSISTENCY_FLAG_THRESHOLD
        )
        consistency = ConsistencyResult(
            mean_similarity    = partial_consistency.mean_similarity,
            min_similarity     = round(embed_sim, 4),
            flagged            = partial_consistency.flagged,
            mismatch_flagged   = mismatch,
            paraphrase_count   = 0,
            uncertainty_reason = partial_consistency.uncertainty_reason,
        )

        # ── 7. Attribution ────────────────────────────────────────────────────
        sentence_influences = self._attribution.sentence_attribution(
            attribution_context, response_vec
        )
        top_sentences = [
            s.sentence for s in sentence_influences[:ATTRIBUTION_TOP_SENTENCES]
        ]
        scope = " ".join(top_sentences) if top_sentences else attribution_context
        word_influences = self._attribution.word_attribution(scope, response_vec)

        # ── 8. Bias probe ─────────────────────────────────────────────────────
        bias_probe = self._bias.probe(prompt, response_vec)

        # ── 9. RAI scoring ────────────────────────────────────────────────────
        rai = self._rai.score(prompt, clean_response)

        # ── 10. Trust aggregation ─────────────────────────────────────────────
        mean_variance = (
            float(np.mean([w.score_variance for w in word_influences]))
            if word_influences else 0.0
        )
        confidence = ExplanationConfidence.compute(
            consistency, bias_probe, rai, adversarial, mean_variance
        )

        # ── 11. Assemble + cache ──────────────────────────────────────────────
        result = GenerativeExplanationResult(
            original_prompt     = prompt,
            llm_response        = clean_response,
            sentence_influences = sentence_influences,
            word_influences     = word_influences,
            consistency         = consistency,
            bias_probe          = bias_probe,
            rai                 = rai,
            adversarial         = adversarial,
            confidence          = confidence,
            model_label         = self.model_label,
            cache_hit           = False,
        )
        self._cache.set(cache_key, result.to_json())
        return result

    def clear_cache(self) -> None:
        """Clear all cached explanations."""
        self._cache.clear()

    # ── private helpers ───────────────────────────────────────────────────────

    def _safe_llm_call(self, prompt: str) -> str:
        try:
            r = self.llm_fn(prompt)
            return r.strip() if r else ""
        except Exception as exc:
            logger.warning("LLM call failed: %s", exc)
            return ""

    def _parse_self_eval(self, raw: str) -> tuple[str, ConsistencyResult]:
        confidence, uncertainty_reason, clean = 1.0, "", raw
        if self.inject_self_eval:
            m = re.search(r'\{[^{}]*"__xai_confidence"[^{}]*\}', raw, re.DOTALL)
            if m:
                try:
                    block              = json.loads(m.group())
                    confidence         = float(block.get("__xai_confidence", 1.0))
                    uncertainty_reason = str(block.get("__xai_uncertainty_reason", ""))
                    clean              = re.sub(r"\s*---\s*$", "", raw[:m.start()]).strip()
                except (json.JSONDecodeError, ValueError):
                    pass

        partial = ConsistencyResult(
            mean_similarity    = round(confidence, 4),
            min_similarity     = 0.0,
            flagged            = confidence < CONSISTENCY_FLAG_THRESHOLD,
            mismatch_flagged   = False,
            paraphrase_count   = 0,
            uncertainty_reason = uncertainty_reason,
        )
        return clean, partial

    # ── cache deserialization ─────────────────────────────────────────────────

    @staticmethod
    def _from_dict(d: dict) -> GenerativeExplanationResult:
        # Deserialise ImplicitBiasSignal dicts → dataclass instances
        bias_data = d["bias_probe"]
        bias_data["implicit_signals"] = [
            ImplicitBiasSignal(**s) for s in bias_data.get("implicit_signals", [])
        ]

        return GenerativeExplanationResult(
            original_prompt     = d["original_prompt"],
            llm_response        = d["llm_response"],
            sentence_influences = [SentenceInfluence(**s) for s in d["sentence_influences"]],
            word_influences     = [WordInfluence(**w) for w in d["word_influences"]],
            consistency         = ConsistencyResult(**d["consistency"]),
            bias_probe          = BiasProbeResult(**bias_data),   # ← uses patched dict
            rai                 = RAIScorecard(**d["rai"]),
            adversarial         = AdversarialCheck(**d["adversarial"]),
            confidence          = ExplanationConfidence(**d["confidence"]),
            model_label         = d["model_label"],
            cache_hit           = d.get("cache_hit", True),
            explanation_method  = d.get("explanation_method", ""),
        )