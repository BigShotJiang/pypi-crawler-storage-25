"""
xai_rai/adapters/image_classifier.py

Model-agnostic adapter for image classification models.

Responsibilities
----------------
- Accept any predict_fn conforming to the protocol below
- Handle PIL → numpy preprocessing (resize, normalise)
- Delegate XAI to explainers.image_explainer (RISE + Occlusion)
- Surface an agreement_score when both methods are run
- Delegate RAI to rai.implements.image_rai
- Provide a ready-made factory for HuggingFace pipeline models

predict_fn protocol
-------------------
    predict_fn(images: np.ndarray) -> np.ndarray
    images  : float32 (N, H, W, 3), values in [0, 1]
    returns : float32 (N, num_classes), each row sums to 1

Performance note (method="both")
---------------------------------
When both RISE and Occlusion are run, the adapter computes the baseline
predict_fn([image]) call exactly once and passes the results (top_class,
baseline_prob) to both explainers, saving one redundant forward pass.
"""

from __future__ import annotations

from typing import Callable, Literal, Optional

import numpy as np
from PIL import Image

from xai_rai.explainers.image_classifier_explainer import (
    OcclusionExplainer,
    RiseExplainer,
    agreement_score,
    LimeExplainer,
)

from xai_rai.rai.image_classifier.image_rai import ImageRAIChecker, ImageRAIResult
from xai_rai.core.results.vision_results import VisionResult
# ── Config ────────────────────────────────────────────────────────────────────

IMAGE_SIZE: tuple[int, int] = (224, 224)

# "both" runs RISE (primary) + Occlusion (cross-check) and populates
# agreement_score in the result — recommended for production use.
ExplainMethod = Literal["rise", "occlusion", "lime", "both"]


# ── Adapter ───────────────────────────────────────────────────────────────────

class ImageClassifierAdapter:
    """
    Unified interface for explaining and auditing any image classifier.

    Parameters
    ----------
    predict_fn        : Callable conforming to the predict_fn protocol.
    image_size        : (W, H) the model expects.  Default (224, 224).
    method            : XAI method(s) to run — "rise", "occlusion", or "both".
                        "both" also computes an agreement_score between the
                        two maps, giving downstream users a trust signal.
    rise_kwargs       : Extra kwargs forwarded to RiseExplainer.__init__.
    occlusion_kwargs  : Extra kwargs forwarded to OcclusionExplainer.__init__.
    rai_kwargs        : Extra kwargs forwarded to ImageRAIChecker.__init__.
    label_names       : Optional list of class names (len == num_classes).
    """

    def __init__(
        self,
        predict_fn:       Callable[[np.ndarray], np.ndarray],
        image_size:       tuple[int, int] = IMAGE_SIZE,
        method:           ExplainMethod   = "both",
        rise_kwargs:      Optional[dict]  = None,
        occlusion_kwargs: Optional[dict]  = None,
        lime_kwargs:      Optional[dict]  = None,   # ← add
        rai_kwargs:       Optional[dict]  = None,
        label_names:      Optional[list[str]] = None,
    ) -> None:
        self.predict_fn  = predict_fn
        self.image_size  = image_size
        self.method      = method
        self.label_names = label_names

        self._rise      = RiseExplainer(**(rise_kwargs or {}))
        self._occlusion = OcclusionExplainer(**(occlusion_kwargs or {}))
        self._lime      = LimeExplainer(**(lime_kwargs or {}))   # ← add
        self._rai       = ImageRAIChecker(**(rai_kwargs or {}))

    # ── Preprocessing ──────────────────────────────────────────────────────

    def _preprocess(self, image: Image.Image) -> np.ndarray:
        """PIL Image → float32 (H, W, 3) in [0, 1] at model input size."""
        img = image.convert("RGB").resize(self.image_size, Image.BILINEAR)
        return np.array(img).astype(np.float32) / 255.0

    # ── XAI ───────────────────────────────────────────────────────────────

    def explain(self, image: Image.Image) -> VisionResult:
        """
        Run the configured XAI method(s) on a single image.

        When method="both", a single baseline forward pass is shared between
        RISE and Occlusion — the top_class and baseline_prob are computed
        once and injected into both explainer calls via keyword arguments.
        This removes one redundant predict_fn([image]) call compared to
        letting each explainer compute its own baseline independently.

        When method="both", RISE runs first (primary saliency map) then
        Occlusion runs as an independent cross-check.  agreement_score is
        then computed between the two maps — a high score (>0.7) means both
        methods agree on which regions drove the prediction, which is a
        meaningful trust indicator for medical / enterprise settings.

        Returns a merged ExplanationResult; fields not produced by the
        selected method are None.
        """
        img_arr = self._preprocess(image)
        result  = VisionResult()

        # ── Shared baseline for method="both" ──────────────────────────────
        # Each explainer would independently call predict_fn([image]) to
        # determine the target class.  When running both, we do it once here
        # and pass the results in, saving one forward pass.
        shared_top_class:     Optional[int]   = None
        shared_baseline_prob: Optional[float] = None

        # ── LIME ───────────────────────────────────────────────────────────────
        if self.method in ("lime",):
            lime = self._lime.explain(
                img_arr,
                self.predict_fn,
                top_class=shared_top_class,
                baseline_prob=shared_baseline_prob,
            )
            result.lime_map       = lime.lime_map
            result.lime_fig       = lime.lime_fig
            if result.top_class_idx is None:
                result.top_class_idx  = lime.top_class_idx
                result.top_class_prob = lime.top_class_prob

        if self.method == "both":
            baseline              = self.predict_fn(img_arr[np.newaxis])[0]
            shared_top_class      = int(np.argmax(baseline))
            shared_baseline_prob  = float(baseline[shared_top_class])

        # ── RISE ───────────────────────────────────────────────────────────
        if self.method in ("rise", "both"):
            rise = self._rise.explain(
                img_arr,
                self.predict_fn,
                top_class=shared_top_class,
                baseline_prob=shared_baseline_prob,
            )
            result.rise_map        = rise.rise_map
            result.rise_fig        = rise.rise_fig
            result.rise_masks_used = rise.rise_masks_used
            result.top_class_idx   = rise.top_class_idx
            result.top_class_prob  = rise.top_class_prob

        # ── Occlusion ──────────────────────────────────────────────────────
        if self.method in ("occlusion", "both"):
            occ = self._occlusion.explain(
                img_arr,
                self.predict_fn,
                top_class=shared_top_class,
                baseline_prob=shared_baseline_prob,
            )
            result.occlusion_map = occ.occlusion_map
            result.occlusion_fig = occ.occlusion_fig
            # top_class from Occlusion as fallback if RISE was not run
            if result.top_class_idx is None:
                result.top_class_idx  = occ.top_class_idx
                result.top_class_prob = occ.top_class_prob

        # ── Agreement ──────────────────────────────────────────────────────
        if result.rise_map is not None and result.occlusion_map is not None:
            result.agreement_score = agreement_score(
                result.rise_map, result.occlusion_map
            )

        if self.label_names and result.top_class_idx is not None:
            result.extra["top_class_name"] = self.label_names[result.top_class_idx]

        return result

    # ── RAI ───────────────────────────────────────────────────────────────

    def audit(
        self,
        image:       Image.Image,
        n_stability: int   = 10,
        noise_std:   float = 0.02,
    ) -> ImageRAIResult:
        """
        Run RAI checks on a single image.

        Parameters
        ----------
        image        : Input image (PIL).
        n_stability  : Number of noisy copies for stability estimation.
        noise_std    : Std-dev of Gaussian noise for the stability test.
        """
        img_arr = self._preprocess(image)
        return self._rai.check(img_arr, self.predict_fn, n_stability, noise_std)

    # ── Combined ──────────────────────────────────────────────────────────

    def explain_and_audit(
        self,
        image: Image.Image,
        **audit_kwargs,
    ) -> dict:
        """
        Convenience method — returns both explain() and audit() results.

        Returns
        -------
        {
            "explanation": ExplanationResult,
            "rai":         ImageRAIResult,
        }
        """
        return {
            "explanation": self.explain(image),
            "rai":         self.audit(image, **audit_kwargs),
        }


# ── HuggingFace pipeline factory ──────────────────────────────────────────────

def make_hf_pipeline_predict_fn(
    model_id: str = "microsoft/resnet-50",
) -> tuple[Callable[[np.ndarray], np.ndarray], list[str]]:
    """
    Build a predict_fn and label list from a HuggingFace image-classification
    pipeline.

    Returns
    -------
    predict_fn : Callable[[np.ndarray], np.ndarray]
        Accepts float32 (N, H, W, 3) in [0, 1], returns float32 (N, C).
    labels     : list[str]  — length C, ordered by class index.

    Example
    -------
    >>> predict_fn, labels = make_hf_pipeline_predict_fn("microsoft/resnet-50")
    >>> adapter = ImageClassifierAdapter(predict_fn, label_names=labels)
    >>> result  = adapter.explain(my_pil_image)
    >>> print(f"Agreement: {result.agreement_score:.2f}")
    """
    from transformers import pipeline as hf_pipeline  # lazy import

    pipe = hf_pipeline("image-classification", model=model_id, top_k=None)

    labels    = list(pipe.model.config.id2label.values())
    label_idx = {label: i for i, label in enumerate(labels)}

    def predict_fn(images: np.ndarray) -> np.ndarray:
        pil_batch = [
            Image.fromarray((img * 255).astype(np.uint8))
            for img in images
        ]
        batch_preds = pipe(pil_batch)

        results = []
        for preds in batch_preds:
            row = np.zeros(len(labels), dtype=np.float32)
            for p in preds:
                idx = label_idx.get(p["label"])
                if idx is not None:
                    row[idx] = float(p["score"])
            results.append(row)

        return np.array(results, dtype=np.float32)

    return predict_fn, labels