"""
xai_rai/vision.py
=================

Thin public façade for vision/image-classification XAI + RAI.

Provides a clean developer-facing API while hiding:
- predict_fn construction
- HuggingFace integration
- adapter wiring
- explainer orchestration
"""

from __future__ import annotations

from PIL import Image

from xai_rai.adapters.image_classifier import (
    ImageClassifierAdapter,
    make_hf_pipeline_predict_fn,
)


class VisionExplainer:
    """
    Public façade for image-classification explainability.

    Example
    -------
    >>> from PIL import Image
    >>> from xai_rai import VisionExplainer
    >>>
    >>> image = Image.open("cat.jpg")
    >>>
    >>> explainer = VisionExplainer(
    ...     model="microsoft/resnet-50",
    ...     method="both",
    ... )
    >>>
    >>> result = explainer.explain(image)
    >>>
    >>> print(result.summary())
    """

    def __init__(
        self,
        model: str = "microsoft/resnet-50",
        method: str = "both",
        image_size: tuple[int, int] = (224, 224),

        rise_kwargs: dict | None = None,
        occlusion_kwargs: dict | None = None,
        rai_kwargs: dict | None = None,
    ) -> None:

        # --------------------------------------------------------------
        # Build predict_fn + labels
        # --------------------------------------------------------------

        predict_fn, labels = make_hf_pipeline_predict_fn(
            model_id=model
        )

        # --------------------------------------------------------------
        # Internal adapter
        # --------------------------------------------------------------

        self._adapter = ImageClassifierAdapter(
            predict_fn=predict_fn,
            image_size=image_size,
            method=method,

            rise_kwargs=rise_kwargs,
            occlusion_kwargs=occlusion_kwargs,
            rai_kwargs=rai_kwargs,

            label_names=labels,
        )

        self.model = model
        self.method = method

    # ------------------------------------------------------------------
    # XAI
    # ------------------------------------------------------------------

    def explain(self, image: Image.Image):
        """
        Generate image explanations.
        """
        return self._adapter.explain(image)

    # ------------------------------------------------------------------
    # RAI
    # ------------------------------------------------------------------

    def audit(
        self,
        image: Image.Image,
        **kwargs,
    ):
        """
        Run image reliability / robustness checks.
        """
        return self._adapter.audit(
            image,
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Combined
    # ------------------------------------------------------------------

    def explain_and_audit(
        self,
        image: Image.Image,
        **kwargs,
    ):
        """
        Run both XAI and RAI analysis.
        """
        return self._adapter.explain_and_audit(
            image,
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            "VisionExplainer("
            f"model={self.model!r}, "
            f"method={self.method!r}"
            ")"
        )