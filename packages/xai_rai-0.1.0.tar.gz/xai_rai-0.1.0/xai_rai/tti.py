"""
xai_rai/tti.py
================

Public facade for text-to-image explainability + RAI auditing.
"""

from __future__ import annotations

from typing import Optional

from xai_rai.explainers.clip_engine import CLIPEngine
from xai_rai.explainers.tti_clip_analyzer import CLIPAnalyzer, make_detoxify
from xai_rai.explainers.tti_blip2_analyzer import BLIP2CaptionAnalyzer
from xai_rai.texttoimage.pipeline.tti_pipeline import TTIPipeline


class TextToImageExplainer:
    """
    Public facade for text-to-image explainability.

    Example
    -------
    >>> explainer = TextToImageExplainer()
    >>> result = explainer.explain(image, prompt)
    >>> print(result.summary())
    """

    def __init__(
        self,
        *,
        device: str = "cpu",
        enable_caption_analysis: bool = True,
        enable_toxicity: bool = True,
    ) -> None:

        # Shared CLIP engine
        self._clip_engine = CLIPEngine(device=device)

        # Tier 1
        detox = make_detoxify() if enable_toxicity else None

        self._clip_analyzer = CLIPAnalyzer(
            engine=self._clip_engine,
            detoxify=detox,
        )

        # Tier 2
        self._caption_analyzer: Optional[BLIP2CaptionAnalyzer] = None

        if enable_caption_analysis:
            self._caption_analyzer = BLIP2CaptionAnalyzer(
                clip_engine=self._clip_engine
            )

        # Internal orchestrator
        self._pipeline = TTIPipeline(
            clip_analyzer=self._clip_analyzer,
            caption_analyzer=self._caption_analyzer,
        )

    def explain(self, image, prompt: str):
        """
        Run the TTI explanation pipeline.

        Parameters
        ----------
        image:
            PIL image

        prompt:
            Original generation prompt

        Returns
        -------
        TTIResult
        """
        return self._pipeline.run(
            image=image,
            prompt=prompt,
        )

    def unload(self) -> None:
        """
        Release all loaded model weights from memory.
        """
        self._clip_engine.unload()

        if self._caption_analyzer:
            self._caption_analyzer.unload()