"""
xai_rai/text_to_image/pipeline/tti_pipeline.py
================================================

Internal orchestration pipeline for text-to-image explainability.
"""

from __future__ import annotations

from typing import Optional

from xai_rai.contracts_tti import AnalyzerContext

from xai_rai.core.results.tti_results import TTIResult


class TTIPipeline:
    """
    Internal orchestrator for TTI analyzers.

    Responsibilities
    ----------------
    - Create shared context
    - Execute analyzers in order
    - Share embeddings/state across tiers
    - Aggregate outputs
    - Construct final TTIResult
    """

    def __init__(
        self,
        *,
        clip_analyzer,
        caption_analyzer=None,
    ) -> None:

        self._clip_analyzer = clip_analyzer
        self._caption_analyzer = caption_analyzer

    def run(self, image, prompt: str) -> TTIResult:
        """
        Execute the full TTI pipeline.
        """

        # Shared mutable context across tiers
        context = AnalyzerContext(
            image=image,
            prompt=prompt,
        )

        analyzer_results = []

        # ─────────────────────────────────────────────
        # Tier 1 — CLIP
        # ─────────────────────────────────────────────

        clip_result = self._clip_analyzer.analyze(context)

        analyzer_results.append(clip_result)

        # ─────────────────────────────────────────────
        # Tier 2 — Caption Delta
        # ─────────────────────────────────────────────

        if self._caption_analyzer is not None:
            caption_result = self._caption_analyzer.analyze(context)

            analyzer_results.append(caption_result)

        # ─────────────────────────────────────────────
        # Aggregate
        # ─────────────────────────────────────────────

        return self._build_result(
            prompt=prompt,
            analyzer_results=analyzer_results,
            context=context,
        )

    def _build_result(
        self,
        *,
        prompt: str,
        analyzer_results,
        context,
    ) -> TTIResult:
        """
        Merge analyzer outputs into a unified result object.
        """

        merged = {}

        flags = []

        for result in analyzer_results:
            merged.update(result.data)
            flags.extend(result.flags)

        return TTIResult(
            prompt=prompt,

            word_attributions=merged.get("word_attributions", []),

            concept_scores=merged.get("concept_scores", []),

            top_concepts=merged.get("top_concepts", []),

            rai_scorecard=merged.get("rai"),

            caption_delta=merged.get("caption_delta"),

            flags=list(set(flags)),

            metadata={
                "caption": getattr(context, "blip_caption", None),
            }
        )