from __future__ import annotations

# utils/helpers.py

import logging
import re
from typing import Any, Dict

import numpy as np
from numpy.typing import NDArray

from xai_rai.core.results.results import XAIResult

logger = logging.getLogger(__name__)


def normalize_feature_name(name: str) -> str:
    """Extract base feature name from LIME/SHAP feature strings.

    Handles formats like:
    - "mean radius <= 0.523"        -> "mean radius"
    - "worst concave points > 0.1"  -> "worst concave points"
    - "0.55 < mean area <= 0.78"    -> "mean area"
    - "f2 < 0.3"                    -> "f2"
    - "feature_name = value"        -> "feature_name"
    """
    # Handle range format: "0.55 < feature name <= 0.78"
    # Strip leading numeric condition
    range_match = re.match(r'^[\d.]+\s*[<>=]+\s*(.+?)\s*[<>=].*$', name)
    if range_match:
        return range_match.group(1).strip()

    # Handle standard format: "feature name <= 0.523" or "feature name = value"
    # Split on the first comparison operator and take everything before it
    parts = re.split(r'\s*[<>=]+\s*', name)
    candidate = parts[0].strip()

    # If candidate is purely numeric, it's the range format but our regex missed it
    # Fall back to taking the middle token
    if re.match(r'^[\d.]+$', candidate):
        # Try extracting the non-numeric, non-operator middle part
        tokens = re.split(r'[\s<>=]+', name)
        non_numeric = [t for t in tokens if t and not re.match(r'^[\d.]+$', t)]
        return ' '.join(non_numeric).strip()

    return candidate

def normalize_lime_explanation(exp, feature_names: list[str]) -> Dict[str, float]:
    """Parse LIME explanation and normalize feature importance values.

    LIME returns weights that can be on different scales. This normalizes
    them to [-1, 1] range for consistent merging with SHAP values.

    Args:
        exp: LIME explanation object with as_list() method
        feature_names: List of expected feature names

    Returns:
        Dict mapping normalized feature names to importance weights
    """
    importance = {}

    for feat_id, weight in exp.as_list():
        # Extract base feature name from condition strings like "f2 < 0.3"
        feat_name = normalize_feature_name(feat_id)

        # Accumulate weights if feature appears multiple times
        if feat_name in importance:
            importance[feat_name] += weight
        else:
            importance[feat_name] = weight

    # Normalize to [-1, 1] range
    if not importance:
        return importance

    values = np.array(list(importance.values()))
    max_abs = np.max(np.abs(values))

    if max_abs < 1e-10:
        return importance

    return {k: v / max_abs for k, v in importance.items()}


def normalize_importance_values(importance: Dict[str, float]) -> Dict[str, float]:
    """Normalize importance values to [-1, 1] range.

    Args:
        importance: Dict mapping feature names to importance values

    Returns:
        Normalized dict with values scaled to [-1, 1]
    """
    if not importance:
        return importance

    values = np.array(list(importance.values()))
    max_abs = np.max(np.abs(values))

    if max_abs < 1e-10:
        return importance

    return {k: v / max_abs for k, v in importance.items()}


def aggregate_importance(results: list[Any]) -> dict[str, float]:
    """
    Aggregate feature_importance across a list of XAIResult objects.
    Returns mean absolute importance per feature.
    """
    if not results:
        return {}

    agg: dict[str, list[float]] = {}
    for r in results:
        if not hasattr(r, "feature_importance") or r.feature_importance is None:
            continue
        for k, v in r.feature_importance.items():
            agg.setdefault(k, []).append(abs(float(v)))

    return {k: float(np.mean(v)) for k, v in agg.items()}


def validate_results(results: list[Any], min_samples: int = 1) -> None:
    """Raise ValueError with a clear message if results are unusable."""
    if not results:
        raise ValueError("results list is empty")
    if len(results) < min_samples:
        raise ValueError(
            f"At least {min_samples} results required, got {len(results)}"
        )
    if not hasattr(results[0], "feature_importance"):
        raise ValueError(
            "Results must have a feature_importance attribute. "
            "Ensure you are passing XAIResult objects."
        )


def validate_labels(y_true: NDArray, results: list[Any]) -> None:
    """Raise if y_true length doesn't match results."""
    if len(y_true) != len(results):
        raise ValueError(
            f"y_true length ({len(y_true)}) must match results length ({len(results)})"
        )


def get_prediction_class(prediction: Any) -> int:
    """
    Safely extract predicted class index from an XAIResult.prediction.
    Handles scalar sigmoid, softmax arrays, and integer outputs.
    Raises ValueError for regression outputs.
    """
    pred = np.asarray(prediction)
    if pred.ndim == 0:
        scalar = pred.item()
        if not (0.0 <= scalar <= 1.0):
            raise ValueError(
                "Scalar prediction outside [0, 1] — looks like regression output. "
                "Fairness analysis requires classification."
            )
        return 1 if scalar > 0.5 else 0
    return int(np.argmax(pred))