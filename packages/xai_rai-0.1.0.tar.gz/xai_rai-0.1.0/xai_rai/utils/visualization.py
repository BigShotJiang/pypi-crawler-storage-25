from xai_rai.core.results.results import XAIResult
from xai_rai.core.config import FeatureMapping
from typing import Optional, Any
import numpy as np
from xai_rai.core.results.results import BatchXAIResult



class VisualizationGenerator:
    @staticmethod
    def generate_waterfall_data(
        result: XAIResult,
        feature_mapping: Optional[FeatureMapping] = None,
        base_value: float = 0.5,
    ) -> dict[str, Any]:
        fm = feature_mapping or FeatureMapping()

        sorted_factors = sorted(result.top_factors, key=lambda x: abs(x[1]), reverse=True)[:8]

        labels = ["Base"]
        values = [base_value]
        colors = ["#6b7280"]

        cumulative = base_value
        for feature, impact in sorted_factors:
            cumulative += impact
            labels.append(fm.get_label(feature))
            values.append(impact)
            colors.append("#22c55e" if impact > 0 else "#ef4444")

        labels.append("Total")
        values.append(0)
        colors.append("#1f2937")

        return {
            "type": "waterfall",
            "title": "Prediction Breakdown",
            "labels": labels,
            "values": values,
            "colors": colors,
            "base_value": base_value,
            "final_value": cumulative,
        }

    @staticmethod
    def generate_force_data(
        result: XAIResult,
        feature_mapping: Optional[FeatureMapping] = None,
    ) -> dict[str, Any]:
        fm = feature_mapping or FeatureMapping()

        positive = [(fm.get_label(f), v) for f, v in result.top_positive_factors(5)]
        negative = [(fm.get_label(f), v) for f, v in result.top_negative_factors(5)]

        return {
            "type": "force",
            "title": "Feature Forces",
            "positive": [{"label": l, "value": v} for l, v in positive],
            "negative": [{"label": l, "value": v} for l, v in negative],
            "base_value": 0.5,
            "output_value": float(result.prediction) if np.isscalar(result.prediction) else 0.5,
        }

    @staticmethod
    def generate_summary_data(
        batch_results: BatchXAIResult,
        feature_mapping: Optional[FeatureMapping] = None,
    ) -> dict[str, Any]:
        fm = feature_mapping or FeatureMapping()

        if not batch_results.aggregate_summary:
            return {"type": "summary", "error": "No aggregate summary available"}

        ranking = batch_results.aggregate_summary.get("ranking", [])[:15]
        mean_imp = batch_results.aggregate_summary.get("mean_importance", {})

        labels = [fm.get_label(f) for f in ranking]
        values = [mean_imp.get(f, 0) for f in ranking]

        return {
            "type": "summary_bar",
            "title": "Global Feature Importance",
            "labels": labels,
            "values": values,
            "orientation": "horizontal",
        }

