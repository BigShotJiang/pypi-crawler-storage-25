from xai_rai.core.results.results import XAIResult
from numpy.typing import NDArray
import hashlib
from typing import Optional
import numpy as np


class ExplanationCache:
    """Simple MD5-based in-memory cache for explanation results."""

    def __init__(self, max_size: int = 512):
        self._cache: dict[str, XAIResult] = {}
        self._max_size = max_size

    def _key(self, instance: NDArray) -> str:
        return hashlib.md5(instance.tobytes()).hexdigest()

    def get(self, instance: NDArray) -> Optional[XAIResult]:
        return self._cache.get(self._key(instance))

    def set(self, instance: NDArray, result: XAIResult) -> None:
        if len(self._cache) >= self._max_size:
            # Evict oldest entry (FIFO)
            oldest = next(iter(self._cache))
            del self._cache[oldest]
        self._cache[self._key(instance)] = result

    def invalidate(self, instance: NDArray) -> None:
        self._cache.pop(self._key(instance), None)

    def clear(self) -> None:
        self._cache.clear()

    @property
    def size(self) -> int:
        return len(self._cache)

