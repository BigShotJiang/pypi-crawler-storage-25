from typing import Optional, Any, Callable, Union
import numpy as np
from numpy.typing import NDArray
import asyncio
from concurrent.futures import ThreadPoolExecutor

from xai_rai.explainers.tabular import ModelAgnosticExplainer
from xai_rai.core.config import XAIConfig, FeatureMapping
from xai_rai.core.results.results import XAIResult, BatchXAIResult
from xai_rai.utils.visualization import VisualizationGenerator
from xai_rai.adapters.llm import NarrativeGenerator


class XAIClient:
    """
    Main SDK entry point for Explainable AI.

    Supports:
    - Tabular explanations (SHAP + LIME)
    - Optional LLM narratives
    - Optional counterfactuals
    - UI-ready JSON output
    """

    def __init__(self, explainer: ModelAgnosticExplainer):
        self._explainer = explainer
        self._viz = VisualizationGenerator()

    # =========================
    # Factory method (IMPORTANT)
    # =========================
    @classmethod
    def from_tabular(
        cls,
        model: Any,
        X_background: NDArray,
        feature_names: Optional[list[str]] = None,
        feature_mapping: Optional[FeatureMapping] = None,
        task_type: str = "classification",
        use_llm: bool = False,
        llm_api_key: Optional[str] = None,
        llm_model: Optional[str] = None,
    ):
        config = XAIConfig(
            use_llm=use_llm,
            llm_api_key=llm_api_key,
            llm_model=llm_model,
        )

        def predict_fn(X):
            return model.predict_proba(X)

        explainer = ModelAgnosticExplainer(
            predict_fn=predict_fn,
            background_data=X_background,
            feature_names=feature_names,
            feature_mapping=feature_mapping,
            task_type=task_type,
            config=config,
            model=model,
        )

        return cls(explainer)

    # =========================
    # Core API
    # =========================
    def explain(
        self,
        X: NDArray,
        n_factors: int = 10,
        generate_narrative: bool = True,
        generate_counterfactuals: bool = False,
        context: Optional[dict] = None,
    ) -> Union[XAIResult, BatchXAIResult]:

        X = np.asarray(X)

        if X.ndim == 1:
            return self._explainer.explain_instance(
                X,
                n_top_factors=n_factors,
                generate_narrative=generate_narrative,
                generate_counterfactuals=generate_counterfactuals,
                context=context,
            )

        return self._explainer.explain_batch(
            X,
            n_top_factors=n_factors,
            generate_narrative=generate_narrative,
        )

    def explain_batch(self, X: NDArray, **kwargs) -> BatchXAIResult:
        return self.explain(X, **kwargs)

    # =========================
    # UI Output
    # =========================
    def explain_ui(
        self,
        X: NDArray,
        n_factors: int = 10,
        include_visuals: bool = True,
        generate_counterfactuals: bool = False,
        context: Optional[dict] = None,
    ) -> Union[dict, list[dict]]:

        X = np.asarray(X)
        fm = self._explainer.feature_mapping

        if X.ndim == 1:
            result = self.explain(
                X,
                n_factors=n_factors,
                generate_narrative=True,
                generate_counterfactuals=generate_counterfactuals,
                context=context,
            )

            ui_json = result.to_ui_json(
                feature_mapping=fm,
                include_visual_data=include_visuals,
            )

            if include_visuals:
                ui_json["visualizations"]["waterfall"] = self._viz.generate_waterfall_data(result, fm)
                ui_json["visualizations"]["force"] = self._viz.generate_force_data(result, fm)

            return ui_json

        batch_result = self.explain_batch(
            X,
            n_factors=n_factors,
            generate_narrative=True,
        )

        ui_json = batch_result.to_ui_json(feature_mapping=fm, include_aggregates=True)

        if include_visuals:
            ui_json["visualizations"] = {
                "summary": self._viz.generate_summary_data(batch_result, fm)
            }

        return ui_json

    # =========================
    # Async Support
    # =========================
    async def explain_async(
        self,
        X: NDArray,
        n_factors: int = 10,
        generate_narrative: bool = True,
        context: Optional[dict] = None,
    ):
        loop = asyncio.get_event_loop()

        with ThreadPoolExecutor(max_workers=1) as pool:
            return await loop.run_in_executor(
                pool,
                lambda: self.explain(
                    X,
                    n_factors=n_factors,
                    generate_narrative=generate_narrative,
                    generate_counterfactuals=False,
                    context=context,
                ),
            )

    # =========================
    # Narrative (explicit control)
    # =========================
    def generate_narrative(self, result: XAIResult, context: Optional[dict] = None) -> str:
        generator = NarrativeGenerator(
            feature_mapping=self._explainer.feature_mapping,
            use_llm=self._explainer.config.use_llm,
            api_key=self._explainer.config.llm_api_key,
            model=self._explainer.config.llm_model,
        )
        return generator.generate(result, context)

    # =========================
    # Utility
    # =========================
    def health_check(self) -> dict[str, Any]:
        try:
            test_instance = self._explainer.background_data[:1]
            pred = self._explainer.predict_fn(test_instance)

            shap_ok = True
            lime_ok = True

            try:
                self._explainer._compute_shap(test_instance[0])
            except Exception:
                shap_ok = False

            try:
                self._explainer._compute_lime(test_instance[0])
            except Exception:
                lime_ok = False

            return {
                "status": "healthy" if shap_ok and lime_ok else "degraded",
                "n_features": self._explainer.n_features,
                "task_type": self._explainer.task_type,
                "prediction_shape": pred.shape,
                "shap_type": self._explainer._shap_type,
                "shap_ok": shap_ok,
                "lime_ok": lime_ok,
            }

        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}

    def clear_cache(self):
        if self._explainer._cache:
            self._explainer._cache.clear()


# =========================
# Helper API (public)
# =========================
def create_feature_mapping(
    labels: dict[str, str],
    descriptions: Optional[dict[str, str]] = None,
):
    return FeatureMapping(
        labels=labels,
        descriptions=descriptions or {},
    )