"""
xai_rai/contracts.py
====================
Single source of truth for all shared dataclasses / data contracts.
Every sub-package imports from here — nothing circular.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import List


# ──────────────────────────────────────────────────────────────────────────────
#  ATTRIBUTION
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class WordInfluence:
    word:             str
    position:         int
    influence_score:  float
    similarity_drop:  float
    window_context:   str   = ""
    score_variance:   float = 0.0   # std-dev across ensemble variants


@dataclass
class SentenceInfluence:
    sentence:         str
    sentence_index:   int
    influence_score:  float


# ──────────────────────────────────────────────────────────────────────────────
#  CONSISTENCY / CONFIDENCE
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class ConsistencyResult:
    mean_similarity:    float
    min_similarity:     float
    flagged:            bool
    mismatch_flagged:   bool
    paraphrase_count:   int
    sample_outputs:     List[str] = field(default_factory=list)
    uncertainty_reason: str       = ""


# ──────────────────────────────────────────────────────────────────────────────
#  BIAS
# ──────────────────────────────────────────────────────────────────────────────

# @dataclass
# class BiasProbeResult:
#     tested:        bool
#     pairs_found:   List[str]
#     max_drift:     float
#     flagged:       bool
#     flagged_swaps: List[dict]

@dataclass
class ImplicitBiasSignal:
    """A single implicit bias pattern match with context."""
    pattern:        str
    category:       str   # e.g. "employment", "gender", "age"
    matched_text:   str
    location:       str   # "prompt" | "response"
    drift:          float = 0.0   # embedding drift vs. neutralised variant


@dataclass
class BiasProbeResult:
    tested:                bool
    pairs_found:           List[str]
    max_drift:             float
    flagged:               bool
    flagged_swaps:         List[dict]
    # ── NEW ──────────────────────────────────────────────────────────────────
    implicit_signals:      List[ImplicitBiasSignal] = field(default_factory=list)
    implicit_flagged:      bool                     = False
    implicit_categories:   List[str]                = field(default_factory=list)
# ──────────────────────────────────────────────────────────────────────────────
#  RAI / TOXICITY
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class RAIScorecard:
    prompt_toxicity:          float
    prompt_severe_toxicity:   float
    prompt_insult:            float
    prompt_threat:            float
    prompt_identity_attack:   float
    prompt_flagged:           bool
    response_toxicity:        float
    response_severe_toxicity: float
    response_insult:          float
    response_threat:          float
    response_identity_attack: float
    response_flagged:         bool
    overall_flagged:          bool


# ──────────────────────────────────────────────────────────────────────────────
#  ADVERSARIAL
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class AdversarialCheck:
    flagged:              bool
    reasons:              List[str]
    attribution_reliable: bool


# ──────────────────────────────────────────────────────────────────────────────
#  TRUST / EXPLANATION CONFIDENCE
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class ExplanationConfidence:
    """
    Aggregated trust signal for UIs and API consumers.

    trust_score : 0.0 (no trust) → 1.0 (high trust)
    grade       : HIGH | MEDIUM | LOW | UNRELIABLE
    caveats     : human-readable active warnings
    """
    trust_score: float
    grade:       str
    caveats:     List[str]

    @staticmethod
    def compute(
        consistency:    ConsistencyResult,
        bias:           BiasProbeResult,
        rai:            RAIScorecard,
        adversarial:    AdversarialCheck,
        score_variance: float,
    ) -> "ExplanationConfidence":
        from xai_rai.core.config import (
            CONSISTENCY_FLAG_THRESHOLD,
            CONSISTENCY_MISMATCH_THRESHOLD,
            BIAS_THRESHOLD,
            IMPLICIT_BIAS_THRESHOLD,   # ← ADD
        )

        penalties: float = 0.0
        caveats:   List[str] = []

        if adversarial.flagged:
            penalties += 0.40
            caveats.append("⚠️ Adversarial input detected — attribution may be unreliable.")

        if consistency.mismatch_flagged:
            penalties += 0.20
            caveats.append(
                f"⚠️ Confidence mismatch: model claimed {consistency.mean_similarity:.2f} "
                f"but semantic alignment is {consistency.min_similarity:.2f}."
            )
        elif consistency.flagged:
            penalties += 0.10
            caveats.append(
                f"⚠️ Low model confidence ({consistency.mean_similarity:.2f}). "
                + (consistency.uncertainty_reason or "")
            )

        # ── Explicit demographic bias ─────────────────────────────────────────────
        if bias.flagged:
            penalties += 0.15
            caveats.append(
                f"⚠️ Demographic bias signal detected (max drift: {bias.max_drift:.2f}). "
                f"Pairs: {', '.join(bias.pairs_found)}."
            )

        # ── Implicit bias (NEW) ───────────────────────────────────────────────────
        if bias.implicit_flagged:
            penalties += 0.10   # softer penalty — implicit signals are subtler
            cats = ", ".join(bias.implicit_categories)
            top_signal = max(bias.implicit_signals, key=lambda s: s.drift, default=None)
            drift_info = f" (max drift: {top_signal.drift:.2f})" if top_signal else ""
            caveats.append(
                f"⚠️ Implicit bias signal detected in categories: {cats}{drift_info}. "
                f"Response may reflect assumptions tied to: "
                f"{', '.join(s.matched_text for s in bias.implicit_signals if s.drift > IMPLICIT_BIAS_THRESHOLD)}."
            )

        if rai.overall_flagged:
            penalties += 0.20
            caveats.append("⚠️ Toxic or harmful content detected by RAI layer.")

        if score_variance > 0.10:
            penalties += 0.10
            caveats.append(
                f"⚠️ Attribution scores show instability across runs "
                f"(variance: {score_variance:.3f}). Treat rankings as approximate."
            )

        if not caveats:
            caveats.append("✅ No issues detected. Explanation reliability is high.")

        trust = round(max(0.0, 1.0 - penalties), 4)
        grade = (
            "HIGH"       if trust >= 0.80 else
            "MEDIUM"     if trust >= 0.55 else
            "LOW"        if trust >= 0.30 else
            "UNRELIABLE"
        )
        return ExplanationConfidence(trust_score=trust, grade=grade, caveats=caveats)
# ──────────────────────────────────────────────────────────────────────────────
#  TOP-LEVEL RESULT
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class GenerativeExplanationResult:
    original_prompt:      str
    llm_response:         str
    sentence_influences:  List[SentenceInfluence]
    word_influences:      List[WordInfluence]
    consistency:          ConsistencyResult
    bias_probe:           BiasProbeResult
    rai:                  RAIScorecard
    adversarial:          AdversarialCheck
    confidence:           ExplanationConfidence
    model_label:          str
    cache_hit:            bool = False
    explanation_method:   str  = (
        "windowed_embedding_attribution(ensemble=3) + sentence_pass + "
        "self_eval_consistency + embed_crosscheck + response_space_bias_probing + "
        "adversarial_detection + trust_aggregation"
    )

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(asdict(self), indent=indent, default=str)

    def summary(self) -> str:
        lines = []
        if self.cache_hit:
            lines.append("(Served from cache.)")
        lines.append(f"Trust: {self.confidence.grade} ({self.confidence.trust_score:.2f})")
        lines.extend(self.confidence.caveats)
        lines.append(f"\nResponse length: {len(self.llm_response.split())} words.")
        if self.sentence_influences:
            lines.append(
                f'Most influential sentence: "{self.sentence_influences[0].sentence[:80]}…"'
            )
        if self.word_influences:
            top3 = [
                f"{w.word} ({w.influence_score:.2f}±{w.score_variance:.2f})"
                for w in self.word_influences[:3]
            ]
            lines.append(f"Top tokens: {', '.join(top3)}.")
        return "\n".join(lines)