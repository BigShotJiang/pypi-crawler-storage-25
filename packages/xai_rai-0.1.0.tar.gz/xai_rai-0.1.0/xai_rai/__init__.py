"""Top-level package exports for xai_rai."""

from typing import Callable, TYPE_CHECKING, Any

__version__ = "0.1.0"

if TYPE_CHECKING:
    from xai_rai.adapters.generative import GenerativeAdapter
    from xai_rai.contracts import (
        AdversarialCheck,
        BiasProbeResult,
        ConsistencyResult,
        ExplanationConfidence,
        GenerativeExplanationResult,
        RAIScorecard,
        SentenceInfluence,
        WordInfluence,
    )
    from xai_rai.core.config import FeatureMapping, XAIConfig
    from xai_rai.nlp import NLPExplainer
    from xai_rai.tabular import TabularExplainer
    from .tti import TextToImageExplainer

from xai_rai.llm import LLMExplainer
from xai_rai.vision import VisionExplainer

def explain(
    llm_fn: Callable[[str], str],
    prompt: str,
    system_prompt: str = "",
    history: list[dict] | None = None,
    model_label: str = "LLM",
    rate_limit_delay: float = 0.5,
    inject_self_eval: bool = True,
    cache_backend: str = "memory",
    redis_url: str = "redis://localhost:6379/0",
) -> "GenerativeExplanationResult":
    """One-shot convenience wrapper around ``GenerativeAdapter.explain``."""
    from xai_rai.adapters.generative import GenerativeAdapter

    adapter = GenerativeAdapter(
        llm_fn=llm_fn,
        model_label=model_label,
        rate_limit_delay=rate_limit_delay,
        inject_self_eval=inject_self_eval,
        cache_backend=cache_backend,
        redis_url=redis_url,
    )
    return adapter.explain(
        prompt=prompt,
        system_prompt=system_prompt,
        history=history or [],
    )


def __getattr__(name: str) -> Any:
    if name == "GenerativeAdapter":
        from xai_rai.adapters.generative import GenerativeAdapter

        return GenerativeAdapter
    if name in {
        "AdversarialCheck",
        "BiasProbeResult",
        "ConsistencyResult",
        "ExplanationConfidence",
        "GenerativeExplanationResult",
        "RAIScorecard",
        "SentenceInfluence",
        "WordInfluence",
    }:
        from xai_rai import contracts

        return getattr(contracts, name)
    if name in {"FeatureMapping", "XAIConfig"}:
        from xai_rai.core.config import FeatureMapping, XAIConfig

        return {"FeatureMapping": FeatureMapping, "XAIConfig": XAIConfig}[name]
    if name == "NLPExplainer":
        from xai_rai.nlp import NLPExplainer

        return NLPExplainer
    if name == "TabularExplainer":
        from xai_rai.tabular import TabularExplainer

        return TabularExplainer
    if name == "TextToImageExplainer":
        from xai_rai.tti import TextToImageExplainer

        return TextToImageExplainer
    raise AttributeError(f"module 'xai_rai' has no attribute '{name}'")


__all__ = [
    "__version__",
    "GenerativeAdapter",
    "explain",
    "XAIConfig",
    "FeatureMapping",
    "GenerativeExplanationResult",
    "WordInfluence",
    "SentenceInfluence",
    "ConsistencyResult",
    "BiasProbeResult",
    "RAIScorecard",
    "AdversarialCheck",
    "ExplanationConfidence",
    "NLPExplainer",
    "TabularExplainer",
    "LLMExplainer",
    "VisionExplainer",
    "TextToImageExplainer"
]