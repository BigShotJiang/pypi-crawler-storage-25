"""
xai_rai/llm.py
==============

Thin public façade for LLM XAI / RAI.

Provides a simple developer-facing API while delegating:
- attribution
- adversarial detection
- embeddings
- orchestration

to internal engine components.
"""

from __future__ import annotations

import time

from xai_rai.core.embeddings import EmbeddingEngine
from xai_rai.core.results.llm_results import LLMResult

from xai_rai.explainers.adversarial import AdversarialDetector
from xai_rai.explainers.attribution import AttributionEngine


class LLMExplainer:
    """
    Public façade for LLM explainability / trust analysis.

    Example
    -------
    >>> from xai_rai import LLMExplainer
    >>>
    >>> explainer = LLMExplainer()
    >>>
    >>> result = explainer.explain(
    ...     prompt="Why is the sky blue?",
    ...     response=response,
    ... )
    >>>
    >>> print(result.summary())
    """

    def __init__(
        self,
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        run_adversarial_check: bool = True,
    ) -> None:

        self._embeddings = EmbeddingEngine(
            model_name=embedding_model
        )

        self._attribution = AttributionEngine(
            embedding_engine=self._embeddings
        )

        self._adversarial = (
            AdversarialDetector()
            if run_adversarial_check
            else None
        )

    # ------------------------------------------------------------------
    # Main API
    # ------------------------------------------------------------------

    def explain(
        self,
        prompt: str,
        response: str,
    ) -> LLMResult:
        """
        Run LLM explainability + trust analysis.
        """

        start = time.perf_counter()

        # --------------------------------------------------------------
        # Response embedding
        # --------------------------------------------------------------

        response_vec = self._embeddings.encode(response)

        # --------------------------------------------------------------
        # XAI
        # --------------------------------------------------------------

        sentence_attr = self._attribution.sentence_attribution(
            prompt,
            response_vec,
        )

        word_attr = self._attribution.word_attribution(
            prompt,
            response_vec,
        )

        # --------------------------------------------------------------
        # RAI
        # --------------------------------------------------------------

        adversarial = None

        if self._adversarial is not None:
            adversarial = self._adversarial.check(prompt)

        # --------------------------------------------------------------
        # Timing
        # --------------------------------------------------------------

        latency_ms = (
            time.perf_counter() - start
        ) * 1000

        # --------------------------------------------------------------
        # Result
        # --------------------------------------------------------------

        return LLMResult(
            prompt=prompt,
            response=response,

            sentence_attributions=sentence_attr,
            word_attributions=word_attr,

            adversarial_check=adversarial,

            latency_ms=latency_ms,
        )

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            "LLMExplainer("
            f"embedding_model={self._embeddings.model_name!r}"
            ")"
        )