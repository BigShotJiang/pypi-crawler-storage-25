"""
xai_rai/nlp.py

Thin public façade for NLP explainability.
"""

from __future__ import annotations

from xai_rai.adapters.text_adapter import TextAdapter
from xai_rai.explainers.text_explainer import (
    NLPExplainer as _NLPExplainer,
)


class NLPExplainer:
    """
    Public NLP façade.

    Examples
    --------
    HuggingFace:

    explainer = NLPExplainer(
        model="distilbert/distilbert-base-uncased-finetuned-sst-2-english"
    )

    Local function:

    explainer = NLPExplainer(
        provider="local",
        fn=my_predict_fn
    )
    """

    def __init__(
        self,
        model: str | None = None,
        adapter: TextAdapter | None = None,
        shap_masker: str = "word",
        lime_num_samples: int = 1000,
        lime_num_features: int = 10,
        remote_api: bool = False,
        **kwargs,
    ):

        # ---------------------------------------------
        # Build adapter
        # ---------------------------------------------

        if adapter is None:

            adapter = TextAdapter.from_provider("hf", model=model)

        # ---------------------------------------------
        # Internal engine
        # ---------------------------------------------

        self._engine = _NLPExplainer(
            adapter=adapter,
            **kwargs,
        )

    # -------------------------------------------------
    # SHAP
    # -------------------------------------------------

    def explain_shap(self, *args, **kwargs):
        return self._engine.explain_shap(*args, **kwargs)

    # -------------------------------------------------
    # LIME
    # -------------------------------------------------

    def explain_lime(self, *args, **kwargs):
        return self._engine.explain_lime(*args, **kwargs)

    # -------------------------------------------------
    # Combined
    # -------------------------------------------------

    def explain(self, *args, **kwargs):
        return self._engine.explain(*args, **kwargs)

    # -------------------------------------------------
    # Convenience
    # -------------------------------------------------

    @property
    def labels(self):
        return self._engine._adapter.labels

    def __repr__(self):
        return f"NLPExplainer(labels={self.labels})"