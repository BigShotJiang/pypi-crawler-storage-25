from xai_rai.explainers.tabular import ModelAgnosticExplainer
from xai_rai.core.config import XAIConfig


class TabularExplainer:
    def __init__(
        self,
        model,
        data,
        feature_names=None,
        class_names=None,
        config=None,
    ):

        self.model = model
        self.data = data
        self.feature_names = (list(feature_names) if feature_names is not None else None)
        self.class_names = (list(class_names) if class_names is not None else None)

        config = config or XAIConfig()

        predict_fn = self._build_predict_fn(model)

        self._explainer = ModelAgnosticExplainer(
            predict_fn=predict_fn,
            background_data=data,
            feature_names=self.feature_names,
            class_names=self.class_names,
            config=config,
            model=model,
        )

    def explain_instance(self, instance):
        return self._explainer.explain_instance(instance)

    def explain_batch(self, instances):
        return self._explainer.explain_batch(instances)

    def _build_predict_fn(self, model):

        if hasattr(model, "predict_proba"):
            return model.predict_proba

        if hasattr(model, "predict"):
            return model.predict

        raise ValueError(
            "Model must implement predict() or predict_proba()"
        )