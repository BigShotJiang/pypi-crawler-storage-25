"""Tests for the bty-tui module.

Two layers:

1. Free helpers (``fetch_remote_catalog``, ``post_pxe_done``) covered
   without instantiating textual at all - they're just HTTP wrappers.
2. End-to-end interaction with the textual ``BtyTui`` app via
   ``App.run_test()`` (textual's headless test harness). The Pilot
   drives key presses and click events; assertions look at widget
   state via ``app.query_one(...)``. ``asyncio.run`` is used to drive
   the async test body so we don't have to take a pytest-asyncio
   dependency.

Data sources (``images.list_images``, ``disks.list_disks``,
``fetch_remote_catalog``) are monkeypatched in the per-test fixtures
to return synthetic rows; the goal is to verify the wiring in
``_populate_images`` / ``_populate_disks`` / ``_load_images`` /
``action_refresh`` / ``_initial_status``, not to re-test the
underlying functions (those have their own coverage).
"""

from __future__ import annotations

import asyncio
import json
import urllib.error
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from bty import images
from bty.tui import _app as tui_app


def _run(coro: Any) -> Any:
    """Drive an async test body without pulling in pytest-asyncio."""
    return asyncio.run(coro)


def _fake_image(
    name: str = "demo.qcow2",
    fmt: str = "qcow2",
    size: int = 1024,
) -> images.Image:
    """Synthetic ``images.Image`` for monkeypatched list_images."""
    return images.Image(
        path=Path("/fake/images") / name,
        name=name,
        format=fmt,
        size_bytes=size,
    )


def _fake_disk(
    path: str = "/dev/sda",
    size: str = "500G",
    model: str = "Test Disk",
) -> dict[str, Any]:
    """Synthetic disk row matching ``disks.list_disks`` output shape."""
    return {
        "path": path,
        "size": size,
        "type": "disk",
        "vendor": "ATA",
        "model": model,
        "serial": "TEST123",
        "tran": "sata",
        "removable": False,
        "readonly": False,
        "mountpoints": [],
    }


def _fake_resp(payload: Any) -> MagicMock:
    """A context-manageable fake matching urlopen's protocol."""
    resp = MagicMock()
    resp.read.return_value = json.dumps(payload).encode("utf-8")
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


def test_fetch_remote_catalog_parses_image_entries(monkeypatch: pytest.MonkeyPatch) -> None:
    """``GET /images`` returns ``ImageEntry[]``; we wrap them as
    ``_TuiImage`` rows with the URL synthesised from ``<server>/images/<name>``."""
    payload = [
        {"name": "demo.qcow2", "format": "qcow2", "size_bytes": 1024, "path": "/x"},
        {"name": "live.img.zst", "format": "img.zst", "size_bytes": 4096, "path": "/y"},
    ]
    monkeypatch.setattr(
        tui_app.urllib.request,
        "urlopen",
        lambda *_args, **_kw: _fake_resp(payload),
    )

    rows = tui_app.fetch_remote_catalog("http://server:8080")

    assert len(rows) == 2
    assert rows[0].name == "demo.qcow2"
    assert rows[0].fmt == "qcow2"
    assert rows[0].size_bytes == 1024
    assert rows[0].url == "http://server:8080/images/demo.qcow2"
    assert rows[0].path is None  # remote rows never get a local path
    assert rows[1].url == "http://server:8080/images/live.img.zst"


def test_fetch_remote_catalog_strips_trailing_slash(monkeypatch: pytest.MonkeyPatch) -> None:
    """Server URLs with a trailing slash get normalised; the synthesised
    image URLs are stable regardless of how the operator typed it."""
    payload = [{"name": "demo.qcow2", "format": "qcow2", "size_bytes": 1}]
    monkeypatch.setattr(
        tui_app.urllib.request,
        "urlopen",
        lambda *_a, **_kw: _fake_resp(payload),
    )

    rows = tui_app.fetch_remote_catalog("http://server:8080/")
    assert rows[0].url == "http://server:8080/images/demo.qcow2"


def test_fetch_remote_catalog_skips_malformed_entries(monkeypatch: pytest.MonkeyPatch) -> None:
    """Entries that are not dicts or have no name are skipped; the rest
    are returned. Defensive against a server emitting a partial schema."""
    payload = [
        "not-a-dict",
        {"name": "", "format": "img"},  # blank name
        {"name": "ok.img", "format": "img", "size_bytes": 100},
    ]
    monkeypatch.setattr(
        tui_app.urllib.request,
        "urlopen",
        lambda *_a, **_kw: _fake_resp(payload),
    )

    rows = tui_app.fetch_remote_catalog("http://server")
    assert [r.name for r in rows] == ["ok.img"]


def test_fetch_remote_catalog_rejects_non_list_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        tui_app.urllib.request,
        "urlopen",
        lambda *_a, **_kw: _fake_resp({"oops": "not a list"}),
    )

    with pytest.raises(ValueError, match="not a list"):
        tui_app.fetch_remote_catalog("http://server")


def test_fetch_remote_catalog_propagates_url_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    def _boom(*_a: object, **_kw: object) -> None:
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr(tui_app.urllib.request, "urlopen", _boom)

    with pytest.raises(urllib.error.URLError):
        tui_app.fetch_remote_catalog("http://server")


def test_post_pxe_done_sends_post(monkeypatch: pytest.MonkeyPatch) -> None:
    """``post_pxe_done`` issues a POST against ``<server>/pxe/<mac>/done``."""
    seen: dict[str, str] = {}

    class _FakeOpen:
        def __enter__(self) -> _FakeOpen:
            return self

        def __exit__(self, *_a: object) -> None:
            pass

    def _capture(req: Any, **_kw: object) -> _FakeOpen:
        seen["url"] = req.full_url
        seen["method"] = req.get_method()
        return _FakeOpen()

    monkeypatch.setattr(tui_app.urllib.request, "urlopen", _capture)

    tui_app.post_pxe_done("http://server:8080", "aa:bb:cc:dd:ee:ff")

    assert seen["url"] == "http://server:8080/pxe/aa:bb:cc:dd:ee:ff/done"
    assert seen["method"] == "POST"


def test_post_pxe_done_strips_trailing_slash_from_server_url(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    seen: dict[str, str] = {}

    class _FakeOpen:
        def __enter__(self) -> _FakeOpen:
            return self

        def __exit__(self, *_a: object) -> None:
            pass

    def _capture(req: Any, **_kw: object) -> _FakeOpen:
        seen["url"] = req.full_url
        return _FakeOpen()

    monkeypatch.setattr(tui_app.urllib.request, "urlopen", _capture)
    tui_app.post_pxe_done("http://server:8080/", "aa:bb:cc:dd:ee:ff")
    assert seen["url"] == "http://server:8080/pxe/aa:bb:cc:dd:ee:ff/done"


def test_post_pxe_done_propagates_url_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    def _boom(*_a: object, **_kw: object) -> None:
        raise urllib.error.URLError("server gone")

    monkeypatch.setattr(tui_app.urllib.request, "urlopen", _boom)

    with pytest.raises(urllib.error.URLError):
        tui_app.post_pxe_done("http://server", "aa:bb:cc:dd:ee:ff")


def test_main_accepts_server_and_mac_flags(monkeypatch: pytest.MonkeyPatch) -> None:
    """``bty-tui --server URL --mac MAC`` reaches ``BtyTui(...)`` with
    the right kwargs. The actual ``run()`` is monkeypatched so we
    don't try to launch a real TUI from a unit test."""
    captured: dict[str, object] = {}

    class _FakeBtyTui:
        def __init__(
            self,
            image_root: object = None,
            *,
            server_url: object = None,
            mac: object = None,
        ) -> None:
            captured["image_root"] = image_root
            captured["server_url"] = server_url
            captured["mac"] = mac

        def run(self) -> None:
            captured["ran"] = True

    monkeypatch.setattr(tui_app, "BtyTui", _FakeBtyTui)

    # Re-import the entry-point to make sure it picks up the patched class.
    import bty.tui as tui_mod

    tui_mod.main(["--server", "http://srv:8080", "--mac", "aa:bb:cc:dd:ee:ff"])

    assert captured["server_url"] == "http://srv:8080"
    assert captured["mac"] == "aa:bb:cc:dd:ee:ff"
    assert captured["ran"] is True


# ---------- end-to-end: BtyTui driven via textual's Pilot ------------------
#
# These run the actual textual ``App`` headless in pytest. The Pilot
# simulates key presses; assertions look at widget state via
# ``app.query_one(...)``. Data sources are monkeypatched on the
# ``bty.tui._app`` module references so the app sees synthetic rows
# without touching the real filesystem / lsblk / network.


def _patch_data_sources(
    monkeypatch: pytest.MonkeyPatch,
    *,
    images_list: list[images.Image] | None = None,
    disks_list: list[dict[str, Any]] | None = None,
    remote_catalog: list[Any] | None = None,
    geteuid: int = 0,
) -> None:
    """Wire fake data into the module-level references the TUI uses.

    ``images_list`` / ``disks_list`` feed the local-mode populate paths.
    ``remote_catalog`` feeds the remote-mode catalog fetch.
    ``geteuid`` controls the read-only-vs-flashable status string.
    """
    monkeypatch.setattr(tui_app.os, "geteuid", lambda: geteuid)
    monkeypatch.setattr(
        tui_app.images,
        "list_images",
        lambda _root: list(images_list or []),
    )
    monkeypatch.setattr(
        tui_app.disks,
        "list_disks",
        lambda: list(disks_list or []),
    )
    if remote_catalog is not None:
        monkeypatch.setattr(
            tui_app,
            "fetch_remote_catalog",
            lambda _url: list(remote_catalog),
        )


def _spy_status(monkeypatch: pytest.MonkeyPatch) -> list[str]:
    """Capture every ``_set_status`` call. Cleaner than poking textual
    Static internals (the rendered-text accessor is private)."""
    captured: list[str] = []
    original = tui_app.BtyTui._set_status

    def _capturing(self: tui_app.BtyTui, message: str) -> None:
        captured.append(message)
        original(self, message)

    monkeypatch.setattr(tui_app.BtyTui, "_set_status", _capturing)
    return captured


def test_app_renders_local_panes_with_seeded_data(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Launch the app with one seeded image + one seeded disk; both
    DataTables populate and the initial status surfaces the
    flash-allowed prompt (geteuid=0)."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image(name="alpha.qcow2", size=4096)],
        disks_list=[_fake_disk(path="/dev/sda")],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import DataTable

            images_table = app.query_one("#images_table", DataTable)
            disks_table = app.query_one("#disks_table", DataTable)
            assert images_table.row_count == 1
            assert disks_table.row_count == 1
            assert "press F to flash" in app._initial_status()  # type: ignore[reportPrivateUsage]

    _run(_drive())


def test_app_shows_no_images_message_when_local_root_is_empty(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Empty image root -> ``_set_status`` is called with the
    "No images at <path>; press R to refresh" message during the
    initial populate."""
    statuses = _spy_status(monkeypatch)
    _patch_data_sources(monkeypatch, images_list=[], disks_list=[_fake_disk()])

    app = tui_app.BtyTui(image_root=tmp_path / "empty")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()

    _run(_drive())
    assert any("No images at" in s and "press R to refresh" in s for s in statuses)


def test_app_refresh_action_repopulates(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Pressing ``r`` re-runs the populate path. First call returns an
    empty list, second call returns one image; after the keypress the
    images table has the new row and ``Refreshed.`` shows in status."""
    statuses = _spy_status(monkeypatch)
    images_returns = [
        [],  # first populate (on mount)
        [_fake_image()],  # second populate (after R)
    ]
    call_count = 0

    def _list_images(_root: Path) -> list[images.Image]:
        nonlocal call_count
        call_count += 1
        return images_returns.pop(0) if images_returns else []

    monkeypatch.setattr(tui_app.os, "geteuid", lambda: 0)
    monkeypatch.setattr(tui_app.images, "list_images", _list_images)
    monkeypatch.setattr(tui_app.disks, "list_disks", lambda: [_fake_disk()])

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import DataTable

            images_table = app.query_one("#images_table", DataTable)
            assert images_table.row_count == 0  # initial: empty

            await pilot.press("r")
            await pilot.pause()

            assert images_table.row_count == 1  # second populate landed

    _run(_drive())
    assert call_count == 2  # populate ran on mount + on refresh
    assert any("Refreshed" in s for s in statuses)


def test_app_non_root_status_says_read_only(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Without root (geteuid != 0), ``_initial_status`` returns the
    read-only message so the operator knows ``F`` won't work."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk()],
        geteuid=1000,
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            assert "Read-only mode" in app._initial_status()  # type: ignore[reportPrivateUsage]

    _run(_drive())


def test_app_remote_mode_renders_catalog_from_server(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--server URL`` swaps the local image-root scan for
    ``fetch_remote_catalog``. The Images pane title shows the server
    URL; the table populates from the mocked remote catalog."""
    remote_rows = [
        tui_app._TuiImage(
            name="remote.img.zst",
            fmt="img.zst",
            size_bytes=8192,
            url="http://server:8080/images/remote.img.zst",
        )
    ]
    _patch_data_sources(
        monkeypatch,
        disks_list=[_fake_disk()],
        remote_catalog=remote_rows,
    )

    app = tui_app.BtyTui(server_url="http://server:8080")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import DataTable

            images_table = app.query_one("#images_table", DataTable)
            assert images_table.row_count == 1
            # The remote URL is the row key (used to drive the URL flash
            # path in action_flash); confirm the entry round-trips.
            row = next(iter(app._images_by_key.values()))  # type: ignore[reportPrivateUsage]
            assert row.url == "http://server:8080/images/remote.img.zst"
            assert row.path is None  # remote rows never carry a local path

    _run(_drive())


# --------------------------------------------------------------------------
# M20: TUI polish (theme, filter, welcome panel, details pane, flash modal)
# --------------------------------------------------------------------------


def test_app_uses_tokyo_night_theme(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """The app picks Tokyo Night on mount (matches the bty mascot's
    navy + warm-yellow palette)."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk()],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            assert app.theme == "tokyo-night"

    _run(_drive())


def test_app_welcome_panel_has_local_onboarding_text_when_empty(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Empty local catalog -> welcome Static is populated with
    local-mode onboarding (BTY_IMAGES partition guidance)."""
    _patch_data_sources(monkeypatch, images_list=[], disks_list=[_fake_disk()])

    app = tui_app.BtyTui(image_root=tmp_path / "empty")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Static

            welcome = app.query_one("#welcome", Static)
            text_str = str(welcome.content)
            # Local-mode markers: BTY_IMAGES partition + image-root path
            assert "BTY_IMAGES" in text_str
            assert str(tmp_path / "empty") in text_str

    _run(_drive())


def test_app_welcome_panel_has_remote_onboarding_text_when_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty remote catalog -> welcome Static is populated with
    remote-mode onboarding (PUT /images guidance)."""
    _patch_data_sources(monkeypatch, disks_list=[_fake_disk()], remote_catalog=[])

    app = tui_app.BtyTui(server_url="http://server:8080")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Static

            welcome = app.query_one("#welcome", Static)
            text_str = str(welcome.content)
            # Remote-mode markers: server URL + the PUT example
            assert "http://server:8080/images" in text_str
            assert "curl -X PUT" in text_str

    _run(_drive())


def test_app_welcome_panel_clears_when_catalog_populated(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Non-empty catalog -> welcome Static is cleared so the panel
    collapses and the table fills the space."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk()],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Static

            welcome = app.query_one("#welcome", Static)
            text_str = str(welcome.content)
            assert text_str == ""

    _run(_drive())


def test_app_filter_action_focuses_input(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """``/`` makes the filter Input visible + focused so the operator
    can type a substring. Pressing it from the table (initial focus)
    should not type ``/`` into the table."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk()],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Input

            await pilot.press("slash")
            await pilot.pause()
            filter_input = app.query_one("#filter-input", Input)
            assert filter_input.has_class("active")
            assert filter_input.has_focus

    _run(_drive())


def test_app_filter_narrows_catalog_to_matching_substring(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Submitting the filter Input narrows the images table to rows
    whose name contains the substring (case-insensitive). Other
    rows go away; non-matching filter -> empty table."""
    _patch_data_sources(
        monkeypatch,
        images_list=[
            _fake_image(name="alpha.qcow2"),
            _fake_image(name="beta.img.zst"),
            _fake_image(name="gamma.qcow2"),
        ],
        disks_list=[_fake_disk()],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import DataTable, Input

            images_table = app.query_one("#images_table", DataTable)
            assert images_table.row_count == 3  # all three pre-filter

            # Apply the filter via the Input's value (instead of
            # typing each character through pilot, which is slow and
            # easy to fight focus on).
            filter_input = app.query_one("#filter-input", Input)
            filter_input.value = "qcow2"
            # Trigger the submitted handler the way Enter does.
            app._filter = "qcow2"  # type: ignore[reportPrivateUsage]
            app._populate_images()  # type: ignore[reportPrivateUsage]
            await pilot.pause()
            assert images_table.row_count == 2  # alpha + gamma match qcow2

    _run(_drive())


def test_app_filter_escape_clears_and_repopulates(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``escape`` clears the active filter, re-populates the catalog,
    and emits a ``Filter cleared.`` status."""
    _patch_data_sources(
        monkeypatch,
        images_list=[
            _fake_image(name="alpha.qcow2"),
            _fake_image(name="beta.img.zst"),
        ],
        disks_list=[_fake_disk()],
    )
    statuses = _spy_status(monkeypatch)

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import DataTable

            # Apply a filter that excludes ``beta``
            app._filter = "alpha"  # type: ignore[reportPrivateUsage]
            app._populate_images()  # type: ignore[reportPrivateUsage]
            await pilot.pause()
            images_table = app.query_one("#images_table", DataTable)
            assert images_table.row_count == 1

            # escape should clear the filter
            await pilot.press("escape")
            await pilot.pause()
            assert app._filter == ""  # type: ignore[reportPrivateUsage]
            assert images_table.row_count == 2  # both rows back
            assert any("Filter cleared" in s for s in statuses)

    _run(_drive())


def test_app_details_pane_updates_on_image_row_highlight(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Moving the cursor to an image row updates the details pane
    with the image's name + format + size + source."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image(name="my-image.qcow2", fmt="qcow2", size=1024)],
        disks_list=[_fake_disk()],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Static

            # The first image row is highlighted by default after
            # populate; the details pane should already reflect it.
            body = app.query_one("#details-body", Static)
            text_str = str(body.content)
            assert "my-image.qcow2" in text_str
            assert "qcow2" in text_str
            assert "1,024 bytes" in text_str  # comma-grouped formatting

    _run(_drive())


def test_app_details_pane_renders_disk_metadata(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``_show_disk_details`` renders vendor / model / transport /
    serial / removable / readonly into the details pane. The rendering
    logic is the contract; the textual ``RowHighlighted`` message
    routing that calls it is textual's job, not ours to retest."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk(path="/dev/sdb", model="Acme NVMe", size="2T")],
    )

    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Static

            disk = next(iter(app._disks_by_key.values()))  # type: ignore[reportPrivateUsage]
            app._show_disk_details(disk)  # type: ignore[reportPrivateUsage]
            await pilot.pause()

            body = app.query_one("#details-body", Static)
            text_str = str(body.content)
            assert "/dev/sdb" in text_str
            assert "Acme NVMe" in text_str
            assert "2T" in text_str
            assert "ATA" in text_str  # vendor (default in _fake_disk)

    _run(_drive())


# --------------------------------------------------------------------------
# FlashStatusScreen stage tracker (M20)
# --------------------------------------------------------------------------


def _fake_flash_plan() -> tui_app.flash.FlashPlan:
    """Synthesize a minimal FlashPlan for FlashStatusScreen tests.

    The plan's content doesn't matter; we mock ``flash.execute_plan``
    so it never actually touches the disk.
    """
    image = tui_app.flash.ImageInfo(
        path=Path("/fake/images/demo.qcow2"),
        format="qcow2",
        size_bytes=1024,
        virtual_size_bytes=2048,
    )
    target = tui_app.flash.TargetInfo(
        path=Path("/dev/sdz"),
        exists=True,
        is_block_device=True,
        size_bytes=8192,
        mountpoints=[],
    )
    return tui_app.flash.FlashPlan(
        image=image,
        target=target,
        provisioning_mode="none",
    )


def test_flash_status_screen_ticks_stages_on_success(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """As ``flash.execute_plan`` emits each lifecycle event the stage
    tracker advances: prior stages get ``done``, the active one gets
    ``active``. After completion all five stages (started, writing,
    synced, partprobed, done) are marked ``done``."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk()],
    )

    def _fake_execute_plan(plan: Any, progress: Any = None) -> None:
        # Walk through the four lifecycle events the screen renders
        # as stages (the fifth, ``done``, is ticked by the screen
        # itself after execute_plan returns).
        if progress is None:
            return
        for ev in ("started", "writing", "synced", "partprobed"):
            progress(tui_app.flash.FlashProgress(event=ev))

    monkeypatch.setattr(tui_app.flash, "execute_plan", _fake_execute_plan)

    plan = _fake_flash_plan()
    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Button, Static

            screen = tui_app.FlashStatusScreen(plan)
            app.push_screen(screen)
            # Drain the worker thread + queued call_from_thread updates.
            for _ in range(20):
                await pilot.pause()

            # All five stages should be done.
            for ev_name, _ in tui_app.FlashStatusScreen._STAGES:  # type: ignore[reportPrivateUsage]
                widget = screen.query_one(f"#stage-{ev_name}", Static)
                assert "done" in widget.classes, (
                    f"stage {ev_name} not marked done: classes={widget.classes}"
                )

            # Close button is now enabled (worker reported success).
            close_btn = screen.query_one("#close", Button)
            assert close_btn.disabled is False

    _run(_drive())


def test_flash_status_screen_marks_failed_stage_on_FlashError(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When ``flash.execute_plan`` raises a ``FlashError`` partway
    through, the currently-active stage is marked ``failed`` (not
    done) and the close button enables so the operator can dismiss."""
    _patch_data_sources(
        monkeypatch,
        images_list=[_fake_image()],
        disks_list=[_fake_disk()],
    )

    def _fake_execute_plan(plan: Any, progress: Any = None) -> None:
        if progress is not None:
            progress(tui_app.flash.FlashProgress(event="started"))
            progress(tui_app.flash.FlashProgress(event="writing"))
        raise tui_app.flash.FlashError("boom: simulated write failure")

    monkeypatch.setattr(tui_app.flash, "execute_plan", _fake_execute_plan)

    plan = _fake_flash_plan()
    app = tui_app.BtyTui(image_root=tmp_path / "images")

    async def _drive() -> None:
        async with app.run_test() as pilot:
            await pilot.pause()
            from textual.widgets import Button, Static

            screen = tui_app.FlashStatusScreen(plan)
            app.push_screen(screen)
            for _ in range(20):
                await pilot.pause()

            # ``writing`` was active when the failure landed; expect
            # it marked ``failed``. Earlier ``started`` is ``done``;
            # later stages are still ``pending``.
            started = screen.query_one("#stage-started", Static)
            writing = screen.query_one("#stage-writing", Static)
            synced = screen.query_one("#stage-synced", Static)
            assert "done" in started.classes
            assert "failed" in writing.classes
            assert "pending" in synced.classes

            close_btn = screen.query_one("#close", Button)
            assert close_btn.disabled is False  # enabled to let operator dismiss

    _run(_drive())
