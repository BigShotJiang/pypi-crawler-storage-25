# lse-data

Python SDK for [London Strategic Edge](https://londonstrategicedge.com) real-time market data.

Stream live prices for **2,000+ instruments** including stocks, crypto, forex, indices, commodities, ETFs, and options.

## Install

```bash
pip install lse-data
```

## Quick start

```python
from lse import LSE

client = LSE(api_key="your_api_key")

for tick in client.stream(["BTC/USD", "AAPL", "EUR/USD"]):
    print(f"{tick.symbol}: ${tick.price}")
```

Get your API key at [londonstrategicedge.com/data](https://londonstrategicedge.com/data).

## Features

- Real-time WebSocket streaming with auto-reconnect
- 2,000+ symbols: US/UK/EU/Asia stocks, crypto, forex, indices, commodities, options
- Sync and async interfaces
- Callback and iterator patterns
- Zero config, just an API key

## Usage

### Stream ticks (simplest)

```python
from lse import LSE

client = LSE(api_key="your_key")

for tick in client.stream(["BTC/USD", "ETH/USD", "AAPL"]):
    print(f"{tick.symbol:12s} ${tick.price:>12,.2f}")
```

### Callback style

```python
from lse import LSE

def on_tick(tick):
    print(f"{tick.symbol}: {tick.price}")

client = LSE(api_key="your_key")
client.on("tick", on_tick)
client.connect(symbols=["BTC/USD", "ETH/USD"])
```

### Async streaming

```python
import asyncio
from lse import LSE

async def main():
    client = LSE(api_key="your_key")
    async for tick in client.stream_async(["BTC/USD"]):
        print(tick)

asyncio.run(main())
```

### Save to CSV

```python
import csv, datetime
from lse import LSE

client = LSE(api_key="your_key")

with open("ticks.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["time", "symbol", "price", "bid", "ask"])

    for tick in client.stream(["BTC/USD", "ETH/USD"]):
        writer.writerow([
            datetime.datetime.now().isoformat(),
            tick.symbol, tick.price, tick.bid, tick.ask,
        ])
```

## Tick object

Each tick has these fields:

| Field | Type | Description |
|-------|------|-------------|
| `symbol` | `str` | Instrument symbol (e.g. `BTC/USD`, `AAPL`) |
| `price` | `float` | Latest price |
| `bid` | `float` | Bid price (if available) |
| `ask` | `float` | Ask price (if available) |
| `volume` | `float` | Volume (if available) |
| `timestamp` | `float` | Unix timestamp |
| `name` | `str` | Human-readable name (e.g. `Apple Inc.`) |

## Events

When using the callback style with `.on()`:

| Event | Callback args | Description |
|-------|---------------|-------------|
| `tick` | `Tick` | New price tick |
| `connected` | (none) | WebSocket connected |
| `authenticated` | (none) | API key accepted |
| `disconnected` | (none) | Connection lost (will auto-reconnect) |
| `error` | `str` | Error message |

## Available symbols

After connecting, `client.symbols` contains the full list of available instruments:

```python
client = LSE(api_key="your_key")

# stream() handles connection internally, but you can also connect manually:
import asyncio, json, websockets

async def list_symbols():
    async with websockets.connect("wss://data-ws.londonstrategicedge.com") as ws:
        await ws.recv()  # welcome
        await ws.send(json.dumps({"action": "auth", "api_key": "your_key"}))
        data = json.loads(await ws.recv())
        for s in data["symbols"]:
            print(s["symbol"], s.get("name", ""))

asyncio.run(list_symbols())
```

## Requirements

- Python 3.8+
- `websockets` (installed automatically)

## License

MIT
