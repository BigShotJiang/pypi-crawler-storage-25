# Repo Committer ⏳

![Repo Committer UI](screenshots/screenshot.png)

A simple, beautifully designed local Flask web application that allows you to easily _backdate_ or _forward-date_ your GitHub commits. The app modifies standard environment parameters (`GIT_AUTHOR_DATE` and `GIT_COMMITTER_DATE`) underneath the hood to track an `activity.log` file at a custom chosen timestamp.

## Features ✨

- **Premium CLI-GUI Interface**: A distinctive "modern coding" aesthetic featuring responsive panels, terminal styling, and real-time process logs.
- **Single Commit Mode**: Execute pinpointed commits at any chosen timestamp, with support for multiple iterations (automatic 1-minute increments).
- **Batch Processing**: Distribute any number of commits randomly across a specified date range—ideal for populating your contribution graph at scale.
- **Git Hook Integration**: Modifies `GIT_AUTHOR_DATE` and `GIT_COMMITTER_DATE` to track an `activity.log` file without manual terminal configurations.
- **Lightweight & Portable**: Runs entirely within a local Flask environment with minimal dependencies.

## Setup & Installation 🛠️

Ensure you have [Python 3.x](https://www.python.org/) and Git installed on your system.

**1. Clone the Repository:**

```bash
git clone https://github.com/n4od/repo-committer.git
cd repo-committer
```

**2. Install Dependencies:**
It's highly recommended to use a virtual environment, but you can also install directly.

```bash
pip install -r requirements.txt
```

_(The only dependency required is Flask)._

**3. Run the Application:**

```bash
python app.py
```

**4. Access the Web Interface:**
Open your browser and navigate to `http://127.0.0.1:5000`

## How it Works 🧠

1. **Input Parsing**: The frontend sends either a specific timestamp or a date range to the Flask backend.
2. **Process Execution**: The `app.py` script calculates the required number of commits.
3. **Metadata Manipulation**: For each commit, the script updates the `activity.log` file and temporarily exports `GIT_AUTHOR_DATE` and `GIT_COMMITTER_DATE` for that specific iteration.
4. **Git Transaction**: The program executes `git add activity.log` and `git commit -m "..."` via Python's `subprocess`.
5. **Real-time Logs**: Execution feedback is streamed back to the UI terminal in real-time.

## Important Note ⚠️

This application alters your local `.git` metadata for particular commits. For the commits to appear on GitHub with the correct backdated sequence, run `git push origin main` (or your respective branch) as you normally would. Ensure your terminal has standard Git hooks tracking authorship (`user.email` and `user.name`) set appropriately.

## Author & Credits 🚀

**Repo Committer** was created and brought to life by **[n4od](https://github.com/n4od)**.
If this tool made your Git history look a whole lot greener, consider giving the repo a ⭐️ and checking out my other projects!

---

_Built with passion by [@n4od](https://github.com/n4od)._

## License 📜

Distributed under the MIT License. See `LICENSE` for more information.
