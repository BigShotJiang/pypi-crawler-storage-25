# Changelog

All notable changes to **Repo Committer** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-04-06

### Added
- **Batch Processing Mode:** New endpoint and UI tab to generate any number of random commits across a specified date range.
- **Premium CLI-GUI Design:** Complete visual overhaul with a technical coding aesthetic, terminal-style logs, and a futuristic workspace layout.
- **Incremental Commit Spacing:** Support for multiple commits at a single timestamp with automatic 1-minute sequential offsets.
- **Creator UI Integration:** Added author credits to the interface with direct links to the GitHub profile.

### Changed
- **UI Architecture:** Migrated to a dual-tab system for seamless switching between Single and Batch modes.
- **Enhanced Logging:** Replaced simple alerts with a high-fidelity terminal component for execution feedback.

## [1.0.0] - 2026-04-06

### Added
- **Initial Release:** Fully functional local Flask web app to backdate or forward-date GitHub commits.
- **Python Backend:** Included `app.py` utilizing the `subprocess` module to manipulate `GIT_AUTHOR_DATE` and `GIT_COMMITTER_DATE`.
- **Beautiful UI Frontend:** Added `templates/index.html` featuring a glassmorphism design, clean animations, and a sleek HTML5 `datetime-local` input picker.
- **Activity Log Tracking:** Implemented local `activity.log` file tracking to push timestamped string logs with every commit natively.
- **Comprehensive README:** Added a beautifully documented `README.md` with setup instructions and project details.

### Changed
- **Branding:** Renamed the initial concept from "Ripo Comiter" & "Time Travel Commits" to the official **Repo Committer**.

### Fixed
- Handled dynamic parsing of both default HTML5 `datetime-local` payloads and fallback date strings.
- Implemented robust error handling from UI (loading spinners, disabled buttons) downstream to Flask server-side subprocess responses.

---

*Authored by [n4od](https://github.com/n4od)*
