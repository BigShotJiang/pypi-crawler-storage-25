"""Differentiable depth rendering via implicit function theorem (IFT).

Forward pass uses the existing NumPy bisection pipeline to robustly find
surface points.  The backward pass applies the IFT at surface points to
compute exact depth gradients w.r.t. any torch parameter used by ``f``.

Key identity (IFT):
    Given f(o + t*d, θ) = 0 on the surface,
    dt/dθ = −(∂f/∂θ) / (∇ₓf · d)

This is implemented as a *surrogate* expression whose value equals the
forward depth but whose autograd gradient equals the IFT derivative:
    t_surr = t_detached − f(p*) / (∇ₓf · d)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

from isoray.arithmetic.interval import GradientInclusion
from isoray.renderer.camera import generate_rays, generate_rays_parallel
from isoray.renderer.render import _compute_camera
from isoray.tracer.bisection import bisect_trace
from isoray.tracer.ray import ray_aabb_intersect
from isoray.tracer.refine import newton_refine

# ---------------------------------------------------------------------------
# NumPy wrapper — adapts a torch callable to the ImplicitFunction protocol
# ---------------------------------------------------------------------------


class _TorchToNumpy:
    """Wraps a ``torch.Tensor → torch.Tensor`` function for the NumPy pipeline.

    Evaluates the torch function under ``torch.no_grad()`` and converts
    tensors to/from NumPy.  If the torch function is differentiable,
    gradients are computed for ``GradientInclusion`` (but NOT tracked in
    the autograd graph — that happens only in the backward surrogate).
    """

    def __init__(self, f_torch, bounds, dtype, device):
        self.f_torch = f_torch
        self._bounds = (
            np.asarray(bounds[0], dtype=np.float64),
            np.asarray(bounds[1], dtype=np.float64),
        )
        self.dtype = dtype
        self.device = device

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        pos_t = torch.tensor(pos, dtype=self.dtype, device=self.device, requires_grad=True)
        with torch.enable_grad():
            val_t = self.f_torch(pos_t)
            try:
                (grad_t,) = torch.autograd.grad(val_t.sum(), pos_t)
                grad_np = grad_t.detach().cpu().numpy()
            except RuntimeError:
                # f might not be differentiable w.r.t. pos (unlikely but safe)
                grad_np = None
        return val_t.detach().cpu().numpy(), grad_np

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        return self._bounds[0].copy(), self._bounds[1].copy()


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class TorchRenderResult:
    """Result of :func:`render_depth`.

    Attributes:
        depth: ``(H, W)`` differentiable depth tensor.  Gradients flow
            through hit pixels to any ``requires_grad`` parameter used
            by the implicit function.  Non-hit pixels are 0 with no gradient.
        hit: ``(H, W)`` boolean mask (True where a surface was found).
        hit_count: Number of hit pixels.
    """

    depth: torch.Tensor
    hit: torch.Tensor
    hit_count: int


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render_depth(
    f,
    bounds: tuple,
    *,
    # Camera
    direction=(1, 1, 1),
    distance: float | None = None,
    target=None,
    up=(0, 1, 0),
    fov_deg: float = 60.0,
    projection: str = "perspective",
    # Resolution
    width: int = 256,
    height: int = 256,
    # Tracing
    lipschitz: float = 1.0,
    max_depth: int = 40,
    threshold: float = 1e-5,
    newton_iter: int = 3,
    # Torch
    dtype: torch.dtype = torch.float64,
    device: str | torch.device = "cpu",
    grad_clamp: float = 1e-6,
) -> TorchRenderResult:
    """Render a differentiable depth map of an implicit surface.

    The forward pass uses the full NumPy bisection pipeline (robust
    interval-arithmetic root finding).  The backward pass computes
    ``dt/dθ`` via the implicit function theorem — no need to
    differentiate through the bisection itself.

    Args:
        f: Implicit function in PyTorch.
            Signature: ``f(pos: Tensor(N,3)) -> Tensor(N,)``.
            Must be differentiable w.r.t. both ``pos`` and any captured
            parameters that require gradients.
        bounds: Axis-aligned bounding box ``(lo, hi)``, each shape ``(3,)``.
        direction: Direction from object toward camera (auto-normalized).
        distance: Camera distance from target.  ``None`` = auto.
        target: Look-at point.  ``None`` = center of *bounds*.
        up: World up vector.
        fov_deg: Vertical FOV in degrees (perspective only).
        projection: ``"perspective"`` or ``"parallel"``.
        width: Image width in pixels.
        height: Image height in pixels.
        lipschitz: Lipschitz constant for the inclusion function.
        max_depth: Maximum bisection depth.
        threshold: Bisection convergence threshold.
        newton_iter: Newton refinement iterations (0 = disable).
        dtype: Torch dtype (``float64`` recommended for numerical stability).
        device: Torch device.
        grad_clamp: Minimum ``|∇f · d|`` to prevent division-by-zero
            for grazing rays.

    Returns:
        :class:`TorchRenderResult` with differentiable depth and hit mask.

    Example::

        import torch
        from isoray.torch import render_depth

        radius = torch.tensor(1.0, requires_grad=True)

        def sphere(pos):
            return (pos ** 2).sum(dim=1) - radius ** 2

        result = render_depth(sphere, bounds=([-1.5]*3, [1.5]*3))
        loss = result.depth[result.hit].sum()
        loss.backward()
        print(radius.grad)  # d(total_depth) / d(radius)
    """
    R = height * width

    # --- NumPy wrapper ---
    f_np = _TorchToNumpy(f, bounds, dtype=dtype, device=device)

    # --- Camera setup (reuses existing logic) ---
    dir_arr = np.asarray(direction, dtype=np.float64)
    up_arr = np.asarray(up, dtype=np.float64)
    target_arr = np.asarray(target, dtype=np.float64) if target is not None else None
    lo = np.asarray(bounds[0], dtype=np.float64)
    hi = np.asarray(bounds[1], dtype=np.float64)

    eye, target_pt, half_diag = _compute_camera(
        (lo, hi), dir_arr, distance, target_arr, fov_deg, projection
    )

    # --- Ray generation ---
    if projection == "perspective":
        origins, directions = generate_rays(
            width, height, fov_deg=fov_deg, eye=eye, target=target_pt, up=up_arr
        )
    else:
        extent = half_diag * 1.1
        origins, directions = generate_rays_parallel(
            width, height, extent=extent, eye=eye, target=target_pt, up=up_arr
        )

    # --- Ray-AABB intersection ---
    margin = (hi - lo) * 0.01
    t_min, t_max, hit_mask = ray_aabb_intersect(
        origins, directions, lo - margin, hi + margin
    )

    # --- Bisection trace ---
    inclusion = GradientInclusion(f_np, lipschitz=lipschitz)
    trace = bisect_trace(
        origins, directions, t_min, t_max, hit_mask, inclusion, f_np,
        max_depth=max_depth, threshold=threshold,
    )

    # --- Newton refinement ---
    if newton_iter > 0:
        trace.t = newton_refine(
            trace.t, origins, directions, trace.hit, f_np,
            t_lo=trace.t_lo, t_hi=trace.t_hi, max_iter=newton_iter,
        )

    # --- IFT surrogate for differentiable depth ---
    hit_np = trace.hit  # (R,) bool
    t_np = trace.t  # (R,) float64
    hit_idx = np.where(hit_np)[0]

    if len(hit_idx) > 0:
        # Surface points from the forward solve
        p_star_np = origins[hit_idx] + t_np[hit_idx, None] * directions[hit_idx]
        d_np = directions[hit_idx]

        # Evaluate f in torch WITH autograd graph
        p_star = torch.tensor(p_star_np, dtype=dtype, device=device, requires_grad=True)
        d_t = torch.tensor(d_np, dtype=dtype, device=device)
        t_det = torch.tensor(t_np[hit_idx], dtype=dtype, device=device)

        f_vals = f(p_star)  # (N_hit,)
        (grad_x,) = torch.autograd.grad(
            f_vals.sum(), p_star, create_graph=True,
        )  # (N_hit, 3)

        # Directional derivative along ray: ∇f · d
        dot = (grad_x * d_t).sum(dim=1)  # (N_hit,)

        # Clamp to avoid division-by-zero at grazing incidence
        dot_clamped = torch.where(
            dot.abs() < grad_clamp,
            torch.where(dot >= 0, grad_clamp, -grad_clamp),
            dot,
        )

        # IFT surrogate:
        #   value  ≈ t*           (because f(p*) ≈ 0 after Newton)
        #   grad   = −∂f/∂θ / (∇f·d)   (exact IFT derivative)
        t_surr = t_det - f_vals / dot_clamped

        # Scatter into full (R,) depth tensor
        idx_t = torch.from_numpy(hit_idx).long().to(device)
        depth_flat = torch.zeros(R, dtype=dtype, device=device)
        depth_flat = depth_flat.scatter(0, idx_t, t_surr)
    else:
        # No hits — return a zero tensor that still supports backward()
        # by giving it a trivial grad_fn (0 * dummy).
        depth_flat = torch.zeros(R, dtype=dtype, device=device, requires_grad=True)

    hit_t = torch.from_numpy(hit_np).to(device)

    return TorchRenderResult(
        depth=depth_flat.reshape(height, width),
        hit=hit_t.reshape(height, width),
        hit_count=int(hit_np.sum()),
    )
