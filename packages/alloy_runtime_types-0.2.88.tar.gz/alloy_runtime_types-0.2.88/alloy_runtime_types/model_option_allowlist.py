from __future__ import annotations

import math
import re
from collections.abc import Mapping
from typing import Any, cast

ALLOWED_MODEL_OPTIONS_KEYS: frozenset[str] = frozenset(
    {
        "temperature",
        "max_tokens",
        "max_completion_tokens",
        "top_p",
        "top_k",
        "frequency_penalty",
        "presence_penalty",
        "seed",
        "stop",
        "user",
        "reasoning_effort",
        "thinking",
        "reasoning",
        "include",
        "safety_settings",
    }
)

PROTECTED_EXTRA_HEADERS: frozenset[str] = frozenset(
    {
        "authorization",
        "proxy-authorization",
        "x-api-key",
        "api-key",
        "x-goog-api-key",
        "x-auth-token",
        "cookie",
        "set-cookie",
    }
)

REDACTED_EXTRA_HEADER_VALUE = "[REDACTED]"

_SENSITIVE_HEADER_TOKEN_PATTERN = re.compile(
    r"(^|[-_])(?:authorization|auth|api[-_]?key|apikey|token|credential|secret|cookie)([-_]|$)",
    re.IGNORECASE,
)


def is_sensitive_header_name(name: str) -> bool:
    normalized = name.strip().lower()
    return normalized in PROTECTED_EXTRA_HEADERS or bool(
        _SENSITIVE_HEADER_TOKEN_PATTERN.search(normalized)
    )


def redact_extra_headers(headers: Mapping[str, Any] | None) -> dict[str, str]:
    if not headers:
        return {}
    return {str(key).lower(): REDACTED_EXTRA_HEADER_VALUE for key in headers}


def _is_redacted_placeholder(value: Any) -> bool:
    return isinstance(value, str) and value.strip() in {
        REDACTED_EXTRA_HEADER_VALUE,
        "***REDACTED***",
    }


def _validate_temperature_model_option(value: Any, *, field_name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ValueError(f"{field_name}.temperature must be a number between 0 and 2")

    numeric_value = float(value)
    if not math.isfinite(numeric_value) or numeric_value < 0 or numeric_value > 2:
        raise ValueError(f"{field_name}.temperature must be between 0 and 2")


def _validate_positive_integer_model_option(
    option_name: str,
    value: Any,
    *,
    field_name: str,
) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field_name}.{option_name} must be a positive integer")
    if value <= 0:
        raise ValueError(f"{field_name}.{option_name} must be greater than 0")


def normalize_model_options(
    model_options: Any,
    *,
    field_name: str = "model_options",
    strip_null_values: bool = False,
) -> dict[str, Any]:
    if not isinstance(model_options, dict):
        raise ValueError(f"{field_name} must be an object")

    raw_model_options = cast(dict[object, Any], model_options)
    non_string_keys = [
        raw_key for raw_key in raw_model_options if not isinstance(raw_key, str)
    ]
    if non_string_keys:
        raise ValueError(f"{field_name} keys must be strings")

    normalized_model_options = dict(cast(dict[str, Any], raw_model_options))
    if strip_null_values:
        normalized_model_options = {
            key: value
            for key, value in normalized_model_options.items()
            if value is not None
        }

    unknown_keys = sorted(set(normalized_model_options) - ALLOWED_MODEL_OPTIONS_KEYS)
    if unknown_keys:
        raise ValueError(
            f"{field_name} contains unsupported keys: " + ", ".join(unknown_keys)
        )

    if "temperature" in normalized_model_options:
        if normalized_model_options["temperature"] is not None:
            _validate_temperature_model_option(
                normalized_model_options["temperature"],
                field_name=field_name,
            )
    if "max_tokens" in normalized_model_options:
        if normalized_model_options["max_tokens"] is not None:
            _validate_positive_integer_model_option(
                "max_tokens",
                normalized_model_options["max_tokens"],
                field_name=field_name,
            )
    if "max_completion_tokens" in normalized_model_options:
        if normalized_model_options["max_completion_tokens"] is not None:
            _validate_positive_integer_model_option(
                "max_completion_tokens",
                normalized_model_options["max_completion_tokens"],
                field_name=field_name,
            )

    return normalized_model_options


def normalize_extra_headers(
    extra_headers: Any,
    *,
    field_name: str = "extra_headers",
    lowercase_keys: bool = False,
    allow_null_values: bool = False,
    protected_headers: frozenset[str] | None = None,
) -> dict[str, Any]:
    if not isinstance(extra_headers, dict):
        raise ValueError(f"{field_name} must be an object")

    raw_headers = cast(dict[object, object], extra_headers)
    invalid_entries = [
        raw_key
        for raw_key, raw_value in raw_headers.items()
        if not isinstance(raw_key, str)
        or (raw_value is None and not allow_null_values)
        or (raw_value is not None and not isinstance(raw_value, str))
    ]
    if invalid_entries:
        raise ValueError(f"{field_name} values must be strings")

    normalized_headers: dict[str, Any] = {}
    protected_matches: set[str] = set()
    for raw_key, raw_value in raw_headers.items():
        if not isinstance(raw_key, str):
            continue
        key = raw_key.lower() if lowercase_keys else raw_key
        protected_lookup_key = raw_key.lower()
        if (
            protected_headers is not None and protected_lookup_key in protected_headers
        ) or is_sensitive_header_name(raw_key):
            protected_matches.add(protected_lookup_key)
        if _is_redacted_placeholder(raw_value):
            raise ValueError(
                f"{field_name} cannot use redacted placeholder values as raw header replacements"
            )
        normalized_headers[key] = raw_value

    if protected_matches:
        raise ValueError(
            f"{field_name} contains protected headers: {', '.join(sorted(protected_matches))}"
        )

    return normalized_headers
