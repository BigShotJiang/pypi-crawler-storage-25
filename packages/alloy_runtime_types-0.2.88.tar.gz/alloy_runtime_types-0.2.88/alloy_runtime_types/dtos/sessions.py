"""DTOs for chat session operations."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class CreateSessionRequest(BaseModel):
    """Request to create a new chat session."""

    name: str | None = Field(None, description="Optional user-friendly session name")
    agent: str | UUID | None = Field(
        default=None,
        description="Optional agent identifier - can be UUID or agent name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )


class UpdateSessionRequest(BaseModel):
    """Request to update an existing chat session."""

    name: str | None = Field(None, description="Optional user-friendly session name")


class SessionSummary(BaseModel):
    """Summary of a chat session for list responses."""

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(..., description="Unique identifier for the session.")
    organization_id: UUID | None = Field(
        default=None,
        description="Organization ID if session belongs to an organization.",
    )
    user_id: UUID = Field(..., description="ID of the user who owns the session.")
    name: str | None = Field(
        default=None, description="User-friendly name for the session, if set."
    )
    message_count: int = Field(
        ..., description="Total number of messages in the session."
    )
    created_at: datetime = Field(..., description="When the session was created.")
    last_activity_at: datetime = Field(
        ..., description="When the last message was sent or session was updated."
    )


class ListSessionsResponse(BaseModel):
    """Response for listing chat sessions."""

    sessions: list[SessionSummary] = Field(
        ..., description="List of session summaries."
    )
    total: int = Field(
        ..., description="Total number of sessions available (for pagination)."
    )


class MessageContentPartResponse(BaseModel):
    """A single content part within a message."""

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(..., description="Unique identifier for this content part.")
    part_index: int = Field(
        ..., description="Position of this part within the message (0-indexed)."
    )
    content_type_id: str = Field(
        ..., description="Type of content (e.g., 'text', 'image', 'file')."
    )
    content_text: str | None = Field(
        default=None, description="Plain text content, if applicable."
    )
    content_structured: dict[str, Any] | None = Field(
        default=None,
        description="Structured data content (JSON object), if applicable.",
    )
    content_object_id: UUID | None = Field(
        default=None, description="Reference to stored object/file, if applicable."
    )


class AgentExecutionMetadata(BaseModel):
    """Metadata about the agent execution for assistant messages."""

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(..., description="Unique identifier for the agent execution.")
    agent_id: UUID | None = Field(
        default=None,
        description="ID of the agent that generated this message, if applicable.",
    )
    model: str = Field(
        ..., description="Canonical model identity in <provider>/<model> format."
    )
    total_tokens: int | None = Field(
        default=None, description="Total tokens consumed (input + output), if tracked."
    )
    queued_at: datetime = Field(
        ..., description="When the execution was queued for processing."
    )


class MessageResponse(BaseModel):
    """A message within a session with its content parts."""

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(..., description="Unique identifier for the message.")
    sequence_number: int = Field(
        ..., description="Position in conversation (0, 1, 2, ...)."
    )
    role: str = Field(
        ...,
        description="Message sender role: 'user', 'assistant', 'system', or 'tool'.",
    )
    tool_call_id: str | None = Field(
        default=None,
        description="ID of tool call this message responds to, if applicable.",
    )
    tool_name: str | None = Field(
        default=None,
        description="Name of tool being called, if this is a tool message.",
    )
    content_parts: list[MessageContentPartResponse] = Field(
        ..., description="Ordered list of content parts making up this message."
    )
    agent_execution: AgentExecutionMetadata | None = Field(
        default=None,
        description="Execution metadata if this is an assistant message from an agent.",
    )
    created_at: datetime = Field(..., description="When the message was created.")


class SessionDetailResponse(BaseModel):
    """Detailed session information with messages."""

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(..., description="Unique identifier for the session.")
    organization_id: UUID | None = Field(
        default=None,
        description="Organization ID if session belongs to an organization.",
    )
    user_id: UUID = Field(..., description="ID of the user who owns the session.")
    name: str | None = Field(
        default=None, description="User-friendly name for the session, if set."
    )
    created_at: datetime = Field(..., description="When the session was created.")
    last_activity_at: datetime = Field(
        ..., description="When the last message was sent or session was updated."
    )
    messages: list[MessageResponse] = Field(
        ..., description="List of messages in the session (paginated, may be partial)."
    )
    total_messages: int = Field(
        ..., description="Total number of messages in the session."
    )
    has_more: bool = Field(
        ...,
        description="True if there are more messages beyond what's returned (use pagination).",
    )


class ListSessionMessagesResponse(BaseModel):
    """Response for listing messages within a session."""

    model_config = ConfigDict(extra="forbid")

    messages: list[MessageResponse] = Field(
        ..., description="List of messages in the session."
    )
    total: int = Field(..., description="Total number of messages in the session.")
    has_more: bool = Field(
        ..., description="True if there are more messages beyond what's returned."
    )


class DeletedSessionResponse(BaseModel):
    """Final state of a deleted session."""

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(..., description="Unique identifier for the deleted session.")
    organization_id: UUID | None = Field(
        default=None,
        description="Organization ID if session belonged to an organization.",
    )
    user_id: UUID = Field(..., description="ID of the user who owned the session.")
    name: str | None = Field(
        default=None, description="User-friendly name of the session, if set."
    )
    created_at: datetime = Field(
        ..., description="When the session was originally created."
    )
    last_activity_at: datetime = Field(
        ..., description="When the last activity occurred before deletion."
    )


class DeleteSessionResponse(BaseModel):
    """Response for deleting a chat session."""

    model_config = ConfigDict(extra="forbid")

    deleted_session: DeletedSessionResponse = Field(
        ..., description="Details of the deleted session for confirmation."
    )
