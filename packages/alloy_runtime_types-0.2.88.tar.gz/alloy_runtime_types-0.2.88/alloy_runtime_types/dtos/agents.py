"""DTOs for agent operations."""

from datetime import datetime
from typing import Any, Literal, cast
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator,
    model_validator,
)
from typing_extensions import Self

from alloy_runtime_types.dtos.generation import (
    build_canonical_model,
    parse_canonical_model,
)
from alloy_runtime_types.dtos.managed_tools import (
    ManagedToolReference,
    validate_unique_managed_tool_aliases,
)
from alloy_runtime_types.dtos.mcp_servers import (
    AgentMCPServerConfig,
    AgentMCPServerResponse,
)
from alloy_runtime_types.enums.ownership_scope import OwnershipScope
from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.model_option_allowlist import (
    PROTECTED_EXTRA_HEADERS,
    normalize_extra_headers,
    normalize_model_options,
)


def _validate_canonical_model_string(value: str) -> str:
    return AgentModelConfig.model_validate(value).model


def _reject_legacy_wrapped_json_schema(value: Any) -> Any:
    original_value: Any = value
    if not isinstance(value, dict):
        return original_value
    schema_value = cast(dict[object, Any], value)
    if schema_value.get("type") == "json_schema" and "schema_def" in schema_value:
        raise ValueError("output_schema must be a raw JSON Schema object, not wrapped")
    return original_value


def _empty_agent_mcp_server_responses() -> list[AgentMCPServerResponse]:
    return []


class AgentModelConfig(RootModel[str]):
    @field_validator("root")
    @classmethod
    def validate_root(cls, value: str) -> str:
        provider, provider_model_name = parse_canonical_model(value)
        return build_canonical_model(provider.value, provider_model_name)

    @property
    def model(self) -> str:
        return self.root

    @property
    def provider_key(self) -> Provider:
        provider, _ = parse_canonical_model(self.root)
        return provider

    @property
    def provider_model_name(self) -> str:
        _, provider_model_name = parse_canonical_model(self.root)
        return provider_model_name


AgentModelResponse = AgentModelConfig


class AgentToolConfig(ManagedToolReference):
    """Configuration for an agent tool.

    Configuration can come from either:
    - Inline config (config field): Direct configuration dict
    - Config reference (tool_config_id): Reference to a reusable ToolConfig
    - Config reference with overrides: tool_config_id plus config, where config
      shallowly overrides top-level keys from the referenced ToolConfig

    The tool_alias enables multiple instances of the same tool per agent.
    It defaults to tool_id when not provided and is used as the OpenAI function name.
    """

    org_credential_id: UUID | None = None
    is_enabled: bool = True
    tool_order: int = Field(default=0, ge=0)


class CreateAgentRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    model: str
    tags: list[str] = Field(
        default_factory=list,
        description="List of tag paths to associate with this agent. Required for user and organization scoped agents. Must be empty for global agents.",
    )
    scope: OwnershipScope = Field(
        default=OwnershipScope.ORGANIZATION,
        description="Ownership scope for the agent. Defaults to organization scope when omitted.",
    )
    base_agent_id: str | UUID | None = Field(
        default=None,
        description="Base agent identifier - can be UUID or agent name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    description: str | None = None
    system_instruction_template: str | UUID | None = Field(
        default=None,
        description="System instruction template identifier - can be UUID or template name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    system_instruction_version_id: UUID | None = None
    input_schema_id: str | UUID | None = Field(
        default=None,
        description="Input schema identifier - can be UUID or schema name. "
        "Names resolve to the latest visible schema.",
    )
    output_schema_id: str | UUID | None = Field(
        default=None,
        description="Output schema identifier - can be UUID or schema name. "
        "Names resolve to the latest visible schema.",
    )
    output_schema: dict[str, Any] | None = Field(
        default=None,
        description="Inline output schema. For structured JSON output, pass a raw JSON "
        "Schema object. For regex output, pass {'type': 'regex', 'schema_def': '<pattern>'}. "
        "Mutually exclusive with output_schema_id.",
    )
    default_model_options: dict[str, Any] | None = Field(
        default=None,
        description="Flat allowlisted model options applied as defaults for this agent",
    )
    default_extra_headers: dict[str, str] | None = Field(
        default=None,
        description="Additional string-valued HTTP headers applied as defaults for this agent",
    )
    tools: list[AgentToolConfig] | None = None
    mcp_servers: list[AgentMCPServerConfig] | None = None

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        return _validate_canonical_model_string(value)

    @field_validator("output_schema", mode="before")
    @classmethod
    def validate_output_schema_shape(cls, value: Any) -> Any:
        return _reject_legacy_wrapped_json_schema(value)

    @field_validator("default_model_options")
    @classmethod
    def validate_default_model_options(
        cls,
        value: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        if value is None:
            return value
        return normalize_model_options(value, field_name="default_model_options")

    @field_validator("default_extra_headers", mode="before")
    @classmethod
    def validate_default_extra_headers(cls, value: Any) -> Any:
        if value is None or not isinstance(value, dict):
            return value
        return normalize_extra_headers(
            value,
            lowercase_keys=True,
            field_name="default_extra_headers",
            protected_headers=PROTECTED_EXTRA_HEADERS,
        )

    @model_validator(mode="after")
    def validate_system_instruction_reference_exclusivity(self) -> Self:
        if (
            self.system_instruction_template is not None
            and self.system_instruction_version_id is not None
        ):
            raise ValueError(
                "Cannot specify both system_instruction_template and "
                "system_instruction_version_id. Provide one or neither."
            )
        return self

    @model_validator(mode="after")
    def validate_output_schema_exclusivity(self) -> Self:
        if self.output_schema_id is not None and self.output_schema is not None:
            raise ValueError(
                "Cannot specify both output_schema_id and output_schema. "
                "Provide one or neither."
            )
        return self

    @model_validator(mode="after")
    def validate_tool_alias_uniqueness(self) -> Self:
        validate_unique_managed_tool_aliases(self.tools, field_name="tools")
        return self

    @model_validator(mode="after")
    def validate_mcp_server_id_uniqueness(self) -> Self:
        if self.mcp_servers:
            ids = [server.mcp_server_id for server in self.mcp_servers]
            if len(ids) != len(set(ids)):
                raise ValueError(
                    "Duplicate mcp_server_id found in mcp_servers list. "
                    "Each MCP server can only be attached once."
                )
        return self


class AgentToolResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    agent_id: UUID
    tool_alias: str = Field(description="Unique alias for this tool within the agent")
    tool_id: str = Field(description="Tool implementation ID (references ai.tools.id)")
    org_credential_id: UUID | None
    is_enabled: bool
    tool_order: int
    submitted_config: dict[str, Any] | None = Field(
        default=None,
        description="Source config before server defaults. When tool_config_id and config overrides are both present, this contains the shallowly merged result.",
    )
    effective_config: dict[str, Any] | None = Field(
        default=None,
        description="Resolved config after applying tool_config references, alias/request-level overrides, and server defaults.",
    )
    defaults_applied: list[str] = Field(
        default_factory=list,
        description="Config keys added by server defaults when producing effective_config.",
    )
    config_source: Literal["inline", "tool_config"] = Field(
        description="Source used to build effective_config.",
    )
    update_mode: Literal["replace"] = Field(
        default="replace",
        description="Agent tool updates replace the full entry rather than merging config fields.",
    )
    tool_config_id: UUID | None = None
    tool_config_name: str | None = Field(
        default=None,
        description="Name of the referenced ToolConfig (convenience field for display)",
    )
    llm_instruction: str | None = Field(
        default=None,
        description="Optional instruction appended to tool description for LLM",
    )
    created_at: datetime


class AgentTagResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tag_id: UUID
    tag_path: str
    display_name: str


class CreateAgentResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    organization_id: UUID | None
    user_id: UUID | None
    base_agent_id: UUID | None
    description: str | None
    system_instruction_template_id: UUID | None = None
    system_instruction_version_id: UUID | None
    input_schema_id: UUID | None
    output_schema_id: UUID | None
    default_model_options: dict[str, Any] | None = None
    default_extra_headers: dict[str, str] | None = None
    created_at: datetime
    updated_at: datetime
    model: str
    tools: list[AgentToolResponse]
    mcp_servers: list[AgentMCPServerResponse] = Field(
        default_factory=_empty_agent_mcp_server_responses
    )
    tags: list[AgentTagResponse]

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        return _validate_canonical_model_string(value)


class UpdateAgentRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1)
    description: str | None = None
    model: str | None = None
    tags: list[str] | None = Field(
        default=None,
        description="List of tag paths to associate with this agent. If provided, replaces all existing tags.",
    )
    system_instruction_template: str | UUID | None = Field(
        default=None,
        description="System instruction template identifier - can be UUID or template name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    system_instruction_version_id: UUID | None = None
    input_schema_id: str | UUID | None = Field(
        default=None,
        description="Input schema identifier - can be UUID or schema name. "
        "Names resolve to the latest visible schema.",
    )
    output_schema_id: str | UUID | None = Field(
        default=None,
        description="Output schema identifier - can be UUID or schema name. "
        "Names resolve to the latest visible schema.",
    )
    output_schema: dict[str, Any] | None = Field(
        default=None,
        description="Inline output schema. For structured JSON output, pass a raw JSON "
        "Schema object. For regex output, pass {'type': 'regex', 'schema_def': '<pattern>'}. "
        "Mutually exclusive with output_schema_id.",
    )
    default_model_options: dict[str, Any] | None = Field(
        default=None,
        description="Flat allowlisted model options applied as defaults for this agent",
    )
    default_extra_headers: dict[str, str] | None = Field(
        default=None,
        description="Additional string-valued HTTP headers applied as defaults for this agent",
    )
    tools: list[AgentToolConfig] | None = Field(
        default=None,
        description="Full replacement for agent tools. When provided, replaces all existing tools and omitted nested config keys are removed.",
    )
    mcp_servers: list[AgentMCPServerConfig] | None = None

    @field_validator("model")
    @classmethod
    def validate_model(
        cls,
        value: str | None,
    ) -> str | None:
        if value is None:
            return value
        return _validate_canonical_model_string(value)

    @field_validator("output_schema", mode="before")
    @classmethod
    def validate_output_schema_shape(cls, value: Any) -> Any:
        return _reject_legacy_wrapped_json_schema(value)

    @field_validator("default_model_options")
    @classmethod
    def validate_default_model_options(
        cls,
        value: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        if value is None:
            return value
        return normalize_model_options(value, field_name="default_model_options")

    @field_validator("default_extra_headers", mode="before")
    @classmethod
    def validate_default_extra_headers(cls, value: Any) -> Any:
        if value is None or not isinstance(value, dict):
            return value
        return normalize_extra_headers(
            value,
            lowercase_keys=True,
            field_name="default_extra_headers",
            protected_headers=PROTECTED_EXTRA_HEADERS,
        )

    @model_validator(mode="after")
    def validate_required_fields_not_explicitly_null(self) -> Self:
        if "name" in self.model_fields_set and self.name is None:
            raise ValueError(
                "name cannot be null; omit it to leave the value unchanged"
            )
        return self

    @model_validator(mode="after")
    def validate_system_instruction_reference_exclusivity(self) -> Self:
        if (
            self.system_instruction_template is not None
            and self.system_instruction_version_id is not None
        ):
            raise ValueError(
                "Cannot specify both system_instruction_template and "
                "system_instruction_version_id. Provide one or neither."
            )
        return self

    @model_validator(mode="after")
    def validate_output_schema_exclusivity(self) -> Self:
        if self.output_schema_id is not None and self.output_schema is not None:
            raise ValueError(
                "Cannot specify both output_schema_id and output_schema. "
                "Provide one or neither."
            )
        return self

    @model_validator(mode="after")
    def validate_tool_alias_uniqueness(self) -> Self:
        validate_unique_managed_tool_aliases(self.tools, field_name="tools")
        return self

    @model_validator(mode="after")
    def validate_mcp_server_id_uniqueness(self) -> Self:
        if self.mcp_servers:
            ids = [server.mcp_server_id for server in self.mcp_servers]
            if len(ids) != len(set(ids)):
                raise ValueError(
                    "Duplicate mcp_server_id found in mcp_servers list. "
                    "Each MCP server can only be attached once."
                )
        return self


UpdateAgentResponse = CreateAgentResponse


class AgentSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    description: str | None
    organization_id: UUID | None
    user_id: UUID | None
    model: str
    system_instruction_template_id: UUID | None = None
    system_instruction_version_id: UUID | None
    input_schema_id: UUID | None
    output_schema_id: UUID | None
    created_at: datetime
    updated_at: datetime
    usage_count: int | None = Field(
        default=None,
        description="Number of named sessions using this agent. Only populated when sort_by=usage.",
    )

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        return _validate_canonical_model_string(value)


class ListAgentsResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    agents: list[AgentSummary]
    total: int


class GetAgentResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    organization_id: UUID | None
    user_id: UUID | None
    base_agent_id: UUID | None
    description: str | None
    system_instruction_template_id: UUID | None = None
    system_instruction_version_id: UUID | None
    input_schema_id: UUID | None
    output_schema_id: UUID | None
    default_model_options: dict[str, Any] | None = None
    default_extra_headers: dict[str, str] | None = None
    created_at: datetime
    updated_at: datetime
    model: str
    tools: list[AgentToolResponse]
    tags: list[AgentTagResponse]
    mcp_servers: list[AgentMCPServerResponse] = Field(
        default_factory=_empty_agent_mcp_server_responses
    )

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        return _validate_canonical_model_string(value)


class DeletedAgentResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    organization_id: UUID | None
    user_id: UUID | None
    base_agent_id: UUID | None
    description: str | None
    system_instruction_template_id: UUID | None = None
    system_instruction_version_id: UUID | None
    input_schema_id: UUID | None
    output_schema_id: UUID | None
    default_model_options: dict[str, Any] | None = None
    default_extra_headers: dict[str, str] | None = None
    created_at: datetime
    updated_at: datetime
    model: str
    tools: list[AgentToolResponse]
    mcp_servers: list[AgentMCPServerResponse] = Field(
        default_factory=_empty_agent_mcp_server_responses
    )
    tags: list[AgentTagResponse]

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        return _validate_canonical_model_string(value)


class DeleteAgentResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    deleted_agent: DeletedAgentResponse
