"""DTOs for AI model listing."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from typing_extensions import Self

from alloy_runtime_types.dtos.generation import (
    build_canonical_model,
    parse_canonical_model,
)
from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.model_option_allowlist import (
    PROTECTED_EXTRA_HEADERS,
    normalize_extra_headers,
    normalize_model_options,
)


class ModelProviderResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: str = Field(..., description="Provider identifier")
    display_name: str = Field(..., description="Provider friendly name")
    model: str = Field(..., description="Canonical model identity")
    is_active: bool = Field(
        ..., description="Whether this provider-model combination is active"
    )
    context_window: int | None = Field(
        default=None,
        description="Maximum context size in tokens for this provider",
    )
    max_output_tokens: int | None = Field(
        default=None,
        description="Maximum output tokens for this provider",
    )


class ModelListItemResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model: str = Field(
        ..., description="Canonical model identity in <provider>/<model> format"
    )
    description: str | None = Field(default=None, description="Model description")
    is_active: bool = Field(..., description="Whether this provider model is active")
    context_window: int | None = Field(
        default=None, description="Maximum context size in tokens"
    )
    max_output_tokens: int | None = Field(
        default=None, description="Maximum output tokens"
    )
    input_modalities: list[str] = Field(..., description="Supported input types")
    output_modalities: list[str] = Field(..., description="Supported output types")


class ListModelsResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    models: list[ModelListItemResponse] = Field(..., description="List of models")
    total_count: int = Field(..., description="Total matching models across all pages")
    has_more: bool = Field(
        default=False,
        description="Whether additional results exist beyond this page",
    )
    limit: int = Field(
        default=100,
        ge=1,
        description="Page size used to fetch this result set",
    )
    offset: int = Field(
        default=0,
        ge=0,
        description="Zero-based offset used to fetch this result set",
    )


class UpsertProviderDefaultRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: str | None = Field(
        default=None, description="Provider-wide default target"
    )
    model: str | None = Field(default=None, description="Exact canonical model target")
    model_options: dict[str, Any] = Field(
        default_factory=dict,
        description="Flat allowlisted model options passed to the selected model.",
    )
    extra_headers: dict[str, str] = Field(
        default_factory=dict,
        description="Additional string-valued HTTP headers for the upstream model request.",
    )

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, value: str | None) -> str | None:
        if value is None:
            return value
        return Provider.from_str(value).value

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str | None) -> str | None:
        if value is None:
            return value
        provider, provider_model_name = parse_canonical_model(value)
        return build_canonical_model(provider.value, provider_model_name)

    @field_validator("model_options")
    @classmethod
    def validate_model_options(cls, value: dict[str, Any]) -> dict[str, Any]:
        return normalize_model_options(value)

    @field_validator("extra_headers", mode="before")
    @classmethod
    def validate_extra_headers(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        return normalize_extra_headers(
            value,
            lowercase_keys=True,
            protected_headers=PROTECTED_EXTRA_HEADERS,
        )

    @model_validator(mode="after")
    def validate_target(self) -> Self:
        if (self.provider is None) == (self.model is None):
            raise ValueError("Exactly one of provider or model must be provided")
        return self

    @property
    def target_provider(self) -> str:
        if self.provider is not None:
            return self.provider
        provider, _ = parse_canonical_model(self.model or "")
        return provider.value

    @property
    def target_provider_model_name(self) -> str | None:
        if self.model is None:
            return None
        _, provider_model_name = parse_canonical_model(self.model)
        return provider_model_name


class ProviderDefaultResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: UUID
    organization_id: UUID
    provider: str
    model: str | None
    target_type: str
    model_options: dict[str, Any]
    extra_headers: dict[str, str]
    created_at: datetime
    updated_at: datetime


class ListProviderDefaultsResponse(BaseModel):
    defaults: list[ProviderDefaultResponse]


class DeleteProviderDefaultResponse(BaseModel):
    deleted_default: ProviderDefaultResponse
