"""Public retrieval diagnostics DTO consumed by SDK, CLI, and server code."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, computed_field, model_validator

DiagnosticSeverity = Literal["info", "warning", "error"]

DiagnosticCode = Literal[
    "decomposition_timeout",
    "decomposition_failed",
    "hyde_timeout",
    "hyde_fallback",
    "voyage_degraded",
    "semantic_no_results",
    "sparse_overfetch_exhausted",
    "question_low_headroom",
    "subquery_fanout_timeout",
    "subquery_fanout_failed",
    "tool_cancelled",
    "tool_errored",
    "no_collections_configured",
    "configured_collections_not_found",
    "collection_filter_not_found",
]

DiagnosticStatus = Literal["ok", "degraded", "failed"]


def _empty_warnings() -> list["RetrievalDiagnosticWarning"]:
    return []


class RetrievalDiagnosticWarning(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: DiagnosticCode
    severity: DiagnosticSeverity
    message: str
    fields: dict[str, object] = Field(default_factory=dict)


class RetrievalDiagnostics(BaseModel):
    model_config = ConfigDict(extra="forbid")

    warnings: list[RetrievalDiagnosticWarning] = Field(default_factory=_empty_warnings)

    @model_validator(mode="before")
    @classmethod
    def _discard_computed_round_trip_fields(
        cls, data: dict[str, object]
    ) -> dict[str, object]:
        cleaned = dict(data)
        cleaned.pop("status", None)
        cleaned.pop("degraded", None)
        return cleaned

    @computed_field
    @property
    def status(self) -> DiagnosticStatus:
        if any(w.severity == "error" for w in self.warnings):
            return "failed"
        if self.warnings:
            return "degraded"
        return "ok"

    @computed_field
    @property
    def degraded(self) -> bool:
        return self.status != "ok"
