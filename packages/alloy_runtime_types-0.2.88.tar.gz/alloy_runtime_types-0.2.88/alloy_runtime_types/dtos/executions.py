from datetime import datetime
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


ExecutionActivityState = Literal["unavailable", "partial", "complete"]
ExecutionActivityKind = Literal[
    "reasoning",
    "assistant_text",
    "tool_call",
    "tool_output",
    "tool_error",
]


class _ActivityBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    index: int
    timestamp: datetime | None = None
    round_index: int | None = None


class ReasoningActivity(_ActivityBase):
    kind: Literal["reasoning"] = "reasoning"
    text: str


class AssistantTextActivity(_ActivityBase):
    kind: Literal["assistant_text"] = "assistant_text"
    text: str


class ToolCallActivity(_ActivityBase):
    kind: Literal["tool_call"] = "tool_call"
    tool_name: str
    tool_call_id: str | None = None
    input: dict[str, Any]


class ToolOutputActivity(_ActivityBase):
    kind: Literal["tool_output"] = "tool_output"
    tool_name: str
    tool_call_id: str | None = None
    output: dict[str, Any] | list[Any] | str


class ToolErrorActivity(_ActivityBase):
    kind: Literal["tool_error"] = "tool_error"
    tool_name: str
    tool_call_id: str | None = None
    error: str


ExecutionActivityItem = Annotated[
    ReasoningActivity
    | AssistantTextActivity
    | ToolCallActivity
    | ToolOutputActivity
    | ToolErrorActivity,
    Field(discriminator="kind"),
]


class GetExecutionResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    execution_id: UUID
    origin_label: str
    status: str
    is_terminal: bool
    execution_purpose: str
    chat_session_id: UUID | None = None
    pipeline_execution_id: UUID | None = None
    model: str
    queued_at: datetime
    started_at: datetime | None = None
    last_activity_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = None
    output_text: str | None = None
    output_incomplete: bool = False
    error_message: str | None = None
    error_type: str | None = None
    activity_state: ExecutionActivityState
    round_count: int | None = None
    activity: list[ExecutionActivityItem]
