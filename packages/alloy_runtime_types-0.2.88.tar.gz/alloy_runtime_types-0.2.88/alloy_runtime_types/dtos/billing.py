"""DTOs for billing project endpoints."""

import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ============================================================================
# Project DTOs
# ============================================================================


class CreateProjectRequest(BaseModel):
    """Request to create a new billing project."""

    name: str = Field(
        min_length=1, max_length=255, description="Project name, unique per org"
    )
    description: str | None = Field(
        default=None, description="Optional project description"
    )
    external_reference: str | None = Field(
        default=None, description="External billing system identifier"
    )


class CreateProjectResponse(BaseModel):
    """Response after creating a billing project."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    description: str | None
    external_reference: str | None
    is_active: bool
    created_at: datetime.datetime


class ProjectResponse(BaseModel):
    """Full billing project details."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    organization_id: UUID
    name: str
    description: str | None
    external_reference: str | None
    is_active: bool
    created_at: datetime.datetime
    updated_at: datetime.datetime


class ProjectListItem(BaseModel):
    """Summary of a billing project for list views."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    description: str | None
    external_reference: str | None
    is_active: bool
    created_at: datetime.datetime


class ProjectListResponse(BaseModel):
    """List of billing projects."""

    model_config = ConfigDict(extra="forbid")

    projects: list[ProjectListItem]
    total: int


# ============================================================================
# Project Cost DTOs
# ============================================================================


class ProjectCostSummary(BaseModel):
    """Cost summary for a billing project over a time period.

    Includes execution statistics and cost breakdown by LLM and RAG.
    """

    model_config = ConfigDict(extra="forbid")

    project_id: UUID
    project_name: str
    period_start: datetime.datetime = Field(
        description="Start of the aggregation period"
    )
    period_end: datetime.datetime = Field(description="End of the aggregation period")
    execution_count: int = Field(description="Total agent executions in the period")
    completed_count: int = Field(description="Number of completed executions")
    failed_count: int = Field(description="Number of failed executions")
    llm_cost_usd: Decimal = Field(
        description="Total cost from LLM API calls (agent_executions.total_cost_usd)"
    )
    rag_cost_usd: Decimal = Field(
        description="Total cost from RAG operations (retrieval_logs.total_cost_usd)"
    )
    total_cost_usd: Decimal = Field(description="Sum of llm_cost_usd and rag_cost_usd")
    avg_cost_usd: Decimal = Field(description="Average cost per execution")
    min_cost_usd: Decimal | None = Field(
        default=None, description="Minimum execution cost (None if no executions)"
    )
    max_cost_usd: Decimal | None = Field(
        default=None, description="Maximum execution cost (None if no executions)"
    )


class ProjectDailyCostEntry(BaseModel):
    """Daily cost aggregation for a billing project."""

    model_config = ConfigDict(extra="forbid")

    date: datetime.date = Field(description="Date of the aggregation (UTC)")
    execution_count: int = Field(description="Number of executions on this date")
    llm_cost_usd: Decimal = Field(description="LLM costs on this date")
    rag_cost_usd: Decimal = Field(description="RAG costs on this date")
    total_cost_usd: Decimal = Field(description="Total cost on this date")
    avg_cost_usd: Decimal = Field(description="Average cost per execution on this date")


class ProjectCostByAgent(BaseModel):
    """Cost breakdown by agent for a billing project."""

    model_config = ConfigDict(extra="forbid")

    agent_id: UUID | None = Field(description="Agent ID (None for transient agents)")
    agent_name: str = Field(description="Agent name or '(transient)' for ad-hoc calls")
    execution_count: int = Field(description="Number of executions using this agent")
    total_tokens: int = Field(description="Total tokens consumed")
    llm_cost_usd: Decimal = Field(description="LLM costs for this agent")
    rag_cost_usd: Decimal = Field(description="RAG costs for this agent")
    total_cost_usd: Decimal = Field(description="Total cost for this agent")


class ProjectCostByModel(BaseModel):
    """Cost breakdown by provider and model for a billing project."""

    model_config = ConfigDict(extra="forbid")

    model: str = Field(
        description="Canonical model identity in <provider>/<model> format"
    )
    execution_count: int = Field(description="Number of executions using this model")
    total_tokens: int = Field(description="Total tokens consumed by this model")
    llm_cost_usd: Decimal = Field(description="LLM costs for this model")
    rag_cost_usd: Decimal = Field(description="RAG costs for this model")
    total_cost_usd: Decimal = Field(description="Total cost for this model")
