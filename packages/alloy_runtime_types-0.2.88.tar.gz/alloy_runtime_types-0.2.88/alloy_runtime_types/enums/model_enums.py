"""Enums for model domain."""

from enum import Enum


class ModelSortField(str, Enum):
    """Fields available for sorting models."""

    PROVIDER_KEY = "provider_key"
    PROVIDER_MODEL_NAME = "provider_model_name"
    CONTEXT_WINDOW = "context_window"
    MAX_OUTPUT_TOKENS = "max_output_tokens"
