# alloy-runtime-types

Shared DTOs, enums, and parsing helpers for Alloy Runtime Python clients.

## Install

```bash
pip install alloy-runtime-types
```

## What it includes

- Pydantic request and response models used by the SDK and CLI.
- Shared enums for ownership scope, providers, and tool metadata.
- Parsing helpers used by higher-level packages.

This package is published separately so `alloy-runtime-sdk` and `alloy-runtime-cli`
can be installed cleanly from PyPI without a workspace checkout.

## Hard-cut DTO migration

DTOs now reject Old / Removed generation and agent fields such as `model_source`, `controls`, `provider_options`, `default_controls`, `default_provider_options`, and `default_request_headers`. Use canonical `model`, flat `model_options`, `extra_headers`, `default_model_options`, and `default_extra_headers`. See `docs/generate/hardcut_migration.md`.
