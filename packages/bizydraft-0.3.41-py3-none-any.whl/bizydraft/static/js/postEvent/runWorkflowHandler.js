/**
 * runWorkflow 内部实现：验证、保存、创建任务
 * 发送 taskCreated 事件，不传输 workflow 数据
 */
import { app } from "../../../scripts/app.js";
import { saveWorkflowToServer } from "./saveWorkflow.js";
import { fetchFullConfig } from "../hookLoad/configLoader.js";
import { draftFetch } from "../utils/draftFetch.js";

const SUPPLEMENT = [
  "clip_name",
  "clip_name1",
  "clip_name2",
  "clip_name3",
  "clip_name4",
  "ckpt_name",
  "lora_name",
  "name",
  "lora",
  "lora_01",
  "lora_02",
  "lora_03",
  "lora_04",
  "lora_1_name",
  "lora_2_name",
  "lora_3_name",
  "lora_4_name",
  "lora_5_name",
  "lora_6_name",
  "lora_7_name",
  "lora_8_name",
  "lora_9_name",
  "lora_10_name",
  "lora_11_name",
  "lora_12_name",
  "model_name",
  "control_net_name",
  "ipadapter_file",
  "unet_name",
  "vae_name",
  "model",
  "instantid_file",
  "pulid_file",
  "style_model_name",
  "yolo_model",
  "face_model",
  "bbox_model_name",
  "sam_model_name",
  "model_path",
  "upscale_model",
  "supir_model",
  "sdxl_model",
  "upscale_model_1",
  "upscale_model_2",
  "upscale_model_3",
  "sam_model",
  "sam2_model",
  "grounding_dino_model",
];

async function getPossibleWidgetNames() {
  const config = await fetchFullConfig();
  if (!config?.weight_load_nodes) return SUPPLEMENT;
  const w = config.weight_load_nodes;
  const keys = Object.keys(w);
  const values = keys
    .map((e) => w[e].inputs)
    .filter(Boolean)
    .map((e) => Object.keys(e));
  const valuesFlat = values.flat();
  return [...new Set([...valuesFlat, ...SUPPLEMENT])];
}

function buildProcessTransform(jsonWorkflow, possibleWidgetNames) {
  const filterProcessTransform = Object.entries(jsonWorkflow).filter(
    ([key, item]) =>
      item.inputs &&
      item.inputs.model_version_id !== undefined &&
      key &&
      !item.class_type?.toLowerCase().includes("bizyair")
  );

  const processTransform = [];
  filterProcessTransform.forEach(([, item]) => {
    if (!item.inputs) return;

    if (item.class_type === "Power Lora Loader (rgthree)") {
      const loraKeys = Object.keys(item.inputs).filter((key) =>
        key.startsWith("lora_")
      );
      // 注意 comfyui会 将非原始类型转化为 proxy 对象，所以需要特殊处理
      // inputs.model_version_id is { __value__: [id1, id2, id3] }
      const raw = item.inputs.model_version_id;
      const versionIds =
        raw && typeof raw === "object" && Array.isArray(raw.__value__)
          ? raw.__value__
          : Array.isArray(raw)
            ? raw
            : [];

      loraKeys.forEach((loraKey) => {
        const match = loraKey.match(/\d+/);
        const index = match ? parseInt(match[0], 10) - 1 : 0;
        const val = versionIds[index] !== undefined ? versionIds[index] : 0;

        processTransform.push({
          node_id: item._meta?.id,
          field_name: loraKey,
          node_type: item._meta?.class_type,
          class_type: item.class_type,
          field_value: val,
        });
      });
      return;
    }

    const otherFieldKeys = Object.keys(item.inputs).filter((k) =>
      possibleWidgetNames.includes(k)
    );
    const otherFieldVals = Object.keys(item.inputs).filter(
      (k) => k.search("model_version_id") !== -1
    );
    otherFieldKeys.forEach((ele, index) => {
      const key = otherFieldVals[index];
      const fieldValue = item.inputs[key];
      if (fieldValue) {
        processTransform.push({
          node_id: item._meta?.id,
          field_name: ele,
          node_type: item._meta?.class_type,
          class_type: item.class_type,
          field_value: fieldValue,
        });
      }
    });
  });
  return processTransform;
}

function emitTaskCreated(payload) {
  if (typeof window !== "undefined" && window.parent) {
    window.parent.postMessage({ type: "taskCreated", ...payload }, "*");
  }
}

/**
 * 执行 runWorkflow
 * @param {Object} params - { workflowId, backendId, clientId }
 */
export async function runWorkflowHandler(params) {
  const { workflowId, backendId, clientId } = params || {};
  const ext = app.extensions?.find((e) => e.name === "comfy.BizyAir.Socket");
  const methods = ext?.methods || {};

  try {
    if (!workflowId) {
      emitTaskCreated({ success: false, error: "workflowId 缺失" });
      return;
    }

    const graph = await app.graphToPrompt();
    const clientIdVal = clientId || sessionStorage.getItem("clientId");

    const validRes = await fetch("bizyair/workflow_valid", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: graph.output,
        clientId: clientIdVal,
        extra_data: {
          extra_pnginfo: { workflow: graph.workflow },
        },
      }),
    });

    const resPromptJson = await validRes.json();

    if (resPromptJson.error) {
      if (methods?.openCustomError) {
        const err = resPromptJson.error;
        methods.openCustomError({
          nodeId: err.node_id,
          nodeType: err.node_type || err.type,
          errorMessage: err.details || err.message,
          borderColor: "#FF0000",
        });
        return;
      }
      emitTaskCreated({ success: false, error: "工作流验证失败" });
      return;
    }

    for (const i in resPromptJson.node_errors || {}) {
      const errs = resPromptJson.node_errors[i]?.errors;
      if (errs?.[0] && methods?.openCustomError) {
        methods.openCustomError({
          nodeId: i,
          nodeType: errs[0].type,
          errorMessage: errs[0].details,
          borderColor: "#FF0000",
        });
        return;
      }
    }

    if (Object.keys(resPromptJson.node_errors || {}).length > 0) {
      emitTaskCreated({ success: false, error: "工作流验证失败" });
      return;
    }
    // ref: https://github.com/Comfy-Org/ComfyUI_frontend/blob/12ee5de73bf52199aafabfc8d76978468518d425/src/scripts/widgets.ts#L276-L290
    for (const node of app.graph.nodes || []) {
      for (const widget of node.widgets ?? []) {
        if (widget.beforeQueued) widget.beforeQueued();
      }
    }
    for (const subgraph of app.graph.subgraphs?.values() || []) {
      for (const node of subgraph.nodes || []) {
        for (const widget of node.widgets ?? []) {
          if (widget.beforeQueued) widget.beforeQueued();
        }
      }
    }
    for (const node of app.graph.nodes || []) {
      for (const widget of node.widgets ?? []) {
        if (widget.afterQueued) widget.afterQueued();
      }
    }
    for (const subgraph of app.graph.subgraphs?.values() || []) {
      for (const node of subgraph.nodes || []) {
        for (const widget of node.widgets ?? []) {
          if (widget.afterQueued) widget.afterQueued();
        }
      }
    }

    const finalGraph = await app.graphToPrompt();
    const jsonWorkflow = finalGraph.output;

    for (const key in jsonWorkflow) {
      jsonWorkflow[key]._meta = jsonWorkflow[key]._meta || {};
      jsonWorkflow[key]._meta.id = Number(key);
      jsonWorkflow[key]._meta.class_type = jsonWorkflow[key].class_type;
    }
    for (const i in jsonWorkflow) {
      if (
        jsonWorkflow[i].class_type === "LoadImage" &&
        jsonWorkflow[i].inputs?.image
      ) {
        jsonWorkflow[i].inputs.image = jsonWorkflow[i].inputs.image.replace(
          "pasted/http",
          "http"
        );
      }
    }

    await saveWorkflowToServer({
      workflowId,
      type: 2,
    });

    const possibleWidgetNames = await getPossibleWidgetNames();
    const processTransform = buildProcessTransform(
      jsonWorkflow,
      possibleWidgetNames
    );

    const suppressPreviewOutput =
      localStorage.getItem("suppress_preview_output") === "true" ||
      !localStorage.getItem("suppress_preview_output");

    const checksum = sessionStorage.getItem("workflowHash") || "";

    const processedJsonWorkflow = { ...jsonWorkflow };
    Object.keys(processedJsonWorkflow).forEach((key) => {
      const node = processedJsonWorkflow[key];
      if (node.class_type === "LoadImage" && node.inputs?.image) {
        processedJsonWorkflow[key] = {
          ...node,
          inputs: {
            ...node.inputs,
            image: node.inputs.image.replace("clipspace/", ""),
          },
        };
      }
    });

    const taskRes = await draftFetch("/w/v1/comfy/task/create", {
      method: "POST",
      body: {
        client_id: clientIdVal,
        draft_id: Number(workflowId),
        prompt_content: processedJsonWorkflow,
        process_transform: processTransform,
        suppress_preview_output: suppressPreviewOutput,
        checksum,
        backend_id: backendId || 0,
      },
    });

    if (taskRes?.code === 401) {
      emitTaskCreated({ success: false, error: "请先登录" });
      return;
    }

    const taskId = taskRes?.data?.id ?? taskRes?.id;
    emitTaskCreated({ success: true, taskId });
  } catch (error) {
    console.error("[runWorkflowHandler]", error);
    emitTaskCreated({
      success: false,
      error: error?.message || "运行失败",
    });
  }
}
