import copy
import time
import warnings
from concurrent.futures import ProcessPoolExecutor, as_completed
from functools import wraps

import numpy as np
import polars as pl
from tqdm import tqdm

from ._format_time import _format_time


def _prepare_boot_data(self, data, boot_id):
    id_counts = self._boot_samples[boot_id]

    counts = pl.DataFrame(
        {self.id_col: list(id_counts.keys()), "count": list(id_counts.values())}
    )

    bootstrapped = (
        data.lazy()
        .join(counts.lazy(), on=self.id_col, how="inner")
        .with_columns(pl.int_ranges(0, pl.col("count")).alias("replicate"))
        .explode("replicate")
        .with_columns(
            (
                pl.col(self.id_col).cast(pl.Utf8)
                + "_"
                + pl.col("replicate").cast(pl.Utf8)
            ).alias(self.id_col)
        )
        .drop("count", "replicate")
        .collect()
    )

    return bootstrapped


def _bootstrap_worker(obj, method_name, original_DT, i, seed, args, kwargs):
    # Shallow copy the object and only deep copy mutable state that changes per-bootstrap
    obj = copy.copy(obj)
    # Deep copy only the mutable attributes that get modified during fitting
    obj.outcome_model = []
    obj.numerator_model = (
        copy.copy(obj.numerator_model)
        if hasattr(obj, "numerator_model") and obj.numerator_model
        else []
    )
    obj.denominator_model = (
        copy.copy(obj.denominator_model)
        if hasattr(obj, "denominator_model") and obj.denominator_model
        else []
    )

    obj._rng = (
        np.random.RandomState(seed + i) if seed is not None else np.random.RandomState()
    )
    original_DT = obj._offloader.load_dataframe(original_DT)
    obj.DT = _prepare_boot_data(obj, original_DT, i)
    del original_DT
    obj._current_boot_idx = i + 1

    # Disable bootstrapping to prevent recursion
    obj.bootstrap_nboot = 0

    method = getattr(obj, method_name)
    result = method(*args, **kwargs)
    obj._rng = None
    return result


def bootstrap_loop(method):
    @wraps(method)
    def wrapper(self, *args, **kwargs):
        if not hasattr(self, "outcome_model"):
            self.outcome_model = []
        start = time.perf_counter()

        results = []
        original_DT = self.DT

        seed = getattr(self, "seed", None)
        if seed is not None:
            self._rng = np.random.RandomState(seed)

        self._current_boot_idx = None
        full = method(self, *args, **kwargs)
        results.append(full)

        if getattr(self, "bootstrap_nboot") > 0 and getattr(
            self, "_boot_samples", None
        ):
            nboot = self.bootstrap_nboot
            ncores = self.ncores
            seed = getattr(self, "seed", None)
            method_name = method.__name__

            original_DT_ref = self._offloader.save_dataframe(original_DT, "_DT")

            if getattr(self, "parallel", False):
                original_rng = getattr(self, "_rng", None)
                self._rng = None
                self.DT = None

                with ProcessPoolExecutor(max_workers=ncores) as executor:
                    futures = {
                        executor.submit(
                            _bootstrap_worker,
                            self,
                            method_name,
                            original_DT_ref,
                            i,
                            seed,
                            args,
                            kwargs,
                        ): i
                        for i in range(nboot)
                    }
                    skipped = 0
                    for j in tqdm(
                        as_completed(futures), total=nboot, desc="Bootstrapping..."
                    ):
                        boot_idx = futures[j]
                        try:
                            results.append(j.result())
                        except np.linalg.LinAlgError as e:
                            skipped += 1
                            warnings.warn(
                                f"Bootstrap iteration {boot_idx + 1} failed "
                                f"({e}); skipping replicate.",
                                UserWarning,
                                stacklevel=2,
                            )

                self._rng = original_rng
                self.DT = self._offloader.load_dataframe(original_DT_ref)
            else:
                # Keep original data in memory if offloading is disabled to avoid unnecessary I/O
                if self._offloader.enabled:
                    original_DT_ref = self._offloader.save_dataframe(original_DT, "_DT")
                    del original_DT
                else:
                    original_DT_ref = original_DT

                skipped = 0
                for i in tqdm(range(nboot), desc="Bootstrapping..."):
                    self._current_boot_idx = i + 1
                    if seed is not None:
                        self._rng = np.random.RandomState(seed + i)
                    tmp = self._offloader.load_dataframe(original_DT_ref)
                    self.DT = _prepare_boot_data(self, tmp, i)
                    if self._offloader.enabled:
                        del tmp
                    self.bootstrap_nboot = 0
                    try:
                        boot_fit = method(self, *args, **kwargs)
                        results.append(boot_fit)
                    except np.linalg.LinAlgError as e:
                        skipped += 1
                        warnings.warn(
                            f"Bootstrap iteration {i + 1} failed "
                            f"({e}); skipping replicate.",
                            UserWarning,
                            stacklevel=2,
                        )

                self.DT = self._offloader.load_dataframe(original_DT_ref)

            self.bootstrap_nboot = len(results) - 1
            if skipped > 0:
                warnings.warn(
                    f"{skipped} of {nboot} bootstrap replicate(s) skipped due to "
                    "singular Hessian; effective bootstrap_nboot is "
                    f"{self.bootstrap_nboot}.",
                    UserWarning,
                    stacklevel=2,
                )

            end = time.perf_counter()
            self._model_time = _format_time(start, end)

        self.outcome_model = results
        return results

    return wrapper
