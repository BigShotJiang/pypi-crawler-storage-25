import numpy as np
import pandas as pd
import pytest
import xarray as xr
from earthkit.data.testing import earthkit_remote_test_data_file

# from earthkit.data.core.temporary import temp_directory
from earthkit import data as ek_data
from earthkit.transforms import temporal

# Use caching for speedy repeats
ek_data.settings.set("cache-policy", "user")

TO_XARRAY_KWARGS = {
    "valid_time": {"time_dim_mode": "valid_time"},
    "forecast": {
        "time_dim_mode": "forecast",
        "allow_holes": True,
        "ensure_dims": ["forecast_reference_time"],
    },
}
ACCUM_TIME_DIM = {"forecast": "step"}
RATE_SUFFIX = {
    "step_length": "per_step",
}
ERA5_LAND_TEST_POINT: dict[str, int] = {"latitude": 10, "longitude": 18}
SEAS5_TEST_POINT: dict[str, int] = {"latitude": 10, "longitude": 17}


def get_data(srcfile: str = "era5_temperature_europe_2015.grib"):
    remote_era5_file = earthkit_remote_test_data_file(srcfile)
    return ek_data.from_source("url", remote_era5_file)


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
def test_accumulation_to_rate_base(time_dim_mode):
    test_file = "era5-sfc-precip-3deg-202401.grib"
    dataset = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])
    dataarray = dataset["tp"]
    original_units = dataarray.attrs["units"]

    rate_dataset = temporal.accumulation_to_rate(dataset)
    assert isinstance(rate_dataset, xr.Dataset)
    assert "tp_rate" in rate_dataset
    assert original_units + " s^-1" == rate_dataset["tp_rate"].attrs["units"]
    assert "standard_name" not in rate_dataset["tp_rate"].attrs

    rate_data = temporal.accumulation_to_rate(dataarray)
    assert isinstance(rate_data, xr.DataArray)
    assert "tp_rate" == rate_data.name
    assert original_units + " s^-1" == rate_data.attrs["units"]
    assert "standard_name" not in rate_data.attrs

    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    numeric_test_sample = rate_data.isel(latitude=5, longitude=5, **{accum_time_dim: slice(0, 5)})
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (dataarray.isel(latitude=5, longitude=5, **{accum_time_dim: slice(0, 5)}).values) / (
        3600.0
    )  # seconds in an hour
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
@pytest.mark.parametrize(
    "step,result_scale_factor",
    (
        ("1 hour", 1),
        ("1h", 1),
        (pd.to_timedelta("1 hour"), 1),
        ("30 minutes", 0.5),
        ("2 hours", 2),
    ),
)
def test_accumulation_to_rate_base_step(time_dim_mode, step, result_scale_factor):
    test_file = "era5-sfc-precip-3deg-202401.grib"
    dataset = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])
    dataarray = dataset["tp"]
    original_units = dataarray.attrs["units"]

    rate_dataset = temporal.accumulation_to_rate(dataset, step=step)
    assert isinstance(rate_dataset, xr.Dataset)
    assert "tp_rate" in rate_dataset
    assert original_units + " s^-1" == rate_dataset["tp_rate"].attrs["units"]
    assert "standard_name" not in rate_dataset["tp_rate"].attrs

    rate_data = temporal.accumulation_to_rate(dataarray, step=step)
    assert isinstance(rate_data, xr.DataArray)
    assert "tp_rate" == rate_data.name
    assert original_units + " s^-1" == rate_data.attrs["units"]
    assert "standard_name" not in rate_data.attrs

    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    numeric_test_sample = rate_data.isel(latitude=5, longitude=5, **{accum_time_dim: slice(0, 5)})
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (dataarray.isel(latitude=5, longitude=5, **{accum_time_dim: slice(0, 5)}).values) / (
        3600.0 * result_scale_factor
    )  # seconds in an hour
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
@pytest.mark.parametrize(
    "rate_units, expected_units, sample_sf",
    [
        ("seconds", " s^-1", 3600.0),
        ("minutes", " min^-1", 60.0),
        ("hours", " hours^-1", 1.0),
        ("3 hours", " (3 hours)^-1", 1.0 / 3.0),
        ("step_length", "", 1.0),
        (pd.to_timedelta("1 second"), " s^-1", 3600.0),
    ],
)
def test_accumulation_to_rate_start_of_step_rate_units(rate_units, expected_units, sample_sf, time_dim_mode):
    test_file = "era5-sfc-precip-3deg-202401.grib"
    data = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])["tp"]
    original_units = data.attrs["units"]

    rate_data = temporal.accumulation_to_rate(data, rate_units=rate_units)
    assert f"tp_{RATE_SUFFIX.get(rate_units, 'rate')}" == rate_data.name
    assert original_units + expected_units == rate_data.attrs["units"]
    assert rate_data.attrs["long_name"].endswith(f" {RATE_SUFFIX.get(rate_units, 'rate').replace('_', ' ')}")
    assert "standard_name" not in rate_data.attrs

    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    numeric_test_sample = rate_data.isel(latitude=5, longitude=5, **{accum_time_dim: slice(0, 5)})
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (data.isel(latitude=5, longitude=5, **{accum_time_dim: slice(0, 5)}).values) / (sample_sf)
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Array contains only NaN values"


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
def test_accumulation_to_rate_start_of_forecast(time_dim_mode):
    test_file = "seas5-precip-3deg-202401.grib"
    accumulation_type = "start_of_forecast"
    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    data = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])["tp"]
    original_units = data.attrs["units"]

    rate_data = temporal.accumulation_to_rate(data, accumulation_type=accumulation_type)
    assert "tp_rate" == rate_data.name
    assert original_units + " s^-1" == rate_data.attrs["units"]
    assert "standard_name" not in rate_data.attrs
    assert rate_data[accum_time_dim][0].values == data[accum_time_dim][1].values
    isel_kwargs = {k: 0 for k in data.dims if k not in (accum_time_dim, "latitude", "longitude")}
    numeric_test_sample = rate_data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(1, 5)}, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(2, 6)}, **isel_kwargs).values
        - data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(1, 5)}, **isel_kwargs).values
    ) / (3600.0 * 24)  # 24 hours in seconds
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)

    # Check the from_first_step=True option, should preserve first timestep
    rate_data = temporal.accumulation_to_rate(data, accumulation_type="start_of_forecast", from_first_step=True)
    assert "tp_rate" == rate_data.name
    assert original_units + " s^-1" == rate_data.attrs["units"]
    assert "standard_name" not in rate_data.attrs
    assert rate_data[accum_time_dim][0].values == data[accum_time_dim][0].values
    assert not np.all(np.isnan(numeric_test_sample.values)), "Array contains only NaN values"

    numeric_test_sample = rate_data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(1, 5)}, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(1, 5)}, **isel_kwargs).values
        - data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(0, 4)}, **isel_kwargs).values
    ) / (3600.0 * 24)  # 24 hours in seconds
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
@pytest.mark.parametrize(
    "rate_units, expected_units, sample_sf",
    [
        ("minutes", " min^-1", 60.0 * 24),
        ("hours", " hours^-1", 24.0),
        ("3 hours", " (3 hours)^-1", 8.0),
        ("step_length", "", 1.0),
    ],
)
def test_accumulation_to_rate_start_of_forecast_rate_units(rate_units, expected_units, sample_sf, time_dim_mode):
    test_file = "seas5-precip-3deg-202401.grib"
    accumulation_type = "start_of_forecast"
    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    data = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])["tp"]
    original_units = data.attrs["units"]

    rate_data = temporal.accumulation_to_rate(data, accumulation_type=accumulation_type, rate_units=rate_units)
    assert f"tp_{RATE_SUFFIX.get(rate_units, 'rate')}" == rate_data.name
    assert original_units + expected_units == rate_data.attrs["units"]
    assert rate_data.attrs["long_name"].endswith(f" {RATE_SUFFIX.get(rate_units, 'rate').replace('_', ' ')}")
    assert "standard_name" not in rate_data.attrs

    isel_kwargs = {k: 0 for k in data.dims if k not in (accum_time_dim, "latitude", "longitude")}
    numeric_test_sample = rate_data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(1, 5)}, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(2, 6)}, **isel_kwargs).values
        - data.isel(**SEAS5_TEST_POINT, **{accum_time_dim: slice(1, 5)}, **isel_kwargs).values
    ) / sample_sf
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
def test_accumulation_to_rate_start_of_day(time_dim_mode):
    test_file = "era5-land-precip-3deg-202401.grib"
    accumulation_type = "start_of_day"
    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    data = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])["tp"]

    original_units = data.attrs["units"]
    rate_data = temporal.accumulation_to_rate(data, accumulation_type=accumulation_type)
    assert "tp_rate" == rate_data.name
    assert original_units + " s^-1" == rate_data.attrs["units"]
    assert "standard_name" not in rate_data.attrs
    assert rate_data[accum_time_dim][0].values == data[accum_time_dim][1].values

    isel_kwargs = {k: 1 for k in data.dims if k not in (accum_time_dim, "latitude", "longitude")}
    numeric_test_sample = rate_data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(2, 22)}, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(3, 23)}, **isel_kwargs).values
        - data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(2, 22)}, **isel_kwargs).values
    ) / 3600.0  # hours to seconds
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)

    rate_data = temporal.accumulation_to_rate(data, accumulation_type=accumulation_type, from_first_step=True)
    assert "tp_rate" == rate_data.name
    assert original_units + " s^-1" == rate_data.attrs["units"]
    assert "standard_name" not in rate_data.attrs

    # First step is midnight, so first step should be dropped

    assert rate_data[accum_time_dim][0].values == data[accum_time_dim][0].values

    if time_dim_mode == "valid_time":
        # Check a value for the first timestep of a day, in this example at 01:00
        assert data.valid_time[25].values.astype("datetime64[h]").item().hour == 1
        # the rate can be computed
        numeric_test_sample = rate_data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: 25}, **isel_kwargs)
        assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
        assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
        expected_sample = (data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: 25}, **isel_kwargs).values) / 3600.0
        np.testing.assert_allclose(numeric_test_sample.values, expected_sample)

        # Check a period that is not the first day
        numeric_test_sample = rate_data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(26, 31)}, **isel_kwargs)
        assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
        assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
        expected_sample = (
            data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(26, 31)}, **isel_kwargs).values
            - data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(25, 30)}, **isel_kwargs).values
        ) / 3600.0  # hours in seconds
        np.testing.assert_allclose(numeric_test_sample.values, expected_sample)


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
@pytest.mark.parametrize(
    "rate_units, expected_units, sample_sf",
    [
        ("seconds", " s^-1", 3600.0),
        ("minutes", " min^-1", 60.0),
        ("hours", " hours^-1", 1.0),
        ("3 hours", " (3 hours)^-1", 1.0 / 3.0),
        ("step_length", "", 1.0),
    ],
)
def test_accumulation_to_rate_start_of_day_rate_units(time_dim_mode, rate_units, expected_units, sample_sf):
    test_file = "era5-land-precip-3deg-202401.grib"
    accumulation_type = "start_of_day"
    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    data = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])["tp"]

    original_units = data.attrs["units"]
    rate_data = temporal.accumulation_to_rate(data, accumulation_type=accumulation_type, rate_units=rate_units)
    assert f"tp_{RATE_SUFFIX.get(rate_units, 'rate')}" == rate_data.name
    assert original_units + expected_units == rate_data.attrs["units"]
    assert rate_data.attrs["long_name"].endswith(f" {RATE_SUFFIX.get(rate_units, 'rate').replace('_', ' ')}")
    assert "standard_name" not in rate_data.attrs
    assert rate_data[accum_time_dim][0].values == data[accum_time_dim][1].values
    isel_kwargs = {k: 1 for k in data.dims if k not in (accum_time_dim, "latitude", "longitude")}
    numeric_test_sample = rate_data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(6, 11)}, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(7, 12)}, **isel_kwargs).values
        - data.isel(**ERA5_LAND_TEST_POINT, **{accum_time_dim: slice(6, 11)}, **isel_kwargs).values
    ) / sample_sf
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)

    rate_data = temporal.accumulation_to_rate(
        data, accumulation_type=accumulation_type, rate_units=rate_units, from_first_step=True
    )
    assert f"tp_{RATE_SUFFIX.get(rate_units, 'rate')}" == rate_data.name
    assert original_units + expected_units == rate_data.attrs["units"]
    assert rate_data.attrs["long_name"].endswith(f" {RATE_SUFFIX.get(rate_units, 'rate').replace('_', ' ')}")
    assert "standard_name" not in rate_data.attrs
    assert rate_data[accum_time_dim][0].values == data[accum_time_dim][0].values


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
def test_accumulation_to_rate_label(time_dim_mode):
    test_file = "era5-sfc-precip-3deg-202401.grib"
    rate_label = "custom"
    dataset = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])
    dataarray = dataset["tp"]

    rate_dataset = temporal.accumulation_to_rate(dataset, rate_label=rate_label)
    assert f"tp_{rate_label}" in rate_dataset

    rate_data = temporal.accumulation_to_rate(dataarray, rate_label=rate_label)
    assert f"tp_{rate_label}" == rate_data.name


@pytest.mark.parametrize(
    "time_dim_mode",
    ("forecast", "valid_time"),
)
def test_deaccumulate(time_dim_mode):
    test_file = "seas5-precip-3deg-202401.grib"
    data = get_data(test_file).to_xarray(**TO_XARRAY_KWARGS[time_dim_mode])["tp"]
    accum_time_dim = ACCUM_TIME_DIM.get(time_dim_mode, time_dim_mode)
    original_units = data.attrs["units"]

    deaccum_data = temporal.deaccumulate(data, from_first_step=True)
    assert "tp" == deaccum_data.name
    assert original_units == deaccum_data.attrs["units"]
    assert deaccum_data.attrs["long_name"] == data.attrs["long_name"]
    assert "standard_name" not in deaccum_data.attrs

    # Check first timestep is unchanged
    np.testing.assert_allclose(deaccum_data.isel(**{accum_time_dim: 0}).values, data.isel(**{accum_time_dim: 0}).values)

    isel_kwargs = {k: 0 for k in data.dims if k not in (accum_time_dim, "latitude", "longitude")}

    numeric_test_sample = deaccum_data.isel(**{accum_time_dim: slice(1, 5)}, **SEAS5_TEST_POINT, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**{accum_time_dim: slice(1, 5)}, **SEAS5_TEST_POINT, **isel_kwargs).values
        - data.isel(**{accum_time_dim: slice(0, 4)}, **SEAS5_TEST_POINT, **isel_kwargs).values
    )
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)

    deaccum_data = temporal.deaccumulate(data)
    assert "tp" == deaccum_data.name
    assert original_units == deaccum_data.attrs["units"]
    assert deaccum_data.attrs["long_name"] == data.attrs["long_name"]
    assert "standard_name" not in deaccum_data.attrs

    isel_kwargs = {k: 0 for k in data.dims if k not in (accum_time_dim, "latitude", "longitude")}

    numeric_test_sample = deaccum_data.isel(**{accum_time_dim: slice(1, 5)}, **SEAS5_TEST_POINT, **isel_kwargs)
    assert not np.all(np.isnan(numeric_test_sample.values)), "Sample array contains only NaN values"
    assert not np.all(numeric_test_sample.values == 0), "Sample array contains only zero values"
    expected_sample = (
        data.isel(**{accum_time_dim: slice(2, 6)}, **SEAS5_TEST_POINT, **isel_kwargs).values
        - data.isel(**{accum_time_dim: slice(1, 5)}, **SEAS5_TEST_POINT, **isel_kwargs).values
    )
    np.testing.assert_allclose(numeric_test_sample.values, expected_sample)


def test_accumulation_to_rate_single_timestep():
    data = xr.DataArray(
        [[6.0]],
        dims=["forecast_reference_time", "forecast_period"],
        coords={
            "forecast_reference_time": [np.datetime64("2024-01-01")],
            "forecast_period": [np.timedelta64(1, "h")],
        },
        name="tp",
        attrs={"units": "m"},
    )

    result = temporal.accumulation_to_rate(
        data,
        time_dim="forecast_reference_time",
        accumulation_type="start_of_step",
    )
    assert result.name == "tp_rate"
    assert result.attrs["units"] == "m s^-1"
    assert result.item() == 6.0 / 3600


def test_accumulation_to_rate_start_of_day_from_first_step_first_step_midnight():
    data = xr.DataArray(
        [24.0, 1.0, 2.0],
        dims=["valid_time"],
        coords={
            "valid_time": [
                np.datetime64("2024-01-01T00:00"),
                np.datetime64("2024-01-01T01:00"),
                np.datetime64("2024-01-01T02:00"),
            ]
        },
        name="tp",
        attrs={"units": "m"},
    )

    out = temporal.accumulation_to_rate(
        data,
        time_dim="valid_time",
        accumulation_type="start_of_day",
        from_first_step=True,
    )
    assert np.isnan(out[0].item())
