"""Tools"""

from json import JSONDecodeError, dumps, loads
from os import system
from pathlib import Path
from typing import Any


def write_file_system(path: str, content: str, mode: str = "w") -> None:
    """Write file system"""
    if mode == "a":
        system(f"echo '{content}' >> {path}")

    if mode == "w":
        system(f"echo '{content}' > {path}")


def write_file(
    path: str, content: Any, mode: str = "w", encoding: str = "utf-8"
) -> None:
    """Write file"""
    try:
        with open(file=path, mode=mode, encoding=encoding) as file:
            file.write(dumps(content))
    except TypeError:
        with open(file=path, mode=mode, encoding=encoding) as file:
            file.write(str(content))


def read_file(path: Path, encoding: str = "utf-8") -> Any:
    """Read file"""
    if path.exists():
        with open(file=path, encoding=encoding) as file:
            content = file.read()
        try:
            return loads(content)
        except JSONDecodeError:
            return content
    return None
