"""Action module"""

import asyncio
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from time import sleep
from types import FunctionType

from dotflow.core.context import Context
from dotflow.core.exception import ExecutionWithClassError, TaskError
from dotflow.core.types.status import TypeStatus


def is_execution_with_class_internal_error(error: Exception) -> bool:
    message = str(error)
    patterns = [
        "initial_context",
        "previous_context",
        "missing 1 required positional argument: 'self'",
    ]
    return any(pattern in message for pattern in patterns)


class Action:
    """
    Import:
        You can import the **action** decorator directly from dotflow:

            from dotflow import action

    Example:
        `class` dotflow.core.action.Action

        Standard

            @action
            def my_task():
                print("task")

        With Retry

            @action(retry=5)
            def my_task():
                print("task")


        With Timeout

            @action(timeout=60)
            def my_task():
                print("task")

        With Retry delay

            @action(retry=5, retry_delay=5)
            def my_task():
                print("task")

        With Backoff

            @action(retry=5, backoff=True)
            def my_task():
                print("task")

    Args:
        func (Callable):

        task (Callable):

        retry (int): Number of task retries on on_failure.

        timeout (int): Execution timeout for a task. Duration (in seconds)

        retry_delay (int): Retry delay on task on_failure. Duration (in seconds)

        backoff (bool): Exponential backoff. Doubles retry_delay after each attempt.

    """

    def __init__(
        self,
        func: Callable = None,
        task: Callable = None,
        retry: int = 1,
        timeout: int = 0,
        retry_delay: int = 1,
        backoff: bool = False,
    ) -> None:
        self.func = func
        self.task = task
        self.retry = retry
        self.timeout = timeout
        self.retry_delay = retry_delay
        self.backoff = backoff
        self.params = []

    def __call__(self, *args, **kwargs):
        if self.func:
            self._set_params()

            task = self._get_task(kwargs=kwargs)
            contexts = self._get_context(kwargs=kwargs)

            if contexts:
                return Context(
                    storage=self._run_action(*args, task=task, **contexts),
                    task_id=task.task_id,
                    workflow_id=task.workflow_id,
                )

            return Context(
                storage=self._run_action(*args, task=task),
                task_id=task.task_id,
                workflow_id=task.workflow_id,
            )

        def action(*_args, **_kwargs):
            self.func = args[0]
            self._set_params()

            task = self._get_task(kwargs=_kwargs)
            contexts = self._get_context(kwargs=_kwargs)

            if contexts:
                return Context(
                    storage=self._run_action(*_args, task=task, **contexts),
                    task_id=task.task_id,
                    workflow_id=task.workflow_id,
                )

            return Context(
                storage=self._run_action(*_args, task=task),
                task_id=task.task_id,
                workflow_id=task.workflow_id,
            )

        return action

    def _run_action(self, *args, task=None, **kwargs):
        current_delay = self.retry_delay

        is_async = asyncio.iscoroutinefunction(self.func)

        for attempt in range(1, self.retry + 1):
            try:
                if self.timeout:
                    executor = ThreadPoolExecutor(max_workers=1)
                    try:
                        future = executor.submit(
                            self._call_func,
                            is_async,
                            *args,
                            **kwargs,
                        )
                        result = future.result(timeout=self.timeout)
                    except TimeoutError:
                        future.cancel()
                        executor.shutdown(wait=False, cancel_futures=True)
                        raise
                    except Exception:
                        executor.shutdown(wait=False)
                        raise
                    else:
                        executor.shutdown(wait=False)
                else:
                    result = self._call_func(is_async, *args, **kwargs)

                return result

            except TimeoutError:
                raise

            except Exception as error:
                last_exception = error

                if is_execution_with_class_internal_error(
                    error=last_exception
                ):
                    raise ExecutionWithClassError() from None

                if attempt == self.retry:
                    raise last_exception from None

                if task is not None:
                    task.retry_count += 1
                    task.errors = TaskError(
                        error=error,
                        attempt=attempt,
                    )
                    task.status = TypeStatus.RETRY

                sleep(current_delay)
                if self.backoff:
                    current_delay *= 2

    def _call_func(self, is_async, *args, **kwargs):
        if is_async:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop and loop.is_running():
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as pool:
                    return pool.submit(
                        asyncio.run, self.func(*args, **kwargs)
                    ).result()
            return asyncio.run(self.func(*args, **kwargs))
        return self.func(*args, **kwargs)

    def _set_params(self):
        if isinstance(self.func, FunctionType):
            code = self.func.__code__
            self.params = list(
                code.co_varnames[: code.co_argcount + code.co_kwonlyargcount]
            )

        if (
            type(self.func) is type
            and hasattr(self.func, "__init__")
            and hasattr(self.func.__init__, "__code__")
        ):
            code = self.func.__init__.__code__
            self.params = list(
                code.co_varnames[: code.co_argcount + code.co_kwonlyargcount]
            )

    def _get_context(self, kwargs: dict):
        context = {}
        if "initial_context" in self.params:
            context["initial_context"] = Context(kwargs.get("initial_context"))

        if "previous_context" in self.params:
            context["previous_context"] = Context(
                kwargs.get("previous_context")
            )

        return context

    def _get_task(self, kwargs: dict):
        return kwargs.get("task")
