"""Workflow module"""

import sys
import threading
from collections.abc import Callable
from datetime import datetime
from multiprocessing import get_context
from queue import Empty
from uuid import UUID, uuid4

from dotflow.abc.flow import Flow
from dotflow.core.context import Context
from dotflow.core.exception import ExecutionModeNotExist
from dotflow.core.execution import Execution
from dotflow.core.task import Task, TaskError
from dotflow.core.types import TypeExecution, TypeStatus
from dotflow.utils import basic_callback

if sys.platform == "win32":
    _mp = get_context("spawn")
else:
    import multiprocessing

    if sys.platform == "darwin" and hasattr(
        multiprocessing, "set_forkserver_preload"
    ):
        import os

        os.environ.setdefault("OBJC_DISABLE_INITIALIZE_FORK_SAFETY", "YES")
    _mp = get_context("fork")


def grouper(tasks: list[Task]) -> dict[str, list[Task]]:
    """Grouper"""
    groups = {}
    for task in tasks:
        if not groups.get(task.group_name):
            groups[task.group_name] = []
        groups[task.group_name].append(task)

    return groups


class Manager:
    """
    Import:
        You can import the **Manager** class with:

            from dotflow.core.workflow import Manager

    Example:
        `class` dotflow.core.workflow.Manager

            workflow = Manager(
                tasks=[tasks],
                on_success=basic_callback,
                on_failure=basic_callback,
                keep_going=True
            )

    Args:
        tasks (List[Task]):
            A list containing objects of type Task.

        on_success (Callable):
            Success function to be executed after the completion of the entire
            workflow. It's essentially a callback for successful scenarios.

        on_failure (Callable):
            Failure function to be executed after the completion of the entire
            workflow. It's essentially a callback for error scenarios

        mode (TypeExecution):
            Parameter that defines the execution mode of the workflow. Currently,
            there are options to execute in **sequential**, **background**, or **parallel** mode.
            The sequential mode is used by default.


        keep_going (bool):
            A parameter that receives a boolean object with the purpose of continuing
            or not the execution of the workflow in case of an error during the
            execution of a task. If it is **true**, the execution will continue;
            if it is **False**, the workflow will stop.

        workflow_id (UUID): Workflow ID.

        resume (bool):
            If True, checks for existing checkpoints before executing each task.
            Tasks with a checkpoint are skipped and their saved context is used.
            Requires a persistent storage provider and a fixed workflow_id.

    Attributes:
        on_success (Callable):

        on_failure (Callable):

        workflow_id (UUID):

        started (datetime):
    """

    def __init__(
        self,
        tasks: list[Task],
        on_success: Callable = basic_callback,
        on_failure: Callable = basic_callback,
        mode: TypeExecution = TypeExecution.SEQUENTIAL,
        keep_going: bool = False,
        workflow_id: UUID = None,
        resume: bool = False,
    ) -> None:
        self.tasks = tasks
        self.on_success = on_success
        self.on_failure = on_failure
        self.workflow_id = workflow_id or uuid4()
        self.started = datetime.now()

        execution = None
        groups = grouper(tasks=tasks)

        VALID_MODES = {
            "sequential",
            "sequential_group",
            "background",
            "parallel",
        }
        if mode not in VALID_MODES:
            raise ExecutionModeNotExist()

        execution = getattr(self, mode)

        self.tasks = execution(
            tasks=tasks,
            workflow_id=self.workflow_id,
            ignore=keep_going,
            groups=groups,
            resume=resume,
        )

        if mode != TypeExecution.BACKGROUND:
            self._callback_workflow(tasks=self.tasks)

    def _callback_workflow(self, tasks: list[Task]):
        final_status = [task.status for task in tasks]

        if TypeStatus.FAILED in final_status:
            self.on_failure(tasks=tasks)
        else:
            self.on_success(tasks=tasks)

    def sequential(self, **kwargs) -> list[Task]:
        if len(kwargs.get("groups", {})) > 1:
            process = SequentialGroup(**kwargs)
            return process.get_tasks()

        process = Sequential(**kwargs)
        return process.get_tasks()

    def sequential_group(self, **kwargs):
        process = SequentialGroup(**kwargs)
        return process.get_tasks()

    def background(self, **kwargs) -> list[Task]:
        process = Background(**kwargs)
        self.thread = process.thread
        return process.get_tasks()

    def parallel(self, **kwargs) -> list[Task]:
        process = Parallel(**kwargs)
        return process.get_tasks()


class Sequential(Flow):
    """Sequential"""

    def setup_queue(self) -> None:
        self.queue = []

    def get_tasks(self) -> list[Task]:
        return self.queue

    def _flow_callback(self, task: Task) -> None:
        self.queue.append(task)

    def _has_checkpoint(self, task: Task) -> bool:
        if not self.resume:
            return False

        context = task.config.storage.get(
            key=task.config.storage.key(task=task)
        )

        return context.storage is not None

    def run(self) -> None:
        previous_context = Context(workflow_id=self.workflow_id)

        for task in self.tasks:
            if self._has_checkpoint(task):
                previous_context = task.config.storage.get(
                    key=task.config.storage.key(task=task)
                )

                task.status = TypeStatus.COMPLETED
                task.current_context = previous_context
                self._flow_callback(task=task)
                continue

            Execution(
                task=task,
                workflow_id=self.workflow_id,
                previous_context=previous_context,
                _flow_callback=self._flow_callback,
            )

            previous_context = task.config.storage.get(
                key=task.config.storage.key(task=task)
            )

            if not self.ignore and task.status == TypeStatus.FAILED:
                break


class SequentialGroup(Flow):
    """SequentialGroup"""

    def setup_queue(self) -> None:
        self.queue = _mp.Queue()
        self._processes = []

    def get_tasks(self) -> list[Task]:
        contexts = {}
        while len(contexts) < len(self.tasks):
            try:
                contexts.update(self.queue.get(timeout=0.1))
            except Empty:
                if all(not p.is_alive() for p in self._processes):
                    break

        for task in self.tasks:
            if task.task_id in contexts:
                task.current_context = contexts[task.task_id][
                    "current_context"
                ]
                task.duration = contexts[task.task_id]["duration"]
                task.errors = contexts[task.task_id]["errors"]
                task.retry_count = contexts[task.task_id]["retry_count"]
                task.status = contexts[task.task_id]["status"]
            else:
                task.status = TypeStatus.FAILED
                task.errors = TaskError(
                    RuntimeError(
                        "Worker process terminated without reporting a result"
                    )
                )

        return self.tasks

    def _flow_callback(self, task: Task) -> None:
        current_task = {
            task.task_id: {
                "current_context": task.current_context,
                "duration": task.duration,
                "errors": task.errors,
                "retry_count": task.retry_count,
                "status": task.status,
            }
        }
        self.queue.put(current_task)

    def run(self) -> None:
        for _, group_tasks in self.groups.items():
            process = _mp.Process(target=self._run_group, args=(group_tasks,))
            process.start()
            self._processes.append(process)

        for process in self._processes:
            process.join()

    def _has_checkpoint(self, task: Task) -> bool:
        if not self.resume:
            return False

        context = task.config.storage.get(
            key=task.config.storage.key(task=task)
        )

        return context.storage is not None

    def _run_group(self, groups: list[Task]) -> None:
        previous_context = Context(workflow_id=self.workflow_id)

        for task in groups:
            if self._has_checkpoint(task):
                previous_context = task.config.storage.get(
                    key=task.config.storage.key(task=task)
                )

                task.status = TypeStatus.COMPLETED
                task.current_context = previous_context
                self._flow_callback(task=task)
                continue

            Execution(
                task=task,
                workflow_id=self.workflow_id,
                previous_context=previous_context,
                _flow_callback=self._flow_callback,
            )

            previous_context = task.config.storage.get(
                key=task.config.storage.key(task=task)
            )

            if not self.ignore and task.status == TypeStatus.FAILED:
                break


class Background(Flow):
    """Background"""

    def setup_queue(self) -> None:
        self.queue = []
        self._lock = threading.Lock()

    def get_tasks(self) -> list[Task]:
        return self.tasks

    def _flow_callback(self, task: Task) -> None:
        with self._lock:
            self.queue.append(task)

    def _has_checkpoint(self, task: Task) -> bool:
        if not self.resume:
            return False

        context = task.config.storage.get(
            key=task.config.storage.key(task=task)
        )

        return context.storage is not None

    def _run_sequential(self) -> None:
        previous_context = Context(workflow_id=self.workflow_id)

        for task in self.tasks:
            if self._has_checkpoint(task):
                previous_context = task.config.storage.get(
                    key=task.config.storage.key(task=task)
                )

                task.status = TypeStatus.COMPLETED
                task.current_context = previous_context
                self._flow_callback(task=task)
                continue

            Execution(
                task=task,
                workflow_id=self.workflow_id,
                previous_context=previous_context,
                _flow_callback=self._flow_callback,
            )

            previous_context = task.config.storage.get(
                key=task.config.storage.key(task=task)
            )

            if not self.ignore and task.status == TypeStatus.FAILED:
                break

    def run(self) -> None:
        self.thread = threading.Thread(
            target=self._run_sequential, daemon=True
        )
        self.thread.start()


class Parallel(Flow):
    """Parallel"""

    def setup_queue(self) -> None:
        self.queue = _mp.Queue()
        self._processes = []

    def get_tasks(self) -> list[Task]:
        contexts = {}
        while len(contexts) < len(self.tasks):
            try:
                contexts.update(self.queue.get(timeout=0.1))
            except Empty:
                if all(not p.is_alive() for p in self._processes):
                    break

        for task in self.tasks:
            if task.task_id in contexts:
                task.current_context = contexts[task.task_id][
                    "current_context"
                ]
                task.duration = contexts[task.task_id]["duration"]
                task.errors = contexts[task.task_id]["errors"]
                task.retry_count = contexts[task.task_id]["retry_count"]
                task.status = contexts[task.task_id]["status"]
            else:
                task.status = TypeStatus.FAILED
                task.errors = TaskError(
                    RuntimeError(
                        "Worker process terminated without reporting a result"
                    )
                )

        return self.tasks

    def _flow_callback(self, task: Task) -> None:
        current_task = {
            task.task_id: {
                "current_context": task.current_context,
                "duration": task.duration,
                "errors": task.errors,
                "retry_count": task.retry_count,
                "status": task.status,
            }
        }
        self.queue.put(current_task)

    def run(self) -> None:
        previous_context = Context(workflow_id=self.workflow_id)

        for task in self.tasks:
            process = _mp.Process(
                target=Execution,
                args=(
                    task,
                    self.workflow_id,
                    previous_context,
                    self._flow_callback,
                ),
            )
            process.start()
            self._processes.append(process)

        for process in self._processes:
            process.join()
