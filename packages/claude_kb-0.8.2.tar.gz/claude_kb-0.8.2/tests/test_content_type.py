"""Tests for the content-type classifier used by the search filter (client-side)."""

from claude_kb.db import classify_content_type


class TestClassifyContentType:
    def test_plain_string_is_prose(self):
        assert classify_content_type("hello world") == "prose"

    def test_text_only_blocks(self):
        assert classify_content_type([{"type": "text", "text": "hi"}]) == "prose"

    def test_tool_use_only(self):
        blocks = [{"type": "tool_use", "name": "Bash", "input": {}}]
        assert classify_content_type(blocks) == "tool_use"

    def test_tool_result_only(self):
        blocks = [{"type": "tool_result", "content": "..."}]
        assert classify_content_type(blocks) == "tool_result"

    def test_thinking_only(self):
        blocks = [{"type": "thinking", "thinking": "..."}]
        assert classify_content_type(blocks) == "thinking"

    def test_mixed(self):
        blocks = [
            {"type": "text", "text": "Let me check"},
            {"type": "tool_use", "name": "Bash", "input": {}},
        ]
        assert classify_content_type(blocks) == "mixed"

    def test_json_stringified_list(self):
        s = '[{"type":"tool_result","content":"out"}]'
        assert classify_content_type(s) == "tool_result"

    def test_json_stringified_thinking(self):
        s = '[{"type":"thinking","thinking":"weighing options"}]'
        assert classify_content_type(s) == "thinking"

    def test_empty(self):
        assert classify_content_type("") == "empty"
        assert classify_content_type([]) == "empty"

    def test_malformed_json_string_falls_to_empty(self):
        # Non-JSON list-looking string should be treated as plain prose-or-empty
        assert classify_content_type("[not json") == "empty"

    def test_dict_block_without_type(self):
        # Block without "type" doesn't contribute -> empty
        assert classify_content_type([{"foo": "bar"}]) == "empty"

    def test_bash_stdout_xml_wrapped(self):
        # Claude Code local bash hook output is stored as a plain string with XML tags,
        # not structured blocks. Should still be tagged tool_result so the default filter excludes it.
        s = "<bash-stdout>(Bash completed with no output)</bash-stdout><bash-stderr></bash-stderr>"
        assert classify_content_type(s) == "tool_result"

    def test_bash_stdout_with_content(self):
        s = "<bash-stdout>file1.txt\nfile2.txt</bash-stdout><bash-stderr></bash-stderr>"
        assert classify_content_type(s) == "tool_result"

    def test_local_command_stdout(self):
        assert (
            classify_content_type("<local-command-stdout></local-command-stdout>") == "tool_result"
        )

    def test_local_command_stderr(self):
        assert (
            classify_content_type("<local-command-stderr>err</local-command-stderr>")
            == "tool_result"
        )

    def test_bash_stderr_only(self):
        assert classify_content_type("<bash-stderr>error</bash-stderr>") == "tool_result"

    def test_xml_tool_output_with_leading_whitespace(self):
        assert classify_content_type("  <bash-stdout>x</bash-stdout>") == "tool_result"


class TestBackfillAction:
    """Backfill decision policy: which points get classified, written, or skipped."""

    def setup_method(self):
        from claude_kb.cli import _backfill_action

        self.action = _backfill_action

    def test_untagged_point_always_classified(self):
        # No existing tag -> classify and write, regardless of retag flag.
        for retag in (False, True):
            action, tag = self.action(None, "hello world", retag=retag)
            assert action == "tag_new"
            assert tag == "prose"

    def test_tagged_point_skipped_without_retag(self):
        # Existing tag + retag=False -> skip the point untouched.
        action, tag = self.action("prose", "anything", retag=False)
        assert action == "skip"
        assert tag is None

    def test_tagged_point_classified_with_retag(self):
        # Existing tag + retag=True -> classify and compare.
        # Tag matches current classifier -> unchanged (no write).
        action, tag = self.action("prose", "hello world", retag=True)
        assert action == "unchanged"
        assert tag == "prose"

    def test_stale_tag_overwritten_with_retag(self):
        # Existing "prose" tag + content the classifier now detects as tool_result
        # -> retag with the new tag.
        action, tag = self.action("prose", "<bash-stdout>file1.txt</bash-stdout>", retag=True)
        assert action == "retag"
        assert tag == "tool_result"

    def test_retag_does_not_overwrite_correct_tag(self):
        # Common case after running --retag once: most points already match.
        action, tag = self.action(
            "tool_result", '[{"type":"tool_result","content":"x"}]', retag=True
        )
        assert action == "unchanged"
        assert tag == "tool_result"
