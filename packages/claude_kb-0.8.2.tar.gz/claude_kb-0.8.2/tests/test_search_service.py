"""Tests for SearchService restore and retrieval edge cases."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime

import numpy as np

from claude_kb import search as search_module
from claude_kb.models import ErrorResult, GetResult, SearchResult
from claude_kb.search import SearchService


@dataclass
class FakePoint:
    """Minimal Qdrant point shape for tests."""

    id: str
    payload: dict | None
    score: float | None = None


class _FakeCountResult:
    def __init__(self, count: int):
        self.count = count


class FakeClient:
    """Fake Qdrant client that supports paginated scroll() and count()."""

    def __init__(self, points: list[FakePoint]):
        self.points = points
        self.scroll_calls: list[dict] = []
        self.count_calls: list[dict] = []

    def scroll(
        self,
        collection_name: str,
        scroll_filter=None,
        limit: int = 100,
        offset=None,
        with_payload: bool = True,
        with_vectors: bool = False,
    ):
        del collection_name, scroll_filter, with_vectors
        self.scroll_calls.append({"limit": limit, "offset": offset, "with_payload": with_payload})

        start = 0 if offset is None else offset
        end = min(start + limit, len(self.points))
        page = self.points[start:end]
        if not with_payload:
            page = [FakePoint(id=p.id, payload=None) for p in page]

        next_offset = end if end < len(self.points) else None
        return page, next_offset

    def count(self, collection_name: str, count_filter, exact: bool = True):
        del collection_name, count_filter, exact
        self.count_calls.append({})
        return _FakeCountResult(len(self.points))


class _FakeEmbeddingModel:
    """Stand-in for db.embedding_model on the search hot path."""

    def load(self) -> None:
        return None

    def encode(self, texts, batch_size=1, show_progress=False):
        del batch_size, show_progress
        return np.zeros((len(texts), 4), dtype=np.float32)


class FakeDB:
    """Fake DB adapter for SearchService tests."""

    def __init__(self, points: list[FakePoint]):
        self.client = FakeClient(points)
        self.embedding_model = _FakeEmbeddingModel()
        self.search_calls: list[dict] = []

    def get_thread_context(self, collection: str, message_id: str, depth: int):
        del collection, message_id, depth
        return []

    def get_by_id(self, collection: str, point_id: str):
        del collection, point_id
        return None

    def has_sparse_vectors(self, collection: str) -> bool:
        del collection
        return False

    def ensure_indices(self, collection: str) -> None:
        del collection

    def search(
        self,
        query_vector,
        collection: str,
        limit: int,
        query_filter=None,
        score_threshold: float = 0.0,
        sparse_vector=None,
    ):
        """Return points sorted by score, ignoring query_filter so tests can
        exercise the client-side fallback against the same input set."""
        del query_vector, collection, sparse_vector
        self.search_calls.append({"limit": limit, "score_threshold": score_threshold})
        ranked = sorted(
            (p for p in self.client.points if (p.score or 0.0) >= score_threshold),
            key=lambda p: p.score or 0.0,
            reverse=True,
        )
        return ranked[:limit]


def make_point(
    point_id: str,
    *,
    role: str,
    timestamp: str,
    content: str | list | dict,
    conversation_id: str = "conv-1",
    project_path: str = "/tmp/project",
    parent_message_id: str | None = None,
    score: float | None = None,
) -> FakePoint:
    """Build a fake point payload."""
    payload = {
        "message_id": point_id,
        "role": role,
        "timestamp": timestamp,
        "content": content,
        "project_path": project_path,
        "conversation_id": conversation_id,
    }
    if parent_message_id is not None:
        payload["parent_message_id"] = parent_message_id
    return FakePoint(id=point_id, payload=payload, score=score)


def make_service(points: list[FakePoint]) -> SearchService:
    """Create service with fake DB and fixed collection."""
    service = SearchService(db=FakeDB(points))
    service._collection = "conversations"  # Bypass auto-detection during tests.
    return service


def test_get_conversation_restores_clean_text_and_metadata():
    """Restore mode should keep readable text and strip tool/thinking/system blocks."""
    points = [
        make_point(
            "m3",
            role="user",
            timestamp="2026-01-01T10:00:03+00:00",
            content=[{"type": "text", "text": "late message"}],
        ),
        make_point(
            "m1",
            role="user",
            timestamp="2026-01-01T10:00:00",
            content="<system-reminder>remove this</system-reminder>Hello there",
        ),
        make_point(
            "m2",
            role="assistant",
            timestamp="2026-01-01T10:00:01Z",
            content=json.dumps(
                [
                    {"type": "thinking", "thinking": "hidden"},
                    {"type": "text", "text": "Answer one"},
                    {"type": "tool_use", "name": "lookup"},
                    {"type": "tool_result", "content": "verbose data"},
                    {"type": "text", "text": "Final bit <system-reminder>x</system-reminder>"},
                ]
            ),
        ),
        make_point(
            "meta-1",
            role="system",
            timestamp="2026-01-01T10:00:02+00:00",
            content="meta",
        ),
    ]
    service = make_service(points)

    result = service.get_conversation("conv-1", up_to="m2", max_messages=10)

    assert isinstance(result, GetResult)
    assert result.thread is not None
    assert [msg.id for msg in result.thread] == ["m1", "m2"]
    assert [msg.role for msg in result.thread] == ["user", "assistant"]

    all_content = "\n".join(msg.content for msg in result.thread)
    assert "tool_use" not in all_content
    assert "tool_result" not in all_content
    assert "thinking" not in all_content
    assert "<system-reminder>" not in all_content
    assert "[user] Hello there" in result.thread[0].content
    assert "Answer one" in result.thread[1].content
    assert "Final bit" in result.thread[1].content
    assert result.thread[0].content.endswith("\n\n---")

    assert result.message.conversation_id == "conv-1"
    assert "message_count=2" in result.message.content
    assert "up_to=m2" in result.message.content


def test_get_conversation_applies_max_messages_after_up_to():
    """Restore mode should truncate to most recent N messages after up_to selection."""
    points = [
        make_point(
            f"m{i}",
            role="user" if i % 2 else "assistant",
            timestamp=f"2026-01-01T10:00:0{i}" + ("Z" if i % 2 else ""),
            content=[{"type": "text", "text": f"message {i}"}],
        )
        for i in range(1, 6)
    ]
    service = make_service(points)

    result = service.get_conversation("conv-1", up_to="m5", max_messages=2)

    assert isinstance(result, GetResult)
    assert result.thread is not None
    assert [msg.id for msg in result.thread] == ["m4", "m5"]
    assert "truncated_to_most_recent=2" in result.message.content


def test_get_validates_ambiguous_and_unsupported_restore_flags():
    """Service.get should reject mixed modes and restore-only incompatible flags."""
    service = make_service([])

    both_ids = service.get(message_id="m1", conversation_id="conv-1")
    assert isinstance(both_ids, ErrorResult)
    assert "mutually exclusive" in both_ids.error

    restore_with_include = service.get(conversation_id="conv-1", include_tool_results=True)
    assert isinstance(restore_with_include, ErrorResult)
    assert "not supported in conversation restore mode" in restore_with_include.error


def test_strip_system_reminders_and_parse_timestamp_fallback():
    """System reminder cleanup and timestamp parsing should be deterministic."""
    service = make_service([])

    cleaned = service._strip_system_reminders("a<system-reminder>drop</system-reminder>b\n\n\n\nc")
    assert cleaned == "ab\n\nc"

    cleaned_open = service._strip_system_reminders("prefix<system-reminder>drop rest")
    assert cleaned_open == "prefix"

    fallback = datetime(2000, 1, 1, tzinfo=UTC)
    assert service._parse_timestamp("not-a-time", fallback=fallback) == fallback
    assert service._parse_timestamp("2026-01-01T10:00:00").tzinfo is not None


def test_count_uses_native_count_api_and_scroll_paginates():
    """Conversation count goes through qdrant's count API (one call); restore
    scroll still paginates."""
    points = [
        make_point(
            f"m{i}",
            role="user",
            timestamp=f"2026-01-01T10:00:{i % 60:02d}Z",
            content="x",
        )
        for i in range(205)
    ]
    service = make_service(points)
    client = service.db.client

    # _get_conversation_message_count should hit count() exactly once - no scrolling.
    scroll_count_before = len(client.scroll_calls)
    count = service._get_conversation_message_count("conv-1")
    assert count == 205
    assert len(client.count_calls) == 1
    assert len(client.scroll_calls) == scroll_count_before  # No scroll calls added.

    # Restore path still paginates via scroll.
    loaded = service._scroll_conversation_points("conv-1", with_payload=True)
    assert len(loaded) == 205
    assert loaded[0].payload is not None


# ==================== Compact mode tests ====================


def test_compact_strips_parent_id_and_shortens_project():
    """Compact mode should drop parent_id and shorten project to basename."""
    point = make_point(
        "m1",
        role="user",
        timestamp="2026-01-01T10:00:00Z",
        content="hello",
        project_path="/Users/tenequm/Projects/claude-kb",
        parent_message_id="m0",
        score=0.85,
    )
    service = make_service([])
    msg = service._to_message(point, compact=True)

    assert msg.parent_id is None
    assert msg.project == "claude-kb"


def test_compact_rounds_score():
    """Compact mode should round score to 2 decimal places."""
    point = make_point(
        "m1",
        role="assistant",
        timestamp="2026-01-01T10:00:00Z",
        content="response",
        score=0.8260917916427055,
    )
    service = make_service([])
    msg = service._to_message(point, compact=True)

    assert msg.score == 0.83


def test_compact_unwraps_single_text_block():
    """Compact mode should unwrap single text blocks to plain text."""
    service = make_service([])
    content = json.dumps([{"type": "text", "text": "hello world"}])
    result = service._clean_content(content, compact=True)

    assert result == "hello world"


def test_compact_keeps_multi_block_as_compact_json():
    """Compact mode should use compact JSON for multi-block content."""
    service = make_service([])
    content = json.dumps(
        [
            {"type": "text", "text": "first"},
            {"type": "text", "text": "second"},
        ]
    )
    result = service._clean_content(content, compact=True)

    assert "\n" not in result
    assert "  " not in result
    parsed = json.loads(result)
    assert len(parsed) == 2


def test_compact_strips_tool_use_blocks():
    """tool_use blocks should be reduced to type+name when include_tool_results=False."""
    service = make_service([])
    content = json.dumps(
        [
            {"type": "text", "text": "searching"},
            {
                "type": "tool_use",
                "id": "toolu_01Eh3cbqQaYMTcq2fKUxZupu",  # pragma: allowlist secret
                "name": "mcp__kb__kb_search",
                "input": {"query": "test", "limit": 10},
                "caller": {"type": "direct"},
            },
        ]
    )
    result = service._clean_content(content, include_tool_results=False, compact=True)
    parsed = json.loads(result)

    tool_block = parsed[1]
    assert tool_block == {"type": "tool_use", "name": "mcp__kb__kb_search"}
    assert "id" not in tool_block
    assert "input" not in tool_block
    assert "caller" not in tool_block


def test_is_thinking_only_helper():
    """_is_thinking_only should detect thinking-only content patterns."""
    assert SearchService._is_thinking_only("[thinking: 1234 chars]")
    assert SearchService._is_thinking_only(
        json.dumps([{"type": "thinking", "thinking": "[thinking: 500 chars]"}])
    )
    assert not SearchService._is_thinking_only("actual useful content")
    assert not SearchService._is_thinking_only(
        json.dumps(
            [
                {"type": "thinking", "thinking": "..."},
                {"type": "text", "text": "useful"},
            ]
        )
    )
    assert not SearchService._is_thinking_only("")


def test_compact_restore_deduplicates_fields():
    """Compact restore should drop conversation_id and parent_id from thread messages."""
    points = [
        make_point(
            "m1",
            role="user",
            timestamp="2026-01-01T10:00:00Z",
            content="hello",
            parent_message_id="m0",
            project_path="/Users/tenequm/Projects/myproject",
        ),
        make_point(
            "m2",
            role="assistant",
            timestamp="2026-01-01T10:00:01Z",
            content="world",
            parent_message_id="m1",
            project_path="/Users/tenequm/Projects/myproject",
        ),
    ]
    service = make_service(points)

    result = service.get_conversation("conv-1", compact=True)

    assert isinstance(result, GetResult)
    assert result.thread is not None
    for msg in result.thread:
        assert msg.conversation_id is None
        assert msg.parent_id is None
        assert msg.project == "myproject"

    # Summary message should still have conversation_id
    assert result.message.conversation_id == "conv-1"


def test_non_compact_preserves_all_fields():
    """Default (non-compact) mode should preserve all metadata fields."""
    point = make_point(
        "m1",
        role="user",
        timestamp="2026-01-01T10:00:00Z",
        content=json.dumps([{"type": "text", "text": "hello"}]),
        project_path="/Users/tenequm/Projects/claude-kb",
        parent_message_id="m0",
        score=0.8260917916427055,
    )
    service = make_service([])
    msg = service._to_message(point, compact=False)

    assert msg.parent_id == "m0"
    assert msg.project == "/Users/tenequm/Projects/claude-kb"
    assert msg.score == 0.8260917916427055
    # Non-compact keeps JSON wrapping
    assert '"type": "text"' in msg.content


# ==================== Dual-stage content-type filter tests ====================


def _reset_tag_probe():
    """The `_maybe_warn_untagged` probe dedupes by (process, collection). Tests
    sharing the "conversations" collection name need to reset between cases."""
    search_module._TAG_PROBED.clear()


def make_search_point(
    point_id: str,
    *,
    content,
    score: float,
    primary_content_type: str | None = None,
    role: str = "user",
    timestamp: str = "2026-01-01T10:00:00Z",
) -> FakePoint:
    """Build a fake point usable by FakeDB.search() (carries a score)."""
    payload = {
        "message_id": point_id,
        "role": role,
        "timestamp": timestamp,
        "content": content,
        "project_path": "/tmp/project",
        "conversation_id": "conv-1",
    }
    if primary_content_type is not None:
        payload["primary_content_type"] = primary_content_type
    return FakePoint(id=point_id, payload=payload, score=score)


def test_search_drops_untagged_tool_result_via_classifier():
    """Untagged XML-wrapped bash output should be dropped by the client-side
    fallback even though the server-side must_not can't match missing fields."""
    _reset_tag_probe()
    points = [
        make_search_point("p1", content="how do I write a python decorator", score=0.9),
        make_search_point(
            "p2",
            content="<bash-stdout>file1.txt\nfile2.txt</bash-stdout><bash-stderr></bash-stderr>",
            score=0.85,
        ),
    ]
    service = make_service(points)

    result = service.search(query="x", limit=5, boost_recent=False, min_score=0.0)

    assert isinstance(result, SearchResult)
    ids = {m.id for m in result.results}
    assert "p1" in ids
    assert "p2" not in ids


def test_search_drops_tagged_tool_result_via_payload_tag():
    """A point pre-tagged primary_content_type=tool_result is dropped without
    re-running the classifier (tag-first fast path)."""
    _reset_tag_probe()
    points = [
        make_search_point("p1", content="prose answer", score=0.9, primary_content_type="prose"),
        make_search_point(
            "p2",
            content="opaque content the classifier wouldn't catch",
            score=0.85,
            primary_content_type="tool_result",
        ),
    ]
    service = make_service(points)

    result = service.search(query="x", limit=5, boost_recent=False, min_score=0.0)

    assert isinstance(result, SearchResult)
    ids = {m.id for m in result.results}
    assert "p1" in ids
    assert "p2" not in ids


def test_search_drops_stale_prose_tag_via_classifier():
    """A point tagged `prose` before the XML tool-output classifier landed must
    still be dropped: the tag is treated as quick-reject only, so a non-excluded
    tag never short-circuits classification."""
    _reset_tag_probe()
    points = [
        make_search_point("p1", content="legitimate prose answer", score=0.9),
        make_search_point(
            "p2",
            content="<bash-stdout>ls output</bash-stdout>",
            score=0.85,
            primary_content_type="prose",  # stale tag from before XML detection
        ),
    ]
    service = make_service(points)

    result = service.search(query="x", limit=5, boost_recent=False, min_score=0.0)

    assert isinstance(result, SearchResult)
    ids = {m.id for m in result.results}
    assert "p1" in ids
    assert "p2" not in ids


def test_search_includes_tool_result_when_flag_true():
    """include_tool_results=True must skip both server-side and client-side filters."""
    _reset_tag_probe()
    points = [
        make_search_point("p1", content="prose answer", score=0.9),
        make_search_point(
            "p2",
            content="<bash-stdout>cmd output</bash-stdout>",
            score=0.85,
        ),
        make_search_point(
            "p3",
            content="tagged tool",
            score=0.8,
            primary_content_type="tool_result",
        ),
    ]
    service = make_service(points)

    result = service.search(
        query="x",
        limit=5,
        boost_recent=False,
        min_score=0.0,
        include_tool_results=True,
    )

    assert isinstance(result, SearchResult)
    ids = {m.id for m in result.results}
    assert ids == {"p1", "p2", "p3"}


def test_search_drops_thinking_by_default():
    """Default search should drop thinking-only points via the same dual filter."""
    _reset_tag_probe()
    points = [
        make_search_point("p1", content="prose answer", score=0.9),
        make_search_point(
            "p2",
            content=json.dumps([{"type": "thinking", "thinking": "weighing options"}]),
            score=0.85,
        ),
        make_search_point(
            "p3",
            content="anything",
            score=0.8,
            primary_content_type="thinking",
        ),
    ]
    service = make_service(points)

    result = service.search(query="x", limit=5, boost_recent=False, min_score=0.0)

    assert isinstance(result, SearchResult)
    ids = {m.id for m in result.results}
    assert ids == {"p1"}


def test_search_overfetches_when_filter_active():
    """With excluded_types active, the search should request 3x the user limit."""
    _reset_tag_probe()
    points = [make_search_point(f"p{i}", content="prose", score=1.0 - i * 0.01) for i in range(40)]
    service = make_service(points)

    service.search(query="x", limit=5, boost_recent=False, min_score=0.0)

    assert service.db.search_calls
    assert service.db.search_calls[-1]["limit"] == 5 * 3


def test_search_overfetch_compounds_for_compact_plus_filter():
    """compact + excluded_types should compound multipliers: limit * 3 * 1.5 = 4.5x."""
    _reset_tag_probe()
    points = [make_search_point(f"p{i}", content="prose", score=1.0 - i * 0.01) for i in range(80)]
    service = make_service(points)

    service.search(query="x", limit=10, boost_recent=False, min_score=0.0, compact=True)

    assert service.db.search_calls[-1]["limit"] == int(10 * 3 * 1.5)


def test_search_overfetch_floors_at_10x_for_grouping():
    """group_by_conversation should floor over-fetch at 10x even when other multipliers
    would individually be smaller."""
    _reset_tag_probe()
    # Spread points across 12 conversations so grouping has enough material.
    points = [
        FakePoint(
            id=f"p{i}",
            payload={
                "message_id": f"p{i}",
                "role": "user",
                "timestamp": "2026-01-01T10:00:00Z",
                "content": "prose",
                "project_path": "/tmp/project",
                "conversation_id": f"conv-{i % 12}",
            },
            score=1.0 - i * 0.005,
        )
        for i in range(120)
    ]
    service = make_service(points)

    service.search(
        query="x", limit=5, boost_recent=False, min_score=0.0, group_by_conversation=True
    )

    # max(limit * 3, limit * 10) = 50; max(int(limit * 4.5), limit * 10) = 50.
    assert service.db.search_calls[-1]["limit"] == 5 * 10


def test_search_overfetch_default_no_filter_no_compact():
    """With no filter, no compact, no grouping: search should request exactly limit."""
    _reset_tag_probe()
    points = [make_search_point(f"p{i}", content="prose", score=1.0 - i * 0.01) for i in range(20)]
    service = make_service(points)

    service.search(
        query="x",
        limit=7,
        boost_recent=False,
        min_score=0.0,
        include_tool_results=True,
        include_thinking=True,
    )

    assert service.db.search_calls[-1]["limit"] == 7


def test_search_recency_boost_runs_after_client_side_filter():
    """Recency boost should reorder by boosted score AFTER the client-side filter
    drops excluded points - the dropped points must not influence the post-boost
    ordering."""
    _reset_tag_probe()
    now_iso = datetime.now(UTC).isoformat()
    old_iso = "2020-01-01T00:00:00+00:00"
    points = [
        # Older prose with a high raw score - should win without boost.
        make_search_point("old_prose", content="prose answer", score=0.9, timestamp=old_iso),
        # Recent prose with a slightly lower raw score - boost should lift it past old_prose.
        make_search_point("new_prose", content="prose answer", score=0.85, timestamp=now_iso),
        # Tool-result that would beat both raw scores but must be filtered first.
        make_search_point(
            "tool",
            content="<bash-stdout>x</bash-stdout>",
            score=0.95,
            timestamp=now_iso,
        ),
    ]
    service = make_service(points)

    result = service.search(query="x", limit=2, boost_recent=True, min_score=0.0)

    assert isinstance(result, SearchResult)
    ids = [m.id for m in result.results]
    assert "tool" not in ids  # client-side filter dropped it
    assert ids[0] == "new_prose"  # recency boost beat old_prose


def test_search_group_by_conversation_with_filter_drops_excluded():
    """group_by_conversation should still apply the client-side filter so excluded
    content doesn't pollute conversation summaries."""
    _reset_tag_probe()
    points = [
        FakePoint(
            id="p1",
            payload={
                "message_id": "p1",
                "role": "user",
                "timestamp": "2026-01-01T10:00:00Z",
                "content": "prose answer",
                "project_path": "/tmp/project",
                "conversation_id": "conv-prose",
            },
            score=0.9,
        ),
        FakePoint(
            id="p2",
            payload={
                "message_id": "p2",
                "role": "user",
                "timestamp": "2026-01-01T10:00:00Z",
                "content": "<bash-stdout>noise</bash-stdout>",
                "project_path": "/tmp/project",
                "conversation_id": "conv-tool",
            },
            score=0.95,
        ),
    ]
    service = make_service(points)

    result = service.search(
        query="x", limit=10, boost_recent=False, min_score=0.0, group_by_conversation=True
    )

    from claude_kb.models import ConversationSearchResult

    assert isinstance(result, ConversationSearchResult)
    conv_ids = {c.conversation_id for c in result.conversations}
    assert "conv-prose" in conv_ids
    assert "conv-tool" not in conv_ids


def test_maybe_warn_untagged_marks_only_after_successful_scroll(monkeypatch, caplog):
    """A scroll exception must not mark the collection probed - the warning has to
    remain available on a later successful search."""
    import logging as _logging

    _reset_tag_probe()
    points = [make_search_point(f"p{i}", content="prose", score=1.0 - i * 0.01) for i in range(5)]
    service = make_service(points)
    client = service.db.client

    # First call: scroll raises -> collection must NOT be added to _TAG_PROBED.
    real_scroll = client.scroll
    calls = {"n": 0}

    def flaky_scroll(*args, **kwargs):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("transient qdrant blip")
        return real_scroll(*args, **kwargs)

    monkeypatch.setattr(client, "scroll", flaky_scroll)

    with caplog.at_level(_logging.DEBUG, logger="claude_kb.search"):
        search_module._maybe_warn_untagged(service.db, "conversations")

    assert "conversations" not in search_module._TAG_PROBED  # not marked after failure

    # Second call: scroll succeeds, collection should now be marked probed.
    search_module._maybe_warn_untagged(service.db, "conversations")
    assert "conversations" in search_module._TAG_PROBED


def test_maybe_warn_untagged_dedupes_after_success():
    """Once a successful probe runs, repeat calls must short-circuit on the lock
    check without scrolling again."""
    _reset_tag_probe()
    points = [make_search_point(f"p{i}", content="prose", score=1.0 - i * 0.01) for i in range(5)]
    service = make_service(points)
    client = service.db.client

    search_module._maybe_warn_untagged(service.db, "conversations")
    scroll_count_after_first = len(client.scroll_calls)

    # Repeat call should not add another scroll.
    search_module._maybe_warn_untagged(service.db, "conversations")
    assert len(client.scroll_calls) == scroll_count_after_first
