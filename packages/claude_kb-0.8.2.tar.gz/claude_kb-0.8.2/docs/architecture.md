# Architecture

One page. Pipelines from Claude Code's on-disk session logs into a Qdrant collection,
then exposes that collection as both a CLI and an MCP server.

## Pipeline

```
~/.claude/projects/<encoded-cwd>/<session-uuid>.jsonl
        │
        │  (one JSONL line per message; UUID, role, content, timestamp,
        │   sessionId, parentUuid, cwd)
        ▼
┌───────────────────────────────────────────────────┐
│ parse_session_file        src/claude_kb/import_claude.py │
│   - skips isMeta unless include_meta              │
│   - normalises content (list -> JSON string)      │
│   - parses ISO timestamps, derives timestamp_unix │
└───────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────┐
│ Classify content_type                              │
│   classify_content_type() in db.py                 │
│   → prose | tool_use | tool_result | thinking |    │
│     mixed | empty                                  │
└───────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────┐
│ Embedding (per message, no chunking)              │
│   dense:  BAAI/bge-base-en-v1.5  (768d, normalised)│
│           sentence-transformers, MPS/CUDA/CPU      │
│   (sparse vector slot reserved in schema; not      │
│    populated or queried in the production path -   │
│    see docs/retrieval-experiments-2026-05.md)      │
└───────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────┐
│ Qdrant collection: conversations_hybrid            │
│   named vectors:  dense (cosine)                   │
│   payload: message_id, conversation_id, role,     │
│            content, primary_content_type (KEYWORD- │
│            indexed), timestamp, timestamp_unix,    │
│            project_path, parent_message_id, ...    │
│   point id = Claude Code message UUID             │
└───────────────────────────────────────────────────┘
        │
        │  query_points(dense)
        │  + server-side filter (project, conversation_id, role,
        │    timestamp_unix range, primary_content_type must_not in
        │    {tool_result, thinking} unless include_* opt-in)
        │  + score_threshold = min_score
        ▼
┌───────────────────────────────────────────────────┐
│ Post-processing (SearchService, search.py)         │
│   - client-side date fallback for legacy points   │
│   - recency boost: +0.2 * exp(-age / 1 week)      │
│   - compact mode: strip metadata for MCP          │
│   - group_by_conversation: aggregate to summaries │
└───────────────────────────────────────────────────┘
        │
        ▼
   ┌──────────────────┐    ┌────────────────────────────┐
   │ CLI (kb …)        │    │ MCP server                  │
   │   kb search       │    │   kb_search                 │
   │   kb get          │    │   kb_get                    │
   │   kb get-thread   │    │   stdio | streamable-http   │
   │   kb status       │    │                             │
   └──────────────────┘    └────────────────────────────┘
```

## Collections

The codebase auto-detects which collection to use, preferring the named-vector
one if both exist (`search.py`, `_get_best_collection` in `import_claude.py`):

| Collection                 | Vectors                       | Search path |
| -------------------------- | ----------------------------- | ----------- |
| `conversations_hybrid`     | named `dense` (sparse slot reserved but unused) | dense-only |
| `conversations` (legacy)   | unnamed dense only            | dense-only  |

`kb migrate` builds `conversations_hybrid` from a legacy `conversations`
collection. The sparse arm is no longer populated by default; the slot is kept
in the schema so future encoder experiments can backfill into it without a
schema change.

## Why this shape

- **One Qdrant point per Claude Code message.** Rationale and alternatives in
  [chunking.md](chunking.md).
- **Dense-only retrieval, BGE-base 768d.** Five experiments
  ([retrieval-experiments-2026-05.md](retrieval-experiments-2026-05.md))
  confirmed dense-only is the ceiling on this corpus shape (short-form English
  code-conversation messages, ~47 words/doc median). Hybrid RRF-fusion
  regressed Recall@10 by 0.075; SOTA bigger encoders (bge-m3, Qwen3-8B)
  regressed by 0.18-0.22. The BM25 sparse vectors are kept in storage so the
  hybrid path stays one config flip away if the corpus shape ever changes.
- **Default-deny on tool_result and thinking blocks (dual-stage).**
  - **Server-side fast path:** a KEYWORD-indexed `primary_content_type` payload
    field lets qdrant prune tagged candidates before scoring. Set on new imports
    automatically; legacy collections opt in via `kb backfill-content-type`.
  - **Client-side fallback:** after qdrant returns top-K, the search loop
    consults each result's `primary_content_type` payload tag if present, or
    runs `classify_content_type` against the content for untagged points, and
    drops anything that should be excluded. Catches untagged points (qdrant
    `must_not` does not match missing fields) and any points whose stored tag
    is stale relative to the current classifier. Search over-fetches by 3x
    when content filtering is active; compact mode adds another 1.5x;
    `group_by_conversation` floors the over-fetch at 10x.
  - First search per process logs an INFO line if `primary_content_type`
    coverage is below 50%, suggesting the backfill command. Search results are
    correct without backfilling - the warning is purely a performance hint.
- **Server-side filtering wherever possible.** `min_score`, `project`,
  `conversation_id`, `role`, and date ranges all push down into Qdrant via
  `Filter` and `score_threshold`. Client-side fallbacks: a date filter for
  legacy points missing `timestamp_unix`, and the content-type re-check above.
- **Recency boost is post-hoc, not embedded.** Time is not a vector. The boost
  is a small additive term (`+0.2 * exp(-age / 1 week)`) applied after
  retrieval so it can be turned off (`boost_recent=False`) without re-running
  the search.
- **Two surfaces, one service.** CLI commands and MCP tools both call into
  `SearchService` (`search.py`). The compact-mode metadata stripping is
  isolated to MCP; CLI output is unaffected.

## Files

| Concern                  | File                                |
| ------------------------ | ----------------------------------- |
| CLI entrypoint           | `src/claude_kb/cli.py`              |
| MCP server + tools       | `src/claude_kb/mcp.py`              |
| Search / retrieval logic | `src/claude_kb/search.py`           |
| Qdrant client + models   | `src/claude_kb/db.py`               |
| Import pipeline          | `src/claude_kb/import_claude.py`    |
| Pydantic output models   | `src/claude_kb/models.py`           |
| Config                   | `src/claude_kb/config.py`           |
