# MCP API Reference

The `kb` MCP server exposes two tools (`kb_search`, `kb_get`) and two
resources (`schema://kb`, `stats://kb`) over stdio or Streamable HTTP.

- Source: [`src/claude_kb/mcp.py`](../src/claude_kb/mcp.py)
- Output models: [`src/claude_kb/models.py`](../src/claude_kb/models.py)

All tools return either a typed result model or `ErrorResult`. Both are
serialised by Pydantic with `None` fields stripped, so absent keys mean
"not provided" rather than "null".

## Server

| | |
| --- | --- |
| Name | `kb` |
| Tools | `kb_search`, `kb_get` |
| Resources | `schema://kb`, `stats://kb` |
| Transports | stdio (default), Streamable HTTP (`--transport http`) |
| Stateless HTTP | yes |
| Annotations | `readOnlyHint=True`, `idempotentHint=True`, `openWorldHint=False` (no external network) |

## Filter application order

Used by `kb_search`. Verbatim from the implementation:

1. Semantic search with `min_score` threshold (server-side, Qdrant
   `score_threshold`).
2. Metadata filters: `project`, `conversation_id`, `role`, `from_date`,
   `to_date` (server-side, Qdrant `Filter`).
3. Optional client-side date fallback for legacy points without
   `timestamp_unix`.
4. Recency boost (client-side, post-retrieval, optional).
5. Limit applied. With `group_by_conversation=True` the search over-fetches
   `limit * 10` candidates before grouping; with compact mode it over-fetches
   `limit * 1.5` to compensate for thinking-only message filtering.

## `kb_search`

Hybrid semantic + keyword search across imported messages. Returns either
flat message hits or conversation summaries.

### Parameters

| Name | Type | Default | Where applied | Description |
| --- | --- | --- | --- | --- |
| `query` | string | required | Qdrant (vector) | Natural-language search terms. Keep this WHAT (concepts, topics). Use the filter parameters for WHERE. |
| `limit` | int | `10` | client | Maximum hits returned. With `group_by_conversation=True` this caps conversations, not messages. |
| `project` | string \| null | `null` | server | Substring match against the `project_path` payload (Qdrant `MatchText`). Case-sensitive. Example: `"claude-kb"` matches `/Users/x/Projects/claude-kb`. |
| `conversation_id` | string \| null | `null` | server | Exact match against Claude Code `sessionId`. |
| `role` | `"user"` \| `"assistant"` \| null | `null` | server | Exact match. Lower-cased before matching. |
| `from_date` | string \| null | `null` | server | ISO `YYYY-MM-DD`. Inclusive at `00:00:00 UTC`. Filtered via `timestamp_unix` range. |
| `to_date` | string \| null | `null` | server | ISO `YYYY-MM-DD`. Inclusive at `23:59:59 UTC`. |
| `min_score` | float | `0.5` | server | Qdrant `score_threshold`. Applied **before** metadata filters in retrieval. Lower to `0.3` for exploratory recall, raise to `0.7+` for precision. |
| `boost_recent` | bool | `true` | client | Adds `0.2 * exp(-age / 7 days)` to each hit's score and re-sorts. Disable for chronologically neutral ranking. |
| `include_tool_results` | bool | `false` | server + client + output | If `false` (default), messages whose primary content is tool output are excluded from results entirely. Two-stage drop: (1) server-side `must_not` on `primary_content_type == "tool_result"` for tagged points (KEYWORD-indexed payload set by import or `kb backfill-content-type`); (2) client-side `classify_content_type` fallback that catches untagged or mistagged points after retrieval. Search over-fetches by 3x to compensate. Tool-result blocks within mixed messages also render as `[tool result: N chars]`. Content is still indexed and searchable; the flag only controls what's returned. Set `true` when a query is best satisfied by a tool output. |
| `include_thinking` | bool | `false` | server + client + output | If `false` (default), messages whose primary content is model thinking are excluded via the same two-stage drop as `include_tool_results`. Thinking blocks within mixed messages render as `[thinking: N chars]`. |
| `group_by_conversation` | bool | `false` | client | If `true`, aggregates flat hits into `ConversationSummary[]`. Over-fetches `limit * 10` to give the grouping enough material. |

### Returns

`SearchResult | ConversationSearchResult | ErrorResult`.

`SearchResult` (flat mode):

```jsonc
{
  "count": 3,
  "results": [
    {
      "id": "8c5b...uuid",
      "role": "assistant",
      "content": "...",
      "timestamp": "2026-02-19T10:14:22Z",
      "project": "claude-kb",
      "conversation_id": "abc123",          // omitted in compact mode
      "score": 0.84
    }
  ]
}
```

`ConversationSearchResult` (`group_by_conversation=true`):

```jsonc
{
  "count": 2,
  "conversations": [
    {
      "conversation_id": "abc123",
      "project": "claude-kb",
      "first_timestamp": "2026-02-19T10:00:00Z",
      "last_timestamp":  "2026-02-19T11:30:00Z",
      "message_count": 47,
      "preview": "We were debugging the recency boost...",
      "best_score": 0.84
    }
  ]
}
```

In compact mode (the default for the MCP server) the envelope `query` and
`collection` fields are stripped, project paths are shortened to the basename,
single-block content is unwrapped from its JSON-array wrapper, `tool_use`
blocks are reduced to `{type, name}`, and scores are rounded.

## `kb_get`

Retrieves a single message, a thread context, or restores a full conversation
transcript. Modes are selected by which arguments are set; `message_id` and
`conversation_id` are mutually exclusive.

### Modes

| Mode | Trigger |
| --- | --- |
| Single message | `kb_get(message_id="...")` |
| Message + thread | `kb_get(message_id="...", context_depth=N)` for N > 0 |
| Full conversation | `kb_get(conversation_id="...")` |
| Conversation up to a point | `kb_get(conversation_id="...", up_to="...")` |

### Parameters

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| `message_id` | string \| null | `null` | Message UUID from `kb_search`. Mutually exclusive with `conversation_id`. |
| `conversation_id` | string \| null | `null` | Claude Code `sessionId`. Triggers restore mode. Mutually exclusive with `message_id`. |
| `up_to` | string \| null | `null` | Restore mode only. Truncates the conversation at and **including** this message UUID. |
| `context_depth` | int | `0` | Single-message mode only. If > 0, returns ±N messages from the same conversation, ordered chronologically. |
| `max_messages` | int | `100` | Restore mode safety cap. Applied after `up_to`. Keeps the most recent `max_messages` if the conversation is longer. |
| `include_tool_results` | bool | `false` | Single/thread mode only. Returns `ErrorResult` in restore mode. |
| `include_thinking` | bool | `false` | Single/thread mode only. Returns `ErrorResult` in restore mode. |

### Returns

`GetResult | ErrorResult`. `GetResult` always has a `message`; `thread` is set
when `context_depth > 0` or in restore mode (where `thread` is the full
transcript and `message` is a synthesised system summary):

```jsonc
{
  "message": {
    "id": "8c5b...uuid",
    "role": "assistant",
    "content": "...",
    "timestamp": "2026-02-19T10:14:22Z",
    "project": "claude-kb"
  },
  "thread": [ /* surrounding or restored messages, chronological */ ]
}
```

Restore mode aggressively cleans the transcript: `tool_use`, `tool_result`,
and `thinking` blocks are stripped regardless of the `include_*` flags
(those flags would return `ErrorResult` if set).

## Error modes

All errors are returned as `ErrorResult`, never raised:

```jsonc
{ "error": "...", "suggestion": "..." }   // suggestion optional
```

Documented errors:

| Tool | Condition | `error` |
| --- | --- | --- |
| `kb_get` | neither `message_id` nor `conversation_id` set | `"Either message_id or conversation_id must be provided"` |
| `kb_get` | both `message_id` and `conversation_id` set | `"message_id and conversation_id are mutually exclusive"` |
| `kb_get` | `include_tool_results` or `include_thinking` set in restore mode | `"include_tool_results/include_thinking are not supported in conversation restore mode"` |
| `kb_get` | `max_messages <= 0` in restore mode | `"max_messages must be greater than 0"` |
| `kb_get` | `message_id` not found | `"Message not found: <id>"` |
| `kb_get` | `conversation_id` not found | `"Conversation not found: <id>"` |
| `kb_get` | `up_to` not in conversation | `"Message <up_to> not found in conversation <id>"` |
| `kb_get` | restore yields no user/assistant messages | `"No user/assistant messages found in <id>"` |
| both | underlying exception | `str(exception)` |

## Resources

- `schema://kb` - Markdown reference for fields, filters, score bands, and
  example invocations. Useful as a system prompt addendum for agents that
  need to learn the API on the fly.
- `stats://kb` - current Qdrant URL, embedding model, and per-collection
  point counts.

## Score interpretation

Returned scores are raw cosine similarity (0-1) from the dense encoder.

| Score | Meaning |
| --- | --- |
| 0.9+ | Very high relevance, near-exact topic match. |
| 0.7-0.9 | Good match, related concepts. |
| 0.5-0.7 | Moderate match, partial relevance. |
| <0.5 | Filtered out by default; lower `min_score` to include. |

When `boost_recent=true`, scores can exceed the original cosine range by up
to `+0.2`.
