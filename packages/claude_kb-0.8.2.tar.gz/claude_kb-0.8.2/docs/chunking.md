# Chunking Rationale

## Strategy

**One Claude Code message, one Qdrant point. No sub-message chunking.**

Implemented in `import_claude.py` (`parse_session_file`, `_upload_batch_async`):

- Each line of a Claude Code session JSONL produces at most one point.
- The point ID is the Claude Code message UUID, so retrieval round-trips
  cleanly with `kb_get`.
- If `message.content` is a list of content blocks (text + `tool_use` +
  `tool_result` + `thinking`), the list is JSON-serialised before embedding,
  preserving the structure as text.
- Each message is classified into a `primary_content_type` (one of `prose`,
  `tool_use`, `tool_result`, `thinking`, `mixed`, `empty`) and that tag is
  stored in the qdrant payload. The default search filter uses this to
  exclude `tool_result` and `thinking` blocks from results unless the caller
  opts in. Embeddings are still computed from the full content - the filter
  only affects what's returned.

## Why messages are the right unit

1. **The data already has the boundary.** Each Claude Code message has a
   UUID, a role, a timestamp, a `parentUuid`, and a `sessionId`. There is no
   ambiguity about where one unit ends and the next begins, and that
   boundary is stable across every importer Claude Code has shipped.
2. **The retrieval contract demands message IDs.** `kb_search` returns
   message UUIDs that an agent fetches via `kb_get`. If we chunked, every
   retrieval result would have to either return chunk IDs (breaking the
   round-trip with `kb_get`) or de-chunk by message ID at retrieval time
   (re-introducing the boundary problem on the read side).
3. **Tool calls and thinking belong with their message.** Splitting a single
   assistant turn into separate "text", "tool_use", and "tool_result"
   chunks would isolate a tool call from the question that triggered it and
   from the result that came back. Those three blocks are useful together
   and uninformative apart.
4. **The unit a human asks for is the message.** The most common retrieval
   intent on this data is "the message where I figured out X" or "the turn
   where Claude proposed Y". Sub-message chunks force the user to assemble
   that mental model from fragments.

## What we lose, and why we accept it

- **No window-overlap recall.** Long-form prose chunked with a sliding
  window would catch a query that hits the middle of one chunk and the
  start of the next. Single-message points cannot. Acceptable because
  Claude Code messages skew short (~47 words median).
- **Long messages get embedded as one vector.** Messages longer than the
  dense encoder's context window (BGE-base: 512 tokens) get truncated by the
  encoder. Acceptable because messages past ~2000 characters in this corpus
  are usually tool-result dumps that the default search filter excludes
  anyway.
- **Conversation-level questions need a re-aggregation step.** "What did we
  decide in this whole thread?" is answered by `group_by_conversation=True`
  in `kb_search` (which builds `ConversationSummary` objects from message
  hits) or by `kb_get(conversation_id=...)` (which restores the full
  transcript). Both are post-hoc aggregations rather than thread-level
  embeddings.

## Alternatives considered and rejected

| Alternative | Why rejected |
| --- | --- |
| **Turn pairs** (one user + next assistant message) | Doubles point count, breaks single-message retrieval, no clear semantic win. The two messages share context but are still separate retrieval units in practice. |
| **Sliding window over message text** (e.g. 512-token chunks with 64-token overlap) | Optimised for long-form prose. Claude Code corpora are mostly short messages and tool-heavy turns, where window overlap adds duplicate noise to the index without recovering useful recall. |
| **Per-content-block split** (one point per text / tool_use / tool_result / thinking block) | 5-10x index inflation, breaks the causal link between a tool_use and its tool_result, and forces the search layer to invent a re-stitching step the agent already gets for free from `kb_get`. |
| **Conversation-level embeddings** (one point per session) | Loses the per-message addressability the MCP tools depend on. Useful as a *secondary* index but not as the primary one. |

## When this would change

If the corpus shifted toward genuinely long-form documents (e.g. ingesting
design docs, RFCs, or Markdown notes alongside chats), the natural fix is a
content-type-aware chunker:

- Chats: keep one-message-per-point.
- Long-form docs: section- or heading-based chunks with a parent document
  pointer.

That hybrid would justify a per-collection schema change. Today, with a
chat-only corpus, it is not worth the complexity.

## Source

- `src/claude_kb/import_claude.py` - `parse_session_file`,
  `_upload_batch_async`.
- `src/claude_kb/db.py` - `EmbeddingModel`, `classify_content_type`.
