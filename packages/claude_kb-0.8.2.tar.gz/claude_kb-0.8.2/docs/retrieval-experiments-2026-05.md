# Retrieval improvement experiments (2026-05)

Five experiments run against `conversations_hybrid_bm25` (685,675 messages, 28 hand-graded queries, conversation-level grading at k=10, `min_score=0.0`, recency boost off). Goal: figure out whether hybrid retrieval can be made to beat dense-only on this corpus, or whether dense-only BGE-base is the natural ceiling.

**Verdict: dense-only BGE-base 768d is the ceiling.** None of the five levers improved Recall@10 enough to justify keeping. One produced a modest MRR gain. Two SOTA model swaps (bge-m3 1024d, Qwen3-Embedding-8B 1024d) regressed Recall by 0.18-0.22 each — the corpus shape (short-form English code-conversation messages) is the constraint, not the encoder.

## Baseline (start of experiments)

| Mode | Recall@10 | MRR@10 |
| --- | ---: | ---: |
| **dense-only (BGE-base 768d)** | **0.502** | **0.591** |
| hybrid (RRF dense + BM25) | 0.418 | 0.505 |
| sparse-only (BM25) | ~0.317 | 0.396 |

Dense-only already wins by 0.084 Recall@10 over hybrid before any change.

## Experiments

### Step 1: BM25 hyperparameter tuning — REJECTED (-0.099 sparse)

**Hypothesis**: fastembed's `Qdrant/bm25` defaults (`avg_len=256, disable_stemmer=False`) are tuned for English web prose. Our corpus averages 47 words per message after `extract_sparse_text` cleanup; disabling the stemmer should preserve code identifiers (`get_collection` ≠ `getCollections` after a stemmer collapse).

**Setup**: `conversations_hybrid_bm25_tuned` rebuilt with `avg_len=47, disable_stemmer=True`. Same source documents, same dense vectors copied verbatim.

**Result**:

| Mode | Baseline (default BM25) | Tuned | Δ |
| --- | ---: | ---: | ---: |
| sparse-only | ~0.317 | **0.218** | **-0.099** |
| hybrid factor=3 | 0.418 | 0.383 | -0.035 |
| hybrid factor=30 | 0.427 | 0.395 | -0.032 |

**Why it failed**: disabling the stemmer hurts English-prose query recall (`searching` no longer matches `search`) more than it helps code-identifier matching. The avg_len=47 also strongly penalises longer documents, which is the wrong tail to penalize for our query mix. The corpus benefits from the stemmer despite being code-heavy.

**Decision**: revert. fastembed defaults stand.

### Step 2: RRF prefetch pool size — KEEP factor=30

**Hypothesis**: `prefetch_limit = limit * 3 = 30` per arm caps the RRF candidate pool too tight. Recall@100 (0.737 hybrid) shows headroom inside a wider pool. Larger pools may surface dense/sparse single-arm wins that fusion currently misses at rank 30+.

**Setup**: pure query-time change, no migration. `--prefetch-factor 3, 10, 30`.

**Result** (hybrid mode on `conversations_hybrid_bm25`):

| factor | Recall@10 | MRR@10 |
| --- | ---: | ---: |
| 3 (default) | 0.418 | 0.505 |
| 10 | 0.418 | 0.510 |
| 30 | **0.427** | **0.529** |

**Why mixed**: Recall barely moves (+0.009) — the right docs already make the top-30. MRR climbs +0.024 — fusion is reranking better when given more material. Below the +0.02 Recall keep gate, but the MRR lift is real and the cost is one extra parameter.

**Decision**: keep `prefetch_factor=30` as the default for hybrid mode. Marginal but free.

### Step 3a: bge-m3 dense (1024d) replacing BGE-base — REJECTED HARD (-0.186)

**Hypothesis**: bge-m3 is a SOTA multilingual long-context (8K) model often paired with hybrid systems that beat dense-only. Worth swapping in to test the ceiling.

**Setup**: deployed `BAAI/bge-m3` on a HuggingFace Inference Endpoint A10G in eu-west-1 with the official TEI image (compute cap 8.6 build), migrated all 685k points re-encoding dense via the endpoint, copied BM25 sparse vectors verbatim from the source. New collection `conversations_hybrid_bgem3` with 1024d dense + IDF-modifier sparse.

**Result**:

| Mode | Baseline (BGE-base) | bge-m3 | Δ |
| --- | ---: | ---: | ---: |
| dense-only | 0.502 | **0.316** | **-0.186** |
| sparse (BM25, copied verbatim) | 0.317 | 0.317 | 0.000 |
| hybrid factor=3 | 0.418 | 0.328 | -0.090 |
| hybrid factor=30 | 0.427 | 0.342 | -0.085 |

**Why it failed**: bge-m3's multilingual training and longer-context optimization don't match a short-form English code-conversation corpus. BGE-base is English-only and tuned for ~512-token documents — closer to our actual document distribution. The sparse arm matching baseline (0.317 = 0.317) is a clean sanity check that the migration pipeline preserved the BM25 vectors correctly; the regression is entirely on the dense swap.

**Decision**: stop. Per-plan gate said abort if dense regresses by >0.02; we regressed by 0.186. bge-m3 sparse cannot recover that deficit, so Step 3b is not worth running.

### Step 3b: bge-m3 sparse — INFRASTRUCTURE BUILT, NOT RUN

**Why prepared anyway**: the user wanted Step 3b infrastructure ready in parallel with Step 3a. After Step 3a's hard failure, running 3b was waste — even if bge-m3 sparse contributed +0.10 (which it almost certainly wouldn't), it cannot recover -0.186 dense.

**What was built** (kept on branch for future reuse with a different model):
- `docker/bge-m3-sparse/` — FastAPI server wrapping `BGEM3FlagModel` with `/embed`, `/embed_sparse`, `/embed_all` routes. TEI does not expose bge-m3's `lexical_weights` head ("not a SPLADE pooling model" 424 error), so a custom container was the only path. Image at `ghcr.io/tenequm/bge-m3-sparse:0.1.2` (public).
- `kb migrate-sparse-bgem3` CLI command — creates `conversations_hybrid_bgem3_v2` with bge-m3 dense (copied) + bge-m3 sparse (no `Modifier.IDF` — bge-m3 emits IDF-weighted lexical weights directly), resumable, parallel via ThreadPoolExecutor.
- `--use-bge-m3-sparse` flag on `scripts/run_eval.py` — query-time bge-m3 sparse encoding via the custom endpoint.

The custom-container Dockerfile required pinning `transformers<5` and bumping the pytorch base image to `2.6.0-cuda12.4-cudnn9-runtime` (transformers refuses to load `.bin` weights with torch <2.6 since CVE-2025-32434).

### Step 4: Qwen3-Embedding-8B (1024d Matryoshka via OpenRouter) — REJECTED HARD (-0.18 to -0.22)

Added after the first three experiments to test whether a SOTA decoder-based embedding model
could finally beat BGE-base. It cannot.

**Setup**: deployed via `qwen/qwen3-embedding-8b` on OpenRouter (`provider: {data_collection: deny, quantizations: [unknown, fp16, bf16]}`), 685k messages re-encoded into `conversations_dense_qwen3_1024` (1024d Matryoshka-truncated client-side, L2-normalized). Migration sharded across 6 parallel processes via SHA256-bucket on point ID, peak ~1700 docs/s on the cold cache. Long-tail docs capped at 30k chars to fit qwen3's 40,960-token context.

Three eval variants tested for the query side:

| Setup | Recall@10 | MRR@10 | Δ vs BGE-base |
| --- | ---: | ---: | ---: |
| **BGE-base baseline (current production)** | **0.479** | **0.578** | — |
| Qwen3, no instruction prefix | 0.256 | 0.302 | -0.223 |
| Qwen3, custom instruction (software-engineering) | 0.299 | 0.399 | -0.180 |
| Qwen3, canonical instruction (web-search retrieval) | 0.257 | 0.414 | -0.222 |

**What the instruction prefix did**: bumped MRR by +0.10 (better top-3 ordering) but Recall@10 stayed flat. The model finds the *same* docs whether you instruct it or not, just ranks them slightly better when you do.

**Why it failed**: same shape as bge-m3 — Qwen3 is a multilingual long-context decoder model trained for cross-lingual retrieval and document-level RAG. Our corpus is short-form English code conversation. BGE-base's English-only 512-token-document training is a structural fit; Qwen3's training distribution is not.

**Decision**: drop. Same conclusion as bge-m3, with stronger evidence: even a much bigger, more recent model that needed `>$5 of OpenRouter spend` to test fails to beat the 110M-param baseline. The corpus shape is the constraint, not the encoder size.

## What's now in the codebase from this work

This branch (`feat/measured-retrieval-and-docs`) carries only the measurement and the dense-only conclusion. None of the experimental code is shipped:

- No `BgeM3Model` / `Qwen3EmbeddingModel` classes.
- No `migrate-dense-bgem3` / `migrate-sparse-bgem3` / `migrate-dense-qwen3` CLI commands.
- No `--use-bge-m3` / `--use-qwen3` / `--prefetch-factor` eval flags.
- No `docker/bge-m3-sparse/` container, no `scripts/run_all_evals.sh` runner.

The full experimental code (model classes, migration commands, eval flags) was developed on the parent `feat/retrieval-improvements` branch during this work. That branch is kept locally as a reference for anyone reproducing the experiments; it is not merged to main and is not the source of the production behaviour.

Cleaned up after experiments (resources, not code):
- Qdrant collections `conversations_hybrid_bm25_tuned`, `conversations_hybrid_bgem3`, `conversations_dense_qwen3_1024` dropped.
- HF endpoints `bge-m3-test`, `bge-m3-sparse`, `qwen3-emb-8b`, `qwen3-embedding-8b-gguf-ezg` torn down.
- Docker image `ghcr.io/tenequm/bge-m3-sparse:0.1.2` left on ghcr.io public for future reference.

Production retrieval uses `conversations_hybrid` (BGE-base 768d dense; sparse vector slot reserved in schema but not populated or queried). The default `prefetch_factor=3` is unchanged from upstream qdrant defaults; the +0.024 MRR gain at `factor=30` was deemed too marginal to justify a custom knob given the dense-only path is the production default.

## Final answer to the question that drove this work

**"Can hybrid retrieval beat dense-only on this corpus?"**

No, not with any of the levers tested. Dense-only BGE-base 768d is the ceiling at Recall@10 = 0.502. Hybrid plateaus at 0.427 because the BM25 arm pulls in lexically-similar but topically-irrelevant docs faster than RRF fusion can promote the dense-arm wins to the top.

Things that might still move the needle (not tested here):
- Cross-encoder reranker tuned on this corpus (the off-the-shelf MS-MARCO MiniLM is net-negative — confirmed earlier in the session).
- voyage-code-3 dense (paid API, code-tuned).
- Query-side classifier that routes lexical queries to sparse and semantic queries to dense.
- Rewriting eval queries until they match what BM25 should be able to find — but that's gaming the metric, not improving retrieval.

None are in the current scope. Recommendation: ship dense-only as the default mode, keep the hybrid pipeline as opt-in with `prefetch_factor=30`, and revisit if the corpus shape changes meaningfully.
