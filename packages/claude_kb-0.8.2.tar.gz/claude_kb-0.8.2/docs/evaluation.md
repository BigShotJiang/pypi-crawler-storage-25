# Retrieval Evaluation

## Status

Measured on the maintainer's corpus (~690k messages in `conversations_hybrid`), 20 hand-graded queries spread across five categories: bug fixing, design discussion, configuration, refactoring, library/API lookup. Grading is at the *conversation* level (a query is satisfied if any message from a relevant conversation appears in the top-k) using cross-phrasing - the discovery phrasing used to identify relevant conversations differs from the evaluation phrasing the harness runs. This breaks the selection-bias loop that inflated the previous self-graded numbers.

The query strings and the relevant-conversation UUIDs are committed in [`tests/eval/queries.jsonl`](../tests/eval/queries.jsonl); no private content is included. The harness will not fabricate metrics for ungraded queries.

The deep-dive `docs/retrieval-experiments-2026-05.md` documents an expanded 28-query test (20 abstract cross-phrased + 8 identifier-style) used to evaluate five experimental hybrid- and encoder-replacement configurations against this baseline.

## Headline

20 queries, k=10, `min_score=0.0`, recency boost off, content-type filter on (default - excludes `tool_result` and `thinking` blocks):

| Mode | Recall@10 | MRR@10 |
| --- | ---: | ---: |
| **dense-only, filter on (production default)** | **0.368** | **0.397** |
| dense-only, filter on, recency boost on | 0.368 | 0.440 |
| dense-only, filter off (--include-tool-results --include-thinking) | 0.361 | 0.389 |

Filter contribution on this query set: +0.007 Recall@10, +0.008 MRR@10. Modest because the 20-query set is mostly abstract queries where tool/thinking exclusion has smaller marginal value. On the expanded 28-query set tested during this session's encoder-replacement experiments (which adds 8 identifier-style queries like `_get_best_collection function`, `Modifier.IDF qdrant sparse vectors`), dense-only with filter on measured Recall@10 = 0.479 - see [retrieval-experiments-2026-05.md](retrieval-experiments-2026-05.md) for the full table.

Recency boost lifts MRR@10 by +0.043 on this set (top-3 quality improves; raw recall is unchanged).

## Rejected paths

Five hybrid- and encoder-replacement experiments, all rejected. Detail per experiment is in [retrieval-experiments-2026-05.md](retrieval-experiments-2026-05.md); the table here is the summary used to justify the dense-only default.

| Lever | Δ Recall@10 vs dense-only | Decision |
| --- | ---: | --- |
| BM25 hyperparameter tuning (avg_len=47, no stemmer) | -0.099 sparse-only | reject |
| RRF prefetch_factor 30 vs 3 | +0.009 (MRR +0.024) | marginal, parameter retained |
| bge-m3 dense (1024d via TEI A10G HF endpoint) | -0.186 dense | reject |
| bge-m3 sparse via custom container | not tested - 3a gate failed | gated |
| Qwen3-Embedding-8B (1024d Matryoshka via OpenRouter) | -0.223 (-0.180 with retrieval-task instruction prefix) | reject |

The corpus shape (short-form English code-conversation messages, ~47 words/doc median) is the constraint, not the encoder. Bigger SOTA decoder-based encoders trained on multilingual long-context retrieval do not transfer.

## Methodology

### Why conversation-level grading

The previous version of this eval graded against individual message UUIDs picked from the observed top-10 results. Recall@10 was being measured against the same retrieval the metric was supposed to evaluate, so it was guaranteed to look good.

A conversation is a coarser unit (typically hundreds of messages) and is hard to "accidentally hit" - if a query lands in a relevant conversation, that's a meaningful retrieval event. A query is satisfied if **any** message from a relevant conversation appears in the top-k.

### Why cross-phrasing

For each query intent, two phrasings are written: a *discovery* phrasing used to identify candidate relevant conversations, and an *evaluation* phrasing used by the harness. The two are deliberately different (different word choices, sometimes different framings of the same intent). Examples from `tests/eval/queries.jsonl`:

| Discovery (used during grading) | Evaluation (run by harness) |
| --- | --- |
| 429 rate limit retry-after exponential backoff | throttling 429 errors with retry policy |
| docker compose containers volumes ports | container orchestration setup for local dev |
| github actions workflow yaml configuration | continuous integration pipeline setup |
| pydantic model validation field | schema validation with pydantic models |
| click cli argument parser command | wiring up python command-line entry points |

The harness scores how well the eval phrasing recovers the conversations that the discovery phrasing identified. Residual bias: a relevant conversation the discovery phrasing missed is not graded. There is no escape from this without a larger external rater.

### Categories

20 queries, 4 per category:

- **Bug fixing**: test failures, merge conflicts, rate-limit handling, type errors
- **Design discussion**: trade-offs, system design, rewrite-vs-refactor, API shape
- **Configuration**: docker, CI, env vars, linter
- **Refactoring**: function breakdown, extracting helpers, renames, dead-code removal
- **Library/API lookup**: async http, vector DB, pydantic, click CLI

### Metrics

| Metric | Definition |
| --- | --- |
| Recall@10 | fraction of relevant *conversations* whose any message appears in the top 10 |
| MRR@10 | reciprocal rank of the first message belonging to any relevant conversation |
| Precision@5 | per-query only (table column); not in the headline because under sparse grading it has a `min(1, |relevant|/5)` ceiling that biases the average |

### Two real bugs surfaced

1. `QdrantDB.has_sparse_vectors()` (`src/claude_kb/db.py`) inspects the dense `vectors` config for a `"sparse"` key. It always returns False, so every "hybrid" query in earlier iterations silently fell through to dense-only retrieval. Left as-is on this branch: the bug is harmless because production is dense-only by design, and fixing it would re-enable a code path the rejected-paths analysis showed is net-negative on this corpus.
2. `min_score=0.5` (the kb default) is a cosine threshold for dense search, but RRF-fusion scores cap at roughly `2/61 ≈ 0.033`. Combined with bug 1, hybrid retrieval at the default threshold would return almost nothing. The eval below uses `--min-score 0.0` to compare pure ranking quality across modes; the production default is dense-only so the cosine threshold is correct for production.

## Run the harness

Prerequisite: a populated Qdrant collection (`docker compose up -d` and `kb import-claude-code-chats`).

```bash
uv run python scripts/run_eval.py --min-score 0.0 --no-boost-recent
```

The harness exposes `--include-tool-results` and `--include-thinking` flags to disable the default content-type filter for ablation. Production search is dense-only; the rejected-path measurements (hybrid, sparse, alternate encoders) live in [retrieval-experiments-2026-05.md](retrieval-experiments-2026-05.md) for reproducibility.

If every query is ungraded the harness prints `ungraded, N queries pending hand-grading` and exits 0. No fake numbers.

## Re-grade against your own corpus

The 20 query strings are generic; the conversation IDs are tied to the maintainer's local corpus and will not match yours. To re-run on your imported data:

1. For each query in `tests/eval/queries.jsonl`, run `kb search "<discovery phrasing from the notes>"` (or pick your own).
2. Identify the 2-5 conversations whose contents are genuinely about the topic - take their conversation IDs.
3. Replace the `relevant_conversation_ids` array.
4. Re-run the harness with the eval phrasing already in the file.

A small set (2-5 IDs per query) is sufficient. Conversation-level grading is forgiving compared to per-message grading.

## What is measured today, beyond retrieval ranking

- **Compact-mode token reduction** (`CHANGELOG.md` `[0.7.0]`): MCP responses shrink 29% on average, up to 86% on assistant messages, vs. the pre-compact response shape. Methodology: per-response `tiktoken` count over the same query set in dev.
- **Restore-mode unit tests** (`tests/test_search_service.py`): edge cases for `up_to` truncation, `max_messages` capping, role filtering, `tool_use` / `thinking` block stripping in restored conversations.
- **Content-type classifier tests** (`tests/test_content_type.py`): asserts the `primary_content_type` classifier produces the right tag for plain strings, text-only blocks, tool_use, tool_result, thinking, mixed, JSON-stringified lists, and empty/malformed input.

Run them with `uv run pytest -q`.

## Reproducibility note

The author's KB is private, so the specific numbers above are measured against a corpus nobody else can rerun against. The methodology, the harness, the query strings, and the cross-phrasing notes are all in the repo and can be re-applied to anyone else's imported corpus. To support a publishable benchmark, the next step is to build a small synthetic or public-corpus query set; out of scope for this iteration.
