#!/usr/bin/env python3
"""Retrieval evaluation harness for claude-kb.

Loads a JSONL query set, runs each query through SearchService, and reports
Recall@10 and MRR@10 against hand-graded relevant *conversation* IDs. Per-query
Precision@5 is shown in the table for reference but is not in the headline -
under sparse grading it has a ceiling of |relevant|/5 that makes the average
misleading.

A query is satisfied if any message from a relevant conversation appears in the
top-k. Conversation-level grading defeats most of the message-level selection
bias, since conversations are coarse units retrieval cannot 'accidentally' hit.

Usage:
    uv run python scripts/run_eval.py
    uv run python scripts/run_eval.py --no-boost-recent --min-score 0.3
    uv run python scripts/run_eval.py --include-tool-results --include-thinking

Query file format (JSONL, one object per line):
    {
      "id": "q-001",
      "query": "git merge conflict resolution",
      "relevant_conversation_ids": ["conv-uuid-a", "conv-uuid-b"]
    }

Queries with an empty `relevant_conversation_ids` array are counted as ungraded
and excluded from metric averages.

The harness does not fabricate metrics. If every query is ungraded the
metrics line reads "ungraded, N queries pending" and exits 0.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))

from claude_kb.models import ErrorResult, SearchResult  # noqa: E402
from claude_kb.search import SearchService  # noqa: E402


@dataclass
class Query:
    id: str
    query: str
    relevant_ids: set[str]

    @property
    def graded(self) -> bool:
        return bool(self.relevant_ids)


def load_queries(path: Path) -> list[Query]:
    queries: list[Query] = []
    with path.open() as fh:
        for line_num, raw in enumerate(fh, 1):
            raw = raw.strip()
            if not raw or raw.startswith("//"):
                continue
            data = json.loads(raw)
            queries.append(
                Query(
                    id=data.get("id", f"q-{line_num}"),
                    query=data["query"],
                    relevant_ids=set(data.get("relevant_conversation_ids", [])),
                )
            )
    return queries


def metrics_for(retrieved_conv_ids: list[str], relevant: set[str], k: int) -> dict[str, float]:
    """Compute Recall@k (unique relevant conversations found), Precision@k/2 (per-slot),
    and MRR@k (rank of first hit) for one query."""
    top_k = retrieved_conv_ids[:k]
    top_5 = retrieved_conv_ids[: max(1, k // 2)]

    found_unique = {cid for cid in top_k if cid in relevant}
    recall = len(found_unique) / len(relevant) if relevant else 0.0

    hits_5 = sum(1 for cid in top_5 if cid in relevant)
    precision_5 = hits_5 / len(top_5) if top_5 else 0.0

    rr = 0.0
    for rank, cid in enumerate(top_k, 1):
        if cid in relevant:
            rr = 1.0 / rank
            break

    return {"recall": recall, "precision_5": precision_5, "mrr": rr}


def run(args: argparse.Namespace) -> int:
    queries_path = Path(args.queries)
    if not queries_path.exists():
        print(f"Query file not found: {queries_path}", file=sys.stderr)
        return 2

    queries = load_queries(queries_path)
    if not queries:
        print(f"No queries found in {queries_path}", file=sys.stderr)
        return 2

    graded = [q for q in queries if q.graded]
    ungraded = [q for q in queries if not q.graded]

    service = SearchService()

    rows: list[tuple[Query, dict[str, float]]] = []
    for q in graded:
        result = service.search(
            query=q.query,
            limit=max(args.k, 10),
            min_score=args.min_score,
            boost_recent=args.boost_recent,
            include_tool_results=args.include_tool_results,
            include_thinking=args.include_thinking,
        )
        if isinstance(result, ErrorResult):
            print(f"[{q.id}] error: {result.error}", file=sys.stderr)
            continue
        assert isinstance(result, SearchResult)
        retrieved = [m.conversation_id or "" for m in result.results]
        rows.append((q, metrics_for(retrieved, q.relevant_ids, args.k)))

    print("# claude-kb retrieval evaluation\n")
    print(f"queries file: `{queries_path}`")
    print(f"queries total: {len(queries)} (graded: {len(graded)}, ungraded: {len(ungraded)})")
    print(
        f"settings: k={args.k}, min_score={args.min_score}, "
        f"boost_recent={args.boost_recent}, "
        f"include_tool_results={args.include_tool_results}, "
        f"include_thinking={args.include_thinking}\n"
    )

    if not rows:
        print(f"ungraded, {len(ungraded)} queries pending hand-grading")
        return 0

    print("| id | query | recall@k | precision@5 | rr |")
    print("| --- | --- | ---: | ---: | ---: |")
    for q, m in rows:
        print(
            f"| {q.id} | {q.query[:50]} | {m['recall']:.2f} | "
            f"{m['precision_5']:.2f} | {m['mrr']:.2f} |"
        )

    avg_recall = sum(m["recall"] for _, m in rows) / len(rows)
    avg_mrr = sum(m["mrr"] for _, m in rows) / len(rows)

    print(
        f"\n**Recall@{args.k}**: {avg_recall:.3f}  "
        f"**MRR@{args.k}**: {avg_mrr:.3f}  "
        f"({len(rows)} graded queries)"
    )
    if ungraded:
        print(f"\n_ungraded: {len(ungraded)} queries pending hand-grading_")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--queries", default="tests/eval/queries.jsonl")
    parser.add_argument("--k", type=int, default=10, help="cutoff for Recall@k and MRR@k")
    parser.add_argument("--min-score", type=float, default=0.5)
    parser.add_argument(
        "--boost-recent",
        dest="boost_recent",
        action="store_true",
        default=True,
        help="enable recency boost (default)",
    )
    parser.add_argument(
        "--no-boost-recent",
        dest="boost_recent",
        action="store_false",
        help="disable recency boost",
    )
    parser.add_argument(
        "--include-tool-results",
        dest="include_tool_results",
        action="store_true",
        default=False,
        help="don't filter out tool_result messages (default: filter)",
    )
    parser.add_argument(
        "--include-thinking",
        dest="include_thinking",
        action="store_true",
        default=False,
        help="don't filter out thinking messages (default: filter)",
    )
    args = parser.parse_args()
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
