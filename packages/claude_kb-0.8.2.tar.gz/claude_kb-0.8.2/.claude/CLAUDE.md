# claude-kb Project Instructions

## Commit Format

Always use Conventional Commits format:
- `feat:` new feature
- `fix:` bug fix
- `docs:` documentation only
- `refactor:` code change that neither fixes a bug nor adds a feature
- `chore:` maintenance tasks (deps, build, etc.)
- `test:` adding or updating tests

Examples:
```
feat: add streaming search mode
fix: handle empty query gracefully
docs: update installation instructions
chore: bump version to 0.2.0
```

## Release Process

Run from `main` after the feature PR is merged.

1. **Bump version** (see "Version Bumping" below for the right bump type)
   ```bash
   uv version --bump <patch|minor|major>
   ```

2. **Update CHANGELOG.md**
   - Rename `[Unreleased]` to the new version with a release date
   - Add a fresh empty `[Unreleased]` section above it
   - Add comparison link at the bottom; update the `[Unreleased]` link to point at the new version

3. **Commit and push**
   ```bash
   git add -A && git commit -m "chore: release X.Y.Z" && git push origin main
   ```

4. **Build artifacts**
   ```bash
   rm -rf dist/ && uv build
   ```

5. **Create GitHub Release** (the tag is created by `gh release create`)
   ```bash
   # extract just this version's notes, not the full changelog
   awk '/^## \[X.Y.Z\]/{flag=1; next} flag && /^## \[/{exit} flag' CHANGELOG.md > /tmp/release_notes.md
   gh release create vX.Y.Z --title "vX.Y.Z" --notes-file /tmp/release_notes.md \
     dist/claude_kb-X.Y.Z.tar.gz dist/claude_kb-X.Y.Z-py3-none-any.whl
   ```

6. **Publish to PyPI**
   ```bash
   uv publish   # picks up UV_PUBLISH_TOKEN from env
   ```

7. **Verify**
   ```bash
   curl -s https://pypi.org/pypi/claude-kb/json | python3 -c "import sys, json; print(json.load(sys.stdin)['info']['version'])"
   uv tool upgrade claude-kb && kb --version
   ```

## Version Bumping

Use uv to bump versions:
```bash
uv version --bump patch  # 0.1.0 -> 0.1.1
uv version --bump minor  # 0.1.0 -> 0.2.0
uv version --bump major  # 0.1.0 -> 1.0.0
```

## Development

- Run `uv sync --extra dev` for development dependencies
- Run `just check` for linting and formatting
- Run `kb ai` before using kb commands to see AI-optimized help
