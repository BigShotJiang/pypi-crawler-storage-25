"""Tests for container plugin."""
