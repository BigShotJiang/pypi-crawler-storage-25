from coordinode.v1.common import types_pb2 as _types_pb2
from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExecuteCypherRequest(_message.Message):
    __slots__ = ("query", "parameters")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _types_pb2.PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_types_pb2.PropertyValue, _Mapping]] = ...) -> None: ...
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    query: str
    parameters: _containers.MessageMap[str, _types_pb2.PropertyValue]
    def __init__(self, query: _Optional[str] = ..., parameters: _Optional[_Mapping[str, _types_pb2.PropertyValue]] = ...) -> None: ...

class ExecuteCypherResponse(_message.Message):
    __slots__ = ("columns", "rows", "stats")
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    ROWS_FIELD_NUMBER: _ClassVar[int]
    STATS_FIELD_NUMBER: _ClassVar[int]
    columns: _containers.RepeatedScalarFieldContainer[str]
    rows: _containers.RepeatedCompositeFieldContainer[Row]
    stats: QueryStats
    def __init__(self, columns: _Optional[_Iterable[str]] = ..., rows: _Optional[_Iterable[_Union[Row, _Mapping]]] = ..., stats: _Optional[_Union[QueryStats, _Mapping]] = ...) -> None: ...

class Row(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedCompositeFieldContainer[_types_pb2.PropertyValue]
    def __init__(self, values: _Optional[_Iterable[_Union[_types_pb2.PropertyValue, _Mapping]]] = ...) -> None: ...

class QueryStats(_message.Message):
    __slots__ = ("nodes_created", "nodes_deleted", "edges_created", "edges_deleted", "properties_set", "execution_time_ms")
    NODES_CREATED_FIELD_NUMBER: _ClassVar[int]
    NODES_DELETED_FIELD_NUMBER: _ClassVar[int]
    EDGES_CREATED_FIELD_NUMBER: _ClassVar[int]
    EDGES_DELETED_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_SET_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_TIME_MS_FIELD_NUMBER: _ClassVar[int]
    nodes_created: int
    nodes_deleted: int
    edges_created: int
    edges_deleted: int
    properties_set: int
    execution_time_ms: int
    def __init__(self, nodes_created: _Optional[int] = ..., nodes_deleted: _Optional[int] = ..., edges_created: _Optional[int] = ..., edges_deleted: _Optional[int] = ..., properties_set: _Optional[int] = ..., execution_time_ms: _Optional[int] = ...) -> None: ...

class ExplainCypherRequest(_message.Message):
    __slots__ = ("query", "parameters")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _types_pb2.PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_types_pb2.PropertyValue, _Mapping]] = ...) -> None: ...
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    query: str
    parameters: _containers.MessageMap[str, _types_pb2.PropertyValue]
    def __init__(self, query: _Optional[str] = ..., parameters: _Optional[_Mapping[str, _types_pb2.PropertyValue]] = ...) -> None: ...

class ExplainCypherResponse(_message.Message):
    __slots__ = ("plan",)
    PLAN_FIELD_NUMBER: _ClassVar[int]
    plan: QueryPlan
    def __init__(self, plan: _Optional[_Union[QueryPlan, _Mapping]] = ...) -> None: ...

class QueryPlan(_message.Message):
    __slots__ = ("operator", "details", "children", "estimated_rows")
    class DetailsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    CHILDREN_FIELD_NUMBER: _ClassVar[int]
    ESTIMATED_ROWS_FIELD_NUMBER: _ClassVar[int]
    operator: str
    details: _containers.ScalarMap[str, str]
    children: _containers.RepeatedCompositeFieldContainer[QueryPlan]
    estimated_rows: float
    def __init__(self, operator: _Optional[str] = ..., details: _Optional[_Mapping[str, str]] = ..., children: _Optional[_Iterable[_Union[QueryPlan, _Mapping]]] = ..., estimated_rows: _Optional[float] = ...) -> None: ...
