from coordinode.v1.common import types_pb2 as _types_pb2
from coordinode.v1.graph import graph_pb2 as _graph_pb2
from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DistanceMetric(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DISTANCE_METRIC_UNSPECIFIED: _ClassVar[DistanceMetric]
    DISTANCE_METRIC_COSINE: _ClassVar[DistanceMetric]
    DISTANCE_METRIC_L2: _ClassVar[DistanceMetric]
    DISTANCE_METRIC_DOT: _ClassVar[DistanceMetric]
    DISTANCE_METRIC_L1: _ClassVar[DistanceMetric]
DISTANCE_METRIC_UNSPECIFIED: DistanceMetric
DISTANCE_METRIC_COSINE: DistanceMetric
DISTANCE_METRIC_L2: DistanceMetric
DISTANCE_METRIC_DOT: DistanceMetric
DISTANCE_METRIC_L1: DistanceMetric

class VectorSearchRequest(_message.Message):
    __slots__ = ("label", "property", "query_vector", "top_k", "metric")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    PROPERTY_FIELD_NUMBER: _ClassVar[int]
    QUERY_VECTOR_FIELD_NUMBER: _ClassVar[int]
    TOP_K_FIELD_NUMBER: _ClassVar[int]
    METRIC_FIELD_NUMBER: _ClassVar[int]
    label: str
    property: str
    query_vector: _types_pb2.Vector
    top_k: int
    metric: DistanceMetric
    def __init__(self, label: _Optional[str] = ..., property: _Optional[str] = ..., query_vector: _Optional[_Union[_types_pb2.Vector, _Mapping]] = ..., top_k: _Optional[int] = ..., metric: _Optional[_Union[DistanceMetric, str]] = ...) -> None: ...

class VectorSearchResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[VectorResult]
    def __init__(self, results: _Optional[_Iterable[_Union[VectorResult, _Mapping]]] = ...) -> None: ...

class VectorResult(_message.Message):
    __slots__ = ("node", "distance")
    NODE_FIELD_NUMBER: _ClassVar[int]
    DISTANCE_FIELD_NUMBER: _ClassVar[int]
    node: _graph_pb2.Node
    distance: float
    def __init__(self, node: _Optional[_Union[_graph_pb2.Node, _Mapping]] = ..., distance: _Optional[float] = ...) -> None: ...

class HybridSearchRequest(_message.Message):
    __slots__ = ("start_node_id", "edge_type", "max_depth", "vector_property", "query_vector", "top_k", "metric")
    START_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    EDGE_TYPE_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPTH_FIELD_NUMBER: _ClassVar[int]
    VECTOR_PROPERTY_FIELD_NUMBER: _ClassVar[int]
    QUERY_VECTOR_FIELD_NUMBER: _ClassVar[int]
    TOP_K_FIELD_NUMBER: _ClassVar[int]
    METRIC_FIELD_NUMBER: _ClassVar[int]
    start_node_id: int
    edge_type: str
    max_depth: int
    vector_property: str
    query_vector: _types_pb2.Vector
    top_k: int
    metric: DistanceMetric
    def __init__(self, start_node_id: _Optional[int] = ..., edge_type: _Optional[str] = ..., max_depth: _Optional[int] = ..., vector_property: _Optional[str] = ..., query_vector: _Optional[_Union[_types_pb2.Vector, _Mapping]] = ..., top_k: _Optional[int] = ..., metric: _Optional[_Union[DistanceMetric, str]] = ...) -> None: ...

class HybridSearchResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[VectorResult]
    def __init__(self, results: _Optional[_Iterable[_Union[VectorResult, _Mapping]]] = ...) -> None: ...
