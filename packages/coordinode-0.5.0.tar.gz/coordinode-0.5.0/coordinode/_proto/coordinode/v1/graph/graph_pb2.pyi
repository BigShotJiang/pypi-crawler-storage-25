from coordinode.v1.common import types_pb2 as _types_pb2
from coordinode.v1.common import pagination_pb2 as _pagination_pb2
from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TraversalDirection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRAVERSAL_DIRECTION_UNSPECIFIED: _ClassVar[TraversalDirection]
    TRAVERSAL_DIRECTION_OUTBOUND: _ClassVar[TraversalDirection]
    TRAVERSAL_DIRECTION_INBOUND: _ClassVar[TraversalDirection]
    TRAVERSAL_DIRECTION_BOTH: _ClassVar[TraversalDirection]
TRAVERSAL_DIRECTION_UNSPECIFIED: TraversalDirection
TRAVERSAL_DIRECTION_OUTBOUND: TraversalDirection
TRAVERSAL_DIRECTION_INBOUND: TraversalDirection
TRAVERSAL_DIRECTION_BOTH: TraversalDirection

class Node(_message.Message):
    __slots__ = ("node_id", "labels", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _types_pb2.PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_types_pb2.PropertyValue, _Mapping]] = ...) -> None: ...
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    labels: _containers.RepeatedScalarFieldContainer[str]
    properties: _containers.MessageMap[str, _types_pb2.PropertyValue]
    def __init__(self, node_id: _Optional[int] = ..., labels: _Optional[_Iterable[str]] = ..., properties: _Optional[_Mapping[str, _types_pb2.PropertyValue]] = ...) -> None: ...

class Edge(_message.Message):
    __slots__ = ("edge_id", "edge_type", "source_node_id", "target_node_id", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _types_pb2.PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_types_pb2.PropertyValue, _Mapping]] = ...) -> None: ...
    EDGE_ID_FIELD_NUMBER: _ClassVar[int]
    EDGE_TYPE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    edge_id: int
    edge_type: str
    source_node_id: int
    target_node_id: int
    properties: _containers.MessageMap[str, _types_pb2.PropertyValue]
    def __init__(self, edge_id: _Optional[int] = ..., edge_type: _Optional[str] = ..., source_node_id: _Optional[int] = ..., target_node_id: _Optional[int] = ..., properties: _Optional[_Mapping[str, _types_pb2.PropertyValue]] = ...) -> None: ...

class CreateNodeRequest(_message.Message):
    __slots__ = ("labels", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _types_pb2.PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_types_pb2.PropertyValue, _Mapping]] = ...) -> None: ...
    LABELS_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    labels: _containers.RepeatedScalarFieldContainer[str]
    properties: _containers.MessageMap[str, _types_pb2.PropertyValue]
    def __init__(self, labels: _Optional[_Iterable[str]] = ..., properties: _Optional[_Mapping[str, _types_pb2.PropertyValue]] = ...) -> None: ...

class GetNodeRequest(_message.Message):
    __slots__ = ("node_id",)
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    def __init__(self, node_id: _Optional[int] = ...) -> None: ...

class CreateEdgeRequest(_message.Message):
    __slots__ = ("edge_type", "source_node_id", "target_node_id", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _types_pb2.PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_types_pb2.PropertyValue, _Mapping]] = ...) -> None: ...
    EDGE_TYPE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    edge_type: str
    source_node_id: int
    target_node_id: int
    properties: _containers.MessageMap[str, _types_pb2.PropertyValue]
    def __init__(self, edge_type: _Optional[str] = ..., source_node_id: _Optional[int] = ..., target_node_id: _Optional[int] = ..., properties: _Optional[_Mapping[str, _types_pb2.PropertyValue]] = ...) -> None: ...

class TraverseRequest(_message.Message):
    __slots__ = ("start_node_id", "edge_type", "direction", "max_depth", "pagination")
    START_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    EDGE_TYPE_FIELD_NUMBER: _ClassVar[int]
    DIRECTION_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPTH_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    start_node_id: int
    edge_type: str
    direction: TraversalDirection
    max_depth: int
    pagination: _pagination_pb2.PaginationRequest
    def __init__(self, start_node_id: _Optional[int] = ..., edge_type: _Optional[str] = ..., direction: _Optional[_Union[TraversalDirection, str]] = ..., max_depth: _Optional[int] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ...) -> None: ...

class TraverseResponse(_message.Message):
    __slots__ = ("nodes", "edges", "pagination")
    NODES_FIELD_NUMBER: _ClassVar[int]
    EDGES_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    nodes: _containers.RepeatedCompositeFieldContainer[Node]
    edges: _containers.RepeatedCompositeFieldContainer[Edge]
    pagination: _pagination_pb2.PaginationResponse
    def __init__(self, nodes: _Optional[_Iterable[_Union[Node, _Mapping]]] = ..., edges: _Optional[_Iterable[_Union[Edge, _Mapping]]] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationResponse, _Mapping]] = ...) -> None: ...
