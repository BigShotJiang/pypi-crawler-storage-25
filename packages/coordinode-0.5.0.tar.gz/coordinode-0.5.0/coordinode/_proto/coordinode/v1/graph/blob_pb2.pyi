from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class BlobChunk(_message.Message):
    __slots__ = ("data", "sequence")
    DATA_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    data: bytes
    sequence: int
    def __init__(self, data: _Optional[bytes] = ..., sequence: _Optional[int] = ...) -> None: ...

class UploadBlobResponse(_message.Message):
    __slots__ = ("blob_id", "chunk_ids", "total_size", "dedup_chunks")
    BLOB_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_IDS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SIZE_FIELD_NUMBER: _ClassVar[int]
    DEDUP_CHUNKS_FIELD_NUMBER: _ClassVar[int]
    blob_id: str
    chunk_ids: _containers.RepeatedScalarFieldContainer[str]
    total_size: int
    dedup_chunks: int
    def __init__(self, blob_id: _Optional[str] = ..., chunk_ids: _Optional[_Iterable[str]] = ..., total_size: _Optional[int] = ..., dedup_chunks: _Optional[int] = ...) -> None: ...

class DownloadBlobRequest(_message.Message):
    __slots__ = ("blob_id",)
    BLOB_ID_FIELD_NUMBER: _ClassVar[int]
    blob_id: str
    def __init__(self, blob_id: _Optional[str] = ...) -> None: ...

class DeleteBlobRequest(_message.Message):
    __slots__ = ("blob_id",)
    BLOB_ID_FIELD_NUMBER: _ClassVar[int]
    blob_id: str
    def __init__(self, blob_id: _Optional[str] = ...) -> None: ...

class DeleteBlobResponse(_message.Message):
    __slots__ = ("chunks_deleted",)
    CHUNKS_DELETED_FIELD_NUMBER: _ClassVar[int]
    chunks_deleted: int
    def __init__(self, chunks_deleted: _Optional[int] = ...) -> None: ...

class GetBlobMetaRequest(_message.Message):
    __slots__ = ("blob_id",)
    BLOB_ID_FIELD_NUMBER: _ClassVar[int]
    blob_id: str
    def __init__(self, blob_id: _Optional[str] = ...) -> None: ...

class BlobMeta(_message.Message):
    __slots__ = ("blob_id", "total_size", "chunk_count", "chunk_ids")
    BLOB_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SIZE_FIELD_NUMBER: _ClassVar[int]
    CHUNK_COUNT_FIELD_NUMBER: _ClassVar[int]
    CHUNK_IDS_FIELD_NUMBER: _ClassVar[int]
    blob_id: str
    total_size: int
    chunk_count: int
    chunk_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, blob_id: _Optional[str] = ..., total_size: _Optional[int] = ..., chunk_count: _Optional[int] = ..., chunk_ids: _Optional[_Iterable[str]] = ...) -> None: ...
