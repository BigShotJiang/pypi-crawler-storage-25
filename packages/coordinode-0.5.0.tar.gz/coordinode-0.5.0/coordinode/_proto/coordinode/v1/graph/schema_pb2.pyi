from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PropertyType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROPERTY_TYPE_UNSPECIFIED: _ClassVar[PropertyType]
    PROPERTY_TYPE_INT64: _ClassVar[PropertyType]
    PROPERTY_TYPE_FLOAT64: _ClassVar[PropertyType]
    PROPERTY_TYPE_STRING: _ClassVar[PropertyType]
    PROPERTY_TYPE_BOOL: _ClassVar[PropertyType]
    PROPERTY_TYPE_BYTES: _ClassVar[PropertyType]
    PROPERTY_TYPE_TIMESTAMP: _ClassVar[PropertyType]
    PROPERTY_TYPE_VECTOR: _ClassVar[PropertyType]
    PROPERTY_TYPE_LIST: _ClassVar[PropertyType]
    PROPERTY_TYPE_MAP: _ClassVar[PropertyType]
PROPERTY_TYPE_UNSPECIFIED: PropertyType
PROPERTY_TYPE_INT64: PropertyType
PROPERTY_TYPE_FLOAT64: PropertyType
PROPERTY_TYPE_STRING: PropertyType
PROPERTY_TYPE_BOOL: PropertyType
PROPERTY_TYPE_BYTES: PropertyType
PROPERTY_TYPE_TIMESTAMP: PropertyType
PROPERTY_TYPE_VECTOR: PropertyType
PROPERTY_TYPE_LIST: PropertyType
PROPERTY_TYPE_MAP: PropertyType

class Label(_message.Message):
    __slots__ = ("name", "properties", "version")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    name: str
    properties: _containers.RepeatedCompositeFieldContainer[PropertyDefinition]
    version: int
    def __init__(self, name: _Optional[str] = ..., properties: _Optional[_Iterable[_Union[PropertyDefinition, _Mapping]]] = ..., version: _Optional[int] = ...) -> None: ...

class EdgeType(_message.Message):
    __slots__ = ("name", "properties", "version")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    name: str
    properties: _containers.RepeatedCompositeFieldContainer[PropertyDefinition]
    version: int
    def __init__(self, name: _Optional[str] = ..., properties: _Optional[_Iterable[_Union[PropertyDefinition, _Mapping]]] = ..., version: _Optional[int] = ...) -> None: ...

class PropertyDefinition(_message.Message):
    __slots__ = ("name", "type", "required", "unique")
    NAME_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    UNIQUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    type: PropertyType
    required: bool
    unique: bool
    def __init__(self, name: _Optional[str] = ..., type: _Optional[_Union[PropertyType, str]] = ..., required: bool = ..., unique: bool = ...) -> None: ...

class CreateLabelRequest(_message.Message):
    __slots__ = ("name", "properties")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    name: str
    properties: _containers.RepeatedCompositeFieldContainer[PropertyDefinition]
    def __init__(self, name: _Optional[str] = ..., properties: _Optional[_Iterable[_Union[PropertyDefinition, _Mapping]]] = ...) -> None: ...

class CreateEdgeTypeRequest(_message.Message):
    __slots__ = ("name", "properties")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    name: str
    properties: _containers.RepeatedCompositeFieldContainer[PropertyDefinition]
    def __init__(self, name: _Optional[str] = ..., properties: _Optional[_Iterable[_Union[PropertyDefinition, _Mapping]]] = ...) -> None: ...

class ListLabelsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListLabelsResponse(_message.Message):
    __slots__ = ("labels",)
    LABELS_FIELD_NUMBER: _ClassVar[int]
    labels: _containers.RepeatedCompositeFieldContainer[Label]
    def __init__(self, labels: _Optional[_Iterable[_Union[Label, _Mapping]]] = ...) -> None: ...

class ListEdgeTypesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEdgeTypesResponse(_message.Message):
    __slots__ = ("edge_types",)
    EDGE_TYPES_FIELD_NUMBER: _ClassVar[int]
    edge_types: _containers.RepeatedCompositeFieldContainer[EdgeType]
    def __init__(self, edge_types: _Optional[_Iterable[_Union[EdgeType, _Mapping]]] = ...) -> None: ...
