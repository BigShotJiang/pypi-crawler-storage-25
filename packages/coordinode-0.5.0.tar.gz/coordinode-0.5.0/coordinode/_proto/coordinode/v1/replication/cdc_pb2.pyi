from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ChangeOpType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CHANGE_OP_TYPE_UNSPECIFIED: _ClassVar[ChangeOpType]
    INSERT: _ClassVar[ChangeOpType]
    DELETE: _ClassVar[ChangeOpType]
    MERGE: _ClassVar[ChangeOpType]
    NOOP: _ClassVar[ChangeOpType]
    RAFT_ENTRY: _ClassVar[ChangeOpType]
    RAFT_TRUNCATION: _ClassVar[ChangeOpType]
CHANGE_OP_TYPE_UNSPECIFIED: ChangeOpType
INSERT: ChangeOpType
DELETE: ChangeOpType
MERGE: ChangeOpType
NOOP: ChangeOpType
RAFT_ENTRY: ChangeOpType
RAFT_TRUNCATION: ChangeOpType

class ResumeToken(_message.Message):
    __slots__ = ("shard_id", "segment_id", "entry_offset")
    SHARD_ID_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_OFFSET_FIELD_NUMBER: _ClassVar[int]
    shard_id: int
    segment_id: int
    entry_offset: int
    def __init__(self, shard_id: _Optional[int] = ..., segment_id: _Optional[int] = ..., entry_offset: _Optional[int] = ...) -> None: ...

class CdcFilters(_message.Message):
    __slots__ = ("edge_types", "is_migration")
    EDGE_TYPES_FIELD_NUMBER: _ClassVar[int]
    IS_MIGRATION_FIELD_NUMBER: _ClassVar[int]
    edge_types: _containers.RepeatedScalarFieldContainer[str]
    is_migration: bool
    def __init__(self, edge_types: _Optional[_Iterable[str]] = ..., is_migration: bool = ...) -> None: ...

class SubscribeRequest(_message.Message):
    __slots__ = ("resume_token", "filters")
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    resume_token: ResumeToken
    filters: CdcFilters
    def __init__(self, resume_token: _Optional[_Union[ResumeToken, _Mapping]] = ..., filters: _Optional[_Union[CdcFilters, _Mapping]] = ...) -> None: ...

class ChangeEvent(_message.Message):
    __slots__ = ("ts", "term", "log_index", "shard_id", "is_migration", "ops", "position")
    TS_FIELD_NUMBER: _ClassVar[int]
    TERM_FIELD_NUMBER: _ClassVar[int]
    LOG_INDEX_FIELD_NUMBER: _ClassVar[int]
    SHARD_ID_FIELD_NUMBER: _ClassVar[int]
    IS_MIGRATION_FIELD_NUMBER: _ClassVar[int]
    OPS_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    ts: int
    term: int
    log_index: int
    shard_id: int
    is_migration: bool
    ops: _containers.RepeatedCompositeFieldContainer[ChangeOp]
    position: ResumeToken
    def __init__(self, ts: _Optional[int] = ..., term: _Optional[int] = ..., log_index: _Optional[int] = ..., shard_id: _Optional[int] = ..., is_migration: bool = ..., ops: _Optional[_Iterable[_Union[ChangeOp, _Mapping]]] = ..., position: _Optional[_Union[ResumeToken, _Mapping]] = ...) -> None: ...

class ChangeOp(_message.Message):
    __slots__ = ("type", "partition", "key", "value")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    PARTITION_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    type: ChangeOpType
    partition: int
    key: bytes
    value: bytes
    def __init__(self, type: _Optional[_Union[ChangeOpType, str]] = ..., partition: _Optional[int] = ..., key: _Optional[bytes] = ..., value: _Optional[bytes] = ...) -> None: ...
