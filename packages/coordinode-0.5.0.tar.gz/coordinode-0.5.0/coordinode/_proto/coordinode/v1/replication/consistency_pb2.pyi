from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WriteConcernLevel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WRITE_CONCERN_LEVEL_UNSPECIFIED: _ClassVar[WriteConcernLevel]
    WRITE_CONCERN_LEVEL_W0: _ClassVar[WriteConcernLevel]
    WRITE_CONCERN_LEVEL_W1: _ClassVar[WriteConcernLevel]
    WRITE_CONCERN_LEVEL_MAJORITY: _ClassVar[WriteConcernLevel]

class ReadConcernLevel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    READ_CONCERN_LEVEL_UNSPECIFIED: _ClassVar[ReadConcernLevel]
    READ_CONCERN_LEVEL_LOCAL: _ClassVar[ReadConcernLevel]
    READ_CONCERN_LEVEL_MAJORITY: _ClassVar[ReadConcernLevel]
    READ_CONCERN_LEVEL_LINEARIZABLE: _ClassVar[ReadConcernLevel]
    READ_CONCERN_LEVEL_SNAPSHOT: _ClassVar[ReadConcernLevel]

class ReadPreference(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    READ_PREFERENCE_UNSPECIFIED: _ClassVar[ReadPreference]
    READ_PREFERENCE_PRIMARY: _ClassVar[ReadPreference]
    READ_PREFERENCE_PRIMARY_PREFERRED: _ClassVar[ReadPreference]
    READ_PREFERENCE_SECONDARY: _ClassVar[ReadPreference]
    READ_PREFERENCE_SECONDARY_PREFERRED: _ClassVar[ReadPreference]
    READ_PREFERENCE_NEAREST: _ClassVar[ReadPreference]
WRITE_CONCERN_LEVEL_UNSPECIFIED: WriteConcernLevel
WRITE_CONCERN_LEVEL_W0: WriteConcernLevel
WRITE_CONCERN_LEVEL_W1: WriteConcernLevel
WRITE_CONCERN_LEVEL_MAJORITY: WriteConcernLevel
READ_CONCERN_LEVEL_UNSPECIFIED: ReadConcernLevel
READ_CONCERN_LEVEL_LOCAL: ReadConcernLevel
READ_CONCERN_LEVEL_MAJORITY: ReadConcernLevel
READ_CONCERN_LEVEL_LINEARIZABLE: ReadConcernLevel
READ_CONCERN_LEVEL_SNAPSHOT: ReadConcernLevel
READ_PREFERENCE_UNSPECIFIED: ReadPreference
READ_PREFERENCE_PRIMARY: ReadPreference
READ_PREFERENCE_PRIMARY_PREFERRED: ReadPreference
READ_PREFERENCE_SECONDARY: ReadPreference
READ_PREFERENCE_SECONDARY_PREFERRED: ReadPreference
READ_PREFERENCE_NEAREST: ReadPreference

class WriteConcern(_message.Message):
    __slots__ = ("level", "journal", "timeout_ms")
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    JOURNAL_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    level: WriteConcernLevel
    journal: bool
    timeout_ms: int
    def __init__(self, level: _Optional[_Union[WriteConcernLevel, str]] = ..., journal: bool = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class ReadConcern(_message.Message):
    __slots__ = ("level",)
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    level: ReadConcernLevel
    def __init__(self, level: _Optional[_Union[ReadConcernLevel, str]] = ...) -> None: ...
