from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class NodeId(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: int
    def __init__(self, id: _Optional[int] = ...) -> None: ...

class EdgeId(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: int
    def __init__(self, id: _Optional[int] = ...) -> None: ...

class HlcTimestamp(_message.Message):
    __slots__ = ("wall_time", "logical")
    WALL_TIME_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_FIELD_NUMBER: _ClassVar[int]
    wall_time: int
    logical: int
    def __init__(self, wall_time: _Optional[int] = ..., logical: _Optional[int] = ...) -> None: ...

class PropertyValue(_message.Message):
    __slots__ = ("int_value", "float_value", "string_value", "bool_value", "bytes_value", "timestamp_value", "vector_value", "list_value", "map_value")
    INT_VALUE_FIELD_NUMBER: _ClassVar[int]
    FLOAT_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    BOOL_VALUE_FIELD_NUMBER: _ClassVar[int]
    BYTES_VALUE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_VALUE_FIELD_NUMBER: _ClassVar[int]
    VECTOR_VALUE_FIELD_NUMBER: _ClassVar[int]
    LIST_VALUE_FIELD_NUMBER: _ClassVar[int]
    MAP_VALUE_FIELD_NUMBER: _ClassVar[int]
    int_value: int
    float_value: float
    string_value: str
    bool_value: bool
    bytes_value: bytes
    timestamp_value: HlcTimestamp
    vector_value: Vector
    list_value: PropertyList
    map_value: PropertyMap
    def __init__(self, int_value: _Optional[int] = ..., float_value: _Optional[float] = ..., string_value: _Optional[str] = ..., bool_value: bool = ..., bytes_value: _Optional[bytes] = ..., timestamp_value: _Optional[_Union[HlcTimestamp, _Mapping]] = ..., vector_value: _Optional[_Union[Vector, _Mapping]] = ..., list_value: _Optional[_Union[PropertyList, _Mapping]] = ..., map_value: _Optional[_Union[PropertyMap, _Mapping]] = ...) -> None: ...

class Vector(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, values: _Optional[_Iterable[float]] = ...) -> None: ...

class PropertyList(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedCompositeFieldContainer[PropertyValue]
    def __init__(self, values: _Optional[_Iterable[_Union[PropertyValue, _Mapping]]] = ...) -> None: ...

class PropertyMap(_message.Message):
    __slots__ = ("entries",)
    class EntriesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: PropertyValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[PropertyValue, _Mapping]] = ...) -> None: ...
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.MessageMap[str, PropertyValue]
    def __init__(self, entries: _Optional[_Mapping[str, PropertyValue]] = ...) -> None: ...
