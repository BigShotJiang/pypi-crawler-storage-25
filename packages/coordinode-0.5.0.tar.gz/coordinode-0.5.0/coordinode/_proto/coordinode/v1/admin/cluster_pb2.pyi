from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class NodeRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NODE_ROLE_UNSPECIFIED: _ClassVar[NodeRole]
    NODE_ROLE_LEADER: _ClassVar[NodeRole]
    NODE_ROLE_FOLLOWER: _ClassVar[NodeRole]
    NODE_ROLE_LEARNER: _ClassVar[NodeRole]

class NodeState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NODE_STATE_UNSPECIFIED: _ClassVar[NodeState]
    NODE_STATE_HEALTHY: _ClassVar[NodeState]
    NODE_STATE_DEGRADED: _ClassVar[NodeState]
    NODE_STATE_DOWN: _ClassVar[NodeState]
NODE_ROLE_UNSPECIFIED: NodeRole
NODE_ROLE_LEADER: NodeRole
NODE_ROLE_FOLLOWER: NodeRole
NODE_ROLE_LEARNER: NodeRole
NODE_STATE_UNSPECIFIED: NodeState
NODE_STATE_HEALTHY: NodeState
NODE_STATE_DEGRADED: NodeState
NODE_STATE_DOWN: NodeState

class GetClusterStatusRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ClusterStatus(_message.Message):
    __slots__ = ("nodes", "leader_id", "raft_term")
    NODES_FIELD_NUMBER: _ClassVar[int]
    LEADER_ID_FIELD_NUMBER: _ClassVar[int]
    RAFT_TERM_FIELD_NUMBER: _ClassVar[int]
    nodes: _containers.RepeatedCompositeFieldContainer[ClusterNode]
    leader_id: str
    raft_term: int
    def __init__(self, nodes: _Optional[_Iterable[_Union[ClusterNode, _Mapping]]] = ..., leader_id: _Optional[str] = ..., raft_term: _Optional[int] = ...) -> None: ...

class ClusterNode(_message.Message):
    __slots__ = ("node_id", "address", "role", "state")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    node_id: str
    address: str
    role: NodeRole
    state: NodeState
    def __init__(self, node_id: _Optional[str] = ..., address: _Optional[str] = ..., role: _Optional[_Union[NodeRole, str]] = ..., state: _Optional[_Union[NodeState, str]] = ...) -> None: ...

class AddNodeRequest(_message.Message):
    __slots__ = ("address",)
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    address: str
    def __init__(self, address: _Optional[str] = ...) -> None: ...

class RemoveNodeRequest(_message.Message):
    __slots__ = ("node_id",)
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    node_id: str
    def __init__(self, node_id: _Optional[str] = ...) -> None: ...

class RemoveNodeResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
