"""Pipeline orchestrator — chains all Truva engines together."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console

from truva.config import PipelineConfig
from truva.report.generator import AuditResult

console = Console()


class Pipeline:
    """Run the full Truva curation pipeline from a single config.

    Steps (each optional):
        1. Load data
        2. Embed
        3. Deduplicate
        4. Score + quality filter
        5. Detect contradictions
        6. Write gold dataset + report
    """

    def __init__(self, config: PipelineConfig) -> None:
        self.config = config

    def run(self, input_path: str) -> AuditResult:
        """Execute the pipeline and return an AuditResult.

        Args:
            input_path: Path to the input dataset (JSONL, CSV, or HF id).

        Returns:
            AuditResult with counts, scores, contradictions, and gold indices.
        """
        cfg = self.config
        audit = AuditResult(config_snapshot=_config_snapshot(cfg))

        # ── Step 1: Load ──────────────────────────────────────────────────
        from truva.data.loader import detect_text_field, load_dataset

        rows = load_dataset(input_path, format=cfg.input_format, text_column=cfg.text_field)
        audit.input_rows = len(rows)

        if not rows:
            audit.gold_rows = 0
            return audit

        text_field = cfg.text_field or detect_text_field(rows)

        # ── Step 2: Embed ─────────────────────────────────────────────────
        from truva.engines.embedder import compute_embeddings
        from truva.models.embedding import EmbeddingModel

        console.print(f"[cyan]Step 1/4:[/cyan] Computing embeddings…")
        emb_model = EmbeddingModel(
            provider=cfg.embed_provider,
            model_name=cfg.embed_model,
        )
        embeddings = compute_embeddings(rows, model=emb_model, text_field=text_field)

        # ── Step 3: Deduplicate ───────────────────────────────────────────
        dedupe_result = None
        active_indices = list(range(len(rows)))

        if cfg.dedupe_threshold > 0.0:
            from truva.engines.deduper import deduplicate

            console.print(
                f"[cyan]Step 2/4:[/cyan] Deduplicating "
                f"(threshold={cfg.dedupe_threshold})…"
            )
            dedupe_result = deduplicate(embeddings, rows, threshold=cfg.dedupe_threshold)
            active_indices = dedupe_result.kept_indices
            audit.rows_after_dedupe = len(active_indices)
            audit.clusters = [
                {
                    "representative_idx": c.representative_idx,
                    "size": len(c.member_indices),
                    "avg_similarity": round(c.avg_similarity, 4),
                }
                for c in dedupe_result.clusters
            ]
        else:
            console.print("[dim]Step 2/4: Deduplication skipped (threshold=0)[/dim]")

        active_rows = [rows[i] for i in active_indices]
        active_embeddings = embeddings[active_indices]

        # ── Step 4: Score + quality filter ────────────────────────────────
        if cfg.min_quality > 0.0:
            from truva.calibration.calibrator import load_calibration
            from truva.engines.scorer import filter_by_quality, score_dataset
            from truva.models.judge import JudgeModel

            console.print(
                f"[cyan]Step 3/4:[/cyan] Scoring rows "
                f"(min_quality={cfg.min_quality}, mode={cfg.score_mode})…"
            )

            cal_config = None
            if cfg.calibration_path:
                cal_config = load_calibration(cfg.calibration_path)

            judge = JudgeModel(
                provider=cfg.score_provider,
                model_name=cfg.score_model if cfg.score_model else None,
                rubric=cal_config.rubric if cal_config else cfg.rubric,
                calibration_examples=cal_config.examples if cal_config else None,
            )

            # Build a partial dedupe_result for active rows if we ran dedup
            score_dedupe = None
            if dedupe_result is not None:
                from truva.engines.deduper import Cluster, DedupeResult
                # Remap cluster indices to positions within active_rows
                idx_to_active = {orig: pos for pos, orig in enumerate(active_indices)}
                remapped_clusters = []
                for c in dedupe_result.clusters:
                    remapped_members = [
                        idx_to_active[m] for m in c.member_indices
                        if m in idx_to_active
                    ]
                    if remapped_members:
                        remapped_clusters.append(
                            Cluster(
                                idx_to_active.get(c.representative_idx, remapped_members[0]),
                                remapped_members,
                                c.avg_similarity,
                            )
                        )
                score_dedupe = DedupeResult(
                    kept_indices=list(range(len(active_rows))),
                    removed_indices=[],
                    clusters=remapped_clusters,
                )

            score_results = score_dataset(
                active_rows,
                judge,
                text_field=text_field,
                mode=cfg.score_mode,
                dedupe_result=score_dedupe,
            )

            audit.scores = {s.row_id: s.score for s in score_results}

            kept_rows, _ = filter_by_quality(active_rows, score_results, cfg.min_quality)
            # Recover original indices for kept rows
            kept_row_ids = {r["row_id"] for r in kept_rows}
            active_indices = [
                active_indices[pos]
                for pos, row in enumerate(active_rows)
                if row["row_id"] in kept_row_ids
            ]
            active_rows = [rows[i] for i in active_indices]
            audit.rows_after_scoring = len(active_rows)
        else:
            console.print("[dim]Step 3/4: Scoring skipped (min_quality=0)[/dim]")

        # ── Step 5: Contradiction detection ───────────────────────────────
        if cfg.detect_contradictions and dedupe_result is not None:
            from truva.engines.contradictor import detect_contradictions
            from truva.models.nli import NLIModel

            console.print(
                f"[cyan]Step 4/4:[/cyan] Detecting contradictions "
                f"(confidence={cfg.contradiction_confidence})…"
            )
            nli = NLIModel()
            contradictions = detect_contradictions(
                rows,
                dedupe_result.clusters,
                nli,
                text_field=text_field,
                confidence_threshold=cfg.contradiction_confidence,
            )
            audit.contradictions_found = len(contradictions)
            audit.contradictions = [
                {
                    "row_a_id": c.row_a_id,
                    "row_b_id": c.row_b_id,
                    "text_a": c.text_a,
                    "text_b": c.text_b,
                    "confidence": round(c.confidence, 4),
                }
                for c in contradictions
            ]
        else:
            console.print("[dim]Step 4/4: Contradiction detection skipped[/dim]")

        # ── Step 6: Write outputs ─────────────────────────────────────────
        from truva.data.writer import write_jsonl
        from truva.report.generator import generate_report

        audit.gold_row_indices = active_indices
        audit.gold_rows = len(active_rows)

        output_dir = Path(cfg.output_path)
        output_dir.mkdir(parents=True, exist_ok=True)

        write_jsonl(active_rows, str(output_dir / "gold.jsonl"))
        generate_report(audit, str(output_dir))

        return audit


def _config_snapshot(cfg: PipelineConfig) -> dict[str, Any]:
    return {
        "embed_provider": cfg.embed_provider,
        "embed_model": cfg.embed_model,
        "dedupe_threshold": cfg.dedupe_threshold,
        "score_provider": cfg.score_provider,
        "min_quality": cfg.min_quality,
        "score_mode": cfg.score_mode,
        "detect_contradictions": cfg.detect_contradictions,
        "contradiction_confidence": cfg.contradiction_confidence,
    }
