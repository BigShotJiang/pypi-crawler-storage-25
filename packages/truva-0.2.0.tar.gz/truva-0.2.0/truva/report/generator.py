"""Audit report generation — JSON output and rich terminal summary."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

console = Console()


@dataclass
class AuditResult:
    # Row counts at each stage
    input_rows: int = 0
    rows_after_dedupe: int | None = None      # None = step was skipped
    rows_after_scoring: int | None = None     # None = step was skipped
    contradictions_found: int = 0
    gold_rows: int = 0

    # Actual row data surviving to the end
    gold_row_indices: list[int] = field(default_factory=list)

    # Per-row scores (row_id → score)
    scores: dict[str, float] = field(default_factory=dict)

    # Contradiction pairs
    contradictions: list[dict[str, Any]] = field(default_factory=list)

    # Cluster summary from dedup
    clusters: list[dict[str, Any]] = field(default_factory=list)

    # Config snapshot
    config_snapshot: dict[str, Any] = field(default_factory=dict)


def generate_report(audit: AuditResult, output_dir: str) -> dict[str, Any]:
    """Write report.json and print a rich terminal summary.

    Args:
        audit: Populated AuditResult from a Pipeline run.
        output_dir: Directory to write report.json into.

    Returns:
        The report dict (also written to report.json).
    """
    from pathlib import Path
    import json

    report = _build_report_dict(audit)

    out_path = Path(output_dir) / "report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(report, f, indent=2, ensure_ascii=False, default=str)

    _print_terminal_summary(audit, out_path)
    return report


def _build_report_dict(audit: AuditResult) -> dict[str, Any]:
    stages: list[dict[str, Any]] = [
        {"stage": "input", "rows": audit.input_rows},
    ]

    if audit.rows_after_dedupe is not None:
        removed = audit.input_rows - audit.rows_after_dedupe
        pct = removed / audit.input_rows * 100 if audit.input_rows else 0
        stages.append({
            "stage": "deduplication",
            "rows": audit.rows_after_dedupe,
            "removed": removed,
            "reduction_pct": round(pct, 2),
        })

    if audit.rows_after_scoring is not None:
        base = audit.rows_after_dedupe if audit.rows_after_dedupe is not None else audit.input_rows
        removed = base - audit.rows_after_scoring
        pct = removed / audit.input_rows * 100 if audit.input_rows else 0
        stages.append({
            "stage": "quality_filter",
            "rows": audit.rows_after_scoring,
            "removed": removed,
            "reduction_pct": round(pct, 2),
        })

    total_reduction = (
        (1 - audit.gold_rows / audit.input_rows) * 100 if audit.input_rows else 0
    )

    return {
        "summary": {
            "input_rows": audit.input_rows,
            "gold_rows": audit.gold_rows,
            "total_reduction_pct": round(total_reduction, 2),
            "contradictions_found": audit.contradictions_found,
            "estimated_tokens_saved": _estimate_tokens_saved(
                audit.input_rows - audit.gold_rows
            ),
        },
        "stages": stages,
        "clusters": audit.clusters[:50],  # cap report size
        "contradictions": audit.contradictions,
        "config": audit.config_snapshot,
    }


def _print_terminal_summary(audit: AuditResult, report_path: Any) -> None:
    """Print a rich box summary to the terminal."""
    n_in = audit.input_rows
    n_gold = audit.gold_rows
    total_pct = (1 - n_gold / n_in) * 100 if n_in else 0
    tokens_saved = _estimate_tokens_saved(n_in - n_gold)

    table = Table(box=box.SIMPLE, show_header=False, pad_edge=False)
    table.add_column("label", style="dim", min_width=28)
    table.add_column("value", style="bold white")

    table.add_row("Input Rows", f"{n_in:,}")

    if audit.rows_after_dedupe is not None:
        removed = n_in - audit.rows_after_dedupe
        pct = removed / n_in * 100 if n_in else 0
        table.add_row(
            "After Deduplication",
            f"{audit.rows_after_dedupe:,}  [red](-{pct:.1f}%)[/red]",
        )

    if audit.rows_after_scoring is not None:
        base = audit.rows_after_dedupe if audit.rows_after_dedupe is not None else n_in
        removed = base - audit.rows_after_scoring
        pct = removed / n_in * 100 if n_in else 0
        table.add_row(
            "After Quality Filter",
            f"{audit.rows_after_scoring:,}  [red](-{pct:.1f}%)[/red]",
        )

    if audit.contradictions_found:
        table.add_row("Contradictions Found", f"[yellow]{audit.contradictions_found} pairs[/yellow]")

    table.add_section()
    table.add_row('Final "Gold" Rows', f"[green]{n_gold:,}  (-{total_pct:.1f}%)[/green]")
    table.add_row("Est. Tokens Saved", f"~{tokens_saved:,}")

    panel = Panel(
        table,
        title="[bold cyan]TRUVA AUDIT REPORT[/bold cyan]",
        border_style="cyan",
        padding=(0, 2),
    )
    console.print()
    console.print(panel)
    console.print(f"[dim]Gold dataset → {report_path.parent / 'gold.jsonl'}[/dim]")
    console.print(f"[dim]Report       → {report_path}[/dim]\n")


def _estimate_tokens_saved(rows_removed: int, avg_tokens_per_row: int = 500) -> int:
    """Rough token savings estimate (assumes ~500 tokens per row on average)."""
    return max(0, rows_removed * avg_tokens_per_row)
