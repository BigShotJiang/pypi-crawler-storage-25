"""Load datasets from JSONL, CSV, or Hugging Face."""

from __future__ import annotations

import csv
import json
import uuid
from pathlib import Path
from typing import Any

from rich.console import Console

console = Console()


def load_dataset(
    path: str,
    format: str = "auto",
    text_column: str | None = None,
) -> list[dict[str, Any]]:
    """Load a dataset from JSONL, CSV, or Hugging Face.

    Args:
        path: File path or HF dataset identifier (contains '/').
        format: One of "auto", "jsonl", "csv", "hf".
        text_column: Explicit text column name for CSV files.

    Returns:
        List of dicts, each with a 'row_id' field and original fields.
    """
    if format == "auto":
        format = _detect_format(path)

    loaders = {
        "jsonl": _load_jsonl,
        "csv": _load_csv,
        "hf": _load_hf,
    }

    if format not in loaders:
        raise ValueError(f"Unknown format: {format!r}. Expected one of {list(loaders)}")

    rows = loaders[format](path, text_column=text_column)
    rows = _ensure_row_ids(rows)

    console.print(f"[green]Loaded {len(rows)} rows[/green] from {path} (format={format})")
    return rows


def detect_text_field(rows: list[dict[str, Any]], text_column: str | None = None) -> str:
    """Detect or validate the text field in the dataset.

    If text_column is provided, validates it exists. Otherwise picks the
    string field with the longest average length.
    """
    if not rows:
        raise ValueError("Cannot detect text field from empty dataset")

    if text_column:
        if text_column not in rows[0]:
            raise ValueError(
                f"Text column {text_column!r} not found. "
                f"Available: {list(rows[0].keys())}"
            )
        return text_column

    # Find string fields and pick the one with longest average length
    sample = rows[:100]
    string_fields: dict[str, float] = {}

    for key in sample[0]:
        if key == "row_id":
            continue
        values = [r.get(key) for r in sample if isinstance(r.get(key), str)]
        if values:
            string_fields[key] = sum(len(v) for v in values) / len(values)

    if not string_fields:
        raise ValueError("No string fields found in dataset")

    best = max(string_fields, key=string_fields.get)  # type: ignore[arg-type]
    return best


def _detect_format(path: str) -> str:
    suffix = Path(path).suffix.lower()
    if suffix in (".jsonl", ".json"):
        return "jsonl"
    elif suffix == ".csv":
        return "csv"
    elif "/" in path and not Path(path).exists():
        return "hf"
    else:
        raise ValueError(
            f"Cannot auto-detect format for {path!r}. "
            "Use --format to specify one of: jsonl, csv, hf"
        )


def _load_jsonl(path: str, **_: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    filepath = Path(path)
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {path}")

    with open(filepath) as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON on line {line_num}: {e}") from e
            if not isinstance(row, dict):
                raise ValueError(f"Line {line_num}: expected JSON object, got {type(row).__name__}")
            rows.append(row)

    return rows


def _load_csv(path: str, text_column: str | None = None, **_: Any) -> list[dict[str, Any]]:
    filepath = Path(path)
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {path}")

    rows: list[dict[str, Any]] = []
    with open(filepath, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(dict(row))

    if not rows:
        return rows

    # Validate text_column if provided
    if text_column and text_column not in rows[0]:
        raise ValueError(
            f"Text column {text_column!r} not found in CSV. "
            f"Available columns: {list(rows[0].keys())}"
        )

    return rows


def _load_hf(path: str, **_: Any) -> list[dict[str, Any]]:
    try:
        from datasets import load_dataset as hf_load
    except ImportError:
        raise ImportError(
            "Hugging Face datasets library required. "
            "Install with: pip install 'truva[hf]'"
        )

    ds = hf_load(path)
    # If DatasetDict, take the first split
    if hasattr(ds, "keys"):
        split = list(ds.keys())[0]
        console.print(f"[dim]Using split: {split}[/dim]")
        ds = ds[split]

    return [dict(row) for row in ds]


def _ensure_row_ids(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    for row in rows:
        if "row_id" not in row:
            row["row_id"] = str(uuid.uuid4())
    return rows
