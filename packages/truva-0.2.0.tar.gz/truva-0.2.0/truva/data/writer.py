"""Write cleaned datasets and reports."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rich.console import Console

console = Console()


def write_jsonl(rows: list[dict[str, Any]], path: str) -> None:
    """Write rows to a JSONL file."""
    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    console.print(f"[green]Wrote {len(rows)} rows[/green] to {filepath}")


def write_json_report(data: dict[str, Any], path: str) -> None:
    """Write a JSON report file."""
    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    console.print(f"[green]Report written[/green] to {filepath}")
