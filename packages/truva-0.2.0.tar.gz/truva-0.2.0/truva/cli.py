"""Click-based CLI entry point for Truva."""

from __future__ import annotations

from pathlib import Path

import click
import numpy as np
from rich.console import Console

console = Console()


@click.group()
@click.version_option(package_name="truva")
def main() -> None:
    """Truva — Data curation engine for LLM fine-tuning."""


@main.command()
@click.argument("input_path")
@click.option("--provider", default="local", type=click.Choice(["local", "api"]), help="Embedding provider.")
@click.option("--model", default=None, help="Model name. Default: all-MiniLM-L6-v2 (local) or text-embedding-3-small (api).")
@click.option("--text-field", default=None, help="Column/field to embed. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--output", "-o", default="./embeddings.npy", help="Output path for embeddings (.npy).")
def embed(
    input_path: str,
    provider: str,
    model: str | None,
    text_field: str | None,
    input_format: str,
    output: str,
) -> None:
    """Compute embeddings for a dataset."""
    from truva.data.loader import load_dataset
    from truva.engines.embedder import compute_embeddings
    from truva.models.embedding import EmbeddingModel

    rows = load_dataset(input_path, format=input_format, text_column=text_field)

    emb_model = EmbeddingModel(provider=provider, model_name=model)
    embeddings = compute_embeddings(rows, model=emb_model, text_field=text_field)

    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(output_path), embeddings)

    console.print(f"[green]Saved embeddings[/green] ({embeddings.shape}) to {output_path}")


@main.command()
@click.argument("input_path")
@click.option("--threshold", default=0.95, type=float, help="Cosine similarity threshold (0.0–1.0).")
@click.option("--provider", default="local", type=click.Choice(["local", "api"]), help="Embedding provider.")
@click.option("--model", default=None, help="Embedding model name.")
@click.option("--text-field", default=None, help="Column/field to embed. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--output", "-o", default="./deduped.jsonl", help="Output path for deduplicated dataset.")
@click.option("--report", default=None, help="Output path for dedupe report JSON.")
def dedupe(
    input_path: str,
    threshold: float,
    provider: str,
    model: str | None,
    text_field: str | None,
    input_format: str,
    output: str,
    report: str | None,
) -> None:
    """Remove semantic duplicates from a dataset."""
    from truva.data.loader import load_dataset
    from truva.data.writer import write_json_report, write_jsonl
    from truva.engines.deduper import deduplicate
    from truva.engines.embedder import compute_embeddings
    from truva.models.embedding import EmbeddingModel

    rows = load_dataset(input_path, format=input_format, text_column=text_field)

    emb_model = EmbeddingModel(provider=provider, model_name=model)
    embeddings = compute_embeddings(rows, model=emb_model, text_field=text_field)

    result = deduplicate(embeddings, rows, threshold=threshold)

    kept_rows = [rows[i] for i in result.kept_indices]
    write_jsonl(kept_rows, output)

    pct = (1 - len(result.kept_indices) / len(rows)) * 100 if rows else 0
    console.print(
        f"[bold]Dedup:[/bold] {len(rows)} → {len(result.kept_indices)} rows "
        f"([red]-{pct:.1f}%[/red]), {len(result.clusters)} clusters"
    )

    if report:
        report_data = {
            "input_rows": len(rows),
            "kept_rows": len(result.kept_indices),
            "removed_rows": len(result.removed_indices),
            "reduction_pct": round(pct, 2),
            "threshold": threshold,
            "num_clusters": len(result.clusters),
            "clusters": [
                {
                    "representative_idx": c.representative_idx,
                    "size": len(c.member_indices),
                    "avg_similarity": round(c.avg_similarity, 4),
                }
                for c in result.clusters
            ],
        }
        write_json_report(report_data, report)


@main.command()
@click.argument("input_path")
@click.option("--provider", default="ollama", type=click.Choice(["ollama", "openai", "anthropic"]), help="Judge model provider.")
@click.option("--model", default=None, help="Judge model name.")
@click.option("--text-field", default=None, help="Column/field to score. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--mode", default="fast", type=click.Choice(["fast", "thorough"]), help="'fast' scores cluster reps only; 'thorough' scores every row.")
@click.option("--min-quality", default=0.0, type=float, help="Drop rows with score below this threshold (0.0 = keep all).")
@click.option("--calibration", default=None, help="Path to calibration YAML file.")
@click.option("--output", "-o", default="./scored.jsonl", help="Output path for scored dataset.")
@click.option("--report", default=None, help="Output path for scoring report JSON.")
@click.option("--sample", default=None, type=int, help="For --interactive: number of rows to sample.")
@click.option("--interactive", is_flag=True, default=False, help="Interactive dry-run: show scores, collect feedback.")
def score(
    input_path: str,
    provider: str,
    model: str | None,
    text_field: str | None,
    input_format: str,
    mode: str,
    min_quality: float,
    calibration: str | None,
    output: str,
    report: str | None,
    sample: int | None,
    interactive: bool,
) -> None:
    """Score dataset rows for information density using an LLM judge."""
    import random

    from truva.calibration.calibrator import load_calibration
    from truva.data.loader import load_dataset
    from truva.data.writer import write_json_report, write_jsonl
    from truva.engines.scorer import filter_by_quality, score_dataset
    from truva.models.judge import JudgeModel

    rows = load_dataset(input_path, format=input_format, text_column=text_field)

    cal_config = None
    if calibration:
        cal_config = load_calibration(calibration)

    judge = JudgeModel(
        provider=provider,
        model_name=model,
        rubric=cal_config.rubric if cal_config else None,
        calibration_examples=cal_config.examples if cal_config else None,
    )

    if interactive:
        _run_interactive(rows, judge, text_field, sample or 50)
        return

    scores = score_dataset(rows, judge, text_field=text_field, mode=mode)

    if min_quality > 0.0:
        kept_rows, removed_rows = filter_by_quality(rows, scores, min_quality)
    else:
        kept_rows = [{**row, "_score": s.score, "_flags": s.flags} for row, s in zip(rows, scores)]
        removed_rows = []

    write_jsonl(kept_rows, output)

    avg = sum(s.score for s in scores) / len(scores) if scores else 0
    console.print(
        f"[bold]Score:[/bold] {len(rows)} rows, avg score [cyan]{avg:.2f}[/cyan], "
        f"kept [green]{len(kept_rows)}[/green] / removed [red]{len(removed_rows)}[/red]"
    )

    if report:
        flag_counts: dict[str, int] = {}
        for s in scores:
            for f in s.flags:
                flag_counts[f] = flag_counts.get(f, 0) + 1

        report_data = {
            "input_rows": len(rows),
            "kept_rows": len(kept_rows),
            "removed_rows": len(removed_rows),
            "min_quality": min_quality,
            "avg_score": round(avg, 3),
            "score_distribution": _score_distribution(scores),
            "flag_counts": flag_counts,
            "scores": [
                {"row_id": s.row_id, "score": s.score, "flags": s.flags}
                for s in scores
            ],
        }
        write_json_report(report_data, report)


def _run_interactive(
    rows: list[dict],
    judge: "JudgeModel",
    text_field: str | None,
    n_sample: int,
) -> None:
    """Interactive dry-run: display scores and collect user agreement."""
    import json
    import random

    from truva.data.loader import detect_text_field

    if text_field is None:
        text_field = detect_text_field(rows)

    sample = random.sample(rows, min(n_sample, len(rows)))
    agreed = 0
    disagreed = 0
    feedback: list[dict] = []

    console.print(f"\n[bold]Interactive dry-run[/bold] — scoring {len(sample)} random rows\n")

    for i, row in enumerate(sample, 1):
        result = judge.score_batch([row], text_field)[0]
        text = row.get(text_field, str(row))[:300]

        console.print(f"[dim]── Row {i}/{len(sample)} ──────────────────────────────[/dim]")
        console.print(f"[bold]Text:[/bold] {text}")
        console.print(f"[bold]Score:[/bold] [cyan]{result.score:.0f}/10[/cyan]  "
                      f"[bold]Flags:[/bold] {result.flags or 'none'}")
        console.print(f"[bold]Reasoning:[/bold] {result.reasoning}")

        try:
            choice = click.prompt(
                "\n[y] agree  [n] disagree  [s] skip  [q] quit",
                default="s",
            ).strip().lower()
        except (click.Abort, KeyboardInterrupt):
            console.print("\n[yellow]Interrupted.[/yellow]")
            break

        if choice == "q":
            break
        elif choice == "y":
            agreed += 1
        elif choice == "n":
            disagreed += 1
            feedback.append({**row, "_judge_score": result.score, "_user_agreed": False})
        # "s" = skip

    total = agreed + disagreed
    if total > 0:
        pct = agreed / total * 100
        console.print(f"\n[bold]Alignment:[/bold] agreed on {agreed}/{total} scored rows ({pct:.0f}%)")
        if pct < 70:
            console.print(
                "[yellow]Low alignment (<70%). Consider adding a calibration file "
                "with domain-specific examples to guide the judge.[/yellow]"
            )

    if feedback:
        feedback_path = "./truva_feedback.jsonl"
        from truva.data.writer import write_jsonl
        write_jsonl(feedback, feedback_path)
        console.print(f"[dim]Disagreements saved to {feedback_path} for future calibration.[/dim]")


@main.command()
@click.argument("input_path")
@click.option("--confidence", default=0.8, type=float, help="Minimum NLI confidence to flag a contradiction (0.0–1.0).")
@click.option("--nli-model", default="cross-encoder/nli-deberta-v3-base", help="NLI model name.")
@click.option("--text-field", default=None, help="Column/field to compare. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--dedupe-threshold", default=0.95, type=float, help="Similarity threshold for clustering before NLI check.")
@click.option("--output", "-o", default="./contradictions.json", help="Output path for contradiction report JSON.")
def contradict(
    input_path: str,
    confidence: float,
    nli_model: str,
    text_field: str | None,
    input_format: str,
    dedupe_threshold: float,
    output: str,
) -> None:
    """Detect contradicting row pairs within semantic clusters."""
    from truva.data.loader import detect_text_field, load_dataset
    from truva.data.writer import write_json_report
    from truva.engines.contradictor import detect_contradictions
    from truva.engines.deduper import deduplicate
    from truva.engines.embedder import compute_embeddings
    from truva.models.embedding import EmbeddingModel
    from truva.models.nli import NLIModel

    rows = load_dataset(input_path, format=input_format, text_column=text_field)

    if text_field is None:
        text_field = detect_text_field(rows)

    # Cluster first so NLI only checks semantically similar pairs
    emb_model = EmbeddingModel(provider="local")
    embeddings = compute_embeddings(rows, model=emb_model, text_field=text_field)
    dedupe_result = deduplicate(embeddings, rows, threshold=dedupe_threshold)

    nli = NLIModel(model_name=nli_model)
    contradictions = detect_contradictions(
        rows,
        dedupe_result.clusters,
        nli,
        text_field=text_field,
        confidence_threshold=confidence,
    )

    console.print(
        f"[bold]Contradict:[/bold] checked {len(rows)} rows in "
        f"{len(dedupe_result.clusters)} clusters — "
        f"found [red]{len(contradictions)}[/red] contradiction(s)"
    )

    report_data = {
        "input_rows": len(rows),
        "num_clusters": len(dedupe_result.clusters),
        "confidence_threshold": confidence,
        "contradictions_found": len(contradictions),
        "contradictions": [
            {
                "row_a_id": c.row_a_id,
                "row_b_id": c.row_b_id,
                "text_a": c.text_a,
                "text_b": c.text_b,
                "confidence": round(c.confidence, 4),
            }
            for c in contradictions
        ],
    }
    write_json_report(report_data, output)


@main.command()
@click.argument("input_path")
@click.option("--dedupe", "dedupe_threshold", default=0.95, type=float, help="Dedup similarity threshold (0.0 to skip).")
@click.option("--min-quality", default=0.0, type=float, help="Drop rows below this score (0.0 to skip scoring).")
@click.option("--detect-contradictions", "do_contradict", is_flag=True, default=False, help="Run contradiction detection.")
@click.option("--score-provider", default="ollama", type=click.Choice(["ollama", "openai", "anthropic"]), help="Judge model provider.")
@click.option("--score-model", default=None, help="Judge model name.")
@click.option("--embed-provider", default="local", type=click.Choice(["local", "api"]), help="Embedding provider.")
@click.option("--embed-model", default="all-MiniLM-L6-v2", help="Embedding model name.")
@click.option("--score-mode", default="fast", type=click.Choice(["fast", "thorough"]), help="Scoring mode.")
@click.option("--calibration", default=None, help="Path to calibration YAML file.")
@click.option("--contradiction-confidence", default=0.8, type=float, help="NLI confidence threshold.")
@click.option("--text-field", default=None, help="Column/field to process. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--output", "-o", default="./truva_output/", help="Output directory.")
def audit(
    input_path: str,
    dedupe_threshold: float,
    min_quality: float,
    do_contradict: bool,
    score_provider: str,
    score_model: str | None,
    embed_provider: str,
    embed_model: str,
    score_mode: str,
    calibration: str | None,
    contradiction_confidence: float,
    text_field: str | None,
    input_format: str,
    output: str,
) -> None:
    """Run the full curation pipeline: embed → dedupe → score → contradict."""
    from truva.config import PipelineConfig
    from truva.pipeline import Pipeline

    cfg = PipelineConfig(
        input_path=input_path,
        input_format=input_format,
        text_field=text_field,
        embed_provider=embed_provider,
        embed_model=embed_model,
        dedupe_threshold=dedupe_threshold,
        score_provider=score_provider,
        score_model=score_model or "",
        min_quality=min_quality,
        score_mode=score_mode,
        calibration_path=calibration,
        detect_contradictions=do_contradict,
        contradiction_confidence=contradiction_confidence,
        output_path=output,
    )

    pipeline = Pipeline(cfg)
    pipeline.run(input_path)


@main.command()
@click.argument("report_path")
@click.option("--cluster", "cluster_idx", default=None, type=int, help="Cluster index to inspect.")
@click.option("--contradictions", is_flag=True, default=False, help="Show all contradictions instead.")
def inspect(report_path: str, cluster_idx: int | None, contradictions: bool) -> None:
    """Inspect a specific cluster or contradiction from a report.json."""
    import json
    from pathlib import Path

    path = Path(report_path)
    if not path.exists():
        console.print(f"[red]Report not found:[/red] {report_path}")
        raise SystemExit(1)

    with open(path) as f:
        report = json.load(f)

    if contradictions:
        pairs = report.get("contradictions", [])
        if not pairs:
            console.print("[yellow]No contradictions found in this report.[/yellow]")
            return
        console.print(f"\n[bold]Contradictions[/bold] ({len(pairs)} pairs)\n")
        for i, pair in enumerate(pairs, 1):
            console.print(f"[cyan]── Pair {i} ──────────────────────────────────[/cyan]")
            console.print(f"[bold]Row A[/bold] ({pair['row_a_id']}): {pair['text_a'][:200]}")
            console.print(f"[bold]Row B[/bold] ({pair['row_b_id']}): {pair['text_b'][:200]}")
            console.print(f"[bold]Confidence:[/bold] {pair['confidence']:.4f}\n")
        return

    clusters = report.get("clusters", [])
    if cluster_idx is None:
        console.print(f"\n[bold]Clusters summary[/bold] — {len(clusters)} total\n")
        for i, c in enumerate(clusters[:20]):
            console.print(
                f"  [{i:>4}]  size={c['size']:>4}  "
                f"avg_sim={c['avg_similarity']:.4f}  "
                f"rep_idx={c['representative_idx']}"
            )
        if len(clusters) > 20:
            console.print(f"  [dim]… and {len(clusters) - 20} more[/dim]")
        return

    if cluster_idx >= len(clusters):
        console.print(f"[red]Cluster {cluster_idx} not found.[/red] Report has {len(clusters)} clusters.")
        raise SystemExit(1)

    c = clusters[cluster_idx]
    console.print(f"\n[bold]Cluster {cluster_idx}[/bold]")
    console.print(f"  Size:               {c['size']}")
    console.print(f"  Avg similarity:     {c['avg_similarity']:.4f}")
    console.print(f"  Representative idx: {c['representative_idx']}")


@main.command()
@click.argument("output_dir")
@click.option("--format", "fmt", default="jsonl", type=click.Choice(["jsonl", "csv"]), help="Export format.")
@click.option("--columns", default=None, help="Comma-separated list of columns to include.")
@click.option("--output", "-o", default=None, help="Output file path. Defaults to gold.<format> in output_dir.")
def export(output_dir: str, fmt: str, columns: str | None, output: str | None) -> None:
    """Export the gold dataset in a different format or with selected columns."""
    import csv
    import json
    from pathlib import Path

    gold_path = Path(output_dir) / "gold.jsonl"
    if not gold_path.exists():
        console.print(f"[red]Gold dataset not found:[/red] {gold_path}")
        raise SystemExit(1)

    rows = []
    with open(gold_path) as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    col_list = [c.strip() for c in columns.split(",")] if columns else None

    if col_list:
        rows = [{k: v for k, v in row.items() if k in col_list} for row in rows]

    out_path = Path(output or str(Path(output_dir) / f"gold.{fmt}"))
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "jsonl":
        with open(out_path, "w") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
    elif fmt == "csv":
        if not rows:
            console.print("[yellow]No rows to export.[/yellow]")
            return
        fieldnames = col_list or list(rows[0].keys())
        with open(out_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)

    console.print(f"[green]Exported {len(rows)} rows[/green] → {out_path}")


@main.command()
@click.argument("input_path")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--text-field", default=None, help="Column/field to analyse. Auto-detected if not set.")
@click.option("--sample", default=500, type=int, help="Number of rows to sample for stats.")
def health(
    input_path: str,
    input_format: str,
    text_field: str | None,
    sample: int,
) -> None:
    """Show a dataset health summary without modifying anything."""
    import random

    from rich.table import Table

    from truva.data.loader import detect_text_field, load_dataset

    rows = load_dataset(input_path, format=input_format, text_column=text_field)
    if not rows:
        console.print("[yellow]Dataset is empty.[/yellow]")
        return

    tf = text_field or detect_text_field(rows)
    sample_rows = random.sample(rows, min(sample, len(rows)))

    texts = [str(r.get(tf, "")) for r in sample_rows]
    lengths = [len(t.split()) for t in texts]
    empty = sum(1 for t in texts if not t.strip())
    avg_len = sum(lengths) / len(lengths) if lengths else 0
    min_len = min(lengths) if lengths else 0
    max_len = max(lengths) if lengths else 0

    # Very short rows (< 5 words) — likely low quality
    short = sum(1 for l in lengths if l < 5)

    fields = list(rows[0].keys())

    table = Table(title="Dataset Health", show_header=True, header_style="bold cyan")
    table.add_column("Metric", style="dim")
    table.add_column("Value", style="bold white")

    table.add_row("Total rows", f"{len(rows):,}")
    table.add_row("Fields", ", ".join(fields))
    table.add_row("Text field used", tf)
    table.add_row("Sample size", f"{len(sample_rows):,}")
    table.add_row("Avg text length (words)", f"{avg_len:.1f}")
    table.add_row("Min / Max length", f"{min_len} / {max_len}")
    table.add_row("Empty rows", f"{empty} ({empty/len(sample_rows)*100:.1f}%)")
    table.add_row("Very short rows (<5 words)", f"{short} ({short/len(sample_rows)*100:.1f}%)")

    console.print()
    console.print(table)
    console.print()
    console.print("[dim]Tip: run [bold]truva audit[/bold] to deduplicate and score this dataset.[/dim]\n")


def _score_distribution(scores: list) -> dict[str, int]:
    """Bucket scores into ranges for the report."""
    buckets: dict[str, int] = {"1-3": 0, "4-6": 0, "7-8": 0, "9-10": 0}
    for s in scores:
        if s.score <= 3:
            buckets["1-3"] += 1
        elif s.score <= 6:
            buckets["4-6"] += 1
        elif s.score <= 8:
            buckets["7-8"] += 1
        else:
            buckets["9-10"] += 1
    return buckets


if __name__ == "__main__":
    main()
