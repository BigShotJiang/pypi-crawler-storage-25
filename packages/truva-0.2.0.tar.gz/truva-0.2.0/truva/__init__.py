"""Truva — Data curation engine for LLM fine-tuning."""

__version__ = "0.2.0"
