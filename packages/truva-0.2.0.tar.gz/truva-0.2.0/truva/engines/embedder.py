"""Compute embeddings for dataset rows."""

from __future__ import annotations

from typing import Any

import numpy as np

from truva.data.loader import detect_text_field
from truva.models.embedding import EmbeddingModel


def compute_embeddings(
    rows: list[dict[str, Any]],
    model: EmbeddingModel,
    text_field: str | None = None,
) -> np.ndarray:
    """Generate embeddings for dataset rows.

    Args:
        rows: Dataset rows as list of dicts.
        model: An EmbeddingModel instance.
        text_field: Key to extract text from. If None, auto-detects the
            best string field. If "auto", concatenates all string fields.

    Returns:
        numpy array of shape (n_rows, embed_dim).
    """
    if not rows:
        raise ValueError("Cannot compute embeddings for empty dataset")

    if text_field is None:
        text_field = detect_text_field(rows)

    texts = _extract_texts(rows, text_field)
    return model.embed_batch(texts)


def _extract_texts(rows: list[dict[str, Any]], text_field: str) -> list[str]:
    """Extract text from each row for embedding."""
    texts: list[str] = []

    for i, row in enumerate(rows):
        if text_field in row:
            value = row[text_field]
            if not isinstance(value, str):
                value = str(value)
            texts.append(value)
        else:
            # Concatenate all string fields as fallback
            parts = [
                str(v) for k, v in row.items()
                if k != "row_id" and isinstance(v, str)
            ]
            if not parts:
                raise ValueError(f"Row {i} has no text content")
            texts.append(" ".join(parts))

    return texts
