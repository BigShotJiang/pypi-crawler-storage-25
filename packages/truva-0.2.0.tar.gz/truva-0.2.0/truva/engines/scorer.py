"""Information density scoring engine."""

from __future__ import annotations

from typing import Any

from truva.engines.deduper import Cluster, DedupeResult
from truva.models.judge import JudgeModel, ScoreResult


def score_dataset(
    rows: list[dict[str, Any]],
    judge: JudgeModel,
    text_field: str | None = None,
    mode: str = "fast",
    dedupe_result: DedupeResult | None = None,
) -> list[ScoreResult]:
    """Score dataset rows for information density.

    Args:
        rows: Dataset rows to score.
        judge: A JudgeModel instance.
        text_field: Field to extract text from. Auto-detected if None.
        mode: "fast" scores only cluster representatives and propagates
              scores to cluster members (5-10x cheaper). "thorough"
              scores every row individually.
        dedupe_result: Output from a previous deduplicate() call.
              Required for fast mode to identify cluster representatives.
              If None, falls back to thorough mode.

    Returns:
        List of ScoreResult, one per row, in input order.
    """
    if not rows:
        return []

    if text_field is None:
        from truva.data.loader import detect_text_field
        text_field = detect_text_field(rows)

    if mode == "fast" and dedupe_result is not None:
        return _score_fast(rows, judge, text_field, dedupe_result)
    else:
        return _score_thorough(rows, judge, text_field)


def _score_thorough(
    rows: list[dict[str, Any]],
    judge: JudgeModel,
    text_field: str,
) -> list[ScoreResult]:
    """Score every row individually."""
    return judge.score_batch(rows, text_field)


def _score_fast(
    rows: list[dict[str, Any]],
    judge: JudgeModel,
    text_field: str,
    dedupe_result: DedupeResult,
) -> list[ScoreResult]:
    """Score cluster representatives only; propagate to members with -1 penalty."""
    n = len(rows)

    # Build index: row_idx → cluster
    idx_to_cluster: dict[int, Cluster] = {}
    for cluster in dedupe_result.clusters:
        for member_idx in cluster.member_indices:
            idx_to_cluster[member_idx] = cluster

    # Collect unique representative rows to score
    rep_indices: list[int] = sorted(
        {c.representative_idx for c in dedupe_result.clusters}
    )
    rep_rows = [rows[i] for i in rep_indices]

    rep_results = judge.score_batch(rep_rows, text_field)

    # Build map: representative_idx → ScoreResult
    rep_score_map: dict[int, ScoreResult] = {
        rep_indices[i]: rep_results[i] for i in range(len(rep_indices))
    }

    # Propagate scores to all rows
    results: list[ScoreResult | None] = [None] * n
    for idx in range(n):
        cluster = idx_to_cluster.get(idx)
        if cluster is None:
            # Row not part of any cluster — score individually
            row_result = judge.score_batch([rows[idx]], text_field)[0]
            results[idx] = row_result
            continue

        rep_idx = cluster.representative_idx
        rep_result = rep_score_map.get(rep_idx)

        if rep_result is None or idx == rep_idx:
            # This IS the representative — use its score directly
            results[idx] = rep_score_map.get(idx) or judge.score_batch([rows[idx]], text_field)[0]
        else:
            # Non-representative member: propagate with -1 penalty
            propagated_score = max(1.0, rep_result.score - 1.0)
            results[idx] = ScoreResult(
                row_id=str(rows[idx].get("row_id", idx)),
                score=propagated_score,
                reasoning=f"Propagated from cluster representative (score {rep_result.score:.1f} - 1 penalty)",
                flags=list(rep_result.flags),
            )

    return [r for r in results if r is not None]


def filter_by_quality(
    rows: list[dict[str, Any]],
    scores: list[ScoreResult],
    min_quality: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Split rows into kept (score >= min_quality) and removed.

    Returns:
        (kept_rows, removed_rows)
    """
    kept, removed = [], []
    for row, result in zip(rows, scores):
        if result.score >= min_quality:
            kept.append({**row, "_score": result.score, "_flags": result.flags})
        else:
            removed.append({**row, "_score": result.score, "_flags": result.flags})
    return kept, removed
