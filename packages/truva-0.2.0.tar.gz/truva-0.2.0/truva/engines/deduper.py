"""Semantic deduplication via cosine similarity search and Union-Find clustering."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class Cluster:
    representative_idx: int
    member_indices: list[int]
    avg_similarity: float


@dataclass
class DedupeResult:
    kept_indices: list[int]
    removed_indices: list[int]
    clusters: list[Cluster]


class _UnionFind:
    """Disjoint-set data structure with path compression and union by rank."""

    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, x: int, y: int) -> None:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1


def deduplicate(
    embeddings: np.ndarray,
    rows: list[dict[str, Any]],
    threshold: float = 0.95,
) -> DedupeResult:
    """Remove semantically redundant rows using embedding similarity.

    Uses brute-force cosine similarity via numpy dot product on
    unit-normalized embeddings. Efficient for datasets up to ~100k rows.

    Args:
        embeddings: Unit-normalized embeddings of shape (n, dim).
        rows: Original dataset rows (used only for count validation).
        threshold: Cosine similarity threshold. Pairs above this are
            considered duplicates. 0.0 keeps everything, 1.0 removes
            only exact vector matches.

    Returns:
        DedupeResult with kept/removed indices and cluster details.
    """
    n = len(embeddings)
    if n != len(rows):
        raise ValueError(
            f"Embedding count ({n}) doesn't match row count ({len(rows)})"
        )

    if n == 0:
        return DedupeResult(kept_indices=[], removed_indices=[], clusters=[])

    if threshold <= 0.0:
        return DedupeResult(
            kept_indices=list(range(n)),
            removed_indices=[],
            clusters=[Cluster(i, [i], 1.0) for i in range(n)],
        )

    embeddings = np.ascontiguousarray(embeddings, dtype=np.float32)

    # Step 1: Compute pairwise cosine similarity (dot product on unit vectors)
    # For large datasets, process in blocks to limit memory usage.
    uf = _UnionFind(n)
    block_size = 1024

    for i_start in range(0, n, block_size):
        i_end = min(i_start + block_size, n)
        # Compute similarities between this block and all embeddings
        sims = embeddings[i_start:i_end] @ embeddings.T  # (block, n)

        for i_local in range(i_end - i_start):
            i = i_start + i_local
            for j in range(i + 1, n):
                if sims[i_local, j] >= threshold:
                    uf.union(i, j)

    # Step 2: Build clusters from Union-Find components
    components: dict[int, list[int]] = {}
    for i in range(n):
        root = uf.find(i)
        components.setdefault(root, []).append(i)

    # Step 3: For each cluster, pick representative closest to centroid
    clusters: list[Cluster] = []
    kept: list[int] = []
    removed: list[int] = []

    for members in components.values():
        if len(members) == 1:
            clusters.append(Cluster(members[0], members, 1.0))
            kept.append(members[0])
            continue

        member_embs = embeddings[members]
        centroid = member_embs.mean(axis=0)
        centroid /= np.linalg.norm(centroid) + 1e-10

        # Find member closest to centroid
        sims_to_centroid = member_embs @ centroid
        rep_local = int(np.argmax(sims_to_centroid))
        rep_idx = members[rep_local]

        # Average pairwise similarity within cluster
        pairwise = member_embs @ member_embs.T
        n_members = len(members)
        avg_sim = float(
            (pairwise.sum() - n_members) / max(n_members * (n_members - 1), 1)
        )

        clusters.append(Cluster(rep_idx, members, avg_sim))
        kept.append(rep_idx)
        removed.extend(m for m in members if m != rep_idx)

    kept.sort()
    removed.sort()

    return DedupeResult(kept_indices=kept, removed_indices=removed, clusters=clusters)
