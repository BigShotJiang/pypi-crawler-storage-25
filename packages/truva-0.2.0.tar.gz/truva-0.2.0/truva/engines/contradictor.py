"""Contradiction detection engine using NLI within semantic clusters."""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass
from typing import Any

from truva.engines.deduper import Cluster
from truva.models.nli import NLIModel

# Max pairwise comparisons per cluster to avoid O(n²) explosion
_MAX_PAIRS_PER_CLUSTER = 100


@dataclass
class Contradiction:
    row_a_id: str
    row_b_id: str
    text_a: str
    text_b: str
    confidence: float


def detect_contradictions(
    rows: list[dict[str, Any]],
    clusters: list[Cluster],
    nli: NLIModel,
    text_field: str,
    confidence_threshold: float = 0.8,
) -> list[Contradiction]:
    """Find contradicting row pairs within semantic clusters.

    Only rows that are semantically similar (in the same cluster) are
    compared, keeping the number of NLI calls tractable.

    Args:
        rows: Full dataset rows.
        clusters: Clusters from deduplicate(). Only clusters with >1
            member are checked.
        nli: An NLIModel instance.
        text_field: Field to extract text from each row.
        confidence_threshold: Minimum NLI confidence to flag a contradiction.

    Returns:
        List of Contradiction objects sorted by confidence descending.
    """
    pairs_to_check: list[tuple[int, int]] = []

    for cluster in clusters:
        if len(cluster.member_indices) < 2:
            continue

        all_pairs = list(itertools.combinations(cluster.member_indices, 2))

        if len(all_pairs) > _MAX_PAIRS_PER_CLUSTER:
            all_pairs = random.sample(all_pairs, _MAX_PAIRS_PER_CLUSTER)

        pairs_to_check.extend(all_pairs)

    if not pairs_to_check:
        return []

    # Extract text for each pair
    text_pairs = [
        (_get_text(rows[a], text_field), _get_text(rows[b], text_field))
        for a, b in pairs_to_check
    ]

    nli_results = nli.predict_batch(text_pairs)

    contradictions: list[Contradiction] = []
    for (idx_a, idx_b), nli_result, (text_a, text_b) in zip(
        pairs_to_check, nli_results, text_pairs
    ):
        if (
            nli_result.label == "contradiction"
            and nli_result.confidence >= confidence_threshold
        ):
            contradictions.append(Contradiction(
                row_a_id=str(rows[idx_a].get("row_id", idx_a)),
                row_b_id=str(rows[idx_b].get("row_id", idx_b)),
                text_a=text_a,
                text_b=text_b,
                confidence=nli_result.confidence,
            ))

    contradictions.sort(key=lambda c: c.confidence, reverse=True)
    return contradictions


def _get_text(row: dict[str, Any], text_field: str) -> str:
    if text_field in row:
        v = row[text_field]
        return str(v) if not isinstance(v, str) else v
    parts = [str(v) for k, v in row.items() if k != "row_id" and isinstance(v, str)]
    return " ".join(parts) if parts else str(row)
