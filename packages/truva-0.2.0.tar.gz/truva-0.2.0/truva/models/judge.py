"""Judge model abstraction for LLM-based quality scoring."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from tqdm import tqdm


@dataclass
class ScoreResult:
    row_id: str
    score: float
    reasoning: str
    flags: list[str] = field(default_factory=list)
    parse_error: bool = False


_DEFAULT_PROMPT = """\
You are a data quality judge for ML training datasets.

Rate the following training example on a scale of 1-10 for its educational value in fine-tuning a language model.

Consider:
- Completeness: Is the instruction and response fully formed?
- Specificity: Does it teach something concrete vs. being vague?
- Correctness: Is the information accurate and logically consistent?
- Complexity: Does it demonstrate non-trivial reasoning?
{calibration_block}
{rubric_block}
Example to score:
{row_text}

Respond with ONLY valid JSON (no markdown, no explanation outside the JSON):
{{"score": <1-10>, "reasoning": "<one sentence>", "flags": ["<issue1>", ...]}}

Valid flag values: vague, fragment, filler, repetitive, incorrect, incomplete, off-topic, low-complexity"""


class JudgeModel:
    """Score dataset rows using a local or API-based LLM judge.

    Args:
        provider: "ollama", "openai", or "anthropic".
        model_name: Model identifier.
        rubric: Optional domain-specific scoring rubric text.
        calibration_examples: Optional list of few-shot dicts with
            keys "text", "score", "reasoning".
    """

    def __init__(
        self,
        provider: str = "ollama",
        model_name: str | None = None,
        rubric: str | None = None,
        calibration_examples: list[dict[str, Any]] | None = None,
    ) -> None:
        self.provider = provider
        self.rubric = rubric
        self.calibration_examples = calibration_examples or []

        if provider == "ollama":
            self.model_name = model_name or "llama3:8b"
            self._client = self._load_ollama()
        elif provider == "openai":
            self.model_name = model_name or "gpt-4o-mini"
            self._client = self._load_openai()
        elif provider == "anthropic":
            self.model_name = model_name or "claude-haiku-4-5-20251001"
            self._client = self._load_anthropic()
        else:
            raise ValueError(
                f"Unknown provider: {provider!r}. Expected 'ollama', 'openai', or 'anthropic'"
            )

    def _load_ollama(self):
        try:
            import ollama
            return ollama
        except ImportError:
            raise ImportError(
                "ollama library required for local scoring. "
                "Install with: pip install 'truva[local]'"
            )

    def _load_openai(self):
        try:
            from openai import OpenAI
            return OpenAI()
        except ImportError:
            raise ImportError(
                "openai library required. Install with: pip install 'truva[api]'"
            )

    def _load_anthropic(self):
        try:
            import anthropic
            return anthropic.Anthropic()
        except ImportError:
            raise ImportError(
                "anthropic library required. Install with: pip install 'truva[api]'"
            )

    def score_batch(
        self,
        rows: list[dict[str, Any]],
        text_field: str,
        batch_size: int = 1,
    ) -> list[ScoreResult]:
        """Score a list of rows for information density.

        Args:
            rows: Dataset rows to score.
            text_field: The field to extract text from each row.
            batch_size: Unused for LLM judge (always 1 call per row),
                kept for interface consistency.

        Returns:
            List of ScoreResult in the same order as rows.
        """
        results: list[ScoreResult] = []
        for row in tqdm(rows, desc="Scoring", unit="row"):
            result = self._score_one(row, text_field)
            results.append(result)
        return results

    def _score_one(self, row: dict[str, Any], text_field: str) -> ScoreResult:
        row_id = str(row.get("row_id", ""))
        text = self._extract_text(row, text_field)
        prompt = self._build_prompt(text)

        raw = self._call_llm(prompt)
        result = self._parse_response(raw, row_id)

        if result.parse_error:
            # Retry once
            raw2 = self._call_llm(prompt)
            result = self._parse_response(raw2, row_id)
            if result.parse_error:
                result.score = 5.0
                result.flags = ["parse_error"]

        return result

    def _extract_text(self, row: dict[str, Any], text_field: str) -> str:
        if text_field in row:
            value = row[text_field]
            return str(value) if not isinstance(value, str) else value

        # Concatenate all string fields as fallback
        parts = [
            f"{k}: {v}" for k, v in row.items()
            if k != "row_id" and isinstance(v, str)
        ]
        return "\n".join(parts) if parts else str(row)

    def _build_prompt(self, row_text: str) -> str:
        calibration_block = ""
        if self.calibration_examples:
            lines = ["\nCalibration examples:"]
            for ex in self.calibration_examples:
                lines.append(
                    f'  - Text: "{ex["text"]}"\n'
                    f'    Score: {ex["score"]} — {ex.get("reasoning", "")}'
                )
            calibration_block = "\n".join(lines) + "\n"

        rubric_block = ""
        if self.rubric:
            rubric_block = f"\nScoring rubric:\n{self.rubric}\n"

        return _DEFAULT_PROMPT.format(
            calibration_block=calibration_block,
            rubric_block=rubric_block,
            row_text=row_text,
        )

    def _call_llm(self, prompt: str) -> str:
        if self.provider == "ollama":
            response = self._client.chat(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
            )
            return response["message"]["content"]

        elif self.provider == "openai":
            response = self._client.chat.completions.create(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
            )
            return response.choices[0].message.content or ""

        elif self.provider == "anthropic":
            response = self._client.messages.create(
                model=self.model_name,
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text

        return ""

    def _parse_response(self, raw: str, row_id: str) -> ScoreResult:
        # Strip markdown fences if present
        text = re.sub(r"```(?:json)?\s*", "", raw).strip()

        # Try to extract JSON object from the response
        match = re.search(r"\{[^{}]+\}", text, re.DOTALL)
        if not match:
            return ScoreResult(row_id=row_id, score=5.0, reasoning="", parse_error=True)

        try:
            data = json.loads(match.group())
        except json.JSONDecodeError:
            return ScoreResult(row_id=row_id, score=5.0, reasoning="", parse_error=True)

        score = float(data.get("score", 5))
        score = max(1.0, min(10.0, score))  # clamp to [1, 10]
        reasoning = str(data.get("reasoning", ""))
        flags = [str(f) for f in data.get("flags", []) if isinstance(f, str)]

        return ScoreResult(
            row_id=row_id,
            score=score,
            reasoning=reasoning,
            flags=flags,
            parse_error=False,
        )
