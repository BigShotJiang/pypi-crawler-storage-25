"""NLI model abstraction for contradiction detection."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class NLIResult:
    label: str  # "entailment" | "neutral" | "contradiction"
    confidence: float


class NLIModel:
    """Predict natural language inference labels for text pairs.

    Uses a CrossEncoder NLI model that runs on CPU.

    Args:
        model_name: HuggingFace model identifier.
            Default: "cross-encoder/nli-deberta-v3-base"
    """

    # Label order for cross-encoder/nli-deberta-v3-base
    _LABELS = ["contradiction", "entailment", "neutral"]

    def __init__(self, model_name: str = "cross-encoder/nli-deberta-v3-base") -> None:
        self.model_name = model_name
        self._model = self._load_model()

    def _load_model(self):
        from sentence_transformers import CrossEncoder
        return CrossEncoder(self.model_name)

    def predict_batch(
        self,
        pairs: list[tuple[str, str]],
        batch_size: int = 32,
    ) -> list[NLIResult]:
        """Predict NLI labels for a list of (premise, hypothesis) pairs.

        Args:
            pairs: List of (text_a, text_b) tuples to classify.
            batch_size: Batch size for inference.

        Returns:
            List of NLIResult in the same order as pairs.
        """
        if not pairs:
            return []

        raw_scores = self._model.predict(
            list(pairs),
            batch_size=batch_size,
            show_progress_bar=False,
        )

        results: list[NLIResult] = []
        for scores in raw_scores:
            # Apply softmax to get probabilities
            probs = _softmax(np.asarray(scores, dtype=np.float32))
            best_idx = int(np.argmax(probs))
            results.append(NLIResult(
                label=self._LABELS[best_idx],
                confidence=float(probs[best_idx]),
            ))

        return results


def _softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max())
    return e / e.sum()
