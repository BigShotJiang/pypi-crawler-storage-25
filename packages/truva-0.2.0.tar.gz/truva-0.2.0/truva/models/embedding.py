"""Embedding model abstraction for local and API-based models."""

from __future__ import annotations

import numpy as np
from tqdm import tqdm


class EmbeddingModel:
    """Generate vector embeddings using local or API-based models.

    Args:
        provider: "local" for sentence-transformers, "api" for OpenAI.
        model_name: Model identifier. Defaults depend on provider.
    """

    def __init__(
        self,
        provider: str = "local",
        model_name: str | None = None,
    ) -> None:
        self.provider = provider

        if provider == "local":
            self.model_name = model_name or "all-MiniLM-L6-v2"
            self._model = self._load_local_model()
        elif provider == "api":
            self.model_name = model_name or "text-embedding-3-small"
            self._client = self._load_api_client()
        else:
            raise ValueError(f"Unknown provider: {provider!r}. Expected 'local' or 'api'")

    def _load_local_model(self):
        from sentence_transformers import SentenceTransformer

        return SentenceTransformer(self.model_name)

    def _load_api_client(self):
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError(
                "OpenAI library required for API embeddings. "
                "Install with: pip install 'truva[api]'"
            )
        return OpenAI()

    @property
    def dimension(self) -> int:
        if self.provider == "local":
            return self._model.get_sentence_embedding_dimension()
        # OpenAI text-embedding-3-small is 1536-dim
        return 1536

    def embed_batch(
        self,
        texts: list[str],
        batch_size: int = 256,
    ) -> np.ndarray:
        """Embed a list of texts, returning unit-normalized vectors.

        Args:
            texts: Texts to embed.
            batch_size: Number of texts per batch.

        Returns:
            numpy array of shape (len(texts), embed_dim), L2-normalized.
        """
        if not texts:
            raise ValueError("Cannot embed empty list of texts")

        if self.provider == "local":
            return self._embed_local(texts, batch_size)
        else:
            return self._embed_api(texts, batch_size)

    def _embed_local(self, texts: list[str], batch_size: int) -> np.ndarray:
        all_embeddings: list[np.ndarray] = []

        for i in tqdm(range(0, len(texts), batch_size), desc="Embedding", unit="batch"):
            batch = texts[i : i + batch_size]
            embs = self._model.encode(batch, show_progress_bar=False, normalize_embeddings=True)
            all_embeddings.append(np.asarray(embs))

        result = np.vstack(all_embeddings)
        return _normalize(result)

    def _embed_api(self, texts: list[str], batch_size: int) -> np.ndarray:
        all_embeddings: list[np.ndarray] = []

        for i in tqdm(range(0, len(texts), batch_size), desc="Embedding (API)", unit="batch"):
            batch = texts[i : i + batch_size]
            response = self._client.embeddings.create(
                model=self.model_name,
                input=batch,
            )
            batch_embs = [np.array(item.embedding) for item in response.data]
            all_embeddings.extend(batch_embs)

        result = np.array(all_embeddings)
        return _normalize(result)


def _normalize(embeddings: np.ndarray) -> np.ndarray:
    """L2-normalize each row to unit vectors."""
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-10)
    return embeddings / norms
