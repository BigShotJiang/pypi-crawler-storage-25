"""Load and validate calibration configs for judge model few-shot prompting."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class CalibrationConfig:
    rubric: str = ""
    examples: list[dict[str, Any]] = field(default_factory=list)

    def validate(self) -> None:
        for i, ex in enumerate(self.examples):
            if "text" not in ex:
                raise ValueError(f"Calibration example {i} missing 'text' field")
            if "score" not in ex:
                raise ValueError(f"Calibration example {i} missing 'score' field")
            score = float(ex["score"])
            if not (1 <= score <= 10):
                raise ValueError(
                    f"Calibration example {i} score {score} out of range [1, 10]"
                )


def load_calibration(path: str) -> CalibrationConfig:
    """Load a calibration YAML file.

    Expected format:
        rubric: |
          Optional domain-specific scoring instructions.
        examples:
          - text: "example text"
            score: 8
            reasoning: "why this score"

    Args:
        path: Path to the YAML calibration file.

    Returns:
        CalibrationConfig with rubric and few-shot examples.
    """
    filepath = Path(path)
    if not filepath.exists():
        raise FileNotFoundError(f"Calibration file not found: {path}")

    with open(filepath) as f:
        data: dict[str, Any] = yaml.safe_load(f) or {}

    config = CalibrationConfig(
        rubric=str(data.get("rubric", "") or "").strip(),
        examples=list(data.get("examples", []) or []),
    )
    config.validate()
    return config
