"""Configuration dataclass for Truva pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class PipelineConfig:
    # Input
    input_path: str = ""
    input_format: str = "auto"
    text_field: str | None = None

    # Embedding
    embed_provider: str = "local"
    embed_model: str = "all-MiniLM-L6-v2"

    # Deduplication
    dedupe_threshold: float = 0.95

    # Scoring
    score_provider: str = "local"
    score_model: str = "llama3:8b"
    min_quality: float = 0.0
    score_mode: str = "fast"
    calibration_path: str | None = None
    rubric: str | None = None

    # Contradiction
    detect_contradictions: bool = False
    contradiction_confidence: float = 0.8

    # Output
    output_path: str = "./truva_output/"
    output_format: str = "jsonl"

    @classmethod
    def from_yaml(cls, path: str) -> PipelineConfig:
        """Load configuration from a YAML file."""
        with open(path) as f:
            data: dict[str, Any] = yaml.safe_load(f) or {}
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
