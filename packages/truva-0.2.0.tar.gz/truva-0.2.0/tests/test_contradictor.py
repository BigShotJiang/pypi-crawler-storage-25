"""Tests for the NLI model abstraction and contradiction detection engine."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from truva.engines.contradictor import (
    Contradiction,
    _MAX_PAIRS_PER_CLUSTER,
    _get_text,
    detect_contradictions,
)
from truva.engines.deduper import Cluster, DedupeResult
from truva.models.nli import NLIModel, NLIResult, _softmax

FIXTURES = Path(__file__).parent / "fixtures"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_rows(texts: list[str]) -> list[dict]:
    return [{"row_id": str(i), "text": t} for i, t in enumerate(texts)]


def _mock_nli(results: list[NLIResult]) -> NLIModel:
    """NLIModel whose predict_batch returns the given results."""
    nli = NLIModel.__new__(NLIModel)
    nli.model_name = "mock"
    nli._model = None
    nli._results = iter(results)

    def fake_predict_batch(pairs, batch_size=32):
        out = []
        for _ in pairs:
            out.append(next(nli._results))
        return out

    nli.predict_batch = fake_predict_batch
    return nli


# ── _softmax ──────────────────────────────────────────────────────────────────

class TestSoftmax:
    def test_sums_to_one(self):
        x = np.array([1.0, 2.0, 0.5])
        probs = _softmax(x)
        assert abs(probs.sum() - 1.0) < 1e-6

    def test_argmax_preserved(self):
        x = np.array([0.1, 5.0, 0.3])
        probs = _softmax(x)
        assert np.argmax(probs) == 1

    def test_uniform_input(self):
        x = np.array([1.0, 1.0, 1.0])
        probs = _softmax(x)
        np.testing.assert_allclose(probs, [1/3, 1/3, 1/3], atol=1e-6)


# ── _get_text ─────────────────────────────────────────────────────────────────

class TestGetText:
    def test_uses_text_field(self):
        row = {"row_id": "1", "text": "hello", "other": "ignore"}
        assert _get_text(row, "text") == "hello"

    def test_fallback_concatenates_strings(self):
        row = {"row_id": "1", "a": "foo", "b": "bar"}
        result = _get_text(row, "missing")
        assert "foo" in result and "bar" in result

    def test_converts_non_string(self):
        row = {"row_id": "1", "count": 42}
        result = _get_text(row, "count")
        assert result == "42"


# ── detect_contradictions ────────────────────────────────────────────────────

class TestDetectContradictions:
    def test_contradiction_detected(self):
        rows = _make_rows(["Refunds are instant.", "Refunds take 5 days."])
        clusters = [Cluster(0, [0, 1], 0.96)]
        nli = _mock_nli([NLIResult("contradiction", 0.92)])

        result = detect_contradictions(rows, clusters, nli, "text", confidence_threshold=0.8)
        assert len(result) == 1
        assert result[0].row_a_id == "0"
        assert result[0].row_b_id == "1"
        assert result[0].confidence == pytest.approx(0.92)

    def test_neutral_pair_not_flagged(self):
        rows = _make_rows(["Python is a language.", "Python is interpreted."])
        clusters = [Cluster(0, [0, 1], 0.93)]
        nli = _mock_nli([NLIResult("neutral", 0.88)])

        result = detect_contradictions(rows, clusters, nli, "text")
        assert len(result) == 0

    def test_entailment_not_flagged(self):
        rows = _make_rows(["Paris is the capital of France.", "France's capital is Paris."])
        clusters = [Cluster(0, [0, 1], 0.99)]
        nli = _mock_nli([NLIResult("entailment", 0.97)])

        result = detect_contradictions(rows, clusters, nli, "text")
        assert len(result) == 0

    def test_below_confidence_threshold_not_flagged(self):
        rows = _make_rows(["A", "B"])
        clusters = [Cluster(0, [0, 1], 0.95)]
        nli = _mock_nli([NLIResult("contradiction", 0.65)])

        result = detect_contradictions(rows, clusters, nli, "text", confidence_threshold=0.8)
        assert len(result) == 0

    def test_single_member_cluster_skipped(self):
        rows = _make_rows(["only one"])
        clusters = [Cluster(0, [0], 1.0)]
        nli = _mock_nli([])

        result = detect_contradictions(rows, clusters, nli, "text")
        assert len(result) == 0

    def test_empty_clusters(self):
        rows = _make_rows(["a", "b"])
        result = detect_contradictions(rows, [], MagicMock(), "text")
        assert result == []

    def test_multiple_contradictions_sorted_by_confidence(self):
        rows = _make_rows(["a", "b", "c", "d"])
        clusters = [
            Cluster(0, [0, 1], 0.95),
            Cluster(2, [2, 3], 0.95),
        ]
        nli = _mock_nli([
            NLIResult("contradiction", 0.85),
            NLIResult("contradiction", 0.95),
        ])

        result = detect_contradictions(rows, clusters, nli, "text", confidence_threshold=0.8)
        assert len(result) == 2
        assert result[0].confidence > result[1].confidence  # sorted descending

    def test_large_cluster_sampled(self):
        """Clusters >15 members should be sampled to ≤ MAX_PAIRS_PER_CLUSTER."""
        n = 20  # 20 members → 190 pairs without sampling
        rows = _make_rows([f"text {i}" for i in range(n)])
        clusters = [Cluster(0, list(range(n)), 0.96)]

        call_count = 0
        original = NLIModel.predict_batch

        nli = NLIModel.__new__(NLIModel)
        nli.model_name = "mock"
        nli._model = None

        pairs_seen: list = []

        def counting_predict(pairs, batch_size=32):
            pairs_seen.extend(pairs)
            return [NLIResult("neutral", 0.9) for _ in pairs]

        nli.predict_batch = counting_predict

        detect_contradictions(rows, clusters, nli, "text")
        assert len(pairs_seen) <= _MAX_PAIRS_PER_CLUSTER

    def test_result_contains_text(self):
        rows = _make_rows(["Refunds are instant.", "Refunds take 5 days."])
        clusters = [Cluster(0, [0, 1], 0.96)]
        nli = _mock_nli([NLIResult("contradiction", 0.91)])

        result = detect_contradictions(rows, clusters, nli, "text")
        assert result[0].text_a == "Refunds are instant."
        assert result[0].text_b == "Refunds take 5 days."

    def test_three_member_cluster_checks_all_pairs(self):
        """3 members → 3 pairs: (0,1), (0,2), (1,2)."""
        rows = _make_rows(["a", "b", "c"])
        clusters = [Cluster(0, [0, 1, 2], 0.95)]
        nli = _mock_nli([
            NLIResult("neutral", 0.8),
            NLIResult("contradiction", 0.9),
            NLIResult("neutral", 0.7),
        ])

        result = detect_contradictions(rows, clusters, nli, "text", confidence_threshold=0.8)
        assert len(result) == 1
        assert result[0].confidence == pytest.approx(0.9)


# ── Integration test with real NLI model ──────────────────────────────────────

class TestNLIModelIntegration:
    @pytest.fixture(scope="class")
    def nli(self):
        return NLIModel()

    def test_loads(self, nli):
        assert nli.model_name == "cross-encoder/nli-deberta-v3-base"

    def test_contradiction_detected(self, nli):
        pairs = [("Refunds are processed instantly.", "Refunds take 3 to 5 business days.")]
        results = nli.predict_batch(pairs)
        assert len(results) == 1
        assert results[0].label == "contradiction"
        assert results[0].confidence > 0.5

    def test_entailment_detected(self, nli):
        pairs = [("The capital of France is Paris.", "Paris is the capital city of France.")]
        results = nli.predict_batch(pairs)
        assert results[0].label in ("entailment", "neutral")  # paraphrase ≥ neutral

    def test_neutral_detected(self, nli):
        pairs = [("Python is a programming language.", "The sky is blue.")]
        results = nli.predict_batch(pairs)
        assert results[0].label == "neutral"

    def test_empty_pairs(self, nli):
        assert nli.predict_batch([]) == []

    def test_batch_returns_one_per_pair(self, nli):
        pairs = [
            ("Refunds are instant.", "Refunds take 5 days."),
            ("Paris is in France.", "France contains Paris."),
        ]
        results = nli.predict_batch(pairs)
        assert len(results) == 2
        for r in results:
            assert r.label in ("contradiction", "entailment", "neutral")
            assert 0.0 <= r.confidence <= 1.0

    def test_real_fixture_contradictions(self, nli):
        """Load the fixture and verify known contradicting pairs are caught."""
        from truva.data.loader import load_dataset
        from truva.engines.deduper import Cluster

        rows = load_dataset(str(FIXTURES / "sample_contradictions.jsonl"))

        # Manually define the clusters we know should contain contradictions
        # c1a/c1b = refund timing contradiction
        idx = {r["row_id"]: i for i, r in enumerate(rows)}
        clusters = [
            Cluster(idx["c1a"], [idx["c1a"], idx["c1b"]], 0.93),
        ]

        result = detect_contradictions(rows, clusters, nli, "response", confidence_threshold=0.7)
        assert len(result) >= 1
        row_ids = {(c.row_a_id, c.row_b_id) for c in result}
        assert ("c1a", "c1b") in row_ids or ("c1b", "c1a") in row_ids
