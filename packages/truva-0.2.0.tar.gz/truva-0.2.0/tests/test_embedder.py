"""Tests for the embedder engine and embedding model."""

import numpy as np
import pytest

from truva.engines.embedder import compute_embeddings, _extract_texts
from truva.models.embedding import EmbeddingModel, _normalize


class TestNormalize:
    def test_unit_vectors(self):
        vecs = np.array([[3.0, 4.0], [1.0, 0.0]])
        normed = _normalize(vecs)
        norms = np.linalg.norm(normed, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-6)

    def test_zero_vector(self):
        vecs = np.array([[0.0, 0.0]])
        normed = _normalize(vecs)
        # Should not produce NaN
        assert not np.any(np.isnan(normed))


class TestExtractTexts:
    def test_single_field(self):
        rows = [{"text": "hello"}, {"text": "world"}]
        texts = _extract_texts(rows, "text")
        assert texts == ["hello", "world"]

    def test_fallback_concatenation(self):
        rows = [{"a": "hello", "b": "world", "row_id": "123"}]
        texts = _extract_texts(rows, "missing_field")
        assert texts == ["hello world"]

    def test_non_string_conversion(self):
        rows = [{"val": 42}]
        texts = _extract_texts(rows, "val")
        assert texts == ["42"]

    def test_no_text_content_raises(self):
        rows = [{"row_id": "123"}]
        with pytest.raises(ValueError, match="no text content"):
            _extract_texts(rows, "missing")


class TestEmbeddingModel:
    @pytest.fixture
    def local_model(self):
        return EmbeddingModel(provider="local", model_name="all-MiniLM-L6-v2")

    def test_local_model_loads(self, local_model):
        assert local_model.provider == "local"
        assert local_model.dimension == 384

    def test_embed_batch(self, local_model):
        texts = ["Hello world", "Goodbye world"]
        embeddings = local_model.embed_batch(texts)
        assert embeddings.shape == (2, 384)

    def test_embeddings_are_normalized(self, local_model):
        texts = ["Test sentence one", "Test sentence two", "Something different"]
        embeddings = local_model.embed_batch(texts)
        norms = np.linalg.norm(embeddings, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-6)

    def test_similar_texts_have_high_cosine(self, local_model):
        texts = ["How to reset my password", "I need to change my password"]
        embs = local_model.embed_batch(texts)
        cosine = np.dot(embs[0], embs[1])
        assert cosine > 0.7

    def test_different_texts_have_lower_cosine(self, local_model):
        texts = ["How to reset my password", "What is the weather today"]
        embs = local_model.embed_batch(texts)
        cosine = np.dot(embs[0], embs[1])
        assert cosine < 0.5

    def test_empty_list_raises(self, local_model):
        with pytest.raises(ValueError, match="empty"):
            local_model.embed_batch([])

    def test_invalid_provider(self):
        with pytest.raises(ValueError, match="Unknown provider"):
            EmbeddingModel(provider="invalid")


class TestComputeEmbeddings:
    @pytest.fixture
    def local_model(self):
        return EmbeddingModel(provider="local")

    def test_basic(self, local_model):
        rows = [
            {"row_id": "1", "instruction": "What is Python?", "response": "A language"},
            {"row_id": "2", "instruction": "What is Java?", "response": "Another language"},
        ]
        embs = compute_embeddings(rows, model=local_model, text_field="instruction")
        assert embs.shape == (2, 384)

    def test_auto_detect_field(self, local_model):
        rows = [
            {"row_id": "1", "text": "Hello world"},
            {"row_id": "2", "text": "Goodbye world"},
        ]
        embs = compute_embeddings(rows, model=local_model)
        assert embs.shape == (2, 384)

    def test_empty_rows_raises(self, local_model):
        with pytest.raises(ValueError):
            compute_embeddings([], model=local_model)
