"""Tests for the data loader."""

import json
import tempfile
from pathlib import Path

import pytest

from truva.data.loader import detect_text_field, load_dataset

FIXTURES = Path(__file__).parent / "fixtures"


class TestLoadJsonl:
    def test_load_sample_50(self):
        rows = load_dataset(str(FIXTURES / "sample_50.jsonl"))
        assert len(rows) == 50
        assert all("row_id" in r for r in rows)
        assert all("instruction" in r for r in rows)
        assert all("response" in r for r in rows)

    def test_preserves_fields(self):
        rows = load_dataset(str(FIXTURES / "sample_50.jsonl"))
        assert rows[0]["instruction"] == "What is Python?"

    def test_row_ids_are_unique(self):
        rows = load_dataset(str(FIXTURES / "sample_50.jsonl"))
        ids = [r["row_id"] for r in rows]
        assert len(ids) == len(set(ids))

    def test_preserves_existing_row_id(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
            f.write(json.dumps({"row_id": "my-id", "text": "hello"}) + "\n")
            path = f.name

        rows = load_dataset(path)
        assert rows[0]["row_id"] == "my-id"

    def test_empty_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
            f.write("")
            path = f.name

        rows = load_dataset(path)
        assert rows == []

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_dataset("/nonexistent/path.jsonl")

    def test_invalid_json(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
            f.write("not json\n")
            path = f.name

        with pytest.raises(ValueError, match="Invalid JSON"):
            load_dataset(path)


class TestLoadCsv:
    def test_load_csv(self):
        rows = load_dataset(str(FIXTURES / "sample_3.csv"))
        assert len(rows) == 3
        assert all("row_id" in r for r in rows)
        assert rows[0]["question"] == "What is Python?"

    def test_invalid_text_column(self):
        with pytest.raises(ValueError, match="not found"):
            load_dataset(str(FIXTURES / "sample_3.csv"), text_column="nonexistent")


class TestDetectTextField:
    def test_auto_detects_longest_string_field(self):
        rows = [
            {"id": "1", "short": "hi", "long_text": "This is a much longer piece of text"},
            {"id": "2", "short": "yo", "long_text": "Another long piece of text here too"},
        ]
        field = detect_text_field(rows)
        assert field == "long_text"

    def test_explicit_column(self):
        rows = [{"a": "short", "b": "long text here"}]
        assert detect_text_field(rows, text_column="a") == "a"

    def test_invalid_explicit_column(self):
        rows = [{"a": "text"}]
        with pytest.raises(ValueError, match="not found"):
            detect_text_field(rows, text_column="missing")

    def test_empty_dataset(self):
        with pytest.raises(ValueError, match="empty"):
            detect_text_field([])

    def test_no_string_fields(self):
        rows = [{"a": 1, "b": 2}]
        with pytest.raises(ValueError, match="No string fields"):
            detect_text_field(rows)
