"""Tests for the scoring engine, judge model parsing, and calibration loader."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from truva.calibration.calibrator import CalibrationConfig, load_calibration
from truva.engines.deduper import Cluster, DedupeResult
from truva.engines.scorer import filter_by_quality, score_dataset
from truva.models.judge import JudgeModel, ScoreResult


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_rows(texts: list[str]) -> list[dict]:
    return [{"row_id": str(i), "text": t} for i, t in enumerate(texts)]


def _mock_judge(responses: list[str]) -> JudgeModel:
    """Return a JudgeModel whose _call_llm returns successive responses."""
    judge = JudgeModel.__new__(JudgeModel)
    judge.provider = "ollama"
    judge.model_name = "llama3:8b"
    judge.rubric = None
    judge.calibration_examples = []
    judge._client = None
    judge._responses = iter(responses)
    judge._call_llm = lambda prompt: next(judge._responses)
    return judge


# ── JudgeModel._parse_response ────────────────────────────────────────────────

class TestParseResponse:
    def _judge(self) -> JudgeModel:
        return _mock_judge([])

    def test_valid_json(self):
        j = self._judge()
        result = j._parse_response('{"score": 8, "reasoning": "Good", "flags": []}', "r1")
        assert result.score == 8.0
        assert result.reasoning == "Good"
        assert result.flags == []
        assert not result.parse_error

    def test_score_clamped_high(self):
        j = self._judge()
        result = j._parse_response('{"score": 15, "reasoning": "Too high", "flags": []}', "r1")
        assert result.score == 10.0

    def test_score_clamped_low(self):
        j = self._judge()
        result = j._parse_response('{"score": -3, "reasoning": "Too low", "flags": []}', "r1")
        assert result.score == 1.0

    def test_with_flags(self):
        j = self._judge()
        result = j._parse_response(
            '{"score": 2, "reasoning": "Vague", "flags": ["vague", "filler"]}', "r1"
        )
        assert result.flags == ["vague", "filler"]

    def test_json_in_markdown_fence(self):
        j = self._judge()
        raw = '```json\n{"score": 7, "reasoning": "OK", "flags": []}\n```'
        result = j._parse_response(raw, "r1")
        assert result.score == 7.0
        assert not result.parse_error

    def test_json_embedded_in_prose(self):
        j = self._judge()
        raw = 'Here is my evaluation: {"score": 6, "reasoning": "Decent", "flags": []} — done.'
        result = j._parse_response(raw, "r1")
        assert result.score == 6.0

    def test_no_json(self):
        j = self._judge()
        result = j._parse_response("I cannot score this.", "r1")
        assert result.parse_error

    def test_malformed_json(self):
        j = self._judge()
        result = j._parse_response("{score: 5, reasoning: bad}", "r1")
        assert result.parse_error

    def test_missing_score_field(self):
        j = self._judge()
        result = j._parse_response('{"reasoning": "OK", "flags": []}', "r1")
        # Should use default score of 5 from data.get("score", 5)
        assert result.score == 5.0


# ── JudgeModel retry logic ────────────────────────────────────────────────────

class TestJudgeRetry:
    def test_retry_on_parse_error(self):
        """First response is invalid, second is valid — should use second."""
        judge = _mock_judge([
            "not json at all",
            '{"score": 9, "reasoning": "Retry worked", "flags": []}',
        ])
        row = {"row_id": "1", "text": "Test"}
        result = judge._score_one(row, "text")
        assert result.score == 9.0
        assert not result.parse_error

    def test_two_parse_failures_fallback(self):
        """Two bad responses → score 5 with parse_error flag."""
        judge = _mock_judge(["bad", "also bad"])
        row = {"row_id": "1", "text": "Test"}
        result = judge._score_one(row, "text")
        assert result.score == 5.0
        assert "parse_error" in result.flags


# ── JudgeModel.score_batch ────────────────────────────────────────────────────

class TestScoreBatch:
    def test_returns_one_result_per_row(self):
        responses = [
            '{"score": 8, "reasoning": "Good", "flags": []}',
            '{"score": 2, "reasoning": "Bad", "flags": ["filler"]}',
        ]
        judge = _mock_judge(responses)
        rows = _make_rows(["detailed answer", "yes"])
        results = judge.score_batch(rows, "text")
        assert len(results) == 2
        assert results[0].score == 8.0
        assert results[1].score == 2.0

    def test_filler_row_scores_low(self):
        """'Yes' should score 1-3 according to the prompt."""
        responses = ['{"score": 1, "reasoning": "Zero value", "flags": ["filler"]}']
        judge = _mock_judge(responses)
        rows = _make_rows(["Yes"])
        results = judge.score_batch(rows, "text")
        assert results[0].score <= 3.0
        assert "filler" in results[0].flags


# ── JudgeModel provider validation ───────────────────────────────────────────

class TestJudgeModelInit:
    def test_invalid_provider(self):
        with pytest.raises(ValueError, match="Unknown provider"):
            JudgeModel(provider="grok")

    def test_ollama_missing_import(self):
        with patch.dict("sys.modules", {"ollama": None}):
            with pytest.raises((ImportError, TypeError)):
                JudgeModel(provider="ollama")


# ── Scorer engine ─────────────────────────────────────────────────────────────

class TestScoreDataset:
    def _make_dedupe_result(self, n_rows: int, cluster_size: int) -> DedupeResult:
        """Build a DedupeResult with one cluster per cluster_size rows."""
        clusters = []
        kept, removed = [], []
        for start in range(0, n_rows, cluster_size):
            members = list(range(start, min(start + cluster_size, n_rows)))
            rep = members[0]
            clusters.append(Cluster(rep, members, 0.97))
            kept.append(rep)
            removed.extend(m for m in members if m != rep)
        return DedupeResult(kept_indices=kept, removed_indices=removed, clusters=clusters)

    def test_thorough_scores_all_rows(self):
        n = 5
        responses = [f'{{"score": {i+1}, "reasoning": "ok", "flags": []}}' for i in range(n)]
        judge = _mock_judge(responses)
        rows = _make_rows([f"text {i}" for i in range(n)])
        results = score_dataset(rows, judge, text_field="text", mode="thorough")
        assert len(results) == n

    def test_fast_mode_fewer_judge_calls(self):
        """Fast mode with 10 clusters of 3 rows each → only 10 judge calls."""
        n_clusters = 3
        cluster_size = 3
        n_rows = n_clusters * cluster_size

        call_count = 0
        responses = [f'{{"score": 8, "reasoning": "ok", "flags": []}}' for _ in range(n_clusters)]
        judge = _mock_judge(responses)
        original_score_batch = judge.score_batch

        rows = _make_rows([f"text {i}" for i in range(n_rows)])
        dedupe_result = self._make_dedupe_result(n_rows, cluster_size)

        results = score_dataset(
            rows, judge, text_field="text", mode="fast", dedupe_result=dedupe_result
        )

        assert len(results) == n_rows

    def test_fast_mode_propagates_with_penalty(self):
        """Non-representative members get rep_score - 1."""
        # 1 cluster: rows 0 (rep), 1, 2
        dedupe_result = DedupeResult(
            kept_indices=[0],
            removed_indices=[1, 2],
            clusters=[Cluster(0, [0, 1, 2], 0.98)],
        )
        judge = _mock_judge(['{"score": 8, "reasoning": "Good", "flags": []}'])
        rows = _make_rows(["rep text", "dup 1", "dup 2"])
        results = score_dataset(rows, judge, text_field="text", mode="fast", dedupe_result=dedupe_result)

        assert results[0].score == 8.0   # representative
        assert results[1].score == 7.0   # penalized
        assert results[2].score == 7.0   # penalized

    def test_empty_dataset(self):
        judge = _mock_judge([])
        results = score_dataset([], judge, text_field="text")
        assert results == []

    def test_fast_falls_back_without_dedupe_result(self):
        """Fast mode without dedupe_result → thorough scoring."""
        responses = ['{"score": 6, "reasoning": "ok", "flags": []}'] * 2
        judge = _mock_judge(responses)
        rows = _make_rows(["a", "b"])
        results = score_dataset(rows, judge, text_field="text", mode="fast", dedupe_result=None)
        assert len(results) == 2


# ── filter_by_quality ─────────────────────────────────────────────────────────

class TestFilterByQuality:
    def _scores(self, values: list[float]) -> list[ScoreResult]:
        return [ScoreResult(row_id=str(i), score=v, reasoning="") for i, v in enumerate(values)]

    def test_keeps_above_threshold(self):
        rows = _make_rows(["high", "low", "mid"])
        scores = self._scores([8.0, 2.0, 6.0])
        kept, removed = filter_by_quality(rows, scores, min_quality=6.0)
        assert len(kept) == 2
        assert len(removed) == 1

    def test_zero_min_quality_keeps_all(self):
        rows = _make_rows(["a", "b"])
        scores = self._scores([1.0, 1.0])
        kept, removed = filter_by_quality(rows, scores, min_quality=0.0)
        assert len(kept) == 2
        assert len(removed) == 0

    def test_score_attached_to_row(self):
        rows = _make_rows(["text"])
        scores = self._scores([7.5])
        kept, _ = filter_by_quality(rows, scores, min_quality=5.0)
        assert kept[0]["_score"] == 7.5


# ── CalibrationConfig + load_calibration ─────────────────────────────────────

class TestCalibration:
    def test_load_valid_yaml(self, tmp_path):
        content = """
rubric: |
  Prioritize clinical accuracy.
examples:
  - text: "pt presents with SOB"
    score: 9
    reasoning: "Clinically precise"
  - text: "patient is unwell"
    score: 3
    reasoning: "Vague"
"""
        f = tmp_path / "cal.yaml"
        f.write_text(content)
        config = load_calibration(str(f))
        assert "clinical" in config.rubric
        assert len(config.examples) == 2
        assert config.examples[0]["score"] == 9

    def test_missing_file(self):
        with pytest.raises(FileNotFoundError):
            load_calibration("/nonexistent/path.yaml")

    def test_missing_text_field(self, tmp_path):
        content = "examples:\n  - score: 5\n    reasoning: missing text\n"
        f = tmp_path / "bad.yaml"
        f.write_text(content)
        with pytest.raises(ValueError, match="missing 'text'"):
            load_calibration(str(f))

    def test_missing_score_field(self, tmp_path):
        content = "examples:\n  - text: some text\n    reasoning: no score\n"
        f = tmp_path / "bad.yaml"
        f.write_text(content)
        with pytest.raises(ValueError, match="missing 'score'"):
            load_calibration(str(f))

    def test_score_out_of_range(self, tmp_path):
        content = "examples:\n  - text: hi\n    score: 15\n"
        f = tmp_path / "bad.yaml"
        f.write_text(content)
        with pytest.raises(ValueError, match="out of range"):
            load_calibration(str(f))

    def test_empty_yaml(self, tmp_path):
        f = tmp_path / "empty.yaml"
        f.write_text("")
        config = load_calibration(str(f))
        assert config.rubric == ""
        assert config.examples == []

    def test_rubric_injected_into_prompt(self):
        judge = _mock_judge([])
        judge.rubric = "Prefer clinical specificity."
        judge.calibration_examples = []
        prompt = judge._build_prompt("some text")
        assert "clinical specificity" in prompt

    def test_calibration_examples_injected(self):
        judge = _mock_judge([])
        judge.rubric = None
        judge.calibration_examples = [
            {"text": "great example", "score": 9, "reasoning": "specific"}
        ]
        prompt = judge._build_prompt("some text")
        assert "great example" in prompt
        assert "9" in prompt
