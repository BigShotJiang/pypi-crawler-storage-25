"""Tests for the Pipeline orchestrator and AuditResult report generator."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from truva.config import PipelineConfig
from truva.pipeline import Pipeline
from truva.report.generator import AuditResult, generate_report

FIXTURES = Path(__file__).parent / "fixtures"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_rows(n: int) -> list[dict]:
    return [{"row_id": str(i), "text": f"row text number {i}"} for i in range(n)]


def _make_embeddings(n: int, dim: int = 8) -> np.ndarray:
    rng = np.random.default_rng(42)
    e = rng.random((n, dim)).astype(np.float32)
    norms = np.linalg.norm(e, axis=1, keepdims=True)
    return e / norms


def _minimal_config(**overrides) -> PipelineConfig:
    defaults = dict(
        embed_provider="local",
        embed_model="all-MiniLM-L6-v2",
        dedupe_threshold=0.0,      # skip dedup
        score_provider="ollama",
        score_model=None,
        min_quality=0.0,            # skip scoring
        score_mode="fast",
        calibration_path=None,
        rubric=None,
        detect_contradictions=False,
        contradiction_confidence=0.8,
        output_path="/tmp/truva_test_output",
        output_format="jsonl",
        input_format="auto",
        text_field=None,
    )
    defaults.update(overrides)
    return PipelineConfig(**defaults)


# ── AuditResult ───────────────────────────────────────────────────────────────

class TestAuditResult:
    def test_defaults(self):
        audit = AuditResult()
        assert audit.input_rows == 0
        assert audit.rows_after_dedupe is None
        assert audit.rows_after_scoring is None
        assert audit.contradictions_found == 0
        assert audit.gold_rows == 0
        assert audit.gold_row_indices == []
        assert audit.scores == {}
        assert audit.contradictions == []
        assert audit.clusters == []
        assert audit.config_snapshot == {}

    def test_config_snapshot_stored(self):
        snap = {"embed_provider": "local", "dedupe_threshold": 0.95}
        audit = AuditResult(config_snapshot=snap)
        assert audit.config_snapshot["embed_provider"] == "local"


# ── generate_report ───────────────────────────────────────────────────────────

class TestGenerateReport:
    def test_writes_report_json(self, tmp_path):
        audit = AuditResult(
            input_rows=100,
            rows_after_dedupe=80,
            rows_after_scoring=60,
            gold_rows=60,
            contradictions_found=2,
        )
        generate_report(audit, str(tmp_path))
        report_path = tmp_path / "report.json"
        assert report_path.exists()
        data = json.loads(report_path.read_text())
        assert data["summary"]["input_rows"] == 100
        assert data["summary"]["gold_rows"] == 60
        assert data["summary"]["contradictions_found"] == 2

    def test_report_stages_include_dedup(self, tmp_path):
        audit = AuditResult(input_rows=100, rows_after_dedupe=75, gold_rows=75)
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        stage_names = [s["stage"] for s in data["stages"]]
        assert "deduplication" in stage_names

    def test_report_stages_include_quality_filter(self, tmp_path):
        audit = AuditResult(
            input_rows=100, rows_after_dedupe=80, rows_after_scoring=50, gold_rows=50
        )
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        stage_names = [s["stage"] for s in data["stages"]]
        assert "quality_filter" in stage_names

    def test_total_reduction_pct(self, tmp_path):
        audit = AuditResult(input_rows=100, gold_rows=25)
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        assert data["summary"]["total_reduction_pct"] == pytest.approx(75.0)

    def test_no_dedup_stage_when_skipped(self, tmp_path):
        audit = AuditResult(input_rows=50, gold_rows=50)
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        stage_names = [s["stage"] for s in data["stages"]]
        assert "deduplication" not in stage_names

    def test_tokens_saved_estimate(self, tmp_path):
        audit = AuditResult(input_rows=100, gold_rows=0)
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        # 100 removed rows × 500 tokens each
        assert data["summary"]["estimated_tokens_saved"] == 50_000

    def test_clusters_capped_at_50(self, tmp_path):
        audit = AuditResult(
            input_rows=100,
            gold_rows=100,
            clusters=[{"representative_idx": i, "size": 2, "avg_similarity": 0.9} for i in range(60)],
        )
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        assert len(data["clusters"]) == 50

    def test_contradictions_in_report(self, tmp_path):
        audit = AuditResult(
            input_rows=10,
            gold_rows=10,
            contradictions_found=1,
            contradictions=[
                {"row_a_id": "a", "row_b_id": "b", "text_a": "X", "text_b": "Y", "confidence": 0.9}
            ],
        )
        generate_report(audit, str(tmp_path))
        data = json.loads((tmp_path / "report.json").read_text())
        assert len(data["contradictions"]) == 1
        assert data["contradictions"][0]["row_a_id"] == "a"

    def test_zero_input_rows_no_division_error(self, tmp_path):
        audit = AuditResult(input_rows=0, gold_rows=0)
        report = generate_report(audit, str(tmp_path))
        assert report["summary"]["total_reduction_pct"] == 0.0


# ── Pipeline (mocked engines) ──────────────────────────────────────────────────

class TestPipelineEmptyDataset:
    def test_empty_input_returns_zero_gold(self, tmp_path):
        cfg = _minimal_config(output_path=str(tmp_path))
        pipeline = Pipeline(cfg)

        with patch("truva.data.loader.load_dataset", return_value=[]):
            result = pipeline.run("fake_path.jsonl")

        assert result.input_rows == 0
        assert result.gold_rows == 0


class TestPipelineSkipAllSteps:
    """Embed only, no dedup, no scoring, no contradictions."""

    def test_all_rows_become_gold(self, tmp_path):
        rows = _make_rows(5)
        embeddings = _make_embeddings(5)
        cfg = _minimal_config(output_path=str(tmp_path))
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.data.writer.write_jsonl"),
        ):
            result = pipeline.run("fake.jsonl")

        assert result.input_rows == 5
        assert result.gold_rows == 5
        assert result.rows_after_dedupe is None
        assert result.rows_after_scoring is None


class TestPipelineWithDedup:
    def test_dedup_reduces_rows(self, tmp_path):
        from truva.engines.deduper import Cluster, DedupeResult

        rows = _make_rows(10)
        embeddings = _make_embeddings(10)
        kept = [0, 2, 4, 6, 8]
        dedupe_result = DedupeResult(
            kept_indices=kept,
            removed_indices=[1, 3, 5, 7, 9],
            clusters=[Cluster(i, [i, i + 1], 0.97) for i in range(0, 10, 2)],
        )

        cfg = _minimal_config(output_path=str(tmp_path), dedupe_threshold=0.95)
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.engines.deduper.deduplicate", return_value=dedupe_result),
            patch("truva.data.writer.write_jsonl"),
        ):
            result = pipeline.run("fake.jsonl")

        assert result.input_rows == 10
        assert result.rows_after_dedupe == 5
        assert result.gold_rows == 5

    def test_cluster_summary_stored(self, tmp_path):
        from truva.engines.deduper import Cluster, DedupeResult

        rows = _make_rows(4)
        embeddings = _make_embeddings(4)
        dedupe_result = DedupeResult(
            kept_indices=[0, 2],
            removed_indices=[1, 3],
            clusters=[
                Cluster(0, [0, 1], 0.96),
                Cluster(2, [2, 3], 0.97),
            ],
        )

        cfg = _minimal_config(output_path=str(tmp_path), dedupe_threshold=0.95)
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.engines.deduper.deduplicate", return_value=dedupe_result),
            patch("truva.data.writer.write_jsonl"),
        ):
            result = pipeline.run("fake.jsonl")

        assert len(result.clusters) == 2
        assert result.clusters[0]["representative_idx"] == 0


class TestPipelineWithScoring:
    def test_scoring_filters_low_quality(self, tmp_path):
        from truva.engines.scorer import ScoreResult

        rows = _make_rows(6)
        embeddings = _make_embeddings(6)

        score_results = [
            ScoreResult(row_id=str(i), score=float(i + 4), reasoning="ok")
            for i in range(6)
        ]
        # scores: 4,5,6,7,8,9 — with min_quality=7 keeps indices 3,4,5

        cfg = _minimal_config(output_path=str(tmp_path), min_quality=7.0)
        pipeline = Pipeline(cfg)

        kept_rows = [r for r in rows if int(r["row_id"]) >= 3]

        mock_judge = MagicMock()
        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.models.judge.JudgeModel", return_value=mock_judge),
            patch("truva.engines.scorer.score_dataset", return_value=score_results),
            patch(
                "truva.engines.scorer.filter_by_quality",
                return_value=(kept_rows, [r for r in rows if int(r["row_id"]) < 3]),
            ),
            patch("truva.data.writer.write_jsonl"),
        ):
            result = pipeline.run("fake.jsonl")

        assert result.input_rows == 6
        assert result.rows_after_scoring == 3
        assert result.gold_rows == 3

    def test_scores_stored_in_audit(self, tmp_path):
        from truva.engines.scorer import ScoreResult

        rows = _make_rows(3)
        embeddings = _make_embeddings(3)
        score_results = [ScoreResult(row_id=str(i), score=float(i + 5), reasoning="ok") for i in range(3)]

        cfg = _minimal_config(output_path=str(tmp_path), min_quality=1.0)
        pipeline = Pipeline(cfg)

        mock_judge = MagicMock()
        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.models.judge.JudgeModel", return_value=mock_judge),
            patch("truva.engines.scorer.score_dataset", return_value=score_results),
            patch("truva.engines.scorer.filter_by_quality", return_value=(rows, [])),
            patch("truva.data.writer.write_jsonl"),
        ):
            result = pipeline.run("fake.jsonl")

        assert len(result.scores) == 3
        assert result.scores["0"] == pytest.approx(5.0)


class TestPipelineWithContradictions:
    def test_contradictions_stored(self, tmp_path):
        from truva.engines.contradictor import Contradiction
        from truva.engines.deduper import Cluster, DedupeResult

        rows = _make_rows(4)
        embeddings = _make_embeddings(4)
        dedupe_result = DedupeResult(
            kept_indices=[0, 1, 2, 3],
            removed_indices=[],
            clusters=[Cluster(0, [0, 1, 2, 3], 0.96)],
        )
        contradictions = [
            Contradiction(row_a_id="0", row_b_id="1", text_a="a", text_b="b", confidence=0.91)
        ]

        cfg = _minimal_config(
            output_path=str(tmp_path),
            dedupe_threshold=0.95,
            detect_contradictions=True,
        )
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.engines.deduper.deduplicate", return_value=dedupe_result),
            patch("truva.engines.contradictor.detect_contradictions", return_value=contradictions),
            patch("truva.data.writer.write_jsonl"),
        ):
            result = pipeline.run("fake.jsonl")

        assert result.contradictions_found == 1
        assert result.contradictions[0]["row_a_id"] == "0"
        assert result.contradictions[0]["confidence"] == pytest.approx(0.91)

    def test_contradictions_skipped_without_dedup(self, tmp_path):
        """detect_contradictions=True but dedupe_threshold=0 → contradictions skipped."""
        rows = _make_rows(3)
        embeddings = _make_embeddings(3)

        cfg = _minimal_config(
            output_path=str(tmp_path),
            dedupe_threshold=0.0,
            detect_contradictions=True,
        )
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
            patch("truva.data.writer.write_jsonl"),
            patch("truva.engines.contradictor.detect_contradictions") as mock_contra,
        ):
            result = pipeline.run("fake.jsonl")

        mock_contra.assert_not_called()
        assert result.contradictions_found == 0


class TestPipelineOutputFiles:
    def test_output_dir_and_files_created(self, tmp_path):
        rows = _make_rows(3)
        embeddings = _make_embeddings(3)
        cfg = _minimal_config(output_path=str(tmp_path / "out"))
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
        ):
            result = pipeline.run("fake.jsonl")

        assert (tmp_path / "out" / "gold.jsonl").exists()
        assert (tmp_path / "out" / "report.json").exists()

    def test_gold_row_indices_correct(self, tmp_path):
        rows = _make_rows(5)
        embeddings = _make_embeddings(5)
        cfg = _minimal_config(output_path=str(tmp_path))
        pipeline = Pipeline(cfg)

        with (
            patch("truva.data.loader.load_dataset", return_value=rows),
            patch("truva.data.loader.detect_text_field", return_value="text"),
            patch("truva.engines.embedder.compute_embeddings", return_value=embeddings),
        ):
            result = pipeline.run("fake.jsonl")

        assert result.gold_row_indices == list(range(5))
