"""End-to-end integration tests for the full Truva pipeline.

These tests use real embedding models and touch the file system.
They are marked `integration` and skipped in fast CI unless explicitly requested.

Run with:
    pytest tests/test_integration.py -v
or include them in a full run:
    pytest tests/ -v -m integration
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from truva.config import PipelineConfig
from truva.pipeline import Pipeline

FIXTURES = Path(__file__).parent / "fixtures"


def _config(tmp_path: Path, **overrides) -> PipelineConfig:
    defaults = dict(
        embed_provider="local",
        embed_model="all-MiniLM-L6-v2",
        dedupe_threshold=0.95,
        score_provider="ollama",
        score_model=None,
        min_quality=0.0,
        score_mode="fast",
        calibration_path=None,
        rubric=None,
        detect_contradictions=False,
        contradiction_confidence=0.8,
        output_path=str(tmp_path / "out"),
        output_format="jsonl",
        input_format="auto",
        text_field=None,
    )
    defaults.update(overrides)
    return PipelineConfig(**defaults)


# ── Full pipeline on 50-row fixture ───────────────────────────────────────────

@pytest.mark.integration
class TestFullPipelineOnFixture:
    def test_produces_output_files(self, tmp_path):
        cfg = _config(tmp_path)
        result = Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))

        assert (tmp_path / "out" / "gold.jsonl").exists()
        assert (tmp_path / "out" / "report.json").exists()

    def test_input_rows_correct(self, tmp_path):
        cfg = _config(tmp_path)
        result = Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))
        assert result.input_rows == 50

    def test_gold_rows_within_bounds(self, tmp_path):
        """Dedup at 0.95 must keep at least 1 row and at most all rows."""
        cfg = _config(tmp_path)
        result = Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))
        assert 1 <= result.gold_rows <= 50

    def test_dedupe_stage_recorded(self, tmp_path):
        cfg = _config(tmp_path)
        result = Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))
        assert result.rows_after_dedupe is not None

    def test_report_json_structure(self, tmp_path):
        cfg = _config(tmp_path)
        Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))

        report = json.loads((tmp_path / "out" / "report.json").read_text())
        assert "summary" in report
        assert "stages" in report
        assert "clusters" in report
        assert report["summary"]["input_rows"] == 50
        assert report["summary"]["gold_rows"] >= 1

    def test_gold_jsonl_parseable(self, tmp_path):
        cfg = _config(tmp_path)
        Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))

        gold_path = tmp_path / "out" / "gold.jsonl"
        rows = [json.loads(line) for line in gold_path.read_text().splitlines() if line.strip()]
        assert len(rows) >= 1
        for row in rows:
            assert "row_id" in row

    def test_dedup_disabled_keeps_all_rows(self, tmp_path):
        """dedupe_threshold=0.0 skips dedup — all 50 rows become gold."""
        cfg = _config(tmp_path, dedupe_threshold=0.0)
        result = Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))
        assert result.gold_rows == 50
        assert result.rows_after_dedupe is None


# ── Edge cases with real embedding model ──────────────────────────────────────

@pytest.mark.integration
class TestEdgeCases:
    def test_single_row_dataset(self, tmp_path):
        """A one-row dataset passes through with no dedup."""
        single = tmp_path / "single.jsonl"
        single.write_text('{"instruction": "What is 1+1?", "response": "2"}\n')

        cfg = _config(tmp_path, dedupe_threshold=0.95)
        result = Pipeline(cfg).run(str(single))

        assert result.input_rows == 1
        assert result.gold_rows == 1
        assert result.rows_after_dedupe == 1

    def test_all_identical_rows_collapse_to_one(self, tmp_path):
        """Dataset of identical rows should deduplicate to exactly 1."""
        identical = tmp_path / "identical.jsonl"
        row = '{"text": "The sky is blue."}\n'
        identical.write_text(row * 10)

        cfg = _config(tmp_path, dedupe_threshold=0.95)
        result = Pipeline(cfg).run(str(identical))

        assert result.input_rows == 10
        assert result.gold_rows == 1

    def test_high_threshold_keeps_more_rows(self, tmp_path):
        """threshold=1.0 keeps everything except exact-vector duplicates."""
        cfg_low = _config(tmp_path / "low", dedupe_threshold=0.85)
        cfg_high = _config(tmp_path / "high", dedupe_threshold=1.0)

        result_low = Pipeline(cfg_low).run(str(FIXTURES / "sample_50.jsonl"))
        result_high = Pipeline(cfg_high).run(str(FIXTURES / "sample_50.jsonl"))

        assert result_high.gold_rows >= result_low.gold_rows

    def test_csv_input_format(self, tmp_path):
        cfg = _config(tmp_path, dedupe_threshold=0.0, input_format="csv")
        result = Pipeline(cfg).run(str(FIXTURES / "sample_3.csv"))
        assert result.input_rows == 3
        assert result.gold_rows == 3

    def test_report_config_snapshot(self, tmp_path):
        cfg = _config(tmp_path)
        result = Pipeline(cfg).run(str(FIXTURES / "sample_50.jsonl"))
        assert result.config_snapshot["dedupe_threshold"] == 0.95
        assert result.config_snapshot["embed_provider"] == "local"


# ── Contradiction detection end-to-end ────────────────────────────────────────

@pytest.mark.integration
class TestContradictionPipeline:
    def test_known_contradictions_detected(self, tmp_path):
        """The sample_contradictions fixture has known contradicting pairs.

        Contradiction detection only fires on rows that land in the same dedup
        cluster. Semantically opposite sentences have low embedding similarity,
        so we use a permissive threshold (0.5) to ensure c1a/c1b cluster
        together, then let the NLI model flag the contradiction.
        """
        cfg = _config(
            tmp_path,
            dedupe_threshold=0.50,
            detect_contradictions=True,
            contradiction_confidence=0.7,
        )
        result = Pipeline(cfg).run(str(FIXTURES / "sample_contradictions.jsonl"))

        assert result.contradictions_found >= 1

    def test_no_contradictions_when_disabled(self, tmp_path):
        cfg = _config(
            tmp_path,
            dedupe_threshold=0.85,
            detect_contradictions=False,
        )
        result = Pipeline(cfg).run(str(FIXTURES / "sample_contradictions.jsonl"))
        assert result.contradictions_found == 0
