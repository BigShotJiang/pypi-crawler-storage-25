"""Tests for the semantic deduplication engine."""

from __future__ import annotations

import numpy as np
import pytest

from truva.engines.deduper import Cluster, DedupeResult, _UnionFind, deduplicate


class TestUnionFind:
    def test_basic_union(self):
        uf = _UnionFind(5)
        uf.union(0, 1)
        uf.union(2, 3)
        assert uf.find(0) == uf.find(1)
        assert uf.find(2) == uf.find(3)
        assert uf.find(0) != uf.find(2)

    def test_transitive(self):
        uf = _UnionFind(3)
        uf.union(0, 1)
        uf.union(1, 2)
        assert uf.find(0) == uf.find(2)

    def test_self_union(self):
        uf = _UnionFind(2)
        uf.union(0, 0)
        assert uf.find(0) == 0


def _make_rows(n: int) -> list[dict]:
    return [{"row_id": str(i), "text": f"text {i}"} for i in range(n)]


def _normalized(vecs: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    return (vecs / np.maximum(norms, 1e-10)).astype(np.float32)


class TestDeduplicate:
    def test_identical_rows_deduped(self):
        """Two identical embeddings → one removed."""
        vec = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)
        embs = np.vstack([vec, vec])
        rows = _make_rows(2)

        result = deduplicate(embs, rows, threshold=0.95)
        assert len(result.kept_indices) == 1
        assert len(result.removed_indices) == 1

    def test_different_rows_kept(self):
        """Two orthogonal embeddings → both kept."""
        embs = _normalized(np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32))
        rows = _make_rows(2)

        result = deduplicate(embs, rows, threshold=0.95)
        assert len(result.kept_indices) == 2
        assert len(result.removed_indices) == 0

    def test_single_row(self):
        """Single row → no change."""
        embs = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)
        rows = _make_rows(1)

        result = deduplicate(embs, rows, threshold=0.95)
        assert result.kept_indices == [0]
        assert result.removed_indices == []

    def test_empty_dataset(self):
        embs = np.empty((0, 3), dtype=np.float32)
        result = deduplicate(embs, [], threshold=0.95)
        assert result.kept_indices == []

    def test_threshold_zero_keeps_all(self):
        """Threshold 0.0 → everything kept."""
        vec = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)
        embs = np.vstack([vec, vec, vec])
        rows = _make_rows(3)

        result = deduplicate(embs, rows, threshold=0.0)
        assert len(result.kept_indices) == 3
        assert len(result.removed_indices) == 0

    def test_threshold_one_removes_exact_matches(self):
        """Threshold 1.0 → only exact vector matches removed."""
        vec = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)
        embs = np.vstack([vec, vec])
        rows = _make_rows(2)

        result = deduplicate(embs, rows, threshold=1.0)
        assert len(result.kept_indices) == 1

    def test_near_duplicates_above_threshold(self):
        """Two very similar but not identical vectors above threshold → deduped."""
        v1 = np.array([1.0, 0.0, 0.0])
        v2 = np.array([0.99, 0.1, 0.0])
        embs = _normalized(np.array([v1, v2], dtype=np.float32))

        # These should have cosine sim ~0.995
        sim = float(embs[0] @ embs[1])
        assert sim > 0.95

        rows = _make_rows(2)
        result = deduplicate(embs, rows, threshold=0.95)
        assert len(result.kept_indices) == 1

    def test_near_duplicates_below_threshold(self):
        """Two somewhat similar vectors below threshold → both kept."""
        v1 = np.array([1.0, 0.0, 0.0])
        v2 = np.array([0.7, 0.7, 0.0])
        embs = _normalized(np.array([v1, v2], dtype=np.float32))

        sim = float(embs[0] @ embs[1])
        assert sim < 0.95

        rows = _make_rows(2)
        result = deduplicate(embs, rows, threshold=0.95)
        assert len(result.kept_indices) == 2

    def test_cluster_structure(self):
        """Three identical vectors form one cluster with one representative."""
        vec = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)
        embs = np.vstack([vec, vec, vec])
        rows = _make_rows(3)

        result = deduplicate(embs, rows, threshold=0.95)
        multi_clusters = [c for c in result.clusters if len(c.member_indices) > 1]
        assert len(multi_clusters) == 1
        assert len(multi_clusters[0].member_indices) == 3
        assert multi_clusters[0].representative_idx in multi_clusters[0].member_indices

    def test_multiple_clusters(self):
        """Two groups of duplicates → two clusters."""
        embs = _normalized(np.array([
            [1.0, 0.0, 0.0],
            [1.0, 0.01, 0.0],  # near-dup of row 0
            [0.0, 1.0, 0.0],
            [0.0, 1.0, 0.01],  # near-dup of row 2
        ], dtype=np.float32))
        rows = _make_rows(4)

        result = deduplicate(embs, rows, threshold=0.95)
        assert len(result.kept_indices) == 2
        assert len(result.removed_indices) == 2

    def test_mismatched_lengths_raises(self):
        embs = np.array([[1.0, 0.0]], dtype=np.float32)
        rows = _make_rows(2)
        with pytest.raises(ValueError, match="doesn't match"):
            deduplicate(embs, rows)

    def test_representative_is_centroid_closest(self):
        """Representative should be the embedding closest to cluster centroid."""
        # Row 1 is the centroid-closest (it's the average of 0 and 2)
        embs = _normalized(np.array([
            [1.0, 0.0, 0.0],
            [0.98, 0.1, 0.0],
            [0.96, 0.2, 0.0],
        ], dtype=np.float32))
        rows = _make_rows(3)

        result = deduplicate(embs, rows, threshold=0.95)
        multi_clusters = [c for c in result.clusters if len(c.member_indices) > 1]
        assert len(multi_clusters) == 1
        rep = multi_clusters[0].representative_idx
        # Representative should be index 1 (closest to centroid of the three)
        assert rep == 1

    def test_avg_similarity_reasonable(self):
        """Average similarity within a cluster of identical vectors should be 1.0."""
        vec = np.array([[1.0, 0.0, 0.0]], dtype=np.float32)
        embs = np.vstack([vec, vec])
        rows = _make_rows(2)

        result = deduplicate(embs, rows, threshold=0.95)
        multi_clusters = [c for c in result.clusters if len(c.member_indices) > 1]
        assert len(multi_clusters) == 1
        assert multi_clusters[0].avg_similarity == pytest.approx(1.0, abs=0.01)


class TestDeduplicateWithRealEmbeddings:
    """Integration tests using actual sentence-transformers embeddings."""

    @pytest.fixture
    def model(self):
        from truva.models.embedding import EmbeddingModel
        return EmbeddingModel(provider="local")

    def test_semantic_duplicates_removed(self, model):
        """Semantically identical questions should be deduped."""
        rows = [
            {"row_id": "1", "text": "How do I reset my password?"},
            {"row_id": "2", "text": "How can I change my password?"},
            {"row_id": "3", "text": "What is the weather like today?"},
        ]
        embs = model.embed_batch([r["text"] for r in rows])
        result = deduplicate(embs, rows, threshold=0.85)

        # The two password questions should cluster; weather stays separate
        assert len(result.kept_indices) == 2
        assert 2 in result.kept_indices  # weather row always kept

    def test_distinct_rows_all_kept(self, model):
        """Genuinely different rows should all survive."""
        rows = [
            {"row_id": "1", "text": "Explain quantum entanglement"},
            {"row_id": "2", "text": "How to make sourdough bread"},
            {"row_id": "3", "text": "What causes tides in the ocean"},
        ]
        embs = model.embed_batch([r["text"] for r in rows])
        result = deduplicate(embs, rows, threshold=0.95)

        assert len(result.kept_indices) == 3
