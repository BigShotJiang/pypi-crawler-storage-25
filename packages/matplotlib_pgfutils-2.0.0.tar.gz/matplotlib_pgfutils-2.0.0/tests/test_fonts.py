# SPDX-FileCopyrightText: Blair Bonnett
# SPDX-License-Identifier: BSD-3-Clause

from pathlib import Path

from .utils import build_pypgf

srcdir = Path(__file__).parent.resolve() / "sources" / "fonts"


def test_custom_font():
    """Test figure using a custom font with fontspec in config file..."""
    with build_pypgf(srcdir, "custom_font.py") as res:
        assert res.returncode == 0, "Failed to build tests/sources/fonts/custom_font.py"
