"""Codex harness extractor."""

from __future__ import annotations

import re
from collections.abc import Mapping
from pathlib import Path

from meridian.lib.core.domain import TokenUsage
from meridian.lib.core.types import SpawnId
from meridian.lib.harness.adapter import ArtifactStore
from meridian.lib.harness.codex_rollout import (
    CODEX_ROLLOUT_FILENAME_RE,
    resolve_codex_home,
    resolve_rollout_session_id,
)
from meridian.lib.harness.common import (
    extract_codex_report,
    extract_session_id_from_artifacts_with_patterns,
    extract_usage_from_artifacts,
)
from meridian.lib.harness.connections.base import HarnessEvent
from meridian.lib.harness.launch_spec import CodexLaunchSpec

from .base import HarnessExtractor, session_from_mapping_with_keys

_SESSION_ID_TEXT_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bcodex\s+resume\s+([A-Za-z0-9][A-Za-z0-9._:-]{5,})\b", re.IGNORECASE),
    re.compile(r"\bresume\s+([A-Za-z0-9][A-Za-z0-9._:-]{5,})\b", re.IGNORECASE),
)
def _resolve_rollout_session_id(path: Path, project_root: Path) -> str | None:
    return resolve_rollout_session_id(path, project_root)


def _detect_primary_session_id(
    *,
    child_cwd: Path,
    launch_env: Mapping[str, str],
) -> str | None:
    sessions_root = resolve_codex_home(launch_env) / "sessions"

    if not sessions_root.is_dir():
        return None

    project_root = child_cwd.resolve()
    candidates: list[tuple[float, Path]] = []
    for candidate in sessions_root.rglob("rollout-*.jsonl"):
        if CODEX_ROLLOUT_FILENAME_RE.match(candidate.name) is None:
            continue
        try:
            modified_at = candidate.stat().st_mtime
        except OSError:
            continue
        candidates.append((modified_at, candidate))

    for _, candidate in sorted(candidates, key=lambda item: item[0], reverse=True):
        resolved = _resolve_rollout_session_id(candidate, project_root)
        if resolved:
            return resolved
    return None


class CodexHarnessExtractor(HarnessExtractor[CodexLaunchSpec]):
    """Extractor implementation for Codex artifacts and events."""

    def detect_session_id_from_event(self, event: HarnessEvent) -> str | None:
        return session_from_mapping_with_keys(
            event.payload,
            (
                "threadId",
                "thread_id",
                "session_id",
                "sessionId",
                "sessionID",
                "conversation_id",
                "conversationId",
            ),
        )

    def detect_session_id_from_artifacts(
        self,
        *,
        spec: CodexLaunchSpec,
        launch_env: Mapping[str, str],
        child_cwd: Path,
        runtime_root: Path,
    ) -> str | None:
        _ = runtime_root
        if spec.continue_session_id and spec.continue_session_id.strip():
            return spec.continue_session_id.strip()
        return _detect_primary_session_id(child_cwd=child_cwd, launch_env=launch_env)

    def extract_usage(self, artifacts: ArtifactStore, spawn_id: SpawnId) -> TokenUsage:
        return extract_usage_from_artifacts(artifacts, spawn_id)

    def extract_session_id(self, artifacts: ArtifactStore, spawn_id: SpawnId) -> str | None:
        return extract_session_id_from_artifacts_with_patterns(
            artifacts,
            spawn_id,
            json_keys=(
                "session_id",
                "sessionId",
                "sessionID",
                "conversation_id",
                "conversationId",
                "thread_id",
                "threadId",
            ),
            text_patterns=_SESSION_ID_TEXT_PATTERNS,
        )

    def extract_report(self, artifacts: ArtifactStore, spawn_id: SpawnId) -> str | None:
        return extract_codex_report(artifacts, spawn_id)


CODEX_EXTRACTOR = CodexHarnessExtractor()

__all__ = ["CODEX_EXTRACTOR", "CodexHarnessExtractor"]
