"""Streaming launch internals."""
