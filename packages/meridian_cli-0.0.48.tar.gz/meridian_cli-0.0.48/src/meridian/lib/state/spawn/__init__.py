"""Spawn state internals."""
