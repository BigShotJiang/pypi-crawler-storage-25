"""User-level state root resolution and project UUID management."""

from __future__ import annotations

import os
import uuid
from pathlib import Path

from meridian.lib.platform import IS_WINDOWS, get_home_path
from meridian.lib.platform.locking import lock_file
from meridian.lib.state.atomic import atomic_write_text


def get_user_home() -> Path:
    """Return the user-level Meridian data directory.

    Resolution order:
    1. MERIDIAN_HOME env var if set
    2. Platform default:
       - Unix/macOS: ~/.meridian/
       - Windows: %LOCALAPPDATA%\\meridian\\
         (fallback: %USERPROFILE%\\AppData\\Local\\meridian\\)
    """

    override = os.getenv("MERIDIAN_HOME", "").strip()
    if override:
        return Path(override).expanduser()

    if IS_WINDOWS:
        local_app_data = os.getenv("LOCALAPPDATA", "").strip()
        if local_app_data:
            return Path(local_app_data) / "meridian"

        user_profile = os.getenv("USERPROFILE", "").strip()
        if user_profile:
            return Path(user_profile) / "AppData" / "Local" / "meridian"

        return get_home_path() / "AppData" / "Local" / "meridian"

    return get_home_path() / ".meridian"


def get_project_uuid(meridian_dir: Path) -> str | None:
    """Read-only UUID lookup from `.meridian/id`.

    Returns None when the id file is missing, unreadable, or empty.
    """

    id_file = meridian_dir / "id"
    if not id_file.is_file():
        return None
    try:
        project_uuid = id_file.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return project_uuid or None


def get_or_create_project_uuid(meridian_dir: Path) -> str:
    """Read or generate the project UUID from .meridian/id.

    - If .meridian/id exists, read and return it
    - If not, generate UUID v4, create .meridian/ and id file atomically, return UUID
    - UUID is 36 chars, no trailing newline
    """

    project_uuid = get_project_uuid(meridian_dir)
    if project_uuid is not None:
        return project_uuid

    lock_path = meridian_dir / "id.lock"
    with lock_file(lock_path):
        project_uuid = get_project_uuid(meridian_dir)
        if project_uuid is not None:
            return project_uuid

        id_file = meridian_dir / "id"
        project_uuid = str(uuid.uuid4())
        meridian_dir.mkdir(parents=True, exist_ok=True)
        atomic_write_text(id_file, project_uuid)
        return project_uuid


def get_project_home(project_uuid: str) -> Path:
    """Return the user-level project data directory.

    Returns: get_user_home() / "projects" / project_uuid
    """

    return get_user_home() / "projects" / project_uuid
