"""Headless chat backend substrate."""
