"""Chat event normalization package."""
