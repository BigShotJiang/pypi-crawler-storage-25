"""Recipes for MRCC."""
