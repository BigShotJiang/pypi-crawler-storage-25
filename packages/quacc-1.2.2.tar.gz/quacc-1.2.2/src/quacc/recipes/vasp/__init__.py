"""Recipes for VASP."""
