# MAD Lab CLI

A Python CLI tool to generate Android lab templates automatically.

## Usage

```bash
madlab