from setuptools import setup, find_packages

setup(
    name="madshell",   # ⚠️ MUST be unique globally
    version="2.0.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    entry_points={
        'console_scripts': [
            'madlab=madlab.cli:show_menu',
            'Madlab=madlab.cli:show_menu',
            'madshell=madlab.cli:show_menu',
            'madshell to start the menu=madlab.cli:show_menu',
        ],
    },
    author="Your Friend",
    description="MAD Lab Android Code Generator CLI",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
)