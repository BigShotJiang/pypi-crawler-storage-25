def main():
    print("Hello from acpremote!")


if __name__ == "__main__":
    main()
