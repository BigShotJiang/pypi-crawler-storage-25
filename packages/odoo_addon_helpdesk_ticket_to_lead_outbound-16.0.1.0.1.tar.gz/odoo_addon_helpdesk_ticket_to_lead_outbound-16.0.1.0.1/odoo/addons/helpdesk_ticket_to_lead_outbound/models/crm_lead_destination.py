# Copyright 2025 Som IT Cooperatiu SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

import logging

from odoo import _, fields, models
from odoo.addons.webhook_hub.services.dispatcher import WebhookDispatcher


_logger = logging.getLogger(__name__)


class CrmLeadDestination(models.Model):
    """Configuration record that pairs a friendly name with an outbound webhook.

    One destination = one external CRM target (e.g. a specific Zoho account
    reached through an n8n bridge).  The ``webhook_id`` must point to an
    *outbound* ``webhook.webhook`` record that has a payload template configured
    and is ready to dispatch.
    """

    _name = "crm.lead.destination"
    _description = "CRM Lead External Destination"
    _rec_name = "name"
    _order = "name asc"

    name = fields.Char(string="Name", required=True)

    webhook_id = fields.Many2one(
        comodel_name="webhook.webhook",
        string="Outbound Webhook",
        required=True,
        domain=[("direction", "=", "outbound")],
        ondelete="restrict",
        help=(
            "Outbound webhook configured in Webhook Hub that will receive the "
            "lead payload.  The webhook must have a payload template assigned."
        ),
    )

    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        default=lambda self: self.env.company,
    )

    active = fields.Boolean(default=True)

    notes = fields.Text(
        string="Notes",
        help="Internal notes about this destination (URL of the bridge, team, etc.).",
    )

    def dispatch(self, lead, extra_context=None):
        """Dispatch a converted lead to this destination's outbound webhook.

        Builds the enriched context expected by the payload template and
        delegates all HTTP dispatch, logging and error handling to
        WebhookDispatcher from webhook_hub.
        """
        self.ensure_one()
        dispatcher = WebhookDispatcher.for_env(self.env)
        dispatcher.add_observer(self)
        try:
            context = self._build_extra_context(lead)
            if extra_context:
                context.update(extra_context)
            return dispatcher.trigger_webhook(
                webhook=self.webhook_id,
                record=lead,
                method="POST",
                extra_context=context,
            )
        finally:
            dispatcher.remove_observer(self)

    def on_webhook_success(
        self, webhook, response, record, event_type, extra_context=None
    ):
        """Post a success note on the lead when webhook dispatch succeeds."""
        if not record or record._name != "crm.lead":
            return
        record.write(
            {
                "sent_to_destination": True,
                "destination_last_sync_at": fields.Datetime.now(),
                "destination_last_error": False,
            }
        )
        if (extra_context or {}).get("notify_user", True):
            record.message_post(
                body=_("Lead forwarded successfully to external destination: %s")
                % self.display_name,
                message_type="comment",
                subtype_xmlid="mail.mt_note",
            )

    def on_webhook_failure(
        self, webhook, error_or_response, record, event_type, extra_context=None
    ):
        """Post a failure note on the lead when webhook dispatch fails."""
        if not record or record._name != "crm.lead":
            return
        error_message = self._get_webhook_error_message(error_or_response)
        record.write(
            {
                "sent_to_destination": False,
                "destination_last_sync_at": fields.Datetime.now(),
                "destination_last_error": error_message,
            }
        )
        _logger.warning(
            "Webhook dispatch failure callback for lead %s and destination %s",
            record.id,
            self.display_name,
        )
        if (extra_context or {}).get("notify_user", True):
            record.message_post(
                body=(
                    _(
                        "External lead forwarding failed for destination '%s'. "
                        "Please contact an administrator to review Webhook Hub logs."
                    )
                    % self.display_name
                ),
                message_type="comment",
                subtype_xmlid="mail.mt_note",
            )

    def _get_webhook_error_message(self, error_or_response):
        """Normalize webhook callback failure value to a concise string."""
        if isinstance(error_or_response, Exception):
            return str(error_or_response)

        status_code = getattr(error_or_response, "status_code", None)
        body = getattr(error_or_response, "body", "")
        if status_code:
            return "HTTP %s - %s" % (status_code, body or "Webhook call failed")
        return body or "Webhook call failed"

    def _build_extra_context(self, lead):
        """Return the extra context injected into the Jinja2 payload template.

        Keys available as ``context.*`` in the template:
          ticket_body         - HTML conversation history
                                (get_message_body_with_history when
                                helpdesk_ticket_mail_message is installed,
                                raw description otherwise)
          ticket_attachments  - list of {id, name, mimetype, url}
          ticket_origin_email - origin email for the ticket (partner email first,
                                fallback to first message sender)
          event_type          - always "create"
        """
        ticket = lead.helpdesk_original_ticket_id
        ticket_origin_email = ticket.partner_email or ""
        if not ticket_origin_email:
            first_incoming_email = ticket.message_ids.filtered(
                lambda msg: msg.message_type == "email"
                and msg.message_type_mail == "email_received"
                and msg.email_from
            ).sorted("date")[:1]
            ticket_origin_email = (
                first_incoming_email.email_from if first_incoming_email else ""
            )
        body = (
            str(ticket.get_message_body_with_history())
            if hasattr(ticket, "get_message_body_with_history")
            else (ticket.description or "")
        )
        attachments = [
            {
                "id": att.id,
                "name": att.name or "",
                "mimetype": att.mimetype or "",
                "url": "/web/content/%d?download=true" % att.id,
            }
            for msg in ticket.message_ids
            for att in msg.attachment_ids
        ]
        return {
            "event_type": "create",
            "ticket_body": body,
            "ticket_attachments": attachments,
            "ticket_origin_email": ticket_origin_email,
        }
