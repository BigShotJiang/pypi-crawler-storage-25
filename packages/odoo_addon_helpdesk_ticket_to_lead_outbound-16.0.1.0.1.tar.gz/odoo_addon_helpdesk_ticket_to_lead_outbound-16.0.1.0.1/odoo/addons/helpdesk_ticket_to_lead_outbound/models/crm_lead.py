# Copyright 2025 Som IT Cooperatiu SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

import logging

from odoo import api, fields, models


_logger = logging.getLogger(__name__)


class CRMLead(models.Model):
    _inherit = "crm.lead"

    destination_id = fields.Many2one(
        comodel_name="crm.lead.destination",
        string="External Destination",
        domain=[("active", "=", True)],
        help=(
            "Select an external CRM destination to forward this lead and its "
            "originating ticket data via webhook. Leave empty to keep the lead "
            "in Odoo CRM only."
        ),
    )
    sent_to_destination = fields.Boolean(
        string="Sent to Destination",
        default=False,
        copy=False,
        readonly=True,
        help="Technical flag set when outbound synchronization succeeds.",
    )
    destination_last_sync_at = fields.Datetime(
        string="Destination Last Sync",
        copy=False,
        readonly=True,
    )
    destination_last_error = fields.Text(
        string="Destination Last Error",
        copy=False,
        readonly=True,
    )

    def _dispatch_to_destination(self, notify_user=True):
        """Dispatch lead to destination, delegating feedback to destination callbacks."""
        self.ensure_one()
        return self.destination_id.dispatch(
            self,
            extra_context={
                "event_type": "create",
                "notify_user": notify_user,
            },
        )

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        for record in records.filtered(
            lambda r: r.destination_id and r.helpdesk_original_ticket_id
        ):
            record._dispatch_to_destination(notify_user=True)
        return records

    def trigger_webhook_manually(self):
        """Re-dispatch this lead to its selected destination. Useful for retries."""
        self.ensure_one()
        self._dispatch_to_destination(notify_user=True)
        return True

    def write(self, vals):
        if "destination_id" in vals:
            vals = dict(vals)
            vals.update(
                {
                    "sent_to_destination": False,
                    "destination_last_sync_at": False,
                    "destination_last_error": False,
                }
            )
        return super().write(vals)

    @api.model
    def _cron_retry_unsent_destination_leads(self, limit=200):
        """Retry unsent leads with destination every 2 hours via scheduled action."""
        leads = self.search(
            [
                ("destination_id", "!=", False),
                ("sent_to_destination", "=", False),
            ],
            limit=limit,
            order="id asc",
        )
        for lead in leads:
            try:
                lead._dispatch_to_destination(notify_user=False)
            except Exception:
                _logger.exception(
                    "Unexpected error during cron retry for lead %s", lead.id
                )
        return True
