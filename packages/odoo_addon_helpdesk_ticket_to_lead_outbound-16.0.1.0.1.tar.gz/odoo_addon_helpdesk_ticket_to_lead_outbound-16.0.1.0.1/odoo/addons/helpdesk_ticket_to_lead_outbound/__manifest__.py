# Copyright 2025 Som IT Cooperatiu SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

{
    "name": "Helpdesk Ticket to Lead - Outbound",
    "summary": (
        "Forward CRM lead and ticket data to external CRM platforms "
        "via outbound webhooks when converting a helpdesk ticket."
    ),
    "description": """
        Extends the *Helpdesk Ticket to Lead* conversion workflow with an optional
        outbound webhook step so that the lead (and its originating ticket data)
        can be forwarded to an external CRM platform such as Zoho through an
        intermediate layer like n8n.

        Key features:
        * ``crm.lead.destination`` – configuration model that pairs a human-readable
          name with an outbound ``webhook.webhook`` from Webhook Hub.
        * ``destination_id`` field on ``crm.lead`` – lets the agent choose the target
          at conversion time inside the existing wizard.
        * When a destination is selected the module automatically builds a structured
          payload (lead fields + ticket conversation history + attachment metadata)
          and dispatches it through the configured webhook.
        * Falls back gracefully if ``helpdesk_ticket_mail_message`` is not installed
          (uses the ticket description instead of full conversation history).
        * Webhook execution, retries and logging are fully delegated to Webhook Hub;
          no additional log models are introduced.
    """,
    "version": "16.0.1.0.1",
    "category": "Tools",
    "license": "AGPL-3",
    "author": "Som IT Cooperatiu SCCL",
    "website": "https://gitlab.com/somitcoop/erp-research/odoo-helpdesk",
    "depends": [
        "helpdesk_ticket_to_lead",
        "helpdesk_ticket_mail_message",  # optional but recommended for richer payloads
        "webhook_hub",
    ],
    "data": [
        "security/ir.model.access.csv",
        "data/webhook_data.xml",
        "data/ir_cron.xml",
        "views/crm_lead_views.xml",
        "views/crm_lead_destination_views.xml",
        "views/crm_lead_outbound_wizard_views.xml",
        "views/menuitems.xml",
    ],
    "installable": True,
    "application": False,
}
