# Odoo Setup Checklist — Helpdesk → External CRM via Webhook

You need the `helpdesk_ticket_to_lead_outbound` module installed.
Three pre-configured records are already created by the module — you just
need to edit them with real values and activate them.

You need the **n8n webhook trigger URL** before starting. Get it from
whoever is setting up n8n.

---

## Step 1 — Edit the Webhook

Go to **Webhook Hub → Webhooks** and open **"CRM Lead Outbound (Edit me)"**.

Change:

| Field | Set to |
|---|---|
| **Name** | Something meaningful, e.g. `n8n — CRM Lead (Zoho)` |
| **URL** | The n8n webhook trigger URL |
| **Active** | Toggle **on** |

Everything else (payload, method, headers, logs) is already configured.
Save.

> If n8n runs on the same machine as the Odoo Docker container, use
> `http://host.docker.internal:<port>/webhook/<slug>` — not `localhost`.

---

## Step 2 — Activate the Destination

Go to **CRM → Configuration → CRM Lead Destinations** and open
**"External CRM (configure me)"**.

Change:

| Field | Set to |
|---|---|
| **Name** | Something visible to agents, e.g. `Zoho CRM via n8n` |
| **Active** | Toggle **on** |

The webhook field is already linked. Save.

---

## Step 3 — Test it

1. Open any Helpdesk ticket and click **Convert into CRM Lead**.
2. In the wizard, set **External Destination** to the destination from Step 2.
3. Save the wizard.
4. Go to **Webhook Hub → Webhooks → [your webhook] → Logs** and verify
   the last entry shows `success`. If it shows `failure`, the request
   body and response are logged there — share them with the n8n developer.

---

That's it. See [README.rst](README.rst) for the full payload structure,
field descriptions, retry mechanism, and troubleshooting.
