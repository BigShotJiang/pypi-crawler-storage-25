# Copyright 2025 Som IT Cooperatiu SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import models
