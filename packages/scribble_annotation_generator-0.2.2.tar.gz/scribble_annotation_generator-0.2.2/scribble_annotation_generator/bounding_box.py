import numpy as np
import cv2
import torch
from typing import Tuple


BBOX_FEATURE_TO_KEY = {
    "center_x": 0,
    "center_y": 1,
    "height": 2,
    "width": 3,
}
BBOX_KEY_TO_FEATURE = {v: k for k, v in BBOX_FEATURE_TO_KEY.items()}


def extract_bounding_box_features(mask: np.ndarray) -> torch.Tensor:
    """
    Extract bounding box features from a binary mask.

    Args:
        mask: (H, W) binary mask of a single object

    Returns:
        Feature vector as a torch Tensor with [center_x, center_y, height, width]
    """
    # Find non-zero coordinates
    ys, xs = np.nonzero(mask)

    if len(xs) == 0:
        # Empty mask
        return torch.zeros(4, dtype=torch.float32)

    # Get bounding box coordinates
    x_min, x_max = xs.min(), xs.max()
    y_min, y_max = ys.min(), ys.max()

    # Calculate center and dimensions
    center_x = (x_min + x_max) / 2.0
    center_y = (y_min + y_max) / 2.0
    width = x_max - x_min + 1
    height = y_max - y_min + 1

    # Normalize to [-1, 1]
    center_x = (center_x / mask.shape[1]) * 2 - 1
    center_y = (center_y / mask.shape[0]) * 2 - 1
    width = width / mask.shape[1]
    height = height / mask.shape[0]

    features = {
        "center_x": center_x,
        "center_y": center_y,
        "height": height,
        "width": width,
    }

    return pack_bbox_feature_vector(features)


def pack_bbox_feature_vector(features: dict) -> torch.Tensor:
    """
    Pack a bounding box feature vector into a Tensor from a dict.

    Args:
        features: dictionary of feature names to values

    Returns:
        feature vector as a torch Tensor
    """
    vector = torch.zeros(len(BBOX_FEATURE_TO_KEY), dtype=torch.float32)
    for key, value in features.items():
        if key in BBOX_FEATURE_TO_KEY:
            vector[BBOX_FEATURE_TO_KEY[key]] = value
    return vector


def unpack_bbox_feature_vector(vector: torch.Tensor) -> dict:
    """
    Unpack a bounding box feature vector Tensor into a dict.

    Args:
        vector: feature vector as a torch Tensor

    Returns:
        dictionary of feature names to values
    """
    features = {}
    for i in range(len(vector)):
        key = BBOX_KEY_TO_FEATURE[i]
        features[key] = vector[i].item()
    return features


def generate_bbox(
    image_shape: Tuple[int, int],
    features: dict,
    class_id: int = 1,
) -> np.ndarray:
    """
    Generate a synthetic bounding box annotation based on features.

    Args:
        image_shape: Tuple (H, W) for the output size
        features: Dictionary with bounding box features (center_x, center_y, height, width)
        class_id: Class index to assign to the generated bbox (default: 1)

    Returns:
        Binary mask of shape (H, W) with values 0 (background) and class_id
    """
    canvas = np.zeros(image_shape, dtype=np.uint8)

    center_x = features["center_x"]
    center_y = features["center_y"]
    width = features["width"]
    height = features["height"]

    # Convert from normalized coordinates to pixel coordinates
    # center_x, center_y are in [-1, 1]
    # width, height are in [0, 1] (already normalized as fractions)
    
    # Calculate pixel coordinates
    px_center_x = int((center_x + 1) * image_shape[1] / 2)
    px_center_y = int((center_y + 1) * image_shape[0] / 2)
    px_width = int(width * image_shape[1])
    px_height = int(height * image_shape[0])

    # Calculate top-left and bottom-right corners
    x1 = int(px_center_x - px_width / 2)
    y1 = int(px_center_y - px_height / 2)
    x2 = int(px_center_x + px_width / 2)
    y2 = int(px_center_y + px_height / 2)

    # Clip to image boundaries
    x1 = max(0, min(x1, image_shape[1] - 1))
    y1 = max(0, min(y1, image_shape[0] - 1))
    x2 = max(0, min(x2, image_shape[1] - 1))
    y2 = max(0, min(y2, image_shape[0] - 1))

    # Draw filled rectangle
    cv2.rectangle(canvas, (x1, y1), (x2, y2), int(class_id), -1)

    return canvas


def generate_multiclass_bbox(
    image_shape: Tuple[int, int],
    objects: list[dict],
    classes: np.ndarray | torch.Tensor,
    colour_map: dict[tuple[int, int, int], int] | None = None,
) -> np.ndarray:
    """
    Generate multi-class synthetic bounding box annotation.
    Objects are drawn in descending order of surface area (larger boxes first).

    Args:
        image_shape: Tuple (H, W) for the output size
        objects: List of feature dictionaries with bbox features
        classes: Array of class IDs
        colour_map: Optional dict mapping (R, G, B) -> class index. If provided, returns RGB output.

    Returns:
        Either indexed (H, W) or RGB (H, W, 3) bounding box annotation
    """
    from scribble_annotation_generator.utils import indexed_to_rgb
    
    if type(classes) is torch.Tensor:
        classes = classes.cpu().numpy()

    # Create empty canvas
    indexed_output = np.zeros(image_shape, dtype=np.uint8)

    # Calculate surface area for each object and sort by descending area
    areas = []
    for obj in objects:
        area = obj["width"] * obj["height"]
        areas.append(area)
    
    # Get indices sorted by descending area (largest first)
    sorted_indices = np.argsort(areas)[::-1]

    # Generate bounding boxes in order of descending area
    for idx in sorted_indices:
        class_id = classes[idx]
        if class_id == 0:  # Skip background
            continue

        features = objects[idx]
        
        class_bbox = generate_bbox(
            image_shape=image_shape,
            features=features,
            class_id=int(class_id),
        )

        # Add to canvas (later/smaller boxes can overwrite earlier/larger ones at overlaps)
        indexed_output = np.where(class_bbox > 0, class_bbox, indexed_output)

    # Convert to RGB if colour_map provided
    if colour_map is not None:
        return indexed_to_rgb(indexed_output, colour_map)

    return indexed_output
