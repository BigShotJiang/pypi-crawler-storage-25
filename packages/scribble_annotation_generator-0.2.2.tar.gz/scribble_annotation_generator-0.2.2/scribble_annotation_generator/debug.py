import argparse
import os
import cv2

from scribble_annotation_generator.cli import parse_colour_map
from scribble_annotation_generator.dataset import AnnotationDataset
from scribble_annotation_generator.scribble import (
    generate_multiclass_scribble,
    unpack_feature_vector,
)
from scribble_annotation_generator.bounding_box import (
    generate_multiclass_bbox,
    unpack_bbox_feature_vector,
)


def parameterize_and_unparameterize(
    data_dir: str,
    num_classes: int,
    colour_map: dict,
    annotation_type: str,
    output_dir: str,
    image_width: int = 512,
    image_height: int = 512,
):
    """
    Test dataset by loading annotations, extracting features, and generating synthetic images.

    Args:
        data_dir: Directory containing annotation files
        num_classes: Number of classes
        colour_map: Dictionary mapping RGB tuples to class indices
        annotation_type: Type of annotation ("scribble" or "bbox")
        output_dir: Directory to save synthetic outputs
        image_width: Width of synthetic images
        image_height: Height of synthetic images
    """
    os.makedirs(output_dir, exist_ok=True)

    dataset = AnnotationDataset(
        num_classes=num_classes,
        data_dir=data_dir,
        colour_map=colour_map,
        annotation_type=annotation_type,
    )

    print(f"Loaded {len(dataset)} samples from {data_dir}")
    print(f"Annotation type: {annotation_type}")
    print(f"Output directory: {output_dir}")

    for i in range(len(dataset)):
        sample = dataset[i]

        objects = sample["objects"]
        classes = sample["classes"]

        # Unpack feature vectors based on annotation type
        if annotation_type == "scribble":
            objects = [unpack_feature_vector(obj) for obj in objects.numpy()]
            synthetic = generate_multiclass_scribble(
                image_shape=(image_height, image_width),
                objects=objects,
                classes=classes,
                colour_map=colour_map,
            )
        else:  # bbox
            objects = [unpack_bbox_feature_vector(obj) for obj in objects.numpy()]
            synthetic = generate_multiclass_bbox(
                image_shape=(image_height, image_width),
                objects=objects,
                classes=classes,
                colour_map=colour_map,
            )

        # Save the synthetic annotation
        output_path = os.path.join(output_dir, f"synthetic_{i:04d}.png")

        # Convert RGB to BGR for saving with OpenCV
        synthetic_bgr = cv2.cvtColor(synthetic, cv2.COLOR_RGB2BGR)
        cv2.imwrite(str(output_path), synthetic_bgr)

        if (i + 1) % 10 == 0:
            print(f"Processed {i + 1}/{len(dataset)} samples")

    print(f"Done! Saved {len(dataset)} synthetic images to {output_dir}")


def main():
    parser = argparse.ArgumentParser(
        description="Debug annotation dataset by generating synthetic images"
    )
    parser.add_argument(
        "--data-dir",
        type=str,
        default="./local/soybean1",
        help="Directory containing annotation files (default: ./local/soybean1)",
    )
    parser.add_argument(
        "--num-classes",
        type=int,
        default=3,
        help="Number of classes (default: 3)",
    )
    parser.add_argument(
        "--colour-map",
        type=str,
        default=None,
        help="Path to colour map file (optional, uses default if not provided)",
    )
    parser.add_argument(
        "--annotation-type",
        type=str,
        choices=["scribble", "bbox"],
        default="scribble",
        help="Type of annotation: 'scribble' or 'bbox' (default: scribble)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./local/nn-out",
        help="Directory to save synthetic outputs (default: ./local/nn-out)",
    )
    parser.add_argument(
        "--image-width",
        type=int,
        default=512,
        help="Width of synthetic images (default: 512)",
    )
    parser.add_argument(
        "--image-height",
        type=int,
        default=512,
        help="Height of synthetic images (default: 512)",
    )

    args = parser.parse_args()

    # Parse colour map
    if args.colour_map:
        colour_map = parse_colour_map(args.colour_map)
    else:
        # Default colour map
        colour_map = {
            (0, 0, 0): 0,
            (0, 128, 255): 1,
            (124, 255, 121): 2,
            (127, 0, 0): 3,
            (255, 148, 0): 4,
            (0, 0, 127): 5,
        }

    parameterize_and_unparameterize(
        data_dir=args.data_dir,
        num_classes=args.num_classes,
        colour_map=colour_map,
        annotation_type=args.annotation_type,
        output_dir=args.output_dir,
        image_width=args.image_width,
        image_height=args.image_height,
    )


if __name__ == "__main__":
    main()
