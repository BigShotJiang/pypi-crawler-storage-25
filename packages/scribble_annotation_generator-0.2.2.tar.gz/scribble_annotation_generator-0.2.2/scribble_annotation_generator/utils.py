import numpy as np
import cv2
from typing import Tuple, List, Optional


def is_rgb_annotation(mask: np.ndarray) -> bool:
    """
    Detect if annotation is RGB (H, W, 3) or indexed (H, W).

    Args:
        mask: Annotation array

    Returns:
        True if RGB, False if indexed
    """
    return len(mask.shape) == 3 and mask.shape[2] == 3


def rgb_to_indexed(
    rgb_mask: np.ndarray, colour_map: dict[tuple[int, int, int], int]
) -> np.ndarray:
    """
    Convert an RGB segmentation mask to an index mask.

    Args:
        rgb_mask: (H, W, 3) uint8 array
        colour_map: dict mapping (R, G, B) -> class index

    Returns:
        index_mask: (H, W) int64 array
    """
    if rgb_mask.ndim != 3 or rgb_mask.shape[-1] != 3:
        raise ValueError("mask_rgb must have shape (H, W, 3)")

    h, w, _ = rgb_mask.shape
    index_mask = np.zeros((h, w), dtype=np.int64)

    # Vectorized comparison per class
    for rgb, idx in colour_map.items():
        rgb = np.array(rgb, dtype=rgb_mask.dtype)
        matches = np.all(rgb_mask == rgb, axis=-1)
        index_mask[matches] = idx

    return index_mask


def indexed_to_rgb(
    indexed_mask: np.ndarray, colour_map: dict[tuple[int, int, int], int]
) -> np.ndarray:
    """
    Convert indexed annotation back to RGB using color palette.

    Args:
        indexed_mask: (H, W) array with class indices
        colour_map: dict mapping (R, G, B) -> class index

    Returns:
        (H, W, 3) RGB annotation
    """
    palette = np.zeros((max(colour_map.values()) + 1, 3), dtype=np.uint8)
    for rgb, idx in colour_map.items():
        palette[idx] = np.array(rgb, dtype=np.uint8)

    rgb_mask = palette[indexed_mask]
    return rgb_mask.astype(np.uint8)


def extract_class_masks(indexed_mask: np.ndarray) -> dict[int, np.ndarray]:
    """
    Extract individual binary masks for each class.

    Args:
        indexed_mask: (H, W) indexed annotation

    Returns:
        List of (class_id, binary_mask) tuples
    """
    unique_classes = np.unique(indexed_mask)
    class_masks = {}

    for class_id in unique_classes:
        if class_id == 0:  # Skip background
            continue
        binary_mask = (indexed_mask == class_id).astype(np.uint8)
        class_masks[class_id] = binary_mask

    return class_masks


def count_objects(mask: np.ndarray) -> int:
    """
    Count the number of connected components (objects) in a binary mask.

    Args:
        mask: (H, W) binary mask

    Returns:
        Number of separate objects (connected components)
    """
    if mask.max() == 0:
        return 0

    # Use OpenCV to find connected components
    num_labels, _ = cv2.connectedComponents(mask.astype(np.uint8))
    # Subtract 1 to exclude background
    return max(0, num_labels - 1)


def get_objects(mask: np.ndarray) -> List[np.ndarray]:
    """
    Extract individual object masks from a binary mask.

    Args:
        mask: (H, W) binary mask

    Returns:
        List of (H, W) binary masks for each object
    """
    if mask.max() == 0:
        return []

    # Use OpenCV to find connected components
    num_labels, labels = cv2.connectedComponents(mask.astype(np.uint8))

    object_masks = []
    for label in range(1, num_labels):  # Skip background label 0
        object_mask = (labels == label).astype(np.uint8)
        object_masks.append(object_mask)

    return object_masks



