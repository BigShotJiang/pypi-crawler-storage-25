from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Action(str, Enum):
    BLOCKED = "blocked"
    REDACTED = "redacted"
    WARNED = "warned"
    FLAGGED = "flagged"
    PASSED = "passed"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class Violation:
    module: str
    category: str | None
    severity: Severity
    confidence: float
    action_taken: Action
    explanation: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "module": self.module,
            "category": self.category,
            "severity": self.severity.value,
            "confidence": self.confidence,
            "action_taken": self.action_taken.value,
            "explanation": self.explanation,
        }
        return d


@dataclass
class DefendResult:
    """Unified result for scan(), check(), and all integrations."""

    flagged: bool
    action: Action
    text: str | None
    original_text: str
    violations: list[Violation] = field(default_factory=list)
    latency_ms: float = 0.0
    provider: str = ""

    @property
    def passed(self) -> bool:
        return self.action != Action.BLOCKED

    def __bool__(self) -> bool:
        return self.passed

    def raise_if_flagged(self) -> None:
        from .exceptions import InputBlockedError, OutputBlockedError

        if not self.flagged:
            return
        if self._scan_is_input:
            raise InputBlockedError(violations=self.violations, original_text=self.original_text)
        raise OutputBlockedError(violations=self.violations, original_text=self.original_text)

    # Set by orchestrator for raise_if_flagged branch (input vs output)
    _scan_is_input: bool = field(default=True, repr=False, compare=False)

    def to_dict(self) -> dict[str, Any]:
        return {
            "flagged": self.flagged,
            "passed": self.passed,
            "action": self.action.value,
            "text": self.text,
            "original_text": self.original_text,
            "violations": [v.to_dict() for v in self.violations],
            "latency_ms": self.latency_ms,
            "provider": self.provider,
        }

    def explain(self) -> str:
        if not self.violations:
            return f"action={self.action.value}; no violations"
        parts = [
            f"{v.module}: {v.explanation or v.category or 'triggered'} ({v.severity.value})"
            for v in self.violations
        ]
        return "; ".join(parts)
