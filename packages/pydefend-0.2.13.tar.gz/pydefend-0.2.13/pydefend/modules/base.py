from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from ..context import GuardContext
from ..policy import OnFail, OnFailCallable


def pop_module_runtime_kwargs(
    kwargs: dict[str, Any],
) -> tuple[OnFail | OnFailCallable | None, float | None, dict[str, Any]]:
    k = dict(kwargs)
    on_fail = k.pop("on_fail", None)
    timeout = k.pop("timeout", None)
    if isinstance(on_fail, str):
        on_fail = OnFail(on_fail)
    return on_fail, timeout, k

if TYPE_CHECKING:
    from ..providers.base import BaseProvider


@dataclass
class ModuleResult:
    triggered: bool
    confidence: float = 0.0
    category: str | None = None
    explanation: str | None = None

    @classmethod
    def passed(cls) -> ModuleResult:
        return cls(triggered=False, confidence=0.0)

    @classmethod
    def flagged(
        cls,
        *,
        confidence: float,
        category: str | None = None,
        explanation: str | None = None,
    ) -> ModuleResult:
        return cls(
            triggered=True,
            confidence=confidence,
            category=category,
            explanation=explanation,
        )


class BaseModule(ABC):
    name: str
    description: str = ""
    direction: Literal["input", "output", "both"] = "input"

    def __init__(
        self,
        *,
        on_fail: OnFail | OnFailCallable | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> None:
        self._on_fail = on_fail
        self._timeout = timeout
        self._extra = kwargs

    @property
    def on_fail(self) -> OnFail | OnFailCallable | None:
        return self._on_fail

    @property
    def timeout(self) -> float | None:
        return self._timeout

    @abstractmethod
    def system_prompt(self) -> str:
        """Prompt fragment included in batched classifier calls."""
        ...

    async def _run(self, text: str, ctx: GuardContext, provider: BaseProvider) -> ModuleResult:
        """Optional per-module execution; default uses batched classifier only."""
        return ModuleResult.passed()

    async def classify_json(
        self,
        provider: BaseProvider,
        *,
        user_prompt: str,
        schema_hint: str = "",
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Route a small JSON classification through the provider (tool use)."""
        from ..providers.classify import run_simple_classifier

        text = user_prompt + (f"\n\n{schema_hint}" if schema_hint else "")
        return await run_simple_classifier(provider, text, timeout=timeout or self._timeout)


class PromptModule(BaseModule):
    """Lightweight custom module from a prompt string."""

    def __init__(
        self,
        name: str,
        direction: Literal["input", "output", "both"],
        prompt: str,
        *,
        on_fail: OnFail | OnFailCallable | None = None,
        timeout: float | None = None,
    ) -> None:
        super().__init__(on_fail=on_fail, timeout=timeout)
        self.name = name
        self.direction = direction
        self._prompt = prompt

    def system_prompt(self) -> str:
        return self._prompt
