from __future__ import annotations

import json
import os
import time
from typing import Any

import httpx

from ..modules.base import BaseModule
from ._batch_schema import EVAL_SYSTEM_PROMPT, normalize_module_outcomes
from .base import BaseProvider, ClassifierBatchResult, ProviderUnavailableError


class OllamaProvider(BaseProvider):
    name = "ollama"
    supports_modules = True

    def __init__(
        self,
        *,
        model: str | None = None,
        max_input_tokens: int | None = 2048,
        base_url: str | None = None,
    ) -> None:
        self._model = model or os.environ.get("OLLAMA_MODEL", "llama3.2")
        self._max_input_tokens = max_input_tokens
        self._base_url = (base_url or os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434")).rstrip("/")

    async def classify_modules(
        self,
        text: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        *,
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = (
            f"{module_instructions}\n\nConfigured module names: [{allowed_list}]. "
            'Emit JSON only: {"module_results": [{"module": str, "triggered": bool, "confidence": number, '
            '"category": str, "explanation": str} ...], "redacted_text": str}'
        )
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"

        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)

        max_input_tokens = self._max_input_tokens
        if max_input_tokens and max_input_tokens > 0:
            max_chars = max_input_tokens * 4
            if len(text) > max_chars:
                text = text[:max_chars]

        timeout_s = timeout if timeout and timeout > 0 else 120.0
        url = f"{self._base_url}/api/chat"
        body: dict[str, Any] = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": text},
            ],
            "stream": False,
            "format": "json",
        }
        try:
            async with httpx.AsyncClient(timeout=timeout_s) as client:
                r = await client.post(url, json=body)
                r.raise_for_status()
                data = r.json()
        except Exception as exc:
            raise ProviderUnavailableError(f"ollama error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000
        msg = (data.get("message") or {}).get("content") or ""
        if isinstance(msg, dict):
            payload = msg
        else:
            try:
                payload = json.loads(msg) if isinstance(msg, str) else {}
            except json.JSONDecodeError:
                payload = {}

        raw = payload.get("module_results") if isinstance(payload, dict) else None
        if not isinstance(raw, list):
            raw = []
        rows = [x for x in raw if isinstance(x, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text") if isinstance(payload, dict) else None
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )
