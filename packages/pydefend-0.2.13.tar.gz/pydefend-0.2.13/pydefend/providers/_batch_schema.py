from __future__ import annotations

from typing import Any

from .base import ClassifierModuleOutcome

EVAL_SYSTEM_PROMPT = """
You are a module-driven security classifier for an LLM application guardrail system.
Analyze the following text against EACH configured guard module independently.

{module_instructions}

For every configured module listed below, you MUST emit exactly one entry in module_results with that module's name.
- Set triggered=true only when that specific module's rules are violated.
- confidence is 0.0–1.0 for that module's decision.
- category: short machine label when triggered (e.g. prompt_injection, ssn).
- explanation: one short human-readable sentence.

If any module that supports redaction is triggered (PII, malicious URLs, etc), also include a top-level field redacted_text:
- redacted_text must be the FULL original text with all detected sensitive substrings replaced with "[REDACTED]".
- preserve all other characters and whitespace exactly.
- if no redaction is needed, either omit redacted_text or set it equal to the original text.

If the text is clean for a module, set triggered=false and confidence near 0.
""".strip()


def build_module_results_openai_schema(allowed_module_names: set[str]) -> dict[str, object]:
    mod_enum = sorted(allowed_module_names)
    item_properties: dict[str, object] = {
        "module": {"type": "string", "enum": mod_enum},
        "triggered": {"type": "boolean"},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "category": {"type": "string"},
        "explanation": {"type": "string"},
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "module_results": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": item_properties,
                    "required": ["module", "triggered", "confidence"],
                },
            },
            "redacted_text": {"type": "string"},
        },
        "required": ["module_results"],
    }


def build_module_results_claude_tool(allowed_module_names: set[str]) -> dict[str, object]:
    schema = build_module_results_openai_schema(allowed_module_names)
    return {
        "name": "submit_module_results",
        "description": "Per-module guard outcomes for all configured modules.",
        "input_schema": schema,
    }


def build_module_results_openai_tool(allowed_module_names: set[str]) -> dict[str, object]:
    return {
        "type": "function",
        "function": {
            "name": "submit_module_results",
            "description": "Per-module guard outcomes for all configured modules.",
            "parameters": build_module_results_openai_schema(allowed_module_names),
        },
    }


def normalize_module_outcomes(
    raw_results: list[dict[str, Any]],
    allowed_module_names: set[str],
) -> list[ClassifierModuleOutcome]:
    by_name: dict[str, ClassifierModuleOutcome] = {}
    for row in raw_results:
        m = row.get("module")
        if not isinstance(m, str) or m not in allowed_module_names:
            continue
        conf = row.get("confidence")
        conf_f = float(conf) if isinstance(conf, (int, float)) else 0.0
        cat = row.get("category")
        expl = row.get("explanation")
        by_name[m] = ClassifierModuleOutcome(
            module=m,
            triggered=bool(row.get("triggered")),
            confidence=conf_f,
            category=str(cat) if isinstance(cat, str) else None,
            explanation=str(expl) if isinstance(expl, str) else None,
        )
    outcomes: list[ClassifierModuleOutcome] = []
    for name in sorted(allowed_module_names):
        outcomes.append(
            by_name.get(name) or ClassifierModuleOutcome(module=name, triggered=False, confidence=0.0),
        )
    return outcomes
