from __future__ import annotations

import base64
import json
import os
import time
from typing import Any

import anyio

try:
    from openai import APIStatusError, OpenAI
except Exception:  # pragma: no cover
    APIStatusError = Exception  # type: ignore[assignment]
    OpenAI = None  # type: ignore[assignment]

from ..modules.base import BaseModule
from ._batch_schema import (
    EVAL_SYSTEM_PROMPT,
    build_module_results_openai_tool,
    normalize_module_outcomes,
)
from .base import BaseProvider, ClassifierBatchResult, ProviderUnavailableError


class OpenAIProvider(BaseProvider):
    name = "openai"
    supports_modules = True

    def __init__(
        self,
        api_key: str | None = None,
        *,
        model: str = "gpt-4o-mini",
        max_input_tokens: int | None = 2048,
        base_url: str | None = None,
    ) -> None:
        self._client: OpenAI | None = None
        self._api_key = api_key
        self._model = model
        self._max_input_tokens = max_input_tokens
        self._base_url = base_url

    def _ensure_client(self) -> OpenAI:
        if OpenAI is None:
            raise ProviderUnavailableError('openai is not installed; install "pydefend[openai]"')
        if not self._api_key and not os.environ.get("OPENAI_API_KEY"):
            raise ProviderUnavailableError("OPENAI_API_KEY is not set")
        if self._client is None:
            kwargs: dict[str, Any] = {}
            if self._api_key:
                kwargs["api_key"] = self._api_key
            if self._base_url:
                kwargs["base_url"] = self._base_url
            self._client = OpenAI(**kwargs)
        return self._client

    async def classify_modules(
        self,
        text: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        *,
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = f"""{module_instructions}

Configured module names (emit one module_results entry per name): [{allowed_list}]"""
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"

        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)

        max_input_tokens = self._max_input_tokens
        if max_input_tokens and max_input_tokens > 0:
            max_chars = max_input_tokens * 4
            if len(text) > max_chars:
                text = text[:max_chars]

        client = self._ensure_client()
        tool = build_module_results_openai_tool(allowed_module_names)

        try:

            def _call_openai() -> object:
                call_kw: dict[str, Any] = dict(
                    model=self._model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": text},
                    ],
                    tools=[tool],
                    tool_choice={"type": "function", "function": {"name": "submit_module_results"}},
                    max_tokens=1024,
                )
                if timeout is not None and timeout > 0:
                    call_kw["timeout"] = timeout
                return client.chat.completions.create(**call_kw)

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call_openai)
            else:
                response = await anyio.to_thread.run_sync(_call_openai)
        except TimeoutError as exc:
            raise ProviderUnavailableError(f"openai timeout: {exc}") from exc
        except APIStatusError as exc:
            raise ProviderUnavailableError(f"openai API error: {exc}") from exc
        except Exception as exc:  # pragma: no cover - defensive
            raise ProviderUnavailableError(f"openai error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000

        try:
            message = response.choices[0].message
            tool_calls = getattr(message, "tool_calls", None) or []
            if not tool_calls:
                raise ValueError("missing tool call")
            arguments = tool_calls[0].function.arguments
            payload = json.loads(arguments)
        except Exception as exc:
            raise ProviderUnavailableError(f"openai invalid function arguments: {exc}") from exc

        raw = payload.get("module_results")
        if not isinstance(raw, list):
            raise ProviderUnavailableError("openai missing module_results")
        rows = [r for r in raw if isinstance(r, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text")
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )

    async def classify_modules_multimodal(
        self,
        *,
        text: str,
        images: list[bytes],
        image_format: str,
        modules: list[BaseModule],
        allowed_module_names: set[str],
        timeout: float | None = None,
        extra_system_suffix: str = "",
    ) -> ClassifierBatchResult:
        start = time.perf_counter()
        if not modules or not allowed_module_names:
            return ClassifierBatchResult(outcomes=[], latency_ms=0.0, provider=self.name)

        module_instructions = "\n\n".join(m.system_prompt() for m in modules)
        allowed_list = ", ".join(f'"{n}"' for n in sorted(allowed_module_names))
        module_instructions = f"""{module_instructions}

Configured module names (emit one module_results entry per name): [{allowed_list}]"""
        if extra_system_suffix.strip():
            module_instructions = f"{module_instructions}\n\n{extra_system_suffix.strip()}"
        system = EVAL_SYSTEM_PROMPT.format(module_instructions=module_instructions)

        fmt = (image_format or "auto").strip().lower()
        if fmt == "auto":
            fmt = "png"

        parts: list[dict[str, Any]] = [{"type": "text", "text": text}]
        for b in images:
            b64 = base64.b64encode(b).decode("ascii")
            parts.append(
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/{fmt};base64,{b64}"},
                },
            )

        client = self._ensure_client()
        tool = build_module_results_openai_tool(allowed_module_names)

        try:

            def _call_openai() -> object:
                call_kw: dict[str, Any] = dict(
                    model=self._model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": parts},
                    ],
                    tools=[tool],
                    tool_choice={"type": "function", "function": {"name": "submit_module_results"}},
                    max_tokens=1024,
                )
                if timeout is not None and timeout > 0:
                    call_kw["timeout"] = timeout
                return client.chat.completions.create(**call_kw)

            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call_openai)
            else:
                response = await anyio.to_thread.run_sync(_call_openai)
        except TimeoutError as exc:
            raise ProviderUnavailableError(f"openai timeout: {exc}") from exc
        except APIStatusError as exc:
            raise ProviderUnavailableError(f"openai API error: {exc}") from exc
        except Exception as exc:  # pragma: no cover
            raise ProviderUnavailableError(f"openai error: {exc}") from exc

        latency_ms = (time.perf_counter() - start) * 1000

        try:
            message = response.choices[0].message
            tool_calls = getattr(message, "tool_calls", None) or []
            if not tool_calls:
                raise ValueError("missing tool call")
            arguments = tool_calls[0].function.arguments
            payload = json.loads(arguments)
        except Exception as exc:
            raise ProviderUnavailableError(f"openai invalid function arguments: {exc}") from exc

        raw = payload.get("module_results")
        if not isinstance(raw, list):
            raise ProviderUnavailableError("openai missing module_results")
        rows = [r for r in raw if isinstance(r, dict)]
        outcomes = normalize_module_outcomes(rows, allowed_module_names)
        redacted_text = payload.get("redacted_text")
        return ClassifierBatchResult(
            outcomes=outcomes,
            latency_ms=latency_ms,
            provider=self.name,
            redacted_text=str(redacted_text) if isinstance(redacted_text, str) else None,
        )

    async def classify_simple_json(self, user_text: str, *, timeout: float | None = None) -> dict[str, Any]:
        tool = {
            "type": "function",
            "function": {
                "name": "submit_simple_verdict",
                "description": "Binary classification result.",
                "parameters": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "flagged": {"type": "boolean"},
                        "confidence": {"type": "number"},
                        "reason": {"type": "string"},
                    },
                    "required": ["flagged", "confidence", "reason"],
                },
            },
        }
        client = self._ensure_client()

        def _call() -> object:
            call_kw: dict[str, Any] = dict(
                model=self._model,
                messages=[
                    {"role": "system", "content": "Respond only via the tool."},
                    {"role": "user", "content": user_text},
                ],
                tools=[tool],
                tool_choice={"type": "function", "function": {"name": "submit_simple_verdict"}},
                max_tokens=256,
            )
            if timeout is not None and timeout > 0:
                call_kw["timeout"] = timeout
            return client.chat.completions.create(**call_kw)

        try:
            if timeout is not None and timeout > 0:
                with anyio.fail_after(timeout):
                    response = await anyio.to_thread.run_sync(_call)
            else:
                response = await anyio.to_thread.run_sync(_call)
        except Exception as exc:
            raise ProviderUnavailableError(f"openai classify_simple_json: {exc}") from exc

        message = response.choices[0].message
        tool_calls = getattr(message, "tool_calls", None) or []
        if tool_calls:
            try:
                return json.loads(tool_calls[0].function.arguments)
            except Exception:
                pass
        return {"flagged": False, "confidence": 0.0, "reason": "no tool output"}
