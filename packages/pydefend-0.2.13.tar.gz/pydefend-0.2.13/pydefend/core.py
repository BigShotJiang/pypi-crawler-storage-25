from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from .context import GuardContext
from .modules.base import BaseModule
from .observe.bus import EventBus
from .orchestrator import run_guard
from .policy import OnFail
from .providers.base import BaseProvider
from .providers.resolve import resolve_provider
from .types import Action, DefendResult


@dataclass(frozen=True)
class DefendRuntime:
    provider: BaseProvider
    input_modules: tuple[BaseModule, ...]
    output_modules: tuple[BaseModule, ...]
    global_on_fail: OnFail | None
    timeout: float | None
    max_input_chars: int | None
    module_error_policy: str
    all_modules: tuple[BaseModule, ...] = field(default_factory=tuple)

    @staticmethod
    def merge_modules(inp: tuple[BaseModule, ...], out: tuple[BaseModule, ...]) -> tuple[BaseModule, ...]:
        seen: set[str] = set()
        merged: list[BaseModule] = []
        for m in inp + out:
            if m.name not in seen:
                seen.add(m.name)
                merged.append(m)
        return tuple(merged)


@dataclass
class DefendBuilderState:
    provider_name: str | None = None
    provider: BaseProvider | None = None
    model: str | None = None
    input_modules: tuple[BaseModule, ...] = ()
    output_modules: tuple[BaseModule, ...] = ()
    global_on_fail: OnFail | None = None
    timeout: float | None = None
    max_input_chars: int | None = 8192
    module_error_policy: str = "passthrough"


class DefendBuilder:
    """Fluent immutable builder; use ``Defend()`` to construct."""

    __slots__ = ("_s",)

    @staticmethod
    def _default_module_on_fail(mod: BaseModule) -> BaseModule:
        if mod.on_fail is None:
            setattr(mod, "_on_fail", OnFail.BLOCK)
        return mod

    def __init__(self, state: DefendBuilderState | None = None) -> None:
        self._s = state or DefendBuilderState()

    def default(self) -> DefendBuilder:
        """Seed the builder with the library default module setup."""

        d = Defend.default()
        rt = d._runtime
        return DefendBuilder(
            replace(
                self._s,
                provider=rt.provider,
                provider_name=None,
                model=None,
                input_modules=rt.input_modules,
                output_modules=rt.output_modules,
                global_on_fail=rt.global_on_fail,
                timeout=rt.timeout,
                max_input_chars=rt.max_input_chars,
                module_error_policy=rt.module_error_policy,
            )
        )

    def provider(self, name: str, *, model: str | None = None) -> DefendBuilder:
        return DefendBuilder(replace(self._s, provider_name=name, model=model, provider=None))

    def with_provider(self, provider: BaseProvider) -> DefendBuilder:
        return DefendBuilder(replace(self._s, provider=provider, provider_name=None))

    def input(self, *modules: BaseModule) -> DefendBuilder:
        modules = tuple(self._default_module_on_fail(m) for m in modules)
        return DefendBuilder(
            replace(self._s, input_modules=self._s.input_modules + tuple(modules)),
        )

    def output(self, *modules: BaseModule) -> DefendBuilder:
        modules = tuple(self._default_module_on_fail(m) for m in modules)
        return DefendBuilder(
            replace(self._s, output_modules=self._s.output_modules + tuple(modules)),
        )

    def on_fail(self, policy: OnFail) -> DefendBuilder:
        return DefendBuilder(replace(self._s, global_on_fail=policy))

    def timeout(self, seconds: float | None) -> DefendBuilder:
        return DefendBuilder(replace(self._s, timeout=seconds))

    def max_input_chars(self, n: int | None) -> DefendBuilder:
        return DefendBuilder(replace(self._s, max_input_chars=n))

    def module_error_policy(self, policy: str) -> DefendBuilder:
        return DefendBuilder(replace(self._s, module_error_policy=policy))

    def build(self) -> Defend:
        s = self._s
        prov = s.provider
        if prov is None:
            pn = s.provider_name or "auto"
            prov = resolve_provider(provider=pn if pn != "auto" else None, model=s.model)
        all_m = DefendRuntime.merge_modules(s.input_modules, s.output_modules)
        rt = DefendRuntime(
            provider=prov,
            input_modules=s.input_modules,
            output_modules=s.output_modules,
            global_on_fail=s.global_on_fail,
            timeout=s.timeout,
            max_input_chars=s.max_input_chars,
            module_error_policy=s.module_error_policy,
            all_modules=all_m,
        )
        return Defend(_runtime=rt)


class Defend:
    """Guard runtime. Call ``Defend()`` with no args for a :class:`DefendBuilder`."""

    def __new__(cls, *args: Any, **kwargs: Any) -> Defend | DefendBuilder:
        if cls is Defend:
            if kwargs.get("_runtime") is not None:
                return super().__new__(cls)
            if not args and "provider" not in kwargs and "modules" not in kwargs:
                return DefendBuilder()
            return super().__new__(cls)
        return super().__new__(cls)

    def __init__(
        self,
        provider: BaseProvider | None = None,
        modules: list[BaseModule] | None = None,
        *,
        max_input_chars: int | None = 8192,
        global_on_fail: OnFail | None = None,
        timeout: float | None = None,
        module_error_policy: str = "passthrough",
        _runtime: DefendRuntime | None = None,
    ) -> None:
        if type(self) is DefendBuilder:
            return
        if _runtime is not None:
            self._rt = _runtime
            self._bus = EventBus()
            return
        if provider is None or modules is None:
            raise TypeError("Defend requires provider= and modules=, or use Defend().provider(...).build()")
        inp = tuple(m for m in modules if m.direction in ("input", "both"))
        out = tuple(m for m in modules if m.direction in ("output", "both"))
        all_m = DefendRuntime.merge_modules(inp, out)
        self._rt = DefendRuntime(
            provider=provider,
            input_modules=inp,
            output_modules=out,
            global_on_fail=global_on_fail,
            timeout=timeout,
            max_input_chars=max_input_chars,
            module_error_policy=module_error_policy,
            all_modules=all_m,
        )
        self._bus = EventBus()

    @classmethod
    def default(cls) -> Defend:
        from .modules import (
            Injection,
            InvisibleText,
            Jailbreak,
            MaliciousUrl,
            Pii,
            PiiOutput,
            PromptLeak,
            ToxicityOutput,
        )

        prov = resolve_provider()
        inp = (
            Injection(strict=True, on_fail=OnFail.BLOCK),
            Jailbreak(on_fail=OnFail.BLOCK),
            InvisibleText(on_fail=OnFail.BLOCK),
            Pii(on_fail=OnFail.REDACT),
        )
        out = (
            PromptLeak(on_fail=OnFail.BLOCK),
            PiiOutput(on_fail=OnFail.REDACT),
            MaliciousUrl(on_fail=OnFail.REDACT),
            ToxicityOutput(on_fail=OnFail.BLOCK),
        )
        all_m = DefendRuntime.merge_modules(inp, out)
        rt = DefendRuntime(
            provider=prov,
            input_modules=inp,
            output_modules=out,
            global_on_fail=OnFail.BLOCK,
            timeout=30.0,
            max_input_chars=8192,
            module_error_policy="passthrough",
            all_modules=all_m,
        )
        return cls(_runtime=rt)

    @classmethod
    def from_yaml(cls, path: str | Path) -> Defend:
        from .config import load_defend_config

        return load_defend_config(path)

    @property
    def _runtime(self) -> DefendRuntime:
        return self._rt  # type: ignore[attr-defined]

    def observe(self, *observers: Any) -> Defend:
        for o in observers:
            self._bus.add_observer(o)
        return self

    def on(self, event_name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def deco(fn: Callable[..., Any]) -> Callable[..., Any]:
            self._bus.subscribe(event_name, fn)
            return fn

        return deco

    async def scan_input(self, text: str, **kwargs: Any) -> DefendResult:
        """Alias for :meth:`scan` (backward compatible)."""
        return await self.scan(text, **kwargs)

    async def scan_output(self, text: str, **kwargs: Any) -> DefendResult:
        """Alias for :meth:`check` (backward compatible)."""
        return await self.check(text, **kwargs)

    def scan_input_sync(self, text: str, **kwargs: Any) -> DefendResult:
        return self.scan_sync(text, **kwargs)

    def scan_output_sync(self, text: str, **kwargs: Any) -> DefendResult:
        return self.check_sync(text, **kwargs)

    async def scan(
        self,
        text: str,
        *,
        ctx: GuardContext | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DefendResult:
        rt = self._runtime
        gctx = ctx or GuardContext(metadata=dict(metadata or {}))
        await self._bus.emit("scan.started", {"direction": "input", "text_len": len(text)})
        res = await run_guard(
            text=text,
            direction="input",
            provider=rt.provider,
            all_modules=list(rt.all_modules),
            global_on_fail=rt.global_on_fail,
            timeout=rt.timeout,
            max_input_chars=rt.max_input_chars,
            module_error_policy=rt.module_error_policy,
            ctx=gctx,
        )
        await self._bus.emit("scan.completed", {"result": res})
        if res.action == Action.BLOCKED:
            await self._bus.emit("blocked", {"result": res})
        for v in res.violations:
            await self._bus.emit("violation.detected", {"violation": v})
        return res

    async def check(
        self,
        text: str,
        *,
        ctx: GuardContext | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DefendResult:
        rt = self._runtime
        gctx = ctx or GuardContext(metadata=dict(metadata or {}))
        await self._bus.emit("scan.started", {"direction": "output", "text_len": len(text)})
        res = await run_guard(
            text=text,
            direction="output",
            provider=rt.provider,
            all_modules=list(rt.all_modules),
            global_on_fail=rt.global_on_fail,
            timeout=rt.timeout,
            max_input_chars=rt.max_input_chars,
            module_error_policy=rt.module_error_policy,
            ctx=gctx,
        )
        res = DefendResult(
            flagged=res.flagged,
            action=res.action,
            text=res.text,
            original_text=res.original_text,
            violations=res.violations,
            latency_ms=res.latency_ms,
            provider=res.provider,
            _scan_is_input=False,
        )
        await self._bus.emit("scan.completed", {"result": res})
        if res.action == Action.BLOCKED:
            await self._bus.emit("blocked", {"result": res})
        for v in res.violations:
            await self._bus.emit("violation.detected", {"violation": v})
        return res

    def scan_sync(self, text: str, **kwargs: Any) -> DefendResult:
        return self._run_sync(self.scan(text, **kwargs))

    def check_sync(self, text: str, **kwargs: Any) -> DefendResult:
        return self._run_sync(self.check(text, **kwargs))

    def _run_sync(self, coro: Any) -> DefendResult:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(coro)
        raise RuntimeError("scan_sync/check_sync cannot run inside an active event loop; use await scan()/check()")

    async def scan_conversation(
        self,
        *,
        messages: list[dict[str, Any]],
        latest: str,
        ctx: GuardContext | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DefendResult:
        gctx = ctx or GuardContext(metadata=dict(metadata or {}), messages=list(messages), latest_message=latest)
        history = json.dumps(messages, ensure_ascii=False, indent=2)
        suffix = (
            "Conversation context (JSON array of role/content):\n"
            f"{history}\n\nFocus evaluation on the LATEST user message:\n{latest}"
        )
        rt = self._runtime
        await self._bus.emit("scan.started", {"direction": "input", "mode": "conversation"})
        res = await run_guard(
            text=latest,
            direction="input",
            provider=rt.provider,
            all_modules=list(rt.all_modules),
            global_on_fail=rt.global_on_fail,
            timeout=rt.timeout,
            max_input_chars=rt.max_input_chars,
            module_error_policy=rt.module_error_policy,
            ctx=gctx,
            extra_system_suffix=suffix,
        )
        await self._bus.emit("scan.completed", {"result": res})
        return res

    async def scan_batch(
        self,
        texts: list[str],
        *,
        concurrency: int = 20,
        metadata: list[dict[str, Any]] | None = None,
        ctx: GuardContext | None = None,
    ) -> list[DefendResult]:
        sem = asyncio.Semaphore(concurrency)
        meta = metadata or [{}] * len(texts)

        async def one(i: int, t: str) -> DefendResult:
            async with sem:
                md = meta[i] if i < len(meta) else {}
                return await self.scan(t, ctx=ctx, metadata=md)

        return await asyncio.gather(*[one(i, t) for i, t in enumerate(texts)])

    async def scan_batch_stream(
        self,
        texts: list[str],
        *,
        concurrency: int = 20,
    ) -> AsyncIterator[tuple[int, DefendResult]]:
        sem = asyncio.Semaphore(concurrency)

        async def run_i(i: int, t: str) -> tuple[int, DefendResult]:
            async with sem:
                return i, await self.scan(t)

        tasks = [asyncio.create_task(run_i(i, t)) for i, t in enumerate(texts)]
        for fut in asyncio.as_completed(tasks):
            i, res = await fut
            yield i, res

    async def check_structured(self, data: Any) -> DefendResult:
        """Validate structured output by scanning a JSON serialization (full-document pass)."""
        text = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
        return await self.check(text)

    async def scan_tool_call(
        self,
        *,
        tool_name: str,
        tool_args: dict[str, Any],
        context: dict[str, Any] | None = None,
    ) -> DefendResult:
        payload = json.dumps({"tool": tool_name, "arguments": tool_args}, ensure_ascii=False)
        gctx = GuardContext(metadata={**(context or {}), "tool_name": tool_name})
        rt = self._runtime
        out_mods = [m for m in rt.output_modules if m.name in ("tool_misuse", "excessive_agency")]
        if not out_mods:
            out_mods = list(rt.output_modules)
        all_m = DefendRuntime.merge_modules((), tuple(out_mods))
        return await run_guard(
            text=payload,
            direction="output",
            provider=rt.provider,
            all_modules=list(all_m),
            global_on_fail=rt.global_on_fail,
            timeout=rt.timeout,
            max_input_chars=rt.max_input_chars,
            module_error_policy=rt.module_error_policy,
            ctx=gctx,
        )

    async def scan_multimodal(
        self,
        *,
        text: str,
        images: list[bytes] | None = None,
        image_format: str = "auto",
        **kwargs: Any,
    ) -> DefendResult:
        rt = self._runtime
        gctx = GuardContext(metadata=dict(kwargs.get("metadata") or {}))
        await self._bus.emit(
            "scan.started",
            {"direction": "input", "mode": "multimodal", "text_len": len(text), "n_images": len(images or [])},
        )
        res = await run_guard(
            text=text,
            direction="input",
            provider=rt.provider,
            all_modules=list(rt.all_modules),
            global_on_fail=rt.global_on_fail,
            timeout=rt.timeout,
            max_input_chars=rt.max_input_chars,
            module_error_policy=rt.module_error_policy,
            ctx=gctx,
            images=list(images or []),
            image_format=image_format,
        )
        await self._bus.emit("scan.completed", {"result": res})
        if res.action == Action.BLOCKED:
            await self._bus.emit("blocked", {"result": res})
        for v in res.violations:
            await self._bus.emit("violation.detected", {"violation": v})
        return res

    async def stream_check(self, stream: Any, *, mode: str = "buffer") -> AsyncIterator[Any]:
        chunks: list[str] = []
        async for item in stream:
            if isinstance(item, str):
                chunks.append(item)
            elif hasattr(item, "choices"):
                ch = item.choices[0]
                d = getattr(ch, "delta", None)
                if d and getattr(d, "content", None):
                    chunks.append(d.content)
        full = "".join(chunks)
        result = await self.check(full)
        if mode == "incremental":
            yield type("Flush", (), {"type": "flush", "result": result, "text": result.text})()
            return
        safe = result.text or ""
        yield safe

    def tool_scope(self) -> Any:
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def _scope() -> Any:
            yield self

        return _scope()


# Re-export builder under same module
__all__ = ["Defend", "DefendBuilder", "DefendRuntime"]
