from pathlib import Path

import pytest

from pydefend.config import load_defend_config
from pydefend.exceptions import ConfigError


def test_load_minimal_yaml(tmp_path: Path) -> None:
    p = tmp_path / "defend.yaml"
    p.write_text(
        """
provider: auto
timeout: 5.0
modules:
  input:
    - injection: {strict: true}
  output:
    - prompt_leak: {}
""",
        encoding="utf-8",
    )
    d = load_defend_config(p)
    by_name = {m.name: m for m in d._rt.all_modules}
    assert "injection" in by_name
    assert "prompt_leak" in by_name
    assert by_name["injection"].on_fail is not None
    assert by_name["injection"].on_fail.value == "block"
    assert by_name["prompt_leak"].on_fail is not None
    assert by_name["prompt_leak"].on_fail.value == "block"


def test_invalid_module_raises(tmp_path: Path) -> None:
    p = tmp_path / "bad.yaml"
    p.write_text("modules:\n  input:\n    - not_a_real_module: {}\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        load_defend_config(p)
