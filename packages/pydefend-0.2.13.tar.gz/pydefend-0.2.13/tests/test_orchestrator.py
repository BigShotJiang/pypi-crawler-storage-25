import pytest

from pydefend.core import Defend
from pydefend.modules import Injection
from pydefend.policy import OnFail
from pydefend.providers.base import BaseProvider, ClassifierBatchResult, ClassifierModuleOutcome
from pydefend.types import Action


class MockProvider(BaseProvider):
    name = "mock"

    def __init__(self, outcomes: list[ClassifierModuleOutcome], *, redacted_text: str | None = None) -> None:
        self._out = outcomes
        self._redacted_text = redacted_text

    async def classify_modules(self, text, modules, allowed_module_names, **kwargs):
        return ClassifierBatchResult(
            outcomes=list(self._out),
            latency_ms=5.0,
            provider=self.name,
            redacted_text=self._redacted_text,
        )


@pytest.mark.asyncio
async def test_scan_blocks_when_injection_triggers() -> None:
    prov = MockProvider(
        [ClassifierModuleOutcome(module="injection", triggered=True, confidence=0.95, explanation="inj")],
    )
    d = Defend(provider=prov, modules=[Injection(on_fail=OnFail.BLOCK)])
    r = await d.scan("hello")
    assert not r
    assert r.action == Action.BLOCKED
    assert r.text is None
