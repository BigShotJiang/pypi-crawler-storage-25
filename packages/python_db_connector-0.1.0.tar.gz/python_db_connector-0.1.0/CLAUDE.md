# Minimal docstrings

## Top of file

Do not add module-level docstrings or descriptive comments at the top of files. Start directly with imports or code.

```python
# BAD
"""Retry policy value object for application-layer retry logic."""

from dataclasses import dataclass
```

```python
# GOOD
from dataclasses import dataclass
```

## Function and class docstrings

Add docstrings only when:

- The function is **complex** (non-obvious behavior, multiple responsibilities, subtle side effects), or
- **Business rules** need to be highlighted (invariants, validation rules, domain constraints)

Use your judgment. Simple, self-explanatory functions (e.g. thin wrappers, straightforward setters) do not need docstrings.

---

# Ruff format after Python edits

After applying changes to Python files, run **Ruff format** on the affected paths **before** you finish the response.

## Environment

Run Ruff **inside `python-db-connector-env`**: activate it first if it is not already active.

## When

- After editing one or more `.py` files
- Before finishing the response

## Commands

Single file:

```bash
ruff format path/to/modified_file.py
```

Multiple files:

```bash
ruff format path/to/file1.py path/to/file2.py
```

Entire project:

```bash
ruff format .
```

**Preference:** Format only the files you modified to keep runs fast. Use `ruff format .` when many files were changed or when you are unsure which paths need formatting.
