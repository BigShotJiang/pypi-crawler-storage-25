# PRD: Python DB Connector

**Branch:** feature/python-db-connector

## Introduction

Installable Python library that provides sync and async PostgreSQL connectivity to Amazon RDS databases (treasury, research, sandbox) across environments (dev/prod). Authentication supports both explicit password credentials and AWS IAM database authentication. The library is packaged for `pip install` so other repositories can depend on it.

## Goals

- Provide a single, reusable library for all PostgreSQL RDS access across the organisation
- Support both password-based and IAM token-based authentication
- Offer synchronous and asynchronous clients with identical interfaces
- Include optional connection pooling for production workloads
- Use context-manager transactions for safe, Pythonic transaction control
- Follow TDD — write tests before implementation for every story with testable logic
- Publish as an installable package (`pip install python-db-connector`)

## User Stories

### US-001: Project scaffolding and packaging metadata

**Description:** As a developer, I need the project skeleton with proper packaging so the library is installable via `pip install -e .` and eventually publishable.

**Acceptance Criteria:**
- [ ] `pyproject.toml` contains `[project]` table with name `python-db-connector`, version `0.1.0`, Python `>=3.10`, and dependencies: `boto3>=1.28.0`, `psycopg[binary]>=3.1.0`, `psycopg_pool>=3.1.0`
- [ ] `pyproject.toml` contains `[project.optional-dependencies]` with `dev` extras: `pytest>=8.0.0`, `pytest-asyncio>=0.23.0`, `ruff>=0.14.0`, `mypy>=1.8.0`, `pre-commit>=4.4.0`
- [ ] `pyproject.toml` contains `[build-system]` using `setuptools>=68.0` and `setuptools-scm`
- [ ] `src/db_connector/__init__.py` exists (empty for now)
- [ ] `src/db_connector/py.typed` marker file exists
- [ ] `tests/__init__.py` exists
- [ ] `tests/conftest.py` exists with a placeholder
- [ ] Running `pip install -e ".[dev]"` succeeds
- [ ] Existing `[tool.ruff]` config in `pyproject.toml` is preserved
- [ ] Typecheck passes

---

### US-002: Custom error hierarchy

**Description:** As a library consumer, I need well-defined exception types so I can catch specific failure modes (auth errors, timeouts, connection failures) without depending on driver internals.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_errors.py` written first — tests that all error classes exist, inherit correctly, and carry a message
- [ ] `src/db_connector/errors.py` defines: `ConnectorError` (base), `AuthenticationError(ConnectorError)`, `IAMAuthenticationError(AuthenticationError)`, `DatabaseAuthenticationError(AuthenticationError)`, `ConnectorTimeoutError(ConnectorError)`, `ConnectorConnectionError(ConnectorError)`
- [ ] Each error class accepts a `message: str` and optional `cause: Exception | None`
- [ ] `str(error)` returns the message
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-003: Error mapping utility

**Description:** As a developer, I need a function that maps raw psycopg and socket exceptions into the library's error hierarchy so callers never see driver-specific exceptions.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_error_mapping.py` written first — tests that psycopg `OperationalError` with auth-related messages maps to `DatabaseAuthenticationError`, connection-refused maps to `ConnectorConnectionError`, timeout maps to `ConnectorTimeoutError`, and unknown errors wrap in `ConnectorError`
- [ ] `src/db_connector/error_mapping.py` implements `raise_mapped_connector_error(exc: Exception) -> NoReturn`
- [ ] Handles `psycopg.OperationalError`, `socket.timeout`, `socket.gaierror`, `ConnectionRefusedError`, `OSError`
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-004: Connection configuration dataclass and env-var loader

**Description:** As a library consumer, I need to configure database connections through environment variables following the `{DATABASE}_{ENVIRONMENT}_{FIELD}` naming convention (e.g. `SANDBOX_DEV_HOST`) so each repo only sets env vars.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_config.py` written first — tests for `ConnectionConfig` validation, `connection_config_from_env()` loading, missing variable errors, default port handling
- [ ] `src/db_connector/config.py` defines `ConnectionConfig` dataclass with fields: `host: str`, `port: int`, `dbname: str`, `user: str`, `password: str | None` (None means IAM auth), `region: str | None` (required when password is None), `sslmode: str` (default `"require"`)
- [ ] `connection_config_from_env(database: str, environment: str) -> ConnectionConfig` reads `{DATABASE}_{ENVIRONMENT}_HOST`, `_PORT`, `_DBNAME`, `_USER`, `_PASSWORD`, `_REGION` from `os.environ`
- [ ] Port defaults to `5432` when env var is unset or blank
- [ ] Raises `ValueError` with a clear message when required vars (`HOST`, `DBNAME`, `USER`) are missing
- [ ] When `PASSWORD` is empty/unset and `REGION` is empty/unset, raises `ValueError` explaining that either password or region (for IAM) must be provided
- [ ] `connection_config_from_mapping(data: dict) -> ConnectionConfig` validates and builds config from a plain dict with keys: `host`, `port`, `dbname`, `username` (mapped to `user`), `password`, `engine` (ignored), `region`
- [ ] `.env.example` file created with all variable placeholders for treasury/research/sandbox in dev/prod
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-005: IAM authentication token generation

**Description:** As a library consumer, I need the library to generate short-lived IAM authentication tokens via boto3 when using IAM auth mode, so I don't manage passwords for RDS.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_iam_auth.py` written first — tests mock `boto3.client("rds")` and verify `generate_db_auth_token` is called with correct host, port, user, region; test that boto3 errors are wrapped in `IAMAuthenticationError`
- [ ] `src/db_connector/iam_auth.py` implements `generate_iam_token(config: ConnectionConfig) -> str`
- [ ] Uses `boto3.client("rds", region_name=config.region).generate_db_auth_token(DBHostname=config.host, Port=config.port, DBUsername=config.user, Region=config.region)`
- [ ] Wraps `botocore.exceptions.BotoCoreError`, `botocore.exceptions.ClientError`, and `botocore.exceptions.NoCredentialsError` in `IAMAuthenticationError` with the original as `cause`
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-006: Sync client — connect and close

**Description:** As a library consumer, I need a `SyncClient` that establishes a synchronous PostgreSQL connection using either password or IAM auth, and closes it cleanly.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_sync_client.py` written first — tests mock `psycopg.connect` and verify it receives the correct connection string / params for password auth; tests verify IAM path calls `generate_iam_token`; tests verify `close()` calls `connection.close()`; tests verify client works as a context manager (`with SyncClient(config) as client:`)
- [ ] `src/db_connector/sync_client.py` implements `SyncClient.__init__(self, config: ConnectionConfig, pool: bool = False, min_connections: int = 1, max_connections: int = 10)`
- [ ] When `pool=False`: `connect()` opens a single `psycopg.Connection`; password is used directly when `config.password` is set, otherwise `generate_iam_token()` is called
- [ ] `close()` closes the connection
- [ ] `SyncClient` supports context manager protocol (`__enter__` / `__exit__`)
- [ ] Connection errors are mapped through `raise_mapped_connector_error`
- [ ] `sslmode` from config is passed to the connection
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-007: Sync client — query execution

**Description:** As a library consumer, I need to execute raw SQL queries and fetch results as tuples through the sync client.

**Acceptance Criteria:**
- [ ] TDD: tests added to `tests/test_sync_client.py` — tests mock cursor and verify `execute()`, `fetchall()`, `fetchone()`, `fetchmany()` delegate correctly to psycopg cursor; tests verify parameterised queries pass params safely
- [ ] `SyncClient.execute(query: str, params: tuple | None = None) -> None` executes a statement
- [ ] `SyncClient.fetchall(query: str, params: tuple | None = None) -> list[tuple]` returns all rows
- [ ] `SyncClient.fetchone(query: str, params: tuple | None = None) -> tuple | None` returns one row or None
- [ ] `SyncClient.fetchmany(query: str, params: tuple | None = None, size: int = 100) -> list[tuple]` returns up to `size` rows
- [ ] All methods use parameterised queries (no string interpolation)
- [ ] Exceptions during execution are mapped through `raise_mapped_connector_error`
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-008: Sync client — context-manager transactions

**Description:** As a library consumer, I need `with client.transaction():` to group multiple statements in a transaction that auto-commits on success and auto-rollbacks on exception.

**Acceptance Criteria:**
- [ ] TDD: tests added to `tests/test_sync_client.py` — tests verify commit is called on clean exit, rollback is called on exception, nested transaction calls raise an error
- [ ] `SyncClient.transaction()` returns a context manager
- [ ] On `__enter__`: begins a transaction (or uses psycopg's built-in transaction context manager)
- [ ] On `__exit__` with no exception: commits
- [ ] On `__exit__` with exception: rolls back, then re-raises the exception
- [ ] Calling `transaction()` while already in a transaction raises `ConnectorError("Already in a transaction")`
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-009: Sync client — optional connection pooling

**Description:** As a library consumer, I need to enable connection pooling on `SyncClient` for production workloads so connections are reused instead of opened/closed each time.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_sync_pool.py` written first — tests mock `psycopg_pool.ConnectionPool` and verify it is created with correct min/max connections; tests verify `connect()` calls `pool.getconn()`, `close()` calls `pool.close()`; tests verify pool is not created when `pool=False`
- [ ] When `SyncClient(config, pool=True)`: uses `psycopg_pool.ConnectionPool` with `min_size` and `max_size` from constructor args
- [ ] `connect()` gets a connection from the pool
- [ ] `close()` drains and closes the pool
- [ ] When `pool=False` (default): behaves as in US-006 (single direct connection)
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-010: Async client — connect, close, and query execution

**Description:** As a library consumer, I need an `AsyncClient` with the same interface as `SyncClient` but using `async/await` for non-blocking database access.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_async_client.py` written first — tests mock `psycopg.AsyncConnection.connect` and verify password/IAM auth paths; tests verify `execute()`, `fetchall()`, `fetchone()`, `fetchmany()` work as async methods; tests verify `close()` and async context manager
- [ ] `src/db_connector/async_client.py` implements `AsyncClient.__init__(self, config: ConnectionConfig, pool: bool = False, min_connections: int = 1, max_connections: int = 10)`
- [ ] `async connect()`, `async close()`, `async execute()`, `async fetchall()`, `async fetchone()`, `async fetchmany()` mirror SyncClient's signatures but are async
- [ ] `AsyncClient` supports async context manager (`__aenter__` / `__aexit__`)
- [ ] Password and IAM auth paths identical to SyncClient logic
- [ ] Connection errors mapped through `raise_mapped_connector_error`
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-011: Async client — context-manager transactions

**Description:** As a library consumer, I need `async with client.transaction():` for async transaction management with the same semantics as the sync version.

**Acceptance Criteria:**
- [ ] TDD: tests added to `tests/test_async_client.py` — tests verify commit on clean exit, rollback on exception, nested transaction error
- [ ] `AsyncClient.transaction()` returns an async context manager
- [ ] Auto-commits on clean `__aexit__`, auto-rollbacks on exception
- [ ] Nested `transaction()` calls raise `ConnectorError("Already in a transaction")`
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-012: Async client — optional connection pooling

**Description:** As a library consumer, I need optional async connection pooling for production async workloads.

**Acceptance Criteria:**
- [ ] TDD: `tests/test_async_pool.py` written first — tests mock `psycopg_pool.AsyncConnectionPool` and verify pool creation, connection acquisition, and pool close
- [ ] When `AsyncClient(config, pool=True)`: uses `psycopg_pool.AsyncConnectionPool` with `min_size` and `max_size`
- [ ] `async connect()` gets a connection from the pool
- [ ] `async close()` drains and closes the pool
- [ ] When `pool=False` (default): single direct async connection
- [ ] Tests pass
- [ ] Typecheck passes

---

### US-013: Public API exports and README

**Description:** As a library consumer, I need a clean `from db_connector import ...` public API and documentation so I can get started quickly.

**Acceptance Criteria:**
- [ ] `src/db_connector/__init__.py` exports: `ConnectionConfig`, `SyncClient`, `AsyncClient`, `connection_config_from_env`, `connection_config_from_mapping`, `generate_iam_token`, `ConnectorError`, `AuthenticationError`, `IAMAuthenticationError`, `DatabaseAuthenticationError`, `ConnectorTimeoutError`, `ConnectorConnectionError`, `raise_mapped_connector_error`
- [ ] `README.md` documents: install instructions (`pip install python-db-connector`), quick-start for sync and async usage (password and IAM), env var configuration pattern, connection pooling options, transaction usage, error handling, development setup
- [ ] Typecheck passes

## Functional Requirements

- FR-1: The library must connect to PostgreSQL RDS instances using explicit password credentials provided via environment variables following the `{DATABASE}_{ENVIRONMENT}_{FIELD}` convention
- FR-2: The library must connect to PostgreSQL RDS instances using AWS IAM database authentication when no password is provided, generating short-lived tokens via `boto3`
- FR-3: The library must provide a synchronous client (`SyncClient`) using `psycopg` for blocking database operations
- FR-4: The library must provide an asynchronous client (`AsyncClient`) using `psycopg` async for non-blocking database operations
- FR-5: Both clients must expose `execute()`, `fetchall()`, `fetchone()`, and `fetchmany()` for raw SQL execution with parameterised queries
- FR-6: Both clients must support context-manager transactions (`with client.transaction()` / `async with client.transaction()`) that auto-commit on success and auto-rollback on exception
- FR-7: Both clients must support optional connection pooling via `psycopg_pool`, configurable at instantiation (`pool=True/False`, `min_connections`, `max_connections`)
- FR-8: All driver-specific exceptions must be mapped to the library's error hierarchy (`ConnectorError` and subclasses) so consumers never catch `psycopg` internals
- FR-9: The library must be installable via `pip install python-db-connector` (or `pip install -e ".[dev]"` for development)
- FR-10: All query methods must use parameterised queries — no string interpolation of user-supplied values

## Non-Goals

- No ORM or query-builder functionality — raw SQL only
- No support for non-PostgreSQL databases (MySQL, SQLite, etc.)
- No automatic migration or schema management
- No built-in retry logic or circuit-breaker patterns
- No result serialisation to dicts, dataclasses, or Pydantic models — raw tuples only
- No connection to non-RDS PostgreSQL instances (though it would technically work)
- No CLI tool — library only

## Technical Considerations

- **Driver:** `psycopg` v3 (psycopg3) for both sync and async — single dependency, mature, supports binary protocol
- **Pooling:** `psycopg_pool` (`ConnectionPool` for sync, `AsyncConnectionPool` for async)
- **IAM auth:** `boto3` for `generate_db_auth_token` — tokens are valid for 15 minutes; the library generates a fresh token on each `connect()` call (caching is a future enhancement)
- **SSL:** Default `sslmode=require` for all RDS connections
- **Packaging:** `src/` layout with `pyproject.toml` using `setuptools` as build backend
- **Python:** `>=3.10` (uses `X | Y` union syntax, `match` statements allowed)
- **Testing:** `pytest` + `pytest-asyncio`, mock-heavy (no real DB in CI), TDD approach
- **Env vars pattern:** `{DATABASE}_{ENVIRONMENT}_{FIELD}` where DATABASE is `TREASURY`, `RESEARCH`, or `SANDBOX`; ENVIRONMENT is `DEV` or `PROD`; FIELD is `HOST`, `PORT`, `DBNAME`, `USER`, `PASSWORD`, `REGION`

## Success Metrics

- All 13 user stories have passing tests
- `pip install -e ".[dev]"` succeeds cleanly
- `ruff check src/ tests/` and `ruff format --check src/ tests/` pass with zero errors
- `mypy src/` passes with no errors
- A consuming project can `pip install git+<repo-url>` and use `from db_connector import SyncClient` successfully

## Open Questions

- Should IAM tokens be cached for their 15-minute lifetime, or generated fresh on each connect?
- Should the library support RDS Proxy endpoints in addition to direct RDS endpoints?
- Should there be a `REGION` fallback to `AWS_REGION` / `AWS_DEFAULT_REGION` env vars when per-database region is not set?
- Should future versions return `Row` objects (named-tuple style) instead of plain tuples?
