#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import sys
import time

from dotenv import load_dotenv

from db_connector import (
    AsyncClient,
    ConnectorConnectionError,
    ConnectorError,
    ConnectorTimeoutError,
    SyncClient,
    connection_config_from_env,
)

DIVIDER = "-" * 50

OK = "\033[32m✔\033[0m"
FAIL = "\033[31m✘\033[0m"
INFO = "\033[34mi\033[0m"


def _header(database: str, environment: str) -> None:
    print(f"\n{DIVIDER}")
    print(f"  Testing connection: {database.upper()} / {environment.upper()}")
    print(DIVIDER)


def _test_sync(database: str, environment: str) -> bool:
    config = connection_config_from_env(database, environment)
    print(f"\n{INFO} Sync client  |  host={config.host}:{config.port}  db={config.dbname}")

    start = time.perf_counter()
    try:
        with SyncClient(config) as client:
            row = client.fetchone("SELECT version()")
            elapsed = time.perf_counter() - start
            version = row[0] if row else "unknown"
            print(f"  {OK} Connected in {elapsed:.3f}s")
            print(f"  {OK} Server version: {version}")
            return True
    except ConnectorTimeoutError as exc:
        print(f"  {FAIL} Timeout: {exc}")
    except ConnectorConnectionError as exc:
        print(f"  {FAIL} Connection error: {exc}")
    except ConnectorError as exc:
        print(f"  {FAIL} Error: {exc}")
    return False


async def _test_async(database: str, environment: str) -> bool:
    config = connection_config_from_env(database, environment)
    print(f"\n{INFO} Async client  |  host={config.host}:{config.port}  db={config.dbname}")

    start = time.perf_counter()
    try:
        async with AsyncClient(config) as client:
            row = await client.fetchone("SELECT version()")
            elapsed = time.perf_counter() - start
            version = row[0] if row else "unknown"
            print(f"  {OK} Connected in {elapsed:.3f}s")
            print(f"  {OK} Server version: {version}")
            return True
    except ConnectorTimeoutError as exc:
        print(f"  {FAIL} Timeout: {exc}")
    except ConnectorConnectionError as exc:
        print(f"  {FAIL} Connection error: {exc}")
    except ConnectorError as exc:
        print(f"  {FAIL} Error: {exc}")
    return False


def main() -> None:
    parser = argparse.ArgumentParser(description="Test database connectivity using python-db-connector")
    parser.add_argument("database", help="Database name (e.g. treasury, research, sandbox)")
    parser.add_argument("environment", help="Environment (e.g. dev, prod)")
    parser.add_argument("--sync-only", action="store_true", help="Run only the sync client test")
    parser.add_argument("--async-only", action="store_true", help="Run only the async client test")
    parser.add_argument("--env-file", default=".env", help="Path to .env file (default: .env)")

    args = parser.parse_args()

    load_dotenv(args.env_file)
    _header(args.database, args.environment)

    results: list[bool] = []

    if not args.async_only:
        results.append(_test_sync(args.database, args.environment))

    if not args.sync_only:
        results.append(asyncio.run(_test_async(args.database, args.environment)))

    print(f"\n{DIVIDER}")
    if all(results):
        print(f"  {OK} All checks passed")
    else:
        print(f"  {FAIL} Some checks failed")
    print(f"{DIVIDER}\n")

    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
