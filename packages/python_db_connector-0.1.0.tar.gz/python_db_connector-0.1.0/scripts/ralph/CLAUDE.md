# Ralph Agent Instructions

You are an autonomous coding agent working on a software project (Claude Code CLI).

## Your Task

1. Read the PRD at `prd.json` (in the same directory as this file)
2. Read the progress log at `progress.txt` (check Codebase Patterns section first)
3. Check you're on the correct branch from PRD `branchName`. Branch names must be **`feature/<kebab-case-feature-name>`** (e.g. `feature/python-db-connector`). If `branchName` is wrong in `prd.json`, fix it to match before creating the branch. If you're not on that branch, check it out or create it from `main`.
4. Pick the **highest priority** user story where `passes: false`
5. Implement that single user story
6. Run quality checks (e.g., typecheck, lint, test - use whatever your project requires)
7. If you discover reusable patterns, record them under **Preserve learnings** below
8. If checks pass, commit ALL changes with message: `feat: [Story ID] - [Story Title]`
9. Push the branch to GitHub: `git push -u origin <branchName>` using `branchName` from `prd.json` (use `git push` on subsequent pushes if upstream is already set)
10. Update the PRD to set `passes: true` for the completed story
11. Append your progress to `progress.txt`

## Progress Report Format

APPEND to progress.txt (never replace, always append):
```
## [Date/Time] - [Story ID]
- What was implemented
- Files changed
- **Learnings for future iterations:**
  - Patterns discovered (e.g., "this codebase uses X for Y")
  - Gotchas encountered (e.g., "don't forget to update Z when changing W")
  - Useful context (e.g., "the evaluation panel is in component X")
---
```

The learnings section is critical - it helps future iterations avoid repeating mistakes and understand the codebase better.

## Consolidate Patterns

If you discover a **reusable pattern** that future iterations should know, add it to the `## Codebase Patterns` section at the TOP of progress.txt (create it if it doesn't exist). This section should consolidate the most important learnings:

```
## Codebase Patterns
- Example: Use `sql<number>` template for aggregations
- Example: Always use `IF NOT EXISTS` for migrations
- Example: Export types from actions.ts for UI components
```

Only add patterns that are **general and reusable**, not story-specific details.

## Preserve Learnings (Claude)

Before committing, if you discovered knowledge that should live beyond `progress.txt`:

1. Prefer **`CLAUDE.md`** at the repo root for project-wide rules and conventions.
2. Or **`.claude/skills/`** for reusable, structured knowledge (skill files).
3. Or **`AGENTS.md`** at the repo root or near the code you changed, if the repo already uses that pattern.

**Good additions:** module conventions, gotchas, test/env requirements, file coupling.

**Do not add:** story-specific implementation dumps, duplicate content already in `progress.txt`.

## Quality Requirements

- ALL commits must pass your project's quality checks (typecheck, lint, test)
- Do NOT commit broken code
- Keep changes focused and minimal
- Follow existing code patterns

## Browser Testing (If Available)

For any story that changes UI, verify it works in the browser using the dev-browser skill if available:

1. Navigate to the relevant page
2. Verify the UI changes work as expected
3. Take a screenshot if helpful for the progress log

If no browser tools are available, note in your progress report that manual browser verification is needed.

## Stop Condition

After completing a user story, check if ALL stories have `passes: true`.

If ALL stories are complete and passing, end your reply with **only** this on the final line (no other text after it):
<promise>COMPLETE</promise>

If there are still stories with `passes: false`, end your response normally and **do not** write that tag (not even when explaining that work remains—the shell looks for it only on the last line).

## Important

- Work on ONE story per iteration
- Commit frequently and push to GitHub after each successful story commit
- Keep CI green
- Read the Codebase Patterns section in progress.txt before starting
