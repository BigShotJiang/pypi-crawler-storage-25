from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from db_connector.async_client import AsyncClient
from db_connector.config import ConnectionConfig
from db_connector.errors import ConnectorConnectionError, ConnectorError


@pytest.fixture
def password_config() -> ConnectionConfig:
    return ConnectionConfig(
        host="db.example.com",
        port=5432,
        dbname="mydb",
        user="myuser",
        password="secret",
    )


def make_mock_conn() -> MagicMock:
    mock_conn = MagicMock()
    mock_conn.close = AsyncMock()
    mock_conn.commit = AsyncMock()
    mock_conn.rollback = AsyncMock()
    return mock_conn


def make_cursor_ctx(mock_cursor: MagicMock) -> MagicMock:
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=mock_cursor)
    ctx.__aexit__ = AsyncMock(return_value=False)
    return ctx


class TestAsyncClientConnect:
    async def test_connect_password_auth_calls_async_connect(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ) as mock_connect:
            client = AsyncClient(password_config)
            await client.connect()

            mock_connect.assert_called_once()
            call_kwargs = mock_connect.call_args[1]
            assert call_kwargs["host"] == "db.example.com"
            assert call_kwargs["port"] == 5432
            assert call_kwargs["dbname"] == "mydb"
            assert call_kwargs["user"] == "myuser"
            assert call_kwargs["password"] == "secret"
            assert call_kwargs["sslmode"] == "require"

    async def test_connect_passes_sslmode(self, password_config: ConnectionConfig) -> None:
        password_config.sslmode = "verify-full"
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ) as mock_connect:
            client = AsyncClient(password_config)
            await client.connect()

            call_kwargs = mock_connect.call_args[1]
            assert call_kwargs["sslmode"] == "verify-full"

    async def test_connect_error_raises_connector_error(self, password_config: ConnectionConfig) -> None:
        import psycopg

        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            side_effect=psycopg.OperationalError("refused"),
        ):
            client = AsyncClient(password_config)
            with pytest.raises(ConnectorConnectionError):
                await client.connect()


class TestAsyncClientClose:
    async def test_close_calls_connection_close(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            await client.close()

            mock_conn.close.assert_called_once()

    async def test_close_without_connect_does_not_raise(self, password_config: ConnectionConfig) -> None:
        client = AsyncClient(password_config)
        await client.close()  # should not raise


class TestAsyncClientQueryExecution:
    async def test_execute_calls_cursor_execute(self, password_config: ConnectionConfig) -> None:
        mock_cursor = AsyncMock()
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            await client.execute("INSERT INTO t VALUES (%s)", (1,))
            mock_cursor.execute.assert_called_once_with("INSERT INTO t VALUES (%s)", (1,))

    async def test_fetchall_returns_all_rows(self, password_config: ConnectionConfig) -> None:
        rows = [(1, "a"), (2, "b")]
        mock_cursor = AsyncMock()
        mock_cursor.fetchall.return_value = rows
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            result = await client.fetchall("SELECT * FROM t", ())
            assert result == rows

    async def test_fetchone_returns_one_row(self, password_config: ConnectionConfig) -> None:
        mock_cursor = AsyncMock()
        mock_cursor.fetchone.return_value = (1, "a")
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            result = await client.fetchone("SELECT * FROM t WHERE id=%s", (1,))
            assert result == (1, "a")

    async def test_fetchone_returns_none_when_no_row(self, password_config: ConnectionConfig) -> None:
        mock_cursor = AsyncMock()
        mock_cursor.fetchone.return_value = None
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            result = await client.fetchone("SELECT * FROM t WHERE id=%s", (999,))
            assert result is None

    async def test_fetchmany_returns_up_to_size_rows(self, password_config: ConnectionConfig) -> None:
        rows = [(1, "a"), (2, "b")]
        mock_cursor = AsyncMock()
        mock_cursor.fetchmany.return_value = rows
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            result = await client.fetchmany("SELECT * FROM t", (), size=50)
            mock_cursor.fetchmany.assert_called_once_with(50)
            assert result == rows

    async def test_fetchmany_default_size_is_100(self, password_config: ConnectionConfig) -> None:
        mock_cursor = AsyncMock()
        mock_cursor.fetchmany.return_value = []
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            await client.fetchmany("SELECT * FROM t", ())
            mock_cursor.fetchmany.assert_called_once_with(100)

    async def test_execute_maps_exception_on_error(self, password_config: ConnectionConfig) -> None:
        import psycopg as _psycopg

        mock_cursor = AsyncMock()
        mock_cursor.execute.side_effect = _psycopg.OperationalError("conn lost")
        mock_conn = make_mock_conn()
        mock_conn.cursor.return_value = make_cursor_ctx(mock_cursor)
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            with pytest.raises(ConnectorConnectionError):
                await client.execute("BAD SQL", ())


class TestAsyncClientContextManager:
    async def test_async_context_manager_connects_and_closes(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            async with AsyncClient(password_config) as client:
                assert client is not None

            mock_conn.close.assert_called_once()

    async def test_async_context_manager_closes_on_exception(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            with pytest.raises(ValueError):
                async with AsyncClient(password_config):
                    raise ValueError("boom")

            mock_conn.close.assert_called_once()


class TestAsyncClientTransaction:
    async def test_transaction_commits_on_clean_exit(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            async with client.transaction():
                pass
            mock_conn.commit.assert_called_once()
            mock_conn.rollback.assert_not_called()

    async def test_transaction_rollbacks_and_reraises_on_exception(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            with pytest.raises(ValueError):
                async with client.transaction():
                    raise ValueError("oops")
            mock_conn.rollback.assert_called_once()
            mock_conn.commit.assert_not_called()

    async def test_nested_transaction_raises_connector_error(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            with pytest.raises(ConnectorError, match=r"Already in a transaction"):
                async with client.transaction():
                    async with client.transaction():
                        pass

    async def test_transaction_flag_reset_after_exit(self, password_config: ConnectionConfig) -> None:
        mock_conn = make_mock_conn()
        with patch(
            "db_connector.async_client.psycopg.AsyncConnection.connect",
            new_callable=AsyncMock,
            return_value=mock_conn,
        ):
            client = AsyncClient(password_config)
            await client.connect()
            async with client.transaction():
                pass
            assert not client._in_transaction
