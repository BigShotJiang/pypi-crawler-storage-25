from __future__ import annotations

import socket

import psycopg
import pytest

from db_connector.error_mapping import raise_mapped_connector_error
from db_connector.errors import ConnectorConnectionError, ConnectorTimeoutError


def test_psycopg_operational_error_maps_to_connector_connection_error():
    exc = psycopg.OperationalError("connection failed")
    with pytest.raises(ConnectorConnectionError) as exc_info:
        raise_mapped_connector_error(exc)
    assert exc_info.value.cause is exc


def test_socket_timeout_maps_to_connector_timeout_error():
    exc = TimeoutError("timed out")
    with pytest.raises(ConnectorTimeoutError) as exc_info:
        raise_mapped_connector_error(exc)
    assert exc_info.value.cause is exc


def test_socket_gaierror_maps_to_connector_connection_error():
    exc = socket.gaierror("name resolution failed")
    with pytest.raises(ConnectorConnectionError) as exc_info:
        raise_mapped_connector_error(exc)
    assert exc_info.value.cause is exc


def test_connection_refused_error_maps_to_connector_connection_error():
    exc = ConnectionRefusedError("connection refused")
    with pytest.raises(ConnectorConnectionError) as exc_info:
        raise_mapped_connector_error(exc)
    assert exc_info.value.cause is exc


def test_os_error_maps_to_connector_connection_error():
    exc = OSError("os error")
    with pytest.raises(ConnectorConnectionError) as exc_info:
        raise_mapped_connector_error(exc)
    assert exc_info.value.cause is exc


def test_unknown_exception_maps_to_connector_connection_error():
    exc = RuntimeError("unexpected")
    with pytest.raises(ConnectorConnectionError) as exc_info:
        raise_mapped_connector_error(exc)
    assert exc_info.value.cause is exc


def test_mapped_error_message_contains_original():
    exc = psycopg.OperationalError("disk full")
    with pytest.raises(ConnectorConnectionError, match="disk full"):
        raise_mapped_connector_error(exc)


def test_socket_timeout_message_preserved():
    exc = TimeoutError("deadline exceeded")
    with pytest.raises(ConnectorTimeoutError, match="deadline exceeded"):
        raise_mapped_connector_error(exc)


def test_raise_mapped_connector_error_never_returns():
    """raise_mapped_connector_error is typed NoReturn — always raises."""
    exc = OSError("test")
    with pytest.raises(ConnectorConnectionError):
        raise_mapped_connector_error(exc)
