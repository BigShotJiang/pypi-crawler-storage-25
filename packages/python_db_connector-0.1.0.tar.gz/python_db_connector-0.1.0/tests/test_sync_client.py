from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from db_connector.config import ConnectionConfig
from db_connector.errors import ConnectorConnectionError
from db_connector.sync_client import SyncClient


@pytest.fixture
def password_config() -> ConnectionConfig:
    return ConnectionConfig(
        host="db.example.com",
        port=5432,
        dbname="mydb",
        user="myuser",
        password="secret",
    )


class TestSyncClientConnect:
    def test_connect_password_auth_calls_psycopg_connect(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn) as mock_connect:
            client = SyncClient(password_config)
            client.connect()

            mock_connect.assert_called_once()
            call_kwargs = mock_connect.call_args[1]
            assert call_kwargs["host"] == "db.example.com"
            assert call_kwargs["port"] == 5432
            assert call_kwargs["dbname"] == "mydb"
            assert call_kwargs["user"] == "myuser"
            assert call_kwargs["password"] == "secret"
            assert call_kwargs["sslmode"] == "require"

    def test_connect_passes_sslmode(self, password_config: ConnectionConfig) -> None:
        password_config.sslmode = "verify-full"
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn) as mock_connect:
            client = SyncClient(password_config)
            client.connect()

            call_kwargs = mock_connect.call_args[1]
            assert call_kwargs["sslmode"] == "verify-full"

    def test_connect_error_raises_connector_error(self, password_config: ConnectionConfig) -> None:
        import psycopg

        with patch("db_connector.sync_client.psycopg.connect", side_effect=psycopg.OperationalError("refused")):
            client = SyncClient(password_config)
            with pytest.raises(ConnectorConnectionError):
                client.connect()


class TestSyncClientClose:
    def test_close_calls_connection_close(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            client.close()

            mock_conn.close.assert_called_once()

    def test_close_without_connect_does_not_raise(self, password_config: ConnectionConfig) -> None:
        client = SyncClient(password_config)
        client.close()  # should not raise


class TestSyncClientQueryExecution:
    def test_execute_calls_cursor_execute(self, password_config: ConnectionConfig) -> None:
        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            client.execute("INSERT INTO t VALUES (%s)", (1,))
            mock_cursor.execute.assert_called_once_with("INSERT INTO t VALUES (%s)", (1,))

    def test_fetchall_returns_all_rows(self, password_config: ConnectionConfig) -> None:
        rows = [(1, "a"), (2, "b")]
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = rows
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            result = client.fetchall("SELECT * FROM t", ())
            assert result == rows

    def test_fetchone_returns_one_row(self, password_config: ConnectionConfig) -> None:
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = (1, "a")
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            result = client.fetchone("SELECT * FROM t WHERE id=%s", (1,))
            assert result == (1, "a")

    def test_fetchone_returns_none_when_no_row(self, password_config: ConnectionConfig) -> None:
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = None
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            result = client.fetchone("SELECT * FROM t WHERE id=%s", (999,))
            assert result is None

    def test_fetchmany_returns_up_to_size_rows(self, password_config: ConnectionConfig) -> None:
        rows = [(1, "a"), (2, "b")]
        mock_cursor = MagicMock()
        mock_cursor.fetchmany.return_value = rows
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            result = client.fetchmany("SELECT * FROM t", (), size=50)
            mock_cursor.fetchmany.assert_called_once_with(50)
            assert result == rows

    def test_fetchmany_default_size_is_100(self, password_config: ConnectionConfig) -> None:
        mock_cursor = MagicMock()
        mock_cursor.fetchmany.return_value = []
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            client.fetchmany("SELECT * FROM t", ())
            mock_cursor.fetchmany.assert_called_once_with(100)

    def test_execute_maps_exception_on_error(self, password_config: ConnectionConfig) -> None:
        import psycopg as _psycopg

        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = _psycopg.OperationalError("conn lost")
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            with pytest.raises(ConnectorConnectionError):
                client.execute("BAD SQL", ())


class TestSyncClientTransactions:
    def test_transaction_commits_on_clean_exit(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            with client.transaction():
                pass
            mock_conn.commit.assert_called_once()
            mock_conn.rollback.assert_not_called()

    def test_transaction_rollbacks_and_reraises_on_exception(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            with pytest.raises(ValueError, match=r"boom"):
                with client.transaction():
                    raise ValueError("boom")
            mock_conn.rollback.assert_called_once()
            mock_conn.commit.assert_not_called()

    def test_nested_transaction_raises_connector_error(self, password_config: ConnectionConfig) -> None:
        from db_connector.errors import ConnectorError

        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            with pytest.raises(ConnectorError, match=r"Already in a transaction"):
                with client.transaction():
                    with client.transaction():
                        pass

    def test_transaction_flag_reset_after_exit(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            client = SyncClient(password_config)
            client.connect()
            with client.transaction():
                pass
            # Should be able to start a second transaction after the first completes
            with client.transaction():
                pass
            assert mock_conn.commit.call_count == 2


class TestSyncClientContextManager:
    def test_context_manager_connects_and_closes(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            with SyncClient(password_config) as client:
                assert client is not None

            mock_conn.close.assert_called_once()

    def test_context_manager_closes_on_exception(self, password_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn):
            with pytest.raises(ValueError):
                with SyncClient(password_config):
                    raise ValueError("boom")

            mock_conn.close.assert_called_once()
