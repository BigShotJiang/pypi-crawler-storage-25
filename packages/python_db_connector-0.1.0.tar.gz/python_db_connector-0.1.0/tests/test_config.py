from __future__ import annotations

import pytest

from db_connector.config import ConnectionConfig, connection_config_from_env, connection_config_from_mapping

# --- ConnectionConfig dataclass ---


def test_connection_config_defaults():
    cfg = ConnectionConfig(host="localhost", port=5432, dbname="mydb", user="me")
    assert cfg.port == 5432
    assert cfg.sslmode == "require"
    assert cfg.password == ""


def test_connection_config_with_password():
    cfg = ConnectionConfig(host="h", port=5432, dbname="d", user="u", password="secret")
    assert cfg.password == "secret"


def test_connection_config_custom_sslmode():
    cfg = ConnectionConfig(host="h", port=5432, dbname="d", user="u", sslmode="verify-full")
    assert cfg.sslmode == "verify-full"


# --- connection_config_from_env ---


def test_from_env_password_auth(monkeypatch):
    monkeypatch.setenv("SANDBOX_DEV_HOST", "rds.example.com")
    monkeypatch.setenv("SANDBOX_DEV_PORT", "5433")
    monkeypatch.setenv("SANDBOX_DEV_DBNAME", "sandbox")
    monkeypatch.setenv("SANDBOX_DEV_USER", "appuser")
    monkeypatch.setenv("SANDBOX_DEV_PASSWORD", "s3cr3t")

    cfg = connection_config_from_env("SANDBOX", "DEV")

    assert cfg.host == "rds.example.com"
    assert cfg.port == 5433
    assert cfg.dbname == "sandbox"
    assert cfg.user == "appuser"
    assert cfg.password == "s3cr3t"


def test_from_env_port_defaults_when_blank(monkeypatch):
    monkeypatch.setenv("RESEARCH_DEV_HOST", "h")
    monkeypatch.setenv("RESEARCH_DEV_DBNAME", "d")
    monkeypatch.setenv("RESEARCH_DEV_USER", "u")
    monkeypatch.setenv("RESEARCH_DEV_PASSWORD", "p")
    monkeypatch.setenv("RESEARCH_DEV_PORT", "")

    cfg = connection_config_from_env("RESEARCH", "DEV")
    assert cfg.port == 5432


def test_from_env_missing_host_raises(monkeypatch):
    monkeypatch.delenv("SANDBOX_DEV_HOST", raising=False)
    monkeypatch.setenv("SANDBOX_DEV_DBNAME", "d")
    monkeypatch.setenv("SANDBOX_DEV_USER", "u")
    monkeypatch.setenv("SANDBOX_DEV_PASSWORD", "p")

    with pytest.raises(ValueError, match="SANDBOX_DEV_HOST"):
        connection_config_from_env("SANDBOX", "DEV")


def test_from_env_missing_dbname_raises(monkeypatch):
    monkeypatch.setenv("SANDBOX_DEV_HOST", "h")
    monkeypatch.delenv("SANDBOX_DEV_DBNAME", raising=False)
    monkeypatch.setenv("SANDBOX_DEV_USER", "u")
    monkeypatch.setenv("SANDBOX_DEV_PASSWORD", "p")

    with pytest.raises(ValueError, match="SANDBOX_DEV_DBNAME"):
        connection_config_from_env("SANDBOX", "DEV")


def test_from_env_missing_user_raises(monkeypatch):
    monkeypatch.setenv("SANDBOX_DEV_HOST", "h")
    monkeypatch.setenv("SANDBOX_DEV_DBNAME", "d")
    monkeypatch.delenv("SANDBOX_DEV_USER", raising=False)
    monkeypatch.setenv("SANDBOX_DEV_PASSWORD", "p")

    with pytest.raises(ValueError, match="SANDBOX_DEV_USER"):
        connection_config_from_env("SANDBOX", "DEV")


def test_from_env_missing_password_raises(monkeypatch):
    monkeypatch.setenv("SANDBOX_DEV_HOST", "h")
    monkeypatch.setenv("SANDBOX_DEV_DBNAME", "d")
    monkeypatch.setenv("SANDBOX_DEV_USER", "u")
    monkeypatch.delenv("SANDBOX_DEV_PASSWORD", raising=False)

    with pytest.raises(ValueError, match="PASSWORD"):
        connection_config_from_env("SANDBOX", "DEV")


def test_from_env_lowercase_database_and_env(monkeypatch):
    """database and environment args are uppercased automatically."""
    monkeypatch.setenv("SANDBOX_DEV_HOST", "h")
    monkeypatch.setenv("SANDBOX_DEV_DBNAME", "d")
    monkeypatch.setenv("SANDBOX_DEV_USER", "u")
    monkeypatch.setenv("SANDBOX_DEV_PASSWORD", "p")

    cfg = connection_config_from_env("sandbox", "dev")
    assert cfg.host == "h"


# --- connection_config_from_mapping ---


def test_from_mapping_basic():
    cfg = connection_config_from_mapping(
        {
            "host": "rds.example.com",
            "port": 5432,
            "dbname": "mydb",
            "username": "appuser",
            "password": "pw",
        }
    )
    assert cfg.host == "rds.example.com"
    assert cfg.user == "appuser"
    assert cfg.password == "pw"


def test_from_mapping_engine_field_is_ignored():
    cfg = connection_config_from_mapping(
        {
            "host": "h",
            "port": 5432,
            "dbname": "d",
            "username": "u",
            "password": "p",
            "engine": "postgres",
        }
    )
    assert cfg.host == "h"


def test_from_mapping_port_string_is_coerced():
    cfg = connection_config_from_mapping(
        {
            "host": "h",
            "port": "5433",
            "dbname": "d",
            "username": "u",
            "password": "p",
        }
    )
    assert cfg.port == 5433


def test_from_mapping_missing_host_raises():
    with pytest.raises(ValueError, match="host"):
        connection_config_from_mapping({"dbname": "d", "username": "u", "password": "p"})


def test_from_mapping_missing_password_raises():
    with pytest.raises(ValueError, match="password"):
        connection_config_from_mapping({"host": "h", "dbname": "d", "username": "u"})
