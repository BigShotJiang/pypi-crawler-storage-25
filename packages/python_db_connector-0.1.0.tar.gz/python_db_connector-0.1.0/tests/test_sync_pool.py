from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from db_connector.config import ConnectionConfig
from db_connector.sync_client import SyncClient


@pytest.fixture
def pool_config() -> ConnectionConfig:
    return ConnectionConfig(
        host="db.example.com",
        port=5432,
        dbname="mydb",
        user="myuser",
        password="secret",
    )


class TestSyncClientPool:
    def test_connect_creates_connection_pool_when_pool_true(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn.return_value = mock_conn
        with patch("db_connector.sync_client.psycopg_pool.ConnectionPool", return_value=mock_pool) as mock_cls:
            client = SyncClient(pool_config, pool=True, min_connections=2, max_connections=5)
            client.connect()
            mock_cls.assert_called_once()
            call_kwargs = mock_cls.call_args[1]
            assert call_kwargs["min_size"] == 2
            assert call_kwargs["max_size"] == 5

    def test_connect_gets_connection_from_pool(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn.return_value = mock_conn
        with patch("db_connector.sync_client.psycopg_pool.ConnectionPool", return_value=mock_pool):
            client = SyncClient(pool_config, pool=True)
            client.connect()
            mock_pool.getconn.assert_called_once()
            assert client._connection is mock_conn

    def test_close_puts_connection_back_and_closes_pool(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn.return_value = mock_conn
        with patch("db_connector.sync_client.psycopg_pool.ConnectionPool", return_value=mock_pool):
            client = SyncClient(pool_config, pool=True)
            client.connect()
            client.close()
            mock_pool.putconn.assert_called_once_with(mock_conn)
            mock_pool.close.assert_called_once()

    def test_close_clears_connection_and_pool_references(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn.return_value = mock_conn
        with patch("db_connector.sync_client.psycopg_pool.ConnectionPool", return_value=mock_pool):
            client = SyncClient(pool_config, pool=True)
            client.connect()
            client.close()
            assert client._connection is None
            assert client._pool_obj is None

    def test_close_without_connect_does_not_raise_when_pool_true(self, pool_config: ConnectionConfig) -> None:
        with patch("db_connector.sync_client.psycopg_pool.ConnectionPool"):
            client = SyncClient(pool_config, pool=True)
            client.close()  # should not raise

    def test_pool_false_does_not_create_connection_pool(self, pool_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with (
            patch("db_connector.sync_client.psycopg.connect", return_value=mock_conn),
            patch("db_connector.sync_client.psycopg_pool.ConnectionPool") as mock_cls,
        ):
            client = SyncClient(pool_config, pool=False)
            client.connect()
            mock_cls.assert_not_called()

    def test_pool_connection_kwargs_passed_to_pool(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn.return_value = mock_conn
        with patch("db_connector.sync_client.psycopg_pool.ConnectionPool", return_value=mock_pool) as mock_cls:
            client = SyncClient(pool_config, pool=True)
            client.connect()
            call_kwargs = mock_cls.call_args[1]
            conn_kwargs = call_kwargs["kwargs"]
            assert conn_kwargs["host"] == "db.example.com"
            assert conn_kwargs["password"] == "secret"
            assert conn_kwargs["dbname"] == "mydb"
            assert conn_kwargs["user"] == "myuser"
            assert conn_kwargs["port"] == 5432
