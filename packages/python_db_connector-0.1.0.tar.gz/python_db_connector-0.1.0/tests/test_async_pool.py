from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from db_connector.async_client import AsyncClient
from db_connector.config import ConnectionConfig


@pytest.fixture
def pool_config() -> ConnectionConfig:
    return ConnectionConfig(
        host="db.example.com",
        port=5432,
        dbname="mydb",
        user="myuser",
        password="secret",
    )


class TestAsyncClientPool:
    async def test_connect_creates_async_connection_pool_when_pool_true(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn = AsyncMock(return_value=mock_conn)
        with patch(
            "db_connector.async_client.psycopg_pool.AsyncConnectionPool",
            return_value=mock_pool,
        ) as mock_cls:
            client = AsyncClient(pool_config, pool=True, min_connections=2, max_connections=5)
            await client.connect()
            mock_cls.assert_called_once()
            call_kwargs = mock_cls.call_args[1]
            assert call_kwargs["min_size"] == 2
            assert call_kwargs["max_size"] == 5

    async def test_connect_gets_connection_from_async_pool(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn = AsyncMock(return_value=mock_conn)
        with patch(
            "db_connector.async_client.psycopg_pool.AsyncConnectionPool",
            return_value=mock_pool,
        ):
            client = AsyncClient(pool_config, pool=True)
            await client.connect()
            mock_pool.getconn.assert_called_once()
            assert client._connection is mock_conn

    async def test_close_puts_connection_back_and_closes_pool(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn = AsyncMock(return_value=mock_conn)
        mock_pool.putconn = AsyncMock()
        mock_pool.close = AsyncMock()
        with patch(
            "db_connector.async_client.psycopg_pool.AsyncConnectionPool",
            return_value=mock_pool,
        ):
            client = AsyncClient(pool_config, pool=True)
            await client.connect()
            await client.close()
            mock_pool.putconn.assert_called_once_with(mock_conn)
            mock_pool.close.assert_called_once()

    async def test_close_clears_connection_and_pool_references(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn = AsyncMock(return_value=mock_conn)
        mock_pool.putconn = AsyncMock()
        mock_pool.close = AsyncMock()
        with patch(
            "db_connector.async_client.psycopg_pool.AsyncConnectionPool",
            return_value=mock_pool,
        ):
            client = AsyncClient(pool_config, pool=True)
            await client.connect()
            await client.close()
            assert client._connection is None
            assert client._pool_obj is None

    async def test_close_without_connect_does_not_raise_when_pool_true(self, pool_config: ConnectionConfig) -> None:
        with patch("db_connector.async_client.psycopg_pool.AsyncConnectionPool"):
            client = AsyncClient(pool_config, pool=True)
            await client.close()  # should not raise

    async def test_pool_false_does_not_create_async_connection_pool(self, pool_config: ConnectionConfig) -> None:
        mock_conn = MagicMock()
        with (
            patch(
                "db_connector.async_client.psycopg.AsyncConnection.connect",
                new_callable=AsyncMock,
                return_value=mock_conn,
            ),
            patch("db_connector.async_client.psycopg_pool.AsyncConnectionPool") as mock_cls,
        ):
            client = AsyncClient(pool_config, pool=False)
            await client.connect()
            mock_cls.assert_not_called()

    async def test_pool_connection_kwargs_passed_to_async_pool(self, pool_config: ConnectionConfig) -> None:
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_pool.getconn = AsyncMock(return_value=mock_conn)
        with patch(
            "db_connector.async_client.psycopg_pool.AsyncConnectionPool",
            return_value=mock_pool,
        ) as mock_cls:
            client = AsyncClient(pool_config, pool=True)
            await client.connect()
            call_kwargs = mock_cls.call_args[1]
            conn_kwargs = call_kwargs["kwargs"]
            assert conn_kwargs["host"] == "db.example.com"
            assert conn_kwargs["password"] == "secret"
            assert conn_kwargs["dbname"] == "mydb"
            assert conn_kwargs["user"] == "myuser"
            assert conn_kwargs["port"] == 5432
