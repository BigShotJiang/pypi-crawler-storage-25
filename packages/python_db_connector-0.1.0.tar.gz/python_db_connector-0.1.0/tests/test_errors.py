import pytest

from db_connector.errors import (
    AuthenticationError,
    ConnectorConnectionError,
    ConnectorError,
    ConnectorTimeoutError,
    DatabaseAuthenticationError,
)


def test_connector_error_is_exception():
    assert issubclass(ConnectorError, Exception)


def test_connector_error_message():
    err = ConnectorError("something went wrong")
    assert str(err) == "something went wrong"


def test_connector_error_no_cause_by_default():
    err = ConnectorError("msg")
    assert err.cause is None


def test_connector_error_with_cause():
    cause = ValueError("root")
    err = ConnectorError("msg", cause=cause)
    assert err.cause is cause


def test_authentication_error_inherits_connector_error():
    assert issubclass(AuthenticationError, ConnectorError)


def test_authentication_error_message():
    err = AuthenticationError("auth failed")
    assert str(err) == "auth failed"


def test_authentication_error_with_cause():
    cause = RuntimeError("boom")
    err = AuthenticationError("auth failed", cause=cause)
    assert err.cause is cause


def test_database_authentication_error_inherits_authentication_error():
    assert issubclass(DatabaseAuthenticationError, AuthenticationError)


def test_database_authentication_error_message():
    err = DatabaseAuthenticationError("db auth failed")
    assert str(err) == "db auth failed"


def test_connector_timeout_error_inherits_connector_error():
    assert issubclass(ConnectorTimeoutError, ConnectorError)


def test_connector_timeout_error_message():
    err = ConnectorTimeoutError("timed out")
    assert str(err) == "timed out"


def test_connector_connection_error_inherits_connector_error():
    assert issubclass(ConnectorConnectionError, ConnectorError)


def test_connector_connection_error_message():
    err = ConnectorConnectionError("connection refused")
    assert str(err) == "connection refused"


def test_all_errors_catchable_as_connector_error():
    errors = [
        AuthenticationError("a"),
        DatabaseAuthenticationError("b"),
        ConnectorTimeoutError("c"),
        ConnectorConnectionError("d"),
    ]
    for err in errors:
        assert isinstance(err, ConnectorError)


def test_can_raise_and_catch():
    with pytest.raises(ConnectorError, match="boom"):
        raise ConnectorError("boom")
