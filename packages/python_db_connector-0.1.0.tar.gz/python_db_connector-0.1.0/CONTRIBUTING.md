# Contributing

## Dev Setup

```bash
git clone git@github.com:AVL-Foundation/python-db-connector.git
cd python-db-connector
python -m venv python-db-connector-env
source python-db-connector-env/bin/activate
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check src/ tests/

# Format
ruff format src/ tests/

# Type check
mypy src/
```

## Releasing a New Version

### Tags vs Releases

A **tag** is a Git pointer to a specific commit — it marks a point in history but does nothing else:

```bash
git tag v0.1.0
git push origin v0.1.0
```

A **release** is a GitHub feature built on top of a tag. When you publish a release, GitHub creates the tag (if it doesn't exist) and triggers any workflow listening for the `release` event. The `publish.yml` workflow only runs on a **release**, not on a tag push alone.

### How to publish

1. Bump the `version` in `pyproject.toml`
2. Commit and push to `main`
3. Create a GitHub Release using the CLI or the web UI
4. The `publish.yml` workflow automatically builds and publishes to PyPI

Using the CLI:

```bash
gh release create v0.1.0 --title "v0.1.0" --generate-notes --repo AVL-Foundation/python-db-connector
```

Using the web UI: go to **Releases → Create a new release**, enter the tag (e.g. `v0.1.0`), add a title, and click **Publish release**.

### What does NOT trigger a publish

- Pushing commits or merging PRs to `main` — only `tests.yml` and `code-quality.yml` run
- Pushing a tag with `git push origin v0.1.0` — no workflow runs
- Creating a **draft** release — the workflow runs only when the release is **published**

## Test Connection

A helper script verifies connectivity against any configured database/environment pair. It tests both the sync and async clients, reports timing, and prints the server version.

```bash
# Install python-dotenv if not already present
pip install python-dotenv

# Test a specific database + environment (reads from .env by default)
python scripts/test_connection.py sandbox dev

# Use a custom .env path
python scripts/test_connection.py treasury prod --env-file /path/to/.env

# Sync client only
python scripts/test_connection.py sandbox dev --sync-only

# Async client only
python scripts/test_connection.py sandbox dev --async-only
```

Example output:

```
--------------------------------------------------
  Testing connection: SANDBOX / DEV
--------------------------------------------------

i Sync client  |  host=sandbox-rds-dev.example.com:5432  db=sandbox  auth=password
  ✔ Connected in 0.128s
  ✔ Server version: PostgreSQL 15.4 on x86_64-pc-linux-gnu ...

i Async client  |  host=sandbox-rds-dev.example.com:5432  db=sandbox  auth=password
  ✔ Connected in 0.097s
  ✔ Server version: PostgreSQL 15.4 on x86_64-pc-linux-gnu ...

--------------------------------------------------
  ✔ All checks passed
--------------------------------------------------
```

The script exits with code `0` on success and `1` if any check fails.
