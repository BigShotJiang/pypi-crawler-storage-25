from __future__ import annotations

from collections.abc import AsyncGenerator, Sequence
from contextlib import asynccontextmanager
from types import TracebackType
from typing import Any

import psycopg
import psycopg_pool

from db_connector.config import ConnectionConfig
from db_connector.error_mapping import raise_mapped_connector_error
from db_connector.errors import ConnectorError


class AsyncClient:
    def __init__(
        self,
        config: ConnectionConfig,
        pool: bool = False,
        min_connections: int = 1,
        max_connections: int = 10,
    ) -> None:
        self._config = config
        self._pool = pool
        self._min_connections = min_connections
        self._max_connections = max_connections
        self._connection: psycopg.AsyncConnection[Any] | None = None
        self._pool_obj: psycopg_pool.AsyncConnectionPool[psycopg.AsyncConnection[Any]] | None = None
        self._in_transaction: bool = False

    async def connect(self) -> None:
        conn_kwargs: dict[str, Any] = {
            "host": self._config.host,
            "port": self._config.port,
            "dbname": self._config.dbname,
            "user": self._config.user,
            "password": self._config.password,
            "sslmode": self._config.sslmode,
        }
        try:
            if self._pool:
                self._pool_obj = psycopg_pool.AsyncConnectionPool(
                    conninfo="",
                    kwargs=conn_kwargs,
                    min_size=self._min_connections,
                    max_size=self._max_connections,
                )
                self._connection = await self._pool_obj.getconn()
            else:
                self._connection = await psycopg.AsyncConnection.connect(**conn_kwargs)
        except Exception as exc:
            raise_mapped_connector_error(exc)

    async def close(self) -> None:
        if self._pool and self._pool_obj is not None:
            if self._connection is not None:
                await self._pool_obj.putconn(self._connection)
                self._connection = None
            await self._pool_obj.close()
            self._pool_obj = None
        elif self._connection is not None:
            await self._connection.close()
            self._connection = None

    async def execute(self, query: str, params: Sequence[Any] = ()) -> None:
        try:
            async with self._connection.cursor() as cur:  # type: ignore[union-attr]
                await cur.execute(query, params)
        except Exception as exc:
            raise_mapped_connector_error(exc)

    async def fetchall(self, query: str, params: Sequence[Any] = ()) -> list[tuple[Any, ...]]:
        try:
            async with self._connection.cursor() as cur:  # type: ignore[union-attr]
                await cur.execute(query, params)
                return await cur.fetchall()
        except Exception as exc:
            raise_mapped_connector_error(exc)

    async def fetchone(self, query: str, params: Sequence[Any] = ()) -> tuple[Any, ...] | None:
        try:
            async with self._connection.cursor() as cur:  # type: ignore[union-attr]
                await cur.execute(query, params)
                return await cur.fetchone()
        except Exception as exc:
            raise_mapped_connector_error(exc)

    async def fetchmany(self, query: str, params: Sequence[Any] = (), size: int = 100) -> list[tuple[Any, ...]]:
        try:
            async with self._connection.cursor() as cur:  # type: ignore[union-attr]
                await cur.execute(query, params)
                return await cur.fetchmany(size)
        except Exception as exc:
            raise_mapped_connector_error(exc)

    @asynccontextmanager
    async def transaction(self) -> AsyncGenerator[None, None]:
        if self._in_transaction:
            raise ConnectorError("Already in a transaction")
        self._in_transaction = True
        try:
            yield
            await self._connection.commit()  # type: ignore[union-attr]
        except Exception:
            await self._connection.rollback()  # type: ignore[union-attr]
            raise
        finally:
            self._in_transaction = False

    async def __aenter__(self) -> AsyncClient:
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
