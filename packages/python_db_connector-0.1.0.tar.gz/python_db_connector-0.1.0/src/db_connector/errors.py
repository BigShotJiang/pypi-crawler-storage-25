from __future__ import annotations


class ConnectorError(Exception):
    def __init__(self, message: str, *, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.cause = cause

    def __str__(self) -> str:
        return str(self.args[0])


class AuthenticationError(ConnectorError):
    pass


class DatabaseAuthenticationError(AuthenticationError):
    pass


class ConnectorTimeoutError(ConnectorError):
    pass


class ConnectorConnectionError(ConnectorError):
    pass
