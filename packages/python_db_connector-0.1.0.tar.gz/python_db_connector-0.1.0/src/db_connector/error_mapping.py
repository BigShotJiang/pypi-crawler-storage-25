from __future__ import annotations

import socket
from typing import NoReturn

import psycopg

from db_connector.errors import ConnectorConnectionError, ConnectorTimeoutError


def raise_mapped_connector_error(exc: Exception) -> NoReturn:
    """Map raw driver/socket exceptions to the library's error hierarchy."""
    if isinstance(exc, socket.timeout):
        raise ConnectorTimeoutError(str(exc), cause=exc) from exc
    if isinstance(exc, (psycopg.OperationalError, socket.gaierror, ConnectionRefusedError, OSError)):
        raise ConnectorConnectionError(str(exc), cause=exc) from exc
    raise ConnectorConnectionError(str(exc), cause=exc) from exc
