from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class ConnectionConfig:
    host: str
    port: int
    dbname: str
    user: str
    password: str = ""
    sslmode: str = field(default="require")


def connection_config_from_env(database: str, environment: str) -> ConnectionConfig:
    prefix = f"{database.upper()}_{environment.upper()}"

    def get(name: str) -> str | None:
        return os.environ.get(f"{prefix}_{name}") or None

    host = get("HOST")
    if not host:
        raise ValueError(f"Required environment variable {prefix}_HOST is not set")

    dbname = get("DBNAME")
    if not dbname:
        raise ValueError(f"Required environment variable {prefix}_DBNAME is not set")

    user = get("USER")
    if not user:
        raise ValueError(f"Required environment variable {prefix}_USER is not set")

    port_raw = os.environ.get(f"{prefix}_PORT", "")
    port = int(port_raw) if port_raw.strip() else 5432

    password = get("PASSWORD")
    if not password:
        raise ValueError(f"Required environment variable {prefix}_PASSWORD is not set")

    return ConnectionConfig(
        host=host,
        port=port,
        dbname=dbname,
        user=user,
        password=password,
    )


def connection_config_from_mapping(data: dict) -> ConnectionConfig:  # type: ignore[type-arg]
    host = data.get("host")
    if not host:
        raise ValueError("Required field 'host' is missing from mapping")

    dbname = data.get("dbname")
    if not dbname:
        raise ValueError("Required field 'dbname' is missing from mapping")

    user = data.get("username")
    if not user:
        raise ValueError("Required field 'username' is missing from mapping")

    port_raw = data.get("port", 5432)
    port = int(port_raw) if port_raw else 5432

    password = data.get("password")
    if not password:
        raise ValueError("Required field 'password' is missing from mapping")

    return ConnectionConfig(
        host=host,
        port=port,
        dbname=dbname,
        user=user,
        password=password,
    )
