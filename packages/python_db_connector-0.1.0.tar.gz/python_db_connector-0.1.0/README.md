# python-db-connector

Installable Python library providing sync and async PostgreSQL connectivity to Amazon RDS with password authentication, connection pooling, and context-manager transactions.

## Install

```bash
pip install python-db-connector
```

In your `requirements.txt`:

```
python-db-connector==0.1.0
```

Or in your `pyproject.toml`:

```toml
dependencies = [
    "python-db-connector>=0.1.0",
]
```

## Quick Start

### Sync client

```python
from db_connector import SyncClient, ConnectionConfig

config = ConnectionConfig(
    host="mydb.cluster.us-east-1.rds.amazonaws.com",
    port=5432,
    dbname="mydb",
    user="myuser",
    password="secret",
)

with SyncClient(config) as client:
    rows = client.fetchall("SELECT id, name FROM users WHERE active = %s", [True])
    for row in rows:
        print(row)
```

### Async client

```python
import asyncio
from db_connector import AsyncClient, ConnectionConfig

config = ConnectionConfig(
    host="mydb.cluster.us-east-1.rds.amazonaws.com",
    port=5432,
    dbname="mydb",
    user="myuser",
    password="secret",
)

async def main():
    async with AsyncClient(config) as client:
        row = await client.fetchone("SELECT version()")
        print(row)

asyncio.run(main())
```

## Environment Variable Configuration

Use `connection_config_from_env` to build a `ConnectionConfig` from environment variables following the `{DATABASE}_{ENVIRONMENT}_{FIELD}` naming convention:

```python
from db_connector import connection_config_from_env

config = connection_config_from_env("treasury", "prod")
```

This reads the following variables:

| Variable | Required | Description |
|---|---|---|
| `TREASURY_PROD_HOST` | yes | Database host |
| `TREASURY_PROD_DBNAME` | yes | Database name |
| `TREASURY_PROD_USER` | yes | Database user |
| `TREASURY_PROD_PASSWORD` | yes | Database password |
| `TREASURY_PROD_PORT` | no | Port (default: 5432) |

See `.env.example` for a full list of variable templates.

You can also build a config from a dictionary:

```python
from db_connector import connection_config_from_mapping

config = connection_config_from_mapping({
    "host": "mydb.example.com",
    "dbname": "mydb",
    "username": "myuser",
    "password": "secret",
})
```

## Connection Pooling

Both `SyncClient` and `AsyncClient` accept pooling parameters:

| Parameter | Default | Description |
|---|---|---|
| `pool` | `False` | When `True`, the client creates a connection pool instead of a single connection. A pool keeps multiple connections open and reuses them across queries, avoiding the overhead of connecting/disconnecting on every call. |
| `min_connections` | `1` | Minimum number of connections the pool keeps open at all times, even when idle. Set higher if your application has a steady baseline of concurrent queries. |
| `max_connections` | `10` | Maximum number of connections the pool is allowed to open. When all connections are in use, new requests wait until one is returned. Set this based on your database's connection limit and expected concurrency. |

### `pool` -- single connection vs pooled

Without pooling (default), each client holds exactly one connection:

```python
# Single connection — good for scripts, CLIs, or low-concurrency tasks
with SyncClient(config) as client:
    rows = client.fetchall("SELECT count(*) FROM orders")
```

Enable pooling for workloads that run many queries concurrently:

```python
# Pooled — reuses connections instead of opening/closing each time
with SyncClient(config, pool=True) as client:
    rows = client.fetchall("SELECT count(*) FROM orders")
```

### `min_connections` -- warm connections kept idle

The pool pre-opens this many connections and keeps them alive even when idle, so queries don't pay the connect cost:

```python
# Keep 5 connections always ready (e.g. a web server with steady traffic)
with SyncClient(config, pool=True, min_connections=5) as client:
    rows = client.fetchall("SELECT count(*) FROM orders")
```

### `max_connections` -- concurrency ceiling

The pool never opens more than this many connections. If all are busy, new queries wait until one is returned:

```python
# Allow up to 30 concurrent connections (e.g. a high-throughput batch job)
with SyncClient(config, pool=True, min_connections=5, max_connections=30) as client:
    rows = client.fetchall("SELECT count(*) FROM orders")
```

### Async pooling

All three parameters work the same way with `AsyncClient`:

```python
async with AsyncClient(config, pool=True, min_connections=2, max_connections=20) as client:
    row = await client.fetchone("SELECT count(*) FROM orders")
```

## Transactions

Use `client.transaction()` to group statements. The block auto-commits on success and auto-rolls back on exception.

### Sync

```python
with SyncClient(config) as client:
    with client.transaction():
        client.execute("INSERT INTO accounts (name) VALUES (%s)", ["Alice"])
        client.execute("INSERT INTO accounts (name) VALUES (%s)", ["Bob"])
```

### Async

```python
async with AsyncClient(config) as client:
    async with client.transaction():
        await client.execute("INSERT INTO accounts (name) VALUES (%s)", ["Alice"])
        await client.execute("INSERT INTO accounts (name) VALUES (%s)", ["Bob"])
```

Nesting `transaction()` inside another `transaction()` raises `ConnectorError("Already in a transaction")`.

## Error Handling

All exceptions raised by the library descend from `ConnectorError`:

```
ConnectorError
├── AuthenticationError
│   └── DatabaseAuthenticationError — DB rejected credentials
├── ConnectorTimeoutError        — connection or query timed out
└── ConnectorConnectionError     — network/DNS/refused errors
```

```python
from db_connector import SyncClient, ConnectorError, ConnectorTimeoutError

try:
    with SyncClient(config) as client:
        rows = client.fetchall("SELECT 1")
except ConnectorTimeoutError as exc:
    print(f"Timed out: {exc}")
except ConnectorError as exc:
    print(f"DB error: {exc} (cause: {exc.cause})")
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, releasing, and testing.
