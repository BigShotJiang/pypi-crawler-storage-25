# Design

**Goal**: Define HOW to build it. Architecture, modules, what to reuse.

**Skip this phase when:** The change is straightforward — no architectural decisions, no new patterns, no module interactions to plan. For simple features, design happens inline during Execute.

## Process

### 1. Load Context

Read the spec before designing. If a context document exists with implementation decisions, load it too — it contains decisions that constrain the design (API shape, behavior preferences, data flow). Decisions marked as "Agent's Discretion" are yours to decide.

### 1.5. Research (Optional but Recommended)

If the feature involves unfamiliar technology, patterns, or integrations, research before designing. Document findings briefly in the design doc or as inline notes. This prevents incorrect assumptions from propagating into tasks.

Follow the **Knowledge Verification Chain** in strict order:

```
Codebase → Project docs → Web search → Flag as uncertain
```

**CRITICAL: NEVER assume or fabricate information.** If you cannot find an answer through the chain, explicitly say "I don't know" or "I couldn't find documentation for this". Inventing an API, a pattern, or a behavior that doesn't exist is far worse than admitting uncertainty. Wrong assumptions propagate through design → tasks → implementation and cause cascading failures.

Good triggers for research: new libraries, unfamiliar APIs, performance-sensitive features, security-sensitive features, patterns you haven't used in this codebase before.

### 2. Define Architecture

Overview of how modules interact. Use mermaid diagrams when helpful.

### 3. Identify Code Reuse

**CRITICAL**: What existing code can we leverage? This saves tokens and reduces errors.

### 4. Define Modules and Interfaces

Each module: Purpose, Location, Public API (functions/classes), Dependencies, What it reuses.

### 5. Define Data Models

If the feature involves data, define models before implementation. Prefer `dataclass`, `TypedDict`, or Pydantic models.

---

## Template

````markdown
# [Feature] Design

**Spec**: [link to spec]
**Status**: Draft | Approved

---

## Architecture Overview

[Brief description of the architecture approach]

```mermaid
graph TD
    A[Caller] --> B[Module A]
    B --> C[Service Layer]
    C --> D[Database / External API]
    B --> E[Module B]
```
````

---

## Code Reuse Analysis

### Existing Modules to Leverage

| Module               | Location                   | How to Use                |
| -------------------- | -------------------------- | ------------------------- |
| [Existing module]    | `src/package/module.py`    | [Import/Extend/Reference] |
| [Existing utility]   | `src/utils/helpers.py`     | [How it helps]            |
| [Existing pattern]   | `src/core/base.py`         | [Apply same pattern]      |

### Integration Points

| System         | Integration Method                      |
| -------------- | --------------------------------------- |
| [Existing API] | [How new feature connects]              |
| [Database]     | [How data connects to existing models]  |

---

## Modules

### [Module Name]

- **Purpose**: [What this module does - one sentence]
- **Location**: `src/package/module.py`
- **Public API**:
  - `def function_name(param: type) -> ReturnType` - [description]
  - `class ClassName` - [description]
- **Dependencies**: [What it needs to function]
- **Reuses**: [Existing code this builds upon]

### [Module Name]

- **Purpose**: [What this module does]
- **Location**: `src/package/module.py`
- **Public API**:
  - `def function_name(param: type) -> ReturnType`
- **Dependencies**: [Dependencies]
- **Reuses**: [Existing code]

---

## Data Models (if applicable)

### [Model Name]

```python
@dataclass
class ModelName:
    id: str
    field1: str
    field2: int
    created_at: datetime
```

**Relationships**: [How this relates to other models]

---

## Error Handling Strategy

| Error Scenario | Exception / Handling   | Caller Impact            |
| -------------- | ---------------------- | ------------------------ |
| [Scenario 1]   | [Raise / catch / log]  | [What caller sees]       |
| [Scenario 2]   | [Raise / catch / log]  | [What caller sees]       |

---

## Tech Decisions (only non-obvious ones)

| Decision          | Choice          | Rationale     |
| ----------------- | --------------- | ------------- |
| [What we decided] | [What we chose] | [Why - brief] |

---

## Tips

- **Load context first** — If context doc exists, decisions there are locked
- **Research when uncertain** — 5 minutes of research prevents hours of rework
- **Reuse is king** — Every module should reference existing patterns
- **Protocols / ABCs first** — Define contracts before implementation
- **Keep it visual** — Diagrams save 1000 words
- **Small modules** — If a module does 3+ things, split it
- **Confirm before Tasks** — User approves design before breaking into tasks
