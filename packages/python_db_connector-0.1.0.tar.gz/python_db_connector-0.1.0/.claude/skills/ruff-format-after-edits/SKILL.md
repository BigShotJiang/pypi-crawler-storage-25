---
name: ruff-format-after-edits
description: Runs Ruff format on modified Python files after code changes. Use after editing any .py files in this project and before finishing the response; prefer formatting only paths that were touched unless many files changed or scope is unclear.
---

# Ruff format after Python edits

After applying changes to Python files, run **Ruff format** on the affected paths **before** you finish the response.

## Environment

Run Ruff **inside `python-db-connector-env`**: activate it first if it is not already active.

## When

- After editing one or more `.py` files
- Before finishing the response

## Commands

Single file:

```bash
ruff format path/to/modified_file.py
```

Multiple files:

```bash
ruff format path/to/file1.py path/to/file2.py
```

Entire project:

```bash
ruff format .
```

**Preference:** Format only the files you modified to keep runs fast. Use `ruff format .` when many files were changed or when you are unsure which paths need formatting.
