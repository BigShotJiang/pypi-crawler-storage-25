---
name: prd
description: "Generate a Product Requirements Document (PRD) based on Spec Driven Development pattern for a new feature. Use when planning a feature, starting a new project, or when asked to create a PRD. Triggers on: create a prd, write prd for, plan this feature, requirements for, spec out."
user-invocable: true
---

# PRD Generator

Create detailed Product Requirements Documents based on Spec Driven Development pattern that are clear, actionable, and ready to be converted to `prd.json` for the Ralph autonomous agent.

**Pipeline:** `/prd` → saves `tasks/prd-[feature-name].md` → `/ralph` converts to `prd.json` → Ralph agent executes stories autonomously.


## The Job

1. Receive a feature description from the user
2. Ask essential clarifying questions (with lettered options)
3. Generate a structured PRD based on answers
4. Save to `tasks/prd-[feature-name].md`

**Important:** Do NOT start implementing. Just create the PRD.


## Step 1: Assess Scope Before Anything Else

Plan with precision. Granular tasks. Clear dependencies. Right tools. Zero ceremony.

```
┌──────────┐   ┌──────────┐   ┌─────────┐
│ SPECIFY  │ → │  DESIGN  │ → │  TASKS  │
└──────────┘   └──────────┘   └─────────┘
   required      optional*      optional*
```



**The complexity determines the depth, not a fixed pipeline.** Assess scope first, then apply only what's needed:

| Scope | What | Specify | Design | Tasks |
|-------|------|---------|--------|-------|
| **Small** | ≤3 files, one sentence | Quick mode — skip pipeline | - | - |
| **Medium** | Clear feature, <10 tasks | Spec (brief) + discuss [gray areas](../references/discuss.md)| Skip — design inline | Full breakdown + dependencies |
| **Large** | Multi-component feature | Full spec + discuss [gray areas](../references/discuss.md)| Architecture + components | Full breakdown + dependencies |
| **Complex** | Ambiguity, new domain | Full spec + discuss [gray areas](../references/discuss.md) | [Research](../references/design.md) + architecture | Breakdown + parallel plan |

**Rules:**
- **Specify and Tasks are always required** — you always need to know WHAT and HOW
- **Design is skipped** when the change is straightforward (no architectural decisions, no new patterns)
- **Tasks is skipped** when there are ≤3 obvious steps (they become implicit)
- **Discuss is triggered within Specify** only when the agent detects ambiguous gray areas that need user input — see [discuss.md](../references/discuss.md)
- **Quick mode** is the express lane — for bug fixes, config changes, and small tweaks

State the detected scope before asking questions: `Scope detected: here are my questions:`

---

## Step 2: PRD Structure

Generate the PRD with these sections:

### 1. Introduction/Overview
Brief description of the feature and the problem it solves.

### 2. Goals
Specific, measurable objectives (bullet list).

### 3. User Stories

Each story needs:
- **Title:** Short descriptive name
- **Description:** "As a [user], I want [feature] so that [benefit]"
- **Acceptance Criteria:** Verifiable checklist of what "done" means

**Format:**
```markdown
### US-001: [Title]
**Description:** As a [user], I want [feature] so that [benefit].

**Acceptance Criteria:**
- [ ] Specific verifiable criterion
- [ ] Another criterion
- [ ] Typecheck passes
- [ ] Tests pass  ← include when story has testable logic
- [ ] Verify in browser using dev-browser skill  ← include for UI stories only
```

#### Ralph Constraints — read carefully before writing stories

Ralph executes each story in a **fresh context window with no memory of previous work**. Stories that are too large cause context overflow and broken code.

**Each story must be completable in one Ralph iteration:**
- Right-sized: add a DB column, add one UI component, update a server action, add a filter
- Too big (split these): "build the dashboard", "add authentication", "refactor the API"
- **Rule of thumb:** If you cannot describe the change in 2–3 sentences, split it.

**Stories must be ordered by dependency — Ralph runs them in priority order:**
1. Schema/database changes (migrations first)
2. Server actions / backend logic
3. UI components that use the backend
4. Dashboard/summary views that aggregate data

Never have a story depend on a later-numbered story.

**Acceptance criteria must be verifiable, not vague:**
- Good: `"Add status column to tasks table with default 'pending'"`
- Bad: `"Works correctly"`, `"Good UX"`, `"Handles edge cases"`

**Mandatory criteria on every story:**
- `"Typecheck passes"` — always, on every story, as the last criterion
- `"Tests pass"` — on stories with testable logic
- `"Verify in browser using dev-browser skill"` — on every story that changes UI

### 4. Functional Requirements
Numbered list of specific functionalities:
- "FR-1: The system must allow users to..."
- "FR-2: When a user clicks X, the system must..."

Be explicit and unambiguous.

### 5. Non-Goals (Out of Scope)
What this feature will NOT include. Critical for managing scope.

### 6. Design Considerations (Optional)
- UI/UX requirements
- Link to mockups if available
- Relevant existing components to reuse

### 7. Technical Considerations (Optional)
- Known constraints or dependencies
- Integration points with existing systems
- Performance requirements

### 8. Success Metrics
How will success be measured?

### 9. Open Questions
Remaining questions or areas needing clarification.

---

## Writing for Junior Developers

The PRD reader may be a junior developer or AI agent. Therefore:

- Be explicit and unambiguous
- Avoid jargon or explain it
- Provide enough detail to understand purpose and core logic
- Number requirements for easy reference
- Use concrete examples where helpful

---

## Output

- **Format:** Markdown (`.md`)
- **Location:** `tasks/`
- **Filename:** `prd-[feature-name].md` (kebab-case)

---

## Example PRD

```markdown
# PRD: Task Priority System

**Branch:** feature/task-priority

## Introduction

Add priority levels to tasks so users can focus on what matters most. Tasks can be marked as high, medium, or low priority, with visual indicators and filtering.

## Goals

- Allow assigning priority (high/medium/low) to any task
- Provide clear visual differentiation between priority levels
- Enable filtering by priority
- Default new tasks to medium priority

## User Stories

### US-001: Add priority field to database
**Description:** As a developer, I need to store task priority so it persists across sessions.

**Acceptance Criteria:**
- [ ] Add priority column to tasks table: 'high' | 'medium' | 'low' (default 'medium')
- [ ] Generate and run migration successfully
- [ ] Typecheck passes

### US-002: Display priority indicator on task cards
**Description:** As a user, I want to see task priority at a glance so I know what needs attention first.

**Acceptance Criteria:**
- [ ] Each task card shows colored priority badge (red=high, yellow=medium, gray=low)
- [ ] Priority visible without hovering or clicking
- [ ] Typecheck passes
- [ ] Verify in browser using dev-browser skill

### US-003: Add priority selector to task edit
**Description:** As a user, I want to change a task's priority when editing it.

**Acceptance Criteria:**
- [ ] Priority dropdown in task edit modal
- [ ] Shows current priority as selected
- [ ] Saves immediately on selection change
- [ ] Typecheck passes
- [ ] Verify in browser using dev-browser skill

### US-004: Filter tasks by priority
**Description:** As a user, I want to filter the task list to see only high-priority items when I'm focused.

**Acceptance Criteria:**
- [ ] Filter dropdown with options: All | High | Medium | Low
- [ ] Filter persists in URL params
- [ ] Empty state message when no tasks match filter
- [ ] Typecheck passes
- [ ] Verify in browser using dev-browser skill

## Functional Requirements

- FR-1: Add `priority` field to tasks table ('high' | 'medium' | 'low', default 'medium')
- FR-2: Display colored priority badge on each task card
- FR-3: Include priority selector in task edit modal
- FR-4: Add priority filter dropdown to task list header

## Non-Goals

- No priority-based notifications or reminders
- No automatic priority assignment based on due date
- No priority inheritance for subtasks

## Technical Considerations

- Reuse existing badge component with color variants
- Filter state managed via URL search params
- Priority stored in database, not computed

## Success Metrics

- Users can change priority in under 2 clicks
- High-priority tasks immediately visible at top of lists

## Open Questions

- Should priority affect task ordering within a column?
```

---

## Checklist

Before saving the PRD:

- [ ] Header includes `**Branch:** feature/[feature-name]`
- [ ] Asked clarifying questions with lettered options (see discuss.md)
- [ ] Incorporated user's answers
- [ ] Stories are ordered by dependency (schema → backend → UI)
- [ ] Each story is completable in 2–3 sentences (one Ralph iteration)
- [ ] Every story has `"Typecheck passes"` as final criterion
- [ ] UI stories have `"Verify in browser using dev-browser skill"`
- [ ] Acceptance criteria are verifiable (not vague)
- [ ] Functional requirements are numbered and unambiguous
- [ ] Non-goals section defines clear boundaries
- [ ] Saved to `tasks/prd-[feature-name].md`
- [ ] Told the user to run `/ralph` next
