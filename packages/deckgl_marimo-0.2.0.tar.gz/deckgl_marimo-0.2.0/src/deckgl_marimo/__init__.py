"""deckgl-marimo: deck.gl visualization library for marimo notebooks.

Provides deck.gl layers on MapLibre GL basemaps as interactive
anywidget-based widgets with full marimo reactivity support.
"""

from deckgl_marimo._basemaps import Basemaps
from deckgl_marimo._map import Map
from deckgl_marimo._view_state import ViewState

# Core layers (fully tested)
from deckgl_marimo.layers._core import (
    ArcLayer,
    ColumnLayer,
    GeoJsonLayer,
    IconLayer,
    PathLayer,
    PolygonLayer,
    ScatterplotLayer,
    TextLayer,
)

# Aggregation layers (fully tested)
from deckgl_marimo.layers._aggregation import (
    HeatmapLayer,
    HexagonLayer,
)

# Backward compatibility
from deckgl_marimo.widget import DeckGLHexagonWidget

__all__ = [
    # Widget
    "Map",
    "ViewState",
    "Basemaps",
    # Core layers
    "ArcLayer",
    "ColumnLayer",
    "GeoJsonLayer",
    "IconLayer",
    "PathLayer",
    "PolygonLayer",
    "ScatterplotLayer",
    "TextLayer",
    # Aggregation layers
    "HeatmapLayer",
    "HexagonLayer",
    # Backward compat
    "DeckGLHexagonWidget",
]
