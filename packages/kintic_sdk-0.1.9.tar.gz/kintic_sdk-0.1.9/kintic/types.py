"""
Typed shapes for the Kintic ingest API (align with backend /api/ingest JSON).
"""

from __future__ import annotations

from typing import Any, Dict, List, TypedDict


class IngestCorrelationIds(TypedDict, total=False):
    traceId: str
    spanId: str
    parentSpanId: str
    requestId: str
    datadogTraceId: str
    datadogSpanId: str


class IngestDeployment(TypedDict, total=False):
    service: str
    repository: str
    commit: str
    version: str
    environment: str


class IngestCodeLocation(TypedDict, total=False):
    file: str
    symbol: str
    line: int


class ContextSnapshot(TypedDict, total=False):
    """`contextSnapshot` in JSON (camelCase keys). `args` / `kwargs` are always set by the SDK."""

    args: List[Any]
    kwargs: Any
    beliefState: Dict[str, Any]
    policyVersion: str
    availableInformation: Any
    confidence: float
    correlationIds: IngestCorrelationIds
    deployment: IngestDeployment
    codeLocation: IngestCodeLocation
    promptContext: str
    langchainContext: Dict[str, Any]
    autogenContext: Dict[str, Any]
    crewaiContext: Dict[str, Any]
    llamaIndexContext: Dict[str, Any]
    adkContext: Dict[str, Any]
    llmCalls: List[Dict[str, Any]]
    callStack: List[str]
    failed: bool
    exceptionType: str
    traceback: str


# Delegation links are JSON objects: { "from", "to", "authorization", "timestamp" }.
DelegationChain = List[Dict[str, Any]]


class DecisionPayload(TypedDict, total=False):
    """POST /api/ingest body."""

    eventId: str
    agentName: str
    action: str
    contextSnapshot: Dict[str, Any]
    delegationChain: List[Dict[str, Any]]
    outcome: str
    latency: float
    costImpact: float
    timestamp: str
