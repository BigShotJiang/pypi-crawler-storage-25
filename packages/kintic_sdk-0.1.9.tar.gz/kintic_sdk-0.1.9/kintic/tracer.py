from __future__ import annotations

import functools
import inspect
import json
import os
import queue
import threading
import time
import traceback
import uuid
import atexit
from datetime import datetime, timezone
from typing import (
    Any,
    Callable,
    Dict,
    Optional,
    TypeVar,
    Union,
    cast,
)

import requests

from kintic.context_hints import (
    dd_trace_env_correlation_ids,
    env_deployment_meta,
    otel_span_correlation_ids,
    request_id_from_env,
)
from kintic.sanitize import sanitize_context_snapshot as _sanitize_snap
from kintic.types import ContextSnapshot, DecisionPayload, DelegationChain


def _env_flag(name: str, default_true: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default_true
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _shallow_merge(*dicts: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for part in dicts:
        if not part or not isinstance(part, dict):
            continue
        for k, v in part.items():
            if v is None:
                continue
            out[str(k)] = v
    return out

F = TypeVar("F", bound=Callable[..., Any])


_PATCH_LOCK = threading.Lock()
_PATCH_REFCOUNT = 0
_PATCHED_FUNCS: list[tuple[Any, str, Any]] = []
_ACTIVE_CAPTURE = threading.local()


def _jsonify(obj: Any) -> Any:
    """Best-effort JSON-serializable value for context."""
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {str(k): _jsonify(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonify(x) for x in obj]
    if isinstance(obj, (set, frozenset)):
        return [_jsonify(x) for x in obj]
    return str(obj)


def _now_iso_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_getattr(obj: Any, name: str, default: Any = None) -> Any:
    try:
        return getattr(obj, name, default)
    except Exception:
        return default


def _looks_like_prompt_key(key: str) -> bool:
    k = key.lower()
    return any(
        token in k
        for token in (
            "prompt",
            "message",
            "query",
            "instruction",
            "input",
            "question",
            "content",
        )
    )


def _to_prompt_text(value: Any) -> Optional[str]:
    if isinstance(value, str):
        s = value.strip()
        return s if s else None
    if isinstance(value, dict):
        for k in ("prompt", "message", "messages", "input", "content", "query", "question"):
            if k in value:
                v = value[k]
                if isinstance(v, str) and v.strip():
                    return v.strip()
                if isinstance(v, list):
                    parts = [str(x) for x in v if isinstance(x, (str, dict))]
                    if parts:
                        return "\n".join(parts)[:8_000]
        try:
            return json.dumps(_jsonify(value), default=str)[:8_000]
        except Exception:
            return str(value)[:8_000]
    return None


def _extract_prompt_context(args: Any, kwargs: Any) -> Optional[str]:
    for arg in list(args or ()):
        text = _to_prompt_text(arg)
        if text:
            return text
    for k, v in dict(kwargs or {}).items():
        if _looks_like_prompt_key(str(k)):
            text = _to_prompt_text(v)
            if text:
                return text
    return None


def _extract_langchain_context(args: Any, kwargs: Any) -> Optional[Dict[str, Any]]:
    objects = list(args or ()) + list(dict(kwargs or {}).values())
    for obj in objects:
        module_name = str(_safe_getattr(obj.__class__, "__module__", ""))
        if "langchain" not in module_name.lower():
            continue

        chain_name = _safe_getattr(obj.__class__, "__name__", "LangChainObject")
        model_name = (
            _safe_getattr(obj, "model_name")
            or _safe_getattr(obj, "model")
            or _safe_getattr(_safe_getattr(obj, "llm"), "model_name")
            or _safe_getattr(_safe_getattr(obj, "llm"), "model")
        )
        prompt_template = None
        prompt_obj = _safe_getattr(obj, "prompt") or _safe_getattr(_safe_getattr(obj, "llm_chain"), "prompt")
        if prompt_obj is not None:
            prompt_template = _safe_getattr(prompt_obj, "template")
            if prompt_template is None:
                prompt_template = str(prompt_obj)

        memory_obj = _safe_getattr(obj, "memory") or _safe_getattr(_safe_getattr(obj, "llm_chain"), "memory")
        memory_dump: Any = None
        last_messages: list[Any] = []
        if memory_obj is not None:
            memory_dump = _jsonify(
                {
                    "memory_key": _safe_getattr(memory_obj, "memory_key"),
                    "input_key": _safe_getattr(memory_obj, "input_key"),
                    "output_key": _safe_getattr(memory_obj, "output_key"),
                    "type": memory_obj.__class__.__name__,
                }
            )
            chat_memory = _safe_getattr(memory_obj, "chat_memory")
            messages = _safe_getattr(chat_memory, "messages") or _safe_getattr(memory_obj, "messages")
            if isinstance(messages, list):
                for m in messages[-8:]:
                    role = (
                        str(_safe_getattr(m, "type", ""))
                        or str(_safe_getattr(m, "role", ""))
                        or m.__class__.__name__
                    )
                    content = _safe_getattr(m, "content", str(m))
                    last_messages.append({"role": role, "content": _jsonify(content)})

        return cast(
            Dict[str, Any],
            _jsonify(
                {
                    "chain_name": chain_name,
                    "model_name": model_name,
                    "prompt_template": prompt_template,
                    "memory": memory_dump,
                    "memory_last_messages": last_messages,
                }
            ),
        )
    return None


def _extract_text_response(result: Any) -> str:
    if isinstance(result, str):
        return result[:20_000]
    if isinstance(result, dict):
        if "content" in result and isinstance(result.get("content"), str):
            return cast(str, result["content"])[:20_000]
        if "output_text" in result and isinstance(result.get("output_text"), str):
            return cast(str, result["output_text"])[:20_000]
        return json.dumps(_jsonify(result), default=str)[:20_000]
    if hasattr(result, "choices"):
        choices = _safe_getattr(result, "choices", [])
        if isinstance(choices, list) and choices:
            first = choices[0]
            msg = _safe_getattr(first, "message")
            content = _safe_getattr(msg, "content")
            if isinstance(content, str):
                return content[:20_000]
    return str(result)[:20_000]


def _extract_openai_prompt(kwargs: Dict[str, Any]) -> Optional[str]:
    msgs = kwargs.get("messages")
    if isinstance(msgs, list):
        user_parts: list[str] = []
        system_parts: list[str] = []
        for m in msgs:
            if not isinstance(m, dict):
                continue
            role = str(m.get("role", ""))
            content = m.get("content")
            text = content if isinstance(content, str) else json.dumps(_jsonify(content), default=str)
            if role == "system":
                system_parts.append(text)
            elif role == "user":
                user_parts.append(text)
        merged = "\n".join((["[system]\n" + "\n".join(system_parts)] if system_parts else []) + user_parts)
        return merged[:20_000] if merged else None
    prompt = kwargs.get("prompt")
    if isinstance(prompt, str):
        return prompt[:20_000]
    return None


def _record_llm_event(provider: str, model: Optional[str], prompt: Optional[str], response: Optional[str], started_at: float) -> None:
    capture = getattr(_ACTIVE_CAPTURE, "value", None)
    if capture is None:
        return
    latency_ms = (time.perf_counter() - started_at) * 1000.0
    capture.append(
        _jsonify(
            {
                "provider": provider,
                "model": model,
                "prompt": prompt,
                "response": response,
                "latency_ms": latency_ms,
                "timestamp": _now_iso_utc(),
            }
        )
    )


def _patch_once(module: Any, attr_path: str, wrapped_factory: Callable[[Callable[..., Any]], Callable[..., Any]]) -> None:
    parts = attr_path.split(".")
    parent = module
    for part in parts[:-1]:
        parent = getattr(parent, part)
    leaf = parts[-1]
    original = getattr(parent, leaf)
    patched = wrapped_factory(original)
    setattr(parent, leaf, patched)
    _PATCHED_FUNCS.append((parent, leaf, original))


def _install_global_patches() -> None:
    global _PATCH_REFCOUNT
    with _PATCH_LOCK:
        _PATCH_REFCOUNT += 1
        if _PATCH_REFCOUNT > 1:
            return
        try:
            import openai  # type: ignore

            def wrap_openai_chat(original: Callable[..., Any]) -> Callable[..., Any]:
                @functools.wraps(original)
                def inner(*args: Any, **kwargs: Any) -> Any:
                    t0 = time.perf_counter()
                    out = original(*args, **kwargs)
                    _record_llm_event(
                        "openai",
                        cast(Optional[str], kwargs.get("model")),
                        _extract_openai_prompt(kwargs),
                        _extract_text_response(out),
                        t0,
                    )
                    return out

                return inner

            _patch_once(openai, "resources.chat.completions.Completions.create", wrap_openai_chat)
        except Exception:
            pass

        try:
            import anthropic  # type: ignore

            def wrap_anthropic_messages(original: Callable[..., Any]) -> Callable[..., Any]:
                @functools.wraps(original)
                def inner(*args: Any, **kwargs: Any) -> Any:
                    t0 = time.perf_counter()
                    out = original(*args, **kwargs)
                    messages = kwargs.get("messages")
                    prompt = None
                    if isinstance(messages, list):
                        prompt = json.dumps(_jsonify(messages), default=str)[:20_000]
                    _record_llm_event(
                        "anthropic",
                        cast(Optional[str], kwargs.get("model")),
                        prompt,
                        _extract_text_response(out),
                        t0,
                    )
                    return out

                return inner

            _patch_once(anthropic, "resources.messages.Messages.create", wrap_anthropic_messages)
        except Exception:
            pass

        try:
            import langchain_core  # type: ignore

            def wrap_langchain_invoke(original: Callable[..., Any]) -> Callable[..., Any]:
                @functools.wraps(original)
                def inner(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
                    t0 = time.perf_counter()
                    out = original(self_obj, *args, **kwargs)
                    model = _safe_getattr(self_obj, "model_name") or _safe_getattr(self_obj, "model")
                    prompt = None
                    if args:
                        prompt = _to_prompt_text(args[0])
                    _record_llm_event(
                        "langchain",
                        cast(Optional[str], model),
                        prompt,
                        _extract_text_response(out),
                        t0,
                    )
                    return out

                return inner

            _patch_once(langchain_core, "language_models.chat_models.BaseChatModel.invoke", wrap_langchain_invoke)
            _patch_once(langchain_core, "language_models.llms.BaseLLM.invoke", wrap_langchain_invoke)
        except Exception:
            pass


def _uninstall_global_patches() -> None:
    global _PATCH_REFCOUNT
    with _PATCH_LOCK:
        _PATCH_REFCOUNT = max(0, _PATCH_REFCOUNT - 1)
        if _PATCH_REFCOUNT != 0:
            return
        while _PATCHED_FUNCS:
            parent, leaf, original = _PATCHED_FUNCS.pop()
            try:
                setattr(parent, leaf, original)
            except Exception:
                pass


class _LLMCallCapture:
    def __enter__(self) -> list[Dict[str, Any]]:
        self.events: list[Dict[str, Any]] = []
        _ACTIVE_CAPTURE.value = self.events
        _install_global_patches()
        return self.events

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        _ACTIVE_CAPTURE.value = None
        _uninstall_global_patches()


class KinticTracer:
    """
    Instruments agent functions: records context, outcome, and ships to Kintic
    in a background daemon thread (never blocks, never fails the app).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://origin.api.kintic.dev",
        debug: bool = False,
        queue_max_size: int = 1024,
        request_timeout_sec: float = 5.0,
        max_retries: int = 1,
        retry_backoff_sec: float = 0.15,
        default_deployment: Optional[Dict[str, Any]] = None,
        sanitize_context: Optional[bool] = None,
        auto_collect_trace_meta: bool = True,
        **_extra: Any,
    ) -> None:
        if not api_key or not str(api_key).startswith("kintic_live_"):
            raise ValueError(
                "Invalid Kintic API key: must start with 'kintic_live_'. "
                "Create a key in the Kintic dashboard (Settings → API Keys)."
            )
        self.api_key = str(api_key)
        self.base_url = str(base_url).rstrip("/")
        self.debug = bool(debug)
        self.request_timeout_sec = float(request_timeout_sec)
        self.max_retries = max(0, int(max_retries))
        self.retry_backoff_sec = max(0.0, float(retry_backoff_sec))
        self.default_deployment = dict(default_deployment) if default_deployment else {}
        self.auto_collect_trace_meta = bool(auto_collect_trace_meta)
        self.sanitize_context = (
            bool(sanitize_context)
            if sanitize_context is not None
            else _env_flag("KINTIC_SANITIZE_CONTEXT", True)
        )
        self._session = requests.Session()
        self._session.headers.update(
            {
                "x-api-key": self.api_key,
                "Content-Type": "application/json",
            }
        )
        self._queue: queue.Queue[DecisionPayload] = queue.Queue(maxsize=max(16, int(queue_max_size)))
        self._stop_event = threading.Event()
        self._metrics_lock = threading.Lock()
        self._metrics: Dict[str, int] = {
            "enqueued": 0,
            "sent_ok": 0,
            "send_failed": 0,
            "dropped_queue_full": 0,
            "retries_total": 0,
        }
        self._worker = threading.Thread(target=self._ship_worker_loop, daemon=True)
        self._worker.start()
        atexit.register(self.flush, 2.0)

    def decision(
        self,
        agent: str,
        policy: Optional[Union[str, Dict[str, Any]]] = None,
        delegation_chain: Optional[DelegationChain] = None,
    ) -> Callable[[F], F]:
        """
        Decorator. ``agent`` is required; ``policy`` and ``delegation_chain`` are optional
        and attached to each ingested event.
        """

        if not agent or not str(agent).strip():
            raise ValueError("Kintic: 'agent' must be a non-empty string.")

        def decorator(fn: F) -> F:
            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                start = time.perf_counter()
                with _LLMCallCapture() as llm_calls:
                    try:
                        result = fn(*args, **kwargs)
                    except Exception as e:
                        latency_ms = (time.perf_counter() - start) * 1000.0
                        ctx = self._build_context_snapshot(
                            args,
                            kwargs,
                            policy,
                            llm_calls=llm_calls,
                            call_stack=traceback.format_stack(limit=30),
                            decoratee_fn=fn,
                        )
                        ctx["failed"] = True
                        ctx["exceptionType"] = e.__class__.__name__
                        ctx["traceback"] = traceback.format_exc()
                        self.record_decision(
                            agent=str(agent).strip(),
                            action=getattr(fn, "__name__", "wrapped"),
                            context_snapshot=ctx,
                            outcome=f"FAILED: {e}",
                            latency_ms=latency_ms,
                            delegation_chain=delegation_chain,
                        )
                        raise

                latency_ms = (time.perf_counter() - start) * 1000.0
                try:
                    ctx = self._build_context_snapshot(
                        args,
                        kwargs,
                        policy,
                        llm_calls=llm_calls,
                        call_stack=traceback.format_stack(limit=30),
                        decoratee_fn=fn,
                    )
                    outcome, cost_impact = self._outcome_and_cost(result)
                    self.record_decision(
                        agent=str(agent).strip(),
                        action=getattr(fn, "__name__", "wrapped"),
                        context_snapshot=ctx,
                        outcome=outcome,
                        latency_ms=latency_ms,
                        delegation_chain=delegation_chain,
                        cost_impact=cost_impact,
                    )
                except Exception:
                    if self.debug:
                        print("[kintic] build/ship prep failed (suppressed)")

                return result

            return wrapper  # type: ignore[return-value]

        return decorator

    def _outcome_and_cost(
        self, result: Any
    ) -> tuple[str, Optional[float]]:
        cost: Optional[float] = None
        if isinstance(result, dict):
            raw = result.get("cost_impact", result.get("costImpact"))
            if raw is not None and isinstance(raw, (int, float)):
                cost = float(raw)
        if isinstance(result, (dict, list)):
            try:
                return json.dumps(_jsonify(result), default=str)[:200_000], cost
            except Exception:
                return str(result)[:200_000], cost
        if isinstance(result, str):
            return result, cost
        return str(result), cost

    def _build_context_snapshot(
        self,
        args: Any,
        kwargs: Any,
        policy: Optional[Union[str, Dict[str, Any]]],
        llm_calls: Optional[list[Dict[str, Any]]] = None,
        call_stack: Optional[list[str]] = None,
        decoratee_fn: Optional[Callable[..., Any]] = None,
    ) -> ContextSnapshot:
        raw_kwd = dict(kwargs) if kwargs else {}
        deployment_user = raw_kwd.pop("deployment", None) or raw_kwd.pop("kinticDeployment", None)
        corr_user = raw_kwd.pop("correlationIds", None) or raw_kwd.pop("correlation_ids", None)
        code_user = raw_kwd.pop("codeLocation", None) or raw_kwd.pop("code_location", None)

        kwd = raw_kwd
        be = kwd.get("belief_state", kwd.get("beliefState"))
        av = kwd.get("available_information", kwd.get("availableInformation"))
        conf = kwd.get("confidence")

        snap: Dict[str, Any] = {
            "args": _jsonify(args if args is not None else ()),
            "kwargs": _jsonify(kwd),
        }
        prompt_context = _extract_prompt_context(args, kwd)
        if prompt_context:
            snap["promptContext"] = prompt_context
        lc_ctx = _extract_langchain_context(args, kwd)
        if lc_ctx:
            snap["langchainContext"] = lc_ctx
        if llm_calls:
            snap["llmCalls"] = _jsonify(llm_calls)
        if call_stack:
            snap["callStack"] = _jsonify(call_stack[-25:])
        if be is not None:
            snap["beliefState"] = _jsonify(be)
        if av is not None:
            snap["availableInformation"] = _jsonify(av)
        if conf is not None:
            try:
                snap["confidence"] = float(conf)
            except (TypeError, ValueError):
                snap["confidence"] = conf

        if policy is not None:
            if isinstance(policy, str):
                snap["policyVersion"] = policy
            elif isinstance(policy, dict) and "version" in policy:
                snap["policyVersion"] = str(policy["version"])

        corr: Dict[str, Any] = {}
        if self.auto_collect_trace_meta:
            corr = _shallow_merge(
                corr,
                otel_span_correlation_ids(),
                dd_trace_env_correlation_ids(),
                request_id_from_env(),
            )
        if isinstance(corr_user, dict):
            corr = _shallow_merge(corr, corr_user)
        if corr:
            snap["correlationIds"] = corr

        deploy_parts = [env_deployment_meta()]
        if self.default_deployment:
            deploy_parts.append(self.default_deployment)
        if isinstance(deployment_user, dict):
            deploy_parts.append(deployment_user)
        deployment = _shallow_merge(*deploy_parts)
        if deployment:
            snap["deployment"] = deployment

        code_loc_auto: Dict[str, Any] = {}
        try:
            if decoratee_fn is not None:
                mod = inspect.getmodule(decoratee_fn)
                fname = getattr(mod, "__file__", None) if mod else None
                qual = getattr(decoratee_fn, "__qualname__", None)
                co = getattr(decoratee_fn, "__code__", None)
                line = getattr(co, "co_firstlineno", None) if co else None
                if fname:
                    code_loc_auto["file"] = str(fname)[:2048]
                if qual:
                    code_loc_auto["symbol"] = str(qual)[:512]
                if isinstance(line, int):
                    code_loc_auto["line"] = line
        except Exception:
            pass

        if isinstance(code_user, dict):
            code_loc_auto = _shallow_merge(code_loc_auto, code_user)
        if code_loc_auto:
            snap["codeLocation"] = code_loc_auto

        return cast(ContextSnapshot, snap)

    def record_decision(
        self,
        *,
        agent: str,
        action: str,
        context_snapshot: Dict[str, Any],
        outcome: str,
        latency_ms: float,
        delegation_chain: Optional[DelegationChain] = None,
        cost_impact: Optional[float] = None,
    ) -> None:
        ctx_in = dict(context_snapshot)
        if self.sanitize_context:
            ctx_in = _sanitize_snap(ctx_in)
        payload: DecisionPayload = {
            "eventId": f"evt_{uuid.uuid4().hex}",
            "agentName": agent,
            "action": action,
            "contextSnapshot": cast(Dict[str, Any], _jsonify(ctx_in)),
            "outcome": outcome,
            "latency": float(latency_ms),
            "timestamp": _now_iso_utc(),
        }
        if cost_impact is not None and isinstance(cost_impact, (int, float)):
            payload["costImpact"] = float(cost_impact)
        if delegation_chain is not None and len(delegation_chain) > 0:
            payload["delegationChain"] = list(dict(d) for d in delegation_chain)

        self._enqueue(payload)

    def _ship(self, payload: Dict[str, Any]) -> None:
        """Compatibility helper used by integrations. Non-blocking fire-and-forget."""
        self._enqueue(cast(DecisionPayload, payload))

    def _incr_metric(self, name: str) -> None:
        with self._metrics_lock:
            self._metrics[name] = int(self._metrics.get(name, 0)) + 1

    def _enqueue(self, payload: DecisionPayload) -> None:
        try:
            self._queue.put_nowait(payload)
            self._incr_metric("enqueued")
        except queue.Full:
            self._incr_metric("dropped_queue_full")
            if self.debug:
                print("[kintic] drop: ship queue full")

    def _ship_worker_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                payload = self._queue.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                ok = self._ship_with_retries(payload)
                self._incr_metric("sent_ok" if ok else "send_failed")
            finally:
                self._queue.task_done()

    def _ship_with_retries(self, payload: DecisionPayload) -> bool:
        for attempt in range(self.max_retries + 1):
            if self._ship_once(payload):
                return True
            if attempt < self.max_retries:
                self._incr_metric("retries_total")
                time.sleep(self.retry_backoff_sec)
        return False

    def _ship_once(self, payload: DecisionPayload) -> bool:
        url = f"{self.base_url}/api/ingest"
        try:
            r = self._session.post(
                url,
                json=cast(Any, payload),
                timeout=self.request_timeout_sec,
            )
            if self.debug:
                if r.status_code < 300:
                    print(f"[kintic] ingest ok: {r.status_code}")
                else:
                    print(f"[kintic] ingest error: {r.status_code} {r.text[:500]}")
            return r.status_code < 300
        except requests.exceptions.RequestException as e:
            if self.debug:
                print(f"[kintic] request error: {e}")
            return False

    def flush(self, timeout_sec: float = 2.0) -> bool:
        deadline = time.time() + max(0.1, float(timeout_sec))
        while self._queue.unfinished_tasks > 0 and time.time() < deadline:
            time.sleep(0.02)
        return self._queue.unfinished_tasks == 0

    def close(self, timeout_sec: float = 2.0) -> bool:
        flushed = self.flush(timeout_sec=timeout_sec)
        self._stop_event.set()
        try:
            self._worker.join(timeout=max(0.1, float(timeout_sec)))
        except Exception:
            pass
        return flushed

    def get_delivery_stats(self) -> Dict[str, int]:
        with self._metrics_lock:
            out = dict(self._metrics)
        out["queue_size"] = self._queue.qsize()
        out["queue_unfinished"] = int(self._queue.unfinished_tasks)
        return out

    def health_snapshot(self) -> Dict[str, Any]:
        """
        Runtime diagnostics snapshot for SDK delivery health.

        This is intentionally lightweight and safe to call from health endpoints
        in host applications.
        """
        stats = self.get_delivery_stats()
        return {
            "timestamp": _now_iso_utc(),
            "base_url": self.base_url,
            "request_timeout_sec": self.request_timeout_sec,
            "max_retries": self.max_retries,
            "retry_backoff_sec": self.retry_backoff_sec,
            "worker_alive": self._worker.is_alive(),
            "queue_max_size": int(self._queue.maxsize),
            "sanitize_context": self.sanitize_context,
            "auto_collect_trace_meta": self.auto_collect_trace_meta,
            "stats": stats,
        }
