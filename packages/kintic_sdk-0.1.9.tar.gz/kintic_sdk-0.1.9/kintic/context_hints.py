"""
Optional deployment / trace correlation hints merged into ContextSnapshot.

Does not fail if OTEL deps are absent; reads standard env hints when present.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

try:
    from opentelemetry import trace as otel_trace
except Exception:  # pragma: no cover - optional dependency
    otel_trace = None  # type: ignore[assignment]


def _env(key: str) -> Optional[str]:
    v = os.environ.get(key)
    return v.strip() if v else None


def otel_span_correlation_ids() -> Dict[str, str]:
    out: Dict[str, str] = {}
    if otel_trace is None:
        return out
    try:
        span = otel_trace.get_current_span()
        ctx = span.get_span_context()
        if ctx is not None and ctx.is_valid:
            tid = format(ctx.trace_id, "032x")
            sid = format(ctx.span_id, "016x")
            out["traceId"] = tid
            out["spanId"] = sid
    except Exception:
        pass
    return out


def env_deployment_meta() -> Dict[str, Any]:
    """Reads common CI / runtime env conventions (camelCase JSON keys match backend types)."""

    svc = (
        _env("KINTIC_DEPLOY_SERVICE")
        or _env("DD_SERVICE")
        or _env("OTEL_SERVICE_NAME")
        or _env("ECS_SERVICE_NAME")
        or _env("K_SERVICE")  # k8s
    )
    ver = (
        _env("KINTIC_DEPLOY_VERSION")
        or _env("DD_VERSION")
        or _env("OTEL_SERVICE_VERSION")
        or _env("ECS_TASK_DEFINITION")
    )
    commit = (
        _env("KINTIC_GIT_COMMIT")
        or _env("GIT_COMMIT")
        or _env("GIT_SHA")
        or _env("CODEBUILD_RESOLVED_SOURCE_VERSION")
        or _env("GITHUB_SHA")
        or _env("CIRCLE_SHA1")
    )
    repo = (
        _env("KINTIC_GIT_REPOSITORY")
        or _env("GITHUB_REPOSITORY")
        or _env("CI_REPOSITORY_URL")
    )
    environment = (
        _env("KINTIC_DEPLOY_ENV")
        or _env("ENVIRONMENT")
        or _env("DD_ENV")
        or _env("NODE_ENV")
    )

    deployment: Dict[str, Any] = {}
    if svc:
        deployment["service"] = svc[:256]
    if repo:
        deployment["repository"] = repo[:512]
    if commit:
        deployment["commit"] = commit[:64]
    if ver:
        deployment["version"] = ver[:128]
    if environment:
        deployment["environment"] = environment[:128]
    return deployment


def dd_trace_env_correlation_ids() -> Dict[str, str]:
    out: Dict[str, str] = {}
    dd_trace = _env("DD_TRACE_ID") or _env("_dd.trace_id")
    dd_span = _env("DD_SPAN_ID") or _env("_dd.span_id")
    if dd_trace:
        out["datadogTraceId"] = dd_trace[:64]
    if dd_span:
        out["datadogSpanId"] = dd_span[:32]
    return out


def request_id_from_env() -> Dict[str, str]:
    out: Dict[str, str] = {}
    rid = (
        _env("KINTIC_REQUEST_ID")
        or _env("REQUEST_ID")
        or _env("X_REQUEST_ID")
        or _env("CORRELATION_ID")
    )
    if rid:
        out["requestId"] = rid[:128]
    return out