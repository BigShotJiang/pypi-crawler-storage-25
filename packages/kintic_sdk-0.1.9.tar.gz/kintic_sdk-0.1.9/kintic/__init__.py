"""
Kintic — context logging for AI agents.

    import kintic

    tracer = kintic.init(
        api_key=os.environ["KINTIC_API_KEY"],
        base_url="http://localhost:4000",
        debug=True,
    )

    @tracer.decision(agent="my-agent", policy="v1")
    def my_agent(*, goal: str) -> str: ...
"""

from typing import List, Optional

__version__ = "0.1.9"

from kintic.integrations import (
    KinticAdkCallbacks,
    KinticAdkRunCollector,
    KinticAutoGenObserver,
    KinticCallbackHandler,
    KinticLangGraphHandler,
    KinticLangGraphStreamCollector,
    KinticCrewAIListener,
    KinticCrewAIRunCollector,
    LegacyAutoGenCollector,
    ObservedAutoGenStream,
    attach_legacy_observers,
    attach_llamaindex_settings,
    create_langgraph_handler,
    create_llamaindex_callback_manager,
    merge_langgraph_config,
    install_adk_callbacks,
    install_crewai_listener,
    observe_team_stream,
    patch_anthropic,
    patch_cohere,
    patch_gemini,
    patch_groq,
    patch_mistral,
    patch_openai,
    run_observed_crew,
    run_observed_crew_async,
    run_observed_query,
    run_observed_team,
    ship_adk_turn,
    ship_legacy_chat_history,
)
from kintic.tracer import KinticTracer

__all__ = [
    "__version__",
    "KinticTracer",
    "KinticCallbackHandler",
    "KinticLangGraphHandler",
    "KinticLangGraphStreamCollector",
    "KinticAdkCallbacks",
    "KinticAdkRunCollector",
    "KinticCrewAIListener",
    "KinticCrewAIRunCollector",
    "KinticAutoGenObserver",
    "LegacyAutoGenCollector",
    "ObservedAutoGenStream",
    "attach_legacy_observers",
    "attach_llamaindex_settings",
    "create_langgraph_handler",
    "create_llamaindex_callback_manager",
    "merge_langgraph_config",
    "install_adk_callbacks",
    "install_crewai_listener",
    "init",
    "observe_team_stream",
    "patch",
    "patch_anthropic",
    "patch_cohere",
    "patch_gemini",
    "patch_groq",
    "patch_mistral",
    "patch_openai",
    "run_observed_crew",
    "run_observed_crew_async",
    "run_observed_ainvoke",
    "run_observed_astream",
    "run_observed_invoke",
    "run_observed_query",
    "run_observed_stream",
    "run_observed_team",
    "ship_adk_turn",
    "ship_legacy_chat_history",
]

_global_tracer: Optional[KinticTracer] = None


def init(api_key: str, **kwargs: object) -> KinticTracer:
    global _global_tracer
    _global_tracer = KinticTracer(api_key=api_key, **kwargs)
    return _global_tracer


def patch(
    agent: str,
    policy: Optional[str] = None,
    providers: Optional[List[str]] = None,
) -> KinticTracer:
    if _global_tracer is None:
        raise RuntimeError("Call kintic.init() before kintic.patch()")
    providers = providers or ["openai", "anthropic"]

    if "openai" in providers:
        patch_openai(_global_tracer, agent=agent, policy=policy)
    if "anthropic" in providers:
        patch_anthropic(_global_tracer, agent=agent, policy=policy)
    if "gemini" in providers:
        patch_gemini(_global_tracer, agent=agent, policy=policy)
    if "groq" in providers:
        patch_groq(_global_tracer, agent=agent, policy=policy)
    if "mistral" in providers:
        patch_mistral(_global_tracer, agent=agent, policy=policy)
    if "cohere" in providers:
        patch_cohere(_global_tracer, agent=agent, policy=policy)

    return _global_tracer
