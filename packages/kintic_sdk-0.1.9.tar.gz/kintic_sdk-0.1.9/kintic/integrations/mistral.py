from __future__ import annotations

import functools
import time
from typing import Any, Optional

from kintic.integrations._llm_chat import (
    extract_system_and_conversation,
    mistral_response_text,
    ship_chat_decision,
    ship_chat_error,
    token_cost,
)
from kintic.tracer import KinticTracer

_MISTRAL_COSTS = {
    "mistral-large-latest": (0.002, 0.006),
    "mistral-small-latest": (0.0001, 0.0003),
    "codestral-latest": (0.0003, 0.0009),
}


def _mistral_cost(model: str, usage: object) -> float:
    return token_cost(
        usage,
        model=model,
        costs=_MISTRAL_COSTS,
        input_attr="prompt_tokens",
        output_attr="completion_tokens",
    )


def patch_mistral(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
) -> None:
    try:
        from mistralai.client.chat import Chat  # type: ignore
    except ImportError:
        if tracer.debug:
            print("[Kintic] Mistral not installed, skipping patch")
        return

    original = Chat.complete
    if getattr(original, "_kintic_patched", False):
        return

    @functools.wraps(original)
    def patched_complete(self_chat: Any, *args: Any, **kwargs: Any) -> Any:
        start = time.time()
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        system_prompt, conversation = extract_system_and_conversation(messages)
        try:
            response = original(self_chat, *args, **kwargs)
            latency = time.time() - start
            output_text = mistral_response_text(response)
            usage = getattr(response, "usage", None)
            ship_chat_decision(
                tracer,
                agent=agent,
                policy=policy,
                model=model,
                messages=messages,
                kwargs=kwargs,
                output_text=output_text,
                latency=latency,
                cost_impact=_mistral_cost(str(model), usage),
                system_prompt=system_prompt,
                conversation=conversation,
            )
            return response
        except Exception as e:
            ship_chat_error(
                tracer,
                agent=agent,
                system_prompt=system_prompt,
                error=e,
                latency=time.time() - start,
            )
            raise

    setattr(patched_complete, "_kintic_patched", True)
    Chat.complete = patched_complete
    if tracer.debug:
        print("[Kintic] Mistral patched successfully")
