"""
LlamaIndex integration for Kintic decision ingest.

Uses LlamaIndex ``CallbackManager`` + a custom handler on ``start_trace`` / ``end_trace``
and LLM/QUERY events. Ships one Kintic decision per top-level trace (e.g. each ``query()``).

Install::

    pip install "kintic-sdk[llamaindex]"
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from kintic.tracer import KinticTracer, _jsonify


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _safe_text(value: Any, limit: int = 8_000) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value[:limit]
    return str(_jsonify(value))[:limit]


def _payload_preview(payload: Optional[Dict[str, Any]], limit: int = 4_000) -> Dict[str, Any]:
    if not payload:
        return {}
    out: Dict[str, Any] = {}
    for k, v in payload.items():
        key = str(k)
        if hasattr(k, "value"):
            key = str(getattr(k, "value"))
        if isinstance(v, str):
            out[key] = v[:limit]
        else:
            try:
                out[key] = _jsonify(v)
            except Exception:
                out[key] = str(v)[:limit]
    return out


def _import_llamaindex():
    try:
        from llama_index.core.callbacks import CallbackManager  # type: ignore
        from llama_index.core.callbacks.base_handler import BaseCallbackHandler  # type: ignore
        from llama_index.core.callbacks.schema import CBEventType, EventPayload  # type: ignore
    except ImportError as exc:
        raise ImportError(
            'LlamaIndex is not installed. Use: pip install "kintic-sdk[llamaindex]"'
        ) from exc
    return CallbackManager, BaseCallbackHandler, CBEventType, EventPayload


class KinticLlamaIndexRunCollector:
    """Accumulates LlamaIndex callback events for one trace."""

    def __init__(
        self,
        tracer: KinticTracer,
        *,
        agent: str,
        policy: Optional[str] = None,
        action: str = "llamaindex_query",
        query: Optional[str] = None,
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self.action = action
        self.query = query
        self._started = time.time()
        self._shipped = False
        self.trace_id: Optional[str] = None
        self._events: List[Dict[str, Any]] = []
        self._llm_calls: List[Dict[str, Any]] = []
        self._final_response: Optional[str] = None

    @property
    def shipped(self) -> bool:
        return self._shipped

    def reset(self, *, trace_id: Optional[str] = None, query: Optional[str] = None) -> None:
        self._started = time.time()
        self._shipped = False
        self.trace_id = trace_id
        if query is not None:
            self.query = query
        self._events.clear()
        self._llm_calls.clear()
        self._final_response = None

    def on_event_end(
        self,
        event_type: Any,
        payload: Optional[Dict[str, Any]],
        *,
        event_payload_enum: Any,
    ) -> None:
        et = str(getattr(event_type, "name", event_type))
        rec = {"type": et, "payload": _payload_preview(payload)}
        self._events.append(rec)

        if et == "LLM" and payload:
            llm_rec: Dict[str, Any] = {"event": "llamaindex_llm", "timestamp": _now_iso()}
            for attr in ("PROMPT", "COMPLETION", "MESSAGES", "RESPONSE"):
                key = getattr(event_payload_enum, attr, attr)
                if key in payload:
                    llm_rec[attr.lower()] = _safe_text(payload.get(key), 2_000)
            self._llm_calls.append(llm_rec)

        if et == "QUERY" and payload:
            ep = event_payload_enum
            for attr in ("RESPONSE", "QUERY_STR"):
                key = getattr(ep, attr, None)
                if key is not None and key in payload:
                    val = payload.get(key)
                    if attr == "RESPONSE":
                        self._final_response = _safe_text(val, 20_000)
                    elif attr == "QUERY_STR" and not self.query:
                        self.query = _safe_text(val, 2_000)

    def build_context_snapshot(self) -> Dict[str, Any]:
        snap: Dict[str, Any] = {
            "args": [],
            "kwargs": {"query": self.query} if self.query else {},
            "beliefState": {
                "trace_id": self.trace_id,
                "event_count": len(self._events),
            },
            "availableInformation": {
                "events": self._events[-40:],
            },
            "llamaIndexContext": {
                "framework": "llamaindex",
                "trace_id": self.trace_id,
                "query": self.query,
            },
        }
        if self.policy:
            snap["policyVersion"] = self.policy
        if self._llm_calls:
            snap["llmCalls"] = self._llm_calls
        return snap

    def ship(self, *, outcome: Optional[str] = None) -> None:
        if self._shipped:
            return
        self._shipped = True
        latency_ms = (time.time() - self._started) * 1000.0
        final = outcome or self._final_response or "completed"
        self.tracer.record_decision(
            agent=self.agent_name,
            action=self.action,
            context_snapshot=self.build_context_snapshot(),
            outcome=final[:20_000],
            latency_ms=latency_ms,
        )


def _build_handler_class():
    CallbackManager, BaseCallbackHandler, CBEventType, EventPayload = _import_llamaindex()

    class KinticLlamaIndexHandler(BaseCallbackHandler):  # type: ignore[misc]
        """LlamaIndex callback handler that ships one Kintic decision per trace."""

        def __init__(self, collector: KinticLlamaIndexRunCollector) -> None:
            self._collector = collector
            super().__init__(event_starts_to_ignore=[], event_ends_to_ignore=[])

        def on_event_start(
            self,
            event_type: Any,
            payload: Optional[Dict[str, Any]] = None,
            event_id: str = "",
            parent_id: str = "",
            **kwargs: Any,
        ) -> str:
            return event_id or ""

        def on_event_end(
            self,
            event_type: Any,
            payload: Optional[Dict[str, Any]] = None,
            event_id: str = "",
            **kwargs: Any,
        ) -> None:
            self._collector.on_event_end(
                event_type,
                payload,
                event_payload_enum=EventPayload,
            )

        def start_trace(self, trace_id: Optional[str] = None) -> None:
            q = None
            if isinstance(trace_id, str) and trace_id.startswith("query"):
                q = self._collector.query
            self._collector.reset(trace_id=trace_id, query=q)

        def end_trace(
            self,
            trace_id: Optional[str] = None,
            trace_map: Optional[Dict[str, List[str]]] = None,
        ) -> None:
            self._collector.ship()

    return KinticLlamaIndexHandler, CallbackManager


def create_llamaindex_callback_manager(
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str] = None,
    action: str = "llamaindex_query",
    query: Optional[str] = None,
) -> Any:
    """
    Build a LlamaIndex ``CallbackManager`` wired to Kintic.

    Use globally::

        from llama_index.core import Settings
        Settings.callback_manager = create_llamaindex_callback_manager(...)
    """
    HandlerCls, CallbackManager = _build_handler_class()
    collector = KinticLlamaIndexRunCollector(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
        query=query,
    )
    handler = HandlerCls(collector)
    return CallbackManager([handler])


def run_observed_query(
    query_engine: Any,
    query_str: str,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    action: str = "llamaindex_query",
) -> Any:
    """
  Run ``query_engine.query(...)`` with a per-call Kintic callback manager.
    """
    cm = create_llamaindex_callback_manager(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
        query=query_str,
    )
    query_fn = getattr(query_engine, "query", None)
    if not callable(query_fn):
        raise TypeError("query_engine must provide a query(str) method")

    try:
        return query_fn(query_str, callback_manager=cm)
    except TypeError:
        # Older engines: set on Settings for the duration of the call.
        try:
            from llama_index.core import Settings  # type: ignore

            prev = getattr(Settings, "callback_manager", None)
            Settings.callback_manager = cm
            try:
                return query_fn(query_str)
            finally:
                Settings.callback_manager = prev
        except Exception:
            return query_fn(query_str)


def attach_llamaindex_settings(
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str] = None,
    action: str = "llamaindex_query",
) -> Any:
    """Set ``Settings.callback_manager`` globally. Returns the ``CallbackManager``."""
    cm = create_llamaindex_callback_manager(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
    )
    from llama_index.core import Settings  # type: ignore

    Settings.callback_manager = cm
    return cm
