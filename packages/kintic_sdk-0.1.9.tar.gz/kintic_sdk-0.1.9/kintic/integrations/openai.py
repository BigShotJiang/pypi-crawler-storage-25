from __future__ import annotations

import functools
import time
from typing import Any, Dict, Optional, Tuple

from kintic.tracer import KinticTracer


def _extract_system_and_conversation(messages: Any) -> Tuple[Optional[str], list[Any]]:
    system_prompt: Optional[str] = None
    conversation: list[Any] = []
    if not isinstance(messages, list):
        return system_prompt, conversation
    for item in messages:
        if not isinstance(item, dict):
            conversation.append(item)
            continue
        role = item.get("role")
        if role == "system" and system_prompt is None:
            content = item.get("content")
            system_prompt = content if isinstance(content, str) else str(content)
        else:
            conversation.append(item)
    return system_prompt, conversation


def _response_text(response: Any) -> str:
    try:
        choices = getattr(response, "choices", None)
        if isinstance(choices, list) and choices:
            msg = getattr(choices[0], "message", None)
            content = getattr(msg, "content", None)
            if isinstance(content, str):
                return content
        return str(response)
    except Exception:
        return str(response)


def patch_openai(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
) -> None:
    try:
        import openai  # type: ignore
    except ImportError:
        if tracer.debug:
            print("[Kintic] OpenAI not installed, skipping patch")
        return

    create_owner = None
    original_create = None
    # New OpenAI client structure.
    try:
        create_owner = openai.resources.chat.completions.Completions
        original_create = create_owner.create
    except Exception:
        pass
    # Compatibility fallback for older interfaces.
    if original_create is None:
        try:
            create_owner = openai.chat.completions
            original_create = create_owner.create
        except Exception:
            pass
    if original_create is None or create_owner is None:
        if tracer.debug:
            print("[Kintic] OpenAI create() target not found, skipping patch")
        return
    if getattr(original_create, "_kintic_patched", False):
        return

    @functools.wraps(original_create)
    def patched_create(*args: Any, **kwargs: Any) -> Any:
        start = time.time()
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        system_prompt, conversation = _extract_system_and_conversation(messages)
        try:
            response = original_create(*args, **kwargs)
            latency = time.time() - start
            usage = getattr(response, "usage", None)
            output_text = _response_text(response)
            context_snapshot: Dict[str, Any] = {
                "beliefState": {
                    "systemPrompt": system_prompt,
                    "conversationHistory": conversation,
                    "model": model,
                    "lastUserMessage": (
                        conversation[-1].get("content")
                        if conversation and isinstance(conversation[-1], dict)
                        else None
                    ),
                },
                "policyVersion": policy,
                "availableInformation": {
                    "messageCount": len(messages) if isinstance(messages, list) else 0,
                    "model": model,
                    "temperature": kwargs.get("temperature"),
                    "maxTokens": kwargs.get("max_tokens"),
                },
            }
            payload = {
                "agentName": agent,
                "action": output_text[:100] if output_text else "llm_response",
                "contextSnapshot": context_snapshot,
                "outcome": output_text,
                "latency": latency,
                "costImpact": _calculate_cost(str(model), usage),
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }
            tracer._ship(payload)
            return response
        except Exception as e:
            latency = time.time() - start
            tracer._ship(
                {
                    "agentName": agent,
                    "action": "llm_error",
                    "contextSnapshot": {
                        "beliefState": {"systemPrompt": system_prompt},
                        "error": str(e),
                    },
                    "outcome": f"ERROR: {str(e)}",
                    "latency": latency,
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                }
            )
            raise

    setattr(patched_create, "_kintic_patched", True)
    create_owner.create = patched_create
    if tracer.debug:
        print("[Kintic] OpenAI patched successfully")


def _calculate_cost(model: str, usage: Any) -> float:
    if not usage:
        return 0.0
    costs = {
        "gpt-4": (0.03, 0.06),
        "gpt-4-turbo": (0.01, 0.03),
        "gpt-3.5-turbo": (0.001, 0.002),
        "gpt-4o": (0.005, 0.015),
        "gpt-4o-mini": (0.00015, 0.0006),
    }
    input_cost, output_cost = costs.get(model, (0.01, 0.03))
    prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
    completion_tokens = getattr(usage, "completion_tokens", 0) or 0
    return (prompt_tokens * input_cost / 1000.0) + (
        completion_tokens * output_cost / 1000.0
    )
