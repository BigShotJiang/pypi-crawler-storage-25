from __future__ import annotations

import functools
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from kintic.tracer import KinticTracer


def extract_system_and_conversation(messages: Any) -> Tuple[Optional[str], list[Any]]:
    system_prompt: Optional[str] = None
    conversation: list[Any] = []
    if not isinstance(messages, list):
        return system_prompt, conversation
    for item in messages:
        normalized = _normalize_message(item)
        if not isinstance(normalized, dict):
            conversation.append(normalized)
            continue
        role = normalized.get("role")
        if role == "system" and system_prompt is None:
            content = normalized.get("content")
            system_prompt = content if isinstance(content, str) else str(content)
        else:
            conversation.append(normalized)
    return system_prompt, conversation


def _normalize_message(item: Any) -> Any:
    if isinstance(item, dict):
        return item
    role = getattr(item, "role", None)
    content = getattr(item, "content", None)
    if role is not None:
        if content is not None and not isinstance(content, str):
            content = str(content)
        return {"role": role, "content": content}
    return item


def openai_style_response_text(response: Any) -> str:
    try:
        choices = getattr(response, "choices", None)
        if isinstance(choices, list) and choices:
            msg = getattr(choices[0], "message", None)
            content = getattr(msg, "content", None)
            if isinstance(content, str):
                return content
        text = getattr(response, "text", None)
        if isinstance(text, str):
            return text
        return str(response)
    except Exception:
        return str(response)


def mistral_response_text(response: Any) -> str:
    try:
        choices = getattr(response, "choices", None)
        if isinstance(choices, list) and choices:
            msg = getattr(choices[0], "message", None)
            content = getattr(msg, "content", None)
            if isinstance(content, str):
                return content
    except Exception:
        pass
    return openai_style_response_text(response)


def cohere_v2_response_text(response: Any) -> str:
    try:
        message = getattr(response, "message", None)
        if message is not None:
            content = getattr(message, "content", None)
            if isinstance(content, list) and content:
                first = content[0]
                text = getattr(first, "text", None)
                if isinstance(text, str):
                    return text
            if isinstance(content, str):
                return content
        text = getattr(response, "text", None)
        if isinstance(text, str):
            return text
    except Exception:
        pass
    return str(response)


def cohere_v1_response_text(response: Any) -> str:
    try:
        text = getattr(response, "text", None)
        if isinstance(text, str):
            return text
    except Exception:
        pass
    return str(response)


def gemini_response_text(response: Any) -> str:
    try:
        text = getattr(response, "text", None)
        if isinstance(text, str) and text:
            return text
        candidates = getattr(response, "candidates", None)
        if isinstance(candidates, list) and candidates:
            content = getattr(candidates[0], "content", None)
            parts = getattr(content, "parts", None) if content is not None else None
            if isinstance(parts, list) and parts:
                part_text = getattr(parts[0], "text", None)
                if isinstance(part_text, str):
                    return part_text
    except Exception:
        pass
    return str(response)


def gemini_contents_to_messages(contents: Any) -> list[Any]:
    if isinstance(contents, str):
        return [{"role": "user", "content": contents}]
    if not isinstance(contents, list):
        return [{"role": "user", "content": str(contents)}]
    messages: list[Any] = []
    for item in contents:
        if isinstance(item, str):
            messages.append({"role": "user", "content": item})
            continue
        role = getattr(item, "role", None) or "user"
        content = getattr(item, "content", None) or getattr(item, "parts", item)
        if content is not None and not isinstance(content, str):
            content = str(content)
        messages.append({"role": role, "content": content})
    return messages


def ship_chat_decision(
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str],
    model: Any,
    messages: Any,
    kwargs: Dict[str, Any],
    output_text: str,
    latency: float,
    cost_impact: float = 0.0,
    action: Optional[str] = None,
    system_prompt: Optional[str] = None,
    conversation: Optional[list[Any]] = None,
) -> None:
    if conversation is None:
        system_prompt, conversation = extract_system_and_conversation(messages)
    context_snapshot: Dict[str, Any] = {
        "beliefState": {
            "systemPrompt": system_prompt,
            "conversationHistory": conversation,
            "model": model,
            "lastUserMessage": (
                conversation[-1].get("content")
                if conversation
                and isinstance(conversation[-1], dict)
                else None
            ),
        },
        "policyVersion": policy,
        "availableInformation": {
            "messageCount": len(messages) if isinstance(messages, list) else 0,
            "model": model,
            "temperature": kwargs.get("temperature"),
            "maxTokens": kwargs.get("max_tokens") or kwargs.get("maxTokens"),
        },
    }
    tracer._ship(
        {
            "agentName": agent,
            "action": action or (output_text[:100] if output_text else "llm_response"),
            "contextSnapshot": context_snapshot,
            "outcome": output_text,
            "latency": latency,
            "costImpact": cost_impact,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
    )


def ship_chat_error(
    tracer: KinticTracer,
    *,
    agent: str,
    system_prompt: Optional[str],
    error: Exception,
    latency: float,
) -> None:
    tracer._ship(
        {
            "agentName": agent,
            "action": "llm_error",
            "contextSnapshot": {
                "beliefState": {"systemPrompt": system_prompt},
                "error": str(error),
            },
            "outcome": f"ERROR: {str(error)}",
            "latency": latency,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
    )


def patch_method(
    owner: Any,
    method_name: str,
    wrapper: Callable[[Callable[..., Any]], Callable[..., Any]],
) -> bool:
    original = getattr(owner, method_name, None)
    if original is None or not callable(original):
        return False
    if getattr(original, "_kintic_patched", False):
        return False
    patched = wrapper(original)
    setattr(patched, "_kintic_patched", True)
    setattr(owner, method_name, patched)
    return True


def patch_openai_compatible_create(
    module: Any,
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str],
    label: str,
    cost_fn: Optional[Callable[[str, Any], float]] = None,
) -> bool:
    create_owner = None
    original_create = None
    try:
        create_owner = module.resources.chat.completions.Completions
        original_create = create_owner.create
    except Exception:
        pass
    if original_create is None:
        try:
            create_owner = module.chat.completions
            original_create = create_owner.create
        except Exception:
            pass
    if original_create is None or create_owner is None:
        return False
    if getattr(original_create, "_kintic_patched", False):
        return False

    @functools.wraps(original_create)
    def patched_create(*args: Any, **kwargs: Any) -> Any:
        start = time.time()
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        system_prompt, conversation = extract_system_and_conversation(messages)
        try:
            response = original_create(*args, **kwargs)
            latency = time.time() - start
            output_text = openai_style_response_text(response)
            usage = getattr(response, "usage", None)
            cost = cost_fn(model, usage) if cost_fn else 0.0
            ship_chat_decision(
                tracer,
                agent=agent,
                policy=policy,
                model=model,
                messages=messages,
                kwargs=kwargs,
                output_text=output_text,
                latency=latency,
                cost_impact=cost,
                system_prompt=system_prompt,
                conversation=conversation,
            )
            return response
        except Exception as e:
            ship_chat_error(
                tracer,
                agent=agent,
                system_prompt=system_prompt,
                error=e,
                latency=time.time() - start,
            )
            raise

    setattr(patched_create, "_kintic_patched", True)
    create_owner.create = patched_create
    if tracer.debug:
        print(f"[Kintic] {label} patched successfully")
    return True


def token_cost(
    usage: Any,
    *,
    model: str,
    costs: Dict[str, Tuple[float, float]],
    input_attr: str,
    output_attr: str,
) -> float:
    if not usage:
        return 0.0
    input_cost, output_cost = costs.get(model, (0.01, 0.03))
    prompt_tokens = getattr(usage, input_attr, 0) or 0
    completion_tokens = getattr(usage, output_attr, 0) or 0
    return (prompt_tokens * input_cost / 1000.0) + (
        completion_tokens * output_cost / 1000.0
    )
