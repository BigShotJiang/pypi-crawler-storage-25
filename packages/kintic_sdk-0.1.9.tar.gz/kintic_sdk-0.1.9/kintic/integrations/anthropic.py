from __future__ import annotations

import functools
import json
import re
import time
from typing import Any, Optional

from kintic.tracer import KinticTracer


def _anthropic_output_text(response: Any) -> str:
    try:
        content = getattr(response, "content", None)
        if isinstance(content, list) and content:
            first = content[0]
            text = getattr(first, "text", None)
            if isinstance(text, str):
                return text
        return str(response)
    except Exception:
        return str(response)


def _strip_code_fences(text: str) -> str:
    return text.replace("```json\n", "").replace("```json", "").replace("```", "").strip()


def _extract_action(response_text: str, agent_name: str) -> str:
    cleaned = _strip_code_fences(response_text)
    try:
        parsed = json.loads(cleaned)
        decision = parsed.get("decision")
        if isinstance(decision, str) and decision:
            normalized_decision = decision.lower()
            if "deployment" in agent_name.lower():
                if normalized_decision in {"block", "deny"}:
                    return "deployment_block"
                if normalized_decision == "approve":
                    return "deployment_approve"
            return f"refund_{normalized_decision}"
    except Exception:
        pass
    fallback = re.sub(r"[`\n]+", " ", response_text[:50]).strip()
    return fallback or f"{agent_name}_response"


def _extract_cost_impact(response_text: str, messages: Any) -> float:
    cleaned = _strip_code_fences(response_text)
    decision = "UNKNOWN"
    risk_level = ""
    try:
        parsed = json.loads(cleaned)
        decision = str(parsed.get("decision", "UNKNOWN")).upper()
        risk_level = str(parsed.get("risk_level", "")).upper()
        if decision in {"BLOCK", "DENY"}:
            print(f"[Kintic] costImpact decision={decision} -> 0")
            return 0.0
        if decision != "APPROVE":
            print(f"[Kintic] costImpact decision={decision} unsupported -> 0")
            return 0.0
    except Exception:
        print("[Kintic] costImpact parse failed -> 0")
        return 0.0

    last_msg = ""
    if isinstance(messages, list) and messages and isinstance(messages[-1], dict):
        content = messages[-1].get("content")
        if isinstance(content, str):
            last_msg = content
    amount_match = re.search(r"Amount:\s*\$(\d+)", last_msg)
    if amount_match:
        try:
            amount = float(int(amount_match.group(1)))
            print(f"[Kintic] costImpact decision={decision} amount={amount}")
            return amount
        except Exception:
            print(f"[Kintic] costImpact decision={decision} amount=parse-error")

    if risk_level == "HIGH":
        print("[Kintic] costImpact decision=APPROVE risk=HIGH amount=45000")
        return 45000.0
    if risk_level == "MEDIUM":
        print("[Kintic] costImpact decision=APPROVE risk=MEDIUM amount=12000")
        return 12000.0
    if risk_level == "LOW":
        print("[Kintic] costImpact decision=APPROVE risk=LOW amount=3500")
        return 3500.0

    print("[Kintic] costImpact decision=APPROVE risk=missing amount=3500")
    return 3500.0


def patch_anthropic(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
) -> None:
    try:
        import anthropic as anthropic_sdk  # type: ignore
    except ImportError:
        if tracer.debug:
            print("[Kintic] Anthropic not installed, skipping patch")
        return

    try:
        messages_type = anthropic_sdk.resources.messages.Messages
        original_create = messages_type.create
    except Exception:
        if tracer.debug:
            print("[Kintic] Anthropic create() target not found, skipping patch")
        return
    if getattr(original_create, "_kintic_patched", False):
        return

    @functools.wraps(original_create)
    def patched_create(self_client: Any, *args: Any, **kwargs: Any) -> Any:
        start = time.time()
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        system = kwargs.get("system", None)
        try:
            response = original_create(self_client, *args, **kwargs)
            latency = time.time() - start
            output_text = _anthropic_output_text(response)
            context_snapshot = {
                "beliefState": {
                    "systemPrompt": system,
                    "conversationHistory": messages,
                    "model": model,
                    "lastUserMessage": (
                        messages[-1].get("content")
                        if isinstance(messages, list)
                        and messages
                        and isinstance(messages[-1], dict)
                        else None
                    ),
                },
                "policyVersion": policy,
                "availableInformation": {
                    "messageCount": len(messages) if isinstance(messages, list) else 0,
                    "model": model,
                    "maxTokens": kwargs.get("max_tokens"),
                },
            }
            payload = {
                "agentName": agent,
                "action": _extract_action(output_text, agent),
                "contextSnapshot": context_snapshot,
                "outcome": output_text,
                "latency": latency,
                "costImpact": _extract_cost_impact(output_text, messages),
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }
            tracer._ship(payload)
            return response
        except Exception as e:
            tracer._ship(
                {
                    "agentName": agent,
                    "action": "llm_error",
                    "contextSnapshot": {"system": system, "error": str(e)},
                    "outcome": f"ERROR: {str(e)}",
                    "latency": time.time() - start,
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                }
            )
            raise

    setattr(patched_create, "_kintic_patched", True)
    messages_type.create = patched_create
    if tracer.debug:
        print("[Kintic] Anthropic patched successfully")


def _calculate_anthropic_cost(model: str, usage: Any) -> float:
    if not usage:
        return 0.0
    costs = {
        "claude-3-opus-20240229": (0.015, 0.075),
        "claude-3-sonnet-20240229": (0.003, 0.015),
        "claude-3-haiku-20240307": (0.00025, 0.00125),
        "claude-sonnet-4-20250514": (0.003, 0.015),
    }
    input_cost, output_cost = costs.get(model, (0.003, 0.015))
    input_tokens = getattr(usage, "input_tokens", 0) or 0
    output_tokens = getattr(usage, "output_tokens", 0) or 0
    return (input_tokens * input_cost / 1000.0) + (output_tokens * output_cost / 1000.0)
