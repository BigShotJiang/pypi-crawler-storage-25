from __future__ import annotations

import functools
import time
from typing import Any, Optional

from kintic.integrations._llm_chat import (
    extract_system_and_conversation,
    gemini_contents_to_messages,
    gemini_response_text,
    ship_chat_decision,
    ship_chat_error,
)
from kintic.tracer import KinticTracer


def _patch_google_genai(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str],
) -> bool:
    try:
        from google.genai.models import Models  # type: ignore
    except ImportError:
        return False

    original = Models.generate_content
    if getattr(original, "_kintic_patched", False):
        return True

    @functools.wraps(original)
    def patched_generate(self_models: Any, *args: Any, **kwargs: Any) -> Any:
        start = time.time()
        model = kwargs.get("model", "unknown")
        contents = kwargs.get("contents")
        messages = gemini_contents_to_messages(contents)
        system_prompt, conversation = extract_system_and_conversation(messages)
        config = kwargs.get("config") or {}
        if isinstance(config, dict):
            temp = config.get("temperature")
        else:
            temp = getattr(config, "temperature", None)
        merged_kwargs = {**kwargs, "temperature": temp}
        try:
            response = original(self_models, *args, **kwargs)
            latency = time.time() - start
            output_text = gemini_response_text(response)
            ship_chat_decision(
                tracer,
                agent=agent,
                policy=policy,
                model=model,
                messages=messages,
                kwargs=merged_kwargs,
                output_text=output_text,
                latency=latency,
                system_prompt=system_prompt,
                conversation=conversation,
            )
            return response
        except Exception as e:
            ship_chat_error(
                tracer,
                agent=agent,
                system_prompt=system_prompt,
                error=e,
                latency=time.time() - start,
            )
            raise

    setattr(patched_generate, "_kintic_patched", True)
    Models.generate_content = patched_generate
    return True


def _patch_generativeai(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str],
) -> bool:
    try:
        import google.generativeai as genai  # type: ignore
    except ImportError:
        return False

    try:
        model_cls = genai.GenerativeModel
    except Exception:
        return False

    original = model_cls.generate_content
    if getattr(original, "_kintic_patched", False):
        return True

    @functools.wraps(original)
    def patched_generate(self_model: Any, contents: Any, *args: Any, **kwargs: Any) -> Any:
        start = time.time()
        model = getattr(self_model, "model_name", None) or getattr(
            self_model, "_model_name", "unknown"
        )
        messages = gemini_contents_to_messages(contents)
        system_prompt, conversation = extract_system_and_conversation(messages)
        try:
            response = original(self_model, contents, *args, **kwargs)
            latency = time.time() - start
            output_text = gemini_response_text(response)
            ship_chat_decision(
                tracer,
                agent=agent,
                policy=policy,
                model=model,
                messages=messages,
                kwargs=kwargs,
                output_text=output_text,
                latency=latency,
                system_prompt=system_prompt,
                conversation=conversation,
            )
            return response
        except Exception as e:
            ship_chat_error(
                tracer,
                agent=agent,
                system_prompt=system_prompt,
                error=e,
                latency=time.time() - start,
            )
            raise

    setattr(patched_generate, "_kintic_patched", True)
    model_cls.generate_content = patched_generate
    return True


def patch_gemini(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
) -> None:
    genai_ok = _patch_google_genai(tracer, agent, policy)
    legacy_ok = _patch_generativeai(tracer, agent, policy)
    if not genai_ok and not legacy_ok:
        if tracer.debug:
            print("[Kintic] Gemini SDK not installed, skipping patch")
    elif tracer.debug:
        print("[Kintic] Gemini patched successfully")
