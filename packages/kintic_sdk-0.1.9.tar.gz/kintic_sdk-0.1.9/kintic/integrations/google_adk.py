"""
Google ADK (Agent Development Kit) integration for Kintic decision ingest.

Registers ADK agent callbacks (before/after agent, model, tool) and ships one
Kintic decision per agent turn when ``after_agent`` fires.

Install::

    pip install "kintic-sdk[google-adk]"
"""

from __future__ import annotations

import time
from typing import Any, Callable, Dict, List, Optional

from kintic.tracer import KinticTracer, _jsonify


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _safe_text(value: Any, limit: int = 8_000) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value[:limit]
    return str(_jsonify(value))[:limit]


def _ctx_agent_name(callback_context: Any) -> str:
    return str(
        getattr(callback_context, "agent_name", None)
        or getattr(callback_context, "agent_id", None)
        or "adk-agent"
    )


def _build_delegation_chain(names: List[str]) -> List[Dict[str, Any]]:
    ts = _now_iso()
    chain: List[Dict[str, Any]] = []
    for i in range(1, len(names)):
        chain.append(
            {
                "from": names[i - 1],
                "to": names[i],
                "authorization": "adk_handoff",
                "timestamp": ts,
            }
        )
    return chain


class KinticAdkRunCollector:
    """Accumulates ADK callback signals for one agent invocation."""

    def __init__(
        self,
        tracer: KinticTracer,
        *,
        agent: str,
        policy: Optional[str] = None,
        action: str = "adk_agent_turn",
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self.action = action
        self._started = time.time()
        self._shipped = False
        self._participants: List[str] = []
        self._model_calls: List[Dict[str, Any]] = []
        self._tool_calls: List[Dict[str, Any]] = []
        self._errors: List[str] = []
        self._final_outcome: Optional[str] = None

    @property
    def shipped(self) -> bool:
        return self._shipped

    def reset(self) -> None:
        self._started = time.time()
        self._shipped = False
        self._participants.clear()
        self._model_calls.clear()
        self._tool_calls.clear()
        self._errors.clear()
        self._final_outcome = None

    def _track_participant(self, name: str) -> None:
        if name and (not self._participants or self._participants[-1] != name):
            self._participants.append(name)

    def on_before_agent(self, callback_context: Any) -> None:
        self.reset()
        self._track_participant(_ctx_agent_name(callback_context))

    def on_after_agent(self, callback_context: Any, result: Any = None) -> None:
        self._track_participant(_ctx_agent_name(callback_context))
        if result is not None:
            self._final_outcome = _safe_text(result, 20_000)
        self.ship()

    def on_before_model(self, callback_context: Any, llm_request: Any) -> None:
        self._track_participant(_ctx_agent_name(callback_context))
        self._model_calls.append(
            {
                "phase": "before_model",
                "timestamp": _now_iso(),
                "request_preview": _safe_text(llm_request, 2_000),
            }
        )

    def on_after_model(
        self,
        callback_context: Any,
        llm_response: Any,
    ) -> None:
        self._track_participant(_ctx_agent_name(callback_context))
        self._model_calls.append(
            {
                "phase": "after_model",
                "timestamp": _now_iso(),
                "response_preview": _safe_text(llm_response, 2_000),
            }
        )

    def on_before_tool(
        self,
        callback_context: Any,
        tool: Any = None,
        tool_input: Any = None,
        **kwargs: Any,
    ) -> None:
        self._track_participant(_ctx_agent_name(callback_context))
        tool_name = str(getattr(tool, "name", None) or kwargs.get("tool_name") or "tool")
        self._tool_calls.append(
            {
                "tool": tool_name,
                "input": _safe_text(tool_input, 2_000),
                "timestamp": _now_iso(),
            }
        )

    def on_after_tool(
        self,
        callback_context: Any,
        tool: Any = None,
        tool_result: Any = None,
        **kwargs: Any,
    ) -> None:
        tool_name = str(getattr(tool, "name", None) or kwargs.get("tool_name") or "tool")
        for call in reversed(self._tool_calls):
            if call.get("tool") == tool_name and "output" not in call:
                call["output"] = _safe_text(tool_result, 2_000)
                break

    def on_error(self, message: str) -> None:
        self._errors.append(message[:2_000])

    def build_context_snapshot(self) -> Dict[str, Any]:
        belief: Dict[str, Any] = {
            "participants": list(self._participants),
            "model_call_count": len(self._model_calls),
            "tool_call_count": len(self._tool_calls),
        }
        if self._errors:
            belief["errors"] = self._errors

        snap: Dict[str, Any] = {
            "args": [],
            "kwargs": {},
            "beliefState": belief,
            "availableInformation": {
                "model_calls": self._model_calls[-30:],
                "tool_calls": self._tool_calls[-30:],
            },
            "adkContext": {
                "framework": "google_adk",
            },
        }
        if self.policy:
            snap["policyVersion"] = self.policy
        if self._model_calls:
            snap["llmCalls"] = self._model_calls
        return snap

    def ship(self, *, outcome: Optional[str] = None) -> None:
        if self._shipped:
            return
        self._shipped = True
        latency_ms = (time.time() - self._started) * 1000.0
        snap = self.build_context_snapshot()
        final = outcome or self._final_outcome
        if not final and self._errors:
            final = f"ERROR: {self._errors[-1]}"
        if not final:
            final = "completed"
        delegation = _build_delegation_chain(self._participants)
        self.tracer.record_decision(
            agent=self.agent_name,
            action=self.action,
            context_snapshot=snap,
            outcome=final[:20_000],
            latency_ms=latency_ms,
            delegation_chain=delegation if delegation else None,
        )


class KinticAdkCallbacks:
    """
    Callback callables for ``google.adk.agents.LlmAgent`` (and similar).

    Pass :meth:`as_agent_kwargs` into the agent constructor.
    """

    def __init__(self, collector: KinticAdkRunCollector) -> None:
        self.collector = collector

    def before_agent(self, callback_context: Any, *args: Any, **kwargs: Any) -> Any:
        try:
            self.collector.on_before_agent(callback_context)
        except Exception:
            pass
        return None

    def after_agent(self, callback_context: Any, *args: Any, **kwargs: Any) -> Any:
        result = args[0] if args else kwargs.get("result")
        try:
            self.collector.on_after_agent(callback_context, result)
        except Exception:
            pass
        return None

    def before_model(self, callback_context: Any, *args: Any, **kwargs: Any) -> Any:
        llm_request = args[0] if args else kwargs.get("llm_request")
        try:
            self.collector.on_before_model(callback_context, llm_request)
        except Exception:
            pass
        return None

    def after_model(self, callback_context: Any, *args: Any, **kwargs: Any) -> Any:
        llm_response = args[0] if args else kwargs.get("llm_response")
        try:
            self.collector.on_after_model(callback_context, llm_response)
        except Exception:
            pass
        return None

    def before_tool(self, callback_context: Any, *args: Any, **kwargs: Any) -> Any:
        try:
            tool = args[0] if args else kwargs.get("tool")
            tool_input = args[1] if len(args) > 1 else kwargs.get("tool_input")
            self.collector.on_before_tool(
                callback_context,
                tool=tool,
                tool_input=tool_input,
                **kwargs,
            )
        except Exception:
            pass
        return None

    def after_tool(self, callback_context: Any, *args: Any, **kwargs: Any) -> Any:
        try:
            tool = args[0] if args else kwargs.get("tool")
            tool_result = args[1] if len(args) > 1 else kwargs.get("tool_result")
            self.collector.on_after_tool(
                callback_context,
                tool=tool,
                tool_result=tool_result,
                **kwargs,
            )
        except Exception:
            pass
        return None

    def as_agent_kwargs(self) -> Dict[str, Callable[..., Any]]:
        """Keyword arguments for ``LlmAgent(..., **kwargs)``."""
        return {
            "before_agent_callback": self.before_agent,
            "after_agent_callback": self.after_agent,
            "before_model_callback": self.before_model,
            "after_model_callback": self.after_model,
            "before_tool_callback": self.before_tool,
            "after_tool_callback": self.after_tool,
        }


def install_adk_callbacks(
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str] = None,
    action: str = "adk_agent_turn",
) -> KinticAdkCallbacks:
    """
    Build ADK callback bundle. Use with::

        callbacks = install_adk_callbacks(tracer, agent="my-adk-agent", policy="v1")
        my_agent = LlmAgent(..., **callbacks.as_agent_kwargs())
    """
    collector = KinticAdkRunCollector(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
    )
    return KinticAdkCallbacks(collector)


def ship_adk_turn(
    tracer: KinticTracer,
    *,
    agent: str,
    outcome: str,
    policy: Optional[str] = None,
    action: str = "adk_agent_turn",
    model_calls: Optional[List[Dict[str, Any]]] = None,
    tool_calls: Optional[List[Dict[str, Any]]] = None,
    latency_ms: Optional[float] = None,
) -> None:
    """Manual one-shot ingest when you already have ADK run results."""
    collector = KinticAdkRunCollector(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
    )
    if model_calls:
        collector._model_calls.extend(model_calls)
    if tool_calls:
        collector._tool_calls.extend(tool_calls)
    if latency_ms is not None:
        collector._started = time.time() - (latency_ms / 1000.0)
    collector.ship(outcome=outcome)
