from __future__ import annotations

from typing import Optional

from kintic.integrations._llm_chat import patch_openai_compatible_create, token_cost
from kintic.tracer import KinticTracer

_GROQ_COSTS = {
    "llama-3.3-70b-versatile": (0.00059, 0.00079),
    "llama-3.1-8b-instant": (0.00005, 0.00008),
    "mixtral-8x7b-32768": (0.00024, 0.00024),
}


def _groq_cost(model: str, usage: object) -> float:
    return token_cost(
        usage,
        model=model,
        costs=_GROQ_COSTS,
        input_attr="prompt_tokens",
        output_attr="completion_tokens",
    )


def patch_groq(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
) -> None:
    try:
        import groq  # type: ignore
    except ImportError:
        if tracer.debug:
            print("[Kintic] Groq not installed, skipping patch")
        return
    if not patch_openai_compatible_create(
        groq,
        tracer,
        agent=agent,
        policy=policy,
        label="Groq",
        cost_fn=_groq_cost,
    ):
        if tracer.debug:
            print("[Kintic] Groq create() target not found, skipping patch")
