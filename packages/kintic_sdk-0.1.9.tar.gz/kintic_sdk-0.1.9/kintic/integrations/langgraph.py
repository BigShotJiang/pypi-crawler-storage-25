"""
LangGraph integration for Kintic decision ingest.

Wires ``KinticLangGraphHandler`` (LangChain callbacks) into graph ``invoke`` / ``stream``
runs. LangGraph sets ``langgraph_node`` in callback metadata on each node step.

Install::

    pip install "kintic-sdk[langgraph]"
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, AsyncIterator, Dict, Iterator, List, Literal, Optional, Union

from kintic.integrations.langchain import KinticCallbackHandler
from kintic.tracer import KinticTracer, _jsonify

ShipMode = Literal["graph_only", "per_node", "both"]


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _import_langgraph() -> None:
    try:
        import langgraph  # type: ignore  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            'LangGraph is not installed. Use: pip install "kintic-sdk[langgraph]"'
        ) from exc


def _safe_json(value: Any, limit: int = 12_000) -> Any:
    try:
        out = _jsonify(value)
        if isinstance(out, str) and len(out) > limit:
            return out[:limit]
        return out
    except Exception:
        text = str(value)
        return text[:limit]


def _extract_langgraph_node(metadata: Any) -> Optional[str]:
    if not isinstance(metadata, dict):
        return None
    node = metadata.get("langgraph_node")
    if node is not None:
        return str(node)
    return None


def _extract_langgraph_meta(metadata: Any) -> Dict[str, Any]:
    if not isinstance(metadata, dict):
        return {}
    keys = (
        "langgraph_node",
        "langgraph_step",
        "langgraph_triggers",
        "langgraph_path",
        "langgraph_checkpoint_ns",
        "ls_integration",
    )
    return {k: _safe_json(metadata[k]) for k in keys if k in metadata}


class KinticLangGraphHandler(KinticCallbackHandler):
    """
    LangChain callback handler tuned for LangGraph.

    * ``graph_only`` (default): one Kintic decision when the full graph finishes.
    * ``per_node``: one decision per LangGraph node (``langgraph:{node}``).
    * ``both``: per-node decisions plus a final graph run decision.
    """

    def __init__(
        self,
        tracer: KinticTracer,
        agent: str,
        policy: Optional[str] = None,
        *,
        ship_mode: ShipMode = "graph_only",
    ) -> None:
        super().__init__(tracer, agent=agent, policy=policy)
        self.ship_mode = ship_mode
        self._node_meta: Dict[str, Dict[str, Any]] = {}

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        super().on_chain_start(
            serialized, inputs, run_id=run_id, **kwargs
        )
        metadata = kwargs.get("metadata")
        node = _extract_langgraph_node(metadata)
        if not node:
            return
        rid = self._rid(run_id)
        root_rid = self._root_rid(run_id, kwargs.get("parent_run_id"))
        self._node_meta[rid] = _extract_langgraph_meta(metadata)
        run = self._runs.get(root_rid)
        if run is not None:
            run["langgraph_node"] = node
            run["langgraph_meta"] = self._node_meta.get(rid, {})

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        parent_run_id = kwargs.get("parent_run_id")

        if self.ship_mode == "graph_only" and parent_run_id is not None:
            return

        root_rid = self._root_rid(run_id, parent_run_id)
        run = self._runs.get(root_rid)
        node_name = run.get("langgraph_node") if isinstance(run, dict) else None

        if (
            self.ship_mode in ("per_node", "both")
            and parent_run_id is not None
            and node_name
            and run is not None
        ):
            self._ship_node_decision(
                run,
                node_name=str(node_name),
                outputs=outputs,
                meta=run.get("langgraph_meta") if isinstance(run.get("langgraph_meta"), dict) else {},
            )
            run.pop("langgraph_node", None)
            run.pop("langgraph_meta", None)
            if self.ship_mode == "per_node":
                return

        if self.ship_mode == "per_node" and parent_run_id is None:
            return

        super().on_chain_end(outputs, run_id=run_id, **kwargs)

    def _ship_node_decision(
        self,
        run: Dict[str, Any],
        *,
        node_name: str,
        outputs: Dict[str, Any],
        meta: Dict[str, Any],
    ) -> None:
        reasoning = [
            str(a.get("log"))
            for a in run.get("agent_actions", [])
            if isinstance(a, dict) and a.get("log") is not None
        ]
        context_snapshot = {
            "beliefState": {
                "reasoning": reasoning,
                "final_reasoning": reasoning[-1] if reasoning else None,
                "langgraphNode": node_name,
            },
            "policyVersion": run.get("policy"),
            "systemPrompt": run.get("system_prompt"),
            "llmCalls": run.get("llm_calls", []),
            "availableInformation": {
                "langgraph": meta,
                "node": node_name,
                "outputs": _safe_json(outputs),
                "inputs": run.get("inputs", {}),
            },
        }
        self.tracer._ship(
            {
                "agentName": run.get("agent", self.agent_name),
                "action": f"langgraph:{node_name}",
                "contextSnapshot": context_snapshot,
                "delegationChain": [],
                "outcome": _safe_json(outputs),
                "latency": float(time.time() - float(run.get("start_time", time.time()))),
                "timestamp": _now_iso(),
            }
        )


class KinticLangGraphStreamCollector:
    """Ships one Kintic decision per ``stream_mode='updates'`` chunk."""

    def __init__(
        self,
        tracer: KinticTracer,
        *,
        agent: str,
        policy: Optional[str] = None,
        graph_input: Any = None,
        ship_final: bool = True,
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self.graph_input = graph_input
        self.ship_final = ship_final
        self._started = time.time()
        self._nodes: List[Dict[str, Any]] = []
        self._final_state: Any = None

    def record_update(self, chunk: Any) -> None:
        if not isinstance(chunk, dict):
            self._final_state = chunk
            return
        for node_name, state in chunk.items():
            self._nodes.append(
                {
                    "node": str(node_name),
                    "state": _safe_json(state),
                    "timestamp": _now_iso(),
                }
            )
            self._ship_node(str(node_name), state)

    def finish(self, result: Any) -> None:
        self._final_state = result
        if self.ship_final:
            self._ship_graph(result)

    def _ship_node(self, node_name: str, state: Any) -> None:
        self.tracer._ship(
            {
                "agentName": self.agent_name,
                "action": f"langgraph:{node_name}",
                "contextSnapshot": {
                    "beliefState": {"langgraphNode": node_name},
                    "policyVersion": self.policy,
                    "availableInformation": {
                        "graphInput": _safe_json(self.graph_input),
                        "node": node_name,
                        "state": _safe_json(state),
                        "streamMode": "updates",
                    },
                },
                "outcome": _safe_json(state),
                "latency": time.time() - self._started,
                "timestamp": _now_iso(),
            }
        )

    def _ship_graph(self, result: Any) -> None:
        self.tracer._ship(
            {
                "agentName": self.agent_name,
                "action": "langgraph_run",
                "contextSnapshot": {
                    "beliefState": {"nodesExecuted": [n.get("node") for n in self._nodes]},
                    "policyVersion": self.policy,
                    "availableInformation": {
                        "graphInput": _safe_json(self.graph_input),
                        "nodes": self._nodes,
                        "finalState": _safe_json(result),
                        "streamMode": "updates",
                    },
                },
                "outcome": _safe_json(result),
                "latency": time.time() - self._started,
                "timestamp": _now_iso(),
            }
        )


def create_langgraph_handler(
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str] = None,
    ship_mode: ShipMode = "graph_only",
) -> KinticLangGraphHandler:
    """Build a callback handler for ``config={'callbacks': [handler]}``."""
    _import_langgraph()
    return KinticLangGraphHandler(
        tracer,
        agent=agent,
        policy=policy,
        ship_mode=ship_mode,
    )


def merge_langgraph_config(
    config: Optional[Dict[str, Any]],
    handler: KinticLangGraphHandler,
) -> Dict[str, Any]:
    """Merge *handler* into a LangGraph / LangChain ``RunnableConfig``."""
    merged: Dict[str, Any] = dict(config or {})
    callbacks = list(merged.get("callbacks") or [])
    if handler not in callbacks:
        callbacks.append(handler)
    merged["callbacks"] = callbacks
    return merged


def _compiled_graph(graph: Any) -> Any:
    if hasattr(graph, "invoke"):
        return graph
    if hasattr(graph, "compile") and callable(graph.compile):
        return graph.compile()
    raise TypeError(
        "graph must be a compiled LangGraph (with invoke/stream) or a StateGraph with compile()"
    )


def run_observed_invoke(
    graph: Any,
    input: Any,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    ship_mode: ShipMode = "graph_only",
    **invoke_kwargs: Any,
) -> Any:
    """
    ``graph.invoke(...)`` with Kintic callbacks (one graph-level decision by default).
    """
    _import_langgraph()
    app = _compiled_graph(graph)
    handler = create_langgraph_handler(
        tracer, agent=agent, policy=policy, ship_mode=ship_mode
    )
    merged = merge_langgraph_config(config, handler)
    return app.invoke(input, config=merged, **invoke_kwargs)


async def run_observed_ainvoke(
    graph: Any,
    input: Any,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    ship_mode: ShipMode = "graph_only",
    **invoke_kwargs: Any,
) -> Any:
    """Async ``graph.ainvoke(...)`` with Kintic callbacks."""
    _import_langgraph()
    app = _compiled_graph(graph)
    handler = create_langgraph_handler(
        tracer, agent=agent, policy=policy, ship_mode=ship_mode
    )
    merged = merge_langgraph_config(config, handler)
    return await app.ainvoke(input, config=merged, **invoke_kwargs)


def run_observed_stream(
    graph: Any,
    input: Any,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    stream_mode: Union[str, List[str]] = "updates",
    ship_stream_nodes: bool = True,
    ship_final_graph: bool = True,
    also_attach_callbacks: bool = False,
    ship_mode: ShipMode = "graph_only",
    **stream_kwargs: Any,
) -> Iterator[Any]:
    """
    Wrap ``graph.stream(...)``.

    With ``stream_mode='updates'`` (default), ships one decision per node chunk.
    Optionally also attaches callbacks for LLM/tool detail inside nodes.
    """
    _import_langgraph()
    app = _compiled_graph(graph)
    merged = dict(config or {})
    handler: Optional[KinticLangGraphHandler] = None
    if also_attach_callbacks:
        handler = create_langgraph_handler(
            tracer, agent=agent, policy=policy, ship_mode=ship_mode
        )
        merged = merge_langgraph_config(merged, handler)

    collector = KinticLangGraphStreamCollector(
        tracer,
        agent=agent,
        policy=policy,
        graph_input=input,
        ship_final=ship_final_graph,
    )
    final: Any = None
    for chunk in app.stream(
        input,
        config=merged,
        stream_mode=stream_mode,
        **stream_kwargs,
    ):
        final = chunk
        if ship_stream_nodes and stream_mode == "updates" and isinstance(chunk, dict):
            collector.record_update(chunk)
        yield chunk
    collector.finish(final)


async def run_observed_astream(
    graph: Any,
    input: Any,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    stream_mode: Union[str, List[str]] = "updates",
    ship_stream_nodes: bool = True,
    ship_final_graph: bool = True,
    also_attach_callbacks: bool = False,
    ship_mode: ShipMode = "graph_only",
    **stream_kwargs: Any,
) -> AsyncIterator[Any]:
    """Async ``graph.astream(...)`` with per-node Kintic decisions."""
    _import_langgraph()
    app = _compiled_graph(graph)
    merged = dict(config or {})
    if also_attach_callbacks:
        handler = create_langgraph_handler(
            tracer, agent=agent, policy=policy, ship_mode=ship_mode
        )
        merged = merge_langgraph_config(merged, handler)

    collector = KinticLangGraphStreamCollector(
        tracer,
        agent=agent,
        policy=policy,
        graph_input=input,
        ship_final=ship_final_graph,
    )
    final: Any = None
    async for chunk in app.astream(
        input,
        config=merged,
        stream_mode=stream_mode,
        **stream_kwargs,
    ):
        final = chunk
        if ship_stream_nodes and stream_mode == "updates" and isinstance(chunk, dict):
            collector.record_update(chunk)
        yield chunk
    collector.finish(final)
