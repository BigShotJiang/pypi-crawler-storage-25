from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from kintic.tracer import KinticTracer, _jsonify

try:  # LangChain classic path
    from langchain.callbacks.base import BaseCallbackHandler  # type: ignore
except Exception:  # pragma: no cover
    try:  # LangChain core path
        from langchain_core.callbacks.base import BaseCallbackHandler  # type: ignore
    except Exception:  # pragma: no cover
        class BaseCallbackHandler:  # type: ignore
            pass

try:
    from langchain.schema import AgentAction, AgentFinish, LLMResult  # type: ignore
except Exception:  # pragma: no cover
    AgentAction = Any  # type: ignore
    AgentFinish = Any  # type: ignore
    LLMResult = Any  # type: ignore


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class KinticCallbackHandler(BaseCallbackHandler):
    def __init__(
        self,
        tracer: KinticTracer,
        agent: str,
        policy: Optional[str] = None,
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self._runs: Dict[str, Dict[str, Any]] = {}
        self._parents: Dict[str, str] = {}

    @staticmethod
    def _rid(run_id: Union[UUID, str, None]) -> str:
        return str(run_id or "default")

    def _root_rid(
        self,
        run_id: Union[UUID, str, None],
        parent_run_id: Union[UUID, str, None] = None,
    ) -> str:
        rid = self._rid(run_id)
        parent = self._rid(parent_run_id) if parent_run_id is not None else None
        if parent:
            root = self._parents.get(parent, parent)
            self._parents[rid] = root
            return root
        return self._parents.get(rid, rid)

    def _ensure_run(
        self,
        run_id: Union[UUID, str, None],
        parent_run_id: Union[UUID, str, None] = None,
    ) -> Dict[str, Any]:
        root_rid = self._root_rid(run_id, parent_run_id)
        run = self._runs.get(root_rid)
        if run is None:
            run = {
                "agent": self.agent_name,
                "policy": self.policy,
                "start_time": time.time(),
                "llm_calls": [],
                "tool_calls": [],
                "agent_actions": [],
                "system_prompt": None,
                "belief_state": {},
                "inputs": {},
            }
            self._runs[root_rid] = run
        return run

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        run["serialized"] = _jsonify(serialized)
        run["inputs"] = _jsonify(inputs)
        run["start_time"] = time.time()

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        prompts: List[str] = []
        for turn in messages or []:
            parts: List[str] = []
            for msg in turn or []:
                content = getattr(msg, "content", None)
                role = getattr(msg, "type", None) or getattr(msg, "role", None)
                if content is not None:
                    if role:
                        parts.append(f"[{role}] {content}")
                    else:
                        parts.append(str(content))
            if parts:
                prompts.append("\n".join(parts))
        self.on_llm_start(
            serialized=serialized,
            prompts=prompts,
            run_id=run_id,
            **kwargs,
        )

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        model = None
        invocation_params = kwargs.get("invocation_params")
        if isinstance(invocation_params, dict):
            model = invocation_params.get("model") or invocation_params.get("model_name")
        system_prompt = None
        user_prompt = None
        if prompts:
            if len(prompts) > 1:
                system_prompt = prompts[0]
                user_prompt = prompts[-1]
            else:
                user_prompt = prompts[0]
        if system_prompt and run.get("system_prompt") is None:
            run["system_prompt"] = system_prompt
        run["llm_calls"].append(
            _jsonify(
                {
                    "event": "llm_start",
                    "serialized": serialized,
                    "prompts": prompts,
                    "system_prompt": system_prompt,
                    "user_prompt": user_prompt,
                    "model": model,
                    "start_time": time.time(),
                    "timestamp": _now_iso(),
                }
            )
        )

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        now = time.time()
        llm_output = getattr(response, "llm_output", None)
        token_usage = llm_output.get("token_usage") if isinstance(llm_output, dict) else None
        generations = getattr(response, "generations", None)
        output_text = None
        if isinstance(generations, list) and generations:
            first_group = generations[0]
            if isinstance(first_group, list) and first_group:
                output_text = getattr(first_group[0], "text", None) or str(first_group[0])
        latency = None
        for entry in reversed(run["llm_calls"]):
            if isinstance(entry, dict) and entry.get("event") == "llm_start":
                st = entry.get("start_time")
                if isinstance(st, (int, float)):
                    latency = now - st
                break
        run["llm_calls"].append(
            _jsonify(
                {
                    "event": "llm_end",
                    "response": output_text if output_text is not None else str(response),
                    "token_usage": token_usage,
                    "latency": latency,
                    "timestamp": _now_iso(),
                }
            )
        )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        run["llm_calls"].append(
            _jsonify(
                {
                    "event": "llm_error",
                    "error": str(error),
                    "timestamp": _now_iso(),
                }
            )
        )

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        tool_name = (
            serialized.get("name")
            or serialized.get("id")
            or kwargs.get("name")
            or "tool"
        )
        run["tool_calls"].append(
            _jsonify(
                {
                    "from": "agent",
                    "tool": tool_name,
                    "input": input_str,
                    "timestamp": _now_iso(),
                    "start_time": time.time(),
                }
            )
        )

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        for call in reversed(run["tool_calls"]):
            if isinstance(call, dict) and "output" not in call:
                call["output"] = output
                st = call.get("start_time")
                if isinstance(st, (int, float)):
                    call["latency"] = time.time() - st
                break

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        for call in reversed(run["tool_calls"]):
            if isinstance(call, dict) and "output" not in call and "error" not in call:
                call["error"] = str(error)
                st = call.get("start_time")
                if isinstance(st, (int, float)):
                    call["latency"] = time.time() - st
                break

    def on_agent_action(
        self,
        action: AgentAction,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        tool = getattr(action, "tool", "unknown_tool")
        tool_input = getattr(action, "tool_input", None)
        log = getattr(action, "log", str(action))
        run["agent_actions"].append(
            _jsonify(
                {
                    "tool": tool,
                    "tool_input": tool_input,
                    "log": log,
                    "timestamp": _now_iso(),
                }
            )
        )
        run["belief_state"] = {
            "latest_reasoning": log,
            "latest_tool": tool,
        }

    def on_agent_finish(
        self,
        finish: AgentFinish,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        run = self._ensure_run(run_id, kwargs.get("parent_run_id"))
        run["agent_finish"] = _jsonify(
            {
                "return_values": getattr(finish, "return_values", {}),
                "log": getattr(finish, "log", str(finish)),
            }
        )

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        root_rid = self._root_rid(run_id, kwargs.get("parent_run_id"))
        run = self._runs.pop(root_rid, None)
        if not run:
            return

        delegation_chain = [
            {
                "from": call.get("from", "agent"),
                "to": call.get("tool", "tool"),
                "authorization": "tool_call",
                "input": call.get("input"),
                "output": call.get("output"),
                "timestamp": call.get("timestamp", _now_iso()),
            }
            for call in run["tool_calls"]
            if isinstance(call, dict)
        ]
        reasoning = [
            str(a.get("log"))
            for a in run["agent_actions"]
            if isinstance(a, dict) and a.get("log") is not None
        ]
        tools_considered = sorted(
            {
                str(a.get("tool"))
                for a in run["agent_actions"]
                if isinstance(a, dict) and a.get("tool") is not None
            }
        )
        belief_state = {
            "reasoning": reasoning,
            "tools_considered": tools_considered,
            "final_reasoning": reasoning[-1] if reasoning else None,
        }
        context_snapshot = {
            "beliefState": belief_state,
            "policyVersion": run.get("policy"),
            "systemPrompt": run.get("system_prompt"),
            "llmCalls": run.get("llm_calls", []),
            "availableInformation": {
                "inputs": run.get("inputs", {}),
                "outputs": outputs,
                "agentFinish": run.get("agent_finish"),
            },
        }
        payload = {
            "agentName": run.get("agent", self.agent_name),
            "action": "agent_completion",
            "contextSnapshot": context_snapshot,
            "delegationChain": delegation_chain,
            "outcome": str(outputs),
            "latency": float(time.time() - float(run.get("start_time", time.time()))),
            "timestamp": _now_iso(),
        }
        self.tracer._ship(payload)
        self._cleanup_parent_links(root_rid)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: Union[UUID, str],
        **kwargs: Any,
    ) -> None:
        root_rid = self._root_rid(run_id, kwargs.get("parent_run_id"))
        run = self._runs.pop(root_rid, None)
        if not run:
            return
        context_snapshot = {
            "beliefState": {
                "failed": True,
                "error": str(error),
            },
            "policyVersion": run.get("policy"),
            "systemPrompt": run.get("system_prompt"),
            "llmCalls": run.get("llm_calls", []),
            "availableInformation": {
                "inputs": run.get("inputs", {}),
                "agentFinish": run.get("agent_finish"),
            },
        }
        payload = {
            "agentName": run.get("agent", self.agent_name),
            "action": "agent_completion",
            "contextSnapshot": context_snapshot,
            "delegationChain": [],
            "outcome": f"ERROR: {str(error)}",
            "latency": float(time.time() - float(run.get("start_time", time.time()))),
            "timestamp": _now_iso(),
        }
        self.tracer._ship(payload)
        self._cleanup_parent_links(root_rid)

    def _cleanup_parent_links(self, root_rid: str) -> None:
        dead = [rid for rid, root in self._parents.items() if root == root_rid or rid == root_rid]
        for rid in dead:
            self._parents.pop(rid, None)
