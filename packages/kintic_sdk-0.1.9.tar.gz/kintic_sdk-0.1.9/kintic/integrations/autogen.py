"""
AutoGen integration for Kintic decision ingest.

Supports:
  - **autogen-agentchat** (0.4+): observe ``team.run_stream()`` / agent streams and ship one
    decision per completed run (``TaskResult``).
  - **Legacy autogen / AG2** (0.2-style): attach reply observers on ``ConversableAgent`` and
    call ``finish()`` when the group chat completes.

Install extras::

    pip install "kintic-sdk[autogen]"        # autogen-agentchat
    pip install "kintic-sdk[autogen-legacy]" # ag2 / pyautogen (optional)
"""

from __future__ import annotations

import time
from typing import Any, AsyncIterator, Dict, List, Optional, Sequence, Union

from kintic.tracer import KinticTracer, _jsonify

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _type_name(obj: Any) -> str:
    return type(obj).__name__


def _is_task_result(obj: Any) -> bool:
    if obj is None:
        return False
    if _type_name(obj) == "TaskResult":
        return True
    return hasattr(obj, "messages") and hasattr(obj, "stop_reason")


def _safe_text(obj: Any, limit: int = 8_000) -> str:
    if obj is None:
        return ""
    if hasattr(obj, "to_text"):
        try:
            return str(obj.to_text())[:limit]
        except Exception:
            pass
    if hasattr(obj, "content"):
        content = getattr(obj, "content", None)
        if isinstance(content, str):
            return content[:limit]
        return str(_jsonify(content))[:limit]
    return str(obj)[:limit]


def _usage_dict(obj: Any) -> Optional[Dict[str, Any]]:
    usage = getattr(obj, "models_usage", None)
    if usage is None:
        return None
    if hasattr(usage, "model_dump"):
        try:
            return usage.model_dump(mode="json")
        except Exception:
            pass
    if isinstance(usage, dict):
        return _jsonify(usage)
    prompt = getattr(usage, "prompt_tokens", None)
    completion = getattr(usage, "completion_tokens", None)
    if prompt is not None or completion is not None:
        return {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
        }
    return {"raw": str(usage)}


def _message_record(msg: Any) -> Dict[str, Any]:
    rec: Dict[str, Any] = {"type": _type_name(msg)}
    source = getattr(msg, "source", None)
    if source is not None:
        rec["source"] = str(source)
    text = _safe_text(msg)
    if text:
        rec["text"] = text
    usage = _usage_dict(msg)
    if usage:
        rec["usage"] = usage
    meta = getattr(msg, "metadata", None)
    if isinstance(meta, dict) and meta:
        rec["metadata"] = _jsonify(meta)
    return rec


def _build_delegation_chain(sources: List[str]) -> List[Dict[str, Any]]:
    ts = _now_iso()
    chain: List[Dict[str, Any]] = []
    for i in range(1, len(sources)):
        chain.append(
            {
                "from": sources[i - 1],
                "to": sources[i],
                "authorization": "autogen_handoff",
                "timestamp": ts,
            }
        )
    return chain


def _extract_outcome(task_result: Any, message_records: List[Dict[str, Any]]) -> str:
    if task_result is not None:
        stop = getattr(task_result, "stop_reason", None)
        if stop:
            return f"completed:{stop}"
    for rec in reversed(message_records):
        if rec.get("type") in ("TextMessage", "ToolCallSummaryMessage"):
            text = rec.get("text") or rec.get("content")
            if text:
                return str(text)[:20_000]
    if message_records:
        return str(message_records[-1].get("text", "completed"))[:20_000]
    return "completed"


# ---------------------------------------------------------------------------
# autogen-agentchat (modern)
# ---------------------------------------------------------------------------


class KinticAutoGenObserver:
    """
    Collects messages from an AutoGen AgentChat stream and ships one Kintic decision
    when a ``TaskResult`` arrives.
    """

    def __init__(
        self,
        tracer: KinticTracer,
        *,
        agent: str,
        policy: Optional[str] = None,
        action: str = "autogen_team_run",
        task: Optional[str] = None,
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self.action = action
        self.task = task
        self._started = time.time()
        self._message_records: List[Dict[str, Any]] = []
        self._tool_events: List[Dict[str, Any]] = []
        self._llm_calls: List[Dict[str, Any]] = []
        self._sources: List[str] = []
        self._task_result: Any = None
        self._token_prompt = 0
        self._token_completion = 0

    def ingest(self, item: Any) -> None:
        if _is_task_result(item):
            self._task_result = item
            for msg in getattr(item, "messages", []) or []:
                self._ingest_message(msg)
            return

        self._ingest_message(item)

    def _ingest_message(self, msg: Any) -> None:
        if msg is None:
            return
        rec = _message_record(msg)
        self._message_records.append(rec)
        source = rec.get("source")
        if source and (not self._sources or self._sources[-1] != source):
            self._sources.append(str(source))

        tn = rec.get("type", "")
        if "ToolCall" in tn:
            self._tool_events.append(rec)
        usage = rec.get("usage")
        if usage:
            pt = int(usage.get("prompt_tokens") or 0)
            ct = int(usage.get("completion_tokens") or 0)
            self._token_prompt += pt
            self._token_completion += ct
            self._llm_calls.append(
                {
                    "event": "autogen_llm_turn",
                    "source": source,
                    "model_usage": usage,
                    "text_preview": (rec.get("text") or "")[:2_000],
                    "timestamp": _now_iso(),
                }
            )

    def build_context_snapshot(self) -> Dict[str, Any]:
        stop_reason = None
        if self._task_result is not None:
            stop_reason = getattr(self._task_result, "stop_reason", None)

        belief: Dict[str, Any] = {
            "participant_sources": list(self._sources),
            "stop_reason": stop_reason,
            "message_count": len(self._message_records),
        }
        if self._message_records:
            belief["last_message_preview"] = (self._message_records[-1].get("text") or "")[:2_000]

        snap: Dict[str, Any] = {
            "args": [],
            "kwargs": {"task": self.task} if self.task else {},
            "beliefState": belief,
            "availableInformation": {
                "messages": self._message_records[-40:],
                "tool_events": self._tool_events[-20:],
            },
            "autogenContext": {
                "framework": "autogen_agentchat",
                "task": self.task,
                "stop_reason": stop_reason,
                "token_usage": {
                    "prompt_tokens": self._token_prompt,
                    "completion_tokens": self._token_completion,
                },
            },
        }
        if self.policy:
            snap["policyVersion"] = self.policy
        if self._llm_calls:
            snap["llmCalls"] = self._llm_calls
        return snap

    def ship(self) -> None:
        latency_ms = (time.time() - self._started) * 1000.0
        outcome = _extract_outcome(self._task_result, self._message_records)
        delegation = _build_delegation_chain(self._sources)
        self.tracer.record_decision(
            agent=self.agent_name,
            action=self.action,
            context_snapshot=self.build_context_snapshot(),
            outcome=outcome,
            latency_ms=latency_ms,
            delegation_chain=delegation if delegation else None,
        )

    @property
    def task_result(self) -> Any:
        return self._task_result


class ObservedAutoGenStream:
    """
    Async iterator wrapper: yields the same events as AutoGen, ships one Kintic
    decision when the stream ends. Read :attr:`task_result` after iteration.
    """

    def __init__(
        self,
        tracer: KinticTracer,
        stream: AsyncIterator[Any],
        *,
        agent: str,
        policy: Optional[str] = None,
        action: str = "autogen_team_run",
        task: Optional[str] = None,
        echo: bool = False,
    ) -> None:
        self._stream = stream
        self._echo = echo
        self._observer = KinticAutoGenObserver(
            tracer,
            agent=agent,
            policy=policy,
            action=action,
            task=task,
        )
        self._shipped = False

    def __aiter__(self) -> ObservedAutoGenStream:
        return self

    async def __anext__(self) -> Any:
        try:
            item = await self._stream.__anext__()
        except StopAsyncIteration:
            if not self._shipped:
                self._observer.ship()
                self._shipped = True
            raise
        self._observer.ingest(item)
        if self._echo:
            text = _safe_text(item, limit=4_000)
            if text:
                print(text)
            elif _is_task_result(item):
                print(
                    f"[kintic] TaskResult stop_reason="
                    f"{getattr(item, 'stop_reason', None)}"
                )
        return item

    @property
    def task_result(self) -> Any:
        return self._observer.task_result

    @property
    def observer(self) -> KinticAutoGenObserver:
        return self._observer


def observe_team_stream(
    tracer: KinticTracer,
    stream: AsyncIterator[Any],
    *,
    agent: str,
    policy: Optional[str] = None,
    action: str = "autogen_team_run",
    task: Optional[str] = None,
    echo: bool = False,
) -> ObservedAutoGenStream:
    """
    Wrap ``team.run_stream(...)``. Example::

        wrapped = observe_team_stream(
            tracer,
            team.run_stream(task="Approve refund for order 42"),
            agent="refund-team",
            policy="v1",
            task="Approve refund for order 42",
        )
        async for event in wrapped:
            ...
        result = wrapped.task_result
    """
    return ObservedAutoGenStream(
        tracer,
        stream,
        agent=agent,
        policy=policy,
        action=action,
        task=task,
        echo=echo,
    )


async def run_observed_team(
    team: Any,
    *,
    tracer: KinticTracer,
    task: Union[str, None] = None,
    agent: str,
    policy: Optional[str] = None,
    action: str = "autogen_team_run",
    echo: bool = False,
) -> Any:
    """
    Run ``team.run_stream(task=...)``, observe all events, ship one decision, return
  ``TaskResult``.
    """
    if not hasattr(team, "run_stream"):
        raise TypeError("team must provide run_stream(task=...) (autogen-agentchat team)")

    observer = KinticAutoGenObserver(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
        task=task if isinstance(task, str) else None,
    )
    stream = team.run_stream(task=task)
    async for item in stream:
        observer.ingest(item)
        if echo:
            text = _safe_text(item, limit=4_000)
            if text:
                print(text)
    observer.ship()
    return observer.task_result


# ---------------------------------------------------------------------------
# Legacy autogen / AG2 (ConversableAgent)
# ---------------------------------------------------------------------------


def _import_legacy_autogen() -> Any:
    for mod_name in ("autogen", "ag2", "pyautogen"):
        try:
            return __import__(mod_name)
        except ImportError:
            continue
    raise ImportError(
        "Legacy AutoGen not installed. Use: pip install ag2  (or pyautogen), "
        "or prefer autogen-agentchat with run_observed_team()."
    )


class LegacyAutoGenCollector:
    """Accumulates legacy group-chat messages; call :meth:`finish` to ship."""

    def __init__(
        self,
        tracer: KinticTracer,
        *,
        agent: str,
        policy: Optional[str] = None,
        action: str = "autogen_group_chat",
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self.action = action
        self._started = time.time()
        self._turns: List[Dict[str, Any]] = []

    def record_turn(
        self,
        *,
        recipient: str,
        sender: str,
        content: Any,
    ) -> None:
        self._turns.append(
            _jsonify(
                {
                    "recipient": recipient,
                    "sender": sender,
                    "content": _safe_text(content) if not isinstance(content, dict) else content,
                    "timestamp": _now_iso(),
                }
            )
        )

    def finish(
        self,
        *,
        outcome: str,
        summary: Optional[str] = None,
        cost_impact: Optional[float] = None,
    ) -> None:
        latency_ms = (time.time() - self._started) * 1000.0
        sources: List[str] = []
        for t in self._turns:
            s = str(t.get("sender", ""))
            if s and (not sources or sources[-1] != s):
                sources.append(s)
        delegation = _build_delegation_chain(sources)
        snap: Dict[str, Any] = {
            "args": [],
            "kwargs": {},
            "beliefState": {
                "turn_count": len(self._turns),
                "summary": summary,
            },
            "availableInformation": {"turns": self._turns[-50:]},
            "autogenContext": {
                "framework": "autogen_legacy",
                "summary": summary,
            },
        }
        if self.policy:
            snap["policyVersion"] = self.policy
        self.tracer.record_decision(
            agent=self.agent_name,
            action=self.action,
            context_snapshot=snap,
            outcome=outcome[:20_000],
            latency_ms=latency_ms,
            delegation_chain=delegation if delegation else None,
            cost_impact=cost_impact,
        )


def attach_legacy_observers(
    collector: LegacyAutoGenCollector,
    agents: Sequence[Any],
) -> LegacyAutoGenCollector:
    """
    Register non-blocking reply hooks on legacy ``ConversableAgent`` instances.
    Call :meth:`LegacyAutoGenCollector.finish` after ``initiate_chat`` completes.
    """
    mod = _import_legacy_autogen()
    agent_types: List[Any] = []
    for attr in ("Agent", "ConversableAgent"):
        if hasattr(mod, attr):
            agent_types.append(getattr(mod, attr))
    if not agent_types:
        agent_types = [object]  # type: ignore[list-item]

    def _make_reply(agent_obj: Any):
        def _reply(
            recipient: Any,
            messages: Optional[List[Dict[str, Any]]],
            sender: Any,
            config: Any,
        ):
            try:
                last = (messages or [])[-1] if messages else {}
                content = last.get("content", last) if isinstance(last, dict) else last
                collector.record_turn(
                    recipient=str(getattr(recipient, "name", recipient)),
                    sender=str(getattr(sender, "name", sender)),
                    content=content,
                )
            except Exception:
                pass
            return False, None

        return _reply

    for ag in agents:
        if not hasattr(ag, "register_reply"):
            raise TypeError(
                f"{ag!r} has no register_reply; expected legacy ConversableAgent"
            )
        ag.register_reply(
            agent_types + [None],
            reply_func=_make_reply(ag),
            config={"kintic": True},
        )
    return collector


def ship_legacy_chat_history(
    tracer: KinticTracer,
    *,
    agent: str,
    chat_history: Sequence[Any],
    outcome: str,
    policy: Optional[str] = None,
    action: str = "autogen_group_chat",
    latency_ms: Optional[float] = None,
    cost_impact: Optional[float] = None,
) -> None:
    """
    One-shot ingest from a completed legacy ``chat_history`` list (no hooks).
    """
    started = time.time()
    records: List[Dict[str, Any]] = []
    sources: List[str] = []
    for entry in chat_history:
        if isinstance(entry, dict):
            role = str(entry.get("role") or entry.get("name") or "unknown")
            content = entry.get("content", entry)
            records.append({"role": role, "text": _safe_text(content)})
            if role and (not sources or sources[-1] != role):
                sources.append(role)
        else:
            records.append({"text": _safe_text(entry)})

    snap: Dict[str, Any] = {
        "args": [],
        "kwargs": {},
        "beliefState": {"message_count": len(records)},
        "availableInformation": {"chat_history": records[-50:]},
        "autogenContext": {"framework": "autogen_legacy", "mode": "history_import"},
    }
    if policy:
        snap["policyVersion"] = policy

    ms = latency_ms if latency_ms is not None else (time.time() - started) * 1000.0
    tracer.record_decision(
        agent=agent,
        action=action,
        context_snapshot=snap,
        outcome=outcome[:20_000],
        latency_ms=ms,
        delegation_chain=_build_delegation_chain(sources) or None,
        cost_impact=cost_impact,
    )
