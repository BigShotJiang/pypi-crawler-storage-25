"""
CrewAI integration for Kintic decision ingest.

Uses CrewAI's official event bus (``BaseEventListener``) to record one Kintic
decision per crew ``kickoff`` with agent handoffs, tool usage, and LLM calls.

Install::

    pip install "kintic-sdk[crewai]"
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List, Optional, Union

from kintic.tracer import KinticTracer, _jsonify


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _event_name(event: Any) -> str:
    return type(event).__name__


def _safe_text(value: Any, limit: int = 8_000) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value[:limit]
    return str(_jsonify(value))[:limit]


def _event_record(event: Any) -> Dict[str, Any]:
    rec: Dict[str, Any] = {"type": _event_name(event)}
    for key in (
        "crew_name",
        "task_id",
        "agent_id",
        "tool_name",
        "tool_input",
        "output",
        "result",
        "error",
        "error_message",
        "message",
        "inputs",
    ):
        if hasattr(event, key):
            val = getattr(event, key)
            if val is not None:
                rec[key] = _jsonify(val) if not isinstance(val, str) else val[:8_000]
    agent = getattr(event, "agent", None)
    if agent is not None:
        role = getattr(agent, "role", None)
        if role:
            rec["agent_role"] = str(role)
    return rec


def _build_delegation_chain(roles: List[str]) -> List[Dict[str, Any]]:
    ts = _now_iso()
    chain: List[Dict[str, Any]] = []
    for i in range(1, len(roles)):
        chain.append(
            {
                "from": roles[i - 1],
                "to": roles[i],
                "authorization": "crewai_task_handoff",
                "timestamp": ts,
            }
        )
    return chain


def _import_crewai_events():
    try:
        from crewai.events import (  # type: ignore
            AgentExecutionCompletedEvent,
            AgentExecutionErrorEvent,
            BaseEventListener,
            CrewKickoffCompletedEvent,
            CrewKickoffFailedEvent,
            CrewKickoffStartedEvent,
            LLMCallCompletedEvent,
            TaskCompletedEvent,
            ToolUsageFinishedEvent,
        )
    except ImportError as exc:
        raise ImportError(
            'CrewAI is not installed. Use: pip install "kintic-sdk[crewai]"'
        ) from exc
    return {
        "BaseEventListener": BaseEventListener,
        "CrewKickoffStartedEvent": CrewKickoffStartedEvent,
        "CrewKickoffCompletedEvent": CrewKickoffCompletedEvent,
        "CrewKickoffFailedEvent": CrewKickoffFailedEvent,
        "AgentExecutionCompletedEvent": AgentExecutionCompletedEvent,
        "AgentExecutionErrorEvent": AgentExecutionErrorEvent,
        "TaskCompletedEvent": TaskCompletedEvent,
        "ToolUsageFinishedEvent": ToolUsageFinishedEvent,
        "LLMCallCompletedEvent": LLMCallCompletedEvent,
    }


class KinticCrewAIRunCollector:
    """Accumulates CrewAI bus events; ships one ingest decision per kickoff."""

    def __init__(
        self,
        tracer: KinticTracer,
        *,
        agent: str,
        policy: Optional[str] = None,
        action: str = "crewai_kickoff",
        inputs: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.tracer = tracer
        self.agent_name = agent
        self.policy = policy
        self.action = action
        self.inputs = inputs
        self._started = time.time()
        self._shipped = False
        self.crew_name: Optional[str] = None
        self._agent_roles: List[str] = []
        self._agent_runs: List[Dict[str, Any]] = []
        self._task_events: List[Dict[str, Any]] = []
        self._tool_events: List[Dict[str, Any]] = []
        self._llm_calls: List[Dict[str, Any]] = []
        self._raw_events: List[Dict[str, Any]] = []
        self._final_output: Any = None
        self._error: Optional[str] = None

    @property
    def shipped(self) -> bool:
        return self._shipped

    def _track_agent_role(self, role: Optional[str]) -> None:
        if not role:
            return
        r = str(role)
        if not self._agent_roles or self._agent_roles[-1] != r:
            self._agent_roles.append(r)

    def on_kickoff_started(self, event: Any) -> None:
        self._started = time.time()
        self._shipped = False
        self.crew_name = getattr(event, "crew_name", None) or self.crew_name
        self._raw_events.append(_event_record(event))

    def on_kickoff_completed(self, event: Any) -> None:
        self._final_output = getattr(event, "output", None)
        self.crew_name = getattr(event, "crew_name", None) or self.crew_name
        self._raw_events.append(_event_record(event))
        self._ship_success()

    def on_kickoff_failed(self, event: Any) -> None:
        err = getattr(event, "error", None) or getattr(event, "error_message", None)
        self._error = _safe_text(err, 4_000) if err else "crew_kickoff_failed"
        self._raw_events.append(_event_record(event))
        self._ship_error(self._error)

    def on_agent_completed(self, event: Any) -> None:
        rec = _event_record(event)
        self._agent_runs.append(rec)
        self._track_agent_role(rec.get("agent_role"))
        self._raw_events.append(rec)

    def on_agent_error(self, event: Any) -> None:
        rec = _event_record(event)
        rec["failed"] = True
        self._agent_runs.append(rec)
        self._track_agent_role(rec.get("agent_role"))
        self._raw_events.append(rec)

    def on_task_completed(self, event: Any) -> None:
        rec = _event_record(event)
        self._task_events.append(rec)
        self._raw_events.append(rec)

    def on_tool_finished(self, event: Any) -> None:
        rec = _event_record(event)
        self._tool_events.append(rec)
        self._raw_events.append(rec)
        role = rec.get("agent_role")
        tool = rec.get("tool_name") or "tool"
        if role:
            self._track_agent_role(str(role))

    def on_llm_completed(self, event: Any) -> None:
        rec = _event_record(event)
        usage = None
        for attr in ("token_usage", "usage", "models_usage"):
            raw = getattr(event, attr, None)
            if raw is not None:
                usage = _jsonify(raw) if not isinstance(raw, dict) else raw
                break
        if usage:
            rec["usage"] = usage
        self._llm_calls.append(
            {
                "event": "crewai_llm_call",
                "record": rec,
                "timestamp": _now_iso(),
            }
        )
        self._raw_events.append(rec)

    def build_context_snapshot(self) -> Dict[str, Any]:
        belief: Dict[str, Any] = {
            "crew_name": self.crew_name,
            "agent_roles": list(self._agent_roles),
            "agent_run_count": len(self._agent_runs),
            "task_count": len(self._task_events),
            "tool_count": len(self._tool_events),
        }
        if self._error:
            belief["failed"] = True
            belief["error"] = self._error

        snap: Dict[str, Any] = {
            "args": [],
            "kwargs": {"inputs": self.inputs} if self.inputs else {},
            "beliefState": belief,
            "availableInformation": {
                "agent_runs": self._agent_runs[-30:],
                "tasks": self._task_events[-30:],
                "tools": self._tool_events[-30:],
                "events": self._raw_events[-50:],
            },
            "crewaiContext": {
                "framework": "crewai",
                "crew_name": self.crew_name,
                "inputs": _jsonify(self.inputs) if self.inputs else None,
            },
        }
        if self.policy:
            snap["policyVersion"] = self.policy
        if self._llm_calls:
            snap["llmCalls"] = self._llm_calls
        return snap

    def _ship(self, *, outcome: str) -> None:
        if self._shipped:
            return
        self._shipped = True
        latency_ms = (time.time() - self._started) * 1000.0
        delegation = _build_delegation_chain(self._agent_roles)
        self.tracer.record_decision(
            agent=self.agent_name,
            action=self.action,
            context_snapshot=self.build_context_snapshot(),
            outcome=outcome[:20_000],
            latency_ms=latency_ms,
            delegation_chain=delegation if delegation else None,
        )

    def _ship_success(self) -> None:
        out = self._final_output
        outcome = _safe_text(out, 20_000) if out is not None else "completed"
        self._ship(outcome=outcome)

    def _ship_error(self, message: str) -> None:
        self._ship(outcome=f"ERROR: {message}"[:20_000])

    def finish_from_return_value(self, result: Any) -> None:
        """Fallback when kickoff returns but completed event did not ship."""
        if self._shipped:
            return
        self._final_output = result
        self._ship_success()


class KinticCrewAIListener:
    """
    CrewAI ``BaseEventListener`` that forwards bus events to a
    :class:`KinticCrewAIRunCollector`.

    Keep a reference to the listener instance for the lifetime of your crew module
    (CrewAI docs requirement).
    """

    def __init__(self, collector: KinticCrewAIRunCollector) -> None:
        self.collector = collector
        events = _import_crewai_events()
        base = events["BaseEventListener"]

        class _Listener(base):  # type: ignore[misc, valid-type]
            def setup_listeners(self, crewai_event_bus):  # noqa: N802
                @crewai_event_bus.on(events["CrewKickoffStartedEvent"])
                def _on_started(source, event):
                    collector.on_kickoff_started(event)

                @crewai_event_bus.on(events["CrewKickoffCompletedEvent"])
                def _on_completed(source, event):
                    collector.on_kickoff_completed(event)

                @crewai_event_bus.on(events["CrewKickoffFailedEvent"])
                def _on_failed(source, event):
                    collector.on_kickoff_failed(event)

                @crewai_event_bus.on(events["AgentExecutionCompletedEvent"])
                def _on_agent_done(source, event):
                    collector.on_agent_completed(event)

                @crewai_event_bus.on(events["AgentExecutionErrorEvent"])
                def _on_agent_err(source, event):
                    collector.on_agent_error(event)

                @crewai_event_bus.on(events["TaskCompletedEvent"])
                def _on_task_done(source, event):
                    collector.on_task_completed(event)

                @crewai_event_bus.on(events["ToolUsageFinishedEvent"])
                def _on_tool_done(source, event):
                    collector.on_tool_finished(event)

                @crewai_event_bus.on(events["LLMCallCompletedEvent"])
                def _on_llm_done(source, event):
                    collector.on_llm_completed(event)

        self._listener = _Listener()

    @property
    def listener(self) -> Any:
        """Underlying CrewAI listener (keeps handlers registered)."""
        return self._listener


def install_crewai_listener(
    tracer: KinticTracer,
    *,
    agent: str,
    policy: Optional[str] = None,
    action: str = "crewai_kickoff",
    inputs: Optional[Dict[str, Any]] = None,
) -> KinticCrewAIListener:
    """
    Register Kintic handlers on the global CrewAI event bus.

    Instantiate once at module load (alongside your ``Crew`` definition) and keep
    the returned object in scope.
    """
    collector = KinticCrewAIRunCollector(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
        inputs=inputs,
    )
    return KinticCrewAIListener(collector)


def run_observed_crew(
    crew: Any,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    action: str = "crewai_kickoff",
    inputs: Optional[Dict[str, Any]] = None,
) -> Any:
    """
    Run ``crew.kickoff(...)`` with a temporary Kintic listener; ship one decision.

    For long-lived apps, prefer :func:`install_crewai_listener` at import time.
    """
    handle = install_crewai_listener(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
        inputs=inputs,
    )
    collector = handle.collector
    try:
        if inputs is not None:
            result = crew.kickoff(inputs=inputs)
        else:
            result = crew.kickoff()
        collector.finish_from_return_value(result)
        return result
    except Exception as exc:
        if not collector.shipped:
            collector._ship_error(str(exc))
        raise


async def run_observed_crew_async(
    crew: Any,
    *,
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
    action: str = "crewai_kickoff",
    inputs: Optional[Dict[str, Any]] = None,
) -> Any:
    """Async variant when ``crew.kickoff_async`` is available."""
    handle = install_crewai_listener(
        tracer,
        agent=agent,
        policy=policy,
        action=action,
        inputs=inputs,
    )
    collector = handle.collector
    kickoff_async = getattr(crew, "kickoff_async", None)
    if not callable(kickoff_async):
        return await asyncio.to_thread(
            run_observed_crew,
            crew,
            tracer=tracer,
            agent=agent,
            policy=policy,
            action=action,
            inputs=inputs,
        )
    try:
        if inputs is not None:
            result = await kickoff_async(inputs=inputs)
        else:
            result = await kickoff_async()
        collector.finish_from_return_value(result)
        return result
    except Exception as exc:
        if not collector.shipped:
            collector._ship_error(str(exc))
        raise
