from __future__ import annotations

import functools
import time
from typing import Any, Optional

from kintic.integrations._llm_chat import (
    cohere_v1_response_text,
    cohere_v2_response_text,
    extract_system_and_conversation,
    ship_chat_decision,
    ship_chat_error,
)
from kintic.tracer import KinticTracer


def _patch_cohere_v2(tracer: KinticTracer, agent: str, policy: Optional[str]) -> bool:
    try:
        from cohere.v2.client import V2Client  # type: ignore
    except ImportError:
        return False

    original = V2Client.chat
    if getattr(original, "_kintic_patched", False):
        return True

    @functools.wraps(original)
    def patched_chat(self_client: Any, *args: Any, **kwargs: Any) -> Any:
        start = time.time()
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        system_prompt, conversation = extract_system_and_conversation(messages)
        try:
            response = original(self_client, *args, **kwargs)
            latency = time.time() - start
            output_text = cohere_v2_response_text(response)
            ship_chat_decision(
                tracer,
                agent=agent,
                policy=policy,
                model=model,
                messages=messages,
                kwargs=kwargs,
                output_text=output_text,
                latency=latency,
                system_prompt=system_prompt,
                conversation=conversation,
            )
            return response
        except Exception as e:
            ship_chat_error(
                tracer,
                agent=agent,
                system_prompt=system_prompt,
                error=e,
                latency=time.time() - start,
            )
            raise

    setattr(patched_chat, "_kintic_patched", True)
    V2Client.chat = patched_chat
    return True


def _patch_cohere_v1(tracer: KinticTracer, agent: str, policy: Optional[str]) -> bool:
    try:
        from cohere.base_client import BaseCohere  # type: ignore
    except ImportError:
        return False

    original = BaseCohere.chat
    if getattr(original, "_kintic_patched", False):
        return True

    @functools.wraps(original)
    def patched_chat(self_client: Any, *args: Any, **kwargs: Any) -> Any:
        start = time.time()
        message = kwargs.get("message", "")
        preamble = kwargs.get("preamble")
        chat_history = kwargs.get("chat_history") or []
        model = kwargs.get("model", "unknown")
        messages = list(chat_history) if isinstance(chat_history, list) else []
        if message:
            messages = [*messages, {"role": "user", "content": message}]
        system_prompt = preamble if isinstance(preamble, str) else None
        try:
            response = original(self_client, *args, **kwargs)
            latency = time.time() - start
            output_text = cohere_v1_response_text(response)
            ship_chat_decision(
                tracer,
                agent=agent,
                policy=policy,
                model=model,
                messages=messages,
                kwargs=kwargs,
                output_text=output_text,
                latency=latency,
                system_prompt=system_prompt,
                conversation=messages,
            )
            return response
        except Exception as e:
            ship_chat_error(
                tracer,
                agent=agent,
                system_prompt=system_prompt,
                error=e,
                latency=time.time() - start,
            )
            raise

    setattr(patched_chat, "_kintic_patched", True)
    BaseCohere.chat = patched_chat
    return True


def patch_cohere(
    tracer: KinticTracer,
    agent: str,
    policy: Optional[str] = None,
) -> None:
    try:
        import cohere  # type: ignore  # noqa: F401
    except ImportError:
        if tracer.debug:
            print("[Kintic] Cohere not installed, skipping patch")
        return

    v2_ok = _patch_cohere_v2(tracer, agent, policy)
    v1_ok = _patch_cohere_v1(tracer, agent, policy)
    if not v2_ok and not v1_ok and tracer.debug:
        print("[Kintic] Cohere chat() target not found, skipping patch")
    elif tracer.debug and (v2_ok or v1_ok):
        print("[Kintic] Cohere patched successfully")
