"""
Redact sensitive values from ingest context payloads before ship.

Keeps structured keys intact; recursively redacts nested dict/list values when
keys look like secrets, credentials, tokens, etc.
"""

from __future__ import annotations

import copy
import re
from typing import Any

# Keys containing these fragments (case-insensitive) redact scalar / leaf values.
_DEFAULT_SENSITIVE_FRAGMENTS = (
    "password",
    "passwd",
    "secret",
    "token",
    "authorization",
    "bearer",
    "cookie",
    "api_key",
    "apikey",
    "api-key",
    "private_key",
    "privatekey",
    "ssh_key",
    "creditcard",
    "credit_card",
    "ssn",
    "social_security",
)

# Optional: common high-entropy bearer-like strings on values (whole string only).
_BEARER_RE = re.compile(r"^(Bearer|Basic)\s+.+$", re.I)

MAX_STRING_CHARS = 20_000
MAX_DEPTH = 24


def _key_sensitive(key: str) -> bool:
    k = key.lower().replace("-", "_")
    return any(f in k for f in _DEFAULT_SENSITIVE_FRAGMENTS)


def redact_value(value: Any, depth: int) -> Any:
    if depth > MAX_DEPTH:
        return "[DEPTH_LIMIT]"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        s = value
        if len(s) > MAX_STRING_CHARS:
            s = s[:MAX_STRING_CHARS] + "…"
        if _BEARER_RE.match(s.strip()):
            return "[REDACTED_AUTH_HEADER]"
        return s
    if isinstance(value, dict):
        return redact_mapping(value, depth + 1)
    if isinstance(value, (list, tuple)):
        return [redact_value(v, depth + 1) for v in value]
    return value


def redact_mapping(mapping: dict[str, Any], depth: int = 0) -> dict[str, Any]:
    if depth > MAX_DEPTH:
        return {"_truncated": "[DEPTH_LIMIT]"}

    out: dict[str, Any] = {}
    for raw_k, raw_v in mapping.items():
        k = str(raw_k)
        if _key_sensitive(k):
            if isinstance(raw_v, dict):
                out[k] = {"_redacted": True, "_nested": "[REDACTED_NESTED]"}
            elif isinstance(raw_v, (list, tuple)):
                out[k] = "[REDACTED_LIST]"
            else:
                out[k] = "[REDACTED]"
            continue
        out[k] = redact_value(raw_v, depth)
    return out


def sanitize_context_snapshot(snap: dict[str, Any]) -> dict[str, Any]:
    """
    Deep-copy and redact a contextSnapshot-shaped dict suitable for ingest.

    Applies full recursive redaction to args, kwargs, beliefState,
    availableInformation, promptContext (string length cap), langchainContext, llmCalls, callStack, traceback.

    For structural keys deployment / codeLocation / correlationIds:
    treats them as mappings and redacts only sensitive-named child keys / values still pass through truncation.
    """
    out = copy.deepcopy(snap)

    heavy_keys = (
        "args",
        "kwargs",
        "beliefState",
        "availableInformation",
        "langchainContext",
        "autogenContext",
        "crewaiContext",
        "llamaIndexContext",
        "adkContext",
        "llmCalls",
        "callStack",
        "promptContext",
    )
    for key in heavy_keys:
        if key not in out:
            continue
        val = out[key]
        if key == "promptContext" and isinstance(val, str):
            if len(val) > MAX_STRING_CHARS:
                out[key] = val[:MAX_STRING_CHARS] + "…"
            continue
        if isinstance(val, dict):
            out[key] = redact_mapping(val, 0)
        elif isinstance(val, list):
            out[key] = redact_value(val, 0)
        elif isinstance(val, tuple):
            out[key] = redact_value(list(val), 0)

    for sk in ("deployment", "codeLocation", "correlationIds"):
        if sk in out and isinstance(out[sk], dict):
            cleaned: dict[str, Any] = {}
            for kk, vv in out[sk].items():
                if _key_sensitive(str(kk)):
                    cleaned[kk] = "[REDACTED]"
                    continue
                if isinstance(vv, str):
                    if len(vv) > MAX_STRING_CHARS:
                        cleaned[kk] = vv[:MAX_STRING_CHARS] + "…"
                    else:
                        cleaned[kk] = vv
                    continue
                if isinstance(vv, dict):
                    cleaned[kk] = redact_mapping(vv, 0)
                    continue
                cleaned[kk] = redact_value(vv, 0)
            out[sk] = cleaned

    if "traceback" in out and isinstance(out["traceback"], str) and len(out["traceback"]) > MAX_STRING_CHARS:
        out["traceback"] = out["traceback"][:MAX_STRING_CHARS] + "…"

    return out
