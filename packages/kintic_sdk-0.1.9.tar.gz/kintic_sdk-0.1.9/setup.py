from pathlib import Path

from setuptools import find_packages, setup

_README = Path(__file__).parent / "README.md"

_EXTRAS = {
    "autogen": ["autogen-agentchat>=0.4.0"],
    "autogen-legacy": ["ag2>=0.2.0"],
    "crewai": ["crewai>=0.80.0"],
    "llamaindex": ["llama-index-core>=0.11.0"],
    "google-adk": ["google-adk>=0.1.0"],
    "gemini": ["google-genai>=1.0.0"],
    "gemini-legacy": ["google-generativeai>=0.8.0"],
    "groq": ["groq>=0.9.0"],
    "mistral": ["mistralai>=1.0.0"],
    "cohere": ["cohere>=5.0.0"],
    "langgraph": ["langgraph>=0.2.0", "langchain-core>=0.3.0"],
    "langchain": ["langchain-core>=0.3.0"],
}

# One command for teams that want every integration (large install; may take a minute).
_EXTRAS["all"] = sorted(
    {
        *(
            dep
            for deps in _EXTRAS.values()
            for dep in deps
        ),
        "openai>=1.0.0",
        "anthropic>=0.20.0",
    }
)

setup(
    name="kintic-sdk",
    version="0.1.9",
    description="Context logging for AI agents",
    author="Kintic",
    long_description=_README.read_text(encoding="utf-8") if _README.is_file() else "",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.8",
    extras_require=_EXTRAS,
)
