"""Unit tests for publish transport-to-domain mappers."""

from __future__ import annotations

import pytest

from aimp_cli.core.errors import CliError
from aimp_cli.domain.models import CliPublishResult, PublishResponse
from aimp_cli.operations.publish.mappers import map_publish_response, map_registration_result
from aimp_cli.operations.publish.service import build_publish_success_message


def test_map_publish_response_returns_cli_publish_result() -> None:
    response = PublishResponse.model_validate(
        {
            "id": "asset-1",
            "slug": "demo-model",
            "visibility": "private",
            "readiness": {
                "is_ready": False,
                "blocking_reasons": ["publish_pricing_not_configured"],
            },
            "url": "http://localhost:3000/studio/models/demo-model",
        }
    )

    result = map_publish_response(response)

    assert isinstance(result, CliPublishResult)
    assert result.id == "asset-1"
    assert result.slug == "demo-model"
    assert result.readiness.is_ready is False
    assert result.readiness.blocking_reasons == ["publish_pricing_not_configured"]
    assert build_publish_success_message(result).startswith("Deployment successful.")


def test_map_registration_result_returns_cli_publish_result() -> None:
    result = map_registration_result(
        registration_result={
            "id": "asset-2",
            "slug": "demo-model",
            "visibility": "public",
            "readiness": {"is_ready": True, "blocking_reasons": []},
            "url": "http://localhost:3000/studio/models/demo-model",
        },
        slug="demo-model",
        version="0.1.0",
        job_id="job-1",
        request_id="req-1",
    )

    assert isinstance(result, CliPublishResult)
    assert result.id == "asset-2"
    assert result.visibility == "public"
    assert result.url == "http://localhost:3000/studio/models/demo-model"
    assert result.publish_build_group_id == "job-1"
    assert result.request_id == "req-1"


def test_map_registration_result_fails_when_terminal_fields_missing() -> None:
    with pytest.raises(CliError) as exc_info:
        map_registration_result(
            registration_result={
                "slug": "demo-model",
                "visibility": "private",
                "readiness": {"is_ready": True, "blocking_reasons": []},
            },
            slug="demo-model",
            version="0.1.0",
            job_id="job-2",
            request_id="req-2",
        )

    assert exc_info.value.code == "publish_registration_result_missing"
