"""Tests for repo-local Stage runtime state and login gateway resolution."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aimp_cli.domain.models import LOCAL_GATEWAY_URL
from aimp_cli.utils.stage_runtime_state import (
    clear_stage_runtime_state,
    discover_monorepo_root,
    is_trycloudflare_gateway_url,
    read_stage_runtime_state,
    resolve_login_gateway_url,
    stage_runtime_state_path,
    write_local_stage_runtime_state,
    write_quick_tunnel_stage_runtime_state,
)


def _touch_monorepo_layout(root: Path) -> None:
    (root / "packages" / "python" / "cli" / "pyproject.toml").parent.mkdir(parents=True, exist_ok=True)
    (root / "packages" / "python" / "framework" / "pyproject.toml").parent.mkdir(parents=True, exist_ok=True)
    (root / "packages" / "python" / "sdk" / "pyproject.toml").parent.mkdir(parents=True, exist_ok=True)
    (root / "packages" / "python" / "cli" / "pyproject.toml").write_text("[project]\nname='cli'\n", encoding="utf-8")
    (root / "packages" / "python" / "framework" / "pyproject.toml").write_text(
        "[project]\nname='fw'\n", encoding="utf-8"
    )
    (root / "packages" / "python" / "sdk" / "pyproject.toml").write_text("[project]\nname='sdk'\n", encoding="utf-8")


def test_discover_monorepo_root(tmp_path: Path) -> None:
    _touch_monorepo_layout(tmp_path)
    assert discover_monorepo_root(tmp_path / "deep" / "nest") == tmp_path.resolve()


def test_read_local_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    monkeypatch.chdir(tmp_path)
    write_local_stage_runtime_state(
        tmp_path,
        gateway_url="http://localhost:8080",
        frontend_url="http://localhost:3000",
    )
    state = read_stage_runtime_state()
    assert state is not None
    assert state.mode == "local"
    assert state.gateway_url == "http://localhost:8080"
    assert state.frontend_url == "http://localhost:3000"


def test_read_quick_tunnel_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    monkeypatch.chdir(tmp_path)
    tunnel = "https://abc-def.trycloudflare.com"
    write_quick_tunnel_stage_runtime_state(tmp_path, gateway_url=tunnel, frontend_url="https://ghi.trycloudflare.com")
    state = read_stage_runtime_state()
    assert state is not None
    assert state.mode == "quick_tunnel"
    assert state.gateway_url == tunnel
    assert state.ephemeral is True


def test_quick_tunnel_state_rejected_when_host_mismatches(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    path = stage_runtime_state_path(tmp_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "mode": "quick_tunnel",
                "gateway_url": "http://localhost:8080",
                "updated_at": "2026-01-01T00:00:00Z",
                "ephemeral": True,
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    assert read_stage_runtime_state() is None


def test_malformed_json_returns_none(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    path = stage_runtime_state_path(tmp_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("{ not json", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    assert read_stage_runtime_state() is None


def test_clear_removes_state(tmp_path: Path) -> None:
    _touch_monorepo_layout(tmp_path)
    write_local_stage_runtime_state(tmp_path)
    path = stage_runtime_state_path(tmp_path)
    assert path.is_file()
    clear_stage_runtime_state(tmp_path)
    assert not path.exists()


def test_resolve_login_precedence_runtime_over_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AIMP_GATEWAY_URL", "https://stale.example")
    write_local_stage_runtime_state(tmp_path, gateway_url="http://localhost:8080")
    assert resolve_login_gateway_url() == "http://localhost:8080"


def test_resolve_login_env_when_no_runtime(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AIMP_GATEWAY_URL", "https://via-env.example")
    assert resolve_login_gateway_url() == "https://via-env.example"


def test_resolve_login_local_when_no_state_or_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    assert resolve_login_gateway_url() == LOCAL_GATEWAY_URL


def test_resolve_login_gateway_flag_wins(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _touch_monorepo_layout(tmp_path)
    monkeypatch.chdir(tmp_path)
    write_local_stage_runtime_state(tmp_path, gateway_url="http://localhost:8080")
    assert resolve_login_gateway_url(gateway_flag=" https://explicit.example ") == "https://explicit.example"


def test_trycloudflare_url_detection() -> None:
    assert is_trycloudflare_gateway_url("https://abc.trycloudflare.com/foo")
    assert not is_trycloudflare_gateway_url("http://localhost:8080")


def test_outside_monorepo_no_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    assert discover_monorepo_root() is None
    monkeypatch.delenv("AIMP_GATEWAY_URL", raising=False)
    assert resolve_login_gateway_url() == LOCAL_GATEWAY_URL
