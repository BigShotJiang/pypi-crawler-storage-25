"""Regression tests for Gateway contract generation toolchain alignment."""

from __future__ import annotations

import ast
import importlib.metadata
import json
import tomllib
from pathlib import Path

from aimp_cli.generated.gateway_contracts import (
    CliPublishHardwareTier,
    ModelLookupResponse,
    PublishResponse,
)

REPO_ROOT = Path(__file__).resolve().parents[4]
GENERATOR_SCRIPT = (
    REPO_ROOT / "packages" / "python" / "cli" / "scripts" / "generate_gateway_contracts.py"
)
GENERATOR_REQUIREMENTS = (
    REPO_ROOT / "packages" / "python" / "cli" / "scripts" / "requirements-contract-generation.txt"
)
CLI_PYPROJECT = REPO_ROOT / "packages" / "python" / "cli" / "pyproject.toml"
CLI_CONTRACT_OPENAPI = REPO_ROOT / "gateway" / "openapi" / "cli_contract_openapi.json"


def _read_script_constants(script_path: Path) -> dict[str, str]:
    module = ast.parse(script_path.read_text(encoding="utf-8"))
    constants: dict[str, str] = {}
    for node in module.body:
        if not isinstance(node, ast.Assign):
            continue
        if len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        if not isinstance(node.value, ast.Constant):
            continue
        if not isinstance(node.value.value, str):
            continue
        constants[target.id] = node.value.value
    return constants


def _read_cli_pydantic_pin(pyproject_path: Path) -> str:
    payload = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    dependencies = payload["project"]["dependencies"]
    for dependency in dependencies:
        if dependency.startswith("pydantic=="):
            return dependency.split("==", maxsplit=1)[1]
    raise AssertionError("Expected exact pydantic pin in cli/pyproject.toml")


def _read_pinned_requirement(path: Path, package_name: str) -> str:
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(f"{package_name}=="):
            return line.split("==", maxsplit=1)[1]
    raise AssertionError(f"Expected exact {package_name} pin in {path}")


def test_generation_toolchain_pins_are_consistent() -> None:
    constants = _read_script_constants(GENERATOR_SCRIPT)
    cli_pydantic_pin = _read_cli_pydantic_pin(CLI_PYPROJECT)
    runtime_pydantic = importlib.metadata.version("pydantic")
    requirement_codegen = _read_pinned_requirement(
        GENERATOR_REQUIREMENTS, "datamodel-code-generator"
    )

    assert constants["EXPECTED_CLI_PYDANTIC_VERSION"] == cli_pydantic_pin
    assert constants["EXPECTED_CLI_PYDANTIC_VERSION"] == runtime_pydantic
    assert constants["EXPECTED_DATAMODEL_CODEGEN_VERSION"] == requirement_codegen

    assert constants["TARGET_PYDANTIC_VERSION"] == "2"
    assert runtime_pydantic.startswith("2.")


def test_generated_publish_response_validates_under_runtime_pydantic() -> None:
    payload = {
        "id": "asset-1",
        "slug": "demo-model",
        "visibility": "private",
        "readiness": {
            "is_ready": False,
            "blocking_reasons": ["publish_pricing_not_configured"],
        },
        "url": "http://localhost:3000/studio/models/demo-model",
    }
    parsed = PublishResponse.model_validate(payload)
    assert parsed.id == "asset-1"
    assert parsed.readiness is not None
    assert parsed.readiness.is_ready is False


def test_generated_model_lookup_response_validates_under_runtime_pydantic() -> None:
    payload = {
        "id": "asset-456",
        "slug": "claude",
        "name": "Claude",
        "version": "0.1.0",
        "visibility": "private",
        "release_state": "ready",
        "asset_type": "model",
        "runtime_state": None,
    }
    parsed = ModelLookupResponse.model_validate(payload)
    assert parsed.slug == "claude"
    assert parsed.runtime_state is None


def test_publish_hardware_tier_fields_are_in_sync_between_openapi_and_generated_models() -> None:
    snapshot = json.loads(CLI_CONTRACT_OPENAPI.read_text(encoding="utf-8"))
    schema = snapshot["components"]["schemas"]["CliPublishHardwareTier"]
    properties = schema["properties"]

    for field_name in ("architecture_family", "provider", "pricing_mode", "display_specs"):
        assert field_name in properties
        assert field_name in CliPublishHardwareTier.model_fields
