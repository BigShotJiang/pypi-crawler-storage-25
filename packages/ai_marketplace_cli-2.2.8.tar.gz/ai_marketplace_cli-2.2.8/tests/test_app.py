"""CLI command tests."""

from __future__ import annotations

import json
import shutil
import sys
import tempfile
from contextlib import contextmanager
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
import typer
from pytest import MonkeyPatch
from rich.console import Console
from rich.text import Text
from typer.testing import CliRunner

import aimp_cli.core.app as app_module
import aimp_cli.core.config as config_module
import aimp_cli.operations.publish.config as publish_config_module
from aimp_cli.core.config import config_store
from aimp_cli.core.errors import CliError, network_error
from aimp_cli.core.launcher import LauncherActionResult
from aimp_cli.domain.models import (
    AuthResponse,
    CliPublishResult,
    ConfigData,
    FineTuneJobListResponse,
    FineTuneJobResponse,
    InputDefinition,
    JobCancelResponse,
    ModeContract,
    ModelSecretListResponse,
    ModelSecretMetadata,
    ModesConfig,
    OutputDefinition,
    PublishBuildGroup,
    PublishBuildGroupListResponse,
    PublishBuildProfile,
    PublishResponse,
    ResourceConfig,
    TuningConfig,
)
from aimp_cli.domain.project import (
    PROJECT_CONFIG_RELATIVE_PATH,
    ProjectConfig,
    PublishMetadataConfig,
    PublishStudioConfig,
    create_project_files,
    load_project_config,
    write_project_config,
)
from aimp_cli.utils.interactive import LauncherJobItem

runner = CliRunner()


def _scaffold_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
    *,
    name: str = "demo-model",
) -> Path:
    monkeypatch.chdir(tmp_path)
    return create_project_files(name)


class FakeTTYStream:
    """Simple stream stub with configurable TTY behavior."""

    def __init__(self, *, is_tty: bool) -> None:
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty

    def write(self, text: str) -> int:
        return len(text)

    def flush(self) -> None:
        pass


class FakeCommand:
    """Simple command stub for top-level help dispatch."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def main(self, **kwargs: Any) -> None:
        self.calls.append(kwargs)


class FakeGatewayClient:
    """Fake gateway used by app tests."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def authenticate(self, api_key: str) -> AuthResponse:
        assert api_key == "pk_test"
        return AuthResponse(valid=True, user_id=1, username="alice", workspace="acme", scopes=[])

    def get_current_user(self) -> AuthResponse | None:
        return AuthResponse(valid=True, user_id=1, username="alice", workspace="acme", scopes=[])


class FakeSecretGateway:
    """Gateway stub for secret command tests."""

    last_set: dict[str, str] | None = None
    last_deleted: dict[str, str] | None = None

    def __init__(self, *args: object, **kwargs: object) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def set_model_secret(self, *, model_slug: str, name: str, value: str) -> dict[str, Any]:
        type(self).last_set = {"model_slug": model_slug, "name": name, "value": value}
        return ModelSecretMetadata(
            name=name,
            is_configured=True,
            created_at="2026-04-03T00:00:00+00:00",
            updated_at="2026-04-03T00:00:00+00:00",
            last_rotated_at="2026-04-03T00:00:00+00:00",
        )

    def list_model_secrets(self, *, model_slug: str) -> ModelSecretListResponse:
        return ModelSecretListResponse(
            model=model_slug,
            secrets=[
                ModelSecretMetadata(
                    name="ZAI_API_KEY",
                    is_configured=True,
                    updated_at="2026-04-03T00:00:00+00:00",
                )
            ],
        )

    def delete_model_secret(self, *, model_slug: str, name: str) -> None:
        type(self).last_deleted = {"model_slug": model_slug, "name": name}


class UnusedPublishConfigGateway:
    """Gateway stub used when publish config loading should fail early."""

    def get_publish_metadata(self) -> Any:
        raise AssertionError("get_publish_metadata should not be called in this test")


class FakeFineTuneGateway:
    """Gateway stub for fine-tune CLI commands."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
        return {
            "slug": slug,
            "tuning_supported": True,
            "supported_hardware_tiers": ["cpu-basic"],
            "selected_hardware_tier": "cpu-basic",
            "tuning_schema": {
                "fields": [
                    {
                        "key": "query_image",
                        "type": "image",
                        "required": True,
                        "description": "Query image",
                        "multiple": False,
                    },
                    {
                        "key": "candidate_image",
                        "type": "image",
                        "required": True,
                        "description": "Candidate image",
                        "multiple": False,
                    },
                ],
            },
        }

    def create_fine_tune_job(
        self,
        *,
        model_slug: str,
        dataset_ref: str,
        budget: dict[str, Any] | None = None,
        labels: dict[str, Any] | None = None,
    ) -> FineTuneJobResponse:
        _ = labels
        return FineTuneJobResponse(
            job_id="job-1",
            model_slug=model_slug,
            status="queued",
            output_kind="tuned_model",
            output_asset_slug="vision-pro-tuned",
            timeline=[{"status": "queued"}],
        )

    @contextmanager
    def stream_job(self, job_id: str, **kwargs: Any) -> Any:
        yield iter(
            [
                "event: snapshot",
                (
                    "data: "
                    + json.dumps(
                        {
                            "job": {
                                "job_id": job_id,
                                "job_type": "fine-tune",
                                "model_slug": "vision-pro",
                                "status": "queued",
                                "timeline": [{"status": "queued"}],
                                "details": {
                                    "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                    "adapter_format": "lora",
                                    "output_asset_id": None,
                                },
                            },
                            "timeline_count": 1,
                            "log_count": None,
                        }
                    )
                ),
                "",
                "event: terminal",
                (
                    "data: "
                    + json.dumps(
                        {
                            "job": {
                                "job_id": job_id,
                                "job_type": "fine-tune",
                                "model_slug": "vision-pro",
                                "status": "succeeded",
                                "timeline": [
                                    {"status": "queued"},
                                    {"status": "succeeded"},
                                ],
                                "details": {
                                    "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                    "adapter_format": "lora",
                                    "output_asset_id": None,
                                },
                            },
                            "timeline_count": 2,
                            "log_count": None,
                        }
                    )
                ),
                "",
            ]
        )

    def list_fine_tune_jobs(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> FineTuneJobListResponse:
        _ = model_slug, status, page, page_size
        return FineTuneJobListResponse(
            results=[
                FineTuneJobResponse(
                    job_id="job-1",
                    model_slug="vision-pro",
                    status="queued",
                )
            ],
            pagination={"total_items": 1},
        )

    def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
        return FineTuneJobResponse(
            job_id=job_id,
            model_slug="vision-pro",
            status="succeeded",
            output_asset_slug="vision-pro-tuned",
            output_kind="tuned_model",
            output_usable_modes=["example"],
        )


class FakeJobsGateway(FakeFineTuneGateway):
    """Gateway stub for unified jobs CLI commands."""

    last_build_list_params: dict[str, Any] | None = None
    last_canceled_build_job: str | None = None
    last_deleted_build_job: str | None = None
    last_canceled_fine_tune_job: str | None = None
    last_deleted_fine_tune_job: str | None = None
    last_list_jobs_params: dict[str, Any] | None = None

    def list_publish_build_groups(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildGroupListResponse:
        type(self).last_build_list_params = {
            "model_slug": model_slug,
            "status": status,
            "page": page,
            "page_size": page_size,
        }
        return PublishBuildGroupListResponse(
            results=[
                PublishBuildGroup(
                    job_id="build-1",
                    slug="vision-pro",
                    version="1.0.0",
                    status=status or "running",
                    created_at="2026-03-18T10:00:00Z",
                    timeline=[],
                    requested_profiles=[
                        PublishBuildProfile(
                            runtime_profile="cpu",
                            supported_hardware_tiers=["cpu-basic"],
                        )
                    ],
                )
            ],
            pagination={
                "page": page,
                "page_size": page_size,
                "total_items": 1,
                "total_pages": 1,
                "has_next": False,
                "has_previous": False,
            },
            model_slug=model_slug,
        )

    def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
        return PublishBuildGroup(
            job_id=job_id,
            slug="vision-pro",
            version="1.0.0",
            status="succeeded",
            created_at="2026-03-18T10:00:00Z",
            timeline=[],
            requested_profiles=[
                PublishBuildProfile(
                    runtime_profile="cpu",
                    supported_hardware_tiers=["cpu-basic"],
                )
            ],
        )

    def cancel_publish_build_group(self, job_id: str) -> JobCancelResponse:
        type(self).last_canceled_build_job = job_id
        return JobCancelResponse(
            job_type="build",
            cancel_state="canceled",
            job={"job_id": job_id, "status": "canceled"},
        )

    def delete_publish_build_group(self, job_id: str) -> None:
        type(self).last_deleted_build_job = job_id

    def cancel_fine_tune_job(self, *, job_id: str) -> JobCancelResponse:
        type(self).last_canceled_fine_tune_job = job_id
        return JobCancelResponse(
            job_type="fine-tune",
            cancel_state="canceled",
            job={"job_id": job_id, "status": "canceled"},
        )

    def delete_fine_tune_job(self, *, job_id: str) -> None:
        type(self).last_deleted_fine_tune_job = job_id

    def list_jobs(
        self,
        *,
        job_type: str | None = None,
        status: str | None = None,
        model_slug: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        type(self).last_list_jobs_params = {
            "job_type": job_type,
            "status": status,
            "model_slug": model_slug,
            "page": page,
            "page_size": page_size,
        }
        results: list[dict[str, Any]] = []
        if job_type in {None, "build"}:
            results.append(
                {
                    "job_type": "build",
                    "job_id": "build-1",
                    "model_slug": "vision-pro",
                    "status": status or "running",
                    "created_at": "2026-03-18T10:00:00Z",
                    "started_at": None,
                    "finished_at": None,
                    "job": {
                        "job_type": "build",
                        "job_id": "build-1",
                        "model_slug": "vision-pro",
                        "slug": "vision-pro",
                        "version": "1.0.0",
                        "status": status or "running",
                        "timeline": [],
                        "logs": [],
                    },
                }
            )
        if job_type in {None, "fine-tune"}:
            results.append(
                {
                    "job_type": "fine-tune",
                    "job_id": "job-1",
                    "model_slug": "vision-pro",
                    "status": status or "queued",
                    "created_at": "2026-03-18T09:00:00Z",
                    "started_at": None,
                    "finished_at": None,
                    "job": {
                        "job_type": "fine-tune",
                        "job_id": "job-1",
                        "model_slug": "vision-pro",
                        "status": status or "queued",
                        "timeline": [],
                        "logs": [],
                        "adapter_format": "lora",
                        "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                    },
                }
            )
        return {
            "results": results,
            "pagination": {
                "page": page,
                "page_size": page_size,
                "total_items": len(results),
                "total_pages": 1,
                "has_next": False,
                "has_previous": False,
            },
        }

    def get_job(self, *, job_id: str) -> dict[str, Any]:
        if job_id.startswith("build"):
            return {
                "job_type": "build",
                "job": {
                    "job_type": "build",
                    "job_id": job_id,
                    "model_slug": "vision-pro",
                    "slug": "vision-pro",
                    "version": "1.0.0",
                    "status": "succeeded",
                    "created_at": "2026-03-18T10:00:00Z",
                    "started_at": None,
                    "finished_at": "2026-03-18T10:10:00Z",
                    "timeline": [],
                    "logs": [],
                },
            }
        return {
            "job_type": "fine-tune",
            "job": {
                "job_type": "fine-tune",
                "job_id": job_id,
                "model_slug": "vision-pro",
                "status": "succeeded",
                "created_at": "2026-03-18T09:00:00Z",
                "started_at": None,
                "finished_at": "2026-03-18T09:10:00Z",
                "timeline": [],
                "logs": [],
                "adapter_format": "lora",
                "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
            },
        }

    def cancel_job(self, *, job_id: str) -> dict[str, Any]:
        if job_id.startswith("build"):
            type(self).last_canceled_build_job = job_id
            return {
                "job_type": "build",
                "cancel_state": "canceling",
                "job": {
                    "job_type": "build",
                    "job_id": job_id,
                    "model_slug": "vision-pro",
                    "status": "canceling",
                },
            }
        type(self).last_canceled_fine_tune_job = job_id
        return {
            "job_type": "fine-tune",
            "cancel_state": "canceling",
            "job": {
                "job_type": "fine-tune",
                "job_id": job_id,
                "model_slug": "vision-pro",
                "status": "canceling",
            },
        }

    def delete_job(self, *, job_id: str) -> None:
        if job_id.startswith("build"):
            type(self).last_deleted_build_job = job_id
            return
        type(self).last_deleted_fine_tune_job = job_id


def test_login_stdin_persists_config(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(app_module, "GatewayClient", FakeGatewayClient)
    config_store._path = tmp_path / "config.json"
    result = runner.invoke(
        app_module.app,
        ["login", "--gateway", "http://localhost:8080", "--stdin", "--json"],
        input="pk_test",
    )
    if result.exit_code != 0:
        print(result.stdout)
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["username"] == "alice"
    persisted = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert persisted["apiKey"] == "pk_test"


def test_auth_reports_not_authenticated_when_no_credentials(tmp_path: Path) -> None:
    config_store._path = tmp_path / "config.json"
    config_store._config = None
    result = runner.invoke(app_module.app, ["auth", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["authenticated"] is False
    assert payload["data"]["reason"] == "no_credentials"


def test_secret_set_reads_from_stdin_and_resolves_local_model(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_files("glm-lab")
    monkeypatch.chdir(project_dir)
    monkeypatch.setattr(app_module, "GatewayClient", FakeSecretGateway)
    config_store._path = tmp_path / "config.json"
    config_store.save(
        ConfigData(
            gatewayUrl="http://localhost:8080",
            apiKey="pk_test",
            username="alice",
            defaultWorkspace="acme",
        )
    )

    result = runner.invoke(
        app_module.app,
        ["secret", "set", "ZAI_API_KEY", "--stdin", "--json"],
        input="live-secret",
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["model"] == "glm-lab"
    assert payload["data"]["secret"]["name"] == "ZAI_API_KEY"
    assert FakeSecretGateway.last_set == {
        "model_slug": "glm-lab",
        "name": "ZAI_API_KEY",
        "value": "live-secret",
    }


def test_secret_list_uses_local_project_model_slug(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_files("glm-lab")
    monkeypatch.chdir(project_dir)
    monkeypatch.setattr(app_module, "GatewayClient", FakeSecretGateway)
    config_store._path = tmp_path / "config.json"
    config_store.save(
        ConfigData(
            gatewayUrl="http://localhost:8080",
            apiKey="pk_test",
            username="alice",
            defaultWorkspace="acme",
        )
    )

    result = runner.invoke(app_module.app, ["secret", "list", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["model"] == "glm-lab"
    assert payload["data"]["secrets"][0]["name"] == "ZAI_API_KEY"


def test_init_creates_unified_deployable_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        ["init", "demo-model", "--yes", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["entrypoint"] == "main.py"
    assert payload["data"]["next_steps"] == [
        "cd demo-model",
        "uv sync",
        "ai push --configure",
        "ai push",
    ]
    project_dir = tmp_path / "demo-model"
    assert (project_dir / "main.py").exists()
    assert (project_dir / "internal" / "loader.py").exists()
    assert (project_dir / "internal" / "inference.py").exists()
    assert (project_dir / "tests" / "test_model.py").exists()
    assert (project_dir / "runtime" / "pyproject.toml").exists()
    assert (project_dir / "runtime" / "Dockerfile").exists()
    assert (project_dir / "runtime" / "README.md").exists()
    assert (project_dir / "artifacts" / "README.md").exists()
    assert (project_dir / "artifacts" / "artifact.py").exists()
    assert not (project_dir / "agent.py").exists()
    assert not (project_dir / "models").exists()
    assert (project_dir / "schemas.py").exists()
    assert (project_dir / "playground.py").exists()
    assert (project_dir / "PROJECT.md").exists()
    assert (project_dir / ".agents" / "skills" / "model-architecture" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "publish-readiness" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "studio-content" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "tuning-development" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "skills" / "quality-gates" / "SKILL.md").exists()
    assert (project_dir / ".agents" / "references" / "layout.md").exists()
    assert (project_dir / ".agents" / "references" / "commands.md").exists()
    assert (project_dir / ".agents" / "references" / "publish-flow.md").exists()
    assert (project_dir / "studio" / "article.mdx").exists()
    assert (project_dir / "studio" / "cover.jpg").exists()
    assert not any(path.name == "__pycache__" for path in project_dir.rglob("__pycache__"))
    model_text = (project_dir / "main.py").read_text(encoding="utf-8")
    project_text = (project_dir / "PROJECT.md").read_text(encoding="utf-8")
    model_architecture_skill_text = (
        project_dir / ".agents" / "skills" / "model-architecture" / "SKILL.md"
    ).read_text(encoding="utf-8")
    publish_skill_text = (
        project_dir / ".agents" / "skills" / "publish-readiness" / "SKILL.md"
    ).read_text(encoding="utf-8")
    quality_skill_text = (
        project_dir / ".agents" / "skills" / "quality-gates" / "SKILL.md"
    ).read_text(encoding="utf-8")
    layout_reference_text = (project_dir / ".agents" / "references" / "layout.md").read_text(
        encoding="utf-8"
    )
    commands_reference_text = (project_dir / ".agents" / "references" / "commands.md").read_text(
        encoding="utf-8"
    )
    model_docker_text = (project_dir / "runtime" / "Dockerfile").read_text(encoding="utf-8")
    engine_text = (project_dir / "internal" / "loader.py").read_text(encoding="utf-8")
    readme_text = (project_dir / "README.md").read_text(encoding="utf-8")
    assert "class DemoModel(Model):" in model_text
    assert "engine = DemoModelEngine" in model_text
    assert "vectors = [DemoModelDocsVector]" in model_text
    assert "@mode(" in model_text
    assert "async def example(" in model_text
    assert "from internal.loader import DemoModelEngine" in model_text
    assert "from internal.inference import DemoModelDocsVector" in model_text
    assert "from aimp_sdk import Model" in model_text and "mode" in model_text
    assert 'python", "-m", "aimp_sdk.model_runner"' in model_docker_text
    assert "/app/main.py" in model_docker_text
    assert "def build(self)" not in engine_text
    assert "`ai push` requires `runtime/Dockerfile`" in readme_text
    assert "main.py" in project_text
    assert "`internal/` is internal-only implementation" in project_text
    assert "`ai push` is the canonical end-to-end publish command" in project_text
    assert "Do not hardcode hardware tiers" in project_text
    assert "Do not download weights, datasets, binaries" in project_text
    assert "agent.py" in project_text
    assert "core/" in project_text
    assert "One project is one model" in model_architecture_skill_text
    assert "add or change a public mode" in model_architecture_skill_text.lower()
    assert "ai contract validate --json" in publish_skill_text
    assert "ai push" in publish_skill_text
    assert "Do not invent alternate publish commands" in publish_skill_text
    assert "Verify no legacy layout paths were introduced" in quality_skill_text
    assert "ai contract validate --json" in quality_skill_text
    assert "Invalid legacy shapes" in layout_reference_text
    assert "ai jobs get --type build --job <job_id>" in commands_reference_text
    assert "Do not hardcode hardware tiers" in readme_text


def test_init_uses_leaf_directory_name_for_scaffold_metadata(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        ["init", "agents/demo-model", "--yes", "--json"],
    )

    assert result.exit_code == 0
    project_dir = tmp_path / "agents" / "demo-model"
    assert project_dir.exists()

    project_toml = (project_dir / "pyproject.toml").read_text(encoding="utf-8")
    hidden_toml = (project_dir / ".aimp" / "project.toml").read_text(encoding="utf-8")
    model_text = (project_dir / "main.py").read_text(encoding="utf-8")

    assert 'name = "demo-model"' in project_toml
    assert "[tool.aimp.project]" in project_toml
    assert 'artifact_path = "artifacts"' in hidden_toml
    assert "model_key" not in hidden_toml
    assert (project_dir / "main.py").exists()
    assert "class DemoModel(Model):" in model_text


def test_init_rejects_removed_template_option(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["init", "demo-model", "--template", "anything"])

    assert result.exit_code != 0
    assert "No such option: --template" in result.stdout


def test_init_rejects_removed_vector_options(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["init", "demo-model", "--with-vector"])

    assert result.exit_code != 0
    assert "No such option: --with-vector" in result.stdout


def test_init_rejects_removed_no_skills_option(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["init", "demo-model", "--no-skills"])

    assert result.exit_code != 0
    assert "No such option: --no-skills" in result.stdout


def test_help_no_longer_exposes_add_commands() -> None:
    result = runner.invoke(app_module.app, ["--help"])

    assert result.exit_code == 0
    assert "add" not in result.stdout
    assert "agent" not in result.stdout


def test_init_fails_when_directory_exists(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "demo-model").mkdir()

    result = runner.invoke(app_module.app, ["init", "demo-model", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "validation_error"
    assert 'Directory "demo-model" already exists' in payload["error"]["message"]


def test_skills_list_returns_project_local_skills(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    project_dir = _scaffold_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    result = runner.invoke(app_module.app, ["skills", "list", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["project_file"] == "PROJECT.md"
    skill_names = [item["name"] for item in payload["data"]["skills"]]
    assert "model-architecture" in skill_names
    assert "tuning-development" in skill_names
    assert "publish-readiness" in skill_names
    assert "studio-content" in skill_names
    assert "quality-gates" in skill_names


def test_skills_list_fails_cleanly_outside_project(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app_module.app, ["skills", "list", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "project_not_found"


def test_skills_list_fails_when_project_has_no_skills(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_project(tmp_path, monkeypatch)
    shutil.rmtree(project_dir / ".agents" / "skills")
    (project_dir / "PROJECT.md").unlink()
    monkeypatch.chdir(project_dir)

    result = runner.invoke(app_module.app, ["skills", "list", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "project_skills_not_found"


def test_fine_tune_create_rejects_missing_bundle(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--bundle",
            "/tmp/does-not-exist.json",
            "--json",
        ],
    )

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "dataset_not_found"


def test_fine_tune_create_uploads_workspace_bundle_and_submits_job(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class NoActiveFineTuneGateway(FakeFineTuneGateway):
        def list_fine_tune_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> FineTuneJobListResponse:
            _ = model_slug, status, page, page_size
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

    query_image = tmp_path / "query.jpg"
    candidate_image = tmp_path / "candidate.jpg"
    query_image.write_bytes(b"query-image")
    candidate_image.write_bytes(b"candidate-image")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "query_image": query_image.name,
                        "candidate_image": candidate_image.name,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    upload_calls: list[dict[str, Any]] = []

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(
            self,
            *,
            file_path: Path,
            slug: str,
            version: str,
            artifact_type: str,
            content_type: str,
            metadata: dict[str, Any],
            concurrency: int,
            on_progress: Any,
        ) -> Any:
            upload_calls.append(
                {
                    "file_path": file_path,
                    "slug": slug,
                    "version": version,
                    "artifact_type": artifact_type,
                    "content_type": content_type,
                    "metadata": metadata,
                    "concurrency": concurrency,
                    "on_progress": on_progress,
                }
            )
            return SimpleNamespace(storage_uri="s3://datasets/vision-pro/bundle.zip")

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", NoActiveFineTuneGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--workspace",
            str(tmp_path),
            "--max-trials",
            "3",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["job_id"] == "job-1"
    assert payload["data"]["job_created"] is True
    assert payload["data"]["output_dir"] == str(tmp_path)
    assert payload["data"]["output_kind"] == "tuned_model"
    assert payload["data"]["output_asset_slug"] == "vision-pro-tuned"
    assert upload_calls[0]["artifact_type"] == "fine_tune_dataset"
    assert upload_calls[0]["slug"] == "vision-pro"
    assert upload_calls[0]["content_type"] == "application/zip"


def test_fine_tune_create_scaffolds_output_dir_when_bundle_missing(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    output_dir = tmp_path / "customer-data"
    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--output-dir",
            str(output_dir),
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["job_created"] is False
    assert payload["data"]["output_dir"] == str(output_dir)
    assert (output_dir / ".tuning" / "schema.json").exists()
    assert (output_dir / ".tuning" / "state.json").exists()
    assert (output_dir / ".tuning" / "generated.py").exists()
    assert (output_dir / "tune.py").exists()
    tune_py = (output_dir / "tune.py").read_text(encoding="utf-8")
    assert "from ._tuning.generated import" in tune_py
    assert (output_dir / "data.jsonl").exists()
    assert (output_dir / "README.md").exists()
    assert "ai tune push" in payload["data"]["next_step"]


def test_fine_tune_create_preserves_existing_workspace_when_bundle_missing(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    output_dir = tmp_path / "customer-data"
    output_dir.mkdir(parents=True)
    (output_dir / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import VisionProAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='vision-pro', data='data.jsonl', tuning=VisionProAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (output_dir / ".tuning").mkdir(parents=True, exist_ok=True)
    (output_dir / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class VisionProAutoTune:\n"
            "    max_trials: int = 3\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--output-dir",
            str(output_dir),
            "--json",
        ],
    )

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "dataset_not_found"
    assert "Use `ai tune push`" in payload["error"]["message"]


def test_fine_tune_create_rejects_existing_active_job_before_upload(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class ActiveFineTuneGateway(FakeFineTuneGateway):
        def list_fine_tune_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> FineTuneJobListResponse:
            _ = status, page, page_size
            return FineTuneJobListResponse(
                results=[
                    FineTuneJobResponse(
                        job_id="job-active",
                        model_slug=model_slug or "vision-pro",
                        status="running",
                        adapter_format="lora",
                    )
                ],
                pagination={"total_items": 1},
            )

        def create_fine_tune_job(
            self,
            *,
            model_slug: str,
            dataset_ref: str,
            budget: dict[str, Any] | None = None,
            labels: dict[str, Any] | None = None,
        ) -> FineTuneJobResponse:
            _ = model_slug, dataset_ref, budget, labels
            raise AssertionError("create_fine_tune_job should not be called")

    class NoUploadClient:
        def __init__(self, *args: object, **kwargs: object) -> None:
            _ = args, kwargs

        def upload_file(self, **kwargs: Any) -> Any:
            _ = kwargs
            raise AssertionError("upload_file should not be called")

    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text("{}", encoding="utf-8")

    def fake_create_bundle(**_kwargs: Any) -> tuple[SimpleNamespace, str]:
        temp_path = Path(tempfile.mkstemp(suffix=".zip")[1])
        temp_path.write_text("archive", encoding="utf-8")
        return SimpleNamespace(name=str(temp_path)), "application/zip"

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", ActiveFineTuneGateway)
    monkeypatch.setattr(app_module, "UploadClient", NoUploadClient)
    monkeypatch.setattr(app_module, "_create_tuning_bundle_archive", fake_create_bundle)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--bundle",
            str(bundle_path),
            "--json",
        ],
    )

    assert result.exit_code == 6
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "active_job_exists"


def test_fine_tune_create_streams_live_logs_in_non_json_mode(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class StreamingFineTuneGateway(FakeFineTuneGateway):
        def list_fine_tune_jobs(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> FineTuneJobListResponse:
            _ = model_slug, status, page, page_size
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "running",
                                    "timeline": [{"status": "queued"}],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Creating tuning study",
                                        }
                                    ],
                                    "details": {
                                        "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                        "adapter_format": "lora",
                                        "output_asset_id": None,
                                    },
                                },
                                "timeline_count": 1,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                    "event: logs",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job_id": job_id,
                                "job_type": "fine-tune",
                                "offset": 1,
                                "count": 1,
                                "items": [
                                    {
                                        "level": "warning",
                                        "message": "Executing tuning trial 1/3",
                                    }
                                ],
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "succeeded",
                                    "timeline": [
                                        {"status": "queued"},
                                        {"status": "succeeded"},
                                    ],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Creating tuning study",
                                        },
                                        {
                                            "level": "warning",
                                            "message": "Executing tuning trial 1/3",
                                        },
                                        {
                                            "level": "info",
                                            "message": "Fine-tune job succeeded",
                                        },
                                    ],
                                    "details": {
                                        "dataset_ref": "s3://datasets/vision-pro/bundle.zip",
                                        "adapter_format": "lora",
                                        "output_asset_id": None,
                                    },
                                },
                                "timeline_count": 2,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(
            self,
            *,
            file_path: Path,
            slug: str,
            version: str,
            artifact_type: str,
            content_type: str,
            metadata: dict[str, Any],
            concurrency: int,
            on_progress: Any,
        ) -> Any:
            _ = (
                file_path,
                slug,
                version,
                artifact_type,
                content_type,
                metadata,
                concurrency,
                on_progress,
            )
            return SimpleNamespace(storage_uri="s3://datasets/vision-pro/bundle.zip")

    class _StatusStub:
        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            _ = message

    printed: list[str] = []

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return _StatusStub()

        @staticmethod
        def print(message: Any, **kwargs: Any) -> None:
            _ = kwargs
            printed.append(str(message))

        @staticmethod
        def print_json(*args: Any, **kwargs: Any) -> None:
            _ = args, kwargs

    query_image = tmp_path / "query.jpg"
    candidate_image = tmp_path / "candidate.jpg"
    query_image.write_bytes(b"query-image")
    candidate_image.write_bytes(b"candidate-image")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "query_image": query_image.name,
                        "candidate_image": candidate_image.name,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", StreamingFineTuneGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)
    monkeypatch.setattr(app_module, "console", _ConsoleStub())

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "create",
            "--model",
            "vision-pro",
            "--workspace",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "[dim]  Creating tuning study[/dim]" in printed
    assert "[yellow]⚠ Executing tuning trial 1/3[/yellow]" in printed
    assert "[dim]  Fine-tune job succeeded[/dim]" in printed


def test_contract_edit_enables_fine_tune_module(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    assert (tmp_path / "demo-model" / "tuning" / "runner.py").exists()
    assert (tmp_path / "demo-model" / "tuning" / "dataset.py").exists()


def test_contract_edit_keeps_project_fine_tune_wiring(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "generate,search",
            "--mode-inputs",
            "search=image",
            "--json",
        ],
    )

    assert result.exit_code == 0
    assert (tmp_path / "demo-model" / "tuning" / "runner.py").exists()
    assert (tmp_path / "demo-model" / "tuning" / "dataset.py").exists()


def test_fine_tune_schema_reads_local_project_contract(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    dataset_path = tmp_path / "demo-model" / "tuning" / "dataset.py"
    dataset_path.write_text(
        "from aimp_sdk import FineTuneSchema, TuningTextField\n\n\n"
        "class DemoModelDatasetSchema(FineTuneSchema):\n"
        "    dataset_url = TuningTextField()\n",
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["fine-tune", "schema", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    field_keys = [field["key"] for field in payload["data"]["schema"]["fields"]]
    assert field_keys == ["dataset_url"]


def test_fine_tune_schema_accepts_tuning_model_override_for_local_discovery(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    project_dir = _scaffold_project(tmp_path, monkeypatch)
    monkeypatch.chdir(project_dir)

    captured: dict[str, object] = {}

    def _fake_load_local_tuning_contract(
        project_root: Path,
        *,
        tuning_model: str | None = None,
    ) -> dict[str, object]:
        captured["project_root"] = project_root
        captured["tuning_model"] = tuning_model
        return {
            "schema": {
                "fields": [
                    {
                        "key": "dataset_url",
                        "type": "text",
                        "required": True,
                        "multiple": False,
                    }
                ]
            }
        }

    monkeypatch.setattr(
        app_module,
        "_load_local_tuning_contract",
        _fake_load_local_tuning_contract,
    )

    result = runner.invoke(
        app_module.app,
        ["fine-tune", "schema", "--tuning-model", "custom_model", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert captured["project_root"] == project_dir
    assert captured["tuning_model"] == "custom_model"


def test_fine_tune_schema_rejects_tuning_model_with_remote_model(
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "schema",
            "--model",
            "vision-pro",
            "--tuning-model",
            "custom_model",
            "--json",
        ],
    )

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "invalid_tuning_model_option"


def test_fine_tune_scaffold_generates_consumer_workspace(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class RichSchemaGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            return {
                "slug": slug,
                "tuning_supported": True,
                "supported_hardware_tiers": ["cpu-basic"],
                "selected_hardware_tier": "cpu-basic",
                "tuning_schema": {
                    "fields": [
                        {
                            "key": "prompt",
                            "type": "text",
                            "required": True,
                            "description": "Prompt text",
                            "multiple": False,
                        },
                        {
                            "key": "metadata",
                            "type": "json",
                            "required": True,
                            "description": "Structured metadata",
                            "multiple": False,
                        },
                        {
                            "key": "attachments",
                            "type": "file",
                            "required": False,
                            "description": "Supporting files",
                            "multiple": True,
                        },
                        {
                            "key": "query_image",
                            "type": "image",
                            "required": True,
                            "description": "Reference image",
                            "multiple": False,
                        },
                        {
                            "key": "reference_audio",
                            "type": "audio",
                            "required": False,
                            "description": "Reference audio",
                            "multiple": False,
                        },
                        {
                            "key": "preview_video",
                            "type": "video",
                            "required": False,
                            "description": "Preview video",
                            "multiple": False,
                        },
                    ],
                },
            }

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", RichSchemaGateway)

    output_dir = tmp_path / "consumer-workspace"
    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "scaffold",
            "--model",
            "vision-pro",
            "--output",
            str(output_dir),
            "--json",
        ],
    )

    assert result.exit_code == 0
    assert (output_dir / ".tuning" / "schema.json").exists()
    assert (output_dir / ".tuning" / "state.json").exists()
    assert (output_dir / ".tuning" / "generated.py").exists()
    assert (output_dir / "tune.py").exists()
    assert (output_dir / "data.jsonl").exists()
    assert (output_dir / "README.md").exists()
    assert (output_dir / "assets" / "README.md").exists()
    readme = (output_dir / "README.md").read_text(encoding="utf-8")
    assert "ai tune push" in readme


def test_tune_init_creates_workspace_for_tune_push(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class TextFineTuneGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", TextFineTuneGateway)
    workspace = tmp_path / "ft-demo-tune"

    result = runner.invoke(
        app_module.app,
        [
            "tune",
            "init",
            "ft-demo",
            "--output",
            str(workspace),
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["output_dir"] == str(workspace)
    assert (workspace / "README.md").exists()
    assert (workspace / "tune.py").exists()
    assert (workspace / "data.jsonl").exists()
    assert (workspace / ".tuning" / "schema.json").exists()
    assert (workspace / ".tuning" / "state.json").exists()
    assert (workspace / ".tuning" / "generated.py").exists()


def test_tune_help_includes_workspace_first_flow() -> None:
    result = runner.invoke(app_module.app, ["tune", "--help"])

    assert result.exit_code == 0
    assert "ai tune init <model>" in result.stdout
    assert "ai tune push" in result.stdout


def test_tune_model_alias_shows_clear_migration_message() -> None:
    result = runner.invoke(app_module.app, ["tune", "ft-demo"])

    assert result.exit_code != 0
    assert "ai tune <model>" in result.stdout
    assert "ai tune init <model>" in result.stdout
    assert "ai tune push" in result.stdout


def test_tune_push_rejects_non_workspace_directory(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    result = runner.invoke(app_module.app, ["tune", "push", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "invalid_tune_workspace"
    assert "ai tune init ft-demo" in payload["error"]["message"]


def test_tune_push_creates_job_from_workspace(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class NoActiveTextGateway(FakeFineTuneGateway):
        last_budget: dict[str, Any] | None = None

        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        def create_fine_tune_job(
            self,
            *,
            model_slug: str,
            dataset_ref: str,
            budget: dict[str, Any] | None = None,
            labels: dict[str, Any] | None = None,
        ) -> FineTuneJobResponse:
            _ = dataset_ref, labels
            type(self).last_budget = budget
            return FineTuneJobResponse(
                job_id="job-1",
                model_slug=model_slug,
                status="queued",
                adapter_format="lora",
                output_kind="derived_model_recipe",
                output_asset_slug="ft-demo-ft-8d91c",
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **kwargs: Any) -> Any:
            assert kwargs["artifact_type"] == "fine_tune_dataset"
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {
                        "key": "completion",
                        "type": "text",
                        "required": True,
                        "multiple": False,
                    },
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 3\n"
            "    mode: str = 'auto'\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoManualTune:\n"
            "    mode: str = 'manual'\n"
            "    parameters: dict = None\n"
            "    def __post_init__(self):\n"
            "        object.__setattr__(self, 'parameters', {})\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", NoActiveTextGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    monkeypatch.chdir(workspace)
    result = runner.invoke(app_module.app, ["tune", "push", "--detach", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["job"]["job_created"] is True
    assert payload["data"]["job"]["status"] == "queued"
    assert payload["data"]["workspace"] == "."
    assert NoActiveTextGateway.last_budget == {"max_trials": 1}


def test_tune_push_watch_failure_exits_without_started_message(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class FailingGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        def create_fine_tune_job(
            self,
            *,
            model_slug: str,
            dataset_ref: str,
            budget: dict[str, Any] | None = None,
            labels: dict[str, Any] | None = None,
        ) -> FineTuneJobResponse:
            _ = dataset_ref, budget, labels
            return FineTuneJobResponse(
                job_id="job-fail",
                model_slug=model_slug,
                status="queued",
                adapter_format="lora",
                output_kind="derived_model_recipe",
                output_asset_slug=None,
            )

        def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
            _ = job_id
            return FineTuneJobResponse(
                job_id="job-fail",
                model_slug="ft-demo",
                status="failed",
                error_code="fine_tune_failed",
                error_message="Trial failed: [Errno 30] Read-only file system: '/app/artifacts/memory.json'",
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **_kwargs: Any) -> Any:
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 1\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(workspace)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FailingGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)
    monkeypatch.setattr(
        app_module.fine_tune_commands,
        "watch_execution_stream",
        lambda **_kwargs: {"job_id": "job-fail", "status": "failed"},
    )

    result = runner.invoke(app_module.app, ["tune", "push", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "fine_tune_failed"
    assert "Read-only file system" in payload["error"]["message"]


def test_tune_push_recovers_terminal_failure_when_stream_disconnects(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class ReconcileFailureGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        @contextmanager
        def stream_job(self, job_id: str, **_kwargs: Any) -> Any:
            _ = job_id
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": "job-reconcile-fail",
                                    "job_type": "fine-tune",
                                    "model_slug": "ft-demo",
                                    "status": "running",
                                    "timeline": [{"status": "running"}],
                                },
                                "timeline_count": 1,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                ]
            )

        def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
            return FineTuneJobResponse(
                job_id=job_id,
                model_slug="ft-demo",
                status="failed",
                error_code="fine_tune_output_not_usable",
                error_message=(
                    "Derived model materialization failed: fine_tune_output_not_usable: "
                    "example (missing_active_rate_for_mode:example)"
                ),
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **_kwargs: Any) -> Any:
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 1\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(workspace)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", ReconcileFailureGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    result = runner.invoke(app_module.app, ["tune", "push", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "fine_tune_output_not_usable"
    assert "missing_active_rate_for_mode:example" in payload["error"]["message"]


def test_tune_push_recovers_terminal_success_when_stream_disconnects(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class ReconcileSuccessGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        @contextmanager
        def stream_job(self, job_id: str, **_kwargs: Any) -> Any:
            _ = job_id
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": "job-reconcile-success",
                                    "job_type": "fine-tune",
                                    "model_slug": "ft-demo",
                                    "status": "running",
                                    "timeline": [{"status": "running"}],
                                },
                                "timeline_count": 1,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                ]
            )

        def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
            return FineTuneJobResponse(
                job_id=job_id,
                model_slug="ft-demo",
                status="succeeded",
                output_asset_slug="ft-demo-ft-reconciled",
                output_kind="tuned_model",
                output_usable_modes=["example"],
                output_unusable_modes={},
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **_kwargs: Any) -> Any:
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 1\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(workspace)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", ReconcileSuccessGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    result = runner.invoke(app_module.app, ["tune", "push"])

    assert result.exit_code == 0
    assert "Fine-tune succeeded" in result.stdout
    assert "Derived model: ft-demo-ft-reconciled" in result.stdout


def test_tune_push_uses_data_path_from_tune_py_jsonl(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class NoActiveTextGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **_kwargs: Any) -> Any:
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "train.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='train.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {
                        "key": "completion",
                        "type": "text",
                        "required": True,
                        "multiple": False,
                    },
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 3\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", NoActiveTextGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    monkeypatch.chdir(workspace)
    result = runner.invoke(app_module.app, ["tune", "push", "--detach", "--json"])

    assert result.exit_code == 0
    bundle = json.loads(
        (tmp_path / "ft-demo-tune" / ".tuning" / "bundle.json").read_text(encoding="utf-8")
    )
    assert bundle["records"] == [{"completion": "hi", "prompt": "hello"}]


def test_tune_push_human_output_shows_mode_aware_run_hint_for_usable_mode(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class UsableOutputGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
            return FineTuneJobResponse(
                job_id=job_id,
                model_slug="ft-demo",
                status="succeeded",
                output_asset_slug="ft-demo-ft-usable",
                output_kind="tuned_model",
                output_usable_modes=["example"],
                output_unusable_modes={},
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **_kwargs: Any) -> Any:
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {
                        "key": "completion",
                        "type": "text",
                        "required": True,
                        "multiple": False,
                    },
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 1\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(workspace)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", UsableOutputGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    result = runner.invoke(app_module.app, ["tune", "push"])

    assert result.exit_code == 0
    assert "Use: ai run --model ft-demo-ft-usable --mode example" in result.stdout


def test_tune_push_human_output_warns_when_no_usable_mode_exists(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class UnusableOutputGateway(FakeFineTuneGateway):
        def get_marketplace_model_detail(self, slug: str) -> dict[str, Any]:
            detail = super().get_marketplace_model_detail(slug)
            detail["tuning_schema"] = {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
            return detail

        def list_fine_tune_jobs(self, **_kwargs: Any) -> FineTuneJobListResponse:
            return FineTuneJobListResponse(results=[], pagination={"total_items": 0})

        def get_fine_tune_job(self, *, job_id: str) -> FineTuneJobResponse:
            return FineTuneJobResponse(
                job_id=job_id,
                model_slug="ft-demo",
                status="succeeded",
                output_asset_slug="ft-demo-ft-unusable",
                output_kind="tuned_model",
                output_usable_modes=[],
                output_unusable_modes={
                    "example": ["missing execution_asset.root_artifact"],
                },
            )

    class FakeUploadClient:
        def __init__(self, gateway: Any) -> None:
            self.gateway = gateway

        def upload_file(self, **_kwargs: Any) -> Any:
            return SimpleNamespace(storage_uri="s3://datasets/ft-demo/bundle.zip")

    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoAutoTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoAutoTune(max_trials=1))\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {
                        "key": "completion",
                        "type": "text",
                        "required": True,
                        "multiple": False,
                    },
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoAutoTune:\n"
            "    max_trials: int = 1\n"
            "    mode: str = 'auto'\n"
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(workspace)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", UnusableOutputGateway)
    monkeypatch.setattr(app_module, "UploadClient", FakeUploadClient)

    result = runner.invoke(app_module.app, ["tune", "push"])

    assert result.exit_code == 0
    assert "Result warning: derived model is not yet usable:" in result.stdout
    assert "execution_asset.root_artifact" in result.stdout
    assert "Use: ai run --model" not in result.stdout


def test_tune_push_rejects_manual_mode_until_wired(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    workspace = tmp_path / "ft-demo-tune"
    workspace.mkdir(parents=True)
    (workspace / "tune.py").write_text(
        (
            "from __future__ import annotations\n\n"
            "from dataclasses import dataclass\n"
            "from ._tuning.generated import FtDemoManualTune\n\n"
            "@dataclass(frozen=True)\n"
            "class TuneConfig:\n"
            "    model: str\n"
            "    data: str\n"
            "    tuning: object\n\n"
            "config = TuneConfig(model='ft-demo', data='data.jsonl', tuning=FtDemoManualTune())\n"
        ),
        encoding="utf-8",
    )
    (workspace / "data.jsonl").write_text(
        '{"prompt":"hello","completion":"hi"}\n', encoding="utf-8"
    )
    (workspace / ".tuning").mkdir(parents=True)
    (workspace / ".tuning" / "schema.json").write_text(
        json.dumps(
            {
                "fields": [
                    {"key": "prompt", "type": "text", "required": True, "multiple": False},
                    {"key": "completion", "type": "text", "required": True, "multiple": False},
                ]
            }
        ),
        encoding="utf-8",
    )
    (workspace / ".tuning" / "generated.py").write_text(
        (
            "from __future__ import annotations\n"
            "from dataclasses import dataclass\n\n"
            "@dataclass(frozen=True)\n"
            "class FtDemoManualTune:\n"
            "    mode: str = 'manual'\n"
            "    parameters: dict = None\n"
            "    def __post_init__(self):\n"
            "        object.__setattr__(self, 'parameters', {})\n"
        ),
        encoding="utf-8",
    )

    monkeypatch.chdir(workspace)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )

    result = runner.invoke(app_module.app, ["tune", "push", "--detach", "--json"])

    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "invalid_tune_workspace"
    assert "not a valid fine-tune workspace" in payload["error"]["message"]
    assert "manual tuning parameters must not be empty" in payload["error"].get("hint", "")


def test_fine_tune_list_and_get_commands(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    list_result = runner.invoke(app_module.app, ["fine-tune", "list", "--json"])
    get_result = runner.invoke(app_module.app, ["fine-tune", "get", "--job", "job-1", "--json"])

    assert list_result.exit_code == 0
    assert get_result.exit_code == 0
    assert json.loads(list_result.stdout)["data"]["results"][0]["job_id"] == "job-1"
    assert json.loads(get_result.stdout)["data"]["status"] == "succeeded"


def test_jobs_list_defaults_to_all_and_merges_job_types(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeJobsGateway)
    FakeJobsGateway.last_list_jobs_params = None

    result = runner.invoke(app_module.app, ["jobs", "list", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["type"] == "all"
    assert [item["job_type"] for item in payload["data"]["results"]] == ["build", "fine-tune"]
    assert payload["data"]["results"][0]["job_id"] == "build-1"
    assert payload["data"]["results"][1]["job_id"] == "job-1"
    assert payload["data"]["sources"] == {}


def test_jobs_list_build_filter_and_get_build_job(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeJobsGateway)
    FakeJobsGateway.last_list_jobs_params = None

    list_result = runner.invoke(
        app_module.app,
        [
            "jobs",
            "list",
            "--type",
            "build",
            "--status",
            "running",
            "--model",
            "vision-pro",
            "--json",
        ],
    )
    get_result = runner.invoke(
        app_module.app,
        ["jobs", "get", "--type", "build", "--job", "build-1", "--json"],
    )

    assert list_result.exit_code == 0
    assert get_result.exit_code == 0
    assert FakeJobsGateway.last_list_jobs_params == {
        "job_type": "build",
        "status": "running",
        "model_slug": "vision-pro",
        "page": 1,
        "page_size": 20,
    }
    assert json.loads(list_result.stdout)["data"]["results"][0]["job_type"] == "build"
    assert json.loads(get_result.stdout)["data"]["job"]["job_id"] == "build-1"


def test_jobs_cancel_and_delete_commands(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeJobsGateway)
    FakeJobsGateway.last_canceled_build_job = None
    FakeJobsGateway.last_deleted_build_job = None
    FakeJobsGateway.last_deleted_fine_tune_job = None

    cancel_result = runner.invoke(
        app_module.app,
        ["jobs", "cancel", "--type", "build", "--job", "build-1", "--json"],
    )
    delete_result = runner.invoke(
        app_module.app,
        ["jobs", "delete", "--type", "fine-tune", "--job", "job-1", "--json"],
    )

    assert cancel_result.exit_code == 0
    assert delete_result.exit_code == 0
    cancel_payload = json.loads(cancel_result.stdout)["data"]
    assert cancel_payload["action"] == "canceled"
    assert cancel_payload["cancel_state"] == "canceling"
    assert json.loads(delete_result.stdout)["data"]["action"] == "deleted"
    assert FakeJobsGateway.last_canceled_build_job == "build-1"
    assert FakeJobsGateway.last_deleted_build_job is None
    assert FakeJobsGateway.last_deleted_fine_tune_job == "job-1"


def test_jobs_watch_build_streams_phase_aware_status_and_logs(monkeypatch: MonkeyPatch) -> None:
    """jobs watch should consume the canonical build stream with explicit phase metadata."""

    class StreamingJobsGateway(FakeJobsGateway):
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "id": job_id,
                                    "type": "publish-build",
                                    "model_slug": "vision-pro",
                                    "status": "running",
                                    "stage": "build",
                                    "phase": "image_build",
                                    "current_step_message": "Installing runtime dependencies",
                                    "last_progress_at": "2026-04-04T00:00:00Z",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "1.0.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                    "event: logs",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "offset": 0,
                                "count": 1,
                                "items": [{"level": "info", "message": "Building image layer"}],
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "id": job_id,
                                    "type": "publish-build",
                                    "model_slug": "vision-pro",
                                    "status": "succeeded",
                                    "stage": "build",
                                    "phase": "succeeded",
                                    "current_step_message": "Build completed",
                                    "last_progress_at": "2026-04-04T00:00:05Z",
                                    "timeline": [],
                                    "logs": [{"level": "info", "message": "Building image layer"}],
                                    "details": {"version": "1.0.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                ]
            )

    class _StatusStub:
        def __init__(self) -> None:
            self.messages: list[str] = []

        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            self.messages.append(message)

    status_stub = _StatusStub()
    printed: list[str] = []

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return status_stub

        @staticmethod
        def print(message: Any, **kwargs: Any) -> None:
            _ = kwargs
            printed.append(str(message))

        @staticmethod
        def print_json(*args: Any, **kwargs: Any) -> None:
            _ = args, kwargs

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", StreamingJobsGateway)
    monkeypatch.setattr(app_module, "console", _ConsoleStub())

    result = runner.invoke(
        app_module.app,
        ["jobs", "watch", "--job", "build-1", "--type", "build"],
    )

    assert result.exit_code == 0
    assert any("build" in message for message in status_stub.messages)
    assert any("Installing runtime dependencies" in line for line in printed)
    assert "[dim]  Building image layer[/dim]" in printed


def test_auth_surfaces_gateway_connectivity_failure(monkeypatch: MonkeyPatch) -> None:
    class UnreachableGateway(FakeGatewayClient):
        def get_current_user(self) -> AuthResponse | None:
            raise network_error(
                "Authentication failed: gateway unreachable",
                code="gateway_unreachable",
                request_id="req-auth-down",
            )

    monkeypatch.setattr(app_module, "GatewayClient", UnreachableGateway)
    result = runner.invoke(
        app_module.app,
        ["auth", "--json", "--gateway", "http://127.0.0.1:9", "--api-key", "pk_test"],
    )
    assert result.exit_code == 5
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "gateway_unreachable"


def test_build_publish_success_message_includes_readiness_blockers() -> None:
    message = app_module._build_publish_success_message(
        CliPublishResult(
            id="asset-1",
            slug="demo-model",
            visibility="private",
            readiness={
                "is_ready": False,
                "blocking_reasons": ["publish_pricing_not_configured"],
            },
            url="http://localhost:3000/studio/models/demo-model",
        )
    )

    assert "Deployment successful." in message
    assert "Visibility: private" in message
    assert "Ready: no" in message
    assert "- publish_pricing_not_configured" in message


def test_ensure_publish_config_rejects_legacy_root_file(tmp_path: Path) -> None:
    (tmp_path / "aimp.publish.toml").write_text("schema_version = 2\n", encoding="utf-8")

    with pytest.raises(CliError) as exc_info:
        publish_config_module.ensure_publish_config(
            project_dir=tmp_path,
            gateway=UnusedPublishConfigGateway(),
            configure_only=False,
            console=app_module.console,
            interactive_terminal=False,
        )

    assert exc_info.value.code == "legacy_publish_config_unsupported"


def test_ensure_publish_config_non_tty_missing_config_deduplicates_guidance(
    tmp_path: Path,
) -> None:
    with pytest.raises(CliError) as exc_info:
        publish_config_module.ensure_publish_config(
            project_dir=tmp_path,
            gateway=UnusedPublishConfigGateway(),
            configure_only=False,
            console=app_module.console,
            interactive_terminal=False,
        )

    assert exc_info.value.code == "publish_config_required"
    assert "Publish config not found: .aimp/publish.toml." in str(exc_info.value)
    assert (
        "Use an interactive terminal to create .aimp/publish.toml, or commit a valid file."
        in str(exc_info.value)
    )


def test_write_publish_config_writes_hidden_state_and_default_article(tmp_path: Path) -> None:
    config = PublishMetadataConfig(
        schema_version=4,
        studio=PublishStudioConfig(
            name="Demo",
            tags=["example"],
            visibility="private",
            cover_file="studio/cover.jpg",
            article_mdx_file="studio/article.mdx",
        ),
        pricing={"developer_margin": 0},
    )

    config_path = publish_config_module.write_publish_config(tmp_path, config)

    assert config_path == tmp_path / ".aimp" / "publish.toml"
    assert config_path.exists()
    assert (tmp_path / "studio" / "article.mdx").exists()
    assert (tmp_path / "studio" / "cover.jpg").exists()


def test_project_settings_editor_changes_name_only(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    existing = PublishMetadataConfig(
        schema_version=4,
        studio=PublishStudioConfig(
            name="Old Name",
            tags=["agent"],
            visibility="private",
            cover_file="studio/cover.jpg",
            article_mdx_file="studio/article.mdx",
        ),
        pricing={"developer_margin": 1.25},
    )
    monkeypatch.setattr(
        publish_config_module,
        "prompt_text",
        lambda *args, **kwargs: "New Name",
    )

    updated = publish_config_module.run_project_settings_editor(
        project_dir=tmp_path,
        gateway=UnusedPublishConfigGateway(),
        existing_config=existing,
        console=app_module.console,
        interactive_terminal=True,
        setting="name",
    )

    assert updated.studio.name == "New Name"
    assert updated.studio.tags == ["agent"]
    assert updated.studio.visibility == "private"
    assert updated.studio.article_mdx_file == "studio/article.mdx"
    assert updated.pricing == {"developer_margin": 1.25}


def test_project_settings_editor_changes_hardware_in_project_config_only(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    project_config = ProjectConfig()
    project_config.publish.selected_hardware_tier = "runpod-rtx-4090"
    write_project_config(tmp_path, project_config)
    existing = PublishMetadataConfig(
        schema_version=4,
        studio=PublishStudioConfig(
            name="Demo",
            tags=["agent"],
            visibility="private",
            cover_file="studio/cover.jpg",
            article_mdx_file="studio/article.mdx",
        ),
        pricing={"developer_margin": 1.25},
    )

    class FakeGateway:
        def get_publish_metadata(self) -> Any:
            return SimpleNamespace(
                hardware_tiers=[
                    SimpleNamespace(
                        id="runpod-a100-80gb-pcie",
                        label="NVIDIA A100 80GB PCIe",
                        description="80 GB GPU",
                        base_cost_hourly=2.736,
                        tier_type="gpu",
                        gpu_vram_gb=80,
                        ram_gb=None,
                        provider="Runpod",
                        pricing_mode="spot",
                        architecture_family="Ampere",
                        display_specs="80 GB VRAM • GPU • Runpod Spot",
                    )
                ],
                platform_fee_pct=0.3,
            )

    captured_descriptions: list[str] = []

    def fake_select_menu(sections: list[Any], **kwargs: Any) -> Any:
        _ = kwargs
        captured_descriptions.extend(option.description for option in sections[0].options)
        return sections[0].options[0]

    monkeypatch.setattr(
        publish_config_module,
        "select_menu",
        fake_select_menu,
    )

    updated = publish_config_module.run_project_settings_editor(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        existing_config=existing,
        console=app_module.console,
        interactive_terminal=True,
        setting="hardware",
    )

    assert updated == existing
    assert load_project_config(tmp_path).publish.selected_hardware_tier == "runpod-a100-80gb-pcie"
    assert captured_descriptions == [
        "NVIDIA A100 80GB PCIe - 80 GB VRAM • GPU • Runpod Spot - $2.74/hr infra - 80 GB GPU"
    ]


def test_format_hardware_tier_description_prefers_display_specs() -> None:
    tier = SimpleNamespace(
        id="runpod-rtx-a4000",
        label="NVIDIA RTX A4000",
        description="Cost-effective GPU for small inference workloads.",
        base_cost_hourly=0.576,
        tier_type="gpu",
        gpu_vram_gb=16,
        architecture_family="Ampere",
        provider="Runpod",
        pricing_mode="flex",
        display_specs="16 GB VRAM • GPU • Runpod Flex",
    )

    description = publish_config_module.format_hardware_tier_description(tier)

    assert description == (
        "NVIDIA RTX A4000 - 16 GB VRAM • GPU • Runpod Flex - "
        "$0.58/hr infra - Cost-effective GPU for small inference workloads."
    )


def test_render_publish_hardware_table_shows_specs_and_infra_cost() -> None:
    table = publish_config_module.render_publish_hardware_table(
        hardware_tiers=[
            SimpleNamespace(
                id="runpod-rtx-a4000",
                label="NVIDIA RTX A4000",
                description="Cost-effective GPU for small inference workloads.",
                base_cost_hourly=0.576,
                display_specs="16 GB VRAM • GPU • Runpod Flex",
            )
        ],
        platform_fee_pct=Decimal("0.3"),
    )

    assert [column.header for column in table.columns] == [
        "#",
        "Tier",
        "Label",
        "Specs",
        "Infra Cost",
        "Description",
    ]
    assert table.columns[3]._cells == ["16 GB VRAM • GPU • Runpod Flex"]
    assert table.columns[4]._cells == ["$0.58/hr"]


def test_select_visibility_only_offers_private_and_public(monkeypatch: MonkeyPatch) -> None:
    captured_keys: list[str] = []
    captured_show_header: list[bool] = []

    def fake_select_menu(
        sections: list[Any],
        *,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
    ) -> Any:
        captured_keys.extend(option.key for option in sections[0].options)
        captured_show_header.append(show_header)
        _ = title, subtitle
        return sections[0].options[0]

    monkeypatch.setattr(publish_config_module, "select_menu", fake_select_menu)

    result = publish_config_module._select_visibility(
        default_visibility="private",
        console=app_module.console,
        interactive_terminal=True,
    )

    assert result == "private"
    assert captured_keys == ["private", "public"]
    assert captured_show_header == [False]


def test_contract_edit_writes_hidden_contract_from_flags(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "generate,search,index",
            "--mode-inputs",
            "generate=text,image",
            "--mode-outputs",
            "generate=result:text",
            "--mode-inputs",
            "search=image",
            "--mode-inputs",
            "index=image",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["resources"]["vector_db"] is False
    assert payload["data"]["modes"]["generate"]["outputs"] == [
        {
            "name": "result",
            "kind": "text",
            "required": True,
            "description": "",
            "multiple": False,
        }
    ]
    assert payload["data"]["modes"]["search"]["inputs"] == [
        {"name": "image", "kind": "image", "required": True, "description": "", "multiple": False}
    ]
    assert payload["data"]["modes"]["index"]["inputs"] == [
        {"name": "image", "kind": "image", "required": True, "description": "", "multiple": False}
    ]
    contract_text = (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).read_text(encoding="utf-8")
    assert "schema_version = 3" in contract_text
    assert "[capabilities]" in contract_text
    assert "vector = false" in contract_text
    assert "[modes.generate]" in contract_text
    assert "[modes.search]" in contract_text
    assert "[modes.index]" in contract_text


def test_contract_edit_rejects_removed_vector_db_flag(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--vector-db",
            "--json",
        ],
    )

    assert result.exit_code != 0
    assert "No such option: --vector-db" in result.stdout


def test_contract_edit_supports_generate_and_search_without_index(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "generate,search",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is False
    assert set(payload["data"]["modes"]) == {"generate", "search"}


def test_contract_edit_supports_search_only_without_vector_flag(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search",
            "--mode-inputs",
            "search=image",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is False
    assert set(payload["data"]["modes"]) == {"search"}
    assert payload["data"]["modes"]["search"]["inputs"] == [
        {"name": "image", "kind": "image", "required": True, "description": "", "multiple": False}
    ]


def test_contract_edit_supports_arbitrary_modes_with_generic_flags(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "rank,rerank",
            "--mode-inputs",
            "rank=text,json",
            "--mode-outputs",
            "rerank=report:json",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["resources"]["vector_db"] is False
    assert set(payload["data"]["modes"]) == {"rank", "rerank"}
    assert payload["data"]["modes"]["rank"]["inputs"] == [
        {"name": "text", "kind": "text", "required": True, "description": "", "multiple": False},
        {"name": "json", "kind": "json", "required": True, "description": "", "multiple": False},
    ]
    assert payload["data"]["modes"]["rerank"]["outputs"] == [
        {
            "name": "report",
            "kind": "json",
            "required": True,
            "description": "",
            "multiple": False,
        }
    ]


def test_contract_edit_rejects_removed_no_vector_db_flag(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search",
            "--no-vector-db",
            "--json",
        ],
    )

    assert result.exit_code != 0
    assert "No such option: --no-vector-db" in result.stdout


def test_contract_edit_rejects_mode_inputs_when_mode_disabled(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(
        app_module.app,
        [
            "contract",
            "edit",
            "--modes",
            "search",
            "--mode-inputs",
            "generate=text",
            "--json",
        ],
    )

    assert result.exit_code != 0
    assert "mode input/output flags require enabled modes: generate" in result.stdout


def _sdk_example_contract() -> dict[str, Any]:
    return {
        "resources": {"vector_db": False},
        "modes": {
            "example": {
                "description": "Runs the demo text mode.",
                "inputs": [
                    {
                        "name": "message",
                        "kind": "text",
                        "required": True,
                        "description": "Input message",
                    }
                ],
                "outputs": [
                    {"name": "result", "kind": "text", "required": True},
                ],
            }
        },
    }


def _sdk_tuning_payload(*, learning_rate_default: float = 0.1) -> dict[str, Any]:
    return {
        "supported": True,
        "model_key": "ft_demo",
        "supports_chaining": True,
        "schema": {
            "fields": [
                {
                    "key": "prompt",
                    "type": "text",
                    "required": True,
                    "description": "Input prompt",
                },
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "description": "Expected response",
                },
            ]
        },
        "artifacts": {
            "fields": [
                {
                    "key": "memory",
                    "kind": "json",
                    "required": True,
                    "description": "Prompt completion memory",
                }
            ]
        },
        "metrics": {
            "fields": [
                {
                    "key": "validation_accuracy",
                    "goal": "maximize",
                    "required": True,
                    "description": "Exact prompt completion match accuracy",
                }
            ]
        },
        "parameters": {
            "learning_rate": {
                "kind": "float",
                "default": learning_rate_default,
                "min": 0.001,
                "max": 1.0,
                "required": True,
            },
            "epochs": {
                "kind": "integer",
                "default": 2,
                "min": 1,
                "max": 10,
                "required": True,
            },
        },
    }


def _write_minimal_hidden_contract(project_dir: Path) -> None:
    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    config_path.parent.mkdir(parents=True)
    config_path.write_text("schema_version = 3\n", encoding="utf-8")


def test_contract_sync_dry_run_reports_model_declared_tuning(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    _write_minimal_hidden_contract(tmp_path)
    tuning_config = TuningConfig.model_validate(_sdk_tuning_payload())
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_contract",
        lambda project_dir, python_bin: _sdk_example_contract(),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_tuning_config",
        lambda project_dir: tuning_config,
    )

    result = runner.invoke(app_module.app, ["contract", "sync", "--dry-run", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["changes"]["added_operations"] == ["example"]
    assert payload["data"]["changes"]["updated_tuning"] is True
    contract_text = (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).read_text(encoding="utf-8")
    assert "[tuning]" not in contract_text


def test_contract_sync_writes_model_declared_tuning_and_validate_reports_enabled(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    _write_minimal_hidden_contract(tmp_path)
    tuning_config = TuningConfig.model_validate(_sdk_tuning_payload())
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_contract",
        lambda project_dir, python_bin: _sdk_example_contract(),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_tuning_config",
        lambda project_dir: tuning_config,
    )

    sync_result = runner.invoke(app_module.app, ["contract", "sync", "--json"])

    assert sync_result.exit_code == 0
    contract_text = (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).read_text(encoding="utf-8")
    assert "tuning = true" in contract_text
    assert "[tuning]" in contract_text
    assert 'model_key = "ft_demo"' in contract_text
    assert "supports_chaining = true" in contract_text
    assert "[[tuning.artifacts.fields]]" in contract_text
    assert "[[tuning.metrics.fields]]" in contract_text
    assert "[tuning.parameters.learning_rate]" in contract_text
    assert "[tuning.parameters.epochs]" in contract_text

    validate_result = runner.invoke(app_module.app, ["contract", "validate", "--json"])

    assert validate_result.exit_code == 0
    payload = json.loads(validate_result.stdout)
    assert payload["data"]["capabilities"]["tuning"] is True
    assert payload["data"]["tuning"]["model_key"] == "ft_demo"
    assert payload["data"]["tuning"]["supports_chaining"] is True


def test_contract_diff_reports_missing_toml_tuning_when_sdk_declares_tuning(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    _write_minimal_hidden_contract(tmp_path)
    tuning_config = TuningConfig.model_validate(_sdk_tuning_payload())
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_contract",
        lambda project_dir, python_bin: _sdk_example_contract(),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_tuning_config",
        lambda project_dir: tuning_config,
    )

    result = runner.invoke(app_module.app, ["contract", "diff", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    data = payload["data"]
    assert data["has_drift"] is True
    assert data["toml_tuning"] is None
    assert data["sdk_tuning"]["model_key"] == "ft_demo"
    assert data["sdk_tuning"]["supports_chaining"] is True
    assert data["tuning_mismatch"] is True


def test_contract_diff_reports_no_tuning_drift_when_toml_matches_sdk(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    tuning_config = TuningConfig.model_validate(_sdk_tuning_payload())
    write_project_config(
        tmp_path,
        ProjectConfig(
            capabilities={"vector": False, "tuning": True},
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "example": ModeContract(
                        inputs=[
                            InputDefinition(
                                name="message",
                                kind="text",
                                required=True,
                                description="Input message",
                            )
                        ],
                        outputs=[OutputDefinition(name="result", kind="text", required=True)],
                        description="Runs the demo text mode.",
                    )
                }
            ),
            tuning=tuning_config,
        ),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_contract",
        lambda project_dir, python_bin: _sdk_example_contract(),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_tuning_config",
        lambda project_dir: tuning_config,
    )

    result = runner.invoke(app_module.app, ["contract", "diff", "--json"])

    assert result.exit_code == 0
    data = json.loads(result.stdout)["data"]
    assert data["has_drift"] is False
    assert data["tuning_mismatch"] is False
    assert data["tuning_differences"] == []


def test_contract_diff_reports_tuning_parameter_mismatch(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    toml_tuning = TuningConfig.model_validate(_sdk_tuning_payload(learning_rate_default=0.2))
    sdk_tuning = TuningConfig.model_validate(_sdk_tuning_payload(learning_rate_default=0.1))
    write_project_config(
        tmp_path,
        ProjectConfig(
            capabilities={"vector": False, "tuning": True},
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "example": ModeContract(
                        inputs=[
                            InputDefinition(
                                name="message",
                                kind="text",
                                required=True,
                                description="Input message",
                            )
                        ],
                        outputs=[OutputDefinition(name="result", kind="text", required=True)],
                        description="Runs the demo text mode.",
                    )
                }
            ),
            tuning=toml_tuning,
        ),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_contract",
        lambda project_dir, python_bin: _sdk_example_contract(),
    )
    monkeypatch.setattr(
        app_module.contract_commands,
        "_extract_sdk_tuning_config",
        lambda project_dir: sdk_tuning,
    )

    result = runner.invoke(app_module.app, ["contract", "diff", "--json"])

    assert result.exit_code == 0
    data = json.loads(result.stdout)["data"]
    assert data["has_drift"] is True
    assert data["tuning_mismatch"] is True
    assert any(diff["field"] == "parameters" for diff in data["tuning_differences"])


def test_contract_sync_normalizes_sdk_messages_input_to_json() -> None:
    input_defs = app_module.contract_commands._input_defs_from_sdk(
        [
            {
                "name": "history",
                "kind": "messages",
                "required": False,
                "description": "Chat history",
            }
        ]
    )

    assert input_defs == [
        InputDefinition(
            name="history",
            kind="json",
            required=False,
            description="Chat history",
        )
    ]


def test_prompt_public_modes_passes_console_to_prompt_wrapper() -> None:
    console_marker = object()
    captured_console: list[Any] = []

    def fake_prompt_text(
        message: str,
        *,
        console: Any,
        default: str | None = None,
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> str:
        _ = message, default, show_header, title, subtitle, details
        captured_console.append(console)
        return "search"

    runtime = SimpleNamespace(
        require_tty=lambda: None,
        prompt_text=fake_prompt_text,
        console=console_marker,
    )

    result = app_module.contract_commands.prompt_public_modes(
        runtime=runtime,
        default=["generate"],
    )

    assert result == ["search"]
    assert captured_console == [console_marker]


def test_prompt_contract_config_search_only_skips_vector_prompt(
    monkeypatch: MonkeyPatch,
) -> None:
    def fake_prompt_public_modes(*, default: list[str]) -> list[str]:
        assert default == ["generate"]
        return ["search"]

    monkeypatch.setattr(app_module, "_prompt_public_modes", fake_prompt_public_modes)

    config = app_module._prompt_contract_config()

    assert config == ProjectConfig(
        schema_version=3,
        capabilities={"vector": False, "tuning": False},
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "search": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    outputs=[OutputDefinition(name="result", kind="text", required=True)],
                ),
            }
        ),
    )


def test_prompt_contract_config_generate_only_skips_vector_prompt(
    monkeypatch: MonkeyPatch,
) -> None:
    def fake_prompt_public_modes(*, default: list[str]) -> list[str]:
        assert default == ["generate"]
        return ["generate"]

    monkeypatch.setattr(app_module, "_prompt_public_modes", fake_prompt_public_modes)

    config = app_module._prompt_contract_config()

    assert config == ProjectConfig(
        schema_version=3,
        capabilities={"vector": False, "tuning": False},
        resources=ResourceConfig(vector_db=False),
        modes=ModesConfig(
            {
                "generate": ModeContract(
                    inputs=[InputDefinition(name="text", kind="text", required=True)],
                    outputs=[OutputDefinition(name="result", kind="text", required=True)],
                ),
            }
        ),
    )


def test_contract_show_resolved_defaults_to_generate(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".aimp").mkdir()
    (tmp_path / "app").mkdir()
    (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).write_text(
        "schema_version = 3\n\n"
        "[capabilities]\n"
        "vector = false\n"
        "tuning = false\n\n"
        "[modes.generate]\n"
        "enabled = true\n"
        "\n[[modes.generate.inputs]]\n"
        'name = "text"\n'
        'kind = "text"\n'
        "required = true\n\n"
        "[[modes.generate.outputs]]\n"
        'name = "result"\n'
        'kind = "text"\n'
        "required = true\n",
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["contract", "show", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["resources"]["vector_db"] is False
    assert "modes" in payload["data"]
    assert payload["data"]["modes"]["generate"]["inputs"] == [
        {"name": "text", "kind": "text", "required": True, "description": "", "multiple": False}
    ]


def test_contract_validate_includes_publish_defaults(
    tmp_path: Path, monkeypatch: MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".aimp").mkdir()
    (tmp_path / PROJECT_CONFIG_RELATIVE_PATH).write_text(
        "schema_version = 3\n\n"
        "[capabilities]\n"
        "vector = false\n"
        "tuning = false\n\n"
        "[modes.generate]\n"
        "enabled = true\n"
        "\n[[modes.generate.inputs]]\n"
        'name = "text"\n'
        'kind = "text"\n'
        "required = true\n\n"
        "[[modes.generate.outputs]]\n"
        'name = "result"\n'
        'kind = "text"\n'
        "required = true\n",
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["contract", "validate", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert "modes" in payload["data"]


def test_contract_migrate_command_removed(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "aimp.config.toml").write_text(
        '[interface.input]\nprimary = "text"\nattachments = ["image"]\n\n'
        '[interface.output]\nprimary = "text"\nattachments = []\n\n'
        '[capabilities]\nactions = ["search"]\n',
        encoding="utf-8",
    )

    result = runner.invoke(app_module.app, ["contract", "migrate", "--json"])

    assert result.exit_code != 0
    assert "No such command 'migrate'" in result.stdout


def test_publish_configuration_wizard_uses_hardware_catalog_for_margin_context(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    prompt_values = iter(
        [
            "Demo Model",
            "agents, codex",
            "studio/article.mdx",
            "0.25",
        ]
    )

    class FakeGateway:
        def get_publish_metadata(self) -> Any:
            return SimpleNamespace(
                hardware_tiers=[
                    SimpleNamespace(
                        id="cpu-basic",
                        label="CPU Basic",
                        description="CPU tier",
                        base_cost_hourly=0.05,
                    ),
                    SimpleNamespace(
                        id="gpu-t4",
                        label="NVIDIA T4",
                        description="GPU tier",
                        base_cost_hourly=0.50,
                    ),
                ],
                platform_fee_pct=0.3,
            )

    recorded_titles: list[str] = []
    recorded_defaults: list[str | None] = []

    def fake_prompt_text(
        message: str,
        console: Any,
        default: str | None = None,
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> str:
        _ = console, show_header, subtitle, details
        recorded_titles.append(title or message)
        recorded_defaults.append(default)
        return next(prompt_values)

    monkeypatch.setattr(
        publish_config_module,
        "prompt_text",
        fake_prompt_text,
    )
    monkeypatch.setattr(
        publish_config_module,
        "select_menu",
        lambda sections, show_header=True, title=None, subtitle=None, details=None: next(
            option for option in sections[0].options if option.key == "private"
        ),
    )

    def fake_confirm_action(
        message: str,
        console: Any,
        default: bool = True,
        confirm_label: str = "Confirm",
        cancel_label: str = "Cancel",
        confirm_description: str = "Proceed with this action.",
        cancel_description: str = "Return without making changes.",
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> bool:
        _ = (
            message,
            console,
            default,
            confirm_label,
            cancel_label,
            confirm_description,
            cancel_description,
            show_header,
            title,
            subtitle,
            details,
        )
        return True

    monkeypatch.setattr(
        publish_config_module,
        "confirm_action",
        fake_confirm_action,
    )

    config = publish_config_module.run_publish_configuration_wizard(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        existing_config=None,
        console=app_module.console,
        interactive_terminal=True,
    )

    serialized = config.model_dump(exclude_none=True)
    assert "hardware" not in serialized
    assert config.pricing == {"developer_margin": 0.25}
    assert config.studio.visibility == "private"
    assert recorded_titles == [
        "Model Name",
        "Tags",
        "Article Path",
        "Developer Margin",
    ]
    assert recorded_defaults[0] is None


def test_main_without_args_launches_interactive_on_tty(monkeypatch: MonkeyPatch) -> None:
    fake_command = FakeCommand()
    interactive_calls: list[None] = []

    def fake_interactive_launcher() -> None:
        interactive_calls.append(None)

    monkeypatch.setattr(sys, "argv", ["ai"])
    monkeypatch.setattr(sys, "stdin", FakeTTYStream(is_tty=True))
    monkeypatch.setattr(sys, "stdout", FakeTTYStream(is_tty=True))
    monkeypatch.setattr(app_module, "get_command", lambda _app: fake_command)
    monkeypatch.setattr(app_module, "interactive_launcher", fake_interactive_launcher)

    app_module.main()

    assert interactive_calls == [None]
    assert fake_command.calls == []


def test_main_without_args_prints_help_without_tty(monkeypatch: MonkeyPatch) -> None:
    fake_command = FakeCommand()

    monkeypatch.setattr(sys, "argv", ["ai"])
    monkeypatch.setattr(sys, "stdin", FakeTTYStream(is_tty=False))
    monkeypatch.setattr(sys, "stdout", FakeTTYStream(is_tty=False))
    monkeypatch.setattr(app_module, "get_command", lambda _app: fake_command)

    app_module.main()

    assert fake_command.calls == [{"args": ["--help"], "prog_name": "ai", "standalone_mode": False}]


def test_init_requires_repo_aligned_cli(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "_require_repo_aligned_cli",
        lambda command_name: (_ for _ in ()).throw(
            app_module.click.ClickException(f"blocked:{command_name}")
        ),
    )

    result = runner.invoke(app_module.app, ["init", "demo-model"])

    assert result.exit_code == 1
    assert "blocked:init" in result.stdout


def test_push_requires_repo_aligned_cli(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setattr(
        app_module,
        "_require_repo_aligned_cli",
        lambda command_name: (_ for _ in ()).throw(
            app_module.click.ClickException(f"blocked:{command_name}")
        ),
    )

    result = runner.invoke(app_module.app, ["push"])

    assert result.exit_code == 1
    assert "blocked:push" in result.stdout


def test_require_repo_aligned_cli_error_includes_absolute_project_path(
    monkeypatch: MonkeyPatch, tmp_path: Path
) -> None:
    """Stale-CLI hint must use resolved paths so it works when cwd is a subfolder (e.g. agents/)."""
    repo = tmp_path / "monorepo"
    for rel in (
        "packages/python/cli/pyproject.toml",
        "packages/python/framework/pyproject.toml",
        "packages/python/sdk/pyproject.toml",
    ):
        p = repo / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("[project]\nname = 'stub'\n", encoding="utf-8")
    (repo / "agents").mkdir()
    monkeypatch.chdir(repo / "agents")
    monkeypatch.setattr(app_module, "_active_cli_matches_repo_snapshot", lambda _root: False)

    with pytest.raises(app_module.click.ClickException) as excinfo:
        app_module._require_repo_aligned_cli("init")

    msg = excinfo.value.format_message()
    cli_project = (repo / "packages" / "python" / "cli").resolve()
    scripts_ai = (repo / "scripts" / "ai").resolve()
    assert str(cli_project) in msg
    assert f"uv run --project {cli_project}" in msg
    assert str(scripts_ai) in msg
    assert f"uv tool install {cli_project}" in msg


def test_launcher_model_actions_prompt_for_slug(monkeypatch: MonkeyPatch) -> None:
    inspect_calls: list[dict[str, Any]] = []
    pull_calls: list[dict[str, Any]] = []
    captured_callbacks: list[Any] = []

    monkeypatch.setattr(app_module, "model_inspect", lambda **kwargs: inspect_calls.append(kwargs))
    monkeypatch.setattr(app_module, "model_pull", lambda **kwargs: pull_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    inspect_result = callbacks.inspect_model("demo-model")
    pull_result = callbacks.pull_model("demo-model")

    assert inspect_calls == [
        {
            "slug": "demo-model",
            "asset_id": None,
            "modes": None,
            "gateway": None,
            "api_key": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(inspect_result, LauncherActionResult)
    assert inspect_result.title == "Inspect Model"
    assert pull_calls == [
        {
            "slug": "demo-model",
            "asset_id": None,
            "gateway": None,
            "api_key": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(pull_result, LauncherActionResult)
    assert pull_result.title == "Pull Metadata"


def test_launcher_configure_publish_dispatches_to_push_configure(
    monkeypatch: MonkeyPatch,
) -> None:
    """Interactive launcher wraps project settings edits as push --configure."""
    captured_callbacks: list[Any] = []
    push_calls: list[dict[str, Any]] = []

    monkeypatch.setattr(app_module, "push", lambda **kwargs: push_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    publish_result = callbacks.configure_publish()

    assert isinstance(publish_result, LauncherActionResult)
    assert publish_result.title == "Configure Publish"
    assert push_calls == [
        {
            "gateway": None,
            "api_key": None,
            "slug": None,
            "hardware": None,
            "parallel": 3,
            "configure": True,
            "configure_section": None,
            "force": False,
            "detach": False,
            "verbose": False,
            "python_bin": None,
            "json_output": False,
            "debug": False,
        }
    ]


def test_launcher_publish_project_dispatches_to_push_with_saved_hardware_resolution(
    monkeypatch: MonkeyPatch,
) -> None:
    captured_callbacks: list[Any] = []
    push_calls: list[dict[str, Any]] = []

    monkeypatch.setattr(app_module, "push", lambda **kwargs: push_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    publish_result = callbacks.publish_project()

    assert isinstance(publish_result, LauncherActionResult)
    assert publish_result.title == "Publish Project"
    assert push_calls == [
        {
            "gateway": None,
            "api_key": None,
            "slug": None,
            "hardware": None,
            "parallel": 3,
            "configure": False,
            "force": False,
            "detach": False,
            "verbose": False,
            "python_bin": None,
            "json_output": False,
            "debug": False,
        }
    ]


def test_fine_tune_get_human_output_shows_publishable_derived_model_hints(
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeFineTuneGateway)

    result = runner.invoke(
        app_module.app,
        [
            "fine-tune",
            "get",
            "--job",
            "job-1",
        ],
    )

    assert result.exit_code == 0
    assert "Derived model slug" in result.stdout
    assert "vision-pro-tuned" in result.stdout
    assert "ai model inspect --slug vision-pro-tuned" in result.stdout
    assert 'mode="example"' in result.stdout


def test_model_inspect_human_output_surfaces_readiness_and_mode_specific_rates(
    monkeypatch: MonkeyPatch,
) -> None:
    class FakeModelInspectGateway:
        def __init__(self, *args: object, **kwargs: object) -> None:
            self.closed = False

        def close(self) -> None:
            self.closed = True

        def get_model(self, slug: str) -> Any:
            return SimpleNamespace(id="model-1", slug=slug)

        def get_studio_model(self, model_id: str) -> Any:
            assert model_id == "model-1"
            return SimpleNamespace(
                id=model_id,
                slug="claude-ft-15462071",
                name="Claude FT",
                status="live",
                version="1.0.0",
                tuning_supported=True,
                tuning_schema=None,
                tuning_artifacts=None,
                tuning_metrics=None,
                supports_chaining=False,
                supported_hardware_tiers=["cpu-basic"],
                selected_hardware_tier="cpu-basic",
                hardware_tier="cpu-basic",
                pricing={"effective_customer_price_per_hour": 3.0},
                execution={"modes": ["example"]},
                readiness={
                    "is_ready": False,
                    "blocking_reasons": ["missing_active_rate_for_mode:example"],
                },
                mode_readiness={"example": {"declared": True, "implemented": True, "reason": None}},
                usable_modes=[],
                unusable_modes={
                    "example": ["missing_active_rate_for_mode:example"],
                },
                studio={},
            )

        def get_studio_model_analytics(self, model_id: str) -> dict[str, Any]:
            assert model_id == "model-1"
            return {"model_size_bytes": 1024, "layer_pool": {}}

        def get_model_rates(self, model_id: str, actions: list[str]) -> dict[str, Any]:
            assert model_id == "model-1"
            assert actions == ["example"]
            return {
                "model_id": model_id,
                "rates": [],
                "missing_rates": [
                    {"operation": "example", "reason": "missing_active_rate_for_mode:example"}
                ],
            }

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeModelInspectGateway)

    result = runner.invoke(
        app_module.app,
        [
            "model",
            "inspect",
            "--slug",
            "claude-ft-15462071",
        ],
    )

    assert result.exit_code == 0
    assert "READINESS" in result.stdout
    assert "Readiness" in result.stdout
    assert "not ready" in result.stdout
    assert "Usable modes" in result.stdout
    assert "Blocked modes" in result.stdout
    assert "missing_active_rate_for_mode:example" in result.stdout


def test_publish_remote_slug_path_uses_gateway_publish_without_local_build(
    monkeypatch: MonkeyPatch,
) -> None:
    class FakeRemotePublishGateway:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            _ = args, kwargs

        def publish_model_by_slug(self, slug: str) -> PublishResponse:
            assert slug == "vision-pro-tuned"
            return PublishResponse(
                id="derived-1",
                slug=slug,
                visibility="public",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/vision-pro-tuned",
            )

        def close(self) -> None:
            return None

    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", FakeRemotePublishGateway)

    result = runner.invoke(
        app_module.app,
        [
            "push",
            "--slug",
            "vision-pro-tuned",
            "--json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["slug"] == "vision-pro-tuned"
    assert payload["data"]["visibility"] == "public"


def test_model_pull_fails_closed_when_remote_hardware_tiers_are_missing(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    class IncompleteModelDetail:
        id = "asset-1"
        slug = "demo-model"

        def model_dump(self) -> dict[str, Any]:
            return {
                "id": self.id,
                "slug": self.slug,
                "name": "Demo Model",
                "visibility": "private",
                "studio": {},
                "pricing": {"developer_margin": 0.0},
                "hardware_tier": "cpu-basic",
            }

    class IncompleteModelGateway:
        def __init__(self, *args: object, **kwargs: object) -> None:
            _ = args, kwargs

        def close(self) -> None:
            return None

        def get_model(self, slug: str) -> Any:
            return SimpleNamespace(id="asset-1", slug=slug)

        def get_studio_model(self, model_id: str) -> Any:
            assert model_id == "asset-1"
            return IncompleteModelDetail()

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        app_module,
        "resolve_auth_context",
        lambda **_kwargs: SimpleNamespace(api_key="pk_test", gateway_url="http://localhost:8080"),
    )
    monkeypatch.setattr(app_module, "GatewayClient", IncompleteModelGateway)

    result = runner.invoke(
        app_module.app,
        [
            "model",
            "pull",
            "--slug",
            "demo-model",
            "--json",
        ],
    )

    assert result.exit_code == 6
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "remote_publish_metadata_invalid"
    assert "selected_hardware_tier" in payload["error"]["message"]


def test_interactive_launcher_delegates_to_shared_flow(monkeypatch: MonkeyPatch) -> None:
    captured_calls: list[dict[str, Any]] = []

    def fake_launcher_flow(*, console: Any, config_store: Any, callbacks: Any) -> None:
        captured_calls.append(
            {
                "console": console,
                "config_store": config_store,
                "callbacks": callbacks,
            }
        )

    monkeypatch.setattr(app_module, "run_interactive_launcher_flow", fake_launcher_flow)

    app_module.interactive_launcher()

    assert len(captured_calls) == 1
    assert captured_calls[0]["config_store"] is config_store


def test_launcher_init_prompts_for_name_and_confirms(monkeypatch: MonkeyPatch) -> None:
    init_calls: list[dict[str, Any]] = []
    captured_callbacks: list[Any] = []

    monkeypatch.setattr(app_module, "init", lambda **kwargs: init_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    callbacks.init_project("demo-model")

    assert init_calls == [
        {
            "name": "demo-model",
            "yes": True,
            "json_output": False,
            "debug": False,
        }
    ]


def test_launcher_login_prompts_for_gateway_and_api_key(monkeypatch: MonkeyPatch) -> None:
    config_store.clear()
    login_calls: list[dict[str, Any]] = []
    captured_callbacks: list[Any] = []

    monkeypatch.setattr(config_store, "get_gateway_url", lambda: "http://localhost:8080")
    monkeypatch.setattr(app_module, "login", lambda **kwargs: login_calls.append(kwargs))
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    result = callbacks.login("http://localhost:8080", "pk_live")

    assert login_calls == [
        {
            "gateway": "http://localhost:8080",
            "api_key": "pk_live",
            "stdin": False,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(result, LauncherActionResult)
    assert result.title == "Login"


def test_launcher_jobs_callbacks_use_structured_json_and_detail_output(
    monkeypatch: MonkeyPatch,
) -> None:
    captured_callbacks: list[Any] = []
    jobs_list_calls: list[dict[str, Any]] = []
    jobs_get_calls: list[dict[str, Any]] = []

    def fake_jobs_list(**kwargs: Any) -> None:
        jobs_list_calls.append(kwargs)
        config_module.console.print_json(
            json.dumps(
                {
                    "ok": True,
                    "data": {
                        "results": [
                            {
                                "job_type": "build",
                                "job_id": "build-1",
                                "model_slug": "vision-pro",
                                "status": "running",
                                "created_at": "2026-03-18T10:00:00Z",
                            }
                        ]
                    },
                }
            )
        )

    def fake_jobs_get(**kwargs: Any) -> None:
        jobs_get_calls.append(kwargs)
        config_module.console.print("Loaded build job build-1")

    monkeypatch.setattr(app_module, "jobs_list", fake_jobs_list)
    monkeypatch.setattr(app_module, "jobs_get", fake_jobs_get)
    monkeypatch.setattr(
        app_module,
        "run_interactive_launcher_flow",
        lambda *, console, config_store, callbacks: captured_callbacks.append(callbacks),
    )

    app_module.interactive_launcher()
    callbacks = captured_callbacks[0]
    jobs = callbacks.list_jobs("build")
    detail_result = callbacks.get_job_detail("build", "build-1")

    assert jobs_list_calls == [
        {
            "type": "build",
            "model": None,
            "status": None,
            "page": 1,
            "page_size": 20,
            "gateway": None,
            "api_key": None,
            "json_output": True,
            "debug": False,
        }
    ]
    assert isinstance(jobs, list)
    assert jobs == [
        LauncherJobItem(
            job_id="build-1",
            job_type="build",
            model_slug="vision-pro",
            status="running",
            created_at="2026-03-18T10:00:00Z",
        )
    ]
    assert jobs_get_calls == [
        {
            "type": "build",
            "job": "build-1",
            "gateway": None,
            "api_key": None,
            "json_output": False,
            "debug": False,
        }
    ]
    assert isinstance(detail_result, LauncherActionResult)
    assert detail_result.title == "Job Details"
    assert "Loaded build job build-1" in Text.from_ansi(detail_result.content).plain


def test_run_interactive_action_captures_human_output() -> None:
    result = app_module._run_interactive_action(
        title="Validate Contract",
        subtitle="Validate the local hidden contract file.",
        status="success",
        fallback_success_message="Validated contract.",
        callback=lambda: config_module.console.print("Validated: .aimp/project.toml"),
    )

    assert result is not None
    assert result.status == "success"
    assert "Validated: .aimp/project.toml" in result.content


def test_run_interactive_action_converts_exit_errors_to_detail_result() -> None:
    def failing_callback() -> None:
        config_module.console.print("Not authenticated. Run: ai login")
        raise typer.Exit(code=5)

    result = app_module._run_interactive_action(
        title="Publish Project",
        subtitle="Build and push the current local project.",
        status="success",
        fallback_success_message="Publish completed.",
        callback=failing_callback,
    )

    assert result is not None
    assert result.status == "error"
    assert "Not authenticated. Run: ai login" in result.content
