"""Tests for Gateway->CLI contract artifact verification tooling."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
VERIFY_SCRIPT = REPO_ROOT / "cli" / "scripts" / "verify_gateway_contract_artifacts.py"
REQUIRED_ARTIFACTS: tuple[str, ...] = (
    "gateway/openapi/cli_contract_openapi.json",
    "packages/python/cli/aimp_cli/generated/gateway_contracts/models.py",
    "packages/python/cli/aimp_cli/generated/gateway_contracts/__init__.py",
    "packages/python/cli/aimp_cli/generated/__init__.py",
)


def _run_git(*, repo_root: Path, args: list[str]) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def _init_repo_with_artifacts(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    _run_git(repo_root=repo_root, args=["init"])
    _run_git(repo_root=repo_root, args=["config", "user.name", "test"])
    _run_git(repo_root=repo_root, args=["config", "user.email", "test@example.com"])

    for rel_path in REQUIRED_ARTIFACTS:
        artifact_path = repo_root / rel_path
        artifact_path.parent.mkdir(parents=True, exist_ok=True)
        artifact_path.write_text("generated\n", encoding="utf-8")

    _run_git(repo_root=repo_root, args=["add", "."])
    _run_git(repo_root=repo_root, args=["commit", "-m", "init"])
    return repo_root


def _run_verifier(*, repo_root: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(VERIFY_SCRIPT), "--repo-root", str(repo_root)],
        check=False,
        text=True,
        capture_output=True,
    )


def test_verify_gateway_contract_artifacts_passes_when_clean(tmp_path: Path) -> None:
    repo_root = _init_repo_with_artifacts(tmp_path)
    result = _run_verifier(repo_root=repo_root)
    assert result.returncode == 0
    assert result.stderr == ""


def test_verify_gateway_contract_artifacts_fails_when_modified(tmp_path: Path) -> None:
    repo_root = _init_repo_with_artifacts(tmp_path)
    (repo_root / REQUIRED_ARTIFACTS[0]).write_text("drifted\n", encoding="utf-8")

    result = _run_verifier(repo_root=repo_root)
    assert result.returncode == 1
    assert "drift detected" in result.stderr.lower()


def test_verify_gateway_contract_artifacts_fails_when_missing(tmp_path: Path) -> None:
    repo_root = _init_repo_with_artifacts(tmp_path)
    (repo_root / REQUIRED_ARTIFACTS[1]).unlink()

    result = _run_verifier(repo_root=repo_root)
    assert result.returncode == 1
    assert "missing required generated artifacts" in result.stderr.lower()


def test_verify_gateway_contract_artifacts_fails_when_untracked(tmp_path: Path) -> None:
    repo_root = _init_repo_with_artifacts(tmp_path)
    _run_git(repo_root=repo_root, args=["rm", "--cached", REQUIRED_ARTIFACTS[2]])

    result = _run_verifier(repo_root=repo_root)
    assert result.returncode == 1
    assert "required artifacts are untracked" in result.stderr.lower()


def test_verify_gateway_contract_artifacts_fails_when_staged_drift(tmp_path: Path) -> None:
    repo_root = _init_repo_with_artifacts(tmp_path)
    staged_path = repo_root / REQUIRED_ARTIFACTS[3]
    staged_path.write_text("staged-drift\n", encoding="utf-8")
    _run_git(repo_root=repo_root, args=["add", REQUIRED_ARTIFACTS[3]])

    result = _run_verifier(repo_root=repo_root)
    assert result.returncode == 1
    assert "staged contract artifact drift detected" in result.stderr.lower()
