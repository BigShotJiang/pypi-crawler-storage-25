"""Regression tests for on-disk model project layout validation."""

from __future__ import annotations

from pathlib import Path

import pytest
from pytest import MonkeyPatch

from aimp_cli.core.errors import CliError
from aimp_cli.operations.publish.layout import validate_model_project_layout


def test_validate_layout_rejects_root_agent_py(tmp_path: Path) -> None:
    (tmp_path / "agent.py").write_text("x", encoding="utf-8")
    with pytest.raises(CliError, match="Unsupported project layout"):
        validate_model_project_layout(tmp_path)


def test_validate_layout_rejects_engine_and_vectors(tmp_path: Path) -> None:
    (tmp_path / "engine.py").write_text("x", encoding="utf-8")
    with pytest.raises(CliError, match="Unsupported project layout"):
        validate_model_project_layout(tmp_path)


def test_validate_layout_rejects_workers_and_models_dirs(tmp_path: Path) -> None:
    (tmp_path / "workers").mkdir()
    (tmp_path / "models").mkdir()
    with pytest.raises(CliError, match="Unsupported project layout"):
        validate_model_project_layout(tmp_path)


def test_validate_layout_accepts_minimal_valid_tree(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    from aimp_cli.domain.project import create_project_files

    monkeypatch.chdir(tmp_path)
    project_dir = create_project_files("demo-model")
    validate_model_project_layout(project_dir)


def test_scaffold_includes_internal_layout_and_tests(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    from aimp_cli.domain.project import create_project_files

    monkeypatch.chdir(tmp_path)
    project_dir = create_project_files("demo-model")
    assert (project_dir / "main.py").is_file()
    assert (project_dir / "internal" / "loader.py").is_file()
    assert (project_dir / "internal" / "inference.py").is_file()
    assert not (project_dir / "model.py").exists()
    assert not (project_dir / "core").exists()
    assert (project_dir / "tests" / "test_model.py").is_file()
    assert not (project_dir / "engine.py").exists()
    assert not (project_dir / "vectors.py").exists()
