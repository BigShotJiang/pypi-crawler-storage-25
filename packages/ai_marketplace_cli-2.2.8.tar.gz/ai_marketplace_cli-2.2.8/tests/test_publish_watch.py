"""Unit tests for publish watch helpers."""

from __future__ import annotations

from aimp_cli.utils.publish_watch import (
    effective_last_progress_at,
    merge_publish_watch_display_payload,
    publish_stage_display_name,
)


def test_effective_last_progress_at_uses_group_field_when_present() -> None:
    payload = {"last_progress_at": "2026-01-15T12:00:00+00:00", "child_jobs": []}
    assert effective_last_progress_at(payload) == "2026-01-15T12:00:00+00:00"


def test_effective_last_progress_at_picks_latest_child_timestamp() -> None:
    payload = {
        "child_jobs": [
            {"last_progress_at": "2026-01-15T12:00:00+00:00"},
            {"last_progress_at": "2026-01-15T12:05:00+00:00"},
        ],
    }
    assert effective_last_progress_at(payload) == "2026-01-15T12:05:00+00:00"


def test_merge_publish_watch_display_payload_injects_effective_progress() -> None:
    payload = {
        "status": "running",
        "child_jobs": [{"last_progress_at": "2026-01-15T12:05:00+00:00"}],
    }
    merged = merge_publish_watch_display_payload(payload)
    assert merged["last_progress_at"] == "2026-01-15T12:05:00+00:00"


def test_publish_stage_display_name_maps_known_stages_without_debug() -> None:
    assert publish_stage_display_name("release_bundle_prepare", debug=False) == (
        "Preparing release bundle"
    )
    assert publish_stage_display_name("runtime_matrix_build", debug=False) == (
        "Runtime matrix build"
    )


def test_publish_stage_display_name_preserves_raw_when_debug() -> None:
    assert publish_stage_display_name("release_bundle_prepare", debug=True) == (
        "release_bundle_prepare"
    )


def test_publish_stage_display_name_title_cases_unknown_stages() -> None:
    assert publish_stage_display_name("custom_phase_name", debug=False) == (
        "Custom Phase Name"
    )
