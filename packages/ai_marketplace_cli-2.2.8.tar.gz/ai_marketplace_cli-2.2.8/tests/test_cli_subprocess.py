"""Subprocess tests for the installed CLI surface."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

CLI_ROOT = Path(__file__).resolve().parents[1]

# `uv run pytest` often runs tests with the system interpreter while dependencies
# (e.g. typer) live in the project `.venv`. Prefer the local venv for subprocess checks.
_VENV_PYTHON = CLI_ROOT / ".venv" / "bin" / "python3"


def _cli_python() -> Path:
    if _VENV_PYTHON.is_file():
        return _VENV_PYTHON
    return Path(sys.executable)


def _run_cli(
    args: list[str],
    *,
    env: dict[str, str] | None = None,
    stdin: int | None = None,
) -> subprocess.CompletedProcess[str]:
    command = [str(_cli_python()), "-m", "aimp_cli", *args]
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        command,
        cwd=CLI_ROOT,
        env=merged_env,
        stdin=stdin,
        capture_output=True,
        text=True,
        check=False,
    )


def test_help_commands_exit_zero() -> None:
    for args in (["--help"], ["push", "--help"], ["model", "inspect", "--help"]):
        result = _run_cli(args)
        assert result.returncode == 0, result.stderr
        assert "Usage:" in result.stdout


def test_module_without_tty_prints_help() -> None:
    result = _run_cli([], stdin=subprocess.DEVNULL)
    assert result.returncode == 0, result.stderr
    assert "Usage:" in result.stdout


def test_auth_json_no_credentials_returns_status_payload(tmp_path: Path) -> None:
    result = _run_cli(["auth", "--json"], env={"HOME": str(tmp_path)})
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["authenticated"] is False
    assert payload["data"]["reason"] == "no_credentials"


def test_auth_json_unreachable_gateway_exits_five(tmp_path: Path) -> None:
    result = _run_cli(
        ["auth", "--json", "--gateway", "http://127.0.0.1:9", "--api-key", "pk_test"],
        env={"HOME": str(tmp_path)},
    )
    assert result.returncode == 5
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "gateway_unreachable"
    assert payload["error"]["retryable"] is True


def test_model_inspect_missing_selector_exits_two(tmp_path: Path) -> None:
    result = _run_cli(
        ["model", "inspect", "--json"],
        env={"HOME": str(tmp_path)},
    )
    assert result.returncode == 2
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "missing_model_selector"
