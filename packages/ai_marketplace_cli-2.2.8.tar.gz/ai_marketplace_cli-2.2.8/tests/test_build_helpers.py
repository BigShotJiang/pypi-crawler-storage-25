"""Tests for Docker build-context resolution and publish validation."""

from __future__ import annotations

from pathlib import Path

import pytest

from aimp_cli.core.errors import CliError
from aimp_cli.domain.project import (
    MODEL_RUNTIME_DOCKERFILE,
    extract_docker_context_sources,
    resolve_docker_build_spec,
    validate_publish_runtime_layout,
)
from aimp_cli.domain.project_config import ProjectConfig
from aimp_cli.operations.publish.layout import validate_publish_model_contract


def test_extract_docker_context_sources_from_dockerfile(tmp_path: Path) -> None:
    project_dir = tmp_path / "qa" / "codex"
    project_dir.mkdir(parents=True)
    (tmp_path / "shared").mkdir()
    (tmp_path / "shared" / "requirements.txt").write_text("requests\n", encoding="utf-8")
    (project_dir / "Dockerfile").write_text(
        "FROM python:3.13-slim\nCOPY shared/requirements.txt /app/requirements.txt\n",
        encoding="utf-8",
    )
    sources = extract_docker_context_sources(
        (project_dir / "Dockerfile").read_text(encoding="utf-8")
    )
    assert sources == ["shared/requirements.txt"]


def test_resolve_docker_build_spec_fails_without_runtime_dockerfile(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\nversion='0.1.0'\n", encoding="utf-8")
    with pytest.raises(CliError) as exc:
        resolve_docker_build_spec(tmp_path)
    assert exc.value.code == "publish_runtime_dockerfile_missing"


def test_resolve_docker_build_spec_fails_without_runtime_pyproject(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text("FROM python:3.11-slim\n", encoding="utf-8")
    with pytest.raises(CliError) as exc:
        resolve_docker_build_spec(tmp_path)
    assert exc.value.code == "publish_runtime_pyproject_missing"


def test_resolve_docker_build_spec_nested_runtime_path_is_ignored(tmp_path: Path) -> None:
    """Only project-root ``runtime/Dockerfile`` is used for publish."""
    project_dir = tmp_path / "agents" / "demo"
    runtime_dir = project_dir / "models" / "demo_model" / "runtime"
    runtime_dir.mkdir(parents=True)
    (runtime_dir / "Dockerfile").write_text("FROM python:3.11-slim\n", encoding="utf-8")

    with pytest.raises(CliError) as exc:
        resolve_docker_build_spec(project_dir)
    assert exc.value.code == "publish_runtime_dockerfile_missing"


def test_resolve_docker_build_spec_returns_model_runtime_when_complete(tmp_path: Path) -> None:
    root = tmp_path / "my-model"
    root.mkdir()
    (root / "runtime").mkdir()
    (root / "runtime" / "Dockerfile").write_text("FROM python:3.11-slim\nCOPY . .\n", encoding="utf-8")
    (root / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )

    context, dockerfile = resolve_docker_build_spec(root)

    assert context == root.resolve()
    assert dockerfile == MODEL_RUNTIME_DOCKERFILE


def test_validate_publish_runtime_layout_model_runtime_without_pyproject_fails(
    tmp_path: Path,
) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\nCOPY main.py .\n", encoding="utf-8"
    )
    (tmp_path / "main.py").write_text("x=1\n", encoding="utf-8")
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_pyproject_missing"


def test_validate_publish_runtime_layout_copy_outside_context_fails(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\nCOPY ../evil.txt /app/evil.txt\n", encoding="utf-8"
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_dockerfile_copy_outside_context"


def test_validate_publish_runtime_layout_absolute_copy_fails(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\nCOPY /etc/hosts /app/hosts\n", encoding="utf-8"
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_dockerfile_copy_outside_context"


def test_validate_publish_runtime_layout_accepts_valid_model_runtime(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\n"
        "WORKDIR /app\n"
        "COPY runtime/pyproject.toml ./pyproject.toml\n"
        "RUN pip install --no-cache-dir .\n"
        "COPY . .\n",
        encoding="utf-8",
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    validate_publish_runtime_layout(
        project_dir=tmp_path,
        dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
        build_context=tmp_path,
    )


def test_validate_publish_runtime_layout_rejects_copy_runtime_dir_before_pip(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\n"
        "COPY runtime/ /app/runtime/\n"
        "RUN pip install --no-cache-dir /app/runtime\n",
        encoding="utf-8",
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_dockerfile_dependency_layer_copy_runtime_dir"


def test_validate_publish_runtime_layout_rejects_copy_aimp_before_pip(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\n"
        "COPY .aimp/project.toml /tmp/p.toml\n"
        "RUN pip install --no-cache-dir requests\n",
        encoding="utf-8",
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_dockerfile_dependency_layer_copy_aimp_dir"


def test_validate_publish_runtime_layout_rejects_missing_pip_install(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\nCOPY runtime/pyproject.toml ./pyproject.toml\nCOPY . .\n",
        encoding="utf-8",
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_dockerfile_missing_pip_install"


def test_validate_publish_runtime_layout_rejects_unsupported_dockerfile_path(
    tmp_path: Path,
) -> None:
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=".aimp/platform-root-runtime/Dockerfile",
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_dockerfile_path_unsupported"


def test_clip32_repo_runtime_layout_validates() -> None:
    repo_root = Path(__file__).resolve().parents[4]
    project_dir = repo_root / "agents" / "clip32"
    if not (project_dir / "runtime" / "Dockerfile").is_file():
        pytest.skip("agents/clip32 not present in this checkout")
    validate_publish_runtime_layout(
        project_dir=project_dir,
        dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
        build_context=project_dir,
    )


def test_clipo_repo_runtime_layout_validates() -> None:
    repo_root = Path(__file__).resolve().parents[4]
    project_dir = repo_root / "agents" / "clipo"
    if not (project_dir / "runtime" / "Dockerfile").is_file():
        pytest.skip("agents/clipo not present in this checkout")
    validate_publish_runtime_layout(
        project_dir=project_dir,
        dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
        build_context=project_dir,
    )


def test_clip32_runtime_dockerfile_does_not_bake_model_assets() -> None:
    """CLIP example prepares weights under artifacts/; Dockerfile must not download or bake weights."""
    repo_root = Path(__file__).resolve().parents[4]
    dockerfile = repo_root / "agents" / "clip32" / "runtime" / "Dockerfile"
    if not dockerfile.is_file():
        pytest.skip("agents/clip32/runtime/Dockerfile not present in this checkout")
    text = dockerfile.read_text(encoding="utf-8").lower()
    assert "from_pretrained" not in text
    assert "/opt/models" not in text


def test_clipo_runtime_dockerfile_does_not_bake_model_assets() -> None:
    repo_root = Path(__file__).resolve().parents[4]
    dockerfile = repo_root / "agents" / "clipo" / "runtime" / "Dockerfile"
    if not dockerfile.is_file():
        pytest.skip("agents/clipo/runtime/Dockerfile not present in this checkout")
    text = dockerfile.read_text(encoding="utf-8").lower()
    assert "bake_clipo" not in text
    assert "/opt/models" not in text


def test_validate_publish_runtime_layout_rejects_model_bake_run(tmp_path: Path) -> None:
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\n"
        "COPY runtime/pyproject.toml ./pyproject.toml\n"
        "RUN pip install --no-cache-dir .\n"
        'RUN python -c "from transformers import CLIPModel; CLIPModel.from_pretrained(\'x\')"\n',
        encoding="utf-8",
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "rt"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    with pytest.raises(CliError) as exc:
        validate_publish_runtime_layout(
            project_dir=tmp_path,
            dockerfile_relative=MODEL_RUNTIME_DOCKERFILE,
            build_context=tmp_path,
        )
    assert exc.value.code == "publish_runtime_dockerfile_from_pretrained"


def test_validate_publish_model_contract_requires_readmes(tmp_path: Path) -> None:
    (tmp_path / "artifacts").mkdir()
    (tmp_path / "artifacts" / ".keep").write_text("", encoding="utf-8")
    with pytest.raises(CliError) as exc:
        validate_publish_model_contract(
            project_dir=tmp_path,
            project_config=ProjectConfig(),
        )
    assert exc.value.code == "publish_artifacts_readme_missing"


def test_validate_publish_model_contract_accepts_scaffold_layout(tmp_path: Path) -> None:
    (tmp_path / "artifacts").mkdir()
    (tmp_path / "artifacts" / "README.md").write_text("# Artifacts\n", encoding="utf-8")
    (tmp_path / "artifacts" / "artifact.py").write_text(
        "def main():\n    pass\nif __name__ == '__main__': main()\n",
        encoding="utf-8",
    )
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "README.md").write_text("# Runtime\n", encoding="utf-8")
    validate_publish_model_contract(project_dir=tmp_path, project_config=ProjectConfig())


def test_validate_publish_model_contract_requires_artifact_entrypoint(tmp_path: Path) -> None:
    (tmp_path / "artifacts").mkdir()
    (tmp_path / "artifacts" / "README.md").write_text("# Artifacts\n", encoding="utf-8")
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "README.md").write_text("# Runtime\n", encoding="utf-8")
    with pytest.raises(CliError) as exc:
        validate_publish_model_contract(project_dir=tmp_path, project_config=ProjectConfig())
    assert exc.value.code == "publish_artifacts_entrypoint_missing"
