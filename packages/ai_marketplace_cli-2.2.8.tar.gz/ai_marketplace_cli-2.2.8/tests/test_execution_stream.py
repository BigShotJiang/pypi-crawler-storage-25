"""Tests for unified CLI job SSE helpers."""

from __future__ import annotations

import json
import time
from contextlib import contextmanager
from typing import Any

import pytest

from aimp_cli.core.config import build_command_context
from aimp_cli.core.errors import CliError, network_error
from aimp_cli.utils.execution_stream import (
    ExecutionStreamCallbacks,
    StreamGapConfig,
    StreamReconcileConfig,
    parse_execution_stream_events,
    watch_execution_stream,
)


def test_parse_execution_stream_events_supports_all_event_types_and_comments() -> None:
    """The SSE parser should decode all supported event frames and ignore comments."""
    context = build_command_context("job.stream", debug=False, json_output=True)
    snapshot_payload = {"job": {"job_id": "exec-1"}, "timeline_count": 0, "log_count": 0}
    status_payload = {
        "job_id": "exec-1",
        "job_type": "build",
        "status": "running",
    }
    timeline_payload = {
        "job_id": "exec-1",
        "job_type": "build",
        "offset": 0,
        "count": 1,
        "items": [{"status": "running"}],
    }
    logs_payload = {
        "job_id": "exec-1",
        "job_type": "build",
        "offset": 0,
        "count": 1,
        "items": [{"message": "hello"}],
    }
    terminal_payload = {"job": {"job_id": "exec-1"}, "timeline_count": 1, "log_count": 1}
    lines = [
        ": keep-alive",
        "",
        "event: snapshot",
        f"data: {json.dumps(snapshot_payload)}",
        "",
        "event: status",
        f"data: {json.dumps(status_payload)}",
        "",
        "event: timeline",
        f"data: {json.dumps(timeline_payload)}",
        "",
        "event: logs",
        f"data: {json.dumps(logs_payload)}",
        "",
        "event: terminal",
        f"data: {json.dumps(terminal_payload)}",
        "",
    ]

    events = list(parse_execution_stream_events(lines, context=context))

    assert [event.event for event in events] == [
        "snapshot",
        "status",
        "timeline",
        "logs",
        "terminal",
    ]
    assert events[1].payload["status"] == "running"
    assert events[3].payload["items"][0]["message"] == "hello"


def test_watch_execution_stream_reconnects_once_without_replaying_seen_items(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Reconnect should dedupe already seen timeline/log entries across snapshots."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)
    seen_timeline: list[str] = []
    seen_logs: list[str] = []

    class _InterruptingIterator:
        def __init__(self, lines: list[str]) -> None:
            self._lines = iter(lines)

        def __iter__(self) -> _InterruptingIterator:
            return self

        def __next__(self) -> str:
            try:
                return next(self._lines)
            except StopIteration as exc:
                raise network_error(
                    "stream interrupted",
                    code="job_stream_unavailable",
                    request_id=context.request_id,
                ) from exc

    class _Gateway:
        def __init__(self) -> None:
            self.attempt = 0

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            self.attempt += 1
            if self.attempt == 1:
                yield _InterruptingIterator(
                    [
                        "event: snapshot",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job": {
                                        "job_id": job_id,
                                        "job_type": "build",
                                        "model_slug": "demo-model",
                                        "status": "running",
                                        "timeline": [{"status": "queued"}],
                                        "logs": [{"message": "first"}],
                                    },
                                    "timeline_count": 1,
                                    "log_count": 1,
                                }
                            )
                        ),
                        "",
                        "event: timeline",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "offset": 1,
                                    "count": 1,
                                    "items": [{"status": "running"}],
                                }
                            )
                        ),
                        "",
                        "event: logs",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "offset": 1,
                                    "count": 1,
                                    "items": [{"message": "warning"}],
                                }
                            )
                        ),
                        "",
                    ]
                )
                return

            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "running",
                                    "timeline": [
                                        {"status": "queued"},
                                        {"status": "running"},
                                    ],
                                    "logs": [
                                        {"message": "first"},
                                        {"message": "warning"},
                                    ],
                                },
                                "timeline_count": 2,
                                "log_count": 2,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "build",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "timeline": [
                                        {"status": "queued"},
                                        {"status": "running"},
                                    ],
                                    "logs": [
                                        {"message": "first"},
                                        {"message": "warning"},
                                        {"message": "final"},
                                    ],
                                },
                                "timeline_count": 2,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    job = watch_execution_stream(
        gateway=_Gateway(),
        job_id="exec-1",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_timeline=lambda items, _payload: seen_timeline.extend(
                str(item.get("status") or "") for item in items
            ),
            on_logs=lambda items, _payload: seen_logs.extend(
                str(item.get("message") or "") for item in items
            ),
        ),
    )

    assert job["status"] == "succeeded"
    assert seen_timeline == ["queued", "running"]
    assert seen_logs == ["first", "warning", "final"]


def test_watch_execution_stream_processes_fine_tune_logs_from_snapshot_and_terminal(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Fine-tune streams should surface logs via snapshot backfill and terminal delta."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)
    seen_logs: list[str] = []

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "running",
                                    "timeline": [{"status": "queued"}],
                                    "logs": [{"message": "Creating tuning study"}],
                                    "details": {"adapter_format": "lora"},
                                },
                                "timeline_count": 1,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "fine-tune",
                                    "model_slug": "vision-pro",
                                    "status": "succeeded",
                                    "timeline": [{"status": "queued"}, {"status": "succeeded"}],
                                    "logs": [
                                        {"message": "Creating tuning study"},
                                        {"message": "Fine-tune job succeeded"},
                                    ],
                                    "details": {"adapter_format": "lora"},
                                },
                                "timeline_count": 2,
                                "log_count": 2,
                            }
                        )
                    ),
                    "",
                ]
            )

    job = watch_execution_stream(
        gateway=_Gateway(),
        job_id="ft-1",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_logs=lambda items, _payload: seen_logs.extend(
                str(item.get("message") or "") for item in items
            )
        ),
    )

    assert job["status"] == "succeeded"
    assert seen_logs == ["Creating tuning study", "Fine-tune job succeeded"]


def test_watch_execution_stream_fails_after_second_stream_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A second SSE failure should surface the canonical job stream error."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            raise network_error(
                f"gateway offline for {job_id}",
                code="gateway_unreachable",
                request_id=context.request_id,
            )
            yield iter(())

    with pytest.raises(CliError) as exc_info:
        watch_execution_stream(
            gateway=_Gateway(),
            job_id="exec-2",
            context=context,
            max_stream_sessions=2,
        )

    assert exc_info.value.code == "job_stream_unavailable"
    assert exc_info.value.request_id == context.request_id
    assert exc_info.value.extra["job_id"] == "exec-2"


def test_watch_execution_stream_reconcile_still_running_after_stream_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """After SSE failure, REST reconcile should report active job, not generic stream error."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            raise network_error(
                "read timed out",
                code="job_stream_unavailable",
                request_id=context.request_id,
            )
            yield iter(())

    with pytest.raises(CliError) as exc_info:
        watch_execution_stream(
            gateway=_Gateway(),
            job_id="exec-recon-1",
            context=context,
            reconcile=StreamReconcileConfig(
                fetch=lambda: {
                    "job_type": "build",
                    "job": {
                        "job_id": "exec-recon-1",
                        "status": "running",
                        "model_slug": "m",
                    },
                },
                kind="execution",
                job_type_for_hint="build",
            ),
            max_stream_sessions=2,
        )

    assert exc_info.value.code == "job_stream_disconnected_active"
    assert "still running" in exc_info.value.message.lower()


def test_watch_execution_stream_reconcile_terminal_failed_execution(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """After SSE failure, reconcile should surface remote failure message."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            raise network_error(
                "read timed out",
                code="job_stream_unavailable",
                request_id=context.request_id,
            )
            yield iter(())

    with pytest.raises(CliError) as exc_info:
        watch_execution_stream(
            gateway=_Gateway(),
            job_id="exec-recon-2",
            context=context,
            reconcile=StreamReconcileConfig(
                fetch=lambda: {
                    "job_type": "build",
                    "job": {
                        "job_id": "exec-recon-2",
                        "status": "failed",
                        "error_message": "Docker cache export timed out",
                        "model_slug": "m",
                    },
                },
                kind="execution",
                job_type_for_hint="build",
            ),
            max_stream_sessions=2,
        )

    assert exc_info.value.code == "remote_job_failed"
    assert "Docker cache export timed out" in exc_info.value.message


def test_watch_execution_stream_reconcile_publish_failed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish reconcile should raise environment_error with build failure detail."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            raise network_error(
                "read timed out",
                code="job_stream_unavailable",
                request_id=context.request_id,
            )
            yield iter(())

    with pytest.raises(CliError) as exc_info:
        watch_execution_stream(
            gateway=_Gateway(),
            job_id="pb-1",
            context=context,
            reconcile=StreamReconcileConfig(
                fetch=lambda: {
                    "job_id": "pb-1",
                    "slug": "s",
                    "version": "1",
                    "status": "failed",
                    "error_message": "export bad",
                    "current_step_message": "image_build",
                },
                kind="publish",
            ),
            max_stream_sessions=2,
        )

    assert exc_info.value.code == "publish_build_failed"
    assert "image_build" in exc_info.value.message


def test_watch_execution_stream_reconcile_publish_canceling_still_active(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish reconcile must treat canceling like running (keep reconnecting until terminal)."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    context = build_command_context("job.watch", debug=False, json_output=False)

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            raise network_error(
                "read timed out",
                code="job_stream_unavailable",
                request_id=context.request_id,
            )
            yield iter(())

    with pytest.raises(CliError) as exc_info:
        watch_execution_stream(
            gateway=_Gateway(),
            job_id="pb-canceling",
            context=context,
            reconcile=StreamReconcileConfig(
                fetch=lambda: {
                    "job_id": "pb-canceling",
                    "slug": "s",
                    "version": "1",
                    "status": "canceling",
                    "current_step_message": "Canceling…",
                },
                kind="publish",
            ),
            max_stream_sessions=2,
        )

    assert exc_info.value.code == "job_stream_disconnected_active"
    assert "still running" in exc_info.value.message.lower()


def test_watch_execution_stream_gap_poll_publish_succeeds_without_second_sse(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """After EOF, REST heartbeat polling may observe terminal success before SSE reconnects."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    monkeypatch.setattr(
        "aimp_cli.utils.execution_stream._reconnect_delay_seconds", lambda _a: 0.01
    )
    context = build_command_context("publish.gap", debug=False, json_output=False)

    active_payload = {
        "job_id": "gap-ok",
        "slug": "m",
        "version": "1.0",
        "status": "running",
    }
    success_payload = {
        "job_id": "gap-ok",
        "slug": "m",
        "version": "1.0",
        "status": "succeeded",
    }
    fetch_count = 0

    def fetch() -> dict[str, Any]:
        nonlocal fetch_count
        fetch_count += 1
        if fetch_count == 1:
            return dict(active_payload)
        return dict(success_payload)

    terminal_seen: list[dict[str, Any]] = []

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            _ = job_id, kwargs
            yield iter([])

    result = watch_execution_stream(
        gateway=_Gateway(),
        job_id="gap-ok",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_terminal=lambda job: terminal_seen.append(dict(job)),
        ),
        reconcile=StreamReconcileConfig(fetch=fetch, kind="publish"),
        gap=StreamGapConfig(),
    )

    assert result["status"] == "succeeded"
    assert len(terminal_seen) == 1
    assert terminal_seen[0]["status"] == "succeeded"


def test_watch_execution_stream_gap_poll_streams_rest_logs_before_reconnect(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish REST heartbeat snapshots should stream log deltas during SSE gaps."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    monkeypatch.setattr(
        "aimp_cli.utils.execution_stream._reconnect_delay_seconds", lambda _a: 0.0
    )
    context = build_command_context("publish.gap.logs", debug=False, json_output=False)
    seen_logs: list[str] = []
    fetch_count = 0

    def fetch() -> dict[str, Any]:
        nonlocal fetch_count
        fetch_count += 1
        return {
            "job_id": "gap-logs",
            "slug": "m",
            "version": "1.0",
            "status": "running",
            "timeline": [{"event": "build"}],
            "logs": [
                {"message": "docker line 1"},
                {"message": "docker line 2"},
            ],
        }

    class _Gateway:
        def __init__(self) -> None:
            self.attempt = 0

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            self.attempt += 1
            _ = job_id
            if self.attempt == 1:
                yield iter([])
                return
            assert kwargs["log_offset"] == 2
            yield iter(
                [
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": "gap-logs",
                                    "slug": "m",
                                    "version": "1.0",
                                    "status": "succeeded",
                                    "timeline": [{"event": "build"}],
                                    "logs": [
                                        {"message": "docker line 1"},
                                        {"message": "docker line 2"},
                                        {"message": "final line"},
                                    ],
                                },
                                "timeline_count": 1,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    result = watch_execution_stream(
        gateway=_Gateway(),
        job_id="gap-logs",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_logs=lambda items, _payload: seen_logs.extend(
                str(item.get("message") or "") for item in items
            )
        ),
        reconcile=StreamReconcileConfig(fetch=fetch, kind="publish"),
        gap=StreamGapConfig(),
    )

    assert result["status"] == "succeeded"
    assert seen_logs == ["docker line 1", "docker line 2", "final line"]
    assert fetch_count == 1


def test_watch_execution_stream_gap_poll_terminal_streams_unseen_logs_first(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If REST reconcile observes terminal success, unseen logs should render first."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    monkeypatch.setattr(
        "aimp_cli.utils.execution_stream._reconnect_delay_seconds", lambda _a: 0.01
    )
    context = build_command_context("publish.gap.terminal", debug=False, json_output=False)
    observed: list[str] = []

    def fetch() -> dict[str, Any]:
        return {
            "job_id": "gap-terminal",
            "slug": "m",
            "version": "1.0",
            "status": "succeeded",
            "timeline": [{"event": "succeeded"}],
            "logs": [{"message": "final docker line"}],
        }

    class _Gateway:
        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            _ = job_id, kwargs
            yield iter([])

    result = watch_execution_stream(
        gateway=_Gateway(),
        job_id="gap-terminal",
        context=context,
        callbacks=ExecutionStreamCallbacks(
            on_logs=lambda items, _payload: observed.extend(
                str(item.get("message") or "") for item in items
            ),
            on_terminal=lambda job: observed.append(f"terminal:{job['status']}"),
        ),
        reconcile=StreamReconcileConfig(fetch=fetch, kind="publish"),
        gap=StreamGapConfig(),
    )

    assert result["status"] == "succeeded"
    assert observed == ["final docker line", "terminal:succeeded"]


def test_watch_execution_stream_gap_calls_on_stream_resumed_before_second_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When SSE reconnects after a gap, ``on_stream_resumed`` runs before consuming events."""
    monkeypatch.setattr(time, "sleep", lambda _s: None)
    monkeypatch.setattr(
        "aimp_cli.utils.execution_stream._reconnect_delay_seconds", lambda _a: 0.01
    )
    context = build_command_context("publish.gap2", debug=False, json_output=False)

    active_payload = {
        "job_id": "gap-rs",
        "slug": "m",
        "version": "1.0",
        "status": "running",
    }

    def fetch() -> dict[str, Any]:
        return dict(active_payload)

    resumed: list[str] = []

    class _Gateway:
        def __init__(self) -> None:
            self.attempt = 0

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            self.attempt += 1
            _ = job_id, kwargs
            if self.attempt == 1:
                yield iter([])
            else:
                yield iter(
                    [
                        "event: terminal",
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "job": {
                                        "job_id": "gap-rs",
                                        "slug": "m",
                                        "version": "1.0",
                                        "status": "succeeded",
                                        "timeline": [],
                                        "logs": [],
                                    },
                                    "timeline_count": 0,
                                    "log_count": 0,
                                }
                            )
                        ),
                        "",
                    ]
                )

    watch_execution_stream(
        gateway=_Gateway(),
        job_id="gap-rs",
        context=context,
        reconcile=StreamReconcileConfig(fetch=fetch, kind="publish"),
        gap=StreamGapConfig(
            on_stream_resumed=lambda: resumed.append("yes"),
        ),
    )

    assert resumed == ["yes"]
