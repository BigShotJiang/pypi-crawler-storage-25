"""Fine-tune dataset source tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aimp_cli.core.errors import CliError
from aimp_cli.operations.fine_tune.dataset_sources import (
    load_dataset_source,
    parse_column_mapping,
)
from aimp_cli.operations.fine_tune.workspace import create_tune_workspace

TEXT_SCHEMA = {
    "fields": [
        {"key": "prompt", "type": "text", "required": True, "multiple": False},
        {"key": "completion", "type": "text", "required": True, "multiple": False},
    ]
}


def test_jsonl_valid_records(tmp_path: Path) -> None:
    source = tmp_path / "train.jsonl"
    source.write_text('{"prompt":"hello","completion":"hi"}\n', encoding="utf-8")

    records = load_dataset_source(
        source_path=source,
        schema_contract=TEXT_SCHEMA,
        source_format=None,
    )

    assert records == [{"prompt": "hello", "completion": "hi"}]


def test_jsonl_malformed_line(tmp_path: Path) -> None:
    source = tmp_path / "train.jsonl"
    source.write_text('{"prompt":"hello"\n', encoding="utf-8")

    with pytest.raises(CliError, match="Malformed JSONL"):
        load_dataset_source(
            source_path=source,
            schema_contract=TEXT_SCHEMA,
            source_format=None,
        )


def test_csv_with_mapping(tmp_path: Path) -> None:
    source = tmp_path / "train.csv"
    source.write_text("input,output\nhello,hi\n", encoding="utf-8")

    records = load_dataset_source(
        source_path=source,
        schema_contract=TEXT_SCHEMA,
        source_format=None,
        mapping=parse_column_mapping(["prompt=input", "completion=output"]),
    )

    assert records == [{"prompt": "hello", "completion": "hi"}]


def test_missing_required_field(tmp_path: Path) -> None:
    source = tmp_path / "train.jsonl"
    source.write_text('{"prompt":"hello"}\n', encoding="utf-8")

    with pytest.raises(CliError, match="missing required field"):
        load_dataset_source(
            source_path=source,
            schema_contract=TEXT_SCHEMA,
            source_format=None,
        )


def test_unknown_field_rejected(tmp_path: Path) -> None:
    source = tmp_path / "train.jsonl"
    source.write_text(
        json.dumps({"prompt": "hello", "completion": "hi", "extra": "no"}) + "\n",
        encoding="utf-8",
    )

    with pytest.raises(CliError, match="unknown fields"):
        load_dataset_source(
            source_path=source,
            schema_contract=TEXT_SCHEMA,
            source_format=None,
        )


def test_missing_local_media_file(tmp_path: Path) -> None:
    source = tmp_path / "train.jsonl"
    source.write_text('{"image":"missing.png"}\n', encoding="utf-8")
    schema = {"fields": [{"key": "image", "type": "image", "required": True}]}

    with pytest.raises(CliError, match="file not found"):
        load_dataset_source(
            source_path=source,
            schema_contract=schema,
            source_format=None,
        )


def test_empty_dataset_rejected(tmp_path: Path) -> None:
    source = tmp_path / "train.jsonl"
    source.write_text("", encoding="utf-8")

    with pytest.raises(CliError, match="empty"):
        load_dataset_source(
            source_path=source,
            schema_contract=TEXT_SCHEMA,
            source_format=None,
        )


def test_workspace_generation_preserves_edited_data(tmp_path: Path) -> None:
    workspace = tmp_path / "ft-demo-tune"
    create_tune_workspace(
        workspace_dir=workspace,
        model_slug="ft-demo",
        schema_contract=TEXT_SCHEMA,
        parameters_contract={},
    )
    data_path = workspace / "data.jsonl"
    data_path.write_text('{"prompt":"custom","completion":"kept"}\n', encoding="utf-8")

    create_tune_workspace(
        workspace_dir=workspace,
        model_slug="ft-demo",
        schema_contract=TEXT_SCHEMA,
        parameters_contract={},
    )

    assert (workspace / "README.md").exists()
    assert (workspace / "tune.py").exists()
    assert (workspace / ".tuning" / "schema.json").exists()
    assert (workspace / ".tuning" / "generated.py").exists()
    assert (workspace / ".tuning" / "state.json").exists()
    assert data_path.read_text(encoding="utf-8") == '{"prompt":"custom","completion":"kept"}\n'
