"""Shared test bootstrap for CLI package tests."""

from __future__ import annotations

from pathlib import Path
import sys


REPO_ROOT = Path(__file__).resolve().parents[4]
FRAMEWORK_ROOT = REPO_ROOT / "packages" / "python" / "framework"
SDK_ROOT = REPO_ROOT / "packages" / "python" / "sdk"

for path in (FRAMEWORK_ROOT, SDK_ROOT):
    resolved = str(path)
    if resolved not in sys.path:
        sys.path.insert(0, resolved)
