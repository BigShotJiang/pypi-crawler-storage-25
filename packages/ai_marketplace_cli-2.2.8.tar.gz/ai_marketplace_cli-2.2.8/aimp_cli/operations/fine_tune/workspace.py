"""Customer fine-tune workspace generation and typed config loading."""

from __future__ import annotations

import json
import importlib.util
import sys
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from aimp_cli.core.errors import CliError, usage_error
from aimp_cli.domain.constants import (
    TUNING_HIDDEN_DIR_PATH,
    TUNING_HIDDEN_SCHEMA_FILE_NAME,
    TUNING_HIDDEN_STATE_FILE_NAME,
    TUNING_README_FILE_NAME,
)
from aimp_cli.domain.models import TuningSchemaConfig, TuningSchemaFieldConfig

TUNE_CONFIG_FILE_NAME = "tune.py"
TUNE_DATA_FILE_NAME = "data.jsonl"
TUNING_HIDDEN_GENERATED_FILE_NAME = "generated.py"


@dataclass(frozen=True)
class TuneConfigValue:
    """Resolved typed tune config loaded from `tune.py`."""

    model: str
    data: str
    mode: str
    max_trials: int
    manual_parameters: dict[str, Any]


def _workspace_state_template(*, model_slug: str) -> dict[str, Any]:
    return {
        "model": model_slug,
        "latest_job_id": None,
        "latest_status": None,
        "latest_output_model": None,
        "last_successful_output_model": None,
    }


def load_tune_workspace_state(workspace_dir: Path) -> dict[str, Any]:
    """Load workspace state from .tuning/state.json, defaulting when missing."""
    config = load_tune_config(workspace_dir)
    model_slug = config.model
    state_path = workspace_dir / TUNING_HIDDEN_DIR_PATH / TUNING_HIDDEN_STATE_FILE_NAME
    if not state_path.exists():
        return _workspace_state_template(model_slug=model_slug)
    try:
        payload = json.loads(state_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise usage_error(
            f"{state_path.name} is invalid JSON: {exc.msg}",
            code="invalid_tune_workspace",
        ) from exc
    if not isinstance(payload, dict):
        raise usage_error(
            f"{state_path.name} must be a JSON object.",
            code="invalid_tune_workspace",
        )
    normalized = _workspace_state_template(model_slug=model_slug)
    for key in (
        "latest_job_id",
        "latest_status",
        "latest_output_model",
        "last_successful_output_model",
    ):
        value = payload.get(key)
        normalized[key] = None if value is None else str(value)
    return normalized


def save_tune_workspace_state(workspace_dir: Path, state: dict[str, Any]) -> Path:
    """Persist workspace state into .tuning/state.json."""
    config = load_tune_config(workspace_dir)
    payload = _workspace_state_template(model_slug=config.model)
    for key in payload:
        if key == "model":
            continue
        value = state.get(key)
        payload[key] = None if value is None else str(value)
    tuning_dir = workspace_dir / TUNING_HIDDEN_DIR_PATH
    tuning_dir.mkdir(parents=True, exist_ok=True)
    state_path = tuning_dir / TUNING_HIDDEN_STATE_FILE_NAME
    state_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return state_path


def ensure_tune_workspace(workspace_dir: Path) -> dict[str, Any]:
    """Validate current directory as a tune workspace and return core metadata."""
    resolved = workspace_dir.expanduser().resolve()
    try:
        config = load_tune_config(resolved)
    except CliError as error:
        raise usage_error(
            (
                f"{resolved} is not a valid fine-tune workspace. "
                "Create one with: ai tune init ft-demo"
            ),
            code="invalid_tune_workspace",
            hint=error.message,
        ) from error
    schema_path = resolved / TUNING_HIDDEN_DIR_PATH / TUNING_HIDDEN_SCHEMA_FILE_NAME
    if not schema_path.exists() or not schema_path.is_file():
        raise usage_error(
            (
                f"{resolved} is not a valid fine-tune workspace: missing .tuning/schema.json. "
                "Create one with: ai tune init <model-slug>"
            ),
            code="invalid_tune_workspace",
        )
    generated_path = resolved / TUNING_HIDDEN_DIR_PATH / TUNING_HIDDEN_GENERATED_FILE_NAME
    if not generated_path.exists() or not generated_path.is_file():
        raise usage_error(
            (
                f"{resolved} is not a valid fine-tune workspace: missing .tuning/generated.py. "
                "Create one with: ai tune init <model-slug>"
            ),
            code="invalid_tune_workspace",
        )
    state = load_tune_workspace_state(resolved)
    return {
        "workspace_dir": resolved,
        "model": config.model,
        "config": config,
        "schema_path": schema_path,
        "generated_path": generated_path,
        "state": state,
    }


def default_tune_workspace_path(model_slug: str) -> Path:
    """Return the default workspace for tune init."""
    safe_slug = model_slug.strip().replace("/", "__").replace(" ", "-")
    return Path.cwd() / f"{safe_slug}-tune"


def create_tune_workspace(
    *,
    workspace_dir: Path,
    model_slug: str,
    schema_contract: dict[str, Any],
    parameters_contract: dict[str, Any] | None,
) -> list[str]:
    """Create or refresh a fine-tune workspace without overwriting data edits."""
    schema = TuningSchemaConfig.model_validate(schema_contract)
    workspace_dir.mkdir(parents=True, exist_ok=True)
    tuning_dir = workspace_dir / TUNING_HIDDEN_DIR_PATH
    tuning_dir.mkdir(parents=True, exist_ok=True)
    generated_classes = _build_generated_tuning_classes(
        model_slug=model_slug,
        parameters_contract=parameters_contract or {},
    )

    written: list[str] = []
    managed_always = {
        tuning_dir / TUNING_HIDDEN_SCHEMA_FILE_NAME: json.dumps(
            schema.model_dump(), indent=2, sort_keys=True
        )
        + "\n",
        tuning_dir / TUNING_HIDDEN_GENERATED_FILE_NAME: generated_classes,
        tuning_dir / TUNING_HIDDEN_STATE_FILE_NAME: json.dumps(
            _workspace_state_template(model_slug=model_slug), indent=2, sort_keys=True
        )
        + "\n",
        workspace_dir / TUNING_README_FILE_NAME: _readme_content(
            schema=schema,
            model_slug=model_slug,
        ),
    }
    for path, content in managed_always.items():
        preserves_user_edits = path.name in {TUNING_README_FILE_NAME}
        if path.name == TUNING_HIDDEN_STATE_FILE_NAME and path.exists():
            continue
        if preserves_user_edits and path.exists():
            continue
        path.write_text(content, encoding="utf-8")
        written.append(str(path.relative_to(workspace_dir)))

    tune_config = workspace_dir / TUNE_CONFIG_FILE_NAME
    if not tune_config.exists():
        tune_config.write_text(
            _tune_py_content(model_slug=model_slug, parameters_contract=parameters_contract or {}),
            encoding="utf-8",
        )
        written.append(str(tune_config.relative_to(workspace_dir)))

    data_path = workspace_dir / TUNE_DATA_FILE_NAME
    if not data_path.exists():
        asset_types = {"image", "audio", "video", "file"}
        has_asset_fields = any(field.type in asset_types for field in schema.fields)
        if has_asset_fields:
            assets_dir = workspace_dir / "assets"
            assets_dir.mkdir(parents=True, exist_ok=True)
            assets_readme = assets_dir / "README.md"
            if not assets_readme.exists():
                assets_readme.write_text(
                    "Place local asset files referenced by data.jsonl records in this folder.\n",
                    encoding="utf-8",
                )
                written.append(str(assets_readme.relative_to(workspace_dir)))
        for field in schema.fields:
            if field.type in asset_types:
                sample_value = _sample_value(field)
                sample_paths = sample_value if isinstance(sample_value, list) else [sample_value]
                for sample_path in sample_paths:
                    if not isinstance(sample_path, str):
                        continue
                    asset_path = workspace_dir / sample_path
                    asset_path.parent.mkdir(parents=True, exist_ok=True)
                    if not asset_path.exists():
                        asset_path.write_bytes(_sample_asset_bytes(field.type))
                        written.append(str(asset_path.relative_to(workspace_dir)))
        data_path.write_text(
            json.dumps(_sample_record(schema), sort_keys=True, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        written.append(str(data_path.relative_to(workspace_dir)))

    return written


def load_tune_config(workspace_dir: Path) -> TuneConfigValue:
    """Load and validate `tune.py` from a workspace."""
    config_path = workspace_dir / TUNE_CONFIG_FILE_NAME
    if not config_path.exists() or not config_path.is_file():
        raise usage_error(
            f"Fine-tune workspace is missing {TUNE_CONFIG_FILE_NAME}: {workspace_dir}",
            code="invalid_tune_workspace",
        )
    generated_path = workspace_dir / TUNING_HIDDEN_DIR_PATH / TUNING_HIDDEN_GENERATED_FILE_NAME
    if not generated_path.exists() or not generated_path.is_file():
        raise usage_error(
            f"Fine-tune workspace is missing .tuning/{TUNING_HIDDEN_GENERATED_FILE_NAME}: {workspace_dir}",
            code="invalid_tune_workspace",
        )
    module_prefix = f"aimp_tune_workspace_{abs(hash(str(workspace_dir.resolve())))}"
    parent_name = module_prefix
    tune_module_name = f"{module_prefix}.tune"
    tuning_pkg_name = f"{module_prefix}.tuning"
    hidden_pkg_name = f"{module_prefix}._tuning"
    generated_public_name = f"{tuning_pkg_name}.generated"
    generated_hidden_name = f"{hidden_pkg_name}.generated"
    inserted_modules: list[str] = []
    try:
        parent_module = types.ModuleType(parent_name)
        parent_module.__path__ = [str(workspace_dir)]
        sys.modules[parent_name] = parent_module
        inserted_modules.append(parent_name)

        tuning_pkg = types.ModuleType(tuning_pkg_name)
        tuning_pkg.__path__ = [str(workspace_dir / TUNING_HIDDEN_DIR_PATH)]
        sys.modules[tuning_pkg_name] = tuning_pkg
        inserted_modules.append(tuning_pkg_name)

        hidden_pkg = types.ModuleType(hidden_pkg_name)
        hidden_pkg.__path__ = [str(workspace_dir / TUNING_HIDDEN_DIR_PATH)]
        sys.modules[hidden_pkg_name] = hidden_pkg
        inserted_modules.append(hidden_pkg_name)

        generated_spec = importlib.util.spec_from_file_location(
            generated_hidden_name,
            generated_path,
        )
        if generated_spec is None or generated_spec.loader is None:
            raise usage_error(
                f"Unable to load generated tuning classes from {generated_path}",
                code="invalid_tune_workspace",
            )
        generated_module = importlib.util.module_from_spec(generated_spec)
        sys.modules[generated_hidden_name] = generated_module
        sys.modules[generated_public_name] = generated_module
        inserted_modules.extend([generated_hidden_name, generated_public_name])
        generated_spec.loader.exec_module(generated_module)

        config_spec = importlib.util.spec_from_file_location(tune_module_name, config_path)
        if config_spec is None or config_spec.loader is None:
            raise usage_error(
                f"Unable to load {TUNE_CONFIG_FILE_NAME} from {workspace_dir}",
                code="invalid_tune_workspace",
            )
        config_module = importlib.util.module_from_spec(config_spec)
        config_module.__package__ = module_prefix
        sys.modules[tune_module_name] = config_module
        inserted_modules.append(tune_module_name)
        config_spec.loader.exec_module(config_module)
    except Exception as exc:
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} could not be loaded: {exc}",
            code="invalid_tune_workspace",
        ) from exc
    finally:
        for name in reversed(inserted_modules):
            sys.modules.pop(name, None)

    config = getattr(config_module, "config", None)
    if config is None:
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} must define a top-level `config` variable.",
            code="invalid_tune_workspace",
        )
    if not hasattr(config, "model") or not hasattr(config, "data") or not hasattr(config, "tuning"):
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} config must expose model, data, and tuning fields.",
            code="invalid_tune_workspace",
        )
    model = str(getattr(config, "model") or "").strip()
    data = str(getattr(config, "data") or "").strip()
    tuning = getattr(config, "tuning")
    if not model:
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} config.model must be a non-empty string.",
            code="invalid_tune_workspace",
        )
    if not data:
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} config.data must be a non-empty string.",
            code="invalid_tune_workspace",
        )
    mode = str(getattr(tuning, "mode", "")).strip().lower()
    if mode not in {"auto", "manual"}:
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} config.tuning.mode must be 'auto' or 'manual'.",
            code="invalid_tune_workspace",
        )
    if mode == "auto":
        max_trials = getattr(tuning, "max_trials", None)
        if isinstance(max_trials, bool) or not isinstance(max_trials, int) or max_trials < 1:
            raise usage_error(
                f"{TUNE_CONFIG_FILE_NAME} auto tuning requires max_trials >= 1.",
                code="invalid_tune_workspace",
            )
        return TuneConfigValue(
            model=model,
            data=data,
            mode="auto",
            max_trials=max_trials,
            manual_parameters={},
        )

    raw_parameters = getattr(tuning, "parameters", None)
    if raw_parameters is None:
        raw_parameters = {
            key: value for key, value in vars(tuning).items() if key not in {"mode", "parameters"}
        }
    if not isinstance(raw_parameters, dict):
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} manual tuning parameters must be a dict.",
            code="invalid_tune_workspace",
        )
    if not raw_parameters:
        raise usage_error(
            f"{TUNE_CONFIG_FILE_NAME} manual tuning parameters must not be empty.",
            code="invalid_tune_workspace",
        )

    return TuneConfigValue(
        model=model,
        data=data,
        mode="manual",
        max_trials=1,
        manual_parameters={str(key): value for key, value in raw_parameters.items()},
    )


def _sample_record(schema: TuningSchemaConfig) -> dict[str, Any]:
    return {field.key: _sample_value(field) for field in schema.fields}


def _sample_value(field: TuningSchemaFieldConfig) -> Any:
    if field.type == "text":
        value: Any = f"example {field.key.replace('_', ' ')}"
    elif field.type == "json":
        value = {"example": field.key}
    elif field.type == "image":
        value = f"assets/{field.key}-example.png"
    elif field.type == "audio":
        value = f"assets/{field.key}-example.wav"
    elif field.type == "video":
        value = f"assets/{field.key}-example.mp4"
    else:
        value = f"assets/{field.key}-example.bin"
    return [value] if field.multiple else value


def _sample_asset_bytes(field_type: str) -> bytes:
    if field_type == "image":
        return b"\x89PNG\r\n\x1a\n"
    if field_type == "audio":
        return b"RIFF\x00\x00\x00\x00WAVE"
    if field_type == "video":
        return b"\x00\x00\x00\x18ftypmp42"
    return b"example"


def _class_name(base_model_slug: str, suffix: str) -> str:
    clean = "".join(ch if ch.isalnum() else " " for ch in base_model_slug)
    parts = [p.capitalize() for p in clean.split() if p]
    base = "".join(parts) or "Model"
    return f"{base}{suffix}"


def _tune_py_content(*, model_slug: str, parameters_contract: dict[str, Any]) -> str:
    auto_name = _class_name(model_slug, "AutoTune")
    manual_name = _class_name(model_slug, "ManualTune")
    default_trials = 3
    if parameters_contract:
        default_trials = 3
    return (
        "from __future__ import annotations\n\n"
        f"from ._tuning.generated import {auto_name}, {manual_name}, TuneConfig\n\n"
        "config = TuneConfig(\n"
        f'    model="{model_slug}",\n'
        f'    data="{TUNE_DATA_FILE_NAME}",\n'
        f"    tuning={auto_name}(max_trials={default_trials}),\n"
        ")\n"
    )


def _build_generated_tuning_classes(*, model_slug: str, parameters_contract: dict[str, Any]) -> str:
    auto_name = _class_name(model_slug, "AutoTune")
    manual_name = _class_name(model_slug, "ManualTune")
    lines = [
        "from __future__ import annotations",
        "",
        "from dataclasses import dataclass",
        "from dataclasses import field",
        "from typing import Any",
        "",
        "",
        f"@dataclass(frozen=True)",
        f"class {auto_name}:",
        "    max_trials: int = 3",
        '    mode: str = "auto"',
        "",
        "    def __post_init__(self) -> None:",
        "        if isinstance(self.max_trials, bool) or not isinstance(self.max_trials, int):",
        "            raise ValueError('max_trials must be an integer')",
        "        if self.max_trials < 1:",
        "            raise ValueError('max_trials must be >= 1')",
        "",
        "",
        f"@dataclass(frozen=True)",
        f"class {manual_name}:",
        '    mode: str = "manual"',
    ]

    if not parameters_contract:
        lines.extend(
            [
                "    parameters: dict[str, Any] = field(default_factory=dict)",
                "",
                "    def __post_init__(self) -> None:",
                "        if not isinstance(self.parameters, dict):",
                "            raise ValueError('parameters must be a dict')",
                "",
            ]
        )
        lines.extend(
            [
                "",
                "@dataclass(frozen=True)",
                "class TuneConfig:",
                "    model: str",
                "    data: str",
                f"    tuning: {auto_name} | {manual_name}",
                "",
                "    def __post_init__(self) -> None:",
                "        if not isinstance(self.model, str) or not self.model.strip():",
                "            raise ValueError('model must be a non-empty string')",
                "        if not isinstance(self.data, str) or not self.data.strip():",
                "            raise ValueError('data must be a non-empty string')",
            ]
        )
        return "\n".join(lines) + "\n"

    type_map = {
        "integer": "int",
        "float": "float",
        "select": "str",
    }
    defaults: list[str] = []
    validators: list[str] = []
    params_builder: list[str] = ["        params: dict[str, Any] = {}"]
    for raw_name, meta in sorted(parameters_contract.items()):
        name = str(raw_name)
        if not isinstance(meta, dict):
            continue
        kind = str(meta.get("kind") or "").strip().lower()
        py_type = type_map.get(kind, "Any")
        default_value = meta.get("default")
        default_literal = repr(default_value)
        defaults.append(f"    {name}: {py_type} = {default_literal}")
        if kind in {"integer", "float"}:
            min_val = meta.get("min")
            max_val = meta.get("max")
            validators.extend(
                [
                    f"        if self.{name} < {repr(min_val)} or self.{name} > {repr(max_val)}:",
                    (
                        "            raise ValueError("
                        f'"{name} must be between {min_val} and {max_val}"'
                        ")"
                    ),
                ]
            )
        elif kind == "select":
            options = meta.get("options") or []
            validators.extend(
                [
                    f"        if self.{name} not in {repr(options)}:",
                    (
                        "            raise ValueError("
                        f'"{name} must be one of: {", ".join(str(v) for v in options)}"'
                        ")"
                    ),
                ]
            )
        params_builder.append(f"        params['{name}'] = self.{name}")
    params_builder.append("        object.__setattr__(self, 'parameters', params)")

    lines.extend(defaults)
    lines.extend(
        [
            "    parameters: dict[str, Any] = field(init=False, repr=False)",
            "",
            "    def __post_init__(self) -> None:",
            *validators,
            *params_builder,
            "",
        ]
    )
    lines.extend(
        [
            "",
            "@dataclass(frozen=True)",
            "class TuneConfig:",
            "    model: str",
            "    data: str",
            f"    tuning: {auto_name} | {manual_name}",
            "",
            "    def __post_init__(self) -> None:",
            "        if not isinstance(self.model, str) or not self.model.strip():",
            "            raise ValueError('model must be a non-empty string')",
            "        if not isinstance(self.data, str) or not self.data.strip():",
            "            raise ValueError('data must be a non-empty string')",
        ]
    )
    return "\n".join(lines) + "\n"


def _readme_content(*, schema: TuningSchemaConfig, model_slug: str) -> str:
    field_lines = "\n".join(
        f"- `{field.key}`: {field.type}, {'required' if field.required else 'optional'}"
        + (", multiple" if field.multiple else "")
        for field in schema.fields
    )
    return f"""# Fine-tune `{model_slug}`

Edit `tune.py` and `data.jsonl`, then run:

```bash
ai tune push
```

To start without attaching logs:

```bash
ai tune push --detach
```

Expected fields:

{field_lines}

`data.jsonl` must contain one JSON object per line. Media and file fields must point to local files.
"""
