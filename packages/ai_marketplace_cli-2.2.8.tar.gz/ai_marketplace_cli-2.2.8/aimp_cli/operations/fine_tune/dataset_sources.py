"""Fine-tune dataset source loading and validation."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Literal

from aimp_cli.core.errors import usage_error
from aimp_cli.domain.models import TuningSchemaConfig, TuningSchemaFieldConfig

DatasetSourceFormat = Literal["jsonl", "csv"]

_SUPPORTED_FORMATS: set[str] = {"jsonl", "csv"}
_FILE_FIELD_TYPES = {"image", "audio", "video", "file"}


def parse_column_mapping(items: list[str] | None) -> dict[str, str]:
    """Parse repeated ``target=source`` mapping options."""
    mapping: dict[str, str] = {}
    for item in items or []:
        if "=" not in item:
            raise usage_error(
                f"Invalid --map value '{item}'. Expected target=source.",
                code="invalid_dataset_mapping",
            )
        target, source = (part.strip() for part in item.split("=", 1))
        if not target or not source:
            raise usage_error(
                f"Invalid --map value '{item}'. Target and source must be non-empty.",
                code="invalid_dataset_mapping",
            )
        if target in mapping:
            raise usage_error(
                f"Duplicate --map target: {target}",
                code="invalid_dataset_mapping",
            )
        mapping[target] = source
    return mapping


def detect_source_format(
    source_path: Path,
    *,
    explicit_format: str | None,
) -> DatasetSourceFormat:
    """Resolve the v1 source format from an explicit option or file extension."""
    normalized = str(explicit_format or "").strip().lower()
    if normalized:
        if normalized not in _SUPPORTED_FORMATS:
            raise usage_error(
                f"Unsupported dataset format '{explicit_format}'. Use one of: csv, jsonl.",
                code="unsupported_dataset_format",
            )
        return normalized  # type: ignore[return-value]

    suffix = source_path.suffix.lower().lstrip(".")
    if suffix in _SUPPORTED_FORMATS:
        return suffix  # type: ignore[return-value]
    raise usage_error(
        f"Could not detect dataset format from {source_path}. Pass --format jsonl or --format csv.",
        code="dataset_format_required",
    )


def load_dataset_source(
    *,
    source_path: Path,
    schema_contract: dict[str, Any],
    source_format: str | None,
    mapping: dict[str, str] | None = None,
    bundle_dir: Path | None = None,
) -> list[dict[str, Any]]:
    """Load one supported source file and return canonical bundle records."""
    resolved_source = source_path.expanduser().resolve()
    if not resolved_source.exists() or not resolved_source.is_file():
        raise usage_error(
            f"Dataset source not found: {source_path}",
            code="dataset_not_found",
        )

    schema = TuningSchemaConfig.model_validate(schema_contract)
    resolved_format = detect_source_format(resolved_source, explicit_format=source_format)
    mapping = mapping or {}
    _validate_mapping_targets(schema=schema, mapping=mapping)

    if resolved_format == "jsonl":
        raw_records = _load_jsonl(resolved_source)
    else:
        raw_records = _load_csv(resolved_source, schema=schema, mapping=mapping)

    if not raw_records:
        raise usage_error("Fine-tune dataset is empty.", code="empty_dataset")

    resolved_bundle_dir = (
        bundle_dir.expanduser().resolve() if bundle_dir else resolved_source.parent
    )
    return [
        _canonicalize_record(
            record=record,
            record_index=index,
            schema=schema,
            mapping=mapping,
            source_dir=resolved_source.parent,
            bundle_dir=resolved_bundle_dir,
        )
        for index, record in enumerate(raw_records)
    ]


def write_bundle(*, bundle_path: Path, records: list[dict[str, Any]]) -> None:
    """Write deterministic platform bundle JSON from canonical records."""
    bundle_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"records": records}
    bundle_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _load_jsonl(source_path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for line_number, raw_line in enumerate(source_path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw_line.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise usage_error(
                f"Malformed JSONL at {source_path}:{line_number}: {exc.msg}",
                code="malformed_jsonl",
            ) from exc
        if not isinstance(value, dict):
            raise usage_error(
                f"JSONL record at {source_path}:{line_number} must be a JSON object.",
                code="invalid_dataset_record",
            )
        records.append(value)
    return records


def _load_csv(
    source_path: Path,
    *,
    schema: TuningSchemaConfig,
    mapping: dict[str, str],
) -> list[dict[str, Any]]:
    with source_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames
        if not headers:
            raise usage_error("CSV dataset requires a header row.", code="csv_header_required")
        header_set = {header for header in headers if header is not None}
        if mapping:
            missing_sources = sorted(set(mapping.values()) - header_set)
            if missing_sources:
                raise usage_error(
                    "CSV mapping references missing source columns: "
                    + ", ".join(missing_sources),
                    code="invalid_dataset_mapping",
                )
        else:
            schema_keys = {field.key for field in schema.fields}
            unknown_columns = sorted(header_set - schema_keys)
            if unknown_columns:
                raise usage_error(
                    "CSV contains unknown columns: " + ", ".join(unknown_columns),
                    code="unknown_dataset_fields",
                )
        return [dict(row) for row in reader]


def _validate_mapping_targets(
    *,
    schema: TuningSchemaConfig,
    mapping: dict[str, str],
) -> None:
    schema_keys = {field.key for field in schema.fields}
    unknown_targets = sorted(set(mapping) - schema_keys)
    if unknown_targets:
        raise usage_error(
            "Mapping targets unknown schema fields: " + ", ".join(unknown_targets),
            code="invalid_dataset_mapping",
        )


def _canonicalize_record(
    *,
    record: dict[str, Any],
    record_index: int,
    schema: TuningSchemaConfig,
    mapping: dict[str, str],
    source_dir: Path,
    bundle_dir: Path,
) -> dict[str, Any]:
    schema_by_key = {field.key: field for field in schema.fields}
    canonical: dict[str, Any] = {}

    if not mapping:
        unknown_fields = sorted(set(record) - set(schema_by_key))
        if unknown_fields:
            raise usage_error(
                f"Record {record_index} contains unknown fields: " + ", ".join(unknown_fields),
                code="unknown_dataset_fields",
            )

    for field in schema.fields:
        source_key = mapping.get(field.key, field.key)
        raw_value = record.get(source_key)
        canonical[field.key] = _validate_field_value(
            field=field,
            value=raw_value,
            record_index=record_index,
            source_dir=source_dir,
            bundle_dir=bundle_dir,
        )
    return canonical


def _validate_field_value(
    *,
    field: TuningSchemaFieldConfig,
    value: Any,
    record_index: int,
    source_dir: Path,
    bundle_dir: Path,
) -> Any:
    if value in (None, "") or value == []:
        if field.required:
            raise usage_error(
                f"Record {record_index} is missing required field: {field.key}",
                code="missing_required_field",
            )
        return [] if field.multiple else None

    values = value if field.multiple else [value]
    if field.multiple and not isinstance(values, list):
        raise usage_error(
            f"Record {record_index} field '{field.key}' must be an array.",
            code="invalid_field_type",
        )

    normalized_values = [
        _validate_single_value(
            field=field,
            value=item,
            record_index=record_index,
            item_index=item_index,
            source_dir=source_dir,
            bundle_dir=bundle_dir,
        )
        for item_index, item in enumerate(values)
    ]
    return normalized_values if field.multiple else normalized_values[0]


def _validate_single_value(
    *,
    field: TuningSchemaFieldConfig,
    value: Any,
    record_index: int,
    item_index: int,
    source_dir: Path,
    bundle_dir: Path,
) -> Any:
    context = f"Record {record_index} field '{field.key}' item {item_index}"
    if field.type == "text":
        if not isinstance(value, str):
            raise usage_error(f"{context} must be text.", code="invalid_field_type")
        return value
    if field.type == "json":
        try:
            json.dumps(value)
        except (TypeError, ValueError) as exc:
            raise usage_error(
                f"{context} must be a JSON value.",
                code="invalid_field_type",
            ) from exc
        return value
    if field.type in _FILE_FIELD_TYPES:
        if not isinstance(value, str) or not value.strip():
            raise usage_error(f"{context} must be a local file path.", code="invalid_field_type")
        source_ref = Path(value).expanduser()
        resolved = source_ref if source_ref.is_absolute() else (source_dir / source_ref)
        resolved = resolved.resolve()
        if not resolved.exists() or not resolved.is_file():
            raise usage_error(
                f"{context} file not found: {value}",
                code="dataset_file_not_found",
            )
        if source_ref.is_absolute():
            return str(resolved)
        try:
            return str(resolved.relative_to(bundle_dir.resolve()))
        except ValueError:
            return str(resolved)
    raise usage_error(
        f"Unsupported schema field type '{field.type}' for field '{field.key}'.",
        code="unsupported_schema_field_type",
    )
