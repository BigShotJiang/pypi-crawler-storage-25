"""Model project scaffolding helpers.

This module intentionally performs only filesystem templating operations.
Project structure and architecture are defined by framework-owned template files.
"""

from __future__ import annotations

import shutil
from importlib import resources
from pathlib import Path

from aimp_cli.domain.constants import DEFAULT_STUDIO_COVER_FILE, PROJECT_ENV_RELATIVE_PATH
from aimp_cli.domain.runtime_packages import ordered_runtime_dependency_specs
from aimp_cli.operations.scaffold.files import write_default_studio_cover


def _to_pascal_case(value: str) -> str:
    """Convert string to PascalCase."""
    cleaned = "".join(character if character.isalnum() else " " for character in value)
    return "".join(part.capitalize() for part in cleaned.split()) or "Model"


def _to_snake_case(value: str) -> str:
    """Convert string to snake_case."""
    cleaned = "".join(character if character.isalnum() else " " for character in value)
    return "_".join(part.lower() for part in cleaned.split()) or "model"


def _framework_template_root() -> Path:
    """Return the framework-owned template root directory."""
    try:
        return Path(str(resources.files("aimp_framework").joinpath("project_template")))
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Framework project template not found. Ensure ai-marketplace-framework is available."
        ) from exc


def _framework_guidance_template_root() -> Path:
    """Return the framework-owned project guidance template directory."""
    try:
        return Path(
            str(resources.files("aimp_framework").joinpath("project_template").joinpath("guidance"))
        )
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Framework project guidance templates not found. Ensure ai-marketplace-framework is available."
        ) from exc


def _apply_placeholders(content: str, values: dict[str, str]) -> str:
    """Replace placeholders in template content."""
    result = content
    for key, value in values.items():
        result = result.replace(f"{{{{{key}}}}}", value)
    return result


def _copy_template_tree(
    source: Path,
    destination: Path,
    *,
    values: dict[str, str],
    skip_relative_paths: set[str] | None = None,
) -> None:
    """Copy one template tree and materialize placeholders."""
    skipped = skip_relative_paths or set()
    for path in source.rglob("*"):
        if path.name == "__pycache__" or path.suffix in {".pyc", ".pyo"}:
            continue
        relative = path.relative_to(source)
        if any(
            relative == Path(skipped_path) or Path(skipped_path) in relative.parents
            for skipped_path in skipped
        ):
            continue
        target = destination / relative
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix in {".py", ".md", ".mdx", ".toml", ".txt", ""}:
            content = path.read_text(encoding="utf-8")
            target.write_text(_apply_placeholders(content, values), encoding="utf-8")
        else:
            shutil.copy2(path, target)


def _create_single_model_project(project_dir: Path, values: dict[str, str]) -> None:
    """Create a single-model project from framework-owned templates."""
    template_root = _framework_template_root()
    single_model_template = template_root / "single_model"
    _copy_template_tree(
        single_model_template,
        project_dir,
        values=values,
        skip_relative_paths=set(),
    )


def _write_template_file(source: Path, target: Path, *, values: dict[str, str]) -> None:
    """Render one text template file with placeholder substitution."""
    target.parent.mkdir(parents=True, exist_ok=True)
    content = source.read_text(encoding="utf-8")
    target.write_text(_apply_placeholders(content, values), encoding="utf-8")


def _create_project_guidance(project_dir: Path, values: dict[str, str]) -> None:
    """Create framework-owned project guidance and skill files."""
    template_root = _framework_guidance_template_root()
    _write_template_file(template_root / "PROJECT.md.tpl", project_dir / "PROJECT.md", values=values)

    skills_template_root = template_root / "skills"
    skills_root = project_dir / ".agents" / "skills"
    for path in sorted(skills_template_root.glob("*.md.tpl")):
        skill_name = path.name.removesuffix(".md.tpl")
        _write_template_file(path, skills_root / skill_name / "SKILL.md", values=values)

    references_template_root = template_root / "references"
    references_root = project_dir / ".agents" / "references"
    if references_template_root.exists():
        for path in sorted(references_template_root.glob("*.md")):
            _write_template_file(path, references_root / path.name, values=values)


def _validate_scaffold(project_dir: Path) -> None:
    required_paths = (
        "pyproject.toml",
        ".aimp/project.toml",
        ".aimp/publish.toml",
        ".aimp/runtime-wheelhouse/.gitkeep",
        "PROJECT.md",
        ".agents/skills/model-architecture/SKILL.md",
        ".agents/skills/publish-readiness/SKILL.md",
        ".agents/skills/studio-content/SKILL.md",
        ".agents/skills/tuning-development/SKILL.md",
        ".agents/skills/quality-gates/SKILL.md",
        ".agents/references/layout.md",
        ".agents/references/commands.md",
        ".agents/references/publish-flow.md",
        "main.py",
        "internal/__init__.py",
        "internal/loader.py",
        "internal/inference.py",
        "schemas.py",
        "playground.py",
        "tuning/runner.py",
        "tests/test_model.py",
        "runtime/Dockerfile",
        "runtime/pyproject.toml",
        "runtime/README.md",
        "artifacts/README.md",
        "artifacts/artifact.py",
        ".dockerignore",
        ".env",
    )
    missing = [path for path in required_paths if not (project_dir / path).exists()]
    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(f"Scaffold template is incomplete; missing required files: {joined}")


def create_project_scaffold(name: str) -> Path:
    """Create a single-model project scaffold.

    Creates a flat layout under ./<name>/ with ``main.py`` as the execution entrypoint.
    The template includes ``runtime/Dockerfile`` and ``runtime/pyproject.toml``, which
    ``ai push`` requires to publish (there is no fallback publish image).
    """
    requested_name = name.strip()
    if not requested_name:
        raise ValueError("Project name cannot be empty")

    project_dir = Path(requested_name).resolve()
    if project_dir.exists():
        raise RuntimeError(f'Directory "{requested_name}" already exists')

    project_name = project_dir.name.strip()
    if not project_name:
        raise ValueError("Project name cannot be empty")

    model_key = _to_snake_case(project_name)
    model_class_name = _to_pascal_case(model_key)
    if not model_class_name.endswith("Model"):
        model_class_name = f"{model_class_name}Model"

    runtime_dependencies = ordered_runtime_dependency_specs()

    values = {
        "PROJECT_NAME": project_name,
        "PROJECT_NAME_PASCAL": model_class_name,
        "MODEL_KEY": model_key,
        "MODEL_CLASS_NAME": model_class_name,
        "FRAMEWORK_DEP": runtime_dependencies[0],
        "SDK_DEP": runtime_dependencies[1],
    }

    _create_single_model_project(project_dir, values)
    write_default_studio_cover(project_dir / DEFAULT_STUDIO_COVER_FILE)
    _create_project_guidance(project_dir, values)
    (project_dir / PROJECT_ENV_RELATIVE_PATH).write_text("", encoding="utf-8")
    _validate_scaffold(project_dir)

    return project_dir
