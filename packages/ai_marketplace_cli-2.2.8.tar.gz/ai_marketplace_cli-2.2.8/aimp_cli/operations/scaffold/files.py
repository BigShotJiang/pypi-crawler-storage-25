"""Template file helpers for CLI scaffold-adjacent utilities."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from aimp_cli.clients.studio_article import default_studio_article_mdx
from aimp_cli.operations.fine_tune.workspace import create_tune_workspace


def _template_root() -> Path:
    return Path(__file__).resolve().parent / "templates"


def _load_template(template_name: str, values: dict[str, str] | None = None) -> str:
    content = (_template_root() / template_name).read_text(encoding="utf-8")
    rendered = content
    for key, value in (values or {}).items():
        rendered = rendered.replace(f"{{{{{key}}}}}", value)
    return rendered


def studio_article_mdx_template() -> str:
    return _load_template(
        "studio/article/article.mdx.tpl",
        {"article_source": default_studio_article_mdx()},
    )


def write_default_studio_cover(cover_path: Path) -> None:
    cover_path.parent.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).resolve().parents[2] / "assets" / "default-cover.jpg"
    shutil.copyfile(source, cover_path)


def create_consumer_tuning_scaffold(
    output_dir: Path,
    *,
    model_slug: str,
    schema_contract: dict[str, Any],
    parameters_contract: dict[str, Any] | None = None,
) -> list[str]:
    """Create tune workspace using canonical workspace generator."""
    return create_tune_workspace(
        workspace_dir=output_dir,
        model_slug=model_slug,
        schema_contract=schema_contract,
        parameters_contract=parameters_contract or {},
    )


def regenerate_tuning_scaffold(
    output_dir: Path,
    *,
    model_slug: str,
    schema_contract: dict[str, Any],
    parameters_contract: dict[str, Any] | None = None,
) -> list[str]:
    """Refresh hidden tuning files while preserving user-facing edits."""
    written = create_tune_workspace(
        workspace_dir=output_dir,
        model_slug=model_slug,
        schema_contract=schema_contract,
        parameters_contract=parameters_contract or {},
    )
    # During regenerate, only report hidden files as refreshed.
    return [path for path in written if path.startswith(".tuning/")]
