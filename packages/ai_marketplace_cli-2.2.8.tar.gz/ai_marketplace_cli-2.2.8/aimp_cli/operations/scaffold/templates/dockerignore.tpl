.git/
.gitignore
__pycache__/
*.pyc
*.pyo
.env
.venv/
.agents/
# Keep .aimp/runtime-wheelhouse/ in context for Docker dependency-layer COPY.
.aimp/project.toml
.aimp/publish.toml
studio/
AGENTS.md
tests/
.pytest_cache/
build/
dist/
