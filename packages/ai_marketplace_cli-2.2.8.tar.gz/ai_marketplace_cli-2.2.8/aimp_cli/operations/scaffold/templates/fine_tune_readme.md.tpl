# Fine-Tune Workspace for `{{model_slug}}`

This workspace was generated from the published fine-tune contract.

## Quick Start

```bash
# 1) Edit tune.py
# 2) Edit data.jsonl
# 3) Start and watch the job
ai tune push
```

Use `--detach` when you do not want live logs:

```bash
ai tune push --detach
```

## Schema Fields

{{schema_fields}}

## Files

| File | Purpose |
|------|---------|
| `tune.py` | Primary typed local tune configuration |
| `data.jsonl` | Training records (one JSON object per line) |
| `assets/` | Optional local media/file assets |
| `.tuning/schema.json` | Hidden schema snapshot from remote model |
| `.tuning/generated.py` | Hidden generated typed tuning classes |
| `.tuning/state.json` | Hidden local latest-job state |

## Commands

```bash
# Start (and watch) fine-tune job
ai tune push

# Watch latest workspace job
ai tune watch

# Show latest workspace job status
ai tune status

# Show latest workspace job logs
ai tune logs

# Cancel latest workspace job
ai tune cancel
```
