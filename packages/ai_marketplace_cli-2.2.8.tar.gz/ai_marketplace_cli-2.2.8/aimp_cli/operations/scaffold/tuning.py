"""Fine-tune scaffold defaults."""

from __future__ import annotations

from aimp_cli.domain.models import (
    TuningConfig,
    TuningParameterDefinition,
    TuningSchemaConfig,
    TuningSchemaFieldConfig,
)
from aimp_cli.domain.project_config import ProjectConfig, default_project_config


def default_tuning_workspace_config(
    project_config: ProjectConfig | None = None,
) -> TuningConfig:
    """Return the default explicit fine-tune contract scaffold."""
    _ = project_config or default_project_config()
    fields = [
        TuningSchemaFieldConfig(
            key="input",
            type="json",
            required=True,
            description="Structured fine-tune record.",
        )
    ]
    return TuningConfig(
        supported=True,
        model_key="default_model",
        input_schema=TuningSchemaConfig(fields=fields),
        artifacts={
            "fields": [
                {
                    "key": "result",
                    "kind": "json",
                    "required": True,
                    "description": "Training output manifest.",
                }
            ]
        },
        metrics={
            "fields": [
                {
                    "key": "validation_score",
                    "goal": "maximize",
                    "required": True,
                    "description": "Primary validation score.",
                }
            ]
        },
        supports_chaining=True,
        parameters={
            "learning_rate": TuningParameterDefinition(
                kind="float",
                default=1e-5,
                min=1e-6,
                max=1e-4,
                log=True,
                required=True,
            ),
            "epochs": TuningParameterDefinition(
                kind="integer",
                default=3,
                min=1,
                max=5,
                required=True,
            ),
            "batch_size": TuningParameterDefinition(
                kind="select",
                default=16,
                options=[8, 16, 32],
                required=True,
            ),
        },
    )
