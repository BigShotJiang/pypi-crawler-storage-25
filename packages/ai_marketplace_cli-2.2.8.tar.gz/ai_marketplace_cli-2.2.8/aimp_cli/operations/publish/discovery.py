"""Resolve the single model runtime for publish."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from aimp_cli.core.errors import usage_error
from aimp_cli.domain.constants import MODEL_ENTRYPOINT_RELATIVE_PATH


# Helper services that should be ignored during compose validation
HELPER_SERVICES = frozenset(
    {
        "redis",
        "postgres",
        "db",
        "database",
        "minio",
        "qdrant",
        "vector-db",
        "vectordb",
        "nginx",
        "proxy",
        "gateway",
        "api",
        "worker",
        "scheduler",
        "celery",
        "rabbitmq",
        "kafka",
        "zookeeper",
        "elasticsearch",
        "mongo",
        "mongodb",
        "mysql",
        "mariadb",
        "memcached",
        "prometheus",
        "grafana",
        "jaeger",
        "zipkin",
    }
)


@dataclass(frozen=True)
class DeclaredModelRuntime:
    """One deployable model runtime (project ``runtime/`` directory)."""

    key: str
    path: Path
    class_name: str
    module: str
    module_origin: Path


def is_model_runtime_directory(path: Path) -> bool:
    """Return true when ``path`` is a model runtime directory with image markers."""
    return (
        path.is_dir()
        and (path / "Dockerfile").is_file()
        and (path / "pyproject.toml").is_file()
    )


def validate_model_runtime_directory(*, key: str, path: Path) -> None:
    """Validate the project ``runtime/`` directory."""
    missing: list[str] = []
    if not (path / "Dockerfile").is_file():
        missing.append("Dockerfile")
    if not (path / "pyproject.toml").is_file():
        missing.append("pyproject.toml")
    if missing:
        raise usage_error(
            (
                f"Model runtime '{key}' at '{path}' is missing "
                f"deployment markers: {', '.join(missing)}."
            ),
            code="model_runtime_deployment_markers_missing",
            extra={"runtime_key": key, "path": str(path), "missing": missing},
        )


def is_helper_service(service_name: str) -> bool:
    """Return True if the service name is a known helper service (not the model)."""
    normalized = service_name.lower().replace("-", "").replace("_", "")
    if service_name.lower() in HELPER_SERVICES:
        return True
    return normalized in {h.replace("-", "").replace("_", "") for h in HELPER_SERVICES}


def load_declared_model_runtimes(
    *,
    project_dir: Path,
    python_bin: str | None = None,
) -> list[DeclaredModelRuntime]:
    """Load the single model runtime for this project (``runtime/`` next to ``main.py``)."""
    _ = python_bin
    module_path = project_dir / MODEL_ENTRYPOINT_RELATIVE_PATH
    if not module_path.exists():
        raise usage_error(
            f"{MODEL_ENTRYPOINT_RELATIVE_PATH} not found. Run: ai init",
            code="model_entrypoint_missing",
            extra={"project_dir": str(project_dir)},
        )

    runtime_dir = project_dir / "runtime"
    validate_model_runtime_directory(key="model", path=runtime_dir)

    return [
        DeclaredModelRuntime(
            key="model",
            path=runtime_dir.resolve(),
            class_name="",
            module="model",
            module_origin=module_path.resolve(),
        )
    ]


def load_model_runtime_entries(
    *,
    project_dir: Path,
    python_bin: str | None = None,
) -> list[dict[str, Any]]:
    """Return runtime entries for compose helpers (single model)."""
    runtimes = load_declared_model_runtimes(project_dir=project_dir, python_bin=python_bin)
    return [
        {
            "key": r.key,
            "class_name": r.class_name,
            "module": r.module,
            "module_origin": str(r.module_origin),
            "project_path": str(r.path),
        }
        for r in runtimes
    ]


def validate_model_compose(
    *,
    project_dir: Path,
    runtimes: list[DeclaredModelRuntime] | None = None,
) -> None:
    """Validate optional local ``docker-compose.yml`` against the model service."""
    compose_path = project_dir / "docker-compose.yml"
    if not compose_path.exists():
        return

    if runtimes is None:
        runtimes = load_declared_model_runtimes(project_dir=project_dir)

    try:
        payload = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise usage_error(
            f"docker-compose.yml is invalid YAML: {exc}",
            code="compose_invalid",
            extra={"compose_path": str(compose_path)},
        ) from exc
    if not isinstance(payload, dict):
        raise usage_error(
            "docker-compose.yml must define a mapping payload.",
            code="compose_invalid",
            extra={"compose_path": str(compose_path)},
        )
    services = payload.get("services")
    if not isinstance(services, dict):
        raise usage_error(
            "docker-compose.yml must define services.",
            code="compose_invalid",
            extra={"compose_path": str(compose_path)},
        )

    declared_keys = [r.key for r in runtimes]

    runtime_services = {
        name: config for name, config in services.items() if not is_helper_service(name)
    }

    if "model" not in runtime_services:
        raise usage_error(
            "docker-compose.yml is missing model service. "
            "Add a service named 'model' for the model runtime.",
            code="compose_root_model_missing",
            extra={
                "compose_path": str(compose_path),
                "expected_service": "model",
            },
        )

    missing = [key for key in declared_keys if key not in runtime_services]
    if missing:
        raise usage_error(
            ("docker-compose.yml is missing services for declared runtimes: " + ", ".join(missing)),
            code="compose_declared_runtimes_missing",
            extra={
                "compose_path": str(compose_path),
                "missing_runtime_services": missing,
                "declared_runtime_keys": declared_keys,
            },
        )


def validate_compose(
    *,
    project_dir: Path,
    python_bin: str | None = None,
) -> dict[str, Any]:
    """Validate docker-compose.yml against the model runtime."""
    compose_path = project_dir / "docker-compose.yml"

    entries = load_model_runtime_entries(project_dir=project_dir, python_bin=python_bin)
    declared_keys = [str(entry.get("key", "")) for entry in entries if entry.get("key")]

    if not compose_path.exists():
        return {
            "valid": True,
            "declared_runtimes": declared_keys,
            "compose_services": [],
            "runtime_services": [],
            "helper_services": [],
            "missing": [],
            "error": "docker-compose.yml not found",
        }

    try:
        payload = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return {
            "valid": False,
            "declared_runtimes": declared_keys,
            "compose_services": [],
            "runtime_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": f"Invalid YAML: {exc}",
        }

    if not isinstance(payload, dict):
        return {
            "valid": False,
            "declared_runtimes": declared_keys,
            "compose_services": [],
            "runtime_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": "docker-compose.yml must define a mapping payload",
        }

    services = payload.get("services")
    if not isinstance(services, dict):
        return {
            "valid": False,
            "declared_runtimes": declared_keys,
            "compose_services": [],
            "runtime_services": [],
            "helper_services": [],
            "missing": declared_keys,
            "error": "docker-compose.yml must define services",
        }

    all_service_names = list(services.keys())
    helper_names = [name for name in all_service_names if is_helper_service(name)]
    runtime_service_names = [name for name in all_service_names if not is_helper_service(name)]
    missing = [key for key in declared_keys if key not in runtime_service_names]

    return {
        "valid": len(missing) == 0,
        "declared_runtimes": declared_keys,
        "compose_services": all_service_names,
        "runtime_services": runtime_service_names,
        "helper_services": helper_names,
        "missing": missing,
    }


def generate_compose(
    *,
    project_dir: Path,
    python_bin: str | None = None,
    version: str = "3.8",
) -> dict[str, Any]:
    """Generate docker-compose.yml content for the single-model layout."""
    _ = project_dir, python_bin
    services: dict[str, Any] = {
        "model": {
            "build": {
                "context": ".",
                "dockerfile": "Dockerfile",
            }
        }
    }

    return {
        "version": version,
        "services": services,
    }
