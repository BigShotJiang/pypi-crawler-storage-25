"""Validate on-disk model project layout (reject legacy layouts)."""

from __future__ import annotations

from pathlib import Path

from aimp_cli.core.errors import usage_error
from aimp_cli.domain.project_config import ProjectConfig
from aimp_sdk.execution_assets import ExecutionArtifactContractError
from aimp_sdk.execution_assets import resolve_execution_bundle_payload_dir


def validate_model_project_layout(project_dir: Path) -> None:
    """Fail fast when a legacy agent, multi-model, or pre-``internal/`` layout is present."""
    root = project_dir.resolve()
    violations: list[str] = []
    if (root / "agent.py").is_file():
        violations.append("agent.py (unsupported; use main.py only)")
    if (root / "model.py").is_file():
        violations.append("model.py (unsupported; use main.py only)")
    if (root / "engine.py").is_file():
        violations.append("engine.py (moved under internal/loader.py)")
    if (root / "vectors.py").is_file():
        violations.append("vectors.py (moved under internal/inference.py)")
    if (root / "core").is_dir():
        violations.append("core/ (renamed to internal/)")
    if (root / "workers").is_dir():
        violations.append("workers/ (worker topology is not supported)")
    if (root / "models").is_dir():
        violations.append("models/ (multi-model tree is not supported)")
    if not violations:
        return
    detail = "; ".join(violations)
    raise usage_error(
        f"Unsupported project layout: {detail}",
        code="unsupported_project_layout",
        extra={"project_dir": str(root), "violations": violations},
    )


def validate_publish_model_contract(*, project_dir: Path, project_config: ProjectConfig) -> None:
    """Enforce ``runtime/`` + ``artifacts/`` publish layout and local README documentation."""
    root = project_dir.resolve()
    artifacts_dir = root / "artifacts"
    if not artifacts_dir.is_dir():
        raise usage_error(
            "artifacts/ is required because published models must provide an execution artifact bundle.",
            code="publish_artifacts_dir_missing",
            extra={"project_dir": str(root)},
        )
    if not (artifacts_dir / "README.md").is_file():
        raise usage_error(
            "Missing artifacts/README.md. Framework-owned directories must document their role locally.",
            code="publish_artifacts_readme_missing",
            extra={"project_dir": str(root)},
        )
    runtime_readme = root / "runtime" / "README.md"
    if not runtime_readme.is_file():
        raise usage_error(
            "Missing runtime/README.md. Framework-owned directories must document their role locally.",
            code="publish_runtime_readme_missing",
            extra={"project_dir": str(root)},
        )
    bundle_root = root / project_config.publish.artifact_path
    if not bundle_root.is_dir():
        raise usage_error(
            f"publish.artifact_path directory is missing: {project_config.publish.artifact_path!r}",
            code="publish_artifact_path_missing",
            extra={"project_dir": str(root), "artifact_path": project_config.publish.artifact_path},
        )
    artifact_entry = artifacts_dir / "artifact.py"
    if not artifact_entry.is_file():
        raise usage_error(
            "Missing artifacts/artifact.py. Publishable models must declare the framework "
            "artifact preparation entrypoint.",
            code="publish_artifacts_entrypoint_missing",
            extra={"project_dir": str(root)},
        )
    try:
        resolve_execution_bundle_payload_dir(root)
    except ExecutionArtifactContractError as exc:
        raise usage_error(
            str(exc),
            code="publish_execution_bundle_layout_invalid",
            extra={"project_dir": str(root)},
        ) from exc
