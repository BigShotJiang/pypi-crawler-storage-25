"""TOML serialization helpers for package metadata and local project config."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from aimp_cli.domain.publish_config import PublishMetadataConfig

from .constants import (
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    DEFAULT_PUBLISH_SCHEMA_VERSION,
    DEFAULT_STUDIO_ARTICLE_MDX_FILE,
    DEFAULT_STUDIO_COVER_FILE,
)
from .models import TuningParameterDefinition, VectorResourceCollectionsConfig
from .project_config import (
    ProjectConfig,
    ProjectPackageMetadata,
    default_project_config,
    default_project_package_metadata,
)


def _format_toml_array(values: Sequence[Any]) -> str:
    return "[" + ", ".join(_to_toml_literal(value) or '""' for value in values) + "]"


def _append_toml_table(lines: list[str], table_name: str, values: dict[str, Any]) -> None:
    """Append a TOML table for scalar values."""
    lines.extend(["", f"[{table_name}]"])
    for key, value in values.items():
        literal = _to_toml_literal(value)
        if literal is not None:
            lines.append(f"{key} = {literal}")


def _serialize_input_definition(inp: Any) -> list[str]:
    """Serialize a single InputDefinition to TOML array-of-tables entries."""
    lines: list[str] = []
    lines.append(f'name = "{_escape_toml_string(inp.name)}"')
    lines.append(f'kind = "{inp.kind}"')
    lines.append(f"required = {'true' if inp.required else 'false'}")
    if inp.description:
        lines.append(f'description = "{_escape_toml_string(inp.description)}"')
    if inp.multiple:
        lines.append("multiple = true")
    if inp.label:
        lines.append(f'label = "{_escape_toml_string(inp.label)}"')
    if inp.default is not None:
        default_literal = _to_toml_literal(inp.default)
        if default_literal:
            lines.append(f"default = {default_literal}")
    return lines


def _serialize_output_definition(output: Any) -> list[str]:
    """Serialize a single OutputDefinition to TOML array-of-tables entries."""
    lines: list[str] = []
    lines.append(f'name = "{_escape_toml_string(output.name)}"')
    lines.append(f'kind = "{output.kind}"')
    lines.append(f"required = {'true' if output.required else 'false'}")
    if output.description:
        lines.append(f'description = "{_escape_toml_string(output.description)}"')
    if output.multiple:
        lines.append("multiple = true")
    if output.label:
        lines.append(f'label = "{_escape_toml_string(output.label)}"')
    if output.default is not None:
        default_literal = _to_toml_literal(output.default)
        if default_literal:
            lines.append(f"default = {default_literal}")
    return lines


def serialize_project_package_toml(metadata: ProjectPackageMetadata) -> str:
    """Serialize package metadata as ``pyproject.toml`` section text.

    This generates the ``[tool.aimp.project]`` section content.  Name, version,
    and description live in ``[project]`` and are not duplicated here.
    """
    lines = [
        "[tool.aimp.project]",
        f'author = "{_escape_toml_string(metadata.author)}"',
    ]
    return "\n".join(lines) + "\n"


def _append_tuning_parameter_table(lines: list[str], name: str, param: TuningParameterDefinition) -> None:
    lines.extend(["", f"[tuning.parameters.{name}]"])
    lines.append(f'kind = "{param.kind}"')
    lit_default = _to_toml_literal(param.default)
    if lit_default is not None:
        lines.append(f"default = {lit_default}")
    lines.append(f"required = {'true' if param.required else 'false'}")
    if param.min is not None:
        lines.append(f"min = {param.min}")
    if param.max is not None:
        lines.append(f"max = {param.max}")
    if param.step is not None:
        lines.append(f"step = {param.step}")
    if param.log:
        lines.append("log = true")
    if param.options:
        opts = _format_toml_array(param.options)
        lines.append(f"options = {opts}")


def serialize_project_config_toml(config: ProjectConfig) -> str:
    """Serialize ``.aimp/project.toml`` in stable canonical order."""
    lines = [
        "# Hidden project config managed by the CLI",
        f"schema_version = {config.schema_version}",
    ]
    lines.extend(
        [
            "",
            "[publish]",
            f'artifact_path = "{_escape_toml_string(config.publish.artifact_path)}"',
            f'artifact_format = "{config.publish.artifact_format}"',
        ]
    )
    if config.publish.selected_hardware_tier:
        lines.append(
            f'selected_hardware_tier = "{_escape_toml_string(config.publish.selected_hardware_tier)}"'
        )
    for adapter in config.publish.adapters:
        lines.extend(
            [
                "",
                "[[publish.adapters]]",
                f'slug = "{_escape_toml_string(adapter.slug)}"',
                f'artifact_path = "{_escape_toml_string(adapter.artifact_path)}"',
            ]
        )

    lines.extend(
        [
            "",
            "[capabilities]",
            f"vector = {'true' if config.capabilities.vector else 'false'}",
            f"tuning = {'true' if config.capabilities.tuning else 'false'}",
        ]
    )

    lines.extend(["", "[resources]"])
    vdb = config.resources.vector_db
    if isinstance(vdb, bool):
        lines.append(f"vector_db = {'true' if vdb else 'false'}")
    elif isinstance(vdb, VectorResourceCollectionsConfig):
        lines.append("")
        lines.extend(["[resources.vector_db]", ""])
        for coll in vdb.collections:
            lines.extend(
                [
                    "[[resources.vector_db.collections]]",
                    f'alias = "{_escape_toml_string(coll.alias)}"',
                    f'name = "{_escape_toml_string(coll.name)}"',
                    f'description = "{_escape_toml_string(coll.description)}"',
                    f"dimension = {coll.dimension}",
                    f'metric = "{_escape_toml_string(coll.metric)}"',
                ]
            )
    if config.resources.timeout:
        lines.append(f'timeout = "{_escape_toml_string(config.resources.timeout)}"')

    for mode_name in sorted(config.modes.names()):
        contract = config.modes[mode_name]
        lines.extend([f"", f"[modes.{mode_name}]"])
        lines.append(f"enabled = {'true' if contract.enabled else 'false'}")
        if contract.description:
            lines.append(f'description = "{_escape_toml_string(contract.description)}"')
        if contract.resources is not None and contract.resources.vector_aliases:
            lines.extend([f"", f"[modes.{mode_name}.resources]"])
            aliases = _format_toml_array(contract.resources.vector_aliases)
            lines.append(f"vector_aliases = {aliases}")
        for inp in contract.inputs:
            lines.append("")
            lines.append(f"[[modes.{mode_name}.inputs]]")
            lines.extend(_serialize_input_definition(inp))
        for output in contract.outputs:
            lines.append("")
            lines.append(f"[[modes.{mode_name}.outputs]]")
            lines.extend(_serialize_output_definition(output))

    if config.tuning is not None:
        tc = config.tuning
        lines.extend(["", "[tuning]"])
        lines.append(f"supported = {'true' if tc.supported else 'false'}")
        lines.append(f'model_key = "{_escape_toml_string(tc.model_key)}"')
        if tc.supports_chaining:
            lines.append("supports_chaining = true")
        lines.extend(["", "[tuning.schema]"])
        for field in tc.input_schema.fields:
            lines.extend(
                [
                    "",
                    "[[tuning.schema.fields]]",
                    f'key = "{_escape_toml_string(field.key)}"',
                    f'type = "{field.type}"',
                    f"required = {'true' if field.required else 'false'}",
                ]
            )
            if field.description:
                lines.append(f'description = "{_escape_toml_string(field.description)}"')
            if field.multiple:
                lines.append("multiple = true")
        lines.extend(["", "[tuning.artifacts]"])
        for field in tc.artifacts.get("fields", []):
            lines.extend(
                [
                    "",
                    "[[tuning.artifacts.fields]]",
                    f'key = "{_escape_toml_string(str(field["key"]))}"',
                    f'kind = "{_escape_toml_string(str(field["kind"]))}"',
                    f"required = {'true' if field.get('required', True) else 'false'}",
                ]
            )
            if field.get("description"):
                lines.append(
                    f'description = "{_escape_toml_string(str(field["description"]))}"'
                )
        lines.extend(["", "[tuning.metrics]"])
        for field in tc.metrics.get("fields", []):
            lines.extend(
                [
                    "",
                    "[[tuning.metrics.fields]]",
                    f'key = "{_escape_toml_string(str(field["key"]))}"',
                    f'goal = "{_escape_toml_string(str(field["goal"]))}"',
                    f"required = {'true' if field.get('required', True) else 'false'}",
                ]
            )
            if field.get("description"):
                lines.append(
                    f'description = "{_escape_toml_string(str(field["description"]))}"'
                )
        for pname, pdef in tc.parameters.items():
            _append_tuning_parameter_table(lines, pname, pdef)

    return "\n".join(lines) + "\n"


def _escape_toml_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _format_toml_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return f'"{_escape_toml_string(value)}"'
    return repr(value)


def _to_toml_literal(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(value)
    if isinstance(value, str):
        return f'"{_escape_toml_string(value)}"'
    if isinstance(value, list):
        return "[" + ", ".join(filter(None, (_to_toml_literal(item) for item in value))) + "]"
    if isinstance(value, dict):
        items = []
        for key, item in value.items():
            item_literal = _to_toml_literal(item)
            if item_literal is None:
                continue
            items.append(f"{key} = {item_literal}")
        return "{ " + ", ".join(items) + " }"
    raise RuntimeError(f"Unsupported TOML literal value: {value!r}")


def publish_config_toml_template() -> str:
    """Return default hidden publish config text."""
    return (
        "# Hidden publish state managed by the CLI\n"
        f"schema_version = {DEFAULT_PUBLISH_SCHEMA_VERSION}\n\n"
        "[studio]\n"
        'name = "Example Model"\n'
        'tags = ["example", "starter"]\n'
        'visibility = "private"\n'
        f'cover_file = "{DEFAULT_STUDIO_COVER_FILE}"\n'
        f'article_mdx_file = "{DEFAULT_STUDIO_ARTICLE_MDX_FILE}"\n\n'
        "[pricing]\n"
        "developer_margin = 0\n"
    )


def project_package_toml_template(project_name: str = "model") -> str:
    """Return default scaffolded ``[tool.aimp.project]`` section text."""
    return serialize_project_package_toml(default_project_package_metadata(project_name))


def project_config_toml_template() -> str:
    """Return default scaffolded ``.aimp/project.toml`` text."""
    return serialize_project_config_toml(default_project_config())


def serialize_publish_config_toml(config: PublishMetadataConfig) -> str:
    """Serialize hidden publish config in stable canonical order."""
    lines = [
        "# Hidden publish state managed by the CLI",
        f"schema_version = {DEFAULT_PUBLISH_SCHEMA_VERSION}",
        "",
        "[studio]",
        f'name = "{_escape_toml_string(config.studio.name)}"',
        f"tags = {_format_toml_array(config.studio.tags)}",
        f'visibility = "{config.studio.visibility}"',
    ]
    if config.studio.cover_file:
        lines.append(f'cover_file = "{_escape_toml_string(config.studio.cover_file)}"')
    if config.studio.cover_url:
        lines.append(f'cover_url = "{_escape_toml_string(config.studio.cover_url)}"')
    lines.append(f'article_mdx_file = "{_escape_toml_string(config.studio.article_mdx_file)}"')
    lines.extend(
        [
            "",
            "[pricing]",
        ]
    )
    developer_margin = config.pricing.get("developer_margin", 0)
    lines.append(f"developer_margin = {developer_margin}")
    if config.python_packages is not None:
        lines.extend(
            [
                "",
                "[python_packages]",
                f'extra_index_url = "{_escape_toml_string(config.python_packages.extra_index_url)}"',
            ]
        )
        if config.python_packages.username is not None:
            lines.append(f'username = "{_escape_toml_string(config.python_packages.username)}"')
        if config.python_packages.password is not None:
            lines.append(f'password = "{_escape_toml_string(config.python_packages.password)}"')
    return "\n".join(lines) + "\n"
