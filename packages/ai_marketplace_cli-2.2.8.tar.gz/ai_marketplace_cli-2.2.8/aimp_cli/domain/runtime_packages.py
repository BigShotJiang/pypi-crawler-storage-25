"""Official runtime package dependency specs used by scaffolded projects."""

from __future__ import annotations

RUNTIME_DEPENDENCY_NAMES = ("ai-marketplace-framework", "ai-marketplace-sdk")

OFFICIAL_RUNTIME_DEPENDENCY_SPECS = {
    "ai-marketplace-framework": "ai-marketplace-framework==0.4.5",
    "ai-marketplace-sdk": "ai-marketplace-sdk==0.6.1",
}


def ordered_runtime_dependency_specs() -> tuple[str, str]:
    """Return runtime dependency specs in the stable package order."""
    return tuple(OFFICIAL_RUNTIME_DEPENDENCY_SPECS[name] for name in RUNTIME_DEPENDENCY_NAMES)
