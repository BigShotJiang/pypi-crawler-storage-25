"""Typing protocols for CLI service dependencies."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Protocol

from aimp_cli.clients.docker import DockerAccessStatus, RegistryAuthStatus
from aimp_cli.domain.models import (
    ArtifactType,
    AuthResponse,
    JobCancelResponse,
    ModelLookupResponse,
    ModelSecretListResponse,
    ModelSecretMetadata,
    PublishBuildGroup,
    PublishBuildGroupCreateRequest,
    PublishBuildGroupListResponse,
    PublishMetadataResponse,
    PublishRequest,
    PublishResponse,
    StudioModelDetailResponse,
)


class AuthGatewayProtocol(Protocol):
    """Gateway methods used by auth flows."""

    def authenticate(self, api_key: str) -> AuthResponse:
        """Validate an API key."""

    def get_current_user(self) -> AuthResponse | None:
        """Return the current authenticated user."""

    def close(self) -> None:
        """Close underlying resources."""


class PublishMetadataGatewayProtocol(Protocol):
    """Gateway methods used by publish configuration flows."""

    def get_publish_metadata(self) -> PublishMetadataResponse:
        """Return publish metadata for the current user."""


class ModelGatewayProtocol(Protocol):
    """Gateway methods used by model inspection flows."""

    def get_model(self, slug: str) -> ModelLookupResponse | None:
        """Look up a model by slug."""

    def get_model_version(self, slug: str, version: str) -> ModelLookupResponse | None:
        """Look up a specific model release by slug and version."""

    def get_studio_model(self, model_id: str) -> StudioModelDetailResponse:
        """Return detailed studio model metadata."""

    def get_studio_model_analytics(self, model_id: str) -> dict[str, Any]:
        """Return analytics for a studio model."""

    def get_model_rates(self, model_id: str, actions: list[str]) -> dict[str, Any]:
        """Return action rates for a studio model."""

    def close(self) -> None:
        """Close underlying resources."""


class JobStreamGatewayProtocol(Protocol):
    """Gateway methods used by unified SSE job watching."""

    def stream_job(
        self,
        job_id: str,
        *,
        timeline_offset: int = 0,
        log_offset: int = 0,
    ) -> AbstractContextManager[Iterator[str]]:
        """Open one live SSE stream for a single job."""


class PublishGatewayProtocol(JobStreamGatewayProtocol, Protocol):
    """Gateway methods used by the publish pipeline."""

    def get_model(self, slug: str) -> ModelLookupResponse | None:
        """Look up a model by slug."""

    def get_model_version(self, slug: str, version: str) -> ModelLookupResponse | None:
        """Look up a specific model release by slug and version."""

    def upload_studio_media(
        self,
        *,
        file_path: Path,
        media_type: str,
    ) -> dict[str, Any]:
        """Upload Studio media and return the trusted completion payload."""

    def set_model_secret(self, *, model_slug: str, name: str, value: str) -> ModelSecretMetadata:
        """Upsert one model-scoped runtime secret."""

    def list_model_secrets(self, *, model_slug: str) -> ModelSecretListResponse:
        """List configured model-scoped runtime secrets."""

    def delete_model_secret(self, *, model_slug: str, name: str) -> None:
        """Delete one model-scoped runtime secret."""

    def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
        """Publish a model build."""

    def publish_model_by_slug(self, slug: str) -> PublishResponse:
        """Publish one existing remote model by slug."""

    def create_publish_build_group(
        self,
        request: PublishBuildGroupCreateRequest,
    ) -> PublishBuildGroup:
        """Create a remote publish build group."""

    def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
        """Get one remote publish build group."""

    def list_publish_build_groups(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildGroupListResponse:
        """List publish build groups within the authenticated workspace."""

    def cancel_publish_build_group(self, job_id: str) -> JobCancelResponse:
        """Cancel one publish build group."""

    def delete_publish_build_group(self, job_id: str) -> None:
        """Delete one terminal publish build group."""


class JobsGatewayProtocol(Protocol):
    """Gateway methods used by unified job read commands."""

    def list_jobs(
        self,
        *,
        job_type: str | None = None,
        status: str | None = None,
        model_slug: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """List unified jobs within the authenticated workspace."""

    def get_job(self, *, job_id: str) -> dict[str, Any]:
        """Get one unified job by ID."""

    def cancel_job(self, *, job_id: str) -> dict[str, Any]:
        """Cancel one unified job by ID."""

    def delete_job(self, *, job_id: str) -> None:
        """Delete one terminal unified job by ID."""


class DockerBackendProtocol(Protocol):
    """Docker operations required by the publish flow."""

    def inspect_daemon_access(self) -> DockerAccessStatus:
        """Return Docker daemon diagnostics."""

    def build_image(
        self,
        *,
        context_dir: Path,
        tag: str,
        dockerfile: str | None,
        on_line: Callable[[str], None],
    ) -> None:
        """Build an image."""

    def verify_runtime_sdk(self, image_tag: str) -> None:
        """Validate the canonical runtime SDK executable within the built image."""

    def tag_image(self, source: str, target: str) -> None:
        """Tag an image."""

    def push_image(self, image_ref: str, on_line: Callable[[str], None]) -> None:
        """Push an image to the registry."""

    def save_image(self, image_tag: str, output_path: Path) -> None:
        """Archive an image to disk."""

    def get_registry_auth_status(self, registry_host: str) -> RegistryAuthStatus:
        """Return registry auth availability."""

    def get_registry_basic_auth_header(self, registry_host: str) -> str | None:
        """Return a basic auth header when available."""


class UploadResultProtocol(Protocol):
    """Upload result attributes consumed by the publish flow."""

    storage_uri: str


class UploadClientProtocol(Protocol):
    """Artifact upload client contract."""

    def upload_file(
        self,
        *,
        file_path: Path,
        slug: str,
        version: str,
        artifact_type: ArtifactType,
        content_type: str,
        metadata: dict[str, Any] | None,
        concurrency: int,
        on_progress: Any | None,
    ) -> UploadResultProtocol:
        """Upload an artifact file."""


UploadClientFactoryProtocol = Callable[[PublishGatewayProtocol], UploadClientProtocol]
