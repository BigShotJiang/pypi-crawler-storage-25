"""Project discovery helpers and project-local skill indexing."""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, ConfigDict

from .constants import (
    PUBLISH_CONFIG_RELATIVE_PATH,
    PROJECT_CONFIG_RELATIVE_PATH,
    SKILLS_RELATIVE_PATH,
)


class ProjectSkillEntry(BaseModel):
    """Machine-readable metadata for a project-local skill file."""

    model_config = ConfigDict(extra="forbid")

    name: str
    description: str
    path: str
    kind: str


def find_project_root(start_dir: Path) -> Path:
    """Return the nearest project root containing project metadata or hidden config."""
    current = start_dir.resolve()
    for directory in (current, *current.parents):
        if (directory / PROJECT_CONFIG_RELATIVE_PATH).exists():
            return directory
        if (directory / "pyproject.toml").exists():
            return directory
    raise RuntimeError(
        "Project root not found. Run this command inside a project or create one with `ai init`."
    )


def _parse_skill_frontmatter(text: str) -> tuple[str, str]:
    if not text.startswith("---\n"):
        raise RuntimeError("Skill file is missing YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end == -1:
        raise RuntimeError("Skill file frontmatter is not terminated")
    header = text[4:end].splitlines()
    values: dict[str, str] = {}
    for line in header:
        if ":" not in line:
            continue
        key, raw_value = line.split(":", 1)
        values[key.strip()] = raw_value.strip()
    name = values.get("name", "").strip()
    description = values.get("description", "").strip()
    if not name or not description:
        raise RuntimeError("Skill frontmatter requires non-empty name and description")
    return name, description


def list_project_skills(project_dir: Path) -> tuple[str | None, list[ProjectSkillEntry]]:
    """Return project-local skills for the given project directory."""
    entries: list[ProjectSkillEntry] = []
    project_file: str | None = None
    guidance_path = project_dir / "PROJECT.md"
    if guidance_path.exists():
        project_file = str(guidance_path.relative_to(project_dir))
    for skills_root in (project_dir / SKILLS_RELATIVE_PATH,):
        if not skills_root.exists():
            continue
        for skill_path in sorted(skills_root.glob("*/SKILL.md")):
            name, description = _parse_skill_frontmatter(skill_path.read_text(encoding="utf-8"))
            entries.append(
                ProjectSkillEntry(
                    name=name,
                    description=description,
                    path=str(skill_path.relative_to(project_dir)),
                    kind="skill",
                )
            )
    return project_file, entries


def build_project_bootstrap_paths(project_dir: Path) -> dict[str, str | None]:
    """Return common project file paths for local project payloads."""
    publish_path = project_dir / PUBLISH_CONFIG_RELATIVE_PATH
    return {
        "project_manifest_file": "pyproject.toml",
        "project_config_file": str(PROJECT_CONFIG_RELATIVE_PATH),
        "publish_file": (
            str(PUBLISH_CONFIG_RELATIVE_PATH.relative_to(PUBLISH_CONFIG_RELATIVE_PATH.parent))
            if publish_path.exists()
            else None
        ),
    }
