"""Project metadata and hidden scaffold configuration persistence."""

from __future__ import annotations

import re
import tomllib
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .constants import (
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    PROJECT_CONFIG_FILE_NAME,
    PROJECT_CONFIG_RELATIVE_PATH,
)
from .models import (
    CapabilitiesConfig,
    ModesConfig,
    ResourceConfig,
    TuningConfig,
)


class ProjectPackageMetadata(BaseModel):
    """Package identity sourced from ``pyproject.toml`` (name, version, author, description)."""

    model_config = ConfigDict(extra="forbid")

    name: str
    version: str = "0.1.0"
    author: str = ""
    description: str = ""


class PublishAdapterDecl(BaseModel):
    """Optional LoRA / adapter bundle declared under ``[[publish.adapters]]``."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    artifact_path: str


class ProjectPublishConfig(BaseModel):
    """Hidden packaging config stored in ``.aimp/project.toml``."""

    model_config = ConfigDict(extra="forbid")

    artifact_path: str = "artifacts"
    artifact_format: Literal["tar.zst"] = "tar.zst"
    selected_hardware_tier: str | None = None
    adapters: list[PublishAdapterDecl] = Field(default_factory=list)

    @field_validator("artifact_path")
    @classmethod
    def validate_artifact_path(cls, value: str) -> str:
        raw = str(value or "").strip()
        if not raw or raw == ".":
            raise ValueError(
                'publish.artifact_path must be "artifacts" (the execution bundle directory); '
                "legacy `.` is no longer supported."
            )
        cleaned = raw.replace("\\", "/").strip("/")
        while cleaned.startswith("./"):
            cleaned = cleaned[2:].lstrip("/")
        if cleaned != "artifacts":
            raise ValueError(
                'publish.artifact_path must be exactly "artifacts" at the project root. '
                "Additional adapter bundles belong under [[publish.adapters]]."
            )
        return "artifacts"

    @field_validator("artifact_format", mode="before")
    @classmethod
    def normalize_artifact_format(cls, value: object) -> str:
        return str(value or "").strip().lower()

    @field_validator("selected_hardware_tier", mode="before")
    @classmethod
    def normalize_selected_hardware_tier(cls, value: object) -> str | None:
        normalized = str(value or "").strip().lower()
        return normalized or None


class ProjectConfig(BaseModel):
    """Hidden scaffold configuration loaded from ``.aimp/project.toml``."""

    model_config = ConfigDict(extra="forbid")

    schema_version: int = DEFAULT_CONTRACT_SCHEMA_VERSION
    publish: ProjectPublishConfig = Field(default_factory=ProjectPublishConfig)
    capabilities: CapabilitiesConfig = Field(default_factory=CapabilitiesConfig)
    resources: ResourceConfig = Field(
        default_factory=lambda: ResourceConfig(vector_db=False),
    )
    modes: ModesConfig = Field(default_factory=lambda: ModesConfig({}))
    tuning: TuningConfig | None = None


def default_project_config() -> ProjectConfig:
    """Return the default hidden project configuration."""
    return ProjectConfig(schema_version=DEFAULT_CONTRACT_SCHEMA_VERSION)


def default_project_package_metadata(project_name: str) -> ProjectPackageMetadata:
    """Return default metadata for a new scaffolded model project."""
    normalized_name = project_name.strip() or "model"
    return ProjectPackageMetadata(
        name=normalized_name,
        version="0.1.0",
        author="",
        description=f"{normalized_name} model",
    )


def load_project_package_metadata(project_dir: Path) -> ProjectPackageMetadata:
    """Load package identity from ``pyproject.toml``.

    Reads ``[project].name``, ``[project].version``, ``[project].description``,
    and ``[tool.aimp.project].author``.
    """
    pyproject_path = project_dir / "pyproject.toml"
    if not pyproject_path.exists():
        raise RuntimeError("pyproject.toml not found. Run: ai init")
    raw = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    project = raw.get("project") or {}
    tool_aimp = (raw.get("tool") or {}).get("aimp") or {}
    aimp_project = tool_aimp.get("project") or {}

    name = str(project.get("name", "") or "").strip()
    version = str(project.get("version", "") or "").strip()
    description = str(project.get("description", "") or "").strip()
    author = str(aimp_project.get("author", "") or "").strip()

    if not name:
        raise RuntimeError("pyproject.toml [project].name is required")
    if not version:
        raise RuntimeError(
            'pyproject.toml [project].version is required. Set version = "0.1.0" under [project].'
        )
    return ProjectPackageMetadata(
        name=name,
        version=version,
        author=author,
        description=description,
    )


def write_project_package_metadata(project_dir: Path, metadata: ProjectPackageMetadata) -> Path:
    """Persist package fields to ``pyproject.toml``.

    Writes version to ``[project].version`` and author to
    ``[tool.aimp.project].author``.  Name and description are not overwritten
    since those are expected to be manually authored.
    """
    pyproject_path = project_dir / "pyproject.toml"
    if not pyproject_path.exists():
        raise RuntimeError("pyproject.toml not found. Run: ai init")
    current_text = pyproject_path.read_text(encoding="utf-8")
    updated = _replace_pyproject_field(current_text, "version", metadata.version, section="project")
    if metadata.author:
        updated = _ensure_toml_section(updated, "tool.aimp.project", {"author": metadata.author})
    pyproject_path.write_text(updated, encoding="utf-8")
    return pyproject_path


def _replace_pyproject_field(text: str, field: str, value: str, *, section: str) -> str:
    """Replace a field in a TOML section of ``pyproject.toml`` text."""
    lines = text.splitlines()
    inside_section = False
    section_header = f"[{section}]"
    replaced = False
    pattern = re.compile(rf"^(\s*{re.escape(field)}\s*=\s*)(['\"])(.*)(\2\s*)$")

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if stripped == section_header:
                inside_section = True
            else:
                inside_section = False
            continue
        if not inside_section:
            continue
        match = pattern.match(line)
        if match:
            prefix, quote_char, _, suffix = match.groups()
            lines[index] = f"{prefix}{quote_char}{value}{suffix}"
            replaced = True
            break

    if not replaced and inside_section is not None:
        insert_idx = len(lines)
        for index, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                break
            if stripped.startswith(f"{field} =") or stripped.startswith(f"{field} ="):
                insert_idx = index + 1
                break
        lines.append(f'{field} = "{value}"')

    result = "\n".join(lines)
    if not text.endswith("\n"):
        result += "\n"
    return result


def _ensure_toml_section(text: str, section: str, fields: dict[str, str]) -> str:
    """Ensure a TOML section exists with the given string fields, creating if needed."""
    import re as _re

    section_header = f"[{section}]"
    lines = text.splitlines()
    section_start = None

    for index, line in enumerate(lines):
        if line.strip() == section_header:
            section_start = index
            break

    if section_start is None:
        if not text.endswith("\n"):
            text += "\n"
        text += f"\n{section_header}\n"
        for key, val in fields.items():
            text += f'{key} = "{val}"\n'
        return text

    for key, val in fields.items():
        field_pattern = _re.compile(rf"^(\s*{re.escape(key)}\s*=\s*)(['\"])(.*)(\2\s*)$")
        found = False
        for index in range(section_start + 1, len(lines)):
            stripped = lines[index].strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                break
            match = field_pattern.match(lines[index])
            if match:
                prefix, quote_char, _, suffix = match.groups()
                lines[index] = f"{prefix}{quote_char}{val}{suffix}"
                found = True
                break
        if not found:
            insert_after = section_start + 1
            for index in range(section_start + 1, len(lines)):
                stripped = lines[index].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    break
                insert_after = index + 1
            lines.insert(insert_after, f'{key} = "{val}"')

    result = "\n".join(lines)
    if not result.endswith("\n"):
        result += "\n"
    return result


def load_project_config(project_dir: Path) -> ProjectConfig:
    """Load and validate ``.aimp/project.toml``."""
    raw = load_project_config_payload(project_dir)
    return build_project_config(raw)


def load_project_config_payload(project_dir: Path) -> dict[str, Any]:
    """Load raw ``.aimp/project.toml`` after file-level prechecks."""
    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    if not config_path.exists():
        legacy_path = project_dir / "aimp.config.toml"
        if legacy_path.exists():
            raise RuntimeError(
                "Root contract file is no longer supported: aimp.config.toml. "
                f"Use {PROJECT_CONFIG_FILE_NAME} instead."
            )
        raise RuntimeError(f"Config file not found: {PROJECT_CONFIG_FILE_NAME}. Run: ai init")
    raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
    if "parameters" in raw:
        raise RuntimeError(f"parameters are not allowed in {PROJECT_CONFIG_FILE_NAME}")
    if "required_secrets" in raw:
        raise RuntimeError(
            (
                f"{PROJECT_CONFIG_FILE_NAME} contains deprecated `required_secrets`, which must be "
                "removed. Move project runtime secrets to a project-local `.env` file "
                "(for example: `ZAI_API_KEY=...`)."
            )
        )
    return raw


def build_project_config(
    raw: dict[str, Any],
) -> ProjectConfig:
    """Validate raw project config payload into a canonical config object."""
    try:
        schema_version = int(raw.get("schema_version", 0))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(
            f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION} is required"
        ) from exc
    if schema_version != DEFAULT_CONTRACT_SCHEMA_VERSION:
        raise RuntimeError(
            f"schema_version = {DEFAULT_CONTRACT_SCHEMA_VERSION} is required in "
            f"{PROJECT_CONFIG_FILE_NAME}. "
            "Update schema_version or re-initialize the project."
        )
    raw_publish = raw.get("publish")
    if raw_publish is None:
        publish = ProjectPublishConfig()
    else:
        if not isinstance(raw_publish, dict):
            raise RuntimeError(f"publish must be a table in {PROJECT_CONFIG_FILE_NAME}")
        if "artifact_path" not in raw_publish:
            raise RuntimeError(f"publish.artifact_path is required in {PROJECT_CONFIG_FILE_NAME}")
        if "artifact_format" not in raw_publish:
            raise RuntimeError(f"publish.artifact_format is required in {PROJECT_CONFIG_FILE_NAME}")
        try:
            publish = ProjectPublishConfig.model_validate(raw_publish)
        except Exception as exc:  # pragma: no cover - pydantic shapes are unit tested elsewhere
            raise RuntimeError(f"publish config is invalid: {exc}") from exc
    try:
        capabilities = CapabilitiesConfig.model_validate(raw.get("capabilities") or {})
        resources = ResourceConfig.model_validate(raw.get("resources") or {})
        modes = ModesConfig.model_validate(raw.get("modes") or {})
    except Exception as exc:
        raise RuntimeError(f"project contract config is invalid: {exc}") from exc
    tuning_raw = raw.get("tuning")
    tuning: TuningConfig | None = None
    if tuning_raw is not None:
        if not isinstance(tuning_raw, dict):
            raise RuntimeError(f"tuning must be a table in {PROJECT_CONFIG_FILE_NAME}")
        try:
            tuning = TuningConfig.model_validate(tuning_raw)
        except Exception as exc:
            raise RuntimeError(f"tuning config is invalid: {exc}") from exc
    return ProjectConfig(
        schema_version=DEFAULT_CONTRACT_SCHEMA_VERSION,
        publish=publish,
        capabilities=capabilities,
        resources=resources,
        modes=modes,
        tuning=tuning,
    )


def write_project_config(project_dir: Path, config: ProjectConfig) -> Path:
    """Write the hidden scaffold configuration file."""
    from .serialization import serialize_project_config_toml

    config_path = project_dir / PROJECT_CONFIG_RELATIVE_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(serialize_project_config_toml(config), encoding="utf-8")
    return config_path


def resolve_project_mode_names(config: ProjectConfig) -> list[str]:
    """Return mode names declared in ``.aimp/project.toml``."""
    return sorted(config.modes.names())
