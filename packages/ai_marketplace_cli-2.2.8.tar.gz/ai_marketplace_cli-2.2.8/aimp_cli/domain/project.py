"""Current project-domain facade for scaffold, config, and publish helpers."""

from __future__ import annotations

from aimp_cli.domain.constants import (
    APP_PACKAGE_RELATIVE_PATH,
    DEFAULT_AGENT_NAME,
    DEFAULT_CONTRACT_SCHEMA_VERSION,
    DEFAULT_PUBLISH_SCHEMA_VERSION,
    DEFAULT_STUDIO_ARTICLE_MDX_FILE,
    DEFAULT_STUDIO_COVER_FILE,
    EMBEDDER_PACKAGE_NAME,
    FINE_TUNE_MODEL_ENTRYPOINT_RELATIVE_PATH,
    GENERATOR_PACKAGE_NAME,
    LEGACY_PUBLISH_CONFIG_FILE_NAME,
    MODEL_ENTRYPOINT_RELATIVE_PATH,
    PROJECT_CONFIG_FILE_NAME,
    PROJECT_CONFIG_RELATIVE_PATH,
    PUBLISH_CONFIG_FILE_NAME,
    PUBLISH_CONFIG_RELATIVE_PATH,
    SKILLS_RELATIVE_PATH,
    TUNING_ASSETS_RELATIVE_PATH,
    TUNING_BUNDLE_FILE_NAME,
    TUNING_HIDDEN_DIR_PATH,
    TUNING_HIDDEN_HELPERS_FILE,
    TUNING_HIDDEN_INIT_FILE,
    TUNING_HIDDEN_SCHEMA_FILE,
    TUNING_HIDDEN_SCHEMA_FILE_NAME,
    TUNING_HIDDEN_SCHEMA_TYPES_FILE,
    TUNING_PREPARE_SCRIPT_FILE_NAME,
    TUNING_README_FILE_NAME,
)
from aimp_cli.domain.discovery import ProjectSkillEntry, find_project_root, list_project_skills
from aimp_cli.domain.project_config import (
    ProjectConfig,
    ProjectPackageMetadata,
    ProjectPublishConfig,
    default_project_config,
    default_project_package_metadata,
    load_project_config,
    load_project_package_metadata,
    write_project_config,
    write_project_package_metadata,
)
from aimp_cli.domain.publish_config import (
    PublishMetadataConfig,
    PublishStudioConfig,
    load_publish_config,
    load_studio_article_source,
    resolve_studio_file_paths,
)
from aimp_cli.domain.serialization import (
    project_config_toml_template,
    project_package_toml_template,
    publish_config_toml_template,
    serialize_project_config_toml,
    serialize_project_package_toml,
    serialize_publish_config_toml,
)
from aimp_cli.operations.publish.local_metadata import (
    RemoteModelPublishSnapshot,
    build_local_publish_metadata,
)
from aimp_cli.operations.scaffold.files import (
    create_consumer_tuning_scaffold,
    regenerate_tuning_scaffold,
    studio_article_mdx_template,
    write_default_studio_cover,
)
from aimp_cli.operations.scaffold.init_project import create_project_scaffold
from aimp_cli.operations.scaffold.tuning import default_tuning_workspace_config
from aimp_cli.utils.docker_build import (
    MODEL_RUNTIME_DOCKERFILE,
    extract_docker_context_sources,
    resolve_docker_build_spec,
    validate_publish_runtime_layout,
    validate_runtime_dockerfile_dependency_layer_order,
)

__all__ = [
    "APP_PACKAGE_RELATIVE_PATH",
    "ProjectPackageMetadata",
    "DEFAULT_AGENT_NAME",
    "DEFAULT_CONTRACT_SCHEMA_VERSION",
    "DEFAULT_PUBLISH_SCHEMA_VERSION",
    "DEFAULT_STUDIO_ARTICLE_MDX_FILE",
    "DEFAULT_STUDIO_COVER_FILE",
    "EMBEDDER_PACKAGE_NAME",
    "MODEL_ENTRYPOINT_RELATIVE_PATH",
    "FINE_TUNE_MODEL_ENTRYPOINT_RELATIVE_PATH",
    "GENERATOR_PACKAGE_NAME",
    "LEGACY_PUBLISH_CONFIG_FILE_NAME",
    "load_project_package_metadata",
    "PROJECT_CONFIG_FILE_NAME",
    "PROJECT_CONFIG_RELATIVE_PATH",
    "PUBLISH_CONFIG_FILE_NAME",
    "PUBLISH_CONFIG_RELATIVE_PATH",
    "ProjectConfig",
    "ProjectPublishConfig",
    "ProjectSkillEntry",
    "PublishMetadataConfig",
    "PublishStudioConfig",
    "RemoteModelPublishSnapshot",
    "SKILLS_RELATIVE_PATH",
    "TUNING_ASSETS_RELATIVE_PATH",
    "TUNING_BUNDLE_FILE_NAME",
    "TUNING_HIDDEN_DIR_PATH",
    "TUNING_HIDDEN_HELPERS_FILE",
    "TUNING_HIDDEN_INIT_FILE",
    "TUNING_HIDDEN_SCHEMA_FILE",
    "TUNING_HIDDEN_SCHEMA_FILE_NAME",
    "TUNING_HIDDEN_SCHEMA_TYPES_FILE",
    "TUNING_PREPARE_SCRIPT_FILE_NAME",
    "TUNING_README_FILE_NAME",
    "project_package_toml_template",
    "build_local_publish_metadata",
    "create_consumer_tuning_scaffold",
    "create_project_files",
    "default_project_package_metadata",
    "default_project_config",
    "list_project_skills",
    "load_project_config",
    "load_publish_config",
    "load_studio_article_source",
    "project_config_toml_template",
    "publish_config_toml_template",
    "regenerate_tuning_scaffold",
    "MODEL_RUNTIME_DOCKERFILE",
    "resolve_docker_build_spec",
    "validate_publish_runtime_layout",
    "validate_runtime_dockerfile_dependency_layer_order",
    "resolve_studio_file_paths",
    "serialize_project_package_toml",
    "serialize_project_config_toml",
    "serialize_publish_config_toml",
    "studio_article_mdx_template",
    "write_project_package_metadata",
    "write_default_studio_cover",
    "write_project_config",
]


def create_project_files(name: str):
    """Create a project scaffold from framework-owned templates."""
    return create_project_scaffold(name)
