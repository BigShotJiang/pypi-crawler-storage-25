"""Interactive launcher and prompt helpers for the Python CLI."""

from __future__ import annotations

import getpass
import io
import shutil
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

import typer
from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from aimp_cli import __version__
from aimp_cli.core.config import ZINC_THEME, has_interactive_terminal

try:
    from prompt_toolkit import Application
    from prompt_toolkit.formatted_text import ANSI
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.key_binding.key_processor import KeyPressEvent
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style as PromptStyle
    from prompt_toolkit.widgets import TextArea

    _PROMPT_TOOLKIT_AVAILABLE = True
except ModuleNotFoundError:
    Application = Any
    ANSI = Any
    KeyBindings = Any
    KeyPressEvent = Any
    HSplit = Any
    Layout = Any
    Window = Any
    FormattedTextControl = Any
    PromptStyle = None
    TextArea = Any
    _PROMPT_TOOLKIT_AVAILABLE = False

ASCII_HEADER = r"""
 █████╗ ██╗███╗   ███╗██████╗      ██████╗██╗     ██╗
██╔══██╗██║████╗ ████║██╔══██╗    ██╔════╝██║     ██║
███████║██║██╔████╔██║██████╔╝    ██║     ██║     ██║
██╔══██║██║██║╚██╔╝██║██╔═══╝     ██║     ██║     ██║
██║  ██║██║██║ ╚═╝ ██║██║         ╚██████╗███████╗██║
╚═╝  ╚═╝╚═╝╚═╝     ╚═╝╚═╝          ╚═════╝╚══════╝╚═╝
"""

COMPACT_HEADER = "AIMP CLI"
MIN_TERMINAL_WIDTH = 48
WIDE_HEADER_WIDTH = 100
COMPACT_HEADER_WIDTH = 70

_PROMPT_STYLE = (
    PromptStyle.from_dict(
        {
            "input-field": "fg:#e2e8f0 bg:#111827",
            "detail-body": "fg:#e2e8f0 bg:#020617",
        }
    )
    if _PROMPT_TOOLKIT_AVAILABLE and PromptStyle is not None
    else None
)

LauncherNavAction = Literal["back", "home", "quit"]


@dataclass(frozen=True, slots=True)
class LauncherActionResult:
    """Scrollable result payload displayed inside the TUI."""

    title: str
    content: str
    subtitle: str | None = None
    status: Literal["info", "success", "error"] = "info"
    show_status_badge: bool = True


@dataclass(frozen=True, slots=True)
class LauncherNavigationRequest:
    """Internal navigation request returned by launcher handlers."""

    action: LauncherNavAction


@dataclass(frozen=True, slots=True)
class LauncherOption:
    """Selectable launcher action."""

    key: str
    label: str
    description: str
    handler: Callable[[], LauncherActionResult | LauncherNavigationRequest | None]


@dataclass(frozen=True, slots=True)
class LauncherSection:
    """Logical launcher section."""

    title: str
    options: list[LauncherOption]


@dataclass(slots=True)
class _LauncherState:
    """Mutable launcher selection state."""

    sections: list[LauncherSection]
    options: list[LauncherOption]
    selected_index: int = 0

    @property
    def current(self) -> LauncherOption:
        """Return the currently selected option."""
        return self.options[self.selected_index]

    def move(self, delta: int) -> None:
        """Move selection with wraparound."""
        self.selected_index = (self.selected_index + delta) % len(self.options)


@dataclass(slots=True)
class _MultiLauncherState:
    """Mutable multi-select launcher state."""

    sections: list[LauncherSection]
    options: list[LauncherOption]
    selected_keys: set[str] = field(default_factory=set)
    selected_index: int = 0

    @property
    def current(self) -> LauncherOption:
        """Return the currently selected option."""
        return self.options[self.selected_index]

    def move(self, delta: int) -> None:
        """Move selection with wraparound."""
        self.selected_index = (self.selected_index + delta) % len(self.options)

    def toggle_current(self) -> None:
        """Toggle the current option selection."""
        key = self.current.key
        if key in self.selected_keys:
            self.selected_keys.remove(key)
            return
        self.selected_keys.add(key)


@dataclass(frozen=True, slots=True)
class _ScreenChrome:
    """Shared screen metadata for launcher views."""

    show_header: bool = True
    title: str | None = None
    subtitle: str | None = None
    details: Any | None = None


def _flatten_options(sections: list[LauncherSection]) -> list[LauncherOption]:
    flattened: list[LauncherOption] = []
    for section in sections:
        flattened.extend(section.options)
    return flattened


def _build_footer(entries: list[tuple[str, str]], *, width: int) -> Table:
    footer = Table.grid(expand=True)
    footer.add_column(style="muted")
    footer.add_row(Text("─" * max(width - 2, 10), style="border"))
    footer.add_row(
        Text.assemble(
            *[
                segment
                for index, (key, label) in enumerate(entries)
                for segment in (
                    ((f" {key} ", "bold grey70"), f"{label}")
                    if index == len(entries) - 1
                    else ((f" {key} ", "bold grey70"), f"{label}  ")
                )
            ]
        )
    )
    return footer


def _render_header(console: Console, *, width: int) -> None:
    if width >= WIDE_HEADER_WIDTH:
        console.print(Text(ASCII_HEADER, style="bold bright_white"))
        console.print(Text(f" v{__version__}", style="grey50"))
        return
    if width >= COMPACT_HEADER_WIDTH:
        console.print(Text(COMPACT_HEADER, style="bold bright_white"))
        console.print(Text(" Marketplace model tooling", style="grey50"))
        return
    console.print(Text("AIMP", style="bold bright_white"))


def _render_chrome(console: Console, *, chrome: _ScreenChrome, width: int) -> None:
    if chrome.show_header:
        _render_header(console, width=width)
    if chrome.title:
        console.print(Text(chrome.title.upper(), style="label bold"))
    if chrome.subtitle:
        console.print(Text(chrome.subtitle, style="muted"))
    if chrome.details is not None:
        if chrome.title or chrome.subtitle:
            console.print("")
        console.print(chrome.details)
    if chrome.title or chrome.subtitle or chrome.details is not None:
        console.print("")


def _build_description_panel(option: LauncherOption) -> Panel:
    description = option.description or "No additional details."
    return Panel(
        Text(description, style="primary"),
        title=f" {option.label} ",
        title_align="left",
        border_style="border",
    )


def _build_menu_body(
    *,
    state: _LauncherState | _MultiLauncherState,
    width: int,
    multi_select: bool,
) -> Any:
    menu_table = Table.grid(padding=(0, 1))
    menu_table.add_column(style="primary")

    current_idx = 0
    for section in state.sections:
        menu_table.add_row(Text(f"\n{section.title.upper()}", style="label bold"))
        for option in section.options:
            is_current = current_idx == state.selected_index
            if multi_select:
                if not isinstance(state, _MultiLauncherState):
                    raise RuntimeError("Expected multi-select state")
                marker = "[x]" if option.key in state.selected_keys else "[ ]"
                prefix = " > " if is_current else "   "
                style = "info bold" if is_current else "muted"
                menu_table.add_row(Text(f"{prefix}{marker} {option.label}", style=style))
            else:
                prefix = " > " if is_current else "   "
                style = "info bold" if is_current else "muted"
                menu_table.add_row(Text(f"{prefix}{option.label}", style=style))
            current_idx += 1

    description_panel = _build_description_panel(state.current)
    if width >= 96:
        columns = Table.grid(expand=True)
        columns.add_column(ratio=3)
        columns.add_column(ratio=2)
        columns.add_row(menu_table, description_panel)
        return columns
    return Group(menu_table, description_panel)


def _render_screen(
    state: _LauncherState,
    width: int = 100,
    *,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> str:
    output = io.StringIO()
    console = Console(
        file=output,
        force_terminal=True,
        width=max(width, MIN_TERMINAL_WIDTH),
        theme=ZINC_THEME,
    )
    chrome = _ScreenChrome(
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )
    _render_chrome(console, chrome=chrome, width=max(width, MIN_TERMINAL_WIDTH))
    console.print(_build_menu_body(state=state, width=width, multi_select=False))
    console.print("")
    console.print(
        _build_footer(
            [("ARROWS", "move"), ("ENTER", "select"), ("ESC", "cancel")],
            width=width,
        )
    )
    return output.getvalue()


def _render_multi_select_screen(
    state: _MultiLauncherState,
    width: int = 100,
    *,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> str:
    output = io.StringIO()
    console = Console(
        file=output,
        force_terminal=True,
        width=max(width, MIN_TERMINAL_WIDTH),
        theme=ZINC_THEME,
    )
    chrome = _ScreenChrome(
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )
    _render_chrome(console, chrome=chrome, width=max(width, MIN_TERMINAL_WIDTH))
    console.print(_build_menu_body(state=state, width=width, multi_select=True))
    console.print("")
    console.print(
        _build_footer(
            [("ARROWS", "move"), ("SPACE", "toggle"), ("ENTER", "confirm"), ("ESC", "cancel")],
            width=width,
        )
    )
    return output.getvalue()


def _render_prompt_screen(
    *,
    message: str,
    width: int,
    show_header: bool,
    title: str | None,
    subtitle: str | None,
    details: Any | None,
) -> str:
    output = io.StringIO()
    console = Console(
        file=output,
        force_terminal=True,
        width=max(width, MIN_TERMINAL_WIDTH),
        theme=ZINC_THEME,
    )
    chrome = _ScreenChrome(
        show_header=show_header,
        title=title or message,
        subtitle=subtitle,
        details=details,
    )
    _render_chrome(console, chrome=chrome, width=max(width, MIN_TERMINAL_WIDTH))
    console.print(Panel(Text(message, style="primary"), border_style="border"))
    return output.getvalue()


def _render_detail_content(
    result: LauncherActionResult,
    *,
    width: int,
    show_header: bool,
) -> str:
    """Render detail content as an ANSI string for the detail screen."""
    output = io.StringIO()
    console = Console(
        file=output,
        force_terminal=True,
        no_color=False,
        color_system="truecolor",
        width=max(width, MIN_TERMINAL_WIDTH),
        theme=ZINC_THEME,
    )
    chrome = _ScreenChrome(
        show_header=show_header,
        title=result.title,
        subtitle=result.subtitle,
    )
    _render_chrome(console, chrome=chrome, width=max(width, MIN_TERMINAL_WIDTH))
    status_style = {
        "info": "border",
        "success": "success",
        "error": "error",
    }[result.status]
    status_badge = {
        "info": "● INFO",
        "success": "✔ SUCCESS",
        "error": "✖ ERROR",
    }[result.status]
    rule_width = max(width, MIN_TERMINAL_WIDTH) - 2
    if result.show_status_badge:
        console.print(Text(f" {status_badge}", style=f"bold {status_style}"))
        console.print(Text("─" * rule_width, style=status_style))
        console.print("")
    content = result.content.strip() or "No output."
    console.print(Text.from_ansi(content))
    return output.getvalue()


def _build_detail_layout(*, body: Window, footer_window: Window) -> Layout:
    """Build the fixed-footer layout used by detail screens."""
    return Layout(
        HSplit([body, footer_window]),
        focused_element=body,
    )


def _build_prompt_layout(
    *,
    render_body: Callable[[], ANSI],
    input_field: TextArea,
    footer_window: Window,
) -> Layout:
    body_window = Window(
        content=FormattedTextControl(render_body),
        always_hide_cursor=True,
        dont_extend_height=True,
    )
    return Layout(
        HSplit([body_window, input_field, footer_window]),
        focused_element=input_field,
    )


class TerminalUI:
    """Unified interactive terminal controller built on ``prompt_toolkit``."""

    def _terminal_width(self, application: Application[Any] | None = None) -> int:
        if application is not None:
            return max(application.output.get_size().columns, MIN_TERMINAL_WIDTH)
        return max(shutil.get_terminal_size((100, 30)).columns, MIN_TERMINAL_WIDTH)

    def select_menu(
        self,
        sections: list[LauncherSection],
        *,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> LauncherOption | None:
        """Show a single-select menu."""
        if not _PROMPT_TOOLKIT_AVAILABLE or not has_interactive_terminal():
            raise RuntimeError("Interactive selector unavailable")
        options = _flatten_options(sections)
        state = _LauncherState(sections=sections, options=options)
        application: Application[LauncherOption | None] | None = None

        def render_content() -> ANSI:
            return ANSI(
                _render_screen(
                    state,
                    width=self._terminal_width(application),
                    show_header=show_header,
                    title=title,
                    subtitle=subtitle,
                    details=details,
                )
            )

        bindings = KeyBindings()

        @bindings.add("up")
        def _handle_up(event: KeyPressEvent) -> None:
            _ = event
            state.move(-1)
            if application is not None:
                application.invalidate()

        @bindings.add("down")
        def _handle_down(event: KeyPressEvent) -> None:
            _ = event
            state.move(1)
            if application is not None:
                application.invalidate()

        @bindings.add("enter")
        def _handle_enter(event: KeyPressEvent) -> None:
            event.app.exit(result=state.current)

        @bindings.add("escape")
        @bindings.add("c-c")
        def _handle_exit(event: KeyPressEvent) -> None:
            event.app.exit(result=None)

        application = Application(
            layout=Layout(
                Window(
                    content=FormattedTextControl(render_content),
                    always_hide_cursor=True,
                    dont_extend_height=True,
                )
            ),
            key_bindings=bindings,
            full_screen=False,
            mouse_support=False,
            erase_when_done=True,
        )
        return application.run()

    def select_multi_menu(
        self,
        sections: list[LauncherSection],
        *,
        preselected_keys: list[str] | None = None,
        show_header: bool = True,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> list[str] | None:
        """Show a multi-select menu."""
        if not _PROMPT_TOOLKIT_AVAILABLE or not has_interactive_terminal():
            raise RuntimeError("Interactive selector unavailable")
        options = _flatten_options(sections)
        state = _MultiLauncherState(
            sections=sections,
            options=options,
            selected_keys=set(preselected_keys or []),
        )
        application: Application[list[str] | None] | None = None

        def render_content() -> ANSI:
            return ANSI(
                _render_multi_select_screen(
                    state,
                    width=self._terminal_width(application),
                    show_header=show_header,
                    title=title,
                    subtitle=subtitle,
                    details=details,
                )
            )

        bindings = KeyBindings()

        @bindings.add("up")
        def _handle_up(event: KeyPressEvent) -> None:
            _ = event
            state.move(-1)
            if application is not None:
                application.invalidate()

        @bindings.add("down")
        def _handle_down(event: KeyPressEvent) -> None:
            _ = event
            state.move(1)
            if application is not None:
                application.invalidate()

        @bindings.add("space")
        def _handle_space(event: KeyPressEvent) -> None:
            _ = event
            state.toggle_current()
            if application is not None:
                application.invalidate()

        @bindings.add("enter")
        def _handle_enter(event: KeyPressEvent) -> None:
            result = [option.key for option in options if option.key in state.selected_keys]
            event.app.exit(result=result)

        @bindings.add("escape")
        @bindings.add("c-c")
        def _handle_exit(event: KeyPressEvent) -> None:
            event.app.exit(result=None)

        application = Application(
            layout=Layout(
                Window(
                    content=FormattedTextControl(render_content),
                    always_hide_cursor=True,
                    dont_extend_height=True,
                )
            ),
            key_bindings=bindings,
            full_screen=False,
            mouse_support=False,
            erase_when_done=True,
        )
        return application.run()

    def prompt_text(
        self,
        message: str,
        *,
        default: str | None = None,
        is_password: bool = False,
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> str | None:
        """Prompt for text or secret input using the unified TUI."""
        if not _PROMPT_TOOLKIT_AVAILABLE or not has_interactive_terminal():
            return _prompt_value_plain(message, default=default, is_password=is_password)

        application: Application[str | None] | None = None
        input_field = TextArea(
            text=default or "",
            multiline=False,
            password=is_password,
            wrap_lines=False,
            style="class:input-field",
            prompt="> ",
            height=1,
            dont_extend_height=True,
        )

        def render_body() -> ANSI:
            return ANSI(
                _render_prompt_screen(
                    message=message,
                    width=self._terminal_width(application),
                    show_header=show_header,
                    title=title,
                    subtitle=subtitle,
                    details=details,
                )
            )

        footer_window = Window(
            content=FormattedTextControl(
                lambda: ANSI(
                    _render_footer_screen(
                        width=self._terminal_width(application),
                        default=default,
                    )
                )
            ),
            height=2,
            always_hide_cursor=True,
            dont_extend_height=True,
        )

        bindings = KeyBindings()

        @bindings.add("enter")
        def _handle_enter(event: KeyPressEvent) -> None:
            _ = event
            value = input_field.text.strip()
            event.app.exit(result=value or default)

        @bindings.add("escape")
        @bindings.add("c-c")
        def _handle_exit(event: KeyPressEvent) -> None:
            event.app.exit(result=None)

        application = Application(
            layout=_build_prompt_layout(
                render_body=render_body,
                input_field=input_field,
                footer_window=footer_window,
            ),
            style=_PROMPT_STYLE,
            key_bindings=bindings,
            full_screen=False,
            mouse_support=False,
            erase_when_done=True,
        )
        return application.run()

    def show_detail(
        self,
        result: LauncherActionResult,
        *,
        show_header: bool = True,
    ) -> LauncherNavAction:
        """Display a scrollable detail view and return the next navigation action."""
        if not _PROMPT_TOOLKIT_AVAILABLE or not has_interactive_terminal():
            return "back"

        rendered = _render_detail_content(
            result,
            width=self._terminal_width() - 1,
            show_header=show_header,
        )

        body_window = Window(
            content=FormattedTextControl(lambda: ANSI(rendered), focusable=True),
            wrap_lines=False,
            allow_scroll_beyond_bottom=False,
            style="class:detail-body",
            dont_extend_height=True,
        )
        application: Application[LauncherNavAction] | None = None

        footer_window = Window(
            content=FormattedTextControl(
                lambda: ANSI(
                    _render_footer_screen(
                        width=self._terminal_width(application),
                        default=None,
                        entries=[
                            ("ARROWS", "move"),
                            ("PGUP/PGDN", "page"),
                            ("B/ESC", "back"),
                            ("H", "home"),
                            ("Q", "exit"),
                        ],
                    )
                )
            ),
            height=2,
            always_hide_cursor=True,
            dont_extend_height=True,
        )

        bindings = KeyBindings()

        @bindings.add("up")
        def _scroll_up(event: KeyPressEvent) -> None:
            _ = event
            body_window.vertical_scroll = max(0, body_window.vertical_scroll - 1)

        @bindings.add("down")
        def _scroll_down(event: KeyPressEvent) -> None:
            _ = event
            body_window.vertical_scroll += 1

        @bindings.add("pageup")
        def _page_up(event: KeyPressEvent) -> None:
            _ = event
            body_window.vertical_scroll = max(0, body_window.vertical_scroll - 10)

        @bindings.add("pagedown")
        def _page_down(event: KeyPressEvent) -> None:
            _ = event
            body_window.vertical_scroll += 10

        @bindings.add("b", eager=True)
        @bindings.add("escape", eager=True)
        def _handle_back(event: KeyPressEvent) -> None:
            event.app.exit(result="back")

        @bindings.add("h", eager=True)
        def _handle_home(event: KeyPressEvent) -> None:
            event.app.exit(result="home")

        @bindings.add("q", eager=True)
        @bindings.add("c-c", eager=True)
        def _handle_quit(event: KeyPressEvent) -> None:
            event.app.exit(result="quit")

        application = Application(
            layout=_build_detail_layout(body=body_window, footer_window=footer_window),
            style=_PROMPT_STYLE,
            key_bindings=bindings,
            full_screen=False,
            mouse_support=False,
            erase_when_done=True,
        )
        return application.run()

    def confirm_action(
        self,
        message: str,
        *,
        default: bool = True,
        confirm_label: str = "Confirm",
        cancel_label: str = "Cancel",
        confirm_description: str = "Proceed with this action.",
        cancel_description: str = "Return without making changes.",
        show_header: bool = False,
        title: str | None = None,
        subtitle: str | None = None,
        details: Any | None = None,
    ) -> bool:
        """Prompt for a semantic binary choice using the unified TUI."""
        yes_option = LauncherOption(
            key="confirm",
            label=confirm_label,
            description=confirm_description,
            handler=lambda: None,
        )
        no_option = LauncherOption(
            key="cancel",
            label=cancel_label,
            description=cancel_description,
            handler=lambda: None,
        )
        options = [yes_option, no_option] if default else [no_option, yes_option]
        selected = self.select_menu(
            [LauncherSection(title="Confirm", options=options)],
            show_header=show_header,
            title=title or message,
            subtitle=subtitle,
            details=details,
        )
        return selected is not None and selected.key == "confirm"


def _render_footer_screen(
    *,
    width: int,
    default: str | None,
    entries: list[tuple[str, str]] | None = None,
) -> str:
    output = io.StringIO()
    console = Console(
        file=output,
        force_terminal=True,
        width=max(width, MIN_TERMINAL_WIDTH),
        theme=ZINC_THEME,
    )
    footer_entries = list(entries or [("ENTER", "submit"), ("ESC", "cancel")])
    if default:
        footer_entries.insert(0, ("DEFAULT", default))
    console.print(_build_footer(footer_entries, width=width))
    return output.getvalue()


def _prompt_value_plain(message: str, *, default: str | None, is_password: bool) -> str | None:
    prompt_suffix = f" [{default}]" if default else ""
    prompt_text = f"{message}{prompt_suffix}: "
    try:
        result = getpass.getpass(prompt_text) if is_password else input(prompt_text)
    except (EOFError, KeyboardInterrupt):
        return None
    stripped = result.strip()
    return stripped or default


_DEFAULT_UI = TerminalUI()


def select_menu(
    sections: list[LauncherSection],
    *,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> LauncherOption | None:
    """Show a one-shot interactive menu and return the selected option."""
    return _DEFAULT_UI.select_menu(
        sections,
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )


def select_multi_menu(
    sections: list[LauncherSection],
    *,
    preselected_keys: list[str] | None = None,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> list[str] | None:
    """Show a multi-select menu and return selected option keys."""
    return _DEFAULT_UI.select_multi_menu(
        sections,
        preselected_keys=preselected_keys,
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )


def prompt_text(
    message: str,
    *,
    console: Console,
    default: str | None = None,
    show_header: bool = False,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> str | None:
    """Prompt for text input within the launcher."""
    _ = console
    return _DEFAULT_UI.prompt_text(
        message,
        default=default,
        is_password=False,
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )


def prompt_secret(
    message: str,
    *,
    console: Console,
    show_header: bool = False,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> str | None:
    """Prompt for a hidden value within the launcher."""
    _ = console
    return _DEFAULT_UI.prompt_text(
        message,
        default=None,
        is_password=True,
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )


def confirm_action(
    message: str,
    *,
    console: Console,
    default: bool = True,
    confirm_label: str = "Confirm",
    cancel_label: str = "Cancel",
    confirm_description: str = "Proceed with this action.",
    cancel_description: str = "Return without making changes.",
    show_header: bool = False,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
) -> bool:
    """Prompt for a semantic binary choice within the launcher."""
    _ = console
    return _DEFAULT_UI.confirm_action(
        message,
        default=default,
        confirm_label=confirm_label,
        cancel_label=cancel_label,
        confirm_description=confirm_description,
        cancel_description=cancel_description,
        show_header=show_header,
        title=title,
        subtitle=subtitle,
        details=details,
    )


def run_interactive_launcher(
    sections_factory: Callable[[], list[LauncherSection]],
    *,
    console: Console,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
    details: Any | None = None,
    cancel_action: LauncherNavAction = "quit",
) -> LauncherNavAction:
    """Run the interactive launcher until the user exits."""
    while True:
        sections = sections_factory()
        try:
            selected = select_menu(
                sections,
                show_header=show_header,
                title=title,
                subtitle=subtitle,
                details=details,
            )
        except Exception:
            console.print(
                "[yellow]Interactive selector unavailable. Falling back to plain menu.[/yellow]"
            )
            selected = _select_option_fallback(
                sections,
                console=console,
                show_header=show_header,
                title=title,
                subtitle=subtitle,
            )
        if selected is None:
            return cancel_action
        if selected.key == "quit":
            return "quit"
        if selected.key == "back":
            return "back"
        try:
            handler_result = selected.handler()
        except typer.Exit as exit_error:
            if exit_error.exit_code != 0:
                raise
            continue
        if isinstance(handler_result, LauncherNavigationRequest):
            if handler_result.action == "quit":
                return "quit"
            if handler_result.action == "home":
                return "home"
            continue
        if isinstance(handler_result, LauncherActionResult):
            nav_action = _DEFAULT_UI.show_detail(
                handler_result,
                show_header=show_header,
            )
            if nav_action == "quit":
                return "quit"
            if nav_action == "home":
                return "home"


def _select_option_fallback(
    sections: list[LauncherSection],
    *,
    console: Console,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
) -> LauncherOption | None:
    options = _flatten_options(sections)
    if show_header:
        console.print("[header]AIMP CLI[/header]")
        console.print("")
    if title:
        console.print(f"[label]{title}[/label]")
    if subtitle:
        console.print(f"[muted]{subtitle}[/muted]")
    if title or subtitle:
        console.print("")
    for index, option in enumerate(options, start=1):
        console.print(f"{index}. {option.label}")
        console.print(f"   [muted]{option.description}[/muted]")
    raw_choice = _prompt_value_plain("Choose an action number", default=None, is_password=False)
    if raw_choice is None or not raw_choice.isdigit():
        return None
    choice_index = int(raw_choice) - 1
    if choice_index < 0 or choice_index >= len(options):
        return None
    return options[choice_index]


def select_menu_fallback(
    sections: list[LauncherSection],
    *,
    console: Console,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
) -> LauncherOption | None:
    """Fallback single-select prompt for terminals without full TUI support."""
    return _select_option_fallback(
        sections,
        console=console,
        show_header=show_header,
        title=title,
        subtitle=subtitle,
    )


def select_multi_menu_fallback(
    sections: list[LauncherSection],
    *,
    console: Console,
    preselected_keys: list[str] | None = None,
    show_header: bool = True,
    title: str | None = None,
    subtitle: str | None = None,
) -> list[str] | None:
    """Fallback multi-select prompt for terminals without full TUI support."""
    options = _flatten_options(sections)
    preselected = set(preselected_keys or [])
    if show_header:
        console.print("[header]AIMP CLI[/header]")
        console.print("")
    if title:
        console.print(f"[label]{title}[/label]")
    if subtitle:
        console.print(f"[muted]{subtitle}[/muted]")
    if title or subtitle:
        console.print("")
    for index, option in enumerate(options, start=1):
        marker = "[x]" if option.key in preselected else "[ ]"
        console.print(f"{index}. {marker} {option.label}")
        console.print(f"   [muted]{option.description}[/muted]")
    raw_choice = _prompt_value_plain(
        "Choose one or more action numbers (comma-separated)",
        default=None,
        is_password=False,
    )
    if raw_choice is None:
        return None
    normalized = raw_choice.strip()
    if not normalized:
        return [option.key for option in options if option.key in preselected]
    selected_indexes: list[int] = []
    for item in normalized.split(","):
        value = item.strip()
        if not value.isdigit():
            return None
        selected_indexes.append(int(value) - 1)
    if any(index < 0 or index >= len(options) for index in selected_indexes):
        return None
    selected_keys: list[str] = []
    for index in selected_indexes:
        key = options[index].key
        if key not in selected_keys:
            selected_keys.append(key)
    return selected_keys
