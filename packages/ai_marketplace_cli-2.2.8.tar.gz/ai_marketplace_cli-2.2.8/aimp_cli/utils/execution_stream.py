"""Shared SSE job stream parsing and watch helpers for the CLI."""

from __future__ import annotations

import json
import os
import random
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal

from aimp_cli.core.config import CommandContext
from aimp_cli.core.errors import (
    CliError,
    ErrorCategory,
    environment_error,
    internal_error,
    network_error,
    remote_state_error,
)
from aimp_cli.domain.models import PublishBuildGroup
from aimp_cli.domain.protocols import JobStreamGatewayProtocol

_ACTIVE_EXECUTION_STATUSES = frozenset({"queued", "running", "canceling"})
_TERMINAL_FAILURE_STATUSES = frozenset({"failed", "canceled"})


def _reconnect_delay_seconds(attempt: int) -> float:
    """Bounded exponential backoff with jitter between SSE reconnect attempts."""
    raw_base = os.environ.get("AIMP_JOB_STREAM_RECONNECT_BASE_SECONDS", "").strip()
    raw_cap = os.environ.get("AIMP_JOB_STREAM_RECONNECT_MAX_SECONDS", "").strip()
    try:
        base = float(raw_base) if raw_base else 0.75
    except ValueError:
        base = 0.75
    try:
        cap = float(raw_cap) if raw_cap else 30.0
    except ValueError:
        cap = 30.0
    base = max(0.05, base)
    cap = max(base, cap)
    exp = min(attempt, 12)
    delay = min(cap, base * (2**exp))
    jitter = random.uniform(0, min(1.0, delay * 0.1))
    return delay + jitter


def _reconcile_raw_to_outcome(
    raw: dict[str, Any],
    *,
    context: CommandContext,
    job_id: str,
    config: StreamReconcileConfig,
) -> dict[str, Any] | None:
    """Classify one REST job payload: terminal success dict, or None if still active."""
    if config.kind == "publish":
        group = PublishBuildGroup.model_validate(raw)
        status = str(group.status or "").strip().lower()
        if status in _ACTIVE_EXECUTION_STATUSES:
            return None
        if status in _TERMINAL_FAILURE_STATUSES:
            raise environment_error(
                _publish_terminal_failure_message_from_dict(raw),
                code=group.error_code or "publish_build_failed",
                extra={
                    "job_id": job_id,
                    "phase": group.phase,
                    "stage": group.stage,
                    "current_step_message": group.current_step_message,
                },
            )
        if status == "succeeded":
            return dict(raw)
        raise remote_state_error(
            f"Remote publish build has unexpected status after stream disconnect: {status}",
            code="job_stream_reconcile_unexpected",
            request_id=context.request_id,
            extra={"job_id": job_id, "status": status},
        )

    job = raw.get("job") if isinstance(raw.get("job"), dict) else raw
    if not isinstance(job, dict):
        raise internal_error(
            "Gateway returned an invalid job detail payload during stream reconcile.",
            code="gateway_job_detail_invalid",
            request_id=context.request_id,
        )
    status = str(job.get("status") or "").strip().lower()
    if status in _ACTIVE_EXECUTION_STATUSES:
        return None
    if status in _TERMINAL_FAILURE_STATUSES:
        msg = str(job.get("error_message") or "").strip() or "Remote job failed"
        prefix = (
            "Remote build failed"
            if config.job_type_for_hint == "build"
            else "Remote job failed"
        )
        raise remote_state_error(
            f"{prefix}: {msg}",
            code="remote_job_failed",
            request_id=context.request_id,
            hint=_jobs_get_hint(job_id=job_id, job_type=config.job_type_for_hint),
            extra={"job_id": job_id},
        )
    if status == "succeeded":
        return job
    raise remote_state_error(
        f"Remote job has unexpected status after stream disconnect: {status}",
        code="job_stream_reconcile_unexpected",
        request_id=context.request_id,
        extra={"job_id": job_id, "status": status},
    )


@dataclass(frozen=True)
class StreamGapConfig:
    """Optional REST heartbeat polling while the SSE stream is unavailable (publish builds)."""

    on_gap_start: Callable[[], None] | None = None
    on_heartbeat: Callable[[dict[str, Any]], None] | None = None
    on_stream_resumed: Callable[[], None] | None = None
    heartbeat_interval_seconds: float = 4.0


def _stream_gap_interval_seconds(config: StreamGapConfig) -> float:
    raw = os.environ.get("AIMP_PUBLISH_WATCH_HEARTBEAT_INTERVAL_SECONDS", "").strip()
    try:
        env_val = float(raw) if raw else 0.0
    except ValueError:
        env_val = 0.0
    interval = env_val if env_val > 0 else config.heartbeat_interval_seconds
    return max(0.5, interval)


@dataclass(frozen=True)
class ExecutionStreamEvent:
    """One parsed SSE job event."""

    event: str
    payload: dict[str, Any]


@dataclass
class ExecutionStreamCallbacks:
    """Callback hooks invoked while consuming one job stream."""

    on_snapshot: Any | None = None
    on_status: Any | None = None
    on_timeline: Any | None = None
    on_logs: Any | None = None
    on_terminal: Any | None = None


@dataclass
class ExecutionStreamState:
    """Deduplication state persisted across reconnect attempts."""

    timeline_count_seen: int = 0
    log_count_seen: int = 0


@dataclass(frozen=True)
class StreamReconcileConfig:
    """One REST fetch after SSE failure to distinguish transport from job outcome."""

    fetch: Callable[[], dict[str, Any]]
    kind: Literal["publish", "execution"]
    job_type_for_hint: str | None = None


def _publish_terminal_failure_message_from_dict(job: dict[str, Any]) -> str:
    """Mirror publish/core terminal failure wording without importing publish.core."""
    current_step = str(job.get("current_step_message") or "").strip()
    error_message = str(job.get("error_message") or "").strip()
    if current_step and error_message and current_step.lower() != error_message.lower():
        return f"{current_step}: {error_message}"
    if current_step:
        return current_step
    if error_message:
        return error_message
    return "Remote publish build failed"


def _jobs_get_hint(*, job_id: str, job_type: str | None) -> str:
    if job_type in {"build", "fine-tune"}:
        return f"Poll job status with: ai jobs get --type {job_type} --job {job_id}"
    return f"Poll job status with: ai jobs get --job {job_id}"


def _reconcile_stream_state(
    *,
    context: CommandContext,
    job_id: str,
    config: StreamReconcileConfig,
) -> dict[str, Any]:
    """Fetch job state once after SSE failure; raise or return terminal success payload."""
    raw = config.fetch()
    result = _reconcile_raw_to_outcome(
        raw, context=context, job_id=job_id, config=config
    )
    if result is None:
        message = (
            "Live stream disconnected; remote build is still running."
            if config.kind == "publish"
            else "Live stream disconnected; remote job is still running."
        )
        raise remote_state_error(
            message,
            code="job_stream_disconnected_active",
            request_id=context.request_id,
            hint=_jobs_get_hint(
                job_id=job_id,
                job_type="build" if config.kind == "publish" else config.job_type_for_hint,
            ),
            extra={"job_id": job_id},
        )
    return result


def watch_execution_stream(
    *,
    gateway: JobStreamGatewayProtocol,
    job_id: str,
    context: CommandContext,
    callbacks: ExecutionStreamCallbacks | None = None,
    reconcile: StreamReconcileConfig | None = None,
    max_stream_sessions: int | None = None,
    on_reconnect: Callable[[int], None] | None = None,
    gap: StreamGapConfig | None = None,
) -> dict[str, Any]:
    """Watch one job SSE stream until a terminal payload is received.

    Reconnects on transport loss or EOF while the job may still be running; optional
    ``max_stream_sessions`` bounds attempts (useful in tests). When ``None``, the
    stream keeps reconnecting with backoff until a terminal event or reconcile shows
    a terminal outcome.

    When ``gap`` is set with ``reconcile.kind == \"publish\"``, after an EOF while the
    build is still active the CLI polls REST on a heartbeat interval until the
    reconnect delay elapses, then retries SSE.
    """
    callback_state = callbacks or ExecutionStreamCallbacks()
    stream_state = ExecutionStreamState()
    reconnect_generation = 0
    session_index = 0

    def _consume_one_stream() -> dict[str, Any] | None:
        """Process events until terminal or source exhaustion; return job if terminal."""
        with gateway.stream_job(
            job_id,
            timeline_offset=stream_state.timeline_count_seen,
            log_offset=stream_state.log_count_seen,
        ) as lines:
            if reconnect_generation > 0 and gap is not None and gap.on_stream_resumed is not None:
                gap.on_stream_resumed()
            for event in parse_execution_stream_events(lines, context=context):
                if event.event == "snapshot":
                    _handle_snapshot_event(
                        event.payload,
                        stream_state=stream_state,
                        callbacks=callback_state,
                        context=context,
                    )
                    continue

                if event.event == "status":
                    _handle_status_event(
                        event.payload, callbacks=callback_state, context=context
                    )
                    continue

                if event.event == "timeline":
                    _handle_timeline_event(
                        event.payload,
                        stream_state=stream_state,
                        callbacks=callback_state,
                        context=context,
                    )
                    continue

                if event.event == "logs":
                    _handle_logs_event(
                        event.payload,
                        stream_state=stream_state,
                        callbacks=callback_state,
                        context=context,
                    )
                    continue

                if event.event == "terminal":
                    return _handle_terminal_event(
                        event.payload,
                        stream_state=stream_state,
                        callbacks=callback_state,
                        context=context,
                    )
        return None

    while True:
        session_index += 1
        if max_stream_sessions is not None and session_index > max_stream_sessions:
            if reconcile is not None:
                terminal = _reconcile_stream_state(
                    context=context, job_id=job_id, config=reconcile
                )
                if callback_state.on_terminal is not None:
                    callback_state.on_terminal(terminal)
                return terminal
            raise _job_stream_unavailable_error(
                context=context,
                job_id=job_id,
                message="Job stream unavailable after bounded reconnect attempts.",
            )

        use_gap_poll = False
        try:
            terminal_job = _consume_one_stream()
            if terminal_job is not None:
                return terminal_job
        except CliError as error:
            if not _should_retry_stream_error_unlimited(error):
                raise
            use_gap_poll = (
                gap is not None
                and reconcile is not None
                and reconcile.kind == "publish"
            )
        except Exception as error:
            stream_error = _job_stream_unavailable_error(
                context=context,
                job_id=job_id,
                message=f"Job stream failed unexpectedly: {error}",
            )
            if not _should_retry_generic_stream_failure(error):
                raise stream_error from error
            use_gap_poll = (
                gap is not None
                and reconcile is not None
                and reconcile.kind == "publish"
            )
        else:
            # EOF without terminal: optional reconcile; if still active, reconnect.
            if reconcile is not None:
                raw = reconcile.fetch()
                _handle_reconcile_snapshot_event(
                    raw,
                    stream_state=stream_state,
                    callbacks=callback_state,
                    context=context,
                )
                terminal = _reconcile_raw_to_outcome(
                    raw, context=context, job_id=job_id, config=reconcile
                )
                if terminal is not None:
                    if callback_state.on_terminal is not None:
                        callback_state.on_terminal(terminal)
                    return terminal
                use_gap_poll = gap is not None and reconcile.kind == "publish"

        reconnect_generation += 1
        delay = _reconnect_delay_seconds(reconnect_generation)

        if use_gap_poll and gap is not None and reconcile is not None:
            if gap.on_gap_start is not None:
                gap.on_gap_start()
            deadline = time.monotonic() + delay
            interval = _stream_gap_interval_seconds(gap)
            while time.monotonic() < deadline:
                raw = reconcile.fetch()
                _handle_reconcile_snapshot_event(
                    raw,
                    stream_state=stream_state,
                    callbacks=callback_state,
                    context=context,
                )
                result = _reconcile_raw_to_outcome(
                    raw, context=context, job_id=job_id, config=reconcile
                )
                if result is not None:
                    if callback_state.on_terminal is not None:
                        callback_state.on_terminal(result)
                    return result
                if gap.on_heartbeat is not None:
                    gap.on_heartbeat(raw)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(interval, remaining))
        else:
            if on_reconnect is not None:
                on_reconnect(reconnect_generation)
            time.sleep(delay)
        continue


def parse_execution_stream_events(
    lines: Any,
    *,
    context: CommandContext,
) -> Any:
    """Parse SSE lines into structured execution events."""
    current_event: str | None = None
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line if isinstance(raw_line, str) else str(raw_line)
        if line == "":
            parsed = _flush_sse_event(
                current_event=current_event,
                data_lines=data_lines,
                context=context,
            )
            if parsed is not None:
                yield parsed
            current_event = None
            data_lines = []
            continue

        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            current_event = line.partition(":")[2].lstrip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.partition(":")[2].lstrip())
            continue

    parsed = _flush_sse_event(
        current_event=current_event,
        data_lines=data_lines,
        context=context,
    )
    if parsed is not None:
        yield parsed


def _flush_sse_event(
    *,
    current_event: str | None,
    data_lines: list[str],
    context: CommandContext,
) -> ExecutionStreamEvent | None:
    """Flush the currently buffered SSE event when a frame boundary is reached."""
    if not data_lines:
        return None

    payload_text = "\n".join(data_lines).strip()
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError as exc:
        raise _job_stream_unavailable_error(
            context=context,
            job_id="unknown",
            message="Gateway returned an invalid job stream payload.",
        ) from exc

    if not isinstance(payload, dict):
        raise internal_error(
            "Gateway returned an invalid job stream payload.",
            code="gateway_job_stream_payload_invalid",
            request_id=context.request_id,
            extra={"payload_type": type(payload).__name__},
        )

    event_name = (current_event or "message").strip()
    if not event_name:
        raise internal_error(
            "Gateway returned a job stream event without a name.",
            code="gateway_job_stream_event_invalid",
            request_id=context.request_id,
        )
    return ExecutionStreamEvent(event=event_name, payload=payload)


def _handle_reconcile_snapshot_event(
    raw: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply one REST reconcile payload as a snapshot so gap polling streams deltas."""
    job = raw.get("job") if isinstance(raw.get("job"), dict) else raw
    if not isinstance(job, dict):
        raise internal_error(
            "Gateway returned an invalid job detail payload during stream reconcile.",
            code="gateway_job_detail_invalid",
            request_id=context.request_id,
        )
    _handle_snapshot_event(
        {
            "job": job,
            "timeline_count": _list_length(job.get("timeline")),
            "log_count": _optional_list_length(job.get("logs")),
        },
        stream_state=stream_state,
        callbacks=callbacks,
        context=context,
    )


def _handle_snapshot_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply a snapshot payload, including backfilling any unseen deltas."""
    job = _require_job_payload(payload, context=context)
    if callbacks.on_snapshot is not None:
        callbacks.on_snapshot(job)

    timeline_base = payload.get("timeline_offset")
    timeline_base_idx = (
        timeline_base if isinstance(timeline_base, int) and timeline_base >= 0 else 0
    )
    log_base = payload.get("log_offset")
    log_base_idx = log_base if isinstance(log_base, int) and log_base >= 0 else 0

    timeline = job.get("timeline")
    if isinstance(timeline, list):
        effective_timeline_seen = max(
            0, stream_state.timeline_count_seen - timeline_base_idx
        )
        new_timeline = _slice_snapshot_items(
            items=timeline,
            seen_count=effective_timeline_seen,
        )
        if new_timeline and callbacks.on_timeline is not None:
            callbacks.on_timeline(new_timeline, payload)
        full_timeline = _coerce_count(
            payload.get("timeline_count"),
            fallback=timeline_base_idx + len(timeline),
        )
        stream_state.timeline_count_seen = max(
            stream_state.timeline_count_seen,
            full_timeline,
        )

    logs = job.get("logs")
    if isinstance(logs, list):
        effective_log_seen = max(0, stream_state.log_count_seen - log_base_idx)
        new_logs = _slice_snapshot_items(
            items=logs,
            seen_count=effective_log_seen,
        )
        if new_logs and callbacks.on_logs is not None:
            callbacks.on_logs(new_logs, payload)
        raw_lc = payload.get("log_count")
        if isinstance(raw_lc, int) and raw_lc >= 0:
            full_logs = raw_lc
        else:
            full_logs = log_base_idx + len(logs)
        stream_state.log_count_seen = max(stream_state.log_count_seen, full_logs)


def _handle_status_event(
    payload: dict[str, Any],
    *,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Invoke the status callback for one status event."""
    if not isinstance(payload.get("status"), str):
        raise internal_error(
            "Gateway returned an execution status event without a status value.",
            code="gateway_execution_stream_event_invalid",
            request_id=context.request_id,
            extra={"event": "status"},
        )
    if callbacks.on_status is not None:
        callbacks.on_status(payload)


def _handle_timeline_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply one timeline delta event with deduplication."""
    offset = _coerce_offset(payload.get("offset"), context=context, event_name="timeline")
    items = _coerce_items(payload.get("items"), context=context, event_name="timeline")
    new_items = _slice_delta_items(
        items=items,
        offset=offset,
        seen_count=stream_state.timeline_count_seen,
    )
    if new_items and callbacks.on_timeline is not None:
        callbacks.on_timeline(new_items, payload)
    stream_state.timeline_count_seen = max(stream_state.timeline_count_seen, offset + len(items))


def _handle_logs_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> None:
    """Apply one logs delta event with deduplication."""
    offset = _coerce_offset(payload.get("offset"), context=context, event_name="logs")
    items = _coerce_items(payload.get("items"), context=context, event_name="logs")
    new_items = _slice_delta_items(
        items=items,
        offset=offset,
        seen_count=stream_state.log_count_seen,
    )
    if new_items and callbacks.on_logs is not None:
        callbacks.on_logs(new_items, payload)
    stream_state.log_count_seen = max(stream_state.log_count_seen, offset + len(items))


def _handle_terminal_event(
    payload: dict[str, Any],
    *,
    stream_state: ExecutionStreamState,
    callbacks: ExecutionStreamCallbacks,
    context: CommandContext,
) -> dict[str, Any]:
    """Apply one terminal event and return its final job payload."""
    job = _require_job_payload(payload, context=context)
    _handle_snapshot_event(
        payload,
        stream_state=stream_state,
        callbacks=ExecutionStreamCallbacks(
            on_snapshot=None,
            on_status=None,
            on_timeline=callbacks.on_timeline,
            on_logs=callbacks.on_logs,
            on_terminal=None,
        ),
        context=context,
    )
    if callbacks.on_terminal is not None:
        callbacks.on_terminal(job)
    return job


def _should_retry_stream_error_unlimited(error: CliError) -> bool:
    """Return whether a stream failure should trigger another reconnect attempt."""
    if error.http_status in {401, 403, 404}:
        return False
    if error.code == "job_stream_unavailable":
        return True
    return error.category == ErrorCategory.NETWORK


def _should_retry_generic_stream_failure(error: Exception) -> bool:
    """Return whether a non-CliError stream failure should reconnect."""
    _ = error
    return True


def _job_stream_unavailable_error(
    *,
    context: CommandContext,
    job_id: str,
    message: str,
) -> CliError:
    """Build the canonical CLI error for live job stream failures."""
    return network_error(
        message,
        code="job_stream_unavailable",
        request_id=context.request_id,
        hint=("Live job stream unavailable. Verify Gateway SSE connectivity and retry."),
        extra={"job_id": job_id},
    )


def _require_job_payload(
    payload: dict[str, Any], *, context: CommandContext
) -> dict[str, Any]:
    """Extract one job payload from a snapshot or terminal event."""
    job = payload.get("job")
    if isinstance(job, dict):
        return job
    raise internal_error(
        "Gateway returned a job stream event without a job payload.",
        code="gateway_job_stream_event_invalid",
        request_id=context.request_id,
    )


def _coerce_count(value: Any, *, fallback: int) -> int:
    """Return a non-negative count from a stream payload."""
    if isinstance(value, int) and value >= 0:
        return value
    return fallback


def _list_length(value: Any) -> int:
    """Return the length of a list-backed stream field, defaulting to zero."""
    return len(value) if isinstance(value, list) else 0


def _optional_list_length(value: Any) -> int | None:
    """Return a list length or None when the stream field is not list-backed."""
    if isinstance(value, list):
        return len(value)
    return None


def _coerce_offset(
    value: Any,
    *,
    context: CommandContext,
    event_name: str,
) -> int:
    """Return a valid non-negative offset for delta payloads."""
    if isinstance(value, int) and value >= 0:
        return value
    raise internal_error(
        "Gateway returned a job stream event with an invalid offset.",
        code="gateway_job_stream_event_invalid",
        request_id=context.request_id,
        extra={"event": event_name, "offset": value},
    )


def _coerce_items(
    value: Any,
    *,
    context: CommandContext,
    event_name: str,
) -> list[dict[str, Any]]:
    """Return one validated list of item payloads."""
    if not isinstance(value, list):
        raise internal_error(
            "Gateway returned a job stream event with invalid items.",
            code="gateway_job_stream_event_invalid",
            request_id=context.request_id,
            extra={"event": event_name, "items_type": type(value).__name__},
        )
    return [item for item in value if isinstance(item, dict)]


def _slice_snapshot_items(*, items: list[Any], seen_count: int) -> list[dict[str, Any]]:
    """Return unseen items from a full snapshot payload."""
    if seen_count <= 0:
        return [item for item in items if isinstance(item, dict)]
    tail = items[seen_count:]
    return [item for item in tail if isinstance(item, dict)]


def _slice_delta_items(
    *,
    items: list[dict[str, Any]],
    offset: int,
    seen_count: int,
) -> list[dict[str, Any]]:
    """Return only unseen items from one offset-based delta payload."""
    if offset >= seen_count:
        return items
    skip = seen_count - offset
    if skip >= len(items):
        return []
    return items[skip:]
