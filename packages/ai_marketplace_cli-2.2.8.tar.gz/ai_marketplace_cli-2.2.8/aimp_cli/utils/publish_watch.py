"""Shared publish-build watch rendering helpers."""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from rich.console import Console

# User-facing labels for publish-build group stages (API uses snake_case ids).
_PUBLISH_STAGE_LABELS: dict[str, str] = {
    "release_bundle_prepare": "Preparing release bundle",
    "runtime_matrix_build": "Runtime matrix build",
    "registration": "Registration",
    "source_bundle_download": "Downloading source",
    "source_bundle_extract": "Extracting source",
    "artifact_prepare": "Preparing artifacts",
    "dependency_layer_prepare": "Installing dependencies",
    "image_build": "Building image",
    "image_push": "Pushing image",
}


def publish_stage_display_name(stage: str, *, debug: bool) -> str:
    """Map internal stage id to a short client-facing label; raw id when ``debug``."""
    normalized = str(stage or "").strip()
    if not normalized:
        return ""
    if debug:
        return normalized
    if normalized in _PUBLISH_STAGE_LABELS:
        return _PUBLISH_STAGE_LABELS[normalized]
    return normalized.replace("_", " ").strip().title()


def _parse_timestamp(value: str | None) -> datetime | None:
    """Parse one optional ISO timestamp."""
    if not value:
        return None
    normalized = value.strip()
    if not normalized:
        return None
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def seconds_since_timestamp(value: str | None) -> int | None:
    """Return elapsed whole seconds since one timestamp."""
    parsed = _parse_timestamp(value)
    if parsed is None:
        return None
    return max(0, int((datetime.now(UTC) - parsed).total_seconds()))


def effective_last_progress_at(payload: dict[str, Any]) -> str | None:
    """Best-effort last progress timestamp: group field, else max of child job timestamps."""
    direct = str(payload.get("last_progress_at") or "").strip()
    if direct:
        return direct
    children = payload.get("child_jobs")
    if not isinstance(children, list):
        return None
    best: datetime | None = None
    best_raw: str | None = None
    for child in children:
        if not isinstance(child, dict):
            continue
        raw = str(child.get("last_progress_at") or "").strip()
        if not raw:
            continue
        parsed = _parse_timestamp(raw)
        if parsed is None:
            continue
        if best is None or parsed > best:
            best = parsed
            best_raw = raw
    return best_raw


def merge_publish_watch_display_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Copy payload and attach effective ``last_progress_at`` when missing at group level."""
    merged = dict(payload)
    if not str(merged.get("last_progress_at") or "").strip():
        eff = effective_last_progress_at(payload)
        if eff:
            merged["last_progress_at"] = eff
    return merged


def _heartbeat_repeat_seconds() -> float:
    raw = os.environ.get("AIMP_PUBLISH_WATCH_HEARTBEAT_REPEAT_SECONDS", "").strip()
    try:
        v = float(raw) if raw else 0.0
    except ValueError:
        v = 0.0
    return max(10.0, v) if v > 0 else 30.0


def _no_progress_warn_seconds() -> float:
    raw = os.environ.get("AIMP_PUBLISH_WATCH_NO_PROGRESS_WARN_SECONDS", "").strip()
    try:
        v = float(raw) if raw else 0.0
    except ValueError:
        v = 0.0
    return max(30.0, v) if v > 0 else 90.0


def format_watch_elapsed_mm_ss(watch_start_monotonic: float) -> str:
    """Format monotonic elapsed time as MM:SS."""
    elapsed = max(0.0, time.monotonic() - watch_start_monotonic)
    total_seconds = int(elapsed)
    minutes, secs = divmod(total_seconds, 60)
    return f"{minutes:02d}:{secs:02d}"


def format_publish_heartbeat_body(
    payload: dict[str, Any],
    *,
    watch_start_monotonic: float,
    debug: bool,
) -> str:
    """One line body for poll / heartbeat output (after the ``Heartbeat:`` prefix)."""
    merged = merge_publish_watch_display_payload(payload)
    status_value = str(merged.get("status") or "unknown").strip() or "unknown"
    stage_raw = str(merged.get("stage") or "").strip()
    stage = publish_stage_display_name(stage_raw, debug=debug) if stage_raw else ""
    step = str(merged.get("current_step_message") or "").strip()
    last_progress_seconds = seconds_since_timestamp(
        str(merged.get("last_progress_at") or "").strip() or None
    )
    elapsed = format_watch_elapsed_mm_ss(watch_start_monotonic)
    parts: list[str] = [status_value]
    if stage:
        parts.append(stage)
    if step:
        parts.append(step)
    if last_progress_seconds is not None:
        parts.append(f"last progress {last_progress_seconds}s ago")
    parts.append(f"elapsed {elapsed}")
    return " · ".join(parts)


def build_publish_watch_status_message(
    payload: dict[str, Any], *, job_id: str, debug: bool
) -> str:
    """Build the compact live publish-build status line."""
    payload = merge_publish_watch_display_payload(payload)
    model_slug = str(payload.get("model_slug") or payload.get("slug") or "").strip()
    details = payload.get("details")
    details_payload = details if isinstance(details, dict) else {}
    version = str(payload.get("version") or details_payload.get("version") or "").strip()
    status_value = str(payload.get("status") or "unknown").strip() or "unknown"
    stage_raw = str(payload.get("stage") or "").strip()
    stage = publish_stage_display_name(stage_raw, debug=debug) if stage_raw else ""
    last_progress_seconds = seconds_since_timestamp(
        str(payload.get("last_progress_at") or "").strip() or None
    )

    parts = [status_value]
    if stage:
        parts.append(stage)
    if last_progress_seconds is not None:
        parts.append(f"last progress {last_progress_seconds}s ago")
    if model_slug:
        parts.append(model_slug if not version else f"{model_slug}:{version}")
    if debug:
        parts.append(f"job {job_id[:8]}")
    return " · ".join(parts)


def render_publish_watch_logs(console: Console, items: list[dict[str, Any]]) -> None:
    """Render structured execution log items for publish-build watch flows."""
    for item in items:
        level = str(item.get("level") or "info").strip().lower()
        message = str(item.get("message") or "")
        if level == "error":
            console.print(f"[red]✗ {message}[/red]", soft_wrap=True)
        elif level == "warning":
            console.print(f"[yellow]⚠ {message}[/yellow]", soft_wrap=True)
        else:
            console.print(f"[dim]  {message}[/dim]", soft_wrap=True)


@dataclass(slots=True)
class PublishWatchRenderer:
    """Render one publish-build execution stream without duplicating steps."""

    console: Console
    job_id: str
    status_prefix: str = "Remote build"
    debug: bool = False
    _last_stage: str | None = None
    _last_step: str | None = None
    _last_event_key: str | None = None
    _latest_execution: dict[str, Any] = field(default_factory=dict)
    _watch_start_monotonic: float = field(default_factory=time.monotonic)
    _last_heartbeat_key: str | None = None
    _last_heartbeat_emit_at: float = field(default_factory=time.monotonic)
    _last_progress_snapshot: str | None = None
    _no_progress_warned_for_stale_snapshot: bool = False

    def status_message(self, payload: dict[str, Any]) -> str:
        """Return the compact status line for one payload."""
        return f"{self.status_prefix}: " + build_publish_watch_status_message(
            payload,
            job_id=self.job_id,
            debug=self.debug,
        )

    def apply_snapshot(self, execution: dict[str, Any], status_handle: Any) -> None:
        """Render one snapshot payload."""
        self._latest_execution.clear()
        self._latest_execution.update(execution)
        merged = merge_publish_watch_display_payload(execution)
        self._render_state(merged)
        status_handle.update(self.status_message(merged))

    def apply_status(self, payload: dict[str, Any], status_handle: Any) -> None:
        """Render one incremental status payload."""
        merged = {**self._latest_execution, **payload}
        self._latest_execution.clear()
        self._latest_execution.update(merged)
        display = merge_publish_watch_display_payload(merged)
        self._render_state(display)
        status_handle.update(self.status_message(display))

    def apply_terminal(self, execution: dict[str, Any], status_handle: Any) -> None:
        """Render one terminal payload."""
        self._latest_execution.clear()
        self._latest_execution.update(execution)
        disp = merge_publish_watch_display_payload(execution)
        self._render_state(disp)
        status_handle.update(self.status_message(disp))

    def emit_gap_heartbeat(self, raw: dict[str, Any], status_handle: Any) -> None:
        """Render REST poll snapshot during SSE gap: stage/step, spinner, deduped heartbeat line."""
        merged = merge_publish_watch_display_payload(raw)
        self._latest_execution.clear()
        self._latest_execution.update(merged)
        self._render_state(merged)
        status_handle.update(self.status_message(merged))

        eff = str(merged.get("last_progress_at") or "").strip()
        if eff != self._last_progress_snapshot:
            self._last_progress_snapshot = eff
            self._no_progress_warned_for_stale_snapshot = False

        last_sec = seconds_since_timestamp(
            str(merged.get("last_progress_at") or "").strip() or None
        )
        warn_after = int(_no_progress_warn_seconds())
        if (
            last_sec is not None
            and last_sec >= warn_after
            and not self._no_progress_warned_for_stale_snapshot
        ):
            self._no_progress_warned_for_stale_snapshot = True
            self.console.print(
                f"[yellow]No new progress for {warn_after}s. "
                "Build still active remotely.[/yellow]",
                soft_wrap=True,
            )

        key = "|".join(
            (
                str(merged.get("status") or ""),
                str(merged.get("stage") or ""),
                str(merged.get("current_step_message") or ""),
                str(last_sec if last_sec is not None else ""),
            )
        )
        now = time.monotonic()
        repeat = _heartbeat_repeat_seconds()
        if key == self._last_heartbeat_key and (now - self._last_heartbeat_emit_at) < repeat:
            return
        self._last_heartbeat_key = key
        self._last_heartbeat_emit_at = now
        if not self.debug:
            return
        body = format_publish_heartbeat_body(
            merged,
            watch_start_monotonic=self._watch_start_monotonic,
            debug=self.debug,
        )
        self.console.print(f"[dim]Heartbeat:[/dim] {body}", soft_wrap=True)

    def print_gap_started(self) -> None:
        """Print once when SSE ends while the remote build is still active."""
        self.console.print(
            "[yellow]Connection interrupted; still checking build status…[/yellow]",
            soft_wrap=True,
        )

    def print_stream_resumed(self) -> None:
        """Print when SSE reconnects after a gap."""
        self.console.print(
            "[green]Live updates restored.[/green]",
            soft_wrap=True,
        )

    def render_timeline(self, items: list[dict[str, Any]]) -> None:
        """Render distinct timeline detail items."""
        for item in items:
            if not isinstance(item, dict):
                continue
            event = str(item.get("event") or "").strip()
            detail = str(item.get("detail") or "").strip()
            phase = str(item.get("phase") or "").strip()
            if not detail:
                continue
            event_key = "|".join((event, phase, detail))
            if event_key == self._last_event_key:
                continue
            self._last_event_key = event_key
            self.console.print(f"[cyan]Event:[/cyan] {event}: {detail}", soft_wrap=True)

    def render_logs(self, items: list[dict[str, Any]]) -> None:
        """Render raw structured log entries."""
        render_publish_watch_logs(self.console, items)

    def _render_state(self, payload: dict[str, Any]) -> None:
        """Render Stage/Step transitions once."""
        stage = str(payload.get("stage") or "").strip()
        if stage and stage != self._last_stage:
            self._last_stage = stage
            label = publish_stage_display_name(stage, debug=self.debug)
            self.console.print(f"[cyan]Stage:[/cyan] {label}", soft_wrap=True)

        step = str(payload.get("current_step_message") or "").strip()
        if step and step != self._last_step:
            self._last_step = step
            self.console.print(f"[bold]Step:[/bold] {step}", soft_wrap=True)
