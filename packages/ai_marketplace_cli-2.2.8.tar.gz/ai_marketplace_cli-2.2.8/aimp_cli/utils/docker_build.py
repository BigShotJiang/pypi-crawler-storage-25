"""Docker build-context discovery helpers."""

from __future__ import annotations

import re
import shlex
from pathlib import Path

from aimp_cli.core.errors import usage_error

MODEL_RUNTIME_DOCKERFILE = "runtime/Dockerfile"


def extract_docker_context_sources(content: str) -> list[str]:
    """Extract relative COPY/ADD sources from a Dockerfile."""
    sources: list[str] = []
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = re.match(r"^(COPY|ADD)\s+(.+)$", line, flags=re.IGNORECASE)
        if match is None:
            continue
        operands = match.group(2).strip()
        if operands.startswith("--"):
            continue
        parts = [part for part in re.split(r"\s+", operands) if part]
        if len(parts) < 2:
            continue
        for source in parts[:-1]:
            cleaned = source.strip()
            if cleaned and cleaned not in {".", "./"}:
                sources.append(cleaned)
    return sources


def _merge_dockerfile_logical_lines(content: str) -> list[str]:
    """Merge Dockerfile lines continued with a trailing backslash into single logical lines."""
    merged: list[str] = []
    for raw in content.splitlines():
        line = raw.rstrip()
        if merged and merged[-1].endswith("\\"):
            merged[-1] = merged[-1][:-1].rstrip() + " " + line.strip()
        else:
            merged.append(line)
    return merged


def _run_installs_python_dependencies(run_instruction_body: str) -> bool:
    """Return True if a RUN body installs Python packages (pip/uv)."""
    lower = run_instruction_body.lower()
    if "pip install" in lower or "pip3 install" in lower:
        return True
    if "uv pip install" in lower:
        return True
    if "python -m pip" in lower and "install" in lower:
        return True
    if "python3 -m pip" in lower and "install" in lower:
        return True
    return False


def _first_python_dependency_install_line_index(logical_lines: list[str]) -> int | None:
    """Index of the first RUN instruction that runs pip/uv install."""
    for i, line in enumerate(logical_lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if not stripped.upper().startswith("RUN"):
            continue
        body = stripped[3:].strip()
        if _run_installs_python_dependencies(body):
            return i
    return None


def _parse_copy_add_sources_from_instruction(line: str) -> list[str] | None:
    """Return host build-context source paths for COPY/ADD, or None if not applicable."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None
    match = re.match(r"^(COPY|ADD)\s+(.+)$", stripped, flags=re.IGNORECASE)
    if match is None:
        return None
    if re.search(r"\s--from=", stripped, flags=re.IGNORECASE):
        return None
    rest = match.group(2).strip()
    try:
        parts = shlex.split(rest, posix=True)
    except ValueError:
        return None
    i = 0
    while i < len(parts) and parts[i].startswith("--"):
        i += 1
    if i >= len(parts):
        return None
    sources = parts[i:-1]
    return sources


def _normalize_copy_source(src: str) -> str:
    cleaned = src.strip().strip("'\"")
    if cleaned.startswith("./"):
        return cleaned[2:]
    return cleaned


def _is_disallowed_full_runtime_tree_copy(src: str) -> bool:
    """True if COPY would pull the whole runtime tree or a dir under runtime (not a single file)."""
    s = _normalize_copy_source(src)
    if s in ("runtime", "runtime/"):
        return True
    if not s.startswith("runtime/"):
        return False
    if s.endswith("/"):
        return True
    return False


def _is_disallowed_aimp_copy_before_wheelhouse(src: str) -> bool:
    """True if COPY would pull .aimp metadata beyond runtime-wheelhouse."""
    s = _normalize_copy_source(src)
    if s in (".aimp", ".aimp/"):
        return True
    if s.startswith(".aimp/runtime-wheelhouse"):
        return False
    if s.startswith(".aimp/"):
        return True
    return False


def validate_runtime_dockerfile_dependency_layer_order(dockerfile_content: str) -> None:
    """Validate dependency-first COPY order for ``runtime/Dockerfile`` (publish contract).

    Before the first ``python -m pip`` / ``pip install`` / ``uv pip install`` step, only
    dependency inputs and ``.aimp/runtime-wheelhouse/`` may be copied from the build context.
    Full ``COPY runtime/`` or ``COPY .aimp/`` (except wheelhouse) break layer caching.
    """
    logical = _merge_dockerfile_logical_lines(dockerfile_content)
    pip_idx = _first_python_dependency_install_line_index(logical)
    if pip_idx is None:
        raise usage_error(
            "runtime/Dockerfile must include at least one RUN step that installs Python dependencies "
            "(for example `pip install` or `uv pip install`) so remote builds can cache dependency layers.",
            code="publish_runtime_dockerfile_missing_pip_install",
        )

    for line in logical[:pip_idx]:
        sources = _parse_copy_add_sources_from_instruction(line)
        if not sources:
            continue
        for src in sources:
            if "://" in src:
                continue
            if _is_disallowed_full_runtime_tree_copy(src):
                raise usage_error(
                    "runtime/Dockerfile copies `runtime/` as a directory (or a subdirectory as a "
                    "directory) before the first `pip install` step. This invalidates Docker layer "
                    "cache when unrelated files under `runtime/` change. Copy only `runtime/pyproject.toml` "
                    "and optional lock files (for example `runtime/uv.lock`) before `pip install`, then `COPY` "
                    "the rest of the project later.",
                    code="publish_runtime_dockerfile_dependency_layer_copy_runtime_dir",
                    extra={"source": src},
                )
            if _is_disallowed_aimp_copy_before_wheelhouse(src):
                raise usage_error(
                    "runtime/Dockerfile copies `.aimp/` under paths other than `.aimp/runtime-wheelhouse/` "
                    "before the first `pip install` step. This invalidates Docker layer cache when AIMP "
                    "metadata changes. Copy only `.aimp/runtime-wheelhouse/` before `pip install` (not full "
                    "`COPY .aimp/`).",
                    code="publish_runtime_dockerfile_dependency_layer_copy_aimp_dir",
                    extra={"source": src},
                )


def _docker_copy_source_is_within_build_context(source: str, build_context: Path) -> bool:
    """Return whether a COPY/ADD source path stays inside the Docker build context."""
    cleaned = source.strip().strip("'\"")
    if not cleaned or cleaned in {".", "./"}:
        return True
    if "://" in cleaned:
        return True
    if cleaned.startswith("/"):
        return False
    parts = Path(cleaned).parts
    if ".." in parts:
        return False
    base = build_context.resolve()
    resolved = (build_context / cleaned).resolve()
    try:
        resolved.relative_to(base)
    except ValueError:
        return False
    return True


def resolve_docker_build_spec(project_dir: Path) -> tuple[Path, str]:
    """Resolve Docker build context and Dockerfile path for publish.

    Remote publish always builds from ``runtime/Dockerfile`` with ``runtime/pyproject.toml``.
    There is no alternate platform Dockerfile on the publish path.
    """
    root = project_dir.resolve()
    dockerfile = root / "runtime" / "Dockerfile"
    pyproject = root / "runtime" / "pyproject.toml"
    if not dockerfile.is_file():
        raise usage_error(
            "Remote publish requires runtime/Dockerfile and runtime/pyproject.toml at the project root. "
            "Run `ai init` for a scaffold that includes them, or add both files under runtime/.",
            code="publish_runtime_dockerfile_missing",
            extra={"project_dir": str(root)},
        )
    if not pyproject.is_file():
        raise usage_error(
            "runtime/Dockerfile exists but runtime/pyproject.toml is missing. "
            "Add runtime/pyproject.toml next to runtime/Dockerfile.",
            code="publish_runtime_pyproject_missing",
            extra={"project_dir": str(root)},
        )
    return root, MODEL_RUNTIME_DOCKERFILE


def validate_publish_runtime_layout(
    *,
    project_dir: Path,
    dockerfile_relative: str,
    build_context: Path,
) -> None:
    """Validate ``runtime/Dockerfile`` before ``ai push`` packages a source bundle."""
    project_root = project_dir.resolve()
    context_root = build_context.resolve()
    if context_root != project_root:
        raise usage_error(
            "Publish build context must be the project directory root.",
            code="publish_build_context_invalid",
            extra={"project_dir": str(project_root), "build_context": str(context_root)},
        )

    if dockerfile_relative != MODEL_RUNTIME_DOCKERFILE:
        raise usage_error(
            f"Unsupported publish Dockerfile path: {dockerfile_relative!r}",
            code="publish_dockerfile_path_unsupported",
        )

    runtime_dir = project_root / "runtime"
    dockerfile_path = runtime_dir / "Dockerfile"
    if not dockerfile_path.is_file():
        raise usage_error(
            "runtime/Dockerfile is missing.",
            code="publish_runtime_dockerfile_missing",
            extra={"project_dir": str(project_root)},
        )
    if not (runtime_dir / "pyproject.toml").is_file():
        raise usage_error(
            "runtime/pyproject.toml is missing.",
            code="publish_runtime_pyproject_missing",
            extra={"project_dir": str(project_root)},
        )

    content = dockerfile_path.read_text(encoding="utf-8")
    for source in extract_docker_context_sources(content):
        if not _docker_copy_source_is_within_build_context(source, context_root):
            raise usage_error(
                f"runtime/Dockerfile COPY/ADD source {source!r} must refer to paths "
                "inside the project directory (the Docker build context). "
                "Absolute paths, parent segments (..), and copies from outside the "
                "project root are not allowed.",
                code="publish_runtime_dockerfile_copy_outside_context",
                extra={"project_dir": str(project_root), "source": source},
            )
    validate_runtime_dockerfile_dependency_layer_order(content)
    validate_runtime_dockerfile_no_baked_model_assets(content)


def validate_runtime_dockerfile_no_baked_model_assets(dockerfile_content: str) -> None:
    """Reject Dockerfiles that download or copy production model assets into the image."""
    logical = _merge_dockerfile_logical_lines(dockerfile_content)
    for line in logical:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        upper_line = stripped.upper()
        lowered_full = stripped.lower()
        if upper_line.startswith("ENV ") and "/opt/models" in lowered_full:
            raise usage_error(
                "runtime/Dockerfile must not materialize production model assets. Use artifacts/ instead.",
                code="publish_runtime_dockerfile_opt_models",
            )
        if upper_line.startswith(("COPY ", "ADD ")):
            sources = _parse_copy_add_sources_from_instruction(stripped)
            if sources:
                for src in sources:
                    if "://" in src:
                        continue
                    norm = _normalize_copy_source(src)
                    if norm == "artifacts" or norm.startswith("artifacts/"):
                        raise usage_error(
                            "Production publish must not materialize model assets in runtime/Dockerfile. "
                            "Put execution assets under artifacts/.",
                            code="publish_runtime_dockerfile_copies_artifacts",
                            extra={"source": src},
                        )
            lowered = stripped.lower()
            if "/opt/models" in lowered:
                raise usage_error(
                    "runtime/Dockerfile must not materialize production model assets. Use artifacts/ instead.",
                    code="publish_runtime_dockerfile_opt_models",
                )
            continue

        if upper_line.startswith("RUN "):
            body = stripped[3:].strip()
            lowered = body.lower()
            if "/opt/models" in lowered:
                raise usage_error(
                    "runtime/Dockerfile must not materialize production model assets. Use artifacts/ instead.",
                    code="publish_runtime_dockerfile_opt_models",
                )
            if "huggingface-cli" in lowered:
                raise usage_error(
                    "Production publish must not materialize model assets in runtime/Dockerfile. "
                    "Put execution assets under artifacts/.",
                    code="publish_runtime_dockerfile_hf_cli",
                )
            if "hf download" in lowered or "hf_hub_download" in lowered or "snapshot_download" in lowered:
                raise usage_error(
                    "Production publish must not materialize model assets in runtime/Dockerfile. "
                    "Put execution assets under artifacts/.",
                    code="publish_runtime_dockerfile_hf_download",
                )
            if "huggingface.co" in lowered and (
                "curl" in lowered or "wget" in lowered or "aria2c" in lowered
            ):
                raise usage_error(
                    "Production publish must not materialize model assets in runtime/Dockerfile. "
                    "Put execution assets under artifacts/.",
                    code="publish_runtime_dockerfile_hf_fetch",
                )
            if "from_pretrained(" in body or ".from_pretrained(" in body:
                raise usage_error(
                    "Production publish must not materialize model assets in runtime/Dockerfile. "
                    "Put execution assets under artifacts/.",
                    code="publish_runtime_dockerfile_from_pretrained",
                )
