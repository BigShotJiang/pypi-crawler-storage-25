"""Docker and registry helpers for the Python CLI."""

from __future__ import annotations

import base64
import json
import os
import shutil
import socket
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urljoin, urlparse

import httpx

from aimp_cli.core.config import CommandContext
from aimp_cli.core.errors import environment_error, usage_error
from aimp_cli.domain.models import ImageManifest, ImageManifestLayer

if TYPE_CHECKING:
    from aimp_cli.domain.protocols import DockerBackendProtocol

REGISTRY_PROBE_TIMEOUT_MS = 5.0


@dataclass(slots=True)
class RegistryAuthStatus:
    """Registry auth status."""

    state: str
    message: str


@dataclass(slots=True)
class DockerAccessStatus:
    """Docker daemon access status."""

    ok: bool
    code: str | None = None
    message: str | None = None
    hint: str | None = None
    detail: str | None = None


class DockerClient:
    """Wrapper for docker commands used by the CLI."""

    def __init__(self, context: CommandContext) -> None:
        self.context = context

    def is_docker_available(self) -> bool:
        """Return whether ``docker`` is installed."""
        return shutil.which("docker") is not None

    def inspect_daemon_access(self) -> DockerAccessStatus:
        """Return structured Docker daemon access diagnostics."""
        if not self.is_docker_available():
            return DockerAccessStatus(
                ok=False,
                code="docker_not_found",
                message="Docker not found. Please install Docker.",
                hint="Install Docker, confirm `docker info` works, then retry `ai push`.",
            )

        try:
            subprocess.run(
                ["docker", "info"],
                check=True,
                capture_output=True,
                text=True,
            )
        except OSError as error:
            return DockerAccessStatus(
                ok=False,
                code="docker_not_running",
                message="Docker daemon is not running or not reachable.",
                hint=(
                    "Start Docker, confirm `docker info` succeeds, then run `make dev-up` "
                    "and retry `ai push`."
                ),
                detail=str(error),
            )
        except subprocess.CalledProcessError as error:
            detail = self._extract_docker_error_detail(error)
            normalized = detail.lower()
            if "permission denied" in normalized and "docker" in normalized:
                return DockerAccessStatus(
                    ok=False,
                    code="docker_permission_denied",
                    message="Docker is installed, but this shell cannot access the Docker daemon.",
                    hint=(
                        "Run `docker info` to confirm access. If Docker is already running, "
                        "refresh your shell/session permissions, then run `make dev-up` and "
                        "retry `ai push`."
                    ),
                    detail=detail,
                )

            return DockerAccessStatus(
                ok=False,
                code="docker_not_running",
                message="Docker daemon is not running or not reachable.",
                hint=(
                    "Start Docker, confirm `docker info` succeeds, then run `make dev-up` "
                    "and retry `ai push`."
                ),
                detail=detail,
            )

        return DockerAccessStatus(ok=True)

    def is_docker_running(self) -> bool:
        """Return whether the Docker daemon is reachable."""
        return self.inspect_daemon_access().ok

    def _extract_docker_error_detail(self, error: subprocess.CalledProcessError) -> str:
        """Extract the most useful error output from a failed Docker command."""
        output = (error.stderr or error.stdout or "").strip()
        if output:
            return output
        return f"Docker command failed with exit {error.returncode}."

    def _run(
        self,
        args: list[str],
        *,
        capture_output: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["docker", *args],
            check=True,
            capture_output=capture_output,
            text=True,
        )

    def _stream(self, args: list[str], *, on_line: Any | None = None) -> None:
        process = subprocess.Popen(
            ["docker", *args],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if process.stdout is None:
            raise RuntimeError("Docker output stream was not available")
        lines: list[str] = []
        for raw_line in process.stdout:
            line = raw_line.rstrip()
            if not line:
                continue
            lines.append(line)
            if on_line is not None:
                on_line(line)
        return_code = process.wait()
        if return_code != 0:
            tail = "\n".join(lines[-20:])
            raise RuntimeError(f"Docker {' '.join(args[:1])} failed (exit {return_code}).\n{tail}")

    def build_image(
        self,
        *,
        context_dir: Path,
        tag: str,
        dockerfile: str | None,
        on_line: Any,
    ) -> None:
        """Build an image with streamed output."""
        args = ["build", str(context_dir), "-t", tag]
        if dockerfile:
            args.extend(["-f", dockerfile])
        self._stream(args, on_line=on_line)

    def verify_runtime_sdk(self, image_tag: str) -> None:
        """Ensure the runtime image exposes the canonical model runner."""
        command = [
            "run",
            "--rm",
            "--entrypoint",
            "python",
            image_tag,
            "-m",
            "aimp_sdk.model_runner",
            "--help",
        ]
        self._run(command)

    def tag_image(self, source: str, target: str) -> None:
        """Tag an image."""
        self._run(["tag", source, target], capture_output=False)

    def push_image(self, image_ref: str, on_line: Any) -> None:
        """Push an image to the registry."""
        self._stream(["push", image_ref], on_line=on_line)

    def save_image(self, image_tag: str, output_path: Path) -> None:
        """Save image tarball to disk."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        self._run(["save", image_tag, "-o", str(output_path)], capture_output=False)

    def get_image_manifest(self, image_ref: str) -> ImageManifest:
        """Read concrete registry manifest metadata after push."""
        descriptor = self._inspect_manifest_descriptor(image_ref)
        manifest_ref = image_ref
        manifest_digest = str(descriptor.get("digest") or "").strip()

        manifests = descriptor.get("manifests")
        if isinstance(manifests, list):
            manifest_digest = self._select_publish_manifest_digest(
                image_ref=image_ref,
                manifests=manifests,
            )
            manifest_ref = self._build_manifest_digest_ref(image_ref, manifest_digest)

        raw_manifest = self._inspect_manifest_raw(manifest_ref)
        layers = self._build_manifest_layers(raw_manifest)
        config_size = int(raw_manifest.get("config", {}).get("size") or 0)
        total_size = config_size + sum(layer.size for layer in layers)

        if not manifest_digest:
            raise environment_error(
                f"Registry manifest for '{image_ref}' did not include a manifest digest.",
                code="registry_manifest_inspection_failed",
                hint="Run `make verify-registry` and retry `ai push`.",
                extra={
                    "image_ref": image_ref,
                    "docker_subcommand": (
                        "docker buildx imagetools inspect --format '{{json .Manifest}}'"
                    ),
                },
            )

        return ImageManifest(
            digest=manifest_digest,
            media_type=raw_manifest.get("mediaType"),
            total_size=total_size,
            raw_manifest=raw_manifest,
            layers=layers,
        )

    def _inspect_manifest_descriptor(self, image_ref: str) -> dict[str, Any]:
        """Load the machine-readable manifest descriptor for an image reference."""
        return self._run_manifest_json(
            [
                "buildx",
                "imagetools",
                "inspect",
                "--format",
                "{{json .Manifest}}",
                image_ref,
            ],
            image_ref=image_ref,
        )

    def _inspect_manifest_raw(self, image_ref: str) -> dict[str, Any]:
        """Load the raw OCI manifest JSON for an image reference."""
        return self._run_manifest_json(
            ["buildx", "imagetools", "inspect", "--raw", image_ref],
            image_ref=image_ref,
        )

    def _run_manifest_json(self, args: list[str], *, image_ref: str) -> dict[str, Any]:
        """Run a Docker manifest inspection command and parse its JSON output."""
        command = f"docker {' '.join(args)}"
        try:
            payload = self._run(args).stdout
        except subprocess.CalledProcessError as error:
            detail = self._extract_docker_error_detail(error)
            raise environment_error(
                f"Failed to inspect pushed image manifest for '{image_ref}'.",
                code="registry_manifest_inspection_failed",
                hint="Run `make verify-registry` and retry `ai push`.",
                extra={
                    "image_ref": image_ref,
                    "docker_subcommand": command,
                    "docker_diagnostic": detail,
                },
            ) from error

        try:
            decoded = json.loads(payload)
        except ValueError as error:
            raise environment_error(
                f"Failed to parse registry manifest data for '{image_ref}'.",
                code="registry_manifest_inspection_failed",
                hint="Run `make verify-registry` and retry `ai push`.",
                extra={
                    "image_ref": image_ref,
                    "docker_subcommand": command,
                    "docker_output": payload.strip(),
                },
            ) from error

        if not isinstance(decoded, dict):
            raise environment_error(
                f"Registry manifest response for '{image_ref}' was not a JSON object.",
                code="registry_manifest_inspection_failed",
                hint="Run `make verify-registry` and retry `ai push`.",
                extra={
                    "image_ref": image_ref,
                    "docker_subcommand": command,
                    "docker_output": payload.strip(),
                },
            )

        return cast(dict[str, Any], decoded)

    def _select_publish_manifest_digest(
        self,
        *,
        image_ref: str,
        manifests: list[Any],
    ) -> str:
        """Select the single publishable platform manifest digest from an OCI index."""
        candidates: list[str] = []
        candidate_summaries: list[str] = []

        for manifest in manifests:
            if not isinstance(manifest, dict):
                continue

            digest = str(manifest.get("digest") or "").strip()
            platform = manifest.get("platform")
            platform_data = platform if isinstance(platform, dict) else {}
            os_name = str(platform_data.get("os") or "").strip()
            architecture = str(platform_data.get("architecture") or "").strip()
            annotations = manifest.get("annotations")
            annotation_data = annotations if isinstance(annotations, dict) else {}
            reference_type = str(annotation_data.get("vnd.docker.reference.type") or "").strip()
            candidate_summaries.append(
                f"{digest or '<missing>'}:{os_name or '<missing>'}/{architecture or '<missing>'}"
            )

            if not digest:
                continue
            if reference_type == "attestation-manifest":
                continue
            if not os_name or not architecture:
                continue
            if os_name == "unknown" or architecture == "unknown":
                continue
            candidates.append(digest)

        if len(candidates) == 1:
            return candidates[0]

        if not candidates:
            raise usage_error(
                f"Image '{image_ref}' does not contain a publishable platform manifest.",
                code="registry_manifest_unresolvable",
                hint="Publish a single-platform image and retry `ai push`.",
                extra={
                    "image_ref": image_ref,
                    "manifest_candidates": candidate_summaries,
                },
            )

        raise usage_error(
            f"Image '{image_ref}' contains multiple platform manifests.",
            code="registry_manifest_ambiguous",
            hint="Publish a single-platform image and retry `ai push`.",
            extra={
                "image_ref": image_ref,
                "manifest_candidates": candidate_summaries,
            },
        )

    def _build_manifest_layers(self, raw_manifest: dict[str, Any]) -> list[ImageManifestLayer]:
        """Build validated manifest layers from raw OCI manifest JSON."""
        layers_payload = raw_manifest.get("layers")
        if not isinstance(layers_payload, list):
            raise environment_error(
                "Registry manifest payload did not include a valid layers array.",
                code="registry_manifest_inspection_failed",
                hint="Run `make verify-registry` and retry `ai push`.",
                extra={"raw_manifest": raw_manifest},
            )

        layers = [
            ImageManifestLayer(
                digest=str(layer.get("digest")),
                size=int(layer.get("size", 0)),
                media_type=layer.get("mediaType"),
            )
            for layer in layers_payload
            if isinstance(layer, dict)
        ]
        if not layers:
            raise environment_error(
                "Registry manifest payload did not include any valid image layers.",
                code="registry_manifest_inspection_failed",
                hint="Run `make verify-registry` and retry `ai push`.",
                extra={"raw_manifest": raw_manifest},
            )
        return layers

    def _build_manifest_digest_ref(self, image_ref: str, digest: str) -> str:
        """Convert an image tag or digest reference into a concrete digest reference."""
        if "@" in image_ref:
            repository = image_ref.split("@", 1)[0]
        else:
            last_segment = image_ref.rsplit("/", 1)[-1]
            repository = image_ref.rsplit(":", 1)[0] if ":" in last_segment else image_ref
        return f"{repository}@{digest}"

    def _load_docker_auth_config(self) -> dict[str, Any] | None:
        home = Path(os.environ.get("HOME", str(Path.home())))
        config_path = home / ".docker" / "config.json"
        if not config_path.exists():
            return None
        return cast(dict[str, Any], json.loads(config_path.read_text(encoding="utf-8")))

    def get_registry_auth_status(self, registry_host: str) -> RegistryAuthStatus:
        """Return whether Docker has auth configured for a registry host."""
        config = self._load_docker_auth_config()
        if not config:
            return RegistryAuthStatus(
                state="missing",
                message="Docker registry credentials not configured",
            )
        auths = config.get("auths") or {}
        normalized = (
            registry_host.lower().replace("https://", "").replace("http://", "").rstrip("/")
        )
        for key, value in auths.items():
            if not isinstance(value, dict):
                continue
            key_normalized = key.lower().replace("https://", "").replace("http://", "").rstrip("/")
            if key_normalized == normalized and value.get("auth"):
                return RegistryAuthStatus(
                    state="configured",
                    message="Docker registry credentials configured",
                )
        return RegistryAuthStatus(
            state="missing",
            message="Docker registry credentials not configured",
        )

    def get_registry_basic_auth_header(self, registry_host: str) -> str | None:
        """Build the basic auth header from Docker config."""
        config = self._load_docker_auth_config()
        if not config:
            return None
        auths = config.get("auths") or {}
        normalized = (
            registry_host.lower().replace("https://", "").replace("http://", "").rstrip("/")
        )
        for key, value in auths.items():
            if not isinstance(value, dict):
                continue
            key_normalized = key.lower().replace("https://", "").replace("http://", "").rstrip("/")
            if key_normalized == normalized and isinstance(value.get("auth"), str):
                encoded = value["auth"]
                try:
                    base64.b64decode(encoded)
                except Exception:
                    return None
                return f"Basic {encoded}"
        return None


def normalize_registry_host(value: str) -> str:
    """Normalize registry host/namespace prefix."""
    trimmed = value.strip()
    if not trimmed:
        raise RuntimeError("Registry URL is empty")
    return trimmed.removeprefix("https://").removeprefix("http://").rstrip("/")


def extract_registry_hostname(registry_host: str) -> str:
    """Extract DNS hostname from a registry host string."""
    first_segment = registry_host.split("/")[0]
    if not first_segment:
        raise RuntimeError("Registry host is empty after normalization")
    if first_segment.startswith("[") and "]" in first_segment:
        return first_segment[1 : first_segment.index("]")]
    return first_segment.split(":")[0]


def _validate_local_registry_url(registry_url: str) -> None:
    parsed = urlparse(registry_url)
    if parsed.scheme == "http" and parsed.hostname == "localhost":
        raise RuntimeError(
            f"Local registry URL '{registry_url}' uses localhost over HTTP. "
            "Use http://127.0.0.1:5050 for local development."
        )


def _probe_registry(registry_url: str, auth_header: str | None = None) -> int:
    probe_url = urljoin(registry_url if registry_url.endswith("/") else f"{registry_url}/", "v2/")
    headers = {"Authorization": auth_header} if auth_header else None
    with httpx.Client(timeout=REGISTRY_PROBE_TIMEOUT_MS, headers=headers) as client:
        response = client.get(probe_url)
        return response.status_code


def run_registry_preflight(
    registry_url: str,
    *,
    docker: DockerBackendProtocol,
) -> None:
    """Validate registry DNS, endpoint reachability, and credentials."""
    _validate_local_registry_url(registry_url)
    registry_host = normalize_registry_host(registry_url)
    hostname = extract_registry_hostname(registry_host)
    if hostname not in {"localhost", "127.0.0.1", "::1"}:
        try:
            socket.getaddrinfo(hostname, None)
        except socket.gaierror as error:
            raise RuntimeError(
                f"Registry hostname '{hostname}' cannot be resolved (DNS). "
                "Set GATEWAY REGISTRY_URL to a resolvable registry and retry."
            ) from error
    try:
        probe_status = _probe_registry(registry_url)
    except httpx.HTTPError as error:
        raise RuntimeError(
            f"Registry endpoint '{registry_url}' is unreachable. "
            "Ensure the local tunnel or registry port is up, then retry publish."
        ) from error
    if probe_status not in {200, 401}:
        raise RuntimeError(
            f"Registry endpoint '{registry_url}' responded with unexpected status {probe_status}. "
            "Expected 200 or 401 from /v2/."
        )
    auth_status = docker.get_registry_auth_status(registry_host)
    if auth_status.state == "missing":
        raise RuntimeError(
            f"{auth_status.message}. This publish flow requires registry authentication before "
            "docker push."
        )
    auth_header = docker.get_registry_basic_auth_header(registry_host)
    if not auth_header:
        return
    try:
        authenticated_status = _probe_registry(registry_url, auth_header=auth_header)
    except httpx.HTTPError as error:
        raise RuntimeError(
            f"Registry endpoint '{registry_url}' is unreachable when checking credentials. "
            "Run make repair-local-registry-auth and retry publish."
        ) from error
    if authenticated_status == 200:
        return
    if authenticated_status == 401:
        raise RuntimeError(
            f"Registry credentials for {registry_host} are invalid or incompatible with the local "
            "registry. Run 'make repair-local-registry-auth' and then "
            f"'docker login {registry_host}'."
        )
    raise RuntimeError(
        f"Registry endpoint '{registry_url}' responded with unexpected authenticated status "
        f"{authenticated_status}. Expected 200 from /v2/."
    )


def create_publish_archive_path(slug: str, version: str) -> Path:
    """Create a temp file path for a docker image archive."""
    temp_dir = Path(tempfile.gettempdir()) / "ai-marketplace-cli"
    temp_dir.mkdir(parents=True, exist_ok=True)
    return temp_dir / f"{slug}-{version}.tar"
