"""Authentication command handlers."""

from __future__ import annotations

import sys
from typing import Any

import typer

from aimp_cli.domain.models import ConfigData
from aimp_cli.utils.stage_runtime_state import resolve_login_gateway_url

from .common import CommandRuntime, exit_with_error


def _persist_login(runtime: CommandRuntime, auth_context: Any, auth_response: Any) -> None:
    runtime.config_store.save(
        ConfigData(
            gatewayUrl=auth_context.gateway_url,
            apiKey=auth_context.api_key or "",
            username=auth_response.username,
            defaultWorkspace=auth_response.workspace,
        )
    )


def login_command(
    *,
    runtime: CommandRuntime,
    gateway: str | None,
    api_key: str | None,
    stdin: bool,
    json_output: bool,
    debug: bool,
) -> None:
    """Authenticate and store credentials."""
    context = runtime.build_command_context("login", debug=debug, json_output=json_output)
    try:
        if stdin:
            api_key = sys.stdin.read().strip()
        if not gateway:
            suggested = resolve_login_gateway_url(gateway_flag=None)
            if runtime.has_interactive_terminal():
                gateway = runtime.prompt_text(
                    "Gateway URL",
                    console=runtime.console,
                    default=suggested,
                    show_header=False,
                    title="Login",
                    subtitle="Enter the Gateway URL used for authentication.",
                )
            else:
                gateway = suggested
        if gateway is None:
            raise typer.Exit(code=0)
        if not api_key:
            runtime.require_tty()
            api_key = runtime.prompt_secret(
                "API key",
                console=runtime.console,
                show_header=False,
                title="Login",
                subtitle="Paste the API key for this machine.",
            )
        if api_key is None:
            raise typer.Exit(code=0)
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key, persist=True)
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            auth_response = client.authenticate(auth_context.api_key or "")
        finally:
            client.close()
        _persist_login(runtime, auth_context, auth_response)
        runtime.emit_result(
            {
                "valid": auth_response.valid,
                "username": auth_response.username,
                "user_id": auth_response.user_id,
                "workspace": auth_response.workspace,
                "gateway_url": auth_context.gateway_url,
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Authenticated as: {auth_response.username}\nWorkspace: {auth_response.workspace}"
            ),
            title="LOGIN",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def logout_command(*, runtime: CommandRuntime, json_output: bool, debug: bool) -> None:
    """Remove stored credentials."""
    context = runtime.build_command_context("logout", debug=debug, json_output=json_output)
    runtime.config_store.clear()
    runtime.emit_result(
        {"status": "logged_out", "request_id": context.request_id},
        json_output=json_output,
        success_message="Local credentials cleared.",
        title="LOGOUT",
    )


def auth_command(
    *,
    runtime: CommandRuntime,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_auth_panel: Any,
) -> None:
    """Show current authentication status."""
    context = runtime.build_command_context("auth", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            payload = {
                "authenticated": False,
                "reason": "no_credentials",
                "gateway_url": auth_context.gateway_url,
                "request_id": context.request_id,
            }
            if json_output:
                runtime.emit_result(payload, json_output=True)
            else:
                render_auth_panel(
                    gateway_url=auth_context.gateway_url,
                    authenticated=False,
                    reason="no_credentials",
                )
            return
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            current_user = client.get_current_user()
        finally:
            client.close()
        if current_user is None:
            payload = {
                "authenticated": False,
                "reason": "invalid_api_key",
                "gateway_url": auth_context.gateway_url,
                "request_id": context.request_id,
            }
            if json_output:
                runtime.emit_result(payload, json_output=True)
            else:
                render_auth_panel(
                    gateway_url=auth_context.gateway_url,
                    authenticated=False,
                    reason="invalid_api_key",
                )
            return

        if not json_output:
            render_auth_panel(
                gateway_url=auth_context.gateway_url,
                username=current_user.username,
                workspace=current_user.workspace,
                scopes=current_user.scopes,
                authenticated=True,
            )
        else:
            runtime.emit_result(
                {
                    "authenticated": True,
                    "reason": "authenticated",
                    "username": current_user.username,
                    "workspace": current_user.workspace,
                    "workspace_id": current_user.workspace_id,
                    "scopes": current_user.scopes,
                    "gateway_url": auth_context.gateway_url,
                    "request_id": context.request_id,
                },
                json_output=True,
            )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
