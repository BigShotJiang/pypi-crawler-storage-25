"""Compose command handlers for docker-compose.yml generation and validation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from aimp_cli.core.config import build_command_context, emit_result
from aimp_cli.core.errors import usage_error
from aimp_cli.operations.publish.discovery import generate_compose, validate_compose


def validate_compose_command(
    *,
    runtime: Any,
    python_bin: str | None = None,
    json_output: bool = False,
    debug: bool = False,
) -> None:
    """Validate docker-compose.yml against declared model runtimes."""
    ctx = build_command_context(runtime, json_output=json_output, debug=debug)
    project_dir = Path.cwd()

    try:
        result = validate_compose(project_dir=project_dir, python_bin=python_bin)
    except Exception as exc:  # noqa: BLE001
        if json_output:
            emit_result(ctx, error=str(exc))
            return
        raise

    if json_output:
        emit_result(ctx, data=result)
        return

    if result.get("valid"):
        print("docker-compose.yml is valid.")
    else:
        error_msg = result.get("error", "Validation failed")
        print(f"Validation error: {error_msg}")
        if result.get("missing"):
            print(f"Missing services: {', '.join(result['missing'])}")


def generate_compose_command(
    *,
    runtime: Any,
    output: Path | None = None,
    python_bin: str | None = None,
    dry_run: bool = False,
    json_output: bool = False,
    debug: bool = False,
) -> None:
    """Generate docker-compose.yml for the single-model runtime layout."""
    ctx = build_command_context(runtime, json_output=json_output, debug=debug)
    project_dir = Path.cwd()
    output_path = output or project_dir / "docker-compose.yml"

    try:
        compose_content = generate_compose(
            project_dir=project_dir,
            python_bin=python_bin,
        )
    except Exception as exc:  # noqa: BLE001
        if json_output:
            emit_result(ctx, error=str(exc))
            return
        raise

    yaml_content = yaml.dump(compose_content, default_flow_style=False, sort_keys=False)

    if dry_run:
        print(yaml_content)
        return

    output_path.write_text(yaml_content, encoding="utf-8")

    if json_output:
        emit_result(ctx, data={"path": str(output_path), "content": compose_content})
        return

    print(f"Generated {output_path}")
