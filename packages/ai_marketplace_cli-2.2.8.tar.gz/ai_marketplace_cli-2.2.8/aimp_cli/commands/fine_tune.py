"""Fine-tune command handlers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from aimp_cli.core.errors import (
    CliError,
    auth_error,
    environment_error,
    remote_state_error,
    usage_error,
)
from aimp_cli.domain.discovery import find_project_root
from aimp_cli.operations.fine_tune.dataset_sources import (
    load_dataset_source,
    write_bundle,
)
from aimp_cli.operations.fine_tune.workspace import (
    create_tune_workspace,
    default_tune_workspace_path,
    ensure_tune_workspace,
    load_tune_workspace_state,
    save_tune_workspace_state,
)
from aimp_cli.operations.scaffold.files import create_consumer_tuning_scaffold
from aimp_cli.utils.execution_stream import ExecutionStreamCallbacks, watch_execution_stream
from aimp_cli.utils.execution_stream import StreamReconcileConfig

from .common import CommandRuntime, exit_with_error

_ACTIVE_JOB_STATUSES = {"queued", "running"}
_TERMINAL_FINE_TUNE_STATUSES = {"succeeded", "failed", "canceled"}


def _hardware_family_from_tier(tier: str) -> str:
    normalized = str(tier or "").strip().lower()
    if not normalized:
        raise ValueError("hardware tier is required")
    return "gpu" if normalized.startswith("gpu-") else "cpu"


def _resolve_training_hardware_family(detail: dict[str, Any]) -> str:
    supported = detail.get("supported_hardware_tiers")
    selected = str(detail.get("selected_hardware_tier") or "").strip().lower()
    candidate_tiers: list[str] = []
    if isinstance(supported, list):
        candidate_tiers = [
            str(item).strip().lower() for item in supported if str(item or "").strip()
        ]
    if selected and selected not in candidate_tiers:
        candidate_tiers.insert(0, selected)
    if not candidate_tiers:
        raise RuntimeError("Model detail missing hardware tier metadata for fine-tune validation")

    families = {_hardware_family_from_tier(tier) for tier in candidate_tiers}
    if len(families) != 1:
        raise RuntimeError("Model detail contains mixed CPU/GPU hardware tiers")
    return next(iter(families))


def _build_fine_tune_status_message(execution: dict[str, Any], job_id: str) -> str:
    """Build the live fine-tune status line for one execution payload."""
    model_slug = str(execution.get("model_slug") or execution.get("slug") or "").strip()
    status = str(execution.get("status") or "unknown").strip()
    summary = f"Fine-tune: {status}"
    if model_slug:
        summary += f" · {model_slug}"
    stage_hint = _infer_fine_tune_stage_hint(execution)
    if stage_hint:
        summary += f" · {stage_hint}"
    summary += f" · job {job_id[:8]}"
    return summary


def _infer_fine_tune_stage_hint(execution: dict[str, Any]) -> str:
    """Infer one compact stage hint from timeline/log tail."""
    logs = execution.get("logs")
    if isinstance(logs, list):
        for item in reversed(logs):
            if not isinstance(item, dict):
                continue
            extra = item.get("extra")
            if not isinstance(extra, dict):
                continue
            trial_number = extra.get("trial_number")
            max_trials = extra.get("max_trials")
            if isinstance(trial_number, int) and isinstance(max_trials, int):
                elapsed_seconds = extra.get("elapsed_seconds")
                if isinstance(elapsed_seconds, int) and elapsed_seconds >= 0:
                    return f"trial {trial_number}/{max_trials} · {elapsed_seconds}s"
                return f"trial {trial_number}/{max_trials}"

    timeline = execution.get("timeline")
    if isinstance(timeline, list):
        for item in reversed(timeline):
            if not isinstance(item, dict):
                continue
            event = str(item.get("event") or "").strip().lower()
            if event == "job_claimed":
                return "claimed"
            if event == "study_create_started":
                return "creating study"
            if event == "study_created":
                return "study created"
            if event == "study_finalization_started":
                return "finalizing"
            if event == "result_bundle_upload_started":
                return "uploading bundle"
            if event == "trial_started":
                detail = str(item.get("detail") or "").strip()
                if detail:
                    return detail.replace("trial_id=", "trial ")
                return "trial started"
    return ""


def _merge_stream_items(
    execution: dict[str, Any], *, field: str, items: list[dict[str, Any]]
) -> None:
    """Merge streamed timeline/log deltas into latest execution snapshot."""
    current = execution.get(field)
    if isinstance(current, list):
        execution[field] = [*current, *items]
    else:
        execution[field] = list(items)


def _terminal_failure_detail(payload: dict[str, Any]) -> str:
    error_message = str(payload.get("error_message") or "").strip()
    if error_message:
        return error_message
    policy_summary = payload.get("smart_policy_summary")
    if isinstance(policy_summary, dict):
        failure_summary = policy_summary.get("failure_summary")
        if isinstance(failure_summary, dict):
            root_cause = str(failure_summary.get("root_cause_message") or "").strip()
            if root_cause:
                return root_cause
    logs = payload.get("logs")
    if isinstance(logs, list):
        for entry in reversed(logs):
            if not isinstance(entry, dict):
                continue
            message = str(entry.get("message") or "").strip()
            if not message:
                continue
            level = str(entry.get("level") or "").strip().lower()
            if (
                level in {"error", "fatal"}
                or "failed" in message.lower()
                or "errno" in message.lower()
            ):
                return message
    return "Fine-tune failed"


def _render_fine_tune_log_items(*, runtime: CommandRuntime, items: list[dict[str, Any]]) -> None:
    """Render streamed fine-tune log entries using the same style as publish-build."""
    for log_entry in items:
        log_level = log_entry.get("level", "info")
        message = str(log_entry.get("message") or "")
        if log_level == "error":
            runtime.console.print(f"[red]✗ {message}[/red]", soft_wrap=True)
        elif log_level == "warning":
            runtime.console.print(f"[yellow]⚠ {message}[/yellow]", soft_wrap=True)
        else:
            runtime.console.print(f"[dim]  {message}[/dim]", soft_wrap=True)


def _fetch_fine_tune_job_payload(*, client: Any, job_id: str) -> dict[str, Any]:
    """Fetch one fine-tune job payload from Gateway detail API."""
    return client.get_fine_tune_job(job_id=job_id).model_dump()


def _recover_terminal_fine_tune_payload_after_stream_error(
    *,
    client: Any,
    job_id: str,
    error: CliError,
) -> dict[str, Any] | None:
    """Return terminal job payload when stream failed but backend already finalized."""
    if error.code not in {
        "remote_job_failed",
        "job_stream_unavailable",
        "job_stream_disconnected_active",
        "job_stream_reconcile_unexpected",
    }:
        return None
    try:
        payload = _fetch_fine_tune_job_payload(client=client, job_id=job_id)
    except Exception:
        return None
    if _status_like(payload) in _TERMINAL_FINE_TUNE_STATUSES:
        return payload
    return None


def _find_active_fine_tune_job(*, client: Any, model_slug: str) -> dict[str, Any] | None:
    """Return one active fine-tune job payload for the target model when present."""
    payload = client.list_fine_tune_jobs(model_slug=model_slug, page_size=100)
    for job in payload.results:
        if job.status in _ACTIVE_JOB_STATUSES:
            return job.model_dump()
    return None


def _extract_active_fine_tune_job_from_error(error: CliError) -> dict[str, Any] | None:
    """Extract one existing fine-tune job payload from a structured conflict error."""
    if error.code != "active_job_exists":
        return None
    if not isinstance(error.extra, dict):
        return None
    if error.extra.get("job_type") != "fine-tune":
        return None
    existing_job = error.extra.get("existing_job")
    return existing_job if isinstance(existing_job, dict) else None


def _build_active_fine_tune_error(
    *,
    model_slug: str,
    existing_job: dict[str, Any],
    request_id: str,
) -> CliError:
    """Build a stable CLI conflict error for an existing active fine-tune job."""
    job_id = str(existing_job.get("job_id") or "").strip() or "unknown"
    status = str(existing_job.get("status") or "queued").strip() or "queued"
    return remote_state_error(
        f"Active fine-tune job exists: {job_id}",
        code="active_job_exists",
        request_id=request_id,
        hint="Use --force to cancel it and start a new one.",
        http_status=409,
        extra={
            "job_type": "fine-tune",
            "model_slug": model_slug,
            "status": status,
            "existing_job": existing_job,
        },
    )


def _display_path(path: Path) -> str:
    """Render a local path relative to cwd when that is clearer."""
    resolved = path.expanduser().resolve()
    try:
        relative = resolved.relative_to(Path.cwd().resolve())
    except ValueError:
        return str(resolved)
    return "." if not relative.parts else f"./{relative}"


def _validate_remote_fine_tune_detail(
    *,
    detail: dict[str, Any],
    model: str,
    request_id: str,
) -> dict[str, Any]:
    """Validate remote model fine-tune metadata and return the schema contract."""
    if not bool(detail.get("tuning_supported", False)):
        raise remote_state_error(
            f"Model '{model}' does not support fine-tune",
            code="fine_tune_not_supported",
            request_id=request_id,
            http_status=400,
        )
    try:
        _resolve_training_hardware_family(detail)
    except RuntimeError as error:
        raise remote_state_error(
            f"Model '{model}' has invalid training runtime metadata: {error}",
            code="fine_tune_training_runtime_invalid",
            request_id=request_id,
            http_status=400,
        ) from error
    schema_contract = detail.get("tuning_schema")
    if not isinstance(schema_contract, dict):
        raise remote_state_error(
            f"Model '{model}' does not expose a fine-tune schema",
            code="fine_tune_schema_missing",
            request_id=request_id,
            http_status=400,
        )
    return schema_contract


def fine_tune_schema_command(
    *,
    runtime: CommandRuntime,
    model: str | None,
    tuning_model: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    load_local_tuning_contract: Any,
) -> None:
    """Show the fine-tune schema for a local or published model."""
    context = runtime.build_command_context(
        "fine_tune.schema",
        debug=debug,
        json_output=json_output,
    )
    try:
        if model and tuning_model:
            raise usage_error(
                "--tuning-model can only be used for local schema discovery (without --model)",
                code="invalid_tuning_model_option",
                request_id=context.request_id,
            )
        if model:
            auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
            if not auth_context.api_key:
                raise auth_error(
                    "Not authenticated. Run: ai login",
                    code="not_authenticated",
                    request_id=context.request_id,
                )
            client = runtime.gateway_client_cls(auth_context, context)
            try:
                detail = client.get_marketplace_model_detail(model)
            finally:
                client.close()
            schema_contract = detail.get("tuning_schema")
            if not isinstance(schema_contract, dict):
                raise remote_state_error(
                    f"Model '{model}' does not expose a fine-tune schema",
                    code="fine_tune_schema_missing",
                    request_id=context.request_id,
                    http_status=404,
                )
            payload = {
                "model": model,
                "schema": schema_contract,
                "request_id": context.request_id,
            }
        else:
            project_dir = find_project_root(Path.cwd())
            payload = {
                "project_root": str(project_dir),
                "schema": load_local_tuning_contract(
                    project_dir,
                    tuning_model=tuning_model,
                )["schema"],
                "request_id": context.request_id,
            }
        runtime.emit_result(
            payload,
            json_output=json_output,
            success_message=(
                "Fine-tune schema fields: "
                + ", ".join(
                    str(field.get("key") or "").strip()
                    for field in payload["schema"].get("fields", [])
                    if isinstance(field, dict) and str(field.get("key") or "").strip()
                )
            ),
            title="FINE-TUNE SCHEMA",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_scaffold_command(
    *,
    runtime: CommandRuntime,
    model: str,
    output: Path | None,
    regenerate: bool,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    default_fine_tune_scaffold_output_dir: Any,
) -> None:
    """Generate a consumer-facing fine-tune scaffold from a published schema.

    Args:
        regenerate: If True, only update .tuning/ folder, preserve user edits.
    """
    context = runtime.build_command_context(
        "fine_tune.scaffold",
        debug=debug,
        json_output=json_output,
    )
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            detail = client.get_marketplace_model_detail(model)
        finally:
            client.close()
        if not bool(detail.get("tuning_supported", False)):
            raise remote_state_error(
                f"Model '{model}' does not support fine-tune",
                code="fine_tune_not_supported",
                request_id=context.request_id,
                http_status=400,
            )
        schema_contract = detail.get("tuning_schema")
        if not isinstance(schema_contract, dict):
            raise remote_state_error(
                f"Model '{model}' does not expose a fine-tune schema",
                code="fine_tune_schema_missing",
                request_id=context.request_id,
                http_status=400,
            )
        tuning_contract = detail.get("tuning")
        parameters_contract: dict[str, Any] = {}
        if isinstance(tuning_contract, dict):
            params = tuning_contract.get("parameters")
            if isinstance(params, dict):
                parameters_contract = params
        output_dir = (
            output.expanduser().resolve()
            if output
            else default_fine_tune_scaffold_output_dir(model)
        )

        if regenerate:
            from aimp_cli.operations.scaffold.files import regenerate_tuning_scaffold

            files = regenerate_tuning_scaffold(
                output_dir,
                model_slug=model,
                schema_contract=schema_contract,
                parameters_contract=parameters_contract,
            )
            success_msg = (
                f"Regenerated .tuning/ for {model}\n"
                "Workspace metadata refreshed.\n"
                f"Output: {output_dir}"
            )
        else:
            files = create_consumer_tuning_scaffold(
                output_dir,
                model_slug=model,
                schema_contract=schema_contract,
                parameters_contract=parameters_contract,
            )
            success_msg = (
                f"Scaffolded: {output_dir}\n"
                "Edit data.jsonl and tune.py, then run:\n"
                f"  cd {output_dir}\n"
                "  ai tune push"
            )

        payload = {
            "model": model,
            "output_dir": str(output_dir),
            "files": files,
            "regenerated": regenerate,
            "request_id": context.request_id,
        }
        runtime.emit_result(
            payload,
            json_output=json_output,
            success_message=success_msg,
            title="FINE-TUNE SCAFFOLD",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def _submit_fine_tune_bundle(
    *,
    runtime: CommandRuntime,
    context: Any,
    client: Any,
    model: str,
    schema_contract: dict[str, Any],
    bundle_path: Path,
    max_trials: int,
    labels: dict[str, Any] | None,
    force: bool,
    watch: bool,
    json_output: bool,
    create_tuning_bundle_archive: Any,
    render_fine_tune_job: Any | None,
) -> dict[str, Any]:
    """Upload a validated bundle, create the fine-tune job, and optionally watch it."""
    temp_bundle, content_type = create_tuning_bundle_archive(
        schema_contract=schema_contract,
        bundle_path=bundle_path,
    )
    existing_job = _find_active_fine_tune_job(client=client, model_slug=model)
    if existing_job is not None:
        if render_fine_tune_job is not None and not json_output:
            render_fine_tune_job(existing_job)
        if not force:
            raise _build_active_fine_tune_error(
                model_slug=model,
                existing_job=existing_job,
                request_id=context.request_id,
            )
        job_id = str(existing_job.get("job_id") or "").strip()
        if job_id:
            client.cancel_fine_tune_job(job_id=job_id)

    upload_client = runtime.upload_client_cls(client)
    version_suffix = "".join(ch for ch in context.request_id if ch.isalnum() or ch == ".")[:12]
    upload_version = f"0.0.0-{version_suffix}" if version_suffix else "0.0.0"
    try:
        upload_result = upload_client.upload_file(
            file_path=Path(temp_bundle.name),
            slug=model,
            version=upload_version,
            artifact_type="fine_tune_dataset",
            content_type=content_type,
            metadata={
                "purpose": "fine_tune_dataset",
                "bundle_format": "aimp_tuning_bundle_v1",
            },
            concurrency=1,
            on_progress=None,
        )
    finally:
        Path(temp_bundle.name).unlink(missing_ok=True)

    try:
        job = client.create_fine_tune_job(
            model_slug=model,
            dataset_ref=upload_result.storage_uri,
            budget={"max_trials": max_trials},
            labels=labels,
        )
    except CliError as error:
        existing_job = _extract_active_fine_tune_job_from_error(error)
        if existing_job is None:
            raise
        if render_fine_tune_job is not None and not json_output:
            render_fine_tune_job(existing_job)
        if force:
            job_id = str(existing_job.get("job_id") or "").strip()
            if job_id:
                client.cancel_fine_tune_job(job_id=job_id)
            raise usage_error(
                f"Fine-tune {job_id[:8]} canceled. Run the command again to start a new one.",
                code="fine_tune_force_retry",
                request_id=context.request_id,
            ) from error
        raise _build_active_fine_tune_error(
            model_slug=model,
            existing_job=existing_job,
            request_id=context.request_id,
        ) from error

    latest_execution: dict[str, Any] = {}
    if watch:
        if json_output:
            try:
                watch_execution_stream(
                    gateway=client,
                    job_id=job.job_id,
                    context=context,
                    reconcile=StreamReconcileConfig(
                        fetch=lambda: _fetch_fine_tune_job_payload(
                            client=client, job_id=job.job_id
                        ),
                        kind="execution",
                        job_type_for_hint="fine-tune",
                    ),
                )
            except CliError as error:
                reconciled = _recover_terminal_fine_tune_payload_after_stream_error(
                    client=client,
                    job_id=job.job_id,
                    error=error,
                )
                if reconciled is None:
                    raise
        else:
            with runtime.console.status("Fine-tune queued", spinner="line") as status:
                try:
                    watch_execution_stream(
                        gateway=client,
                        job_id=job.job_id,
                        context=context,
                        callbacks=ExecutionStreamCallbacks(
                            on_snapshot=lambda execution: (
                                latest_execution.clear(),
                                latest_execution.update(execution),
                                status.update(
                                    _build_fine_tune_status_message(execution, job.job_id)
                                ),
                            ),
                            on_status=lambda payload: status.update(
                                _build_fine_tune_status_message(
                                    {**latest_execution, "status": payload.get("status")},
                                    job.job_id,
                                )
                            ),
                            on_timeline=lambda items, _payload: (
                                _merge_stream_items(
                                    latest_execution, field="timeline", items=items
                                ),
                                status.update(
                                    _build_fine_tune_status_message(latest_execution, job.job_id)
                                ),
                            ),
                            on_logs=lambda items, _payload: (
                                _merge_stream_items(latest_execution, field="logs", items=items),
                                status.update(
                                    _build_fine_tune_status_message(latest_execution, job.job_id)
                                ),
                                _render_fine_tune_log_items(
                                    runtime=runtime,
                                    items=items,
                                ),
                            ),
                            on_terminal=lambda execution: (
                                latest_execution.clear(),
                                latest_execution.update(execution),
                                status.update(
                                    _build_fine_tune_status_message(execution, job.job_id)
                                ),
                            ),
                        ),
                        on_reconnect=lambda attempt: status.update(
                            f"Reconnecting to fine-tune stream (attempt {attempt})..."
                        ),
                        reconcile=StreamReconcileConfig(
                            fetch=lambda: _fetch_fine_tune_job_payload(
                                client=client, job_id=job.job_id
                            ),
                            kind="execution",
                            job_type_for_hint="fine-tune",
                        ),
                    )
                except CliError as error:
                    reconciled = _recover_terminal_fine_tune_payload_after_stream_error(
                        client=client,
                        job_id=job.job_id,
                        error=error,
                    )
                    if reconciled is None:
                        raise
        job = client.get_fine_tune_job(job_id=job.job_id)

    if job.status == "failed":
        raise environment_error(
            job.error_message or "Fine-tune failed",
            code=job.error_code or "fine_tune_failed",
            request_id=context.request_id,
            extra={"job_id": job.job_id},
        )
    if job.status == "canceled":
        raise remote_state_error(
            "Fine-tune canceled",
            code="fine_tune_canceled",
            request_id=context.request_id,
            extra={"job_id": job.job_id},
        )
    payload = job.model_dump()
    payload["job_created"] = True
    payload["terminal"] = bool(job.status in {"succeeded", "failed", "canceled"})
    return payload


def _workspace_bundle_path(workspace_dir: Path) -> Path:
    return workspace_dir / ".tuning" / "bundle.json"


def _schema_from_workspace(workspace_metadata: dict[str, Any]) -> dict[str, Any]:
    schema_path = Path(workspace_metadata["schema_path"])
    try:
        payload = json.loads(schema_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise usage_error(
            f"{schema_path} contains invalid JSON: {exc.msg}",
            code="invalid_tune_workspace",
        ) from exc
    if not isinstance(payload, dict):
        raise usage_error(
            f"{schema_path} must be a JSON object.",
            code="invalid_tune_workspace",
        )
    return payload


def _status_like(payload: dict[str, Any]) -> str:
    return str(payload.get("status") or "").strip().lower()


def _update_workspace_job_state(
    *,
    workspace_dir: Path,
    model_slug: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    state = load_tune_workspace_state(workspace_dir)
    state["model"] = model_slug
    job_id = str(payload.get("job_id") or "").strip() or None
    status = _status_like(payload) or None
    output_model = str(payload.get("output_asset_slug") or "").strip() or None
    if job_id is not None:
        state["latest_job_id"] = job_id
    if status is not None:
        state["latest_status"] = status
    state["latest_output_model"] = output_model
    if status == "succeeded" and output_model:
        state["last_successful_output_model"] = output_model
    save_tune_workspace_state(workspace_dir, state)
    return state


def _resolve_target_job_id(
    *,
    client: Any,
    workspace_dir: Path,
    model_slug: str,
    explicit_job_id: str | None,
    request_id: str,
) -> str:
    if explicit_job_id:
        return explicit_job_id
    state = load_tune_workspace_state(workspace_dir)
    latest_job_id = str(state.get("latest_job_id") or "").strip()
    if latest_job_id:
        return latest_job_id
    payload = client.list_fine_tune_jobs(model_slug=model_slug, page_size=1)
    if payload.results:
        job_id = payload.results[0].job_id
        save_tune_workspace_state(
            workspace_dir,
            {
                **state,
                "latest_job_id": job_id,
                "latest_status": payload.results[0].status,
                "latest_output_model": payload.results[0].output_asset_slug,
                "last_successful_output_model": (
                    payload.results[0].output_asset_slug
                    if payload.results[0].status == "succeeded"
                    else state.get("last_successful_output_model")
                ),
            },
        )
        return job_id
    raise usage_error(
        "No fine-tune jobs found for this workspace. Start one with: ai tune push",
        code="tune_workspace_job_missing",
        request_id=request_id,
    )


def _watch_job(
    *,
    runtime: CommandRuntime,
    client: Any,
    context: Any,
    job_id: str,
    model_slug: str,
    workspace_dir: Path,
    json_output: bool,
) -> dict[str, Any]:
    latest_execution: dict[str, Any] = {}
    if json_output:
        try:
            payload = watch_execution_stream(
                gateway=client,
                job_id=job_id,
                context=context,
                reconcile=StreamReconcileConfig(
                    fetch=lambda: _fetch_fine_tune_job_payload(client=client, job_id=job_id),
                    kind="execution",
                    job_type_for_hint="fine-tune",
                ),
            )
        except CliError as error:
            reconciled = _recover_terminal_fine_tune_payload_after_stream_error(
                client=client,
                job_id=job_id,
                error=error,
            )
            if reconciled is None:
                raise
            payload = reconciled
        if not isinstance(payload, dict):
            payload = client.get_fine_tune_job(job_id=job_id).model_dump()
        result = client.get_fine_tune_job(job_id=job_id).model_dump()
        _update_workspace_job_state(
            workspace_dir=workspace_dir,
            model_slug=model_slug,
            payload=result,
        )
        return result

    with runtime.console.status(
        _build_fine_tune_status_message({"status": "queued"}, job_id)
    ) as status:
        try:
            watch_execution_stream(
                gateway=client,
                job_id=job_id,
                context=context,
                callbacks=ExecutionStreamCallbacks(
                    on_snapshot=lambda execution: (
                        latest_execution.clear(),
                        latest_execution.update(execution),
                        status.update(_build_fine_tune_status_message(execution, job_id)),
                    ),
                    on_status=lambda payload: status.update(
                        _build_fine_tune_status_message(
                            {**latest_execution, "status": payload.get("status")},
                            job_id,
                        )
                    ),
                    on_timeline=lambda items, _payload: (
                        _merge_stream_items(latest_execution, field="timeline", items=items),
                        status.update(_build_fine_tune_status_message(latest_execution, job_id)),
                    ),
                    on_logs=lambda items, _payload: (
                        _merge_stream_items(latest_execution, field="logs", items=items),
                        status.update(_build_fine_tune_status_message(latest_execution, job_id)),
                        _render_fine_tune_log_items(
                            runtime=runtime,
                            items=items,
                        ),
                    ),
                    on_terminal=lambda execution: (
                        latest_execution.clear(),
                        latest_execution.update(execution),
                        status.update(_build_fine_tune_status_message(execution, job_id)),
                    ),
                ),
                on_reconnect=lambda attempt: status.update(
                    f"Reconnecting to fine-tune stream (attempt {attempt})..."
                ),
                reconcile=StreamReconcileConfig(
                    fetch=lambda: _fetch_fine_tune_job_payload(client=client, job_id=job_id),
                    kind="execution",
                    job_type_for_hint="fine-tune",
                ),
            )
        except CliError as error:
            reconciled = _recover_terminal_fine_tune_payload_after_stream_error(
                client=client,
                job_id=job_id,
                error=error,
            )
            if reconciled is None:
                raise
    result = client.get_fine_tune_job(job_id=job_id).model_dump()
    _update_workspace_job_state(
        workspace_dir=workspace_dir,
        model_slug=model_slug,
        payload=result,
    )
    return result


def tune_push_command(
    *,
    runtime: CommandRuntime,
    detach: bool,
    force: bool,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    create_tuning_bundle_archive: Any,
    render_fine_tune_job: Any,
) -> None:
    """Push a fine-tune job from the current tune workspace."""
    context = runtime.build_command_context("tune.push", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        workspace_metadata = ensure_tune_workspace(Path.cwd())
        workspace_dir = Path(workspace_metadata["workspace_dir"])
        model_slug = str(workspace_metadata["model"])
        schema_contract = _schema_from_workspace(workspace_metadata)
        config = workspace_metadata["config"]
        source_path = workspace_dir / str(config.data)
        source_format = None
        max_trials = int(config.max_trials)
        labels: dict[str, Any] = {"tuning_mode": str(config.mode)}
        if str(config.mode) == "manual":
            labels["manual_parameters"] = dict(config.manual_parameters)

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            detail = client.get_marketplace_model_detail(model_slug)
            _validate_remote_fine_tune_detail(
                detail=detail,
                model=model_slug,
                request_id=context.request_id,
            )
            records = load_dataset_source(
                source_path=source_path,
                schema_contract=schema_contract,
                source_format=source_format,
                mapping={},
                bundle_dir=workspace_dir,
            )
            bundle_path = _workspace_bundle_path(workspace_dir)
            write_bundle(bundle_path=bundle_path, records=records)

            payload = _submit_fine_tune_bundle(
                runtime=runtime,
                context=context,
                client=client,
                model=model_slug,
                schema_contract=schema_contract,
                bundle_path=bundle_path,
                max_trials=max_trials,
                labels=labels,
                force=force,
                watch=False,
                json_output=json_output,
                create_tuning_bundle_archive=create_tuning_bundle_archive,
                render_fine_tune_job=render_fine_tune_job,
            )
            state = _update_workspace_job_state(
                workspace_dir=workspace_dir,
                model_slug=model_slug,
                payload=payload,
            )
            job_id = str(payload.get("job_id") or "")
            if not detach and job_id:
                payload = _watch_job(
                    runtime=runtime,
                    client=client,
                    context=context,
                    job_id=job_id,
                    model_slug=model_slug,
                    workspace_dir=workspace_dir,
                    json_output=json_output,
                )
                state = load_tune_workspace_state(workspace_dir)
        finally:
            client.close()

        result = {
            "model": model_slug,
            "workspace": _display_path(workspace_dir),
            "job": payload,
            "state": state,
            "request_id": context.request_id,
        }
        status = _status_like(payload)
        if status == "failed":
            raise environment_error(
                _terminal_failure_detail(payload),
                code=str(payload.get("error_code") or "fine_tune_failed"),
                request_id=context.request_id,
                extra={"job_id": payload.get("job_id")},
            )
        if status == "canceled":
            raise remote_state_error(
                f"Fine-tune canceled (job {payload.get('job_id')})",
                code="fine_tune_canceled",
                request_id=context.request_id,
            )

        if json_output:
            runtime.emit_result(result, json_output=True)
            return
        output_slug = str(payload.get("output_asset_slug") or "").strip()
        if detach:
            message = (
                "Fine-tune job started\n"
                f"Model: {model_slug}\n"
                f"Job: {payload.get('job_id')}\n"
                f"Workspace: {_display_path(workspace_dir)}"
            )
        else:
            message = (
                "Fine-tune succeeded\n"
                f"Model: {model_slug}\n"
                f"Job: {payload.get('job_id')}\n"
                f"Workspace: {_display_path(workspace_dir)}"
            )
        if detach and status in {"queued", "running", "canceling"}:
            message += "\nRun: ai tune watch"
        if status == "succeeded" and output_slug:
            usable_modes = [
                str(mode).strip()
                for mode in (payload.get("output_usable_modes") or [])
                if str(mode).strip()
            ]
            unusable_modes = payload.get("output_unusable_modes") or {}
            message += (
                f"\nDerived model: {output_slug}\nInspect: ai model inspect --slug {output_slug}\n"
            )
            if usable_modes:
                message += f"Use: ai run --model {output_slug} --mode {usable_modes[0]}"
            elif isinstance(unusable_modes, dict) and unusable_modes:
                blocked = ", ".join(
                    f"{mode} ({'; '.join(reasons)})" for mode, reasons in unusable_modes.items()
                )
                message += f"Result warning: derived model is not yet usable: {blocked}"
        runtime.emit_result(result, json_output=False, success_message=message, title="TUNE PUSH")
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def tune_watch_command(
    *,
    runtime: CommandRuntime,
    job: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """Watch the latest workspace fine-tune job or one explicit job."""
    context = runtime.build_command_context("tune.watch", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        workspace_metadata = ensure_tune_workspace(Path.cwd())
        workspace_dir = Path(workspace_metadata["workspace_dir"])
        model_slug = str(workspace_metadata["model"])
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            job_id = _resolve_target_job_id(
                client=client,
                workspace_dir=workspace_dir,
                model_slug=model_slug,
                explicit_job_id=job,
                request_id=context.request_id,
            )
            payload = _watch_job(
                runtime=runtime,
                client=client,
                context=context,
                job_id=job_id,
                model_slug=model_slug,
                workspace_dir=workspace_dir,
                json_output=json_output,
            )
        finally:
            client.close()
        result = {
            "model": model_slug,
            "workspace": _display_path(workspace_dir),
            **payload,
            "request_id": context.request_id,
        }
        if json_output:
            runtime.emit_result(result, json_output=True)
            return
        runtime.emit_result(
            result,
            json_output=False,
            success_message=f"Fine-tune watch complete for job {payload.get('job_id')}",
            title="TUNE WATCH",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def tune_status_command(
    *,
    runtime: CommandRuntime,
    job: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_fine_tune_job: Any,
) -> None:
    """Show status for the latest workspace fine-tune job."""
    context = runtime.build_command_context("tune.status", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        workspace_metadata = ensure_tune_workspace(Path.cwd())
        workspace_dir = Path(workspace_metadata["workspace_dir"])
        model_slug = str(workspace_metadata["model"])
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            job_id = _resolve_target_job_id(
                client=client,
                workspace_dir=workspace_dir,
                model_slug=model_slug,
                explicit_job_id=job,
                request_id=context.request_id,
            )
            payload = client.get_fine_tune_job(job_id=job_id).model_dump()
        finally:
            client.close()
        state = _update_workspace_job_state(
            workspace_dir=workspace_dir,
            model_slug=model_slug,
            payload=payload,
        )
        result = {
            "model": model_slug,
            "workspace": _display_path(workspace_dir),
            "state": state,
            **payload,
            "request_id": context.request_id,
        }
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            status_value = str(result.get("status") or "").strip().lower()
            if status_value == "failed" and not result.get("error_message"):
                result["error_message"] = _terminal_failure_detail(result)
            render_fine_tune_job(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def tune_logs_command(
    *,
    runtime: CommandRuntime,
    job: str | None,
    watch: bool,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """Show or stream logs for a workspace fine-tune job."""
    context = runtime.build_command_context("tune.logs", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        workspace_metadata = ensure_tune_workspace(Path.cwd())
        workspace_dir = Path(workspace_metadata["workspace_dir"])
        model_slug = str(workspace_metadata["model"])
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            job_id = _resolve_target_job_id(
                client=client,
                workspace_dir=workspace_dir,
                model_slug=model_slug,
                explicit_job_id=job,
                request_id=context.request_id,
            )
            if watch:
                payload = _watch_job(
                    runtime=runtime,
                    client=client,
                    context=context,
                    job_id=job_id,
                    model_slug=model_slug,
                    workspace_dir=workspace_dir,
                    json_output=json_output,
                )
                result = {
                    "model": model_slug,
                    "workspace": _display_path(workspace_dir),
                    **payload,
                    "request_id": context.request_id,
                }
                if json_output:
                    runtime.emit_result(result, json_output=True)
                else:
                    runtime.emit_result(
                        result,
                        json_output=False,
                        success_message=f"Fine-tune log stream complete for job {job_id}",
                        title="TUNE LOGS",
                    )
                return
            raw = client.get_job(job_id=job_id)
            job_payload = raw.get("job") if isinstance(raw.get("job"), dict) else raw
            if not isinstance(job_payload, dict):
                job_payload = {}
            logs = job_payload.get("logs") if isinstance(job_payload.get("logs"), list) else []
            error_message = str(job_payload.get("error_message") or "").strip()
            status_value = str(job_payload.get("status") or "").strip().lower()
            result = {
                "model": model_slug,
                "workspace": _display_path(workspace_dir),
                "job_id": job_id,
                "logs": logs,
                "error_message": (
                    error_message or _terminal_failure_detail(job_payload)
                    if status_value == "failed"
                    else error_message
                ),
                "request_id": context.request_id,
            }
            if json_output:
                runtime.emit_result(result, json_output=True)
            else:
                _render_fine_tune_log_items(
                    runtime=runtime,
                    items=[item for item in logs if isinstance(item, dict)],
                )
                if result["error_message"]:
                    runtime.console.print(f"[red]Failure:[/red] {result['error_message']}")
                runtime.emit_result(
                    result,
                    json_output=False,
                    success_message=f"Displayed {len(logs)} log entries for job {job_id}",
                    title="TUNE LOGS",
                )
        finally:
            client.close()
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def tune_cancel_command(
    *,
    runtime: CommandRuntime,
    job: str | None,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
) -> None:
    """Cancel the latest running workspace fine-tune job."""
    context = runtime.build_command_context("tune.cancel", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        workspace_metadata = ensure_tune_workspace(Path.cwd())
        workspace_dir = Path(workspace_metadata["workspace_dir"])
        model_slug = str(workspace_metadata["model"])
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            job_id = _resolve_target_job_id(
                client=client,
                workspace_dir=workspace_dir,
                model_slug=model_slug,
                explicit_job_id=job,
                request_id=context.request_id,
            )
            payload = client.cancel_fine_tune_job(job_id=job_id).model_dump()
            current = client.get_fine_tune_job(job_id=job_id).model_dump()
        finally:
            client.close()
        _update_workspace_job_state(
            workspace_dir=workspace_dir,
            model_slug=model_slug,
            payload=current,
        )
        result = {
            "model": model_slug,
            "workspace": _display_path(workspace_dir),
            **payload,
            "job": current,
            "request_id": context.request_id,
        }
        if json_output:
            runtime.emit_result(result, json_output=True)
            return
        runtime.emit_result(
            result,
            json_output=False,
            success_message=f"Cancel requested for fine-tune job {job_id}",
            title="TUNE CANCEL",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def tune_list_command(
    *,
    runtime: CommandRuntime,
    status: str | None,
    page: int,
    page_size: int,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_fine_tune_list: Any,
) -> None:
    """List fine-tune jobs for the current workspace model."""
    context = runtime.build_command_context("tune.list", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        workspace_metadata = ensure_tune_workspace(Path.cwd())
        workspace_dir = Path(workspace_metadata["workspace_dir"])
        model_slug = str(workspace_metadata["model"])
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = client.list_fine_tune_jobs(
                model_slug=model_slug,
                status=status,
                page=page,
                page_size=page_size,
            )
        finally:
            client.close()
        result = {
            "model": model_slug,
            "workspace": _display_path(workspace_dir),
            **payload.model_dump(),
            "request_id": context.request_id,
        }
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_fine_tune_list(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_create_command(
    *,
    runtime: CommandRuntime,
    model: str,
    bundle: Path | None,
    workspace: Path | None,
    output_dir: Path | None,
    max_trials: int,
    force: bool = False,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    resolve_fine_tune_output_dir: Any,
    resolve_fine_tune_bundle_path: Any,
    create_tuning_bundle_archive: Any,
    render_fine_tune_job: Any,
) -> None:
    """Create a new fine-tune job for a published model."""
    context = runtime.build_command_context(
        "fine_tune.create",
        debug=debug,
        json_output=json_output,
    )
    try:
        if bundle is not None and (workspace is not None or output_dir is not None):
            raise usage_error(
                "Use either --bundle or one workspace/output directory source",
                code="invalid_dataset_source",
                request_id=context.request_id,
            )

        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )

        client = runtime.gateway_client_cls(auth_context, context)
        try:
            detail = client.get_marketplace_model_detail(model)
            schema_contract = _validate_remote_fine_tune_detail(
                detail=detail,
                model=model,
                request_id=context.request_id,
            )
            resolved_output_dir = resolve_fine_tune_output_dir(
                model_slug=model,
                workspace=workspace,
                output_dir=output_dir,
            )
            if bundle is not None:
                bundle_path = resolve_fine_tune_bundle_path(bundle=bundle)
            else:
                bundle_path = resolved_output_dir / "bundle.json"
                workspace_exists = resolved_output_dir.exists()
                workspace_has_files = workspace_exists and any(resolved_output_dir.iterdir())
                if not workspace_has_files:
                    tuning_contract = detail.get("tuning")
                    parameters_contract: dict[str, Any] = {}
                    if isinstance(tuning_contract, dict):
                        params = tuning_contract.get("parameters")
                        if isinstance(params, dict):
                            parameters_contract = params
                    files = create_tune_workspace(
                        workspace_dir=resolved_output_dir,
                        model_slug=model,
                        schema_contract=schema_contract,
                        parameters_contract=parameters_contract,
                    )
                    payload = {
                        "model": model,
                        "job_created": False,
                        "output_dir": str(resolved_output_dir),
                        "files": files,
                        "next_step": (
                            f"Run `cd {resolved_output_dir} && ai tune push` "
                            "to validate data, create the internal bundle, and submit the job."
                        ),
                        "request_id": context.request_id,
                    }
                    runtime.emit_result(
                        payload,
                        json_output=json_output,
                        success_message=(
                            f"Scaffolded: {resolved_output_dir}\n"
                            "Next:\n"
                            f"  cd {resolved_output_dir}\n"
                            "  ai tune push"
                        ),
                        title="FINE-TUNE CREATE",
                    )
                    return
                if not bundle_path.exists() or not bundle_path.is_file():
                    raise usage_error(
                        f"Fine-tune bundle not found at {bundle_path}. "
                        f"Use `ai tune push` from {resolved_output_dir} to generate and submit it.",
                        code="dataset_not_found",
                        request_id=context.request_id,
                    )
            payload = _submit_fine_tune_bundle(
                runtime=runtime,
                context=context,
                client=client,
                model=model,
                schema_contract=schema_contract,
                bundle_path=bundle_path,
                max_trials=max_trials,
                labels=None,
                force=force,
                watch=True,
                json_output=json_output,
                create_tuning_bundle_archive=create_tuning_bundle_archive,
                render_fine_tune_job=render_fine_tune_job,
            )
        finally:
            client.close()
        if bundle is None:
            payload["output_dir"] = str(resolved_output_dir)
        if json_output:
            runtime.emit_result(payload, json_output=True)
        else:
            render_fine_tune_job(payload)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def tune_command(
    *,
    runtime: CommandRuntime,
    model: str,
    data: Path | None,
    source_format: str | None,
    column_mapping: list[str] | None,
    workspace: Path | None,
    max_trials: int,
    watch: bool,
    force: bool,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    create_tuning_bundle_archive: Any,
    render_fine_tune_job: Any,
) -> None:
    """Deprecated model-first tune command; use workspace-first flow."""
    context = runtime.build_command_context("tune", debug=debug, json_output=json_output)
    try:
        workspace_dir = (
            workspace.expanduser().resolve() if workspace else default_tune_workspace_path(model)
        )
        if workspace is None and data is None and not workspace_dir.exists():
            auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
            if not auth_context.api_key:
                raise auth_error(
                    "Not authenticated. Run: ai login",
                    code="not_authenticated",
                    request_id=context.request_id,
                )
            client = runtime.gateway_client_cls(auth_context, context)
            try:
                detail = client.get_marketplace_model_detail(model)
                schema_contract = _validate_remote_fine_tune_detail(
                    detail=detail,
                    model=model,
                    request_id=context.request_id,
                )
            finally:
                client.close()
            files = create_tune_workspace(
                workspace_dir=workspace_dir,
                model_slug=model,
                schema_contract=schema_contract,
                parameters_contract=(
                    detail.get("tuning", {}).get("parameters", {})
                    if isinstance(detail.get("tuning"), dict)
                    else {}
                ),
            )
            payload = {
                "model": model,
                "workspace": _display_path(workspace_dir),
                "job_created": False,
                "files": files,
                "next_step": "cd ./%s && ai tune push" % workspace_dir.name,
                "request_id": context.request_id,
            }
            runtime.emit_result(
                payload,
                json_output=json_output,
                success_message=(
                    f"Created fine-tune workspace: {_display_path(workspace_dir)}\n"
                    "Next:\n"
                    f"  cd {_display_path(workspace_dir)}\n"
                    "  ai tune push"
                ),
                title="TUNE",
            )
            return
        raise usage_error(
            (
                "`ai tune <model>` is deprecated. Use workspace-first commands:\n"
                "  ai tune init <model>\n"
                "  ai tune push\n"
                "  ai tune watch\n"
                "  ai tune status\n"
                "Create a workspace first with: ai tune init <model-slug>"
            ),
            code="tune_command_deprecated",
            request_id=context.request_id,
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_list_command(
    *,
    runtime: CommandRuntime,
    model: str | None,
    status: str | None,
    page: int,
    page_size: int,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_fine_tune_list: Any,
) -> None:
    """List workspace-scoped fine-tune jobs."""
    context = runtime.build_command_context("fine_tune.list", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = client.list_fine_tune_jobs(
                model_slug=model,
                status=status,
                page=page,
                page_size=page_size,
            )
        finally:
            client.close()
        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_fine_tune_list(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )


def fine_tune_get_command(
    *,
    runtime: CommandRuntime,
    job: str,
    gateway: str | None,
    api_key: str | None,
    json_output: bool,
    debug: bool,
    render_fine_tune_job: Any,
) -> None:
    """Get a single fine-tune job."""
    context = runtime.build_command_context("fine_tune.get", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            payload = client.get_fine_tune_job(job_id=job)
        finally:
            client.close()
        result = payload.model_dump()
        if json_output:
            runtime.emit_result(result, json_output=True)
        else:
            render_fine_tune_job(result)
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
