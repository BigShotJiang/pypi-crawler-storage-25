"""Project skill command handlers."""

from __future__ import annotations

from pathlib import Path

from aimp_cli.core.errors import usage_error
from aimp_cli.domain.discovery import find_project_root, list_project_skills

from .common import CommandRuntime, exit_with_error


def skills_list_command(*, runtime: CommandRuntime, json_output: bool, debug: bool) -> None:
    """List project-local skills for the current project."""
    context = runtime.build_command_context("skills.list", debug=debug, json_output=json_output)
    try:
        try:
            project_dir = find_project_root(Path.cwd())
        except RuntimeError as error:
            raise usage_error(
                str(error),
                code="project_not_found",
                request_id=context.request_id,
            ) from error
        project_file, skills = list_project_skills(project_dir)
        if project_file is None and not skills:
            raise usage_error(
                "No project-local skills found for this project",
                code="project_skills_not_found",
                request_id=context.request_id,
            )
        runtime.emit_result(
            {
                "project_root": str(project_dir),
                "project_file": project_file,
                "skills": [entry.model_dump() for entry in skills],
                "request_id": context.request_id,
            },
            json_output=json_output,
            success_message=(
                f"Project root: {project_dir}\n"
                + "Skills: "
                + ", ".join(entry.name for entry in skills if entry.kind == "skill")
            ),
            title="SKILLS",
        )
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
