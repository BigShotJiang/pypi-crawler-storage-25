"""Publish command handlers for model projects."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

from aimp_cli.core.errors import CliError, auth_error, usage_error
from aimp_cli.core.launcher import (
    LauncherOption,
    LauncherSection,
    select_menu,
    select_menu_fallback,
)
from aimp_cli.domain.constants import PUBLISH_CONFIG_FILE_NAME
from aimp_cli.domain.models import CliPublishResult
from aimp_cli.domain.project import load_project_config, write_project_config
from aimp_cli.operations.publish.config import (
    ensure_publish_config,
    format_hardware_tier_description,
)
from aimp_cli.operations.publish.core import (
    cancel_publish_build_group,
    publish_model_by_slug,
    resolve_publish_build_group_result,
)
from aimp_cli.operations.publish.mappers import map_detached_publish_build_group

from .common import CommandRuntime, exit_with_error

_WATCH_EXISTING_BUILD = "watch_existing_build"
_CANCEL_AND_REBUILD = "cancel_and_rebuild"
_KEEP_EXISTING_AND_EXIT = "keep_existing_and_exit"


def _serialize_publish_result(*, result: CliPublishResult, request_id: str) -> dict[str, Any]:
    """Serialize one publish result model for command output rendering."""
    payload = result.model_copy(update={"request_id": request_id})
    return payload.model_dump(exclude_none=True)


def _resolve_hardware_tier(*, hardware: str | None) -> str | None:
    """Resolve one optional deployment hardware tier string."""
    if hardware is None:
        return None
    tier = hardware.strip().lower()
    if not tier:
        raise usage_error("--hardware must be non-empty", code="invalid_hardware_tier")
    return tier


def _rebuild_cli_error(error: CliError, *, hint: str | None = None) -> CliError:
    """Return one copy of a CLI error with an optional hint override."""
    return CliError(
        error.message,
        code=error.code,
        category=error.category,
        exit_code=error.exit_code,
        request_id=error.request_id,
        hint=hint if hint is not None else error.hint,
        retryable=error.retryable,
        http_status=error.http_status,
        extra=error.extra,
    )


def _publish_intent_conflict_hint(existing_job_id: str) -> str:
    """Build one explicit next-step hint for publish intent conflicts."""
    return "\n".join(
        [
            f"Watch the active build: ai jobs watch --type build --job {existing_job_id}",
            f"Cancel the active build: ai jobs cancel --type build --job {existing_job_id}",
            "Start a new build explicitly: ai push --force",
        ]
    )


def _augment_publish_intent_conflict(error: CliError) -> CliError:
    """Attach a user-facing hint to one publish-intent conflict error."""
    if error.code != "publish_build_intent_conflict":
        return error
    existing_job_id = str(error.extra.get("existing_job_id") or "").strip()
    if not existing_job_id or error.hint:
        return error
    return _rebuild_cli_error(
        error,
        hint=_publish_intent_conflict_hint(existing_job_id),
    )


def _select_publish_conflict_action(
    *,
    runtime: CommandRuntime,
    existing_job_id: str,
    existing_status: str,
    existing_stage: str,
) -> str | None:
    """Prompt for one action when publish conflicts with an active build."""
    subtitle_parts = [f"Build {existing_job_id[:8]}"]
    if existing_status:
        subtitle_parts.append(existing_status)
    if existing_stage:
        subtitle_parts.append(existing_stage)
    sections = [
        LauncherSection(
            title="Publish Conflict",
            options=[
                LauncherOption(
                    key=_WATCH_EXISTING_BUILD,
                    label="Watch Existing Build",
                    description="Attach to the active remote build and wait for its final result.",
                    handler=lambda: None,
                ),
                LauncherOption(
                    key=_CANCEL_AND_REBUILD,
                    label="Cancel And Rebuild",
                    description=(
                        "Cancel the active build, then submit a fresh publish with --force."
                    ),
                    handler=lambda: None,
                ),
                LauncherOption(
                    key=_KEEP_EXISTING_AND_EXIT,
                    label="Keep Existing And Exit",
                    description=(
                        "Leave the current remote build running and return without resubmitting."
                    ),
                    handler=lambda: None,
                ),
            ],
        )
    ]
    try:
        selected = select_menu(
            sections,
            show_header=False,
            title="Publish Conflict",
            subtitle=" · ".join(subtitle_parts),
        )
    except Exception:
        selected = select_menu_fallback(
            sections,
            console=runtime.console,
            show_header=False,
            title="Publish Conflict",
            subtitle=" · ".join(subtitle_parts),
        )
    return selected.key if selected is not None else None


def _build_existing_publish_success_message(result: CliPublishResult) -> str:
    """Build one success message for keeping an existing remote build alive."""
    lines = [
        "Existing remote build kept running.",
        f"Slug: {result.slug}",
        f"Version: {result.version or 'unknown'}",
        f"Build group: {result.publish_build_group_id or 'unknown'}",
    ]
    if result.phase:
        lines.append(f"Phase: {result.phase}")
    if result.current_step_message:
        lines.append(f"Current step: {result.current_step_message}")
    if result.publish_build_group_id:
        lines.append(f"Watch: ai jobs watch --type build --job {result.publish_build_group_id}")
    return "\n".join(lines)


def _publish_config_success_message(configure_setting: str | None) -> str:
    """Build one accurate configure-only success message."""
    if configure_setting == "review":
        return "Reviewed project settings. No files were changed."
    if configure_setting == "hardware":
        return "Updated hardware selection in .aimp/project.toml."
    if configure_setting:
        return "Updated project settings."
    return (
        f"Updated {PUBLISH_CONFIG_FILE_NAME}.\n"
        "Hardware is selected on first `ai push`, then remembered in .aimp/project.toml."
    )


def _persist_selected_hardware_tier(*, project_dir: Path, selected_hardware_tier: str) -> None:
    """Persist one normalized deployment hardware tier in project config when it changes."""
    project_config = load_project_config(project_dir)
    if project_config.publish.selected_hardware_tier == selected_hardware_tier:
        return
    project_config.publish.selected_hardware_tier = selected_hardware_tier
    write_project_config(project_dir, project_config)


def _available_hardware_tier_ids(hardware_tiers: list[Any]) -> set[str]:
    """Return normalized hardware tier ids from one publish metadata catalog."""
    return {
        str(tier.id).strip().lower()
        for tier in hardware_tiers
        if str(getattr(tier, "id", "")).strip()
    }


def _format_hardware_tier_choices(hardware_tiers: list[Any]) -> str:
    """Render one compact list of valid hardware ids for errors."""
    return ", ".join(sorted(_available_hardware_tier_ids(hardware_tiers)))


def _reject_unavailable_hardware_tier(
    *,
    requested_hardware_tier: str,
    hardware_tiers: list[Any],
    code: str,
) -> None:
    available = _format_hardware_tier_choices(hardware_tiers)
    suffix = f" Available hardware: {available}" if available else ""
    raise usage_error(
        f"Deployment hardware '{requested_hardware_tier}' is not available.{suffix}",
        code=code,
    )


def _prompt_for_hardware_tier(
    *,
    runtime: CommandRuntime,
    hardware_tiers: list[Any],
    subtitle: str,
) -> str:
    """Prompt for one deployment hardware tier from the current publish catalog."""
    options = [
        LauncherOption(
            key=tier.id,
            label=tier.id,
            description=format_hardware_tier_description(tier),
            handler=lambda: None,
        )
        for tier in hardware_tiers
    ]
    sections = [LauncherSection(title="Hardware Tiers", options=options)]
    try:
        selected = select_menu(
            sections,
            show_header=False,
            title="Select Hardware",
            subtitle=subtitle,
        )
    except Exception:
        selected = select_menu_fallback(
            sections,
            console=runtime.console,
            show_header=False,
            title="Select Hardware",
            subtitle=subtitle,
        )
    if selected is None:
        raise usage_error(
            "Hardware selection cancelled",
            code="hardware_selection_cancelled",
        )
    return str(selected.key).strip().lower()


def _resolve_publish_hardware_tier(
    *,
    runtime: CommandRuntime,
    client: Any,
    project_dir: Path,
    hardware: str | None,
    json_output: bool,
) -> str:
    """Resolve one publish hardware tier from override, saved project state, or prompt."""
    selected_hardware_tier = _resolve_hardware_tier(hardware=hardware)
    metadata = client.get_publish_metadata()
    if not metadata.hardware_tiers:
        raise usage_error(
            "No hardware tiers are currently available for publish.",
            code="publish_hardware_catalog_empty",
        )
    available_hardware_tier_ids = _available_hardware_tier_ids(metadata.hardware_tiers)
    if selected_hardware_tier:
        if selected_hardware_tier not in available_hardware_tier_ids:
            _reject_unavailable_hardware_tier(
                requested_hardware_tier=selected_hardware_tier,
                hardware_tiers=metadata.hardware_tiers,
                code="selected_hardware_tier_unavailable",
            )
        _persist_selected_hardware_tier(
            project_dir=project_dir,
            selected_hardware_tier=selected_hardware_tier,
        )
        return selected_hardware_tier

    project_config = load_project_config(project_dir)
    saved_hardware_tier = project_config.publish.selected_hardware_tier
    if saved_hardware_tier and saved_hardware_tier in available_hardware_tier_ids:
        return saved_hardware_tier

    if json_output or not runtime.has_interactive_terminal():
        if saved_hardware_tier:
            available = _format_hardware_tier_choices(metadata.hardware_tiers)
            raise usage_error(
                f"Saved deployment hardware '{saved_hardware_tier}' is no longer available. "
                f"Available hardware: {available}",
                code="selected_hardware_tier_unavailable",
            )
        raise usage_error(
            (
                "Deployment hardware selection is required for this project. "
                "Run `ai push --hardware <sku>` once to save a default device. "
                f"Available hardware: {_format_hardware_tier_choices(metadata.hardware_tiers)}"
            ),
            code="selected_hardware_tier_missing",
        )

    subtitle = "Choose the deployment hardware for this publish."
    if saved_hardware_tier:
        subtitle = (
            f"Saved hardware '{saved_hardware_tier}' is unavailable. "
            "Choose a new deployment hardware tier."
        )
    selected_hardware_tier = _prompt_for_hardware_tier(
        runtime=runtime,
        hardware_tiers=metadata.hardware_tiers,
        subtitle=subtitle,
    )
    _persist_selected_hardware_tier(
        project_dir=project_dir,
        selected_hardware_tier=selected_hardware_tier,
    )
    return selected_hardware_tier


def _run_publish_with_conflict_resolution(
    *,
    runtime: CommandRuntime,
    client: Any,
    context: Any,
    project_dir: Path,
    selected_hardware_tier: str,
    python_bin: str | None,
    parallel: int,
    verbose: bool,
    force: bool,
    detach: bool,
    json_output: bool,
) -> tuple[CliPublishResult, str | None]:
    """Run publish and resolve active-build conflicts explicitly at the CLI layer."""
    try:
        return (
            runtime.run_publish(
                project_dir=project_dir,
                gateway=client,
                context=context,
                selected_hardware_tier=selected_hardware_tier,
                python_bin=python_bin,
                parallel=parallel,
                verbose=verbose,
                force=force,
                detach=detach,
            ),
            None,
        )
    except CliError as error:
        augmented_error = _augment_publish_intent_conflict(error)
        if (
            augmented_error.code != "publish_build_intent_conflict"
            or json_output
            or not runtime.has_interactive_terminal()
        ):
            raise augmented_error from error

        existing_job_id = str(augmented_error.extra.get("existing_job_id") or "").strip()
        existing_status = str(augmented_error.extra.get("existing_status") or "").strip()
        existing_stage = str(augmented_error.extra.get("existing_stage") or "").strip()
        if not existing_job_id:
            raise augmented_error from error

        selected_action = _select_publish_conflict_action(
            runtime=runtime,
            existing_job_id=existing_job_id,
            existing_status=existing_status,
            existing_stage=existing_stage,
        )
        if selected_action is None:
            raise usage_error(
                f"Publish canceled. Active build {existing_job_id[:8]} is still running.",
                code="publish_conflict_resolution_cancelled",
                request_id=context.request_id,
                hint=_publish_intent_conflict_hint(existing_job_id),
                extra={"existing_job_id": existing_job_id},
            ) from error

        if selected_action == _WATCH_EXISTING_BUILD:
            build_group = client.get_publish_build_group(existing_job_id)
            return (
                resolve_publish_build_group_result(
                    gateway=client,
                    build_group=build_group,
                    context=context,
                ),
                None,
            )

        if selected_action == _CANCEL_AND_REBUILD:
            cancel_publish_build_group(
                gateway=client,
                job_id=existing_job_id,
                poll_interval_seconds=1.0,
            )
            try:
                return (
                    runtime.run_publish(
                        project_dir=project_dir,
                        gateway=client,
                        context=context,
                        selected_hardware_tier=selected_hardware_tier,
                        python_bin=python_bin,
                        parallel=parallel,
                        verbose=verbose,
                        force=True,
                        detach=detach,
                    ),
                    None,
                )
            except CliError as retry_error:
                raise _augment_publish_intent_conflict(retry_error) from retry_error

        build_group = client.get_publish_build_group(existing_job_id)
        active_statuses = {"queued", "running"}
        if str(build_group.status or "").strip().lower() not in active_statuses:
            return (
                resolve_publish_build_group_result(
                    gateway=client,
                    build_group=build_group,
                    context=context,
                ),
                None,
            )
        detached_result = map_detached_publish_build_group(
            build_group=build_group,
            request_id=context.request_id,
        )
        return detached_result, _build_existing_publish_success_message(detached_result)


def run_publish_command(
    *,
    runtime: CommandRuntime,
    gateway: str | None,
    api_key: str | None,
    slug: str | None,
    parallel: int,
    hardware: str | None,
    verbose: bool,
    json_output: bool,
    debug: bool,
    python_bin: str | None,
    configure_only: bool,
    force: bool,
    detach: bool,
    build_publish_success_message: Callable[[CliPublishResult], str],
    configure_setting: str | None = None,
) -> None:
    """Run unified publish flow or configure-only flow."""
    context = runtime.build_command_context("publish", debug=debug, json_output=json_output)
    try:
        auth_context = runtime.resolve_auth_context(gateway=gateway, api_key=api_key)
        if not auth_context.api_key:
            raise auth_error(
                "Not authenticated. Run: ai login",
                code="not_authenticated",
                request_id=context.request_id,
            )
        client = runtime.gateway_client_cls(auth_context, context)
        try:
            if slug is not None:
                normalized_slug = slug.strip()
                if not normalized_slug:
                    raise usage_error(
                        "--slug must be non-empty",
                        code="invalid_publish_slug",
                        request_id=context.request_id,
                    )
                if configure_only:
                    raise usage_error(
                        "--configure cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if python_bin is not None:
                    raise usage_error(
                        "--python cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if force:
                    raise usage_error(
                        "--force cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if verbose:
                    raise usage_error(
                        "--verbose cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if detach:
                    raise usage_error(
                        "--detach cannot be used with --slug",
                        code="invalid_publish_mode",
                        request_id=context.request_id,
                    )
                if not json_output and runtime.has_interactive_terminal():
                    confirmed = runtime.confirm_action(
                        f"Publish '{normalized_slug}' now?",
                        console=runtime.console,
                        confirm_label="Publish model",
                        cancel_label="Keep private",
                        confirm_description=(
                            "Make this existing model public using the normal publish flow."
                        ),
                        cancel_description="Leave the model private and exit.",
                        title="Publish Existing Model",
                        subtitle=f"Model slug: {normalized_slug}",
                    )
                    if not confirmed:
                        raise usage_error(
                            f"Publish canceled. Model '{normalized_slug}' remains private.",
                            code="publish_canceled_by_user",
                            request_id=context.request_id,
                        )
                result = publish_model_by_slug(gateway=client, slug=normalized_slug)
                payload = _serialize_publish_result(result=result, request_id=context.request_id)
                runtime.emit_result(
                    payload,
                    json_output=json_output,
                    success_message=build_publish_success_message(result),
                    title="PUBLISH",
                )
                return

            publish_config = ensure_publish_config(
                project_dir=Path.cwd(),
                gateway=client,
                configure_only=configure_only,
                console=runtime.console,
                interactive_terminal=runtime.has_interactive_terminal(),
                configure_setting=configure_setting,
            )
            if configure_only:
                runtime.emit_result(
                    {
                        "publish_config_file": PUBLISH_CONFIG_FILE_NAME,
                        "studio_name": publish_config.studio.name,
                        "developer_margin": publish_config.pricing.get("developer_margin", 0),
                        "request_id": context.request_id,
                    },
                    json_output=json_output,
                    success_message=_publish_config_success_message(configure_setting),
                    title="PUBLISH CONFIG",
                )
                return

            selected_hardware_tier = _resolve_publish_hardware_tier(
                runtime=runtime,
                client=client,
                project_dir=Path.cwd(),
                hardware=hardware,
                json_output=json_output,
            )

            result, success_message_override = _run_publish_with_conflict_resolution(
                runtime=runtime,
                client=client,
                context=context,
                project_dir=Path.cwd(),
                selected_hardware_tier=selected_hardware_tier,
                python_bin=python_bin,
                parallel=parallel,
                verbose=verbose,
                force=force,
                detach=detach,
                json_output=json_output,
            )
            runtime.emit_result(
                _serialize_publish_result(result=result, request_id=context.request_id),
                json_output=json_output,
                success_message=success_message_override or build_publish_success_message(result),
                title="PUBLISH",
            )
        finally:
            client.close()
    except Exception as error:
        exit_with_error(
            error,
            json_output=json_output,
            request_id=context.request_id,
            context=context,
        )
