"""Shared helpers for CLI subcommands."""

from __future__ import annotations

import argparse
import logging
import sys

from sylvac.scanner import scan as _scan

logger = logging.getLogger(__name__)


def add_json_arg(parser: argparse.ArgumentParser) -> None:
    """Add --json flag to *parser*."""
    parser.add_argument(
        "-j", "--json",
        action="store_true",
        help="Output as JSON instead of human-readable text.",
    )


def add_connection_args(parser: argparse.ArgumentParser) -> None:
    """Add --timeout, --prefix, and --address to *parser*."""
    parser.add_argument(
        "-t", "--timeout", type=float, default=10.0,
        help="BLE scan timeout in seconds (default: 10)",
    )
    parser.add_argument(
        "-p", "--prefix", default="SY",
        help="Device name prefix to filter during scan (default: SY)",
    )
    parser.add_argument(
        "-a", "--address",
        help="Skip scanning and connect directly to this BLE address",
    )


def setup_logging(args: argparse.Namespace) -> None:
    logging.basicConfig(
        level=args.log_level,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
    )

    logging.getLogger("bleak").setLevel(logging.INFO)


async def resolve_address(args: argparse.Namespace) -> str:
    """Return BLE address from args, scanning if --address was not given."""
    if args.address:
        return args.address
    device = await _scan(timeout=args.timeout, name_prefix=args.prefix)
    if device is None:
        logger.error(
            "No Sylvac device found (prefix=%r, timeout=%.1fs).", args.prefix, args.timeout
        )
        sys.exit(1)
    return device.address
