"""``sylvac info`` subcommand — show device identification and status."""

from __future__ import annotations

import argparse
import json
import logging

from sylvac import Device
from sylvac.cli._common import add_connection_args, add_json_arg, resolve_address

logger = logging.getLogger(__name__)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    p = subparsers.add_parser(
        "info",
        help="Show device identification and current status.",
    )
    add_connection_args(p)
    add_json_arg(p)
    p.set_defaults(func=run)


async def run(args: argparse.Namespace) -> None:
    address = await resolve_address(args)

    async with Device(address) as dev:
        data = {
            **await dev.get_all_info(),
            **await dev.get_all_settings(),
        }

        if args.json:
            print(json.dumps(data, indent=2, default=str), flush=True)
        else:
            battery_level = data.get("battery_level")
            level_str = f"{battery_level}%" if battery_level is not None else "—"

            print("Device Address:     ", data["address"])
            print("MAC Address:        ", data["bluetooth_mac"] or "—")
            print("Manufacturer:       ", data["manufacturer"] or "—")
            print("Model number:       ", data["model_number"] or "—")
            print("Serial number:      ", data["serial_number"] or "—")
            print("Firmware revision:  ", data["firmware_revision"] or "—")
            print("Hardware revision:  ", data["hardware_revision"] or "—")
            print("ID:                 ", data["id"] or "—")
            print("Number:             ", data["number"] or "—")
            print("Version:            ", data["version"] or "—")
            print("Battery state:      ", data["battery"] or "—")
            print("Battery level:      ", level_str)
            print("Unit:               ", data["unit"])
            print("Resolution:         ", data["resolution"])
            print("Mode:               ", data["mode"])
            print("Resolution mode:    ", data["resolution_mode"] or "—")
            print("Preset value:       ", data["preset"] or "—")
            print("Display status:     ", data["display"] or "—")
            print("Economy mode:       ", data["eco"])
            print("Last calibration:   ", data["last_calibration"] or "—")
            print("Next calibration:   ", data["next_calibration"] or "—")
            print("Favorites:          ", data["favorites"] or "—")
            print("Current value:      ", data["value"], data["unit"])
