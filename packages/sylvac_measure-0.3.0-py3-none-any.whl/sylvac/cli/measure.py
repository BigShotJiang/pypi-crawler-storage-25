"""``sylvac measure`` subcommand — take one or more measurements."""

from __future__ import annotations

import argparse
import json
import logging

from sylvac import Device, MeasuringMode
from sylvac.cli._common import add_connection_args, add_json_arg, resolve_address

logger = logging.getLogger(__name__)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    p = subparsers.add_parser(
        "measure",
        help="Take a measurement. Prints a single value by default; "
             "use -f/--follow to stream continuously.",
    )
    add_connection_args(p)
    add_json_arg(p)
    p.add_argument(
        "-f", "--follow",
        action="store_true",
        help="Take multiple measurements until Ctrl-C is pressed.",
    )
    p.add_argument(
        "-b", "--button",
        action="store_true",
        help="Capture measurements via data button press.",
    )
    p.add_argument(
        "-l", "--live",
        action="store_true",
        help="Capture live measurements continuously.",
    )
    p.add_argument(
        "-r", "--raw",
        action="store_true",
        help="Only print the numeric measurement value. Skips units and other info.",
    )
    p.set_defaults(func=run)


async def run(args: argparse.Namespace) -> None:
    address = await resolve_address(args)

    # If neither source is selected, enable both
    use_both = not args.button and not args.live
    button = args.button or use_both
    live = args.live or use_both

    sources = []
    if button:
        sources.append("button")
    if live:
        sources.append("live")
    logger.debug("Taking measurements from: %s. Press Ctrl-C to stop.", ", ".join(sources))

    async with Device(address) as dev:
        async for measurement in dev.measurements(button=button, live=live):
            if args.json:
                print(json.dumps({
                    "value":      measurement.value,
                    "unit":       str(measurement.unit),
                    "resolution": measurement.resolution,
                    "mode":       str(measurement.mode),
                    "manual":     measurement.manual,
                }), flush=True)
            else:
                value = measurement.format()
                line = str(value)
                if not args.raw:
                    line += f" {measurement.unit}"
                    if measurement.mode != MeasuringMode.NORMAL:
                        line += f" [{measurement.mode}]"
                    if measurement.manual and args.live:
                        line += " (button)"

                print(line, flush=True)

            if not args.follow:
                break
