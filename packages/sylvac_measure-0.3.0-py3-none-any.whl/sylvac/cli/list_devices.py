"""``sylvac list`` subcommand — scan for available Sylvac BLE devices."""

from __future__ import annotations

import argparse
import logging

from sylvac.scanner import scan_all

logger = logging.getLogger(__name__)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    p = subparsers.add_parser(
        "list",
        help="Scan for available Sylvac BLE devices.",
    )
    p.add_argument(
        "--timeout", type=float, default=10.0,
        help="Scan duration in seconds (default: 10)",
    )
    p.add_argument(
        "--prefix", default="SY",
        help="Device name prefix to filter (default: SY)",
    )
    p.set_defaults(func=run)


async def run(args: argparse.Namespace) -> None:
    found = False
    async for device in scan_all(timeout=args.timeout, name_prefix=args.prefix):
        print(f"{device.address} {device.name}", flush=True)
        found = True
    if not found:
        logger.warning("No Sylvac devices found.")
