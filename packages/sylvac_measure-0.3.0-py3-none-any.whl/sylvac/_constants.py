"""GATT UUIDs and protocol lookup tables for Sylvac BLE instruments.

Protocol reference:
  Sylvac SA, "Bluetooth Profile Specifications", MEM-PM 292-1806-01
  https://github.com/SylvacDev/BluetoothDevTools/blob/main/
  Sylvac-Custom-Bluetooth-GATT-Profiles/
  MEM-PM%20292-1806-01-Bluetooth%20Profile%20Specifications.pdf

  - SDS (Simple Data Service):
      standard BLE base UUID 0000XXXX-0000-1000-8000-00805F9B34FB
  - SMS (Sylvac Metrology Service):
      custom base UUID C1B2XXXX-CAAF-6D0E-4C33-7DAE30052840
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# SDS — Simple Data Service (standard BLE base UUID)
# ---------------------------------------------------------------------------
SDS_MEASUREMENT_UUID = "00005020-0000-1000-8000-00805f9b34fb"  # Notify, SINT32 LE
SDS_PARAMETERS_UUID = "00005021-0000-1000-8000-00805f9b34fb"   # Notify, UINT16 bitmap

# ---------------------------------------------------------------------------
# SMS — Sylvac Metrology Service
# Custom base UUID: C1B2XXXX-CAAF-6D0E-4C33-7DAE30052840
# ---------------------------------------------------------------------------
SMS_SERVICE_UUID = "c1b25000-caaf-6d0e-4c33-7dae30052840"
SMS_DATASEND_UUID = "c1b25010-caaf-6d0e-4c33-7dae30052840"      # Indicate (data button)
SMS_REMOTEREQUEST_UUID = "c1b25012-caaf-6d0e-4c33-7dae30052840"  # Write w/o response
SMS_REMOTERESPONSE_UUID = "c1b25013-caaf-6d0e-4c33-7dae30052840"  # Notify

# ---------------------------------------------------------------------------
# DIS — Device Information Service (standard BLE base UUID)
# ---------------------------------------------------------------------------
DIS_MODEL_NUMBER_UUID = "00002a24-0000-1000-8000-00805f9b34fb"     # Read
DIS_SERIAL_NUMBER_UUID = "00002a25-0000-1000-8000-00805f9b34fb"    # Read
DIS_FIRMWARE_REV_UUID = "00002a26-0000-1000-8000-00805f9b34fb"     # Read
DIS_HARDWARE_REV_UUID = "00002a27-0000-1000-8000-00805f9b34fb"     # Read
DIS_MANUFACTURER_UUID = "00002a29-0000-1000-8000-00805f9b34fb"     # Read

# ---------------------------------------------------------------------------
# BAS — Battery Service (standard BLE base UUID)
# ---------------------------------------------------------------------------
BAS_SERVICE_UUID = "0000180f-0000-1000-8000-00805f9b34fb"          # Battery Service
BAS_BATTERY_LEVEL_UUID = "00002a19-0000-1000-8000-00805f9b34fb"    # Read/Notify

# ---------------------------------------------------------------------------
# Standard descriptors
# ---------------------------------------------------------------------------

# Characteristic Presentation Format Descriptor
CPFD_UUID = "00002904-0000-1000-8000-00805f9b34fb"

# Sentinel returned by READ on measurement characteristic (notifications required)
MEASUREMENT_SENTINEL = 0x7FFFFFFF

# Device name prefixes used in BLE advertisement (spec Table 1)
DEVICE_NAME_PREFIXES = ("SY", "MTY")

# ---------------------------------------------------------------------------
# SDS Parameters characteristic bitmaps (UUID 0x5021)
# ---------------------------------------------------------------------------

# Bits 15-12: unit
UNIT_MAP: dict[int, str] = {
    0b0000: "?",
    0b0001: "mm",
    0b0010: "in",
    0b0100: "rad",
    0b0101: "°",
    0b0110: "°'",
}

# Bits 11-8: resolution (SI units)
RES_MAP: dict[int, float | None] = {
    0b0000: None,
    0b0001: 1e-4,  # 100 µm
    0b0010: 1e-5,  # 10 µm  (0.01 mm)
    0b0011: 1e-6,  # 1 µm
    0b0100: 1e-7,  # 0.1 µm
    0b0101: 1e-8,  # 0.01 µm
}
