"""Device: async context manager for a connected Sylvac BLE instrument.

Specifications:
  - Sylvac SA, "Bluetooth Profile Specifications", MEM-PM 292-1806-01
    https://github.com/SylvacDev/BluetoothDevTools/blob/main/
    Sylvac-Custom-Bluetooth-GATT-Profiles/
    MEM-PM%20292-1806-01-Bluetooth%20Profile%20Specifications.pdf
  - Sylvac SA, "SDS Specification", SPE-PM 292-1744-01
    https://github.com/SylvacDev/BluetoothDevTools/blob/main/
    Sylvac-Custom-Bluetooth-GATT-Profiles/Spec/
    SPE-PM%20292-1744-01%20SDS%20Specification.pdf
  - Sylvac SA, "SMS Specification", SPE-PM 292-1746-01
    https://github.com/SylvacDev/BluetoothDevTools/blob/main/
    Sylvac-Custom-Bluetooth-GATT-Profiles/Spec/
    SPE-PM%20292-1746-01%20SMS%20Specification.pdf
"""

from __future__ import annotations

import asyncio
import logging
import struct
from collections.abc import AsyncIterator, Callable
from datetime import datetime

from aiostream import stream
from bleak import BleakClient, BleakError
from bleak.backends.characteristic import BleakGATTCharacteristic

from sylvac._constants import (
    BAS_BATTERY_LEVEL_UUID,
    CPFD_UUID,
    DIS_FIRMWARE_REV_UUID,
    DIS_HARDWARE_REV_UUID,
    DIS_MANUFACTURER_UUID,
    DIS_MODEL_NUMBER_UUID,
    DIS_SERIAL_NUMBER_UUID,
    SDS_MEASUREMENT_UUID,
    SDS_PARAMETERS_UUID,
    SMS_DATASEND_UUID,
    SMS_REMOTEREQUEST_UUID,
    SMS_REMOTERESPONSE_UUID,
)
from sylvac._protocol import (
    BatteryState,
    DeviceInfo,
    DisplayStatus,
    Measurement,
    MeasuringMode,
    ResolutionMode,
    Unit,
    decode_measurement,
    decode_parameters,
    si_to_display,
    resolution_in_display_unit,
    INPUT_DATE_FORMAT,
)

logger = logging.getLogger(__name__)


class Device:
    """Async context manager for a Sylvac BLE instrument.

    Usage::

        async with Device("AA:BB:CC:DD:EE:FF") as device:
            async for measurement in device.measurements():
                print(measurement.format())

    The ``measurements()`` async generator yields a :class:`~sylvac._protocol.Measurement`
    for every notification received from the SDS Measurement characteristic.
    It runs until the connection is lost or the generator is closed.
    """

    def __init__(self, address: str) -> None:
        self._address = address
        self._client: BleakClient | None = None

        # Instrument state, updated by Parameter notifications
        self._unit: Unit = Unit.MM
        self._resolution: float | None = 1e-5  # Default: 10 µm
        self._mode: MeasuringMode = MeasuringMode.NORMAL
        self._exponent: int = -9  # Default: raw value in nanometers

        self._queue: asyncio.Queue[Measurement] = asyncio.Queue(maxsize=100)
        self._parameters_received: asyncio.Event = asyncio.Event()

        # SMS RemoteResponse accumulator: chunks arrive without \r until complete
        self._response_buf: str = ""
        self._response_queue: asyncio.Queue[str] = asyncio.Queue(maxsize=100)

        # SMS DataSend queue: triggered when user presses data button
        self._datasend_queue: asyncio.Queue[Measurement] = asyncio.Queue(maxsize=100)

    # ------------------------------------------------------------------
    # Async context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "Device":
        self._client = BleakClient(self._address)
        logger.debug("Connecting to %s…", self._address)
        await self._client.connect()
        logger.debug("Connected.")
        await self._setup()
        return self

    async def __aexit__(self, *_args) -> None:
        if self._client and self._client.is_connected:
            await self._client.disconnect()
            logger.debug("Disconnected from %s.", self._address)
        self._client = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def address(self) -> str:
        return self._address

    @property
    def unit(self) -> Unit:
        """Current display unit."""
        return self._unit

    @property
    def resolution(self) -> float | None:
        """Smallest measurement increment in SI units, or None if unknown."""
        return self._resolution

    @property
    def mode(self) -> MeasuringMode:
        """Current measuring mode."""
        return self._mode

    async def get_measurement(self) -> float | None:
        """Get a single measurement from the instrument."""
        value = await self._query()
        if value is None:
            return None
        return float(value)

    async def get_unit(self) -> Unit | None:
        """Query the instrument for its current display unit.

        Returns the current configured unit.
        """
        unit = await self._query("UNI")
        if unit is None:
            return None
        return Unit(unit)

    async def set_unit(self, unit: Unit) -> str | None:
        """Set the display unit.

        Returns the instrument's response, or None if timeout.
        """
        if unit not in [Unit.MM, Unit.INCH]:
            raise ValueError(f"Invalid unit {unit!r}. Valid options: MM, INCH")

        return await self.send_command(unit.value.upper())

    async def set_unit_lock(self, locked: bool) -> str | None:
        """Lock or unlock the unit change function (``UNI0`` / ``UNI1``)."""
        return await self.send_command("UNI0" if locked else "UNI1")

    async def get_resolution(self) -> ResolutionMode | None:
        """Get the current resolution mode from the instrument."""
        response = await self._query("RES")
        if response is None:
            return None
        return ResolutionMode(response)

    async def set_resolution(self, resolution: ResolutionMode) -> str | None:
        """Set the resolution mode on the instrument.

        Returns the instrument's response, or None if timeout.
        """
        return await self.send_command(resolution.value)

    async def get_bt_mac(self) -> str | None:
        """Get the Bluetooth MAC address of the instrument (``MAC?``).

        Returns the MAC address string (e.g. "AA:BB:CC:DD:EE:FF").
        """
        return await self._query("MAC")

    async def set_bt(self, enabled: bool) -> str | None:
        """Enable or disable Bluetooth (``BT1`` / ``BT0``)."""
        return await self.send_command("BT1" if enabled else "BT0")

    async def get_output(self) -> bool | None:
        """Query whether continuous data output is enabled (``OUT?``).

        Returns ``True`` if enabled, ``False`` if disabled, or ``None`` on timeout.
        """
        response = await self._query("OUT")
        if response is None:
            return None
        return response == "OUT1"

    async def set_output(self, enabled: bool) -> str | None:
        """Enable or disable continuous data output (``OUT1`` / ``OUT0``)."""
        return await self.send_command("OUT1" if enabled else "OUT0")

    async def get_battery_state(self) -> BatteryState | None:
        """Get the battery state from the instrument via SMS command.

        Returns BatteryState.OK or BatteryState.LOW based on the instrument's
        response to the BAT? command.
        """
        response = await self._query("BAT")
        if response is None:
            return None
        return BatteryState(response)

    async def get_battery_level(self) -> int | None:
        """Get the battery level percentage from the BLE Battery Service.

        Reads the standard BLE Battery Level characteristic (0x2A19) from
        the Battery Service (0x180F). Returns the battery level as a
        percentage (0-100), or None if the characteristic is not available
        or cannot be read.

        This provides more granular battery information than get_battery_state(),
        which only returns OK or LOW status via SMS.
        """
        if self._client is None or not self._client.is_connected:
            raise RuntimeError("Device is not connected.")

        try:
            char = self._client.services.get_characteristic(BAS_BATTERY_LEVEL_UUID)
            if char is None or "read" not in char.properties:
                logger.debug("Battery Level characteristic not available")
                return None

            data = await self._client.read_gatt_char(BAS_BATTERY_LEVEL_UUID)
            if not data:
                return None

            # Battery Level is a single uint8 value (0-100%)
            level = data[0]
            logger.debug("Battery level: %d%%", level)
            return level
        except (BleakError, asyncio.TimeoutError) as exc:
            logger.debug("Could not read battery level: %s", exc)
            return None

    async def get_number(self) -> str | None:
        """Get the instrument number."""
        number = await self._query("NUM")
        if number is None:
            return None

        return number.removeprefix("NUM").strip()

    async def set_number(self, number: str) -> str | None:
        """Set the instrument number (``NUM XXXXX``).

        *number* is an arbitrary string that may be used to identify the
        instrument; it is printed on the device's display when receiving a
        measurement command. The instrument may ignore this command if it doesn't
        support setting the number.

        Returns the instrument's response, or None if timeout.
        """
        return await self.send_command(f"NUM {number}")

    async def get_id(self) -> str | None:
        """Get the instrument identification string from the instrument, e.g. ``"SY276"``."""
        return await self._query("ID")

    async def get_version(self) -> str | None:
        """Get the firmware version and date from the instrument, e.g. ``"V1.24 11.10.2017"``."""
        return await self._query("VER")

    async def get_last_calibration_date(self) -> datetime | None:
        """Get the date of the last calibration from the instrument.

        Returns a :class:`~datetime.datetime` (time set to midnight), or
        ``None`` if the instrument doesn't respond or the date is unset.
        """
        return await self._query_date("LCAL")

    async def get_next_calibration_date(self) -> datetime | None:
        """Get the date of the next calibration from the instrument.

        Returns a :class:`~datetime.datetime` (time set to midnight), or
        ``None`` if the instrument doesn't respond or the date is unset.
        """
        return await self._query_date("NCAL")

    async def set_last_calibration_date(self, date: datetime) -> str | None:
        """Set the date of the last calibration on the instrument (``LCAL JJ.MM.[AA]AA``).

        *date* is a :class:`~datetime.datetime` object; only the day, month, and year
        are used. The instrument may ignore this command if it doesn't support setting
        the calibration date.

        Returns the instrument's response, or None if timeout.
        """
        date_str = date.strftime("%d.%m.%Y")
        return await self.send_command(f"LCAL {date_str}")

    async def set_next_calibration_date(self, date: datetime) -> str | None:
        """Set the date of the next calibration on the instrument (``NCAL JJ.MM.[AA]AA``).

        *date* is a :class:`~datetime.datetime` object; only the day, month, and year
        are used. The instrument may ignore this command if it doesn't support setting
        the calibration date.

        Returns the instrument's response, or None if timeout.
        """
        date_str = date.strftime("%d.%m.%Y")
        return await self.send_command(f"NCAL {date_str}")

    async def get_preset(self) -> float | None:
        """Get the current preset value (``PRE?``), e.g. ``"+001.234"``."""
        value = await self._query("PRE")
        if value is None:
            return None
        return float(value)

    async def set_preset(self, value: float) -> str | None:
        """Set the preset value (``PRE JJ.JJJ``), e.g. ``"PRE +001.234"``.

        Returns the instrument's response, or None if timeout.
        """
        return await self.send_command(f"PRE {value}")

    async def get_display_status(self) -> DisplayStatus | None:
        """Get the display freeze status from the instrument."""
        response = await self._query("STO")
        if response is None:
            return None
        return DisplayStatus(response)

    async def set_display_status(self, frozen: bool) -> str | None:
        """Freeze or unfreeze the display (``STO1`` / ``STO0``)."""
        return await self.send_command("STO1" if frozen else "STO0")

    async def get_eco_mode(self) -> bool | None:
        """Query the economy mode state (``ECO?``).

        Returns ``True`` if enabled, ``False`` if disabled, or ``None`` on timeout.
        """
        response = await self._query("ECO")
        if response is None:
            return None
        return response == "ECO1"

    async def set_eco_mode(self, enabled: bool) -> str | None:
        """Enable or disable economy mode (``ECO1`` / ``ECO0``)."""
        return await self.send_command("ECO1" if enabled else "ECO0")

    async def get_favorites(self) -> str | None:
        """Query the favorites function assignment (``FCT?``)."""
        return await self._query("FCT")

    async def standby(self) -> None:
        """Put the instrument into standby mode."""

        await self._unsubscribe_all()
        await self.send_command("SBY", timeout=1)
        self._client = None

    async def get_standby_timeout(self) -> int | None:
        """Query the standby timeout (``SBY?``).

        Returns the number of minutes of inactivity before the instrument enters
        standby mode, or None if timeout.
        """
        to = await self._query("SBY")
        if to is None:
            return None
        try:
            return int(to.removeprefix("SBY"))
        except ValueError:
            logger.warning("Could not parse standby timeout response %r", to)
            return None

    async def set_standby_timeout(self, minutes: int) -> str | None:
        """Set the standby timeout (``SBY XX``).

        *minutes* is the number of minutes of inactivity before the instrument
        enters standby mode. Setting it to 0 disables automatic standby.

        Returns the instrument's response, or None if timeout.
        """

        return await self.send_command(f"SBY {minutes}")

    async def poweroff(self) -> None:
        """Put the instrument into sleep mode to save battery.

        This is equivalent to sending the "OFF" command, but it doesn't wait
        for a response (which may not arrive if the device goes to sleep too
        quickly).
        """
        await self.send_command("OFF", timeout=0)
        await asyncio.sleep(0.5)

    async def reset(self) -> None:
        """Reset the instrument (user settings, not power cycle)."""
        await self.send_command("RST", timeout=1)

    async def get_keyboard_lock(self) -> bool | None:
        """Query the keyboard lock state (``KEY?``).

        Returns ``True`` if locked, ``False`` if unlocked, or ``None`` on timeout.
        """
        response = await self._query("KEY")
        if response is None:
            return None
        return response == "KEY0"

    async def set_keyboard_lock(self, locked: bool) -> str | None:
        """Lock or unlock the keyboard (``KEY1`` / ``KEY0``)."""
        return await self.send_command("KEY0" if locked else "KEY1")

    async def measurements(
        self, button: bool = True, live: bool = True
    ) -> AsyncIterator[Measurement]:
        measurements = []

        if button:
            measurements.append(self.button_measurements())
        if live:
            measurements.append(self.live_measurements())

        async with stream.merge(*measurements).stream() as merged_measurements:
            async for measurement in merged_measurements:
                yield measurement

    async def live_measurements(self) -> AsyncIterator[Measurement]:
        """Async generator that yields each measurement notification.

        Runs until the BLE connection is dropped or the generator is closed.
        """
        if self._client is None or not self._client.is_connected:
            raise RuntimeError("Device is not connected; use 'async with Device(...)'")

        await self._subscribe_characteristic(SDS_MEASUREMENT_UUID, self._on_measurement)

        while self._client.is_connected:
            try:
                measurement = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                yield measurement
            except asyncio.TimeoutError:
                continue

        await self._unsubscribe_characteristic(SDS_MEASUREMENT_UUID)

    async def button_measurements(self) -> AsyncIterator[Measurement]:
        """Async generator that yields measurements when data button is pressed.

        This subscribes to the SMS DataSend characteristic (0x5010) which sends
        an indication whenever the user presses the physical data button on the
        instrument. Each indication contains the current measurement value.

        Usage::

            async with Device(address) as dev:
                async for measurement in dev.button_measurements():
                    print(f"Button pressed: {measurement.format()}")

        Runs until the BLE connection is dropped or the generator is closed.
        """
        if self._client is None or not self._client.is_connected:
            raise RuntimeError("Device is not connected; use 'async with Device(...)'")

        await self._subscribe_characteristic(SMS_DATASEND_UUID, self._on_datasend)

        while self._client.is_connected:
            try:
                measurement = await asyncio.wait_for(
                    self._datasend_queue.get(), timeout=1.0
                )
                yield measurement
            except asyncio.TimeoutError:
                continue

        await self._unsubscribe_characteristic(SMS_DATASEND_UUID)

    async def read_device_info(self) -> DeviceInfo:
        """Read device identification from the BLE DIS service (0x180A).

        Returns a :class:`~sylvac._protocol.DeviceInfo` with manufacturer,
        model number, serial number, firmware revision, and hardware revision.
        Fields that the device does not expose are set to ``None``.
        """
        if self._client is None or not self._client.is_connected:
            raise RuntimeError("Device is not connected.")

        async def _read(uuid: str) -> str | None:
            char = self._client.services.get_characteristic(uuid)  # type: ignore[union-attr]
            if char is None or "read" not in char.properties:
                return None
            try:
                data = await self._client.read_gatt_char(uuid)  # type: ignore[union-attr]
                return data.decode("utf-8").strip()
            except (BleakError, asyncio.TimeoutError, UnicodeDecodeError) as exc:
                logger.debug("Could not read DIS characteristic %s: %s", uuid, exc)
                return None

        info = DeviceInfo(
            manufacturer=await _read(DIS_MANUFACTURER_UUID),
            model_number=await _read(DIS_MODEL_NUMBER_UUID),
            serial_number=await _read(DIS_SERIAL_NUMBER_UUID),
            firmware_revision=await _read(DIS_FIRMWARE_REV_UUID),
            hardware_revision=await _read(DIS_HARDWARE_REV_UUID),
        )
        logger.debug("Device info: %s", info)
        return info

    async def get_all_info(self) -> dict:
        """Query all available details from *device* and return as a dict."""
        info = await self.read_device_info()

        return {
            "address": self.address,
            "manufacturer": info.manufacturer,
            "model_number": info.model_number,
            "serial_number": info.serial_number,
            "firmware_revision": info.firmware_revision,
            "hardware_revision": info.hardware_revision,
            "version": await self.get_version(),
            "bluetooth_mac": await self.get_bt_mac(),
            "id": await self.get_id(),
            "battery": await self.get_battery_state(),
            "battery_level": await self.get_battery_level(),
            "resolution": self.resolution,
            "value": await self.get_measurement(),
        }

    async def get_all_settings(self) -> dict:
        last_cal = await self.get_last_calibration_date()
        next_cal = await self.get_next_calibration_date()

        return {
            "number": await self.get_number(),
            "unit": str(self.unit),
            "mode": self.mode,
            "resolution_mode": str(await self.get_resolution()),
            "preset": await self.get_preset(),
            "display": str(await self.get_display_status()),
            "eco": await self.get_eco_mode(),
            "last_calibration": (
                last_cal.strftime(INPUT_DATE_FORMAT) if last_cal else None
            ),
            "next_calibration": (
                next_cal.strftime(INPUT_DATE_FORMAT) if next_cal else None
            ),
            "favorites": await self.get_favorites(),
            "keyboard_lock": await self.get_keyboard_lock(),
            "standby_timeout": await self.get_standby_timeout(),
        }

    async def send_command(self, command: str, timeout: float = 1.0) -> str | None:
        """Send an ASCII command and return the instrument's response.

        Writes *command* to the SMS RemoteRequest characteristic (0x5012) and
        waits for a complete response on the RemoteResponse notify characteristic
        (0x5013). Responses are ASCII text terminated with ``\\r``; multiple BLE
        packets are reassembled automatically.

        Returns the response string (without the trailing ``\\r``), or ``None``
        if no response arrives within *timeout* seconds.

        Example commands: ``"SVR1"`` (saver mode on), ``"UNI?"`` (query unit).
        """
        if self._client is None or not self._client.is_connected:
            raise RuntimeError("Device is not connected.")
        payload = (command + "\r").encode("ascii")
        await self._client.write_gatt_char(
            SMS_REMOTEREQUEST_UUID, payload, response=False
        )
        logger.debug("Sent command: %r", command)

        if timeout == 0:
            return None  # Caller doesn't want to wait for a response

        try:
            response = await asyncio.wait_for(
                self._response_queue.get(), timeout=timeout
            )
            logger.debug("Response: %r", response)
            return response
        except asyncio.TimeoutError:
            logger.warning("No response to command %r within %.1fs", command, timeout)
            return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _query(self, command: str = "") -> str | None:
        """Send ``command?`` and return the stripped response, or ``None`` on timeout."""
        response = await self.send_command(command + "?")
        return response.strip() if response is not None else None

    async def _query_date(self, command: str) -> datetime | None:
        """Send ``command?`` and parse the response as a date (``DD.MM.YYYY``)."""
        response = await self._query(command)
        if response is None or response == "00.00.2000":
            return None
        try:
            return datetime.strptime(response, "%d.%m.%Y")
        except ValueError:
            logger.warning("Could not parse date response %r for %r", response, command)
            return None

    # ------------------------------------------------------------------
    # Internal setup
    # ------------------------------------------------------------------

    async def _setup(self) -> None:
        await self._read_cpfd_exponent()
        await self._subscribe_characteristic(
            SMS_REMOTERESPONSE_UUID, self._on_remote_response
        )
        await self._subscribe_characteristic(SDS_PARAMETERS_UUID, self._on_parameters)

    async def _read_cpfd_exponent(self) -> None:
        """Read the Characteristic Presentation Format Descriptor for scaling."""
        if self._client is None:
            raise RuntimeError("Device not connected.")
        try:
            char = self._client.services.get_characteristic(SDS_MEASUREMENT_UUID)
            if char is None:
                return
            for desc in char.descriptors:
                if desc.uuid.lower() == CPFD_UUID:
                    cpfd = await self._client.read_gatt_descriptor(desc.handle)
                    # CPFD layout: format(1), exponent(1, signed), unit(2), namespace(1), description(2)
                    if len(cpfd) >= 3:
                        self._exponent = struct.unpack("b", bytes([cpfd[1]]))[0]
                    logger.debug("CPFD exponent: 10^%d", self._exponent)
                    break
        except (BleakError, asyncio.TimeoutError, struct.error, IndexError) as exc:
            logger.warning("Could not read CPFD descriptor: %s", exc)

    async def _subscribe_characteristic(
        self,
        uuid: str,
        callback: Callable[[BleakGATTCharacteristic, bytearray], None],
    ) -> None:
        if self._client is None:
            raise RuntimeError("Device not connected.")
        char = self._client.services.get_characteristic(uuid)
        if char and ("notify" in char.properties or "indicate" in char.properties):
            try:
                await self._client.start_notify(uuid, callback)
                logger.debug("Subscribed to notifications on %s.", uuid)
            except BleakError as exc:
                logger.debug("Could not subscribe to %s: %s", uuid, exc)

    async def _unsubscribe_characteristic(self, uuid: str) -> None:
        if self._client is None:
            raise RuntimeError("Device not connected.")
        char = self._client.services.get_characteristic(uuid)
        if char and ("notify" in char.properties or "indicate" in char.properties):
            try:
                await self._client.stop_notify(uuid)
                logger.debug("Unsubscribed from notifications on %s.", uuid)
            except BleakError as exc:
                logger.debug("Could not unsubscribe from %s: %s", uuid, exc)

    async def _unsubscribe_all(self) -> None:
        await self._unsubscribe_characteristic(SDS_MEASUREMENT_UUID)
        await self._unsubscribe_characteristic(SDS_PARAMETERS_UUID)
        await self._unsubscribe_characteristic(SMS_DATASEND_UUID)
        await self._unsubscribe_characteristic(SMS_REMOTERESPONSE_UUID)

    # ------------------------------------------------------------------
    # BLE notification callbacks
    # ------------------------------------------------------------------

    def _on_measurement(self, _char: BleakGATTCharacteristic, data: bytearray) -> None:
        si_value = decode_measurement(bytes(data), self._exponent)
        if si_value is None:
            return

        display_value = si_to_display(si_value, self._unit)
        display_res = (
            resolution_in_display_unit(self._resolution, self._unit)
            if self._resolution is not None
            else None
        )
        measurement = Measurement(
            value=display_value,
            unit=self._unit,
            resolution=display_res,
            mode=self._mode,
        )

        logger.debug("Received measurement: %s", measurement.format())

        try:
            self._queue.put_nowait(measurement)
        except asyncio.QueueFull:
            logger.warning("Measurement queue full; dropping measurement.")

    def _on_remote_response(
        self, _char: BleakGATTCharacteristic, data: bytearray
    ) -> None:
        # Per spec: responses are plain ASCII, max 20 bytes per packet,
        # terminated with \r once the full string has been transmitted.
        chunk = data.decode("ascii", errors="replace")
        self._response_buf += chunk
        while "\r" in self._response_buf:
            response, self._response_buf = self._response_buf.split("\r", 1)
            logger.debug("Received response: %r", response)
            try:
                self._response_queue.put_nowait(response)
            except asyncio.QueueFull:
                logger.warning("Response queue full; dropping response %r.", response)

    def _on_datasend(self, _char: BleakGATTCharacteristic, data: bytearray) -> None:
        """Handle DataSend indication (data button press event).

        The DataSend characteristic sends an indication when the user presses
        the physical data button on the instrument.
        The payload format is ASCII text representing the current measurement value,
        terminated with \r.
        """

        buf = data.decode("ascii", errors="replace").rstrip("\r")

        try:
            value = float(buf)
        except ValueError:
            logger.warning("Could not parse DataSend value %r; ignoring.", buf)
            return

        display_res = (
            resolution_in_display_unit(self._resolution, self._unit)
            if self._resolution is not None
            else None
        )
        measurement = Measurement(
            value=value,
            unit=self._unit,
            resolution=display_res,
            mode=self._mode,
            manual=True,  # Mark as manual measurement from data button
        )

        logger.debug("Received measurement via button press: %s", measurement.format())

        try:
            self._datasend_queue.put_nowait(measurement)
        except asyncio.QueueFull:
            logger.warning("DataSend queue full; dropping measurement.")

    def _on_parameters(self, _char: BleakGATTCharacteristic, data: bytearray) -> None:
        unit, res, mode = decode_parameters(data)
        self._unit = unit
        self._mode = mode
        if res is not None:
            self._resolution = res

        logger.debug(
            "Parameters updated: unit=%s, resolution=%s, mode=%s",
            self._unit,
            self._resolution,
            self._mode,
        )

        self._parameters_received.set()
