# Copyright 2015 AvanzOSC - Ainara Galdona
# Copyright 2016 Tecnativa - Antonio Espinosa
# Copyright 2021 Tecnativa - João Marques
# Copyright 2012,2023,2025 Tecnativa - Pedro M. Baezas
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

{
    "name": "Gestión de activos fijos para España",
    "version": "18.0.2.0.0",
    "depends": ["account_asset_management", "l10n_es_aeat"],
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://github.com/OCA/l10n-spain",
    "category": "Accounting & Finance",
    "data": ["views/account_asset_profile_views.xml", "views/account_asset_views.xml"],
    "installable": True,
    "development_status": "Production/Stable",
    "maintainers": ["pedrobaeza"],
}
