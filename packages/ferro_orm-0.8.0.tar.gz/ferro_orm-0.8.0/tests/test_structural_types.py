import pytest
import uuid
from decimal import Decimal
from enum import Enum
from typing import Annotated, Dict, List

from pydantic import BaseModel, Field

from ferro import Model, connect, FerroField

pytestmark = pytest.mark.backend_matrix


class UserRole(str, Enum):
    ADMIN = "admin"
    USER = "user"


class TranscriptFormat(str, Enum):
    PDF = "pdf"
    DOCX = "docx"
    MD = "md"
    TXT = "txt"
    JSON = "json"


@pytest.mark.asyncio
async def test_structural_types_roundtrip(db_url):
    """Test that UUID, JSON, Enum, BLOB, and Decimal objects are correctly saved and hydrated."""

    class ComplexModel(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        user_id: uuid.UUID
        metadata: Dict[str, str]
        tags: List[str]
        role: UserRole
        data: bytes
        balance: Decimal

    await connect(db_url, auto_migrate=True)

    uid = uuid.uuid4()
    raw_data = b"hello world"
    balance = Decimal("123.456")

    item = await ComplexModel.create(
        user_id=uid,
        metadata={"key": "value"},
        tags=["a", "b"],
        role=UserRole.ADMIN,
        data=raw_data,
        balance=balance,
    )
    item_id = item.id

    # Force eviction from Identity Map to test database hydration
    from ferro import evict_instance

    evict_instance("ComplexModel", str(item_id))

    fetched = await ComplexModel.get(item_id)
    assert fetched is not None

    # Assertions
    assert isinstance(fetched.user_id, uuid.UUID)
    assert fetched.user_id == uid

    assert isinstance(fetched.metadata, dict)
    assert fetched.metadata == {"key": "value"}

    assert isinstance(fetched.tags, list)
    assert fetched.tags == ["a", "b"]

    assert isinstance(fetched.role, UserRole)
    assert fetched.role == UserRole.ADMIN

    assert isinstance(fetched.data, bytes)
    assert fetched.data == raw_data

    assert isinstance(fetched.balance, Decimal)
    assert fetched.balance == balance


@pytest.mark.asyncio
async def test_json_column_list_of_nested_pydantic_models_roundtrip(db_url):
    """list[BaseModel] stores as JSON; accepts models on write; reload yields dicts."""

    class JsonListItem(BaseModel):
        field_a: str
        field_b: int

    class JsonListParent(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        items: list[JsonListItem] = Field(default_factory=list)

    await connect(db_url, auto_migrate=True)

    empty = await JsonListParent.create(items=[])
    from ferro import evict_instance

    evict_instance("JsonListParent", str(empty.id))
    fetched_empty = await JsonListParent.get(empty.id)
    assert fetched_empty is not None
    assert fetched_empty.items == []

    payload = [
        JsonListItem(field_a="x", field_b=1),
        JsonListItem(field_a="y", field_b=2),
    ]
    row = await JsonListParent.create(items=payload)
    assert all(isinstance(it, JsonListItem) for it in row.items)
    evict_instance("JsonListParent", str(row.id))
    fetched = await JsonListParent.get(row.id)
    assert fetched is not None
    assert isinstance(fetched.items, list)
    assert len(fetched.items) == 2
    assert all(isinstance(it, dict) for it in fetched.items)
    assert fetched.items == [p.model_dump() for p in payload]
    revived = [JsonListItem.model_validate(it) for it in fetched.items]
    assert revived == payload


@pytest.mark.asyncio
async def test_structural_filtering(db_url):
    """Test filtering by UUID and Decimal."""

    class ComplexModel(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        user_id: uuid.UUID
        balance: Decimal

    await connect(db_url, auto_migrate=True)

    uid1 = uuid.uuid4()
    uid2 = uuid.uuid4()

    await ComplexModel.create(user_id=uid1, balance=Decimal("10.0"))
    await ComplexModel.create(user_id=uid2, balance=Decimal("20.0"))

    # Filter by UUID
    res = await ComplexModel.where(ComplexModel.user_id == uid1).first()
    assert res is not None
    assert res.user_id == uid1

    # Filter by Decimal
    res = await ComplexModel.where(ComplexModel.balance > Decimal("15.0")).first()
    assert res is not None
    assert res.balance == Decimal("20.0")


@pytest.mark.asyncio
async def test_uuid_in_filter_serializes_collection_values(db_url):
    """UUID values inside IN filters should serialize the same way as scalar UUID filters."""

    class ComplexModel(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        user_id: uuid.UUID

    await connect(db_url, auto_migrate=True)

    uid1 = uuid.uuid4()
    uid2 = uuid.uuid4()
    uid3 = uuid.uuid4()

    await ComplexModel.create(user_id=uid1)
    await ComplexModel.create(user_id=uid2)
    await ComplexModel.create(user_id=uid3)

    results = await ComplexModel.where(ComplexModel.user_id << [uid1, uid3]).all()
    assert {row.user_id for row in results} == {uid1, uid3}


@pytest.mark.asyncio
async def test_uuid_filter_serializes_for_update_and_delete_queries(db_url):
    """UUID filters should serialize for mutating query payloads too."""

    class UuidMutationModel(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        run_id: uuid.UUID
        label: str

    await connect(db_url, auto_migrate=True)

    uid1 = uuid.uuid4()
    uid2 = uuid.uuid4()
    await UuidMutationModel.create(run_id=uid1, label="old")
    await UuidMutationModel.create(run_id=uid2, label="keep")

    updated = await UuidMutationModel.where(
        UuidMutationModel.run_id == uid1
    ).update(label="new")
    assert updated == 1

    fetched = await UuidMutationModel.where(UuidMutationModel.run_id == uid1).first()
    assert fetched is not None
    assert fetched.label == "new"

    deleted = await UuidMutationModel.where(UuidMutationModel.run_id == uid1).delete()
    assert deleted == 1
    remaining = await UuidMutationModel.all()
    assert [row.run_id for row in remaining] == [uid2]


@pytest.mark.asyncio
@pytest.mark.postgres_only
async def test_postgres_json_and_decimal_updates_keep_typed_hydration(db_url):
    """Postgres JSON and numeric updates need casts plus text hydration."""

    class PgTypedMutation(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        metadata: Dict[str, str]
        tags: List[str]
        balance: Decimal

    await connect(db_url, auto_migrate=True)

    row = await PgTypedMutation.create(
        metadata={"old": "value"},
        tags=["a"],
        balance=Decimal("1.50"),
    )

    updated = await PgTypedMutation.where(PgTypedMutation.id == row.id).update(
        metadata={"new": "value"},
        tags=["b", "c"],
        balance=Decimal("2.75"),
    )
    assert updated == 1

    fetched = await PgTypedMutation.get(row.id)
    assert fetched is not None
    assert fetched.metadata == {"new": "value"}
    assert fetched.tags == ["b", "c"]
    assert fetched.balance == Decimal("2.75")

    filtered = await PgTypedMutation.where(
        PgTypedMutation.balance > Decimal("2.00")
    ).first()
    assert filtered is not None
    assert filtered.id == row.id


@pytest.mark.asyncio
@pytest.mark.postgres_only
async def test_native_postgres_enum_column_decodes_via_text_cast(
    db_url, postgres_base_url, db_schema_name
):
    """Reading a native Postgres enum column should not fail through sqlx::Any."""

    class Transcript(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        format: TranscriptFormat

    import psycopg

    with psycopg.connect(postgres_base_url) as conn:
        conn.execute(f'SET search_path TO "{db_schema_name}"')
        conn.execute(
            "CREATE TYPE transcriptformat AS ENUM ('pdf', 'docx', 'md', 'txt', 'json')"
        )
        conn.execute(
            """
            CREATE TABLE transcript (
                id integer PRIMARY KEY,
                format transcriptformat NOT NULL
            )
            """
        )
        conn.execute("INSERT INTO transcript (id, format) VALUES (1, 'pdf')")
        conn.commit()

    await connect(db_url)

    fetched = await Transcript.get(1)
    assert fetched is not None
    assert fetched.format == TranscriptFormat.PDF


@pytest.mark.asyncio
@pytest.mark.postgres_only
async def test_native_postgres_enum_plain_str_column(
    db_url, postgres_base_url, db_schema_name
):
    """Native PG enum columns work when the model field is plain `str` (no `enum_type_name` in schema)."""

    class StrFieldEnumModel(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        status: str

    import psycopg

    with psycopg.connect(postgres_base_url) as conn:
        conn.execute(f'SET search_path TO "{db_schema_name}"')
        conn.execute(
            """
            CREATE TYPE strfieldrowstatus AS ENUM ('active', 'inactive')
            """
        )
        conn.execute(
            """
            CREATE TABLE strfieldenummodel (
                id BIGSERIAL PRIMARY KEY,
                status strfieldrowstatus NOT NULL
            )
            """
        )

    await connect(db_url, auto_migrate=False)

    row = await StrFieldEnumModel.create(status="active")
    fetched = await StrFieldEnumModel.get(row.id)

    assert fetched is not None
    assert fetched.status == "active"


@pytest.mark.asyncio
@pytest.mark.postgres_only
async def test_native_uuid_null_inserts(
    db_url, postgres_base_url, db_schema_name
):
    """Optional ``UUID`` columns on Postgres need ``::uuid`` casts, including for ``NULL``."""

    class UuidRun(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        run_id: uuid.UUID | None = None

    import psycopg

    with psycopg.connect(postgres_base_url) as conn:
        conn.execute(f'SET search_path TO "{db_schema_name}"')
        conn.execute(
            """
            CREATE TABLE uuidrun (
                id BIGSERIAL PRIMARY KEY,
                run_id uuid
            )
            """
        )
        conn.commit()

    await connect(db_url, auto_migrate=False)

    row = await UuidRun.create()
    assert row.id is not None
    assert row.run_id is None
    u = uuid.uuid4()
    row2 = await UuidRun.create(run_id=u)
    f2 = await UuidRun.get(row2.id)
    assert f2 is not None
    assert f2.run_id == u


@pytest.mark.asyncio
@pytest.mark.postgres_only
async def test_native_timestamp_without_time_zone_null_and_value(
    db_url, postgres_base_url, db_schema_name
):
    """``datetime | None`` on ``timestamp without time zone`` must not bind as plain text."""

    from datetime import UTC, datetime

    class RowWithTs(Model):
        id: Annotated[int | None, FerroField(primary_key=True)] = None
        scrubbed_at: datetime | None = None

    import psycopg

    with psycopg.connect(postgres_base_url) as conn:
        conn.execute(f'SET search_path TO "{db_schema_name}"')
        conn.execute(
            """
            CREATE TABLE rowwithts (
                id BIGSERIAL PRIMARY KEY,
                scrubbed_at timestamp without time zone
            )
            """
        )
        conn.commit()

    await connect(db_url, auto_migrate=False)

    row = await RowWithTs.create()
    assert row.scrubbed_at is None
    d = datetime(2024, 1, 2, 3, 4, 5, tzinfo=UTC)
    row2 = await RowWithTs.create(scrubbed_at=d)
    f2 = await RowWithTs.get(row2.id)
    assert f2 is not None
    assert f2.scrubbed_at is not None
