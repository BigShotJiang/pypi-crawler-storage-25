# -*- coding: utf-8 -*-

import argparse
import sys
import os
from ood_cli.core import (
    initialize_workspace,
    load_and_interpolate_config,
    compute_plan,
    apply_plan,
    destroy_resources,
)

# Color ANSI Constants
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_header(title):
    print(f"\n{BOLD}{CYAN}=== {title} ==={RESET}\n")

def main():
    parser = argparse.ArgumentParser(
        description="Odoo Infrastructure as Code (IaC) Engine - Terraform-like declarative tool via XML-RPC."
    )
    
    subparsers = parser.add_subparsers(dest="command", required=True, help="Command to run")
    
    # init command
    init_parser = subparsers.add_parser("init", help="Initialize workspace and test connection")
    
    # plan command
    plan_parser = subparsers.add_parser("plan", help="Compute execution plan and show changes")
    
    # apply command
    apply_parser = subparsers.add_parser("apply", help="Apply declarative configuration to Odoo instance")
    apply_parser.add_argument(
        "--auto-approve", action="store_true", help="Apply changes without asking for manual confirmation"
    )
    
    # destroy command
    destroy_parser = subparsers.add_parser("destroy", help="Completely destroy and unlink all custom resources")
    destroy_parser.add_argument(
        "--auto-approve", action="store_true", help="Destroy resources without asking for manual confirmation"
    )
    
    args = parser.parse_args()
    
    config_file = "main.ood"
    vars_file = "variables.ood"
    state_file = "ood.oodstate"
    
    if args.command == "init":
        print_header("Initializing Workspace")
        if not os.path.exists(config_file):
            print(f"{RED}Error: Required configuration file '{config_file}' is missing!{RESET}")
            sys.exit(1)
            
        success = initialize_workspace(config_file, vars_file, state_file)
        if success:
            print(f"\n{GREEN}{BOLD}Success! Workspace successfully initialized.{RESET}")
            print(f"Configuration file: {config_file}")
            print(f"Variables file: {vars_file if os.path.exists(vars_file) else 'None (using environment)'}")
            print(f"State file: {state_file}")
        else:
            print(f"\n{RED}{BOLD}Initialization failed! Check connection parameters.{RESET}")
            sys.exit(1)
            
    elif args.command in ["plan", "apply", "destroy"]:
        if not os.path.exists(config_file):
            print(f"{RED}Error: Run in a directory containing '{config_file}'!{RESET}")
            sys.exit(1)
        if not os.path.exists(state_file):
            print(f"{YELLOW}Warning: State file '{state_file}' missing. Run 'ood init' first.{RESET}")
            # Automatically try to initialize if connection is okay
            success = initialize_workspace(config_file, vars_file, state_file)
            if not success:
                print(f"{RED}Error: Cannot initialize workspace automatically.{RESET}")
                sys.exit(1)

        print_header(f"Loading Configuration & Connecting")
        config, client = load_and_interpolate_config(config_file, vars_file)
        if not client:
            print(f"{RED}Error: Connection/Authentication failed.{RESET}")
            sys.exit(1)
            
        print(f"Connected to Odoo server version: {BOLD}{client.server_version}{RESET} (Major: {client.major_version})")
            
        if args.command == "plan":
            print_header("Compiling execution plan")
            plan = compute_plan(config, state_file, client)
            display_plan(plan)
            
        elif args.command == "apply":
            print_header("Compiling execution plan")
            plan = compute_plan(config, state_file, client)
            display_plan(plan)
            
            if not plan.get("has_changes"):
                print(f"\n{GREEN}{BOLD}No changes. Database matches configuration. Apply complete.{RESET}")
                sys.exit(0)
                
            if not args.auto_approve:
                try:
                    response = input(f"\n{BOLD}Do you want to perform these actions? (yes/no): {RESET}").strip().lower()
                    if response != "yes":
                        print(f"{YELLOW}Apply cancelled.{RESET}")
                        sys.exit(0)
                except KeyboardInterrupt:
                    print(f"\n{YELLOW}Apply cancelled.{RESET}")
                    sys.exit(0)
                    
            print_header("Applying changes")
            
            conn_info = config.get("connection", {}) if config else {}
            max_workers = conn_info.get("max_workers", 4)
            try:
                max_workers = int(float(max_workers))
            except (ValueError, TypeError):
                max_workers = 4
                
            try:
                apply_plan(plan, state_file, client, max_workers=max_workers)
                print(f"\n{GREEN}{BOLD}Apply complete! Resources applied successfully.{RESET}")
            except Exception as e:
                print(f"\n{RED}{BOLD}Apply failed!{RESET}")
                print(f"{RED}{e}{RESET}")
                sys.exit(1)
            
        elif args.command == "destroy":
            print_header("Compiling destruction plan")
            plan = compute_plan({"resources": []}, state_file, client)
            display_plan(plan)
            
            if not plan.get("has_changes"):
                print(f"\n{GREEN}{BOLD}No active resources tracked in state. Nothing to destroy.{RESET}")
                sys.exit(0)
                
            if not args.auto_approve:
                try:
                    response = input(f"\n{RED}{BOLD}WARNING: Are you sure you want to destroy all managed custom resources? (yes/no): {RESET}").strip().lower()
                    if response != "yes":
                        print(f"{YELLOW}Destruction cancelled.{RESET}")
                        sys.exit(0)
                except KeyboardInterrupt:
                    print(f"\n{YELLOW}Destruction cancelled.{RESET}")
                    sys.exit(0)
                    
            print_header("Destroying resources")
            
            conn_info = config.get("connection", {}) if config else {}
            max_workers = conn_info.get("max_workers", 4)
            try:
                max_workers = int(float(max_workers))
            except (ValueError, TypeError):
                max_workers = 4
                
            try:
                destroy_resources(plan, state_file, client, max_workers=max_workers)
                print(f"\n{GREEN}{BOLD}Destroy complete! All managed resources have been deleted.{RESET}")
            except Exception as e:
                print(f"\n{RED}{BOLD}Destroy failed!{RESET}")
                print(f"{RED}{e}{RESET}")
                sys.exit(1)

def mask_value_recursive(val, sensitive_keys=None):
    if sensitive_keys is None:
        sensitive_keys = {"password", "passwd", "token", "secret", "key", "credential", "private"}
    
    if isinstance(val, dict):
        return {
            k: mask_value_recursive(v, sensitive_keys) if not any(sk in str(k).lower() for sk in sensitive_keys) else "**********"
            for k, v in val.items()
        }
    elif isinstance(val, list):
        return [mask_value_recursive(v, sensitive_keys) for v in val]
    return val

def mask_sensitive_attrs(key, val, sensitive_keys=None):
    if sensitive_keys is None:
        sensitive_keys = {"password", "passwd", "token", "secret", "key", "credential", "private"}
    key_lower = str(key).lower()
    if any(sk in key_lower for sk in sensitive_keys):
        return "**********"
    return mask_value_recursive(val, sensitive_keys)

def display_plan(plan):
    changes = plan.get("changes", [])
    if not plan.get("has_changes"):
        print(f"{BOLD}No changes. Database matches configuration.{RESET}")
        return
        
    print(f"Odoo IaC will perform the following actions:")
    
    for chg in changes:
        action = chg["action"]
        res_type = chg["type"]
        res_name = chg["name"]
        
        if action == "create":
            print(f"  {GREEN}+ create{RESET} {BOLD}{res_type}.{res_name}{RESET}")
            for k, v in chg.get("attrs", {}).items():
                print(f"      {GREEN}{k}:{RESET} {repr(mask_sensitive_attrs(k, v))}")
        elif action == "update":
            print(f"  {YELLOW}~ update{RESET} {BOLD}{res_type}.{res_name}{RESET}")
            for k, diff in chg.get("diff", {}).items():
                masked_old = mask_sensitive_attrs(k, diff['old'])
                masked_new = mask_sensitive_attrs(k, diff['new'])
                print(f"      {YELLOW}{k}:{RESET} {repr(masked_old)} => {repr(masked_new)}")
        elif action == "destroy":
            print(f"  {RED}- destroy{RESET} {BOLD}{res_type}.{res_name}{RESET} (ID: {chg.get('id')})")
            
    print(f"\n{BOLD}Plan: {GREEN}{plan['to_create']} to add{RESET}, {YELLOW}{plan['to_update']} to change{RESET}, {RED}{plan['to_destroy']} to destroy.{RESET}")

if __name__ == "__main__":
    main()
