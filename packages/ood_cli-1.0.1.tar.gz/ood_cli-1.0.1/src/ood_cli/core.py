# -*- coding: utf-8 -*-

import os
import re
import json
import hashlib
import xmlrpc.client
import yaml
import threading
import copy
from concurrent.futures import ThreadPoolExecutor, as_completed

# Precision list of supported resource types in absolute dependency sequence
DEPENDENCY_ORDER = [
    "app",
    "privilege",
    "group",
    "model",
    "field",
    "acl",
    "rule",
    "server_action",
    "base_automation",
    "cron",
    "view",
    "window_action_filter",
    "website_page",
    "attachment",
    "asset",
    "record",
    "import",
]

# Map resource types to Odoo core models for pre-flight checking
RESOURCE_TYPE_TO_MODEL = {
    "app": "ir.module.module",
    "privilege": "res.groups.privilege",
    "group": "res.groups",
    "model": "ir.model",
    "field": "ir.model.fields",
    "acl": "ir.model.access",
    "rule": "ir.rule",
    "server_action": "ir.actions.server",
    "base_automation": "base.automation",
    "cron": "ir.cron",
    "view": "ir.ui.view",
    "window_action_filter": "ir.actions.act_window",
    "website_page": "website.page",
    "attachment": "ir.attachment",
    "asset": "ir.asset",
}


class PreflightValidationError(Exception):
    """Exception raised when pre-flight security or schema validation fails."""
    pass


class OdooClient:
    def __init__(self, url, db, uid, password, version_info=None):
        self.url = url
        self.db = db
        self.uid = uid
        self.password = password
        self.version_info = version_info or {}
        self.server_version = self.version_info.get("server_version", "18.0")
        
        # Extract major version (e.g. 18 or 19)
        self.major_version = 18
        if "server_version_info" in self.version_info and self.version_info["server_version_info"]:
            self.major_version = self.version_info["server_version_info"][0]
        else:
            match = re.search(r"(\d+)\.", self.server_version)
            if match:
                self.major_version = int(match.group(1))
                
        self._thread_local = threading.local()
        
    @property
    def _objects(self):
        if not hasattr(self._thread_local, "objects"):
            self._thread_local.objects = xmlrpc.client.ServerProxy(
                f"{self.url}/xmlrpc/2/object", allow_none=True
            )
        return self._thread_local.objects
        
    def execute(self, model, method, *args, **kwargs):
        try:
            return self._objects.execute_kw(
                self.db, self.uid, self.password, model, method, args, kwargs
            )
        except Exception as e:
            raise Exception(f"Odoo execution failed on model '{model}', method '{method}': {e}")

def get_checksum(attrs):
    """Compute deterministic MD5 checksum for a dictionary of attributes."""
    serialized = json.dumps(attrs, sort_keys=True)
    return hashlib.md5(serialized.encode("utf-8")).hexdigest()

def interpolate_text(text, vars_dict):
    """Replace ${VAR} with values from variables.ood or os.environ."""
    if not isinstance(text, str):
        return text
        
    def replace(match):
        var_name = match.group(1)
        if var_name in vars_dict:
            return str(vars_dict[var_name])
        val = os.getenv(var_name)
        if val is not None:
            return val
        return match.group(0) # Keep ${VAR} if not found

    pattern = re.compile(r"\$\{([^}]+)\}")
    return pattern.sub(replace, text)

def interpolate_recursive(data, vars_dict):
    """Recursively interpolate strings inside dicts/lists."""
    if isinstance(data, dict):
        return {k: interpolate_recursive(v, vars_dict) for k, v in data.items()}
    elif isinstance(data, list):
        return [interpolate_recursive(v, vars_dict) for v in data]
    elif isinstance(data, str):
        return interpolate_text(data, vars_dict)
    return data

def load_vars_file(vars_path):
    """Load local variable definitions from variables.ood if present."""
    if os.path.exists(vars_path):
        try:
            with open(vars_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                return data if isinstance(data, dict) else {}
        except Exception as e:
            print(f"\033[91mWarning: Failed to load variables file '{vars_path}': {e}\033[0m")
    return {}

def _load_yaml_with_includes(file_path, loaded_paths=None, loaded_vars_paths=None, vars_dict=None, variable_sources=None):
    """Load config YAML recursively resolving 'include' files and local 'variables.ood' files."""
    import glob
    if loaded_paths is None:
        loaded_paths = set()
    if loaded_vars_paths is None:
        loaded_vars_paths = set()
    if vars_dict is None:
        vars_dict = {}
    if variable_sources is None:
        variable_sources = {}

    abs_path = os.path.abspath(file_path)
    if abs_path in loaded_paths:
        return {"resources": []}
        
    loaded_paths.add(abs_path)
    
    # 1. Automatic discovery of variables.ood in the directory of this file
    base_dir = os.path.dirname(abs_path)
    local_vars_path = os.path.join(base_dir, "variables.ood")
    if os.path.exists(local_vars_path):
        abs_vars_path = os.path.abspath(local_vars_path)
        if abs_vars_path not in loaded_vars_paths:
            loaded_vars_paths.add(abs_vars_path)
            local_vars = load_vars_file(abs_vars_path)
            for k, v in local_vars.items():
                if k in vars_dict:
                    raise Exception(
                        f"La variable '{k}' est déclarée plusieurs fois : "
                        f"dans '{variable_sources[k]}' et dans '{abs_vars_path}'."
                    )
                vars_dict[k] = v
                variable_sources[k] = abs_vars_path

    # 2. Parse the configuration file
    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Fichier de configuration introuvable : {abs_path}")
        
    with open(abs_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
        
    if not isinstance(config, dict):
        raise ValueError(f"Le fichier {abs_path} doit être un dictionnaire YAML")
        
    resources = config.get("resources") or []
    if not isinstance(resources, list):
        raise ValueError(f"La section 'resources' dans {abs_path} doit être une liste")
        
    # Process includes
    includes = config.get("include") or []
    if isinstance(includes, str):
        includes = [includes]
    elif not isinstance(includes, list):
        raise ValueError(f"La section 'include' dans {abs_path} doit être une liste ou une chaîne")
        
    merged_resources = []
    for pattern in includes:
        full_pattern = os.path.join(base_dir, pattern)
        matching_files = glob.glob(full_pattern, recursive=True)
        matching_files.sort()
        for fpath in matching_files:
            if os.path.isfile(fpath):
                imported_config = _load_yaml_with_includes(
                    fpath, loaded_paths, loaded_vars_paths, vars_dict, variable_sources
                )
                merged_resources.extend(imported_config.get("resources") or [])
                
    merged_resources.extend(resources)
    config["resources"] = merged_resources
    return config

def load_and_interpolate_config(config_path, vars_path):
    """Load raw YAML config, interpolate variables, and authenticate to Odoo."""
    if not os.path.exists(config_path):
        return None, None
        
    # 1. Initialize tracker for loaded variable files and vars dict
    vars_dict = {}
    variable_sources = {}
    loaded_vars_paths = set()
    
    # Load the main variables file first if it exists
    if vars_path and os.path.exists(vars_path):
        abs_vars_path = os.path.abspath(vars_path)
        loaded_vars_paths.add(abs_vars_path)
        vars_dict = load_vars_file(abs_vars_path)
        for k in vars_dict.keys():
            variable_sources[k] = abs_vars_path
            
    # 2. Load and interpolate configuration file recursively
    try:
        raw_config = _load_yaml_with_includes(
            config_path,
            loaded_paths=None,
            loaded_vars_paths=loaded_vars_paths,
            vars_dict=vars_dict,
            variable_sources=variable_sources
        )
    except Exception as e:
        print(f"\033[91mError: Failed to load and compile configuration: {e}\033[0m")
        return None, None
        
    interpolated_config = interpolate_recursive(raw_config, vars_dict)
    
    # 3. Create Odoo client connection
    conn_info = interpolated_config.get("connection", {})
    url = conn_info.get("url")
    db = conn_info.get("db")
    username = conn_info.get("username")
    password = conn_info.get("password")
    
    if not all([url, db, username, password]):
        print("\033[91mError: Missing required connection parameters in config/variables.\033[0m")
        return None, None
        
    try:
        common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common", allow_none=True)
        version_info = {}
        try:
            version_info = common.version()
        except Exception:
            pass
            
        uid = common.authenticate(db, username, password, {})
        if not uid:
            print("\033[91mError: Odoo authentication failed!\033[0m")
            return None, None
            
        client = OdooClient(url, db, uid, password, version_info)
        
        # Explicit override from connection configuration
        declared_version = conn_info.get("odoo_version")
        if declared_version:
            try:
                client.major_version = int(float(declared_version))
                client.server_version = str(declared_version)
            except ValueError:
                pass
                
        return interpolated_config, client
    except Exception as e:
        print(f"\033[91mError connecting to Odoo XML-RPC: {e}\033[0m")
        return None, None

def initialize_workspace(config_path, vars_path, state_path):
    """Verify Odoo connection parameters and initialize empty state file."""
    config, client = load_and_interpolate_config(config_path, vars_path)
    if not client:
        return False
        
    if not os.path.exists(state_path):
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump({"resources": {}}, f, indent=2)
            
    return True

def load_state(state_path):
    """Load JSON state tracker file."""
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"resources": {}}

def save_state(state, state_path):
    """Persist JSON state tracker file."""
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

def compute_plan(config, state_path, client):
    """Compare configuration vs state file to generate structured additions/changes/destructions."""
    state = load_state(state_path)
    state_resources = state.get("resources", {})
    
    declared_resources = config.get("resources", [])
    if declared_resources is None:
        declared_resources = []
        
    # Check for duplicate names within same resource type
    declared_keys = set()
    for res in declared_resources:
        key = f"{res['type']}.{res['name']}"
        if key in declared_keys:
            raise Exception(f"Duplicate resource declaration found: {key}")
        declared_keys.add(key)
        
    model_fields_cache = {}
    
    changes = []
    to_create = 0
    to_update = 0
    to_destroy = 0
    
    # 1. Flag resources to CREATE or UPDATE
    # Preserves declared order for dependency calculation
    for res in declared_resources:
        res_type = res["type"]
        res_name = res["name"]
        key = f"{res_type}.{res_name}"
        
        # Clean attributes dict
        attrs = {k: v for k, v in res.items() if k not in ["type", "name"]}
        if res_type in ["app", "model", "website_page", "attachment", "asset", "record", "import"]:
            attrs["name"] = res_name
            
        # --- Option C: Python Code Syntax Linting ---
        if res_type in ["server_action", "cron", "base_automation"]:
            code = attrs.get("code")
            if code and isinstance(code, str):
                try:
                    compile(code, f"{res_type}.{res_name}", "exec")
                except SyntaxError as e:
                    err_snippet = e.text.strip() if e.text else ""
                    raise Exception(
                        f"Python Syntax Error in resource '{res_type}.{res_name}':\n"
                        f"  Message: {e.msg}\n"
                        f"  Line: {e.lineno}\n"
                        f"  Code snippet: {err_snippet}"
                    )
                    
        # --- Option D: Schema Validation ---
        if res_type in ["record", "import"]:
            model = attrs.get("model")
            if not model:
                raise Exception(f"Validation error in '{res_type}.{res_name}': Missing target model name.")
            
            # Fetch model fields if not cached
            if model not in model_fields_cache:
                try:
                    fields_def = client.execute(model, "fields_get", [])
                    model_fields_cache[model] = set(fields_def.keys())
                except Exception as e:
                    raise Exception(
                        f"Model validation error in resource '{res_type}.{res_name}': "
                        f"The model '{model}' does not exist in Odoo or is inaccessible.\n"
                        f"Details: {e}"
                    )
            
            valid_fields = model_fields_cache[model]
            
            # Identify which fields we are targeting
            fields_to_check = []
            if res_type == "record":
                values = attrs.get("values", {})
                if isinstance(values, dict):
                    fields_to_check = list(values.keys())
            elif res_type == "import":
                mapping = attrs.get("mapping", {})
                if isinstance(mapping, dict):
                    fields_to_check = list(mapping.keys())
                    
            # Check fields
            for field in fields_to_check:
                if field.startswith("_") or field == "id":
                    continue
                if field not in valid_fields:
                    raise Exception(
                        f"Schema Validation Error in resource '{res_type}.{res_name}': "
                        f"Field '{field}' does not exist on Odoo model '{model}'.\n"
                        f"Available fields on '{model}': {sorted(list(valid_fields))}"
                    )
            
        # Inject file hash for import resources to detect data updates dynamically
        if res_type == "import":
            file_path = attrs.get("file_path")
            if file_path and os.path.exists(file_path):
                try:
                    with open(file_path, "rb") as f:
                        file_hash = hashlib.md5(f.read()).hexdigest()
                    attrs["_file_hash"] = file_hash
                except Exception as e:
                    print(f"\033[93mWarning: Failed to compute hash for import file '{file_path}': {e}\033[0m")
                    
        checksum = get_checksum(attrs)
        
        if key not in state_resources:
            changes.append({
                "action": "create",
                "type": res_type,
                "name": res_name,
                "key": key,
                "attrs": attrs,
                "checksum": checksum
            })
            to_create += 1
        else:
            state_res = state_resources[key]
            state_checksum = state_res.get("checksum")
            
            if state_checksum != checksum:
                # Compute attribute difference
                diff = {}
                state_attrs = state_res.get("attrs", {})
                all_keys = set(attrs.keys()) | set(state_attrs.keys())
                for k in all_keys:
                    if attrs.get(k) != state_attrs.get(k):
                        diff[k] = {
                            "old": state_attrs.get(k),
                            "new": attrs.get(k)
                        }
                changes.append({
                    "action": "update",
                    "type": res_type,
                    "name": res_name,
                    "key": key,
                    "id": state_res["id"],
                    "attrs": attrs,
                    "checksum": checksum,
                    "diff": diff
                })
                to_update += 1
                
    # 2. Flag resources to DESTROY
    # Any resource in state but no longer in config file represents a deleted resource
    for key, state_res in list(state_resources.items()):
        if not any(f"{res['type']}.{res['name']}" == key for res in declared_resources):
            changes.append({
                "action": "destroy",
                "type": state_res["type"],
                "name": state_res["name"],
                "key": key,
                "id": state_res["id"]
            })
            to_destroy += 1
            
    # 3. Sort changes according to strict dependency layers
    def sort_key(chg):
        action = chg["action"]
        res_type = chg["type"]
        type_idx = DEPENDENCY_ORDER.index(res_type) if res_type in DEPENDENCY_ORDER else 99
        
        # Deletions/destructions must happen in REVERSE order of dependencies
        # Creations and updates must happen in FORWARD order of dependencies
        if action == "destroy":
            return (0, -type_idx) # Phase 0: destroy (reverse order)
        elif action == "update":
            return (1, type_idx)  # Phase 1: update (forward order)
        else:
            return (2, type_idx)  # Phase 2: create (forward order)

    changes.sort(key=sort_key)
    
    return {
        "changes": changes,
        "has_changes": len(changes) > 0,
        "to_create": to_create,
        "to_update": to_update,
        "to_destroy": to_destroy
    }


def run_preflight_acl_checks(plan, client):
    """Verify that the Odoo user has sufficient access rights for all planned changes."""
    # 1. Identify models being created in the current plan
    created_models = set()
    for chg in plan["changes"]:
        if chg["type"] == "model" and chg["action"] == "create":
            created_models.add(chg["name"])
            # Handle standard 'x_' prefix if not already present
            if not chg["name"].startswith("x_") and "." not in chg["name"]:
                created_models.add(f"x_{chg['name']}")

    # 2. Gather all checks: (model_name, operation) -> list of resource descriptions
    checks = {}
    for chg in plan["changes"]:
        action = chg["action"]
        res_type = chg["type"]
        res_name = chg["name"]
        
        # Map action to Odoo access rights operation
        if action == "create":
            operation = "create"
        elif action == "update":
            operation = "write"
        elif action == "destroy":
            operation = "unlink"
        else:
            continue
            
        # Resolve the Odoo model name for this check
        model_name = None
        if res_type in ["record", "import"]:
            model_name = chg["attrs"].get("model")
        else:
            model_name = RESOURCE_TYPE_TO_MODEL.get(res_type)
            
        if not model_name:
            continue
            
        # If the model is created in this plan, we skip pre-flight checking for it
        if model_name in created_models:
            continue
            
        key = (model_name, operation)
        if key not in checks:
            checks[key] = []
        checks[key].append(f"{res_type}.{res_name} ({action})")

    # 3. Perform the checks against Odoo
    denied = []
    checked_models = {} # Cache if model exists and access
    
    # Check if res.groups.privilege model is supported on this Odoo instance
    privilege_supported = None
    
    for (model_name, operation), resources in sorted(checks.items()):
        if model_name == "res.groups.privilege":
            if privilege_supported is None:
                if hasattr(client, 'major_version') and client.major_version < 19:
                    privilege_supported = False
                else:
                    try:
                        res = client.execute("ir.model", "search", [("model", "=", "res.groups.privilege")])
                        privilege_supported = bool(res)
                    except Exception:
                        privilege_supported = False
            if not privilege_supported:
                continue
                
        # Verify model existence
        if model_name not in checked_models:
            try:
                exists = bool(client.execute("ir.model", "search", [("model", "=", model_name)]))
            except Exception:
                exists = False
            checked_models[model_name] = exists
        else:
            exists = checked_models[model_name]
            
        if not exists:
            # If the model does not exist yet (and is not created in the plan), we skip
            continue

        # Check access rights via XML-RPC
        has_access = False
        try:
            has_access = client.execute(model_name, "check_access_rights", operation, raise_exception=False)
        except Exception:
            try:
                client.execute(model_name, "check_access_rights", operation)
                has_access = True
            except Exception:
                has_access = False
                
        if not has_access:
            denied.append({
                "model": model_name,
                "operation": operation,
                "resources": resources
            })

    if denied:
        error_msg = "Pre-flight ACL Audit Failed! Missing required Odoo access rights:\n"
        for d in denied:
            error_msg += f"  - Model '{d['model']}': No '{d['operation']}' access. Required by:\n"
            for r in d["resources"]:
                error_msg += f"    * {r}\n"
        raise PreflightValidationError(error_msg)


def execute_single_change(chg, client, state, state_path, rollback_stack, state_lock):
    """Execute a single resource change, updating state and the rollback stack in a thread-safe way."""
    from ood_cli.handlers import get_handler
    
    action = chg["action"]
    res_type = chg["type"]
    res_name = chg["name"]
    key = chg["key"]
    
    handler = get_handler(res_type)
    if not handler:
        raise Exception(f"No resource handler defined for type '{res_type}'")
        
    if action == "destroy":
        print(f"  {res_type}.{res_name}: Destroying...")
        with state_lock:
            state_resources_snapshot = dict(state["resources"])
            
        handler.destroy(chg["id"], client, state_resources_snapshot)
        
        with state_lock:
            state["resources"].pop(key, None)
            save_state(state, state_path)
        print(f"  {res_type}.{res_name}: Destroyed successfully.")
        
    elif action == "create":
        print(f"  {res_type}.{res_name}: Creating...")
        with state_lock:
            state_resources_snapshot = dict(state["resources"])
            
        db_id = handler.create(chg["attrs"], client, state_resources_snapshot)
        
        with state_lock:
            state["resources"][key] = {
                "id": db_id,
                "type": res_type,
                "name": res_name,
                "checksum": chg["checksum"],
                "attrs": chg["attrs"]
            }
            save_state(state, state_path)
            rollback_stack.append(("create", key, db_id, res_type, res_name))
        print(f"  {res_type}.{res_name}: Created successfully (ID: {db_id}).")
        
    elif action == "update":
        print(f"  {res_type}.{res_name}: Updating...")
        db_id = chg["id"]
        
        with state_lock:
            state_resources_snapshot = dict(state["resources"])
            old_attrs = copy.deepcopy(state["resources"][key].get("attrs", {}))
            
        handler.update(db_id, chg["attrs"], client, state_resources_snapshot)
        
        with state_lock:
            state["resources"][key] = {
                "id": db_id,
                "type": res_type,
                "name": res_name,
                "checksum": chg["checksum"],
                "attrs": chg["attrs"]
            }
            save_state(state, state_path)
            rollback_stack.append(("update", key, db_id, res_type, res_name, old_attrs))
        print(f"  {res_type}.{res_name}: Updated successfully (ID: {db_id}).")


def apply_plan(plan, state_path, client, max_workers=4):
    """Execute plan changes and record Odoo IDs dynamically to local state."""
    from ood_cli.handlers import get_handler
    import itertools
    
    state = load_state(state_path)
    rollback_stack = []
    state_lock = threading.Lock()
    
    # 1. Option C: Run Pre-flight ACL Audits
    print("Running pre-flight ACL checks...")
    run_preflight_acl_checks(plan, client)
    print("Pre-flight ACL checks passed successfully.")
    
    # 2. Option B & D: Thread-safe grouped execution with rollback stack
    try:
        # Group adjacent changes sharing the same action and resource type
        # plan["changes"] is already sorted by action index and dependency order type index
        for (action, res_type), group in itertools.groupby(plan["changes"], key=lambda c: (c["action"], c["type"])):
            group_changes = list(group)
            if not group_changes:
                continue
                
            if len(group_changes) == 1:
                # Single change in tier: execute synchronously to avoid thread overhead
                execute_single_change(group_changes[0], client, state, state_path, rollback_stack, state_lock)
            else:
                # Multiple changes in tier: execute concurrently using a ThreadPoolExecutor
                print(f"Executing tier: {action} {res_type}s in parallel (count: {len(group_changes)}, max_workers: {max_workers})...")
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = {
                        executor.submit(
                            execute_single_change, chg, client, state, state_path, rollback_stack, state_lock
                        ): chg
                        for chg in group_changes
                    }
                    
                    # Wait for all futures in this tier to complete
                    for future in as_completed(futures):
                        chg = futures[future]
                        try:
                            future.result()
                        except Exception as e:
                            # Shutdown/cancel other pending futures in executor if possible
                            # Python 3.9+ supports cancel_futures=True in shutdown
                            try:
                                executor.shutdown(wait=False, cancel_futures=True)
                            except TypeError:
                                executor.shutdown(wait=False)
                            raise Exception(
                                f"Failed to execute parallel change for '{chg['type']}.{chg['name']}': {e}"
                            ) from e
                            
    except Exception as main_exc:
        # Option D: Traverse the rollback stack in reverse order
        print(f"\n\033[91m\033[1m{'='*60}\n=== CRITICAL FAILURE: INITIATING SAFE ROLLBACK ===\n{'='*60}\033[0m")
        print(f"Reason of failure: {main_exc}\n")
        
        for item in reversed(rollback_stack):
            action_type = item[0]
            key = item[1]
            db_id = item[2]
            res_type = item[3]
            res_name = item[4]
            
            handler = get_handler(res_type)
            if not handler:
                continue
                
            if action_type == "create":
                print(f"  Rollback: Destroying created resource '{res_type}.{res_name}' (ID: {db_id})...")
                try:
                    handler.destroy(db_id, client, state["resources"])
                    state["resources"].pop(key, None)
                    save_state(state, state_path)
                    print(f"  Rollback: Destroyed successfully.")
                except Exception as rollback_err:
                    print(f"  \033[91mWarning: Failed to rollback creation of '{res_type}.{res_name}': {rollback_err}\033[0m")
                    
            elif action_type == "update":
                old_attrs = item[5]
                print(f"  Rollback: Reverting resource '{res_type}.{res_name}' (ID: {db_id}) to previous attributes...")
                try:
                    handler.update(db_id, old_attrs, client, state["resources"])
                    state["resources"][key]["attrs"] = old_attrs
                    state["resources"][key]["checksum"] = get_checksum(old_attrs)
                    save_state(state, state_path)
                    print(f"  Rollback: Reverted successfully.")
                except Exception as rollback_err:
                    print(f"  \033[91mWarning: Failed to rollback update of '{res_type}.{res_name}': {rollback_err}\033[0m")
                    
        print(f"\033[91m\033[1m=== ROLLBACK SEQUENCE COMPLETE ===\033[0m\n")
        raise main_exc


def destroy_resources(plan, state_path, client, max_workers=4):
    """Completely wipe and unlink all managed resources in correct reverse order."""
    apply_plan(plan, state_path, client, max_workers=max_workers)
