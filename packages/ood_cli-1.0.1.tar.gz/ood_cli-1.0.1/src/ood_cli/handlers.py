# -*- coding: utf-8 -*-

import base64
import csv
import os

# Helper functions to look up metadata
_has_privileges_cached = None

def has_privileges(client):
    if hasattr(client, 'major_version') and client.major_version < 19:
        return False
    global _has_privileges_cached
    if _has_privileges_cached is None:
        try:
            res = client.execute("ir.model", "search", [("model", "=", "res.groups.privilege")])
            _has_privileges_cached = bool(res)
        except Exception:
            _has_privileges_cached = False
    return _has_privileges_cached

def get_model_id(model_name, client):
    res = client.execute("ir.model", "search", [("model", "=", model_name)])
    if res:
        return res[0]
    if not model_name.startswith("x_") and "." not in model_name:
        prefixed = f"x_{model_name}"
        res = client.execute("ir.model", "search", [("model", "=", prefixed)])
        if res:
            return res[0]
    raise Exception(f"Odoo model '{model_name}' not found!")

def get_id_by_xml_id(xml_id, client):
    if not xml_id or "." not in xml_id:
        return None
    module, name = xml_id.split(".", 1)
    res = client.execute(
        "ir.model.data", "search_read",
        [("module", "=", module), ("name", "=", name)],
        ["res_id"]
    )
    if res:
        return res[0]["res_id"]
    return None

def resolve_group_id(ref, client, state_resources):
    if not ref:
        return None
    if isinstance(ref, int):
        return ref
    # Check if tracked in state (e.g., "contacts_user_group" -> "group.contacts_user_group")
    state_key = f"group.{ref}"
    if state_key in state_resources:
        return state_resources[state_key]["id"]
    # Check if XML-ID
    if "." in str(ref):
        xml_id = get_id_by_xml_id(str(ref), client)
        if xml_id:
            return xml_id
    # Search by name
    res = client.execute("res.groups", "search", [("name", "=", str(ref))])
    if res:
        return res[0]
    return None

def resolve_server_action_id(ref, client, state_resources):
    if not ref:
        return None
    if isinstance(ref, int):
        return ref
    # Check if state-tracked (e.g., "won_crm_lead_sa" -> "server_action.won_crm_lead_sa")
    state_key = f"server_action.{ref}"
    if state_key in state_resources:
        return state_resources[state_key]["id"]
    # Check XML-ID
    if "." in str(ref):
        xml_id = get_id_by_xml_id(str(ref), client)
        if xml_id:
            return xml_id
    # Search by name
    res = client.execute("ir.actions.server", "search", [("name", "=", str(ref))])
    if res:
        return res[0]
    return None

# Base Handler Blueprint
class BaseHandler:
    @staticmethod
    def create(attrs, client, state_resources):
        raise NotImplementedError()
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        raise NotImplementedError()
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        raise NotImplementedError()

# 1. App Handler
class AppHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        app_name = attrs.get("name")
        res = client.execute("ir.module.module", "search_read", [("name", "=", app_name)], ["id", "state"])
        if not res:
            raise Exception(f"Odoo App module '{app_name}' does not exist in the database catalog.")
        
        module_id = res[0]["id"]
        module_state = res[0]["state"]
        
        if module_state != "installed":
            print(f"    Installing module '{app_name}'...")
            client.execute("ir.module.module", "button_immediate_install", [module_id])
            print(f"    Module '{app_name}' installed successfully.")
            
        return module_id
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        # Already installed, nothing to update
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        # Uninstalling modules during destroy might be too intrusive / slow down local testing.
        # Let's perform the uninstall only if explicitly needed, or gracefully ignore to protect core system.
        # For a true Terraform-like approach, we'll try to uninstall.
        try:
            res = client.execute("ir.module.module", "search_read", [("id", "=", db_id)], ["name", "state"])
            if res and res[0]["state"] == "installed" and res[0]["name"] not in ["base", "web"]:
                print(f"    Uninstalling module '{res[0]['name']}'...")
                client.execute("ir.module.module", "button_immediate_uninstall", [db_id])
                print(f"    Module '{res[0]['name']}' uninstalled.")
        except Exception as e:
            print(f"    Warning: Could not uninstall module ID {db_id}: {e}")

# 2. Privilege Handler
class PrivilegeHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        if not has_privileges(client):
            print("    Skipping privilege creation (Odoo 18 - res.groups.privilege not supported)")
            return 0
            
        name = attrs.get("privilege_name")
        cat_xml_id = attrs.get("category_xml_id")
        cat_id = get_id_by_xml_id(cat_xml_id, client)
        
        vals = {
            "name": name,
            "category_id": cat_id,
            "placeholder": "Aucun accès"
        }
        
        # Check if already exists in Odoo
        existing = client.execute("res.groups.privilege", "search", [("name", "=", name)])
        if existing:
            client.execute("res.groups.privilege", "write", existing, vals)
            return existing[0]
            
        return client.execute("res.groups.privilege", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        if not has_privileges(client):
            return db_id
            
        cat_xml_id = attrs.get("category_xml_id")
        cat_id = get_id_by_xml_id(cat_xml_id, client)
        vals = {
            "name": attrs.get("privilege_name"),
            "category_id": cat_id
        }
        client.execute("res.groups.privilege", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        if not has_privileges(client) or db_id == 0:
            return
        try:
            client.execute("res.groups.privilege", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink privilege ID {db_id} (might be already deleted): {e}")

# 3. Group Handler
class GroupHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("group_name")
        priv_name = attrs.get("privilege_name")
        
        # Resolve privilege_id (Odoo 19) or category_id (Odoo 18)
        priv_id = None
        category_id = None
        
        if priv_name:
            if has_privileges(client):
                # Check in state
                state_priv_key = f"privilege.{priv_name}"
                if state_priv_key in state_resources:
                    priv_id = state_resources[state_priv_key]["id"]
                else:
                    # Fallback search by name
                    res = client.execute("res.groups.privilege", "search", [("name", "=", priv_name)])
                    if res:
                        priv_id = res[0]
            else:
                # Odoo 18: Map group privilege to category_id
                state_priv_key = f"privilege.{priv_name}"
                if state_priv_key in state_resources:
                    cat_xml_id = state_resources[state_priv_key]["attrs"].get("category_xml_id")
                    if cat_xml_id:
                        category_id = get_id_by_xml_id(cat_xml_id, client)
                    
        # Resolve implied ids
        implied_ids = []
        for ref in attrs.get("implied_xml_ids", []):
            g_id = resolve_group_id(ref, client, state_resources)
            if g_id:
                implied_ids.append(g_id)
                
        vals = {
            "name": name,
            "implied_ids": [(6, 0, implied_ids)] if implied_ids else []
        }
        
        if has_privileges(client):
            vals["privilege_id"] = priv_id
        else:
            if category_id:
                vals["category_id"] = category_id
        
        existing = client.execute("res.groups", "search", [("name", "=", name)])
        if existing:
            client.execute("res.groups", "write", existing, vals)
            return existing[0]
            
        return client.execute("res.groups", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        name = attrs.get("group_name")
        priv_name = attrs.get("privilege_name")
        
        # Resolve privilege_id (Odoo 19) or category_id (Odoo 18)
        priv_id = None
        category_id = None
        
        if priv_name:
            if has_privileges(client):
                state_priv_key = f"privilege.{priv_name}"
                if state_priv_key in state_resources:
                    priv_id = state_resources[state_priv_key]["id"]
                else:
                    res = client.execute("res.groups.privilege", "search", [("name", "=", priv_name)])
                    if res:
                        priv_id = res[0]
            else:
                # Odoo 18: Map group privilege to category_id
                state_priv_key = f"privilege.{priv_name}"
                if state_priv_key in state_resources:
                    cat_xml_id = state_resources[state_priv_key]["attrs"].get("category_xml_id")
                    if cat_xml_id:
                        category_id = get_id_by_xml_id(cat_xml_id, client)
                    
        implied_ids = []
        for ref in attrs.get("implied_xml_ids", []):
            g_id = resolve_group_id(ref, client, state_resources)
            if g_id:
                implied_ids.append(g_id)
                
        vals = {
            "name": name,
            "implied_ids": [(6, 0, implied_ids)]
        }
        
        if has_privileges(client):
            vals["privilege_id"] = priv_id
        else:
            if category_id:
                vals["category_id"] = category_id
                
        client.execute("res.groups", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("res.groups", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink group ID {db_id} (might be already deleted): {e}")

# 4. Field Handler
class FieldHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        model_name = attrs.get("model")
        field_name = attrs.get("field_name")
        model_id = get_model_id(model_name, client)
        
        # Check if field exists and check its state
        existing_res = client.execute(
            "ir.model.fields", "search_read",
            [("model", "=", model_name), ("name", "=", field_name)],
            ["id", "state"]
        )
        if existing_res:
            db_id = existing_res[0]["id"]
            if existing_res[0]["state"] != "manual":
                print(f"    Field '{model_name}.{field_name}' exists as a base/delegated field. Skipping creation/modification.")
                return db_id
            
        vals = {
            "name": field_name,
            "model": model_name,
            "model_id": model_id,
            "field_description": attrs.get("field_description"),
            "ttype": attrs.get("ttype"),
            "state": "manual",
            "readonly": attrs.get("readonly", False),
            "store": attrs.get("store", False),
        }
        
        # Add conditional params
        if attrs.get("related"):
            vals["related"] = attrs.get("related")
        if attrs.get("compute"):
            vals["compute"] = attrs.get("compute")
        if attrs.get("depends"):
            vals["depends"] = attrs.get("depends")
        if attrs.get("relation"):
            vals["relation"] = attrs.get("relation")
        if attrs.get("selection"):
            vals["selection"] = str(attrs.get("selection"))
            
        if existing_res:
            db_id = existing_res[0]["id"]
            client.execute("ir.model.fields", "write", [db_id], vals)
            return db_id
            
        return client.execute("ir.model.fields", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        # Verify it's a manual field before updating
        res = client.execute("ir.model.fields", "read", [db_id], ["state", "model", "name"])
        if res and res[0]["state"] != "manual":
            print(f"    Field '{res[0]['model']}.{res[0]['name']}' is a base/delegated field. Skipping update.")
            return db_id
            
        vals = {
            "field_description": attrs.get("field_description"),
            "readonly": attrs.get("readonly", False),
            "store": attrs.get("store", False),
        }
        if attrs.get("related"):
            vals["related"] = attrs.get("related")
        if attrs.get("compute"):
            vals["compute"] = attrs.get("compute")
        if attrs.get("depends"):
            vals["depends"] = attrs.get("depends")
        if attrs.get("selection"):
            vals["selection"] = str(attrs.get("selection"))
            
        client.execute("ir.model.fields", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            res = client.execute("ir.model.fields", "read", [db_id], ["state"])
            if res and res[0]["state"] != "manual":
                print(f"    Field ID {db_id} is a base/delegated field. Skipping destroy.")
                return
        except Exception:
            pass
        try:
            client.execute("ir.model.fields", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink field ID {db_id} (might be already deleted): {e}")

# 5. ACL Handler
class ACLHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("acl_name")
        model_name = attrs.get("model")
        group_ref = attrs.get("group_name")
        
        model_id = get_model_id(model_name, client)
        group_id = resolve_group_id(group_ref, client, state_resources)
        
        vals = {
            "name": name,
            "model_id": model_id,
            "group_id": group_id,
            "perm_read": attrs.get("perm_read", True),
            "perm_write": attrs.get("perm_write", False),
            "perm_create": attrs.get("perm_create", False),
            "perm_unlink": attrs.get("perm_unlink", False),
        }
        
        existing = client.execute("ir.model.access", "search", [("name", "=", name), ("group_id", "=", group_id)])
        if existing:
            client.execute("ir.model.access", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.model.access", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        vals = {
            "perm_read": attrs.get("perm_read", True),
            "perm_write": attrs.get("perm_write", False),
            "perm_create": attrs.get("perm_create", False),
            "perm_unlink": attrs.get("perm_unlink", False),
        }
        client.execute("ir.model.access", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("ir.model.access", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink ACL ID {db_id} (might be already deleted): {e}")

# 6. Record Rule Handler
class RuleHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("rule_name")
        model_name = attrs.get("model")
        group_ref = attrs.get("group_name")
        
        model_id = get_model_id(model_name, client)
        
        group_ids = []
        if group_ref:
            g_id = resolve_group_id(group_ref, client, state_resources)
            if g_id:
                group_ids.append(g_id)
                
        vals = {
            "name": name,
            "model_id": model_id,
            "groups": [(6, 0, group_ids)] if group_ids else [],
            "domain_force": attrs.get("domain_force"),
            "global": not bool(group_ids),
            "perm_read": attrs.get("perm_read", True),
            "perm_write": attrs.get("perm_write", False),
            "perm_create": attrs.get("perm_create", False),
            "perm_unlink": attrs.get("perm_unlink", False),
        }
        
        existing = client.execute("ir.rule", "search", [("name", "=", name)])
        if existing:
            client.execute("ir.rule", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.rule", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        group_ref = attrs.get("group_name")
        group_ids = []
        if group_ref:
            g_id = resolve_group_id(group_ref, client, state_resources)
            if g_id:
                group_ids.append(g_id)
                
        vals = {
            "groups": [(6, 0, group_ids)] if group_ids else [],
            "domain_force": attrs.get("domain_force"),
            "global": not bool(group_ids),
            "perm_read": attrs.get("perm_read", True),
            "perm_write": attrs.get("perm_write", False),
            "perm_create": attrs.get("perm_create", False),
            "perm_unlink": attrs.get("perm_unlink", False),
        }
        client.execute("ir.rule", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("ir.rule", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink rule ID {db_id} (might be already deleted): {e}")

# 7. Server Action Handler
class ServerActionHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("action_name")
        model_name = attrs.get("model")
        model_id = get_model_id(model_name, client)
        
        vals = {
            "name": name,
            "model_id": model_id,
            "state": "code",
            "code": attrs.get("code")
        }
        
        existing = client.execute("ir.actions.server", "search", [("name", "=", name)])
        if existing:
            client.execute("ir.actions.server", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.actions.server", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        vals = {
            "code": attrs.get("code")
        }
        client.execute("ir.actions.server", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("ir.actions.server", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink server action ID {db_id} (might be already deleted): {e}")

# 8. Automated Rule Handler
class BaseAutomationHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("rule_name")
        model_name = attrs.get("model")
        model_id = get_model_id(model_name, client)
        
        # Resolve server actions
        sa_ids = []
        for ref in attrs.get("server_actions", []):
            sa_id = resolve_server_action_id(ref, client, state_resources)
            if sa_id:
                sa_ids.append(sa_id)
                
        # Resolve trigger fields
        field_ids = []
        trigger_fields = attrs.get("trigger_fields", [])
        if trigger_fields:
            field_ids = client.execute("ir.model.fields", "search", [
                ("model", "=", model_name),
                ("name", "in", trigger_fields)
            ])
            
        vals = {
            "name": name,
            "model_id": model_id,
            "trigger": attrs.get("trigger"),
            "trigger_field_ids": [(6, 0, field_ids)] if field_ids else [],
            "action_server_ids": [(6, 0, sa_ids)] if sa_ids else [],
            "active": True
        }
        
        existing = client.execute("base.automation", "search", [("name", "=", name)])
        if existing:
            client.execute("base.automation", "write", existing, vals)
            return existing[0]
            
        return client.execute("base.automation", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        model_name = attrs.get("model")
        sa_ids = []
        for ref in attrs.get("server_actions", []):
            sa_id = resolve_server_action_id(ref, client, state_resources)
            if sa_id:
                sa_ids.append(sa_id)
                
        field_ids = []
        trigger_fields = attrs.get("trigger_fields", [])
        if trigger_fields:
            field_ids = client.execute("ir.model.fields", "search", [
                ("model", "=", model_name),
                ("name", "in", trigger_fields)
            ])
            
        vals = {
            "trigger": attrs.get("trigger"),
            "trigger_field_ids": [(6, 0, field_ids)] if field_ids else [],
            "action_server_ids": [(6, 0, sa_ids)] if sa_ids else []
        }
        client.execute("base.automation", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("base.automation", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink base automation ID {db_id} (might be already deleted): {e}")

# 9. Cron Handler
class CronHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("cron_name")
        model_name = attrs.get("model")
        model_id = get_model_id(model_name, client)
        code = attrs.get("code")
        
        # 1. First manage the automatically associated Cron server action
        sa_name = f"NAT - CronAction: {name}"
        sa_existing = client.execute("ir.actions.server", "search", [("name", "=", sa_name)])
        sa_vals = {
            "name": sa_name,
            "model_id": model_id,
            "state": "code",
            "code": code
        }
        if sa_existing:
            sa_id = sa_existing[0]
            client.execute("ir.actions.server", "write", [sa_id], sa_vals)
        else:
            sa_id = client.execute("ir.actions.server", "create", sa_vals)
            
        # 2. Manage the ir.cron record itself
        vals = {
            "name": name,
            "model_id": model_id,
            "ir_actions_server_id": sa_id,
            "user_id": 1, # Admin / Bot
            "interval_number": attrs.get("interval_number", 1),
            "interval_type": attrs.get("interval_type", "days"),
            "active": True
        }
        
        existing = client.execute("ir.cron", "search", [("name", "=", name)])
        if existing:
            client.execute("ir.cron", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.cron", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        # Keep associated server action synchronized
        cron_data = client.execute("ir.cron", "read", [db_id], ["ir_actions_server_id"])
        if cron_data and cron_data[0].get("ir_actions_server_id"):
            sa_id = cron_data[0]["ir_actions_server_id"][0]
            client.execute("ir.actions.server", "write", [sa_id], {"code": attrs.get("code")})
            
        vals = {
            "interval_number": attrs.get("interval_number", 1),
            "interval_type": attrs.get("interval_type", "days"),
        }
        client.execute("ir.cron", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        # Automatically clean up both the ir.cron and its associated ir.actions.server
        try:
            cron_data = client.execute("ir.cron", "read", [db_id], ["ir_actions_server_id"])
            client.execute("ir.cron", "unlink", [db_id])
            if cron_data and cron_data[0].get("ir_actions_server_id"):
                sa_id = cron_data[0]["ir_actions_server_id"][0]
                client.execute("ir.actions.server", "unlink", [sa_id])
        except Exception as e:
            print(f"    Warning: Could not fully clean up cron {db_id}: {e}")

# 10. QWeb/UI View Handler
class ViewHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("view_name")
        model = attrs.get("model")
        inherit_xml_id = attrs.get("inherit_xml_id")
        arch = attrs.get("arch")
        priority = attrs.get("priority", 16)
        view_type = attrs.get("view_type")
        key = attrs.get("key")
        
        # Version-specific UI syntax compatibility handler
        if arch:
            if client.major_version < 19:
                arch = arch.replace("<card>", "<kanban-box>").replace("</card>", "</kanban-box>")
            else:
                arch = arch.replace("<kanban-box>", "<card>").replace("</kanban-box>", "</card>")
                
            if client.major_version < 18:
                arch = arch.replace("t-out=", "t-esc=")
        
        vals = {
            "name": name,
            "priority": priority,
            "arch_db": arch,
            "active": True
        }
        
        if model:
            if not model.startswith("x_") and "." not in model:
                model = f"x_{model}"
            vals["model"] = model
            
        if inherit_xml_id:
            inherit_id = get_id_by_xml_id(inherit_xml_id, client)
            if not inherit_id:
                raise Exception(f"Parent view to inherit from '{inherit_xml_id}' not found in Odoo!")
            vals["inherit_id"] = inherit_id
            
        if view_type:
            vals["type"] = view_type
            
        if key:
            vals["key"] = key
            
        domain = [("name", "=", name)]
        if model:
            domain.append(("model", "=", model))
        if key:
            domain = [("key", "=", key)]
            
        existing = client.execute("ir.ui.view", "search", domain)
        if existing:
            client.execute("ir.ui.view", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.ui.view", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        arch = attrs.get("arch")
        name = attrs.get("view_name")
        model = attrs.get("model")
        inherit_xml_id = attrs.get("inherit_xml_id")
        priority = attrs.get("priority", 16)
        view_type = attrs.get("view_type")
        key = attrs.get("key")
        
        # Version-specific UI syntax compatibility handler
        if arch:
            if client.major_version < 19:
                arch = arch.replace("<card>", "<kanban-box>").replace("</card>", "</kanban-box>")
            else:
                arch = arch.replace("<kanban-box>", "<card>").replace("</kanban-box>", "</card>")
                
            if client.major_version < 18:
                arch = arch.replace("t-out=", "t-esc=")
                
        vals = {
            "name": name,
            "arch_db": arch,
            "priority": priority
        }
        
        if model:
            if not model.startswith("x_") and "." not in model:
                model = f"x_{model}"
            vals["model"] = model
            
        if inherit_xml_id:
            inherit_id = get_id_by_xml_id(inherit_xml_id, client)
            if inherit_id:
                vals["inherit_id"] = inherit_id
                
        if view_type:
            vals["type"] = view_type
            
        if key:
            vals["key"] = key
            
        client.execute("ir.ui.view", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("ir.ui.view", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink view ID {db_id} (might be already deleted, e.g. via website.page cascade): {e}")

# 11. Window Action Filter Handler
class WindowActionFilterHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        # 1. Resolve action database ID dynamically from name/xml_id
        xml_id = attrs.get("xml_id")
        action_id = attrs.get("action_id")
        
        if xml_id:
            resolved_id = get_id_by_xml_id(xml_id, client)
            if resolved_id:
                action_id = resolved_id
                
        if not action_id:
            raise Exception(f"Could not resolve action ID from config '{xml_id or action_id}'")
            
        # 2. Read existing context
        res = client.execute("ir.actions.act_window", "read", [action_id], ["name", "context"])
        if not res:
            raise Exception(f"Odoo Window Action ID {action_id} not found!")
            
        original_context_str = res[0].get("context") or "{}"
        
        # 3. Add our filter logic safely
        filter_key = attrs.get("filter_key")
        filter_val = attrs.get("filter_value")
        
        new_context_str = original_context_str
        try:
            # Parse dict
            ctx_dict = eval(original_context_str) if isinstance(original_context_str, str) else original_context_str
            if isinstance(ctx_dict, dict):
                ctx_dict[filter_key] = filter_val
                new_context_str = str(ctx_dict)
            else:
                new_context_str = f"{{'{filter_key}': {filter_val}}}"
        except Exception:
            if filter_key not in original_context_str:
                clean_str = original_context_str.rstrip("}").strip()
                if clean_str in ["", "{}"]:
                    new_context_str = f"{{'{filter_key}': {filter_val}}}"
                else:
                    new_context_str = f"{clean_str}, '{filter_key}': {filter_val}}}"
                    
        client.execute("ir.actions.act_window", "write", [action_id], {"context": new_context_str})
        
        # Save original context as db_id or inside custom return structure to restore later
        # Since Odoo database ID is an integer, we return the action_id itself
        # And we'll store original context metadata in the handler or return code if needed
        # But wait: the core engine tracks the resources state. It is safer to return action_id
        return action_id
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        # Rerun create logic to maintain/update context
        return WindowActionFilterHandler.create(attrs, client, state_resources)
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        # We want to restore original context
        # We can read current context, and clean out 'search_default_late'
        try:
            res = client.execute("ir.actions.act_window", "read", [db_id], ["context"])
            if res:
                curr_context = res[0].get("context") or "{}"
                if isinstance(curr_context, str):
                    try:
                        ctx_dict = eval(curr_context)
                        if isinstance(ctx_dict, dict):
                            ctx_dict.pop("search_default_late", None)
                            new_context_str = str(ctx_dict)
                            client.execute("ir.actions.act_window", "write", [db_id], {"context": new_context_str})
                    except Exception:
                        pass
        except Exception as e:
            print(f"    Warning: Could not revert context for action ID {db_id}: {e}")

# 12. Model Handler
class ModelHandler(BaseHandler):
    _ir_model_fields = None

    @staticmethod
    def _get_model_name(name):
        if not name.startswith("x_") and "." not in name:
            return f"x_{name}"
        return name

    @staticmethod
    def _get_supported_mixin_fields(client):
        if ModelHandler._ir_model_fields is None:
            try:
                fields = client.execute("ir.model", "fields_get", [])
                ModelHandler._ir_model_fields = set(fields.keys())
            except Exception:
                ModelHandler._ir_model_fields = set()
        return ModelHandler._ir_model_fields

    @staticmethod
    def _get_mixin_vals(attrs, client):
        inherit_val = attrs.get("inherit")
        if isinstance(inherit_val, str):
            inherit_list = [inherit_val]
        elif isinstance(inherit_val, list):
            inherit_list = inherit_val
        else:
            inherit_list = []

        mixin_mapping = {
            "mail.thread": "is_mail_thread",
            "mail.activity.mixin": "is_mail_activity",
            "mail.blacklist": "is_mail_blacklist",
            "mail.thread.sms": "is_mail_thread_sms",
        }

        supported_fields = ModelHandler._get_supported_mixin_fields(client)
        vals = {}
        for mixin, field_name in mixin_mapping.items():
            if field_name in supported_fields:
                vals[field_name] = mixin in inherit_list
        return vals

    @staticmethod
    def create(attrs, client, state_resources):
        raw_name = attrs.get("name")
        model_name = ModelHandler._get_model_name(raw_name)
        model_desc = attrs.get("model_description", model_name)
        transient = attrs.get("transient", False)
        
        vals = {
            "model": model_name,
            "name": model_desc,
            "state": "manual",
            "transient": transient,
        }
        
        mixin_vals = ModelHandler._get_mixin_vals(attrs, client)
        vals.update(mixin_vals)
        
        existing = client.execute("ir.model", "search", [("model", "=", model_name)])
        if existing:
            update_vals = {
                "name": model_desc,
                "transient": transient
            }
            update_vals.update(mixin_vals)
            client.execute("ir.model", "write", existing, update_vals)
            return existing[0]
            
        return client.execute("ir.model", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        raw_name = attrs.get("name")
        model_name = ModelHandler._get_model_name(raw_name)
        model_desc = attrs.get("model_description", model_name)
        transient = attrs.get("transient", False)
        
        vals = {
            "name": model_desc,
            "transient": transient
        }
        mixin_vals = ModelHandler._get_mixin_vals(attrs, client)
        vals.update(mixin_vals)
        
        client.execute("ir.model", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            res = client.execute("ir.model", "read", [db_id], ["state"])
            if res and res[0]["state"] != "manual":
                print(f"    Model ID {db_id} is a base/delegated model. Skipping destroy.")
                return
        except Exception:
            pass
        try:
            client.execute("ir.model", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink model ID {db_id} (might be already deleted): {e}")

# 13. Website Page Handler
class WebsitePageHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        page_url = attrs.get("url")
        view_ref = attrs.get("view_ref")
        page_name = attrs.get("name")
        is_published = attrs.get("is_published", True)
        website_indexed = attrs.get("website_indexed", True)
        
        view_id = None
        if isinstance(view_ref, int):
            view_id = view_ref
        elif view_ref:
            state_key = f"view.{view_ref}"
            if state_key in state_resources:
                view_id = state_resources[state_key]["id"]
            else:
                if "." in str(view_ref):
                    view_id = get_id_by_xml_id(str(view_ref), client)
                if not view_id:
                    res = client.execute("ir.ui.view", "search", [("name", "=", str(view_ref))])
                    if res:
                        view_id = res[0]
                        
        if not view_id:
            raise Exception(f"Could not resolve QWeb view reference '{view_ref}' for website page '{page_name}'")
            
        vals = {
            "url": page_url,
            "view_id": view_id,
            "name": page_name,
            "is_published": is_published,
            "website_indexed": website_indexed
        }
        
        existing = client.execute("website.page", "search", [("url", "=", page_url)])
        if existing:
            client.execute("website.page", "write", existing, vals)
            return existing[0]
            
        return client.execute("website.page", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        page_url = attrs.get("url")
        view_ref = attrs.get("view_ref")
        is_published = attrs.get("is_published", True)
        website_indexed = attrs.get("website_indexed", True)
        
        view_id = None
        if isinstance(view_ref, int):
            view_id = view_ref
        elif view_ref:
            state_key = f"view.{view_ref}"
            if state_key in state_resources:
                view_id = state_resources[state_key]["id"]
            else:
                if "." in str(view_ref):
                    view_id = get_id_by_xml_id(str(view_ref), client)
                if not view_id:
                    res = client.execute("ir.ui.view", "search", [("name", "=", str(view_ref))])
                    if res:
                        view_id = res[0]
                        
        vals = {
            "url": page_url,
            "is_published": is_published,
            "website_indexed": website_indexed
        }
        if view_id:
            vals["view_id"] = view_id
            
        client.execute("website.page", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("website.page", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink website page ID {db_id} (might be already deleted): {e}")

# 14. Attachment Handler
class AttachmentHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        url = attrs.get("url")
        name = attrs.get("name")
        mimetype = attrs.get("mimetype")
        raw_content = attrs.get("raw_content", "")
        
        datas = ""
        if raw_content:
            datas = base64.b64encode(raw_content.encode("utf-8")).decode("utf-8")
            
        vals = {
            "name": name,
            "type": "binary",
            "url": url,
            "mimetype": mimetype,
            "datas": datas,
            "public": True,
        }
        
        search_domain = [("url", "=", url)] if url else [("name", "=", name)]
        existing = client.execute("ir.attachment", "search", search_domain)
        if existing:
            client.execute("ir.attachment", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.attachment", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        url = attrs.get("url")
        name = attrs.get("name")
        mimetype = attrs.get("mimetype")
        raw_content = attrs.get("raw_content", "")
        
        datas = ""
        if raw_content:
            datas = base64.b64encode(raw_content.encode("utf-8")).decode("utf-8")
            
        vals = {
            "name": name,
            "type": "binary",
            "url": url,
            "mimetype": mimetype,
            "datas": datas,
            "public": True,
        }
        client.execute("ir.attachment", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("ir.attachment", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink attachment ID {db_id}: {e}")

# 15. Asset Handler
class AssetHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        name = attrs.get("name")
        bundle = attrs.get("bundle")
        path = attrs.get("path")
        directive = attrs.get("directive", "append")
        sequence = attrs.get("sequence", 16)
        
        vals = {
            "name": name,
            "bundle": bundle,
            "path": path,
            "directive": directive,
            "sequence": sequence,
        }
        
        existing = client.execute("ir.asset", "search", [("name", "=", name)])
        if existing:
            client.execute("ir.asset", "write", existing, vals)
            return existing[0]
            
        return client.execute("ir.asset", "create", vals)
        
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        name = attrs.get("name")
        bundle = attrs.get("bundle")
        path = attrs.get("path")
        directive = attrs.get("directive", "append")
        sequence = attrs.get("sequence", 16)
        
        vals = {
            "name": name,
            "bundle": bundle,
            "path": path,
            "directive": directive,
            "sequence": sequence,
        }
        client.execute("ir.asset", "write", [db_id], vals)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        try:
            client.execute("ir.asset", "unlink", [db_id])
        except Exception as e:
            print(f"    Warning: Could not unlink asset ID {db_id}: {e}")

# 16. Record Handler (Field Values Modifier)
class RecordHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        model = attrs.get("model")
        xml_id = attrs.get("xml_id")
        res_id = attrs.get("res_id")
        search = attrs.get("search")
        values = attrs.get("values", {})
        
        db_id = None
        if xml_id:
            db_id = get_id_by_xml_id(xml_id, client)
        elif res_id:
            db_id = int(res_id)
        elif search:
            # search is a domain, e.g. [('name', '=', 'MyCompany')]
            res = client.execute(model, "search", search)
            if res:
                db_id = res[0]
                
        if db_id:
            # Record already exists (system or previously created), update field values
            client.execute(model, "write", [db_id], values)
            return db_id
        else:
            # Record does not exist, create a new one
            new_id = client.execute(model, "create", values)
            # Register XML-ID if specified so it can be referenced in Odoo
            if xml_id and "." in xml_id:
                module, name = xml_id.split(".", 1)
                client.execute("ir.model.data", "create", {
                    "module": module,
                    "name": name,
                    "model": model,
                    "res_id": new_id,
                    "noupdate": True
                })
            return new_id
            
    @staticmethod
    def update(db_id, attrs, client, state_resources):
        model = attrs.get("model")
        values = attrs.get("values", {})
        client.execute(model, "write", [db_id], values)
        return db_id
        
    @staticmethod
    def destroy(db_id, client, state_resources):
        # By default, do not unlink system records to avoid accidental deletion.
        # But we print a safe message.
        print(f"    Notice: Unlinking record ID {db_id} omitted for safety.")

# 17. Data Import Handler (CSV / XLSX)
class ImportHandler(BaseHandler):
    @staticmethod
    def create(attrs, client, state_resources):
        model = attrs.get("model")
        file_path = attrs.get("file_path")
        mapping = attrs.get("mapping", {})
        unique_by = attrs.get("unique_by")
        
        if not file_path:
            raise Exception("Balise 'file_path' manquante pour la ressource d'import.")
            
        if not os.path.exists(file_path):
            raise Exception(f"Le fichier d'import spécifié n'existe pas : {file_path}")
            
        # Parse based on file extension
        _, ext = os.path.splitext(file_path.lower())
        records = []
        if ext == ".csv":
            records = ImportHandler._parse_csv(file_path)
        elif ext in [".xlsx", ".xls"]:
            records = ImportHandler._parse_xlsx(file_path)
        else:
            raise Exception(f"Format de fichier non supporté pour l'import (uniquement CSV ou XLSX) : {file_path}")
            
        imported_count = 0
        updated_count = 0
        
        for row in records:
            vals = {}
            for odoo_field, mapping_val in mapping.items():
                if isinstance(mapping_val, dict):
                    if "relation" in mapping_val and "column" in mapping_val:
                        # Many2one dynamic relation lookup (lookup target record ID by name or other field)
                        relation_model = mapping_val["relation"]
                        search_field = mapping_val.get("search_by", "name")
                        col_name = mapping_val["column"]
                        val = row.get(col_name)
                        if val is not None:
                            if isinstance(val, str):
                                val = val.strip()
                            if val:
                                domain = [(search_field, "=", val)]
                                res = client.execute(relation_model, "search", domain)
                                if res:
                                    vals[odoo_field] = res[0]
                                else:
                                    vals[odoo_field] = None
                            else:
                                vals[odoo_field] = None
                    else:
                        # Translatable JSONB field mapping (e.g. {'fr_FR': 'Nom FR', 'en_US': 'Nom EN'})
                        lang_dict = {}
                        for lang_code, col_name in mapping_val.items():
                            val = row.get(col_name)
                            if val is not None:
                                if isinstance(val, str):
                                    val = val.strip()
                                lang_dict[lang_code] = val
                        if lang_dict:
                            vals[odoo_field] = lang_dict
                else:
                    # Standard field mapping
                    val = row.get(mapping_val)
                    if val is not None:
                        if isinstance(val, str):
                            val = val.strip()
                        vals[odoo_field] = val
                    
            if not vals:
                continue
                
            # Perform search to check uniqueness
            domain = []
            if unique_by:
                unique_fields = [unique_by] if isinstance(unique_by, str) else unique_by
                for uf in unique_fields:
                    val = vals.get(uf)
                    if isinstance(val, dict):
                        # Extract the first available translation string for the search filter
                        val = next(iter(val.values())) if val else None
                    domain.append((uf, "=", val))
                    
            existing_ids = []
            if domain:
                existing_ids = client.execute(model, "search", domain)
                
            if existing_ids:
                # Update existing records
                client.execute(model, "write", existing_ids, vals)
                updated_count += len(existing_ids)
            else:
                # Create a new record
                client.execute(model, "create", vals)
                imported_count += 1
                
        print(f"    -> [Import Info] Fichier {file_path} importé avec succès : {imported_count} créés, {updated_count} mis à jour.")
        # Return a deterministic ID
        return 1

    @staticmethod
    def update(db_id, attrs, client, state_resources):
        # Simply run the create method to re-import/update values!
        return ImportHandler.create(attrs, client, state_resources)

    @staticmethod
    def destroy(db_id, client, state_resources):
        # Do not delete imported data to avoid losing business database information
        print(f"    Notice: Destroying data import IaC tracking (data records are preserved).")

    @staticmethod
    def _parse_csv(file_path):
        import pandas as pd
        try:
            df = pd.read_csv(file_path, dtype=str)
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, dtype=str, encoding="iso-8859-1")
        df = df.where(pd.notnull(df), None)
        return df.to_dict(orient="records")

    @staticmethod
    def _parse_xlsx(file_path):
        import pandas as pd
        df = pd.read_excel(file_path, dtype=str)
        df = df.where(pd.notnull(df), None)
        return df.to_dict(orient="records")

# Registry Mapping
HANDLERS = {
    "app": AppHandler,
    "privilege": PrivilegeHandler,
    "group": GroupHandler,
    "field": FieldHandler,
    "acl": ACLHandler,
    "rule": RuleHandler,
    "server_action": ServerActionHandler,
    "base_automation": BaseAutomationHandler,
    "cron": CronHandler,
    "view": ViewHandler,
    "window_action_filter": WindowActionFilterHandler,
    "model": ModelHandler,
    "website_page": WebsitePageHandler,
    "attachment": AttachmentHandler,
    "asset": AssetHandler,
    "record": RecordHandler,
    "import": ImportHandler,
}

def get_handler(res_type):
    return HANDLERS.get(res_type)
