"""Embedding backends. Jina (cloud, code-tuned) is default; Ollama is the local fallback."""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterable

import httpx

log = logging.getLogger(__name__)

# Per-text character cap before sending to the embedder. Most embedding models
# accept tens of thousands of tokens; we cap conservatively to avoid surprises.
MAX_INPUT_CHARS = 30_000


def truncate(text: str, *, limit: int = MAX_INPUT_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit]


class Embedder(ABC):
    """Embedder interface. `dim` MUST match the value baked into chunks_vec."""

    model_name: str
    dim: int

    @abstractmethod
    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        ...

    @abstractmethod
    def embed_query(self, text: str) -> list[float]:
        ...


class JinaEmbedder(Embedder):
    """Jina `jina-embeddings-v2-base-code` (768d). Requires JINA_API_KEY."""

    def __init__(
        self,
        model: str = "jina-embeddings-v2-base-code",
        dim: int = 768,
        api_key: str | None = None,
        url: str = "https://api.jina.ai/v1/embeddings",
        batch_size: int = 64,
        timeout: float = 60.0,
    ) -> None:
        key = api_key or os.environ.get("JINA_API_KEY")
        if not key:
            raise RuntimeError(
                "JINA_API_KEY not set; export it or use CODE_INDEX_EMBEDDER=ollama"
            )
        self.model_name = model
        self.dim = dim
        self.url = url
        self.batch_size = batch_size
        self._client = httpx.Client(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._embed(texts)

    def embed_query(self, text: str) -> list[float]:
        return self._embed([text])[0]

    def _embed(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for batch in _batched(texts, self.batch_size):
            prepped = [truncate(t) for t in batch]
            resp = self._client.post(
                self.url,
                json={"model": self.model_name, "input": prepped},
            )
            resp.raise_for_status()
            data = resp.json()
            sorted_items = sorted(data.get("data", []), key=lambda x: x.get("index", 0))
            out.extend(item["embedding"] for item in sorted_items)
        return out


class OllamaEmbedder(Embedder):
    """Local embeddings via Ollama. Defaults to nomic-embed-text (768d)."""

    def __init__(
        self,
        model: str = "nomic-embed-text",
        dim: int = 768,
        url: str | None = None,
        batch_size: int = 32,
        timeout: float = 60.0,
    ) -> None:
        self.model_name = model
        self.dim = dim
        self.url = (url or os.environ.get("OLLAMA_URL", "http://localhost:11434")).rstrip("/")
        self.batch_size = batch_size
        self._client = httpx.Client(timeout=timeout)

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for batch in _batched(texts, self.batch_size):
            prepped = [truncate(t) for t in batch]
            resp = self._client.post(
                f"{self.url}/api/embed",
                json={"model": self.model_name, "input": prepped},
            )
            resp.raise_for_status()
            data = resp.json()
            embeddings = data.get("embeddings") or data.get("embedding")
            if embeddings is None:
                raise RuntimeError(f"unexpected Ollama response shape: {list(data.keys())}")
            out.extend(embeddings)
        return out

    def embed_query(self, text: str) -> list[float]:
        return self.embed_documents([text])[0]


def _maybe_load_dotenv() -> None:
    """Auto-load `.env` from cwd or any parent so CLI users don't need to source it."""
    if "JINA_API_KEY" in os.environ:
        return
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        candidate = parent / ".env"
        if candidate.is_file():
            load_dotenv(candidate, override=False)
            return


def make_embedder() -> Embedder:
    """Build the embedder configured in the environment."""
    _maybe_load_dotenv()
    backend = os.environ.get("CODE_INDEX_EMBEDDER", "jina").lower()
    model = os.environ.get("CODE_INDEX_EMBED_MODEL")
    dim_env = os.environ.get("CODE_INDEX_EMBED_DIM")

    if backend == "jina":
        return JinaEmbedder(
            model=model or "jina-embeddings-v2-base-code",
            dim=int(dim_env) if dim_env else 768,
        )
    if backend == "ollama":
        return OllamaEmbedder(
            model=model or "nomic-embed-text",
            dim=int(dim_env) if dim_env else 768,
        )
    raise ValueError(f"unknown CODE_INDEX_EMBEDDER: {backend} (use 'jina' or 'ollama')")


def _batched(items: list[str], size: int) -> Iterable[list[str]]:
    for i in range(0, len(items), size):
        yield items[i:i + size]
