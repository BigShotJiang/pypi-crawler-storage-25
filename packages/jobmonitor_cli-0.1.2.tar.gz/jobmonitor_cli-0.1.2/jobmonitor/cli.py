#!/usr/bin/env python3
"""Job monitor — wraps any command or attaches to a running PID with periodic notifications via Slack, Discord, or email."""

import argparse
import configparser
import json
import os
import platform
import re
import smtplib
import subprocess
import sys
import threading
import time
import urllib.request
from collections import deque
from email.mime.text import MIMEText

CONFIG_PATH = os.path.expanduser("~/.jobmonitorrc")


# --- Interval / time helpers ---

def parse_interval(s):
    """Parse interval string like '2h', '30m', '1h30m' into seconds."""
    matches = re.findall(r"(\d+)([hms])", s.lower())
    if not matches:
        raise ValueError(f"Invalid interval format: {s!r}. Use e.g. '2h', '30m', '1h30m'.")
    total = 0
    for value, unit in matches:
        if unit == "h":
            total += int(value) * 3600
        elif unit == "m":
            total += int(value) * 60
        elif unit == "s":
            total += int(value)
    return total


def format_elapsed(seconds):
    """Format seconds as human-readable elapsed time."""
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    parts = []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    parts.append(f"{s}s")
    return " ".join(parts)


# --- System info gathering ---

def get_gpu_info():
    """Query nvidia-smi for GPU status. Returns list of dicts or None."""
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,name",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        lines = result.stdout.strip().split("\n")
        gpus = []
        for line in lines:
            parts = [p.strip() for p in line.split(",")]
            if len(parts) == 5:
                gpus.append({
                    "name": parts[4],
                    "utilization": f"{parts[0]}%",
                    "memory": f"{int(parts[1])}/{int(parts[2])} MiB",
                    "temperature": f"{parts[3]}C",
                })
        return gpus if gpus else None
    except Exception:
        return None


def get_ram_info():
    """Get system RAM usage. Returns dict or None."""
    try:
        with open("/proc/meminfo", "r") as f:
            meminfo = {}
            for line in f:
                parts = line.split()
                meminfo[parts[0].rstrip(":")] = int(parts[1])
        total = meminfo["MemTotal"]
        available = meminfo["MemAvailable"]
        used = total - available
        pct = used * 100 // total
        return {
            "used": f"{used / 1048576:.1f} GiB",
            "total": f"{total / 1048576:.1f} GiB",
            "percent": f"{pct}%",
        }
    except Exception:
        return None


def get_cpu_info():
    """Get system CPU usage. Returns dict or None."""
    try:
        with open("/proc/stat", "r") as f:
            line = f.readline()
        fields = line.split()
        idle = int(fields[4])
        total = sum(int(x) for x in fields[1:])
        time.sleep(0.1)
        with open("/proc/stat", "r") as f:
            line = f.readline()
        fields2 = line.split()
        idle2 = int(fields2[4])
        total2 = sum(int(x) for x in fields2[1:])
        d_total = total2 - total
        d_idle = idle2 - idle
        pct = ((d_total - d_idle) * 100) // d_total if d_total > 0 else 0
        cores = os.cpu_count() or 0
        return {"percent": f"{pct}%", "cores": str(cores)}
    except Exception:
        return None


def get_disk_info():
    """Get disk usage for the current working directory's filesystem. Returns dict or None."""
    try:
        stat = os.statvfs(".")
        total = stat.f_blocks * stat.f_frsize
        free = stat.f_bavail * stat.f_frsize
        used = total - free
        pct = (used * 100) // total if total > 0 else 0
        total_gb = total / (1024 ** 3)
        used_gb = used / (1024 ** 3)
        return {
            "used": f"{used_gb:.1f} GiB",
            "total": f"{total_gb:.1f} GiB",
            "percent": f"{pct}%",
        }
    except Exception:
        return None


# --- Process helpers ---

def pid_is_running(pid):
    """Check if a PID is still running."""
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def get_pid_command(pid):
    """Get the command line of a running PID from /proc."""
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read().decode("utf-8", errors="replace")
            return cmdline.replace("\x00", " ").strip()
    except Exception:
        return f"PID {pid}"


def get_pid_start_time(pid):
    """Get the start time of a PID (seconds since epoch)."""
    try:
        stat = os.stat(f"/proc/{pid}")
        return stat.st_mtime
    except Exception:
        return time.time()


def tail_file(path, n):
    """Read the last n lines from a file."""
    try:
        with open(path, "r", errors="replace") as f:
            return list(deque(f, maxlen=n))
    except Exception:
        return []


# --- Notification content (backend-agnostic) ---

STATUS_LABELS = {
    "started": "Started",
    "running": "Running",
    "completed": "Completed",
    "failed": "Failed",
    "cancelled": "Cancelled",
}


def collect_notification_data(job_name, command_str, status, elapsed, tail_lines,
                               gpu_info, ram_info, cpu_info, disk_info, exit_code=None):
    """Collect all notification data into a plain dict used by all backends."""
    status_label = STATUS_LABELS.get(status, status)
    if exit_code is not None and status == "failed":
        status_label += f" (exit code {exit_code})"
    return {
        "job_name": job_name,
        "command_str": command_str,
        "status": status,
        "status_label": status_label,
        "elapsed": format_elapsed(elapsed),
        "hostname": platform.node(),
        "tail_lines": tail_lines,
        "gpu_info": gpu_info,
        "ram_info": ram_info,
        "cpu_info": cpu_info,
        "disk_info": disk_info,
        "exit_code": exit_code,
    }


# --- Slack backend ---

SLACK_STATUS_ICONS = {
    "started": ":rocket:",
    "running": ":large_green_circle:",
    "completed": ":white_check_mark:",
    "failed": ":red_circle:",
    "cancelled": ":warning:",
}


def build_slack_message(data):
    """Build Slack Block Kit message payload from notification data."""
    icon = SLACK_STATUS_ICONS.get(data["status"], "")
    status_text = f"{icon} {data['status_label']}"

    fields = [
        {"type": "mrkdwn", "text": f"*Status:*\n{status_text}"},
        {"type": "mrkdwn", "text": f"*Elapsed:*\n{data['elapsed']}"},
        {"type": "mrkdwn", "text": f"*Host:*\n{data['hostname']}"},
    ]

    if data["cpu_info"]:
        fields.append({"type": "mrkdwn", "text": f"*CPU:*\n{data['cpu_info']['percent']} ({data['cpu_info']['cores']} cores)"})
    if data["ram_info"]:
        fields.append({"type": "mrkdwn", "text": f"*RAM:*\n{data['ram_info']['used']}/{data['ram_info']['total']} ({data['ram_info']['percent']})"})
    if data["disk_info"]:
        fields.append({"type": "mrkdwn", "text": f"*Disk:*\n{data['disk_info']['used']}/{data['disk_info']['total']} ({data['disk_info']['percent']})"})
    if data["gpu_info"]:
        gpu_lines = [f"{g['name']} | {g['utilization']} | {g['memory']} | {g['temperature']}" for g in data["gpu_info"]]
        fields.append({"type": "mrkdwn", "text": f"*GPU:*\n{chr(10).join(gpu_lines)}"})

    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": f"Job Monitor: {data['job_name']}", "emoji": True}},
        {"type": "section", "fields": fields},
    ]

    if data["tail_lines"]:
        output_text = "\n".join(line.rstrip("\n") for line in data["tail_lines"])
        if len(output_text) > 2900:
            output_text = output_text[-2900:]
        blocks.append({"type": "section", "text": {"type": "mrkdwn", "text": f"*Recent output:*\n```\n{output_text}\n```"}})

    cmd = data["command_str"]
    cmd_display = cmd if len(cmd) <= 200 else cmd[:197] + "..."
    blocks.append({"type": "context", "elements": [{"type": "mrkdwn", "text": f"`{cmd_display}`"}]})

    return {"blocks": blocks}


def send_slack(webhook_url, data):
    """Send notification via Slack webhook."""
    payload = build_slack_message(data)
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(webhook_url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"[jobmonitor] Failed to send Slack notification: {e}", file=sys.stderr)
        return False


# --- Discord backend ---

DISCORD_STATUS_COLORS = {
    "started": 0x3498DB,    # blue
    "running": 0x2ECC71,    # green
    "completed": 0x27AE60,  # dark green
    "failed": 0xE74C3C,     # red
    "cancelled": 0xF39C12,  # orange
}


def build_discord_message(data):
    """Build Discord webhook embed payload from notification data."""
    color = DISCORD_STATUS_COLORS.get(data["status"], 0x95A5A6)

    fields = [
        {"name": "Status", "value": data["status_label"], "inline": True},
        {"name": "Elapsed", "value": data["elapsed"], "inline": True},
        {"name": "Host", "value": data["hostname"], "inline": True},
    ]

    if data["cpu_info"]:
        fields.append({"name": "CPU", "value": f"{data['cpu_info']['percent']} ({data['cpu_info']['cores']} cores)", "inline": True})
    if data["ram_info"]:
        fields.append({"name": "RAM", "value": f"{data['ram_info']['used']}/{data['ram_info']['total']} ({data['ram_info']['percent']})", "inline": True})
    if data["disk_info"]:
        fields.append({"name": "Disk", "value": f"{data['disk_info']['used']}/{data['disk_info']['total']} ({data['disk_info']['percent']})", "inline": True})
    if data["gpu_info"]:
        gpu_lines = [f"{g['name']} | {g['utilization']} | {g['memory']} | {g['temperature']}" for g in data["gpu_info"]]
        fields.append({"name": "GPU", "value": "\n".join(gpu_lines), "inline": False})

    embed = {
        "title": f"Job Monitor: {data['job_name']}",
        "color": color,
        "fields": fields,
    }

    if data["tail_lines"]:
        output_text = "\n".join(line.rstrip("\n") for line in data["tail_lines"])
        if len(output_text) > 1000:
            output_text = output_text[-1000:]
        embed["description"] = f"**Recent output:**\n```\n{output_text}\n```"

    cmd = data["command_str"]
    cmd_display = cmd if len(cmd) <= 200 else cmd[:197] + "..."
    embed["footer"] = {"text": cmd_display}

    return {"embeds": [embed]}


def send_discord(webhook_url, data):
    """Send notification via Discord webhook."""
    payload = build_discord_message(data)
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(webhook_url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status in (200, 204)
    except Exception as e:
        print(f"[jobmonitor] Failed to send Discord notification: {e}", file=sys.stderr)
        return False


# --- Email backend ---

def build_email_body(data):
    """Build a plain-text email body from notification data."""
    lines = [
        f"Job Monitor: {data['job_name']}",
        f"{'=' * 40}",
        f"Status:  {data['status_label']}",
        f"Elapsed: {data['elapsed']}",
        f"Host:    {data['hostname']}",
    ]

    if data["cpu_info"]:
        lines.append(f"CPU:     {data['cpu_info']['percent']} ({data['cpu_info']['cores']} cores)")
    if data["ram_info"]:
        lines.append(f"RAM:     {data['ram_info']['used']}/{data['ram_info']['total']} ({data['ram_info']['percent']})")
    if data["disk_info"]:
        lines.append(f"Disk:    {data['disk_info']['used']}/{data['disk_info']['total']} ({data['disk_info']['percent']})")
    if data["gpu_info"]:
        for g in data["gpu_info"]:
            lines.append(f"GPU:     {g['name']} | {g['utilization']} | {g['memory']} | {g['temperature']}")

    if data["tail_lines"]:
        lines.append("")
        lines.append("Recent output:")
        lines.append("-" * 40)
        for line in data["tail_lines"]:
            lines.append(line.rstrip("\n"))
        lines.append("-" * 40)

    cmd = data["command_str"]
    cmd_display = cmd if len(cmd) <= 200 else cmd[:197] + "..."
    lines.append("")
    lines.append(f"Command: {cmd_display}")

    return "\n".join(lines)


def send_email(args, data):
    """Send notification via email using SMTP."""
    email_to = args.email_to
    email_from = args.email_from or f"{os.getenv('USER', 'jobmonitor')}@{platform.node()}"
    smtp_server = args.smtp_server or os.environ.get("SMTP_SERVER", "localhost")
    smtp_port = args.smtp_port

    body = build_email_body(data)
    subject = f"[jobmonitor] {data['job_name']} — {data['status_label']}"

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = email_from
    msg["To"] = email_to

    try:
        with smtplib.SMTP(smtp_server, smtp_port, timeout=10) as server:
            server.sendmail(email_from, [email_to], msg.as_string())
        return True
    except Exception as e:
        print(f"[jobmonitor] Failed to send email: {e}", file=sys.stderr)
        return False


# --- Backend dispatcher ---

def send_notification(args, data):
    """Send notification using the configured backend."""
    backend = args.backend

    if backend == "slack":
        webhook_url = args.webhook_url or os.environ.get("SLACK_WEBHOOK_URL")
        if not webhook_url:
            print("Error: --webhook-url or SLACK_WEBHOOK_URL env var required for Slack backend.", file=sys.stderr)
            sys.exit(1)
        return send_slack(webhook_url, data)

    elif backend == "discord":
        webhook_url = args.webhook_url or os.environ.get("DISCORD_WEBHOOK_URL")
        if not webhook_url:
            print("Error: --webhook-url or DISCORD_WEBHOOK_URL env var required for Discord backend.", file=sys.stderr)
            sys.exit(1)
        return send_discord(webhook_url, data)

    elif backend == "email":
        if not args.email_to and not os.environ.get("JOBMONITOR_EMAIL_TO"):
            print("Error: --email-to or JOBMONITOR_EMAIL_TO env var required for email backend.", file=sys.stderr)
            sys.exit(1)
        if not args.email_to:
            args.email_to = os.environ["JOBMONITOR_EMAIL_TO"]
        return send_email(args, data)


# --- Run modes ---

def run_wrap_mode(args, command, interval_secs):
    """Wrap a command: launch it, tee its output, and send periodic notifications."""
    command_str = " ".join(command)
    job_name = args.name or (command_str[:50] + "..." if len(command_str) > 50 else command_str)

    output_buffer = deque(maxlen=args.tail)

    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    def reader():
        for line in iter(process.stdout.readline, b""):
            decoded = line.decode("utf-8", errors="replace")
            sys.stdout.write(decoded)
            sys.stdout.flush()
            output_buffer.append(decoded.rstrip("\n"))
        process.stdout.close()

    thread = threading.Thread(target=reader, daemon=True)
    thread.start()

    start_time = time.time()
    last_notification = start_time
    status = "running"

    def send_update(st, exit_code=None):
        elapsed = time.time() - start_time
        gpu_info = None if args.no_gpu else get_gpu_info()
        ram_info = None if args.no_ram else get_ram_info()
        cpu_info = get_cpu_info() if args.cpu else None
        disk_info = get_disk_info() if args.disk else None
        tail_lines = tail_file(args.log, args.tail) if args.log else list(output_buffer)
        data = collect_notification_data(job_name, command_str, st, elapsed, tail_lines, gpu_info, ram_info, cpu_info, disk_info, exit_code)
        send_notification(args, data)

    print(f"[jobmonitor] Started. Notifications every {args.interval} via {args.backend}.", file=sys.stderr)
    send_update("started")

    try:
        while True:
            retcode = process.poll()
            if retcode is not None:
                thread.join(timeout=5)
                status = "completed" if retcode == 0 else "failed"
                break

            now = time.time()
            if now - last_notification >= interval_secs:
                send_update("running")
                last_notification = now

            time.sleep(5)

    except KeyboardInterrupt:
        status = "cancelled"
        process.terminate()
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            process.kill()

    send_update(status, exit_code=process.returncode)
    elapsed = format_elapsed(time.time() - start_time)
    print(f"[jobmonitor] Job {status} after {elapsed}. Final notification sent.", file=sys.stderr)

    sys.exit(process.returncode if process.returncode is not None else 1)


def run_attach_mode(args, interval_secs):
    """Attach to a running PID and send periodic notifications until it exits."""
    pid = args.pid
    if not pid_is_running(pid):
        print(f"Error: PID {pid} is not running.", file=sys.stderr)
        sys.exit(1)

    command_str = get_pid_command(pid)
    job_name = args.name or f"PID {pid}"
    log_path = args.log
    start_time = get_pid_start_time(pid)

    def send_update(st):
        elapsed = time.time() - start_time
        gpu_info = None if args.no_gpu else get_gpu_info()
        ram_info = None if args.no_ram else get_ram_info()
        cpu_info = get_cpu_info() if args.cpu else None
        disk_info = get_disk_info() if args.disk else None
        tail_lines = tail_file(log_path, args.tail) if log_path else []
        data = collect_notification_data(job_name, command_str, st, elapsed, tail_lines, gpu_info, ram_info, cpu_info, disk_info)
        send_notification(args, data)

    log_msg = f" Tailing {log_path}." if log_path else ""
    print(f"[jobmonitor] Attached to PID {pid}. Notifications every {args.interval} via {args.backend}.{log_msg}", file=sys.stderr)
    send_update("started")

    last_notification = time.time()
    status = "running"

    try:
        while True:
            if not pid_is_running(pid):
                status = "completed"
                break

            now = time.time()
            if now - last_notification >= interval_secs:
                send_update("running")
                last_notification = now

            time.sleep(5)

    except KeyboardInterrupt:
        status = "cancelled"

    send_update(status)
    elapsed = format_elapsed(time.time() - start_time)
    print(f"[jobmonitor] PID {pid} {status} after {elapsed}. Final notification sent.", file=sys.stderr)


# --- Config file ---

def load_config():
    """Load config from ~/.jobmonitorrc. Returns a configparser object."""
    config = configparser.ConfigParser()
    config.read(CONFIG_PATH)
    return config


def apply_config_defaults(args, config):
    """Apply config file defaults to args where CLI didn't explicitly set a value.
    Priority: CLI flags > env vars > config file > hardcoded defaults."""

    defaults = dict(config["defaults"]) if config.has_section("defaults") else {}

    # String options: only override if CLI left them at their hardcoded default
    if args.interval == "2h" and "interval" in defaults:
        args.interval = defaults["interval"]
    if args.backend == "slack" and "backend" in defaults:
        backend = os.environ.get("JOBMONITOR_BACKEND", defaults["backend"])
        if backend in ("slack", "discord", "email"):
            args.backend = backend
    if args.tail == 5 and "tail" in defaults:
        args.tail = int(defaults["tail"])

    # Boolean options: only override if CLI left them False (not passed)
    for flag in ("cpu", "disk"):
        if not getattr(args, flag) and defaults.get(flag, "").lower() in ("true", "yes", "1"):
            setattr(args, flag, True)
    for flag in ("no_gpu", "no_ram"):
        config_key = flag.replace("_", "-")
        if not getattr(args, flag) and defaults.get(config_key, "").lower() in ("true", "yes", "1"):
            setattr(args, flag, True)

    # Backend-specific config sections
    if args.webhook_url is None:
        if args.backend == "slack":
            args.webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
            if not args.webhook_url and config.has_section("slack"):
                args.webhook_url = config.get("slack", "webhook_url", fallback=None)
        elif args.backend == "discord":
            args.webhook_url = os.environ.get("DISCORD_WEBHOOK_URL")
            if not args.webhook_url and config.has_section("discord"):
                args.webhook_url = config.get("discord", "webhook_url", fallback=None)

    if args.backend == "email":
        email_section = dict(config["email"]) if config.has_section("email") else {}
        if not args.email_to:
            args.email_to = os.environ.get("JOBMONITOR_EMAIL_TO", email_section.get("to"))
        if not args.email_from:
            args.email_from = email_section.get("from")
        if not args.smtp_server:
            args.smtp_server = os.environ.get("SMTP_SERVER", email_section.get("smtp_server"))
        if args.smtp_port == 25 and "smtp_port" in email_section:
            args.smtp_port = int(email_section["smtp_port"])

    return args


# --- CLI entry point ---

def main():
    parser = argparse.ArgumentParser(
        description="Job monitor with Slack, Discord, or email notifications",
        usage="jobmonitor [OPTIONS] -- COMMAND [ARGS...]\n       jobmonitor --pid PID [OPTIONS]",
    )
    parser.add_argument("--interval", default="2h", help="Notification interval (e.g. 2h, 30m, 1h30m). Default: 2h")
    parser.add_argument("--backend", default=os.environ.get("JOBMONITOR_BACKEND", "slack"),
                        choices=["slack", "discord", "email"],
                        help="Notification backend. Default: slack (or JOBMONITOR_BACKEND env var)")
    parser.add_argument("--webhook-url", default=None, help="Webhook URL for Slack or Discord")
    parser.add_argument("--name", default=None, help="Job name for notifications")
    parser.add_argument("--tail", type=int, default=5, help="Number of output lines to include in notifications. Default: 5")
    parser.add_argument("--pid", type=int, default=None, help="Attach to an already-running process by PID")
    parser.add_argument("--log", default=None, help="Log file to tail for notification output instead of stdout. Works in both wrap and --pid modes")
    parser.add_argument("--no-gpu", action="store_true", help="Skip GPU info in notifications")
    parser.add_argument("--no-ram", action="store_true", help="Skip RAM info in notifications")
    parser.add_argument("--cpu", action="store_true", help="Include CPU usage in notifications")
    parser.add_argument("--disk", action="store_true", help="Include disk usage in notifications")
    # Email-specific options
    parser.add_argument("--email-to", default=None, help="Recipient email address")
    parser.add_argument("--email-from", default=None, help="Sender email address. Default: user@hostname")
    parser.add_argument("--smtp-server", default=None, help="SMTP server. Default: localhost")
    parser.add_argument("--smtp-port", type=int, default=25, help="SMTP port. Default: 25")

    # Handle --help before splitting at '--'
    if "--help" in sys.argv or "-h" in sys.argv:
        parser.parse_args(["--help"])

    # Check if we're in attach mode (--pid) or wrap mode (--)
    has_separator = "--" in sys.argv
    has_pid = "--pid" in sys.argv

    if has_pid:
        args = parser.parse_args()
    elif has_separator:
        sep_idx = sys.argv.index("--")
        monitor_args = sys.argv[1:sep_idx]
        command = sys.argv[sep_idx + 1:]
        if not command:
            print("Error: no command specified after '--'.", file=sys.stderr)
            sys.exit(1)
        args = parser.parse_args(monitor_args)
    else:
        print("Usage: jobmonitor [OPTIONS] -- COMMAND [ARGS...]", file=sys.stderr)
        print("       jobmonitor --pid PID [OPTIONS]", file=sys.stderr)
        print("\nError: provide either '--' followed by a command, or --pid PID.", file=sys.stderr)
        sys.exit(1)

    # Load config and apply defaults
    config = load_config()
    args = apply_config_defaults(args, config)

    interval_secs = parse_interval(args.interval)

    if has_pid:
        run_attach_mode(args, interval_secs)
    else:
        run_wrap_mode(args, command, interval_secs)


if __name__ == "__main__":
    main()
