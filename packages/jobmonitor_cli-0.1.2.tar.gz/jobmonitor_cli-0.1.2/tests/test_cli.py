"""Unit tests for jobmonitor.cli internals."""

import argparse
import configparser
import json
import os
import tempfile

import pytest

from jobmonitor.cli import (
    apply_config_defaults,
    build_discord_message,
    build_email_body,
    build_slack_message,
    collect_notification_data,
    format_elapsed,
    get_cpu_info,
    get_disk_info,
    get_ram_info,
    load_config,
    parse_interval,
    tail_file,
)


# --- helpers ---

def _make_data(status="running", tail_lines=None, gpu_info=None,
               ram_info=None, cpu_info=None, disk_info=None, exit_code=None):
    return collect_notification_data(
        job_name="test-job",
        command_str="python train.py",
        status=status,
        elapsed=3661,
        tail_lines=tail_lines or [],
        gpu_info=gpu_info,
        ram_info=ram_info,
        cpu_info=cpu_info,
        disk_info=disk_info,
        exit_code=exit_code,
    )


# --- parse_interval ---

class TestParseInterval:
    def test_hours(self):
        assert parse_interval("2h") == 7200

    def test_minutes(self):
        assert parse_interval("30m") == 1800

    def test_seconds(self):
        assert parse_interval("45s") == 45

    def test_combined(self):
        assert parse_interval("1h30m") == 5400

    def test_full_combo(self):
        assert parse_interval("1h30m10s") == 5410

    def test_case_insensitive(self):
        assert parse_interval("2H") == 7200
        assert parse_interval("30M") == 1800

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            parse_interval("invalid")

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            parse_interval("")


# --- format_elapsed ---

class TestFormatElapsed:
    def test_seconds_only(self):
        assert format_elapsed(45) == "45s"

    def test_minutes_and_seconds(self):
        assert format_elapsed(125) == "2m 5s"

    def test_hours_minutes_seconds(self):
        assert format_elapsed(3661) == "1h 1m 1s"

    def test_exact_hour(self):
        assert format_elapsed(3600) == "1h 0s"

    def test_zero(self):
        assert format_elapsed(0) == "0s"

    def test_large_value(self):
        result = format_elapsed(86400)
        assert result == "24h 0s"


# --- tail_file ---

class TestTailFile:
    def test_tail_fewer_lines(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("line1\nline2\nline3\n")
            path = f.name
        try:
            lines = tail_file(path, 10)
            assert len(lines) == 3
            assert lines[0].strip() == "line1"
        finally:
            os.unlink(path)

    def test_tail_truncates(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            for i in range(100):
                f.write(f"line{i}\n")
            path = f.name
        try:
            lines = tail_file(path, 5)
            assert len(lines) == 5
            assert lines[0].strip() == "line95"
        finally:
            os.unlink(path)

    def test_nonexistent_file(self):
        lines = tail_file("/tmp/nonexistent_file_12345.log", 10)
        assert lines == []

    def test_empty_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            path = f.name
        try:
            lines = tail_file(path, 10)
            assert lines == []
        finally:
            os.unlink(path)


# --- collect_notification_data ---

class TestCollectNotificationData:
    def test_basic_fields(self):
        data = _make_data()
        assert data["job_name"] == "test-job"
        assert data["command_str"] == "python train.py"
        assert data["status"] == "running"
        assert data["status_label"] == "Running"
        assert data["elapsed"] == "1h 1m 1s"
        assert data["hostname"]  # should be non-empty

    def test_failed_with_exit_code(self):
        data = _make_data(status="failed", exit_code=137)
        assert "exit code 137" in data["status_label"]

    def test_all_statuses(self):
        for status, label in [("started", "Started"), ("running", "Running"),
                               ("completed", "Completed"), ("failed", "Failed"),
                               ("cancelled", "Cancelled")]:
            data = _make_data(status=status)
            assert data["status_label"] == label


# --- build_slack_message ---

class TestBuildSlackMessage:
    def _build(self, **kwargs):
        return build_slack_message(_make_data(**kwargs))

    def test_basic_structure(self):
        msg = self._build()
        assert "blocks" in msg
        assert len(msg["blocks"]) >= 3
        assert msg["blocks"][0]["type"] == "header"
        assert "test-job" in msg["blocks"][0]["text"]["text"]

    def test_status_icons(self):
        for status, icon in [
            ("started", ":rocket:"),
            ("running", ":large_green_circle:"),
            ("completed", ":white_check_mark:"),
            ("failed", ":red_circle:"),
            ("cancelled", ":warning:"),
        ]:
            msg = self._build(status=status)
            fields_text = json.dumps(msg["blocks"][1]["fields"])
            assert icon in fields_text

    def test_elapsed_in_fields(self):
        msg = self._build()
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "1h 1m 1s" in fields_text

    def test_failed_with_exit_code(self):
        msg = self._build(status="failed", exit_code=137)
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "exit code 137" in fields_text

    def test_gpu_info_included(self):
        gpu = [{"name": "A100", "utilization": "85%", "memory": "8192/16384 MiB", "temperature": "72C"}]
        msg = self._build(gpu_info=gpu)
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "A100" in fields_text
        assert "85%" in fields_text

    def test_ram_info_included(self):
        ram = {"used": "8000 MiB", "total": "16000 MiB", "percent": "50%"}
        msg = self._build(ram_info=ram)
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "8000 MiB" in fields_text

    def test_cpu_info_included(self):
        cpu = {"percent": "42%", "cores": "16"}
        msg = self._build(cpu_info=cpu)
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "42%" in fields_text
        assert "16 cores" in fields_text

    def test_disk_info_included(self):
        disk = {"used": "100.0 GiB", "total": "500.0 GiB", "percent": "20%"}
        msg = self._build(disk_info=disk)
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "100.0 GiB" in fields_text

    def test_no_optional_fields(self):
        msg = self._build()
        fields_text = json.dumps(msg["blocks"][1]["fields"])
        assert "GPU" not in fields_text
        assert "CPU" not in fields_text
        assert "Disk" not in fields_text
        assert "RAM" not in fields_text

    def test_tail_lines_included(self):
        msg = self._build(tail_lines=["epoch 1 loss=0.5", "epoch 2 loss=0.3"])
        output_blocks = [b for b in msg["blocks"] if b["type"] == "section" and "Recent output" in b.get("text", {}).get("text", "")]
        assert len(output_blocks) == 1
        assert "epoch 2 loss=0.3" in output_blocks[0]["text"]["text"]

    def test_no_tail_lines_no_output_block(self):
        msg = self._build(tail_lines=[])
        output_blocks = [b for b in msg["blocks"] if b["type"] == "section" and "Recent output" in b.get("text", {}).get("text", "")]
        assert len(output_blocks) == 0

    def test_command_in_context(self):
        msg = self._build()
        context_block = msg["blocks"][-1]
        assert context_block["type"] == "context"
        assert "python train.py" in context_block["elements"][0]["text"]

    def test_long_command_truncated(self):
        data = _make_data()
        data["command_str"] = "x" * 300
        msg = build_slack_message(data)
        context_text = msg["blocks"][-1]["elements"][0]["text"]
        assert len(context_text) <= 210

    def test_long_output_truncated(self):
        long_lines = [f"line {i} " + "x" * 100 for i in range(100)]
        msg = self._build(tail_lines=long_lines)
        output_blocks = [b for b in msg["blocks"] if "Recent output" in b.get("text", {}).get("text", "")]
        inner = output_blocks[0]["text"]["text"].split("```")[1]
        assert len(inner) <= 2910

    def test_serializable(self):
        gpu = [{"name": "V100", "utilization": "50%", "memory": "4000/8000 MiB", "temperature": "60C"}]
        ram = {"used": "4000 MiB", "total": "8000 MiB", "percent": "50%"}
        cpu = {"percent": "25%", "cores": "8"}
        disk = {"used": "50.0 GiB", "total": "200.0 GiB", "percent": "25%"}
        msg = self._build(status="completed", tail_lines=["done"],
                          gpu_info=gpu, ram_info=ram, cpu_info=cpu, disk_info=disk, exit_code=0)
        assert isinstance(json.dumps(msg), str)


# --- build_discord_message ---

class TestBuildDiscordMessage:
    def _build(self, **kwargs):
        return build_discord_message(_make_data(**kwargs))

    def test_basic_structure(self):
        msg = self._build()
        assert "embeds" in msg
        assert len(msg["embeds"]) == 1
        embed = msg["embeds"][0]
        assert "test-job" in embed["title"]
        assert "color" in embed
        assert len(embed["fields"]) >= 3  # status, elapsed, host

    def test_status_colors(self):
        colors = {
            "started": 0x3498DB,
            "running": 0x2ECC71,
            "completed": 0x27AE60,
            "failed": 0xE74C3C,
            "cancelled": 0xF39C12,
        }
        for status, expected_color in colors.items():
            msg = self._build(status=status)
            assert msg["embeds"][0]["color"] == expected_color

    def test_gpu_info_included(self):
        gpu = [{"name": "A100", "utilization": "85%", "memory": "8192/16384 MiB", "temperature": "72C"}]
        msg = self._build(gpu_info=gpu)
        fields_text = json.dumps(msg["embeds"][0]["fields"])
        assert "A100" in fields_text

    def test_tail_lines_in_description(self):
        msg = self._build(tail_lines=["epoch 1 loss=0.5"])
        assert "epoch 1 loss=0.5" in msg["embeds"][0]["description"]

    def test_no_tail_lines_no_description(self):
        msg = self._build()
        assert "description" not in msg["embeds"][0]

    def test_command_in_footer(self):
        msg = self._build()
        assert "python train.py" in msg["embeds"][0]["footer"]["text"]

    def test_all_optional_fields(self):
        gpu = [{"name": "V100", "utilization": "50%", "memory": "4000/8000 MiB", "temperature": "60C"}]
        ram = {"used": "4000 MiB", "total": "8000 MiB", "percent": "50%"}
        cpu = {"percent": "25%", "cores": "8"}
        disk = {"used": "50.0 GiB", "total": "200.0 GiB", "percent": "25%"}
        msg = self._build(gpu_info=gpu, ram_info=ram, cpu_info=cpu, disk_info=disk)
        field_names = [f["name"] for f in msg["embeds"][0]["fields"]]
        assert "GPU" in field_names
        assert "RAM" in field_names
        assert "CPU" in field_names
        assert "Disk" in field_names

    def test_serializable(self):
        msg = self._build(status="completed", tail_lines=["done"], exit_code=0)
        assert isinstance(json.dumps(msg), str)


# --- build_email_body ---

class TestBuildEmailBody:
    def _build(self, **kwargs):
        return build_email_body(_make_data(**kwargs))

    def test_basic_content(self):
        body = self._build()
        assert "test-job" in body
        assert "Running" in body
        assert "1h 1m 1s" in body
        assert "python train.py" in body

    def test_failed_with_exit_code(self):
        body = self._build(status="failed", exit_code=1)
        assert "exit code 1" in body

    def test_gpu_info_included(self):
        gpu = [{"name": "A100", "utilization": "85%", "memory": "8192/16384 MiB", "temperature": "72C"}]
        body = self._build(gpu_info=gpu)
        assert "A100" in body

    def test_ram_info_included(self):
        ram = {"used": "8000 MiB", "total": "16000 MiB", "percent": "50%"}
        body = self._build(ram_info=ram)
        assert "8000 MiB" in body

    def test_cpu_info_included(self):
        cpu = {"percent": "42%", "cores": "16"}
        body = self._build(cpu_info=cpu)
        assert "42%" in body

    def test_disk_info_included(self):
        disk = {"used": "100.0 GiB", "total": "500.0 GiB", "percent": "20%"}
        body = self._build(disk_info=disk)
        assert "100.0 GiB" in body

    def test_tail_lines_included(self):
        body = self._build(tail_lines=["epoch 1 loss=0.5", "epoch 2 loss=0.3"])
        assert "Recent output" in body
        assert "epoch 2 loss=0.3" in body

    def test_no_tail_lines(self):
        body = self._build()
        assert "Recent output" not in body

    def test_no_optional_fields(self):
        body = self._build()
        assert "GPU" not in body
        assert "CPU" not in body
        assert "Disk" not in body
        assert "RAM" not in body


# --- config file ---

class TestConfigFile:
    def _make_args(self, **overrides):
        defaults = dict(
            interval="2h", backend="slack", webhook_url=None, name=None,
            tail=5, pid=None, log=None, no_gpu=False, no_ram=False,
            cpu=False, disk=False, email_to=None, email_from=None,
            smtp_server=None, smtp_port=25,
        )
        defaults.update(overrides)
        return argparse.Namespace(**defaults)

    def _make_config(self, sections):
        config = configparser.ConfigParser()
        for section, values in sections.items():
            config[section] = values
        return config

    def test_empty_config_no_change(self):
        args = self._make_args()
        config = self._make_config({})
        result = apply_config_defaults(args, config)
        assert result.interval == "2h"
        assert result.backend == "slack"
        assert result.tail == 5

    def test_defaults_section_applied(self):
        args = self._make_args()
        config = self._make_config({"defaults": {"interval": "1h", "tail": "50", "cpu": "true", "disk": "yes"}})
        result = apply_config_defaults(args, config)
        assert result.interval == "1h"
        assert result.tail == 50
        assert result.cpu is True
        assert result.disk is True

    def test_cli_overrides_config(self):
        args = self._make_args(interval="30m", cpu=True)
        config = self._make_config({"defaults": {"interval": "1h", "cpu": "false"}})
        result = apply_config_defaults(args, config)
        assert result.interval == "30m"
        assert result.cpu is True

    def test_backend_from_config(self):
        args = self._make_args()
        config = self._make_config({"defaults": {"backend": "discord"}})
        result = apply_config_defaults(args, config)
        assert result.backend == "discord"

    def test_slack_webhook_from_config(self):
        args = self._make_args()
        config = self._make_config({"slack": {"webhook_url": "https://hooks.slack.com/test"}})
        # Clear env var if set
        env_backup = os.environ.pop("SLACK_WEBHOOK_URL", None)
        try:
            result = apply_config_defaults(args, config)
            assert result.webhook_url == "https://hooks.slack.com/test"
        finally:
            if env_backup:
                os.environ["SLACK_WEBHOOK_URL"] = env_backup

    def test_discord_webhook_from_config(self):
        args = self._make_args(backend="discord")
        config = self._make_config({"defaults": {"backend": "discord"}, "discord": {"webhook_url": "https://discord.com/api/webhooks/test"}})
        env_backup = os.environ.pop("DISCORD_WEBHOOK_URL", None)
        try:
            result = apply_config_defaults(args, config)
            assert result.webhook_url == "https://discord.com/api/webhooks/test"
        finally:
            if env_backup:
                os.environ["DISCORD_WEBHOOK_URL"] = env_backup

    def test_email_from_config(self):
        args = self._make_args(backend="email")
        config = self._make_config({"email": {"to": "user@example.com", "from": "bot@host", "smtp_server": "mail.example.com", "smtp_port": "587"}})
        env_backup = os.environ.pop("JOBMONITOR_EMAIL_TO", None)
        try:
            result = apply_config_defaults(args, config)
            assert result.email_to == "user@example.com"
            assert result.email_from == "bot@host"
            assert result.smtp_server == "mail.example.com"
            assert result.smtp_port == 587
        finally:
            if env_backup:
                os.environ["JOBMONITOR_EMAIL_TO"] = env_backup

    def test_no_gpu_from_config(self):
        args = self._make_args()
        config = self._make_config({"defaults": {"no-gpu": "true", "no-ram": "yes"}})
        result = apply_config_defaults(args, config)
        assert result.no_gpu is True
        assert result.no_ram is True


# --- system info functions (smoke tests) ---

class TestSystemInfo:
    def test_get_ram_info(self):
        info = get_ram_info()
        if info is not None:
            assert "used" in info
            assert "total" in info
            assert "percent" in info

    def test_get_cpu_info(self):
        info = get_cpu_info()
        if info is not None:
            assert "percent" in info
            assert "cores" in info

    def test_get_disk_info(self):
        info = get_disk_info()
        if info is not None:
            assert "used" in info
            assert "total" in info
            assert "percent" in info
