"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, FileText, BookOpen, Zap, History, Map } from "lucide-react";
import AppShell from "@/components/AppShell";
import { ProjectListView } from "@/components/ProjectListView";
import { VaultNoteCard } from "@/components/VaultNoteCard";
import { VaultNoteDetail } from "@/components/VaultNoteDetail";
import { ProjectKnacksPanel } from "@/components/ProjectKnacksPanel";
import { ProjectSessionsPanel } from "@/components/ProjectSessionsPanel";
import { MemoryGraphPanel } from "@/components/MemoryGraphPanel";
import { api } from "@/lib/api";
import { useTranslation } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

function StatChip({ label, value }: { label: string; value: number }) {
  return (
    <div className="pi-chip">
      <span className="text-base font-semibold tabular-nums">{value}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  );
}

function ProjectDetailContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { t } = useTranslation();
  const slug = searchParams.get("slug");
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["project-workspace", slug],
    queryFn: () => api.projectWorkspace(slug as string),
    enabled: Boolean(slug),
  });

  const notes = useMemo(() => data?.workspace.notes ?? [], [data?.workspace.notes]);
  // Stabilize the graph inputs across unrelated re-renders so MemoryGraphPanel
  // doesn't see a new graphData reference (and restart the d3 simulation)
  // every time the parent rerenders for tabs/translations/etc.
  const graphNodes = useMemo(
    () => data?.workspace.graph.nodes ?? [],
    [data?.workspace.graph.nodes],
  );
  const graphEdges = useMemo(
    () => data?.workspace.graph.edges ?? [],
    [data?.workspace.graph.edges],
  );

  useEffect(() => {
    if (!selectedNoteId && notes.length > 0) {
      setSelectedNoteId(notes[0].memory_id);
    }
  }, [notes, selectedNoteId]);

  if (!slug) {
    return (
      <AppShell title={t.appShell.sidebar.projects}>
        <ProjectListView />
      </AppShell>
    );
  }

  const selectedNote = notes.find((n) => n.memory_id === selectedNoteId) ?? notes[0] ?? null;
  const stats = data?.workspace.stats;

  return (
    <AppShell title={data?.project.name ?? slug ?? ""}>
      {/* v0.3.58: back link inline so the header stays stable across routes. */}
      <div className="mb-2">
        <Button variant="ghost" size="sm" className="-ms-2" onClick={() => router.push("/projects")}>
          <ArrowLeft className="me-1 size-4" /> {t.projects.breadcrumb}
        </Button>
      </div>
      {data?.project.description && (
        <p className="text-muted-foreground mb-3 text-sm">{data.project.description}</p>
      )}
      <div className="mb-4 flex flex-wrap gap-2">
        <StatChip label={t.projects.notes} value={stats?.notes ?? 0} />
        <StatChip label={t.projects.nodes} value={stats?.nodes ?? 0} />
        <StatChip label={t.projects.edges} value={stats?.edges ?? 0} />
        <StatChip label={t.projects.tags} value={stats?.tags ?? 0} />
      </div>

      {/* Inner tabs — keep top-level menu minimal, surface
          memories / patterns / raw sessions inside the project view. */}
      <Tabs defaultValue="memories">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="memories" className="flex-1 gap-1.5 sm:flex-none">
            <BookOpen className="size-3.5" />
            {t.projects.tabMemories}
          </TabsTrigger>
          <TabsTrigger value="patterns" className="flex-1 gap-1.5 sm:flex-none">
            <Zap className="size-3.5" />
            {t.projects.tabKnacks}
          </TabsTrigger>
          <TabsTrigger value="sessions" className="flex-1 gap-1.5 sm:flex-none">
            <History className="size-3.5" />
            {t.projects.tabSessions}
          </TabsTrigger>
          <TabsTrigger value="graph" className="flex-1 gap-1.5 sm:flex-none">
            <Map className="size-3.5" />
            맥락 지도
          </TabsTrigger>
        </TabsList>

        <TabsContent value="memories" className="mt-4">
          <Card className="overflow-hidden lg:h-[calc(100vh-16rem)]">
            <div className="grid h-full lg:grid-cols-[minmax(0,340px)_minmax(0,1fr)]">
              <aside className="flex min-h-0 flex-col border-b lg:border-b-0 lg:border-r">
                <div className="flex-1 space-y-2 overflow-y-auto p-3">
                  {isLoading ? (
                    [1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)
                  ) : notes.length === 0 ? (
                    <div className="flex flex-col items-center gap-3 py-10 text-muted-foreground">
                      <FileText className="size-8" />
                      <p className="text-sm">{t.projects.noNotes}</p>
                    </div>
                  ) : (
                    notes.map((note) => (
                      <VaultNoteCard
                        key={note.memory_id}
                        note={note}
                        active={note.memory_id === selectedNote?.memory_id}
                        onSelect={(n) => setSelectedNoteId(n.memory_id)}
                      />
                    ))
                  )}
                </div>
              </aside>

              <section className="min-h-0 overflow-y-auto">
                <VaultNoteDetail note={selectedNote} />
              </section>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="mt-4">
          <ProjectKnacksPanel slug={slug} />
        </TabsContent>

        <TabsContent value="sessions" className="mt-4">
          <ProjectSessionsPanel slug={slug} />
        </TabsContent>

        <TabsContent value="graph" className="mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-16 text-muted-foreground text-sm">
              맥락 지도 불러오는 중…
            </div>
          ) : (
            <div className="h-[520px] overflow-hidden rounded-xl border bg-card">
              <MemoryGraphPanel nodes={graphNodes} edges={graphEdges} />
            </div>
          )}
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}

export default function ProjectsPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background p-12">
          <Skeleton className="mb-6 h-8 w-48" />
          <Skeleton className="mb-4 h-32 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      }
    >
      <ProjectDetailContent />
    </Suspense>
  );
}
