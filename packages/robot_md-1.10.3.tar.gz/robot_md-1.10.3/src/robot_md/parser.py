"""Parse a ROBOT.md file into frontmatter (dict) and body (markdown string)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import frontmatter
import yaml


class ParseError(Exception):
    """Raised when a ROBOT.md file cannot be parsed."""


@dataclass
class ParsedRobotMd:
    frontmatter: dict[str, Any]
    body: str
    source_path: Path | None = None


def parse_file(path: Path | str) -> ParsedRobotMd:
    """Parse a ROBOT.md file from disk.

    If `path` is a directory, resolves to ``<path>/ROBOT.md`` — so callers
    can pass either an explicit manifest file or its containing directory.
    This makes `robot-md compliance status .`, `robot-md validate ./bob`,
    and similar invocations work as users naturally expect (issue #32).
    """
    p = Path(path)
    if p.is_dir():
        candidate = p / "ROBOT.md"
        if not candidate.exists():
            raise ParseError(
                f"no ROBOT.md found in directory {p} — pass the manifest path "
                f"explicitly or `cd` into a directory containing one."
            )
        p = candidate
    elif not p.exists():
        raise ParseError(f"file not found: {p}")
    try:
        text = p.read_text()
    except OSError as e:
        raise ParseError(f"cannot read {p}: {e}") from e
    parsed = parse_text(text)
    return ParsedRobotMd(
        frontmatter=parsed.frontmatter,
        body=parsed.body,
        source_path=p,
    )


def parse_text(text: str) -> ParsedRobotMd:
    """Parse ROBOT.md content from a string."""
    if not text.lstrip().startswith("---"):
        raise ParseError(
            "no frontmatter found — ROBOT.md must start with a YAML frontmatter "
            "block delimited by '---'."
        )
    try:
        post = frontmatter.loads(text)
    except yaml.YAMLError as e:
        raise ParseError(f"frontmatter YAML parse error: {e}") from e
    except Exception as e:
        raise ParseError(f"frontmatter parse error: {e}") from e

    if not post.metadata:
        raise ParseError("frontmatter is empty or not a YAML mapping")

    fm = dict(post.metadata)
    _upgrade_legacy_camera(fm)
    return ParsedRobotMd(
        frontmatter=fm,
        body=post.content,
        source_path=None,
    )


def _upgrade_legacy_camera(fm: dict) -> None:
    """Move singular physics.solver.camera → physics.solver.cameras[0] in place.

    The first driver whose protocol looks camera-ish (`depthai`, `realsense`,
    `v4l2`, `zed`, `uvc`) is used as driver_id. If no such driver exists,
    fallback to the literal string 'camera' as driver_id. The upgrade always proceeds.
    """
    solver = fm.get("physics", {}).get("solver", {})
    legacy = solver.get("camera")
    if not isinstance(legacy, dict):
        return
    drivers = fm.get("drivers") or []
    camera_proto = {"depthai", "realsense", "v4l2", "zed", "uvc"}
    driver_id = next(
        (d["id"] for d in drivers if d.get("protocol") in camera_proto and d.get("id")),
        "camera",
    )

    upgraded = {
        "driver_id": driver_id,
        "primary_stream": "rgb",
        "mount": legacy.get("mount", "world"),
        "extrinsic": legacy.get("extrinsic"),
    }
    solver["cameras"] = [upgraded]
    solver.pop("camera", None)
    fm.setdefault("_deprecations", []).append(
        "physics.solver.camera (singular) is deprecated; upgraded to cameras[]."
    )
