#!/usr/bin/env python3
"""Tests for FastAPI integration with the @tool decorator and resources."""

import json
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from opal_tools_sdk import (
    UI,
    InteractionContext,
    ToolsService,
    _registry,
    interaction,
    resource,
    tool,
)
from pydantic import BaseModel, Field


from typing import Optional


class SimpleParams(BaseModel):
    """Simple tool parameters."""

    name: str = Field(description="The name to greet")


class TaskFormInput(BaseModel):
    """Input schema for the submit_task_form interaction."""

    title: str = Field(description="Task title")
    priority: str = Field(default="medium", description="Task priority level")
    assignee: Optional[str] = Field(default=None, description="Assignee email address")


@pytest.fixture(autouse=True)
def clear_registry():
    """Clear the global registry before each test."""
    _registry.services.clear()
    yield
    _registry.services.clear()


def test_simple_tool_endpoint():
    """Test that a simple tool creates a working endpoint"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="greet", description="Greet a user")
    async def greet_tool(params: SimpleParams, environment: dict) -> str:
        """Greet tool."""
        return f"Hello, {params.name}!"

    client = TestClient(app)

    # Call the endpoint (returns result directly, not wrapped in response envelope)
    response = client.post("/tools/greet", json={"name": "Alice"})

    assert response.status_code == 200
    # Verify correct content-type header for regular tools (application/json)
    assert response.headers["content-type"] == "application/json"
    assert response.json() == "Hello, Alice!"


def test_environment_parameter_passed():
    """Test that environment parameter is correctly passed to the tool"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="check_env", description="Check environment")
    async def check_env(params: SimpleParams, environment: dict) -> dict:
        """Check environment tool."""
        return {
            "has_environment": environment is not None,
            "param_name": params.name,
        }

    client = TestClient(app)

    # Call the endpoint
    response = client.post("/tools/check_env", json={"name": "Test"})

    assert response.status_code == 200
    assert response.json() == {
        "has_environment": True,
        "param_name": "Test",
    }


def test_invalid_parameters():
    """Test that invalid parameters return proper error"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="validate_params", description="Validate parameters")
    async def validate_params(params: SimpleParams, environment: dict) -> str:
        """Validate params tool."""
        return f"Valid: {params.name}"

    client = TestClient(app)

    # Call with missing required parameter
    response = client.post("/tools/validate_params", json={})

    assert response.status_code == 400  # Validation error (Pydantic ValidationError)


def test_multiple_tools_same_service():
    """Test that multiple tools can be registered on the same service"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="tool_one", description="First tool")
    async def tool_one(params: SimpleParams, environment: dict) -> str:
        """Tool one."""
        return "Tool 1"

    @tool(name="tool_two", description="Second tool")
    async def tool_two(params: SimpleParams, environment: dict) -> str:
        """Tool two."""
        return "Tool 2"

    client = TestClient(app)

    # Call both endpoints
    response1 = client.post("/tools/tool_one", json={"name": "Test"})
    response2 = client.post("/tools/tool_two", json={"name": "Test"})

    assert response1.status_code == 200
    assert response2.status_code == 200
    assert response1.json() == "Tool 1"
    assert response2.json() == "Tool 2"


def test_resource_endpoint():
    """Test that a resource endpoint returns correct content."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/form",
        name="test-form",
        description="A test form",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_form() -> str:
        """Get test form."""
        proteus_spec = {"type": "form", "fields": [{"name": "title", "type": "text"}]}
        return json.dumps(proteus_spec)

    client = TestClient(app)

    # Call the resource endpoint via POST /resources/read
    response = client.post("/resources/read", json={"uri": "ui://test-app/form"})

    assert response.status_code == 200
    assert response.json() == {
        "uri": "ui://test-app/form",
        "mimeType": "application/vnd.opal.proteus+json",
        "text": '{"type": "form", "fields": [{"name": "title", "type": "text"}]}',
    }


def test_tool_with_ui_resource():
    """Test that a tool can declare an associated UI resource."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/create-form",
        name="create-form",
        description="Form for creating items",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_create_form() -> str:
        """Get create form."""
        return "{}"

    @tool(
        name="create_item",
        description="Create a new item",
        ui_resource="ui://test-app/create-form",
    )
    async def create_item(params: SimpleParams) -> dict:
        """Create item tool."""
        return {"id": "item-123", "title": params.name}

    client = TestClient(app)

    # Call discovery endpoint
    response = client.get("/discovery")

    assert response.status_code == 200
    discovery = response.json()

    # Verify function has ui_resource
    assert len(discovery["functions"]) == 1
    function = discovery["functions"][0]
    assert function["name"] == "create_item"
    assert function["ui_resource"] == "ui://test-app/create-form"


def test_discovery():
    """Test that discovery works."""
    app = FastAPI()
    _ = ToolsService(app)

    @tool(name="simple_tool", description="A simple tool")
    async def simple_tool(params: SimpleParams) -> dict:
        """Simple tool."""
        return {"result": "ok"}

    client = TestClient(app)

    # Call discovery endpoint
    response = client.get("/discovery")

    assert response.status_code == 200
    assert response.json() == {
        "functions": [
            {
                "name": "simple_tool",
                "description": "A simple tool",
                "parameters": [
                    {
                        "name": "name",
                        "in_context": False,
                        "description": "The name to greet",
                        "required": True,
                        "type": "string",
                    }
                ],
                "endpoint": "/tools/simple_tool",
                "http_method": "POST",
            }
        ]
    }


def test_multiple_resources():
    """Test registering multiple resources."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/form1",
        name="form1",
        description="First form",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_form1() -> str:
        """Get form 1."""
        return "{}"

    @resource(
        uri="ui://test-app/form2",
        name="form2",
        description="Second form",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_form2() -> str:
        """Get form 2."""
        return "{}"

    client = TestClient(app)

    # Verify both resources are accessible via POST /resources/read
    response1 = client.post("/resources/read", json={"uri": "ui://test-app/form1"})
    assert response1.status_code == 200
    assert response1.json()["uri"] == "ui://test-app/form1"

    response2 = client.post("/resources/read", json={"uri": "ui://test-app/form2"})
    assert response2.status_code == 200
    assert response2.json()["uri"] == "ui://test-app/form2"


def test_resource_with_proteus_document_return():
    """Test that a resource returning ProteusDocument is auto-serialized."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/dynamic-form",
        name="dynamic-form",
        description="A dynamic form using UI.Document",
    )
    async def get_dynamic_form():
        """Get dynamic form as ProteusDocument."""
        return UI.Document(
            appName="Item Manager",
            title="Create New Item",
            body=[
                UI.Heading(children="Create Item"),
                UI.Field(
                    label="Item Name",
                    children=UI.Input(name="item_name", placeholder="Enter item name"),
                ),
                UI.Field(
                    label="Description",
                    children=UI.Textarea(name="description", placeholder="Enter description"),
                ),
            ],
            actions=[
                UI.Action(children="Save", appearance="primary"),
            ],
        )

    client = TestClient(app)

    # Call the resource endpoint
    response = client.post("/resources/read", json={"uri": "ui://test-app/dynamic-form"})

    assert response.status_code == 200
    result = response.json()

    # Verify URI
    assert result["uri"] == "ui://test-app/dynamic-form"

    # Verify MIME type was auto-set
    assert result["mimeType"] == "application/vnd.opal.proteus+json"

    # Verify the text is a serialized ProteusDocument
    parsed_doc = json.loads(result["text"])
    assert parsed_doc["$type"] == "Document"
    assert len(parsed_doc["body"]) == 3
    assert parsed_doc["body"][0]["$type"] == "Heading"
    assert parsed_doc["body"][0]["children"] == "Create Item"
    assert parsed_doc["body"][1]["$type"] == "Field"
    assert parsed_doc["body"][1]["label"] == "Item Name"
    assert len(parsed_doc["actions"]) == 2
    assert parsed_doc["actions"][0]["$type"] == "Action"


def test_resource_with_proteus_document_and_explicit_mime_type():
    """Test that explicit MIME type is preserved when returning ProteusDocument."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/custom-mime",
        name="custom-mime",
        description="ProteusDocument with custom MIME type",
        mime_type="application/custom+json",
    )
    async def get_custom():
        """Get custom resource."""
        return UI.Document(
            appName="Test App",
            title="Test Document",
            body=[UI.Text(children="Test")],
        )

    client = TestClient(app)

    # Call the resource endpoint
    response = client.post("/resources/read", json={"uri": "ui://test-app/custom-mime"})

    assert response.status_code == 200
    result = response.json()

    # Verify explicit MIME type is preserved (not auto-set)
    assert result["mimeType"] == "application/custom+json"


def test_interaction_endpoint():
    """Test that an interaction handler creates a working endpoint."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(
        name="submit_task_form",
        description="Handle task form submission",
    )
    async def handle_task_submission(parameters: TaskFormInput, context: InteractionContext):
        return {
            "task_id": "task-123",
            "message": f"Task '{parameters.title}' created",
            "priority": parameters.priority,
        }

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={"name": "submit_task_form", "parameters": {"title": "My Task"}},
    )

    assert response.status_code == 200
    assert response.json() == {
        "task_id": "task-123",
        "message": "Task 'My Task' created",
        "priority": "medium",
    }


def test_interaction_with_auth_data():
    """Test that auth data is passed through to the interaction context."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(name="authed_action", description="Action requiring auth")
    async def authed_action(parameters: dict, context: InteractionContext):
        return {
            "has_auth": context.auth_data is not None,
            "provider": context.auth_data.get("provider") if context.auth_data else None,
        }

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={
            "name": "authed_action",
            "parameters": {},
            "auth": {"provider": "google", "credentials": {"access_token": "tok"}},
        },
    )

    assert response.status_code == 200
    assert response.json() == {"has_auth": True, "provider": "google"}


def test_interaction_not_found():
    """Test that calling a nonexistent interaction returns 404."""
    app = FastAPI()
    _ = ToolsService(app)

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={"name": "nonexistent", "parameters": {}},
    )

    assert response.status_code == 404
    assert "not found" in response.json()["detail"]


def test_interaction_missing_name():
    """Test that a request without a name returns 400."""
    app = FastAPI()
    _ = ToolsService(app)

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={"parameters": {}},
    )

    assert response.status_code == 400
    assert "Missing 'name'" in response.json()["detail"]


def test_interaction_handler_error():
    """Test that a handler exception returns 500."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(name="failing_action", description="Will fail")
    async def failing_action(parameters: dict, context: InteractionContext):
        raise RuntimeError("Something went wrong")

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={"name": "failing_action", "parameters": {}},
    )

    assert response.status_code == 500
    assert "Something went wrong" in response.json()["detail"]


def test_multiple_interactions():
    """Test registering and calling multiple interactions."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(name="action_one", description="First action")
    async def action_one(parameters: dict, context: InteractionContext):
        return {"action": "one"}

    @interaction(name="action_two", description="Second action")
    async def action_two(parameters: dict, context: InteractionContext):
        return {"action": "two"}

    client = TestClient(app)

    r1 = client.post("/interactions/execute", json={"name": "action_one", "parameters": {}})
    r2 = client.post("/interactions/execute", json={"name": "action_two", "parameters": {}})

    assert r1.status_code == 200
    assert r1.json() == {"action": "one"}
    assert r2.status_code == 200
    assert r2.json() == {"action": "two"}


def test_interaction_default_parameters():
    """Test that parameters defaults to empty dict when omitted."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(name="no_params", description="No params needed")
    async def no_params(parameters: dict, context: InteractionContext):
        return {"received": parameters}

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={"name": "no_params"},
    )

    assert response.status_code == 200
    assert response.json() == {"received": {}}


def test_interaction_name_conflicts_with_tool():
    """Test that registering an interaction with the same name as a tool raises ValueError."""
    app = FastAPI()
    _ = ToolsService(app)

    @tool(name="shared_name", description="A tool")
    async def my_tool(params: SimpleParams) -> dict:
        return {"result": "ok"}

    with pytest.raises(ValueError, match="conflicts with an existing tool name"):

        @interaction(name="shared_name", description="Conflicting interaction")
        async def my_interaction(parameters: dict, context: InteractionContext):
            return {}


def test_tool_name_conflicts_with_interaction():
    """Test that registering a tool with the same name as an interaction raises ValueError."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(name="shared_name", description="An interaction")
    async def my_interaction(parameters: dict, context: InteractionContext):
        return {}

    with pytest.raises(ValueError, match="conflicts with an existing interaction name"):

        @tool(name="shared_name", description="Conflicting tool")
        async def my_tool(params: SimpleParams) -> dict:
            return {"result": "ok"}


def test_duplicate_interaction_name():
    """Test that registering two interactions with the same name raises ValueError."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(name="dupe", description="First")
    async def first(parameters: dict, context: InteractionContext):
        return {}

    with pytest.raises(ValueError, match="already registered"):

        @interaction(name="dupe", description="Second")
        async def second(parameters: dict, context: InteractionContext):
            return {}


def test_tool_and_interaction_different_names_ok():
    """Test that a tool and interaction with different names coexist fine."""
    app = FastAPI()
    _ = ToolsService(app)

    @tool(name="my_tool", description="A tool")
    async def my_tool(params: SimpleParams) -> dict:
        return {"from": "tool"}

    @interaction(name="my_interaction", description="An interaction")
    async def my_interaction(parameters: dict, context: InteractionContext):
        return {"from": "interaction"}

    client = TestClient(app)

    # Both should work
    tool_resp = client.post("/tools/my_tool", json={"name": "Test"})
    assert tool_resp.status_code == 200
    assert tool_resp.json() == {"from": "tool"}

    interaction_resp = client.post(
        "/interactions/execute",
        json={"name": "my_interaction", "parameters": {}},
    )
    assert interaction_resp.status_code == 200
    assert interaction_resp.json() == {"from": "interaction"}


def test_interaction_extracts_parameters_from_pydantic_model():
    """Test that @interaction extracts parameter definitions from a Pydantic model."""
    app = FastAPI()
    svc = ToolsService(app)

    @interaction(
        name="typed_action",
        description="Action with typed params",
    )
    async def typed_action(parameters: TaskFormInput, context: InteractionContext):
        return {}

    # Verify parameters were extracted and stored
    interaction_info = svc.interactions["typed_action"]
    params = interaction_info["parameters"]

    assert len(params) == 3

    # title: str, required
    title_param = next(p for p in params if p.name == "title")
    assert title_param.param_type.value == "string"
    assert title_param.description == "Task title"
    assert title_param.required is True

    # priority: str, default="medium", not required
    priority_param = next(p for p in params if p.name == "priority")
    assert priority_param.param_type.value == "string"
    assert priority_param.description == "Task priority level"
    assert priority_param.required is False

    # assignee: Optional[str], not required
    assignee_param = next(p for p in params if p.name == "assignee")
    assert assignee_param.param_type.value == "string"
    assert assignee_param.description == "Assignee email address"
    assert assignee_param.required is False


def test_interaction_pydantic_validation_error():
    """Test that invalid parameters for a Pydantic-typed interaction return 400."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(
        name="validated_action",
        description="Action with validation",
    )
    async def validated_action(parameters: TaskFormInput, context: InteractionContext):
        return {"title": parameters.title}

    client = TestClient(app)

    # Call with missing required 'title' field
    response = client.post(
        "/interactions/execute",
        json={"name": "validated_action", "parameters": {}},
    )

    assert response.status_code == 400


def test_interaction_pydantic_model_with_all_fields():
    """Test that a Pydantic-typed interaction receives all fields correctly."""
    app = FastAPI()
    _ = ToolsService(app)

    @interaction(
        name="full_form",
        description="Form with all fields",
    )
    async def full_form(parameters: TaskFormInput, context: InteractionContext):
        return {
            "title": parameters.title,
            "priority": parameters.priority,
            "assignee": parameters.assignee,
        }

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={
            "name": "full_form",
            "parameters": {
                "title": "My Task",
                "priority": "high",
                "assignee": "alice@example.com",
            },
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "title": "My Task",
        "priority": "high",
        "assignee": "alice@example.com",
    }


def test_interaction_dict_handler_still_works():
    """Test that interactions with dict-typed parameters still work (backward compat)."""
    app = FastAPI()
    svc = ToolsService(app)

    @interaction(
        name="dict_action",
        description="Action with dict params",
    )
    async def dict_action(parameters: dict, context: InteractionContext):
        return {"received": parameters}

    # No parameters should be extracted for dict-typed handler
    interaction_info = svc.interactions["dict_action"]
    assert interaction_info["parameters"] == []

    client = TestClient(app)

    response = client.post(
        "/interactions/execute",
        json={"name": "dict_action", "parameters": {"any_key": "any_value"}},
    )

    assert response.status_code == 200
    assert response.json() == {"received": {"any_key": "any_value"}}


def test_interaction_pydantic_various_types():
    """Test that @interaction correctly extracts various parameter types."""
    app = FastAPI()
    svc = ToolsService(app)

    class MultiTypeInput(BaseModel):
        name: str = Field(description="A string field")
        count: int = Field(description="An integer field")
        score: float = Field(description="A float field")
        active: bool = Field(description="A boolean field")
        tags: list = Field(default=[], description="A list field")
        metadata: dict = Field(default={}, description="A dict field")

    @interaction(name="multi_type", description="Various types")
    async def multi_type(parameters: MultiTypeInput, context: InteractionContext):
        return {"name": parameters.name, "count": parameters.count}

    params = svc.interactions["multi_type"]["parameters"]
    assert len(params) == 6

    param_map = {p.name: p for p in params}
    assert param_map["name"].param_type.value == "string"
    assert param_map["count"].param_type.value == "integer"
    assert param_map["score"].param_type.value == "number"
    assert param_map["active"].param_type.value == "boolean"
    assert param_map["tags"].param_type.value == "array"
    assert param_map["metadata"].param_type.value == "object"
