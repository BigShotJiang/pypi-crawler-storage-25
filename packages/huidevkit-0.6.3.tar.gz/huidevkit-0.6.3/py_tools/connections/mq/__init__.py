#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author: Hui
# @Desc: { 消息队列连接处理 }
# @Date: 2023/05/03 21:12
"""Experimental MQ namespace.

RabbitMQ / Kafka helpers are placeholders and are not part of the stable
public API yet.
"""

__all__ = []
