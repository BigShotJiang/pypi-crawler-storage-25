#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author: Hui
# @Desc: { websocket连接与房间管理 }
# @Date: 2026/04/02
import asyncio
from collections import defaultdict
from typing import Any, Dict, Iterable, Set


class WebSocketHub:
    """管理 WebSocket 连接、房间与广播。

    该管理器在内存中维护连接对象和房间成员关系，适合单进程实时场景下
    的房间消息路由与广播能力。

    Attributes:
        client_map: ``client_id`` 到 websocket 连接对象的映射。
        room_map: ``room_id`` 到已加入 ``client_id`` 集合的映射。
    """

    def __init__(self):
        self.client_map: Dict[str, Any] = {}
        self.room_map: Dict[str, Set[str]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def register(self, client_id: str, websocket: Any):
        """注册客户端对应的 websocket 连接。

        Args:
            client_id: 已连接客户端的唯一标识。
            websocket: 提供 ``send_json`` 方法的 websocket 对象。
        """
        async with self._lock:
            self.client_map[client_id] = websocket

    async def unregister(self, client_id: str):
        """移除客户端并清理其所有房间成员关系。

        Args:
            client_id: 已连接客户端的唯一标识。
        """
        async with self._lock:
            self.client_map.pop(client_id, None)
            empty_rooms = []
            for room_id, client_ids in self.room_map.items():
                client_ids.discard(client_id)
                if not client_ids:
                    empty_rooms.append(room_id)

            for room_id in empty_rooms:
                self.room_map.pop(room_id, None)

    async def join_room(self, client_id: str, room_id: str):
        """将已注册客户端加入房间。

        Args:
            client_id: 已连接客户端的唯一标识。
            room_id: 逻辑房间名称。

        Raises:
            KeyError: 当客户端尚未注册时抛出。
        """
        async with self._lock:
            if client_id not in self.client_map:
                raise KeyError(f"client_id not found: {client_id}")
            self.room_map[room_id].add(client_id)

    async def leave_room(self, client_id: str, room_id: str):
        """将客户端移出房间。

        Args:
            client_id: 已连接客户端的唯一标识。
            room_id: 逻辑房间名称。
        """
        async with self._lock:
            client_ids = self.room_map.get(room_id)
            if not client_ids:
                return

            client_ids.discard(client_id)
            if not client_ids:
                self.room_map.pop(room_id, None)

    async def get_room_members(self, room_id: str) -> Set[str]:
        """返回房间当前成员的副本集合。

        Args:
            room_id: 逻辑房间名称。

        Returns:
            当前房间内客户端标识的拷贝集合。
        """
        async with self._lock:
            return set(self.room_map.get(room_id, set()))

    async def send_to_client(self, client_id: str, message: Any):
        """向单个客户端发送 JSON 消息。

        发送失败时会自动注销该客户端，避免在内存中残留失效连接。

        Args:
            client_id: 目标客户端标识。
            message: 可被 JSON 序列化的消息载荷。

        Raises:
            KeyError: 当目标客户端未注册时抛出。
            Exception: 清理后继续抛出底层发送异常。
        """
        websocket = self.client_map.get(client_id)
        if websocket is None:
            raise KeyError(f"client_id not found: {client_id}")

        try:
            await websocket.send_json(message)
        except Exception:
            await self.unregister(client_id)
            raise

    async def broadcast(self, message: Any):
        """向所有已注册客户端广播 JSON 消息。

        Args:
            message: 可被 JSON 序列化的消息载荷。
        """
        await self._broadcast_to_clients(list(self.client_map.keys()), message)

    async def broadcast_room(self, room_id: str, message: Any):
        """向房间内所有客户端广播 JSON 消息。

        Args:
            room_id: 逻辑房间名称。
            message: 可被 JSON 序列化的消息载荷。
        """
        client_ids = await self.get_room_members(room_id)
        if not client_ids:
            return
        await self._broadcast_to_clients(client_ids, message)

    async def _broadcast_to_clients(self, client_ids: Iterable[str], message: Any):
        """并发向多个客户端发送 JSON 消息。

        广播完成后会清理发送失败的失效连接。

        Args:
            client_ids: 需要接收消息的客户端标识迭代器。
            message: 可被 JSON 序列化的消息载荷。
        """
        tasks = []
        client_id_list = list(client_ids)
        for client_id in client_id_list:
            websocket = self.client_map.get(client_id)
            if websocket is None:
                continue
            tasks.append(websocket.send_json(message))

        if not tasks:
            return

        results = await asyncio.gather(*tasks, return_exceptions=True)
        failed_client_ids = [
            client_id for client_id, result in zip(client_id_list, results) if isinstance(result, Exception)
        ]
        for client_id in failed_client_ids:
            await self.unregister(client_id)
