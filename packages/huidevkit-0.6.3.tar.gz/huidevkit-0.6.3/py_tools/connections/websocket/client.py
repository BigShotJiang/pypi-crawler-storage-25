#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author: Hui
# @Desc: { websocket客户端 }
# @Date: 2026/04/02
import json
from datetime import timedelta
from typing import Any, AsyncGenerator, Optional

import aiohttp
from aiohttp import ClientWebSocketResponse, WSMessage, WSMsgType


class AsyncWebSocketClient:
    """基于 aiohttp 的异步 WebSocket 客户端。

    该客户端封装了 ``aiohttp.ClientSession.ws_connect``，提供连接管理、
    消息发送、消息接收以及异步上下文管理等基础能力。

    Examples:
        >>> async with AsyncWebSocketClient("ws://localhost:8000/ws") as client:
        >>>     await client.send_json({"event": "ping"})
        >>>     resp = await client.recv_json()
        >>>     print(resp)
    """

    def __init__(
        self,
        url: str,
        timeout: timedelta = timedelta(seconds=10),
        headers: Optional[dict] = None,
        heartbeat: Optional[float] = None,
        session: aiohttp.ClientSession = None,
        **kwargs,
    ):
        self.url = url
        self.timeout = timeout
        self.headers = headers or {}
        self.heartbeat = heartbeat
        self.session = session
        self.ws: ClientWebSocketResponse = None
        self._session_owner = session is None
        self.kwargs = kwargs

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def _get_client_session(self) -> aiohttp.ClientSession:
        if self.session is not None and not self.session.closed:
            return self.session

        client_timeout = self.timeout
        if isinstance(client_timeout, timedelta):
            client_timeout = aiohttp.ClientTimeout(total=client_timeout.total_seconds())

        self.session = aiohttp.ClientSession(headers=self.headers, timeout=client_timeout)
        self._session_owner = True
        return self.session

    async def connect(self) -> ClientWebSocketResponse:
        """建立 WebSocket 连接，若已连接则直接复用。

        Returns:
            当前可用的 aiohttp websocket 连接对象。
        """
        if self.ws is not None and not self.ws.closed:
            return self.ws

        session = await self._get_client_session()
        self.ws = await session.ws_connect(self.url, heartbeat=self.heartbeat, **self.kwargs)
        return self.ws

    async def close(self):
        """关闭 WebSocket 连接，并在需要时关闭当前客户端持有的 Session。"""
        if self.ws is not None and not self.ws.closed:
            await self.ws.close()

        if self._session_owner and self.session is not None and not self.session.closed:
            await self.session.close()

    async def ping(self, message: bytes = b""):
        """发送 websocket ping 帧。

        Args:
            message: 可选的 ping 载荷。
        """
        ws = await self.connect()
        await ws.ping(message)

    async def send_text(self, data: str):
        """发送文本消息。

        Args:
            data: 待发送的文本内容。
        """
        ws = await self.connect()
        await ws.send_str(data)

    async def send_bytes(self, data: bytes):
        """发送二进制消息。

        Args:
            data: 待发送的二进制内容。
        """
        ws = await self.connect()
        await ws.send_bytes(data)

    async def send_json(self, data: Any, dumps=json.dumps):
        """发送 JSON 消息。

        Args:
            data: 可被 JSON 序列化的待发送载荷。
            dumps: aiohttp 使用的 JSON 序列化函数。
        """
        ws = await self.connect()
        await ws.send_json(data, dumps=dumps)

    async def receive(self) -> WSMessage:
        """接收原始 websocket 消息对象。

        Returns:
            aiohttp 原始 websocket 消息对象。
        """
        ws = await self.connect()
        return await ws.receive()

    async def recv(self) -> Any:
        """接收一条消息并返回其原始载荷。

        Returns:
            文本帧或二进制帧的原始载荷；若连接正在关闭或已经关闭则返回 ``None``。

        Raises:
            Exception: 透传 aiohttp websocket 的错误帧异常。
        """
        message = await self.receive()
        if message.type in {WSMsgType.TEXT, WSMsgType.BINARY}:
            return message.data

        if message.type in {WSMsgType.CLOSE, WSMsgType.CLOSED, WSMsgType.CLOSING}:
            return None

        if message.type == WSMsgType.ERROR:
            raise message.data

        return message.data

    async def recv_json(self, loads=json.loads) -> Any:
        """接收一条 JSON 文本消息并完成反序列化。

        Args:
            loads: JSON 反序列化函数。

        Returns:
            反序列化后的 JSON 数据；若连接正在关闭或已经关闭则返回 ``None``。

        Raises:
            Exception: 透传 aiohttp websocket 的错误帧异常。
            TypeError: 当接收到的消息不是文本帧时抛出。
        """
        message = await self.receive()
        if message.type == WSMsgType.TEXT:
            return loads(message.data)

        if message.type in {WSMsgType.CLOSE, WSMsgType.CLOSED, WSMsgType.CLOSING}:
            return None

        if message.type == WSMsgType.ERROR:
            raise message.data

        raise TypeError("websocket message is not text json")

    async def iter_messages(self) -> AsyncGenerator[WSMessage, None]:
        """持续迭代接收 websocket 消息直到连接关闭。

        Yields:
            aiohttp 原始 websocket 消息对象。
        """
        ws = await self.connect()
        async for message in ws:
            yield message
