"""huidevkit package.

Top-level package intentionally keeps a narrow public surface.
Utilities should be imported from their owning submodules, e.g.
`py_tools.utils`, `py_tools.connections.http`, `py_tools.logging`.
"""

__version__ = "0.6.3"

__all__ = ["__version__"]
