#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author: Hui
# @Desc: { 配置工具类模块 }
# @Date: 2026/04/02
import json
import os
from pathlib import Path
from typing import Any, Optional, Type, TypeVar, Union, get_origin

from pydantic import TypeAdapter
from pydantic_core import PydanticUndefined
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic_settings.sources import DotEnvSettingsSource, EnvSettingsSource, InitSettingsSource
import yaml

T_BaseSettings = TypeVar("T_BaseSettings", bound=BaseSettings)


class BaseConfigSettings(BaseSettings):
    """统一的配置基类，默认支持读取 `.env` 文件。"""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


class ConfigUtil:
    """统一配置读取工具类。"""

    @staticmethod
    def _type_to_str(annotation: Any) -> str:
        """将注解转换为可读字符串。"""
        if annotation is None:
            return "Any"

        if hasattr(annotation, "__name__"):
            return annotation.__name__

        return str(annotation).replace("typing.", "")

    @staticmethod
    def _build_env_name(field_name: str, field_info, env_prefix: str = "") -> str:
        """构造字段对应的环境变量名。"""
        env_name = field_info.alias or field_name
        if not field_info.alias:
            env_name = f"{env_prefix}{field_name}".upper()
        return env_name

    @staticmethod
    def _deep_merge(base_data: dict, override_data: dict) -> dict:
        """递归合并字典，`override_data` 优先级更高。"""
        merged_data = dict(base_data)
        for key, value in override_data.items():
            if isinstance(value, dict) and isinstance(merged_data.get(key), dict):
                merged_data[key] = ConfigUtil._deep_merge(merged_data[key], value)
            else:
                merged_data[key] = value
        return merged_data

    @staticmethod
    def merge_sources(*sources: Optional[dict]) -> dict:
        """
        按传入顺序合并多个配置源，后者优先级更高。
        """
        merged_data = {}
        for source in sources:
            if not source:
                continue
            merged_data = ConfigUtil._deep_merge(merged_data, source)
        return merged_data

    @staticmethod
    def find_env_file(start_path: Union[str, Path, None] = None, filename: str = ".env") -> Optional[Path]:
        """
        自底向上查找 `.env` 文件。

        Args:
            start_path: 起始目录或文件路径，默认为当前工作目录
            filename: 需要查找的文件名，默认 `.env`

        Returns:
            找到时返回文件路径，否则返回 None
        """
        search_path = Path(start_path or Path.cwd()).resolve()
        if search_path.is_file():
            search_path = search_path.parent

        for cur_dir in (search_path, *search_path.parents):
            env_file = cur_dir / filename
            if env_file.exists():
                return env_file
        return None

    @classmethod
    def get_env(
        cls,
        env_key: str,
        default: Any = None,
        value_type: Type = None,
        strip: bool = True,
    ):
        """
        读取环境变量，并按需要做类型转换。

        Args:
            env_key: 环境变量名称
            default: 环境变量不存在时返回的默认值
            value_type: 指定需要转换的目标类型
            strip: 字符串类型是否先做去空白处理

        Returns:
            环境变量值或默认值
        """
        value = os.getenv(env_key)
        if value is None:
            return default

        if strip and isinstance(value, str):
            value = value.strip()

        if value_type is None:
            return value

        return cls.cast_value(value, value_type)

    @classmethod
    def require_env(cls, env_key: str, value_type: Type = None, strip: bool = True):
        """
        强制读取环境变量，不存在时直接抛错。
        """
        if env_key not in os.environ:
            raise KeyError(f"env `{env_key}` is required")
        return cls.get_env(env_key, value_type=value_type, strip=strip)

    @staticmethod
    def cast_value(value: Any, value_type: Type):
        """
        将值转换为指定类型。
        """
        adapter = TypeAdapter(value_type)
        origin_type = get_origin(value_type)
        complex_type = origin_type in (list, dict, tuple, set) or value_type in (list, dict, tuple, set)

        try:
            if complex_type and isinstance(value, str):
                value = json.loads(value)
            return adapter.validate_python(value)
        except Exception as e:
            raise ValueError(f"failed to cast value `{value}` to {value_type}") from e

    @staticmethod
    def load_yaml(yaml_file: Union[str, Path]) -> dict:
        """
        读取 YAML 配置文件。

        Args:
            yaml_file: YAML 文件路径

        Returns:
            解析后的字典
        """
        yaml_path = Path(yaml_file).expanduser().resolve()
        if not yaml_path.exists():
            raise FileNotFoundError(f"yaml file `{yaml_path}` does not exist")

        with yaml_path.open("r", encoding="utf-8") as fp:
            yaml_data = yaml.safe_load(fp) or {}

        if not isinstance(yaml_data, dict):
            raise ValueError("yaml config root must be a mapping object")

        return yaml_data

    @classmethod
    def load_settings(
        cls,
        settings_cls: Type[T_BaseSettings],
        env_file: Union[str, Path, None] = None,
        env_file_encoding: str = "utf-8",
        **kwargs,
    ) -> T_BaseSettings:
        """
        统一构造 Pydantic Settings 对象。

        Args:
            settings_cls: 继承自 BaseSettings 的配置类
            env_file: 指定 `.env` 文件路径；不传时使用 settings 自身默认配置
            env_file_encoding: `.env` 文件编码
            **kwargs: 其他 settings 初始化参数

        Returns:
            构造完成的 settings 实例
        """
        if env_file is None:
            return settings_cls(**kwargs)

        return settings_cls(
            _env_file=str(Path(env_file).expanduser().resolve()),
            _env_file_encoding=env_file_encoding,
            **kwargs,
        )

    @classmethod
    def load_merged_settings(
        cls,
        settings_cls: Type[T_BaseSettings],
        *,
        yaml_file: Union[str, Path, None] = None,
        env_file: Union[str, Path, None] = None,
        env_file_encoding: str = "utf-8",
        **kwargs,
    ) -> T_BaseSettings:
        """
        统一加载多来源配置。

        优先级：
            显式传参(kwargs) > 环境变量 > .env > yaml > 默认值
        """
        model_config = getattr(settings_cls, "model_config", {}) or {}

        yaml_data = cls.load_yaml(yaml_file) if yaml_file else {}

        init_source = InitSettingsSource(settings_cls=settings_cls, init_kwargs=kwargs)
        env_source = EnvSettingsSource(
            settings_cls=settings_cls,
            case_sensitive=model_config.get("case_sensitive"),
            env_prefix=model_config.get("env_prefix"),
            env_nested_delimiter=model_config.get("env_nested_delimiter"),
            env_nested_max_split=model_config.get("env_nested_max_split"),
            env_ignore_empty=model_config.get("env_ignore_empty"),
            env_parse_none_str=model_config.get("env_parse_none_str"),
            env_parse_enums=model_config.get("env_parse_enums"),
        )
        dotenv_source = DotEnvSettingsSource(
            settings_cls=settings_cls,
            env_file=str(Path(env_file).expanduser().resolve()) if env_file else model_config.get("env_file"),
            env_file_encoding=env_file_encoding,
            case_sensitive=model_config.get("case_sensitive"),
            env_prefix=model_config.get("env_prefix"),
            env_nested_delimiter=model_config.get("env_nested_delimiter"),
            env_nested_max_split=model_config.get("env_nested_max_split"),
            env_ignore_empty=model_config.get("env_ignore_empty"),
            env_parse_none_str=model_config.get("env_parse_none_str"),
            env_parse_enums=model_config.get("env_parse_enums"),
        )

        merged_data = cls.merge_sources(yaml_data, dotenv_source(), env_source(), init_source())
        return settings_cls.model_validate(merged_data)

    @classmethod
    def describe_settings(cls, settings_cls: Type[T_BaseSettings]) -> list[dict]:
        """
        获取 settings 类的字段说明。
        """
        model_config = getattr(settings_cls, "model_config", {}) or {}
        env_prefix = model_config.get("env_prefix", "") or ""

        field_descriptions = []
        for field_name, field_info in settings_cls.model_fields.items():
            is_required = field_info.is_required()
            default_value = None if is_required else field_info.default
            if default_value is PydanticUndefined:
                default_value = None

            field_descriptions.append(
                {
                    "field": field_name,
                    "env": cls._build_env_name(field_name, field_info, env_prefix=env_prefix),
                    "type": cls._type_to_str(field_info.annotation),
                    "required": is_required,
                    "default": default_value,
                    "description": field_info.description,
                }
            )

        return field_descriptions

    @classmethod
    def generate_env_example(cls, settings_cls: Type[T_BaseSettings], include_comments: bool = True) -> str:
        """
        根据 settings 类生成 `.env.example` 内容。
        """
        field_descriptions = cls.describe_settings(settings_cls)
        lines = []

        for field_info in field_descriptions:
            if include_comments:
                comment_parts = [field_info["type"]]
                comment_parts.append("required" if field_info["required"] else f"default={field_info['default']!r}")
                if field_info["description"]:
                    comment_parts.append(field_info["description"])
                lines.append(f"# {' | '.join(comment_parts)}")

            env_value = "" if field_info["required"] else field_info["default"]
            if isinstance(env_value, (list, dict, tuple, set)):
                env_value = json.dumps(env_value, ensure_ascii=False)
            elif env_value is None:
                env_value = ""
            lines.append(f"{field_info['env']}={env_value}")

        return "\n".join(lines)

    @staticmethod
    def settings_to_dict(settings: BaseSettings) -> dict:
        """
        将 settings 对象转换为字典。
        """
        return settings.model_dump()
