#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author: Hui
# @File: encode_util.py
# @Desc: { 编码与摘要工具模块 }
# @Date: 2026/04/02
import base64
import hashlib
import hmac
from pathlib import Path
from typing import Callable


class EncodeUtil:
    """编码与摘要工具类。

    提供常用的 Base64、Hex、摘要算法和 HMAC 签名能力，统一文本与字节
    输入的处理方式，减少业务代码中对标准库细节的重复实现。
    """

    DEFAULT_ENCODING = "utf-8"

    @classmethod
    def _to_bytes(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> bytes:
        """将文本或字节统一转换为字节数据。

        Args:
            data: 原始文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            转换后的字节数据。

        Raises:
            TypeError: 当输入既不是字符串也不是字节时抛出。
        """
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return data.encode(encoding)
        raise TypeError("data must be str or bytes")

    @classmethod
    def base64_encode(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """对文本或字节数据进行 Base64 编码。

        Args:
            data: 待编码的文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            Base64 编码后的字符串。
        """
        return base64.b64encode(cls._to_bytes(data, encoding=encoding)).decode(cls.DEFAULT_ENCODING)

    @classmethod
    def base64_decode_bytes(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> bytes:
        """将 Base64 数据解码为字节。

        Args:
            data: Base64 编码后的文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            解码后的原始字节数据。
        """
        return base64.b64decode(cls._to_bytes(data, encoding=encoding))

    @classmethod
    def base64_decode(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """将 Base64 数据解码为字符串。

        Args:
            data: Base64 编码后的文本或字节数据。
            encoding: 解码后的字节转文本时使用的编码。

        Returns:
            解码后的字符串。
        """
        return cls.base64_decode_bytes(data, encoding=encoding).decode(encoding)

    @classmethod
    def urlsafe_base64_encode(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """对文本或字节数据进行 URL 安全的 Base64 编码。

        Args:
            data: 待编码的文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            URL 安全的 Base64 编码字符串。
        """
        return base64.urlsafe_b64encode(cls._to_bytes(data, encoding=encoding)).decode(cls.DEFAULT_ENCODING)

    @classmethod
    def urlsafe_base64_decode_bytes(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> bytes:
        """将 URL 安全的 Base64 数据解码为字节。

        Args:
            data: URL 安全的 Base64 编码文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            解码后的原始字节数据。
        """
        return base64.urlsafe_b64decode(cls._to_bytes(data, encoding=encoding))

    @classmethod
    def urlsafe_base64_decode(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """将 URL 安全的 Base64 数据解码为字符串。

        Args:
            data: URL 安全的 Base64 编码文本或字节数据。
            encoding: 解码后的字节转文本时使用的编码。

        Returns:
            解码后的字符串。
        """
        return cls.urlsafe_base64_decode_bytes(data, encoding=encoding).decode(encoding)

    @classmethod
    def hex_encode(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """将文本或字节数据编码为十六进制字符串。

        Args:
            data: 待编码的文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            十六进制字符串。
        """
        return cls._to_bytes(data, encoding=encoding).hex()

    @classmethod
    def hex_decode_bytes(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> bytes:
        """将十六进制数据解码为字节。

        Args:
            data: 十六进制编码文本或字节数据。
            encoding: 输入为文本时使用的编码。

        Returns:
            解码后的原始字节数据。
        """
        hex_str = data.decode(encoding) if isinstance(data, bytes) else data
        return bytes.fromhex(hex_str)

    @classmethod
    def hex_decode(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """将十六进制数据解码为字符串。

        Args:
            data: 十六进制编码文本或字节数据。
            encoding: 解码后的字节转文本时使用的编码。

        Returns:
            解码后的字符串。
        """
        return cls.hex_decode_bytes(data, encoding=encoding).decode(encoding)

    @classmethod
    def md5(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """计算 MD5 摘要。

        Args:
            data: 原始文本或字节数据。
            encoding: 文本转字节时使用的编码。

        Returns:
            MD5 十六进制摘要字符串。
        """
        return hashlib.md5(cls._to_bytes(data, encoding=encoding)).hexdigest()

    @classmethod
    def sha1(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """计算 SHA1 摘要。"""
        return hashlib.sha1(cls._to_bytes(data, encoding=encoding)).hexdigest()

    @classmethod
    def sha256(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """计算 SHA256 摘要。"""
        return hashlib.sha256(cls._to_bytes(data, encoding=encoding)).hexdigest()

    @classmethod
    def sha512(cls, data: str | bytes, encoding: str = DEFAULT_ENCODING) -> str:
        """计算 SHA512 摘要。"""
        return hashlib.sha512(cls._to_bytes(data, encoding=encoding)).hexdigest()

    @classmethod
    def hmac_sha256(
        cls,
        secret: str | bytes,
        data: str | bytes,
        encoding: str = DEFAULT_ENCODING,
        return_base64: bool = False,
    ) -> str:
        """使用 HMAC-SHA256 对数据进行签名。

        Args:
            secret: 签名密钥。
            data: 待签名数据。
            encoding: 文本转字节时使用的编码。
            return_base64: 是否返回 Base64 编码结果，默认返回十六进制字符串。

        Returns:
            HMAC 签名字符串。
        """
        digest = hmac.new(
            cls._to_bytes(secret, encoding=encoding),
            cls._to_bytes(data, encoding=encoding),
            digestmod=hashlib.sha256,
        ).digest()
        if return_base64:
            return base64.b64encode(digest).decode(cls.DEFAULT_ENCODING)
        return digest.hex()

    @classmethod
    def file_md5(cls, file_path: str | Path, chunk_size: int = 8192) -> str:
        """计算文件的 MD5 摘要。"""
        return cls._file_digest(file_path, hashlib.md5, chunk_size=chunk_size)

    @classmethod
    def file_sha256(cls, file_path: str | Path, chunk_size: int = 8192) -> str:
        """计算文件的 SHA256 摘要。"""
        return cls._file_digest(file_path, hashlib.sha256, chunk_size=chunk_size)

    @staticmethod
    def _file_digest(file_path: str | Path, digest_factory: Callable, chunk_size: int = 8192) -> str:
        """按块读取文件并计算摘要。

        Args:
            file_path: 文件路径。
            digest_factory: 摘要工厂函数，如 ``hashlib.md5``。
            chunk_size: 每次读取的字节数。

        Returns:
            文件摘要的十六进制字符串。
        """
        digest = digest_factory()
        with open(file_path, "rb") as file:
            for chunk in iter(lambda: file.read(chunk_size), b""):
                digest.update(chunk)
        return digest.hexdigest()
