# pip4

**pip4** adalah package installer super ngebut yang **tidak pandang memory** — install paket secepat mungkin tanpa peduli RAM/CPU yang dipakai. Cocok buat developer yang punya mesin kuat dan males nungguin pip biasa.

## Fitur

- Install ngebut (paralel, multi-stream, no memory cap)
- Turbo modes yang bisa diganti: `asd-turbo1`, `Cpu2`, `supertubro-hard`
- Command sederhana: `install`, `delete`, `change`, `list`

## Install

```bash
pip install pip4
```

## Pakai

```bash
pip4 install requests numpy fastapi
pip4 delete requests
pip4 change turbo supertubro-hard
pip4 list
```

## Turbo modes

| Mode              | Deskripsi                                                |
|-------------------|----------------------------------------------------------|
| `asd-turbo1`      | Mode default — cepat, hemat sedikit memori               |
| `Cpu2`            | Pakai semua core CPU — cocok buat mesin multi-core       |
| `supertubro-hard` | Mode paling agresif — abaikan limit memori, max paralel  |

## Lisensi

MIT
