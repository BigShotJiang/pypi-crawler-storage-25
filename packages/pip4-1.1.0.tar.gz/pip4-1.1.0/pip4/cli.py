"""CLI pip4: install (+ --64bit), delete, change turbo, list, status, bausin."""
from __future__ import annotations
import argparse
import sys

from . import __version__
from .config import Config, TURBO_MODES
from .installer import Installer
from .bausin import handle_many, SUPPORTED_EXT


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pip4",
        description="pip4 - installer ngebut tanpa pandang memory",
    )
    p.add_argument("--version", action="version", version=f"pip4 {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    pi = sub.add_parser("install", help="Install paket (tambah --64bit untuk memaksa wheel 64-bit)")
    pi.add_argument("packages", nargs="+")
    pi.add_argument("--64bit", dest="bit64", action="store_true",
                    help="Paksa download wheel 64-bit (manylinux/win_amd64/macos arm64/x86_64)")

    pd = sub.add_parser("delete", help="Hapus paket")
    pd.add_argument("packages", nargs="+")

    pc = sub.add_parser("change", help="mis. 'pip4 change turbo Cpu2'")
    pc.add_argument("setting", choices=["turbo"])
    pc.add_argument("value", help=f"Untuk turbo: {', '.join(TURBO_MODES)}")

    sub.add_parser("list", help="Daftar paket tercatat pip4")
    sub.add_parser("status", help="Tampilkan turbo aktif & versi")

    pb = sub.add_parser("bausin", help=f"Jalankan/compile file kode {', '.join(SUPPORTED_EXT)}")
    pb.add_argument("files", nargs="+")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    cfg = Config.load()

    if args.command == "install":
        return Installer(cfg).install(args.packages, only_64bit=args.bit64)

    if args.command == "delete":
        return Installer(cfg).delete(args.packages)

    if args.command == "change":
        if args.setting == "turbo":
            try:
                cfg.turbo = args.value
            except ValueError as e:
                print(f"pip4: {e}", file=sys.stderr)
                return 2
            cfg.save()
            print(f"pip4: turbo diganti -> {cfg.turbo}")
        return 0

    if args.command == "status":
        print(f"pip4 v{__version__}  turbo={cfg.turbo}")
        return 0

    if args.command == "list":
        if not cfg.installed:
            print("pip4: belum ada paket tercatat")
        else:
            for k, v in sorted(cfg.installed.items()):
                print(f" - {k}  [{v}]")
        return 0

    if args.command == "bausin":
        return handle_many(args.files)

    return 1


if __name__ == "__main__":
    sys.exit(main())
