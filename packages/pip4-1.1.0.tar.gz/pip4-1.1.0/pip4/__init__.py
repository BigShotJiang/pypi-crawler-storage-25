"""pip4 - super-fast package installer with switchable turbo modes & bausin."""
from .config import Config, TURBO_MODES
from .installer import Installer
from . import bausin

__version__ = "1.1.0"
__all__ = ["Config", "Installer", "TURBO_MODES", "bausin", "__version__"]
