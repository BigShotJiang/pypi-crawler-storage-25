"""Installer pip4 — wrap pip dengan tuning agresif sesuai turbo mode.
Mendukung opsi 64bit (memaksa wheel manylinux x86_64 / win_amd64 / arm64).
"""
from __future__ import annotations
import os
import platform
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from typing import Iterable, List, Tuple

from .config import Config

# Profil tiap turbo mode: (parallel_workers, extra_pip_args)
TURBO_PROFILES = {
    "asd-turbo1":      (4,  ["--no-cache-dir"]),
    "Cpu2":            (8,  ["--no-cache-dir", "--prefer-binary"]),
    "supertubro-hard": (32, ["--no-cache-dir", "--prefer-binary", "--use-pep517"]),
}


def _platform_tag_64() -> str:
    sysname = platform.system().lower()
    if sysname == "windows":
        return "win_amd64"
    if sysname == "darwin":
        return "macosx_11_0_arm64" if platform.machine() == "arm64" else "macosx_11_0_x86_64"
    return "manylinux2014_aarch64" if platform.machine() == "aarch64" else "manylinux2014_x86_64"


class Installer:
    def __init__(self, config: Config | None = None) -> None:
        self.config = config or Config.load()

    def _profile(self) -> Tuple[int, List[str]]:
        return TURBO_PROFILES.get(self.config.turbo, TURBO_PROFILES["asd-turbo1"])

    def install(self, packages: Iterable[str], *, only_64bit: bool = False) -> int:
        pkgs = list(packages)
        if not pkgs:
            print("pip4: tidak ada paket untuk diinstall")
            return 0
        workers, extra = self._profile()
        if only_64bit:
            extra = extra + ["--platform", _platform_tag_64(),
                             "--only-binary=:all:", "--target",
                             os.environ.get("PIP4_TARGET", "./pip4_64bit")]
        print(f"pip4: turbo='{self.config.turbo}' workers={workers} 64bit={only_64bit} -> {pkgs}")

        def _one(pkg: str) -> Tuple[str, int]:
            cmd = [sys.executable, "-m", "pip", "install", *extra, pkg]
            r = subprocess.run(cmd)
            return pkg, r.returncode

        rc = 0
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for pkg, code in ex.map(_one, pkgs):
                if code == 0:
                    self.config.installed[pkg] = "64bit" if only_64bit else "installed"
                    print(f"pip4: OK  {pkg}")
                else:
                    rc = code
                    print(f"pip4: ERR {pkg} (exit={code})")
        self.config.save()
        return rc

    def delete(self, packages: Iterable[str]) -> int:
        pkgs = list(packages)
        if not pkgs:
            print("pip4: tidak ada paket untuk dihapus")
            return 0
        rc = 0
        for pkg in pkgs:
            cmd = [sys.executable, "-m", "pip", "uninstall", "-y", pkg]
            r = subprocess.run(cmd)
            if r.returncode == 0:
                self.config.installed.pop(pkg, None)
                print(f"pip4: dihapus {pkg}")
            else:
                rc = r.returncode
                print(f"pip4: gagal hapus {pkg}")
        self.config.save()
        return rc
