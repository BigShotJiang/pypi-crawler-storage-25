"""Konfigurasi pip4 — turbo mode persisten di ~/.pip4/config.json."""
from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any, Dict

TURBO_MODES = ("asd-turbo1", "Cpu2", "supertubro-hard")
DEFAULT_TURBO = "asd-turbo1"

CONFIG_DIR = Path(os.path.expanduser("~")) / ".pip4"
CONFIG_FILE = CONFIG_DIR / "config.json"


class Config:
    def __init__(self, data: Dict[str, Any] | None = None) -> None:
        self.data: Dict[str, Any] = data or {"turbo": DEFAULT_TURBO, "installed": {}}

    @classmethod
    def load(cls) -> "Config":
        if CONFIG_FILE.exists():
            try:
                return cls(json.loads(CONFIG_FILE.read_text()))
            except Exception:
                pass
        return cls()

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(self.data, indent=2))

    @property
    def turbo(self) -> str:
        return self.data.get("turbo", DEFAULT_TURBO)

    @turbo.setter
    def turbo(self, mode: str) -> None:
        if mode not in TURBO_MODES:
            raise ValueError(
                f"turbo mode '{mode}' tidak dikenal. Pilih: {', '.join(TURBO_MODES)}"
            )
        self.data["turbo"] = mode

    @property
    def installed(self) -> Dict[str, str]:
        return self.data.setdefault("installed", {})
