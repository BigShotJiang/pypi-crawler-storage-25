"""bausin runner — eksekusi/kompilasi file kode tambahan untuk pip4.

Format yang didukung:
  .per  -> Python Extended Routine (dijalankan via python interpreter)
  .cpp  -> C++ source (dikompilasi via g++/clang++)
  .xcc  -> eXtended C Component (dikompilasi via cc, dengan -O3)
"""
from __future__ import annotations
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List

SUPPORTED_EXT = (".per", ".cpp", ".xcc")


def _which(*names: str) -> str | None:
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def run_per(path: Path) -> int:
    """File .per = skrip Python diperluas. Jalankan dengan interpreter."""
    return subprocess.run([sys.executable, str(path)]).returncode


def compile_cpp(path: Path, out: Path | None = None) -> int:
    cxx = _which("g++", "clang++")
    if not cxx:
        print("pip4/bausin: g++/clang++ tidak ditemukan", file=sys.stderr)
        return 127
    out = out or path.with_suffix("")
    cmd = [cxx, "-O2", "-std=c++17", "-x", "c++", str(path), "-o", str(out)]
    return subprocess.run(cmd).returncode


def compile_xcc(path: Path, out: Path | None = None) -> int:
    cc = _which("cc", "gcc", "clang")
    if not cc:
        print("pip4/bausin: cc/gcc/clang tidak ditemukan", file=sys.stderr)
        return 127
    out = out or path.with_suffix("")
    cmd = [cc, "-O3", "-x", "c", str(path), "-o", str(out)]
    return subprocess.run(cmd).returncode


def handle(path_str: str) -> int:
    path = Path(path_str)
    if not path.exists():
        print(f"pip4/bausin: file tidak ditemukan: {path}", file=sys.stderr)
        return 2
    ext = path.suffix.lower()
    if ext == ".per":
        return run_per(path)
    if ext == ".cpp":
        return compile_cpp(path)
    if ext == ".xcc":
        return compile_xcc(path)
    print(f"pip4/bausin: ekstensi tidak didukung: {ext}", file=sys.stderr)
    return 2


def handle_many(paths: List[str]) -> int:
    rc = 0
    for p in paths:
        r = handle(p)
        if r != 0:
            rc = r
    return rc
