# 🔐 PrivyLayer

> Privacy layer for AI systems — protect sensitive data *before* it reaches AI.

---

## 🚀 Overview

**PrivyLayer** is a lightweight Python library that acts as a **security layer between user input and AI models**.

It detects sensitive information (PII), replaces it with secure placeholders, and restores it after the AI response — ensuring **zero data exposure**.

---

## ⚡ Why PrivyLayer?

Modern AI systems process user input directly, which may include:

* 📱 Phone numbers
* 📧 Emails
* 🪪 Aadhaar / PAN
* 🏦 Bank details

This creates a **privacy risk**.

👉 PrivyLayer solves this by introducing a **reversible masking system**.

---

## 🧠 How It Works

```
User Input
   ↓
PrivyLayer (detect + mask)
   ↓
AI Model
   ↓
PrivyLayer (restore)
   ↓
Final Output
```

---

## ✨ Features

* 🔍 Detects sensitive data using regex patterns
* 🔁 Reversible masking (no data loss)
* 🧠 Smart tokenization system
* ⚡ Fast and lightweight
* 🇮🇳 India-specific PII support
* 🔒 No data stored globally

---

## 📦 Installation

```bash
pip install privylayer
```

---

## 🛠️ Usage

### 🔐 Protect (Mask data)

```python
from privylayer import protect

text = "My phone is 9876543210 and email is test@gmail.com"

mask , context , seen = main.find_p(text)

print(mask)
```

### Output:

```
My phone is ⟦PII_PHONE_x1⟧ and email is ⟦PII_EMAIL_x2⟧
```

---

### 🔓 Restore (Unmask data)

```python
from privylayer import restore

original = restore(masked, context)

print(original)
```

### Output:

```
My phone is 9876543210 and email is test@gmail.com
```

---

## 🧩 Supported Data Types

* 📱 Phone numbers (India)
* 📧 Email addresses
* 🪪 Aadhaar numbers
* 🧾 PAN numbers
* 🏦 IFSC codes

---

## 🔐 Token Format

PrivyLayer replaces sensitive data with structured tokens:

```
⟦PII_TYPE_ID⟧
```

Example:

```
⟦PII_PHONE_x1⟧
⟦PII_EMAIL_x2⟧
```

---

## ⚠️ Limitations

* Regex-based detection (may not detect names accurately)
* Does not validate Aadhaar checksum (yet)
* Context must be preserved for restoration

---

## 🚀 Roadmap

* [ ] AI-based name detection
* [ ] Risk scoring system
* [ ] Browser extension
* [ ] API gateway version
* [ ] Encryption-based token vault

---

## 🤝 Contributing

Contributions are welcome!

* Fork the repo
* Create a feature branch
* Submit a pull request

---

## 📄 License

MIT License

---

## 👨‍💻 Author

Built by Nithish 🚀

[Nithish's Portfolio] (https://nithishprogrammer.github.io/Nithish)

[Nithish's Github] (https://github.com/NithishProgrammer)

---

## 🌟 Vision

> Making AI safe for everyone by protecting sensitive data at the source.

---

⭐ If you like this project, consider giving it a star!
