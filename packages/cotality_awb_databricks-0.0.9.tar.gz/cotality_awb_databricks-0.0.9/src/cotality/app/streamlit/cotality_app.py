# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Workbench App."""

from __future__ import annotations

from typing import Any

import streamlit as st

from ...core import clgxtyping
from ...core.clgxtyping import LogLevel
from ...core.locales import keys
from ...core.platform import Platform
from ..base.base_app import BaseApp, UIFramework
from .modules import layout as app_layout


def CotalityApp(platform: Platform) -> _CotalityApp:  # noqa: N802
    """Get or create singleton instance of CotalityApp.

    Args:
        platform: Platform instance to initialize the app.

    Returns:
        _CotalityApp: Singleton instance of the Cotality Streamlit app.

    """
    if not hasattr(_CotalityApp, "instance") or _CotalityApp.instance is None:
        _CotalityApp.instance = _CotalityApp(platform)
    return _CotalityApp.instance


class _CotalityApp(BaseApp):
    """Panel Workbench Application Client."""

    instance: _CotalityApp | None = None

    def __init__(self, platform: Platform) -> None:
        """Initialize the Workbench Application Client.

        Args:
            platform (Platform): The platform instance to use.
        """
        super().__init__(
            platform=platform,
            ui_framework=UIFramework.STREAMLIT,
        )

        st.html(f"<style>{self.style}</style>")

    def display_message(self, level: LogLevel, message: str) -> None:
        """Return localized message based on the message.

        Args:
            level (LogLevel): The log level for the message.
            message (str): The localization message.
        """

    def display(self) -> Any:  # noqa: ANN401
        entitlements = self.application_entitlements
        number_of_entitlements = len(entitlements)
        if number_of_entitlements == 0:
            return st.error(self._(keys.SYS_ERROR_NO_ENTITLEMENTS))
        if number_of_entitlements == 1:
            app_layout.display(self)
            return None
        return st.info(
            "Please select an application from the menu to continue.",
        )

    def display_app(self, app_code: clgxtyping.AppCode) -> None:
        """Display the specified micro application.

        Args:
            app_code (clgxtyping.AppCode): The application code to display.
        """
