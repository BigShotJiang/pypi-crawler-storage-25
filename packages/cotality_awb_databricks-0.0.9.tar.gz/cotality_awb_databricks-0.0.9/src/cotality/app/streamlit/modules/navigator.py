# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Navigator Module."""

from __future__ import annotations

from dataclasses import dataclass, field
import enum

from dataclasses_json import DataClassJsonMixin
import streamlit as st

from ...base.base_app import BaseApp


__NAVIGATION_KEY = "NAVIGATION_KEY"


class NavigationFlow(str, enum.Enum):
    """FieldViolationType - Violation type."""

    UNKNOWN = "unknown"
    SECRET = "secret"  # noqa: S105
    DASHBOARD = "dashboard"

    def __str__(self) -> str:
        """Return string.

        Returns:
            str: String
        """
        return str(self.value)


@dataclass(init=True, frozen=False)
class Navigation(DataClassJsonMixin):
    """Navigation state."""

    flow: NavigationFlow = field(default_factory=lambda: NavigationFlow.UNKNOWN)
    enable_menu: dict = field(default_factory=dict)
    input_table: str = field(default_factory=lambda: "")
    input_record_count: int = 0


def set_navigation(flow: NavigationFlow) -> None:
    """Set the navigation flow in the session state."""
    st.session_state[__NAVIGATION_KEY] = flow.value


def get_navigation(app: BaseApp) -> Navigation:
    """Display the input module."""
    flow = NavigationFlow(st.session_state.get(__NAVIGATION_KEY, NavigationFlow.DASHBOARD.value))

    navigation = Navigation()
    navigation.enable_menu = {NavigationFlow.SECRET: True}

    if not app.api_credential_is_valid:
        navigation.flow = NavigationFlow.SECRET
    else:
        navigation.flow = flow
        navigation.enable_menu = {
            NavigationFlow.SECRET: True,
            NavigationFlow.DASHBOARD: True,
        }

    return navigation
