# Copyright 2025 Cotality  # noqa: D100
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations

from typing import Any

from pandas import DataFrame as PandaDataFrame  # type: ignore[import-untyped]
from plotly import graph_objects as go  # type: ignore[import-untyped]
import streamlit as st

from ....core.locales import keys
from ....core.utils.misc import int_to_datetime_string
from ....xapi.clip.typing import (
    INPUT_TABLE_NAME,
    LAST_CLIP_RUN_DATE,
    LAST_CLIP_RUN_RECORDS,
    LAST_CLIP_RUN_STATUS,
    RGB_DEFAULT,
    TOTAL_CLIP_RECORDS,
    TOTAL_DUPLICATE_RECORDS,
    TOTAL_INVALID_RECORDS,
    TOTAL_RECORDS,
    TOTAL_UNIQUE_RECORDS,
    TOTAL_UNMATCHED_RECORDS,
)
from ...base.base_app import BaseApp
from ...streamlit.utils import validate_input_table_name
from .navigator import Navigation


def display(app: BaseApp, navigation: Navigation) -> None:  # noqa: ARG001
    """Select the input table for the Clip Lookup Streamlit app.

    Args:
        app: BaseApp instance.
        navigation: Navigation instance (unused).

    """
    tables = []
    try:
        tables = app.clip_client.get_clip_input_tables()
    except Exception:
        st.error(app._(keys.SYS_ERROR_GET_TABLES))
        return

    if len(tables) == 0:
        __display_create_input_table(app)
    else:
        __display_dashboard(app)


def __display_create_input_table(app: BaseApp) -> None:
    """Render the create input table widget.

    Args:
        app (BaseApp): The APP instance.
    """
    with st.container(key="input-container"):
        st.subheader(app._(keys.TEXT_NO_INPUT_TABLES_CREATED))
        st.write(app._(keys.TEXT_ADD_INPUT_TABLE_INTRO))

        if st.button(label=app._(keys.BUTTON_CREATE_TABLE), key=keys.BUTTON_CREATE_TABLE):
            display_dialog_create_table(app)


def __display_dashboard(app: BaseApp) -> None:
    """Display the summary of input tables.

    Args:
        app (BaseApp): The APP instance.
    """
    # After selection, use the stored value
    if st.session_state.get(keys.SELECT_INPUT_TABLE_LABEL) is not None:
        with st.container():
            cols = st.columns([4, 1, 1])

            with cols[1]:
                if st.button(
                    label=app._(keys.BUTTON_DROP_INPUT_TABLE),
                    key=keys.BUTTON_DROP_INPUT_TABLE,
                    use_container_width=True,
                ):
                    display_dialog_drop_table(app)

            with cols[2]:
                if st.button(
                    label=app._(keys.BUTTON_RUN_JOB),
                    key=keys.BUTTON_RUN_JOB,
                    use_container_width=True,
                ):
                    input_table = st.session_state[keys.SELECT_INPUT_TABLE_LABEL]

                    if not validate_input_table_name(app, input_table):
                        # invalid table name
                        return

                    input_record_count = 0
                    try:
                        input_record_count = app.clip_client.get_input_record_count(input_table)
                    except Exception:
                        st.toast(f":red[{app._(keys.SYS_ERROR_GET_RECORD_COUNT)}]")

                    if input_record_count == 0:
                        st.toast(f":red[{app._(keys.ERROR_INPUT_TABLE_SELECTION)}]")
                    else:
                        dialog_run_clip_job(app)

    __display_summary(app)


def dialog_run_clip_job(app: BaseApp) -> Any:  # noqa: ANN401
    """Display dialog to run clip job.

    Args:
        app: BaseApp instance.

    Returns:
        Any: Dialog function result.

    """

    @st.dialog(app._(keys.BUTTON_RUN_JOB_DIALOG))
    def _dialog() -> None:
        st.write(app._(keys.TEXT_CLIP_INFO))

        if st.button(label=app._(keys.BUTTON_RUN_JOB_DIALOG), key=keys.BUTTON_RUN_JOB_DIALOG):
            # Define default no-op callback
            def progress_callback_default(progress_status: Any) -> None:  # noqa: ANN401
                """Default no-op callback for progress."""

            progress_callback = progress_callback_default

            if app.platform.config.has_access_to_external_integration:
                processed_batches = st.empty()
                progress_text = app._(keys.TEXT_OPERATION_IN_PROGRESS)
                my_bar = st.progress(0, text=progress_text)

                def progress_callback_active(progress_status: Any) -> None:  # noqa: ANN401
                    """Callback to show progress."""
                    percentage = 0
                    if progress_status.input_counts != 0:
                        percentage = 100 / progress_status.input_counts
                        percentage = int(progress_status.batch_input_counts * percentage)

                    my_bar.progress(percentage, text=progress_text)
                    processed_batches.text(
                        app._(keys.TEXT_OPERATION_IN_PROGRESS_BATCHES).format(
                            batches=progress_status.batch_input_counts
                        )
                    )

                progress_callback = progress_callback_active
                my_bar.empty()
            else:
                st.info(app._(keys.TEXT_OPERATION_IN_PROGRESS))

            try:
                app.clip_client.clip(
                    input_table=st.session_state[keys.SELECT_INPUT_TABLE_LABEL],
                    limit=0,
                    event_callback=progress_callback,
                )
            except Exception:
                st.error(app._(keys.SYS_ERROR_CLIP_LOOKUP))
                return

            st.rerun()

    return _dialog()


def display_dialog_create_table(app: BaseApp) -> None:
    """Display dialog to create a new input table.

    Args:
        app: BaseApp instance.

    """

    @st.dialog(app._(keys.BUTTON_CREATE_TABLE_DIALOG))
    def _dialog() -> None:
        st.write(app._(keys.TEXT_ADD_INPUT_TABLE_EXPLANATION))
        table_name = st.text_input(app._(keys.TEXT_ADD_INPUT_TABLE_DIALOG))
        table_name = table_name.lower()

        if st.button(
            label=app._(keys.BUTTON_CREATE_TABLE_DIALOG),
            key=keys.BUTTON_CREATE_TABLE_DIALOG,
        ):
            if not validate_input_table_name(app, table_name):
                # invalid table name
                return

            tables = []
            try:
                tables = app.clip_client.get_clip_input_tables()
            except Exception:
                st.error(app._(keys.SYS_ERROR_GET_TABLES))
                return

            if table_name in tables:
                st.error(app._(keys.ERROR_INPUT_TABLE_ALREADY_EXISTS))
                return

            try:
                app.clip_client.create_clip_input_table(table_name)
            except Exception:
                st.error(app._(keys.SYS_ERROR_CREATE_TABLE))
                return

            st.success(app._(keys.SUCCESS_INPUT_TABLE_CREATION))
            st.rerun()

    return _dialog()


def display_dialog_drop_table(app: BaseApp) -> None:
    """Display dialog to drop an input table.

    Args:
        app: BaseApp instance.

    """

    @st.dialog(app._(keys.TEXT_DROP_INPUT_TABLE))
    def _dialog() -> None:
        st.write(app._(keys.TEXT_DROP_INPUT_TABLE_EXPLANATION))
        if st.button(
            label=app._(keys.BUTTON_DROP_INPUT_TABLE_DIALOG),
            key=keys.BUTTON_DROP_INPUT_TABLE_DIALOG,
        ):
            try:
                app.clip_client.drop_clip_input_table(str(st.session_state[keys.SELECT_INPUT_TABLE_LABEL]))
                st.session_state[keys.SELECT_INPUT_TABLE_LABEL] = None
            except Exception:
                st.error(app._(keys.SYS_ERROR_DROP_TABLE))
                return

            st.success(app._(keys.SUCCESS_INPUT_TABLE_DROP))
            st.rerun()

    return _dialog()


def __display_last_run_alert(app: BaseApp, df: PandaDataFrame) -> None:
    """Shows alert on the UI if the last job failed."""
    selected_table = st.session_state.get(keys.SELECT_INPUT_TABLE_LABEL)

    if selected_table is None:
        return

    tables = df[df[INPUT_TABLE_NAME] == selected_table].to_dict("records")
    if len(tables) == 0:
        return

    row_selected = tables[0]
    if row_selected[LAST_CLIP_RUN_STATUS] == "Failed":
        st.error(app._(keys.TEXT_LAST_JOB_FAILED))


def __display_summary(app: BaseApp) -> None:  # noqa: PLR0915
    """Display the dashboard module.

    If process hasn't been run yet → show DataFrame
    Calculate weighted average percentage from property_match_score
    If clip_summary_metric is a dataclass, access attribute directly
    property_match_score is now a dict: {score: count, ...}.

    Args:
        app: BaseApp instance.

    """
    try:
        summary_df = app.clip_client.get_input_tables_summary()
    except Exception:
        st.error(app._(keys.SYS_ERROR_GET_SUMMARY))
        return

    def on_select_table() -> None:
        """Store selected table name in session state.

        If table is selected in the dataframe stores
        the name of the table it in the session.
        """
        rows = st.session_state["DF_SUMMARY"]["selection"]["rows"]
        if len(rows) != 0:
            row = summary_df.iloc[rows[0]]
            st.session_state[keys.SELECT_INPUT_TABLE_LABEL] = str(row[INPUT_TABLE_NAME])

    if st.session_state.get(keys.SELECT_INPUT_TABLE_LABEL) is None:
        st.header(app._(keys.TEXT_DASHBOARD))
    else:
        st.header(app._(keys.TEXT_DASHBOARD) + " - " + str(st.session_state[keys.SELECT_INPUT_TABLE_LABEL]))

    if st.button(app._(keys.TEXT_DASHBOARD_START), key="dashboard-button"):
        st.session_state[keys.SELECT_INPUT_TABLE_LABEL] = None
        st.rerun()

    __display_last_run_alert(app, summary_df)

    st.dataframe(
        summary_df,
        key="DF_SUMMARY",
        column_config={
            INPUT_TABLE_NAME: app._(keys.COLUMN_INPUT_TABLE_NAME),
            TOTAL_RECORDS: app._(keys.COLUMN_TOTAL_RECORDS),
            TOTAL_CLIP_RECORDS: app._(keys.COLUMN_TOTAL_CLIP_RECORDS),
            TOTAL_UNMATCHED_RECORDS: app._(keys.COLUMN_TOTAL_UNMATCHED_RECORDS),
            TOTAL_INVALID_RECORDS: app._(keys.COLUMN_TOTAL_INVALID_RECORDS),
            TOTAL_UNIQUE_RECORDS: app._(keys.COLUMN_TOTAL_UNIQUE_RECORDS),
            TOTAL_DUPLICATE_RECORDS: app._(keys.COLUMN_TOTAL_DUPLICATE_RECORDS),
            LAST_CLIP_RUN_STATUS: app._(keys.COLUMN_INPUT_TABLE_STATUS),
            LAST_CLIP_RUN_RECORDS: app._(keys.COLUMN_INPUT_TABLE_RECORDS),
            LAST_CLIP_RUN_DATE: app._(keys.COLUMN_INPUT_TABLE_LAST_RUN),
        },
        hide_index=True,
        on_select=on_select_table,
        selection_mode="single-row",
    )

    if st.session_state.get(keys.SELECT_INPUT_TABLE_LABEL) is None:
        return

    input_table = st.session_state[keys.SELECT_INPUT_TABLE_LABEL]

    jobs = []
    try:
        jobs = app.clip_client.get_input_jobs_list(input_table)
    except Exception:
        st.error(app._(keys.SYS_ERROR_GET_JOBS))
        return

    if len(jobs) == 0:
        return

    job = st.selectbox(
        label=app._(keys.SELECT_JOB_LABEL),
        key=keys.SELECT_JOB_LABEL,
        options=[int_to_datetime_string(j.started_at) for j in jobs],
        index=0,
    )

    selected = job if job else int_to_datetime_string(jobs[0].started_at)
    clip_metric = next((j.clip_metrics for j in jobs if int_to_datetime_string(j.started_at) == selected), None)
    if clip_metric is None:
        return
    scores_dict = clip_metric.clip_summary_metric.property_match_score

    scores = [
        {"score": int(float(score if score != "NaN" else 0)), "count": count} for score, count in scores_dict.items()
    ]

    total_count = sum(item["count"] for item in scores)
    weighted_sum = sum(item["score"] * item["count"] for item in scores)
    percentage = round(weighted_sum / total_count, 2) if total_count > 0 else 0

    labels = [app._(keys.TEXT_MATCHED), app._(keys.TEXT_UNMATCHED)]

    values = [percentage, 10 - percentage]
    colors = ["blue", "gray"]

    # Create two columns: left for pie chart, right for text
    col1, col2 = st.columns([1, 2])

    with col1:
        # Add annotation above the pie chart
        st.markdown(
            f"""
            <div style="text-align:center; font-size:13px; margin-bottom:8px;">
            {app._(keys.TEXT_PIE_DESCRIPTION)}
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Make a plotly pie chart with a hole in the middle
        fig = go.Figure(
            data=[
                go.Pie(
                    labels=labels,
                    values=values,
                    hole=0.5,
                    marker={"colors": colors},
                    textinfo="none",
                )
            ]
        )

        # Add percentage annotation in the center
        fig.add_annotation(
            text=f"{round(percentage * 10, 2)}%",
            x=0.5,
            y=0.5,
            font={"size": 20, "color": "black"},
            showarrow=False,
            xanchor="center",
            yanchor="middle",
        )

        fig.update_layout(
            margin={"t": 20, "b": 40, "l": 10, "r": 10},
            legend={
                "x": 0.5,
                "y": -0.15,
                "xanchor": "center",
                "yanchor": "top",
                "orientation": "h",
                "bgcolor": RGB_DEFAULT,
            },
            height=300,
        )
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        total_count = clip_metric.input_metrics.total_input_counts
        matched_count = clip_metric.input_metrics.clip_counts
        unmatched_count = clip_metric.input_metrics.non_clip_counts
        invalid_count = clip_metric.input_metrics.invalid_counts

        def pluralize(count: int) -> str:
            """Return 'record' or 'records' based on count."""
            return "record" if count == 1 else "records"

        total_label = pluralize(total_count)
        matched_label = pluralize(matched_count)
        unmatched_label = pluralize(unmatched_count)
        invalid_label = pluralize(invalid_count)

        # Vertically center the markdown using Streamlit's container and CSS
        st.markdown(
            f"""
            <div style="display: flex; height: 340px; align-items: center; justify-content: center;">
                <div style="width: 100%;">
                    <ul style="list-style-type: none; padding-left: 0; margin: 0; text-align: left;">
                        <li><strong>{app._(keys.CLIP_JOB_METRICS)}</strong></li>
                        <li><strong>{app._(keys.TEXT_TOTAL_JOB_RECORDS)}:</strong> {total_count} {total_label}</li>
                        <li><strong>{app._(keys.TEXT_MATCHED)}:</strong> {matched_count} {matched_label}</li>
                        <li><strong>{app._(keys.TEXT_UNMATCHED)}:</strong> {unmatched_count} {unmatched_label}</li>
                        <li><strong>{app._(keys.TEXT_INVALID)}:</strong> {invalid_count} {invalid_label}</li>
                    </ul>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    get_graphs(app, scores)


def get_graphs(app: BaseApp, scores: list[dict[str, int]]) -> None:
    """Generates the Figure of 4 graphs using Plotly."""

    def _percent(count: int, total: int) -> float:
        """Percentage without exeception."""
        return (count / total) * 100 if total != 0 else 0

    records_8_10_count = sum(item["count"] for item in scores if 8 <= item["score"] <= 10)  # noqa: PLR2004
    records_6_7_count = sum(item["count"] for item in scores if 6 <= item["score"] <= 7)  # noqa: PLR2004
    records_1_5_count = sum(item["count"] for item in scores if 1 <= item["score"] <= 5)  # noqa: PLR2004
    records_0_count = sum(item["count"] for item in scores if item["score"] == 0)

    records_8_10_percent_sum = records_8_10_count + records_6_7_count + records_1_5_count + records_0_count
    records_8_10_percent = _percent(records_8_10_count, records_8_10_percent_sum)
    records_6_7_percent_sum = records_8_10_count + records_6_7_count + records_1_5_count + records_0_count
    records_6_7_percent = _percent(records_6_7_count, records_6_7_percent_sum)
    records_1_5_percent_sum = records_8_10_count + records_6_7_count + records_1_5_count + records_0_count
    records_1_5_percent = _percent(records_1_5_count, records_1_5_percent_sum)
    records_0_percent_sum = records_8_10_count + records_6_7_count + records_1_5_count + records_0_count
    records_0_percent = _percent(records_0_count, records_0_percent_sum)

    # Top graph
    category0 = app._(keys.TEXT_EXACT_MATCH)
    chart0 = plot_horizontal_bar(
        records_8_10_percent,
        category0,
        app._(keys.TEXT_EXACT_MATCH_DESCRIPTION).format(count=records_8_10_count),
    )
    pct0 = f"{round(records_8_10_percent, 2)}%"
    chart0.update_layout(margin={"t": 0, "b": 0, "l": 80, "r": 0})
    chart0.add_annotation(
        x=0,
        xref="paper",
        xanchor="right",
        xshift=-8,
        y=category0,
        yref="y",
        text=pct0,
        showarrow=False,
        yanchor="middle",
        font={"size": 13, "color": "black"},
    )

    # Second graph
    category1 = app._(keys.TEXT_MEDIUM_MATCH)
    chart1 = plot_horizontal_bar(
        records_6_7_percent,
        category1,
        app._(keys.TEXT_MEDIUM_MATCH_DESCRIPTION).format(count=records_6_7_count),
    )
    pct1 = f"{round(records_6_7_percent, 2)}%"
    chart1.update_layout(margin={"t": 0, "b": 0, "l": 80, "r": 0})
    chart1.add_annotation(
        x=0,
        xref="paper",
        xanchor="right",
        xshift=-8,
        y=category1,
        yref="y",
        text=pct1,
        showarrow=False,
        yanchor="middle",
        font={"size": 13, "color": "black"},
    )

    # Third graph
    category2 = app._(keys.TEXT_LOW_MATCH)
    chart2 = plot_horizontal_bar(
        records_1_5_percent,
        category2,
        app._(keys.TEXT_LOW_MATCH_DESCRIPTION).format(count=records_1_5_count),
    )
    pct2 = f"{round(records_1_5_percent, 2)}%"
    chart2.update_layout(margin={"t": 0, "b": 0, "l": 80, "r": 0})
    chart2.add_annotation(
        x=0,
        xref="paper",
        xanchor="right",
        xshift=-8,
        y=category2,
        yref="y",
        text=pct2,
        showarrow=False,
        yanchor="middle",
        font={"size": 13, "color": "black"},
    )

    # Bottom graph
    category3 = app._(keys.TEXT_NO_MATCH)
    chart3 = plot_horizontal_bar(
        records_0_percent,
        category3,
        app._(keys.TEXT_NO_MATCH_DESCRIPTION).format(count=records_0_count),
    )
    pct3 = f"{round(records_0_percent, 2)}%"
    chart3.update_layout(margin={"t": 0, "b": 0, "l": 80, "r": 0})
    chart3.add_annotation(
        x=0,
        xref="paper",
        xanchor="right",
        xshift=-8,
        y=category3,
        yref="y",
        text=pct3,
        showarrow=False,
        yanchor="middle",
        font={"size": 13, "color": "black"},
    )

    st.plotly_chart(chart0, use_container_width=True)
    st.plotly_chart(chart1, use_container_width=True)
    st.plotly_chart(chart2, use_container_width=True)
    st.plotly_chart(chart3, use_container_width=True)


def plot_horizontal_bar(value: float, category: str, text: str) -> go.Figure:
    """Plots a horizontal bar chart with a single value and a category."""
    fig = go.Figure()

    fig.add_trace(
        go.Bar(
            x=[value],
            y=[category],
            orientation="h",
            marker={"color": "blue"},
            name="Percentage",
        )
    )
    fig.add_trace(
        go.Bar(
            x=[100 - value],
            y=[category],
            orientation="h",
            marker={"color": "gray"},
            name="Remaining",
        ),
    )

    fig.update_layout(
        barmode="stack",
        showlegend=False,
        xaxis={"showticklabels": False, "showgrid": False, "zeroline": False},
        yaxis={"showticklabels": False, "showgrid": False, "zeroline": False},
        margin={"t": 0, "b": 0, "l": 0, "r": 0},
        plot_bgcolor=RGB_DEFAULT,
        paper_bgcolor=RGB_DEFAULT,
        height=40,
    )

    fig.add_annotation(
        x=0,
        y=category,
        text=text,
        showarrow=False,
        font={"size": 12, "color": "black"},
        align="left",
        xanchor="left",
        yanchor="bottom",
        yshift=-30,
    )

    return fig
