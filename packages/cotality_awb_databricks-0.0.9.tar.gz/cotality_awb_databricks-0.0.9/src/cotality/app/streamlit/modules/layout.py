# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Header."""

from __future__ import annotations

from datetime import timezone
from datetime import datetime as dt

import streamlit as st

from ....core.locales import keys
from ...base.base_app import BaseApp
from . import body as body_module
from .dashboard import display_dialog_create_table
from .navigator import Navigation, NavigationFlow, get_navigation, set_navigation


def display(app: BaseApp) -> None:
    """Screen layout for the Clip Lookup Streamlit app."""
    navigation = get_navigation(app)

    with st.container(key="myheader"):
        __header(app, navigation)

    body_module.display(app)
    __footer()


def __header(app: BaseApp, navigation: Navigation) -> None:
    """Display the app header."""
    cols = st.columns([1, 1, 1, 5, 1])
    with cols[0]:
        st.html(app.logo_content)

    with cols[1]:
        _val = NavigationFlow.SECRET
        if navigation.enable_menu.get(_val, False):  # noqa: SIM102
            if st.button(app._(keys.NAVIGATION_TEXT_SECRET), key=f"nav-btn-{_val.value}"):
                set_navigation(_val)
                st.rerun()

    with cols[2]:
        _val = NavigationFlow.DASHBOARD
        if navigation.enable_menu.get(_val, False):  # noqa: SIM102
            if st.button(app._(keys.NAVIGATION_TEXT_DASHBOARD), key=f"nav-btn-{_val.value}"):
                set_navigation(_val)
                st.rerun()

    with cols[4]:
        if app.api_credential_is_valid:  # noqa: SIM102
            if st.button(app._(keys.NAVIGATION_CREATE_TABLE), key="nav-btn-add-table"):
                display_dialog_create_table(app)


def __footer() -> None:
    """Display the app footer."""
    st.markdown(
        f"""
        <div class="myfooter">
            &copy; {dt.now(tz=timezone.utc).year} Cotality. All rights reserved.
        </div>
        """,
        unsafe_allow_html=True,
    )
