# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Input Module."""

from __future__ import annotations

from ...base.base_app import BaseApp
from . import dashboard as dashboard_module
from . import secret as secret_module
from .navigator import NavigationFlow, get_navigation


def display(app: BaseApp) -> None:
    """Display the input module."""
    navigation = get_navigation(app)
    match navigation.flow:
        case NavigationFlow.SECRET:
            secret_module.display(app)
        case NavigationFlow.DASHBOARD:
            dashboard_module.display(app, navigation)
