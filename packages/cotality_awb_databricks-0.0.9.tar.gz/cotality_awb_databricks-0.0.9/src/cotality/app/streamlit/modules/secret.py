# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Secret Module."""

from __future__ import annotations

import streamlit as st

from ....core.locales import keys
from ...base.base_app import BaseApp
from ....core.clgxtyping import PlatformType

def display(app: BaseApp) -> None:
    """Edit API credentials."""
    platform_type = app.platform.config.platform_type

    # only on databricks update secrets works
    if platform_type != PlatformType.DATABRICKS:
        st.error(app._(keys.TEXT_WORK_IN_PROGESS))

    if app.api_credential_is_valid:
        __display_update_secrets(app)
    else:
        __display_create_secrets(app)


def __display_update_secrets(app: BaseApp) -> None:
    secret_client = app.platform.secret_client

    st.subheader(app._(keys.TEXT_UPDATE_SECRET))
    st.write(app._(keys.TEXT_UPDATE_SECRET_INTRO))

    user_name = st.text_input(app._(keys.TEXT_SECRET_USERNAME))
    user_pawd = st.text_input(app._(keys.TEXT_SECRET_PASSWORD), type="password")

    if st.button(app._(keys.BUTTON_SAVE_SECRET), use_container_width=True) and not (user_name and user_pawd):
        st.write(app._(keys.TEXT_SECRET_INTRODUCTION))

        try:
            secret_client.save_digital_gateway_credential(
                user_name,
                user_pawd
            )
        except Exception:
            st.error(app._(keys.SYS_ERROR_SAVE_SECRETS))
            return





def __display_create_secrets(app: BaseApp) -> None:
    st.subheader(app._(keys.TEXT_NO_SECRET_CREATED))
    st.write(app._(keys.TEXT_NO_SECRET_CREATED_INTRO))

    user_name = st.text_input(app._(keys.TEXT_SECRET_USERNAME))
    user_pawd = st.text_input(app._(keys.TEXT_SECRET_PASSWORD), type="password")

    if st.button(app._(keys.BUTTON_SAVE_SECRET), use_container_width=True) and not (user_name and user_pawd):
        st.write(app._(keys.TEXT_SECRET_INTRODUCTION))

        try:
            secret_client.save_digital_gateway_credential(
                user_name,
                user_pawd
            )
        except Exception:
            st.error(app._(keys.SYS_ERROR_SAVE_SECRETS))
            return
