# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Streamlit Utils."""

from __future__ import annotations

from enum import Enum
from logging import getLogger
import re

import streamlit as st

from ...core.locales import keys
from ..base.base_app import BaseApp


logger = getLogger(__name__)


class MessageLevel(Enum):
    """Enum for Streamlit Application Types."""

    USER_ERROR = "user_error"
    APP_WARNING = "system_error"
    APP_ERROR = "system_warning"


def error(
    message: str,
    level: MessageLevel = MessageLevel.USER_ERROR,
    exception: Exception | None = None,
    inplace: bool = False,
) -> None:
    """Display an error message in the Streamlit app.

    Args:
        level (MessageType): The type of error message to display.
        message (str): The error message to display.
        exception (Optional[Exception]): An optional exception to log with the error message.
        inplace (Optional[bools]): An optional parameter to show error inplace instead of popup
    """
    if not inplace:
        st.toast(f":red[{message}]")
    else:
        st.error(message)

    if level == MessageLevel.APP_WARNING:
        logger.warning(
            "Streamlit error: (%s) - Exception: (%s)",
            message,
            str(exception) if exception else "",
        )

    elif level == MessageLevel.APP_ERROR:
        logger.error(
            "Streamlit error: (%s) - Exception: (%s)",
            message,
            str(exception) if exception else "",
        )


def validate_input_table_name(app: BaseApp, table_name: str) -> bool:
    """Validate the input table name.

    Args:
        app: BaseApp instance.
        table_name: The name of the input table.

    Returns:
        bool: True if valid, False otherwise.

    """
    table_name = table_name.strip().lower()
    if len(table_name.strip()) == 0:
        error(
            level=MessageLevel.USER_ERROR,
            message=app._(keys.ERROR_INPUT_TABLE_REQUIRED),
            inplace=True,
        )
        return False
    if len(table_name.split(" ")) > 1:
        error(
            level=MessageLevel.USER_ERROR,
            message=app._(keys.ERROR_INPUT_TABLE_HAS_SPACES),
            inplace=True,
        )
        return False

    if not re.match("^[a-zA-Z]$", table_name[0]):
        error(
            level=MessageLevel.USER_ERROR,
            message=app._(keys.ERROR_INPUT_TABLE_FIRST_CHAR),
            inplace=True,
        )
        return False

    if len(table_name) < 4:  # noqa: PLR2004
        error(
            level=MessageLevel.USER_ERROR,
            message=app._(keys.ERROR_INPUT_TABLE_MIN_LENGTH),
            inplace=True,
        )
        return False

    if not re.match(r"^[a-zA-Z]\w{3,}$", table_name):
        error(
            level=MessageLevel.USER_ERROR,
            message=app._(keys.ERROR_INPUT_TABLE_INVALID_CHARS),
            inplace=True,
        )
        return False

    return True
