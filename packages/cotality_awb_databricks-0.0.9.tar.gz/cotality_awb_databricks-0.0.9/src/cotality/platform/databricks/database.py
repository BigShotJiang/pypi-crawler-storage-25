# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Databricks Database client."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
import io
import logging
from typing import IO, Any

from databricks.sdk import WorkspaceClient
from pandas import DataFrame as PandaDataFrame  # type: ignore[import-untyped]

from ...core.clgxtyping import CSVConfig, FileFormat, PlatformType
from ...core.error_codes import CommonErrorCodes
from ...core.exception import ClgxException
from ...core.interfaces.database import DatabaseClient as DatabaseInterface
from ...core.interfaces.database import DbConfig
from ...core.logger import LOG_HEADER_KEY_DATABASE, LOG_HEADER_KEY_SERVER, set_log_header


logger = logging.getLogger(__name__)

# Databricks configuration
db_config = DbConfig(
    db_type=PlatformType.DATABRICKS,
    string_quotation="'",
    table_name_separator=".",
    table_quotation="",
)
CAUSE = "%s. Cause: %s"
PARAM_QUERIES = "Parameterized queries not fully supported through spark adapter"


class PandaDatabricksQueryIterator:
    """Databricks Pandas Query Iterator that lazily fetches data in pages."""

    def __init__(self, data: PandaDataFrame, page_size: int = 1000) -> None:
        """Initialize the Pandas query iterator.

        Args:
            data: Pandas DataFrame with all results
            page_size (int, optional): Number of records per page. Defaults to 1000.
        """
        self.__data = data
        self.__page_size = page_size
        self.__position = 0

    def __iter__(self) -> PandaDatabricksQueryIterator:
        """Return iterator object.

        Returns:
            PandaDatabricksQueryIterator: Self iterator object
        """
        return self

    def __next__(self) -> PandaDataFrame:
        """Return next page of results as Pandas DataFrame.

        Raises:
            StopIteration: When no more data is available

        Returns:
            PandaDataFrame: Next page of results
        """
        if self.__position >= len(self.__data):
            raise StopIteration

        end_position = min(self.__position + self.__page_size, len(self.__data))
        result = self.__data.iloc[self.__position : end_position].copy()
        self.__position = end_position

        return result


class DatabaseClient(DatabaseInterface):
    """Databricks Database client."""

    def __init__(self, spark, workspace_client: WorkspaceClient) -> None:
        """Initialize the Databricks Database client.

        Args:
            spark: Databricks Spark adapter (local or remote connection)
            workspace_client: Databricks WorkspaceClient for secrets and storage
        """
        logger.info("Initializing Databricks Database client...")

        if not spark:
            raise ClgxException(
                error=CommonErrorCodes.GEN_INVALID_PARAMETER,
                parameters={"spark": spark},
                message="Spark adapter is required.",
            )

        self.__spark = spark
        self.__catalog = self.get_default_database()
        self.__workspace_client = workspace_client

        super().__init__(db_config)
        set_log_header(header=self.get_session_info())

    def __str__(self) -> str:
        """Return string representation of the database client."""
        return str(self.config)

    # ========== Metadata
    def get_session_info(self) -> dict[str, str]:
        """Extract session info for Databricks.

        Returns:
            dict[str, str]: Session information including catalog and schema
        """
        return {
            LOG_HEADER_KEY_SERVER: "Databricks",
            LOG_HEADER_KEY_DATABASE: self.__catalog,
        }

    def get_databases(self) -> list[str]:
        """Return list of catalog names (Databricks databases).

        Returns:
            List[str]: List of catalog names
        """
        try:
            df = self.__spark.sql("SHOW CATALOGS")
            df = df.toPandas()
            return df["catalog"].tolist()
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message="Failed to fetch catalogs (databases).",
            ) from err

    def get_default_database(self) -> str:
        """Return the default catalog name.

        Returns:
            str: Default catalog name
        """
        try:
            data = self.query_to_dict("select CURRENT_CATALOG() AS catalog")
            return data[0]["catalog"]
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message="Failed to get default catalog:",
            ) from err

    def get_schemas(self, database: str) -> list[str]:
        """Return list of schema names for a given catalog.

        Args:
            database (str): Catalog name (maps to database in interface)

        Returns:
            List[str]: List of schema names
        """
        try:
            df = self.__spark.sql(f"SHOW SCHEMAS IN {database}")
            df = df.toPandas()
            return df.iloc[:, 0].tolist()
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to fetch schemas for catalog: {database}",
            ) from err

    def get_tables(self, database: str, schema: str) -> list[str]:
        """Return list of table names from the catalog and schema.

        Args:
            database (str): Catalog name
            schema (str): Schema name

        Returns:
            List[str]: List of table names
        """
        if not database or not schema:
            return []

        try:
            df = self.__spark.sql(f"SHOW TABLES IN {database}.{schema}")
            df = df.toPandas()
            # Table name is usually in column named 'tableName'
            table_col = "tablename" if "tablename" in df.columns else df.columns[1]
            return df[table_col].tolist()
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to fetch tables for {database}.{schema}",
            ) from err

    def get_column_names(self, table: str) -> list[str]:
        """Return list of column names.

        Args:
             table (str): Full table name in format `catalog.schema.table`.

        Returns:
            List[str]: List of column names
        """
        try:
            table = self.remove_table_quotation(table)
            df = self.__spark.sql(f"DESCRIBE TABLE {table}")
            df = df.toPandas()
            return df.iloc[:, 0].tolist()
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to fetch columns for table: {table}",
            ) from err

    def get_column_data_types(self, table: str) -> dict[str, str]:
        """Return dictionary of column names with datatypes.

        Args:
             table (str): Full table name in format `catalog.schema.table`.

        Returns:
            Dict[str,str]: dict of column names with dtypes
        """
        df = self.query_to_pandas(f"SELECT * FROM {table} LIMIT 1")  # noqa: S608
        df.columns = df.columns.str.lower()
        data = df.dtypes.to_dict()
        return {k: str(v) for k, v in data.items()}

    # ================== Table Operations
    def row_counts(self, table: str) -> int:
        """Return row counts of the table.

        Args:
            table (str): Table name

        Returns:
            int: Row counts
        """
        try:
            sql = f"SELECT COUNT(*) AS count FROM {table}"  # noqa: S608
            data = self.query_to_dict(sql)
            if not data or len(data) == 0:
                return 0
            count = data[0].get("count", 0)
            return int(count) if count is not None else 0
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to get row count for table: {table}",
            ) from err

    def row_counts_for_tables(
        self, database: str, schema: str, table_filters: list[str] | None = None
    ) -> dict[str, int]:
        """Return row counts of all tables in the catalog and schema.

        Args:
            database (str): Catalog name
            schema (str): Schema name
            table_filters (Optional[List[str]], optional): List of table names to filter. Defaults to None.

        Returns:
            dict[str, int]: Dictionary with table names as keys and row counts as values
        """
        try:
            tables = table_filters if table_filters else self.get_tables(database, schema)
            result = {}

            for table_name in tables:
                full_table = f"{database}.{schema}.{table_name}"
                try:
                    result[table_name] = self.row_counts(full_table)
                except Exception as err:
                    logger.warning("Failed to get row count for %s: %s", full_table, err)
                    result[table_name] = 0

        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to get row counts for tables in {database}.{schema}",
            ) from err
        else:
            return result

    def clone_table(self, source_table: str, destination_table: str, copy_data: bool = False) -> None:
        """Create table with the specified schema.

        Args:
            source_table (str): Source table name
            destination_table (str): Destination table name
            copy_data (bool, optional): Copy data from source to destination. Defaults to False.
        """
        if copy_data:
            # Deep clone with data using Delta Lake
            query = f"CREATE OR REPLACE TABLE {destination_table} DEEP CLONE {source_table}"
        else:
            # Create empty table with same schema
            query = f"CREATE OR REPLACE TABLE {destination_table} LIKE {source_table}"

        try:
            self.execute(query)
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to clone table. Query: {query}",
            ) from err

    def drop_table(self, table: str) -> None:
        """Drop this table.

        Args:
            table (str): Full table name
        """
        query = f"DROP TABLE IF EXISTS {table}"
        try:
            self.execute(query)
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to drop table. Query: {query}",
            ) from err

    def truncate_table(self, table: str) -> None:
        """Truncate this table.

        Args:
            table (str): Full table name
        """
        query = f"TRUNCATE TABLE {table}"
        try:
            self.execute(query)
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to truncate table. Query: {query}",
            ) from err

    def cast_to_string(self, column: str) -> str:
        """Return SQL to cast the column to string.

        Args:
            column (str): Column name

        Returns:
            str: SQL to cast the column to string
        """
        return f"CAST({column} AS STRING)"

    # ================== Execute SQL
    def execute(self, sql: str, params: Sequence[Any] | None = None) -> None:
        """Execute SQL statement.

        Args:
            sql (str): SQL statement
            params (Optional[Sequence[Any]], optional): Parameters for the SQL query. Defaults to None.

        Returns:
            None
        """
        try:
            logger.info("Executing SQL: %s, Params: %s", sql, params)
            if params:
                logger.warning(PARAM_QUERIES)

            if params is None or len(params) == 0:
                self.__spark.sql(sql)
            else:
                param_dict = {f"arg{i + 1}": v for i, v in enumerate(params)}

                for i in range(len(params)):
                    sql = sql.replace("?", f"{{arg{i + 1}}}", 1)

                self.__spark.sql(sql, **param_dict)

        except Exception as err:
            message = f"Failed to execute SQL: {sql}, Params: {params}"
            logger.exception(CAUSE, message, err)  # noqa: TRY401
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=message,
                cause=err,
            ) from err

    def call_proc(self, proc_name: str, *args: Any) -> None:  # noqa: ANN401
        """Call stored procedure with arguments.

        Note: Databricks supports stored procedures but implementation varies.
        This is a basic implementation that may need adjustment based on your procedures.

        Args:
            proc_name (str): Procedure name
            *args: Arguments for the procedure
        Returns:
            None
        """

    # ================== Write Data
    def append_data(self, dataframe: PandaDataFrame, table: str) -> None:
        """Append data to the destination table.

        Args:
            table (str): Table name
            dataframe (PandaDataFrame): Dataframe to append
        Returns:
            None
        """
        if dataframe.empty:
            logging.warning("Dataframe is empty, skipping append operation.")
            return

        try:
            # Write dataframe to temporary table first
            # Note: This requires the dataframe to be compatible with Databricks
            # In production, you might want to use dbutils or other methods
            cursor = self.__spark.sql

            # Get column names and types
            columns = list(dataframe.columns)
            column_list = ", ".join(columns)

            # Insert data row by row (for small datasets)
            # For large datasets, consider using COPY INTO or dbutils
            for _, row in dataframe.iterrows():
                values = ", ".join([f"'{val!s}'" if val is not None else "NULL" for val in row])
                insert_sql = f"INSERT INTO {table} ({column_list}) VALUES ({values})"  # noqa: S608
                cursor(insert_sql)

        except Exception as err:
            columns_str = ", ".join([f"`{col!s}`" for col in dataframe.columns])
            message = f"Failed to append data to table. Table: {table}. Columns: {columns_str}"
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=message,
                cause=err,
            ) from err

    # ================== Query Data
    def table_to_pandas(self, table: str, columns: list[str] | None = None, limit: int = 0) -> PandaDataFrame:
        """Query and return all records to Panda dataframe.

        Args:
            table (str): Table name
            columns (list[str] | None, optional): List of columns to select. Defaults to None (select all).
            limit (int, optional): Limit the number of records. Defaults to 0 (no limit).

        Returns:
            PandaDataFrame: Dataframe with records
        """
        try:
            select_cols = "*"
            if columns:
                select_cols = ", ".join([f"`{c}`" for c in columns])

            query = f"SELECT {select_cols} FROM {table}"  # noqa: S608

            if limit > 0:
                query += f" LIMIT {limit}"

            return self.query_to_pandas(query)
        except Exception as err:
            message = f"Failed to fetch data to PandaDataFrame from table: {table}"
            logger.exception(CAUSE, message, err)  # noqa: TRY401
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=message,
            ) from err

    def query_to_pandas(self, query_sql: str, params: Sequence[Any] | None = None) -> PandaDataFrame:
        """Query and return all records to a Pandas DataFrame.

        Args:
            query_sql (str): SQL query string
            params (Optional[Sequence[Any]], optional): Parameters for the SQL query. Defaults to None.

        Returns:
            PandaDataFrame: Dataframe with results
        """
        try:
            logger.debug("Executing query_to_pandas SQL: %s, Params: %s", query_sql, params)
            if params:
                logger.warning(PARAM_QUERIES)

            df = self.__spark.sql(query_sql, args=params)
            df = df.toPandas()
            df.columns = df.columns.str.lower()
        except Exception as err:
            message = f"Failed to query to PandaDataFrame: {query_sql}, Params: {params}"
            logger.exception(CAUSE, message, err)  # noqa: TRY401
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=message,
                cause=err,
            ) from err
        else:
            return df

    def query_to_pandas_iterator(
        self,
        query_sql: str,
        page_size: int = 1000,
        params: Sequence[Any] | None = None,
    ) -> Iterable[PandaDataFrame]:
        """Return Panda Iterator to fetch records from this query.

        Args:
            query_sql (str): SQL query string
            page_size (int, optional): Page size. Defaults to 1000.
            params (Optional[Sequence[Any]], optional): Parameters for the SQL query. Defaults to None.

        Returns:
            Iterable[PandaDataFrame]: Iterator of Panda DataFrames with records
        """
        logger.info("Creating PandaDatabricksQueryIterator with page size: %d", page_size)
        try:
            logger.debug("Executing query_to_pandas_iterator SQL: %s, Params: %s", query_sql, params)
            if params:
                logger.warning(PARAM_QUERIES)

            df = self.__spark.sql(query_sql, args=params)
            df = df.toPandas()
            return PandaDatabricksQueryIterator(df, page_size)

        except Exception as err:
            message = f"Failed to query to Panda Iterator: {query_sql}, Params: {params}"
            logger.exception(CAUSE, message, err)  # noqa: TRY401
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=message,
            ) from err

    def query_to_dict(self, query_sql: str, params: Sequence[Any] | None = None) -> list[dict]:
        """Query and return all records to List[dict].

        Args:
            query_sql (str): SQL query string
            params (Optional[Sequence[Any]], optional): Parameters for the SQL query. Defaults to None.

        Returns:
            List[dict]: List of dictionaries with records
        """
        try:
            logger.debug("Executing query_to_dict SQL: %s, Params: %s", query_sql, params)
            df = self.query_to_pandas(query_sql, params)
            return df.to_dict(orient="records")
        except Exception as err:
            message = f"Failed to query to List[dict]: {query_sql}, Params: {params}"
            logger.exception(CAUSE, message, err)  # noqa: TRY401
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=message,
                cause=err,
            ) from err

    def upload_file_to_storage(self, content: IO[bytes], file_path: str) -> None:
        """Upload file to Databricks Unity Catalog volume.

        Args:
            content (IO[bytes]): Content to upload as a file
            file_path (str): File path in the volume

        Returns:
            None
        """
        try:
            volume_path = f"/Volumes/{self.__catalog}/cotality_app_clip_output/cotality_stage/{file_path}"

            self.__workspace_client.files.upload(
                volume_path,
                contents=io.BytesIO(content.getvalue()),  # type: ignore
                overwrite=True,
            )

        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to upload file to storage: {file_path}",
                cause=err,
            ) from err

    def load_from_storage_to_table(
        self, file_path: str, table_name: str, file_format: FileFormat, csv_config: CSVConfig | None
    ) -> None:
        """Load data from Unity Catalog volume to table.

        Args:
            file_path (str): File path to load data from
            table_name (str): Full table name to load data into
            file_format (FileFormat): File format to load data from
            csv_config (CSVConfig | None): CSV config to load data from
        """
        try:
            volume_path = f"/Volumes/{self.__catalog}/cotality_app_clip_output/cotality_stage/{file_path}"
            separator = csv_config.separator if csv_config is not None else ","

            # Drop and recreate so the schema defined by create_temp_table is always used.
            # (Avoids stale schemas left by prior failed runs.)
            self.__spark.sql(f"DROP TABLE IF EXISTS {table_name}")
            self.__spark.sql(f"""
                CREATE TABLE {table_name}
                AS SELECT * FROM read_files(
                    '{volume_path}',
                    format => '{file_format}',
                    header => true,
                    sep => '{separator}'
                )
            """) # noqa: S608

        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.DB_GENERAL,
                message=f"Failed to load data from storage to table: {table_name}",
                cause=err,
            ) from err

    def storage_cleanup(self, prefix: str) -> None:
        """Perform cleanup for Unity Catalog volume storage.

        Args:
            prefix (str): The prefix path to clean up in the storage

        Raises:
            ClgxException: If cleanup fails
        """
        try:
            volume_path = f"/Volumes/{self.__catalog}/cotality_app_clip_output/cotality_stage/{prefix}"

            # List and delete files with the prefix
            files = self.__workspace_client.files.list_directory_contents(volume_path)
            for file_info in files:
                if file_info.path is not None:
                    self.__workspace_client.files.delete(file_info.path)

        except Exception as err:
            logger.warning("Failed to cleanup storage at prefix: %s. Error: %s", prefix, err)
            # Don't raise exception for cleanup failures
