# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Databricks Cotality Application Wrapper.

Usage:
    pip install cotality-platform-databricks

    from cotality.platform.databricks.clip_app import ClipApp
    app = ClipApp()

    To display the Application UI, call:
    app.display()

    For automation, call these services:
    1. app.clip()
"""

from __future__ import annotations

from logging import getLogger

from pyspark.sql.connect.session import SparkSession

from ...app.panel.clip_app import ClipApp as ClipAppBase
from ...core.clgxtyping import Environment, Locale
from .platform import DatabricksPlatform


logger = getLogger(__name__)


class ClipApp(ClipAppBase):
    """Cotality application wrapper for Databricks platform."""

    instance: ClipApp | None = None

    def __init__(
        self,
        spark: SparkSession,
        environment: Environment = Environment.PROD,
        locale: Locale = Locale.EN_US,
    ) -> None:
        """Initialize ClipApp with Databricks platform.

        Args:
            spark: SparkSession instance for Databricks
            environment: Environment to connect to (DEV, UAT, PROD)
            locale: Locale for the application
        """
        try:
            self._platform = DatabricksPlatform(
                spark,
                environment=environment,
                locale=locale,
            )

            logger.info("DatabricksPlatform initialized successfully.")
            super().__init__(self._platform)
            logger.info("ClipApp initialized successfully.")
        except Exception:
            logger.exception("Error initializing ClipApp")
            raise


def get_instance(
    spark: SparkSession,
    environment: Environment = Environment.UAT,
    locale: Locale = Locale.EN_US,
) -> ClipApp:
    """Get or create the singleton ClipApp instance.

    Args:
        spark: SparkSession instance for Databricks
        environment: Environment to connect to
        locale: Locale for the application

    Returns:
        ClipApp: Singleton instance
    """
    if ClipApp.instance is None:
        ClipApp.instance = ClipApp(spark=spark, environment=environment, locale=locale)
    return ClipApp.instance
