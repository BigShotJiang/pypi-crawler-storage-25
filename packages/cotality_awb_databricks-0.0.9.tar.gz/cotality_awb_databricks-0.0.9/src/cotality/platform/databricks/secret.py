# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Databricks Secret client."""

from __future__ import annotations

import base64
import logging

from databricks.sdk import WorkspaceClient

from ...core.error_codes import CommonErrorCodes
from ...core.exception import ClgxException
from ...core.interfaces.secret import SecretClient as SecretInterface


logger = logging.getLogger(__name__)


class SecretClient(SecretInterface):
    """Databricks Secret Manager implementation for the SecretClient interface.

    This client interacts with Databricks Secret Scopes via dbutils to store and retrieve
    sensitive information like credentials.
    """

    # Define constants for secret names to ensure consistency
    _SECRET_SCOPE = "cotality"  # noqa: S105
    _DG_USERNAME_KEY = "digital_gateway_username"
    _DG_PW_KEY = "digital_gateway_password"

    def __init__(self, workspace_client: WorkspaceClient) -> None:
        """Initialize the Databricks Secret Manager client."""
        logger.info("Initializing Databricks Secret Manager client.")
        self._workspace_client = workspace_client

        super().__init__()

    def get_digital_gateway_credential(self) -> tuple[str, str]:
        """Return username & password for Digital Gateway from Databricks Secrets.

        Raises:
            ClgxException: If credentials cannot be retrieved

        Returns:
            Tuple[str,str]: username, password
        """
        logger.info("Retrieving Digital Gateway credentials from Databricks Secrets.")
        username: str | None = None
        password: str | None = None

        try:
            # Retrieve secrets
            username = self._workspace_client.secrets.get_secret(
                scope=self._SECRET_SCOPE, key=self._DG_USERNAME_KEY
            ).value
            password = self._workspace_client.secrets.get_secret(scope=self._SECRET_SCOPE, key=self._DG_PW_KEY).value

            if not username or not password:
                msg = "Username or password not found in Databricks Secrets."
                logger.warning(msg)
                raise ClgxException(  # noqa: TRY301
                    error=CommonErrorCodes.SYS_VAULT_FETCH_SECRETS,
                    message=msg,
                )

            username = base64.b64decode(username).decode("utf-8")
            password = base64.b64decode(password).decode("utf-8")

            return username, password  # noqa: TRY300

        except Exception as err:
            logger.exception("Error retrieving Digital Gateway credentials: %s", err)  # noqa: TRY401
            raise ClgxException(
                error=CommonErrorCodes.SYS_VAULT_FETCH_SECRETS,
                message=f"Failed to retrieve Digital Gateway credentials from Databricks Secrets: {err}",
            ) from err

    def save_digital_gateway_credential(self, username: str, password: str) -> None:
        """Save the Digital Gateway credential to Databricks Secrets.

        Args:
            username (str): Username for Digital Gateway
            password (str): Password for Digital Gateway

        Raises:
            ClgxException: If credentials cannot be saved
        """
        if not username or not password:
            msg = "Username and password cannot be empty."
            raise ValueError(msg)

        logger.info("Saving Digital Gateway credentials to Databricks Secrets.")

        try:
            # Save username
            self._put_secret(self._DG_USERNAME_KEY, username)

            # Save password
            self._put_secret(self._DG_PW_KEY, password)

            logger.info("Successfully saved Digital Gateway credentials to Databricks Secrets.")

        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.GEN_RUN_TIME,
                message=f"Failed to save Digital Gateway credentials to Databricks Secrets: {err}",
            ) from err

    # == Private Methods ===
    def _get_secret(self, key: str) -> str | None:
        """Helper function to retrieve a secret's value.

        Args:
            key (str): The key of the secret

        Returns:
            str | None: The secret value as a string, or None if not found

        Raises:
            ClgxException: If the secret cannot be accessed or does not exist
        """
        try:
            # Note: The SDK's get_secret returns the secret value directly
            # This is typically used in notebook/job contexts where secrets are accessed
            secret_value = self._workspace_client.secrets.get_secret(
                scope=self._SECRET_SCOPE,
                key=key,
            )

            if secret_value and hasattr(secret_value, "value"):
                return secret_value.value
            return ""  # noqa: TRY300

        except Exception as err:
            logger.warning("Secret not found or cannot be accessed: %s/%s", self._SECRET_SCOPE, key)
            raise ClgxException(
                error=CommonErrorCodes.GEN_INVALID_PARAMETER,
                parameters={"scope": self._SECRET_SCOPE, "key": key},
                message=f"Secret not found: {self._SECRET_SCOPE}/{key}",
                cause=err,
            ) from err

    def _put_secret(self, key: str, value: str) -> None:
        """Helper function to store a secret's value.

        Args:
            key (str): The key of the secret
            value (str): The value to store

        Raises:
            ClgxException: If the secret cannot be stored
        """
        try:
            self._workspace_client.secrets.put_secret(
                scope=self._SECRET_SCOPE,
                key=key,
                string_value=value,
            )
        except Exception as err:
            raise ClgxException(
                error=CommonErrorCodes.GEN_RUN_TIME,
                message=f"Failed to store secret: {self._SECRET_SCOPE}/{key}",
                cause=err,
            ) from err
