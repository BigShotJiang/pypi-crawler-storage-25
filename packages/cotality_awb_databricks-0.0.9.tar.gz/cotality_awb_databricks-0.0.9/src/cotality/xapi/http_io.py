# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""HTTP IO."""

from __future__ import annotations

from collections.abc import Generator
import logging
from typing import Any

from pandas import DataFrame as PandaDataFrame  # type: ignore[import-untyped]
import requests

from ..core.clgxtyping import APIResponse, FileFormat
from ..core.platform import Platform


logger = logging.getLogger(__name__)


def upload_dataframe(
    platform: Platform,
    dataframe: PandaDataFrame,
    signed_url: str,
    file_format: FileFormat = FileFormat.CSV,
    chunk_size: int = 1000,
    timeout: int = 1 * 60 * 60,
) -> APIResponse:
    """Upload a DataFrame to the DMZ.

    Args:
        platform: Platform object.
        dataframe: Pandas DataFrame to upload.
        signed_url: Signed URL for upload.
        file_format: Output format (default: CSV).
        chunk_size: Number of rows per chunk (default: 1000).
        timeout: Upload timeout in seconds (default: 3600).

    Returns:
        APIResponse: Response containing success status and error message if any.

    """
    logger.debug("Uploading DataFrame to URL: %s", signed_url)
    response = APIResponse(
        success=True,
    )
    try:
        headers = platform.user_context.create_standard_headers()
        api_response = requests.put(
            url=signed_url,
            data=generate_data_chunks(
                dataframe=dataframe,
                file_format=file_format,
                chunk_size=chunk_size,
            ),
            headers=headers,
            timeout=timeout,
        )
        response.response_text = api_response.text
        response.status_code = api_response.status_code
        if api_response.status_code == 200:  # noqa: PLR2004
            response.success = True
    except Exception as e:
        response.success = False
        response.error_message = f"Error uploading DataFrame. Reason:{e!s}"
    return response


def generate_data_chunks(
    dataframe: PandaDataFrame, file_format: FileFormat = FileFormat.CSV, chunk_size: int = 1000
) -> Generator[Any, Any, None]:
    """Generate data chunks from a DataFrame for upload.

    Args:
        dataframe: Pandas DataFrame to chunk.
        file_format: Output format for chunks (default: CSV).
        chunk_size: Number of rows per chunk (default: 1000).

    Yields:
        Data chunks in the specified format.

    """
    df_size = len(dataframe)
    loc = 0

    while loc < df_size:
        end_loc = min(loc + chunk_size, df_size)
        df_chunk = dataframe.iloc[loc:end_loc]
        if file_format == FileFormat.CSV:
            chunk = df_chunk.to_csv(index=False, header=loc == 0, sep="\t")
            yield chunk
        else:
            msg = f"Unsupported file format: {format}"
            raise ValueError(msg)
        loc += chunk_size
