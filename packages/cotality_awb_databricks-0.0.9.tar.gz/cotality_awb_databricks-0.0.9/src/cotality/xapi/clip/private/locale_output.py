# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Clip Output."""

from __future__ import annotations

import enum
from logging import getLogger
from typing import Any

from ....core.clgxtyping import AppSchemaID, Country, PlatformType
from ....core.error_codes import CommonErrorCodes
from ....core.exception import ClgxException
from ....core.platform import Platform
from ..typing import ClipOutputReferenceColumns
from .clip_job import ClipJob
from .clip_us.output import ClipOutputTable as ClipOutputTableUS


logger = getLogger(__name__)


class Columns(enum.Enum):
    """Column names for the CLIP output table."""

    REFERENCE_ID = "reference_id"
    CLIP_STATUS = "clip_status"
    CLIP_ID = "clip_id"
    CURRENT_HASH = "current_hash"

    def __str__(self) -> str:
        """Return string.

        Returns:
            str: String
        """
        return str(self.value)


class ClipOutputTable:
    """Base class for Clip Output Table."""

    def __init__(self, platform: Platform) -> None:
        """Initialize the ClipOutputTable instance.

        Args:
            platform (Platform): Platform instance
        """
        self._platform = platform
        self._database_client = platform.database_client

        self._database_name, self._schema_name = platform.get_schema(AppSchemaID.CLIP_OUTPUT)
        contry_code = platform.config.locale.country_code
        match contry_code:
            case Country.US:
                self._table = ClipOutputTableUS(
                    database_client=platform.database_client,
                    database_name=self._database_name,
                    schema_name=self._schema_name,
                    table_name="clip_output",
                )
            case _:
                raise ClgxException(
                    CommonErrorCodes.CLIP_APP_CONFIG,
                    message=f"ClipOutputTable is not implemented for country code: {contry_code}",
                )

    @property
    def table(self) -> ClipOutputTableUS:
        """Get the Clip output table.

        Returns:
            ClipOutputTableUS: Clip output table instance
        """
        return self._table

    def init_job(self, input_table: str) -> None:
        """Initialize a clip output entry for a new input table.

        If an entry for the input table already exists, this function does nothing.

        Args:
            input_table (str): Input table name without database & schema
        """
        _, _, input_table_only = self._table.database_client.parse_table(input_table)
        table_name = self._table.get_table_name(input_table_only)
        self._table.create(table_name=table_name, if_not_exists=True)

    def get_temp_tables(self, input_table_name: str, return_full_name: bool = True) -> tuple[str, str]:
        """Get the list of temporary tables created by the Clip output table.

        Returns:
            Tuple[str, str]: dedup_table_name, full_table_name
        """
        dedup_table_name = f"{input_table_name}_temp_dedup"
        full_table_name = f"{input_table_name}_temp_full"
        if return_full_name:
            dedup_table_name = self._database_client.full_table_name(
                database=self._database_name, schema=self._schema_name, table=dedup_table_name
            )
            full_table_name = self._database_client.full_table_name(
                database=self._database_name, schema=self._schema_name, table=full_table_name
            )
        return (dedup_table_name, full_table_name)

    def create_temp_tables(self, table_name: str) -> None:
        """Create a temporary table with the same schema as the Clip output table.

        Args:
            table_name (str): Name of the temporary table to create
        """
        dedup_table_name, full_table_name = self.get_temp_tables(table_name)
        self._table.drop(table_name=dedup_table_name)
        self._table.drop(table_name=full_table_name)
        self._table.create(table_name=dedup_table_name, if_not_exists=True)
        self._table.create(table_name=full_table_name, if_not_exists=True)

    def update_clip_metrics(self, clip_job: ClipJob) -> None:
        """Update the Clip metrics in the Clip job.

        Args:
            clip_job (ClipJob): The Clip job to update
        """
        dedup_table, _ = self.get_temp_tables(clip_job.input_table, return_full_name=True)
        logger.info("Calculate clip metrics from dedup: %s", dedup_table)

        try:
            row_counts = self._table.row_counts(dedup_table)
            if row_counts > 0:
                sql = f"""
SELECT COUNT({Columns.CLIP_ID}) AS clipped, COUNT(*) - COUNT({Columns.CLIP_ID}) AS not_clipped FROM {dedup_table}"""  # noqa: S608
                count_results = self._database_client.query_to_dict(sql)[0]
                clip_job.clip_metrics.input_metrics.non_clip_counts = count_results.get("not_clipped", 0)
                clip_job.clip_metrics.input_metrics.clip_counts = count_results.get("clipped", 0)
        except Exception as e:
            raise ClgxException(
                error=CommonErrorCodes.CLIP_FAILED_TO_SAVE_CLIP_RESULTS,
                parameters={"name": clip_job.input_table},
                message="Failed to update Clip metrics",
                cause=e,
            ) from e

    def consolidate_clip_output_table(
        self, input_table: str, full_reference_table: str, ref_input_column_names: list[str]
    ) -> None:
        """Consolidate the Clip output table from the temporary table to the final output table.

        Args:
            input_table (str): Name of the input table
            full_reference_table (str): Full name of the reference input table
            ref_input_column_names (list[str]): List of input column names
        """
        self._update_dedup_table_with_input_columns(
            input_table=input_table,
            full_reference_table=full_reference_table,
            ref_input_column_names=ref_input_column_names,
        )
        self._create_full_table_from_dedup(
            input_table=input_table,
            full_reference_table=full_reference_table,
        )
        self._delete_clip_records_from_clip_output_table(input_table=input_table)
        self._insert_clip_records_to_clip_output_table(input_table=input_table)

    def _update_dedup_table_with_input_columns(
        self, input_table: str, full_reference_table: str, ref_input_column_names: list[str]
    ) -> None:
        """Update the dedup table with input columns from the input table.

        Args:
            input_table (str): Name of the input table
            full_reference_table (str): Full name of the reference input table
            ref_input_column_names (list[str]): List of input column names from the reference table
        """
        sql = ""
        params: list[Any] = []
        full_dedup_table_name, _ = self.get_temp_tables(input_table, return_full_name=True)
        try:
            logger.info("Update dedup table: %s with input columns: %s", full_dedup_table_name, ref_input_column_names)
            set_parts = [f"{name} = ref.{name}" for name in ref_input_column_names]
            set_clause = ", ".join(set_parts)

            # Build the aggregation for the GROUP BY query
            agg_parts = [f"ANY_VALUE({name}) AS {name}" for name in ref_input_column_names]
            agg_parts.append("current_hash")
            agg_clause = ", ".join(agg_parts)
            sql = UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL[self._platform.config.platform_type].format(
                full_dedup_table=full_dedup_table_name,
                full_reference_table=full_reference_table,
                set_clause=set_clause,
                agg_clause=agg_clause,
            )
            logger.debug("Update dedup table SQL: %s", sql)
            self._database_client.execute(sql)
        except Exception as e:
            raise ClgxException(
                error=CommonErrorCodes.CLIP_FAILED_TO_SAVE_CLIP_RESULTS,
                parameters={"name": full_dedup_table_name},
                message=(f"Failed to update dedup table with input columns.SQL: {sql}, Params: {params}"),
                cause=e,
            ) from e

    def _create_full_table_from_dedup(self, input_table: str, full_reference_table: str) -> None:
        """Insert clip records into the full output table from the dedup table.

        Args:
            input_table (str): Name of the input table
            full_reference_table (str): Full name of the reference input table
            ref_input_column_names (list[str]): List of input column names from the reference table
        """
        sql = ""
        params: list[Any] = []
        try:
            dedup_table_name, full_table_name = self.get_temp_tables(input_table)
            pk, output_columns = self._table.column_names
            pk_str = pk[0]
            output_column_expression = ", ".join(output_columns)
            dedup_output_columns = [f"dedup.{col}" for col in output_columns]
            dedup_output_column_expression = ", ".join(dedup_output_columns)

            logger.info("Insert dedup table: %s with input columns: %s", dedup_table_name, output_column_expression)
            sql = f"""
INSERT INTO {full_table_name} ({pk_str}, {output_column_expression})
SELECT ref.{pk_str}, {dedup_output_column_expression}
FROM {dedup_table_name} dedup LEFT JOIN {full_reference_table} ref
ON dedup.{Columns.REFERENCE_ID} = ref.{Columns.CURRENT_HASH}
""".strip()  # noqa: S608
            logger.debug("Update dedup table SQL: %s", sql)
            self._database_client.execute(sql)
        except Exception as e:
            raise ClgxException(
                error=CommonErrorCodes.CLIP_FAILED_TO_SAVE_CLIP_RESULTS,
                parameters={"name": full_table_name},
                message=(f"Failed to insert clip records.SQL: {sql}, Params: {params}"),
                cause=e,
            ) from e

    def _delete_clip_records_from_clip_output_table(self, input_table: str) -> None:
        """Delete clip records from the final output table.

        Args:
            input_table (str): Name of the input table
        """
        sql = ""
        params: list[Any] = []
        try:
            _, full_table_name = self.get_temp_tables(input_table, return_full_name=True)
            final_table_name = self._table.get_table_name(input_table)
            pk, _ = self._table.column_names
            pk_str = pk[0]
            sql = f"""
DELETE FROM {final_table_name}
WHERE {pk_str} IN (SELECT {pk_str} FROM {full_table_name})
""".strip()  # noqa: S608
            logger.debug("Delete clip records SQL: %s", sql)
            self._database_client.execute(sql)
        except Exception as e:
            raise ClgxException(
                error=CommonErrorCodes.CLIP_FAILED_TO_SAVE_CLIP_RESULTS,
                parameters={"name": final_table_name},
                message=(f"Failed to delete clip records.SQL: {sql}, Params: {params}"),
                cause=e,
            ) from e

    def _insert_clip_records_to_clip_output_table(self, input_table: str) -> None:
        """Merge clip records from the temporary full table to the final output table.

        Args:
            input_table (str): Name of the input table
        """
        sql = ""
        params: list[Any] = []
        try:
            _, full_table_name = self.get_temp_tables(input_table, return_full_name=True)
            final_table_name = self._table.get_table_name(input_table)
            pk, output_columns = self._table.column_names
            pk_col = pk[0]
            output_column_expression = ", ".join(output_columns)
            sql = f"""
INSERT INTO {final_table_name} ({pk_col}, {output_column_expression})
SELECT {pk_col}, {output_column_expression}
FROM {full_table_name} src
""".strip()  # noqa: S608
            logger.debug("Merge clip records SQL: %s", sql)
            self._database_client.execute(sql)
        except Exception as e:
            raise ClgxException(
                error=CommonErrorCodes.CLIP_FAILED_TO_SAVE_CLIP_RESULTS,
                parameters={"name": final_table_name},
                message=(f"Failed to merge clip records.SQL: {sql}, Params: {params}"),
                cause=e,
            ) from e

    def insert_records_from_storage_table_to_output_dedup_table(
        self,
        input_table: str,
        storage_table: str,
        column_names: tuple[list[str], list[str]],
        source_column_names: tuple[list[str], list[str]] | None = None,
    ) -> None:
        """Merge clip records from the temporary full table to the final output table.

        Args:
            input_table (str): Name of the input table
            storage_table (str): Full table name of the storage table
            column_names (list[str]): List of target column names (internal schema names)
            source_column_names (list[str]): List of source column names in storage_table
                (CSV aliases). When provided, columns are renamed on SELECT.
        """
        # TO-DO: Select is from storage_table that is not part of this class, revisit
        sql = ""
        params: list[Any] = []
        try:
            dedup_table_name, _ = self.get_temp_tables(input_table, return_full_name=True)
            pk, output_columns = column_names
            pk_col = pk[0]
            output_column_expression = ", ".join(output_columns)

            if source_column_names:
                src_pk, src_output_columns = source_column_names
                src_pk_col = src_pk[0]
                # Build SELECT that renames CSV alias columns to internal column names
                src_pk_expr = f"{src_pk_col} AS {pk_col}" if src_pk_col != pk_col else pk_col
                src_col_exprs = [
                    f"{src} AS {dst}" if src != dst else src for src, dst in zip(
                        src_output_columns, output_columns,strict=True
                    )
                ]
                select_expression = ", ".join([src_pk_expr,*src_col_exprs])
            else:
                select_expression = f"{pk_col}, {output_column_expression}"

            sql = f"""
INSERT INTO {dedup_table_name} ({pk_col}, {output_column_expression})
SELECT {select_expression}
FROM {storage_table}
""".strip()  # noqa: S608
            logger.debug("Insert clip records to dedup SQL: %s", sql)
            self._database_client.execute(sql)
        except Exception as e:
            raise ClgxException(
                error=CommonErrorCodes.CLIP_FAILED_TO_SAVE_CLIP_RESULTS,
                parameters={"name": dedup_table_name},
                message=(f"Failed to insert clip records to dedup.SQL: {sql}, Params: {params}"),
                cause=e,
            ) from e


# ========== SQL Queries ==========
__UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL_BQ = """
UPDATE {{full_dedup_table}} AS dedup
SET
    {{set_clause}}
FROM (
    SELECT
        {{agg_clause}}
    FROM {{full_reference_table}}
    GROUP BY {current_hash}
) AS ref
WHERE dedup.{reference_id} = ref.{current_hash};
""".strip().format(
    reference_id=ClipOutputReferenceColumns.REFERENCE_ID.value,
    current_hash=ClipOutputReferenceColumns.CURRENT_HASH.value,
)


__UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL_SNOWFLAKE = """
MERGE INTO {{full_dedup_table}} AS dedup
USING (
    SELECT
        {{agg_clause}}
    FROM {{full_reference_table}}
    GROUP BY {current_hash}
) AS ref
ON dedup.{reference_id} = ref.{current_hash}
WHEN MATCHED THEN
    UPDATE SET
        {{set_clause}}
""".strip().format(
    reference_id=ClipOutputReferenceColumns.REFERENCE_ID.value,
    current_hash=ClipOutputReferenceColumns.CURRENT_HASH.value,
)

UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL = {
    PlatformType.BIGQUERY: __UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL_BQ,
    PlatformType.SNOWFLAKE: __UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL_SNOWFLAKE,
    PlatformType.DATABRICKS: __UPDATE_DEDUP_WITH_INPUT_COLUMNS_SQL_SNOWFLAKE,
}
