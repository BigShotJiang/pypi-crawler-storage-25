# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Clip Lookup Typing."""

from __future__ import annotations

from dataclasses import dataclass, field
import enum

from dataclasses_json import DataClassJsonMixin

from cotality.core.clgxtyping import AddressAliases


CLIP_UPLOAD_API = "/signed-urls"
CLIP_SUBMIT_API_V2 = "/clip-batch"
CLIP_STATUS_API = "/clip-batch"
CLIP_DOWNLOAD_API = "/signed-urls"


@dataclass(init=True)
class ClipAPIConfig(DataClassJsonMixin):
    """Clip API Configuration."""

    best_match: bool = True
    google_fallback: bool = False
    legacy_county_source: bool = True


@dataclass(init=True, frozen=False)
class ClipSubmitAPI(DataClassJsonMixin):
    """ClipSubmitAPI request parameters."""

    endpoint: str = "universal"
    version: str = "v2"
    params: ClipAPIConfig = field(default_factory=ClipAPIConfig)


@dataclass(init=True, frozen=False)
class ClipSubmitInput(DataClassJsonMixin):
    """ClipSubmitInput request parameters."""

    format: str = "csv"
    delimiter: str = ","
    path: str = ""
    mappings: dict = field(default_factory=dict)


@dataclass(init=True, frozen=False)
class ClipSubmitOutput(DataClassJsonMixin):
    """ClipSubmitOutput request parameters."""

    format: str = "csv"
    path: str = ""
    fields: list[str] = field(default_factory=list)


@dataclass(init=True, frozen=False)
class ClipSubmitAPIRequest(DataClassJsonMixin):
    """ClipSubmitAPIRequest request payload."""

    request_id: str = ""
    client_name: str = ""
    api: ClipSubmitAPI = field(default_factory=ClipSubmitAPI)
    input: ClipSubmitInput = field(default_factory=ClipSubmitInput)
    output: ClipSubmitOutput = field(default_factory=ClipSubmitOutput)


class Columns(enum.Enum):
    """Column names for the CLIP output table."""

    REFERENCE_ID = AddressAliases.REFERENCE_ID.value
    STREET_ADDRESS = AddressAliases.STREET_ADDRESS.value
    CITY = AddressAliases.CITY.value
    STATE = AddressAliases.STATE.value
    ZIP_CODE = AddressAliases.ZIP_CODE.value
    FULL_ADDRESS = AddressAliases.FULL_ADDRESS.value
    APN = AddressAliases.APN.value
    FIPS_CODE = AddressAliases.FIPS_CODE.value
    OWNER_NAME_1 = AddressAliases.OWNER_NAME_1
    OWNER_NAME_2 = AddressAliases.OWNER_NAME_2
    LATITUDE = AddressAliases.LATITUDE.value
    LONGITUDE = AddressAliases.LONGITUDE.value
    CLIP_ID = "clip_id"
    CLIP_CLIP_STATUS_CODE = "clip_status_code"
    CLIP_APN_SEQUENCE_NUMBER = "clip_apn_sequence_number"
    CLIP_UNIVERSAL_PARCEL_ID = "clip_universal_parcel_id"
    CLIP_COUNTY_CODE = "clip_county_code"
    CLIP_LATITUDE = "clip_latitude"
    CLIP_LONGITUDE = "clip_longitude"
    CLIP_APN_UNFORMATTED = "clip_apn_unformatted"
    CLIP_APN_FORMATTED = "clip_apn_formatted"
    CLIP_PREVIOUS_APN_UNFORMATTED = "clip_previous_apn_unformatted"
    CLIP_FULL_ADDRESS = "clip_full_address"
    CLIP_ADDRESS_LINE = "clip_address_line"
    CLIP_HOUSE_NUMBER = "clip_house_number"
    CLIP_UNIT_NUMBER = "clip_unit_number"
    CLIP_UNIT_TYPE = "clip_unit_type"
    CLIP_STREET_NAME = "clip_street_name"
    CLIP_STREET_NAME_FULL = "clip_street_name_full"
    CLIP_STREET_NAME_SUFFIX = "clip_street_name_suffix"
    CLIP_STREET_NAME_PREFIX = "clip_street_name_prefix"
    CLIP_STREET_NAME_PREFIX_DIRECTION = "clip_street_name_prefix_direction"
    CLIP_CITY_LINE = "clip_city_line"
    CLIP_CITY = "clip_city"
    CLIP_STATE = "clip_state"
    CLIP_ZIP_CODE = "clip_zip_code"
    CLIP_COUNTY = "clip_county"
    CLIP_COUNTRY_CODE = "clip_country_code"
    CLIP_ZIP_PLUS4 = "clip_zip_plus4"
    CLIP_MATCH_CODE = "clip_match_code"
    CLIP_PROPERTY_MATCH_SCORE = "clip_property_match_score"
    CLIP_STREET_SIDE = "clip_street_side"
    CLIP_STREET_NAME_BASE = "clip_street_name_base"
    CLIP_STREET_NAME_SUFFIX_DIRECTION = "clip_street_name_suffix_direction"
    CLIP_UNIT_RANGE_HIGH = "clip_unit_range_high"
    CLIP_UNIT_RANGE_LOW = "clip_unit_range_low"
    CLIP_OWNER1_NAME = "clip_owner1_name"
    CLIP_OWNER2_NAME = "clip_owner2_name"
    CLIP_ADDRESS_ID = "clip_address_id"
    CLIP_USPS_RECOMMENDED_CITY = "clip_usps_recommended_city"
    CLIP_ADDRESS_ATTRIBUTES_ADDRESS_ID = "clip_address_attributes_address_id"
    CLIP_ADDRESS_ATTRIBUTES_ADDRESS_TYPE = "clip_address_attributes_address_type"
    CLIP_ADDRESS_ATTRIBUTES_FULL_ADDRESS = "clip_address_attributes_full_address"
    CLIP_ADDRESS_ATTRIBUTES_ADDRESS_LINE = "clip_address_attributes_address_line"
    CLIP_ADDRESS_ATTRIBUTES_HOUSE_NUMBER = "clip_address_attributes_house_number"
    CLIP_ADDRESS_ATTRIBUTES_UNIT_NUMBER = "clip_address_attributes_unit_number"
    CLIP_ADDRESS_ATTRIBUTES_UNIT_TYPE = "clip_address_attributes_unit_type"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME = "clip_address_attributes_street_name"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_SUFFIX = "clip_address_attributes_street_name_suffix"
    CLIP_ADDRESS_ATTRIBUTES_CITY_LINE = "clip_address_attributes_city_line"
    CLIP_ADDRESS_ATTRIBUTES_CITY = "clip_address_attributes_city"
    CLIP_ADDRESS_ATTRIBUTES_STATE = "clip_address_attributes_state"
    CLIP_ADDRESS_ATTRIBUTES_ZIP_CODE = "clip_address_attributes_zip_code"
    CLIP_ADDRESS_ATTRIBUTES_COUNTRY_CODE = "clip_address_attributes_country_code"
    CLIP_ADDRESS_ATTRIBUTES_LATITUDE = "clip_address_attributes_latitude"
    CLIP_ADDRESS_ATTRIBUTES_LONGITUDE = "clip_address_attributes_longitude"
    CLIP_ADDRESS_ATTRIBUTES_ZIP_PLUS4 = "clip_address_attributes_zip_plus4"
    CLIP_ADDRESS_ATTRIBUTES_STREET_SIDE = "clip_address_attributes_street_side"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_PREFIX = "clip_address_attributes_street_name_prefix"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_PREFIX_DIRECTION = "clip_address_attributes_street_name_prefix_direction"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_BASE = "clip_address_attributes_street_name_base"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_SUFFIX_DIRECTION = "clip_address_attributes_street_name_suffix_direction"
    CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_FULL = "clip_address_attributes_street_name_full"
    CLIP_ADDRESS_ATTRIBUTES_UNIT_RANGE_HIGH = "clip_address_attributes_unit_range_high"
    CLIP_ADDRESS_ATTRIBUTES_UNIT_RANGE_LOW = "clip_address_attributes_unit_range_low"
    CLIP_ADDRESS_ATTRIBUTES_GEOCODE_DATA_SET = "clip_address_attributes_geocode_data_set"
    CLIP_ADDRESS_ATTRIBUTES_GEOCODE_VENDOR = "clip_address_attributes_geocode_vendor"
    CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_CODE = "clip_address_attributes_address_match_code"
    CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_DESCRIPTION = "clip_address_attributes_address_match_description"
    CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_RECORD = "clip_address_attributes_address_match_record"
    CLIP_ADDRESS_ATTRIBUTES_USPS_RECOMMENDED_CITY = "clip_address_attributes_usps_recommended_city"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN1 = "clip_address_attributes_admin1"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN2 = "clip_address_attributes_admin2"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN3 = "clip_address_attributes_admin3"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN4 = "clip_address_attributes_admin4"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN5 = "clip_address_attributes_admin5"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN6 = "clip_address_attributes_admin6"
    CLIP_ADDRESS_ATTRIBUTES_ADMIN7 = "clip_address_attributes_admin7"
    CLIP_RESPONSE_STATUS = "clip_response_status"
    CLIP_RESULT_CODE = "clip_result_code"
    CLIP_PAGE_SIZE = "clip_page_size"
    CLIP_TOTAL_RECORDS = "clip_total_records"
    CLIP_TOTAL_PAGES = "clip_total_pages"
    CLIP_PAGE_NUMBER = "clip_page_number"

    def __str__(self) -> str:
        """Return string.

        Returns:
            str: String
        """
        return str(self.value)


@dataclass(init=True, frozen=False)
class ClipOutput(DataClassJsonMixin):
    """CLIP Output dataclass model.

    This dataclass represents the structure of CLIP output data
    combining customer input with CLIP API responses with business-friendly field names
    that map to database columns.
    """

    # === PRIMARY KEY FIELDS ===
    reference_id: str  # Unique reference identifier for the input record

    # === CUSTOMER INPUT ADDRESS FIELDS ===
    street_address: str | None = None  # Street address of the property
    city: str | None = None  # City name
    state: str | None = None  # State abbreviation
    zip_code: str | None = None  # ZIP code
    full_address: str | None = None  # Complete formatted address

    # === CUSTOMER INPUT PROPERTY FIELDS ===
    apn: str | None = None  # Assessor's Parcel Number
    fips_code: str | None = None  # Federal Information Processing Standards code

    # === CUSTOMER INPUT OWNER FIELDS ===
    owner_name_1: str | None = None  # Primary owner name
    owner_name_2: str | None = None  # Secondary owner name

    # === CUSTOMER INPUT LOCATION FIELDS ===
    latitude: float | None = None  # Geographic latitude coordinate
    longitude: float | None = None  # Geographic longitude coordinate

    # === CLIP API RESPONSE FIELDS ===
    clip_id: str | None = None  # CLIP identifier
    clip_clip_status: str | None = None  # CLIP processing status
    clip_apn_sequence_number: int | None = None  # APN sequence number
    clip_universal_parcel_id: str | None = None  # Universal parcel identifier
    clip_county_code: str | None = None  # County code
    clip_latitude: float | None = None  # CLIP latitude coordinate
    clip_longitude: float | None = None  # CLIP longitude coordinate
    clip_apn_unformatted: str | None = None  # Unformatted APN
    clip_apn_formatted: str | None = None  # Formatted APN
    clip_previous_apn_unformatted: str | None = None  # Previous unformatted APN
    clip_full_address: str | None = None  # CLIP full address
    clip_address_line: str | None = None  # CLIP address line
    clip_house_number: str | None = None  # House number
    clip_unit_number: str | None = None  # Unit number
    clip_unit_type: str | None = None  # Unit type
    clip_street_name: str | None = None  # Street name
    clip_street_name_full: str | None = None  # Full street name
    clip_street_name_suffix: str | None = None  # Street name suffix
    clip_street_name_prefix: str | None = None  # Street name prefix
    clip_street_name_prefix_direction: str | None = None  # Street name prefix direction
    clip_city_line: str | None = None  # City line
    clip_city: str | None = None  # CLIP city
    clip_state: str | None = None  # CLIP state
    clip_zip_code: str | None = None  # CLIP ZIP code
    clip_county: str | None = None  # CLIP county
    clip_country_code: str | None = None  # CLIP country code
    clip_zip_plus4: str | None = None  # CLIP ZIP+4
    clip_match_code: str | None = None  # Match code
    clip_property_match_score: float | None = None  # Property match score
    clip_street_side: str | None = None  # Street side
    clip_street_name_base: str | None = None  # Street name base
    clip_street_name_suffix_direction: str | None = None  # Street name suffix direction
    clip_unit_range_high: str | None = None  # Unit range high
    clip_unit_range_low: str | None = None  # Unit range low
    clip_owner1_name: str | None = None  # CLIP owner 1 name
    clip_owner2_name: str | None = None  # CLIP owner 2 name
    clip_address_id: str | None = None  # Address ID
    clip_usps_recommended_city: str | None = None  # USPS recommended city

    # === CLIP ADDRESS ATTRIBUTES ===
    clip_address_attributes_address_id: str | None = None  # Address attributes address ID
    clip_address_attributes_address_type: str | None = None  # Address attributes address type
    clip_address_attributes_full_address: str | None = None  # Address attributes full address
    clip_address_attributes_address_line: str | None = None  # Address attributes address line
    clip_address_attributes_house_number: str | None = None  # Address attributes house number
    clip_address_attributes_unit_number: str | None = None  # Address attributes unit number
    clip_address_attributes_unit_type: str | None = None  # Address attributes unit type
    clip_address_attributes_street_name: str | None = None  # Address attributes street name
    clip_address_attributes_street_name_suffix: str | None = None  # Address attributes street name suffix
    clip_address_attributes_city_line: str | None = None  # Address attributes city line
    clip_address_attributes_city: str | None = None  # Address attributes city
    clip_address_attributes_state: str | None = None  # Address attributes state
    clip_address_attributes_zip_code: str | None = None  # Address attributes ZIP code
    clip_address_attributes_country_code: str | None = None  # Address attributes country code
    clip_address_attributes_latitude: float | None = None  # Address attributes latitude
    clip_address_attributes_longitude: float | None = None  # Address attributes longitude
    clip_address_attributes_zip_plus4: str | None = None  # Address attributes ZIP+4
    clip_address_attributes_street_side: str | None = None  # Address attributes street side
    clip_address_attributes_street_name_prefix: str | None = None  # Address attributes street name prefix
    clip_address_attributes_street_name_prefix_direction: str | None = (
        None  # Address attributes street name prefix direction
    )
    clip_address_attributes_street_name_base: str | None = None  # Address attributes street name base
    clip_address_attributes_street_name_suffix_direction: str | None = (
        None  # Address attributes street name suffix direction
    )
    clip_address_attributes_street_name_full: str | None = None  # Address attributes street name full
    clip_address_attributes_unit_range_high: str | None = None  # Address attributes unit range high
    clip_address_attributes_unit_range_low: str | None = None  # Address attributes unit range low
    clip_address_attributes_geocode_data_set: str | None = None  # Address attributes geocode data set
    clip_address_attributes_geocode_vendor: str | None = None  # Address attributes geocode vendor
    clip_address_attributes_address_match_code: str | None = None  # Address attributes address match code
    clip_address_attributes_address_match_description: str | None = None  # Address attributes address match description
    clip_address_attributes_address_match_record: str | None = None  # Address attributes address match record
    clip_address_attributes_usps_recommended_city: str | None = None  # Address attributes USPS recommended city
    clip_address_attributes_admin1: str | None = None  # Address attributes admin level 1
    clip_address_attributes_admin2: str | None = None  # Address attributes admin level 2
    clip_address_attributes_admin3: str | None = None  # Address attributes admin level 3
    clip_address_attributes_admin4: str | None = None  # Address attributes admin level 4
    clip_address_attributes_admin5: str | None = None  # Address attributes admin level 5
    clip_address_attributes_admin6: str | None = None  # Address attributes admin level 6
    clip_address_attributes_admin7: str | None = None  # Address attributes admin level 7

    # === CLIP PAGINATION AND STATUS ===
    clip_status: int | None = None  # CLIP status code
    clip_result_code: str | None = None  # CLIP result code
    clip_page_size: int | None = None  # Page size
    clip_total_records: int | None = None  # Total records
    clip_total_pages: int | None = None  # Total pages
    clip_page_number: int | None = None  # Current page number


CLIP_METRICS_KEYS_TO_CLIP_OUTPUT_COLUMNS = {
    "property_match_score": Columns.CLIP_PROPERTY_MATCH_SCORE.value,
    "result_code": Columns.CLIP_RESULT_CODE.value,
    "match_code": Columns.CLIP_MATCH_CODE.value,
    "address_type": Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_TYPE.value,
    "address_match_code": Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_CODE.value,
}
