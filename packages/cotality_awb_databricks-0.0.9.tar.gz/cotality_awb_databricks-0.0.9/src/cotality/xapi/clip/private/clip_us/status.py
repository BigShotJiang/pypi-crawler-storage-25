# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Clip Lookup - Job Status."""

from __future__ import annotations

import json
import logging
import time

from .....core.error_codes import CommonErrorCodes
from .....core.exception import ClgxException
from .....core.platform import Platform
from .....core.utils.dict import dict_snake_case
from .....core.utils.misc import datetime_to_int, duration_in_minutes
from ...typing import ClipLookupAction
from ..clip_job import ClipJob, ClipJobStatus, ClipJobTable
from .typing import CLIP_STATUS_API


logger = logging.getLogger(__name__)


def execute(
    platform: Platform,
    clip_job: ClipJob,
    clip_job_table: ClipJobTable,
    stop_after_submit: bool = False,
) -> None:
    """Call batch API to submit clip data.

    Args:
        platform (Platform): Platform object
        clip_job (ClipJob): Clip job object
        clip_job_table (_ClipJobTable): Table to update clip job status
        stop_after_submit (bool): Whether to stop after submitting the job successfully
    """
    if clip_job.step < ClipLookupAction.SUBMIT_JOB:
        return
    _run_poll_loop(platform, clip_job, clip_job_table, stop_after_submit)


def _run_poll_loop(
    platform: Platform,
    clip_job: ClipJob,
    clip_job_table: ClipJobTable,
    stop_after_submit: bool,
) -> None:
    """Poll the clip job status until it reaches a terminal state."""
    logger.info("Checking status of Clip job ID: %s", clip_job.clip_job_id)
    dg_client = platform.digital_gateway_client
    headers = {"Content-Type": "application/json"}
    api = f"{CLIP_STATUS_API}/jobs/{clip_job.clip_job_id}"
    update_interval = 120  # 2 minutes since these are NOT OLTP databases
    last_update_time = time.time()
    clip_job.step = ClipLookupAction.POLL_JOB

    for attempt in range(1000):
        response = dg_client.get(api=api, headers=headers)
        response_data = _parse_response(response)
        _update_status_metrics(clip_job, response_data)
        sleep_time, done = _handle_status(clip_job, response_data, stop_after_submit)
        if done:
            break
        logger.info(
            "Attempt %d: Clip job status: %s/%s. Response:%s",
            attempt + 1,
            clip_job.clip_job_raw_status,
            clip_job.clip_job_status,
            response.text,
        )
        if attempt == 0 or (time.time() - last_update_time > update_interval):
            clip_job_table.update(clip_job)
            last_update_time = time.time()
        time.sleep(sleep_time)

    clip_job_table.update(clip_job)


def _parse_response(response: object) -> dict:
    """Parse the API response and return a snake_case dict."""
    data = dict_snake_case(json.loads(response.text))  # type: ignore[attr-defined]
    if not isinstance(data, dict):
        raise ClgxException(
            error=CommonErrorCodes.CLIP_FAILED_TO_PARSE_API_RESPONSE,
            message="Expected dict response from status API",
        )
    return data


def _update_status_metrics(clip_job: ClipJob, response_data: dict) -> None:
    """Update clip_job metrics fields from the status API response."""
    raw_status = response_data.get("current_status", "")
    clip_job.clip_job_raw_status = str(raw_status) if raw_status else ""
    clip_job.clip_job_status = _clip_job_status(clip_job.clip_job_raw_status)

    est_start_time = response_data.get("estimated_start_time", "")
    clip_job.clip_metrics.clip_status_summary.clip_estimated_start_time = str(est_start_time) if est_start_time else ""

    est_time_remaining = response_data.get("estimated_time_remaining", 0)
    clip_job.clip_metrics.clip_status_summary.clip_estimated_time_remaining_in_minutes = (
        int(est_time_remaining) if est_time_remaining and isinstance(est_time_remaining, (int, float, str)) else 0
    )

    records_processed = response_data.get("recordsProcessed", 0)
    clip_job.clip_metrics.clip_status_summary.clip_records_processed = (
        int(records_processed) if records_processed and isinstance(records_processed, (int, float, str)) else 0
    )


def _handle_status(
    clip_job: ClipJob,
    response_data: dict,
    stop_after_submit: bool,
) -> tuple[int, bool]:
    """Map the current job status to a sleep interval and a done flag.

    Returns:
        (sleep_time_seconds, done) — done=True means the poll loop should stop.
    """
    match clip_job.clip_job_raw_status:
        case "ACCEPTED" | "EVALUATING" | "PENDING":
            return 60, False
        case "RUNNING":
            if stop_after_submit:
                logger.info("Clip job %s is now running. Stopping as per configuration.", clip_job.clip_job_id)
                return 30, True
            return 30, False
        case "SUMMARIZING":
            return 15, False
        case "COMPLETED" | "FAILED" | "CANCELLED":
            _finalize_job(clip_job, response_data)
            return 0, True
        case _:
            return 60, False


def _finalize_job(clip_job: ClipJob, response_data: dict) -> None:
    """Record completion metrics and raise if the job did not complete successfully."""
    clip_job.clip_metrics.clip_status_summary.clip_finished_at = datetime_to_int()
    clip_job.clip_metrics.clip_status_summary.clip_duration_in_minutes = duration_in_minutes(
        start_time=clip_job.clip_metrics.clip_status_summary.clip_started_at,
        end_time=clip_job.clip_metrics.clip_status_summary.clip_finished_at,
    )
    message = f"Clip job {clip_job.clip_job_id} ended with status {clip_job.clip_job_status}, Details: {response_data}"
    if clip_job.clip_job_raw_status == "COMPLETED":
        logger.info(message)
    else:
        raise ClgxException(error=CommonErrorCodes.API_INVALID_RESPONSE, message=message)


# # ================ Private Functions ================
def _clip_job_status(job_status: str) -> ClipJobStatus:
    """Convert job status string to ClipJobStatus enum."""
    match job_status:
        case "ACCEPTED" | "EVALUATING" | "PENDING":
            return ClipJobStatus.SUBMITTED
        case "RUNNING" | "SUMMARIZING":
            return ClipJobStatus.RUNNING
        case "COMPLETED":
            return ClipJobStatus.COMPLETED
        case "FAILED":
            return ClipJobStatus.FAILED
        case "CANCELLED":
            return ClipJobStatus.CANCELED
        case _:
            logger.warning("Unknown job status:%s. Defaulting to UNKNOWN.", job_status)
            return ClipJobStatus.UNKNOWN
