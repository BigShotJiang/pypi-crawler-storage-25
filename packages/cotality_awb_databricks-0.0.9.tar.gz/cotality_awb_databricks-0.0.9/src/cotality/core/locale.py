# Copyright 2022 CORELOGIC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Logger."""

from __future__ import annotations

from collections.abc import Callable
import gettext
import locale
from pathlib import Path


# Type alias for gettext-like functions
_GetTextFn = Callable[[str], str]


class _Localization:
    """Localization for CLIP."""

    instance: _Localization | None = None

    def __init__(self, language: str, platform_type: str) -> None:
        """Initialize locale language. based on the language param."""
        self._get_text: _GetTextFn = lambda a: a  # placeholder for get_text
        self._platform_type = platform_type

        locale_path = Path(__file__).parent / "locales"

        if not locale_path.exists():
            msg = f"Locale path not found: {locale_path}"
            raise FileNotFoundError(msg)

        language_path = locale_path
        if not language_path.exists():
            language_path = locale_path / language[0:2]  # Language path only, ex: en

        if not language_path.exists():
            msg = f"Locale file not found: {language_path}"
            raise FileNotFoundError(msg)

        locale.setlocale(locale.LC_ALL, f"{language}.UTF-8")
        language_package = gettext.translation("base", localedir=str(language_path), languages=[language])
        language_package.install()
        self._get_text = language_package.gettext

    def _(self, key: str) -> str:
        """Returns localization based on Platform if this one exists in the base.po file.

        Returns platform-specific localization string.
        """
        _key = f"{key}_{self._platform_type}"
        output = self._get_text(_key)
        if output == _key:
            return self._get_text(key)
        return output


def Localization(language: str = "", platform_type: str = "") -> _Localization:  # noqa: N802   # NOSONAR
    """Get or create singleton instance of Localization.

    Args:
        language: Language code (default: "").
        platform_type: Platform type (default: "").

    Returns:
        _Localization: Singleton instance of the localization handler.

    """
    if _Localization.instance is None:
        _Localization.instance = _Localization(language, platform_type)
    return _Localization.instance
