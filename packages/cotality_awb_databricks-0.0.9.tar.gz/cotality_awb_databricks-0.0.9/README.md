# Python Client for Cotality Databricks SDK
This package provides a Python client for the Cotality Databricks SDK, allowing users to interact with Databricks services in a streamlined manner.

## Prerequisites
Python >= 3.12

## Installation
```zsh
pip install cotality-sdk-databricks
```

## Example usage

Install package:
```
!pip install cotality-sdk-databricks >/dev/null
```

Setup Clip Application
```
from cotality.platform.databricks.clip_app import ClipApp
app = ClipApp()
```
Display Clip application UI
```
app.display()
```
Run backgroun Clip job
```
app.run_job()
```
