"""Integration tests for cotality.airflow.v1.task module.

This module demonstrates integration testing patterns where we test
the complete flow with real objects and minimal mocking. Integration tests
should test how components work together.

Key Testing Patterns:
- Test end-to-end flows with real configuration objects
- Mock only external dependencies (network, file system, databases)
- Test actual data transformations and business logic
- Verify integration between multiple components
- Test realistic scenarios and user workflows
- Use 'assert actual == expected' format (left = actual, right = expected)
"""

import json

from corelogic.airflow.base import TaskContext
from corelogic.core.base.clgxtyping import StatusCode
from corelogic.core.base.interfaces import (
    CloudStorageClient,
    DbClient,
    SecretClient,
)
from mockito import ANY, mock, unstub, verify, when
import pytest

from cotality.airflow.v1.task import execute_task
from cotality.airflow.v1.typing import DestinationConfig, SourceConfig, TaskConfig


class TestTaskExecutionIntegration:
    """Integration tests for complete task execution flow.

    These tests demonstrate end-to-end execution with real TaskConfig
    and TaskContext objects, mocking only external I/O operations.
    """

    def setup_method(self) -> None:
        """Setup before each test method."""
        unstub()  # Clean up any previous mocks

    def teardown_method(self) -> None:
        """Cleanup after each test method."""
        unstub()  # Always cleanup mocks

    def test_complete_task_execution_flow(self) -> None:
        """Test complete task execution from start to finish.

        This integration test verifies:
        - TaskContext properly initializes all platform clients
        - TaskConfig values are correctly used throughout execution
        - Task response is properly formatted and serializable
        - All client context managers are properly entered and exited
        """
        # Arrange - Create real configuration objects
        task_config = TaskConfig(
            name="integration_test_task",
            source=SourceConfig(value="bucket://test-bucket/configs/task.yaml"),
            destination=DestinationConfig(value="bucket://output-bucket/results/output.yaml"),
        )

        # Create mock TaskContext with realistic platform setup
        mock_task_context = self._create_mock_task_context(
            task_id="integration_task_001", pipeline_id="pipeline_123", dag_id="test_dag"
        )

        # Act - Execute the complete task
        result_json = execute_task(mock_task_context, task_config)

        # Assert - Verify complete execution (actual == expected)
        assert result_json is not None
        assert isinstance(result_json, str)

        # Parse and verify JSON response
        result_dict = json.loads(result_json)
        assert result_dict["task_id"] == "integration_task_001"
        assert result_dict["task_name"] == "integration_test_task"
        assert result_dict["task_class"] == "SDK"
        assert result_dict["status"] == StatusCode.SUCCESS.value

        # Verify all platform clients were accessed
        verify(mock_task_context.platform, times=1).get_cloud_storage_client()
        verify(mock_task_context.platform, times=1).get_cloud_db_client()
        verify(mock_task_context.platform, times=1).get_secret_client()

    def test_task_execution_with_real_data_processing(self) -> None:
        """Test task execution with realistic data processing scenario.

        Simulates a real-world scenario where:
        - Task processes multiple input files
        - Generates multiple output files
        - Returns sorted output paths
        """
        # Arrange - Real configuration
        task_config = TaskConfig(
            name="data_processing_task",
            source=SourceConfig(value="bucket://input/data/*.csv"),
            destination=DestinationConfig(value="bucket://output/processed/"),
        )

        mock_task_context = self._create_mock_task_context(task_id="data_proc_001", pipeline_id="data_pipeline")

        # Act
        result_json = execute_task(mock_task_context, task_config)

        result_dict = json.loads(result_json)
        assert result_dict["task_name"] == "data_processing_task"
        assert result_dict["status"] == StatusCode.SUCCESS.value

        # Verify data location includes destination config
        data_locations = result_dict.get("data_locations", {})
        destination_loc = data_locations.get("destination", {})
        assert destination_loc.get("value") == "bucket://output/processed/"

    def test_task_execution_with_multiple_job_ids(self) -> None:
        """Test task execution that spawns multiple downstream jobs.

        This simulates a scenario where a task triggers multiple
        parallel processing jobs and tracks all their IDs.
        """
        # Arrange
        task_config = TaskConfig(name="multi_job_task")

        mock_task_context = self._create_mock_task_context(task_id="multi_job_001")

        # Act
        result_json = execute_task(mock_task_context, task_config)

        result_dict = json.loads(result_json)
        assert "job_id" in result_dict
        # In this implementation, job_id defaults to empty string
        # In real scenarios, this would contain actual job identifiers
        assert isinstance(result_dict["job_id"], str)

    def test_task_execution_error_handling_with_platform_failure(self) -> None:
        """Test task behavior when platform client initialization fails.

        This integration test verifies error handling when external
        dependencies are unavailable.
        """
        # Arrange
        task_config = TaskConfig(name="error_handling_task")

        mock_task_context = mock(TaskContext)
        mock_platform = mock()
        mock_task_context.platform = mock_platform
        mock_task_context.task_id = "error_task_001"

        # Simulate failure in getting cloud storage client
        when(mock_platform).get_cloud_storage_client().thenRaise(ConnectionError("Failed to connect to Cloud Storage"))

        # Act & Assert - Expect the error to propagate
        with pytest.raises(ConnectionError) as exc_info:
            execute_task(mock_task_context, task_config)

        assert "Failed to connect to Cloud Storage" in str(exc_info.value)

    def test_task_config_template_variable_preservation(self) -> None:
        """Test that Jinja2 template variables in config are preserved.

        Integration test to ensure configuration template variables
        are not prematurely resolved during task execution.
        """
        # Arrange - Config with template variables
        template_source = (
            "bucket://{{pipeline.dataset_config.bucket_zones.pl_config}}/"
            "scripts/{{pipeline.pipeline_id}}/{{pipeline.task_id}}.yaml"
        )
        template_destination = (
            "bucket://{{pipeline.dataset_config.bucket_zones.pl_output}}/"
            "results/{{pipeline.pipeline_id}}/{{pipeline.task_id}}/"
        )

        task_config = TaskConfig(
            name="template_test_task",
            source=SourceConfig(value=template_source),
            destination=DestinationConfig(value=template_destination),
        )

        mock_task_context = self._create_mock_task_context(task_id="template_task_001")

        # Act
        result_json = execute_task(mock_task_context, task_config)

        # Assert - Template variables should be in response (actual == expected)
        result_dict = json.loads(result_json)
        data_locations = result_dict.get("data_locations", {})

        # Find destination location
        dest_location = data_locations.get("destination", {})
        assert dest_location is not None
        assert dest_location.get("value") == template_destination
        assert "{{pipeline." in dest_location.get("value", "")

    def _create_mock_task_context(
        self, task_id: str, pipeline_id: str = "test_pipeline", dag_id: str = "test_dag"
    ) -> TaskContext:
        """Helper method to create a properly configured mock TaskContext.

        This demonstrates the pattern of creating reusable mock fixtures
        for integration testing.

        Args:
            task_id: Unique task identifier.
            pipeline_id: Pipeline identifier.
            dag_id: DAG identifier.

        Returns:
            Configured mock TaskContext ready for testing.
        """
        mock_task_context = mock(TaskContext)
        mock_platform = mock()

        # Set up context attributes
        mock_task_context.platform = mock_platform
        mock_task_context.task_id = task_id
        mock_task_context.pipeline_id = pipeline_id
        mock_task_context.dag_id = dag_id

        # Mock all platform client context managers
        self._setup_platform_clients(mock_platform)

        return mock_task_context

    def _setup_platform_clients(self, mock_platform) -> None:
        """Helper method to set up all platform client mocks.

        This demonstrates the DRY principle by centralizing mock setup
        for reuse across multiple tests.

        Args:
            mock_platform: Mock platform object to configure.
        """
        # Cloud Storage Client - Create context manager mock
        mock_storage = mock(CloudStorageClient)
        storage_context = mock()
        when(storage_context).__enter__().thenReturn(mock_storage)
        when(storage_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_cloud_storage_client().thenReturn(storage_context)

        # Cloud DB Client - Create context manager mock
        mock_db = mock(DbClient)
        db_context = mock()
        when(db_context).__enter__().thenReturn(mock_db)
        when(db_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_cloud_db_client().thenReturn(db_context)

        # Secret Client - Create context manager mock
        mock_secret = mock(SecretClient)
        secret_context = mock()
        when(secret_context).__enter__().thenReturn(mock_secret)
        when(secret_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_secret_client().thenReturn(secret_context)


class TestTaskConfigIntegration:
    """Integration tests for TaskConfig with real dataclass behavior.

    These tests verify that TaskConfig works correctly with
    dataclass serialization and field defaults.
    """

    def test_task_config_json_serialization(self) -> None:
        """Test TaskConfig can be serialized to JSON and back."""
        # Arrange
        original_config = TaskConfig(
            name="serialization_test",
            source=SourceConfig(value="bucket://source/config.yaml"),
            destination=DestinationConfig(value="bucket://dest/output.yaml"),
        )

        # Act - Serialize to JSON
        json_str = original_config.to_json()

        # Deserialize back to object
        restored_config = TaskConfig.from_json(json_str)

        # Assert - Verify round-trip (actual == expected)
        assert restored_config.name == original_config.name
        assert restored_config.class_name == original_config.class_name
        assert restored_config.source.value == original_config.source.value
        assert restored_config.destination.value == original_config.destination.value

    def test_task_config_default_values(self) -> None:
        """Test that TaskConfig has correct default values."""
        # Act - Create config with defaults
        config = TaskConfig()

        # Assert - Verify defaults (actual == expected)
        assert config.name == "${{GLOBAL:APPLICATION_NAME_HYPHEN}}"
        assert config.class_name == "SDK"
        assert isinstance(config.source, SourceConfig)
        assert isinstance(config.destination, DestinationConfig)

    def test_task_config_immutable_class_name(self) -> None:
        """Test that class_name cannot be modified via initialization."""
        # Act
        config = TaskConfig(name="test")

        # Assert - class_name should always be "SDK" (actual == expected)
        assert config.class_name == "SDK"

        # Verify it's set by field default, not __init__
        # This is enforced by init=False in the dataclass field


class TestEndToEndWorkflow:
    """End-to-end integration tests simulating real user workflows.

    These tests demonstrate complete user scenarios from configuration
    creation through task execution to result processing.
    """

    def setup_method(self) -> None:
        """Setup before each test."""
        unstub()

    def teardown_method(self) -> None:
        """Cleanup after each test."""
        unstub()

    def test_full_pipeline_execution_workflow(self) -> None:
        """Test complete pipeline workflow from config to result.

        This simulates a real-world scenario:
        1. User creates task configuration
        2. Configuration is loaded into task execution
        3. Task executes with all platform services
        4. Results are returned in correct format
        5. Results can be parsed and used downstream
        """
        # Step 1: User creates configuration
        pipeline_config = {
            "task_name": "full_pipeline_task",
            "source_bucket": "bucket://input-data/configs/",
            "destination_bucket": "bucket://output-data/results/",
        }

        task_config = TaskConfig(
            name=pipeline_config["task_name"],
            source=SourceConfig(value=pipeline_config["source_bucket"]),
            destination=DestinationConfig(value=pipeline_config["destination_bucket"]),
        )

        # Step 2: Configuration is serialized (e.g., stored in database)
        serialized_config = task_config.to_json()
        assert serialized_config is not None

        # Step 3: Configuration is deserialized (e.g., loaded from database)
        loaded_config = TaskConfig.from_json(serialized_config)

        # Step 4: Task execution environment is prepared
        mock_task_context = mock(TaskContext)
        mock_platform = mock()
        mock_task_context.platform = mock_platform
        mock_task_context.task_id = "full_pipeline_001"

        # Setup all platform services
        self._setup_all_clients(mock_platform)

        # Step 5: Task executes
        result_json = execute_task(mock_task_context, loaded_config)

        # Step 6: Results are processed
        result = json.loads(result_json)

        # Step 7: Verify complete workflow (actual == expected)
        assert result["task_name"] == pipeline_config["task_name"]
        assert result["status"] == StatusCode.SUCCESS.value
        assert result["task_id"] == "full_pipeline_001"

        # Verify results can be used for downstream processing
        assert "values" in result
        assert "data_locations" in result

    def test_multi_task_pipeline_integration(self) -> None:
        """Test scenario with multiple tasks in sequence.

        Simulates a pipeline where:
        - Task 1 processes initial data
        - Task 2 uses Task 1's output as input
        - Task 3 aggregates results
        """
        # Task 1: Data extraction
        task1_config = TaskConfig(
            name="extract_task",
            source=SourceConfig(value="bucket://raw-data/input/"),
            destination=DestinationConfig(value="bucket://processed/stage1/"),
        )

        # Task 2: Data transformation (uses Task 1's output)
        task2_config = TaskConfig(
            name="transform_task",
            source=SourceConfig(value="bucket://processed/stage1/"),
            destination=DestinationConfig(value="bucket://processed/stage2/"),
        )

        # Task 3: Data aggregation
        task3_config = TaskConfig(
            name="aggregate_task",
            source=SourceConfig(value="bucket://processed/stage2/"),
            destination=DestinationConfig(value="bucket://final-results/"),
        )

        # Execute all tasks in sequence
        mock_context = self._create_test_context("pipeline_multi_task")

        result1_json = execute_task(mock_context, task1_config)
        result1 = json.loads(result1_json)
        assert result1["task_name"] == "extract_task"

        result2_json = execute_task(mock_context, task2_config)
        result2 = json.loads(result2_json)
        assert result2["task_name"] == "transform_task"

        result3_json = execute_task(mock_context, task3_config)
        result3 = json.loads(result3_json)
        assert result3["task_name"] == "aggregate_task"

        # Verify all tasks succeeded (actual == expected)
        assert all(result["status"] == StatusCode.SUCCESS.value for result in [result1, result2, result3])

    def _create_test_context(self, task_id: str) -> TaskContext:
        """Helper to create test context with all clients.

        Args:
            task_id: Unique task identifier.

        Returns:
            Mock TaskContext with all clients configured.
        """
        mock_context = mock(TaskContext)
        mock_platform = mock()
        mock_context.platform = mock_platform
        mock_context.task_id = task_id
        self._setup_all_clients(mock_platform)
        return mock_context

    def _setup_all_clients(self, mock_platform) -> None:
        """Helper to setup all platform client mocks.

        Args:
            mock_platform: Mock platform object to configure.
        """
        # Cloud Storage Client - Create context manager mock
        storage_context = mock()
        when(storage_context).__enter__().thenReturn(mock())
        when(storage_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_cloud_storage_client().thenReturn(storage_context)

        # Cloud DB Client - Create context manager mock
        db_context = mock()
        when(db_context).__enter__().thenReturn(mock())
        when(db_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_cloud_db_client().thenReturn(db_context)

        # Secret Client - Create context manager mock
        secret_context = mock()
        when(secret_context).__enter__().thenReturn(mock())
        when(secret_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_secret_client().thenReturn(secret_context)
