"""Unit tests for cotality.airflow.v1.task module.

This module demonstrates proper use of mockito for mocking external dependencies
in unit tests. Unit tests should be fast, isolated, and test individual functions
without external dependencies.

Key Testing Patterns:
- Use mockito for mocking external dependencies
- Test each function in isolation
- Mock all external clients (DMZ, Cloud Storage, DB, etc.)
- Verify function behavior with different inputs
- Test error conditions and edge cases
- Use 'assert actual == expected' format (left = actual, right = expected)
"""

from corelogic.airflow.base import TaskContext
from corelogic.core.base.clgxtyping import StatusCode
from corelogic.core.base.task_typing import LOCATION_DESTINATION, TaskResponse
from mockito import ANY, mock, unstub, verify, when
import pytest

from cotality.airflow.v1.task import _custom_code, _to_task_response, execute_task
from cotality.airflow.v1.typing import DestinationConfig, SourceConfig, TaskConfig


class TestExecuteTask:
    """Test suite for execute_task function.

    This test class demonstrates how to:
    - Mock TaskContext and its platform clients
    - Verify context manager usage (with statements)
    - Test the main execution flow
    """

    def setup_method(self) -> None:
        """Setup before each test method."""
        unstub()  # Clean up any previous mocks

    def teardown_method(self) -> None:
        """Cleanup after each test method."""
        unstub()  # Always cleanup mocks

    def test_execute_task_with_all_clients_success(self) -> None:
        """Test successful execution with all platform clients."""
        # Arrange - Create mock objects
        mock_task_context = mock(TaskContext)
        mock_platform = mock()
        mock_task_context.platform = mock_platform
        mock_task_context.task_id = "test_task_123"

        # Mock all client context managers (no DMZ client in this implementation)
        mock_storage_client = mock()
        mock_db_client = mock()
        mock_secret_client = mock()

        # Configure the platform mock to return mock clients
        storage_context = mock()
        when(storage_context).__enter__().thenReturn(mock_storage_client)
        when(storage_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_cloud_storage_client().thenReturn(storage_context)

        db_context = mock()
        when(db_context).__enter__().thenReturn(mock_db_client)
        when(db_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_cloud_db_client().thenReturn(db_context)

        secret_context = mock()
        when(secret_context).__enter__().thenReturn(mock_secret_client)
        when(secret_context).__exit__(ANY, ANY, ANY).thenReturn(None)
        when(mock_platform).get_secret_client().thenReturn(secret_context)

        # Create task config
        task_config = TaskConfig(
            name="test_task",
            source=SourceConfig(value="bucket://test-source/config.yaml"),
            destination=DestinationConfig(value="bucket://test-dest/output.yaml"),
        )

        # Act - Execute the task
        result = execute_task(mock_task_context, task_config)

        # Assert - Verify the result (actual == expected)
        assert result is not None
        assert isinstance(result, str)
        assert "test_task" in result
        assert "success" in result  # StatusCode.SUCCESS.value is lowercase "success"

        # Verify all clients were accessed (no DMZ client)
        verify(mock_platform, times=1).get_cloud_storage_client()
        verify(mock_platform, times=1).get_cloud_db_client()
        verify(mock_platform, times=1).get_secret_client()

    def test_execute_task_with_minimal_config(self) -> None:
        """Test execution with minimal task configuration."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_platform = mock()
        mock_task_context.platform = mock_platform
        mock_task_context.task_id = "minimal_task"

        # Mock client context managers with proper context manager pattern
        for method_name in ["get_cloud_storage_client", "get_cloud_db_client", "get_secret_client"]:
            context_mgr = mock()
            when(context_mgr).__enter__().thenReturn(mock())
            when(context_mgr).__exit__(ANY, ANY, ANY).thenReturn(None)
            # Use getattr to get the method and then call it
            when(mock_platform).get_cloud_storage_client().thenReturn(
                context_mgr
            ) if method_name == "get_cloud_storage_client" else None
            when(mock_platform).get_cloud_db_client().thenReturn(
                context_mgr
            ) if method_name == "get_cloud_db_client" else None
            when(mock_platform).get_secret_client().thenReturn(
                context_mgr
            ) if method_name == "get_secret_client" else None

        task_config = TaskConfig()  # Use default config

        # Act
        result = execute_task(mock_task_context, task_config)

        assert result is not None
        assert "${{GLOBAL:APPLICATION_NAME_HYPHEN}}" in result


class TestCustomCode:
    """Test suite for __custom_code function.

    Demonstrates testing of internal functions with proper type hints
    and return value verification.
    """

    def test_custom_code_returns_success_message(self) -> None:
        """Test that custom code returns expected success message."""
        # Arrange
        task_config = TaskConfig(name="custom_test")
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "test_123"

        # Act
        result = _custom_code(task_config, mock_task_context)

        assert result == "Custom code executed successfully"

    def test_custom_code_with_different_configs(self) -> None:
        """Test custom code with various task configurations."""
        # Arrange
        configs = [
            TaskConfig(name="config1"),
            TaskConfig(name="config2"),
            TaskConfig(name="config3"),
        ]
        mock_task_context = mock(TaskContext)
        # Configure the task_id attribute for each test iteration
        mock_task_context.task_id = "test_context_id"

        for config in configs:
            result = _custom_code(config, mock_task_context)
            assert result == "Custom code executed successfully"


class TestToTaskResponse:
    """Test suite for __to_task_response function.

    Demonstrates testing of response building logic with different
    input combinations and edge cases.
    """

    def test_to_task_response_with_output_paths(self) -> None:
        """Test task response creation with output paths."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "task_001"

        task_config = TaskConfig(
            name="test_response", destination=DestinationConfig(value="bucket://output/results.yaml")
        )

        output_paths = ["path/to/file1.txt", "path/to/file2.txt", "path/to/file3.txt"]
        job_ids = "job_123,job_456"

        # Act
        response = _to_task_response(mock_task_context, task_config, output_paths=output_paths, job_ids=job_ids)

        assert isinstance(response, TaskResponse)
        assert response.task_id == "task_001"
        assert response.task_name == "test_response"
        assert response.task_class == "SDK"
        assert response.status == StatusCode.SUCCESS
        assert response.job_id == "job_123,job_456"
        assert response.values == sorted(output_paths)

    def test_to_task_response_without_output_paths(self) -> None:
        """Test task response creation without output paths (default message)."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "task_002"

        task_config = TaskConfig(name="no_output_test")

        # Act - No output_paths provided (None)
        response = _to_task_response(mock_task_context, task_config)

        assert isinstance(response, TaskResponse)
        assert response.task_id == "task_002"
        assert response.status == StatusCode.SUCCESS
        assert isinstance(response.values, dict)
        assert response.values["message"] == "Custom code processing completed successfully."

    def test_to_task_response_with_empty_output_paths(self) -> None:
        """Test task response with empty output paths list."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "task_003"

        task_config = TaskConfig(name="empty_output_test")

        # Act
        response = _to_task_response(
            mock_task_context,
            task_config,
            output_paths=[],  # Empty list
            job_ids="",
        )

        assert isinstance(response, TaskResponse)
        assert isinstance(response.values, dict)
        assert response.values["message"] == "Custom code processing completed successfully."

    def test_to_task_response_sorts_output_paths(self) -> None:
        """Test that output paths are sorted in the response."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "task_004"

        task_config = TaskConfig(name="sort_test")

        unsorted_paths = ["zebra.txt", "alpha.txt", "beta.txt"]
        expected_sorted = ["alpha.txt", "beta.txt", "zebra.txt"]

        # Act
        response = _to_task_response(mock_task_context, task_config, output_paths=unsorted_paths)

        assert response.values == expected_sorted

    def test_to_task_response_with_custom_job_ids(self) -> None:
        """Test task response with custom job IDs."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "task_005"

        task_config = TaskConfig(name="job_id_test")

        custom_job_ids = "custom_job_001,custom_job_002,custom_job_003"

        # Act
        response = _to_task_response(mock_task_context, task_config, job_ids=custom_job_ids)

        assert response.job_id == custom_job_ids


class TestTaskResponseIntegrity:
    """Test suite for TaskResponse data integrity.

    Demonstrates testing data location and configuration values.
    """

    def test_task_response_data_location(self) -> None:
        """Test that destination data location is properly set."""
        # Arrange
        mock_task_context = mock(TaskContext)
        mock_task_context.task_id = "location_test"

        destination_value = "bucket://test-bucket/output/results.yaml"
        task_config = TaskConfig(name="location_test", destination=DestinationConfig(value=destination_value))

        # Act
        response = _to_task_response(mock_task_context, task_config)

        # Use the correct constant LOCATION_DESTINATION instead of string "DESTINATION"
        data_location = response.get_data_location(LOCATION_DESTINATION)
        assert data_location.value == destination_value


# Parametrized tests for comprehensive coverage
@pytest.mark.parametrize(
    ("task_name", "expected_class"),
    [
        ("task_alpha", "SDK"),
        ("task_beta", "SDK"),
        ("task_gamma", "SDK"),
    ],
)
def test_task_config_class_name_consistency(task_name: str, expected_class: str) -> None:
    """Test that class_name is always 'SDK' regardless of task name.

    Args:
        task_name: Name to set for the task.
        expected_class: Expected class name (should always be 'SDK').
    """
    # Arrange & Act
    task_config = TaskConfig(name=task_name)

    assert task_config.class_name == expected_class


@pytest.mark.parametrize(
    ("output_paths", "expected_count"),
    [
        (["file1.txt"], 1),
        (["file1.txt", "file2.txt"], 2),
        (["file1.txt", "file2.txt", "file3.txt"], 3),
        (["file1.txt", "file2.txt", "file3.txt", "file4.txt", "file5.txt"], 5),
    ],
)
def test_to_task_response_output_path_count(output_paths: list, expected_count: int) -> None:
    """Test that correct number of output paths are included in response.

    Args:
        output_paths: List of file paths to include in response.
        expected_count: Expected number of paths in the response.
    """
    # Arrange
    mock_task_context = mock(TaskContext)
    mock_task_context.task_id = "count_test"
    task_config = TaskConfig(name="path_count_test")

    # Act
    response = _to_task_response(mock_task_context, task_config, output_paths=output_paths)

    assert len(response.values) == expected_count
