from pystac import Provider, ProviderRole

platforms = ["sentinel-1a", "sentinel-1b"]
instruments = ["c-sar"]
constellation = "sentinel-1"
mission = None
license_name = "CC-BY-NC-4.0"
license_href = "https://creativecommons.org/licenses/by-nc/4.0/"

providers = [
    Provider(
        "ESA", roles=[ProviderRole.PRODUCER], url="https://www.esa.int/", 
        description="The European Space Agency (ESA) is a 22-member intergovernmental body devoted to space exploration. With its headquarters in Paris and a staff of around 2,547 people globally as of 2023, the ESA was founded in 1975."
    ),
    Provider(
        "OSUG", roles=[ProviderRole.PROCESSOR, ProviderRole.LICENSOR], url="https://www.osug.fr/", 
        description="L'Observatoire des sciences de l'Univers de Grenoble (OSUG) est un observatoire des sciences de l'Univers (OSU) associé à l'Institut national des sciences de l'Univers (INSU) du CNRS et une école interne de l'université Grenoble-Alpes. Les OSU ont pour mission l’observation, la recherche, la formation et la diffusion des connaissances. L’OSUG œuvre dans tous les domaines des Sciences de l’Univers, de la planète Terre et de l’environnement."
    ),
    Provider(
        "OPGC", roles=[ProviderRole.HOST], url="https://opgc.uca.fr/", 
        description="L'Observatoire de physique du globe de Clermont-Ferrand (OPGC) est un observatoire des sciences de l'univers (OSU) dépendant du Centre national de la recherche scientifique (CNRS) et de l’université Clermont-Auvergne (UCA). Fondé en 1876 par Émile Alluard sous le nom d'Observatoire du Puy de Dôme, il s'est nommé l'Institut et observatoire de physique du globe (IOPG) de 1921 à 1985."
    )
]

publications = [{
    "citation": "Doin, M.-P., Lodge, F., Guillaso, S., Jolivet, R., Lasserre, C., Ducret, G., Grandin, R., Pathier, E., Pinel, V. (2011). Presentation of the small baseline NSBAS processing chain on a case example: The Etna deformation monitoring from 2003 to 2010 using Envisat data. In Proceedings of FRINGE 2011 ESA Workshop, Frascati, Italy,19–23 September 2011, ESA Publication SP-697.",
    "doi": "",
    "href": "https://flatsim.cnes.fr/doi/docs/NSBAS_Etna.pdf"
}, {
    "citation": "Raphaël Grandin (Institut de Physique du Globe de Paris, France) (2015). \"Interferometric Processing of SLC Sentinel-1 TOPS Data \". In Proceedings of FRINGE’15: Advances in the Science and Applications of SAR Interferometry and Sentinel-1 InSAR Workshop, Frascati, Italy, 23-27 March 2015, Ouwehand L., Ed., ESA Publication SP-731.",
    "doi": "10.5270/Fringe2015.116",
    "href": "https://proceedings.esa.int/files/116.pdf"
}, {
    "citation": "Thollard, F., Clesse, D., Doin, M.-P., Donadieu, J., Durand, P., Grandin, R., Lasserre, C., Laurent, C., Deschamps-Ostanciaux, E, Pathier, E., Pointal, E, Proy, C., Specht, B. (2021). FLATSIM: The ForM@Ter LArge-Scale Multi-Temporal Sentinel-1 InterferoMetry Service, Remote Sens. 13 (18), 3734.",
    "doi": "10.3390/rs13183734",
    "href": "https://www.mdpi.com/2072-4292/13/18/3734"
}]
