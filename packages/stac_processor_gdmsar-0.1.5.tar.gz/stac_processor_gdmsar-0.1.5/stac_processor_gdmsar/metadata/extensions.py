import stac_processor_gdmsar.metadata.common_metadata as metadata

def get_sat_extension_properties(json: dict) -> dict:
    # https://github.com/stac-extensions/sat
    properties = {}
    properties["sat:platform_international_designator"] = "2014-016A"
    if "orbitDirection" in json and properties["orbitDirection"].lower() in ["ascending", "descending"]:
        properties["sat:orbit_state"] = json["orbitDirection"].lower()
    else:
        properties["sat:orbit_state"] = "geostationary"
    if "absoluteOrbitNumber" in json:
        properties["sat:absolute_orbit"] = json["absoluteOrbitNumber"]
    if "relativeOrbitNumber" in json:
        properties["sat:relative_orbit"] = json["relativeOrbitNumber"]
    if "cycleNumber" in json:
        properties["sat:orbit_cycle"] = json["cycleNumber"]
    properties["sat_ext:platform_international_designators"] = ["2014-016A", "2016-025A"]
    # sat:orbit_state_vectors 	Map<string, [number]> 	The state vectors of the satellite at the time of acquisition.
    # sat:anx_datetime 	string 	The Ascending Node Crossing (ANX) time, in UTC. It is formatted according to RFC 3339, section 5.6.
    return properties

def get_sar_extension_properties(json: dict) -> dict:
    # https://github.com/stac-extensions/sar
    properties = {}
    properties["sar:frequency_band"] = "C"
    properties["sar:center_frequency"] = 5.405 # https://sentinel.esa.int/documents/247904/349449/S1_SP-1322_1.pdf page 22
    properties["sar_ext:wavelength"] = 0.05546576
    if "polarisation" in json:
        properties["sar:polarizations"] = json["polarisation"] if isinstance(json["polarisation"], list) else [json["polarisation"]]
    if "mode" in json:
        properties["sar:instrument_mode"] = json["mode"]
    # sar:bandwidth 	number 	The range bandwidth of the SAR instrument, in gigahertz (GHz), representing the full bandwidth used in range compression and image formation.
    try:
        if json["spatialResolution"][0][1] == "[m]": properties["sar:resolution_range"] = float(json["spatialResolution"][0][0])
        if json["spatialResolution"][1][1] == "[m]": properties["sar:resolution_azimuth"] = float(json["spatialResolution"][1][0])
    except:
        pass
    if "rangePixelSize" in json:
        properties["sar:pixel_spacing_range"] = float(json["rangePixelSize"])
    if "azimuthPixelSize" in json:
        properties["sar:pixel_spacing_azimuth"] = float(json["azimuthPixelSize"])
    if "numberOfLooksRange" in json:
        properties["sar:looks_range"] = float(json["numberOfLooksRange"])
    if "numberOfLooksAzimuth" in json:
        properties["sar:looks_azimuth"] = float(json["numberOfLooksAzimuth"])
    # sar:looks_equivalent_number 	number 	The equivalent number of looks (ENL).
    if "antennaSide" in json and json["antennaSide"].lower() in ["left", "right"]:
        properties["sar:observation_direction"] = json["antennaSide"].lower()
    # sar:relative_burst 	number 	Identification number that uniquely identifies a burst cycle within each repeat cycle.
    # sar:beam_ids 	[string] 	Composition of the swath of the SAR acquision referencing the beam identifiers.
    return properties

def get_processing_extension_properties(json: dict) -> dict:
    # https://github.com/stac-extensions/processing
    properties = {}
    if "appliedAlgorithmDescription" in json:
        properties["processing:expression"] = json["appliedAlgorithmDescription"]
    # processing:lineage 	string 	Lineage Information provided as free text information about the how observations were processed or models that were used to create the resource being described NASA ISO. For example, GRD Post Processing for "GRD" product of Sentinel-1 satellites. CommonMark 0.29 syntax MAY be used for rich text representation.
    if "productType" in json:
        properties["processing:lineage"] = json["productType"].lower().replace("_", " ")
    properties["processing:level"] = "L2"
    # processing:facility 	string 	The name of the facility that produced the data. For example, Copernicus S1 Core Ground Segment - DPA for product of Sentinel-1 satellites.
    # processing:datetime 	string 	Processing date and time of the corresponding data formatted according to RFC 3339, section 5.6, in UTC.
    if "softwareVersion" in json:
        properties["processing:version"] = json["softwareVersion"]
    if "serviceUsedForGeneration" in json:
        properties["processing:software"] = json["serviceUsedForGeneration"]
    return properties

def get_insar_extension_properties(json: dict) -> dict:
    # https://github.com/stac-extensions/insar
    properties = {}
    if "perpendicularBaseline" in json:
        properties["insar:perpendicular_baseline"] = float(json["perpendicularBaseline"])
    # insar:temporal_baseline 	number 	The time period between the reference and secondary acquisitions
    # insar:height_of_ambiguity 	number 	This height of ambiguity is the 2 π interferometric phase cycle scaled with the perpendicular baseline between both satellites. The smaller the height of ambiguity is, the lower is the influence of errors caused by the instrument or the different decorrelation effects.
    # insar:reference_datetime 	string 	Date of reference acquisition, in UTC. It is formatted according to RFC 3339, section 5.6.
    # insar:secondary_datetime 	string 	Date of secondary acquisition, in UTC. It is formatted according to RFC 3339, section 5.6.
    # insar:processing_dem 	string 	String representing the Digital Elevation Model used for processing the input data. A list is proposed in the DEMs section
    # insar:geocoding_dem 	string 	String representing the Digital Elevation Model used for geocoding the product. A list is proposed in the DEMs section
    return properties

def get_projection_extension_properties(json: dict) -> dict:
    # https://github.com/stac-extensions/projection#projepsg
    properties = {}
    # proj:code 	string|null 	Authority and specific code of the data source (e.g., EPSG:3857)
    if "geographicCSTypeCode" in json:
        properties["proj:code"] = json['geographicCSTypeCode']
    # proj:wkt2 	string|null 	WKT2 string representing the Coordinate Reference System (CRS) that the proj:geometry and proj:bbox fields represent
    # proj:projjson 	PROJJSON Object|null 	PROJJSON object representing the Coordinate Reference System (CRS) that the proj:geometry and proj:bbox fields represent
    # proj:geometry 	GeoJSON Geometry Object 	Defines the footprint of this Item.
    # proj:bbox 	[number] 	Bounding box of the Item in the asset CRS in 2 or 3 dimensions.
    # proj:centroid 	Centroid Object 	Coordinates representing the centroid of the Item (in lat/long)
    # proj:shape 	[integer] 	Number of pixels in Y and X directions for the default grid
    # proj:transform 	[number] 	The affine transformation coefficients for the default grid
    return properties

def get_scientific_extension_properties(json: dict) -> dict:
    # https://github.com/stac-extensions/scientific
    properties = {}
    # sci:doi 	string 	The DOI of the data, e.g. 10.1000/xyz123. This MUST NOT be a DOIs link. For all DOI names respective DOI links SHOULD be added to the links section (see chapter "Relation types").
    if "mainReference" in json:
        properties["sci:citation"] = json["mainReference"]
    # add publications without the href
    unlinked_publications = []
    for publication in metadata.publications:
        unlinked_publications.append({
            "citation": publication["citation"],
            "doi": publication["doi"]
        })
    properties["sci:publications"] = unlinked_publications
    return properties
