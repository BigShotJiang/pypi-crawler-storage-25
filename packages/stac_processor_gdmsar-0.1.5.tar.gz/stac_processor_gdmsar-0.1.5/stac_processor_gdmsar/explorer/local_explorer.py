import shutil
from typing import List, Any

import os
from os import path
import json
import json

from .base_explorer import BaseExplorer


class LocalExplorer(BaseExplorer):

    @classmethod
    def validate(cls, file: str) -> None:
        if not path.exists(file):
            raise FileNotFoundError(file)

    @classmethod
    def list_dir(cls, dir_listing_url: str) -> List[str]:
        return os.listdir(dir_listing_url)

    @classmethod
    def load_json(cls, file_url: str) -> Any:
        with open(file_url) as fp:
            return json.load(fp)

    @classmethod
    def load(cls, file_url: str) -> Any:
        with open(file_url) as fp:
            return fp.read()

    @classmethod
    def join(cls, file_dir_name: str, file_base_name: str) -> str:
        return path.join(file_dir_name, file_base_name)

    @classmethod
    def basename(cls, file: str) -> str:
        return path.basename(file)

    @classmethod
    def dirname(cls, file: str) -> str:
        return path.dirname(file)

    @classmethod
    def resolve(cls, file: str) -> str:
        return path.abspath(file)

    @classmethod
    def is_directory(cls, file: str) -> bool:
        return path.isdir(file)

    @classmethod
    def copy(cls, file: str, destination: str):
        shutil.copy(file, destination)
