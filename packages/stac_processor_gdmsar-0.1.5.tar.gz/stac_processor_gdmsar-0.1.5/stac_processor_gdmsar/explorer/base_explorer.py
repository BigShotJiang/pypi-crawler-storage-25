from typing import List, Any
import abc


class BaseExplorer(metaclass=abc.ABCMeta):

    @classmethod
    def validate(cls, url: str) -> None:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def list_dir(cls, dir_listing_url: str) -> List[str]:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def load_json(cls, file_url: str) -> Any:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def load(cls, file_url: str) -> str:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def join(cls, file_dir_name: str, file_base_name: str) -> str:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def basename(cls, file: str) -> str:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def dirname(cls, file: str) -> str:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def resolve(cls, file: str) -> str:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def is_directory(cls, file: str) -> bool:
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def copy(cls, file: str, destination: str):
        raise NotImplementedError
