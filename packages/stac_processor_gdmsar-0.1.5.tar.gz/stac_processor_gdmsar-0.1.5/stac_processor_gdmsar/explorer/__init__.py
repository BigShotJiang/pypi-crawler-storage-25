import logging
import re
from urllib.parse import urlparse

from .base_explorer import BaseExplorer
from .local_explorer import LocalExplorer
from .source_explorer import SourceExplorer

logger = logging.getLogger(__name__)

def is_local(url: str) -> bool:
    # test if the url is a local file path, which can be either an absolute path or a relative path
    # we can use urlparse to check if the url has a scheme, but keep in mind that Windows paths can have a drive letter followed by a colon, which can be mistaken for a scheme
    if re.match(r"^[a-zA-Z]:[\\/]", url):
        return True
    parsed = urlparse(url)
    return parsed.scheme in ("", "file")
    
def make_explorer(product_source: str) -> BaseExplorer:
    # the product can be either a local file path or a url, we need to determine which explorer to use based on the product source
    if is_local(product_source):
        # logger.info("Using local explorer")
        explorer = LocalExplorer
    else:
        # logger.info("Using source explorer")
        explorer = SourceExplorer

    try:
        explorer.validate(product_source)
    except Exception as error:
        raise ValueError(f"Bad product source : {product_source}") from error

    return explorer
