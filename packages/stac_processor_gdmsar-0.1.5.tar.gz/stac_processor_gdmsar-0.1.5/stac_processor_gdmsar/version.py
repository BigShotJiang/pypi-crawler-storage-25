from stac_processor_gdmsar.explorer import make_explorer


def version(product_source: str) -> str:
    # prepare the explorer based on the product source
    explorer = make_explorer(product_source)
    # list the files in the product source
    for file in explorer.list_dir(product_source):
        # only consider json files
        if file.endswith(".json"):
            # read the file and return its update time if it has one, otherwise go to the next file
            json_file = explorer.join(product_source, file)
            json_content = explorer.load_json(json_file)
            if "properties" in json_content and "updated" in json_content["properties"]:
                return json_content["properties"]["updated"]
    return ""