import logging
import pystac

from stac_processor_gdmsar.processor.gdmsar_element import GDMElement
import stac_processor_gdmsar.metadata.products as products

logger = logging.getLogger(__name__)

class GDMCatalog(GDMElement):
    # the children collections and items should be defined here, so we can use them to create the stac collection and the links
    child_collections: list = []
    child_items: list = []
    def __init__(self, path: str, child_collections: list = []) -> None:
        self.file_name = "catalog.json"
        self.folder_name = path
        self.child_collections = child_collections
        self.stac_id = "Root GDM-SAR-In catalog"
        self.title="Ground Deformation Monitoring using SAR Interferometry (GDM-SAR) - STAC Catalog",

        # use the children to create the stac collection
        self.stac_object = pystac.Catalog(
            id=self.stac_id, 
            description=products.read_template("root_catalog.md"), 
            title=self.title,
            catalog_type=pystac.CatalogType.SELF_CONTAINED
        )
        # add links to the stac collection
        self.add_common_links()
        
        logger.debug(f"Stac catalog {self.stac_id} created with {len(child_collections)} child collections")