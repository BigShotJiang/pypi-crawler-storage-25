from stac_processor_gdmsar.processor.gdmsar_item import GDMItem

class GDMGeoDEM(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "digital_elevation_model_item", files, ["dem"], "WGS84", date=date, resolution=resolution, default_keywords=["digital elevation model"])
class GDMRadarDEM(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "digital_elevation_model_item", files, ["dem"], "RADAR", date=date, resolution=resolution, default_keywords=["digital elevation model"])

class GDMGeoTCoh(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "temporal_coherence_item", files, ["tcoh"], "WGS84", date=date, resolution=resolution, default_keywords=["temporal coherence"])
class GDMRadarTCoh(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "temporal_coherence_item", files, ["tcoh"], "RADAR", date=date, resolution=resolution, default_keywords=["temporal coherence"])

class GDMGeoCosEnu(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_flatsim_item", files, ["cosenu"], "WGS84", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "ENU", "EPOS convention"])
class GDMRadarCosEnu(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_flatsim_item", files, ["cosenu"], "RADAR", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "ENU", "EPOS convention"])

class GDMGeoCosNeu(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_epos_item", files, ["cosneu"], "WGS84", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "NEU", "FlatSIM convention"])
class GDMRadarCosNeu(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_epos_item", files, ["cosneu"], "RADAR", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "NEU", "FlatSIM convention"])

class GDMGeoCoh(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "spatial_coherence_item", files, ["coh"], "WGS84", date=date, resolution=resolution, default_keywords=["spatial coherence"])
class GDMRadarCoh(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "spatial_coherence_item", files, ["coh"], "RADAR", date=date, resolution=resolution, default_keywords=["spatial coherence"])

class GDMGeoInW(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "wrapped_interferogram_item", files, ["inw"], "WGS84", date=date, resolution=resolution, default_keywords=["wrapped interferogram"])
class GDMRadarInW(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "wrapped_interferogram_item", files, ["inw"], "RADAR", date=date, resolution=resolution, default_keywords=["wrapped interferogram"])

class GDMGeoInWF(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "filtered_interferogram_item", files, ["inwf"], "WGS84", date=date, resolution=resolution, default_keywords=["filtered interferogram"])
class GDMRadarInWF(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "filtered_interferogram_item", files, ["inwf"], "RADAR", date=date, resolution=resolution, default_keywords=["filtered interferogram"])

class GDMGeoInU(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "unwrapped_interferogram_item", files, ["inu"], "WGS84", date=date, resolution=resolution, default_keywords=["unwrapped interferogram"])
class GDMRadarInU(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "unwrapped_interferogram_item", files, ["inu"], "RADAR", date=date, resolution=resolution, default_keywords=["unwrapped interferogram"])

class GDMGeoDts(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "los_displacement_time_series_item", files, ["dts_los", "geo_tot"], "WGS84", date=date, resolution=resolution, default_keywords=["LOS displacement"])
class GDMRadarDts(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "los_displacement_time_series_item", files, ["dts_los"], "RADAR", date=date, resolution=resolution, default_keywords=["LOS displacement"])

class GDMGeoNet(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "network_misclosure_item", files, ["net"], "WGS84", date=date, resolution=resolution, default_keywords=["network misclosure"])
class GDMRadarNet(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "network_misclosure_item", files, ["net"], "RADAR", date=date, resolution=resolution, default_keywords=["network misclosure"])

class GDMGeoMvlos(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "mean_velocity_map_item", files, ["mv-los"], "WGS84", date=date, resolution=resolution, default_keywords=["mean velocity map"])
class GDMRadarMvlos(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "mean_velocity_map_item", files, ["mv-los"], "RADAR", date=date, resolution=resolution, default_keywords=["mean velocity map"])

class GDMGeoLut(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "lookup_table_item", files, ["lut"], "WGS84", date=date, resolution=resolution, default_keywords=["lookup table"])
class GDMRadarLut(GDMItem):
    def __init__(self, main_id: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "lookup_table_item", files, ["lut"], "RADAR", date=date, resolution=resolution, default_keywords=["lookup table"])