# Network misclosures

> This product shows various indicators of the quality of the time series inversion, which allow to obtain phase delay time series from a stack of interferograms.
>
> The geotiff file has 5 bands:
>
> - band 1 shows the rms misclosure of the interferogram network for each pixel (in rad)
> - band 2 shows the number of interferograms used in the time series inversion for each pixel
> - band 3 shows the number of images used in the time series inversion for each pixel
> - band 4 is a proxy for the temporal coherence, computed from triplets (between 0 and rlooks_unw): it is a multilooked version of the proxy for the temporal coherence given in TCoh product
> - band 5 is a proxy for possible bias, computed from triplets (in rad)
> - band 6 is number of unwrapped interferograms greater of 8 months per pixel. It can be considered for a mask wrt the biais
> - band 7 can be 0, 1, or 2. 0 means OK. 1 means layover (i.e. area with two different altitudes in the same pixel). 2 means shadow (area with a very low amplitude)
>
> The png file has one band:
>
> - band 1 is the misclosure of the interferogram network for each pixel

[source](https://formater.pages.in2p3.fr/flatsim/products/Net.html)
