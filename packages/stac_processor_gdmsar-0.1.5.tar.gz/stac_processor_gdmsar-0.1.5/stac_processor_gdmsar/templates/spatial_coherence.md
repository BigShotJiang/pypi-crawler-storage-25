# Spatial Coherence

> This product represents the **spatial coherence** of the **interferograms**.
>
> The geotiff file has 2 bands:
>
> - band 1 is the spatial coherence of the interferogram (between 0 and 1)
> - band 2 is the average amplitudes of the two SAR images used to form the interferogram
>
> The png file has 1 band:
>
> - band 1 is the spatial coherence of the interferogram, normalized by a color palette

[source](https://formater.pages.in2p3.fr/flatsim/products/Coh.html)
