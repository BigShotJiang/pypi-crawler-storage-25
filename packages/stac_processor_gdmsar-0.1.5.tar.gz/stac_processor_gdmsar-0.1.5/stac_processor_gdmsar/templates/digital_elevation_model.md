# The Digital Elevation Model used in run {{processing.id}}


The product represents the **Digital Elevation Model** (elevation in m), by default from SRTM USGS.

The geotiff file has 2 bands:

    band 1 is the elevation (in m)

    band 2 is a shaded view of the topography (simulated SAR amplitude image from the DEM)

the png file has 1 band:

    band 1 is the elevation, normalized by a color palette.
