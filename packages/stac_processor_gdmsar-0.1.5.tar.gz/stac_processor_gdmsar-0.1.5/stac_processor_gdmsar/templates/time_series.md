# Time Serie

> The Time-series geotiff file is a (x,y,t) cube product (an envi file). The cube file contains phase delay images at each time step of the **time series**. Time series for some pixels might be incomplete because unwrapping did not extend everywhere and homogenously for all interferograms. The phase delay is cumulated since the first date that is valid for a given pixel. In order to improve visualization of data slices per date, in terrain geometry, the phase reference for each pixel is set to the origin (at time of first acquisition) of a linear fit through the time series. This representation avoids the APS of the first image to appear in negative on all other dates. However, it is not ideal in case of strongly non linear deformation.
>
> The geotiff file has nb_image bands (nb_image is the number of time steps). Each band is given in rad along the LOS, positive away from satellite.
>
> - Band name gives the date of the time step (YYYY-MM-DD)
>
> The png file has 1 band:
>
> - band 1 is last time step of the cube.

[source](https://formater.pages.in2p3.fr/flatsim/products/DTs.html)
