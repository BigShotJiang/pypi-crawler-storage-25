# Collection of products in **radar geometry** interferograms and time series from run {{processing.id}}

> During NSBAS processing, three phases can be recognized:
>
> - the Interfero phase: from the creation of working directory to the unwrapping step
> - the Time-Serie phase: time serie calculation
> - the Populate phase: generation of the products

_[source](https://formater.pages.in2p3.fr/flatsim/product.html)_

Accordingly, this collection contains a subcollection of all generated interferograms and a single item corresponding to the time series. Auxiliary files can be found as assets to the items, collection, or catalog they are generally relevant to.
