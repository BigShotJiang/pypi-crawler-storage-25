# Interferogram Collection {{processing.id}}

A collection of **interferograms** separated by dates.
