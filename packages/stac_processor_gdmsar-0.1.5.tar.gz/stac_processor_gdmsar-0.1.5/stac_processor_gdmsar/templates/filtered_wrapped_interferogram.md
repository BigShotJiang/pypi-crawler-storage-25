# Filtered Wrapped Interferogram

> This product corresponds to the **filtered wrapped interferogram**.
>
> The geotiff file has 2 bands:
>
> - band 1 is the filtered wrapped phase (phase difference between the two acquisitions) of the interferogram, corrected from stratified atmospheric delay (if asked) and from spectral diversity. It is by default filtered by a moving average, triangular window, filter. Multilooking is that defined with Rlooks_unw and given in nsbas.proc file.
> - band 2 is either the product of the two image’s amplitudes (if ROIPAC Goldstein filter is used) or a coherence (if a Sliding window filter is used (SW)). The coherence is obtained when the sliding window average is applied on the wrapped interferogram phase: it thus quantifies the quality of the filtered phase (1: good quality, 0: no coherence).
>
> The png file has 1 band:
>
> - band 1 is the filtered wrapped phase of the interferogram, normalized by a color palette.

[source](https://formater.pages.in2p3.fr/flatsim/products/InWF.html)
