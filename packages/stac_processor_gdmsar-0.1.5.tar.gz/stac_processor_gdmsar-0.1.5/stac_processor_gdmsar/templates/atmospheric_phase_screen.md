# Atmospheric Phase Screen

> The product shows the **atmospheric phase screen** (or **APS**) computed from a Global Atmospheric Model. The name of the atmospheric model is given in the metadata:
>
> - atmo (atmopheric correction used)
> - ECMWF_model (atmopheric model used)
>
> The geotiff file has 2 bands:
>
> - band 1 is the atmospheric phase delay of the interferogram (in rad), positive away from satellite
> - band 2 is a shaded view of the topography (simulated SAR amplitude image from the DEM)
>
> The png file has 1 band:
>
> - band 1 is the atmospheric phase delay of the interferogram, normalized by a color palette.

[source](https://formater.pages.in2p3.fr/flatsim/products/APS.html)
