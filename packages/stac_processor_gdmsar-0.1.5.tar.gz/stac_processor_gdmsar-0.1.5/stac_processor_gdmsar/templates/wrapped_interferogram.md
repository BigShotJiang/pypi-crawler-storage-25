# Wrapped Interferogram

> This product corresponds to the **wrapped interferogram**, after spectral diversity and atmospheric corrections, and multilooked (given in metadata)
>
> The geotiff file has 2 bands:
>
> - band 1 is the wrapped phase (phase difference between the two SAR image acquisitions) of the interferogram
> - band 2 is the product of the two image’s amplitudes (amplitude of the multilooked hermitian product of the two SAR acquisitions).
>
> The png file has 1 band:
>
> - band 1 is the wrapped phase of the interferogram, normalized by a color palette.

[source](https://formater.pages.in2p3.fr/flatsim/products/InW.html#product-description)
