# Mean velocity map

> This product shows the mean velocity map inverted from the time series analysis. It results from the linear fit to phase delay time series of each pixel. It has to be interpreted with caution as the time-series product (DTs) may contains residual atmospheric phase signal.
>
> The geotiff file has 2 bands:
>
> - band 1 is the mean velocity in rad/yr, positive away from satellite
> - band 2 is a shaded view of the topography (simulated amplitude from DEM simulation)
>
> The png file has 1 band:
>
> - band 1 shows the mean velocity map.

[source](https://formater.pages.in2p3.fr/flatsim/products/MV-LOS.html)
