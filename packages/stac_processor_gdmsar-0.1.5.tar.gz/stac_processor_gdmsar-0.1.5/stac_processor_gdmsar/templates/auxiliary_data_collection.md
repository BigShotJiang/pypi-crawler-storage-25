# The auxiliary data collection from run {{processing.id}}

The **auxiliary data** contain product relative to LOS vectors, digital elevation models, lookup tables and temporal coherence.
