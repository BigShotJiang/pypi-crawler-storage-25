# Extra text files

This collection contains a set of supplementary data for the auxiliary data in radar geometry.
