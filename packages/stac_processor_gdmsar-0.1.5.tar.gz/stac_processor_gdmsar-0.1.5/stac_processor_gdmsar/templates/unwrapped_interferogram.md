# Unwrapped Interferogram

> The product corresponds to the **unwrapped interferogram**.
>
> The geotiff file has 2 bands:
>
> - band 1 is the filtered unwrapped phase of the interferogram. By default, the filter is a moving averaged, triangular sliding window applied on the wrapped phase (see Doin et al., 2015, for example). By default, unwrapping is done by the method described in Grandin et al., 2012.
> - band 2 is by default the coherence obtained when the sliding window average has been applied on the wrapped interferogram: it thus quantifies the quality of the filtered phase. It can also be the product of the two image’s amplitudes if other types of filters have been employed.
>
> The png file has 1 band:
>
> - band 1 is the unwrapped phase difference of the interferogram, normalized by a color palette

[source](https://formater.pages.in2p3.fr/flatsim/products/InU.html)
