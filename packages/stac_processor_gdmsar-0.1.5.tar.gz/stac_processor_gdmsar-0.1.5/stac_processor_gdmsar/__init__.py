import logging
from stac_processor_gdmsar.__about__ import (
    __version__,
    __catalog_name__,
    __catalog_desc__,
)
from stac_processor_gdmsar.discover import discover
from stac_processor_gdmsar.id import id
from stac_processor_gdmsar.version import version
from stac_processor_gdmsar.process import process

# define the logger here, so that it can be used in the other modules without having to redefine it
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
# logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
handler = logging.StreamHandler() # console handler
handler.setFormatter(formatter)
logger.addHandler(handler)
