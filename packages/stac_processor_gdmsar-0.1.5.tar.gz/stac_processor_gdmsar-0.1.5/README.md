# stac-processor-gdmsar

<p align="center">
  <img src="https://gdm.poleterresolide.fr/upload/services/service2_1.png" alt="GDM-SAR" style="vertical-align: middle; width: 100px; height: 100px;"/>
  <img src="https://stacspec.org/public/images-original/STAC-01.png" style="vertical-align: middle; max-width: 400px; max-height: 100px;" />
</p>

A STAC [processor](https://github.com/fntb/stac-repository/) for [GDM-SAR](https://www.isdeform.fr/services-2/) products.

## Overview

We use [`uv`](https://docs.astral.sh/uv/getting-started/installation/) to manage the venv, dependencies, PYTHONPATH, etc. You (shouldn't but) can do without it, just create a `.venv`, activate it, install the dependencies, and add the repo to your $PYTHONPATH when running any of the scripts.

Installing the dependencies from the `uv.lock` file

```bash
uv sync
```

## Usage

As a standalone CLI :

```bash
uv run stac_processor_gdmsar/app.py --help
```

## Installation

The processor can be installed with the following command:

```bash
uv pip install stac-processor-gdmsar
```

### Using `pystac-client` to Query the API

See [the ISDeform data center public documentation](https://gitlab.in2p3.fr/fntb/isdeform-doc-public).

### License

[OPEN LICENCE 2.0](./LICENCE.txt)
