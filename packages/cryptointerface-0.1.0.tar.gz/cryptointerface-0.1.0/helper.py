import requests
import polars as pl
from web3 import Web3
from cryptointerface.periphery.db import _init_tables, insert_data
from cryptointerface.periphery.enums import Network


def _find_coin_ids(symbol: str) -> list[dict]:
    """Return all CoinGecko coin entries matching the given symbol."""
    symbol = symbol.upper()
    coins = requests.get(
        "https://api.coingecko.com/api/v3/coins/list",
        params={"include_platform": "true"},
        timeout=15,
    ).json()
    return [c for c in coins if c.get("symbol", "").upper() == symbol]


def get_token_addresses(symbol: str) -> dict[str, str]:
    """
    Given a token symbol (e.g. "WETH"), return {network: address}
    for all networks known to CoinGecko.
    """
    addresses: dict[str, str] = {}
    for coin in _find_coin_ids(symbol):
        for network, address in coin.get("platforms", {}).items():
            if address:
                addresses[network] = address
    return addresses


def get_token_decimals(symbol: str) -> dict[str, int]:
    """
    Given a token symbol (e.g. "WETH"), return {network: decimals}
    for every network where CoinGecko reports a decimal_place value.
    """
    matches = _find_coin_ids(symbol)
    if not matches:
        return {}

    decimals: dict[str, int] = {}
    for coin in matches:
        detail = requests.get(
            f"https://api.coingecko.com/api/v3/coins/{coin['id']}",
            params={
                "localization": "false",
                "tickers": "false",
                "market_data": "false",
                "community_data": "false",
                "developer_data": "false",
            },
            timeout=15,
        ).json()
        for network, info in detail.get("detail_platforms", {}).items():
            dp = info.get("decimal_place")
            if dp is not None:
                decimals[network] = dp
    return decimals


def insert_token(symbol: str, chain_id: str, address: str, decimals: int = None):
    """
    Insert a single token into the tokens table.
    Example:
        insert_token("WETH", "1", "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", 18)
    """
    df = pl.DataFrame(
        {
            "symbol": [symbol.upper()],
            "chain_id": [chain_id],
            "address": [address.lower()],
            "decimals": [decimals],
        }
    )
    conn = _init_tables()
    insert_data(
        df,
        ["symbol", "chain_id", "address", "decimals"],
        "tokens",
        conn,
        pk_cols=["chain_id", "address"],
    )


def insert_tokens(tokens: list[dict]):
    """
    Insert multiple tokens from a list of dicts.
    Example:
        insert_tokens([
            {"symbol": "WETH", "chain_id": "1", "address": "0xC02a...", "decimals": 18},
            {"symbol": "USDC", "chain_id": "1", "address": "0xA0b8...", "decimals": 6},
        ])
    """
    df = pl.DataFrame(
        {
            "symbol": [t["symbol"].upper() for t in tokens],
            "chain_id": [t["chain_id"] for t in tokens],
            "address": [t["address"].lower() for t in tokens],
            "decimals": [t.get("decimals") for t in tokens],
        }
    )
    conn = _init_tables()
    insert_data(
        df,
        ["symbol", "chain_id", "address", "decimals"],
        "tokens",
        conn,
        pk_cols=["chain_id", "address"],
    )


def checksum_token_addresses():
    """
    Read all token addresses from the DB, convert to checksum format, and update in place.
    Skips any address that is already checksummed or cannot be converted.
    """
    conn = _init_tables()
    rows = conn.execute("SELECT chain_id, address FROM tokens").fetchall()

    updated = 0
    for chain_id, address in rows:
        try:
            checksummed = Web3.to_checksum_address(address)
        except Exception:
            continue
        if checksummed != address:
            conn.execute(
                "UPDATE tokens SET address = ? WHERE chain_id = ? AND address = ?",
                [checksummed, chain_id, address],
            )
            updated += 1

    print(f"Updated {updated} / {len(rows)} addresses to checksum format.")


if __name__ == "__main__":

    # data = get_token_decimals("WETH")
    insert_token(
        "WETH",
        Network.ARBITRUM.value,
        Web3.to_checksum_address("0x82af49447d8a07e3bd95bd0d56f35241523fbab1"),
        18,
    )
    # print(data)
