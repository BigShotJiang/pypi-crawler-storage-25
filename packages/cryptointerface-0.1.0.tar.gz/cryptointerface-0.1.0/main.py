from cryptointerface.token import Token
from cryptointerface.dex import Dex, create_dex_mapping
from cryptointerface.providers.infura import Infura
from cryptointerface.periphery.db import (
    drop_tables,
    export_pools_to_csv,
    export_tokens_to_csv,
    insert_data,
    _init_tables,
)
from cryptointerface.wallet import Wallet
from cryptointerface.periphery.utils import to_wei, from_wei
from cryptointerface.routes import arbitrage_route
from cryptointerface.periphery.enums import Network
import polars as pl
import os
from dotenv import load_dotenv

load_dotenv()


def get_key() -> str:
    key = os.getenv("INFURA_KEY")
    return key


def get_wallet() -> str:
    key = os.getenv("WALLET_KEY")
    return key


if __name__ == "__main__":

    # CHAIN_ID = "11155111"
    CHAIN_ID = Network.ARBITRUM.value
    key = get_key()
    # Provider
    infura = Infura(key)
    mapping = create_dex_mapping(
        ["uniswap_v2", "uniswap_v3", "sushiswap_v2", "sushiswap_v3"], CHAIN_ID, infura
    )
    token0 = Token("WETH", CHAIN_ID)
    token1 = Token("USDC", CHAIN_ID)
    data = arbitrage_route(
        mapping, token_0_address=token0.address, token_1_address=token1.address
    )
    print(data)
    # obj.batch_save(["DAI", "USDC", "USDT", "POL", "LINK"])
    # data = dex.get_pool_address(token_0_address, token_1_address, "uniswap_v2", "1")
    # print(data)
