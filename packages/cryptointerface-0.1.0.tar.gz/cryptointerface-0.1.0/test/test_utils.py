import pytest
from cryptointerface.periphery.utils import to_wei, from_wei


def test_to_wei_default_decimals():
    assert to_wei(1.0) == 10**18


def test_to_wei_usdc():
    assert to_wei(1.0, decimals=6) == 1_000_000


def test_to_wei_wbtc():
    assert to_wei(1.0, decimals=8) == 100_000_000


def test_from_wei_default_decimals():
    assert from_wei(10**18) == 1.0


def test_from_wei_usdc():
    assert from_wei(1_000_000, decimals=6) == 1.0


def test_to_wei_from_wei_roundtrip():
    amount = 123.456
    assert from_wei(to_wei(amount, decimals=18), decimals=18) == pytest.approx(amount)


def test_to_wei_fractional():
    # 0.5 ETH
    assert to_wei(0.5) == 5 * 10**17
