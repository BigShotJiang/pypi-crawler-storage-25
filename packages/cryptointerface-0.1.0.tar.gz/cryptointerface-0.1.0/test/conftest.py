import pytest
import os


def pytest_configure(config):
    config.addinivalue_line("markers", "network: mark test as requiring a live RPC connection")


@pytest.fixture
def sepolia_rpc_url():
    url = os.getenv("INFURA_KEY")
    if not url:
        pytest.skip("INFURA_KEY not set")
    from cryptointerface.providers.infura import Infura
    return Infura(url).get_url("11155111")


@pytest.fixture
def tmp_db(tmp_path):
    """Isolated in-memory-style DB for each test using a temp file."""
    from cryptointerface.periphery import db as db_module
    original_conn = db_module._conn
    db_module._conn = None  # force re-init against tmp path
    db_path = str(tmp_path / "test.db")
    conn = db_module._init_tables(db_path=db_path)
    yield conn
    db_module._conn = original_conn
