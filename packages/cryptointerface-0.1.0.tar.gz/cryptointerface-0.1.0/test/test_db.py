import polars as pl
import pytest
from cryptointerface.periphery.db import insert_data


def test_insert_and_read_token(tmp_db):
    df = pl.DataFrame({
        "symbol":   ["WETH"],
        "chain_id": ["11155111"],
        "address":  ["0xfff9976782d46cc05630d1f6ebab18b2324d6b14"],
        "decimals": [18],
    })
    insert_data(df, ["symbol", "chain_id", "address", "decimals"], "tokens", tmp_db, pk_cols=["chain_id", "address"])
    result = tmp_db.execute("SELECT * FROM tokens").pl()
    assert len(result) == 1
    assert result["symbol"][0] == "WETH"
    assert result["decimals"][0] == 18


def test_insert_token_deduplication(tmp_db):
    df = pl.DataFrame({
        "symbol":   ["WETH"],
        "chain_id": ["11155111"],
        "address":  ["0xfff9976782d46cc05630d1f6ebab18b2324d6b14"],
        "decimals": [18],
    })
    insert_data(df, ["symbol", "chain_id", "address", "decimals"], "tokens", tmp_db, pk_cols=["chain_id", "address"])
    insert_data(df, ["symbol", "chain_id", "address", "decimals"], "tokens", tmp_db, pk_cols=["chain_id", "address"])
    result = tmp_db.execute("SELECT * FROM tokens").pl()
    assert len(result) == 1


def test_insert_multiple_tokens(tmp_db):
    df = pl.DataFrame({
        "symbol":   ["WETH", "USDC"],
        "chain_id": ["11155111", "11155111"],
        "address":  [
            "0xfff9976782d46cc05630d1f6ebab18b2324d6b14",
            "0x1c7d4b196cb0c7b01d743fbc6116a902379c7238",
        ],
        "decimals": [18, 6],
    })
    insert_data(df, ["symbol", "chain_id", "address", "decimals"], "tokens", tmp_db, pk_cols=["chain_id", "address"])
    result = tmp_db.execute("SELECT * FROM tokens ORDER BY symbol").pl()
    assert len(result) == 2
    assert result["symbol"][0] == "USDC"
    assert result["decimals"][0] == 6


def test_insert_pool_v2(tmp_db):
    df = pl.DataFrame({
        "dex":     ["uniswap_v2"],
        "chain_id": [1],
        "token_0": ["0xaaa"],
        "token_1": ["0xbbb"],
        "address": ["0xpool"],
    })
    insert_data(df, ["dex", "chain_id", "token_0", "token_1", "address"], "pools_v2", tmp_db, pk_cols=["dex", "chain_id", "token_0", "token_1"])
    result = tmp_db.execute("SELECT * FROM pools_v2").pl()
    assert len(result) == 1
    assert result["address"][0] == "0xpool"


def test_insert_pool_v3(tmp_db):
    df = pl.DataFrame({
        "dex":     ["uniswap_v3"],
        "chain_id": [1],
        "token_0": ["0xaaa"],
        "token_1": ["0xbbb"],
        "fee":     [3000],
        "address": ["0xpool3"],
    })
    insert_data(df, ["dex", "chain_id", "token_0", "token_1", "fee", "address"], "pools_v3", tmp_db, pk_cols=["dex", "chain_id", "token_0", "token_1", "fee"])
    result = tmp_db.execute("SELECT * FROM pools_v3").pl()
    assert len(result) == 1
    assert result["fee"][0] == 3000


def test_insert_empty_df_is_noop(tmp_db):
    df = pl.DataFrame({"symbol": [], "chain_id": [], "address": [], "decimals": []})
    insert_data(df, ["symbol", "chain_id", "address", "decimals"], "tokens", tmp_db)
    result = tmp_db.execute("SELECT * FROM tokens").pl()
    assert len(result) == 0
