import pytest
from cryptointerface.dex import (
    _sort_tokens,
    _get_protocol,
    _get_fee_tiers,
    _resolve_pool_table,
)
from cryptointerface.periphery.dex_contracts import (
    get_dex_architecture,
    get_dex_contracts,
    get_supported_dexes,
)
from web3 import Web3

# ── Token sorting ────────────────────────────────────────────────────────────


def test_sort_tokens_lower_first():
    a = "0x0000000000000000000000000000000000000001"
    b = "0x0000000000000000000000000000000000000002"
    t0, t1 = _sort_tokens(a, b)
    assert int(t0, 16) < int(t1, 16)


def test_sort_tokens_already_sorted():
    a = "0x1000000000000000000000000000000000000000"
    b = "0x2000000000000000000000000000000000000000"
    t0, t1 = _sort_tokens(a, b)
    assert t0.lower() == a.lower()


def test_sort_tokens_reverse_input():
    a = "0x2000000000000000000000000000000000000000"
    b = "0x1000000000000000000000000000000000000000"
    t0, t1 = _sort_tokens(a, b)
    assert t0.lower() == b.lower()


# ── Protocol resolution ──────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "dex,expected",
    [
        ("uniswap_v2", "uniswap_v2"),
        ("uniswap_v3", "uniswap_v3"),
        ("sushiswap_v2", "uniswap_v2"),
        ("sushiswap_v3", "uniswap_v3"),
        ("pancakeswap_v2", "uniswap_v2"),
        ("pancakeswap_v3", "uniswap_v3"),
        ("quickswap_v3", "algebra_v3"),
        ("camelot_v3", "algebra_v3"),
        ("aerodrome", "solidly_v2"),
        ("velodrome", "solidly_v2"),
    ],
)
def test_get_protocol(dex, expected):
    assert _get_protocol(dex) == expected


def test_get_protocol_fallback_v3():
    assert _get_protocol("unknown_v3_dex") == "uniswap_v3"


def test_get_protocol_fallback_v2():
    assert _get_protocol("unknown_v2_dex") == "uniswap_v2"


# ── Fee tiers ────────────────────────────────────────────────────────────────


def test_fee_tiers_uniswap_v3():
    assert _get_fee_tiers("uniswap_v3") == [100, 500, 3000, 10000]


def test_fee_tiers_pancakeswap_v3():
    # PancakeSwap uses 2500 instead of 3000
    assert 2500 in _get_fee_tiers("pancakeswap_v3")
    assert 3000 not in _get_fee_tiers("pancakeswap_v3")


def test_fee_tiers_fallback():
    assert _get_fee_tiers("unknown_v3") == [500, 3000, 100, 10000]


# ── Pool table resolution ────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "dex,expected_table",
    [
        ("uniswap_v2", "pools_v2"),
        ("uniswap_v3", "pools_v3"),
        ("sushiswap_v2", "pools_v2"),
        ("sushiswap_v3", "pools_v3"),
        ("quickswap_v3", "pools_v3"),
        ("aerodrome", "pools_v2"),
        ("velodrome", "pools_v2"),
    ],
)
def test_resolve_pool_table(dex, expected_table):
    assert _resolve_pool_table(dex) == expected_table


# ── Contract registry ────────────────────────────────────────────────────────


def test_all_architecture_dexes_have_contracts():
    """Every DEX in dex_architecture.json should have at least one chain in dex_contracts.json."""
    from cryptointerface.periphery.dex_contracts import _load, _load_architecture

    arch = _load_architecture()
    contracts = _load()
    missing = [dex for dex in arch if dex not in contracts]
    assert missing == [], f"DEXes in architecture but missing from contracts: {missing}"


def test_uniswap_v3_sepolia_has_router():
    entry = get_dex_contracts("uniswap_v3", 11155111)
    assert entry is not None
    assert entry.get("router") is not None


def test_uniswap_v2_mainnet_has_factory_and_router():
    entry = get_dex_contracts("uniswap_v2", 1)
    assert entry["factory"] is not None
    assert entry["router"] is not None


# ── Network tests ────────────────────────────────────────────────────────────


@pytest.mark.network
def test_get_pool_address_v2(sepolia_rpc_url):
    from cryptointerface.dex import DexInterface

    iface = DexInterface(rpc_url=sepolia_rpc_url)
    weth = "0xfFf9976782d46CC05630D1f6eBAb18b2324d6B14"
    usdc = "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238"
    pool = iface.get_pool_address(weth, usdc, "uniswap_v2", 11155111)
    assert pool is None or pool.startswith("0x")


@pytest.mark.network
def test_get_pool_address_v3(sepolia_rpc_url):
    from cryptointerface.dex import DexInterface

    iface = DexInterface(rpc_url=sepolia_rpc_url)
    weth = "0xfFf9976782d46CC05630D1f6eBAb18b2324d6B14"
    usdc = "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238"
    pool = iface.get_pool_address(weth, usdc, "uniswap_v3", 11155111)
    assert pool is None or pool.startswith("0x")
