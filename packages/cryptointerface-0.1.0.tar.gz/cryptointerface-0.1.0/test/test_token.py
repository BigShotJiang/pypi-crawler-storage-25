import pytest
from unittest.mock import patch, MagicMock
import polars as pl


def _mock_token_df(symbol, chain_id, address, decimals):
    return pl.DataFrame(
        {
            "symbol": [symbol],
            "chain_id": [chain_id],
            "address": [address],
            "decimals": [decimals],
        }
    )


# ── TokenInterface (unit, no network) ────────────────────────────────────────


def test_token_address_lazy(tmp_db):
    from cryptointerface.token import Token

    with patch("cryptointerface.token.TokenInterface", return_value=tmp_db):
        token = Token("WETH", "11155111")
        assert token._address is None  # not yet resolved


def test_token_interface_read_from_db(tmp_db):
    from cryptointerface.periphery.db import insert_data
    from cryptointerface.token import TokenInterface

    df = _mock_token_df(
        "WETH", "11155111", "0xfff9976782d46cc05630d1f6ebab18b2324d6b14", 18
    )
    insert_data(
        df,
        ["symbol", "chain_id", "address", "decimals"],
        "tokens",
        tmp_db,
        pk_cols=["chain_id", "address"],
    )

    iface = TokenInterface()
    iface.conn = tmp_db
    result = iface._read_token_info("WETH", "11155111")
    assert not result.is_empty()
    assert result["address"][0] == "0xfff9976782d46cc05630d1f6ebab18b2324d6b14"


def test_token_interface_get_address_from_db(tmp_db):
    from cryptointerface.periphery.db import insert_data
    from cryptointerface.token import TokenInterface

    df = _mock_token_df(
        "USDC", "11155111", "0x1c7d4b196cb0c7b01d743fbc6116a902379c7238", 6
    )
    insert_data(
        df,
        ["symbol", "chain_id", "address", "decimals"],
        "tokens",
        tmp_db,
        pk_cols=["chain_id", "address"],
    )

    iface = TokenInterface()
    iface.conn = tmp_db
    address = iface.get_token_address("USDC", "11155111")
    assert address == "0x1c7d4b196cb0c7b01d743fbc6116a902379c7238"


def test_token_interface_get_decimals_from_db(tmp_db):
    from cryptointerface.periphery.db import insert_data
    from cryptointerface.token import TokenInterface

    df = _mock_token_df(
        "USDC", "11155111", "0x1c7d4b196cb0c7b01d743fbc6116a902379c7238", 6
    )
    insert_data(
        df,
        ["symbol", "chain_id", "address", "decimals"],
        "tokens",
        tmp_db,
        pk_cols=["chain_id", "address"],
    )

    iface = TokenInterface()
    iface.conn = tmp_db
    decimals = iface.get_token_decimals("USDC", "11155111")
    assert decimals == 6


# ── approve tx (unit, no network) ────────────────────────────────────────────


def test_approve_builds_tx(tmp_db):
    from cryptointerface.periphery.db import insert_data
    from cryptointerface.token import Token

    df = _mock_token_df(
        "WETH", "11155111", "0xfFf9976782d46CC05630D1f6eBAb18b2324d6B14", 18
    )
    insert_data(
        df,
        ["symbol", "chain_id", "address", "decimals"],
        "tokens",
        tmp_db,
        pk_cols=["chain_id", "address"],
    )

    mock_tx = {
        "to": "0xfFf9976782d46CC05630D1f6eBAb18b2324d6B14",
        "data": "0x095ea7b3...",
    }

    token = Token("WETH", "11155111")
    token._address = "0xfFf9976782d46CC05630D1f6eBAb18b2324d6B14"

    with patch("cryptointerface.token.Web3") as mock_w3_cls:
        mock_contract = MagicMock()
        mock_contract.functions.approve.return_value.build_transaction.return_value = (
            mock_tx
        )
        mock_w3_cls.return_value.eth.contract.return_value = mock_contract
        mock_w3_cls.to_checksum_address.side_effect = lambda x: x

        tx = token.approve(
            spender_address="0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45",
            amount=2**256 - 1,
            owner_address="0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF",
            rpc_url="http://localhost:8545",
        )
    assert tx == mock_tx


# ── Network tests ─────────────────────────────────────────────────────────────


@pytest.mark.network
def test_token_downloads_weth_info(sepolia_rpc_url):
    from cryptointerface.token import TokenInterface

    iface = TokenInterface()
    df = iface.get_token_info("WETH", "11155111")
    assert not df.is_empty()
    assert df["symbol"][0] == "WETH"
