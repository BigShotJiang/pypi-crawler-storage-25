from enum import Enum


class Network(Enum):
    ETHEREUM  = "1"
    OPTIMISM  = "10"
    BSC       = "56"
    POLYGON   = "137"
    BASE      = "8453"
    ARBITRUM  = "42161"
    CELO      = "42220"
    AVALANCHE = "43114"
    BLAST     = "81457"
    ZORA      = "7777777"
    SEPOLIA   = "11155111"


class Platform(Enum):
    UNISWAP_V2     = "uniswap_v2"
    UNISWAP_V3     = "uniswap_v3"
    SUSHISWAP_V2   = "sushiswap_v2"
    SUSHISWAP_V3   = "sushiswap_v3"
    PANCAKESWAP_V2 = "pancakeswap_v2"
    PANCAKESWAP_V3 = "pancakeswap_v3"
    QUICKSWAP_V2   = "quickswap_v2"
    QUICKSWAP_V3   = "quickswap_v3"
    CAMELOT_V2     = "camelot_v2"
    CAMELOT_V3     = "camelot_v3"
    TRADERJOE_V1   = "traderjoe_v1"
    AERODROME      = "aerodrome"
    VELODROME      = "velodrome"
