import threading
import duckdb
from .config import get_db_path

_db_path: str | None = None
_lock = threading.Lock()
_thread_local = threading.local()

_CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS tokens (
    symbol      VARCHAR NOT NULL,
    chain_id    VARCHAR NOT NULL,
    address     VARCHAR NOT NULL,
    decimals    INTEGER,
    PRIMARY KEY (chain_id, address)
);
CREATE TABLE IF NOT EXISTS pools_v2 (
    dex         VARCHAR NOT NULL,
    chain_id    INTEGER NOT NULL,
    token_0     VARCHAR NOT NULL,
    token_1     VARCHAR NOT NULL,
    address     VARCHAR NOT NULL,
    PRIMARY KEY (dex, chain_id, token_0, token_1)
);
CREATE TABLE IF NOT EXISTS pools_v3 (
    dex         VARCHAR NOT NULL,
    chain_id    INTEGER NOT NULL,
    token_0     VARCHAR NOT NULL,
    token_1     VARCHAR NOT NULL,
    fee         INTEGER NOT NULL,
    address     VARCHAR NOT NULL,
    PRIMARY KEY (dex, chain_id, token_0, token_1, fee)
);
"""


def _init_tables(db_path: str = None) -> duckdb.DuckDBPyConnection:
    global _db_path
    if db_path is not None:
        _db_path = db_path
    if _db_path is None:
        _db_path = str(get_db_path())

    if not hasattr(_thread_local, "conn"):
        _thread_local.conn = duckdb.connect(_db_path)
        for stmt in _CREATE_TABLES_SQL.strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                _thread_local.conn.execute(stmt)

    return _thread_local.conn


def insert_data(df, db_cols: list, table_name: str, conn, pk_cols: list = None):
    if df.is_empty():
        return
    final_cols = [c for c in db_cols if c in df.columns]
    df = df.select(final_cols)
    col_names = ", ".join(final_cols)

    with _lock:
        if pk_cols:
            pk_where = " AND ".join([f"existing.{c} = df.{c}" for c in pk_cols])
            conn.execute(
                f"""
                INSERT INTO {table_name} ({col_names})
                SELECT {col_names} FROM df
                WHERE NOT EXISTS (
                    SELECT 1 FROM {table_name} existing
                    WHERE {pk_where}
                )
            """
            )
        else:
            conn.execute(
                f"INSERT INTO {table_name} ({col_names}) SELECT {col_names} FROM df"
            )


def drop_tables(table_name: str):
    conn = _init_tables()
    conn.execute(f"DROP TABLE {table_name}")
    conn.commit()
    conn.close()


def export_tokens_to_csv(csv_path: str = "tokens.csv"):
    conn = _init_tables()
    conn.execute(f"COPY tokens TO '{csv_path}' (HEADER, DELIMITER ',')")


def export_pools_to_csv(v2_path: str = "pools_v2.csv", v3_path: str = "pools_v3.csv"):
    conn = _init_tables()
    conn.execute(f"COPY pools_v2 TO '{v2_path}' (HEADER, DELIMITER ',')")
    conn.execute(f"COPY pools_v3 TO '{v3_path}' (HEADER, DELIMITER ',')")


def insert_tokens_csv_to_db(csv_path: str = "tokens.csv"):
    conn = _init_tables()
    conn.execute(
        f"""
        INSERT INTO tokens (symbol, chain_id, address, decimals)
        SELECT symbol, chain_id, address, decimals FROM read_csv_auto('{csv_path}')
        WHERE NOT EXISTS (
            SELECT 1 FROM tokens existing
            WHERE existing.chain_id = chain_id AND existing.address = address
        )
        """
    )


def insert_pools_csv_to_db(v2_path: str = "pools_v2.csv", v3_path: str = "pools_v3.csv"):
    conn = _init_tables()
    conn.execute(
        f"""
        INSERT INTO pools_v2 (dex, chain_id, token_0, token_1, address)
        SELECT dex, chain_id, token_0, token_1, address FROM read_csv_auto('{v2_path}')
        WHERE NOT EXISTS (
            SELECT 1 FROM pools_v2 existing
            WHERE existing.dex = dex AND existing.chain_id = chain_id
              AND existing.token_0 = token_0 AND existing.token_1 = token_1
        )
        """
    )
    conn.execute(
        f"""
        INSERT INTO pools_v3 (dex, chain_id, token_0, token_1, fee, address)
        SELECT dex, chain_id, token_0, token_1, fee, address FROM read_csv_auto('{v3_path}')
        WHERE NOT EXISTS (
            SELECT 1 FROM pools_v3 existing
            WHERE existing.dex = dex AND existing.chain_id = chain_id
              AND existing.token_0 = token_0 AND existing.token_1 = token_1
              AND existing.fee = fee
        )
        """
    )
