def to_wei(amount_in: float, decimals: int = 18) -> int:
    return int(amount_in * 10**decimals)


def from_wei(amount_in_wei: int, decimals: int = 18) -> float:
    return amount_in_wei / 10**decimals
