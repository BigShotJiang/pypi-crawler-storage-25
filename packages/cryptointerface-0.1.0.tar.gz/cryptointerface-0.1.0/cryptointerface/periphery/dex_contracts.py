import json
from pathlib import Path

_JSON_PATH = Path(__file__).parent / "dex_contracts.json"
_ARCH_PATH = Path(__file__).parent / "dex_architecture.json"


def _load() -> dict:
    with open(_JSON_PATH, "r") as f:
        return json.load(f)


def _load_architecture() -> dict:
    with open(_ARCH_PATH, "r") as f:
        return json.load(f)


def get_dex_architecture(dex_name: str) -> dict | None:
    return _load_architecture().get(dex_name)


def _save(data: dict) -> None:
    with open(_JSON_PATH, "w") as f:
        json.dump(data, f, indent=4)


def get_dex_contracts(dex: str, chain_id: int) -> dict[str, str] | None:
    """Return the contract addresses for a given DEX and chain ID, or None if unsupported."""
    return _load().get(dex, {}).get(str(chain_id))


def get_supported_dexes() -> list[str]:
    return list(_load().keys())


def get_supported_chains(dex: str) -> list[int]:
    return [int(k) for k in _load().get(dex, {}).keys()]


def add_dex_entry(dex: str, chain_id: int, contracts: dict[str, str | None]) -> None:
    """
    Add or update a chain entry for a DEX. Changes are written to dex_contracts.json.

    Example:
        add_dex_entry("sushiswap_v3", 1, {
            "factory":          "0xbACEB8eC6b9355Dfc0269C18bac9d6E2Bdc29C4F",
            "router":           "0x...",
            "quoter":           "0x...",
            "position_manager": "0x...",
        })
    """
    data = _load()
    if dex not in data:
        data[dex] = {}
    data[dex][str(chain_id)] = contracts
    _save(data)
