import json
from pathlib import Path

PARENT = Path(__file__).parent
ENDPOINTS = PARENT / Path("endpoints.json")


class Infura:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def get_url(self, chain_id: str) -> str:
        return self._build_url(chain_id)

    def _load_endpoints(self) -> dict:
        with open(ENDPOINTS, "r") as file:
            data = json.load(file)
        return data

    def add_endpoint(self, chain_id: int | str, endpoint: str) -> None:
        data = self._load_endpoints()
        data["infura"][str(chain_id)] = endpoint
        with open(ENDPOINTS, "w") as file:
            json.dump(data, file, indent=4)

    def view_endpoints(self) -> list:
        data = self._load_endpoints()
        return data["infura"]

    def _build_url(self, chain_id: str):
        chain_id = str(chain_id)
        data = self._load_endpoints()
        try:
            return data["infura"][chain_id] + self.api_key
        except KeyError:
            return None
