import requests
import polars as pl
from web3 import Web3
from .periphery.db import _init_tables, insert_data
from .periphery.mapping import COINGECKO_CHAIN_IDS

_ERC20_APPROVE_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "spender", "type": "address"},
            {"internalType": "uint256", "name": "amount", "type": "uint256"},
        ],
        "name": "approve",
        "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
        "stateMutability": "nonpayable",
        "type": "function",
    }
]

_ERC20_ALLOWANCE_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "owner", "type": "address"},
            {"internalType": "address", "name": "spender", "type": "address"},
        ],
        "name": "allowance",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    }
]


class Token:
    def __init__(self, symbol: str, chain_id: str):
        self.symbol = symbol
        self.chain_id = chain_id
        self.interface = TokenInterface()

        self._address = None
        self._decimals = None
        self._info = None

    @property
    def address(self):
        if self._address is None:
            self._address = self.interface.get_token_address(self.symbol, self.chain_id)
        return self._address

    @property
    def decimals(self) -> int:
        if self._decimals is None:
            self._decimals = self.interface.get_token_decimals(
                self.symbol, self.chain_id
            )
        return self._decimals

    @property
    def info(self):
        if self._info is None:
            self._info = self.interface.get_token_info(self.symbol, self.chain_id)
        return self._info

    def approve(
        self, spender_address: str, amount: int, owner_address: str, rpc_url: str
    ) -> dict:
        """
        Build an unsigned ERC-20 approve transaction.
        amount is in raw token units — use to_wei() to scale beforehand.
        Pass 2**256 - 1 as amount for an unlimited approval.
        """
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        contract = w3.eth.contract(
            address=Web3.to_checksum_address(self.address),
            abi=_ERC20_APPROVE_ABI,
        )
        owner_cs = Web3.to_checksum_address(owner_address)
        return contract.functions.approve(
            Web3.to_checksum_address(spender_address), amount
        ).build_transaction({"from": owner_cs})

    def check_allowance(
        self, owner_address: str, spender_address: str, rpc_url: str
    ) -> int:
        """
        Return the current ERC-20 allowance (in raw token units) that
        `spender_address` is approved to spend on behalf of `owner_address`.
        """
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        contract = w3.eth.contract(
            address=Web3.to_checksum_address(self.address),
            abi=_ERC20_ALLOWANCE_ABI,
        )
        return contract.functions.allowance(
            Web3.to_checksum_address(owner_address),
            Web3.to_checksum_address(spender_address),
        ).call()


class TokenInterface:
    def __init__(self):
        self.table_name = "tokens"

    @property
    def conn(self):
        return _init_tables()

    def get_token_info(self, symbol: str, chain_id: str) -> pl.DataFrame:
        symbol = symbol.upper()
        chain_id = str(chain_id)
        gen = self._read_token_info(symbol)
        print(f"GEN: {gen}")
        df = self._read_token_info(symbol, chain_id)
        print(f"DF: {df}")
        if not df.is_empty():
            return df

        # Cache miss — download all chains and persist them.
        downloaded = self._download_token_info(symbol)
        if not downloaded.is_empty():
            self._insert_token_info(downloaded)

        # Re-read so we only return the requested chain.
        df = self._read_token_info(symbol, chain_id)
        return df

    def get_token_address(self, symbol: str, chain_id: str):
        df = self.get_token_info(symbol=symbol, chain_id=chain_id)
        return df["address"][0]

    def get_token_decimals(self, symbol: str, chain_id: str):
        df = self.get_token_info(symbol=symbol, chain_id=chain_id)
        return df["decimals"][0]

    def batch_save(self, symbols: list):
        if isinstance(symbols, str):
            symbols = [symbols]

        coin_ids = _find_coin_ids()

        for s in symbols:
            try:
                df = self._download_token_info(s, coin_ids=coin_ids)
                self._insert_token_info(df)
            except Exception as e:
                break
            except KeyboardInterrupt:
                break

    def _download_token_info(self, symbol: str, coin_ids: list = None) -> dict:
        if coin_ids is None:
            coin_ids = _find_coin_ids(symbol=symbol)
        else:
            coin_ids = _match_coin_ids(coins=coin_ids, symbol=symbol)
        addresses = _fetch_token_addresses(symbol, coin_ids=coin_ids)
        decimals_map = _fetch_token_decimals(symbol, coin_ids=coin_ids)
        decimals = next(iter(decimals_map.values())) if decimals_map else None

        data = {
            "chain_id": [],
            "address": [],
        }
        for k, v in addresses.items():
            cid = COINGECKO_CHAIN_IDS.get(k, None)
            data["chain_id"].append(str(cid) if cid is not None else None)
            try:
                address = Web3.to_checksum_address(v)
            except ValueError:
                address = v
            data["address"].append(address)

        df = pl.DataFrame(data)
        df = df.filter(pl.col("chain_id").is_not_null())
        df = df.with_columns(
            pl.lit(symbol).alias("symbol"), pl.lit(decimals).alias("decimals")
        )
        df = df[["symbol", "chain_id", "address", "decimals"]]
        return df

    def update_decimals(self, symbol: str, decimals: int) -> None:
        self.conn.execute(
            "UPDATE tokens SET decimals = ? WHERE symbol = ?",
            [decimals, symbol],
        )

    def _insert_token_info(self, df: pl.DataFrame):
        insert_data(
            df,
            db_cols=["symbol", "chain_id", "address", "decimals"],
            table_name=self.table_name,
            conn=self.conn,
            pk_cols=["chain_id", "address"],
        )

    def _read_token_info(self, symbol: str, chain_id: str = None) -> pl.DataFrame:
        if chain_id:
            query = f"SELECT * FROM {self.table_name} WHERE symbol = '{symbol}' AND chain_id = '{chain_id}'"
        else:
            query = f"SELECT * FROM {self.table_name} WHERE symbol = '{symbol}'"
        return self.conn.execute(query).pl()


def _find_coin_ids(symbol: str = None) -> list[dict]:
    """Return all CoinGecko coin entries matching the given symbol."""
    coins = requests.get(
        "https://api.coingecko.com/api/v3/coins/list",
        params={"include_platform": "true"},
        timeout=15,
    ).json()
    if symbol:
        return [c for c in coins if c.get("symbol", "").upper() == symbol]
    else:
        return coins


def _match_coin_ids(coins: list, symbol: str):
    return [c for c in coins if c.get("symbol", "").upper() == symbol]


def _fetch_token_addresses(symbol: str, coin_ids: list = None) -> dict[str, str]:
    """
    Given a token symbol (e.g. "WETH"), return {network: address}
    for all networks known to CoinGecko.
    """
    addresses: dict[str, str] = {}
    if coin_ids is None:
        coin_ids = _find_coin_ids(symbol)
    for coin in coin_ids:
        for network, address in coin.get("platforms", {}).items():
            if address:
                addresses[network] = address
    return addresses


def _fetch_token_decimals(symbol: str, coin_ids: list = None) -> dict[str, int]:
    """
    Given a token symbol (e.g. "WETH"), return {network: decimals}
    for every network where CoinGecko reports a decimal_place value.
    """
    if coin_ids is None:
        matches = _find_coin_ids(symbol)
    else:
        matches = coin_ids
    if not matches:
        return {}

    decimals: dict[str, int] = {}
    for coin in matches:
        detail = requests.get(
            f"https://api.coingecko.com/api/v3/coins/{coin['id']}",
            params={
                "localization": "false",
                "tickers": "false",
                "market_data": "false",
                "community_data": "false",
                "developer_data": "false",
            },
            timeout=15,
        ).json()
        for network, info in detail.get("detail_platforms", {}).items():
            dp = info.get("decimal_place")
            if dp is not None:
                decimals[network] = dp
    return decimals
