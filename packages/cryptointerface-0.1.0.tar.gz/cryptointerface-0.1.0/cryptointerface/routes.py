from concurrent.futures import ThreadPoolExecutor, as_completed
from .dex import Dex
from .periphery.dex_contracts import get_dex_architecture


def _get_swap_fee_bps(dex_name: str, pool_fee_tier: int | None) -> int:
    """
    Return the swap fee in basis points for a given DEX.
    For V3 DEXes the fee is per-pool (stored in pools_v3.fee), so pool_fee_tier is used.
    For V2 DEXes the fee is fixed and comes from dex_architecture.json.
    Returns 0 if unknown.
    """
    arch = get_dex_architecture(dex_name)
    if arch is None:
        return 0
    if pool_fee_tier is not None:
        # V3-style: fee tier is already in basis points (e.g. 500 = 0.05%, 3000 = 0.3%)
        return pool_fee_tier // 100
    return arch.get("swap_fee_bps") or 0


def get_prices(
    dex_mapping: dict[str, Dex], token_0_address: str, token_1_address: str
) -> dict[str, dict]:
    """
    Fetch prices and pool addresses for a token pair across all DEXes in parallel.
    Returns {dex_name: {"price": float | None, "pool": str | None, "fee_bps": int}}.
    """
    def _fetch(dex_name: str, dex: Dex) -> tuple[str, dict]:
        pool  = dex.pool_address(token_0_address, token_1_address)
        price = dex.get_price(token_0_address, token_1_address) if pool else None

        # Retrieve cached fee tier for V3 pools (stored as 0 for algebra, actual tier for uniswap_v3)
        fee_tier = None
        if pool and dex.interface:
            from .dex import _sort_tokens
            t0, t1 = _sort_tokens(token_0_address, token_1_address)
            cached = dex.interface.read_pool_v3(dex.name, dex.chain_id, t0, t1)
            if not cached.is_empty():
                fee_tier = int(cached["fee"][0])

        fee_bps = _get_swap_fee_bps(dex_name, fee_tier)
        return dex_name, {"price": price, "pool": pool, "fee_bps": fee_bps}

    results = {}
    with ThreadPoolExecutor() as executor:
        futures = {
            executor.submit(_fetch, name, dex): name
            for name, dex in dex_mapping.items()
        }
        for future in as_completed(futures):
            dex_name, data = future.result()
            results[dex_name] = data

    return results


def arbitrage_route(
    dex_mapping: dict[str, Dex], token_0_address: str, token_1_address: str
):
    results = get_prices(dex_mapping, token_0_address, token_1_address)
    available = {k: v for k, v in results.items() if v["price"] is not None}

    if len(available) < 2:
        return None

    buy_dex  = min(available, key=lambda k: available[k]["price"])
    sell_dex = max(available, key=lambda k: available[k]["price"])

    buy_price  = available[buy_dex]["price"]
    sell_price = available[sell_dex]["price"]

    spread_abs = sell_price - buy_price
    spread_pct = (spread_abs / buy_price) * 100

    # Cost to buy on buy_dex then sell on sell_dex (both legs as % of trade)
    total_fee_pct = (available[buy_dex]["fee_bps"] + available[sell_dex]["fee_bps"]) / 100
    net_spread_pct = spread_pct - total_fee_pct
    is_profitable = net_spread_pct > 0

    return {
        "buy":             {"dex": buy_dex,  "price": buy_price,  "pool": available[buy_dex]["pool"],  "fee_bps": available[buy_dex]["fee_bps"]},
        "sell":            {"dex": sell_dex, "price": sell_price, "pool": available[sell_dex]["pool"], "fee_bps": available[sell_dex]["fee_bps"]},
        "spread_abs":      round(spread_abs, 6),
        "spread_pct":      round(spread_pct, 4),
        "total_fee_pct":   round(total_fee_pct, 4),
        "net_spread_pct":  round(net_spread_pct, 4),
        "profitable":      is_profitable,
        "all_prices":      results,
    }
