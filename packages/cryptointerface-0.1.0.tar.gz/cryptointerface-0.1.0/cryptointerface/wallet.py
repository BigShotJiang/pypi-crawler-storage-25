from web3 import Web3


class Wallet:
    def __init__(self, private_key: str, rpc_url: str):
        self.w3 = Web3(Web3.HTTPProvider(rpc_url))
        self.account = self.w3.eth.account.from_key(private_key)
        self.address = self.account.address

    def sign_and_send(self, tx: dict) -> str:
        """
        Fill in nonce and gas if missing, sign the transaction, broadcast it,
        and return the transaction hash as a hex string.
        """
        if "nonce" not in tx:
            tx["nonce"] = self.w3.eth.get_transaction_count(self.address)
        if "gas" not in tx:
            tx["gas"] = self.w3.eth.estimate_gas({**tx, "from": self.address})
        if "gasPrice" not in tx and "maxFeePerGas" not in tx:
            tx["gasPrice"] = self.w3.eth.gas_price

        signed = self.account.sign_transaction(tx)
        tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
        return tx_hash.hex()

    def wait(self, tx_hash: str, timeout: int = 120) -> dict:
        """Block until the transaction is mined and return the receipt."""
        return self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
