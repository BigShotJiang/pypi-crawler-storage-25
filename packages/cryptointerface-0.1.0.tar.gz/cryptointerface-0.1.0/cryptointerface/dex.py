from web3 import Web3
from .providers.infura import Infura
from .periphery.dex_contracts import get_dex_contracts, _load, get_dex_architecture
from .periphery.db import _init_tables, insert_data
import polars as pl

# Minimal ABIs — only the functions needed for pool/pair lookups.
_V2_FACTORY_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "tokenA", "type": "address"},
            {"internalType": "address", "name": "tokenB", "type": "address"},
        ],
        "name": "getPair",
        "outputs": [{"internalType": "address", "name": "pair", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    }
]

_V3_FACTORY_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "tokenA", "type": "address"},
            {"internalType": "address", "name": "tokenB", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
        ],
        "name": "getPool",
        "outputs": [{"internalType": "address", "name": "pool", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    }
]

_ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"

_V2_PAIR_ABI = [
    {
        "inputs": [],
        "name": "getReserves",
        "outputs": [
            {"internalType": "uint112", "name": "reserve0", "type": "uint112"},
            {"internalType": "uint112", "name": "reserve1", "type": "uint112"},
            {"internalType": "uint32", "name": "blockTimestampLast", "type": "uint32"},
        ],
        "stateMutability": "view",
        "type": "function",
    }
]

_V2_ROUTER_ABI = [
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
            {"internalType": "address[]", "name": "path", "type": "address[]"},
            {"internalType": "address", "name": "to", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
        ],
        "name": "swapExactTokensForTokens",
        "outputs": [
            {"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}
        ],
        "stateMutability": "nonpayable",
        "type": "function",
    }
]

_V3_ROUTER_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "address", "name": "tokenIn", "type": "address"},
                    {"internalType": "address", "name": "tokenOut", "type": "address"},
                    {"internalType": "uint24", "name": "fee", "type": "uint24"},
                    {"internalType": "address", "name": "recipient", "type": "address"},
                    {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                    {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
                    {
                        "internalType": "uint256",
                        "name": "amountOutMinimum",
                        "type": "uint256",
                    },
                    {
                        "internalType": "uint160",
                        "name": "sqrtPriceLimitX96",
                        "type": "uint160",
                    },
                ],
                "internalType": "struct ISwapRouter.ExactInputSingleParams",
                "name": "params",
                "type": "tuple",
            }
        ],
        "name": "exactInputSingle",
        "outputs": [
            {"internalType": "uint256", "name": "amountOut", "type": "uint256"}
        ],
        "stateMutability": "payable",
        "type": "function",
    }
]

_ALGEBRA_FACTORY_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "tokenA", "type": "address"},
            {"internalType": "address", "name": "tokenB", "type": "address"},
        ],
        "name": "poolByPair",
        "outputs": [{"internalType": "address", "name": "pool", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    }
]

_ALGEBRA_ROUTER_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "address", "name": "tokenIn", "type": "address"},
                    {"internalType": "address", "name": "tokenOut", "type": "address"},
                    {"internalType": "address", "name": "recipient", "type": "address"},
                    {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                    {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
                    {
                        "internalType": "uint256",
                        "name": "amountOutMinimum",
                        "type": "uint256",
                    },
                    {
                        "internalType": "uint160",
                        "name": "limitSqrtPrice",
                        "type": "uint160",
                    },
                ],
                "internalType": "struct ISwapRouter.ExactInputSingleParams",
                "name": "params",
                "type": "tuple",
            }
        ],
        "name": "exactInputSingle",
        "outputs": [
            {"internalType": "uint256", "name": "amountOut", "type": "uint256"}
        ],
        "stateMutability": "payable",
        "type": "function",
    }
]

_SOLIDLY_FACTORY_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "tokenA", "type": "address"},
            {"internalType": "address", "name": "tokenB", "type": "address"},
            {"internalType": "bool", "name": "stable", "type": "bool"},
        ],
        "name": "getPool",
        "outputs": [{"internalType": "address", "name": "pool", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    }
]

_SOLIDLY_ROUTER_ABI = [
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
            {
                "components": [
                    {"internalType": "address", "name": "from", "type": "address"},
                    {"internalType": "address", "name": "to", "type": "address"},
                    {"internalType": "bool", "name": "stable", "type": "bool"},
                ],
                "internalType": "struct IRouter.route[]",
                "name": "routes",
                "type": "tuple[]",
            },
            {"internalType": "address", "name": "to", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
        ],
        "name": "swapExactTokensForTokens",
        "outputs": [
            {"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}
        ],
        "stateMutability": "nonpayable",
        "type": "function",
    }
]

_V3_POOL_ABI = [
    {
        "inputs": [],
        "name": "slot0",
        "outputs": [
            {"internalType": "uint160", "name": "sqrtPriceX96", "type": "uint160"},
            {"internalType": "int24", "name": "tick", "type": "int24"},
            {"internalType": "uint16", "name": "observationIndex", "type": "uint16"},
            {
                "internalType": "uint16",
                "name": "observationCardinality",
                "type": "uint16",
            },
            {
                "internalType": "uint16",
                "name": "observationCardinalityNext",
                "type": "uint16",
            },
            {"internalType": "uint8", "name": "feeProtocol", "type": "uint8"},
            {"internalType": "bool", "name": "unlocked", "type": "bool"},
        ],
        "stateMutability": "view",
        "type": "function",
    }
]


def _get_protocol(dex_name: str) -> str:
    """Return the protocol string from dex_architecture.json, falling back to name-based inference."""
    arch = get_dex_architecture(dex_name)
    if arch:
        return arch["protocol"]
    # Fallback for DEXes not yet in dex_architecture.json
    if "v3" in dex_name.lower():
        return "uniswap_v3"
    return "uniswap_v2"


def _get_fee_tiers(dex_name: str) -> list[int]:
    """Return the fee tiers for a DEX, falling back to standard Uniswap V3 tiers."""
    arch = get_dex_architecture(dex_name)
    if arch and arch.get("fee_tiers"):
        return arch["fee_tiers"]
    return [500, 3000, 100, 10000]


def _sort_tokens(token_a: str, token_b: str) -> tuple[str, str]:
    """
    Return (token0, token1) in canonical Uniswap order (lower address first).
    Both inputs are normalised to checksum addresses before comparison.
    """
    a = Web3.to_checksum_address(token_a)
    b = Web3.to_checksum_address(token_b)
    return (a, b) if int(a, 16) < int(b, 16) else (b, a)


def _resolve_pool_table(dex_name: str) -> str:
    """Return the pool table name for a given DEX based on its architecture version."""
    arch = get_dex_architecture(dex_name)
    if arch:
        return "pools_v3" if arch["version"] == 3 else "pools_v2"
    if "v3" in dex_name.lower():
        return "pools_v3"
    if "v2" in dex_name.lower():
        return "pools_v2"
    raise ValueError(
        f"Cannot resolve pool table for '{dex_name}': not found in dex_architecture.json."
    )


def create_dex_mapping(dex_names: list[str], chain_ids: list[str], infura_obj) -> dict:
    if isinstance(dex_names, str):
        dex_names = [dex_names]
    if isinstance(chain_ids, str):
        chain_ids = [chain_ids]
    mapping = {}
    for d in dex_names:
        for _id in chain_ids:
            mapping[d] = Dex(d, _id, infura_obj.get_url(_id))
    return mapping


class Dex:
    def __init__(self, dex_name: str, chain_id: str, rpc_url: str = None):
        self.name = dex_name
        self.chain_id = chain_id
        self.rpc_url = rpc_url
        self.interface = DexInterface(rpc_url=rpc_url)
        self._factory = None
        self._router = None

    @property
    def factory(self):
        if self._factory is None:
            self._factory = self.interface.get_factory(self.name, self.chain_id)
        return self._factory

    @property
    def router(self):
        if self._router is None:
            self._router = self.interface.get_router(self.name, self.chain_id)
        return self._router

    def pool_address(
        self, token_a_address: str, token_b_address: str, fee_tier: str = None
    ):
        address = self.interface.get_pool_address(
            token_a=token_a_address,
            token_b=token_b_address,
            dex_name=self.name,
            chain_id=self.chain_id,
            fee=fee_tier,
        )
        return address

    def get_price(
        self, token_a_address: str, token_b_address: str, fee_tier: int = None
    ):
        price = self.interface.get_price(
            token_a_address,
            token_b_address,
            dex_name=self.name,
            chain_id=self.chain_id,
            fee=fee_tier,
        )
        return price


class DexInterface:
    def __init__(self, rpc_url: str, debug: bool = True):
        self.w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 10}))
        self.dex_contracts = None
        self.debug = debug

    @property
    def conn(self):
        return _init_tables()

    def set_dex_contracts(self):
        self.dex_contracts = _load()

    def get_dex_contracts(self):
        if self.dex_contracts is None:
            self.set_dex_contracts()
        return self.dex_contracts

    def get_router(self, dex_name: str, chain_id: str):
        data = self.get_dex_contracts()
        return self._get(
            dex_name=dex_name, chain_id=chain_id, data=data, contract_type="router"
        )

    def get_factory(self, dex_name: str, chain_id: str):
        data = self.get_dex_contracts()
        return self._get(
            dex_name=dex_name, chain_id=chain_id, data=data, contract_type="factory"
        )

    def get_pool_address(
        self,
        token_a: str,
        token_b: str,
        dex_name: str,
        chain_id: int,
        fee: int = None,
    ) -> str | None:
        token_0, token_1 = _sort_tokens(token_a, token_b)
        token_0 = Web3.to_checksum_address(token_0)
        token_1 = Web3.to_checksum_address(token_1)
        is_v3 = _get_protocol(dex_name) in ("uniswap_v3", "algebra_v3")
        if is_v3:
            cached = self.read_pool_v3(dex_name, chain_id, token_0, token_1, fee)
            if not cached.is_empty():
                return cached["address"][0]
            result = self._fetch_pool_address(
                token_0, token_1, dex_name, str(chain_id), fee
            )
            if result is not None:
                address, matched_fee = result
                self.insert_pool_v3(
                    dex_name, chain_id, token_0, token_1, matched_fee, address
                )
                return address
        else:
            cached = self.read_pool_v2(dex_name, chain_id, token_0, token_1)
            if not cached.is_empty():
                return cached["address"][0]
            result = self._fetch_pool_address(token_0, token_1, dex_name, str(chain_id))
            if result is not None:
                address, _ = result
                self.insert_pool_v2(dex_name, chain_id, token_0, token_1, address)
                return address

        return None

    def _fetch_pool_address(
        self,
        token_0: str,
        token_1: str,
        dex_name: str,
        chain_id: str,
        fee: int = None,
    ) -> tuple[str, int | None] | None:
        """
        Fetch pool address from chain. Returns (address, fee) on success, None if not found.
        Tokens must already be sorted before calling this method.
        fee is unused for algebra_v3 and solidly_v2 (stored as 0).
        """
        if self.debug:
            print(f"Fetching pool address from: {dex_name}")
        factory_address = self.get_factory(dex_name, chain_id)
        if factory_address is None:
            return None

        token_0 = Web3.to_checksum_address(token_0)
        token_1 = Web3.to_checksum_address(token_1)
        factory = Web3.to_checksum_address(factory_address)
        protocol = _get_protocol(dex_name)

        try:
            if protocol == "uniswap_v3":
                contract = self.w3.eth.contract(address=factory, abi=_V3_FACTORY_ABI)
                fee_tiers = [fee] if fee is not None else _get_fee_tiers(dex_name)
                for tier in fee_tiers:
                    pool = contract.functions.getPool(token_0, token_1, tier).call()
                    if pool != _ZERO_ADDRESS:
                        if self.debug:
                            print(f"Found pool at fee tier {tier}: {pool}")
                        return pool, tier
                if self.debug:
                    print(f"No pool found for {token_0}/{token_1} on {dex_name} (chain {chain_id})")
                return None

            elif protocol == "algebra_v3":
                contract = self.w3.eth.contract(address=factory, abi=_ALGEBRA_FACTORY_ABI)
                pool = contract.functions.poolByPair(token_0, token_1).call()
                if pool == _ZERO_ADDRESS:
                    if self.debug:
                        print(f"No pool found for {token_0}/{token_1} on {dex_name} (chain {chain_id})")
                    return None
                if self.debug:
                    print(f"Found Algebra pool: {pool}")
                return pool, 0

            elif protocol == "solidly_v2":
                contract = self.w3.eth.contract(address=factory, abi=_SOLIDLY_FACTORY_ABI)
                for stable in (False, True):
                    pool = contract.functions.getPool(token_0, token_1, stable).call()
                    if pool != _ZERO_ADDRESS:
                        if self.debug:
                            print(f"Found Solidly pool (stable={stable}): {pool}")
                        return pool, None
                if self.debug:
                    print(f"No pool found for {token_0}/{token_1} on {dex_name} (chain {chain_id})")
                return None

            else:  # uniswap_v2
                contract = self.w3.eth.contract(address=factory, abi=_V2_FACTORY_ABI)
                pair = contract.functions.getPair(token_0, token_1).call()
                if pair == _ZERO_ADDRESS:
                    if self.debug:
                        print(f"No pair found for {token_0}/{token_1} on {dex_name} (chain {chain_id})")
                    return None
                return pair, None

        except Exception as e:
            if self.debug:
                print(f"Contract call failed for {dex_name} (chain {chain_id}): {e}")
            return None

    ################## Insert ##################
    def insert_pool_v2(
        self, dex: str, chain_id: int, token_0: str, token_1: str, address: str
    ) -> None:
        df = pl.DataFrame(
            {
                "dex": [dex],
                "chain_id": [chain_id],
                "token_0": [token_0],
                "token_1": [token_1],
                "address": [address],
            }
        )
        insert_data(
            df,
            db_cols=["dex", "chain_id", "token_0", "token_1", "address"],
            table_name="pools_v2",
            conn=self.conn,
            pk_cols=["dex", "chain_id", "token_0", "token_1"],
        )

    def insert_pool_v3(
        self,
        dex: str,
        chain_id: int,
        token_0: str,
        token_1: str,
        fee: int,
        address: str,
    ) -> None:
        df = pl.DataFrame(
            {
                "dex": [dex],
                "chain_id": [chain_id],
                "token_0": [token_0],
                "token_1": [token_1],
                "fee": [fee],
                "address": [address],
            }
        )
        insert_data(
            df,
            db_cols=["dex", "chain_id", "token_0", "token_1", "fee", "address"],
            table_name="pools_v3",
            conn=self.conn,
            pk_cols=["dex", "chain_id", "token_0", "token_1", "fee"],
        )

    ################## Read ##################
    def read_pool_v2(
        self, dex: str, chain_id: int, token_0: str, token_1: str
    ) -> pl.DataFrame:
        query = """
            SELECT * FROM pools_v2
            WHERE dex = ? AND chain_id = ? AND token_0 = ? AND token_1 = ?
        """
        return self.conn.execute(query, [dex, chain_id, token_0, token_1]).pl()

    def read_pool_v3(
        self, dex: str, chain_id: int, token_0: str, token_1: str, fee: int = None
    ) -> pl.DataFrame:
        if fee is not None:
            query = """
                SELECT * FROM pools_v3
                WHERE dex = ? AND chain_id = ? AND token_0 = ? AND token_1 = ? AND fee = ?
            """
            return self.conn.execute(query, [dex, chain_id, token_0, token_1, fee]).pl()
        else:
            query = """
                SELECT * FROM pools_v3
                WHERE dex = ? AND chain_id = ? AND token_0 = ? AND token_1 = ?
            """
            return self.conn.execute(query, [dex, chain_id, token_0, token_1]).pl()

    ################## Prices ##################
    def get_price(
        self,
        token_a: str,
        token_b: str,
        dex_name: str,
        chain_id: int,
        fee: int = None,
    ) -> float | None:
        """
        Return the price of token_a denominated in token_b.
        (i.e. how much token_b you receive for 1 token_a)
        """
        token_0, token_1 = _sort_tokens(token_a, token_b)
        pool_address = self.get_pool_address(token_0, token_1, dex_name, chain_id, fee)
        if pool_address is None:
            return None

        decimals_0 = self._get_token_decimals(token_0, str(chain_id))
        decimals_1 = self._get_token_decimals(token_1, str(chain_id))

        protocol = _get_protocol(dex_name)
        if protocol in ("uniswap_v3", "algebra_v3"):
            price = self._get_v3_price(pool_address, decimals_0, decimals_1)
        else:
            price = self._get_v2_price(pool_address, decimals_0, decimals_1)

        if price is None:
            return None

        # If the caller passed tokens in reverse order, invert the price.
        token_a_cs = Web3.to_checksum_address(token_a)
        if token_a_cs != token_0:
            return 1 / price
        return price

    def _get_v2_price(
        self, pool_address: str, decimals_0: int, decimals_1: int
    ) -> float | None:
        """
        Derive price from V2 pair reserves.
        Returns price of token0 in terms of token1.
        """
        contract = self.w3.eth.contract(
            address=Web3.to_checksum_address(pool_address),
            abi=_V2_PAIR_ABI,
        )
        reserve0, reserve1, _ = contract.functions.getReserves().call()
        if reserve0 == 0:
            return None
        return (reserve1 / 10**decimals_1) / (reserve0 / 10**decimals_0)

    def _get_v3_price(
        self, pool_address: str, decimals_0: int, decimals_1: int
    ) -> float | None:
        """
        Derive price from V3 pool sqrtPriceX96.
        Returns price of token0 in terms of token1.
        """
        contract = self.w3.eth.contract(
            address=Web3.to_checksum_address(pool_address),
            abi=_V3_POOL_ABI,
        )
        sqrt_price_x96 = contract.functions.slot0().call()[0]
        if sqrt_price_x96 == 0:
            return None
        price = (sqrt_price_x96 / (2**96)) ** 2
        return price * (10**decimals_0 / 10**decimals_1)

    def _get_token_decimals(self, address: str, chain_id: str) -> int:
        """Look up token decimals from the tokens table. Defaults to 18 if not found."""
        result = self.conn.execute(
            "SELECT decimals FROM tokens WHERE LOWER(address) = ? AND chain_id = ?",
            [address.lower(), chain_id],
        ).fetchone()
        if result and result[0] is not None:
            return result[0]
        if self.debug:
            print(
                f"Decimals not found for {address} on chain {chain_id}, defaulting to 18"
            )
        return 18

    ################## Swaps ##################
    def swap(
        self,
        token_in: str,
        token_out: str,
        amount_in: int,
        dex_name: str,
        chain_id: int,
        sender: str,
        fee: int = None,
        amount_out_min: int = 0,
        deadline: int = None,
    ) -> dict | None:
        """
        Build a swap transaction for token_in -> token_out.
        Returns an unsigned transaction dict ready for signing, or None if the pool is not found.
        amount_in is in raw token units (i.e. already scaled by decimals).
        """
        if deadline is None:
            import time

            deadline = int(time.time()) + 300

        token_in_cs = Web3.to_checksum_address(token_in)
        token_out_cs = Web3.to_checksum_address(token_out)

        protocol = _get_protocol(dex_name)

        if protocol == "uniswap_v3":
            pool_address = self.get_pool_address(
                token_in_cs, token_out_cs, dex_name, chain_id, fee
            )
            if pool_address is None:
                return None
            token_0, token_1 = _sort_tokens(token_in_cs, token_out_cs)
            cached = self.read_pool_v3(dex_name, chain_id, token_0, token_1, fee)
            resolved_fee = (
                fee
                if fee is not None
                else (cached["fee"][0] if not cached.is_empty() else None)
            )
            if resolved_fee is None:
                return None
            return self._swap_v3(
                token_in_cs,
                token_out_cs,
                amount_in,
                dex_name,
                str(chain_id),
                sender,
                resolved_fee,
                amount_out_min,
                deadline,
            )

        elif protocol == "algebra_v3":
            pool_address = self.get_pool_address(
                token_in_cs, token_out_cs, dex_name, chain_id
            )
            if pool_address is None:
                return None
            return self._swap_algebra(
                token_in_cs,
                token_out_cs,
                amount_in,
                dex_name,
                str(chain_id),
                sender,
                amount_out_min,
                deadline,
            )

        elif protocol == "solidly_v2":
            pool_address = self.get_pool_address(
                token_in_cs, token_out_cs, dex_name, chain_id
            )
            if pool_address is None:
                return None
            return self._swap_solidly(
                token_in_cs,
                token_out_cs,
                amount_in,
                dex_name,
                str(chain_id),
                sender,
                amount_out_min,
                deadline,
            )

        else:  # uniswap_v2
            pool_address = self.get_pool_address(
                token_in_cs, token_out_cs, dex_name, chain_id
            )
            if pool_address is None:
                return None
            return self._swap_v2(
                token_in_cs,
                token_out_cs,
                amount_in,
                dex_name,
                str(chain_id),
                sender,
                amount_out_min,
                deadline,
            )

    def _swap_v2(
        self,
        token_in: str,
        token_out: str,
        amount_in: int,
        dex_name: str,
        chain_id: str,
        sender: str,
        amount_out_min: int,
        deadline: int,
    ) -> dict | None:
        """Build an unsigned V2 swapExactTokensForTokens transaction."""
        router_address = self.get_router(dex_name, chain_id)
        if router_address is None:
            return None
        router = self.w3.eth.contract(
            address=Web3.to_checksum_address(router_address),
            abi=_V2_ROUTER_ABI,
        )
        sender_cs = Web3.to_checksum_address(sender)
        tx = router.functions.swapExactTokensForTokens(
            amount_in,
            amount_out_min,
            [token_in, token_out],
            sender_cs,
            deadline,
        ).build_transaction({"from": sender_cs})
        return tx

    def _swap_v3(
        self,
        token_in: str,
        token_out: str,
        amount_in: int,
        dex_name: str,
        chain_id: str,
        sender: str,
        fee: int,
        amount_out_min: int,
        deadline: int,
    ) -> dict | None:
        """Build an unsigned V3 exactInputSingle transaction."""
        router_address = self.get_router(dex_name, chain_id)
        if router_address is None:
            return None
        router = self.w3.eth.contract(
            address=Web3.to_checksum_address(router_address),
            abi=_V3_ROUTER_ABI,
        )
        sender_cs = Web3.to_checksum_address(sender)
        tx = router.functions.exactInputSingle(
            {
                "tokenIn": token_in,
                "tokenOut": token_out,
                "fee": fee,
                "recipient": sender_cs,
                "deadline": deadline,
                "amountIn": amount_in,
                "amountOutMinimum": amount_out_min,
                "sqrtPriceLimitX96": 0,
            }
        ).build_transaction({"from": sender_cs})
        return tx

    def _swap_algebra(
        self,
        token_in: str,
        token_out: str,
        amount_in: int,
        dex_name: str,
        chain_id: str,
        sender: str,
        amount_out_min: int,
        deadline: int,
    ) -> dict | None:
        """Build an unsigned Algebra V3 exactInputSingle transaction (no fee field)."""
        router_address = self.get_router(dex_name, chain_id)
        if router_address is None:
            return None
        router = self.w3.eth.contract(
            address=Web3.to_checksum_address(router_address),
            abi=_ALGEBRA_ROUTER_ABI,
        )
        sender_cs = Web3.to_checksum_address(sender)
        tx = router.functions.exactInputSingle(
            {
                "tokenIn": token_in,
                "tokenOut": token_out,
                "recipient": sender_cs,
                "deadline": deadline,
                "amountIn": amount_in,
                "amountOutMinimum": amount_out_min,
                "limitSqrtPrice": 0,
            }
        ).build_transaction({"from": sender_cs})
        return tx

    def _swap_solidly(
        self,
        token_in: str,
        token_out: str,
        amount_in: int,
        dex_name: str,
        chain_id: str,
        sender: str,
        amount_out_min: int,
        deadline: int,
    ) -> dict | None:
        """
        Build an unsigned Solidly swapExactTokensForTokens transaction.
        Tries volatile route first; if no pool exists falls back to stable.
        """
        router_address = self.get_router(dex_name, chain_id)
        if router_address is None:
            return None
        factory_address = self.get_factory(dex_name, chain_id)
        factory = self.w3.eth.contract(
            address=Web3.to_checksum_address(factory_address),
            abi=_SOLIDLY_FACTORY_ABI,
        )
        # Determine whether the existing pool is stable or volatile.
        stable = False
        if (
            factory.functions.getPool(token_in, token_out, False).call()
            == _ZERO_ADDRESS
        ):
            stable = True

        router = self.w3.eth.contract(
            address=Web3.to_checksum_address(router_address),
            abi=_SOLIDLY_ROUTER_ABI,
        )
        sender_cs = Web3.to_checksum_address(sender)
        tx = router.functions.swapExactTokensForTokens(
            amount_in,
            amount_out_min,
            [{"from": token_in, "to": token_out, "stable": stable}],
            sender_cs,
            deadline,
        ).build_transaction({"from": sender_cs})
        return tx

    def _get(
        self, dex_name: str, chain_id: str, data: dict, contract_type: str
    ) -> str | None:
        dex_data = data.get(dex_name)
        if dex_data is None:
            if self.debug:
                print(f"Couldn't find dex: {dex_name}...")
            return None

        chain_data = dex_data.get(chain_id)
        if chain_data is None:
            if self.debug:
                print(
                    f"Couldn't find chain_id: {chain_id}. Available: {list(dex_data.keys())}"
                )
            return None

        contract_address = chain_data.get(contract_type)
        if contract_address is None and self.debug:
            print(
                f"Couldn't find contract type: {contract_type}. Available: {list(chain_data.keys())}"
            )

        return contract_address
