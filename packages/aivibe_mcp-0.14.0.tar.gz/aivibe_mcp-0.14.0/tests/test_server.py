"""Tests for the MCP server tool definitions."""

import json
from unittest.mock import patch

from aivibe_mcp.server import (
    add_org_apps,
    add_team_manager,
    add_team_member,
    add_user_to_org,
    check_recos_freshness,
    check_role_template_deploy_conflicts,
    clear_active_org,
    create_team,
    create_user,
    deploy_role_template_to_teams,
    get_active_org,
    get_doc,
    get_org_map_summary,
    get_organization,
    get_survey,
    get_survey_results_detail,
    get_survey_summary,
    get_team,
    get_team_members,
    get_team_roles,
    get_team_summary,
    get_team_task_entries,
    get_team_work_areas,
    get_top_tasks,
    get_user_by_email,
    list_docs,
    list_open_responses,
    list_org_apps,
    list_organizations,
    list_surveys,
    list_teams,
    remove_team_manager,
    remove_team_member,
    remove_team_member_by_id,
    resolve_catalog_app_ids,
    search_catalog_apps,
    set_active_org,
    update_team,
    update_team_member,
    update_team_member_by_id,
    update_user,
)

MOCK_RESPONSE = json.dumps([{"id": 1, "name": "Test"}], indent=2)
TEAM_UUID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


class TestTools:
    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_organizations(self, mock_get) -> None:
        result = list_organizations()
        mock_get.assert_called_once_with("/api/platform/orgs")
        assert "Test" in result

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_organization(self, mock_get) -> None:
        get_organization(1)
        mock_get.assert_called_once_with("/api/platform/orgs/1")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_surveys_no_filter(self, mock_get) -> None:
        list_surveys()
        mock_get.assert_called_once_with("/api/survey/records", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_surveys_with_org(self, mock_get) -> None:
        list_surveys(org_id=5)
        mock_get.assert_called_once_with("/api/survey/records", params={"organization_id": 5})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey(self, mock_get) -> None:
        get_survey("abc-123")
        mock_get.assert_called_once_with("/api/survey/records/abc-123")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_summary(self, mock_get) -> None:
        get_survey_summary("abc-123")
        mock_get.assert_called_once_with("/api/survey/reporting/summary/abc-123", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_summary_with_org(self, mock_get) -> None:
        get_survey_summary("abc-123", org_id=5)
        mock_get.assert_called_once_with(
            "/api/survey/reporting/summary/abc-123", params={"organization_ids": "5"}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_results_detail_no_org(self, mock_get) -> None:
        get_survey_results_detail("abc-123")
        mock_get.assert_called_once_with("/api/survey/reporting/analytics/abc-123", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_results_detail_with_org(self, mock_get) -> None:
        get_survey_results_detail("abc-123", org_id=5)
        mock_get.assert_called_once_with(
            "/api/survey/reporting/analytics/abc-123", params={"organization_ids": "5"}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_no_filter(self, mock_get) -> None:
        list_teams()
        mock_get.assert_called_once_with("/api/map/teams", params={"page": 1, "page_size": 50})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_with_org(self, mock_get) -> None:
        list_teams(org_id=3)
        mock_get.assert_called_once_with(
            "/api/map/teams", params={"page": 1, "page_size": 50, "organization_id": 3}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_with_pagination(self, mock_get) -> None:
        list_teams(page=2, page_size=10)
        mock_get.assert_called_once_with("/api/map/teams", params={"page": 2, "page_size": 10})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team(self, mock_get) -> None:
        get_team(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_members(self, mock_get) -> None:
        get_team_members(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/members")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_roles(self, mock_get) -> None:
        get_team_roles(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/roles")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_work_areas(self, mock_get) -> None:
        get_team_work_areas(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/work-areas")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_task_entries(self, mock_get) -> None:
        get_team_task_entries(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/task-entries")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_open_responses_no_filter(self, mock_get) -> None:
        list_open_responses()
        mock_get.assert_called_once_with("/api/map/open-responses", params={"limit": 500})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_open_responses_team_id(self, mock_get) -> None:
        list_open_responses(team_id=TEAM_UUID)
        mock_get.assert_called_once_with(
            "/api/map/open-responses",
            params={"limit": 500, "team_id": TEAM_UUID},
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_open_responses_org_id(self, mock_get) -> None:
        list_open_responses(org_id=42)
        mock_get.assert_called_once_with(
            "/api/map/open-responses",
            params={"limit": 500, "organization_id": 42},
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_open_responses_team_id_overrides_org_id(self, mock_get) -> None:
        list_open_responses(team_id=TEAM_UUID, org_id=42)
        # team_id wins; organization_id must NOT appear in params
        mock_get.assert_called_once_with(
            "/api/map/open-responses",
            params={"limit": 500, "team_id": TEAM_UUID},
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_open_responses_custom_limit(self, mock_get) -> None:
        list_open_responses(limit=100)
        mock_get.assert_called_once_with("/api/map/open-responses", params={"limit": 100})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_summary(self, mock_get) -> None:
        get_team_summary(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/reports/teams/{TEAM_UUID}/summary")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_org_map_summary(self, mock_get) -> None:
        get_org_map_summary(1)
        mock_get.assert_called_once_with("/api/map/reports/organizations/1/summary")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_top_tasks(self, mock_get) -> None:
        get_top_tasks(org_id=1)
        mock_get.assert_called_once_with("/api/map/reports/top-tasks", params={"org_ids": "1"})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_top_tasks_no_filter(self, mock_get) -> None:
        get_top_tasks()
        mock_get.assert_called_once_with("/api/map/reports/top-tasks", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_search_catalog_apps(self, mock_get) -> None:
        search_catalog_apps("slack")
        mock_get.assert_called_once_with("/api/map/catalog-apps/search", params={"q": "slack"})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_search_catalog_apps_with_org(self, mock_get) -> None:
        search_catalog_apps("slack", org_id=42)
        mock_get.assert_called_once_with(
            "/api/map/catalog-apps/search", params={"q": "slack", "organization_id": 42}
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_resolve_catalog_app_ids(self, mock_post) -> None:
        resolve_catalog_app_ids(["uuid1", "uuid2"])
        mock_post.assert_called_once_with(
            "/api/map/catalog-apps/by-ids", body={"ids": ["uuid1", "uuid2"]}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_org_apps(self, mock_get) -> None:
        list_org_apps(org_id=7)
        mock_get.assert_called_once_with(
            "/api/map/catalog-apps/by-org",
            params={"organization_id": 7, "limit": 200},
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_org_apps_custom_limit(self, mock_get) -> None:
        list_org_apps(org_id=7, limit=50)
        mock_get.assert_called_once_with(
            "/api/map/catalog-apps/by-org",
            params={"organization_id": 7, "limit": 50},
        )

    def test_add_org_apps_buckets_responses(self) -> None:
        """`add_org_apps` buckets each row by `was_created` + `is_org_private`."""
        responses = [
            # New private (just created)
            json.dumps({"id": "u1", "name": "AcmeBot", "is_org_private": True, "was_created": True}),
            # Public match (reused, not created)
            json.dumps(
                {"id": "u2", "name": "Salesforce", "is_org_private": False, "was_created": False}
            ),
            # Existing private (reused, not created)
            json.dumps(
                {"id": "u3", "name": "AcmeCRM", "is_org_private": True, "was_created": False}
            ),
        ]
        with patch("aivibe_mcp.server.api_post", side_effect=responses):
            result_str = add_org_apps(org_id=42, names=["AcmeBot", "Salesforce", "AcmeCRM"])

        result = json.loads(result_str)
        assert {row["name"] for row in result["created"]} == {"AcmeBot"}
        assert {row["name"] for row in result["existed_public"]} == {"Salesforce"}
        assert {row["name"] for row in result["existed_private"]} == {"AcmeCRM"}
        assert result["failed"] == []

    def test_add_org_apps_skips_empty_names(self) -> None:
        with patch("aivibe_mcp.server.api_post") as mock_post:
            result_str = add_org_apps(org_id=1, names=["  ", ""])
        mock_post.assert_not_called()
        result = json.loads(result_str)
        assert result["created"] == []
        assert len(result["failed"]) == 2

    def test_add_org_apps_records_failure(self) -> None:
        with patch("aivibe_mcp.server.api_post", side_effect=RuntimeError("boom")):
            result_str = add_org_apps(org_id=1, names=["AcmeBot"])
        result = json.loads(result_str)
        assert result["created"] == []
        assert result["failed"] == [{"name": "AcmeBot", "error": "boom"}]

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_check_recos_freshness(self, mock_get) -> None:
        check_recos_freshness()
        mock_get.assert_called_once_with("/api/recommend/freshness")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_docs(self, mock_get) -> None:
        list_docs()
        mock_get.assert_called_once_with("/api/platform/docs/manifest")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_doc(self, mock_get) -> None:
        get_doc("guides/ai-vibe-method")
        mock_get.assert_called_once_with("/api/platform/docs/pages/guides/ai-vibe-method")


# ── Cowork org-chart ingestion (#454) ───────────────────────────────────────


class TestCoworkOrgChartTools:
    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_create_team_minimum_args(self, mock_post) -> None:
        create_team(org_id=1, name="Solar US")
        mock_post.assert_called_once_with(
            "/api/map/teams",
            body={"organization_id": 1, "name": "Solar US", "is_workflow": False},
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_create_team_with_optional_fields(self, mock_post) -> None:
        create_team(
            org_id=2,
            name="Wind EU",
            description="Wind dev team",
            region="EU",
            division="Wind",
            team_type="engineering",
            is_workflow=True,
        )
        mock_post.assert_called_once_with(
            "/api/map/teams",
            body={
                "organization_id": 2,
                "name": "Wind EU",
                "is_workflow": True,
                "description": "Wind dev team",
                "region": "EU",
                "division": "Wind",
                "team_type": "engineering",
            },
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_team_partial_omits_unset_fields(self, mock_patch) -> None:
        update_team(team_id=TEAM_UUID, name="Renamed")
        mock_patch.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}", body={"name": "Renamed"}
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_team_soft_delete_via_is_active(self, mock_patch) -> None:
        update_team(team_id=TEAM_UUID, is_active=False)
        mock_patch.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}", body={"is_active": False}
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_add_team_manager_uses_by_email_endpoint(self, mock_post) -> None:
        add_team_manager(team_id=TEAM_UUID, user_email="alice@example.com")
        mock_post.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/managers/by-email",
            body={"user_email": "alice@example.com"},
        )

    @patch("aivibe_mcp.server.api_delete", return_value=MOCK_RESPONSE)
    def test_remove_team_manager_uses_by_email_endpoint(self, mock_delete) -> None:
        remove_team_manager(team_id=TEAM_UUID, user_email="alice@example.com")
        mock_delete.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/managers/by-email/alice@example.com"
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_add_team_member_passes_email_and_name(self, mock_post) -> None:
        add_team_member(team_id=TEAM_UUID, email="bob@example.com", name="Bob")
        mock_post.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-mcp",
            body={"email": "bob@example.com", "name": "Bob"},
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_add_team_member_with_user_title(self, mock_post) -> None:
        """Job titles from org charts flow through `user_title`."""
        add_team_member(
            team_id=TEAM_UUID,
            email="bara@example.com",
            name="Bara Jacobsma",
            user_title="Director, Development",
        )
        mock_post.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-mcp",
            body={
                "email": "bara@example.com",
                "name": "Bara Jacobsma",
                "user_title": "Director, Development",
            },
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_team_member_partial_email_only(self, mock_patch) -> None:
        update_team_member(
            team_id=TEAM_UUID,
            current_email="bob@example.com",
            new_email="bob+real@example.com",
        )
        mock_patch.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-email/bob@example.com",
            body={"new_email": "bob+real@example.com"},
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_team_member_partial_name_only(self, mock_patch) -> None:
        update_team_member(
            team_id=TEAM_UUID,
            current_email="bob@example.com",
            new_name="Robert",
        )
        mock_patch.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-email/bob@example.com",
            body={"new_name": "Robert"},
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_team_member_user_title_only(self, mock_patch) -> None:
        update_team_member(
            team_id=TEAM_UUID,
            current_email="bara@example.com",
            new_user_title="VP, Solar Engineering",
        )
        mock_patch.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-email/bara@example.com",
            body={"new_user_title": "VP, Solar Engineering"},
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_team_member_clear_user_title_with_empty_string(self, mock_patch) -> None:
        """Empty string clears the title; None means leave it alone."""
        update_team_member(
            team_id=TEAM_UUID,
            current_email="bara@example.com",
            new_user_title="",
        )
        mock_patch.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-email/bara@example.com",
            body={"new_user_title": ""},
        )

    @patch("aivibe_mcp.server.api_delete", return_value=MOCK_RESPONSE)
    def test_remove_team_member(self, mock_delete) -> None:
        remove_team_member(team_id=TEAM_UUID, email="bob@example.com")
        mock_delete.assert_called_once_with(
            f"/api/map/teams/{TEAM_UUID}/members/by-email/bob@example.com"
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_user_by_email(self, mock_get) -> None:
        get_user_by_email(email="alice@example.com")
        mock_get.assert_called_once_with("/api/platform/users/by-email/alice@example.com")

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_create_user_without_email_omits_email_field(self, mock_post) -> None:
        create_user(name="Bara Jacobsma")
        mock_post.assert_called_once_with(
            "/api/platform/users/by-mcp", body={"name": "Bara Jacobsma"}
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_create_user_with_email_includes_field(self, mock_post) -> None:
        create_user(name="Real User", email="real@example.com")
        mock_post.assert_called_once_with(
            "/api/platform/users/by-mcp",
            body={"name": "Real User", "email": "real@example.com"},
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_user_email_only(self, mock_patch) -> None:
        update_user(user_id=42, email="new@example.com")
        mock_patch.assert_called_once_with(
            "/api/platform/users/by-mcp/42", body={"email": "new@example.com"}
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_user_name_only(self, mock_patch) -> None:
        update_user(user_id=42, name="Renamed")
        mock_patch.assert_called_once_with(
            "/api/platform/users/by-mcp/42", body={"name": "Renamed"}
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_add_user_to_org_default_role(self, mock_post) -> None:
        """Default role is org_viewer (the narrowest valid role for any org)."""
        add_user_to_org(user_email="alice@example.com", organization_id=42)
        mock_post.assert_called_once_with(
            "/api/platform/users/grant-org-access",
            body={
                "user_email": "alice@example.com",
                "organization_id": 42,
                "org_role": "org_viewer",
            },
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_add_user_to_org_with_explicit_role(self, mock_post) -> None:
        add_user_to_org(
            user_email="bob@example.com",
            organization_id=99,
            org_role="org_admin",
        )
        mock_post.assert_called_once_with(
            "/api/platform/users/grant-org-access",
            body={
                "user_email": "bob@example.com",
                "organization_id": 99,
                "org_role": "org_admin",
            },
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_set_active_org_passes_org_id(self, mock_post) -> None:
        set_active_org(org_id=42)
        mock_post.assert_called_once_with(
            "/api/platform/api-keys/active-org", body={"org_id": 42}
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_clear_active_org_passes_null(self, mock_post) -> None:
        clear_active_org()
        mock_post.assert_called_once_with(
            "/api/platform/api-keys/active-org", body={"org_id": None}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_active_org(self, mock_get) -> None:
        get_active_org()
        mock_get.assert_called_once_with("/api/platform/api-keys/active-org")


TEMPLATE_UUID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


class TestRoleTemplateDeployTools:
    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_deploy_default_on_conflict_skip(self, mock_post) -> None:
        deploy_role_template_to_teams(
            template_id=TEMPLATE_UUID,
            team_ids=[TEAM_UUID],
        )
        mock_post.assert_called_once_with(
            f"/api/map/library-templates/{TEMPLATE_UUID}/deploy",
            body={"team_ids": [TEAM_UUID], "on_conflict": "skip"},
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_deploy_replace_on_conflict_passes_through(self, mock_post) -> None:
        deploy_role_template_to_teams(
            template_id=TEMPLATE_UUID,
            team_ids=[TEAM_UUID, TEAM_UUID],
            on_conflict="replace",
        )
        mock_post.assert_called_once_with(
            f"/api/map/library-templates/{TEMPLATE_UUID}/deploy",
            body={"team_ids": [TEAM_UUID, TEAM_UUID], "on_conflict": "replace"},
        )

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_check_conflicts_posts_team_ids(self, mock_post) -> None:
        check_role_template_deploy_conflicts(
            template_id=TEMPLATE_UUID,
            team_ids=[TEAM_UUID],
        )
        mock_post.assert_called_once_with(
            f"/api/map/library-templates/{TEMPLATE_UUID}/check-conflicts",
            body={"team_ids": [TEAM_UUID]},
        )


MEMBER_UUID = "e6f7c8a9-1b2c-3d4e-5f6a-7b8c9d0e1f2a"


class TestMemberByIdTools:
    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_by_id_partial_omits_unset_fields(self, mock_patch) -> None:
        update_team_member_by_id(member_id=MEMBER_UUID, new_user_title="Director")
        mock_patch.assert_called_once_with(
            f"/api/map/members/{MEMBER_UUID}/by-mcp",
            body={"new_user_title": "Director"},
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_by_id_clears_user_title_with_empty_string(self, mock_patch) -> None:
        update_team_member_by_id(member_id=MEMBER_UUID, new_user_title="")
        mock_patch.assert_called_once_with(
            f"/api/map/members/{MEMBER_UUID}/by-mcp",
            body={"new_user_title": ""},
        )

    @patch("aivibe_mcp.server.api_patch", return_value=MOCK_RESPONSE)
    def test_update_by_id_passes_all_fields(self, mock_patch) -> None:
        update_team_member_by_id(
            member_id=MEMBER_UUID,
            new_email="alice.real@example.com",
            new_name="Alice W.",
            new_user_title="Senior Engineer",
        )
        mock_patch.assert_called_once_with(
            f"/api/map/members/{MEMBER_UUID}/by-mcp",
            body={
                "new_email": "alice.real@example.com",
                "new_name": "Alice W.",
                "new_user_title": "Senior Engineer",
            },
        )

    @patch("aivibe_mcp.server.api_delete", return_value=MOCK_RESPONSE)
    def test_remove_by_id_calls_correct_endpoint(self, mock_delete) -> None:
        remove_team_member_by_id(member_id=MEMBER_UUID)
        mock_delete.assert_called_once_with(f"/api/map/members/{MEMBER_UUID}/by-mcp")
