"""AIVibe MCP server — platform data access (read + draft_write + catalog_write + team_write + user_write + org_membership_write) for Claude Desktop and Cowork."""

__version__ = "0.14.0"
