"""AIVibe MCP server — read-only tools for querying platform data."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from aivibe_mcp.client import api_delete, api_get, api_patch, api_post

mcp = FastMCP("aivibe")

# ── IMPORTANT DATA MODEL NOTE ───────────────────────────────────────────────
# The platform has two independent data modules:
#
# 1. DIAGNOSE (surveys) — responses are ANONYMOUS. There is no link between
#    a survey response and a specific person or team member. You cannot
#    cross-reference survey answers with task map entries at the individual
#    or team level. This is by design for respondent privacy.
#
# 2. MAP (task maps) — task entries are ATTRIBUTED to named team members.
#    Each task entry has a member_id and member_name.
#
# Cross-referencing between modules is only possible at the ORGANIZATION
# level (e.g., "org X has 50 survey responses AND 7 mapped teams").
# Never attempt to correlate individual survey answers with specific
# team members — the data model does not support it.
# ─────────────────────────────────────────────────────────────────────────────


# ── Organizations ────────────────────────────────────────────────────────────


@mcp.tool()
def list_organizations() -> str:
    """List all accessible organizations. Names are anonymized (shown as org codes)."""
    return api_get("/api/platform/orgs")


@mcp.tool()
def get_organization(org_id: int) -> str:
    """Get organization details by ID."""
    return api_get(f"/api/platform/orgs/{org_id}")


# ── Surveys (Diagnose module) ───────────────────────────────────────────────


@mcp.tool()
def list_surveys(org_id: int | None = None) -> str:
    """List surveys, optionally filtered by organization ID."""
    params = {"organization_id": org_id} if org_id is not None else None
    return api_get("/api/survey/records", params=params)


@mcp.tool()
def get_survey(survey_id: str) -> str:
    """Get survey details by ID."""
    return api_get(f"/api/survey/records/{survey_id}")


@mcp.tool()
def get_survey_summary(
    survey_id: str, org_id: int | None = None, template_id: str | None = None
) -> str:
    """Get a lightweight survey analytics summary (~5-10K instead of 300K). Returns: total responses, completed/in-progress counts, and per-question score distributions (option counts and percentages). Does NOT include raw responses or free-text answers. Use this first — only use get_survey_results_full if you need the complete payload. IMPORTANT: Survey responses are ANONYMOUS — there is no link between a survey response and a specific person or team member. You CANNOT cross-reference survey answers with task map entries at the individual or team level. Cross-module analysis is only possible at the organization level."""
    params: dict[str, str] = {}
    if org_id is not None:
        params["organization_ids"] = str(org_id)
    if template_id is not None:
        params["template_id"] = template_id
    return api_get(f"/api/survey/reporting/summary/{survey_id}", params=params or None)


@mcp.tool()
def get_survey_results_detail(survey_id: str, org_id: int | None = None) -> str:
    """Get detailed survey analytics with per-question breakdowns. Can be large — ALWAYS pass org_id to filter to a single organization (much smaller response). Without org_id, the response may exceed context limits (300K+). Prefer get_survey_summary first for counts and distributions; use this only when you need the full question-level detail for a specific org."""
    params: dict[str, str] = {}
    if org_id is not None:
        params["organization_ids"] = str(org_id)
    return api_get(f"/api/survey/reporting/analytics/{survey_id}", params=params or None)


# ── Teams (Map module) ──────────────────────────────────────────────────────


@mcp.tool()
def list_teams(org_id: int | None = None, page: int = 1, page_size: int = 50) -> str:
    """List teams, optionally filtered by organization ID. Returns a PAGINATED response: {items: [...], total, page, page_size}. Each item has: id (UUID), name, organization_id, organization_name, member_count, total_task_entries, fully_assessed_tasks, managers, region, division, team_type."""
    params: dict[str, str | int] = {"page": page, "page_size": page_size}
    if org_id is not None:
        params["organization_id"] = org_id
    return api_get("/api/map/teams", params=params)


@mcp.tool()
def get_team(team_id: str) -> str:
    """Get team details by ID. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}")


@mcp.tool()
def get_team_members(team_id: str) -> str:
    """List members of a team. team_id is a UUID string.

    Names and emails are returned unmasked when the API key carries the
    `team_write` scope — callers reconciling a roster need ground truth to
    detect renames and stale emails before issuing follow-up writes.
    Read-only keys still see soft-masked PII (``First L.`` /
    ``user{N}@masked.demo``).
    """
    return api_get(f"/api/map/teams/{team_id}/members")


@mcp.tool()
def get_team_roles(team_id: str) -> str:
    """List roles defined for a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/roles")


@mcp.tool()
def get_team_work_areas(team_id: str) -> str:
    """List work areas for a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/work-areas")


@mcp.tool()
def get_team_task_entries(team_id: str) -> str:
    """List all task entries (task map data) for a team. Each entry represents a task performed by a NAMED team member (unlike survey responses which are anonymous). Key fields: id (entry UUID), label (task name), frequency (time proportion — values: 'Nearly none of my time', 'Little of my time', 'Some of my time', 'A lot of my time', 'Most of my time', or null if not assessed), enjoyment (values: 'High', 'Medium', 'Low', or null if not assessed), automation_type (current automation level — values: '0', '25', '50', '75', '100', or null if not assessed — this is NOT automation potential, it is how automated the task IS TODAY), app_ids (UUIDs of tools used — resolve via resolve_catalog_app_ids), work_area_id, work_area_label, member_id, member_name. NOTE: Task map data is attributed to individuals. Survey (Diagnose) data is anonymous. Do NOT cross-reference individual survey answers with task map members. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/task-entries")


@mcp.tool()
def list_open_responses(
    team_id: str | None = None,
    org_id: int | None = None,
    limit: int = 500,
) -> str:
    """List free-text answers from magic-link members' open-question form.

    Returns one item per ``(member, question_key)`` where the answer is
    non-empty. The answers are intentionally anonymized at the member
    level — items carry only ``team_id``, ``team_name``,
    ``organization_id``, ``organization_name``, ``question_key``, and
    ``answer``. Member id/name/email are NOT included, by design: the
    open-question form is the one part of the task-entry flow where a
    member is told their words aren't tied back to them.

    Use this when you need qualitative texture (blockers, what people
    would automate first, constraints) to complement the structured
    task-entry data from ``get_team_task_entries``. Do NOT try to
    correlate open responses to a specific named member — even if you
    could guess from voice, treat that as a leak and don't surface it.

    Filtering precedence: ``team_id`` (if provided) overrides ``org_id``.
    Both unset returns answers from every org the API key can see.

    ``question_key`` is a stable slug (``biggest_blocker``,
    ``would_automate_first``, ``wish_to_do_but_constraints``). Stale or
    unknown keys may appear if the question copy is renamed in i18n
    without a coordinated cleanup — treat unknown keys as informational.

    Args:
        team_id: Optional team UUID to scope to a single team.
        org_id: Optional organization id to scope to a single org. Ignored
            when ``team_id`` is provided.
        limit: Cap on number of items returned (1-2000, default 500). The
            list is iterated member-then-question-key, so very large orgs
            may need follow-up paginated calls in a future version.

    Returns: JSON array of items: ``[{team_id, team_name,
        organization_id, organization_name, question_key, answer}, ...]``
    """
    params: dict[str, str | int] = {"limit": limit}
    if team_id is not None:
        params["team_id"] = team_id
    elif org_id is not None:
        params["organization_id"] = org_id
    return api_get("/api/map/open-responses", params=params)


@mcp.tool()
def get_team_summary(team_id: str) -> str:
    """Get team reporting summary. Returns: team_id, team_name, organization_id, organization_name, total_task_entries, members_with_entries, total_members, active_days, fully_assessed_tasks. team_id is a UUID string."""
    return api_get(f"/api/map/reports/teams/{team_id}/summary")


@mcp.tool()
def get_org_map_summary(org_id: int) -> str:
    """Get organization-level map reporting summary. Returns: org_id, org_name, total_task_entries, members_with_entries, total_members, teams_count, active_days, fully_assessed_tasks."""
    return api_get(f"/api/map/reports/organizations/{org_id}/summary")


@mcp.tool()
def get_top_tasks(org_id: int | None = None) -> str:
    """Get the most common tasks ranked by how many people perform them. Returns: label (task name), frequency (time proportion — e.g. 'Most of my time', 'Some of my time'), count (number of people doing this task). Optionally filtered by org. NOTE: this is a popularity ranking, not an automation/AI opportunity ranking."""
    params = {"org_ids": str(org_id)} if org_id is not None else None
    return api_get("/api/map/reports/top-tasks", params=params)


# ── Catalog (tool/app name resolution) ───────────────────────────────────────


@mcp.tool()
def search_catalog_apps(query: str, org_id: int | None = None) -> str:
    """Search for tools/apps by name substring. Returns matching apps with
    id, name, is_org_private. When `org_id` is given, narrows visibility to
    public + that org's private rows; without it, returns public + every
    row in the API key's visibility scope. Use this when you know a tool
    NAME and want to find it. To resolve app UUIDs to names, use
    resolve_catalog_app_ids instead."""
    params: dict[str, str | int] = {"q": query}
    if org_id is not None:
        params["organization_id"] = org_id
    return api_get("/api/map/catalog-apps/search", params=params)


@mcp.tool()
def resolve_catalog_app_ids(ids: list[str]) -> str:
    """Resolve app UUIDs to human-readable names. Pass a list of UUID
    strings from task entry app_ids. Returns: id, name, is_org_private for
    each resolved app."""
    return api_post("/api/map/catalog-apps/by-ids", body={"ids": ids})


# ── Org app prepopulation (#430) — consultant workflow ──────────────────────


@mcp.tool()
def list_org_apps(org_id: int, limit: int = 200) -> str:
    """List custom (org-private) apps registered for an org, plus a count
    of how many public apps are visible.

    Use this during phase-1 kickoff to audit what an org already has
    before bulk-adding new entries via `add_org_apps`. Result is capped
    at `limit` (max 200); the response's `has_more` field signals
    truncation. For larger catalogs, narrow with `search_catalog_apps`
    using a name prefix.

    Args:
        org_id: Organization to list apps for. The API key must have
            visibility on this org (membership or `OrganizationAccessGrant`).
        limit: Maximum number of private apps to return (1-200).

    Returns: ``{private: [{id, name, is_org_private: true}],
              public_app_count: int, has_more: bool}``.
    """
    return api_get(
        "/api/map/catalog-apps/by-org",
        params={"organization_id": org_id, "limit": limit},
    )


@mcp.tool()
def add_org_apps(org_id: int, names: list[str]) -> str:
    """Bulk-add custom apps to an org's private catalog. Idempotent.

    Each name is run through the platform's `get-or-create` endpoint:
    - If a public app with that name already exists, it is reused (no
      duplicate is minted).
    - If the org already has a private app with that name, it is reused.
    - Otherwise a new private row is created stamped with `org_id`.

    Requires the `catalog_write` scope on the API key. Permission is also
    checked at the platform level: the key's user must have visibility on
    `org_id`.

    Args:
        org_id: Organization to add apps for.
        names: List of app names. Whitespace is trimmed; empty names are
            skipped.

    Returns: ``{
        created: list[{id, name}],          # newly minted private rows
        existed_public: list[{id, name}],   # name matched a public row — reused
        existed_private: list[{id, name}],  # name already private to this org — reused
        failed: list[{name, error}],        # names that errored (400/403/etc)
    }``
    """
    created: list[dict[str, str]] = []
    existed_public: list[dict[str, str]] = []
    existed_private: list[dict[str, str]] = []
    failed: list[dict[str, str]] = []

    for raw_name in names:
        name = raw_name.strip() if isinstance(raw_name, str) else ""
        if not name:
            failed.append({"name": raw_name, "error": "empty name"})
            continue
        try:
            payload_str = api_post(
                "/api/map/catalog-apps/get-or-create",
                body={"name": name, "organization_id": org_id},
            )
        except Exception as e:  # MCP tool surface — surface any error to caller
            failed.append({"name": name, "error": str(e)})
            continue

        import json

        try:
            payload = json.loads(payload_str)
        except (TypeError, ValueError) as e:
            failed.append({"name": name, "error": f"non-JSON response: {e}"})
            continue

        item = {"id": payload.get("id", ""), "name": payload.get("name", name)}
        if payload.get("was_created"):
            created.append(item)
        elif payload.get("is_org_private"):
            existed_private.append(item)
        else:
            existed_public.append(item)

    import json as _json

    return _json.dumps(
        {
            "created": created,
            "existed_public": existed_public,
            "existed_private": existed_private,
            "failed": failed,
        }
    )


# ── Recos module ─────────────────────────────────────────────────────────────


@mcp.tool()
def check_recos_freshness() -> str:
    """Check data freshness for recommendations."""
    return api_get("/api/recommend/freshness")


# ── Documentation ────────────────────────────────────────────────────────────


@mcp.tool()
def list_docs() -> str:
    """List the documentation navigation manifest — a tree of sections and pages, role-filtered for the authenticated user. Each leaf has a 'slug' (e.g. 'guides/ai-vibe-method', 'engagement/playbook-status') that can be passed to get_doc. The docs are the canonical description of the AI Vibe engagement method (phases, modules, roles, assets) — prefer reading them over restating the method from memory."""
    return api_get("/api/platform/docs/manifest")


@mcp.tool()
def get_doc(slug: str) -> str:
    """Get a documentation page by slug (e.g. 'index', 'guides/ai-vibe-method', 'engagement/playbook-status'). Returns title and markdown content. Use list_docs first to discover available slugs."""
    return api_get(f"/api/platform/docs/pages/{slug}")


# ── Role library templates (Cowork JD ingestion — #425) ────────────────────


@mcp.tool()
def list_role_templates(
    org_id: int | None = None,
    status: str = "all",
    search: str | None = None,
) -> str:
    """List role-library templates.

    Args:
        org_id: Filter by org (templates with matching org_id OR null/global).
        status: 'published' (default in UI), 'draft' (Cowork's drafts queue),
            or 'all'. Defaults to 'all' here so Cowork sees both during the
            survey-the-library step of its drafting loop.
        search: Substring match on template name.

    Always call this BEFORE creating a draft — Cowork's protocol requires
    surveying the existing library first to decide reuse / extend / new.
    """
    params: dict[str, str | int] = {"status": status}
    if org_id is not None:
        params["org_id"] = org_id
    if search:
        params["search"] = search
    return api_get("/api/map/library-templates", params=params)


@mcp.tool()
def get_role_template(template_id: str) -> str:
    """Get full details of a role-library template (work areas + tasks + cowork_metadata).

    Args:
        template_id: UUID of the template.
    """
    return api_get(f"/api/map/library-templates/{template_id}")


@mcp.tool()
def search_catalog_tasks(query: str, lang: str = "en", limit: int = 50) -> str:
    """Vector-search the canonical task catalog for similar task labels.

    Use this during the drafting loop to decide whether a task in a JD is
    already represented in the catalog (link) or genuinely new (create on
    publish). Mirrors the bucketing the Generate flow uses internally.

    Args:
        query: The task label to search for.
        lang: 'en' (default) or 'fr' — selects which embedding column to query.
        limit: Max number of results (default 50).
    """
    return api_get(
        "/api/map/catalog-tasks/search",
        params={"q": query, "lang": lang, "limit": limit},
    )


@mcp.tool()
def create_role_template_draft(
    name: str,
    org_id: int,
    work_areas: list[dict],
    description: str | None = None,
    tags: list[str] | None = None,
    source_references: list[dict] | None = None,
    cowork_metadata: dict | None = None,
) -> str:
    """Create a draft role-library template from a JD.

    Requires the API key to have the `draft_write` scope. Status is forced
    to 'draft' regardless of body — a human publishes drafts via the
    platform UI, never via this tool.

    Args:
        name: Role title (e.g. "Senior Data Analyst").
        org_id: Organization the draft belongs to.
        work_areas: List of {"label": str, "template_tasks": [{"label": str,
            "catalog_task_id": str | None}]}. catalog_task_id should be set
            for tasks you matched via search_catalog_tasks; left null
            otherwise (publish will run dedup).
        description: Free-text role description.
        tags: List of tag strings.
        source_references: List of {"drive_file_id": str, "name": str,
            "ingested_at": str-iso} entries — the JDs that contributed.
        cowork_metadata: Structured reasoning. Recommended keys: 'verdict'
            ('reuse'|'extend'|'new'), 'matched_catalog_count', 'confidence'
            ('high'|'medium'|'low'), 'notes' (free-text).
    """
    body: dict = {
        "name": name,
        "org_id": org_id,
        "template_work_areas": work_areas,
    }
    if description is not None:
        body["description"] = description
    if tags is not None:
        body["tags"] = tags
    if source_references is not None:
        body["source_references"] = source_references
    if cowork_metadata is not None:
        body["cowork_metadata"] = cowork_metadata
    return api_post("/api/map/library-templates/drafts", body=body)


@mcp.tool()
def update_role_template_draft(
    template_id: str,
    name: str | None = None,
    description: str | None = None,
    tags: list[str] | None = None,
    source_references: list[dict] | None = None,
    cowork_metadata: dict | None = None,
    work_areas: list[dict] | None = None,
) -> str:
    """Update a draft role-library template (partial).

    Returns 400 if the template is no longer in draft status (i.e., the
    expert published it on the platform). Pass only the fields you want to
    update; omit the rest. When `work_areas` is provided, the full content
    tree is replaced.

    Args:
        template_id: UUID of the draft template.
        name: New role title.
        description: New free-text description.
        tags: Replacement tag list.
        source_references: Replacement source list.
        cowork_metadata: Replacement reasoning. Should reflect the *current*
            state of your reasoning, not a chat log.
        work_areas: Replacement content tree. Same shape as
            `create_role_template_draft`.
    """
    body: dict = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if tags is not None:
        body["tags"] = tags
    if source_references is not None:
        body["source_references"] = source_references
    if cowork_metadata is not None:
        body["cowork_metadata"] = cowork_metadata
    if work_areas is not None:
        body["template_work_areas"] = work_areas
    return api_patch(f"/api/map/library-templates/drafts/{template_id}", body=body)


# ── Role-library deploy (#457) ──────────────────────────────────────────────


@mcp.tool()
def deploy_role_template_to_teams(
    template_id: str,
    team_ids: list[str],
    on_conflict: str = "skip",
) -> str:
    """Deploy a published library role template to one or more teams.

    Creates a Role row on each team mirroring the template (name, work
    areas, tasks). The new role is then visible on the team's roles tab
    and can be applied to members from the platform UI.

    on_conflict resolution (single decision applied across all teams):
      - "skip" (default): teams that already have a role with the same
        name come back with status="skipped" and are not modified.
      - "replace": existing same-named roles are overwritten with the
        template's content (destructive — clears prior work-area + task
        subtree on the role).

    Per-team result rows: {team_id, team_name, role_id, status} where
    status is one of: created | replaced | skipped | forbidden.
    "forbidden" is returned inline when the caller lacks access to a
    specific team's org; the rest of the batch still proceeds.

    Use ``check_role_template_deploy_conflicts`` first if you want to
    preview collisions before committing to a single on_conflict
    strategy.

    Requires:
    - ``team_write`` API key scope.
    - Active org bound and matching every team in ``team_ids`` (call
      ``set_active_org`` first; off-org teams fail fast with
      ``ORG_SCOPE_MISMATCH``).
    - The template is in ``published`` status — drafts are rejected with
      400 (approve them via the UI first).

    Args:
        template_id: UUID string of the published library role template.
        team_ids: list of team UUID strings to deploy to.
        on_conflict: "skip" or "replace".
    """
    return api_post(
        f"/api/map/library-templates/{template_id}/deploy",
        body={"team_ids": team_ids, "on_conflict": on_conflict},
    )


@mcp.tool()
def check_role_template_deploy_conflicts(
    template_id: str,
    team_ids: list[str],
) -> str:
    """Preview which teams already have a role with the template's name.

    Pure read — no writes happen. Use this before
    ``deploy_role_template_to_teams`` when you want to describe collisions
    to the user before picking an on_conflict strategy. Returns one row
    per team: {team_id, team_name, has_conflict}.

    Auth requirements match deploy: ``team_write`` scope and an active
    org matching every team in ``team_ids``.
    """
    return api_post(
        f"/api/map/library-templates/{template_id}/check-conflicts",
        body={"team_ids": team_ids},
    )


# ── Cowork org-chart ingestion (#454) ───────────────────────────────────────
#
# Two scopes power this surface:
#  - team_write : team CRUD + manager assignments + member CRUD by email.
#  - user_write : platform-user create + email/name update (Supabase dual-write).
#
# Cowork's typical ingest flow per team:
#  1. create_team(...)
#  2. for each person in the team:
#       add_team_member(team_id, email, name)   # placeholder emails are fine
#  3. for each manager in the team:
#       res = add_team_manager(team_id, user_email)
#       if res["error_code"] == "USER_NOT_FOUND":
#           # leave them as a member-only row; surface in session output
#           # so the org admin invites them through the normal flow
#           continue
#       if res["error_code"] == "USER_EXISTS_NO_ORG_ACCESS":
#           # escalate — org admin must grant access first; do NOT silently
#           # downgrade to member-only (would create a stale duplicate)
#           continue
#  4. for each later edit (placeholder email -> real email):
#       update_team_member(team_id, current_email, new_email=...)
#       update_user(user_id, email=...)         # if they're also a platform user
#
# Add tools are CREATE-ONLY, NEVER OVERWRITE — re-adding an existing row
# returns the existing record unchanged. Use the update tools to edit.
# ─────────────────────────────────────────────────────────────────────────────


@mcp.tool()
def create_team(
    org_id: int,
    name: str,
    description: str | None = None,
    region: str | None = None,
    division: str | None = None,
    team_type: str | None = None,
    is_workflow: bool = False,
) -> str:
    """Create a new team in an organization.

    Requires the API key to have the `team_write` scope.

    Args:
        org_id: Organization the team belongs to.
        name: Team name.
        description: Optional free-text description.
        region, division, team_type: Optional org-chart classifications.
        is_workflow: True for workflow rows, False (default) for normal teams.

    Returns the full team object (id is a UUID string).
    """
    body: dict = {
        "organization_id": org_id,
        "name": name,
        "is_workflow": is_workflow,
    }
    if description is not None:
        body["description"] = description
    if region is not None:
        body["region"] = region
    if division is not None:
        body["division"] = division
    if team_type is not None:
        body["team_type"] = team_type
    return api_post("/api/map/teams", body=body)


@mcp.tool()
def update_team(
    team_id: str,
    name: str | None = None,
    description: str | None = None,
    region: str | None = None,
    division: str | None = None,
    team_type: str | None = None,
    is_active: bool | None = None,
) -> str:
    """Partial update a team. Pass only the fields you want to change.

    Soft-delete is via `is_active=false`. There is no hard-delete tool.
    `org_id` is intentionally not editable — cross-org transfer is out of
    scope (FK cascade implications).

    Requires the API key to have the `team_write` scope.

    Args:
        team_id: UUID string of the team.
    """
    body: dict = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if region is not None:
        body["region"] = region
    if division is not None:
        body["division"] = division
    if team_type is not None:
        body["team_type"] = team_type
    if is_active is not None:
        body["is_active"] = is_active
    return api_patch(f"/api/map/teams/{team_id}", body=body)


@mcp.tool()
def add_team_manager(team_id: str, user_email: str) -> str:
    """Assign a manager to a team by email lookup. Idempotent.

    The user MUST already exist in the platform AND have access to the
    team's org. The MCP server does not auto-promote members to managers
    or auto-create users — that's a deliberate, permissioned action via
    the org admin invite flow on the platform UI.

    Distinguishable error codes (in the response `code` field on 4xx):
    - `USER_NOT_FOUND`           — no platform user with that email. Cowork's
                                   fallback: keep them as a member-only row.
    - `USER_EXISTS_NO_ORG_ACCESS` — user exists but lacks org access.
                                   Cowork's fallback: escalate to org admin
                                   to grant access; do NOT silently downgrade
                                   to member-only.
    - `INSUFFICIENT_PERMISSIONS` — caller's user lacks MANAGE_ORG_USERS or
                                   doesn't have access to this org.

    On success, the platform auto-creates a Member shadow row for the
    manager (preserves UI behavior).

    Requires the API key to have the `team_write` scope.

    Args:
        team_id: UUID string of the team.
        user_email: The email of an existing platform user.
    """
    return api_post(
        f"/api/map/teams/{team_id}/managers/by-email",
        body={"user_email": user_email},
    )


@mcp.tool()
def remove_team_manager(team_id: str, user_email: str) -> str:
    """Remove a manager from a team by email. Idempotent.

    Does NOT delete the auto-created Member shadow row — preserves task
    entry attribution and magic-link/session history. To remove the
    person from the team entirely, also call `remove_team_member`.

    Requires the API key to have the `team_write` scope.
    """
    return api_delete(f"/api/map/teams/{team_id}/managers/by-email/{user_email}")


@mcp.tool()
def add_team_member(
    team_id: str, email: str, name: str, user_title: str | None = None
) -> str:
    """Add a team member, or return the existing row on `(team_id, email)` collision.

    Idempotent and CREATE-ONLY: when a row with the same `(team_id, email)`
    exists, returns the existing record without overwriting `name` or
    `user_title`. To change a member's email/name/title, use
    `update_team_member`.

    Members are stored in the per-team `member` table — they are NOT
    platform users and have no Supabase auth account. Placeholder emails
    are fine here. To make someone a platform user (e.g., to also assign
    them as a manager), use the org admin invite flow on the platform UI.

    Requires the API key to have the `team_write` scope.

    Args:
        team_id: UUID string of the team.
        email: The member's email (any string).
        name: The member's display name.
        user_title: The member's job title from the org chart (e.g.,
            "Director, Development"). Optional — pass `None` (or omit) to
            leave the field empty.
    """
    body: dict = {"email": email, "name": name}
    if user_title is not None:
        body["user_title"] = user_title
    return api_post(f"/api/map/teams/{team_id}/members/by-mcp", body=body)


@mcp.tool()
def update_team_member(
    team_id: str,
    current_email: str,
    new_email: str | None = None,
    new_name: str | None = None,
    new_user_title: str | None = None,
) -> str:
    """Legacy. Prefer `update_team_member_by_id` when you have the id.

    Email is mutable; the row's UUID `id` is the stable primary key.
    `add_team_member` and `get_team_members` both return the id, so any
    caller that read the row before writing can — and should — use
    `update_team_member_by_id`. This email-keyed path stays for the rare
    case where only the current email is known (e.g., a placeholder you
    just created and have in context).

    Update a team member identified by `(team_id, current_email)`. At
    least one of `new_email`, `new_name`, or `new_user_title` must be
    provided.

    Email-collision: if `new_email` matches another existing member of the
    same team, returns 409 with `code="MEMBER_EMAIL_CONFLICT"` and both
    member IDs in `details`.

    To clear an existing `user_title`, pass `new_user_title=""` (empty
    string). Pass `None` (or omit) to leave the field unchanged.

    Requires the API key to have the `team_write` scope.
    """
    body: dict = {}
    if new_email is not None:
        body["new_email"] = new_email
    if new_name is not None:
        body["new_name"] = new_name
    if new_user_title is not None:
        body["new_user_title"] = new_user_title
    return api_patch(
        f"/api/map/teams/{team_id}/members/by-email/{current_email}",
        body=body,
    )


@mcp.tool()
def remove_team_member(team_id: str, email: str) -> str:
    """Legacy. Prefer `remove_team_member_by_id` when you have the id.

    Same rationale as `update_team_member`: id is the stable primary key.
    This email-keyed path stays for compat.

    Remove a team member by email. Idempotent.

    Requires the API key to have the `team_write` scope.
    """
    return api_delete(f"/api/map/teams/{team_id}/members/by-email/{email}")


@mcp.tool()
def update_team_member_by_id(
    member_id: str,
    new_email: str | None = None,
    new_name: str | None = None,
    new_user_title: str | None = None,
) -> str:
    """Update a team member identified by `member_id` (UUID).

    Prefer this over `update_team_member` for any update where you have
    the id (typically you do — `add_team_member` and `get_team_members`
    both return it). The id-keyed path targets a stable row regardless
    of email churn (rename, placeholder→real swap, post-onboarding
    email change). The email-keyed legacy tool is for the narrow case
    where only the email is known.

    At least one of `new_email`, `new_name`, or `new_user_title` must be
    provided. Pass `new_user_title=""` to clear the field; `None` (or
    omit) leaves it unchanged.

    Email-collision: if `new_email` matches another existing member of
    the same team, returns 409 with `code="MEMBER_EMAIL_CONFLICT"` and
    both member IDs in `details`. Missing or cross-org member returns
    404 `MEMBER_NOT_FOUND`.

    Requires the API key to have the `team_write` scope.
    """
    body: dict = {}
    if new_email is not None:
        body["new_email"] = new_email
    if new_name is not None:
        body["new_name"] = new_name
    if new_user_title is not None:
        body["new_user_title"] = new_user_title
    return api_patch(f"/api/map/members/{member_id}/by-mcp", body=body)


@mcp.tool()
def remove_team_member_by_id(member_id: str) -> str:
    """Remove a team member identified by `member_id` (UUID). Idempotent.

    Prefer this over `remove_team_member` for the same reason as the
    update sibling — id is the stable primary key.

    Requires the API key to have the `team_write` scope.
    """
    return api_delete(f"/api/map/members/{member_id}/by-mcp")


@mcp.tool()
def get_user_by_email(email: str) -> str:
    """Look up a platform user by email. Returns `null` on miss.

    Use this to verify that a user exists (and check the name matches the
    org-chart entry) BEFORE issuing `add_team_manager`. Names are returned
    unmasked when the API key is authorized to write — callers need ground
    truth to safely act on user identities.

    Requires the API key to have the `read` scope (default for all keys).
    """
    return api_get(f"/api/platform/users/by-email/{email}")


@mcp.tool()
def create_user(name: str, email: str | None = None) -> str:
    """Create a platform user.

    - When `email` is omitted, the server generates a guaranteed-unique
      placeholder of the shape::

          firstname.lastname-<8hex>@placeholder.invalid

      `.invalid` is RFC-reserved as never-resolvable, so the placeholder
      cannot escape into real mail. The user gets a real Supabase auth
      row but cannot log in until `update_user` swaps the placeholder for
      a real email.
    - When `email` is provided and already exists, returns 409 with
      `code="EMAIL_ALREADY_EXISTS"`. Use `get_user_by_email` for
      find-or-create semantics.

    **Strongly prefer omitting `email` for bulk seeding.** The server-
    generated placeholder is collision-safe; passing made-up addresses
    like `firstname.lastname@todo.com` is dangerous because repeated
    names ("Vacant", "NEW HIRE 2026") will collide on the global email
    uniqueness constraint and silently merge into one user. Only pass
    `email` when you have a real one — and only after calling
    `get_user_by_email` first to confirm it isn't already taken.

    No password, no membership, no invitation send. The standard org
    admin flow on the platform handles those once the user is ready.

    Requires the API key to have the `user_write` scope.
    """
    body: dict = {"name": name}
    if email is not None:
        body["email"] = email
    return api_post("/api/platform/users/by-mcp", body=body)


@mcp.tool()
def update_user(
    user_id: int,
    email: str | None = None,
    name: str | None = None,
) -> str:
    """Partial update a platform user's email and/or name.

    - Email change performs Supabase + platform-DB dual-write. On
      Supabase failure the platform DB is not touched; on platform DB
      failure after Supabase success, the Supabase change is rolled back
      (best-effort — drift requires manual reconciliation if the rollback
      itself fails).
    - Refuses to change a superadmin's email regardless of scope
      possession (`code="SUPERADMIN_EMAIL_LOCKED"`, 403). Name changes
      on superadmins are allowed (no privilege-escalation surface).
    - When the target user has `supabase_user_id=None` (legacy data),
      the email-change path creates a fresh Supabase row using the new
      email rather than PATCHing.

    Requires the API key to have the `user_write` scope.
    """
    body: dict = {}
    if email is not None:
        body["email"] = email
    if name is not None:
        body["name"] = name
    return api_patch(f"/api/platform/users/by-mcp/{user_id}", body=body)


@mcp.tool()
def add_user_to_org(
    user_email: str,
    organization_id: int,
    org_role: str = "org_viewer",
) -> str:
    """Grant a platform user membership in an org at a specific role.

    Closes the seed-flow gap from #454: after `create_user` mints a user,
    `add_team_manager` returns USER_EXISTS_NO_ORG_ACCESS until the user
    has membership. This tool grants that membership directly.

    Sequence: `create_user` → `add_user_to_org` → `add_team_manager`.

    Args:
        user_email: Email of an existing platform user (use `create_user`
            first if needed).
        organization_id: Org to grant access to. Caller must have
            visibility on this org.
        org_role: One of the valid access levels for the org's type:
            - Regular/child orgs: `org_viewer` (default), `team_manager`,
              `org_admin`.
            - Consultancies: also `consultant`, `sp_admin`.
            - `superadmin` is rejected (platform-level only).
            Default `org_viewer` is the narrowest role that satisfies
            the manager-assignment precondition.

    Idempotency rules:
        - No existing membership: creates one at the requested role.
        - Existing same role or higher rank: no-op, returns existing row.
        - Existing lower rank than requested: returns 409 with
          `code="ORG_ROLE_CHANGE_REQUIRES_REMOVAL"` — never silently
          upgrades. Org admin must remove and re-grant via the platform
          UI for explicit role increases.
        - Deactivated row: reactivated at the higher of (prior, requested)
          rank to avoid silent downgrades.

    Distinguishable error codes (in 4xx response `code`):
        - `USER_NOT_FOUND` (404)
        - `ORG_NOT_FOUND` (404)
        - `INSUFFICIENT_PERMISSIONS` (403)
        - `RANK_CEILING_EXCEEDED` (403) — caller can't grant a role
          higher than their own
        - `INVALID_ROLE` (400) — unknown role, `superadmin`, or role not
          permitted for this org type
        - `ORG_ROLE_CHANGE_REQUIRES_REMOVAL` (409)

    **Skips invitation send.** Cowork is mid-seed, placeholder users
    can't receive invites anyway, and the org admin triggers invites
    later via the platform UI's resend-invitation flow once emails are
    confirmed. After granting access for real-email users, surface them
    in your session output so the expert remembers to send invites.

    Requires the API key to have the `org_membership_write` scope.
    """
    return api_post(
        "/api/platform/users/grant-org-access",
        body={
            "user_email": user_email,
            "organization_id": organization_id,
            "org_role": org_role,
        },
    )


# ── Active-org session scoping (#456) ───────────────────────────────────────
#
# Every MCP write tool requires an active_org binding on the API key. Without
# it, writes refuse with ACTIVE_ORG_REQUIRED. With it, writes are validated
# against the binding and refuse on mismatch with ORG_SCOPE_MISMATCH. This
# closes the cross-org accidental-iteration footgun (e.g. "change all emails
# to @todo.com" walking every team in every org the key can see).
#
# **Always call `set_active_org` at the start of any write-using session.**
# If you don't, the first write call will fail and the error message will
# point you here.


@mcp.tool()
def set_active_org(org_id: int) -> str:
    """Bind this API key to one org for the rest of the session.

    Required before any write tool can be called. The binding lives on
    the server (api_key.active_org_id) and persists across MCP tool
    calls. Reads are unaffected.

    Switching orgs mid-session is explicit: call `set_active_org(M)`
    again with the new org. Stale conversation history about a prior
    org doesn't auto-bind — only this call does.

    Args:
        org_id: Organization the rest of this session writes against.
            The calling user must have access (membership or grant).

    Returns: ``{api_key_id, active_org_id, organization_name}``.
    """
    return api_post("/api/platform/api-keys/active-org", body={"org_id": org_id})


@mcp.tool()
def clear_active_org() -> str:
    """Clear the active-org binding on this API key.

    After clearing, every write call refuses with ACTIVE_ORG_REQUIRED
    until `set_active_org(N)` is called again. Useful as a session-end
    discipline ritual or when you want to lock the key down between
    work sessions.
    """
    return api_post("/api/platform/api-keys/active-org", body={"org_id": None})


@mcp.tool()
def get_active_org() -> str:
    """Read the current active-org binding on this API key.

    Use this as a sanity check at the start of a session — if it
    returns null, you'll need to call `set_active_org(N)` before any
    write tool will succeed.

    Returns: ``{api_key_id, active_org_id, organization_name}`` —
    ``active_org_id`` and ``organization_name`` are null when unbound.
    """
    return api_get("/api/platform/api-keys/active-org")


def main() -> None:
    """Entry point for the MCP server (stdio transport)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
