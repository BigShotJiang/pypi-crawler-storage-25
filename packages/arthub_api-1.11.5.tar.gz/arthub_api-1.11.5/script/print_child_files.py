from arthub_api.__main__ import init_config
from arthub_api.__main__ import setup_logging
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from arthub_api.utils import logger

setup_logging()
init_config()

open_api = OpenAPI(api_config_qq)
res = open_api.login(account_name=arthub_api_config.account_email,
                     password=arthub_api_config.password,
                     login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)

storage_cls = Storage(open_api)
res = storage_cls.get_child_nodes_brief_by_id(asset_hub="lk", parent_node_id=120347604868521)
files = res.data
for file in files:
    file_name = storage_cls.node_full_name(file)
    logger.info(file_name)

print("over")
