from arthub_api.__main__ import init_config
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from urllib.parse import urlparse, parse_qs

init_config()

open_api = OpenAPI(api_config_qq)
res = open_api.login(account_name=arthub_api_config.account_email,
                     password=arthub_api_config.password,
                     login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)

# extract node id information from public url
url = "https://arthub.qq.com/apg/pan?node=110347132347390&token=cr1d4qb7aevrb2uqjv50"
parsed_url = urlparse(url)
query_params = parse_qs(parsed_url.query)
node_id = int(query_params.get('node', [None])[0])

# get node brief by id
res = open_api.depot_get_node_brief_by_ids(asset_hub="apg", ids=[node_id])
if not res.is_succeeded():
    print("get node failed, message: %s", res.error_message())
    exit(-1)

node_brief = res.result[0]
print("get node brief success, path: {}".format(node_brief.get("full_path_name")))
