from arthub_api.__main__ import init_config
from arthub_api.__main__ import setup_logging
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from arthub_api.utils import logger
from arthub_api.utils import get_download_file_size

setup_logging()
init_config()

open_api = OpenAPI(api_config_qq)
res = open_api.login(account_name=arthub_api_config.account_email,
                     password=arthub_api_config.password,
                     login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)
storage = Storage(open_api)


def on_operation_failed(operation, error_message):
    logger.error("[SCRIPT] %s failed, error: %s" % (operation, error_message))


def check_asset(asset_hub, root_id):
    r = storage.get_child_nodes_brief_by_id(asset_hub, root_id,
                                            [{"meta": "type", "condition": "x == asset || x == multiasset"}], True,
                                            False)
    if not r.is_succeeded():
        on_operation_failed("get_child_nodes_brief_by_id", r.error_message())

    all_nodes = r.data
    for node in all_nodes:
        res = open_api.depot_get_download_signature(asset_hub,
                                                    nodes=[{"object_id": node["id"], "object_meta": "origin_url"}])
        if not res.is_succeeded():
            logger.error(
                "[SCRIPT] get download signature failed, id: {}, error: {}".format(node["id"], res.error_message()))
        download_url = res.result
        res = get_download_file_size(download_url)
        if not res.is_succeeded():
            logger.error(
                "[SCRIPT] get file size failed, id: {}, error: {}, url: {}".format(node["id"], res.error_message(),
                                                                                   download_url))
        else:
            print("get file {} size: {}".format(node["id"], res.data))


check_asset("honorofkings", 110347172492864)
