# -*- coding: utf-8 -*-
"""测试 NodeCache"""
from __future__ import absolute_import, print_function, unicode_literals

import unittest

from arthub_api.am._internal.cache import NodeCache


class TestNodeCache(unittest.TestCase):
    """测试 NodeCache"""
    
    def setUp(self):
        """测试前准备"""
        self.cache = NodeCache()
        
    def test_put_and_get(self):
        """测试存储和获取"""
        # 创建一个简单的对象
        obj = {'id': 123, 'name': 'Test'}
        
        # 存储
        self.cache.put('Task', 123, obj)
        
        # 获取
        cached = self.cache.get('Task', 123)
        self.assertEqual(cached, obj)
        
    def test_get_nonexistent(self):
        """测试获取不存在的对象"""
        result = self.cache.get('Task', 999)
        self.assertIsNone(result)
        
    def test_different_types(self):
        """测试不同类型的节点"""
        task = {'type': 'Task'}
        version = {'type': 'Version'}
        
        self.cache.put('Task', 1, task)
        self.cache.put('Version', 1, version)
        
        # 同样的 ID 但不同的类型应该分开存储
        self.assertEqual(self.cache.get('Task', 1), task)
        self.assertEqual(self.cache.get('Version', 1), version)
        
    def test_clear(self):
        """测试清空缓存"""
        self.cache.put('Task', 1, {'id': 1})
        self.cache.put('Task', 2, {'id': 2})
        
        self.assertEqual(len(self.cache), 2)
        
        self.cache.clear()
        self.assertEqual(len(self.cache), 0)
        self.assertIsNone(self.cache.get('Task', 1))


if __name__ == '__main__':
    unittest.main()
