# -*- coding: utf-8 -*-
"""测试 Node 类"""
from __future__ import absolute_import, print_function, unicode_literals

import unittest

try:
    from unittest.mock import Mock, MagicMock, patch
except ImportError:
    from mock import Mock, MagicMock, patch

from arthub_api.am.node import Node, PropertyView
from arthub_api.am.exceptions import AMAPIError


class TestNode(unittest.TestCase):
    """测试 Node 基类"""
    
    def setUp(self):
        """测试前准备"""
        # 创建 mock session
        self.mock_session = Mock()
        self.mock_session._loader = Mock()
        self.mock_session.schemas = Mock()
        
        # 创建 Node 实例
        self.node = Node(
            self.mock_session,
            123,
            data={'name': 'Test Node', 'id': 123}
        )
        
    def test_id(self):
        """测试 ID 属性"""
        self.assertEqual(self.node.id, 123)
        
    def test_class_name(self):
        """测试类名"""
        self.assertEqual(self.node.class_name, 'Node')
        
    def test_getitem_from_cache(self):
        """测试从缓存读取属性"""
        value = self.node['name']
        self.assertEqual(value, 'Test Node')
        # 不应该调用 loader
        self.mock_session._loader.load_node_properties.assert_not_called()
        
    def test_getitem_auto_load(self):
        """测试自动加载属性"""
        # 模拟 loader 返回
        self.mock_session._loader.load_node_properties.return_value = {
            'artist': ['user1', 'user2']
        }
        
        # 访问不存在的属性
        value = self.node['artist']
        
        # 应该调用 loader
        self.mock_session._loader.load_node_properties.assert_called_once()
        self.assertEqual(value, ['user1', 'user2'])
        
    def test_setitem(self):
        """测试设置属性"""
        self.node['name'] = 'New Name'
        self.assertEqual(self.node._modified['name'], 'New Name')
        
    def test_get(self):
        """测试 get 方法"""
        value = self.node.get('name')
        self.assertEqual(value, 'Test Node')
        
        value = self.node.get('nonexistent', 'default')
        self.assertEqual(value, 'default')
        
    def test_keys(self):
        """测试 keys 方法"""
        keys = self.node.keys()
        self.assertIn('name', keys)
        self.assertIn('id', keys)
        
    def test_is_modified(self):
        """测试 is_modified"""
        self.assertFalse(self.node.is_modified())
        
        self.node['name'] = 'Modified'
        self.assertTrue(self.node.is_modified())
        
    def test_commit_success(self):
        """测试成功提交"""
        self.node['name'] = 'New Name'
        
        # 模拟提交成功
        self.mock_session._loader.update_node_properties.return_value = True
        
        self.node.commit()
        
        # 检查
        self.assertFalse(self.node.is_modified())
        self.assertEqual(self.node._data['name'], 'New Name')
        
    def test_commit_failure(self):
        """测试提交失败"""
        self.node['name'] = 'New Name'
        
        # 模拟提交失败
        self.mock_session._loader.update_node_properties.return_value = False
        
        with self.assertRaises(AMAPIError):
            self.node.commit()
            
    def test_schema(self):
        """测试获取 Schema"""
        mock_schema = {'display_name': '名称', 'type_name': 'string'}
        self.mock_session.schemas.__getitem__.return_value = mock_schema
        
        schema = self.node.schema('name')
        self.assertEqual(schema, mock_schema)
        
    def test_to_dict(self):
        """测试导出为字典"""
        self.node['artist'] = ['user1']
        result = self.node.to_dict()
        
        self.assertIn('name', result)
        self.assertIn('artist', result)
        self.assertEqual(result['artist'], ['user1'])
        
    def test_repr(self):
        """测试字符串表示"""
        repr_str = repr(self.node)
        self.assertIn('Node', repr_str)
        self.assertIn('123', repr_str)
        self.assertIn('Test Node', repr_str)


class TestPropertyView(unittest.TestCase):
    """测试 PropertyView"""
    
    def setUp(self):
        """测试前准备"""
        # 创建 mock
        self.mock_session = Mock()
        self.mock_session.schemas = Mock()
        
        # 模拟 schemas.get
        def mock_get(key):
            schemas = {
                'name': {'display_name': '名称'},
                'artist': {'display_name': '负责人'},
            }
            return schemas.get(key)
            
        self.mock_session.schemas.get.side_effect = mock_get
        
        # 创建 Node
        self.node = Node(
            self.mock_session,
            123,
            data={'name': 'Test', 'artist': ['user1']}
        )
        
    def test_repr(self):
        """测试 PropertyView 的字符串表示"""
        view = PropertyView(self.node)
        repr_str = repr(view)
        
        self.assertIn('名称', repr_str)
        self.assertIn('负责人', repr_str)
        
    def test_getitem(self):
        """测试通过 PropertyView 访问属性"""
        view = PropertyView(self.node)
        value = view['name']
        self.assertEqual(value, 'Test')


if __name__ == '__main__':
    unittest.main()
