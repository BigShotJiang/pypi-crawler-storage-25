# -*- coding: utf-8 -*-
"""Predefined Tag Tree module.

Provides high-level wrapper classes for managing predefined tag trees
in ArtHub. Predefined tags are organized as a tree structure where each
node has a unique id and name.

Typical usage:
    from arthub_api import OpenAPI, api_config_qq
    from arthub_api.predefined_tag import PredefinedTagTree

    open_api = OpenAPI(api_config_qq)
    open_api.set_public_token("your_token")

    tree = PredefinedTagTree(open_api, "your_asset_hub")
    tree.fetch_all()
    tree.print_tree()
"""
from __future__ import absolute_import, print_function, unicode_literals

from .open_api import APIError


class PredefinedTagNode(object):
    """A single node in the predefined tag tree.

    Attributes:
        id (int): unique tag id.
        name (str): tag display name.
        parent_id (int or None): parent tag id, None for root nodes.
        tagtree_id (int or None): the root tag tree id this node belongs to.
        color (str or None): color string for root nodes. e.g. "#3F9EFF".
        node_type (int or None): node type value from API.
        child_cnt (int): expected number of children (from parent query).
        children (list): list of child PredefinedTagNode instances.
        raw_data (dict): raw data from API response.
    """

    def __init__(self, tag_id, name="", parent_id=None, tagtree_id=None,
                 color=None, node_type=None, child_cnt=0, raw_data=None):
        # type: (int, str, int, int, str, int, int, dict) -> None
        self.id = tag_id
        self.name = name
        self.parent_id = parent_id
        self.tagtree_id = tagtree_id
        self.color = color
        self.node_type = node_type
        self.child_cnt = child_cnt
        self.children = []  # type: list
        self.raw_data = raw_data or {}

    def find_by_id(self, tag_id):
        # type: (int) -> PredefinedTagNode or None
        """Find a node by id in this subtree (including self).

        :param tag_id: int. The tag id to search for.
        :return: PredefinedTagNode or None.
        """
        if self.id == tag_id:
            return self
        for child in self.children:
            result = child.find_by_id(tag_id)
            if result is not None:
                return result
        return None

    def find_all_by_name(self, name):
        # type: (str) -> list
        """Find all nodes matching the given name in this subtree.

        Note: Tag names can be duplicated, use find_by_path for unique lookup.

        :param name: str. The tag name to search for.
        :return: list of PredefinedTagNode.
        """
        results = []
        if self.name == name:
            results.append(self)
        for child in self.children:
            results.extend(child.find_all_by_name(name))
        return results

    def _find_by_path_parts(self, path_parts):
        # type: (list) -> PredefinedTagNode or None
        """Internal method to find node by path parts list.

        :param path_parts: list of str. Path components.
        :return: PredefinedTagNode or None.
        """
        if not path_parts:
            return self
        
        target_name = path_parts[0]
        remaining_parts = path_parts[1:]
        
        for child in self.children:
            if child.name == target_name:
                return child._find_by_path_parts(remaining_parts)
        
        return None

    def walk(self):
        # type: () -> object
        """Depth-first traversal of this subtree.

        Yields:
            tuple: (node, depth) where depth is relative to this node (0-based).
        """
        yield self, 0
        for child in self.children:
            for node, d in child.walk():
                yield node, d + 1

    def __repr__(self):
        return "PredefinedTagNode(id=%s, name=%r)" % (self.id, self.name)


class PredefinedTagTree(object):
    """Manager for predefined tag tree operations.

    Provides methods to fetch the full tag tree, search nodes,
    add/remove tags on assets, and query asset tag mappings.

    Example:
        tree = PredefinedTagTree(open_api, "trial")
        tree.fetch_all()
        tree.print_tree()

        # find a tag by path (path is unique)
        node = tree.find_by_path("root/child/leaf")
        if node:
            tree.add_tags([node.id], asset_ids=[asset_id])
    """

    def __init__(self, open_api, asset_hub):
        # type: (object, str) -> None
        """Initialize PredefinedTagTree.

        :param open_api: OpenAPI instance (must be logged in).
        :param asset_hub: str. The asset hub name. Example: "trial".
        """
        self.open_api = open_api
        self.asset_hub = asset_hub
        self.roots = []  # type: list

    def fetch_all(self):
        # type: () -> list
        """Recursively fetch the entire predefined tag tree into memory.

        Fetches root nodes first, then recursively fetches children layer by
        layer. Returns and stores the root node list.

        :return: list of PredefinedTagNode (root nodes).
        :raises APIError: if any API call fails.
        """
        # Step 1: fetch root-level tag tree IDs
        res = self.open_api.depot_get_predefined_tagtree_ids(self.asset_hub)
        if not res.is_succeeded():
            raise APIError("Failed to get predefined tagtree ids: %s" % res.error_message())

        root_ids = res.result or []  # list<int>
        if not root_ids:
            self.roots = []
            return self.roots

        # Step 2: batch fetch details for all root IDs
        detail_res = self.open_api.depot_get_predefined_tagtree_detail(
            self.asset_hub, root_ids
        )
        if not detail_res.is_succeeded():
            raise APIError(
                "Failed to get predefined tagtree details: %s" % detail_res.error_message()
            )
        
        # Parse detail response (root level returns array directly)
        detail_items = detail_res.result or []
        
        # Create root nodes
        self.roots = []
        for detail in detail_items:
            node = PredefinedTagNode(
                tag_id=detail.get("id"),
                name=detail.get("name", ""),
                color=detail.get("color"),
                raw_data=detail,
            )
            self.roots.append(node)

        # Step 3: recursively fetch children
        self._fetch_children_recursive(self.roots)

        return self.roots

    def _fetch_children_recursive(self, parent_nodes):
        # type: (list) -> None
        """Recursively fetch children for a list of parent nodes.

        Fetches child IDs in batch, then fetches details, creates child nodes,
        and recurses for children that have sub-children.

        :param parent_nodes: list of PredefinedTagNode.
        """
        if not parent_nodes:
            return

        parent_ids = [n.id for n in parent_nodes]
        parent_map = {}  # type: dict
        for n in parent_nodes:
            parent_map[n.id] = n

        # Batch fetch child IDs
        res = self.open_api.depot_get_predefined_tagtree_childtag_ids(
            self.asset_hub, parent_ids
        )
        if not res.is_succeeded():
            raise APIError(
                "Failed to get predefined tagtree child tag ids: %s" % res.error_message()
            )

        items = []
        result = res.result
        if isinstance(result, dict):
            items = result.get("items", [])
        elif isinstance(result, list):
            items = result

        # Collect all child IDs that need detail info
        all_child_ids = []
        # child_id -> (parent_node, child_cnt)
        child_info_map = {}  # type: dict
        for item in items:
            parent_id = item.get("id")
            childs = item.get("childs", [])
            for child in childs:
                child_id = child.get("id")
                child_cnt = child.get("child_cnt", 0)
                all_child_ids.append(child_id)
                child_info_map[child_id] = (parent_map.get(parent_id), child_cnt)

        if not all_child_ids:
            return

        # Batch fetch details for all children
        # Batch fetch child tag details
        res = self.open_api.depot_get_predefined_tagtree_tag_detail(
            self.asset_hub, all_child_ids
        )
        if not res.is_succeeded():
            raise APIError(
                "Failed to get predefined tagtree tag detail: %s" % res.error_message()
            )

        # Parse detail response (child tags return {"items": [...]})
        detail_items = res.result

        # Build detail lookup
        detail_map = {}  # type: dict
        for d in detail_items:
            detail_map[d["id"]] = d

        # Create child nodes and attach to parents
        next_level_parents = []
        for child_id in all_child_ids:
            info = child_info_map.get(child_id)
            if info is None:
                continue
            parent_node, child_cnt = info
            detail = detail_map.get(child_id, {})

            child_node = PredefinedTagNode(
                tag_id=child_id,
                name=detail.get("name", ""),
                parent_id=detail.get("parent_id"),
                tagtree_id=detail.get("tagtree_id"),
                node_type=detail.get("type"),
                child_cnt=child_cnt,
                raw_data=detail,
            )
            if parent_node is not None:
                parent_node.children.append(child_node)

            # If this child has sub-children, mark for next recursion
            if child_cnt > 0:
                next_level_parents.append(child_node)

        # Recurse for next level
        if next_level_parents:
            self._fetch_children_recursive(next_level_parents)

    def find_by_id(self, tag_id):
        # type: (int) -> PredefinedTagNode or None
        """Search for a node by id across all root trees.

        :param tag_id: int. The tag id to search for.
        :return: PredefinedTagNode or None.
        """
        for root in self.roots:
            result = root.find_by_id(tag_id)
            if result is not None:
                return result
        return None

    def find_by_path(self, path, separator="/"):
        # type: (str, str) -> PredefinedTagNode or None
        """Search for a node by its unique path string.

        Tag names can be duplicated, but paths are unique.

        :param path: str. The tag path. Example: "root/child/leaf" or "root > child > leaf".
        :param separator: str. Path separator. Default is "/", also supports " > ".
        :return: PredefinedTagNode or None.
        """
        if not path:
            return None
        
        path_parts = [p.strip() for p in path.split(separator) if p.strip()]
        if not path_parts:
            return None
        
        # First part is the root name
        root_name = path_parts[0]
        remaining_parts = path_parts[1:]
        
        # Find matching root
        for root in self.roots:
            if root.name == root_name:
                if not remaining_parts:
                    return root
                return root._find_by_path_parts(remaining_parts)
        
        return None

    def find_all_by_name(self, name):
        # type: (str) -> list
        """Search for all nodes matching the given name.

        Note: Tag names can be duplicated. Use find_by_path for unique lookup.

        :param name: str. The tag name to search for.
        :return: list of PredefinedTagNode. May contain multiple nodes with same name.
        """
        results = []
        for root in self.roots:
            results.extend(root.find_all_by_name(name))
        return results

    def get_node_path(self, tag_id, separator="/"):
        # type: (int, str) -> str
        """Get the full path string for a given tag id.

        :param tag_id: int. The tag id.
        :param separator: str. Path separator. Default is "/".
        :return: str. Path string. Example: "root/child/leaf", or empty string if not found.
        """
        path_parts = []
        node = self.find_by_id(tag_id)
        while node is not None:
            path_parts.append(node.name)
            if node.parent_id is not None:
                node = self.find_by_id(node.parent_id)
            else:
                break
        path_parts.reverse()
        return separator.join(path_parts)

    def add_tags(self, tag_ids, asset_ids=None, directory_ids=None):
        # type: (list, list, list) -> object
        """Add predefined tags to assets and/or directories.

        :param tag_ids: list<int>. Predefined tag ids to add.
        :param asset_ids: list<int>. File asset ids (optional).
        :param directory_ids: list<int>. Directory ids (optional).
        :return: APIResponse.
        :raises APIError: if the API call fails.
        """
        res = self.open_api.depot_batch_add_asset_predefined_tag(
            self.asset_hub,
            predefined_tag_ids=tag_ids,
            asset_ids=asset_ids,
            directory_ids=directory_ids,
        )
        if not res.is_succeeded():
            raise APIError("Failed to add predefined tags: %s" % res.error_message())
        return res

    def remove_tags(self, tag_ids, asset_ids=None, directory_ids=None, del_all_tags=False):
        # type: (list, list, list, bool) -> object
        """Remove predefined tags from assets and/or directories.

        :param tag_ids: list<int>. Predefined tag ids to remove.
        :param asset_ids: list<int>. File asset ids (optional).
        :param directory_ids: list<int>. Directory ids (optional).
        :param del_all_tags: bool. If True, remove all predefined tags.
        :return: APIResponse.
        :raises APIError: if the API call fails.
        """
        res = self.open_api.depot_batch_del_asset_predefined_tags(
            self.asset_hub,
            predefined_tag_ids=tag_ids,
            asset_ids=asset_ids,
            directory_ids=directory_ids,
            del_all_tags=del_all_tags,
        )
        if not res.is_succeeded():
            raise APIError("Failed to remove predefined tags: %s" % res.error_message())
        return res

    def get_asset_tags(self, asset_id):
        # type: (int) -> list
        """Get all predefined tag mappings for a given asset.

        :param asset_id: int. The asset id to query.
        :return: list of dict. Each dict contains tag_id, asset_id, tagtree_id, etc.
        :raises APIError: if the API call fails.
        """
        res = self.open_api.depot_get_predefined_tag_mapping(
            self.asset_hub, asset_id
        )
        if not res.is_succeeded():
            raise APIError(
                "Failed to get predefined tag mapping: %s" % res.error_message()
            )
        result = res.result
        if isinstance(result, dict):
            return result.get("items", [])
        if isinstance(result, list):
            return result
        return []

    def print_tree(self):
        # type: () -> None
        """Print the tag tree structure to stdout for debugging."""
        if not self.roots:
            print("(empty tree - call fetch_all() first)")
            return
        for root in self.roots:
            self._print_node(root, indent=0)

    def _print_node(self, node, indent=0):
        # type: (PredefinedTagNode, int) -> None
        """Recursively print a single node and its children."""
        prefix = "  " * indent + "- "
        extra = ""
        if node.color:
            extra = " [%s]" % node.color
        print("%s%s (id=%s)%s" % (prefix, node.name, node.id, extra))
        for child in node.children:
            self._print_node(child, indent + 1)
