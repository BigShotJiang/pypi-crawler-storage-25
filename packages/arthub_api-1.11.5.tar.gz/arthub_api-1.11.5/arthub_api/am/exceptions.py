# -*- coding: utf-8 -*-
"""AM SDK 异常类"""
from __future__ import absolute_import, print_function, unicode_literals


class AMAPIError(Exception):
    """AM API 错误基类"""
    pass


class AMConnectionError(AMAPIError):
    """连接错误"""
    pass


class AMAuthError(AMAPIError):
    """认证错误"""
    pass


class AMNotFoundError(AMAPIError):
    """资源不存在"""
    pass


class AMValidationError(AMAPIError):
    """数据验证错误"""
    pass
