# -*- coding: utf-8 -*-
"""AM API 会话管理"""
from __future__ import absolute_import, print_function, unicode_literals

import os

from ..open_api import OpenAPI
from ..config import api_config_oa
from .exceptions import AMAPIError
from .node import _NODE_TYPE_MAP, Node
from ._internal.cache import NodeCache
from ._internal.loader import PropertyLoader
from ._internal.schema import SchemaManager
from ._internal.event_manager import EventManager
from .module import ModuleManager
from .workflow import WorkflowManager


class Session(object):
    """AM API 会话
    
    Session 是使用 AM SDK 的入口，负责管理连接、缓存和全局配置。
    
    Example:
        # 推荐方式：通过 OpenAPI 实例初始化
        from arthub_api import OpenAPI
        from arthub_api.config import api_config_oa
        
        open_api = OpenAPI(api_config_oa)
        open_api.set_public_token('your-public-token')
        session = Session(open_api, asset_hub='your-asset-hub')
        
        # 或者使用环境变量
        import os
        os.environ['ARTHUB_ASSET_HUB'] = 'your-asset-hub'
        session = Session(open_api)
        
        # 访问项目
        project = session.project
        for version in project.versions:
            for task in version.tasks:
                print(task.properties.get('name'))
                
        # 查询 Module
        modules = session.modules
        lang_mod = session.find_module(display_name='语言')
        
        # 查询 Schema
        schema = session.schemas['name']
        print(schema['display_name'])
    """
    
    def __init__(self, open_api, asset_hub=None, cache_enabled=True, sub_instance_name=None):
        # type: (OpenAPI, object, bool, object) -> None
        """初始化 Session
        
        Args:
            open_api: OpenAPI 实例，用于与 ArtHub 服务器通信
                     需要先调用 open_api.set_public_token() 设置认证令牌
            asset_hub: Asset Hub 名称，默认从 ARTHUB_ASSET_HUB 环境变量读取
            cache_enabled: 是否启用 Node 实例缓存，默认为 True
            sub_instance_name: 子实例名称，用于区分商业化和非商业化请求。
                传入 'business' 表示访问商业化 AM 实例，
                传入 None 或空字符串表示访问非商业化实例（默认）。
                设置后，所有 AM API 请求的 HTTP header 中会自动携带
                ``arthub-sub-instance-name`` 字段。
            
        Example:
            # 创建并初始化 Session
            from arthub_api import OpenAPI
            from arthub_api.config import api_config_oa
            
            open_api = OpenAPI(api_config_oa)
            open_api.set_public_token('your-public-token')
            session = Session(open_api, asset_hub='your-asset-hub')
            
            # 或者使用环境变量
            import os
            os.environ['ARTHUB_ASSET_HUB'] = 'your-asset-hub'
            session = Session(open_api)
            
            # 访问商业化 AM 实例
            session = Session(open_api, asset_hub='your-asset-hub', sub_instance_name='business')
        """
        # 底层 API
        self._open_api = open_api
        self._asset_hub = asset_hub or os.getenv('ARTHUB_ASSET_HUB')
        
        # Set sub-instance header for commercial/non-commercial distinction
        if sub_instance_name:
            self._open_api.set_am_sub_instance_name(sub_instance_name)
        
        # 内部组件
        self._cache = NodeCache() if cache_enabled else None
        self._loader = PropertyLoader(self._open_api, self._asset_hub)
        self.schemas = SchemaManager(self._open_api, self._asset_hub)
        
        # Module 缓存 (类似属性枚举)
        self._modules = None
        
        # Workflow 缓存 (工作流定义)
        self._workflows = None
        
        # WebSocket 事件管理器
        self._event_manager = None
        
    # ========== 核心 API ==========
    
    @property
    def project(self):
        # type: () -> object
        """获取当前 asset_hub 的根 Project
        
        Returns:
            Project: 项目根节点
            
        Raises:
            AMAPIError: 获取失败
        """
        project_id = self._get_project_root_id()
        return self._get_or_create_node('Project', project_id)
        
    @property
    def modules(self):
        # type: () -> ModuleManager
        """获取模块管理器
        
        Returns:
            ModuleManager: 模块管理器，提供查询和访问模块定义的功能
            
        Example:
            # 获取所有模块
            all_modules = session.modules.all()
            for mod in all_modules:
                print("{} - {}".format(mod.name, mod.display_name))
            
            # 通过 name 访问（字典式）
            module = session.modules['e3729496-2c09-553a-8c4a-854d0e3c0b96']
            
            # 查找模块
            module = session.modules.find(display_name='模型')
            
            # 按排序索引排序
            sorted_modules = session.modules.sorted()
            
            # 搜索模块
            results = session.modules.search('模型')
        """
        if self._modules is None:
            self._modules = ModuleManager(self._open_api, self._asset_hub)
        return self._modules

    @property
    def workflows(self):
        # type: () -> WorkflowManager
        """获取工作流管理器
        
        Returns:
            WorkflowManager: 工作流管理器，提供查询和访问工作流定义的功能
            
        Example:
            # 获取所有工作流
            all_workflows = session.workflows.all()
            for wf in all_workflows:
                print("{} - {}".format(wf.id, wf.display_name))
            
            # 通过 ID 访问（字典式）
            workflow = session.workflows[120347699877335]
            
            # 安全获取（不存在返回 None）
            workflow = session.workflows.get(workflow_id)
            
            # 查找工作流
            workflow = session.workflows.find(display_name='基础工作流')
            workflow = session.workflows.find(name='am_default_workflow')
            
            # 迭代所有工作流
            for wf in session.workflows:
                print(wf.display_name)
                for state in wf.states:
                    print("  - {}".format(state.display_name))
        """
        if self._workflows is None:
            self._workflows = WorkflowManager(self._open_api, self._asset_hub)
        return self._workflows

    @property
    def open_api(self):
        # type: () -> OpenAPI
        """返回底层 OpenAPI 客户端，便于直接调用低层接口（如 get_account_detail）"""
        return self._open_api
    
    @property
    def events(self):
        # type: () -> EventManager
        """WebSocket 事件管理器
        
        用于订阅和处理 AM 的实时事件（创建、更新、删除、移动等）。
        
        Returns:
            EventManager: 事件管理器实例
        
        Example:
            # 订阅任务创建事件
            def on_task_created(event):
                print("创建了任务: %s" % event.target.node_name)
            
            session.events.on_create(on_task_created, node_types=['Entity'])
            session.events.connect()
            
            # 订阅属性更新事件
            def on_deadline_changed(event):
                for target in event.targets:
                    if target.updated_field_name == 'estimate_end_date':
                        print("截止日期改变了")
            
            session.events.on_update(
                on_deadline_changed,
                fields=['estimate_end_date']
            )
        """
        if self._event_manager is None:
            self._event_manager = EventManager(self)
        return self._event_manager

    def find_module(self, name=None, display_name=None):
        # type: (object, object) -> object
        """查找 Module
        
        Args:
            name: Module 名称 (ID)
            display_name: Module 显示名称
            
        Returns:
            Module: Module 对象或 None
            
        Example:
            mod = session.find_module(display_name='模型')
            if mod:
                print(mod.name)          # module 的实际 ID
                print(mod.display_name)  # '模型'
                print(mod['name'])       # 也支持字典式访问
        """
        return self.modules.find(name=name, display_name=display_name)
        
    def preload(self, nodes):
        # type: (list) -> None
        """批量预加载节点属性（内部方法）
        
        Note:
            SDK 已在 version.tasks、filter_tasks() 等方法中自动调用此方法，
            用户无需手动调用。
        
        Args:
            nodes: Node 列表（Project/Version/Task）
        """
        if not nodes:
            return
            
        # 批量加载属性
        node_ids = [n.id for n in nodes]
        results = self._loader.load_node_properties(node_ids)
        
        # 将结果分配给各个节点
        for i, node in enumerate(nodes):
            if i < len(results):
                node_info = results[i]
                # 保留树形元数据（如 _depth、_tree_path 等）
                tree_meta = {k: v for k, v in node._raw.items() if k.startswith('_')}
                # 更新为完整的 API 响应
                node._raw.update(node_info)
                # 恢复树形元数据
                node._raw.update(tree_meta)
        
    def preload_selected(self, nodes, properties, expand_references=False):
        # type: (list, list, bool) -> None
        """按需批量预加载节点的指定属性（内部方法）
        
        与 preload() 不同，此方法只加载指定的属性，返回精简的 Node 对象。
        Node 只保留以下字段：
        - 基本字段: name, id, node_type, parentId
        - 树形元数据: _depth, _tree_path, _children_count, _is_match_filter 等
        - selected_props 中指定的属性（提升到第一层）
        
        When ``expand_references=True``, raw IDs are replaced with richer
        representations.  See :mod:`arthub_api.am.types` for the full
        type definitions.  Summary:
        
        - Person fields (editor=personEditor) -> PersonDetail dict or list[PersonDetail]
        - module field -> Module object
        - workflow_id field -> WorkflowDetail dict
        - workflow_state field -> WorkflowStateDetail dict
        - Dropdown / enum fields -> EnumOption dict or list[EnumOption]
        - File / image fields (schema.file_meta) -> list[FileInfo]
        
        Note:
            SDK 在 filter_tasks(properties=...) 中自动调用此方法，
            用户无需手动调用。
            
        Args:
            nodes: Node 列表（Project/Version/Task）
            properties: 需要获取的属性名列表，如 ["linked_preview_id", "linked_progress_id"]
            expand_references: 是否展开引用型字段（人员、模块、工作流、工作流状态、
                枚举、文件），默认 False。展开后各字段的数据结构详见
                :mod:`arthub_api.am.types`
        """
        if not nodes or not properties:
            return
            
        node_ids = [n.id for n in nodes]
        
        # 请求基本属性 + 用户指定的属性
        basic_props = ['name', 'type', 'parent']
        all_props = list(set(basic_props + properties))
        results = self._loader.load_node_selected_properties(node_ids, all_props)
        
        # 将结果分配给各个节点，精简 _raw
        for i, node in enumerate(nodes):
            if i < len(results):
                node_info = results[i]
                if not isinstance(node_info, dict):
                    continue
                    
                # 保留树形元数据（如 _depth、_tree_path、_parent_task、_tree_children 等）
                tree_meta = {k: v for k, v in node._raw.items() if k.startswith('_')}
                
                # 获取 API 返回的 properties 字典
                api_props = node_info.get('properties', {})
                
                # 构建精简的 _raw
                slim_raw = {
                    'node_type': node._raw.get('node_type', api_props.get('type', 'Unknown')),
                }
                
                # 基本属性放入 properties
                slim_raw['properties'] = {
                    'name': api_props.get('name'),
                    'type': api_props.get('type'),
                    'parent': api_props.get('parent'),
                }
                
                # selected_props 提升到第一层
                for prop_name in properties:
                    slim_raw[prop_name] = api_props.get(prop_name)
                
                # 恢复树形元数据
                slim_raw.update(tree_meta)
                
                # 替换（而非 update）_raw
                node._raw.clear()
                node._raw.update(slim_raw)
                
                # 标记为精简模式，阻止 __getitem__ 自动 _populate
                node._selected_mode = True
        
        # 展开引用型字段
        if expand_references:
            self._expand_property_references(nodes, properties)
        
    def _expand_property_references(self, nodes, properties):
        # type: (list, list) -> None
        """展开引用型字段的 ID 为详细信息对象
        
        根据 Schema 信息和字段名称，自动识别并展开以下引用：
        
        1. 人员型字段 (editor='personEditor')
           str -> PersonDetail dict, list[str] -> list[PersonDetail]
        2. 模块字段 (key='module')
           str(UUID) -> Module object
        3. 工作流字段 (key='workflow_id')
           int -> WorkflowDetail dict
        4. 工作流状态字段 (key='workflow_state')
           int -> WorkflowStateDetail dict
        5. 下拉选择类字段 (editor 为 dropdownEditor/dropdownMultiSelectEditor/
           treeDropdownEditor/treeDropdownMultiSelectEditor/
           listDropdownEditor/listDropdownMultiSelectEditor)
           str -> EnumOption dict, list[str] -> list[EnumOption]
        6. 文件型字段 (schema.file_meta 非空)
           -> list[FileInfo] (via get-file-brief API)
        
        All type definitions are documented in :mod:`arthub_api.am.types`.
        
        Args:
            nodes: Node 列表
            properties: 用户指定的属性名列表
        """
        if not nodes or not properties:
            return
        
        _DROPDOWN_EDITORS = {
            'dropdownEditor', 'dropdownMultiSelectEditor',
            'treeDropdownEditor', 'treeDropdownMultiSelectEditor',
            'listDropdownEditor', 'listDropdownMultiSelectEditor',
        }
        
        # 识别需要展开的字段
        person_fields = []
        dropdown_fields = {}  # {field_name: display_name_map}
        file_meta_fields = {}  # {field_name: file_meta}
        has_module = 'module' in properties
        has_workflow_id = 'workflow_id' in properties
        has_workflow_state = 'workflow_state' in properties
        
        for prop_name in properties:
            schema = self.schemas.get(prop_name)
            if not schema:
                continue
            # 检查 file_meta
            file_meta = schema.get('file_meta', '')
            if file_meta:
                file_meta_fields[prop_name] = file_meta
                continue
            editor = schema.get('editor', '')
            if editor == 'personEditor':
                person_fields.append(prop_name)
            elif editor in _DROPDOWN_EDITORS:
                range_info = schema.get('range') or {}
                display_name_map = range_info.get('display_name') or {}
                if display_name_map and isinstance(display_name_map, dict):
                    dropdown_fields[prop_name] = display_name_map
        
        # 1. 展开人员型字段
        if person_fields:
            self._expand_person_fields(nodes, person_fields)
        
        # 2. 展开模块字段
        if has_module:
            self._expand_module_fields(nodes)
        
        # 3. 展开工作流字段
        if has_workflow_id:
            self._expand_workflow_id_fields(nodes)
        
        # 4. 展开工作流状态字段（需要 workflow_id 信息）
        if has_workflow_state:
            self._expand_workflow_state_fields(nodes, properties)
        
        # 5. 展开下拉选择类字段
        if dropdown_fields:
            self._expand_dropdown_fields(nodes, dropdown_fields)
        
        # 6. 展开文件型字段（schema.file_meta 非空）
        if file_meta_fields:
            self._expand_file_meta_fields(nodes, file_meta_fields)
    
    def _expand_person_fields(self, nodes, person_fields):
        # type: (list, list) -> None
        """展开人员型字段：收集所有 account_name，批量查询，写回详情
        
        Single-value fields are replaced with a PersonDetail dict;
        multi-value fields become list[PersonDetail].  If the account is
        not found, a fallback ``{"account_name": <original>}`` is used.
        
        See :mod:`arthub_api.am.types` — ``PersonDetail``.
        
        Args:
            nodes: Node 列表
            person_fields: 人员型字段名列表
        """
        # 收集所有需要查询的 account_name（去重）
        all_account_names = set()
        for node in nodes:
            for field_name in person_fields:
                value = node._raw.get(field_name)
                if isinstance(value, list):
                    for name in value:
                        if name:
                            all_account_names.add(name)
                elif isinstance(value, str) and value:
                    all_account_names.add(value)
        
        if not all_account_names:
            return
        
        # 批量查询用户详情
        _PERSON_KEEP_FIELDS = {'nick_name', 'account_name', 'icon_url', 'department', 'qywx_name', 'qywx_alias'}
        account_details = {}
        try:
            res = self._open_api.check_account_if_exist(list(all_account_names))
            if res.is_succeeded():
                raw = res.result if isinstance(res.result, dict) else {}
                account_details = {
                    k: {f: v.get(f) for f in _PERSON_KEEP_FIELDS if f in v}
                    for k, v in raw.items() if isinstance(v, dict)
                }
        except Exception:
            pass
        
        # 写回展开后的详情
        for node in nodes:
            for field_name in person_fields:
                value = node._raw.get(field_name)
                if isinstance(value, list) and value:
                    expanded = []
                    for name in value:
                        detail = account_details.get(name)
                        if detail and isinstance(detail, dict):
                            expanded.append(detail)
                        else:
                            expanded.append({'account_name': name})
                    node._raw[field_name] = expanded
                elif isinstance(value, str) and value:
                    detail = account_details.get(value)
                    if detail and isinstance(detail, dict):
                        node._raw[field_name] = detail
                    else:
                        node._raw[field_name] = {'account_name': value}
    
    def _expand_dropdown_fields(self, nodes, dropdown_fields):
        # type: (list, dict) -> None
        """展开下拉选择类字段：将 ID 替换为 EnumOption 字典
        
        通过 schema.range.display_name 映射表，将选项 ID 转换为
        ``{"id": ..., "display_name": ...}`` 字典。
        单选字段 -> EnumOption dict；多选字段 -> list[EnumOption]。
        
        See :mod:`arthub_api.am.types` — ``EnumOption``.
        
        Args:
            nodes: Node 列表
            dropdown_fields: {field_name: display_name_map} 映射
                display_name_map 格式: {"-1-1-1": "哈哈", "-1-1-2": "哇哇"}
        """
        for node in nodes:
            for field_name, display_name_map in dropdown_fields.items():
                value = node._raw.get(field_name)
                if isinstance(value, list):
                    expanded = []
                    for v in value:
                        if isinstance(v, str) and v in display_name_map:
                            expanded.append({'id': v, 'display_name': display_name_map[v]})
                        else:
                            expanded.append(v)
                    node._raw[field_name] = expanded
                elif isinstance(value, str) and value:
                    if value in display_name_map:
                        node._raw[field_name] = {'id': value, 'display_name': display_name_map[value]}
    
    def _expand_module_fields(self, nodes):
        # type: (list) -> None
        """展开 module 字段：将模块 UUID 替换为 Module 对象
        
        If the UUID is not found in ModuleManager, the raw string is kept.
        
        See :mod:`arthub_api.am.types` — ``Module``.
        
        Args:
            nodes: Node 列表
        """
        for node in nodes:
            module_id = node._raw.get('module')
            if not module_id:
                continue
            module = self.modules.get(module_id)
            if module is not None:
                node._raw['module'] = module
    
    def _expand_workflow_id_fields(self, nodes):
        # type: (list) -> None
        """展开 workflow_id 字段：将工作流 ID 替换为 WorkflowDetail 字典
        
        Expanded dict contains: id, display_name, apply_types, transition.
        Each element in ``transition`` is a TransitionDetail dict.
        
        See :mod:`arthub_api.am.types` — ``WorkflowDetail``, ``TransitionDetail``.
        
        Args:
            nodes: Node 列表
        """
        for node in nodes:
            wf_id = node._raw.get('workflow_id')
            if wf_id is None:
                continue
            workflow = self.workflows.get(wf_id)
            if workflow is not None:
                node._raw['workflow_id'] = {
                    'id': workflow.id,
                    'display_name': workflow.display_name,
                    'apply_types': workflow._data.get('apply_types', []),
                    'transition': workflow.transitions,
                }
    
    def _expand_workflow_state_fields(self, nodes, properties):
        # type: (list, list) -> None
        """展开 workflow_state 字段：将状态 ID 替换为 WorkflowStateDetail 字典
        
        Expanded dict contains: id, display_name, type, workflow_id.
        If ``workflow_id`` is not in the requested properties, it is loaded
        automatically to resolve the state.
        
        See :mod:`arthub_api.am.types` — ``WorkflowStateDetail``.
        
        Args:
            nodes: Node 列表
            properties: 用户指定的属性名列表
        """
        has_workflow_id = 'workflow_id' in properties
        
        # 如果 workflow_id 不在已请求的属性中，需要额外加载
        if not has_workflow_id:
            nodes_needing_wf_id = [n for n in nodes 
                                    if n._raw.get('workflow_state') is not None 
                                    and not isinstance(n._raw.get('workflow_state'), dict)]
            if nodes_needing_wf_id:
                node_ids = [n.id for n in nodes_needing_wf_id]
                wf_results = self._loader.load_node_selected_properties(
                    node_ids, ['workflow_id']
                )
                for i, node in enumerate(nodes_needing_wf_id):
                    if i < len(wf_results):
                        wf_info = wf_results[i]
                        if isinstance(wf_info, dict):
                            wf_props = wf_info.get('properties', {})
                            node._raw['_loaded_workflow_id'] = wf_props.get('workflow_id')
        
        for node in nodes:
            state_id = node._raw.get('workflow_state')
            if state_id is None:
                continue
            
            # 获取 workflow_id：优先从已有属性取，否则从额外加载的字段取
            wf_id = node._raw.get('workflow_id')
            # 如果 workflow_id 已被展开为 dict，取其 id
            if isinstance(wf_id, dict):
                wf_id = wf_id.get('id')
            elif hasattr(wf_id, 'id'):
                wf_id = wf_id.id
            if wf_id is None:
                wf_id = node._raw.get('_loaded_workflow_id')
            
            if wf_id is None:
                continue
            
            workflow = self.workflows.get(wf_id)
            if workflow is None:
                continue
            
            state = workflow.get_state_by_id(state_id)
            if state is not None:
                node._raw['workflow_state'] = {
                    'id': state.id,
                    'display_name': state.display_name,
                    'type': state.type,
                    'workflow_id': wf_id,
                }
        
        # 清理临时字段
        for node in nodes:
            node._raw.pop('_loaded_workflow_id', None)
    
    def _expand_file_meta_fields(self, nodes, file_meta_fields):
        # type: (list, dict) -> None
        """展开文件型字段：通过 get-file-brief 获取任务关联的文件信息
        
        Each field is replaced with ``list[FileInfo]``.  All node × meta
        combinations are batched into a single API call.  When
        file_meta is ``'deliverable'``, ``only_main_version=True`` is set.
        
        See :mod:`arthub_api.am.types` — ``FileInfo``.
        
        Args:
            nodes: Node 列表
            file_meta_fields: {field_name: file_meta} 映射，
                例如 {"linked_preview_id": "preview", "linked_progress_id": "process_image"}
        """
        if not nodes or not file_meta_fields:
            return
        
        # 反向映射: {meta: [field_name, ...]}
        meta_to_fields = {}
        for field_name, meta in file_meta_fields.items():
            meta_to_fields.setdefault(meta, []).append(field_name)
        
        # 构造 items：每个 node × 每种 meta 一条
        items = []
        for node in nodes:
            for meta in meta_to_fields:
                items.append({
                    "id": node.id,
                    "meta": meta,
                    "only_main_version": meta == 'deliverable',
                })
        
        if not items:
            return
        
        try:
            res = self._open_api.am_get_file_by_meta_and_task_id(
                self._asset_hub, items
            )
            if not res.is_succeeded():
                return
            
            result_list = res.result if isinstance(res.result, list) else []
            
            # 通过 item.id 找到 node，通过 item.meta 找到对应的 field_name，写入 item.files
            node_map = {n.id: n for n in nodes}
            for item in result_list:
                if not isinstance(item, dict):
                    continue
                item_id = item.get('id')
                item_meta = item.get('meta')
                if item_id is None or item_meta is None:
                    continue
                
                node = node_map.get(item_id)
                if node is None:
                    continue
                
                # 通过 meta 找到对应的 field_name 列表
                field_names = meta_to_fields.get(item_meta)
                if not field_names:
                    continue
                
                files = item.get('files', [])
                for field_name in field_names:
                    node._raw[field_name] = files
                
        except Exception:
            pass
    
    # ========== 内部方法 ==========
        
    def _get_project_root_id(self):
        # type: () -> int
        """获取项目根 ID
        
        Returns:
            int: 项目 ID
            
        Raises:
            AMAPIError: 获取失败
        """
        res = self._open_api.am_get_project_root_id(self._asset_hub)
        if not res.is_succeeded():
            raise AMAPIError("Failed to get project root: {}".format(res.error_message()))
        return res.result
        
    def _get_or_create_node(self, sdk_type, node_id, data=None):
        # type: (str, int, object) -> Node
        """从缓存获取或创建 Node
        
        Args:
            sdk_type: SDK 节点类型 ('Project', 'Version', 'Task')
            node_id: 节点 ID
            data: 初始数据（可包含 AM 的 node_type 字段）
            
        Returns:
            Node: Node 实例
            
        Note:
            - sdk_type 决定创建哪个类（Project/Version/Task）
            - data['node_type'] 存储 AM 的实际类型（'Entity', 'Stage' 等）
            - 对于 Task，data['node_type'] 可以是 'Entity' 或 'Stage'
        """
        if self._cache:
            node = self._cache.get(sdk_type, node_id)
            if node:
                # 更新数据（如果提供了新数据）
                if data:
                    node._raw.update(data)
                return node
                
        node_class = _NODE_TYPE_MAP.get(sdk_type, Node)
        node = node_class(self, node_id, data)
        
        if self._cache:
            self._cache.put(sdk_type, node_id, node)
        return node
