# -*- coding: utf-8 -*-
"""事件数据模型"""
from __future__ import print_function

import json
from datetime import datetime
from enum import Enum

# ========== 操作类型 ==========

class Operation(Enum):
    """操作类型"""
    CREATE_NODE = "create-node"
    DELETE_NODE = "delete-node"
    MOVE_NODE = "move-node"
    UPDATE_PROPERTY = "update-property"

# ========== 基础结构 ==========

class Who(object):
    """谁"""
    def __init__(self, account_name, account_id):
        # type: (str, int) -> None
        self.account_name = account_name
        self.account_id = account_id

class When(object):
    """何时"""
    def __init__(self, timestamp):
        # type: (int) -> None
        self.timestamp = timestamp
    
    @property
    def datetime(self):
        # type: () -> datetime
        return datetime.fromtimestamp(self.timestamp / 1e9)

class Where(object):
    """何处"""
    def __init__(self, depot_id, depot_name, service_name):
        # type: (int, str, str) -> None
        self.depot_id = depot_id
        self.depot_name = depot_name
        self.service_name = service_name

# ========== Target ==========

class Target(object):
    """目标对象
    
    统一的 Target 类，根据操作类型动态添加相应属性：
    - update-property: 添加 updated_field_* 属性
    - move-node: 添加 parent 和 source 属性
    """
    def __init__(self, node_id, node_name, node_type, node_type_display_name,
                 path_ids, path_names, path_types, raw_data=None):
        # type: (int, str, str, str, list, list, list, object) -> None
        self.node_id = node_id
        self.node_name = node_name
        self.node_type = node_type
        self.node_type_display_name = node_type_display_name
        self.path_ids = path_ids
        self.path_names = path_names
        self.path_types = path_types
        self.raw_data = raw_data or {}
        
        # 动态添加 update-property 相关属性
        if 'updated_field_name' in self.raw_data:
            self.updated_field_name = self._parse_value(self.raw_data['updated_field_name'])
            self.updated_field_display_name = self._parse_value(self.raw_data.get('updated_field_display_name'))
            self.updated_field_old_value = self._parse_value(self.raw_data.get('updated_field_old_value'))
            self.updated_field_new_value = self._parse_value(self.raw_data.get('updated_field_new_value'))
        
        # 动态添加 move-node 相关属性
        if '_relations' in self.raw_data:
            self._parse_relations()
    
    def _parse_value(self, value):
        # type: (object) -> object
        """统一解析：去外层引号 + 尝试 JSON 解析"""
        if value is None:
            return None
        
        # 如果不是字符串，直接返回
        if not isinstance(value, str):
            return value
        
        # 去掉外层引号（如果有）
        if len(value) >= 2 and value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        
        # 尝试 JSON 解析
        try:
            return json.loads(value)
        except (ValueError, TypeError):
            # 不是 JSON，返回字符串
            return value
    
    def _parse_relations(self):
        # type: () -> None
        """解析移动节点的关系"""
        self.parent = None
        self.source = None
        relations = self.raw_data.get('_relations', [])
        for rel in relations:
            rel_type = rel.get('relation')
            rel_target = rel.get('target', {}).get('asset_matrix', {})
            
            if rel_type == 'parent':
                self.parent = Relation(
                    relation_type='parent',
                    node_id=rel_target.get('parent_node_id'),
                    node_name=rel_target.get('parent_node_name'),
                    node_type=rel_target.get('parent_node_type')
                )
            elif rel_type == 'source':
                self.source = Relation(
                    relation_type='source',
                    node_id=rel_target.get('source_node_id'),
                    node_name=rel_target.get('source_node_name'),
                    node_type=rel_target.get('source_node_type'),
                    path_ids=rel_target.get('path_ids'),
                    path_names=rel_target.get('path_names')
                )
    
    def get(self, key, default=None):
        # type: (str, object) -> object
        """访问任意字段"""
        return self.raw_data.get(key, default)
    
    @property
    def path(self):
        # type: () -> str
        """完整路径（用 / 连接）
        
        Example: 'ProjectName/VersionName/TaskName'
        """
        return '/'.join(self.path_names)
    
    # ========== 便捷访问 Path 信息 ==========
    
    @property
    def project_id(self):
        # type: () -> object
        """项目 ID（path 中的第一个节点）
        
        Returns:
            int or None: 项目 ID，如果 path 为空则返回 None
        """
        return self.path_ids[0] if len(self.path_ids) > 0 else None
    
    @property
    def project_name(self):
        # type: () -> object
        """项目名称（path 中的第一个节点）
        
        Returns:
            str or None: 项目名称，如果 path 为空则返回 None
        """
        return self.path_names[0] if len(self.path_names) > 0 else None
    
    @property
    def version_id(self):
        # type: () -> object
        """版本 ID（path 中的第二个节点）
        
        Returns:
            int or None: 版本 ID，如果 path 长度不足则返回 None
        """
        return self.path_ids[1] if len(self.path_ids) > 1 else None
    
    @property
    def version_name(self):
        # type: () -> object
        """版本名称（path 中的第二个节点）
        
        Returns:
            str or None: 版本名称，如果 path 长度不足则返回 None
        
        Example:
            >>> print(target.version_name)
            '266'
        """
        return self.path_names[1] if len(self.path_names) > 1 else None
    
    @property
    def parent_path(self):
        # type: () -> str
        """父路径（不包含当前节点）
        
        Returns:
            str: 父路径，用 / 连接
        
        Example:
            >>> print(target.parent_path)
            'ProjectName/VersionName'
        """
        if len(self.path_names) > 1:
            return '/'.join(self.path_names[:-1])
        return ''

# ========== 关系对象 ==========

class Relation(object):
    """节点关系"""
    def __init__(self, relation_type, node_id, node_name, node_type,
                 path_ids=None, path_names=None):
        # type: (str, int, str, str, object, object) -> None
        self.relation_type = relation_type
        self.node_id = node_id
        self.node_name = node_name
        self.node_type = node_type
        self.path_ids = path_ids
        self.path_names = path_names

# ========== 事件 ==========

class Event(object):
    """事件"""
    def __init__(self, cmd, event_id, timestamp, session_id,
                 who, when, where, operation, targets, raw_data=None):
        # type: (str, str, str, str, Who, When, Where, Operation, list, object) -> None
    # 元数据
        self.cmd = cmd
        self.event_id = event_id
        self.timestamp = timestamp
        self.session_id = session_id
    
    # 5W
        self.who = who
        self.when = when
        self.where = where
        self.operation = operation
        self.targets = targets # list of Target objects
    
    # 原始数据
        self.raw_data = raw_data or {}
    
    @property
    def target(self):
        # type: () -> object
        """主要 target（第一个），用于简单场景
        
        Returns:
            Target or None: 第一个 target，如果没有 targets 则返回 None
        
        Example:
            >>> print(event.target.node_name)
            'TaskName'
        """
        return self.targets[0] if self.targets else None
    
    @property
    def updated_fields(self):
        # type: () -> list
        """返回所有被更新的字段名列表（仅对 update-property 操作有效）
        
        Returns:
            list: 字段名列表，如 ['estimate_end_date', 'artist']
        
        Example:
            >>> print(event.updated_fields)
            ['estimate_end_date', 'artist']
        """
        if self.operation != Operation.UPDATE_PROPERTY:
            return []
        
        fields = []
        for target in self.targets:
            if hasattr(target, 'updated_field_name') and target.updated_field_name:
                fields.append(target.updated_field_name)
        return fields
    
    # ========== 便捷访问（从第一个 target 获取常用信息）==========
    
    @property
    def project_name(self):
        # type: () -> object
        """项目名称（从第一个 target 获取）
        
        Returns:
            str or None: 项目名称
        
        Example:
            >>> print(event.project_name)
            'MyProject'
        """
        return self.target.project_name if self.target else None
    
    @property
    def version_name(self):
        # type: () -> object
        """版本名称（从第一个 target 获取）
        
        Returns:
            str or None: 版本名称
        
        Example:
            >>> print(event.version_name)
            '266'
        """
        return self.target.version_name if self.target else None

# ========== Target工厂 ==========

class TargetFactory(object):
    """创建不同类型的Target"""
    
    @staticmethod
    def create(operation, data):
        # type: (Operation, dict) -> Target
        """创建 Target 实例
        
        Target 类会根据 raw_data 自动添加相应的动态属性
        """
        return Target(
            node_id=data.get('node_id', 0),
            node_name=data.get('node_name', ''),
            node_type=data.get('node_type', ''),
            node_type_display_name=data.get('node_type_display_name', ''),
            path_ids=data.get('path_ids', []),
            path_names=data.get('path_names', []),
            path_types=data.get('path_types', []),
            raw_data=data
        )