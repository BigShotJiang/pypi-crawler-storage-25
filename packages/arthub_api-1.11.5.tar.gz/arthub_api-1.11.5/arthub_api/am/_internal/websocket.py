"""WebSocket客户端"""
from __future__ import print_function

import json
import threading
import uuid
from collections import defaultdict
import logging

try:
    import websocket
    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False
    websocket = None

from .event import Event, Operation, Who, When, Where, TargetFactory
from .event_filter import EventFilter

logger = logging.getLogger(__name__)

class WebSocketClient:
    """WebSocket客户端
    
    支持的操作类型：
    - create-node: 创建节点
    - delete-node: 删除节点
    - move-node: 移动节点
    - update-property: 更新属性
    
    其他类型的 WebSocket 消息（如系统内部事件）会被自动过滤。
    """
    
    def __init__(self, url: str, depot_name: str, ticket: str):
        if not HAS_WEBSOCKET:
            raise ImportError(
                "websocket-client is required for WebSocket support. "
                "Install it with: pip install websocket-client"
            )
        
        self.url = url
        self.depot_name = depot_name
        self.ticket = ticket
        self.ws = None
        self.connected = False
        
        self.handlers = defaultdict(list)
        self.global_handlers = []
        
        self._stop = False
        self._thread = None
    
    def connect(self):
        """连接"""
        # 生成 agentId (类似 JS 代码中的 uuid())
        agent_id = str(uuid.uuid4())
        
        # 构建 WebSocket URL（参数顺序：agentId, ticket, depot）
        ws_url = "{}/conn?agentId={}&ticket={}&depot={}".format(
            self.url, agent_id, self.ticket, self.depot_name
        )
        
        # 调试信息（隐藏完整 ticket）
        safe_ticket = str(self.ticket)[:20] if self.ticket else ""
        safe_url = "{}/conn?agentId={}&ticket={}...&depot={}".format(
            self.url, agent_id, safe_ticket, self.depot_name
        )
        logger.info("Connecting to: {}".format(safe_url))
        
        self.ws = websocket.WebSocketApp(
            ws_url,
            on_open=self._on_open,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close
        )
        
        self._thread = threading.Thread(target=self.ws.run_forever, daemon=True)
        self._thread.start()
    
    def disconnect(self):
        """断开"""
        self._stop = True
        if self.ws:
            self.ws.close()
    
    def _on_open(self, ws):
        self.connected = True
        logger.info("WebSocket connected")
    
    def _on_close(self, ws, code, msg):
        self.connected = False
        logger.info("WebSocket closed")
    
    def _on_error(self, ws, error):
        logger.error("WebSocket error: {}".format(error))
    
    def _on_message(self, ws, message):
        """处理消息"""
        try:
            data = json.loads(message)
            
            # 1. 过滤非本仓库消息 (case-insensitive comparison)
            depot = data.get('body', {}).get('content', {}).get('where', {}).get('depot_name')
            if depot is None or depot.lower() != self.depot_name.lower():
                return
            
            # 2. 检查是否是支持的操作类型（通过 Operation 枚举验证）
            operation_str = data.get('body', {}).get('content', {}).get('what', {}).get('operation', '')
            try:
                Operation(operation_str)
            except ValueError:
                logger.debug("Skipped unsupported operation: '{}', cmd: {}".format(
                    operation_str, data.get('cmd')
                ))
                return

            # 3. 解析并分发事件
            event = self._parse_event(data)
            self._dispatch(event)
            
        except Exception as e:
            logger.error("Failed to process message: {}".format(e), exc_info=True)
    
    def _parse_event(self, data: dict) -> Event:
        """解析事件"""
        content = data['body']['content']
        
        who = Who(
            account_name=content['who']['account_name'],
            account_id=content['who']['account_id']
        )
        
        when = When(timestamp=content['when']['time'])
        
        where = Where(
            depot_id=content['where']['depot_id'],
            depot_name=content['where']['depot_name'],
            service_name=content['where']['service_name']
        )
        
        operation = Operation(content['what']['operation'])
        
        targets = []
        for t in content['what']['targets']:
            if 'asset_matrix' in t.get('target', {}):
                am_data = t['target']['asset_matrix']
                target = TargetFactory.create(operation, am_data)
                targets.append(target)
        
        return Event(
            cmd=data['cmd'],
            event_id=data['id'],
            timestamp=data['ts'],
            session_id=data['sessionId'],
            who=who,
            when=when,
            where=where,
            operation=operation,
            targets=targets,
            raw_data=data
        )
    
    def _dispatch(self, event: Event):
        """分发事件"""
        for callback, filter_ in self.global_handlers:
            if filter_.match(event):
                try:
                    callback(event)
                except Exception as e:
                    logger.error("Handler error: {}".format(e), exc_info=True)
        
        for callback, filter_ in self.handlers.get(event.operation, []):
            if filter_.match(event):
                try:
                    callback(event)
                except Exception as e:
                    logger.error("Handler error: {}".format(e), exc_info=True)
    
    # ========== 订阅API ==========
    
    def on(self, operation: Operation, callback: object, 
           filter_: object = None):
        """订阅特定操作"""
        filter_ = filter_ or EventFilter()
        self.handlers[operation].append((callback, filter_))
        return self
    
    def on_all(self, callback: object, filter_: object = None):
        """订阅所有事件"""
        filter_ = filter_ or EventFilter()
        self.global_handlers.append((callback, filter_))
        return self
    
    # ========== 便捷方法 ==========
    
    def on_create(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅创建事件
        
        Args:
            callback: 回调函数
            filter_: 可选的 EventFilter 对象
        
        Example:
            # 无过滤
            session.events.on_create(callback)
            
            # 使用 EventFilter
            session.events.on_create(callback, EventFilter(node_types=['Entity']))
        """
        return self.on(Operation.CREATE_NODE, callback, filter_)
    
    def on_delete(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅删除事件
        
        Args:
            callback: 回调函数
            filter_: 可选的 EventFilter 对象
        
        Example:
            session.events.on_delete(callback, EventFilter(node_types=['Entity']))
        """
        return self.on(Operation.DELETE_NODE, callback, filter_)
    
    def on_move(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅移动事件
        
        Args:
            callback: 回调函数
            filter_: 可选的 EventFilter 对象
        
        Example:
            session.events.on_move(callback, EventFilter(move_to_ids=[123]))
        """
        return self.on(Operation.MOVE_NODE, callback, filter_)
    
    def on_update(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅更新事件
        
        Args:
            callback: 回调函数
            filter_: 可选的 EventFilter 对象
        
        Example:
            session.events.on_update(callback, EventFilter(updated_fields=['artist']))
        """
        return self.on(Operation.UPDATE_PROPERTY, callback, filter_)