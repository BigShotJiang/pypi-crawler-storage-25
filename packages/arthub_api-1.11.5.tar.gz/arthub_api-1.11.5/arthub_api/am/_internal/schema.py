# -*- coding: utf-8 -*-
"""属性 Schema 管理"""
from __future__ import absolute_import, print_function, unicode_literals


class SchemaManager(object):
    """管理 Property Schema
    
    负责加载和查询属性的元信息（display_name, type_name, editor 等）。
    提供多种查询方式：字典访问、搜索、精确查找、过滤。
    
    Example:
        schemas = SchemaManager(open_api, asset_hub)
        
        # 字典访问
        schema = schemas['name']
        
        # 搜索
        results = schemas.search('文件')
        
        # 精确查找
        schema = schemas.find(display_name='0730文件型')
        
        # 过滤列表
        file_props = schemas.list(editor='fileSelectorEditor')
    """
    
    def __init__(self, open_api, asset_hub):
        # type: (object, str) -> None
        """初始化并加载 Schema
        
        Args:
            open_api: OpenAPI 实例
            asset_hub: Asset Hub 名称
        """
        self._schemas = {}  # type: dict
        self._display_name_index = {}  # type: dict
        self._load_schemas(open_api, asset_hub)
        
    def _load_schemas(self, open_api, asset_hub):
        # type: (object, str) -> None
        """从服务器加载 Schema"""
        result = open_api.am_get_all_properties(asset_hub)
        if result.is_succeeded():
            # result.result 返回的是列表，取第一个元素
            data = result.result[0] if result.result else {}
            properties = data.get('properties', {})
            
            for field_id, payload in properties.items():
                # 提取关键信息
                schema = {
                    'id': field_id,
                    'display_name': payload.get('display_name', ''),
                    'type_name': payload.get('type_name', 'string'),
                    'default_value': payload.get('default_value'),
                    'editor': payload.get('editor', ''),
                    'scope': [s.get('object_type') for s in payload.get('scope', [])],
                    'range': payload.get('range', {}),
                    'is_custom': payload.get('is_custom', False),
                    'is_read_only': payload.get('is_read_only', False),
                    'file_meta': payload.get('file_meta', ''),
                }
                
                self._schemas[field_id] = schema
                
                # 建立 display_name 索引
                if schema['display_name']:
                    self._display_name_index[schema['display_name']] = field_id
                    
    def __getitem__(self, field_id):
        # type: (str) -> dict
        """字典式访问 Schema
        
        Args:
            field_id: 属性 ID
            
        Returns:
            dict: Schema 字典
            
        Raises:
            KeyError: 如果属性不存在
        """
        if field_id not in self._schemas:
            raise KeyError("Property '{}' not found".format(field_id))
        return self._schemas[field_id]
        
    def get(self, field_id, default=None):
        # type: (str, object) -> object
        """安全获取 Schema
        
        Args:
            field_id: 属性 ID
            default: 默认值
            
        Returns:
            Schema 字典或默认值
        """
        return self._schemas.get(field_id, default)
        
    def search(self, keyword):
        # type: (str) -> list
        """搜索 Schema (模糊匹配 display_name)
        
        Args:
            keyword: 搜索关键字
            
        Returns:
            list: 匹配的 Schema 列表
            
        Example:
            file_schemas = schemas.search('文件')
            for schema in file_schemas:
                print(schema['display_name'])
        """
        keyword_lower = keyword.lower()
        results = []
        for schema in self._schemas.values():
            if keyword_lower in schema['display_name'].lower():
                results.append(schema)
        return results
        
    def find(self, display_name=None, **filters):
        # type: (object, object) -> list
        """精确查找 Schema（返回所有匹配）
        
        Args:
            display_name: 显示名称（精确匹配）
            **filters: 其他过滤条件（editor, scope, type_name 等）
            
        Returns:
            list: 匹配的 Schema 列表（可能为空、单个或多个）
            
        Example:
            # 查找"负责人"字段
            schemas = session.schemas.find(display_name='负责人')
            
            if not schemas:
                print("未找到'负责人'字段")
            elif len(schemas) == 1:
                # 唯一匹配，直接使用
                field_id = schemas[0]['id']
                artists = task[field_id]
            else:
                # 多个匹配，需要进一步筛选
                print("找到 {} 个'负责人'字段:".format(len(schemas)))
                for s in schemas:
                    print("  - {} (editor: {}, scope: {})".format(
                        s['id'], s['editor'], s['scope']
                    ))
                
                # 方法1: 按 editor 筛选
                person_fields = [s for s in schemas if s['editor'] == 'personEditor']
                if person_fields:
                    field_id = person_fields[0]['id']
                
                # 方法2: 组合条件直接查找（推荐）
                schemas = session.schemas.find(
                    display_name='负责人',
                    editor='personEditor',
                    scope='Entity'
                )
                if schemas:
                    field_id = schemas[0]['id']
        """
        results = []
        
        for schema in self._schemas.values():
            # 检查 display_name（精确匹配）
            if display_name and schema['display_name'] != display_name:
                continue
                
            # 检查其他过滤条件
            match = True
            for key, value in filters.items():
                if key == 'scope':
                    # scope 是列表，检查是否包含
                    if value not in schema.get('scope', []):
                        match = False
                        break
                elif schema.get(key) != value:
                    match = False
                    break
            
            if match:
                results.append(schema)
        
        return results
        
    def list(self, **filters):
        # type: (object) -> list
        """过滤 Schema 列表
        
        Args:
            **filters: 过滤条件
            
        Returns:
            list: 匹配的 Schema 列表
            
        Example:
            # 获取所有文件选择器
            file_selectors = schemas.list(editor='fileSelectorEditor')
            
            # 获取所有 Entity 可用的属性
            entity_props = schemas.list(scope='Entity')
        """
        results = []
        for schema in self._schemas.values():
            match = True
            for key, value in filters.items():
                if key == 'scope':
                    if value not in schema.get('scope', []):
                        match = False
                        break
                elif schema.get(key) != value:
                    match = False
                    break
            if match:
                results.append(schema)
        return results
        
    def __len__(self):
        # type: () -> int
        """Schema 总数"""
        return len(self._schemas)
        
    def keys(self):
        # type: () -> list
        """返回所有属性 ID (field_id) 列表
        
        Returns:
            list: 属性 ID 列表，例如 ['name', 'artist', '00ee543c-4a24-51f2-be90-0bc6416c15ef', ...]
            
        Example:
            # 列举所有属性
            for field_id in session.schemas.keys():
                schema = session.schemas[field_id]
                print("{}: {}".format(field_id, schema['display_name']))
        """
        return list(self._schemas.keys())
        
    def all(self):
        # type: () -> list
        """返回所有 Schema 列表
        
        Returns:
            list: Schema 字典列表
            
        Example:
            # 列举所有属性的详细信息
            for schema in session.schemas.all():
                print("{} - {} ({})".format(
                    schema['display_name'],
                    schema['id'][:8] + '...',
                    schema['type_name']
                ))
        """
        return list(self._schemas.values())
