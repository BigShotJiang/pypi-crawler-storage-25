# -*- coding: utf-8 -*-
"""事件管理器 - 封装 WebSocket 连接和事件订阅"""
from __future__ import print_function

import logging

try:
    from .websocket import WebSocketClient
    HAS_WEBSOCKET = True
except ImportError:
    WebSocketClient = None
    HAS_WEBSOCKET = False

from .event import Operation
from .event_filter import EventFilter

logger = logging.getLogger(__name__)


class EventManager:
    """事件管理器
    
    提供统一的 WebSocket 事件管理接口，封装连接、订阅等操作。
    
    Example:
        session = Session()
        
        # 订阅事件
        session.events.on_create(callback, node_types=['Entity'])
        session.events.on_update(callback, fields=['estimate_end_date'])
        
        # 连接
        session.events.connect()
        
        # 断开
        session.events.disconnect()
    """
    
    def __init__(self, session):
        """初始化事件管理器
        
        Args:
            session: AM Session 实例
        """
        self._session = session
        self._client = None
        self._ws_url = None
        self._is_connected = False
    
    # ========== 连接管理 ==========
    
    def connect(self, ws_url=None):
        # type: (object) -> None
        """连接 WebSocket
        
        Args:
            ws_url: WebSocket URL，默认从配置中获取
                   格式: 'ws://domain.com' 或 'wss://domain.com'
        
        Example:
            # 方式 1: 使用默认 URL（从 API 配置推断）
            session.events.connect()
            
            # 方式 2: 指定 URL
            session.events.connect('wss://arthub.example.com')
        
        Raises:
            ImportError: 如果 websocket-client 未安装
        """
        if not HAS_WEBSOCKET:
            raise ImportError(
                "WebSocket support requires 'websocket-client' package.\n"
                "Install it with:\n"
                "  pip install websocket-client          # For Python 3\n"
                "  pip install 'websocket-client<1.0'    # For Python 2.7"
            )
        
        if self._is_connected and self._client:
            logger.warning("WebSocket already connected")
            return
        
        # 获取 WebSocket URL
        if ws_url:
            self._ws_url = ws_url
        else:
            self._ws_url = self._get_default_ws_url()
        
        # 获取 ticket
        ticket = self._get_ticket()
        
        # 获取 depot_name（格式：AssetHub_{asset_hub}）
        asset_hub = self._session._asset_hub
        depot_name = "AssetHub_{}".format(asset_hub)
        
        # 调试信息
        logger.info("WebSocket connecting to {}".format(self._ws_url))
        logger.info("Depot: {}".format(depot_name))
        if ticket:
            safe_ticket = str(ticket)[:20] if ticket else ""
            logger.info("Ticket: {}...".format(safe_ticket))
        else:
            logger.info("Ticket: No ticket")
        
        # 创建 WebSocket 客户端并连接
        self._client = WebSocketClient(
            url=self._ws_url,
            depot_name=depot_name,
            ticket=ticket
        )
        self._client.connect()
        self._is_connected = True
    
    def disconnect(self):
        """断开 WebSocket 连接"""
        if self._client:
            self._client.disconnect()
            self._is_connected = False
            logger.info("WebSocket disconnected")
    
    @property
    def is_connected(self):
        # type: () -> bool
        """是否已连接"""
        return self._is_connected and self._client and self._client.connected
    
    # ========== 便捷订阅方法 ==========
    
    def on_create(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅节点创建事件
        
        Args:
            callback: 回调函数，接收 Event 参数
            filter_: 可选的 EventFilter 对象
        
        Returns:
            self: 支持链式调用
        
        Example:
            # 无过滤
            session.events.on_create(callback)
            
            # 使用 EventFilter
            filter_ = EventFilter(node_types=['Entity'])
            session.events.on_create(callback, filter_)
            
            # 复杂过滤
            filter_ = EventFilter(
                node_types=['Entity'],
                version_names=['266']
            )
            session.events.on_create(callback, filter_)
        
        Note:
            请先调用 connect() 建立连接，再订阅事件
        """
        if self._client is None:
            raise RuntimeError("Please call connect() before subscribing to events")
        self._client.on_create(callback, filter_)
        return self
    
    def on_delete(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅节点删除事件
        
        Args:
            callback: 回调函数，接收 Event 参数
            filter_: 可选的 EventFilter 对象
        
        Returns:
            self: 支持链式调用
        
        Example:
            # 无过滤
            session.events.on_delete(callback)
            
            # 使用 EventFilter
            session.events.on_delete(callback, EventFilter(node_types=['Entity']))
        
        Note:
            请先调用 connect() 建立连接，再订阅事件
        """
        if self._client is None:
            raise RuntimeError("Please call connect() before subscribing to events")
        self._client.on_delete(callback, filter_)
        return self
    
    def on_move(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅节点移动事件
        
        Args:
            callback: 回调函数，接收 Event 参数
            filter_: 可选的 EventFilter 对象
        
        Returns:
            self: 支持链式调用
        
        Example:
            # 无过滤
            session.events.on_move(callback)
            
            # 使用 EventFilter
            session.events.on_move(callback, EventFilter(move_to_ids=[123456]))
        
        Note:
            请先调用 connect() 建立连接，再订阅事件
        """
        if self._client is None:
            raise RuntimeError("Please call connect() before subscribing to events")
        self._client.on_move(callback, filter_)
        return self
    
    def on_update(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅属性更新事件
        
        Args:
            callback: 回调函数，接收 Event 参数
            filter_: 可选的 EventFilter 对象
        
        Returns:
            self: 支持链式调用
        
        Example:
            # 无过滤
            session.events.on_update(callback)
            
            # 使用 EventFilter
            filter_ = EventFilter(updated_fields=['estimate_end_date'])
            session.events.on_update(callback, filter_)
            
            # 组合多个条件
            filter_ = EventFilter(
                updated_fields=['estimate_end_date', 'artist'],
                node_types=['Entity'],
                version_names=['266']
            )
            session.events.on_update(callback, filter_)
        
        Note:
            请先调用 connect() 建立连接，再订阅事件
        """
        if self._client is None:
            raise RuntimeError("Please call connect() before subscribing to events")
        self._client.on_update(callback, filter_)
        return self
    
    def on_all(self, callback, filter_=None):
        # type: (object, object) -> object
        """订阅所有事件
        
        Args:
            callback: 回调函数，接收 Event 参数
            filter_: 可选的事件过滤器
        
        Returns:
            self: 支持链式调用
        
        Example:
            def log_all_events(event):
                print("[{}] {}".format(event.operation.value, event.who.account_name))
                print("  影响了 {} 个目标".format(len(event.targets)))
            
            session.events.on_all(log_all_events)
        
        Note:
            请先调用 connect() 建立连接，再订阅事件
        """
        if self._client is None:
            raise RuntimeError("Please call connect() before subscribing to events")
        self._client.on_all(callback, filter_)
        return self
    
    def on(self, operation, callback, filter_=None):
        # type: (object, object, object) -> object
        """订阅特定操作类型（高级用法）
        
        Args:
            operation: 操作类型 (Operation.CREATE_NODE 等)
            callback: 回调函数
            filter_: 可选的事件过滤器
        
        Returns:
            self: 支持链式调用
        
        Example:
            from arthub_api.am._internal.event import Operation
            from arthub_api.am._internal.event_filter import EventFilter
            
            filter_ = EventFilter(
                node_types=['Entity'],
                match_mode='any'
            )
            
            session.events.on(Operation.UPDATE_PROPERTY, callback, filter_)
        
        Note:
            请先调用 connect() 建立连接，再订阅事件
        """
        if self._client is None:
            raise RuntimeError("Please call connect() before subscribing to events")
        self._client.on(operation, callback, filter_)
        return self
    
    # ========== 内部方法 ==========
    
    def _get_default_ws_url(self):
        # type: () -> str
        """从 Session 的 API 配置动态构建 WebSocket URL
        
        根据 Session 初始化时传入的 api_config 自动推断 WebSocket URL，
        确保 WebSocket 连接与 HTTP API 使用相同的域名配置。
        
        Returns:
            str: WebSocket URL (格式: wss://host 或 ws://host)
        
        Example:
            # api_config_oa -> wss://service.arthub.woa.com
            # api_config_qq -> wss://service.arthub.qq.com
            # api_config_public -> wss://api.arthubdam.com
            # api_config_oa_test -> ws://arthub-service-test.woa.com
        """
        # 从 Session 的 OpenAPI 配置中读取
        config = self._session._open_api._config
        scheme = config.get('web_socket_scheme', 'wss:').rstrip(':')
        host = config.get('host', 'service.arthub.woa.com')
        
        # 构建 WebSocket URL
        return "{}://{}".format(scheme, host)
    
    def _get_ticket(self):
        # type: () -> str
        """获取 WebSocket ticket
        
        Returns:
            str: ticket 字符串
        
        Note:
            调用 OpenAPI 的 get_ticket() 方法获取 WebSocket 专用的 ticket
        """
        # 调用 API 获取 ticket
        try:
            result = self._session._open_api.get_ticket()
            if result.is_succeeded():
                ticket = result.result
                # ticket 可能是列表，需要取第一个元素
                if isinstance(ticket, list) and len(ticket) > 0:
                    ticket = ticket[0]
                logger.debug("Got WebSocket ticket: {}...".format(ticket[:20]))
                return ticket
            else:
                logger.error("Failed to get ticket: {}".format(result.error_message()))
        except Exception as e:
            logger.error("Error getting ticket: {}".format(e))
        
        # 降级方案：使用 public_token
        logger.warning("Falling back to public_token as ticket")
        if hasattr(self._session._open_api, '_public_token'):
            return self._session._open_api._public_token
        
        # 最后方案：从环境变量获取
        import os
        token = os.getenv('ARTHUB_PUBLIC_TOKEN', '')
        
        if not token:
            logger.warning("No ticket/token found, WebSocket may fail to connect")
        
        return token

