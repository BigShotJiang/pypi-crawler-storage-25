# -*- coding: utf-8 -*-
"""Expanded property field type definitions.

When ``expand_references=True`` is passed to ``preload_selected`` (or
``filter_tasks`` / ``filter_task_tree`` with ``properties=...``), the SDK
replaces raw IDs with richer dict / object representations.  This module
documents the shape of each expanded value so that callers know exactly
what keys to expect.

All "types" below are plain Python dicts (or SDK objects).  They are
described here for documentation purposes – the SDK does **not** perform
runtime type enforcement.

Example::

    tree = version.filter_task_tree(
        filter_dsl, count=-1,
        properties=['creator', 'module', 'workflow_id',
                    'workflow_state', 'linked_preview_id',
                    'b1afab8e-939f-5d9d-beb1-6ff1abacffe3'],
    )
    for node in tree:
        # person field -> PersonDetail dict
        creator = node.get('creator')  # type: PersonDetail

        # module field -> Module object
        mod = node.get('module')       # type: Module

        # workflow_id field -> WorkflowDetail dict
        wf = node.get('workflow_id')   # type: WorkflowDetail

        # workflow_state field -> WorkflowStateDetail dict
        ws = node.get('workflow_state')  # type: WorkflowStateDetail

        # dropdown field -> EnumOption dict (single-select) or list
        enum_val = node.get('b1afab8e-...')  # type: EnumOption | list[EnumOption]

        # file field -> list[FileInfo]
        files = node.get('linked_preview_id')  # type: list[FileInfo]
"""
from __future__ import absolute_import, print_function, unicode_literals


# ---------------------------------------------------------------------------
# 1. PersonDetail – expanded person (personEditor) field
# ---------------------------------------------------------------------------
# Original value : str (account_name) or list[str]
# Expanded value : PersonDetail dict or list[PersonDetail]
#
# Example:
#   {
#       "account_name": "kazenzhong",
#       "nick_name": "Kazen Zhong",
#       "icon_url": "https://example.com/avatar.png",
#       "department": "Art/Character",
#       "qywx_alias": "kazenzhong",
#       "qywx_name": "钟某某"
#   }
#
# Fields:
#   account_name  (str)  – login account name (unique identifier)
#   nick_name     (str)  – display nickname
#   icon_url      (str)  – avatar URL
#   department    (str)  – department path, e.g. "Art/Character"
#   qywx_alias    (str)  – WeCom alias
#   qywx_name     (str)  – WeCom display name
#
# Notes:
#   - If the account is not found, a fallback dict with only
#     ``account_name`` populated is returned.
#   - For multi-person fields the value is a list of PersonDetail dicts.
#   - Empty / None values remain as-is (None or 'N/A').

PERSON_DETAIL_FIELDS = (
    'account_name',
    'nick_name',
    'icon_url',
    'department',
    'qywx_alias',
    'qywx_name',
)
"""Fields present in an expanded PersonDetail dict."""


# ---------------------------------------------------------------------------
# 2. Module – expanded module field
# ---------------------------------------------------------------------------
# Original value : str (module UUID, e.g. "e3729496-2c09-553a-8c4a-854d0e3c0b96")
# Expanded value : Module object (from arthub_api.am.module.Module)
#
# Key attributes of the Module object:
#   name          (str)  – module ID (UUID)
#   display_name  (str)  – human-readable name, e.g. "模型"
#   param_index   (int)  – sort index
#   color         (str)  – hex colour, e.g. "#13D1B6"
#   is_custom     (bool) – whether this is a user-defined module
#   pre_modules   (list) – prerequisite module IDs
#   post_modules  (list) – downstream module IDs
#
# Notes:
#   - If the module ID is not found in ModuleManager, the raw UUID string
#     is kept unchanged.
#   - The Module object supports dict-style access: module['display_name'].

MODULE_ATTRIBUTES = (
    'name',
    'display_name',
    'param_index',
    'color',
    'is_custom',
    'pre_modules',
    'post_modules',
)
"""Key attributes of an expanded Module object."""


# ---------------------------------------------------------------------------
# 3. WorkflowDetail – expanded workflow_id field
# ---------------------------------------------------------------------------
# Original value : int (workflow ID)
# Expanded value : WorkflowDetail dict
#
# Example:
#   {
#       "id": 120347699877335,
#       "display_name": "基础工作流",
#       "apply_types": ["Entity", "Stage", "OutsourcedEntity"],
#       "transition": [
#           {
#               "name": "规划中-实现中",
#               "display_name": "评审通过",
#               "previous": 120347699877336,
#               "next": 120347699877337,
#               "transition_id": 120347699877340,
#               "previous_state_graph_id": "...",
#               "next_state_graph_id": "...",
#               "graph_transition_id": "..."
#           },
#           ...
#       ]
#   }
#
# Fields:
#   id            (int)                   – workflow ID
#   display_name  (str)                   – workflow display name
#   apply_types   (list[str])             – applicable node types
#   transition    (list[TransitionDetail]) – state-transition rules

WORKFLOW_DETAIL_FIELDS = (
    'id',
    'display_name',
    'apply_types',
    'transition',
)
"""Fields present in an expanded WorkflowDetail dict."""


# ---------------------------------------------------------------------------
# 3a. TransitionDetail – each element inside WorkflowDetail.transition
# ---------------------------------------------------------------------------
# Example:
#   {
#       "name": "规划中-实现中",
#       "display_name": "评审通过",
#       "previous": 120347699877336,
#       "next": 120347699877337,
#       "transition_id": 120347699877340,
#       "previous_state_graph_id": "sgn-xxxxxxxx",
#       "next_state_graph_id": "sgn-yyyyyyyy",
#       "graph_transition_id": "sgt-zzzzzzzz"
#   }
#
# Fields:
#   name                     (str) – transition name, e.g. "规划中-实现中"
#   display_name             (str) – human-readable label, e.g. "评审通过"
#   previous                 (int) – source state ID
#   next                     (int) – target state ID
#   transition_id            (int) – transition ID
#   previous_state_graph_id  (str) – source state graph ID
#   next_state_graph_id      (str) – target state graph ID
#   graph_transition_id      (str) – graph transition ID

TRANSITION_DETAIL_FIELDS = (
    'name',
    'display_name',
    'previous',
    'next',
    'transition_id',
    'previous_state_graph_id',
    'next_state_graph_id',
    'graph_transition_id',
)
"""Fields present in a TransitionDetail dict."""


# ---------------------------------------------------------------------------
# 4. WorkflowStateDetail – expanded workflow_state field
# ---------------------------------------------------------------------------
# Original value : int (state ID)
# Expanded value : WorkflowStateDetail dict
#
# Example:
#   {
#       "id": 120347699877337,
#       "display_name": "实现中",
#       "type": "进行中",
#       "workflow_id": 120347699877335
#   }
#
# Fields:
#   id            (int) – state ID
#   display_name  (str) – state display name, e.g. "实现中"
#   type          (str) – state category, e.g. "未开始" / "进行中" / "已暂停" / "已完成"
#   workflow_id   (int) – parent workflow ID
#
# Notes:
#   - If ``workflow_id`` is not in the requested properties, the SDK
#     automatically loads it to resolve the state detail.

WORKFLOW_STATE_DETAIL_FIELDS = (
    'id',
    'display_name',
    'type',
    'workflow_id',
)
"""Fields present in an expanded WorkflowStateDetail dict."""


# ---------------------------------------------------------------------------
# 5. EnumOption – expanded dropdown / tree-dropdown / list-dropdown field
# ---------------------------------------------------------------------------
# Original value : str (option ID like "-1-1-1") or list[str]
# Expanded value : EnumOption dict or list[EnumOption]
#
# Example (single-select):
#   {
#       "id": "-1-1-1",
#       "display_name": "浅蓝色"
#   }
#
# Example (multi-select):
#   [
#       {"id": "-1-1-1", "display_name": "浅蓝色"},
#       {"id": "-1-1-2", "display_name": "深红色"}
#   ]
#
# Fields:
#   id            (str) – option ID (path-style, e.g. "-1-1-1")
#   display_name  (str) – human-readable label
#
# Supported editors (single-select):
#   dropdownEditor, treeDropdownEditor, listDropdownEditor
# Supported editors (multi-select):
#   dropdownMultiSelectEditor, treeDropdownMultiSelectEditor,
#   listDropdownMultiSelectEditor
#
# Notes:
#   - If the option ID is not found in schema.range.display_name,
#     the raw value is kept unchanged.

ENUM_OPTION_FIELDS = (
    'id',
    'display_name',
)
"""Fields present in an expanded EnumOption dict."""


# ---------------------------------------------------------------------------
# 6. FileInfo – expanded file / image field (schema.file_meta is non-empty)
# ---------------------------------------------------------------------------
# Original value : (varies – the SDK ignores the raw value)
# Expanded value : list[FileInfo]  (always a list, may be empty)
#
# Example:
#   [
#       {
#           "node_id": 123456789,
#           "name": "design_v2.png",
#           "asset_id": 987654321,
#           "preview_url": "https://cdn.example.com/preview/design_v2.png",
#           "display_url": "https://cdn.example.com/display/design_v2.png",
#           ...
#       }
#   ]
#
# Common fields (from the ``get-file-brief`` API):
#   node_id       (int) – file node ID
#   name          (str) – file name
#   asset_id      (int) – asset ID in storage
#   preview_url   (str) – thumbnail / preview image URL
#   display_url   (str) – full-resolution display URL
#
#   Additional fields may be returned by the API; the SDK passes them
#   through as-is.
#
# file_meta mapping (field_name -> file_meta value):
#   linked_preview_id  -> "preview"          (description images)
#   linked_progress_id -> "process_image"    (progress images)
#   deliverable_v2     -> "deliverable"      (deliverables, main version only)
#
# Notes:
#   - When file_meta is "deliverable", the request includes
#     ``only_main_version=True`` so only main-version files are returned.
#   - If a task has no associated files, an empty list ``[]`` is returned.
#   - Network errors are silently caught; the field remains unchanged.

FILE_INFO_COMMON_FIELDS = (
    'node_id',
    'name',
    'asset_id',
    'preview_url',
    'display_url',
)
"""Common fields present in a FileInfo dict (additional API fields may exist)."""


# ---------------------------------------------------------------------------
# Quick-reference table
# ---------------------------------------------------------------------------
#
# Schema / Key              | Editor                          | Expanded Type
# --------------------------|---------------------------------|-----------------------------
# creator, artist, apm, ... | personEditor                    | PersonDetail or list[PersonDetail]
# module                    | (key-based)                     | Module object
# workflow_id               | (key-based)                     | WorkflowDetail dict
# workflow_state            | (key-based)                     | WorkflowStateDetail dict
# (custom enum single)      | dropdownEditor                  | EnumOption dict
# (custom enum single)      | treeDropdownEditor              | EnumOption dict
# (custom enum single)      | listDropdownEditor              | EnumOption dict
# (custom enum multi)       | dropdownMultiSelectEditor       | list[EnumOption]
# (custom enum multi)       | treeDropdownMultiSelectEditor   | list[EnumOption]
# (custom enum multi)       | listDropdownMultiSelectEditor   | list[EnumOption]
# linked_preview_id         | (file_meta="preview")           | list[FileInfo]
# linked_progress_id        | (file_meta="process_image")     | list[FileInfo]
# deliverable_v2            | (file_meta="deliverable")       | list[FileInfo]
