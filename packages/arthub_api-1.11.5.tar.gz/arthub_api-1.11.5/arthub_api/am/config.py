# -*- coding: utf-8 -*-
"""AM 模块配置常量"""
from __future__ import absolute_import, print_function, unicode_literals


# 分页配置
AM_DEFAULT_PAGE_SIZE = 100  # 默认每页大小，用于 get-node-child-as-tree-id-in-range 接口
