# -*- coding: utf-8 -*-
"""
arthub_api.open_api
~~~~~~~~~~~~~~

This module encapsulates the ArtHub OpenAPI.
For detailed interface doc: "https://arthub.aa.com/user_manual/index.html"
"""
from contextlib import contextmanager
import copy
import requests
from . import utils
from . import models
from . import _internal_utils
from . import exception
from . import arthub_api_config
from .config import api_config_oa
from .utils import get_config_by_name, logger
import os
import json


def _node_query_metas(simplified_meta=True):
    metas = [
        "name",
        "file_format",
        "node_type",
        "permission_mask",
        "direct_child_count",
        "capacity",
        "parent_id"
    ]
    if not simplified_meta:
        metas += [
            "full_path_id",
            "full_path_name",
            "confirmed_asset_id",
            "preview_url",
            "status",
            "crc64",
            "updated_date",
            "description",
            "total_leaf_count"
            "last_modifier"
        ]
    return metas


class APIError(Exception):
    pass


class NotLoginError(Exception):
    pass


class NoPermissionError(Exception):
    pass


class APIResponse(object):
    def __init__(self, http_response, network_connection_failed=False):
        self._http_response = http_response
        self._network_connection_failed = network_connection_failed
        self._direct_result = None

        self.api_result_code = -9999
        self.api_item_result_code = -9999
        self.api_error_message = "Unknown"
        self.api_alarm_infos = []
        self.results = {}
        self.errors = {}
        self.exception = None

        self._preprocess()

    def _preprocess(self):
        if self._network_connection_failed:
            return
        if self._http_response is None:
            return
        if not self._http_response.ok:
            logger.error("[API] request \"%s\" failed, code: %d" % (
                self._http_response.url, self._http_response.status_code))
            return
        try:
            # parse api response
            _data = self._http_response.json()
            # parse result code
            self.api_result_code = _data.get("code", self.api_result_code)
            # parse alarm infos if present
            alarm_infos = _data.get("alarm_infos") or []
            self.api_alarm_infos = list(alarm_infos) if isinstance(alarm_infos, (list, tuple)) else []
            # parse result
            self.parse_items(_data.get("result"), self.results)
            # parse error
            self.parse_items(_data.get("error"), self.errors)
            # parse error message
            self._parse_error()
            if type(self.results) == dict:
                self._direct_result = list(self.results.values())

        except Exception as e:
            self.exception = e
            logger.error("[API] parsing response exception, \"%s\"" % self._http_response.text)

    def _parse_error(self):
        if not self.errors:
            return
        e = self.errors.get(next(iter(self.errors)))
        if e is None:
            return
        if type(e) is not dict:
            self.api_error_message = e
        else:
            item_message = e.get("message")
            item_error_code = e.get("error_code")
            if item_message is not None:
                self.api_error_message = item_message
            if item_error_code is not None:
                self.api_item_result_code = item_error_code

    @property
    def url(self):
        if self._http_response is None:
            return ""
        return self._http_response.url

    @property
    def direct_result(self):
        return self._direct_result

    @property
    def result(self):
        return self._direct_result

    def first_result(self, key=None):
        if not self.is_succeeded():
            return None
        if key:
            return self.results.get(0).get(key)
        else:
            return self.results.get(0)

    def set_result_by_key(self, result_key):
        if self.is_succeeded():
            self._direct_result = self.first_result(result_key)

    def set_result(self, result):
        self._direct_result = result

    def set_result_as_first_item(self):
        r = self.first_result()
        if r is not None:
            self._direct_result = r

    @staticmethod
    def parse_items(items_in, items_out):
        if items_in is None:
            return
        t = type(items_in)
        # example: "result": 123
        if t != list and t != dict:
            items_out[0] = items_in
            return

        items_list = []
        if t == list:
            # example: "result": []
            items_list = items_in
        else:
            items_ = items_in.get("items")
            if type(items_) == list:
                # example: "result": {"items": []}
                items_list = items_
            else:
                # example: "result": {}
                items_out[0] = items_in
                return

        for i, item in enumerate(items_list):
            if type(item) != dict:
                items_out[i] = item
                continue
            param_index = item.get("param_index")
            if type(param_index) == int:
                items_out[param_index] = item
            else:
                items_out[i] = item

    def is_http_request_succeeded(self):
        if not self._http_response:
            return False
        return True

    # def is_succeeded(self):
    #     r"""Batch call, all return success.
    #     """

    #     if not self.is_http_request_succeeded():
    #         return False
    #     return self.api_result_code == 0

    def is_succeeded(self):
        r"""Batch call, all return success.
        """

        if not self.is_http_request_succeeded():
            return False
        # 0: success, 1: partial success
        return self.api_result_code == 0 or self.api_result_code == 1

    def is_partial_succeeded(self):
        r"""Batch call, partial success.
        """

        if not self.is_http_request_succeeded():
            return False
        return self.api_result_code == 1

    def is_api_authentication_failed(self):
        r"""Authentication failed.
        """

        if not self.is_http_request_succeeded():
            return False
        return self.api_result_code == -1

    def is_no_permission(self):
        r"""No access to target node, please contact the administrator.
        """

        if not self.is_http_request_succeeded():
            return False
        return self.api_result_code == -19 or self.api_item_result_code == -19

    def is_node_not_exist(self):
        r"""Node does not exist.
        """

        if not self.is_http_request_succeeded():
            return False
        return self.api_result_code == -10 or self.api_item_result_code == -10

    def is_account_not_exist(self):
        r"""User does not exist.
        """

        if not self.is_http_request_succeeded():
            return False
        return self.api_result_code == -6

    def error_message(self):
        if self._network_connection_failed:
            return "network connection failed"
        if not self._http_response.ok:
            return "http request failed, code: %d" % self._http_response.status_code
        if self.is_succeeded():
            return "no error"
        if self.is_api_authentication_failed():
            message = "authentication failed"
        elif self.is_no_permission():
            message = "no permission"
        elif self.is_node_not_exist():
            message = "node not exist"
        else:
            message = self.api_error_message

        parts = ["code=%s" % self.api_result_code, message]
        if self.api_item_result_code not in (-9999, None):
            parts.insert(1, "item_code=%s" % self.api_item_result_code)
        if self.api_alarm_infos:
            parts.append("alarm_infos=%s" % self.api_alarm_infos)
        return ", ".join(parts)

    def raise_for_err(res):
        if res.exception is not None:
            raise res.exception
        if not res._http_response.ok:
            raise APIError("http request failed, code: %d" % res._http_response.status_code)
        if not res.is_succeeded():
            if res.is_api_authentication_failed():
                raise NotLoginError("authentication failed")
            if res.is_no_permission():
                raise NoPermissionError("no permission")
            raise APIError("err from api {0}".format(res.api_error_message))


class OpenAPI(object):
    def __init__(self, config=api_config_oa,
                 get_token_from_cache=True,
                 api_config_name=None,
                 apply_blade_env=True):
        r"""Used to call ArtHub openapi.
        for detailed interface doc: "https://arthub.qq.com/user_manual/index.html"

        :param config: from arthub_api.config.
        :param get_token_from_cache: read token from local cache.
        """
        if api_config_name:
            config = get_config_by_name(api_config_name)
        self._config = config
        self._token = ""
        self._public_token = ""
        self._cookies = None
        self._api_version_depot = "v2"
        self._api_version_explorer = "v2"
        self._api_version_am = "v1"
        self._api_sdk_segment_am = "sdk"
        self._api_version_gateway = "v2"
        self._api_version_account = "v3"
        self._cached_account_name = ""
        self._cached_password = ""
        self._cached_business_type = "default"
        self._cached_terminal_type = "default"
        self._auto_login = False
        self._current_account_info = None
        self._in_blade_env = False
        self._am_sub_instance_name = ""
        if apply_blade_env:
            self._apply_blade_env_value()
        if get_token_from_cache:
            self.get_token_from_cache()

    @contextmanager
    def switch_config(self, api_config_name, get_token_from_cache):
        config = get_config_by_name(api_config_name, api_config_oa)
        old__dict = copy.copy(self.__dict__)
        self.__dict__ = OpenAPI(config, get_token_from_cache).__dict__.copy()
        yield
        self.__dict__ = old__dict

    @property
    def config(self):
        return self._config

    @property
    def in_blade_env(self):
        return self._in_blade_env

    @property
    def api_host(self):
        if self.config:
            return self.config["host"]
        return ""

    @property
    def http_scheme(self):
        if self.config:
            return self.config["http_scheme"]
        return ""

    @property
    def timeout(self):
        if self.config:
            return self.config["timeout"]
        return None

    @staticmethod
    def get_node_permission_group(node_brief):
        p = node_brief.get("permission_mask")
        if p is None:
            raise exception.Error(value="node brief does not contain field \"permission_mask\"")
        permission_group = []
        if p & (1 << 2) > 0:
            permission_group.append("admin")
        if p & (1 << 4) > 0:
            permission_group.append("editor")
        if p & (1 << 6) > 0:
            permission_group.append("uploader")
        if p & (1 << 8) > 0:
            permission_group.append("downloader")
        if p & (1 << 10) > 0:
            permission_group.append("visitor")
        if p & (1 << 12) > 0:
            permission_group.append("pass")
        return permission_group

    def clear_token(self):
        self._token = ""
        self._public_token = ""

    def clear_cookies(self):
        self._cookies = None

    def clear_token_cache(self):
        name = self.api_host
        if name == "":
            return
        utils.remove_token_cache_file(name)

    def logout(self):
        self.clear_token()
        self.clear_token_cache()
        self.clear_cookies()
        self._current_account_info = None

    def get_token_from_cache(self):
        name = self.api_host
        if name == "":
            return
        token = utils.get_token_from_cache(name)
        if token:
            self._token = token

    def save_token_to_cache(self):
        name = self.api_host
        if self._token and name != "":
            utils.save_token_to_cache(self._token, name)

    @property
    def token(self):
        return self._token

    def set_token(self, token, save_to_cache=True):
        r"""Set arthub token which is used to call api

        :param token: str, a token obtained by API:login.
        :param save_to_cache: (optional) bool. save the token to local cache
        """

        self._token = token
        if save_to_cache:
            self.save_token_to_cache()

    def set_public_token(self, token):
        r"""Set public token which is used to call api of data service

        :param token: str, a public token issued by the administrator.
        """

        self._public_token = token

    def set_cookies(self, cookie, parse_token_from_cookies=False):
        r"""Set cookies which is used to call api

        :param cookie: str or dict, cookie from browser.
        :param parse_token_from_cookies: bool, parse arthub token from cookie.
        """

        if type(cookie) is str:
            self._cookies = utils.parse_cookies(cookie)
        elif type(cookie) is dict:
            self._cookies = cookie
        if parse_token_from_cookies:
            self._parse_token_from_cookies()

    def _parse_token_from_cookies(self):
        if not self._cookies:
            return
        _account_ticket = self._cookies.get("arthub_account_ticket")
        if not _account_ticket:
            return
        self._token = _account_ticket

    def has_credential(self):
        r"""Checks if credential is already set or not"""
        if self._public_token:
            return True
        if self._cookies:
            return True
        if self._token:
            return True
        return False

    def reset_config(self, config):
        self._config = config

    def init_from_config(self):
        self.reset_config(utils.get_config_by_name(arthub_api_config.api_config_name, self.config))

    def base_url(self):
        return "%s//%s" % (self.http_scheme, self.api_host)

    def _depot_url(self, asset_hub, api_method):
        return "%s//%s/%s/data/openapi/%s/core/%s" % (
            self.http_scheme, self.api_host, asset_hub, self._api_version_depot, api_method)

    def _explorer_url(self, asset_hub, api_method):
        return "%s//%s/%s/explorer/openapi/%s/core/%s" % (
            self.http_scheme, self.api_host, asset_hub, self._api_version_explorer, api_method)

    def _am_url(self, asset_hub, api_method, version=None, use_sdk_segment=True):
        # get-node-detail and get-file-brief do not support sdk segment routing
        if api_method in ('get-node-detail', 'get-file-brief', 'get-deliverable-asset-directory', 'upload-by-asset-id', 'get-node-type-by-name'):
            use_sdk_segment = False
        api_version_am = self._api_version_am
        if version is not None:
            api_version_am = version
        sdk_segment = ""
        if use_sdk_segment and self._api_sdk_segment_am:
            segment = self._api_sdk_segment_am.strip("/")
            if segment:
                sdk_segment = "%s/" % segment
        return "%s//%s/%s/am/openapi/%s%s/core/%s" % (
            self.http_scheme, self.api_host, asset_hub, sdk_segment, api_version_am, api_method)

    def _gateway_url(self, api_method):
        return "%s//%s/gateway/gateway/openapi/%s/core/%s" % (
            self.http_scheme, self.api_host, self._api_version_gateway, api_method)

    def _account_url(self, api_method):
        return "%s//%s/account/account/openapi/%s/core/%s" % (
            self.http_scheme, self.api_host, self._api_version_account, api_method)

    def _try_auto_login(self):
        # Use the cached account password to log in again to get the token
        if not self._auto_login:
            return False
        if len(self._cached_password) == 0 or len(self._cached_account_name) == 0:
            return False
        return self.login(account_name=self._cached_account_name,
                          password=self._cached_password,
                          terminal_type=self._cached_terminal_type,
                          business_type=self._cached_business_type).is_succeeded()

    def _make_api_request(self, url, data=None, method='POST', content_type='application/json',
                          try_login_on_expired=True):
        # set token to headers
        headers = {}
        if self._token:
            headers["arthubtoken"] = self._token
        if self._public_token:
            headers["publictoken"] = self._public_token
        headers["content-type"] = content_type
        self.add_headers(headers)

        # send request
        try:
            res = requests.request(method=method, url=url, headers=headers, json=data, cookies=self._cookies,
                                   timeout=self.timeout)
        except Exception as e:
            logger.error("[API] send request \"%s\" exception: %s" % (url, e))
            response = APIResponse(None, True)
            response.exception = e
            return response

        response = APIResponse(res)
        if response.is_api_authentication_failed() and try_login_on_expired:
            # Try to log in again due to authentication failure
            if self._try_auto_login():
                response = self._make_api_request(url, data, method, content_type, try_login_on_expired=False)

        return response

    def _apply_blade_env_value(self):
        network_type = os.environ.get("BLADE_NETWORK_TYPE")
        if not network_type:
            return
        self._in_blade_env = True
        self._config = get_config_by_name(network_type, self._config)
        cookies_str = os.environ.get("BLADE_API_COOKIES")
        if cookies_str:
            self.set_cookies(cookies_str, True)

    def add_headers(self, headers):
        if self._am_sub_instance_name:
            headers["arthub-sub-instance-name"] = self._am_sub_instance_name

    def set_am_sub_instance_name(self, name):
        r"""Set the AM sub-instance name header for commercial/non-commercial distinction.

        When set to 'business', all subsequent AM API requests will include
        the header ``arthub-sub-instance-name: business``, which routes to the
        commercial AM instance.

        Set to an empty string (default) to use the non-commercial instance.

        :param name: str. 'business' for commercial instance, '' for non-commercial.
        """
        self._am_sub_instance_name = name

    @staticmethod
    def generate_login_ticket(req_payload, public_key_str):
        plain_text = req_payload["nounce"] + json.dumps(req_payload)
        return utils.encrypt(public_key_str, plain_text)

    def login(self, account_name, password,
              terminal_type="default",
              business_type="default",
              verification_code=None,
              login_public_keys=None,
              set_auto_login=True,
              save_token_to_cache=True,
              nounce=None):
        r"""Login by email/mobile and password. You can visit https://arthub.qq.com to register.

        :param account_name: str. email or mobile.
        :param password: str. If you forget, visit https://arthub.qq.com/reset-password to reset
        :param terminal_type: str.
        :param business_type: str.
        :param verification_code: str.
        :param login_public_keys: str.
        :param set_auto_login: (optional) bool. After successful login, save the account and password,
               and login automatically after the login status expires
        :param save_token_to_cache: (optional) bool. After successful login, save the token to local cache
        :param nounce: (optional) str.

        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "account_name": account_name,
            "account_type": "mobile" if account_name.isdigit() else "email",
            "password": password,
            "terminal_type": terminal_type,
            "business_type": business_type,
            "current_time": utils.current_milli_time(),
            "nounce": nounce if nounce and isinstance(nounce, str) else utils.get_random_string(8),
            "oauth_type": "password",
            "login_type": "arthub_token"
        }

        url = self._account_url("login")
        if not login_public_keys:
            if verification_code:
                req_payload["verification_code"] = verification_code
            else:
                url = self._account_url("login-fix")
        else:
            url = self._account_url("open-secret-login")
            req_payload["ticket"] = self.generate_login_ticket(req_payload, login_public_keys)

        res = self._make_api_request(url, req_payload, try_login_on_expired=False)
        if res.is_succeeded():
            r = res.results.get(0)
            token = r["arthub_token"]
            self.set_token(token, save_token_to_cache)

            self._auto_login = set_auto_login
            # save account and password for auto login
            if set_auto_login:
                self._cached_account_name = account_name
                self._cached_password = password
                self._cached_terminal_type = terminal_type
                self._cached_business_type = business_type

        return res

    def _account_value(self, key):
        account_info = self.current_account_info
        if account_info:
            return account_info.get(key)

    def get_account_email(self):
        r"""
        :rtype: str or None. Example: "XXX@tencent.com".
        """

        return self._account_value("email")

    def get_account_icon_url(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("icon_url")

    def get_account_company(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("company")

    def get_account_department(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("department")

    def get_account_nick_name(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("nick_name")

    def get_account_qywx_alias(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("qywx_alias")

    def get_account_qywx_name(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("qywx_name")

    def get_account_phone(self):
        r"""
        :rtype: str or None.
        """

        return self._account_value("phone")

    @property
    def current_account_info(self):
        if self._current_account_info is not None:
            return self._current_account_info
        res = self.get_account_detail()
        if res.is_succeeded():
            self._current_account_info = res.first_result()
        return self._current_account_info

    def get_account_detail(self, account_name=[]):
        r"""Get the detail of user's account.

        :param account_name: list. Example: ["joey"].
        :rtype: arthub_api.APIResponse
        """

        url = self._account_url("get-account-detail-by-account-name")
        res = self._make_api_request(url, method="GET", data={"account_name": account_name})
        res.set_result_as_first_item()
        return res

    def check_account_if_exist(self, account_names):
        r"""Check whether the given account(s) exist and fetch their basics.

        :param account_names: list<str> or str. Example: ["kazenzhong"].
        :rtype: arthub_api.APIResponse. res.result -> dict<account_name, detail>.
        """

        if account_names is None:
            account_names = []
        elif isinstance(account_names, str):
            account_names = [account_names]

        url = self._account_url("check-account-if-exist")
        payload = {"account_name": account_names}
        res = self._make_api_request(url, payload)
        if res.is_succeeded():
            mapped = {}
            for item in res.results.values():
                if not isinstance(item, dict):
                    continue
                key = item.get("key")
                if not key:
                    continue
                detail = item.get("detail") or {}
                if isinstance(detail, dict) and "account_name" not in detail:
                    detail = dict(detail)
                    detail["account_name"] = key
                mapped[key] = detail
            res.results = mapped
            res.set_result(mapped)
        return res

    def is_login(self):
        r"""Check the login status.

        :rtype: bool
        """

        if self._token == "" and self._public_token == "" and self._cookies is None:
            return False

        return bool(self.current_account_info)

    def get_ticket(self):
        r"""Get the ticket to request websocket.

        :rtype: arthub_api.APIResponse
        """

        url = self._account_url("get-ticket")
        return self._make_api_request(url, method="GET")

    def set_last_access_location_by_account(self, last_location):
        r"""Set the last access location of user's account.

        :param last_location: str. Example: "gas/pan?node=120259084289".
        :rtype: arthub_api.APIResponse
        """

        url = self._account_url("set-last-access-location-by-account")
        req_payload = {
            "last_location": last_location
        }
        return self._make_api_request(url, req_payload)

    def get_last_access_location_by_account(self):
        r"""Get the user's last access location.

        :rtype: arthub_api.APIResponse
        """

        url = self._account_url("get-last-access-location-by-account")
        return self._make_api_request(url, method="GET")

    # depot
    def depot_get_node_brief_by_ids(self, asset_hub, ids, simplified_meta=False):
        r"""Get the brief of node by id in depot.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Example: [1234].
        :param simplified_meta: (optional) bool. Just basic meta, lower bandwidth consumption.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-node-brief-by-id")
        req_payload = {
            "ids": ids,
            "meta": _node_query_metas(simplified_meta)
        }
        return self._make_api_request(url, req_payload)

    def depot_get_download_signature(self, asset_hub, nodes):
        r"""Get the download url of asset in depot.

        :param asset_hub: str. Example: "trial".
        :param nodes: list<node (dict) >. Example: [{"object_id": 110347249345024, "object_meta": "origin_url"}].
                {
                    "object_id": int, node id,
                    "object_meta": str, Example: "origin_url"|"preview_url"
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-download-signature")
        req_payload = {
            "items": nodes
        }
        res = self._make_api_request(url, req_payload)
        signed_url = "%s%s" % (self.http_scheme, res.first_result("signed_url"))
        res.set_result(signed_url)
        return res

    def depot_get_upload_signature(self, asset_hub, nodes):
        r"""Get the upload url of asset in depot.

        :param asset_hub: str. Example: "trial".
        :param nodes: list<node (dict) >. Example: [{"object_id": 110347249345024, "object_meta": "origin_url"}].
                {
                    "object_id": int, node id,
                    "object_meta": str, Example: "origin_url"|"preview_url",
                    "file_name": file name to upload
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-upload-signature")
        req_payload = {
            "items": nodes
        }
        res = self._make_api_request(url, req_payload)
        signed_url = "%s%s" % (self.http_scheme, res.first_result("signed_url"))
        res.set_result(signed_url)
        return res

    def depot_create_empty_file(self, asset_hub, asset_id, file_name):
        r"""Create the empty file on storage of asset in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 1234.
        :param file_name: str. Example: "1.jpg".
        :rtype: arthub_api.Result::data: {"origin_url": str}
        """

        api_res = self.depot_get_upload_signature(asset_hub, [{
            "object_id": asset_id,
            "object_meta": "origin_url",
            "file_name": file_name
        }])
        if not api_res.is_succeeded():
            return models.failure_result("get upload signature url of %d to create empty file failed, %s" % (
                asset_id, api_res.error_message()))
        signed_upload_url = api_res.direct_result
        origin_url = api_res.first_result()["origin_url"]

        # send signature url
        try:
            upload_res = requests.put(url=signed_upload_url, headers={"content-length": str(0)}, timeout=self.timeout)
        except Exception as e:
            return models.failure_result("request \"%s\" exception, %s" % (
                signed_upload_url, e))
        if not upload_res.ok:
            return models.failure_result("upload to \"%s\" failed, status code: %d" % (
                signed_upload_url, upload_res.status_code))

        return models.success_result({
            "origin_url": origin_url
        })

    def depot_get_create_multipart_upload_signature(self, asset_hub, nodes):
        r"""Get the multipart upload url to visit S3 in depot.

        :param asset_hub: str. Example: "trial".
        :param nodes: list<node (dict) >. Example: [{"object_id": 110347249345024, "object_meta": "origin_url"}].
                {
                    "object_id": int, node id,
                    "object_meta": str, Example: "origin_url"|"preview_url",
                    "file_name": file name to upload
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "create-multipart-upload-signature")
        req_payload = {
            "items": nodes
        }
        res = self._make_api_request(url, req_payload)
        signed_url = "%s%s" % (self.http_scheme, res.first_result("signed_url"))
        res.set_result(signed_url)
        return res

    @staticmethod
    def extract_upload_id(input_str):
        if not input_str:
            return ""
        try:
            start_tag = "<UploadId>"
            end_tag = "</UploadId>"
            start_index = input_str.index(start_tag) + len(start_tag)
            end_index = input_str.index(end_tag)
            return input_str[start_index:end_index]
        except ValueError:
            return ""

    def depot_get_multipart_upload_id(self, asset_hub, asset_id, file_name):
        r"""Get the multipart upload id to in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 1234.
        :param file_name: str. Example: "1.jpg".

        :rtype: arthub_api.Result::data: {"upload_id": str, "origin_url": str}
        """

        # create multipart upload task
        api_res = self.depot_get_create_multipart_upload_signature(asset_hub, [{
            "object_id": asset_id,
            "object_meta": "origin_url",
            "file_name": file_name
        }])
        if not api_res.is_succeeded():
            return models.failure_result("get create multipart upload signature url of %d failed, %s" % (
                asset_id, api_res.error_message()))
        signed_url = api_res.direct_result
        origin_url = api_res.first_result()["origin_url"]
        logger.info("[API] get begin multipart upload signed url: %s" % signed_url)

        # send signature url
        try:
            res = requests.post(signed_url,
                                headers={"content-type": _internal_utils.get_content_type_from_file_name(file_name)},
                                timeout=self.timeout)
        except Exception as e:
            error_message = "request S3 multipart by url %s upload id exception: %s" % (signed_url, e)
            logger.error("[API] %s" % error_message)
            return models.failure_result(error_message)

        if not res or not res.ok:
            error_message = "request S3 multipart upload id failed, url: %s, code: %d" % (signed_url, res.status_code)
            logger.error("[API] %s" % error_message)
            return models.failure_result(error_message)

        upload_id = self.extract_upload_id(res.text)
        if not upload_id:
            error_message = "parsing S3 multipart upload id from \"%s\" failed" % res.text
            logger.error("[API] %s" % error_message)
            return models.failure_result(error_message)

        return models.success_result({
            "origin_url": origin_url,
            "upload_id": upload_id
        })

    def depot_get_part_upload_signature(self, asset_hub, nodes):
        r"""Get the S3 part upload url.

        :param asset_hub: str. Example: "trial".
        :param nodes: list<node (dict) >. Example: [{"object_id": 110347249345024, "object_meta": "origin_url"}].
                {
                    "object_id": int, node id,
                    "object_meta": str, Example: "origin_url"|"preview_url",
                    "file_name": file name to upload,
                    "upload_id": str, upload id of S3 multipart upload task,
                    "origin_url": str, origin url,
                    "part_number": int, upload part number, begin with 1
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "upload-part-signature")
        req_payload = {
            "items": nodes
        }
        res = self._make_api_request(url, req_payload)
        signed_url = "%s%s" % (self.http_scheme, res.first_result("signed_url"))

        logger.info("[API] get multipart upload signed url: %s" % signed_url)

        res.set_result(signed_url)
        return res

    def depot_get_complete_multipart_upload_signature(self, asset_hub, nodes):
        r"""Get the multipart upload url to visit S3 in depot.

        :param asset_hub: str. Example: "trial".
        :param nodes: list<node (dict) >. Example: [{"object_id": 110347249345024, "object_meta": "origin_url"}].
                {
                    "object_id": int, node id,
                    "object_meta": str, Example: "origin_url"|"preview_url",
                    "object_id": str, origin url
                    "file_name": file name to upload,
                    "upload_id": str, upload id of S3 multipart upload task
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "complete-multipart-upload-signature")
        req_payload = {
            "items": nodes
        }
        res = self._make_api_request(url, req_payload)
        signed_url = "%s%s" % (self.http_scheme, res.first_result("signed_url"))
        res.set_result(signed_url)
        return res

    def depot_complete_multipart_upload(self, asset_hub, asset_id, file_name, upload_id, origin_url, etag_data):
        r"""Get the multipart upload id to in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 1234.
        :param file_name: str. Example: "1.jpg".
        :param upload_id: str. upload id of S3 multipart upload task
        :param origin_url: str. origin url
        :param etag_data: object
        :rtype: arthub_api.Result::data: {"upload_id": str, "origin_url": str}
        """

        # complete multipart upload task
        api_res = self.depot_get_complete_multipart_upload_signature(asset_hub, [{
            "object_id": asset_id,
            "object_meta": "origin_url",
            "file_name": file_name,
            "upload_id": upload_id,
            "origin_url": origin_url
        }])
        if not api_res.is_succeeded():
            return models.failure_result("get complete multipart upload signature url of %d failed, %s" % (
                asset_id, api_res.error_message()))
        signed_url = api_res.direct_result

        # send signature url
        try:
            res = requests.post(signed_url,
                                headers={"content-type": "application/xml"}, data=etag_data, timeout=self.timeout)
        except Exception as e:
            error_message = "request complete S3 multipart upload by url %s exception: %s" % (signed_url, e)
            logger.error("[API] %s" % error_message)
            return models.failure_result(error_message)

        if not res or not res.ok:
            error_message = "request complete S3 multipart upload failed, url: %s, code: %d" % (
                signed_url, res.status_code)
            logger.error("[API] %s" % error_message)
            return models.failure_result(error_message)
        return models.success_result(None)

    def depot_set_asset_confirmed_version_id(self, asset_hub, multi_asset_id, confirmed_asset_id):
        r"""Set the confirmed version of a multi asset.

        :param asset_hub: str. Example: "trial".
        :param multi_asset_id: int. Example: 1234.
        :param confirmed_asset_id: int. Example: 1234.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "set-asset-confirmed-version-id")
        req_payload = [{
            "id": multi_asset_id,
            "confirmed_asset_id": confirmed_asset_id,
        }]
        res = self._make_api_request(url, req_payload)
        return res

    def depot_get_child_node_count(self, asset_hub, ids, query_filters=[], is_recursive=False):
        r"""Get the child node count of node in depot.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Example: [1234].
        :param query_filters: (optional) list<query_filter (dict) >. Example: [{"meta": "type", "condition": "x != project"}].
                {
                    "meta": filters meta,
                    "condition": filters condition
                }
        :param is_recursive: (optional) bool, Whether to query recursively
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-child-node-count")
        req_payload = {
            "ids": ids,
            "filter": query_filters,
            "is_recursive": is_recursive
        }
        res = self._make_api_request(url, req_payload)
        res.set_result_by_key("count")
        return res

    def depot_get_child_node_id_in_range(self, asset_hub, parent_id, offset, count, query_filters=[],
                                         is_recursive=False, order=None):
        r"""Get the child node count of node in depot.

        :param asset_hub: str. Example: "trial".
        :param parent_id: int. Example: 1234.
        :param offset: int. range offset: 0.
        :param count: int. range count: 100.
        :param query_filters: list<query_filter (dict) >. Example: [{"meta": "type", "condition": "x != project"}].
                {
                    "meta": filters meta,
                    "condition": filters condition
                }
        :param is_recursive: (optional) bool, Whether to query recursively
        :param order: (optional) dict >. Example:
                {
                    "meta": "updated_date",
                    "type": "descend"
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-child-node-id-in-range")
        req_payload = {
            "parent_id": parent_id,
            "offset": offset,
            "count": count,
            "filter": query_filters,
            "is_recursive": is_recursive,
            "order": order
        }
        res = self._make_api_request(url, req_payload)
        res.set_result_by_key("nodes")
        return res

    def depot_get_node_brief_by_path(self, asset_hub, root_id, path, simplified_meta=False):
        r"""Get the brief of node by path in depot.

        :param asset_hub: str. Example: "trial".
        :param root_id: int. Example: 1234.
        :param path: str. Example: "1/2.jpg".
        :param simplified_meta: (optional) bool. Just basic meta, lower bandwidth consumption.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-node-brief-by-path")

        path = path.replace('\\', '/')
        req_payload = {
            "root_id": root_id,
            "path": [path],
            "meta": _node_query_metas(simplified_meta)
        }
        return self._make_api_request(url, req_payload)

    def depot_delete_node_by_ids(self, asset_hub, ids):
        r"""delete the node in depot.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Example: [1234].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "delete-node-by-id")
        req_payload = {
            "ids": ids
        }
        return self._make_api_request(url, req_payload)

    def depot_move_node(self, asset_hub, ids, other_parent_id):
        r"""move the node in depot.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Example: [1234, 3456].
        :param other_parent_id: int.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "move-node")
        req_payload = {
            "ids": ids,
            "other_parent_id": other_parent_id
        }
        return self._make_api_request(url, req_payload)

    def depot_copy_node(self, asset_hub, ids, to_id, copy_permission=False, only_copy_structure=False):
        r"""move the node in depot.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Example: [1234, 3456].
        :param to_id: int.
        :param copy_permission: (optional) bool. Just copy permission.
        :param only_copy_structure: (optional) bool. Just copy structure.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "copy-node")
        req_payload = {
            "node_id": ids,
            "to_id": to_id,
            "copy_permission": copy_permission,
            "only_copy_structure": only_copy_structure
        }
        res = self._make_api_request(url, req_payload)
        if not res.is_succeeded():
            return res
        ids = []
        for id_item in res.result:
            id = id_item.get("id")
            if id:
                ids.append(id)
        res.set_result(ids)
        return res

    def depot_create_project(self, asset_hub, name, parent_id, return_existing_id=True, show_detail_column=True,
                             show_version_column=True,
                             watermark=False):
        r"""create project in depot.

        :param asset_hub: str. Example: "trial".
        :param name: str. project name. Example: "test".
        :param parent_id: int. depot root id. Example: 304942678017.
        :param return_existing_id: (optional) bool.
        :param show_detail_column: (optional) bool.
        :param show_version_column: (optional) bool.
        :param watermark: (optional) bool.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "create-project")
        req_payload = [{
            "name": name,
            "parent_id": parent_id,
            "return_existing_id": return_existing_id,
            "show_detail_column": show_detail_column,
            "show_version_column": show_version_column,
            "watermark": watermark,
        }]

        res = self._make_api_request(url, req_payload)
        res.set_result_by_key("id")
        return res

    def depot_create_directory(self, asset_hub, payloads):
        r"""create dirs in depot.

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "parent_id": parent dir id,
                    "name": name of new dir to create,
                    "allowed_rename": allow renaming new dir to "name(<index>)" when a dir with the same name exists,
                    "return_existing_id": returns the id of an existing dir with the same name
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "create-directory")
        req_payload = {
            "items": payloads
        }

        res = self._make_api_request(url, req_payload)
        res.set_result_by_key("id")
        return res

    def depot_create_asset(self, asset_hub, payloads):
        r"""create assets in depot.

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "parent_id": parent dir id,
                    "name": name of new asset to create,
                    "add_new_version": add a version when an asset with the same name exists,
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "create-asset")
        req_payload = {
            "items": payloads
        }
        res = self._make_api_request(url, req_payload)
        res.set_result_by_key("id")
        return res

    def depot_create_multi_asset(self, asset_hub, payloads):
        r"""create multi asset (version container) in depot.

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "parent_id": parent dir id,
                    "name": name of new multi asset to create,
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "create-multi-asset")
        req_payload = {
            "items": payloads
        }
        return self._make_api_request(url, req_payload)

    def depot_update_asset_by_id(self, asset_hub, payloads):
        r"""update metas of asset in depot.

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "id": int, node id,
                    "name": str, node name,
                    "origin_url": origin url,
                    "description": description of node
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "update-asset-by-id")
        req_payload = {
            "items": payloads
        }
        return self._make_api_request(url, req_payload)

    def depot_convert_asset(self, asset_hub, asset_files, asset_ids):
        r"""convert asset in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_files: list<str>. Example: ["//ahs_cos_guangzhou_1/assethub-trial-1258344700/cospri/download/110347249345/110347249345067/1.png"].
        :param asset_ids: list<int>. Example: [110347249345067].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "convert-asset")
        req_payload = {
            "asset_files": asset_files,
            "asset_ids": asset_ids
        }
        return self._make_api_request(url, req_payload)

    def depot_create_tsa(self, asset_hub, asset_id, company, description, title, tsa_info):
        r"""convert asset in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 110347249345071.
        :param company: str. Example: "Tencent".
        :param description: str. Example: "New weapon".
        :param title: str. Example: "Christmas".
        :param tsa_info: str. Example: "Characters; Web design".
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "create-tsa")
        req_payload = {
            "asset_id": asset_id,
            "company": company,
            "description": description,
            "title": title,
            "tsa_info": tsa_info
        }
        return self._make_api_request(url, req_payload)

    def depot_add_asset_tag(self, asset_hub, asset_id, tag_name):
        r"""add tags to asset node in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 110347249345071.
        :param tag_name: list<str>. Example: ["tag_1", "tag_2"].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "add-asset-tag")
        req_payload = {
            "asset_id": asset_id,
            "tag_name": tag_name
        }
        return self._make_api_request(url, req_payload)

    def depot_get_asset_tag(self, asset_hub, asset_id):
        r"""get tags on asset node in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 110347249345071.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-tag-by-asset-id")
        req_payload = {
            "asset_id": asset_id
        }
        return self._make_api_request(url, req_payload)

    def depot_delete_asset_tag(self, asset_hub, asset_id, tag_id):
        r"""delete tags on asset node in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 306016443484.
        :param tag_id: list<int>. Example: [120347802321392].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "delete-asset-tag")
        req_payload = {
            "asset_id": asset_id,
            "tag_id": tag_id
        }
        return self._make_api_request(url, req_payload)

    # ---- Predefined Tag APIs ----

    def depot_get_predefined_tagtree_ids(self, asset_hub):
        r"""get the root-level predefined tag trees.

        :param asset_hub: str. Example: "trial".
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-predefined-tagtree-ids")
        req_payload = {}
        return self._make_api_request(url, req_payload)

    def depot_get_predefined_tagtree_childtag_ids(self, asset_hub, ids):
        r"""get child tag ids for the given parent tag ids.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Parent tag ids. Example: [120347747659008, 120347733409977].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-predefined-tagtree-childtag-ids")
        req_payload = {
            "ids": ids
        }
        return self._make_api_request(url, req_payload)

    def depot_get_predefined_tagtree_detail(self, asset_hub, ids):
        r"""get detail info for root-level predefined tag trees.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Tag tree ids. Example: [120347555013022, 120347624903288].
        :return: APIResponse with result as list of tagtree objects.
            Example result: [{"id": 120347555013022, "name": "1", "color": "#23d0a1", ...}, ...]
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-predefined-tagtree-detail-by-id")
        req_payload = {
            "ids": ids
        }
        return self._make_api_request(url, req_payload)

    def depot_get_predefined_tagtree_tag_detail(self, asset_hub, ids):
        r"""get detail info for child tags under predefined tag trees.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. Tag ids. Example: [120347624903305, 120347624903309].
        :return: APIResponse with result as {"items": [...]}.
            Example result: {"items": [{"id": 120347624903305, "name": "测试A", "parent_id": ..., ...}, ...]}
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-predefined-tagtree-tag-detail-by-id")
        req_payload = {
            "ids": ids
        }
        return self._make_api_request(url, req_payload)

    def depot_batch_add_asset_predefined_tag(self, asset_hub, predefined_tag_ids,
                                             asset_ids=None, directory_ids=None):
        r"""batch add predefined tags to assets and/or directories.

        :param asset_hub: str. Example: "trial".
        :param predefined_tag_ids: list<int>. Example: [120347747824085].
        :param asset_ids: list<int>. File asset ids. Example: [120347806794611].
        :param directory_ids: list<int>. Directory ids. Example: [120347637424761].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "batch-add-asset-predefined-tag")
        req_payload = {
            "predefined_tag_ids": predefined_tag_ids,
            "asset_ids": asset_ids or [],
            "directory_ids": directory_ids or []
        }
        return self._make_api_request(url, req_payload)

    def depot_batch_del_asset_predefined_tags(self, asset_hub, predefined_tag_ids,
                                              asset_ids=None, directory_ids=None,
                                              del_all_tags=False):
        r"""batch delete predefined tags from assets and/or directories.

        :param asset_hub: str. Example: "trial".
        :param predefined_tag_ids: list<int>. Example: [120347747824085].
        :param asset_ids: list<int>. File asset ids. Example: [120347806794611].
        :param directory_ids: list<int>. Directory ids. Example: [120347637424761].
        :param del_all_tags: bool. If True, delete all predefined tags from the assets.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "batch-del-asset-predefined-tags")
        req_payload = {
            "predefined_tag_ids": predefined_tag_ids,
            "asset_ids": asset_ids or [],
            "directory_ids": directory_ids or [],
            "del_all_tags": del_all_tags
        }
        return self._make_api_request(url, req_payload)

    def depot_get_predefined_tag_mapping(self, asset_hub, asset_id):
        r"""get predefined tag mapping for a given asset.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. Example: 120347806794610.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-predefined-tag-mapping-by-asset-id")
        req_payload = {
            "id": asset_id
        }
        return self._make_api_request(url, req_payload)

    def depot_update_directory_by_id(self, asset_hub, payloads):
        r"""update metas of directory in depot .

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "id": int, node id,
                    "name": str, node name,
                    "origin_url": origin url,
                    "description": description of node
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "update-directory-by-id")
        req_payload = {
            "items": payloads
        }
        return self._make_api_request(url, req_payload)

    def depot_update_project_by_id(self, asset_hub, payloads):
        r"""update metas of project in depot .

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "id": int, node id,
                    "name": str, node name,
                    "origin_url": origin url,
                    "description": description of node
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "update-project-by-id")
        req_payload = {
            "items": payloads
        }
        return self._make_api_request(url, req_payload)

    def depot_update_multi_asset_by_id(self, asset_hub, payloads):
        r"""update metas of multi asset in depot .

        :param asset_hub: str. Example: "trial".
        :param payloads: list<payload (dict) >.
                {
                    "id": int, node id,
                    "name": str, node name,
                    "origin_url": origin url,
                    "description": description of node
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "update-multi-asset-by-id")
        req_payload = {
            "items": payloads
        }
        return self._make_api_request(url, req_payload)

    def depot_add_review(self, asset_hub, asset_id, content, is_pass=0,
                         anchor_info=None, mentions=None):
        r"""Add a review (comment) to an asset node in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. The asset node id to add review to. Example: 120347823072104.
        :param content: str. Review content (supports HTML with @mentions).
            Example: "<p>looks good</p>"
        :param is_pass: (optional) int. Review status enum:
            0 = 暂不表态 (no comment),
            1 = 已验收 (accepted),
            2 = 待优化 (needs improvement),
            3 = 最终版 (final version).
        :param anchor_info: (optional) dict. Anchor information. Default: {"anchor": {}}.
        :param mentions: (optional) list<str>. Account names to notify. Example: ["joeyding"].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "add-review")
        if anchor_info is None:
            anchor_info = {"anchor": {}}
        if mentions is None:
            mentions = []
        req_payload = {
            "asset_id": asset_id,
            "content": content,
            "is_pass": is_pass,
            "anchor_info": anchor_info,
            "has_readed_account_name": [],
            "mentions": mentions,
        }
        res = self._make_api_request(url, req_payload)
        res.set_result_as_first_item()
        return res

    def depot_get_reviews(self, asset_hub, asset_id, filter_pin=False, with_all_child=False):
        r"""Get reviews (comments) of an asset node in depot.

        :param asset_hub: str. Example: "trial".
        :param asset_id: int. The asset node id. Example: 120347823072104.
        :param filter_pin: (optional) bool. Filter pinned reviews only.
        :param with_all_child: (optional) bool. Include child reviews.
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-reviews-by-asset-id")
        req_payload = {
            "asset_id": asset_id,
            "filter_pin": filter_pin,
            "with_all_child": with_all_child,
        }
        res = self._make_api_request(url, req_payload)
        if res.is_succeeded():
            reviews = res.first_result()
            if isinstance(reviews, dict):
                res.set_result(reviews.get("reviews", []))
            else:
                res.set_result(reviews)
        return res

    def depot_delete_review(self, asset_hub, ids):
        r"""Delete reviews (comments) by ids in depot.

        :param asset_hub: str. Example: "trial".
        :param ids: list<int>. The review ids to delete. Example: [120347823151075].
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "delete-review")
        req_payload = {
            "ids": ids
        }
        return self._make_api_request(url, req_payload)

    def depot_get_root_id(self, asset_hub):
        r"""get the depot root id of asset hub.

        :param asset_hub: str. Example: "trial".
        :rtype: arthub_api.APIResponse
        """

        url = self._depot_url(asset_hub, "get-depot-id")
        return self._make_api_request(url)

    def depot_get_pan_search_item_count(self, asset_hub, parent_id, keyword, is_recursive=True):
        r"""
        :param asset_hub: str. Example: "trial".
        :param parent_id: int. Example: 110347249345071.
        :param keyword: str. Example: "1".
        :param is_recursive: bool. Example: True.

        :rtype: arthub_api.APIResponse
        """

        url = self._explorer_url(asset_hub, "get-pan-search-item-count")
        req_payload = {
            "parent_id": parent_id,
            "is_recursive": is_recursive,
            "keyword": keyword,
            "should": "[]",
            "must": "[{\"term\":{\"status\":\"normal\"}}]",
            "must_not": "[]"
        }
        res = self._make_api_request(url, req_payload)
        res.set_result_as_first_item()
        return res

    def depot_get_pan_search_item_id_in_range(self, asset_hub, parent_id, keyword, offset, count, is_recursive=True,
                                              order=None):
        r"""
        :param asset_hub: str. Example: "trial".
        :param parent_id: int. Example: 110347249345071.
        :param keyword: str. Example: "1".
        :param offset: int. range offset: 0.
        :param count: int. range count: 100.
        :param is_recursive: bool. Example: True.
        :param order: (optional) dict >. Example:
                {
                    "meta": "updated_date",
                    "type": "descend"
                }
        :rtype: arthub_api.APIResponse
        """

        url = self._explorer_url(asset_hub, "get-pan-search-item-id-in-range")
        req_payload = {
            "parent_id": parent_id,
            "is_recursive": is_recursive,
            "keyword": keyword,
            "should": "[]",
            "must": "[{\"term\":{\"status\":\"normal\"}}]",
            "must_not": "[]",
            "offset": offset,
            "count": count,
            "order": order
        }
        res = self._make_api_request(url, req_payload)
        if not res.is_succeeded():
            return res
        ids = []
        for id_item in res.result:
            id = id_item.get("id")
            if id:
                ids.append(id)
        res.set_result(ids)
        return res

    def request_am(self, asset_hub, api_name, payload=None, api_version=None, method='POST'):
        url = self._am_url(asset_hub, api_name, version=api_version)
        return self._make_api_request(url, payload, method=method)

    # am
    def am_fuzzy_match_user(self, asset_hub, keyword):
        r"""Fuzzy search person accounts by keyword (nick name / account name) in AM.

        :param asset_hub: str. Example: "yida".
        :param keyword: str. Search text, same as account_name field in API.
        :rtype: arthub_api.APIResponse. res.result -> list<dict>.
        """

        payload = {
            "account_name": keyword,
            "type": ["person"]
        }
        url = self._am_url(asset_hub, "fuzzy-match-user", use_sdk_segment=False)
        res = self._make_api_request(url, payload)
        if res.is_succeeded():
            matches = [item for _, item in sorted(res.results.items()) if item is not None]
            res.set_result(matches)
        return res

    def am_get_all_properties(self, asset_hub):
        r"""Get all properties in asset matrix.

        Example:

            res = open_api.am_get_all_properties(asset_hub="test")
            if res.is_succeeded():
                properties = res.first_result("properties")  # dict[field_id -> metadata]

        :param asset_hub: str. Example: "trial".
        :rtype: arthub_api.APIResponse
        """

        return self.request_am(asset_hub, "get-all-properties")

    def am_get_project_id_in_range(self, asset_hub, offset=0, count=-1):
        r"""Get project id in range in asset matrix.

        :param asset_hub: str. Example: "yida".
        :param offset: int. range offset: 0.
        :param count: int. range count: -1.
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "offset": offset,
            "count": count
        }
        return self.request_am(asset_hub, "get-project-id-in-range", req_payload)

    def am_get_project_root_id(self, asset_hub):
        r"""Get root project id in asset matrix.

        Example:

            res = open_api.am_get_project_root_id(asset_hub="test")
            if res.is_succeeded():
                project_root_id = res.result

        :param asset_hub: str. Example: "cg_artdev".
        :rtype: arthub_api.APIResponse
        """

        res = self.am_get_project_id_in_range(asset_hub)
        if not res.is_succeeded():
            return res

        project_id = res.first_result()
        res.set_result(project_id)
        if project_id is not None:
            res.results = {0: project_id}
        return res

    def am_get_module_name_in_range(self, asset_hub, offset=0, count=-1, key=""):
        r"""Get module names in asset matrix.

        API name: get-module-name-in-range

        :param asset_hub: str. Example: "cg_artdev".
        :param offset: int. Example: 0.
        :param count: int. Example: -1 (fetch all).
        :param key: str. Example: "" (keyword filter).
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "offset": offset,
            "count": count,
            "key": key
        }
        return self.request_am(asset_hub, "get-module-name-in-range", req_payload)

    def am_get_module_detail_by_name(self, asset_hub, names):
        r"""Get module detail by names.

        API name: get-module-detail-by-name

        Request payload example:
            {"names": ["c998590e-4fe3-5af5-9f95-591f60217a2d", ...]}

        :param asset_hub: str. Example: "cg_artdev".
        :param names: list<str>.
        :rtype: arthub_api.APIResponse
        """

        req_payload = {"names": names}
        return self.request_am(asset_hub, "get-module-detail-by-name", req_payload)

    def am_get_all_modules(self, asset_hub):
        r"""Get all module details in asset matrix.

        This is a convenience wrapper around:
          1) get-module-name-in-range
          2) get-module-detail-by-name

        Example:

            res = open_api.am_get_all_modules(asset_hub="test")
            if res.is_succeeded():
                modules = res.result  # list of module dict with all fields
                # Each module contains: name, display_name, param_index,
                # pre_modules, post_modules, color, is_custom, people_level,
                # people_level_color, is_deleted

        :param asset_hub: str. Example: "cg_artdev".
        :rtype: arthub_api.APIResponse
        """

        name_res = self.am_get_module_name_in_range(asset_hub, offset=0, count=-1, key="")
        if not name_res.is_succeeded():
            return name_res

        module_names = name_res.direct_result or []
        if not module_names:
            name_res.set_result([])
            name_res.results = {}
            return name_res

        detail_res = self.am_get_module_detail_by_name(asset_hub, module_names)
        if not detail_res.is_succeeded():
            return detail_res

        # Return complete module data instead of just name/display_name
        modules = []
        for item in detail_res.result or []:
            if isinstance(item, dict):
                modules.append(item)

        detail_res.set_result(modules)
        detail_res.results = {i: module for i, module in enumerate(modules)}
        return detail_res

    def am_get_node_child_with_preset_count(self, asset_hub, node_id, preset=None):
        r"""Get count of nodes under preset view.

        API name: get-node-child-with-preset-count

        :param asset_hub: str. Example: "cg_artdev".
        :param node_id: int. node id (e.g. project root id).
        :param preset: str. Example: "Business_Without_Unplanned".
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "node_id": node_id,
            "preset": preset
        }
        return self.request_am(asset_hub, "get-node-child-with-preset-count", req_payload)

    def am_get_node_child_with_preset_id_in_range(self, asset_hub, node_id, preset, offset=0, count=-1,
                                                  order=None, return_link_node=False, key="", filter=None):
        r"""Get node ids under preset view with pagination.

        API name: get-node-child-with-preset-id-in-range

        :param asset_hub: str. Example: "cg_artdev".
        :param node_id: int.
        :param preset: str.
        :param offset: int.
        :param count: int.
        :param order: list<dict>. Example: [{"meta": "name", "type": "asc"}] or [{"meta": "updated_date", "type": "desc"}]
        :param return_link_node: bool.
        :param key: str. Example: "".
        :param filter: list<dict>. Optional filter list, same syntax as query filters. Example: [{"meta": "type", "condition": "neq", "value": "File"}]
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "offset": offset,
            "count": count,
            "preset": preset,
            "node_id": node_id,
            "order": order,
            "return_link_node": return_link_node,
            "key": key,
            "filter": filter,
        }
        return self.request_am(asset_hub, "get-node-child-with-preset-id-in-range", req_payload)

    def am_get_node_brief(self, asset_hub, ids):
        r"""Get node brief in asset matrix.

        API name: get-node-brief

        Request payload example:
            {"ids": [120347765632896, ...]}

        :param asset_hub: str. Example: "cg_artdev".
        :param ids: list<int>.
        :rtype: arthub_api.APIResponse
        """

        req_payload = {"ids": ids}
        return self.request_am(asset_hub, "get-node-brief", req_payload)
    
    def am_get_node_properties(self, asset_hub, ids, properties):
        r"""Get node properties in asset matrix.

        API name: get-node-properties

        Request payload example:
            {"ids": [120347765632896, ...], "properties": ["name", "type"]}

        :param asset_hub: str. Example: "cg_artdev".
        :param ids: list<int>.
        :param properties: list<str>.
        :rtype: arthub_api.APIResponse
        """

        req_payload = {"ids": ids,"properties": properties}
        return self.request_am(asset_hub, "get-node-detail", req_payload)

    def am_get_node_type_by_name(self, asset_hub, object_types):
        r"""Get node type display info by type name in asset matrix.

        API name: get-node-type-by-name

        Maps node type names (e.g. "Entity", "Stage") to their display names
        (e.g. "实体", "环节") and other metadata.

        Request payload example:
            {"object_type": ["Entity", "File", "Bug", "Stage", "Link", "Demand", "Procedure"]}

        Response example (per item):
            {
                "name": "Entity",
                "display_name": "实体",
                "parent": "Production",
                "display_info": {"icon_source": "system", "icon_file": "icon_entity.svg", "show_color": "#ffffff"},
                "is_read_only": true,
                ...
            }

        :param asset_hub: str. Example: "yida".
        :param object_types: list<str>. Node type names. Example: ["Entity", "Stage", "File"].
        :rtype: arthub_api.APIResponse. res.result -> list<dict>, each with "name" and "display_name".
        """

        req_payload = {"object_type": object_types}
        return self.request_am(asset_hub, "get-node-type-by-name", req_payload)

    def am_update_task_properties(self, asset_hub, ids, properties_obj):
        r"""Update task properties in asset matrix.

        Matches SDK doc: ``update-task-properties(assetHubName, ids, propertiesObj)``

        Example:

            res = open_api.am_update_task_properties(
                asset_hub="test",
                ids=[120347778612225],
                properties_obj={"name": "new-name"}
            )
            if res.is_succeeded():
                updated_ids = res.result

        :param asset_hub: str. Example: "cg_artdev".
        :param ids: list<int>. Task (node) ids to update.
        :param properties_obj: dict. Property ID -> value mapping, e.g.
            ``{"8282a549-29bf-5eb0-ac22-3f466609e7bb": ["-1-1-1-2-1"]}``
        :rtype: arthub_api.APIResponse
        """

        if not isinstance(ids, list) or len(ids) == 0:
            raise ValueError("ids must be a non-empty list")
        if not isinstance(properties_obj, dict) or len(properties_obj) == 0:
            raise ValueError("properties_obj must be a non-empty dict")

        last_response = None
        succeeded = []
        for node_id in ids:
            payload = {
                "node_id": node_id,
                "properties": properties_obj
            }
            res = self.request_am(asset_hub, "update-node-property", payload)
            if not res.is_succeeded():
                return res
            last_response = res
            succeeded.append(node_id)

        if last_response:
            last_response.set_result(succeeded)
            last_response.results = {i: node_id for i, node_id in enumerate(succeeded)}
        return last_response

    def am_get_node_child_as_tree_id_in_range(self, asset_hub, query, offset=0, page_size=100, key=None, api_version="v3"):
        r"""Get node ids as a tree (AM) via "get-node-child-as-tree-id-in-range".

        "query" mirrors the JSON payload used by the AM web console. Common keys:

        - parent_id: int, required. Root node id of the tree.
        - filter: list[dict]. Filter expressions (bool/item/condition/meta/value).
        - order: list[dict]. Sorting rules, e.g. {"meta": "name", "type": "asc"}.
        - offset / page_size: int. Pagination (provided as separate parameters in this wrapper).
        - expand: list[int]. Node ids to be expanded by default.
        - view_root_id: int. View root id (often same as parent_id).
        - skip_production_types: list[str]. Types to exclude, e.g. ["File", "Bug"].
        - Tree behavior: default_collapse / expand_matched / recursive (bool).
        - Filtering behavior: is_path_filter / flat_matched / return_link_node / node_path_hide (bool).
        - display_node_type: str. UI hint, e.g. "Other".
        - key: str. Optional acceleration key from previous response (for faster subsequent requests).

        Minimal requirement: parent_id is required; filter can be an empty list.

        Response contains:
        - Node data arrays: ids, depth, children_count, is_match_filter, recursive_children_count, path, node_type
        - Metadata: count (total nodes in tree), offset (echoed back), page_size (echoed back), key (for next request)

        Example1:

            query = {"parent_id": 120347777793462, "filter": []}
            res = open_api.am_get_node_child_as_tree_id_in_range("test", query=query)
            if res.is_succeeded():
                payload = res.result
                total_count = payload.get('count', 0)  # Total nodes in tree
                cached_key = payload.get('key', '')  # Use in next request

        Example2:

            query = {"parent_id": 120347777793462, "filter": [], "order": [{"meta": "name", "type": "asc"}]}
            res = open_api.am_get_node_child_as_tree_id_in_range(
                asset_hub="test",
                query=query,
                offset=0,
                page_size=100,
                api_version="v3"
            )
            if res.is_succeeded():
                payload = res.result

        Example3 (with acceleration key):

            # First request
            res1 = open_api.am_get_node_child_as_tree_id_in_range("test", query=query, offset=0, page_size=100)
            cached_key = res1.result.get('key')
            
            # Second request (faster with key)
            res2 = open_api.am_get_node_child_as_tree_id_in_range("test", query=query, offset=100, page_size=100, key=cached_key)

        :param asset_hub: str. Example: "cg_artdev".
        :param query: dict. Query object as described above.
        :param offset: int. Starting offset for pagination.
        :param page_size: int. Number of nodes per page (default 100).
        :param key: str or None. Optional acceleration key from previous response.
        :param api_version: str. Default "v3".
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "query": query,
            "offset": offset,
            "page_size": page_size
        }
        if key:
            req_payload["key"] = key
        return self.request_am(asset_hub, "get-node-child-as-tree-id-in-range", req_payload, api_version=api_version)

    def _am_fetch_nodes_paginated(self, asset_hub, query, target_count, page_size=None, api_version="v3"):
        """分页获取节点（内部方法）
        
        Args:
            asset_hub: Asset Hub 名称
            query: 查询对象
            target_count: 目标数量（-1表示获取所有）
            page_size: 每页大小
            api_version: API版本
        
        Returns:
            arthub_api.APIResponse
        """
        from .am.config import AM_DEFAULT_PAGE_SIZE
        import math
        
        if page_size is None:
            page_size = AM_DEFAULT_PAGE_SIZE
        
        # 第一次请求：获取 key 和 total_count
        first_res = self.am_get_node_child_as_tree_id_in_range(
            asset_hub, query, offset=0, page_size=page_size, api_version=api_version
        )
        
        if not first_res.is_succeeded():
            return first_res
        
        first_data = first_res.result
        # AM 接口可能返回列表，取第一个元素
        if isinstance(first_data, list) and len(first_data) > 0:
            first_data = first_data[0]
        
        if not isinstance(first_data, dict):
            return first_res
        
        # 提取元信息
        total_count = first_data.get('count', 0)
        cached_key = first_data.get('key', '')
        
        # 获取第一批数据的实际长度
        first_ids = first_data.get('ids', [])
        current_len = len(first_ids)
        
        # 处理 target_count=-1 的情况（获取所有）
        if target_count == -1:
            target_count = total_count
        
        # 如果第一次请求就足够了
        if current_len >= target_count or current_len >= total_count:
            # 精确截取前 target_count 个
            truncated = self._truncate_paginated_result(first_data, target_count)
            first_res.set_result([truncated])  # 包装成列表保持接口一致性
            first_res.results = {0: truncated}
            return first_res
        
        # 需要更多数据，计算还需要多少次请求
        remaining_count = min(target_count - current_len, total_count - current_len)
        needed_pages = int(math.ceil(float(remaining_count) / page_size))
        
        # 生成后续请求的 offset 列表
        offsets = [page_size * (i + 1) for i in range(needed_pages)]
        
        # 收集所有响应数据
        all_responses = [first_data]
        
        # 尝试并行请求，失败则降级为串行
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            # 并行请求
            executor = ThreadPoolExecutor(max_workers=min(len(offsets), 5))
            futures = {}
            for offset in offsets:
                future = executor.submit(
                    self.am_get_node_child_as_tree_id_in_range,
                    asset_hub, query, offset, page_size, cached_key, api_version
                )
                futures[future] = offset
            
            for future in as_completed(futures):
                result = future.result()
                if result.is_succeeded():
                    data = result.result
                    # AM 接口可能返回列表，取第一个元素
                    if isinstance(data, list) and len(data) > 0:
                        data = data[0]
                    if isinstance(data, dict):
                        all_responses.append(data)
            
            executor.shutdown(wait=True)
        except (ImportError, Exception):
            # 降级为串行请求
            for offset in offsets:
                result = self.am_get_node_child_as_tree_id_in_range(
                    asset_hub, query, offset, page_size, cached_key, api_version
                )
                if result.is_succeeded():
                    data = result.result
                    # AM 接口可能返回列表，取第一个元素
                    if isinstance(data, list) and len(data) > 0:
                        data = data[0]
                    if isinstance(data, dict):
                        all_responses.append(data)
                else:
                    return result
        
        # 合并所有响应
        merged_data = self._merge_paginated_responses(all_responses, total_count, cached_key)
        
        # 精确截取前 target_count 个
        final_data = self._truncate_paginated_result(merged_data, target_count)
        
        # 返回成功响应（包装成列表保持接口一致性）
        first_res.set_result([final_data])
        first_res.results = {0: final_data}
        return first_res
    
    def _merge_paginated_responses(self, responses, total_count, cached_key):
        """合并多个分页响应（内部辅助方法）
        
        Args:
            responses: 响应数据列表
            total_count: 总节点数
            cached_key: 加速密钥
        
        Returns:
            dict: 合并后的数据
        """
        # 需要合并的数组字段
        array_fields = [
            'ids', 'depth', 'children_count', 'is_match_filter',
            'recursive_children_count', 'path', 'node_type'
        ]
        
        merged_data = {
            'count': total_count,
            'key': cached_key
        }
        
        # 初始化数组字段
        for field in array_fields:
            merged_data[field] = []
        
        # 合并所有响应的数组字段
        for response in responses:
            if not isinstance(response, dict):
                continue
            for field in array_fields:
                if field in response and isinstance(response[field], list):
                    merged_data[field].extend(response[field])
        
        return merged_data
    
    def _truncate_paginated_result(self, data, target_count):
        """精确截取分页结果的前 target_count 个元素（内部辅助方法）
        
        Args:
            data: 原始数据字典
            target_count: 目标数量
        
        Returns:
            dict: 截取后的数据
        """
        if not isinstance(data, dict):
            return data
        
        array_fields = [
            'ids', 'depth', 'children_count', 'is_match_filter',
            'recursive_children_count', 'path', 'node_type'
        ]
        
        result = dict(data)
        
        # 截取所有数组字段
        for field in array_fields:
            if field in result and isinstance(result[field], list):
                result[field] = result[field][:target_count]
        
        return result

    def am_get_task_list_by_version(self, asset_hub, version_id, filter=None, offset=0, count=100):
        r"""Get tasks under a version with simple filter.

        Example:

            filters = [{
                "bool": {"must": [{"item": {"condition": "eq", "meta": "type", "value": "Entity"}}]}
            }]
            res = open_api.am_get_task_list_by_version(
                asset_hub="test",
                version_id=120347777793462,
                filter=filters,
                count=100
            )
            if res.is_succeeded():
                payload = res.result

        :param asset_hub: str. Example: "cg_artdev".
        :param version_id: int. AM version node id.
        :param filter: list<dict>. Filter syntax passed to backend.
        :param offset: int. Starting offset (default 0).
        :param count: int. Number of tasks to return (default 100). Use -1 to get all tasks.
        :rtype: arthub_api.APIResponse
        """

        query = {
            "parent_id": version_id,
            "filter": filter or None,
            "skip_production_types": ["File", "Bug"],  # 排除 File 和 Bug 类型
        }

        # Use intelligent pagination if offset is 0 (most common case)
        if offset == 0:
            return self._am_fetch_nodes_paginated(
                asset_hub, query=query, target_count=count, api_version="v3"
            )
        else:
            # Legacy behavior: single request with specific offset
            # (kept for backward compatibility with offset-based pagination)
            return self.am_get_node_child_as_tree_id_in_range(
                asset_hub, query=query, offset=offset, page_size=count, api_version="v3"
            )
    
    def am_get_version_tree(self, asset_hub, project_id, filter=None, offset=0, count=-1):
        r"""Get tasks under a version with simple filter.

        Example:

            filters = [{
                "bool": {"must": [{"item": {"condition": "eq", "meta": "type", "value": "Entity"}}]}
            }]
            res = open_api.am_get_task_list_by_version(
                asset_hub="test",
                version_id=120347777793462,
                filter=filters,
                count=100
            )
            if res.is_succeeded():
                payload = res.result

        :param asset_hub: str. Example: "cg_artdev".
        :param version_id: int. AM version node id.
        :param filter: list<dict>. Filter syntax passed to backend.
        :param offset: int. Starting offset (default 0).
        :param count: int. Number of tasks to return (default 100). Use -1 to get all tasks.
        :rtype: arthub_api.APIResponse
        """

        query = {
            "parent_id": project_id,
            "filter": filter or None,
            "skip_production_types": ["File", "Bug", "Entity", "Stage", "OutsourcedEntity", "Link"],
            "recursive": False,
            "expand_matched": False,
            "order": [{"meta": "custom_order", "type": "desc"}],
        }

        # Use intelligent pagination if offset is 0 (most common case)
        return self.am_get_node_child_as_tree_id_in_range(
            asset_hub, query=query, offset=offset, page_size=count, api_version="v3"
        )
            

    def am_get_version_list(self, asset_hub, project_id):
        r"""Get AM version list for a project.

        Equivalent HTTP calls:
          1) get-node-child-with-preset-count
          2) get-node-child-with-preset-id-in-range

        Example:

            res = open_api.am_get_version_list(asset_hub="test", project_id=120347700000000)
            if res.is_succeeded():
                versions = res.result  # list[{"id","name"}]

        :param asset_hub: str. Example: "cg_artdev".
        :param project_id: int. Root node id of the AM project.
        :rtype: arthub_api.APIResponse
        """

        preset = "Business_Without_Unplanned"
        order = [{"meta": "name", "type": "asc"}]

        count_res = self.am_get_node_child_with_preset_count(asset_hub, project_id, preset)
        if not count_res.is_succeeded():
            return count_res

        count_value = count_res.first_result("count")
        if count_value is None:
            first_item = count_res.first_result()
            if isinstance(first_item, dict):
                count_value = first_item.get("count", 0)
            elif isinstance(first_item, int):
                count_value = first_item
            else:
                count_value = 0

        if count_value <= 0:
            count_res.set_result([])
            count_res.results = {}
            return count_res

        list_res = self.am_get_node_child_with_preset_id_in_range(
            asset_hub,
            node_id=project_id,
            preset=preset,
            offset=0,
            count=count_value,
            order=order,
            return_link_node=False,
            key="",
        )
        if not list_res.is_succeeded():
            return list_res

        # The preset id-in-range API returns items like {"node_id": xxx, "child_count": y}
        node_ids = []
        for item in list_res.result or []:
            if isinstance(item, dict):
                nid = item.get("node_id") or item.get("id")
                if nid is not None:
                    node_ids.append(nid)
            elif isinstance(item, int):
                node_ids.append(item)

        if not node_ids:
            list_res.set_result([])
            list_res.results = {}
            return list_res

        # Fetch names via get-node-brief, then project to [{id, name}, ...]
        brief_res = self.am_get_node_brief(asset_hub, node_ids)
        if not brief_res.is_succeeded():
            return brief_res

        name_by_id = {}
        for item in brief_res.result or []:
            if isinstance(item, dict):
                # AM get-node-brief returns {"node_id": ..., "properties": {"id": ..., "name": ...}, ...}
                nid = item.get("node_id")
                props = item.get("properties") if isinstance(item.get("properties"), dict) else {}
                if nid is None:
                    nid = props.get("id") or item.get("id")
                if nid is not None:
                    name_by_id[nid] = props.get("name") or item.get("name")

        versions = [{"id": nid, "name": name_by_id.get(nid)} for nid in node_ids]

        brief_res.set_result(versions)
        brief_res.results = {i: version for i, version in enumerate(versions)}
        return brief_res

    # ==================== Workflow APIs ====================

    def am_get_workflow_count(self, asset_hub):
        r"""Get the total count of workflows in asset matrix.

        API name: get-workflow-count

        Example:

            res = open_api.am_get_workflow_count(asset_hub="test")
            if res.is_succeeded():
                count = res.result.get('count')  # e.g. 17

        :param asset_hub: str. Example: "cg_artdev".
        :rtype: arthub_api.APIResponse
        """

        req_payload = {}
        return self.request_am(asset_hub, "get-workflow-count", req_payload)

    def am_get_workflow_id_in_range(self, asset_hub, offset=0, count=-1):
        r"""Get workflow IDs in the specified range.

        API name: get-workflow-id-in-range

        Example:

            res = open_api.am_get_workflow_id_in_range(asset_hub="test", offset=0, count=-1)
            if res.is_succeeded():
                workflow_ids = res.result  # list of workflow IDs

        :param asset_hub: str. Example: "cg_artdev".
        :param offset: int. Start offset, default 0.
        :param count: int. Number of items to retrieve, -1 for all.
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "offset": offset,
            "count": count
        }
        return self.request_am(asset_hub, "get-workflow-id-in-range", req_payload)

    def am_get_workflow_by_id(self, asset_hub, ids, disable_graph_data=False):
        r"""Get workflow details by IDs.

        API name: get-workflow-by-id

        Example:

            res = open_api.am_get_workflow_by_id(
                asset_hub="test",
                ids=[120347699877335, 120347699877352]
            )
            if res.is_succeeded():
                workflows = res.result  # list of workflow dicts
                for wf in workflows:
                    print(wf['name'])           # e.g. 'am_default_workflow'
                    print(wf['display_name'])   # e.g. '基础工作流'
                    print(wf['state'])          # list of state dicts
                    print(wf['transition'])     # list of transition dicts

        :param asset_hub: str. Example: "cg_artdev".
        :param ids: list<int>. List of workflow IDs.
        :param disable_graph_data: bool. Whether to disable graph data, default True.
        :rtype: arthub_api.APIResponse
        """

        req_payload = {
            "ids": ids,
            "disable_graph_data": disable_graph_data
        }
        return self.request_am(asset_hub, "get-workflow-by-id", req_payload)

    def am_get_all_workflows(self, asset_hub, disable_graph_data=True):
        r"""Get all workflows in asset matrix.

        This is a convenience wrapper around:
          1) get-workflow-id-in-range
          2) get-workflow-by-id

        Example:

            res = open_api.am_get_all_workflows(asset_hub="test")
            if res.is_succeeded():
                workflows = res.result  # list of workflow dicts
                for wf in workflows:
                    print(wf['id'], wf['display_name'])
                    # Each workflow contains: id, name, display_name, state, transition, etc.

        :param asset_hub: str. Example: "cg_artdev".
        :param disable_graph_data: bool. Whether to disable graph data, default True.
        :rtype: arthub_api.APIResponse
        """

        id_res = self.am_get_workflow_id_in_range(asset_hub, offset=0, count=-1)
        if not id_res.is_succeeded():
            return id_res

        workflow_ids = id_res.direct_result or []
        if not workflow_ids:
            id_res.set_result([])
            id_res.results = {}
            return id_res

        detail_res = self.am_get_workflow_by_id(asset_hub, workflow_ids, disable_graph_data)
        if not detail_res.is_succeeded():
            return detail_res

        workflows = []
        for item in detail_res.result or []:
            if isinstance(item, dict):
                workflows.append(item)

        detail_res.set_result(workflows)
        detail_res.results = {i: wf for i, wf in enumerate(workflows)}
        return detail_res

    def am_get_file_by_meta_and_task_id(self, asset_hub, items, in_children=False):
        r"""Get file brief by task id and file meta in asset matrix.

        Calls the "get-file-brief" API to retrieve file information (preview_url,
        display_url, intermediate_url, etc.) associated with tasks.

        :param asset_hub: str. Example: "yida".
        :param items: list<dict>. Each dict contains:
                {
                    "id": int, task node id,
                    "meta": str, file meta type. Example: "deliverable" | "reference",
                    "asset_ids": (optional) list<int>, filter by specific asset ids. Default [].
                    "only_main_version": (optional) bool, True to return only the main version. Default True.
                }
        :param in_children: (optional) bool. Whether to search in children nodes. Default False.
        :rtype: arthub_api.APIResponse

        Example::

            res = open_api.am_get_file_by_meta_and_task_id("yida", [
                {"id": 120347789277659, "meta": "deliverable", "only_main_version": True}
            ])
            if res.is_succeeded():
                for item in res.result:
                    print(item["id"], item["meta"], item["count"])
                    for f in item.get("files", []):
                        print("  ", f["name"], f["file_format"], f["capacity"])
        """

        normalized = []
        for item in items:
            normalized.append({
                "id": item["id"],
                "meta": item.get("meta", "deliverable"),
                "asset_ids": item.get("asset_ids", []),
                "only_main_version": item.get("only_main_version", True),
            })

        url = self._am_url(asset_hub, "get-file-brief")
        req_payload = {
            "items": normalized,
            "in_children": in_children,
        }
        return self._make_api_request(url, req_payload)

    def am_get_node_pan_directory_id(self, asset_hub, node_id):
        r"""Get the pan directory id of a deliverable asset node in asset matrix.

        Calls the "get-deliverable-asset-directory" API to retrieve the directory_id
        and full path information for a given node.

        :param asset_hub: str. Example: "yida".
        :param node_id: int. The node id. Example: 120347789384709.
        :rtype: arthub_api.APIResponse

        Response example (when directory exists)::

            res.result -> [
                {
                    "directory_id": 120347789980207,
                    "full_path_id": [120347481638733, 120347483054521, ...],
                    "full_path_name": ["AssetHub_yida", ".SYS_AM", ...]
                }
            ]

        Response example (when directory does not exist)::

            res.result -> []
        """

        req_payload = {"node_id": node_id}
        return self.request_am(asset_hub, "get-deliverable-asset-directory", req_payload)

    def am_upload_file_by_asset_id(self, asset_hub, node_id, asset_ids, meta="deliverable_v2"):
        r"""Upload files to an AM task node by asset ids.

        Calls the "upload-by-asset-id" API to associate existing pan assets
        with an AM task node as deliverables.

        :param asset_hub: str. Example: "yida".
        :param node_id: int. The AM task node id. Example: 120347799615192.
        :param asset_ids: list<int>. The asset ids to upload. Example: [120347811613180, 120347789980460].
        :param meta: str. The meta type, default "deliverable_v2".
        :rtype: arthub_api.APIResponse

        Response example::

            res.result -> [
                {
                    "id": 120347799615192,
                    "meta": "deliverable_v2",
                    "type": "node",
                    "asset_id": 120347823043937,
                    "param_index": 0,
                    "asset_name": "Char02 (1).jpg",
                    "file_uploaded_to_id": 120347823003145
                },
                ...
            ]
        """

        items = []
        for i, asset_id in enumerate(asset_ids):
            items.append({
                "param_index": i,
                "asset_id": asset_id,
                "meta": meta,
                "id": node_id,
            })

        req_payload = {"items": items}
        return self.request_am(asset_hub, "upload-by-asset-id", req_payload)