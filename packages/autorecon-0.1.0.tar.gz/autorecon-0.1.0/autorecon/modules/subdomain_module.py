"""Passive Subdomain Discovery Module."""

import asyncio
import aiohttp
from autorecon.models import SubdomainResult



async def scan(domain:str) -> list[SubdomainResult]:

    url = f"https://crt.sh/?q=%25.{domain}&output=json"

    results = []

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                
                data = await response.json()
                
                subs = set()
                for entry in data:
                    
                    name_value = entry["name_value"]

                    for sub in name_value.split("\n"):
                        subs.add(sub)

                for sub in subs:
                    results.append(SubdomainResult(subdomain=sub, source="crt.sh"))

        except Exception:
            return [SubdomainResult(subdomain=domain, source="crt.sh")]
        
    return results





        

