"""DNS Enumeration Module."""

import asyncio
import dns.resolver
from autorecon.models import DNSRecord, DNSResult

RECORD_TYPES = ["A", "AAAA", "MX", "TXT", "NS", "SOA"]


def _resolve_sync(domain: str, record_type: str) -> list[DNSRecord]:
    """Synchroner Lookup - wird in einen Thread ausgelagert."""
    records = []
    try:
        answers = dns.resolver.resolve(domain, record_type)
        ttl = answers.rrset.ttl if answers.rrset else 0
        for rdata in answers:
            records.append(
                DNSRecord(
                    record_type=record_type,
                    value=str(rdata),
                    ttl=ttl,
                )
            )
    except Exception:
        pass  # Record-Typ existiert nicht für diese Domain
    return records


async def scan(domain: str) -> DNSResult:
    records: list[DNSRecord] = []

    tasks = [
        asyncio.to_thread(_resolve_sync, domain, rt) for rt in RECORD_TYPES
    ]

    results = await asyncio.gather(*tasks)
    for record_list in results:
        records.extend(record_list)

    return DNSResult(domain=domain, records=records)
