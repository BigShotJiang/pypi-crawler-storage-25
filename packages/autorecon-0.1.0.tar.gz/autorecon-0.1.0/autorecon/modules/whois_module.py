"""Whois Lookup Module."""

import asyncio
import whois
from autorecon.models import WhoisResult


def _normalize_date(value) -> str | None:
    """Datetime oder Liste von datetimes zu String normalisieren."""
    if value is None:
        return None
    if isinstance(value, list):
        value = value[0]
    return str(value)


def _normalize_nameservers(value) -> list[str]:
    """Nameservers (set, list oder None) zu list[str] normalisieren."""
    if not value:
        return []
    if isinstance(value, set):
        return sorted(str(ns) for ns in value)
    return [str(ns) for ns in value]


def _resolve_sync(domain: str) -> WhoisResult:
    """Synchroner Lookup - wird in einen Thread ausgelagert."""
    try:
        w = whois.whois(domain)

        return WhoisResult(
            domain=domain,
            registrar=w.registrar,
            creation_date=_normalize_date(w.creation_date),
            expiration_date=_normalize_date(w.expiration_date),
            nameservers=_normalize_nameservers(w.name_servers),
        )
    except Exception:
        return WhoisResult(domain=domain)


async def scan(domain: str) -> WhoisResult:
    return await asyncio.to_thread(_resolve_sync, domain)
