"""SSL Certificate Analysis Module."""

import ssl
import socket
import asyncio
from autorecon.models import SSLResult



def _extract_dn(dn_tuple) -> str:
    """DN-Tuple zu String: 'US, Google Trust Services, WE2'"""
    return ", ".join(attr[1] for rdn in dn_tuple for attr in rdn)


def _normalize_data(certificate:dict) -> dict:
    
    cert = {}

    cert["issuer"] = _extract_dn(certificate["issuer"])
    cert["subject"] = _extract_dn(certificate["subject"])

    cert["subjectAltName"] = [entry[1] for entry in certificate["subjectAltName"]]

    cert["not_before"] = certificate["notBefore"]
    cert["not_after"] = certificate["notAfter"]

    return cert


def _resolve_sync(domain:str) -> SSLResult:

        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((domain, 443), 5.0) as sock:
                with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                        cert = ssock.getpeercert()

            cert = _normalize_data(cert)

            return SSLResult(
                domain=domain,
                issuer=cert["issuer"],
                subject=cert["subject"],
                not_before=cert["not_before"],
                not_after=cert["not_after"],
                san=cert["subjectAltName"]
            )
        except:
              return SSLResult(domain=domain)


async def scan(domain:str) -> SSLResult:
      
      return await asyncio.to_thread(_resolve_sync, domain)