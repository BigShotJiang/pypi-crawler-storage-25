"""Technology Stack Detection Module."""

import asyncio
import aiohttp
from autorecon.models import TechResult

TECH_RULES = [
    ("X-Generator", None, "CMS"),
    ("X-Powered-By", None, "Language"),
    ("X-AspNet-Version", "ASP.NET", "Framework"),
]


async def _try_request(session: aiohttp.ClientSession, url: str) -> aiohttp.ClientResponse | None:
    """Request mit Fehlerbehandlung - gibt None zurück wenn es scheitert."""
    try:
        resp = await session.get(url, timeout=aiohttp.ClientTimeout(total=10), ssl=False)
        return resp
    except Exception:
        return None


async def scan(domain: str) -> list[TechResult]:
    results: list[TechResult] = []

    async with aiohttp.ClientSession() as session:
        # Zuerst HTTPS, dann HTTP als Fallback
        response = await _try_request(session, f"https://{domain}")
        if response is None:
            response = await _try_request(session, f"http://{domain}")
        if response is None:
            return []

        # Server Header parsen
        server = response.headers.get("Server", "")
        if server:
            parts = server.split("/", 1)
            name = parts[0]
            version = parts[1] if len(parts) > 1 else None
            results.append(TechResult(name=name, version=version, category="Web Server"))

        # Weitere Header prüfen
        for header_name, fixed_name, category in TECH_RULES:
            value = response.headers.get(header_name)
            if value:
                results.append(TechResult(name=fixed_name or value, category=category))

    return results
