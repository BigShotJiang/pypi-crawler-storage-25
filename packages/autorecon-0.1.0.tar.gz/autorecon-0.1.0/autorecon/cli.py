"""AutoRecon CLI Entry Point."""

import asyncio

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel

from autorecon.scanner import scan
from autorecon.modules import dns_module, whois_module, ssl_module, subdomain_module, tech_module
from autorecon.models import ReconReport

app = typer.Typer()
console = Console()


async def scan_with_progress(domain: str) -> ReconReport:
    """Scan mit Live-Fortschrittsanzeige."""

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    )

    with progress:
        task_dns = progress.add_task("[cyan]DNS Enumeration...", total=None)
        task_whois = progress.add_task("[cyan]Whois Lookup...", total=None)
        task_ssl = progress.add_task("[cyan]SSL Analysis...", total=None)
        task_subs = progress.add_task("[cyan]Subdomain Discovery...", total=None)
        task_tech = progress.add_task("[cyan]Tech Detection...", total=None)

        async def run_dns():
            result = await dns_module.scan(domain)
            progress.update(task_dns, description="[green]✓ DNS Enumeration")
            return result

        async def run_whois():
            result = await whois_module.scan(domain)
            progress.update(task_whois, description="[green]✓ Whois Lookup")
            return result

        async def run_ssl():
            result = await ssl_module.scan(domain)
            progress.update(task_ssl, description="[green]✓ SSL Analysis")
            return result

        async def run_subs():
            result = await subdomain_module.scan(domain)
            count = len(result)
            progress.update(task_subs, description=f"[green]✓ Subdomain Discovery ({count} found)")
            return result

        async def run_tech():
            result = await tech_module.scan(domain)
            count = len(result)
            progress.update(task_tech, description=f"[green]✓ Tech Detection ({count} found)")
            return result

        results = await asyncio.gather(
            run_dns(), run_whois(), run_ssl(), run_subs(), run_tech(),
            return_exceptions=True,
        )

    dns, whois, ssl, subs, techs = results

    return ReconReport(
        target=domain,
        dns=dns if not isinstance(dns, Exception) else None,
        whois=whois if not isinstance(whois, Exception) else None,
        ssl=ssl if not isinstance(ssl, Exception) else None,
        subdomains=subs if not isinstance(subs, Exception) else [],
        technologies=techs if not isinstance(techs, Exception) else [],
    )


@app.command()
def main(
    domain: str,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    output: str = typer.Option(None, "--output", "-o", help="Save to file"),
):
    console.print(Panel(f"[bold]AutoRecon[/bold] - Scanning [cyan]{domain}[/cyan]", border_style="green"))

    report = asyncio.run(scan_with_progress(domain))
    console.print()

    if json_output:
        content = report.to_json()
    else:
        content = report.to_markdown()

    if output:
        with open(output, "w") as f:
            f.write(content)
        console.print(f"[green]Report saved to {output}[/green]")
    else:
        console.print(Panel(content, border_style="blue"))


if __name__ == "__main__":
    app()
