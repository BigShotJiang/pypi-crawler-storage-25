"""Pydantic Data Models für Recon-Ergebnisse."""

from __future__ import annotations
from datetime import datetime
from pydantic import BaseModel, ConfigDict


class DNSRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    record_type: str
    value: str
    ttl: int


class DNSResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    domain: str
    records: list[DNSRecord] = []


class WhoisResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    domain: str
    registrar: str | None = None
    creation_date: str | None = None
    expiration_date: str | None = None
    nameservers: list[str] = []


class SSLResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    domain: str
    issuer: str | None = None
    subject: str | None = None
    not_before: str | None = None
    not_after: str | None = None
    san: list[str] = []


class SubdomainResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    subdomain: str
    source: str


class TechResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    version: str | None = None
    category: str = "Unknown"


class ReconReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target: str
    timestamp: str = ""
    dns: DNSResult | None = None
    whois: WhoisResult | None = None
    ssl: SSLResult | None = None
    subdomains: list[SubdomainResult] = []
    technologies: list[TechResult] = []

    def model_post_init(self, __context) -> None:
        if not self.timestamp:
            object.__setattr__(self, "timestamp", datetime.now().isoformat())

    def to_json(self) -> str:
        return self.model_dump_json(indent=2)

    def to_markdown(self) -> str:
        lines = [
            f"# AutoRecon Report: {self.target}",
            f"**Timestamp:** {self.timestamp}",
            "",
        ]

        if self.dns:
            lines.append("## DNS Records")
            lines.append("")
            for r in self.dns.records:
                lines.append(f"- **{r.record_type}** `{r.value}` (TTL: {r.ttl})")
            lines.append("")

        if self.whois:
            lines.append("## Whois")
            lines.append("")
            lines.append(f"- **Registrar:** {self.whois.registrar or 'N/A'}")
            lines.append(f"- **Created:** {self.whois.creation_date or 'N/A'}")
            lines.append(f"- **Expires:** {self.whois.expiration_date or 'N/A'}")
            if self.whois.nameservers:
                lines.append(f"- **Nameservers:** {', '.join(self.whois.nameservers)}")
            lines.append("")

        if self.ssl:
            lines.append("## SSL Certificate")
            lines.append("")
            lines.append(f"- **Issuer:** {self.ssl.issuer or 'N/A'}")
            lines.append(f"- **Subject:** {self.ssl.subject or 'N/A'}")
            lines.append(f"- **Valid From:** {self.ssl.not_before or 'N/A'}")
            lines.append(f"- **Valid Until:** {self.ssl.not_after or 'N/A'}")
            if self.ssl.san:
                lines.append(f"- **SANs:** {', '.join(self.ssl.san)}")
            lines.append("")

        if self.subdomains:
            lines.append("## Discovered Subdomains")
            lines.append("")
            for s in self.subdomains:
                lines.append(f"- `{s.subdomain}` (via {s.source})")
            lines.append("")

        if self.technologies:
            lines.append("## Detected Technologies")
            lines.append("")
            for t in self.technologies:
                version = f" v{t.version}" if t.version else ""
                lines.append(f"- **{t.name}**{version} ({t.category})")
            lines.append("")

        return "\n".join(lines)
