"""Entry Point für `python -m autorecon`."""

from autorecon.cli import app

app()
