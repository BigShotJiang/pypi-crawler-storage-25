2026-05-07 Version: 1.7.0
- Support API CreateJobTemplate.
- Support API DeleteJobTemplate.
- Support API GetJobTemplate.
- Support API ListJobTemplates.
- Support API SetJobTemplateDefaultVersion.
- Support API UpdateJobTemplate.


2026-04-28 Version: 1.6.14
- Generated python 2020-12-03 for pai-dlc.

2026-04-16 Version: 1.6.13
- Generated python 2020-12-03 for pai-dlc.

2026-04-09 Version: 1.6.12
- Update API CreateJob: add request parameters body.Description.
- Update API GetJob: add response parameters Body.Description.
- Update API ListJobs: add request parameters Description.
- Update API UpdateJob: add request parameters body.Description.


2026-04-09 Version: 1.6.12
- Update API CreateJob: add request parameters body.Description.
- Update API GetJob: add response parameters Body.Description.
- Update API ListJobs: add request parameters Description.
- Update API UpdateJob: add request parameters body.Description.


2026-04-09 Version: 1.6.12
- Update API CreateJob: add request parameters body.Description.
- Update API GetJob: add response parameters Body.Description.
- Update API ListJobs: add request parameters Description.
- Update API UpdateJob: add request parameters body.Description.


2026-03-18 Version: 1.6.11
- Update API CreateJob: add request parameters body.DataSources.$.AccessPointId.
- Update API CreateJob: add request parameters body.DataSources.$.RoleChain.
- Update API GetJob: add response parameters Body.RoleSystemEnvs.


2026-02-12 Version: 1.6.10
- Update API CreateJob: add request parameters body.TemplateId.
- Update API CreateJob: add request parameters body.TemplateVersion.
- Update API ListJobs: add request parameters TemplateId.


2026-02-09 Version: 1.6.9
- Generated python 2020-12-03 for pai-dlc.

2026-02-03 Version: 1.6.8
- Update API CreateJob: add request parameters body.CustomEnvs.
- Update API GetJob: add response parameters Body.CustomEnvs.


2026-01-16 Version: 1.6.7
- Update API ListJobs: add request parameters EnableAssignNode.
- Update API ListJobs: add request parameters ImageSearch.
- Update API ListJobs: add request parameters NumericRangeField.
- Update API ListJobs: add request parameters NumericRangeMax.
- Update API ListJobs: add request parameters NumericRangeMin.
- Update API ListJobs: add request parameters ReasonSearch.
- Update API ListJobs: add request parameters TimeRangeField.
- Update API ListJobs: add request parameters UserCommandSearch.


2026-01-12 Version: 1.6.6
- Generated python 2020-12-03 for pai-dlc.

2025-11-18 Version: 1.6.5
- Update API GetJob: add response parameters Body.Pods.$.Duration.
- Update API GetJob: add response parameters Body.Pods.$.NodeName.
- Update API GetJob: add response parameters Body.Pods.$.PodIps.
- Update API GetJob: add response parameters Body.Pods.$.HistoryPods.$.Duration.
- Update API GetJob: add response parameters Body.Pods.$.HistoryPods.$.NodeName.
- Update API GetJob: add response parameters Body.Pods.$.HistoryPods.$.PodIps.


2025-11-17 Version: 1.6.4
- Generated python 2020-12-03 for pai-dlc.

2025-11-10 Version: 1.6.3
- Update API GetJob: add response parameters Body.JobReplicaStatuses.
- Update API UpdateJob: add request parameters body.JobSpecs.


2025-10-17 Version: 1.6.2
- Update API ListJobs: add request parameters DisplayNameSearchMode.


2025-10-09 Version: 1.6.1
- Generated python 2020-12-03 for pai-dlc.

2025-09-22 Version: 1.6.0
- Support API GetDashboard.


2025-09-22 Version: 1.6.0
- Support API GetDashboard.


2025-09-15 Version: 1.5.7
- Update API GetJob: add response parameters Body.RestartRecord.


2025-08-22 Version: 1.5.6
- Generated python 2020-12-03 for pai-dlc.

2025-07-30 Version: 1.5.5
- Update API CreateJob: add request parameters body.DataSources.$.EnableCache.


2025-07-30 Version: 1.5.5
- Update API CreateJob: add request parameters body.DataSources.$.EnableCache.


2025-05-26 Version: 1.5.4
- Generated python 2020-12-03 for pai-dlc.

2025-05-20 Version: 1.5.3
- Generated python 2020-12-03 for pai-dlc.

2025-05-07 Version: 1.5.2
- Update API ListJobs: add request parameters JobIds.


2025-04-18 Version: 1.5.1
- Generated python 2020-12-03 for pai-dlc.

2025-04-17 Version: 1.5.0
- Support API GetRayDashboard.


2025-04-02 Version: 1.4.21
- Update API CreateJob: add request parameters body.DataSources.$.MountAccess.


2025-01-22 Version: 1.4.20
- Generated python 2020-12-03 for pai-dlc.

2025-01-21 Version: 1.4.19
- Update API ListJobs: add param PaymentType.


2024-12-18 Version: 1.4.18
- Update API CreateJob: update param body.
- Update API GetJob: update response param.


2024-12-17 Version: 1.4.17
- Generated python 2020-12-03 for pai-dlc.

2024-12-06 Version: 1.4.16
- Update API ListJobs: add param OversoldInfo.


2024-11-18 Version: 1.4.15
- Update API UpdateTensorboard: add param Priority.


2024-10-29 Version: 1.4.14
- Update API DeleteJob: update response param.
- Update API GetJob: update response param.
- Update API ListJobs: update param Accessibility.
- Update API UpdateJob: update param body.
- Update API UpdateTensorboard: add param Accessibility.


2024-08-20 Version: 1.4.13
- Update API CreateJob: update param body.
- Update API CreateTensorboard: update param body.
- Update API ListJobs: add param Accessibility.
- Update API ListJobs: update param Order.
- Update API ListTensorboards: add param Accessibility.


2024-08-16 Version: 1.4.12
- Generated python 2020-12-03 for pai-dlc.

2024-08-09 Version: 1.4.11
- Update API CreateJob: update param body.


2024-07-11 Version: 1.4.10
- Update API CreateTensorboard: update param body.
- Update API ListTensorboards: add param QuotaId.


2024-07-09 Version: 1.4.9
- Update API GetJob: update response param.


2024-07-05 Version: 1.4.8
- Update API CreateJob: update param body.


2024-07-04 Version: 1.4.7
- Generated python 2020-12-03 for pai-dlc.

2024-06-06 Version: 1.4.6
- Update API ListTensorboards: add param UserId.
- Update API ListTensorboards: add param Username.


2024-04-09 Version: 1.4.5
- Update API CreateTensorboard: update param body.
- Update API ListJobs: add param ResourceQuotaName.
- Update API ListTensorboards: add param PaymentType.


2024-03-28 Version: 1.4.4
- Update API CreateTensorboard: update param body.
- Update API ListTensorboards: add param PaymentType.


2024-03-20 Version: 1.4.3
- Update API GetJobSanityCheckResult: update param JobId.
- Update API ListJobSanityCheckResults: update param JobId.


2024-02-27 Version: 1.4.2
- Update API GetJobSanityCheckResult: update param JobId.
- Update API ListJobSanityCheckResults: update param JobId.


2024-01-24 Version: 1.4.1
- Generated python 2020-12-03 for pai-dlc.

2024-01-08 Version: 1.4.0
- Generated python 2020-12-03 for pai-dlc.

2023-12-20 Version: 1.3.5
- Generated python 2020-12-03 for pai-dlc.

2023-12-15 Version: 1.3.4
- Generated python 2020-12-03 for pai-dlc.

2023-12-14 Version: 1.3.3
- Generated python 2020-12-03 for pai-dlc.

2023-11-07 Version: 1.3.2
- Generated python 2020-12-03 for pai-dlc.

2023-09-11 Version: 1.3.1
- Generated python 2020-12-03 for pai-dlc.

2023-08-11 Version: 1.3.0
- Generated python 2020-12-03 for pai-dlc.

2023-08-10 Version: 1.2.10
- Generated python 2020-12-03 for pai-dlc.

2023-07-26 Version: 1.2.9
- Open the api GetToken.

2023-07-21 Version: 1.2.8
- Change the API -- GetWebTerminal.

2023-07-19 Version: 1.2.7
- Open the API.

2023-05-26 Version: 1.2.6
- Add parameter in JobElasticSpec.

2023-03-23 Version: 1.2.5
- Change the type of RequestId to string in GetJobEvents API.

2023-01-04 Version: 1.2.4
- Support images from private docker registry.

2022-12-13 Version: 1.2.3
- CreateJob supports params SuccessPolicy.

2022-07-26 Version: 1.2.1
- Support to automatically fill in endpoint according to region.

2022-07-26 Version: 1.2.0
- Upgrade SDK version.

2022-07-22 Version: 1.1.5
- Support change the priority of jobs in queue.

2022-07-21 Version: 1.1.4
- Update tensorboard API support temporary NAS or OSS path.
- Support default workspace.
- Support prepaid resourceGroup.

2021-11-25 Version: 1.1.3
- Support Tensorboard.

2021-09-27 Version: 1.1.2
- SDK for python, Java, Go.

2021-04-22 Version: 1.0.0
- Add Oss support.

