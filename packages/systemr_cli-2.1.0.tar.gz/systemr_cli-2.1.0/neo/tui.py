"""Terminal UI Application — fixed-layout chat interface.

Full-screen prompt_toolkit Application with:
- Scrollable conversation area (top) with auto-scroll
- Fixed separator + input prompt (middle)
- Fixed separator + live status bar (bottom)

Keyboard shortcuts:
- Enter: submit message
- Ctrl+D / Ctrl+C: exit
- Ctrl+L: clear conversation
- Page Up/Down: scroll conversation
- Up/Down: input history
- Escape: cancel current input
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable

from prompt_toolkit import Application
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import (
    HSplit,
    Window,
    FormattedTextControl,
    BufferControl,
    ScrollablePane,
)
from prompt_toolkit.layout.layout import Layout
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.styles import Style

# ── Colors (match theme.py) ──
GREEN = "#3ECF8E"
GREEN_DIM = "#34B87A"
RED = "#EF4444"
DIM = "#52525B"
MUTED = "#3F3F46"
GRAY = "#A1A1AA"
WHITE = "#F5F5F5"
AMBER = "#F59E0B"
BG = "#09090B"
BG_INPUT = "#111114"

# ── Prompt toolkit style ──
TUI_STYLE = Style.from_dict({
    # Conversation area
    "conversation": f"bg:{BG} {GRAY}",
    # Input area
    "input-prompt": f"bold {WHITE}",
    # Separators
    "separator": MUTED,
    # Status bar
    "status": f"bg:{BG_INPUT} {DIM}",
    "status.green": GREEN,
    "status.red": RED,
    "status.dim": DIM,
    "status.muted": MUTED,
    # Auto-suggest
    "auto-suggest": DIM,
})


class ChatTUI:
    """Fixed-layout terminal chat interface.

    Layout:
        ┌──────────────────────────────────────┐
        │ [Scrollable conversation]             │
        │   ◐ Thinking...                       │
        │   ┃ Streaming response...             │
        │   ✓ tool_name  $0.003                 │
        ├──────────────────────────────────────┤
        │ ❯ user input                          │
        ├──────────────────────────────────────┤
        │ ● sonnet │ ○ broker │ /help  │ 2m 3s │
        └──────────────────────────────────────┘
    """

    def __init__(
        self,
        model: str = "sonnet",
        broker: str | None = None,
        history_file: str = "",
    ) -> None:
        self._model = model
        self._broker = broker
        self._conversation_lines: list[tuple[str, str]] = []
        self._running = True
        self._input_ready = asyncio.Event()
        self._last_input = ""
        self._credits_used: float = 0.0
        self._tools_called: int = 0
        self._start_time = time.time()
        self._processing = False

        # Conversation display
        self._conversation_control = FormattedTextControl(
            text=self._get_conversation_text,
            focusable=False,
        )

        # Scrollable conversation window
        self._conversation_window = Window(
            content=self._conversation_control,
            wrap_lines=True,
        )

        # Input buffer
        self._input_buffer = Buffer(
            name="input",
            history=FileHistory(history_file) if history_file else None,
            auto_suggest=AutoSuggestFromHistory(),
            accept_handler=self._on_accept,
            multiline=False,
        )

        # Separator
        self._sep_control = FormattedTextControl(
            text=lambda: FormattedText([(MUTED, "─" * 300)]),
            focusable=False,
        )

        # Status bar
        self._status_control = FormattedTextControl(
            text=self._get_status_text,
            focusable=False,
        )

        # Key bindings
        kb = KeyBindings()

        @kb.add("c-d")
        def _exit(event: Any) -> None:
            self._running = False
            self._input_ready.set()
            event.app.exit(result=None)

        @kb.add("c-c")
        def _interrupt(event: Any) -> None:
            if self._processing:
                # During processing: just signal (future: cancel stream)
                pass
            else:
                self._running = False
                self._input_ready.set()
                event.app.exit(result=None)

        @kb.add("c-l")
        def _clear_screen(event: Any) -> None:
            self._conversation_lines.clear()
            self._invalidate()

        @kb.add("escape")
        def _cancel_input(event: Any) -> None:
            self._input_buffer.text = ""

        # Layout
        self._layout = Layout(
            HSplit([
                # Scrollable conversation (takes all available space)
                ScrollablePane(
                    self._conversation_window,
                ),
                # Top separator
                Window(content=self._sep_control, height=1),
                # Input line with ❯ prefix
                Window(
                    content=BufferControl(buffer=self._input_buffer),
                    height=1,
                    get_line_prefix=lambda lineno, wrap: FormattedText(
                        [("bold " + WHITE, "  ❯ ")]
                    ),
                ),
                # Bottom separator
                Window(content=self._sep_control, height=1),
                # Status bar
                Window(content=self._status_control, height=1),
            ]),
            focused_element=self._input_buffer,
        )

        # Application
        self._app: Application[str | None] = Application(
            layout=self._layout,
            key_bindings=kb,
            full_screen=True,
            mouse_support=True,
            style=TUI_STYLE,
        )

    # ── Internal handlers ──

    def _on_accept(self, buffer: Buffer) -> bool:
        """Handle Enter press."""
        text = buffer.text.strip()
        if text:
            # Echo user input in conversation
            self._conversation_lines.append((WHITE, f"\n  ❯ {text}\n"))
        self._last_input = text
        self._input_ready.set()
        return False

    def _get_conversation_text(self) -> FormattedText:
        """Render conversation area."""
        if not self._conversation_lines:
            return FormattedText([
                (DIM, "\n"),
                (DIM, "  Type your message below.\n"),
                (DIM, "  /help for commands. Ctrl+D to exit.\n"),
            ])
        return FormattedText(self._conversation_lines)

    def _get_status_text(self) -> FormattedText:
        """Render status bar with live data."""
        elapsed = int(time.time() - self._start_time)
        mins, secs = divmod(elapsed, 60)
        time_str = f"{mins}m {secs}s" if mins else f"{secs}s"

        parts: list[tuple[str, str]] = [("", "  ")]

        # Model
        parts.append((GREEN, "● "))
        parts.append((DIM, self._model))
        parts.append((MUTED, "  │  "))

        # Broker
        if self._broker:
            parts.append((GREEN, "● "))
            parts.append((DIM, self._broker))
        else:
            parts.append((RED, "○ "))
            parts.append((DIM, "no broker"))
        parts.append((MUTED, "  │  "))

        # Stats
        if self._tools_called > 0:
            parts.append((DIM, f"{self._tools_called} tools"))
            parts.append((MUTED, "  │  "))

        if self._credits_used > 0:
            parts.append((DIM, f"${self._credits_used:.3f}"))
            parts.append((MUTED, "  │  "))

        # Timer
        parts.append((DIM, time_str))
        parts.append((MUTED, "  │  "))

        # Help hint
        parts.append((DIM, "/help"))

        return FormattedText(parts)

    # ── Public API ──

    def add_line(self, style: str, text: str) -> None:
        """Add a line to conversation."""
        self._conversation_lines.append((style, text + "\n"))
        self._scroll_to_bottom()

    def add_text(self, style: str, text: str) -> None:
        """Add inline text (no newline) for streaming."""
        self._conversation_lines.append((style, text))
        self._scroll_to_bottom()

    def add_thinking(self, text: str) -> None:
        """Show thinking status. Replaces previous thinking line."""
        # Remove previous thinking line if exists
        if (self._conversation_lines and
                self._conversation_lines[-1][1].startswith("  ◐")):
            self._conversation_lines.pop()
        self._conversation_lines.append((DIM, f"  ◐ {text}\n"))
        self._scroll_to_bottom()

    def clear_thinking(self) -> None:
        """Remove the current thinking line."""
        if (self._conversation_lines and
                self._conversation_lines[-1][1].strip().startswith("◐")):
            self._conversation_lines.pop()
            self._invalidate()

    def add_tool_running(self, name: str) -> None:
        """Show tool starting."""
        self.clear_thinking()
        self.add_line(DIM, f"  ◐ {name}...")

    def add_tool_done(self, name: str, cost: str = "") -> None:
        """Show tool completed."""
        # Replace running line
        if (self._conversation_lines and
                "◐" in self._conversation_lines[-1][1]):
            self._conversation_lines.pop()
        suffix = f"  {cost}" if cost else ""
        self.add_line(GREEN, f"  ✓ {name}{suffix}")
        self._tools_called += 1

    def add_tool_error(self, name: str, error: str = "") -> None:
        """Show tool error."""
        if (self._conversation_lines and
                "◐" in self._conversation_lines[-1][1]):
            self._conversation_lines.pop()
        suffix = f"  {error}" if error else ""
        self.add_line(RED, f"  ✗ {name}{suffix}")

    def add_error(self, msg: str) -> None:
        """Show error message."""
        self.clear_thinking()
        self.add_line(RED, f"  ✗ {msg}")

    def start_response(self) -> None:
        """Start a new response block with green border."""
        self.clear_thinking()
        self.add_text(GREEN, "\n  ┃ ")

    def stream_text(self, text: str) -> None:
        """Stream text within a response block, char by char."""
        for ch in text:
            if ch == "\n":
                self._conversation_lines.append((GREEN, "\n  ┃ "))
            else:
                self._conversation_lines.append(("", ch))
        self._scroll_to_bottom()

    def end_response(self, elapsed: float) -> None:
        """End response block with timing."""
        self.add_text(GREEN, "\n  ┃")
        self.add_line(DIM, f"\n  ✦ {elapsed:.1f}s")
        self.add_text("", "\n")

    def add_credits(self, amount: float) -> None:
        """Track credits used (updates status bar)."""
        self._credits_used += amount
        self._invalidate()

    def set_model(self, model: str) -> None:
        """Update model in status bar."""
        self._model = model
        self._invalidate()

    def set_broker(self, broker: str | None) -> None:
        """Update broker in status bar."""
        self._broker = broker
        self._invalidate()

    def set_processing(self, active: bool) -> None:
        """Set processing state (affects Ctrl+C behavior)."""
        self._processing = active
        self._invalidate()

    def clear_conversation(self) -> None:
        """Clear conversation area."""
        self._conversation_lines.clear()
        self._invalidate()

    def _scroll_to_bottom(self) -> None:
        """Scroll conversation to bottom and redraw."""
        self._invalidate()

    def _invalidate(self) -> None:
        """Request UI redraw."""
        if self._app and self._app.is_running:
            self._app.invalidate()

    async def wait_for_input(self) -> str | None:
        """Wait for user to submit input. Returns None on exit."""
        self._input_ready.clear()
        self._input_buffer.text = ""
        self._processing = False
        self._invalidate()

        await self._input_ready.wait()

        if not self._running:
            return None
        self._processing = True
        return self._last_input

    async def run_async(self) -> None:
        """Start the TUI application."""
        await self._app.run_async()

    def exit(self) -> None:
        """Exit the application."""
        self._running = False
        self._input_ready.set()
        if self._app.is_running:
            self._app.exit()
