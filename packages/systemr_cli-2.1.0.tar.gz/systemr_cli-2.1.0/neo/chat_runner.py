"""Chat runner — TUI-based chat loop with fixed layout.

Manages the full-screen TUI application while processing
chat events (streaming, tools, confirmations) in the background.
The TUI stays responsive during all operations.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import structlog

from neo.credits import SessionCredits
from neo.hooks import HookEvent, fire_hook
from neo.profile import (
    append_daily_log,
    auto_save_rule_violation,
    load_daily_context,
    load_profile,
    load_rules,
    load_standing_orders,
    profile_exists,
    search_memory,
)
from neo.streaming import (
    ChatRequest,
    call_tool,
    chat_blocking,
    send_confirmation,
    stream_chat,
)
from neo.tool_router import match_tool
from neo.tui import ChatTUI

logger = structlog.get_logger(module="chat_runner")


async def run_chat_tui(
    tui: ChatTUI,
    access_token: str,
    credits: SessionCredits,
    store: Any,
    db_session_id: int,
    messages: list[dict[str, str]],
    model: str | None = None,
    research: bool = False,
) -> None:
    """Run the chat loop inside the TUI.

    Alternates between waiting for user input and processing
    the response (streaming, tool calls, etc.). The TUI handles
    all display.
    """
    from neo.commands.chat_commands import (
        COMPACTION_THRESHOLD,
        _compact_history,
        _handle_slash_command,
    )

    current_model = model

    while True:
        user_input = await tui.wait_for_input()
        if user_input is None:
            break
        if not user_input:
            continue

        # Slash commands
        if user_input.startswith("/"):
            if user_input.strip() in ("/q", "/exit", "/quit"):
                break
            if user_input.strip() == "/clear":
                messages.clear()
                tui.clear_conversation()
                tui.add_line("#3ECF8E", "  ✓ Conversation cleared.")
                continue
            if user_input.strip() == "/help":
                _show_help(tui)
                continue
            if user_input.strip() == "/credits":
                s = credits.summary()
                tui.add_line("#A1A1AA", f"\n  Credits: ${s['credits_used']:.3f} used  │  {s['tools_called']} tools  │  {s['duration_min']}m")
                continue
            if user_input.startswith("/remember "):
                text = user_input[10:].strip()
                if text:
                    from neo.profile import auto_save_explicit
                    auto_save_explicit(text)
                    tui.add_line("#3ECF8E", f"  ✓ Saved to memory.")
                continue
            if user_input.startswith("/memory "):
                query = user_input[8:].strip()
                if query:
                    results = search_memory(query)
                    if results:
                        for r in results[:5]:
                            tui.add_line("#A1A1AA", f"  {r}")
                    else:
                        tui.add_line("#52525B", "  No memories found.")
                continue
            # Other slash commands: pass to backend as regular chat
            tui.add_line("#52525B", f"  Unknown command. /help for available commands.")
            continue

        store.add_chat_message(db_session_id, "user", user_input)
        messages.append({"role": "user", "content": user_input})

        # Tool pre-routing
        tool_match_result = match_tool(user_input)
        if tool_match_result:
            tui.add_tool_running(tool_match_result.tool_name)
            try:
                tool_result = await call_tool(
                    tool_match_result.tool_name, tool_match_result.arguments
                )
                result_data = tool_result.get("result", {})
                cost = tool_result.get("cost_usdc") or (
                    result_data.get("cost_usdc", "") if isinstance(result_data, dict) else ""
                )
                tui.add_tool_done(
                    tool_match_result.tool_name,
                    f"${cost}" if cost else "",
                )
                if isinstance(result_data, dict):
                    tui.add_text("", "\n")
                    for k, v in result_data.items():
                        if k == "cost_usdc":
                            continue
                        if v is not None and str(v).strip():
                            tui.add_line("#A1A1AA", f"  {k}: ")
                            tui.add_text("#F5F5F5", str(v))
                    tui.add_text("", "\n")
                credits.add_response(credits_used=cost, tools=1)
                reply = f"Tool {tool_match_result.tool_name}: {str(result_data)[:200]}"
                store.add_chat_message(db_session_id, "assistant", reply)
                messages.append({"role": "assistant", "content": reply})
            except Exception as e:
                err = str(e)
                if "402" in err:
                    tui.add_tool_error(tool_match_result.tool_name, "insufficient credits")
                elif "401" in err or "403" in err:
                    tui.add_tool_error(tool_match_result.tool_name, "auth required")
                else:
                    tui.add_tool_error(tool_match_result.tool_name, err[:60])
            continue

        # Compact history
        if len(messages) > COMPACTION_THRESHOLD:
            messages = _compact_history(messages)

        # Build chat request
        rules_text = load_rules() or ""
        standing = load_standing_orders()
        if standing and standing not in rules_text:
            rules_text = rules_text + "\n\n" + standing if rules_text else standing

        request = ChatRequest(
            user_input=user_input,
            session_id=str(db_session_id),
            model=current_model,
            history=messages,
            profile=load_profile() or None,
            rules=rules_text or None,
            daily_context=load_daily_context() or None,
            research_mode=research,
        )

        # Stream response
        reply = await _stream_to_tui(tui, request, access_token, credits)

        if reply:
            store.add_chat_message(db_session_id, "assistant", reply)
            messages.append({"role": "assistant", "content": reply})


async def _stream_to_tui(
    tui: ChatTUI,
    request: ChatRequest,
    access_token: str,
    credits: SessionCredits,
) -> str:
    """Stream chat response into the TUI."""
    collected_text = ""
    tool_count = 0
    has_trade = False
    streaming_started = False
    start_time = time.time()

    tui.set_processing(True)

    try:
        async for event in stream_chat(request, access_token):
            if event.event == "thinking":
                text = event.parsed.get("text", event.parsed.get("status", ""))
                if text:
                    tui.add_thinking(text[:70])

            elif event.event == "action":
                tool = event.parsed.get("action", event.parsed.get("tool", ""))
                params = event.parsed.get("parameters", {})
                tool_count += 1
                if tool:
                    fire_hook(HookEvent.BEFORE_TOOL_CALL, context={"tool": tool, "args": params})
                    tui.add_tool_running(tool)
                    if params:
                        try:
                            result = await call_tool(tool, params)
                            data = result.get("result", {})
                            cost = result.get("cost_usdc") or (data.get("cost_usdc", "") if isinstance(data, dict) else "")
                            tui.add_tool_done(tool, f"${cost}" if cost else "")
                            if isinstance(data, dict):
                                tui.add_text("", "\n")
                                for k, v in data.items():
                                    if k == "cost_usdc":
                                        continue
                                    if v is not None and str(v).strip():
                                        tui.add_text("#A1A1AA", f"  {k}: ")
                                        tui.add_text("#F5F5F5", f"{v}\n")
                        except Exception as e:
                            tui.add_tool_error(tool, str(e)[:60])

            elif event.event == "text_delta":
                text = event.parsed.get("text", event.parsed.get("delta", ""))
                if text and text != "null":
                    if not streaming_started:
                        tui.start_response()
                        streaming_started = True
                    tui.stream_text(text)
                    collected_text += text

            elif event.event == "done":
                if streaming_started:
                    elapsed = time.time() - start_time
                    tui.end_response(elapsed)
                elif not collected_text:
                    full = event.parsed.get("response", event.parsed.get("content", ""))
                    if full:
                        collected_text = full
                        tui.start_response()
                        tui.stream_text(full)
                        tui.end_response(time.time() - start_time)

                credits_used = event.parsed.get("credits_used")
                balance = event.parsed.get("balance")
                credits.add_response(
                    credits_used=credits_used, balance=balance,
                    tools=tool_count, trade=has_trade,
                )
                if credits_used:
                    try:
                        tui.add_credits(float(credits_used))
                    except (ValueError, TypeError):
                        pass

            elif event.event == "error":
                raw = event.parsed.get("message", event.parsed.get("error", ""))
                msg = str(raw)
                if "Classification backend unavailable" in msg:
                    msg = "AI model temporarily unavailable. Try again."
                elif "AccessDeniedException" in msg:
                    msg = "AI model access error."
                elif len(msg) > 120:
                    msg = msg[:120] + "..."
                tui.add_error(msg)

    except Exception as exc:
        tui.add_error(f"Connection error: {str(exc)[:60]}")
        logger.error("stream_error", error=str(exc))
    finally:
        tui.set_processing(False)

    return collected_text


def _show_help(tui: ChatTUI) -> None:
    """Show help in the TUI."""
    tui.add_text("", "\n")
    tui.add_line("#3ECF8E", "  Chat")
    tui.add_line("#52525B", "    /morning      Morning briefing")
    tui.add_line("#52525B", "    /eod          End of day review")
    tui.add_line("#52525B", "    /plan         Plan today's trades")
    tui.add_line("#52525B", "    /portfolio    Open positions")
    tui.add_line("#52525B", "    /risk         Risk dashboard")
    tui.add_text("", "\n")
    tui.add_line("#3ECF8E", "  Memory")
    tui.add_line("#52525B", "    /remember     Save a memory")
    tui.add_line("#52525B", "    /memory       Search memories")
    tui.add_line("#52525B", "    /sessions     Recent sessions")
    tui.add_text("", "\n")
    tui.add_line("#3ECF8E", "  Settings")
    tui.add_line("#52525B", "    /model        Show or switch model")
    tui.add_line("#52525B", "    /permissions   Safety profile")
    tui.add_line("#52525B", "    /credits      Credit usage")
    tui.add_text("", "\n")
    tui.add_line("#3ECF8E", "  Session")
    tui.add_line("#52525B", "    /clear        Clear conversation")
    tui.add_line("#52525B", "    /q            Exit")
    tui.add_text("", "\n")
