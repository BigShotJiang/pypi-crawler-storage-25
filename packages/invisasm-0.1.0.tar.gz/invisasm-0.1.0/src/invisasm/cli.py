import sys
import re
import argparse
from invisasm import __version__

def assemble(source):
    keywords = {
        "HALT": "00",
        "PUSH": "01",
        "POP": "02",
        "DUP": "03",
        "SWAP": "04",
        "COPY": "05",
        "ROT": "06",
        "ADD": "10",
        "SUB": "11",
        "MUL": "12",
        "DIV": "13",
        "MOD": "14",
        "JUMP": "20",
        "JUMPZ": "21",
        "CALL": "22",
        "RET": "23",
        "JUMPNZ": "24",
        "STORE": "30",
        "LOAD": "31",
        "OUTN": "40",
        "OUTC": "41",
        "IN": "42"
    }
    
    hex_output_string = ""
    labels = {}
    
    with open(sys.argv[1], 'r') as f:
        current_page = 0
        current_address = 0

        for line in f:
            line = line.split(';')[0].strip()
            if not line: continue
            
            label_match = re.fullmatch(r"([a-zA-Z0-9_]*):", line)
            if label_match:
                labels[label_match.group(1).upper()] = [current_page, current_address]
            else:
                match line.split()[0].upper():
                    case "PUSH":
                        current_address += 2
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
                    case "COPY":
                        current_address += 2
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
                    case "JUMP":
                        current_address += 3
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
                    case "JUMPZ":
                        current_address += 3
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
                    case "JUMPNZ":
                        current_address += 3
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
                    case "CALL":
                        current_address += 3
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
                    case _:
                        current_address += 1
                        if current_address > 255:
                            current_page += current_address // 256
                            current_address %= 256
        
        f.seek(0)
        
        try:
            for line in f:
                line = line.split(';')[0].strip()
                
                if not line:
                    continue
                
                
                line_parts = line.split()
                
                if line_parts[0].endswith(':'):
                    continue
                
                if line_parts[0].upper() == "PUSH":
                    if len(line_parts) != 2:
                        print("PUSH requires 1 argument")
                        exit(1)
                    else:
                        char_match = re.fullmatch(r"'(.*)'", line_parts[1])
                        if char_match:
                            raw_content = char_match.group(1)
                            decoded_char = raw_content.encode('utf-8').decode('unicode_escape')
                            
                            if len(decoded_char) != 1:
                                print("Invalid argument in PUSH")
                                exit(1)
                                
                            hex_output_string += f"{keywords['PUSH']}{ord(decoded_char):02X}"
                        else:
                            try:
                                int(line_parts[1])
                                hex_output_string += f"{keywords["PUSH"]}{int(line_parts[1]):02X}"
                            except ValueError:
                                print("Invalid argument in PUSH")
                elif line_parts[0].upper() == "COPY":
                    if len(line_parts) != 2:
                        print("COPY requires 1 argument")
                        exit(1)
                    else:
                        try:
                            int(line_parts[1])
                            hex_output_string += f"{keywords["COPY"]}{int(line_parts[1]):02X}"
                        except ValueError:
                            print("Invalid argument in COPY")
                elif line_parts[0].upper() == "JUMP":
                    if len(line_parts) == 3:
                        try:
                            int(line_parts[1])
                            int(line_parts[2])
                            hex_output_string += f"{keywords["JUMP"]}{int(line_parts[1]):02X}{int(line_parts[2]):02X}"
                        except ValueError:
                            print("Invalid argument in JUMP")
                            exit(1)
                    elif len(line_parts) == 2:
                        label_match = re.fullmatch(r"([a-zA-Z0-9_]*)", line_parts[1])
                        if not label_match or not label_match.group(1).upper() in labels:
                            print("Invalid label in JUMP")
                            exit(1)
                        else:
                            hex_output_string += f"{keywords["JUMP"]}{int(labels[line_parts[1].upper()][0]):02X}{int(labels[line_parts[1].upper()][1]):02X}"
                elif line_parts[0].upper() == "JUMPZ":
                    if len(line_parts) == 3:
                        try:
                            int(line_parts[1])
                            int(line_parts[2])
                            hex_output_string += f"{keywords["JUMPZ"]}{int(line_parts[1]):02X}{int(line_parts[2]):02X}"
                        except ValueError:
                            print("Invalid argument in JUMPZ")
                            exit(1)
                    elif len(line_parts) == 2:
                        label_match = re.fullmatch(r"([a-zA-Z0-9_]*)", line_parts[1])
                        if not label_match or not label_match.group(1).upper() in labels:
                            print("Invalid label in JUMPZ")
                            exit(1)
                        else:
                            hex_output_string += f"{keywords["JUMPZ"]}{int(labels[line_parts[1].upper()][0]):02X}{int(labels[line_parts[1].upper()][1]):02X}"
                elif line_parts[0].upper() == "JUMPNZ":
                    if len(line_parts) == 3:
                        try:
                            int(line_parts[1])
                            int(line_parts[2])
                            hex_output_string += f"{keywords["JUMPNZ"]}{int(line_parts[1]):02X}{int(line_parts[2]):02X}"
                        except ValueError:
                            print("Invalid argument in JUMPNZ")
                            exit(1)
                    elif len(line_parts) == 2:
                        label_match = re.fullmatch(r"([a-zA-Z0-9_]*)", line_parts[1])
                        if not label_match or not label_match.group(1).upper() in labels:
                            print("Invalid label in JUMPNZ")
                            exit(1)
                        else:
                            hex_output_string += f"{keywords["JUMPNZ"]}{int(labels[line_parts[1].upper()][0]):02X}{int(labels[line_parts[1].upper()][1]):02X}"
                elif line_parts[0].upper() == "CALL":
                    if len(line_parts) == 3:
                        try:
                            int(line_parts[1])
                            int(line_parts[2])
                            hex_output_string += f"{keywords["CALL"]}{int(line_parts[1]):02X}{int(line_parts[2]):02X}"
                        except ValueError:
                            print("Invalid argument in CALL")
                            exit(1)
                    elif len(line_parts) == 2:
                        label_match = re.fullmatch(r"([a-zA-Z0-9_]*)", line_parts[1])
                        if not label_match or not label_match.group(1).upper() in labels:
                            print("Invalid label in CALL")
                            exit(1)
                        else:
                            hex_output_string += f"{keywords["CALL"]}{int(labels[line_parts[1].upper()][0]):02X}{int(labels[line_parts[1].upper()][1]):02X}"
                else:
                    if len(line_parts) != 1:
                        print("Something was given too many arguments")
                        exit(1)
                    else:
                        if not re.fullmatch(r"[a-zA-Z0-9_]*:", line_parts[0]):
                            hex_output_string += keywords[line_parts[0].upper()]
        except IndexError:
            print("Unknown instruction used")
            exit(1)
        
        bin_output_string = bin(int(hex_output_string, 16))[2:].zfill(len(hex_output_string) * 4)
        final_output_string = bin_output_string.replace("1", "\t").replace("0", " ")
        return final_output_string

def main():
    arg_parser = argparse.ArgumentParser(description=f"InvisLang")

    arg_parser.add_argument('--version', action='version', version=f'InvisAsm {__version__}')

    arg_parser.add_argument("filename", help="path to your file")
    arg_parser.add_argument("-o", "--output", help="path to output file")

    args, unknown = arg_parser.parse_known_args()

    if '--version' in sys.argv:
        sys.exit(0)

    try:
        with open(args.filename, 'r') as f:
            source = f.read()
    except FileNotFoundError:
        print("source file doesn't exist")
        sys.exit(1)
        
    output = assemble(source)
    
    with open(args.output, 'w') as f:
        f.write(output)

if __name__ == "__main__":
    main()
