from importlib.metadata import version
try:
    __version__ = version("invisasm")
except Exception as e:
    __version__ = "uninstalled"
