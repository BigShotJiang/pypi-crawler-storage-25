from __future__ import annotations

import builtins
import sys
from typing import Union
from uuid import UUID

from wasabi import msg

from ellf_pam_sdk import Client
from ellf_pam_sdk.models import ClusterSummary

from ..errors import CLIError
from ..messages import Messages
from ..ui import isatty
from ..url import URL, URLError


def _normalize_address(address: str) -> str | None:
    """Normalize an address-shaped string. Returns ``None`` when unparseable.

    Pam-side and user-supplied URLs vary on trailing slashes and implicit
    schemes, so we compare them in canonical form before deciding a
    `--cluster <url>` argument matches a registered cluster.
    """
    try:
        return str(URL.parse(address))
    except URLError:
        return None


def _match_cluster(
    clusters: builtins.list[ClusterSummary],
    name_or_id: Union[str, UUID],
) -> ClusterSummary | None:
    if isinstance(name_or_id, UUID):
        for c in clusters:
            if c.id == name_or_id:
                return c
        return None
    needle = str(name_or_id)
    for c in clusters:
        if str(c.id) == needle or c.name == needle or c.address == needle:
            return c
    needle_url = _normalize_address(needle)
    if needle_url is None:
        return None
    for c in clusters:
        canonical = _normalize_address(c.address)
        if canonical is not None and canonical == needle_url:
            return c
    return None


def _prompt_for_cluster(
    clusters: builtins.list[ClusterSummary],
) -> ClusterSummary:
    if not isatty(sys.stdin) or not isatty(sys.stdout):
        raise CLIError(Messages.E107)
    msg.info("Multiple clusters are available:")
    for idx, cluster in enumerate(clusters, start=1):
        print(f"  [{idx}] {cluster.name}  ({cluster.address})")
    while True:
        raw = input(f"Pick a cluster [1-{len(clusters)}]: ").strip()
        if raw.isdigit():
            choice = int(raw)
            if 1 <= choice <= len(clusters):
                return clusters[choice - 1]
        matched = _match_cluster(clusters, raw)
        if matched is not None:
            return matched
        msg.warn(f"Invalid selection: {raw!r}")


def select_cluster(
    client: Client,
    name_or_id: Union[str, UUID, None] = None,
) -> ClusterSummary:
    """Pick a cluster the user has access to.

    When ``name_or_id`` is provided, looks it up exactly. Otherwise:
    auto-selects the only cluster, or prompts in a TTY when there are
    multiple. Raises ``CLIError`` if no cluster is accessible or the
    caller is non-interactive with multiple clusters.
    """
    clusters = builtins.list(client.cluster.all(page_size=100))
    if not clusters:
        raise CLIError(Messages.E106)
    if name_or_id is not None:
        matched = _match_cluster(clusters, name_or_id)
        if matched is None:
            raise CLIError(Messages.E038.format(noun="cluster", name_or_id=name_or_id))
        return matched
    if len(clusters) == 1:
        return clusters[0]
    return _prompt_for_cluster(clusters)
