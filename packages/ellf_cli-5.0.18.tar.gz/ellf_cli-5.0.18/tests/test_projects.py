import pytest

from ellf_cli.main import cli


@pytest.mark.skip(
    reason=(
        "Hits the default PAM host (a real URL since e08c1f416) and hangs. "
        "Real coverage lives in compatibility_tests/tests/integration/test_cli.py."
    )
)
def test_list_projects(capsys):
    with pytest.raises(SystemExit):
        cli.run(["ellf", "projects", "list"])
    captured = capsys.readouterr()
    assert "Test Project" in captured.out
