from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

from ellf_cli.config import SavedSettings


class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self):
        return self._payload


def test_support_create_attaches_transcript_when_opted_in(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "session-123")

    session_file = tmp_path / ".claude" / "projects" / "demo" / "session-123.jsonl"
    session_file.parent.mkdir(parents=True)
    session_file.write_text('{"role":"user","content":"help"}\n', encoding="utf-8")
    debug_file = tmp_path / ".claude" / "debug" / "session-123.txt"
    debug_file.parent.mkdir(parents=True)
    debug_file.write_text("traceback", encoding="utf-8")

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["path"] = path
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": True,
                "debug_log_attached": True,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_consent="attach_full_transcript",
        as_json=True,
    )

    assert captured["path"] == "/api/v1/support/request"
    assert captured["json"]["project_id"] == str(project_id)
    assert captured["json"]["transcript_consent"] == "attach_full_transcript"
    assert captured["json"]["session_id"] == "session-123"
    assert "transcript_text" in captured["json"]
    assert "debug_log_text" in captured["json"]
    assert result["attachment_lookup"]["session_id"] == "session-123"
    assert result["attachment_lookup"]["session_id_source"] == "env_var"
    assert result["attachment_lookup"]["transcript_found"] is True
    assert result["attachment_lookup"]["debug_log_found"] is True
    assert result["support_id"] == "abc123"


def test_support_create_prefers_explicit_session_id_over_environment(
    tmp_path, monkeypatch
):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "session-env")

    session_file = tmp_path / ".claude" / "projects" / "demo" / "session-arg.jsonl"
    session_file.parent.mkdir(parents=True)
    session_file.write_text('{"role":"user","content":"help"}\n', encoding="utf-8")

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": True,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        session_id="session-arg",
        transcript_consent="attach_full_transcript",
        as_json=True,
    )

    assert captured["json"]["session_id"] == "session-arg"
    assert result["attachment_lookup"]["session_id"] == "session-arg"
    assert result["attachment_lookup"]["session_id_source"] == "argument"
    assert result["attachment_lookup"]["transcript_found"] is True


def test_support_create_attaches_explicit_transcript_path(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.delenv("CLAUDE_CODE_SESSION_ID", raising=False)

    transcript_path = tmp_path / "manual-session.jsonl"
    transcript_path.write_text(
        '{"role":"user","content":"manual help"}\n', encoding="utf-8"
    )

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": True,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_path=str(transcript_path),
        transcript_consent="attach_full_transcript",
        as_json=True,
    )

    assert "session_id" not in captured["json"]
    assert (
        captured["json"]["transcript_text"] == '{"role":"user","content":"manual help"}'
    )
    assert result["attachment_lookup"]["transcript_path"] == str(transcript_path)
    assert result["attachment_lookup"]["transcript_found"] is True


def test_support_create_prefers_explicit_transcript_path_over_env_lookup(
    tmp_path, monkeypatch
):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "session-env")

    env_session_file = tmp_path / ".claude" / "projects" / "demo" / "session-env.jsonl"
    env_session_file.parent.mkdir(parents=True)
    env_session_file.write_text(
        '{"role":"user","content":"env help"}\n', encoding="utf-8"
    )

    transcript_path = tmp_path / "manual-session.jsonl"
    transcript_path.write_text(
        '{"role":"user","content":"manual help"}\n', encoding="utf-8"
    )

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": True,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_path=str(transcript_path),
        transcript_consent="attach_full_transcript",
        as_json=True,
    )

    assert "session_id" not in captured["json"]
    assert (
        captured["json"]["transcript_text"] == '{"role":"user","content":"manual help"}'
    )
    assert result["attachment_lookup"]["transcript_path"] == str(transcript_path)
    assert result["attachment_lookup"]["transcript_found"] is True


def test_support_create_omits_transcript_by_default(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_consent="summary_only",
        as_json=True,
    )

    assert captured["json"]["transcript_consent"] == "summary_only"
    assert "transcript_text" not in captured["json"]
    assert "debug_log_text" not in captured["json"]


def test_support_create_omits_stale_default_project(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(
            _sync_client=SimpleNamespace(post=fake_post),
            project=SimpleNamespace(
                read=lambda **kwargs: (_ for _ in ()).throw(
                    support_cmd.EllfErrors.ProjectNotFound("")
                )
            ),
        )
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_consent="summary_only",
        as_json=True,
    )

    assert "project_id" not in captured["json"]
    assert result["project_lookup"]["verified"] is False
    assert result["project_lookup"]["reason"] == "stale_default"


def test_support_create_no_project_flag_skips_default(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="General feedback",
        summary="Not tied to a project",
        no_project=True,
        transcript_consent="summary_only",
        as_json=True,
    )

    assert "project_id" not in captured["json"]
    assert result["project_lookup"]["reason"] == "no_project_flag"
    assert result["project_lookup"]["verified"] is True


def test_support_create_reports_missing_transcript_files(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "session-404")

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_consent="attach_full_transcript",
        as_json=True,
    )

    assert captured["json"]["session_id"] == "session-404"
    assert "transcript_text" not in captured["json"]
    assert "debug_log_text" not in captured["json"]
    assert result["attachment_lookup"]["session_id_present"] is True
    assert result["attachment_lookup"]["session_id_source"] == "env_var"
    assert result["attachment_lookup"]["transcript_found"] is False
    assert result["attachment_lookup"]["debug_log_found"] is False


def test_support_create_reports_missing_session_when_env_unset(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.delenv("CLAUDE_CODE_SESSION_ID", raising=False)

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_consent="attach_full_transcript",
        as_json=True,
    )

    assert "session_id" not in captured["json"]
    assert "transcript_text" not in captured["json"]
    assert "debug_log_text" not in captured["json"]
    assert result["attachment_lookup"]["session_id_present"] is False
    assert result["attachment_lookup"]["session_id_source"] == "missing"


def test_support_create_uses_message_as_summary_when_omitted(tmp_path, monkeypatch):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    captured: dict = {}

    def fake_post(path: str, json: dict):
        captured["path"] = path
        captured["json"] = json
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": "abc123",
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary=None,
        as_json=True,
    )

    assert captured["path"] == "/api/v1/support/request"
    assert captured["json"]["summary"] == "Something is broken"
    assert result["support_id"] == "abc123"


def test_support_create_reports_missing_support_id_in_json_details(
    tmp_path, monkeypatch, capsys
):
    from ellf_cli.commands import support as support_cmd

    project_id = uuid4()
    config_dir = tmp_path / "config"
    SavedSettings(project=project_id).save(config_dir / "saved-defaults.json")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    def fake_post(path: str, json: dict):
        return _FakeResponse(
            {
                "email_sent": True,
                "support_id": None,
                "to_email": "support@ellf.ai",
                "subject": "Ellf support request: Demo",
                "transcript_attached": False,
                "debug_log_attached": False,
            }
        )

    fake_auth = SimpleNamespace(
        client=SimpleNamespace(_sync_client=SimpleNamespace(post=fake_post))
    )
    monkeypatch.setattr(support_cmd, "get_auth_state", lambda: fake_auth)

    result = support_cmd.create(
        user_comment="Something is broken",
        summary="Support-ready summary",
        transcript_consent="summary_only",
        as_json=False,
    )

    assert result["support_id"] is None
    out = capsys.readouterr().out
    assert "Successfully sent support request" in out
    assert '"support_id": null' in out
    assert '"support_id_available": false' in out
