from __future__ import annotations

from percylib.external.models import JobResultItem
from percylib.jobs.output import BaseOutputWriter


class JsonlOutputWriter(BaseOutputWriter):
    """Writes job results as JSON Lines to a file path."""

    def __init__(self, path: str) -> None:
        self._path = path

    def write_jobs(self, jobs: list[JobResultItem]) -> None:
        """Write each job result as a single JSON line."""
        with open(self._path, "w") as f:
            for job in jobs:
                f.write(job.model_dump_json())
                f.write("\n")
