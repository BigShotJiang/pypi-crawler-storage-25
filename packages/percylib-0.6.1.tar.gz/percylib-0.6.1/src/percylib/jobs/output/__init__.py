from __future__ import annotations

from abc import ABC, abstractmethod

from percylib.external.models import JobResultItem


class BaseOutputWriter(ABC):
    """Abstract base class for writing job results."""

    @abstractmethod
    def write_jobs(self, jobs: list[JobResultItem]) -> None:
        """Write a list of job result items to the output destination."""
        ...


from percylib.jobs.output.jsonl_writer import JsonlOutputWriter  # noqa: E402

__all__ = [
    "BaseOutputWriter",
    "JsonlOutputWriter",
]
