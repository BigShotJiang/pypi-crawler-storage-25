from __future__ import annotations

import json
import os
from typing import Any, cast

from typing_extensions import TypeAlias

from percylib.ai import DefaultAiModelProvider
from percylib.external.models import (
    ConfigFileLocation,
    DeepDiffJobGroupValidationVariant,
    JobBatchConfiguration,
    JobGroupValidationConfig,
    JobOutputFormat,
    JobPersistenceConfig,
    JobSpecVariant,
    LlmDocExtractSpec,
    LlmDocExtractV1Input,
    LlmDocExtractV1Output,
    LocalPathConfigFileLocationVariant,
    MaxExactMatchJobGroupValidationVariant,
    Value,
)
from percylib.jobs import (
    BaseEventSink,
    BaseJob,
    BaseJobExecutor,
    BaseJobGroupValidator,
    BaseJobLoader,
    BaseJobPersister,
    JobOutput,
    MemoryPersister,
    StderrEventSink,
)
from percylib.jobs.ai.doc_extract_v1 import (
    DocExtractJob,
    DocExtractJobExecutor,
    FolderDocExtractJobLoader,
)
from percylib.jobs.orchestrator import DefaultJobOrchestrator
from percylib.jobs.output import BaseOutputWriter, JsonlOutputWriter
from percylib.jobs.sqlite import SqliteJobPersister, create_pydantic_serde
from percylib.jobs.validators import DeepDiffValidator, MaxExactMatchValidator

ConfiguredJobInput: TypeAlias = LlmDocExtractV1Input
ConfiguredJobOutput: TypeAlias = LlmDocExtractV1Output


class _ConfiguredDocExtractExecutor(
    BaseJobExecutor[BaseJob[LlmDocExtractV1Input], LlmDocExtractV1Output]
):
    def __init__(self, spec: LlmDocExtractSpec) -> None:
        self._executor = DocExtractJobExecutor(DefaultAiModelProvider(), spec)

    def execute_job(
        self, job: BaseJob[LlmDocExtractV1Input]
    ) -> JobOutput[LlmDocExtractV1Output]:
        result = self._executor.execute_job(cast(DocExtractJob, job))
        return JobOutput(output=LlmDocExtractV1Output(value=result.output))


def _create_default_event_sink() -> BaseEventSink | None:
    if os.getenv("PERCY_PROC"):
        return StderrEventSink()
    return None


def create_executor_from_spec(
    spec: JobSpecVariant,
) -> BaseJobExecutor[BaseJob[ConfiguredJobInput], ConfiguredJobOutput]:
    if spec.type == "llmDocExtractV1":
        return _ConfiguredDocExtractExecutor(spec.value)

    raise ValueError(f"Unsupported job spec type: {spec.type}")


def create_job_loader_from_spec(
    spec: JobSpecVariant,
) -> BaseJobLoader[BaseJob[ConfiguredJobInput]]:
    if spec.type == "llmDocExtractV1":
        source = spec.value.source
        if source.type != "folderV1":
            raise ValueError(f"Unsupported doc extract source type: {source.type}")

        return cast(
            BaseJobLoader[BaseJob[ConfiguredJobInput]],
            FolderDocExtractJobLoader(source.value, spec.value.iterations),
        )

    raise ValueError(f"Unsupported job spec type: {spec.type}")


def _create_sqlite_persister_from_spec(
    path: str, spec: JobSpecVariant
) -> BaseJobPersister[BaseJob[ConfiguredJobInput], ConfiguredJobOutput]:
    if spec.type == "llmDocExtractV1":
        return SqliteJobPersister.create(
            path,
            input_serde=create_pydantic_serde(LlmDocExtractV1Input),
            success_serde=create_pydantic_serde(LlmDocExtractV1Output),
        )

    raise ValueError(f"Unsupported job spec type: {spec.type}")


def create_persister_from_config(
    persistence: JobPersistenceConfig | None,
    spec: JobSpecVariant,
) -> BaseJobPersister[BaseJob[ConfiguredJobInput], ConfiguredJobOutput]:
    if persistence is None:
        persister: MemoryPersister[BaseJob[ConfiguredJobInput], ConfiguredJobOutput] = (
            MemoryPersister()
        )
        return persister

    if persistence.variant.type == "sqlite":
        sqlite_config = persistence.variant.value
        if sqlite_config is None or sqlite_config.path is None:
            raise ValueError("Sqlite persistence requires an explicit path.")

        return _create_sqlite_persister_from_spec(sqlite_config.path, spec)

    raise ValueError(
        f"Unsupported persistence configuration type: {persistence.variant.type}"
    )


def create_output_writer_from_config(
    output: JobOutputFormat | None,
) -> BaseOutputWriter | None:
    """Create an output writer from the output format configuration."""
    if output is None:
        return None

    variant = output.variant
    if variant.type == "jsonl":
        return JsonlOutputWriter(variant.value.path)

    raise ValueError(f"Unsupported output format type: {variant.type}")


def create_validator_from_config(
    validation: JobGroupValidationConfig | None,
) -> BaseJobGroupValidator[Any] | None:
    """Create a job group validator from the validation configuration."""
    if validation is None:
        return None

    variant = validation.variant
    if isinstance(variant, MaxExactMatchJobGroupValidationVariant):
        return MaxExactMatchValidator(variant.value)

    if isinstance(variant, DeepDiffJobGroupValidationVariant):
        return DeepDiffValidator(variant.value)

    raise ValueError(f"Unsupported validation type: {variant.type}")


def _get_validation_config_from_spec(
    spec: JobSpecVariant,
) -> JobGroupValidationConfig | None:
    """Extract the validation config from a job spec variant, if present."""
    if spec.type == "llmDocExtractV1":
        return spec.value.validation
    return None


def create_orchestrator_from_config(
    id: str,
    config: JobBatchConfiguration,
    display_name: str | None = None,
    description: str | None = None,
    config_location: ConfigFileLocation | None = None,
) -> DefaultJobOrchestrator[BaseJob[ConfiguredJobInput], ConfiguredJobOutput]:
    spec = config.job.variant
    return DefaultJobOrchestrator(
        id=id,
        display_name=display_name,
        description=description,
        persistence=config.persistence,
        config=config_location,
        persister=create_persister_from_config(config.persistence, spec),
        executor=create_executor_from_spec(spec),
        event_sink=_create_default_event_sink(),
        loader=create_job_loader_from_spec(spec),
        output_writer=create_output_writer_from_config(config.output),
        validator=create_validator_from_config(_get_validation_config_from_spec(spec)),
    )


def create_orchestrator_from_config_path(
    id: str,
    config_path: str,
    display_name: str | None = None,
    description: str | None = None,
) -> DefaultJobOrchestrator[BaseJob[ConfiguredJobInput], ConfiguredJobOutput]:
    """Create an orchestrator by loading a JSON or YAML config file."""
    with open(config_path, "r") as f:
        ext = os.path.splitext(config_path)[1].lower()
        if ext in (".yaml", ".yml"):
            import yaml

            data = yaml.safe_load(f)
        else:
            data = json.load(f)
    config = JobBatchConfiguration.model_validate(data)
    return create_orchestrator_from_config(
        id=id,
        config=config,
        display_name=display_name,
        description=description,
        config_location=LocalPathConfigFileLocationVariant(
            type="localPath",
            value=Value(path=config_path),
        ),
    )


def create_orchestrator_from_config_json(
    id: str,
    config_json: str | dict[str, Any],
    display_name: str | None = None,
    description: str | None = None,
) -> DefaultJobOrchestrator[BaseJob[ConfiguredJobInput], ConfiguredJobOutput]:
    """Create an orchestrator from a JSON string or a dict."""
    if isinstance(config_json, str):
        data: dict[str, Any] = json.loads(config_json)
    else:
        data = config_json
    config = JobBatchConfiguration.model_validate(data)
    return create_orchestrator_from_config(
        id=id, config=config, display_name=display_name, description=description
    )
