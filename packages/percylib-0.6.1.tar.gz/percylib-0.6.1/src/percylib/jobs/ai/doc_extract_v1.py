from __future__ import annotations

import fnmatch
import json
import mimetypes
import os
from collections.abc import Iterator
from pathlib import Path, PurePosixPath
from typing import Any, Union, cast

from pydantic_ai import Agent, BinaryContent, StructuredDict
from pydantic_ai.messages import ModelMessage, ModelRequest, UserPromptPart

from percylib.ai import AiModelProvider
from percylib.external.models import (
    FileLocator,
    FolderFileSource,
    JsonValue,
    LlmDocExtractIterationSpec,
    LlmDocExtractSpec,
    LlmDocExtractV1Input,
)
from percylib.helpers import resolve_locator_or_path
from percylib.jobs import BaseJob, BaseJobExecutor, BaseJobLoader, JobOutput
from percylib.schemas.schema_convert import value_schema_to_json_schema


class DocExtractJob(BaseJob[LlmDocExtractV1Input]):
    """Concrete job for running one extraction iteration on one document."""

    def __init__(
        self, job_id: str, group_id: Union[str, None], input: LlmDocExtractV1Input
    ):
        self._job_id = job_id
        self._group_id = group_id
        self._input = input

    def id(self) -> str:
        return self._job_id

    def job_group(self) -> Union[str, None]:
        return self._group_id

    def input(self) -> LlmDocExtractV1Input:
        return self._input


def _normalize_pattern(pattern: str) -> tuple[str, ...]:
    """Normalize a glob pattern into POSIX path segments.

    Percy job specs use forward-slash-separated globs. We normalize
    Windows separators as well so matching behaves consistently across
    platforms while keeping the matching logic segment-oriented.
    """
    normalized = pattern.replace("\\", "/")
    parts: list[str] = []
    for part in normalized.split("/"):
        if part in {"", "."}:
            continue
        if part == "**" and parts and parts[-1] == "**":
            continue
        parts.append(part)
    return tuple(parts)


def _is_hidden(path_part: str) -> bool:
    """Return whether a path segment should be treated as hidden by glob."""
    return path_part.startswith(".")


def _matches_pattern(
    path_parts: tuple[str, ...], pattern_parts: tuple[str, ...]
) -> bool:
    """Match a normalized relative path against a normalized glob pattern.

    This intentionally mirrors the subset of ``glob.glob(..., recursive=True)``
    semantics that we need while still allowing lazy traversal via
    ``os.scandir``:
    - matching is path-segment aware rather than string-wide
    - ``**`` can span multiple segments
    - hidden files and directories only match when the relevant pattern
      segment also starts with ``.``

    Python 3.9 does not expose a standard-library matcher that preserves
    these recursive ``glob`` semantics without also eagerly expanding the
    filesystem, so this helper keeps just the matching portion custom.
    """
    states = [(0, 0)]
    seen: set[tuple[int, int]] = set()

    while states:
        path_index, pattern_index = states.pop()
        state = (path_index, pattern_index)
        if state in seen:
            continue
        seen.add(state)

        if pattern_index == len(pattern_parts):
            if path_index == len(path_parts):
                return True
            continue

        pattern_part = pattern_parts[pattern_index]
        if pattern_part == "**":
            states.append((path_index, pattern_index + 1))
            # ``glob`` will not recurse into hidden directories unless the
            # pattern explicitly names them, so ``**`` may only absorb
            # non-hidden segments.
            if path_index < len(path_parts) and not _is_hidden(path_parts[path_index]):
                states.append((path_index + 1, pattern_index))
            continue

        if path_index >= len(path_parts):
            continue

        path_part = path_parts[path_index]
        if _is_hidden(path_part) and not _is_hidden(pattern_part):
            continue

        if fnmatch.fnmatchcase(path_part, pattern_part):
            states.append((path_index + 1, pattern_index + 1))

    return False


class FolderDocExtractJobLoader(BaseJobLoader[DocExtractJob]):
    """Lazily load one :class:`DocExtractJob` per file per iteration.

    The loader walks the folder tree with ``os.scandir`` and yields jobs
    incrementally, so the file list is never materialized in memory.
    File contents are not read here; they are loaded later by the
    executor only for the job currently being processed.
    """

    def __init__(
        self,
        source: FolderFileSource,
        iterations: list[LlmDocExtractIterationSpec],
    ) -> None:
        if not iterations:
            raise ValueError(
                "FolderDocExtractJobLoader requires at least one iteration"
            )

        self._source = source
        self._iterations = iterations
        self._has_multiple_iterations = len(iterations) > 1
        include_patterns = source.includePatterns or ["**/*.pdf"]
        self._include_patterns = tuple(
            _normalize_pattern(pattern) for pattern in include_patterns
        )
        self._exclude_patterns = tuple(
            _normalize_pattern(pattern) for pattern in source.excludePatterns
        )

    def load_jobs(self) -> Iterator[DocExtractJob]:
        """Yield jobs lazily for every matching file and iteration.

        Raises:
            ValueError: If the configured source path cannot be resolved
                or does not point to a directory.
        """
        root_path_value = resolve_locator_or_path(self._source.path)
        if root_path_value is None:
            raise ValueError(
                f"Could not resolve folder source path: {self._source.path}"
            )

        root_path = Path(root_path_value)
        if not root_path.is_dir():
            raise ValueError(f"Folder source path is not a directory: {root_path}")

        return self._load_jobs_from_root(root_path)

    def _load_jobs_from_root(self, root_path: Path) -> Iterator[DocExtractJob]:
        for relative_path in self._iter_matching_relative_paths(root_path):
            group_id = relative_path if self._has_multiple_iterations else None
            job_file = self._build_job_file(relative_path, root_path)
            for iteration_number, iteration in enumerate(self._iterations, start=1):
                yield DocExtractJob(
                    job_id=f"{relative_path}-{iteration_number}",
                    group_id=group_id,
                    input=LlmDocExtractV1Input(file=job_file, spec=iteration),
                )

    def _build_job_file(self, relative_path: str, root_path: Path) -> str | FileLocator:
        """Build the job input file reference for a matched relative path."""
        if isinstance(self._source.path, str):
            return str(root_path / Path(relative_path))

        return FileLocator(
            source=self._source.path.source,
            path=str(
                PurePosixPath(self._source.path.path) / PurePosixPath(relative_path)
            ),
        )

    def _iter_matching_relative_paths(self, root_path: Path) -> Iterator[str]:
        for relative_path in self._iter_relative_paths(root_path, PurePosixPath(".")):
            path_parts = PurePosixPath(relative_path).parts
            if not any(
                _matches_pattern(path_parts, pattern_parts)
                for pattern_parts in self._include_patterns
            ):
                continue
            if any(
                _matches_pattern(path_parts, pattern_parts)
                for pattern_parts in self._exclude_patterns
            ):
                continue
            yield relative_path

    def _iter_relative_paths(
        self, directory: Path, relative_directory: PurePosixPath
    ) -> Iterator[str]:
        """Recursively yield relative file paths beneath ``directory``.

        ``os.scandir`` keeps traversal lazy and lets Python reuse the
        directory entry metadata for ``is_dir`` / ``is_file`` checks.
        """
        with os.scandir(directory) as entries:
            for entry in entries:
                entry_relative_path = relative_directory / entry.name
                if entry.is_dir(follow_symlinks=False):
                    yield from self._iter_relative_paths(
                        Path(entry.path), entry_relative_path
                    )
                    continue
                if not entry.is_file(follow_symlinks=False):
                    continue
                yield entry_relative_path.as_posix()


def _load_file(file_path: str) -> BinaryContent:
    """Load a file as BinaryContent with an inferred media type."""
    data = Path(file_path).read_bytes()
    media_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
    return BinaryContent(data=data, media_type=media_type)


class DocExtractJobExecutor(BaseJobExecutor[DocExtractJob, JsonValue]):
    def __init__(self, model_provider: AiModelProvider, spec: LlmDocExtractSpec):
        self._model_provider = model_provider
        self._spec = spec

    def execute_job(self, job: DocExtractJob) -> JobOutput[JsonValue]:
        model = self._model_provider.get_model(job.input().spec.model)

        json_schema = value_schema_to_json_schema(self._spec.outputSchema)
        output_type = StructuredDict(json_schema)

        message_history: list[ModelMessage] = []
        if self._spec.example is not None:
            for example in self._spec.example.examples:
                file_path = resolve_locator_or_path(example.file)
                if file_path is None:
                    raise ValueError(f"Could not resolve example file: {example.file}")

                content: list[str | BinaryContent] = [_load_file(file_path)]

                expected_text = json.dumps(example.expected)
                if example.rationale is not None:
                    expected_text += f"\n\nRationale: {example.rationale}"
                content.append(expected_text)

                message_history.append(
                    # ty cannot resolve pydantic-ai dataclass constructors
                    ModelRequest(parts=[UserPromptPart(content=content)])  # type: ignore[call-arg]
                )

        file_path = resolve_locator_or_path(job.input().file)
        if file_path is None:
            raise ValueError(f"Could not resolve file: {job.input().file}")

        agent: Agent[None, Any] = Agent(
            model=model,
            output_type=output_type,
            instructions=self._spec.prompt,
        )

        result = agent.run_sync(
            user_prompt=[_load_file(file_path)],
            message_history=message_history,
        )

        return JobOutput(output=cast(JsonValue, result.output))
