from __future__ import annotations

import re
import tempfile
from collections.abc import Callable
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import Generic, Optional, TypeVar

from pydantic import BaseModel as PydanticBaseModel
from sqlalchemy import create_engine, func, select, text, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session
from yoyo import get_backend, read_migrations

from percylib.jobs import (
    BaseJob,
    BaseJobPersister,
    FullJob,
    InputT,
    JobProgress,
    JobStatus,
    SuccessT,
)
from percylib.jobs.sqlite.db_models import JobGroups, Jobs

# ── Migration helpers ───────────────────────────────────────────────


def _get_sorted_migrations() -> list[tuple[str, str]]:
    """Read migration SQL files from package data, sorted by folder name."""
    migrations_root = files("percylib").joinpath("migrations")
    entries: list[tuple[str, str]] = []

    for item in migrations_root.iterdir():
        if not item.is_dir():
            continue
        sql_file = item.joinpath("migration.sql")
        if sql_file.is_file():
            sql_content = sql_file.read_text()
            entries.append((item.name, sql_content))

    entries.sort(key=lambda x: x[0])
    return entries


def _drizzle_to_yoyo_sql(
    migration_id: str,
    sql: str,
    depends: str | None,
) -> str:
    """Convert a drizzle ORM SQL migration to a yoyo-compatible SQL file."""
    clean_sql = re.sub(r"--> statement-breakpoint\n?", "", sql)
    depends_line = f"-- depends: {depends}" if depends else "-- depends:"
    return f"-- id: {migration_id}\n{depends_line}\n\n{clean_sql}"


def create_migrated_jobs_sqlite(path: str | Path) -> None:
    """Create a SQLite database and apply all pending migrations.

    Creates the SQLite file and any parent directories if they don't
    already exist.  Migrations already applied are skipped.

    Args:
        path: Path to the SQLite database file.
    """
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)

    entries = _get_sorted_migrations()

    with tempfile.TemporaryDirectory() as tmpdir:
        prev_id: str | None = None
        for folder_name, sql_content in entries:
            yoyo_sql = _drizzle_to_yoyo_sql(folder_name, sql_content, prev_id)
            migration_file = Path(tmpdir) / f"{folder_name}.sql"
            migration_file.write_text(yoyo_sql)
            prev_id = folder_name

        engine = create_engine(f"sqlite:///{path}")
        with engine.connect() as conn:
            conn.execute(text("PRAGMA journal_mode=WAL;"))
            conn.commit()
        engine.dispose()

        backend = get_backend(f"sqlite:///{path}")
        migrations = read_migrations(tmpdir)

        with backend.lock():
            backend.apply_migrations(backend.to_apply(migrations))


# ── Serialization ───────────────────────────────────────────────────


SerdeT = TypeVar("SerdeT")
PydanticModelT = TypeVar("PydanticModelT", bound=PydanticBaseModel)


@dataclass(frozen=True)
class Serde(Generic[SerdeT]):
    """Serialize and deserialize a typed value for SQLite storage."""

    serializer: Callable[[SerdeT], str]
    deserializer: Callable[[str], SerdeT]


def create_pydantic_serde(
    schema: type[PydanticModelT],
) -> Serde[PydanticModelT]:
    """Create a serde for a Pydantic model schema."""

    def serializer(value: PydanticModelT) -> str:
        return value.model_dump_json()

    def deserializer(value: str) -> PydanticModelT:
        return schema.model_validate_json(value)

    return Serde(serializer=serializer, deserializer=deserializer)


# ── Job wrapper ─────────────────────────────────────────────────────


class _SqliteJob(BaseJob[InputT], Generic[InputT]):
    """Lightweight job reconstructed from a SQLite row."""

    def __init__(self, job_id: str, input_data: InputT, group_id: str | None) -> None:
        self._id = job_id
        self._input = input_data
        self._group = group_id

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> InputT:
        return self._input


# ── Persister ───────────────────────────────────────────────────────


class SqliteJobPersister(
    BaseJobPersister[BaseJob[InputT], SuccessT],
    Generic[InputT, SuccessT],
):
    """Persist and manage jobs in a SQLite database.

    Uses SQLAlchemy ORM models from ``db_models`` to interact with the
    ``jobs`` and ``job_groups`` tables.

    Serdes convert job inputs and success values to SQLite strings and
    reconstruct typed values when jobs are loaded back out of storage.
    """

    def __init__(
        self,
        engine: Engine,
        input_serde: Serde[InputT],
        success_serde: Serde[SuccessT],
    ) -> None:
        self._engine = engine
        self._input_serde = input_serde
        self._success_serde = success_serde

    @staticmethod
    def _get_next_pending_priority(session: Session) -> int:
        """Return the next priority value for a newly pending job."""
        current_lowest_priority = session.execute(
            select(Jobs.priority)
            .where(
                Jobs.status == "pending",
                Jobs.priority.is_not(None),
            )
            .order_by(Jobs.priority.desc(), Jobs.id.asc())
            .limit(1)
        ).scalar_one_or_none()
        if current_lowest_priority is None:
            return 0
        return current_lowest_priority + 1

    @staticmethod
    def create(
        path: str | Path,
        input_serde: Serde[InputT],
        success_serde: Serde[SuccessT],
    ) -> SqliteJobPersister[InputT, SuccessT]:
        """Create a :class:`SqliteJobPersister` backed by a SQLite file.

        The SQLite file and any parent directories are created if they
        don't already exist.  Pending migrations are applied
        automatically.

        Args:
            path: Path to the SQLite database file.
            input_serde: Serializer/deserializer pair for job inputs.
            success_serde: Serializer/deserializer pair for success values.

        Returns:
            A ready-to-use persister instance.
        """
        path = Path(path).resolve()
        create_migrated_jobs_sqlite(path)
        engine = create_engine(f"sqlite:///{path}")
        return SqliteJobPersister(
            engine,
            input_serde=input_serde,
            success_serde=success_serde,
        )

    def upsert_jobs(self, jobs: list[BaseJob[InputT]]) -> list[bool]:
        """Upsert a list of jobs with status ``pending``.

        Returns a list of booleans parallel to *jobs*: ``True`` when the
        job was newly added, ``False`` when it already existed (in which
        case the existing record is left unchanged).
        """
        results: list[bool] = []
        with Session(self._engine) as session:
            next_priority = self._get_next_pending_priority(session)
            for job in jobs:
                existing = session.get(Jobs, job.id())
                if existing is not None:
                    results.append(False)
                    continue

                group_id = job.job_group()
                if group_id is not None:
                    existing_group = session.get(JobGroups, group_id)
                    if existing_group is None:
                        session.add(JobGroups(id=group_id))
                session.add(
                    Jobs(
                        id=job.id(),
                        status="pending",
                        input=self._input_serde.serializer(job.input()),
                        group_id=group_id,
                        priority=next_priority,
                    )
                )
                next_priority += 1
                results.append(True)
            session.commit()
        return results

    def pop_pending(self) -> BaseJob[InputT] | None:
        """Pop a pending job, mark it as in progress, and return it."""
        with Session(self._engine) as session:
            row = session.execute(
                select(Jobs)
                .where(Jobs.status == "pending")
                .order_by(
                    Jobs.priority.is_(None),
                    Jobs.priority.asc(),
                    Jobs.id.asc(),
                )
                .limit(1)
            ).scalar_one_or_none()
            if row is None:
                return None
            row.status = "in_progress"
            assert row.id is not None
            job_id: str = row.id
            job_input = self._input_serde.deserializer(row.input)
            job_group: str | None = row.group_id
            session.commit()
            return _SqliteJob(job_id, job_input, job_group)

    def save_success(self, job_id: str, value: SuccessT) -> None:
        """Mark a job as successful and store its output."""
        with Session(self._engine) as session:
            row = session.get(Jobs, job_id)
            if row is not None:
                row.status = "success"
                row.output = self._success_serde.serializer(value)
                session.commit()

    def save_failure(self, job_id: str, error: Exception) -> None:
        """Mark a job as failed and store the error message."""
        with Session(self._engine) as session:
            row = session.get(Jobs, job_id)
            if row is not None:
                row.status = "failure"
                row.output = str(error)
                session.commit()

    def mark_running_as_pending(self) -> None:
        """Reset all in-progress jobs back to pending."""
        with Session(self._engine) as session:
            session.execute(
                update(Jobs)
                .where(Jobs.status == "in_progress")
                .values(status="pending")
            )
            session.commit()

    def get_jobs_in_group(
        self,
        group_id: str,
    ) -> list[FullJob[BaseJob[InputT], SuccessT]]:
        """Return every job that belongs to *group_id*."""
        results: list[FullJob[BaseJob[InputT], SuccessT]] = []
        with Session(self._engine) as session:
            rows = (
                session.execute(select(Jobs).where(Jobs.group_id == group_id))
                .scalars()
                .all()
            )
            for row in rows:
                assert row.id is not None
                job: BaseJob[InputT] = _SqliteJob(
                    row.id,
                    self._input_serde.deserializer(row.input),
                    row.group_id,
                )
                status: JobStatus = row.status  # type: ignore[assignment]
                output: SuccessT | None = None
                if status == "success" and row.output is not None:
                    output = self._success_serde.deserializer(row.output)
                results.append(FullJob(job=job, status=status, output=output))
        return results

    def get_job_progress(self) -> JobProgress:
        """Return aggregate counts for all known jobs."""
        with Session(self._engine) as session:
            rows = session.execute(
                select(Jobs.status, func.count(Jobs.id)).group_by(Jobs.status)
            ).all()

        total = 0
        success = 0
        failure = 0
        for status, count in rows:
            row_count = int(count)
            total += row_count
            if status == "success":
                success = row_count
            elif status == "failure":
                failure = row_count

        return JobProgress(total=total, success=success, failure=failure)

    def store_group_score(self, group_id: str, score: float) -> None:
        """Persist a validation score for *group_id*."""
        with Session(self._engine) as session:
            group = session.get(JobGroups, group_id)
            if group is not None:
                group.validation_score = score
                session.commit()
