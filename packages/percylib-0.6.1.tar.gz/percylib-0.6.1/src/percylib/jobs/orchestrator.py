from __future__ import annotations

import logging
from collections.abc import Generator
from typing import Any, Generic, Optional, cast
from uuid import UUID

from pydantic import BaseModel

from percylib.external.models import (
    BatchStartedEvent,
    BatchStartJobEventVariant,
    ConfigFileLocation,
    JobBatchInfo,
    JobBatchProgress,
    JobCompletedEvent,
    JobCompleteJobEventVariant,
    JobEvent,
    JobFailureResult,
    JobFailureResultVariant,
    JobPersistenceConfig,
    JobResultItem,
    JobStartedEvent,
    JobStartJobEventVariant,
    JobSuccessResult,
    JobSuccessResultVariant,
    JsonValue,
)
from percylib.jobs import (
    BaseEventSink,
    BaseJobExecutor,
    BaseJobGroupValidator,
    BaseJobLoader,
    BaseJobPersister,
    BaseOutputWriter,
    JobT,
    OutputT,
)

logger = logging.getLogger(__name__)


def _to_json_value(value: Any) -> JsonValue:
    """Convert a generic value to a JSON-compatible value for events."""
    if isinstance(value, BaseModel):
        return cast(JsonValue, value.model_dump())
    return cast(JsonValue, value)


class DefaultJobOrchestrator(Generic[JobT, OutputT]):
    """Orchestrates job execution, yielding events as jobs are processed.

    Pops pending jobs from the persister, executes each one via the
    executor, and persists the result.  A :class:`JobEvent` is yielded
    for every lifecycle transition (batch start, job start, job complete).

    If an *event_sink* is provided, each event is also published there.
    """

    def __init__(
        self,
        *,
        id: str,
        display_name: str | None = None,
        description: str | None = None,
        persistence: JobPersistenceConfig | None = None,
        config: ConfigFileLocation | None = None,
        persister: BaseJobPersister[JobT, OutputT],
        executor: BaseJobExecutor[JobT, OutputT],
        event_sink: BaseEventSink | None = None,
        loader: BaseJobLoader[JobT] | None = None,
        output_writer: BaseOutputWriter | None = None,
        validator: BaseJobGroupValidator[OutputT] | None = None,
    ) -> None:
        self._id = id
        self._display_name = display_name if display_name is not None else description
        self._description = description
        self._persistence = persistence
        self._config = config
        self._persister = persister
        self._executor = executor
        self._event_sink = event_sink
        self._loader = loader
        self._output_writer = output_writer
        self._validator = validator

    def _emit(self, event: JobEvent) -> None:
        """Publish event to the event sink if one is configured."""
        if self._event_sink is not None:
            self._event_sink.consume_event(event)

    def _get_progress(self) -> JobBatchProgress:
        progress = self._persister.get_job_progress()
        return JobBatchProgress(
            total=progress.total,
            success=progress.success,
            failure=progress.failure,
        )

    def _try_validate_group(self, group_id: str, validated_groups: set[str]) -> None:
        """Validate a finished group and store its score.

        Does nothing when no validator is configured.  If the group still
        has pending or in-progress jobs it is skipped.  Validator errors
        are logged and silently ignored so that processing continues.
        """
        if self._validator is None:
            return

        if group_id in validated_groups:
            return

        full_jobs = self._persister.get_jobs_in_group(group_id)
        if any(fj.status in ("pending", "in_progress") for fj in full_jobs):
            return

        validated_groups.add(group_id)

        try:
            outputs: list[OutputT] = [
                fj.output
                for fj in full_jobs
                if fj.status == "success" and fj.output is not None
            ]
            score = self._validator.validate(outputs)
            self._persister.store_group_score(group_id, score)
        except Exception:
            logger.exception("Validator failed for group %s; skipping", group_id)

    def run(self, *, reset_in_progress: bool = True) -> Generator[JobEvent, None, None]:
        """Execute all pending jobs, yielding events."""
        if self._loader is not None:
            self._persister.upsert_jobs(list(self._loader.load_jobs()))

        if reset_in_progress:
            self._persister.mark_running_as_pending()

        batch_start = JobEvent(
            variant=BatchStartJobEventVariant(
                type="batchStart",
                value=BatchStartedEvent(
                    id=self._id,
                    info=JobBatchInfo(
                        displayName=self._display_name,
                        description=self._description,
                        persistence=self._persistence,
                        config=self._config,
                    ),
                    progress=self._get_progress(),
                ),
            )
        )
        self._emit(batch_start)
        yield batch_start

        result_items: list[JobResultItem] = []
        validated_groups: set[str] = set()

        job = self._persister.pop_pending()
        while job is not None:
            job_id = job.id()
            job_group = job.job_group()
            input_value = _to_json_value(job.input())
            group_id: Optional[UUID] = (
                UUID(job_group) if job_group is not None else None
            )

            job_start = JobEvent(
                variant=JobStartJobEventVariant(
                    type="jobStart",
                    value=JobStartedEvent(
                        jobId=job_id,
                        input=input_value,
                    ),
                )
            )
            self._emit(job_start)
            yield job_start

            try:
                result = self._executor.execute_job(job)
                self._persister.save_success(job.id(), result.output)
                output_value = _to_json_value(result.output)
                job_complete = JobEvent(
                    variant=JobCompleteJobEventVariant(
                        type="jobComplete",
                        value=JobCompletedEvent(
                            jobId=job_id,
                            result=JobSuccessResultVariant(
                                type="success",
                                value=JobSuccessResult(
                                    output=output_value,
                                ),
                            ),
                            progress=self._get_progress(),
                        ),
                    )
                )
                result_items.append(
                    JobResultItem(
                        id=job_id,
                        group=group_id,
                        success=True,
                        input=input_value,
                        output=output_value,
                    )
                )
            except Exception as e:
                self._persister.save_failure(job.id(), e)
                job_complete = JobEvent(
                    variant=JobCompleteJobEventVariant(
                        type="jobComplete",
                        value=JobCompletedEvent(
                            jobId=job_id,
                            result=JobFailureResultVariant(
                                type="failure",
                                value=JobFailureResult(message=str(e)),
                            ),
                            progress=self._get_progress(),
                        ),
                    )
                )
                result_items.append(
                    JobResultItem(
                        id=job_id,
                        group=group_id,
                        success=False,
                        input=input_value,
                        error=str(e),
                    )
                )

            self._emit(job_complete)
            yield job_complete

            if job_group is not None:
                self._try_validate_group(job_group, validated_groups)

            job = self._persister.pop_pending()

        if self._output_writer is not None and result_items:
            self._output_writer.write_jobs(result_items)
