from __future__ import annotations

from types import SimpleNamespace
from typing import cast

import pytest

from percylib.external.models import (
    JobOutputFormat,
    JsonlOutputFormat,
    JsonlOutputFormatVariant,
)
from percylib.jobs.configured_ochestrator import create_output_writer_from_config
from percylib.jobs.output import JsonlOutputWriter


class TestCreateOutputWriterFromConfig:
    def test_returns_none_when_output_is_none(self) -> None:
        result = create_output_writer_from_config(None)
        assert result is None

    def test_creates_jsonl_writer_from_jsonl_config(self) -> None:
        output = JobOutputFormat(
            variant=JsonlOutputFormatVariant(
                type="jsonl",
                value=JsonlOutputFormat(path="output/results.jsonl"),
            )
        )
        result = create_output_writer_from_config(output)
        assert isinstance(result, JsonlOutputWriter)
        assert result._path == "output/results.jsonl"

    def test_raises_for_unsupported_format(self) -> None:
        unsupported = cast(
            JobOutputFormat,
            SimpleNamespace(
                variant=SimpleNamespace(type="csv", value=SimpleNamespace())
            ),
        )
        with pytest.raises(ValueError, match="Unsupported output format type"):
            create_output_writer_from_config(unsupported)
