from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from percylib.external.models import JobResultItem
from percylib.jobs.output import BaseOutputWriter, JsonlOutputWriter


class TestJsonlOutputWriter:
    def test_writes_single_job_result(self, tmp_path: Path) -> None:
        output_path = tmp_path / "results.jsonl"
        writer = JsonlOutputWriter(str(output_path))

        items = [
            JobResultItem(id="job-1", success=True, input="hello", output="HELLO"),
        ]
        writer.write_jobs(items)

        lines = output_path.read_text().strip().split("\n")
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["id"] == "job-1"
        assert data["success"] is True
        assert data["input"] == "hello"
        assert data["output"] == "HELLO"

    def test_writes_multiple_job_results(self, tmp_path: Path) -> None:
        output_path = tmp_path / "results.jsonl"
        writer = JsonlOutputWriter(str(output_path))

        items = [
            JobResultItem(id="job-1", success=True, input="a", output="A"),
            JobResultItem(id="job-2", success=False, input="b", error="failed"),
        ]
        writer.write_jobs(items)

        lines = output_path.read_text().strip().split("\n")
        assert len(lines) == 2
        first = json.loads(lines[0])
        assert first["id"] == "job-1"
        assert first["success"] is True
        second = json.loads(lines[1])
        assert second["id"] == "job-2"
        assert second["success"] is False
        assert second["error"] == "failed"

    def test_writes_empty_list(self, tmp_path: Path) -> None:
        output_path = tmp_path / "results.jsonl"
        writer = JsonlOutputWriter(str(output_path))

        writer.write_jobs([])

        assert output_path.read_text() == ""

    def test_each_line_is_valid_json(self, tmp_path: Path) -> None:
        output_path = tmp_path / "results.jsonl"
        writer = JsonlOutputWriter(str(output_path))

        items = [
            JobResultItem(id="j1", success=True),
            JobResultItem(id="j2", success=False, error="oops"),
            JobResultItem(id="j3", success=True, output={"key": "value"}),
        ]
        writer.write_jobs(items)

        lines = output_path.read_text().strip().split("\n")
        assert len(lines) == 3
        for line in lines:
            parsed = json.loads(line)
            assert "id" in parsed
            assert "success" in parsed

    def test_is_subclass_of_base_output_writer(self) -> None:
        assert issubclass(JsonlOutputWriter, BaseOutputWriter)

    def test_with_group_id(self, tmp_path: Path) -> None:
        from uuid import UUID

        output_path = tmp_path / "results.jsonl"
        writer = JsonlOutputWriter(str(output_path))

        group_uuid = UUID("550e8400-e29b-41d4-a716-446655440000")
        items = [
            JobResultItem(id="job-1", group=group_uuid, success=True),
        ]
        writer.write_jobs(items)

        lines = output_path.read_text().strip().split("\n")
        data = json.loads(lines[0])
        assert data["group"] == "550e8400-e29b-41d4-a716-446655440000"


class _RecordingOutputWriter(BaseOutputWriter):
    """Test double that records what was written."""

    def __init__(self) -> None:
        self.written: Optional[list[JobResultItem]] = None

    def write_jobs(self, jobs: list[JobResultItem]) -> None:
        self.written = jobs
