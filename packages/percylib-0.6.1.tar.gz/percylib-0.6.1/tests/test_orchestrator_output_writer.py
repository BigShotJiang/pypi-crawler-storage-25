from __future__ import annotations

import uuid
from typing import Optional

from percylib.external.models import JobResultItem
from percylib.jobs import (
    BaseJob,
    BaseJobExecutor,
    BaseOutputWriter,
    JobOutput,
    MemoryPersister,
)
from percylib.jobs.orchestrator import DefaultJobOrchestrator


class _TestJob(BaseJob[str]):
    def __init__(self, job_id: str, payload: str, group: str | None = None):
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> str:
        return self._payload


class _UpperExecutor(BaseJobExecutor["_TestJob", str]):
    def execute_job(self, job: _TestJob) -> JobOutput[str]:
        return JobOutput(output=job.input().upper())


class _FailingExecutor(BaseJobExecutor["_TestJob", str]):
    def execute_job(self, job: _TestJob) -> JobOutput[str]:
        raise RuntimeError(f"failed on {job.id()}")


class _RecordingOutputWriter(BaseOutputWriter):
    def __init__(self) -> None:
        self.written: Optional[list[JobResultItem]] = None

    def write_jobs(self, jobs: list[JobResultItem]) -> None:
        self.written = jobs


def _make_uuid() -> str:
    return str(uuid.uuid4())


class TestOrchestratorWithOutputWriter:
    def test_output_writer_receives_successful_results(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        writer = _RecordingOutputWriter()

        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            output_writer=writer,
        )
        list(orch.run())

        assert writer.written is not None
        assert len(writer.written) == 1
        item = writer.written[0]
        assert item.id == job_id
        assert item.success is True
        assert item.input == "hello"
        assert item.output == "HELLO"
        assert item.error is None

    def test_output_writer_receives_failure_results(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        writer = _RecordingOutputWriter()

        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_FailingExecutor(),
            output_writer=writer,
        )
        list(orch.run())

        assert writer.written is not None
        assert len(writer.written) == 1
        item = writer.written[0]
        assert item.id == job_id
        assert item.success is False
        assert item.input == "hello"
        assert item.output is None
        assert item.error is not None
        assert "failed on" in str(item.error)

    def test_output_writer_receives_mixed_results(self) -> None:
        id1, id2 = _make_uuid(), _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(id1, "ok"), _TestJob(id2, "bad")])

        class _MixedExecutor(BaseJobExecutor["_TestJob", str]):
            def execute_job(self, job: _TestJob) -> JobOutput[str]:
                if job.input() == "bad":
                    raise ValueError("nope")
                return JobOutput(output=job.input().upper())

        writer = _RecordingOutputWriter()
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_MixedExecutor(),
            output_writer=writer,
        )
        list(orch.run())

        assert writer.written is not None
        assert len(writer.written) == 2
        successes = [i for i in writer.written if i.success]
        failures = [i for i in writer.written if not i.success]
        assert len(successes) == 1
        assert len(failures) == 1

    def test_no_output_writer_is_fine(self) -> None:
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(_make_uuid(), "hello")])

        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            output_writer=None,
        )
        events = list(orch.run())
        assert len(events) == 3

    def test_output_writer_not_called_when_no_jobs(self) -> None:
        writer = _RecordingOutputWriter()
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
            output_writer=writer,
        )
        list(orch.run())

        # Writer should not have been called when there are no jobs
        assert writer.written is None

    def test_output_writer_includes_group_id(self) -> None:
        group = str(uuid.uuid4())
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello", group=group)])
        writer = _RecordingOutputWriter()

        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            output_writer=writer,
        )
        list(orch.run())

        assert writer.written is not None
        assert len(writer.written) == 1
        assert str(writer.written[0].group) == group

    def test_output_writer_group_is_none_when_not_set(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        writer = _RecordingOutputWriter()

        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            output_writer=writer,
        )
        list(orch.run())

        assert writer.written is not None
        assert writer.written[0].group is None
