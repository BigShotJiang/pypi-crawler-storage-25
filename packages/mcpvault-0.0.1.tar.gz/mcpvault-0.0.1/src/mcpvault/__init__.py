"""mcpvault - namespace placeholder. See https://gildara.io"""
__version__ = "0.0.1"
