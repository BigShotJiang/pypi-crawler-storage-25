"""Detection and Segmentation heads (inference only — no loss classes)."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List


class DetectionHead(nn.Module):
    def __init__(self, backbone_dims: List[int], hidden_dim: int = 256):
        super().__init__()
        self.scale_projs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(dim, hidden_dim, 1, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.GELU(),
            )
            for dim in backbone_dims
        ])
        self.fuse_conv = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_dim),
            nn.GELU(),
            nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_dim),
            nn.GELU(),
        )
        self.global_avg_pool = nn.AdaptiveAvgPool2d(1)
        self.global_max_pool = nn.AdaptiveMaxPool2d(1)
        self.center_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 2),
            nn.Sigmoid(),
        )
        self.size_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 2),
            nn.Sigmoid(),
        )
        self.conf_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, multi_scale_features: List[torch.Tensor]) -> Dict[str, torch.Tensor]:
        target_size = multi_scale_features[0].shape[2:]
        projected = []
        for feat, proj in zip(multi_scale_features, self.scale_projs):
            x = proj(feat)
            if x.shape[2:] != target_size:
                x = F.interpolate(x, size=target_size, mode='bilinear', align_corners=False)
            projected.append(x)

        fused = torch.stack(projected, dim=0).mean(dim=0)
        fused = self.fuse_conv(fused)

        avg_feat = self.global_avg_pool(fused).flatten(1)
        max_feat = self.global_max_pool(fused).flatten(1)

        center = self.center_head(avg_feat)
        size = self.size_head(torch.cat([avg_feat, max_feat], dim=1))
        bbox = torch.cat([center, size], dim=1)
        confidence = self.conf_head(avg_feat)

        return {'bbox': bbox, 'bbox_confidence': confidence}

    @staticmethod
    def bbox_cxcywh_to_xyxy(bbox: torch.Tensor) -> torch.Tensor:
        cx, cy, w, h = bbox.unbind(dim=-1)
        return torch.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], dim=-1)

    @staticmethod
    def bbox_xyxy_to_cxcywh(bbox: torch.Tensor) -> torch.Tensor:
        x1, y1, x2, y2 = bbox.unbind(dim=-1)
        return torch.stack([(x1 + x2) / 2, (y1 + y2) / 2, x2 - x1, y2 - y1], dim=-1)


class SegmentationHead(nn.Module):
    def __init__(self, backbone_dims: List[int], hidden_dim: int = 128,
                 output_size: List[int] = None):
        super().__init__()
        self.output_size = output_size
        self.laterals = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(dim, hidden_dim, 1, bias=False),
                nn.BatchNorm2d(hidden_dim),
            )
            for dim in backbone_dims
        ])
        self.topdown_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.GELU(),
            )
            for _ in range(len(backbone_dims) - 1)
        ])
        self.final_upsample = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_dim),
            nn.GELU(),
            nn.Conv2d(hidden_dim, hidden_dim // 2, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_dim // 2),
            nn.GELU(),
            nn.Conv2d(hidden_dim // 2, 1, 1),
        )

    def forward(self, multi_scale_features: List[torch.Tensor]) -> Dict[str, torch.Tensor]:
        laterals = [lat(feat) for lat, feat in zip(self.laterals, multi_scale_features)]
        x = laterals[-1]
        for i in range(len(laterals) - 2, -1, -1):
            x = F.interpolate(x, size=laterals[i].shape[2:], mode='bilinear', align_corners=False)
            x = x + laterals[i]
            if i < len(self.topdown_convs):
                x = self.topdown_convs[len(laterals) - 2 - i](x)
        if self.output_size is not None:
            x = F.interpolate(x, size=self.output_size, mode='bilinear', align_corners=False)
        mask_logits = self.final_upsample(x)
        return {'mask_logits': mask_logits, 'mask_prob': torch.sigmoid(mask_logits)}
