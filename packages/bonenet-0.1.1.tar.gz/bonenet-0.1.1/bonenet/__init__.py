"""
BoneNet — neural skeleton pose estimation in 3 lines.

    import bonenet
    model = bonenet.load("Haa-mad/chick-pose")
    result = bonenet.predict(model, "image.jpg")
    # result['keypoints'] → {'beak': (x, y), 'head': (x, y), ...}
"""

from pathlib import Path
from typing import Union, Dict, Any, List, Optional

import torch
from PIL import Image
from torchvision import transforms

from ._model import AnimalPoseModel

_transform = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
])


def load(hf_repo: str, filename: str = "best_model.pth", device: str = None) -> AnimalPoseModel:
    """Download (once) and load a BoneNet model from HuggingFace.

    Args:
        hf_repo: HuggingFace repo ID, e.g. "Haa-mad/chick-pose"
        filename: checkpoint filename in the repo (default: best_model.pth)
        device:   'cuda', 'cpu', or None (auto-detects GPU)

    Returns:
        Loaded AnimalPoseModel ready for inference.

    Example:
        model = bonenet.load("Haa-mad/chick-pose")
    """
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        raise ImportError("Run: pip install huggingface_hub")

    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

    path = hf_hub_download(repo_id=hf_repo, filename=filename)
    return AnimalPoseModel.load(path, device=device)


def predict(
    model: AnimalPoseModel,
    image: Union[str, Path, 'Image.Image', 'np.ndarray'],
    device: str = None,
) -> Dict[str, Any]:
    """Run pose estimation on a single image.

    Args:
        model:  Loaded model from bonenet.load().
        image:  PIL Image, file path, or numpy array (RGB or BGR uint8).
        device: Override device (defaults to model's device).

    Returns:
        dict with:
          'keypoints'  — {name: (x, y)} pixel coords in original image space
          'confidence' — [float] per-keypoint confidence
          'bbox'       — [cx, cy, w, h] normalized to [0, 1]
          'keypoint_names' — ordered list of keypoint names
    """
    if isinstance(image, (str, Path)):
        image = Image.open(image).convert('RGB')
    elif not isinstance(image, Image.Image):
        import numpy as np
        image = Image.fromarray(np.asarray(image, dtype='uint8')).convert('RGB')

    orig_w, orig_h = image.size
    tensor = _transform(image).unsqueeze(0)  # (1, 3, 256, 256)

    if device is None:
        device = next(model.parameters()).device
    tensor = tensor.to(device)

    with torch.no_grad():
        result = model.predict(tensor)

    coords = result['coordinates'][0].cpu()  # (K, 2) in 256x256 space
    coords[:, 0] = coords[:, 0] * orig_w / 256
    coords[:, 1] = coords[:, 1] * orig_h / 256

    keypoint_names = model.skeleton.keypoints

    return {
        'keypoints': {
            name: (float(coords[i, 0]), float(coords[i, 1]))
            for i, name in enumerate(keypoint_names)
        },
        'confidence': result['confidence'][0].cpu().tolist(),
        'bbox': result['bbox'][0].cpu().tolist(),
        'keypoint_names': keypoint_names,
    }


__all__ = ['load', 'predict', 'AnimalPoseModel']
