"""ViT backbone with multi-scale feature extraction (inference-only copy)."""

import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List
import math


class ViTHBackbone(nn.Module):
    SIZE_CONFIGS = {
        'small':  (384,  12, 6,  'vit_small_patch16_224.augreg_in21k'),
        'base':   (768,  12, 12, 'vit_base_patch16_224.mae'),
        'large':  (1024, 24, 16, 'vit_large_patch16_224.mae'),
        'huge':   (1280, 32, 16, 'vit_huge_patch16_224.mae'),
    }

    def __init__(self, config: dict):
        super().__init__()
        pretrained = config.get('pretrained', True)
        patch_size = config.get('patch_size', 16)
        img_size = config.get('img_size', 256)
        drop_path_rate = config.get('drop_path_rate', 0.1)
        size = config.get('size', 'small')
        self._pretrained_source = config.get('pretrained_source', 'mae')

        self.patch_size = patch_size
        self.img_size = img_size
        self.size = size

        embed_dim, depth, num_heads, self._timm_name = self.SIZE_CONFIGS[size]
        self.embed_dim = embed_dim
        self.num_patches_side = img_size // patch_size

        self.patch_embed = nn.Conv2d(3, self.embed_dim, kernel_size=patch_size, stride=patch_size, bias=True)
        num_patches = self.num_patches_side ** 2
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, self.embed_dim))
        self.cls_token = nn.Parameter(torch.zeros(1, 1, self.embed_dim))

        self.blocks = nn.ModuleList([
            TransformerBlock(
                dim=self.embed_dim,
                num_heads=num_heads,
                mlp_ratio=4.0,
                drop_path=drop_path_rate * i / max(1, depth - 1),
            )
            for i in range(depth)
        ])
        self.norm = nn.LayerNorm(self.embed_dim)

        d = depth
        self.scale_taps = [d//4 - 1, d//2 - 1, 3*d//4 - 1, d - 1]
        self.out_dims = [256, 512, 1024, embed_dim]

        self.scale_projs = nn.ModuleList([
            nn.Sequential(
                nn.LayerNorm(self.embed_dim),
                nn.Linear(self.embed_dim, out_dim),
            )
            for out_dim in self.out_dims
        ])

        self._init_weights()

        if pretrained:
            self._load_pretrained_weights()

    def _init_weights(self):
        pos = self._build_sinusoidal_pos_embed(self.num_patches_side, self.num_patches_side, self.embed_dim)
        self.pos_embed.data.copy_(pos.unsqueeze(0))
        nn.init.trunc_normal_(self.cls_token, std=0.02)
        nn.init.trunc_normal_(self.patch_embed.weight, std=0.02)

    @staticmethod
    def _build_sinusoidal_pos_embed(h: int, w: int, dim: int) -> torch.Tensor:
        pe = torch.zeros(h * w, dim)
        position = torch.arange(h * w).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, dim, 2).float() * -(math.log(10000.0) / dim))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe

    def _load_pretrained_weights(self):
        if self._pretrained_source == 'vitpose':
            self._load_vitpose_weights()
        else:
            self._load_mae_weights()

    def _load_vitpose_weights(self):
        try:
            from transformers import VitPoseBackbone
            hf_repo = f'usyd-community/vitpose-{self.size}'
            print(f"Loading ViTPose-{self.size} weights from HuggingFace ({hf_repo})...", file=sys.stderr)
            hf_model = VitPoseBackbone.from_pretrained(hf_repo)
            sd = hf_model.state_dict()
            with torch.no_grad():
                pe_w = sd.get('backbone.embeddings.patch_embeddings.projection.weight')
                pe_b = sd.get('backbone.embeddings.patch_embeddings.projection.bias')
                if pe_w is not None and pe_w.shape == self.patch_embed.weight.shape:
                    self.patch_embed.weight.data.copy_(pe_w)
                if pe_b is not None:
                    self.patch_embed.bias.data.copy_(pe_b)
                pos = sd.get('backbone.embeddings.position_embeddings')
                if pos is not None:
                    N = pos.shape[1]
                    sq = int(math.sqrt(N - 1))
                    if sq * sq == N - 1:
                        pos = pos[:, 1:, :]
                    if pos.shape[1] != self.pos_embed.shape[1]:
                        pos = self._interpolate_pos_embed_nonsquare(pos, self.num_patches_side)
                    if pos.shape[1] == self.pos_embed.shape[1]:
                        self.pos_embed.data.copy_(pos)
                for s in ('weight', 'bias'):
                    v = sd.get(f'backbone.layernorm.{s}')
                    p = getattr(self.norm, s, None)
                    if v is not None and p is not None and v.shape == p.shape:
                        p.data.copy_(v)
                transferred = 0
                for i in range(len(self.blocks)):
                    pfx = f'backbone.encoder.layer.{i}'
                    blk = self.blocks[i]
                    for our, hf in [('norm1', 'layernorm_before'), ('norm2', 'layernorm_after')]:
                        for s in ('weight', 'bias'):
                            v = sd.get(f'{pfx}.{hf}.{s}')
                            p = getattr(getattr(blk, our), s)
                            if v is not None and v.shape == p.shape:
                                p.data.copy_(v)
                    q_w = sd.get(f'{pfx}.attention.attention.query.weight')
                    k_w = sd.get(f'{pfx}.attention.attention.key.weight')
                    v_w = sd.get(f'{pfx}.attention.attention.value.weight')
                    q_b = sd.get(f'{pfx}.attention.attention.query.bias')
                    k_b = sd.get(f'{pfx}.attention.attention.key.bias')
                    v_b = sd.get(f'{pfx}.attention.attention.value.bias')
                    if q_w is not None and k_w is not None and v_w is not None:
                        qkv_w = torch.cat([q_w, k_w, v_w], dim=0)
                        if qkv_w.shape == blk.attn.qkv.weight.shape:
                            blk.attn.qkv.weight.data.copy_(qkv_w)
                    if q_b is not None and k_b is not None and v_b is not None:
                        qkv_b = torch.cat([q_b, k_b, v_b], dim=0)
                        if qkv_b.shape == blk.attn.qkv.bias.shape:
                            blk.attn.qkv.bias.data.copy_(qkv_b)
                    for s in ('weight', 'bias'):
                        v = sd.get(f'{pfx}.attention.output.dense.{s}')
                        p = getattr(blk.attn.proj, s)
                        if v is not None and v.shape == p.shape:
                            p.data.copy_(v)
                    for fc in ('fc1', 'fc2'):
                        for s in ('weight', 'bias'):
                            v = sd.get(f'{pfx}.mlp.{fc}.{s}')
                            p = getattr(getattr(blk.ffn, fc), s)
                            if v is not None and v.shape == p.shape:
                                p.data.copy_(v)
                    transferred += 1
            print(f"ViTPose-{self.size} weights loaded: {transferred}/{len(self.blocks)} blocks transferred.", file=sys.stderr)
            del hf_model, sd
        except Exception as e:
            print(f"Warning: Could not load ViTPose weights: {e}", file=sys.stderr)
            self._load_mae_weights()

    def _load_mae_weights(self):
        try:
            import timm
            print(f"Loading ViT-{self.size} MAE weights from timm ({self._timm_name})...", file=sys.stderr)
            vit_pretrained = timm.create_model(self._timm_name, pretrained=True, img_size=self.img_size)
            if vit_pretrained.patch_embed.proj.weight.shape == self.patch_embed.weight.shape:
                self.patch_embed.weight.data.copy_(vit_pretrained.patch_embed.proj.weight.data)
                self.patch_embed.bias.data.copy_(vit_pretrained.patch_embed.proj.bias.data)
            pretrained_pos = vit_pretrained.pos_embed[:, 1:, :]
            if pretrained_pos.shape[1] != self.pos_embed.shape[1]:
                pretrained_pos = self._interpolate_pos_embed(pretrained_pos, self.num_patches_side)
            self.pos_embed.data.copy_(pretrained_pos)
            self.cls_token.data.copy_(vit_pretrained.cls_token.data)
            n_blocks = min(len(self.blocks), len(vit_pretrained.blocks))
            for i in range(n_blocks):
                self._transfer_block_weights(self.blocks[i], vit_pretrained.blocks[i])
            print(f"MAE ViT-{self.size} weights loaded successfully.", file=sys.stderr)
            del vit_pretrained
        except Exception as e:
            print(f"Warning: Could not load MAE weights: {e}", file=sys.stderr)

    @staticmethod
    def _interpolate_pos_embed(pos_embed: torch.Tensor, new_size: int) -> torch.Tensor:
        old_size = int(math.sqrt(pos_embed.shape[1]))
        if old_size == new_size:
            return pos_embed
        pos_2d = pos_embed.reshape(1, old_size, old_size, -1).permute(0, 3, 1, 2)
        pos_2d = F.interpolate(pos_2d, size=(new_size, new_size), mode='bicubic', align_corners=False)
        return pos_2d.permute(0, 2, 3, 1).reshape(1, new_size * new_size, -1)

    @staticmethod
    def _interpolate_pos_embed_nonsquare(pos_embed: torch.Tensor, new_size: int) -> torch.Tensor:
        N, D = pos_embed.shape[1], pos_embed.shape[2]
        best_h, best_w = 1, N
        for h in range(1, int(N**0.5) + 1):
            if N % h == 0:
                best_h, best_w = h, N // h
        pos_2d = pos_embed.reshape(1, best_h, best_w, D).permute(0, 3, 1, 2)
        pos_2d = F.interpolate(pos_2d, size=(new_size, new_size), mode='bicubic', align_corners=False)
        return pos_2d.permute(0, 2, 3, 1).reshape(1, new_size * new_size, -1)

    @staticmethod
    def _transfer_block_weights(dst, src: nn.Module):
        try:
            dst.norm1.weight.data.copy_(src.norm1.weight.data)
            dst.norm1.bias.data.copy_(src.norm1.bias.data)
            dst.norm2.weight.data.copy_(src.norm2.weight.data)
            dst.norm2.bias.data.copy_(src.norm2.bias.data)
            dst.attn.qkv.weight.data.copy_(src.attn.qkv.weight.data)
            dst.attn.qkv.bias.data.copy_(src.attn.qkv.bias.data)
            dst.attn.proj.weight.data.copy_(src.attn.proj.weight.data)
            dst.attn.proj.bias.data.copy_(src.attn.proj.bias.data)
            dst.ffn.fc1.weight.data.copy_(src.mlp.fc1.weight.data)
            dst.ffn.fc1.bias.data.copy_(src.mlp.fc1.bias.data)
            dst.ffn.fc2.weight.data.copy_(src.mlp.fc2.weight.data)
            dst.ffn.fc2.bias.data.copy_(src.mlp.fc2.bias.data)
        except Exception:
            pass

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        B, C, H, W = x.shape
        Hp = H // self.patch_size
        Wp = W // self.patch_size
        x = self.patch_embed(x)
        x = x.flatten(2).transpose(1, 2)
        x = x + self.pos_embed
        tap_outputs = {}
        for i, block in enumerate(self.blocks):
            x = block(x)
            if i in self.scale_taps:
                tap_outputs[i] = x
        x = self.norm(x)
        tap_outputs[self.scale_taps[-1]] = x
        multi_scale = []
        for tap_idx, proj, out_dim in zip(self.scale_taps, self.scale_projs, self.out_dims):
            feat = tap_outputs[tap_idx]
            feat = proj(feat)
            feat = feat.transpose(1, 2).reshape(B, out_dim, Hp, Wp)
            multi_scale.append(feat)
        outputs = []
        target_sizes = [(Hp * 2, Wp * 2), (Hp, Wp), (Hp // 2, Wp // 2), (Hp // 2, Wp // 2)]
        for feat, size in zip(multi_scale, target_sizes):
            if feat.shape[2:] != size:
                feat = F.interpolate(feat, size=size, mode='bilinear', align_corners=False)
            outputs.append(feat)
        return outputs

    def get_output_dims(self) -> List[int]:
        return self.out_dims


class StochasticDepth(nn.Module):
    def __init__(self, p: float = 0.1):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not self.training or self.p == 0:
            return x
        keep_prob = 1 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        mask = torch.bernoulli(torch.full(shape, keep_prob, device=x.device))
        return x * mask / keep_prob


class Attention(nn.Module):
    def __init__(self, dim: int, num_heads: int):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=True)
        self.proj = nn.Linear(dim, dim, bias=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, D = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        x = (attn @ v).transpose(1, 2).reshape(B, N, D)
        return self.proj(x)


class FFN(nn.Module):
    def __init__(self, dim: int, mlp_ratio: float = 4.0):
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.fc1 = nn.Linear(dim, hidden, bias=True)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden, dim, bias=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(x)))


class TransformerBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, mlp_ratio: float = 4.0, drop_path: float = 0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim, num_heads)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = FFN(dim, mlp_ratio)
        self.drop_path = StochasticDepth(drop_path) if drop_path > 0 else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.drop_path(self.attn(self.norm1(x)))
        x = x + self.drop_path(self.ffn(self.norm2(x)))
        return x


Backbone = ViTHBackbone
