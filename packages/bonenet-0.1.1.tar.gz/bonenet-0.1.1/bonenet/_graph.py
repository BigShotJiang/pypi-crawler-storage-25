"""Anatomical Graph Transformer (inference-only copy)."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Optional

from ._skeleton import Skeleton


class GraphPositionalEncoding(nn.Module):
    def __init__(self, hidden_dim: int, max_hops: int = 10):
        super().__init__()
        self.hop_embeddings = nn.Embedding(max_hops + 1, hidden_dim)

    def forward(self, hop_distance: torch.Tensor) -> torch.Tensor:
        dist = hop_distance.clamp(max=self.hop_embeddings.num_embeddings - 1)
        return self.hop_embeddings(dist)


class AnatomicalPrior(nn.Module):
    def __init__(self, hidden_dim: int, num_keypoints: int, num_edges: int):
        super().__init__()
        self.bone_length_embed = nn.Parameter(torch.randn(num_edges, hidden_dim) * 0.02)
        self.bone_direction_embed = nn.Parameter(torch.randn(num_edges, hidden_dim) * 0.02)
        self.keypoint_type_embed = nn.Parameter(torch.randn(num_keypoints, hidden_dim) * 0.02)

    def forward(self, keypoint_tokens: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        B = keypoint_tokens.shape[0]
        return keypoint_tokens + self.keypoint_type_embed.unsqueeze(0).expand(B, -1, -1)


class GraphAttentionLayer(nn.Module):
    def __init__(self, hidden_dim: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.scale = self.head_dim ** -0.5

        self.self_q = nn.Linear(hidden_dim, hidden_dim)
        self.self_k = nn.Linear(hidden_dim, hidden_dim)
        self.self_v = nn.Linear(hidden_dim, hidden_dim)
        self.self_out = nn.Linear(hidden_dim, hidden_dim)

        self.cross_q = nn.Linear(hidden_dim, hidden_dim)
        self.cross_k = nn.Linear(hidden_dim, hidden_dim)
        self.cross_v = nn.Linear(hidden_dim, hidden_dim)
        self.cross_out = nn.Linear(hidden_dim, hidden_dim)

        self.dist_bias_proj = nn.Linear(hidden_dim, num_heads)

        self.ffn = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.Dropout(dropout),
        )
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(hidden_dim)
        self.norm3 = nn.LayerNorm(hidden_dim)
        self.attn_dropout = nn.Dropout(dropout)

    def _graph_self_attention(self, x: torch.Tensor, hop_encoding: torch.Tensor) -> torch.Tensor:
        B, K, D = x.shape
        q = self.self_q(x).view(B, K, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.self_k(x).view(B, K, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.self_v(x).view(B, K, self.num_heads, self.head_dim).transpose(1, 2)
        attn = torch.matmul(q, k.transpose(-2, -1)) * self.scale
        dist_bias = self.dist_bias_proj(hop_encoding).permute(2, 0, 1).unsqueeze(0)
        attn = attn + dist_bias
        attn = self.attn_dropout(attn.softmax(dim=-1))
        out = torch.matmul(attn, v).transpose(1, 2).reshape(B, K, D)
        return self.self_out(out)

    def _cross_attention(self, keypoints: torch.Tensor, spatial_features: torch.Tensor) -> torch.Tensor:
        B, K, D = keypoints.shape
        q = self.cross_q(keypoints).view(B, K, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.cross_k(spatial_features).view(B, -1, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.cross_v(spatial_features).view(B, -1, self.num_heads, self.head_dim).transpose(1, 2)
        attn = self.attn_dropout((torch.matmul(q, k.transpose(-2, -1)) * self.scale).softmax(dim=-1))
        out = torch.matmul(attn, v).transpose(1, 2).reshape(B, K, D)
        return self.cross_out(out)

    def forward(self, keypoint_tokens, spatial_features, hop_encoding):
        x = keypoint_tokens
        x = x + self._graph_self_attention(self.norm1(x), hop_encoding)
        x = x + self._cross_attention(self.norm2(x), spatial_features)
        x = x + self.ffn(self.norm3(x))
        return x


class AnatomicalGraphTransformer(nn.Module):
    def __init__(self, config: dict, skeleton: Skeleton, backbone_dims: list):
        super().__init__()
        hidden_dim = config.get('hidden_dim', 256)
        num_layers = config['num_layers']
        num_heads = config['num_heads']
        dropout = config['dropout']
        num_keypoints = skeleton.num_keypoints
        num_edges = skeleton.edge_index.shape[1] // 2

        self.hidden_dim = hidden_dim
        self.skeleton = skeleton

        self.feature_projs = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(dim, hidden_dim, 1, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.GELU(),
            )
            for dim in backbone_dims
        ])

        self.keypoint_queries = nn.Parameter(torch.randn(num_keypoints, hidden_dim) * 0.02)
        self.graph_pos_enc = GraphPositionalEncoding(hidden_dim)
        self.anatomical_prior = AnatomicalPrior(hidden_dim, num_keypoints, num_edges)

        self.layers = nn.ModuleList([
            GraphAttentionLayer(hidden_dim, num_heads, dropout)
            for _ in range(num_layers)
        ])
        self.output_norm = nn.LayerNorm(hidden_dim)

        self.register_buffer('hop_distance', skeleton.hop_distance)
        self.register_buffer('edge_index', skeleton.edge_index)

    def _fuse_multiscale_features(self, multi_scale_features: list) -> torch.Tensor:
        target_h, target_w = multi_scale_features[0].shape[2:]
        projected = []
        for feat, proj in zip(multi_scale_features, self.feature_projs):
            x = proj(feat)
            if x.shape[2:] != (target_h, target_w):
                x = F.interpolate(x, size=(target_h, target_w), mode='bilinear', align_corners=False)
            projected.append(x)
        fused = torch.stack(projected, dim=0).mean(dim=0)
        B, D, H, W = fused.shape
        return fused.flatten(2).transpose(1, 2)

    def forward(self, multi_scale_features: list) -> torch.Tensor:
        B = multi_scale_features[0].shape[0]
        spatial_features = self._fuse_multiscale_features(multi_scale_features)
        keypoint_tokens = self.keypoint_queries.unsqueeze(0).expand(B, -1, -1)
        keypoint_tokens = self.anatomical_prior(keypoint_tokens, self.edge_index)
        hop_encoding = self.graph_pos_enc(self.hop_distance)
        for layer in self.layers:
            keypoint_tokens = layer(keypoint_tokens, spatial_features, hop_encoding)
        return self.output_norm(keypoint_tokens)
