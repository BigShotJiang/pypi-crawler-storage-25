"""Keypoint output heads (inference-only copy)."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple

from ._skeleton import Skeleton


class HeatmapHead(nn.Module):
    def __init__(self, in_channels: int, num_keypoints: int,
                 num_deconv_layers: int = 3, num_deconv_filters: list = None):
        super().__init__()
        if num_deconv_filters is None:
            num_deconv_filters = [256, 256, 256]
        layers = []
        current_channels = in_channels
        for i in range(num_deconv_layers):
            out_channels = num_deconv_filters[i]
            layers.extend([
                nn.ConvTranspose2d(current_channels, out_channels, kernel_size=4, stride=2, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.GELU(),
            ])
            current_channels = out_channels
        self.deconv = nn.Sequential(*layers)
        self.final_conv = nn.Conv2d(current_channels, num_keypoints, 1, bias=True)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.final_conv(self.deconv(features))


class RegressionHead(nn.Module):
    def __init__(self, hidden_dim: int, num_keypoints: int):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 2),
        )

    def forward(self, keypoint_features: torch.Tensor) -> torch.Tensor:
        return self.mlp(keypoint_features)


class GraphRefinementHead(nn.Module):
    def __init__(self, hidden_dim: int, num_keypoints: int, skeleton: Skeleton):
        super().__init__()
        self.skeleton = skeleton
        self.coord_encoder = nn.Sequential(
            nn.Linear(2, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, hidden_dim),
        )
        self.gcn1 = GraphConvLayer(hidden_dim * 2, hidden_dim)
        self.gcn2 = GraphConvLayer(hidden_dim, hidden_dim)
        self.coord_decoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 2),
            nn.Tanh(),
        )
        self.refinement_scale = nn.Parameter(torch.tensor(0.1))
        self.register_buffer('norm_adj', skeleton.norm_adj)

    def forward(self, keypoint_features: torch.Tensor, initial_coords: torch.Tensor) -> torch.Tensor:
        coord_features = self.coord_encoder(initial_coords)
        combined = torch.cat([keypoint_features, coord_features], dim=-1)
        x = self.gcn1(combined, self.norm_adj)
        x = self.gcn2(x, self.norm_adj)
        delta = self.coord_decoder(x) * self.refinement_scale
        return initial_coords + delta


class GraphConvLayer(nn.Module):
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim, bias=False)
        self.bias = nn.Parameter(torch.zeros(out_dim))
        self.norm = nn.LayerNorm(out_dim)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        support = self.linear(x)
        out = torch.matmul(adj.unsqueeze(0), support) + self.bias
        return F.gelu(self.norm(out))


class UncertaintyHead(nn.Module):
    def __init__(self, hidden_dim: int, num_keypoints: int):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, keypoint_features: torch.Tensor) -> torch.Tensor:
        return self.mlp(keypoint_features).squeeze(-1)


def heatmap_to_coordinates(heatmaps: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    B, K, H, W = heatmaps.shape
    heatmaps_flat = heatmaps.view(B, K, -1)
    heatmaps_softmax = F.softmax(heatmaps_flat * 10.0, dim=-1).view(B, K, H, W)
    grid_y = torch.arange(H, device=heatmaps.device, dtype=torch.float32) / (H - 1)
    grid_x = torch.arange(W, device=heatmaps.device, dtype=torch.float32) / (W - 1)
    coord_x = (heatmaps_softmax.sum(dim=2) * grid_x[None, None, :]).sum(dim=-1)
    coord_y = (heatmaps_softmax.sum(dim=3) * grid_y[None, None, :]).sum(dim=-1)
    coords = torch.stack([coord_x, coord_y], dim=-1)
    confidence = heatmaps_flat.max(dim=-1).values
    return coords, confidence
