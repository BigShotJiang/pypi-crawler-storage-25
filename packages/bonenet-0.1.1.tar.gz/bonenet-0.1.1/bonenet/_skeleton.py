"""Skeleton utilities for keypoint graph reasoning."""

from __future__ import annotations

from typing import Dict, List, Tuple
import torch


class Skeleton:
    """Holds keypoint graph structure and derived tensors."""

    def __init__(self, cfg: Dict):
        self.keypoints: List[str] = list(cfg.get("keypoints", []))
        self.edges: List[Tuple[str, str]] = [tuple(e) for e in cfg.get("edges", [])]
        self.symmetric_pairs: List[Tuple[str, str]] = [
            tuple(p) for p in cfg.get("symmetric_pairs", [])
        ]

        if not self.keypoints:
            raise ValueError("Skeleton requires at least one keypoint.")

        self._kp_index = {name: i for i, name in enumerate(self.keypoints)}
        self.num_keypoints = len(self.keypoints)

        self.edge_index = self._build_edge_index()
        self.adj = self._build_adj()
        self.norm_adj = self._normalize_adj(self.adj)
        self.hop_distance = self._compute_hop_distance()

    def __repr__(self) -> str:
        return f"Skeleton(K={self.num_keypoints}, E={len(self.edges)})"

    def keypoint_index(self, name: str) -> int:
        return self._kp_index[name]

    def get_parent_indices(self) -> torch.Tensor:
        parents = torch.full((self.num_keypoints,), -1, dtype=torch.long)
        for a, b in self.edges:
            ia, ib = self.keypoint_index(a), self.keypoint_index(b)
            if parents[ib].item() == -1:
                parents[ib] = ia
            if parents[ia].item() == -1:
                parents[ia] = ib
        return parents

    def get_flip_indices(self) -> torch.Tensor:
        idx = list(range(self.num_keypoints))
        for a, b in self.symmetric_pairs:
            ia, ib = self.keypoint_index(a), self.keypoint_index(b)
            idx[ia], idx[ib] = idx[ib], idx[ia]
        return torch.tensor(idx, dtype=torch.long)

    def _build_edge_index(self) -> torch.Tensor:
        edges = []
        for a, b in self.edges:
            ia, ib = self.keypoint_index(a), self.keypoint_index(b)
            edges.append([ia, ib])
            edges.append([ib, ia])
        if not edges:
            return torch.zeros(2, 0, dtype=torch.long)
        return torch.tensor(edges, dtype=torch.long).t().contiguous()

    def _build_adj(self) -> torch.Tensor:
        K = self.num_keypoints
        adj = torch.zeros((K, K), dtype=torch.float32)
        for a, b in self.edges:
            ia, ib = self.keypoint_index(a), self.keypoint_index(b)
            adj[ia, ib] = 1.0
            adj[ib, ia] = 1.0
        adj.fill_diagonal_(1.0)
        return adj

    @staticmethod
    def _normalize_adj(adj: torch.Tensor) -> torch.Tensor:
        deg = adj.sum(dim=1)
        deg_inv_sqrt = torch.pow(deg, -0.5)
        deg_inv_sqrt[torch.isinf(deg_inv_sqrt)] = 0.0
        D_inv = torch.diag(deg_inv_sqrt)
        return D_inv @ adj @ D_inv

    def _compute_hop_distance(self) -> torch.Tensor:
        K = self.num_keypoints
        adj = (self.adj > 0).int()
        hop = torch.full((K, K), fill_value=K, dtype=torch.long)
        for i in range(K):
            hop[i, i] = 0
            queue = [i]
            while queue:
                v = queue.pop(0)
                for u in torch.nonzero(adj[v]).flatten().tolist():
                    if hop[i, u] > hop[i, v] + 1:
                        hop[i, u] = hop[i, v] + 1
                        queue.append(u)
        return hop
