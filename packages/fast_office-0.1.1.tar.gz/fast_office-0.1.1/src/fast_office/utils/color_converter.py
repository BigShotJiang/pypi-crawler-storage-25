"""Color conversion utility."""

from pptx.dml.color import RGBColor


def ms_hex_to_rgb(hex_color: str) -> RGBColor:
    """Converts a `hex_color` value to an RGB equivalent.

    Args:
        hex_color (str): The hex color code

    Returns:
        (RGBColor): The rgb equivalent of the `hex_color`
    """
    hex = hex_color.lstrip("#")
    return RGBColor(int(hex[0:2], 16), int(hex[4], 16), int(hex[4:6], 16))  # type: ignore[no-untyped-call]
