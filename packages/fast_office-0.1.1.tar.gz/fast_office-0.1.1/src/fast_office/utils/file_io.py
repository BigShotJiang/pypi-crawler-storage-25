"""File Read/Write utils."""

import uuid
from pathlib import Path

from fast_office.config.config import config


def create_file_path(filename: str, extension: str) -> Path:
    """Generates a file path to write data to.

    Returns:
        Generated Path.
    """
    out_dir = config.ensure_output_dir()
    filename = "".join(c if c.isalnum() or c in "-_" else "" for c in filename).strip()
    filename = f"{filename}_{uuid.uuid4().hex[:8]}.{extension.lstrip('.').lower()}".strip()
    return out_dir / filename
