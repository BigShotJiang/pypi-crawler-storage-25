"""DOCX document generation utilities."""

from __future__ import annotations

import uuid
from pathlib import Path
from typing import cast

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.styles.style import _ParagraphStyle
from docx.text.paragraph import Paragraph

from fast_office.config.config import config
from fast_office.types.alignment import H_ALIGN
from fast_office.types.docx import (
    ContentElement,
    DocxHeading,
    DocxImage,
    DocxParagraph,
    DocxSection,
    DocxSpec,
    DocxTable,
)


def _hex_to_rgb(hex_color: str) -> RGBColor:
    """Converts a `hex_color` value to an RGB equivalent.

    Args:
        hex_color (str): The hex color code

    Returns:
        (RGBColor): The rgb equivalent of the `hex_color`
    """
    hex = hex_color.lstrip("#")
    return RGBColor(int(hex[0:2], 16), int(hex[4], 16), int(hex[4:6], 16))


class DocxGenerator:
    """Generates DOCX files from a `DocxSpec`."""

    def __init__(self, spec: DocxSpec) -> None:
        """Initialize the DOCX generator.

        Args:
            spec: Document specification describing document structure and styling.
        """
        self.spec = spec
        self.doc = Document()

    def generate(self) -> Path:
        """Generate and save the DOCX document.

        Returns:
            Path to the generated DOCX file.
        """
        self._set_defaults()
        self._set_core_properties()
        self._add_header_and_footer()

        for section_spec in self.spec.sections:
            self._add_section(section_spec)

        return self._save()

    def _set_defaults(self) -> None:
        """Apply default document styling and page layout settings."""
        style = self.doc.styles["Normal"]
        style = cast(_ParagraphStyle, style)
        font = style.font
        font.name = self.spec.font_name
        font.size = Pt(self.spec.font_size)

        for section in self.doc.sections:
            section.top_margin = Inches(1)
            section.bottom_margin = Inches(1)
            section.left_margin = Inches(1)
            section.right_margin = Inches(1)
            section.orientation = WD_ORIENT.PORTRAIT

    def _set_core_properties(self) -> None:
        """Set DOCX core document metadata."""
        props = self.doc.core_properties
        props.title = self.spec.title
        if self.spec.author:
            props.author = self.spec.author
        if self.spec.organization:
            props.category = self.spec.organization

    def _add_header_and_footer(self) -> None:
        """Add document header and footer content."""
        section = self.doc.sections[0]

        if self.spec.header_text:
            header = section.header
            header.is_linked_to_previous = False
            p = header.paragraphs[0]
            run = p.add_run(self.spec.header_text)
            run.font.size = Pt(9)
            p.alignment = H_ALIGN["center"]

        if self.spec.footer_text or self.spec.page_numbers:
            footer = section.footer
            footer.is_linked_to_previous = False
            p = footer.paragraphs[0]

            if self.spec.footer_text:
                run = p.add_run(self.spec.footer_text)
                run.font.size = Pt(9)

            if self.spec.page_numbers:
                if self.spec.footer_text:
                    p.add_run("\t")
                self._add_page_number(p)
            p.alignment = H_ALIGN["center"]

    def _add_page_number(self, paragraph: Paragraph) -> None:
        """Insert a dynamic page number field into a paragraph.

        Args:
            paragraph: Paragraph to insert the page number field into.
        """
        run = paragraph.add_run()
        fld_char_begin = run._r.makeelement(qn("w:fldChar"), {qn("w:fldCharType"): "begin"})
        run._r.append(fld_char_begin)

        run2 = paragraph.add_run()
        instr_text = run2._r.makeelement(qn("w:instrText"), {})
        instr_text.text = " PAGE "
        run2._r.append(instr_text)

    def _add_section(self, section_spec: DocxSection) -> None:
        """Add a document section and its content elements.

        Args:
            section_spec: Section specification to render.
        """
        if section_spec.heading:
            self.doc.add_heading(text=section_spec.heading.text, level=section_spec.heading.level)

        for elem in section_spec.content:
            element_type = elem.get("type")
            element = elem.get("element")
            if not element:
                continue
            if element_type == ContentElement.HEADING:
                self._add_heading_element(DocxHeading.model_validate(element))
            elif element_type == ContentElement.PARAGRAPH:
                self._add_paragraph_element(DocxParagraph.model_validate(element))
            elif element_type == ContentElement.TABLE:
                self._add_table_element(DocxTable.model_validate(element))
            elif element_type == ContentElement.IMAGE:
                self._add_image_element(DocxImage.model_validate(element))
            elif element_type == ContentElement.PAGE_BREAK:
                self.doc.add_page_break()  # type: ignore[no-untyped-call]

    def _add_heading_element(self, element: DocxHeading) -> None:
        """Add a heading element to the document.

        Args:
            element: Heading specification.
        """
        self.doc.add_heading(text=element.text, level=element.level)

    def _add_paragraph_element(self, element: DocxParagraph) -> None:
        """Add a paragraph element to the document.

        Args:
            element: Paragraph specification.
        """
        style = element.style
        p = self.doc.add_paragraph(style=style)
        run = p.add_run(element.text)

        if element.bold:
            run.bold = True
        if element.italic:
            run.italic = True
        if element.font_size:
            run.font.size = Pt(element.font_size)
        if element.font_color:
            run.font.color.rgb = _hex_to_rgb(element.font_color)
        if element.alignment:
            p.alignment = H_ALIGN.get(element.alignment, H_ALIGN["left"])

    def _add_table_element(self, element: DocxTable) -> None:
        """Add a table element to the document.

        Args:
            element: Table specification.
        """
        headers = element.headers
        rows = element.rows
        style = element.style or "Table Grid"

        if not headers and not rows:
            return

        num_cols = len(headers) if headers else (len(rows[0]) if rows else 0)
        num_rows = (1 if headers else 0) + len(rows)

        table = self.doc.add_table(rows=num_rows, cols=num_cols, style=style)

        if headers:
            for col_idx, header in enumerate(headers):
                cell = table.rows[0].cells[col_idx]
                cell.text = header
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        run.bold = True
        start_row = 1 if headers else 0

        for row_idx, row in enumerate(rows):
            for col_idx, value in enumerate(row):
                table.rows[start_row + row_idx].cells[col_idx].text = str(value)

        col_widths = element.col_widths
        if col_widths:
            for col_idx, width in enumerate(col_widths):
                if col_idx < num_cols:
                    for row in table.rows:
                        row.cells[col_idx].width = Inches(width)

    def _add_image_element(self, element: DocxImage) -> None:
        """Add an image element to the document.

        Args:
            element: Image specification.
        """
        path = element.path
        width = element.width
        height = element.height
        caption = element.caption

        try:
            kwargs: dict[str, Inches] = {}
            if width:
                kwargs["width"] = Inches(width)
            if height:
                kwargs["height"] = Inches(height)
            self.doc.add_picture(path, **kwargs)
        except FileNotFoundError:
            self.doc.add_paragraph(f"[Image not found: {path}]")

        if caption:
            p = self.doc.add_paragraph()
            run = p.add_run(caption)

            run.font.size = Pt(9)
            run.font.italic = True

            p.alignment = H_ALIGN["center"]

    def _save(self) -> Path:
        """Save the generated document to disk.

        Returns:
            Path to the saved DOCX file.
        """
        output_dir = config.ensure_output_dir()
        safe_title = "".join(c if c.isalnum() or c in "-_" else "" for c in self.spec.title).strip()
        filename = f"{safe_title}_{uuid.uuid4().hex[:8]}.docx"
        filepath = output_dir / filename
        self.doc.save(str(filepath))
        return filepath
