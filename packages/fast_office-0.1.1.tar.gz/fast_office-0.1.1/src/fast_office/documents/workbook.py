"""XLSX document generation utilities."""

from __future__ import annotations

import contextlib
import urllib.request
from io import BytesIO
from pathlib import Path
from typing import Any, cast

from openpyxl import Workbook
from openpyxl.cell import Cell
from openpyxl.chart import Reference
from openpyxl.comments import Comment
from openpyxl.drawing.image import Image as XlImage
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule, DataBarRule, FormulaRule
from openpyxl.styles import Alignment, Border, Font, GradientFill, PatternFill, Protection, Side
from openpyxl.utils.cell import range_boundaries
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation as OpDataValidation
from openpyxl.worksheet.worksheet import Worksheet

from fast_office.types.workbook import (
    CHARTS,
    BorderSide,
    CellAlignment,
    CellBorder,
    CellFill,
    CellFont,
    CellFormat,
    CellValue,
    ColDimension,
    ConditionalRule,
    DataValidation,
    DvOperator,
    NamedRange,
    PageSetup,
    PatternFillType,
    RangeFormat,
    RowDimension,
    SheetChart,
    SheetImage,
    SheetProtection,
    WorkbookSpec,
    WorksheetSpec,
)
from fast_office.utils.file_io import create_file_path


def _to_argb(hex_color: str) -> str:
    """Normalize a 6- or 8-digit hex color to 8-digit ARGB (FF prefix)."""
    h = hex_color.lstrip("#")
    if len(h) == 6:
        return "FF" + h.upper()
    if len(h) == 8:
        return h.upper()
    raise ValueError(f"Invalid hex color: {hex_color!r}")


def _build_font(spec: CellFont) -> Font:
    kwargs: dict[str, Any] = {}
    if spec.name is not None:
        kwargs["name"] = spec.name
    if spec.size is not None:
        kwargs["size"] = spec.size
    if spec.bold:
        kwargs["bold"] = True
    if spec.italic:
        kwargs["italic"] = True
    if spec.strikethrough:
        kwargs["strike"] = True
    if spec.underline:
        kwargs["underline"] = spec.underline.value
    if spec.color:
        kwargs["color"] = _to_argb(spec.color)
    return Font(**kwargs)


def _build_fill(spec: CellFill) -> PatternFill | GradientFill:
    if spec.fill_type == "gradient":
        return GradientFill(
            type="linear",
            stop=[_to_argb(spec.fg_color or "FFFFFF"), _to_argb(spec.bg_color or "000000")],
        )
    fg = _to_argb(spec.fg_color) if spec.fg_color else "00000000"
    bg = _to_argb(spec.bg_color) if spec.bg_color else "00000000"
    return PatternFill(fill_type=cast(PatternFillType, spec.fill_type), fgColor=fg, bgColor=bg)


def _build_alignment(spec: CellAlignment) -> Alignment:
    kwargs: dict[str, Any] = {}
    if spec.horizontal:
        kwargs["horizontal"] = spec.horizontal
    if spec.vertical:
        kwargs["vertical"] = spec.vertical
    if spec.wrap_text:
        kwargs["wrap_text"] = True
    if spec.shrink_to_fit:
        kwargs["shrink_to_fit"] = True
    if spec.indent is not None:
        kwargs["indent"] = spec.indent
    if spec.text_rotation is not None:
        kwargs["text_rotation"] = spec.text_rotation
    return Alignment(**kwargs)


def _build_side(spec: BorderSide) -> Side:
    kwargs: dict[str, Any] = {"style": spec.style.value}
    if spec.color:
        kwargs["color"] = _to_argb(spec.color)
    return Side(**kwargs)


def _build_border(spec: CellBorder) -> Border:
    kwargs: dict[str, Any] = {}
    if spec.left:
        kwargs["left"] = _build_side(spec.left)
    if spec.right:
        kwargs["right"] = _build_side(spec.right)
    if spec.top:
        kwargs["top"] = _build_side(spec.top)
    if spec.bottom:
        kwargs["bottom"] = _build_side(spec.bottom)
    if spec.diagonal:
        kwargs["diagonal"] = _build_side(spec.diagonal)
    if spec.diagonal_up:
        kwargs["diagonalUp"] = True
    if spec.diagonal_down:
        kwargs["diagonalDown"] = True
    return Border(**kwargs)


def _apply_format(cell: Cell, fmt: CellFormat) -> None:
    if fmt.font:
        cell.font = _build_font(fmt.font)
    if fmt.fill:
        cell.fill = _build_fill(fmt.fill)
    if fmt.alignment:
        cell.alignment = _build_alignment(fmt.alignment)
    if fmt.border:
        cell.border = _build_border(fmt.border)
    if fmt.number_format:
        cell.number_format = fmt.number_format
    if fmt.protection:
        cell.protection = Protection(
            locked=fmt.protection.locked,
            hidden=fmt.protection.hidden,
        )


def _load_image_bytes(source: str) -> bytes:
    if source.startswith("http://") or source.startswith("https://"):
        with urllib.request.urlopen(source, timeout=15) as resp:
            return bytes(resp.read())
    return Path(source).read_bytes()


class WorkbookGenerator:
    """Generate XLSX files from an XlsxSpec."""

    def __init__(self, spec: WorkbookSpec) -> None:
        """Initialize the XLSX generator with a workbook specification."""
        self.spec = spec
        self.workbook = Workbook()
        if self.workbook.active:
            self.workbook.remove(self.workbook.active)

    def generate(self) -> Path:
        """Build and save the XLSX workbook to disk."""
        self._set_properties()

        for sheet_spec in self.spec.sheets:
            self._add_sheet(spec=sheet_spec)

        if self.spec.named_ranges:
            self._add_named_ranges(named_ranges=self.spec.named_ranges)
        return self._save()

    def _set_properties(self) -> None:
        props = self.workbook.properties
        props.title = self.spec.title

        if self.spec.author:
            props.creator = self.spec.author

        for k, v in self.spec.metadata.items():
            with contextlib.suppress(Exception):
                setattr(props, k, str(v))

    def _add_named_ranges(self, named_ranges: list[NamedRange]) -> None:
        for nr in named_ranges:
            defn = DefinedName(name=nr.name, attr_text=f"'{nr.sheet}'!{nr.range}")
            self.workbook.defined_names[nr.name] = defn

    def _write_headers(self, worksheet: Worksheet, spec: WorksheetSpec) -> None:
        headers = spec.headers or []
        for col_idx, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col_idx, value=header)
            if spec.header_format:
                _apply_format(cell, spec.header_format)

        if spec.data:
            for row_idx, row_data in enumerate(spec.data, start=2):
                for col_idx, val in enumerate(row_data, start=1):
                    worksheet.cell(row=row_idx, column=col_idx, value=val)

    def _write_cells(self, worksheet: Worksheet, cells: list[CellValue]) -> None:
        for cv in cells:
            cell: Cell = worksheet[cv.cell]
            if cv.formula is not None:
                cell.value = cv.formula
            elif cv.value is not None:
                cell.value = cv.value
            if cv.format:
                _apply_format(cell, cv.format)
            if cv.comment:
                cell.comment = Comment(cv.comment, author="")
            if cv.hyperlink:
                cell.hyperlink = cv.hyperlink

    def _add_sheet(self, spec: WorksheetSpec) -> None:
        worksheet: Worksheet = self.workbook.create_sheet(title=spec.name)

        if spec.tab_color:
            worksheet.sheet_properties.tabColor = _to_argb(spec.tab_color)

        if spec.zoom:
            worksheet.sheet_view.zoomScale = spec.zoom

        if spec.headers:
            self._write_headers(worksheet=worksheet, spec=spec)

        if spec.cells:
            self._write_cells(worksheet=worksheet, cells=spec.cells)
        if spec.range_formats:
            ...

        if spec.merges:
            for merge in spec.merges:
                worksheet.merge_cells(merge.range)

        if spec.row_dimensions:
            self._apply_row_dimensions(worksheet=worksheet, dims=spec.row_dimensions)
        if spec.col_dimensions:
            self._apply_col_dimensions(worksheet=worksheet, dims=spec.col_dimensions)
        if spec.freeze_panes:
            worksheet.freeze_panes = spec.freeze_panes
        if spec.auto_filter:
            worksheet.auto_filter.ref = spec.auto_filter
        if spec.data_validations:
            ...
        if spec.conditional_formats:
            for rule in spec.conditional_formats:
                self._add_conditional_format(worksheet=worksheet, rule=rule)
        if spec.charts:
            for chart_spec in spec.charts:
                self._add_chart(worksheet=worksheet, spec=chart_spec)

        if spec.images:
            for image_spec in spec.images:
                self._add_image(worksheet=worksheet, spec=image_spec)
        if spec.page_setup:
            self._apply_page_setup(worksheet=worksheet, spec=spec.page_setup)

        if spec.protection:
            self._apply_protection(worksheet=worksheet, spec=spec.protection)

    def _apply_cells(self, worksheet: Worksheet, cells: list[CellValue]) -> None:
        for cell_spec in cells:
            cell: Cell = worksheet[cell_spec.cell]
            if cell_spec.formula:
                cell.value = cell_spec.formula
            elif cell_spec.value:
                cell.value = cell_spec.value
            if cell_spec.format:
                _apply_format(cell=cell, fmt=cell_spec.format)

    def _apply_range_formats(self, worksheet: Worksheet, range_formats: list[RangeFormat]) -> None:
        for rf in range_formats:
            min_col, min_row, max_col, max_row = range_boundaries(rf.range)
            for row in worksheet.iter_rows(
                min_row=min_row,
                max_row=max_row,
                min_col=min_col,
                max_col=max_col,
            ):
                for cell in row:
                    _apply_format(cell=cast(Cell, cell), fmt=rf.format)

    def _apply_row_dimensions(self, worksheet: Worksheet, dims: list[RowDimension]) -> None:
        for rd in dims:
            row_dim = worksheet.row_dimensions[rd.row]
            if rd.height is not None:
                row_dim.height = rd.height
            row_dim.hidden = rd.hidden

    def _apply_col_dimensions(self, worksheet: Worksheet, dims: list[ColDimension]) -> None:
        for cd in dims:
            col_dim = worksheet.column_dimensions[cd.col.upper()]
            if cd.width is not None:
                col_dim.width = cd.width
            col_dim.hidden = cd.hidden

    def _add_data_validations(
        self, worksheet: Worksheet, validations: list[DataValidation]
    ) -> None:
        for dv in validations:
            op_dv = OpDataValidation(
                type=dv.type,
                operator=cast(DvOperator, dv.operator),
                formula1=dv.formula1,
                formula2=dv.formula2,
                allow_blank=dv.allow_blank,
                showDropDown=not dv.show_dropdown,  # openpyxl inverts this
                sqref=dv.range,
            )
            if dv.error_title:
                op_dv.error = dv.error_message
                op_dv.errorTitle = dv.error_title
                op_dv.showErrorMessage = True
            if dv.prompt_title:
                op_dv.prompt = dv.prompt_message
                op_dv.promptTitle = dv.prompt_title
                op_dv.showInputMessage = True
            worksheet.add_data_validation(op_dv)

    def _add_conditional_format(self, worksheet: Worksheet, rule: ConditionalRule) -> None:
        rng = rule.range_string

        if rule.rule_type == "cell_is" and rule.operator and rule.format:
            font = _build_font(rule.format.font) if rule.format.font else None
            fill = _build_fill(rule.format.fill) if rule.format.fill else None
            cf_rule = CellIsRule(  # type: ignore[no-untyped-call]
                operator=rule.operator,
                formula=[str(v) for v in rule.values],
                font=font,
                fill=fill,
            )
            worksheet.conditional_formatting.add(rng, cf_rule)

        elif rule.rule_type == "color_scale":
            colors = rule.colors or ["FF0000", "FFFF00", "00FF00"]
            vals = rule.values if rule.values else [0, 50, 100]
            if len(colors) == 2:
                cs_rule = ColorScaleRule(  # type: ignore[no-untyped-call]
                    start_type="percentile",
                    start_value=vals[0] if vals else 0,
                    start_color=_to_argb(colors[0]),
                    end_type="percentile",
                    end_value=vals[-1] if vals else 100,
                    end_color=_to_argb(colors[-1]),
                )
            else:
                cs_rule = ColorScaleRule(  # type: ignore[no-untyped-call]
                    start_type="percentile",
                    start_value=vals[0] if len(vals) > 0 else 0,
                    start_color=_to_argb(colors[0]),
                    mid_type="percentile",
                    mid_value=vals[1] if len(vals) > 1 else 50,
                    mid_color=_to_argb(colors[1] if len(colors) > 1 else "FFFF00"),
                    end_type="percentile",
                    end_value=vals[2] if len(vals) > 2 else 100,
                    end_color=_to_argb(colors[-1]),
                )
            worksheet.conditional_formatting.add(rng, cs_rule)

        elif rule.rule_type == "data_bar":
            color = _to_argb(rule.colors[0]) if rule.colors else "638EC6"
            db_rule = DataBarRule(start_type="min", end_type="max", color=color)  # type: ignore[no-untyped-call]
            worksheet.conditional_formatting.add(rng, db_rule)

        elif rule.rule_type == "formula" and rule.values and rule.format:
            font = _build_font(rule.format.font) if rule.format.font else None
            fill = _build_fill(rule.format.fill) if rule.format.fill else None
            f_rule = FormulaRule(formula=[str(rule.values[0])], font=font, fill=fill)  # type: ignore[no-untyped-call]
            worksheet.conditional_formatting.add(rng, f_rule)

    def _add_chart(self, worksheet: Worksheet, spec: SheetChart) -> None:
        chart_cls = CHARTS.get(spec.chart_type.value, CHARTS["bar"])
        chart = chart_cls()
        chart.title = spec.title
        chart.width = spec.width
        chart.height = spec.height

        if spec.grouping and hasattr(chart, "grouping"):
            chart.grouping = spec.grouping  # type: ignore[unused-ignore]

        min_col, min_row, max_col, max_row = self._parse_range(spec.data_range)
        data = Reference(
            worksheet=worksheet,
            min_col=min_col,
            min_row=min_row,
            max_col=max_col,
            max_row=max_row,
        )
        chart.add_data(data=data, titles_from_data=True)

        if spec.categories_range:
            cat_min_col, cat_min_row, cat_max_col, cat_max_row = self._parse_range(
                spec.categories_range
            )
            labels = Reference(
                worksheet=worksheet,
                min_col=cat_min_col,
                min_row=cat_min_row,
                max_col=cat_max_col,
                max_row=cat_max_row,
            )
            chart.set_categories(labels)

        worksheet.add_chart(chart, spec.position)

    def _parse_range(self, range_string: str) -> tuple[int, int, int, int]:
        min_col, min_row, max_col, max_row = range_boundaries(range_string=range_string)
        return min_col or 0, min_row or 0, max_col or 0, max_row or 0

    def _add_image(self, worksheet: Worksheet, spec: SheetImage) -> None:
        img_bytes = _load_image_bytes(spec.source)
        img = XlImage(BytesIO(img_bytes))
        if spec.width:
            img.width = spec.width
        if spec.height:
            img.height = spec.height
        worksheet.add_image(img, spec.anchor)

    def _apply_page_setup(self, worksheet: Worksheet, spec: PageSetup) -> None:
        if spec.orientation:
            worksheet.page_setup.orientation = spec.orientation.value
        if spec.paper_size:
            worksheet.page_setup.paperSize = int(spec.paper_size.value)
        if spec.fit_to_page:
            worksheet.page_setup.fitToPage = True
            if spec.fit_to_width is not None:
                worksheet.page_setup.fitToWidth = spec.fit_to_width
            if spec.fit_to_height is not None:
                worksheet.page_setup.fitToHeight = spec.fit_to_height
        if spec.scale:
            worksheet.page_setup.scale = spec.scale
        if spec.print_area:
            worksheet.print_area = spec.print_area
        if spec.repeat_rows:
            worksheet.print_title_rows = spec.repeat_rows
        if spec.repeat_cols:
            worksheet.print_title_cols = spec.repeat_cols

    def _apply_protection(self, worksheet: Worksheet, spec: SheetProtection) -> None:
        if not spec.enabled:
            return

        prot = worksheet.protection
        prot.sheet = True

        if spec.password:
            prot.set_password(spec.password)

        prot.selectLockedCells = not spec.allow_select_locked
        prot.selectUnlockedCells = not spec.allow_select_unlocked
        prot.formatCells = not spec.allow_format_cells
        prot.formatColumns = not spec.allow_format_columns
        prot.formatRows = not spec.allow_format_rows
        prot.insertRows = not spec.allow_insert_rows
        prot.insertColumns = not spec.allow_insert_columns
        prot.deleteRows = not spec.allow_delete_rows
        prot.deleteColumns = not spec.allow_delete_columns
        prot.sort = not spec.allow_sort
        prot.autoFilter = not spec.allow_autofilter

    def _save(self) -> Path:
        filepath = create_file_path(filename=self.spec.title, extension=".xlsx")
        self.workbook.save(str(filepath))
        return filepath
