"""Powerpoint presentation generator."""

import html
from pathlib import Path
from typing import cast

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.chart.data import ChartData as PptxChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.shapes.placeholder import SlidePlaceholder
from pptx.slide import Slide
from pptx.util import Inches, Pt

from fast_office.types.pptx import (
    Alignment,
    ChartData,
    Charts,
    LayoutMap,
    Position,
    PptxSlide,
    PptxSpec,
    SlideElement,
    SlideElementType,
    SlideLayout,
)
from fast_office.utils.color_converter import ms_hex_to_rgb
from fast_office.utils.file_io import create_file_path


def _safe_text(value: str) -> str:
    """Unescape any HTML entities that python-pptx would double-escape."""
    return html.unescape(value)


class PptxGenerator:
    """Generate PPTX files from a PptxSpec."""

    def __init__(self, spec: PptxSpec) -> None:
        """Initialize the generator with a PptxSpec."""
        self.spec = spec
        self.presentation = Presentation()

    def generate(self) -> Path:
        """Generate a PPTX file from the spec and return its path."""
        self._set_slide_size()

        for slide_spec in self.spec.slides:
            self._add_slide(slide_spec=slide_spec)

        return self._save()

    def _set_slide_size(self) -> None:
        self.presentation.slide_width = Inches(13.33)
        self.presentation.slide_height = Inches(7.5)

    def _get_layout_index(self, layout: SlideLayout) -> int:
        idx = LayoutMap.get(layout, 1)
        max_idx = len(self.presentation.slide_layouts) - 1
        return min(idx, max_idx)

    def _add_slide(self, slide_spec: PptxSlide) -> None:
        layout_idx = self._get_layout_index(layout=slide_spec.layout)
        slide_layout = self.presentation.slide_layouts[layout_idx]
        slide = self.presentation.slides.add_slide(slide_layout=slide_layout)

        if slide_spec.title:
            self._set_title(slide=slide, title=slide_spec.title, subtitle=slide_spec.subtitle)

        if slide_spec.body:
            self._add_body_text(slide=slide, text=slide_spec.body)
        elif slide_spec.bullet_points:
            self._add_bullets(slide=slide, bullets=slide_spec.bullet_points)

        if slide_spec.elements:
            for placeholder in list(slide.placeholders):
                sp = placeholder._element
                sp.getparent().remove(sp)
            for element in slide_spec.elements:
                self._add_element(slide=slide, element=element)
        if slide_spec.speaker_notes and slide.notes_slide.notes_text_frame:
            slide.notes_slide.notes_text_frame.text = _safe_text(slide_spec.speaker_notes)

    def _set_title(self, slide: Slide, title: str, subtitle: str | None) -> None:
        if slide.shapes.title:
            text_frame = slide.shapes.title.text_frame
            text_frame.text = _safe_text(title)

            for paragraph in text_frame.paragraphs:
                for run in paragraph.runs:
                    run.font.size = Pt(self.spec.theme.font_size_title)
                    run.font.color.rgb = ms_hex_to_rgb(self.spec.theme.primary_color)
                    run.font.name = self.spec.theme.font_heading

        if subtitle and len(slide.placeholders) > 1:
            placeholder = cast(SlidePlaceholder, slide.placeholders[1])
            placeholder.text = _safe_text(subtitle)

    def _add_body_text(self, slide: Slide, text: str) -> None:
        for placeholder in slide.placeholders:
            placeholder = cast(SlidePlaceholder, placeholder)
            if placeholder.placeholder_format.idx == 1:
                text_frame = placeholder.text_frame
                text_frame.text = _safe_text(text)

                for paragraph in text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size = Pt(self.spec.theme.font_size_body)
                        run.font.name = self.spec.theme.font_body
                return None
        textbox = slide.shapes.add_textbox(
            left=Inches(1), top=Inches(2), width=Inches(11), height=Inches(4.5)
        )
        text_frame = textbox.text_frame
        text_frame.word_wrap = True
        paragraph = text_frame.paragraphs[0]
        paragraph.text = _safe_text(text)
        paragraph.font.size = Pt(self.spec.theme.font_size_body)
        paragraph.font.name = self.spec.theme.font_body

    def _add_bullets(self, slide: Slide, bullets: list[str]) -> None:
        for placeholder in slide.placeholders:
            placeholder = cast(SlidePlaceholder, placeholder)
            if placeholder.placeholder_format.idx == 1:
                text_frame = placeholder.text_frame
                text_frame.clear()
                for i, bullet in enumerate(bullets):
                    paragraph = text_frame.paragraphs[0] if i == 0 else text_frame.add_paragraph()

                    paragraph.text = _safe_text(bullet)
                    paragraph.level = 0
                    paragraph.font.size = Pt(self.spec.theme.font_size_body)
                    paragraph.font.name = self.spec.theme.font_body
                return
        text_box = slide.shapes.add_textbox(
            left=Inches(1), top=Inches(2), width=Inches(11), height=Inches(4.5)
        )
        text_frame = text_box.text_frame
        text_frame.word_wrap = True

        for i, bullet in enumerate(bullets):
            for i, bullet in enumerate(bullets):
                paragraph = text_frame.paragraphs[0] if i == 0 else text_frame.add_paragraph()

                paragraph.text = _safe_text(f"• {bullet}")
                paragraph.font.size = Pt(self.spec.theme.font_size_body)

    def _add_element(self, slide: Slide, element: SlideElement) -> None:
        position = element.position or Position(left=1.0, top=2.0, width=5.0, height=3.0)

        if element.element_type == SlideElementType.TEXTBOX and element.content:
            self._add_textbox_element(slide=slide, element=element, position=position)

        elif element.element_type == SlideElementType.TABLE and element.table_data:
            self._add_table_element(slide=slide, data=element.table_data, position=position)

        elif element.element_type == SlideElementType.CHART and element.chart_data:
            self._add_chart_element(slide=slide, chart_data=element.chart_data, position=position)

        elif element.element_type == SlideElementType.SHAPE:
            self._add_shape_element(slide=slide, element=element, position=position)

    def _add_textbox_element(self, slide: Slide, element: SlideElement, position: Position) -> None:
        text_box = slide.shapes.add_textbox(
            left=Inches(position.left),
            top=Inches(position.top),
            width=Inches(position.width),
            height=Inches(position.height),
        )

        text_frame = text_box.text_frame
        text_frame.word_wrap = True
        text_frame.auto_size = None

        paragraph = text_frame.paragraphs[0]
        paragraph.text = _safe_text(element.content or "")

        style = element.style.model_dump() if element.style else {}

        if style.get("font_size"):
            paragraph.font.size = Pt(style["font_size"])
        if style.get("bold"):
            paragraph.font.bold = True
        if style.get("italic"):
            paragraph.font.italic = True
        if style.get("font_color"):
            paragraph.font.color.rgb = ms_hex_to_rgb(style["font_color"])
        if style.get("alignment"):
            paragraph.alignment = Alignment.get(style["alignment"], PP_ALIGN.LEFT)
        if style.get("vertical_anchor"):
            text_frame.paragraphs[0].alignment = Alignment.get(
                style.get("alignment", "left"), PP_ALIGN.LEFT
            )

    def _add_table_element(self, slide: Slide, data: list[list[str]], position: Position) -> None:
        if not data:
            return None

        rows, cols = len(data), len(data[0])

        table = slide.shapes.add_table(
            rows=rows,
            cols=cols,
            left=Inches(position.left),
            top=Inches(position.top),
            width=Inches(position.width),
            height=Inches(position.height),
        ).table

        for row_idx, row in enumerate(data):
            for col_idx, cell_val in enumerate(row):
                cell = table.cell(row_idx=row_idx, col_idx=col_idx)
                cell.text = _safe_text(str(cell_val))
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE

                if row_idx == 0:
                    for paragraph in cell.text_frame.paragraphs:
                        for run in paragraph.runs:
                            run.font.bold = True
                            run.font.color.rgb = RGBColor(r=0xFF, g=0xFF, b=0xFF)  # type: ignore[no-untyped-call]
                        cell.fill.solid()  # type: ignore[no-untyped-call]
                        cell.fill.fore_color.rgb = ms_hex_to_rgb(self.spec.theme.primary_color)

    def _add_chart_element(self, slide: Slide, chart_data: ChartData, position: Position) -> None:
        chart_type = Charts.get(chart_data.chart_type, XL_CHART_TYPE.BAR_CLUSTERED)
        category_chart_data = CategoryChartData()  # type: ignore[no-untyped-call]
        category_chart_data.categories = chart_data.categories

        for series in chart_data.series:
            category_chart_data.add_series(series.get("name", "Series"), series.get("values", []))  # type: ignore[no-untyped-call]

        chart_frame = slide.shapes.add_chart(
            chart_type=chart_type,
            x=Inches(position.left),
            y=Inches(position.top),
            cx=Inches(position.width),
            cy=Inches(position.height),
            chart_data=cast(PptxChartData, category_chart_data),
        )

        chart = chart_frame.chart_style
        if chart_data.title:
            if chart:
                chart.has_title = True
            if chart:
                chart.chart_title.text_frame = chart_data.title

    def _add_shape_element(self, slide: Slide, element: SlideElement, position: Position) -> None:
        shape = slide.shapes.add_shape(
            autoshape_type_id=MSO_SHAPE.ROUNDED_RECTANGLE,
            left=Inches(position.left),
            top=Inches(position.top),
            width=Inches(position.width),
            height=Inches(position.height),
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = ms_hex_to_rgb(self.spec.theme.accent_color)
        if element.content:
            text_frame = shape.text_frame
            text_frame.text = _safe_text(element.content)
            text_frame.word_wrap = True

    def _save(self) -> Path:
        filepath = create_file_path(self.spec.title, ".pptx")
        self.presentation.save(str(filepath))
        return filepath
