"""Fast Office document generation library."""

from fast_office.documents.docx import DocxGenerator

__all__ = ["DocxGenerator"]
