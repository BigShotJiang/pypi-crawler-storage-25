"""PPT files type definitions."""

from enum import StrEnum
from typing import Any

from pptx.enum.chart import XL_CHART_TYPE
from pptx.enum.text import PP_ALIGN
from pydantic import BaseModel, ConfigDict, Field


class SlideLayout(StrEnum):
    """Supported PowerPoint slide layout types."""

    TITLE = "title"
    TITLE_AND_CONTENT = "title_and_content"
    SECTION_HEADER = "section_header"
    TWO_COLUMN = "two_column"
    TITLE_ONLY = "title_only"
    BLANK = "blank"
    CHART = "chart"
    TABLE = "table"
    COMPARISON = "comparison"
    PICTURE = "picture"


LayoutMap: dict[SlideLayout, int] = {
    SlideLayout.TITLE: 0,
    SlideLayout.TITLE_AND_CONTENT: 1,
    SlideLayout.SECTION_HEADER: 2,
    SlideLayout.TWO_COLUMN: 3,
    SlideLayout.TITLE_ONLY: 4,
    SlideLayout.BLANK: 5,
    SlideLayout.CHART: 1,
    SlideLayout.TABLE: 1,
    SlideLayout.COMPARISON: 3,
    SlideLayout.PICTURE: 1,
}


class SlideTheme(BaseModel):
    """Visual theme for the presentation."""

    primary_color: str = Field(default="#1F4E79", description="Primary brand color (hex)")
    secondary_color: str = Field(default="#2E75B6", description="Secondary brand color (hex)")
    accent_color: str = Field(default="#ED7D31", description="Accent color (hex)")
    background_color: str = Field(default="#FFFFFF", description="Slide background color (hex)")
    font_heading: str = Field(default="Calibri", description="Heading font family")
    font_body: str = Field(default="Calibri", description="Body text font family")
    font_size_title: int = Field(default=36, description="Title font size in points")
    font_size_body: int = Field(default=36, description="Body text font size in points")

    model_config = ConfigDict(extra="ignore")


class ChartType(StrEnum):
    """Supported chart types for PowerPoint slides."""

    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    COLUMN = "column"
    AREA = "area"
    SCATTER = "scatter"


class AlignmentType(StrEnum):
    """Supported text alignment types."""

    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    JUSTIFY = "justify"


Charts: dict[ChartType, XL_CHART_TYPE] = {
    ChartType.BAR: XL_CHART_TYPE.BAR_CLUSTERED,
    ChartType.COLUMN: XL_CHART_TYPE.COLUMN_CLUSTERED,
    ChartType.LINE: XL_CHART_TYPE.LINE,
    ChartType.PIE: XL_CHART_TYPE.PIE,
    ChartType.AREA: XL_CHART_TYPE.AREA,
    ChartType.SCATTER: XL_CHART_TYPE.XY_SCATTER,
}

Alignment: dict[AlignmentType, PP_ALIGN] = {
    AlignmentType.LEFT: PP_ALIGN.LEFT,
    AlignmentType.CENTER: PP_ALIGN.CENTER,
    AlignmentType.RIGHT: PP_ALIGN.RIGHT,
    AlignmentType.JUSTIFY: PP_ALIGN.JUSTIFY,
}


class SlideElementType(StrEnum):
    """Types of elements that can appear on a slide."""

    TEXTBOX = "textbox"
    IMAGE = "image"
    SHAPE = "shape"
    TABLE = "table"
    CHART = "chart"


class Position(BaseModel):
    """Position in inches {left, top, width, height}."""

    left: float = Field(..., description="Left position in inches")
    top: float = Field(..., description="Top position in inches")
    width: float = Field(..., description="Width in inches")
    height: float = Field(..., description="Height in inches")


class Style(BaseModel):
    """Style overrides: font_size, font_color, bold, italic, alignment, vertical_anchor."""

    font_size: int = Field(..., description="Font size in points")
    font_color: str = Field(..., description="Font color RGB")
    bold: bool = False
    italic: bool = False
    alignment: AlignmentType | None = None
    vertical_anchor: AlignmentType | None = None

    model_config = ConfigDict(extra="ignore")


class ChartData(BaseModel):
    """Data for embedding a chart in a slide."""

    chart_type: ChartType = Field(
        default=ChartType.BAR, description="Chart type: bar, column, area"
    )
    title: str = ""
    categories: list[str] = Field(default_factory=list)
    series: list[dict[str, Any]] = Field(
        default_factory=list, description="List of {name, values} dicts"
    )

    model_config = ConfigDict(extra="ignore")


class SlideElement(BaseModel):
    """An element within a slide (textbox, image, shape etc)."""

    element_type: SlideElementType = Field(..., description="Type: textbox, image, shape, etc")
    content: str | None = None
    position: Position | None = None
    style: Style | None = None
    chart_data: ChartData | None = None
    table_data: list[list[str]] | None = Field(default=None, description="Row-major table data")

    model_config = ConfigDict(extra="ignore")


class PptxSlide(BaseModel):
    """Specifications for a single slide."""

    layout: SlideLayout = SlideLayout.TITLE_AND_CONTENT
    title: str = ""
    subtitle: str | None = None
    body: str | None = None
    bullet_points: list[str] | None = None
    speaker_notes: str | None = None
    elements: list[SlideElement] | None = None

    model_config = ConfigDict(extra="ignore")


class PptxSpec(BaseModel):
    """Specifications for a powerpoint presentation."""

    title: str = Field(..., description="Presentation title")
    subtitle: str | None = None
    author: str | None = None
    theme: SlideTheme = Field(default_factory=SlideTheme)
    slides: list[PptxSlide] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="ignore")
