"""Excel files type definitions."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from openpyxl.chart import AreaChart, BarChart, LineChart, PieChart, ScatterChart
from openpyxl.chart._chart import ChartBase
from pydantic import BaseModel, ConfigDict, Field

CHARTS: dict[str, type[ChartBase]] = {
    "bar": BarChart,
    "column": BarChart,
    "line": LineChart,
    "pie": PieChart,
    "area": AreaChart,
    "scatter": ScatterChart,
}

# Enums


class BorderStyle(StrEnum):
    """Border style."""

    THIN = "thin"
    MEDIUM = "medium"
    THICK = "thick"
    DASHED = "dashed"
    DOTTED = "dotted"
    DOUBLE = "double"
    HAIR = "hair"
    MEDIUM_DASHED = "mediumDashed"
    DASH_DOT = "dashDot"
    MEDIUM_DASH_DOT = "mediumDashDot"


FillType = Literal["solid", "pattern", "gradient"]

PatternFillType = Literal[
    "solid",
    "darkDown",
    "darkGray",
    "darkGrid",
    "darkHorizontal",
    "darkTrellis",
    "darkUp",
    "darkVertical",
    "gray0625",
    "gray125",
    "lightDown",
    "lightGray",
    "lightGrid",
    "lightHorizontal",
    "lightTrellis",
    "lightUp",
    "lightVertical",
    "mediumGray",
    "none",
]

DvOperator = Literal[
    "between",
    "notBetween",
    "equal",
    "notEqual",
    "lessThan",
    "lessThanOrEqual",
    "greaterThan",
    "greaterThanOrEqual",
    "none",
]


class UnderlineStyle(StrEnum):
    """Underline Style."""

    SINGLE = "single"
    DOUBLE = "double"
    SINGLE_ACCOUNTING = "singleAccounting"
    DOUBLE_ACCOUNTING = "doubleAccounting"


class PageOrientation(StrEnum):
    """Page orientation."""

    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"


class PaperSize(StrEnum):
    """Common paper sizes. Value maps to Excel's paperSize integer."""

    LETTER = "1"
    A4 = "9"
    A3 = "8"
    LEGAL = "5"


class ChartType(StrEnum):
    """Supported chart types for worksheet chart generation."""

    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    AREA = "area"
    SCATTER = "scatter"
    COLUMN = "column"


# Formatting Primitives


class BorderSide(BaseModel):
    """One side of a cell border."""

    style: BorderStyle = BorderStyle.THIN
    color: str | None = Field(
        default=None,
        description="Hex color without #, e.g. '000000' for black, 'FF0000' for red.",
    )
    model_config = ConfigDict(extra="ignore")


class CellBorder(BaseModel):
    """Full border specification for a cell. Omit any side to leave it unstyled."""

    left: BorderSide | None = None
    right: BorderSide | None = None
    top: BorderSide | None = None
    bottom: BorderSide | None = None
    diagonal: BorderSide | None = None
    diagonal_up: bool = False
    diagonal_down: bool = False
    model_config = ConfigDict(extra="ignore")


class CellFont(BaseModel):
    """Font styling for a cell."""

    name: str | None = Field(
        default=None, description="Font name, e.g. 'Arial', 'Calibri', 'Times New Roman'."
    )
    size: float | None = Field(default=None, description="Font size in points, e.g. 11, 12, 14.")
    bold: bool = False
    italic: bool = False
    underline: UnderlineStyle | None = None
    strikethrough: bool = False
    color: str | None = Field(
        default=None,
        description=(
            "Font color as 6-digit hex without #. "
            "Finance conventions: '0000FF'=blue for inputs, '000000'=black for formulas, "
            "'008000'=green for cross-sheet links, 'FF0000'=red for external links."
        ),
    )
    model_config = ConfigDict(extra="ignore")


class CellFill(BaseModel):
    """Background fill for a cell."""

    fill_type: FillType = "solid"
    fg_color: str | None = Field(
        default=None,
        description="Foreground (main) color as 6-digit hex without #, e.g. '1F4E79', 'FFFF00'.",
    )
    bg_color: str | None = Field(
        default=None,
        description="Background color (only meaningful for pattern fills), 6-digit hex without #.",
    )
    model_config = ConfigDict(extra="ignore")


class CellAlignment(BaseModel):
    """Text alignment and wrapping within a cell."""

    horizontal: (
        Literal["left", "center", "right", "fill", "justify", "centerContinuous", "distributed"]
        | None
    ) = None
    vertical: Literal["top", "center", "bottom", "justify", "distributed"] | None = None
    wrap_text: bool = False
    shrink_to_fit: bool = False
    indent: int | None = Field(default=None, description="Indent level (0–255).")
    text_rotation: int | None = Field(
        default=None, description="Degrees of text rotation (0–180 or 255 for vertical)."
    )
    model_config = ConfigDict(extra="ignore")


class CellProtection(BaseModel):
    """Cell-level lock/hide. Effective only when the sheet is protected."""

    locked: bool = True
    hidden: bool = False
    model_config = ConfigDict(extra="ignore")


class CellFormat(BaseModel):
    """Formatting for a cell / range of cells."""

    font: CellFont | None = None
    fill: CellFill | None = None
    alignment: CellAlignment | None = None
    border: CellBorder | None = None
    number_format: str | None = Field(
        default=None,
        description=(
            "Excel number format string. Examples: "
            "'#,##0' (integer with thousands), "
            "'#,##0.00' (2 dp), "
            "'0.0%' (percentage 1 dp), "
            "'$#,##0.00' (USD), "
            "'[$KES]\\ #,##0.00' (Kenyan shilling), "
            "'#,##0_);(#,##0)' (accounting with parens for negatives), "
            "'_(* #,##0_);_(* \\(#,##0\\);_(* \\-??_);_(@_)' (full accounting), "
            "'YYYY-MM-DD' (date), 'HH:MM:SS' (time), "
            "'0.0x' (multiple), '0' (plain integer)."
        ),
    )
    protection: CellProtection | None = None

    model_config = ConfigDict(extra="ignore")


# Cell value


class CellValue(BaseModel):
    """A single cell value with optimal formatting and formula."""

    cell: str = Field(..., description="Cell reference like: A1, B2, etc")
    value: str | float | int | bool | None = Field(default=None, description="Static cell value.")
    formula: str | None = Field(
        default=None,
        description=(
            "Excel formula string including leading '='. "
            "Cross-sheet: '=Sheet2!B5*1.1'. "
            "Absolute refs: '=$B$6'. "
            "Named ranges: '=Revenue_2024*GrowthRate'. "
            "IF: '=IF(B5>0,B5*C5,0)'. "
            "IFERROR: '=IFERROR(B5/C5,0)'. "
            "Array: '=SUM(IF(A1:A10>0,A1:A10,0))'."
        ),
    )
    format: CellFormat | None = None
    comment: str | None = Field(
        default=None,
        description="Cell comment / annotation text. Shown as a hover tooltip in Excel.",
    )
    hyperlink: str | None = Field(
        default=None,
        description="URL or internal anchor (e.g. '#Sheet2!A1') to attach to the cell.",
    )

    model_config = ConfigDict(extra="ignore")


# Merge


class MergeRange(BaseModel):
    """Merge a rectangular block of cells into one. The top-left cell holds the value."""

    range: str = Field(
        ...,
        description="Cell range to merge, e.g. 'A1:D1', 'B5:B10', 'C3:F8'.",
    )
    model_config = ConfigDict(extra="ignore")


# Validation


class DataValidation(BaseModel):
    """In-cell dropdown list or numeric / date / text constraint.

    Example — dropdown list:
        type='list', range='B2:B100', formula1='"Option A,Option B,Option C"'

    Example — whole number between 1 and 100:
        type='whole', range='C2:C50', operator='between', formula1='1', formula2='100'
    """

    range: str = Field(..., description="Cell range to apply the validation to, e.g. 'B2:B100'.")
    type: Literal["list", "whole", "decimal", "date", "time", "textLength", "custom"] = Field(
        ..., description="Validation type."
    )
    operator: str | None = Field(
        default=None,
        description="Comparison operator: 'between', 'notBetween', 'equal', 'notEqual', 'greaterThan', 'lessThan', 'greaterThanOrEqual', 'lessThanOrEqual'.",
    )
    formula1: str | None = Field(
        default=None,
        description=(
            "First formula or value. For list type: '\"A,B,C\"' or a range like 'Lists!$A$1:$A$10'. "
            "For numeric types: the lower bound or single value."
        ),
    )
    formula2: str | None = Field(
        default=None,
        description="Second formula/value (upper bound for 'between'/'notBetween').",
    )
    allow_blank: bool = True
    show_dropdown: bool = True
    error_title: str | None = None
    error_message: str | None = None
    prompt_title: str | None = None
    prompt_message: str | None = None
    model_config = ConfigDict(extra="ignore")


# Conditional formating


class ConditionalRule(BaseModel):
    """A conditional formatting rule applied to a cell range.

    rule_type options:
    - 'cell_is'   : Compare cell value; requires operator + values.
    - 'color_scale': Two- or three-color gradient; set values as [min_pct, mid_pct, max_pct].
    - 'data_bar'  : In-cell bar chart; no extra params needed.
    - 'icon_set'  : Icon set (not yet rendered by generator but spec is captured).
    - 'formula'   : Custom formula; set formula in values[0].

    Example (highlight cells > 1000 in green):
        rule_type='cell_is', operator='greaterThan', values=[1000],
        format=CellFormat(font=CellFont(color='008000'), fill=CellFill(fg_color='C6EFCE'))
    """

    range_string: str = Field(..., description="Cell range like: A1:A100, etc")
    rule_type: Literal["cell_is", "color_scale", "data_bar", "icon_set", "formula"] = Field(...)
    operator: str | None = Field(
        default=None, description="Operator for cell_is: greaterThan, lessThan, between, equal, etc"
    )
    values: list[str | float] = Field(
        default_factory=list,
        description="Threshold values. For cell_is: [threshold]. For color_scale: [min_pct, mid_pct, max_pct]. For formula: ['=formula_string'].",
    )
    colors: list[str] | None = Field(
        default=None,
        description="For color_scale: list of 2 or 3 hex colors (start, [mid], end), e.g. ['FF0000','FFFF00','00FF00'].",
    )
    format: CellFormat | None = Field(
        default=None,
        description="Formatting to apply when the rule matches (used with cell_is and formula rules).",
    )

    model_config = ConfigDict(extra="ignore")


# Named range


class NamedRange(BaseModel):
    """A workbook-level named range for use in formulas.

    Example:
        name='Revenue_2024', sheet='Forecast', range='$C$11:$N$11'

    Then in a formula: '=SUM(Revenue_2024)' or '=Revenue_2024*GrowthRate'
    """

    name: str = Field(
        ...,
        description="Name (no spaces, no special chars except underscore). E.g. 'Revenue_2024'.",
    )
    sheet: str = Field(..., description="Sheet name that contains the range.")
    range: str = Field(..., description="Cell range with $ signs, e.g. '$C$11:$N$11' or '$B$6'.")
    model_config = ConfigDict(extra="ignore")


# Chart


class SheetChart(BaseModel):
    """A chart embedded in a worksheet.

    data_range must include the data AND a header row (titles_from_data=True is used).
    categories_range is the column/row that labels the X axis.

    Example — bar chart of monthly sales:
        chart_type='bar', title='Monthly Revenue',
        data_range='A1:B13', categories_range='A2:A13',
        position='D2', width=15, height=10
    """

    chart_type: ChartType = ChartType.BAR
    title: str = ""
    data_range: str = Field(..., description="Range including header row, e.g. 'A1:D10'.")
    categories_range: str | None = Field(
        default=None,
        description="Range for category labels (X-axis), e.g. 'A2:A10'. Omit for scatter/pie.",
    )
    position: str = Field(
        default="E2", description="Top-left anchor cell for the chart, e.g. 'E2', 'H5'."
    )
    width: int = Field(
        default=15, description="Chart width in openpyxl units (~1 unit ≈ 1 column)."
    )
    height: int = Field(default=10, description="Chart height in openpyxl units.")
    grouping: Literal["clustered", "stacked", "percentStacked", "standard"] | None = Field(
        default=None, description="Bar/column grouping style."
    )
    model_config = ConfigDict(extra="ignore")


# Image


class SheetImage(BaseModel):
    """An image embedded in a worksheet.

    The image source can be:
    - A local file path  (e.g. '/tmp/logo.png')
    - A URL             (e.g. 'https://example.com/logo.png')

    The generator will download URLs automatically.
    """

    source: str = Field(
        ...,
        description=(
            "File path or HTTP/HTTPS URL of the image. "
            "Supported formats: PNG, JPEG, GIF, BMP, TIFF. "
            "Example: '/tmp/logo.png' or 'https://cdn.example.com/logo.png'."
        ),
    )
    anchor: str = Field(
        ...,
        description="Top-left cell where the image is anchored, e.g. 'A1', 'B3'.",
    )
    width: int | None = Field(
        default=None,
        description="Display width in pixels. If omitted, the image's natural width is used.",
    )
    height: int | None = Field(
        default=None,
        description="Display height in pixels. If omitted, the image's natural height is used.",
    )
    model_config = ConfigDict(extra="ignore")


class PageSetup(BaseModel):
    """Print and page setup for a worksheet."""

    orientation: PageOrientation | None = None
    paper_size: PaperSize | None = Field(
        default=None,
        description="Paper size. Common values: '1'=Letter, '9'=A4, '8'=A3.",
    )
    fit_to_page: bool = False
    fit_to_width: int | None = Field(
        default=None, description="Scale to fit N pages wide. Set fit_to_page=True."
    )
    fit_to_height: int | None = Field(default=None, description="Scale to fit N pages tall.")
    scale: int | None = Field(default=None, description="Zoom scale as integer percent, e.g. 85.")
    print_area: str | None = Field(default=None, description="Print area range, e.g. 'A1:P50'.")
    repeat_rows: str | None = Field(
        default=None,
        description="Rows to repeat at top of each printed page. Format: '$1:$3' to repeat rows 1–3.",
    )
    repeat_cols: str | None = Field(
        default=None,
        description="Columns to repeat at left of each printed page. Format: '$A:$B' to repeat cols A–B.",
    )
    model_config = ConfigDict(extra="ignore")


# Sheet protection


class SheetProtection(BaseModel):
    """Worksheet protection settings.

    When enabled, only cells explicitly marked CellProtection(locked=False) can be edited.
    All other cells are locked. Set a password to prevent users from removing the protection.
    """

    enabled: bool = True
    password: str | None = Field(default=None, description="Optional protection password.")
    allow_select_locked: bool = True
    allow_select_unlocked: bool = True
    allow_format_cells: bool = False
    allow_format_columns: bool = False
    allow_format_rows: bool = False
    allow_insert_rows: bool = False
    allow_insert_columns: bool = False
    allow_delete_rows: bool = False
    allow_delete_columns: bool = False
    allow_sort: bool = False
    allow_autofilter: bool = False
    model_config = ConfigDict(extra="ignore")


# Row and column dims


class RowDimension(BaseModel):
    """Override height or visibility for a specific row."""

    row: int = Field(..., description="1-based row number.")
    height: float | None = Field(
        default=None, description="Row height in points. Default Excel row is ~15."
    )
    hidden: bool = False
    model_config = ConfigDict(extra="ignore")


class ColDimension(BaseModel):
    """Override width or visibility for a specific column."""

    col: str = Field(..., description="Column letter, e.g. 'A', 'B', 'AA'.")
    width: float | None = Field(
        default=None, description="Column width in character units. Default is ~8."
    )
    hidden: bool = False
    model_config = ConfigDict(extra="ignore")


class RangeFormat(BaseModel):
    """Apply a CellFormat to every cell in a rectangular range."""

    range: str = Field(..., description="Cell range, e.g. 'A1:Z100', 'B5:F20'.")
    format: CellFormat = Field(..., description="Formatting to apply to all cells in the range.")
    model_config = ConfigDict(extra="ignore")


class WorksheetSpec(BaseModel):
    """Specification for a single worksheet.

    Building blocks — use in any combination:
    - headers + data     : Quick tabular layout (headers auto-formatted if header_format set).
    - cells              : Precise cell-by-cell control for values, formulas, formatting, comments, hyperlinks.
    - range_formats      : Apply one format to a block of cells efficiently.
    - merges             : Merge cell ranges (e.g. title rows spanning multiple columns).
    - row_dimensions     : Set row heights or hide rows.
    - col_dimensions     : Set column widths or hide columns.
    - freeze_panes       : Freeze rows/columns for scrolling (e.g. 'C2' freezes row 1 and cols A–B).
    - auto_filter        : Add Excel dropdown filters to the header row.
    - data_validations   : Dropdown lists or value constraints.
    - conditional_formats: Color scales, data bars, or rule-based highlighting.
    - charts             : Embedded charts (bar, line, pie, area, scatter).
    - images             : Embedded images (logo, signature, chart image, etc.).
    - page_setup         : Print orientation, paper size, print area.
    - protection         : Sheet-level locking.
    - tab_color          : Color the sheet tab (6-digit hex, e.g. '002060' for navy).
    - zoom               : Worksheet zoom level (e.g. 85 for 85%).
    """

    name: str = Field(..., description="Sheet tab name, e.g. 'Cover', 'Assumptions', 'DCF'.")
    tab_color: str | None = Field(
        default=None,
        description="Sheet tab color as 6-digit hex without #, e.g. '002060', 'FF0000', '70AD47'.",
    )
    zoom: int | None = Field(
        default=None, description="Worksheet zoom percentage, e.g. 85, 100, 120."
    )

    headers: list[str] | None = Field(
        default=None,
        description=(
            "Column header labels. When provided along with `data`, the generator writes "
            "headers to row 1 with `header_format` applied, then appends data rows."
        ),
    )
    header_format: CellFormat | None = Field(
        default=None,
        description="Formatting for the header row (when using headers+data). No default applied.",
    )
    data: list[list[str | float | int | bool | None]] | None = Field(
        default=None,
        description="Row-major data (excluding the header row). Each inner list is one row.",
    )

    # --- precise cell control ---
    cells: list[CellValue] | None = Field(
        default=None,
        description=(
            "Individual cell specifications. Use this for formulas, specific cell formats, "
            "comments, hyperlinks, or any cell not covered by the headers+data shorthand."
        ),
    )

    # --- range-level formatting ---
    range_formats: list[RangeFormat] | None = Field(
        default=None,
        description="Apply a CellFormat to a rectangular range of cells at once.",
    )

    # --- structure ---
    merges: list[MergeRange] | None = Field(
        default=None,
        description="List of cell ranges to merge, e.g. [MergeRange(range='A1:F1')].",
    )
    row_dimensions: list[RowDimension] | None = None
    col_dimensions: list[ColDimension] | None = None
    freeze_panes: str | None = Field(
        default=None,
        description=(
            "Cell reference that marks the top-left unfrozen cell. "
            "'A2' freezes only row 1. 'C2' freezes row 1 and columns A–B. "
            "'C11' freezes rows 1–10 and columns A–B."
        ),
    )
    auto_filter: str | None = Field(
        default=None,
        description="Range to add auto-filter dropdowns to, e.g. 'A1:J1' or 'A1:A1'.",
    )

    # --- data quality ---
    data_validations: list[DataValidation] | None = None

    # --- visual ---
    conditional_formats: list[ConditionalRule] | None = None
    charts: list[SheetChart] | None = None
    images: list[SheetImage] | None = None

    # --- print / protect ---
    page_setup: PageSetup | None = None
    protection: SheetProtection | None = None

    model_config = ConfigDict(extra="ignore")


class WorkbookSpec(BaseModel):
    """Full specification for an Excel workbook.

    The generator converts this spec into a .xlsx file using openpyxl.
    All styling, formulas, structure, charts, images, and print settings
    must be declared here — the generator adds nothing beyond what is specified.

    Tips for agents building specs:
    - Use `cells` for formulas and precise formatting; use `headers`+`data` for plain tables.
    - Reference other sheets in formulas as: `=SheetName!CellRef` (quote names with spaces: `='Sheet Name'!A1`).
    - Absolute refs prevent drift when copied: `=$B$6`, `=SUM($C$11:$N$11)`.
    - Named ranges make complex formulas readable: define in `named_ranges`, use in formulas.
    - For locked cells: set SheetProtection on the sheet, then mark input cells with
      CellProtection(locked=False) so users can still edit them.
    """

    title: str = Field(
        ..., description="Workbook title — used as the file name (special chars stripped)."
    )
    author: str | None = Field(
        default=None, description="Author name stored in workbook properties."
    )
    named_ranges: list[NamedRange] | None = Field(
        default=None,
        description="Workbook-level named ranges accessible in any sheet formula.",
    )
    sheets: list[WorksheetSpec] = Field(
        default_factory=list, description="Ordered list of worksheet specs."
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Arbitrary metadata stored in workbook properties (description, keywords, etc.).",
    )
    model_config = ConfigDict(extra="ignore")
