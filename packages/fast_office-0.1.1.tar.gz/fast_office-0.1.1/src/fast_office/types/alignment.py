"""Alignement type definitions."""

from typing import Literal

from docx.enum.text import WD_ALIGN_PARAGRAPH

H_ALIGNMENT = Literal["left", "center", "right", "justify"]

H_ALIGN: dict[H_ALIGNMENT, WD_ALIGN_PARAGRAPH] = {
    "left": WD_ALIGN_PARAGRAPH.LEFT,
    "center": WD_ALIGN_PARAGRAPH.CENTER,
    "right": WD_ALIGN_PARAGRAPH.RIGHT,
    "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
}
