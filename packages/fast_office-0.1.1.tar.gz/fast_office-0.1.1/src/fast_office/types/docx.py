"""Docx files type definitions."""

from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from fast_office.types.alignment import H_ALIGNMENT

HEADING_LEVEL = Literal[1, 2, 3, 4, 5, 6, 7, 8, 9]


class ContentElement(StrEnum):
    """Element Types."""

    HEADING = "heading"
    PARAGRAPH = "paragraph"
    TABLE = "table"
    IMAGE = "image"
    PAGE_BREAK = "page_break"


class DocxHeading(BaseModel):
    """A heading element."""

    level: Annotated[HEADING_LEVEL, Field(default=1, ge=1, le=9)]
    text: Annotated[str, Field(...)]

    model_config = ConfigDict(extra="ignore")


class DocxParagraph(BaseModel):
    """A paragraph element with optional styling."""

    text: str
    style: str | None = None
    bold: bool = False
    italic: bool = False
    font_size: int | None = None
    font_color: str | None = None
    alignment: H_ALIGNMENT | None = None

    model_config = ConfigDict(extra="ignore")

    model_config = ConfigDict(extra="ignore")


class DocxTable(BaseModel):
    """A table element."""

    headers: Annotated[list[str], Field(default_factory=list)]
    rows: Annotated[list[list[str]], Field(default_factory=list)]
    style: Annotated[str | None, Field(default="Table Grid", description="Word table style name")]
    col_widths: Annotated[
        list[float] | None, Field(default=None, description="Column widths in inches")
    ]

    model_config = ConfigDict(extra="ignore")


class DocxImage(BaseModel):
    """An image element."""

    path: Annotated[str, Field(..., description="Path or URL of the image")]
    width: Annotated[int | None, Field(default=None, description="Width in inches")]
    height: Annotated[int | None, Field(default=None, description="Height in inches")]
    caption: Annotated[
        str | None,
        Field(
            default=None,
        ),
    ]

    model_config = ConfigDict(extra="ignore")


class DocxSection(BaseModel):
    """A section of the document containing mixed content."""

    heading: Annotated[DocxHeading | None, Field(default=None)]
    content: Annotated[list[dict[str, Any]], Field(default_factory=list)]
    model_config = ConfigDict(extra="ignore")


class DocxSpec(BaseModel):
    """Full specification for a Word document."""

    title: Annotated[str, Field(..., description="Document title")]
    author: Annotated[str | None, Field(default=None)]
    organization: Annotated[str | None, Field(default=None)]
    font_name: Annotated[str | None, Field(default="Calibri", description="Default font family")]
    font_size: int = 11
    sections: Annotated[list[DocxSection], Field(default_factory=list)]
    header_text: Annotated[str | None, Field(default=None)]
    footer_text: Annotated[str | None, Field(default=None)]
    page_numbers: Annotated[bool, Field(default=True)]
    metadata: Annotated[dict[str, Any], Field(default_factory=dict)]

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="ignore")
