"""Fast Office package."""
