"""Application configuration utilities."""

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    """Application configuration settings."""

    output_dir: str = "./output"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    def ensure_output_dir(self) -> Path:
        """Ensure the output directory exists.

        Returns:
            Path to the output directory.
        """
        output_dir = Path(self.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir


config = Config()
