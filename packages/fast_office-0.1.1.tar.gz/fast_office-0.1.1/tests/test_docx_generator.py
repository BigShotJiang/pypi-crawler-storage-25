"""Test the DOCX generator."""

from fast_office.documents.docx import DocxGenerator
from fast_office.types.docx import ContentElement, DocxHeading, DocxParagraph, DocxSection, DocxSpec

spec = DocxSpec(
    title="Annual Report 2024",
    author="Jane Smith",
    organization="Acme Corp",
    font_name="Calibri",
    font_size=11,
    header_text="Acme Corp — Confidential",
    footer_text="© 2024 Acme Corp",
    page_numbers=True,
    metadata={"department": "Finance", "version": "1.0"},
    sections=[
        DocxSection(
            heading=DocxHeading(level=1, text="Executive Summary"),
            content=[
                {
                    "type": ContentElement.PARAGRAPH,
                    "element": DocxParagraph(
                        text="This report covers the fiscal year 2024 performance."
                    ).model_dump(),
                },
            ],
        ),
        DocxSection(
            heading=DocxHeading(level=1, text="Financial Overview"),
            content=[
                {
                    "type": ContentElement.PARAGRAPH,
                    "element": DocxParagraph(
                        text="Revenue grew by 12% compared to the previous year."
                    ).model_dump(),
                },
                {
                    "type": ContentElement.PARAGRAPH,
                    "element": DocxParagraph(
                        text="Operating costs were reduced by 8% through efficiency measures."
                    ).model_dump(),
                },
            ],
        ),
        DocxSection(
            heading=DocxHeading(level=2, text="Q4 Highlights"),
            content=[
                {
                    "type": ContentElement.PARAGRAPH,
                    "element": DocxParagraph(
                        text="Q4 saw record-breaking sales in the EMEA region."
                    ).model_dump(),
                }
            ],
        ),
    ],
)


def test_generate_docx_creates_file() -> None:
    """Ensure DOCX generation creates a file."""
    generator = DocxGenerator(spec)

    output_path = generator.generate()

    assert output_path.exists()
    assert output_path.suffix == ".docx"
