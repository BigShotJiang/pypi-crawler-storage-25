"""Test the PPTX generator."""

from fast_office.documents.pptx import PptxGenerator
from fast_office.types.pptx import (
    Position,
    PptxSlide,
    PptxSpec,
    SlideElement,
    SlideElementType,
    SlideLayout,
    SlideTheme,
)

spec = PptxSpec(
    title="Capital Connect Africa – Investor Pitch Deck",
    subtitle="Africa's Digital Capital Raising Marketplace",
    author="Capital Connect Africa",
    theme=SlideTheme(
        primary_color="#1B4332",  # deep green
        secondary_color="#40916C",  # mid green
        accent_color="#F4A261",  # warm amber
        background_color="#FFFFFF",
        font_heading="Calibri",
        font_body="Calibri",
        font_size_title=36,
        font_size_body=20,
    ),
    slides=[
        # 1. Cover
        PptxSlide(
            layout=SlideLayout.TITLE,
            title="Capital Connect Africa",
            subtitle="Africa's Digital Capital Raising Marketplace\ncapitalconnect.africa",
            speaker_notes="Opening slide. Introduce Capital Connect as the bridge between ambitious African businesses and aligned investors.",
        ),
        # 2. The Problem
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="The Problem",
            bullet_points=[
                "African SMEs and startups struggle to access growth capital — funding gaps exceed $330B annually across the continent.",
                "Investors lack structured, reliable deal flow and spend months sourcing and vetting opportunities.",
                "No single platform brings both sides together with readiness tools, valuations, and advisory support.",
                "The result: capital sits idle while high-potential businesses stall.",
            ],
            speaker_notes="Set the stage with the funding gap. Emphasise both sides of the marketplace problem — supply and demand.",
        ),
        # 3. Our Solution
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="Our Solution",
            bullet_points=[
                "Capital Connect is Africa's end-to-end digital capital raising marketplace.",
                "Businesses get AI-powered valuations, readiness reports, investor matching, and advisory support.",
                "Investors get curated deal flow, structured financials, and due-diligence tools — all on one secure platform.",
                "We support the full journey: from investment readiness to term sheet.",
            ],
            speaker_notes="Position Capital Connect as the full-stack solution, not just a directory.",
        ),
        # 4. Product — For Businesses
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="For Businesses & Startups",
            bullet_points=[
                "Instant AI-powered business valuation with branded, investor-ready PDF reports.",
                "Smart investor matching by sector, stage, and ticket size — from a network of 5,200+ verified investors.",
                "Eligibility, preparedness, and impact readiness assessments.",
                "Affordable advisory sessions to refine pitch documents, strategy, and negotiations.",
            ],
            speaker_notes="Walk through the business-side product features. Emphasise speed and affordability.",
        ),
        # 5. Product — For Investors
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="For Investors",
            bullet_points=[
                "Access vetted, investment-ready African businesses aligned with your mandate.",
                "Structured deal profiles with detailed financials, forecasts, and readiness scores.",
                "Smart filters save time — only see businesses that match your sector, stage, and ticket size.",
                "Secure platform with verified listings, encrypted data, and transparency safeguards.",
            ],
            speaker_notes="Show the investor value proposition. Stress quality of deal flow and time saved.",
        ),
        # 6. Lara AI
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="Lara — Our AI Assistant",
            bullet_points=[
                "Lara is Capital Connect's embedded AI assistant, available 24/7.",
                "Guides businesses through onboarding, valuation, and investor readiness.",
                "Answers investor queries and surfaces relevant opportunities instantly.",
                "Reduces support overhead while improving user experience at scale.",
            ],
            speaker_notes="Highlight the AI differentiation. Lara is live at lara.capitalconnect.africa.",
        ),
        # 7. Traction / Key Metrics
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="Traction",
            elements=[
                SlideElement(
                    element_type=SlideElementType.TABLE,
                    position=Position(left=1.5, top=1.8, width=10.0, height=3.5),
                    table_data=[
                        ["Metric", "Number"],
                        ["Businesses on Platform", "2,000+"],
                        ["Verified Investor Database", "5,200+"],
                        ["Advisory Sessions Delivered", "50+"],
                        ["Countries Across Africa", "15"],
                        ["Strategic Partners", "5"],
                    ],
                )
            ],
            speaker_notes="Let the numbers speak. These are live metrics from the platform.",
        ),
        # 8. Market Opportunity
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="Market Opportunity",
            bullet_points=[
                "Africa's SME funding gap exceeds $330B per year (IFC estimate).",
                "54 countries, 1.4B people, and one of the world's fastest-growing middle classes.",
                "Venture and growth capital into Africa reached $5B+ in recent years — and is accelerating.",
                "Capital Connect operates across 15 countries today, with clear expansion runway.",
            ],
            speaker_notes="Frame the TAM. Africa is not a monolith — position CCA as the pan-African infrastructure layer for capital.",
        ),
        # 9. Revenue Model
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="Business Model",
            bullet_points=[
                "Subscription plans for businesses — access to investor network, readiness tools, and reports.",
                "Success fees on completed funding rounds facilitated through the platform.",
                "Advisory services — paid expert sessions for pitch coaching, document review, and deal strategy.",
                "Investor-side access fees for premium deal flow, analytics, and filtering tools.",
            ],
            speaker_notes="Multiple revenue streams reduce dependency on any single line. Recurring + transactional mix.",
        ),
        # 10. Partners & Credibility
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="Partners & Credibility",
            bullet_points=[
                "Strategic partnerships with KCIC, MEDA, KNCCI, and KEPSA.",
                "Backed by Raisin Capital's proven track record in African capital markets.",
                "Trusted by 2,000+ businesses and investors across the continent.",
                "Operating in 15 African countries with a growing pan-African footprint.",
            ],
            speaker_notes="De-risk the investment by showing institutional validation and existing partnerships.",
        ),
        # 11. The Ask
        PptxSlide(
            layout=SlideLayout.TITLE_AND_CONTENT,
            title="The Ask",
            bullet_points=[
                "We are raising growth capital to accelerate platform expansion across Africa.",
                "Funds will be deployed into: engineering & AI (Lara), pan-African market expansion, and BD partnerships.",
                "We are seeking strategic investors aligned with financial inclusion and African economic growth.",
                "Join us in building the infrastructure that unlocks Africa's capital markets.",
            ],
            speaker_notes="Keep it direct. State the round size if known. Emphasise strategic fit over pure financial return.",
        ),
        # 12. Closing / CTA
        PptxSlide(
            layout=SlideLayout.TITLE,
            title="Let's Build Africa's Capital Future Together",
            subtitle="capitalconnect.africa  |  services@capitalconnect.africa  |  +254 792 724 103",
            speaker_notes="Close with the vision. Leave contact details prominent for follow-up.",
        ),
    ],
)


def test_generate_pptx_creates_file() -> None:
    """Ensure PPTX generation creates a file."""
    generator = PptxGenerator(spec)

    output_path = generator.generate()

    assert output_path.exists()
    assert output_path.suffix == ".pptx"
