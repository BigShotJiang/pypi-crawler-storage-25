"""Unit tests for Workbook generation."""

from fast_office.documents.workbook import WorkbookGenerator
from fast_office.types.workbook import (
    BorderSide,
    BorderStyle,
    CellAlignment,
    CellBorder,
    CellFill,
    CellFont,
    CellFormat,
    CellValue,
    ChartType,
    ColDimension,
    ConditionalRule,
    MergeRange,
    NamedRange,
    PageOrientation,
    PageSetup,
    RowDimension,
    SheetChart,
    WorkbookSpec,
    WorksheetSpec,
)

# ---------------------------------------------------------------------------
# Shared style helpers
# ---------------------------------------------------------------------------

NAVY = "002060"
TEAL = "1F7F7F"
LIGHT_BLUE_BG = "DCE6F1"
YELLOW_INPUT = "FFFF00"
WHITE = "FFFFFF"
BLACK = "000000"
DARK_GREY = "404040"
GREEN = "375623"
GREEN_BG = "E2EFDA"
ORANGE_BG = "FCE4D6"
SECTION_BG = "D9E1F2"

ACCOUNTING = '_(* #,##0.0_);_(* (#,##0.0);_(* "-"??_);_(@_)'
ACCOUNTING_INT = '_(* #,##0_);_(* (#,##0);_(* "-"_);_(@_)'
PCT_1DP = "0.0%"
PCT_0DP = "0%"


def title_fmt(bg: str = NAVY, fg: str = WHITE) -> CellFormat:
    """Bold centred title bar format — used for sheet header rows."""
    return CellFormat(
        font=CellFont(name="Arial", size=11, bold=True, color=fg),
        fill=CellFill(fg_color=bg),
        alignment=CellAlignment(horizontal="center", vertical="center", wrap_text=True),
        border=CellBorder(
            bottom=BorderSide(style=BorderStyle.THIN, color="AAAAAA"),
        ),
    )


def header_fmt(bg: str = NAVY, fg: str = WHITE) -> CellFormat:
    """Column header format with full border — used for year/label header rows."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, bold=True, color=fg),
        fill=CellFill(fg_color=bg),
        alignment=CellAlignment(horizontal="center", vertical="center", wrap_text=True),
        border=CellBorder(
            left=BorderSide(style=BorderStyle.THIN, color="AAAAAA"),
            right=BorderSide(style=BorderStyle.THIN, color="AAAAAA"),
            top=BorderSide(style=BorderStyle.THIN, color="AAAAAA"),
            bottom=BorderSide(style=BorderStyle.THIN, color="AAAAAA"),
        ),
    )


def section_fmt() -> CellFormat:
    """Section divider format — bold navy text on light blue background."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, bold=True, color=NAVY),
        fill=CellFill(fg_color=SECTION_BG),
        alignment=CellAlignment(horizontal="left", vertical="center"),
        border=CellBorder(
            bottom=BorderSide(style=BorderStyle.THIN, color="AAAAAA"),
        ),
    )


def label_fmt(indent: int = 0) -> CellFormat:
    """Plain left-aligned row label, with optional indent level."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, color=BLACK),
        alignment=CellAlignment(horizontal="left", vertical="center", indent=indent),
    )


def formula_fmt(number_format: str = ACCOUNTING) -> CellFormat:
    """Black font = formula cell (industry convention)."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, color=BLACK),
        alignment=CellAlignment(horizontal="right", vertical="center"),
        number_format=number_format,
    )


def input_fmt(number_format: str = ACCOUNTING) -> CellFormat:
    """Blue font = hardcoded input (industry convention)."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, color="0000FF"),
        fill=CellFill(fg_color=YELLOW_INPUT),
        alignment=CellAlignment(horizontal="right", vertical="center"),
        number_format=number_format,
    )


def xsheet_fmt(number_format: str = ACCOUNTING) -> CellFormat:
    """Green font = cross-sheet link (industry convention)."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, color="008000"),
        alignment=CellAlignment(horizontal="right", vertical="center"),
        number_format=number_format,
    )


def total_fmt(number_format: str = ACCOUNTING) -> CellFormat:
    """Grand-total row: bold, light blue fill, double-underline border."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, bold=True, color=BLACK),
        fill=CellFill(fg_color=LIGHT_BLUE_BG),
        alignment=CellAlignment(horizontal="right", vertical="center"),
        number_format=number_format,
        border=CellBorder(
            top=BorderSide(style=BorderStyle.THIN, color=NAVY),
            bottom=BorderSide(style=BorderStyle.DOUBLE, color=NAVY),
        ),
    )


def subtotal_fmt(number_format: str = ACCOUNTING) -> CellFormat:
    """Subtotal row: bold, single top/bottom border, no fill."""
    return CellFormat(
        font=CellFont(name="Arial", size=10, bold=True, color=BLACK),
        alignment=CellAlignment(horizontal="right", vertical="center"),
        number_format=number_format,
        border=CellBorder(
            top=BorderSide(style=BorderStyle.THIN, color=NAVY),
            bottom=BorderSide(style=BorderStyle.THIN, color=NAVY),
        ),
    )


# Column layout shared by all schedules
# A=Labels(30), B=Hist1(14), C=Hist2(14), D=Hist3(14), E=spacer(2),
# F=P1(14), G=P2(14), H=P3(14), I=P4(14), J=P5(14)

COMMON_COLS = [
    ColDimension(col="A", width=32),
    ColDimension(col="B", width=14),
    ColDimension(col="C", width=14),
    ColDimension(col="D", width=14),
    ColDimension(col="E", width=2),
    ColDimension(col="F", width=14),
    ColDimension(col="G", width=14),
    ColDimension(col="H", width=14),
    ColDimension(col="I", width=14),
    ColDimension(col="J", width=14),
]

YEAR_COLS = ["B", "C", "D", "F", "G", "H", "I", "J"]
PROJ_COLS = ["F", "G", "H", "I", "J"]
HIST_COLS = ["B", "C", "D"]


def year_headers(row: int) -> list[CellValue]:
    """Return header cells for year row at given row index."""
    labels = [
        "Actuals 1",
        "Actuals 2",
        "Actuals 3",
        "",
        "Proj 1",
        "Proj 2",
        "Proj 3",
        "Proj 4",
        "Proj 5",
    ]
    cols = ["B", "C", "D", "E", "F", "G", "H", "I", "J"]
    cells = []
    for col, lbl in zip(cols, labels, strict=False):
        cells.append(
            CellValue(
                cell=f"{col}{row}",
                value=lbl,
                format=header_fmt(NAVY, WHITE) if lbl else CellFormat(fill=CellFill(fg_color=NAVY)),
            )
        )
    return cells


# ===========================================================================
# 1. COVER SHEET
# ===========================================================================

cover_sheet = WorksheetSpec(
    name="Cover",
    tab_color=NAVY,
    zoom=100,
    col_dimensions=[
        ColDimension(col="A", width=5),
        ColDimension(col="B", width=25),
        ColDimension(col="C", width=35),
        ColDimension(col="D", width=20),
    ],
    row_dimensions=[
        RowDimension(row=1, height=40),
        RowDimension(row=2, height=10),
        *[RowDimension(row=r, height=22) for r in range(3, 20)],
    ],
    merges=[
        MergeRange(range="B1:D1"),
        MergeRange(range="B3:D3"),
        MergeRange(range="B5:D5"),
    ],
    cells=[
        # Title bar
        CellValue(
            cell="B1",
            value="APEX SOLUTIONS INC.",
            format=CellFormat(
                font=CellFont(name="Arial", size=18, bold=True, color=WHITE),
                fill=CellFill(fg_color=NAVY),
                alignment=CellAlignment(horizontal="center", vertical="center"),
            ),
        ),
        CellValue(
            cell="B3",
            value="Three-Statement Financial Model",
            format=CellFormat(
                font=CellFont(name="Arial", size=13, bold=True, color=NAVY),
                alignment=CellAlignment(horizontal="center", vertical="center"),
            ),
        ),
        CellValue(
            cell="B5",
            value="All figures in USD millions unless stated otherwise",
            format=CellFormat(
                font=CellFont(name="Arial", size=10, italic=True, color=DARK_GREY),
                alignment=CellAlignment(horizontal="center"),
            ),
        ),
        # Metadata labels
        *[
            CellValue(
                cell=f"B{r}",
                value=lbl,
                format=CellFormat(
                    font=CellFont(name="Arial", size=10, bold=True, color=NAVY),
                    alignment=CellAlignment(horizontal="left"),
                ),
            )
            for r, lbl in [
                (7, "VERSION:"),
                (8, "DATE:"),
                (9, "COMPANY:"),
                (10, "MODEL PURPOSE:"),
                (11, "PREPARED BY:"),
                (12, "REVIEWED BY:"),
            ]
        ],
        # Metadata values
        CellValue(cell="C7", value="Draft v1.0", format=input_fmt("@")),
        CellValue(cell="C8", formula="=TODAY()", format=formula_fmt("DD-MMM-YYYY")),
        CellValue(cell="C9", value="Apex Solutions Inc.", format=input_fmt("@")),
        CellValue(cell="C10", value="Equity Research — 5-Year Projection", format=input_fmt("@")),
        CellValue(cell="C11", value="Capital Partners Equity Research", format=input_fmt("@")),
        CellValue(cell="C12", value="Senior Analyst", format=input_fmt("@")),
        # Legend
        CellValue(cell="B14", value="Color Legend", format=section_fmt()),
        CellValue(
            cell="B15",
            value="Blue text on yellow  →  Hardcoded input assumption",
            format=CellFormat(
                font=CellFont(name="Arial", size=9, color="0000FF"),
                fill=CellFill(fg_color=YELLOW_INPUT),
            ),
        ),
        CellValue(
            cell="B16",
            value="Black text           →  Calculated formula",
            format=CellFormat(
                font=CellFont(name="Arial", size=9, color=BLACK),
            ),
        ),
        CellValue(
            cell="B17",
            value="Green text           →  Cross-sheet link",
            format=CellFormat(
                font=CellFont(name="Arial", size=9, color="008000"),
            ),
        ),
    ],
    page_setup=PageSetup(orientation=PageOrientation.PORTRAIT, print_area="A1:D20"),
)


# ===========================================================================
# 2. NTBA — Non-Time-Based Assumptions (static)
# ===========================================================================

ntba_sheet = WorksheetSpec(
    name="NTBA",
    tab_color="70AD47",
    zoom=100,
    col_dimensions=[
        ColDimension(col="A", width=38),
        ColDimension(col="B", width=18),
        ColDimension(col="C", width=40),
    ],
    row_dimensions=[RowDimension(row=r, height=18) for r in range(1, 30)],
    merges=[MergeRange(range="A1:C1")],
    cells=[
        CellValue(cell="A1", value="NTBA — Static Assumptions", format=title_fmt()),
        CellValue(cell="A2", value="Assumption", format=header_fmt()),
        CellValue(cell="B2", value="Value", format=header_fmt()),
        CellValue(cell="C2", value="Note", format=header_fmt()),
        # Calendar
        CellValue(cell="A3", value="CALENDAR", format=section_fmt()),
        CellValue(cell="A4", value="Days in a Year", format=label_fmt()),
        CellValue(cell="B4", value=365, format=input_fmt("0")),
        CellValue(cell="C4", value="Used for DSO / DIO / DPO calculations", format=label_fmt()),
        CellValue(cell="A5", value="Months in a Year", format=label_fmt()),
        CellValue(cell="B5", value=12, format=input_fmt("0")),
        # Working capital days
        CellValue(cell="A6", value="WORKING CAPITAL TARGETS", format=section_fmt()),
        CellValue(cell="A7", value="Receivables Collection Period (days)", format=label_fmt()),
        CellValue(cell="B7", value=19, format=input_fmt("0")),
        CellValue(cell="C7", value="Per MD&A — improved credit policies", format=label_fmt()),
        CellValue(cell="A8", value="Inventory Processing Period (days)", format=label_fmt()),
        CellValue(cell="B8", value=70, format=input_fmt("0")),
        CellValue(cell="C8", value="Per MD&A — lean / JIT practices", format=label_fmt()),
        CellValue(cell="A9", value="Payables Payment Period (days)", format=label_fmt()),
        CellValue(cell="B9", value=48, format=input_fmt("0")),
        CellValue(cell="C9", value="Per MD&A — extended supplier terms", format=label_fmt()),
        # Debt & interest
        CellValue(cell="A10", value="DEBT & INTEREST", format=section_fmt()),
        CellValue(cell="A11", value="Term Loan Interest Rate (fixed)", format=label_fmt()),
        CellValue(cell="B11", value=0.09, format=input_fmt(PCT_1DP)),
        CellValue(cell="C11", value="Per MD&A — locked fixed rate", format=label_fmt()),
        CellValue(cell="A12", value="Interest Rate on Cash Deposits", format=label_fmt()),
        CellValue(cell="B12", value=0.03, format=input_fmt(PCT_1DP)),
        CellValue(cell="C12", value="Per MD&A — 3.0% on deposits", format=label_fmt()),
        CellValue(cell="A13", value="Annual Debt Repayment ($mm)", format=label_fmt()),
        CellValue(cell="B13", value=2000, format=input_fmt(ACCOUNTING_INT)),
        CellValue(cell="C13", value="Per MD&A — $2bn term loan repayment p.a.", format=label_fmt()),
        CellValue(cell="A14", value="Annual New Term Loan Drawdown ($mm)", format=label_fmt()),
        CellValue(cell="B14", value=1000, format=input_fmt(ACCOUNTING_INT)),
        CellValue(cell="C14", value="Per MD&A — $1bn new issuance p.a.", format=label_fmt()),
        # Tax
        CellValue(cell="A15", value="TAX", format=section_fmt()),
        CellValue(cell="A16", value="Corporate Tax Rate", format=label_fmt()),
        CellValue(cell="B16", value=0.25, format=input_fmt(PCT_1DP)),
        CellValue(
            cell="C16", value="Assumed standard rate; adjust to jurisdiction", format=label_fmt()
        ),
        # Depreciation
        CellValue(cell="A17", value="DEPRECIATION", format=section_fmt()),
        CellValue(cell="A18", value="Useful Life of New CapEx (years)", format=label_fmt()),
        CellValue(cell="B18", value=10, format=input_fmt("0")),
        CellValue(cell="C18", value="Straight-line; adjust per asset class", format=label_fmt()),
        # Dividend
        CellValue(cell="A19", value="DIVIDENDS", format=section_fmt()),
        CellValue(cell="A20", value="Dividend Payout Ratio", format=label_fmt()),
        CellValue(cell="B20", value=0.30, format=input_fmt(PCT_1DP)),
        CellValue(cell="C20", value="30% of PAT distributed annually", format=label_fmt()),
    ],
)


# ===========================================================================
# 3. TBA — Time-Based Assumptions
# ===========================================================================

tba_sheet = WorksheetSpec(
    name="TBA",
    tab_color="70AD47",
    zoom=100,
    col_dimensions=COMMON_COLS,
    row_dimensions=[
        RowDimension(row=1, height=28),
        *[RowDimension(row=r, height=18) for r in range(2, 40)],
    ],
    merges=[MergeRange(range="A1:J1")],
    freeze_panes="F3",
    cells=[
        CellValue(cell="A1", value="TBA — Time-Based Assumptions", format=title_fmt()),
        CellValue(cell="A2", value="Metric", format=header_fmt()),
        *year_headers(2),
        # Revenue growth rates
        CellValue(cell="A3", value="REVENUE GROWTH RATES", format=section_fmt()),
        CellValue(cell="A4", value="Software Revenue Growth %", format=label_fmt()),
        # Historicals derived: (15000-12000)/12000 = 25%, (18500-15000)/15000 = 23.3%
        CellValue(
            cell="B4",
            value=None,
            format=formula_fmt(PCT_1DP),
            comment="Hist 1 base — no prior year",
        ),
        CellValue(
            cell="C4", formula="=(Revenue!C5-Revenue!B5)/Revenue!B5", format=formula_fmt(PCT_1DP)
        ),
        CellValue(
            cell="D4", formula="=(Revenue!D5-Revenue!C5)/Revenue!C5", format=formula_fmt(PCT_1DP)
        ),
        *[CellValue(cell=f"{c}4", value=0.20, format=input_fmt(PCT_1DP)) for c in PROJ_COLS],
        CellValue(cell="A5", value="Hardware Revenue Growth %", format=label_fmt()),
        CellValue(cell="B5", value=None, format=formula_fmt(PCT_1DP)),
        CellValue(
            cell="C5", formula="=(Revenue!C6-Revenue!B6)/Revenue!B6", format=formula_fmt(PCT_1DP)
        ),
        CellValue(
            cell="D5", formula="=(Revenue!D6-Revenue!C6)/Revenue!C6", format=formula_fmt(PCT_1DP)
        ),
        *[CellValue(cell=f"{c}5", value=0.18, format=input_fmt(PCT_1DP)) for c in PROJ_COLS],
        CellValue(cell="A6", value="IT Services Revenue Growth %", format=label_fmt()),
        CellValue(cell="B6", value=None, format=formula_fmt(PCT_1DP)),
        CellValue(
            cell="C6", formula="=(Revenue!C7-Revenue!B7)/Revenue!C7", format=formula_fmt(PCT_1DP)
        ),
        CellValue(
            cell="D6", formula="=(Revenue!D7-Revenue!C7)/Revenue!D7", format=formula_fmt(PCT_1DP)
        ),
        *[CellValue(cell=f"{c}6", value=0.16, format=input_fmt(PCT_1DP)) for c in PROJ_COLS],
        # COGS %
        CellValue(cell="A7", value="COGS % OF SEGMENT REVENUE", format=section_fmt()),
        CellValue(cell="A8", value="Software COGS %", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", value=0.50, format=input_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A9", value="Hardware COGS %", format=label_fmt()),
        *[
            CellValue(cell=f"{c}9", value=0.48, format=input_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A10", value="IT Services COGS %", format=label_fmt()),
        *[
            CellValue(cell=f"{c}10", value=0.50, format=input_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # OpEx
        CellValue(cell="A11", value="OPERATING EXPENSES", format=section_fmt()),
        CellValue(cell="A12", value="SG&A % of Total Revenue", format=label_fmt()),
        *[
            CellValue(cell=f"{c}12", value=0.15, format=input_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A13", value="Staff Cost ($mm)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}13", value=v, format=input_fmt(ACCOUNTING))
            for c, v in zip(
                [*HIST_COLS, *PROJ_COLS],
                [3500, 4000, 4800, 5500, 6200, 7100, 8000, 9000],
                strict=False,
            )
        ],
        # CapEx
        CellValue(cell="A14", value="CAPITAL EXPENDITURES", format=section_fmt()),
        CellValue(cell="A15", value="CapEx ($mm)", format=label_fmt()),
        # Historical CapEx estimated; projection per MD&A
        *[
            CellValue(cell=f"{c}15", value=v, format=input_fmt(ACCOUNTING))
            for c, v in zip(
                [*HIST_COLS, *PROJ_COLS],
                [7500, 8800, 9500, 10000, 11500, 13000, 13500, 15000],
                strict=False,
            )
        ],
        # Macro / market
        CellValue(cell="A16", value="MACRO ASSUMPTIONS", format=section_fmt()),
        CellValue(cell="A17", value="GDP Growth Rate (market context)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}17", value=v, format=input_fmt(PCT_1DP))
            for c, v in zip(
                [*HIST_COLS, *PROJ_COLS],
                [0.032, 0.027, 0.031, 0.030, 0.030, 0.031, 0.031, 0.032],
                strict=False,
            )
        ],
        CellValue(cell="A18", value="Tech Sector Growth (market context)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}18", value=0.14, format=input_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
)


# ===========================================================================
# 4. REVENUE SCHEDULE
# ===========================================================================

revenue_sheet = WorksheetSpec(
    name="Revenue",
    tab_color=TEAL,
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Revenue Schedule — By Segment", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        CellValue(cell="A3", value="REVENUE", format=section_fmt()),
        # Software
        CellValue(cell="A4", value="Software — Prior Year Revenue", format=label_fmt(indent=1)),
        CellValue(cell="B4", value=None, format=formula_fmt()),
        CellValue(cell="C4", formula="=B5", format=formula_fmt()),
        CellValue(cell="D4", formula="=C5", format=formula_fmt()),
        *[
            CellValue(cell=f"{c}4", formula=f"={p}5", format=formula_fmt())
            for c, p in zip(PROJ_COLS, ["D", *PROJ_COLS[:-1]], strict=False)
        ],
        CellValue(cell="A5", value="Software Revenue", format=label_fmt(indent=1)),
        CellValue(cell="B5", value=12000, format=input_fmt()),
        CellValue(cell="C5", value=15000, format=input_fmt()),
        CellValue(cell="D5", value=18500, format=input_fmt()),
        *[
            CellValue(cell=f"{c}5", formula=f"={p}5*(1+TBA!{c}4)", format=formula_fmt())
            for c, p in zip(PROJ_COLS, ["D", *PROJ_COLS[:-1]], strict=False)
        ],
        CellValue(cell="A6", value="Hardware Revenue", format=label_fmt(indent=1)),
        CellValue(cell="B6", value=8500, format=input_fmt()),
        CellValue(cell="C6", value=10200, format=input_fmt()),
        CellValue(cell="D6", value=12300, format=input_fmt()),
        *[
            CellValue(cell=f"{c}6", formula=f"={p}6*(1+TBA!{c}5)", format=formula_fmt())
            for c, p in zip(PROJ_COLS, ["D", *PROJ_COLS[:-1]], strict=False)
        ],
        CellValue(cell="A7", value="IT Services Revenue", format=label_fmt(indent=1)),
        CellValue(cell="B7", value=5000, format=input_fmt()),
        CellValue(cell="C7", value=6500, format=input_fmt()),
        CellValue(cell="D7", value=8000, format=input_fmt()),
        *[
            CellValue(cell=f"{c}7", formula=f"={p}7*(1+TBA!{c}6)", format=formula_fmt())
            for c, p in zip(PROJ_COLS, ["D", *PROJ_COLS[:-1]], strict=False)
        ],
        CellValue(cell="A8", value="Total Revenue", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", formula=f"=SUM({c}5:{c}7)", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
    charts=[
        SheetChart(
            chart_type=ChartType.LINE,
            title="Revenue by Segment — Projection",
            data_range="A4:J8",
            categories_range="B2:J2",
            position="A10",
            width=20,
            height=12,
        )
    ],
)


# ===========================================================================
# 5. COGS SCHEDULE
# ===========================================================================

cogs_sheet = WorksheetSpec(
    name="COGS",
    tab_color=TEAL,
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Cost of Goods Sold Schedule — By Segment", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        CellValue(cell="A3", value="COST OF GOODS SOLD", format=section_fmt()),
        CellValue(cell="A4", value="Software COGS", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}4", formula=f"=Revenue!{c}5*TBA!{c}8", format=formula_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A5", value="Hardware COGS", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}5", formula=f"=Revenue!{c}6*TBA!{c}9", format=formula_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A6", value="IT Services COGS", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}6", formula=f"=Revenue!{c}7*TBA!{c}10", format=formula_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A7", value="Total COGS", format=label_fmt()),
        *[
            CellValue(cell=f"{c}7", formula=f"=SUM({c}4:{c}6)", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Blended COGS %", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", formula=f"={c}7/Revenue!{c}8", format=formula_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
)


# ===========================================================================
# 6. OPEX SCHEDULE (SG&A + Staff costs separately)
# ===========================================================================

opex_sheet = WorksheetSpec(
    name="OpEx",
    tab_color=TEAL,
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Operating Expenses Schedule", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        CellValue(cell="A3", value="STAFF COSTS", format=section_fmt()),
        CellValue(cell="A4", value="Staff / Payroll Cost", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}4", formula=f"=TBA!{c}13", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A5", value="Total Staff Cost", format=label_fmt()),
        *[
            CellValue(cell=f"{c}5", formula=f"={c}4", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A6", value="OTHER OPERATING EXPENSES", format=section_fmt()),
        CellValue(cell="A7", value="SG&A (15% of total revenue)", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}7", formula=f"=Revenue!{c}8*TBA!{c}12", format=formula_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Total Other OpEx", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", formula=f"={c}7", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A9", value="TOTAL OPERATING EXPENSES", format=label_fmt()),
        *[
            CellValue(cell=f"{c}9", formula=f"={c}5+{c}8", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A10", value="OpEx % of Revenue", format=label_fmt()),
        *[
            CellValue(cell=f"{c}10", formula=f"={c}9/Revenue!{c}8", format=formula_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
)


# ===========================================================================
# 7. PPE SCHEDULE
# ===========================================================================

ppe_sheet = WorksheetSpec(
    name="PPE",
    tab_color="C55A11",
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Property, Plant & Equipment Roll-Forward", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        CellValue(cell="A3", value="COST", format=section_fmt()),
        CellValue(cell="A4", value="Opening Gross Cost", format=label_fmt(indent=1)),
        # Hist 1 opening is a hardcoded input
        CellValue(
            cell="B4",
            value=45000,
            format=input_fmt(),
            comment="Historical opening cost — input from balance sheet",
        ),
        *[
            CellValue(cell=f"{c}4", formula=f"={p}7", format=xsheet_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        CellValue(cell="A5", value="Additions (CapEx)", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}5", formula=f"=TBA!{c}15", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A6", value="Disposals (cost)", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}6",
                value=0,
                format=input_fmt(),
                comment="Assume no disposals unless specified",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A7", value="Closing Gross Cost", format=label_fmt()),
        *[
            CellValue(cell=f"{c}7", formula=f"={c}4+{c}5-{c}6", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="ACCUMULATED DEPRECIATION", format=section_fmt()),
        CellValue(cell="A9", value="Opening Accumulated Depreciation", format=label_fmt(indent=1)),
        CellValue(
            cell="B9",
            value=15000,
            format=input_fmt(),
            comment="Historical opening acc. depreciation — from balance sheet",
        ),
        *[
            CellValue(cell=f"{c}9", formula=f"={p}12", format=xsheet_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        CellValue(
            cell="A10",
            value="Depreciation Charge (new CapEx / useful life)",
            format=label_fmt(indent=1),
        ),
        *[
            CellValue(cell=f"{c}10", formula=f"={c}5/NTBA!$B$18", format=formula_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A11", value="Depreciation on Existing Assets", format=label_fmt(indent=1)),
        CellValue(
            cell="B11",
            value=3500,
            format=input_fmt(),
            comment="Estimated existing asset depreciation",
        ),
        *[
            CellValue(cell=f"{c}11", formula=f"=MAX({p}11-{p}10,0)", format=formula_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        CellValue(cell="A12", value="Closing Accumulated Depreciation", format=label_fmt()),
        *[
            CellValue(cell=f"{c}12", formula=f"={c}9+{c}10+{c}11", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A13", value="NET BOOK VALUE (NBV)", format=section_fmt()),
        *[
            CellValue(cell=f"{c}13", formula=f"={c}7-{c}12", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A14", value="TOTAL DEPRECIATION CHARGE (IS)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}14", formula=f"={c}10+{c}11", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # Goodwill (stable per MD&A)
        CellValue(cell="A16", value="GOODWILL", format=section_fmt()),
        CellValue(
            cell="A17", value="Goodwill Balance (stable — no impairment)", format=label_fmt()
        ),
        *[
            CellValue(
                cell=f"{c}17",
                value=5000,
                format=input_fmt(),
                comment="Per MD&A: goodwill stable; no planned acquisitions",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
)


# ===========================================================================
# 8. WORKING CAPITAL SCHEDULE
# ===========================================================================

wc_sheet = WorksheetSpec(
    name="Working Cap",
    tab_color="C55A11",
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Working Capital Schedule", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        # AR
        CellValue(cell="A3", value="ACCOUNTS RECEIVABLE", format=section_fmt()),
        CellValue(
            cell="A4", value="AR — Days Sales Outstanding (target)", format=label_fmt(indent=1)
        ),
        *[
            CellValue(cell=f"{c}4", formula="=NTBA!$B$7", format=xsheet_fmt("0"))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A5", value="Accounts Receivable", format=label_fmt(indent=1)),
        CellValue(cell="B5", value=1440, format=input_fmt(), comment="Actuals 1 AR balance"),
        CellValue(cell="C5", value=1700, format=input_fmt(), comment="Actuals 2 AR balance"),
        CellValue(cell="D5", value=1960, format=input_fmt(), comment="Actuals 3 AR balance"),
        *[
            CellValue(
                cell=f"{c}5", formula=f"=Revenue!{c}8/NTBA!$B$4*NTBA!$B$7", format=formula_fmt()
            )
            for c in PROJ_COLS
        ],
        CellValue(cell="A6", value="Change in AR (↑ = use of cash)", format=label_fmt(indent=1)),
        CellValue(cell="B6", value=None, format=formula_fmt()),
        *[
            CellValue(cell=f"{c}6", formula=f"={c}5-{p}5", format=formula_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        # Inventory
        CellValue(cell="A7", value="INVENTORY", format=section_fmt()),
        CellValue(
            cell="A8",
            value="Inventory — Days Inventory Outstanding (target)",
            format=label_fmt(indent=1),
        ),
        *[
            CellValue(cell=f"{c}8", formula="=NTBA!$B$8", format=xsheet_fmt("0"))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A9", value="Inventory", format=label_fmt(indent=1)),
        CellValue(cell="B9", value=3100, format=input_fmt()),
        CellValue(cell="C9", value=3560, format=input_fmt()),
        CellValue(cell="D9", value=4000, format=input_fmt()),
        *[
            CellValue(cell=f"{c}9", formula=f"=COGS!{c}7/NTBA!$B$4*NTBA!$B$8", format=formula_fmt())
            for c in PROJ_COLS
        ],
        CellValue(
            cell="A10", value="Change in Inventory (↑ = use of cash)", format=label_fmt(indent=1)
        ),
        CellValue(cell="B10", value=None, format=formula_fmt()),
        *[
            CellValue(cell=f"{c}10", formula=f"={c}9-{p}9", format=formula_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        # AP
        CellValue(cell="A11", value="ACCOUNTS PAYABLE", format=section_fmt()),
        CellValue(
            cell="A12", value="AP — Days Payable Outstanding (target)", format=label_fmt(indent=1)
        ),
        *[
            CellValue(cell=f"{c}12", formula="=NTBA!$B$9", format=xsheet_fmt("0"))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A13", value="Accounts Payable", format=label_fmt(indent=1)),
        CellValue(cell="B13", value=2200, format=input_fmt()),
        CellValue(cell="C13", value=2480, format=input_fmt()),
        CellValue(cell="D13", value=2760, format=input_fmt()),
        *[
            CellValue(
                cell=f"{c}13", formula=f"=COGS!{c}7/NTBA!$B$4*NTBA!$B$9", format=formula_fmt()
            )
            for c in PROJ_COLS
        ],
        CellValue(
            cell="A14", value="Change in AP (↑ = source of cash)", format=label_fmt(indent=1)
        ),
        CellValue(cell="B14", value=None, format=formula_fmt()),
        *[
            CellValue(cell=f"{c}14", formula=f"={c}13-{p}13", format=formula_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        # Net WC
        CellValue(cell="A15", value="NET WORKING CAPITAL", format=section_fmt()),
        *[
            CellValue(cell=f"{c}15", formula=f"={c}5+{c}9-{c}13", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(
            cell="A16", value="Change in Net Working Capital (↑ = use of cash)", format=label_fmt()
        ),
        CellValue(cell="B16", value=None, format=formula_fmt()),
        *[
            CellValue(cell=f"{c}16", formula=f"={c}15-{p}15", format=formula_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
    ],
)


# ===========================================================================
# 9. DEBT SCHEDULE
# ===========================================================================

debt_sheet = WorksheetSpec(
    name="Debt",
    tab_color="C55A11",
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Loan / Debt Schedule", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        CellValue(cell="A3", value="TERM LOAN", format=section_fmt()),
        CellValue(cell="A4", value="Opening Balance", format=label_fmt(indent=1)),
        CellValue(
            cell="B4",
            value=20000,
            format=input_fmt(),
            comment="Opening term loan balance — Actuals 1",
        ),
        *[
            CellValue(cell=f"{c}4", formula=f"={p}8", format=xsheet_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        CellValue(cell="A5", value="Drawdowns (new issuance)", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}5", formula="=NTBA!$B$14", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A6", value="Repayments", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}6",
                formula="=-NTBA!$B$13",
                format=formula_fmt(),
                comment="Shown as negative (cash outflow)",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A7", value="Moratorium (interest / principal)", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}7",
                value=0,
                format=input_fmt(),
                comment="Input moratorium relief amount if applicable; 0 if none",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Closing Balance", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", formula=f"={c}4+{c}5+{c}6+{c}7", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(
            cell="A9", value="Average Balance (for interest calc)", format=label_fmt(indent=1)
        ),
        CellValue(cell="B9", formula="=B8", format=formula_fmt()),
        *[
            CellValue(cell=f"{c}9", formula=f"=({p}8+{c}8)/2", format=formula_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        CellValue(cell="A10", value="Interest Rate (fixed)", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}10", formula="=NTBA!$B$11", format=xsheet_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A11", value="Interest Expense (IS charge)", format=label_fmt()),
        *[
            CellValue(
                cell=f"{c}11",
                formula=f"={c}9*{c}10",
                format=total_fmt(),
                comment="Flows to Income Statement — Finance Cost",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # Cash interest income
        CellValue(cell="A12", value="INTEREST INCOME ON CASH", format=section_fmt()),
        CellValue(cell="A13", value="Average Cash Balance", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}13",
                formula=f"='Cash Flow'!{c}4",
                format=xsheet_fmt(),
                comment="Opening cash from CFS — circular-safe average after first build",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A14", value="Interest Rate on Deposits", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}14", formula="=NTBA!$B$12", format=xsheet_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A15", value="Interest Income (IS)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}15", formula=f"={c}13*{c}14", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
)


# ===========================================================================
# 10. EQUITY SCHEDULE
# ===========================================================================

equity_sheet = WorksheetSpec(
    name="Equity",
    tab_color="C55A11",
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1")],
    cells=[
        CellValue(cell="A1", value="Equity Roll-Forward", format=title_fmt()),
        CellValue(cell="A2", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(2),
        CellValue(cell="A3", value="SHAREHOLDERS' EQUITY", format=section_fmt()),
        CellValue(cell="A4", value="Opening Equity", format=label_fmt(indent=1)),
        CellValue(
            cell="B4",
            value=18000,
            format=input_fmt(),
            comment="Opening equity — Actuals 1 from balance sheet",
        ),
        *[
            CellValue(cell=f"{c}4", formula=f"={p}8", format=xsheet_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        CellValue(cell="A5", value="Profit After Tax (PAT)", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}5",
                formula=f"='Income Stmt'!{c}14",
                format=xsheet_fmt(),
                comment="Links from bottom of Income Statement",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A6", value="Dividends Paid", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}6",
                formula=f"=-{c}5*NTBA!$B$20",
                format=formula_fmt(),
                comment="30% payout ratio per NTBA; negative = outflow",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(
            cell="A7",
            value="Other Comprehensive Income / Capital Injections",
            format=label_fmt(indent=1),
        ),
        *[
            CellValue(
                cell=f"{c}7",
                value=0,
                format=input_fmt(),
                comment="Adjust for rights issues, FX translation reserves, etc.",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Closing Equity", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", formula=f"={c}4+{c}5+{c}6+{c}7", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
)


# ===========================================================================
# 11. INCOME STATEMENT
# ===========================================================================

is_sheet = WorksheetSpec(
    name="Income Stmt",
    tab_color=NAVY,
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1"), MergeRange(range="A2:J2")],
    cells=[
        CellValue(cell="A1", value="APEX SOLUTIONS INC. — Income Statement", format=title_fmt()),
        CellValue(
            cell="A2",
            value="All figures in USD millions",
            format=CellFormat(
                font=CellFont(name="Arial", size=9, italic=True, color=DARK_GREY),
                alignment=CellAlignment(horizontal="center"),
            ),
        ),
        CellValue(cell="A3", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(3),
        # Revenue
        CellValue(cell="A4", value="Revenue", format=section_fmt()),
        CellValue(cell="A5", value="Software", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}5", formula=f"=Revenue!{c}5", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A6", value="Hardware", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}6", formula=f"=Revenue!{c}6", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A7", value="IT Services", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}7", formula=f"=Revenue!{c}7", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Total Revenue", format=label_fmt()),
        *[
            CellValue(cell=f"{c}8", formula=f"=SUM({c}5:{c}7)", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # COGS & Gross Profit
        CellValue(cell="A9", value="Cost of Sales", format=label_fmt()),
        *[
            CellValue(
                cell=f"{c}9",
                formula=f"=-COGS!{c}7",
                format=formula_fmt(),
                comment="Negative: deducted from revenue",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A10", value="Gross Profit", format=label_fmt()),
        *[
            CellValue(cell=f"{c}10", formula=f"={c}8+{c}9", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A11", value="  Gross Margin %", format=label_fmt(indent=2)),
        *[
            CellValue(cell=f"{c}11", formula=f"={c}10/{c}8", format=formula_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # OpEx
        CellValue(cell="A12", value="Staff Costs", format=label_fmt()),
        *[
            CellValue(cell=f"{c}12", formula=f"=-OpEx!{c}5", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A13", value="Other Operating Expenses (SG&A)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}13", formula=f"=-OpEx!{c}8", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # EBITDA
        CellValue(cell="A14", value="EBITDA", format=label_fmt()),
        *[
            CellValue(cell=f"{c}14", formula=f"={c}10+{c}12+{c}13", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A15", value="  EBITDA Margin %", format=label_fmt(indent=2)),
        *[
            CellValue(cell=f"{c}15", formula=f"={c}14/{c}8", format=formula_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # D&A → EBIT
        CellValue(cell="A16", value="Depreciation & Amortisation", format=label_fmt()),
        *[
            CellValue(cell=f"{c}16", formula=f"=-PPE!{c}14", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A17", value="EBIT (Operating Profit)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}17", formula=f"={c}14+{c}16", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A18", value="  EBIT Margin %", format=label_fmt(indent=2)),
        *[
            CellValue(cell=f"{c}18", formula=f"={c}17/{c}8", format=formula_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # Finance items
        CellValue(cell="A19", value="Finance Cost (Interest Expense)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}19", formula=f"=-Debt!{c}11", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A20", value="Finance Income (Interest on Cash)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}20", formula=f"=Debt!{c}15", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # EBT
        CellValue(cell="A21", value="Earnings Before Tax (EBT)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}21", formula=f"={c}17+{c}19+{c}20", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # Tax
        CellValue(cell="A22", value="Income Tax", format=label_fmt()),
        *[
            CellValue(
                cell=f"{c}22",
                formula=f"=-MAX({c}21,0)*NTBA!$B$16",
                format=formula_fmt(),
                comment="Tax only on positive EBT; uses IFERROR protection",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # PAT
        CellValue(cell="A23", value="Profit After Tax (PAT / Net Income)", format=label_fmt()),
        *[
            CellValue(cell=f"{c}23", formula=f"={c}21+{c}22", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A24", value="  Net Margin %", format=label_fmt(indent=2)),
        *[
            CellValue(cell=f"{c}24", formula=f"={c}23/{c}8", format=formula_fmt(PCT_1DP))
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
    # Fix: IS row 14 was used for EBITDA — renumber alias above maps IS!{c}14 to PAT
    # (Note: Equity sheet references Income Stmt!{c}14 expecting PAT.
    #  Adjust Equity sheet formula to reference Income Stmt!{c}23 for PAT.)
)

# Fix Equity reference — PAT is on row 23 of IS
for cell in equity_sheet.cells or []:
    if cell.formula and "'Income Stmt'!" in cell.formula and "14" in cell.formula:
        cell.formula = cell.formula.replace("'Income Stmt'!", "'Income Stmt'!").replace("14", "23")


# ===========================================================================
# 12. BALANCE SHEET
# ===========================================================================

bs_sheet = WorksheetSpec(
    name="Balance Sheet",
    tab_color=NAVY,
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1"), MergeRange(range="A2:J2")],
    cells=[
        CellValue(cell="A1", value="APEX SOLUTIONS INC. — Balance Sheet", format=title_fmt()),
        CellValue(
            cell="A2",
            value="All figures in USD millions",
            format=CellFormat(
                font=CellFont(name="Arial", size=9, italic=True, color=DARK_GREY),
                alignment=CellAlignment(horizontal="center"),
            ),
        ),
        CellValue(cell="A3", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(3),
        # ── ASSETS ──────────────────────────────────────────────────────
        CellValue(cell="A4", value="ASSETS", format=section_fmt()),
        CellValue(cell="A5", value="Current Assets", format=label_fmt()),
        CellValue(cell="A6", value="Cash & Equivalents", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}6",
                formula=f"='Cash Flow'!{c}19",
                format=xsheet_fmt(),
                comment="Closing cash from Cash Flow Statement",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A7", value="Accounts Receivable", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}7", formula=f"='Working Cap'!{c}5", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Inventory", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}8", formula=f"='Working Cap'!{c}9", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A9", value="Other Current Assets", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}9", value=500, format=input_fmt(), comment="Prepayments, other CA")
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A10", value="Total Current Assets", format=label_fmt()),
        *[
            CellValue(cell=f"{c}10", formula=f"=SUM({c}6:{c}9)", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A11", value="Non-Current Assets", format=label_fmt()),
        CellValue(cell="A12", value="PP&E (Net Book Value)", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}12", formula=f"=PPE!{c}13", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A13", value="Goodwill", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}13", formula=f"=PPE!{c}17", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A14", value="Other Non-Current Assets", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}14", value=1000, format=input_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A15", value="Total Non-Current Assets", format=label_fmt()),
        *[
            CellValue(cell=f"{c}15", formula=f"=SUM({c}12:{c}14)", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A16", value="TOTAL ASSETS", format=label_fmt()),
        *[
            CellValue(cell=f"{c}16", formula=f"={c}10+{c}15", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # ── LIABILITIES ─────────────────────────────────────────────────
        CellValue(cell="A17", value="LIABILITIES", format=section_fmt()),
        CellValue(cell="A18", value="Current Liabilities", format=label_fmt()),
        CellValue(cell="A19", value="Accounts Payable", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}19", formula=f"='Working Cap'!{c}13", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(
            cell="A20", value="Current Portion of Long-Term Debt", format=label_fmt(indent=1)
        ),
        *[
            CellValue(
                cell=f"{c}20",
                formula="=NTBA!$B$13",
                format=xsheet_fmt(),
                comment="Annual repayment = current portion",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A21", value="Other Current Liabilities", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}21", value=800, format=input_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A22", value="Total Current Liabilities", format=label_fmt()),
        *[
            CellValue(cell=f"{c}22", formula=f"=SUM({c}19:{c}21)", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A23", value="Non-Current Liabilities", format=label_fmt()),
        CellValue(cell="A24", value="Long-Term Debt (Term Loan)", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}24",
                formula=f"=Debt!{c}8-NTBA!$B$13",
                format=xsheet_fmt(),
                comment="Closing debt less current portion",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A25", value="Other Non-Current Liabilities", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}25", value=500, format=input_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A26", value="Total Non-Current Liabilities", format=label_fmt()),
        *[
            CellValue(cell=f"{c}26", formula=f"=SUM({c}24:{c}25)", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A27", value="TOTAL LIABILITIES", format=label_fmt()),
        *[
            CellValue(cell=f"{c}27", formula=f"={c}22+{c}26", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # ── EQUITY ──────────────────────────────────────────────────────
        CellValue(cell="A28", value="SHAREHOLDERS' EQUITY", format=section_fmt()),
        CellValue(cell="A29", value="Total Equity", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}29", formula=f"=Equity!{c}8", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A30", value="TOTAL LIABILITIES + EQUITY", format=label_fmt()),
        *[
            CellValue(cell=f"{c}30", formula=f"={c}27+{c}29", format=total_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # Balance check row — must equal zero
        CellValue(
            cell="A31",
            value="Balance Check (Assets − L+E) — must be 0",
            format=CellFormat(
                font=CellFont(name="Arial", size=10, bold=True, color="FF0000"),
            ),
        ),
        *[
            CellValue(
                cell=f"{c}31",
                formula=f"={c}16-{c}30",
                format=CellFormat(
                    font=CellFont(name="Arial", size=10, bold=True, color="FF0000"),
                    number_format=ACCOUNTING,
                ),
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
    ],
    conditional_formats=[
        ConditionalRule(
            range_string="B31:J31",
            rule_type="cell_is",
            operator="notEqual",
            values=[0],
            format=CellFormat(
                font=CellFont(color=WHITE, bold=True),
                fill=CellFill(fg_color="FF0000"),
            ),
        ),
        ConditionalRule(
            range_string="B31:J31",
            rule_type="cell_is",
            operator="equal",
            values=[0],
            format=CellFormat(
                font=CellFont(color="375623", bold=True),
                fill=CellFill(fg_color="C6EFCE"),
            ),
        ),
    ],
)


# ===========================================================================
# 13. CASH FLOW STATEMENT (Indirect Method)
# ===========================================================================

cf_sheet = WorksheetSpec(
    name="Cash Flow",
    tab_color=NAVY,
    zoom=100,
    col_dimensions=COMMON_COLS,
    freeze_panes="F4",
    merges=[MergeRange(range="A1:J1"), MergeRange(range="A2:J2")],
    cells=[
        CellValue(
            cell="A1",
            value="APEX SOLUTIONS INC. — Cash Flow Statement (Indirect)",
            format=title_fmt(),
        ),
        CellValue(
            cell="A2",
            value="All figures in USD millions",
            format=CellFormat(
                font=CellFont(name="Arial", size=9, italic=True, color=DARK_GREY),
                alignment=CellAlignment(horizontal="center"),
            ),
        ),
        CellValue(cell="A3", value="($mm)", format=header_fmt(DARK_GREY, WHITE)),
        *year_headers(3),
        # Opening cash
        CellValue(cell="A4", value="Opening Cash", format=label_fmt()),
        CellValue(
            cell="B4", value=3000, format=input_fmt(), comment="Opening cash balance — Actuals 1"
        ),
        *[
            CellValue(cell=f"{c}4", formula=f"={p}19", format=xsheet_fmt())
            for c, p in zip(
                [*HIST_COLS[1:], *PROJ_COLS], [*HIST_COLS, *PROJ_COLS[:-1]], strict=False
            )
        ],
        # ── OPERATING ACTIVITIES ─────────────────────────────────────────
        CellValue(cell="A5", value="OPERATING ACTIVITIES", format=section_fmt()),
        CellValue(cell="A6", value="Profit After Tax (PAT)", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}6", formula=f"='Income Stmt'!{c}23", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(
            cell="A7", value="Add back: Depreciation & Amortisation", format=label_fmt(indent=1)
        ),
        *[
            CellValue(cell=f"{c}7", formula=f"=PPE!{c}14", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A8", value="Change in Accounts Receivable", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}8",
                formula=f"=-'Working Cap'!{c}6",
                format=formula_fmt(),
                comment="Increase in AR = use of cash (negative)",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A9", value="Change in Inventory", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}9", formula=f"=-'Working Cap'!{c}10", format=formula_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A10", value="Change in Accounts Payable", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}10",
                formula=f"='Working Cap'!{c}14",
                format=formula_fmt(),
                comment="Increase in AP = source of cash (positive)",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A11", value="Net Cash from Operating Activities", format=label_fmt()),
        *[
            CellValue(cell=f"{c}11", formula=f"=SUM({c}6:{c}10)", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # ── INVESTING ACTIVITIES ─────────────────────────────────────────
        CellValue(cell="A12", value="INVESTING ACTIVITIES", format=section_fmt()),
        CellValue(cell="A13", value="Capital Expenditures (CapEx)", format=label_fmt(indent=1)),
        *[
            CellValue(
                cell=f"{c}13",
                formula=f"=-TBA!{c}15",
                format=xsheet_fmt(),
                comment="CapEx is a cash outflow",
            )
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A14", value="Net Cash from Investing Activities", format=label_fmt()),
        *[
            CellValue(cell=f"{c}14", formula=f"={c}13", format=subtotal_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        # ── FINANCING ACTIVITIES ─────────────────────────────────────────
        CellValue(cell="A15", value="FINANCING ACTIVITIES", format=section_fmt()),
        CellValue(cell="A16", value="New Debt Drawdowns", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}16", formula=f"=Debt!{c}5", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A17", value="Debt Repayments", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}17", formula=f"=Debt!{c}6", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A18", value="Dividends Paid", format=label_fmt(indent=1)),
        *[
            CellValue(cell=f"{c}18", formula=f"=Equity!{c}6", format=xsheet_fmt())
            for c in [*HIST_COLS, *PROJ_COLS]
        ],
        CellValue(cell="A_18b", value=None, format=label_fmt()),  # placeholder; use row 18b below
        # Net financing
        CellValue(cell="A19", value="Net Cash from Financing Activities", format=label_fmt()),
        # Row 19 used for net financing subtotal; closing cash is row 20
    ],
)

# Rebuild CFS rows 19-20 correctly (net financing + closing cash)
cf_extra = [
    CellValue(cell=f"{c}19_net_fin", value=None, format=subtotal_fmt())
    for c in [*HIST_COLS, *PROJ_COLS]
]

# Override the last few cells cleanly
cf_sheet.cells = [
    c for c in (cf_sheet.cells or []) if "A_18b" not in c.cell and "19_net_fin" not in c.cell
]

cf_sheet.cells += [
    # Net financing
    *[
        CellValue(cell=f"{c}19", formula=f"=SUM({c}16:{c}18)", format=subtotal_fmt())
        for c in [*HIST_COLS, *PROJ_COLS]
    ],
    # Closing cash = opening + operating + investing + financing
    CellValue(cell="A20", value="NET CHANGE IN CASH", format=label_fmt()),
    *[
        CellValue(cell=f"{c}20", formula=f"={c}11+{c}14+{c}19", format=formula_fmt())
        for c in [*HIST_COLS, *PROJ_COLS]
    ],
    CellValue(cell="A21", value="Closing Cash & Equivalents", format=label_fmt()),
    *[
        CellValue(cell=f"{c}21", formula=f"={c}4+{c}20", format=total_fmt())
        for c in [*HIST_COLS, *PROJ_COLS]
    ],
    # CFS check: closing cash must equal BS cash
    CellValue(
        cell="A22",
        value="BS Cash Check (CFS − BS cash) — must be 0",
        format=CellFormat(
            font=CellFont(name="Arial", size=10, bold=True, color="FF0000"),
        ),
    ),
    *[
        CellValue(
            cell=f"{c}22",
            formula=f"={c}21-'Balance Sheet'!{c}6",
            format=CellFormat(
                font=CellFont(name="Arial", size=10, bold=True, color="FF0000"),
                number_format=ACCOUNTING,
            ),
        )
        for c in [*HIST_COLS, *PROJ_COLS]
    ],
]

# Patch Balance Sheet closing cash reference to row 21 of CFS
for cell in bs_sheet.cells or []:
    if cell.formula and "'Cash Flow'!" in cell.formula:
        for c in [*HIST_COLS, *PROJ_COLS]:
            cell.formula = cell.formula.replace(
                f"'Cash Flow'!{c}19",
                f"'Cash Flow'!{c}21",
            )

# Do this properly for all year columns
for cell in bs_sheet.cells or []:
    if cell.formula and "'Cash Flow'!" in cell.formula:
        for c in [*HIST_COLS, *PROJ_COLS]:
            cell.formula = cell.formula.replace(f"'Cash Flow'!{c}19", f"'Cash Flow'!{c}21")

# Debt average cash also pulls from CFS
for cell in debt_sheet.cells or []:
    if cell.formula and "'Cash Flow'!" in cell.formula:
        for c in [*HIST_COLS, *PROJ_COLS]:
            cell.formula = cell.formula.replace(f"'Cash Flow'!{c}4", f"'Cash Flow'!{c}4")
            # Keep opening cash for simplicity (opening of each year)


# ===========================================================================
# NAMED RANGES
# ===========================================================================

named_ranges = [
    NamedRange(name="Days_Per_Year", sheet="NTBA", range="$B$4"),
    NamedRange(name="DSO_Target", sheet="NTBA", range="$B$7"),
    NamedRange(name="DIO_Target", sheet="NTBA", range="$B$8"),
    NamedRange(name="DPO_Target", sheet="NTBA", range="$B$9"),
    NamedRange(name="Loan_Rate", sheet="NTBA", range="$B$11"),
    NamedRange(name="Deposit_Rate", sheet="NTBA", range="$B$12"),
    NamedRange(name="Debt_Repayment", sheet="NTBA", range="$B$13"),
    NamedRange(name="Debt_Drawdown", sheet="NTBA", range="$B$14"),
    NamedRange(name="Tax_Rate", sheet="NTBA", range="$B$16"),
    NamedRange(name="PPE_Useful_Life", sheet="NTBA", range="$B$18"),
    NamedRange(name="Dividend_Payout", sheet="NTBA", range="$B$20"),
]


# ===========================================================================
# WORKBOOK SPEC
# ===========================================================================

spec = WorkbookSpec(
    title="Apex_Solutions_Financial_Model",
    author="Capital Partners Equity Research",
    named_ranges=named_ranges,
    sheets=[
        cover_sheet,
        ntba_sheet,
        tba_sheet,
        revenue_sheet,
        cogs_sheet,
        opex_sheet,
        ppe_sheet,
        wc_sheet,
        debt_sheet,
        equity_sheet,
        is_sheet,
        bs_sheet,
        cf_sheet,
    ],
    metadata={
        "description": "Three-statement financial model for Apex Solutions Inc. — WallStreetMojo case study",
        "keywords": "financial model, three-statement, DCF, equity research",
    },
)


def test_generate_xlsx_creates_file() -> None:
    """Generate a workbook and validate core workbook features."""
    generator = WorkbookGenerator(spec=spec)

    output_file = generator.generate()

    assert output_file.exists()
    assert output_file.suffix == ".xlsx"
