# flywheel-engine 🔄

Compounding intelligence loop — Tile→Room→Inject→Compound cycle.

## Install

```bash
pip install flywheel-engine
```

## About

Part of the [Cocapn](https://github.com/cocapn) fleet. Implements the compounding intelligence cycle: tiles are ingested, organized into rooms, injected with context, and compounded into higher-order intelligence.

MIT License.