"""Flywheel Engine — momentum-based autonomous operation for fleet agents."""

__version__ = "0.2.0"
import time


class Flywheel:
    """Tracks operational momentum for autonomous fleet agents.
    
    Maintains a momentum score that increases with productive work
    and decays during idle periods. High momentum = keep going.
    Low momentum = consider pausing or switching tasks.
    """
    
    def __init__(self, boost: float = 1.0, decay_rate: float = 0.01, threshold: float = 0.5):
        self.momentum = 0.0
        self.boost = boost
        self.decay_rate = decay_rate
        self.threshold = threshold
        self.last_activity = time.time()
        self.tasks_completed = 0
        self.tasks_per_minute = 0.0
        self._history = []
    
    def tick(self, productive: bool = True):
        """Update momentum based on activity."""
        now = time.time()
        elapsed = now - self.last_activity
        self.last_activity = now
        
        if productive:
            self.momentum = min(1.0, self.momentum + self.boost)
            self.tasks_completed += 1
        else:
            self.momentum = max(0.0, self.momentum - self.decay_rate * elapsed)
        
        self._update_rate(elapsed)
    
    def _update_rate(self, elapsed: float):
        self._history.append(elapsed)
        if len(self._history) > 60:
            self._history.pop(0)
        if self._history:
            avg = sum(self._history) / len(self._history)
            self.tasks_per_minute = 60.0 / max(avg, 0.001)
    
    @property
    def should_continue(self) -> bool:
        """Whether the agent should keep working."""
        return self.momentum > self.threshold
    
    @property
    def status(self) -> str:
        if self.momentum > 0.8:
            return "full_speed"
        elif self.momentum > self.threshold:
            return "coasting"
        else:
            return "stalling"


class TaskQueue:
    """Priority queue for flywheel-driven task execution."""
    
    def __init__(self):
        self.tasks = []
    
    def add(self, task: str, priority: float = 0.5):
        self.tasks.append((priority, task))
        self.tasks.sort(key=lambda x: -x[0])
    
    def next(self) -> str:
        if self.tasks:
            _, task = self.tasks.pop(0)
            return task
        return ""
    
    @property
    def remaining(self) -> int:
        return len(self.tasks)
    
    def clear_completed(self, completed: list):
        self.tasks = [(p, t) for p, t in self.tasks if t not in completed]
