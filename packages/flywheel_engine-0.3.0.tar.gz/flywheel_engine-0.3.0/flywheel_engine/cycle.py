"""FlywheelCycle — the Tile→Room→Inject→Compound loop.

The core compounding intelligence cycle. Each iteration:
1. TILE: Extract knowledge from work
2. ROOM: Route tile to the right room
3. INJECT: Add tile to room's knowledge base
4. COMPOUND: Room's compound score increases, making future extraction faster
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Optional
import json
import urllib.request


@dataclass
class CycleResult:
    """Result of one flywheel cycle."""
    tile_id: str = ""
    room: str = ""
    accepted: bool = False
    compound_score: float = 0.0
    reason: str = ""
    metadata: dict = field(default_factory=dict)


class FlywheelCycle:
    """Execute the compounding intelligence loop.

    Usage:
        cycle = FlywheelCycle(plato_url="http://localhost:8847")
        result = cycle.run(
            agent="oracle1",
            room="architecture",
            question="What is X?",
            answer="X is Y.",
            confidence=0.9,
        )
        print(f"Accepted: {result.accepted}, Score: {result.compound_score}")
    """

    def __init__(
        self,
        plato_url: str = "http://localhost:8847",
        agent: str = "flywheel",
        on_submit: Optional[Callable[[CycleResult], None]] = None,
    ):
        self.plato_url = plato_url.rstrip("/")
        self.agent = agent
        self.on_submit = on_submit
        self.history: list[CycleResult] = []
        self.total_compound = 0.0

    def run(
        self,
        agent: str = "",
        room: str = "",
        domain: str = "",
        question: str = "",
        answer: str = "",
        confidence: float = 0.8,
        tags: list[str] | None = None,
    ) -> CycleResult:
        """Execute one Tile→Room→Inject→Compound cycle.

        Args:
            agent: Agent name (overrides default)
            room: PLATO room to submit to
            domain: Knowledge domain
            question: The question this tile answers
            answer: The answer/content
            confidence: Confidence score 0-1
            tags: Optional tags

        Returns:
            CycleResult with acceptance status and compound score
        """
        agent = agent or self.agent
        tags = tags or []

        # TILE: Package the knowledge
        tile = {
            "agent": agent,
            "room": room,
            "domain": domain,
            "question": question,
            "answer": answer,
            "confidence": confidence,
            "tags": tags,
        }

        # ROOM + INJECT: Submit to PLATO
        result = CycleResult(room=room, metadata=tile)
        try:
            req = urllib.request.Request(
                f"{self.plato_url}/submit",
                data=json.dumps(tile).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            resp = urllib.request.urlopen(req, timeout=10)
            data = json.loads(resp.read())
            result.accepted = data.get("status") == "accepted"
            result.tile_id = data.get("tile_id", "")
            result.reason = data.get("reason", "")

            # COMPOUND: Track compound score
            if result.accepted:
                result.compound_score = confidence * 0.1  # Compound grows with confidence
                self.total_compound += result.compound_score
        except Exception as e:
            result.reason = str(e)
            result.accepted = False

        # Track history
        self.history.append(result)

        # Callback
        if self.on_submit:
            self.on_submit(result)

        return result

    def run_batch(self, tiles: list[dict]) -> list[CycleResult]:
        """Run multiple tiles through the cycle."""
        return [self.run(**tile) for tile in tiles]

    @property
    def acceptance_rate(self) -> float:
        """Percentage of tiles accepted."""
        if not self.history:
            return 0.0
        accepted = sum(1 for r in self.history if r.accepted)
        return accepted / len(self.history)

    @property
    def compound_velocity(self) -> float:
        """Rate of compounding (compound per cycle)."""
        if not self.history:
            return 0.0
        return self.total_compound / len(self.history)

    def summary(self) -> dict:
        """Get flywheel summary stats."""
        return {
            "total_cycles": len(self.history),
            "accepted": sum(1 for r in self.history if r.accepted),
            "rejected": sum(1 for r in self.history if not r.accepted),
            "acceptance_rate": f"{self.acceptance_rate:.1%}",
            "total_compound": f"{self.total_compound:.2f}",
            "compound_velocity": f"{self.compound_velocity:.3f}",
        }
