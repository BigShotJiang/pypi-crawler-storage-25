"""Flywheel Engine — compounding intelligence loop.

The flywheel is Tile → Room → Inject → Compound.
Knowledge compounds like interest: each cycle makes the next cycle faster.
"""

from flywheel_engine.flywheel import Flywheel, TaskQueue
from flywheel_engine.cycle import FlywheelCycle, CycleResult
from flywheel_engine.compound import CompoundEngine

__version__ = "0.3.0"
__all__ = ["Flywheel", "TaskQueue", "FlywheelCycle", "CycleResult", "CompoundEngine"]
