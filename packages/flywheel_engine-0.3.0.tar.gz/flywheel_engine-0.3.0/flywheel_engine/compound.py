"""CompoundEngine — measure and optimize knowledge compounding.

Compounding is the key insight: knowledge grows exponentially,
not linearly. Each tile makes the next tile more valuable.
"""

from dataclasses import dataclass
from typing import Optional
import math


@dataclass
class CompoundScore:
    """A compound score for a room or agent."""
    room: str
    tiles: int
    avg_confidence: float
    compound_factor: float  # How much this room compounds
    velocity: float         # Growth rate

    @property
    def projected_value(self) -> float:
        """Projected value after N more cycles (compound interest formula)."""
        # V = P * (1 + r)^n where P=current value, r=compound_factor, n=cycles
        return self.tiles * (1 + self.compound_factor) ** 10


class CompoundEngine:
    """Calculate and optimize knowledge compounding across PLATO rooms.

    The compound formula: Score = tiles × avg_confidence × (1 + diversity)^0.5
    Diversity = unique tags / total tiles in room.

    Usage:
        engine = CompoundEngine()
        score = engine.score_room("architecture", tiles=83, avg_confidence=0.87, unique_tags=42)
        print(f"Compound factor: {score.compound_factor:.3f}")
        print(f"Projected value: {score.projected_value:.0f}")
    """

    def __init__(self, diversity_weight: float = 0.5, confidence_weight: float = 0.3, volume_weight: float = 0.2):
        self.diversity_weight = diversity_weight
        self.confidence_weight = confidence_weight
        self.volume_weight = volume_weight

    def score_room(
        self,
        room: str,
        tiles: int,
        avg_confidence: float,
        unique_tags: int = 0,
        recent_growth: int = 0,
    ) -> CompoundScore:
        """Calculate compound score for a PLATO room.

        Args:
            room: Room name
            tiles: Total tiles in room
            avg_confidence: Average confidence of tiles (0-1)
            unique_tags: Number of unique tags
            recent_growth: Tiles added in last 24h

        Returns:
            CompoundScore with metrics
        """
        # Diversity ratio: unique tags / tiles (capped at 1.0)
        diversity = min(unique_tags / max(tiles, 1), 1.0)

        # Compound factor: weighted combination
        compound_factor = (
            self.diversity_weight * diversity +
            self.confidence_weight * avg_confidence +
            self.volume_weight * min(math.log1p(tiles) / 10, 1.0)
        )

        # Velocity: recent growth rate
        velocity = recent_growth / max(tiles, 1)

        return CompoundScore(
            room=room,
            tiles=tiles,
            avg_confidence=avg_confidence,
            compound_factor=compound_factor,
            velocity=velocity,
        )

    def rank_rooms(self, rooms: list[dict]) -> list[CompoundScore]:
        """Rank rooms by compound score.

        Args:
            rooms: List of dicts with room, tiles, avg_confidence, unique_tags, recent_growth

        Returns:
            List of CompoundScore sorted by compound_factor (highest first)
        """
        scores = [
            self.score_room(
                room=r["room"],
                tiles=r.get("tiles", 0),
                avg_confidence=r.get("avg_confidence", 0.5),
                unique_tags=r.get("unique_tags", 0),
                recent_growth=r.get("recent_growth", 0),
            )
            for r in rooms
        ]
        return sorted(scores, key=lambda s: s.compound_factor, reverse=True)

    def compound_projection(self, current_tiles: int, compound_factor: float, cycles: int = 100) -> list[int]:
        """Project tile growth over N cycles.

        Returns list of projected tile counts at each cycle.
        """
        projections = []
        tiles = current_tiles
        for _ in range(cycles):
            growth = max(1, int(tiles * compound_factor * 0.01))  # 1% compound growth per cycle
            tiles += growth
            projections.append(tiles)
        return projections
