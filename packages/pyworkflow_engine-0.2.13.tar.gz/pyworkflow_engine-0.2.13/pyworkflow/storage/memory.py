"""
In-memory storage backend for testing and transient workflows.

This backend stores all data in memory and is ideal for:
- Unit testing
- Transient workflows that don't need persistence
- Development and prototyping
- Ephemeral containers

Note: All data is lost when the process exits.
"""

import threading
from datetime import UTC, datetime

from pyworkflow.engine.events import Event
from pyworkflow.storage.base import StorageBackend
from pyworkflow.storage.schemas import (
    Hook,
    HookStatus,
    RunStatus,
    Schedule,
    ScheduleStatus,
    StepExecution,
    WorkflowRun,
)


class InMemoryStorageBackend(StorageBackend):
    """
    Thread-safe in-memory storage backend.

    All data is stored in dictionaries and protected by a reentrant lock
    for thread safety.

    Example:
        >>> storage = InMemoryStorageBackend()
        >>> pyworkflow.configure(storage=storage)
    """

    def __init__(self) -> None:
        """Initialize empty storage."""
        self._runs: dict[str, WorkflowRun] = {}
        self._events: dict[str, list[Event]] = {}
        self._steps: dict[str, StepExecution] = {}
        self._hooks: dict[tuple[str, str], Hook] = {}  # (run_id, hook_id) -> Hook
        self._schedules: dict[str, Schedule] = {}
        self._idempotency_index: dict[str, str] = {}  # key -> run_id
        self._token_index: dict[str, tuple[str, str]] = {}  # token -> (run_id, hook_id)
        self._cancellation_flags: dict[str, bool] = {}  # run_id -> cancelled
        self._lock = threading.RLock()
        self._event_sequences: dict[str, int] = {}  # run_id -> next sequence

        # Stream storage
        self._streams: dict[str, dict] = {}  # stream_id -> stream data
        self._signals: dict[str, list[dict]] = {}  # stream_id -> list of signal dicts
        self._signal_sequences: dict[str, int] = {}  # stream_run_id -> next sequence
        self._subscriptions: dict[tuple[str, str], dict] = {}  # (stream_id, step_run_id) -> sub
        self._acknowledgments: set[tuple[str, str]] = set()  # (signal_id, step_run_id)
        self._checkpoints: dict[str, dict] = {}  # step_run_id -> checkpoint data

    # Workflow Run Operations

    async def create_run(self, run: WorkflowRun) -> None:
        """Create a new workflow run record."""
        with self._lock:
            if run.run_id in self._runs:
                raise ValueError(f"Run {run.run_id} already exists")
            self._runs[run.run_id] = run
            self._events[run.run_id] = []
            self._event_sequences[run.run_id] = 0
            if run.idempotency_key:
                self._idempotency_index[run.idempotency_key] = run.run_id

    async def get_run(self, run_id: str) -> WorkflowRun | None:
        """Retrieve a workflow run by ID."""
        with self._lock:
            return self._runs.get(run_id)

    async def get_run_by_idempotency_key(self, key: str) -> WorkflowRun | None:
        """Retrieve a workflow run by idempotency key."""
        with self._lock:
            run_id = self._idempotency_index.get(key)
            if run_id:
                return self._runs.get(run_id)
            return None

    async def update_run_status(
        self,
        run_id: str,
        status: RunStatus,
        result: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update workflow run status and optionally result/error."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.status = status
                run.updated_at = datetime.now(UTC)
                if result is not None:
                    run.result = result
                if error is not None:
                    run.error = error
                if status == RunStatus.COMPLETED or status == RunStatus.FAILED:
                    run.completed_at = datetime.now(UTC)

    async def update_run_recovery_attempts(
        self,
        run_id: str,
        recovery_attempts: int,
    ) -> None:
        """Update the recovery attempts counter for a workflow run."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.recovery_attempts = recovery_attempts
                run.updated_at = datetime.now(UTC)

    async def update_run_context(
        self,
        run_id: str,
        context: dict,
    ) -> None:
        """Update the step context for a workflow run."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.context = context
                run.updated_at = datetime.now(UTC)

    async def get_run_context(self, run_id: str) -> dict:
        """Get the current step context for a workflow run."""
        with self._lock:
            run = self._runs.get(run_id)
            return run.context if run else {}

    async def list_runs(
        self,
        query: str | None = None,
        status: RunStatus | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
        cursor: str | None = None,
    ) -> tuple[list[WorkflowRun], str | None]:
        """List workflow runs with optional filtering and cursor-based pagination."""
        import json

        with self._lock:
            runs = list(self._runs.values())

            # Filter by query (case-insensitive substring in workflow_name or input_kwargs)
            if query:
                query_lower = query.lower()
                filtered_runs = []
                for r in runs:
                    workflow_name_match = query_lower in r.workflow_name.lower()
                    input_kwargs_str = json.dumps(r.input_kwargs or {}).lower()
                    input_kwargs_match = query_lower in input_kwargs_str
                    if workflow_name_match or input_kwargs_match:
                        filtered_runs.append(r)
                runs = filtered_runs

            # Filter by status
            if status:
                runs = [r for r in runs if r.status == status]

            # Filter by time range (based on started_at)
            if start_time or end_time:
                filtered_runs = []
                for r in runs:
                    if r.started_at is None:
                        continue  # Skip runs that haven't started
                    if start_time and r.started_at < start_time:
                        continue
                    if end_time and r.started_at >= end_time:
                        continue
                    filtered_runs.append(r)
                runs = filtered_runs

            # Sort by (created_at DESC, run_id DESC) for deterministic ordering
            runs.sort(key=lambda r: (r.created_at, r.run_id), reverse=True)

            # Apply cursor-based pagination
            if cursor:
                cursor_found = False
                filtered_runs = []
                for run in runs:
                    if cursor_found:
                        filtered_runs.append(run)
                    elif run.run_id == cursor:
                        cursor_found = True
                runs = filtered_runs

            # Apply limit and determine next_cursor
            if len(runs) > limit:
                result_runs = runs[:limit]
                next_cursor = result_runs[-1].run_id if result_runs else None
            else:
                result_runs = runs[:limit]
                next_cursor = None

            return result_runs, next_cursor

    # Event Log Operations

    async def record_event(self, event: Event) -> None:
        """Record an event to the append-only event log."""
        with self._lock:
            run_id = event.run_id
            if run_id not in self._events:
                self._events[run_id] = []
                self._event_sequences[run_id] = 0

            # Assign sequence number
            event.sequence = self._event_sequences[run_id]
            self._event_sequences[run_id] += 1

            self._events[run_id].append(event)

    async def get_events(
        self,
        run_id: str,
        event_types: list[str] | None = None,
    ) -> list[Event]:
        """Retrieve all events for a workflow run, ordered by sequence."""
        with self._lock:
            events = list(self._events.get(run_id, []))

            # Filter by event types
            if event_types:
                events = [e for e in events if e.type in event_types]

            # Sort by sequence
            events.sort(key=lambda e: e.sequence or 0)

            return events

    async def get_latest_event(
        self,
        run_id: str,
        event_type: str | None = None,
    ) -> Event | None:
        """Get the latest event for a run, optionally filtered by type."""
        with self._lock:
            events = self._events.get(run_id, [])
            if not events:
                return None

            # Filter by event type
            if event_type:
                events = [e for e in events if e.type.value == event_type]

            if not events:
                return None

            # Return event with highest sequence
            return max(events, key=lambda e: e.sequence or 0)

    async def has_event(
        self,
        run_id: str,
        event_type: str,
        **filters: str,
    ) -> bool:
        """
        Check if an event exists by loading events of the specific type and filtering.

        This approach:
        1. Uses the event_types filter to load only events of the target type
        2. Filters in Python on the loaded data
        3. Significantly reduces memory vs loading ALL events

        Args:
            run_id: Workflow run identifier
            event_type: Event type to check for
            **filters: Additional filters for event data fields

        Returns:
            True if a matching event exists, False otherwise
        """
        # Load only events of the specific type
        events = await self.get_events(run_id, event_types=[event_type])

        # Filter in Python
        for event in events:
            match = True
            for key, value in filters.items():
                if str(event.data.get(key)) != str(value):
                    match = False
                    break
            if match:
                return True

        return False

    # Step Operations

    async def create_step(self, step: StepExecution) -> None:
        """Create a step execution record."""
        with self._lock:
            self._steps[step.step_id] = step

    async def get_step(self, step_id: str) -> StepExecution | None:
        """Retrieve a step execution by ID."""
        with self._lock:
            return self._steps.get(step_id)

    async def update_step_status(
        self,
        step_id: str,
        status: str,
        result: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update step execution status."""
        with self._lock:
            step = self._steps.get(step_id)
            if step:
                from pyworkflow.storage.schemas import StepStatus

                step.status = StepStatus(status)
                step.updated_at = datetime.now(UTC)
                if result is not None:
                    step.result = result
                if error is not None:
                    step.error = error

    async def list_steps(self, run_id: str) -> list[StepExecution]:
        """List all steps for a workflow run."""
        with self._lock:
            return [s for s in self._steps.values() if s.run_id == run_id]

    # Hook Operations

    async def create_hook(self, hook: Hook) -> None:
        """Create a hook record."""
        with self._lock:
            key = (hook.run_id, hook.hook_id)
            self._hooks[key] = hook
            self._token_index[hook.token] = key

    async def get_hook(self, hook_id: str, run_id: str | None = None) -> Hook | None:
        """Retrieve a hook by ID (requires run_id for composite key lookup)."""
        with self._lock:
            if run_id:
                return self._hooks.get((run_id, hook_id))
            else:
                # Fallback: find any hook with this ID (may return wrong one if duplicates)
                for (_r_id, h_id), hook in self._hooks.items():
                    if h_id == hook_id:
                        return hook
                return None

    async def get_hook_by_token(self, token: str) -> Hook | None:
        """Retrieve a hook by its token."""
        with self._lock:
            key = self._token_index.get(token)
            if key:
                return self._hooks.get(key)
            return None

    async def update_hook_status(
        self,
        hook_id: str,
        status: HookStatus,
        payload: str | None = None,
        run_id: str | None = None,
    ) -> None:
        """Update hook status and optionally payload."""
        with self._lock:
            if run_id:
                hook = self._hooks.get((run_id, hook_id))
            else:
                # Fallback: find any hook with this ID
                hook = None
                for (_r_id, h_id), h in self._hooks.items():
                    if h_id == hook_id:
                        hook = h
                        break
            if hook:
                hook.status = status
                if payload is not None:
                    hook.payload = payload
                if status == HookStatus.RECEIVED:
                    hook.received_at = datetime.now(UTC)

    async def list_hooks(
        self,
        run_id: str | None = None,
        status: HookStatus | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Hook]:
        """List hooks with optional filtering."""
        with self._lock:
            hooks = list(self._hooks.values())

            # Filter by run_id
            if run_id:
                hooks = [h for h in hooks if h.run_id == run_id]

            # Filter by status
            if status:
                hooks = [h for h in hooks if h.status == status]

            # Sort by created_at descending
            hooks.sort(key=lambda h: h.created_at, reverse=True)

            # Apply pagination
            return hooks[offset : offset + limit]

    # Atomic Status Transition

    async def try_claim_run(
        self, run_id: str, from_status: RunStatus, to_status: RunStatus
    ) -> bool:
        """Atomically transition run status using lock-protected check-and-set."""
        with self._lock:
            run = self._runs.get(run_id)
            if not run or run.status != from_status:
                return False
            run.status = to_status
            run.updated_at = datetime.now(UTC)
            return True

    # Cancellation Flag Operations

    async def set_cancellation_flag(self, run_id: str) -> None:
        """Set a cancellation flag for a workflow run."""
        with self._lock:
            self._cancellation_flags[run_id] = True

    async def check_cancellation_flag(self, run_id: str) -> bool:
        """Check if a cancellation flag is set for a workflow run."""
        with self._lock:
            return self._cancellation_flags.get(run_id, False)

    async def clear_cancellation_flag(self, run_id: str) -> None:
        """Clear the cancellation flag for a workflow run."""
        with self._lock:
            self._cancellation_flags.pop(run_id, None)

    # Continue-As-New Chain Operations

    async def update_run_continuation(
        self,
        run_id: str,
        continued_to_run_id: str,
    ) -> None:
        """Update the continuation link for a workflow run."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.continued_to_run_id = continued_to_run_id
                run.updated_at = datetime.now(UTC)

    async def get_workflow_chain(
        self,
        run_id: str,
    ) -> list[WorkflowRun]:
        """Get all runs in a continue-as-new chain."""
        with self._lock:
            run = self._runs.get(run_id)
            if not run:
                return []

            # Walk backwards to find the start of the chain
            current = run
            while current.continued_from_run_id:
                prev = self._runs.get(current.continued_from_run_id)
                if not prev:
                    break
                current = prev

            # Build chain from start to end
            chain = [current]
            while current.continued_to_run_id:
                next_run = self._runs.get(current.continued_to_run_id)
                if not next_run:
                    break
                chain.append(next_run)
                current = next_run

            return chain

    # Child Workflow Operations

    async def get_children(
        self,
        parent_run_id: str,
        status: RunStatus | None = None,
    ) -> list[WorkflowRun]:
        """Get all child workflow runs for a parent workflow."""
        with self._lock:
            children = [run for run in self._runs.values() if run.parent_run_id == parent_run_id]

            if status:
                children = [c for c in children if c.status == status]

            # Sort by created_at
            children.sort(key=lambda r: r.created_at)

            return children

    async def get_parent(self, run_id: str) -> WorkflowRun | None:
        """Get the parent workflow run for a child workflow."""
        with self._lock:
            run = self._runs.get(run_id)
            if run and run.parent_run_id:
                return self._runs.get(run.parent_run_id)
            return None

    async def get_nesting_depth(self, run_id: str) -> int:
        """Get the nesting depth for a workflow."""
        with self._lock:
            run = self._runs.get(run_id)
            return run.nesting_depth if run else 0

    # Schedule Operations

    async def create_schedule(self, schedule: Schedule) -> None:
        """Create a new schedule record."""
        with self._lock:
            if schedule.schedule_id in self._schedules:
                raise ValueError(f"Schedule {schedule.schedule_id} already exists")
            self._schedules[schedule.schedule_id] = schedule

    async def get_schedule(self, schedule_id: str) -> Schedule | None:
        """Retrieve a schedule by ID."""
        with self._lock:
            return self._schedules.get(schedule_id)

    async def update_schedule(self, schedule: Schedule) -> None:
        """Update an existing schedule."""
        with self._lock:
            if schedule.schedule_id not in self._schedules:
                raise ValueError(f"Schedule {schedule.schedule_id} does not exist")
            self._schedules[schedule.schedule_id] = schedule

    async def delete_schedule(self, schedule_id: str) -> None:
        """Mark a schedule as deleted (soft delete)."""
        with self._lock:
            if schedule_id not in self._schedules:
                raise ValueError(f"Schedule {schedule_id} does not exist")
            schedule = self._schedules[schedule_id]
            schedule.status = ScheduleStatus.DELETED
            schedule.updated_at = datetime.now(UTC)

    async def list_schedules(
        self,
        workflow_name: str | None = None,
        status: ScheduleStatus | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Schedule]:
        """List schedules with optional filtering."""
        with self._lock:
            schedules = list(self._schedules.values())

            # Apply filters
            if workflow_name:
                schedules = [s for s in schedules if s.workflow_name == workflow_name]
            if status:
                schedules = [s for s in schedules if s.status == status]

            # Sort by created_at descending
            schedules.sort(key=lambda s: s.created_at, reverse=True)

            # Apply pagination
            return schedules[offset : offset + limit]

    async def get_due_schedules(self, now: datetime) -> list[Schedule]:
        """Get all schedules that are due to run."""
        with self._lock:
            due_schedules = [
                s
                for s in self._schedules.values()
                if s.status == ScheduleStatus.ACTIVE
                and s.next_run_time is not None
                and s.next_run_time <= now
            ]

            # Sort by next_run_time ascending
            due_schedules.sort(key=lambda s: s.next_run_time)  # type: ignore
            return due_schedules

    async def add_running_run(self, schedule_id: str, run_id: str) -> None:
        """Add a run_id to the schedule's running_run_ids list."""
        with self._lock:
            if schedule_id not in self._schedules:
                raise ValueError(f"Schedule {schedule_id} does not exist")
            schedule = self._schedules[schedule_id]
            if run_id not in schedule.running_run_ids:
                schedule.running_run_ids.append(run_id)
                schedule.updated_at = datetime.now(UTC)

    async def remove_running_run(self, schedule_id: str, run_id: str) -> None:
        """Remove a run_id from the schedule's running_run_ids list."""
        with self._lock:
            if schedule_id not in self._schedules:
                raise ValueError(f"Schedule {schedule_id} does not exist")
            schedule = self._schedules[schedule_id]
            if run_id in schedule.running_run_ids:
                schedule.running_run_ids.remove(run_id)
                schedule.updated_at = datetime.now(UTC)

    async def delete_old_runs(self, older_than: datetime) -> int:
        """Delete terminal runs updated before older_than."""
        terminal = {
            RunStatus.COMPLETED,
            RunStatus.FAILED,
            RunStatus.CANCELLED,
            RunStatus.CONTINUED_AS_NEW,
            RunStatus.INTERRUPTED,
        }
        cutoff_iso = older_than.isoformat()
        with self._lock:
            to_delete = [
                run_id
                for run_id, run in self._runs.items()
                if run.status in terminal and run.updated_at < older_than
            ]
            for run_id in to_delete:
                run = self._runs.pop(run_id)
                self._events.pop(run_id, None)
                self._event_sequences.pop(run_id, None)
                if run.idempotency_key:
                    self._idempotency_index.pop(run.idempotency_key, None)
                step_ids = [sid for sid, s in self._steps.items() if s.run_id == run_id]
                for sid in step_ids:
                    self._checkpoints.pop(sid, None)
                    del self._steps[sid]
                hook_keys = [k for k in self._hooks if k[0] == run_id]
                for k in hook_keys:
                    hook = self._hooks.pop(k)
                    self._token_index.pop(hook.token, None)
                self._cancellation_flags.pop(run_id, None)

            # --- Stream / schedule cleanup ---
            # Purge old signals
            for stream_id in list(self._signals):
                self._signals[stream_id] = [
                    s for s in self._signals[stream_id] if s.get("published_at", "") >= cutoff_iso
                ]

            # Purge delivered scheduled signals
            if hasattr(self, "_scheduled_signals"):
                to_remove = [
                    sid for sid, row in self._scheduled_signals.items() if row["delivered"]
                ]
                for sid in to_remove:
                    del self._scheduled_signals[sid]

            # Purge terminal subscriptions
            sub_to_remove = [
                key
                for key, sub in self._subscriptions.items()
                if sub["status"] in ("terminated", "completed")
                and sub.get("created_at", "") < cutoff_iso
            ]
            for key in sub_to_remove:
                del self._subscriptions[key]

            # Purge acknowledgments for signals that no longer exist
            existing_signal_ids = set()
            for sigs in self._signals.values():
                for s in sigs:
                    existing_signal_ids.add(s["signal_id"])
            self._acknowledgments = {
                (sig_id, step_id)
                for sig_id, step_id in self._acknowledgments
                if sig_id in existing_signal_ids
            }

            # Purge soft-deleted schedules
            sched_to_remove = [
                sid
                for sid, sched in self._schedules.items()
                if sched.status == ScheduleStatus.DELETED
                and sched.updated_at is not None
                and sched.updated_at < older_than
            ]
            for sid in sched_to_remove:
                del self._schedules[sid]

            return len(to_delete)

    # Stream Operations

    async def create_stream(self, stream_id: str, metadata: dict | None = None) -> None:
        """Create a new stream."""
        with self._lock:
            if stream_id in self._streams:
                raise ValueError(f"Stream {stream_id} already exists")
            self._streams[stream_id] = {
                "stream_id": stream_id,
                "status": "active",
                "created_at": datetime.now(UTC).isoformat(),
                "metadata": metadata or {},
            }
            self._signals[stream_id] = []

    async def get_stream(self, stream_id: str) -> dict | None:
        """Get a stream by ID."""
        with self._lock:
            return self._streams.get(stream_id)

    async def publish_signal(
        self,
        signal_id: str,
        stream_id: str,
        signal_type: str,
        payload: dict,
        source_run_id: str | None = None,
        stream_run_id: str | None = None,
        metadata: dict | None = None,
    ) -> int:
        """Publish a signal to a stream."""
        with self._lock:
            if stream_id not in self._signals:
                self._signals[stream_id] = []

            # Sequence scoped per stream_run_id
            run_key = stream_run_id or stream_id
            if run_key not in self._signal_sequences:
                self._signal_sequences[run_key] = 0

            seq = self._signal_sequences[run_key]
            self._signal_sequences[run_key] += 1

            signal_data = {
                "signal_id": signal_id,
                "stream_id": stream_id,
                "signal_type": signal_type,
                "payload": payload,
                "published_at": datetime.now(UTC).isoformat(),
                "sequence": seq,
                "source_run_id": source_run_id,
                "stream_run_id": stream_run_id,
                "metadata": metadata or {},
            }
            self._signals[stream_id].append(signal_data)
            return seq

    async def get_signals(
        self,
        stream_id: str,
        after_sequence: int = 0,
        limit: int = 100,
    ) -> list[dict]:
        """Get signals from a stream after a given sequence number."""
        with self._lock:
            signals = self._signals.get(stream_id, [])
            filtered = [s for s in signals if (s.get("sequence", 0)) >= after_sequence]
            filtered.sort(key=lambda s: s.get("sequence", 0))
            return filtered[:limit]

    async def query_stream_signals(
        self,
        stream_id: str,
        stream_run_id: str,
        *,
        source_run_id: str | None = None,
        signal_type: str | None = None,
        after_sequence: int | None = None,
        before_sequence: int | None = None,
        last_n: int | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Query signals from a stream with rich filtering."""
        with self._lock:
            signals = list(self._signals.get(stream_id, []))

        # Apply filters
        filtered = [s for s in signals if s.get("stream_run_id") == stream_run_id]
        if source_run_id is not None:
            filtered = [s for s in filtered if s.get("source_run_id") == source_run_id]
        if signal_type is not None:
            filtered = [s for s in filtered if s.get("signal_type") == signal_type]
        if last_n is None:
            if after_sequence is not None:
                filtered = [s for s in filtered if s.get("sequence", 0) >= after_sequence]
            if before_sequence is not None:
                filtered = [s for s in filtered if s.get("sequence", 0) <= before_sequence]

        filtered.sort(key=lambda s: s.get("sequence", 0))

        if last_n is not None:
            return filtered[-min(last_n, 200) :]
        return filtered[: min(limit, 200)]

    async def register_stream_subscription(
        self,
        stream_id: str,
        step_run_id: str,
        signal_types: list[str],
        stream_run_id: str | None = None,
    ) -> None:
        """Register a stream step's subscription to signal types."""
        with self._lock:
            key = (stream_id, step_run_id)
            self._subscriptions[key] = {
                "stream_id": stream_id,
                "step_run_id": step_run_id,
                "signal_types": signal_types,
                "status": "waiting",
                "stream_run_id": stream_run_id,
                "created_at": datetime.now(UTC).isoformat(),
            }

    async def get_subscription_states(
        self,
        stream_id: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Return all subscriptions and their statuses for a stream run."""
        with self._lock:
            result = []
            for (sid, _), sub in self._subscriptions.items():
                if sid != stream_id:
                    continue
                if stream_run_id is not None and sub.get("stream_run_id") not in (
                    stream_run_id,
                    None,
                ):
                    continue
                result.append(
                    {
                        "stream_id": sub["stream_id"],
                        "step_run_id": sub["step_run_id"],
                        "status": sub["status"],
                        "stream_run_id": sub.get("stream_run_id"),
                    }
                )
            return result

    async def schedule_signal(
        self,
        *,
        stream_id: str,
        signal_type: str,
        payload: dict,
        due_at: datetime,
        stream_run_id: str | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Persist a signal to be emitted at ``due_at``."""
        import uuid as _uuid

        with self._lock:
            if not hasattr(self, "_scheduled_signals"):
                self._scheduled_signals: dict[str, dict] = {}
            sched_id = f"sched_{_uuid.uuid4().hex[:16]}"
            self._scheduled_signals[sched_id] = {
                "id": sched_id,
                "stream_id": stream_id,
                "signal_type": signal_type,
                "payload": payload,
                "due_at": due_at,
                "stream_run_id": stream_run_id,
                "metadata": metadata or {},
                "delivered": False,
            }
            return sched_id

    async def fetch_due_scheduled_signals(
        self,
        now: datetime,
        limit: int = 100,
    ) -> list[dict]:
        """Return scheduled signals whose ``due_at <= now`` and not delivered."""
        with self._lock:
            if not hasattr(self, "_scheduled_signals"):
                return []
            due = []
            for row in self._scheduled_signals.values():
                if row["delivered"]:
                    continue
                if row["due_at"] <= now:
                    due.append(dict(row))
                    if len(due) >= limit:
                        break
            return due

    async def mark_scheduled_signal_delivered(self, sched_id: str) -> None:
        with self._lock:
            if not hasattr(self, "_scheduled_signals"):
                return
            row = self._scheduled_signals.get(sched_id)
            if row:
                row["delivered"] = True

    async def get_waiting_steps(
        self,
        stream_id: str,
        signal_type: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Get step_run_ids waiting for a specific signal type on a stream."""
        with self._lock:
            result = []
            for (sid, _), sub in self._subscriptions.items():
                if sid != stream_id:
                    continue
                if sub["status"] not in ("waiting", "suspended"):
                    continue
                if signal_type not in sub["signal_types"]:
                    continue
                if stream_run_id is not None and sub.get("stream_run_id") not in (
                    stream_run_id,
                    None,
                ):
                    continue
                result.append(sub)
            return result

    async def get_subscriptions_for_stream(
        self,
        stream_id: str,
        signal_type: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Get ALL subscriptions for a signal type, regardless of status."""
        with self._lock:
            result = []
            for (sid, _), sub in self._subscriptions.items():
                if sid != stream_id:
                    continue
                if signal_type not in sub["signal_types"]:
                    continue
                if stream_run_id is not None and sub.get("stream_run_id") not in (
                    stream_run_id,
                    None,
                ):
                    continue
                result.append(sub)
            return result

    async def update_subscription_status(
        self,
        stream_id: str,
        step_run_id: str,
        status: str,
    ) -> None:
        """Update a subscription's status."""
        with self._lock:
            key = (stream_id, step_run_id)
            if key in self._subscriptions:
                self._subscriptions[key]["status"] = status

    async def acknowledge_signal(
        self,
        signal_id: str,
        step_run_id: str,
    ) -> None:
        """Acknowledge that a signal has been processed by a step."""
        with self._lock:
            self._acknowledgments.add((signal_id, step_run_id))

    async def get_pending_signals(
        self,
        stream_id: str,
        step_run_id: str,
    ) -> list[dict]:
        """Get signals that arrived for a step but haven't been acknowledged."""
        with self._lock:
            sub = self._subscriptions.get((stream_id, step_run_id))
            if not sub:
                return []

            signals = self._signals.get(stream_id, [])
            pending = []
            for sig in signals:
                if sig["signal_type"] in sub["signal_types"]:
                    if (sig["signal_id"], step_run_id) not in self._acknowledgments:
                        pending.append(sig)
            pending.sort(key=lambda s: s.get("sequence", 0))
            return pending

    async def save_checkpoint(self, step_run_id: str, data: dict) -> None:
        """Save checkpoint data for a stream step."""
        with self._lock:
            self._checkpoints[step_run_id] = data

    async def load_checkpoint(self, step_run_id: str) -> dict | None:
        """Load checkpoint data for a stream step."""
        with self._lock:
            return self._checkpoints.get(step_run_id)

    async def delete_checkpoint(self, step_run_id: str) -> None:
        """Delete checkpoint data for a stream step."""
        with self._lock:
            self._checkpoints.pop(step_run_id, None)

    # Utility methods

    def clear(self) -> None:
        """
        Clear all data from storage.

        Useful for testing to reset state between tests.
        """
        with self._lock:
            self._runs.clear()
            self._events.clear()
            self._steps.clear()
            self._hooks.clear()
            self._schedules.clear()
            self._idempotency_index.clear()
            self._token_index.clear()
            self._cancellation_flags.clear()
            self._event_sequences.clear()
            self._streams.clear()
            self._signals.clear()
            self._signal_sequences.clear()
            self._subscriptions.clear()
            self._acknowledgments.clear()
            self._checkpoints.clear()

    def __len__(self) -> int:
        """Return total number of workflow runs."""
        with self._lock:
            return len(self._runs)

    def __repr__(self) -> str:
        """Return string representation."""
        with self._lock:
            return (
                f"InMemoryStorageBackend("
                f"runs={len(self._runs)}, "
                f"events={sum(len(e) for e in self._events.values())}, "
                f"steps={len(self._steps)}, "
                f"hooks={len(self._hooks)}, "
                f"schedules={len(self._schedules)})"
            )
