"""
File-based storage backend using JSON files.

This backend stores workflow data in local JSON files, suitable for:
- Development and testing
- Single-machine deployments
- Low-volume production use

Data is stored in a directory structure:
    base_path/
        runs/
            {run_id}.json
        events/
            {run_id}.jsonl  (append-only)
        steps/
            {step_id}.json
        hooks/
            {hook_id}.json
        schedules/
            {schedule_id}.json
        _token_index.json  (token -> hook_id mapping)
"""

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path

from filelock import FileLock

from pyworkflow.engine.events import Event, EventType
from pyworkflow.storage.base import StorageBackend
from pyworkflow.storage.schemas import (
    Hook,
    HookStatus,
    RunStatus,
    Schedule,
    ScheduleStatus,
    StepExecution,
    WorkflowRun,
)


class FileStorageBackend(StorageBackend):
    """
    File-based storage backend using JSON files.

    Thread-safe using file locks for concurrent access.
    """

    def __init__(self, base_path: str = "./pyworkflow_data"):
        """
        Initialize file storage backend.

        Args:
            base_path: Base directory for storing workflow data
        """
        self.base_path = Path(base_path)
        self.runs_dir = self.base_path / "runs"
        self.events_dir = self.base_path / "events"
        self.steps_dir = self.base_path / "steps"
        self.hooks_dir = self.base_path / "hooks"
        self.schedules_dir = self.base_path / "schedules"
        self.checkpoints_dir = self.base_path / "checkpoints"
        self.locks_dir = self.base_path / ".locks"
        self._token_index_file = self.base_path / "_token_index.json"
        self.streams_dir = self.base_path / "streams"
        self.signals_dir = self.base_path / "signals"
        self.subscriptions_dir = self.base_path / "subscriptions"
        self.acknowledgments_dir = self.base_path / "acknowledgments"

        # Create directories
        for dir_path in [
            self.runs_dir,
            self.events_dir,
            self.steps_dir,
            self.hooks_dir,
            self.schedules_dir,
            self.checkpoints_dir,
            self.locks_dir,
            self.streams_dir,
            self.signals_dir,
            self.subscriptions_dir,
            self.acknowledgments_dir,
        ]:
            dir_path.mkdir(parents=True, exist_ok=True)

    # Workflow Run Operations

    async def create_run(self, run: WorkflowRun) -> None:
        """Create a new workflow run record."""
        run_file = self.runs_dir / f"{run.run_id}.json"

        if run_file.exists():
            raise ValueError(f"Workflow run {run.run_id} already exists")

        data = run.to_dict()

        # Use file lock for thread safety
        lock_file = self.locks_dir / f"{run.run_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                run_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_write)

    async def get_run(self, run_id: str) -> WorkflowRun | None:
        """Retrieve a workflow run by ID."""
        run_file = self.runs_dir / f"{run_id}.json"

        if not run_file.exists():
            return None

        lock_file = self.locks_dir / f"{run_id}.lock"
        lock = FileLock(str(lock_file))

        def _read() -> dict | None:
            with lock:
                if not run_file.exists():
                    return None
                content = run_file.read_text()
                if not content.strip():
                    # File exists but is empty (race condition) - treat as not found
                    return None
                return json.loads(content)

        data = await asyncio.to_thread(_read)
        return WorkflowRun.from_dict(data) if data else None

    async def get_run_by_idempotency_key(self, key: str) -> WorkflowRun | None:
        """Retrieve a workflow run by idempotency key."""

        def _search() -> dict | None:
            for run_file in self.runs_dir.glob("*.json"):
                data = json.loads(run_file.read_text())
                if data.get("idempotency_key") == key:
                    return data
            return None

        data = await asyncio.to_thread(_search)
        return WorkflowRun.from_dict(data) if data else None

    async def update_run_status(
        self,
        run_id: str,
        status: RunStatus,
        result: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update workflow run status."""
        run_file = self.runs_dir / f"{run_id}.json"

        if not run_file.exists():
            raise ValueError(f"Workflow run {run_id} not found")

        lock_file = self.locks_dir / f"{run_id}.lock"
        lock = FileLock(str(lock_file))

        def _update() -> None:
            with lock:
                data = json.loads(run_file.read_text())
                data["status"] = status.value
                data["updated_at"] = datetime.now(UTC).isoformat()

                if result is not None:
                    data["result"] = result

                if error is not None:
                    data["error"] = error

                if status == RunStatus.COMPLETED:
                    data["completed_at"] = datetime.now(UTC).isoformat()

                run_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_update)

    async def update_run_recovery_attempts(
        self,
        run_id: str,
        recovery_attempts: int,
    ) -> None:
        """Update the recovery attempts counter for a workflow run."""
        run_file = self.runs_dir / f"{run_id}.json"

        if not run_file.exists():
            raise ValueError(f"Workflow run {run_id} not found")

        lock_file = self.locks_dir / f"{run_id}.lock"
        lock = FileLock(str(lock_file))

        def _update() -> None:
            with lock:
                data = json.loads(run_file.read_text())
                data["recovery_attempts"] = recovery_attempts
                data["updated_at"] = datetime.now(UTC).isoformat()
                run_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_update)

    async def update_run_context(
        self,
        run_id: str,
        context: dict,
    ) -> None:
        """Update the step context for a workflow run."""
        run_file = self.runs_dir / f"{run_id}.json"

        if not run_file.exists():
            raise ValueError(f"Workflow run {run_id} not found")

        lock_file = self.locks_dir / f"{run_id}.lock"
        lock = FileLock(str(lock_file))

        def _update() -> None:
            with lock:
                data = json.loads(run_file.read_text())
                data["context"] = context
                data["updated_at"] = datetime.now(UTC).isoformat()
                run_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_update)

    async def get_run_context(self, run_id: str) -> dict:
        """Get the current step context for a workflow run."""
        run = await self.get_run(run_id)
        return run.context if run else {}

    async def list_runs(
        self,
        query: str | None = None,
        status: RunStatus | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
        cursor: str | None = None,
    ) -> tuple[list[WorkflowRun], str | None]:
        """List workflow runs with optional filtering and cursor-based pagination."""

        def _list() -> tuple[list[dict], str | None]:
            runs = []
            query_lower = query.lower() if query else None

            for run_file in self.runs_dir.glob("*.json"):
                data = json.loads(run_file.read_text())

                # Apply query filter (case-insensitive substring in workflow_name or input_kwargs)
                if query_lower:
                    workflow_name = data.get("workflow_name", "").lower()
                    input_kwargs = json.dumps(data.get("input_kwargs", {})).lower()
                    if query_lower not in workflow_name and query_lower not in input_kwargs:
                        continue

                # Apply status filter
                if status and data.get("status") != status.value:
                    continue

                # Apply time filters (based on started_at)
                started_at_str = data.get("started_at")
                if started_at_str:
                    started_at = datetime.fromisoformat(started_at_str)
                    # Make timezone-aware comparison if needed
                    if start_time and started_at < start_time:
                        continue
                    if end_time and started_at >= end_time:
                        continue
                elif start_time or end_time:
                    # If run hasn't started yet and we have time filters, skip it
                    continue

                runs.append(data)

            # Sort by (created_at DESC, run_id DESC) for deterministic ordering
            runs.sort(key=lambda r: (r.get("created_at", ""), r.get("run_id", "")), reverse=True)

            # Apply cursor-based pagination
            if cursor:
                # Find the cursor position and start after it
                cursor_found = False
                filtered_runs = []
                for run in runs:
                    if cursor_found:
                        filtered_runs.append(run)
                    elif run.get("run_id") == cursor:
                        cursor_found = True
                runs = filtered_runs

            # Apply limit and determine next_cursor
            if len(runs) > limit:
                result_runs = runs[:limit]
                next_cursor = result_runs[-1].get("run_id") if result_runs else None
            else:
                result_runs = runs[:limit]
                next_cursor = None

            return result_runs, next_cursor

        run_data_list, next_cursor = await asyncio.to_thread(_list)
        return [WorkflowRun.from_dict(data) for data in run_data_list], next_cursor

    # Event Log Operations

    async def record_event(self, event: Event) -> None:
        """Record an event to the append-only event log."""
        events_file = self.events_dir / f"{event.run_id}.jsonl"
        lock_file = self.locks_dir / f"events_{event.run_id}.lock"
        lock = FileLock(str(lock_file))

        def _append() -> None:
            with lock:
                # Get next sequence number
                sequence = 1
                if events_file.exists():
                    with events_file.open("r") as f:
                        for line in f:
                            if line.strip():
                                sequence += 1

                event.sequence = sequence

                # Append event
                event_data = {
                    "event_id": event.event_id,
                    "run_id": event.run_id,
                    "type": event.type.value,
                    "sequence": event.sequence,
                    "timestamp": event.timestamp.isoformat(),
                    "data": event.data,
                }

                with events_file.open("a") as f:
                    f.write(json.dumps(event_data) + "\n")

        await asyncio.to_thread(_append)

    async def get_events(
        self,
        run_id: str,
        event_types: list[str] | None = None,
    ) -> list[Event]:
        """Retrieve all events for a workflow run."""
        events_file = self.events_dir / f"{run_id}.jsonl"

        if not events_file.exists():
            return []

        def _read() -> list[Event]:
            events = []
            with events_file.open("r") as f:
                for line in f:
                    if not line.strip():
                        continue

                    data = json.loads(line)

                    # Apply type filter
                    if event_types and data["type"] not in event_types:
                        continue

                    events.append(
                        Event(
                            event_id=data["event_id"],
                            run_id=data["run_id"],
                            type=EventType(data["type"]),
                            sequence=data["sequence"],
                            timestamp=datetime.fromisoformat(data["timestamp"]),
                            data=data["data"],
                        )
                    )

            return sorted(events, key=lambda e: e.sequence or 0)

        return await asyncio.to_thread(_read)

    async def get_latest_event(
        self,
        run_id: str,
        event_type: str | None = None,
    ) -> Event | None:
        """Get the latest event for a run."""
        events = await self.get_events(run_id, event_types=[event_type] if event_type else None)
        return events[-1] if events else None

    async def has_event(
        self,
        run_id: str,
        event_type: str,
        **filters: str,
    ) -> bool:
        """
        Check if an event exists using file-based iteration with early termination.

        Reads the events file line by line and returns as soon as a match is found,
        avoiding loading the entire event log into memory.

        Args:
            run_id: Workflow run identifier
            event_type: Event type to check for
            **filters: Additional filters for event data fields

        Returns:
            True if a matching event exists, False otherwise
        """
        events_file = self.events_dir / f"{run_id}.jsonl"

        if not events_file.exists():
            return False

        def _check() -> bool:
            with events_file.open("r") as f:
                for line in f:
                    if not line.strip():
                        continue

                    data = json.loads(line)

                    # Check event type
                    if data["type"] != event_type:
                        continue

                    # Check all data filters
                    match = True
                    event_data = data.get("data", {})
                    for key, value in filters.items():
                        if str(event_data.get(key)) != str(value):
                            match = False
                            break

                    if match:
                        return True

            return False

        return await asyncio.to_thread(_check)

    # Step Operations

    async def create_step(self, step: StepExecution) -> None:
        """Create a step execution record."""
        step_file = self.steps_dir / f"{step.step_id}.json"

        if step_file.exists():
            raise ValueError(f"Step {step.step_id} already exists")

        data = step.to_dict()

        def _write() -> None:
            step_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_write)

    async def get_step(self, step_id: str) -> StepExecution | None:
        """Retrieve a step execution by ID."""
        step_file = self.steps_dir / f"{step_id}.json"

        if not step_file.exists():
            return None

        def _read() -> dict:
            return json.loads(step_file.read_text())

        data = await asyncio.to_thread(_read)
        return StepExecution.from_dict(data)

    async def update_step_status(
        self,
        step_id: str,
        status: str,
        result: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update step execution status."""
        step_file = self.steps_dir / f"{step_id}.json"

        if not step_file.exists():
            raise ValueError(f"Step {step_id} not found")

        def _update() -> None:
            data = json.loads(step_file.read_text())
            data["status"] = status
            data["updated_at"] = datetime.utcnow().isoformat()

            if result is not None:
                data["result"] = result

            if error is not None:
                data["error"] = error

            if status == "completed":
                data["completed_at"] = datetime.utcnow().isoformat()

            step_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_update)

    async def list_steps(self, run_id: str) -> list[StepExecution]:
        """List all steps for a workflow run."""

        def _list() -> list[dict]:
            steps = []
            for step_file in self.steps_dir.glob("*.json"):
                data = json.loads(step_file.read_text())
                if data.get("run_id") == run_id:
                    steps.append(data)

            # Sort by created_at
            steps.sort(key=lambda s: s.get("created_at", ""))
            return steps

        step_data_list = await asyncio.to_thread(_list)
        return [StepExecution.from_dict(data) for data in step_data_list]

    # Hook Operations

    def _load_token_index(self) -> dict:
        """Load the token -> hook_id index."""
        if self._token_index_file.exists():
            return json.loads(self._token_index_file.read_text())
        return {}

    def _save_token_index(self, index: dict) -> None:
        """Save the token -> hook_id index."""
        self._token_index_file.write_text(json.dumps(index, indent=2))

    async def create_hook(self, hook: Hook) -> None:
        """Create a hook record."""
        # Use composite filename: run_id__hook_id.json (double underscore separator)
        hook_file = self.hooks_dir / f"{hook.run_id}__{hook.hook_id}.json"
        lock_file = self.locks_dir / "token_index.lock"
        lock = FileLock(str(lock_file))

        data = hook.to_dict()

        def _write() -> None:
            with lock:
                hook_file.write_text(json.dumps(data, indent=2))
                # Update token index (stores run_id:hook_id as value)
                index = self._load_token_index()
                index[hook.token] = f"{hook.run_id}:{hook.hook_id}"
                self._save_token_index(index)

        await asyncio.to_thread(_write)

    async def get_hook(self, hook_id: str, run_id: str | None = None) -> Hook | None:
        """Retrieve a hook by ID (requires run_id for composite filename)."""
        if run_id:
            hook_file = self.hooks_dir / f"{run_id}__{hook_id}.json"
        else:
            # Fallback: try old format for backwards compat
            hook_file = self.hooks_dir / f"{hook_id}.json"
            if not hook_file.exists():
                # Search for any file with this hook_id
                for f in self.hooks_dir.glob(f"*__{hook_id}.json"):
                    hook_file = f
                    break

        if not hook_file.exists():
            return None

        def _read() -> dict:
            return json.loads(hook_file.read_text())

        data = await asyncio.to_thread(_read)
        return Hook.from_dict(data)

    async def get_hook_by_token(self, token: str) -> Hook | None:
        """Retrieve a hook by its token."""

        def _lookup() -> tuple[str, str] | None:
            index = self._load_token_index()
            value = index.get(token)
            if value and ":" in value:
                parts = value.split(":", 1)
                return (parts[0], parts[1])
            return None

        result = await asyncio.to_thread(_lookup)
        if result:
            run_id, hook_id = result
            return await self.get_hook(hook_id, run_id)
        return None

    async def update_hook_status(
        self,
        hook_id: str,
        status: HookStatus,
        payload: str | None = None,
        run_id: str | None = None,
    ) -> None:
        """Update hook status and optionally payload."""
        if run_id:
            hook_file = self.hooks_dir / f"{run_id}__{hook_id}.json"
        else:
            # Fallback: try old format
            hook_file = self.hooks_dir / f"{hook_id}.json"
            if not hook_file.exists():
                # Search for any file with this hook_id
                for f in self.hooks_dir.glob(f"*__{hook_id}.json"):
                    hook_file = f
                    break

        if not hook_file.exists():
            raise ValueError(f"Hook {hook_id} not found")

        safe_hook_id = hook_id.replace("/", "_").replace(":", "_")
        lock_file = self.locks_dir / f"hook_{safe_hook_id}.lock"
        lock = FileLock(str(lock_file))

        def _update() -> None:
            with lock:
                data = json.loads(hook_file.read_text())
                data["status"] = status.value

                if payload is not None:
                    data["payload"] = payload

                if status == HookStatus.RECEIVED:
                    data["received_at"] = datetime.now(UTC).isoformat()

                hook_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_update)

    async def list_hooks(
        self,
        run_id: str | None = None,
        status: HookStatus | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Hook]:
        """List hooks with optional filtering."""

        def _list() -> list[dict]:
            hooks = []
            for hook_file in self.hooks_dir.glob("*.json"):
                data = json.loads(hook_file.read_text())

                # Apply filters
                if run_id and data.get("run_id") != run_id:
                    continue
                if status and data.get("status") != status.value:
                    continue

                hooks.append(data)

            # Sort by created_at descending
            hooks.sort(key=lambda h: h.get("created_at", ""), reverse=True)

            # Apply pagination
            return hooks[offset : offset + limit]

        hook_data_list = await asyncio.to_thread(_list)
        return [Hook.from_dict(data) for data in hook_data_list]

    # Atomic Status Transition

    async def try_claim_run(
        self, run_id: str, from_status: RunStatus, to_status: RunStatus
    ) -> bool:
        """Atomically transition run status using file lock."""
        run_file = self.runs_dir / f"{run_id}.json"

        if not run_file.exists():
            return False

        lock_file = self.locks_dir / f"{run_id}.lock"
        lock = FileLock(str(lock_file))

        def _try_claim() -> bool:
            with lock:
                if not run_file.exists():
                    return False
                data = json.loads(run_file.read_text())
                if data.get("status") != from_status.value:
                    return False
                data["status"] = to_status.value
                data["updated_at"] = datetime.now(UTC).isoformat()
                run_file.write_text(json.dumps(data, indent=2))
                return True

        return await asyncio.to_thread(_try_claim)

    # Cancellation Flag Operations

    async def set_cancellation_flag(self, run_id: str) -> None:
        """Set a cancellation flag for a workflow run."""
        cancel_file = self.runs_dir / f"{run_id}.cancel"
        lock_file = self.locks_dir / f"{run_id}_cancel.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                cancel_file.write_text(datetime.now(UTC).isoformat())

        await asyncio.to_thread(_write)

    async def check_cancellation_flag(self, run_id: str) -> bool:
        """Check if a cancellation flag is set for a workflow run."""
        cancel_file = self.runs_dir / f"{run_id}.cancel"

        def _check() -> bool:
            return cancel_file.exists()

        return await asyncio.to_thread(_check)

    async def clear_cancellation_flag(self, run_id: str) -> None:
        """Clear the cancellation flag for a workflow run."""
        cancel_file = self.runs_dir / f"{run_id}.cancel"
        lock_file = self.locks_dir / f"{run_id}_cancel.lock"
        lock = FileLock(str(lock_file))

        def _clear() -> None:
            with lock:
                if cancel_file.exists():
                    cancel_file.unlink()

        await asyncio.to_thread(_clear)

    # Continue-As-New Chain Operations

    async def update_run_continuation(
        self,
        run_id: str,
        continued_to_run_id: str,
    ) -> None:
        """Update the continuation link for a workflow run."""
        run_file = self.runs_dir / f"{run_id}.json"

        if not run_file.exists():
            raise ValueError(f"Workflow run {run_id} not found")

        lock_file = self.locks_dir / f"{run_id}.lock"
        lock = FileLock(str(lock_file))

        def _update() -> None:
            with lock:
                data = json.loads(run_file.read_text())
                data["continued_to_run_id"] = continued_to_run_id
                data["updated_at"] = datetime.now(UTC).isoformat()
                run_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_update)

    async def get_workflow_chain(
        self,
        run_id: str,
    ) -> list[WorkflowRun]:
        """Get all runs in a continue-as-new chain."""
        run = await self.get_run(run_id)
        if not run:
            return []

        # Walk backwards to find the start of the chain
        current = run
        while current.continued_from_run_id:
            prev = await self.get_run(current.continued_from_run_id)
            if not prev:
                break
            current = prev

        # Build chain from start to end
        chain = [current]
        while current.continued_to_run_id:
            next_run = await self.get_run(current.continued_to_run_id)
            if not next_run:
                break
            chain.append(next_run)
            current = next_run

        return chain

    # Child Workflow Operations

    async def get_children(
        self,
        parent_run_id: str,
        status: RunStatus | None = None,
    ) -> list[WorkflowRun]:
        """Get all child workflow runs for a parent workflow."""

        def _list() -> list[dict]:
            children = []
            for run_file in self.runs_dir.glob("*.json"):
                data = json.loads(run_file.read_text())

                # Filter by parent_run_id
                if data.get("parent_run_id") != parent_run_id:
                    continue

                # Filter by status if provided
                if status and data.get("status") != status.value:
                    continue

                children.append(data)

            # Sort by created_at
            children.sort(key=lambda r: r.get("created_at", ""))
            return children

        child_data_list = await asyncio.to_thread(_list)
        return [WorkflowRun.from_dict(data) for data in child_data_list]

    async def get_parent(self, run_id: str) -> WorkflowRun | None:
        """Get the parent workflow run for a child workflow."""
        run = await self.get_run(run_id)
        if run and run.parent_run_id:
            return await self.get_run(run.parent_run_id)
        return None

    async def get_nesting_depth(self, run_id: str) -> int:
        """Get the nesting depth for a workflow."""
        run = await self.get_run(run_id)
        return run.nesting_depth if run else 0

    # Schedule Operations

    async def create_schedule(self, schedule: Schedule) -> None:
        """Create a new schedule record."""
        schedule_file = self.schedules_dir / f"{schedule.schedule_id}.json"

        if schedule_file.exists():
            raise ValueError(f"Schedule {schedule.schedule_id} already exists")

        data = schedule.to_dict()

        lock_file = self.locks_dir / f"schedule_{schedule.schedule_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                schedule_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_write)

    async def get_schedule(self, schedule_id: str) -> Schedule | None:
        """Retrieve a schedule by ID."""
        schedule_file = self.schedules_dir / f"{schedule_id}.json"

        if not schedule_file.exists():
            return None

        lock_file = self.locks_dir / f"schedule_{schedule_id}.lock"
        lock = FileLock(str(lock_file))

        def _read() -> dict | None:
            with lock:
                if not schedule_file.exists():
                    return None
                return json.loads(schedule_file.read_text())

        data = await asyncio.to_thread(_read)
        return Schedule.from_dict(data) if data else None

    async def update_schedule(self, schedule: Schedule) -> None:
        """Update an existing schedule."""
        schedule_file = self.schedules_dir / f"{schedule.schedule_id}.json"

        if not schedule_file.exists():
            raise ValueError(f"Schedule {schedule.schedule_id} does not exist")

        data = schedule.to_dict()

        lock_file = self.locks_dir / f"schedule_{schedule.schedule_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                schedule_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_write)

    async def delete_schedule(self, schedule_id: str) -> None:
        """Mark a schedule as deleted (soft delete)."""
        schedule = await self.get_schedule(schedule_id)

        if not schedule:
            raise ValueError(f"Schedule {schedule_id} does not exist")

        schedule.status = ScheduleStatus.DELETED
        schedule.updated_at = datetime.now(UTC)
        await self.update_schedule(schedule)

    async def list_schedules(
        self,
        workflow_name: str | None = None,
        status: ScheduleStatus | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Schedule]:
        """List schedules with optional filtering."""

        def _list() -> list[dict]:
            schedules = []
            for schedule_file in self.schedules_dir.glob("*.json"):
                try:
                    data = json.loads(schedule_file.read_text())

                    # Apply filters
                    if workflow_name and data.get("workflow_name") != workflow_name:
                        continue
                    if status and data.get("status") != status.value:
                        continue

                    schedules.append(data)
                except (json.JSONDecodeError, KeyError):
                    continue

            # Sort by created_at descending
            schedules.sort(key=lambda x: x.get("created_at", ""), reverse=True)

            # Apply pagination
            return schedules[offset : offset + limit]

        schedule_data_list = await asyncio.to_thread(_list)
        return [Schedule.from_dict(data) for data in schedule_data_list]

    async def get_due_schedules(self, now: datetime) -> list[Schedule]:
        """Get all schedules that are due to run."""
        now_iso = now.isoformat()

        def _list_due() -> list[dict]:
            due_schedules = []
            for schedule_file in self.schedules_dir.glob("*.json"):
                try:
                    data = json.loads(schedule_file.read_text())

                    # Check criteria
                    if data.get("status") != ScheduleStatus.ACTIVE.value:
                        continue
                    next_run = data.get("next_run_time")
                    if not next_run:
                        continue
                    if next_run > now_iso:
                        continue

                    due_schedules.append(data)
                except (json.JSONDecodeError, KeyError):
                    continue

            # Sort by next_run_time ascending
            due_schedules.sort(key=lambda x: x.get("next_run_time", ""))
            return due_schedules

        schedule_data_list = await asyncio.to_thread(_list_due)
        return [Schedule.from_dict(data) for data in schedule_data_list]

    async def add_running_run(self, schedule_id: str, run_id: str) -> None:
        """Add a run_id to the schedule's running_run_ids list."""
        schedule = await self.get_schedule(schedule_id)

        if not schedule:
            raise ValueError(f"Schedule {schedule_id} does not exist")

        if run_id not in schedule.running_run_ids:
            schedule.running_run_ids.append(run_id)
            schedule.updated_at = datetime.now(UTC)
            await self.update_schedule(schedule)

    async def remove_running_run(self, schedule_id: str, run_id: str) -> None:
        """Remove a run_id from the schedule's running_run_ids list."""
        schedule = await self.get_schedule(schedule_id)

        if not schedule:
            raise ValueError(f"Schedule {schedule_id} does not exist")

        if run_id in schedule.running_run_ids:
            schedule.running_run_ids.remove(run_id)
            schedule.updated_at = datetime.now(UTC)
            await self.update_schedule(schedule)

    async def delete_old_runs(self, older_than: datetime) -> int:
        """Delete terminal runs (and all related files) updated before older_than."""
        terminal = {"completed", "failed", "cancelled", "continued_as_new", "interrupted"}
        cutoff_iso = older_than.isoformat()

        def _sync_delete() -> int:
            count = 0
            for run_file in list(self.runs_dir.glob("*.json")):
                try:
                    data = json.loads(run_file.read_text())
                    if data.get("status") not in terminal:
                        continue
                    updated_at = datetime.fromisoformat(data["updated_at"])
                    if updated_at >= older_than:
                        continue
                    run_id = data["run_id"]
                    # Delete run file
                    run_file.unlink(missing_ok=True)
                    # Delete events file
                    (self.events_dir / f"{run_id}.jsonl").unlink(missing_ok=True)
                    # Delete step files belonging to this run
                    for sf in list(self.steps_dir.glob("*.json")):
                        try:
                            sd = json.loads(sf.read_text())
                            if sd.get("run_id") == run_id:
                                # Also delete checkpoint for this step
                                (self.checkpoints_dir / f"{sd['step_id']}.json").unlink(
                                    missing_ok=True
                                )
                                sf.unlink(missing_ok=True)
                        except Exception:
                            pass
                    # Delete hook files for this run
                    for hf in list(self.hooks_dir.glob(f"{run_id}__*.json")):
                        hf.unlink(missing_ok=True)
                    count += 1
                except Exception:
                    continue

            # --- Stream / schedule cleanup ---
            # Prune old signals from each stream's signal file
            for sig_file in list(self.signals_dir.glob("*.json")):
                try:
                    signals = json.loads(sig_file.read_text())
                    kept = [s for s in signals if s.get("published_at", "") >= cutoff_iso]
                    if len(kept) < len(signals):
                        sig_file.write_text(json.dumps(kept, indent=2))
                except Exception:
                    pass

            # Delete old terminal subscriptions
            for sub_file in list(self.subscriptions_dir.glob("*.json")):
                try:
                    sub = json.loads(sub_file.read_text())
                    if sub.get("status") in ("terminated", "completed"):
                        if sub.get("created_at", "") < cutoff_iso:
                            sub_file.unlink(missing_ok=True)
                except Exception:
                    pass

            # Delete old acknowledgments
            for ack_file in list(self.acknowledgments_dir.glob("*.json")):
                try:
                    ack = json.loads(ack_file.read_text())
                    if ack.get("acknowledged_at", "") < cutoff_iso:
                        ack_file.unlink(missing_ok=True)
                except Exception:
                    pass

            # Purge soft-deleted schedules
            for sched_file in list(self.schedules_dir.glob("*.json")):
                try:
                    sched = json.loads(sched_file.read_text())
                    if sched.get("status") == "DELETED":
                        deleted_at = sched.get("deleted_at") or sched.get("updated_at", "")
                        if deleted_at and deleted_at < cutoff_iso:
                            sched_file.unlink(missing_ok=True)
                except Exception:
                    pass

            return count

        return await asyncio.to_thread(_sync_delete)

    # Checkpoint Operations

    async def save_checkpoint(self, step_run_id: str, data: dict) -> None:
        """Save checkpoint data for a step execution."""
        checkpoint_file = self.checkpoints_dir / f"{step_run_id}.json"
        lock_file = self.locks_dir / f"checkpoint_{step_run_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                checkpoint_file.write_text(json.dumps(data, indent=2))

        await asyncio.to_thread(_write)

    async def load_checkpoint(self, step_run_id: str) -> dict | None:
        """Load checkpoint data for a step execution."""
        checkpoint_file = self.checkpoints_dir / f"{step_run_id}.json"

        if not checkpoint_file.exists():
            return None

        lock_file = self.locks_dir / f"checkpoint_{step_run_id}.lock"
        lock = FileLock(str(lock_file))

        def _read() -> dict | None:
            with lock:
                if not checkpoint_file.exists():
                    return None
                content = checkpoint_file.read_text()
                if not content.strip():
                    return None
                return json.loads(content)

        return await asyncio.to_thread(_read)

    async def delete_checkpoint(self, step_run_id: str) -> None:
        """Delete checkpoint data for a step execution."""
        checkpoint_file = self.checkpoints_dir / f"{step_run_id}.json"
        lock_file = self.locks_dir / f"checkpoint_{step_run_id}.lock"
        lock = FileLock(str(lock_file))

        def _delete() -> None:
            with lock:
                if checkpoint_file.exists():
                    checkpoint_file.unlink()

        await asyncio.to_thread(_delete)

    # Stream Operations

    async def create_stream(self, stream_id: str, metadata: dict | None = None) -> None:
        """Create a new stream."""
        stream_file = self.streams_dir / f"{stream_id}.json"
        lock_file = self.locks_dir / f"stream_{stream_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                if stream_file.exists():
                    raise ValueError(f"Stream {stream_id} already exists")
                stream_data = {
                    "stream_id": stream_id,
                    "status": "active",
                    "created_at": datetime.now(UTC).isoformat(),
                    "metadata": metadata or {},
                }
                stream_file.write_text(json.dumps(stream_data, indent=2))

        await asyncio.to_thread(_write)

    async def get_stream(self, stream_id: str) -> dict | None:
        """Get a stream by ID."""
        stream_file = self.streams_dir / f"{stream_id}.json"

        if not stream_file.exists():
            return None

        lock_file = self.locks_dir / f"stream_{stream_id}.lock"
        lock = FileLock(str(lock_file))

        def _read() -> dict | None:
            with lock:
                if not stream_file.exists():
                    return None
                content = stream_file.read_text()
                if not content.strip():
                    return None
                return json.loads(content)

        return await asyncio.to_thread(_read)

    async def publish_signal(
        self,
        signal_id: str,
        stream_id: str,
        signal_type: str,
        payload: dict,
        source_run_id: str | None = None,
        stream_run_id: str | None = None,
        metadata: dict | None = None,
    ) -> int:
        """Publish a signal to a stream."""
        lock_file = self.locks_dir / f"signals_{stream_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> int:
            with lock:
                # Read existing signals for this stream to get next sequence
                signals_file = self.signals_dir / f"{stream_id}.json"
                signals = []
                if signals_file.exists():
                    content = signals_file.read_text()
                    if content.strip():
                        signals = json.loads(content)

                # Sequence scoped per stream_run_id
                run_key = stream_run_id
                seq = (
                    max(
                        (
                            s.get("sequence", -1)
                            for s in signals
                            if s.get("stream_run_id", "") == run_key
                        ),
                        default=-1,
                    )
                    + 1
                )

                signal_data = {
                    "signal_id": signal_id,
                    "stream_id": stream_id,
                    "signal_type": signal_type,
                    "payload": payload,
                    "published_at": datetime.now(UTC).isoformat(),
                    "sequence": seq,
                    "source_run_id": source_run_id,
                    "stream_run_id": stream_run_id,
                    "metadata": metadata or {},
                }
                signals.append(signal_data)
                signals_file.write_text(json.dumps(signals, indent=2))
                return seq

        return await asyncio.to_thread(_write)

    async def get_signals(
        self,
        stream_id: str,
        after_sequence: int = 0,
        limit: int = 100,
    ) -> list[dict]:
        """Get signals from a stream after a given sequence number."""
        signals_file = self.signals_dir / f"{stream_id}.json"

        if not signals_file.exists():
            return []

        lock_file = self.locks_dir / f"signals_{stream_id}.lock"
        lock = FileLock(str(lock_file))

        def _read() -> list[dict]:
            with lock:
                if not signals_file.exists():
                    return []
                content = signals_file.read_text()
                if not content.strip():
                    return []
                signals = json.loads(content)
                filtered = [s for s in signals if s.get("sequence", 0) >= after_sequence]
                filtered.sort(key=lambda s: s.get("sequence", 0))
                return filtered[:limit]

        return await asyncio.to_thread(_read)

    async def register_stream_subscription(
        self,
        stream_id: str,
        step_run_id: str,
        signal_types: list[str],
        stream_run_id: str | None = None,
    ) -> None:
        """Register a stream step's subscription to signal types."""
        sub_file = self.subscriptions_dir / f"{stream_id}__{step_run_id}.json"
        lock_file = self.locks_dir / f"sub_{stream_id}_{step_run_id}.lock"
        lock = FileLock(str(lock_file))

        def _write() -> None:
            with lock:
                sub_data = {
                    "stream_id": stream_id,
                    "step_run_id": step_run_id,
                    "signal_types": signal_types,
                    "status": "waiting",
                    "created_at": datetime.now(UTC).isoformat(),
                }
                sub_file.write_text(json.dumps(sub_data, indent=2))

        await asyncio.to_thread(_write)

    async def get_waiting_steps(
        self,
        stream_id: str,
        signal_type: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Get step_run_ids waiting for a specific signal type on a stream."""

        def _read() -> list[dict]:
            result = []
            for sub_file in self.subscriptions_dir.glob(f"{stream_id}__*.json"):
                content = sub_file.read_text()
                if not content.strip():
                    continue
                sub = json.loads(content)
                if sub.get("status") == "waiting" and signal_type in sub.get("signal_types", []):
                    result.append(sub)
            return result

        return await asyncio.to_thread(_read)

    async def update_subscription_status(
        self,
        stream_id: str,
        step_run_id: str,
        status: str,
    ) -> None:
        """Update a subscription's status."""
        sub_file = self.subscriptions_dir / f"{stream_id}__{step_run_id}.json"
        lock_file = self.locks_dir / f"sub_{stream_id}_{step_run_id}.lock"
        lock = FileLock(str(lock_file))

        def _update() -> None:
            with lock:
                if not sub_file.exists():
                    return
                content = sub_file.read_text()
                if not content.strip():
                    return
                sub = json.loads(content)
                sub["status"] = status
                sub_file.write_text(json.dumps(sub, indent=2))

        await asyncio.to_thread(_update)

    async def acknowledge_signal(
        self,
        signal_id: str,
        step_run_id: str,
    ) -> None:
        """Acknowledge that a signal has been processed by a step."""
        ack_file = self.acknowledgments_dir / f"{signal_id}__{step_run_id}.json"

        def _write() -> None:
            ack_data = {
                "signal_id": signal_id,
                "step_run_id": step_run_id,
                "acknowledged_at": datetime.now(UTC).isoformat(),
            }
            ack_file.write_text(json.dumps(ack_data, indent=2))

        await asyncio.to_thread(_write)

    async def get_pending_signals(
        self,
        stream_id: str,
        step_run_id: str,
    ) -> list[dict]:
        """Get signals that arrived for a step but haven't been acknowledged."""

        def _read() -> list[dict]:
            # Get subscription
            sub_file = self.subscriptions_dir / f"{stream_id}__{step_run_id}.json"
            if not sub_file.exists():
                return []

            content = sub_file.read_text()
            if not content.strip():
                return []
            sub = json.loads(content)
            signal_types = sub.get("signal_types", [])
            if not signal_types:
                return []

            # Get all signals for stream
            signals_file = self.signals_dir / f"{stream_id}.json"
            if not signals_file.exists():
                return []

            sig_content = signals_file.read_text()
            if not sig_content.strip():
                return []
            signals = json.loads(sig_content)

            # Filter by type and check acknowledgments
            pending = []
            for sig in signals:
                if sig.get("signal_type") not in signal_types:
                    continue
                ack_file = self.acknowledgments_dir / f"{sig['signal_id']}__{step_run_id}.json"
                if not ack_file.exists():
                    pending.append(sig)

            pending.sort(key=lambda s: s.get("sequence", 0))
            return pending

        return await asyncio.to_thread(_read)
