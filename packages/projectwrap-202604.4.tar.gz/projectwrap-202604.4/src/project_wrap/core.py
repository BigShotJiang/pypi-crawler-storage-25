"""Core functionality for project-wrap."""

from __future__ import annotations

import os
import shlex
import subprocess
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .deps import require_dep
from .validate import (
    check_config_permissions,
    tiocsti_vulnerable,
    validate_config,
    validate_project_name,
    validate_shell,
)
from .vault import VaultConfig


@dataclass
class ProjectExec:
    """Everything needed to exec into a project environment."""

    display_name: str
    program: str
    argv: list[str]
    is_sandboxed: bool = False
    verbose_info: str | None = None
    vault_config: VaultConfig | None = None


_DOCKER_SOCKET_CANDIDATES = [
    "/run/docker.sock",
    "/var/run/docker.sock",
    "~/.docker/desktop/docker-cli.sock",
    "~/.docker/run/docker.sock",
]


def get_config_dir() -> Path:
    """Get the project configuration directory."""
    # Support XDG, fall back to ~/.config
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        base = Path(xdg_config)
    else:
        base = Path.home() / ".config"
    return base / "pwrap"


def expand_path(path: str) -> Path:
    """Expand ~ and environment variables in path."""
    return Path(os.path.expandvars(os.path.expanduser(path)))



def load_config(name: str) -> dict[str, Any]:
    """Load project configuration."""
    validate_project_name(name)
    config_dir = get_config_dir()
    project_path = config_dir / name

    if not project_path.is_dir():
        raise SystemExit(f"Unknown project: {name}")

    config_file = project_path / "project.toml"
    if not config_file.exists():
        raise SystemExit(f"Missing config: {config_file}")

    check_config_permissions(config_file)

    with open(config_file, "rb") as f:
        config: dict[str, Any] = tomllib.load(f)

    validate_config(config)
    config["_config_dir"] = project_path
    return config



def build_bwrap_args(
    sandbox: dict[str, Any],
    project_dir: Path,
    init_script: Path | None = None,
    ro_bind_extra: list[Path] | None = None,
    rw_bind_extra: list[Path] | None = None,
) -> list[str]:
    """Build bubblewrap command arguments.

    Args:
        sandbox: Sandbox configuration dict
        project_dir: Project working directory
        init_script: Optional init script to bind-mount read-only into sandbox
        ro_bind_extra: Additional paths to bind-mount read-only
        rw_bind_extra: Additional paths to bind-mount read-write (e.g. encrypted mountpoint)

    Returns:
        List of bwrap arguments
    """
    args = [
        "bwrap",
        # Base filesystem (read-only root, read-only home, writable project dir)
        "--ro-bind",
        "/",
        "/",
        "--dev",
        "/dev",
        "--proc",
        "/proc",
        "--tmpfs",
        "/tmp",
        "--ro-bind",
        str(Path.home()),
        str(Path.home()),
        # Hardening
        "--die-with-parent",
        "--unshare-ipc",
    ]

    # Isolate XDG runtime dir (D-Bus, Wayland, SSH/GPG agent sockets)
    uid = os.getuid()
    args.extend(["--tmpfs", f"/run/user/{uid}"])

    # Mask docker sockets — connect() works on ro-bound sockets, so any
    # accessible socket is a sandbox escape to root if docker is running.
    # Cover the common locations; add others via writable to override.
    for sock in _DOCKER_SOCKET_CANDIDATES:
        sock_path = expand_path(sock)
        if os.path.lexists(str(sock_path)):
            args.extend(["--ro-bind", "/dev/null", str(sock_path)])

    # Always blacklist the config directory (prevents reading other project configs
    # or modifying sandbox rules from inside the sandbox)
    config_dir_resolved = get_config_dir().resolve()
    if config_dir_resolved.exists():
        args.extend(["--tmpfs", str(config_dir_resolved)])

    # Validate blacklist and writable up front so the user sees every missing
    # path in one error, rather than one-per-run. Whitelist is "exception to
    # blacklist" and silently skips missing entries by design.
    missing: list[tuple[str, Path]] = []
    blacklist_expanded: list[Path] = []
    for path in sandbox.get("blacklist", []):
        p = expand_path(path)
        if not p.exists():
            missing.append(("blacklist", p))
        else:
            blacklist_expanded.append(p)
    writable_expanded: list[Path] = []
    for path in sandbox.get("writable", []):
        p = expand_path(path)
        if not p.exists():
            missing.append(("writable", p))
        else:
            writable_expanded.append(p)
    if missing:
        lines = "\n".join(f"  [{kind}] {p}" for kind, p in missing)
        raise SystemExit(
            f"Config references paths that do not exist on this host:\n{lines}\n"
            f"Fix your config (comment out the missing entries or adjust the paths)."
        )

    # Blacklist paths by overlaying with tmpfs (dirs) or /dev/null (files)
    blacklist_paths: list[Path] = [config_dir_resolved]
    for p in blacklist_expanded:
        # bwrap can't mount tmpfs over symlinks — resolve to the real path
        mount_path = p.resolve()
        if mount_path.is_file():
            args.extend(["--ro-bind", "/dev/null", str(mount_path)])
        else:
            args.extend(["--tmpfs", str(mount_path)])
        blacklist_paths.append(mount_path)

    # Whitelist paths by binding them back (must be under a blacklisted path)
    for path in sandbox.get("whitelist", []):
        p = expand_path(path)
        if not p.exists():
            continue
        # Resolve once to prevent symlink TOCTOU
        resolved = p.resolve()
        if not any(resolved == bl or bl in resolved.parents for bl in blacklist_paths):
            raise SystemExit(
                f"Whitelist path {p} is not under any blacklisted path. "
                f"Blacklisted: {[str(bl) for bl in blacklist_paths]}"
            )
        args.extend(["--bind", str(resolved), str(resolved)])

    # Extra writable paths (e.g. ~/.pyenv/shims, ~/.keychain)
    for p in writable_expanded:
        mount_path = p.resolve()
        args.extend(["--bind", str(mount_path), str(mount_path)])

    # Project dir writable (after blacklist/whitelist so it's not overwritten)
    args.extend(["--bind", str(project_dir), str(project_dir)])

    # Bind-mount init script read-only (config dir may be blacklisted)
    if init_script is not None:
        args.extend(["--ro-bind", str(init_script), str(init_script)])

    # Bind-mount extra read-only paths (e.g. secrets identity file)
    for path in ro_bind_extra or []:
        args.extend(["--ro-bind", str(path), str(path)])

    # Bind-mount extra read-write paths (e.g. writeback archive)
    for path in rw_bind_extra or []:
        args.extend(["--bind", str(path), str(path)])

    # TIOCSTI protection (--new-session breaks fish TTY, so only enable when needed)
    vulnerable = tiocsti_vulnerable()
    new_session_cfg = sandbox.get("new_session")
    if new_session_cfg is True:
        args.append("--new-session")
    elif new_session_cfg is None and vulnerable:
        # Default: auto-enable on vulnerable kernels
        args.append("--new-session")
    elif new_session_cfg is False and vulnerable:
        import sys

        print(
            "Warning: new_session disabled but kernel is vulnerable to TIOCSTI "
            f"(Linux {os.uname().release}). Upgrade to 6.2+ or set "
            "new_session = true.",
            file=sys.stderr,
        )

    # Network isolation
    if sandbox.get("unshare_net", False):
        args.append("--unshare-net")

    # PID namespace isolation (default: on)
    if sandbox.get("unshare_pid", True):
        args.append("--unshare-pid")

    # Clean environment: clear everything, pass through essentials
    if sandbox.get("clean_env", False):
        args.append("--clearenv")
        for var in ("PATH", "HOME", "USER", "SHELL", "TERM", "LANG"):
            val = os.environ.get(var)
            if val is not None:
                args.extend(["--setenv", var, val])

    # Set environment variables
    args.extend(["--setenv", "PROJECT_WRAP", "1"])

    # Set working directory
    args.extend(["--chdir", str(project_dir)])

    return args


def get_init_script(config_dir: Path, shell: str) -> Path | None:
    """Find shell-specific init script.

    Looks for init.{shell} (e.g., init.fish) then falls back to init.sh.
    """
    shell_name = Path(shell).name

    candidates = [
        config_dir / f"init.{shell_name}",
        config_dir / "init.sh",
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    return None


def _build_init_commands(
    project_dir: Path,
    config_dir: Path,
    shell: str,
) -> list[str]:
    """Build setup commands (cd, init script sourcing).

    Returns list of shell commands — does NOT include the final exec/shell launch.
    """
    commands: list[str] = []

    commands.append(f"cd {shlex.quote(str(project_dir))}")

    # Custom init script
    if init_script := get_init_script(config_dir, shell):
        commands.append(f"source {shlex.quote(str(init_script))}")

    return commands


def build_shell_argv(
    project_dir: Path,
    config_dir: Path,
    shell: str,
) -> list[str]:
    """Build the full argv to launch an interactive shell with project setup.

    Uses shell-specific mechanisms so setup runs inside the interactive shell:
    - fish: --init-command (runs after config.fish, before prompt)
    - other shells: -c "setup; exec shell"
    """
    commands = _build_init_commands(project_dir, config_dir, shell)
    shell_name = Path(shell).name

    if shell_name == "fish":
        return [shell, "--init-command", "; ".join(commands)]

    commands.append(f"exec {shlex.quote(shell)}")
    return [shell, "-c", "; ".join(commands)]


def redact_bwrap_args(args: list[str]) -> list[str]:
    """Redact --setenv values from bwrap args for display."""
    redacted = list(args)
    i = 0
    while i < len(redacted):
        if redacted[i] == "--setenv" and i + 2 < len(redacted):
            redacted[i + 2] = "***"
            i += 3
        else:
            i += 1
    return redacted


def rename_tmux_window(name: str) -> None:
    """Rename current tmux window if in tmux session."""
    if os.environ.get("TMUX"):
        subprocess.run(
            ["tmux", "rename-window", name],
            capture_output=True,
        )


def prepare_project(name: str, verbose: bool = False) -> ProjectExec:
    """Prepare a project environment for execution.

    Loads config, renames tmux window, and returns everything needed
    to exec into the project shell.
    """
    config = load_config(name)

    # Extract config sections
    project_cfg = config.get("project", {})
    sandbox_cfg = config.get("sandbox", {})
    encrypted_cfg = config.get("encrypted", {})
    env_cfg: dict[str, str] = config.get("env", {})
    config_dir: Path = config["_config_dir"]

    # Resolve settings
    display_name = project_cfg.get("name", name)
    project_dir = expand_path(project_cfg.get("dir", f"~/projects/{name}"))
    shell = project_cfg.get("shell", os.environ.get("SHELL", "/bin/bash"))
    validate_shell(shell)
    sandbox_enabled = sandbox_cfg.get("enabled", False)

    # Verify project directory exists
    if not project_dir.exists():
        raise SystemExit(f"Project directory does not exist: {project_dir}")

    # Encrypted volumes require sandbox
    if encrypted_cfg and not sandbox_enabled:
        raise SystemExit(
            "[encrypted] requires sandbox to be enabled"
        )

    # Resolve encrypted volume config
    vault_config: VaultConfig | None = None
    if encrypted_cfg:
        require_dep("gocryptfs")

        cipherdir_raw = encrypted_cfg["cipherdir"]
        cipherdir_path = expand_path(cipherdir_raw)
        if not cipherdir_path.is_absolute():
            cipherdir_path = config_dir / cipherdir_raw
        cipherdir = cipherdir_path.resolve()

        if not cipherdir.is_dir():
            raise SystemExit(
                f"Encrypted cipherdir does not exist: {cipherdir}\n"
                f"Initialize it with: mkdir -p '{cipherdir}' && "
                f"gocryptfs -init '{cipherdir}'"
            )

        mountpoint = expand_path(encrypted_cfg["mountpoint"])
        mountpoint.mkdir(parents=True, exist_ok=True)

        vault_config = VaultConfig(
            cipherdir=cipherdir,
            mountpoint=mountpoint.resolve(),
            project_name=name,
            shared=encrypted_cfg.get("shared", False),
        )

    # Rename tmux window
    rename_tmux_window(display_name)

    # Resolve init script and build shell argv
    init_script = get_init_script(config_dir, shell)
    shell_argv = build_shell_argv(project_dir, config_dir, shell)

    # Expand ~/... in env values
    resolved_env: dict[str, str] = {}
    for k, v in env_cfg.items():
        resolved_env[k] = str(expand_path(v)) if v.startswith("~/") else v

    # Non-sandboxed execution
    if not sandbox_enabled:
        for k, v in resolved_env.items():
            os.environ[k] = v
        return ProjectExec(
            display_name=display_name,
            program=shell,
            argv=shell_argv,
        )

    # Sandboxed execution - verify bwrap is available
    require_dep("bwrap")

    # If encrypted volume, bind the mountpoint into the sandbox
    rw_bind_extra: list[Path] = []
    if vault_config:
        rw_bind_extra = [vault_config.mountpoint]

    bwrap_args = build_bwrap_args(
        sandbox_cfg, project_dir,
        init_script=init_script, rw_bind_extra=rw_bind_extra,
    )
    if vault_config:
        bwrap_args.extend(["--setenv", "PWRAP_VAULT_DIR", str(vault_config.mountpoint)])
    for k, v in resolved_env.items():
        bwrap_args.extend(["--setenv", k, v])
    bwrap_args.extend(shell_argv)

    verbose_info = None
    if verbose:
        verbose_info = f"Exec: {' '.join(redact_bwrap_args(bwrap_args))}"

    return ProjectExec(
        display_name=display_name,
        program="bwrap",
        argv=bwrap_args,
        is_sandboxed=True,
        verbose_info=verbose_info,
        vault_config=vault_config,
    )


def run_project(name: str, verbose: bool = False) -> None:
    """Load and run a project environment.

    This function does not return on success (execs into new shell).
    """
    from .vault import run_vault

    result = prepare_project(name, verbose)

    label = result.display_name
    if result.is_sandboxed:
        label += " (sandboxed)"
        if result.vault_config is not None:
            if result.vault_config.shared:
                label += " (shared vault)"
            else:
                label += " (vault)"
    print(f"Loading {label}")

    if result.verbose_info:
        print(result.verbose_info)

    if result.vault_config:
        sys.exit(run_vault(result.vault_config, result.argv))
    else:
        os.execvp(result.program, result.argv)



def list_projects() -> None:
    """List all available projects."""
    config_dir = get_config_dir()

    if not config_dir.exists():
        print(f"No projects configured. Create configs in: {config_dir}")
        return

    print("Projects:")

    items = sorted(config_dir.iterdir())
    if not items:
        print("  (none)")
        return

    for item in items:
        if item.name.startswith("."):
            continue

        if item.is_dir():
            # Check for valid config
            config_file = item / "project.toml"
            if config_file.exists():
                # Try to load to show name
                try:
                    with open(config_file, "rb") as f:
                        cfg = tomllib.load(f)
                    display_name = cfg.get("project", {}).get("name", item.name)
                    sandboxed = cfg.get("sandbox", {}).get("enabled", False)
                    marker = " [sandboxed]" if sandboxed else ""
                    print(f"  {item.name}/{marker}")
                    if display_name != item.name:
                        print(f"      → {display_name}")
                except Exception:
                    print(f"  {item.name}/ (invalid config)")
            else:
                print(f"  {item.name}/ (missing project.toml)")


