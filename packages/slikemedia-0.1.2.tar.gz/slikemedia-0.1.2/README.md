# slikemedia

Python SDK and CLI for uploading media to the [Slike](https://sli.ke) platform.

Supports **chunked file upload** (4 MiB chunks, Resumable.js-compatible) and **publish-by-URL** (Google Drive, YouTube, etc.).

---

## Install

```bash
pip3 install slikemedia
```

Requires Python 3.7+.

---

## CLI Quick Start

### 1. Create config file

```bash
mkdir -p ~/.slike
cp config.example.toml ~/.slike/config.toml
```

Edit `~/.slike/config.toml`:

```toml
token       = "your-production-token"   # required for production
token_dev   = "your-dev-token"          # required for --env dev
environment = "production"              # production | development
```

Get your token from **Slike CMS → Settings → API Tokens**.

---

### 2. Upload a file

Pass the **absolute or relative path** to your file as the first argument:

```bash
# Absolute path
slike-upload /Users/yourname/Videos/clip.mp4 --title "My Video" --desc "A short description"

# Relative path
slike-upload ./videos/clip.mp4 --title "My Video" --desc "A short description"

# File in current directory
slike-upload clip.mp4 --title "My Video" --desc "A short description"
```

Output:

```
Uploading clip.mp4 (production)…
  [##################################################] 3/3 chunks (100%)
Done. Media ID: 1xnfmdtg66
```

---

### 3. All CLI options

```
slike-upload [file] --title "..." --desc "..."

Arguments:
  file                  Local file path to upload (omit when using --url)

Options:
  --title TEXT          Media title                              (required)
  --desc TEXT           Media description                        (required)
  --url URL             Remote media URL — skips file upload     (optional)
  --type TEXT           Media type with --url: gdrive, youtube, url  (default: url)
  --asset-type TEXT     Asset type: video, shorts, etc.          (optional)
  --tags TEXT           Comma-separated tags: news,live,sports   (optional)
  --no-publish          Save as draft, skip auto-publish         (optional)
  --env TEXT            Override environment: production | dev   (optional)
  --token TEXT          Override production auth token           (optional)
  --token-dev TEXT      Override dev auth token                  (optional)
  --config PATH         Path to config file                      (default: ~/.slike/config.toml)
  --help                Show help and exit
```

---

### 4. More examples

```bash
# Upload to dev environment
slike-upload video.mp4 --title "Test" --desc "Test" --env dev

# Upload with asset type and tags
slike-upload video.mp4 \
  --title "Breaking News" \
  --desc  "Full coverage" \
  --asset-type video \
  --tags  "news,breaking,live"

# Save as draft (do not auto-publish)
slike-upload video.mp4 --title "Draft" --desc "Not live yet" --no-publish

# Publish by URL — Google Drive (no file upload)
slike-upload \
  --url  "https://drive.google.com/file/d/FILE_ID/view" \
  --type gdrive \
  --title "My Video" \
  --desc  "Description"

# Publish by URL — YouTube
slike-upload \
  --url  "https://youtube.com/watch?v=VIDEO_ID" \
  --type youtube \
  --title "My Video" \
  --desc  "Description"

# Pass tokens directly (no config file needed)
slike-upload video.mp4 --title "My Video" --desc "Desc" \
  --token YOUR_PROD_TOKEN

slike-upload video.mp4 --title "My Video" --desc "Desc" \
  --env dev --token-dev YOUR_DEV_TOKEN

# Use a custom config file
slike-upload video.mp4 --title "My Video" --desc "Desc" \
  --config /etc/slike/config.toml
```

---

## Config Reference

### File: `~/.slike/config.toml`

```toml
token       = "your-production-token"   # required
token_dev   = "your-dev-token"          # required for --env dev
environment = "production"              # production | development
```

### Priority (highest wins)

| Priority | Source |
|----------|--------|
| 1 | CLI flags (`--token`, `--token-dev`, `--env`, `--config`) |
| 2 | Environment variables |
| 3 | `~/.slike/config.toml` (or `SLIKE_CONFIG` path) |

### Environment variables

| Variable | Description |
|----------|-------------|
| `SLIKE_TOKEN` | Production auth token |
| `SLIKE_TOKEN_DEV` | Dev auth token |
| `SLIKE_ENVIRONMENT` | `production` or `development` |
| `SLIKE_CONFIG` | Path to a custom config file |

---

## Environments

| Environment | RPC endpoint | Upload endpoint |
|-------------|-------------|-----------------|
| `production` | `https://b2b.sli.ke/rpc` | `https://asset.sli.ke/upload` |
| `development` / `dev` | `https://app-dev.sli.ke/rpc` | `https://asset-dev.sli.ke/upload` |

---

## Python SDK

### One-call upload (register + upload chunks)

```python
from slikemedia import UploadMediaOnSlike

result = UploadMediaOnSlike(
    file_path   = "/path/to/video.mp4",
    title       = "My Video",
    description = "A short description",
    token       = "your-production-token",
    token_dev   = "your-dev-token",        # optional
    environment = "production",            # optional, default: production
    asset_type  = "video",                 # optional
    tags        = ["news", "live"],        # optional
    auto_publish= True,                    # optional, default: True
    on_progress = lambda done, total: print(f"{done}/{total} chunks"),
)

print(result["id"])   # media ID
```

---

### Two-step upload (register first, upload later)

```python
from slikemedia import RegisterMediaOnSlike, UploadChunksOnSlike

# Step 1 — register, get media ID immediately
reg = RegisterMediaOnSlike(
    file_path   = "/path/to/video.mp4",
    title       = "My Video",
    description = "Description",
    token       = "your-production-token",
    environment = "production",
)
print(reg["id"])    # media ID is available before upload starts
print(reg["jwt"])   # JWT used to authenticate the chunk uploads

# Step 2 — upload chunks
UploadChunksOnSlike(
    file_path   = "/path/to/video.mp4",
    media_id    = reg["id"],
    upload_jwt  = reg["jwt"],
    environment = "production",
    on_progress = lambda done, total: print(f"{done}/{total} chunks"),
)
```

---

### Publish by URL (no file upload)

```python
from slikemedia import PublishMediaOnSlike

result = PublishMediaOnSlike(
    url         = "https://drive.google.com/file/d/FILE_ID/view",
    title       = "My Video",
    description = "Description",
    type        = "gdrive",          # gdrive | youtube | url
    token       = "your-production-token",
    environment = "production",      # optional
    tags        = ["news"],          # optional
    asset_type  = "video",           # optional
    auto_publish= True,              # optional, default: True
)

r = result.get("result") or result
print(r["id"])   # media ID
```

---

### Load config programmatically

```python
from slikemedia import load_config, UploadMediaOnSlike

cfg = load_config()          # reads ~/.slike/config.toml then env vars
# cfg = load_config("config.toml")  # or pass an explicit path

result = UploadMediaOnSlike(
    file_path   = "video.mp4",
    title       = "My Video",
    description = "Description",
    token       = cfg.token,
    token_dev   = cfg.token_dev,
    environment = cfg.environment,
)
```

---

### Error handling

```python
from slikemedia import UploadMediaOnSlike, SlikeAPIError

try:
    result = UploadMediaOnSlike(
        file_path   = "video.mp4",
        title       = "My Video",
        description = "Description",
        token       = "your-token",
    )
except ValueError as e:
    print(f"Bad input: {e}")
except SlikeAPIError as e:
    print(f"API error: {e}")
```

---

## Config-driven script (upload.py)

For quick local runs without CLI flags, populate `config.toml` and run `upload.py` directly:

```toml
# config.toml  (in the project root)
token_dev   = "your-dev-token"
environment = "dev"
file        = "/path/to/video.mp4"
title       = "My Video"
desc        = "My description"
asset_type  = "video"
```

```bash
python upload.py
```

---

## How chunked upload works

Files are split into **4 MiB chunks** using the [Resumable.js](https://github.com/23/resumable.js) protocol — identical to what the Slike web app sends:

1. `media.register` RPC → returns `media_id` + short-lived upload JWT
2. Each chunk is POSTed as `multipart/form-data` to the asset server with the JWT in the `token` header
3. The asset server assembles and processes the file

Failed chunks are automatically retried up to **3 times** with exponential backoff.

---

## Development

```bash
# Clone and install in editable mode
git clone <repo>
cd slike-media-package
python3 -m pip install -e .

# Serve test_upload.html over HTTPS (requires slike-admin-mock cert)
python serve.py

# Build distributable wheel
pip install hatch
hatch build
```

---

## License

MIT
