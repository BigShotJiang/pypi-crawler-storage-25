"""
Slike chunked file upload.

Implements the Resumable.js-compatible multipart upload protocol:
  - RegisterMediaOnSlike  — register a file and obtain a media ID + JWT
  - UploadChunksOnSlike   — stream the file to the asset server in 4 MiB chunks
  - UploadMediaOnSlike    — one-call convenience wrapper for both steps
"""

import math
import mimetypes
import os
import re
import time
import uuid
from typing import Any, Dict, List, Optional

import requests

from slikemedia import (
    CHUNK_SIZE,
    DEVELOPMENT_UPLOAD_URL,
    PRODUCTION_UPLOAD_URL,
    SlikeAPIError,
    _build_cookies,
    _build_headers,
    _get_api_url,
    _make_request,
    _normalize_env,
    _select_token,
    _session,
    logger,
)

__all__ = [
    "RegisterMediaOnSlike",
    "UploadChunksOnSlike",
    "UploadMediaOnSlike",
]


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _validate_upload_params(
    file_path: str,
    title: str,
    description: str,
    token: str,
    token_dev: str = "",
    environment: Optional[str] = None,
) -> None:
    if not file_path or not isinstance(file_path, str):
        raise ValueError("file_path parameter is required and must be a non-empty string")
    if not os.path.isfile(file_path):
        raise ValueError(f"file_path does not exist or is not a file: '{file_path}'")
    if not title or not isinstance(title, str):
        raise ValueError("title parameter is required and must be a non-empty string")
    if not description or not isinstance(description, str):
        raise ValueError("description parameter is required and must be a non-empty string")
    is_dev = _normalize_env(environment) == "dev"
    effective = (token_dev if token_dev else token) if is_dev else token
    if not effective:
        raise ValueError("token is required (use token_dev for dev environment, or token as fallback)")


# ---------------------------------------------------------------------------
# URL + payload builders
# ---------------------------------------------------------------------------

def _get_upload_url(environment: Optional[str]) -> str:
    return DEVELOPMENT_UPLOAD_URL if _normalize_env(environment) == "dev" else PRODUCTION_UPLOAD_URL


def _build_register_payload(
    file_path: str,
    title: str,
    description: str,
    asset_type: Optional[str],
    tags: Optional[List[str]],
    preset_meta: Optional[str],
    auto_publish: bool,
) -> Dict[str, Any]:
    filename = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)

    params: Dict[str, Any] = {
        "fid": f"{file_size}{filename}",
        "title": title,
        "desc": description,
        "source": "api",
        "name": "media",
        "type": "upload",
        "auto_publish": auto_publish,
    }

    if tags:
        if not isinstance(tags, list):
            raise ValueError("tags parameter must be a list of strings")
        params["tags"] = tags
    if preset_meta:
        params["preset_meta"] = preset_meta
    if asset_type:
        params["asset_type"] = asset_type

    return {
        "jsonrpc": "2.0",
        "id": uuid.uuid4().int & 0x7FFFFFFF,
        "method": "media.register",
        "params": params,
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def _register_media(
    api_url: str,
    file_path: str,
    title: str,
    description: str,
    asset_type: Optional[str],
    tags: Optional[List[str]],
    preset_meta: Optional[str],
    auto_publish: bool,
    auth_token: str,
    environment: Optional[str],
) -> tuple:
    """Call media.register and return (media_id, upload_jwt, full_result_dict)."""
    payload = _build_register_payload(
        file_path, title, description, asset_type, tags, preset_meta, auto_publish
    )
    headers = _build_headers()
    cookies = _build_cookies(auth_token, environment)
    result = _make_request(api_url, payload, headers, cookies)

    result_data = result.get("result") or {}
    media_id = result_data.get("id")
    upload_jwt = result_data.get("jwt")

    if not media_id or not upload_jwt:
        raise SlikeAPIError("media.register did not return expected 'id' and 'jwt' fields")

    return media_id, upload_jwt, result_data


# ---------------------------------------------------------------------------
# Chunk upload
# ---------------------------------------------------------------------------

def _build_resumable_identifier(filename: str, file_size: int) -> str:
    """Build a deterministic Resumable.js uniqueIdentifier, matching the frontend logic."""
    sanitized = re.sub(r"[.\s]", "", filename)
    return f"{file_size}-{sanitized}"


def _detect_mime_type(file_path: str) -> str:
    mime, _ = mimetypes.guess_type(file_path)
    return mime or "application/octet-stream"


def _upload_chunk(
    upload_url: str,
    media_id: str,
    upload_jwt: str,
    chunk_data: bytes,
    chunk_number: int,
    total_chunks: int,
    file_size: int,
    filename: str,
    mime_type: str,
    identifier: str,
) -> None:
    """Upload a single chunk using Resumable.js-compatible multipart form-data."""
    files = [
        ("resumableChunkNumber",      (None, str(chunk_number))),
        ("resumableChunkSize",        (None, str(CHUNK_SIZE))),
        ("resumableCurrentChunkSize", (None, str(len(chunk_data)))),
        ("resumableTotalSize",        (None, str(file_size))),
        ("resumableType",             (None, mime_type)),
        ("resumableIdentifier",       (None, identifier)),
        ("resumableFilename",         (None, filename)),
        ("resumableRelativePath",     (None, filename)),
        ("resumableTotalChunks",      (None, str(total_chunks))),
        ("method",                    (None, "asset.file")),
        ("entity",                    (None, media_id)),
        ("key",                       (None, "media")),
        ("file",                      (filename, chunk_data, mime_type)),
    ]
    try:
        response = _session.post(
            upload_url,
            files=files,
            headers={"token": upload_jwt},
            verify=True,
            timeout=120,
        )
        if response.status_code >= 400:
            raise SlikeAPIError(
                f"Chunk {chunk_number}/{total_chunks} upload failed: "
                f"HTTP {response.status_code} — {response.text}"
            )
    except SlikeAPIError:
        raise
    except requests.exceptions.RequestException as e:
        raise SlikeAPIError(f"Chunk {chunk_number}/{total_chunks} upload failed: {str(e)}")


_RETRY_ATTEMPTS = 3


def _upload_chunk_with_retry(
    upload_url: str,
    media_id: str,
    upload_jwt: str,
    chunk_data: bytes,
    chunk_number: int,
    total_chunks: int,
    file_size: int,
    filename: str,
    mime_type: str,
    identifier: str,
) -> None:
    """Retry wrapper around _upload_chunk with exponential backoff."""
    last_exc: Optional[Exception] = None
    for attempt in range(1, _RETRY_ATTEMPTS + 1):
        try:
            _upload_chunk(
                upload_url, media_id, upload_jwt,
                chunk_data, chunk_number, total_chunks,
                file_size, filename, mime_type, identifier,
            )
            return
        except SlikeAPIError as exc:
            last_exc = exc
            if attempt < _RETRY_ATTEMPTS:
                wait = 2 ** (attempt - 1)
                logger.warning(
                    "Chunk %d/%d failed (attempt %d/%d), retrying in %ds: %s",
                    chunk_number, total_chunks, attempt, _RETRY_ATTEMPTS, wait, exc,
                )
                time.sleep(wait)
    raise SlikeAPIError(
        f"Chunk {chunk_number}/{total_chunks} failed after {_RETRY_ATTEMPTS} attempts: {last_exc}"
    ) from last_exc


def _upload_file_chunks(
    upload_url: str,
    media_id: str,
    upload_jwt: str,
    file_path: str,
    on_progress: Optional[Any],
) -> None:
    """Read file and upload it in CHUNK_SIZE pieces sequentially."""
    file_size = os.path.getsize(file_path)
    filename = os.path.basename(file_path)
    mime_type = _detect_mime_type(file_path)
    total_chunks = math.ceil(file_size / CHUNK_SIZE)
    identifier = _build_resumable_identifier(filename, file_size)

    with open(file_path, "rb") as fh:
        for chunk_number in range(1, total_chunks + 1):
            chunk_data = fh.read(CHUNK_SIZE)
            if not chunk_data:
                break
            logger.debug("Uploading chunk %d/%d", chunk_number, total_chunks)
            _upload_chunk_with_retry(
                upload_url, media_id, upload_jwt,
                chunk_data, chunk_number, total_chunks,
                file_size, filename, mime_type, identifier,
            )
            if callable(on_progress):
                on_progress(chunk_number, total_chunks)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def RegisterMediaOnSlike(
    file_path: str,
    title: str,
    description: str,
    token: str,
    token_dev: Optional[str] = None,
    environment: Optional[str] = None,
    asset_type: Optional[str] = None,
    tags: Optional[List[str]] = None,
    preset_meta: Optional[str] = None,
    auto_publish: bool = True,
) -> Dict[str, Any]:
    """
    Step 1 of chunked upload: register the media with Slike and get a media ID.

    Call this first to obtain the media_id and upload_jwt before uploading the file.

    Args:
        file_path: Local path to the file to be uploaded
        title: Media title
        description: Media description
        token: Production authentication token
        token_dev: Optional development authentication token
        environment: Optional environment - "production"/"prod" or "development"/"dev"
        asset_type: Optional asset type (e.g., 'video', 'shorts')
        tags: Optional list of tags
        preset_meta: Optional preset metadata identifier
        auto_publish: Whether to auto-publish the media (default: True)

    Returns:
        Dict containing at minimum: { "id": media_id, "media": ..., "exists": ..., "jwt": upload_jwt }

    Raises:
        ValueError: If required parameters are invalid or file does not exist
        SlikeAPIError: If API request fails or response is malformed
    """
    _validate_upload_params(file_path, title, description, token, token_dev or "", environment)
    api_url = _get_api_url(environment)
    auth_token = _select_token(token, token_dev, environment)
    _, _, result_data = _register_media(
        api_url, file_path, title, description, asset_type, tags, preset_meta, auto_publish,
        auth_token, environment,
    )
    return result_data


def UploadChunksOnSlike(
    file_path: str,
    media_id: str,
    upload_jwt: str,
    environment: Optional[str] = None,
    on_progress: Optional[Any] = None,
) -> None:
    """
    Step 2 of chunked upload: upload the file in 4 MiB chunks to Slike.

    Use the media_id and upload_jwt returned by RegisterMediaOnSlike().

    Args:
        file_path: Local path to the file to upload
        media_id: Media ID returned from RegisterMediaOnSlike()
        upload_jwt: JWT token returned from RegisterMediaOnSlike()
        environment: Optional environment - "production"/"prod" or "development"/"dev"
        on_progress: Optional callback called after each successful chunk.
                     Signature: on_progress(chunks_uploaded: int, total_chunks: int)

    Raises:
        ValueError: If file_path, media_id, or upload_jwt are invalid
        SlikeAPIError: If any chunk upload fails
    """
    if not file_path or not isinstance(file_path, str):
        raise ValueError("file_path parameter is required and must be a non-empty string")
    if not os.path.isfile(file_path):
        raise ValueError(f"file_path does not exist or is not a file: '{file_path}'")
    if not media_id or not isinstance(media_id, str):
        raise ValueError("media_id parameter is required and must be a non-empty string")
    if not upload_jwt or not isinstance(upload_jwt, str):
        raise ValueError("upload_jwt parameter is required and must be a non-empty string")

    upload_url = _get_upload_url(environment)
    _upload_file_chunks(upload_url, media_id, upload_jwt, file_path, on_progress)


def UploadMediaOnSlike(
    file_path: str,
    title: str,
    description: str,
    token: str,
    token_dev: Optional[str] = None,
    environment: Optional[str] = None,
    asset_type: Optional[str] = None,
    tags: Optional[List[str]] = None,
    preset_meta: Optional[str] = None,
    auto_publish: bool = True,
    on_progress: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    Register and upload a local file to Slike in one call (combines both steps).

    Equivalent to calling RegisterMediaOnSlike() followed by UploadChunksOnSlike().

    Args:
        file_path: Local path to the file to upload
        title: Media title
        description: Media description
        token: Production authentication token
        token_dev: Optional development authentication token
        environment: Optional environment - "production"/"prod" or "development"/"dev"
        asset_type: Optional asset type (e.g., 'video', 'shorts')
        tags: Optional list of tags
        preset_meta: Optional preset metadata identifier
        auto_publish: Whether to auto-publish the media (default: True)
        on_progress: Optional callback called after each chunk.
                     Signature: on_progress(chunks_uploaded: int, total_chunks: int)

    Returns:
        Dict from media.register containing at minimum: { "id": media_id, "media": ..., "exists": ... }

    Raises:
        ValueError: If required parameters are invalid or file does not exist
        SlikeAPIError: If registration or any chunk upload fails
    """
    register_result = RegisterMediaOnSlike(
        file_path=file_path,
        title=title,
        description=description,
        token=token,
        token_dev=token_dev,
        environment=environment,
        asset_type=asset_type,
        tags=tags,
        preset_meta=preset_meta,
        auto_publish=auto_publish,
    )
    UploadChunksOnSlike(
        file_path=file_path,
        media_id=register_result["id"],
        upload_jwt=register_result["jwt"],
        environment=environment,
        on_progress=on_progress,
    )
    return register_result
