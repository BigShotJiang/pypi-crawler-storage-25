"""
Slike Media Publisher
A module for publishing media to the Slike platform via JSON-RPC API.
Supports both HTTP publish (by URL reference) and direct chunked file upload.
"""

__version__ = "0.1.0"
__all__ = [
    "PublishMediaOnSlike",
    "RegisterMediaOnSlike",
    "UploadChunksOnSlike",
    "UploadMediaOnSlike",
    "SlikeAPIError",
    "SlikeConfig",
    "load_config",
    "PRODUCTION_URL",
    "DEVELOPMENT_URL",
    "PRODUCTION_UPLOAD_URL",
    "DEVELOPMENT_UPLOAD_URL",
]

import logging
import os
import sys
import argparse
import uuid
import requests
from typing import Dict, Optional, Any, List
from dataclasses import dataclass, field

try:
    import tomllib          # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class SlikeConfig:
    """
    Configuration for the Slike SDK.

    Priority (highest to lowest):
      1. Values passed directly to functions
      2. Environment variables  (SLIKE_TOKEN, SLIKE_TOKEN_DEV, SLIKE_ENVIRONMENT)
      3. Config file            (~/.slike/config.toml  or  SLIKE_CONFIG path)
    """
    token: str = ""
    token_dev: str = ""
    environment: str = "production"
    file: str = ""
    title: str = ""
    desc: str = ""
    asset_type: str = ""

    def effective_token(self, environment: Optional[str] = None) -> str:
        if _normalize_env(environment or self.environment) == "dev" and self.token_dev:
            return self.token_dev
        return self.token


def load_config(config_path: Optional[str] = None) -> SlikeConfig:
    """
    Load config from (in priority order):
      1. Explicit path argument
      2. SLIKE_CONFIG env var
      3. ~/.slike/config.toml

    Config file format (TOML subset — plain key=value, no dependencies):

        token = "your-production-token"
        token_dev = "your-dev-token"
        environment = "production"

    Environment variable overrides (always win over file):
        SLIKE_TOKEN, SLIKE_TOKEN_DEV, SLIKE_ENVIRONMENT
    """
    cfg = SlikeConfig()

    # Determine config file path
    path = (
        config_path
        or os.environ.get("SLIKE_CONFIG")
        or os.path.expanduser("~/.slike/config.toml")
    )

    if os.path.isfile(path):
        logger.debug("Loaded config from %s", path)
        if tomllib is not None:
            with open(path, "rb") as f:
                data = tomllib.load(f)
        else:
            # Fallback: parse simple key = "value" lines only
            data = {}
            with open(path) as f:
                for raw in f:
                    line = raw.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    data[key.strip().lower()] = value.strip().strip('"').strip("'")
        cfg.token       = data.get("token", "")
        cfg.token_dev   = data.get("token_dev", "")
        cfg.environment = data.get("environment", "production")
        cfg.file        = data.get("file", "")
        cfg.title       = data.get("title", "")
        cfg.desc        = data.get("desc", "")
        cfg.asset_type  = data.get("asset_type", "")

    # Environment variables override file
    if os.environ.get("SLIKE_TOKEN"):
        cfg.token = os.environ["SLIKE_TOKEN"]
    if os.environ.get("SLIKE_TOKEN_DEV"):
        cfg.token_dev = os.environ["SLIKE_TOKEN_DEV"]
    if os.environ.get("SLIKE_ENVIRONMENT"):
        cfg.environment = os.environ["SLIKE_ENVIRONMENT"]

    return cfg

_session = requests.Session()

# RPC API URL Configuration
PRODUCTION_URL = "https://b2b.sli.ke/rpc"
DEVELOPMENT_URL = "https://app-dev.sli.ke/rpc"

# Upload server URL Configuration
PRODUCTION_UPLOAD_URL = "https://asset.sli.ke/upload"
DEVELOPMENT_UPLOAD_URL = "https://asset-dev.sli.ke/upload"

# Chunk size: 4 MiB — mirrors Resumable.js default
CHUNK_SIZE = 4 * 1024 * 1024


class SlikeAPIError(Exception):
    """Custom exception for Slike API errors."""
    pass


def PublishMediaOnSlike(
    url: str,
    title: str,
    description: str,
    type: str,
    token: str,
    token_dev: Optional[str] = None,
    environment: Optional[str] = None,
    preset_meta: Optional[str] = None,
    tags: Optional[List[str]] = None,
    asset_type: Optional[str] = None,
    auto_publish: bool = True,
) -> Dict[str, Any]:
    """
    Publish media to Slike platform.
    
    Args:
        url: Media URL (Google Drive, YouTube, etc.)
        title: Media title
        description: Media description
        type: Media type (e.g., 'gdrive', 'youtube')
        token: Production authentication token (used when environment is None or "production"/"prod")
        token_dev: Optional development authentication token (used when environment is "development"/"dev")
        environment: Optional environment - "production"/"prod" or "development"/"dev" (default: production if not specified)
        preset_meta: Optional preset metadata identifier
        tags: Optional list of tags
        asset_type: Optional asset type (e.g., 'shorts', 'video')
        auto_publish: Whether to auto-publish the media (default: True)
    
    Returns:
        Dict containing the API response
    
    Raises:
        ValueError: If required parameters are invalid
        SlikeAPIError: If API request fails
    """
    # Validate required parameters
    _validate_required_params(url, title, description, token, token_dev or "", environment)
    
    # Determine API endpoint based on environment
    api_url = _get_api_url(environment)
    
    # Select appropriate token based on environment
    auth_token = _select_token(token, token_dev, environment)
    
    # Build request payload
    payload = _build_payload(url, title, description, type, tags, preset_meta, asset_type, auto_publish)
    
    # Make API request
    headers = _build_headers()
    cookies = _build_cookies(auth_token, environment)
    return _make_request(api_url, payload, headers, cookies)


def _validate_required_params(
    url: str,
    title: str,
    description: str,
    token: str,
    token_dev: str = "",
    environment: Optional[str] = None,
) -> None:
    """Validate required parameters."""
    if not url or not isinstance(url, str):
        raise ValueError("url parameter is required and must be a non-empty string")
    if not title or not isinstance(title, str):
        raise ValueError("title parameter is required and must be a non-empty string")
    if not description or not isinstance(description, str):
        raise ValueError("description parameter is required and must be a non-empty string")
    is_dev = _normalize_env(environment) == "dev"
    effective = (token_dev if token_dev else token) if is_dev else token
    if not effective:
        raise ValueError("token is required (use token_dev for dev environment, or token for production)")


def _normalize_env(environment: Optional[str]) -> str:
    """Return canonical env string: 'dev' | 'prod'. Raises ValueError on invalid input."""
    if not environment:
        return "prod"
    env = environment.lower()
    if env in ("development", "dev"):
        return "dev"
    if env in ("production", "prod"):
        return "prod"
    raise ValueError(
        f"Invalid environment: '{environment}'. Must be 'production'/'prod' or 'development'/'dev'"
    )


def _get_api_url(environment: Optional[str]) -> str:
    """Determine API URL based on environment. Defaults to production if None or empty."""
    return DEVELOPMENT_URL if _normalize_env(environment) == "dev" else PRODUCTION_URL


def _select_token(token: str, token_dev: Optional[str], environment: Optional[str]) -> str:
    """Select appropriate token based on environment."""
    return token_dev if (_normalize_env(environment) == "dev" and token_dev) else token


def _build_payload(
    url: str,
    title: str,
    description: str,
    type: str,
    tags: Optional[List[str]],
    preset_meta: Optional[str],
    asset_type: Optional[str],
    auto_publish: bool
) -> Dict[str, Any]:
    """Build JSON-RPC 2.0 payload."""
    params = {
        "title": title,
        "desc": description,
        "url": url,
        "type": type,
        "auto_publish": auto_publish
    }
    
    # Add optional parameters
    if tags:
        if not isinstance(tags, list):
            raise ValueError("tags parameter must be a list of strings")
        params["tags"] = tags
    
    if preset_meta:
        params["preset_meta"] = preset_meta
    
    if asset_type:
        params["asset_type"] = asset_type
    
    return {
        "jsonrpc": "2.0",
        "id": uuid.uuid4().int & 0x7FFFFFFF,
        "method": "media.publish",
        "params": params
    }


def _build_headers() -> Dict[str, str]:
    return {"Content-Type": "application/json"}


def _build_cookies(token: str, environment: Optional[str]) -> Dict[str, str]:
    """Build auth cookies for RPC requests (server reads token from cookie)."""
    return {"token-dev": token} if _normalize_env(environment) == "dev" else {"token": token}


def _make_request(api_url: str, payload: Dict[str, Any], headers: Dict[str, str],
                  cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Make the API request and handle response."""
    try:
        logger.debug("POST %s method=%s", api_url, payload.get("method"))
        response = _session.post(api_url, json=payload, headers=headers,
                                 cookies=cookies or {}, verify=True, timeout=30)
        result = _parse_response(response)
        _check_for_errors(response, result)
        return result
    except SlikeAPIError:
        raise
    except requests.exceptions.RequestException as e:
        raise SlikeAPIError(f"Failed to publish media on Slike: {str(e)}")
    except Exception as e:
        raise SlikeAPIError(f"Unexpected error while publishing media: {str(e)}")


def _parse_response(response: requests.Response) -> Dict[str, Any]:
    """Parse JSON response."""
    try:
        return response.json()
    except ValueError:
        raise SlikeAPIError(f"Invalid JSON response: {response.text}")


def _check_for_errors(response: requests.Response, result: Dict[str, Any]) -> None:
    """Check for HTTP and JSON-RPC errors."""
    # Check HTTP status code
    if response.status_code >= 400:
        error_msg = _extract_error_message(result, response.text)
        raise SlikeAPIError(f"HTTP {response.status_code}: {error_msg}")
    
    # Check JSON-RPC errors (only if error field is not empty)
    if isinstance(result, dict) and "error" in result:
        error_obj = result.get("error")
        
        # Skip if error is empty string or None
        if not error_obj:
            return
        
        # Include full error details for debugging
        if isinstance(error_obj, dict):
            error_msg = error_obj.get("message", "Unknown JSON-RPC error")
            error_code = error_obj.get("code", "N/A")
            error_data = error_obj.get("data", "")
            full_error = f"{error_msg} (code: {error_code})"
            if error_data:
                full_error += f" - {error_data}"
        else:
            full_error = str(error_obj)
        
        raise SlikeAPIError(f"JSON-RPC error: {full_error}")


def _extract_error_message(error_obj: Any, default: str) -> str:
    """Extract error message from error object."""
    if isinstance(error_obj, dict):
        return error_obj.get("message", default)
    return str(error_obj) if error_obj else default


# ---------------------------------------------------------------------------
# Chunked upload — re-exported from slikeupload (lazy to avoid circular import)
# ---------------------------------------------------------------------------

def __getattr__(name: str):
    if name in ("RegisterMediaOnSlike", "UploadChunksOnSlike", "UploadMediaOnSlike"):
        import slikeupload as _su
        return getattr(_su, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cli_progress(done: int, total: int) -> None:
    pct = int(done / total * 100)
    bar = "#" * (pct // 2)
    print(f"\r  [{bar:<50}] {done}/{total} chunks ({pct}%)", end="", flush=True)
    if done == total:
        print()


def main() -> None:
    """
    slike-upload — CLI for uploading media to Slike.


    Configuration (in priority order):
      1. CLI flags
      2. Env vars: SLIKE_TOKEN, SLIKE_TOKEN_DEV, SLIKE_ENVIRONMENT
      3. Config file: ~/.slike/config.toml  (or SLIKE_CONFIG env var)

    Config file format (~/.slike/config.toml):
        token = "your-production-token"
        token_dev = "your-dev-token"
        environment = "production"
    """
    parser = argparse.ArgumentParser(
        prog="slike-upload",
        description="Upload a media file to the Slike platform.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Upload using config file
  slike-upload video.mp4 --title "My Video" --desc "A description"

  # Override environment on the fly
  slike-upload video.mp4 --title "Test" --desc "Test" --env dev

  # Pass token directly (skips config file)
  slike-upload video.mp4 --title "My Video" --desc "Desc" --token abc123

  # Publish by URL (no file upload)
  slike-upload --url https://drive.google.com/file/d/... --type gdrive \\
               --title "My Video" --desc "Desc"
        """,
    )

    # Input — file or URL
    parser.add_argument("file", nargs="?", help="Local file path to upload")
    parser.add_argument("--url", help="Remote media URL (for publish-by-URL mode)")
    parser.add_argument("--type", default="url", dest="media_type",
                        help="Media type for URL mode: gdrive, youtube, url (default: url)")

    # Metadata
    parser.add_argument("--title", required=True, help="Media title")
    parser.add_argument("--desc", required=True, help="Media description")
    parser.add_argument("--asset-type", default=None, help="Asset type, e.g. video, shorts")
    parser.add_argument("--tags", default=None, help="Comma-separated tags")
    parser.add_argument("--no-publish", action="store_true",
                        help="Do not auto-publish after upload")

    # Auth / environment
    parser.add_argument("--token", default=None, help="Auth token (overrides config)")
    parser.add_argument("--token-dev", default=None, help="Dev auth token (overrides config)")
    parser.add_argument("--env", default=None, dest="environment",
                        help="Environment: production/prod or development/dev (overrides config)")
    parser.add_argument("--config", default=None, help="Path to config file")

    args = parser.parse_args()

    from slikeupload import RegisterMediaOnSlike, UploadChunksOnSlike

    # Load base config then let CLI flags override
    cfg = load_config(args.config)
    token     = args.token     or cfg.token
    token_dev = args.token_dev or cfg.token_dev
    env       = args.environment or cfg.environment

    # Compute effective credential from fully-merged CLI+config values
    effective = _select_token(token, token_dev or None, env)
    if not effective:
        print("Error: auth token required. Set --token/--token-dev, SLIKE_TOKEN, or add token/token_dev to ~/.slike/config.toml")
        sys.exit(1)

    tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
    auto_publish = not args.no_publish

    # ── URL publish mode ────────────────────────────────────────────────────
    if args.url:
        print(f"Publishing via URL ({env})…")
        result = PublishMediaOnSlike(
            url=args.url,
            title=args.title,
            description=args.desc,
            type=args.media_type,
            token=token,
            token_dev=token_dev or None,
            environment=env,
            asset_type=args.asset_type,
            tags=tags,
            auto_publish=auto_publish,
        )
        r = result.get("result") or result
        print(f"Done. Media ID: {r.get('id', '?')}")
        return

    # ── File upload mode ────────────────────────────────────────────────────
    if not args.file:
        parser.error("Provide a file path or --url")

    if not os.path.isfile(args.file):
        print(f"Error: file not found: {args.file}")
        sys.exit(1)

    print(f"Uploading {os.path.basename(args.file)} ({env})…")
    result = RegisterMediaOnSlike(
        file_path=args.file,
        title=args.title,
        description=args.desc,
        token=token,
        token_dev=token_dev or None,
        environment=env,
        asset_type=args.asset_type,
        tags=tags,
        auto_publish=auto_publish,
    )
    print(f"Media ID: {result.get('id', '?')}")
    UploadChunksOnSlike(
        file_path=args.file,
        media_id=result["id"],
        upload_jwt=result["jwt"],
        environment=env,
        on_progress=_cli_progress,
    )
    print(f"Done. Media ID: {result.get('id', '?')}")


if __name__ == "__main__":
    main()
