import uuid
from datetime import datetime

from pydantic import BaseModel, field_validator

from pmflow_shared.enums import OrgRole


class OrganizationCreate(BaseModel):
    name: str
    slug: str
    lark_app_id: str
    lark_app_secret: str  # transient, not persisted in DB
    lark_brand: str = "feishu"

    @field_validator("slug")
    @classmethod
    def slug_must_be_ascii(cls, v: str) -> str:
        import re
        if not re.match(r"^[a-z0-9]+(?:-[a-z0-9]+)*$", v):
            raise ValueError("slug 仅支持小写英文字母、数字和连字符，且不能以连字符开头或结尾")
        return v


class OrganizationRead(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    lark_app_id: str
    lark_brand: str
    lark_folder_token: str | None
    created_by: uuid.UUID
    created_at: datetime
    updated_at: datetime
    my_role: OrgRole | None = None


class OrganizationUpdate(BaseModel):
    name: str | None = None
    lark_folder_token: str | None = None


class OrgMemberRead(BaseModel):
    user_id: uuid.UUID
    email: str
    name: str
    role: OrgRole
    feishu_linked: bool
    joined_at: datetime


class OrgInvitationCreate(BaseModel):
    email: str
    role: OrgRole = OrgRole.MEMBER


class OrgInvitationRead(BaseModel):
    id: uuid.UUID
    organization_id: uuid.UUID
    email: str
    role: OrgRole
    token: str
    invited_by: uuid.UUID
    created_at: datetime
    expires_at: datetime
    accepted_at: datetime | None


class OrgInvitationInfo(BaseModel):
    """Public invitation info (no auth required) for the invite accept page."""
    org_name: str
    org_slug: str
    email: str
    role: OrgRole
    expired: bool
    accepted: bool
