# Next-session handoff — v0.1.4 verify + agent-binding round-3

> Written 2026-05-16 after pushing `v0.1.4`. v0.1.3 had a real bug
> shipped under "P0-4 fixed" — the syncRecordValuesMain lookup used
> `table="block"` (written from spec, no live capture). v0.1.4 fixed
> it once the operator captured the real chat-panel request: the
> table is `bot`, the response carries `name` directly. Round-3 will
> close the last open loop — auto-resolving `agent_id → agent_page_id`
> so operators don't have to copy the persistent_instructions_page
> UUID out of the URL.

## TL;DR — what you're walking into

- v0.1.4 is **tagged + pushed**; PyPI publish should propagate to the
  simple index within ~5 min of the tag push (jarvis round-2 §3 was
  exactly this propagation lag, not an actual publish failure).
- Operator is **re-testing on jarvis** post-pipx upgrade. Round-3
  feedback expected. Verify the lookup path (`syncRecordValuesMain
  table=bot`) returns names on a real 19-agent workspace before
  anything else.
- One **known gap** that round-3 will probably ask about:
  `--agent-name → --agent-page-id` auto-resolution. Currently
  impossible — we have the `bot.name` mapping but not the
  `bot → persistent_instructions_page` mapping. Needs more captures
  (see §"workflow_id mystery" below).

## Startup checks (~30s)

```bash
source .venv/bin/activate
.venv/bin/pytest -q | tail -3                # expect 205 pass
.venv/bin/ruff check src tests | tail -1     # expect "All checks passed!"
notion-agent --version                       # 0.1.4 (after `pip install -e .`)
git log --oneline -5                         # b3f771c / 32779bd / c51138c / ...
git status -s                                # expect clean
```

```bash
# Did v0.1.4 publish?
curl -s https://pypi.org/simple/notion-agent-cli/ | grep -oE 'notion[_-]agent[_-]cli-0\.1\.4'
# If still missing, recheck in 2–3 min — Trusted Publishing → simple index has lag.
```

## What just shipped in v0.1.4

Single fix, two commits (`32779bd` + `b3f771c`):

- `agents list` name resolution now hits `syncRecordValuesMain` with
  `table="bot"` (not `block`). Custom Agents live in Notion's `bot`
  table — they're not pages. The `bot` record returns
  `{name, icon, type, workflow_id, …}`; we read `name` directly (plain
  string, no rich-text array unwrapping unlike block titles).
- `provider.fetch_block_records` → `fetch_bot_records`; pointer body
  changed (`table=bot`, no `spaceId` — Notion auths bot pointers on
  the session cookie alone).
- `agents.parse_block_records` → `parse_bot_records`;
  `extract_page_title` → `extract_bot_name`.
- Tests: new fixture `tests/fixtures/sync_record_values_bot.json` is
  a sanitized copy of the operator's live capture (Email Agent +
  Jarvis). 184 → 205 unit tests; the v0.1.3 block-record tests were
  replaced wholesale (they tested code that never worked on real
  workspaces).
- Docs (AGENTS.md, README): explicit `agent_id` ≠ `agent_page_id`
  warning, with the explanation of why the CLI can't derive one
  from the other yet.

## Workflow_id mystery (the round-3 blocker)

The operator's bot-record capture (Email Agent, `type: workflow`)
showed:

```
{
  "id": "<agent_id>",
  "name": "Email Agent",
  "type": "workflow",
  "workflow_id": "<another-uuid>",   ← candidate for agent_page_id
  ...
}
```

`workflow_id` LOOKS like it could be the agent's instructions /
prompt page — but this is a **workflow-type** bot. Jarvis is
**custom-type**, and we don't yet have its bot record to compare.
Possibilities:

1. `workflow_id` is the instructions page for workflow agents only;
   custom agents use a different field (e.g. `persistent_instructions_page_id`).
2. `workflow_id` is something else entirely (workflow definition,
   not the prompt page).
3. Custom agents don't expose their instructions-page id at all
   on the bot record — would need a different endpoint.

**Round-3 ask**: have the operator capture **Jarvis's bot record**
(call `syncRecordValuesMain table=bot` with `id = <jarvis-agent_id>`
from `agents list`) and share the response. With that one capture
we can:
- Confirm which field holds the instructions page id.
- Add a new flag like `agents list --json` carrying
  `agent_page_id: <uuid>` for the bot types where it exists.
- Implement `agents resolve --name "Jarvis"` so operators can skip
  the manual URL copy.

If round-3 surfaces this capture, that becomes v0.1.5 scope.

## Likely round-3 feedback shape

After v0.1.4 ships, the operator will likely report:

1. **"`agents list` now shows all 19 names — 🎉"** → bank it, move on
   to the workflow_id mystery.
2. **"Some agents still show null"** → those bot records may genuinely
   lack a `name` field (workflow agents auto-named from page title,
   `type: workflow` with no manual rename). Investigate by capturing
   the bot record for the unnamed ones.
3. **"Can `agents list --no-names` round-trip without errors?"** →
   sanity check the opt-out flag.
4. **Wishlist: `agents resolve --name`, `init --agent-name <name>`
   auto-binding** → these depend on the workflow_id mystery being
   solved first; defer to v0.1.5.

## Hot paths (where round-3 changes likely land)

| Theme | First file to look at |
|---|---|
| Adding bot-record fields beyond name | `src/notion_agent_cli/agents.py::extract_bot_name` + `AgentSummary` |
| `agents resolve --name` subcommand | `src/notion_agent_cli/cli/__main__.py` next to `_cmd_agents_list` |
| `init --agent-name` auto-resolution | `src/notion_agent_cli/cli/__main__.py::_cmd_init` — replace the warn branch with a resolve-then-bind path |
| New live capture → fixture | `tests/fixtures/` |

## What NOT to touch

Same list as before — `provider.py` transcript paths, `thread_state.py`
schema, `account.py`'s required-fields list, the `pypi` GitHub
environment.

Specific to v0.1.4 cleanups to **defer**:

- **Don't surface `workflow_id` as `agent_page_id`** in `agents list
  --json` until we have a custom-type bot record to verify the field
  semantics. Premature aliasing would lie to operators when
  workflow-type and custom-type differ.

## How to ship v0.1.5

Same SOP. Auto-mode classifier blocks Claude from pushing to main;
the operator runs the three SOP lines inline (`!` prefix) once they've
reviewed the diff.

```bash
sed -i '' 's/version = "0.1.4"/version = "0.1.5"/' pyproject.toml
git commit -am "Bump version to 0.1.5"
# Operator runs:  git push origin main && git tag v0.1.5 && git push origin v0.1.5
```

## Done state for this session

You're done when:

1. v0.1.4 is **live on PyPI** and `pipx upgrade notion-agent-cli`
   resolves to 0.1.4.
2. The operator confirms `agents list --json` on a real workspace
   returns non-null `name` for at least the manually-recognizable
   agents.
3. If round-3 surfaces a Jarvis (custom-type) bot capture, the
   workflow_id mystery is resolved and a v0.1.5 plan exists.
4. Any new round-3 feedback items are triaged into bug / UX wart /
   doc gap / polish / out-of-scope per the rubric the previous
   handoff established.
5. This file is updated for round-4 or deleted if nothing's in flight.
