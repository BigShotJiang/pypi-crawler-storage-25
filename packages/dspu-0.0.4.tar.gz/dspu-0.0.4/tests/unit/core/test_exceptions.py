"""Tests for core exceptions."""

import pytest

from dspu.core.exceptions import (
    ConfigurationError,
    DSPUError,
    DSPUIOError,
    SecurityError,
    ValidationError,
)


class TestDSPUError:
    """Tests for base DSPUError."""

    def test_can_raise_and_catch(self) -> None:
        """Test raising and catching base error."""
        with pytest.raises(DSPUError) as exc_info:
            raise DSPUError("test error")

        assert str(exc_info.value) == "test error"

    def test_inherits_from_exception(self) -> None:
        """Test that DSPUError inherits from Exception."""
        assert issubclass(DSPUError, Exception)


class TestConfigurationError:
    """Tests for ConfigurationError."""

    def test_basic_error(self) -> None:
        """Test basic configuration error."""
        error = ConfigurationError("Invalid config")
        assert str(error) == "Invalid config"

    def test_error_with_field(self) -> None:
        """Test error with field information."""
        error = ConfigurationError("Invalid value", field="database_url")
        assert "Invalid value" in str(error)
        assert "Field: database_url" in str(error)

    def test_error_with_suggestion(self) -> None:
        """Test error with suggestion."""
        error = ConfigurationError(
            "Invalid URL format", suggestion="Use format: postgresql://user:pass@host:port/db"
        )
        assert "Invalid URL format" in str(error)
        assert "Suggestion:" in str(error)
        assert "postgresql://" in str(error)

    def test_error_with_field_and_suggestion(self) -> None:
        """Test error with both field and suggestion."""
        error = ConfigurationError(
            "Invalid URL", field="database_url", suggestion="Use postgresql:// format"
        )
        error_str = str(error)
        assert "Invalid URL" in error_str
        assert "Field: database_url" in error_str
        assert "Suggestion:" in error_str

    def test_inherits_from_dspu_error(self) -> None:
        """Test inheritance from DSPUError."""
        assert issubclass(ConfigurationError, DSPUError)

    def test_catchable_as_dspu_error(self) -> None:
        """Test that ConfigurationError can be caught as DSPUError."""
        with pytest.raises(DSPUError):
            raise ConfigurationError("test")


class TestValidationError:
    """Tests for ValidationError."""

    def test_basic_error(self) -> None:
        """Test basic validation error."""
        error = ValidationError("Value is invalid")
        assert str(error) == "Value is invalid"

    def test_error_with_field(self) -> None:
        """Test error with field."""
        error = ValidationError("Invalid age", field="age")
        assert "Invalid age" in str(error)
        assert "Field: age" in str(error)

    def test_error_with_value(self) -> None:
        """Test error with invalid value."""
        error = ValidationError("Value must be positive", value=-5)
        assert "Value must be positive" in str(error)
        assert "Value: -5" in str(error)

    def test_error_with_constraint(self) -> None:
        """Test error with constraint."""
        error = ValidationError("Constraint violation", constraint="age >= 0")
        assert "Constraint violation" in str(error)
        assert "Constraint: age >= 0" in str(error)

    def test_error_with_all_fields(self) -> None:
        """Test error with all optional fields."""
        error = ValidationError(
            "Value out of range", field="temperature", value=150, constraint="0 <= temp <= 100"
        )
        error_str = str(error)
        assert "Value out of range" in error_str
        assert "Field: temperature" in error_str
        assert "Value: 150" in error_str
        assert "Constraint:" in error_str

    def test_inherits_from_dspu_error(self) -> None:
        """Test inheritance from DSPUError."""
        assert issubclass(ValidationError, DSPUError)


class TestDSPUIOError:
    """Tests for DSPUIOError."""

    def test_basic_error(self) -> None:
        """Test basic I/O error."""
        error = DSPUIOError("Failed to read")
        assert str(error) == "Failed to read"

    def test_error_with_path(self) -> None:
        """Test error with path."""
        error = DSPUIOError("File not found", path="/data/file.json")
        assert "File not found" in str(error)
        assert "Path: /data/file.json" in str(error)

    def test_error_with_operation(self) -> None:
        """Test error with operation."""
        error = DSPUIOError("Operation failed", operation="write")
        assert "Operation failed" in str(error)
        assert "Operation: write" in str(error)

    def test_error_with_path_and_operation(self) -> None:
        """Test error with both path and operation."""
        error = DSPUIOError("Write failed", path="s3://bucket/file.txt", operation="write")
        error_str = str(error)
        assert "Write failed" in error_str
        assert "Operation: write" in error_str
        assert "Path: s3://bucket/file.txt" in error_str

    def test_inherits_from_dspu_error(self) -> None:
        """Test inheritance from DSPUError."""
        assert issubclass(DSPUIOError, DSPUError)


class TestSecurityError:
    """Tests for SecurityError."""

    def test_basic_error(self) -> None:
        """Test basic security error."""
        error = SecurityError("Authentication failed")
        assert str(error) == "Authentication failed"

    def test_error_with_reason(self) -> None:
        """Test error with reason."""
        error = SecurityError("Access denied", reason="Invalid credentials")
        assert "Access denied" in str(error)
        assert "Reason: Invalid credentials" in str(error)

    def test_error_with_resource(self) -> None:
        """Test error with resource."""
        error = SecurityError("Unauthorized", resource="database")
        assert "Unauthorized" in str(error)
        assert "Resource: database" in str(error)

    def test_error_with_reason_and_resource(self) -> None:
        """Test error with both reason and resource."""
        error = SecurityError(
            "Permission denied", reason="Insufficient privileges", resource="admin-api"
        )
        error_str = str(error)
        assert "Permission denied" in error_str
        assert "Reason: Insufficient privileges" in error_str
        assert "Resource: admin-api" in error_str

    def test_inherits_from_dspu_error(self) -> None:
        """Test inheritance from DSPUError."""
        assert issubclass(SecurityError, DSPUError)
