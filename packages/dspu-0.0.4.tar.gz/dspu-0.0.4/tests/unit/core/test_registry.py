"""Tests for plugin registry."""

import pytest

from dspu.core.exceptions import ConfigurationError
from dspu.core.registry import Registry


class TestRegistry:
    """Tests for Registry class."""

    def test_register_and_get(self) -> None:
        """Test registering and retrieving a plugin."""
        registry = Registry[int]()
        registry.register("answer", 42)

        assert registry.get("answer") == 42

    def test_register_duplicate_raises_error(self) -> None:
        """Test that registering duplicate name raises error."""
        registry = Registry[str]()
        registry.register("plugin", "value1")

        with pytest.raises(ConfigurationError) as exc_info:
            registry.register("plugin", "value2")

        assert "already registered" in str(exc_info.value)

    def test_get_nonexistent_raises_error(self) -> None:
        """Test that getting nonexistent plugin raises error."""
        registry = Registry[int]()

        with pytest.raises(ConfigurationError) as exc_info:
            registry.get("nonexistent")

        assert "not registered" in str(exc_info.value)

    def test_has(self) -> None:
        """Test checking if plugin exists."""
        registry = Registry[str]()
        registry.register("exists", "value")

        assert registry.has("exists")
        assert not registry.has("does_not_exist")

    def test_list_empty(self) -> None:
        """Test listing plugins when registry is empty."""
        registry = Registry[int]()
        assert registry.list() == []

    def test_list_plugins(self) -> None:
        """Test listing registered plugins."""
        registry = Registry[str]()
        registry.register("plugin_b", "b")
        registry.register("plugin_a", "a")
        registry.register("plugin_c", "c")

        # List should be sorted
        assert registry.list() == ["plugin_a", "plugin_b", "plugin_c"]

    def test_unregister(self) -> None:
        """Test unregistering a plugin."""
        registry = Registry[int]()
        registry.register("temp", 123)

        assert registry.has("temp")
        registry.unregister("temp")
        assert not registry.has("temp")

    def test_unregister_nonexistent_raises_error(self) -> None:
        """Test that unregistering nonexistent plugin raises error."""
        registry = Registry[str]()

        with pytest.raises(ConfigurationError) as exc_info:
            registry.unregister("nonexistent")

        assert "not registered" in str(exc_info.value)

    def test_clear(self) -> None:
        """Test clearing all plugins."""
        registry = Registry[int]()
        registry.register("one", 1)
        registry.register("two", 2)
        registry.register("three", 3)

        assert len(registry.list()) == 3

        registry.clear()

        assert len(registry.list()) == 0
        assert not registry.has("one")

    def test_registry_with_callable(self) -> None:
        """Test registry with callable plugins."""
        registry = Registry[callable]()  # type: ignore[misc]

        def multiply(x: int) -> int:
            return x * 2

        registry.register("multiply", multiply)

        func = registry.get("multiply")
        assert func(5) == 10

    def test_registry_with_class(self) -> None:
        """Test registry with class plugins."""
        registry = Registry[type]()

        class MyClass:
            value = 42

        registry.register("MyClass", MyClass)

        cls = registry.get("MyClass")
        instance = cls()
        assert instance.value == 42

    def test_error_includes_available_plugins(self) -> None:
        """Test that error message includes available plugins."""
        registry = Registry[str]()
        registry.register("plugin_a", "a")
        registry.register("plugin_b", "b")

        with pytest.raises(ConfigurationError) as exc_info:
            registry.get("nonexistent")

        error_str = str(exc_info.value)
        assert "plugin_a" in error_str
        assert "plugin_b" in error_str
