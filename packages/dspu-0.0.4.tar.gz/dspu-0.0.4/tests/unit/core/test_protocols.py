"""Tests for core protocols."""

from typing import Any

import pytest

from dspu.core.protocols import AsyncResource, Closeable, Serializable


class TestSerializable:
    """Tests for Serializable protocol."""

    def test_protocol_check(self) -> None:
        """Test that classes implementing Serializable are recognized."""

        class MySerializable:
            def to_dict(self) -> dict[str, Any]:
                return {"value": 42}

            @classmethod
            def from_dict(cls, data: dict[str, Any]) -> "MySerializable":
                return cls()

        obj = MySerializable()
        assert isinstance(obj, Serializable)

    def test_protocol_check_missing_to_dict(self) -> None:
        """Test that class without to_dict is not Serializable."""

        class NotSerializable:
            @classmethod
            def from_dict(cls, data: dict[str, Any]) -> "NotSerializable":
                return cls()

        obj = NotSerializable()
        assert not isinstance(obj, Serializable)

    def test_protocol_check_missing_from_dict(self) -> None:
        """Test that class without from_dict is not Serializable."""

        class NotSerializable:
            def to_dict(self) -> dict[str, Any]:
                return {}

        obj = NotSerializable()
        assert not isinstance(obj, Serializable)

    def test_serializable_roundtrip(self) -> None:
        """Test serialization roundtrip."""

        class Data:
            def __init__(self, value: int) -> None:
                self.value = value

            def to_dict(self) -> dict[str, Any]:
                return {"value": self.value}

            @classmethod
            def from_dict(cls, data: dict[str, Any]) -> "Data":
                return cls(data["value"])

        original = Data(42)
        serialized = original.to_dict()
        restored = Data.from_dict(serialized)

        assert restored.value == original.value


class TestAsyncResource:
    """Tests for AsyncResource protocol."""

    @pytest.mark.asyncio
    async def test_protocol_check(self) -> None:
        """Test that async context managers are recognized."""

        class MyResource:
            async def __aenter__(self) -> "MyResource":
                return self

            async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
                pass

        resource = MyResource()
        assert isinstance(resource, AsyncResource)

    @pytest.mark.asyncio
    async def test_protocol_check_missing_aenter(self) -> None:
        """Test that class without __aenter__ is not AsyncResource."""

        class NotResource:
            async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
                pass

        resource = NotResource()
        assert not isinstance(resource, AsyncResource)

    @pytest.mark.asyncio
    async def test_async_resource_usage(self) -> None:
        """Test using async resource in context manager."""

        class Resource:
            def __init__(self) -> None:
                self.entered = False
                self.exited = False

            async def __aenter__(self) -> "Resource":
                self.entered = True
                return self

            async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
                self.exited = True

        resource = Resource()
        async with resource as r:
            assert r.entered
            assert not r.exited

        assert resource.exited


class TestCloseable:
    """Tests for Closeable protocol."""

    def test_protocol_check(self) -> None:
        """Test that classes with close() are recognized."""

        class MyCloseable:
            def close(self) -> None:
                pass

            async def aclose(self) -> None:
                self.close()

        obj = MyCloseable()
        assert isinstance(obj, Closeable)

    def test_protocol_check_missing_close(self) -> None:
        """Test that class without close() is not Closeable."""

        class NotCloseable:
            async def aclose(self) -> None:
                pass

        obj = NotCloseable()
        assert not isinstance(obj, Closeable)

    def test_closeable_usage(self) -> None:
        """Test using closeable resource."""

        class Resource:
            def __init__(self) -> None:
                self.closed = False

            def close(self) -> None:
                self.closed = True

            async def aclose(self) -> None:
                self.close()

        resource = Resource()
        assert not resource.closed

        resource.close()
        assert resource.closed

    @pytest.mark.asyncio
    async def test_async_close(self) -> None:
        """Test async close method."""

        class Resource:
            def __init__(self) -> None:
                self.closed = False

            def close(self) -> None:
                self.closed = True

            async def aclose(self) -> None:
                self.close()

        resource = Resource()
        await resource.aclose()
        assert resource.closed
