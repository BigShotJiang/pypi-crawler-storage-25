"""Tests for authentication providers."""

import pytest

from dspu.core.exceptions import ConfigurationError
from dspu.security.auth import (
    JWTProvider,
    StaticTokenProvider,
    create_auth_provider,
)


class TestStaticTokenProvider:
    """Tests for StaticTokenProvider."""

    @pytest.mark.asyncio
    async def test_get_token(self):
        """Test getting static token."""
        provider = StaticTokenProvider(token="my-static-token")
        token = await provider.get_token()
        assert token == "my-static-token"

    @pytest.mark.asyncio
    async def test_get_token_with_scopes(self):
        """Test getting token with scopes (ignored for static)."""
        provider = StaticTokenProvider(token="my-token")
        token = await provider.get_token(scopes=["read", "write"])
        assert token == "my-token"

    @pytest.mark.asyncio
    async def test_refresh_token(self):
        """Test refreshing token (returns same token)."""
        provider = StaticTokenProvider(token="my-token")
        token = await provider.refresh_token()
        assert token == "my-token"

    @pytest.mark.asyncio
    async def test_revoke_token(self):
        """Test revoking token (no-op for static)."""
        provider = StaticTokenProvider(token="my-token")
        await provider.revoke_token()  # Should not raise

    @pytest.mark.asyncio
    async def test_validate_token(self):
        """Test validating token."""
        provider = StaticTokenProvider(token="my-token")

        assert await provider.validate_token("my-token") is True
        assert await provider.validate_token("wrong-token") is False


class TestJWTProvider:
    """Tests for JWTProvider."""

    @pytest.mark.asyncio
    async def test_generate_token(self):
        """Test generating JWT token."""
        provider = JWTProvider(
            secret_key="test-secret",
            algorithm="HS256",
            expiry_seconds=3600,
        )

        token = await provider.get_token()
        assert isinstance(token, str)
        assert len(token) > 0

    @pytest.mark.asyncio
    async def test_generate_token_with_scopes(self):
        """Test generating token with scopes."""
        provider = JWTProvider(secret_key="test-secret")

        token = await provider.get_token(scopes=["read", "write"])
        assert isinstance(token, str)

        # Decode and check scopes
        payload = provider.decode_token(token)
        assert payload["scopes"] == ["read", "write"]

    @pytest.mark.asyncio
    async def test_generate_token_with_issuer_audience(self):
        """Test generating token with issuer and audience."""
        provider = JWTProvider(
            secret_key="test-secret",
            issuer="test-issuer",
            audience="test-audience",
        )

        token = await provider.get_token()
        payload = provider.decode_token(token)

        assert payload["iss"] == "test-issuer"
        assert payload["aud"] == "test-audience"

    @pytest.mark.asyncio
    async def test_validate_token(self):
        """Test validating JWT token."""
        provider = JWTProvider(secret_key="test-secret", expiry_seconds=3600)

        # Generate token
        token = await provider.get_token()

        # Validate it
        assert await provider.validate_token(token) is True

        # Invalid token
        assert await provider.validate_token("invalid.token.here") is False

    @pytest.mark.asyncio
    async def test_validate_token_wrong_secret(self):
        """Test validating token with wrong secret."""
        provider1 = JWTProvider(secret_key="secret1")
        provider2 = JWTProvider(secret_key="secret2")

        token = await provider1.get_token()

        # Should fail with different secret
        assert await provider2.validate_token(token) is False

    @pytest.mark.asyncio
    async def test_refresh_token(self):
        """Test refreshing JWT token."""
        import asyncio

        provider = JWTProvider(secret_key="test-secret", expiry_seconds=1)

        token1 = await provider.get_token()

        # Wait for token to expire
        await asyncio.sleep(1.1)

        # Refresh should generate new token with new timestamp
        token2 = await provider.refresh_token()

        # Should be different tokens (different iat and exp timestamps)
        assert token1 != token2

    @pytest.mark.asyncio
    async def test_revoke_token(self):
        """Test revoking token (clears cache)."""
        provider = JWTProvider(secret_key="test-secret")

        await provider.get_token()
        assert provider._current_token is not None

        await provider.revoke_token()
        assert provider._current_token is None

    @pytest.mark.asyncio
    async def test_decode_token(self):
        """Test decoding token without validation."""
        provider = JWTProvider(
            secret_key="test-secret",
            issuer="test-issuer",
        )

        token = await provider.get_token(scopes=["read"])
        payload = provider.decode_token(token)

        assert "iss" in payload
        assert payload["iss"] == "test-issuer"
        assert "scopes" in payload
        assert payload["scopes"] == ["read"]

    @pytest.mark.asyncio
    async def test_token_caching(self):
        """Test that tokens are cached when not expired."""
        call_count = [0]

        class CountingJWTProvider(JWTProvider):
            async def _generate_token(self, scopes=None):
                call_count[0] += 1
                await super()._generate_token(scopes)

        provider = CountingJWTProvider(secret_key="test-secret", expiry_seconds=3600)

        # First call generates token
        token1 = await provider.get_token()
        assert call_count[0] == 1

        # Second call should use cached token
        token2 = await provider.get_token()
        assert call_count[0] == 1  # No additional call
        assert token1 == token2


class TestCreateAuthProvider:
    """Tests for create_auth_provider factory."""

    def test_create_static_provider(self):
        """Test creating static token provider."""
        provider = create_auth_provider("static", token="my-token")
        assert isinstance(provider, StaticTokenProvider)

    def test_create_static_provider_missing_token(self):
        """Test error when token missing for static provider."""
        with pytest.raises(ConfigurationError, match="requires 'token'"):
            create_auth_provider("static")

    def test_create_jwt_provider(self):
        """Test creating JWT provider."""
        provider = create_auth_provider("jwt", secret_key="secret")
        assert isinstance(provider, JWTProvider)

    def test_create_jwt_provider_missing_secret(self):
        """Test error when secret missing for JWT provider."""
        with pytest.raises(ConfigurationError, match="requires 'secret_key'"):
            create_auth_provider("jwt")

    def test_create_unknown_provider(self):
        """Test error for unknown provider type."""
        with pytest.raises(ConfigurationError, match="Unknown auth provider type"):
            create_auth_provider("unknown_type")


# OAuth2Provider tests are skipped as they require httpx and network calls
@pytest.mark.skip(reason="Requires httpx and mock server")
class TestOAuth2Provider:
    """Tests for OAuth2Provider (requires mocking)."""

    def test_placeholder(self):
        """Placeholder for OAuth2 tests."""
        pass
