"""Tests for SecretManager."""

import os

import pytest

from dspu.security import SecretManager
from dspu.security.backends import EnvBackend, FileBackend
from dspu.security.exceptions import SecretNotFoundError


class TestSecretManager:
    """Tests for SecretManager facade."""

    @pytest.mark.asyncio
    async def test_get_secret(self, tmp_path):
        """Test getting secret through manager."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "secret-123"}}')

        backend = FileBackend(secrets_file)
        manager = SecretManager(backend)

        value = await manager.get("api/key")
        assert value == "secret-123"

    @pytest.mark.asyncio
    async def test_get_secret_with_default(self):
        """Test getting secret with default value."""
        backend = EnvBackend(prefix="NONEXISTENT_")
        manager = SecretManager(backend)

        value = await manager.get("api/key", default="default-value")
        assert value == "default-value"

    @pytest.mark.asyncio
    async def test_get_secret_not_found(self):
        """Test getting non-existent secret raises error."""
        backend = EnvBackend(prefix="NONEXISTENT_")
        manager = SecretManager(backend)

        with pytest.raises(SecretNotFoundError, match="Secret not found"):
            await manager.get("api/key")

    @pytest.mark.asyncio
    async def test_set_secret(self, tmp_path):
        """Test setting secret through manager."""
        secrets_file = tmp_path / "secrets.json"

        backend = FileBackend(secrets_file)
        manager = SecretManager(backend)

        await manager.set("api/key", "new-secret")
        value = await manager.get("api/key")
        assert value == "new-secret"

    @pytest.mark.asyncio
    async def test_delete_secret(self, tmp_path):
        """Test deleting secret through manager."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "value"}}')

        backend = FileBackend(secrets_file)
        manager = SecretManager(backend)

        await manager.delete("api/key")

        with pytest.raises(SecretNotFoundError):
            await manager.get("api/key")

    @pytest.mark.asyncio
    async def test_delete_secret_not_found(self):
        """Test deleting non-existent secret raises error."""
        backend = EnvBackend(prefix="NONEXISTENT_")
        manager = SecretManager(backend)

        with pytest.raises(SecretNotFoundError):
            await manager.delete("nonexistent")

    @pytest.mark.asyncio
    async def test_exists(self, tmp_path):
        """Test checking if secret exists."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "value"}}')

        backend = FileBackend(secrets_file)
        manager = SecretManager(backend)

        assert await manager.exists("api/key") is True
        assert await manager.exists("nonexistent") is False

    @pytest.mark.asyncio
    async def test_list_secrets(self, tmp_path):
        """Test listing secrets."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "v1", "secret": "v2"}}')

        backend = FileBackend(secrets_file)
        manager = SecretManager(backend)

        keys = await manager.list()
        assert "api/key" in keys
        assert "api/secret" in keys

    @pytest.mark.asyncio
    async def test_list_with_prefix(self, tmp_path):
        """Test listing secrets with prefix."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "v1"}, "db": {"password": "v2"}}')

        backend = FileBackend(secrets_file)
        manager = SecretManager(backend)

        api_keys = await manager.list(prefix="api")
        assert len(api_keys) == 1
        assert api_keys[0] == "api/key"

    def test_from_env_vars(self):
        """Test creating manager from environment variables."""
        manager = SecretManager.from_env_vars(prefix="TEST_")
        assert isinstance(manager._backend, EnvBackend)

    def test_from_file(self, tmp_path):
        """Test creating manager from file."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text("{}")

        manager = SecretManager.from_file(str(secrets_file))
        assert isinstance(manager._backend, FileBackend)

    def test_from_env_defaults_to_env_backend(self):
        """Test that from_env defaults to environment backend."""
        # Ensure no Vault or AWS variables are set
        old_vault = os.environ.pop("VAULT_ADDR", None)
        old_token = os.environ.pop("VAULT_TOKEN", None)
        old_aws = os.environ.pop("AWS_SECRET_BACKEND", None)

        try:
            manager = SecretManager.from_env()
            assert isinstance(manager._backend, EnvBackend)
        finally:
            # Restore environment
            if old_vault:
                os.environ["VAULT_ADDR"] = old_vault
            if old_token:
                os.environ["VAULT_TOKEN"] = old_token
            if old_aws:
                os.environ["AWS_SECRET_BACKEND"] = old_aws
