"""Tests for secret backends."""

import os

import pytest

from dspu.security.backends import (
    EnvBackend,
    FileBackend,
)


class TestEnvBackend:
    """Tests for environment variable backend."""

    @pytest.mark.asyncio
    async def test_get_secret(self):
        """Test getting secret from environment variable."""
        backend = EnvBackend(prefix="TEST_")
        os.environ["TEST_API_KEY"] = "secret-value"

        value = await backend.get("api/key")
        assert value == "secret-value"

        del os.environ["TEST_API_KEY"]

    @pytest.mark.asyncio
    async def test_get_secret_not_found(self):
        """Test getting non-existent secret raises KeyError."""
        backend = EnvBackend(prefix="TEST_")

        with pytest.raises(KeyError, match="Environment variable not found"):
            await backend.get("nonexistent/key")

    @pytest.mark.asyncio
    async def test_set_secret(self):
        """Test setting environment variable."""
        backend = EnvBackend(prefix="TEST_")

        await backend.set("new/key", "new-value")
        assert os.environ["TEST_NEW_KEY"] == "new-value"

        del os.environ["TEST_NEW_KEY"]

    @pytest.mark.asyncio
    async def test_delete_secret(self):
        """Test deleting environment variable."""
        backend = EnvBackend(prefix="TEST_")
        os.environ["TEST_DELETE_ME"] = "value"

        await backend.delete("delete/me")
        assert "TEST_DELETE_ME" not in os.environ

    @pytest.mark.asyncio
    async def test_delete_secret_not_found(self):
        """Test deleting non-existent secret raises KeyError."""
        backend = EnvBackend(prefix="TEST_")

        with pytest.raises(KeyError):
            await backend.delete("nonexistent")

    @pytest.mark.asyncio
    async def test_exists(self):
        """Test checking if secret exists."""
        backend = EnvBackend(prefix="TEST_")
        os.environ["TEST_EXISTS"] = "value"

        assert await backend.exists("exists") is True
        assert await backend.exists("nonexistent") is False

        del os.environ["TEST_EXISTS"]

    @pytest.mark.asyncio
    async def test_list_secrets(self):
        """Test listing secrets."""
        backend = EnvBackend(prefix="TEST_SECRET_")

        # Set up test environment variables
        os.environ["TEST_SECRET_API_KEY"] = "value1"
        os.environ["TEST_SECRET_DB_PASSWORD"] = "value2"
        os.environ["OTHER_VAR"] = "value3"

        keys = await backend.list()
        assert "api/key" in keys
        assert "db/password" in keys
        assert "other/var" not in keys  # Different prefix

        # Clean up
        del os.environ["TEST_SECRET_API_KEY"]
        del os.environ["TEST_SECRET_DB_PASSWORD"]
        del os.environ["OTHER_VAR"]

    @pytest.mark.asyncio
    async def test_list_with_prefix(self):
        """Test listing secrets with prefix filter."""
        backend = EnvBackend(prefix="TEST_")

        os.environ["TEST_API_KEY"] = "value1"
        os.environ["TEST_API_SECRET"] = "value2"
        os.environ["TEST_DB_PASSWORD"] = "value3"

        api_keys = await backend.list(prefix="api")
        assert len(api_keys) == 2
        assert all(k.startswith("api") for k in api_keys)

        # Clean up
        del os.environ["TEST_API_KEY"]
        del os.environ["TEST_API_SECRET"]
        del os.environ["TEST_DB_PASSWORD"]

    def test_key_to_env_conversion(self):
        """Test key to environment variable name conversion."""
        backend = EnvBackend(prefix="APP_")

        assert backend._key_to_env("api/key") == "APP_API_KEY"
        assert backend._key_to_env("database/password") == "APP_DATABASE_PASSWORD"
        assert backend._key_to_env("my-service/token") == "APP_MY_SERVICE_TOKEN"


class TestFileBackend:
    """Tests for file-based secret backend."""

    @pytest.mark.asyncio
    async def test_get_secret_from_json(self, tmp_path):
        """Test getting secret from JSON file."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "secret-123"}}')

        backend = FileBackend(secrets_file)
        value = await backend.get("api/key")
        assert value == "secret-123"

    @pytest.mark.asyncio
    async def test_get_secret_from_yaml(self, tmp_path):
        """Test getting secret from YAML file."""
        secrets_file = tmp_path / "secrets.yaml"
        secrets_file.write_text("api:\n  key: secret-456\n")

        backend = FileBackend(secrets_file)
        value = await backend.get("api/key")
        assert value == "secret-456"

    @pytest.mark.asyncio
    async def test_get_secret_not_found(self, tmp_path):
        """Test getting non-existent secret raises KeyError."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "value"}}')

        backend = FileBackend(secrets_file)

        with pytest.raises(KeyError, match="Key not found"):
            await backend.get("nonexistent/key")

    @pytest.mark.asyncio
    async def test_set_secret(self, tmp_path):
        """Test setting secret in file."""
        secrets_file = tmp_path / "secrets.json"

        backend = FileBackend(secrets_file, auto_save=True)
        await backend.set("api/key", "new-secret")

        # Verify it was saved
        value = await backend.get("api/key")
        assert value == "new-secret"

        # Verify file exists and contains data
        assert secrets_file.exists()

    @pytest.mark.asyncio
    async def test_set_nested_secret(self, tmp_path):
        """Test setting nested secret path."""
        secrets_file = tmp_path / "secrets.yaml"

        backend = FileBackend(secrets_file)
        await backend.set("database/prod/password", "secret-pwd")

        value = await backend.get("database/prod/password")
        assert value == "secret-pwd"

    @pytest.mark.asyncio
    async def test_delete_secret(self, tmp_path):
        """Test deleting secret from file."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "value"}}')

        backend = FileBackend(secrets_file)
        await backend.delete("api/key")

        with pytest.raises(KeyError):
            await backend.get("api/key")

    @pytest.mark.asyncio
    async def test_exists(self, tmp_path):
        """Test checking if secret exists in file."""
        secrets_file = tmp_path / "secrets.yaml"
        secrets_file.write_text("api:\n  key: value\n")

        backend = FileBackend(secrets_file)

        assert await backend.exists("api/key") is True
        assert await backend.exists("nonexistent") is False

    @pytest.mark.asyncio
    async def test_list_secrets(self, tmp_path):
        """Test listing secrets from file."""
        secrets_file = tmp_path / "secrets.json"
        secrets_file.write_text('{"api": {"key": "v1", "secret": "v2"}, "db": {"password": "v3"}}')

        backend = FileBackend(secrets_file)
        keys = await backend.list()

        assert len(keys) == 3
        assert "api/key" in keys
        assert "api/secret" in keys
        assert "db/password" in keys

    @pytest.mark.asyncio
    async def test_list_with_prefix(self, tmp_path):
        """Test listing secrets with prefix filter."""
        secrets_file = tmp_path / "secrets.yaml"
        secrets_file.write_text("api:\n  key: v1\n  secret: v2\ndb:\n  password: v3\n")

        backend = FileBackend(secrets_file)
        api_keys = await backend.list(prefix="api")

        assert len(api_keys) == 2
        assert all(k.startswith("api") for k in api_keys)

    @pytest.mark.asyncio
    async def test_nonexistent_file(self, tmp_path):
        """Test handling of non-existent file."""
        secrets_file = tmp_path / "nonexistent.json"

        backend = FileBackend(secrets_file)
        keys = await backend.list()
        assert keys == []

    @pytest.mark.asyncio
    async def test_file_permissions(self, tmp_path):
        """Test that saved files have restrictive permissions."""
        secrets_file = tmp_path / "secrets.json"

        backend = FileBackend(secrets_file)
        await backend.set("test", "value")

        # Check file has 600 permissions (owner read/write only)
        stat = secrets_file.stat()
        permissions = oct(stat.st_mode)[-3:]
        assert permissions == "600"


# Note: VaultBackend and AWSSecretBackend tests would require mocking
# the respective services. These tests are placeholders.


@pytest.mark.skip(reason="Requires Vault server or mocking")
class TestVaultBackend:
    """Tests for Vault backend (requires mocking)."""

    def test_placeholder(self):
        """Placeholder for Vault tests."""
        pass


@pytest.mark.skip(reason="Requires AWS or mocking")
class TestAWSSecretBackend:
    """Tests for AWS Secrets Manager backend (requires mocking)."""

    def test_placeholder(self):
        """Placeholder for AWS tests."""
        pass
