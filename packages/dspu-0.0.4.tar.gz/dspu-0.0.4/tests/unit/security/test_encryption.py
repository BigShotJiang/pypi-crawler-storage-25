"""Tests for encryption utilities."""

import pytest

from dspu.security.encryption import (
    AES,
    Fernet,
    constant_time_compare,
    generate_token,
    hash_data,
    hash_password,
    verify_password,
)
from dspu.security.exceptions import EncryptionError


class TestFernet:
    """Tests for Fernet symmetric encryption."""

    def test_generate_key(self):
        """Test generating Fernet key."""
        key = Fernet.generate_key()
        assert isinstance(key, bytes)
        assert len(key) > 0

    def test_encrypt_decrypt_bytes(self):
        """Test encrypting and decrypting bytes."""
        key = Fernet.generate_key()
        cipher = Fernet(key)

        data = b"secret message"
        encrypted = cipher.encrypt(data)
        decrypted = cipher.decrypt(encrypted)

        assert decrypted == data
        assert encrypted != data  # Should be different

    def test_encrypt_decrypt_string(self):
        """Test encrypting and decrypting string."""
        key = Fernet.generate_key()
        cipher = Fernet(key)

        data = "secret message"
        encrypted = cipher.encrypt(data)
        decrypted_str = cipher.decrypt_str(encrypted)

        assert decrypted_str == data

    def test_decrypt_with_wrong_key(self):
        """Test decryption fails with wrong key."""
        key1 = Fernet.generate_key()
        key2 = Fernet.generate_key()

        cipher1 = Fernet(key1)
        cipher2 = Fernet(key2)

        encrypted = cipher1.encrypt(b"secret")

        with pytest.raises(EncryptionError, match="Decryption failed"):
            cipher2.decrypt(encrypted)

    def test_invalid_key(self):
        """Test error with invalid key."""
        with pytest.raises(EncryptionError, match="Invalid encryption key"):
            Fernet(b"invalid-key")

    def test_string_key(self):
        """Test using string key."""
        key = Fernet.generate_key()
        key_str = key.decode("utf-8")

        cipher = Fernet(key_str)
        encrypted = cipher.encrypt(b"data")
        decrypted = cipher.decrypt(encrypted)

        assert decrypted == b"data"


class TestAES:
    """Tests for AES-256-GCM encryption."""

    def test_generate_key(self):
        """Test generating AES key."""
        key = AES.generate_key()
        assert isinstance(key, bytes)
        assert len(key) == 32  # 256 bits

    def test_encrypt_decrypt_bytes(self):
        """Test encrypting and decrypting bytes."""
        key = AES.generate_key()
        cipher = AES(key)

        data = b"secret data"
        encrypted, nonce = cipher.encrypt(data)
        decrypted = cipher.decrypt(encrypted, nonce)

        assert decrypted == data
        assert encrypted != data

    def test_encrypt_decrypt_string(self):
        """Test encrypting and decrypting string."""
        key = AES.generate_key()
        cipher = AES(key)

        data = "secret message"
        encrypted, nonce = cipher.encrypt(data)
        decrypted_str = cipher.decrypt_str(encrypted, nonce)

        assert decrypted_str == data

    def test_decrypt_with_wrong_key(self):
        """Test decryption fails with wrong key."""
        key1 = AES.generate_key()
        key2 = AES.generate_key()

        cipher1 = AES(key1)
        cipher2 = AES(key2)

        encrypted, nonce = cipher1.encrypt(b"secret")

        with pytest.raises(EncryptionError, match="AES decryption failed"):
            cipher2.decrypt(encrypted, nonce)

    def test_decrypt_with_wrong_nonce(self):
        """Test decryption fails with wrong nonce."""
        key = AES.generate_key()
        cipher = AES(key)

        encrypted, _ = cipher.encrypt(b"secret")
        wrong_nonce = AES.generate_key()[:12]  # Wrong nonce

        with pytest.raises(EncryptionError):
            cipher.decrypt(encrypted, wrong_nonce)

    def test_invalid_key_length(self):
        """Test error with invalid key length."""
        with pytest.raises(EncryptionError, match="AES key must be 32 bytes"):
            AES(b"short-key")

    def test_authenticated_data(self):
        """Test encryption with authenticated data."""
        key = AES.generate_key()
        cipher = AES(key)

        data = b"secret"
        associated_data = b"metadata"

        encrypted, nonce = cipher.encrypt(data, associated_data=associated_data)
        decrypted = cipher.decrypt(encrypted, nonce, associated_data=associated_data)

        assert decrypted == data

    def test_authenticated_data_mismatch(self):
        """Test decryption fails with wrong authenticated data."""
        key = AES.generate_key()
        cipher = AES(key)

        encrypted, nonce = cipher.encrypt(b"secret", associated_data=b"metadata1")

        with pytest.raises(EncryptionError):
            cipher.decrypt(encrypted, nonce, associated_data=b"metadata2")


class TestPasswordHashing:
    """Tests for password hashing utilities."""

    def test_hash_password(self):
        """Test hashing password."""
        hash_str, salt = hash_password("my-password")

        assert isinstance(hash_str, str)
        assert isinstance(salt, bytes)
        assert len(hash_str) > 0
        assert len(salt) == 32

    def test_verify_password_correct(self):
        """Test verifying correct password."""
        password = "my-secure-password"
        hash_str, salt = hash_password(password)

        assert verify_password(password, hash_str, salt) is True

    def test_verify_password_incorrect(self):
        """Test verifying incorrect password."""
        password = "correct-password"
        hash_str, salt = hash_password(password)

        assert verify_password("wrong-password", hash_str, salt) is False

    def test_hash_password_with_custom_salt(self):
        """Test hashing with custom salt."""
        import secrets

        password = "password"
        salt = secrets.token_bytes(32)

        hash1, _ = hash_password(password, salt)
        hash2, _ = hash_password(password, salt)

        # Same password and salt should produce same hash
        assert hash1 == hash2

    def test_different_passwords_different_hashes(self):
        """Test that different passwords produce different hashes."""
        hash1, salt = hash_password("password1")
        hash2, _ = hash_password("password2", salt)

        assert hash1 != hash2


class TestTokenGeneration:
    """Tests for token generation."""

    def test_generate_token_default(self):
        """Test generating token with default length."""
        token = generate_token()
        assert isinstance(token, str)
        assert len(token) > 0

    def test_generate_token_custom_length(self):
        """Test generating token with custom length."""
        token16 = generate_token(16)
        token32 = generate_token(32)

        assert len(token16) < len(token32)

    def test_generate_token_unique(self):
        """Test that generated tokens are unique."""
        tokens = [generate_token() for _ in range(100)]
        assert len(set(tokens)) == 100  # All unique


class TestConstantTimeCompare:
    """Tests for constant-time string comparison."""

    def test_compare_equal_strings(self):
        """Test comparing equal strings."""
        assert constant_time_compare("secret", "secret") is True

    def test_compare_different_strings(self):
        """Test comparing different strings."""
        assert constant_time_compare("secret", "wrong") is False

    def test_compare_different_lengths(self):
        """Test comparing strings of different lengths."""
        assert constant_time_compare("short", "longer-string") is False


class TestHashData:
    """Tests for data hashing."""

    def test_hash_bytes(self):
        """Test hashing bytes."""
        data = b"test data"
        hash_result = hash_data(data, algorithm="sha256")

        assert isinstance(hash_result, str)
        assert len(hash_result) == 64  # SHA256 hex length

    def test_hash_string(self):
        """Test hashing string."""
        data = "test data"
        hash_result = hash_data(data, algorithm="sha256")

        assert isinstance(hash_result, str)
        assert len(hash_result) == 64

    def test_hash_deterministic(self):
        """Test that hashing is deterministic."""
        data = b"test data"
        hash1 = hash_data(data, algorithm="sha256")
        hash2 = hash_data(data, algorithm="sha256")

        assert hash1 == hash2

    def test_hash_different_data(self):
        """Test that different data produces different hashes."""
        hash1 = hash_data(b"data1", algorithm="sha256")
        hash2 = hash_data(b"data2", algorithm="sha256")

        assert hash1 != hash2

    def test_hash_sha512(self):
        """Test hashing with SHA512."""
        data = b"test data"
        hash_result = hash_data(data, algorithm="sha512")

        assert len(hash_result) == 128  # SHA512 hex length

    def test_hash_md5(self):
        """Test hashing with MD5."""
        data = b"test data"
        hash_result = hash_data(data, algorithm="md5")

        assert len(hash_result) == 32  # MD5 hex length
