"""Tests for rotating token management."""

import asyncio
import time

import pytest

from dspu.security.exceptions import TokenExpiredError
from dspu.security.rotating_token import (
    RotatingToken,
    TokenData,
    simple_rotating_token,
)


class TestTokenData:
    """Tests for TokenData class."""

    def test_token_data_creation(self):
        """Test creating TokenData."""
        token_data = TokenData(
            token="test-token",
            expires_at=time.time() + 3600,
            scopes=["read", "write"],
        )

        assert token_data.token == "test-token"
        assert token_data.expires_at is not None
        assert token_data.scopes == ["read", "write"]

    def test_is_expired(self):
        """Test checking if token is expired."""
        # Future expiry
        future_token = TokenData(token="token", expires_at=time.time() + 3600)
        assert future_token.is_expired() is False

        # Past expiry
        past_token = TokenData(token="token", expires_at=time.time() - 10)
        assert past_token.is_expired() is True

        # No expiry
        no_expiry_token = TokenData(token="token", expires_at=None)
        assert no_expiry_token.is_expired() is False

    def test_expires_in(self):
        """Test getting time until expiry."""
        # Future expiry
        future_token = TokenData(token="token", expires_at=time.time() + 60)
        expires_in = future_token.expires_in()
        assert expires_in is not None
        assert 55 < expires_in <= 60  # Allow for execution time

        # No expiry
        no_expiry_token = TokenData(token="token", expires_at=None)
        assert no_expiry_token.expires_in() is None

    def test_should_refresh(self):
        """Test checking if token should be refreshed."""
        # Token expiring soon
        soon_token = TokenData(token="token", expires_at=time.time() + 100)
        assert soon_token.should_refresh(refresh_before=200) is True
        assert soon_token.should_refresh(refresh_before=50) is False

        # No expiry
        no_expiry_token = TokenData(token="token", expires_at=None)
        assert no_expiry_token.should_refresh() is False


class TestRotatingToken:
    """Tests for RotatingToken manager."""

    @pytest.mark.asyncio
    async def test_basic_token_rotation(self):
        """Test basic token rotation functionality."""
        call_count = 0

        async def fetch_token() -> TokenData:
            nonlocal call_count
            call_count += 1
            return TokenData(
                token=f"token-{call_count}",
                expires_at=time.time() + 10,
            )

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=None,  # Don't auto-refresh for this test
        ) as rotating_token:
            # Token should be fetched once on entry
            assert call_count == 1
            assert rotating_token.current == "token-1"

    @pytest.mark.asyncio
    async def test_manual_refresh(self):
        """Test manually triggering token refresh."""
        call_count = 0

        async def fetch_token() -> TokenData:
            nonlocal call_count
            call_count += 1
            return TokenData(token=f"token-{call_count}")

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=None,
        ) as rotating_token:
            assert rotating_token.current == "token-1"

            # Manual refresh
            await rotating_token.refresh()
            assert rotating_token.current == "token-2"
            assert call_count == 2

    @pytest.mark.asyncio
    async def test_automatic_refresh(self):
        """Test automatic token refresh at intervals."""
        call_count = 0

        async def fetch_token() -> TokenData:
            nonlocal call_count
            call_count += 1
            return TokenData(token=f"token-{call_count}")

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=0.5,  # Refresh every 0.5 seconds
        ):
            assert call_count == 1

            # Wait for automatic refresh
            await asyncio.sleep(0.6)

            # Should have refreshed automatically
            assert call_count >= 2

    @pytest.mark.asyncio
    async def test_expired_token_raises_error(self):
        """Test that accessing expired token raises error."""

        async def fetch_token() -> TokenData:
            # Return already-expired token
            return TokenData(token="expired", expires_at=time.time() - 10)

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=None,
        ) as rotating_token:
            with pytest.raises(TokenExpiredError, match="Token is expired"):
                _ = rotating_token.current

    @pytest.mark.asyncio
    async def test_token_not_initialized(self):
        """Test error when token not initialized."""

        async def fetch_token() -> TokenData:
            return TokenData(token="test")

        rotating_token = RotatingToken(fetch_fn=fetch_token)

        with pytest.raises(RuntimeError, match="Token not initialized"):
            _ = rotating_token.current

    @pytest.mark.asyncio
    async def test_is_expired(self):
        """Test checking if token is expired."""

        async def fetch_token() -> TokenData:
            return TokenData(token="test", expires_at=time.time() + 60)

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=None,
        ) as rotating_token:
            assert rotating_token.is_expired() is False

    @pytest.mark.asyncio
    async def test_refresh_callback(self):
        """Test refresh callback is called."""
        callback_count = 0

        async def fetch_token() -> TokenData:
            return TokenData(token="test")

        async def on_refresh(token_data: TokenData) -> None:
            nonlocal callback_count
            callback_count += 1

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=None,
            on_refresh=on_refresh,
        ) as rotating_token:
            # Initial fetch should trigger callback
            assert callback_count == 1

            # Manual refresh should trigger callback
            await rotating_token.refresh()
            assert callback_count == 2

    @pytest.mark.asyncio
    async def test_token_data_property(self):
        """Test accessing full token data."""

        async def fetch_token() -> TokenData:
            return TokenData(
                token="test",
                scopes=["read", "write"],
                metadata={"custom": "data"},
            )

        async with RotatingToken(
            fetch_fn=fetch_token,
            refresh_interval=None,
        ) as rotating_token:
            token_data = rotating_token.token_data
            assert token_data is not None
            assert token_data.token == "test"
            assert token_data.scopes == ["read", "write"]
            assert token_data.metadata["custom"] == "data"


class TestSimpleRotatingToken:
    """Tests for simple_rotating_token helper."""

    @pytest.mark.asyncio
    async def test_simple_rotating_token(self):
        """Test simple rotating token helper."""
        call_count = 0

        async def fetch_token_str() -> str:
            nonlocal call_count
            call_count += 1
            return f"token-{call_count}"

        rotating_token = await simple_rotating_token(
            fetch_fn=fetch_token_str,
            refresh_interval=3600,
        )

        async with rotating_token as rt:
            assert rt.current == "token-1"
            assert call_count == 1
