"""Tests for ID generation utilities."""

import time

import pytest

from dspu.ml import IDError, IDGenerator


class TestIDGenerator:
    """Tests for IDGenerator."""

    def test_uuid4_format(self):
        """Test UUID v4 format."""
        id1 = IDGenerator.uuid4()

        assert len(id1) == 36
        assert id1.count("-") == 4

    def test_uuid4_uniqueness(self):
        """Test UUID v4 generates unique IDs."""
        ids = [IDGenerator.uuid4() for _ in range(100)]

        assert len(set(ids)) == 100  # All unique

    def test_uuid1_format(self):
        """Test UUID v1 format."""
        id1 = IDGenerator.uuid1()

        assert len(id1) == 36
        assert id1.count("-") == 4

    def test_ulid_format(self):
        """Test ULID format."""
        ulid = IDGenerator.ulid()

        assert len(ulid) == 26
        assert ulid.isupper()  # Base32 uppercase

    def test_ulid_sortability(self):
        """Test ULIDs are lexicographically sortable."""
        ulid1 = IDGenerator.ulid()
        time.sleep(0.002)  # Ensure different timestamp
        ulid2 = IDGenerator.ulid()

        assert ulid1 < ulid2  # Sortable by time

    def test_ulid_uniqueness(self):
        """Test ULID generates unique IDs."""
        ids = [IDGenerator.ulid() for _ in range(100)]

        assert len(set(ids)) == 100  # All unique

    def test_hash_text_sha256(self):
        """Test hash_text with SHA256."""
        hash1 = IDGenerator.hash_text("hello", algo="sha256")
        hash2 = IDGenerator.hash_text("hello", algo="sha256")

        assert hash1 == hash2  # Deterministic
        assert len(hash1) == 64  # SHA256 produces 64 hex chars

    def test_hash_text_different_inputs(self):
        """Test different inputs produce different hashes."""
        hash1 = IDGenerator.hash_text("hello")
        hash2 = IDGenerator.hash_text("world")

        assert hash1 != hash2

    def test_hash_text_md5(self):
        """Test hash_text with MD5."""
        hash_val = IDGenerator.hash_text("test", algo="md5")

        assert len(hash_val) == 32  # MD5 produces 32 hex chars

    def test_hash_text_sha512(self):
        """Test hash_text with SHA512."""
        hash_val = IDGenerator.hash_text("test", algo="sha512")

        assert len(hash_val) == 128  # SHA512 produces 128 hex chars

    def test_hash_text_with_length(self):
        """Test hash truncation."""
        hash_val = IDGenerator.hash_text("test", algo="sha256", length=16)

        assert len(hash_val) == 16

    def test_hash_text_invalid_algo(self):
        """Test invalid algorithm raises error."""
        with pytest.raises(IDError):
            IDGenerator.hash_text("test", algo="invalid")

    def test_hash_row_basic(self):
        """Test hash_row basic functionality."""
        row = {"name": "Alice", "age": 30}
        hash1 = IDGenerator.hash_row(row)
        hash2 = IDGenerator.hash_row(row)

        assert hash1 == hash2  # Deterministic

    def test_hash_row_with_columns(self):
        """Test hash_row with specific columns."""
        row = {"name": "Alice", "age": 30, "city": "NYC"}

        hash1 = IDGenerator.hash_row(row, columns=["name"])
        hash2 = IDGenerator.hash_row(row, columns=["name", "age"])

        assert hash1 != hash2  # Different columns = different hash

    def test_hash_row_column_order_matters(self):
        """Test hash_row is consistent with column order."""
        row = {"name": "Alice", "age": 30}

        hash1 = IDGenerator.hash_row(row, columns=["name", "age"])
        hash2 = IDGenerator.hash_row(row, columns=["name", "age"])

        assert hash1 == hash2  # Same order = same hash

    def test_hash_row_handles_none(self):
        """Test hash_row handles None values."""
        row = {"name": "Alice", "age": None}
        hash_val = IDGenerator.hash_row(row)

        assert isinstance(hash_val, str)

    def test_add_id_column_uuid4(self):
        """Test add_id_column with UUID v4."""
        table = [{"name": "Alice"}, {"name": "Bob"}]

        IDGenerator.add_id_column(table, id_col="id", method="uuid4")

        assert "id" in table[0]
        assert "id" in table[1]
        assert table[0]["id"] != table[1]["id"]  # Different IDs

    def test_add_id_column_ulid(self):
        """Test add_id_column with ULID."""
        table = [{"name": "Alice"}, {"name": "Bob"}]

        IDGenerator.add_id_column(table, id_col="id", method="ulid")

        assert "id" in table[0]
        assert len(table[0]["id"]) == 26

    def test_add_id_column_hash(self):
        """Test add_id_column with hash."""
        table = [{"name": "Alice"}, {"name": "Bob"}]

        IDGenerator.add_id_column(table, id_col="id", method="hash", hash_columns=["name"])

        assert "id" in table[0]
        # Same name should produce same hash
        table2 = [{"name": "Alice"}]
        IDGenerator.add_id_column(table2, id_col="id", method="hash", hash_columns=["name"])
        assert table[0]["id"] == table2[0]["id"]

    def test_add_id_column_sequential(self):
        """Test add_id_column with sequential IDs."""
        table = [{"name": "Alice"}, {"name": "Bob"}, {"name": "Charlie"}]

        IDGenerator.add_id_column(table, id_col="id", method="sequential", start=10)

        assert table[0]["id"] == 10
        assert table[1]["id"] == 11
        assert table[2]["id"] == 12

    def test_add_id_column_returns_table(self):
        """Test add_id_column returns the modified table."""
        table = [{"name": "Alice"}]

        result = IDGenerator.add_id_column(table, id_col="id")

        assert result is table  # Same object

    def test_add_id_column_invalid_method(self):
        """Test invalid method raises error."""
        table = [{"name": "Alice"}]

        with pytest.raises(IDError):
            IDGenerator.add_id_column(table, method="invalid")

    def test_add_id_column_hash_without_columns(self):
        """Test hash method without hash_columns raises error."""
        table = [{"name": "Alice"}]

        with pytest.raises(IDError):
            IDGenerator.add_id_column(table, method="hash")
