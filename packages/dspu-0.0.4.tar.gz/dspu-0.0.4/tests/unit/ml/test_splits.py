"""Tests for data splitting utilities."""

import pytest

from dspu.ml import DataSplitter, SplitError


class TestTrainTestSplit:
    """Tests for train_test_split."""

    def test_basic_split(self):
        """Test basic train/test split."""
        X = list(range(100))
        y = [i % 2 for i in range(100)]

        X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
            X, y, test_size=0.25, random_state=42
        )

        assert len(X_train) == 75
        assert len(X_test) == 25
        assert len(y_train) == 75
        assert len(y_test) == 25

    def test_no_overlap(self):
        """Test train and test sets don't overlap."""
        X = list(range(100))

        X_train, X_test, _, _ = DataSplitter.train_test_split(X, test_size=0.25, random_state=42)

        train_set = set(X_train)
        test_set = set(X_test)

        assert len(train_set & test_set) == 0  # No overlap

    def test_covers_all_data(self):
        """Test train + test covers all data."""
        X = list(range(100))

        X_train, X_test, _, _ = DataSplitter.train_test_split(X, test_size=0.25, random_state=42)

        assert set(X_train + X_test) == set(X)

    def test_reproducibility(self):
        """Test same seed produces same split."""
        X = list(range(100))
        y = list(range(100))

        result1 = DataSplitter.train_test_split(X, y, test_size=0.25, random_state=42)
        result2 = DataSplitter.train_test_split(X, y, test_size=0.25, random_state=42)

        X_train1, X_test1, y_train1, y_test1 = result1
        X_train2, X_test2, y_train2, y_test2 = result2

        assert X_train1 == X_train2
        assert X_test1 == X_test2

    def test_stratified_split(self):
        """Test stratified split maintains class distribution."""
        X = list(range(100))
        y = [0] * 30 + [1] * 70  # Imbalanced: 30% class 0, 70% class 1

        X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
            X, y, test_size=0.25, stratify=y, random_state=42
        )

        # Check class distribution in train/test
        train_class0_ratio = y_train.count(0) / len(y_train)
        test_class0_ratio = y_test.count(0) / len(y_test)

        # Both should be close to 0.3 (30%)
        assert abs(train_class0_ratio - 0.3) < 0.1
        assert abs(test_class0_ratio - 0.3) < 0.1

    def test_without_labels(self):
        """Test split without labels."""
        X = list(range(100))

        X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
            X, test_size=0.25, random_state=42
        )

        assert y_train is None
        assert y_test is None
        assert len(X_train) == 75
        assert len(X_test) == 25

    def test_invalid_test_size(self):
        """Test invalid test_size raises error."""
        X = list(range(10))

        with pytest.raises(SplitError):
            DataSplitter.train_test_split(X, test_size=1.5)

        with pytest.raises(SplitError):
            DataSplitter.train_test_split(X, test_size=0.0)

    def test_mismatched_lengths(self):
        """Test mismatched X and y lengths raise error."""
        X = list(range(10))
        y = list(range(5))

        with pytest.raises(SplitError):
            DataSplitter.train_test_split(X, y)


class TestTrainValTestSplit:
    """Tests for train_val_test_split."""

    def test_three_way_split(self):
        """Test three-way split."""
        X = list(range(100))
        y = list(range(100))

        splits = DataSplitter.train_val_test_split(
            X, y, test_size=0.2, val_size=0.1, random_state=42
        )
        X_train, X_val, X_test, y_train, y_val, y_test = splits

        assert len(X_train) + len(X_val) + len(X_test) == 100
        assert len(X_test) == 20  # 20%
        assert len(X_val) == 10  # 10%
        assert len(X_train) == 70  # 70%

    def test_no_overlap_three_way(self):
        """Test no overlap between train/val/test."""
        X = list(range(100))

        splits = DataSplitter.train_val_test_split(X, test_size=0.2, val_size=0.1, random_state=42)
        X_train, X_val, X_test, _, _, _ = splits

        train_set = set(X_train)
        val_set = set(X_val)
        test_set = set(X_test)

        assert len(train_set & val_set) == 0
        assert len(train_set & test_set) == 0
        assert len(val_set & test_set) == 0

    def test_invalid_sizes(self):
        """Test invalid size combination raises error."""
        X = list(range(100))

        with pytest.raises(SplitError):
            DataSplitter.train_val_test_split(X, test_size=0.6, val_size=0.5)


class TestKFoldSplit:
    """Tests for kfold_split."""

    def test_basic_kfold(self):
        """Test basic K-fold split."""
        X = list(range(100))

        folds = DataSplitter.kfold_split(X, n_splits=5, random_state=42)

        assert len(folds) == 5

        for train_idx, val_idx in folds:
            assert len(train_idx) == 80  # 4/5 of data
            assert len(val_idx) == 20  # 1/5 of data

    def test_kfold_no_overlap_within_fold(self):
        """Test train and val don't overlap within each fold."""
        X = list(range(100))

        folds = DataSplitter.kfold_split(X, n_splits=5, random_state=42)

        for train_idx, val_idx in folds:
            assert len(set(train_idx) & set(val_idx)) == 0

    def test_kfold_covers_all_data(self):
        """Test each sample appears in validation exactly once."""
        X = list(range(100))

        folds = DataSplitter.kfold_split(X, n_splits=5, random_state=42)

        all_val_indices = []
        for _, val_idx in folds:
            all_val_indices.extend(val_idx)

        assert sorted(all_val_indices) == list(range(100))

    def test_kfold_reproducibility(self):
        """Test same seed produces same folds."""
        X = list(range(100))

        folds1 = DataSplitter.kfold_split(X, n_splits=5, random_state=42)
        folds2 = DataSplitter.kfold_split(X, n_splits=5, random_state=42)

        assert folds1 == folds2

    def test_kfold_invalid_n_splits(self):
        """Test invalid n_splits raises error."""
        X = list(range(10))

        with pytest.raises(SplitError):
            DataSplitter.kfold_split(X, n_splits=1)

        with pytest.raises(SplitError):
            DataSplitter.kfold_split(X, n_splits=20)  # More than n_samples


class TestStratifiedKFold:
    """Tests for stratified_kfold."""

    def test_stratified_kfold_basic(self):
        """Test basic stratified K-fold."""
        y = [0] * 50 + [1] * 50

        folds = DataSplitter.stratified_kfold(y, n_splits=5, random_state=42)

        assert len(folds) == 5

    def test_stratified_preserves_distribution(self):
        """Test stratified K-fold preserves class distribution."""
        y = [0] * 30 + [1] * 70  # 30% class 0, 70% class 1

        folds = DataSplitter.stratified_kfold(y, n_splits=5, random_state=42)

        for train_idx, val_idx in folds:
            train_labels = [y[i] for i in train_idx]
            val_labels = [y[i] for i in val_idx]

            train_ratio = train_labels.count(0) / len(train_labels)
            val_ratio = val_labels.count(0) / len(val_labels)

            # Both should be close to 0.3
            assert abs(train_ratio - 0.3) < 0.1
            assert abs(val_ratio - 0.3) < 0.1

    def test_stratified_insufficient_samples(self):
        """Test error when class has too few samples."""
        y = [0, 1, 1, 1, 1]  # Class 0 has only 1 sample

        with pytest.raises(SplitError):
            DataSplitter.stratified_kfold(y, n_splits=5)


class TestTimeSeriesSplit:
    """Tests for time_series_split."""

    def test_basic_time_series_split(self):
        """Test basic time series split."""
        X = list(range(100))

        splits = DataSplitter.time_series_split(X, n_splits=4)

        assert len(splits) == 4

    def test_time_series_no_future_leakage(self):
        """Test validation data is always after training data."""
        X = list(range(100))

        splits = DataSplitter.time_series_split(X, n_splits=4)

        for train_idx, val_idx in splits:
            # All training indices should be < all validation indices
            assert max(train_idx) < min(val_idx)

    def test_time_series_progressive_training(self):
        """Test training set grows progressively."""
        X = list(range(100))

        splits = DataSplitter.time_series_split(X, n_splits=3)

        train_sizes = [len(train_idx) for train_idx, _ in splits]

        # Each fold should have more training data than the previous
        assert train_sizes[0] < train_sizes[1] < train_sizes[2]

    def test_time_series_max_train_size(self):
        """Test max_train_size parameter."""
        X = list(range(100))

        splits = DataSplitter.time_series_split(X, n_splits=3, max_train_size=20)

        for train_idx, _ in splits:
            assert len(train_idx) <= 20


class TestGroupSplit:
    """Tests for group_split."""

    def test_basic_group_split(self):
        """Test basic group split."""
        X = [[1], [2], [3], [4], [5], [6]]
        y = [0, 0, 1, 1, 0, 1]
        groups = ["A", "A", "B", "B", "C", "C"]

        X_train, X_test, y_train, y_test = DataSplitter.group_split(
            X, groups, y, test_size=0.33, random_state=42
        )

        # Check we got data back
        assert len(X_train) + len(X_test) == 6

    def test_group_no_leakage(self):
        """Test groups don't appear in both train and test."""
        X = list(range(12))
        groups = ["A"] * 3 + ["B"] * 3 + ["C"] * 3 + ["D"] * 3

        X_train, X_test, _, _ = DataSplitter.group_split(X, groups, test_size=0.25, random_state=42)

        # Get groups in train and test
        train_groups = set()
        test_groups = set()

        for idx in X_train:
            train_groups.add(groups[idx])
        for idx in X_test:
            test_groups.add(groups[idx])

        # No overlap
        assert len(train_groups & test_groups) == 0

    def test_group_split_mismatched_lengths(self):
        """Test mismatched lengths raise error."""
        X = list(range(10))
        groups = ["A"] * 5

        with pytest.raises(SplitError):
            DataSplitter.group_split(X, groups)
