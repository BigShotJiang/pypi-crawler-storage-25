"""Tests for categorical encoding."""

import tempfile

import pytest

from dspu.ml import Encoder, EncodingError


class TestEncoder:
    """Tests for Encoder class."""

    def test_label_encoding(self):
        """Test label encoding."""
        encoder = Encoder(method="label")
        categories = ["cat", "dog", "cat", "bird"]

        encoded = encoder.fit_transform(categories)

        assert len(encoded) == 4
        assert encoded[0] == encoded[2]  # Same category = same code
        assert encoded[0] != encoded[1]  # Different categories = different codes

    def test_label_encoding_sorted(self):
        """Test label encoding uses sorted order."""
        encoder = Encoder(method="label")
        encoder.fit(["cat", "dog", "bird"])

        # Should be sorted: bird=0, cat=1, dog=2
        assert encoder.transform(["bird"]) == [0]
        assert encoder.transform(["cat"]) == [1]
        assert encoder.transform(["dog"]) == [2]

    def test_onehot_encoding(self):
        """Test one-hot encoding."""
        encoder = Encoder(method="onehot")
        categories = ["cat", "dog", "bird"]

        encoded = encoder.fit_transform(categories)

        assert len(encoded) == 3
        assert all(len(vec) == 3 for vec in encoded)  # 3 categories
        assert all(sum(vec) == 1 for vec in encoded)  # One-hot property

    def test_onehot_get_feature_names(self):
        """Test getting feature names for one-hot."""
        encoder = Encoder(method="onehot")
        encoder.fit(["A", "B", "C"])

        names = encoder.get_feature_names("category")

        assert names == ["category_A", "category_B", "category_C"]

    def test_ordinal_encoding(self):
        """Test ordinal encoding with custom order."""
        encoder = Encoder(method="ordinal", categories=["low", "medium", "high"])
        categories = ["high", "low", "medium"]

        encoded = encoder.fit_transform(categories)

        assert encoded == [2, 0, 1]  # Based on provided order

    def test_frequency_encoding(self):
        """Test frequency encoding."""
        encoder = Encoder(method="frequency")
        categories = ["A", "A", "A", "B"]  # A=75%, B=25%

        encoded = encoder.fit_transform(categories)

        assert abs(encoded[0] - 0.75) < 0.01  # A frequency
        assert abs(encoded[3] - 0.25) < 0.01  # B frequency

    def test_handle_unknown_error(self):
        """Test unknown category raises error."""
        encoder = Encoder(method="label", handle_unknown="error")
        encoder.fit(["A", "B"])

        with pytest.raises(EncodingError):
            encoder.transform(["C"])  # Unknown category

    def test_handle_unknown_default(self):
        """Test unknown category uses default value."""
        encoder = Encoder(method="label", handle_unknown="use_default", unknown_value=-1)
        encoder.fit(["A", "B"])

        encoded = encoder.transform(["C"])

        assert encoded == [-1]

    def test_handle_unknown_ignore(self):
        """Test unknown category is ignored."""
        encoder = Encoder(method="label", handle_unknown="ignore")
        encoder.fit(["A", "B"])

        encoded = encoder.transform(["A", "C", "B"])  # C is unknown

        assert len(encoded) == 2  # C was filtered out

    def test_inverse_transform(self):
        """Test inverse transformation."""
        encoder = Encoder(method="label")
        categories = ["cat", "dog", "bird"]
        encoder.fit(categories)

        encoded = encoder.transform(categories)
        decoded = encoder.inverse_transform(encoded)

        # Transform then inverse should give back original
        assert decoded == ["cat", "dog", "bird"]

    def test_save_and_load_state(self):
        """Test state serialization."""
        encoder = Encoder(method="label")
        encoder.fit(["A", "B", "C"])

        # Save state
        state = encoder.save_state()

        # Load into new encoder
        new_encoder = Encoder.from_state(state)

        # Should produce same results
        result1 = encoder.transform(["A", "C"])
        result2 = new_encoder.transform(["A", "C"])

        assert result1 == result2

    def test_save_to_file(self):
        """Test saving to file."""
        encoder = Encoder(method="label")
        encoder.fit(["A", "B", "C"])

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            filepath = f.name

        encoder.save_to_file(filepath)

        # Load from file
        loaded_encoder = Encoder.load_from_file(filepath)

        # Should produce same results
        result1 = encoder.transform(["A", "C"])
        result2 = loaded_encoder.transform(["A", "C"])

        assert result1 == result2

    def test_transform_before_fit_raises(self):
        """Test transform before fit raises error."""
        encoder = Encoder(method="label")

        with pytest.raises(EncodingError):
            encoder.transform(["A"])

    def test_invalid_method_raises(self):
        """Test invalid method raises error."""
        with pytest.raises(EncodingError):
            Encoder(method="invalid")

    def test_ordinal_without_categories_raises(self):
        """Test ordinal without categories raises error."""
        with pytest.raises(EncodingError):
            Encoder(method="ordinal")

    def test_invalid_handle_unknown_raises(self):
        """Test invalid handle_unknown strategy raises error."""
        with pytest.raises(EncodingError, match="Invalid handle_unknown"):
            Encoder(method="label", handle_unknown="invalid_strategy")

    def test_fit_empty_data_raises(self):
        """Test fitting on empty data raises error."""
        encoder = Encoder(method="label")
        with pytest.raises(EncodingError, match="Cannot fit on empty data"):
            encoder.fit([])

    def test_inverse_transform_before_fit_raises(self):
        """Test inverse_transform before fit raises error."""
        encoder = Encoder(method="label")
        with pytest.raises(EncodingError, match="not fitted"):
            encoder.inverse_transform([0, 1])

    def test_save_state_unfitted_raises(self):
        """Test saving state before fitting raises error."""
        encoder = Encoder(method="label")
        with pytest.raises(EncodingError, match="unfitted"):
            encoder.save_state()

    def test_save_to_file_unfitted_raises(self):
        """Test saving to file before fitting raises error."""
        encoder = Encoder(method="label")
        with pytest.raises(EncodingError, match="unfitted"):
            encoder.save_to_file("test.json")

    def test_onehot_inverse_transform_not_supported(self):
        """Test inverse transform not supported for one-hot encoding."""
        encoder = Encoder(method="onehot")
        categories = ["A", "B", "C"]
        encoder.fit(categories)

        encoded = encoder.transform(categories)

        with pytest.raises(EncodingError, match="inverse_transform not supported"):
            encoder.inverse_transform(encoded)

    def test_ordinal_inverse_transform(self):
        """Test inverse transform for ordinal encoding."""
        encoder = Encoder(method="ordinal", categories=["low", "medium", "high"])
        categories = ["low", "high", "medium"]
        encoder.fit(categories)

        encoded = encoder.transform(categories)
        decoded = encoder.inverse_transform(encoded)

        assert decoded == categories

    def test_frequency_inverse_transform_not_supported(self):
        """Test inverse transform not supported for frequency encoding."""
        encoder = Encoder(method="frequency")
        encoder.fit(["A", "A", "B"])

        with pytest.raises(EncodingError, match="inverse_transform not supported"):
            encoder.inverse_transform([0.67, 0.67, 0.33])

    def test_get_feature_names_unfitted_raises(self):
        """Test get_feature_names before fit raises error."""
        encoder = Encoder(method="onehot")
        with pytest.raises(EncodingError, match="not fitted"):
            encoder.get_feature_names()

    def test_get_feature_names_not_supported(self):
        """Test get_feature_names not supported for non-onehot."""
        encoder = Encoder(method="label")
        encoder.fit(["A", "B"])
        with pytest.raises(EncodingError, match="only available for method='onehot'"):
            encoder.get_feature_names()

    def test_inverse_transform_unknown_code_raises(self):
        """Test inverse transform with unknown code raises error."""
        encoder = Encoder(method="label")
        encoder.fit(["A", "B"])

        with pytest.raises(EncodingError, match="Unknown code"):
            encoder.inverse_transform([0, 99])
