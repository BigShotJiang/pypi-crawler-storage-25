"""Tests for statistical utilities."""

import pytest

from dspu.ml import Stats, StatsError


class TestBasicStats:
    """Tests for basic statistical functions."""

    def test_mean(self):
        """Test mean calculation."""
        assert Stats.mean([1, 2, 3, 4, 5]) == 3.0

    def test_mean_empty_raises(self):
        """Test mean of empty list raises error."""
        with pytest.raises(StatsError):
            Stats.mean([])

    def test_median_odd(self):
        """Test median with odd number of elements."""
        assert Stats.median([1, 2, 3, 4, 5]) == 3

    def test_median_even(self):
        """Test median with even number of elements."""
        assert Stats.median([1, 2, 3, 4]) == 2.5

    def test_std(self):
        """Test standard deviation."""
        data = [1, 2, 3, 4, 5]
        std = Stats.std(data, ddof=0)
        assert isinstance(std, float)
        assert std > 0

    def test_std_ddof(self):
        """Test std with degrees of freedom."""
        data = [1, 2, 3, 4, 5]
        std_pop = Stats.std(data, ddof=0)
        std_sample = Stats.std(data, ddof=1)

        assert std_sample > std_pop  # Sample std is larger


class TestCorrelation:
    """Tests for correlation functions."""

    def test_pearson_correlation(self):
        """Test Pearson correlation."""
        x = [1, 2, 3, 4, 5]
        y = [2, 4, 6, 8, 10]  # Perfect linear correlation

        corr = Stats.correlation(x, y, method="pearson")
        assert abs(corr - 1.0) < 0.01  # Should be ~1.0

    def test_spearman_correlation(self):
        """Test Spearman correlation."""
        x = [1, 2, 3, 4, 5]
        y = [1, 4, 9, 16, 25]  # Monotonic but not linear

        corr = Stats.correlation(x, y, method="spearman")
        assert abs(corr - 1.0) < 0.01  # Should be 1.0 (monotonic)

    def test_kendall_correlation(self):
        """Test Kendall's tau correlation."""
        x = [1, 2, 3, 4, 5]
        y = [1, 2, 3, 4, 5]

        corr = Stats.correlation(x, y, method="kendall")
        assert abs(corr - 1.0) < 0.01

    def test_correlation_mismatched_lengths(self):
        """Test correlation with mismatched lengths raises error."""
        x = [1, 2, 3]
        y = [1, 2]

        with pytest.raises(StatsError):
            Stats.correlation(x, y)


class TestTTest:
    """Tests for t-test."""

    def test_t_test_independent_basic(self):
        """Test basic t-test."""
        sample1 = [1, 2, 3, 4, 5]
        sample2 = [2, 3, 4, 5, 6]

        t_stat, p_val = Stats.t_test_independent(sample1, sample2)

        assert isinstance(t_stat, float)
        assert isinstance(p_val, float)
        assert 0 <= p_val <= 1

    def test_t_test_too_small_sample(self):
        """Test t-test with insufficient samples raises error."""
        sample1 = [1]
        sample2 = [2, 3]

        with pytest.raises(StatsError):
            Stats.t_test_independent(sample1, sample2)


class TestBootstrap:
    """Tests for bootstrap methods."""

    def test_bootstrap_ci(self):
        """Test bootstrap confidence interval."""
        data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

        estimate, lower, upper = Stats.bootstrap_ci(data, n_bootstrap=100, random_state=42)

        assert lower <= estimate <= upper
        assert isinstance(estimate, float)

    def test_ab_test_uplift(self):
        """Test A/B test uplift calculation."""
        group_a = [10, 12, 11, 13, 12]
        group_b = [15, 16, 14, 17, 16]

        result = Stats.ab_test_uplift(group_a, group_b, n_bootstrap=100, random_state=42)

        assert "a_mean" in result
        assert "b_mean" in result
        assert "absolute_uplift" in result
        assert "relative_uplift" in result
        assert result["b_mean"] > result["a_mean"]


class TestOutlierDetection:
    """Tests for outlier detection."""

    def test_detect_outliers_iqr(self):
        """Test IQR outlier detection."""
        data = [1, 2, 3, 4, 5, 100]  # 100 is outlier

        outliers = Stats.detect_outliers(data, method="iqr")

        assert 5 in outliers  # Index of 100

    def test_detect_outliers_zscore(self):
        """Test Z-score outlier detection."""
        # Use more extreme outlier with larger dataset
        data = [*list(range(1, 21)), 1000]  # 1000 is extreme outlier

        outliers = Stats.detect_outliers(data, method="zscore")

        assert 20 in outliers  # Index of 1000

    def test_detect_outliers_no_outliers(self):
        """Test no outliers detected in normal data."""
        data = [1, 2, 3, 4, 5]

        outliers = Stats.detect_outliers(data, method="iqr")

        assert len(outliers) == 0
