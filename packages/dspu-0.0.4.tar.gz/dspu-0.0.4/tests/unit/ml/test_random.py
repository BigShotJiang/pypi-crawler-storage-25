"""Tests for random utilities."""

import pytest

from dspu.ml import (
    RandomError,
    SeedManager,
    make_classification_data,
    make_regression_data,
    make_time_series,
)


class TestSeedManager:
    """Tests for SeedManager."""

    def test_set_global_seed(self):
        """Test setting global seed."""
        SeedManager.set_global_seed(42)
        assert SeedManager.get_current_seed() == 42

    def test_set_global_seed_negative_raises(self):
        """Test negative seed raises error."""
        with pytest.raises(RandomError):
            SeedManager.set_global_seed(-1)

    def test_seed_produces_deterministic_results(self):
        """Test that same seed produces same results."""
        import random

        SeedManager.set_global_seed(42)
        vals1 = [random.random() for _ in range(10)]

        SeedManager.set_global_seed(42)
        vals2 = [random.random() for _ in range(10)]

        assert vals1 == vals2

    def test_seed_context_restores_state(self):
        """Test seed context restores previous state."""
        import random

        SeedManager.set_global_seed(42)
        val1 = random.random()

        with SeedManager.seed_context(123):
            val_inner = random.random()

        val2 = random.random()

        # val2 should continue from where val1 left off (after seed 42)
        assert val_inner != val1  # Different seed
        assert val2 != val_inner  # Restored to original seed

    def test_get_rng_python(self):
        """Test getting Python RNG."""
        rng = SeedManager.get_rng(seed=42, backend="python")
        val1 = rng.random()
        val2 = rng.random()

        assert val1 != val2  # Different values
        assert 0 <= val1 <= 1  # Valid range

    def test_get_rng_invalid_backend(self):
        """Test invalid backend raises error."""
        with pytest.raises(RandomError):
            SeedManager.get_rng(backend="invalid")

    def test_get_rng_numpy_not_installed(self):
        """Test numpy RNG when numpy not available."""
        # This will succeed if numpy is installed, fail otherwise
        try:
            rng = SeedManager.get_rng(seed=42, backend="numpy")
            assert rng is not None
        except RandomError as e:
            assert "NumPy not available" in str(e)


class TestMakeClassificationData:
    """Tests for make_classification_data."""

    def test_basic_generation(self):
        """Test basic classification data generation."""
        X, y = make_classification_data(n_samples=100, n_features=5)

        assert len(X) == 100
        assert len(y) == 100
        assert len(X[0]) == 5

    def test_binary_classification(self):
        """Test binary classification (2 classes)."""
        X, y = make_classification_data(n_samples=100, n_classes=2)

        unique_classes = set(y)
        assert unique_classes == {0, 1}

    def test_multiclass_classification(self):
        """Test multiclass classification."""
        X, y = make_classification_data(n_samples=100, n_classes=5)

        unique_classes = set(y)
        assert len(unique_classes) == 5
        assert min(y) == 0
        assert max(y) == 4

    def test_informative_features(self):
        """Test n_informative parameter."""
        X, y = make_classification_data(n_samples=100, n_features=10, n_informative=3)

        assert len(X[0]) == 10

    def test_n_informative_exceeds_n_features_raises(self):
        """Test n_informative > n_features raises error."""
        with pytest.raises(RandomError):
            make_classification_data(n_features=5, n_informative=10)

    def test_reproducibility(self):
        """Test same seed produces same data."""
        X1, y1 = make_classification_data(n_samples=50, random_state=42)
        X2, y2 = make_classification_data(n_samples=50, random_state=42)

        assert X1 == X2
        assert y1 == y2

    def test_noise_parameter(self):
        """Test noise parameter affects data."""
        X1, y1 = make_classification_data(n_samples=50, noise=0.0, random_state=42)
        X2, y2 = make_classification_data(n_samples=50, noise=1.0, random_state=42)

        # With different noise, data should be different
        assert X1 != X2


class TestMakeRegressionData:
    """Tests for make_regression_data."""

    def test_basic_generation(self):
        """Test basic regression data generation."""
        X, y = make_regression_data(n_samples=100, n_features=5)

        assert len(X) == 100
        assert len(y) == 100
        assert len(X[0]) == 5

    def test_continuous_targets(self):
        """Test targets are continuous."""
        X, y = make_regression_data(n_samples=100)

        # Check targets are floats
        assert all(isinstance(val, float) for val in y)

    def test_reproducibility(self):
        """Test same seed produces same data."""
        X1, y1 = make_regression_data(n_samples=50, random_state=42)
        X2, y2 = make_regression_data(n_samples=50, random_state=42)

        assert X1 == X2
        assert y1 == y2

    def test_informative_features(self):
        """Test n_informative parameter."""
        X, y = make_regression_data(n_samples=100, n_features=10, n_informative=3)

        assert len(X[0]) == 10

    def test_n_informative_exceeds_n_features_raises(self):
        """Test n_informative > n_features raises error."""
        with pytest.raises(RandomError):
            make_regression_data(n_features=5, n_informative=10)

    def test_noise_affects_output(self):
        """Test noise parameter affects targets."""
        X1, y1 = make_regression_data(n_samples=50, noise=0.01, random_state=42)
        X2, y2 = make_regression_data(n_samples=50, noise=1.0, random_state=42)

        # Targets should be different with different noise
        assert y1 != y2


class TestMakeTimeSeries:
    """Tests for make_time_series."""

    def test_basic_generation(self):
        """Test basic time series generation."""
        ts = make_time_series(length=100)

        assert len(ts) == 100
        assert all(isinstance(val, float) for val in ts)

    def test_trend_pattern(self):
        """Test trend pattern."""
        ts = make_time_series(length=100, pattern="trend", noise=0.01)

        # Should have upward trend
        first_half = sum(ts[:50])
        second_half = sum(ts[50:])
        assert second_half > first_half

    def test_seasonality_pattern(self):
        """Test seasonality pattern."""
        ts = make_time_series(length=48, pattern="seasonality", seasonality_period=12, noise=0.01)

        # Values 12 steps apart should be similar (due to period=12)
        assert len(ts) == 48

    def test_trend_plus_seasonality(self):
        """Test combined pattern."""
        ts = make_time_series(length=100, pattern="trend+seasonality")

        assert len(ts) == 100

    def test_random_pattern(self):
        """Test random walk pattern."""
        ts = make_time_series(length=100, pattern="random")

        assert len(ts) == 100

    def test_invalid_pattern_raises(self):
        """Test invalid pattern raises error."""
        with pytest.raises(RandomError):
            make_time_series(pattern="invalid")

    def test_reproducibility(self):
        """Test same seed produces same series."""
        ts1 = make_time_series(length=50, random_state=42)
        ts2 = make_time_series(length=50, random_state=42)

        assert ts1 == ts2
