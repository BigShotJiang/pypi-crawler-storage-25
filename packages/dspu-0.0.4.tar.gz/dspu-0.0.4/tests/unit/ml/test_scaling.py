"""Tests for feature scaling."""

import tempfile

import pytest

from dspu.ml import Scaler, ScalingError


class TestScaler:
    """Tests for Scaler class."""

    def test_standard_scaler_fit_transform(self):
        """Test standard scaling."""
        scaler = Scaler(method="standard")
        X = [[1.0, 2.0], [2.0, 4.0], [3.0, 6.0]]

        X_scaled = scaler.fit_transform(X)

        assert len(X_scaled) == 3
        assert len(X_scaled[0]) == 2

        # Mean should be close to 0
        feat0_mean = sum(row[0] for row in X_scaled) / 3
        assert abs(feat0_mean) < 0.01

    def test_minmax_scaler(self):
        """Test min-max scaling."""
        scaler = Scaler(method="minmax", feature_range=(0, 1))
        X = [[1.0], [2.0], [3.0]]

        X_scaled = scaler.fit_transform(X)

        # Should be scaled to [0, 1]
        assert X_scaled[0][0] == 0.0  # Min
        assert X_scaled[2][0] == 1.0  # Max

    def test_robust_scaler(self):
        """Test robust scaling."""
        scaler = Scaler(method="robust")
        X = [[1.0], [2.0], [3.0], [100.0]]  # With outlier

        X_scaled = scaler.fit_transform(X)

        assert len(X_scaled) == 4

    def test_fit_then_transform(self):
        """Test separate fit and transform."""
        scaler = Scaler(method="standard")
        X_train = [[1.0], [2.0], [3.0]]
        X_test = [[1.5]]

        scaler.fit(X_train)
        X_test_scaled = scaler.transform(X_test)

        assert len(X_test_scaled) == 1

    def test_inverse_transform(self):
        """Test inverse transformation."""
        scaler = Scaler(method="standard")
        X = [[1.0, 2.0], [2.0, 4.0], [3.0, 6.0]]

        X_scaled = scaler.fit_transform(X)
        X_recovered = scaler.inverse_transform(X_scaled)

        # Should recover original values (approximately)
        for i in range(len(X)):
            for j in range(len(X[0])):
                assert abs(X[i][j] - X_recovered[i][j]) < 0.01

    def test_save_and_load_state(self):
        """Test state serialization."""
        scaler = Scaler(method="standard")
        X = [[1.0], [2.0], [3.0]]
        scaler.fit(X)

        # Save state
        state = scaler.save_state()

        # Load into new scaler
        new_scaler = Scaler.from_state(state)

        # Should produce same results
        X_test = [[2.0]]
        result1 = scaler.transform(X_test)
        result2 = new_scaler.transform(X_test)

        assert result1 == result2

    def test_save_to_file(self):
        """Test saving to file."""
        scaler = Scaler(method="standard")
        X = [[1.0], [2.0], [3.0]]
        scaler.fit(X)

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            filepath = f.name

        scaler.save_to_file(filepath)

        # Load from file
        loaded_scaler = Scaler.load_from_file(filepath)

        # Should produce same results
        X_test = [[2.0]]
        result1 = scaler.transform(X_test)
        result2 = loaded_scaler.transform(X_test)

        assert result1 == result2

    def test_transform_before_fit_raises(self):
        """Test transform before fit raises error."""
        scaler = Scaler(method="standard")
        X = [[1.0]]

        with pytest.raises(ScalingError):
            scaler.transform(X)

    def test_feature_mismatch_raises(self):
        """Test feature count mismatch raises error."""
        scaler = Scaler(method="standard")
        scaler.fit([[1.0, 2.0]])

        with pytest.raises(ScalingError):
            scaler.transform([[1.0]])  # Wrong number of features

    def test_invalid_method_raises(self):
        """Test invalid method raises error."""
        with pytest.raises(ScalingError):
            Scaler(method="invalid")

    def test_fit_empty_data_raises(self):
        """Test fitting on empty data raises error."""
        scaler = Scaler(method="standard")
        with pytest.raises(ScalingError, match="empty data"):
            scaler.fit([])

    def test_fit_inconsistent_features_raises(self):
        """Test fitting with inconsistent feature counts raises error."""
        scaler = Scaler(method="standard")
        X = [[1.0, 2.0], [3.0]]  # Inconsistent lengths
        with pytest.raises(ScalingError, match="same number of features"):
            scaler.fit(X)

    def test_minmax_custom_range(self):
        """Test minmax scaling with custom range."""
        scaler = Scaler(method="minmax", feature_range=(-1.0, 1.0))
        X = [[0.0], [5.0], [10.0]]

        X_scaled = scaler.fit_transform(X)

        # Should be scaled to [-1, 1]
        assert abs(X_scaled[0][0] - (-1.0)) < 0.01  # Min
        assert abs(X_scaled[2][0] - 1.0) < 0.01  # Max

    def test_inverse_transform_minmax(self):
        """Test inverse transform for minmax scaler."""
        scaler = Scaler(method="minmax")
        X = [[1.0], [2.0], [3.0]]

        X_scaled = scaler.fit_transform(X)
        X_recovered = scaler.inverse_transform(X_scaled)

        # Should recover original values
        for i in range(len(X)):
            assert abs(X[i][0] - X_recovered[i][0]) < 0.01

    def test_inverse_transform_robust(self):
        """Test inverse transform for robust scaler."""
        scaler = Scaler(method="robust")
        X = [[1.0], [2.0], [3.0], [4.0]]

        X_scaled = scaler.fit_transform(X)
        X_recovered = scaler.inverse_transform(X_scaled)

        # Should recover original values
        for i in range(len(X)):
            assert abs(X[i][0] - X_recovered[i][0]) < 0.01

    def test_inverse_transform_before_fit_raises(self):
        """Test inverse transform before fit raises error."""
        scaler = Scaler(method="standard")
        with pytest.raises(ScalingError, match="not fitted"):
            scaler.inverse_transform([[1.0]])

    def test_from_state_invalid_raises(self):
        """Test from_state with invalid state raises error."""
        with pytest.raises(KeyError):
            Scaler.from_state({})

    def test_from_state_missing_method_raises(self):
        """Test from_state without method raises error."""
        with pytest.raises(KeyError):
            Scaler.from_state({"is_fitted": True})

    def test_standard_scaler_single_feature(self):
        """Test standard scaler with single feature."""
        scaler = Scaler(method="standard")
        X = [[1.0], [2.0], [3.0], [4.0], [5.0]]

        X_scaled = scaler.fit_transform(X)

        # Mean should be close to 0
        mean = sum(row[0] for row in X_scaled) / len(X_scaled)
        assert abs(mean) < 0.01

        # Std should be close to 1
        variance = sum((row[0] - mean) ** 2 for row in X_scaled) / len(X_scaled)
        std = variance**0.5
        assert abs(std - 1.0) < 0.01

    def test_minmax_scaler_multiple_features(self):
        """Test minmax scaler with multiple features."""
        scaler = Scaler(method="minmax")
        X = [[1.0, 10.0], [2.0, 20.0], [3.0, 30.0]]

        X_scaled = scaler.fit_transform(X)

        # Each feature should be in [0, 1]
        for row in X_scaled:
            for val in row:
                assert 0.0 <= val <= 1.0

    def test_robust_scaler_with_outliers(self):
        """Test robust scaler handles outliers well."""
        scaler = Scaler(method="robust")
        X = [[1.0], [2.0], [3.0], [4.0], [100.0]]  # Large outlier

        X_scaled = scaler.fit_transform(X)

        # Should handle outlier gracefully
        assert len(X_scaled) == 5
        # Outlier should be scaled but not dominate
        assert X_scaled[4][0] > 10  # Still large but not extreme

    def test_save_state_unfitted_raises(self):
        """Test saving state before fitting raises error."""
        scaler = Scaler(method="standard")
        with pytest.raises(ScalingError, match="unfitted"):
            scaler.save_state()

    def test_save_to_file_unfitted_raises(self):
        """Test saving to file before fitting raises error."""
        scaler = Scaler(method="standard")
        with pytest.raises(ScalingError, match="unfitted"):
            scaler.save_to_file("test.json")

    def test_transform_wrong_features_raises(self):
        """Test transform with wrong number of features raises error."""
        scaler = Scaler(method="standard")
        scaler.fit([[1.0, 2.0]])

        with pytest.raises(ScalingError, match="Expected 2 features"):
            scaler.transform([[1.0]])

    def test_inverse_transform_wrong_features_raises(self):
        """Test inverse transform with wrong features raises error."""
        scaler = Scaler(method="standard")
        scaler.fit([[1.0, 2.0]])

        with pytest.raises(ScalingError, match="All samples must have 2 features"):
            scaler.inverse_transform([[1.0]])

    def test_load_from_file_nonexistent_raises(self):
        """Test loading from nonexistent file raises error."""
        with pytest.raises(FileNotFoundError):
            Scaler.load_from_file("nonexistent_file.json")
