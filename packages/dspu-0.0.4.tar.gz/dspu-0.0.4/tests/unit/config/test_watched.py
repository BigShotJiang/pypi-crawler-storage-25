"""Tests for WatchedConfig."""

import time
from pathlib import Path

import pytest
from pydantic import BaseModel

from dspu.config.sources import DictSource, FileSource
from dspu.config.watched import WatchedConfig
from dspu.core.exceptions import ConfigurationError


class SimpleConfig(BaseModel):
    """Simple test configuration."""

    app_name: str
    debug: bool = False
    count: int = 0


class TestWatchedConfigInitialization:
    """Test WatchedConfig initialization."""

    def test_load_single_file_source(self, tmp_path: Path) -> None:
        """Test loading from single file source."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ndebug: true")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=1.0,
        )

        assert watched.current.app_name == "test"
        assert watched.current.debug is True

        watched.stop()

    def test_load_multiple_sources(self, tmp_path: Path) -> None:
        """Test loading from multiple sources."""
        base_file = tmp_path / "base.yaml"
        base_file.write_text("app_name: test\ndebug: false")

        local_file = tmp_path / "local.yaml"
        local_file.write_text("debug: true")

        watched = WatchedConfig.load(
            SimpleConfig,
            sources=[
                FileSource(base_file),
                FileSource(local_file),
            ],
            reload_interval=1.0,
        )

        assert watched.current.app_name == "test"
        assert watched.current.debug is True

        watched.stop()

    def test_requires_file_source(self) -> None:
        """Test that at least one FileSource is required."""
        with pytest.raises(ConfigurationError) as exc_info:
            WatchedConfig.load(
                SimpleConfig,
                sources=[
                    DictSource({"app_name": "test"}),
                ],
            )

        assert "FileSource" in str(exc_info.value)

    def test_requires_source_or_sources(self) -> None:
        """Test that either source or sources must be provided."""
        with pytest.raises(ConfigurationError) as exc_info:
            WatchedConfig.load(SimpleConfig)

        assert "source" in str(exc_info.value).lower()

    def test_cannot_provide_both_source_and_sources(self, tmp_path: Path) -> None:
        """Test that source and sources are mutually exclusive."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test")

        with pytest.raises(ConfigurationError) as exc_info:
            WatchedConfig.load(
                SimpleConfig,
                source=FileSource(config_file),
                sources=[FileSource(config_file)],
            )

        assert "both" in str(exc_info.value).lower()


class TestWatchedConfigFileWatching:
    """Test file watching functionality."""

    def test_detects_file_changes(self, tmp_path: Path) -> None:
        """Test that file changes are detected."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=0.5,  # Fast reload for testing
        )

        assert watched.current.count == 1

        # Wait a bit to ensure different mtime
        time.sleep(0.1)

        # Modify file
        config_file.write_text("app_name: test\ncount: 2")

        # Wait for reload
        time.sleep(1.0)

        assert watched.current.count == 2

        watched.stop()

    def test_callback_on_change(self, tmp_path: Path) -> None:
        """Test that callbacks are called on config change."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=0.5,
        )

        # Track callback invocations
        changes: list[tuple[int, int]] = []

        def on_change(old: SimpleConfig, new: SimpleConfig) -> None:
            changes.append((old.count, new.count))

        watched.on_change(on_change)

        # Wait a bit to ensure different mtime
        time.sleep(0.1)

        # Modify file
        config_file.write_text("app_name: test\ncount: 2")

        # Wait for reload
        time.sleep(1.0)

        assert len(changes) > 0
        assert changes[-1] == (1, 2)

        watched.stop()

    def test_multiple_callbacks(self, tmp_path: Path) -> None:
        """Test multiple callbacks can be registered."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=0.5,
        )

        callbacks_called = [0, 0]

        def callback1(old: SimpleConfig, new: SimpleConfig) -> None:
            callbacks_called[0] += 1

        def callback2(old: SimpleConfig, new: SimpleConfig) -> None:
            callbacks_called[1] += 1

        watched.on_change(callback1)
        watched.on_change(callback2)

        # Wait and modify
        time.sleep(0.1)
        config_file.write_text("app_name: test\ncount: 2")
        time.sleep(1.0)

        assert callbacks_called[0] > 0
        assert callbacks_called[1] > 0

        watched.stop()

    def test_callback_error_does_not_stop_reload(self, tmp_path: Path) -> None:
        """Test that callback errors don't prevent reload."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=0.5,
        )

        def bad_callback(old: SimpleConfig, new: SimpleConfig) -> None:
            raise RuntimeError("Callback failed!")

        def good_callback(old: SimpleConfig, new: SimpleConfig) -> None:
            pass

        watched.on_change(bad_callback)
        watched.on_change(good_callback)

        # Wait and modify
        time.sleep(0.1)
        config_file.write_text("app_name: test\ncount: 2")
        time.sleep(1.0)

        # Config should still be updated despite callback error
        assert watched.current.count == 2

        watched.stop()


class TestWatchedConfigManualReload:
    """Test manual reload functionality."""

    def test_manual_reload(self, tmp_path: Path) -> None:
        """Test manual reload works."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=60.0,  # Long interval
        )

        assert watched.current.count == 1

        # Modify file
        config_file.write_text("app_name: test\ncount: 2")

        # Manual reload
        success = watched.reload()

        assert success is True
        assert watched.current.count == 2

        watched.stop()

    def test_reload_with_invalid_config(self, tmp_path: Path) -> None:
        """Test reload with invalid config keeps old config."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=60.0,
        )

        assert watched.current.count == 1

        # Write invalid config (missing required field)
        config_file.write_text("count: 2")

        # Manual reload should fail
        success = watched.reload()

        assert success is False
        assert watched.current.count == 1  # Old config preserved

        watched.stop()


class TestWatchedConfigContextManager:
    """Test context manager functionality."""

    def test_context_manager_stops_watching(self, tmp_path: Path) -> None:
        """Test that context manager stops watching on exit."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test")

        with WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
        ) as watched:
            assert watched.current.app_name == "test"

        # After exiting context, watcher should be stopped
        assert watched._stop_event.is_set()

    def test_context_manager_with_exception(self, tmp_path: Path) -> None:
        """Test that watcher stops even if exception occurs."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test")

        try:
            with WatchedConfig.load(
                SimpleConfig,
                source=FileSource(config_file),
            ) as watched:
                raise RuntimeError("Test error")
        except RuntimeError:
            pass

        # Watcher should still be stopped
        assert watched._stop_event.is_set()


class TestWatchedConfigThreadSafety:
    """Test thread safety."""

    def test_current_is_thread_safe(self, tmp_path: Path) -> None:
        """Test that accessing current is thread-safe."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("app_name: test\ncount: 1")

        watched = WatchedConfig.load(
            SimpleConfig,
            source=FileSource(config_file),
            reload_interval=0.5,
        )

        # Access current from multiple "threads" (simulated)
        for _ in range(10):
            config = watched.current
            assert config.app_name == "test"
            assert config.count >= 1

        watched.stop()


class TestWatchedConfigDocumentation:
    """Test that WatchedConfig is properly documented."""

    def test_has_docstring(self) -> None:
        """Test that WatchedConfig has documentation."""
        assert WatchedConfig.__doc__ is not None
        assert len(WatchedConfig.__doc__) > 50

    def test_load_has_docstring(self) -> None:
        """Test that load has documentation."""
        assert WatchedConfig.load.__doc__ is not None

    def test_current_has_docstring(self) -> None:
        """Test that current property has documentation."""
        assert WatchedConfig.current.fget.__doc__ is not None  # type: ignore[union-attr]

    def test_on_change_has_docstring(self) -> None:
        """Test that on_change has documentation."""
        assert WatchedConfig.on_change.__doc__ is not None
