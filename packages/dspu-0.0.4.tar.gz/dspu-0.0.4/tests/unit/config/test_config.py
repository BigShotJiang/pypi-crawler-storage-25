"""Tests for Config class."""

from pathlib import Path

import pytest
from pydantic import BaseModel, Field

from dspu.config.config import Config
from dspu.config.sources import DictSource, EnvSource, FileSource
from dspu.core.exceptions import ConfigurationError, ValidationError


class SimpleConfig(BaseModel):
    """Simple test config."""

    app_name: str
    debug: bool = False
    port: int = Field(default=8000, ge=1, le=65535)


class NestedConfig(BaseModel):
    """Config with nested structure."""

    class DatabaseConfig(BaseModel):
        host: str = "localhost"
        port: int = 5432

    app_name: str
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)


class TestConfig:
    """Tests for Config class."""

    def test_load_from_single_dict_source(self) -> None:
        """Test loading from a single dictionary source."""
        config = Config.load(
            SimpleConfig,
            sources=[DictSource({"app_name": "test", "port": 9000})],
        )

        assert config.app_name == "test"
        assert config.port == 9000
        assert config.debug is False  # default value

    def test_load_from_multiple_sources(self) -> None:
        """Test loading from multiple sources with priority."""
        config = Config.load(
            SimpleConfig,
            sources=[
                DictSource({"app_name": "default", "port": 8000}),
                DictSource({"port": 9000}),  # Override port
            ],
        )

        assert config.app_name == "default"
        assert config.port == 9000  # Overridden by second source

    def test_validation_on_load(self) -> None:
        """Test that Pydantic validation is applied."""
        with pytest.raises(ValidationError) as exc_info:
            Config.load(
                SimpleConfig,
                sources=[DictSource({"app_name": "test", "port": 99999})],
            )

        assert "port" in str(exc_info.value)

    def test_validation_required_field(self) -> None:
        """Test validation of required fields."""
        with pytest.raises(ValidationError) as exc_info:
            Config.load(
                SimpleConfig,
                sources=[DictSource({"debug": True})],  # Missing app_name
            )

        assert "app_name" in str(exc_info.value)

    def test_deep_merge_nested_config(self) -> None:
        """Test deep merge of nested configuration."""
        config = Config.load(
            NestedConfig,
            sources=[
                DictSource(
                    {
                        "app_name": "test",
                        "database": {"host": "localhost", "port": 5432},
                    }
                ),
                DictSource(
                    {
                        "database": {"host": "remote"},  # Override only host
                    }
                ),
            ],
        )

        assert config.app_name == "test"
        assert config.database.host == "remote"  # Overridden
        assert config.database.port == 5432  # Preserved

    def test_load_from_file_convenience(self, tmp_path: Path) -> None:
        """Test load_from_file convenience method."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"app_name": "test", "port": 8080}')

        config = Config.load_from_file(SimpleConfig, str(config_file))

        assert config.app_name == "test"
        assert config.port == 8080

    def test_load_from_env_convenience(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test load_from_env convenience method."""
        monkeypatch.setenv("APP_APP_NAME", "test")
        monkeypatch.setenv("APP_PORT", "8080")
        monkeypatch.setenv("APP_DEBUG", "true")

        config = Config.load_from_env(SimpleConfig, prefix="APP_")

        assert config.app_name == "test"
        assert config.port == 8080
        # Note: env returns strings, Pydantic coerces to bool
        assert config.debug is True

    def test_complex_multi_source_scenario(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test realistic multi-source scenario."""
        # Default config file
        default_file = tmp_path / "defaults.yaml"
        default_file.write_text("""
app_name: myapp
debug: false
port: 8000
""")

        # Environment overrides
        monkeypatch.setenv("APP_PORT", "9000")
        monkeypatch.setenv("APP_DEBUG", "true")

        config = Config.load(
            SimpleConfig,
            sources=[
                FileSource(default_file),
                EnvSource(prefix="APP_"),
            ],
        )

        assert config.app_name == "myapp"  # From file
        assert config.port == 9000  # From env
        assert config.debug is True  # From env

    def test_source_loading_error_propagation(self) -> None:
        """Test that source loading errors are propagated."""

        class FailingSource(DictSource):
            def load(self) -> dict:
                raise RuntimeError("Source failed")

        with pytest.raises(ConfigurationError) as exc_info:
            Config.load(SimpleConfig, sources=[FailingSource({})])

        assert "Failed to load" in str(exc_info.value)

    def test_empty_config_with_defaults(self) -> None:
        """Test config with all default values."""

        class AllOptionalConfig(BaseModel):
            value: str = "default"
            number: int = 42

        config = Config.load(AllOptionalConfig, sources=[DictSource({})])

        assert config.value == "default"
        assert config.number == 42


class TestConfigMerging:
    """Tests for configuration merging behavior."""

    def test_shallow_override(self) -> None:
        """Test shallow key override."""
        config = Config.load(
            SimpleConfig,
            sources=[
                DictSource({"app_name": "first", "port": 8000}),
                DictSource({"app_name": "second"}),
            ],
        )

        assert config.app_name == "second"

    def test_deep_merge_preserves_unspecified_keys(self) -> None:
        """Test that deep merge preserves keys not in later sources."""
        config = Config.load(
            NestedConfig,
            sources=[
                DictSource(
                    {
                        "app_name": "test",
                        "database": {"host": "host1", "port": 1111},
                    }
                ),
                DictSource(
                    {
                        "database": {"port": 2222},
                    }
                ),
            ],
        )

        assert config.database.host == "host1"
        assert config.database.port == 2222

    def test_list_override_not_merge(self) -> None:
        """Test that lists are replaced, not merged."""

        class ListConfig(BaseModel):
            items: list[str]

        config = Config.load(
            ListConfig,
            sources=[
                DictSource({"items": ["a", "b", "c"]}),
                DictSource({"items": ["x", "y"]}),
            ],
        )

        assert config.items == ["x", "y"]
