"""Tests for VaultSource."""

import pytest

from dspu.config.vault import VaultSource, is_vault_available
from dspu.core.exceptions import ConfigurationError


class TestVaultAvailability:
    """Test Vault availability detection."""

    def test_is_vault_available(self) -> None:
        """Test if hvac package detection works."""
        # This will be True if hvac is installed, False otherwise
        result = is_vault_available()
        assert isinstance(result, bool)


class TestVaultSourceConfiguration:
    """Test VaultSource configuration."""

    def test_requires_path(self) -> None:
        """Test that VaultSource requires path parameter."""
        if not is_vault_available():
            pytest.skip("hvac not installed")

        with pytest.raises(ConfigurationError) as exc_info:
            VaultSource(
                url="http://localhost:8200",
                token="test-token",
                path=None,
            )

        assert "path" in str(exc_info.value)

    def test_vault_not_installed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test error when hvac is not installed."""
        # Temporarily make hvac unavailable
        import dspu.config.vault as vault_module

        original_hvac = vault_module.hvac
        monkeypatch.setattr(vault_module, "hvac", None)

        with pytest.raises(ConfigurationError) as exc_info:
            VaultSource(
                url="http://localhost:8200",
                token="test-token",
                path="secret/myapp",
            )

        assert "hvac" in str(exc_info.value).lower()
        assert exc_info.value.suggestion is not None

        # Restore
        monkeypatch.setattr(vault_module, "hvac", original_hvac)

    def test_initialization_with_valid_params(self) -> None:
        """Test VaultSource initialization with valid parameters."""
        if not is_vault_available():
            pytest.skip("hvac not installed")

        source = VaultSource(
            url="http://localhost:8200",
            token="test-token",
            path="secret/myapp",
        )

        assert source.url == "http://localhost:8200"
        assert source.token == "test-token"
        assert source.path == "secret/myapp"
        assert source.mount_point == "secret"
        assert source.verify is True

    def test_initialization_with_approle(self) -> None:
        """Test VaultSource initialization with AppRole auth."""
        if not is_vault_available():
            pytest.skip("hvac not installed")

        source = VaultSource(
            url="http://localhost:8200",
            role_id="test-role",
            secret_id="test-secret",
            path="secret/myapp",
        )

        assert source.role_id == "test-role"
        assert source.secret_id == "test-secret"

    def test_initialization_with_custom_mount_point(self) -> None:
        """Test VaultSource with custom mount point."""
        if not is_vault_available():
            pytest.skip("hvac not installed")

        source = VaultSource(
            url="http://localhost:8200",
            token="test-token",
            path="myapp",
            mount_point="custom-secret",
        )

        assert source.mount_point == "custom-secret"


class TestVaultSourceLoading:
    """Test VaultSource loading (integration-style, but mocked)."""

    def test_load_requires_authentication(self) -> None:
        """Test that load fails without proper authentication."""
        if not is_vault_available():
            pytest.skip("hvac not installed")

        source = VaultSource(
            url="http://localhost:8200",
            path="secret/myapp",
        )

        # Without a real Vault server, this should fail
        with pytest.raises(ConfigurationError):
            source.load()

    def test_load_with_mock_client(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test load with mocked hvac client."""
        if not is_vault_available():
            pytest.skip("hvac not installed")

        # Mock hvac.Client
        class MockClient:
            def __init__(self, url, token, namespace, verify):  # type: ignore[no-untyped-def]
                self.url = url
                self.token = token
                self.namespace = namespace
                self.verify = verify
                self.secrets = MockSecrets()

            def is_authenticated(self) -> bool:
                return True

        class MockSecrets:
            def __init__(self) -> None:
                self.kv = MockKV()

        class MockKV:
            def __init__(self) -> None:
                self.v2 = MockKVv2()

        class MockKVv2:
            def read_secret_version(  # type: ignore[no-untyped-def]
                self, path, mount_point
            ) -> dict:
                return {
                    "data": {
                        "data": {
                            "username": "test-user",
                            "password": "test-pass",
                        }
                    }
                }

        import dspu.config.vault as vault_module

        if vault_module.hvac:
            monkeypatch.setattr(vault_module.hvac, "Client", MockClient)

            source = VaultSource(
                url="http://localhost:8200",
                token="test-token",
                path="myapp",
            )

            data = source.load()

            assert data == {
                "username": "test-user",
                "password": "test-pass",
            }


class TestVaultSourceDocumentation:
    """Test that VaultSource is properly documented."""

    def test_has_docstring(self) -> None:
        """Test that VaultSource has documentation."""
        assert VaultSource.__doc__ is not None
        assert len(VaultSource.__doc__) > 50

    def test_init_has_docstring(self) -> None:
        """Test that __init__ has documentation."""
        assert VaultSource.__init__.__doc__ is not None

    def test_load_has_docstring(self) -> None:
        """Test that load has documentation."""
        assert VaultSource.load.__doc__ is not None
