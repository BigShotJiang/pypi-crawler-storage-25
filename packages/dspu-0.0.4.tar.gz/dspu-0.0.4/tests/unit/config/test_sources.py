"""Tests for configuration sources."""

from pathlib import Path

import pytest

from dspu.config.sources import DictSource, EnvSource, FileSource
from dspu.core.exceptions import ConfigurationError


class TestDictSource:
    """Tests for DictSource."""

    def test_load_simple_dict(self) -> None:
        """Test loading from simple dictionary."""
        source = DictSource({"key": "value", "number": 42})
        config = source.load()

        assert config["key"] == "value"
        assert config["number"] == 42

    def test_load_nested_dict(self) -> None:
        """Test loading nested dictionary."""
        source = DictSource(
            {
                "database": {
                    "host": "localhost",
                    "port": 5432,
                }
            }
        )
        config = source.load()

        assert config["database"]["host"] == "localhost"
        assert config["database"]["port"] == 5432

    def test_load_returns_copy(self) -> None:
        """Test that load returns a copy, not reference."""
        original = {"key": "value"}
        source = DictSource(original)
        config = source.load()

        config["key"] = "modified"

        assert original["key"] == "value"


class TestFileSource:
    """Tests for FileSource."""

    def test_load_json(self, tmp_path: Path) -> None:
        """Test loading JSON file."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"app": "test", "port": 8000}')

        source = FileSource(config_file)
        config = source.load()

        assert config["app"] == "test"
        assert config["port"] == 8000

    def test_load_yaml(self, tmp_path: Path) -> None:
        """Test loading YAML file."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
app: test
port: 8000
debug: true
""")

        source = FileSource(config_file)
        config = source.load()

        assert config["app"] == "test"
        assert config["port"] == 8000
        assert config["debug"] is True

    def test_load_toml(self, tmp_path: Path) -> None:
        """Test loading TOML file."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("""
app = "test"
port = 8000

[database]
host = "localhost"
""")

        source = FileSource(config_file)
        config = source.load()

        assert config["app"] == "test"
        assert config["port"] == 8000
        assert config["database"]["host"] == "localhost"

    def test_load_hocon(self, tmp_path: Path) -> None:
        """Test loading HOCON file."""
        config_file = tmp_path / "config.conf"
        config_file.write_text("""
app = test
port = 8000
database {
    host = localhost
    port = 5432
}
""")

        source = FileSource(config_file)
        config = source.load()

        assert config["app"] == "test"
        assert config["port"] == 8000
        assert config["database"]["host"] == "localhost"

    def test_load_env(self, tmp_path: Path) -> None:
        """Test loading .env file."""
        config_file = tmp_path / ".env"
        config_file.write_text("""
APP_NAME=test
APP_PORT=8000
DEBUG=true
""")

        source = FileSource(config_file)
        config = source.load()

        assert config["APP_NAME"] == "test"
        assert config["APP_PORT"] == "8000"
        assert config["DEBUG"] == "true"

    def test_format_detection_from_extension(self, tmp_path: Path) -> None:
        """Test automatic format detection."""
        # Test .yml extension
        yml_file = tmp_path / "config.yml"
        yml_file.write_text("app: test")

        source = FileSource(yml_file)
        config = source.load()
        assert config["app"] == "test"

    def test_explicit_format_override(self, tmp_path: Path) -> None:
        """Test explicit format specification."""
        config_file = tmp_path / "config.txt"
        config_file.write_text('{"app": "test"}')

        source = FileSource(config_file, format="json")
        config = source.load()

        assert config["app"] == "test"

    def test_file_not_found_required(self, tmp_path: Path) -> None:
        """Test error when required file doesn't exist."""
        source = FileSource(tmp_path / "nonexistent.json", required=True)

        with pytest.raises(ConfigurationError) as exc_info:
            source.load()

        assert "not found" in str(exc_info.value)

    def test_file_not_found_optional(self, tmp_path: Path) -> None:
        """Test optional file returns empty dict."""
        source = FileSource(tmp_path / "nonexistent.json", required=False)
        config = source.load()

        assert config == {}

    def test_invalid_json_raises_error(self, tmp_path: Path) -> None:
        """Test error on invalid JSON."""
        config_file = tmp_path / "invalid.json"
        config_file.write_text("{invalid json}")

        source = FileSource(config_file)

        with pytest.raises(ConfigurationError) as exc_info:
            source.load()

        assert "Invalid JSON" in str(exc_info.value)

    def test_invalid_yaml_raises_error(self, tmp_path: Path) -> None:
        """Test error on invalid YAML."""
        config_file = tmp_path / "invalid.yaml"
        config_file.write_text("key: [unclosed list")

        source = FileSource(config_file)

        with pytest.raises(ConfigurationError) as exc_info:
            source.load()

        assert "Invalid YAML" in str(exc_info.value)

    def test_unsupported_format_raises_error(self, tmp_path: Path) -> None:
        """Test error on unsupported format."""
        config_file = tmp_path / "config.txt"
        config_file.write_text("data")

        source = FileSource(config_file)

        with pytest.raises(ConfigurationError) as exc_info:
            source.load()

        assert "Cannot detect format" in str(exc_info.value)


class TestEnvSource:
    """Tests for EnvSource."""

    def test_load_all_env_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading all environment variables."""
        monkeypatch.setenv("TEST_VAR", "value")
        monkeypatch.setenv("ANOTHER_VAR", "123")

        source = EnvSource()
        config = source.load()

        assert config["test_var"] == "value"
        assert config["another_var"] == "123"

    def test_load_with_prefix(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading with prefix filter."""
        monkeypatch.setenv("APP_DEBUG", "true")
        monkeypatch.setenv("APP_PORT", "8000")
        monkeypatch.setenv("OTHER_VAR", "ignored")

        source = EnvSource(prefix="APP_")
        config = source.load()

        assert config["debug"] == "true"
        assert config["port"] == "8000"
        assert "other_var" not in config

    def test_nested_keys_with_separator(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test nested key structure with separator."""
        monkeypatch.setenv("APP__DATABASE__HOST", "localhost")
        monkeypatch.setenv("APP__DATABASE__PORT", "5432")
        monkeypatch.setenv("APP__DEBUG", "true")

        source = EnvSource(prefix="APP__", separator="__")
        config = source.load()

        assert config["database"]["host"] == "localhost"
        assert config["database"]["port"] == "5432"
        assert config["debug"] == "true"

    def test_no_lowercase(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test preserving original case."""
        monkeypatch.setenv("APP_CamelCase", "value")

        source = EnvSource(prefix="APP_", lowercase=False)
        config = source.load()

        assert config["CamelCase"] == "value"

    def test_empty_result_when_no_matching_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test empty config when no variables match."""
        monkeypatch.setenv("OTHER_VAR", "value")

        source = EnvSource(prefix="APP_")
        config = source.load()

        assert config == {}
