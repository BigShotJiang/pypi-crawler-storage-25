"""Example test to verify test infrastructure."""

import pytest


def test_basic_assertion() -> None:
    """Test basic assertion."""
    assert True


def test_addition() -> None:
    """Test simple arithmetic."""
    assert 1 + 1 == 2


@pytest.mark.asyncio
async def test_async_example() -> None:
    """Test async function."""
    result = await async_identity(42)
    assert result == 42


async def async_identity(value: int) -> int:
    """Simple async function for testing."""
    return value


class TestExampleClass:
    """Example test class."""

    def test_method(self) -> None:
        """Test method in class."""
        assert "hello".upper() == "HELLO"

    @pytest.mark.parametrize(
        "value,expected",
        [
            (1, 2),
            (2, 3),
            (10, 11),
        ],
    )
    def test_parametrized(self, value: int, expected: int) -> None:
        """Test with parameters."""
        assert value + 1 == expected
