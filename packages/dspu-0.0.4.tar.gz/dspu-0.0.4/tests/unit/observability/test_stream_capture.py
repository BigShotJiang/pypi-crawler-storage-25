"""Tests for stream capture utilities."""

import logging
import sys

from dspu.observability import StreamToLogger


class TestStreamToLogger:
    """Tests for StreamToLogger."""

    def test_write_returns_char_count(self):
        """Test StreamToLogger.write returns character count."""
        logger = logging.getLogger("test")
        stream = StreamToLogger(logger, logging.INFO)

        chars_written = stream.write("Test message\n")
        assert chars_written == len("Test message\n")

    def test_write_multiline_calls_logger(self):
        """Test StreamToLogger handles multiline strings."""
        # Create a handler to verify logging calls
        import logging
        from unittest.mock import MagicMock

        logger = logging.getLogger("test_multiline")
        logger.setLevel(logging.INFO)
        mock_handler = MagicMock(spec=logging.Handler)
        mock_handler.level = logging.INFO  # Set level attribute
        logger.addHandler(mock_handler)

        stream = StreamToLogger(logger, logging.INFO)
        stream.write("Line 1\nLine 2\nLine 3\n")

        # Should have logged 3 times (one per line)
        assert mock_handler.handle.call_count == 3

        # Clean up
        logger.removeHandler(mock_handler)

    def test_write_empty_lines_skipped(self):
        """Test StreamToLogger skips empty lines."""
        from unittest.mock import MagicMock

        logger = logging.getLogger("test_empty")
        logger.setLevel(logging.INFO)
        mock_handler = MagicMock()
        logger.addHandler(mock_handler)

        stream = StreamToLogger(logger, logging.INFO)
        stream.write("\n\n")

        # Empty lines should not be logged
        assert mock_handler.handle.call_count == 0

        # Clean up
        logger.removeHandler(mock_handler)

    def test_write_with_error_level(self):
        """Test StreamToLogger with ERROR level."""
        from unittest.mock import MagicMock

        logger = logging.getLogger("test_error")
        logger.setLevel(logging.ERROR)
        mock_handler = MagicMock(spec=logging.Handler)
        mock_handler.level = logging.ERROR  # Set level attribute
        logger.addHandler(mock_handler)

        stream = StreamToLogger(logger, logging.ERROR)
        stream.write("Error message\n")

        # Should have logged once
        assert mock_handler.handle.call_count == 1

        # Clean up
        logger.removeHandler(mock_handler)

    def test_subvert_stdout(self):
        """Test StreamToLogger.subvert redirects stdout."""
        logger = logging.getLogger("test")

        try:
            StreamToLogger.subvert(logger, reroute_stdout=True, reroute_stderr=False)

            # Check that stdout is now a StreamToLogger
            assert isinstance(sys.stdout, StreamToLogger)

        finally:
            # Restore stdout
            StreamToLogger.restore()

    def test_subvert_stderr(self):
        """Test StreamToLogger.subvert redirects stderr."""
        logger = logging.getLogger("test")

        try:
            StreamToLogger.subvert(logger, reroute_stdout=False, reroute_stderr=True)

            # Check that stderr is now a StreamToLogger
            assert isinstance(sys.stderr, StreamToLogger)

        finally:
            # Restore stderr
            StreamToLogger.restore()

    def test_restore(self):
        """Test StreamToLogger.restore restores original streams."""
        logger = logging.getLogger("test")

        # Subvert streams
        StreamToLogger.subvert(logger, reroute_stdout=True, reroute_stderr=True)

        # Verify they were redirected
        assert isinstance(sys.stdout, StreamToLogger)
        assert isinstance(sys.stderr, StreamToLogger)

        # Restore
        StreamToLogger.restore()

        # Verify they're back to normal (not StreamToLogger instances)
        assert not isinstance(sys.stdout, StreamToLogger)
        assert not isinstance(sys.stderr, StreamToLogger)

    def test_flush_no_op(self):
        """Test flush is a no-op."""
        logger = logging.getLogger("test")
        stream = StreamToLogger(logger)

        # Should not raise
        stream.flush()

    def test_infinite_loop_detection(self, caplog):
        """Test infinite loop detection prevents recursion."""
        logger = logging.getLogger("test")
        stream = StreamToLogger(logger, logging.INFO)

        with caplog.at_level(logging.INFO):
            # Write the same message twice in rapid succession
            stream.write("Same message\n")
            # Simulate the same message being written from within logging
            # by manipulating the internal state
            stream.last_logged.append("Same message")
            stream.last_num_lines_logged.append(1)

            # This should be detected as potential infinite loop
            chars_written = stream.write("Same message\n")

            # Cleanup
            stream.last_logged.pop()
            stream.last_num_lines_logged.pop()

        # Should have prevented the duplicate write
        assert chars_written == 0
