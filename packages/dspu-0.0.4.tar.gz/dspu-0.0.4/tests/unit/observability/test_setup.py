"""Tests for LoggingSetup class."""

import json
import logging
import os

import pytest

from dspu.core.exceptions import ConfigurationError
from dspu.observability import LoggingSetup


class TestLoggingSetup:
    """Tests for LoggingSetup class."""

    def teardown_method(self):
        """Clear handlers and env vars after each test."""
        root_logger = logging.getLogger()
        root_logger.handlers.clear()

        # Clear test env vars
        for key in ["TEST_LOG_LEVEL", "TEST_LOG_CONFIG"]:
            if key in os.environ:
                del os.environ[key]

    def test_setup_basic_config(self):
        """Test basic setup with defaults."""
        # Provide a dict config so it doesn't try to find a file
        config = {"version": 1, "root": {"level": "DEBUG"}}
        setup = LoggingSetup(logging_config=config, default_log_level="DEBUG")
        setup.setup()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.DEBUG

    def test_setup_from_dict_config(self):
        """Test setup from dictionary configuration."""
        config = {
            "version": 1,
            "formatters": {"simple": {"format": "%(levelname)s - %(message)s"}},
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "simple",
                    "level": "INFO",
                }
            },
            "root": {
                "handlers": ["console"],
                "level": "INFO",
            },
        }

        setup = LoggingSetup(logging_config=config)
        setup.setup()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO
        assert len(root_logger.handlers) == 1

    def test_setup_from_json_file(self, tmp_path):
        """Test setup from JSON config file."""
        config_file = tmp_path / "logging.json"
        config = {
            "version": 1,
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": "WARNING",
                }
            },
            "root": {
                "handlers": ["console"],
                "level": "WARNING",
            },
        }

        with open(config_file, "w") as f:
            json.dump(config, f)

        setup = LoggingSetup(logging_config=str(config_file))
        setup.setup()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.WARNING

    def test_setup_from_yaml_file(self, tmp_path):
        """Test setup from YAML config file."""
        pytest.importorskip("yaml")

        config_file = tmp_path / "logging.yaml"
        config_content = """
version: 1
handlers:
  console:
    class: logging.StreamHandler
    level: INFO
root:
  handlers:
    - console
  level: INFO
"""
        with open(config_file, "w") as f:
            f.write(config_content)

        setup = LoggingSetup(logging_config=str(config_file))
        setup.setup()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO

    def test_setup_with_log_file(self, tmp_path):
        """Test setup with log file override."""
        log_file = tmp_path / "test.log"

        config = {
            "version": 1,
            "handlers": {
                "file": {
                    "class": "logging.FileHandler",
                    "filename": "original.log",
                    "level": "INFO",
                }
            },
            "root": {
                "handlers": ["file"],
                "level": "INFO",
            },
        }

        setup = LoggingSetup(logging_config=config, log_file=str(log_file))
        setup.setup()

        # Check that handler uses the override file
        root_logger = logging.getLogger()
        file_handler = root_logger.handlers[0]
        assert file_handler.baseFilename == str(log_file)

    def test_determine_log_level_from_env(self):
        """Test determine_log_level reads from environment."""
        os.environ["TEST_LOG_LEVEL"] = "WARNING"

        setup = LoggingSetup(default_log_level="INFO", log_level_env="TEST_LOG_LEVEL")

        log_level = setup.determine_log_level()
        assert log_level == "WARNING"

    def test_determine_log_config_from_env(self, tmp_path):
        """Test determine_log_config_file_path reads from environment."""
        config_file = tmp_path / "custom_logging.json"
        config_file.touch()

        os.environ["TEST_LOG_CONFIG"] = str(config_file)

        setup = LoggingSetup(
            default_log_config_file="default.json", log_config_env="TEST_LOG_CONFIG"
        )

        path = setup.determine_log_config_file_path()
        assert path == str(config_file)

    def test_get_absolute_source_file_path(self):
        """Test get_absolute_source_file_path resolves paths."""
        # Test with no anchor (uses cwd)
        path = LoggingSetup.get_absolute_source_file_path("./config.json")
        assert os.path.isabs(path)
        assert path.endswith("config.json")

    def test_get_absolute_source_file_path_with_string_anchor(self):
        """Test get_absolute_source_file_path with string anchor."""
        anchor = "/some/directory"
        path = LoggingSetup.get_absolute_source_file_path("./config.json", source_anchor=anchor)
        assert path == "/some/directory/config.json"

    def test_get_absolute_source_file_path_with_object_anchor(self):
        """Test get_absolute_source_file_path with object anchor."""
        # Use this test class as anchor
        path = LoggingSetup.get_absolute_source_file_path("./config.json", source_anchor=self)
        assert os.path.isabs(path)
        assert "tests/unit/observability" in path

    def test_load_config_file_not_found(self):
        """Test _load_config_file raises error for missing file."""
        setup = LoggingSetup()

        with pytest.raises(ConfigurationError, match="not found"):
            setup._load_config_file("/nonexistent/config.json")

    def test_load_config_file_unsupported_format(self, tmp_path):
        """Test _load_config_file raises error for unsupported format."""
        config_file = tmp_path / "config.txt"
        config_file.touch()

        setup = LoggingSetup()

        with pytest.raises(ConfigurationError, match="Unsupported config file format"):
            setup._load_config_file(str(config_file))

    def test_setup_with_diversion(self):
        """Test setup_with_diversion redirects stdout."""
        import sys

        from dspu.observability.stream_capture import StreamToLogger

        # Provide a dict config
        config = {"version": 1, "root": {"level": "INFO"}}

        try:
            setup = LoggingSetup(logging_config=config, default_logger_name="test_diversion")
            logger = setup.setup_with_diversion()

            # Verify logger was created
            assert isinstance(logger, logging.Logger)
            assert logger.name == "test_diversion"

            # Verify stdout was redirected (it's now a StreamToLogger instance)
            assert isinstance(sys.stdout, StreamToLogger)

        finally:
            # Restore stdout
            StreamToLogger.restore()
