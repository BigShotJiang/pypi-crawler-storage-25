"""Tests for tracing and debugging decorators."""

import asyncio
import logging

import pytest

from dspu.observability import logged_errors, timed, traced


class TestTimedDecorator:
    """Tests for @timed decorator."""

    def test_timed_logs_execution_time(self, caplog):
        """Test @timed logs execution time."""

        @timed()
        def slow_function():
            return "done"

        with caplog.at_level(logging.INFO):
            result = slow_function()

        assert result == "done"
        assert len(caplog.records) == 1
        assert "slow_function took" in caplog.records[0].message
        assert "ms" in caplog.records[0].message

    def test_timed_with_custom_logger(self, caplog):
        """Test @timed with custom logger."""
        custom_logger = logging.getLogger("custom")

        @timed(logger=custom_logger)
        def my_function():
            return "result"

        with caplog.at_level(logging.INFO):
            my_function()

        assert len(caplog.records) == 1
        assert caplog.records[0].name == "custom"

    def test_timed_with_threshold(self, caplog):
        """Test @timed with threshold."""
        import time

        @timed(threshold_ms=50)
        def fast_function():
            time.sleep(0.001)  # 1ms - below threshold
            return "fast"

        with caplog.at_level(logging.INFO):
            result = fast_function()

        # Should not log (below threshold)
        assert result == "fast"
        assert len(caplog.records) == 0

    def test_timed_async_function(self, caplog):
        """Test @timed with async function."""

        @timed()
        async def async_function():
            await asyncio.sleep(0.01)
            return "async_done"

        with caplog.at_level(logging.INFO):
            result = asyncio.run(async_function())

        assert result == "async_done"
        assert len(caplog.records) == 1
        assert "async_function took" in caplog.records[0].message

    def test_timed_with_exception(self, caplog):
        """Test @timed still logs when exception occurs."""

        @timed()
        def failing_function():
            raise ValueError("test error")

        with caplog.at_level(logging.INFO), pytest.raises(ValueError):
            failing_function()

        # Should still log execution time
        assert len(caplog.records) == 1
        assert "failing_function took" in caplog.records[0].message


class TestTracedDecorator:
    """Tests for @traced decorator."""

    def test_traced_logs_entry_exit(self, caplog):
        """Test @traced logs entry and exit."""

        @traced()
        def my_function(x, y):
            return x + y

        with caplog.at_level(logging.DEBUG):
            result = my_function(1, 2)

        assert result == 3
        assert len(caplog.records) == 2
        assert "Entering my_function" in caplog.records[0].message
        assert "1" in caplog.records[0].message
        assert "2" in caplog.records[0].message
        assert "Exiting my_function" in caplog.records[1].message

    def test_traced_with_kwargs(self, caplog):
        """Test @traced logs keyword arguments."""

        @traced()
        def my_function(x, y=10):
            return x + y

        with caplog.at_level(logging.DEBUG):
            result = my_function(5, y=20)

        assert result == 25
        assert "5" in caplog.records[0].message
        assert "y=20" in caplog.records[0].message

    def test_traced_without_args(self, caplog):
        """Test @traced without logging arguments."""

        @traced(log_args=False)
        def my_function(x, y):
            return x + y

        with caplog.at_level(logging.DEBUG):
            my_function(1, 2)

        assert len(caplog.records) == 2
        # Should not include arguments
        assert "1" not in caplog.records[0].message
        assert "Entering my_function" in caplog.records[0].message

    def test_traced_with_result(self, caplog):
        """Test @traced logs return value."""

        @traced(log_result=True)
        def my_function(x):
            return x * 2

        with caplog.at_level(logging.DEBUG):
            result = my_function(5)

        assert result == 10
        assert "-> 10" in caplog.records[1].message

    def test_traced_with_exception(self, caplog):
        """Test @traced logs exceptions."""

        @traced()
        def failing_function():
            raise ValueError("test error")

        with caplog.at_level(logging.DEBUG), pytest.raises(ValueError):
            failing_function()

        assert len(caplog.records) == 2
        assert "Entering failing_function" in caplog.records[0].message
        assert "Exception in failing_function" in caplog.records[1].message
        assert "test error" in caplog.records[1].message

    def test_traced_async_function(self):
        """Test @traced with async function."""
        # Configure root logger for this test
        import logging

        logging.basicConfig(level=logging.DEBUG)

        @traced()
        async def async_function(x):
            await asyncio.sleep(0.001)
            return x * 2

        result = asyncio.run(async_function(5))
        assert result == 10


class TestLoggedErrorsDecorator:
    """Tests for @logged_errors decorator."""

    def test_logged_errors_logs_and_reraises(self, caplog):
        """Test @logged_errors logs exception and re-raises."""

        @logged_errors()
        def failing_function():
            raise ValueError("test error")

        with caplog.at_level(logging.ERROR), pytest.raises(ValueError):
            failing_function()

        assert len(caplog.records) == 1
        assert "Error in failing_function" in caplog.records[0].message
        assert "ValueError" in caplog.records[0].message
        assert "test error" in caplog.records[0].message

    def test_logged_errors_suppresses_exception(self, caplog):
        """Test @logged_errors with reraise=False."""

        @logged_errors(reraise=False)
        def failing_function():
            raise ValueError("test error")

        with caplog.at_level(logging.ERROR):
            result = failing_function()

        # Should not raise, returns None
        assert result is None
        assert len(caplog.records) == 1
        assert "Error in failing_function" in caplog.records[0].message

    def test_logged_errors_without_traceback(self, caplog):
        """Test @logged_errors without traceback."""

        @logged_errors(include_traceback=False)
        def failing_function():
            raise ValueError("test error")

        with caplog.at_level(logging.ERROR), pytest.raises(ValueError):
            failing_function()

        # Should log error message
        assert len(caplog.records) == 1
        assert "Error in failing_function" in caplog.records[0].message

    def test_logged_errors_with_custom_level(self, caplog):
        """Test @logged_errors with custom log level."""

        @logged_errors(level=logging.WARNING)
        def failing_function():
            raise ValueError("test error")

        with caplog.at_level(logging.WARNING), pytest.raises(ValueError):
            failing_function()

        assert len(caplog.records) == 1
        assert caplog.records[0].levelname == "WARNING"

    def test_logged_errors_async_function(self, caplog):
        """Test @logged_errors with async function."""

        @logged_errors()
        async def async_failing_function():
            await asyncio.sleep(0.001)
            raise ValueError("async error")

        with caplog.at_level(logging.ERROR), pytest.raises(ValueError):
            asyncio.run(async_failing_function())

        assert len(caplog.records) == 1
        assert "Error in async_failing_function" in caplog.records[0].message

    def test_logged_errors_successful_function(self, caplog):
        """Test @logged_errors doesn't log on success."""

        @logged_errors()
        def successful_function():
            return "success"

        with caplog.at_level(logging.ERROR):
            result = successful_function()

        assert result == "success"
        # Should not log anything
        assert len(caplog.records) == 0
