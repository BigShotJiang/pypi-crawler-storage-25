"""Tests for logging utilities."""

import logging

from dspu.observability import (
    LogContext,
    StructuredLogger,
    bind_context,
    clear_context,
    configure_logging,
    get_context,
    get_logger,
    unbind_context,
)


class TestStructuredLogger:
    """Tests for StructuredLogger."""

    def test_get_logger(self):
        """Test get_logger returns StructuredLogger."""
        logger = get_logger("test_logger")
        assert isinstance(logger, StructuredLogger)

    def test_get_logger_default_name(self):
        """Test get_logger with no name returns root logger."""
        logger = get_logger()
        assert isinstance(logger, StructuredLogger)

    def test_logger_with_extra_fields(self, caplog):
        """Test logging with extra fields."""
        logger = get_logger("test")

        with caplog.at_level(logging.INFO):
            logger.info("Test message", user_id=123, action="login")

        # Check that the record has extra fields
        assert len(caplog.records) == 1
        record = caplog.records[0]
        assert hasattr(record, "user_id")
        assert record.user_id == 123
        assert hasattr(record, "action")
        assert record.action == "login"


class TestContextManagement:
    """Tests for context management."""

    def setup_method(self):
        """Clear context before each test."""
        clear_context()

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()

    def test_bind_context(self):
        """Test bind_context adds fields."""
        bind_context(request_id="req-123", user_id=456)

        context = get_context()
        assert context["request_id"] == "req-123"
        assert context["user_id"] == 456

    def test_unbind_context(self):
        """Test unbind_context removes fields."""
        bind_context(request_id="req-123", user_id=456)
        unbind_context("request_id")

        context = get_context()
        assert "request_id" not in context
        assert context["user_id"] == 456

    def test_unbind_multiple_keys(self):
        """Test unbind_context with multiple keys."""
        bind_context(a=1, b=2, c=3)
        unbind_context("a", "c")

        context = get_context()
        assert "a" not in context
        assert context["b"] == 2
        assert "c" not in context

    def test_clear_context(self):
        """Test clear_context removes all fields."""
        bind_context(request_id="req-123", user_id=456)
        clear_context()

        context = get_context()
        assert len(context) == 0

    def test_get_context_returns_copy(self):
        """Test get_context returns a copy."""
        bind_context(request_id="req-123")

        context1 = get_context()
        context2 = get_context()

        # Modifying one shouldn't affect the other
        context1["new_field"] = "value"
        assert "new_field" not in context2


class TestLogContext:
    """Tests for LogContext context manager."""

    def setup_method(self):
        """Clear context before each test."""
        clear_context()

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()

    def test_log_context_adds_fields(self):
        """Test LogContext adds fields temporarily."""
        with LogContext(request_id="req-123", user_id=456):
            context = get_context()
            assert context["request_id"] == "req-123"
            assert context["user_id"] == 456

        # Context should be removed after exiting
        context = get_context()
        assert "request_id" not in context
        assert "user_id" not in context

    def test_log_context_restores_previous(self):
        """Test LogContext restores previous context."""
        bind_context(request_id="original")

        with LogContext(request_id="temporary"):
            context = get_context()
            assert context["request_id"] == "temporary"

        context = get_context()
        assert context["request_id"] == "original"

    def test_log_context_nested(self):
        """Test nested LogContext."""
        bind_context(level="base")

        with LogContext(level="outer", user_id=123):
            assert get_context()["level"] == "outer"
            assert get_context()["user_id"] == 123

            with LogContext(level="inner", session_id="abc"):
                assert get_context()["level"] == "inner"
                assert get_context()["user_id"] == 123
                assert get_context()["session_id"] == "abc"

            # Back to outer context
            assert get_context()["level"] == "outer"
            assert "session_id" not in get_context()

        # Back to base context
        assert get_context()["level"] == "base"
        assert "user_id" not in get_context()

    def test_log_context_with_logger(self, caplog):
        """Test LogContext integrates with logger."""
        logger = get_logger("test")

        with LogContext(request_id="req-123"):
            with caplog.at_level(logging.INFO):
                logger.info("Test message")

            # Check that the record has context fields
            assert len(caplog.records) == 1
            record = caplog.records[0]
            assert hasattr(record, "request_id")
            assert record.request_id == "req-123"


class TestConfigureLogging:
    """Tests for configure_logging."""

    def teardown_method(self):
        """Clear handlers after each test."""
        root_logger = logging.getLogger()
        root_logger.handlers.clear()

    def test_configure_logging_default(self):
        """Test configure_logging with defaults."""
        configure_logging()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO
        assert len(root_logger.handlers) > 0

    def test_configure_logging_debug_level(self):
        """Test configure_logging with DEBUG level."""
        configure_logging(level="DEBUG")

        root_logger = logging.getLogger()
        assert root_logger.level == logging.DEBUG

    def test_configure_logging_json_format(self):
        """Test configure_logging with JSON format."""
        configure_logging(format="json")

        root_logger = logging.getLogger()
        assert len(root_logger.handlers) > 0
        # Check that handler has JSONFormatter
        from dspu.observability.logging import JSONFormatter

        assert any(isinstance(h.formatter, JSONFormatter) for h in root_logger.handlers)

    def test_configure_logging_console_format(self):
        """Test configure_logging with console format."""
        configure_logging(format="console")

        root_logger = logging.getLogger()
        assert len(root_logger.handlers) > 0
        # Check that handler has ConsoleFormatter
        from dspu.observability.logging import ConsoleFormatter

        assert any(isinstance(h.formatter, ConsoleFormatter) for h in root_logger.handlers)

    def test_configure_logging_multiple_outputs(self, tmp_path):
        """Test configure_logging with multiple outputs."""
        log_file = tmp_path / "test.log"

        configure_logging(outputs=["stdout", f"file:{log_file}"])

        root_logger = logging.getLogger()
        # Should have 2 handlers: one for stdout, one for file
        assert len(root_logger.handlers) == 2

    def test_configure_logging_stderr_output(self):
        """Test configure_logging with stderr output."""
        configure_logging(outputs=["stderr"])

        root_logger = logging.getLogger()
        assert len(root_logger.handlers) == 1
        import sys

        assert root_logger.handlers[0].stream == sys.stderr

    def test_configure_logging_invalid_output(self):
        """Test configure_logging with invalid output (should be skipped)."""
        configure_logging(outputs=["invalid_output", "stdout"])

        root_logger = logging.getLogger()
        # Should only have 1 handler (invalid_output should be skipped)
        assert len(root_logger.handlers) == 1

    def test_configure_logging_rich_format(self):
        """Test configure_logging with rich format."""
        configure_logging(format="rich")

        root_logger = logging.getLogger()
        assert len(root_logger.handlers) > 0


class TestConsoleFormatter:
    """Tests for ConsoleFormatter."""

    def test_console_formatter_basic(self):
        """Test ConsoleFormatter formats basic log record."""
        from dspu.observability.logging import ConsoleFormatter

        formatter = ConsoleFormatter()
        logger = logging.getLogger("test_console")
        logger.handlers.clear()

        # Create a log record
        record = logger.makeRecord(
            "test_console",
            logging.INFO,
            __file__,
            1,
            "Test message",
            (),
            None,
        )

        formatted = formatter.format(record)
        assert "Test message" in formatted

    def test_console_formatter_with_extra_fields(self):
        """Test ConsoleFormatter with extra fields."""
        from dspu.observability.logging import ConsoleFormatter

        formatter = ConsoleFormatter()
        logger = logging.getLogger("test_console")

        # Create a log record with extra fields
        record = logger.makeRecord(
            "test_console",
            logging.INFO,
            __file__,
            1,
            "Test message",
            (),
            None,
        )
        record.user_id = 123
        record.action = "login"

        formatted = formatter.format(record)
        assert "Test message" in formatted
        assert "user_id=123" in formatted
        assert "action='login'" in formatted


class TestJSONFormatter:
    """Tests for JSONFormatter."""

    def test_json_formatter_basic(self):
        """Test JSONFormatter formats basic log record."""
        import json

        from dspu.observability.logging import JSONFormatter

        formatter = JSONFormatter()
        logger = logging.getLogger("test_json")

        # Create a log record
        record = logger.makeRecord("test_json", logging.INFO, __file__, 1, "Test message", (), None)

        formatted = formatter.format(record)
        log_data = json.loads(formatted)

        assert log_data["level"] == "INFO"
        assert log_data["message"] == "Test message"
        assert log_data["logger"] == "test_json"

    def test_json_formatter_with_timestamp(self):
        """Test JSONFormatter includes timestamp when show_time=True."""
        import json

        from dspu.observability.logging import JSONFormatter

        formatter = JSONFormatter(show_time=True)
        logger = logging.getLogger("test_json")

        record = logger.makeRecord("test_json", logging.INFO, __file__, 1, "Test message", (), None)

        formatted = formatter.format(record)
        log_data = json.loads(formatted)

        assert "timestamp" in log_data

    def test_json_formatter_with_extra_fields(self):
        """Test JSONFormatter with extra fields."""
        import json

        from dspu.observability.logging import JSONFormatter

        formatter = JSONFormatter()
        logger = logging.getLogger("test_json")

        # Create a log record with extra fields
        record = logger.makeRecord("test_json", logging.INFO, __file__, 1, "Test message", (), None)
        record.user_id = 123
        record.action = "login"

        formatted = formatter.format(record)
        log_data = json.loads(formatted)

        assert log_data["user_id"] == 123
        assert log_data["action"] == "login"

    def test_json_formatter_with_exception(self):
        """Test JSONFormatter with exception info."""
        import json

        from dspu.observability.logging import JSONFormatter

        formatter = JSONFormatter()
        logger = logging.getLogger("test_json")

        try:
            raise ValueError("Test error")
        except ValueError:
            import sys

            exc_info = sys.exc_info()
            record = logger.makeRecord(
                "test_json",
                logging.ERROR,
                __file__,
                1,
                "Error occurred",
                (),
                exc_info,
            )

            formatted = formatter.format(record)
            log_data = json.loads(formatted)

            assert "exception" in log_data
            assert "ValueError: Test error" in log_data["exception"]

    def test_json_formatter_with_non_serializable_field(self):
        """Test JSONFormatter converts non-serializable fields to strings."""
        import json

        from dspu.observability.logging import JSONFormatter

        formatter = JSONFormatter()
        logger = logging.getLogger("test_json")

        # Create a log record with a non-serializable field
        record = logger.makeRecord("test_json", logging.INFO, __file__, 1, "Test message", (), None)

        # Add a non-serializable object
        class CustomObject:
            def __repr__(self):
                return "CustomObject()"

        record.custom = CustomObject()

        formatted = formatter.format(record)
        log_data = json.loads(formatted)

        # Should be converted to string
        assert "custom" in log_data
        assert isinstance(log_data["custom"], str)


class TestConfigureFromEnv:
    """Tests for configure_from_env function."""

    def teardown_method(self):
        """Clear handlers and environment after each test."""
        import os

        root_logger = logging.getLogger()
        root_logger.handlers.clear()
        for key in ["LOG_LEVEL", "LOG_FORMAT", "LOG_OUTPUT"]:
            os.environ.pop(key, None)

    def test_configure_from_env_default(self):
        """Test configure_from_env with default values."""
        from dspu.observability.logging import configure_from_env

        configure_from_env()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO
        assert len(root_logger.handlers) > 0

    def test_configure_from_env_custom_level(self):
        """Test configure_from_env with custom log level."""
        import os

        from dspu.observability.logging import configure_from_env

        os.environ["LOG_LEVEL"] = "DEBUG"
        configure_from_env()

        root_logger = logging.getLogger()
        assert root_logger.level == logging.DEBUG

    def test_configure_from_env_custom_format(self):
        """Test configure_from_env with custom format."""
        import os

        from dspu.observability.logging import configure_from_env

        os.environ["LOG_FORMAT"] = "json"
        configure_from_env()

        root_logger = logging.getLogger()
        assert len(root_logger.handlers) > 0
        from dspu.observability.logging import JSONFormatter

        assert any(isinstance(h.formatter, JSONFormatter) for h in root_logger.handlers)

    def test_configure_from_env_multiple_outputs(self, tmp_path):
        """Test configure_from_env with multiple outputs."""
        import os

        from dspu.observability.logging import configure_from_env

        log_file = tmp_path / "test.log"
        os.environ["LOG_OUTPUT"] = f"stdout, file:{log_file}"
        configure_from_env()

        root_logger = logging.getLogger()
        assert len(root_logger.handlers) == 2
