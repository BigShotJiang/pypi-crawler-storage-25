"""Unit tests for I/O module."""
