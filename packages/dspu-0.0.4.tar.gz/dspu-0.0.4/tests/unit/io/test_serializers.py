"""Tests for serialization framework."""

import warnings

import pytest

from dspu.io.serializers import (
    JSONSerializer,
    MessagePackSerializer,
    PickleSerializer,
    SerializationError,
    deserialize,
    detect_format,
    get_serializer,
    serialize,
)


class TestJSONSerializer:
    """Test JSON serializer."""

    def test_serialize_simple_dict(self):
        """Test serializing simple dictionary."""
        serializer = JSONSerializer()
        data = {"name": "Alice", "age": 30}

        result = serializer.serialize(data)

        assert isinstance(result, bytes)
        assert b"Alice" in result
        assert b"30" in result

    def test_deserialize_simple_dict(self):
        """Test deserializing simple dictionary."""
        serializer = JSONSerializer()
        data = {"name": "Alice", "age": 30}
        serialized = serializer.serialize(data)

        result = serializer.deserialize(serialized)

        assert result == data

    def test_roundtrip(self):
        """Test serialize-deserialize roundtrip."""
        serializer = JSONSerializer()
        data = {
            "string": "hello",
            "number": 42,
            "float": 3.14,
            "bool": True,
            "null": None,
            "list": [1, 2, 3],
            "nested": {"key": "value"},
        }

        serialized = serializer.serialize(data)
        result = serializer.deserialize(serialized)

        assert result == data

    def test_serialize_with_indent(self):
        """Test serializing with indentation."""
        serializer = JSONSerializer(indent=2)
        data = {"key": "value"}

        result = serializer.serialize(data)

        # Should have newlines when indented
        assert b"\n" in result

    def test_serialize_with_sort_keys(self):
        """Test serializing with sorted keys."""
        serializer = JSONSerializer(sort_keys=True)
        data = {"z": 1, "a": 2, "m": 3}

        result = serializer.serialize(data)
        text = result.decode("utf-8")

        # Keys should appear in alphabetical order
        assert text.index('"a"') < text.index('"m"') < text.index('"z"')

    def test_serialize_invalid_type(self):
        """Test serializing unsupported type."""
        serializer = JSONSerializer()

        class CustomClass:
            pass

        with pytest.raises(SerializationError) as exc_info:
            serializer.serialize(CustomClass())

        assert "JSON" in str(exc_info.value)

    def test_deserialize_invalid_json(self):
        """Test deserializing invalid JSON."""
        serializer = JSONSerializer()

        with pytest.raises(SerializationError):
            serializer.deserialize(b"{invalid json}")

    def test_deserialize_empty_bytes(self):
        """Test deserializing empty bytes."""
        serializer = JSONSerializer()

        with pytest.raises(SerializationError):
            serializer.deserialize(b"")

    def test_unicode_support(self):
        """Test serializing Unicode strings."""
        serializer = JSONSerializer()
        data = {"emoji": "😀", "chinese": "你好", "arabic": "مرحبا"}

        serialized = serializer.serialize(data)
        result = serializer.deserialize(serialized)

        assert result == data


class TestMessagePackSerializer:
    """Test MessagePack serializer."""

    def test_requires_msgpack(self):
        """Test that MessagePackSerializer requires msgpack."""
        # This test will pass if msgpack is installed, skip otherwise
        try:
            serializer = MessagePackSerializer()
            assert serializer is not None
        except SerializationError as e:
            assert "msgpack" in str(e).lower()
            pytest.skip("msgpack not installed")

    @pytest.mark.skipif(
        not pytest.importorskip("msgpack", reason="msgpack not installed"),
        reason="msgpack not installed",
    )
    def test_serialize_simple_dict(self):
        """Test serializing simple dictionary."""
        serializer = MessagePackSerializer()
        data = {"name": "Alice", "age": 30}

        result = serializer.serialize(data)

        assert isinstance(result, bytes)

    @pytest.mark.skipif(
        not pytest.importorskip("msgpack", reason="msgpack not installed"),
        reason="msgpack not installed",
    )
    def test_roundtrip(self):
        """Test serialize-deserialize roundtrip."""
        serializer = MessagePackSerializer()
        data = {
            "string": "hello",
            "number": 42,
            "float": 3.14,
            "bool": True,
            "null": None,
            "list": [1, 2, 3],
            "nested": {"key": "value"},
            "bytes": b"binary data",
        }

        serialized = serializer.serialize(data)
        result = serializer.deserialize(serialized)

        assert result == data

    @pytest.mark.skipif(
        not pytest.importorskip("msgpack", reason="msgpack not installed"),
        reason="msgpack not installed",
    )
    def test_binary_data(self):
        """Test serializing binary data."""
        serializer = MessagePackSerializer()
        data = {"binary": b"\x00\x01\x02\xff"}

        serialized = serializer.serialize(data)
        result = serializer.deserialize(serialized)

        assert result == data

    @pytest.mark.skipif(
        not pytest.importorskip("msgpack", reason="msgpack not installed"),
        reason="msgpack not installed",
    )
    def test_deserialize_invalid_data(self):
        """Test deserializing invalid MessagePack data."""
        serializer = MessagePackSerializer()

        with pytest.raises(SerializationError):
            serializer.deserialize(b"\xff\xff\xff")


class TestPickleSerializer:
    """Test Pickle serializer."""

    def test_initialization_warns(self):
        """Test that initialization issues security warning."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            PickleSerializer()

            assert len(w) == 1
            assert "insecure" in str(w[0].message).lower()
            assert "pickle" in str(w[0].message).lower()

    def test_serialize_simple_dict(self):
        """Test serializing simple dictionary."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            serializer = PickleSerializer()

        data = {"name": "Alice", "age": 30}

        result = serializer.serialize(data)

        assert isinstance(result, bytes)

    def test_roundtrip(self):
        """Test serialize-deserialize roundtrip."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            serializer = PickleSerializer()

        data = {
            "string": "hello",
            "number": 42,
            "float": 3.14,
            "bool": True,
            "null": None,
            "list": [1, 2, 3],
            "nested": {"key": "value"},
        }

        serialized = serializer.serialize(data)
        result = serializer.deserialize(serialized)

        assert result == data

    def test_serialize_custom_objects(self):
        """Test serializing custom Python objects."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            serializer = PickleSerializer()

        # Use a dict to simulate custom object behavior
        # (Pickle can't serialize local classes defined in tests)
        obj = {"__custom__": True, "value": 42}

        serialized = serializer.serialize(obj)
        result = serializer.deserialize(serialized)

        assert result == obj

    def test_deserialize_invalid_pickle(self):
        """Test deserializing invalid pickle data."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            serializer = PickleSerializer()

        with pytest.raises(SerializationError):
            serializer.deserialize(b"not pickle data")


class TestGetSerializer:
    """Test get_serializer function."""

    def test_get_json_serializer(self):
        """Test getting JSON serializer."""
        serializer = get_serializer("json")

        assert isinstance(serializer, JSONSerializer)

    def test_get_json_case_insensitive(self):
        """Test format is case-insensitive."""
        serializer = get_serializer("JSON")

        assert isinstance(serializer, JSONSerializer)

    def test_get_unsupported_format(self):
        """Test getting unsupported format."""
        with pytest.raises(SerializationError) as exc_info:
            get_serializer("xml")

        assert "xml" in str(exc_info.value).lower()
        assert "supported" in str(exc_info.value).lower()


class TestDetectFormat:
    """Test format detection."""

    def test_detect_json(self):
        """Test detecting JSON format."""
        assert detect_format("data.json") == "json"
        assert detect_format("path/to/file.json") == "json"

    def test_detect_msgpack(self):
        """Test detecting MessagePack format."""
        assert detect_format("data.msgpack") == "msgpack"
        assert detect_format("data.msgpk") == "msgpack"
        assert detect_format("data.mp") == "msgpack"

    def test_detect_pickle(self):
        """Test detecting Pickle format."""
        assert detect_format("model.pkl") == "pickle"
        assert detect_format("data.pickle") == "pickle"

    def test_detect_case_insensitive(self):
        """Test format detection is case-insensitive."""
        assert detect_format("DATA.JSON") == "json"
        assert detect_format("FILE.PKL") == "pickle"

    def test_detect_unknown_extension(self):
        """Test detecting unknown extension."""
        with pytest.raises(SerializationError) as exc_info:
            detect_format("file.xyz")

        assert "cannot detect" in str(exc_info.value).lower()
        assert "xyz" in str(exc_info.value).lower()

    def test_detect_no_extension(self):
        """Test detecting file without extension."""
        with pytest.raises(SerializationError):
            detect_format("filename")


class TestConvenienceFunctions:
    """Test serialize and deserialize convenience functions."""

    def test_serialize_json(self):
        """Test serialize with JSON format."""
        data = {"key": "value"}

        result = serialize(data, "json")

        assert isinstance(result, bytes)
        assert b"key" in result

    def test_deserialize_json(self):
        """Test deserialize with JSON format."""
        data = {"key": "value"}
        serialized = serialize(data, "json")

        result = deserialize(serialized, "json")

        assert result == data

    def test_roundtrip_convenience(self):
        """Test full roundtrip using convenience functions."""
        data = {
            "numbers": [1, 2, 3],
            "string": "hello",
            "nested": {"inner": "value"},
        }

        serialized = serialize(data, "json")
        result = deserialize(serialized, "json")

        assert result == data

    def test_serialize_invalid_format(self):
        """Test serialize with invalid format."""
        with pytest.raises(SerializationError):
            serialize({"key": "value"}, "xml")

    def test_deserialize_invalid_format(self):
        """Test deserialize with invalid format."""
        with pytest.raises(SerializationError):
            deserialize(b"data", "xml")


class TestSerializerDocumentation:
    """Test that serializers are properly documented."""

    def test_json_serializer_has_docstring(self):
        """Test JSONSerializer has documentation."""
        assert JSONSerializer.__doc__ is not None
        assert len(JSONSerializer.__doc__) > 50

    def test_msgpack_serializer_has_docstring(self):
        """Test MessagePackSerializer has documentation."""
        assert MessagePackSerializer.__doc__ is not None

    def test_pickle_serializer_has_docstring(self):
        """Test PickleSerializer has documentation."""
        assert PickleSerializer.__doc__ is not None


class TestSerializationError:
    """Test SerializationError exception."""

    def test_serialization_error_basic(self):
        """Test basic SerializationError."""
        error = SerializationError("Test error")

        assert "Test error" in str(error)

    def test_serialization_error_with_format(self):
        """Test SerializationError with format."""
        error = SerializationError("Failed", format="json")

        assert "Failed" in str(error)
        assert "json" in str(error).lower()

    def test_serialization_error_with_suggestion(self):
        """Test SerializationError with suggestion."""
        error = SerializationError("Failed", suggestion="Try this")

        assert "Failed" in str(error)
        assert "Try this" in str(error)

    def test_serialization_error_is_dspu_error(self):
        """Test that SerializationError inherits from DSPUError."""
        from dspu.core.exceptions import DSPUError

        error = SerializationError("Test")

        assert isinstance(error, DSPUError)
