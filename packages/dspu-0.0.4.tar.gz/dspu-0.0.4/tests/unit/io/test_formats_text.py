"""Tests for text format handlers (Text, Python, Markdown, Env)."""

from pathlib import Path

import pytest

from dspu.io.formats import (
    EnvFormat,
    FormatError,
    MarkdownFormat,
    PythonFormat,
    TextFormat,
)


class TestTextFormat:
    """Tests for plain text format handler."""

    def test_write_string(self, tmp_path: Path):
        """Test writing string to text."""
        fmt = TextFormat()
        data = "Hello, world!\nThis is a test."

        result = fmt.write(data, tmp_path / "test.txt")

        assert isinstance(result, bytes)
        assert result == b"Hello, world!\nThis is a test."

    def test_write_non_string_fails(self, tmp_path: Path):
        """Test writing non-string raises error."""
        fmt = TextFormat()

        with pytest.raises(FormatError):
            fmt.write({"key": "value"}, tmp_path / "test.txt")

    def test_read_string(self):
        """Test reading text."""
        fmt = TextFormat()
        data = b"Hello, world!"

        result = fmt.read(data)

        assert result == "Hello, world!"

    def test_read_unicode(self):
        """Test reading unicode text."""
        fmt = TextFormat()
        data = "Hello 世界 🌍".encode()

        result = fmt.read(data)

        assert result == "Hello 世界 🌍"

    def test_custom_encoding(self):
        """Test with custom encoding."""
        fmt = TextFormat(encoding="latin-1")
        data = "café"

        bytes_data = fmt.write(data, "test.txt")
        result = fmt.read(bytes_data)

        assert result == "café"

    def test_can_write_string(self):
        """Test can_write returns True for string."""
        fmt = TextFormat()
        assert fmt.can_write("test") is True

    def test_can_write_non_string(self):
        """Test can_write returns False for non-string."""
        fmt = TextFormat()
        assert fmt.can_write(123) is False

    def test_extensions(self):
        """Test extensions property."""
        fmt = TextFormat()
        assert ".txt" in fmt.extensions
        assert ".text" in fmt.extensions


class TestPythonFormat:
    """Tests for Python code format handler."""

    def test_write_valid_code(self, tmp_path: Path):
        """Test writing valid Python code."""
        fmt = PythonFormat()
        code = '''
def hello(name: str) -> str:
    """Greet someone."""
    return f"Hello, {name}!"
'''

        result = fmt.write(code, tmp_path / "test.py")

        assert isinstance(result, bytes)
        assert b"def hello" in result

    def test_write_invalid_syntax_fails(self, tmp_path: Path):
        """Test writing invalid Python syntax raises error."""
        fmt = PythonFormat(validate_syntax=True)
        code = "def broken(:\n    pass"

        with pytest.raises(FormatError):
            fmt.write(code, tmp_path / "test.py")

    def test_write_no_validation(self, tmp_path: Path):
        """Test writing with validation disabled."""
        fmt = PythonFormat(validate_syntax=False)
        code = "def broken(:\n    pass"

        # Should not raise with validation disabled
        result = fmt.write(code, tmp_path / "test.py")
        assert isinstance(result, bytes)

    def test_read_python_code(self):
        """Test reading Python code."""
        fmt = PythonFormat()
        data = b'def hello():\n    return "world"\n'

        result = fmt.read(data)

        assert result == 'def hello():\n    return "world"\n'

    def test_can_write_string(self):
        """Test can_write returns True for string."""
        fmt = PythonFormat()
        assert fmt.can_write("def test(): pass") is True

    def test_can_write_non_string(self):
        """Test can_write returns False for non-string."""
        fmt = PythonFormat()
        assert fmt.can_write([1, 2, 3]) is False

    def test_extensions(self):
        """Test extensions property."""
        fmt = PythonFormat()
        assert ".py" in fmt.extensions


class TestMarkdownFormat:
    """Tests for Markdown format handler."""

    def test_write_markdown(self, tmp_path: Path):
        """Test writing Markdown text."""
        fmt = MarkdownFormat()
        markdown = """# My Document

This is a paragraph with **bold** and *italic* text.

## Section

- Item 1
- Item 2
"""

        result = fmt.write(markdown, tmp_path / "README.md")

        assert isinstance(result, bytes)
        assert b"# My Document" in result
        assert b"**bold**" in result

    def test_write_non_string_fails(self, tmp_path: Path):
        """Test writing non-string raises error."""
        fmt = MarkdownFormat()

        with pytest.raises(FormatError):
            fmt.write({"title": "Test"}, tmp_path / "test.md")

    def test_read_markdown(self):
        """Test reading Markdown."""
        fmt = MarkdownFormat()
        data = b"# Title\n\nParagraph with **bold** text."

        result = fmt.read(data)

        assert result == "# Title\n\nParagraph with **bold** text."

    def test_can_write_string(self):
        """Test can_write returns True for string."""
        fmt = MarkdownFormat()
        assert fmt.can_write("# Markdown") is True

    def test_can_write_non_string(self):
        """Test can_write returns False for non-string."""
        fmt = MarkdownFormat()
        assert fmt.can_write({"key": "value"}) is False

    def test_extensions(self):
        """Test extensions property."""
        fmt = MarkdownFormat()
        assert ".md" in fmt.extensions
        assert ".markdown" in fmt.extensions


class TestEnvFormat:
    """Tests for environment file format handler."""

    def test_write_dict(self, tmp_path: Path):
        """Test writing dictionary to .env format."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        data = {
            "DATABASE_URL": "postgresql://localhost/db",
            "SECRET_KEY": "abc123",
            "DEBUG": "true",
        }

        result = fmt.write(data, tmp_path / ".env")

        assert isinstance(result, bytes)
        assert b"DATABASE_URL=" in result
        assert b"SECRET_KEY=" in result

    def test_write_with_quotes(self, tmp_path: Path):
        """Test writing values with spaces (auto-quoted)."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        data = {"MESSAGE": "Hello World"}

        result = fmt.write(data, tmp_path / ".env")

        # Should be quoted because of space
        assert b'"Hello World"' in result

    def test_write_with_export(self, tmp_path: Path):
        """Test writing with export prefix."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat(export_prefix=True)
        data = {"VAR": "value"}

        result = fmt.write(data, tmp_path / ".env")

        assert b"export VAR=" in result

    def test_write_invalid_key_fails(self, tmp_path: Path):
        """Test writing invalid key raises error."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        data = {"my-invalid key!": "value"}

        with pytest.raises(FormatError):
            fmt.write(data, tmp_path / ".env")

    def test_write_non_dict_fails(self, tmp_path: Path):
        """Test writing non-dict raises error."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()

        with pytest.raises(FormatError):
            fmt.write("not a dict", tmp_path / ".env")

    def test_read_env_file(self):
        """Test reading .env file."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        data = b"DATABASE_URL=postgresql://localhost/db\nDEBUG=true\n"

        result = fmt.read(data)

        assert result == {
            "DATABASE_URL": "postgresql://localhost/db",
            "DEBUG": "true",
        }

    def test_can_write_dict_with_str_keys(self):
        """Test can_write returns True for dict with string keys."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        assert fmt.can_write({"KEY": "value"}) is True

    def test_can_write_dict_with_non_str_keys(self):
        """Test can_write returns False for dict with non-string keys."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        assert fmt.can_write({1: "value"}) is False

    def test_can_write_non_dict(self):
        """Test can_write returns False for non-dict."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        assert fmt.can_write("string") is False

    def test_extensions(self):
        """Test extensions property."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        assert ".env" in fmt.extensions

    def test_write_non_string_key_raises(self):
        """Test writing dict with non-string keys raises error."""
        pytest.importorskip("dotenv")

        fmt = EnvFormat()
        with pytest.raises(FormatError, match="Env var keys must be strings"):
            fmt.write({123: "value"}, "test.env")


class TestTextFormatErrors:
    """Additional error handling tests."""

    def test_text_decode_error(self):
        """Test TextFormat with invalid encoding raises error."""
        fmt = TextFormat(encoding="utf-8")
        # Invalid UTF-8 bytes
        data = b"\x80\x81\x82"
        with pytest.raises(FormatError, match="Cannot decode text"):
            fmt.read(data)


class TestPythonFormatErrors:
    """Additional error handling tests for PythonFormat."""

    def test_write_non_string_raises(self):
        """Test PythonFormat write with non-string raises error."""
        fmt = PythonFormat()
        with pytest.raises(FormatError, match="PythonFormat requires str"):
            fmt.write(["not", "a", "string"], "test.py")


class TestMarkdownFormatValidation:
    """Tests for MarkdownFormat header validation."""

    def test_markdown_with_headers(self, tmp_path: Path):
        """Test markdown with headers passes validation."""
        fmt = MarkdownFormat(validate_headers=True)
        data = "# Title\n\nSome content here.\n\n## Section\n\nMore content."

        result = fmt.write(data, tmp_path / "test.md")

        assert isinstance(result, bytes)
        assert b"# Title" in result

    def test_markdown_without_headers(self, tmp_path: Path):
        """Test markdown without headers (should still succeed but validation logic is executed)."""
        fmt = MarkdownFormat(validate_headers=True)
        data = "Just plain text without any headers."

        # Should not raise, but validation logic is executed
        result = fmt.write(data, tmp_path / "test.md")

        assert isinstance(result, bytes)
