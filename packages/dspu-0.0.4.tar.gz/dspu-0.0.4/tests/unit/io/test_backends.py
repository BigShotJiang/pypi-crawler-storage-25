"""Tests for storage backend protocol and base types."""

from datetime import UTC, datetime

import pytest

from dspu.io.backends import FileInfo, parse_uri


class TestFileInfo:
    """Test FileInfo dataclass."""

    def test_file_info_creation(self):
        """Test creating FileInfo instance."""
        now = datetime.now(UTC)
        info = FileInfo(
            path="test.txt",
            size=1024,
            modified=now,
            is_dir=False,
        )

        assert info.path == "test.txt"
        assert info.size == 1024
        assert info.modified == now
        assert info.is_dir is False

    def test_file_info_directory(self):
        """Test FileInfo for directory."""
        now = datetime.now(UTC)
        info = FileInfo(
            path="testdir",
            size=0,
            modified=now,
            is_dir=True,
        )

        assert info.is_dir is True

    def test_file_info_frozen(self):
        """Test that FileInfo is immutable."""
        info = FileInfo(
            path="test.txt",
            size=1024,
            modified=datetime.now(UTC),
        )

        with pytest.raises((AttributeError, TypeError)):  # FrozenInstanceError
            info.path = "new.txt"


class TestParseUri:
    """Test URI parsing."""

    def test_parse_file_uri_with_scheme(self):
        """Test parsing file:// URI."""
        scheme, path = parse_uri("file:///home/user/data")

        assert scheme == "file"
        assert str(path) == "/home/user/data"

    def test_parse_file_uri_without_scheme(self):
        """Test parsing path without scheme."""
        scheme, path = parse_uri("/home/user/data")

        assert scheme == "file"
        assert path.is_absolute()

    def test_parse_s3_uri(self):
        """Test parsing S3 URI."""
        scheme, path = parse_uri("s3://my-bucket/path/to/file")

        assert scheme == "s3"
        assert str(path) == "my-bucket/path/to/file"

    def test_parse_gs_uri(self):
        """Test parsing Google Cloud Storage URI."""
        scheme, path = parse_uri("gs://my-bucket/path")

        assert scheme == "gs"
        assert str(path) == "my-bucket/path"

    def test_parse_azure_uri(self):
        """Test parsing Azure Blob Storage URI."""
        scheme, path = parse_uri("az://container/path")

        assert scheme == "az"
        assert str(path) == "container/path"

    def test_parse_relative_path(self):
        """Test parsing relative path."""
        scheme, path = parse_uri("data/local")

        assert scheme == "file"
        assert path.is_absolute()  # Resolved to absolute

    def test_parse_path_with_tilde(self):
        """Test parsing path with tilde expansion."""
        scheme, path = parse_uri("~/data")

        assert scheme == "file"
        assert "~" not in str(path)  # Tilde expanded
        assert path.is_absolute()

    def test_scheme_case_insensitive(self):
        """Test that scheme is case-insensitive."""
        scheme1, _ = parse_uri("S3://bucket/path")
        scheme2, _ = parse_uri("s3://bucket/path")

        assert scheme1 == scheme2 == "s3"
