"""Tests for tabular format handlers (CSV)."""

from pathlib import Path

import pytest

from dspu.io.formats import CSVFormat, FormatError


class TestCSVFormat:
    """Tests for CSV format handler."""

    def test_write_list_of_dicts(self, tmp_path: Path):
        """Test writing list of dicts to CSV."""
        fmt = CSVFormat(header=True)
        data = [
            {"name": "Alice", "age": 30, "city": "NYC"},
            {"name": "Bob", "age": 25, "city": "LA"},
            {"name": "Charlie", "age": 35, "city": "Chicago"},
        ]

        result = fmt.write(data, tmp_path / "users.csv")

        assert isinstance(result, bytes)
        # Should have header
        assert b"name" in result
        assert b"age" in result
        # Should have data
        assert b"Alice" in result
        assert b"Bob" in result

    def test_write_list_of_dicts_no_header(self, tmp_path: Path):
        """Test writing list of dicts without header."""
        fmt = CSVFormat(header=False)
        data = [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "age": 25},
        ]

        result = fmt.write(data, tmp_path / "users.csv")

        # Header line should not be present as separate header row
        # (values will still appear in data)
        lines = result.decode("utf-8").strip().split("\n")
        # With header=False, we have 2 data lines
        # With header=True, we would have 3 lines (1 header + 2 data)
        assert len(lines) == 2

    def test_write_list_of_lists(self, tmp_path: Path):
        """Test writing 2D list to CSV."""
        fmt = CSVFormat()
        data = [
            ["Name", "Age", "City"],
            ["Alice", 30, "NYC"],
            ["Bob", 25, "LA"],
        ]

        result = fmt.write(data, tmp_path / "data.csv")

        assert isinstance(result, bytes)
        assert b"Name" in result
        assert b"Alice" in result

    def test_write_list_of_tuples(self, tmp_path: Path):
        """Test writing list of tuples to CSV."""
        fmt = CSVFormat()
        data = [
            ("Alice", 30, "NYC"),
            ("Bob", 25, "LA"),
        ]

        result = fmt.write(data, tmp_path / "data.csv")

        assert isinstance(result, bytes)
        assert b"Alice" in result

    def test_write_custom_delimiter(self, tmp_path: Path):
        """Test writing CSV with custom delimiter."""
        fmt = CSVFormat(delimiter=";")
        data = [["a", "b"], ["c", "d"]]

        result = fmt.write(data, tmp_path / "data.csv")

        # Should use semicolon as delimiter
        assert b";" in result
        # Should not use comma
        assert result.count(b",") == 0

    def test_write_empty_list_fails(self, tmp_path: Path):
        """Test writing empty list raises error."""
        fmt = CSVFormat()
        data = []

        with pytest.raises(FormatError):
            fmt.write(data, tmp_path / "data.csv")

    def test_write_non_list_fails(self, tmp_path: Path):
        """Test writing non-list raises error."""
        fmt = CSVFormat()
        data = {"name": "Alice"}

        with pytest.raises(FormatError):
            fmt.write(data, tmp_path / "data.csv")

    def test_write_list_of_invalid_type_fails(self, tmp_path: Path):
        """Test writing list of invalid types raises error."""
        fmt = CSVFormat()
        data = ["string1", "string2"]  # List of strings, not dicts or lists

        with pytest.raises(FormatError):
            fmt.write(data, tmp_path / "data.csv")

    def test_read_csv_to_list_of_dicts(self):
        """Test reading CSV to list of dicts."""
        fmt = CSVFormat()
        data = b"name,age,city\nAlice,30,NYC\nBob,25,LA\n"

        result = fmt.read(data)

        assert result == [
            {"name": "Alice", "age": "30", "city": "NYC"},
            {"name": "Bob", "age": "25", "city": "LA"},
        ]

    def test_read_csv_custom_delimiter(self):
        """Test reading CSV with custom delimiter."""
        fmt = CSVFormat(delimiter=";")
        data = b"name;age\nAlice;30\nBob;25\n"

        result = fmt.read(data)

        assert result == [
            {"name": "Alice", "age": "30"},
            {"name": "Bob", "age": "25"},
        ]

    def test_can_write_list_of_dicts(self):
        """Test can_write returns True for list of dicts."""
        fmt = CSVFormat()
        assert fmt.can_write([{"name": "Alice"}]) is True

    def test_can_write_list_of_lists(self):
        """Test can_write returns True for list of lists."""
        fmt = CSVFormat()
        assert fmt.can_write([["a", "b"]]) is True

    def test_can_write_empty_list(self):
        """Test can_write returns False for empty list."""
        fmt = CSVFormat()
        assert fmt.can_write([]) is False

    def test_can_write_non_list(self):
        """Test can_write returns False for non-list."""
        fmt = CSVFormat()
        assert fmt.can_write({"key": "value"}) is False

    def test_can_write_list_of_strings(self):
        """Test can_write returns False for list of strings."""
        fmt = CSVFormat()
        assert fmt.can_write(["a", "b"]) is False

    def test_extensions(self):
        """Test extensions property."""
        fmt = CSVFormat()
        assert ".csv" in fmt.extensions

    def test_roundtrip_dict_format(self, tmp_path: Path):
        """Test write and read roundtrip with dict format."""
        fmt = CSVFormat(header=True)
        original = [
            {"name": "Alice", "age": "30"},
            {"name": "Bob", "age": "25"},
        ]

        # Write
        bytes_data = fmt.write(original, tmp_path / "test.csv")

        # Read
        result = fmt.read(bytes_data)

        assert result == original
