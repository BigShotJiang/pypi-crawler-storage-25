"""Tests for path resolution utilities."""

from pathlib import Path

import pytest

from dspu.core.exceptions import DSPUIOError
from dspu.io.paths import PathResolver, resolve_path


class TestPathResolverInitialization:
    """Tests for PathResolver initialization."""

    def test_init_with_defaults(self, tmp_path: Path):
        """Test initialization with default basis."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))

        assert resolver.source_file == source_file
        assert resolver.basis == "."

    def test_init_with_custom_basis(self, tmp_path: Path):
        """Test initialization with custom basis directory."""
        source_file = tmp_path / "src" / "mymodule.py"
        source_file.parent.mkdir(parents=True, exist_ok=True)
        source_file.touch()

        resolver = PathResolver(str(source_file), basis="../configs")

        assert resolver.source_file == source_file
        assert resolver.basis == "../configs"


class TestPathResolverGetters:
    """Tests for PathResolver getter methods."""

    def test_get_source_path(self, tmp_path: Path):
        """Test getting absolute source file path."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))
        source_path = resolver.get_source_path()

        assert source_path.is_absolute()
        assert source_path == source_file.resolve()

    def test_get_source_dir(self, tmp_path: Path):
        """Test getting source file directory."""
        subdir = tmp_path / "src"
        subdir.mkdir()
        source_file = subdir / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))
        source_dir = resolver.get_source_dir()

        assert source_dir.is_absolute()
        assert source_dir == subdir.resolve()

    def test_get_basis_path_default(self, tmp_path: Path):
        """Test getting basis path with default basis."""
        subdir = tmp_path / "src"
        subdir.mkdir()
        source_file = subdir / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))
        basis_path = resolver.get_basis_path()

        # Default basis "." means the source file's directory
        assert basis_path == subdir.resolve()

    def test_get_basis_path_custom(self, tmp_path: Path):
        """Test getting basis path with custom basis."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        configs_dir = tmp_path / "configs"
        configs_dir.mkdir()
        source_file = src_dir / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file), basis="../configs")
        basis_path = resolver.get_basis_path()

        assert basis_path == configs_dir.resolve()


class TestPathResolverResolve:
    """Tests for PathResolver.resolve() method."""

    def test_resolve_simple_filename(self, tmp_path: Path):
        """Test resolving a simple filename."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        data_file = tmp_path / "data.json"
        data_file.touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("data.json")

        assert resolved == data_file.resolve()
        assert resolved.is_absolute()

    def test_resolve_with_subdirectory(self, tmp_path: Path):
        """Test resolving filename in subdirectory."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        subdir = tmp_path / "data"
        subdir.mkdir()
        data_file = subdir / "config.yaml"
        data_file.touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("data/config.yaml")

        assert resolved == data_file.resolve()

    def test_resolve_with_custom_basis(self, tmp_path: Path):
        """Test resolving with custom basis directory."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        configs_dir = tmp_path / "configs"
        configs_dir.mkdir()
        source_file = src_dir / "mymodule.py"
        source_file.touch()
        config_file = configs_dir / "app.yaml"
        config_file.touch()

        resolver = PathResolver(str(source_file), basis="../configs")
        resolved = resolver.resolve("app.yaml")

        assert resolved == config_file.resolve()

    def test_resolve_check_exists_true(self, tmp_path: Path):
        """Test resolve with check_exists=True for existing file."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        data_file = tmp_path / "data.json"
        data_file.touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("data.json", check_exists=True)

        assert resolved == data_file.resolve()

    def test_resolve_check_exists_false_missing_file(self, tmp_path: Path):
        """Test resolve with check_exists=False for missing file."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("missing.json", check_exists=False)

        # Should not raise, returns path even if it doesn't exist
        assert resolved == (tmp_path / "missing.json").resolve()

    def test_resolve_check_exists_true_missing_file(self, tmp_path: Path):
        """Test resolve with check_exists=True for missing file raises error."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))

        with pytest.raises(FileNotFoundError) as exc_info:
            resolver.resolve("missing.json", check_exists=True)

        assert "missing.json" in str(exc_info.value)

    def test_resolve_must_be_file(self, tmp_path: Path):
        """Test resolve with must_be_file=True for a file."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        data_file = tmp_path / "data.json"
        data_file.touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("data.json", must_be_file=True)

        assert resolved == data_file.resolve()

    def test_resolve_must_be_file_for_directory(self, tmp_path: Path):
        """Test resolve with must_be_file=True for directory raises error."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        subdir = tmp_path / "data"
        subdir.mkdir()

        resolver = PathResolver(str(source_file))

        with pytest.raises(IsADirectoryError) as exc_info:
            resolver.resolve("data", must_be_file=True)

        assert "directory" in str(exc_info.value).lower()

    def test_resolve_must_be_file_missing(self, tmp_path: Path):
        """Test resolve with must_be_file=True for missing file raises error."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))

        with pytest.raises(FileNotFoundError):
            resolver.resolve("missing.json", must_be_file=True)

    def test_resolve_must_be_dir(self, tmp_path: Path):
        """Test resolve with must_be_dir=True for a directory."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        subdir = tmp_path / "data"
        subdir.mkdir()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("data", must_be_dir=True)

        assert resolved == subdir.resolve()

    def test_resolve_must_be_dir_for_file(self, tmp_path: Path):
        """Test resolve with must_be_dir=True for file raises error."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()
        data_file = tmp_path / "data.json"
        data_file.touch()

        resolver = PathResolver(str(source_file))

        with pytest.raises(NotADirectoryError) as exc_info:
            resolver.resolve("data.json", must_be_dir=True)

        assert "file" in str(exc_info.value).lower()

    def test_resolve_must_be_dir_missing(self, tmp_path: Path):
        """Test resolve with must_be_dir=True for missing directory raises error."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))

        with pytest.raises(FileNotFoundError):
            resolver.resolve("missing_dir", must_be_dir=True)


class TestPathResolverSecurity:
    """Tests for PathResolver security features."""

    def test_path_traversal_blocked_parent(self, tmp_path: Path):
        """Test that path traversal using .. is blocked."""
        source_file = tmp_path / "src" / "mymodule.py"
        source_file.parent.mkdir(parents=True, exist_ok=True)
        source_file.touch()

        resolver = PathResolver(str(source_file))

        # Try to escape the basis directory
        with pytest.raises(DSPUIOError) as exc_info:
            resolver.resolve("../../etc/passwd")

        assert "escapes basis directory" in str(exc_info.value)

    def test_path_traversal_blocked_absolute(self, tmp_path: Path):
        """Test that absolute paths outside basis are blocked."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))

        # Try to use absolute path outside basis
        with pytest.raises(DSPUIOError) as exc_info:
            resolver.resolve("/etc/passwd")

        assert "escapes basis directory" in str(exc_info.value)

    def test_symlink_following_within_basis(self, tmp_path: Path):
        """Test that symlinks within basis are allowed."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        # Create target file
        target = tmp_path / "target.txt"
        target.write_text("data")

        # Create symlink to target within same directory
        link = tmp_path / "link.txt"
        link.symlink_to(target)

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve("link.txt")

        # Should resolve to the target, which is still within basis
        assert resolved == target.resolve()

    def test_symlink_escaping_basis_blocked(self, tmp_path: Path):
        """Test that symlinks pointing outside basis are blocked."""
        basis_dir = tmp_path / "safe"
        basis_dir.mkdir()
        source_file = basis_dir / "mymodule.py"
        source_file.touch()

        # Create target outside basis
        outside = tmp_path / "outside"
        outside.mkdir()
        target = outside / "secret.txt"
        target.write_text("secret")

        # Create symlink inside basis pointing outside
        link = basis_dir / "link.txt"
        link.symlink_to(target)

        resolver = PathResolver(str(source_file))

        # Should block because resolved path is outside basis
        with pytest.raises(DSPUIOError) as exc_info:
            resolver.resolve("link.txt")

        assert "escapes basis directory" in str(exc_info.value)


class TestPathResolverResolveAll:
    """Tests for PathResolver.resolve_all() method."""

    def test_resolve_all_multiple_files(self, tmp_path: Path):
        """Test resolving multiple files at once."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        files = ["a.txt", "b.txt", "c.txt"]
        for filename in files:
            (tmp_path / filename).touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve_all(*files)

        assert len(resolved) == 3
        assert all(p.is_absolute() for p in resolved)
        assert resolved[0] == (tmp_path / "a.txt").resolve()
        assert resolved[1] == (tmp_path / "b.txt").resolve()
        assert resolved[2] == (tmp_path / "c.txt").resolve()

    def test_resolve_all_empty(self, tmp_path: Path):
        """Test resolve_all with no files."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve_all()

        assert resolved == []

    def test_resolve_all_check_exists(self, tmp_path: Path):
        """Test resolve_all with check_exists=True."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        (tmp_path / "a.txt").touch()
        (tmp_path / "b.txt").touch()

        resolver = PathResolver(str(source_file))
        resolved = resolver.resolve_all("a.txt", "b.txt", check_exists=True)

        assert len(resolved) == 2

    def test_resolve_all_check_exists_one_missing(self, tmp_path: Path):
        """Test resolve_all with check_exists=True and missing file."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        (tmp_path / "a.txt").touch()
        # b.txt doesn't exist

        resolver = PathResolver(str(source_file))

        with pytest.raises(FileNotFoundError):
            resolver.resolve_all("a.txt", "b.txt", check_exists=True)


class TestPathResolverCheckPathWithin:
    """Tests for PathResolver.check_path_within() static method."""

    def test_check_path_within_valid(self, tmp_path: Path):
        """Test checking valid path within basis."""
        basis = tmp_path / "safe"
        basis.mkdir()

        path = basis / "data" / "file.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()

        result = PathResolver.check_path_within(path, basis)

        assert result == path.resolve()

    def test_check_path_within_invalid(self, tmp_path: Path):
        """Test checking invalid path outside basis."""
        basis = tmp_path / "safe"
        basis.mkdir()

        outside = tmp_path / "outside"
        outside.mkdir()
        path = outside / "file.txt"
        path.touch()

        with pytest.raises(DSPUIOError) as exc_info:
            PathResolver.check_path_within(path, basis)

        assert "outside basis directory" in str(exc_info.value)

    def test_check_path_within_no_resolve(self, tmp_path: Path):
        """Test checking paths without resolving."""
        basis = tmp_path / "safe"
        basis.mkdir()

        # Use relative paths without resolving
        result = PathResolver.check_path_within(
            "safe/data/file.txt",
            "safe",
            resolve=False,
        )

        # Should work without resolution if relative structure is correct
        assert "safe" in str(result)

    def test_check_path_within_string_paths(self, tmp_path: Path):
        """Test checking with string paths instead of Path objects."""
        basis = tmp_path / "safe"
        basis.mkdir()

        path = basis / "file.txt"
        path.touch()

        result = PathResolver.check_path_within(str(path), str(basis))

        assert result == path.resolve()


class TestResolvePathFunction:
    """Tests for resolve_path() convenience function."""

    def test_resolve_path_simple(self, tmp_path: Path):
        """Test resolve_path convenience function."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        data_file = tmp_path / "data.json"
        data_file.touch()

        resolved = resolve_path(str(source_file), "data.json")

        assert resolved == data_file.resolve()

    def test_resolve_path_with_basis(self, tmp_path: Path):
        """Test resolve_path with custom basis."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        configs_dir = tmp_path / "configs"
        configs_dir.mkdir()

        source_file = src_dir / "mymodule.py"
        source_file.touch()

        config_file = configs_dir / "app.yaml"
        config_file.touch()

        resolved = resolve_path(
            str(source_file),
            "app.yaml",
            basis="../configs",
        )

        assert resolved == config_file.resolve()

    def test_resolve_path_default_basis(self, tmp_path: Path):
        """Test resolve_path uses default basis."""
        source_file = tmp_path / "mymodule.py"
        source_file.touch()

        data_file = tmp_path / "data.json"
        data_file.touch()

        # Should default to basis="."
        resolved = resolve_path(str(source_file), "data.json")

        assert resolved == data_file.resolve()
