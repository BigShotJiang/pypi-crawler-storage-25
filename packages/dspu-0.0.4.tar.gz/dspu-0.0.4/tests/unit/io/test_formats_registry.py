"""Tests for format registry module."""

import pytest

from dspu.core.exceptions import ConfigurationError
from dspu.io.formats.base import FormatError
from dspu.io.formats.registry import (
    _EXTENSION_MAP,
    _FORMATS,
    detect_format_from_path,
    get_format,
    list_extensions,
    list_formats,
    register_format,
    unregister_format,
)


class DummyFormat:
    """Dummy format for testing registration."""

    def write(self, obj, path):
        """Write dummy data."""
        return b"dummy"

    def read(self, data, path=None):
        """Read dummy data."""
        return "dummy"

    def can_write(self, obj):
        """Check if can write."""
        return True

    @property
    def extensions(self):
        """Get extensions."""
        return [".dummy"]


class IncompleteFormat:
    """Incomplete format missing required methods."""

    pass


class NoWriteFormat:
    """Format without write method."""

    def read(self, data, path=None):
        """Read method."""
        return data

    def can_write(self, obj):
        """Can write method."""
        return True

    @property
    def extensions(self):
        """Extensions."""
        return [".nowrit"]


class NoReadFormat:
    """Format without read method."""

    def write(self, obj, path):
        """Write method."""
        return b""

    def can_write(self, obj):
        """Can write method."""
        return True

    @property
    def extensions(self):
        """Extensions."""
        return [".noread"]


class NoCanWriteFormat:
    """Format without can_write method."""

    def write(self, obj, path):
        """Write method."""
        return b""

    def read(self, data, path=None):
        """Read method."""
        return data

    @property
    def extensions(self):
        """Extensions."""
        return [".nocan"]


class NoExtensionsFormat:
    """Format without extensions property."""

    def write(self, obj, path):
        """Write method."""
        return b""

    def read(self, data, path=None):
        """Read method."""
        return data

    def can_write(self, obj):
        """Can write method."""
        return True


class TestGetFormat:
    """Tests for get_format function."""

    def test_get_json_format(self):
        """Test getting JSON format."""
        fmt = get_format("json")
        assert fmt is not None
        assert hasattr(fmt, "write")
        assert hasattr(fmt, "read")

    def test_get_yaml_format(self):
        """Test getting YAML format."""
        fmt = get_format("yaml")
        assert fmt is not None

    def test_get_toml_format(self):
        """Test getting TOML format."""
        fmt = get_format("toml")
        assert fmt is not None

    def test_get_csv_format(self):
        """Test getting CSV format."""
        fmt = get_format("csv")
        assert fmt is not None

    def test_get_text_format(self):
        """Test getting text format."""
        fmt = get_format("text")
        assert fmt is not None

    def test_get_python_format(self):
        """Test getting Python format."""
        fmt = get_format("python")
        assert fmt is not None

    def test_get_markdown_format(self):
        """Test getting Markdown format."""
        fmt = get_format("markdown")
        assert fmt is not None

    def test_get_env_format(self):
        """Test getting env format."""
        fmt = get_format("env")
        assert fmt is not None

    def test_get_hocon_format(self):
        """Test getting HOCON format."""
        fmt = get_format("hocon")
        assert fmt is not None

    def test_get_format_case_insensitive(self):
        """Test format name is case-insensitive."""
        fmt1 = get_format("JSON")
        fmt2 = get_format("json")
        assert isinstance(fmt1, type(fmt2))

    def test_get_format_with_kwargs(self):
        """Test getting format with constructor kwargs."""
        fmt = get_format("json", indent=4, sort_keys=True)
        assert fmt.indent == 4
        assert fmt.sort_keys is True

    def test_get_unsupported_format(self):
        """Test getting unsupported format raises error."""
        with pytest.raises(FormatError) as exc_info:
            get_format("unsupported")
        assert "Unsupported format" in str(exc_info.value)
        assert "unsupported" in str(exc_info.value)


class TestDetectFormatFromPath:
    """Tests for detect_format_from_path function."""

    def test_detect_json(self):
        """Test detecting JSON format."""
        assert detect_format_from_path("data.json") == "json"

    def test_detect_yaml(self):
        """Test detecting YAML format."""
        assert detect_format_from_path("config.yaml") == "yaml"

    def test_detect_yml(self):
        """Test detecting YML format."""
        assert detect_format_from_path("config.yml") == "yaml"

    def test_detect_toml(self):
        """Test detecting TOML format."""
        assert detect_format_from_path("pyproject.toml") == "toml"

    def test_detect_csv(self):
        """Test detecting CSV format."""
        assert detect_format_from_path("data.csv") == "csv"

    def test_detect_txt(self):
        """Test detecting text format."""
        assert detect_format_from_path("readme.txt") == "text"

    def test_detect_md(self):
        """Test detecting Markdown format."""
        assert detect_format_from_path("README.md") == "markdown"

    def test_detect_py(self):
        """Test detecting Python format."""
        assert detect_format_from_path("script.py") == "python"

    def test_detect_env(self):
        """Test detecting env format."""
        assert detect_format_from_path(".env") == "env"

    def test_detect_env_local(self):
        """Test detecting env format with suffix."""
        assert detect_format_from_path(".env.local") == "env"

    def test_detect_env_production(self):
        """Test detecting env format with production suffix."""
        assert detect_format_from_path(".env.production") == "env"

    def test_detect_hocon(self):
        """Test detecting HOCON format."""
        assert detect_format_from_path("app.conf") == "hocon"

    def test_detect_case_insensitive(self):
        """Test extension detection is case-insensitive."""
        assert detect_format_from_path("DATA.JSON") == "json"
        assert detect_format_from_path("Config.YAML") == "yaml"

    def test_detect_no_extension_error(self):
        """Test detecting format without extension raises error."""
        with pytest.raises(FormatError) as exc_info:
            detect_format_from_path("noextension")
        assert "without extension" in str(exc_info.value)

    def test_detect_unknown_extension_error(self):
        """Test detecting unknown extension raises error."""
        with pytest.raises(FormatError) as exc_info:
            detect_format_from_path("file.unknown")
        assert "Cannot detect format" in str(exc_info.value)
        assert ".unknown" in str(exc_info.value)


class TestRegisterFormat:
    """Tests for register_format function."""

    def test_register_custom_format(self):
        """Test registering a custom format."""
        register_format("dummy", DummyFormat)
        assert "dummy" in list_formats()

        # Clean up
        unregister_format("dummy")

    def test_register_format_with_extension_mapping(self):
        """Test format extension mapping after registration."""
        register_format("dummy", DummyFormat)
        assert ".dummy" in list_extensions()

        # Clean up
        unregister_format("dummy")

    def test_register_duplicate_format_error(self):
        """Test registering duplicate format raises error."""
        register_format("dummy", DummyFormat)

        with pytest.raises(ConfigurationError) as exc_info:
            register_format("dummy", DummyFormat)
        assert "already registered" in str(exc_info.value)

        # Clean up
        unregister_format("dummy")

    def test_register_format_without_write(self):
        """Test registering format without write method raises error."""
        with pytest.raises(ConfigurationError) as exc_info:
            register_format("nowrit", NoWriteFormat)
        assert "write" in str(exc_info.value).lower()

    def test_register_format_without_read(self):
        """Test registering format without read method raises error."""
        with pytest.raises(ConfigurationError) as exc_info:
            register_format("noread", NoReadFormat)
        assert "read" in str(exc_info.value).lower()

    def test_register_format_without_can_write(self):
        """Test registering format without can_write method raises error."""
        with pytest.raises(ConfigurationError) as exc_info:
            register_format("nocan", NoCanWriteFormat)
        assert "can_write" in str(exc_info.value).lower()

    def test_register_format_without_extensions(self):
        """Test registering format without extensions property raises error."""
        with pytest.raises(ConfigurationError) as exc_info:
            register_format("noext", NoExtensionsFormat)
        assert "extensions" in str(exc_info.value).lower()

    def test_register_non_instantiable_format(self):
        """Test registering incomplete format raises error."""
        with pytest.raises(ConfigurationError) as exc_info:
            register_format("incomplete", IncompleteFormat)
        # Should fail on missing 'write' method
        assert "write" in str(exc_info.value).lower()

    def test_use_registered_format(self):
        """Test using a registered custom format."""
        register_format("dummy", DummyFormat)
        fmt = get_format("dummy")
        assert fmt is not None
        assert fmt.write({}, "test") == b"dummy"

        # Clean up
        unregister_format("dummy")


class TestUnregisterFormat:
    """Tests for unregister_format function."""

    def test_unregister_custom_format(self):
        """Test unregistering a custom format."""
        register_format("dummy", DummyFormat)
        assert "dummy" in list_formats()

        unregister_format("dummy")
        assert "dummy" not in list_formats()

    def test_unregister_removes_extensions(self):
        """Test unregistering format removes extension mappings."""
        register_format("dummy", DummyFormat)
        assert ".dummy" in list_extensions()

        unregister_format("dummy")
        assert ".dummy" not in list_extensions()

    def test_unregister_nonexistent_format_error(self):
        """Test unregistering non-existent format raises error."""
        with pytest.raises(ConfigurationError) as exc_info:
            unregister_format("nonexistent")
        assert "not registered" in str(exc_info.value)

    def test_unregister_builtin_format(self):
        """Test unregistering built-in format is allowed."""
        # This is allowed for advanced use cases
        unregister_format("json")
        assert "json" not in list_formats()

        # Need to re-initialize for other tests
        # This is a bit hacky but necessary for test isolation
        _FORMATS.clear()
        _EXTENSION_MAP.clear()
        # Force re-initialization on next get_format call
        get_format("json")  # This will trigger _initialize_registry()


class TestListFormats:
    """Tests for list_formats function."""

    def test_list_formats_returns_sorted_list(self):
        """Test list_formats returns sorted list."""
        formats = list_formats()
        assert isinstance(formats, list)
        assert len(formats) > 0
        assert formats == sorted(formats)

    def test_list_formats_includes_builtins(self):
        """Test list includes built-in formats."""
        formats = list_formats()
        assert "json" in formats
        assert "yaml" in formats
        assert "csv" in formats
        assert "text" in formats


class TestListExtensions:
    """Tests for list_extensions function."""

    def test_list_extensions_returns_sorted_list(self):
        """Test list_extensions returns sorted list."""
        extensions = list_extensions()
        assert isinstance(extensions, list)
        assert len(extensions) > 0
        assert extensions == sorted(extensions)

    def test_list_extensions_includes_common_types(self):
        """Test list includes common extensions."""
        extensions = list_extensions()
        assert ".json" in extensions
        assert ".yaml" in extensions
        assert ".csv" in extensions
        assert ".txt" in extensions
