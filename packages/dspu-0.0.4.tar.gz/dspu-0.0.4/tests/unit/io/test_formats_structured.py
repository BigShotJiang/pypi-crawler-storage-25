"""Tests for structured format handlers (JSON, YAML, TOML, HOCON)."""

from pathlib import Path

import pytest

from dspu.io.formats import (
    FormatError,
    HOCONFormat,
    JSONFormat,
    TOMLFormat,
    YAMLFormat,
)


class TestJSONFormat:
    """Tests for JSON format handler."""

    def test_write_dict(self, tmp_path: Path):
        """Test writing dictionary to JSON."""
        fmt = JSONFormat()
        data = {"name": "Alice", "age": 30, "active": True}

        result = fmt.write(data, tmp_path / "test.json")

        assert isinstance(result, bytes)
        assert b"Alice" in result
        assert b"30" in result

    def test_write_list(self, tmp_path: Path):
        """Test writing list to JSON."""
        fmt = JSONFormat()
        data = [1, 2, 3, 4, 5]

        result = fmt.write(data, tmp_path / "test.json")

        assert isinstance(result, bytes)
        assert b"[" in result

    def test_write_with_indent(self, tmp_path: Path):
        """Test JSON with pretty printing."""
        fmt = JSONFormat(indent=2)
        data = {"nested": {"key": "value"}}

        result = fmt.write(data, tmp_path / "test.json")

        # Should have newlines from indentation
        assert b"\n" in result

    def test_write_compact(self, tmp_path: Path):
        """Test JSON without indentation."""
        fmt = JSONFormat(indent=None)
        data = {"key": "value"}

        result = fmt.write(data, tmp_path / "test.json")

        # Should not have newlines
        assert b"\n" not in result

    def test_write_sorted_keys(self, tmp_path: Path):
        """Test JSON with sorted keys."""
        fmt = JSONFormat(sort_keys=True)
        data = {"zebra": 1, "apple": 2, "banana": 3}

        result = fmt.write(data, tmp_path / "test.json")

        # apple should come before zebra
        apple_pos = result.find(b"apple")
        zebra_pos = result.find(b"zebra")
        assert apple_pos < zebra_pos

    def test_write_unicode(self, tmp_path: Path):
        """Test JSON with unicode characters."""
        fmt = JSONFormat(ensure_ascii=False)
        data = {"message": "Hello 世界 🌍"}

        result = fmt.write(data, tmp_path / "test.json")

        assert "世界".encode() in result

    def test_read_dict(self):
        """Test reading JSON dict."""
        fmt = JSONFormat()
        data = b'{"name": "Alice", "age": 30}'

        result = fmt.read(data)

        assert result == {"name": "Alice", "age": 30}

    def test_read_list(self):
        """Test reading JSON list."""
        fmt = JSONFormat()
        data = b"[1, 2, 3, 4, 5]"

        result = fmt.read(data)

        assert result == [1, 2, 3, 4, 5]

    def test_read_invalid_json(self):
        """Test reading invalid JSON raises error."""
        fmt = JSONFormat()
        data = b"{invalid json}"

        with pytest.raises(FormatError) as exc_info:
            fmt.read(data)

        assert "json" in str(exc_info.value).lower()

    def test_can_write_dict(self):
        """Test can_write returns True for dict."""
        fmt = JSONFormat()
        assert fmt.can_write({"key": "value"}) is True

    def test_can_write_list(self):
        """Test can_write returns True for list."""
        fmt = JSONFormat()
        assert fmt.can_write([1, 2, 3]) is True

    def test_can_write_invalid(self):
        """Test can_write returns False for unsupported types."""
        fmt = JSONFormat()
        assert fmt.can_write(lambda x: x) is False

    def test_extensions(self):
        """Test extensions property."""
        fmt = JSONFormat()
        assert ".json" in fmt.extensions


class TestYAMLFormat:
    """Tests for YAML format handler."""

    def test_write_dict(self, tmp_path: Path):
        """Test writing dictionary to YAML."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        data = {"name": "Alice", "age": 30}

        result = fmt.write(data, tmp_path / "test.yaml")

        assert isinstance(result, bytes)
        assert b"name:" in result or b"name :" in result

    def test_write_nested_dict(self, tmp_path: Path):
        """Test writing nested dictionary."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        data = {
            "database": {
                "host": "localhost",
                "port": 5432,
            },
            "debug": True,
        }

        result = fmt.write(data, tmp_path / "test.yaml")

        assert b"database:" in result or b"database :" in result
        assert b"host:" in result or b"host :" in result

    def test_write_list(self, tmp_path: Path):
        """Test writing list to YAML."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        data = [1, 2, 3, 4, 5]

        result = fmt.write(data, tmp_path / "test.yaml")

        assert isinstance(result, bytes)

    def test_write_string_not_allowed(self, tmp_path: Path):
        """Test writing string raises error."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()

        with pytest.raises(FormatError):
            fmt.write("plain string", tmp_path / "test.yaml")

    def test_read_dict(self):
        """Test reading YAML dict."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        data = b"name: Alice\nage: 30\n"

        result = fmt.read(data)

        assert result == {"name": "Alice", "age": 30}

    def test_read_list(self):
        """Test reading YAML list."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        data = b"- 1\n- 2\n- 3\n"

        result = fmt.read(data)

        assert result == [1, 2, 3]

    def test_can_write_dict(self):
        """Test can_write returns True for dict."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        assert fmt.can_write({"key": "value"}) is True

    def test_can_write_list(self):
        """Test can_write returns True for list."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        assert fmt.can_write([1, 2, 3]) is True

    def test_can_write_string(self):
        """Test can_write returns False for string."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        assert fmt.can_write("string") is False

    def test_extensions(self):
        """Test extensions property."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        assert ".yaml" in fmt.extensions
        assert ".yml" in fmt.extensions


class TestTOMLFormat:
    """Tests for TOML format handler."""

    def test_write_dict(self, tmp_path: Path):
        """Test writing dictionary to TOML."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        data = {"name": "Alice", "age": 30}

        result = fmt.write(data, tmp_path / "test.toml")

        assert isinstance(result, bytes)
        assert b"name" in result

    def test_write_nested_dict(self, tmp_path: Path):
        """Test writing nested dictionary."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        data = {
            "database": {
                "host": "localhost",
                "port": 5432,
            },
        }

        result = fmt.write(data, tmp_path / "test.toml")

        assert b"database" in result

    def test_write_list_at_root_fails(self, tmp_path: Path):
        """Test writing list at root raises error (TOML requires dict)."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        data = [1, 2, 3]

        with pytest.raises(FormatError):
            fmt.write(data, tmp_path / "test.toml")

    def test_read_dict(self):
        """Test reading TOML dict."""
        pytest.importorskip("tomllib", "tomli")

        fmt = TOMLFormat()
        data = b'name = "Alice"\nage = 30\n'

        result = fmt.read(data)

        assert result == {"name": "Alice", "age": 30}

    def test_can_write_dict(self):
        """Test can_write returns True for dict."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        assert fmt.can_write({"key": "value"}) is True

    def test_can_write_list(self):
        """Test can_write returns False for list."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        assert fmt.can_write([1, 2, 3]) is False

    def test_extensions(self):
        """Test extensions property."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        assert ".toml" in fmt.extensions


class TestHOCONFormat:
    """Tests for HOCON format handler."""

    def test_write_dict(self, tmp_path: Path):
        """Test writing dictionary to HOCON."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        data = {"name": "Alice", "age": 30}

        result = fmt.write(data, tmp_path / "test.conf")

        assert isinstance(result, bytes)

    def test_write_nested_dict(self, tmp_path: Path):
        """Test writing nested dictionary."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        data = {
            "database": {
                "host": "localhost",
                "port": 5432,
            },
        }

        result = fmt.write(data, tmp_path / "test.conf")

        assert isinstance(result, bytes)

    def test_write_list_at_root_fails(self, tmp_path: Path):
        """Test writing list at root raises error."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        data = [1, 2, 3]

        with pytest.raises(FormatError):
            fmt.write(data, tmp_path / "test.conf")

    def test_read_dict(self):
        """Test reading HOCON dict."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        data = b"name = Alice\nage = 30\n"

        result = fmt.read(data)

        assert result == {"name": "Alice", "age": 30}

    def test_can_write_dict(self):
        """Test can_write returns True for dict."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        assert fmt.can_write({"key": "value"}) is True

    def test_can_write_list(self):
        """Test can_write returns False for list."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        assert fmt.can_write([1, 2, 3]) is False

    def test_extensions(self):
        """Test extensions property."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        assert ".conf" in fmt.extensions
        assert ".hocon" in fmt.extensions


class TestErrorHandling:
    """Tests for error handling across formats."""

    def test_json_write_invalid_object(self):
        """Test JSON write with unserializable object."""
        fmt = JSONFormat()

        class CustomClass:
            pass

        obj = {"data": CustomClass()}
        with pytest.raises(FormatError, match="Cannot serialize to JSON"):
            fmt.write(obj, "test.json")

    def test_yaml_write_string_raises(self):
        """Test YAML write with string (not dict/list)."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        with pytest.raises(FormatError, match="Structured formats require dict or list"):
            fmt.write("just a string", "test.yaml")

    def test_yaml_read_invalid(self):
        """Test YAML read with invalid syntax."""
        pytest.importorskip("yaml")

        fmt = YAMLFormat()
        data = b"invalid: yaml: syntax:"
        with pytest.raises(FormatError):
            fmt.read(data)

    def test_toml_write_list_raises(self):
        """Test TOML write with list at root (not allowed)."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()
        with pytest.raises(FormatError, match="requires a dict"):
            fmt.write([1, 2, 3], "test.toml")

    def test_toml_write_invalid_object(self):
        """Test TOML write with unserializable object."""
        pytest.importorskip("tomli_w")

        fmt = TOMLFormat()

        class CustomClass:
            pass

        obj = {"data": CustomClass()}
        with pytest.raises(FormatError, match="Cannot serialize to TOML"):
            fmt.write(obj, "test.toml")

    def test_toml_read_invalid(self):
        """Test TOML read with invalid syntax."""
        pytest.importorskip("tomllib", "tomli")

        fmt = TOMLFormat()
        data = b"[invalid toml syntax"
        with pytest.raises(FormatError):
            fmt.read(data)

    def test_hocon_write_list_raises(self):
        """Test HOCON write with list at root (not allowed)."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        with pytest.raises(FormatError, match="requires a dict"):
            fmt.write([1, 2, 3], "test.conf")

    def test_hocon_read_invalid(self):
        """Test HOCON read with invalid syntax."""
        pytest.importorskip("pyhocon")

        fmt = HOCONFormat()
        data = b"{unclosed: ["
        with pytest.raises(FormatError):
            fmt.read(data)
