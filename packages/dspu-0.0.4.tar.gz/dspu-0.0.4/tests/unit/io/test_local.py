"""Tests for LocalBackend."""

from pathlib import Path

import pytest

from dspu.core.exceptions import DSPUIOError
from dspu.io.local import LocalBackend


class TestLocalBackendInitialization:
    """Test LocalBackend initialization."""

    def test_init_creates_root_directory(self, tmp_path: Path):
        """Test that initialization creates root directory."""
        root = tmp_path / "storage"
        assert not root.exists()

        backend = LocalBackend(root)

        assert root.exists()
        assert root.is_dir()
        assert backend.root == root

    def test_init_with_existing_directory(self, tmp_path: Path):
        """Test initialization with existing directory."""
        root = tmp_path / "storage"
        root.mkdir()

        backend = LocalBackend(root)

        assert backend.root == root

    def test_init_expands_tilde(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        """Test that tilde is expanded in path."""
        monkeypatch.setenv("HOME", str(tmp_path))

        backend = LocalBackend("~/storage")

        assert "~" not in str(backend.root)
        assert backend.root.is_absolute()


class TestLocalBackendReadWrite:
    """Test read and write operations."""

    @pytest.mark.asyncio
    async def test_write_and_read_file(self, tmp_path: Path):
        """Test basic write and read."""
        backend = LocalBackend(tmp_path)
        data = b"Hello, World!"

        await backend.write("test.txt", data)
        result = await backend.read("test.txt")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_creates_parent_directories(self, tmp_path: Path):
        """Test that write creates parent directories."""
        backend = LocalBackend(tmp_path)
        data = b"test data"

        await backend.write("nested/deep/file.txt", data)

        assert (tmp_path / "nested" / "deep" / "file.txt").exists()
        result = await backend.read("nested/deep/file.txt")
        assert result == data

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self, tmp_path: Path):
        """Test reading file that doesn't exist."""
        backend = LocalBackend(tmp_path)

        with pytest.raises(FileNotFoundError):
            await backend.read("nonexistent.txt")

    @pytest.mark.asyncio
    async def test_write_empty_file(self, tmp_path: Path):
        """Test writing empty file."""
        backend = LocalBackend(tmp_path)

        await backend.write("empty.txt", b"")
        result = await backend.read("empty.txt")

        assert result == b""

    @pytest.mark.asyncio
    async def test_write_large_file(self, tmp_path: Path):
        """Test writing large file."""
        backend = LocalBackend(tmp_path)
        data = b"x" * (10 * 1024 * 1024)  # 10MB

        await backend.write("large.bin", data)
        result = await backend.read("large.bin")

        assert result == data


class TestLocalBackendSecurity:
    """Test security features."""

    @pytest.mark.asyncio
    async def test_path_traversal_blocked(self, tmp_path: Path):
        """Test that path traversal attacks are blocked."""
        backend = LocalBackend(tmp_path)

        with pytest.raises(DSPUIOError) as exc_info:
            await backend.write("../../../etc/passwd", b"bad")

        assert "escapes root" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_absolute_path_blocked(self, tmp_path: Path):
        """Test that absolute paths outside root are blocked."""
        backend = LocalBackend(tmp_path)

        with pytest.raises(DSPUIOError) as exc_info:
            await backend.read("/etc/passwd")

        assert "escapes root" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_symlink_escape_blocked(self, tmp_path: Path):
        """Test that symlinks escaping root are blocked."""
        backend = LocalBackend(tmp_path)
        outside = tmp_path.parent / "outside.txt"
        outside.write_text("secret")

        # Create symlink pointing outside root
        link = tmp_path / "link.txt"
        link.symlink_to(outside)

        # Reading through symlink should be blocked
        with pytest.raises(DSPUIOError):
            await backend.read("link.txt")


class TestLocalBackendExists:
    """Test exists operation."""

    @pytest.mark.asyncio
    async def test_exists_for_existing_file(self, tmp_path: Path):
        """Test exists returns True for existing file."""
        backend = LocalBackend(tmp_path)
        await backend.write("test.txt", b"data")

        result = await backend.exists("test.txt")

        assert result is True

    @pytest.mark.asyncio
    async def test_exists_for_nonexistent_file(self, tmp_path: Path):
        """Test exists returns False for nonexistent file."""
        backend = LocalBackend(tmp_path)

        result = await backend.exists("nonexistent.txt")

        assert result is False

    @pytest.mark.asyncio
    async def test_exists_for_directory(self, tmp_path: Path):
        """Test exists returns True for directory."""
        backend = LocalBackend(tmp_path)
        (tmp_path / "subdir").mkdir()

        result = await backend.exists("subdir")

        assert result is True

    @pytest.mark.asyncio
    async def test_exists_handles_path_traversal(self, tmp_path: Path):
        """Test exists returns False for path traversal."""
        backend = LocalBackend(tmp_path)

        result = await backend.exists("../outside")

        assert result is False


class TestLocalBackendDelete:
    """Test delete operation."""

    @pytest.mark.asyncio
    async def test_delete_file(self, tmp_path: Path):
        """Test deleting a file."""
        backend = LocalBackend(tmp_path)
        await backend.write("test.txt", b"data")

        await backend.delete("test.txt")

        assert not (tmp_path / "test.txt").exists()

    @pytest.mark.asyncio
    async def test_delete_nonexistent_file(self, tmp_path: Path):
        """Test deleting nonexistent file raises error."""
        backend = LocalBackend(tmp_path)

        with pytest.raises(FileNotFoundError):
            await backend.delete("nonexistent.txt")

    @pytest.mark.asyncio
    async def test_delete_directory(self, tmp_path: Path):
        """Test deleting a directory."""
        backend = LocalBackend(tmp_path)
        (tmp_path / "subdir" / "nested").mkdir(parents=True)
        (tmp_path / "subdir" / "file.txt").write_text("data")

        await backend.delete("subdir")

        assert not (tmp_path / "subdir").exists()

    @pytest.mark.asyncio
    async def test_delete_empty_directory(self, tmp_path: Path):
        """Test deleting empty directory."""
        backend = LocalBackend(tmp_path)
        (tmp_path / "empty").mkdir()

        await backend.delete("empty")

        assert not (tmp_path / "empty").exists()


class TestLocalBackendList:
    """Test list operation."""

    @pytest.mark.asyncio
    async def test_list_all_files(self, tmp_path: Path):
        """Test listing all files."""
        backend = LocalBackend(tmp_path)
        await backend.write("file1.txt", b"data1")
        await backend.write("file2.txt", b"data2")
        await backend.write("subdir/file3.txt", b"data3")

        files = [f async for f in backend.list("*")]

        assert len(files) >= 2  # At least file1 and file2
        paths = [f.path for f in files]
        assert "file1.txt" in paths
        assert "file2.txt" in paths

    @pytest.mark.asyncio
    async def test_list_with_pattern(self, tmp_path: Path):
        """Test listing files with glob pattern."""
        backend = LocalBackend(tmp_path)
        await backend.write("test.txt", b"data")
        await backend.write("test.json", b"data")
        await backend.write("other.xml", b"data")

        files = [f async for f in backend.list("*.txt")]

        assert len(files) == 1
        assert files[0].path == "test.txt"

    @pytest.mark.asyncio
    async def test_list_includes_file_info(self, tmp_path: Path):
        """Test that list returns complete FileInfo."""
        backend = LocalBackend(tmp_path)
        data = b"test data"
        await backend.write("test.txt", data)

        files = [f async for f in backend.list("test.txt")]

        assert len(files) == 1
        info = files[0]
        assert info.path == "test.txt"
        assert info.size == len(data)
        assert info.modified is not None
        assert info.is_dir is False

    @pytest.mark.asyncio
    async def test_list_empty_directory(self, tmp_path: Path):
        """Test listing empty directory."""
        backend = LocalBackend(tmp_path)

        files = [f async for f in backend.list("*.txt")]

        assert len(files) == 0


class TestLocalBackendStreaming:
    """Test streaming operations."""

    @pytest.mark.asyncio
    async def test_read_stream(self, tmp_path: Path):
        """Test reading file as stream."""
        backend = LocalBackend(tmp_path)
        data = b"chunk1chunk2chunk3"
        await backend.write("test.txt", data)

        chunks = [chunk async for chunk in backend.read_stream("test.txt", chunk_size=6)]

        assert b"".join(chunks) == data
        assert len(chunks) > 1  # Multiple chunks

    @pytest.mark.asyncio
    async def test_read_stream_large_file(self, tmp_path: Path):
        """Test streaming large file."""
        backend = LocalBackend(tmp_path)
        data = b"x" * (1024 * 1024)  # 1MB
        await backend.write("large.bin", data)

        chunks = [chunk async for chunk in backend.read_stream("large.bin", chunk_size=8192)]

        assert b"".join(chunks) == data
        assert len(chunks) > 100  # Many chunks

    @pytest.mark.asyncio
    async def test_read_stream_nonexistent_file(self, tmp_path: Path):
        """Test streaming nonexistent file."""
        backend = LocalBackend(tmp_path)

        with pytest.raises(FileNotFoundError):
            async for _ in backend.read_stream("nonexistent.txt"):
                pass

    @pytest.mark.asyncio
    async def test_write_stream(self, tmp_path: Path):
        """Test writing file from stream."""
        backend = LocalBackend(tmp_path)

        async def data_generator():
            for i in range(10):
                yield f"chunk{i}\n".encode()

        await backend.write_stream("output.txt", data_generator())

        result = await backend.read("output.txt")
        assert b"chunk0\n" in result
        assert b"chunk9\n" in result

    @pytest.mark.asyncio
    async def test_write_stream_creates_directories(self, tmp_path: Path):
        """Test that write_stream creates parent directories."""
        backend = LocalBackend(tmp_path)

        async def data_generator():
            yield b"test data"

        await backend.write_stream("nested/deep/file.txt", data_generator())

        assert (tmp_path / "nested" / "deep" / "file.txt").exists()
