"""Tests for validation decorators and Pydantic integration."""

from typing import ClassVar

import pytest
from pydantic import ValidationError as PydanticValidationError

from dspu.core.exceptions import ValidationError
from dspu.validation.filters import (
    EmailNormalizationFilter,
    FilterChain,
    LowercaseFilter,
    StripWhitespaceFilter,
    TruncateFilter,
)
from dspu.validation.validators import validate, validate_field

# Import Pydantic components if available
try:
    from pydantic import BaseModel, field_validator

    from dspu.validation.validators import (
        FilteredModel,
        create_pydantic_model_with_filters,
        pydantic_filter_validator,
    )

    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False


class TestValidateField:
    """Tests for validate_field decorator."""

    def test_basic_field_validation(self):
        """Test basic field validation."""

        @validate_field(StripWhitespaceFilter(), LowercaseFilter())
        def process_email(email: str) -> str:
            return email

        assert process_email("  USER@EXAMPLE.COM  ") == "user@example.com"

    def test_validates_first_parameter_by_default(self):
        """Test that first parameter is validated by default."""

        @validate_field(StripWhitespaceFilter())
        def process(value: str, other: str) -> str:
            return f"{value}:{other}"

        assert process("  hello  ", "world") == "hello:world"

    def test_validates_specific_field(self):
        """Test validating specific field by name."""

        @validate_field(LowercaseFilter(), field_name="email")
        def create_user(name: str, email: str) -> str:
            return f"{name} <{email}>"

        assert create_user("John", "USER@EXAMPLE.COM") == "John <user@example.com>"

    def test_invalid_field_name_raises_error(self):
        """Test that invalid field name raises error."""
        with pytest.raises(ValueError, match="Parameter 'invalid' not found"):

            @validate_field(StripWhitespaceFilter(), field_name="invalid")
            def process(value: str) -> str:
                return value

    def test_function_without_params_raises_error(self):
        """Test that function without params raises error."""
        with pytest.raises(ValueError, match="has no parameters to validate"):

            @validate_field(StripWhitespaceFilter())
            def process() -> str:
                return "value"

    def test_no_filters_raises_error(self):
        """Test that no filters raises error."""
        with pytest.raises(ValueError, match="At least one filter must be provided"):

            @validate_field()  # type: ignore[misc]
            def process(value: str) -> str:
                return value

    def test_validation_error_on_filter_failure(self):
        """Test that filter failures raise ValidationError."""

        @validate_field(EmailNormalizationFilter())
        def process_email(email: str) -> str:
            return email

        with pytest.raises(ValidationError, match="Validation failed"):
            process_email("not-an-email")

    def test_preserves_function_metadata(self):
        """Test that decorator preserves function metadata."""

        @validate_field(StripWhitespaceFilter())
        def process_email(email: str) -> str:
            """Process an email address."""
            return email

        assert process_email.__name__ == "process_email"
        assert "Process an email" in process_email.__doc__

    def test_with_kwargs(self):
        """Test validation with keyword arguments."""

        @validate_field(StripWhitespaceFilter(), field_name="email")
        def process(name: str, email: str) -> str:
            return f"{name}:{email}"

        assert process(name="John", email="  user@example.com  ") == "John:user@example.com"

    def test_with_defaults(self):
        """Test validation with default parameters."""

        @validate_field(StripWhitespaceFilter())
        def process(value: str = "  default  ") -> str:
            return value

        assert process() == "default"
        assert process("  custom  ") == "custom"


class TestValidate:
    """Tests for validate decorator."""

    def test_input_validation(self):
        """Test input parameter validation."""

        @validate(
            input_filters={
                "email": EmailNormalizationFilter(),
                "name": StripWhitespaceFilter(),
            }
        )
        def create_user(email: str, name: str) -> dict:
            return {"email": email, "name": name}

        result = create_user("John.Doe@GMAIL.COM", "  John  ")
        assert result["email"] == "johndoe@gmail.com"
        assert result["name"] == "John"

    def test_output_validation(self):
        """Test output validation."""

        @validate(output_filter=StripWhitespaceFilter())
        def get_username() -> str:
            return "  username  "

        assert get_username() == "username"

    def test_both_input_and_output_validation(self):
        """Test both input and output validation."""

        @validate(
            input_filters={"email": LowercaseFilter()},
            output_filter=StripWhitespaceFilter(),
        )
        def format_email(email: str) -> str:
            return f"  {email}  "

        assert format_email("USER@EXAMPLE.COM") == "user@example.com"

    def test_filter_chain_in_input(self):
        """Test using FilterChain for input validation."""

        @validate(
            input_filters={
                "name": FilterChain([StripWhitespaceFilter(), TruncateFilter(max_length=10)])
            }
        )
        def process(name: str) -> str:
            return name

        assert process("  Hello World  ") == "Hello Worl"

    def test_invalid_parameter_name_raises_error(self):
        """Test that invalid parameter name raises error."""
        with pytest.raises(ValueError, match="Parameter 'invalid' not found"):

            @validate(input_filters={"invalid": StripWhitespaceFilter()})
            def process(value: str) -> str:
                return value

    def test_validation_error_on_input_failure(self):
        """Test that input validation failures raise ValidationError."""

        @validate(input_filters={"email": EmailNormalizationFilter()})
        def process(email: str) -> str:
            return email

        with pytest.raises(ValidationError, match="Validation failed for parameter 'email'"):
            process("not-an-email")

    def test_validation_error_on_output_failure(self):
        """Test that output validation failures raise ValidationError."""

        @validate(output_filter=EmailNormalizationFilter())
        def get_email() -> str:
            return "not-an-email"

        with pytest.raises(ValidationError, match="Output validation failed"):
            get_email()

    def test_preserves_function_metadata(self):
        """Test that decorator preserves function metadata."""

        @validate(input_filters={"email": LowercaseFilter()})
        def process_email(email: str) -> str:
            """Process an email address."""
            return email

        assert process_email.__name__ == "process_email"
        assert "Process an email" in process_email.__doc__

    def test_with_no_filters(self):
        """Test decorator with no filters."""

        @validate()
        def process(value: str) -> str:
            return value

        assert process("test") == "test"

    def test_multiple_input_filters(self):
        """Test multiple input filters."""

        @validate(
            input_filters={
                "email": EmailNormalizationFilter(),
                "name": FilterChain([StripWhitespaceFilter(), TruncateFilter(max_length=20)]),
                "username": LowercaseFilter(),
            }
        )
        def create_user(email: str, name: str, username: str) -> dict:
            return {"email": email, "name": name, "username": username}

        result = create_user(
            "John.Doe+test@GMAIL.COM",
            "  John Doe With A Very Long Name  ",
            "JohnDoe",
        )

        assert result["email"] == "johndoe@gmail.com"
        assert result["name"] == "John Doe With A Very"
        assert result["username"] == "johndoe"


@pytest.mark.skipif(not PYDANTIC_AVAILABLE, reason="Pydantic not installed")
class TestPydanticIntegration:
    """Tests for Pydantic integration."""

    def test_pydantic_filter_validator(self):
        """Test creating Pydantic validator from filter."""

        class User(BaseModel):
            email: str

            _validate_email = field_validator("email", mode="before")(
                pydantic_filter_validator(EmailNormalizationFilter())
            )

        user = User(email="John.Doe@GMAIL.COM")
        assert user.email == "johndoe@gmail.com"

    def test_pydantic_filter_validator_with_chain(self):
        """Test Pydantic validator with FilterChain."""

        class User(BaseModel):
            name: str

            _validate_name = field_validator("name", mode="before")(
                pydantic_filter_validator(
                    FilterChain([StripWhitespaceFilter(), TruncateFilter(max_length=20)])
                )
            )

        user = User(name="  John Doe With A Very Long Name  ")
        assert user.name == "John Doe With A Very"

    def test_pydantic_validator_error_handling(self):
        """Test that Pydantic validator handles errors."""

        class User(BaseModel):
            email: str

            _validate_email = field_validator("email", mode="before")(
                pydantic_filter_validator(EmailNormalizationFilter())
            )

        with pytest.raises(PydanticValidationError):
            User(email="not-an-email")

    def test_filtered_model(self):
        """Test FilteredModel base class."""

        class User(FilteredModel):
            email: str
            name: str

            _filters: ClassVar[dict] = {
                "email": EmailNormalizationFilter(),
                "name": FilterChain([StripWhitespaceFilter(), TruncateFilter(max_length=20)]),
            }

        user = User(email="John.Doe@GMAIL.COM", name="  John Doe  ")
        assert user.email == "johndoe@gmail.com"
        assert user.name == "John Doe"

    def test_filtered_model_partial_filters(self):
        """Test FilteredModel with filters on some fields."""

        class User(FilteredModel):
            email: str
            age: int

            _filters: ClassVar[dict] = {
                "email": LowercaseFilter(),
            }

        user = User(email="USER@EXAMPLE.COM", age=25)
        assert user.email == "user@example.com"
        assert user.age == 25

    def test_filtered_model_no_filters(self):
        """Test FilteredModel without _filters attribute."""

        class User(FilteredModel):
            email: str

        user = User(email="test@example.com")
        assert user.email == "test@example.com"

    def test_create_pydantic_model_with_filters(self):
        """Test dynamically creating Pydantic model with filters."""
        user_model = create_pydantic_model_with_filters(
            "User",
            fields={"email": str, "name": str},
            filters={
                "email": EmailNormalizationFilter(),
                "name": StripWhitespaceFilter(),
            },
        )

        user = user_model(email="John.Doe@GMAIL.COM", name="  John  ")
        assert user.email == "johndoe@gmail.com"
        assert user.name == "John"

    def test_create_pydantic_model_partial_filters(self):
        """Test creating model with filters on subset of fields."""
        user_model = create_pydantic_model_with_filters(
            "User",
            fields={"email": str, "age": int},
            filters={"email": LowercaseFilter()},
        )

        user = user_model(email="USER@EXAMPLE.COM", age=25)
        assert user.email == "user@example.com"
        assert user.age == 25


@pytest.mark.skipif(PYDANTIC_AVAILABLE, reason="Testing without Pydantic")
class TestWithoutPydantic:
    """Tests for behavior when Pydantic is not installed."""

    def test_pydantic_filter_validator_raises_import_error(self):
        """Test that pydantic_filter_validator raises ImportError without Pydantic."""
        from dspu.validation.validators import pydantic_filter_validator

        with pytest.raises(ImportError, match="Pydantic is required"):
            pydantic_filter_validator(StripWhitespaceFilter())

    def test_filtered_model_raises_import_error(self):
        """Test that FilteredModel raises ImportError without Pydantic."""
        from dspu.validation.validators import FilteredModel

        # Try to instantiate (will fail in __init__)
        with pytest.raises(ImportError, match="Pydantic is required"):
            # This will work at definition time but fail at instantiation
            class User(FilteredModel):
                email: str

            User(email="test@example.com")

    def test_create_pydantic_model_raises_import_error(self):
        """Test that create_pydantic_model_with_filters raises ImportError."""
        from dspu.validation.validators import create_pydantic_model_with_filters

        with pytest.raises(ImportError, match="Pydantic is required"):
            create_pydantic_model_with_filters(
                "User",
                fields={"email": str},
                filters={"email": LowercaseFilter()},
            )


class TestValidationEdgeCases:
    """Tests for edge cases and error scenarios."""

    def test_validate_field_with_none_value(self):
        """Test validate_field with None value (converts to string)."""

        @validate_field(LowercaseFilter())
        def process(value) -> str:
            return value

        assert process(None) == "none"

    def test_validate_with_none_filter(self):
        """Test that None output_filter is handled."""

        @validate(output_filter=None)
        def process() -> str:
            return "test"

        assert process() == "test"

    def test_validate_with_empty_input_filters(self):
        """Test validate with empty input_filters dict."""

        @validate(input_filters={})
        def process(value: str) -> str:
            return value

        assert process("test") == "test"

    def test_complex_nested_validation(self):
        """Test complex nested validation scenario."""

        @validate(
            input_filters={
                "email": FilterChain(
                    [
                        StripWhitespaceFilter(),
                        LowercaseFilter(),
                        EmailNormalizationFilter(),
                    ]
                ),
                "name": FilterChain(
                    [
                        StripWhitespaceFilter(),
                        TruncateFilter(max_length=50),
                    ]
                ),
            },
            output_filter=StripWhitespaceFilter(),
        )
        def create_user(email: str, name: str) -> str:
            return f"  {name} ({email})  "

        result = create_user("  John.Doe+test@GMAIL.COM  ", "  John Doe  ")
        assert result == "John Doe (johndoe@gmail.com)"
