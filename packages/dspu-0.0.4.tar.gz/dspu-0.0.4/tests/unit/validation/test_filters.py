"""Tests for validation filters."""

import pytest

from dspu.validation.filters import (
    EmailNormalizationFilter,
    Filter,
    FilterChain,
    LowercaseFilter,
    RegexReplaceFilter,
    RemoveSpecialCharsFilter,
    SlugifyFilter,
    StripWhitespaceFilter,
    TruncateFilter,
    UppercaseFilter,
)


class TestFilterBase:
    """Tests for Filter base class."""

    def test_filter_is_callable(self):
        """Test that filters can be called directly."""

        class DoubleFilter(Filter):
            def apply(self, value):
                return value * 2

        f = DoubleFilter()
        assert f(5) == 10
        assert f("hi") == "hihi"

    def test_filter_then_creates_chain(self):
        """Test that then() creates a FilterChain."""
        f1 = StripWhitespaceFilter()
        f2 = LowercaseFilter()

        chain = f1.then(f2)
        assert isinstance(chain, FilterChain)
        assert len(chain.filters) == 2


class TestStripWhitespaceFilter:
    """Tests for StripWhitespaceFilter."""

    def test_strips_leading_whitespace(self):
        """Test stripping leading whitespace."""
        f = StripWhitespaceFilter()
        assert f("  hello") == "hello"

    def test_strips_trailing_whitespace(self):
        """Test stripping trailing whitespace."""
        f = StripWhitespaceFilter()
        assert f("hello  ") == "hello"

    def test_strips_both_sides(self):
        """Test stripping both sides."""
        f = StripWhitespaceFilter()
        assert f("  hello  ") == "hello"

    def test_strips_newlines_and_tabs(self):
        """Test stripping newlines and tabs."""
        f = StripWhitespaceFilter()
        assert f("\n\t hello \t\n") == "hello"

    def test_converts_non_strings(self):
        """Test converting non-string values."""
        f = StripWhitespaceFilter()
        assert f(123) == "123"
        assert f(True) == "True"


class TestLowercaseFilter:
    """Tests for LowercaseFilter."""

    def test_converts_to_lowercase(self):
        """Test basic lowercase conversion."""
        f = LowercaseFilter()
        assert f("HELLO") == "hello"
        assert f("Hello World") == "hello world"

    def test_handles_already_lowercase(self):
        """Test that already lowercase strings pass through."""
        f = LowercaseFilter()
        assert f("hello") == "hello"

    def test_handles_mixed_case(self):
        """Test mixed case strings."""
        f = LowercaseFilter()
        assert f("HeLLo WoRLd") == "hello world"

    def test_converts_non_strings(self):
        """Test converting non-string values."""
        f = LowercaseFilter()
        assert f(123) == "123"


class TestUppercaseFilter:
    """Tests for UppercaseFilter."""

    def test_converts_to_uppercase(self):
        """Test basic uppercase conversion."""
        f = UppercaseFilter()
        assert f("hello") == "HELLO"
        assert f("Hello World") == "HELLO WORLD"

    def test_handles_already_uppercase(self):
        """Test that already uppercase strings pass through."""
        f = UppercaseFilter()
        assert f("HELLO") == "HELLO"

    def test_handles_mixed_case(self):
        """Test mixed case strings."""
        f = UppercaseFilter()
        assert f("HeLLo WoRLd") == "HELLO WORLD"


class TestTruncateFilter:
    """Tests for TruncateFilter."""

    def test_truncates_long_strings(self):
        """Test truncating strings longer than max_length."""
        f = TruncateFilter(max_length=10)
        assert f("Hello World!") == "Hello Worl"

    def test_preserves_short_strings(self):
        """Test that short strings are not modified."""
        f = TruncateFilter(max_length=20)
        assert f("Hello") == "Hello"

    def test_truncates_at_exact_length(self):
        """Test string exactly at max_length."""
        f = TruncateFilter(max_length=5)
        assert f("Hello") == "Hello"
        assert f("Hello!") == "Hello"

    def test_truncate_with_suffix(self):
        """Test truncation with suffix."""
        f = TruncateFilter(max_length=10, suffix="...")
        assert f("Hello World!") == "Hello W..."

    def test_suffix_length_validation(self):
        """Test that suffix length is validated."""
        with pytest.raises(ValueError, match="suffix length must be less than max_length"):
            TruncateFilter(max_length=5, suffix="......")

    def test_invalid_max_length(self):
        """Test that max_length must be positive."""
        with pytest.raises(ValueError, match="max_length must be positive"):
            TruncateFilter(max_length=0)

        with pytest.raises(ValueError, match="max_length must be positive"):
            TruncateFilter(max_length=-1)

    def test_converts_non_strings(self):
        """Test converting non-string values."""
        f = TruncateFilter(max_length=5)
        assert f(12345678) == "12345"


class TestRemoveSpecialCharsFilter:
    """Tests for RemoveSpecialCharsFilter."""

    def test_removes_special_characters(self):
        """Test removing special characters."""
        f = RemoveSpecialCharsFilter()
        assert f("hello@world!") == "helloworld"
        assert f("test#$%123") == "test123"

    def test_preserves_alphanumeric(self):
        """Test that alphanumeric characters are preserved."""
        f = RemoveSpecialCharsFilter()
        assert f("abc123") == "abc123"
        assert f("Test123") == "Test123"

    def test_allows_specific_characters(self):
        """Test allowing specific characters."""
        f = RemoveSpecialCharsFilter(allowed_chars={" ", "-", "."})
        assert f("hello-world.com!") == "hello-world.com"
        assert f("test user@example") == "test userexample"

    def test_replacement_character(self):
        """Test replacing special chars with specific character."""
        f = RemoveSpecialCharsFilter(replacement="_")
        assert f("hello@world!") == "hello_world_"
        assert f("test#value") == "test_value"

    def test_empty_string(self):
        """Test empty string."""
        f = RemoveSpecialCharsFilter()
        assert f("") == ""

    def test_only_special_characters(self):
        """Test string with only special characters."""
        f = RemoveSpecialCharsFilter()
        assert f("@#$%!") == ""


class TestEmailNormalizationFilter:
    """Tests for EmailNormalizationFilter."""

    def test_normalizes_case(self):
        """Test email case normalization."""
        f = EmailNormalizationFilter()
        assert f("John.Doe@Example.COM") == "john.doe@example.com"

    def test_removes_gmail_dots(self):
        """Test removing dots from Gmail addresses."""
        f = EmailNormalizationFilter()
        assert f("john.doe@gmail.com") == "johndoe@gmail.com"
        assert f("test.user@googlemail.com") == "testuser@googlemail.com"

    def test_keeps_dots_in_non_gmail(self):
        """Test that dots are kept in non-Gmail addresses."""
        f = EmailNormalizationFilter()
        assert f("john.doe@example.com") == "john.doe@example.com"

    def test_removes_plus_tags(self):
        """Test removing + tags from emails."""
        f = EmailNormalizationFilter()
        assert f("user+tag@example.com") == "user@example.com"
        assert f("test+filter@gmail.com") == "test@gmail.com"

    def test_strips_whitespace(self):
        """Test stripping whitespace."""
        f = EmailNormalizationFilter()
        assert f("  user@example.com  ") == "user@example.com"

    def test_invalid_email_no_at(self):
        """Test that emails without @ raise error."""
        f = EmailNormalizationFilter()
        with pytest.raises(ValueError, match="Invalid email format"):
            f("notanemail")

    def test_invalid_email_multiple_at(self):
        """Test that emails with multiple @ raise error."""
        f = EmailNormalizationFilter()
        with pytest.raises(ValueError, match="Invalid email format"):
            f("user@@example.com")

    def test_complex_gmail_normalization(self):
        """Test complex Gmail normalization."""
        f = EmailNormalizationFilter()
        assert f("John.Doe+spam@Gmail.COM") == "johndoe@gmail.com"


class TestSlugifyFilter:
    """Tests for SlugifyFilter."""

    def test_basic_slugify(self):
        """Test basic slug conversion."""
        f = SlugifyFilter()
        assert f("Hello World") == "hello-world"
        assert f("Test Title") == "test-title"

    def test_removes_special_characters(self):
        """Test removing special characters."""
        f = SlugifyFilter()
        assert f("Hello World!") == "hello-world"
        assert f("Test@Title#123") == "testtitle123"

    def test_multiple_spaces(self):
        """Test handling multiple spaces."""
        f = SlugifyFilter()
        assert f("Hello   World") == "hello-world"

    def test_leading_trailing_separators(self):
        """Test removing leading/trailing separators."""
        f = SlugifyFilter()
        assert f("  Hello World  ") == "hello-world"

    def test_custom_separator(self):
        """Test custom separator."""
        f = SlugifyFilter(separator="_")
        assert f("Hello World") == "hello_world"

    def test_no_lowercase(self):
        """Test preserving case."""
        f = SlugifyFilter(lowercase=False)
        assert f("Hello World") == "Hello-World"

    def test_empty_string(self):
        """Test empty string."""
        f = SlugifyFilter()
        assert f("") == ""


class TestRegexReplaceFilter:
    """Tests for RegexReplaceFilter."""

    def test_basic_replacement(self):
        """Test basic regex replacement."""
        f = RegexReplaceFilter(r"\d+", "X")
        assert f("I have 123 apples") == "I have X apples"

    def test_multiple_replacements(self):
        """Test multiple replacements."""
        f = RegexReplaceFilter(r"\d+", "X")
        assert f("123 and 456") == "X and X"

    def test_limited_replacements(self):
        """Test limited number of replacements."""
        f = RegexReplaceFilter(r"\d+", "X", count=1)
        assert f("123 and 456") == "X and 456"

    def test_complex_pattern(self):
        """Test complex regex pattern."""
        f = RegexReplaceFilter(r"\b[A-Z]{2,}\b", "ACRONYM")
        assert f("The USA and UK are countries") == "The ACRONYM and ACRONYM are countries"

    def test_no_matches(self):
        """Test when pattern doesn't match."""
        f = RegexReplaceFilter(r"\d+", "X")
        assert f("no numbers here") == "no numbers here"


class TestFilterChain:
    """Tests for FilterChain."""

    def test_chain_applies_filters_in_order(self):
        """Test that filters are applied in sequence."""
        chain = FilterChain([StripWhitespaceFilter(), LowercaseFilter()])
        assert chain("  HELLO  ") == "hello"

    def test_chain_with_multiple_filters(self):
        """Test chain with multiple filters."""
        chain = FilterChain(
            [
                StripWhitespaceFilter(),
                LowercaseFilter(),
                TruncateFilter(max_length=5),
            ]
        )
        assert chain("  HELLO WORLD  ") == "hello"

    def test_chain_then_adds_filter(self):
        """Test that then() adds filter to chain."""
        chain = FilterChain([StripWhitespaceFilter(), LowercaseFilter()])
        new_chain = chain.then(TruncateFilter(max_length=5))

        assert len(new_chain.filters) == 3
        assert new_chain("  HELLO WORLD  ") == "hello"

    def test_empty_chain_raises_error(self):
        """Test that empty chain raises error."""
        with pytest.raises(ValueError, match="must contain at least one filter"):
            FilterChain([])

    def test_chain_repr(self):
        """Test chain string representation."""
        chain = FilterChain([StripWhitespaceFilter(), LowercaseFilter()])
        repr_str = repr(chain)
        assert "StripWhitespaceFilter" in repr_str
        assert "LowercaseFilter" in repr_str
        assert "->" in repr_str

    def test_complex_chain(self):
        """Test complex filter chain."""
        chain = FilterChain(
            [
                StripWhitespaceFilter(),
                LowercaseFilter(),
                RemoveSpecialCharsFilter(allowed_chars={"-", " "}),
                SlugifyFilter(),
            ]
        )
        assert chain("  Hello World! @#$  ") == "hello-world"

    def test_filter_then_method(self):
        """Test chaining with then() method."""
        chain = StripWhitespaceFilter().then(LowercaseFilter()).then(TruncateFilter(max_length=10))
        assert chain("  HELLO WORLD  ") == "hello worl"


class TestFilterEdgeCases:
    """Tests for edge cases and error handling."""

    def test_none_value_handling(self):
        """Test handling None values (converts to string)."""
        f = StripWhitespaceFilter()
        assert f(None) == "None"

    def test_numeric_values(self):
        """Test handling numeric values."""
        f = LowercaseFilter()
        assert f(123) == "123"
        assert f(45.67) == "45.67"

    def test_boolean_values(self):
        """Test handling boolean values."""
        f = LowercaseFilter()
        assert f(True) == "true"
        assert f(False) == "false"

    def test_unicode_handling(self):
        """Test handling Unicode characters."""
        f = StripWhitespaceFilter()
        assert f("  héllo wørld  ") == "héllo wørld"

        f2 = LowercaseFilter()
        assert f2("HÉLLO") == "héllo"

    def test_empty_string_handling(self):
        """Test handling empty strings."""
        f = StripWhitespaceFilter()
        assert f("") == ""

        f2 = LowercaseFilter()
        assert f2("") == ""

    def test_whitespace_only_string(self):
        """Test handling whitespace-only strings."""
        f = StripWhitespaceFilter()
        assert f("   ") == ""
        assert f("\n\t  ") == ""


class TestFilterComposition:
    """Tests for filter composition patterns."""

    def test_email_cleaning_pipeline(self):
        """Test typical email cleaning pipeline."""
        pipeline = FilterChain([StripWhitespaceFilter(), EmailNormalizationFilter()])

        assert pipeline("  John.Doe+spam@Gmail.COM  ") == "johndoe@gmail.com"

    def test_username_sanitization(self):
        """Test username sanitization pipeline."""
        pipeline = FilterChain(
            [
                StripWhitespaceFilter(),
                LowercaseFilter(),
                RemoveSpecialCharsFilter(allowed_chars={"_", "-"}),
                TruncateFilter(max_length=20),
            ]
        )

        assert pipeline("  Test@User#123!  ") == "testuser123"

    def test_title_slugification(self):
        """Test title to slug conversion."""
        pipeline = FilterChain([StripWhitespaceFilter(), SlugifyFilter()])

        assert pipeline("  Hello World! How are you?  ") == "hello-world-how-are-you"
