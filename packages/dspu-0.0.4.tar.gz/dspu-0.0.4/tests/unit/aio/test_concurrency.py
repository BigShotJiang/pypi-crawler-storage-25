"""Tests for concurrency utilities."""

import asyncio
import contextlib
import time

import pytest

from dspu.aio import (
    AsyncTimeoutError,
    Timeout,
    gather_with_limit,
    gather_with_limit_from_iter,
    run_in_executor,
    run_with_shield,
    run_with_timeout,
    run_with_timeout_or_default,
)


class TestGatherWithLimit:
    """Tests for gather_with_limit function."""

    @pytest.mark.asyncio
    async def test_gather_all_successful(self):
        """Test gathering all successful awaitables."""

        async def task(value):
            await asyncio.sleep(0.01)
            return value * 2

        results = await gather_with_limit(task(1), task(2), task(3), task(4), task(5), limit=2)

        assert results == [2, 4, 6, 8, 10]

    @pytest.mark.asyncio
    async def test_gather_respects_limit(self):
        """Test that concurrency limit is respected."""
        concurrent_count = 0
        max_concurrent = 0

        async def task():
            nonlocal concurrent_count, max_concurrent
            concurrent_count += 1
            max_concurrent = max(max_concurrent, concurrent_count)
            await asyncio.sleep(0.05)
            concurrent_count -= 1
            return "done"

        await gather_with_limit(
            *[task() for _ in range(10)],
            limit=3,
        )

        # Max concurrent should not exceed limit
        assert max_concurrent <= 3

    @pytest.mark.asyncio
    async def test_gather_with_exceptions(self):
        """Test gather with some failing tasks."""

        async def task(value):
            if value == 3:
                raise ValueError(f"Failed: {value}")
            return value

        with pytest.raises(ValueError):
            await gather_with_limit(
                task(1), task(2), task(3), task(4), limit=2, return_exceptions=False
            )

    @pytest.mark.asyncio
    async def test_gather_return_exceptions(self):
        """Test gather with return_exceptions=True."""

        async def task(value):
            if value % 2 == 0:
                raise ValueError(f"Even: {value}")
            return value

        results = await gather_with_limit(
            task(1), task(2), task(3), task(4), limit=2, return_exceptions=True
        )

        assert results[0] == 1  # Success
        assert isinstance(results[1], ValueError)  # Exception
        assert results[2] == 3  # Success
        assert isinstance(results[3], ValueError)  # Exception

    @pytest.mark.asyncio
    async def test_gather_empty_list(self):
        """Test gather with empty list."""
        results = await gather_with_limit(limit=2)
        assert results == []

    @pytest.mark.asyncio
    async def test_gather_invalid_limit(self):
        """Test that invalid limit raises error."""

        async def task():
            return 1

        with pytest.raises(ValueError, match="Limit must be positive"):
            await gather_with_limit(task(), limit=0)

        with pytest.raises(ValueError, match="Limit must be positive"):
            await gather_with_limit(task(), limit=-1)

    @pytest.mark.asyncio
    async def test_gather_preserves_order(self):
        """Test that results are returned in input order."""

        async def task(value, delay):
            await asyncio.sleep(delay)
            return value

        # Tasks complete in different order than submitted
        results = await gather_with_limit(
            task(1, 0.05),
            task(2, 0.01),
            task(3, 0.03),
            task(4, 0.02),
            limit=2,
        )

        # But results should be in input order
        assert results == [1, 2, 3, 4]


class TestGatherWithLimitFromIter:
    """Tests for gather_with_limit_from_iter function."""

    @pytest.mark.asyncio
    async def test_gather_from_iterable(self):
        """Test gather from an iterable."""

        async def task(value):
            return value * 2

        tasks = (task(i) for i in range(5))
        results = await gather_with_limit_from_iter(tasks, limit=2)

        assert results == [0, 2, 4, 6, 8]

    @pytest.mark.asyncio
    async def test_gather_from_filtered_iterable(self):
        """Test gather from filtered iterable."""

        async def task(value):
            return value * 2

        tasks = (task(i) for i in range(10) if i % 2 == 0)
        results = await gather_with_limit_from_iter(tasks, limit=3)

        assert results == [0, 4, 8, 12, 16]


class TestRunWithTimeout:
    """Tests for run_with_timeout function."""

    @pytest.mark.asyncio
    async def test_successful_within_timeout(self):
        """Test successful completion within timeout."""

        async def quick_task():
            await asyncio.sleep(0.01)
            return "success"

        result = await run_with_timeout(quick_task(), timeout=1.0)
        assert result == "success"

    @pytest.mark.asyncio
    async def test_timeout_exceeded(self):
        """Test that timeout is enforced."""

        async def slow_task():
            await asyncio.sleep(1.0)
            return "too slow"

        with pytest.raises(AsyncTimeoutError) as exc_info:
            await run_with_timeout(slow_task(), timeout=0.05)

        assert exc_info.value.timeout == 0.05

    @pytest.mark.asyncio
    async def test_exception_propagates(self):
        """Test that exceptions from task propagate."""

        async def failing_task():
            raise ValueError("Task failed")

        with pytest.raises(ValueError, match="Task failed"):
            await run_with_timeout(failing_task(), timeout=1.0)


class TestRunWithTimeoutOrDefault:
    """Tests for run_with_timeout_or_default function."""

    @pytest.mark.asyncio
    async def test_successful_returns_result(self):
        """Test successful completion returns result."""

        async def task():
            return "success"

        result = await run_with_timeout_or_default(task(), timeout=1.0, default="default")
        assert result == "success"

    @pytest.mark.asyncio
    async def test_timeout_returns_default(self):
        """Test that timeout returns default value."""

        async def slow_task():
            await asyncio.sleep(1.0)
            return "result"

        result = await run_with_timeout_or_default(slow_task(), timeout=0.05, default="default")
        assert result == "default"

    @pytest.mark.asyncio
    async def test_exception_propagates(self):
        """Test that exceptions still propagate."""

        async def failing_task():
            raise ValueError("Failed")

        with pytest.raises(ValueError):
            await run_with_timeout_or_default(failing_task(), timeout=1.0, default="default")


class TestRunWithShield:
    """Tests for run_with_shield function."""

    @pytest.mark.asyncio
    async def test_shield_basic(self):
        """Test basic shielding functionality."""

        async def task():
            await asyncio.sleep(0.01)
            return "shielded"

        result = await run_with_shield(task())
        assert result == "shielded"

    @pytest.mark.asyncio
    async def test_shield_protects_from_cancellation(self):
        """Test that shield protects from cancellation."""

        completed = False

        async def protected_task():
            nonlocal completed
            await asyncio.sleep(0.1)
            completed = True
            return "done"

        async def run_with_cancel():
            task = asyncio.create_task(run_with_shield(protected_task()))
            await asyncio.sleep(0.01)
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
            # Give task time to complete
            await asyncio.sleep(0.15)

        await run_with_cancel()
        # Task should have completed despite cancellation attempt
        assert completed


class TestRunInExecutor:
    """Tests for run_in_executor function."""

    @pytest.mark.asyncio
    async def test_run_sync_function(self):
        """Test running a sync function in executor."""

        def sync_func(a, b):
            return a + b

        result = await run_in_executor(sync_func, 2, 3)
        assert result == 5

    @pytest.mark.asyncio
    async def test_run_with_kwargs(self):
        """Test running function with keyword arguments."""

        def sync_func(a, b=10):
            return a * b

        result = await run_in_executor(sync_func, 3, b=4)
        assert result == 12

    @pytest.mark.asyncio
    async def test_blocking_operation(self):
        """Test running blocking operation without blocking event loop."""
        import time as time_module

        def blocking_operation():
            time_module.sleep(0.1)
            return "done"

        start = time.monotonic()
        result = await run_in_executor(blocking_operation)
        elapsed = time.monotonic() - start

        assert result == "done"
        assert elapsed >= 0.09  # Should have taken ~0.1 seconds


class TestTimeoutContextManager:
    """Tests for Timeout context manager."""

    @pytest.mark.asyncio
    async def test_timeout_context_successful(self):
        """Test successful completion within timeout."""

        async with Timeout(1.0):
            await asyncio.sleep(0.01)
            result = "success"

        assert result == "success"

    @pytest.mark.asyncio
    async def test_timeout_context_cancels(self):
        """Test that timeout cancels the task."""

        with pytest.raises(asyncio.CancelledError):
            async with Timeout(0.05):
                await asyncio.sleep(1.0)

    @pytest.mark.asyncio
    async def test_timeout_allows_quick_operations(self):
        """Test that quick operations complete successfully."""
        results = []

        async with Timeout(1.0):
            for i in range(5):
                await asyncio.sleep(0.01)
                results.append(i)

        assert results == [0, 1, 2, 3, 4]


class TestConcurrencyEdgeCases:
    """Tests for edge cases in concurrency utilities."""

    @pytest.mark.asyncio
    async def test_gather_limit_equals_task_count(self):
        """Test when limit equals number of tasks."""

        async def task(value):
            return value

        results = await gather_with_limit(task(1), task(2), task(3), limit=3)
        assert results == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_gather_limit_exceeds_task_count(self):
        """Test when limit exceeds number of tasks."""

        async def task(value):
            return value

        results = await gather_with_limit(task(1), task(2), limit=10)
        assert results == [1, 2]

    @pytest.mark.asyncio
    async def test_very_short_timeout(self):
        """Test with very short timeout."""

        async def instant_task():
            return "done"

        result = await run_with_timeout(instant_task(), timeout=0.001)
        assert result == "done"

    @pytest.mark.asyncio
    async def test_concurrent_gather_calls(self):
        """Test multiple concurrent gather_with_limit calls."""

        async def task(value):
            await asyncio.sleep(0.01)
            return value

        results = await asyncio.gather(
            gather_with_limit(task(1), task(2), limit=1),
            gather_with_limit(task(3), task(4), limit=1),
        )

        assert results == [[1, 2], [3, 4]]


class TestConcurrencyPerformance:
    """Tests for performance characteristics."""

    @pytest.mark.asyncio
    async def test_gather_with_limit_improves_performance(self):
        """Test that limited gather can improve performance."""

        call_times = []

        async def task():
            call_times.append(time.monotonic())
            await asyncio.sleep(0.05)

        # With limit of 5, should take ~0.1 seconds for 10 tasks
        # (2 batches of 5 concurrent tasks)
        start = time.monotonic()
        await gather_with_limit(*[task() for _ in range(10)], limit=5)
        elapsed = time.monotonic() - start

        # Should take roughly 2 * 0.05 = 0.1 seconds
        assert 0.08 < elapsed < 0.2

    @pytest.mark.asyncio
    async def test_unlimited_vs_limited_gather(self):
        """Compare unlimited vs limited gather timing."""

        async def task():
            await asyncio.sleep(0.01)
            return "done"

        # Limited gather (limit=2 for 6 tasks = 3 batches)
        start = time.monotonic()
        await gather_with_limit(*[task() for _ in range(6)], limit=2)
        limited_time = time.monotonic() - start

        # Should take roughly 3 * 0.01 = 0.03 seconds
        assert 0.025 < limited_time < 0.06
