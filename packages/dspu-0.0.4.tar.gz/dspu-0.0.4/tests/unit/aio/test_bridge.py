"""Tests for sync/async bridge utilities."""

import asyncio

import pytest

from dspu.aio import (
    AsyncContextManager,
    async_to_sync,
    ensure_coroutine,
    iter_over_async,
    run_async,
    sync_to_async,
)


class TestRunAsync:
    """Tests for run_async function."""

    def test_run_async_with_result(self):
        """Test running async function and getting result."""

        async def async_func():
            await asyncio.sleep(0.01)
            return "result"

        result = run_async(async_func())
        assert result == "result"

    def test_run_async_with_exception(self):
        """Test that exceptions propagate."""

        async def failing_func():
            raise ValueError("Failed")

        with pytest.raises(ValueError, match="Failed"):
            run_async(failing_func())

    def test_run_async_with_arguments(self):
        """Test running async function with arguments."""

        async def async_func(a, b):
            return a + b

        result = run_async(async_func(2, 3))
        assert result == 5


class TestSyncToAsync:
    """Tests for sync_to_async conversion."""

    @pytest.mark.asyncio
    async def test_convert_sync_to_async(self):
        """Test converting sync function to async."""

        def sync_func(x):
            return x * 2

        async_func = sync_to_async(sync_func)
        result = await async_func(5)
        assert result == 10

    @pytest.mark.asyncio
    async def test_blocking_function_doesnt_block_loop(self):
        """Test that converted sync function doesn't block event loop."""
        import time

        def blocking_func():
            time.sleep(0.1)
            return "done"

        async_func = sync_to_async(blocking_func)

        # Run concurrently with another task
        other_completed = False

        async def other_task():
            nonlocal other_completed
            await asyncio.sleep(0.05)
            other_completed = True

        result, _ = await asyncio.gather(async_func(), other_task())

        assert result == "done"
        assert other_completed  # Should have completed while blocking func was running

    @pytest.mark.asyncio
    async def test_sync_to_async_with_kwargs(self):
        """Test converted function with keyword arguments."""

        def sync_func(a, b=10):
            return a * b

        async_func = sync_to_async(sync_func)
        result = await async_func(3, b=4)
        assert result == 12

    @pytest.mark.asyncio
    async def test_sync_to_async_exception_propagates(self):
        """Test that exceptions from sync function propagate."""

        def failing_func():
            raise ValueError("Sync error")

        async_func = sync_to_async(failing_func)

        with pytest.raises(ValueError, match="Sync error"):
            await async_func()


class TestAsyncToSync:
    """Tests for async_to_sync conversion."""

    def test_convert_async_to_sync(self):
        """Test converting async function to sync."""

        async def async_func(x):
            await asyncio.sleep(0.01)
            return x * 2

        sync_func = async_to_sync(async_func)
        result = sync_func(5)
        assert result == 10

    def test_async_to_sync_with_kwargs(self):
        """Test converted function with keyword arguments."""

        async def async_func(a, b=10):
            await asyncio.sleep(0.01)
            return a + b

        sync_func = async_to_sync(async_func)
        result = sync_func(3, b=7)
        assert result == 10

    def test_async_to_sync_exception_propagates(self):
        """Test that exceptions from async function propagate."""

        async def failing_func():
            raise ValueError("Async error")

        sync_func = async_to_sync(failing_func)

        with pytest.raises(ValueError, match="Async error"):
            sync_func()


class TestIterOverAsync:
    """Tests for iter_over_async function."""

    def test_iterate_over_async_generator(self):
        """Test iterating over async generator."""

        async def async_gen():
            for i in range(5):
                await asyncio.sleep(0.01)
                yield i

        results = list(iter_over_async(async_gen()))
        assert results == [0, 1, 2, 3, 4]

    def test_iterate_empty_generator(self):
        """Test iterating over empty async generator."""

        async def empty_gen():
            return
            yield  # unreachable, but makes it a generator

        results = list(iter_over_async(empty_gen()))
        assert results == []

    def test_iterate_with_exception(self):
        """Test iteration when async generator raises exception."""

        async def failing_gen():
            yield 1
            yield 2
            raise ValueError("Generator failed")

        with pytest.raises(ValueError, match="Generator failed"):
            list(iter_over_async(failing_gen()))


class TestAsyncContextManager:
    """Tests for AsyncContextManager wrapper."""

    def test_sync_usage_of_async_context_manager(self):
        """Test using async context manager from sync code."""

        class MyAsyncContextManager:
            def __init__(self):
                self.entered = False
                self.exited = False

            async def __aenter__(self):
                self.entered = True
                return self

            async def __aexit__(self, exc_type, exc_val, exc_tb):
                self.exited = True

        async_cm = MyAsyncContextManager()

        with AsyncContextManager(async_cm) as value:
            assert value.entered
            assert not value.exited

        assert async_cm.entered
        assert async_cm.exited

    def test_context_manager_with_exception(self):
        """Test context manager handles exceptions."""

        class MyAsyncContextManager:
            def __init__(self):
                self.exception_handled = False

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc_val, exc_tb):
                if exc_type is not None:
                    self.exception_handled = True
                return False  # Don't suppress exception

        async_cm = MyAsyncContextManager()

        with pytest.raises(ValueError), AsyncContextManager(async_cm):
            raise ValueError("Test error")

        assert async_cm.exception_handled


class TestEnsureCoroutine:
    """Tests for ensure_coroutine function."""

    @pytest.mark.asyncio
    async def test_coroutine_function_unchanged(self):
        """Test that coroutine functions are returned unchanged."""

        async def async_func(x):
            return x * 2

        ensured = ensure_coroutine(async_func)
        assert ensured is async_func

        result = await ensured(5)
        assert result == 10

    @pytest.mark.asyncio
    async def test_sync_function_converted(self):
        """Test that sync functions are converted to async."""

        def sync_func(x):
            return x * 2

        ensured = ensure_coroutine(sync_func)
        assert ensured is not sync_func
        assert asyncio.iscoroutinefunction(ensured)

        result = await ensured(5)
        assert result == 10

    @pytest.mark.asyncio
    async def test_ensure_coroutine_with_kwargs(self):
        """Test ensure_coroutine with keyword arguments."""

        def sync_func(a, b=10):
            return a + b

        ensured = ensure_coroutine(sync_func)
        result = await ensured(5, b=3)
        assert result == 8


class TestBridgeEdgeCases:
    """Tests for edge cases in bridge utilities."""

    @pytest.mark.asyncio
    async def test_nested_conversions(self):
        """Test nested sync/async conversions."""

        async def original_async(x):
            return x * 2

        # Convert to sync, then back to async
        sync_version = async_to_sync(original_async)
        async_again = sync_to_async(sync_version)

        result = await async_again(5)
        assert result == 10

    def test_multiple_iterations_over_async(self):
        """Test that we can't iterate multiple times (generator exhaustion)."""

        async def async_gen():
            for i in range(3):
                yield i

        gen = async_gen()
        list1 = list(iter_over_async(gen))

        # Second iteration should be empty (generator exhausted)
        assert list1 == [0, 1, 2]

    @pytest.mark.asyncio
    async def test_sync_to_async_multiple_concurrent_calls(self):
        """Test multiple concurrent calls to converted function."""
        import time

        call_times = []

        def sync_func(value):
            call_times.append(time.monotonic())
            time.sleep(0.05)
            return value

        async_func = sync_to_async(sync_func)

        # Make multiple concurrent calls
        results = await asyncio.gather(
            async_func(1),
            async_func(2),
            async_func(3),
        )

        assert results == [1, 2, 3]
        # Calls should have overlapped (running in different threads)
        assert len(call_times) == 3


class TestBridgeIntegration:
    """Integration tests for bridge utilities."""

    @pytest.mark.asyncio
    async def test_mixed_sync_async_pipeline(self):
        """Test pipeline mixing sync and async functions."""

        def sync_step1(x):
            return x * 2

        async def async_step2(x):
            await asyncio.sleep(0.01)
            return x + 10

        def sync_step3(x):
            return x**2

        # Build pipeline
        step1 = ensure_coroutine(sync_step1)
        step2 = async_step2
        step3 = ensure_coroutine(sync_step3)

        # Execute pipeline
        result = await step1(5)  # 10
        result = await step2(result)  # 20
        result = await step3(result)  # 400

        assert result == 400

    def test_sync_code_using_async_utilities(self):
        """Test sync code using multiple async utilities."""

        async def fetch_data(source):
            await asyncio.sleep(0.01)
            return f"data from {source}"

        async def process_data(data):
            await asyncio.sleep(0.01)
            return data.upper()

        def sync_workflow():
            # Fetch data
            data = run_async(fetch_data("api"))

            # Process it
            return run_async(process_data(data))

        result = sync_workflow()
        assert result == "DATA FROM API"

    @pytest.mark.asyncio
    async def test_async_code_using_sync_libraries(self):
        """Test async code using sync library functions."""
        import json

        # Simulate sync library functions
        def sync_parse(data):
            return json.loads(data)

        def sync_validate(obj):
            return "name" in obj and "value" in obj

        # Convert to async
        async_parse = sync_to_async(sync_parse)
        async_validate = sync_to_async(sync_validate)

        # Use in async code
        data = '{"name": "test", "value": 42}'
        obj = await async_parse(data)
        is_valid = await async_validate(obj)

        assert is_valid
        assert obj["value"] == 42
