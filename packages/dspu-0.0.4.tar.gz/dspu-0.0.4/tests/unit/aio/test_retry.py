"""Tests for retry utilities."""

import pytest

from dspu.aio import BackoffStrategy, RetryError, calculate_backoff_delay, retry, retry_async


class TestCalculateBackoffDelay:
    """Tests for backoff delay calculation."""

    def test_exponential_backoff(self):
        """Test exponential backoff calculation."""
        # Base delay 1.0, multiplier 2.0
        delay0 = calculate_backoff_delay(0, strategy=BackoffStrategy.EXPONENTIAL, jitter=False)
        delay1 = calculate_backoff_delay(1, strategy=BackoffStrategy.EXPONENTIAL, jitter=False)
        delay2 = calculate_backoff_delay(2, strategy=BackoffStrategy.EXPONENTIAL, jitter=False)

        assert delay0 == 1.0  # 1.0 * 2^0
        assert delay1 == 2.0  # 1.0 * 2^1
        assert delay2 == 4.0  # 1.0 * 2^2

    def test_linear_backoff(self):
        """Test linear backoff calculation."""
        delay0 = calculate_backoff_delay(0, strategy=BackoffStrategy.LINEAR, jitter=False)
        delay1 = calculate_backoff_delay(1, strategy=BackoffStrategy.LINEAR, jitter=False)
        delay2 = calculate_backoff_delay(2, strategy=BackoffStrategy.LINEAR, jitter=False)

        assert delay0 == 1.0  # 1.0 + 2.0 * 0
        assert delay1 == 3.0  # 1.0 + 2.0 * 1
        assert delay2 == 5.0  # 1.0 + 2.0 * 2

    def test_constant_backoff(self):
        """Test constant backoff calculation."""
        delay0 = calculate_backoff_delay(0, strategy=BackoffStrategy.CONSTANT, jitter=False)
        delay1 = calculate_backoff_delay(1, strategy=BackoffStrategy.CONSTANT, jitter=False)
        delay2 = calculate_backoff_delay(2, strategy=BackoffStrategy.CONSTANT, jitter=False)

        assert delay0 == 1.0
        assert delay1 == 1.0
        assert delay2 == 1.0

    def test_max_delay_cap(self):
        """Test that delay is capped at max_delay."""
        delay = calculate_backoff_delay(
            10,
            strategy=BackoffStrategy.EXPONENTIAL,
            base_delay=1.0,
            max_delay=10.0,
            jitter=False,
        )
        assert delay == 10.0

    def test_jitter_adds_randomness(self):
        """Test that jitter adds randomness to delay."""
        delays = [
            calculate_backoff_delay(
                5, strategy=BackoffStrategy.EXPONENTIAL, base_delay=1.0, jitter=True
            )
            for _ in range(10)
        ]

        # With jitter, delays should vary
        assert len(set(delays)) > 1

        # All delays should be positive
        assert all(d >= 0 for d in delays)

    def test_custom_parameters(self):
        """Test custom base delay and multiplier."""
        delay = calculate_backoff_delay(
            2,
            strategy=BackoffStrategy.EXPONENTIAL,
            base_delay=2.0,
            multiplier=3.0,
            jitter=False,
        )
        assert delay == 18.0  # 2.0 * 3^2


class TestRetryDecorator:
    """Tests for @retry decorator."""

    @pytest.mark.asyncio
    async def test_successful_call_no_retry(self):
        """Test that successful calls don't retry."""
        call_count = 0

        @retry(max_attempts=3)
        async def successful_func():
            nonlocal call_count
            call_count += 1
            return "success"

        result = await successful_func()
        assert result == "success"
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        """Test retrying on failures."""
        call_count = 0

        @retry(max_attempts=3, base_delay=0.01)
        async def failing_func():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Fail")
            return "success"

        result = await failing_func()
        assert result == "success"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_retry_exhausted(self):
        """Test that RetryError is raised when retries exhausted."""

        @retry(max_attempts=3, base_delay=0.01)
        async def always_fails():
            raise ValueError("Always fails")

        with pytest.raises(RetryError) as exc_info:
            await always_fails()

        assert exc_info.value.attempts == 3
        assert isinstance(exc_info.value.last_exception, ValueError)

    @pytest.mark.asyncio
    async def test_specific_exceptions_only(self):
        """Test retrying only specific exceptions."""
        call_count = 0

        @retry(max_attempts=3, base_delay=0.01, exceptions=(ValueError,))
        async def specific_error():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ValueError("Retryable")
            raise TypeError("Not retryable")

        with pytest.raises(TypeError):
            await specific_error()

        assert call_count == 2

    @pytest.mark.asyncio
    async def test_on_retry_callback(self):
        """Test on_retry callback is called."""
        retry_info = []

        async def on_retry_callback(attempt, exception):
            retry_info.append((attempt, str(exception)))

        @retry(max_attempts=3, base_delay=0.01, on_retry=on_retry_callback)
        async def failing_func():
            if len(retry_info) < 2:
                raise ValueError(f"Fail {len(retry_info)}")
            return "success"

        await failing_func()

        assert len(retry_info) == 2
        assert retry_info[0][0] == 1
        assert retry_info[1][0] == 2

    @pytest.mark.asyncio
    async def test_exponential_backoff_timing(self):
        """Test that exponential backoff increases delays."""
        import time

        attempts = []

        @retry(
            max_attempts=3,
            strategy=BackoffStrategy.EXPONENTIAL,
            base_delay=0.05,
            jitter=False,
        )
        async def time_tracking_func():
            attempts.append(time.time())
            if len(attempts) < 3:
                raise ValueError("Retry")
            return "done"

        await time_tracking_func()

        # Check that delays increase
        delay1 = attempts[1] - attempts[0]
        delay2 = attempts[2] - attempts[1]

        # Second delay should be roughly 2x first delay (exponential)
        assert delay2 > delay1 * 1.5

    @pytest.mark.asyncio
    async def test_linear_backoff_timing(self):
        """Test linear backoff strategy."""
        attempts = []

        @retry(
            max_attempts=3,
            strategy=BackoffStrategy.LINEAR,
            base_delay=0.05,
            multiplier=0.05,
            jitter=False,
        )
        async def linear_func():
            attempts.append(len(attempts))
            if len(attempts) < 3:
                raise ValueError("Retry")
            return "done"

        await linear_func()
        assert len(attempts) == 3

    @pytest.mark.asyncio
    async def test_constant_backoff(self):
        """Test constant backoff strategy."""
        attempts = []

        @retry(max_attempts=3, strategy=BackoffStrategy.CONSTANT, base_delay=0.01, jitter=False)
        async def constant_func():
            attempts.append(len(attempts))
            if len(attempts) < 3:
                raise ValueError("Retry")
            return "done"

        await constant_func()
        assert len(attempts) == 3


class TestRetryAsync:
    """Tests for retry_async function."""

    @pytest.mark.asyncio
    async def test_successful_call(self):
        """Test successful function call."""

        async def success_func(value):
            return value * 2

        result = await retry_async(success_func, 5, max_attempts=3)
        assert result == 10

    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        """Test retrying failed calls."""
        state = {"count": 0}

        async def failing_func():
            state["count"] += 1
            if state["count"] < 3:
                raise ValueError("Fail")
            return "success"

        result = await retry_async(failing_func, max_attempts=3, base_delay=0.01)
        assert result == "success"
        assert state["count"] == 3

    @pytest.mark.asyncio
    async def test_with_kwargs(self):
        """Test retry_async with keyword arguments."""

        async def func_with_kwargs(a, b=10):
            if a < 5:
                raise ValueError("Too small")
            return a + b

        result = await retry_async(func_with_kwargs, 5, b=20, max_attempts=2, base_delay=0.01)
        assert result == 25

    @pytest.mark.asyncio
    async def test_retry_exhausted(self):
        """Test RetryError when retries exhausted."""

        async def always_fails():
            raise ValueError("Always fails")

        with pytest.raises(RetryError) as exc_info:
            await retry_async(always_fails, max_attempts=3, base_delay=0.01)

        assert exc_info.value.attempts == 3

    @pytest.mark.asyncio
    async def test_exception_filtering(self):
        """Test that only specified exceptions are retried."""
        state = {"count": 0}

        async def specific_errors():
            state["count"] += 1
            if state["count"] == 1:
                raise ValueError("Retry this")
            raise TypeError("Don't retry this")

        with pytest.raises(TypeError):
            await retry_async(
                specific_errors, max_attempts=3, base_delay=0.01, exceptions=(ValueError,)
            )

        assert state["count"] == 2


class TestRetryErrorDetails:
    """Tests for RetryError exception details."""

    @pytest.mark.asyncio
    async def test_retry_error_attributes(self):
        """Test RetryError contains correct attributes."""

        @retry(max_attempts=2, base_delay=0.01)
        async def failing():
            raise ValueError("Original error")

        with pytest.raises(RetryError) as exc_info:
            await failing()

        error = exc_info.value
        assert error.attempts == 2
        assert isinstance(error.last_exception, ValueError)
        assert str(error.last_exception) == "Original error"

    @pytest.mark.asyncio
    async def test_retry_error_message(self):
        """Test RetryError message is descriptive."""

        @retry(max_attempts=5, base_delay=0.01)
        async def failing():
            raise ValueError("Test")

        with pytest.raises(RetryError) as exc_info:
            await failing()

        assert "5 attempts" in str(exc_info.value)
