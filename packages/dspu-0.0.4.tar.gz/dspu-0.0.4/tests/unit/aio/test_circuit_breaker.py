"""Tests for circuit breaker utilities."""

import asyncio

import pytest

from dspu.aio import CircuitBreaker, CircuitBreakerError, CircuitState, circuit_breaker


class TestCircuitBreakerBasics:
    """Tests for basic CircuitBreaker functionality."""

    @pytest.mark.asyncio
    async def test_initialization(self):
        """Test circuit breaker initialization."""
        cb = CircuitBreaker(failure_threshold=5, timeout=60.0)
        assert cb.state == CircuitState.CLOSED
        assert cb.failure_threshold == 5
        assert cb.timeout == 60.0
        assert cb.failure_count == 0

    def test_invalid_parameters(self):
        """Test that invalid parameters raise errors."""
        with pytest.raises(ValueError, match="Failure threshold must be positive"):
            CircuitBreaker(failure_threshold=0)

        with pytest.raises(ValueError, match="Success threshold must be positive"):
            CircuitBreaker(success_threshold=0)

        with pytest.raises(ValueError, match="Timeout must be positive"):
            CircuitBreaker(timeout=0.0)


class TestCircuitBreakerStates:
    """Tests for circuit breaker state transitions."""

    @pytest.mark.asyncio
    async def test_closed_state_allows_calls(self):
        """Test that closed state allows function calls."""
        cb = CircuitBreaker()

        async def success_func():
            return "success"

        result = await cb.call(success_func)
        assert result == "success"
        assert cb.state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_transition_to_open_on_failures(self):
        """Test transition to open state after threshold failures."""
        cb = CircuitBreaker(failure_threshold=3, timeout=1.0)

        async def failing_func():
            raise ValueError("Fail")

        # Make failing calls
        for _ in range(3):
            with pytest.raises(ValueError):
                await cb.call(failing_func)

        # Circuit should now be open
        assert cb.state == CircuitState.OPEN
        assert cb.failure_count == 3

    @pytest.mark.asyncio
    async def test_open_state_blocks_calls(self):
        """Test that open state blocks function calls."""
        cb = CircuitBreaker(failure_threshold=2, timeout=1.0)

        async def failing_func():
            raise ValueError("Fail")

        # Trigger circuit to open
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(failing_func)

        # Next call should be blocked by circuit breaker
        with pytest.raises(CircuitBreakerError) as exc_info:
            await cb.call(failing_func)

        assert exc_info.value.state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_transition_to_half_open_after_timeout(self):
        """Test transition to half-open after timeout."""
        cb = CircuitBreaker(failure_threshold=2, timeout=0.1)

        async def failing_func():
            raise ValueError("Fail")

        # Open the circuit
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(failing_func)

        assert cb.state == CircuitState.OPEN

        # Wait for timeout
        await asyncio.sleep(0.15)

        # Next call should transition to half-open
        with pytest.raises(ValueError):
            await cb.call(failing_func)

        # State should have been half-open during the call
        # (now back to open due to failure)
        assert cb.state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_half_open_success_closes_circuit(self):
        """Test that successes in half-open state close the circuit."""
        cb = CircuitBreaker(failure_threshold=2, success_threshold=2, timeout=0.1)

        call_count = 0

        async def func():
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                raise ValueError("Fail")
            return "success"

        # Open the circuit
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(func)

        assert cb.state == CircuitState.OPEN

        # Wait for timeout
        await asyncio.sleep(0.15)

        # Make successful calls
        result1 = await cb.call(func)
        result2 = await cb.call(func)

        assert result1 == "success"
        assert result2 == "success"
        assert cb.state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_half_open_failure_reopens_circuit(self):
        """Test that failure in half-open reopens the circuit."""
        cb = CircuitBreaker(failure_threshold=2, timeout=0.1)

        async def failing_func():
            raise ValueError("Fail")

        # Open the circuit
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(failing_func)

        # Wait for timeout
        await asyncio.sleep(0.15)

        # Fail in half-open state
        with pytest.raises(ValueError):
            await cb.call(failing_func)

        assert cb.state == CircuitState.OPEN


class TestCircuitBreakerFailureCount:
    """Tests for failure counting."""

    @pytest.mark.asyncio
    async def test_failure_count_increments(self):
        """Test that failure count increments on errors."""
        cb = CircuitBreaker(failure_threshold=5)

        async def failing_func():
            raise ValueError("Fail")

        for i in range(3):
            with pytest.raises(ValueError):
                await cb.call(failing_func)
            assert cb.failure_count == i + 1

    @pytest.mark.asyncio
    async def test_failure_count_resets_on_success(self):
        """Test that failure count resets on successful call."""
        cb = CircuitBreaker()

        call_count = 0

        async def func():
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                raise ValueError("Fail")
            return "success"

        # Make some failures
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(func)

        assert cb.failure_count == 2

        # Success should reset count
        await cb.call(func)
        assert cb.failure_count == 0


class TestCircuitBreakerExceptionFiltering:
    """Tests for exception filtering."""

    @pytest.mark.asyncio
    async def test_only_specified_exceptions_counted(self):
        """Test that only specified exceptions count as failures."""
        cb = CircuitBreaker(failure_threshold=2, exceptions=(ValueError,))

        async def mixed_errors(error_type):
            if error_type == "value":
                raise ValueError("Value error")
            raise TypeError("Type error")

        # ValueError should be counted
        with pytest.raises(ValueError):
            await cb.call(mixed_errors, "value")
        assert cb.failure_count == 1

        # TypeError should not be counted
        with pytest.raises(TypeError):
            await cb.call(mixed_errors, "type")
        assert cb.failure_count == 1  # Unchanged

    @pytest.mark.asyncio
    async def test_unfiltered_exceptions_pass_through(self):
        """Test that non-filtered exceptions pass through without counting."""
        cb = CircuitBreaker(failure_threshold=2, exceptions=(ValueError,))

        async def type_error():
            raise TypeError("Not counted")

        # Make multiple calls with TypeError
        for _ in range(5):
            with pytest.raises(TypeError):
                await cb.call(type_error)

        # Circuit should still be closed
        assert cb.state == CircuitState.CLOSED
        assert cb.failure_count == 0


class TestCircuitBreakerProtectContextManager:
    """Tests for protect() context manager."""

    @pytest.mark.asyncio
    async def test_protect_successful_operation(self):
        """Test protect context manager with successful operation."""
        cb = CircuitBreaker()

        async with cb.protect():
            result = "success"

        assert result == "success"
        assert cb.state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_protect_counts_failures(self):
        """Test that protect counts failures."""
        cb = CircuitBreaker(failure_threshold=2)

        for _ in range(2):
            with pytest.raises(ValueError):
                async with cb.protect():
                    raise ValueError("Fail")

        assert cb.state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_protect_blocks_when_open(self):
        """Test that protect blocks when circuit is open."""
        cb = CircuitBreaker(failure_threshold=1)

        # Open the circuit
        with pytest.raises(ValueError):
            async with cb.protect():
                raise ValueError("Fail")

        # Should be blocked
        with pytest.raises(CircuitBreakerError):
            async with cb.protect():
                pass


class TestCircuitBreakerDecorator:
    """Tests for @circuit_breaker decorator."""

    @pytest.mark.asyncio
    async def test_decorator_basic(self):
        """Test basic decorator usage."""
        cb = CircuitBreaker()

        @circuit_breaker(cb)
        async def protected_func():
            return "success"

        result = await protected_func()
        assert result == "success"

    @pytest.mark.asyncio
    async def test_decorator_counts_failures(self):
        """Test that decorator counts failures."""
        cb = CircuitBreaker(failure_threshold=2)

        @circuit_breaker(cb)
        async def failing_func():
            raise ValueError("Fail")

        for _ in range(2):
            with pytest.raises(ValueError):
                await failing_func()

        assert cb.state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_decorator_with_arguments(self):
        """Test decorator on function with arguments."""
        cb = CircuitBreaker()

        @circuit_breaker(cb)
        async def func_with_args(a, b):
            return a + b

        result = await func_with_args(2, 3)
        assert result == 5


class TestCircuitBreakerStateCallbacks:
    """Tests for state change callbacks."""

    @pytest.mark.asyncio
    async def test_state_change_callback_called(self):
        """Test that state change callback is called."""
        state_changes = []

        async def on_state_change(old_state, new_state):
            state_changes.append((old_state, new_state))

        cb = CircuitBreaker(failure_threshold=2, on_state_change=on_state_change)

        async def failing_func():
            raise ValueError("Fail")

        # Trigger state change to OPEN
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(failing_func)

        assert len(state_changes) == 1
        assert state_changes[0] == (CircuitState.CLOSED, CircuitState.OPEN)

    @pytest.mark.asyncio
    async def test_multiple_state_transitions_tracked(self):
        """Test tracking multiple state transitions."""
        state_changes = []

        async def on_state_change(old_state, new_state):
            state_changes.append((old_state, new_state))

        cb = CircuitBreaker(
            failure_threshold=2, success_threshold=1, timeout=0.1, on_state_change=on_state_change
        )

        async def func(should_fail):
            if should_fail:
                raise ValueError("Fail")
            return "success"

        # Transition to OPEN
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(func, True)

        # Wait for timeout and transition to HALF_OPEN
        await asyncio.sleep(0.15)

        # Success transitions to CLOSED
        await cb.call(func, False)

        # Should have: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
        assert len(state_changes) >= 2


class TestCircuitBreakerReset:
    """Tests for manual reset."""

    @pytest.mark.asyncio
    async def test_reset_closes_circuit(self):
        """Test that reset closes the circuit."""
        cb = CircuitBreaker(failure_threshold=2)

        async def failing_func():
            raise ValueError("Fail")

        # Open the circuit
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(failing_func)

        assert cb.state == CircuitState.OPEN

        # Reset
        await cb.reset()

        assert cb.state == CircuitState.CLOSED
        assert cb.failure_count == 0

    @pytest.mark.asyncio
    async def test_reset_allows_calls_again(self):
        """Test that reset allows calls to proceed."""
        cb = CircuitBreaker(failure_threshold=1)

        async def func(should_fail):
            if should_fail:
                raise ValueError("Fail")
            return "success"

        # Open the circuit
        with pytest.raises(ValueError):
            await cb.call(func, True)

        # Reset
        await cb.reset()

        # Should work now
        result = await cb.call(func, False)
        assert result == "success"


class TestCircuitBreakerConcurrency:
    """Tests for concurrent access."""

    @pytest.mark.asyncio
    async def test_concurrent_calls_through_circuit(self):
        """Test multiple concurrent calls through circuit breaker."""
        cb = CircuitBreaker(failure_threshold=10)

        call_count = 0

        async def concurrent_func():
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.01)
            return "success"

        # Launch concurrent calls
        results = await asyncio.gather(*[cb.call(concurrent_func) for _ in range(5)])

        assert len(results) == 5
        assert all(r == "success" for r in results)
        assert call_count == 5

    @pytest.mark.asyncio
    async def test_concurrent_failures_counted_correctly(self):
        """Test that concurrent failures are counted correctly."""
        cb = CircuitBreaker(failure_threshold=5)

        async def failing_func():
            await asyncio.sleep(0.01)
            raise ValueError("Fail")

        # Launch concurrent failing calls
        results = await asyncio.gather(
            *[cb.call(failing_func) for _ in range(5)], return_exceptions=True
        )

        # All should have failed
        assert all(isinstance(r, ValueError) for r in results)

        # Circuit should be open
        assert cb.state == CircuitState.OPEN


class TestCircuitBreakerEdgeCases:
    """Tests for edge cases."""

    @pytest.mark.asyncio
    async def test_very_short_timeout(self):
        """Test circuit breaker with very short timeout."""
        cb = CircuitBreaker(failure_threshold=1, timeout=0.01)

        async def failing_func():
            raise ValueError("Fail")

        # Open circuit
        with pytest.raises(ValueError):
            await cb.call(failing_func)

        # Wait for timeout
        await asyncio.sleep(0.02)

        # Should transition to half-open
        with pytest.raises(ValueError):
            await cb.call(failing_func)

    @pytest.mark.asyncio
    async def test_success_threshold_greater_than_one(self):
        """Test with success threshold > 1."""
        cb = CircuitBreaker(failure_threshold=2, success_threshold=3, timeout=0.1)

        async def func(should_fail):
            if should_fail:
                raise ValueError("Fail")
            return "success"

        # Open circuit
        for _ in range(2):
            with pytest.raises(ValueError):
                await cb.call(func, True)

        # Wait for timeout
        await asyncio.sleep(0.15)

        # Need 3 successes to close
        for _ in range(3):
            await cb.call(func, False)

        assert cb.state == CircuitState.CLOSED
