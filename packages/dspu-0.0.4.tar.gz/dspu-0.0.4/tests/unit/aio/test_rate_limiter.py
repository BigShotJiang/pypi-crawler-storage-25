"""Tests for rate limiter utilities."""

import asyncio
import time

import pytest

from dspu.aio import RateLimiter, rate_limit


class TestRateLimiterBasics:
    """Tests for basic RateLimiter functionality."""

    @pytest.mark.asyncio
    async def test_initialization(self):
        """Test rate limiter initialization."""
        limiter = RateLimiter(rate=10.0)
        assert limiter.rate == 10.0
        assert limiter.capacity == 10.0
        assert limiter.tokens == 10.0

    @pytest.mark.asyncio
    async def test_custom_capacity(self):
        """Test initialization with custom capacity."""
        limiter = RateLimiter(rate=10.0, capacity=20.0)
        assert limiter.rate == 10.0
        assert limiter.capacity == 20.0
        assert limiter.tokens == 20.0

    def test_invalid_rate(self):
        """Test that negative or zero rate raises error."""
        with pytest.raises(ValueError, match="Rate must be positive"):
            RateLimiter(rate=0.0)

        with pytest.raises(ValueError, match="Rate must be positive"):
            RateLimiter(rate=-1.0)


class TestRateLimiterAcquire:
    """Tests for token acquisition."""

    @pytest.mark.asyncio
    async def test_acquire_single_token(self):
        """Test acquiring a single token."""
        limiter = RateLimiter(rate=100.0)  # High rate for quick test
        await limiter.acquire(1.0)
        # Should succeed immediately
        assert limiter.tokens < limiter.capacity

    @pytest.mark.asyncio
    async def test_acquire_multiple_tokens(self):
        """Test acquiring multiple tokens at once."""
        limiter = RateLimiter(rate=100.0, capacity=10.0)
        await limiter.acquire(5.0)
        assert limiter.tokens <= 5.0

    @pytest.mark.asyncio
    async def test_acquire_waits_for_tokens(self):
        """Test that acquire waits when tokens not available."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        # Exhaust tokens
        await limiter.acquire(5.0)

        # Next acquire should wait
        start = time.monotonic()
        await limiter.acquire(2.0)
        elapsed = time.monotonic() - start

        # Should have waited ~0.2 seconds (2 tokens / 10 tokens per second)
        assert elapsed >= 0.15  # Allow some margin

    @pytest.mark.asyncio
    async def test_acquire_invalid_tokens(self):
        """Test that invalid token amounts raise errors."""
        limiter = RateLimiter(rate=10.0)

        with pytest.raises(ValueError, match="Tokens must be positive"):
            await limiter.acquire(0.0)

        with pytest.raises(ValueError, match="Tokens must be positive"):
            await limiter.acquire(-1.0)

    @pytest.mark.asyncio
    async def test_acquire_exceeds_capacity(self):
        """Test that requesting more than capacity raises error."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        with pytest.raises(ValueError, match="exceeds capacity"):
            await limiter.acquire(10.0)


class TestRateLimiterTryAcquire:
    """Tests for non-blocking token acquisition."""

    @pytest.mark.asyncio
    async def test_try_acquire_success(self):
        """Test successful try_acquire."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)
        result = await limiter.try_acquire(2.0)
        assert result is True
        assert limiter.tokens <= 3.0

    @pytest.mark.asyncio
    async def test_try_acquire_failure(self):
        """Test try_acquire returns False when tokens unavailable."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        # Exhaust tokens
        await limiter.acquire(5.0)

        # Try to acquire more should fail
        result = await limiter.try_acquire(1.0)
        assert result is False

    @pytest.mark.asyncio
    async def test_try_acquire_invalid_tokens(self):
        """Test try_acquire with invalid tokens."""
        limiter = RateLimiter(rate=10.0)

        with pytest.raises(ValueError, match="Tokens must be positive"):
            await limiter.try_acquire(0.0)


class TestRateLimiterContextManager:
    """Tests for context manager interface."""

    @pytest.mark.asyncio
    async def test_context_manager_basic(self):
        """Test basic context manager usage."""
        limiter = RateLimiter(rate=100.0)

        async with limiter.limit():
            # Operation protected by rate limiter
            pass

        # Tokens should have been consumed
        assert limiter.tokens < limiter.capacity

    @pytest.mark.asyncio
    async def test_context_manager_custom_tokens(self):
        """Test context manager with custom token amount."""
        limiter = RateLimiter(rate=100.0, capacity=10.0)

        async with limiter.limit(tokens=5.0):
            pass

        assert limiter.tokens <= 5.0

    @pytest.mark.asyncio
    async def test_context_manager_exception_handling(self):
        """Test that context manager handles exceptions properly."""
        limiter = RateLimiter(rate=100.0)

        with pytest.raises(ValueError):
            async with limiter.limit():
                raise ValueError("Test error")

        # Rate limiter should still work after exception
        async with limiter.limit():
            pass


class TestRateLimiterReset:
    """Tests for reset functionality."""

    @pytest.mark.asyncio
    async def test_reset_restores_capacity(self):
        """Test that reset restores full capacity."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        # Consume tokens
        await limiter.acquire(5.0)
        assert limiter.tokens < 1.0

        # Reset
        await limiter.reset()
        assert limiter.tokens == 5.0


class TestRateLimiterTokenRefill:
    """Tests for token refill over time."""

    @pytest.mark.asyncio
    async def test_tokens_refill_over_time(self):
        """Test that tokens refill based on rate."""
        limiter = RateLimiter(rate=10.0, capacity=10.0)

        # Consume all tokens
        await limiter.acquire(10.0)

        # Wait for some tokens to refill (0.2 seconds = 2 tokens at 10/sec)
        await asyncio.sleep(0.2)

        available = await limiter.get_available_tokens()
        assert available >= 1.5  # Should have ~2 tokens (with some margin)

    @pytest.mark.asyncio
    async def test_tokens_capped_at_capacity(self):
        """Test that tokens don't exceed capacity."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        # Wait longer than needed to fill
        await asyncio.sleep(1.0)

        available = await limiter.get_available_tokens()
        assert available <= 5.0


class TestRateLimitDecorator:
    """Tests for @rate_limit decorator."""

    @pytest.mark.asyncio
    async def test_decorator_basic(self):
        """Test basic decorator usage."""
        limiter = RateLimiter(rate=100.0)

        @rate_limit(limiter)
        async def limited_func():
            return "success"

        result = await limited_func()
        assert result == "success"

    @pytest.mark.asyncio
    async def test_decorator_custom_tokens(self):
        """Test decorator with custom token cost."""
        limiter = RateLimiter(rate=100.0, capacity=10.0)

        @rate_limit(limiter, tokens=5.0)
        async def expensive_func():
            return "done"

        await expensive_func()
        assert limiter.tokens <= 5.0

    @pytest.mark.asyncio
    async def test_decorator_with_arguments(self):
        """Test decorator on function with arguments."""
        limiter = RateLimiter(rate=100.0)

        @rate_limit(limiter)
        async def func_with_args(a, b):
            return a + b

        result = await func_with_args(2, 3)
        assert result == 5

    @pytest.mark.asyncio
    async def test_decorator_enforces_rate(self):
        """Test that decorator enforces rate limits."""
        limiter = RateLimiter(rate=5.0, capacity=2.0)

        call_times = []

        @rate_limit(limiter)
        async def limited():
            call_times.append(time.monotonic())

        # Make 3 calls
        await limited()
        await limited()
        await limited()

        # Check that calls were rate limited
        delay1 = call_times[1] - call_times[0]
        delay2 = call_times[2] - call_times[1]

        # At least one call should have been delayed
        assert delay1 > 0.05 or delay2 > 0.05


class TestRateLimiterConcurrency:
    """Tests for concurrent access to rate limiter."""

    @pytest.mark.asyncio
    async def test_concurrent_acquire(self):
        """Test that concurrent acquires are properly serialized."""
        limiter = RateLimiter(rate=20.0, capacity=10.0)

        async def consume():
            await limiter.acquire(1.0)

        # Launch multiple concurrent tasks
        await asyncio.gather(*[consume() for _ in range(15)])

        # All acquires should have completed
        # (some waited for refill)

    @pytest.mark.asyncio
    async def test_fairness_under_contention(self):
        """Test fairness when multiple tasks contend for tokens."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        completed_order = []

        async def task(task_id):
            await limiter.acquire(2.0)
            completed_order.append(task_id)

        # Start tasks concurrently
        await asyncio.gather(*[task(i) for i in range(5)])

        # All tasks should have completed
        assert len(completed_order) == 5
        assert set(completed_order) == {0, 1, 2, 3, 4}


class TestRateLimiterEdgeCases:
    """Tests for edge cases and boundary conditions."""

    @pytest.mark.asyncio
    async def test_fractional_tokens(self):
        """Test that fractional tokens work correctly."""
        limiter = RateLimiter(rate=10.0, capacity=5.0)

        await limiter.acquire(0.5)
        await limiter.acquire(1.5)

        # Allow small margin for floating point precision
        assert limiter.tokens <= 3.01

    @pytest.mark.asyncio
    async def test_very_high_rate(self):
        """Test rate limiter with very high rate."""
        limiter = RateLimiter(rate=1000.0)

        # Should be able to acquire many tokens quickly
        for _ in range(100):
            await limiter.acquire(1.0)

    @pytest.mark.asyncio
    async def test_very_low_rate(self):
        """Test rate limiter with very low rate."""
        limiter = RateLimiter(rate=0.5, capacity=1.0)  # 1 token every 2 seconds

        await limiter.acquire(1.0)

        # Next acquire should wait ~2 seconds
        start = time.monotonic()
        await limiter.acquire(1.0)
        elapsed = time.monotonic() - start

        assert elapsed >= 1.5  # Should wait at least 1.5 seconds
