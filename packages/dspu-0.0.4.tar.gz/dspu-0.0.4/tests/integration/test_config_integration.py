"""Integration tests for configuration module.

These tests demonstrate realistic multi-source configuration scenarios.
"""

from pathlib import Path

import pytest
from pydantic import BaseModel, Field

from dspu.config.config import Config
from dspu.config.sources import DictSource, EnvSource, FileSource


class DatabaseConfig(BaseModel):
    """Database configuration."""

    host: str = "localhost"
    port: int = 5432
    username: str = "postgres"
    password: str = "secret"
    database: str = "myapp"
    pool_size: int = 10


class RedisConfig(BaseModel):
    """Redis configuration."""

    host: str = "localhost"
    port: int = 6379
    db: int = 0


class AppConfig(BaseModel):
    """Application configuration."""

    app_name: str
    debug: bool = False
    log_level: str = "INFO"
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)
    api_key: str | None = None


class TestMultiSourceConfiguration:
    """Test realistic multi-source configuration loading."""

    def test_layered_config_defaults_file_env(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test layered configuration: defaults -> file -> environment.

        This simulates a real-world scenario where:
        1. Application has sensible defaults
        2. Deployment-specific config comes from a file
        3. Secrets and overrides come from environment variables
        """
        # Create a production config file
        prod_config = tmp_path / "production.yaml"
        prod_config.write_text("""
app_name: myapp
debug: false
log_level: WARNING

database:
  host: prod-db.example.com
  port: 5432
  database: production_db
  pool_size: 20

redis:
  host: redis.example.com
  port: 6379
""")

        # Set environment overrides for secrets
        monkeypatch.setenv("APP_DATABASE__PASSWORD", "prod-secret-pass")
        monkeypatch.setenv("APP_API_KEY", "secret-api-key-12345")
        monkeypatch.setenv("APP_DEBUG", "false")

        # Load with priority: defaults -> file -> env
        config = Config.load(
            AppConfig,
            sources=[
                DictSource({}),  # Empty dict means Pydantic defaults apply
                FileSource(prod_config),
                EnvSource(prefix="APP_", separator="__"),
            ],
        )

        # Verify layered configuration
        assert config.app_name == "myapp"  # From file
        assert config.debug is False  # From env
        assert config.log_level == "WARNING"  # From file

        # Database config: mixed sources
        assert config.database.host == "prod-db.example.com"  # From file
        assert config.database.port == 5432  # From file
        assert config.database.password == "prod-secret-pass"  # From env
        assert config.database.pool_size == 20  # From file

        # Redis config: from file
        assert config.redis.host == "redis.example.com"
        assert config.redis.port == 6379

        # API key: from env
        assert config.api_key == "secret-api-key-12345"

    def test_local_development_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test local development configuration pattern.

        Common pattern:
        1. Base configuration in config.yaml
        2. Local overrides in config.local.yaml (git-ignored)
        3. Environment variables for secrets
        """
        # Base configuration
        base_config = tmp_path / "config.yaml"
        base_config.write_text("""
app_name: myapp
debug: false
log_level: INFO

database:
  host: localhost
  port: 5432
  database: myapp
""")

        # Local developer overrides
        local_config = tmp_path / "config.local.yaml"
        local_config.write_text("""
debug: true
log_level: DEBUG

database:
  database: myapp_dev
  pool_size: 5
""")

        # Environment secrets
        monkeypatch.setenv("APP_DATABASE__PASSWORD", "dev-password")

        config = Config.load(
            AppConfig,
            sources=[
                FileSource(base_config),
                FileSource(local_config),
                EnvSource(prefix="APP_", separator="__"),
            ],
        )

        assert config.app_name == "myapp"  # From base
        assert config.debug is True  # Overridden by local
        assert config.log_level == "DEBUG"  # Overridden by local
        assert config.database.host == "localhost"  # From base
        assert config.database.database == "myapp_dev"  # Overridden by local
        assert config.database.pool_size == 5  # From local
        assert config.database.password == "dev-password"  # From env

    def test_optional_config_file(self, tmp_path: Path) -> None:
        """Test configuration with optional files.

        Useful for:
        - Optional local development overrides
        - Optional secrets files
        - Graceful degradation when files don't exist
        """
        # Only create base config
        base_config = tmp_path / "config.yaml"
        base_config.write_text("""
app_name: myapp
debug: false
""")

        # Local config doesn't exist
        local_config = tmp_path / "config.local.yaml"

        # Should load successfully with optional file missing
        config = Config.load(
            AppConfig,
            sources=[
                FileSource(base_config),
                FileSource(local_config, required=False),  # Optional
            ],
        )

        assert config.app_name == "myapp"
        assert config.debug is False
        # Should use defaults for everything else
        assert config.database.host == "localhost"

    def test_multi_format_configuration(self, tmp_path: Path) -> None:
        """Test loading from multiple file formats.

        Real-world scenario: different teams/tools use different formats.
        """
        # Base config in YAML (common for web apps)
        yaml_config = tmp_path / "config.yaml"
        yaml_config.write_text("""
app_name: myapp
debug: false
""")

        # Database config in TOML (popular in Python ecosystem)
        toml_config = tmp_path / "database.toml"
        toml_config.write_text("""
[database]
host = "db.example.com"
port = 5432
database = "prod"
pool_size = 25
""")

        # Secrets in .env file (common for local development)
        # Note: .env files use flat structure, so we need nested keys
        env_file = tmp_path / ".env.production"
        env_file.write_text("""
DATABASE__PASSWORD=secret123
API_KEY=api-key-xyz
""")

        # For .env file, we need to load it and parse with separator
        # First load the file, then use a dict source with proper structure
        from dotenv import dotenv_values

        env_values = dotenv_values(env_file)
        # Parse nested keys manually for this example
        secrets = {
            "database": {"password": env_values.get("DATABASE__PASSWORD", "")},
            "api_key": env_values.get("API_KEY"),
        }

        config = Config.load(
            AppConfig,
            sources=[
                FileSource(yaml_config),
                FileSource(toml_config),
                DictSource(secrets),  # Structured secrets
            ],
        )

        assert config.app_name == "myapp"  # From YAML
        assert config.database.host == "db.example.com"  # From TOML
        assert config.database.password == "secret123"  # From secrets
        assert config.api_key == "api-key-xyz"  # From secrets

    def test_environment_specific_configuration(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test environment-specific configuration loading.

        Pattern: Load different config files based on environment.
        """
        # Shared defaults
        defaults = tmp_path / "config.yaml"
        defaults.write_text("""
app_name: myapp
log_level: INFO

database:
  port: 5432
  pool_size: 10
""")

        # Production config
        prod_config = tmp_path / "config.production.yaml"
        prod_config.write_text("""
debug: false
log_level: WARNING

database:
  host: prod-db.example.com
  database: production_db
  pool_size: 50
""")

        # Staging config
        staging_config = tmp_path / "config.staging.yaml"
        staging_config.write_text("""
debug: true
log_level: DEBUG

database:
  host: staging-db.example.com
  database: staging_db
  pool_size: 20
""")

        # Simulate production environment
        monkeypatch.setenv("ENV", "production")

        # Load production configuration
        env = "production"
        config = Config.load(
            AppConfig,
            sources=[
                FileSource(defaults),
                FileSource(tmp_path / f"config.{env}.yaml"),
            ],
        )

        assert config.debug is False
        assert config.log_level == "WARNING"
        assert config.database.host == "prod-db.example.com"
        assert config.database.pool_size == 50

    def test_docker_compose_style_env_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test Docker Compose style environment variables.

        Common in containerized deployments.
        """
        # Set Docker Compose style env vars
        monkeypatch.setenv("MYAPP_APP_NAME", "containerized-app")
        monkeypatch.setenv("MYAPP_DEBUG", "true")
        monkeypatch.setenv("MYAPP_DATABASE__HOST", "db")
        monkeypatch.setenv("MYAPP_DATABASE__PORT", "5432")
        monkeypatch.setenv("MYAPP_DATABASE__USERNAME", "app")
        monkeypatch.setenv("MYAPP_DATABASE__PASSWORD", "apppass")
        monkeypatch.setenv("MYAPP_DATABASE__DATABASE", "appdb")
        monkeypatch.setenv("MYAPP_REDIS__HOST", "redis")
        monkeypatch.setenv("MYAPP_REDIS__PORT", "6379")

        config = Config.load(
            AppConfig,
            sources=[
                EnvSource(prefix="MYAPP_", separator="__"),
            ],
        )

        assert config.app_name == "containerized-app"
        assert config.debug is True
        assert config.database.host == "db"
        assert config.database.port == 5432
        assert config.database.username == "app"
        assert config.database.password == "apppass"
        assert config.database.database == "appdb"
        assert config.redis.host == "redis"
        assert config.redis.port == 6379

    def test_kubernetes_configmap_and_secrets(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test Kubernetes ConfigMap and Secrets pattern.

        In Kubernetes:
        - ConfigMaps are mounted as files
        - Secrets are mounted as files or env vars
        """
        # Simulate ConfigMap mounted as file
        configmap_dir = tmp_path / "config"
        configmap_dir.mkdir()
        (configmap_dir / "app-config.yaml").write_text("""
app_name: k8s-app
debug: false
log_level: INFO

database:
  host: postgres-service
  port: 5432
  database: production
""")

        # Simulate Secret mounted as env vars
        # For nested fields, use double underscore separator
        monkeypatch.setenv("DATABASE__PASSWORD", "k8s-secret-password")
        monkeypatch.setenv("API_KEY", "k8s-api-key")

        config = Config.load(
            AppConfig,
            sources=[
                FileSource(configmap_dir / "app-config.yaml"),
                EnvSource(prefix="", separator="__"),  # Use separator for nested keys
            ],
        )

        assert config.app_name == "k8s-app"
        assert config.database.host == "postgres-service"
        assert config.database.password == "k8s-secret-password"
        assert config.api_key == "k8s-api-key"


class TestConfigurationValidation:
    """Test configuration validation in realistic scenarios."""

    def test_missing_required_field_with_helpful_error(self, tmp_path: Path) -> None:
        """Test that validation errors are helpful for debugging."""
        config_file = tmp_path / "incomplete.yaml"
        config_file.write_text("""
debug: true
log_level: DEBUG
""")

        from dspu.core.exceptions import ValidationError

        with pytest.raises(ValidationError) as exc_info:
            Config.load_from_file(AppConfig, str(config_file))

        # Error should mention the missing field
        assert "app_name" in str(exc_info.value)
        assert exc_info.value.field == "app_name"

    def test_invalid_port_validation(self, tmp_path: Path) -> None:
        """Test validation of constrained fields."""

        class ServerConfig(BaseModel):
            app_name: str
            port: int = Field(ge=1, le=65535)

        config_file = tmp_path / "invalid.yaml"
        config_file.write_text("""
app_name: myapp
port: 99999
""")

        from dspu.core.exceptions import ValidationError

        with pytest.raises(ValidationError) as exc_info:
            Config.load_from_file(ServerConfig, str(config_file))

        assert "port" in str(exc_info.value)


class TestConfigurationEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_config_with_all_defaults(self) -> None:
        """Test that empty sources work with default values."""

        class DefaultsConfig(BaseModel):
            value: str = "default"
            number: int = 42
            enabled: bool = True

        config = Config.load(
            DefaultsConfig,
            sources=[DictSource({})],
        )

        assert config.value == "default"
        assert config.number == 42
        assert config.enabled is True

    def test_deep_nested_structure(self, tmp_path: Path) -> None:
        """Test deeply nested configuration structures."""

        class DeepConfig(BaseModel):
            class Level1(BaseModel):
                class Level2(BaseModel):
                    class Level3(BaseModel):
                        value: str = "deep"

                    level3: Level3 = Field(default_factory=Level3)

                level2: Level2 = Field(default_factory=Level2)

            level1: Level1 = Field(default_factory=Level1)

        config_file = tmp_path / "deep.yaml"
        config_file.write_text("""
level1:
  level2:
    level3:
      value: nested
""")

        config = Config.load_from_file(DeepConfig, str(config_file))

        assert config.level1.level2.level3.value == "nested"

    def test_list_values_override_not_merge(self, tmp_path: Path) -> None:
        """Test that lists are replaced, not merged."""

        class ListConfig(BaseModel):
            items: list[str]

        base = tmp_path / "base.yaml"
        base.write_text("""
items:
  - a
  - b
  - c
""")

        override = tmp_path / "override.yaml"
        override.write_text("""
items:
  - x
  - y
""")

        config = Config.load(
            ListConfig,
            sources=[
                FileSource(base),
                FileSource(override),
            ],
        )

        # Should be replaced, not merged
        assert config.items == ["x", "y"]
