"""Integration tests for I/O module."""
