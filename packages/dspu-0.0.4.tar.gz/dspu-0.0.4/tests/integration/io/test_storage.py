"""Integration tests for Storage facade."""

from pathlib import Path

import pytest

from dspu.core.exceptions import ConfigurationError
from dspu.io import Storage
from dspu.io.serializers import SerializationError


class TestStorageInitialization:
    """Test Storage initialization."""

    def test_from_uri_local_absolute(self, tmp_path: Path):
        """Test creating Storage from absolute local path."""
        storage = Storage.from_uri(str(tmp_path))

        assert storage is not None

    def test_from_uri_local_relative(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        """Test creating Storage from relative local path."""
        monkeypatch.chdir(tmp_path)

        storage = Storage.from_uri("./data")

        assert storage is not None

    def test_from_uri_file_scheme(self, tmp_path: Path):
        """Test creating Storage with file:// scheme."""
        storage = Storage.from_uri(f"file://{tmp_path}")

        assert storage is not None

    def test_from_uri_unsupported_scheme(self):
        """Test creating Storage with unsupported scheme."""
        with pytest.raises(ConfigurationError) as exc_info:
            Storage.from_uri("ftp://server/path")

        assert "unsupported" in str(exc_info.value).lower()
        assert "ftp" in str(exc_info.value).lower()

    @pytest.mark.skipif(
        pytest.importorskip("fsspec", reason="fsspec installed"),
        reason="fsspec is installed, test not applicable",
    )
    def test_from_uri_s3_without_fsspec(self):
        """Test S3 URI without fsspec raises helpful error."""
        with pytest.raises(ConfigurationError) as exc_info:
            Storage.from_uri("s3://bucket/path")

        error_msg = str(exc_info.value).lower()
        assert "s3" in error_msg
        assert "fsspec" in error_msg or "s3fs" in error_msg


class TestStorageReadWrite:
    """Test read and write operations."""

    @pytest.mark.asyncio
    async def test_write_and_read_json(self, tmp_path: Path):
        """Test writing and reading JSON data."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"name": "Alice", "age": 30, "active": True}

        await storage.write("config.json", data)
        result = await storage.read("config.json")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_and_read_with_format(self, tmp_path: Path):
        """Test writing and reading with explicit format."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}

        await storage.write("data.txt", data, format="json")
        result = await storage.read("data.txt", format="json")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_and_read_raw_bytes(self, tmp_path: Path):
        """Test writing and reading raw bytes."""
        storage = Storage.from_uri(str(tmp_path))
        data = b"raw binary data \x00\x01\x02"

        await storage.write("file.bin", data, raw=True)
        result = await storage.read("file.bin", raw=True)

        assert result == data

    @pytest.mark.asyncio
    async def test_write_creates_nested_directories(self, tmp_path: Path):
        """Test that write creates nested directories."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"test": "value"}

        await storage.write("nested/deep/config.json", data)
        result = await storage.read("nested/deep/config.json")

        assert result == data

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self, tmp_path: Path):
        """Test reading nonexistent file."""
        storage = Storage.from_uri(str(tmp_path))

        with pytest.raises(FileNotFoundError):
            await storage.read("nonexistent.json")

    @pytest.mark.asyncio
    async def test_write_raw_requires_bytes(self, tmp_path: Path):
        """Test that write with raw=True requires bytes."""
        storage = Storage.from_uri(str(tmp_path))

        with pytest.raises(TypeError) as exc_info:
            await storage.write("file.bin", "not bytes", raw=True)

        assert "bytes" in str(exc_info.value).lower()


class TestStorageExists:
    """Test exists operation."""

    @pytest.mark.asyncio
    async def test_exists_for_existing_file(self, tmp_path: Path):
        """Test exists returns True for existing file."""
        storage = Storage.from_uri(str(tmp_path))
        await storage.write("test.json", {"data": "value"})

        result = await storage.exists("test.json")

        assert result is True

    @pytest.mark.asyncio
    async def test_exists_for_nonexistent_file(self, tmp_path: Path):
        """Test exists returns False for nonexistent file."""
        storage = Storage.from_uri(str(tmp_path))

        result = await storage.exists("nonexistent.json")

        assert result is False


class TestStorageDelete:
    """Test delete operation."""

    @pytest.mark.asyncio
    async def test_delete_file(self, tmp_path: Path):
        """Test deleting a file."""
        storage = Storage.from_uri(str(tmp_path))
        await storage.write("test.json", {"data": "value"})

        await storage.delete("test.json")

        assert not await storage.exists("test.json")

    @pytest.mark.asyncio
    async def test_delete_nonexistent_file(self, tmp_path: Path):
        """Test deleting nonexistent file."""
        storage = Storage.from_uri(str(tmp_path))

        with pytest.raises(FileNotFoundError):
            await storage.delete("nonexistent.json")


class TestStorageList:
    """Test list operation."""

    @pytest.mark.asyncio
    async def test_list_files(self, tmp_path: Path):
        """Test listing files."""
        storage = Storage.from_uri(str(tmp_path))
        await storage.write("file1.json", {"a": 1})
        await storage.write("file2.json", {"b": 2})
        await storage.write("data.txt", b"text", raw=True)

        files = await storage.list("*.json")

        paths = [f.path for f in files]
        assert "file1.json" in paths
        assert "file2.json" in paths
        assert "data.txt" not in paths

    @pytest.mark.asyncio
    async def test_list_all_files(self, tmp_path: Path):
        """Test listing all files."""
        storage = Storage.from_uri(str(tmp_path))
        await storage.write("file1.json", {"a": 1})
        await storage.write("file2.txt", b"text", raw=True)

        files = await storage.list()

        assert len(files) >= 2

    @pytest.mark.asyncio
    async def test_list_includes_file_info(self, tmp_path: Path):
        """Test that list returns FileInfo with metadata."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}
        await storage.write("test.json", data)

        files = await storage.list("test.json")

        assert len(files) == 1
        info = files[0]
        assert info.path == "test.json"
        assert info.size > 0
        assert info.modified is not None


class TestStorageStreaming:
    """Test streaming operations."""

    @pytest.mark.asyncio
    async def test_read_stream(self, tmp_path: Path):
        """Test reading file as stream."""
        storage = Storage.from_uri(str(tmp_path))
        data = b"a" * 10000  # 10KB
        await storage.write("large.bin", data, raw=True)

        chunks = []
        async for chunk in storage.read_stream("large.bin"):
            chunks.append(chunk)

        assert b"".join(chunks) == data

    @pytest.mark.asyncio
    async def test_write_stream(self, tmp_path: Path):
        """Test writing file from stream."""
        storage = Storage.from_uri(str(tmp_path))

        async def data_generator():
            for i in range(100):
                yield f"line {i}\n".encode()

        await storage.write_stream("output.txt", data_generator())

        result = await storage.read("output.txt", raw=True)
        assert b"line 0\n" in result
        assert b"line 99\n" in result


class TestStorageFormatAutoDetection:
    """Test automatic format detection."""

    @pytest.mark.asyncio
    async def test_json_format_auto_detected(self, tmp_path: Path):
        """Test JSON format is auto-detected from .json extension."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}

        await storage.write("test.json", data)
        result = await storage.read("test.json")

        assert result == data

    @pytest.mark.asyncio
    async def test_pickle_format_auto_detected(self, tmp_path: Path):
        """Test Pickle format is auto-detected from .pkl extension."""
        import warnings

        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            await storage.write("test.pkl", data)
            result = await storage.read("test.pkl")

        assert result == data

    @pytest.mark.asyncio
    @pytest.mark.skipif(
        not pytest.importorskip("msgpack", reason="msgpack not installed"),
        reason="msgpack not installed",
    )
    async def test_msgpack_format_auto_detected(self, tmp_path: Path):
        """Test MessagePack format is auto-detected."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}

        await storage.write("test.msgpack", data)
        result = await storage.read("test.msgpack")

        assert result == data


class TestStorageComplexData:
    """Test Storage with complex data types."""

    @pytest.mark.asyncio
    async def test_nested_structures(self, tmp_path: Path):
        """Test storing nested data structures."""
        storage = Storage.from_uri(str(tmp_path))
        data = {
            "users": [
                {"name": "Alice", "age": 30, "active": True},
                {"name": "Bob", "age": 25, "active": False},
            ],
            "metadata": {
                "version": "1.0",
                "created": "2024-01-01",
            },
        }

        await storage.write("users.json", data)
        result = await storage.read("users.json")

        assert result == data

    @pytest.mark.asyncio
    async def test_unicode_data(self, tmp_path: Path):
        """Test storing Unicode strings."""
        storage = Storage.from_uri(str(tmp_path))
        data = {
            "emoji": "😀🎉",
            "chinese": "你好世界",
            "arabic": "مرحبا بك",
            "mixed": "Hello 世界 🌍",
        }

        await storage.write("unicode.json", data)
        result = await storage.read("unicode.json")

        assert result == data

    @pytest.mark.asyncio
    async def test_large_data(self, tmp_path: Path):
        """Test storing large data structures."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"values": list(range(10000))}

        await storage.write("large.json", data)
        result = await storage.read("large.json")

        assert result == data


class TestStorageErrorHandling:
    """Test error handling."""

    @pytest.mark.asyncio
    async def test_invalid_json_in_file(self, tmp_path: Path):
        """Test reading file with invalid JSON."""
        storage = Storage.from_uri(str(tmp_path))
        (tmp_path / "invalid.json").write_text("{invalid json}")

        with pytest.raises(SerializationError):
            await storage.read("invalid.json")

    @pytest.mark.asyncio
    async def test_unknown_format_raises_error(self, tmp_path: Path):
        """Test reading file with unknown format."""
        storage = Storage.from_uri(str(tmp_path))
        await storage.write("file.xyz", b"data", raw=True)

        with pytest.raises(SerializationError):
            await storage.read("file.xyz")


class TestStorageDocumentation:
    """Test that Storage is properly documented."""

    def test_storage_has_docstring(self):
        """Test Storage has documentation."""
        assert Storage.__doc__ is not None
        assert len(Storage.__doc__) > 100

    def test_from_uri_has_docstring(self):
        """Test from_uri has documentation."""
        assert Storage.from_uri.__doc__ is not None

    def test_read_has_docstring(self):
        """Test read has documentation."""
        assert Storage.read.__doc__ is not None

    def test_write_has_docstring(self):
        """Test write has documentation."""
        assert Storage.write.__doc__ is not None
