"""Integration tests for Storage with format system."""

from pathlib import Path

import pytest

from dspu.io import FormatError, Storage


class TestStorageFormatIntegration:
    """Integration tests for Storage.write_format() and read_format()."""

    @pytest.mark.asyncio
    async def test_write_read_json(self, tmp_path: Path):
        """Test writing and reading JSON format."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"name": "Alice", "age": 30, "active": True}

        await storage.write_format("config.json", data)
        result = await storage.read_format("config.json")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_read_yaml(self, tmp_path: Path):
        """Test writing and reading YAML format."""
        pytest.importorskip("yaml")

        storage = Storage.from_uri(str(tmp_path))
        data = {
            "database": {"host": "localhost", "port": 5432},
            "debug": True,
        }

        await storage.write_format("config.yaml", data)
        result = await storage.read_format("config.yaml")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_read_toml(self, tmp_path: Path):
        """Test writing and reading TOML format."""
        pytest.importorskip("tomli_w")
        pytest.importorskip("tomllib", "tomli")

        storage = Storage.from_uri(str(tmp_path))
        data = {
            "database": {"host": "localhost", "port": 5432},
            "debug": True,
        }

        await storage.write_format("config.toml", data)
        result = await storage.read_format("config.toml")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_read_hocon(self, tmp_path: Path):
        """Test writing and reading HOCON format."""
        pytest.importorskip("pyhocon")

        storage = Storage.from_uri(str(tmp_path))
        data = {
            "database": {"host": "localhost", "port": 5432},
            "debug": True,
        }

        await storage.write_format("config.conf", data)
        result = await storage.read_format("config.conf")

        assert result == data

    @pytest.mark.asyncio
    async def test_write_read_text(self, tmp_path: Path):
        """Test writing and reading plain text."""
        storage = Storage.from_uri(str(tmp_path))
        text = "Hello, world!\nThis is a test file."

        await storage.write_format("README.txt", text)
        result = await storage.read_format("README.txt")

        assert result == text

    @pytest.mark.asyncio
    async def test_write_read_markdown(self, tmp_path: Path):
        """Test writing and reading Markdown."""
        storage = Storage.from_uri(str(tmp_path))
        markdown = """# My Project

This is a **test** document with *markdown* formatting.

## Features

- Feature 1
- Feature 2
"""

        await storage.write_format("README.md", markdown)
        result = await storage.read_format("README.md")

        assert result == markdown

    @pytest.mark.asyncio
    async def test_write_read_python(self, tmp_path: Path):
        """Test writing and reading Python code."""
        storage = Storage.from_uri(str(tmp_path))
        code = '''def hello(name: str) -> str:
    """Greet someone."""
    return f"Hello, {name}!"
'''

        await storage.write_format("utils.py", code)
        result = await storage.read_format("utils.py")

        assert result == code

    @pytest.mark.asyncio
    async def test_write_read_env(self, tmp_path: Path):
        """Test writing and reading .env file."""
        pytest.importorskip("dotenv")

        storage = Storage.from_uri(str(tmp_path))
        env_vars = {
            "DATABASE_URL": "postgresql://localhost/db",
            "SECRET_KEY": "abc123",
            "DEBUG": "true",
        }

        await storage.write_format(".env", env_vars)
        result = await storage.read_format(".env")

        assert result == env_vars

    @pytest.mark.asyncio
    async def test_write_read_csv(self, tmp_path: Path):
        """Test writing and reading CSV file."""
        storage = Storage.from_uri(str(tmp_path))
        data = [
            {"name": "Alice", "age": "30", "city": "NYC"},
            {"name": "Bob", "age": "25", "city": "LA"},
        ]

        await storage.write_format("users.csv", data)
        result = await storage.read_format("users.csv")

        assert result == data

    @pytest.mark.asyncio
    async def test_format_auto_detection(self, tmp_path: Path):
        """Test format is auto-detected from extension."""
        pytest.importorskip("yaml")

        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}

        # Write YAML without specifying format
        await storage.write_format("config.yaml", data)

        # Read YAML without specifying format
        result = await storage.read_format("config.yaml")

        assert result == data

    @pytest.mark.asyncio
    async def test_explicit_format_override(self, tmp_path: Path):
        """Test explicitly specifying format overrides extension."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"key": "value"}

        # Write as JSON even though extension is .txt
        await storage.write_format("data.txt", data, format="json")

        # Read as JSON
        result = await storage.read_format("data.txt", format="json")

        assert result == data

    @pytest.mark.asyncio
    async def test_format_options_json_indent(self, tmp_path: Path):
        """Test passing format options (JSON indent)."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"nested": {"key": "value"}}

        await storage.write_format(
            "config.json",
            data,
            format_options={"indent": 4},
        )

        # Read raw bytes to check formatting
        file_path = tmp_path / "config.json"
        content = file_path.read_text()

        # Should have indentation
        assert "\n" in content
        assert "    " in content  # 4 spaces

    @pytest.mark.asyncio
    async def test_format_options_json_sorted(self, tmp_path: Path):
        """Test passing format options (JSON sorted keys)."""
        storage = Storage.from_uri(str(tmp_path))
        data = {"zebra": 1, "apple": 2, "banana": 3}

        await storage.write_format(
            "config.json",
            data,
            format_options={"sort_keys": True},
        )

        # Read raw content
        file_path = tmp_path / "config.json"
        content = file_path.read_text()

        # apple should come before zebra
        apple_pos = content.find("apple")
        zebra_pos = content.find("zebra")
        assert apple_pos < zebra_pos

    @pytest.mark.asyncio
    async def test_format_options_csv_delimiter(self, tmp_path: Path):
        """Test passing format options (CSV delimiter)."""
        storage = Storage.from_uri(str(tmp_path))
        data = [["a", "b"], ["c", "d"]]

        await storage.write_format(
            "data.csv",
            data,
            format_options={"delimiter": ";"},
        )

        # Read raw content
        file_path = tmp_path / "data.csv"
        content = file_path.read_text()

        # Should use semicolon
        assert ";" in content

    @pytest.mark.asyncio
    async def test_format_options_csv_no_header(self, tmp_path: Path):
        """Test passing format options (CSV no header)."""
        storage = Storage.from_uri(str(tmp_path))
        data = [{"name": "Alice", "age": "30"}]

        await storage.write_format(
            "data.csv",
            data,
            format_options={"header": False},
        )

        # Read raw content
        file_path = tmp_path / "data.csv"
        lines = file_path.read_text().strip().split("\n")

        # Should have only 1 line (no header)
        assert len(lines) == 1

    @pytest.mark.asyncio
    async def test_write_wrong_type_fails(self, tmp_path: Path):
        """Test writing wrong data type raises error."""
        storage = Storage.from_uri(str(tmp_path))

        # Try to write string to YAML (requires dict or list)
        with pytest.raises(FormatError):
            await storage.write_format("config.yaml", "plain string")

    @pytest.mark.asyncio
    async def test_write_list_to_toml_fails(self, tmp_path: Path):
        """Test writing list to TOML raises error (TOML requires dict)."""
        pytest.importorskip("tomli_w")

        storage = Storage.from_uri(str(tmp_path))

        with pytest.raises(FormatError):
            await storage.write_format("config.toml", [1, 2, 3])

    @pytest.mark.asyncio
    async def test_no_extension_fails(self, tmp_path: Path):
        """Test file without extension raises error."""
        storage = Storage.from_uri(str(tmp_path))

        with pytest.raises(FormatError):
            await storage.write_format("noextension", {"key": "value"})

    @pytest.mark.asyncio
    async def test_unsupported_extension_fails(self, tmp_path: Path):
        """Test unsupported extension raises error."""
        storage = Storage.from_uri(str(tmp_path))

        with pytest.raises(FormatError):
            await storage.write_format("data.xyz", {"key": "value"})

    @pytest.mark.asyncio
    async def test_multiple_formats_same_data(self, tmp_path: Path):
        """Test writing same data to multiple formats."""
        pytest.importorskip("yaml")
        pytest.importorskip("tomli_w")

        storage = Storage.from_uri(str(tmp_path))
        data = {"name": "Alice", "age": 30}

        # Write to multiple formats
        await storage.write_format("config.json", data)
        await storage.write_format("config.yaml", data)
        await storage.write_format("config.toml", data)

        # Read back from all formats
        json_result = await storage.read_format("config.json")
        yaml_result = await storage.read_format("config.yaml")
        toml_result = await storage.read_format("config.toml")

        # All should have same data
        assert json_result == data
        assert yaml_result == data
        assert toml_result == data

    @pytest.mark.asyncio
    async def test_complex_nested_structure(self, tmp_path: Path):
        """Test writing complex nested structures."""
        pytest.importorskip("yaml")

        storage = Storage.from_uri(str(tmp_path))
        data = {
            "app": {
                "name": "MyApp",
                "version": "1.0.0",
                "config": {
                    "database": {
                        "primary": {
                            "host": "localhost",
                            "port": 5432,
                        },
                        "replica": {
                            "host": "replica.local",
                            "port": 5432,
                        },
                    },
                    "cache": {
                        "enabled": True,
                        "ttl": 300,
                    },
                },
                "features": ["auth", "api", "admin"],
            },
        }

        await storage.write_format("complex.yaml", data)
        result = await storage.read_format("complex.yaml")

        assert result == data

    @pytest.mark.asyncio
    async def test_unicode_in_formats(self, tmp_path: Path):
        """Test unicode characters in various formats."""
        pytest.importorskip("yaml")

        storage = Storage.from_uri(str(tmp_path))
        data = {
            "greeting": "Hello 世界 🌍",
            "name": "José",
            "city": "São Paulo",
        }

        # Test JSON
        await storage.write_format("unicode.json", data)
        json_result = await storage.read_format("unicode.json")
        assert json_result == data

        # Test YAML
        await storage.write_format("unicode.yaml", data)
        yaml_result = await storage.read_format("unicode.yaml")
        assert yaml_result == data
