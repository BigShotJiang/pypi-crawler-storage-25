"""Pytest configuration and shared fixtures."""

from pathlib import Path
from typing import Any

import pytest


@pytest.fixture
def sample_config_dict() -> dict[str, Any]:
    """Sample configuration dictionary for testing."""
    return {
        "app_name": "test-app",
        "debug": True,
        "max_workers": 4,
        "timeout": 30,
    }


@pytest.fixture
def sample_yaml_config(tmp_path: Path) -> Path:
    """Create a sample YAML config file."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text("""
app_name: test-app
debug: true
max_workers: 4
timeout: 30
""")
    return config_path


@pytest.fixture
def sample_json_data() -> dict[str, Any]:
    """Sample JSON data for testing."""
    return {
        "id": "123",
        "name": "Test Item",
        "values": [1, 2, 3, 4, 5],
        "metadata": {
            "created": "2024-01-01",
            "updated": "2024-01-02",
        },
    }
