# Contributing to DSPU

Thank you for your interest in contributing to DSPU! This document provides guidelines and instructions for contributing.

## Code of Conduct

By participating in this project, you agree to maintain a respectful and inclusive environment for everyone.

## Getting Started

### Prerequisites

- Python 3.11 or higher
- UV (recommended) or pip
- Git

### Development Setup

1. **Fork and clone the repository**

```bash
git clone https://github.com/deepsaia/dspu.git
cd dspu
```

2. **Install UV** (if not already installed)

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

3. **Create a virtual environment and install dependencies**

```bash
uv sync --all-extras
```

4. **Install pre-commit hooks**

```bash
uv run pre-commit install
```

5. **Verify the setup**

```bash
uv run pytest
uv run ruff check .
uv run pyrefly check src/dspu
```

## Development Workflow

### 1. Create a Feature Branch

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/your-bug-fix
```

Branch naming conventions:
- `feature/` - New features
- `fix/` - Bug fixes
- `docs/` - Documentation changes
- `refactor/` - Code refactoring
- `test/` - Test additions or modifications

### 2. Make Your Changes

- Write clean, readable code
- Follow the existing code style
- Add type hints to all functions
- Write docstrings for public APIs
- Add tests for new functionality

### 3. Run Tests and Linting

```bash
# Run tests
uv run pytest

# Run tests with coverage
uv run pytest --cov=dspu --cov-report=term-missing

# Lint and format
uv run ruff check . --fix
uv run ruff format .

# Type check
uv run pyrefly check src/dspu

# Run all pre-commit hooks
uv run pre-commit run --all-files
```

### 4. Commit Your Changes

Write clear, descriptive commit messages:

```bash
git add .
git commit -m "feat: add retry mechanism to async module"
```

Commit message conventions:
- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation changes
- `test:` - Test changes
- `refactor:` - Code refactoring
- `chore:` - Maintenance tasks

### 5. Push and Create a Pull Request

```bash
git push origin feature/your-feature-name
```

Then open a Pull Request on GitHub with:
- Clear title and description
- Reference to any related issues
- Description of changes made
- Testing performed

## Code Style Guide

### Python Style

We use **Ruff** for linting and formatting, which enforces:
- Line length: 100 characters
- PEP 8 compliance
- Import sorting
- Type hints for all functions

### Type Hints

All functions must have complete type hints:

```python
from typing import Optional

def process_data(
    data: list[dict[str, Any]],
    filter_empty: bool = True
) -> list[dict[str, Any]]:
    """Process data with optional filtering.

    Args:
        data: Input data to process
        filter_empty: Whether to filter empty entries

    Returns:
        Processed data list
    """
    ...
```

### Docstrings

Use Google-style docstrings:

```python
def fetch_data(url: str, timeout: int = 30) -> dict[str, Any]:
    """Fetch data from a URL.

    Args:
        url: The URL to fetch from
        timeout: Request timeout in seconds

    Returns:
        Parsed JSON response

    Raises:
        TimeoutError: If request times out
        ValueError: If URL is invalid
    """
    ...
```

### Async Functions

Always use type hints with async functions:

```python
async def fetch_user(user_id: str) -> User:
    """Fetch user by ID."""
    ...
```

## Testing Guidelines

### Test Structure

```
tests/
├── unit/          # Unit tests (fast, isolated)
├── integration/   # Integration tests
├── property/      # Property-based tests (hypothesis)
└── fixtures/      # Shared test fixtures
```

### Writing Tests

```python
import pytest
from dspu.config import Config

class TestConfig:
    """Test suite for Config class."""

    def test_load_from_dict(self) -> None:
        """Test loading config from dictionary."""
        config = Config.load_from_dict({"key": "value"})
        assert config.key == "value"

    @pytest.mark.asyncio
    async def test_async_operation(self) -> None:
        """Test async configuration loading."""
        config = await load_async_config()
        assert config is not None
```

### Test Coverage

- Aim for >90% code coverage
- Test edge cases and error conditions
- Use property-based testing for complex logic
- Mock external dependencies

## Documentation

### Module Documentation

Each module should have a docstring explaining its purpose:

```python
"""Configuration management module.

This module provides type-safe configuration loading from multiple sources
including files, environment variables, and secret managers.
"""
```

### Updating Documentation

- Update `docs/design.md` for architectural changes
- Update `docs/plan.md` checkboxes as you complete tasks
- Add examples to `examples/` directory
- Update README.md if adding new features

## Pull Request Process

1. **Update tests** - Ensure all tests pass and add new tests for new features
2. **Update documentation** - Add or update docstrings and docs
3. **Run linting** - Ensure code passes all checks
4. **Update CHANGELOG** - Add entry describing your changes (if applicable)
5. **Request review** - Tag relevant reviewers

### Pull Request Checklist

- [ ] Tests added/updated and passing
- [ ] Documentation updated
- [ ] Code passes linting (`ruff check`)
- [ ] Code passes type checking (`pyrefly`)
- [ ] Commit messages follow conventions
- [ ] PR description is clear and complete
- [ ] Related issues are referenced

## Module-Specific Guidelines

### Core Module

- Keep protocols simple and focused
- Avoid dependencies on other modules
- Document all type definitions

### Config Module

- Use Pydantic for validation
- Support multiple source types
- Provide clear error messages

### I/O Module

- Support both sync and async
- Handle errors gracefully
- Add backend tests with mocks

### Async Module

- Use `anyio` for async abstractions
- Provide both decorators and context managers
- Test with property-based testing

### Security Module

- Never log secrets
- Use secure defaults
- Add security warnings in docstrings

## Release Process

Maintainers only:

1. Update version in `pyproject.toml`
2. Update CHANGELOG.md
3. Create git tag
4. Build package: `uv build`
5. Publish to PyPI: `uv publish`

## Getting Help

- **Questions**: Open a Discussion on GitHub
- **Bugs**: Open an Issue with detailed reproduction steps
- **Features**: Open an Issue describing the use case
- **Chat**: Join our community (link TBD)

## Recognition

Contributors will be recognized in:
- CHANGELOG.md for their contributions
- GitHub contributors page
- Release notes for significant contributions

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0.

---

Thank you for contributing to DSPU! Your efforts help make data science workflows better for everyone.
