"""Core abstractions and protocols.

This module provides core types, protocols, and exceptions used throughout
the library.

Example:
    >>> from dspu.core.exceptions import ConfigurationError, ValidationError
    >>>
    >>> raise ConfigurationError(
    ...     "Invalid database URL",
    ...     field="database_url",
    ...     suggestion="Use format: postgresql://user:pass@host:port/db",
    ... )
"""

from dspu.core.exceptions import (
    ConfigurationError,
    DSPUError,
    DSPUIOError,
    SecurityError,
    ValidationError,
)

__all__ = [
    "ConfigurationError",
    "DSPUError",
    "DSPUIOError",
    "SecurityError",
    "ValidationError",
]
