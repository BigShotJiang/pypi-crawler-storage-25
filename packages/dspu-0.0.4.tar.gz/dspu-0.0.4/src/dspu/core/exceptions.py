"""Core exceptions for DSPU.

This module defines the exception hierarchy used throughout the library.
All exceptions include helpful context and suggestions when possible.
"""


class DSPUError(Exception):
    """Base exception for all DSPU errors.

    All exceptions in the library inherit from this base class,
    making it easy to catch any DSPU specific error.

    Example:
        >>> try:
        ...     # Some DSPU operation
        ...     pass
        ... except DSPUError as e:
        ...     print(f"DSPU error: {e}")
    """

    pass


class ConfigurationError(DSPUError):
    """Raised when configuration is invalid or missing.

    This exception includes optional field and suggestion information
    to help users fix configuration issues quickly.

    Attributes:
        field: The configuration field that caused the error (if applicable).
        suggestion: A helpful suggestion for fixing the error.

    Example:
        >>> raise ConfigurationError(
        ...     "Invalid database URL",
        ...     field="database_url",
        ...     suggestion="Use format: postgresql://user:pass@host:port/db"
        ... )
    """

    def __init__(
        self,
        message: str,
        *,
        field: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        """Initialize configuration error.

        Args:
            message: Error message describing the problem.
            field: The configuration field that caused the error.
            suggestion: A helpful suggestion for fixing the error.
        """
        super().__init__(message)
        self.field = field
        self.suggestion = suggestion

    def __str__(self) -> str:
        """Format error message with field and suggestion."""
        parts = [super().__str__()]

        if self.field:
            parts.append(f"Field: {self.field}")

        if self.suggestion:
            parts.append(f"Suggestion: {self.suggestion}")

        return "\n".join(parts)


class ValidationError(DSPUError):
    """Raised when data validation fails.

    This exception is used for data validation errors, including
    schema validation, type checking, and constraint violations.

    Attributes:
        field: The field that failed validation (if applicable).
        value: The invalid value that caused the error.
        constraint: The constraint that was violated.

    Example:
        >>> raise ValidationError(
        ...     "Value must be positive",
        ...     field="age",
        ...     value=-5,
        ...     constraint="age >= 0"
        ... )
    """

    def __init__(
        self,
        message: str,
        *,
        field: str | None = None,
        value: object = None,
        constraint: str | None = None,
    ) -> None:
        """Initialize validation error.

        Args:
            message: Error message describing the validation failure.
            field: The field that failed validation.
            value: The invalid value.
            constraint: The constraint that was violated.
        """
        super().__init__(message)
        self.field = field
        self.value = value
        self.constraint = constraint

    def __str__(self) -> str:
        """Format error message with validation details."""
        parts = [super().__str__()]

        if self.field:
            parts.append(f"Field: {self.field}")

        if self.value is not None:
            parts.append(f"Value: {self.value!r}")

        if self.constraint:
            parts.append(f"Constraint: {self.constraint}")

        return "\n".join(parts)


class DSPUIOError(DSPUError):
    """Raised when I/O operations fail.

    This exception is used for file system, network, and other I/O errors.

    Attributes:
        path: The path or resource that caused the error.
        operation: The operation that failed (e.g., "read", "write").

    Example:
        >>> raise IOError(
        ...     "Failed to read file",
        ...     path="data/file.json",
        ...     operation="read"
        ... )
    """

    def __init__(
        self,
        message: str,
        *,
        path: str | None = None,
        operation: str | None = None,
    ) -> None:
        """Initialize I/O error.

        Args:
            message: Error message describing the I/O failure.
            path: The path or resource that caused the error.
            operation: The operation that failed.
        """
        super().__init__(message)
        self.path = path
        self.operation = operation

    def __str__(self) -> str:
        """Format error message with I/O details."""
        parts = [super().__str__()]

        if self.operation:
            parts.append(f"Operation: {self.operation}")

        if self.path:
            parts.append(f"Path: {self.path}")

        return "\n".join(parts)


class SecurityError(DSPUError):
    """Raised when security operations fail.

    This exception is used for authentication, authorization,
    encryption, and other security-related errors.

    Attributes:
        reason: The reason for the security failure.
        resource: The resource that was being accessed.

    Example:
        >>> raise SecurityError(
        ...     "Authentication failed",
        ...     reason="Invalid credentials",
        ...     resource="database"
        ... )
    """

    def __init__(
        self,
        message: str,
        *,
        reason: str | None = None,
        resource: str | None = None,
    ) -> None:
        """Initialize security error.

        Args:
            message: Error message describing the security failure.
            reason: The reason for the security failure.
            resource: The resource that was being accessed.
        """
        super().__init__(message)
        self.reason = reason
        self.resource = resource

    def __str__(self) -> str:
        """Format error message with security details."""
        parts = [super().__str__()]

        if self.reason:
            parts.append(f"Reason: {self.reason}")

        if self.resource:
            parts.append(f"Resource: {self.resource}")

        return "\n".join(parts)
