"""Core protocols for DSPU.

This module defines the fundamental protocols used throughout the library.
Protocols provide structural typing without requiring inheritance.
"""

from typing import Any, Protocol, Self, runtime_checkable


@runtime_checkable
class Serializable(Protocol):
    """Protocol for objects that can be serialized to and from dictionaries.

    This protocol defines the interface for objects that can be converted
    to dictionary format for serialization and reconstructed from dictionaries.

    Example:
        >>> class MyData:
        ...     def __init__(self, value: int):
        ...         self.value = value
        ...
        ...     def to_dict(self) -> dict[str, Any]:
        ...         return {"value": self.value}
        ...
        ...     @classmethod
        ...     def from_dict(cls, data: dict[str, Any]) -> Self:
        ...         return cls(data["value"])
        ...
        >>> isinstance(MyData(42), Serializable)
        True
    """

    def to_dict(self) -> dict[str, Any]:
        """Convert object to dictionary representation.

        Returns:
            Dictionary representation of the object.
        """
        ...

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create object from dictionary representation.

        Args:
            data: Dictionary containing object data.

        Returns:
            New instance of the class.
        """
        ...


@runtime_checkable
class AsyncResource(Protocol):
    """Protocol for async context managers.

    This protocol defines the interface for resources that need async
    setup and cleanup. It's a stricter version of typing.AsyncContextManager
    with explicit type hints.

    Example:
        >>> class DatabaseConnection:
        ...     async def __aenter__(self) -> Self:
        ...         await self.connect()
        ...         return self
        ...
        ...     async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        ...         await self.disconnect()
        ...
        >>> async def use_db():
        ...     async with DatabaseConnection() as db:
        ...         await db.query("SELECT 1")
    """

    async def __aenter__(self) -> Self:
        """Enter the async context.

        Returns:
            The resource instance.
        """
        ...

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit the async context.

        Args:
            exc_type: Exception type if an exception was raised.
            exc_val: Exception value if an exception was raised.
            exc_tb: Exception traceback if an exception was raised.
        """
        ...


@runtime_checkable
class Closeable(Protocol):
    """Protocol for resources that need explicit cleanup.

    This protocol defines the interface for resources that need to be
    explicitly closed or cleaned up. Supports both sync and async cleanup.

    Example:
        >>> class FileHandle:
        ...     def close(self) -> None:
        ...         # Cleanup logic
        ...         pass
        ...
        >>> handle = FileHandle()
        >>> handle.close()
        ...
        >>> class AsyncFileHandle:
        ...     async def aclose(self) -> None:
        ...         # Async cleanup logic
        ...         pass
        ...
        >>> async def use_file():
        ...     handle = AsyncFileHandle()
        ...     await handle.aclose()
    """

    def close(self) -> None:
        """Close or cleanup the resource synchronously."""
        ...

    async def aclose(self) -> None:
        """Close or cleanup the resource asynchronously.

        Default implementation calls sync close().
        Override for true async cleanup.
        """
        self.close()
