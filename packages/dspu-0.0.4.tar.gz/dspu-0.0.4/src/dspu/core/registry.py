"""Plugin registry system for DSPU.

This module provides a simple plugin registry for registering and
retrieving plugins by name.
"""

from collections.abc import Callable
from typing import Generic, TypeVar

from dspu.core.exceptions import ConfigurationError

T = TypeVar("T")


class Registry(Generic[T]):
    """Generic registry for plugins.

    This class provides a simple registry pattern for storing and
    retrieving plugins by name. It's generic and can store any type.

    Example:
        >>> registry = Registry[Callable]()
        >>> registry.register("my_plugin", lambda x: x * 2)
        >>> func = registry.get("my_plugin")
        >>> func(5)
        10
    """

    def __init__(self) -> None:
        """Initialize empty registry."""
        self._plugins: dict[str, T] = {}

    def register(self, name: str, plugin: T) -> None:
        """Register a plugin with a name.

        Args:
            name: Name to register the plugin under.
            plugin: The plugin instance to register.

        Raises:
            ConfigurationError: If name is already registered.

        Example:
            >>> registry = Registry[int]()
            >>> registry.register("answer", 42)
        """
        if name in self._plugins:
            raise ConfigurationError(
                f"Plugin '{name}' is already registered",
                field="name",
                suggestion=f"Use a different name or unregister '{name}' first",
            )
        self._plugins[name] = plugin

    def unregister(self, name: str) -> None:
        """Unregister a plugin by name.

        Args:
            name: Name of the plugin to unregister.

        Raises:
            ConfigurationError: If name is not registered.

        Example:
            >>> registry = Registry[int]()
            >>> registry.register("answer", 42)
            >>> registry.unregister("answer")
        """
        if name not in self._plugins:
            raise ConfigurationError(
                f"Plugin '{name}' is not registered",
                field="name",
                suggestion="Check the registered plugin names",
            )
        del self._plugins[name]

    def get(self, name: str) -> T:
        """Get a plugin by name.

        Args:
            name: Name of the plugin to retrieve.

        Returns:
            The registered plugin.

        Raises:
            ConfigurationError: If name is not registered.

        Example:
            >>> registry = Registry[int]()
            >>> registry.register("answer", 42)
            >>> registry.get("answer")
            42
        """
        if name not in self._plugins:
            available = ", ".join(sorted(self._plugins.keys()))
            suggestion = f"Available plugins: {available}" if available else "No plugins registered"
            raise ConfigurationError(
                f"Plugin '{name}' is not registered",
                field="name",
                suggestion=suggestion,
            )
        return self._plugins[name]

    def has(self, name: str) -> bool:
        """Check if a plugin is registered.

        Args:
            name: Name to check.

        Returns:
            True if plugin is registered, False otherwise.

        Example:
            >>> registry = Registry[int]()
            >>> registry.register("answer", 42)
            >>> registry.has("answer")
            True
            >>> registry.has("unknown")
            False
        """
        return name in self._plugins

    def list(self) -> list[str]:
        """List all registered plugin names.

        Returns:
            Sorted list of registered plugin names.

        Example:
            >>> registry = Registry[int]()
            >>> registry.register("one", 1)
            >>> registry.register("two", 2)
            >>> registry.list()
            ['one', 'two']
        """
        return sorted(self._plugins.keys())

    def clear(self) -> None:
        """Clear all registered plugins.

        Example:
            >>> registry = Registry[int]()
            >>> registry.register("answer", 42)
            >>> registry.clear()
            >>> registry.list()
            []
        """
        self._plugins.clear()


def register_plugin(_name: str) -> Callable[[type[T]], type[T]]:
    """Decorator for registering plugins.

    This is a decorator factory that creates a registry-specific
    registration decorator. Typically used with module-level registries.

    Args:
        _name: Name to register the plugin under (currently unused in base implementation).

    Returns:
        Decorator that registers the class and returns it unchanged.

    Note:
        This is a placeholder implementation. In practice, submodules will
        provide their own registration decorators that use module-specific registries.

    Example:
        >>> registry = Registry[type]()
        >>>
        >>> @register_plugin("my_serializer")
        ... class MySerializer:
        ...     def serialize(self, obj: Any) -> bytes:
        ...         return b""
        ...
        >>> registry.has("my_serializer")
        True
    """

    def decorator(cls: type[T]) -> type[T]:
        """Register the class and return it unchanged."""
        # This is a simplified version - in practice, this would need
        # to know which registry to use, possibly via a module-level
        # registry or dependency injection
        return cls

    return decorator
