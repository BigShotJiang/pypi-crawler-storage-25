"""Common type definitions for DSPU.

This module defines type aliases and common types used throughout the library.
"""

from os import PathLike
from typing import Any, TypeAlias

# Path types - accepts strings or path-like objects
StrPath: TypeAlias = str | PathLike[str]

# JSON-compatible types
JSONPrimitive: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | dict[str, "JSONValue"] | list["JSONValue"]
JSONObject: TypeAlias = dict[str, JSONValue]
JSONArray: TypeAlias = list[JSONValue]

# Generic serializable types
Serializable: TypeAlias = JSONValue | bytes

# Config value types
ConfigValue: TypeAlias = (
    str | int | float | bool | None | list["ConfigValue"] | dict[str, "ConfigValue"]
)

# Header types for HTTP/gRPC
Headers: TypeAlias = dict[str, str]
Metadata: TypeAlias = dict[str, Any]
