"""Storage backend protocols and base types.

This module defines the StorageBackend protocol that all storage
implementations must follow.
"""

from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class FileInfo:
    """Information about a file in storage.

    Attributes:
        path: Relative path to the file.
        size: Size in bytes.
        modified: Last modification time.
        is_dir: Whether this is a directory.
    """

    path: str
    size: int
    modified: datetime
    is_dir: bool = False


@runtime_checkable
class StorageBackend(Protocol):
    """Protocol for storage backend implementations.

    All storage backends (local, S3, GCS, Azure, etc.) must implement
    this protocol to work with the Storage facade.

    Example:
        >>> class MyBackend:
        ...     async def read(self, path: str) -> bytes:
        ...         # Implementation
        ...         pass
        ...
        ...     async def write(self, path: str, data: bytes) -> None:
        ...         # Implementation
        ...         pass
        ...
        ...     # ... implement other methods
    """

    async def read(self, path: str) -> bytes:
        """Read file contents as bytes.

        Args:
            path: Path to file relative to backend root.

        Returns:
            File contents as bytes.

        Raises:
            FileNotFoundError: If file doesn't exist.
            PermissionError: If access denied.
            IOError: For other I/O errors.
        """
        ...

    async def write(self, path: str, data: bytes) -> None:
        """Write bytes to file.

        Creates parent directories if needed.

        Args:
            path: Path to file relative to backend root.
            data: Data to write.

        Raises:
            PermissionError: If access denied.
            IOError: For other I/O errors.
        """
        ...

    async def exists(self, path: str) -> bool:
        """Check if file or directory exists.

        Args:
            path: Path to check.

        Returns:
            True if exists, False otherwise.
        """
        ...

    async def delete(self, path: str) -> None:
        """Delete file or directory.

        For directories, deletes recursively.

        Args:
            path: Path to delete.

        Raises:
            FileNotFoundError: If path doesn't exist.
            PermissionError: If access denied.
            IOError: For other I/O errors.
        """
        ...

    async def list(self, pattern: str = "*") -> AsyncIterator[FileInfo]:  # noqa: ARG002
        """List files matching pattern.

        Args:
            pattern: Glob pattern (default: "*" = all files).

        Yields:
            FileInfo for each matching file/directory.

        Example:
            >>> async for file in backend.list("*.json"):
            ...     print(f"{file.path}: {file.size} bytes")
        """
        ...
        if False:  # pragma: no cover
            yield  # Make this a generator, but never execute

    async def read_stream(
        self,
        path: str,  # noqa: ARG002
        chunk_size: int = 8192,  # noqa: ARG002
    ) -> AsyncIterator[bytes]:
        """Stream file contents in chunks.

        Useful for large files to avoid loading entire file in memory.

        Args:
            path: Path to file.
            chunk_size: Size of each chunk in bytes.

        Yields:
            Chunks of file data.

        Raises:
            FileNotFoundError: If file doesn't exist.
            PermissionError: If access denied.
            IOError: For other I/O errors.

        Example:
            >>> async for chunk in backend.read_stream("large_file.bin"):
            ...     process(chunk)
        """
        ...
        if False:  # pragma: no cover
            yield  # Make this a generator, but never execute

    async def write_stream(
        self,
        path: str,
        data: AsyncIterator[bytes],
    ) -> None:
        """Write file from async stream of chunks.

        Useful for large files or streaming data.

        Args:
            path: Path to write to.
            data: Async iterator of data chunks.

        Raises:
            PermissionError: If access denied.
            IOError: For other I/O errors.

        Example:
            >>> async def generate_data():
            ...     for i in range(1000):
            ...         yield f"chunk {i}\\n".encode()
            ...
            >>> await backend.write_stream("output.txt", generate_data())
        """
        ...


def parse_uri(uri: str) -> tuple[str, Path]:
    """Parse storage URI into scheme and path.

    Args:
        uri: Storage URI (e.g., "file:///path", "s3://bucket/key").

    Returns:
        Tuple of (scheme, path).

    Example:
        >>> parse_uri("file:///home/user/data")
        ('file', Path('/home/user/data'))
        >>> parse_uri("/home/user/data")
        ('file', Path('/home/user/data'))
        >>> parse_uri("s3://my-bucket/path/to/file")
        ('s3', Path('my-bucket/path/to/file'))
    """
    if "://" in uri:
        scheme, path_str = uri.split("://", 1)
        return scheme.lower(), Path(path_str)

    # No scheme = local file path
    return "file", Path(uri).expanduser().resolve()
