"""Path resolution utilities.

This module provides utilities for resolving file paths relative to source files,
similar to leaf-common's FileOfClass but with a cleaner API.
"""

from pathlib import Path

from dspu.core.exceptions import DSPUIOError


class PathResolver:
    """Resolve file paths relative to a source file.

    This class helps resolve file paths relative to the location of a source file,
    useful for loading configuration files, data files, etc. that are stored
    relative to your code.

    Example:
        >>> # In your module file
        >>> resolver = PathResolver(__file__)
        >>> config_path = resolver.resolve("../configs/app.yaml")
        >>> assert config_path.is_absolute()
        >>>
        >>> # With a basis directory
        >>> resolver = PathResolver(__file__, basis="../configs")
        >>> config_path = resolver.resolve("app.yaml")

    Security:
        - All paths are resolved to absolute paths
        - Path traversal protection ensures files stay within basis
        - Symlinks are followed and validated
    """

    def __init__(self, source_file: str, basis: str = ".") -> None:
        """Initialize path resolver.

        Args:
            source_file: Starting point for resolution (typically __file__).
            basis: Relative path from source_file's directory to use as root.
                  Default "." means the directory containing source_file.

        Example:
            >>> # Resolve relative to current file's directory
            >>> resolver = PathResolver(__file__)
            >>>
            >>> # Resolve relative to parent directory
            >>> resolver = PathResolver(__file__, basis="..")
            >>>
            >>> # Resolve relative to configs directory
            >>> resolver = PathResolver(__file__, basis="../configs")
        """
        self.source_file = Path(source_file)
        self.basis = basis

    def get_source_path(self) -> Path:
        """Get absolute path to the source file.

        Returns:
            Absolute path to source file.
        """
        return self.source_file.resolve()

    def get_source_dir(self) -> Path:
        """Get directory containing the source file.

        Returns:
            Absolute path to source file's directory.
        """
        return self.source_file.parent.resolve()

    def get_basis_path(self) -> Path:
        """Get absolute path to the basis directory.

        Returns:
            Absolute path to basis directory.
        """
        return (self.source_file.parent / self.basis).resolve()

    def resolve(
        self,
        filename: str,
        *,
        check_exists: bool = False,
        must_be_file: bool = False,
        must_be_dir: bool = False,
    ) -> Path:
        """Resolve filename relative to basis directory.

        Args:
            filename: File or directory name to resolve.
            check_exists: If True, verify path exists.
            must_be_file: If True, verify path is a file.
            must_be_dir: If True, verify path is a directory.

        Returns:
            Absolute path to the resolved file/directory.

        Raises:
            FileNotFoundError: If check_exists=True and path doesn't exist.
            NotADirectoryError: If must_be_dir=True and path is not a directory.
            IsADirectoryError: If must_be_file=True and path is a directory.
            DSPUIOError: If path escapes basis directory.

        Example:
            >>> resolver = PathResolver(__file__, basis="../configs")
            >>> path = resolver.resolve("app.yaml", check_exists=True)
            >>> path = resolver.resolve("data", must_be_dir=True)
        """
        basis_path = self.get_basis_path()
        full_path = (basis_path / filename).resolve()

        # Security: ensure path stays within basis directory
        try:
            full_path.relative_to(basis_path)
        except ValueError as e:
            raise DSPUIOError(
                f"Path '{filename}' escapes basis directory: {basis_path}",
                path=str(full_path),
                operation="resolve",
            ) from e

        # Validation checks
        if check_exists and not full_path.exists():
            raise FileNotFoundError(f"Path not found: {full_path}")

        if must_be_file:
            if not full_path.exists():
                raise FileNotFoundError(f"File not found: {full_path}")
            if not full_path.is_file():
                raise IsADirectoryError(f"Path is a directory, not a file: {full_path}")

        if must_be_dir:
            if not full_path.exists():
                raise FileNotFoundError(f"Directory not found: {full_path}")
            if not full_path.is_dir():
                raise NotADirectoryError(f"Path is a file, not a directory: {full_path}")

        return full_path

    def resolve_all(self, *filenames: str, check_exists: bool = False) -> list[Path]:
        """Resolve multiple filenames at once.

        Args:
            *filenames: File or directory names to resolve.
            check_exists: If True, verify all paths exist.

        Returns:
            List of absolute paths.

        Raises:
            FileNotFoundError: If check_exists=True and any path doesn't exist.
            DSPUIOError: If any path escapes basis directory.

        Example:
            >>> resolver = PathResolver(__file__)
            >>> paths = resolver.resolve_all("a.txt", "b.txt", "c.txt")
        """
        return [self.resolve(f, check_exists=check_exists) for f in filenames]

    @staticmethod
    def check_path_within(
        path: str | Path,
        basis: str | Path,
        *,
        resolve: bool = True,
    ) -> Path:
        """Check that a path is within a basis directory.

        Static utility method for one-off path validation without creating
        a PathResolver instance.

        Args:
            path: Path to check.
            basis: Directory that path must be within.
            resolve: If True, resolve paths to absolute before checking.

        Returns:
            The resolved path if valid.

        Raises:
            DSPUIOError: If path is outside basis directory.

        Example:
            >>> safe_path = PathResolver.check_path_within(
            ...     "/data/configs/app.yaml",
            ...     "/data",
            ... )
        """
        path_obj = Path(path)
        basis_obj = Path(basis)

        if resolve:
            path_obj = path_obj.resolve()
            basis_obj = basis_obj.resolve()

        try:
            path_obj.relative_to(basis_obj)
        except ValueError as e:
            raise DSPUIOError(
                f"Path '{path}' is outside basis directory: {basis}",
                path=str(path_obj),
                operation="check",
            ) from e

        return path_obj


def resolve_path(source_file: str, filename: str, basis: str = ".") -> Path:
    """Convenience function to resolve a single path.

    Args:
        source_file: Starting point (typically __file__).
        filename: File to resolve.
        basis: Relative path to basis directory.

    Returns:
        Absolute path to file.

    Example:
        >>> from dspu.io.paths import resolve_path
        >>> config_path = resolve_path(__file__, "../configs/app.yaml")
    """
    resolver = PathResolver(source_file, basis=basis)
    return resolver.resolve(filename)
