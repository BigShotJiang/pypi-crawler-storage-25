"""Cloud storage backends using fsspec.

This module provides storage backends for cloud providers (S3, GCS, Azure)
using the fsspec library for unified filesystem access.

Requires: pip install dspu[io]
"""

from collections.abc import AsyncIterator
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from dspu.core.exceptions import ConfigurationError, DSPUIOError
from dspu.io.backends import FileInfo

# Optional fsspec dependency
try:
    import fsspec
except ImportError:
    fsspec = None


class _FsspecBackend:
    """Base class for fsspec-based backends.

    Provides common functionality for all cloud backends using fsspec.
    """

    def __init__(self, protocol: str, path: str, **kwargs: Any) -> None:
        """Initialize fsspec backend.

        Args:
            protocol: fsspec protocol (s3, gs, az, etc.).
            path: Path within the storage (bucket/container + prefix).
            **kwargs: Protocol-specific options.

        Raises:
            ConfigurationError: If fsspec is not installed.
        """
        if fsspec is None:
            raise ConfigurationError(
                f"{protocol.upper()} backend requires fsspec package",
                suggestion="Install with: pip install dspu[io]",
            )

        self.protocol = protocol
        self.path = path
        self.fs = fsspec.filesystem(protocol, **kwargs)

    def _resolve_path(self, relative_path: str) -> str:
        """Resolve relative path to full path.

        Args:
            relative_path: Path relative to backend root.

        Returns:
            Full path in storage.
        """
        return str(Path(self.path) / relative_path)

    async def read(self, path: str) -> bytes:
        """Read file contents.

        Args:
            path: Path to file.

        Returns:
            File contents as bytes.

        Raises:
            FileNotFoundError: If file doesn't exist.
            DSPUIOError: For other I/O errors.
        """
        full_path = self._resolve_path(path)

        try:
            # fsspec provides async methods
            if hasattr(self.fs, "_cat_file"):
                data: bytes = await self.fs._cat_file(full_path)
                return data

            # Fallback to sync method
            result: bytes = self.fs.cat_file(full_path)
            return result

        except FileNotFoundError:
            raise
        except Exception as e:
            raise DSPUIOError(
                f"Failed to read from {self.protocol}: {path}",
                path=path,
                operation="read",
            ) from e

    async def write(self, path: str, data: bytes) -> None:
        """Write data to file.

        Args:
            path: Path to file.
            data: Data to write.

        Raises:
            DSPUIOError: For I/O errors.
        """
        full_path = self._resolve_path(path)

        try:
            # fsspec provides async methods
            if hasattr(self.fs, "_pipe_file"):
                await self.fs._pipe_file(full_path, data)
            else:
                # Fallback to sync method
                self.fs.pipe_file(full_path, data)

        except Exception as e:
            raise DSPUIOError(
                f"Failed to write to {self.protocol}: {path}",
                path=path,
                operation="write",
            ) from e

    async def exists(self, path: str) -> bool:
        """Check if path exists.

        Args:
            path: Path to check.

        Returns:
            True if exists, False otherwise.
        """
        full_path = self._resolve_path(path)

        try:
            exists: bool = self.fs.exists(full_path)
            return exists
        except Exception:
            return False

    async def delete(self, path: str) -> None:
        """Delete file or directory.

        Args:
            path: Path to delete.

        Raises:
            FileNotFoundError: If path doesn't exist.
            DSPUIOError: For other I/O errors.
        """
        full_path = self._resolve_path(path)

        if not self.fs.exists(full_path):
            raise FileNotFoundError(f"Path not found: {path}")

        try:
            self.fs.rm(full_path, recursive=True)
        except Exception as e:
            raise DSPUIOError(
                f"Failed to delete from {self.protocol}: {path}",  # noqa: S608
                path=path,
                operation="delete",
            ) from e

    async def list(self, pattern: str = "*") -> AsyncIterator[FileInfo]:
        """List files matching pattern.

        Args:
            pattern: Glob pattern.

        Yields:
            FileInfo for each matching file.
        """
        try:
            # Use glob to find matching files
            full_pattern = self._resolve_path(pattern)
            files = self.fs.glob(full_pattern)

            for file_path in files:
                try:
                    info = self.fs.info(file_path)

                    # Extract relative path
                    rel_path = str(Path(file_path).relative_to(self.path))

                    yield FileInfo(
                        path=rel_path,
                        size=info.get("size", 0),
                        modified=datetime.fromtimestamp(
                            info.get("mtime", 0),
                            tz=UTC,
                        ),
                        is_dir=info.get("type") == "directory",
                    )
                except Exception:  # noqa: S112
                    # Skip files we can't stat
                    continue

        except Exception as e:
            raise DSPUIOError(
                f"Failed to list files in {self.protocol}: {pattern}",
                path=self.path,
                operation="list",
            ) from e

    async def read_stream(
        self,
        path: str,
        chunk_size: int = 8192,
    ) -> AsyncIterator[bytes]:
        """Stream file contents.

        Args:
            path: Path to file.
            chunk_size: Chunk size in bytes.

        Yields:
            Chunks of file data.

        Raises:
            FileNotFoundError: If file doesn't exist.
            DSPUIOError: For other I/O errors.
        """
        full_path = self._resolve_path(path)

        if not self.fs.exists(full_path):
            raise FileNotFoundError(f"File not found: {path}")

        try:
            with self.fs.open(full_path, "rb") as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk

        except FileNotFoundError:
            raise
        except Exception as e:
            raise DSPUIOError(
                f"Failed to stream from {self.protocol}: {path}",
                path=path,
                operation="read_stream",
            ) from e

    async def write_stream(
        self,
        path: str,
        data: AsyncIterator[bytes],
    ) -> None:
        """Write file from stream.

        Args:
            path: Path to write to.
            data: Async iterator of data chunks.

        Raises:
            DSPUIOError: For I/O errors.
        """
        full_path = self._resolve_path(path)

        try:
            with self.fs.open(full_path, "wb") as f:
                async for chunk in data:
                    f.write(chunk)

        except Exception as e:
            raise DSPUIOError(
                f"Failed to write stream to {self.protocol}: {path}",
                path=path,
                operation="write_stream",
            ) from e


class S3Backend(_FsspecBackend):
    """Amazon S3 storage backend.

    Requires: pip install s3fs

    Example:
        >>> backend = S3Backend(
        ...     "my-bucket/prefix",
        ...     key="ACCESS_KEY",
        ...     secret="SECRET_KEY",
        ... )
        >>> await backend.write("data.json", b'{"key": "value"}')
    """

    def __init__(self, path: str, **kwargs: Any) -> None:
        """Initialize S3 backend.

        Args:
            path: S3 path (bucket/prefix).
            **kwargs: S3-specific options (key, secret, endpoint_url, etc.).
        """
        super().__init__("s3", path, **kwargs)


class GCSBackend(_FsspecBackend):
    """Google Cloud Storage backend.

    Requires: pip install gcsfs

    Example:
        >>> backend = GCSBackend(
        ...     "my-bucket/prefix",
        ...     token="path/to/credentials.json",
        ... )
        >>> await backend.write("data.json", b'{"key": "value"}')
    """

    def __init__(self, path: str, **kwargs: Any) -> None:
        """Initialize GCS backend.

        Args:
            path: GCS path (bucket/prefix).
            **kwargs: GCS-specific options (token, project, etc.).
        """
        super().__init__("gs", path, **kwargs)


class AzureBackend(_FsspecBackend):
    """Azure Blob Storage backend.

    Requires: pip install adlfs

    Example:
        >>> backend = AzureBackend(
        ...     "container/prefix",
        ...     account_name="myaccount",
        ...     account_key="KEY",
        ... )
        >>> await backend.write("data.json", b'{"key": "value"}')
    """

    def __init__(self, path: str, **kwargs: Any) -> None:
        """Initialize Azure backend.

        Args:
            path: Azure path (container/prefix).
            **kwargs: Azure-specific options (account_name, account_key, etc.).
        """
        super().__init__("az", path, **kwargs)
