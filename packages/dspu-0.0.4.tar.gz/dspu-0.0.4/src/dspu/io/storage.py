"""Storage facade for unified I/O operations.

This module provides the Storage class, a high-level interface for
reading/writing data to various storage backends (local, S3, GCS, Azure).
"""

from collections.abc import AsyncIterator
from typing import Any, cast

from dspu.core.exceptions import ConfigurationError
from dspu.io.backends import FileInfo, StorageBackend, parse_uri
from dspu.io.local import LocalBackend
from dspu.io.serializers import deserialize, detect_format, serialize


class Storage:
    """Unified storage interface with automatic serialization.

    Provides a high-level API for reading/writing data to any storage backend
    with automatic format detection and serialization.

    Example:
        >>> # Local filesystem
        >>> storage = Storage.from_uri("/data")
        >>> await storage.write("config.json", {"debug": True})
        >>> config = await storage.read("config.json")
        >>>
        >>> # S3 (requires fsspec)
        >>> storage = Storage.from_uri("s3://my-bucket/path")
        >>> await storage.write("data.msgpack", large_dataset)
        >>>
        >>> # Streaming for large files
        >>> async for chunk in storage.read_stream("large_file.csv"):
        ...     process(chunk)
    """

    def __init__(self, backend: StorageBackend) -> None:
        """Initialize storage with backend.

        Args:
            backend: Storage backend implementation.
        """
        self._backend: StorageBackend = backend

    @classmethod
    def from_uri(cls, uri: str, **kwargs: Any) -> "Storage":
        """Create Storage from URI.

        Auto-detects backend from URI scheme.

        Args:
            uri: Storage URI (e.g., "file:///path", "s3://bucket").
            **kwargs: Backend-specific options.

        Returns:
            Storage instance with appropriate backend.

        Raises:
            ConfigurationError: If backend is not supported or unavailable.

        Example:
            >>> storage = Storage.from_uri("/data/local")
            >>> storage = Storage.from_uri("s3://my-bucket/prefix")
        """
        scheme, path = parse_uri(uri)

        if scheme == "file":
            backend = cast(StorageBackend, LocalBackend(path))
            return cls(backend)

        if scheme == "s3":
            # Lazy import to avoid requiring fsspec for local-only use
            try:
                from dspu.io.cloud import S3Backend  # noqa: PLC0415
            except ImportError as e:
                raise ConfigurationError(
                    "S3 backend requires fsspec and s3fs packages",
                    suggestion="Install with: pip install dspu[io]",
                ) from e

            backend = cast(StorageBackend, S3Backend(str(path), **kwargs))
            return cls(backend)

        if scheme in {"gs", "gcs"}:
            try:
                from dspu.io.cloud import GCSBackend  # noqa: PLC0415
            except ImportError as e:
                raise ConfigurationError(
                    "GCS backend requires fsspec and gcsfs packages",
                    suggestion="Install with: pip install dspu[io]",
                ) from e

            backend = cast(StorageBackend, GCSBackend(str(path), **kwargs))
            return cls(backend)

        if scheme in {"az", "azure"}:
            try:
                from dspu.io.cloud import AzureBackend  # noqa: PLC0415
            except ImportError as e:
                raise ConfigurationError(
                    "Azure backend requires fsspec and adlfs packages",
                    suggestion="Install with: pip install dspu[io]",
                ) from e

            backend = cast(StorageBackend, AzureBackend(str(path), **kwargs))
            return cls(backend)

        raise ConfigurationError(
            f"Unsupported storage scheme: {scheme}",
            suggestion="Supported schemes: file, s3, gs/gcs, az/azure",
        )

    async def read(
        self,
        path: str,
        *,
        format: str | None = None,  # noqa: A002
        raw: bool = False,
    ) -> Any:
        """Read and deserialize data from storage.

        Args:
            path: Path to file.
            format: Serialization format (auto-detected if None).
            raw: If True, return raw bytes without deserialization.

        Returns:
            Deserialized data or raw bytes if raw=True.

        Raises:
            FileNotFoundError: If file doesn't exist.
            SerializationError: If deserialization fails.

        Example:
            >>> config = await storage.read("config.json")
            >>> data = await storage.read("data.msgpack", format="msgpack")
            >>> raw_bytes = await storage.read("file.bin", raw=True)
        """
        data = await self._backend.read(path)

        if raw:
            return data

        # Auto-detect format if not specified
        fmt = format or detect_format(path)

        return deserialize(data, fmt)

    async def write(
        self,
        path: str,
        data: Any,
        *,
        format: str | None = None,  # noqa: A002
        raw: bool = False,
    ) -> None:
        """Serialize and write data to storage.

        Args:
            path: Path to file.
            data: Data to write (or bytes if raw=True).
            format: Serialization format (auto-detected if None).
            raw: If True, write data as-is (must be bytes).

        Raises:
            SerializationError: If serialization fails.
            TypeError: If raw=True and data is not bytes.

        Example:
            >>> await storage.write("config.json", {"debug": True})
            >>> await storage.write("data.msgpack", dataset, format="msgpack")
            >>> await storage.write("file.bin", b"raw data", raw=True)
        """
        if raw:
            if not isinstance(data, bytes):
                raise TypeError("raw=True requires bytes data")
            serialized = data
        else:
            # Auto-detect format if not specified
            fmt = format or detect_format(path)
            serialized = serialize(data, fmt)

        await self._backend.write(path, serialized)

    async def write_format(
        self,
        path: str,
        data: Any,
        *,
        format: str | None = None,  # noqa: A002
        format_options: dict[str, Any] | None = None,
    ) -> None:
        """Write data using format writer (text-based formats).

        This method uses the format system for text-based structured formats
        like YAML, TOML, CSV, .env files, etc. For binary formats (msgpack,
        pickle), use the regular write() method.

        Args:
            path: Path to file.
            data: Data to write.
            format: Format name (auto-detected from path if None).
            format_options: Format-specific options (indent, delimiter, etc).

        Raises:
            FormatError: If format operations fail.

        Example:
            >>> # YAML with custom options
            >>> await storage.write_format(
            ...     'config.yaml',
            ...     {'debug': True},
            ...     format_options={'sort_keys': True}
            ... )
            >>>
            >>> # CSV with headers
            >>> await storage.write_format(
            ...     'data.csv',
            ...     [{'name': 'Alice', 'age': 30}],
            ...     format_options={'header': True}
            ... )
        """
        from dspu.io.formats import (  # noqa: PLC0415
            detect_format_from_path,
            get_format,
        )
        from dspu.io.formats.base import FormatError  # noqa: PLC0415

        # Detect format
        fmt_name = format or detect_format_from_path(path)

        # Get format instance
        opts = format_options or {}
        fmt = get_format(fmt_name, **opts)

        # Check if can write
        if not fmt.can_write(data):
            raise FormatError(
                f"Format '{fmt_name}' cannot write {type(data).__name__}",
                format=fmt_name,
                suggestion="Check data type matches format requirements",
            )

        # Convert to bytes
        bytes_data = fmt.write(data, path)

        # Write via backend
        await self._backend.write(path, bytes_data)

    async def read_format(
        self,
        path: str,
        *,
        format: str | None = None,  # noqa: A002
        format_options: dict[str, Any] | None = None,
    ) -> Any:
        """Read data using format reader (text-based formats).

        This method uses the format system for text-based structured formats.
        For binary formats, use the regular read() method.

        Args:
            path: Path to file.
            format: Format name (auto-detected from path if None).
            format_options: Format-specific options.

        Returns:
            Parsed data (type depends on format).

        Raises:
            FormatError: If format operations fail.

        Example:
            >>> config = await storage.read_format('config.yaml')
            >>> data = await storage.read_format('data.csv')
        """
        from dspu.io.formats import (  # noqa: PLC0415
            detect_format_from_path,
            get_format,
        )

        # Read raw bytes
        bytes_data = await self._backend.read(path)

        # Detect format
        fmt_name = format or detect_format_from_path(path)

        # Get format instance
        opts = format_options or {}
        fmt = get_format(fmt_name, **opts)

        # Parse bytes
        return fmt.read(bytes_data, path)

    async def exists(self, path: str) -> bool:
        """Check if file exists.

        Args:
            path: Path to check.

        Returns:
            True if exists, False otherwise.

        Example:
            >>> if await storage.exists("config.json"):
            ...     config = await storage.read("config.json")
        """
        return await self._backend.exists(path)

    async def delete(self, path: str) -> None:
        """Delete file or directory.

        Args:
            path: Path to delete.

        Raises:
            FileNotFoundError: If path doesn't exist.

        Example:
            >>> await storage.delete("old_data.json")
        """
        await self._backend.delete(path)

    async def list(self, pattern: str = "*") -> list[FileInfo]:
        """List files matching pattern.

        Args:
            pattern: Glob pattern.

        Returns:
            List of FileInfo for matching files.

        Example:
            >>> files = await storage.list("*.json")
            >>> for file in files:
            ...     print(f"{file.path}: {file.size} bytes")
        """
        # Type ignore: pyrefly has issues with async generator protocol variance
        return [f async for f in self._backend.list(pattern)]  # type: ignore[misc]

    async def read_stream(
        self,
        path: str,
        chunk_size: int = 8192,
    ) -> AsyncIterator[bytes]:
        """Stream file contents.

        Useful for large files to avoid loading everything in memory.

        Args:
            path: Path to file.
            chunk_size: Size of chunks in bytes.

        Yields:
            Chunks of file data.

        Example:
            >>> async for chunk in storage.read_stream("large_file.csv"):
            ...     process(chunk)
        """
        # Type ignore: pyrefly has issues with async generator protocol variance
        async for chunk in self._backend.read_stream(path, chunk_size):  # type: ignore[misc]
            yield chunk

    async def write_stream(
        self,
        path: str,
        data: AsyncIterator[bytes],
    ) -> None:
        """Write file from stream.

        Args:
            path: Path to write to.
            data: Async iterator of data chunks.

        Example:
            >>> async def generate_data():
            ...     for i in range(1000):
            ...         yield f"line {i}\\n".encode()
            ...
            >>> await storage.write_stream("output.txt", generate_data())
        """
        await self._backend.write_stream(path, data)
