"""Local filesystem storage backend."""

import shutil
from collections.abc import AsyncIterator
from datetime import UTC, datetime
from pathlib import Path

import anyio

from dspu.core.exceptions import DSPUIOError
from dspu.io.backends import FileInfo


class LocalBackend:
    """Local filesystem storage backend.

    Provides async file operations on the local filesystem.

    Example:
        >>> backend = LocalBackend("/data")
        >>> await backend.write("test.txt", b"Hello")
        >>> data = await backend.read("test.txt")
        >>> print(data.decode())
        Hello
    """

    def __init__(self, root: str | Path) -> None:
        """Initialize local backend.

        Args:
            root: Root directory for storage.
        """
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _resolve_path(self, path: str) -> Path:
        """Resolve relative path to absolute path within root.

        Args:
            path: Relative path.

        Returns:
            Absolute path.

        Raises:
            DSPUIOError: If path escapes root directory.
        """
        full_path = (self.root / path).resolve()

        # Security: ensure path is within root
        try:
            full_path.relative_to(self.root)
        except ValueError as e:
            raise DSPUIOError(
                f"Path escapes root directory: {path}",
                path=path,
            ) from e

        return full_path

    async def read(self, path: str) -> bytes:
        """Read file contents.

        Args:
            path: Path to file relative to root.

        Returns:
            File contents as bytes.

        Raises:
            FileNotFoundError: If file doesn't exist.
            DSPUIOError: For other I/O errors.
        """
        full_path = self._resolve_path(path)

        try:
            data: bytes = await anyio.Path(full_path).read_bytes()
            return data
        except FileNotFoundError:
            raise
        except Exception as e:
            raise DSPUIOError(
                f"Failed to read file: {path}",
                path=path,
                operation="read",
            ) from e

    async def write(self, path: str, data: bytes) -> None:
        """Write data to file.

        Creates parent directories if needed.

        Args:
            path: Path to file relative to root.
            data: Data to write.

        Raises:
            DSPUIOError: For I/O errors.
        """
        full_path = self._resolve_path(path)

        try:
            # Create parent directories
            full_path.parent.mkdir(parents=True, exist_ok=True)

            # Write file atomically using anyio
            await anyio.Path(full_path).write_bytes(data)
        except Exception as e:
            raise DSPUIOError(
                f"Failed to write file: {path}",
                path=path,
                operation="write",
            ) from e

    async def exists(self, path: str) -> bool:
        """Check if path exists.

        Args:
            path: Path to check.

        Returns:
            True if exists, False otherwise.
        """
        try:
            full_path = self._resolve_path(path)
            exists: bool = await anyio.Path(full_path).exists()
            return exists
        except DSPUIOError:
            return False

    async def delete(self, path: str) -> None:
        """Delete file or directory.

        Args:
            path: Path to delete.

        Raises:
            FileNotFoundError: If path doesn't exist.
            DSPUIOError: For other I/O errors.
        """
        full_path = self._resolve_path(path)

        if not full_path.exists():
            raise FileNotFoundError(f"Path not found: {path}")

        try:
            if full_path.is_dir():
                # Use sync shutil for recursive delete
                await anyio.to_thread.run_sync(shutil.rmtree, full_path)
            else:
                await anyio.Path(full_path).unlink()
        except Exception as e:
            raise DSPUIOError(
                f"Failed to delete: {path}",
                path=path,
                operation="delete",
            ) from e

    async def list(self, pattern: str = "*") -> AsyncIterator[FileInfo]:
        """List files matching pattern.

        Args:
            pattern: Glob pattern.

        Yields:
            FileInfo for each matching file/directory.
        """
        try:
            # Use glob to find matching paths
            for path in self.root.glob(pattern):
                stat = path.stat()

                # Convert to relative path
                rel_path = path.relative_to(self.root)

                yield FileInfo(
                    path=str(rel_path),
                    size=stat.st_size,
                    modified=datetime.fromtimestamp(stat.st_mtime, tz=UTC),
                    is_dir=path.is_dir(),
                )
        except Exception as e:
            raise DSPUIOError(
                f"Failed to list files: {pattern}",
                path=str(self.root),
                operation="list",
            ) from e

    async def read_stream(
        self,
        path: str,
        chunk_size: int = 8192,
    ) -> AsyncIterator[bytes]:
        """Stream file contents in chunks.

        Args:
            path: Path to file.
            chunk_size: Chunk size in bytes.

        Yields:
            Chunks of file data.

        Raises:
            FileNotFoundError: If file doesn't exist.
            DSPUIOError: For other I/O errors.
        """
        full_path = self._resolve_path(path)

        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        try:
            async with await anyio.open_file(full_path, "rb") as f:
                while True:
                    chunk = await f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk
        except FileNotFoundError:
            raise
        except Exception as e:
            raise DSPUIOError(
                f"Failed to stream file: {path}",
                path=path,
                operation="read_stream",
            ) from e

    async def write_stream(
        self,
        path: str,
        data: AsyncIterator[bytes],
    ) -> None:
        """Write file from stream.

        Args:
            path: Path to write to.
            data: Async iterator of data chunks.

        Raises:
            DSPUIOError: For I/O errors.
        """
        full_path = self._resolve_path(path)

        try:
            # Create parent directories
            full_path.parent.mkdir(parents=True, exist_ok=True)

            async with await anyio.open_file(full_path, "wb") as f:
                async for chunk in data:
                    await f.write(chunk)
        except Exception as e:
            raise DSPUIOError(
                f"Failed to write stream: {path}",
                path=path,
                operation="write_stream",
            ) from e
