"""Structured data formats (JSON, YAML, TOML, HOCON)."""

import json
from pathlib import Path
from typing import Any

from dspu.io.formats.base import FormatError

# Optional dependencies
try:
    import orjson
except ImportError:
    orjson = None

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore[assignment]

try:
    import tomli_w
except ImportError:
    tomli_w = None

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]

try:
    from pyhocon import ConfigFactory, HOCONConverter
except ImportError:
    ConfigFactory = None
    HOCONConverter = None


def _validate_structured(obj: Any) -> None:
    """Validate object is structured data (dict or list).

    Raises:
        FormatError: If not dict or list.
    """
    if not isinstance(obj, (dict, list)):
        raise FormatError(
            f"Structured formats require dict or list, got {type(obj).__name__}",
            suggestion="Use TextFormat for strings or CSVFormat for tabular data",
        )


def _ensure_dict(obj: Any) -> dict[str, Any]:
    """Ensure object is a dict (some formats like TOML require dict root).

    Raises:
        FormatError: If object is not a dict.
    """
    if not isinstance(obj, dict):
        raise FormatError(
            f"This format requires a dict at root, got {type(obj).__name__}",
            suggestion="Wrap your data in a dict or use a different format",
        )
    return obj


class JSONFormat:
    """JSON format handler.

    Handles dicts, lists, and JSON-serializable primitives.
    Uses orjson for better performance if available.

    Example:
        >>> fmt = JSONFormat(indent=2, sort_keys=True)
        >>> data = {"name": "Alice", "age": 30}
        >>> bytes_data = fmt.write(data, "output.json")
    """

    def __init__(
        self,
        *,
        indent: int | None = 2,
        sort_keys: bool = False,
        ensure_ascii: bool = False,
    ) -> None:
        """Initialize JSON format.

        Args:
            indent: Indentation level (None = compact).
            sort_keys: Sort dictionary keys.
            ensure_ascii: Escape non-ASCII characters.
        """
        self.indent = indent
        self.sort_keys = sort_keys
        self.ensure_ascii = ensure_ascii
        self.use_orjson = orjson is not None

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write object as JSON bytes."""
        try:
            if self.use_orjson and orjson is not None:
                option = 0
                if self.indent:
                    option |= orjson.OPT_INDENT_2
                if self.sort_keys:
                    option |= orjson.OPT_SORT_KEYS
                result: bytes = orjson.dumps(obj, option=option)
                return result

            # Fallback to stdlib
            json_str = json.dumps(
                obj,
                indent=self.indent,
                sort_keys=self.sort_keys,
                ensure_ascii=self.ensure_ascii,
            )
            return json_str.encode("utf-8")

        except (TypeError, ValueError) as e:
            raise FormatError(
                f"Cannot serialize to JSON (writing to {path}): {e}",
                format="json",
                suggestion="Ensure object contains only JSON-serializable types",
            ) from e

    def read(self, data: bytes, path: str | Path | None = None) -> Any:
        """Read JSON bytes to object."""
        try:
            if self.use_orjson and orjson is not None:
                return orjson.loads(data)
            return json.loads(data.decode("utf-8"))
        except (json.JSONDecodeError, ValueError) as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(
                f"Invalid JSON{path_info}: {e}",
                format="json",
                suggestion="Check JSON syntax",
            ) from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is JSON-serializable."""
        try:
            json.dumps(obj)
            return True
        except (TypeError, ValueError):
            return False

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".json"]


class YAMLFormat:
    """YAML format handler.

    Supports complex nested structures, multiple documents.

    Example:
        >>> fmt = YAMLFormat(sort_keys=True)
        >>> data = {"database": {"host": "localhost", "port": 5432}}
        >>> bytes_data = fmt.write(data, "config.yaml")
    """

    def __init__(
        self,
        *,
        default_flow_style: bool = False,
        sort_keys: bool = False,
        allow_unicode: bool = True,
    ) -> None:
        """Initialize YAML format.

        Args:
            default_flow_style: Use flow style {...} instead of block style.
            sort_keys: Sort dictionary keys.
            allow_unicode: Allow unicode characters (vs ASCII escapes).
        """
        self.default_flow_style = default_flow_style
        self.sort_keys = sort_keys
        self.allow_unicode = allow_unicode

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write object as YAML bytes."""
        if yaml is None:
            raise FormatError(
                "YAML format requires pyyaml package",
                format="yaml",
                suggestion="Install with: pip install pyyaml",
            )

        _validate_structured(obj)

        try:
            yaml_str = yaml.dump(
                obj,
                default_flow_style=self.default_flow_style,
                sort_keys=self.sort_keys,
                allow_unicode=self.allow_unicode,
                Dumper=yaml.SafeDumper,
            )
            return yaml_str.encode("utf-8")
        except yaml.YAMLError as e:
            raise FormatError(
                f"Cannot serialize to YAML (writing to {path}): {e}",
                format="yaml",
                suggestion="Check for unsupported types",
            ) from e

    def read(self, data: bytes, path: str | Path | None = None) -> Any:
        """Read YAML bytes to object."""
        if yaml is None:
            raise FormatError(
                "YAML format requires pyyaml package",
                format="yaml",
                suggestion="Install with: pip install pyyaml",
            )

        try:
            return yaml.safe_load(data.decode("utf-8"))
        except yaml.YAMLError as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(f"Invalid YAML{path_info}: {e}", format="yaml") from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is YAML-serializable."""
        return isinstance(obj, (dict, list))

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".yaml", ".yml"]


class TOMLFormat:
    """TOML format handler.

    TOML requires dict at root level (no lists at root).
    Good for configuration files with sections.

    Example:
        >>> fmt = TOMLFormat()
        >>> data = {"database": {"host": "localhost", "port": 5432}}
        >>> bytes_data = fmt.write(data, "config.toml")
    """

    def __init__(self, *, multiline_strings: bool = False) -> None:
        """Initialize TOML format.

        Args:
            multiline_strings: Use multiline string format for long strings.
        """
        self.multiline_strings = multiline_strings

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write object as TOML bytes."""
        if tomli_w is None:
            raise FormatError(
                "TOML writing requires tomli-w package",
                format="toml",
                suggestion="Install with: pip install tomli-w",
            )

        # TOML requires dict at root
        data = _ensure_dict(obj)

        try:
            toml_str: str = tomli_w.dumps(data)
            return toml_str.encode("utf-8")
        except (TypeError, ValueError) as e:
            raise FormatError(
                f"Cannot serialize to TOML (writing to {path}): {e}",
                format="toml",
                suggestion="TOML requires simple types (no custom objects)",
            ) from e

    def read(self, data: bytes, path: str | Path | None = None) -> dict[str, Any]:
        """Read TOML bytes to dict."""
        if tomllib is None:
            raise FormatError(
                "TOML reading requires tomllib (Python 3.11+) or tomli package",
                format="toml",
                suggestion="Install with: pip install tomli",
            )

        try:
            return tomllib.loads(data.decode("utf-8"))
        except Exception as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(f"Invalid TOML{path_info}: {e}", format="toml") from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is TOML-serializable."""
        return isinstance(obj, dict)

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".toml"]


class HOCONFormat:
    """HOCON format handler.

    HOCON (Human-Optimized Config Object Notation) is a JSON superset
    with comments, includes, substitutions, and more human-friendly syntax.

    Example:
        >>> fmt = HOCONFormat()
        >>> data = {"database": {"host": "localhost", "port": 5432}}
        >>> bytes_data = fmt.write(data, "config.conf")
    """

    def __init__(self, *, resolve: bool = True) -> None:
        """Initialize HOCON format.

        Args:
            resolve: Resolve substitutions and includes on read.
        """
        self.resolve = resolve

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write object as HOCON bytes.

        Note: Outputs JSON-compatible format since pyhocon has limited
        write support.
        """
        if ConfigFactory is None or HOCONConverter is None:
            raise FormatError(
                "HOCON format requires pyhocon package",
                format="hocon",
                suggestion="Install with: pip install pyhocon",
            )

        data = _ensure_dict(obj)

        try:
            # Convert to HOCON string (pretty-printed JSON-like format)
            config = ConfigFactory.from_dict(data)
            hocon_str = HOCONConverter.to_hocon(config)
            return hocon_str.encode("utf-8")  # type: ignore[no-any-return]
        except Exception as e:
            raise FormatError(
                f"Cannot serialize to HOCON (writing to {path}): {e}",
                format="hocon",
                suggestion="Ensure object is a dict with simple types",
            ) from e

    def read(self, data: bytes, path: str | Path | None = None) -> dict[str, Any]:
        """Read HOCON bytes to dict."""
        if ConfigFactory is None:
            raise FormatError(
                "HOCON format requires pyhocon package",
                format="hocon",
                suggestion="Install with: pip install pyhocon",
            )

        try:
            config = ConfigFactory.parse_string(data.decode("utf-8"))
            return dict(config)
        except Exception as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(f"Invalid HOCON{path_info}: {e}", format="hocon") from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is HOCON-serializable."""
        return isinstance(obj, dict)

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".conf", ".hocon"]
