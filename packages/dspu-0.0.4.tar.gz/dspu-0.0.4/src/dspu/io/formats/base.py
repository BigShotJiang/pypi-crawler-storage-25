"""Base protocols and exceptions for format system."""

from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from dspu.core.exceptions import DSPUError


class FormatError(DSPUError):
    """Raised when format operations fail.

    Attributes:
        format: The format that caused the error.
        suggestion: Helpful suggestion for fixing the error.
    """

    def __init__(
        self,
        message: str,
        *,
        format: str | None = None,  # noqa: A002
        suggestion: str | None = None,
    ) -> None:
        """Initialize format error.

        Args:
            message: Error message.
            format: Format name that caused the error.
            suggestion: Helpful suggestion for fixing the error.
        """
        super().__init__(message)
        self.format = format
        self.suggestion = suggestion

    def __str__(self) -> str:
        """Format error message with context."""
        parts = [super().__str__()]
        if self.format:
            parts.append(f"Format: {self.format}")
        if self.suggestion:
            parts.append(f"Suggestion: {self.suggestion}")
        return "\n".join(parts)


@runtime_checkable
class FormatWriter(Protocol):
    """Protocol for format writers.

    Format writers convert Python objects to bytes for storage.
    Unlike serializers (binary formats), writers handle text-based
    formats with specific syntax requirements.
    """

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Convert object to bytes in this format.

        Args:
            obj: Object to write (type depends on format).
            path: Target path (used for validation/metadata).

        Returns:
            Formatted bytes ready to write to storage.

        Raises:
            FormatError: If object cannot be written in this format.
        """
        ...

    def can_write(self, obj: Any) -> bool:
        """Check if this writer can handle the object.

        Args:
            obj: Object to check.

        Returns:
            True if this writer can handle the object type.
        """
        ...

    @property
    def extensions(self) -> list[str]:
        """List of file extensions this writer handles.

        Returns:
            List of extensions (e.g., ['.json', '.jsonl']).
        """
        ...


@runtime_checkable
class FormatReader(Protocol):
    """Protocol for format readers.

    Format readers parse bytes into Python objects.
    """

    def read(self, data: bytes, path: str | Path | None = None) -> Any:
        """Parse bytes in this format to object.

        Args:
            data: Raw bytes to parse.
            path: Source path (optional, used for error messages).

        Returns:
            Parsed object (type depends on format).

        Raises:
            FormatError: If data cannot be parsed.
        """
        ...

    @property
    def extensions(self) -> list[str]:
        """List of file extensions this reader handles."""
        ...


@runtime_checkable
class Format(Protocol):
    """Protocol for formats that support both read and write.

    Most formats implement both reading and writing.
    """

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write object to bytes."""
        ...

    def read(self, data: bytes, path: str | Path | None = None) -> Any:
        """Read bytes to object."""
        ...

    def can_write(self, obj: Any) -> bool:
        """Check if can write object."""
        ...

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        ...
