"""Format registry for automatic discovery and instantiation."""

from pathlib import Path
from typing import Any

from dspu.core.exceptions import ConfigurationError
from dspu.io.formats.base import Format, FormatError

# Global format registry - maps format names to classes
_FORMATS: dict[str, type[Format]] = {}

# Extension to format name mapping
_EXTENSION_MAP: dict[str, str] = {}


def _initialize_registry() -> None:
    """Initialize registry with built-in formats."""
    # Import here to avoid circular imports
    from dspu.io.formats.structured import (  # noqa: PLC0415
        HOCONFormat,
        JSONFormat,
        TOMLFormat,
        YAMLFormat,
    )
    from dspu.io.formats.tabular import CSVFormat  # noqa: PLC0415
    from dspu.io.formats.text import (  # noqa: PLC0415
        EnvFormat,
        MarkdownFormat,
        PythonFormat,
        TextFormat,
    )

    # Register built-in formats
    _register_builtin("json", JSONFormat)
    _register_builtin("yaml", YAMLFormat)
    _register_builtin("toml", TOMLFormat)
    _register_builtin("hocon", HOCONFormat)
    _register_builtin("csv", CSVFormat)
    _register_builtin("text", TextFormat)
    _register_builtin("python", PythonFormat)
    _register_builtin("markdown", MarkdownFormat)
    _register_builtin("env", EnvFormat)


def _register_builtin(name: str, format_class: type[Format]) -> None:
    """Register a built-in format without validation.

    Args:
        name: Format name.
        format_class: Format class.
    """
    _FORMATS[name] = format_class

    # Register extensions
    instance = format_class()
    for ext in instance.extensions:
        # Don't overwrite existing mappings (first registered wins)
        if ext not in _EXTENSION_MAP:
            _EXTENSION_MAP[ext] = name


def register_format(name: str, format_class: type[Format]) -> None:
    """Register a custom format.

    Args:
        name: Format name (e.g., 'xml').
        format_class: Format class implementing Format protocol.

    Raises:
        ConfigurationError: If name already registered or invalid format class.

    Example:
        >>> class XMLFormat:
        ...     def write(self, obj, path): ...
        ...     def read(self, data, path): ...
        ...     def can_write(self, obj): ...
        ...     @property
        ...     def extensions(self): return ['.xml']
        ...
        >>> register_format('xml', XMLFormat)
    """
    if name in _FORMATS:
        raise ConfigurationError(
            f"Format '{name}' is already registered",
            field="name",
            suggestion="Unregister first or use different name",
        )

    # Basic validation - try to instantiate
    try:
        instance = format_class()
    except Exception as e:
        raise ConfigurationError(
            f"Cannot instantiate format class: {e}",
            field="format_class",
            suggestion="Ensure class can be instantiated with no arguments",
        ) from e

    # Check it has required methods/properties
    if not hasattr(instance, "write"):
        raise ConfigurationError(
            "Format class must have 'write' method",
            field="format_class",
            suggestion="Add: def write(self, obj, path) -> bytes",
        )

    if not hasattr(instance, "read"):
        raise ConfigurationError(
            "Format class must have 'read' method",
            field="format_class",
            suggestion="Add: def read(self, data, path) -> Any",
        )

    if not hasattr(instance, "can_write"):
        raise ConfigurationError(
            "Format class must have 'can_write' method",
            field="format_class",
            suggestion="Add: def can_write(self, obj) -> bool",
        )

    if not hasattr(instance, "extensions"):
        raise ConfigurationError(
            "Format class must have 'extensions' property",
            field="format_class",
            suggestion="Add: @property\\ndef extensions(self) -> list[str]",
        )

    _FORMATS[name] = format_class

    # Register extensions
    for ext in instance.extensions:
        if ext not in _EXTENSION_MAP:
            _EXTENSION_MAP[ext] = name


def unregister_format(name: str) -> None:
    """Unregister a format.

    Args:
        name: Format name to unregister.

    Raises:
        ConfigurationError: If name not registered or is a built-in format.
    """
    if name not in _FORMATS:
        raise ConfigurationError(
            f"Format '{name}' is not registered",
            field="name",
            suggestion=f"Available formats: {', '.join(_FORMATS.keys())}",
        )

    # Note: We allow unregistering built-in formats for advanced use cases

    # Remove from format registry
    del _FORMATS[name]

    # Remove extensions that point to this format
    extensions_to_remove = [ext for ext, fmt_name in _EXTENSION_MAP.items() if fmt_name == name]
    for ext in extensions_to_remove:
        del _EXTENSION_MAP[ext]


def get_format(name: str, **kwargs: Any) -> Format:
    """Get format instance by name.

    Args:
        name: Format name (e.g., 'json', 'yaml').
        **kwargs: Format-specific options passed to constructor.

    Returns:
        Format instance.

    Raises:
        FormatError: If format not found.

    Example:
        >>> fmt = get_format('json', indent=4, sort_keys=True)
        >>> data = fmt.write({'key': 'value'}, 'out.json')
    """
    # Lazy initialization
    if not _FORMATS:
        _initialize_registry()

    name_lower = name.lower()

    if name_lower not in _FORMATS:
        raise FormatError(
            f"Unsupported format: {name}",
            format=name,
            suggestion=f"Supported formats: {', '.join(_FORMATS.keys())}",
        )

    format_class = _FORMATS[name_lower]
    return format_class(**kwargs)


def detect_format_from_path(path: str | Path) -> str:
    """Detect format from file path extension.

    Args:
        path: File path.

    Returns:
        Format name.

    Raises:
        FormatError: If format cannot be detected.

    Example:
        >>> detect_format_from_path('config.yaml')
        'yaml'
        >>> detect_format_from_path('data.json')
        'json'
    """
    # Lazy initialization
    if not _EXTENSION_MAP:
        _initialize_registry()

    path_obj = Path(path)

    # Special case: .env files (may be named .env.local, .env.production, etc.)
    if path_obj.name.startswith(".env"):
        return "env"

    ext = path_obj.suffix.lower()

    if not ext:
        raise FormatError(
            f"Cannot detect format from path without extension: {path}",
            suggestion="Provide explicit format or add file extension",
        )

    if ext not in _EXTENSION_MAP:
        extensions = ", ".join(_EXTENSION_MAP.keys())
        raise FormatError(
            f"Cannot detect format from extension: {ext}",
            suggestion=f"Use explicit format or supported extensions: {extensions}",
        )

    return _EXTENSION_MAP[ext]


def list_formats() -> list[str]:
    """List all registered format names.

    Returns:
        Sorted list of format names.
    """
    # Lazy initialization
    if not _FORMATS:
        _initialize_registry()

    return sorted(_FORMATS.keys())


def list_extensions() -> list[str]:
    """List all supported file extensions.

    Returns:
        Sorted list of extensions.
    """
    # Lazy initialization
    if not _EXTENSION_MAP:
        _initialize_registry()

    return sorted(_EXTENSION_MAP.keys())
