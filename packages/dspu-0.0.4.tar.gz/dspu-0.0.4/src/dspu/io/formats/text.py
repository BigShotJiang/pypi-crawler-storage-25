"""Text-based formats (plain text, Python code, environment files)."""

from pathlib import Path
from typing import Any

from dspu.io.formats.base import FormatError

# Optional dependencies
try:
    from dotenv import dotenv_values
except ImportError:
    dotenv_values = None


class TextFormat:
    """Plain text format handler.

    Handles simple string data.

    Example:
        >>> fmt = TextFormat()
        >>> text = "Hello, world!\\nThis is a text file."
        >>> bytes_data = fmt.write(text, "output.txt")
    """

    def __init__(self, *, encoding: str = "utf-8") -> None:
        """Initialize text format.

        Args:
            encoding: Text encoding (default: utf-8).
        """
        self.encoding = encoding

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write string as text bytes."""
        if not isinstance(obj, str):
            raise FormatError(
                f"TextFormat requires str, got {type(obj).__name__} (writing to {path})",
                format="text",
                suggestion="Convert to string first or use StructuredFormat",
            )

        return obj.encode(self.encoding)

    def read(self, data: bytes, path: str | Path | None = None) -> str:
        """Read text bytes to string."""
        try:
            return data.decode(self.encoding)
        except UnicodeDecodeError as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(
                f"Cannot decode text with {self.encoding}{path_info}: {e}",
                format="text",
                suggestion="Try different encoding",
            ) from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is string."""
        return isinstance(obj, str)

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".txt", ".text"]


class PythonFormat(TextFormat):
    """Python source code format handler.

    Handles Python code as text with optional syntax validation.

    Example:
        >>> fmt = PythonFormat(validate_syntax=True)
        >>> code = '''
        ... def hello(name: str) -> str:
        ...     return f"Hello, {name}!"
        ... '''
        >>> bytes_data = fmt.write(code, "utils.py")
    """

    def __init__(
        self,
        *,
        encoding: str = "utf-8",
        validate_syntax: bool = True,
    ) -> None:
        """Initialize Python format.

        Args:
            encoding: Text encoding.
            validate_syntax: Validate Python syntax on write.
        """
        super().__init__(encoding=encoding)
        self.validate_syntax = validate_syntax

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write Python code as text bytes."""
        if not isinstance(obj, str):
            raise FormatError(
                f"PythonFormat requires str, got {type(obj).__name__}",
                format="python",
                suggestion="Convert to Python code string first",
            )

        # Optionally validate syntax
        if self.validate_syntax:
            try:
                compile(obj, str(path), "exec")
            except SyntaxError as e:
                raise FormatError(
                    f"Invalid Python syntax: {e}",
                    format="python",
                    suggestion="Fix syntax errors before writing",
                ) from e

        return obj.encode(self.encoding)

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".py"]


class MarkdownFormat(TextFormat):
    """Markdown format handler.

    Handles Markdown text with optional validation.

    Example:
        >>> fmt = MarkdownFormat()
        >>> markdown = '''
        ... # My Document
        ...
        ... This is a paragraph with **bold** and *italic* text.
        ... '''
        >>> bytes_data = fmt.write(markdown, "README.md")
    """

    def __init__(
        self,
        *,
        encoding: str = "utf-8",
        validate_headers: bool = False,
    ) -> None:
        """Initialize Markdown format.

        Args:
            encoding: Text encoding.
            validate_headers: Check for valid markdown headers.
        """
        super().__init__(encoding=encoding)
        self.validate_headers = validate_headers

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write Markdown as text bytes."""
        if not isinstance(obj, str):
            raise FormatError(
                f"MarkdownFormat requires str, got {type(obj).__name__} (writing to {path})",
                format="markdown",
                suggestion="Convert to Markdown string first",
            )

        # Optional validation: check for common markdown patterns
        if self.validate_headers:
            lines = obj.split("\n")
            has_header = any(line.strip().startswith("#") for line in lines)
            if not has_header:
                # Warning only, not an error
                pass

        return obj.encode(self.encoding)

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".md", ".markdown"]


class EnvFormat:
    """Environment file format handler.

    Handles .env files with KEY=value format.

    Example:
        >>> fmt = EnvFormat()
        >>> env_vars = {
        ...     "DATABASE_URL": "postgresql://localhost/db",
        ...     "SECRET_KEY": "abc123",
        ...     "DEBUG": "true"
        ... }
        >>> bytes_data = fmt.write(env_vars, ".env")
    """

    def __init__(
        self,
        *,
        quote_values: bool = False,
        export_prefix: bool = False,
    ) -> None:
        """Initialize .env format.

        Args:
            quote_values: Quote all values.
            export_prefix: Add 'export ' prefix to lines.
        """
        self.quote_values = quote_values
        self.export_prefix = export_prefix

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write dict as .env format bytes."""
        if not isinstance(obj, dict):
            raise FormatError(
                f"EnvFormat requires dict, got {type(obj).__name__} (writing to {path})",
                format="env",
                suggestion="Convert to dict with string keys and values",
            )

        lines: list[str] = []
        for key, value in obj.items():
            # Validate key (must be valid env var name)
            if not isinstance(key, str):
                raise FormatError(
                    f"Env var keys must be strings, got {type(key).__name__}",
                    format="env",
                    suggestion="Convert keys to strings",
                )

            # Basic validation - allow alphanumeric and underscore
            if not key.replace("_", "").replace("-", "").isalnum():
                raise FormatError(
                    f"Invalid env var name: {key}",
                    format="env",
                    suggestion="Use alphanumeric characters, underscores, and hyphens",
                )

            # Convert value to string
            value_str = str(value)

            # Quote if needed
            if self.quote_values or " " in value_str or "\n" in value_str:
                # Escape quotes in value
                value_str = value_str.replace('"', '\\"')
                value_str = f'"{value_str}"'

            # Build line
            line = f"{key}={value_str}"
            if self.export_prefix:
                line = f"export {line}"

            lines.append(line)

        return "\n".join(lines).encode("utf-8")

    def read(self, data: bytes, path: str | Path | None = None) -> dict[str, str]:
        """Read .env bytes to dict."""
        if dotenv_values is None:
            raise FormatError(
                "Env format requires python-dotenv package",
                format="env",
                suggestion="Install with: pip install python-dotenv",
            )

        try:
            from io import StringIO  # noqa: PLC0415

            content = data.decode("utf-8")
            result = dotenv_values(stream=StringIO(content))
            return {k: v for k, v in result.items() if v is not None}
        except Exception as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(f"Invalid .env format{path_info}: {e}", format="env") from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is env-serializable."""
        return isinstance(obj, dict) and all(isinstance(k, str) for k in obj)

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".env"]
