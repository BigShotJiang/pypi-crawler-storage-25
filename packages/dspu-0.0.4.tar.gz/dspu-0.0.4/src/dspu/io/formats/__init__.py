"""File format writers and readers for dspu.

This module provides an extensible system for reading and writing various
file formats using protocol-based design. Unlike serializers (which handle
binary formats like msgpack and pickle), formats handle text-based structured
data like JSON, YAML, TOML, CSV, etc.

Example:
    >>> from dspu.io import Storage
    >>>
    >>> storage = Storage.from_uri("/data")
    >>>
    >>> # Write YAML with auto-detection
    >>> await storage.write_format("config.yaml", {"debug": True})
    >>>
    >>> # Write CSV with options
    >>> await storage.write_format(
    ...     "data.csv",
    ...     [{"name": "Alice", "age": 30}],
    ...     format_options={"header": True}
    ... )
    >>>
    >>> # Read with auto-detection
    >>> config = await storage.read_format("config.yaml")
"""

from dspu.io.formats.base import (
    Format,
    FormatError,
    FormatReader,
    FormatWriter,
)
from dspu.io.formats.registry import (
    detect_format_from_path,
    get_format,
    list_extensions,
    list_formats,
    register_format,
    unregister_format,
)
from dspu.io.formats.structured import (
    HOCONFormat,
    JSONFormat,
    TOMLFormat,
    YAMLFormat,
)
from dspu.io.formats.tabular import CSVFormat
from dspu.io.formats.text import (
    EnvFormat,
    MarkdownFormat,
    PythonFormat,
    TextFormat,
)

__all__ = [
    "CSVFormat",
    "EnvFormat",
    "Format",
    "FormatError",
    "FormatReader",
    "FormatWriter",
    "HOCONFormat",
    "JSONFormat",
    "MarkdownFormat",
    "PythonFormat",
    "TOMLFormat",
    "TextFormat",
    "YAMLFormat",
    "detect_format_from_path",
    "get_format",
    "list_extensions",
    "list_formats",
    "register_format",
    "unregister_format",
]
