"""Tabular data formats (CSV, TSV)."""

import csv
from io import StringIO
from pathlib import Path
from typing import Any

from dspu.io.formats.base import FormatError


class CSVFormat:
    """CSV format handler for tabular data.

    Handles list of dicts (each dict is a row) or 2D lists.

    Example:
        >>> fmt = CSVFormat(header=True)
        >>> data = [
        ...     {"name": "Alice", "age": 30, "city": "NYC"},
        ...     {"name": "Bob", "age": 25, "city": "LA"},
        ... ]
        >>> bytes_data = fmt.write(data, "users.csv")
    """

    def __init__(
        self,
        *,
        delimiter: str = ",",
        quoting: int = csv.QUOTE_MINIMAL,
        header: bool = True,
        encoding: str = "utf-8",
    ) -> None:
        """Initialize CSV format.

        Args:
            delimiter: Field delimiter (default: comma).
            quoting: Quoting style (csv.QUOTE_* constants).
            header: Include header row (for dict input).
            encoding: Text encoding.
        """
        self.delimiter = delimiter
        self.quoting = quoting
        self.header = header
        self.encoding = encoding

    def write(self, obj: Any, path: str | Path) -> bytes:
        """Write tabular data as CSV bytes."""
        # Validate and normalize input
        if not isinstance(obj, list):
            raise FormatError(
                f"CSVFormat requires list, got {type(obj).__name__} (writing to {path})",
                format="csv",
                suggestion="Convert to list of dicts or list of lists",
            )

        if len(obj) == 0:
            raise FormatError(
                "Cannot write empty list to CSV",
                format="csv",
                suggestion="Provide at least one row of data",
            )

        first_item = obj[0]

        if isinstance(first_item, dict):
            # List of dicts - use DictWriter
            return self._write_dict_rows(obj)
        if isinstance(first_item, (list, tuple)):
            # List of lists/tuples - use regular writer
            return self._write_list_rows(obj)
        item_type = type(first_item).__name__
        raise FormatError(
            f"CSVFormat requires list of dicts or list of lists, got list of {item_type}",
            format="csv",
            suggestion="Convert rows to dicts or lists",
        )

    def _write_dict_rows(self, rows: list[dict[str, Any]]) -> bytes:
        """Write list of dicts to CSV."""
        output = StringIO()

        # Get fieldnames from first row
        fieldnames = list(rows[0].keys())

        writer = csv.DictWriter(
            output,
            fieldnames=fieldnames,
            delimiter=self.delimiter,
            quoting=self.quoting,  # type: ignore[arg-type]
        )

        if self.header:
            writer.writeheader()

        writer.writerows(rows)

        return output.getvalue().encode(self.encoding)

    def _write_list_rows(self, rows: list[list[Any]]) -> bytes:
        """Write 2D list to CSV."""
        output = StringIO()
        writer = csv.writer(
            output,
            delimiter=self.delimiter,
            quoting=self.quoting,  # type: ignore[arg-type]
        )
        writer.writerows(rows)

        return output.getvalue().encode(self.encoding)

    def read(self, data: bytes, path: str | Path | None = None) -> list[dict[str, str]]:
        """Read CSV bytes to list of dicts."""
        try:
            content = data.decode(self.encoding)
            reader = csv.DictReader(StringIO(content), delimiter=self.delimiter)

            return list(reader)
        except Exception as e:
            path_info = f" from {path}" if path else ""
            raise FormatError(
                f"Invalid CSV{path_info}: {e}",
                format="csv",
                suggestion="Check CSV syntax and encoding",
            ) from e

    def can_write(self, obj: Any) -> bool:
        """Check if object is CSV-serializable."""
        if not isinstance(obj, list) or len(obj) == 0:
            return False

        first = obj[0]
        return isinstance(first, (dict, list, tuple))

    @property
    def extensions(self) -> list[str]:
        """Supported extensions."""
        return [".csv"]
