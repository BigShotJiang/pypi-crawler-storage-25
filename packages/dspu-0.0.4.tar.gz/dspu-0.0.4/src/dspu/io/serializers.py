"""Serialization framework for various data formats.

This module provides a unified interface for serializing/deserializing data
in different formats (JSON, MessagePack, Pickle).
"""

import json
import pickle
import warnings
from typing import Any, Protocol, runtime_checkable

from dspu.core.exceptions import DSPUError

# Optional dependencies
try:
    import orjson
except ImportError:
    orjson = None

try:
    import msgpack
except ImportError:
    msgpack = None


class SerializationError(DSPUError):
    """Raised when serialization/deserialization fails.

    Attributes:
        format: The serialization format that caused the error.
        suggestion: A helpful suggestion for fixing the error.
    """

    def __init__(
        self,
        message: str,
        *,
        format: str | None = None,  # noqa: A002
        suggestion: str | None = None,
    ) -> None:
        """Initialize serialization error.

        Args:
            message: Error message describing the problem.
            format: The serialization format that caused the error.
            suggestion: A helpful suggestion for fixing the error.
        """
        super().__init__(message)
        self.format = format
        self.suggestion = suggestion

    def __str__(self) -> str:
        """Format error message with details."""
        parts = [super().__str__()]

        if self.format:
            parts.append(f"Format: {self.format}")

        if self.suggestion:
            parts.append(f"Suggestion: {self.suggestion}")

        return "\n".join(parts)


@runtime_checkable
class Serializer(Protocol):
    """Protocol for serializer implementations.

    All serializers must implement serialize and deserialize methods.
    """

    def serialize(self, obj: Any) -> bytes:
        """Serialize object to bytes.

        Args:
            obj: Object to serialize.

        Returns:
            Serialized bytes.

        Raises:
            SerializationError: If serialization fails.
        """
        ...

    def deserialize(self, data: bytes) -> Any:
        """Deserialize bytes to object.

        Args:
            data: Serialized bytes.

        Returns:
            Deserialized object.

        Raises:
            SerializationError: If deserialization fails.
        """
        ...


class JSONSerializer:
    """JSON serializer with optional orjson support.

    Uses orjson if available for better performance, falls back to stdlib json.

    Example:
        >>> serializer = JSONSerializer()
        >>> data = {"name": "John", "age": 30}
        >>> serialized = serializer.serialize(data)
        >>> restored = serializer.deserialize(serialized)
        >>> assert restored == data
    """

    def __init__(self, *, indent: int | None = None, sort_keys: bool = False) -> None:
        """Initialize JSON serializer.

        Args:
            indent: Indentation level (None = compact).
            sort_keys: Whether to sort dictionary keys.
        """
        self.indent = indent
        self.sort_keys = sort_keys
        self.use_orjson = orjson is not None

    def serialize(self, obj: Any) -> bytes:
        """Serialize object to JSON bytes.

        Args:
            obj: Object to serialize (must be JSON-serializable).

        Returns:
            JSON bytes (UTF-8 encoded).

        Raises:
            SerializationError: If object is not JSON-serializable.
        """
        try:
            if self.use_orjson:
                assert orjson is not None  # Type narrowing
                # orjson always returns bytes
                option = 0
                if self.indent is not None:
                    option |= orjson.OPT_INDENT_2
                if self.sort_keys:
                    option |= orjson.OPT_SORT_KEYS

                result: bytes = orjson.dumps(obj, option=option)
                return result

            # Fallback to stdlib json
            json_str = json.dumps(
                obj,
                indent=self.indent,
                sort_keys=self.sort_keys,
                ensure_ascii=False,
            )
            return json_str.encode("utf-8")

        except (TypeError, ValueError) as e:
            raise SerializationError(
                f"Failed to serialize to JSON: {e}",
                suggestion="Ensure object contains only JSON-serializable types",
            ) from e

    def deserialize(self, data: bytes) -> Any:
        """Deserialize JSON bytes to object.

        Args:
            data: JSON bytes (UTF-8 encoded).

        Returns:
            Deserialized object.

        Raises:
            SerializationError: If data is not valid JSON.
        """
        try:
            if self.use_orjson:
                assert orjson is not None  # Type narrowing
                return orjson.loads(data)

            # Fallback to stdlib json
            return json.loads(data.decode("utf-8"))

        except (json.JSONDecodeError, ValueError, UnicodeDecodeError) as e:
            raise SerializationError(
                f"Failed to deserialize JSON: {e}",
                suggestion="Ensure data is valid JSON",
            ) from e


class MessagePackSerializer:
    """MessagePack serializer.

    MessagePack is a binary serialization format that's more compact
    and faster than JSON.

    Requires: pip install msgpack

    Example:
        >>> serializer = MessagePackSerializer()
        >>> data = {"name": "John", "values": [1, 2, 3, 4, 5]}
        >>> serialized = serializer.serialize(data)
        >>> restored = serializer.deserialize(serialized)
        >>> assert restored == data
    """

    def __init__(self, *, use_bin_type: bool = True) -> None:
        """Initialize MessagePack serializer.

        Args:
            use_bin_type: Use binary type for bytes (recommended).

        Raises:
            SerializationError: If msgpack is not installed.
        """
        if msgpack is None:
            raise SerializationError(
                "MessagePack serialization requires msgpack package",
                suggestion="Install with: pip install msgpack",
            )

        # Type narrowing: msgpack is guaranteed to be available after this point
        assert msgpack is not None
        self.use_bin_type = use_bin_type

    def serialize(self, obj: Any) -> bytes:
        """Serialize object to MessagePack bytes.

        Args:
            obj: Object to serialize.

        Returns:
            MessagePack bytes.

        Raises:
            SerializationError: If serialization fails.
        """
        assert msgpack is not None  # Guaranteed by __init__ check
        try:
            result: bytes = msgpack.packb(obj, use_bin_type=self.use_bin_type)
            return result
        except (TypeError, ValueError) as e:
            raise SerializationError(
                f"Failed to serialize to MessagePack: {e}",
                suggestion="Ensure object contains MessagePack-compatible types",
            ) from e

    def deserialize(self, data: bytes) -> Any:
        """Deserialize MessagePack bytes to object.

        Args:
            data: MessagePack bytes.

        Returns:
            Deserialized object.

        Raises:
            SerializationError: If deserialization fails.
        """
        assert msgpack is not None  # Guaranteed by __init__ check
        try:
            return msgpack.unpackb(data, raw=False)
        except (msgpack.exceptions.ExtraData, ValueError) as e:
            raise SerializationError(
                f"Failed to deserialize MessagePack: {e}",
                suggestion="Ensure data is valid MessagePack",
            ) from e


class PickleSerializer:
    """Pickle serializer with security warnings.

    WARNING: Pickle is insecure. Only use with trusted data.
    Pickle can execute arbitrary code during deserialization.

    Example:
        >>> serializer = PickleSerializer()
        >>> data = {"complex": object(), "nested": {"list": [1, 2, 3]}}
        >>> serialized = serializer.serialize(data)
        >>> restored = serializer.deserialize(serialized)
    """

    def __init__(self, *, protocol: int | None = None) -> None:
        """Initialize Pickle serializer.

        Issues a security warning on initialization.

        Args:
            protocol: Pickle protocol version (None = highest).
        """
        self.protocol = protocol

        # Warn about security risks
        warnings.warn(
            "PickleSerializer uses pickle, which is insecure. "
            "Only use with trusted data. Consider JSON or MessagePack instead.",
            UserWarning,
            stacklevel=2,
        )

    def serialize(self, obj: Any) -> bytes:
        """Serialize object to pickle bytes.

        Args:
            obj: Object to serialize.

        Returns:
            Pickle bytes.

        Raises:
            SerializationError: If serialization fails.
        """
        try:
            return pickle.dumps(obj, protocol=self.protocol)
        except (pickle.PicklingError, TypeError) as e:
            raise SerializationError(
                f"Failed to serialize with pickle: {e}",
                suggestion="Ensure object is picklable",
            ) from e

    def deserialize(self, data: bytes) -> Any:
        """Deserialize pickle bytes to object.

        WARNING: This can execute arbitrary code. Only use with trusted data.

        Args:
            data: Pickle bytes.

        Returns:
            Deserialized object.

        Raises:
            SerializationError: If deserialization fails.
        """
        try:
            return pickle.loads(data)  # noqa: S301
        except (pickle.UnpicklingError, ValueError, AttributeError) as e:
            raise SerializationError(
                f"Failed to deserialize pickle: {e}",
                suggestion="Ensure data is valid pickle format",
            ) from e


# Registry of available serializers
_SERIALIZERS: dict[str, type[Serializer]] = {
    "json": JSONSerializer,
    "msgpack": MessagePackSerializer,
    "pickle": PickleSerializer,
}


def get_serializer(format: str) -> Serializer:  # noqa: A002
    """Get serializer instance for format.

    Args:
        format: Serialization format (json, msgpack, pickle).

    Returns:
        Serializer instance.

    Raises:
        SerializationError: If format is not supported.

    Example:
        >>> serializer = get_serializer("json")
        >>> data = serializer.serialize({"key": "value"})
    """
    format_lower = format.lower()

    if format_lower not in _SERIALIZERS:
        raise SerializationError(
            f"Unsupported serialization format: {format}",
            suggestion=f"Supported formats: {', '.join(_SERIALIZERS.keys())}",
        )

    serializer_class = _SERIALIZERS[format_lower]
    return serializer_class()


def detect_format(path: str) -> str:
    """Detect serialization format from file extension.

    Args:
        path: File path or name.

    Returns:
        Detected format string.

    Raises:
        SerializationError: If format cannot be detected.

    Example:
        >>> detect_format("data.json")
        'json'
        >>> detect_format("model.pkl")
        'pickle'
    """
    # Map extensions to formats
    extension_map = {
        ".json": "json",
        ".msgpack": "msgpack",
        ".msgpk": "msgpack",
        ".mp": "msgpack",
        ".pkl": "pickle",
        ".pickle": "pickle",
    }

    # Extract extension
    if "." in path:
        ext = "." + path.rsplit(".", 1)[-1].lower()
        if ext in extension_map:
            return extension_map[ext]

    raise SerializationError(
        f"Cannot detect format from path: {path}",
        suggestion=f"Specify format explicitly or use known extensions: "
        f"{', '.join(extension_map.keys())}",
    )


def serialize(obj: Any, format: str) -> bytes:  # noqa: A002
    """Serialize object to bytes.

    Convenience function for one-off serialization.

    Args:
        obj: Object to serialize.
        format: Serialization format.

    Returns:
        Serialized bytes.

    Example:
        >>> data = {"name": "Alice", "age": 30}
        >>> bytes_data = serialize(data, "json")
        >>> restored = deserialize(bytes_data, "json")
        >>> assert restored == data
    """
    serializer = get_serializer(format)
    return serializer.serialize(obj)


def deserialize(data: bytes, format: str) -> Any:  # noqa: A002
    """Deserialize bytes to object.

    Convenience function for one-off deserialization.

    Args:
        data: Serialized bytes.
        format: Serialization format.

    Returns:
        Deserialized object.

    Example:
        >>> serialized = serialize({"key": "value"}, "json")
        >>> obj = deserialize(serialized, "json")
        >>> print(obj)
        {'key': 'value'}
    """
    serializer = get_serializer(format)
    return serializer.deserialize(data)
