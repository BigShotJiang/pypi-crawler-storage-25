"""I/O operations and storage abstractions.

This module provides unified interfaces for reading/writing data across
different storage backends (local, S3, GCS, Azure) with automatic
serialization support and multi-format file writing.

Example:
    >>> from dspu.io import Storage
    >>>
    >>> # Local storage with serializers (binary formats)
    >>> storage = Storage.from_uri("/data")
    >>> await storage.write("config.json", {"debug": True})
    >>> config = await storage.read("config.json")
    >>>
    >>> # Format writers (text-based formats)
    >>> await storage.write_format("config.yaml", {"debug": True})
    >>> await storage.write_format("data.csv", [{"name": "Alice", "age": 30}])
    >>>
    >>> # S3 storage (requires fsspec)
    >>> storage = Storage.from_uri("s3://my-bucket/path")
    >>> await storage.write("data.msgpack", large_dataset)
"""

from dspu.io.backends import FileInfo, StorageBackend
from dspu.io.formats import (
    CSVFormat,
    EnvFormat,
    Format,
    FormatError,
    FormatReader,
    FormatWriter,
    HOCONFormat,
    JSONFormat,
    MarkdownFormat,
    PythonFormat,
    TextFormat,
    TOMLFormat,
    YAMLFormat,
    detect_format_from_path,
    get_format,
    list_extensions,
    list_formats,
    register_format,
    unregister_format,
)
from dspu.io.local import LocalBackend
from dspu.io.paths import PathResolver, resolve_path
from dspu.io.serializers import (
    JSONSerializer,
    MessagePackSerializer,
    PickleSerializer,
    SerializationError,
    Serializer,
    deserialize,
    detect_format,
    get_serializer,
    serialize,
)
from dspu.io.storage import Storage

__all__ = [
    "CSVFormat",
    "EnvFormat",
    "FileInfo",
    "Format",
    "FormatError",
    "FormatReader",
    "FormatWriter",
    "HOCONFormat",
    "JSONFormat",
    "JSONSerializer",
    "LocalBackend",
    "MarkdownFormat",
    "MessagePackSerializer",
    "PathResolver",
    "PickleSerializer",
    "PythonFormat",
    "SerializationError",
    "Serializer",
    "Storage",
    "StorageBackend",
    "TOMLFormat",
    "TextFormat",
    "YAMLFormat",
    "deserialize",
    "detect_format",
    "detect_format_from_path",
    "get_format",
    "get_serializer",
    "list_extensions",
    "list_formats",
    "register_format",
    "resolve_path",
    "serialize",
    "unregister_format",
]
