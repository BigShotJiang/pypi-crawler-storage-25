"""Secret backend implementations.

This module provides various backend implementations for secret storage.
"""

import json
import os
from pathlib import Path
from typing import Any

import yaml

from dspu.core.exceptions import SecurityError


class EnvBackend:
    """Environment variable backend for secrets.

    Reads secrets from environment variables with optional prefix.
    Key paths are converted to uppercase with underscores.

    Example:
        >>> backend = EnvBackend(prefix="APP_SECRET_")
        >>> # Gets from APP_SECRET_API_KEY
        >>> api_key = await backend.get("api/key")
    """

    def __init__(self, prefix: str = "", separator: str = "_") -> None:
        """Initialize environment backend.

        Args:
            prefix: Prefix for all environment variables.
            separator: Separator for nested keys (default: _).
        """
        self.prefix = prefix
        self.separator = separator

    def _key_to_env(self, key: str) -> str:
        """Convert secret key to environment variable name.

        Args:
            key: Secret key (e.g., "database/password").

        Returns:
            Environment variable name (e.g., "APP_SECRET_DATABASE_PASSWORD").
        """
        # Replace / with separator and convert to uppercase
        env_key = key.replace("/", self.separator).replace("-", self.separator)
        env_key = env_key.upper()
        return f"{self.prefix}{env_key}"

    def _env_to_key(self, env_name: str) -> str:
        """Convert environment variable name back to secret key.

        Args:
            env_name: Environment variable name.

        Returns:
            Secret key.
        """
        # Remove prefix
        if self.prefix and env_name.startswith(self.prefix):
            key = env_name[len(self.prefix) :]
        else:
            key = env_name

        # Convert to lowercase and replace separator with /
        key = key.lower().replace(self.separator, "/")
        return key

    async def get(self, key: str) -> str:
        """Get secret from environment variable."""
        env_key = self._key_to_env(key)
        value = os.getenv(env_key)

        if value is None:
            raise KeyError(f"Environment variable not found: {env_key}")

        return value

    async def set(self, key: str, value: str) -> None:
        """Set environment variable (runtime only, not persistent)."""
        env_key = self._key_to_env(key)
        os.environ[env_key] = value

    async def delete(self, key: str) -> None:
        """Delete environment variable."""
        env_key = self._key_to_env(key)
        if env_key not in os.environ:
            raise KeyError(f"Environment variable not found: {env_key}")
        del os.environ[env_key]

    async def exists(self, key: str) -> bool:
        """Check if environment variable exists."""
        env_key = self._key_to_env(key)
        return env_key in os.environ

    async def list(self, prefix: str = "") -> list[str]:
        """List environment variables matching prefix."""
        keys = []
        env_prefix = self._key_to_env(prefix) if prefix else self.prefix

        for env_name in os.environ:
            if env_name.startswith(env_prefix):
                key = self._env_to_key(env_name)
                if not prefix or key.startswith(prefix):
                    keys.append(key)

        return sorted(keys)


class FileBackend:
    """File-based backend for secrets (development only).

    Reads secrets from a JSON or YAML file. This backend is intended
    for local development and testing only. DO NOT use in production.

    Example:
        >>> backend = FileBackend("secrets.yaml")
        >>> password = await backend.get("database/password")
    """

    def __init__(self, path: str | Path, auto_save: bool = True) -> None:
        """Initialize file backend.

        Args:
            path: Path to secrets file (JSON or YAML).
            auto_save: Auto-save changes to file (default: True).
        """
        self.path = Path(path)
        self.auto_save = auto_save
        self._secrets: dict[str, Any] = {}
        self._loaded = False

    async def _load(self) -> None:
        """Load secrets from file."""
        if self._loaded:
            return

        if not self.path.exists():
            self._secrets = {}
            self._loaded = True
            return

        content = self.path.read_text()
        suffix = self.path.suffix.lower()

        if suffix == ".json":
            self._secrets = json.loads(content)
        elif suffix in (".yaml", ".yml"):
            self._secrets = yaml.safe_load(content) or {}
        else:
            raise SecurityError(
                f"Unsupported file format: {suffix}",
                reason="Only JSON and YAML formats supported",
            )

        self._loaded = True

    async def _save(self) -> None:
        """Save secrets to file."""
        if not self.auto_save:
            return

        suffix = self.path.suffix.lower()

        if suffix == ".json":
            content = json.dumps(self._secrets, indent=2)
        elif suffix in (".yaml", ".yml"):
            content = yaml.safe_dump(self._secrets, default_flow_style=False)
        else:
            raise SecurityError(
                f"Unsupported file format: {suffix}",
                reason="Only JSON and YAML formats supported",
            )

        # Ensure directory exists
        self.path.parent.mkdir(parents=True, exist_ok=True)

        # Write with restrictive permissions (600)
        self.path.write_text(content)
        self.path.chmod(0o600)

    def _get_nested(self, key: str) -> str:
        """Get value from nested dictionary using path."""
        parts = key.split("/")
        current = self._secrets

        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                raise KeyError(f"Key not found: {key}")
            current = current[part]

        last_part = parts[-1]
        if last_part not in current:
            raise KeyError(f"Key not found: {key}")

        value = current[last_part]
        return str(value)

    def _set_nested(self, key: str, value: str) -> None:
        """Set value in nested dictionary using path."""
        parts = key.split("/")
        current = self._secrets

        # Create nested structure
        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                current[part] = {}
            current = current[part]

        current[parts[-1]] = value

    def _delete_nested(self, key: str) -> None:
        """Delete value from nested dictionary using path."""
        parts = key.split("/")
        current = self._secrets

        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                raise KeyError(f"Key not found: {key}")
            current = current[part]

        last_part = parts[-1]
        if last_part not in current:
            raise KeyError(f"Key not found: {key}")

        del current[last_part]

    async def get(self, key: str) -> str:
        """Get secret from file."""
        await self._load()
        return self._get_nested(key)

    async def set(self, key: str, value: str) -> None:
        """Set secret in file."""
        await self._load()
        self._set_nested(key, value)
        await self._save()

    async def delete(self, key: str) -> None:
        """Delete secret from file."""
        await self._load()
        self._delete_nested(key)
        await self._save()

    async def exists(self, key: str) -> bool:
        """Check if secret exists in file."""
        await self._load()
        try:
            self._get_nested(key)
            return True
        except KeyError:
            return False

    async def list(self, prefix: str = "") -> list[str]:
        """List secret keys from file."""
        await self._load()

        def collect_keys(d: dict[str, Any], current_path: str = "") -> list[str]:
            keys = []
            for key, value in d.items():
                path = f"{current_path}/{key}" if current_path else key
                if isinstance(value, dict):
                    keys.extend(collect_keys(value, path))
                else:
                    keys.append(path)
            return keys

        all_keys = collect_keys(self._secrets)

        if prefix:
            return sorted([k for k in all_keys if k.startswith(prefix)])
        return sorted(all_keys)


class VaultBackend:
    """HashiCorp Vault backend for secrets.

    Connects to Vault server for secure secret storage and retrieval.

    Example:
        >>> backend = VaultBackend(
        ...     url="http://localhost:8200",
        ...     token="dev-token",
        ...     mount_point="secret"
        ... )
        >>> password = await backend.get("database/password")
    """

    def __init__(
        self,
        url: str,
        token: str,
        mount_point: str = "secret",
        **kwargs: Any,
    ) -> None:
        """Initialize Vault backend.

        Args:
            url: Vault server URL.
            token: Vault authentication token.
            mount_point: Vault mount point (default: "secret").
            **kwargs: Additional hvac client options.

        Raises:
            ConfigurationError: If hvac not installed.
        """
        try:
            import hvac
        except ImportError as e:
            from dspu.core.exceptions import ConfigurationError

            raise ConfigurationError(
                "Vault backend requires hvac package",
                suggestion="Install with: pip install hvac",
            ) from e

        self.url = url
        self.token = token
        self.mount_point = mount_point
        self._client = hvac.Client(url=url, token=token, **kwargs)

        # Verify connection
        if not self._client.is_authenticated():
            raise SecurityError(
                "Vault authentication failed",
                reason="Invalid token or server unreachable",
                resource=url,
            )

    async def get(self, key: str) -> str:
        """Get secret from Vault."""
        try:
            response = self._client.secrets.kv.v2.read_secret_version(
                path=key,
                mount_point=self.mount_point,
            )
            data = response["data"]["data"]

            # If the secret has a 'value' field, return it
            # Otherwise return the entire data as JSON
            if "value" in data:
                return str(data["value"])
            return json.dumps(data)

        except Exception as e:
            if "404" in str(e) or "not found" in str(e).lower():
                raise KeyError(f"Secret not found: {key}") from e
            raise SecurityError(
                f"Failed to read secret from Vault: {e}",
                reason=str(e),
                resource=key,
            ) from e

    async def set(self, key: str, value: str) -> None:
        """Set secret in Vault."""
        try:
            self._client.secrets.kv.v2.create_or_update_secret(
                path=key,
                secret={"value": value},
                mount_point=self.mount_point,
            )
        except Exception as e:
            raise SecurityError(
                f"Failed to write secret to Vault: {e}",
                reason=str(e),
                resource=key,
            ) from e

    async def delete(self, key: str) -> None:
        """Delete secret from Vault."""
        try:
            self._client.secrets.kv.v2.delete_metadata_and_all_versions(
                path=key,
                mount_point=self.mount_point,
            )
        except Exception as e:
            if "404" in str(e) or "not found" in str(e).lower():
                raise KeyError(f"Secret not found: {key}") from e
            raise SecurityError(
                f"Failed to delete secret from Vault: {e}",
                reason=str(e),
                resource=key,
            ) from e

    async def exists(self, key: str) -> bool:
        """Check if secret exists in Vault."""
        try:
            await self.get(key)
            return True
        except KeyError:
            return False

    async def list(self, prefix: str = "") -> list[str]:
        """List secret keys from Vault."""
        try:
            # List keys at the prefix path
            path = prefix.rstrip("/")
            response = self._client.secrets.kv.v2.list_secrets(
                path=path if path else "",
                mount_point=self.mount_point,
            )
            keys = response["data"]["keys"]

            # Add prefix back to keys
            if prefix:
                return sorted([f"{prefix}/{k}".rstrip("/") for k in keys])
            return sorted(keys)

        except Exception as e:
            if "404" in str(e) or "not found" in str(e).lower():
                return []
            raise SecurityError(
                f"Failed to list secrets from Vault: {e}",
                reason=str(e),
            ) from e


class AWSSecretBackend:
    """AWS Secrets Manager backend.

    Uses AWS Secrets Manager for secure secret storage.

    Example:
        >>> backend = AWSSecretBackend(region="us-west-2")
        >>> api_key = await backend.get("prod/api/key")
    """

    def __init__(self, region: str = "us-east-1", **kwargs: Any) -> None:
        """Initialize AWS Secrets Manager backend.

        Args:
            region: AWS region.
            **kwargs: Additional boto3 client options.

        Raises:
            ConfigurationError: If boto3 not installed.
        """
        try:
            import boto3
        except ImportError as e:
            from dspu.core.exceptions import ConfigurationError

            raise ConfigurationError(
                "AWS backend requires boto3 package",
                suggestion="Install with: pip install boto3",
            ) from e

        self.region = region
        self._client = boto3.client("secretsmanager", region_name=region, **kwargs)

    async def get(self, key: str) -> str:
        """Get secret from AWS Secrets Manager."""
        try:
            response = self._client.get_secret_value(SecretId=key)

            # Return the secret string
            if "SecretString" in response:
                return response["SecretString"]

            # For binary secrets, decode
            import base64

            return base64.b64decode(response["SecretBinary"]).decode("utf-8")

        except self._client.exceptions.ResourceNotFoundException:
            raise KeyError(f"Secret not found: {key}") from None
        except Exception as e:
            raise SecurityError(
                f"Failed to read secret from AWS: {e}",
                reason=str(e),
                resource=key,
            ) from e

    async def set(self, key: str, value: str) -> None:
        """Set secret in AWS Secrets Manager."""
        try:
            # Try to update existing secret
            self._client.update_secret(SecretId=key, SecretString=value)
        except self._client.exceptions.ResourceNotFoundException:
            # Create new secret if it doesn't exist
            try:
                self._client.create_secret(Name=key, SecretString=value)
            except Exception as e:
                raise SecurityError(
                    f"Failed to create secret in AWS: {e}",
                    reason=str(e),
                    resource=key,
                ) from e
        except Exception as e:
            raise SecurityError(
                f"Failed to write secret to AWS: {e}",
                reason=str(e),
                resource=key,
            ) from e

    async def delete(self, key: str) -> None:
        """Delete secret from AWS Secrets Manager."""
        try:
            self._client.delete_secret(
                SecretId=key,
                ForceDeleteWithoutRecovery=True,
            )
        except self._client.exceptions.ResourceNotFoundException:
            raise KeyError(f"Secret not found: {key}") from None
        except Exception as e:
            raise SecurityError(
                f"Failed to delete secret from AWS: {e}",
                reason=str(e),
                resource=key,
            ) from e

    async def exists(self, key: str) -> bool:
        """Check if secret exists in AWS Secrets Manager."""
        try:
            self._client.describe_secret(SecretId=key)
            return True
        except self._client.exceptions.ResourceNotFoundException:
            return False
        except Exception:
            return False

    async def list(self, prefix: str = "") -> list[str]:
        """List secret keys from AWS Secrets Manager."""
        try:
            secrets = []
            paginator = self._client.get_paginator("list_secrets")

            for page in paginator.paginate():
                for secret in page["SecretList"]:
                    name = secret["Name"]
                    if not prefix or name.startswith(prefix):
                        secrets.append(name)

            return sorted(secrets)

        except Exception as e:
            raise SecurityError(
                f"Failed to list secrets from AWS: {e}",
                reason=str(e),
            ) from e
