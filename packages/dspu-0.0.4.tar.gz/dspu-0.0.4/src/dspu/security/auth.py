"""Authentication provider implementations.

This module provides authentication providers for various schemes.
"""

import time
from typing import Any

from dspu.core.exceptions import ConfigurationError
from dspu.security.exceptions import AuthenticationError
from dspu.security.rotating_token import TokenData


class StaticTokenProvider:
    """Static token authentication provider.

    Simple provider that returns a fixed token. Useful for development
    and services that use long-lived API keys.

    Example:
        >>> provider = StaticTokenProvider(token="my-api-key-123")
        >>> token = await provider.get_token()
        >>> print(token)  # "my-api-key-123"
    """

    def __init__(self, token: str) -> None:
        """Initialize static token provider.

        Args:
            token: Static token value.
        """
        self._token = token

    async def get_token(self, scopes: list[str] | None = None) -> str:
        """Get the static token.

        Args:
            scopes: Ignored for static tokens.

        Returns:
            Static token value.
        """
        return self._token

    async def refresh_token(self) -> str:
        """Refresh token (returns same token for static provider).

        Returns:
            Static token value.
        """
        return self._token

    async def revoke_token(self) -> None:
        """Revoke token (no-op for static provider)."""
        pass

    async def validate_token(self, token: str) -> bool:
        """Validate token.

        Args:
            token: Token to validate.

        Returns:
            True if matches static token, False otherwise.
        """
        return token == self._token


class OAuth2Provider:
    """OAuth2 authentication provider.

    Implements OAuth2 client credentials flow for service-to-service
    authentication.

    Example:
        >>> provider = OAuth2Provider(
        ...     client_id="my-client-id",
        ...     client_secret="my-client-secret",
        ...     token_url="https://auth.example.com/oauth/token"
        ... )
        >>> token = await provider.get_token(scopes=["read", "write"])
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        token_url: str,
        **kwargs: Any,
    ) -> None:
        """Initialize OAuth2 provider.

        Args:
            client_id: OAuth2 client ID.
            client_secret: OAuth2 client secret.
            token_url: Token endpoint URL.
            **kwargs: Additional httpx options.

        Raises:
            ConfigurationError: If httpx not installed.
        """
        try:
            import httpx

            self._httpx = httpx
        except ImportError as e:
            raise ConfigurationError(
                "OAuth2 provider requires httpx package",
                suggestion="Install with: pip install dspu[async]",
            ) from e

        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = token_url
        self.kwargs = kwargs

        self._current_token: TokenData | None = None

    async def get_token(self, scopes: list[str] | None = None) -> str:
        """Get OAuth2 access token.

        Args:
            scopes: OAuth2 scopes to request.

        Returns:
            Access token.

        Raises:
            AuthenticationError: If token request fails.
        """
        # Check if we have a valid cached token
        if self._current_token is not None and not self._current_token.is_expired():
            # Check if scopes match
            if scopes is None or set(scopes).issubset(set(self._current_token.scopes)):
                return self._current_token.token

        # Request new token
        await self._request_token(scopes)

        if self._current_token is None:
            raise AuthenticationError(
                "Failed to obtain OAuth2 token",
                provider="oauth2",
            )

        return self._current_token.token

    async def _request_token(self, scopes: list[str] | None = None) -> None:
        """Request new OAuth2 token.

        Args:
            scopes: OAuth2 scopes to request.

        Raises:
            AuthenticationError: If request fails.
        """
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        if scopes:
            data["scope"] = " ".join(scopes)

        try:
            async with self._httpx.AsyncClient(**self.kwargs) as client:
                response = await client.post(
                    self.token_url,
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
                response.raise_for_status()
                token_data = response.json()

            # Parse token response
            access_token = token_data.get("access_token")
            if not access_token:
                raise AuthenticationError(
                    "No access token in OAuth2 response",
                    provider="oauth2",
                )

            expires_in = token_data.get("expires_in")
            expires_at = time.time() + expires_in if expires_in else None

            returned_scopes = []
            if "scope" in token_data:
                returned_scopes = token_data["scope"].split()

            self._current_token = TokenData(
                token=access_token,
                expires_at=expires_at,
                scopes=returned_scopes or (scopes or []),
                metadata=token_data,
            )

        except Exception as e:
            raise AuthenticationError(
                f"OAuth2 token request failed: {e}",
                provider="oauth2",
                reason=str(e),
            ) from e

    async def refresh_token(self) -> str:
        """Refresh OAuth2 token.

        Returns:
            New access token.

        Raises:
            AuthenticationError: If refresh fails.
        """
        scopes = self._current_token.scopes if self._current_token else None
        await self._request_token(scopes)

        if self._current_token is None:
            raise AuthenticationError(
                "Failed to refresh OAuth2 token",
                provider="oauth2",
            )

        return self._current_token.token

    async def revoke_token(self) -> None:
        """Revoke OAuth2 token (no-op, tokens expire naturally)."""
        self._current_token = None

    async def validate_token(self, token: str) -> bool:
        """Validate OAuth2 token.

        Args:
            token: Token to validate.

        Returns:
            True if token matches current valid token.
        """
        if self._current_token is None:
            return False

        return token == self._current_token.token and not self._current_token.is_expired()


class JWTProvider:
    """JWT (JSON Web Token) authentication provider.

    Creates and validates JWT tokens for authentication.

    Example:
        >>> provider = JWTProvider(
        ...     secret_key="my-secret-key",
        ...     algorithm="HS256"
        ... )
        >>> token = await provider.get_token()
    """

    def __init__(
        self,
        secret_key: str,
        algorithm: str = "HS256",
        issuer: str | None = None,
        audience: str | None = None,
        expiry_seconds: int = 3600,
        **kwargs: Any,
    ) -> None:
        """Initialize JWT provider.

        Args:
            secret_key: Secret key for signing JWTs.
            algorithm: JWT algorithm (default: HS256).
            issuer: Token issuer claim.
            audience: Token audience claim.
            expiry_seconds: Token expiry time in seconds (default: 3600).
            **kwargs: Additional JWT claims.

        Raises:
            ConfigurationError: If pyjwt not installed.
        """
        try:
            import jwt

            self._jwt = jwt
        except ImportError as e:
            raise ConfigurationError(
                "JWT provider requires pyjwt package",
                suggestion="Install with: pip install dspu[security]",
            ) from e

        self.secret_key = secret_key
        self.algorithm = algorithm
        self.issuer = issuer
        self.audience = audience
        self.expiry_seconds = expiry_seconds
        self.kwargs = kwargs

        self._current_token: TokenData | None = None

    async def get_token(self, scopes: list[str] | None = None) -> str:
        """Generate JWT token.

        Args:
            scopes: Token scopes/permissions.

        Returns:
            JWT token string.

        Example:
            >>> token = await provider.get_token(scopes=["read", "write"])
        """
        # Check if we have a valid cached token
        if self._current_token is not None and not self._current_token.is_expired():
            if scopes is None or set(scopes).issubset(set(self._current_token.scopes)):
                return self._current_token.token

        # Generate new token
        await self._generate_token(scopes)

        if self._current_token is None:
            raise AuthenticationError(
                "Failed to generate JWT token",
                provider="jwt",
            )

        return self._current_token.token

    async def _generate_token(self, scopes: list[str] | None = None) -> None:
        """Generate new JWT token.

        Args:
            scopes: Token scopes/permissions.
        """
        now = time.time()
        expires_at = now + self.expiry_seconds

        payload: dict[str, Any] = {
            "iat": int(now),
            "exp": int(expires_at),
            **self.kwargs,
        }

        if self.issuer:
            payload["iss"] = self.issuer

        if self.audience:
            payload["aud"] = self.audience

        if scopes:
            payload["scopes"] = scopes

        # Encode JWT
        token = self._jwt.encode(payload, self.secret_key, algorithm=self.algorithm)

        self._current_token = TokenData(
            token=token,
            expires_at=expires_at,
            scopes=scopes or [],
            metadata=payload,
        )

    async def refresh_token(self) -> str:
        """Generate new JWT token.

        Returns:
            New JWT token.
        """
        scopes = self._current_token.scopes if self._current_token else None
        await self._generate_token(scopes)

        if self._current_token is None:
            raise AuthenticationError(
                "Failed to refresh JWT token",
                provider="jwt",
            )

        return self._current_token.token

    async def revoke_token(self) -> None:
        """Revoke JWT token (clears cached token).

        Note: JWTs are stateless, so this only clears the local cache.
        The token will still be valid until it expires.
        """
        self._current_token = None

    async def validate_token(self, token: str) -> bool:
        """Validate JWT token.

        Args:
            token: JWT token to validate.

        Returns:
            True if token is valid, False otherwise.
        """
        try:
            payload = self._jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                audience=self.audience,
                issuer=self.issuer,
            )

            # Check expiry
            exp = payload.get("exp")
            if exp and time.time() >= exp:
                return False

            return True

        except Exception:
            return False

    def decode_token(self, token: str) -> dict[str, Any]:
        """Decode JWT token without validation.

        Args:
            token: JWT token to decode.

        Returns:
            Decoded payload.

        Example:
            >>> payload = provider.decode_token(token)
            >>> print(payload["scopes"])
        """
        return self._jwt.decode(
            token,
            options={"verify_signature": False},
        )


def create_auth_provider(provider_type: str, **kwargs: Any) -> Any:
    """Create authentication provider by type.

    Factory function to create appropriate auth provider based on type.

    Args:
        provider_type: Provider type ("static", "oauth2", "jwt").
        **kwargs: Provider-specific configuration.

    Returns:
        Authentication provider instance.

    Raises:
        ConfigurationError: If provider type is unknown.

    Example:
        >>> # Static token
        >>> provider = create_auth_provider("static", token="api-key-123")
        >>>
        >>> # OAuth2
        >>> provider = create_auth_provider(
        ...     "oauth2",
        ...     client_id="id",
        ...     client_secret="secret",
        ...     token_url="https://auth.example.com/token"
        ... )
        >>>
        >>> # JWT
        >>> provider = create_auth_provider(
        ...     "jwt",
        ...     secret_key="secret",
        ...     algorithm="HS256"
        ... )
    """
    if provider_type == "static":
        if "token" not in kwargs:
            raise ConfigurationError(
                "Static provider requires 'token' parameter",
                field="token",
            )
        return StaticTokenProvider(**kwargs)

    if provider_type == "oauth2":
        required = ["client_id", "client_secret", "token_url"]
        missing = [f for f in required if f not in kwargs]
        if missing:
            raise ConfigurationError(
                f"OAuth2 provider requires: {', '.join(missing)}",
                field=missing[0],
            )
        return OAuth2Provider(**kwargs)

    if provider_type == "jwt":
        if "secret_key" not in kwargs:
            raise ConfigurationError(
                "JWT provider requires 'secret_key' parameter",
                field="secret_key",
            )
        return JWTProvider(**kwargs)

    raise ConfigurationError(
        f"Unknown auth provider type: {provider_type}",
        suggestion="Supported types: static, oauth2, jwt",
    )
