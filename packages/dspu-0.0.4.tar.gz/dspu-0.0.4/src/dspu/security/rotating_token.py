"""Rotating token management with automatic refresh.

This module provides RotatingToken for managing tokens that need periodic refresh.
"""

import asyncio
import contextlib
import time
from collections.abc import Awaitable, Callable
from types import TracebackType
from typing import Any

from dspu.security.exceptions import TokenExpiredError


class TokenData:
    """Container for token information.

    Attributes:
        token: The token value.
        expires_at: Unix timestamp when token expires (or None).
        scopes: List of token scopes/permissions.
        metadata: Additional token metadata.
    """

    def __init__(
        self,
        token: str,
        expires_at: float | None = None,
        scopes: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Initialize token data.

        Args:
            token: Token value.
            expires_at: Unix timestamp when token expires.
            scopes: List of scopes/permissions.
            metadata: Additional metadata.
        """
        self.token = token
        self.expires_at = expires_at
        self.scopes = scopes or []
        self.metadata = metadata or {}

    def is_expired(self) -> bool:
        """Check if token is expired.

        Returns:
            True if expired, False otherwise.
        """
        if self.expires_at is None:
            return False
        return time.time() >= self.expires_at

    def expires_in(self) -> float | None:
        """Get seconds until token expires.

        Returns:
            Seconds until expiry or None if no expiry.
        """
        if self.expires_at is None:
            return None
        remaining = self.expires_at - time.time()
        return max(0.0, remaining)

    def should_refresh(self, refresh_before: float = 300.0) -> bool:
        """Check if token should be refreshed.

        Args:
            refresh_before: Seconds before expiry to trigger refresh.

        Returns:
            True if should refresh, False otherwise.
        """
        expires_in = self.expires_in()
        if expires_in is None:
            return False
        return expires_in <= refresh_before


class RotatingToken:
    """Automatic token rotation context manager.

    Manages tokens that need periodic refresh, automatically refreshing
    before expiration and providing the current valid token.

    Example:
        >>> async def fetch_token() -> TokenData:
        ...     # Get token from auth service
        ...     token = await auth.get_token()
        ...     expires_at = time.time() + 3600  # 1 hour
        ...     return TokenData(token, expires_at=expires_at)
        >>>
        >>> async with RotatingToken(
        ...     fetch_fn=fetch_token,
        ...     refresh_interval=3600,
        ...     refresh_before=300,  # 5 minutes before expiry
        ... ) as rotating_token:
        ...     # Use current token
        ...     api_client.set_token(rotating_token.current)
        ...
        ...     # Token will auto-refresh when needed
        ...     await api_client.make_request()
    """

    def __init__(
        self,
        fetch_fn: Callable[[], Awaitable[TokenData]],
        refresh_interval: float | None = None,
        refresh_before: float = 300.0,
        on_refresh: Callable[[TokenData], Awaitable[None]] | None = None,
    ) -> None:
        """Initialize rotating token manager.

        Args:
            fetch_fn: Async function that returns TokenData.
            refresh_interval: Interval in seconds to refresh (None = use token expiry).
            refresh_before: Seconds before expiry to refresh (default: 300).
            on_refresh: Optional callback called after token refresh.

        Example:
            >>> token_manager = RotatingToken(
            ...     fetch_fn=lambda: auth.get_token(),
            ...     refresh_interval=3600,
            ...     refresh_before=300,
            ... )
        """
        self._fetch_fn = fetch_fn
        self._refresh_interval = refresh_interval
        self._refresh_before = refresh_before
        self._on_refresh = on_refresh

        self._token_data: TokenData | None = None
        self._refresh_task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()

    @property
    def current(self) -> str:
        """Get current valid token.

        Returns:
            Current token value.

        Raises:
            TokenExpiredError: If token is expired and refresh hasn't completed.
            RuntimeError: If token not initialized.

        Example:
            >>> token = rotating_token.current
            >>> api_client.set_token(token)
        """
        if self._token_data is None:
            raise RuntimeError("Token not initialized. Use within async context.")

        if self._token_data.is_expired():
            raise TokenExpiredError(
                "Token is expired",
                expired_at=self._token_data.expires_at,
            )

        return self._token_data.token

    @property
    def token_data(self) -> TokenData | None:
        """Get full token data including metadata.

        Returns:
            Current TokenData or None if not initialized.
        """
        return self._token_data

    def is_expired(self) -> bool:
        """Check if current token is expired.

        Returns:
            True if expired or not initialized, False otherwise.
        """
        if self._token_data is None:
            return True
        return self._token_data.is_expired()

    async def refresh(self) -> None:
        """Manually trigger token refresh.

        Example:
            >>> await rotating_token.refresh()
        """
        self._token_data = await self._fetch_fn()

        # Call refresh callback if provided
        if self._on_refresh is not None and self._token_data is not None:
            await self._on_refresh(self._token_data)

    async def _refresh_loop(self) -> None:
        """Background task for automatic token refresh."""
        while not self._stop_event.is_set():
            try:
                # Refresh token
                await self.refresh()

                # Determine next refresh time
                if self._refresh_interval is not None:
                    # Use fixed interval
                    wait_time = self._refresh_interval
                elif self._token_data is not None and self._token_data.expires_at is not None:
                    # Use token expiry with buffer
                    expires_in = self._token_data.expires_in() or 0
                    wait_time = max(1.0, expires_in - self._refresh_before)
                else:
                    # Default to 1 hour if no expiry info
                    wait_time = 3600.0

                # Wait for next refresh or stop signal
                try:
                    await asyncio.wait_for(
                        self._stop_event.wait(),
                        timeout=wait_time,
                    )
                    # Stop event was set, exit loop
                    break
                except TimeoutError:
                    # Timeout = time to refresh again
                    continue

            except Exception:
                # Log error but continue trying
                # In production, you'd want proper logging here

                # Wait a bit before retrying
                try:
                    await asyncio.wait_for(
                        self._stop_event.wait(),
                        timeout=60.0,  # Retry after 1 minute
                    )
                    break
                except TimeoutError:
                    continue

    async def __aenter__(self) -> "RotatingToken":
        """Enter async context and start token rotation.

        Returns:
            Self for use in context.
        """
        # Initial token fetch
        await self.refresh()

        # Start background refresh task
        self._stop_event.clear()
        self._refresh_task = asyncio.create_task(self._refresh_loop())

        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context and stop token rotation.

        Args:
            exc_type: Exception type if raised.
            exc_val: Exception value if raised.
            exc_tb: Exception traceback if raised.
        """
        # Signal refresh task to stop
        self._stop_event.set()

        # Wait for refresh task to complete
        if self._refresh_task is not None:
            try:
                await asyncio.wait_for(self._refresh_task, timeout=5.0)
            except TimeoutError:
                # Force cancel if it doesn't stop gracefully
                self._refresh_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._refresh_task


async def simple_rotating_token(
    fetch_fn: Callable[[], Awaitable[str]],
    refresh_interval: float,
) -> RotatingToken:
    """Create a simple rotating token with just a string fetch function.

    Convenience function for cases where you just need periodic refresh
    without expiry tracking.

    Args:
        fetch_fn: Async function that returns token string.
        refresh_interval: How often to refresh in seconds.

    Returns:
        RotatingToken instance.

    Example:
        >>> async def get_token() -> str:
        ...     return await auth_service.get_token()
        >>>
        >>> async with simple_rotating_token(get_token, 3600) as token:
        ...     api.set_token(token.current)
    """

    async def fetch_token_data() -> TokenData:
        token = await fetch_fn()
        return TokenData(token=token)

    return RotatingToken(
        fetch_fn=fetch_token_data,
        refresh_interval=refresh_interval,
    )
