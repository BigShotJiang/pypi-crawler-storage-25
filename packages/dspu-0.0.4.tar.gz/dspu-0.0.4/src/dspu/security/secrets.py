"""Secret management facade and implementation.

This module provides the SecretManager class and secret backend implementations.
"""

import os
from typing import Any

from dspu.core.exceptions import ConfigurationError
from dspu.security.exceptions import SecretNotFoundError
from dspu.security.protocols import SecretBackend


class SecretManager:
    """Unified interface for secret management.

    Provides a consistent API for accessing secrets from various backends
    (Vault, AWS Secrets Manager, environment variables, files).

    Example:
        >>> # Auto-detect from environment
        >>> secrets = SecretManager.from_env()
        >>> password = await secrets.get("database/password")
        >>>
        >>> # Explicit backend
        >>> from dspu.security.backends import EnvBackend
        >>> secrets = SecretManager(EnvBackend(prefix="APP_"))
        >>> api_key = await secrets.get("api/key")
        >>>
        >>> # Set secrets (if backend supports it)
        >>> await secrets.set("new/secret", "value")
    """

    def __init__(self, backend: SecretBackend) -> None:
        """Initialize secret manager with backend.

        Args:
            backend: Secret backend implementation.
        """
        self._backend = backend

    @classmethod
    def from_env(cls, **kwargs: Any) -> "SecretManager":
        """Create SecretManager from environment configuration.

        Auto-detects backend from environment variables:
        - VAULT_ADDR + VAULT_TOKEN -> Vault backend
        - AWS_SECRET_BACKEND=true -> AWS Secrets Manager
        - Otherwise -> Environment variable backend

        Args:
            **kwargs: Backend-specific options.

        Returns:
            SecretManager instance with detected backend.

        Example:
            >>> # With Vault
            >>> os.environ["VAULT_ADDR"] = "http://localhost:8200"
            >>> os.environ["VAULT_TOKEN"] = "dev-token"
            >>> secrets = SecretManager.from_env()
            >>>
            >>> # With environment variables
            >>> os.environ["SECRET_PREFIX"] = "APP_SECRET_"
            >>> secrets = SecretManager.from_env()
        """
        # Check for Vault
        vault_addr = os.getenv("VAULT_ADDR")
        vault_token = os.getenv("VAULT_TOKEN")

        if vault_addr and vault_token:
            try:
                from dspu.security.backends import VaultBackend
            except ImportError as e:
                raise ConfigurationError(
                    "Vault backend requires hvac package",
                    suggestion="Install with: pip install dspu[security]",
                ) from e

            backend: SecretBackend = VaultBackend(
                url=vault_addr,
                token=vault_token,
                **kwargs,
            )
            return cls(backend)

        # Check for AWS
        if os.getenv("AWS_SECRET_BACKEND", "").lower() == "true":
            try:
                from dspu.security.backends import AWSSecretBackend
            except ImportError as e:
                raise ConfigurationError(
                    "AWS backend requires boto3 package",
                    suggestion="Install with: pip install dspu[security]",
                ) from e

            region = os.getenv("AWS_REGION", "us-east-1")
            backend = AWSSecretBackend(region=region, **kwargs)
            return cls(backend)

        # Default to environment variables
        from dspu.security.backends import EnvBackend

        prefix = os.getenv("SECRET_PREFIX", "")
        backend = EnvBackend(prefix=prefix, **kwargs)
        return cls(backend)

    @classmethod
    def from_vault(
        cls,
        url: str,
        token: str,
        **kwargs: Any,
    ) -> "SecretManager":
        """Create SecretManager with Vault backend.

        Args:
            url: Vault server URL.
            token: Vault authentication token.
            **kwargs: Additional Vault options.

        Returns:
            SecretManager with Vault backend.

        Raises:
            ConfigurationError: If hvac package not installed.

        Example:
            >>> secrets = SecretManager.from_vault(
            ...     url="http://localhost:8200",
            ...     token="dev-token"
            ... )
            >>> password = await secrets.get("secret/database/password")
        """
        try:
            from dspu.security.backends import VaultBackend
        except ImportError as e:
            raise ConfigurationError(
                "Vault backend requires hvac package",
                suggestion="Install with: pip install dspu[security]",
            ) from e

        backend = VaultBackend(url=url, token=token, **kwargs)
        return cls(backend)

    @classmethod
    def from_aws(cls, region: str = "us-east-1", **kwargs: Any) -> "SecretManager":
        """Create SecretManager with AWS Secrets Manager backend.

        Args:
            region: AWS region.
            **kwargs: Additional AWS options.

        Returns:
            SecretManager with AWS backend.

        Raises:
            ConfigurationError: If boto3 package not installed.

        Example:
            >>> secrets = SecretManager.from_aws(region="us-west-2")
            >>> api_key = await secrets.get("prod/api/key")
        """
        try:
            from dspu.security.backends import AWSSecretBackend
        except ImportError as e:
            raise ConfigurationError(
                "AWS backend requires boto3 package",
                suggestion="Install with: pip install boto3",
            ) from e

        backend = AWSSecretBackend(region=region, **kwargs)
        return cls(backend)

    @classmethod
    def from_env_vars(cls, prefix: str = "", **kwargs: Any) -> "SecretManager":
        """Create SecretManager with environment variable backend.

        Args:
            prefix: Prefix for environment variables.
            **kwargs: Additional options.

        Returns:
            SecretManager with environment backend.

        Example:
            >>> secrets = SecretManager.from_env_vars(prefix="APP_SECRET_")
            >>> # Gets from APP_SECRET_API_KEY environment variable
            >>> api_key = await secrets.get("api/key")
        """
        from dspu.security.backends import EnvBackend

        backend = EnvBackend(prefix=prefix, **kwargs)
        return cls(backend)

    @classmethod
    def from_file(cls, path: str, **kwargs: Any) -> "SecretManager":
        """Create SecretManager with file-based backend.

        Args:
            path: Path to secrets file (JSON or YAML).
            **kwargs: Additional options.

        Returns:
            SecretManager with file backend.

        Example:
            >>> secrets = SecretManager.from_file("secrets.yaml")
            >>> password = await secrets.get("database/password")
        """
        from dspu.security.backends import FileBackend

        backend = FileBackend(path=path, **kwargs)
        return cls(backend)

    async def get(self, key: str, default: str | None = None) -> str:
        """Get a secret value.

        Args:
            key: Secret key/path.
            default: Default value if secret not found.

        Returns:
            Secret value.

        Raises:
            SecretNotFoundError: If secret not found and no default.
            SecurityError: If access denied or backend error.

        Example:
            >>> password = await secrets.get("database/password")
            >>> api_key = await secrets.get("api/key", default="dev-key")
        """
        try:
            return await self._backend.get(key)
        except KeyError:
            if default is not None:
                return default
            raise SecretNotFoundError(
                f"Secret not found: {key}",
                key=key,
            ) from None

    async def set(self, key: str, value: str) -> None:
        """Set a secret value.

        Args:
            key: Secret key/path.
            value: Secret value.

        Raises:
            SecurityError: If write fails or not supported.

        Example:
            >>> await secrets.set("api/key", "new-secret-key")
        """
        await self._backend.set(key, value)

    async def delete(self, key: str) -> None:
        """Delete a secret.

        Args:
            key: Secret key/path.

        Raises:
            SecretNotFoundError: If secret not found.
            SecurityError: If delete fails.

        Example:
            >>> await secrets.delete("old/api/key")
        """
        try:
            await self._backend.delete(key)
        except KeyError:
            raise SecretNotFoundError(
                f"Secret not found: {key}",
                key=key,
            ) from None

    async def exists(self, key: str) -> bool:
        """Check if a secret exists.

        Args:
            key: Secret key/path.

        Returns:
            True if secret exists, False otherwise.

        Example:
            >>> if await secrets.exists("database/password"):
            ...     password = await secrets.get("database/password")
        """
        return await self._backend.exists(key)

    async def list(self, prefix: str = "") -> list[str]:
        """List secret keys.

        Args:
            prefix: Optional prefix filter.

        Returns:
            List of secret keys.

        Example:
            >>> # List all database secrets
            >>> db_secrets = await secrets.list(prefix="database/")
            >>> for key in db_secrets:
            ...     print(key)
        """
        return await self._backend.list(prefix)
