"""Security module for DSPU.

This module provides:
- Secret management (Vault, AWS Secrets Manager, environment variables, files)
- Authentication providers (OAuth2, JWT, static tokens)
- Token rotation management
- Encryption utilities

Example:
    >>> from dspu.security import SecretManager, create_auth_provider, Fernet
    >>>
    >>> # Secret management
    >>> secrets = SecretManager.from_env()
    >>> api_key = await secrets.get("api/key")
    >>>
    >>> # Authentication
    >>> auth = create_auth_provider(
    ...     "oauth2",
    ...     client_id="id",
    ...     client_secret="secret",
    ...     token_url="https://auth.example.com/token"
    ... )
    >>> token = await auth.get_token(scopes=["read", "write"])
    >>>
    >>> # Encryption
    >>> key = Fernet.generate_key()
    >>> cipher = Fernet(key)
    >>> encrypted = cipher.encrypt(b"secret data")
    >>> decrypted = cipher.decrypt(encrypted)
"""

# Protocols
# Authentication
from dspu.security.auth import (
    JWTProvider,
    OAuth2Provider,
    StaticTokenProvider,
    create_auth_provider,
)
from dspu.security.backends import (
    AWSSecretBackend,
    EnvBackend,
    FileBackend,
    VaultBackend,
)

# Encryption
from dspu.security.encryption import (
    AES,
    Fernet,
    constant_time_compare,
    generate_token,
    hash_data,
    hash_password,
    verify_password,
)

# Exceptions
from dspu.security.exceptions import (
    AuthenticationError,
    EncryptionError,
    SecretNotFoundError,
    TokenExpiredError,
)
from dspu.security.protocols import AuthProvider, SecretBackend, TokenInfo

# Token rotation
from dspu.security.rotating_token import (
    RotatingToken,
    TokenData,
    simple_rotating_token,
)

# Secret management
from dspu.security.secrets import SecretManager

__all__ = [
    # Encryption
    "AES",
    # Secret management
    "AWSSecretBackend",
    # Protocols
    "AuthProvider",
    # Exceptions
    "AuthenticationError",
    "EncryptionError",
    "EnvBackend",
    "Fernet",
    "FileBackend",
    # Authentication
    "JWTProvider",
    "OAuth2Provider",
    # Token rotation
    "RotatingToken",
    "SecretBackend",
    "SecretManager",
    "SecretNotFoundError",
    "StaticTokenProvider",
    "TokenData",
    "TokenExpiredError",
    "TokenInfo",
    "VaultBackend",
    "constant_time_compare",
    "create_auth_provider",
    "generate_token",
    "hash_data",
    "hash_password",
    "simple_rotating_token",
    "verify_password",
]
