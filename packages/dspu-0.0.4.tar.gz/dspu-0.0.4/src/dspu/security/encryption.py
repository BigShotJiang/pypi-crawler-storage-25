"""Encryption and cryptographic utilities.

This module provides simple wrappers for common encryption operations.
"""

import base64
import hashlib
import secrets

from dspu.core.exceptions import ConfigurationError
from dspu.security.exceptions import EncryptionError


class Fernet:
    """Symmetric encryption using Fernet (AES-128-CBC).

    Provides simple symmetric encryption for data at rest.
    Uses the cryptography library's Fernet implementation.

    Example:
        >>> # Generate a key
        >>> key = Fernet.generate_key()
        >>>
        >>> # Encrypt data
        >>> fernet = Fernet(key)
        >>> encrypted = fernet.encrypt(b"secret data")
        >>>
        >>> # Decrypt data
        >>> decrypted = fernet.decrypt(encrypted)
        >>> print(decrypted)  # b"secret data"
    """

    def __init__(self, key: bytes | str) -> None:
        """Initialize Fernet cipher with key.

        Args:
            key: Encryption key (32 bytes or base64-encoded string).

        Raises:
            ConfigurationError: If cryptography not installed.
            EncryptionError: If key is invalid.
        """
        try:
            from cryptography.fernet import Fernet as CryptoFernet

            self._fernet_class = CryptoFernet
        except ImportError as e:
            raise ConfigurationError(
                "Encryption requires cryptography package",
                suggestion="Install with: pip install dspu[security]",
            ) from e

        # Convert string key to bytes if needed
        if isinstance(key, str):
            key = key.encode("utf-8")

        try:
            self._cipher = self._fernet_class(key)
        except Exception as e:
            raise EncryptionError(
                f"Invalid encryption key: {e}",
                algorithm="fernet",
            ) from e

    @staticmethod
    def generate_key() -> bytes:
        """Generate a new Fernet encryption key.

        Returns:
            32-byte encryption key (base64 encoded).

        Example:
            >>> key = Fernet.generate_key()
            >>> print(key.decode())  # Base64 encoded key
        """
        try:
            from cryptography.fernet import Fernet as CryptoFernet

            return CryptoFernet.generate_key()
        except ImportError as e:
            raise ConfigurationError(
                "Encryption requires cryptography package",
                suggestion="Install with: pip install dspu[security]",
            ) from e

    def encrypt(self, data: bytes | str) -> bytes:
        """Encrypt data.

        Args:
            data: Data to encrypt (bytes or string).

        Returns:
            Encrypted data (base64 encoded).

        Example:
            >>> encrypted = fernet.encrypt(b"secret")
            >>> encrypted = fernet.encrypt("secret")  # Also works
        """
        if isinstance(data, str):
            data = data.encode("utf-8")

        try:
            return self._cipher.encrypt(data)
        except Exception as e:
            raise EncryptionError(
                f"Encryption failed: {e}",
                operation="encrypt",
                algorithm="fernet",
            ) from e

    def decrypt(self, encrypted_data: bytes) -> bytes:
        """Decrypt data.

        Args:
            encrypted_data: Encrypted data to decrypt.

        Returns:
            Decrypted data as bytes.

        Example:
            >>> decrypted = fernet.decrypt(encrypted)
            >>> print(decrypted.decode())  # Convert to string
        """
        try:
            return self._cipher.decrypt(encrypted_data)
        except Exception as e:
            raise EncryptionError(
                f"Decryption failed: {e}",
                operation="decrypt",
                algorithm="fernet",
            ) from e

    def decrypt_str(self, encrypted_data: bytes) -> str:
        """Decrypt data and return as string.

        Args:
            encrypted_data: Encrypted data to decrypt.

        Returns:
            Decrypted data as string.

        Example:
            >>> message = fernet.decrypt_str(encrypted)
            >>> print(message)  # "secret"
        """
        return self.decrypt(encrypted_data).decode("utf-8")


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, bytes]:
    """Hash a password using PBKDF2.

    Args:
        password: Password to hash.
        salt: Salt bytes (generates new one if None).

    Returns:
        Tuple of (hash_string, salt_bytes).

    Example:
        >>> hash_str, salt = hash_password("my-password")
        >>> # Store hash_str and salt in database
        >>>
        >>> # Later, verify password
        >>> is_valid = verify_password("my-password", hash_str, salt)
    """
    if salt is None:
        salt = secrets.token_bytes(32)

    # Use PBKDF2 with SHA256
    key = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations=100000,  # OWASP recommendation
        dklen=32,
    )

    # Return base64-encoded hash and salt
    hash_str = base64.b64encode(key).decode("utf-8")
    return hash_str, salt


def verify_password(password: str, hash_str: str, salt: bytes) -> bool:
    """Verify a password against its hash.

    Args:
        password: Password to verify.
        hash_str: Base64-encoded password hash.
        salt: Salt bytes used for hashing.

    Returns:
        True if password matches, False otherwise.

    Example:
        >>> # After storing hash and salt
        >>> is_valid = verify_password("user-input", stored_hash, stored_salt)
        >>> if is_valid:
        ...     print("Password correct!")
    """
    # Hash the password with the same salt
    computed_hash, _ = hash_password(password, salt)

    # Constant-time comparison to prevent timing attacks
    return secrets.compare_digest(computed_hash, hash_str)


def generate_token(length: int = 32) -> str:
    """Generate a cryptographically secure random token.

    Args:
        length: Token length in bytes (default: 32).

    Returns:
        URL-safe base64-encoded token.

    Example:
        >>> api_key = generate_token(32)
        >>> session_id = generate_token(16)
    """
    token_bytes = secrets.token_bytes(length)
    return base64.urlsafe_b64encode(token_bytes).decode("utf-8")


def constant_time_compare(a: str, b: str) -> bool:
    """Compare two strings in constant time.

    Prevents timing attacks when comparing secrets like tokens or passwords.

    Args:
        a: First string.
        b: Second string.

    Returns:
        True if strings are equal, False otherwise.

    Example:
        >>> token1 = "secret-token-123"
        >>> token2 = user_provided_token
        >>> if constant_time_compare(token1, token2):
        ...     print("Valid token")
    """
    return secrets.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


class AES:
    """AES encryption utilities.

    Provides AES-256-GCM encryption for data at rest and in transit.

    Example:
        >>> # Generate a key
        >>> key = AES.generate_key()
        >>>
        >>> # Encrypt data
        >>> aes = AES(key)
        >>> encrypted, nonce = aes.encrypt(b"secret data")
        >>>
        >>> # Decrypt data
        >>> decrypted = aes.decrypt(encrypted, nonce)
    """

    def __init__(self, key: bytes) -> None:
        """Initialize AES cipher with key.

        Args:
            key: 32-byte encryption key.

        Raises:
            ConfigurationError: If cryptography not installed.
            EncryptionError: If key is invalid.
        """
        try:
            from cryptography.hazmat.primitives.ciphers.aead import (
                AESGCM,
            )

            self._aesgcm_class = AESGCM
        except ImportError as e:
            raise ConfigurationError(
                "Encryption requires cryptography package",
                suggestion="Install with: pip install dspu[security]",
            ) from e

        if len(key) != 32:
            raise EncryptionError(
                "AES key must be 32 bytes",
                algorithm="aes-256-gcm",
            )

        self._cipher = self._aesgcm_class(key)

    @staticmethod
    def generate_key() -> bytes:
        """Generate a new AES-256 key.

        Returns:
            32-byte encryption key.

        Example:
            >>> key = AES.generate_key()
        """
        return secrets.token_bytes(32)

    def encrypt(
        self,
        data: bytes | str,
        associated_data: bytes | None = None,
    ) -> tuple[bytes, bytes]:
        """Encrypt data using AES-256-GCM.

        Args:
            data: Data to encrypt.
            associated_data: Optional authenticated but unencrypted data.

        Returns:
            Tuple of (encrypted_data, nonce).

        Example:
            >>> encrypted, nonce = aes.encrypt(b"secret")
            >>> # Store both encrypted and nonce
        """
        if isinstance(data, str):
            data = data.encode("utf-8")

        try:
            # Generate random nonce (12 bytes for GCM)
            nonce = secrets.token_bytes(12)

            encrypted = self._cipher.encrypt(nonce, data, associated_data)
            return encrypted, nonce

        except Exception as e:
            raise EncryptionError(
                f"AES encryption failed: {e}",
                operation="encrypt",
                algorithm="aes-256-gcm",
            ) from e

    def decrypt(
        self,
        encrypted_data: bytes,
        nonce: bytes,
        associated_data: bytes | None = None,
    ) -> bytes:
        """Decrypt data using AES-256-GCM.

        Args:
            encrypted_data: Data to decrypt.
            nonce: Nonce used during encryption.
            associated_data: Optional authenticated data (must match encryption).

        Returns:
            Decrypted data.

        Example:
            >>> decrypted = aes.decrypt(encrypted, nonce)
        """
        try:
            return self._cipher.decrypt(nonce, encrypted_data, associated_data)
        except Exception as e:
            raise EncryptionError(
                f"AES decryption failed: {e}",
                operation="decrypt",
                algorithm="aes-256-gcm",
            ) from e

    def decrypt_str(
        self,
        encrypted_data: bytes,
        nonce: bytes,
        associated_data: bytes | None = None,
    ) -> str:
        """Decrypt data and return as string.

        Args:
            encrypted_data: Data to decrypt.
            nonce: Nonce used during encryption.
            associated_data: Optional authenticated data.

        Returns:
            Decrypted data as string.
        """
        return self.decrypt(encrypted_data, nonce, associated_data).decode("utf-8")


def hash_data(data: bytes | str, algorithm: str = "sha256") -> str:
    """Hash data using specified algorithm.

    Args:
        data: Data to hash.
        algorithm: Hash algorithm (sha256, sha512, etc.).

    Returns:
        Hexadecimal hash string.

    Example:
        >>> file_hash = hash_data(file_contents, algorithm="sha256")
        >>> checksum = hash_data(b"data", algorithm="md5")
    """
    if isinstance(data, str):
        data = data.encode("utf-8")

    hasher = hashlib.new(algorithm)
    hasher.update(data)
    return hasher.hexdigest()
