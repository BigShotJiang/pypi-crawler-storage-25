"""Security-specific exceptions.

This module extends the core SecurityError with more specific exception types
for secret management and authentication.
"""

from dspu.core.exceptions import SecurityError


class SecretNotFoundError(SecurityError):
    """Raised when a secret cannot be found.

    Attributes:
        key: The secret key that was not found.
        backend: The backend that was queried.
    """

    def __init__(
        self,
        message: str,
        *,
        key: str,
        backend: str | None = None,
    ) -> None:
        """Initialize secret not found error.

        Args:
            message: Error message.
            key: The secret key that was not found.
            backend: The backend that was queried.
        """
        super().__init__(message, resource=key)
        self.key = key
        self.backend = backend

    def __str__(self) -> str:
        """Format error message."""
        parts = [super().__str__()]
        if self.backend:
            parts.append(f"Backend: {self.backend}")
        return "\n".join(parts)


class AuthenticationError(SecurityError):
    """Raised when authentication fails.

    Attributes:
        provider: The authentication provider that failed.
        reason: Specific reason for failure.
    """

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        reason: str | None = None,
    ) -> None:
        """Initialize authentication error.

        Args:
            message: Error message.
            provider: The authentication provider.
            reason: Specific reason for failure.
        """
        super().__init__(message, reason=reason)
        self.provider = provider

    def __str__(self) -> str:
        """Format error message."""
        parts = [super().__str__()]
        if self.provider:
            parts.append(f"Provider: {self.provider}")
        return "\n".join(parts)


class TokenExpiredError(SecurityError):
    """Raised when a token has expired.

    Attributes:
        token: The expired token (truncated for security).
        expired_at: When the token expired.
    """

    def __init__(
        self,
        message: str,
        *,
        expired_at: float | None = None,
    ) -> None:
        """Initialize token expired error.

        Args:
            message: Error message.
            expired_at: Unix timestamp when token expired.
        """
        super().__init__(message)
        self.expired_at = expired_at


class EncryptionError(SecurityError):
    """Raised when encryption/decryption fails.

    Attributes:
        operation: The operation that failed (encrypt/decrypt).
        algorithm: The encryption algorithm used.
    """

    def __init__(
        self,
        message: str,
        *,
        operation: str | None = None,
        algorithm: str | None = None,
    ) -> None:
        """Initialize encryption error.

        Args:
            message: Error message.
            operation: The operation that failed.
            algorithm: The encryption algorithm.
        """
        super().__init__(message)
        self.operation = operation
        self.algorithm = algorithm

    def __str__(self) -> str:
        """Format error message."""
        parts = [super().__str__()]
        if self.operation:
            parts.append(f"Operation: {self.operation}")
        if self.algorithm:
            parts.append(f"Algorithm: {self.algorithm}")
        return "\n".join(parts)
