"""Security protocols for DSPU.

This module defines the protocols for secret management and authentication.
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class SecretBackend(Protocol):
    """Protocol for secret storage backends.

    Backends provide secure storage and retrieval of secrets like passwords,
    API keys, and certificates. Implementations include Vault, AWS Secrets Manager,
    environment variables, and file-based storage.

    Example:
        >>> class MyBackend:
        ...     async def get(self, key: str) -> str:
        ...         return await fetch_secret(key)
        ...
        ...     async def set(self, key: str, value: str) -> None:
        ...         await store_secret(key, value)
        ...
        ...     async def delete(self, key: str) -> None:
        ...         await remove_secret(key)
        ...
        >>> backend = MyBackend()
        >>> secret = await backend.get("api/key")
    """

    async def get(self, key: str) -> str:
        """Get a secret value by key.

        Args:
            key: Secret key/path (e.g., "database/password", "api/key").

        Returns:
            Secret value as string.

        Raises:
            KeyError: If secret not found.
            SecurityError: If access denied or backend error.
        """
        ...

    async def set(self, key: str, value: str) -> None:
        """Set a secret value.

        Args:
            key: Secret key/path.
            value: Secret value to store.

        Raises:
            SecurityError: If write fails or access denied.
        """
        ...

    async def delete(self, key: str) -> None:
        """Delete a secret.

        Args:
            key: Secret key/path to delete.

        Raises:
            KeyError: If secret not found.
            SecurityError: If delete fails or access denied.
        """
        ...

    async def exists(self, key: str) -> bool:
        """Check if a secret exists.

        Args:
            key: Secret key/path to check.

        Returns:
            True if secret exists, False otherwise.
        """
        ...

    async def list(self, prefix: str = "") -> list[str]:
        """List secret keys with optional prefix filter.

        Args:
            prefix: Optional prefix to filter keys (e.g., "api/").

        Returns:
            List of secret keys.

        Raises:
            SecurityError: If list operation fails or access denied.
        """
        ...


@runtime_checkable
class AuthProvider(Protocol):
    """Protocol for authentication providers.

    Providers handle authentication and token management for various
    authentication schemes (OAuth2, JWT, static tokens, etc.).

    Example:
        >>> class MyAuthProvider:
        ...     async def get_token(self, scopes: list[str] | None = None) -> str:
        ...         return await authenticate(scopes)
        ...
        ...     async def refresh_token(self) -> str:
        ...         return await refresh()
        ...
        ...     async def revoke_token(self) -> None:
        ...         await revoke()
        ...
        >>> provider = MyAuthProvider()
        >>> token = await provider.get_token(scopes=["read", "write"])
    """

    async def get_token(self, scopes: list[str] | None = None) -> str:
        """Get an authentication token.

        Args:
            scopes: Optional list of permission scopes.

        Returns:
            Authentication token as string.

        Raises:
            SecurityError: If authentication fails.
        """
        ...

    async def refresh_token(self) -> str:
        """Refresh the current token.

        Returns:
            New authentication token.

        Raises:
            SecurityError: If refresh fails.
        """
        ...

    async def revoke_token(self) -> None:
        """Revoke the current token.

        Raises:
            SecurityError: If revocation fails.
        """
        ...

    async def validate_token(self, token: str) -> bool:
        """Validate a token.

        Args:
            token: Token to validate.

        Returns:
            True if token is valid, False otherwise.
        """
        ...


@runtime_checkable
class TokenInfo(Protocol):
    """Protocol for token information.

    Provides metadata about authentication tokens including
    expiry time, scopes, and other attributes.
    """

    @property
    def token(self) -> str:
        """Get the token value."""
        ...

    @property
    def expires_at(self) -> float | None:
        """Get token expiry timestamp (Unix timestamp).

        Returns:
            Expiry timestamp or None if token doesn't expire.
        """
        ...

    @property
    def scopes(self) -> list[str]:
        """Get token scopes/permissions."""
        ...

    def is_expired(self) -> bool:
        """Check if token is expired.

        Returns:
            True if token is expired, False otherwise.
        """
        ...

    def expires_in(self) -> float | None:
        """Get seconds until token expires.

        Returns:
            Seconds until expiry or None if token doesn't expire.
        """
        ...
