"""Logging setup utilities for flexible configuration.

This module provides utilities to configure Python logging from files,
dictionaries, or environment variables with sensible defaults.
"""

import inspect
import logging
import logging.config
import os
from pathlib import Path
from typing import Any

from dspu.core.exceptions import ConfigurationError


class LoggingSetup:
    """Configure Python logging from files, dictionaries, or environment variables.

    Provides flexible logging configuration with support for:
    - Configuration from JSON, YAML, or HOCON files
    - Environment variable overrides
    - Dictionary configuration
    - Relative path resolution
    - Stdout/stderr redirection

    Example:
        >>> setup = LoggingSetup(
        ...     default_log_config_file="logging.json",
        ...     default_log_level="INFO",
        ...     log_config_env="LOG_CONFIG",
        ...     log_level_env="LOG_LEVEL",
        ... )
        >>> setup.setup()
    """

    def __init__(
        self,
        default_log_config_dir: str = ".",
        default_log_config_file: str = "logging.json",
        default_log_level: str = "DEBUG",
        log_config_env: str | None = None,
        log_level_env: str | None = None,
        log_file: str | None = None,
        logging_config: dict[str, Any] | str | None = None,
        source_anchor: Any = None,
        default_logger_name: str | None = None,
    ):
        """Initialize logging setup.

        Args:
            default_log_config_dir: Directory where logging config file lives.
            default_log_config_file: Default name of logging config file.
            default_log_level: Default log level if no config file found.
            log_config_env: Environment variable for config file override.
            log_level_env: Environment variable for log level override.
            log_file: Actual file to log to (overrides config).
            logging_config: Config reference (file path or dictionary).
            source_anchor: Object whose source file is anchor for relative paths.
            default_logger_name: Logger name for default setup.
        """
        self.default_log_config_dir = default_log_config_dir
        self.default_log_config_file = default_log_config_file
        self.default_log_level = default_log_level
        self.log_config_env = log_config_env
        self.log_level_env = log_level_env
        self.log_file = log_file
        self.logging_config = logging_config
        self.source_anchor = source_anchor
        self.default_logger_name = default_logger_name

    def setup(self) -> None:
        """Set up logging per the configured parameters.

        Configures Python logging based on:
        1. Explicit logging_config (if provided)
        2. Config file path from environment variable or defaults
        3. Basic config with default log level

        Raises:
            ConfigurationError: If config file cannot be loaded.
        """
        # First, assume config is what we got from constructor
        config = self.logging_config

        # Determine config file path if needed
        log_config_file_path = self.determine_log_config_file_path()
        if log_config_file_path is not None:
            # Read the logging config file
            config = self._load_config_file(log_config_file_path)

        # Apply the configuration
        if config is not None and isinstance(config, dict):
            config = self.replace_log_file(config)
            logging.config.dictConfig(config)
        else:
            # Fall back to basic config
            log_level = self.determine_log_level()
            logging.basicConfig(
                filename=self.log_file,
                level=log_level,
                format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            )

    def setup_with_diversion(self) -> logging.Logger:
        """Set up logging and divert stdout/stderr to logger.

        Returns:
            Logger instance used for diversion.

        Example:
            >>> logger = setup.setup_with_diversion()
            >>> print("This goes to the logger")
        """
        self.setup()

        # Determine the default logger name
        logger_name = self.default_logger_name
        if logger_name is None:
            logger_name = "default"
            if self.source_anchor is not None:
                logger_name = self.source_anchor.__class__.__name__

        logger = logging.getLogger(logger_name)
        log_level = self.determine_log_level()
        logger.setLevel(log_level)

        # Import StreamToLogger to avoid circular import
        from dspu.observability.stream_capture import StreamToLogger

        StreamToLogger.subvert(
            logger=logger,
            reroute_stdout=True,
            reroute_stderr=True,
        )

        logger.info("Print statements diverted to logger")
        return logger

    def determine_log_config_file_path(self) -> str | None:
        """Determine path of log config file based on parameters.

        Returns:
            Absolute path to log config file, or None if using dict config.
        """
        # By default, use defaults from constructor
        default_logging_config_file = os.path.join(
            self.default_log_config_dir,
            self.default_log_config_file,
        )

        # See if explicit config was given
        if self.logging_config is not None:
            # If it's a dictionary, no file needed
            if isinstance(self.logging_config, dict):
                return None

            # If it's a string, use it as the full path
            if isinstance(self.logging_config, str):
                default_logging_config_file = self.logging_config

        # Check for environment variable override
        log_config_file_path = default_logging_config_file
        if self.log_config_env is not None:
            log_config_file_path = os.environ.get(
                self.log_config_env,
                default_logging_config_file,
            )

        # Convert relative paths to absolute
        if log_config_file_path.startswith("."):
            log_config_file_path = self.get_absolute_source_file_path(
                log_config_file_path,
                source_anchor=self.source_anchor,
            )

        return os.path.abspath(log_config_file_path)

    def determine_log_level(self) -> str:
        """Determine log level from environment or defaults.

        Returns:
            Log level string (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        """
        log_level = self.default_log_level
        if self.log_level_env is not None:
            log_level = os.environ.get(
                self.log_level_env,
                self.default_log_level,
            )
        return log_level

    def replace_log_file(self, config: dict[str, Any]) -> dict[str, Any]:
        """Replace log file in config with constructor-provided file.

        Args:
            config: Dictionary containing logging configuration.

        Returns:
            Modified configuration dictionary.
        """
        # If there's nothing to change, return early
        if self.log_file is None:
            return config

        # Find first handler with filename and replace it
        handlers = config.get("handlers", {})
        for handler_key in handlers:
            handler = handlers.get(handler_key, {})
            if "filename" in handler:
                handler["filename"] = self.log_file
                break

        return config

    @staticmethod
    def get_absolute_source_file_path(
        relative_filepath: str,
        source_anchor: Any = None,
    ) -> str:
        """Convert relative filepath to absolute based on source anchor.

        Args:
            relative_filepath: Filepath relative to source file.
            source_anchor: Object whose source file is anchor for relative paths.
                          If None, uses current working directory.
                          If str, uses as directory path.
                          Otherwise, uses object's class source file location.

        Returns:
            Absolute filepath.

        Example:
            >>> path = LoggingSetup.get_absolute_source_file_path(
            ...     "./config/logging.json",
            ...     source_anchor=my_object,
            ... )
        """
        relative_dir = os.getcwd()

        if source_anchor is not None:
            if isinstance(source_anchor, str):
                relative_dir = source_anchor
            else:
                module_file = inspect.getfile(source_anchor.__class__)
                module_path = os.path.abspath(module_file)
                relative_dir = os.path.dirname(module_path)

        partial_relative_path = os.path.join(relative_dir, relative_filepath)
        return os.path.abspath(partial_relative_path)

    def _load_config_file(self, config_path: str) -> dict[str, Any]:
        """Load configuration from file.

        Supports JSON, YAML, and HOCON formats based on file extension.

        Args:
            config_path: Path to configuration file.

        Returns:
            Configuration dictionary.

        Raises:
            ConfigurationError: If file cannot be loaded or format unsupported.
        """
        path = Path(config_path)

        if not path.exists():
            raise ConfigurationError(
                f"Logging config file not found: {config_path}",
                suggestion="Check that the file path is correct",
            )

        suffix = path.suffix.lower()

        try:
            if suffix == ".json":
                import json

                with open(path) as f:
                    return json.load(f)

            elif suffix in (".yaml", ".yml"):
                try:
                    import yaml

                    with open(path) as f:
                        return yaml.safe_load(f)
                except ImportError as e:
                    raise ConfigurationError(
                        "YAML config requires PyYAML",
                        suggestion="Install with: pip install pyyaml",
                    ) from e

            elif suffix == ".conf":
                # Try HOCON format
                try:
                    from pyhocon import ConfigFactory

                    return ConfigFactory.parse_file(config_path)
                except ImportError as e:
                    raise ConfigurationError(
                        "HOCON config requires pyhocon",
                        suggestion="Install with: pip install pyhocon",
                    ) from e

            else:
                raise ConfigurationError(
                    f"Unsupported config file format: {suffix}",
                    suggestion="Supported formats: .json, .yaml, .yml, .conf (HOCON)",
                )

        except Exception as e:
            if isinstance(e, ConfigurationError):
                raise
            raise ConfigurationError(
                f"Failed to load logging config: {e}",
                suggestion="Check that the file contains valid configuration",
            ) from e
