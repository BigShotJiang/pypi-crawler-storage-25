"""Observability utilities for structured logging and debugging.

This module provides practical utilities to help any Python library enable
structured logging, rich console output, and simple tracing/debugging.
"""

# Logging utilities
# Simple decorators
from dspu.observability.decorators import logged_errors, timed, traced
from dspu.observability.logging import (
    ConsoleFormatter,
    JSONFormatter,
    LogContext,
    StructuredLogger,
    bind_context,
    clear_context,
    configure_from_env,
    configure_logging,
    get_context,
    get_logger,
    unbind_context,
)

# Rich output utilities
from dspu.observability.rich_output import (
    Progress,
    RichConsoleHandler,
    TaskProgress,
    get_console,
    inspect_object,
    print_json,
    print_table,
    print_traceback,
    print_tree,
)

# Logging setup
from dspu.observability.setup import LoggingSetup

# Stream capture
from dspu.observability.stream_capture import StreamToLogger

__all__ = [
    "ConsoleFormatter",
    "JSONFormatter",
    "LogContext",
    # Logging setup
    "LoggingSetup",
    "Progress",
    # Rich output
    "RichConsoleHandler",
    # Stream capture
    "StreamToLogger",
    "StructuredLogger",
    "TaskProgress",
    "bind_context",
    "clear_context",
    "configure_from_env",
    "configure_logging",
    "get_console",
    "get_context",
    # Logging
    "get_logger",
    "inspect_object",
    "logged_errors",
    "print_json",
    "print_table",
    "print_traceback",
    "print_tree",
    # Decorators
    "timed",
    "traced",
    "unbind_context",
]
