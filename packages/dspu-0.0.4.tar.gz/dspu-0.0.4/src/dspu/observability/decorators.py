"""Simple tracing and debugging decorators.

This module provides lightweight decorators for timing functions,
tracing execution, and logging errors.
"""

import asyncio
import functools
import logging
import time
from collections.abc import Callable
from typing import Any, TypeVar

# Type variable for decorators
F = TypeVar("F", bound=Callable[..., Any])


def timed(
    logger: logging.Logger | str | None = None,
    level: int = logging.INFO,
    threshold_ms: float | None = None,
) -> Callable[[F], F]:
    """Decorator to log function execution time.

    Args:
        logger: Logger instance or name. If None, uses function's module logger.
        level: Log level (default: INFO).
        threshold_ms: Only log if execution time exceeds this threshold (milliseconds).

    Returns:
        Decorated function.

    Example:
        >>> @timed()
        ... def slow_function():
        ...     time.sleep(1)
        ...     return "done"
        >>> slow_function()  # Logs: "slow_function took 1000.5ms"

        >>> @timed(threshold_ms=100)
        ... def fast_function():
        ...     return "quick"
        >>> fast_function()  # Not logged (below threshold)
    """

    def decorator(func: F) -> F:
        # Get logger
        if isinstance(logger, str):
            log = logging.getLogger(logger)
        elif logger is not None:
            log = logger
        else:
            log = logging.getLogger(func.__module__)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            start_time = time.perf_counter()
            try:
                return func(*args, **kwargs)
            finally:
                duration_ms = (time.perf_counter() - start_time) * 1000

                # Only log if threshold not set or exceeded
                if threshold_ms is None or duration_ms >= threshold_ms:
                    log.log(
                        level,
                        f"{func.__name__} took {duration_ms:.2f}ms",
                    )

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            start_time = time.perf_counter()
            try:
                return await func(*args, **kwargs)
            finally:
                duration_ms = (time.perf_counter() - start_time) * 1000

                # Only log if threshold not set or exceeded
                if threshold_ms is None or duration_ms >= threshold_ms:
                    log.log(
                        level,
                        f"{func.__name__} took {duration_ms:.2f}ms",
                    )

        # Return appropriate wrapper
        if asyncio.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        return sync_wrapper  # type: ignore

    return decorator


def traced(
    logger: logging.Logger | str | None = None,
    level: int = logging.DEBUG,
    log_args: bool = True,
    log_result: bool = False,
) -> Callable[[F], F]:
    """Decorator to trace function entry/exit and log arguments.

    Args:
        logger: Logger instance or name. If None, uses function's module logger.
        level: Log level (default: DEBUG).
        log_args: If True, log function arguments.
        log_result: If True, log function return value.

    Returns:
        Decorated function.

    Example:
        >>> @traced()
        ... def process_order(order_id: str, items: list) -> dict:
        ...     return {"status": "success"}
        >>> process_order("123", ["item1", "item2"])
        # Logs: "Entering process_order(order_id='123', items=['item1', 'item2'])"
        # Logs: "Exiting process_order"
    """

    def decorator(func: F) -> F:
        # Get logger
        if isinstance(logger, str):
            log = logging.getLogger(logger)
        elif logger is not None:
            log = logger
        else:
            log = logging.getLogger(func.__module__)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Log entry
            if log_args:
                # Format arguments
                arg_strs = [repr(arg) for arg in args]
                kwarg_strs = [f"{k}={v!r}" for k, v in kwargs.items()]
                all_args = ", ".join(arg_strs + kwarg_strs)
                log.log(level, f"Entering {func.__name__}({all_args})")
            else:
                log.log(level, f"Entering {func.__name__}")

            try:
                result = func(*args, **kwargs)

                # Log exit with result
                if log_result:
                    log.log(level, f"Exiting {func.__name__} -> {result!r}")
                else:
                    log.log(level, f"Exiting {func.__name__}")

                return result

            except Exception as e:
                log.log(level, f"Exception in {func.__name__}: {e}", exc_info=True)
                raise

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Log entry
            if log_args:
                # Format arguments
                arg_strs = [repr(arg) for arg in args]
                kwarg_strs = [f"{k}={v!r}" for k, v in kwargs.items()]
                all_args = ", ".join(arg_strs + kwarg_strs)
                log.log(level, f"Entering {func.__name__}({all_args})")
            else:
                log.log(level, f"Entering {func.__name__}")

            try:
                result = await func(*args, **kwargs)

                # Log exit with result
                if log_result:
                    log.log(level, f"Exiting {func.__name__} -> {result!r}")
                else:
                    log.log(level, f"Exiting {func.__name__}")

                return result

            except Exception as e:
                log.log(level, f"Exception in {func.__name__}: {e}", exc_info=True)
                raise

        # Return appropriate wrapper
        if asyncio.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        return sync_wrapper  # type: ignore

    return decorator


def logged_errors(
    logger: logging.Logger | str | None = None,
    level: int = logging.ERROR,
    reraise: bool = True,
    include_traceback: bool = True,
) -> Callable[[F], F]:
    """Decorator to automatically log exceptions.

    Args:
        logger: Logger instance or name. If None, uses function's module logger.
        level: Log level for errors (default: ERROR).
        reraise: If True, re-raise exception after logging (default: True).
        include_traceback: If True, include full traceback in log.

    Returns:
        Decorated function.

    Example:
        >>> @logged_errors()
        ... def risky_operation():
        ...     raise ValueError("Something went wrong")
        >>> risky_operation()  # Logs error with traceback, then raises

        >>> @logged_errors(reraise=False)
        ... def safe_operation():
        ...     raise ValueError("Handled")
        ...     return None
        >>> safe_operation()  # Logs error but doesn't raise
    """

    def decorator(func: F) -> F:
        # Get logger
        if isinstance(logger, str):
            log = logging.getLogger(logger)
        elif logger is not None:
            log = logger
        else:
            log = logging.getLogger(func.__module__)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Log the error
                log.log(
                    level,
                    f"Error in {func.__name__}: {type(e).__name__}: {e}",
                    exc_info=include_traceback,
                )

                # Re-raise if configured
                if reraise:
                    raise

                return None

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                # Log the error
                log.log(
                    level,
                    f"Error in {func.__name__}: {type(e).__name__}: {e}",
                    exc_info=include_traceback,
                )

                # Re-raise if configured
                if reraise:
                    raise

                return None

        # Return appropriate wrapper
        if asyncio.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        return sync_wrapper  # type: ignore

    return decorator
