"""Rich console output utilities.

This module provides utilities for pretty console output using the rich library.
"""

import logging
from typing import Any

from dspu.core.exceptions import ConfigurationError


class RichConsoleHandler(logging.Handler):
    """Logging handler with rich console output.

    Provides colorized, formatted log output with syntax highlighting
    and rich tracebacks.

    Example:
        >>> handler = RichConsoleHandler(show_time=True, show_path=True)
        >>> logger.addHandler(handler)
    """

    def __init__(
        self,
        show_time: bool = True,
        show_path: bool = True,
        show_level: bool = True,
        enable_link_path: bool = True,
        markup: bool = False,
        rich_tracebacks: bool = True,
        **kwargs: Any,
    ):
        """Initialize rich console handler.

        Args:
            show_time: Show timestamp in logs.
            show_path: Show file path in logs.
            show_level: Show log level in logs.
            enable_link_path: Enable clickable file paths.
            markup: Enable rich markup in log messages.
            rich_tracebacks: Use rich formatting for exceptions.
            **kwargs: Additional arguments for RichHandler.

        Raises:
            ConfigurationError: If rich is not installed.
        """
        super().__init__()

        try:
            from rich.logging import RichHandler
        except ImportError as e:
            raise ConfigurationError(
                "RichConsoleHandler requires rich library",
                suggestion="Install with: pip install rich",
            ) from e

        self._handler = RichHandler(
            show_time=show_time,
            show_path=show_path,
            show_level=show_level,
            enable_link_path=enable_link_path,
            markup=markup,
            rich_tracebacks=rich_tracebacks,
            **kwargs,
        )

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record.

        Args:
            record: Log record to emit.
        """
        self._handler.emit(record)


# Singleton console instance
_console = None


def get_console() -> Any:
    """Get rich console instance.

    Returns:
        Rich Console instance.

    Raises:
        ConfigurationError: If rich is not installed.

    Example:
        >>> console = get_console()
        >>> console.print("[bold green]Success![/bold green]")
    """
    global _console

    if _console is None:
        try:
            from rich.console import Console

            _console = Console()
        except ImportError as e:
            raise ConfigurationError(
                "Rich console requires rich library",
                suggestion="Install with: pip install rich",
            ) from e

    return _console


def print_json(data: Any, **kwargs: Any) -> None:
    """Pretty-print JSON data with syntax highlighting.

    Args:
        data: Data to print (will be JSON-serialized).
        **kwargs: Additional arguments for rich JSON printing.

    Example:
        >>> print_json({"user": "alice", "items": [1, 2, 3]})
    """
    try:
        from rich.json import JSON
    except ImportError as e:
        raise ConfigurationError(
            "print_json requires rich library",
            suggestion="Install with: pip install rich",
        ) from e

    import json

    console = get_console()
    json_str = json.dumps(data, indent=2, default=str)
    console.print(JSON(json_str), **kwargs)


def print_table(
    data: list[dict[str, Any]],
    title: str | None = None,
    **kwargs: Any,
) -> None:
    """Display tabular data in a formatted table.

    Args:
        data: List of dictionaries to display.
        title: Optional table title.
        **kwargs: Additional arguments for rich Table.

    Example:
        >>> data = [
        ...     {"name": "Alice", "age": 30},
        ...     {"name": "Bob", "age": 25},
        ... ]
        >>> print_table(data, title="Users")
    """
    try:
        from rich.table import Table
    except ImportError as e:
        raise ConfigurationError(
            "print_table requires rich library",
            suggestion="Install with: pip install rich",
        ) from e

    if not data:
        return

    console = get_console()
    table = Table(title=title, **kwargs)

    # Add columns from first row
    for key in data[0].keys():
        table.add_column(str(key), style="cyan")

    # Add rows
    for row in data:
        table.add_row(*[str(v) for v in row.values()])

    console.print(table)


def print_tree(data: dict[str, Any], title: str = "Data") -> None:
    """Display hierarchical data as a tree.

    Args:
        data: Nested dictionary to display.
        title: Tree title.

    Example:
        >>> data = {
        ...     "root": {
        ...         "child1": {"leaf1": "value1"},
        ...         "child2": {"leaf2": "value2"},
        ...     }
        ... }
        >>> print_tree(data)
    """
    try:
        from rich.tree import Tree
    except ImportError as e:
        raise ConfigurationError(
            "print_tree requires rich library",
            suggestion="Install with: pip install rich",
        ) from e

    console = get_console()

    def build_tree(node: Tree, data: Any) -> None:
        """Recursively build tree."""
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    branch = node.add(f"[bold]{key}[/bold]")
                    build_tree(branch, value)
                else:
                    node.add(f"{key}: {value}")
        elif isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, (dict, list)):
                    branch = node.add(f"[bold][{i}][/bold]")
                    build_tree(branch, item)
                else:
                    node.add(f"[{i}]: {item}")

    tree = Tree(title)
    build_tree(tree, data)
    console.print(tree)


def print_traceback(
    *,
    show_locals: bool = False,
    max_frames: int = 20,
    **kwargs: Any,
) -> None:
    """Print enhanced traceback for current exception.

    Args:
        show_locals: Show local variables in traceback.
        max_frames: Maximum number of stack frames to show.
        **kwargs: Additional arguments for rich Traceback.

    Example:
        >>> try:
        ...     risky_operation()
        ... except Exception:
        ...     print_traceback(show_locals=True)
    """
    try:
        from rich.traceback import Traceback
    except ImportError as e:
        raise ConfigurationError(
            "print_traceback requires rich library",
            suggestion="Install with: pip install rich",
        ) from e

    console = get_console()
    console.print(
        Traceback(
            show_locals=show_locals,
            max_frames=max_frames,
            **kwargs,
        )
    )


def inspect_object(
    obj: Any,
    methods: bool = False,
    private: bool = False,
    **kwargs: Any,
) -> None:
    """Rich inspection of an object.

    Args:
        obj: Object to inspect.
        methods: Show methods.
        private: Show private attributes.
        **kwargs: Additional arguments for rich inspect.

    Example:
        >>> inspect_object(my_object, methods=True)
    """
    try:
        from rich import inspect as rich_inspect
    except ImportError as e:
        raise ConfigurationError(
            "inspect_object requires rich library",
            suggestion="Install with: pip install rich",
        ) from e

    rich_inspect(
        obj,
        methods=methods,
        private=private,
        console=get_console(),
        **kwargs,
    )


class Progress:
    """Progress bar context manager.

    Example:
        >>> with Progress() as progress:
        ...     task = progress.add_task("Processing", total=1000)
        ...     for i in range(1000):
        ...         process_item(i)
        ...         progress.update(task, advance=1)
    """

    def __init__(self, **kwargs: Any):
        """Initialize progress.

        Args:
            **kwargs: Arguments for rich Progress.
        """
        try:
            from rich.progress import Progress as RichProgress

            self._progress_class = RichProgress
        except ImportError as e:
            raise ConfigurationError(
                "Progress requires rich library",
                suggestion="Install with: pip install rich",
            ) from e

        self._progress = None
        self._kwargs = kwargs

    def __enter__(self) -> Any:
        """Enter context."""
        self._progress = self._progress_class(**self._kwargs)
        return self._progress.__enter__()

    def __exit__(self, *args: Any) -> None:
        """Exit context."""
        if self._progress:
            self._progress.__exit__(*args)


class TaskProgress:
    """Multi-task progress tracking.

    Example:
        >>> with TaskProgress() as progress:
        ...     download = progress.add_task("Downloading", total=100)
        ...     extract = progress.add_task("Extracting", total=100)
        ...     for i in range(100):
        ...         progress.update(download, advance=1)
    """

    def __init__(self, **kwargs: Any):
        """Initialize task progress.

        Args:
            **kwargs: Arguments for rich Progress.
        """
        try:
            from rich.progress import (
                BarColumn,
                MofNCompleteColumn,
                SpinnerColumn,
                TaskProgressColumn,
                TextColumn,
                TimeElapsedColumn,
            )
            from rich.progress import (
                Progress as RichProgress,
            )

            self._progress_class = RichProgress
            self._columns = [
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
            ]
        except ImportError as e:
            raise ConfigurationError(
                "TaskProgress requires rich library",
                suggestion="Install with: pip install rich",
            ) from e

        self._progress = None
        self._kwargs = kwargs

    def __enter__(self) -> Any:
        """Enter context."""
        self._progress = self._progress_class(*self._columns, **self._kwargs)
        return self._progress.__enter__()

    def __exit__(self, *args: Any) -> None:
        """Exit context."""
        if self._progress:
            self._progress.__exit__(*args)
