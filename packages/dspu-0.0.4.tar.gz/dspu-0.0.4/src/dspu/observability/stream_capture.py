"""Stream capture utilities for redirecting stdout/stderr to loggers.

This module provides utilities to redirect print statements and standard
streams to Python loggers.
"""

import errno
import logging
import sys
from io import StringIO


class StreamToLogger(StringIO):
    """File-like stream that redirects writes to a logger.

    Redirects stdout/stderr to a logger instance, useful for capturing
    print statements in logging output. Includes protection against
    infinite recursion when loggers output to stdout.

    Example:
        >>> logger = logging.getLogger(__name__)
        >>> StreamToLogger.subvert(logger, reroute_stdout=True)
        >>> print("This goes to the logger")
    """

    def __init__(self, logger: logging.Logger, log_level: int = logging.INFO):
        """Initialize stream-to-logger adapter.

        Args:
            logger: Logger to redirect writes to.
            log_level: Logging level for writes (default: INFO).
        """
        super().__init__()
        self.logger = logger
        self.log_level = log_level

        # Stacks to help avoid infinite recursion
        self.last_logged: list[str] = []
        self.last_num_lines_logged: list[int] = []

    def write(self, s: str) -> int:
        """Write string to logger.

        Args:
            s: String to write to log.

        Returns:
            Number of characters written.
        """
        # Parse incoming string
        stripped = s.rstrip()
        lines = stripped.splitlines()
        num_lines = len(lines)

        # Check for exceptions that indicate logging issues
        exception_type, exception_value, _ = sys.exc_info()

        # Detect infinite loop conditions
        dont_log = False

        # If we've logged something in this call stack
        if len(self.last_num_lines_logged) > 0:
            # ... and same number of lines as before
            dont_log = self.last_num_lines_logged[-1] == num_lines
            # ... and the string we last logged is in what we're trying to log
            dont_log = dont_log and self.last_logged[-1] in stripped

        # Prevent infinite loops on logging errors
        dont_log = dont_log or (exception_type is BrokenPipeError)
        dont_log = dont_log or (exception_type is RecursionError)
        dont_log = dont_log or (
            (exception_type is OSError) and (str(exception_value) == str(errno.EPIPE))
        )
        dont_log = dont_log or (num_lines > 0 and lines[0].startswith("--- Logging error ---"))

        if dont_log:
            # Bail to avoid infinite recursion
            return 0

        # Push current information on stacks
        self.last_logged.append(stripped)
        self.last_num_lines_logged.append(num_lines)

        # Write each line separately
        for line in lines:
            line_to_write = line.rstrip()
            if line_to_write:  # Only log non-empty lines
                self.logger.log(self.log_level, line_to_write)

        # Pop current information off stacks
        self.last_logged.pop()
        self.last_num_lines_logged.pop()

        return len(s)

    def flush(self) -> None:
        """Flush the stream (no-op for logger)."""
        pass

    @classmethod
    def subvert(
        cls,
        logger: logging.Logger | None = None,
        reroute_stdout: bool = True,
        reroute_stderr: bool = True,
    ) -> None:
        """Subvert stdout and stderr to logger.

        Args:
            logger: Logger to use for subverting stdout/stderr.
                   If None, creates new logger from class name.
            reroute_stdout: If True, reroute stdout to logger.
            reroute_stderr: If True, reroute stderr to logger.

        Example:
            >>> logger = logging.getLogger(__name__)
            >>> StreamToLogger.subvert(logger, reroute_stdout=True)
            >>> print("This goes to the logger at INFO level")
        """
        # Get or create logger
        use_logger = logger
        if use_logger is None:
            use_logger = logging.getLogger(cls.__name__)

        # Reroute stdout to INFO level
        if reroute_stdout:
            info_stream_logger = cls(use_logger, logging.INFO)
            sys.stdout = info_stream_logger  # type: ignore

        # Reroute stderr to ERROR level
        if reroute_stderr:
            error_stream_logger = cls(use_logger, logging.ERROR)
            sys.stderr = error_stream_logger  # type: ignore

    @classmethod
    def restore(cls) -> None:
        """Restore stdout and stderr to their original state.

        Example:
            >>> StreamToLogger.restore()
            >>> print("This goes to normal stdout")
        """
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
