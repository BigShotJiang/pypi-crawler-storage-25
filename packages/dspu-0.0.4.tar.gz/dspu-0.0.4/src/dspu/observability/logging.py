"""Structured logging utilities.

This module provides utilities to help any Python library set up structured logging
with support for multiple backends and output formats.
"""

import logging
import os
import sys
from contextvars import ContextVar
from typing import Any

# Context variable for log context (thread/async-safe)
_log_context: ContextVar[dict[str, Any] | None] = ContextVar("log_context", default=None)


class StructuredLogger(logging.LoggerAdapter):
    """Logger adapter that adds structured context to log records.

    Example:
        >>> logger = StructuredLogger(logging.getLogger(__name__))
        >>> logger.info("User login", user_id=123, ip="192.168.1.1")
    """

    def process(self, msg: str, kwargs: dict[str, Any]) -> tuple[str, dict[str, Any]]:  # type: ignore[override]
        """Add context to log record.

        Args:
            msg: Log message.
            kwargs: Keyword arguments.

        Returns:
            Tuple of (message, kwargs) with added context.
        """
        # Get context from contextvars
        context = (_log_context.get() or {}).copy()

        # Merge with extra fields from kwargs
        extra = kwargs.get("extra", {})
        extra.update(context)

        # Add any additional keyword arguments as extra fields
        for key, value in list(kwargs.items()):
            if key not in ("extra", "exc_info", "stack_info", "stacklevel"):
                extra[key] = value
                kwargs.pop(key)

        kwargs["extra"] = extra
        return msg, kwargs


def get_logger(name: str | None = None) -> StructuredLogger:
    """Get a structured logger instance.

    Args:
        name: Logger name (typically __name__). If None, returns root logger.

    Returns:
        StructuredLogger instance.

    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("Application started", version="1.0.0")
    """
    base_logger = logging.getLogger(name)
    return StructuredLogger(base_logger, {})


def configure_logging(
    level: str | int = "INFO",
    format: str = "console",  # noqa: A002
    outputs: list[str] | None = None,
    show_time: bool = True,
    show_name: bool = True,
    show_level: bool = True,
) -> None:
    """Configure logging with sensible defaults.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        format: Output format ("console", "json", "rich").
        outputs: List of outputs (e.g., ["stdout", "file:app.log"]).
        show_time: Show timestamp in logs.
        show_name: Show logger name in logs.
        show_level: Show log level in logs.

    Example:
        >>> configure_logging(level="INFO", format="json")
        >>> configure_logging(level="DEBUG", format="rich", outputs=["stdout", "file:app.log"])
    """
    if outputs is None:
        outputs = ["stdout"]

    # Convert string level to int
    if isinstance(level, str):
        level = getattr(logging, level.upper())

    # Create formatter based on format type
    if format == "json":
        formatter = JSONFormatter(show_time=show_time)
    elif format == "rich":
        formatter = None  # Rich handler has its own formatting
    else:  # console
        formatter = ConsoleFormatter(
            show_time=show_time,
            show_name=show_name,
            show_level=show_level,
        )

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()

    # Add handlers for each output
    for output in outputs:
        if output == "stdout":
            handler = logging.StreamHandler(sys.stdout)
        elif output == "stderr":
            handler = logging.StreamHandler(sys.stderr)
        elif output.startswith("file:"):
            filename = output[5:]  # Remove "file:" prefix
            handler = logging.FileHandler(filename)
        else:
            continue

        if format == "rich":
            # Import rich handler lazily
            try:
                from dspu.observability.rich_output import (
                    RichConsoleHandler,
                )

                handler = RichConsoleHandler(
                    show_time=show_time,
                    show_path=show_name,
                )
            except ImportError:
                # Fall back to console format if rich not available
                handler.setFormatter(formatter)
        else:
            handler.setFormatter(formatter)

        handler.setLevel(level)
        root_logger.addHandler(handler)


def configure_from_env() -> None:
    """Configure logging from environment variables.

    Environment variables:
        LOG_LEVEL: Log level (default: INFO)
        LOG_FORMAT: Output format (default: console)
        LOG_OUTPUT: Comma-separated outputs (default: stdout)

    Example:
        >>> os.environ["LOG_LEVEL"] = "DEBUG"
        >>> os.environ["LOG_FORMAT"] = "json"
        >>> configure_from_env()
    """
    level = os.getenv("LOG_LEVEL", "INFO")
    format_type = os.getenv("LOG_FORMAT", "console")
    output_str = os.getenv("LOG_OUTPUT", "stdout")
    outputs = [o.strip() for o in output_str.split(",")]

    configure_logging(level=level, format=format_type, outputs=outputs)


class ConsoleFormatter(logging.Formatter):
    """Console formatter for human-readable logs.

    Example output:
        2024-12-05 10:30:45 INFO myapp.core: User login (user_id=123)
    """

    def __init__(
        self,
        show_time: bool = True,
        show_name: bool = True,
        show_level: bool = True,
    ):
        """Initialize console formatter.

        Args:
            show_time: Show timestamp.
            show_name: Show logger name.
            show_level: Show log level.
        """
        self.show_time = show_time
        self.show_name = show_name
        self.show_level = show_level

        # Build format string
        parts = []
        if show_time:
            parts.append("%(asctime)s")
        if show_level:
            parts.append("%(levelname)s")
        if show_name:
            parts.append("%(name)s:")

        parts.append("%(message)s")
        fmt = " ".join(parts)

        super().__init__(fmt, datefmt="%Y-%m-%d %H:%M:%S")

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with extra fields.

        Args:
            record: Log record.

        Returns:
            Formatted log string.
        """
        # Format base message
        message = super().format(record)

        # Add extra fields
        extra_fields = []
        for key, value in vars(record).items():
            if key not in (
                "name",
                "msg",
                "args",
                "created",
                "filename",
                "funcName",
                "levelname",
                "levelno",
                "lineno",
                "module",
                "msecs",
                "message",
                "pathname",
                "process",
                "processName",
                "relativeCreated",
                "thread",
                "threadName",
                "exc_info",
                "exc_text",
                "stack_info",
                "asctime",
            ):
                extra_fields.append(f"{key}={value!r}")

        if extra_fields:
            message = f"{message} ({', '.join(extra_fields)})"

        return message


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logs.

    Example output:
        {"timestamp":"2024-12-05T10:30:45","level":"INFO","message":"User login","user_id":123}
    """

    def __init__(self, show_time: bool = True):
        """Initialize JSON formatter.

        Args:
            show_time: Include timestamp in output.
        """
        self.show_time = show_time
        super().__init__()

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON.

        Args:
            record: Log record.

        Returns:
            JSON-formatted log string.
        """
        import json
        from datetime import datetime

        log_data: dict[str, Any] = {
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
        }

        if self.show_time:
            log_data["timestamp"] = datetime.fromtimestamp(record.created).isoformat()

        # Add extra fields
        for key, value in vars(record).items():
            if key not in (
                "name",
                "msg",
                "args",
                "created",
                "filename",
                "funcName",
                "levelname",
                "levelno",
                "lineno",
                "module",
                "msecs",
                "message",
                "pathname",
                "process",
                "processName",
                "relativeCreated",
                "thread",
                "threadName",
                "exc_info",
                "exc_text",
                "stack_info",
                "logger",
                "level",
                "timestamp",
                "asctime",
            ):
                # Only add serializable extra fields
                try:
                    json.dumps(value)
                    log_data[key] = value
                except (TypeError, ValueError):
                    log_data[key] = str(value)

        # Add exception info if present
        if record.exc_info:
            import traceback

            log_data["exception"] = "".join(traceback.format_exception(*record.exc_info))

        return json.dumps(log_data)


class LogContext:
    """Context manager for adding temporary log context.

    Example:
        >>> with LogContext(request_id="req-123", user_id=456):
        ...     logger.info("Processing")  # Includes request_id and user_id
    """

    def __init__(self, **context: Any):
        """Initialize log context.

        Args:
            **context: Context fields to add.
        """
        self.context = context
        self.token = None
        self.previous_context = None

    def __enter__(self) -> "LogContext":
        """Enter context."""
        # Get current context and add new fields
        self.previous_context = (_log_context.get() or {}).copy()
        new_context = self.previous_context.copy()
        new_context.update(self.context)

        # Set new context
        self.token = _log_context.set(new_context)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit context and restore previous context."""
        if self.token is not None:
            _log_context.reset(self.token)


def bind_context(**context: Any) -> None:
    """Add persistent context fields to all subsequent logs.

    Args:
        **context: Context fields to add.

    Example:
        >>> bind_context(service="api", version="1.0.0")
        >>> logger.info("Started")  # Includes service and version
    """
    current = (_log_context.get() or {}).copy()
    current.update(context)
    _log_context.set(current)


def unbind_context(*keys: str) -> None:
    """Remove context fields.

    Args:
        *keys: Context field keys to remove.

    Example:
        >>> unbind_context("request_id", "user_id")
    """
    current = (_log_context.get() or {}).copy()
    for key in keys:
        current.pop(key, None)
    _log_context.set(current)


def clear_context() -> None:
    """Clear all context fields.

    Example:
        >>> clear_context()
    """
    _log_context.set({})


def get_context() -> dict[str, Any]:
    """Get current log context.

    Returns:
        Dictionary of current context fields.

    Example:
        >>> context = get_context()
        >>> print(context["request_id"])
    """
    return (_log_context.get() or {}).copy()
