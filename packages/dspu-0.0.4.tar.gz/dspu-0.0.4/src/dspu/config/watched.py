"""Watched configuration with automatic reload.

This module provides a configuration wrapper that watches source files
and automatically reloads when changes are detected.

Example:
    >>> from dspu.config.watched import WatchedConfig
    >>> from dspu.config.sources import FileSource
    >>>
    >>> watched = WatchedConfig.load(
    ...     AppConfig,
    ...     source=FileSource("config.yaml"),
    ...     reload_interval=5.0,
    ... )
    >>>
    >>> # Access current config
    >>> print(watched.current.debug)
    >>>
    >>> # Register callback for changes
    >>> def on_config_change(old, new):
    ...     print(f"Config changed: debug {old.debug} -> {new.debug}")
    >>> watched.on_change(on_config_change)
"""

import threading
from collections.abc import Callable, Sequence
from pathlib import Path
from types import TracebackType
from typing import Generic, TypeVar

from pydantic import BaseModel

from dspu.config.config import Config
from dspu.config.sources import ConfigSource, FileSource
from dspu.core.exceptions import ConfigurationError

T = TypeVar("T", bound=BaseModel)


class WatchedConfig(Generic[T]):
    """Configuration that watches for file changes and automatically reloads.

    This class wraps a configuration and monitors the source files for changes.
    When a change is detected, the configuration is automatically reloaded and
    registered callbacks are invoked.

    Example:
        >>> watched = WatchedConfig.load(
        ...     AppConfig,
        ...     source=FileSource("config.yaml"),
        ...     reload_interval=5.0,
        ... )
        >>>
        >>> # Use current config
        >>> app = Application(watched.current)
        >>>
        >>> # Register callback
        >>> watched.on_change(lambda old, new: app.reconfigure(new))
        >>>
        >>> # When config.yaml changes, app.reconfigure() is called
        >>> # Stop watching when done
        >>> watched.stop()

    Note:
        - Only works with FileSource (needs file to watch)
        - Callbacks are called in a background thread
        - Always call stop() when done or use as context manager
    """

    def __init__(
        self,
        config_class: type[T],
        sources: Sequence[ConfigSource],
        reload_interval: float = 5.0,
    ) -> None:
        """Initialize watched configuration.

        Args:
            config_class: Pydantic model class for validation.
            sources: Configuration sources to watch.
            reload_interval: How often to check for changes (seconds).

        Raises:
            ConfigurationError: If no file sources are provided.
        """
        self._config_class = config_class
        self._sources = list(sources)
        self._reload_interval = reload_interval

        # Extract file paths to watch
        self._watched_files: list[Path] = []
        for source in sources:
            if isinstance(source, FileSource) and source.path.exists():
                self._watched_files.append(source.path)

        if not self._watched_files:
            raise ConfigurationError(
                "WatchedConfig requires at least one FileSource",
                suggestion="Add a FileSource to your sources list",
            )

        # Load initial configuration
        self._current = Config.load(config_class, sources)
        self._lock = threading.RLock()
        self._callbacks: list[Callable[[T, T], None]] = []

        # File modification times
        self._mtimes: dict[Path, float] = {}
        for path in self._watched_files:
            self._mtimes[path] = path.stat().st_mtime

        # Background watcher thread
        self._stop_event = threading.Event()
        self._watcher_thread = threading.Thread(
            target=self._watch_loop,
            daemon=True,
            name="config-watcher",
        )
        self._watcher_thread.start()

    @classmethod
    def load(
        cls,
        config_class: type[T],
        source: ConfigSource | None = None,
        sources: Sequence[ConfigSource] | None = None,
        reload_interval: float = 5.0,
    ) -> "WatchedConfig[T]":
        """Load watched configuration from source(s).

        Args:
            config_class: Pydantic model class for validation.
            source: Single configuration source (convenience).
            sources: Multiple configuration sources.
            reload_interval: How often to check for changes (seconds).

        Returns:
            WatchedConfig instance.

        Raises:
            ConfigurationError: If neither source nor sources provided.

        Example:
            >>> # Single source
            >>> watched = WatchedConfig.load(
            ...     AppConfig,
            ...     source=FileSource("config.yaml"),
            ... )
            >>>
            >>> # Multiple sources
            >>> watched = WatchedConfig.load(
            ...     AppConfig,
            ...     sources=[
            ...         FileSource("base.yaml"),
            ...         FileSource("local.yaml", required=False),
            ...     ],
            ... )
        """
        if source is not None and sources is not None:
            raise ConfigurationError("Provide either 'source' or 'sources', not both")

        if source is not None:
            sources = [source]
        elif sources is None:
            raise ConfigurationError(
                "Must provide either 'source' or 'sources'",
                suggestion="Pass a FileSource or list of sources",
            )

        return cls(config_class, sources, reload_interval)

    @property
    def current(self) -> T:
        """Get current configuration.

        This property is thread-safe and always returns the latest
        validated configuration.

        Returns:
            Current configuration instance.
        """
        with self._lock:
            return self._current

    def on_change(self, callback: Callable[[T, T], None]) -> None:
        """Register a callback for configuration changes.

        The callback is called with (old_config, new_config) when
        the configuration is successfully reloaded after a file change.

        Args:
            callback: Function to call on config change.
                Signature: (old: T, new: T) -> None

        Example:
            >>> def log_change(old, new):
            ...     print(f"Debug mode: {old.debug} -> {new.debug}")
            >>>
            >>> watched.on_change(log_change)
        """
        with self._lock:
            self._callbacks.append(callback)

    def reload(self) -> bool:
        """Manually reload configuration.

        Forces a reload regardless of file modification times.

        Returns:
            True if config was reloaded successfully, False otherwise.
        """
        try:
            new_config = Config.load(self._config_class, self._sources)

            with self._lock:
                old_config = self._current
                self._current = new_config

                # Call callbacks
                for callback in self._callbacks:
                    try:  # noqa: SIM105
                        callback(old_config, new_config)
                    except Exception:  # noqa: S110
                        # Don't let callback errors stop reload
                        pass

            return True

        except Exception:
            # Reload failed, keep current config
            return False

    def stop(self) -> None:
        """Stop watching for file changes.

        Should be called when done with the configuration to clean up
        the background thread.
        """
        self._stop_event.set()
        if self._watcher_thread.is_alive():
            self._watcher_thread.join(timeout=self._reload_interval + 1)

    def _watch_loop(self) -> None:
        """Background loop that watches for file changes."""
        while not self._stop_event.is_set():
            # Check for file changes
            changed = False
            for path in self._watched_files:
                if not path.exists():
                    continue

                try:
                    current_mtime = path.stat().st_mtime
                    if current_mtime > self._mtimes[path]:
                        self._mtimes[path] = current_mtime
                        changed = True
                except OSError:
                    # File might have been temporarily unavailable
                    pass

            # Reload if any file changed
            if changed:
                self.reload()

            # Sleep until next check
            self._stop_event.wait(self._reload_interval)

    def __enter__(self) -> "WatchedConfig[T]":
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager - stop watching."""
        self.stop()

    def __del__(self) -> None:
        """Cleanup when garbage collected."""
        # Only stop if fully initialized
        if hasattr(self, "_stop_event"):
            self.stop()
