"""Main configuration management.

This module provides the primary Config class for loading and validating
configuration from multiple sources.
"""

from collections.abc import Sequence
from typing import Any, TypeVar

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from dspu.config.sources import ConfigSource
from dspu.core.exceptions import ConfigurationError, ValidationError

T = TypeVar("T", bound=BaseModel)


class Config:
    """Main configuration loader with Pydantic validation.

    Loads configuration from multiple sources with priority ordering
    (later sources override earlier ones) and validates using Pydantic models.

    Example:
        >>> from pydantic import BaseModel
        >>> from dspu.config import Config, ConfigSource
        >>>
        >>> class AppConfig(BaseModel):
        ...     debug: bool = False
        ...     port: int = 8000
        ...
        >>> config = Config.load(
        ...     AppConfig,
        ...     sources=[
        ...         ConfigSource.file("config.yaml"),
        ...         ConfigSource.env(prefix="APP_"),
        ...     ]
        ... )
        >>> config.port
        8000
    """

    @classmethod
    def load(
        cls,
        config_class: type[T],
        sources: Sequence[ConfigSource],
    ) -> T:
        """Load and validate configuration from multiple sources.

        Sources are applied in order, with later sources overriding earlier ones.
        The merged configuration is then validated using the Pydantic model.

        Args:
            config_class: Pydantic model class for validation.
            sources: List of configuration sources in priority order.

        Returns:
            Validated configuration instance.

        Raises:
            ConfigurationError: If loading from any source fails.
            ValidationError: If validation fails.

        Example:
            >>> config = Config.load(
            ...     AppConfig,
            ...     sources=[
            ...         DictSource({"debug": True}),
            ...         EnvSource(prefix="APP_"),
            ...     ]
            ... )
        """
        # Merge all sources
        merged: dict[str, Any] = {}

        for source in sources:
            try:
                data = source.load()
                cls._deep_merge(merged, data)
            except ConfigurationError:
                # Re-raise configuration errors as-is
                raise
            except Exception as e:
                raise ConfigurationError(
                    f"Failed to load from source {type(source).__name__}: {e}",
                    suggestion="Check source configuration and permissions",
                ) from e

        # Validate with Pydantic
        try:
            return config_class(**merged)
        except PydanticValidationError as e:
            # Convert Pydantic validation error to our ValidationError
            errors = e.errors()
            if errors:
                first_error = errors[0]
                field = ".".join(str(x) for x in first_error["loc"])
                raise ValidationError(
                    f"Configuration validation failed: {first_error['msg']}",
                    field=field,
                    value=first_error.get("input"),
                    constraint=first_error["type"],
                ) from e
            raise ValidationError(
                "Configuration validation failed",
                constraint="unknown",
            ) from e

    @classmethod
    def load_from_file(
        cls,
        config_class: type[T],
        path: str,
        *,
        format: str | None = None,  # noqa: A002
    ) -> T:
        """Load configuration from a single file.

        Convenience method for loading from a single file source.

        Args:
            config_class: Pydantic model class for validation.
            path: Path to configuration file.
            format: Format override (json, yaml, toml, hocon, env).

        Returns:
            Validated configuration instance.

        Example:
            >>> config = Config.load_from_file(AppConfig, "config.yaml")
        """
        from dspu.config.sources import FileSource  # noqa: PLC0415

        return cls.load(config_class, sources=[FileSource(path, format=format)])

    @classmethod
    def load_from_env(
        cls,
        config_class: type[T],
        *,
        prefix: str = "",
    ) -> T:
        """Load configuration from environment variables.

        Convenience method for loading from environment only.

        Args:
            config_class: Pydantic model class for validation.
            prefix: Only load variables starting with this prefix.

        Returns:
            Validated configuration instance.

        Example:
            >>> config = Config.load_from_env(AppConfig, prefix="APP_")
        """
        from dspu.config.sources import EnvSource  # noqa: PLC0415

        return cls.load(config_class, sources=[EnvSource(prefix=prefix)])

    @classmethod
    def _deep_merge(cls, target: dict[str, Any], source: dict[str, Any]) -> None:
        """Deep merge source dict into target dict.

        Args:
            target: Target dictionary to merge into (modified in place).
            source: Source dictionary to merge from.
        """
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                # Recursively merge nested dicts
                cls._deep_merge(target[key], value)
            else:
                # Override value
                target[key] = value
