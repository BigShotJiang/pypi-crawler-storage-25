"""Configuration source implementations.

This module provides different sources for loading configuration data.
"""

import json
import os
import tomllib
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, cast

import yaml
from dotenv import dotenv_values
from pyhocon import ConfigFactory

from dspu.core.exceptions import ConfigurationError


class ConfigSource(ABC):
    """Abstract base class for configuration sources."""

    @abstractmethod
    def load(self) -> dict[str, Any]:
        """Load configuration data from source.

        Returns:
            Dictionary containing configuration data.

        Raises:
            ConfigurationError: If loading fails.
        """
        ...


class DictSource(ConfigSource):
    """Configuration source from a Python dictionary.

    Useful for testing and programmatic configuration.

    Example:
        >>> source = DictSource({"debug": True, "port": 8000})
        >>> config = source.load()
        >>> config["debug"]
        True
    """

    def __init__(self, data: dict[str, Any]) -> None:
        """Initialize dictionary source.

        Args:
            data: Configuration dictionary.
        """
        self.data = data

    def load(self) -> dict[str, Any]:
        """Load configuration from dictionary."""
        return self.data.copy()


class FileSource(ConfigSource):
    """Configuration source from a file.

    Supports multiple formats:
    - JSON (.json)
    - YAML (.yaml, .yml)
    - TOML (.toml)
    - HOCON (.conf, .hocon)
    - ENV (.env)

    Format is auto-detected from file extension or can be specified explicitly.

    Example:
        >>> source = FileSource("config.yaml")
        >>> config = source.load()
        >>>
        >>> # Explicit format
        >>> source = FileSource("settings.txt", format="json")
        >>> config = source.load()
    """

    def __init__(
        self,
        path: str | Path,
        *,
        format: str | None = None,  # noqa: A002
        required: bool = True,
    ) -> None:
        """Initialize file source.

        Args:
            path: Path to configuration file.
            format: Format override (json, yaml, toml, hocon, env).
                   If None, auto-detect from extension.
            required: If True, raise error if file doesn't exist.
        """
        self.path = Path(path)
        self.format = format
        self.required = required

    def load(self) -> dict[str, Any]:
        """Load configuration from file.

        Returns:
            Configuration dictionary.

        Raises:
            ConfigurationError: If file cannot be read or parsed.
        """
        if not self.path.exists():
            if self.required:
                raise ConfigurationError(
                    f"Configuration file not found: {self.path}",
                    field="path",
                    suggestion=f"Create the file at {self.path}",
                )
            return {}

        # Determine format
        fmt = self.format or self._detect_format()

        try:
            content = self.path.read_text()

            if fmt == "json":
                return cast(dict[str, Any], json.loads(content))
            if fmt in ("yaml", "yml"):
                return cast(dict[str, Any], yaml.safe_load(content) or {})
            if fmt == "toml":
                return tomllib.loads(content)
            if fmt in ("hocon", "conf"):
                return cast(dict[str, Any], ConfigFactory.parse_string(content))
            if fmt == "env":
                # dotenv returns a dict directly
                return dict(dotenv_values(self.path))
            raise ConfigurationError(
                f"Unsupported format: {fmt}",
                field="format",
                suggestion="Supported formats: json, yaml, toml, hocon, env",
            )

        except json.JSONDecodeError as e:
            raise ConfigurationError(
                f"Invalid JSON in {self.path}: {e}",
                field="format",
                suggestion="Check JSON syntax",
            ) from e
        except yaml.YAMLError as e:
            raise ConfigurationError(
                f"Invalid YAML in {self.path}: {e}",
                field="format",
                suggestion="Check YAML syntax",
            ) from e
        except tomllib.TOMLDecodeError as e:
            raise ConfigurationError(
                f"Invalid TOML in {self.path}: {e}",
                field="format",
                suggestion="Check TOML syntax",
            ) from e
        except Exception as e:
            raise ConfigurationError(
                f"Failed to load config from {self.path}: {e}",
                suggestion="Check file format and permissions",
            ) from e

    def _detect_format(self) -> str:
        """Detect format from file extension.

        Returns:
            Format string.

        Raises:
            ConfigurationError: If format cannot be detected.
        """
        # Special case: .env files (starts with dot, no extension)
        if self.path.name.startswith(".env"):
            return "env"

        suffix = self.path.suffix.lstrip(".")

        format_map = {
            "json": "json",
            "yaml": "yaml",
            "yml": "yaml",
            "toml": "toml",
            "conf": "hocon",
            "hocon": "hocon",
            "env": "env",
        }

        fmt = format_map.get(suffix)
        if not fmt:
            raise ConfigurationError(
                f"Cannot detect format from extension: {suffix}",
                field="path",
                suggestion=f"Specify format explicitly or use: {', '.join(format_map.keys())}",
            )

        return fmt


class EnvSource(ConfigSource):
    """Configuration source from environment variables.

    Supports:
    - Optional prefix filtering
    - Nested keys using underscores or double underscores
    - Type conversion (numbers, booleans)

    Example:
        >>> # With prefix: APP_DEBUG=true, APP_PORT=8000
        >>> source = EnvSource(prefix="APP_")
        >>> config = source.load()
        >>> config
        {'debug': 'true', 'port': '8000'}
        >>>
        >>> # With nested keys: APP__DATABASE__HOST=localhost
        >>> source = EnvSource(prefix="APP__", separator="__")
        >>> config = source.load()
        >>> config
        {'database': {'host': 'localhost'}}
    """

    def __init__(
        self,
        *,
        prefix: str = "",
        separator: str = "__",
        lowercase: bool = True,
    ) -> None:
        """Initialize environment source.

        Args:
            prefix: Only load variables starting with this prefix.
            separator: Separator for nested keys (default: double underscore).
            lowercase: Convert keys to lowercase.
        """
        self.prefix = prefix
        self.separator = separator
        self.lowercase = lowercase

    def load(self) -> dict[str, Any]:
        """Load configuration from environment variables.

        Returns:
            Configuration dictionary with nested structure if separator is used.
        """
        config: dict[str, Any] = {}

        for key, value in os.environ.items():
            if not key.startswith(self.prefix):
                continue

            # Remove prefix
            clean_key = key[len(self.prefix) :]

            # Convert to lowercase if requested
            if self.lowercase:
                clean_key = clean_key.lower()

            # Handle nested keys
            if self.separator in clean_key:
                parts = clean_key.split(self.separator)
                self._set_nested(config, parts, value)
            else:
                config[clean_key] = value

        return config

    def _set_nested(self, config: dict[str, Any], parts: list[str], value: str) -> None:
        """Set nested dictionary value from key parts.

        Args:
            config: Configuration dictionary to modify.
            parts: Key parts for nested structure.
            value: Value to set.
        """
        current = config
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]

        current[parts[-1]] = value
