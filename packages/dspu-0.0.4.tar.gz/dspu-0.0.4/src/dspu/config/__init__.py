"""Configuration management with validation.

This module provides type-safe configuration loading from multiple sources
with Pydantic validation, file watching, and HashiCorp Vault integration.

Example:
    >>> from dspu.config import Config, FileSource, EnvSource
    >>> from pydantic import BaseModel
    >>>
    >>> class AppConfig(BaseModel):
    ...     app_name: str
    ...     debug: bool = False
    >>>
    >>> config = Config.load(
    ...     AppConfig,
    ...     sources=[
    ...         FileSource("config.yaml"),
    ...         EnvSource(prefix="APP_"),
    ...     ],
    ... )
"""

from dspu.config.config import Config
from dspu.config.sources import ConfigSource, DictSource, EnvSource, FileSource
from dspu.config.vault import VaultSource, is_vault_available
from dspu.config.watched import WatchedConfig

__all__ = [
    "Config",
    "ConfigSource",
    "DictSource",
    "EnvSource",
    "FileSource",
    "VaultSource",
    "WatchedConfig",
    "is_vault_available",
]
