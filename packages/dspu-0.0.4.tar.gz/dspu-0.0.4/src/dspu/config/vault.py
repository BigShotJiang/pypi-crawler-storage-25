"""Vault integration for secure configuration management.

This module provides HashiCorp Vault integration as an optional configuration source.
Requires: pip install hvac

Example:
    >>> from dspu.config.vault import VaultSource
    >>> source = VaultSource(
    ...     url="http://localhost:8200",
    ...     token="my-token",
    ...     path="secret/myapp"
    ... )
    >>> config = source.load()
"""

from typing import Any

from dspu.core.exceptions import ConfigurationError

try:
    import hvac
except ImportError:
    hvac = None

from dspu.config.sources import ConfigSource


class VaultSource(ConfigSource):
    """Configuration source from HashiCorp Vault.

    Fetches secrets from Vault's KV (Key-Value) secrets engine.

    Requires the 'hvac' package:
        pip install hvac

    Example:
        >>> source = VaultSource(
        ...     url="http://localhost:8200",
        ...     token="my-token",
        ...     path="secret/data/myapp",
        ... )
        >>> config = source.load()

    Authentication methods:
        1. Token (recommended for development):
            VaultSource(url=..., token="...")

        2. AppRole:
            VaultSource(
                url=...,
                role_id="...",
                secret_id="...",
            )

        3. Environment variables:
            VAULT_ADDR=http://localhost:8200
            VAULT_TOKEN=my-token
    """

    def __init__(
        self,
        url: str | None = None,
        token: str | None = None,
        path: str | None = None,
        *,
        role_id: str | None = None,
        secret_id: str | None = None,
        namespace: str | None = None,
        mount_point: str = "secret",
        verify: bool = True,
    ) -> None:
        """Initialize Vault source.

        Args:
            url: Vault server URL. If None, uses VAULT_ADDR env var.
            token: Vault token. If None, uses VAULT_TOKEN env var.
            path: Path to secret in Vault (e.g., "secret/data/myapp").
            role_id: AppRole role_id for authentication.
            secret_id: AppRole secret_id for authentication.
            namespace: Vault namespace (Vault Enterprise).
            mount_point: Mount point for KV secrets engine.
            verify: Verify TLS certificates.

        Raises:
            ConfigurationError: If hvac is not installed or configuration is invalid.
        """
        if hvac is None:
            raise ConfigurationError(
                "VaultSource requires the 'hvac' package",
                suggestion="Install with: pip install hvac",
            )

        # Type narrowing: hvac is guaranteed to be available after this point
        assert hvac is not None
        self.url = url
        self.token = token
        self.path = path
        self.role_id = role_id
        self.secret_id = secret_id
        self.namespace = namespace
        self.mount_point = mount_point
        self.verify = verify

        # Validate configuration
        if not self.path:
            raise ConfigurationError(
                "VaultSource requires 'path' parameter",
                field="path",
                suggestion="Provide path to secret in Vault (e.g., 'secret/data/myapp')",
            )

    def load(self) -> dict[str, Any]:
        """Load configuration from Vault.

        Returns:
            Configuration dictionary from Vault secret.

        Raises:
            ConfigurationError: If connection fails or secret not found.
        """
        assert hvac is not None  # Guaranteed by __init__ check
        try:
            # Initialize client
            client = hvac.Client(
                url=self.url,
                token=self.token,
                namespace=self.namespace,
                verify=self.verify,
            )

            # Authenticate with AppRole if provided
            if self.role_id and self.secret_id:
                client.auth.approle.login(
                    role_id=self.role_id,
                    secret_id=self.secret_id,
                )
            elif not self.token:
                raise ConfigurationError(
                    "VaultSource requires either 'token' or 'role_id' + 'secret_id'",
                    suggestion="Provide authentication credentials or set VAULT_TOKEN",
                )

            # Check if authenticated
            if not client.is_authenticated():
                raise ConfigurationError(
                    "Failed to authenticate with Vault",
                    suggestion="Check your credentials and Vault server status",
                )

            # Read secret from KV v2
            # Path format for KV v2: {mount_point}/data/{path}
            if not self.path:
                raise ConfigurationError("Vault path is required")

            # Try KV v2 first (most common)
            try:
                response = client.secrets.kv.v2.read_secret_version(
                    path=self.path,
                    mount_point=self.mount_point,
                )
                data = response["data"]["data"]
            except (hvac.exceptions.InvalidPath, KeyError):
                # Fall back to KV v1
                try:
                    response = client.secrets.kv.v1.read_secret(
                        path=self.path,
                        mount_point=self.mount_point,
                    )
                    data = response["data"]
                except Exception as e:
                    raise ConfigurationError(
                        f"Failed to read secret from Vault: {self.path}",
                        field="path",
                        suggestion="Check that the secret exists and you have read permissions",
                    ) from e

            return dict(data)

        except hvac.exceptions.VaultError as e:
            raise ConfigurationError(
                f"Vault error: {e}",
                suggestion="Check Vault server status and credentials",
            ) from e
        except Exception as e:
            raise ConfigurationError(
                f"Failed to connect to Vault: {e}",
                suggestion="Check Vault URL and network connectivity",
            ) from e


def is_vault_available() -> bool:
    """Check if hvac package is installed.

    Returns:
        True if hvac is available, False otherwise.
    """
    return hvac is not None
