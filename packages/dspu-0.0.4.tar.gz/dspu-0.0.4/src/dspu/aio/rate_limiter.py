"""Rate limiter implementation using token bucket algorithm.

This module provides async-safe rate limiting for controlling request rates,
API calls, or any rate-limited operations.
"""

import asyncio
import time
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from functools import wraps
from typing import Any, TypeVar

T = TypeVar("T")


class RateLimiter:
    """Async-safe rate limiter using token bucket algorithm.

    The token bucket algorithm allows bursts up to the bucket capacity while
    maintaining an average rate over time.

    Attributes:
        rate: Number of tokens added per second
        capacity: Maximum number of tokens in the bucket
        tokens: Current number of available tokens
        last_update: Timestamp of last token update
    """

    def __init__(self, rate: float, *, capacity: float | None = None) -> None:
        """Initialize rate limiter.

        Args:
            rate: Number of operations allowed per second
            capacity: Maximum burst capacity. If None, defaults to rate.
                A larger capacity allows bigger bursts.

        Example:
            >>> # Allow 10 requests per second with burst of 20
            >>> limiter = RateLimiter(rate=10.0, capacity=20.0)
            >>>
            >>> # Allow 5 requests per second, no burst
            >>> limiter = RateLimiter(rate=5.0, capacity=5.0)
        """
        if rate <= 0:
            msg = "Rate must be positive"
            raise ValueError(msg)

        self.rate = rate
        self.capacity = capacity if capacity is not None else rate
        self.tokens = self.capacity
        self.last_update = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self, tokens: float = 1.0) -> None:
        """Acquire tokens, waiting if necessary.

        This method blocks until the requested number of tokens becomes available.

        Args:
            tokens: Number of tokens to acquire (default: 1.0)

        Raises:
            ValueError: If tokens is negative or exceeds capacity
        """
        if tokens <= 0:
            msg = "Tokens must be positive"
            raise ValueError(msg)

        if tokens > self.capacity:
            msg = f"Requested {tokens} tokens exceeds capacity {self.capacity}"
            raise ValueError(msg)

        async with self._lock:
            while True:
                now = time.monotonic()
                elapsed = now - self.last_update

                # Add tokens based on elapsed time
                self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
                self.last_update = now

                if self.tokens >= tokens:
                    # We have enough tokens
                    self.tokens -= tokens
                    return

                # Calculate how long to wait for enough tokens
                tokens_needed = tokens - self.tokens
                wait_time = tokens_needed / self.rate

                # Release lock while waiting
                await asyncio.sleep(wait_time)

    async def try_acquire(self, tokens: float = 1.0) -> bool:
        """Try to acquire tokens without waiting.

        Args:
            tokens: Number of tokens to acquire (default: 1.0)

        Returns:
            True if tokens were acquired, False otherwise

        Raises:
            ValueError: If tokens is negative or exceeds capacity
        """
        if tokens <= 0:
            msg = "Tokens must be positive"
            raise ValueError(msg)

        if tokens > self.capacity:
            msg = f"Requested {tokens} tokens exceeds capacity {self.capacity}"
            raise ValueError(msg)

        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update

            # Add tokens based on elapsed time
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            self.last_update = now

            if self.tokens >= tokens:
                self.tokens -= tokens
                return True

            return False

    @asynccontextmanager
    async def limit(self, tokens: float = 1.0) -> AsyncGenerator[None, None]:
        """Context manager for rate-limited operations.

        Args:
            tokens: Number of tokens to acquire (default: 1.0)

        Example:
            >>> limiter = RateLimiter(rate=10.0)
            >>> async with limiter.limit():
            >>>     await make_api_call()
        """
        await self.acquire(tokens)
        try:
            yield
        finally:
            pass

    async def reset(self) -> None:
        """Reset the rate limiter to full capacity."""
        async with self._lock:
            self.tokens = self.capacity
            self.last_update = time.monotonic()

    async def get_available_tokens(self) -> float:
        """Get the current number of available tokens.

        Returns:
            Number of tokens currently available
        """
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            return min(self.capacity, self.tokens + elapsed * self.rate)


def rate_limit(
    limiter: RateLimiter,
    *,
    tokens: float = 1.0,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """Decorator to rate limit async functions.

    Args:
        limiter: The RateLimiter instance to use
        tokens: Number of tokens to acquire per call (default: 1.0)

    Returns:
        Decorated function with rate limiting

    Example:
        >>> limiter = RateLimiter(rate=10.0)
        >>>
        >>> @rate_limit(limiter)
        >>> async def fetch_data():
        >>>     return await api.get("/data")
        >>>
        >>> # Different cost for expensive operations
        >>> @rate_limit(limiter, tokens=5.0)
        >>> async def expensive_operation():
        >>>     return await heavy_computation()
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            await limiter.acquire(tokens)
            return await func(*args, **kwargs)

        return wrapper

    return decorator
