"""Concurrency utilities for async operations.

This module provides utilities for managing concurrent async operations,
including limited concurrency and timeout management.
"""

import asyncio
import functools
from collections.abc import Awaitable, Callable, Iterable
from concurrent.futures import Executor
from typing import Any, TypeVar, cast

from dspu.core.exceptions import DSPUError

T = TypeVar("T")


class AsyncTimeoutError(DSPUError):
    """Exception raised when an async operation times out."""

    def __init__(self, message: str, *, timeout: float) -> None:
        """Initialize timeout error.

        Args:
            message: Error message
            timeout: The timeout value that was exceeded
        """
        super().__init__(message)
        self.timeout = timeout


async def gather_with_limit(
    *awaitables: Awaitable[T],
    limit: int,
    return_exceptions: bool = False,
) -> list[T]:
    """Gather awaitables with concurrency limit.

    Similar to asyncio.gather() but limits the number of concurrent operations.
    This is useful for rate limiting or resource management.

    Args:
        *awaitables: Awaitable objects to execute
        limit: Maximum number of concurrent operations
        return_exceptions: If True, exceptions are returned as results instead
            of being raised (default: False)

    Returns:
        List of results in the same order as input awaitables

    Raises:
        ValueError: If limit is not positive
        Exception: If any awaitable raises and return_exceptions is False

    Example:
        >>> tasks = [fetch_url(url) for url in urls]
        >>> results = await gather_with_limit(*tasks, limit=10)
        >>>
        >>> # With exception handling
        >>> results = await gather_with_limit(
        >>>     *tasks,
        >>>     limit=5,
        >>>     return_exceptions=True
        >>> )
    """
    if limit <= 0:
        msg = "Limit must be positive"
        raise ValueError(msg)

    if not awaitables:
        return []

    # Semaphore to limit concurrency
    semaphore = asyncio.Semaphore(limit)

    async def limited_awaitable(awaitable: Awaitable[T]) -> T:
        """Wrap awaitable with semaphore."""
        async with semaphore:
            return await awaitable

    # Wrap all awaitables with semaphore
    limited = [limited_awaitable(aw) for aw in awaitables]

    # Gather all with exception handling
    return cast(list[T], await asyncio.gather(*limited, return_exceptions=return_exceptions))


async def gather_with_limit_from_iter(
    awaitables: Iterable[Awaitable[T]],
    *,
    limit: int,
    return_exceptions: bool = False,
) -> list[T]:
    """Gather awaitables from iterable with concurrency limit.

    This variant accepts an iterable instead of *args, which can be more
    convenient when working with generated or filtered awaitables.

    Args:
        awaitables: Iterable of awaitable objects to execute
        limit: Maximum number of concurrent operations
        return_exceptions: If True, exceptions are returned as results

    Returns:
        List of results in the same order as input awaitables

    Example:
        >>> urls = get_urls()
        >>> tasks = (fetch_url(url) for url in urls if url.startswith("https"))
        >>> results = await gather_with_limit_from_iter(tasks, limit=10)
    """
    awaitable_list = list(awaitables)
    return await gather_with_limit(
        *awaitable_list,
        limit=limit,
        return_exceptions=return_exceptions,
    )


async def run_with_timeout(
    awaitable: Awaitable[T],
    *,
    timeout: float,
) -> T:
    """Run an awaitable with a timeout.

    Args:
        awaitable: The awaitable to execute
        timeout: Timeout in seconds

    Returns:
        Result of the awaitable

    Raises:
        AsyncTimeoutError: If operation exceeds timeout
        Exception: If awaitable raises an exception

    Example:
        >>> result = await run_with_timeout(slow_operation(), timeout=5.0)
    """
    try:
        return await asyncio.wait_for(awaitable, timeout=timeout)
    except TimeoutError as e:
        msg = f"Operation timed out after {timeout} seconds"
        raise AsyncTimeoutError(msg, timeout=timeout) from e


async def run_with_timeout_or_default(
    awaitable: Awaitable[T],
    *,
    timeout: float,
    default: T,
) -> T:
    """Run an awaitable with timeout, returning default on timeout.

    Args:
        awaitable: The awaitable to execute
        timeout: Timeout in seconds
        default: Default value to return on timeout

    Returns:
        Result of awaitable, or default if timeout occurs

    Example:
        >>> result = await run_with_timeout_or_default(
        >>>     fetch_data(),
        >>>     timeout=5.0,
        >>>     default={}
        >>> )
    """
    try:
        return await asyncio.wait_for(awaitable, timeout=timeout)
    except TimeoutError:
        return default


async def run_with_shield(awaitable: Awaitable[T]) -> T:
    """Shield an awaitable from cancellation.

    The awaitable will continue running even if the caller is cancelled.
    However, the awaitable can still be cancelled directly.

    Args:
        awaitable: The awaitable to shield

    Returns:
        Result of the awaitable

    Example:
        >>> # Critical operation that should complete
        >>> result = await run_with_shield(commit_transaction())
    """
    return await asyncio.shield(awaitable)


async def run_in_executor(
    func: Callable[..., T],
    *args: Any,
    executor: Executor | None = None,
    **kwargs: Any,
) -> T:
    """Run a sync function in an executor.

    This allows CPU-bound or blocking I/O operations to run without
    blocking the event loop.

    Args:
        func: The sync function to run
        *args: Positional arguments for func
        executor: Optional executor (ThreadPoolExecutor or ProcessPoolExecutor).
            If None, uses the default thread pool executor.
        **kwargs: Keyword arguments for func

    Returns:
        Result of the function

    Example:
        >>> # Run CPU-bound work without blocking event loop
        >>> result = await run_in_executor(expensive_computation, data)
        >>>
        >>> # Run blocking I/O
        >>> content = await run_in_executor(read_large_file, filepath)
    """
    loop = asyncio.get_running_loop()

    # If kwargs are provided, wrap with functools.partial
    if kwargs:
        func = functools.partial(func, **kwargs)

    return await loop.run_in_executor(executor, func, *args)


class Timeout:
    """Context manager for operations with timeout.

    Example:
        >>> async with Timeout(5.0):
        >>>     await slow_operation()
    """

    def __init__(self, seconds: float) -> None:
        """Initialize timeout context.

        Args:
            seconds: Timeout in seconds
        """
        self.seconds = seconds
        self._task: asyncio.Task[Any] | None = None

    async def __aenter__(self) -> "Timeout":
        """Enter timeout context."""
        loop = asyncio.get_running_loop()
        self._task = asyncio.current_task(loop)
        loop.call_later(self.seconds, self._timeout_callback)
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit timeout context."""

    def _timeout_callback(self) -> None:
        """Cancel task on timeout."""
        if self._task is not None and not self._task.done():
            self._task.cancel()
