"""Async utilities for dspu.

This module provides comprehensive async utilities including:
- Retry decorators with multiple backoff strategies
- Rate limiting with token bucket algorithm
- Circuit breaker for fault tolerance
- Concurrency management and timeout utilities
- Sync/async bridge utilities

Example:
    >>> from dspu.aio import retry, RateLimiter, CircuitBreaker
    >>>
    >>> @retry(max_attempts=5)
    >>> async def fetch_data():
    >>>     return await api.get("/data")
    >>>
    >>> limiter = RateLimiter(rate=10.0)
    >>> async with limiter.limit():
    >>>     await make_api_call()
"""

from dspu.aio.bridge import (
    AsyncContextManager,
    async_to_sync,
    ensure_coroutine,
    iter_over_async,
    run_async,
    sync_to_async,
)
from dspu.aio.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerError,
    CircuitState,
    circuit_breaker,
)
from dspu.aio.concurrency import (
    AsyncTimeoutError,
    Timeout,
    gather_with_limit,
    gather_with_limit_from_iter,
    run_in_executor,
    run_with_shield,
    run_with_timeout,
    run_with_timeout_or_default,
)
from dspu.aio.rate_limiter import RateLimiter, rate_limit
from dspu.aio.retry import (
    BackoffStrategy,
    RetryError,
    calculate_backoff_delay,
    retry,
    retry_async,
)

__all__ = [
    "AsyncContextManager",
    "AsyncTimeoutError",
    "BackoffStrategy",
    "CircuitBreaker",
    "CircuitBreakerError",
    "CircuitState",
    "RateLimiter",
    "RetryError",
    "Timeout",
    "async_to_sync",
    "calculate_backoff_delay",
    "circuit_breaker",
    "ensure_coroutine",
    "gather_with_limit",
    "gather_with_limit_from_iter",
    "iter_over_async",
    "rate_limit",
    "retry",
    "retry_async",
    "run_async",
    "run_in_executor",
    "run_with_shield",
    "run_with_timeout",
    "run_with_timeout_or_default",
    "sync_to_async",
]
