"""Retry decorators and utilities for async operations.

This module provides flexible retry mechanisms with various backoff strategies,
exception filtering, and timeout support.
"""

import asyncio
import random
from collections.abc import Awaitable, Callable
from enum import Enum
from functools import wraps
from typing import Any, TypeVar

from dspu.core.exceptions import DSPUError

T = TypeVar("T")


class BackoffStrategy(str, Enum):
    """Backoff strategy for retry delays."""

    EXPONENTIAL = "exponential"
    LINEAR = "linear"
    CONSTANT = "constant"


class RetryError(DSPUError):
    """Exception raised when all retry attempts are exhausted."""

    def __init__(
        self,
        message: str,
        *,
        attempts: int,
        last_exception: Exception | None = None,
    ) -> None:
        """Initialize retry error.

        Args:
            message: Error message
            attempts: Number of attempts made
            last_exception: The last exception that was raised
        """
        super().__init__(message)
        self.attempts = attempts
        self.last_exception = last_exception


def calculate_backoff_delay(
    attempt: int,
    *,
    strategy: BackoffStrategy = BackoffStrategy.EXPONENTIAL,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    multiplier: float = 2.0,
    jitter: bool = True,
) -> float:
    """Calculate delay for retry attempt based on backoff strategy.

    Args:
        attempt: The attempt number (0-indexed)
        strategy: The backoff strategy to use
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        multiplier: Multiplier for exponential/linear backoff
        jitter: Whether to add random jitter to the delay

    Returns:
        Delay in seconds
    """
    if strategy == BackoffStrategy.EXPONENTIAL:
        delay = base_delay * (multiplier**attempt)
    elif strategy == BackoffStrategy.LINEAR:
        delay = base_delay + (multiplier * attempt)
    else:  # CONSTANT
        delay = base_delay

    # Cap at max_delay
    delay = min(delay, max_delay)

    # Add jitter if requested (±25% random variation)
    if jitter and delay > 0:
        jitter_amount = delay * 0.25
        delay = delay + random.uniform(-jitter_amount, jitter_amount)  # noqa: S311
        delay = max(0.0, delay)  # Ensure non-negative

    return delay


def retry(
    *,
    max_attempts: int = 3,
    strategy: BackoffStrategy = BackoffStrategy.EXPONENTIAL,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    multiplier: float = 2.0,
    jitter: bool = True,
    exceptions: tuple[type[Exception], ...] = (Exception,),
    on_retry: Callable[[int, Exception], Awaitable[None]] | None = None,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """Decorator to retry async functions with configurable backoff strategies.

    Args:
        max_attempts: Maximum number of attempts (default: 3)
        strategy: Backoff strategy to use (default: EXPONENTIAL)
        base_delay: Base delay in seconds (default: 1.0)
        max_delay: Maximum delay in seconds (default: 60.0)
        multiplier: Multiplier for exponential/linear backoff (default: 2.0)
        jitter: Whether to add random jitter (default: True)
        exceptions: Tuple of exception types to retry on (default: (Exception,))
        on_retry: Optional async callback function called on each retry.
            Receives attempt number and exception as arguments.

    Returns:
        Decorated function with retry logic

    Example:
        >>> @retry(max_attempts=5, strategy=BackoffStrategy.EXPONENTIAL)
        >>> async def fetch_data():
        >>>     # May fail transiently
        >>>     return await api.get("/data")

        >>> @retry(
        >>>     max_attempts=3,
        >>>     strategy=BackoffStrategy.LINEAR,
        >>>     exceptions=(ConnectionError, TimeoutError)
        >>> )
        >>> async def connect_to_service():
        >>>     return await service.connect()
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            last_exception: Exception | None = None

            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e

                    # If this was the last attempt, don't retry
                    if attempt == max_attempts - 1:
                        break

                    # Call retry callback if provided
                    if on_retry is not None:
                        await on_retry(attempt + 1, e)

                    # Calculate and apply backoff delay
                    delay = calculate_backoff_delay(
                        attempt,
                        strategy=strategy,
                        base_delay=base_delay,
                        max_delay=max_delay,
                        multiplier=multiplier,
                        jitter=jitter,
                    )

                    if delay > 0:
                        await asyncio.sleep(delay)

            # All attempts exhausted
            msg = f"Failed after {max_attempts} attempts"
            raise RetryError(
                msg,
                attempts=max_attempts,
                last_exception=last_exception,
            ) from last_exception

        return wrapper

    return decorator


async def retry_async(
    func: Callable[..., Awaitable[T]],
    *args: Any,
    max_attempts: int = 3,
    strategy: BackoffStrategy = BackoffStrategy.EXPONENTIAL,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    multiplier: float = 2.0,
    jitter: bool = True,
    exceptions: tuple[type[Exception], ...] = (Exception,),
    on_retry: Callable[[int, Exception], Awaitable[None]] | None = None,
    **kwargs: Any,
) -> T:
    """Programmatically retry an async function call.

    This is a functional alternative to the @retry decorator, useful when
    you need to retry a function call dynamically.

    Args:
        func: The async function to retry
        *args: Positional arguments for func
        max_attempts: Maximum number of attempts (default: 3)
        strategy: Backoff strategy to use (default: EXPONENTIAL)
        base_delay: Base delay in seconds (default: 1.0)
        max_delay: Maximum delay in seconds (default: 60.0)
        multiplier: Multiplier for exponential/linear backoff (default: 2.0)
        jitter: Whether to add random jitter (default: True)
        exceptions: Tuple of exception types to retry on (default: (Exception,))
        on_retry: Optional async callback called on each retry
        **kwargs: Keyword arguments for func

    Returns:
        Result of the function call

    Example:
        >>> result = await retry_async(
        >>>     fetch_data,
        >>>     url="https://api.example.com",
        >>>     max_attempts=5,
        >>>     strategy=BackoffStrategy.EXPONENTIAL
        >>> )
    """
    last_exception: Exception | None = None

    for attempt in range(max_attempts):
        try:
            return await func(*args, **kwargs)
        except exceptions as e:
            last_exception = e

            if attempt == max_attempts - 1:
                break

            if on_retry is not None:
                await on_retry(attempt + 1, e)

            delay = calculate_backoff_delay(
                attempt,
                strategy=strategy,
                base_delay=base_delay,
                max_delay=max_delay,
                multiplier=multiplier,
                jitter=jitter,
            )

            if delay > 0:
                await asyncio.sleep(delay)

    msg = f"Failed after {max_attempts} attempts"
    raise RetryError(
        msg,
        attempts=max_attempts,
        last_exception=last_exception,
    ) from last_exception
