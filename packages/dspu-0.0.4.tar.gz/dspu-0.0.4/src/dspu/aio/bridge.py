"""Sync/async bridge utilities.

This module provides utilities for bridging between synchronous and
asynchronous code, allowing them to interoperate seamlessly.
"""

import asyncio
import functools
from collections.abc import Awaitable, Callable, Iterator
from concurrent.futures import ThreadPoolExecutor
from typing import Any, TypeVar, cast

T = TypeVar("T")


def run_async(
    coro: Awaitable[T],
    *,
    loop: asyncio.AbstractEventLoop | None = None,
) -> T:
    """Run an async coroutine from synchronous code.

    Args:
        coro: The coroutine to run
        loop: Optional event loop. If None, creates a new one.

    Returns:
        Result of the coroutine

    Example:
        >>> async def fetch_data():
        >>>     return await api.get("/data")
        >>>
        >>> # Call from sync code
        >>> result = run_async(fetch_data())
    """
    if loop is None:
        # Try to get running loop
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop, create new one
            return asyncio.run(coro)  # type: ignore[arg-type]

    # We have a running loop, use run_until_complete
    return loop.run_until_complete(coro)


def sync_to_async(
    func: Callable[..., T],
    *,
    executor: ThreadPoolExecutor | None = None,
) -> Callable[..., Awaitable[T]]:
    """Convert a sync function to async.

    The sync function will run in a thread pool executor to avoid
    blocking the event loop.

    Args:
        func: The sync function to convert
        executor: Optional executor. If None, uses default thread pool.

    Returns:
        Async version of the function

    Example:
        >>> def blocking_operation(data):
        >>>     # CPU-intensive or blocking I/O
        >>>     return process(data)
        >>>
        >>> async_operation = sync_to_async(blocking_operation)
        >>> result = await async_operation(data)
    """

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> T:
        loop = asyncio.get_running_loop()
        partial_func = functools.partial(func, *args, **kwargs)
        return await loop.run_in_executor(executor, partial_func)

    return wrapper


def async_to_sync(func: Callable[..., Awaitable[T]]) -> Callable[..., T]:
    """Convert an async function to sync.

    Args:
        func: The async function to convert

    Returns:
        Sync version of the function

    Warning:
        This should not be called from async code as it will create
        a new event loop. Use await instead.

    Example:
        >>> async def fetch_data(url):
        >>>     return await http_client.get(url)
        >>>
        >>> sync_fetch = async_to_sync(fetch_data)
        >>> result = sync_fetch("https://api.example.com/data")
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> T:
        coro = func(*args, **kwargs)
        return run_async(coro)

    return wrapper


def iter_over_async(
    async_iterable: Any,
    *,
    loop: asyncio.AbstractEventLoop | None = None,
) -> Iterator[T]:
    """Convert an async iterable to a sync iterator.

    Args:
        async_iterable: The async iterable to convert
        loop: Optional event loop. If None, creates new one.

    Yields:
        Items from the async iterable

    Example:
        >>> async def async_generator():
        >>>     for i in range(10):
        >>>         await asyncio.sleep(0.1)
        >>>         yield i
        >>>
        >>> # Use from sync code
        >>> for item in iter_over_async(async_generator()):
        >>>     print(item)
    """
    if loop is None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        close_loop = True
    else:
        close_loop = False

    try:
        async_iter = async_iterable.__aiter__()

        while True:
            try:
                item = loop.run_until_complete(async_iter.__anext__())
                yield item
            except StopAsyncIteration:
                break

    finally:
        if close_loop:
            loop.close()


class AsyncContextManager:
    """Helper for using async context managers in sync code.

    Example:
        >>> async_cm = some_async_context_manager()
        >>> with AsyncContextManager(async_cm) as value:
        >>>     # Use value
        >>>     pass
    """

    def __init__(
        self,
        async_cm: Any,
        *,
        loop: asyncio.AbstractEventLoop | None = None,
    ) -> None:
        """Initialize async context manager wrapper.

        Args:
            async_cm: The async context manager
            loop: Optional event loop
        """
        self.async_cm = async_cm
        self.loop = loop

    def __enter__(self) -> Any:
        """Enter context."""
        if self.loop is None:
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self._close_loop = True
        else:
            self._close_loop = False

        return self.loop.run_until_complete(self.async_cm.__aenter__())

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context."""
        try:
            if self.loop is not None:
                self.loop.run_until_complete(self.async_cm.__aexit__(exc_type, exc_val, exc_tb))
        finally:
            if self._close_loop and self.loop is not None:
                self.loop.close()


def ensure_coroutine(
    func_or_coro: Any,
) -> Callable[..., Awaitable[Any]]:
    """Ensure a function or coroutine is a coroutine function.

    If the input is already a coroutine function, returns it unchanged.
    If it's a regular function, wraps it to return a coroutine.

    Args:
        func_or_coro: Function or coroutine function

    Returns:
        Coroutine function

    Example:
        >>> def sync_func(x):
        >>>     return x * 2
        >>>
        >>> async_func = ensure_coroutine(sync_func)
        >>> result = await async_func(5)  # Works!
    """
    if asyncio.iscoroutinefunction(func_or_coro):
        return cast(Callable[..., Awaitable[Any]], func_or_coro)

    @functools.wraps(func_or_coro)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Run sync function in executor
        loop = asyncio.get_running_loop()
        partial_func = functools.partial(func_or_coro, *args, **kwargs)
        return await loop.run_in_executor(None, partial_func)

    return wrapper
