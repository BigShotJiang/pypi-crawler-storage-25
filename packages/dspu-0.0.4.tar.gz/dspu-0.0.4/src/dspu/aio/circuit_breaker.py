"""Circuit breaker pattern implementation for async operations.

This module provides circuit breaker functionality to prevent cascading failures
and allow systems to recover from transient errors.
"""

import asyncio
import time
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from enum import Enum
from functools import wraps
from typing import Any, TypeVar

from dspu.core.exceptions import DSPUError

T = TypeVar("T")


class CircuitState(str, Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Normal operation, requests allowed
    OPEN = "open"  # Failure threshold exceeded, requests blocked
    HALF_OPEN = "half_open"  # Testing if service recovered


class CircuitBreakerError(DSPUError):
    """Exception raised when circuit breaker is open."""

    def __init__(
        self,
        message: str,
        *,
        state: CircuitState,
        failure_count: int,
    ) -> None:
        """Initialize circuit breaker error.

        Args:
            message: Error message
            state: Current circuit breaker state
            failure_count: Number of consecutive failures
        """
        super().__init__(message)
        self.state = state
        self.failure_count = failure_count


class CircuitBreaker:
    """Async-safe circuit breaker for fault tolerance.

    The circuit breaker prevents cascading failures by:
    - CLOSED: Normal operation, counting failures
    - OPEN: After threshold failures, blocking requests for timeout period
    - HALF_OPEN: After timeout, allowing test requests to check recovery

    Attributes:
        failure_threshold: Number of failures before opening circuit
        success_threshold: Number of successes in half-open to close circuit
        timeout: Seconds to wait before transitioning to half-open
        state: Current circuit state
        failure_count: Consecutive failures in closed state
        success_count: Consecutive successes in half-open state
        last_failure_time: Timestamp of last failure
    """

    def __init__(
        self,
        *,
        failure_threshold: int = 5,
        success_threshold: int = 2,
        timeout: float = 60.0,
        exceptions: tuple[type[Exception], ...] = (Exception,),
        on_state_change: Callable[[CircuitState, CircuitState], Awaitable[None]] | None = None,
    ) -> None:
        """Initialize circuit breaker.

        Args:
            failure_threshold: Failures before opening circuit (default: 5)
            success_threshold: Successes needed to close circuit (default: 2)
            timeout: Seconds to wait in open state (default: 60.0)
            exceptions: Tuple of exceptions to count as failures
            on_state_change: Optional async callback for state changes.
                Receives (old_state, new_state) as arguments.

        Example:
            >>> # Basic circuit breaker
            >>> cb = CircuitBreaker(failure_threshold=3, timeout=30.0)
            >>>
            >>> # With custom exception handling
            >>> cb = CircuitBreaker(
            >>>     failure_threshold=5,
            >>>     exceptions=(ConnectionError, TimeoutError)
            >>> )
        """
        if failure_threshold <= 0:
            msg = "Failure threshold must be positive"
            raise ValueError(msg)

        if success_threshold <= 0:
            msg = "Success threshold must be positive"
            raise ValueError(msg)

        if timeout <= 0:
            msg = "Timeout must be positive"
            raise ValueError(msg)

        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.timeout = timeout
        self.exceptions = exceptions
        self.on_state_change = on_state_change

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: float | None = None
        self._lock = asyncio.Lock()

    @property
    def state(self) -> CircuitState:
        """Get current circuit state."""
        return self._state

    @property
    def failure_count(self) -> int:
        """Get current failure count."""
        return self._failure_count

    @property
    def success_count(self) -> int:
        """Get current success count."""
        return self._success_count

    async def _transition_to(self, new_state: CircuitState) -> None:
        """Transition to a new state.

        Args:
            new_state: The state to transition to
        """
        old_state = self._state
        if old_state == new_state:
            return

        self._state = new_state

        # Reset counters based on new state
        if new_state == CircuitState.CLOSED:
            self._failure_count = 0
            self._success_count = 0
        elif new_state == CircuitState.HALF_OPEN:
            self._success_count = 0

        # Call state change callback
        if self.on_state_change is not None:
            await self.on_state_change(old_state, new_state)

    async def _check_state(self) -> None:
        """Check and update state based on current conditions."""
        # Check if timeout has elapsed and transition to half-open
        if (
            self._state == CircuitState.OPEN
            and self._last_failure_time is not None
            and time.monotonic() - self._last_failure_time >= self.timeout
        ):
            await self._transition_to(CircuitState.HALF_OPEN)

    async def call(
        self,
        func: Callable[..., Awaitable[T]],
        *args: Any,
        **kwargs: Any,
    ) -> T:
        """Call a function through the circuit breaker.

        Args:
            func: The async function to call
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Result of the function call

        Raises:
            CircuitBreakerError: If circuit is open
            Exception: If function raises an exception
        """
        async with self._lock:
            await self._check_state()

            # Block requests if circuit is open
            if self._state == CircuitState.OPEN:
                msg = f"Circuit breaker is open (failures: {self._failure_count})"
                raise CircuitBreakerError(
                    msg,
                    state=self._state,
                    failure_count=self._failure_count,
                )

        # Try to execute the function
        try:
            result = await func(*args, **kwargs)

            # Success - update state
            async with self._lock:
                if self._state == CircuitState.HALF_OPEN:
                    self._success_count += 1
                    if self._success_count >= self.success_threshold:
                        await self._transition_to(CircuitState.CLOSED)
                elif self._state == CircuitState.CLOSED:
                    # Reset failure count on success
                    self._failure_count = 0

            return result

        except self.exceptions as e:
            # Failure - update state
            async with self._lock:
                self._last_failure_time = time.monotonic()

                if self._state == CircuitState.HALF_OPEN:
                    # Failed test request - back to open
                    await self._transition_to(CircuitState.OPEN)
                elif self._state == CircuitState.CLOSED:
                    self._failure_count += 1
                    if self._failure_count >= self.failure_threshold:
                        await self._transition_to(CircuitState.OPEN)

            raise e

    @asynccontextmanager
    async def protect(self) -> AsyncGenerator[None, None]:
        """Context manager for circuit breaker protection.

        Example:
            >>> cb = CircuitBreaker()
            >>> async with cb.protect():
            >>>     await make_api_call()
        """
        async with self._lock:
            await self._check_state()

            if self._state == CircuitState.OPEN:
                msg = f"Circuit breaker is open (failures: {self._failure_count})"
                raise CircuitBreakerError(
                    msg,
                    state=self._state,
                    failure_count=self._failure_count,
                )

        try:
            yield

            # Success
            async with self._lock:
                if self._state == CircuitState.HALF_OPEN:
                    self._success_count += 1
                    if self._success_count >= self.success_threshold:
                        await self._transition_to(CircuitState.CLOSED)
                elif self._state == CircuitState.CLOSED:
                    self._failure_count = 0

        except self.exceptions as e:
            # Failure
            async with self._lock:
                self._last_failure_time = time.monotonic()

                if self._state == CircuitState.HALF_OPEN:
                    await self._transition_to(CircuitState.OPEN)
                elif self._state == CircuitState.CLOSED:
                    self._failure_count += 1
                    if self._failure_count >= self.failure_threshold:
                        await self._transition_to(CircuitState.OPEN)

            raise e

    async def reset(self) -> None:
        """Manually reset the circuit breaker to closed state."""
        async with self._lock:
            await self._transition_to(CircuitState.CLOSED)
            self._last_failure_time = None


def circuit_breaker(
    breaker: CircuitBreaker,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """Decorator to protect async functions with circuit breaker.

    Args:
        breaker: The CircuitBreaker instance to use

    Returns:
        Decorated function with circuit breaker protection

    Example:
        >>> cb = CircuitBreaker(failure_threshold=5, timeout=60.0)
        >>>
        >>> @circuit_breaker(cb)
        >>> async def call_external_service():
        >>>     return await service.call()
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            return await breaker.call(func, *args, **kwargs)

        return wrapper

    return decorator
