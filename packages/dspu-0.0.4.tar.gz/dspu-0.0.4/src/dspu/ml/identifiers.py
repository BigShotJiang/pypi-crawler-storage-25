"""ID generation utilities for ML workflows.

This module provides utilities for generating various types of identifiers:
- UUID v4 (random) and v1 (time-based)
- ULID (lexicographically sortable, timestamp-based)
- Hash-based IDs (deterministic from data)
- Row ID generation for tables and dataframes

Example:
    >>> from dspu.ml import IDGenerator
    >>>
    >>> # Generate UUIDs
    >>> uuid = IDGenerator.uuid4()
    >>> ulid = IDGenerator.ulid()
    >>>
    >>> # Hash-based IDs
    >>> id = IDGenerator.hash_text("hello world")
    >>>
    >>> # Add IDs to table
    >>> table = [{"name": "Alice"}, {"name": "Bob"}]
    >>> IDGenerator.add_id_column(table, id_col="id")
"""

import hashlib
import time
import uuid
from typing import Any, Literal

from ..core.exceptions import DSPUError


class IDError(DSPUError):
    """Raised when ID generation fails."""


class IDGenerator:
    """Utilities for generating and working with identifiers.

    Supports multiple ID formats:
    - UUID v4: Random, globally unique
    - UUID v1: Time-based, globally unique
    - ULID: Time-based, lexicographically sortable
    - Hash-based: Deterministic from input data

    Example:
        >>> id1 = IDGenerator.uuid4()
        >>> id2 = IDGenerator.ulid()
        >>> id3 = IDGenerator.hash_text("data")
    """

    @staticmethod
    def uuid4() -> str:
        """Generate random UUID v4.

        UUID v4 is randomly generated and has extremely low collision probability.

        Returns:
            UUID v4 as string (e.g., "550e8400-e29b-41d4-a716-446655440000")

        Example:
            >>> id = IDGenerator.uuid4()
            >>> len(id)
            36
        """
        return str(uuid.uuid4())

    @staticmethod
    def uuid1() -> str:
        """Generate time-based UUID v1.

        UUID v1 includes timestamp and MAC address. Useful when you need
        time-ordered IDs but not necessarily sortable.

        Returns:
            UUID v1 as string

        Example:
            >>> id = IDGenerator.uuid1()
            >>> len(id)
            36
        """
        return str(uuid.uuid1())

    @staticmethod
    def ulid() -> str:
        """Generate ULID (Universally Unique Lexicographically Sortable Identifier).

        ULIDs are:
        - 26 characters (vs 36 for UUID)
        - Lexicographically sortable by creation time
        - Case-insensitive (base32 encoded)
        - Timestamp + randomness

        Returns:
            ULID as string (e.g., "01ARZ3NDEKTSV4RRFFQ69G5FAV")

        Example:
            >>> id1 = IDGenerator.ulid()
            >>> time.sleep(0.001)
            >>> id2 = IDGenerator.ulid()
            >>> id1 < id2  # Sortable by time
            True
        """
        # ULID format: 10 bytes timestamp + 16 bytes randomness
        # Encoded as 26 character base32 string

        # Timestamp (48 bits = 10 chars in base32)
        timestamp_ms = int(time.time() * 1000)

        # Randomness (80 bits = 16 chars in base32)
        import random

        randomness = random.getrandbits(80)

        # Encode to base32 (Crockford's base32)
        # Using custom alphabet that excludes ambiguous characters (I, L, O, U)
        alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

        # Encode timestamp (10 chars)
        ulid_str = ""
        ts = timestamp_ms
        for _ in range(10):
            ulid_str = alphabet[ts & 0x1F] + ulid_str
            ts >>= 5

        # Encode randomness (16 chars)
        rand = randomness
        rand_str = ""
        for _ in range(16):
            rand_str = alphabet[rand & 0x1F] + rand_str
            rand >>= 5

        return ulid_str + rand_str

    @staticmethod
    def hash_text(
        text: str,
        algo: Literal["md5", "sha1", "sha256", "sha512"] = "sha256",
        length: int | None = None,
    ) -> str:
        """Generate hash-based ID from text.

        Creates deterministic ID by hashing the input text.
        Useful for deduplication or creating stable IDs from content.

        Args:
            text: Input text to hash
            algo: Hash algorithm - "md5", "sha1", "sha256", "sha512"
            length: Optional truncation length (in characters)

        Returns:
            Hex-encoded hash string

        Raises:
            IDError: If algorithm is invalid

        Example:
            >>> id1 = IDGenerator.hash_text("hello")
            >>> id2 = IDGenerator.hash_text("hello")
            >>> id1 == id2  # Same input = same ID
            True
        """
        valid_algos = {"md5", "sha1", "sha256", "sha512"}
        if algo not in valid_algos:
            raise IDError(f"Invalid algorithm: {algo}. Use one of {valid_algos}")

        if algo == "md5":
            h = hashlib.md5(text.encode("utf-8"))
        elif algo == "sha1":
            h = hashlib.sha1(text.encode("utf-8"))
        elif algo == "sha256":
            h = hashlib.sha256(text.encode("utf-8"))
        else:  # sha512
            h = hashlib.sha512(text.encode("utf-8"))

        digest = h.hexdigest()

        if length is not None:
            return digest[:length]

        return digest

    @staticmethod
    def hash_row(
        row: dict[str, Any],
        columns: list[str] | None = None,
        algo: Literal["md5", "sha1", "sha256", "sha512"] = "sha256",
        length: int | None = None,
    ) -> str:
        """Generate stable hash-based ID for a row.

        Creates deterministic ID by hashing selected column values.
        Useful for composite keys or content-based deduplication.

        Args:
            row: Dictionary representing a row
            columns: Columns to include in hash (None = all columns, sorted)
            algo: Hash algorithm
            length: Optional truncation length

        Returns:
            Hex-encoded hash string

        Example:
            >>> row = {"name": "Alice", "age": 30}
            >>> id = IDGenerator.hash_row(row, columns=["name"])
        """
        if columns is None:
            columns = sorted(row.keys())

        # Create stable string representation
        parts: list[str] = []
        for col in columns:
            value = row.get(col)
            if value is None:
                parts.append("")
            else:
                parts.append(str(value))

        text = "|".join(parts)
        return IDGenerator.hash_text(text, algo=algo, length=length)

    @staticmethod
    def add_id_column(
        table: list[dict[str, Any]],
        id_col: str = "_id",
        method: Literal["uuid4", "uuid1", "ulid", "hash", "sequential"] = "uuid4",
        hash_columns: list[str] | None = None,
        start: int = 1,
    ) -> list[dict[str, Any]]:
        """Add ID column to a table (list of dicts).

        Modifies the table in-place by adding an ID column to each row.

        Args:
            table: List of dictionaries (rows)
            id_col: Name of ID column to add
            method: ID generation method - "uuid4", "uuid1", "ulid", "hash", "sequential"
            hash_columns: Columns to use for hash-based IDs (for method="hash")
            start: Starting value for sequential IDs

        Returns:
            Modified table (same object, modified in-place)

        Raises:
            IDError: If method is invalid or hash_columns not provided for hash method

        Example:
            >>> table = [{"name": "Alice"}, {"name": "Bob"}]
            >>> IDGenerator.add_id_column(table, id_col="id", method="uuid4")
            >>> "id" in table[0]
            True
        """
        valid_methods = {"uuid4", "uuid1", "ulid", "hash", "sequential"}
        if method not in valid_methods:
            raise IDError(f"Invalid method: {method}. Use one of {valid_methods}")

        if method == "hash" and hash_columns is None:
            raise IDError("hash_columns must be provided for method='hash'")

        for i, row in enumerate(table):
            if method == "uuid4":
                row[id_col] = IDGenerator.uuid4()
            elif method == "uuid1":
                row[id_col] = IDGenerator.uuid1()
            elif method == "ulid":
                row[id_col] = IDGenerator.ulid()
            elif method == "hash":
                row[id_col] = IDGenerator.hash_row(row, columns=hash_columns)
            elif method == "sequential":
                row[id_col] = start + i

        return table
