"""Feature scaling utilities for ML workflows.

This module provides stateful feature scaling with fit/transform pattern:
- Standard scaling (mean=0, std=1)
- Min-max scaling (to [0, 1] or custom range)
- Robust scaling (median, IQR)
- State serialization for production deployment

Example:
    >>> from dspu.ml import Scaler
    >>>
    >>> # Fit scaler on training data
    >>> scaler = Scaler(method="standard")
    >>> X_train = [[1.0], [2.0], [3.0]]
    >>> X_train_scaled = scaler.fit_transform(X_train)
    >>>
    >>> # Transform test data with same parameters
    >>> X_test = [[1.5], [2.5]]
    >>> X_test_scaled = scaler.transform(X_test)
    >>>
    >>> # Save/load state for production
    >>> state = scaler.save_state()
    >>> new_scaler = Scaler.from_state(state)
"""

import json
from typing import Any, Literal

from ..core.exceptions import DSPUError


class ScalingError(DSPUError):
    """Raised when feature scaling fails."""


class Scaler:
    """Feature scaling with fit/transform pattern.

    Supports multiple scaling methods:
    - standard: (x - mean) / std
    - minmax: (x - min) / (max - min)
    - robust: (x - median) / IQR

    Example:
        >>> scaler = Scaler(method="standard")
        >>> X = [[1.0, 2.0], [2.0, 4.0], [3.0, 6.0]]
        >>> X_scaled = scaler.fit_transform(X)
    """

    def __init__(
        self,
        method: Literal["standard", "minmax", "robust"] = "standard",
        feature_range: tuple[float, float] = (0.0, 1.0),
    ):
        """Initialize scaler.

        Args:
            method: Scaling method - "standard", "minmax", or "robust"
            feature_range: Target range for minmax scaling (default: (0, 1))

        Raises:
            ScalingError: If method is invalid
        """
        valid_methods = {"standard", "minmax", "robust"}
        if method not in valid_methods:
            raise ScalingError(f"Invalid method: {method}. Use one of {valid_methods}")

        self.method = method
        self.feature_range = feature_range
        self._is_fitted = False

        # Statistics will be stored per feature
        self._means: list[float] | None = None
        self._stds: list[float] | None = None
        self._mins: list[float] | None = None
        self._maxs: list[float] | None = None
        self._medians: list[float] | None = None
        self._iqrs: list[float] | None = None
        self._n_features: int | None = None

    def fit(self, X: list[list[float]]) -> "Scaler":
        """Fit scaler to data by computing statistics.

        Args:
            X: Training data (list of samples, each sample is list of features)

        Returns:
            self (for method chaining)

        Raises:
            ScalingError: If data is empty or invalid

        Example:
            >>> scaler = Scaler(method="standard")
            >>> X = [[1.0, 2.0], [2.0, 4.0]]
            >>> scaler.fit(X)
        """
        if not X:
            raise ScalingError("Cannot fit on empty data")

        n_samples = len(X)
        n_features = len(X[0])

        if any(len(row) != n_features for row in X):
            raise ScalingError("All samples must have same number of features")

        self._n_features = n_features

        if self.method == "standard":
            # Compute mean and std for each feature
            self._means = []
            self._stds = []

            for feat_idx in range(n_features):
                values = [row[feat_idx] for row in X]
                mean = sum(values) / n_samples

                variance = sum((x - mean) ** 2 for x in values) / n_samples
                std = variance**0.5

                # Avoid division by zero
                if std == 0:
                    std = 1.0

                self._means.append(mean)
                self._stds.append(std)

        elif self.method == "minmax":
            # Compute min and max for each feature
            self._mins = []
            self._maxs = []

            for feat_idx in range(n_features):
                values = [row[feat_idx] for row in X]
                min_val = min(values)
                max_val = max(values)

                # Avoid division by zero
                if max_val == min_val:
                    max_val = min_val + 1.0

                self._mins.append(min_val)
                self._maxs.append(max_val)

        elif self.method == "robust":
            # Compute median and IQR for each feature
            self._medians = []
            self._iqrs = []

            for feat_idx in range(n_features):
                values = sorted([row[feat_idx] for row in X])
                n = len(values)

                # Median
                if n % 2 == 0:
                    median = (values[n // 2 - 1] + values[n // 2]) / 2
                else:
                    median = values[n // 2]

                # IQR (Q3 - Q1)
                q1_idx = n // 4
                q3_idx = 3 * n // 4
                q1 = values[q1_idx]
                q3 = values[q3_idx]
                iqr = q3 - q1

                # Avoid division by zero
                if iqr == 0:
                    iqr = 1.0

                self._medians.append(median)
                self._iqrs.append(iqr)

        self._is_fitted = True
        return self

    def transform(self, X: list[list[float]]) -> list[list[float]]:
        """Transform data using fitted parameters.

        Args:
            X: Data to transform

        Returns:
            Scaled data

        Raises:
            ScalingError: If scaler not fitted or data shape mismatch

        Example:
            >>> scaler = Scaler(method="standard")
            >>> X_train = [[1.0], [2.0], [3.0]]
            >>> scaler.fit(X_train)
            >>> X_test = [[1.5]]
            >>> X_test_scaled = scaler.transform(X_test)
        """
        if not self._is_fitted:
            raise ScalingError("Scaler not fitted. Call fit() first.")

        # Type narrowing: after fit(), these attributes are guaranteed to be set
        assert self._n_features is not None
        if self.method == "standard":
            assert self._means is not None and self._stds is not None
        elif self.method == "minmax":
            assert self._mins is not None and self._maxs is not None
        elif self.method == "robust":
            assert self._medians is not None and self._iqrs is not None

        if not X:
            return []

        n_features = len(X[0])
        if n_features != self._n_features:
            raise ScalingError(f"Expected {self._n_features} features, got {n_features}")

        X_scaled = []

        for row in X:
            if len(row) != self._n_features:
                raise ScalingError(f"All samples must have {self._n_features} features")

            scaled_row = []

            for feat_idx, value in enumerate(row):
                if self.method == "standard":
                    assert self._means is not None and self._stds is not None
                    scaled_value = (value - self._means[feat_idx]) / self._stds[feat_idx]

                elif self.method == "minmax":
                    assert self._mins is not None and self._maxs is not None
                    # Scale to [0, 1]
                    min_val = self._mins[feat_idx]
                    max_val = self._maxs[feat_idx]
                    scaled_01 = (value - min_val) / (max_val - min_val)

                    # Scale to feature_range
                    range_min, range_max = self.feature_range
                    scaled_value = scaled_01 * (range_max - range_min) + range_min

                elif self.method == "robust":
                    assert self._medians is not None and self._iqrs is not None
                    scaled_value = (value - self._medians[feat_idx]) / self._iqrs[feat_idx]

                else:
                    raise ScalingError(f"Unknown method: {self.method}")  # Should never happen

                scaled_row.append(scaled_value)

            X_scaled.append(scaled_row)

        return X_scaled

    def fit_transform(self, X: list[list[float]]) -> list[list[float]]:
        """Fit scaler and transform data in one step.

        Args:
            X: Training data

        Returns:
            Scaled data

        Example:
            >>> scaler = Scaler(method="standard")
            >>> X = [[1.0], [2.0], [3.0]]
            >>> X_scaled = scaler.fit_transform(X)
        """
        self.fit(X)
        return self.transform(X)

    def inverse_transform(self, X_scaled: list[list[float]]) -> list[list[float]]:
        """Reverse scaling transformation.

        Args:
            X_scaled: Scaled data

        Returns:
            Original-scale data

        Raises:
            ScalingError: If scaler not fitted or inverse not supported

        Example:
            >>> scaler = Scaler(method="standard")
            >>> X = [[1.0], [2.0], [3.0]]
            >>> X_scaled = scaler.fit_transform(X)
            >>> X_recovered = scaler.inverse_transform(X_scaled)
        """
        if not self._is_fitted:
            raise ScalingError("Scaler not fitted. Call fit() first.")

        # Type narrowing: after fit(), these attributes are guaranteed to be set
        assert self._n_features is not None
        if self.method == "standard":
            assert self._means is not None and self._stds is not None
        elif self.method == "minmax":
            assert self._mins is not None and self._maxs is not None
        elif self.method == "robust":
            assert self._medians is not None and self._iqrs is not None

        if not X_scaled:
            return []

        X_original = []

        for row in X_scaled:
            if len(row) != self._n_features:
                raise ScalingError(f"All samples must have {self._n_features} features")

            original_row = []

            for feat_idx, scaled_value in enumerate(row):
                if self.method == "standard":
                    assert self._means is not None and self._stds is not None
                    original_value = scaled_value * self._stds[feat_idx] + self._means[feat_idx]

                elif self.method == "minmax":
                    assert self._mins is not None and self._maxs is not None
                    # Reverse feature_range scaling
                    range_min, range_max = self.feature_range
                    scaled_01 = (scaled_value - range_min) / (range_max - range_min)

                    # Reverse [0, 1] scaling
                    min_val = self._mins[feat_idx]
                    max_val = self._maxs[feat_idx]
                    original_value = scaled_01 * (max_val - min_val) + min_val

                elif self.method == "robust":
                    assert self._medians is not None and self._iqrs is not None
                    original_value = scaled_value * self._iqrs[feat_idx] + self._medians[feat_idx]

                else:
                    raise ScalingError(f"Unknown method: {self.method}")  # Should never happen

                original_row.append(original_value)

            X_original.append(original_row)

        return X_original

    def save_state(self) -> dict[str, Any]:
        """Save scaler state for serialization.

        Returns:
            Dictionary containing scaler configuration and statistics

        Raises:
            ScalingError: If scaler not fitted

        Example:
            >>> scaler = Scaler(method="standard")
            >>> scaler.fit([[1.0], [2.0]])
            >>> state = scaler.save_state()
            >>> # Save to file: json.dump(state, f)
        """
        if not self._is_fitted:
            raise ScalingError("Cannot save state of unfitted scaler")

        state: dict[str, Any] = {
            "method": self.method,
            "feature_range": self.feature_range,
            "n_features": self._n_features,
        }

        if self.method == "standard":
            state["means"] = self._means
            state["stds"] = self._stds
        elif self.method == "minmax":
            state["mins"] = self._mins
            state["maxs"] = self._maxs
        elif self.method == "robust":
            state["medians"] = self._medians
            state["iqrs"] = self._iqrs

        return state

    @classmethod
    def from_state(cls, state: dict[str, Any]) -> "Scaler":
        """Load scaler from saved state.

        Args:
            state: Dictionary from save_state()

        Returns:
            Configured scaler

        Example:
            >>> state = {"method": "standard", "means": [0.0], ...}
            >>> scaler = Scaler.from_state(state)
        """
        method = state["method"]
        feature_range_data = state["feature_range"]
        feature_range = (float(feature_range_data[0]), float(feature_range_data[1]))

        scaler = cls(method=method, feature_range=feature_range)
        scaler._n_features = state["n_features"]

        if method == "standard":
            scaler._means = state["means"]
            scaler._stds = state["stds"]
        elif method == "minmax":
            scaler._mins = state["mins"]
            scaler._maxs = state["maxs"]
        elif method == "robust":
            scaler._medians = state["medians"]
            scaler._iqrs = state["iqrs"]

        scaler._is_fitted = True
        return scaler

    def save_to_file(self, filepath: str) -> None:
        """Save scaler state to JSON file.

        Args:
            filepath: Path to output file

        Example:
            >>> scaler.save_to_file("scaler.json")
        """
        state = self.save_state()
        with open(filepath, "w") as f:
            json.dump(state, f, indent=2)

    @classmethod
    def load_from_file(cls, filepath: str) -> "Scaler":
        """Load scaler from JSON file.

        Args:
            filepath: Path to state file

        Returns:
            Configured scaler

        Example:
            >>> scaler = Scaler.load_from_file("scaler.json")
        """
        with open(filepath) as f:
            state = json.load(f)
        return cls.from_state(state)
