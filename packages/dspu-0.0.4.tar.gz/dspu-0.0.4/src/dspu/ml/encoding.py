"""Categorical encoding utilities for ML workflows.

This module provides stateful categorical encoding with fit/transform pattern:
- Label encoding (categories → integers)
- One-hot encoding (categories → binary vectors)
- Ordinal encoding (categories → ordered integers)
- Frequency encoding (categories → occurrence frequency)
- State serialization for production deployment

Example:
    >>> from dspu.ml import Encoder
    >>>
    >>> # Label encoding
    >>> encoder = Encoder(method="label")
    >>> categories = ["cat", "dog", "cat", "bird"]
    >>> encoded = encoder.fit_transform(categories)
    >>> # [0, 1, 0, 2]
    >>>
    >>> # One-hot encoding
    >>> encoder = Encoder(method="onehot")
    >>> encoded = encoder.fit_transform(categories)
    >>> # [[1, 0, 0], [0, 1, 0], [1, 0, 0], [0, 0, 1]]
"""

import json
from collections import Counter
from typing import Any, Literal

from ..core.exceptions import DSPUError


class EncodingError(DSPUError):
    """Raised when categorical encoding fails."""


class Encoder:
    """Categorical encoding with fit/transform pattern.

    Supports multiple encoding methods:
    - label: Categories → integers (0, 1, 2, ...)
    - onehot: Categories → binary vectors ([1,0,0], [0,1,0], ...)
    - ordinal: Categories → ordered integers (custom order)
    - frequency: Categories → occurrence frequency

    Example:
        >>> encoder = Encoder(method="label")
        >>> categories = ["A", "B", "A", "C"]
        >>> encoded = encoder.fit_transform(categories)
    """

    def __init__(
        self,
        method: Literal["label", "onehot", "ordinal", "frequency"] = "label",
        categories: list[str] | None = None,
        handle_unknown: Literal["error", "use_default", "ignore"] = "error",
        unknown_value: int | list[int] | None = None,
    ):
        """Initialize encoder.

        Args:
            method: Encoding method
            categories: Pre-defined category order (for ordinal encoding)
            handle_unknown: How to handle unknown categories:
                - "error": Raise error (default)
                - "use_default": Use unknown_value
                - "ignore": Skip/remove unknown values
            unknown_value: Value for unknown categories (for handle_unknown="use_default")

        Raises:
            EncodingError: If method is invalid
        """
        valid_methods = {"label", "onehot", "ordinal", "frequency"}
        if method not in valid_methods:
            raise EncodingError(f"Invalid method: {method}. Use one of {valid_methods}")

        valid_unknown_strategies = {"error", "use_default", "ignore"}
        if handle_unknown not in valid_unknown_strategies:
            raise EncodingError(
                f"Invalid handle_unknown: {handle_unknown}. Use one of {valid_unknown_strategies}"
            )

        self.method = method
        self.handle_unknown = handle_unknown
        self.unknown_value = unknown_value
        self._is_fitted = False

        # Attribute declarations
        self._categories: list[str] | None
        self._category_to_int: dict[str, int] | None
        self._category_frequencies: dict[str, float] | None = None

        # For ordinal encoding, use provided category order
        if method == "ordinal":
            if categories is None:
                raise EncodingError("Must provide categories for ordinal encoding")
            self._categories = categories
            self._category_to_int = {cat: i for i, cat in enumerate(categories)}
        else:
            self._categories = categories
            self._category_to_int = None

    def fit(self, categories: list[str]) -> "Encoder":
        """Fit encoder by learning category mappings.

        Args:
            categories: Training categories

        Returns:
            self (for method chaining)

        Raises:
            EncodingError: If data is invalid

        Example:
            >>> encoder = Encoder(method="label")
            >>> encoder.fit(["A", "B", "A", "C"])
        """
        if not categories:
            raise EncodingError("Cannot fit on empty data")

        if self.method == "ordinal":
            # Categories already set in __init__
            pass
        elif self.method in {"label", "onehot"}:
            # Learn unique categories (sorted for consistency)
            unique_cats = sorted(set(categories))
            self._categories = unique_cats
            self._category_to_int = {cat: i for i, cat in enumerate(unique_cats)}
        elif self.method == "frequency":
            # Compute frequency of each category
            counts = Counter(categories)
            total = len(categories)
            self._category_frequencies = {cat: count / total for cat, count in counts.items()}
            self._categories = list(counts.keys())

        self._is_fitted = True
        return self

    def transform(self, categories: list[str]) -> list[Any]:
        """Transform categories using fitted encoding.

        Args:
            categories: Categories to encode

        Returns:
            Encoded values (type depends on encoding method)

        Raises:
            EncodingError: If encoder not fitted or unknown category encountered

        Example:
            >>> encoder = Encoder(method="label")
            >>> encoder.fit(["A", "B", "C"])
            >>> encoder.transform(["A", "C", "B"])
            [0, 2, 1]
        """
        if not self._is_fitted:
            raise EncodingError("Encoder not fitted. Call fit() first.")

        if not categories:
            return []

        encoded = []

        for cat in categories:
            if self.method == "label":
                encoded_val = self._encode_label(cat)
                if encoded_val is not None:
                    encoded.append(encoded_val)

            elif self.method == "onehot":
                encoded_val = self._encode_onehot(cat)
                if encoded_val is not None:
                    encoded.append(encoded_val)

            elif self.method == "ordinal":
                encoded_val = self._encode_ordinal(cat)
                if encoded_val is not None:
                    encoded.append(encoded_val)

            elif self.method == "frequency":
                encoded_val = self._encode_frequency(cat)
                if encoded_val is not None:
                    encoded.append(encoded_val)

        return encoded

    def _encode_label(self, category: str) -> int | None:
        """Encode single category as integer."""
        assert self._category_to_int is not None  # Guaranteed after fit()
        if category in self._category_to_int:
            return self._category_to_int[category]
        return self._handle_unknown_category(category, default=self.unknown_value or -1)

    def _encode_onehot(self, category: str) -> list[int] | None:
        """Encode single category as one-hot vector."""
        assert (
            self._categories is not None and self._category_to_int is not None
        )  # Guaranteed after fit()
        n_categories = len(self._categories)

        if category in self._category_to_int:
            idx = self._category_to_int[category]
            vector = [0] * n_categories
            vector[idx] = 1
            return vector
        default = self.unknown_value or [0] * n_categories
        return self._handle_unknown_category(category, default=default)

    def _encode_ordinal(self, category: str) -> int | None:
        """Encode single category as ordinal integer."""
        assert self._category_to_int is not None  # Guaranteed after fit()
        if category in self._category_to_int:
            return self._category_to_int[category]
        return self._handle_unknown_category(category, default=self.unknown_value or -1)

    def _encode_frequency(self, category: str) -> float | None:
        """Encode single category as frequency."""
        if self._category_frequencies is not None and category in self._category_frequencies:
            return self._category_frequencies[category]
        return self._handle_unknown_category(category, default=self.unknown_value or 0.0)

    def _handle_unknown_category(self, category: str, default: Any) -> Any | None:
        """Handle unknown category based on strategy."""
        if self.handle_unknown == "error":
            raise EncodingError(
                f"Unknown category: {category}. Known categories: {self._categories}"
            )
        if self.handle_unknown == "use_default":
            return default
        if self.handle_unknown == "ignore":
            return None  # Will be filtered out
        raise EncodingError(f"Invalid handle_unknown: {self.handle_unknown}")

    def fit_transform(self, categories: list[str]) -> list[Any]:
        """Fit encoder and transform categories in one step.

        Args:
            categories: Training categories

        Returns:
            Encoded values

        Example:
            >>> encoder = Encoder(method="label")
            >>> encoded = encoder.fit_transform(["A", "B", "A"])
        """
        self.fit(categories)
        return self.transform(categories)

    def inverse_transform(self, encoded: list[int]) -> list[str]:
        """Reverse encoding transformation.

        Args:
            encoded: Encoded integers

        Returns:
            Original categories

        Raises:
            EncodingError: If encoder not fitted or method doesn't support inverse

        Example:
            >>> encoder = Encoder(method="label")
            >>> encoder.fit(["A", "B", "C"])
            >>> encoded = [0, 2, 1]
            >>> encoder.inverse_transform(encoded)
            ['A', 'C', 'B']
        """
        if not self._is_fitted:
            raise EncodingError("Encoder not fitted. Call fit() first.")

        if self.method not in {"label", "ordinal"}:
            raise EncodingError(f"inverse_transform not supported for method={self.method}")

        # Type narrowing: after fit(), _category_to_int is guaranteed to be set
        assert self._category_to_int is not None
        # Create reverse mapping
        int_to_category = {v: k for k, v in self._category_to_int.items()}

        categories = []
        for code in encoded:
            if code in int_to_category:
                categories.append(int_to_category[code])
            else:
                raise EncodingError(f"Unknown code: {code}")

        return categories

    def get_feature_names(self, input_feature: str = "x") -> list[str]:
        """Get feature names for one-hot encoding.

        Args:
            input_feature: Name of input feature

        Returns:
            List of feature names (one per category)

        Raises:
            EncodingError: If method is not one-hot

        Example:
            >>> encoder = Encoder(method="onehot")
            >>> encoder.fit(["A", "B", "C"])
            >>> encoder.get_feature_names("category")
            ['category_A', 'category_B', 'category_C']
        """
        if self.method != "onehot":
            raise EncodingError("get_feature_names only available for method='onehot'")

        if not self._is_fitted:
            raise EncodingError("Encoder not fitted. Call fit() first.")

        assert self._categories is not None  # Guaranteed after fit()
        return [f"{input_feature}_{cat}" for cat in self._categories]

    def save_state(self) -> dict[str, Any]:
        """Save encoder state for serialization.

        Returns:
            Dictionary containing encoder configuration and mappings

        Raises:
            EncodingError: If encoder not fitted

        Example:
            >>> encoder = Encoder(method="label")
            >>> encoder.fit(["A", "B"])
            >>> state = encoder.save_state()
        """
        if not self._is_fitted:
            raise EncodingError("Cannot save state of unfitted encoder")

        state: dict[str, Any] = {
            "method": self.method,
            "handle_unknown": self.handle_unknown,
            "unknown_value": self.unknown_value,
            "categories": self._categories,
        }

        if self.method in {"label", "onehot", "ordinal"}:
            state["category_to_int"] = self._category_to_int

        if self.method == "frequency":
            state["category_frequencies"] = self._category_frequencies

        return state

    @classmethod
    def from_state(cls, state: dict[str, Any]) -> "Encoder":
        """Load encoder from saved state.

        Args:
            state: Dictionary from save_state()

        Returns:
            Configured encoder

        Example:
            >>> state = {"method": "label", "categories": ["A", "B"], ...}
            >>> encoder = Encoder.from_state(state)
        """
        method = state["method"]
        handle_unknown = state["handle_unknown"]
        unknown_value = state["unknown_value"]

        if method == "ordinal":
            encoder = cls(
                method=method,
                categories=state["categories"],
                handle_unknown=handle_unknown,
                unknown_value=unknown_value,
            )
        else:
            encoder = cls(
                method=method,
                handle_unknown=handle_unknown,
                unknown_value=unknown_value,
            )
            encoder._categories = state["categories"]

        if method in {"label", "onehot", "ordinal"}:
            encoder._category_to_int = state["category_to_int"]

        if method == "frequency":
            encoder._category_frequencies = state["category_frequencies"]

        encoder._is_fitted = True
        return encoder

    def save_to_file(self, filepath: str) -> None:
        """Save encoder state to JSON file.

        Args:
            filepath: Path to output file

        Example:
            >>> encoder.save_to_file("encoder.json")
        """
        state = self.save_state()
        with open(filepath, "w") as f:
            json.dump(state, f, indent=2)

    @classmethod
    def load_from_file(cls, filepath: str) -> "Encoder":
        """Load encoder from JSON file.

        Args:
            filepath: Path to state file

        Returns:
            Configured encoder

        Example:
            >>> encoder = Encoder.load_from_file("encoder.json")
        """
        with open(filepath) as f:
            state = json.load(f)
        return cls.from_state(state)
