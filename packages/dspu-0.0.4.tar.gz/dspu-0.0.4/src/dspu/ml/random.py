"""Random utilities and reproducibility tools.

This module provides utilities for:
- Unified seed management across Python, NumPy, PyTorch, TensorFlow
- Synthetic data generation for testing and demos
- Reproducible random number generation

Example:
    >>> from dspu.ml import SeedManager, make_classification_data
    >>>
    >>> # Set global seed for reproducibility
    >>> SeedManager.set_global_seed(42)
    >>>
    >>> # Generate synthetic data
    >>> X, y = make_classification_data(n_samples=100, n_features=5)
    >>>
    >>> # Use seed context for temporary seeding
    >>> with SeedManager.seed_context(123):
    ...     data = make_regression_data(n_samples=50)
"""

import random
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

from ..core.exceptions import DSPUError


class RandomError(DSPUError):
    """Raised when random number generation fails."""


class SeedManager:
    """Unified seed management for reproducibility.

    Manages random seeds across multiple libraries (Python random, NumPy,
    PyTorch, TensorFlow) to ensure reproducible results.

    Example:
        >>> SeedManager.set_global_seed(42)
        >>> # Now all random operations are seeded
        >>>
        >>> with SeedManager.seed_context(123):
        ...     # Temporary seed for this block
        ...     pass
    """

    _current_seed: int | None = None

    @classmethod
    def set_global_seed(cls, seed: int) -> None:
        """Set seed for all available random number generators.

        Seeds the following libraries if available:
        - Python's random module
        - NumPy
        - PyTorch (CPU and CUDA)
        - TensorFlow

        Args:
            seed: Random seed value (non-negative integer)

        Raises:
            RandomError: If seed is negative

        Example:
            >>> SeedManager.set_global_seed(42)
            >>> import random
            >>> random.random()  # Will be deterministic
        """
        if seed < 0:
            raise RandomError(f"Seed must be non-negative, got {seed}")

        cls._current_seed = seed

        # Python random
        random.seed(seed)

        # NumPy
        try:
            import numpy as np

            np.random.seed(seed)
        except ImportError:
            pass

        # PyTorch
        try:
            import torch

            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
            # Make PyTorch deterministic (may impact performance)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        except ImportError:
            pass

        # TensorFlow
        try:
            import tensorflow as tf

            tf.random.set_seed(seed)
        except ImportError:
            pass

    @classmethod
    @contextmanager
    def seed_context(cls, seed: int) -> Generator[None, None, None]:
        """Context manager for temporary seeding.

        Sets a seed for the duration of the context, then restores
        the previous seed state.

        Args:
            seed: Temporary seed value

        Yields:
            None

        Example:
            >>> SeedManager.set_global_seed(42)
            >>> with SeedManager.seed_context(123):
            ...     # Operations here use seed 123
            ...     data = random.random()
            >>> # Back to seed 42
        """
        # Save current state
        old_seed = cls._current_seed
        old_python_state = random.getstate()

        old_numpy_state = None
        try:
            import numpy as np

            old_numpy_state = np.random.get_state()
        except ImportError:
            pass

        # Set new seed
        cls.set_global_seed(seed)

        try:
            yield
        finally:
            # Restore old state
            random.setstate(old_python_state)

            if old_numpy_state is not None:
                try:
                    import numpy as np

                    np.random.set_state(old_numpy_state)
                except ImportError:
                    pass

            cls._current_seed = old_seed

    @classmethod
    def get_rng(cls, seed: int | None = None, backend: str = "python") -> Any:
        """Get a random number generator instance.

        Args:
            seed: Optional seed for the RNG. If None, uses current global seed.
            backend: RNG backend - "python" or "numpy"

        Returns:
            Random number generator instance

        Raises:
            RandomError: If backend is invalid or not available

        Example:
            >>> rng = SeedManager.get_rng(seed=42, backend="python")
            >>> rng.random()
        """
        if seed is None:
            seed = cls._current_seed

        if backend == "python":
            rng = random.Random(seed)
            return rng
        if backend == "numpy":
            try:
                import numpy as np

                if seed is not None:
                    return np.random.default_rng(seed)
                return np.random.default_rng()
            except ImportError:
                raise RandomError("NumPy not available, cannot create numpy RNG")
        else:
            raise RandomError(f"Unknown backend: {backend}. Use 'python' or 'numpy'")

    @classmethod
    def get_current_seed(cls) -> int | None:
        """Get the current global seed value.

        Returns:
            Current seed or None if not set
        """
        return cls._current_seed


def make_classification_data(
    n_samples: int = 100,
    n_features: int = 5,
    n_classes: int = 2,
    n_informative: int | None = None,
    noise: float = 0.1,
    random_state: int | None = None,
) -> tuple[list[list[float]], list[int]]:
    """Generate synthetic classification dataset.

    Creates a simple classification dataset with optional noise.
    Features are drawn from normal distribution, with informative
    features correlating with class labels.

    Args:
        n_samples: Number of samples to generate
        n_features: Number of features
        n_classes: Number of classes
        n_informative: Number of informative features (default: n_features // 2)
        noise: Standard deviation of Gaussian noise added to features
        random_state: Random seed for reproducibility

    Returns:
        Tuple of (X, y) where X is features and y is labels

    Example:
        >>> X, y = make_classification_data(n_samples=100, n_features=5)
        >>> len(X), len(y)
        (100, 100)
    """
    if n_informative is None:
        n_informative = max(1, n_features // 2)

    if n_informative > n_features:
        raise RandomError("n_informative cannot exceed n_features")

    rng = random.Random(random_state)

    X = []
    y = []

    for _ in range(n_samples):
        # Assign class
        class_label = rng.randint(0, n_classes - 1)

        # Generate features
        features = []
        for j in range(n_features):
            if j < n_informative:
                # Informative features correlate with class
                value = rng.gauss(class_label, 1.0) + rng.gauss(0, noise)
            else:
                # Non-informative features are pure noise
                value = rng.gauss(0, 1.0)
            features.append(value)

        X.append(features)
        y.append(class_label)

    return X, y


def make_regression_data(
    n_samples: int = 100,
    n_features: int = 5,
    n_informative: int | None = None,
    noise: float = 0.1,
    random_state: int | None = None,
) -> tuple[list[list[float]], list[float]]:
    """Generate synthetic regression dataset.

    Creates a simple regression dataset with linear relationship
    between informative features and target, plus Gaussian noise.

    Args:
        n_samples: Number of samples to generate
        n_features: Number of features
        n_informative: Number of informative features (default: n_features // 2)
        noise: Standard deviation of Gaussian noise added to target
        random_state: Random seed for reproducibility

    Returns:
        Tuple of (X, y) where X is features and y is continuous targets

    Example:
        >>> X, y = make_regression_data(n_samples=100, n_features=5)
        >>> len(X), len(y)
        (100, 100)
    """
    if n_informative is None:
        n_informative = max(1, n_features // 2)

    if n_informative > n_features:
        raise RandomError("n_informative cannot exceed n_features")

    rng = random.Random(random_state)

    # Generate random weights for informative features
    weights = [rng.gauss(0, 1) for _ in range(n_informative)]

    X = []
    y = []

    for _ in range(n_samples):
        # Generate features
        features = [rng.gauss(0, 1) for _ in range(n_features)]

        # Compute target as linear combination of informative features + noise
        target = sum(w * features[i] for i, w in enumerate(weights))
        target += rng.gauss(0, noise)

        X.append(features)
        y.append(target)

    return X, y


def make_time_series(
    length: int = 100,
    pattern: str = "trend+seasonality",
    trend_slope: float = 0.1,
    seasonality_period: int = 12,
    seasonality_amplitude: float = 1.0,
    noise: float = 0.1,
    random_state: int | None = None,
) -> list[float]:
    """Generate synthetic time series data.

    Creates time series with configurable patterns:
    - trend: Linear trend
    - seasonality: Sinusoidal seasonality
    - trend+seasonality: Both components
    - random: Pure random walk

    Args:
        length: Number of time steps
        pattern: Pattern type - "trend", "seasonality", "trend+seasonality", "random"
        trend_slope: Slope of linear trend
        seasonality_period: Period of seasonal component
        seasonality_amplitude: Amplitude of seasonal component
        noise: Standard deviation of Gaussian noise
        random_state: Random seed for reproducibility

    Returns:
        List of time series values

    Raises:
        RandomError: If pattern is invalid

    Example:
        >>> ts = make_time_series(length=100, pattern="trend+seasonality")
        >>> len(ts)
        100
    """
    import math

    valid_patterns = {"trend", "seasonality", "trend+seasonality", "random"}
    if pattern not in valid_patterns:
        raise RandomError(f"Invalid pattern: {pattern}. Use one of {valid_patterns}")

    rng = random.Random(random_state)

    series = []

    for t in range(length):
        value = 0.0

        if pattern in {"trend", "trend+seasonality"}:
            value += trend_slope * t

        if pattern in {"seasonality", "trend+seasonality"}:
            value += seasonality_amplitude * math.sin(2 * math.pi * t / seasonality_period)

        if pattern == "random":
            # Random walk
            value = series[-1] + rng.gauss(0, 1) if series else 0

        # Add noise
        value += rng.gauss(0, noise)

        series.append(value)

    return series
