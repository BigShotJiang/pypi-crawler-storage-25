"""Data splitting utilities for ML workflows.

This module provides train/test splitting strategies:
- Train/validation/test splits with stratification
- K-fold cross-validation
- Stratified K-fold for imbalanced data
- Time-series splits for temporal data
- Group splits to prevent data leakage

Example:
    >>> from dspu.ml import DataSplitter
    >>>
    >>> X = [[1, 2], [3, 4], [5, 6], [7, 8]]
    >>> y = [0, 1, 0, 1]
    >>>
    >>> # Train/test split
    >>> result = DataSplitter.train_test_split(X, y, test_size=0.25)
    >>> X_train, X_test, y_train, y_test = result
    >>>
    >>> # K-fold split
    >>> for train_idx, val_idx in DataSplitter.kfold_split(X, n_splits=3):
    ...     X_train = [X[i] for i in train_idx]
"""

import random
from collections import defaultdict
from typing import Any

from ..core.exceptions import DSPUError


class SplitError(DSPUError):
    """Raised when data splitting fails."""


class DataSplitter:
    """Data splitting strategies for ML workflows.

    Provides various train/test splitting methods with proper
    stratification and group handling to prevent data leakage.

    Example:
        >>> X = [[1], [2], [3], [4]]
        >>> y = [0, 1, 0, 1]
        >>> X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
        ...     X, y, test_size=0.25
        ... )
    """

    @staticmethod
    def train_test_split(
        X: list[Any],
        y: list[Any] | None = None,
        test_size: float = 0.25,
        stratify: list[Any] | None = None,
        random_state: int | None = None,
    ) -> tuple[list[Any], list[Any], list[Any] | None, list[Any] | None]:
        """Split data into train and test sets.

        Args:
            X: Input data (list of samples)
            y: Target labels (optional)
            test_size: Fraction of data for test set (0 to 1)
            stratify: If provided, perform stratified split to maintain class distribution
            random_state: Random seed for reproducibility

        Returns:
            Tuple of (X_train, X_test, y_train, y_test)
            If y is None, returns (X_train, X_test, None, None)

        Raises:
            SplitError: If test_size is invalid or data sizes don't match

        Example:
            >>> X = [[1], [2], [3], [4]]
            >>> y = [0, 1, 0, 1]
            >>> X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
            ...     X, y, test_size=0.25, random_state=42
            ... )
        """
        if not 0 < test_size < 1:
            raise SplitError(f"test_size must be between 0 and 1, got {test_size}")

        n_samples = len(X)

        if y is not None and len(y) != n_samples:
            raise SplitError(f"X and y have different lengths: {n_samples} vs {len(y)}")

        if stratify is not None and len(stratify) != n_samples:
            raise SplitError(
                f"X and stratify have different lengths: {n_samples} vs {len(stratify)}"
            )

        n_test = max(1, int(n_samples * test_size))
        n_train = n_samples - n_test

        rng = random.Random(random_state)

        if stratify is not None:
            # Stratified split - maintain class distribution
            indices_by_class = defaultdict(list)
            for idx, label in enumerate(stratify):
                indices_by_class[label].append(idx)

            train_indices = []
            test_indices = []

            for label, indices in indices_by_class.items():
                n_class = len(indices)
                n_class_test = max(1, int(n_class * test_size))

                # Shuffle within class
                shuffled = list(indices)
                rng.shuffle(shuffled)

                test_indices.extend(shuffled[:n_class_test])
                train_indices.extend(shuffled[n_class_test:])

        else:
            # Random split
            indices = list(range(n_samples))
            rng.shuffle(indices)

            test_indices = indices[:n_test]
            train_indices = indices[n_test:]

        # Split data
        X_train = [X[i] for i in train_indices]
        X_test = [X[i] for i in test_indices]

        if y is not None:
            y_train = [y[i] for i in train_indices]
            y_test = [y[i] for i in test_indices]
            return X_train, X_test, y_train, y_test
        return X_train, X_test, None, None

    @staticmethod
    def train_val_test_split(
        X: list[Any],
        y: list[Any] | None = None,
        test_size: float = 0.2,
        val_size: float = 0.1,
        stratify: list[Any] | None = None,
        random_state: int | None = None,
    ) -> tuple[
        list[Any], list[Any], list[Any], list[Any] | None, list[Any] | None, list[Any] | None
    ]:
        """Split data into train, validation, and test sets.

        Args:
            X: Input data
            y: Target labels (optional)
            test_size: Fraction for test set
            val_size: Fraction for validation set
            stratify: If provided, perform stratified split
            random_state: Random seed

        Returns:
            Tuple of (X_train, X_val, X_test, y_train, y_val, y_test)

        Raises:
            SplitError: If sizes are invalid

        Example:
            >>> X = list(range(100))
            >>> y = [i % 2 for i in range(100)]
            >>> splits = DataSplitter.train_val_test_split(X, y, test_size=0.2, val_size=0.1)
            >>> X_train, X_val, X_test, y_train, y_val, y_test = splits
        """
        if test_size + val_size >= 1:
            raise SplitError(f"test_size + val_size must be < 1, got {test_size + val_size}")

        # First split: train+val vs test
        X_temp, X_test, y_temp, y_test = DataSplitter.train_test_split(
            X, y, test_size=test_size, stratify=stratify, random_state=random_state
        )

        # Second split: train vs val (from remaining data)
        val_size_adjusted = val_size / (1 - test_size)
        X_train, X_val, y_train, y_val = DataSplitter.train_test_split(
            X_temp,
            y_temp,
            test_size=val_size_adjusted,
            stratify=stratify,
            random_state=random_state,
        )

        return X_train, X_val, X_test, y_train, y_val, y_test

    @staticmethod
    def kfold_split(
        X: list[Any],
        n_splits: int = 5,
        shuffle: bool = True,
        random_state: int | None = None,
    ) -> list[tuple[list[int], list[int]]]:
        """K-fold cross-validation indices.

        Splits data into K consecutive folds, yielding train/validation
        indices for each fold.

        Args:
            X: Input data (only length is used)
            n_splits: Number of folds
            shuffle: Whether to shuffle data before splitting
            random_state: Random seed (only used if shuffle=True)

        Returns:
            List of (train_indices, val_indices) tuples

        Raises:
            SplitError: If n_splits is invalid

        Example:
            >>> X = list(range(10))
            >>> folds = DataSplitter.kfold_split(X, n_splits=3)
            >>> for train_idx, val_idx in folds:
            ...     print(len(train_idx), len(val_idx))
        """
        n_samples = len(X)

        if n_splits < 2:
            raise SplitError(f"n_splits must be >= 2, got {n_splits}")

        if n_splits > n_samples:
            raise SplitError(f"n_splits ({n_splits}) cannot exceed n_samples ({n_samples})")

        indices = list(range(n_samples))

        if shuffle:
            rng = random.Random(random_state)
            rng.shuffle(indices)

        fold_sizes = [n_samples // n_splits] * n_splits
        # Distribute remainder
        for i in range(n_samples % n_splits):
            fold_sizes[i] += 1

        folds = []
        current = 0
        fold_indices = []

        for size in fold_sizes:
            fold_indices.append(indices[current : current + size])
            current += size

        # Generate train/val splits
        for i in range(n_splits):
            val_indices = fold_indices[i]
            train_indices = []
            for j in range(n_splits):
                if j != i:
                    train_indices.extend(fold_indices[j])

            folds.append((train_indices, val_indices))

        return folds

    @staticmethod
    def stratified_kfold(
        y: list[Any],
        n_splits: int = 5,
        random_state: int | None = None,
    ) -> list[tuple[list[int], list[int]]]:
        """Stratified K-fold cross-validation indices.

        Like K-fold but preserves class distribution in each fold.
        Useful for imbalanced datasets.

        Args:
            y: Target labels
            n_splits: Number of folds
            random_state: Random seed

        Returns:
            List of (train_indices, val_indices) tuples

        Raises:
            SplitError: If any class has fewer samples than n_splits

        Example:
            >>> y = [0, 0, 0, 1, 1, 1]
            >>> folds = DataSplitter.stratified_kfold(y, n_splits=3)
        """
        n_samples = len(y)

        if n_splits < 2:
            raise SplitError(f"n_splits must be >= 2, got {n_splits}")

        # Group indices by class
        class_indices = defaultdict(list)
        for idx, label in enumerate(y):
            class_indices[label].append(idx)

        # Verify each class has enough samples
        for label, indices in class_indices.items():
            if len(indices) < n_splits:
                raise SplitError(
                    f"Class {label} has only {len(indices)} samples, "
                    f"need at least {n_splits} for {n_splits}-fold CV"
                )

        rng = random.Random(random_state)

        # Shuffle within each class
        for indices in class_indices.values():
            rng.shuffle(indices)

        # Distribute samples from each class across folds
        folds = [[] for _ in range(n_splits)]

        for label, indices in class_indices.items():
            for i, idx in enumerate(indices):
                fold_idx = i % n_splits
                folds[fold_idx].append(idx)

        # Generate train/val splits
        result = []
        for i in range(n_splits):
            val_indices = folds[i]
            train_indices = []
            for j in range(n_splits):
                if j != i:
                    train_indices.extend(folds[j])

            result.append((train_indices, val_indices))

        return result

    @staticmethod
    def time_series_split(
        X: list[Any],
        n_splits: int = 5,
        max_train_size: int | None = None,
    ) -> list[tuple[list[int], list[int]]]:
        """Time-series cross-validation indices.

        Sequential splits suitable for temporal data where future data
        must not leak into training. Each fold uses progressively more
        historical data.

        Args:
            X: Input data (only length is used)
            n_splits: Number of splits
            max_train_size: Maximum size of training set (None = unlimited)

        Returns:
            List of (train_indices, val_indices) tuples

        Raises:
            SplitError: If n_splits is too large

        Example:
            >>> X = list(range(20))
            >>> splits = DataSplitter.time_series_split(X, n_splits=4)
            >>> # Split 1: train [0-4], test [5-9]
            >>> # Split 2: train [0-9], test [10-14]
            >>> # Split 3: train [0-14], test [15-19]
        """
        n_samples = len(X)

        if n_splits < 2:
            raise SplitError(f"n_splits must be >= 2, got {n_splits}")

        # Each fold needs at least 1 sample for validation
        if n_splits >= n_samples:
            raise SplitError(f"n_splits ({n_splits}) must be less than n_samples ({n_samples})")

        # Calculate fold size for validation sets
        test_size = n_samples // (n_splits + 1)
        if test_size == 0:
            test_size = 1

        splits = []

        for i in range(n_splits):
            # Validation set: next chunk of data
            val_start = (i + 1) * test_size
            val_end = min(val_start + test_size, n_samples)

            if val_start >= n_samples:
                break

            # Training set: all data before validation set
            train_start = 0
            train_end = val_start

            if max_train_size is not None and (train_end - train_start) > max_train_size:
                train_start = train_end - max_train_size

            train_indices = list(range(train_start, train_end))
            val_indices = list(range(val_start, val_end))

            splits.append((train_indices, val_indices))

        return splits

    @staticmethod
    def group_split(
        X: list[Any],
        groups: list[Any],
        y: list[Any] | None = None,
        test_size: float = 0.25,
        random_state: int | None = None,
    ) -> tuple[list[Any], list[Any], list[Any] | None, list[Any] | None]:
        """Split data by groups to prevent leakage.

        Ensures that samples from the same group appear only in either
        train or test set, never both. Critical for scenarios like:
        - Patient data (keep all visits from same patient together)
        - Time series (keep all events from same entity together)
        - Hierarchical data (keep related samples together)

        Args:
            X: Input data
            groups: Group labels for each sample
            y: Target labels (optional)
            test_size: Approximate fraction for test set
            random_state: Random seed

        Returns:
            Tuple of (X_train, X_test, y_train, y_test)

        Raises:
            SplitError: If data sizes don't match

        Example:
            >>> X = [[1], [2], [3], [4], [5], [6]]
            >>> y = [0, 0, 1, 1, 0, 1]
            >>> groups = ["A", "A", "B", "B", "C", "C"]  # A, B, C are patients
            >>> X_train, X_test, y_train, y_test = DataSplitter.group_split(
            ...     X, groups, y, test_size=0.33
            ... )
            >>> # All samples from same patient stay together
        """
        n_samples = len(X)

        if len(groups) != n_samples:
            raise SplitError(f"X and groups have different lengths: {n_samples} vs {len(groups)}")

        if y is not None and len(y) != n_samples:
            raise SplitError(f"X and y have different lengths: {n_samples} vs {len(y)}")

        # Get unique groups and their indices
        group_indices = defaultdict(list)
        for idx, group in enumerate(groups):
            group_indices[group].append(idx)

        unique_groups = list(group_indices.keys())
        n_groups = len(unique_groups)

        # Split groups (not individual samples)
        rng = random.Random(random_state)
        rng.shuffle(unique_groups)

        n_test_groups = max(1, int(n_groups * test_size))
        test_groups = set(unique_groups[:n_test_groups])

        # Assign samples based on group membership
        train_indices = []
        test_indices = []

        for group, indices in group_indices.items():
            if group in test_groups:
                test_indices.extend(indices)
            else:
                train_indices.extend(indices)

        # Split data
        X_train = [X[i] for i in train_indices]
        X_test = [X[i] for i in test_indices]

        if y is not None:
            y_train = [y[i] for i in train_indices]
            y_test = [y[i] for i in test_indices]
            return X_train, X_test, y_train, y_test
        return X_train, X_test, None, None
