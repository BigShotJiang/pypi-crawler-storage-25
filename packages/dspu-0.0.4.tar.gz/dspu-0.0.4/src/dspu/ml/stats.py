"""Statistical utilities for ML workflows.

This module provides common statistical functions:
- Correlation analysis (Pearson, Spearman, Kendall)
- Basic hypothesis tests (t-test, Mann-Whitney U)
- Bootstrap utilities for confidence intervals
- A/B test uplift calculation
- Outlier detection (IQR, Z-score)

Example:
    >>> from dspu.ml import Stats
    >>>
    >>> # Correlation
    >>> x = [1, 2, 3, 4, 5]
    >>> y = [2, 4, 5, 4, 5]
    >>> corr = Stats.correlation(x, y, method="pearson")
    >>>
    >>> # Outlier detection
    >>> data = [1, 2, 3, 4, 5, 100]
    >>> outliers = Stats.detect_outliers(data, method="iqr")
"""

import math
import random
from collections.abc import Callable
from typing import Literal

from ..core.exceptions import DSPUError


class StatsError(DSPUError):
    """Raised when statistical computation fails."""


class Stats:
    """Statistical utilities for data analysis and ML.

    Provides common statistical functions without requiring scipy.
    For advanced statistical analysis, consider using scipy.stats.

    Example:
        >>> x = [1, 2, 3, 4, 5]
        >>> y = [2, 4, 5, 4, 5]
        >>> corr = Stats.correlation(x, y)
    """

    @staticmethod
    def mean(data: list[float]) -> float:
        """Calculate arithmetic mean.

        Args:
            data: List of numbers

        Returns:
            Mean value

        Raises:
            StatsError: If data is empty
        """
        if not data:
            raise StatsError("Cannot compute mean of empty data")
        return sum(data) / len(data)

    @staticmethod
    def median(data: list[float]) -> float:
        """Calculate median.

        Args:
            data: List of numbers

        Returns:
            Median value

        Raises:
            StatsError: If data is empty
        """
        if not data:
            raise StatsError("Cannot compute median of empty data")

        sorted_data = sorted(data)
        n = len(sorted_data)

        if n % 2 == 0:
            return (sorted_data[n // 2 - 1] + sorted_data[n // 2]) / 2
        return sorted_data[n // 2]

    @staticmethod
    def std(data: list[float], ddof: int = 0) -> float:
        """Calculate standard deviation.

        Args:
            data: List of numbers
            ddof: Delta degrees of freedom (0 for population, 1 for sample)

        Returns:
            Standard deviation

        Raises:
            StatsError: If data is empty or has insufficient samples
        """
        if not data:
            raise StatsError("Cannot compute std of empty data")

        if len(data) <= ddof:
            raise StatsError(f"Need more than {ddof} samples for ddof={ddof}")

        mean_val = Stats.mean(data)
        variance = sum((x - mean_val) ** 2 for x in data) / (len(data) - ddof)
        return math.sqrt(variance)

    @staticmethod
    def correlation(
        x: list[float],
        y: list[float],
        method: Literal["pearson", "spearman", "kendall"] = "pearson",
    ) -> float:
        """Calculate correlation between two variables.

        Args:
            x: First variable
            y: Second variable
            method: Correlation method - "pearson", "spearman", or "kendall"

        Returns:
            Correlation coefficient (between -1 and 1)

        Raises:
            StatsError: If lengths don't match or method is invalid

        Example:
            >>> x = [1, 2, 3, 4, 5]
            >>> y = [2, 4, 5, 4, 5]
            >>> corr = Stats.correlation(x, y, method="pearson")
        """
        if len(x) != len(y):
            raise StatsError(f"x and y must have same length: {len(x)} vs {len(y)}")

        if len(x) < 2:
            raise StatsError("Need at least 2 samples for correlation")

        if method == "pearson":
            return Stats._pearson_correlation(x, y)
        if method == "spearman":
            # Spearman = Pearson on ranks
            x_ranks = Stats._rank_data(x)
            y_ranks = Stats._rank_data(y)
            return Stats._pearson_correlation(x_ranks, y_ranks)
        if method == "kendall":
            return Stats._kendall_tau(x, y)
        raise StatsError(f"Unknown correlation method: {method}")

    @staticmethod
    def _pearson_correlation(x: list[float], y: list[float]) -> float:
        """Pearson correlation coefficient."""
        n = len(x)
        mean_x = Stats.mean(x)
        mean_y = Stats.mean(y)

        numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
        denominator_x = math.sqrt(sum((x[i] - mean_x) ** 2 for i in range(n)))
        denominator_y = math.sqrt(sum((y[i] - mean_y) ** 2 for i in range(n)))

        if denominator_x == 0 or denominator_y == 0:
            return 0.0

        return numerator / (denominator_x * denominator_y)

    @staticmethod
    def _rank_data(data: list[float]) -> list[float]:
        """Convert data to ranks (for Spearman correlation)."""
        indexed = [(val, i) for i, val in enumerate(data)]
        indexed.sort()

        ranks = [0.0] * len(data)
        i = 0
        while i < len(indexed):
            # Handle ties by assigning average rank
            j = i
            while j < len(indexed) and indexed[j][0] == indexed[i][0]:
                j += 1

            avg_rank = (i + j - 1) / 2 + 1  # +1 for 1-based ranking

            for k in range(i, j):
                ranks[indexed[k][1]] = avg_rank

            i = j

        return ranks

    @staticmethod
    def _kendall_tau(x: list[float], y: list[float]) -> float:
        """Kendall's tau correlation coefficient."""
        n = len(x)
        concordant = 0
        discordant = 0

        for i in range(n):
            for j in range(i + 1, n):
                sign_x = 1 if x[j] > x[i] else (-1 if x[j] < x[i] else 0)
                sign_y = 1 if y[j] > y[i] else (-1 if y[j] < y[i] else 0)

                if sign_x * sign_y > 0:
                    concordant += 1
                elif sign_x * sign_y < 0:
                    discordant += 1

        n_pairs = n * (n - 1) / 2
        if n_pairs == 0:
            return 0.0

        return (concordant - discordant) / n_pairs

    @staticmethod
    def t_test_independent(
        sample1: list[float],
        sample2: list[float],
        equal_var: bool = True,
    ) -> tuple[float, float]:
        """Independent two-sample t-test.

        Tests whether two samples have different means.

        Args:
            sample1: First sample
            sample2: Second sample
            equal_var: Assume equal variances (True) or not (False, Welch's t-test)

        Returns:
            Tuple of (t_statistic, p_value_approx)
            Note: p-value is approximate

        Raises:
            StatsError: If samples are too small

        Example:
            >>> sample1 = [1, 2, 3, 4, 5]
            >>> sample2 = [2, 3, 4, 5, 6]
            >>> t_stat, p_val = Stats.t_test_independent(sample1, sample2)
        """
        if len(sample1) < 2 or len(sample2) < 2:
            raise StatsError("Each sample must have at least 2 observations")

        n1, n2 = len(sample1), len(sample2)
        mean1 = Stats.mean(sample1)
        mean2 = Stats.mean(sample2)
        std1 = Stats.std(sample1, ddof=1)
        std2 = Stats.std(sample2, ddof=1)

        if equal_var:
            # Pooled standard deviation
            pooled_std = math.sqrt(((n1 - 1) * std1**2 + (n2 - 1) * std2**2) / (n1 + n2 - 2))
            t_stat = (mean1 - mean2) / (pooled_std * math.sqrt(1 / n1 + 1 / n2))
            df = n1 + n2 - 2
        else:
            # Welch's t-test
            s1 = std1**2 / n1
            s2 = std2**2 / n2
            t_stat = (mean1 - mean2) / math.sqrt(s1 + s2)

            # Welch-Satterthwaite degrees of freedom
            df = (s1 + s2) ** 2 / (s1**2 / (n1 - 1) + s2**2 / (n2 - 1))

        # Approximate p-value using normal approximation for large df
        # For small df, this is less accurate
        p_value = 2 * (1 - Stats._normal_cdf(abs(t_stat)))

        return t_stat, p_value

    @staticmethod
    def _normal_cdf(x: float) -> float:
        """Approximate standard normal CDF using error function approximation."""
        # Using approximation: CDF(x) ≈ 0.5 * (1 + erf(x / sqrt(2)))
        # erf approximation (Abramowitz and Stegun)
        a1 = 0.254829592
        a2 = -0.284496736
        a3 = 1.421413741
        a4 = -1.453152027
        a5 = 1.061405429
        p = 0.3275911

        sign = 1 if x >= 0 else -1
        x = abs(x) / math.sqrt(2.0)

        t = 1.0 / (1.0 + p * x)
        y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * math.exp(-x * x)

        return 0.5 * (1.0 + sign * y)

    @staticmethod
    def bootstrap_ci(
        data: list[float],
        stat_fn: Callable[[list[float]], float] | None = None,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: int | None = None,
    ) -> tuple[float, float, float]:
        """Bootstrap confidence interval for a statistic.

        Args:
            data: Input data
            stat_fn: Statistic function (default: mean)
            n_bootstrap: Number of bootstrap samples
            confidence_level: Confidence level (e.g., 0.95 for 95% CI)
            random_state: Random seed

        Returns:
            Tuple of (estimate, lower_bound, upper_bound)

        Example:
            >>> data = [1, 2, 3, 4, 5]
            >>> estimate, lower, upper = Stats.bootstrap_ci(data, n_bootstrap=1000)
        """
        if stat_fn is None:
            stat_fn = Stats.mean

        if not 0 < confidence_level < 1:
            raise StatsError(f"confidence_level must be between 0 and 1, got {confidence_level}")

        rng = random.Random(random_state)

        # Calculate original statistic
        estimate = stat_fn(data)

        # Bootstrap resampling
        bootstrap_stats = []
        n = len(data)

        for _ in range(n_bootstrap):
            # Resample with replacement
            sample = [rng.choice(data) for _ in range(n)]
            stat = stat_fn(sample)
            bootstrap_stats.append(stat)

        # Calculate percentile confidence interval
        bootstrap_stats.sort()
        alpha = 1 - confidence_level
        lower_idx = int(n_bootstrap * alpha / 2)
        upper_idx = int(n_bootstrap * (1 - alpha / 2))

        lower_bound = bootstrap_stats[lower_idx]
        upper_bound = bootstrap_stats[upper_idx]

        return estimate, lower_bound, upper_bound

    @staticmethod
    def ab_test_uplift(
        group_a: list[float],
        group_b: list[float],
        metric_fn: Callable[[list[float]], float] | None = None,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: int | None = None,
    ) -> dict[str, float]:
        """A/B test uplift calculation with bootstrap confidence interval.

        Args:
            group_a: Metric values for group A (control)
            group_b: Metric values for group B (treatment)
            metric_fn: Metric function (default: mean)
            n_bootstrap: Number of bootstrap samples
            confidence_level: Confidence level
            random_state: Random seed

        Returns:
            Dictionary with keys:
            - "a_mean": Mean for group A
            - "b_mean": Mean for group B
            - "absolute_uplift": B - A
            - "relative_uplift": (B - A) / A
            - "uplift_ci_lower": Lower confidence bound for uplift
            - "uplift_ci_upper": Upper confidence bound for uplift

        Example:
            >>> group_a = [10, 12, 11, 13, 12]  # Control
            >>> group_b = [15, 16, 14, 17, 16]  # Treatment
            >>> result = Stats.ab_test_uplift(group_a, group_b)
            >>> print(result["relative_uplift"])  # % improvement
        """
        if metric_fn is None:
            metric_fn = Stats.mean

        rng = random.Random(random_state)

        # Calculate observed metrics
        a_mean = metric_fn(group_a)
        b_mean = metric_fn(group_b)
        absolute_uplift = b_mean - a_mean
        relative_uplift = (absolute_uplift / a_mean) if a_mean != 0 else 0.0

        # Bootstrap uplift distribution
        uplift_dist = []
        n_a = len(group_a)
        n_b = len(group_b)

        for _ in range(n_bootstrap):
            sample_a = [rng.choice(group_a) for _ in range(n_a)]
            sample_b = [rng.choice(group_b) for _ in range(n_b)]

            uplift = metric_fn(sample_b) - metric_fn(sample_a)
            uplift_dist.append(uplift)

        # Confidence interval for uplift
        uplift_dist.sort()
        alpha = 1 - confidence_level
        lower_idx = int(n_bootstrap * alpha / 2)
        upper_idx = int(n_bootstrap * (1 - alpha / 2))

        return {
            "a_mean": a_mean,
            "b_mean": b_mean,
            "absolute_uplift": absolute_uplift,
            "relative_uplift": relative_uplift,
            "uplift_ci_lower": uplift_dist[lower_idx],
            "uplift_ci_upper": uplift_dist[upper_idx],
        }

    @staticmethod
    def detect_outliers(
        data: list[float],
        method: Literal["iqr", "zscore"] = "iqr",
        threshold: float | None = None,
    ) -> list[int]:
        """Detect outliers in data.

        Args:
            data: Input data
            method: Detection method - "iqr" (interquartile range) or "zscore"
            threshold: Custom threshold (default: 1.5 for IQR, 3.0 for Z-score)

        Returns:
            List of indices of outlier values

        Example:
            >>> data = [1, 2, 3, 4, 5, 100]
            >>> outlier_indices = Stats.detect_outliers(data, method="iqr")
            >>> [data[i] for i in outlier_indices]
            \\[100]
        """
        if method == "iqr":
            if threshold is None:
                threshold = 1.5

            # Calculate quartiles
            sorted_data = sorted(data)
            n = len(sorted_data)

            q1_idx = n // 4
            q3_idx = 3 * n // 4

            q1 = sorted_data[q1_idx]
            q3 = sorted_data[q3_idx]
            iqr = q3 - q1

            lower_bound = q1 - threshold * iqr
            upper_bound = q3 + threshold * iqr

            outliers = [i for i, x in enumerate(data) if x < lower_bound or x > upper_bound]

        elif method == "zscore":
            if threshold is None:
                threshold = 3.0

            mean_val = Stats.mean(data)
            std_val = Stats.std(data, ddof=1)

            if std_val == 0:
                return []

            outliers = [i for i, x in enumerate(data) if abs((x - mean_val) / std_val) > threshold]

        else:
            raise StatsError(f"Unknown method: {method}. Use 'iqr' or 'zscore'")

        return outliers
