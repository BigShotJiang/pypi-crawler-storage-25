"""Machine Learning utilities module.

This module provides practical ML utilities that complement sklearn/pandas:
- Random & reproducibility (SeedManager, synthetic data)
- ID generation (UUID, ULID, hash-based IDs)
- Data splitting (train/val/test, k-fold, stratified, time-series, group)
- Statistical utilities (correlation, hypothesis tests, bootstrap, outliers)
- Feature scaling (standard, min-max, robust with state management)
- Categorical encoding (label, one-hot, ordinal, frequency with state management)

Example:
    >>> from dspu.ml import SeedManager, DataSplitter, Scaler, Encoder
    >>>
    >>> # Reproducibility
    >>> SeedManager.set_global_seed(42)
    >>>
    >>> # Data splitting
    >>> X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
    ...     X, y, test_size=0.2
    ... )
    >>>
    >>> # Feature scaling
    >>> scaler = Scaler(method="standard")
    >>> X_train_scaled = scaler.fit_transform(X_train)
    >>> X_test_scaled = scaler.transform(X_test)
    >>>
    >>> # Categorical encoding
    >>> encoder = Encoder(method="label")
    >>> y_encoded = encoder.fit_transform(y_categorical)
"""

# Random & Reproducibility
# Categorical Encoding
from .encoding import Encoder, EncodingError

# ID Generation
from .identifiers import IDError, IDGenerator
from .random import (
    RandomError,
    SeedManager,
    make_classification_data,
    make_regression_data,
    make_time_series,
)

# Feature Scaling
from .scaling import Scaler, ScalingError

# Data Splitting
from .splits import DataSplitter, SplitError

# Statistical Utilities
from .stats import Stats, StatsError

__all__ = [
    # Data Splitting
    "DataSplitter",
    # Categorical Encoding
    "Encoder",
    "EncodingError",
    # ID Generation
    "IDError",
    "IDGenerator",
    # Random & Reproducibility
    "RandomError",
    # Feature Scaling
    "Scaler",
    "ScalingError",
    "SeedManager",
    "SplitError",
    # Statistical Utilities
    "Stats",
    "StatsError",
    "make_classification_data",
    "make_regression_data",
    "make_time_series",
]
