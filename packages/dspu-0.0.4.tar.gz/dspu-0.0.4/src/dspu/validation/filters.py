"""Filter classes for data validation and transformation.

This module provides a base Filter class and common filter implementations
for cleaning and transforming data.
"""

import re
from abc import ABC, abstractmethod
from typing import Any


class Filter(ABC):
    """Base class for all filters.

    Filters are transformation functions that take an input value and return
    a modified version. They can be chained together using FilterChain.

    Example:
        >>> class MyFilter(Filter):
        ...     def apply(self, value: Any) -> Any:
        ...         return str(value).upper()
        >>>
        >>> f = MyFilter()
        >>> f("hello")
        'HELLO'
    """

    @abstractmethod
    def apply(self, value: Any) -> Any:
        """Apply the filter transformation to a value.

        Args:
            value: The input value to transform

        Returns:
            The transformed value
        """

    def __call__(self, value: Any) -> Any:
        """Allow filter to be called directly.

        Args:
            value: The input value to transform

        Returns:
            The transformed value
        """
        return self.apply(value)

    def then(self, other: "Filter") -> "FilterChain":
        """Chain this filter with another.

        Args:
            other: The filter to chain after this one

        Returns:
            A FilterChain combining both filters

        Example:
            >>> strip = StripWhitespaceFilter()
            >>> lower = LowercaseFilter()
            >>> chain = strip.then(lower)
            >>> chain("  HELLO  ")
            'hello'
        """
        return FilterChain([self, other])


class FilterChain(Filter):
    """Chain multiple filters together.

    Applies filters in sequence, passing the output of each filter
    as the input to the next.

    Attributes:
        filters: List of filters to apply in order

    Example:
        >>> chain = FilterChain([
        ...     StripWhitespaceFilter(),
        ...     LowercaseFilter(),
        ...     TruncateFilter(max_length=10)
        ... ])
        >>> chain("  HELLO WORLD  ")
        'hello worl'
    """

    def __init__(self, filters: list[Filter]) -> None:
        """Initialize filter chain.

        Args:
            filters: List of filters to apply in sequence
        """
        if not filters:
            msg = "FilterChain must contain at least one filter"
            raise ValueError(msg)

        self.filters = filters

    def apply(self, value: Any) -> Any:
        """Apply all filters in sequence.

        Args:
            value: The input value to transform

        Returns:
            The transformed value after all filters applied
        """
        result = value
        for filter_func in self.filters:
            result = filter_func.apply(result)
        return result

    def then(self, other: Filter) -> "FilterChain":
        """Add another filter to the chain.

        Args:
            other: The filter to add to the end of the chain

        Returns:
            A new FilterChain with the additional filter
        """
        return FilterChain([*self.filters, other])

    def __repr__(self) -> str:
        """Return string representation of the filter chain."""
        filters_repr = " -> ".join(f.__class__.__name__ for f in self.filters)
        return f"FilterChain({filters_repr})"


class StripWhitespaceFilter(Filter):
    """Remove leading and trailing whitespace from strings.

    Example:
        >>> f = StripWhitespaceFilter()
        >>> f("  hello  ")
        'hello'
        >>> f("\\n\\t test \\n")
        'test'
    """

    def apply(self, value: Any) -> Any:
        """Strip whitespace from string value.

        Args:
            value: Input value (converted to string)

        Returns:
            String with whitespace stripped
        """
        return str(value).strip()


class LowercaseFilter(Filter):
    """Convert strings to lowercase.

    Example:
        >>> f = LowercaseFilter()
        >>> f("HELLO World")
        'hello world'
    """

    def apply(self, value: Any) -> Any:
        """Convert value to lowercase string.

        Args:
            value: Input value (converted to string)

        Returns:
            Lowercase string
        """
        return str(value).lower()


class UppercaseFilter(Filter):
    """Convert strings to uppercase.

    Example:
        >>> f = UppercaseFilter()
        >>> f("hello world")
        'HELLO WORLD'
    """

    def apply(self, value: Any) -> Any:
        """Convert value to uppercase string.

        Args:
            value: Input value (converted to string)

        Returns:
            Uppercase string
        """
        return str(value).upper()


class TruncateFilter(Filter):
    """Truncate strings to a maximum length.

    Attributes:
        max_length: Maximum length of output string
        suffix: Optional suffix to add to truncated strings

    Example:
        >>> f = TruncateFilter(max_length=10)
        >>> f("Hello World!")
        'Hello Worl'
        >>>
        >>> f = TruncateFilter(max_length=10, suffix="...")
        >>> f("Hello World!")
        'Hello W...'
    """

    def __init__(self, max_length: int, suffix: str = "") -> None:
        """Initialize truncate filter.

        Args:
            max_length: Maximum length of output string
            suffix: Optional suffix to add when truncating (default: "")

        Raises:
            ValueError: If max_length is not positive
        """
        if max_length <= 0:
            msg = "max_length must be positive"
            raise ValueError(msg)

        if suffix and len(suffix) >= max_length:
            msg = "suffix length must be less than max_length"
            raise ValueError(msg)

        self.max_length = max_length
        self.suffix = suffix

    def apply(self, value: Any) -> Any:
        """Truncate string to maximum length.

        Args:
            value: Input value (converted to string)

        Returns:
            Truncated string
        """
        text = str(value)
        if len(text) <= self.max_length:
            return text

        if self.suffix:
            truncate_to = self.max_length - len(self.suffix)
            return text[:truncate_to] + self.suffix

        return text[: self.max_length]


class RemoveSpecialCharsFilter(Filter):
    """Remove special characters from strings.

    Keeps only alphanumeric characters and specified allowed characters.

    Attributes:
        allowed_chars: Set of additional characters to allow (besides alphanumeric)
        replacement: Character to replace special characters with

    Example:
        >>> f = RemoveSpecialCharsFilter()
        >>> f("hello@world!")
        'helloworld'
        >>>
        >>> f = RemoveSpecialCharsFilter(allowed_chars={" ", "-"})
        >>> f("hello-world!")
        'hello-world'
        >>>
        >>> f = RemoveSpecialCharsFilter(replacement="_")
        >>> f("hello@world!")
        'hello_world_'
    """

    def __init__(
        self,
        allowed_chars: set[str] | None = None,
        replacement: str = "",
    ) -> None:
        """Initialize remove special chars filter.

        Args:
            allowed_chars: Set of additional characters to allow (default: None)
            replacement: Character to replace special characters with (default: "")
        """
        self.allowed_chars = allowed_chars or set()
        self.replacement = replacement

    def apply(self, value: Any) -> Any:
        """Remove special characters from string.

        Args:
            value: Input value (converted to string)

        Returns:
            String with special characters removed or replaced
        """
        text = str(value)
        result: list[str] = []

        for char in text:
            if char.isalnum() or char in self.allowed_chars:
                result.append(char)
            elif self.replacement:
                result.append(self.replacement)

        return "".join(result)


class EmailNormalizationFilter(Filter):
    """Normalize email addresses.

    Converts email to lowercase and removes dots from Gmail addresses
    (as Gmail ignores dots in the username part).

    Example:
        >>> f = EmailNormalizationFilter()
        >>> f("John.Doe@Example.COM")
        'johndoe@example.com'
        >>>
        >>> f("test.user+tag@gmail.com")
        'testuser@gmail.com'
    """

    def apply(self, value: Any) -> Any:
        """Normalize email address.

        Args:
            value: Email address string

        Returns:
            Normalized email address

        Raises:
            ValueError: If value is not a valid email format
        """
        email = str(value).strip().lower()

        # Basic email validation
        if "@" not in email or email.count("@") != 1:
            msg = f"Invalid email format: {value}"
            raise ValueError(msg)

        username, domain = email.split("@")

        # Remove dots from Gmail addresses
        if domain in ("gmail.com", "googlemail.com"):
            username = username.replace(".", "")

        # Remove + tags (common email aliasing)
        if "+" in username:
            username = username.split("+")[0]

        return f"{username}@{domain}"


class SlugifyFilter(Filter):
    """Convert strings to URL-friendly slugs.

    Converts text to lowercase, replaces spaces and special characters
    with hyphens, and removes consecutive hyphens.

    Attributes:
        separator: Character to use as separator (default: "-")
        lowercase: Whether to convert to lowercase (default: True)

    Example:
        >>> f = SlugifyFilter()
        >>> f("Hello World!")
        'hello-world'
        >>>
        >>> f("  Multiple   Spaces  ")
        'multiple-spaces'
        >>>
        >>> f = SlugifyFilter(separator="_", lowercase=False)
        >>> f("Hello World!")
        'Hello_World'
    """

    def __init__(self, separator: str = "-", lowercase: bool = True) -> None:
        """Initialize slugify filter.

        Args:
            separator: Character to use as separator (default: "-")
            lowercase: Whether to convert to lowercase (default: True)
        """
        self.separator = separator
        self.lowercase = lowercase

    def apply(self, value: Any) -> Any:
        """Convert string to slug.

        Args:
            value: Input value (converted to string)

        Returns:
            URL-friendly slug
        """
        text = str(value)

        # Convert to lowercase if requested
        if self.lowercase:
            text = text.lower()

        # Replace whitespace and special chars with separator
        text = re.sub(r"[^\w\s-]", "", text)
        text = re.sub(r"[-\s]+", self.separator, text)

        # Remove leading/trailing separators
        return text.strip(self.separator)


class RegexReplaceFilter(Filter):
    """Replace text matching a regex pattern.

    Attributes:
        pattern: Regex pattern to match
        replacement: String to replace matches with
        count: Maximum number of replacements (0 = unlimited)

    Example:
        >>> f = RegexReplaceFilter(r"\\d+", "X")
        >>> f("I have 123 apples and 456 oranges")
        'I have X apples and X oranges'
        >>>
        >>> f = RegexReplaceFilter(r"\\d+", "X", count=1)
        >>> f("I have 123 apples and 456 oranges")
        'I have X apples and 456 oranges'
    """

    def __init__(self, pattern: str, replacement: str, count: int = 0) -> None:
        """Initialize regex replace filter.

        Args:
            pattern: Regex pattern to match
            replacement: String to replace matches with
            count: Maximum number of replacements (default: 0 = unlimited)
        """
        self.pattern = re.compile(pattern)
        self.replacement = replacement
        self.count = count

    def apply(self, value: Any) -> Any:
        """Replace text matching regex pattern.

        Args:
            value: Input value (converted to string)

        Returns:
            String with replacements applied
        """
        return self.pattern.sub(self.replacement, str(value), count=self.count)
