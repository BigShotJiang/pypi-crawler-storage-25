"""Validation decorators and Pydantic integration.

This module provides decorators for applying filters and validators to functions,
along with Pydantic integration for automatic validation.
"""

import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar

try:
    from pydantic import BaseModel, create_model, field_validator, model_validator
    from pydantic import ValidationError as PydanticValidationError

    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False
    BaseModel = None  # type: ignore[misc,assignment]
    PydanticValidationError = Exception  # type: ignore[misc,assignment]
    field_validator = None  # type: ignore[assignment]
    create_model = None  # type: ignore[assignment]
    model_validator = None  # type: ignore[assignment]

from dspu.core.exceptions import ValidationError
from dspu.validation.filters import Filter, FilterChain

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])


def validate_field(
    *filters: Filter,
    field_name: str | None = None,
) -> Callable[[F], F]:
    """Decorator to validate and transform a specific function argument.

    Args:
        *filters: Filters to apply to the field value
        field_name: Name of the parameter to validate (if None, validates first param)

    Returns:
        Decorated function that applies filters to the specified field

    Example:
        >>> @validate_field(StripWhitespaceFilter(), LowercaseFilter())
        ... def process_email(email: str) -> str:
        ...     return email
        >>>
        >>> process_email("  USER@EXAMPLE.COM  ")
        'user@example.com'
    """
    if not filters:
        msg = "At least one filter must be provided"
        raise ValueError(msg)

    filter_chain = FilterChain(list(filters)) if len(filters) > 1 else filters[0]

    def decorator(func: F) -> F:
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())

        # Determine which parameter to validate
        if field_name is None:
            if not params:
                msg = f"Function {func.__name__} has no parameters to validate"
                raise ValueError(msg)
            target_param = params[0]
        else:
            if field_name not in params:
                msg = f"Parameter '{field_name}' not found in function {func.__name__}"
                raise ValueError(msg)
            target_param = field_name

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Convert args to kwargs for easier manipulation
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()

            # Apply filter to target parameter
            if target_param in bound_args.arguments:
                original_value = bound_args.arguments[target_param]
                try:
                    filtered_value = filter_chain.apply(original_value)
                    bound_args.arguments[target_param] = filtered_value
                except Exception as e:
                    msg = f"Validation failed for parameter '{target_param}': {e}"
                    raise ValidationError(msg) from e

            return func(*bound_args.args, **bound_args.kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator


def validate(
    *,
    input_filters: dict[str, Filter | FilterChain] | None = None,
    output_filter: Filter | FilterChain | None = None,
) -> Callable[[F], F]:
    """Decorator to validate function inputs and outputs.

    Args:
        input_filters: Dict mapping parameter names to filters
        output_filter: Filter to apply to function return value

    Returns:
        Decorated function with validation applied

    Example:
        >>> @validate(
        ...     input_filters={
        ...         "email": EmailNormalizationFilter(),
        ...         "name": FilterChain([
        ...             StripWhitespaceFilter(),
        ...             TruncateFilter(max_length=50)
        ...         ])
        ...     },
        ...     output_filter=StripWhitespaceFilter()
        ... )
        ... def create_user(email: str, name: str) -> str:
        ...     return f"{name} <{email}>"
        >>>
        >>> create_user("John.Doe@GMAIL.COM", "  John Doe  ")
        'John Doe <johndoe@gmail.com>'
    """

    def decorator(func: F) -> F:
        sig = inspect.signature(func)

        # Validate that input_filters reference valid parameters
        if input_filters:
            for param_name in input_filters:
                if param_name not in sig.parameters:
                    msg = f"Parameter '{param_name}' not found in function {func.__name__}"
                    raise ValueError(msg)

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Apply input filters
            if input_filters:
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()

                for param_name, filter_func in input_filters.items():
                    if param_name in bound_args.arguments:
                        original_value = bound_args.arguments[param_name]
                        try:
                            filtered_value = filter_func.apply(original_value)
                            bound_args.arguments[param_name] = filtered_value
                        except Exception as e:
                            msg = f"Validation failed for parameter '{param_name}': {e}"
                            raise ValidationError(msg) from e

                result = func(*bound_args.args, **bound_args.kwargs)
            else:
                result = func(*args, **kwargs)

            # Apply output filter
            if output_filter is not None:
                try:
                    result = output_filter.apply(result)
                except Exception as e:
                    msg = f"Output validation failed: {e}"
                    raise ValidationError(msg) from e

            return result

        return wrapper  # type: ignore[return-value]

    return decorator


def pydantic_filter_validator(
    filter_func: Filter | FilterChain,
) -> Callable[[Any], Any]:
    """Create a Pydantic field validator from a filter.

    This allows using dspu filters as Pydantic field validators.

    Args:
        filter_func: Filter or FilterChain to use for validation

    Returns:
        Pydantic validator function

    Raises:
        ImportError: If Pydantic is not installed

    Example:
        >>> from pydantic import BaseModel, field_validator
        >>>
        >>> class User(BaseModel):
        ...     email: str
        ...     name: str
        ...
        ...     _validate_email = field_validator("email", mode="before")(
        ...         pydantic_filter_validator(EmailNormalizationFilter())
        ...     )
        ...     _validate_name = field_validator("name", mode="before")(
        ...         pydantic_filter_validator(
        ...             FilterChain([StripWhitespaceFilter(), TruncateFilter(50)])
        ...         )
        ...     )
        >>>
        >>> user = User(email="John.Doe@GMAIL.COM", name="  John Doe  ")
        >>> user.email
        'johndoe@gmail.com'
        >>> user.name
        'John Doe'
    """
    if not PYDANTIC_AVAILABLE:
        msg = (
            "Pydantic is required for pydantic_filter_validator. Install with: pip install pydantic"
        )
        raise ImportError(msg)

    def validator(value: Any) -> Any:
        """Apply filter to field value."""
        try:
            return filter_func.apply(value)
        except Exception as e:
            msg = f"Validation failed: {e}"
            raise ValueError(msg) from e

    return validator


class FilteredModel(BaseModel):  # type: ignore[misc]
    """Base Pydantic model with filter support.

    Subclass this to automatically apply filters to fields using
    a `_filters` class attribute.

    Example:
        >>> class User(FilteredModel):
        ...     email: str
        ...     name: str
        ...
        ...     _filters = {
        ...         "email": EmailNormalizationFilter(),
        ...         "name": FilterChain([
        ...             StripWhitespaceFilter(),
        ...             TruncateFilter(max_length=50)
        ...         ])
        ...     }
        >>>
        >>> user = User(email="John.Doe@GMAIL.COM", name="  John Doe  ")
        >>> user.email
        'johndoe@gmail.com'
    """

    @model_validator(mode="wrap")  # type: ignore[misc]
    @classmethod
    def apply_filters_wrap(cls, values: Any, handler: Any) -> Any:
        """Apply filters before validation using wrap mode.

        Args:
            values: Input values
            handler: Validation handler

        Returns:
            Validated model instance

        Raises:
            ImportError: If Pydantic is not installed
        """
        if not PYDANTIC_AVAILABLE:
            msg = "Pydantic is required for FilteredModel. Install with: pip install pydantic"
            raise ImportError(msg)

        # Look for _filters in the class hierarchy
        # In Pydantic 2, _filters is stored in __private_attributes__
        filters = None
        for base_cls in cls.__mro__:
            # Check __private_attributes__ first (Pydantic 2.x)
            if (
                hasattr(base_cls, "__private_attributes__")
                and "_filters" in base_cls.__private_attributes__
            ):
                filters_attr = base_cls.__private_attributes__["_filters"]
                if hasattr(filters_attr, "default"):
                    filters = filters_attr.default
                break
            # Fallback to __dict__ for non-Pydantic usage
            if "_filters" in base_cls.__dict__:
                filters_attr = base_cls.__dict__["_filters"]
                filters = filters_attr.default if hasattr(filters_attr, "default") else filters_attr
                break

        # Apply filters if found and input is dict
        if filters and isinstance(values, dict):
            filtered_values = values.copy()
            for field_name, filter_func in filters.items():
                if field_name in filtered_values:
                    try:
                        filtered_values[field_name] = filter_func.apply(filtered_values[field_name])
                    except Exception as e:
                        msg = f"Filter validation failed for field '{field_name}': {e}"
                        raise ValueError(msg) from e

            # Call handler with filtered values
            return handler(filtered_values)

        # Call handler with original values
        return handler(values)


def create_pydantic_model_with_filters(
    model_name: str,
    fields: dict[str, type],
    filters: dict[str, Filter | FilterChain],
) -> type[BaseModel]:
    """Dynamically create a Pydantic model with filters applied.

    Args:
        model_name: Name for the generated model class
        fields: Dict mapping field names to types
        filters: Dict mapping field names to filters

    Returns:
        Dynamically created Pydantic model class

    Raises:
        ImportError: If Pydantic is not installed

    Example:
        >>> UserModel = create_pydantic_model_with_filters(
        ...     "User",
        ...     fields={"email": str, "name": str},
        ...     filters={
        ...         "email": EmailNormalizationFilter(),
        ...         "name": StripWhitespaceFilter()
        ...     }
        ... )
        >>>
        >>> user = UserModel(email="Test@EXAMPLE.COM", name="  John  ")
        >>> user.email
        'test@example.com'
    """
    if not PYDANTIC_AVAILABLE:
        msg = "Pydantic is required. Install with: pip install pydantic"
        raise ImportError(msg)

    # Type narrowing: after checking PYDANTIC_AVAILABLE, these are guaranteed to be available
    assert field_validator is not None and BaseModel is not None

    # Build namespace for model class
    namespace: dict[str, Any] = {}

    # Add field annotations
    namespace["__annotations__"] = fields

    # Add validators for filtered fields
    for field_name, filter_func in filters.items():
        if field_name in fields:
            # Create validator function for this field
            validator_name = f"_validate_{field_name}"

            # Use field_validator decorator
            validator = field_validator(field_name, mode="before")(
                pydantic_filter_validator(filter_func)
            )

            namespace[validator_name] = validator

    # Create the model class
    return type(model_name, (BaseModel,), namespace)
