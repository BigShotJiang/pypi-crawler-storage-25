#!/usr/bin/env python3
"""Generate comprehensive coverage report in Markdown format.

This script runs pytest with coverage, parses the results, and generates
a detailed docs/reports/COVERAGE_REPORT.md file.

Artifacts (coverage.json, htmlcov/) are cleaned up after generation.

Usage:
    python scripts/generate_coverage_report.py
    # or
    uv run python scripts/generate_coverage_report.py
"""

import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).parent.parent
REPORT_PATH = PROJECT_ROOT / "docs" / "reports" / "COVERAGE_REPORT.md"


def run_coverage() -> tuple[dict[str, Any], str]:
    """Run pytest with coverage and return JSON results + terminal output."""
    print("Running pytest with coverage...")

    # Run pytest with JSON and terminal output
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "--cov=dspu",
            "--cov-report=json",
            "--cov-report=term-missing",
            "-q",
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    # Load JSON coverage data
    coverage_json_path = Path("coverage.json")
    if not coverage_json_path.exists():
        print("ERROR: coverage.json not found!")
        sys.exit(1)

    with open(coverage_json_path) as f:
        coverage_data = json.load(f)

    # Combine stdout and stderr for test output parsing
    test_output = result.stdout + "\n" + result.stderr

    return coverage_data, test_output


def get_coverage_emoji(coverage: float) -> str:
    """Get emoji indicator for coverage level."""
    if coverage >= 95 or coverage >= 90:
        return "✅"
    if coverage >= 75:
        return "🟨"
    return "⚠️"


def get_coverage_status(coverage: float) -> str:
    """Get status text for coverage level."""
    if coverage == 100 or coverage >= 95:
        return "✅ Excellent"
    if coverage >= 90:
        return "✅ Good"
    if coverage >= 75:
        return "🟨 Good"
    if coverage >= 60:
        return "🟨 Acceptable"
    if coverage >= 50:
        return "🟨 Needs Improvement"
    if coverage > 0:
        return "⚠️ Needs Improvement"
    return "⚠️ Not Tested"


def calculate_module_coverage(coverage_data: dict[str, Any]) -> dict[str, dict]:
    """Calculate coverage statistics per module."""
    files = coverage_data["files"]
    modules: dict[str, dict] = {}

    for file_path, file_data in files.items():
        if not file_path.startswith("src/dspu/"):
            continue

        # Extract module name (e.g., "aio", "config", "io")
        parts = file_path.split("/")
        if len(parts) < 3:
            continue

        module_name = parts[2]

        if module_name not in modules:
            modules[module_name] = {
                "files": [],
                "total_statements": 0,
                "total_missing": 0,
                "total_branches": 0,
                "total_partial_branches": 0,
            }

        summary = file_data["summary"]
        file_name = "/".join(parts[3:])  # Relative to module

        modules[module_name]["files"].append(
            {
                "name": file_name,
                "statements": summary["num_statements"],
                "missing": summary["missing_lines"],
                "branches": summary["num_branches"],
                "partial_branches": summary["num_partial_branches"],
                "coverage": summary["percent_covered"],
            }
        )

        modules[module_name]["total_statements"] += summary["num_statements"]
        modules[module_name]["total_missing"] += summary["missing_lines"]
        modules[module_name]["total_branches"] += summary["num_branches"]
        modules[module_name]["total_partial_branches"] += summary["num_partial_branches"]

    # Calculate overall module coverage
    for module_data in modules.values():
        total = module_data["total_statements"]
        missing = module_data["total_missing"]
        if total > 0:
            module_data["coverage"] = round((total - missing) / total * 100, 2)
        else:
            module_data["coverage"] = 0.0

    return modules


# ruff: noqa: W291
def generate_markdown_report(coverage_data: dict[str, Any], test_output: str) -> str:
    """Generate simple Markdown coverage report."""
    summary = coverage_data["totals"]
    total_coverage = round(summary["percent_covered"], 2)

    # Calculate module-level stats
    modules = calculate_module_coverage(coverage_data)

    # Parse test output for test counts
    # Look for pattern like "858 passed, 17 skipped in 21.53s"
    passed_tests = 0
    skipped_tests = 0

    for line in test_output.split("\n"):
        if "passed" in line:
            parts = line.split()
            for i, part in enumerate(parts):
                # Look for "123 passed" or "123 passed,"
                if i > 0 and (part == "passed" or part == "passed,"):
                    try:
                        passed_tests = int(parts[i - 1])
                    except (ValueError, IndexError):
                        pass
                # Look for "123 skipped"
                elif i > 0 and (part == "skipped" or part == "skipped,"):
                    try:
                        skipped_tests = int(parts[i - 1])
                    except (ValueError, IndexError):
                        pass

    total_tests = passed_tests + skipped_tests

    # Generate report
    md = f"""# DSPU Test Coverage Report

**Generated:** {datetime.now().strftime("%Y-%m-%d")}  
**Total Coverage:** {total_coverage}%  
**Tests Passing:** {passed_tests} tests  
**Tests Skipped:** {skipped_tests} tests

---

## Coverage by Module

| Module | Coverage | Status |
|--------|----------|--------|
"""

    # Sort modules by coverage (descending)
    sorted_modules = sorted(modules.items(), key=lambda x: x[1]["coverage"], reverse=True)

    for module_name, module_data in sorted_modules:
        coverage = module_data["coverage"]
        emoji = get_coverage_emoji(coverage)
        status = get_coverage_status(coverage)
        md += f"| **{module_name.capitalize()}** | {coverage:.2f}% | {status} |\n"

    md += "\n---\n\n"

    # Detailed module coverage
    md += "## Detailed Module Coverage\n\n"

    for module_name, module_data in sorted_modules:
        module_coverage = module_data["coverage"]
        file_count = len(module_data["files"])

        md += f"### {module_name.capitalize()} Module (`dspu.{module_name}`)\n\n"
        md += f"**Overall: {module_coverage:.2f}% ({file_count} files)**\n\n"
        md += "| File | Statements | Missing | Branches | Partial | Coverage |\n"
        md += "|------|-----------|---------|----------|---------|----------|\n"

        # Sort files by coverage
        sorted_files = sorted(module_data["files"], key=lambda x: x["coverage"], reverse=True)

        for file_info in sorted_files:
            coverage = file_info["coverage"]
            emoji = get_coverage_emoji(coverage)
            md += f"| `{file_info['name']}` | {file_info['statements']} | "
            md += f"{file_info['missing']} | {file_info['branches']} | "
            md += f"{file_info['partial_branches']} | **{coverage:.2f}%** {emoji} |\n"

        md += "\n"

    md += "---\n\n"

    # Test statistics
    md += "## Test Statistics\n\n"
    if total_tests > 0:
        success_rate = passed_tests / total_tests * 100
        md += f"- **Total Tests:** {total_tests} ({passed_tests} passed, {skipped_tests} skipped)\n"
        md += f"- **Success Rate:** {success_rate:.1f}%\n"
    else:
        md += "- **Total Tests:** 0\n"

    md += "- **Total Statements:** {:,}\n".format(summary["num_statements"])
    md += "- **Covered Statements:** {:,}\n".format(summary["covered_lines"])
    md += "- **Missing Statements:** {:,}\n".format(summary["missing_lines"])
    md += "- **Total Branches:** {:,}\n".format(summary["num_branches"])
    md += "- **Covered Branches:** {:,}\n".format(summary["covered_branches"])

    md += "\n---\n\n"
    md += f"**Last Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"

    return md


def main():
    """Main function to generate coverage report."""
    print("=" * 70)
    print("DSPU Coverage Report Generator")
    print("=" * 70)
    print()

    # Run coverage
    coverage_data, test_output = run_coverage()

    # Generate markdown
    print("\nGenerating markdown report...")
    markdown = generate_markdown_report(coverage_data, test_output)

    # Write to file
    REPORT_PATH.write_text(markdown)

    print(f"\n✅ Coverage report generated: {REPORT_PATH}")
    print(f"   Total coverage: {coverage_data['totals']['percent_covered']:.2f}%")

    # Clean up artifacts
    print("\nCleaning up artifacts...")

    # Remove coverage.json
    coverage_json = Path("coverage.json")
    if coverage_json.exists():
        coverage_json.unlink()
        print("   ✓ Removed coverage.json")

    # Remove htmlcov directory
    htmlcov_dir = Path("htmlcov")
    if htmlcov_dir.exists():
        shutil.rmtree(htmlcov_dir)
        print("   ✓ Removed htmlcov/")

    print("\n✅ Done!\n")


if __name__ == "__main__":
    main()
