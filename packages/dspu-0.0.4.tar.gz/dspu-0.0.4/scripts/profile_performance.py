# Profiling script - imports intentionally in functions
# ruff: noqa: PLC0415
#!/usr/bin/env python3
"""Profile performance of key DSPU operations.

This script profiles critical paths across all modules to identify
optimization opportunities, and generates a detailed
docs/reports/PERFORMANCE_REPORT.md file.

Usage:
    python scripts/profile_performance.py
    # or
    uv run python scripts/profile_performance.py
"""

import cProfile
import io
import pstats

# Ensure we're profiling the local version
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from pstats import SortKey

PROJECT_ROOT = Path(__file__).parent.parent
REPORT_PATH = PROJECT_ROOT / "docs" / "reports" / "PERFORMANCE_REPORT.md"

sys.path.insert(0, str(PROJECT_ROOT / "src"))


def profile_io_operations():
    """Profile I/O operations (serialization, format detection)."""
    import asyncio

    from dspu.io import Storage, serialize

    async def async_io_ops():
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Profile JSON serialization (using serializer directly for sync)
            data = {"key": "value", "numbers": list(range(1000))}
            for _ in range(100):
                json_data = serialize(data, "json")
                _ = json_data

            # Profile storage operations
            storage = Storage.from_uri(str(tmpdir_path))
            for i in range(50):
                await storage.write(f"file_{i}.txt", f"content_{i}".encode())

            for i in range(50):
                await storage.read(f"file_{i}.txt")

            # List operations
            _ = [f async for f in storage.list()]

    asyncio.run(async_io_ops())


def profile_config_loading():
    """Profile configuration loading and validation."""
    try:
        from dspu.config import Config, ConfigSource
    except ImportError as e:
        # Skip if optional dependencies are missing
        raise ImportError(f"Config dependencies not available: {e}") from e

    config_data = {
        "database": {"host": "localhost", "port": 5432},
        "features": {f"feature_{i}": True for i in range(100)},
    }

    for _ in range(100):
        config = Config()
        config.load_source(ConfigSource.from_dict(config_data))
        _ = config.get("database.host")
        _ = config.get("features.feature_50")


def profile_validation():
    """Profile validation and filtering operations."""
    from dspu.validation import (
        LowercaseFilter,
        RemoveSpecialCharsFilter,
        StripWhitespaceFilter,
    )

    filter_chain = StripWhitespaceFilter().then(LowercaseFilter()).then(RemoveSpecialCharsFilter())

    test_strings = [f"  Test String #{i}!@#  " for i in range(1000)]

    for s in test_strings:
        filter_chain(s)


def profile_ml_operations():
    """Profile ML utilities (scaling, encoding, stats)."""
    from dspu.ml import Encoder, Scaler, Stats

    # Profile scaling
    scaler = Scaler(method="standard")
    data = [[float(i), float(i * 2)] for i in range(1000)]
    scaler.fit(data)

    for _ in range(100):
        scaler.transform(data)
        scaler.inverse_transform(scaler.transform(data))

    # Profile encoding
    encoder = Encoder(method="label")
    categories = [f"cat_{i % 50}" for i in range(1000)]
    encoder.fit(categories)

    for _ in range(100):
        encoder.transform(categories)

    # Profile stats
    numbers = [float(i) for i in range(1000)]
    for _ in range(50):
        Stats.mean(numbers)
        Stats.median(numbers)
        Stats.std(numbers)
        Stats.correlation(numbers, numbers, method="pearson")


def profile_async_utilities():
    """Profile async utilities (retry, rate limiter, circuit breaker)."""
    import asyncio

    from dspu.aio import BackoffStrategy, CircuitBreaker, RateLimiter, retry

    async def async_operations():
        # Profile retry decorator
        @retry(max_attempts=3, strategy=BackoffStrategy.EXPONENTIAL)
        async def flaky_operation():
            return "success"

        for _ in range(100):
            await flaky_operation()

        # Profile rate limiter
        limiter = RateLimiter(rate=100, capacity=100)
        for _ in range(200):
            async with limiter.limit():
                pass

        # Profile circuit breaker
        breaker = CircuitBreaker(failure_threshold=5)

        async def protected_operation():
            return "success"

        for _ in range(100):
            await breaker.call(protected_operation)

    asyncio.run(async_operations())


def run_profile(func, name):
    """Run profiler on a function and return detailed results."""
    print(f"\n{'=' * 70}")
    print(f"Profiling: {name}")
    print(f"{'=' * 70}\n")

    profiler = cProfile.Profile()
    profiler.enable()

    import time

    start_time = time.perf_counter()

    try:
        func()
        elapsed_time = time.perf_counter() - start_time
        error = None
    except Exception as e:
        elapsed_time = time.perf_counter() - start_time
        error = str(e)
        print(f"Error during profiling: {e}")
    finally:
        # Ensure profiler is always disabled
        profiler.disable()

    if error:
        return {
            "name": name,
            "status": "error",
            "error": error,
            "elapsed_time": elapsed_time,
        }

    # Create stats
    stats = pstats.Stats(profiler)

    # Get top functions by cumulative time
    stream = io.StringIO()
    stats_copy = pstats.Stats(profiler, stream=stream)
    stats_copy.sort_stats(SortKey.CUMULATIVE)
    stats_copy.print_stats(10)
    cumulative_output = stream.getvalue()

    # Get top functions by time
    stream = io.StringIO()
    stats_copy = pstats.Stats(profiler, stream=stream)
    stats_copy.sort_stats(SortKey.TIME)
    stats_copy.print_stats(10)
    time_output = stream.getvalue()

    print(f"✅ Completed in {elapsed_time:.3f}s")

    return {
        "name": name,
        "status": "success",
        "elapsed_time": elapsed_time,
        "cumulative_output": cumulative_output,
        "time_output": time_output,
        "total_calls": stats.total_calls,
    }


def generate_report(results: dict) -> str:
    """Generate markdown report from profiling results."""
    report_lines = [
        "# Performance Profiling Report",
        "",
        f"**Date:** {datetime.now().strftime('%Y-%m-%d')}",
        "",
        "## Summary",
        "",
        "Comprehensive performance profiling of DSPU modules to identify",
        "optimization opportunities.",
        "",
        "## Profiled Modules",
        "",
    ]

    # Summary table
    report_lines.extend(
        [
            "| Module | Status | Time (s) | Total Calls |",
            "|--------|--------|----------|-------------|",
        ]
    )

    for name, result in results.items():
        if result["status"] == "success":
            report_lines.append(
                f"| {name} | ✅ Success | {result['elapsed_time']:.3f} | "
                f"{result.get('total_calls', 'N/A'):,} |"
            )
        else:
            report_lines.append(f"| {name} | ❌ Error | {result['elapsed_time']:.3f} | N/A |")

    report_lines.extend(["", "---", ""])

    # Detailed results for each module
    report_lines.extend(["## Detailed Results", ""])

    for name, result in results.items():
        report_lines.extend([f"### {name}", ""])

        if result["status"] == "error":
            report_lines.extend(
                [
                    "**Status:** ❌ Error",
                    "",
                    f"**Error:** {result['error']}",
                    "",
                    "---",
                    "",
                ]
            )
            continue

        report_lines.extend(
            [
                "**Status:** ✅ Success",
                f"**Execution Time:** {result['elapsed_time']:.3f}s",
                f"**Total Function Calls:** {result.get('total_calls', 'N/A'):,}",
                "",
                "#### Top Functions by Cumulative Time",
                "",
                "```",
                result["cumulative_output"].strip(),
                "```",
                "",
                "---",
                "",
            ]
        )

    # Recommendations
    report_lines.extend(
        [
            "## Performance Insights",
            "",
            "### Key Observations",
            "",
        ]
    )

    successful = [r for r in results.values() if r["status"] == "success"]
    if successful:
        fastest = min(successful, key=lambda x: x["elapsed_time"])
        slowest = max(successful, key=lambda x: x["elapsed_time"])

        report_lines.extend(
            [
                f"- **Fastest Module:** {fastest['name']} ({fastest['elapsed_time']:.3f}s)",
                f"- **Slowest Module:** {slowest['name']} ({slowest['elapsed_time']:.3f}s)",
                "",
            ]
        )

    report_lines.extend(
        [
            "### Optimization Opportunities",
            "",
            "Review the detailed profiling data above to identify:",
            "- Functions with high cumulative time (potential bottlenecks)",
            "- Functions called frequently (optimization candidates)",
            "- Import overhead in hot paths",
            "",
            "---",
            "",
            "## Next Steps",
            "",
            "1. **Hot Path Analysis**: Focus on functions with highest cumulative time",
            "2. **Call Count Reduction**: Optimize frequently called functions",
            "3. **Caching**: Consider caching for expensive operations",
            "4. **Lazy Loading**: Defer imports of optional dependencies",
            "",
        ]
    )

    return "\n".join(report_lines)


def main():
    """Run all profiling tests and generate report."""
    print("=" * 70)
    print("DSPU Performance Profiling")
    print("=" * 70)

    profiles = [
        (profile_io_operations, "I/O Operations"),
        (profile_config_loading, "Config Loading"),
        (profile_validation, "Validation & Filtering"),
        (profile_ml_operations, "ML Utilities"),
        (profile_async_utilities, "Async Utilities"),
    ]

    results = {}
    for func, name in profiles:
        try:
            result = run_profile(func, name)
            results[name] = result
        except Exception as e:
            print(f"\nFailed to profile {name}: {e}")
            results[name] = {
                "name": name,
                "status": "error",
                "error": str(e),
                "elapsed_time": 0.0,
            }

    print("\n" + "=" * 70)
    print("Profiling Complete!")
    print("=" * 70)

    # Summary
    print("\n📊 Summary:")
    print("-" * 70)
    for name, result in results.items():
        if result["status"] == "success":
            print(f"✅ {name}: {result['elapsed_time']:.3f}s")
        else:
            print(f"❌ {name}: Failed")

    # Generate report
    print(f"\nGenerating report: {REPORT_PATH}")
    report_content = generate_report(results)
    REPORT_PATH.write_text(report_content)
    print(f"✅ Report generated: {REPORT_PATH}")


if __name__ == "__main__":
    main()
