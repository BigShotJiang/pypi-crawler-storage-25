# Examples Overview

Practical examples for each DSPU module.

## Available Examples

### Core Module
[Core Examples →](core.md)

Learn about protocols, plugin registry, and exception handling.

- Basic protocol usage
- Plugin registration and retrieval
- Error handling patterns

### Configuration
[Config Examples →](config.md)

Multi-source configuration management.

- Loading from files (YAML, TOML, JSON, HOCON)
- Environment variable integration
- Vault secret integration
- Configuration watching
- Pydantic validation

### I/O Operations
[I/O Examples →](io.md)

File operations and cloud storage.

- Basic file operations
- Multi-format file writing
- Path resolution and security
- Streaming large files
- Cloud storage (S3, GCS, Azure)

### Async Utilities
[Async Examples →](aio.md)

Resilient async operations.

- Retry patterns with backoff strategies
- Rate limiting
- Circuit breakers
- Concurrency control
- Sync/async bridges

### Validation
[Validation Examples →](validation.md)

Data filtering and validation.

- Basic filters and composition
- Pydantic integration
- Real-world use cases

### Security
[Security Examples →](security.md)

Secret management and encryption.

- Secret management backends
- Authentication providers
- Encryption patterns
- Token rotation

### Observability
[Observability Examples →](observability.md)

Logging, tracing, and rich output.

- Basic logging setup
- Structured logging with context
- Tracing decorators
- Rich console output
- Progress bars

### ML Utilities
[ML Examples →](ml.md)

Machine learning utilities.

- Complete ML pipeline
- Reproducibility and seed management
- Data splitting strategies
- Feature scaling and encoding
- Statistical analysis
- A/B testing

## Running Examples

All examples are located in the `examples/` directory:

```bash
# Clone the repository
git clone https://github.com/yourorg/dspu.git
cd dspu

# Install dependencies
uv sync --all-extras

# Run an example
python examples/ml/01_ml_pipeline.py
python examples/observability/01_basic_logging.py
```

## Example Structure

Each module's examples directory contains:

- `README.md` - Overview and documentation
- `01_*.py` - Basic usage examples
- `02_*.py` - Advanced patterns
- `03_*.py` - Real-world scenarios

## Contributing Examples

Have a great use case? We welcome example contributions!

See the [Contributing Guide](../contributing/development.md) for details.
