# DSPU Design Document

**Version:** 1.0.0
**Status:** Design Phase
**Last Updated:** 2025-11-16

---

## Executive Summary

**DSPU** is a modern, extensible data science utilities library designed to provide a robust foundation for ML/AI projects. Built with simplicity and developer experience in mind, it uses contemporary Python best practices, type safety, and a plugin-based architecture.

### Design Principles

1. **Simplicity First**: APIs should be intuitive and self-documenting
2. **Type Safety**: Full type hints with runtime validation
3. **Extensibility**: Plugin architecture for easy customization
4. **Zero Bloat**: Minimal dependencies with optional extras
5. **Modern Python**: Python 3.11+ features, async-first where appropriate
6. **Developer Experience**: Excellent error messages, comprehensive docs
7. **Production Ready**: Battle-tested patterns, extensive testing

---

## Architecture Overview

### Module Structure

```
dspu/
├── core/           # Core abstractions and protocols
├── config/         # Configuration management
├── io/             # I/O operations (persistence, serialization)
├── async/          # Async utilities and patterns
├── security/       # Authentication and secrets management
├── ml/             # ML-specific utilities
├── observability/  # Logging, metrics, tracing
├── validation/     # Data validation and sanitization
└── plugins/        # Plugin system and registry
```

### Dependency Philosophy

**Core Dependencies (Minimal):**
- `pydantic >= 2.0` - Data validation and settings
- `typing-extensions` - Enhanced typing support
- `structlog` - Structured logging

**Optional Dependencies (Install as needed):**
```toml
[project.optional-dependencies]
io = ["fsspec", "cloudpathlib", "orjson", "msgpack"]
async = ["anyio", "httpx"]
security = ["cryptography", "pyjwt", "hvac"]
ml = ["numpy", "pandas"]
grpc = ["grpcio", "grpcio-tools", "protobuf"]
all = ["dspu[io,async,security,ml,grpc]"]
```

### Plugin Architecture

Simple plugin system using protocols:

```python
from dspu.plugins import Plugin, register_plugin
from typing import Protocol

@runtime_checkable
class SerializerPlugin(Protocol):
    def serialize(self, obj: Any) -> bytes: ...
    def deserialize(self, data: bytes, type_hint: type) -> Any: ...

@register_plugin("custom-serializer")
class CustomSerializer:
    def serialize(self, obj: Any) -> bytes:
        return custom_encode(obj)

    def deserialize(self, data: bytes, type_hint: type) -> Any:
        return custom_decode(data, type_hint)
```

---

## Module Designs

### 1. Configuration Module (`dspu.config`)

**Type-safe configuration with validation**

```python
from dspu.config import Config, ConfigSource
from pydantic import BaseModel, Field

class AppConfig(BaseModel):
    database_url: str = Field(..., description="Database connection URL")
    max_workers: int = Field(default=4, ge=1, le=100)
    debug: bool = False

# Load from multiple sources with priority
config = Config.load(
    AppConfig,
    sources=[
        ConfigSource.file("config.yaml"),
        ConfigSource.env(prefix="APP_"),
        ConfigSource.vault("secret/myapp"),
    ]
)
```

**Features:**
- Pydantic-based validation
- Multiple format support (YAML, TOML, JSON, HOCON, TOON, .env)
- Secret injection from various sources
- Environment variable overlay
- Type coercion and validation
- Clear error messages

**Public API:**
```python
class Config:
    @classmethod
    def load(cls, config_class: Type[T], sources: Sequence[ConfigSource]) -> T: ...
    @classmethod
    def load_from_file(cls, config_class: Type[T], path: str) -> T: ...
    @classmethod
    def load_from_env(cls, config_class: Type[T], prefix: str = "") -> T: ...

class ConfigSource:
    @staticmethod
    def file(path: str, format: str | None = None) -> FileSource: ...
    @staticmethod
    def env(prefix: str = "") -> EnvSource: ...
    @staticmethod
    def dict(data: dict) -> DictSource: ...
    @staticmethod
    def vault(path: str, **kwargs) -> VaultSource: ...

class WatchedConfig:
    @classmethod
    def load(cls, config_class: Type[T], source: ConfigSource, reload_interval: float) -> WatchedConfig[T]: ...
    @property
    def current(self) -> T: ...
    def on_change(self, callback: Callable[[T, T], None]) -> None: ...
```

**Configuration Patterns:**

The configuration module supports various real-world patterns for different deployment scenarios.

**1. Layered Configuration (Defaults → File → Environment)**

This is the most common pattern: start with defaults, override with deployment-specific files, and apply secrets from environment variables.

```python
from dspu.config import Config, FileSource, EnvSource, DictSource
from pydantic import BaseModel, Field

class DatabaseConfig(BaseModel):
    host: str = "localhost"
    port: int = 5432
    username: str = "postgres"
    password: str = "secret"
    database: str = "myapp"
    pool_size: int = 10

class AppConfig(BaseModel):
    app_name: str
    debug: bool = False
    log_level: str = "INFO"
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)

# Load with priority: defaults → file → environment
config = Config.load(
    AppConfig,
    sources=[
        DictSource({}),  # Empty dict means Pydantic defaults apply
        FileSource("production.yaml"),
        EnvSource(prefix="APP_", separator="__"),
    ],
)

# production.yaml:
#   app_name: myapp
#   database:
#     host: prod-db.example.com
#     pool_size: 20
#
# Environment variables:
#   APP_DATABASE__PASSWORD=prod-secret-pass
#   APP_API_KEY=secret-api-key-12345
#
# Result: app_name from file, database.host from file,
#         database.password from env, database.port from defaults
```

**2. Local Development Override**

A common development pattern where developers have local overrides without modifying the base config.

```python
# Base configuration
base_config = FileSource("config.yaml")

# Local developer overrides (git-ignored)
local_config = FileSource("config.local.yaml", required=False)

# Environment secrets
env_secrets = EnvSource(prefix="APP_", separator="__")

config = Config.load(
    AppConfig,
    sources=[base_config, local_config, env_secrets],
)

# config.yaml (committed):
#   app_name: myapp
#   debug: false
#   log_level: INFO
#
# config.local.yaml (git-ignored):
#   debug: true
#   log_level: DEBUG
#   database:
#     database: myapp_dev
#
# Result: Developers can override settings without touching base config
```

**3. Multi-Format Configuration**

Load configuration from multiple file formats based on team/tool preferences.

```python
config = Config.load(
    AppConfig,
    sources=[
        FileSource("config.yaml"),        # Base config (YAML)
        FileSource("database.toml"),      # DB config (TOML)
        FileSource(".env.production", format="env"),  # Secrets (.env)
    ],
)

# Each file contributes to the final configuration.
# Later sources override earlier ones for conflicting keys.
```

**4. Environment-Specific Configuration**

Load different config files based on the deployment environment.

```python
import os

env = os.getenv("ENVIRONMENT", "development")

config = Config.load(
    AppConfig,
    sources=[
        FileSource("config.yaml"),           # Shared defaults
        FileSource(f"config.{env}.yaml"),    # Environment-specific
    ],
)

# config.yaml (shared):
#   app_name: myapp
#   database:
#     port: 5432
#
# config.production.yaml:
#   debug: false
#   log_level: WARNING
#   database:
#     host: prod-db.example.com
#     pool_size: 50
#
# config.staging.yaml:
#   debug: true
#   log_level: DEBUG
#   database:
#     host: staging-db.example.com
#     pool_size: 20
```

**5. Docker Compose / Container Pattern**

Configuration for containerized applications using environment variables.

```python
# Docker Compose style environment variables
config = Config.load(
    AppConfig,
    sources=[
        EnvSource(prefix="MYAPP_", separator="__"),
    ],
)

# docker-compose.yml:
#   environment:
#     MYAPP_APP_NAME: containerized-app
#     MYAPP_DEBUG: "true"
#     MYAPP_DATABASE__HOST: db
#     MYAPP_DATABASE__PORT: "5432"
#     MYAPP_DATABASE__USERNAME: app
#     MYAPP_DATABASE__PASSWORD: apppass
#     MYAPP_DATABASE__DATABASE: appdb
#
# The separator "__" creates nested structures:
#   MYAPP_DATABASE__HOST → config.database.host
```

**6. Kubernetes ConfigMap and Secrets**

Pattern for Kubernetes deployments with ConfigMaps and Secrets.

```python
config = Config.load(
    AppConfig,
    sources=[
        # ConfigMap mounted as file
        FileSource("/config/app-config.yaml"),
        # Secrets as environment variables
        EnvSource(prefix="", separator="__"),
    ],
)

# Kubernetes manifests:
#
# ConfigMap:
#   apiVersion: v1
#   kind: ConfigMap
#   metadata:
#     name: app-config
#   data:
#     app-config.yaml: |
#       app_name: k8s-app
#       debug: false
#       database:
#         host: postgres-service
#         port: 5432
#
# Secret (as env vars):
#   apiVersion: v1
#   kind: Secret
#   metadata:
#     name: app-secrets
#   data:
#     DATABASE__PASSWORD: <base64-encoded>
#     API_KEY: <base64-encoded>
```

**7. Optional Configuration Files**

Gracefully handle optional config files that may not exist.

```python
config = Config.load(
    AppConfig,
    sources=[
        FileSource("config.yaml"),                    # Required
        FileSource("config.local.yaml", required=False),  # Optional
        FileSource("secrets.yaml", required=False),   # Optional
    ],
)

# If optional files don't exist, they're silently skipped.
# Useful for local overrides and optional secrets.
```

**Configuration Best Practices:**

1. **Sensible Defaults**: Use Pydantic default values for common settings
2. **Secrets in Environment**: Never commit secrets; use environment variables or secret managers
3. **Validation**: Leverage Pydantic's validation (Field constraints, custom validators)
4. **Deep Merge**: Nested configs merge automatically; only override what you need
5. **Type Safety**: Use proper types in Pydantic models for automatic coercion
6. **Optional Files**: Use `required=False` for optional local overrides
7. **Prefix Convention**: Use consistent prefixes (e.g., `APP_`) to avoid conflicts
8. **Separator for Nesting**: Use `__` separator for nested configuration in env vars

---

### 2. I/O Module (`dspu.io`)

**Unified I/O interface for any storage backend**

```python
from dspu.io import Storage, serialize, deserialize

# Works with local, S3, GCS, Azure, etc.
storage = Storage.from_uri("s3://bucket/path")

# Auto-format detection or explicit
data = storage.read("data.json", format="json")
storage.write("output.msgpack", data, format="msgpack")

# Streaming for large files
async for chunk in storage.read_stream("large_file.csv"):
    process(chunk)

# Type-safe serialization
@dataclass
class Model:
    weights: np.ndarray
    metadata: dict

bytes_data = serialize(model, format="msgpack")
restored = deserialize(bytes_data, Model, format="msgpack")
```

**Key Features:**
- Protocol-based design (easy to extend)
- Async and sync interfaces
- Automatic format detection
- Cloud storage support via fsspec
- Type preservation
- Compression support

**Public API:**
```python
class Storage:
    @classmethod
    def from_uri(cls, uri: str, **kwargs) -> Storage: ...
    async def read(self, path: str, format: str | None = None) -> Any: ...
    async def write(self, path: str, data: Any, format: str | None = None) -> None: ...
    async def exists(self, path: str) -> bool: ...
    async def list(self, pattern: str) -> AsyncIterator[FileInfo]: ...
    async def delete(self, path: str) -> None: ...
    async def read_stream(self, path: str, chunk_size: int = 8192) -> AsyncIterator[bytes]: ...

def serialize(obj: Any, format: str) -> bytes: ...
def deserialize(data: bytes, type_hint: type, format: str) -> Any: ...

@runtime_checkable
class StorageBackend(Protocol):
    async def read(self, path: str) -> bytes: ...
    async def write(self, path: str, data: bytes) -> None: ...
    async def exists(self, path: str) -> bool: ...
    async def list(self, pattern: str) -> AsyncIterator[FileInfo]: ...
```

---

### 3. Async Module (`dspu.async`)

**Modern async patterns and utilities**

```python
from dspu.async import (
    retry_async,
    timeout_async,
    gather_with_limit,
    RateLimiter,
    CircuitBreaker,
)

# Retry with exponential backoff
@retry_async(max_attempts=3, backoff="exponential")
async def fetch_data(url: str) -> dict:
    response = await client.get(url)
    return response.json()

# Concurrent execution with rate limiting
limiter = RateLimiter(rate=100, per=60)  # 100 requests per 60 seconds
async with limiter:
    results = await gather_with_limit(
        10,  # max concurrent
        *[fetch_data(url) for url in urls]
    )

# Circuit breaker for resilience
circuit = CircuitBreaker(
    failure_threshold=5,
    recovery_timeout=60.0,
    expected_exceptions=(ConnectionError, TimeoutError),
)

@circuit.protected
async def call_external_service(endpoint: str) -> dict:
    response = await client.get(endpoint)
    return response.json()
```

**Features:**
- Retry decorators with configurable strategies
- Timeout management
- Concurrent execution limiting
- Circuit breaker pattern
- Rate limiting
- Sync/async compatibility layer

---

### 4. Security Module (`dspu.security`)

**Unified secret management and authentication**

```python
from dspu.security import SecretManager, AuthProvider, RotatingToken

# Unified interface for secrets (auto-detects: Vault, AWS Secrets, etc.)
secrets = SecretManager.from_env()
db_password = await secrets.get("database/password")

# Automatic token rotation
async with RotatingToken(
    fetch_fn=lambda: auth_client.get_token(),
    refresh_interval=3600,
    refresh_before=300,  # Refresh 5 minutes before expiry
) as token:
    api_client.set_token(token.current)

# Auth providers
auth = AuthProvider.create(
    "oauth2",
    client_id="...",
    client_secret=await secrets.get("oauth/secret"),
    token_url="https://auth.example.com/token",
)
token = await auth.get_token(scopes=["read", "write"])
```

**Features:**
- Pluggable secret backends (Vault, AWS, GCP, Azure, Kubernetes)
- Automatic token rotation
- Auth provider abstraction (Auth0, OAuth2, JWT, mTLS)
- Certificate management
- Encryption utilities

---

### 5. ML Module (`dspu.ml`)

**Evolutionary algorithms and experiment tracking**

```python
from dspu.ml import FitnessFunction, Population, Candidate, Experiment

# Type-safe fitness definition
class AccuracyFitness(FitnessFunction):
    def evaluate(self, candidate: Candidate) -> float:
        return candidate.score

    def compare(self, a: float, b: float) -> int:
        return 1 if a > b else -1

# Population management
population = Population[MyCandidate](
    size=100,
    fitness_fn=AccuracyFitness(),
    selection_strategy="tournament",
)
best = await population.evolve(generations=100)

# Experiment tracking
experiment = Experiment(name="training", tags={"model": "resnet50"})
async with experiment.run() as run:
    run.log_params({"lr": 0.001, "batch_size": 32})

    for epoch in range(epochs):
        loss = train_epoch()
        run.log_metric("train_loss", loss, step=epoch)

    await run.log_artifact("model", model_path)
```

**Features:**
- Generic fitness evaluation framework
- Population management
- Common selection strategies
- Metrics tracking and logging
- Experiment tracking integration
- Distributed evaluation support

---

### 6. Observability Module (`dspu.observability`)

**Structured logging, tracing, and metrics**

```python
from dspu.observability import get_logger, traced, metrics

logger = get_logger(__name__)

@traced(span_name="process_data")
async def process_data(data: list) -> Result:
    logger.info("processing_started", count=len(data))

    with metrics.timer("processing_time"):
        result = await expensive_operation(data)

    metrics.increment("items_processed", len(data))
    logger.info("processing_completed", result=result)
    return result
```

**Features:**
- Structured logging (structlog-based)
- OpenTelemetry tracing integration
- Metrics collection (Prometheus, StatsD)
- Performance profiling utilities
- Context propagation
- Log aggregation helpers

---

### 7. Validation Module (`dspu.validation`)

**Data validation and sanitization**

```python
from dspu.validation import validate, sanitize, Filter

# Compose filters
clean = (
    Filter.strip_whitespace()
    .remove_special_chars()
    .truncate(max_length=100)
    .apply(user_input)
)

# Schema validation
@validate
def process_user(
    name: str,
    email: EmailStr,
    age: int = Field(ge=0, le=150)
) -> User:
    return User(name=name, email=email, age=age)

# Custom filters
class SQLInjectionFilter(Filter):
    def apply(self, value: str) -> str:
        # Sanitization logic
        return sanitized_value
```

**Features:**
- Composable filter chains
- Common sanitization filters
- Pydantic integration
- Custom validator support
- Type-safe validation

---

## Technical Stack

### Package Management: UV

**Why UV?**
- 10-100x faster than pip
- Built-in virtual environment management
- Reproducible builds
- Better dependency resolution
- Compatible with pip ecosystem

**Project Structure:**
```toml
[project]
name = "dspu"
version = "1.0.0"
requires-python = ">=3.11"
dependencies = [
    "pydantic>=2.0",
    "structlog>=23.0",
    "typing-extensions>=4.0",
]

[project.optional-dependencies]
io = ["fsspec>=2023.1", "orjson>=3.9"]
async = ["anyio>=4.0", "httpx>=0.25"]
security = ["cryptography>=41.0", "pyjwt>=2.8"]
ml = ["numpy>=1.24", "pandas>=2.0"]
grpc = ["grpcio>=1.59", "protobuf>=4.25"]
dev = ["pytest>=7.4", "pyrefly>=0.44", "ruff>=0.1"]

[tool.ruff]
line-length = 100
target-version = "py311"

[tool.pyrefly]
# Pyrefly automatically detects Python version and applies strict checks
```

### Development Tools

- **Linting**: Ruff (fast, modern, replaces flake8/black/isort)
- **Type Checking**: Pyrefly (Meta's fast, advanced type checker)
- **Testing**: pytest + hypothesis (property-based) + pytest-asyncio
- **Documentation**: mkdocs with material theme
- **CI/CD**: GitHub Actions with uv integration

---

## API Design Patterns

### Core Principles

1. **Protocol-based**: Use protocols for interfaces, not abstract base classes
2. **Composition over inheritance**: Favor composition and mixins
3. **Async-first**: Async APIs with sync wrappers when needed
4. **Type-safe**: Full type hints, runtime validation with Pydantic
5. **Explicit errors**: Rich error messages with context

### Error Handling Pattern

```python
from dspu.exceptions import DSPUError, ConfigurationError

class ConfigurationError(DSPUError):
    """Raised when configuration is invalid"""

    def __init__(
        self,
        message: str,
        *,
        field: str | None = None,
        suggestion: str | None = None,
    ):
        super().__init__(message)
        self.field = field
        self.suggestion = suggestion

    def __str__(self) -> str:
        parts = [self.message]
        if self.field:
            parts.append(f"Field: {self.field}")
        if self.suggestion:
            parts.append(f"Suggestion: {self.suggestion}")
        return "\n".join(parts)

# Usage with helpful context
raise ConfigurationError(
    "Invalid database URL",
    field="database_url",
    suggestion="Use format: postgresql://user:pass@host:port/db"
)
```

---

## Testing Strategy

### Testing Levels

1. **Unit Tests**: Fast, isolated, high coverage (>90%)
2. **Integration Tests**: Test module interactions
3. **Property Tests**: Hypothesis for edge cases
4. **Performance Tests**: Benchmarks for critical paths
5. **Contract Tests**: Ensure API compatibility

### Example Test Structure

```python
import pytest
from hypothesis import given, strategies as st
from dspu.io import Storage

class TestStorage:
    @pytest.mark.asyncio
    async def test_read_write_roundtrip(self, tmp_path):
        storage = Storage.from_uri(str(tmp_path))
        data = b"test data"

        await storage.write("test.bin", data)
        result = await storage.read("test.bin")

        assert result == data

    @given(st.binary(min_size=0, max_size=10_000))
    async def test_roundtrip_any_bytes(self, data):
        # Property test: any bytes should roundtrip
        storage = Storage.from_uri(str(tmp_path))
        await storage.write("test.bin", data)
        result = await storage.read("test.bin")
        assert result == data
```

---

## Usage Examples

### Complete ML Training Pipeline

```python
from pydantic import BaseModel
from dspu.config import Config, ConfigSource
from dspu.io import Storage
from dspu.ml import Experiment
from dspu.observability import get_logger, traced
from dspu.security import SecretManager

logger = get_logger(__name__)

class TrainingConfig(BaseModel):
    model_name: str
    dataset_path: str
    epochs: int
    batch_size: int
    learning_rate: float
    storage_uri: str

@traced(span_name="training_pipeline")
async def main():
    # Load configuration
    config = Config.load(
        TrainingConfig,
        sources=[
            ConfigSource.file("config.yaml"),
            ConfigSource.env(prefix="TRAIN_"),
        ]
    )

    # Initialize services
    storage = Storage.from_uri(config.storage_uri)

    # Load data
    logger.info("loading_data", path=config.dataset_path)
    train_data = await storage.read(f"{config.dataset_path}/train.parquet")
    val_data = await storage.read(f"{config.dataset_path}/val.parquet")

    # Create experiment
    experiment = Experiment(
        name=f"training-{config.model_name}",
        tags={"model": config.model_name},
    )

    async with experiment.run() as run:
        run.log_params(config.dict())

        model = create_model(config.model_name)

        for epoch in range(config.epochs):
            logger.info("epoch_started", epoch=epoch)

            train_loss = await train_epoch(model, train_data, config)
            val_loss, val_metrics = await validate(model, val_data)

            run.log_metrics({
                "train_loss": train_loss,
                "val_loss": val_loss,
                **val_metrics,
            }, step=epoch)

            logger.info("epoch_completed", epoch=epoch, train_loss=train_loss)

        # Save model
        model_path = f"models/{config.model_name}/final.pt"
        await storage.write(model_path, model.state_dict())
        run.log_artifact("model", model_path)

        logger.info("training_completed", model_path=model_path)
```

### Data Processing Service

```python
from fastapi import FastAPI
from dspu.config import Config, WatchedConfig
from dspu.io import Storage
from dspu.async import CircuitBreaker, RateLimiter
from dspu.observability import get_logger, traced, metrics

logger = get_logger(__name__)
app = FastAPI()

class ServiceConfig(BaseModel):
    storage_uri: str
    external_api_url: str
    rate_limit: int = 100

config = WatchedConfig.load(ServiceConfig, source="config.yaml")
storage = Storage.from_uri(config.current.storage_uri)
limiter = RateLimiter(rate=config.current.rate_limit, per=60)
circuit = CircuitBreaker(failure_threshold=5, recovery_timeout=60)

@app.post("/process")
@traced(span_name="process_endpoint")
async def process_data(request: ProcessRequest):
    logger.info("loading_data", path=request.data_path)
    data = await storage.read(request.data_path)

    async with limiter:
        processed = await process_with_external_api(data)

    await storage.write(request.output_path, processed)
    logger.info("processing_completed", output=request.output_path)

    return {"status": "success", "output": request.output_path}

@circuit.protected
async def process_with_external_api(data: dict) -> dict:
    async with httpx.AsyncClient() as client:
        response = await client.post(
            config.current.external_api_url,
            json=data,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
```

---

## Success Metrics

### Technical Metrics
- **Type Coverage**: >95% pyrefly type safety
- **Test Coverage**: >90% line coverage
- **Performance**: <5ms overhead for common operations
- **Package Size**: Core <500KB, full <5MB

### Developer Experience Metrics
- **API Simplicity**: Common tasks <5 lines of code
- **Error Clarity**: 100% errors include helpful messages
- **Docs Coverage**: Every public API documented with examples

### Adoption Metrics
- **Migration Time**: <1 week for typical project
- **Issue Resolution**: <48 hours median response time
- **Community Growth**: Track GitHub stars, PyPI downloads

---

## Technology Choices Rationale

### Pydantic v2
- Runtime validation with minimal overhead
- Excellent JSON schema support
- Type-safe settings management
- Wide adoption in Python ecosystem

### UV
- Performance: 10-100x faster than pip
- Better UX: Simpler commands, clearer output
- Future-proof: Active development, modern design
- Compatible: Works with existing PyPI ecosystem

### Protocols over Abstract Classes
- Less coupling
- Better type checking
- More Pythonic (structural subtyping)
- Easier testing

### Async-first
- Modern Python trend
- Better scalability
- Non-blocking I/O essential for ML workflows
- Easy to provide sync wrappers

---

## Open Questions & Future Enhancements

### Current Considerations
1. Python 3.10 support or require 3.11+? (Leaning toward 3.11+)
2. Governance model for community plugins
3. Backward compatibility strategy for major changes

### Future Enhancements
- Distributed computing integration (Dask, Ray)
- ML experiment tracking platforms (MLflow, Weights & Biases)
- Data validation frameworks (Great Expectations)
- Workflow orchestration integration (Prefect, Airflow)
- GPU-accelerated operations

---

**Document Status**: Living document, updated as design evolves
**Next Review**: After Phase 1 completion
**Feedback**: Open GitHub issue or discussion
