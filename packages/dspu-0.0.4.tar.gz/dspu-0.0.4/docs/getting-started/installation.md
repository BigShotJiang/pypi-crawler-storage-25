# Installation

## Requirements

- Python 3.11 or later
- pip or uv package manager

## Basic Installation

Install DSPU using pip:

```bash
pip install dspu
```

Or using UV (faster):

```bash
uv pip install dspu
```

## Installation with Extras

DSPU provides optional dependencies for specific features:

### All Extras

Install everything:

```bash
pip install dspu[all]
```

### Specific Feature Sets

Install only what you need:

```bash
# Configuration extras (YAML, TOML, HOCON, Vault)
pip install dspu[config]

# I/O extras (cloud storage, parquet)
pip install dspu[io]

# Security extras (encryption, JWT, OAuth2)
pip install dspu[security]

# Observability extras (rich console output)
pip install dspu[observability]

# ML extras (numeric operations)
pip install dspu[ml]

# Multiple extras
pip install dspu[config,ml,observability]
```

## Available Extras

| Extra | Dependencies | Use Case |
|-------|--------------|----------|
| `config` | pyyaml, toml, pyhocon, hvac | Advanced configuration management |
| `io` | fsspec, s3fs, gcsfs, adlfs | Cloud storage and Parquet support |
| `security` | cryptography, pyjwt, httpx | Encryption, JWT, OAuth2 |
| `observability` | rich | Enhanced console output |
| `ml` | - | ML utilities (no extra deps) |
| `dev` | pytest, pyrefly, ruff | Development tools |
| `all` | All of the above | Complete installation |

## Development Installation

For contributing to DSPU:

```bash
# Clone the repository
git clone https://github.com/yourorg/dspu.git
cd dspu

# Install with UV (recommended)
uv sync --all-extras

# Or with pip
pip install -e ".[dev,all]"

# Install pre-commit hooks
pre-commit install
```

## Verify Installation

Verify DSPU is installed correctly:

```python
import dspu

print(dspu.__version__)  # Should print version number

# Try importing modules
from dspu.ml import SeedManager
from dspu.observability import get_logger
from dspu.config import Config

print("✓ DSPU installed successfully!")
```

## Troubleshooting

### Import Errors

If you encounter import errors for specific modules:

```python
# Check which extras you have installed
pip show dspu

# Install missing extras
pip install dspu[config,io,security]
```

### Version Conflicts

If you have version conflicts with other packages:

```bash
# Create a clean virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install DSPU
pip install dspu[all]
```

### UV Installation Issues

If UV is not installed:

```bash
# Install UV
curl -LsSf https://astral.sh/uv/install.sh | sh

# Or with pip
pip install uv
```

## Next Steps

- [Quick Start Guide](quickstart.md) - Your first DSPU program
- [Tutorial](tutorial.md) - Comprehensive walkthrough
- [User Guide](../user-guide/core-concepts.md) - Learn about modules
