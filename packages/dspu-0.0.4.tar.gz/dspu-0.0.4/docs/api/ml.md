# ML API Reference

Practical machine learning utilities that complement sklearn/pandas.

## Overview

The `dspu.ml` module provides utilities for:

- **Reproducibility**: Unified seed management across libraries
- **ID Generation**: UUID, ULID, hash-based identifiers
- **Data Splitting**: Train/val/test splits with no leakage
- **Statistics**: Correlation, hypothesis tests, bootstrap, A/B testing
- **Feature Scaling**: Standard, min-max, robust scaling with state persistence
- **Categorical Encoding**: Label, one-hot, ordinal, frequency encoding

## Random & Reproducibility

### SeedManager

::: dspu.ml.random.SeedManager
    options:
      show_root_heading: true
      show_source: true
      members:
        - set_global_seed
        - seed_context
        - get_rng
        - get_current_seed

### Synthetic Data Generation

::: dspu.ml.random.make_classification_data
    options:
      show_root_heading: true
      show_source: false

::: dspu.ml.random.make_regression_data
    options:
      show_root_heading: true
      show_source: false

::: dspu.ml.random.make_time_series
    options:
      show_root_heading: true
      show_source: false

## ID Generation

### IDGenerator

::: dspu.ml.identifiers.IDGenerator
    options:
      show_root_heading: true
      show_source: true
      members:
        - uuid4
        - uuid1
        - ulid
        - hash_text
        - hash_row
        - add_id_column

## Data Splitting

### DataSplitter

::: dspu.ml.splits.DataSplitter
    options:
      show_root_heading: true
      show_source: true
      members:
        - train_test_split
        - train_val_test_split
        - kfold_split
        - stratified_kfold
        - time_series_split
        - group_split

## Statistical Utilities

### Stats

::: dspu.ml.stats.Stats
    options:
      show_root_heading: true
      show_source: true
      members:
        - mean
        - median
        - std
        - correlation
        - t_test_independent
        - bootstrap_ci
        - ab_test_uplift
        - detect_outliers

## Feature Scaling

### Scaler

::: dspu.ml.scaling.Scaler
    options:
      show_root_heading: true
      show_source: true
      members:
        - __init__
        - fit
        - transform
        - fit_transform
        - inverse_transform
        - save_state
        - from_state
        - save_to_file
        - load_from_file

## Categorical Encoding

### Encoder

::: dspu.ml.encoding.Encoder
    options:
      show_root_heading: true
      show_source: true
      members:
        - __init__
        - fit
        - transform
        - fit_transform
        - inverse_transform
        - get_feature_names
        - save_state
        - from_state
        - save_to_file
        - load_from_file

## Exceptions

::: dspu.ml.random.RandomError
::: dspu.ml.identifiers.IDError
::: dspu.ml.splits.SplitError
::: dspu.ml.stats.StatsError
::: dspu.ml.scaling.ScalingError
::: dspu.ml.encoding.EncodingError

## Usage Examples

### Reproducible ML Pipeline

```python
from dspu.ml import SeedManager, DataSplitter, Scaler, make_classification_data

# Set seed
SeedManager.set_global_seed(42)

# Generate data
X, y = make_classification_data(n_samples=1000, n_features=10)

# Split
X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
    X, y, test_size=0.2, stratify=y
)

# Scale
scaler = Scaler(method="standard")
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Save for production
scaler.save_to_file("scaler.json")
```

### Data Splitting Strategies

```python
from dspu.ml import DataSplitter

# Stratified K-fold (preserves class distribution)
folds = DataSplitter.stratified_kfold(y, n_splits=5)
for train_idx, val_idx in folds:
    X_train = [X[i] for i in train_idx]
    X_val = [X[i] for i in val_idx]
    # Train and validate

# Time series split (no future leakage)
splits = DataSplitter.time_series_split(X, n_splits=5)
for train_idx, val_idx in splits:
    assert max(train_idx) < min(val_idx)  # Chronological order

# Group split (prevent leakage by group)
X_train, X_test, y_train, y_test = DataSplitter.group_split(
    X, groups=patient_ids, y=y, test_size=0.25
)
```

### A/B Testing

```python
from dspu.ml import Stats

# Analyze A/B test
result = Stats.ab_test_uplift(
    group_a=[0.10, 0.11, 0.09, 0.10, 0.12],  # Control conversion rates
    group_b=[0.15, 0.16, 0.14, 0.15, 0.17],  # Treatment conversion rates
    n_bootstrap=1000
)

print(f"Uplift: {result['relative_uplift']*100:.1f}%")
print(f"95% CI: [{result['uplift_ci_lower']:.3f}, {result['uplift_ci_upper']:.3f}]")

if result['uplift_ci_lower'] > 0:
    print("Statistically significant improvement!")
```

## See Also

- [ML Examples](../examples/ml.md) - Comprehensive examples
- [ML User Guide](../user-guide/ml.md) - Detailed guide
- [Tutorial](../getting-started/tutorial.md) - Getting started
