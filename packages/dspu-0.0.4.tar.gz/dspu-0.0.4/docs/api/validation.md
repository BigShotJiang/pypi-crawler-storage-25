# Validation API Reference

Data filters and validation decorators.

## Filters

### Base Filter

::: dspu.validation.filters.Filter

### Built-in Filters

::: dspu.validation.filters.StripWhitespaceFilter
::: dspu.validation.filters.LowercaseFilter
::: dspu.validation.filters.UppercaseFilter
::: dspu.validation.filters.TruncateFilter
::: dspu.validation.filters.RemoveSpecialCharsFilter
::: dspu.validation.filters.EmailNormalizationFilter
::: dspu.validation.filters.SlugifyFilter
::: dspu.validation.filters.RegexReplaceFilter

### Filter Chain

::: dspu.validation.filters.FilterChain

## Pydantic Integration

::: dspu.validation.validators.pydantic_filter_validator
::: dspu.validation.validators.FilteredModel

## Decorators

::: dspu.validation.validators.validate_field
::: dspu.validation.validators.validate

## Usage

```python
from dspu.validation import StripWhitespaceFilter, LowercaseFilter, EmailNormalizationFilter

# Compose filters
email_filter = (
    StripWhitespaceFilter()
    .then(LowercaseFilter())
    .then(EmailNormalizationFilter())
)

# Apply
clean_email = email_filter("  Alice@GMAIL.COM  ")
# Result: "alice@gmail.com"

# Pydantic integration
from pydantic import BaseModel

class User(BaseModel):
    email: str

    _email_filter = pydantic_filter_validator("email", email_filter)

user = User(email="  ALICE@EXAMPLE.COM  ")
# Automatically cleaned: "alice@example.com"
```

## See Also

- [Validation Examples](../examples/validation.md)
- [Validation User Guide](../user-guide/validation.md)
