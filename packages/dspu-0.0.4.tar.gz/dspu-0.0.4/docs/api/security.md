# Security API Reference

Secret management, authentication, and encryption.

## Secret Management

### SecretManager

::: dspu.security.secrets.SecretManager
    options:
      members:
        - from_env
        - from_vault
        - from_aws
        - from_env_vars
        - from_file
        - get
        - set
        - list_secrets

### Secret Backends

::: dspu.security.backends.EnvBackend
::: dspu.security.backends.FileBackend
::: dspu.security.backends.VaultBackend
::: dspu.security.backends.AWSSecretBackend

## Token Rotation

::: dspu.security.rotating_token.RotatingToken
    options:
      members:
        - __init__
        - current
        - refresh
        - is_expired

::: dspu.security.rotating_token.simple_rotating_token

## Authentication

### Providers

::: dspu.security.auth.StaticTokenProvider
::: dspu.security.auth.OAuth2Provider
::: dspu.security.auth.JWTProvider

::: dspu.security.auth.create_auth_provider

## Encryption

### Symmetric Encryption

::: dspu.security.encryption.Fernet
    options:
      members:
        - generate
        - encrypt
        - decrypt

::: dspu.security.encryption.AES
    options:
      members:
        - generate_key
        - encrypt
        - decrypt

### Password Hashing

::: dspu.security.encryption.hash_password
::: dspu.security.encryption.verify_password

### Utilities

::: dspu.security.encryption.generate_token
::: dspu.security.encryption.constant_time_compare
::: dspu.security.encryption.hash_data

## Usage

### Secret Management

```python
from dspu.security import SecretManager

# From environment
secrets = SecretManager.from_env()
api_key = secrets.get("API_KEY")

# From Vault
vault_secrets = SecretManager.from_vault(
    url="http://vault:8200",
    token="s.abc123"
)
db_password = vault_secrets.get("database/password")
```

### Token Rotation

```python
from dspu.security import RotatingToken

async def refresh_token():
    # Fetch new token from API
    return {"access_token": "...", "expires_in": 3600}

async with RotatingToken(refresh_fn=refresh_token, refresh_interval=3300) as token:
    # Token automatically refreshes
    await make_api_call(token.get())
```

### Encryption

```python
from dspu.security import Fernet, hash_password, verify_password

# Encrypt data
cipher = Fernet.generate()
encrypted = cipher.encrypt(b"sensitive data")
decrypted = cipher.decrypt(encrypted)

# Password hashing
hashed = hash_password("my_password")
is_valid = verify_password("my_password", hashed)  # True
```

## See Also

- [Security Examples](../examples/security.md)
- [Security User Guide](../user-guide/security.md)
