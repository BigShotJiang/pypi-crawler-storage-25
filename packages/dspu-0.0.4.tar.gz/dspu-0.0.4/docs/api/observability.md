# Observability API Reference

Structured logging, rich console output, and tracing utilities.

## Overview

The `dspu.observability` module provides:

- **Structured Logging**: Context-based logging with ContextVar
- **Rich Console Output**: Colors, tables, trees, progress bars
- **Tracing Decorators**: `@timed`, `@traced`, `@logged_errors`
- **Stream Capture**: Redirect stdout/stderr to logger
- **Configuration**: JSON/YAML/HOCON config file support

## Logging

### Configuration

::: dspu.observability.logging.configure_logging
    options:
      show_root_heading: true
      show_source: false

### StructuredLogger

::: dspu.observability.logging.get_logger
    options:
      show_root_heading: true
      show_source: false

::: dspu.observability.logging.StructuredLogger
    options:
      show_root_heading: true
      members:
        - __init__
        - info
        - debug
        - warning
        - error
        - exception

### Context Management

::: dspu.observability.logging.LogContext
    options:
      show_root_heading: true
      show_source: false

::: dspu.observability.logging.bind_context
::: dspu.observability.logging.unbind_context
::: dspu.observability.logging.clear_context

## Decorators

### Timing

::: dspu.observability.decorators.timed
    options:
      show_root_heading: true
      show_source: false

### Tracing

::: dspu.observability.decorators.traced
    options:
      show_root_heading: true
      show_source: false

### Error Logging

::: dspu.observability.decorators.logged_errors
    options:
      show_root_heading: true
      show_source: false

## Rich Output

### Console

::: dspu.observability.rich_output.get_console
::: dspu.observability.rich_output.print_json
::: dspu.observability.rich_output.print_table
::: dspu.observability.rich_output.print_tree
::: dspu.observability.rich_output.print_traceback
::: dspu.observability.rich_output.inspect_object

### Progress

::: dspu.observability.rich_output.Progress
    options:
      show_root_heading: true
      members:
        - add_task
        - update

::: dspu.observability.rich_output.TaskProgress
    options:
      show_root_heading: true
      members:
        - add_task
        - update

## Advanced

### LoggingSetup

::: dspu.observability.setup.LoggingSetup
    options:
      show_root_heading: true
      members:
        - __init__
        - setup
        - setup_with_diversion

### Stream Capture

::: dspu.observability.stream_capture.StreamToLogger
    options:
      show_root_heading: true
      members:
        - __init__
        - subvert
        - restore

## Usage Examples

### Basic Logging

```python
from dspu.observability import configure_logging, get_logger, LogContext

# Configure
configure_logging(level="INFO", format="rich")
logger = get_logger(__name__)

# Log with structured fields
logger.info("User logged in", user_id=123, ip="192.168.1.1")

# Context manager
with LogContext(request_id="req-123"):
    logger.info("Processing request")  # Includes request_id
    logger.info("Query executed", duration_ms=45)
```

### Tracing Decorators

```python
from dspu.observability import timed, traced, logged_errors

@timed()
def slow_operation():
    # Execution time automatically logged
    time.sleep(1)

@traced(log_args=True, log_result=True)
def process_order(order_id, items):
    # Logs entry, args, result, and exit
    return {"status": "success", "order_id": order_id}

@logged_errors(reraise=True)
def risky_operation():
    # Logs errors with traceback
    raise ValueError("Something went wrong")
```

### Rich Output

```python
from dspu.observability import print_json, print_table, Progress

# Pretty JSON
data = {"user": {"name": "Alice", "age": 30}}
print_json(data)

# Table
users = [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]
print_table(users, title="Users")

# Progress bar
with Progress() as progress:
    task = progress.add_task("Processing", total=100)
    for i in range(100):
        time.sleep(0.01)
        progress.update(task, advance=1)
```

## See Also

- [Observability Examples](../examples/observability.md) - Practical examples
- [Observability User Guide](../user-guide/observability.md) - Detailed guide
- [Quick Start](../getting-started/quickstart.md) - Get started quickly
