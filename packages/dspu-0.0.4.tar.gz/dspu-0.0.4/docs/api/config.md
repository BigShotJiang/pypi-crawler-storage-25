# Config API Reference

Multi-source configuration management.

## Config Class

::: dspu.config.config.Config
    options:
      members:
        - from_file
        - from_dict
        - from_env
        - get
        - set
        - merge

## WatchedConfig

::: dspu.config.watched.WatchedConfig
    options:
      members:
        - from_file
        - start_watching
        - stop_watching

## Configuration Sources

::: dspu.config.sources.FileSource
::: dspu.config.sources.EnvSource
::: dspu.config.sources.DictSource

## Usage

```python
from dspu.config import Config, WatchedConfig

# Load from file
config = Config.from_file("config.yaml")
db_host = config.get("database.host")

# Merge from environment
config.merge_from_env(prefix="APP_")

# Watch for changes
watched = WatchedConfig.from_file("config.yaml")
watched.start_watching()
```

## See Also

- [Config Examples](../examples/config.md)
- [Config User Guide](../user-guide/configuration.md)
