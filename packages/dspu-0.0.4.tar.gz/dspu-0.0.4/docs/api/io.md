# I/O API Reference

Storage abstraction and multi-format file operations.

## Storage

::: dspu.io.storage.Storage
    options:
      members:
        - from_uri
        - read
        - write
        - exists
        - list
        - delete
        - read_stream
        - write_stream
        - write_format
        - read_format

## Storage Backends

::: dspu.io.local.LocalBackend
::: dspu.io.cloud.S3Backend
::: dspu.io.cloud.GCSBackend
::: dspu.io.cloud.AzureBackend

## Path Resolution

::: dspu.io.paths.PathResolver
    options:
      members:
        - __init__
        - resolve
        - resolve_all
        - check_path_within

## Usage

```python
from dspu.io import Storage

# Local storage
storage = Storage.from_uri("file:///data")
data = storage.read("file.json")
storage.write("output.json", {"status": "success"})

# S3 storage
s3 = Storage.from_uri("s3://bucket/path")
s3.write("data.json", {"count": 100})

# Multi-format
storage.write_format("config.yaml", {"database": {"host": "localhost"}})
storage.write_format("data.csv", [{"name": "Alice", "age": 30}])
```

## See Also

- [I/O Examples](../examples/io.md)
- [I/O User Guide](../user-guide/io.md)
