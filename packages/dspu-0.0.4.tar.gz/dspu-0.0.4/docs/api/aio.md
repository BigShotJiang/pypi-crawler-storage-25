# Async API Reference

Async utilities for resilient operations.

## Retry

::: dspu.aio.retry.retry
    options:
      show_source: false

## Rate Limiting

::: dspu.aio.rate_limiter.RateLimiter
    options:
      members:
        - __init__
        - acquire
        - try_acquire

## Circuit Breaker

::: dspu.aio.circuit_breaker.CircuitBreaker
    options:
      members:
        - __init__
        - call
        - reset

## Concurrency

::: dspu.aio.concurrency.gather_with_limit
::: dspu.aio.concurrency.run_with_timeout
::: dspu.aio.concurrency.run_with_shield

## Sync/Async Bridge

::: dspu.aio.bridge.sync_to_async
::: dspu.aio.bridge.async_to_sync
::: dspu.aio.bridge.run_async
::: dspu.aio.bridge.iter_over_async

## Usage

```python
from dspu.aio import retry, RateLimiter, CircuitBreaker

@retry(max_attempts=3, backoff="exponential")
async def fetch_data(url):
    async with httpx.AsyncClient() as client:
        return await client.get(url)

async def process_with_rate_limit():
    limiter = RateLimiter(rate=10, per=1.0)
    async with limiter:
        await process_item()

circuit_breaker = CircuitBreaker(failure_threshold=5)

@circuit_breaker
async def call_api():
    ...
```

## See Also

- [Async Examples](../examples/aio.md)
- [Async User Guide](../user-guide/async.md)
