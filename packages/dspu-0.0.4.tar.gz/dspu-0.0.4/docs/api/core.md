# Core API Reference

Foundation protocols, exceptions, and plugin system.

## Protocols

::: dspu.core.protocols.Serializable
::: dspu.core.protocols.AsyncResource
::: dspu.core.protocols.Closeable

## Exceptions

::: dspu.core.exceptions.DSPUError
::: dspu.core.exceptions.ConfigurationError
::: dspu.core.exceptions.ValidationError
::: dspu.core.exceptions.DSPUIOError
::: dspu.core.exceptions.SecurityError

## Plugin Registry

::: dspu.core.registry.Registry
    options:
      members:
        - register
        - get
        - list

## Type Definitions

::: dspu.core.types

## Usage

```python
from dspu.core import Registry, DSPUError

# Plugin registry
registry = Registry()

@registry.register("my_plugin")
class MyPlugin:
    pass

# Get plugin
PluginClass = registry.get("my_plugin")

# Exception handling
try:
    # Your code
    pass
except DSPUError as e:
    print(f"Error: {e}")
```

## See Also

- [Core Examples](../examples/core.md)
- [Core User Guide](../user-guide/core-concepts.md)
