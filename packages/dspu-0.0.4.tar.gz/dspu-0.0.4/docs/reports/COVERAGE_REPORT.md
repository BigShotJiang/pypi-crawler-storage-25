# DSPU Test Coverage Report

**Generated:** 2025-12-06
**Total Coverage:** 83.75%
**Tests Passing:** 994 tests
**Tests Skipped:** 10 tests

---

## Coverage by Module

| Module | Coverage | Status |
|--------|----------|--------|
| **Aio** | 96.94% | ✅ Excellent |
| **Ml** | 92.27% | ✅ Good |
| **Config** | 91.57% | ✅ Good |
| **Validation** | 91.23% | ✅ Good |
| **Observability** | 90.98% | ✅ Good |
| **Core** | 85.42% | 🟨 Good |
| **Io** | 77.45% | 🟨 Good |
| **Security** | 68.57% | 🟨 Acceptable |

---

## Detailed Module Coverage

### Aio Module (`dspu.aio`)

**Overall: 96.94% (5 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `concurrency.py` | 57 | 0 | 8 | 1 | **98.46%** ✅ |
| `rate_limiter.py` | 75 | 2 | 14 | 1 | **96.63%** ✅ |
| `retry.py` | 66 | 1 | 22 | 5 | **93.18%** ✅ |
| `circuit_breaker.py` | 126 | 6 | 44 | 7 | **91.18%** ✅ |
| `bridge.py` | 68 | 3 | 14 | 6 | **89.02%** 🟨 |

### Ml Module (`dspu.ml`)

**Overall: 92.27% (6 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `identifiers.py` | 77 | 2 | 36 | 3 | **95.58%** ✅ |
| `splits.py` | 159 | 8 | 76 | 9 | **92.77%** ✅ |
| `encoding.py` | 155 | 9 | 76 | 15 | **89.61%** 🟨 |
| `random.py` | 127 | 15 | 40 | 2 | **88.62%** 🟨 |
| `stats.py` | 188 | 16 | 62 | 16 | **86.40%** 🟨 |
| `scaling.py` | 187 | 19 | 86 | 12 | **85.71%** 🟨 |

### Config Module (`dspu.config`)

**Overall: 91.57% (4 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `watched.py` | 87 | 3 | 30 | 1 | **96.58%** ✅ |
| `sources.py` | 82 | 5 | 30 | 1 | **94.64%** ✅ |
| `config.py` | 42 | 2 | 8 | 1 | **94.00%** ✅ |
| `vault.py` | 50 | 12 | 12 | 3 | **75.81%** 🟨 |

### Validation Module (`dspu.validation`)

**Overall: 91.23% (2 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `filters.py` | 91 | 0 | 26 | 0 | **100.00%** ✅ |
| `validators.py` | 137 | 20 | 48 | 8 | **83.78%** 🟨 |

### Observability Module (`dspu.observability`)

**Overall: 90.98% (5 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `stream_capture.py` | 52 | 1 | 14 | 2 | **95.45%** ✅ |
| `logging.py` | 129 | 2 | 46 | 8 | **94.29%** ✅ |
| `decorators.py` | 108 | 11 | 30 | 8 | **86.23%** 🟨 |
| `rich_output.py` | 112 | 18 | 24 | 3 | **84.56%** 🟨 |
| `setup.py` | 109 | 14 | 40 | 8 | **83.89%** 🟨 |

### Core Module (`dspu.core`)

**Overall: 85.42% (4 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `exceptions.py` | 53 | 0 | 18 | 0 | **100.00%** ✅ |
| `protocols.py` | 1 | 0 | 0 | 0 | **100.00%** ✅ |
| `registry.py` | 31 | 3 | 6 | 0 | **91.89%** ✅ |
| `types.py` | 11 | 11 | 0 | 0 | **0.00%** ⚠️ |

### Io Module (`dspu.io`)

**Overall: 77.45% (11 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `backends.py` | 16 | 0 | 2 | 0 | **100.00%** ✅ |
| `paths.py` | 49 | 0 | 16 | 0 | **100.00%** ✅ |
| `formats/tabular.py` | 52 | 3 | 12 | 0 | **95.31%** ✅ |
| `formats/base.py` | 15 | 0 | 4 | 1 | **94.74%** ✅ |
| `formats/text.py` | 95 | 6 | 26 | 1 | **94.21%** ✅ |
| `formats/registry.py` | 80 | 4 | 38 | 4 | **93.22%** ✅ |
| `serializers.py` | 106 | 12 | 20 | 3 | **88.10%** 🟨 |
| `local.py` | 83 | 14 | 12 | 0 | **85.26%** 🟨 |
| `storage.py` | 79 | 18 | 18 | 3 | **78.35%** 🟨 |
| `formats/structured.py` | 151 | 30 | 24 | 8 | **78.29%** 🟨 |
| `cloud.py` | 99 | 99 | 16 | 0 | **0.00%** ⚠️ |

### Security Module (`dspu.security`)

**Overall: 68.57% (7 files)**

| File | Statements | Missing | Branches | Partial | Coverage |
|------|-----------|---------|----------|---------|----------|
| `protocols.py` | 1 | 0 | 0 | 0 | **100.00%** ✅ |
| `encryption.py` | 88 | 10 | 12 | 0 | **90.00%** ✅ |
| `rotating_token.py` | 94 | 15 | 22 | 3 | **82.76%** 🟨 |
| `exceptions.py` | 36 | 7 | 8 | 2 | **75.00%** 🟨 |
| `secrets.py` | 75 | 25 | 6 | 2 | **66.67%** ⚠️ |
| `backends.py` | 253 | 103 | 68 | 8 | **59.19%** ⚠️ |
| `auth.py` | 137 | 55 | 44 | 5 | **56.91%** ⚠️ |

---

## Test Statistics

- **Total Tests:** 1004 (994 passed, 10 skipped)
- **Success Rate:** 99.0%
- **Total Statements:** 3,889
- **Covered Statements:** 3,305
- **Missing Statements:** 584
- **Total Branches:** 1,158
- **Covered Branches:** 922

---

**Last Updated:** 2025-12-06 06:37:17
