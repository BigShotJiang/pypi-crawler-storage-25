# MkDocs Deployment Guide

This guide explains how to deploy DSPU documentation to GitHub Pages.

## Prerequisites

1. **GitHub Repository**: Repository at `deepsaia/dspu`
2. **GitHub Pages Enabled**: Must be enabled in repository settings
3. **Python 3.11+**: For local development

## Local Development

### Install Dependencies

```bash
# Install all dependencies including docs
uv sync --all-extras

# Or install just docs dependencies
uv sync --group docs
```

### Serve Documentation Locally

```bash
# Start local server
uv run mkdocs serve

# Server runs at http://127.0.0.1:8000
# Changes auto-reload
```

### Build Documentation

```bash
# Build static site
uv run mkdocs build

# Output in ./site directory

# Build with strict mode (fails on warnings)
uv run mkdocs build --strict
```

## GitHub Pages Deployment

### Setup (One-time)

1. **Enable GitHub Pages**:
   - Go to repository settings
   - Navigate to "Pages" section
   - Source: "GitHub Actions"

2. **Configure Repository Secrets** (if using analytics):
   - Go to repository settings
   - Navigate to "Secrets and variables" → "Actions"
   - Add any required secrets

### Automatic Deployment

Documentation automatically deploys on push to `main` branch:

```bash
git add .
git commit -m "docs: update documentation"
git push origin main
```

The GitHub Actions workflow (`.github/workflows/deploy-docs.yml`) will:
1. Checkout code with full history
2. Install Python and uv
3. Install all dependencies
4. Build MkDocs site
5. Deploy to GitHub Pages

### Manual Deployment

Trigger manual deployment:

1. Go to Actions tab
2. Select "Deploy MkDocs to GitHub Pages"
3. Click "Run workflow"
4. Select branch and click "Run workflow"

## Viewing Documentation

After deployment completes:

- **Production URL**: https://deepsaia.github.io/dspu
- **Check deployment status**: Actions tab in GitHub

## Features

### Material Theme

- Dark/light mode toggle
- Instant navigation
- Search with suggestions
- Tabbed navigation
- Code copy buttons
- Responsive design

### Plugins

#### git-revision-date-localized
Shows "Last updated" date on pages based on git history.

#### git-authors
Shows contributors for each page.

#### mkdocstrings
Auto-generates API documentation from Python docstrings.

### Feedback System

Users can provide feedback on each page:
- Happy/sad face buttons
- Stores feedback in console log
- Links to GitHub issues for detailed feedback

### Progress Tracking

Checkboxes in documentation persist state in localStorage.

### Math Support

LaTeX math rendering with MathJax:

Inline: `\(x^2 + y^2 = z^2\)`
Display: `\[E = mc^2\]`

## Configuration

### Site Configuration

Edit `mkdocs.yml`:

```yaml
site_name: DSPU Documentation
site_url: https://deepsaia.github.io/dspu
repo_url: https://github.com/deepsaia/dspu
```

### Theme Customization

Colors and fonts in `mkdocs.yml`:

```yaml
theme:
  palette:
    primary: indigo
    accent: indigo
  font:
    text: Roboto
    code: Roboto Mono
```

### Custom CSS/JS

- CSS: `docs/stylesheets/extra.css`
- JavaScript: `docs/javascripts/*.js`

## Navigation Structure

```
docs/
├── index.md                    # Home
├── getting-started/
│   ├── installation.md
│   ├── quickstart.md
│   └── tutorial.md
├── user-guide/
│   ├── core-concepts.md
│   ├── configuration.md
│   └── ...
├── api/
│   ├── core.md
│   ├── config.md
│   └── ...
├── examples/
│   ├── index.md
│   └── ...
├── contributing/
│   ├── development.md
│   └── ...
└── about/
    ├── changelog.md
    └── license.md
```

## Troubleshooting

### Build Fails

```bash
# Check for errors
uv run mkdocs build --strict

# Common issues:
# - Missing files in nav
# - Broken internal links
# - Invalid YAML in mkdocs.yml
```

### Plugin Errors

```bash
# Check plugin installation
uv pip list | grep mkdocs

# Reinstall plugins
uv sync --group docs
```

### GitHub Actions Fails

1. Check Actions tab for error logs
2. Verify `uv.lock` is committed
3. Ensure all dependencies are in `pyproject.toml`
4. Check repository permissions

### Pages Not Updating

1. Clear browser cache
2. Check deployment status in Actions
3. Verify GitHub Pages is enabled
4. Check Pages settings for correct source

## Advanced Features

### Version Management (mike)

```bash
# Deploy version
uv run mike deploy 1.0 latest --update-aliases

# List versions
uv run mike list

# Set default version
uv run mike set-default latest
```

### Custom Domain

1. Add CNAME file: `docs/CNAME`
2. Configure DNS records
3. Enable HTTPS in GitHub Pages settings

### Analytics Integration

Add Google Analytics in `mkdocs.yml`:

```yaml
extra:
  analytics:
    provider: google
    property: G-XXXXXXXXXX
```

## Resources

- [MkDocs Documentation](https://www.mkdocs.org/)
- [Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)
- [mkdocstrings](https://mkdocstrings.github.io/)
- [GitHub Pages Documentation](https://docs.github.com/en/pages)

## Support

For issues:
- Documentation bugs: [Open issue](https://github.com/deepsaia/dspu/issues/new)
- Deployment problems: Check Actions logs
- General questions: GitHub Discussions
