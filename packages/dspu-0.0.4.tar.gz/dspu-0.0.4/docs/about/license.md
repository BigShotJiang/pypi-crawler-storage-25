# License

DSPU is released under the MIT License.

## MIT License

```
MIT License

Copyright (c) 2024 DSPU Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## What This Means

### You Can

✅ **Use** - Use DSPU in personal or commercial projects
✅ **Modify** - Modify the source code
✅ **Distribute** - Distribute copies of DSPU
✅ **Sublicense** - Include in proprietary software
✅ **Private Use** - Use privately without publishing

### You Must

📋 **Include License** - Include the license and copyright notice in distributions
📋 **Preserve Copyright** - Preserve the copyright notice

### You Cannot

❌ **Hold Liable** - Hold the authors liable for damages
❌ **Use Trademark** - Use the project's trademarks without permission

## Third-Party Licenses

DSPU depends on several open-source libraries:

### Core Dependencies

- **Pydantic**: MIT License
- **PyYAML**: MIT License
- **HTTPX**: BSD 3-Clause License

### Optional Dependencies

#### Configuration
- **pyhocon**: Apache License 2.0
- **python-dotenv**: BSD 3-Clause License

#### I/O
- **boto3** (AWS): Apache License 2.0
- **google-cloud-storage**: Apache License 2.0
- **azure-storage-blob**: MIT License

#### Security
- **cryptography**: Apache License 2.0 and BSD License
- **PyJWT**: MIT License
- **hvac** (Vault): Apache License 2.0

#### Observability
- **rich**: MIT License

All dependencies are compatible with the MIT License.

## Contributing

By contributing to DSPU, you agree that your contributions will be licensed under the MIT License.

See [Contributing Guide](../contributing/development.md) for details.

## Questions

For licensing questions, contact the maintainers via:
- GitHub Issues: [dspu/issues](https://github.com/yourorg/dspu/issues)
- Email: maintainers@dspu.org
