# DSPU

Modern data science utilities library with type safety, extensibility, and async-first design.

## Features

- Type-Safe: Full type hints with runtime validation using Pydantic
- Async-First: Modern async APIs with sync wrappers when needed
- Extensible: Plugin architecture for easy customization
- Zero Bloat: Minimal dependencies, optional extras for features
- Fast: Built with UV, 10-100x faster package management
- Batteries Included: Config, I/O, async utils, security, ML, observability

## Installation

```bash
# Install core package
uv pip install dspu

# Install with extras
uv pip install dspu[io,async,security]

# Install everything
uv pip install dspu[all]
```

## Quick Start

```python
from pydantic import BaseModel
from dspu.config import Config, ConfigSource
from dspu.io import Storage
from dspu.observability import get_logger

# Type-safe configuration
class AppConfig(BaseModel):
    database_url: str
    max_workers: int = 4

config = Config.load(
    AppConfig,
    sources=[
        ConfigSource.file("config.yaml"),
        ConfigSource.env(prefix="APP_"),
    ]
)

# Unified storage interface
storage = Storage.from_uri("s3://my-bucket/data")
data = await storage.read("file.json")

# Structured logging
logger = get_logger(__name__)
logger.info("processing_started", count=len(data))
```

## Development

```bash
# Clone and setup
git clone https://github.com/yourorg/dspu
cd dspu
uv sync --all-extras

# Run tests
uv run pytest

# Run linting
uv run ruff check .

# Type check
uv run pyrefly check src/dspu
```

## Documentation

- [Design Document](docs/design.md)
- [Implementation Plan](docs/plan.md)

## Requirements

- Python 3.11+
- UV (recommended) or pip

## Status

Current Version: 0.1.0 (Alpha)
