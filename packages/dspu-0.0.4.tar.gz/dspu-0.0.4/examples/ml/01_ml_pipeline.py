"""Example: Complete ML Pipeline with dspu.

This example demonstrates a full ML pipeline:
1. Set up reproducibility
2. Generate/load data
3. Split data (train/val/test)
4. Encode categorical features
5. Scale numeric features
6. Save artifacts for production
"""

from dspu.ml import (
    DataSplitter,
    Encoder,
    IDGenerator,
    Scaler,
    SeedManager,
    make_classification_data,
)


def example_1_basic_pipeline():
    """Example 1: Basic end-to-end pipeline."""
    print("\n=== Example 1: Basic ML Pipeline ===\n")

    # Step 1: Set up reproducibility
    SeedManager.set_global_seed(42)
    print("✓ Set global seed to 42 for reproducibility")

    # Step 2: Generate synthetic data
    X, y = make_classification_data(n_samples=1000, n_features=10, n_classes=2, random_state=42)
    print(f"✓ Generated {len(X)} samples with {len(X[0])} features")

    # Step 3: Split data into train/val/test
    X_train, X_val, X_test, y_train, y_val, y_test = DataSplitter.train_val_test_split(
        X, y, test_size=0.2, val_size=0.1, random_state=42
    )
    print(f"✓ Split data: train={len(X_train)}, val={len(X_val)}, test={len(X_test)}")

    # Step 4: Fit scaler on training data
    scaler = Scaler(method="standard")
    X_train_scaled = scaler.fit_transform(X_train)
    print("✓ Fitted standard scaler on training data")

    # Step 5: Transform validation and test data
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)
    print("✓ Transformed validation and test data")

    # Step 6: Save scaler for production
    scaler.save_to_file("scaler.json")
    print("✓ Saved scaler to 'scaler.json'")

    print("\n📊 Pipeline Summary:")
    print(f"   - Total samples: {len(X)}")
    print(f"   - Train samples: {len(X_train)} ({len(X_train) / len(X) * 100:.1f}%)")
    print(f"   - Val samples: {len(X_val)} ({len(X_val) / len(X) * 100:.1f}%)")
    print(f"   - Test samples: {len(X_test)} ({len(X_test) / len(X) * 100:.1f}%)")


def example_2_categorical_encoding():
    """Example 2: Working with categorical features."""
    print("\n=== Example 2: Categorical Encoding ===\n")

    # Simulate dataset with categorical features
    data = [
        {"age": 25, "city": "NYC", "occupation": "Engineer"},
        {"age": 30, "city": "SF", "occupation": "Designer"},
        {"age": 35, "city": "NYC", "occupation": "Manager"},
        {"age": 28, "city": "LA", "occupation": "Engineer"},
        {"age": 32, "city": "SF", "occupation": "Engineer"},
    ]

    # Add IDs to dataset
    IDGenerator.add_id_column(data, id_col="id", method="sequential")
    print(f"✓ Added IDs to {len(data)} rows")

    # Extract categorical features
    cities = [row["city"] for row in data]
    occupations = [row["occupation"] for row in data]

    # Encode cities with label encoding
    city_encoder = Encoder(method="label")
    cities_encoded = city_encoder.fit_transform(cities)
    print(f"✓ Encoded cities: {dict(zip(cities, cities_encoded))}")

    # Encode occupations with one-hot encoding
    occupation_encoder = Encoder(method="onehot")
    occupations_encoded = occupation_encoder.fit_transform(occupations)
    feature_names = occupation_encoder.get_feature_names("occ")
    print(f"✓ One-hot encoded occupations: {feature_names}")

    # Save encoders
    city_encoder.save_to_file("city_encoder.json")
    occupation_encoder.save_to_file("occupation_encoder.json")
    print("✓ Saved encoders for production")

    # Production: Load and use encoders
    loaded_city_encoder = Encoder.load_from_file("city_encoder.json")
    new_cities = ["NYC", "SF"]
    encoded = loaded_city_encoder.transform(new_cities)
    print(f"\n📊 Production inference: {new_cities} → {encoded}")


def example_3_stratified_cv():
    """Example 3: Stratified K-fold cross-validation."""
    print("\n=== Example 3: Stratified K-Fold CV ===\n")

    # Generate imbalanced dataset (30% class 0, 70% class 1)
    X = list(range(100))
    y = [0] * 30 + [1] * 70

    print(f"Dataset: {len(X)} samples, class distribution: 30% class 0, 70% class 1")

    # Perform stratified 5-fold CV
    folds = DataSplitter.stratified_kfold(y, n_splits=5, random_state=42)
    print(f"\n✓ Created {len(folds)} stratified folds\n")

    # Verify class distribution in each fold
    for i, (train_idx, val_idx) in enumerate(folds, 1):
        train_labels = [y[idx] for idx in train_idx]
        val_labels = [y[idx] for idx in val_idx]

        train_ratio = train_labels.count(0) / len(train_labels) * 100
        val_ratio = val_labels.count(0) / len(val_labels) * 100

        print(f"Fold {i}:")
        print(f"  Train: {len(train_idx)} samples, {train_ratio:.1f}% class 0")
        print(f"  Val:   {len(val_idx)} samples, {val_ratio:.1f}% class 0")

    print("\n✓ All folds maintain class distribution!")


def example_4_time_series_split():
    """Example 4: Time series cross-validation."""
    print("\n=== Example 4: Time Series Split ===\n")

    # Simulate time series data
    dates = [f"2024-{i // 30 + 1:02d}-{i % 30 + 1:02d}" for i in range(365)]
    values = list(range(365))

    print(f"Time series: {len(dates)} days of data")

    # Split for temporal validation (no future leakage)
    splits = DataSplitter.time_series_split(values, n_splits=4)
    print(f"\n✓ Created {len(splits)} time series splits\n")

    for i, (train_idx, val_idx) in enumerate(splits, 1):
        train_start = dates[train_idx[0]]
        train_end = dates[train_idx[-1]]
        val_start = dates[val_idx[0]]
        val_end = dates[val_idx[-1]]

        print(f"Split {i}:")
        print(f"  Train: {train_start} to {train_end} ({len(train_idx)} days)")
        print(f"  Val:   {val_start} to {val_end} ({len(val_idx)} days)")
        print("  ✓ No future leakage: max(train) < min(val)")

    print("\n✓ Perfect for time series model validation!")


def example_5_group_split():
    """Example 5: Group split to prevent leakage."""
    print("\n=== Example 5: Group Split (No Leakage) ===\n")

    # Simulate patient medical data (multiple visits per patient)
    data = []
    patients = ["Alice", "Bob", "Charlie", "David"]
    for patient in patients:
        for visit in range(3):
            data.append(
                {
                    "patient": patient,
                    "visit": visit + 1,
                    "measurement": visit * 10 + hash(patient) % 20,
                }
            )

    X = [row["measurement"] for row in data]
    groups = [row["patient"] for row in data]

    print(f"Medical data: {len(data)} visits from {len(set(groups))} patients")
    print("Each patient has 3 visits")

    # Split by patients (not by visits) to prevent leakage
    X_train, X_test, _, _ = DataSplitter.group_split(X, groups, test_size=0.25, random_state=42)

    # Check which patients are in each set
    train_patients = set()
    test_patients = set()

    for idx in range(len(X)):
        if X[idx] in X_train:
            train_patients.add(groups[idx])
        elif X[idx] in X_test:
            test_patients.add(groups[idx])

    print(f"\n✓ Train patients: {sorted(train_patients)}")
    print(f"✓ Test patients: {sorted(test_patients)}")
    print(f"✓ No overlap: {len(train_patients & test_patients) == 0}")
    print("\n✓ All visits from same patient stay together!")


def example_6_production_pipeline():
    """Example 6: Save and load complete pipeline."""
    print("\n=== Example 6: Production Pipeline ===\n")

    print("Training phase:")
    print("-" * 50)

    # Generate and split data
    X, y = make_classification_data(n_samples=100, n_features=5, random_state=42)
    X_train, X_test, y_train, y_test = DataSplitter.train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Fit and save scaler
    scaler = Scaler(method="minmax", feature_range=(0, 1))
    X_train_scaled = scaler.fit_transform(X_train)
    scaler.save_to_file("production_scaler.json")
    print("✓ Trained and saved scaler")

    # Fit and save encoder (simulate categorical labels)
    label_names = ["ClassA", "ClassB"]
    y_train_categorical = [label_names[label] for label in y_train]
    y_encoder = Encoder(method="label")
    y_train_encoded = y_encoder.fit_transform(y_train_categorical)
    y_encoder.save_to_file("production_encoder.json")
    print("✓ Trained and saved label encoder")

    print("\nProduction inference:")
    print("-" * 50)

    # Load artifacts
    scaler = Scaler.load_from_file("production_scaler.json")
    y_encoder = Encoder.load_from_file("production_encoder.json")
    print("✓ Loaded scaler and encoder")

    # Transform new data
    X_test_scaled = scaler.transform(X_test)
    print(f"✓ Scaled {len(X_test)} test samples")

    # Decode predictions (simulate)
    y_test_categorical = [label_names[label] for label in y_test[:5]]
    y_test_encoded = y_encoder.transform(y_test_categorical)
    y_test_decoded = y_encoder.inverse_transform(y_test_encoded)

    print("\n📊 Sample predictions:")
    for orig, enc, dec in zip(y_test_categorical[:3], y_test_encoded[:3], y_test_decoded[:3]):
        print(f"   {orig} → {enc} → {dec}")


def main():
    """Run all examples."""
    examples = [
        example_1_basic_pipeline,
        example_2_categorical_encoding,
        example_3_stratified_cv,
        example_4_time_series_split,
        example_5_group_split,
        example_6_production_pipeline,
    ]

    for example in examples:
        try:
            example()
            print()
        except Exception as e:
            print(f"\n❌ Error in {example.__name__}: {e}\n")


if __name__ == "__main__":
    main()
