"""Example: Reproducibility and Statistical Analysis.

This example demonstrates:
1. Seed management for reproducibility
2. Synthetic data generation
3. Statistical analysis (correlation, hypothesis tests)
4. Bootstrap confidence intervals
5. A/B testing
6. Outlier detection
"""

from dspu.ml import (
    SeedManager,
    Stats,
    make_classification_data,
    make_regression_data,
    make_time_series,
)


def example_1_reproducibility():
    """Example 1: Reproducible experiments."""
    print("\n=== Example 1: Reproducibility ===\n")

    # Set global seed
    SeedManager.set_global_seed(42)
    print("✓ Set global seed to 42")

    # Generate data twice with same seed
    X1, y1 = make_classification_data(n_samples=10, random_state=42)
    X2, y2 = make_classification_data(n_samples=10, random_state=42)

    print(f"✓ Data 1: {y1[:5]}")
    print(f"✓ Data 2: {y2[:5]}")
    print(f"✓ Identical: {y1 == y2}")

    # Use seed context for temporary seed
    with SeedManager.seed_context(123):
        X3, y3 = make_classification_data(n_samples=10, random_state=123)
        print(f"\n✓ Different seed: {y3[:5]}")

    # Back to original seed
    X4, y4 = make_classification_data(n_samples=10, random_state=42)
    print(f"✓ Back to seed 42: {y4[:5]}")
    print(f"✓ Matches original: {y1 == y4}")


def example_2_synthetic_data():
    """Example 2: Generating synthetic datasets."""
    print("\n=== Example 2: Synthetic Data Generation ===\n")

    # Classification data
    X_clf, y_clf = make_classification_data(
        n_samples=100,
        n_features=5,
        n_classes=3,
        n_informative=3,
        noise=0.1,
        random_state=42,
    )
    print(
        f"✓ Classification: {len(X_clf)} samples, {len(X_clf[0])} features, {max(y_clf) + 1} classes"
    )

    class_counts = {i: y_clf.count(i) for i in range(max(y_clf) + 1)}
    print(f"  Class distribution: {class_counts}")

    # Regression data
    X_reg, y_reg = make_regression_data(
        n_samples=100, n_features=5, n_informative=3, noise=0.1, random_state=42
    )
    print(f"\n✓ Regression: {len(X_reg)} samples, {len(X_reg[0])} features")
    print(f"  Target range: [{min(y_reg):.2f}, {max(y_reg):.2f}]")

    # Time series data
    ts_trend = make_time_series(
        length=100, pattern="trend", trend_slope=0.1, noise=0.05, random_state=42
    )
    print(f"\n✓ Time series (trend): {len(ts_trend)} points")
    print(f"  First 5: {[f'{x:.2f}' for x in ts_trend[:5]]}")
    print(f"  Last 5:  {[f'{x:.2f}' for x in ts_trend[-5:]]}")

    ts_seasonal = make_time_series(
        length=100,
        pattern="seasonality",
        seasonality_period=12,
        noise=0.1,
        random_state=42,
    )
    print(f"\n✓ Time series (seasonal): {len(ts_seasonal)} points")
    print("  Period: 12, values oscillate around 0")


def example_3_correlation_analysis():
    """Example 3: Correlation analysis."""
    print("\n=== Example 3: Correlation Analysis ===\n")

    # Generate correlated data
    X, _ = make_regression_data(n_samples=100, n_features=5, random_state=42)

    # Extract two features
    feature_0 = [row[0] for row in X]
    feature_1 = [row[1] for row in X]

    # Compute correlations
    pearson = Stats.correlation(feature_0, feature_1, method="pearson")
    spearman = Stats.correlation(feature_0, feature_1, method="spearman")
    kendall = Stats.correlation(feature_0, feature_1, method="kendall")

    print("Correlation between feature 0 and feature 1:")
    print(f"  Pearson:  {pearson:.3f}")
    print(f"  Spearman: {spearman:.3f}")
    print(f"  Kendall:  {kendall:.3f}")

    # Create perfectly correlated data
    x = [1, 2, 3, 4, 5]
    y = [2, 4, 6, 8, 10]  # y = 2*x

    perfect_corr = Stats.correlation(x, y, method="pearson")
    print(f"\n✓ Perfect linear correlation: {perfect_corr:.3f}")


def example_4_hypothesis_testing():
    """Example 4: Hypothesis testing."""
    print("\n=== Example 4: Hypothesis Testing ===\n")

    # Generate two samples
    sample1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    sample2 = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

    print(f"Sample 1 mean: {Stats.mean(sample1):.2f}")
    print(f"Sample 2 mean: {Stats.mean(sample2):.2f}")

    # T-test
    t_stat, p_value = Stats.t_test_independent(sample1, sample2)

    print("\nT-test results:")
    print(f"  t-statistic: {t_stat:.3f}")
    print(f"  p-value: {p_value:.3f}")

    if p_value < 0.05:
        print("  ✓ Significant difference (p < 0.05)")
    else:
        print("  ✗ No significant difference (p >= 0.05)")


def example_5_bootstrap_ci():
    """Example 5: Bootstrap confidence intervals."""
    print("\n=== Example 5: Bootstrap Confidence Intervals ===\n")

    # Generate sample data
    data = [10, 12, 11, 13, 12, 14, 13, 15, 14, 16]

    # Bootstrap CI for mean
    estimate, lower, upper = Stats.bootstrap_ci(
        data, stat_fn=Stats.mean, n_bootstrap=1000, confidence_level=0.95, random_state=42
    )

    print(f"Data: {data}")
    print(f"\nMean estimate: {estimate:.2f}")
    print(f"95% CI: [{lower:.2f}, {upper:.2f}]")

    # Bootstrap CI for median
    estimate_med, lower_med, upper_med = Stats.bootstrap_ci(
        data, stat_fn=Stats.median, n_bootstrap=1000, confidence_level=0.95, random_state=42
    )

    print(f"\nMedian estimate: {estimate_med:.2f}")
    print(f"95% CI: [{lower_med:.2f}, {upper_med:.2f}]")


def example_6_ab_testing():
    """Example 6: A/B testing with uplift calculation."""
    print("\n=== Example 6: A/B Testing ===\n")

    # Simulate A/B test data
    # Group A (control): conversion rate ~10%
    group_a = [0.08, 0.10, 0.09, 0.11, 0.10, 0.12, 0.09, 0.10, 0.11, 0.10]

    # Group B (treatment): conversion rate ~15% (50% uplift)
    group_b = [0.14, 0.16, 0.15, 0.17, 0.15, 0.18, 0.14, 0.15, 0.16, 0.15]

    result = Stats.ab_test_uplift(
        group_a, group_b, metric_fn=Stats.mean, n_bootstrap=1000, random_state=42
    )

    print("A/B Test Results:")
    print(f"  Group A (control): {result['a_mean']:.3f}")
    print(f"  Group B (treatment): {result['b_mean']:.3f}")
    print(f"\n  Absolute uplift: {result['absolute_uplift']:.3f}")
    print(f"  Relative uplift: {result['relative_uplift'] * 100:.1f}%")
    print(
        f"\n  95% CI for uplift: [{result['uplift_ci_lower']:.3f}, {result['uplift_ci_upper']:.3f}]"
    )

    if result["uplift_ci_lower"] > 0:
        print("\n  ✓ Statistically significant improvement!")
    else:
        print("\n  ✗ Not statistically significant")


def example_7_outlier_detection():
    """Example 7: Outlier detection."""
    print("\n=== Example 7: Outlier Detection ===\n")

    # Data with outliers
    data = [10, 12, 11, 13, 12, 14, 13, 15, 14, 100, 16, -50]

    print(f"Data: {data}")
    print(f"Mean: {Stats.mean(data):.2f}")
    print(f"Median: {Stats.median(data):.2f}")

    # IQR method
    outliers_iqr = Stats.detect_outliers(data, method="iqr", threshold=1.5)
    outlier_values_iqr = [data[i] for i in outliers_iqr]
    print(f"\n✓ IQR method outliers (indices {outliers_iqr}): {outlier_values_iqr}")

    # Z-score method
    outliers_zscore = Stats.detect_outliers(data, method="zscore", threshold=2.0)
    outlier_values_zscore = [data[i] for i in outliers_zscore]
    print(f"✓ Z-score method outliers (indices {outliers_zscore}): {outlier_values_zscore}")

    # Clean data by removing outliers
    clean_data = [val for i, val in enumerate(data) if i not in outliers_iqr]
    print(f"\n✓ Clean data: {clean_data}")
    print(f"  Clean mean: {Stats.mean(clean_data):.2f}")
    print(f"  Clean median: {Stats.median(clean_data):.2f}")


def example_8_descriptive_stats():
    """Example 8: Descriptive statistics."""
    print("\n=== Example 8: Descriptive Statistics ===\n")

    # Generate sample data
    data = [12, 15, 14, 10, 13, 18, 16, 11, 14, 15, 17, 13, 12, 16, 14]

    print(f"Data: {data}")
    print(f"N = {len(data)}")

    # Compute statistics
    mean = Stats.mean(data)
    median = Stats.median(data)
    std_pop = Stats.std(data, ddof=0)
    std_sample = Stats.std(data, ddof=1)

    print("\n📊 Summary Statistics:")
    print(f"  Mean:              {mean:.2f}")
    print(f"  Median:            {median:.2f}")
    print(f"  Std Dev (pop):     {std_pop:.2f}")
    print(f"  Std Dev (sample):  {std_sample:.2f}")
    print(f"  Min:               {min(data)}")
    print(f"  Max:               {max(data)}")
    print(f"  Range:             {max(data) - min(data)}")


def main():
    """Run all examples."""
    examples = [
        example_1_reproducibility,
        example_2_synthetic_data,
        example_3_correlation_analysis,
        example_4_hypothesis_testing,
        example_5_bootstrap_ci,
        example_6_ab_testing,
        example_7_outlier_detection,
        example_8_descriptive_stats,
    ]

    for example in examples:
        try:
            example()
            print()
        except Exception as e:
            print(f"\n❌ Error in {example.__name__}: {e}\n")


if __name__ == "__main__":
    main()
