"""Basic validation examples with dspu filters.

This example demonstrates basic usage of filters, filter chains, and decorators
for data validation and transformation.
"""

from dspu.validation import (
    EmailNormalizationFilter,
    FilterChain,
    LowercaseFilter,
    RemoveSpecialCharsFilter,
    SlugifyFilter,
    StripWhitespaceFilter,
    TruncateFilter,
    UppercaseFilter,
    validate,
    validate_field,
)


def example_basic_filters():
    """Demonstrate basic filter usage."""
    print("\n" + "=" * 70)
    print("Basic Filter Usage")
    print("=" * 70)

    # Example 1: Strip whitespace
    print("\n1. Strip Whitespace:")
    strip = StripWhitespaceFilter()
    print("   Input:  '  hello world  '")
    print(f"   Output: '{strip('  hello world  ')}'")

    # Example 2: Lowercase
    print("\n2. Lowercase:")
    lower = LowercaseFilter()
    print("   Input:  'HELLO WORLD'")
    print(f"   Output: '{lower('HELLO WORLD')}'")

    # Example 3: Truncate
    print("\n3. Truncate:")
    truncate = TruncateFilter(max_length=10)
    print("   Input:  'Hello World, this is a long string'")
    print(f"   Output: '{truncate('Hello World, this is a long string')}'")

    # Example 4: Truncate with suffix
    print("\n4. Truncate with Suffix:")
    truncate_suffix = TruncateFilter(max_length=15, suffix="...")
    print("   Input:  'Hello World, this is a long string'")
    print(f"   Output: '{truncate_suffix('Hello World, this is a long string')}'")

    # Example 5: Remove special characters
    print("\n5. Remove Special Characters:")
    remove_special = RemoveSpecialCharsFilter()
    print("   Input:  'hello@world!#$%'")
    print(f"   Output: '{remove_special('hello@world!#$%')}'")

    # Example 6: Email normalization
    print("\n6. Email Normalization:")
    email_filter = EmailNormalizationFilter()
    print("   Input:  'John.Doe+spam@Gmail.COM'")
    print(f"   Output: '{email_filter('John.Doe+spam@Gmail.COM')}'")

    # Example 7: Slugify
    print("\n7. Slugify:")
    slug = SlugifyFilter()
    print("   Input:  'Hello World! How are you?'")
    print(f"   Output: '{slug('Hello World! How are you?')}'")


def example_filter_chains():
    """Demonstrate filter chain composition."""
    print("\n" + "=" * 70)
    print("Filter Chain Composition")
    print("=" * 70)

    # Example 1: Clean and normalize email
    print("\n1. Email Cleaning Pipeline:")
    email_chain = FilterChain(
        [
            StripWhitespaceFilter(),
            EmailNormalizationFilter(),
        ]
    )
    input_email = "  John.Doe+test@GMAIL.COM  "
    print(f"   Input:  '{input_email}'")
    print(f"   Output: '{email_chain(input_email)}'")

    # Example 2: Username sanitization
    print("\n2. Username Sanitization:")
    username_chain = FilterChain(
        [
            StripWhitespaceFilter(),
            LowercaseFilter(),
            RemoveSpecialCharsFilter(allowed_chars={"_", "-"}),
            TruncateFilter(max_length=20),
        ]
    )
    input_username = "  John@Doe#123!  "
    print(f"   Input:  '{input_username}'")
    print(f"   Output: '{username_chain(input_username)}'")

    # Example 3: Title to slug
    print("\n3. Title to Slug Conversion:")
    title_chain = FilterChain(
        [
            StripWhitespaceFilter(),
            SlugifyFilter(),
        ]
    )
    input_title = "  Hello World! How are you?  "
    print(f"   Input:  '{input_title}'")
    print(f"   Output: '{title_chain(input_title)}'")

    # Example 4: Using then() method for chaining
    print("\n4. Chaining with then():")
    chain = StripWhitespaceFilter().then(LowercaseFilter()).then(TruncateFilter(max_length=15))
    input_text = "  HELLO WORLD FROM DS-UTILS  "
    print(f"   Input:  '{input_text}'")
    print(f"   Output: '{chain(input_text)}'")


def example_validate_field_decorator():
    """Demonstrate @validate_field decorator."""
    print("\n" + "=" * 70)
    print("@validate_field Decorator")
    print("=" * 70)

    # Example 1: Simple field validation
    print("\n1. Simple Field Validation:")

    @validate_field(StripWhitespaceFilter(), LowercaseFilter())
    def process_email(email: str) -> str:
        return f"Processing: {email}"

    input_email = "  USER@EXAMPLE.COM  "
    print(f"   Input:  '{input_email}'")
    print(f"   Result: {process_email(input_email)}")

    # Example 2: Specific field validation
    print("\n2. Validating Specific Field:")

    @validate_field(EmailNormalizationFilter(), field_name="email")
    def create_user(name: str, email: str) -> dict:
        return {"name": name, "email": email}

    print("   Input:  name='John', email='John.Doe@GMAIL.COM'")
    result = create_user("John", "John.Doe@GMAIL.COM")
    print(f"   Result: {result}")

    # Example 3: With filter chain
    print("\n3. With Filter Chain:")

    @validate_field(
        FilterChain(
            [
                StripWhitespaceFilter(),
                SlugifyFilter(),
            ]
        )
    )
    def create_slug(title: str) -> str:
        return title

    input_title = "  Hello World!  "
    print(f"   Input:  '{input_title}'")
    print(f"   Output: '{create_slug(input_title)}'")


def example_validate_decorator():
    """Demonstrate @validate decorator for multiple fields."""
    print("\n" + "=" * 70)
    print("@validate Decorator")
    print("=" * 70)

    # Example 1: Multiple input filters
    print("\n1. Multiple Input Filters:")

    @validate(
        input_filters={
            "email": EmailNormalizationFilter(),
            "username": FilterChain(
                [
                    StripWhitespaceFilter(),
                    LowercaseFilter(),
                    RemoveSpecialCharsFilter(allowed_chars={"_", "-"}),
                ]
            ),
            "bio": TruncateFilter(max_length=100),
        }
    )
    def create_user_profile(email: str, username: str, bio: str) -> dict:
        return {
            "email": email,
            "username": username,
            "bio": bio,
        }

    print("   Input:")
    print("     email='John.Doe@GMAIL.COM'")
    print("     username='  John@Doe#123  '")
    print("     bio='A very long bio...' (truncated for display)")

    result = create_user_profile(
        "John.Doe@GMAIL.COM",
        "  John@Doe#123  ",
        "This is a very long bio that will be truncated to 100 characters maximum...",
    )

    print("   Result:")
    for key, value in result.items():
        print(f"     {key}='{value}'")

    # Example 2: Input and output validation
    print("\n2. Input and Output Validation:")

    @validate(
        input_filters={"name": StripWhitespaceFilter()},
        output_filter=UppercaseFilter(),
    )
    def format_greeting(name: str) -> str:
        return f"hello {name}"

    input_name = "  john  "
    print(f"   Input:  '{input_name}'")
    print(f"   Output: '{format_greeting(input_name)}'")


def example_real_world_patterns():
    """Demonstrate real-world validation patterns."""
    print("\n" + "=" * 70)
    print("Real-World Validation Patterns")
    print("=" * 70)

    # Example 1: User registration data cleaning
    print("\n1. User Registration Data Cleaning:")

    @validate(
        input_filters={
            "email": FilterChain(
                [
                    StripWhitespaceFilter(),
                    EmailNormalizationFilter(),
                ]
            ),
            "username": FilterChain(
                [
                    StripWhitespaceFilter(),
                    LowercaseFilter(),
                    RemoveSpecialCharsFilter(allowed_chars={"_", "-", "."}),
                    TruncateFilter(max_length=30),
                ]
            ),
            "full_name": FilterChain(
                [
                    StripWhitespaceFilter(),
                    TruncateFilter(max_length=100),
                ]
            ),
        }
    )
    def register_user(email: str, username: str, full_name: str) -> dict:
        """Register a new user with validated data."""
        return {
            "email": email,
            "username": username,
            "full_name": full_name,
            "status": "registered",
        }

    print("   Input:")
    print("     email='  Test.User+tag@GMAIL.COM  '")
    print("     username='  Test@User#123!  '")
    print("     full_name='  John Doe  '")

    user = register_user(
        "  Test.User+tag@GMAIL.COM  ",
        "  Test@User#123!  ",
        "  John Doe  ",
    )

    print("   Result:")
    for key, value in user.items():
        print(f"     {key}: {value}")

    # Example 2: Blog post slug generation
    print("\n2. Blog Post Slug Generation:")

    @validate_field(
        FilterChain(
            [
                StripWhitespaceFilter(),
                SlugifyFilter(),
                TruncateFilter(max_length=50),
            ]
        )
    )
    def generate_slug(title: str) -> str:
        """Generate URL-friendly slug from title."""
        return title

    titles = [
        "  Hello World! How Are You?  ",
        "Python 3.11: What's New?",
        "10 Tips for Better Code",
    ]

    print("   Examples:")
    for title in titles:
        slug = generate_slug(title)
        print(f"     '{title}' -> '{slug}'")

    # Example 3: Comment sanitization
    print("\n3. Comment Sanitization:")

    comment_filter = FilterChain(
        [
            StripWhitespaceFilter(),
            RemoveSpecialCharsFilter(
                allowed_chars={" ", ".", ",", "!", "?", "-", "'", '"'},
                replacement="",
            ),
            TruncateFilter(max_length=500),
        ]
    )

    raw_comment = "  This is a test comment with @tags and #hashtags!  "
    print(f"   Input:  '{raw_comment}'")
    print(f"   Output: '{comment_filter(raw_comment)}'")


def main():
    """Run all validation examples."""
    print("\n" + "=" * 70)
    print("DSPU Validation Examples")
    print("=" * 70)

    example_basic_filters()
    example_filter_chains()
    example_validate_field_decorator()
    example_validate_decorator()
    example_real_world_patterns()

    print("\n" + "=" * 70)
    print("Examples Complete!")
    print("=" * 70)


if __name__ == "__main__":
    main()
