"""Pydantic integration examples with dspu filters.

This example demonstrates how to use dspu filters with Pydantic models
for automatic data validation and transformation.
"""

import sys
from typing import ClassVar

try:
    from pydantic import BaseModel, field_validator
except ImportError:
    print("Pydantic is required for these examples. Install with: pip install pydantic")
    sys.exit(1)

from dspu.validation import (
    EmailNormalizationFilter,
    FilterChain,
    FilteredModel,
    LowercaseFilter,
    RemoveSpecialCharsFilter,
    SlugifyFilter,
    StripWhitespaceFilter,
    TruncateFilter,
    UppercaseFilter,
    create_pydantic_model_with_filters,
    pydantic_filter_validator,
)


def example_field_validator():
    """Demonstrate using filters as Pydantic field validators."""
    print("\n" + "=" * 70)
    print("Pydantic field_validator with Filters")
    print("=" * 70)

    # Example 1: Single filter as validator
    print("\n1. Single Filter Validator:")

    class User(BaseModel):
        email: str
        username: str

        _validate_email = field_validator("email", mode="before")(
            pydantic_filter_validator(EmailNormalizationFilter())
        )

        _validate_username = field_validator("username", mode="before")(
            pydantic_filter_validator(LowercaseFilter())
        )

    print("   Input:")
    print("     email='John.Doe@GMAIL.COM'")
    print("     username='JOHNDOE'")

    user = User(email="John.Doe@GMAIL.COM", username="JOHNDOE")

    print("   Result:")
    print(f"     email='{user.email}'")
    print(f"     username='{user.username}'")

    # Example 2: Filter chain as validator
    print("\n2. Filter Chain Validator:")

    class Article(BaseModel):
        title: str
        slug: str

        _validate_slug = field_validator("slug", mode="before")(
            pydantic_filter_validator(
                FilterChain(
                    [
                        StripWhitespaceFilter(),
                        SlugifyFilter(),
                        TruncateFilter(max_length=50),
                    ]
                )
            )
        )

    print("   Input:")
    print("     title='My Article'")
    print("     slug='  Hello World! How Are You?  '")

    article = Article(
        title="My Article",
        slug="  Hello World! How Are You?  ",
    )

    print("   Result:")
    print(f"     title='{article.title}'")
    print(f"     slug='{article.slug}'")


def example_filtered_model():
    """Demonstrate FilteredModel base class."""
    print("\n" + "=" * 70)
    print("FilteredModel Base Class")
    print("=" * 70)

    # Example 1: User model with filters
    print("\n1. User Model with Filters:")

    class User(FilteredModel):
        email: str
        username: str
        full_name: str
        bio: str

        _filters: ClassVar[dict] = {
            "email": EmailNormalizationFilter(),
            "username": FilterChain(
                [
                    StripWhitespaceFilter(),
                    LowercaseFilter(),
                    RemoveSpecialCharsFilter(allowed_chars={"_", "-"}),
                ]
            ),
            "full_name": FilterChain(
                [
                    StripWhitespaceFilter(),
                    TruncateFilter(max_length=100),
                ]
            ),
            "bio": TruncateFilter(max_length=500),
        }

    print("   Input:")
    print("     email='John.Doe+test@GMAIL.COM'")
    print("     username='  John@Doe#123  '")
    print("     full_name='  John Doe  '")
    print("     bio='Short bio'")

    user = User(
        email="John.Doe+test@GMAIL.COM",
        username="  John@Doe#123  ",
        full_name="  John Doe  ",
        bio="Short bio",
    )

    print("   Result:")
    print(f"     email='{user.email}'")
    print(f"     username='{user.username}'")
    print(f"     full_name='{user.full_name}'")
    print(f"     bio='{user.bio}'")

    # Example 2: Blog post model
    print("\n2. Blog Post Model:")

    class BlogPost(FilteredModel):
        title: str
        slug: str
        content: str
        tags: list[str]

        _filters: ClassVar[dict] = {
            "title": FilterChain(
                [
                    StripWhitespaceFilter(),
                    TruncateFilter(max_length=200),
                ]
            ),
            "slug": FilterChain(
                [
                    StripWhitespaceFilter(),
                    SlugifyFilter(),
                ]
            ),
            "content": StripWhitespaceFilter(),
        }

    print("   Input:")
    print("     title='  My Amazing Blog Post!  '")
    print("     slug='  My Amazing Blog Post!  '")
    print("     content='  Blog content here...  '")
    print("     tags=['python', 'tutorial']")

    post = BlogPost(
        title="  My Amazing Blog Post!  ",
        slug="  My Amazing Blog Post!  ",
        content="  Blog content here...  ",
        tags=["python", "tutorial"],
    )

    print("   Result:")
    print(f"     title='{post.title}'")
    print(f"     slug='{post.slug}'")
    print(f"     content='{post.content}'")
    print(f"     tags={post.tags}")


def example_dynamic_model_creation():
    """Demonstrate dynamic model creation with filters."""
    print("\n" + "=" * 70)
    print("Dynamic Model Creation")
    print("=" * 70)

    print("\n1. Create Model at Runtime:")

    # Create a user model dynamically
    user_model = create_pydantic_model_with_filters(
        "DynamicUser",
        fields={
            "email": str,
            "username": str,
            "age": int,
        },
        filters={
            "email": EmailNormalizationFilter(),
            "username": LowercaseFilter(),
        },
    )

    print("   Model created with filters for email and username")
    print("   Input:")
    print("     email='Test@EXAMPLE.COM'")
    print("     username='TESTUSER'")
    print("     age=25")

    user = user_model(
        email="Test@EXAMPLE.COM",
        username="TESTUSER",
        age=25,
    )

    print("   Result:")
    print(f"     email='{user.email}'")
    print(f"     username='{user.username}'")
    print(f"     age={user.age}")


def example_real_world_api():
    """Demonstrate real-world API request/response models."""
    print("\n" + "=" * 70)
    print("Real-World API Models")
    print("=" * 70)

    # Example 1: User registration request
    print("\n1. User Registration Request:")

    class UserRegistrationRequest(FilteredModel):
        email: str
        username: str
        password: str
        full_name: str
        phone: str | None = None

        _filters: ClassVar[dict] = {
            "email": FilterChain(
                [
                    StripWhitespaceFilter(),
                    EmailNormalizationFilter(),
                ]
            ),
            "username": FilterChain(
                [
                    StripWhitespaceFilter(),
                    LowercaseFilter(),
                    RemoveSpecialCharsFilter(allowed_chars={"_", "-", "."}),
                    TruncateFilter(max_length=30),
                ]
            ),
            "full_name": FilterChain(
                [
                    StripWhitespaceFilter(),
                    TruncateFilter(max_length=100),
                ]
            ),
            "phone": StripWhitespaceFilter(),
        }

    print("   Input:")
    print("     email='  Test.User+spam@GMAIL.COM  '")
    print("     username='  Test@User#123!  '")
    print("     password='secret123'")
    print("     full_name='  John Doe  '")

    request = UserRegistrationRequest(
        email="  Test.User+spam@GMAIL.COM  ",
        username="  Test@User#123!  ",
        password="secret123",
        full_name="  John Doe  ",
    )

    print("   Result:")
    print(f"     email='{request.email}'")
    print(f"     username='{request.username}'")
    print(f"     password='{'*' * len(request.password)}'")
    print(f"     full_name='{request.full_name}'")

    # Example 2: Blog post creation
    print("\n2. Blog Post Creation:")

    class CreateBlogPostRequest(FilteredModel):
        title: str
        content: str
        summary: str
        tags: list[str]
        author_email: str

        _filters: ClassVar[dict] = {
            "title": FilterChain(
                [
                    StripWhitespaceFilter(),
                    TruncateFilter(max_length=200),
                ]
            ),
            "content": StripWhitespaceFilter(),
            "summary": TruncateFilter(max_length=500),
            "author_email": EmailNormalizationFilter(),
        }

    print("   Input:")
    print("     title='  Getting Started with Python  '")
    print("     content='  Long article content...  '")
    print("     summary='A comprehensive guide...' (truncated)")
    print("     tags=['python', 'tutorial']")
    print("     author_email='Author@Example.COM'")

    post_request = CreateBlogPostRequest(
        title="  Getting Started with Python  ",
        content="  Long article content...  ",
        summary="A comprehensive guide to Python programming for beginners...",
        tags=["python", "tutorial"],
        author_email="Author@Example.COM",
    )

    print("   Result:")
    print(f"     title='{post_request.title}'")
    print(f"     content='{post_request.content}'")
    print(f"     summary='{post_request.summary[:50]}...'")
    print(f"     tags={post_request.tags}")
    print(f"     author_email='{post_request.author_email}'")

    # Example 3: Nested models
    print("\n3. Nested Models with Filters:")

    class Address(FilteredModel):
        street: str
        city: str
        country: str
        postal_code: str

        _filters: ClassVar[dict] = {
            "street": StripWhitespaceFilter(),
            "city": StripWhitespaceFilter(),
            "country": UppercaseFilter(),
            "postal_code": StripWhitespaceFilter(),
        }

    class UserProfile(FilteredModel):
        email: str
        username: str
        address: Address

        _filters: ClassVar[dict] = {
            "email": EmailNormalizationFilter(),
            "username": LowercaseFilter(),
        }

    print("   Input:")
    print("     email='User@EXAMPLE.COM'")
    print("     username='TESTUSER'")
    print("     address.country='usa'")

    profile = UserProfile(
        email="User@EXAMPLE.COM",
        username="TESTUSER",
        address=Address(
            street="  123 Main St  ",
            city="  New York  ",
            country="usa",
            postal_code="  10001  ",
        ),
    )

    print("   Result:")
    print(f"     email='{profile.email}'")
    print(f"     username='{profile.username}'")
    print(f"     address.street='{profile.address.street}'")
    print(f"     address.city='{profile.address.city}'")
    print(f"     address.country='{profile.address.country}'")
    print(f"     address.postal_code='{profile.address.postal_code}'")


def main():
    """Run all Pydantic integration examples."""
    print("\n" + "=" * 70)
    print("DSPU Pydantic Integration Examples")
    print("=" * 70)

    example_field_validator()
    example_filtered_model()
    example_dynamic_model_creation()
    example_real_world_api()

    print("\n" + "=" * 70)
    print("Examples Complete!")
    print("=" * 70)


if __name__ == "__main__":
    main()
