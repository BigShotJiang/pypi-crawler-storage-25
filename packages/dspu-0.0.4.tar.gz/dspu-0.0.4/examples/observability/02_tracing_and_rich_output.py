"""Example: Tracing decorators and rich output utilities.

This example demonstrates:
1. @timed decorator for execution timing
2. @traced decorator for function tracing
3. @logged_errors for error handling
4. Rich output utilities (JSON, tables, trees)
5. Progress bars
"""

import asyncio
import time

from dspu.observability import (
    Progress,
    TaskProgress,
    configure_logging,
    get_logger,
    inspect_object,
    logged_errors,
    print_json,
    print_table,
    print_traceback,
    print_tree,
    timed,
    traced,
)

# Configure logging for examples
configure_logging(level="DEBUG", format="console")
logger = get_logger(__name__)


def example_1_timed_decorator():
    """Example 1: Timing function execution."""
    print("\n=== Example 1: @timed Decorator ===")

    @timed()
    def slow_operation():
        time.sleep(0.1)
        return "done"

    @timed(threshold_ms=50)
    def fast_operation():
        time.sleep(0.01)  # Won't be logged (below threshold)
        return "quick"

    result1 = slow_operation()  # Logs execution time
    result2 = fast_operation()  # Not logged (below 50ms threshold)

    print(f"Results: {result1}, {result2}")


def example_2_traced_decorator():
    """Example 2: Tracing function calls."""
    print("\n=== Example 2: @traced Decorator ===")

    @traced(log_args=True, log_result=True)
    def process_order(order_id: str, items: list) -> dict:
        logger.info(f"Processing order {order_id}")
        return {"status": "success", "order_id": order_id, "items": len(items)}

    result = process_order("order-123", ["item1", "item2", "item3"])
    print(f"Result: {result}")


def example_3_logged_errors_decorator():
    """Example 3: Automatic error logging."""
    print("\n=== Example 3: @logged_errors Decorator ===")

    @logged_errors(reraise=False)
    def risky_operation(x: int) -> int:
        if x < 0:
            raise ValueError("Negative numbers not allowed")
        return x * 2

    # This will log the error but not raise
    result1 = risky_operation(-5)
    print(f"Result 1 (error): {result1}")  # None

    # This will succeed
    result2 = risky_operation(10)
    print(f"Result 2 (success): {result2}")  # 20


def example_4_async_decorators():
    """Example 4: Decorators with async functions."""
    print("\n=== Example 4: Async Function Decorators ===")

    @timed()
    @traced()
    async def async_fetch_data(user_id: int) -> dict:
        await asyncio.sleep(0.05)  # Simulate API call
        return {"user_id": user_id, "name": "Alice"}

    # Run async function
    result = asyncio.run(async_fetch_data(123))
    print(f"Result: {result}")


def example_5_combined_decorators():
    """Example 5: Combining multiple decorators."""
    print("\n=== Example 5: Combined Decorators ===")

    @logged_errors()
    @timed()
    @traced(log_args=True)
    def complex_operation(x: int, y: int) -> int:
        logger.debug(f"Computing {x} + {y}")
        time.sleep(0.02)
        return x + y

    result = complex_operation(5, 10)
    print(f"Result: {result}")


def example_6_print_json():
    """Example 6: Pretty-printing JSON."""
    print("\n=== Example 6: Pretty JSON Output ===")

    data = {
        "user": {"id": 123, "name": "Alice", "email": "alice@example.com"},
        "orders": [{"id": "order-1", "total": 99.99}, {"id": "order-2", "total": 149.99}],
        "metadata": {"timestamp": "2024-12-05T10:30:00", "version": "1.0.0"},
    }

    print_json(data)


def example_7_print_table():
    """Example 7: Tabular data display."""
    print("\n=== Example 7: Table Output ===")

    users = [
        {"name": "Alice", "age": 30, "city": "New York"},
        {"name": "Bob", "age": 25, "city": "San Francisco"},
        {"name": "Charlie", "age": 35, "city": "Boston"},
    ]

    print_table(users, title="Users")


def example_8_print_tree():
    """Example 8: Hierarchical data as tree."""
    print("\n=== Example 8: Tree Output ===")

    config = {
        "database": {
            "host": "localhost",
            "port": 5432,
            "credentials": {"username": "admin", "password": "****"},
        },
        "cache": {"redis": {"host": "localhost", "port": 6379}},
        "features": ["auth", "logging", "metrics"],
    }

    print_tree(config, title="Configuration")


def example_9_progress_bar():
    """Example 9: Progress bar."""
    print("\n=== Example 9: Progress Bar ===")

    with Progress() as progress:
        task = progress.add_task("Processing items", total=100)

        for i in range(100):
            time.sleep(0.01)
            progress.update(task, advance=1)


def example_10_multi_task_progress():
    """Example 10: Multiple progress bars."""
    print("\n=== Example 10: Multi-Task Progress ===")

    with TaskProgress() as progress:
        download = progress.add_task("Downloading", total=100)
        process = progress.add_task("Processing", total=50)
        upload = progress.add_task("Uploading", total=75)

        # Simulate work
        for i in range(100):
            time.sleep(0.01)
            progress.update(download, advance=1)

            if i % 2 == 0 and i < 50:
                progress.update(process, advance=1)

            if i % 3 == 0 and i < 75:
                progress.update(upload, advance=1)


def example_11_inspect_object():
    """Example 11: Object inspection."""
    print("\n=== Example 11: Object Inspection ===")

    class User:
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age
            self._password = "secret"

        def greet(self):
            return f"Hello, I'm {self.name}"

    user = User("Alice", 30)

    # Inspect object (shows attributes and methods)
    inspect_object(user, methods=True, private=False)


def example_12_enhanced_traceback():
    """Example 12: Enhanced error tracebacks."""
    print("\n=== Example 12: Enhanced Traceback ===")

    def buggy_function(x, y):
        result = x / y  # Will fail if y is 0
        return result

    try:
        buggy_function(10, 0)
    except Exception:
        print_traceback(show_locals=True)


def example_13_real_world_data_processing():
    """Example 13: Real-world data processing with observability."""
    print("\n=== Example 13: Real-World Data Processing ===")

    @timed()
    @traced()
    def load_data(filename: str) -> list:
        """Load data from file."""
        time.sleep(0.05)
        return [{"id": i, "value": i * 10} for i in range(100)]

    @timed()
    def transform_data(data: list) -> list:
        """Transform data."""
        with Progress() as progress:
            task = progress.add_task("Transforming", total=len(data))

            transformed = []
            for item in data:
                transformed.append(
                    {"id": item["id"], "value": item["value"], "squared": item["value"] ** 2}
                )
                progress.update(task, advance=1)
                time.sleep(0.001)

        return transformed

    @timed()
    @traced()
    def save_results(data: list, filename: str):
        """Save results."""
        time.sleep(0.03)
        logger.info(f"Saved {len(data)} records to {filename}")

    # Run pipeline
    logger.info("Starting data processing pipeline")

    data = load_data("input.csv")
    logger.info(f"Loaded {len(data)} records")

    transformed = transform_data(data)
    logger.info(f"Transformed {len(transformed)} records")

    save_results(transformed, "output.csv")
    logger.info("Pipeline complete")

    # Show summary
    summary = {"input_records": len(data), "output_records": len(transformed), "status": "success"}
    print("\nPipeline Summary:")
    print_json(summary)


def main():
    """Run all examples."""
    examples = [
        example_1_timed_decorator,
        example_2_traced_decorator,
        example_3_logged_errors_decorator,
        example_4_async_decorators,
        example_5_combined_decorators,
        example_6_print_json,
        example_7_print_table,
        example_8_print_tree,
        example_9_progress_bar,
        example_10_multi_task_progress,
        example_11_inspect_object,
        example_12_enhanced_traceback,
        example_13_real_world_data_processing,
    ]

    for example in examples:
        try:
            example()
            time.sleep(0.3)
        except Exception as e:
            print(f"Error in {example.__name__}: {e}")


if __name__ == "__main__":
    main()
