"""Example: Basic logging setup and structured logging.

This example demonstrates:
1. Simple logging configuration
2. Structured logging with extra fields
3. Context management
4. Rich console output
"""

import time

from dspu.observability import (
    LogContext,
    bind_context,
    configure_logging,
    get_logger,
)


def example_1_simple_logging():
    """Example 1: Simple logging with console format."""
    print("\n=== Example 1: Simple Logging ===")

    # Configure logging with console format
    configure_logging(level="INFO", format="console")

    logger = get_logger(__name__)

    logger.info("Application started")
    logger.debug("This won't show (DEBUG < INFO)")
    logger.warning("This is a warning")
    logger.error("This is an error")


def example_2_structured_logging():
    """Example 2: Structured logging with extra fields."""
    print("\n=== Example 2: Structured Logging ===")

    # Configure with JSON format for structured output
    configure_logging(level="INFO", format="json")

    logger = get_logger(__name__)

    # Log with extra structured fields
    logger.info("User login", user_id=123, username="alice", ip="192.168.1.1")
    logger.info("Order created", order_id="order-456", total=99.99, items=3)
    logger.error("Payment failed", error_code="CARD_DECLINED", amount=49.99)


def example_3_context_management():
    """Example 3: Using log context for automatic field propagation."""
    print("\n=== Example 3: Context Management ===")

    configure_logging(level="INFO", format="console")
    logger = get_logger(__name__)

    # Add persistent context that appears in all logs
    bind_context(service="my-api", version="1.0.0")

    logger.info("Service started")  # Includes service and version

    # Use context manager for temporary context
    with LogContext(request_id="req-123", user_id=456):
        logger.info("Processing request")  # Includes request_id and user_id
        logger.info("Database query executed")  # Still has context

    logger.info("Request complete")  # Context removed, but service/version remain


def example_4_rich_console():
    """Example 4: Rich console output with colors."""
    print("\n=== Example 4: Rich Console Output ===")

    # Configure with rich format for colorful output
    configure_logging(level="INFO", format="rich")

    logger = get_logger(__name__)

    logger.info("Starting data processing")
    logger.warning("Found 3 duplicate records")
    logger.error("Failed to connect to database")

    try:
        # Simulate an error
        result = 1 / 0
    except Exception:
        logger.exception("An error occurred")  # Rich traceback!


def example_5_multiple_loggers():
    """Example 5: Using multiple loggers."""
    print("\n=== Example 5: Multiple Loggers ===")

    configure_logging(level="DEBUG", format="console")

    # Different loggers for different modules
    api_logger = get_logger("api")
    db_logger = get_logger("database")
    cache_logger = get_logger("cache")

    api_logger.info("Received API request", endpoint="/users")
    db_logger.debug("Executing query", table="users")
    cache_logger.info("Cache miss", key="user:123")
    api_logger.info("Sending response", status_code=200)


def example_6_json_output():
    """Example 6: JSON output for log aggregation."""
    print("\n=== Example 6: JSON Output (NDJSON) ===")

    # JSON format is ideal for log aggregation systems like ELK, Splunk, etc.
    configure_logging(level="INFO", format="json")

    logger = get_logger(__name__)

    # Each log line is a complete JSON object (NDJSON format)
    logger.info("Request received", method="POST", path="/api/users")
    logger.info("Database query", duration_ms=45.2, rows=10)
    logger.warning("Rate limit approaching", current=95, limit=100)
    logger.error("External API failure", api="payment-service", retry_count=3)


def example_7_file_logging():
    """Example 7: Logging to files."""
    print("\n=== Example 7: File Logging ===")

    # Log to both console and file
    configure_logging(level="INFO", format="console", outputs=["stdout", "file:app.log"])

    logger = get_logger(__name__)

    logger.info("Logs go to both console and app.log")
    logger.error("Errors are captured in the file")

    print("Check app.log file for the logs")


def example_8_real_world_api():
    """Example 8: Real-world API request logging."""
    print("\n=== Example 8: Real-World API Logging ===")

    configure_logging(level="INFO", format="json")
    logger = get_logger(__name__)

    # Simulate API request handling
    request_id = "req-789"

    with LogContext(request_id=request_id):
        start_time = time.time()

        logger.info("Request started", method="GET", path="/api/orders")

        # Simulate processing
        time.sleep(0.1)

        # Log database operations
        logger.debug("Database query", table="orders", query_time_ms=15.3)

        # Log cache operations
        logger.debug("Cache lookup", key="orders:recent", hit=True)

        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000

        logger.info(
            "Request completed",
            status_code=200,
            duration_ms=round(duration_ms, 2),
            items_returned=10,
        )


def main():
    """Run all examples."""
    examples = [
        example_1_simple_logging,
        example_2_structured_logging,
        example_3_context_management,
        example_4_rich_console,
        example_5_multiple_loggers,
        example_6_json_output,
        example_7_file_logging,
        example_8_real_world_api,
    ]

    for example in examples:
        try:
            example()
            time.sleep(0.5)  # Pause between examples
        except Exception as e:
            print(f"Error in {example.__name__}: {e}")


if __name__ == "__main__":
    main()
