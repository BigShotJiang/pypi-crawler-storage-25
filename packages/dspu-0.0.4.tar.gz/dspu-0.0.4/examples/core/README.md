# Core Module Examples

These examples demonstrate the core utilities and patterns provided by `dspu.core`.

## Examples

### 1. Protocols (`01_protocols_basic.py`)

Demonstrates the use of structural typing with protocols:

- **Serializable**: Objects that can be converted to/from dictionaries
- **AsyncResource**: Objects that support async context management
- **Closeable**: Objects with sync and async cleanup methods

**Key Concepts:**
- Duck typing without inheritance
- Runtime protocol checking with `isinstance()`
- Flexible, testable code design

**Run:**
```bash
uv run python examples/core/01_protocols_basic.py
```

### 2. Registry & Plugins (`02_registry_plugins.py`)

Shows how to build extensible plugin systems using the Registry class:

- Data transformer plugins
- Serializer plugins (JSON, Pickle)
- Validator plugins (required fields, types, ranges)
- Registry operations (register, get, has, unregister, clear)

**Key Concepts:**
- Plugin architecture without complex frameworks
- Type-safe plugin registration
- Multiple plugin systems in one application

**Run:**
```bash
uv run python examples/core/02_registry_plugins.py
```

### 3. Exception Handling (`03_exception_handling.py`)

Demonstrates rich error handling with context:

- **ConfigurationError**: Config loading failures with suggestions
- **ValidationError**: Data validation with field, value, and constraint info
- **DSPUIOError**: File operations with path and operation context
- **SecurityError**: Security violations with reason and resource info
- Exception hierarchy and catching patterns
- Exception chaining

**Key Concepts:**
- Actionable error messages
- Rich error context for debugging
- Exception chaining to preserve information
- Best practices for error handling

**Run:**
```bash
uv run python examples/core/03_exception_handling.py
```

## What You'll Learn

From these examples, you'll learn how to:

1. **Design flexible APIs** using protocols instead of inheritance
2. **Build extensible systems** with the registry pattern
3. **Provide helpful errors** with rich context and suggestions
4. **Follow best practices** for error handling in Python

## Prerequisites

Make sure you have dspu installed:

```bash
uv sync
```

## Running All Examples

```bash
# Run all examples
uv run python examples/core/01_protocols_basic.py
uv run python examples/core/02_registry_plugins.py
uv run python examples/core/03_exception_handling.py
```

## Next Steps

After understanding the core utilities, check out:

- **`../config/`** - Configuration management examples
- **`../sample_inputs/`** - Sample data files used by examples

---

### Support

For issues or questions:
- [GitHub Issues](https://github.com/deepsaia/dspu/issues)
- [Documentation](https://deepsaia.github.io/dspu)
