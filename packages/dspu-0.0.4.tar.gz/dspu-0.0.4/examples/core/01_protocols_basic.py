"""Example: Using Protocols for Duck Typing.

This example demonstrates how to use the Serializable, AsyncResource,
and Closeable protocols from dspu.core.protocols.

Protocols provide structural subtyping (duck typing) without inheritance,
making your code more flexible and testable.
"""

import asyncio
from typing import Any

from dspu.core.protocols import AsyncResource, Closeable, Serializable


# Example 1: Serializable Protocol
# ===================================
class DataModel:
    """A simple data model that implements Serializable."""

    def __init__(self, name: str, value: int, metadata: dict[str, Any]) -> None:
        self.name = name
        self.value = value
        self.metadata = metadata

    def to_dict(self) -> dict[str, Any]:
        """Convert model to dictionary."""
        return {
            "name": self.name,
            "value": self.value,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DataModel":
        """Create model from dictionary."""
        return cls(
            name=data["name"],
            value=data["value"],
            metadata=data["metadata"],
        )


def save_to_storage(obj: Serializable) -> dict[str, Any]:
    """Save any serializable object to storage.

    This function accepts ANY object that implements the Serializable protocol,
    without requiring inheritance from a base class.
    """
    return obj.to_dict()


def load_from_storage(cls: type[Serializable], data: dict[str, Any]) -> Serializable:
    """Load any serializable object from storage."""
    return cls.from_dict(data)


# Example 2: AsyncResource Protocol
# ===================================
class DatabaseConnection:
    """A database connection that implements AsyncResource."""

    def __init__(self, connection_string: str) -> None:
        self.connection_string = connection_string
        self.connected = False

    async def __aenter__(self) -> "DatabaseConnection":
        """Enter async context - connect to database."""
        print(f"Connecting to database: {self.connection_string}")
        await asyncio.sleep(0.1)  # Simulate connection time
        self.connected = True
        print("Connected!")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context - disconnect from database."""
        print("Disconnecting from database...")
        await asyncio.sleep(0.1)  # Simulate disconnection time
        self.connected = False
        print("Disconnected!")

    async def query(self, sql: str) -> list[dict[str, Any]]:
        """Execute a query."""
        if not self.connected:
            raise RuntimeError("Not connected to database")
        print(f"Executing query: {sql}")
        return [{"id": 1, "name": "result"}]


async def fetch_data(resource: AsyncResource) -> Any:
    """Fetch data using any async resource.

    This function works with ANY object implementing AsyncResource,
    without knowing the specific type.
    """
    async with resource:
        # Use the resource
        if hasattr(resource, "query"):
            return await resource.query("SELECT * FROM users")
        return None


# Example 3: Closeable Protocol
# ===================================
class FileHandler:
    """A file handler that implements Closeable (both sync and async)."""

    def __init__(self, filename: str) -> None:
        self.filename = filename
        self.file_handle = None
        self.open()

    def open(self) -> None:
        """Open the file."""
        print(f"Opening file: {self.filename}")
        self.file_handle = f"<file-handle-{self.filename}>"

    def close(self) -> None:
        """Close the file (synchronous)."""
        if self.file_handle:
            print(f"Closing file: {self.filename}")
            self.file_handle = None

    async def aclose(self) -> None:
        """Close the file (asynchronous)."""
        if self.file_handle:
            print(f"Async closing file: {self.filename}")
            await asyncio.sleep(0.05)  # Simulate async cleanup
            self.file_handle = None

    def write(self, data: str) -> None:
        """Write data to file."""
        if not self.file_handle:
            raise RuntimeError("File is closed")
        print(f"Writing to {self.filename}: {data}")


def cleanup_resource(resource: Closeable) -> None:
    """Clean up any closeable resource (sync version)."""
    print("Cleaning up resource...")
    resource.close()
    print("Resource cleaned up!")


async def async_cleanup_resource(resource: Closeable) -> None:
    """Clean up any closeable resource (async version)."""
    print("Async cleaning up resource...")
    await resource.aclose()
    print("Resource cleaned up!")


# Example 4: Type Checking at Runtime
# =====================================
def demonstrate_runtime_checking() -> None:
    """Demonstrate runtime protocol checking."""
    from dspu.core.protocols import Serializable as SerializableProtocol

    # Check if an object implements the protocol
    model = DataModel("test", 42, {"key": "value"})

    if isinstance(model, SerializableProtocol):
        print("✓ DataModel implements Serializable protocol")
        data = model.to_dict()
        print(f"  Serialized: {data}")
    else:
        print("✗ DataModel does NOT implement Serializable protocol")

    # This won't work - plain dict doesn't implement Serializable
    plain_dict = {"name": "test"}
    if isinstance(plain_dict, SerializableProtocol):
        print("✓ dict implements Serializable protocol")
    else:
        print("✗ dict does NOT implement Serializable protocol")


# Main demonstration
# ===================
async def main() -> None:
    """Run all protocol examples."""
    print("=" * 60)
    print("DSPU Protocol Examples")
    print("=" * 60)

    # Example 1: Serializable
    print("\n1. Serializable Protocol")
    print("-" * 60)
    model = DataModel("user_data", 100, {"created": "2024-01-01"})
    serialized = save_to_storage(model)
    print(f"Serialized: {serialized}")

    restored = load_from_storage(DataModel, serialized)
    print(f"Restored: {restored.name}, {restored.value}")

    # Example 2: AsyncResource
    print("\n2. AsyncResource Protocol")
    print("-" * 60)
    db = DatabaseConnection("postgresql://localhost/mydb")
    results = await fetch_data(db)
    print(f"Query results: {results}")

    # Example 3: Closeable
    print("\n3. Closeable Protocol (Sync)")
    print("-" * 60)
    file_handler = FileHandler("data.txt")
    file_handler.write("Hello, World!")
    cleanup_resource(file_handler)

    print("\n4. Closeable Protocol (Async)")
    print("-" * 60)
    file_handler2 = FileHandler("data2.txt")
    file_handler2.write("Async Hello!")
    await async_cleanup_resource(file_handler2)

    # Example 4: Runtime checking
    print("\n5. Runtime Protocol Checking")
    print("-" * 60)
    demonstrate_runtime_checking()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
