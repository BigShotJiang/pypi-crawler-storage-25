"""Example: Exception Handling with Rich Context.

This example demonstrates how to use the exception classes from
dspu.core.exceptions to provide rich, actionable error messages.

The exception hierarchy provides context-rich errors with fields like:
- field: The specific field or component that failed
- suggestion: Actionable suggestion for fixing the error
- constraint: The constraint that was violated
- value: The invalid value that caused the error
"""

from pathlib import Path

from dspu.core.exceptions import (
    ConfigurationError,
    DSPUError,
    DSPUIOError,
    SecurityError,
    ValidationError,
)


# Example 1: ConfigurationError
# ==============================
def load_database_config(config_path: str) -> dict:
    """Load database configuration."""
    if not Path(config_path).exists():
        raise ConfigurationError(
            f"Configuration file not found: {config_path}",
            field="config_path",
            suggestion=f"Create a configuration file at {config_path} or check the path is correct",
        )

    # Simulate loading config
    config = {"host": "localhost", "port": None}

    if config["port"] is None:
        raise ConfigurationError(
            "Database port is not configured",
            field="database.port",
            suggestion="Add 'database.port' to your configuration file",
        )

    return config


# Example 2: ValidationError
# ===========================
def validate_user_age(age: int) -> None:
    """Validate user age."""
    if not isinstance(age, int):
        raise ValidationError(
            f"Age must be an integer, got {type(age).__name__}",
            field="age",
            value=age,
            constraint="type_int",
        )

    if age < 0:
        raise ValidationError(
            "Age cannot be negative",
            field="age",
            value=age,
            constraint="ge_0",
        )

    if age > 150:
        raise ValidationError(
            "Age exceeds maximum allowed value",
            field="age",
            value=age,
            constraint="le_150",
        )


def validate_email(email: str) -> None:
    """Validate email format."""
    if not isinstance(email, str):
        raise ValidationError(
            f"Email must be a string, got {type(email).__name__}",
            field="email",
            value=email,
            constraint="type_str",
        )

    if "@" not in email:
        raise ValidationError(
            "Invalid email format: missing '@' symbol",
            field="email",
            value=email,
            constraint="email_format",
        )

    if "." not in email.split("@")[1]:
        raise ValidationError(
            "Invalid email format: domain must contain '.'",
            field="email",
            value=email,
            constraint="email_domain",
        )


# Example 3: DSPUIOError
# ==========================
def read_data_file(filepath: str) -> str:
    """Read data from file."""
    path = Path(filepath)

    if not path.exists():
        raise DSPUIOError(
            f"File not found: {filepath}",
            path=filepath,
            operation="read",
        )

    if not path.is_file():
        raise DSPUIOError(
            f"Path is not a file: {filepath}",
            path=filepath,
            operation="read",
        )

    try:
        return path.read_text()
    except PermissionError as e:
        raise DSPUIOError(
            f"Permission denied reading file: {filepath}",
            path=filepath,
            operation="read",
        ) from e
    except UnicodeDecodeError as e:
        raise DSPUIOError(
            f"Failed to decode file as UTF-8: {filepath}",
            path=filepath,
            operation="read",
        ) from e


def write_data_file(filepath: str, data: str) -> None:
    """Write data to file."""
    path = Path(filepath)

    if path.exists() and not path.is_file():
        raise DSPUIOError(
            f"Path exists but is not a file: {filepath}",
            path=filepath,
            operation="write",
        )

    try:
        path.write_text(data)
    except PermissionError as e:
        raise DSPUIOError(
            f"Permission denied writing to file: {filepath}",
            path=filepath,
            operation="write",
        ) from e
    except OSError as e:
        raise DSPUIOError(
            f"OS error writing to file: {filepath}",
            path=filepath,
            operation="write",
        ) from e


# Example 4: SecurityError
# =========================
def check_api_key(api_key: str) -> None:
    """Validate API key."""
    if len(api_key) < 32:
        raise SecurityError(
            "API key is too short",
            reason="insufficient_length",
            resource="api_key",
        )

    if not api_key.startswith("sk-"):
        raise SecurityError(
            "Invalid API key format",
            reason="invalid_format",
            resource="api_key",
        )


def check_file_permissions(filepath: str) -> None:
    """Check if file has safe permissions."""
    import stat

    path = Path(filepath)
    if not path.exists():
        return

    # Check if file is world-readable
    mode = path.stat().st_mode
    if mode & stat.S_IROTH:
        raise SecurityError(
            f"File has insecure permissions (world-readable): {filepath}",
            reason="insecure_permissions",
            resource=filepath,
        )


# Example 5: Exception Hierarchy and Catching
# ============================================
def demonstrate_exception_hierarchy() -> None:
    """Demonstrate exception hierarchy."""
    print("=" * 60)
    print("Exception Hierarchy")
    print("=" * 60)

    # All custom exceptions inherit from DSPUError
    print("\n1. Catching specific exception types:")

    try:
        validate_user_age(-5)
    except ValidationError as e:
        print(f"✓ Caught ValidationError: {e}")
        print(f"  Field: {e.field}")
        print(f"  Value: {e.value}")
        print(f"  Constraint: {e.constraint}")

    print("\n2. Catching base exception (DSPUError):")

    try:
        check_api_key("short")
    except DSPUError as e:
        # Can catch all dspu exceptions with base class
        print(f"✓ Caught DSPUError (actually {type(e).__name__}): {e}")
        if isinstance(e, SecurityError):
            print(f"  Reason: {e.reason}")
            print(f"  Resource: {e.resource}")


# Example 6: Rich Error Context
# ==============================
def demonstrate_error_context() -> None:
    """Demonstrate rich error context."""
    print("\n" + "=" * 60)
    print("Rich Error Context")
    print("=" * 60)

    print("\n1. ConfigurationError with suggestion:")
    try:
        load_database_config("/nonexistent/config.yaml")
    except ConfigurationError as e:
        print(f"✗ Error: {e}")
        print(f"  Field: {e.field}")
        print(f"  Suggestion: {e.suggestion}")

    print("\n2. ValidationError with value and constraint:")
    try:
        validate_user_age(200)
    except ValidationError as e:
        print(f"✗ Error: {e}")
        print(f"  Field: {e.field}")
        print(f"  Value: {e.value}")
        print(f"  Constraint: {e.constraint}")

    print("\n3. DSPUIOError with path and operation:")
    try:
        read_data_file("/tmp/nonexistent.txt")
    except DSPUIOError as e:
        print(f"✗ Error: {e}")
        print(f"  Path: {e.path}")
        print(f"  Operation: {e.operation}")

    print("\n4. SecurityError with reason and resource:")
    try:
        check_api_key("invalid")
    except SecurityError as e:
        print(f"✗ Error: {e}")
        print(f"  Reason: {e.reason}")
        print(f"  Resource: {e.resource}")


# Example 7: Chaining Exceptions
# ===============================
def process_user_data(data: dict) -> None:
    """Process user data with error chaining."""
    try:
        # This might raise a KeyError
        age = data["age"]
        validate_user_age(age)
    except KeyError as e:
        # Chain the original exception
        raise ValidationError(
            "Missing required field",
            field="age",
            constraint="required",
        ) from e


def demonstrate_exception_chaining() -> None:
    """Demonstrate exception chaining."""
    print("\n" + "=" * 60)
    print("Exception Chaining")
    print("=" * 60)

    try:
        process_user_data({"name": "Alice"})  # Missing 'age' field
    except ValidationError as e:
        print(f"✗ ValidationError: {e}")
        print(f"  Field: {e.field}")
        print(f"  Constraint: {e.constraint}")

        if e.__cause__:
            print(f"  Caused by: {type(e.__cause__).__name__}: {e.__cause__}")


# Example 8: Best Practices
# ==========================
def demonstrate_best_practices() -> None:
    """Demonstrate error handling best practices."""
    print("\n" + "=" * 60)
    print("Best Practices")
    print("=" * 60)

    print("\n1. Always provide actionable error messages:")
    print("   ✗ Bad: 'Invalid configuration'")
    print("   ✓ Good: 'Database port is not configured'")
    print("          + Suggestion: 'Add database.port to your config file'")

    print("\n2. Include relevant context (field, value, path, etc.):")
    print("   ✗ Bad: 'Validation failed'")
    print("   ✓ Good: ValidationError with field='age', value=200, constraint='le_150'")

    print("\n3. Use specific exception types:")
    print("   ✗ Bad: raise Exception('Config error')")
    print("   ✓ Good: raise ConfigurationError('...', field='...', suggestion='...')")

    print("\n4. Chain exceptions to preserve context:")
    print("   ✗ Bad: raise ValidationError('Field missing')")
    print("   ✓ Good: raise ValidationError('...') from original_error")

    print("\n5. Catch at the appropriate level:")
    print("   - Catch specific types when you can handle them")
    print("   - Catch DSPUError to handle all dspu exceptions")
    print("   - Let unexpected exceptions propagate")


# Main demonstration
# ===================
def main() -> None:
    """Run all exception handling examples."""
    print("\n" + "=" * 60)
    print("DSPU Exception Handling Examples")
    print("=" * 60)

    demonstrate_exception_hierarchy()
    demonstrate_error_context()
    demonstrate_exception_chaining()
    demonstrate_best_practices()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
