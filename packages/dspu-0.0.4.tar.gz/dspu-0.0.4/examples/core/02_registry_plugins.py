"""Example: Plugin System using Registry.

This example demonstrates how to use the Registry class to build
a flexible plugin system for data processing, serialization,
and other extensible components.
"""

from abc import abstractmethod
from typing import Any, Protocol, runtime_checkable

from dspu.core.registry import Registry


# Example 1: Data Transformer Plugin System
# ===========================================
@runtime_checkable
class DataTransformer(Protocol):
    """Protocol for data transformers."""

    @abstractmethod
    def transform(self, data: dict[str, Any]) -> dict[str, Any]:
        """Transform data."""
        ...


class UppercaseTransformer:
    """Transform all string values to uppercase."""

    def transform(self, data: dict[str, Any]) -> dict[str, Any]:
        """Transform data by uppercasing all string values."""
        result = {}
        for key, value in data.items():
            if isinstance(value, str):
                result[key] = value.upper()
            elif isinstance(value, dict):
                result[key] = self.transform(value)
            else:
                result[key] = value
        return result


class AddTimestampTransformer:
    """Add a timestamp field to data."""

    def transform(self, data: dict[str, Any]) -> dict[str, Any]:
        """Add timestamp to data."""
        from datetime import datetime

        result = data.copy()
        result["processed_at"] = datetime.now().isoformat()
        return result


class PrefixKeysTransformer:
    """Add a prefix to all keys."""

    def __init__(self, prefix: str) -> None:
        self.prefix = prefix

    def transform(self, data: dict[str, Any]) -> dict[str, Any]:
        """Add prefix to all keys."""
        return {f"{self.prefix}_{key}": value for key, value in data.items()}


# Example 2: Serializer Plugin System
# =====================================
@runtime_checkable
class Serializer(Protocol):
    """Protocol for serializers."""

    @abstractmethod
    def serialize(self, data: Any) -> bytes:
        """Serialize data to bytes."""
        ...

    @abstractmethod
    def deserialize(self, data: bytes) -> Any:
        """Deserialize bytes to data."""
        ...


class JSONSerializer:
    """JSON serializer."""

    def serialize(self, data: Any) -> bytes:
        """Serialize to JSON bytes."""
        import json

        return json.dumps(data).encode("utf-8")

    def deserialize(self, data: bytes) -> Any:
        """Deserialize from JSON bytes."""
        import json

        return json.loads(data.decode("utf-8"))


class PickleSerializer:
    """Pickle serializer (with warning)."""

    def serialize(self, data: Any) -> bytes:
        """Serialize to pickle bytes."""
        import pickle

        print("⚠️  Warning: Using pickle serialization (not secure)")
        return pickle.dumps(data)

    def deserialize(self, data: bytes) -> Any:
        """Deserialize from pickle bytes."""
        import pickle

        print("⚠️  Warning: Using pickle deserialization (not secure)")
        return pickle.loads(data)  # noqa: S301


# Example 3: Data Validator Plugin System
# =========================================
@runtime_checkable
class Validator(Protocol):
    """Protocol for validators."""

    @abstractmethod
    def validate(self, data: dict[str, Any]) -> tuple[bool, list[str]]:
        """Validate data, return (is_valid, errors)."""
        ...


class RequiredFieldsValidator:
    """Validate that required fields are present."""

    def __init__(self, required_fields: list[str]) -> None:
        self.required_fields = required_fields

    def validate(self, data: dict[str, Any]) -> tuple[bool, list[str]]:
        """Check for required fields."""
        errors = []
        for field in self.required_fields:
            if field not in data:
                errors.append(f"Missing required field: {field}")
        return len(errors) == 0, errors


class TypeValidator:
    """Validate field types."""

    def __init__(self, type_specs: dict[str, type]) -> None:
        self.type_specs = type_specs

    def validate(self, data: dict[str, Any]) -> tuple[bool, list[str]]:
        """Check field types."""
        errors = []
        for field, expected_type in self.type_specs.items():
            if field in data and not isinstance(data[field], expected_type):
                errors.append(
                    f"Field '{field}' has wrong type: "
                    f"expected {expected_type.__name__}, "
                    f"got {type(data[field]).__name__}"
                )
        return len(errors) == 0, errors


class RangeValidator:
    """Validate numeric ranges."""

    def __init__(self, field: str, min_val: float, max_val: float) -> None:
        self.field = field
        self.min_val = min_val
        self.max_val = max_val

    def validate(self, data: dict[str, Any]) -> tuple[bool, list[str]]:
        """Check if value is in range."""
        errors = []
        if self.field in data:
            value = data[self.field]
            if not isinstance(value, (int, float)):
                errors.append(f"Field '{self.field}' is not numeric")
            elif value < self.min_val or value > self.max_val:
                errors.append(
                    f"Field '{self.field}' out of range: "
                    f"{value} not in [{self.min_val}, {self.max_val}]"
                )
        return len(errors) == 0, errors


# Demonstration
# ==============
def demonstrate_transformer_registry() -> None:
    """Demonstrate transformer plugin system."""
    print("=" * 60)
    print("1. Data Transformer Registry")
    print("=" * 60)

    # Create registry and register transformers
    transformers: Registry[DataTransformer] = Registry()
    transformers.register("uppercase", UppercaseTransformer())
    transformers.register("timestamp", AddTimestampTransformer())
    transformers.register("prefix", PrefixKeysTransformer("app"))

    print(f"Registered transformers: {transformers.list()}")

    # Use transformers
    data = {"name": "john doe", "email": "john@example.com"}
    print(f"\nOriginal data: {data}")

    # Apply uppercase transformer
    uppercase = transformers.get("uppercase")
    result1 = uppercase.transform(data)
    print(f"After uppercase: {result1}")

    # Apply timestamp transformer
    timestamp = transformers.get("timestamp")
    result2 = timestamp.transform(result1)
    print(f"After timestamp: {result2}")

    # Apply prefix transformer
    prefix = transformers.get("prefix")
    result3 = prefix.transform(data)
    print(f"After prefix: {result3}")


def demonstrate_serializer_registry() -> None:
    """Demonstrate serializer plugin system."""
    print("\n" + "=" * 60)
    print("2. Serializer Registry")
    print("=" * 60)

    # Create registry and register serializers
    serializers: Registry[Serializer] = Registry()
    serializers.register("json", JSONSerializer())
    serializers.register("pickle", PickleSerializer())

    print(f"Registered serializers: {serializers.list()}")

    data = {"user_id": 123, "username": "alice", "scores": [95, 87, 92]}
    print(f"\nOriginal data: {data}")

    # Use JSON serializer
    json_ser = serializers.get("json")
    json_bytes = json_ser.serialize(data)
    print(f"\nJSON serialized ({len(json_bytes)} bytes): {json_bytes[:50]}...")
    json_restored = json_ser.deserialize(json_bytes)
    print(f"JSON deserialized: {json_restored}")

    # Use Pickle serializer
    pickle_ser = serializers.get("pickle")
    pickle_bytes = pickle_ser.serialize(data)
    print(f"\nPickle serialized ({len(pickle_bytes)} bytes)")
    pickle_restored = pickle_ser.deserialize(pickle_bytes)
    print(f"Pickle deserialized: {pickle_restored}")


def demonstrate_validator_registry() -> None:
    """Demonstrate validator plugin system."""
    print("\n" + "=" * 60)
    print("3. Validator Registry")
    print("=" * 60)

    # Create registry and register validators
    validators: Registry[Validator] = Registry()
    validators.register(
        "required",
        RequiredFieldsValidator(["name", "age", "email"]),
    )
    validators.register(
        "types",
        TypeValidator({"name": str, "age": int, "email": str}),
    )
    validators.register("age_range", RangeValidator("age", 0, 150))

    print(f"Registered validators: {validators.list()}")

    # Test valid data
    print("\n--- Testing VALID data ---")
    valid_data = {"name": "Alice", "age": 30, "email": "alice@example.com"}
    print(f"Data: {valid_data}")

    for name in validators.list():
        validator = validators.get(name)
        is_valid, errors = validator.validate(valid_data)
        status = "✓ PASS" if is_valid else "✗ FAIL"
        print(f"  {name}: {status}")
        if errors:
            for error in errors:
                print(f"    - {error}")

    # Test invalid data
    print("\n--- Testing INVALID data ---")
    invalid_data = {"name": "Bob", "age": "thirty"}  # Missing email, wrong type
    print(f"Data: {invalid_data}")

    all_valid = True
    all_errors = []
    for name in validators.list():
        validator = validators.get(name)
        is_valid, errors = validator.validate(invalid_data)
        status = "✓ PASS" if is_valid else "✗ FAIL"
        print(f"  {name}: {status}")
        if errors:
            all_valid = False
            all_errors.extend(errors)
            for error in errors:
                print(f"    - {error}")

    print(f"\nOverall validation: {'✓ PASS' if all_valid else '✗ FAIL'}")
    if not all_valid:
        print(f"Total errors: {len(all_errors)}")


def demonstrate_registry_operations() -> None:
    """Demonstrate registry operations."""
    print("\n" + "=" * 60)
    print("4. Registry Operations")
    print("=" * 60)

    registry: Registry[DataTransformer] = Registry()

    # Register
    print("\nRegistering plugins...")
    registry.register("uppercase", UppercaseTransformer())
    registry.register("timestamp", AddTimestampTransformer())
    print(f"Registered: {registry.list()}")

    # Check existence
    print(f"\nHas 'uppercase': {registry.has('uppercase')}")
    print(f"Has 'unknown': {registry.has('unknown')}")

    # Get plugin
    print("\nGetting plugin...")
    transformer = registry.get("uppercase")
    result = transformer.transform({"text": "hello"})
    print(f"Result: {result}")

    # Try to get non-existent plugin
    print("\nTrying to get non-existent plugin...")
    try:
        registry.get("unknown")
    except KeyError as e:
        print(f"✓ Caught expected error: {e}")

    # Unregister
    print("\nUnregistering 'timestamp'...")
    registry.unregister("timestamp")
    print(f"Remaining: {registry.list()}")

    # Clear all
    print("\nClearing registry...")
    registry.clear()
    print(f"Remaining: {registry.list()}")


def main() -> None:
    """Run all registry examples."""
    print("\n" + "=" * 60)
    print("DSPU Registry Examples")
    print("=" * 60)

    demonstrate_transformer_registry()
    demonstrate_serializer_registry()
    demonstrate_validator_registry()
    demonstrate_registry_operations()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
