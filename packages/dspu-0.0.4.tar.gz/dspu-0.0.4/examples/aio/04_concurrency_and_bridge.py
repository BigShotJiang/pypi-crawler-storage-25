"""Concurrency utilities and sync/async bridge examples.

This example demonstrates concurrency control, timeout management,
and bridging between sync and async code.
"""

import asyncio
import time

from dspu.aio import (
    Timeout,
    async_to_sync,
    gather_with_limit,
    run_async,
    run_in_executor,
    run_with_timeout,
    sync_to_async,
)

# =============================================================================
# PART 1: Concurrency Control
# =============================================================================


async def example_gather_with_limit():
    """Control concurrency with gather_with_limit."""
    print("\n1. Gather with Concurrency Limit:")
    print("-" * 50)

    concurrent_count = 0
    max_concurrent = 0

    async def fetch_data(item_id: int):
        """Fetch data with concurrency tracking."""
        nonlocal concurrent_count, max_concurrent

        concurrent_count += 1
        max_concurrent = max(max_concurrent, concurrent_count)

        print(f"  Fetching item {item_id} (concurrent: {concurrent_count})")
        await asyncio.sleep(0.2)

        concurrent_count -= 1
        return f"Data for item {item_id}"

    # Fetch 10 items with max 3 concurrent
    results = await gather_with_limit(
        *[fetch_data(i) for i in range(10)],
        limit=3,
    )

    print(f"✓ Fetched {len(results)} items")
    print(f"  Max concurrent: {max_concurrent} (limit was 3)")


async def example_controlled_api_calls():
    """Rate-control API calls with gather_with_limit."""
    print("\n2. Controlled API Calls:")
    print("-" * 50)

    async def call_api(endpoint: str, delay: float = 0.1):
        """Simulate API call."""
        print(f"  Calling {endpoint}")
        await asyncio.sleep(delay)
        return {"endpoint": endpoint, "status": "ok"}

    # Make 20 API calls, but only 5 concurrent
    endpoints = [f"/api/resource/{i}" for i in range(20)]
    tasks = [call_api(ep) for ep in endpoints]

    start = time.time()
    results = await gather_with_limit(*tasks, limit=5)
    elapsed = time.time() - start

    print(f"✓ Completed {len(results)} API calls in {elapsed:.2f}s")


# =============================================================================
# PART 2: Timeout Management
# =============================================================================


async def example_timeout_operations():
    """Timeout management for async operations."""
    print("\n3. Timeout Management:")
    print("-" * 50)

    async def slow_operation(delay: float, name: str):
        """Simulate slow operation."""
        print(f"  Starting {name} (will take {delay}s)")
        await asyncio.sleep(delay)
        return f"{name} completed"

    # Operation that completes in time
    try:
        result = await run_with_timeout(
            slow_operation(0.5, "quick-op"),
            timeout=1.0,
        )
        print(f"  ✓ {result}")
    except Exception as e:
        print(f"  ✗ {type(e).__name__}: {e}")

    # Operation that times out
    try:
        result = await run_with_timeout(
            slow_operation(2.0, "slow-op"),
            timeout=0.5,
        )
        print(f"  ✓ {result}")
    except Exception as e:
        print(f"  ✗ Timeout: {type(e).__name__}")


async def example_timeout_context_manager():
    """Using Timeout context manager."""
    print("\n4. Timeout Context Manager:")
    print("-" * 50)

    try:
        async with Timeout(1.0):
            print("  Starting work...")
            await asyncio.sleep(0.5)
            print("  ✓ Work completed within timeout")
    except asyncio.CancelledError:
        print("  ✗ Work cancelled due to timeout")

    try:
        async with Timeout(0.3):
            print("  Starting slow work...")
            await asyncio.sleep(1.0)
            print("  ✓ Work completed")
    except asyncio.CancelledError:
        print("  ✗ Work cancelled - timeout exceeded")


# =============================================================================
# PART 3: Running Sync Code in Async Context
# =============================================================================


async def example_run_in_executor():
    """Run blocking code without blocking event loop."""
    print("\n5. Run Blocking Code in Executor:")
    print("-" * 50)

    def cpu_intensive_task(n: int) -> int:
        """CPU-intensive calculation."""
        print(f"  Computing factorial({n})...")
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result

    def blocking_io():
        """Blocking I/O operation."""
        print("  Performing blocking I/O...")
        time.sleep(0.5)
        return "I/O completed"

    # Run CPU-intensive work
    factorial = await run_in_executor(cpu_intensive_task, 10)
    print(f"  ✓ Result: {factorial}")

    # Run blocking I/O
    io_result = await run_in_executor(blocking_io)
    print(f"  ✓ {io_result}")


# =============================================================================
# PART 4: Sync/Async Bridge
# =============================================================================


def example_sync_code_calling_async():
    """Sync code calling async functions."""
    print("\n6. Sync Code Calling Async Functions:")
    print("-" * 50)

    async def async_fetch_data(source: str):
        """Async function to fetch data."""
        print(f"  Fetching from {source}")
        await asyncio.sleep(0.1)
        return f"Data from {source}"

    # Call async function from sync code
    result = run_async(async_fetch_data("database"))
    print(f"  ✓ {result}")


async def example_async_code_calling_sync():
    """Async code calling sync functions."""
    print("\n7. Async Code Calling Sync Functions:")
    print("-" * 50)

    def sync_process_data(data: str) -> str:
        """Sync function to process data."""
        print(f"  Processing: {data}")
        time.sleep(0.1)  # Blocking operation
        return data.upper()

    # Convert sync to async
    async_process = sync_to_async(sync_process_data)

    # Use in async code
    result = await async_process("hello world")
    print(f"  ✓ Processed: {result}")


def example_convert_async_to_sync():
    """Convert async function to sync."""
    print("\n8. Convert Async to Sync:")
    print("-" * 50)

    async def async_computation(x: int, y: int) -> int:
        """Async computation."""
        await asyncio.sleep(0.1)
        return x + y

    # Convert to sync
    sync_computation = async_to_sync(async_computation)

    # Use as normal sync function
    result = sync_computation(5, 3)
    print(f"  ✓ Result: {result}")


# =============================================================================
# PART 5: Real-World Patterns
# =============================================================================


async def example_mixed_sync_async_pipeline():
    """Pipeline combining sync and async operations."""
    print("\n9. Mixed Sync/Async Pipeline:")
    print("-" * 50)

    def validate_input(data: dict) -> dict:
        """Sync validation."""
        print("  1. Validating input (sync)...")
        return {**data, "validated": True}

    async def fetch_enrichment(data: dict) -> dict:
        """Async data enrichment."""
        print("  2. Fetching enrichment data (async)...")
        await asyncio.sleep(0.1)
        return {**data, "enriched": True}

    def transform_output(data: dict) -> dict:
        """Sync transformation."""
        print("  3. Transforming output (sync)...")
        return {**data, "transformed": True}

    # Convert sync functions to async for uniform pipeline
    async_validate = sync_to_async(validate_input)
    async_transform = sync_to_async(transform_output)

    # Build pipeline
    input_data = {"value": 42}
    result = await async_validate(input_data)
    result = await fetch_enrichment(result)
    result = await async_transform(result)

    print(f"  ✓ Pipeline result: {result}")


async def example_parallel_processing():
    """Parallel processing with controlled concurrency."""
    print("\n10. Parallel Processing:")
    print("-" * 50)

    def cpu_bound_task(item: int) -> int:
        """CPU-bound task."""
        # Simulate heavy computation
        return sum(i**2 for i in range(item * 100))

    # Convert to async
    async_task = sync_to_async(cpu_bound_task)

    # Process items in parallel with limit
    items = list(range(1, 11))
    print(f"  Processing {len(items)} items...")

    start = time.time()
    results = await gather_with_limit(
        *[async_task(item) for item in items],
        limit=4,  # Process 4 at a time
    )
    elapsed = time.time() - start

    print(f"  ✓ Processed {len(results)} items in {elapsed:.2f}s")


class DataProcessor:
    """Example class using both sync and async methods."""

    def __init__(self):
        self.cache = {}

    def load_from_cache(self, key: str) -> str | None:
        """Sync cache lookup."""
        return self.cache.get(key)

    async def fetch_from_api(self, key: str) -> str:
        """Async API fetch."""
        await asyncio.sleep(0.1)
        return f"data-{key}"

    def save_to_cache(self, key: str, value: str) -> None:
        """Sync cache save."""
        self.cache[key] = value

    async def get_data(self, key: str) -> str:
        """Get data with cache-aside pattern."""
        # Try cache first (sync)
        cached = await run_in_executor(self.load_from_cache, key)
        if cached:
            print(f"  Cache hit: {key}")
            return cached

        # Fetch from API (async)
        print(f"  Cache miss: {key} - fetching from API")
        data = await self.fetch_from_api(key)

        # Save to cache (sync)
        await run_in_executor(self.save_to_cache, key, data)

        return data


async def example_cache_aside_pattern():
    """Cache-aside pattern with mixed sync/async."""
    print("\n11. Cache-Aside Pattern:")
    print("-" * 50)

    processor = DataProcessor()

    # First call - cache miss
    result1 = await processor.get_data("user:123")
    print(f"  ✓ First call: {result1}")

    # Second call - cache hit
    result2 = await processor.get_data("user:123")
    print(f"  ✓ Second call: {result2}")


# =============================================================================
# PART 6: Error Handling with Concurrency
# =============================================================================


async def example_error_handling_in_concurrent():
    """Error handling in concurrent operations."""
    print("\n12. Error Handling in Concurrent Operations:")
    print("-" * 50)

    async def task_that_may_fail(task_id: int):
        """Task that might fail."""
        await asyncio.sleep(0.1)
        if task_id % 3 == 0:
            raise ValueError(f"Task {task_id} failed")
        return f"Task {task_id} succeeded"

    # Gather with exceptions returned as values
    results = await gather_with_limit(
        *[task_that_may_fail(i) for i in range(10)],
        limit=3,
        return_exceptions=True,
    )

    # Process results
    successes = [r for r in results if not isinstance(r, Exception)]
    failures = [r for r in results if isinstance(r, Exception)]

    print(f"  ✓ Successes: {len(successes)}")
    print(f"  ✗ Failures: {len(failures)}")


async def main():
    """Run all examples."""
    print("=" * 70)
    print("Concurrency and Bridge Utilities Examples")
    print("=" * 70)

    # Concurrency control
    await example_gather_with_limit()
    await example_controlled_api_calls()

    # Timeout management
    await example_timeout_operations()
    await example_timeout_context_manager()

    # Executor
    await example_run_in_executor()

    # Sync/Async bridge
    example_sync_code_calling_async()
    await example_async_code_calling_sync()
    example_convert_async_to_sync()

    # Real-world patterns
    await example_mixed_sync_async_pipeline()
    await example_parallel_processing()
    await example_cache_aside_pattern()

    # Error handling
    await example_error_handling_in_concurrent()

    print("\n" + "=" * 70)
    print("Examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
