"""Circuit breaker patterns with dspu async utilities.

This example demonstrates circuit breaker patterns for preventing cascading
failures and allowing systems to recover from transient errors.
"""

import asyncio

from dspu.aio import CircuitBreaker, CircuitBreakerError, CircuitState, circuit_breaker


# Example 1: Basic circuit breaker
async def example_basic_circuit_breaker():
    """Basic circuit breaker to protect against failing services."""
    print("\n1. Basic Circuit Breaker:")
    print("-" * 50)

    cb = CircuitBreaker(failure_threshold=3, timeout=2.0)

    failure_count = 0

    async def unreliable_service():
        """Service that fails frequently."""
        nonlocal failure_count
        failure_count += 1

        # Fail first 5 times, then succeed
        if failure_count <= 5:
            raise ConnectionError("Service unavailable")
        return "Success!"

    # Make repeated calls
    for i in range(8):
        try:
            result = await cb.call(unreliable_service)
            print(f"  Attempt {i + 1}: {result} (State: {cb.state.value})")
        except CircuitBreakerError:
            print(f"  Attempt {i + 1}: Circuit OPEN - fast fail (State: {cb.state.value})")
        except ConnectionError as e:
            print(f"  Attempt {i + 1}: {e} (State: {cb.state.value})")

        await asyncio.sleep(0.3)


# Example 2: Circuit breaker with state change callbacks
async def example_with_callbacks():
    """Circuit breaker with state change notifications."""
    print("\n2. Circuit Breaker with State Change Callbacks:")
    print("-" * 50)

    async def on_state_change(old_state: CircuitState, new_state: CircuitState):
        """Callback for state changes."""
        print(f"  🔔 State changed: {old_state.value} → {new_state.value}")

    cb = CircuitBreaker(
        failure_threshold=2, success_threshold=2, timeout=1.0, on_state_change=on_state_change
    )

    call_count = 0

    async def flaky_service():
        """Service that eventually recovers."""
        nonlocal call_count
        call_count += 1

        # Fail first 3 calls, then succeed
        if call_count <= 3:
            raise RuntimeError("Service error")
        return "OK"

    for i in range(8):
        try:
            result = await cb.call(flaky_service)
            print(f"  Call {i + 1}: {result}")
        except (CircuitBreakerError, RuntimeError) as e:
            print(f"  Call {i + 1}: {type(e).__name__}")

        await asyncio.sleep(0.3)


# Example 3: Circuit breaker decorator
async def example_decorator():
    """Using circuit breaker as a decorator."""
    print("\n3. Circuit Breaker Decorator:")
    print("-" * 50)

    cb = CircuitBreaker(failure_threshold=2, timeout=1.5)

    attempts = 0

    @circuit_breaker(cb)
    async def call_external_api(endpoint: str):
        """Call external API with circuit breaker protection."""
        nonlocal attempts
        attempts += 1

        # Simulate failures
        if attempts <= 3:
            raise ConnectionError(f"Failed to reach {endpoint}")
        return f"Data from {endpoint}"

    for i in range(6):
        try:
            result = await call_external_api("/api/data")
            print(f"  Request {i + 1}: {result}")
        except Exception as e:
            print(f"  Request {i + 1}: {type(e).__name__}: {e}")

        await asyncio.sleep(0.4)


# Example 4: Context manager usage
async def example_context_manager():
    """Using circuit breaker as a context manager."""
    print("\n4. Circuit Breaker Context Manager:")
    print("-" * 50)

    cb = CircuitBreaker(failure_threshold=2, timeout=1.0)

    for i in range(5):
        try:
            async with cb.protect():
                print(f"  Executing operation {i + 1}...")

                # Simulate failures
                if i < 2:
                    raise RuntimeError("Operation failed")

                print(f"  ✓ Operation {i + 1} succeeded")
        except (CircuitBreakerError, RuntimeError) as e:
            print(f"  ✗ Operation {i + 1}: {type(e).__name__}")

        await asyncio.sleep(0.3)


# Example 5: Exception filtering
async def example_exception_filtering():
    """Circuit breaker with specific exception filtering."""
    print("\n5. Exception Filtering:")
    print("-" * 50)

    # Only count ConnectionError and TimeoutError as failures
    cb = CircuitBreaker(failure_threshold=2, exceptions=(ConnectionError, TimeoutError))

    attempts = 0

    async def service_with_mixed_errors():
        """Service that throws different types of errors."""
        nonlocal attempts
        attempts += 1

        if attempts == 1:
            raise ConnectionError("Network error")  # Counted
        if attempts == 2:
            raise ValueError("Invalid input")  # NOT counted
        if attempts == 3:
            raise ConnectionError("Network error")  # Counted
        if attempts == 4:
            raise TimeoutError("Timeout")  # Counted - circuit opens

        return "Success"

    for i in range(5):
        try:
            result = await cb.call(service_with_mixed_errors)
            print(f"  Call {i + 1}: {result} (failures: {cb.failure_count})")
        except Exception as e:
            print(
                f"  Call {i + 1}: {type(e).__name__} "
                f"(failures: {cb.failure_count}, state: {cb.state.value})"
            )

        await asyncio.sleep(0.2)


# Example 6: Service dependency management
class ServiceClient:
    """Client with circuit breaker for each dependency."""

    def __init__(self):
        # Separate circuit breakers for each service
        self.payment_cb = CircuitBreaker(
            failure_threshold=3, timeout=5.0, exceptions=(ConnectionError,)
        )
        self.inventory_cb = CircuitBreaker(
            failure_threshold=2, timeout=3.0, exceptions=(ConnectionError,)
        )
        self.notification_cb = CircuitBreaker(
            failure_threshold=5, timeout=2.0, exceptions=(ConnectionError,)
        )

        self.payment_failures = 0
        self.inventory_failures = 0
        self.notification_failures = 0

    async def process_payment(self, amount: float):
        """Process payment with circuit breaker."""
        async with self.payment_cb.protect():
            if self.payment_failures < 2:
                self.payment_failures += 1
                raise ConnectionError("Payment gateway unavailable")
            print(f"  💳 Payment of ${amount} processed")
            return {"status": "paid", "amount": amount}

    async def check_inventory(self, product_id: str):
        """Check inventory with circuit breaker."""
        async with self.inventory_cb.protect():
            if self.inventory_failures < 1:
                self.inventory_failures += 1
                raise ConnectionError("Inventory service down")
            print(f"  📦 Inventory checked for {product_id}")
            return {"product_id": product_id, "available": True}

    async def send_notification(self, user_id: str, _message: str):
        """Send notification with circuit breaker (non-critical)."""
        try:
            async with self.notification_cb.protect():
                print(f"  📧 Notification sent to {user_id}")
                return {"sent": True}
        except CircuitBreakerError:
            # Notifications are non-critical - degrade gracefully
            print("  ⚠️  Notification service unavailable - queued for later")
            return {"sent": False, "queued": True}


async def example_service_dependencies():
    """Managing multiple service dependencies with circuit breakers."""
    print("\n6. Service Dependency Management:")
    print("-" * 50)

    client = ServiceClient()

    async def process_order(order_id: int):
        """Process order using multiple services."""
        print(f"\nProcessing order #{order_id}:")

        try:
            # Check inventory
            _inventory = await client.check_inventory(f"PRODUCT-{order_id}")

            # Process payment
            _payment = await client.process_payment(99.99)

            # Send notification (non-critical)
            _notification = await client.send_notification(f"user-{order_id}", "Order confirmed")

            print(f"  ✓ Order #{order_id} completed")
            return {"order_id": order_id, "status": "success"}

        except CircuitBreakerError as e:
            print(f"  ✗ Order #{order_id} failed: Service unavailable")
            return {"order_id": order_id, "status": "failed", "reason": str(e)}
        except Exception as e:
            print(f"  ✗ Order #{order_id} failed: {e}")
            return {"order_id": order_id, "status": "failed", "reason": str(e)}

    # Process multiple orders
    for i in range(5):
        await process_order(i + 1)
        await asyncio.sleep(0.5)


# Example 7: Manual reset
async def example_manual_reset():
    """Manually reset circuit breaker."""
    print("\n7. Manual Circuit Breaker Reset:")
    print("-" * 50)

    cb = CircuitBreaker(failure_threshold=2, timeout=10.0)

    async def failing_service():
        """Service that always fails."""
        raise RuntimeError("Service error")

    # Open the circuit
    for i in range(2):
        try:
            await cb.call(failing_service)
        except RuntimeError:
            print(f"  Failure {i + 1}")

    print(f"  Circuit state: {cb.state.value}")

    # Manual intervention: service is fixed
    print("  🔧 Service manually fixed - resetting circuit breaker...")
    await cb.reset()
    print(f"  Circuit state after reset: {cb.state.value}")


# Example 8: Real-world pattern: Fallback to cache
async def example_cache_fallback():
    """Circuit breaker with cache fallback."""
    print("\n8. Cache Fallback Pattern:")
    print("-" * 50)

    cb = CircuitBreaker(failure_threshold=2, timeout=2.0)
    cache = {"user:1": {"name": "Cached User", "email": "cached@example.com"}}

    attempts = 0

    async def fetch_from_db(_user_id: int):
        """Fetch from database (may fail)."""
        nonlocal attempts
        attempts += 1

        if attempts <= 3:
            raise ConnectionError("Database unavailable")

        return {"name": "Live User", "email": "live@example.com"}

    async def get_user(user_id: int):
        """Get user with fallback to cache."""
        try:
            user = await cb.call(fetch_from_db, user_id)
            print(f"  ✓ User {user_id} from database: {user}")
            return user
        except CircuitBreakerError:
            # Circuit is open - use cache immediately
            user = cache.get(f"user:{user_id}", {"name": "Unknown", "email": ""})
            print(f"  📦 User {user_id} from cache (circuit open): {user}")
            return user
        except ConnectionError:
            # Individual failure - try cache
            user = cache.get(f"user:{user_id}", {"name": "Unknown", "email": ""})
            print(f"  📦 User {user_id} from cache (fallback): {user}")
            return user

    for _ in range(6):
        await get_user(1)
        await asyncio.sleep(0.3)


async def main():
    """Run all circuit breaker examples."""
    print("=" * 70)
    print("Circuit Breaker Patterns Examples")
    print("=" * 70)

    await example_basic_circuit_breaker()
    await example_with_callbacks()
    await example_decorator()
    await example_context_manager()
    await example_exception_filtering()
    await example_service_dependencies()
    await example_manual_reset()
    await example_cache_fallback()

    print("\n" + "=" * 70)
    print("Examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
