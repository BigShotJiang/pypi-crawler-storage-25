"""Retry patterns with dspu async utilities.

This example demonstrates various retry patterns for handling transient failures
in async operations like API calls, database queries, and network requests.
"""

import asyncio
import random

from dspu.aio import BackoffStrategy, retry, retry_async


# Example 1: Basic retry with exponential backoff
@retry(max_attempts=5, strategy=BackoffStrategy.EXPONENTIAL, base_delay=0.5)
async def fetch_data_from_api(url: str) -> dict:
    """Fetch data from an unreliable API with automatic retries."""
    print(f"Attempting to fetch: {url}")

    # Simulate random failures
    if random.random() < 0.6:  # 60% failure rate
        raise ConnectionError("API temporarily unavailable")

    return {"url": url, "data": "Success!"}


# Example 2: Retry with custom exception filtering
@retry(
    max_attempts=3,
    strategy=BackoffStrategy.LINEAR,
    base_delay=1.0,
    exceptions=(ConnectionError, TimeoutError),  # Only retry these
)
async def connect_to_database(host: str, port: int) -> str:
    """Connect to database, retrying only connection errors."""
    print(f"Connecting to {host}:{port}")

    # Simulate different error types
    rand = random.random()
    if rand < 0.3:
        raise ConnectionError("Connection refused")
    if rand < 0.6:
        raise TimeoutError("Connection timeout")
    if rand < 0.7:
        raise ValueError("Invalid credentials")  # Won't be retried!

    return f"Connected to {host}:{port}"


# Example 3: Retry with callback for logging
async def log_retry(attempt: int, exception: Exception) -> None:
    """Callback function called on each retry."""
    print(f"  ⚠️  Retry attempt {attempt} after error: {type(exception).__name__}")


@retry(
    max_attempts=4,
    strategy=BackoffStrategy.EXPONENTIAL,
    base_delay=0.5,
    on_retry=log_retry,
)
async def process_with_logging(item: str) -> str:
    """Process item with detailed retry logging."""
    if random.random() < 0.5:
        raise RuntimeError("Processing failed")
    return f"Processed: {item}"


# Example 4: Using retry_async for dynamic retry configuration
async def fetch_with_dynamic_retry(url: str, max_attempts: int) -> dict:
    """Fetch data with dynamically configured retry logic."""

    async def fetch():
        print(f"Fetching {url}")
        if random.random() < 0.6:
            raise ConnectionError("Temporary failure")
        return {"url": url, "status": "ok"}

    return await retry_async(
        fetch,
        max_attempts=max_attempts,
        strategy=BackoffStrategy.EXPONENTIAL,
        base_delay=0.3,
    )


# Example 5: Combining retry with real-world patterns
class APIClient:
    """API client with built-in retry logic."""

    def __init__(self, base_url: str):
        self.base_url = base_url
        self.request_count = 0

    @retry(max_attempts=3, strategy=BackoffStrategy.EXPONENTIAL, base_delay=1.0)
    async def get(self, endpoint: str) -> dict:
        """GET request with automatic retries."""
        self.request_count += 1
        url = f"{self.base_url}{endpoint}"
        print(f"GET {url} (attempt #{self.request_count})")

        # Simulate failures
        if random.random() < 0.5:
            raise ConnectionError("Network error")

        return {"endpoint": endpoint, "data": f"Response from {url}"}

    @retry(
        max_attempts=5,
        strategy=BackoffStrategy.EXPONENTIAL,
        base_delay=0.5,
        jitter=True,  # Add random jitter to prevent thundering herd
    )
    async def post(self, endpoint: str, data: dict) -> dict:
        """POST request with jittered exponential backoff."""
        url = f"{self.base_url}{endpoint}"
        print(f"POST {url}")

        if random.random() < 0.4:
            raise ConnectionError("Temporary failure")

        return {"endpoint": endpoint, "posted": data}


# Example 6: Graceful degradation with retry fallback
async def fetch_user_data_with_fallback(user_id: int) -> dict:
    """Fetch user data with retry, falling back to cache on failure."""
    cache = {"1": {"name": "Cached User", "id": 1}}

    try:
        return await retry_async(
            fetch_from_primary_db,
            user_id,
            max_attempts=3,
            base_delay=0.5,
        )
    except Exception as e:
        print(f"All retries failed: {e}, using cache")
        return cache.get(str(user_id), {"name": "Unknown", "id": user_id})


async def fetch_from_primary_db(user_id: int) -> dict:
    """Fetch from primary database (may fail)."""
    if random.random() < 0.8:
        raise ConnectionError("Database unavailable")
    return {"name": "Live User", "id": user_id}


async def main():
    """Run all retry pattern examples."""
    print("=" * 70)
    print("Retry Patterns Examples")
    print("=" * 70)

    # Example 1: Basic exponential retry
    print("\n1. Basic Exponential Backoff:")
    print("-" * 50)
    try:
        result = await fetch_data_from_api("https://api.example.com/data")
        print(f"✓ Success: {result}")
    except Exception as e:
        print(f"✗ Failed: {e}")

    # Example 2: Exception filtering
    print("\n2. Exception Filtering:")
    print("-" * 50)
    try:
        result = await connect_to_database("db.example.com", 5432)
        print(f"✓ {result}")
    except ValueError as e:
        print(f"✗ Not retried (ValueError): {e}")
    except Exception as e:
        print(f"✗ Failed after retries: {e}")

    # Example 3: Retry with logging
    print("\n3. Retry with Logging:")
    print("-" * 50)
    try:
        result = await process_with_logging("important-item")
        print(f"✓ {result}")
    except Exception as e:
        print(f"✗ {e}")

    # Example 4: Dynamic retry configuration
    print("\n4. Dynamic Retry Configuration:")
    print("-" * 50)
    try:
        result = await fetch_with_dynamic_retry("https://api.example.com/v2", max_attempts=4)
        print(f"✓ Success: {result}")
    except Exception as e:
        print(f"✗ Failed: {e}")

    # Example 5: API client with retries
    print("\n5. API Client with Built-in Retries:")
    print("-" * 50)
    client = APIClient("https://api.example.com")
    try:
        get_result = await client.get("/users/123")
        print(f"✓ GET: {get_result}")

        post_result = await client.post("/users", {"name": "New User"})
        print(f"✓ POST: {post_result}")
    except Exception as e:
        print(f"✗ API call failed: {e}")

    # Example 6: Graceful degradation
    print("\n6. Graceful Degradation with Cache Fallback:")
    print("-" * 50)
    result = await fetch_user_data_with_fallback(1)
    print(f"✓ User data: {result}")

    print("\n" + "=" * 70)
    print("Examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
