

# DSPU Async (AIO) Examples

Comprehensive examples showcasing all features of the `dspu.aio` async utilities module.

## 📁 Examples Overview

### [01_retry_patterns.py](01_retry_patterns.py)
**Retry mechanisms for transient failures**

Demonstrates:
- ✅ Basic exponential backoff retry
- ✅ Exception filtering (retry only specific errors)
- ✅ Retry callbacks for logging/monitoring
- ✅ Dynamic retry configuration
- ✅ API client with built-in retries
- ✅ Graceful degradation with cache fallback

**Use Cases:**
- API calls that may fail temporarily
- Database connection retries
- Network request resilience
- Distributed system communication

**Run:** `uv run python examples/aio/01_retry_patterns.py`

---

### [02_rate_limiting.py](02_rate_limiting.py)
**Rate limiting for resource management**

Demonstrates:
- ✅ Basic rate limiting (requests per second)
- ✅ Burst capacity for bursty workloads
- ✅ Rate limit decorator
- ✅ Weighted rate limiting (different token costs)
- ✅ Conditional rate limiting
- ✅ Multiple rate limiters for different resources
- ✅ Try-acquire for optional operations
- ✅ Dynamic rate adjustment

**Use Cases:**
- API rate limit compliance
- Database connection pooling
- Resource throttling
- Load management
- Cost control for metered APIs

**Run:** `uv run python examples/aio/02_rate_limiting.py`

---

### [03_circuit_breaker.py](03_circuit_breaker.py)
**Circuit breaker pattern for fault tolerance**

Demonstrates:
- ✅ Basic circuit breaker (CLOSED → OPEN → HALF_OPEN)
- ✅ State change callbacks
- ✅ Circuit breaker decorator
- ✅ Context manager usage
- ✅ Exception filtering
- ✅ Service dependency management
- ✅ Manual circuit reset
- ✅ Cache fallback pattern

**Use Cases:**
- Microservices communication
- External API calls
- Database connection failures
- Preventing cascading failures
- Service degradation
- System recovery

**Run:** `uv run python examples/aio/03_circuit_breaker.py`

---

### [04_concurrency_and_bridge.py](04_concurrency_and_bridge.py)
**Concurrency control and sync/async bridging**

Demonstrates:
- ✅ Concurrent execution with limits (`gather_with_limit`)
- ✅ Timeout management
- ✅ Running sync code in async context
- ✅ Running async code from sync context
- ✅ Sync-to-async conversion
- ✅ Async-to-sync conversion
- ✅ Mixed sync/async pipelines
- ✅ Parallel processing
- ✅ Cache-aside pattern
- ✅ Error handling in concurrent operations

**Use Cases:**
- Controlling concurrency for rate-limited APIs
- Mixing sync libraries with async code
- Legacy code integration
- CPU-bound operations in async context
- Timeout enforcement
- Parallel data processing

**Run:** `uv run python examples/aio/04_concurrency_and_bridge.py`

---

## 🚀 Quick Start

### Prerequisites

Install dspu with async dependencies:

```bash
cd /path/to/dspu
uv sync --extra async
```

### Running Examples

Run individual examples:

```bash
# Retry patterns
uv run python examples/aio/01_retry_patterns.py

# Rate limiting
uv run python examples/aio/02_rate_limiting.py

# Circuit breaker
uv run python examples/aio/03_circuit_breaker.py

# Concurrency and bridge
uv run python examples/aio/04_concurrency_and_bridge.py
```

Or run all examples:

```bash
for f in examples/aio/*.py; do uv run python "$f"; done
```

---

## 📚 Common Patterns

### Pattern 1: Resilient API Client

```python
from dspu.aio import retry, RateLimiter, CircuitBreaker, BackoffStrategy

# Create utilities
limiter = RateLimiter(rate=10.0)  # 10 req/s
circuit_breaker = CircuitBreaker(failure_threshold=5, timeout=60.0)

@retry(max_attempts=3, strategy=BackoffStrategy.EXPONENTIAL)
async def call_api(endpoint: str):
    # Rate limit
    async with limiter.limit():
        # Circuit breaker protection
        async with circuit_breaker.protect():
            # Make API call
            return await http_client.get(endpoint)
```

### Pattern 2: Controlled Parallel Processing

```python
from dspu.aio import gather_with_limit, run_in_executor

async def process_items(items: list):
    """Process items in parallel with concurrency limit."""

    def cpu_intensive_work(item):
        # CPU-bound work
        return expensive_calculation(item)

    # Convert to async and process with limit
    async_work = sync_to_async(cpu_intensive_work)

    results = await gather_with_limit(
        *[async_work(item) for item in items],
        limit=4  # Max 4 concurrent
    )

    return results
```

### Pattern 3: Graceful Degradation

```python
from dspu.aio import CircuitBreaker, retry

circuit_breaker = CircuitBreaker(failure_threshold=3, timeout=30.0)
cache = {}

async def get_data(key: str):
    """Get data with cache fallback."""
    try:
        # Try primary source with circuit breaker
        async with circuit_breaker.protect():
            return await fetch_from_primary(key)
    except CircuitBreakerError:
        # Circuit open - use cache immediately
        return cache.get(key, default_value)
    except Exception:
        # Other errors - still try cache
        return cache.get(key, default_value)
```

### Pattern 4: Timeout with Fallback

```python
from dspu.aio import run_with_timeout_or_default

async def fetch_with_timeout(url: str):
    """Fetch with timeout, return cached data on timeout."""
    return await run_with_timeout_or_default(
        fetch_from_api(url),
        timeout=2.0,
        default=get_from_cache(url)
    )
```

---

## 🎯 Feature Matrix

| Feature | Retry | Rate Limiter | Circuit Breaker | Concurrency | Bridge |
|---------|-------|--------------|-----------------|-------------|--------|
| Decorator | ✅ | ✅ | ✅ | ❌ | ✅ |
| Context Manager | ❌ | ✅ | ✅ | ✅ | ❌ |
| Functional API | ✅ | ✅ | ✅ | ✅ | ✅ |
| Callbacks | ✅ | ❌ | ✅ | ❌ | ❌ |
| Exception Filtering | ✅ | ❌ | ✅ | ❌ | ❌ |
| Backoff Strategies | ✅ | ❌ | ❌ | ❌ | ❌ |
| State Management | ❌ | ✅ | ✅ | ❌ | ❌ |

---

## 📖 API Reference

### Retry

```python
from dspu.aio import retry, retry_async, BackoffStrategy

# Decorator
@retry(
    max_attempts=5,
    strategy=BackoffStrategy.EXPONENTIAL,
    base_delay=1.0,
    max_delay=60.0,
    jitter=True,
    exceptions=(Exception,),
    on_retry=callback_func
)
async def my_function():
    ...

# Functional
result = await retry_async(
    my_function,
    max_attempts=3,
    strategy=BackoffStrategy.LINEAR
)
```

### Rate Limiter

```python
from dspu.aio import RateLimiter, rate_limit

# Create limiter
limiter = RateLimiter(rate=10.0, capacity=20.0)

# Context manager
async with limiter.limit(tokens=1.0):
    await make_request()

# Decorator
@rate_limit(limiter, tokens=2.0)
async def expensive_operation():
    ...

# Direct acquire
await limiter.acquire(1.0)
if await limiter.try_acquire(1.0):
    # Got tokens
    ...
```

### Circuit Breaker

```python
from dspu.aio import CircuitBreaker, circuit_breaker, CircuitState

# Create circuit breaker
cb = CircuitBreaker(
    failure_threshold=5,
    success_threshold=2,
    timeout=60.0,
    exceptions=(ConnectionError,),
    on_state_change=state_callback
)

# Context manager
async with cb.protect():
    await external_service()

# Decorator
@circuit_breaker(cb)
async def call_service():
    ...

# Direct call
result = await cb.call(my_function, arg1, arg2)

# Manual reset
await cb.reset()

# Check state
if cb.state == CircuitState.OPEN:
    # Circuit is open
    ...
```

### Concurrency

```python
from dspu.aio import (
    gather_with_limit,
    run_with_timeout,
    run_in_executor,
    Timeout
)

# Gather with limit
results = await gather_with_limit(
    *tasks,
    limit=10,
    return_exceptions=True
)

# Timeout
result = await run_with_timeout(operation(), timeout=5.0)

# Timeout context manager
async with Timeout(5.0):
    await operation()

# Run sync code
result = await run_in_executor(sync_function, arg1, arg2)
```

### Bridge

```python
from dspu.aio import (
    sync_to_async,
    async_to_sync,
    run_async
)

# Convert sync to async
async_func = sync_to_async(sync_function)
result = await async_func(arg)

# Convert async to sync
sync_func = async_to_sync(async_function)
result = sync_func(arg)

# Run async from sync code
result = run_async(async_function())
```

---

## 💡 Best Practices

### 1. Combining Utilities

Stack utilities for comprehensive resilience:

```python
@retry(max_attempts=3)
@rate_limit(api_limiter)
@circuit_breaker(api_breaker)
async def robust_api_call(endpoint: str):
    return await http_client.get(endpoint)
```

### 2. Resource-Specific Configuration

Use different configurations for different resources:

```python
# Aggressive retries for cache (fast)
@retry(max_attempts=5, base_delay=0.1)
async def get_from_cache(key):
    ...

# Conservative retries for external API (slow)
@retry(max_attempts=3, base_delay=2.0)
async def call_external_api(endpoint):
    ...
```

### 3. Monitoring and Observability

Use callbacks for monitoring:

```python
async def log_retry(attempt: int, exception: Exception):
    logger.warning(f"Retry {attempt}: {exception}")
    metrics.increment("retries", tags=["exception": type(exception).__name__])

async def on_circuit_state_change(old: CircuitState, new: CircuitState):
    logger.info(f"Circuit state: {old} → {new}")
    metrics.gauge("circuit_state", new.value)

@retry(on_retry=log_retry)
async def monitored_operation():
    ...
```

### 4. Graceful Degradation

Always have fallback mechanisms:

```python
async def get_user_data(user_id: int):
    try:
        return await fetch_from_db(user_id)
    except CircuitBreakerError:
        return get_from_cache(user_id)
    except Exception:
        return get_default_user()
```

---

## 🔧 Troubleshooting

### High Retry Latency

**Problem:** Operations take too long due to retries

**Solution:**
- Reduce `max_attempts`
- Use shorter `base_delay`
- Use `BackoffStrategy.CONSTANT` instead of `EXPONENTIAL`
- Set aggressive `max_delay` cap

### Circuit Breaker Stuck Open

**Problem:** Circuit breaker stays open even after service recovers

**Solution:**
- Reduce `timeout` duration
- Lower `failure_threshold`
- Use manual `reset()` after confirming service health
- Check `success_threshold` isn't too high

### Rate Limiter Too Restrictive

**Problem:** Operations are being throttled too much

**Solution:**
- Increase `rate` parameter
- Increase `capacity` for burst allowance
- Use `try_acquire()` for optional operations
- Consider per-user/per-resource limiters

### Timeout Errors

**Problem:** Operations timing out unexpectedly

**Solution:**
- Increase timeout duration
- Use `run_with_timeout_or_default` with fallback
- Check for blocking operations in async code
- Use `run_in_executor` for CPU-bound work

---

## 📝 Notes

- All examples use simulated failures with `random` for demonstration
- Adjust delays and thresholds for your specific use case
- Always test resilience patterns under load
- Monitor and adjust based on production metrics
- Consider using these patterns together for maximum resilience

---

## 🌟 Highlights

**What makes dspu.aio great:**

✅ **Production-ready** - Battle-tested patterns
✅ **Type-safe** - Full type hints with Pyrefly
✅ **Well-tested** - 126 comprehensive tests
✅ **Flexible** - Multiple interfaces (decorator, context manager, functional)
✅ **Documented** - Extensive examples and API docs
✅ **Performant** - Efficient async implementation
✅ **Composable** - Utilities work together seamlessly

---

### Support

For issues or questions:
- [GitHub Issues](https://github.com/deepsaia/dspu/issues)
- [Documentation](https://deepsaia.github.io/dspu)
