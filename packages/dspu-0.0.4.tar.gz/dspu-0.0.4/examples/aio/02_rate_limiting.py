"""Rate limiting patterns with dspu async utilities.

This example demonstrates various rate limiting patterns for controlling
request rates to APIs, databases, or any rate-limited resources.
"""

import asyncio
import time

from dspu.aio import RateLimiter, rate_limit


# Example 1: Basic rate limiting for API calls
async def example_basic_rate_limiting():
    """Basic rate limiting to respect API rate limits."""
    print("\n1. Basic Rate Limiting (10 requests/second):")
    print("-" * 50)

    limiter = RateLimiter(rate=10.0)  # 10 requests per second

    async def make_api_call(request_id: int):
        """Make a rate-limited API call."""
        async with limiter.limit():
            timestamp = time.time()
            print(f"Request #{request_id} at {timestamp:.2f}")
            return f"Response {request_id}"

    # Make 15 requests - should take ~1.5 seconds
    start = time.time()
    _results = await asyncio.gather(*[make_api_call(i) for i in range(15)])
    elapsed = time.time() - start

    print(f"✓ Completed 15 requests in {elapsed:.2f}s")
    print(f"  Effective rate: {15 / elapsed:.1f} req/s")


# Example 2: Rate limiting with burst capacity
async def example_burst_capacity():
    """Rate limiting with burst capacity for bursty workloads."""
    print("\n2. Rate Limiting with Burst Capacity:")
    print("-" * 50)

    # Allow 5 req/s sustained, but burst up to 10
    limiter = RateLimiter(rate=5.0, capacity=10.0)

    async def send_request(req_id: int):
        """Send a request."""
        await limiter.acquire()
        print(f"  Request #{req_id} sent")

    # Send 10 requests immediately (uses burst capacity)
    print("Sending 10 requests (burst)...")
    await asyncio.gather(*[send_request(i) for i in range(10)])

    # Wait and send more
    await asyncio.sleep(1.0)
    print("Sending 5 more requests...")
    await asyncio.gather(*[send_request(i) for i in range(10, 15)])


# Example 3: Rate limiting decorator
limiter = RateLimiter(rate=5.0)


@rate_limit(limiter)
async def fetch_user_data(user_id: int) -> dict:
    """Fetch user data with automatic rate limiting."""
    print(f"  Fetching user {user_id}")
    await asyncio.sleep(0.1)  # Simulate API call
    return {"user_id": user_id, "name": f"User {user_id}"}


async def example_decorator():
    """Using rate limit decorator."""
    print("\n3. Rate Limiting Decorator:")
    print("-" * 50)

    # Fetch multiple users
    users = await asyncio.gather(*[fetch_user_data(i) for i in range(10)])
    print(f"✓ Fetched {len(users)} users")


# Example 4: Different costs for different operations
async def example_weighted_rate_limiting():
    """Rate limiting with different token costs."""
    print("\n4. Weighted Rate Limiting:")
    print("-" * 50)

    limiter = RateLimiter(rate=10.0, capacity=20.0)

    async def lightweight_op():
        """Lightweight operation (1 token)."""
        async with limiter.limit(tokens=1.0):
            print("  ⚡ Lightweight operation")

    async def heavy_op():
        """Heavy operation (5 tokens)."""
        async with limiter.limit(tokens=5.0):
            print("  🔥 Heavy operation (costs 5x)")

    # Mix of operations
    await lightweight_op()
    await lightweight_op()
    await heavy_op()
    await lightweight_op()
    print("✓ All operations completed")


# Example 5: Conditional rate limiting
async def example_conditional_rate_limiting():
    """Only rate limit certain operations."""
    print("\n5. Conditional Rate Limiting:")
    print("-" * 50)

    limiter = RateLimiter(rate=5.0)

    async def process_item(item_id: int, is_premium: bool):
        """Process item, rate limiting only non-premium users."""
        if not is_premium:
            await limiter.acquire()
            print(f"  Processing item {item_id} (rate limited)")
        else:
            print(f"  Processing item {item_id} (premium - no limit)")

    # Mix of premium and regular users
    tasks = [
        process_item(1, is_premium=False),
        process_item(2, is_premium=True),
        process_item(3, is_premium=False),
        process_item(4, is_premium=True),
        process_item(5, is_premium=False),
    ]
    await asyncio.gather(*tasks)


# Example 6: Multiple rate limiters for different resources
class MultiAPIClient:
    """Client with separate rate limiters for different APIs."""

    def __init__(self):
        self.api_a_limiter = RateLimiter(rate=10.0)  # API A: 10 req/s
        self.api_b_limiter = RateLimiter(rate=5.0)  # API B: 5 req/s
        self.db_limiter = RateLimiter(rate=50.0)  # DB: 50 req/s

    async def call_api_a(self, endpoint: str):
        """Call API A with its rate limit."""
        async with self.api_a_limiter.limit():
            print(f"  API A: {endpoint}")
            return f"Response from API A: {endpoint}"

    async def call_api_b(self, endpoint: str):
        """Call API B with its rate limit."""
        async with self.api_b_limiter.limit():
            print(f"  API B: {endpoint}")
            return f"Response from API B: {endpoint}"

    async def query_db(self, query: str):
        """Query database with its rate limit."""
        async with self.db_limiter.limit():
            print(f"  DB: {query}")
            return f"DB result: {query}"


async def example_multi_resource():
    """Multiple rate limiters for different resources."""
    print("\n6. Multiple Rate Limiters:")
    print("-" * 50)

    client = MultiAPIClient()

    # Make concurrent calls to different services
    results = await asyncio.gather(
        client.call_api_a("/users"),
        client.call_api_b("/data"),
        client.query_db("SELECT * FROM users"),
        client.call_api_a("/posts"),
        client.call_api_b("/stats"),
    )
    print(f"✓ Completed {len(results)} calls")


# Example 7: Try acquire for optional operations
async def example_try_acquire():
    """Try acquire for non-critical operations."""
    print("\n7. Try Acquire (Optional Operations):")
    print("-" * 50)

    limiter = RateLimiter(rate=2.0, capacity=2.0)

    async def critical_operation(op_id: int):
        """Critical operation that must complete."""
        await limiter.acquire()
        print(f"  ✓ Critical op {op_id} executed")

    async def optional_operation(op_id: int):
        """Optional operation - skip if rate limited."""
        if await limiter.try_acquire():
            print(f"  ⚡ Optional op {op_id} executed")
        else:
            print(f"  ⏭️  Optional op {op_id} skipped (rate limited)")

    # Mix of critical and optional operations
    await critical_operation(1)
    await critical_operation(2)
    await optional_operation(1)  # Will be skipped
    await asyncio.sleep(0.6)  # Wait for tokens to refill
    await optional_operation(2)  # Should succeed


# Example 8: Dynamic rate adjustment
async def example_dynamic_rate():
    """Dynamically adjust rate based on conditions."""
    print("\n8. Dynamic Rate Adjustment:")
    print("-" * 50)

    limiter = RateLimiter(rate=5.0)

    async def adjust_rate_based_on_time():
        """Adjust rate based on time of day (simulated)."""
        import random

        is_peak_hour = random.choice([True, False])

        if is_peak_hour:
            print("  ⏰ Peak hours detected - slowing down")
            # During peak, acquire more tokens per request
            await limiter.acquire(2.0)
        else:
            print("  ⏰ Off-peak hours - normal rate")
            await limiter.acquire(1.0)

        print("    Request processed")

    for _ in range(5):
        await adjust_rate_based_on_time()


async def main():
    """Run all rate limiting examples."""
    print("=" * 70)
    print("Rate Limiting Patterns Examples")
    print("=" * 70)

    await example_basic_rate_limiting()
    await example_burst_capacity()
    await example_decorator()
    await example_weighted_rate_limiting()
    await example_conditional_rate_limiting()
    await example_multi_resource()
    await example_try_acquire()
    await example_dynamic_rate()

    print("\n" + "=" * 70)
    print("Examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
