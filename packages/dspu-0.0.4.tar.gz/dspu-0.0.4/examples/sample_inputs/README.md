# Sample Input Files

This directory contains sample input files used by the I/O examples.

## Files

### Configuration Files

- **sample_config.yaml** - Sample application configuration in YAML format
  - Demonstrates nested configuration structure
  - Includes common config sections (server, database, logging, etc.)
  - Use this to test reading YAML configs

### Data Files

- **sample_data.json** - Sample JSON data with users and metadata
  - Shows structured data format
  - Includes arrays, objects, and nested structures
  - Use this to test JSON reading and processing

- **products.csv** - Sample product catalog in CSV format
  - Contains 15 sample products
  - Headers: id, name, category, price, stock, rating, available
  - Use this to test CSV reading and tabular data processing

### Environment Files

- **.env.sample** - Sample environment variables template
  - Copy to `.env` and customize for your needs
  - Includes common environment variables for applications
  - Never commit actual `.env` files with secrets!

## Usage in Examples

These files are referenced by various examples:

```python
from dspu.io import Storage

# Read sample config
storage = Storage.from_uri("./examples/sample_inputs")
config = await storage.read_format("sample_config.yaml")

# Read sample data
data = await storage.read_format("sample_data.json")

# Read CSV
products = await storage.read_format("products.csv")
```

## Creating Your Own Sample Files

Feel free to add more sample files here for testing:

```python
# Write your own samples
storage = Storage.from_uri("./examples/sample_inputs")

await storage.write_format("my_config.toml", my_config)
await storage.write_format("my_data.yaml", my_data)
```

## Security Note

⚠️ **Important:** Never commit files with real credentials or secrets!

- Use `.env.sample` as a template
- Add actual `.env` to `.gitignore`
- Use placeholder values in sample files

## Format Support

You can create sample files in any of these formats:

- **Structured:** .json, .yaml, .yml, .toml, .conf, .hocon
- **Text:** .txt, .md, .py
- **Tabular:** .csv
- **Config:** .env

See the examples in `../io/` for how to work with each format.
