"""Streaming large files with dspu.

This example demonstrates:
- Streaming reads for large files
- Streaming writes with async generators
- Processing data in chunks
- Memory-efficient file operations
"""

import asyncio
from pathlib import Path

from dspu.io import Storage


async def generate_large_data():
    """Generate large data as an async generator.

    This simulates processing large datasets that don't fit in memory.
    """
    print("Generating data chunks...")
    for i in range(1000):
        chunk = f"Line {i}: " + "x" * 100 + "\n"
        yield chunk.encode("utf-8")
        if i % 100 == 0:
            print(f"  Generated {i} chunks...")
            await asyncio.sleep(0.01)  # Simulate processing time


async def process_chunk(chunk: bytes, chunk_number: int) -> dict:
    """Process a single chunk of data.

    Args:
        chunk: Raw bytes to process.
        chunk_number: The chunk number.

    Returns:
        Processing statistics.
    """
    # Simulate some processing
    lines = chunk.decode("utf-8").count("\n")
    chars = len(chunk)

    return {
        "chunk": chunk_number,
        "lines": lines,
        "chars": chars,
        "sample": chunk[:50].decode("utf-8", errors="ignore"),
    }


async def main():
    """Demonstrate streaming file operations."""
    # Setup
    output_dir = Path("./examples/sample_outputs/streaming")
    output_dir.mkdir(parents=True, exist_ok=True)

    storage = Storage.from_uri(str(output_dir))

    print("=== Streaming Large Files ===\n")

    # 1. Write large file using streaming
    print("1. Writing large file with streaming...")
    await storage.write_stream("large_file.txt", generate_large_data())
    print("✓ Large file written using streaming\n")

    # Check file size
    file_info = (await storage.list("large_file.txt"))[0]
    print(f"File size: {file_info.size:,} bytes ({file_info.size / 1024:.2f} KB)\n")

    # 2. Read large file using streaming
    print("2. Reading large file with streaming...")
    chunk_count = 0
    total_size = 0
    stats_list = []

    async for chunk in storage.read_stream("large_file.txt", chunk_size=8192):
        total_size += len(chunk)
        stats = await process_chunk(chunk, chunk_count)
        stats_list.append(stats)
        chunk_count += 1

        if chunk_count % 5 == 0:
            print(f"  Processed {chunk_count} chunks ({total_size:,} bytes)...")

    print(f"✓ Processed {chunk_count} chunks totaling {total_size:,} bytes\n")

    # 3. Show statistics
    print("3. Processing statistics:")
    print(f"  Total chunks: {len(stats_list)}")
    print(f"  Total lines: {sum(s['lines'] for s in stats_list)}")
    print(f"  Total chars: {sum(s['chars'] for s in stats_list):,}")
    print(f"  Average chunk size: {total_size / len(stats_list):.0f} bytes")
    print(f"\n  First chunk sample: {stats_list[0]['sample']}...")
    print(f"  Last chunk sample: {stats_list[-1]['sample']}...\n")

    # 4. Process and transform while streaming
    print("4. Transform data while streaming...")

    async def transform_and_generate():
        """Read, transform, and write data in one streaming operation."""
        line_number = 0
        async for chunk in storage.read_stream("large_file.txt", chunk_size=4096):
            # Transform: add line numbers and uppercase
            lines = chunk.decode("utf-8").splitlines(keepends=True)
            for line in lines:
                transformed = f"[{line_number:06d}] {line.upper()}"
                yield transformed.encode("utf-8")
                line_number += 1

    await storage.write_stream("transformed.txt", transform_and_generate())
    print("✓ Transformed file written\n")

    # 5. Stream first few lines to verify
    print("5. Verifying transformed file (first 5 lines)...")
    first_chunk = None
    async for chunk in storage.read_stream("transformed.txt", chunk_size=1024):
        first_chunk = chunk
        break

    if first_chunk:
        lines = first_chunk.decode("utf-8").splitlines()[:5]
        for line in lines:
            print(f"  {line}")
    print()

    # 6. Memory-efficient CSV processing
    print("6. Streaming CSV-like data...")

    async def generate_csv_data():
        """Generate CSV data as chunks."""
        # Header
        yield b"id,name,value,timestamp\n"

        # Data rows
        for i in range(10000):
            row = f"{i},User_{i},{i * 100},2024-01-{(i % 30) + 1:02d}\n"
            yield row.encode("utf-8")

            if i % 1000 == 0 and i > 0:
                print(f"  Generated {i} CSV rows...")

    await storage.write_stream("data.csv", generate_csv_data())
    print("✓ CSV data file created\n")

    # 7. Read and parse CSV in chunks
    print("7. Processing CSV in chunks...")
    row_count = 0
    sample_rows = []

    async for chunk in storage.read_stream("data.csv", chunk_size=4096):
        lines = chunk.decode("utf-8").splitlines()
        for line in lines:
            if row_count == 0:  # Skip header
                row_count += 1
                continue

            if row_count < 5:  # Collect samples
                parts = line.split(",")
                if len(parts) == 4:
                    sample_rows.append(
                        {
                            "id": parts[0],
                            "name": parts[1],
                            "value": parts[2],
                            "timestamp": parts[3],
                        }
                    )

            row_count += 1

    print(f"✓ Processed {row_count - 1} CSV rows")
    print("\n  Sample rows:")
    for row in sample_rows[:3]:
        print(f"    {row}")
    print()

    # 8. Cleanup and summary
    print("8. File summary:")
    files = await storage.list("*")
    print("Created files:")
    for file in files:
        size_kb = file.size / 1024
        print(f"  - {file.path}: {size_kb:.2f} KB")

    print("\n=== Streaming operations complete! ===")
    print("\nKey benefits of streaming:")
    print("  ✓ Handles files larger than available memory")
    print("  ✓ Processes data incrementally")
    print("  ✓ Lower memory footprint")
    print("  ✓ Can start processing before full download completes")


if __name__ == "__main__":
    asyncio.run(main())
