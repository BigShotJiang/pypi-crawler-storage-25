"""Basic file operations with dspu Storage.

This example demonstrates:
- Creating a Storage instance
- Writing and reading files
- Checking file existence
- Listing files
- Deleting files
"""

import asyncio
from pathlib import Path

from dspu.io import Storage


async def main():
    """Demonstrate basic file operations."""
    # Create a temporary storage directory
    storage_dir = Path("./examples/sample_outputs/basic")
    storage_dir.mkdir(parents=True, exist_ok=True)

    # Initialize storage for local filesystem
    storage = Storage.from_uri(str(storage_dir))

    print("=== Basic File Operations ===\n")

    # 1. Write a file
    print("1. Writing data to file...")
    data = {"message": "Hello from dspu!", "version": "1.0.0"}
    await storage.write("hello.json", data)
    print(f"✓ Written to {storage_dir}/hello.json\n")

    # 2. Read the file back
    print("2. Reading data from file...")
    result = await storage.read("hello.json")
    print(f"✓ Read data: {result}\n")

    # 3. Check if file exists
    print("3. Checking file existence...")
    exists = await storage.exists("hello.json")
    print(f"✓ File exists: {exists}")
    missing = await storage.exists("missing.json")
    print(f"✓ Missing file exists: {missing}\n")

    # 4. Write more files
    print("4. Writing multiple files...")
    await storage.write("data1.json", {"id": 1, "name": "Alice"})
    await storage.write("data2.json", {"id": 2, "name": "Bob"})
    await storage.write("data3.json", {"id": 3, "name": "Charlie"})
    print("✓ Written 3 more files\n")

    # 5. List all files
    print("5. Listing all files...")
    files = await storage.list("*.json")
    print("Files found:")
    for file in files:
        print(f"  - {file.path} ({file.size} bytes)")
    print()

    # 6. Delete a file
    print("6. Deleting a file...")
    await storage.delete("hello.json")
    print("✓ Deleted hello.json")
    exists_after = await storage.exists("hello.json")
    print(f"✓ File exists after deletion: {exists_after}\n")

    # 7. Write raw bytes
    print("7. Writing raw bytes...")
    raw_data = b"This is raw binary data"
    await storage.write("raw_data.bin", raw_data, raw=True)
    print("✓ Written raw bytes to raw_data.bin\n")

    # 8. Read raw bytes
    print("8. Reading raw bytes...")
    raw_result = await storage.read("raw_data.bin", raw=True)
    print(f"✓ Read {len(raw_result)} bytes: {raw_result[:20]}...\n")

    print("=== All operations completed successfully! ===")


if __name__ == "__main__":
    asyncio.run(main())
