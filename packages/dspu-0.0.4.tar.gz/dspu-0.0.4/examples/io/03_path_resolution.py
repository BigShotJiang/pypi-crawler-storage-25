"""Path resolution utilities with dspu.

This example demonstrates:
- PathResolver for relative path resolution
- Resolving paths relative to source files
- Security checks for path traversal
- Using basis directories
"""

import asyncio

from dspu.io import PathResolver, Storage, resolve_path


async def main():
    """Demonstrate path resolution utilities."""
    print("=== Path Resolution ===\n")

    # 1. Basic path resolution
    print("1. Basic path resolution...")
    resolver = PathResolver(__file__)

    # Resolve relative to this file's directory
    output_path = resolver.resolve("sample_outputs/paths")
    print(f"✓ Resolved path: {output_path}")
    print(f"  Is absolute: {output_path.is_absolute()}\n")

    # Create the directory
    output_path.mkdir(parents=True, exist_ok=True)

    # 2. Using basis directory
    print("2. Using custom basis directory...")
    # Resolve relative to examples directory (parent of this file)
    examples_resolver = PathResolver(__file__, basis=".")
    sample_inputs = examples_resolver.resolve("sample_inputs")
    print(f"✓ Sample inputs path: {sample_inputs}")

    # Create sample inputs directory
    sample_inputs.mkdir(parents=True, exist_ok=True)

    # 3. Multiple file resolution
    print("\n3. Resolving multiple files at once...")
    config_files = examples_resolver.resolve_all(
        "sample_inputs/config.yaml",
        "sample_inputs/data.json",
        "sample_inputs/settings.toml",
    )
    print("✓ Resolved files:")
    for path in config_files:
        print(f"  - {path.name}: {path}")

    # 4. Path validation
    print("\n4. Path validation with checks...")
    # Create a test file
    test_file = output_path / "test.json"
    test_file.write_text('{"test": true}')

    # Resolve with existence check
    validated_path = resolver.resolve(
        "sample_outputs/paths/test.json",
        check_exists=True,
        must_be_file=True,
    )
    print(f"✓ Validated file path: {validated_path}")
    print(f"  Exists: {validated_path.exists()}")
    print(f"  Is file: {validated_path.is_file()}\n")

    # 5. Directory validation
    print("5. Directory validation...")
    dir_path = resolver.resolve(
        "sample_outputs/paths",
        check_exists=True,
        must_be_dir=True,
    )
    print(f"✓ Validated directory: {dir_path}")
    print(f"  Is directory: {dir_path.is_dir()}\n")

    # 6. Security: Path traversal protection
    print("6. Security - Path traversal protection...")
    try:
        # This should fail - trying to escape basis directory
        resolver.resolve("../../../etc/passwd")
        print("✗ SECURITY ISSUE: Path traversal allowed!")
    except Exception as e:
        print(f"✓ Path traversal blocked: {type(e).__name__}")
        print(f"  Message: {str(e)[:80]}...\n")

    # 7. Convenience function
    print("7. Using convenience function...")
    quick_path = resolve_path(__file__, "sample_outputs/paths/quick.txt")
    print(f"✓ Quick resolution: {quick_path}\n")

    # 8. Integration with Storage
    print("8. Using PathResolver with Storage...")
    storage_path = examples_resolver.resolve("sample_outputs/paths")
    storage = Storage.from_uri(str(storage_path))

    # Write a file using resolved path
    await storage.write_format(
        "app_config.yaml",
        {
            "app": "PathResolverDemo",
            "version": "1.0.0",
            "resolved_at": str(storage_path),
        },
    )
    print("✓ Written config using resolved path\n")

    # 9. Static path checking
    print("9. Static path validation...")
    safe_dir = output_path
    test_path = output_path / "subdir" / "file.txt"

    PathResolver.check_path_within(test_path, safe_dir)
    print("✓ Path is within safe directory")
    print(f"  Test path: {test_path}")
    print(f"  Safe directory: {safe_dir}\n")

    # 10. Practical example: Config file loading
    print("10. Practical example - Loading config relative to source...")

    # Create sample config
    config_dir = examples_resolver.resolve("sample_inputs/configs")
    config_dir.mkdir(parents=True, exist_ok=True)

    storage_temp = Storage.from_uri(str(config_dir))
    await storage_temp.write_format(
        "app.yaml",
        {
            "database": {"host": "localhost", "port": 5432},
            "logging": {"level": "INFO", "format": "json"},
            "features": {"auth": True, "api": True},
        },
    )

    # Now resolve and load it
    config_resolver = PathResolver(__file__, basis="sample_inputs/configs")
    app_config_path = config_resolver.resolve("app.yaml", check_exists=True)

    storage_config = Storage.from_uri(str(app_config_path.parent))
    config = await storage_config.read_format(app_config_path.name)

    print(f"✓ Loaded config from: {app_config_path}")
    print(f"  Database host: {config['database']['host']}")
    print(f"  Logging level: {config['logging']['level']}\n")

    print("=== Path resolution complete! ===")


if __name__ == "__main__":
    asyncio.run(main())
