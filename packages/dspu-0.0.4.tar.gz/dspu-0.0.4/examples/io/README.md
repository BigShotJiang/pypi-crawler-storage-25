# I/O Module Examples

This directory contains practical examples demonstrating the dspu I/O module capabilities.

## Examples Overview

### 01 - Basic File Operations
**File:** `01_basic_file_operations.py`

Learn the fundamentals:
- Creating a Storage instance
- Writing and reading files
- Checking file existence
- Listing files with patterns
- Deleting files
- Working with raw bytes

```bash
python examples/io/01_basic_file_operations.py
```

### 02 - Multi-Format Files
**File:** `02_multi_format_files.py`

Master file format handling:
- Writing to 9 different formats (JSON, YAML, TOML, HOCON, CSV, Markdown, Python, Env, Text)
- Auto-detection from file extensions
- Format-specific options (indentation, delimiters, etc.)
- Reading back from various formats
- Format override capabilities

**Supported Formats:**
- **Structured:** JSON, YAML, TOML, HOCON
- **Text:** Plain text, Python code, Markdown
- **Tabular:** CSV
- **Config:** .env files

```bash
python examples/io/02_multi_format_files.py
```

### 03 - Path Resolution
**File:** `03_path_resolution.py`

Work safely with file paths:
- PathResolver for relative paths
- Resolving paths relative to source files
- Path traversal security checks
- Using basis directories
- Integration with Storage
- Static path validation

```bash
python examples/io/03_path_resolution.py
```

### 04 - Streaming Large Files
**File:** `04_streaming_large_files.py`

Handle large files efficiently:
- Streaming reads and writes
- Processing data in chunks
- Memory-efficient operations
- Transform data while streaming
- CSV streaming example

**Benefits:**
- Handle files larger than RAM
- Lower memory footprint
- Start processing before download completes

```bash
python examples/io/04_streaming_large_files.py
```

### 05 - Config Management
**File:** `05_config_management.py`

Practical configuration management:
- Multi-environment configs (dev, staging, production)
- Config file generation in multiple formats
- Merging configs from multiple sources
- Generating .env files
- Auto-generating documentation

**Use Cases:**
- Application configuration
- Environment-specific settings
- Config file templating

```bash
python examples/io/05_config_management.py
```

### 06 - Cloud Storage
**File:** `06_cloud_storage.py`

Work with cloud storage providers:
- Unified API for local, S3, GCS, Azure
- URI-based provider selection
- Multi-cloud patterns
- Data migration strategies
- Best practices

**Supported Providers:**
- Local filesystem
- Amazon S3
- Google Cloud Storage
- Azure Blob Storage

```bash
python examples/io/06_cloud_storage.py
```

## Quick Start

### Installation

```bash
# Basic I/O
pip install dspu

# With cloud storage support
pip install 'dspu[io]'

# Development dependencies
pip install 'dspu[dev]'
```

### Running All Examples

```bash
# From the project root
python examples/io/01_basic_file_operations.py
python examples/io/02_multi_format_files.py
python examples/io/03_path_resolution.py
python examples/io/04_streaming_large_files.py
python examples/io/05_config_management.py
python examples/io/06_cloud_storage.py
```

### Running with UV

```bash
uv run python examples/io/01_basic_file_operations.py
# ... etc
```

## Sample Outputs

All examples create output files in `examples/sample_outputs/`:

```
sample_outputs/
├── basic/           # Basic operations output
├── formats/         # Multi-format files
├── paths/           # Path resolution output
├── streaming/       # Streaming examples
└── cloud/           # Cloud storage examples
```

## Sample Inputs

Pre-configured input files are available in `examples/sample_inputs/`:

```
sample_inputs/
├── configs/         # Sample configuration files
├── data/            # Sample data files
└── templates/       # Template files
```

## Common Patterns

### Reading Configuration

```python
from dspu.io import Storage

storage = Storage.from_uri("./config")
config = await storage.read_format("app.yaml")
```

### Writing Multiple Formats

```python
data = {"name": "MyApp", "version": "1.0.0"}

# Auto-detection from extension
await storage.write_format("config.json", data)
await storage.write_format("config.yaml", data)
await storage.write_format("config.toml", data)
```

### Streaming Large Files

```python
async for chunk in storage.read_stream("large_file.csv", chunk_size=8192):
    process(chunk)
```

### Path Resolution

```python
from dspu.io import PathResolver

resolver = PathResolver(__file__, basis="../configs")
config_path = resolver.resolve("app.yaml", check_exists=True)
```

### Cloud Storage

```python
# Same API, different URI
local = Storage.from_uri("./data")
s3 = Storage.from_uri("s3://my-bucket/data")
gcs = Storage.from_uri("gs://my-bucket/data")

# All use identical methods
await local.write_format("data.json", data)
await s3.write_format("data.json", data)
await gcs.write_format("data.json", data)
```

## Format Options

### JSON Options

```python
await storage.write_format(
    "config.json",
    data,
    format_options={
        "indent": 4,           # Pretty print with 4 spaces
        "sort_keys": True,     # Sort dictionary keys
        "ensure_ascii": False  # Allow unicode characters
    }
)
```

### CSV Options

```python
await storage.write_format(
    "data.csv",
    rows,
    format_options={
        "header": True,        # Include header row
        "delimiter": ",",      # Field delimiter
    }
)
```

### Python Code Options

```python
await storage.write_format(
    "utils.py",
    python_code,
    format_options={
        "validate_syntax": True  # Validate syntax before writing
    }
)
```

## Error Handling

```python
from dspu.io import FormatError

try:
    await storage.write_format("config.toml", ["list", "at", "root"])
except FormatError as e:
    print(f"Format error: {e}")
    print(f"Suggestion: {e.suggestion}")
```

## Advanced Usage

### Custom Format Registration

```python
from dspu.io import register_format

class XMLFormat:
    def write(self, obj, path):
        # Implementation
        ...

    def read(self, data, path):
        # Implementation
        ...

    def can_write(self, obj):
        return isinstance(obj, dict)

    @property
    def extensions(self):
        return [".xml"]

register_format("xml", XMLFormat)
```

### Format Discovery

```python
from dspu.io import list_formats, list_extensions

print(f"Available formats: {list_formats()}")
print(f"Supported extensions: {list_extensions()}")
```

## Troubleshooting

### Import Errors

```python
# If you see: ModuleNotFoundError: No module named 'yaml'
pip install pyyaml

# For cloud storage
pip install 'dspu[io]'
```

### Permission Errors

```python
# Ensure write permissions
output_dir.mkdir(parents=True, exist_ok=True)
```

### Format Errors

```python
# Check what formats are available
from dspu.io import list_formats
print(list_formats())

# Check if your data is compatible
fmt = get_format("json")
if fmt.can_write(my_data):
    await storage.write_format("out.json", my_data)
```

## Learn More

- **API Documentation:** See docstrings in `src/dspu/io/`
- **Tests:** Check `tests/unit/io/` and `tests/integration/io/` for more examples
- **Type Hints:** All code is fully typed for IDE support

---

### Support

For issues or questions:
- [GitHub Issues](https://github.com/deepsaia/dspu/issues)
- [Documentation](https://deepsaia.github.io/dspu)
