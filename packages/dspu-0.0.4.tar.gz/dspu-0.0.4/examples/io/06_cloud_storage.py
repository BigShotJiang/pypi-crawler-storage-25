"""Cloud storage integration with dspu.

This example demonstrates:
- Using the same API for local and cloud storage
- S3, GCS, and Azure blob storage
- URI-based storage selection
- Unified interface across providers

Note: This example shows the API usage. To run with actual cloud storage,
you'll need:
- AWS credentials for S3
- Google Cloud credentials for GCS
- Azure credentials for Azure Blob Storage
- Install cloud extras: pip install dspu[io]
"""

import asyncio

from dspu.io import Storage


async def local_storage_example():
    """Demonstrate local filesystem storage (baseline)."""
    print("=== Local Filesystem Storage ===\n")

    storage = Storage.from_uri("./examples/sample_outputs/cloud")

    # Write data
    data = {
        "message": "Hello from local storage",
        "provider": "local",
        "features": ["fast", "reliable", "always available"],
    }

    await storage.write_format("local_data.json", data)
    print("✓ Written to local filesystem\n")

    # Read back
    result = await storage.read_format("local_data.json")
    print(f"✓ Read from local: {result['message']}\n")

    return data


async def s3_storage_example():
    """Demonstrate S3 storage usage (requires AWS credentials).

    To use this:
    1. Set AWS credentials:
       - AWS_ACCESS_KEY_ID
       - AWS_SECRET_ACCESS_KEY
       - AWS_DEFAULT_REGION

    2. Install fsspec: pip install fsspec s3fs
    """
    print("=== Amazon S3 Storage ===\n")

    # S3 URI format: s3://bucket-name/path/to/folder
    # storage = Storage.from_uri("s3://my-bucket/data")

    print("S3 Storage API (when credentials are configured):\n")

    example_code = """
# Initialize S3 storage
storage = Storage.from_uri("s3://my-bucket/data")

# Write data - same API as local!
data = {"message": "Hello from S3", "provider": "aws"}
await storage.write_format("s3_data.json", data)

# Read data
result = await storage.read_format("s3_data.json")

# List files
files = await storage.list("*.json")

# Stream large files
async for chunk in storage.read_stream("large_file.csv"):
    process(chunk)

# Delete files
await storage.delete("old_data.json")
"""

    print(example_code)
    print("\n✓ S3 uses the exact same API as local storage\n")


async def gcs_storage_example():
    """Demonstrate Google Cloud Storage usage (requires GCS credentials).

    To use this:
    1. Set GOOGLE_APPLICATION_CREDENTIALS environment variable
    2. Install fsspec: pip install fsspec gcsfs
    """
    print("=== Google Cloud Storage ===\n")

    # GCS URI format: gs://bucket-name/path/to/folder
    # storage = Storage.from_uri("gs://my-bucket/data")

    print("GCS Storage API (when credentials are configured):\n")

    example_code = """
# Initialize GCS storage
storage = Storage.from_uri("gs://my-bucket/data")

# Write data - same API!
data = {"message": "Hello from GCS", "provider": "google"}
await storage.write_format("gcs_data.yaml", data)

# Read data
result = await storage.read_format("gcs_data.yaml")

# The API is identical to local and S3
"""

    print(example_code)
    print("\n✓ GCS uses the exact same API\n")


async def azure_storage_example():
    """Demonstrate Azure Blob Storage usage (requires Azure credentials).

    To use this:
    1. Set AZURE_STORAGE_CONNECTION_STRING or individual credentials
    2. Install fsspec: pip install fsspec adlfs
    """
    print("=== Azure Blob Storage ===\n")

    # Azure URI format: az://container-name/path/to/folder
    # storage = Storage.from_uri("az://my-container/data")

    print("Azure Storage API (when credentials are configured):\n")

    example_code = """
# Initialize Azure storage
storage = Storage.from_uri("az://my-container/data")

# Write data - same API!
data = {"message": "Hello from Azure", "provider": "microsoft"}
await storage.write_format("azure_data.toml", data)

# Read data
result = await storage.read_format("azure_data.toml")

# All operations work identically
"""

    print(example_code)
    print("\n✓ Azure uses the exact same API\n")


async def multi_cloud_pattern():
    """Demonstrate patterns for working with multiple cloud providers."""
    print("=== Multi-Cloud Pattern ===\n")

    print("Managing data across multiple providers:\n")

    example_code = """
import os
from dspu.io import Storage

# Get storage URI from environment
storage_uri = os.getenv("STORAGE_URI", "./local_data")

# Works with any provider!
storage = Storage.from_uri(storage_uri)

# Your code doesn't change
await storage.write_format("config.yaml", config)
data = await storage.read_format("config.yaml")

# Environment determines provider:
# - STORAGE_URI=./data          -> Local
# - STORAGE_URI=s3://bucket     -> AWS S3
# - STORAGE_URI=gs://bucket     -> Google Cloud
# - STORAGE_URI=az://container  -> Azure
"""

    print(example_code)
    print("\n✓ Write once, deploy anywhere\n")


async def migration_pattern():
    """Demonstrate migrating data between storage providers."""
    print("=== Data Migration Pattern ===\n")

    print("Migrating data from local to cloud:\n")

    example_code = """
from dspu.io import Storage

# Source and destination
source = Storage.from_uri("./local_data")
dest = Storage.from_uri("s3://my-bucket/backup")

# Migrate files
files = await source.list("*.json")

for file in files:
    print(f"Migrating {file.path}...")

    # Read from source
    data = await source.read(file.path, raw=True)

    # Write to destination
    await dest.write(file.path, data, raw=True)

    print(f"✓ Migrated {file.path}")

print("Migration complete!")
"""

    print(example_code)
    print("\n✓ Easy data migration between providers\n")


async def best_practices():
    """Show best practices for cloud storage."""
    print("=== Best Practices ===\n")

    practices = [
        ("1. Use environment variables", "Store URIs and credentials in environment, not code"),
        ("2. Handle errors gracefully", "Network issues and rate limits are common in cloud"),
        ("3. Use streaming for large files", "Avoid loading entire files into memory"),
        ("4. Implement retries", "Cloud operations can fail transiently"),
        ("5. Monitor costs", "Track storage and transfer costs"),
        ("6. Use appropriate regions", "Choose regions close to your users/compute"),
        ("7. Enable versioning", "Protect against accidental deletions"),
        ("8. Set lifecycle policies", "Auto-delete or archive old data"),
    ]

    for title, description in practices:
        print(f"{title}")
        print(f"  {description}\n")


async def main():
    """Demonstrate cloud storage integration."""
    print("╔═══════════════════════════════════════════════════════════╗")
    print("║         DSPU Cloud Storage Integration            ║")
    print("╚═══════════════════════════════════════════════════════════╝\n")

    # Run local example (always works)
    await local_storage_example()

    # Show cloud provider APIs
    await s3_storage_example()
    await gcs_storage_example()
    await azure_storage_example()

    # Show patterns
    await multi_cloud_pattern()
    await migration_pattern()
    await best_practices()

    print("=== Key Advantages ===\n")

    advantages = [
        "✓ Unified API - same code works everywhere",
        "✓ Protocol-based - easy to add new providers",
        "✓ Async-first - efficient I/O operations",
        "✓ Type-safe - full type hints throughout",
        "✓ Format-aware - automatic serialization",
        "✓ Streaming support - handle large files",
        "✓ Environment-driven - configure via env vars",
        "✓ No vendor lock-in - switch providers easily",
    ]

    for advantage in advantages:
        print(f"  {advantage}")

    print("\n" + "=" * 60)
    print("To use cloud storage, install extras:")
    print("  pip install 'dspu[io]'")
    print("\nThen configure credentials per provider documentation.")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
