"""Multi-format file writing with dspu.

This example demonstrates:
- Writing to different formats (JSON, YAML, TOML, HOCON, CSV, Markdown, etc.)
- Format auto-detection from file extensions
- Format-specific options
- Reading back from various formats
"""

import asyncio
from pathlib import Path

from dspu.io import Storage, list_extensions, list_formats


async def main():
    """Demonstrate multi-format file writing."""
    # Create output directory
    output_dir = Path("./examples/sample_outputs/formats")
    output_dir.mkdir(parents=True, exist_ok=True)

    storage = Storage.from_uri(str(output_dir))

    print("=== Multi-Format File Writing ===\n")

    # Show available formats
    print(f"Available formats: {', '.join(list_formats())}")
    print(f"Supported extensions: {', '.join(list_extensions())}\n")

    # Configuration data for structured formats
    config = {
        "app": {
            "name": "MyApp",
            "version": "1.0.0",
            "debug": True,
        },
        "database": {
            "host": "localhost",
            "port": 5432,
            "name": "mydb",
        },
        "features": ["auth", "api", "admin"],
    }

    # 1. JSON - with pretty printing
    print("1. Writing JSON (with custom options)...")
    await storage.write_format(
        "config.json",
        config,
        format_options={"indent": 4, "sort_keys": True},
    )
    print(f"✓ Written to {output_dir}/config.json\n")

    # 2. YAML - human-readable
    print("2. Writing YAML...")
    await storage.write_format("config.yaml", config)
    print(f"✓ Written to {output_dir}/config.yaml\n")

    # 3. TOML - configuration standard
    print("3. Writing TOML...")
    await storage.write_format("config.toml", config)
    print(f"✓ Written to {output_dir}/config.toml\n")

    # 4. HOCON - with comments support
    print("4. Writing HOCON...")
    await storage.write_format("config.conf", config)
    print(f"✓ Written to {output_dir}/config.conf\n")

    # 5. CSV - tabular data
    print("5. Writing CSV...")
    users = [
        {"name": "Alice", "age": 30, "city": "NYC"},
        {"name": "Bob", "age": 25, "city": "LA"},
        {"name": "Charlie", "age": 35, "city": "Chicago"},
    ]
    await storage.write_format(
        "users.csv",
        users,
        format_options={"header": True},
    )
    print(f"✓ Written to {output_dir}/users.csv\n")

    # 6. Markdown - documentation
    print("6. Writing Markdown...")
    readme = """# MyApp

A powerful application built with dspu.

## Features

- **Authentication**: Secure user authentication
- **API**: RESTful API endpoints
- **Admin Panel**: Comprehensive admin interface

## Configuration

See `config.yaml` for configuration options.

## Installation

```bash
pip install myapp
```

## Usage

```python
from myapp import App

app = App()
app.run()
```
"""
    await storage.write_format("README.md", readme)
    print(f"✓ Written to {output_dir}/README.md\n")

    # 7. Python code - with syntax validation
    print("7. Writing Python code...")
    python_code = '''"""Utility functions for MyApp."""

def greet(name: str) -> str:
    """Greet a user by name.

    Args:
        name: The user's name.

    Returns:
        A greeting message.
    """
    return f"Hello, {name}!"


def calculate_sum(numbers: list[int]) -> int:
    """Calculate the sum of a list of numbers.

    Args:
        numbers: List of integers.

    Returns:
        The sum of all numbers.
    """
    return sum(numbers)
'''
    await storage.write_format(
        "utils.py",
        python_code,
        format_options={"validate_syntax": True},
    )
    print(f"✓ Written to {output_dir}/utils.py\n")

    # 8. Environment file
    print("8. Writing .env file...")
    env_vars = {
        "DATABASE_URL": "postgresql://localhost/mydb",
        "SECRET_KEY": "your-secret-key-here",
        "DEBUG": "true",
        "LOG_LEVEL": "INFO",
        "API_HOST": "0.0.0.0",
        "API_PORT": "8000",
    }
    await storage.write_format(".env", env_vars)
    print(f"✓ Written to {output_dir}/.env\n")

    # 9. Plain text
    print("9. Writing plain text...")
    notes = """Project Notes
============

- Completed: Basic file operations
- Completed: Multi-format support
- TODO: Add cloud storage examples
- TODO: Implement caching layer
"""
    await storage.write_format("notes.txt", notes)
    print(f"✓ Written to {output_dir}/notes.txt\n")

    # 10. Read back and verify
    print("10. Reading back from different formats...")
    json_data = await storage.read_format("config.json")
    yaml_data = await storage.read_format("config.yaml")
    toml_data = await storage.read_format("config.toml")

    print(f"✓ JSON config loaded: {json_data['app']['name']}")
    print(f"✓ YAML config loaded: {yaml_data['app']['name']}")
    print(f"✓ TOML config loaded: {toml_data['app']['name']}\n")

    csv_data = await storage.read_format("users.csv")
    print(f"✓ CSV loaded {len(csv_data)} rows")
    print(f"  First user: {csv_data[0]}\n")

    # 11. Format override example
    print("11. Explicit format override...")
    # Write JSON data to .txt file
    await storage.write_format("data.txt", config, format="json")
    # Read it back as JSON
    data_from_txt = await storage.read_format("data.txt", format="json")
    print(f"✓ Wrote JSON to .txt and read back: {data_from_txt['app']['name']}\n")

    print("=== All formats written successfully! ===")
    print(f"\nCheck the output files in: {output_dir}")


if __name__ == "__main__":
    asyncio.run(main())
