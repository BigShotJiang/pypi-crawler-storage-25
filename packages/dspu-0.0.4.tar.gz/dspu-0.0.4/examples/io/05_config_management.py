"""Practical configuration file management.

This example demonstrates:
- Managing config files in multiple formats
- Environment-specific configurations
- Merging configs from multiple sources
- Validating configurations
- Using PathResolver for config discovery
"""

import asyncio
from pathlib import Path
from typing import Any

from dspu.io import Storage


class ConfigManager:
    """Manages application configurations across multiple formats and environments."""

    def __init__(self, config_dir: Path):
        """Initialize config manager.

        Args:
            config_dir: Directory containing configuration files.
        """
        self.config_dir = config_dir
        self.storage = Storage.from_uri(str(config_dir))
        self.configs: dict[str, Any] = {}

    async def load_base_config(self) -> dict:
        """Load base configuration that applies to all environments."""
        print("Loading base configuration...")

        # Create base config if it doesn't exist
        base_config = {
            "app": {
                "name": "MyApplication",
                "version": "1.0.0",
                "description": "Example application with dspu",
            },
            "logging": {
                "level": "INFO",
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            },
            "features": {
                "auth": True,
                "api": True,
                "admin": False,
                "metrics": True,
            },
        }

        # Write in multiple formats for demonstration
        await self.storage.write_format("base.yaml", base_config)
        await self.storage.write_format("base.json", base_config)
        await self.storage.write_format("base.toml", base_config)

        print("✓ Base config created in multiple formats\n")
        return base_config

    async def load_environment_config(self, env: str) -> dict:
        """Load environment-specific configuration.

        Args:
            env: Environment name (dev, staging, production).

        Returns:
            Environment-specific configuration.
        """
        print(f"Loading {env} environment config...")

        env_configs = {
            "dev": {
                "database": {
                    "host": "localhost",
                    "port": 5432,
                    "name": "myapp_dev",
                    "pool_size": 5,
                },
                "redis": {
                    "host": "localhost",
                    "port": 6379,
                    "db": 0,
                },
                "debug": True,
            },
            "staging": {
                "database": {
                    "host": "staging-db.example.com",
                    "port": 5432,
                    "name": "myapp_staging",
                    "pool_size": 10,
                },
                "redis": {
                    "host": "staging-redis.example.com",
                    "port": 6379,
                    "db": 0,
                },
                "debug": False,
            },
            "production": {
                "database": {
                    "host": "prod-db.example.com",
                    "port": 5432,
                    "name": "myapp_prod",
                    "pool_size": 20,
                },
                "redis": {
                    "host": "prod-redis.example.com",
                    "port": 6379,
                    "db": 0,
                },
                "debug": False,
            },
        }

        config = env_configs.get(env, env_configs["dev"])

        # Save environment config
        await self.storage.write_format(f"{env}.yaml", config)

        print(f"✓ {env.capitalize()} config loaded\n")
        return config

    async def generate_env_file(self, env: str, config: dict) -> None:
        """Generate .env file from configuration.

        Args:
            env: Environment name.
            config: Configuration dictionary.
        """
        print(f"Generating .env.{env} file...")

        # Flatten config for environment variables
        env_vars = {
            "APP_ENV": env,
            "DATABASE_HOST": config["database"]["host"],
            "DATABASE_PORT": str(config["database"]["port"]),
            "DATABASE_NAME": config["database"]["name"],
            "DATABASE_POOL_SIZE": str(config["database"]["pool_size"]),
            "REDIS_HOST": config["redis"]["host"],
            "REDIS_PORT": str(config["redis"]["port"]),
            "DEBUG": str(config["debug"]).lower(),
        }

        await self.storage.write_format(f".env.{env}", env_vars)
        print(f"✓ .env.{env} file created\n")

    def merge_configs(self, base: dict, override: dict) -> dict:
        """Merge two configuration dictionaries.

        Args:
            base: Base configuration.
            override: Override configuration.

        Returns:
            Merged configuration.
        """
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self.merge_configs(result[key], value)
            else:
                result[key] = value

        return result

    async def save_merged_config(self, env: str, config: dict) -> None:
        """Save merged configuration in multiple formats.

        Args:
            env: Environment name.
            config: Merged configuration.
        """
        print(f"Saving merged {env} configuration...")

        # Save in multiple formats
        await self.storage.write_format(
            f"merged.{env}.yaml",
            config,
            format_options={"sort_keys": False},
        )

        await self.storage.write_format(
            f"merged.{env}.json",
            config,
            format_options={"indent": 2, "sort_keys": True},
        )

        await self.storage.write_format(f"merged.{env}.toml", config)

        print("✓ Merged config saved in YAML, JSON, and TOML\n")

    async def generate_readme(self, environments: list[str]) -> None:
        """Generate README documentation for configurations.

        Args:
            environments: List of environment names.
        """
        readme = """# Configuration Files

This directory contains configuration files for MyApplication.

## Available Configurations

### Base Configuration

- `base.yaml` - Base configuration (YAML format)
- `base.json` - Base configuration (JSON format)
- `base.toml` - Base configuration (TOML format)

### Environment Configurations

"""

        for env in environments:
            readme += f"""
#### {env.capitalize()} Environment

- `{env}.yaml` - {env.capitalize()} specific settings
- `.env.{env}` - Environment variables for {env}
- `merged.{env}.*` - Merged configuration in multiple formats
"""

        readme += """
## Usage

### Loading Configuration

```python
from dspu.io import Storage

# Load YAML config
storage = Storage.from_uri("./config")
config = await storage.read_format("merged.production.yaml")
```

### Environment Variables

Source the environment file for your environment:

```bash
# Development
export $(cat .env.dev | xargs)

# Production
export $(cat .env.production | xargs)
```

## Configuration Structure

```yaml
app:
  name: Application name
  version: Version number
  description: Application description

database:
  host: Database hostname
  port: Database port
  name: Database name
  pool_size: Connection pool size

redis:
  host: Redis hostname
  port: Redis port
  db: Redis database number

logging:
  level: Log level (DEBUG, INFO, WARNING, ERROR)
  format: Log format string

features:
  auth: Enable authentication
  api: Enable API
  admin: Enable admin panel
  metrics: Enable metrics collection

debug: Debug mode flag
```

## Generated Files

All configuration files are automatically generated by the configuration
management system. Do not edit manually - changes will be overwritten.

Last updated: {Path.cwd()}
"""

        await self.storage.write_format("README.md", readme)
        print("✓ README.md generated\n")


async def main():
    """Demonstrate practical configuration management."""
    print("=== Configuration Management ===\n")

    # Setup
    config_dir = Path("./examples/sample_inputs/config")
    config_dir.mkdir(parents=True, exist_ok=True)

    manager = ConfigManager(config_dir)

    # 1. Load base configuration
    base_config = await manager.load_base_config()

    # 2. Generate configs for each environment
    environments = ["dev", "staging", "production"]

    for env in environments:
        print(f"--- Processing {env.upper()} environment ---\n")

        # Load environment-specific config
        env_config = await manager.load_environment_config(env)

        # Merge with base config
        merged = manager.merge_configs(base_config, env_config)

        # Save merged configuration
        await manager.save_merged_config(env, merged)

        # Generate .env file
        await manager.generate_env_file(env, merged)

    # 3. Generate documentation
    await manager.generate_readme(environments)

    # 4. Show summary
    print("=== Configuration Summary ===\n")

    files = await manager.storage.list("*")
    files_by_type = {}

    for file in files:
        ext = Path(file.path).suffix or "no_extension"
        if ext not in files_by_type:
            files_by_type[ext] = []
        files_by_type[ext].append(file)

    print("Files created by type:")
    for ext, file_list in sorted(files_by_type.items()):
        print(f"\n{ext} files ({len(file_list)}):")
        for file in sorted(file_list, key=lambda f: f.path):
            print(f"  - {file.path} ({file.size} bytes)")

    print(f"\n✓ Total files created: {len(files)}")
    print(f"✓ Configuration directory: {config_dir}")

    # 5. Demonstrate loading and using config
    print("\n=== Loading Configuration ===\n")

    print("Loading production configuration...")
    prod_config = await manager.storage.read_format("merged.production.yaml")

    print(f"✓ Application: {prod_config['app']['name']} v{prod_config['app']['version']}")
    print(f"✓ Database: {prod_config['database']['host']}:{prod_config['database']['port']}")
    print(f"✓ Debug mode: {prod_config['debug']}")
    print(f"✓ Features enabled: {', '.join([k for k, v in prod_config['features'].items() if v])}")

    print("\n=== Configuration management complete! ===")


if __name__ == "__main__":
    asyncio.run(main())
