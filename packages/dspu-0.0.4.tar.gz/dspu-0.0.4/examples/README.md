# DSPU Examples

Comprehensive examples showcasing all features of the `dspu` library.

## 📁 Directory Structure

```
examples/
├── core/                   # Core utilities examples
│   ├── 01_protocols_basic.py
│   ├── 02_registry_plugins.py
│   ├── 03_exception_handling.py
│   └── README.md
├── config/                 # Configuration management examples
│   ├── 01_basic_config.py
│   ├── 02_multi_source_config.py
│   ├── 03_deployment_patterns.py
│   ├── 04_validation_patterns.py
│   └── README.md
├── io/                     # I/O and storage examples
│   ├── 01_basic_file_operations.py
│   ├── 02_multi_format_files.py
│   ├── 03_path_resolution.py
│   ├── 04_streaming_large_files.py
│   ├── 05_config_management.py
│   ├── 06_cloud_storage.py
│   └── README.md
├── aio/                    # Async utilities examples ✨ NEW
│   ├── 01_retry_patterns.py
│   ├── 02_rate_limiting.py
│   ├── 03_circuit_breaker.py
│   ├── 04_concurrency_and_bridge.py
│   └── README.md
├── sample_inputs/          # Sample data files
│   ├── config/            # Configuration files
│   ├── sample_config.yaml # Sample YAML config
│   ├── sample_data.json   # Sample JSON data
│   ├── products.csv       # Sample CSV data
│   └── .env.sample        # Sample environment vars
├── sample_outputs/         # Generated outputs (gitignored)
└── README.md              # This file
```

## 🚀 Quick Start

### Prerequisites

Install dspu with UV:

```bash
cd /path/to/dspu
uv sync
```

### Running Examples

```bash
# Core module examples
uv run python examples/core/01_protocols_basic.py
uv run python examples/core/02_registry_plugins.py
uv run python examples/core/03_exception_handling.py

# Configuration module examples
uv run python examples/config/01_basic_config.py
uv run python examples/config/02_multi_source_config.py
uv run python examples/config/03_deployment_patterns.py
uv run python examples/config/04_validation_patterns.py
```

## 📚 Examples by Module

### Core Module (`core/`)

Fundamental utilities and patterns:

1. **Protocols** - Structural typing without inheritance
   - Serializable, AsyncResource, Closeable protocols
   - Runtime protocol checking
   - Flexible, testable design patterns

2. **Registry & Plugins** - Extensible plugin architecture
   - Data transformer plugins
   - Serializer plugins
   - Validator plugins
   - Type-safe plugin registration

3. **Exception Handling** - Rich error context
   - ConfigurationError, ValidationError, DSPUIOError, SecurityError
   - Actionable error messages
   - Exception chaining

[→ See core/ README for details](core/README.md)

### Configuration Module (`config/`)

Powerful configuration management:

1. **Basic Configuration** - Getting started
   - Loading from dict, files (YAML, JSON, TOML, HOCON, .env)
   - Default values and validation
   - Type coercion

2. **Multi-Source Configuration** - Advanced patterns
   - Source priority and deep merge
   - Layered configuration (defaults → file → env)
   - Optional configuration files

3. **Deployment Patterns** - Real-world scenarios
   - Docker Compose
   - Kubernetes (ConfigMap + Secrets)
   - AWS ECS/Fargate
   - Cloud-native patterns
   - 12-factor app methodology

4. **Validation Patterns** - Advanced Pydantic features
   - Field constraints and string patterns
   - Enum validation
   - Custom validators
   - Conditional validation

[→ See config/ README for details](config/README.md)

### Async Module (`aio/`)

Production-ready async utilities for resilient applications:

1. **Retry Patterns** - Handle transient failures
   - Exponential, linear, and constant backoff strategies
   - Jitter support to prevent thundering herd
   - Exception filtering and retry callbacks
   - 6 practical retry patterns

2. **Rate Limiting** - Control resource usage
   - Token bucket algorithm with burst capacity
   - Decorator and context manager interfaces
   - Weighted rate limiting (different costs)
   - 8 rate limiting patterns

3. **Circuit Breaker** - Prevent cascading failures
   - State management (CLOSED → OPEN → HALF_OPEN)
   - Configurable thresholds and callbacks
   - Exception filtering
   - 8 circuit breaker patterns

4. **Concurrency & Bridge** - Control and integration
   - `gather_with_limit` for controlled parallelism
   - Timeout utilities and context managers
   - Sync/async bridge functions
   - 12 concurrency and bridge patterns

[→ See aio/ README for details](aio/README.md)

## 🎯 Learning Path

### Beginner

Start here if you're new to dspu:

1. `core/01_protocols_basic.py` - Understand the protocol pattern
2. `config/01_basic_config.py` - Learn basic configuration loading
3. `core/03_exception_handling.py` - See error handling patterns

### Intermediate

Once you understand the basics:

4. `core/02_registry_plugins.py` - Build plugin systems
5. `config/02_multi_source_config.py` - Multi-source configuration
6. `config/04_validation_patterns.py` - Advanced validation

### Advanced

For production deployments:

7. `config/03_deployment_patterns.py` - Docker, Kubernetes, cloud patterns

## 💡 Common Use Cases

### Use Case 1: Simple Application Configuration

```python
from pydantic import BaseModel
from dspu.config import Config

class AppConfig(BaseModel):
    app_name: str
    debug: bool = False
    port: int = 8000

# Load from YAML file
config = Config.load_from_file(AppConfig, "config.yaml")
```

**See:** `config/01_basic_config.py`

### Use Case 2: Environment-Specific Configuration

```python
import os
from dspu.config import Config, FileSource

env = os.getenv("ENV", "development")

config = Config.load(
    AppConfig,
    sources=[
        FileSource("config.yaml"),           # Base
        FileSource(f"config.{env}.yaml"),    # Environment-specific
    ],
)
```

**See:** `config/02_multi_source_config.py`

### Use Case 3: Docker/Kubernetes Deployment

```python
from dspu.config import Config, FileSource, EnvSource

config = Config.load(
    AppConfig,
    sources=[
        FileSource("/config/app.yaml"),      # ConfigMap
        EnvSource(prefix="", separator="__"),  # Secrets
    ],
)
```

**See:** `config/03_deployment_patterns.py`

### Use Case 4: Plugin System

```python
from dspu.core.registry import Registry
from typing import Protocol

class DataTransformer(Protocol):
    def transform(self, data: dict) -> dict: ...

# Create registry
transformers: Registry[DataTransformer] = Registry()

# Register plugins
transformers.register("uppercase", UppercaseTransformer())
transformers.register("timestamp", TimestampTransformer())

# Use plugins
transformer = transformers.get("uppercase")
result = transformer.transform(data)
```

**See:** `core/02_registry_plugins.py`

### Use Case 5: Rich Error Handling

```python
from dspu.core.exceptions import ValidationError

def validate_age(age: int) -> None:
    if age < 0:
        raise ValidationError(
            "Age cannot be negative",
            field="age",
            value=age,
            constraint="ge_0",
        )
```

**See:** `core/03_exception_handling.py`

## 📦 Sample Input Files

The `sample_inputs/` directory contains example data files used by the examples:

### Configuration Files (`sample_inputs/config/`)

- **Format Examples:**
  - `app_config.yaml` - YAML format
  - `app_config.json` - JSON format
  - `app_config.toml` - TOML format
  - `database.conf` - HOCON format
  - `.env.example` - Environment variables

- **Environment-Specific:**
  - `config.development.yaml` - Dev settings
  - `config.staging.yaml` - Staging settings
  - `config.production.yaml` - Production settings

## 🔧 Customizing Examples

All examples are self-contained and can be easily modified:

1. **Copy an example:** `cp examples/config/01_basic_config.py my_example.py`
2. **Modify for your use case:** Edit the configuration models and sources
3. **Run it:** `uv run python my_example.py`

## 📖 Documentation

- [Design Document](../docs/design.md) - Architecture and design decisions
- [Implementation Plan](../docs/plan.md) - Development roadmap
- [Contributing Guide](../CONTRIBUTING.md) - How to contribute

## 🤝 Contributing

Found an issue or want to add an example?

1. Check existing examples to avoid duplication
2. Follow the existing code style and structure
3. Add comments explaining key concepts
4. Update the relevant README
5. Submit a pull request

## 💬 Getting Help

- Read the module READMEs: `core/README.md`, `config/README.md`
- Check the examples for similar use cases
- Review the main documentation in `docs/`
- Open an issue on GitHub

## 🎓 Next Steps

After exploring the examples:

1. Read the [Design Document](../docs/design.md) for architectural details
2. Check the [API documentation](../docs/) (when available)
3. Explore the [test suite](../tests/) for more usage patterns
4. Build your own application using dspu!

## 📝 Notes

- All examples use Python 3.11+ features
- Examples are tested as part of the CI pipeline
- Sample configuration files contain placeholder values only
- Never commit real secrets or credentials

## 🌟 Highlights

**What makes dspu examples great:**

✅ **Comprehensive** - Cover all features with real-world scenarios
✅ **Practical** - Deployable patterns for Docker, Kubernetes, cloud
✅ **Well-documented** - Extensive comments and READMEs
✅ **Self-contained** - Each example runs independently
✅ **Progressive** - From beginner to advanced
✅ **Type-safe** - Full type hints and validation
✅ **Tested** - All examples are verified working

---

### Support

For issues or questions:
- [GitHub Issues](https://github.com/deepsaia/dspu/issues)
- [Documentation](https://deepsaia.github.io/dspu)
