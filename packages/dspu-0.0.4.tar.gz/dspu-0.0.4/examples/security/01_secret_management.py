"""Secret management examples with dspu.

This example demonstrates:
- Environment variable secrets
- File-based secrets (for development)
- Vault integration (when available)
- AWS Secrets Manager integration (when available)
"""

import asyncio
import os
from pathlib import Path

from dspu.security import SecretManager


async def example_env_secrets():
    """Example 1: Environment variable secrets."""
    print("\n" + "=" * 70)
    print("Example 1: Environment Variable Secrets")
    print("=" * 70)

    # Set up some test environment variables
    os.environ["APP_SECRET_DATABASE_PASSWORD"] = "my-db-password-123"
    os.environ["APP_SECRET_API_KEY"] = "api-key-456"
    os.environ["APP_SECRET_JWT_SECRET"] = "jwt-secret-789"

    # Create secret manager with environment backend
    secrets = SecretManager.from_env_vars(prefix="APP_SECRET_")

    # Get secrets
    print("\n1. Getting secrets from environment:")
    db_password = await secrets.get("database/password")
    print(f"   Database password: {db_password}")

    api_key = await secrets.get("api/key")
    print(f"   API key: {api_key}")

    # List all secrets
    print("\n2. Listing all secrets:")
    all_secrets = await secrets.list()
    for key in all_secrets:
        print(f"   - {key}")

    # Check if secret exists
    print("\n3. Checking if secret exists:")
    exists = await secrets.exists("database/password")
    print(f"   database/password exists: {exists}")

    # Get with default value
    print("\n4. Getting secret with default value:")
    optional_key = await secrets.get("optional/key", default="default-value")
    print(f"   optional/key: {optional_key}")

    # Clean up
    del os.environ["APP_SECRET_DATABASE_PASSWORD"]
    del os.environ["APP_SECRET_API_KEY"]
    del os.environ["APP_SECRET_JWT_SECRET"]


async def example_file_secrets():
    """Example 2: File-based secrets (development)."""
    print("\n" + "=" * 70)
    print("Example 2: File-Based Secrets (Development Only)")
    print("=" * 70)

    # Create a temporary secrets file
    secrets_file = Path("./examples/security/secrets.yaml")
    secrets_file.parent.mkdir(parents=True, exist_ok=True)

    secrets_file.write_text(
        """
database:
  host: localhost
  port: 5432
  username: postgres
  password: dev-password-123

api:
  key: dev-api-key-456
  secret: dev-api-secret-789

oauth:
  client_id: dev-client-id
  client_secret: dev-client-secret
"""
    )

    print(f"\n1. Created secrets file: {secrets_file}")

    # Create secret manager with file backend
    secrets = SecretManager.from_file(str(secrets_file))

    # Get secrets
    print("\n2. Reading secrets from file:")
    db_password = await secrets.get("database/password")
    print(f"   Database password: {db_password}")

    api_key = await secrets.get("api/key")
    print(f"   API key: {api_key}")

    # List secrets with prefix
    print("\n3. Listing database secrets:")
    db_secrets = await secrets.list(prefix="database")
    for key in db_secrets:
        value = await secrets.get(key)
        print(f"   {key}: {value}")

    # Set a new secret
    print("\n4. Adding a new secret:")
    await secrets.set("cache/redis/url", "redis://localhost:6379")
    print("   Added cache/redis/url")

    # Verify it was saved
    redis_url = await secrets.get("cache/redis/url")
    print(f"   Retrieved: {redis_url}")

    print("\n⚠️  WARNING: File-based secrets are for DEVELOPMENT ONLY!")
    print("   Use Vault or cloud secret managers in production.")

    # Clean up
    secrets_file.unlink()


async def example_auto_detect_backend():
    """Example 3: Auto-detect backend from environment."""
    print("\n" + "=" * 70)
    print("Example 3: Auto-Detecting Secret Backend")
    print("=" * 70)

    print("\n1. Auto-detection priority:")
    print("   1. Vault (if VAULT_ADDR and VAULT_TOKEN set)")
    print("   2. AWS Secrets Manager (if AWS_SECRET_BACKEND=true)")
    print("   3. Environment variables (default)")

    # Default: Environment variables
    print("\n2. Using default environment variable backend:")
    os.environ["SECRET_DATABASE_URL"] = "postgresql://localhost/mydb"

    secrets = SecretManager.from_env()
    db_url = await secrets.get("database/url", default="not-found")
    print(f"   Retrieved: {db_url}")

    # Clean up
    if "SECRET_DATABASE_URL" in os.environ:
        del os.environ["SECRET_DATABASE_URL"]


async def example_secret_management_patterns():
    """Example 4: Common secret management patterns."""
    print("\n" + "=" * 70)
    print("Example 4: Common Secret Management Patterns")
    print("=" * 70)

    # Pattern 1: Configuration with secrets
    print("\n1. Loading configuration with secrets:")
    os.environ["APP_DB_HOST"] = "prod-db.example.com"
    os.environ["APP_DB_PASSWORD"] = "secret-password-123"
    os.environ["APP_API_KEY"] = "secret-api-key-456"

    secrets = SecretManager.from_env_vars(prefix="APP_")

    # Build database connection string
    db_host = await secrets.get("db/host")
    db_password = await secrets.get("db/password")
    connection_string = f"postgresql://user:{db_password}@{db_host}/mydb"
    print(f"   Connection string: postgresql://user:****@{db_host}/mydb")

    # Pattern 2: Conditional secret existence
    print("\n2. Conditional secret usage:")
    if await secrets.exists("api/key"):
        api_key = await secrets.get("api/key")
        print(f"   Using API key: {api_key[:10]}...")
    else:
        print("   No API key configured, using default authentication")

    # Pattern 3: Secret namespacing
    print("\n3. Organizing secrets by namespace:")
    namespaces = {}
    all_keys = await secrets.list()

    for key in all_keys:
        namespace = key.split("/")[0] if "/" in key else "root"
        if namespace not in namespaces:
            namespaces[namespace] = []
        namespaces[namespace].append(key)

    for namespace, keys in namespaces.items():
        print(f"   {namespace}: {len(keys)} secrets")

    # Clean up
    for key in ["APP_DB_HOST", "APP_DB_PASSWORD", "APP_API_KEY"]:
        if key in os.environ:
            del os.environ[key]


async def main():
    """Run all secret management examples."""
    print("\n" + "=" * 70)
    print("DSPU Security: Secret Management Examples")
    print("=" * 70)

    await example_env_secrets()
    await example_file_secrets()
    await example_auto_detect_backend()
    await example_secret_management_patterns()

    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
