## DSPU Security Module Examples

This directory contains comprehensive examples for the security module.

### Examples

#### 1. Secret Management (`01_secret_management.py`)

Demonstrates secret storage and retrieval:

- **Environment Variable Secrets**: Store secrets in environment variables
- **File-Based Secrets**: Development-friendly file-based storage
- **Auto-Detection**: Automatic backend selection (Vault → AWS → Env)
- **Common Patterns**: Configuration loading, secret namespacing

**Run:**
```bash
python examples/security/01_secret_management.py
```

#### 2. Authentication (`02_authentication.py`)

Shows authentication providers and token management:

- **Static Tokens**: Simple API key authentication
- **JWT Tokens**: JSON Web Token generation and validation
- **Token Rotation**: Automatic token refresh before expiry
- **Callbacks**: React to token refresh events
- **Production Patterns**: Service-to-service authentication

**Run:**
```bash
python examples/security/02_authentication.py
```

#### 3. Encryption (`03_encryption.py`)

Covers encryption and cryptographic operations:

- **Fernet Encryption**: Simple symmetric encryption
- **AES-256-GCM**: Advanced authenticated encryption
- **Password Hashing**: Secure password storage with PBKDF2
- **Token Generation**: Cryptographically secure random tokens
- **Constant-Time Comparison**: Timing attack prevention
- **Data Hashing**: Integrity verification with SHA-256/512
- **Production Patterns**: Database field encryption, config files

**Run:**
```bash
python examples/security/03_encryption.py
```

### Quick Start

```python
# Secret management
from dspu.security import SecretManager

secrets = SecretManager.from_env()
api_key = await secrets.get("api/key")

# Authentication
from dspu.security import create_auth_provider

auth = create_auth_provider("jwt", secret_key="secret")
token = await auth.get_token(scopes=["read", "write"])

# Encryption
from dspu.security import Fernet

key = Fernet.generate_key()
cipher = Fernet(key)
encrypted = cipher.encrypt(b"secret data")
decrypted = cipher.decrypt(encrypted)
```

### Installation

```bash
# Install with security extras
uv pip install dspu[security]

# Or with pip
pip install dspu[security]
```

This includes:
- `cryptography` - Encryption algorithms
- `pyjwt` - JWT token support
- `hvac` - HashiCorp Vault integration

### Production Considerations

#### Secret Management
- ✅ Use Vault or cloud secret managers (AWS, GCP, Azure) in production
- ❌ Don't use file-based secrets in production
- ✅ Rotate secrets regularly
- ✅ Use strong encryption for stored secrets

#### Authentication
- ✅ Use short-lived tokens (15-60 minutes)
- ✅ Implement token rotation for long-running services
- ✅ Store JWT secrets securely (secret manager)
- ✅ Use HTTPS for all token transmission

#### Encryption
- ✅ Generate keys using cryptographically secure methods
- ✅ Store encryption keys separately from encrypted data
- ✅ Use AES-256-GCM for authenticated encryption
- ✅ Implement key rotation strategy
- ❌ Don't hardcode encryption keys in source code

### Backend Support

| Backend | Production Ready | Use Case |
|---------|------------------|----------|
| Environment Variables | ✅ Yes | Simple deployments, containers |
| File-Based | ❌ No | Development only |
| HashiCorp Vault | ✅ Yes | Enterprise secret management |
| AWS Secrets Manager | ✅ Yes | AWS deployments |
| Azure Key Vault | 🚧 Planned | Azure deployments |
| GCP Secret Manager | 🚧 Planned | GCP deployments |

### Testing

Run security module tests:

```bash
# All security tests
uv run pytest tests/unit/security/ -v

# Specific test file
uv run pytest tests/unit/security/test_backends.py -v

# With coverage
uv run pytest tests/unit/security/ --cov=src/dspu/security
```

### Additional Resources

- [Security Module Design](../../docs/design.md#4-security-module)
- [API Documentation](../../docs/api/security.md)
- [Best Practices Guide](../../docs/security-best-practices.md)

### Common Patterns

#### 1. Loading Application Secrets

```python
import os
from dspu.security import SecretManager

# Auto-detect backend from environment
secrets = SecretManager.from_env()

# Load database credentials
db_password = await secrets.get("database/password")
db_url = f"postgresql://user:{db_password}@host/db"

# Load API keys
api_key = await secrets.get("api/key")
```

#### 2. Service Authentication

```python
from dspu.security import JWTProvider, RotatingToken, TokenData

# JWT provider
auth = JWTProvider(
    secret_key=await secrets.get("jwt/secret"),
    issuer="my-service",
    expiry_seconds=900
)

# Auto-rotating token for long-running service
async def fetch_token() -> TokenData:
    token = await auth.get_token(scopes=["api:read", "api:write"])
    # Parse JWT for expiry...
    return TokenData(token=token, expires_at=expiry_time)

async with RotatingToken(fetch_fn=fetch_token) as rotating:
    # Use rotating.current for API calls
    headers = {"Authorization": f"Bearer {rotating.current}"}
```

#### 3. Encrypting Sensitive Data

```python
from dspu.security import Fernet

# Get encryption key from secrets
key = await secrets.get("encryption/key")
cipher = Fernet(key.encode())

# Encrypt before storing
user.email_encrypted = cipher.encrypt(user.email)
user.phone_encrypted = cipher.encrypt(user.phone)

# Decrypt when needed
email = cipher.decrypt_str(user.email_encrypted)
```

---

### Support

For issues or questions:
- [GitHub Issues](https://github.com/deepsaia/dspu/issues)
- [Documentation](https://deepsaia.github.io/dspu)
