"""Encryption examples with dspu.

This example demonstrates:
- Symmetric encryption with Fernet
- AES-256-GCM encryption
- Password hashing and verification
- Token generation
- Data hashing
"""

from dspu.security.encryption import (
    AES,
    Fernet,
    constant_time_compare,
    generate_token,
    hash_data,
    hash_password,
    verify_password,
)


def example_fernet_encryption():
    """Example 1: Fernet symmetric encryption."""
    print("\n" + "=" * 70)
    print("Example 1: Fernet Symmetric Encryption")
    print("=" * 70)

    print("\n1. Generating encryption key:")
    key = Fernet.generate_key()
    print(f"   Key: {key[:30].decode()}...")

    print("\n2. Creating cipher:")
    cipher = Fernet(key)

    print("\n3. Encrypting data:")
    plaintext = b"This is a secret message!"
    encrypted = cipher.encrypt(plaintext)
    print(f"   Plaintext: {plaintext.decode()}")
    print(f"   Encrypted: {encrypted[:50]}...")

    print("\n4. Decrypting data:")
    decrypted = cipher.decrypt(encrypted)
    print(f"   Decrypted: {decrypted.decode()}")
    assert decrypted == plaintext

    print("\n5. Encrypting strings (auto-converted to bytes):")
    encrypted_str = cipher.encrypt("Secret string data")
    decrypted_str = cipher.decrypt_str(encrypted_str)
    print("   Original: Secret string data")
    print(f"   Decrypted: {decrypted_str}")


def example_aes_encryption():
    """Example 2: AES-256-GCM encryption."""
    print("\n" + "=" * 70)
    print("Example 2: AES-256-GCM Encryption")
    print("=" * 70)

    print("\n1. Generating AES-256 key (32 bytes):")
    key = AES.generate_key()
    print(f"   Key length: {len(key)} bytes")

    print("\n2. Creating AES cipher:")
    cipher = AES(key)

    print("\n3. Encrypting data:")
    plaintext = b"Confidential data"
    encrypted, nonce = cipher.encrypt(plaintext)
    print(f"   Plaintext: {plaintext.decode()}")
    print(f"   Encrypted: {encrypted[:40]}...")
    print(f"   Nonce: {nonce.hex()}")

    print("\n4. Decrypting data:")
    decrypted = cipher.decrypt(encrypted, nonce)
    print(f"   Decrypted: {decrypted.decode()}")

    print("\n5. Authenticated encryption (with associated data):")
    metadata = b"user_id=123,timestamp=2024"
    encrypted, nonce = cipher.encrypt(plaintext, associated_data=metadata)
    print(f"   Metadata: {metadata.decode()}")
    print("   Encrypted with metadata authentication")

    # Must provide same metadata to decrypt
    decrypted = cipher.decrypt(encrypted, nonce, associated_data=metadata)
    print("   Decrypted successfully with correct metadata")

    print("\n6. Tampering detection:")
    try:
        # Trying to decrypt with wrong metadata
        wrong_metadata = b"user_id=999,timestamp=2024"
        cipher.decrypt(encrypted, nonce, associated_data=wrong_metadata)
        print("   ERROR: Should have failed!")
    except Exception:
        print("   ✓ Tampering detected! Decryption failed with wrong metadata")


def example_password_hashing():
    """Example 3: Password hashing and verification."""
    print("\n" + "=" * 70)
    print("Example 3: Password Hashing and Verification")
    print("=" * 70)

    print("\n1. Hashing a password:")
    password = "my-secure-password-123"
    hash_str, salt = hash_password(password)
    print(f"   Password: {password}")
    print(f"   Hash: {hash_str[:40]}...")
    print(f"   Salt: {salt[:20].hex()}...")

    print("\n2. Verifying correct password:")
    is_valid = verify_password(password, hash_str, salt)
    print(f"   Valid: {is_valid}")

    print("\n3. Verifying incorrect password:")
    is_valid = verify_password("wrong-password", hash_str, salt)
    print(f"   Valid: {is_valid}")

    print("\n4. Same password, different salt = different hash:")
    hash1, salt1 = hash_password(password)
    hash2, salt2 = hash_password(password)
    print(f"   Hash 1: {hash1[:30]}...")
    print(f"   Hash 2: {hash2[:30]}...")
    print(f"   Same hashes: {hash1 == hash2}")

    print("\n5. User registration pattern:")
    users_db = {}

    def register_user(username: str, password: str):
        hash_str, salt = hash_password(password)
        users_db[username] = {"hash": hash_str, "salt": salt}
        print(f"   ✓ User '{username}' registered")

    def login_user(username: str, password: str) -> bool:
        if username not in users_db:
            return False
        user_data = users_db[username]
        return verify_password(password, user_data["hash"], user_data["salt"])

    register_user("alice", "alice-password")
    print(f"   Login with correct password: {login_user('alice', 'alice-password')}")
    print(f"   Login with wrong password: {login_user('alice', 'wrong')}")


def example_token_generation():
    """Example 4: Secure token generation."""
    print("\n" + "=" * 70)
    print("Example 4: Secure Token Generation")
    print("=" * 70)

    print("\n1. Generating random tokens:")
    api_key = generate_token(32)
    session_id = generate_token(16)
    csrf_token = generate_token(24)

    print(f"   API Key (32 bytes): {api_key[:40]}...")
    print(f"   Session ID (16 bytes): {session_id}")
    print(f"   CSRF Token (24 bytes): {csrf_token[:40]}...")

    print("\n2. Token uniqueness test:")
    tokens = set(generate_token(16) for _ in range(1000))
    print("   Generated 1000 tokens")
    print(f"   All unique: {len(tokens) == 1000}")

    print("\n3. Use cases:")
    print("   - API keys for service authentication")
    print("   - Session IDs for user sessions")
    print("   - CSRF tokens for form protection")
    print("   - Password reset tokens")


def example_constant_time_compare():
    """Example 5: Constant-time string comparison."""
    print("\n" + "=" * 70)
    print("Example 5: Constant-Time Comparison (Timing Attack Prevention)")
    print("=" * 70)

    secret_token = "secret-token-12345"

    print("\n1. Comparing tokens safely:")
    user_token1 = "secret-token-12345"
    user_token2 = "wrong-token"

    match1 = constant_time_compare(secret_token, user_token1)
    match2 = constant_time_compare(secret_token, user_token2)

    print(f"   Correct token: {match1}")
    print(f"   Wrong token: {match2}")

    print("\n2. Why constant-time matters:")
    print("   - Regular == comparison may leak information via timing")
    print("   - Attackers can use timing differences to guess secrets")
    print("   - constant_time_compare takes same time regardless of match")

    print("\n3. Use in API authentication:")

    def authenticate_api_request(provided_token: str) -> bool:
        """Authenticate API request with timing attack protection."""
        expected_token = "api-secret-key-abc123"
        return constant_time_compare(provided_token, expected_token)

    print(f"   Valid token: {authenticate_api_request('api-secret-key-abc123')}")
    print(f"   Invalid token: {authenticate_api_request('wrong-key')}")


def example_data_hashing():
    """Example 6: Data hashing and integrity checking."""
    print("\n" + "=" * 70)
    print("Example 6: Data Hashing and Integrity Checking")
    print("=" * 70)

    data = b"Important file content that must not be tampered with"

    print("\n1. Hashing data with SHA-256:")
    sha256_hash = hash_data(data, algorithm="sha256")
    print(f"   Data: {data[:30].decode()}...")
    print(f"   SHA-256: {sha256_hash}")

    print("\n2. Verifying data integrity:")
    # Simulate receiving data and hash
    received_data = b"Important file content that must not be tampered with"
    received_hash = sha256_hash

    computed_hash = hash_data(received_data, algorithm="sha256")
    integrity_ok = computed_hash == received_hash
    print(f"   Integrity check: {integrity_ok}")

    print("\n3. Detecting tampering:")
    tampered_data = b"Important file content that WAS tampered with!!!"
    tampered_hash = hash_data(tampered_data, algorithm="sha256")
    tampering_detected = tampered_hash != received_hash
    print(f"   Tampering detected: {tampering_detected}")

    print("\n4. Different hash algorithms:")
    print(f"   MD5:    {hash_data(data, 'md5')}")
    print(f"   SHA-1:  {hash_data(data, 'sha1')}")
    print(f"   SHA-256: {hash_data(data, 'sha256')[:64]}")
    print(f"   SHA-512: {hash_data(data, 'sha512')[:64]}...")

    print("\n5. Use cases:")
    print("   - File integrity verification")
    print("   - Checksum validation")
    print("   - Content addressing")
    print("   - Digital signatures")


def example_production_encryption():
    """Example 7: Production encryption patterns."""
    print("\n" + "=" * 70)
    print("Example 7: Production Encryption Patterns")
    print("=" * 70)

    print("\n1. Encrypting sensitive database fields:")

    # Generate and store key securely (e.g., in environment variable)
    encryption_key = Fernet.generate_key()
    cipher = Fernet(encryption_key)

    # Simulated database record
    user_record = {
        "id": 123,
        "username": "alice",
        "email_encrypted": cipher.encrypt("alice@example.com"),
        "phone_encrypted": cipher.encrypt("+1-555-0123"),
    }

    print(f"   User ID: {user_record['id']}")
    print(f"   Username: {user_record['username']}")
    print(f"   Email (encrypted): {user_record['email_encrypted'][:40]}...")

    # Decrypt when needed
    email = cipher.decrypt_str(user_record["email_encrypted"])
    print(f"   Email (decrypted): {email}")

    print("\n2. Secure configuration file:")
    # Encrypt sensitive config values
    config = {
        "app_name": "MyApp",
        "database_url": cipher.encrypt("postgresql://user:pass@host/db"),
        "api_key": cipher.encrypt("secret-api-key-123"),
        "jwt_secret": cipher.encrypt("jwt-signing-secret"),
    }

    print("   Config with encrypted secrets stored safely")
    print("   Decrypt on application startup")

    print("\n3. Key rotation strategy:")
    print("   - Generate new key periodically")
    print("   - Re-encrypt data with new key")
    print("   - Maintain old key temporarily for transition")
    print("   - Update key reference in environment/secret manager")


def main():
    """Run all encryption examples."""
    print("\n" + "=" * 70)
    print("DSPU Security: Encryption Examples")
    print("=" * 70)

    example_fernet_encryption()
    example_aes_encryption()
    example_password_hashing()
    example_token_generation()
    example_constant_time_compare()
    example_data_hashing()
    example_production_encryption()

    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    main()
