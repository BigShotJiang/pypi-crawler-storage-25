"""Authentication examples with dspu.

This example demonstrates:
- Static token authentication
- JWT token generation and validation
- Token rotation management
- OAuth2 authentication (requires httpx)
"""

import asyncio
import time

from dspu.security import (
    JWTProvider,
    RotatingToken,
    StaticTokenProvider,
    TokenData,
    create_auth_provider,
)


async def example_static_token():
    """Example 1: Static token authentication."""
    print("\n" + "=" * 70)
    print("Example 1: Static Token Authentication")
    print("=" * 70)

    # Create static token provider
    provider = StaticTokenProvider(token="my-api-key-12345")

    print("\n1. Getting token:")
    token = await provider.get_token()
    print(f"   Token: {token}")

    print("\n2. Validating token:")
    is_valid = await provider.validate_token("my-api-key-12345")
    print(f"   Valid: {is_valid}")

    is_invalid = await provider.validate_token("wrong-token")
    print(f"   Invalid token: {is_invalid}")

    print("\n3. Refreshing token (returns same token):")
    refreshed = await provider.refresh_token()
    print(f"   Refreshed token: {refreshed}")


async def example_jwt_tokens():
    """Example 2: JWT token generation and validation."""
    print("\n" + "=" * 70)
    print("Example 2: JWT Tokens")
    print("=" * 70)

    # Create JWT provider
    provider = JWTProvider(
        secret_key="my-secret-key-12345",
        algorithm="HS256",
        issuer="my-app",
        audience="api-users",
        expiry_seconds=3600,  # 1 hour
    )

    print("\n1. Generating JWT token:")
    token = await provider.get_token(scopes=["read", "write"])
    print(f"   Token: {token[:50]}...")

    print("\n2. Decoding token payload:")
    payload = provider.decode_token(token)
    print(f"   Issuer: {payload['iss']}")
    print(f"   Audience: {payload['aud']}")
    print(f"   Scopes: {payload['scopes']}")
    print(f"   Issued at: {time.ctime(payload['iat'])}")
    print(f"   Expires at: {time.ctime(payload['exp'])}")

    print("\n3. Validating token:")
    is_valid = await provider.validate_token(token)
    print(f"   Token valid: {is_valid}")

    print("\n4. Token with different scopes:")
    admin_token = await provider.get_token(scopes=["read", "write", "admin"])
    admin_payload = provider.decode_token(admin_token)
    print(f"   Admin scopes: {admin_payload['scopes']}")


async def example_rotating_token():
    """Example 3: Automatic token rotation."""
    print("\n" + "=" * 70)
    print("Example 3: Automatic Token Rotation")
    print("=" * 70)

    # Simulate a token fetch function
    call_count = [0]

    async def fetch_token() -> TokenData:
        call_count[0] += 1
        print(f"\n   [Fetch #{call_count[0]}] Fetching new token...")
        return TokenData(
            token=f"token-{call_count[0]}",
            expires_at=time.time() + 2,  # Expires in 2 seconds
            scopes=["read", "write"],
        )

    print("\n1. Creating rotating token manager:")
    print("   Refresh interval: 2 seconds")
    print("   Refresh before expiry: 0.5 seconds")

    async with RotatingToken(
        fetch_fn=fetch_token,
        refresh_interval=None,  # Use token expiry
        refresh_before=0.5,  # Refresh 0.5s before expiry
    ) as rotating_token:
        print(f"\n2. Initial token: {rotating_token.current}")

        # Use token for a while
        print("\n3. Using token...")
        for i in range(3):
            await asyncio.sleep(0.7)
            print(f"   Iteration {i + 1}: Token = {rotating_token.current}")

        print("\n4. Token data:")
        token_data = rotating_token.token_data
        if token_data:
            print(f"   Scopes: {token_data.scopes}")
            expires_in = token_data.expires_in()
            if expires_in:
                print(f"   Expires in: {expires_in:.2f} seconds")

    print(f"\n5. Total token fetches: {call_count[0]}")


async def example_token_with_callback():
    """Example 4: Token rotation with callback."""
    print("\n" + "=" * 70)
    print("Example 4: Token Rotation with Callback")
    print("=" * 70)

    refresh_count = [0]

    async def fetch_token() -> TokenData:
        return TokenData(
            token=f"token-{time.time()}",
            expires_at=time.time() + 1,
        )

    async def on_token_refresh(token_data: TokenData) -> None:
        refresh_count[0] += 1
        print(f"\n   [Callback] Token refreshed! (count: {refresh_count[0]})")
        print(f"   New token: {token_data.token[:30]}...")

    print("\n1. Creating rotating token with callback:")

    async with RotatingToken(
        fetch_fn=fetch_token,
        refresh_interval=1.5,  # Refresh every 1.5 seconds
        on_refresh=on_token_refresh,
    ) as rotating_token:
        print(f"   Initial token: {rotating_token.current[:30]}...")

        # Wait for automatic refreshes
        await asyncio.sleep(3.5)

        print(f"\n2. Token refreshed {refresh_count[0]} times")


async def example_auth_provider_factory():
    """Example 5: Using auth provider factory."""
    print("\n" + "=" * 70)
    print("Example 5: Auth Provider Factory")
    print("=" * 70)

    print("\n1. Creating static provider:")
    static_provider = create_auth_provider("static", token="my-static-token")
    token = await static_provider.get_token()
    print(f"   Token: {token}")

    print("\n2. Creating JWT provider:")
    jwt_provider = create_auth_provider(
        "jwt",
        secret_key="secret-123",
        algorithm="HS256",
        expiry_seconds=3600,
    )
    jwt_token = await jwt_provider.get_token(scopes=["read"])
    print(f"   JWT Token: {jwt_token[:50]}...")

    print("\n3. Provider types available:")
    print("   - static: Simple static token")
    print("   - jwt: JSON Web Tokens")
    print("   - oauth2: OAuth2 client credentials (requires httpx)")


async def example_production_pattern():
    """Example 6: Production authentication pattern."""
    print("\n" + "=" * 70)
    print("Example 6: Production Authentication Pattern")
    print("=" * 70)

    print("\n1. Simulating production API authentication:")

    # JWT provider for service-to-service auth
    auth_provider = JWTProvider(
        secret_key="production-secret-key",
        issuer="my-service",
        audience="api-gateway",
        expiry_seconds=900,  # 15 minutes
    )

    # Get token for API call
    print("\n2. Getting authentication token:")
    token = await auth_provider.get_token(scopes=["api:read", "api:write"])
    print(f"   Token obtained: {token[:40]}...")

    # Simulate API calls
    print("\n3. Making API calls:")
    for i in range(3):
        # In real code, you'd use this token in HTTP headers
        # headers = {"Authorization": f"Bearer {token}"}
        is_valid = await auth_provider.validate_token(token)
        print(f"   Call {i + 1}: Token valid = {is_valid}")
        await asyncio.sleep(0.5)

    # Token rotation for long-running service
    print("\n4. Setting up token rotation for long-running service:")

    async def fetch_service_token() -> TokenData:
        token = await auth_provider.get_token(scopes=["api:read", "api:write"])
        # Parse expiry from JWT
        import base64
        import json

        payload = token.split(".")[1]
        # Add padding if needed
        payload += "=" * (4 - len(payload) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(payload))

        return TokenData(
            token=token,
            expires_at=decoded["exp"],
            scopes=decoded.get("scopes", []),
        )

    print("   Token will auto-refresh before expiry")
    print("   Service can run indefinitely with valid tokens")


async def main():
    """Run all authentication examples."""
    print("\n" + "=" * 70)
    print("DSPU Security: Authentication Examples")
    print("=" * 70)

    await example_static_token()
    await example_jwt_tokens()
    await example_rotating_token()
    await example_token_with_callback()
    await example_auth_provider_factory()
    await example_production_pattern()

    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
