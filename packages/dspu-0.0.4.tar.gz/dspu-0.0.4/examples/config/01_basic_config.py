"""Example: Basic Configuration Loading.

This example demonstrates the fundamentals of loading and validating
configuration using dspu.config with Pydantic models.
"""

from pathlib import Path

from pydantic import BaseModel, Field

from dspu.config.config import Config
from dspu.config.sources import DictSource, FileSource

# Get the examples directory
EXAMPLES_DIR = Path(__file__).parent.parent
SAMPLE_INPUTS = EXAMPLES_DIR / "sample_inputs" / "config"


# Example 1: Simple Configuration
# ================================
class SimpleConfig(BaseModel):
    """A simple configuration model."""

    app_name: str
    debug: bool = False
    port: int = Field(default=8000, ge=1, le=65535)


def example_dict_source() -> None:
    """Load configuration from a Python dictionary."""
    print("=" * 60)
    print("1. Loading from Dictionary (DictSource)")
    print("=" * 60)

    # Create config from a dictionary
    config = Config.load(
        SimpleConfig,
        sources=[
            DictSource(
                {
                    "app_name": "my-app",
                    "debug": True,
                    "port": 9000,
                }
            )
        ],
    )

    print(f"App name: {config.app_name}")
    print(f"Debug mode: {config.debug}")
    print(f"Port: {config.port}")


def example_default_values() -> None:
    """Demonstrate default values with minimal config."""
    print("\n" + "=" * 60)
    print("2. Using Default Values")
    print("=" * 60)

    # Only provide required field, use defaults for the rest
    config = Config.load(
        SimpleConfig,
        sources=[
            DictSource(
                {
                    "app_name": "minimal-app",
                    # debug and port will use defaults
                }
            )
        ],
    )

    print(f"App name: {config.app_name}")
    print(f"Debug mode: {config.debug} (default)")
    print(f"Port: {config.port} (default)")


# Example 2: Loading from Files
# ===============================
def example_yaml_file() -> None:
    """Load configuration from YAML file."""
    print("\n" + "=" * 60)
    print("3. Loading from YAML File")
    print("=" * 60)

    class AppConfig(BaseModel):
        app_name: str
        version: str
        debug: bool
        log_level: str

    yaml_path = SAMPLE_INPUTS / "app_config.yaml"
    config = Config.load(
        AppConfig,
        sources=[FileSource(yaml_path)],
    )

    print(f"Loaded from: {yaml_path}")
    print(f"App name: {config.app_name}")
    print(f"Version: {config.version}")
    print(f"Debug: {config.debug}")
    print(f"Log level: {config.log_level}")


def example_json_file() -> None:
    """Load configuration from JSON file."""
    print("\n" + "=" * 60)
    print("4. Loading from JSON File")
    print("=" * 60)

    class AppConfig(BaseModel):
        app_name: str
        version: str
        debug: bool

    json_path = SAMPLE_INPUTS / "app_config.json"
    config = Config.load(
        AppConfig,
        sources=[FileSource(json_path)],
    )

    print(f"Loaded from: {json_path}")
    print(f"App name: {config.app_name}")
    print(f"Version: {config.version}")
    print(f"Debug: {config.debug}")


def example_toml_file() -> None:
    """Load configuration from TOML file."""
    print("\n" + "=" * 60)
    print("5. Loading from TOML File")
    print("=" * 60)

    class AppConfig(BaseModel):
        app_name: str
        version: str
        debug: bool

    toml_path = SAMPLE_INPUTS / "app_config.toml"
    config = Config.load(
        AppConfig,
        sources=[FileSource(toml_path)],
    )

    print(f"Loaded from: {toml_path}")
    print(f"App name: {config.app_name}")
    print(f"Version: {config.version}")
    print(f"Debug: {config.debug}")


# Example 3: Convenience Methods
# ================================
def example_convenience_methods() -> None:
    """Demonstrate convenience methods."""
    print("\n" + "=" * 60)
    print("6. Convenience Methods")
    print("=" * 60)

    class AppConfig(BaseModel):
        app_name: str
        debug: bool = False

    # Method 1: load_from_file() - shorthand for single file
    print("\nMethod 1: Config.load_from_file()")
    config1 = Config.load_from_file(
        AppConfig,
        str(SAMPLE_INPUTS / "app_config.yaml"),
    )
    print(f"  App name: {config1.app_name}")

    # Method 2: load() with FileSource - more explicit
    print("\nMethod 2: Config.load() with FileSource")
    config2 = Config.load(
        AppConfig,
        sources=[FileSource(SAMPLE_INPUTS / "app_config.yaml")],
    )
    print(f"  App name: {config2.app_name}")

    print("\nBoth methods produce the same result!")


# Example 4: Nested Configuration
# =================================
class DatabaseConfig(BaseModel):
    """Database configuration."""

    host: str = "localhost"
    port: int = 5432
    username: str = "postgres"
    database: str = "myapp"
    pool_size: int = 10


class AppConfigWithNested(BaseModel):
    """App config with nested database config."""

    app_name: str
    debug: bool = False
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)


def example_nested_config() -> None:
    """Demonstrate nested configuration."""
    print("\n" + "=" * 60)
    print("7. Nested Configuration")
    print("=" * 60)

    yaml_path = SAMPLE_INPUTS / "app_config.yaml"
    config = Config.load(
        AppConfigWithNested,
        sources=[FileSource(yaml_path)],
    )

    print(f"App name: {config.app_name}")
    print("\nDatabase config:")
    print(f"  Host: {config.database.host}")
    print(f"  Port: {config.database.port}")
    print(f"  Database: {config.database.database}")
    print(f"  Pool size: {config.database.pool_size}")


# Example 5: Validation
# =======================
def example_validation() -> None:
    """Demonstrate Pydantic validation."""
    print("\n" + "=" * 60)
    print("8. Automatic Validation")
    print("=" * 60)

    from dspu.core.exceptions import ValidationError

    class ServerConfig(BaseModel):
        host: str
        port: int = Field(ge=1, le=65535)
        workers: int = Field(ge=1, le=100)

    # Valid configuration
    print("\n✓ Valid configuration:")
    try:
        config = Config.load(
            ServerConfig,
            sources=[
                DictSource(
                    {
                        "host": "0.0.0.0",
                        "port": 8000,
                        "workers": 4,
                    }
                )
            ],
        )
        print(f"  Host: {config.host}")
        print(f"  Port: {config.port}")
        print(f"  Workers: {config.workers}")
    except ValidationError as e:
        print(f"  Error: {e}")

    # Invalid port (too high)
    print("\n✗ Invalid configuration (port out of range):")
    try:
        config = Config.load(
            ServerConfig,
            sources=[
                DictSource(
                    {
                        "host": "0.0.0.0",
                        "port": 99999,  # Invalid!
                        "workers": 4,
                    }
                )
            ],
        )
    except ValidationError as e:
        print(f"  Error: {e}")
        print(f"  Field: {e.field}")
        print(f"  Constraint: {e.constraint}")

    # Missing required field
    print("\n✗ Invalid configuration (missing required field):")
    try:
        config = Config.load(
            ServerConfig,
            sources=[
                DictSource(
                    {
                        "port": 8000,
                        # Missing 'host'!
                    }
                )
            ],
        )
    except ValidationError as e:
        print(f"  Error: {e}")
        print(f"  Field: {e.field}")


# Example 6: Type Coercion
# =========================
def example_type_coercion() -> None:
    """Demonstrate automatic type coercion."""
    print("\n" + "=" * 60)
    print("9. Automatic Type Coercion")
    print("=" * 60)

    class TypedConfig(BaseModel):
        count: int
        ratio: float
        enabled: bool

    # Pydantic automatically converts compatible types
    config = Config.load(
        TypedConfig,
        sources=[
            DictSource(
                {
                    "count": "42",  # String -> int
                    "ratio": "0.75",  # String -> float
                    "enabled": "true",  # String -> bool
                }
            )
        ],
    )

    print("Input (all strings):")
    print('  count: "42"')
    print('  ratio: "0.75"')
    print('  enabled: "true"')

    print("\nOutput (coerced types):")
    print(f"  count: {config.count} ({type(config.count).__name__})")
    print(f"  ratio: {config.ratio} ({type(config.ratio).__name__})")
    print(f"  enabled: {config.enabled} ({type(config.enabled).__name__})")


# Main demonstration
# ===================
def main() -> None:
    """Run all basic configuration examples."""
    print("\n" + "=" * 60)
    print("DSPU Basic Configuration Examples")
    print("=" * 60)

    example_dict_source()
    example_default_values()
    example_yaml_file()
    example_json_file()
    example_toml_file()
    example_convenience_methods()
    example_nested_config()
    example_validation()
    example_type_coercion()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
