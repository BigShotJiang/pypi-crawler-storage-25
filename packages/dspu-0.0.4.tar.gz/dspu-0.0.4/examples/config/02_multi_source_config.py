"""Example: Multi-Source Configuration.

This example demonstrates loading configuration from multiple sources
with priority ordering. Later sources override earlier ones, enabling
powerful layered configuration patterns.
"""

import os
import tempfile
from pathlib import Path

from pydantic import BaseModel, Field

from dspu.config.config import Config
from dspu.config.sources import DictSource, EnvSource, FileSource

# Get the examples directory
EXAMPLES_DIR = Path(__file__).parent.parent
SAMPLE_INPUTS = EXAMPLES_DIR / "sample_inputs" / "config"


# Configuration models
# ====================
class DatabaseConfig(BaseModel):
    """Database configuration."""

    host: str = "localhost"
    port: int = 5432
    username: str = "postgres"
    password: str = "changeme"
    database: str = "myapp"
    pool_size: int = 10


class RedisConfig(BaseModel):
    """Redis configuration."""

    host: str = "localhost"
    port: int = 6379
    db: int = 0


class AppConfig(BaseModel):
    """Application configuration."""

    app_name: str
    debug: bool = False
    log_level: str = "INFO"
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)


# Example 1: Override with Later Sources
# ========================================
def example_source_priority() -> None:
    """Demonstrate source priority (later sources override earlier)."""
    print("=" * 60)
    print("1. Source Priority (Later Sources Win)")
    print("=" * 60)

    config = Config.load(
        AppConfig,
        sources=[
            # Source 1: Base defaults
            DictSource(
                {
                    "app_name": "myapp",
                    "debug": False,
                    "log_level": "INFO",
                }
            ),
            # Source 2: Override debug and log_level
            DictSource(
                {
                    "debug": True,
                    "log_level": "DEBUG",
                }
            ),
        ],
    )

    print("Source 1 (base): app_name='myapp', debug=False, log_level='INFO'")
    print("Source 2 (override): debug=True, log_level='DEBUG'")
    print("\nResult:")
    print(f"  app_name: {config.app_name} (from source 1)")
    print(f"  debug: {config.debug} (overridden by source 2)")
    print(f"  log_level: {config.log_level} (overridden by source 2)")


# Example 2: Deep Merge for Nested Config
# =========================================
def example_deep_merge() -> None:
    """Demonstrate deep merge of nested configuration."""
    print("\n" + "=" * 60)
    print("2. Deep Merge of Nested Configuration")
    print("=" * 60)

    config = Config.load(
        AppConfig,
        sources=[
            # Source 1: Base database config
            DictSource(
                {
                    "app_name": "myapp",
                    "database": {
                        "host": "localhost",
                        "port": 5432,
                        "database": "myapp_dev",
                        "pool_size": 10,
                    },
                }
            ),
            # Source 2: Override only host and pool_size
            DictSource(
                {
                    "database": {
                        "host": "prod-db.example.com",
                        "pool_size": 50,
                    }
                }
            ),
        ],
    )

    print("Source 1 (base):")
    print("  database.host: localhost")
    print("  database.port: 5432")
    print("  database.database: myapp_dev")
    print("  database.pool_size: 10")
    print("\nSource 2 (override):")
    print("  database.host: prod-db.example.com")
    print("  database.pool_size: 50")
    print("\nResult (deep merge):")
    print(f"  database.host: {config.database.host} (overridden)")
    print(f"  database.port: {config.database.port} (preserved)")
    print(f"  database.database: {config.database.database} (preserved)")
    print(f"  database.pool_size: {config.database.pool_size} (overridden)")


# Example 3: Defaults → File → Environment
# ==========================================
def example_layered_configuration() -> None:
    """Demonstrate layered configuration pattern."""
    print("\n" + "=" * 60)
    print("3. Layered Configuration (Defaults → File → Env)")
    print("=" * 60)

    # Set some environment variables for this example
    os.environ["APP_DEBUG"] = "true"
    os.environ["APP_LOG_LEVEL"] = "DEBUG"
    os.environ["APP_DATABASE__PASSWORD"] = "prod-secret"

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # Layer 1: Application defaults
                DictSource(
                    {
                        "app_name": "default-app",
                        "debug": False,
                        "log_level": "INFO",
                    }
                ),
                # Layer 2: Configuration file
                FileSource(SAMPLE_INPUTS / "app_config.yaml"),
                # Layer 3: Environment variables (highest priority)
                EnvSource(prefix="APP_", separator="__"),
            ],
        )

        print("Layer 1 (defaults): debug=False, log_level='INFO'")
        print("Layer 2 (file): app_name='data-science-app', debug=False")
        print("Layer 3 (env): APP_DEBUG=true, APP_LOG_LEVEL=DEBUG")
        print("\nResult:")
        print(f"  app_name: {config.app_name} (from file)")
        print(f"  debug: {config.debug} (from env)")
        print(f"  log_level: {config.log_level} (from env)")
        print(f"  database.password: {config.database.password} (from env)")

    finally:
        # Clean up environment variables
        os.environ.pop("APP_DEBUG", None)
        os.environ.pop("APP_LOG_LEVEL", None)
        os.environ.pop("APP_DATABASE__PASSWORD", None)


# Example 4: Optional Configuration Files
# =========================================
def example_optional_files() -> None:
    """Demonstrate optional configuration files."""
    print("\n" + "=" * 60)
    print("4. Optional Configuration Files")
    print("=" * 60)

    config = Config.load(
        AppConfig,
        sources=[
            # Base configuration (required)
            FileSource(SAMPLE_INPUTS / "app_config.yaml"),
            # Local overrides (optional - doesn't exist)
            FileSource(
                SAMPLE_INPUTS / "app_config.local.yaml",
                required=False,
            ),
            # Secrets file (optional - doesn't exist)
            FileSource(
                SAMPLE_INPUTS / "secrets.yaml",
                required=False,
            ),
        ],
    )

    print("Source 1: app_config.yaml (required) ✓")
    print("Source 2: app_config.local.yaml (optional, missing) - skipped")
    print("Source 3: secrets.yaml (optional, missing) - skipped")
    print("\nResult:")
    print(f"  app_name: {config.app_name}")
    print(f"  debug: {config.debug}")
    print("  Config loaded successfully despite missing optional files!")


# Example 5: Multi-Format Configuration
# =======================================
def example_multi_format() -> None:
    """Load configuration from multiple file formats."""
    print("\n" + "=" * 60)
    print("5. Multi-Format Configuration")
    print("=" * 60)

    # Create a temporary TOML file for database overrides
    with tempfile.NamedTemporaryFile(mode="w", suffix=".toml", delete=False) as f:
        f.write("""
[database]
pool_size = 25
timeout = 60
""")
        toml_path = f.name

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # Base config from YAML
                FileSource(SAMPLE_INPUTS / "app_config.yaml"),
                # Database overrides from TOML
                FileSource(toml_path),
            ],
        )

        print("Source 1: YAML (base configuration)")
        print("Source 2: TOML (database overrides)")
        print("\nResult:")
        print(f"  app_name: {config.app_name} (from YAML)")
        print(f"  database.host: {config.database.host} (from YAML)")
        print(f"  database.pool_size: {config.database.pool_size} (from TOML)")

    finally:
        Path(toml_path).unlink()


# Example 6: Mixing All Source Types
# ====================================
def example_all_sources() -> None:
    """Demonstrate using all source types together."""
    print("\n" + "=" * 60)
    print("6. Using All Source Types Together")
    print("=" * 60)

    # Set environment variable
    os.environ["APP_DATABASE__PASSWORD"] = "env-password"

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # 1. Hardcoded defaults
                DictSource(
                    {
                        "app_name": "fallback-app",
                        "log_level": "WARNING",
                    }
                ),
                # 2. Base YAML file
                FileSource(SAMPLE_INPUTS / "app_config.yaml"),
                # 3. Optional local overrides
                FileSource(
                    SAMPLE_INPUTS / "config.local.yaml",
                    required=False,
                ),
                # 4. Environment variables
                EnvSource(prefix="APP_", separator="__"),
            ],
        )

        print("Priority order (lowest to highest):")
        print("  1. DictSource (defaults)")
        print("  2. FileSource (YAML)")
        print("  3. FileSource (optional local)")
        print("  4. EnvSource (environment)")
        print("\nResult:")
        print(f"  app_name: {config.app_name} (from YAML)")
        print(f"  log_level: {config.log_level} (from YAML)")
        print(f"  database.password: {config.database.password} (from env)")

    finally:
        os.environ.pop("APP_DATABASE__PASSWORD", None)


# Example 7: Environment-Specific Configuration
# ===============================================
def example_environment_specific() -> None:
    """Load different configs based on environment."""
    print("\n" + "=" * 60)
    print("7. Environment-Specific Configuration")
    print("=" * 60)

    environments = ["development", "staging", "production"]

    for env in environments:
        config_file = SAMPLE_INPUTS / f"config.{env}.yaml"

        if not config_file.exists():
            print(f"\n{env.upper()}: (file not found)")
            continue

        config = Config.load(
            AppConfig,
            sources=[
                # Base defaults
                FileSource(SAMPLE_INPUTS / "app_config.yaml"),
                # Environment-specific overrides
                FileSource(config_file),
            ],
        )

        print(f"\n{env.upper()}:")
        print(f"  debug: {config.debug}")
        print(f"  log_level: {config.log_level}")
        print(f"  database.host: {config.database.host}")
        print(f"  database.pool_size: {config.database.pool_size}")


# Main demonstration
# ===================
def main() -> None:
    """Run all multi-source configuration examples."""
    print("\n" + "=" * 60)
    print("DSPU Multi-Source Configuration Examples")
    print("=" * 60)

    example_source_priority()
    example_deep_merge()
    example_layered_configuration()
    example_optional_files()
    example_multi_format()
    example_all_sources()
    example_environment_specific()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
