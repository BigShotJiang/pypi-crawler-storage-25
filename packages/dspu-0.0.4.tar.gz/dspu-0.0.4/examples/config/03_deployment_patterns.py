"""Example: Deployment Patterns (Docker, Kubernetes, Cloud).

This example demonstrates configuration patterns for different
deployment environments: Docker Compose, Kubernetes, and cloud platforms.
"""

import os
import tempfile
from pathlib import Path

from pydantic import BaseModel, Field

from dspu.config.config import Config
from dspu.config.sources import DictSource, EnvSource, FileSource

# Get the examples directory
EXAMPLES_DIR = Path(__file__).parent.parent
SAMPLE_INPUTS = EXAMPLES_DIR / "sample_inputs" / "config"


# Configuration models
# ====================
class DatabaseConfig(BaseModel):
    """Database configuration."""

    host: str = "localhost"
    port: int = 5432
    username: str = "postgres"
    password: str = "changeme"
    database: str = "myapp"


class RedisConfig(BaseModel):
    """Redis configuration."""

    host: str = "localhost"
    port: int = 6379


class AppConfig(BaseModel):
    """Application configuration."""

    app_name: str
    debug: bool = False
    log_level: str = "INFO"
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)


# Example 1: Docker Compose Pattern
# ===================================
def example_docker_compose() -> None:
    """Configuration pattern for Docker Compose."""
    print("=" * 60)
    print("1. Docker Compose Pattern")
    print("=" * 60)

    print("\nTypical docker-compose.yml:")
    print("""
    services:
      app:
        environment:
          MYAPP_APP_NAME: containerized-app
          MYAPP_DEBUG: "true"
          MYAPP_DATABASE__HOST: postgres
          MYAPP_DATABASE__PORT: "5432"
          MYAPP_DATABASE__USERNAME: app
          MYAPP_DATABASE__PASSWORD: apppass
          MYAPP_DATABASE__DATABASE: appdb
          MYAPP_REDIS__HOST: redis
          MYAPP_REDIS__PORT: "6379"
      postgres:
        image: postgres:15
      redis:
        image: redis:7
    """)

    # Simulate Docker Compose environment
    env_vars = {
        "MYAPP_APP_NAME": "containerized-app",
        "MYAPP_DEBUG": "true",
        "MYAPP_DATABASE__HOST": "postgres",
        "MYAPP_DATABASE__PORT": "5432",
        "MYAPP_DATABASE__USERNAME": "app",
        "MYAPP_DATABASE__PASSWORD": "apppass",
        "MYAPP_DATABASE__DATABASE": "appdb",
        "MYAPP_REDIS__HOST": "redis",
        "MYAPP_REDIS__PORT": "6379",
    }

    # Set environment
    os.environ.update(env_vars)

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # All configuration from environment variables
                EnvSource(prefix="MYAPP_", separator="__"),
            ],
        )

        print("\nLoaded configuration:")
        print(f"  app_name: {config.app_name}")
        print(f"  debug: {config.debug}")
        print(f"  database.host: {config.database.host} (service name)")
        print(f"  database.port: {config.database.port}")
        print(f"  redis.host: {config.redis.host} (service name)")

        print("\n✓ Note: Service names (postgres, redis) are used as hostnames")
        print("  This is how Docker Compose networking works!")

    finally:
        # Clean up
        for key in env_vars:
            os.environ.pop(key, None)


# Example 2: Kubernetes ConfigMap + Secrets
# ===========================================
def example_kubernetes() -> None:
    """Configuration pattern for Kubernetes."""
    print("\n" + "=" * 60)
    print("2. Kubernetes ConfigMap + Secrets")
    print("=" * 60)

    print("\nTypical Kubernetes setup:")
    print("""
    # ConfigMap for non-sensitive config
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: app-config
    data:
      config.yaml: |
        app_name: k8s-app
        debug: false
        log_level: INFO
        database:
          host: postgres-service
          port: 5432

    # Secret for sensitive data (mounted as env vars)
    apiVersion: v1
    kind: Secret
    metadata:
      name: app-secrets
    data:
      DATABASE__PASSWORD: <base64-encoded>
      REDIS__PASSWORD: <base64-encoded>
    """)

    # Create temporary config file (simulating mounted ConfigMap)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("""
app_name: k8s-app
debug: false
log_level: INFO
database:
  host: postgres-service
  port: 5432
  database: production
redis:
  host: redis-service
  port: 6379
""")
        config_path = f.name

    # Simulate Secret as environment variables
    os.environ["DATABASE__PASSWORD"] = "k8s-secret-password"
    os.environ["DATABASE__USERNAME"] = "k8s-user"

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # ConfigMap (mounted as file)
                FileSource(config_path),
                # Secrets (mounted as environment variables)
                EnvSource(prefix="", separator="__"),
            ],
        )

        print("\nLoaded configuration:")
        print(f"  app_name: {config.app_name} (from ConfigMap)")
        print(f"  log_level: {config.log_level} (from ConfigMap)")
        print(f"  database.host: {config.database.host} (from ConfigMap)")
        print(f"  database.username: {config.database.username} (from Secret)")
        print(f"  database.password: {config.database.password} (from Secret)")

        print("\n✓ ConfigMap for non-sensitive config")
        print("✓ Secrets for passwords and keys")

    finally:
        Path(config_path).unlink()
        os.environ.pop("DATABASE__PASSWORD", None)
        os.environ.pop("DATABASE__USERNAME", None)


# Example 3: AWS ECS / Fargate Pattern
# ======================================
def example_aws_ecs() -> None:
    """Configuration pattern for AWS ECS/Fargate."""
    print("\n" + "=" * 60)
    print("3. AWS ECS / Fargate Pattern")
    print("=" * 60)

    print("\nTypical ECS Task Definition:")
    print("""
    {
      "family": "myapp",
      "containerDefinitions": [{
        "environment": [
          {"name": "APP_NAME", "value": "ecs-app"},
          {"name": "LOG_LEVEL", "value": "INFO"}
        ],
        "secrets": [
          {
            "name": "DATABASE__PASSWORD",
            "valueFrom": "arn:aws:secretsmanager:...:secret:db-pass"
          }
        ]
      }]
    }
    """)

    # Simulate ECS environment
    os.environ.update(
        {
            "APP_NAME": "ecs-app",
            "LOG_LEVEL": "INFO",
            "DATABASE__PASSWORD": "secretsmanager-password",
            "DATABASE__HOST": "myapp.cluster-xyz.us-east-1.rds.amazonaws.com",
        }
    )

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # Defaults
                DictSource(
                    {
                        "app_name": "default",
                        "debug": False,
                        "database": {
                            "port": 5432,
                            "database": "production",
                        },
                    }
                ),
                # Environment variables (from ECS Task Definition)
                EnvSource(prefix="", separator="__"),
            ],
        )

        print("\nLoaded configuration:")
        print(f"  app_name: {config.app_name}")
        print(f"  log_level: {config.log_level}")
        print(f"  database.host: {config.database.host}")
        print(f"  database.password: {config.database.password}")
        print("    (from AWS Secrets Manager)")

        print("\n✓ Non-sensitive config from environment variables")
        print("✓ Sensitive values from AWS Secrets Manager")

    finally:
        for key in ["APP_NAME", "LOG_LEVEL", "DATABASE__PASSWORD", "DATABASE__HOST"]:
            os.environ.pop(key, None)


# Example 4: Cloud-Native with Multiple Config Sources
# ======================================================
def example_cloud_native() -> None:
    """Cloud-native pattern with multiple config sources."""
    print("\n" + "=" * 60)
    print("4. Cloud-Native Multi-Source Pattern")
    print("=" * 60)

    print("\nConfiguration sources (in priority order):")
    print("  1. Default values (in code)")
    print("  2. Config file (from container image)")
    print("  3. ConfigMap (Kubernetes)")
    print("  4. Environment variables (platform)")
    print("  5. Secrets (Secrets Manager / Vault)")

    # Create config files
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as base_config:
        base_config.write("""
app_name: cloud-app
debug: false
log_level: INFO
database:
  port: 5432
  database: myapp
redis:
  port: 6379
""")
        base_path = base_config.name

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as k8s_config:
        k8s_config.write("""
log_level: WARNING
database:
  host: prod-postgres.svc.cluster.local
redis:
  host: prod-redis.svc.cluster.local
""")
        k8s_path = k8s_config.name

    # Environment and secrets
    os.environ.update(
        {
            "APP_DEBUG": "false",
            "DATABASE__PASSWORD": "vault-secret-password",
            "DATABASE__USERNAME": "prod-user",
        }
    )

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # 1. Defaults (application code)
                DictSource(
                    {
                        "app_name": "default-app",
                        "debug": True,
                    }
                ),
                # 2. Base config (baked into container)
                FileSource(base_path),
                # 3. Kubernetes ConfigMap
                FileSource(k8s_path),
                # 4. Environment variables
                EnvSource(prefix="APP_", separator="__"),
                # 5. Secrets (from Vault/Secrets Manager as env vars)
                EnvSource(prefix="", separator="__"),
            ],
        )

        print("\nLoaded configuration (showing source for each):")
        print(f"  app_name: {config.app_name}")
        print("    → from base config file")
        print(f"  debug: {config.debug}")
        print("    → from environment (APP_DEBUG)")
        print(f"  log_level: {config.log_level}")
        print("    → from Kubernetes ConfigMap")
        print(f"  database.host: {config.database.host}")
        print("    → from Kubernetes ConfigMap")
        print(f"  database.username: {config.database.username}")
        print("    → from secrets (DATABASE__USERNAME)")
        print(f"  database.password: {config.database.password}")
        print("    → from secrets (DATABASE__PASSWORD)")

        print("\n✓ Layered configuration for maximum flexibility")
        print("✓ Each environment can override what it needs")

    finally:
        Path(base_path).unlink()
        Path(k8s_path).unlink()
        for key in ["APP_DEBUG", "DATABASE__PASSWORD", "DATABASE__USERNAME"]:
            os.environ.pop(key, None)


# Example 5: 12-Factor App Pattern
# ==================================
def example_twelve_factor() -> None:
    """Configuration following 12-factor app principles."""
    print("\n" + "=" * 60)
    print("5. 12-Factor App Pattern")
    print("=" * 60)

    print("\n12-Factor Principle III: Store config in the environment")
    print("https://12factor.net/config")
    print("\nAll configuration from environment variables:")

    # Simulate complete environment-based config
    env_vars = {
        "APP_NAME": "twelve-factor-app",
        "DEBUG": "false",
        "LOG_LEVEL": "INFO",
        "DATABASE__HOST": "db.production.internal",
        "DATABASE__PORT": "5432",
        "DATABASE__USERNAME": "produser",
        "DATABASE__PASSWORD": "prodpass",
        "DATABASE__DATABASE": "production",
        "REDIS__HOST": "cache.production.internal",
        "REDIS__PORT": "6379",
    }

    os.environ.update(env_vars)

    try:
        config = Config.load(
            AppConfig,
            sources=[
                # Only source: environment variables
                EnvSource(prefix="", separator="__"),
            ],
        )

        print("\nLoaded configuration (100% from environment):")
        print(f"  app_name: {config.app_name}")
        print(f"  debug: {config.debug}")
        print(f"  log_level: {config.log_level}")
        print(f"  database.host: {config.database.host}")
        print(f"  redis.host: {config.redis.host}")

        print("\n✓ No config files needed")
        print("✓ Same code runs in any environment")
        print("✓ Easy to change config without rebuilding")

    finally:
        for key in env_vars:
            os.environ.pop(key, None)


# Main demonstration
# ===================
def main() -> None:
    """Run all deployment pattern examples."""
    print("\n" + "=" * 60)
    print("DSPU Deployment Patterns Examples")
    print("=" * 60)

    example_docker_compose()
    example_kubernetes()
    example_aws_ecs()
    example_cloud_native()
    example_twelve_factor()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)
    print("\nKey Takeaways:")
    print("  • Use EnvSource for container/cloud deployments")
    print("  • ConfigMaps for non-sensitive, Secrets for passwords")
    print("  • Layer configs: defaults → file → env → secrets")
    print("  • Follow 12-factor principles for cloud-native apps")


if __name__ == "__main__":
    main()
