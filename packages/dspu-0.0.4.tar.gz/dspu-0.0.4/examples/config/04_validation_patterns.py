"""Example: Advanced Validation Patterns.

This example demonstrates advanced validation techniques using
Pydantic with dspu.config, including custom validators,
field constraints, and validation error handling.
"""

from enum import Enum
from typing import Annotated

from pydantic import (
    BaseModel,
    EmailStr,
    Field,
    HttpUrl,
    field_validator,
    model_validator,
)

from dspu.config.config import Config
from dspu.config.sources import DictSource
from dspu.core.exceptions import ValidationError


# Example 1: Field Constraints
# ==============================
class ServerConfig(BaseModel):
    """Server configuration with field constraints."""

    host: str = Field(
        default="0.0.0.0",
        description="Host to bind to",
    )
    port: int = Field(
        default=8000,
        ge=1,
        le=65535,
        description="Port number (1-65535)",
    )
    workers: int = Field(
        default=4,
        ge=1,
        le=100,
        description="Number of worker processes",
    )
    timeout: float = Field(
        default=30.0,
        gt=0,
        le=300,
        description="Request timeout in seconds",
    )
    max_connections: int = Field(
        default=1000,
        ge=1,
        description="Maximum concurrent connections",
    )


def example_field_constraints() -> None:
    """Demonstrate field constraints."""
    print("=" * 60)
    print("1. Field Constraints")
    print("=" * 60)

    # Valid configuration
    print("\n✓ Valid configuration:")
    config = Config.load(
        ServerConfig,
        sources=[
            DictSource(
                {
                    "host": "127.0.0.1",
                    "port": 8080,
                    "workers": 8,
                    "timeout": 60.0,
                    "max_connections": 5000,
                }
            )
        ],
    )
    print(f"  Port: {config.port} (valid: 1-65535)")
    print(f"  Workers: {config.workers} (valid: 1-100)")
    print(f"  Timeout: {config.timeout} (valid: > 0, <= 300)")

    # Invalid configurations
    print("\n✗ Invalid configurations:")

    test_cases = [
        ({"port": 0}, "port too small"),
        ({"port": 99999}, "port too large"),
        ({"workers": 0}, "workers too small"),
        ({"workers": 200}, "workers too large"),
        ({"timeout": -1}, "negative timeout"),
        ({"timeout": 500}, "timeout too large"),
    ]

    for invalid_data, description in test_cases:
        try:
            Config.load(ServerConfig, sources=[DictSource(invalid_data)])
            print(f"  {description}: SHOULD HAVE FAILED!")
        except ValidationError as e:
            print(f"  {description}: {e.field} - {e.constraint}")


# Example 2: String Patterns and Formats
# ========================================
class ConnectionConfig(BaseModel):
    """Configuration with string patterns."""

    email: EmailStr = Field(description="Contact email")
    webhook_url: HttpUrl = Field(description="Webhook callback URL")
    api_key: str = Field(
        min_length=32,
        max_length=128,
        pattern=r"^sk-[a-zA-Z0-9]+$",
        description="API key (must start with 'sk-')",
    )
    database_url: str = Field(
        pattern=r"^postgresql://.*",
        description="PostgreSQL connection string",
    )


def example_string_patterns() -> None:
    """Demonstrate string patterns and formats."""
    print("\n" + "=" * 60)
    print("2. String Patterns and Formats")
    print("=" * 60)

    # Valid configuration
    print("\n✓ Valid configuration:")
    config = Config.load(
        ConnectionConfig,
        sources=[
            DictSource(
                {
                    "email": "admin@example.com",
                    "webhook_url": "https://api.example.com/webhook",
                    "api_key": "sk-" + "a" * 30,
                    "database_url": "postgresql://localhost/mydb",
                }
            )
        ],
    )
    print(f"  Email: {config.email}")
    print(f"  Webhook: {config.webhook_url}")
    print(f"  API key: {config.api_key[:10]}...")

    # Invalid configurations
    print("\n✗ Invalid configurations:")

    test_cases = [
        ({"email": "not-an-email"}, "invalid email"),
        ({"webhook_url": "not-a-url"}, "invalid URL"),
        ({"api_key": "short"}, "API key too short"),
        ({"api_key": "a" * 40}, "API key wrong format (missing sk-)"),
        ({"database_url": "mysql://localhost"}, "wrong database type"),
    ]

    for invalid_data, description in test_cases:
        # Fill in required fields
        full_data = {
            "email": "admin@example.com",
            "webhook_url": "https://example.com",
            "api_key": "sk-" + "a" * 30,
            "database_url": "postgresql://localhost/db",
        }
        full_data.update(invalid_data)

        try:
            Config.load(ConnectionConfig, sources=[DictSource(full_data)])
            print(f"  {description}: SHOULD HAVE FAILED!")
        except ValidationError as e:
            print(f"  {description}: {e.field}")


# Example 3: Enum Validation
# ===========================
class LogLevel(str, Enum):
    """Log level choices."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class Environment(str, Enum):
    """Environment choices."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class AppConfig(BaseModel):
    """Application config with enums."""

    app_name: str
    environment: Environment
    log_level: LogLevel = LogLevel.INFO


def example_enum_validation() -> None:
    """Demonstrate enum validation."""
    print("\n" + "=" * 60)
    print("3. Enum Validation")
    print("=" * 60)

    # Valid configuration
    print("\n✓ Valid configuration:")
    config = Config.load(
        AppConfig,
        sources=[
            DictSource(
                {
                    "app_name": "myapp",
                    "environment": "production",
                    "log_level": "WARNING",
                }
            )
        ],
    )
    print(f"  Environment: {config.environment}")
    print(f"  Log level: {config.log_level}")

    # Invalid configuration
    print("\n✗ Invalid configuration:")
    try:
        Config.load(
            AppConfig,
            sources=[
                DictSource(
                    {
                        "app_name": "myapp",
                        "environment": "qa",  # Not a valid environment!
                        "log_level": "WARNING",
                    }
                )
            ],
        )
    except ValidationError as e:
        print(f"  Invalid environment: {e.field}")
        print("  Valid choices: development, staging, production")


# Example 4: Custom Validators
# ==============================
class DatabaseConfig(BaseModel):
    """Database config with custom validators."""

    host: str
    port: int = Field(ge=1, le=65535)
    username: str
    password: str = Field(min_length=8)
    database: str
    max_connections: int = Field(ge=1)

    @field_validator("username")
    @classmethod
    def validate_username(cls, v: str) -> str:
        """Validate username format."""
        if not v.islower():
            raise ValueError("Username must be lowercase")
        if not v.isalnum():
            raise ValueError("Username must be alphanumeric")
        return v

    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        """Validate password strength."""
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain uppercase letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain digit")
        return v

    @model_validator(mode="after")
    def validate_connection_pool(self) -> "DatabaseConfig":
        """Validate connection pool size is reasonable."""
        if self.max_connections > 1000:
            raise ValueError(f"max_connections too high: {self.max_connections} > 1000")
        return self


def example_custom_validators() -> None:
    """Demonstrate custom validators."""
    print("\n" + "=" * 60)
    print("4. Custom Validators")
    print("=" * 60)

    # Valid configuration
    print("\n✓ Valid configuration:")
    config = Config.load(
        DatabaseConfig,
        sources=[
            DictSource(
                {
                    "host": "localhost",
                    "port": 5432,
                    "username": "dbuser",
                    "password": "SecurePass123",
                    "database": "myapp",
                    "max_connections": 100,
                }
            )
        ],
    )
    print(f"  Username: {config.username}")
    print(f"  Max connections: {config.max_connections}")

    # Invalid configurations
    print("\n✗ Invalid configurations:")

    test_cases = [
        (
            {"username": "DbUser"},
            "username with uppercase",
        ),
        (
            {"username": "db-user"},
            "username with special char",
        ),
        (
            {"password": "weak"},
            "weak password",
        ),
        (
            {"password": "NoDigits"},
            "password without digits",
        ),
        (
            {"max_connections": 2000},
            "too many connections",
        ),
    ]

    for invalid_field, description in test_cases:
        full_data = {
            "host": "localhost",
            "port": 5432,
            "username": "dbuser",
            "password": "SecurePass123",
            "database": "myapp",
            "max_connections": 100,
        }
        full_data.update(invalid_field)

        try:
            Config.load(DatabaseConfig, sources=[DictSource(full_data)])
            print(f"  {description}: SHOULD HAVE FAILED!")
        except ValidationError as e:
            print(f"  {description}: {e}")


# Example 5: Conditional Validation
# ===================================
class AppConfigWithSSL(BaseModel):
    """Config with conditional SSL validation."""

    app_name: str
    use_ssl: bool = False
    ssl_cert_path: str | None = None
    ssl_key_path: str | None = None

    @model_validator(mode="after")
    def validate_ssl_config(self) -> "AppConfigWithSSL":
        """If SSL is enabled, cert and key must be provided."""
        if self.use_ssl:
            if not self.ssl_cert_path:
                raise ValueError("ssl_cert_path required when use_ssl=True")
            if not self.ssl_key_path:
                raise ValueError("ssl_key_path required when use_ssl=True")
        return self


def example_conditional_validation() -> None:
    """Demonstrate conditional validation."""
    print("\n" + "=" * 60)
    print("5. Conditional Validation")
    print("=" * 60)

    # Valid: SSL disabled
    print("\n✓ Valid (SSL disabled):")
    config1 = Config.load(
        AppConfigWithSSL,
        sources=[
            DictSource(
                {
                    "app_name": "myapp",
                    "use_ssl": False,
                }
            )
        ],
    )
    print(f"  use_ssl: {config1.use_ssl}")
    print("  SSL paths not required")

    # Valid: SSL enabled with paths
    print("\n✓ Valid (SSL enabled with paths):")
    config2 = Config.load(
        AppConfigWithSSL,
        sources=[
            DictSource(
                {
                    "app_name": "myapp",
                    "use_ssl": True,
                    "ssl_cert_path": "/etc/ssl/cert.pem",
                    "ssl_key_path": "/etc/ssl/key.pem",
                }
            )
        ],
    )
    print(f"  use_ssl: {config2.use_ssl}")
    print(f"  cert: {config2.ssl_cert_path}")
    print(f"  key: {config2.ssl_key_path}")

    # Invalid: SSL enabled without paths
    print("\n✗ Invalid (SSL enabled without paths):")
    try:
        Config.load(
            AppConfigWithSSL,
            sources=[
                DictSource(
                    {
                        "app_name": "myapp",
                        "use_ssl": True,
                        # Missing cert and key!
                    }
                )
            ],
        )
    except ValidationError as e:
        print(f"  Error: {e}")


# Example 6: Type Aliases with Validation
# =========================================
PositiveInt = Annotated[int, Field(gt=0)]
PercentFloat = Annotated[float, Field(ge=0.0, le=100.0)]
NonEmptyString = Annotated[str, Field(min_length=1)]


class MetricsConfig(BaseModel):
    """Config using type aliases."""

    sample_rate: PercentFloat = 100.0
    buffer_size: PositiveInt = 1000
    metric_prefix: NonEmptyString = "app"


def example_type_aliases() -> None:
    """Demonstrate type aliases with validation."""
    print("\n" + "=" * 60)
    print("6. Type Aliases with Validation")
    print("=" * 60)

    # Valid configuration
    print("\n✓ Valid configuration:")
    config = Config.load(
        MetricsConfig,
        sources=[
            DictSource(
                {
                    "sample_rate": 50.0,
                    "buffer_size": 5000,
                    "metric_prefix": "myapp",
                }
            )
        ],
    )
    print(f"  Sample rate: {config.sample_rate}%")
    print(f"  Buffer size: {config.buffer_size}")
    print(f"  Prefix: {config.metric_prefix}")

    # Invalid configurations
    print("\n✗ Invalid configurations:")

    test_cases = [
        ({"sample_rate": -10.0}, "negative sample rate"),
        ({"sample_rate": 150.0}, "sample rate > 100%"),
        ({"buffer_size": 0}, "zero buffer size"),
        ({"buffer_size": -100}, "negative buffer size"),
        ({"metric_prefix": ""}, "empty prefix"),
    ]

    for invalid_data, description in test_cases:
        try:
            Config.load(MetricsConfig, sources=[DictSource(invalid_data)])
            print(f"  {description}: SHOULD HAVE FAILED!")
        except ValidationError as e:
            print(f"  {description}: {e.field}")


# Main demonstration
# ===================
def main() -> None:
    """Run all validation examples."""
    print("\n" + "=" * 60)
    print("DSPU Validation Patterns Examples")
    print("=" * 60)

    example_field_constraints()
    example_string_patterns()
    example_enum_validation()
    example_custom_validators()
    example_conditional_validation()
    example_type_aliases()

    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)
    print("\nKey Takeaways:")
    print("  • Use Field constraints for ranges and lengths")
    print("  • Use Enums for fixed choices")
    print("  • Custom validators for complex business logic")
    print("  • Model validators for cross-field validation")
    print("  • Type aliases for reusable constraints")


if __name__ == "__main__":
    main()
