# Configuration Module Examples

These examples demonstrate the powerful configuration management features of `dspu.config`.

## Examples

### 1. Basic Configuration (`01_basic_config.py`)

Introduction to configuration loading:

- Loading from dictionaries (DictSource)
- Loading from files (YAML, JSON, TOML)
- Using default values
- Convenience methods (`load_from_file`, `load_from_env`)
- Nested configuration structures
- Automatic validation with Pydantic
- Type coercion

**Key Concepts:**
- Simple, type-safe configuration
- Multiple file format support
- Automatic validation

**Run:**
```bash
uv run python examples/config/01_basic_config.py
```

### 2. Multi-Source Configuration (`02_multi_source_config.py`)

Advanced multi-source patterns:

- Source priority (later sources override earlier)
- Deep merge of nested configuration
- Layered configuration (Defaults → File → Environment)
- Optional configuration files
- Multi-format configuration
- Environment-specific configuration

**Key Concepts:**
- Flexible configuration composition
- Environment-based overrides
- Secrets management

**Run:**
```bash
uv run python examples/config/02_multi_source_config.py
```

### 3. Deployment Patterns (`03_deployment_patterns.py`)

Real-world deployment scenarios:

- **Docker Compose**: Environment variable based config
- **Kubernetes**: ConfigMap + Secrets pattern
- **AWS ECS/Fargate**: ECS Task Definition + Secrets Manager
- **Cloud-Native**: Multi-source layered config
- **12-Factor App**: Pure environment variable config

**Key Concepts:**
- Container orchestration patterns
- Cloud platform integration
- Secrets management best practices
- 12-factor methodology

**Run:**
```bash
uv run python examples/config/03_deployment_patterns.py
```

### 4. Validation Patterns (`04_validation_patterns.py`)

Advanced validation with Pydantic:

- **Field Constraints**: Ranges, lengths, patterns
- **String Patterns**: Email, URL, regex patterns
- **Enum Validation**: Fixed choices
- **Custom Validators**: Business logic validation
- **Conditional Validation**: Cross-field validation
- **Type Aliases**: Reusable validation rules

**Key Concepts:**
- Data validation at load time
- Custom business rules
- Helpful error messages
- Type safety

**Run:**
```bash
uv run python examples/config/04_validation_patterns.py
```

## Sample Input Files

All examples use sample configuration files from `../sample_inputs/config/`:

- `app_config.yaml` - Base YAML configuration
- `app_config.json` - Base JSON configuration
- `app_config.toml` - Base TOML configuration
- `database.conf` - HOCON format example
- `.env.example` - Environment variables template
- `config.development.yaml` - Development overrides
- `config.staging.yaml` - Staging overrides
- `config.production.yaml` - Production overrides

## Common Patterns

### Pattern 1: Local Development

```python
config = Config.load(
    AppConfig,
    sources=[
        FileSource("config.yaml"),                    # Base config
        FileSource("config.local.yaml", required=False),  # Local overrides
        EnvSource(prefix="APP_"),                     # Environment overrides
    ],
)
```

### Pattern 2: Docker Compose

```python
config = Config.load(
    AppConfig,
    sources=[
        EnvSource(prefix="MYAPP_", separator="__"),
    ],
)
```

### Pattern 3: Kubernetes

```python
config = Config.load(
    AppConfig,
    sources=[
        FileSource("/config/app.yaml"),  # ConfigMap
        EnvSource(prefix="", separator="__"),  # Secrets
    ],
)
```

### Pattern 4: Environment-Specific

```python
import os

env = os.getenv("ENV", "development")

config = Config.load(
    AppConfig,
    sources=[
        FileSource("config.yaml"),           # Base
        FileSource(f"config.{env}.yaml"),    # Environment-specific
    ],
)
```

## Best Practices

1. **Layer Your Configuration**
   ```
   Defaults (code) → Base file → Environment file → Environment variables → Secrets
   ```

2. **Never Commit Secrets**
   - Use `.env` files locally (git-ignored)
   - Use Secrets Manager or Vault in production
   - Pass secrets via environment variables

3. **Use Validation**
   - Define Pydantic models with constraints
   - Fail fast with clear error messages
   - Use custom validators for business rules

4. **Environment Variables Convention**
   - Use prefixes: `APP_`, `MYAPP_`
   - Use `__` for nested keys: `APP_DATABASE__PASSWORD`
   - Keep names consistent across environments

5. **Optional Configuration**
   - Make local overrides optional: `required=False`
   - Provide sensible defaults
   - Document required vs optional settings

## Running All Examples

```bash
# Run all config examples
uv run python examples/config/01_basic_config.py
uv run python examples/config/02_multi_source_config.py
uv run python examples/config/03_deployment_patterns.py
uv run python examples/config/04_validation_patterns.py
```

## Next Steps

After understanding configuration:

- **`../core/`** - Core utilities (protocols, registry, exceptions)
- **`../sample_inputs/`** - Sample configuration files

## Configuration File Formats

### Supported Formats

| Format | Extensions | Use Case |
|--------|-----------|----------|
| YAML | `.yaml`, `.yml` | Human-readable, common for configs |
| JSON | `.json` | Machine-readable, APIs |
| TOML | `.toml` | Python ecosystem (pyproject.toml) |
| HOCON | `.conf`, `.hocon` | Akka, complex hierarchical configs |
| ENV | `.env` | Secrets, Docker, simple key=value |

### Format Auto-Detection

DSPU automatically detects the format from the file extension:

```python
config = Config.load_from_file(AppConfig, "config.yaml")  # Auto-detects YAML
config = Config.load_from_file(AppConfig, "config.json")  # Auto-detects JSON
config = Config.load_from_file(AppConfig, "config.toml")  # Auto-detects TOML
```

Or specify explicitly:

```python
config = Config.load_from_file(AppConfig, "settings.txt", format="json")
```

## Troubleshooting

### Common Issues

**Issue**: `ValidationError: Field required`
- **Solution**: Provide the required field or add a default value in your Pydantic model

**Issue**: `ConfigurationError: Configuration file not found`
- **Solution**: Check the file path or use `required=False` for optional files

**Issue**: Environment variables not being picked up
- **Solution**: Check the prefix and separator match your env var names

**Issue**: Values not overriding as expected
- **Solution**: Check source order - later sources override earlier ones

## Learn More

- [Pydantic Documentation](https://docs.pydantic.dev/)
- [12-Factor App Methodology](https://12factor.net/)
- [Docker Compose Environment Variables](https://docs.docker.com/compose/environment-variables/)
- [Kubernetes ConfigMaps](https://kubernetes.io/docs/concepts/configuration/configmap/)
- [Kubernetes Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)

---

### Support

For issues or questions:
- [GitHub Issues](https://github.com/deepsaia/dspu/issues)
- [Documentation](https://deepsaia.github.io/dspu)
