# contriwork-config-core (Python)

Python adapter for the ContriWork **config-core** port. One API surface,
three languages (Python / .NET / npm) — this package is the Python
implementation.

Cross-language specification, contract, and release history live in the
[GitHub repository](https://github.com/contriwork/contriwork-config-core):

- [Root README](https://github.com/contriwork/contriwork-config-core/blob/main/README.md) — ecosystem overview
- [`CONTRACT.md`](https://github.com/contriwork/contriwork-config-core/blob/main/CONTRACT.md) — language-agnostic port spec
- [`CHANGELOG.md`](https://github.com/contriwork/contriwork-config-core/blob/main/CHANGELOG.md)

Sister packages: [`Contriwork.ConfigCore`](https://www.nuget.org/packages/Contriwork.ConfigCore) (NuGet), [`@contriwork/config-core`](https://www.npmjs.com/package/@contriwork/config-core) (npm).

## Install

```bash
pip install contriwork-config-core
```

Requires **Python ≥ 3.13**.

## Quick start

```python
from contriwork_config_core import ConfigCorePort

# TODO: one-line example once the port has real methods.
```

## Local development

```bash
uv sync --all-extras
uv run pytest
uv run ruff check
uv run mypy src
```

## License

MIT — see [LICENSE](https://github.com/contriwork/contriwork-config-core/blob/main/LICENSE).
