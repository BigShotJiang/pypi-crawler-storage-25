"""Data model tests."""
