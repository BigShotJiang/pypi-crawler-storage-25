# Amazon Bedrock AgentCore Construct Library

<!--BEGIN STABILITY BANNER-->---


![cdk-constructs: Experimental](https://img.shields.io/badge/cdk--constructs-experimental-important.svg?style=for-the-badge)

> The APIs of higher level constructs in this module are experimental and under active development.
> They are subject to non-backward compatible changes or removal in any future version. These are
> not subject to the [Semantic Versioning](https://semver.org/) model and breaking changes will be
> announced in the release notes. This means that while you may use them, you may need to update
> your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

| **Language**                                                                                   | **Package**                             |
| :--------------------------------------------------------------------------------------------- | --------------------------------------- |
| ![Typescript Logo](https://docs.aws.amazon.com/cdk/api/latest/img/typescript32.png) TypeScript | `@aws-cdk/aws-bedrock-agentcore-alpha` |

[Amazon Bedrock AgentCore](https://aws.amazon.com/bedrock/agentcore/) enables you to deploy and operate highly capable AI agents securely, at scale. It offers infrastructure purpose-built for dynamic agent workloads, powerful tools to enhance agents, and essential controls for real-world deployment. AgentCore services can be used together or independently and work with any framework including CrewAI, LangGraph, LlamaIndex, and Strands Agents, as well as any foundation model in or outside of Amazon Bedrock, giving you ultimate flexibility. AgentCore eliminates the undifferentiated heavy lifting of building specialized agent infrastructure, so you can accelerate agents to production.

This construct library facilitates the deployment of Bedrock AgentCore primitives, enabling you to create sophisticated AI applications that can interact with your systems and data sources.

> **Note:** Users need to ensure their CDK deployment role has the `iam:CreateServiceLinkedRole` permission for AgentCore service-linked roles.

## Table of contents

* [Amazon Bedrock AgentCore Construct Library](#amazon-bedrock-agentcore-construct-library)

  * [Table of contents](#table-of-contents)
  * [AgentCore Runtime](#agentcore-runtime)

    * [Runtime Endpoints](#runtime-endpoints)
    * [AgentCore Runtime Properties](#agentcore-runtime-properties)
    * [Runtime Endpoint Properties](#runtime-endpoint-properties)
    * [Creating a Runtime](#creating-a-runtime)

      * [Option 1: Use an existing image in ECR](#option-1-use-an-existing-image-in-ecr)
      * [Option 2: Use a local asset](#option-2-use-a-local-asset)
      * [Option 3: Use direct code deployment](#option-3-use-direct-code-deployment)
      * [Option 4: Use an ECR container image URI](#option-4-use-an-ecr-container-image-uri)
    * [Granting Permissions to Invoke Bedrock Models or Inference Profiles](#granting-permissions-to-invoke-bedrock-models-or-inference-profiles)
    * [Runtime Versioning](#runtime-versioning)

      * [Managing Endpoints and Versions](#managing-endpoints-and-versions)

        * [Step 1: Initial Deployment](#step-1-initial-deployment)
        * [Step 2: Creating Custom Endpoints](#step-2-creating-custom-endpoints)
        * [Step 3: Runtime Update Deployment](#step-3-runtime-update-deployment)
        * [Step 4: Testing with Staging Endpoints](#step-4-testing-with-staging-endpoints)
        * [Step 5: Promoting to Production](#step-5-promoting-to-production)
    * [Creating Standalone Runtime Endpoints](#creating-standalone-runtime-endpoints)

      * [Example: Creating an endpoint for an existing runtime](#example-creating-an-endpoint-for-an-existing-runtime)
    * [Runtime Authentication Configuration](#runtime-authentication-configuration)

      * [IAM Authentication (Default)](#iam-authentication-default)
      * [Cognito Authentication](#cognito-authentication)
      * [JWT Authentication](#jwt-authentication)
      * [OAuth Authentication](#oauth-authentication)
      * [Using a Custom IAM Role](#using-a-custom-iam-role)
    * [Runtime Network Configuration](#runtime-network-configuration)

      * [Public Network Mode (Default)](#public-network-mode-default)
      * [VPC Network Mode](#vpc-network-mode)
      * [Managing Security Groups with VPC Configuration](#managing-security-groups-with-vpc-configuration)
    * [Runtime IAM Permissions](#runtime-iam-permissions)
    * [Other configuration](#other-configuration)

      * [Lifecycle configuration](#lifecycle-configuration)
      * [Request header configuration](#request-header-configuration)
  * [Browser](#browser)

    * [Browser Network modes](#browser-network-modes)
    * [Browser Properties](#browser-properties)
    * [Basic Browser Creation](#basic-browser-creation)
    * [Browser with Tags](#browser-with-tags)
    * [Browser with VPC](#browser-with-vpc)
    * [Browser with Recording Configuration](#browser-with-recording-configuration)
    * [Browser with Custom Execution Role](#browser-with-custom-execution-role)
    * [Browser with S3 Recording and Permissions](#browser-with-s3-recording-and-permissions)
    * [Browser with Browser signing](#browser-with-browser-signing)
    * [Browser IAM Permissions](#browser-iam-permissions)
  * [Code Interpreter](#code-interpreter)

    * [Code Interpreter Network Modes](#code-interpreter-network-modes)
    * [Code Interpreter Properties](#code-interpreter-properties)
    * [Basic Code Interpreter Creation](#basic-code-interpreter-creation)
    * [Code Interpreter with VPC](#code-interpreter-with-vpc)
    * [Code Interpreter with Sandbox Network Mode](#code-interpreter-with-sandbox-network-mode)
    * [Code Interpreter with Custom Execution Role](#code-interpreter-with-custom-execution-role)
    * [Code Interpreter IAM Permissions](#code-interpreter-iam-permissions)
    * [Code interpreter with tags](#code-interpreter-with-tags)
  * [Gateway](#gateway)

    * [Gateway Properties](#gateway-properties)
    * [Basic Gateway Creation](#basic-gateway-creation)
    * [Protocol configuration](#protocol-configuration)
    * [Inbound authorization](#inbound-authorization)
    * [Gateway with KMS Encryption](#gateway-with-kms-encryption)
    * [Gateway with Custom Execution Role](#gateway-with-custom-execution-role)
    * [Gateway IAM Permissions](#gateway-iam-permissions)
  * [Gateway Target](#gateway-target)

    * [Gateway Target Properties](#gateway-target-properties)
    * [Targets types](#targets-types)
    * [Understanding Tool Naming](#understanding-tool-naming)
    * [Tools schema For Lambda target](#tools-schema-for-lambda-target)
    * [Api schema For OpenAPI and Smithy target](#api-schema-for-openapi-and-smithy-target)
    * [Outbound auth](#outbound-auth)
    * [Basic Gateway Target Creation](#basic-gateway-target-creation)

      * [Using addTarget methods (Recommended)](#using-addtarget-methods-recommended)
      * [Using static factory methods](#using-static-factory-methods)
    * [Advanced Usage: Direct Configuration for gateway target](#advanced-usage-direct-configuration-for-gateway-target)

      * [Configuration Factory Methods](#configuration-factory-methods)
      * [Example: Lambda Target with Custom Configuration](#example-lambda-target-with-custom-configuration)
    * [Gateway Target IAM Permissions](#gateway-target-iam-permissions)
  * [Memory](#memory)

    * [Memory Properties](#memory-properties)
    * [Basic Memory Creation](#basic-memory-creation)
    * [LTM Memory Extraction Stategies](#ltm-memory-extraction-stategies)
    * [Memory with Built-in Strategies](#memory-with-built-in-strategies)
    * [Memory with custom Strategies](#memory-with-custom-strategies)

      * [Memory with Custom Execution Role](#memory-with-custom-execution-role)
    * [Memory with self-managed Strategies](#memory-with-self-managed-strategies)
    * [Memory Strategy Methods](#memory-strategy-methods)
  * [Policy](#policy)

    * [PolicyEngine Properties](#policyengine-properties)
    * [Policy Properties](#policy-properties)
    * [Basic PolicyEngine and Policy Creation](#basic-policyengine-and-policy-creation)
    * [Associating a Policy Engine with a Gateway](#associating-a-policy-engine-with-a-gateway)
    * [Type-Safe Policy Builder](#type-safe-policy-builder)
    * [PolicyEngine with KMS Encryption](#policyengine-with-kms-encryption)
    * [Policy Validation Modes](#policy-validation-modes)
  * [Online Evaluation](#online-evaluation)

    * [Online Evaluation Properties](#online-evaluation-properties)
    * [Basic Online Evaluation Creation](#basic-online-evaluation-creation)
    * [Built-in Evaluators](#built-in-evaluators)
    * [Custom Evaluators](#custom-evaluators)

      * [LLM-as-a-Judge Evaluator](#llm-as-a-judge-evaluator)
      * [Code-Based Evaluator](#code-based-evaluator)
      * [Using Custom Evaluators with Online Evaluation](#using-custom-evaluators-with-online-evaluation)
    * [Data Source Configuration](#data-source-configuration)
    * [Sampling and Filtering](#sampling-and-filtering)
    * [Online Evaluation with Custom Execution Role](#online-evaluation-with-custom-execution-role)
    * [Online Evaluation IAM Permissions](#online-evaluation-iam-permissions)

## AgentCore Runtime

The AgentCore Runtime construct enables you to deploy containerized agents on Amazon Bedrock AgentCore.
This L2 construct simplifies runtime creation just pass your ECR repository name
and the construct handles all the configuration with sensible defaults.

### Runtime Endpoints

Endpoints provide a stable way to invoke specific versions of your agent runtime, enabling controlled deployments across different environments.
When you create an agent runtime, Amazon Bedrock AgentCore automatically creates a "DEFAULT" endpoint which always points to the latest version
of runtime.

You can create additional endpoints in two ways:

1. **Using Runtime.addEndpoint()** - Convenient method when creating endpoints alongside the runtime.
2. **Using RuntimeEndpoint** - Flexible approach for existing runtimes.

For example, you might keep a "production" endpoint on a stable version while testing newer versions
through a "staging" endpoint. This separation allows you to test changes thoroughly before promoting them
to production by simply updating the endpoint to point to the newer version.

### AgentCore Runtime Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `runtimeName` | `string` | No | The name of the agent runtime. Valid characters are a-z, A-Z, 0-9, _ (underscore). Must start with a letter and can be up to 48 characters long. If not provided, a unique name will be auto-generated |
| `agentRuntimeArtifact` | `AgentRuntimeArtifact` | Yes | The artifact configuration for the agent runtime containing the container configuration with ECR URI |
| `executionRole` | `iam.IRole` | No | The IAM role that provides permissions for the agent runtime. If not provided, a role will be created automatically |
| `networkConfiguration` | `NetworkConfiguration` | No | Network configuration for the agent runtime. Defaults to `RuntimeNetworkConfiguration.usingPublicNetwork()` |
| `description` | `string` | No | Optional description for the agent runtime |
| `protocolConfiguration` | `ProtocolType` | No | Protocol configuration for the agent runtime. Defaults to `ProtocolType.HTTP` |
| `authorizerConfiguration` | `RuntimeAuthorizerConfiguration` | No | Authorizer configuration for the agent runtime. Use `RuntimeAuthorizerConfiguration` static methods to create configurations for IAM, Cognito, JWT, or OAuth authentication |
| `environmentVariables` | `{ [key: string]: string }` | No | Environment variables for the agent runtime. Maximum 50 environment variables |
| `tags` | `{ [key: string]: string }` | No | Tags for the agent runtime. A list of key:value pairs of tags to apply to this Runtime resource |
| `lifecycleConfiguration` | LifecycleConfiguration | No | The life cycle configuration for the AgentCore Runtime. Defaults to 900 seconds (15 minutes) for idle, 28800 seconds (8 hours) for max life time |
| `requestHeaderConfiguration` | RequestHeaderConfiguration | No | Configuration for HTTP request headers that will be passed through to the runtime. Defaults to no configuration |

### Runtime Endpoint Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `endpointName` | `string` | No | The name of the runtime endpoint. Valid characters are a-z, A-Z, 0-9, _ (underscore). Must start with a letter and can be up to 48 characters long. If not provided, a unique name will be auto-generated |
| `agentRuntimeId` | `string` | Yes | The Agent Runtime ID for this endpoint |
| `agentRuntimeVersion` | `string` | Yes | The Agent Runtime version for this endpoint. Must be between 1 and 5 characters long.|
| `description` | `string` | No | Optional description for the runtime endpoint |
| `tags` | `{ [key: string]: string }` | No | Tags for the runtime endpoint |

### Creating a Runtime

#### Option 1: Use an existing image in ECR

Reference an image available within ECR.

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

# The runtime by default create ECR permission only for the repository available in the account the stack is being deployed
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create runtime using the built image
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

#### Option 2: Use a local asset

Reference a local directory containing a Dockerfile.
Images are built from a local Docker context directory (with a Dockerfile), uploaded to Amazon Elastic Container Registry (ECR)
by the CDK toolkit,and can be naturally referenced in your CDK app.

```python
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_asset(
    path.join(__dirname, "path to agent dockerfile directory"))

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

#### Option 3: Use direct code deployment

With the container deployment method, developers create a Dockerfile, build ARM-compatible containers, manage ECR repositories, and upload containers for code changes. This works well where container DevOps pipelines have already been established to automate deployments.

However, customers looking for fully managed deployments can benefit from direct code deployment, which can significantly improve developer time and productivity. Direct code deployment provides a secure and scalable path forward for rapid prototyping agent capabilities to deploying production workloads at scale.

With direct code deployment, developers create a zip archive of code and dependencies, upload to Amazon S3, and configure the bucket in the agent configuration. A ZIP archive containing Linux arm64 dependencies needs to be uploaded to S3 as a pre-requisite to Create Agent Runtime.

For more information, please refer to the [documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-get-started-code-deploy.html).

```python
# S3 bucket containing the agent core
code_bucket = s3.Bucket(self, "AgentCode",
    bucket_name="my-code-bucket",
    removal_policy=RemovalPolicy.DESTROY
)

# the bucket above needs to contain the agent code

agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_s3(s3.Location(
    bucket_name=code_bucket.bucket_name,
    object_key="deployment_package.zip"
), agentcore.AgentCoreRuntime.PYTHON_3_12, ["opentelemetry-instrument", "main.py"])

runtime_instance = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

Alternatively, you can use local code assets that will be automatically packaged and uploaded to a CDK-managed S3 bucket:

```python
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_code_asset(
    path=path.join(__dirname, "path/to/agent/code"),
    runtime=agentcore.AgentCoreRuntime.PYTHON_3_12,
    entrypoint=["opentelemetry-instrument", "main.py"]
)

runtime_instance = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

#### Option 4: Use an ECR container image URI

Reference an ECR container image directly by its URI. This is useful when you have a pre-existing ECR image URI from CloudFormation parameters or cross-stack references. No IAM permissions are automatically granted - you must ensure the runtime has ECR pull permissions.

```python
# Direct URI reference
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_image_uri("123456789012.dkr.ecr.us-east-1.amazonaws.com/my-agent:v1.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

You can also use CloudFormation parameters or references:

```python
# Using a CloudFormation parameter
image_uri_param = cdk.CfnParameter(self, "ImageUri",
    type="String",
    description="Container image URI for the agent runtime"
)

agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_image_uri(image_uri_param.value_as_string)

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

### Granting Permissions to Invoke Bedrock Models or Inference Profiles

To grant the runtime permissions to invoke Bedrock models or inference profiles:

```python
# Note: This example uses @aws-cdk/aws-bedrock-alpha which must be installed separately
# runtime: agentcore.Runtime


# Define the Bedrock Foundation Model
model = bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_7_SONNET_V1_0

# Grant the runtime permissions to invoke the model
model.grant_invoke(runtime)

# Create a cross-region inference profile for Claude 3.7 Sonnet
inference_profile = bedrock.CrossRegionInferenceProfile.from_config(
    geo_region=bedrock.CrossRegionInferenceProfileRegion.US,
    model=bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_7_SONNET_V1_0
)

# Grant the runtime permissions to invoke the inference profile
inference_profile.grant_invoke(runtime)
```

### Runtime Versioning

Amazon Bedrock AgentCore automatically manages runtime versioning to ensure safe deployments and rollback capabilities.
When you create an agent runtime, AgentCore automatically creates version 1 (V1). Each subsequent update to the
runtime configuration (such as updating the container image, modifying network settings, or changing protocol configurations)
creates a new immutable version. These versions contain complete, self-contained configurations that can be referenced by endpoints,
allowing you to maintain different versions for different environments or gradually roll out updates.

#### Managing Endpoints and Versions

Amazon Bedrock AgentCore automatically manages runtime versioning to provide safe deployments and rollback capabilities. You can follow
the steps below to understand how to use versioning with runtime for controlled deployments across different environments.

##### Step 1: Initial Deployment

When you first create an agent runtime, AgentCore automatically creates Version 1 of your runtime. At this point, a DEFAULT endpoint is
automatically created that points to Version 1. This DEFAULT endpoint serves as the main access point for your runtime.

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")
)
```

##### Step 2: Creating Custom Endpoints

After the initial deployment, you can create additional endpoints for different environments. For example, you might create a "production"
endpoint that explicitly points to Version 1. This allows you to maintain stable access points for specific environments while keeping the
flexibility to test newer versions elsewhere.

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")
)

prod_endpoint = runtime.add_endpoint("production",
    version="1",
    description="Stable production endpoint - pinned to v1"
)
```

##### Step 3: Runtime Update Deployment

When you update the runtime configuration (such as updating the container image, modifying network settings, or changing protocol
configurations), AgentCore automatically creates a new version (Version 2). Upon this update:

* Version 2 is created automatically with the new configuration
* The DEFAULT endpoint automatically updates to point to Version 2
* Any explicitly pinned endpoints (like the production endpoint) remain on their specified versions

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

agent_runtime_artifact_new = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v2.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact_new
)
```

##### Step 4: Testing with Staging Endpoints

Once Version 2 exists, you can create a staging endpoint that points to the new version. This staging endpoint allows you to test the
new version in a controlled environment before promoting it to production. This separation ensures that production traffic continues
to use the stable version while you validate the new version.

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

agent_runtime_artifact_new = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v2.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact_new
)

staging_endpoint = runtime.add_endpoint("staging",
    version="2",
    description="Staging environment for testing new version"
)
```

##### Step 5: Promoting to Production

After thoroughly testing the new version through the staging endpoint, you can update the production endpoint to point to Version 2.
This controlled promotion process ensures that you can validate changes before they affect production traffic.

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

agent_runtime_artifact_new = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v2.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact_new
)

prod_endpoint = runtime.add_endpoint("production",
    version="2",  # New version added here
    description="Stable production endpoint"
)
```

### Creating Standalone Runtime Endpoints

RuntimeEndpoint can also be created as a standalone resource.

#### Example: Creating an endpoint for an existing runtime

```python
# Reference an existing runtime by its ID
existing_runtime_id = "abc123-runtime-id" # The ID of an existing runtime

# Create a standalone endpoint
endpoint = agentcore.RuntimeEndpoint(self, "MyEndpoint",
    endpoint_name="production",
    agent_runtime_id=existing_runtime_id,
    agent_runtime_version="1",  # Specify which version to use
    description="Production endpoint for existing runtime"
)
```

### Runtime Authentication Configuration

The AgentCore Runtime supports multiple authentication modes to secure access to your agent endpoints. Authentication is configured during runtime creation using the `RuntimeAuthorizerConfiguration` class's static factory methods.

#### IAM Authentication (Default)

IAM authentication is the default mode, when no authorizerConfiguration is set then the underlying service use IAM.

#### Cognito Authentication

To configure AWS Cognito User Pool authentication:

```python
# user_pool: cognito.UserPool
# user_pool_client: cognito.UserPoolClient
# another_user_pool_client: cognito.UserPoolClient


repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Optional: Create custom claims for additional validation
custom_claims = [
    agentcore.RuntimeCustomClaim.with_string_value("department", "engineering"),
    agentcore.RuntimeCustomClaim.with_string_array_value("roles", ["admin"], agentcore.CustomClaimOperator.CONTAINS),
    agentcore.RuntimeCustomClaim.with_string_array_value("permissions", ["read", "write"], agentcore.CustomClaimOperator.CONTAINS_ANY)
]

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_cognito(user_pool, [user_pool_client, another_user_pool_client], ["audience1"], ["read", "write"], custom_claims)
)
```

You can configure:

* User Pool: The Cognito User Pool that issues JWT tokens
* User Pool Clients: One or more Cognito User Pool App Clients that are allowed to access the runtime
* Allowed audiences: Used to validate that the audiences specified in the Cognito token match or are a subset of the audiences specified in the AgentCore Runtime
* Allowed scopes: Allow access only if the token contains at least one of the required scopes configured here
* Custom claims: A set of rules to match specific claims in the incoming token against predefined values for validating JWT tokens

#### JWT Authentication

To configure custom JWT authentication with your own OpenID Connect (OIDC) provider:

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_jWT("https://example.com/.well-known/openid-configuration", ["client1", "client2"], ["audience1"], ["read", "write"])
)
```

You can configure:

* Discovery URL: Enter the Discovery URL from your identity provider (e.g. Okta, Cognito, etc.), typically found in that provider's documentation. This allows your Agent or Tool to fetch login, downstream resource token, and verification settings.
* Allowed audiences: This is used to validate that the audiences specified for the OAuth token matches or are a subset of the audiences specified in the AgentCore Runtime.
* Allowed clients: This is used to validate that the public identifier of the client, as specified in the authorization token, is allowed to access the AgentCore Runtime.
* Allowed scopes: Allow access only if the token contains at least one of the required scopes configured here.
* Custom claims: A set of rules to match specific claims in the incoming token against predefined values for validating JWT tokens.

**Note**: The discovery URL must end with `/.well-known/openid-configuration`.

##### Custom Claims Validation

Custom claims allow you to validate additional fields in JWT tokens beyond the standard audience, client, and scope validations. You can create custom claims using the `RuntimeCustomClaim` class:

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# String claim - validates that the claim exactly equals the specified value
# Uses EQUALS operator automatically
department_claim = agentcore.RuntimeCustomClaim.with_string_value("department", "engineering")

# String array claim with CONTAINS operator (default)
# Validates that the claim array contains a specific string value
# IMPORTANT: CONTAINS requires exactly one value in the array parameter
roles_claim = agentcore.RuntimeCustomClaim.with_string_array_value("roles", ["admin"])

# String array claim with CONTAINS_ANY operator
# Validates that the claim array contains at least one of the specified values
# Use this when you want to check for multiple possible values
permissions_claim = agentcore.RuntimeCustomClaim.with_string_array_value("permissions", ["read", "write"], agentcore.CustomClaimOperator.CONTAINS_ANY)

# Use custom claims in authorizer configuration
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_jWT("https://example.com/.well-known/openid-configuration", ["client1", "client2"], ["audience1"], ["read", "write"], [department_claim, roles_claim, permissions_claim])
)
```

**Custom Claim Rules**:

* **String claims**: Must use the `EQUALS` operator (automatically set). The claim value must exactly match the specified string.
* **String array claims**: Can use `CONTAINS` (default) or `CONTAINS_ANY` operators:

  * **`CONTAINS`**: Checks if the claim array contains a specific string value. **Requires exactly one value** in the array parameter. For example, `['admin']` will check if the token's claim array contains the string `'admin'`.
  * **`CONTAINS_ANY`**: Checks if the claim array contains at least one of the provided string values. Use this when you want to validate against multiple possible values. For example, `['read', 'write']` will check if the token's claim array contains either `'read'` or `'write'`.

**Example Use Cases**:

* Use `CONTAINS` when you need to verify a user has a specific role: `RuntimeCustomClaim.withStringArrayValue('roles', ['admin'])`
* Use `CONTAINS_ANY` when you need to verify a user has any of several permissions: `RuntimeCustomClaim.withStringArrayValue('permissions', ['read', 'write'], CustomClaimOperator.CONTAINS_ANY)`

#### OAuth Authentication

To configure OAuth 2.0 authentication:

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_oAuth("https://github.com/.well-known/openid-configuration", "oauth_client_123", ["audience1"], ["openid", "profile"])
)
```

#### Using a Custom IAM Role

Instead of using the auto-created execution role, you can provide your own IAM role with specific permissions:
The auto-created role includes all necessary baseline permissions for ECR access, CloudWatch logging, and X-Ray tracing. When providing a custom role, ensure these permissions are included.

### Runtime Network Configuration

The AgentCore Runtime supports two network modes for deployment:

#### Public Network Mode (Default)

By default, runtimes are deployed in PUBLIC network mode, which provides internet access suitable for less sensitive or open-use scenarios:

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Explicitly using public network (this is the default)
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    network_configuration=agentcore.RuntimeNetworkConfiguration.using_public_network()
)
```

#### VPC Network Mode

For enhanced security and network isolation, you can deploy your runtime within a VPC:

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create or use an existing VPC
vpc = ec2.Vpc(self, "MyVpc",
    max_azs=2
)

# Configure runtime with VPC
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    network_configuration=agentcore.RuntimeNetworkConfiguration.using_vpc(self,
        vpc=vpc,
        vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS)
    )
)
```

#### Managing Security Groups with VPC Configuration

When using VPC mode, the Runtime implements `ec2.IConnectable`, allowing you to manage network access using the `connections` property:

```python
vpc = ec2.Vpc(self, "MyVpc",
    max_azs=2
)

repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create runtime with VPC configuration
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    network_configuration=agentcore.RuntimeNetworkConfiguration.using_vpc(self,
        vpc=vpc,
        vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS)
    )
)

# Now you can manage network access using the connections property
# Allow inbound HTTPS traffic from a specific security group
web_server_security_group = ec2.SecurityGroup(self, "WebServerSG", vpc=vpc)
runtime.connections.allow_from(web_server_security_group, ec2.Port.tcp(443), "Allow HTTPS from web servers")

# Allow outbound connections to a database
database_security_group = ec2.SecurityGroup(self, "DatabaseSG", vpc=vpc)
runtime.connections.allow_to(database_security_group, ec2.Port.tcp(5432), "Allow PostgreSQL connection")

# Allow outbound HTTPS to anywhere (for external API calls)
runtime.connections.allow_to_any_ipv4(ec2.Port.tcp(443), "Allow HTTPS outbound")
```

### Runtime IAM Permissions

The Runtime construct provides convenient methods for granting IAM permissions to principals that need to invoke the runtime or manage its execution role.

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create a runtime
runtime = agentcore.Runtime(self, "MyRuntime",
    runtime_name="my_runtime",
    agent_runtime_artifact=agent_runtime_artifact
)

# Create a Lambda function that needs to invoke the runtime
invoker_function = lambda_.Function(self, "InvokerFunction",
    runtime=lambda_.Runtime.PYTHON_3_12,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
        import boto3
        def handler(event, context):
            client = boto3.client('bedrock-agentcore')
            # Invoke the runtime...
          """)
)

# Grant permission to invoke the runtime directly
runtime.grant_invoke_runtime(invoker_function)

# Grant permission to invoke the runtime on behalf of a user
# (requires X-Amzn-Bedrock-AgentCore-Runtime-User-Id header)
runtime.grant_invoke_runtime_for_user(invoker_function)

# Grant both invoke permissions (most common use case)
runtime.grant_invoke(invoker_function)

# Grant specific custom permissions to the runtime's execution role
runtime.grant(["bedrock:InvokeModel"], ["arn:aws:bedrock:*:*:*"])

# Add a policy statement to the runtime's execution role
runtime.add_to_role_policy(iam.PolicyStatement(
    actions=["s3:GetObject"],
    resources=["arn:aws:s3:::my-bucket/*"]
))
```

### Other configuration

#### Lifecycle configuration

The LifecycleConfiguration input parameter to CreateAgentRuntime lets you manage the lifecycle of runtime sessions and resources in Amazon Bedrock AgentCore Runtime. This configuration helps optimize resource utilization by automatically cleaning up idle sessions and preventing long-running instances from consuming resources indefinitely.

You can configure:

* idleRuntimeSessionTimeout: Timeout in seconds for idle runtime sessions. When a session remains idle for this duration, it will trigger termination. Termination can last up to 15 seconds due to logging and other process completion. Default: 900 seconds (15 minutes)
* maxLifetime: Maximum lifetime for the instance in seconds. Once reached, instances will initialize termination. Termination can last up to 15 seconds due to logging and other process completion. Default: 28800 seconds (8 hours)

For additional information, please refer to the [documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-lifecycle-settings.html).

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

agentcore.Runtime(self, "test-runtime",
    runtime_name="test_runtime",
    agent_runtime_artifact=agent_runtime_artifact,
    lifecycle_configuration=agentcore.LifecycleConfiguration(
        idle_runtime_session_timeout=Duration.minutes(10),
        max_lifetime=Duration.hours(4)
    )
)
```

#### Request header configuration

Custom headers let you pass contextual information from your application directly to your agent code without cluttering the main request payload. This includes authentication tokens like JWT (JSON Web Tokens, which contain user identity and authorization claims) through the Authorization header, allowing your agent to make decisions based on who is calling it. You can also pass custom metadata like user preferences, session identifiers, or trace context using headers prefixed with X-Amzn-Bedrock-AgentCore-Runtime-Custom-, giving your agent access to up to 20 pieces of runtime context that travel alongside each request. This information can be also used in downstream systems like AgentCore Memory that you can namespace based on those characteristics like user_id or aud in claims like line of business.

For additional information, please refer to the [documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-header-allowlist.html).

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

agentcore.Runtime(self, "test-runtime",
    runtime_name="test_runtime",
    agent_runtime_artifact=agent_runtime_artifact,
    request_header_configuration=agentcore.RequestHeaderConfiguration(
        allowlisted_headers=["X-Amzn-Bedrock-AgentCore-Runtime-Custom-H1"]
    )
)
```

#### Observability configuration

The Runtime construct supports observability features including X-Ray tracing and logging to CloudWatch Logs, S3, or Kinesis Data Firehose. This allows you to monitor and debug your agent runtime invocations.

You can configure:

* tracingEnabled: Enable X-Ray tracing for the runtime
* loggingConfigs: Send APPLICATION_LOGS (agent runtime invocations) and USAGE_LOGS (session-level resource consumption) to CloudWatch Logs, S3, or Kinesis Data Firehose

For additional information, please refer to the [Set up logging and tracing for AgentCore](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/observability.html).

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create logging destinations
log_group = logs.LogGroup(self, "RuntimeLogGroup")
log_bucket = s3.Bucket(self, "RuntimeLogBucket")
firehose_stream = firehose.DeliveryStream(self, "RuntimeLogStream",
    destination=firehose.S3Bucket(log_bucket)
)

agentcore.Runtime(self, "test-runtime",
    runtime_name="test_runtime",
    agent_runtime_artifact=agent_runtime_artifact,
    tracing_enabled=True,
    logging_configs=[agentcore.LoggingConfig(
        log_type=agentcore.LogType.APPLICATION_LOGS,
        destination=agentcore.LoggingDestination.cloud_watch_logs(log_group)
    ), agentcore.LoggingConfig(
        log_type=agentcore.LogType.APPLICATION_LOGS,
        destination=agentcore.LoggingDestination.s3(log_bucket)
    ), agentcore.LoggingConfig(
        log_type=agentcore.LogType.APPLICATION_LOGS,
        destination=agentcore.LoggingDestination.firehose(firehose_stream)
    )
    ]
)
```

## Browser

The Amazon Bedrock AgentCore Browser provides a secure, cloud-based browser that enables AI agents to interact with websites. It includes security features such as session isolation, built-in observability through live viewing, CloudTrail logging, and session replay capabilities.

Additional information about the browser tool can be found in the [official documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/browser-tool.html)

### Browser Network modes

The Browser construct supports the following network modes:

1. **Public Network Mode** (`BrowserNetworkMode.usingPublicNetwork()`) - Default

   * Allows internet access for web browsing and external API calls
   * Suitable for scenarios where agents need to interact with publicly available websites
   * Enables full web browsing capabilities
   * VPC mode is not supported with this option
2. **VPC (Virtual Private Cloud)** (`BrowserNetworkMode.usingVpc()`)

   * Select whether to run the browser in a virtual private cloud (VPC).
   * By configuring VPC connectivity, you enable secure access to private resources such as databases, internal APIs, and services within your VPC.

   While the VPC itself is mandatory, these are optional:

   * Subnets - if not provided, CDK will select appropriate subnets from the VPC
   * Security Groups - if not provided, CDK will create a default security group
   * Specific subnet selection criteria - you can let CDK choose automatically

For more information on VPC connectivity for Amazon Bedrock AgentCore Browser, please refer to the [official documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agentcore-vpc.html).

### Browser Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `browserCustomName` | `string` | No | The name of the browser. Must start with a letter and can be up to 48 characters long. Pattern: `[a-zA-Z][a-zA-Z0-9_]{0,47}`. If not provided, a unique name will be auto-generated |
| `description` | `string` | No | Optional description for the browser. Can have up to 200 characters |
| `networkConfiguration` | `BrowserNetworkConfiguration` | No | Network configuration for browser. Defaults to PUBLIC network mode |
| `recordingConfig` | `RecordingConfig` | No | Recording configuration for browser. Defaults to no recording |
| `executionRole` | `iam.IRole` | No | The IAM role that provides permissions for the browser to access AWS services. A new role will be created if not provided |
| `tags` | `{ [key: string]: string }` | No | Tags to apply to the browser resource |
| `browserSigning` | BrowserSigning | No | Browser signing configuration. Defaults to DISABLED |

### Basic Browser Creation

```python
# Create a basic browser with public network access
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="A browser for web automation"
)
```

### Browser with Tags

```python
# Create a browser with custom tags
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="A browser for web automation with tags",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    tags={
        "Environment": "Production",
        "Team": "AI/ML",
        "Project": "AgentCore"
    }
)
```

### Browser with VPC

```python
browser = agentcore.BrowserCustom(self, "BrowserVpcWithRecording",
    browser_custom_name="browser_recording",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=ec2.Vpc(self, "VPC", restrict_default_security_group=False)
    )
)
```

Browser exposes a [connections](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_ec2.Connections.html) property. This property returns a connections object, which simplifies the process of defining and managing ingress and egress rules for security groups in your AWS CDK applications. Instead of directly manipulating security group rules, you interact with the Connections object of a construct, which then translates your connectivity requirements into the appropriate security group rules. For instance:

```python
vpc = ec2.Vpc(self, "testVPC")

browser = agentcore.BrowserCustom(self, "test-browser",
    browser_custom_name="test_browser",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=vpc
    )
)

browser.connections.add_security_group(ec2.SecurityGroup(self, "AdditionalGroup", vpc=vpc))
```

So security groups can be added after the browser construct creation. You can use methods like allowFrom() and allowTo() to grant ingress access to/egress access from a specified peer over a given portRange. The Connections object automatically adds the necessary ingress or egress rules to the security group(s) associated with the calling construct.

### Browser with Recording Configuration

```python
# Create an S3 bucket for recordings
recording_bucket = s3.Bucket(self, "RecordingBucket",
    bucket_name="my-browser-recordings",
    removal_policy=RemovalPolicy.DESTROY
)

# Create browser with recording enabled
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser with recording enabled",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    recording_config=agentcore.RecordingConfig(
        enabled=True,
        s3_location=s3.Location(
            bucket_name=recording_bucket.bucket_name,
            object_key="browser-recordings/"
        )
    )
)
```

### Browser with Custom Execution Role

```python
# Create a custom execution role
execution_role = iam.Role(self, "BrowserExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockAgentCoreBrowserExecutionRolePolicy")
    ]
)

# Create browser with custom execution role
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser with custom execution role",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    execution_role=execution_role
)
```

### Browser with S3 Recording and Permissions

```python
# Create an S3 bucket for recordings
recording_bucket = s3.Bucket(self, "RecordingBucket",
    bucket_name="my-browser-recordings",
    removal_policy=RemovalPolicy.DESTROY
)

# Create browser with recording enabled
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser with recording enabled",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    recording_config=agentcore.RecordingConfig(
        enabled=True,
        s3_location=s3.Location(
            bucket_name=recording_bucket.bucket_name,
            object_key="browser-recordings/"
        )
    )
)
```

### Browser with Browser signing

AI agents need to browse the web on your behalf. When your agent visits a website to gather information, complete a form, or verify data, it encounters the same defenses designed to stop unwanted bots: CAPTCHAs, rate limits, and outright blocks.

Amazon Bedrock AgentCore Browser supports Web Bot Auth. Web Bot Auth is a draft IETF protocol that gives agents verifiable cryptographic identities. When you enable Web Bot Auth in AgentCore Browser, the service issues cryptographic credentials that websites can verify. The agent presents these credentials with every request. The WAF may now additionally check the signature, confirm it matches a trusted directory, and allow the request through if verified bots are allowed by the domain owner and other WAF checks are clear.

To enable the browser to sign requests using the Web Bot Auth protocol, create a browser tool with the browserSigning configuration:

```python
browser = agentcore.BrowserCustom(self, "test-browser",
    browser_custom_name="test_browser",
    browser_signing=agentcore.BrowserSigning.ENABLED
)
```

### Browser IAM Permissions

The Browser construct provides convenient methods for granting IAM permissions:

```python
# Create a browser
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser for web automation",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network()
)

# Create a role that needs access to the browser
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
browser.grant_read(user_role)

# Grant use permissions (Start, Update, Stop actions)
browser.grant_use(user_role)

# Grant specific custom permissions
browser.grant(user_role, "bedrock-agentcore:GetBrowserSession")
```

## Code Interpreter

The Amazon Bedrock AgentCore Code Interpreter enables AI agents to write and execute code securely in sandbox environments, enhancing their accuracy and expanding their ability to solve complex end-to-end tasks. This is critical in Agentic AI applications where the agents may execute arbitrary code that can lead to data compromise or security risks. The AgentCore Code Interpreter tool provides secure code execution, which helps you avoid running into these issues.

For more information about code interpreter, please refer to the [official documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter-tool.html)

### Code Interpreter Network Modes

The Code Interpreter construct supports the following network modes:

1. **Public Network Mode** (`CodeInterpreterNetworkMode.usingPublicNetwork()`) - Default

   * Allows internet access for package installation and external API calls
   * Suitable for development and testing environments
   * Enables downloading Python packages from PyPI
2. **Sandbox Network Mode** (`CodeInterpreterNetworkMode.usingSandboxNetwork()`)

   * Isolated network environment with no internet access
   * Suitable for production environments with strict security requirements
   * Only allows access to pre-installed packages and local resources
3. **VPC (Virtual Private Cloud)** (`CodeInterpreterNetworkMode.usingVpc()`)

   * Select whether to run the browser in a virtual private cloud (VPC).
   * By configuring VPC connectivity, you enable secure access to private resources such as databases, internal APIs, and services within your VPC.

   While the VPC itself is mandatory, these are optional:

   * Subnets - if not provided, CDK will select appropriate subnets from the VPC
   * Security Groups - if not provided, CDK will create a default security group
   * Specific subnet selection criteria - you can let CDK choose automatically

For more information on VPC connectivity for Amazon Bedrock AgentCore Browser, please refer to the [official documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agentcore-vpc.html).

### Code Interpreter Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `codeInterpreterCustomName` | `string` | No | The name of the code interpreter. Must start with a letter and can be up to 48 characters long. Pattern: `[a-zA-Z][a-zA-Z0-9_]{0,47}`. If not provided, a unique name will be auto-generated |
| `description` | `string` | No | Optional description for the code interpreter. Can have up to 200 characters |
| `executionRole` | `iam.IRole` | No | The IAM role that provides permissions for the code interpreter to access AWS services. A new role will be created if not provided |
| `networkConfiguration` | `CodeInterpreterNetworkConfiguration` | No | Network configuration for code interpreter. Defaults to PUBLIC network mode |
| `tags` | `{ [key: string]: string }` | No | Tags to apply to the code interpreter resource |

### Basic Code Interpreter Creation

```python
# Create a basic code interpreter with public network access
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_code_interpreter",
    description="A code interpreter for Python execution"
)
```

### Code Interpreter with VPC

```python
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=ec2.Vpc(self, "VPC", restrict_default_security_group=False)
    )
)
```

Code Interpreter exposes a [connections](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_ec2.Connections.html) property. This property returns a connections object, which simplifies the process of defining and managing ingress and egress rules for security groups in your AWS CDK applications. Instead of directly manipulating security group rules, you interact with the Connections object of a construct, which then translates your connectivity requirements into the appropriate security group rules. For instance:

```python
vpc = ec2.Vpc(self, "testVPC")

code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=vpc
    )
)

code_interpreter.connections.add_security_group(ec2.SecurityGroup(self, "AdditionalGroup", vpc=vpc))
```

So security groups can be added after the browser construct creation. You can use methods like allowFrom() and allowTo() to grant ingress access to/egress access from a specified peer over a given portRange. The Connections object automatically adds the necessary ingress or egress rules to the security group(s) associated with the calling construct.

### Code Interpreter with Sandbox Network Mode

```python
# Create code interpreter with sandbox network mode (isolated)
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_sandbox_network()
)
```

### Code Interpreter with Custom Execution Role

```python
# Create a custom execution role
execution_role = iam.Role(self, "CodeInterpreterExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com")
)

# Create code interpreter with custom execution role
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_code_interpreter",
    description="Code interpreter with custom execution role",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_public_network(),
    execution_role=execution_role
)
```

### Code Interpreter IAM Permissions

The Code Interpreter construct provides convenient methods for granting IAM permissions:

```python
# Create a code interpreter
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_code_interpreter",
    description="Code interpreter for Python execution",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_public_network()
)

# Create a role that needs access to the code interpreter
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
code_interpreter.grant_read(user_role)

# Grant use permissions (Start, Invoke, Stop actions)
code_interpreter.grant_use(user_role)

# Grant specific custom permissions
code_interpreter.grant(user_role, "bedrock-agentcore:GetCodeInterpreterSession")
```

### Code interpreter with tags

```python
# Create code interpreter with sandbox network mode (isolated)
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_public_network(),
    tags={
        "Environment": "Production",
        "Team": "AI/ML",
        "Project": "AgentCore"
    }
)
```

## Gateway

The Gateway construct provides a way to create Amazon Bedrock Agent Core Gateways, which serve as integration points between agents and external services.

### Gateway Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `gatewayName` | `string` | No | The name of the gateway. Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen). Maximum 100 characters. If not provided, a unique name will be auto-generated |
| `description` | `string` | No | Optional description for the gateway. Maximum 200 characters |
| `protocolConfiguration` | `IGatewayProtocolConfig` | No | The protocol configuration for the gateway. Defaults to MCP protocol |
| `authorizerConfiguration` | `IGatewayAuthorizerConfig` | No | The authorizer configuration for the gateway. Defaults to Cognito |
| `exceptionLevel` | `GatewayExceptionLevel` | No | The verbosity of exception messages. Use DEBUG mode to see granular exception messages |
| `kmsKey` | `kms.IKey` | No | The AWS KMS key used to encrypt data associated with the gateway |
| `role` | `iam.IRole` | No | The IAM role that provides permissions for the gateway to access AWS services. A new role will be created if not provided |
| `tags` | `{ [key: string]: string }` | No | Tags for the gateway. A list of key:value pairs of tags to apply to this Gateway resource |
| `policyEngineConfiguration` | `GatewayPolicyEngineConfig` | No | Associates a policy engine with this gateway. All agent requests are evaluated against the Cedar policies in the engine. The gateway role is automatically granted evaluate permissions. Default: no policy engine |

### Basic Gateway Creation

The protocol configuration defaults to MCP and the inbound auth configuration uses Cognito (it is automatically created on your behalf).

```python
# Create a basic gateway with default MCP protocol and Cognito authorizer
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)
```

### Protocol configuration

Currently MCP is the only protocol available. To configure it, use the `protocol` property with `McpProtocolConfiguration`:

* Instructions: Guidance for how to use the gateway with your tools
* Semantic search: Smart tool discovery that finds the right tools without typical limits. It improves accuracy by finding relevant tools based on context
* Supported versions: Which MCP protocol versions the gateway can use

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    )
)
```

### Inbound authorization

Before you create your gateway, you must set up inbound authorization. Inbound authorization validates users who attempt to access targets through
your AgentCore gateway. By default, if not provided, the construct will create and configure Cognito as the default identity provider
(inbound Auth setup). AgentCore supports the following types of inbound authorization:

**JSON Web Token (JWT)** – A secure and compact token used for authorization. After creating the JWT, you specify it as the authorization
configuration when you create the gateway. You can create a JWT with any of the identity providers at Provider setup and configuration.

You can configure a custom authorization provider using the `authorizerConfiguration` property with `GatewayAuthorizer.usingCustomJwt()`.
You need to specify an OAuth discovery server and client IDs/audiences when you create the gateway. You can specify the following:

* Discovery Url — String that must match the pattern ^.+/.well-known/openid-configuration$ for OpenID Connect discovery URLs
* At least one of the below options depending on the chosen identity provider.
* Allowed audiences — List of allowed audiences for JWT tokens
* Allowed clients — List of allowed client identifiers
* Allowed scopes — List of allowed scopes for JWT tokens
* Custom claims — Optional custom claim validations (see Custom Claims Validation section below)

```python
# Optional: Create custom claims (CustomClaimOperator and GatewayCustomClaim from agentcore)
custom_claims = [
    agentcore.GatewayCustomClaim.with_string_value("department", "engineering"),
    agentcore.GatewayCustomClaim.with_string_array_value("roles", ["admin"], agentcore.CustomClaimOperator.CONTAINS),
    agentcore.GatewayCustomClaim.with_string_array_value("permissions", ["read", "write"], agentcore.CustomClaimOperator.CONTAINS_ANY)
]

gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"],
        allowed_scopes=["read", "write"],
        custom_claims=custom_claims
    )
)
```

**IAM** – Authorizes through the credentials of the AWS IAM identity trying to access the gateway.

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    authorizer_configuration=agentcore.GatewayAuthorizer.using_aws_iam()
)

# Grant access to a Lambda function's role
lambda_role = iam.Role(self, "LambdaRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# The Lambda needs permission to invoke the gateway
gateway.grant_invoke(lambda_role)
```

**No Authorization** – Creates a gateway with no inbound authorization. This is useful for building public MCP servers,
or when you want to skip gateway-level authentication and enforce tool execution-level authentication using Gateway Interceptors.

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    authorizer_configuration=agentcore.GatewayAuthorizer.with_no_auth()
)
```

> **⚠️ Important:** Do not use No Authorization gateways for production workloads unless you have implemented all the security best practices. No Authorization gateways are most appropriate for testing and development purposes. See [Security Best Practices](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-inbound-auth.html#gateway-inbound-auth-none) for required compensating controls.

For more information, see [No Authorization](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-inbound-auth.html#gateway-inbound-auth-none).

**Cognito with M2M (Machine-to-Machine) Authentication (Default)** – When no authorizer is specified, the construct automatically creates a Cognito User Pool configured for OAuth 2.0 client credentials flow. This enables machine-to-machine authentication suitable for AI agents and service-to-service communication.

For more information, see [Setting up Amazon Cognito for Gateway inbound authorization](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-cognito.html).

```python
# Create a gateway with default Cognito M2M authorizer
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

# Access the Cognito resources for authentication setup
user_pool = gateway.user_pool
user_pool_client = gateway.user_pool_client

# Get the token endpoint URL and OAuth scopes for client credentials flow
token_endpoint_url = gateway.token_endpoint_url
oauth_scopes = gateway.oauth_scopes
```

**Using Cognito User Pool Explicitly with Custom Claims** – You can also use an existing Cognito User Pool with custom claims:

```python
# user_pool: cognito.UserPool
# user_pool_client: cognito.UserPoolClient


# Optional: Create custom claims (CustomClaimOperator and GatewayCustomClaim from agentcore)
custom_claims = [
    agentcore.GatewayCustomClaim.with_string_value("department", "engineering"),
    agentcore.GatewayCustomClaim.with_string_array_value("roles", ["admin"], agentcore.CustomClaimOperator.CONTAINS),
    agentcore.GatewayCustomClaim.with_string_array_value("permissions", ["read", "write"], agentcore.CustomClaimOperator.CONTAINS_ANY)
]

gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    authorizer_configuration=agentcore.GatewayAuthorizer.using_cognito(
        user_pool=user_pool,
        allowed_clients=[user_pool_client],
        allowed_audiences=["audience1"],
        allowed_scopes=["read", "write"],
        custom_claims=custom_claims
    )
)
```

To authenticate with the gateway, request an access token using the client credentials flow and use it to call Gateway endpoints. For more information about the token endpoint, see [The token issuer endpoint](https://docs.aws.amazon.com/cognito/latest/developerguide/token-endpoint.html).

The following is an example of a token request using curl:

```bash
curl -X POST "${TOKEN_ENDPOINT_URL}" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${USER_POOL_CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}" \
  -d "scope=${OAUTH_SCOPES}"
```

### Gateway with KMS Encryption

You can provide a KMS key, and configure the authorizer as well as the protocol configuration.

```python
# Create a KMS key for encryption
encryption_key = kms.Key(self, "GatewayEncryptionKey",
    enable_key_rotation=True,
    description="KMS key for gateway encryption"
)

# Create gateway with KMS encryption
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-encrypted-gateway",
    description="Gateway with KMS encryption",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"],
        allowed_scopes=["read", "write"]
    ),
    kms_key=encryption_key,
    exception_level=agentcore.GatewayExceptionLevel.DEBUG
)
```

### Gateway with Custom Execution Role

```python
# Create a custom execution role
execution_role = iam.Role(self, "GatewayExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockAgentCoreGatewayExecutionRolePolicy")
    ]
)

# Create gateway with custom execution role
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    description="Gateway with custom execution role",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"],
        allowed_scopes=["read", "write"]
    ),
    role=execution_role
)
```

### Gateway IAM Permissions

The Gateway construct provides convenient methods for granting IAM permissions:

```python
# Create a gateway
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    description="Gateway for external service integration",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"],
        allowed_scopes=["read", "write"]
    )
)

# Create a role that needs access to the gateway
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
gateway.grant_read(user_role)

# Grant manage permissions (Create, Update, Delete actions)
gateway.grant_manage(user_role)

# Grant specific custom permissions
gateway.grant(user_role, "bedrock-agentcore:GetGateway")
```

## Gateway Target

After Creating gateways, you can add targets which define the tools that your gateway will host. Gateway supports multiple target
types including Lambda functions and API specifications (either OpenAPI schemas or Smithy models). Gateway allows you to attach multiple
targets to a Gateway and you can change the targets / tools attached to a gateway at any point. Each target can have its own
credential provider attached enabling you to securely access targets whether they need IAM, API Key, or OAuth credentials.

### Gateway Target Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `gatewayTargetName` | `string` | No | The name of the gateway target. Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen). If not provided, a unique name will be auto-generated |
| `description` | `string` | No | Optional description for the gateway target. Maximum 200 characters |
| `gateway` | `IGateway` | Yes | The gateway this target belongs to |
| `targetConfiguration` | `ITargetConfiguration` | Yes | The target configuration (Lambda, OpenAPI, Smithy, or API Gateway). **Note:** Users typically don't create this directly. When using convenience methods like `GatewayTarget.forLambda()`, `GatewayTarget.forOpenApi()`, `GatewayTarget.forSmithy()`, `GatewayTarget.forApiGateway()`, `GatewayTarget.forMcpServer()` or the gateway's `addLambdaTarget()`, `addOpenApiTarget()`, `addSmithyTarget()`, `addApiGatewayTarget()`, `addMcpServerTarget()` methods, this configuration is created internally for you. Only needed when using the GatewayTarget constructor directly for [advanced scenarios](#advanced-usage-direct-configuration-for-gateway-target). |
| `credentialProviderConfigurations` | `IGatewayCredentialProvider[]` | No | Credential providers for authentication. Defaults to `[GatewayCredentialProvider.fromIamRole()]`. Use `GatewayCredentialProvider.fromApiKeyIdentityArn()`, `GatewayCredentialProvider.fromOauthIdentityArn()`, or `GatewayCredentialProvider.fromIamRole()` |
| `validateOpenApiSchema` | `boolean` | No | (OpenAPI targets only) Whether to validate the OpenAPI schema at synthesis time. Defaults to `true`. Only applies to inline and local asset schemas. For more information refer here [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-schema-openapi.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-schema-openapi.html) |

This approach gives you full control over the configuration but is typically not necessary for most use cases.

### Targets types

You can create the following targets types:

**Lambda Target**: Lambda targets allow you to connect your gateway to AWS Lambda functions that implement your tools. This is useful
when you want to execute custom code in response to tool invocations.

* Supports GATEWAY_IAM_ROLE credential provider only
* Ideal for custom serverless function integration
* Need tool schema (tool schema is a blueprint that describes the functions your Lambda provides to AI agents).
  The construct provide [3 ways to upload a tool schema to Lambda target](#tools-schema-for-lambda-target)
* When using the default IAM authentication (no `credentialProviderConfigurations` specified),
  the construct automatocally grants the gateway role permission to invoke your Lambda function (`lambda:InvokeFunction`).

**OpenAPI Schema Target** : OpenAPI widely used standard for describing RESTful APIs. Gateway supports OpenAPI 3.0
specifications for defining API targets. It connects to REST APIs using OpenAPI specifications

* Supports OAUTH and API_KEY credential providers (Do not support IAM, you must provide `credentialProviderConfigurations`)
* Ideal for integrating with external REST services
* Need API schema. The construct provide [3 ways to upload a API schema to OpenAPI target](#api-schema-for-openapi-and-smithy-target)

**Smithy Model Target** : Smithy is a language for defining services and software development kits (SDKs). Smithy models provide
a more structured approach to defining APIs compared to OpenAPI, and are particularly useful for connecting to AWS services.
AgentCore Gateway supports built-in AWS service models only. It connects to services using Smithy model definitions

* Supports OAUTH and API_KEY credential providers
* Ideal for AWS service integrations
* Need API schema. The construct provide 3 ways to upload a API schema to Smity target
* When using the default IAM authentication (no `credentialProviderConfigurations` specified), The construct only
  grants permission to read the Smithy schema file from S3. You MUST manually grant permissions for the gateway
  role to invoke the actual Smithy API endpoints

> Note: For Smithy model targets that access AWS services, your Gateway's execution role needs permissions to access those services.
> For example, for a DynamoDB target, your execution role needs permissions to perform DynamoDB operations.
> This is not managed by the construct due to the large number of options. Please refer to
> [Smithy Model Permission](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-prerequisites-permissions.html) for example.

**MCP Server Target**: Model Context Protocol (MCP) servers provide external tools, data access, and custom functions for AI agents.
MCP servers enable agents to interact with external systems and services through a standardized protocol. Gateway automatically
discovers and indexes available tools from MCP servers through synchronization.

**Key Features:**

* Requires explicit authentication configuration (OAuth2 recommended, empty array for NoAuth)
* Ideal for connecting to external MCP-compliant servers
* The endpoint must use HTTPS protocol
* Supported MCP protocol versions: 2025-06-18, 2025-03-26
* Automatic tool discovery through synchronization

**Synchronization Behavior:**

MCP Server targets require synchronization to discover and index available tools:

* **Implicit Synchronization (Automatic)**: Tool discovery happens automatically during:

  * Target creation (`CreateGatewayTarget`)
  * Target updates (`UpdateGatewayTarget`)
  * The Gateway calls the MCP server's `tools/list` endpoint and indexes tools without user intervention
* **Explicit Synchronization (Manual)**: When the MCP server's tools change independently (new tools added, schemas modified, tools removed):

  * The Gateway's tool catalog becomes stale
  * Call the `SynchronizeGatewayTargets` API to refresh the catalog
  * Use the `grantSync()` method to grant permissions to Lambda functions, CI/CD pipelines, or scheduled tasks that will trigger synchronization

**Authentication & Permissions:**

When using OAuth2, the Gateway service role automatically receives:

* `bedrock-agentcore:GetWorkloadAccessToken`
* `bedrock-agentcore:GetResourceOauth2Token`
* `secretsmanager:GetSecretValue`
* KMS decrypt (if secrets are encrypted)

For explicit synchronization, use `grantSync()` to grant `bedrock-agentcore:SynchronizeGatewayTargets` permission to your operator roles.

> For more information, refer to the [MCP Server Target documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-target-MCPservers.html).

### Understanding Tool Naming

When tools are exposed through gateway targets, AgentCore Gateway prefixes each tool name with the target name to ensure uniqueness across multiple targets. This is important to understand when building your application logic.

**Naming Pattern:**

**Example:**

If your target is named `my-lambda-target` and provides a tool called `calculate_price`, agents will discover and invoke it as `my-lambda-target__calculate_price`.

**Important Considerations:**

* **For Lambda Targets**: Your Lambda handler must strip the target name prefix before processing the tool request. The full tool name (with prefix) is sent in the event.
* **For MCP Server Targets**: The MCP server receives tool calls with the prefixed name from the gateway.
* **For OpenAPI/Smithy Targets**: The gateway handles the prefix automatically when mapping to API operations based on the `operationId`.

This naming convention ensures that:

* Tools from different targets don't collide even if they have the same name
* Agents can access tools from multiple targets through a single gateway
* Tool names remain unique in the unified tool catalog

For more details, see the [Gateway Tool Naming Documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-tool-naming.html).

### Tools schema For Lambda target

The lambda target need tools schema to understand the fuunction lambda provides. You can upload the tool schema by following 3 ways:

* From a local asset file

```python
tool_schema = agentcore.ToolSchema.from_local_asset(
    path.join(__dirname, "schemas", "my-tool-schema.json"))
```

* From an existing S3 file:

```python
tool_schema = agentcore.ToolSchema.from_s3_file(
    s3.Bucket.from_bucket_name(self, "SchemasBucket", "my-schemas-bucket"), "tools/complex-tool-schema.json", "123456789012")
```

* From Inline:

```python
tool_schema = agentcore.ToolSchema.from_inline([
    name="hello_world",
    description="A simple hello world tool",
    input_schema=agentcore.SchemaDefinition(
        type=agentcore.SchemaDefinitionType.OBJECT,
        properties={
            "name": agentcore.SchemaDefinition(
                type=agentcore.SchemaDefinitionType.STRING,
                description="The name to greet"
            )
        },
        required=["name"]
    )
])
```

### Api schema For OpenAPI and Smithy target

The OpenAPI and Smithy target need API Schema. The Gateway construct provide three ways to upload API schema for your target:

* From a local asset file (requires binding to scope):

```python
# When using ApiSchema.fromLocalAsset, you must bind the schema to a scope
schema = agentcore.ApiSchema.from_local_asset(path.join(__dirname, "mySchema.yml"))

schema.bind(self)
```

* From an inline schema:

```python
inline_schema = agentcore.ApiSchema.from_inline("""
    openapi: 3.0.3
    info:
      title: Library API
      version: 1.0.0
    paths:
      /search:
        get:
          summary: Search for books
          operationId: searchBooks
          parameters:
            - name: query
              in: query
              required: true
              schema:
                type: string
    """)
```

* From an existing S3 file:

```python
bucket = s3.Bucket.from_bucket_name(self, "ExistingBucket", "my-schema-bucket")
s3_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/action-group.yaml")
```

### Outbound auth

Outbound authorization lets Amazon Bedrock AgentCore gateways securely access gateway targets on behalf of users authenticated
and authorized during Inbound Auth.

AgentCore Gateway supports the following types of outbound authorization:

**IAM-based outbound authorization** – The gateway uses its execution role to authenticate with AWS services. This is the default
and most common approach for Lambda targets and AWS service integrations.

**2-legged OAuth (OAuth 2LO)** – Use OAuth 2.0 two-legged flow (2LO) for targets that require OAuth authentication.
The gateway authenticates on its own behalf, not on behalf of a user.

**API key** – Use the AgentCore service/AWS console to generate an API key to authenticate access to the gateway target.

**Note > You need to set up the outbound identity before you can create a gateway target.

### Basic Gateway Target Creation

You can create targets in two ways: using the static factory methods on `GatewayTarget` or using the convenient `addTarget` methods on the gateway instance.

#### Using addTarget methods (Recommended)

This approach is recommended for most use cases, especially when creating targets alongside the gateway. It provides a cleaner, more fluent API by eliminating the need to explicitly pass the gateway reference.

Below are the examples on how you can create Lambda, Smithy, OpenAPI, MCP Server, and API Gateway targets using `addTarget` methods.

```python
# Create a gateway first
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

lambda_function = lambda_.Function(self, "MyFunction",
    runtime=lambda_.Runtime.NODEJS_22_X,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
            exports.handler = async (event) => {
              return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Hello from Lambda!' })
              };
            };
          """)
)

lambda_target = gateway.add_lambda_target("MyLambdaTarget",
    gateway_target_name="my-lambda-target",
    description="Lambda function target",
    lambda_function=lambda_function,
    tool_schema=agentcore.ToolSchema.from_inline([
        name="hello_world",
        description="A simple hello world tool",
        input_schema=agentcore.SchemaDefinition(
            type=agentcore.SchemaDefinitionType.OBJECT,
            properties={
                "name": agentcore.SchemaDefinition(
                    type=agentcore.SchemaDefinitionType.STRING,
                    description="The name to greet"
                )
            },
            required=["name"]
        )

    ])
)
```

* OpenAPI Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

# These ARNs are returned when creating the API key credential provider via Console or API
api_key_provider_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
api_key_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket = s3.Bucket.from_bucket_name(self, "ExistingBucket", "my-schema-bucket")
s3my_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/myschema.yaml")

# Add an OpenAPI target directly to the gateway
target = gateway.add_open_api_target("MyTarget",
    gateway_target_name="my-api-target",
    description="Target for external API integration",
    api_schema=s3my_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.from_api_key_identity_arn(
            provider_arn=api_key_provider_arn,
            secret_arn=api_key_secret_arn,
            credential_location=agentcore.ApiKeyCredentialLocation.header(
                credential_parameter_name="X-API-Key"
            )
        )
    ]
)

# This make sure your s3 bucket is available before target
target.node.add_dependency(bucket)
```

* Smithy Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

smithy_schema = agentcore.ApiSchema.from_local_asset(
    path.join(__dirname, "models", "smithy-model.json"))
smithy_schema.bind(self)

smithy_target = gateway.add_smithy_target("MySmithyTarget",
    gateway_target_name="my-smithy-target",
    description="Smithy model target",
    smithy_model=smithy_schema
)
```

* MCP Server Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

# OAuth2 authentication (recommended)
# Note: Create the OAuth provider using AWS console or Identity L2 construct when available
oauth_provider_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/oauth2credentialprovider/my-oauth"
oauth_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth-secret-abc123"

# Add an MCP server target directly to the gateway
mcp_target = gateway.add_mcp_server_target("MyMcpServer",
    gateway_target_name="my-mcp-server",
    description="External MCP server integration",
    endpoint="https://my-mcp-server.example.com",
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.from_oauth_identity_arn(
            provider_arn=oauth_provider_arn,
            secret_arn=oauth_secret_arn,
            scopes=["mcp-runtime-server/invoke"]
        )
    ]
)

# Grant sync permission to a Lambda function that will trigger synchronization
sync_function = lambda_.Function(self, "SyncFunction",
    runtime=lambda_.Runtime.PYTHON_3_12,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
        import boto3

        def handler(event, context):
            client = boto3.client('bedrock-agentcore')
            response = client.synchronize_gateway_targets(
                gatewayIdentifier=event['gatewayId'],
                targetIds=[event['targetId']]
            )
            return response
          """)
)

mcp_target.grant_sync(sync_function)
```

* API Gateway Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

api = apigateway.RestApi(self, "MyApi",
    rest_api_name="my-api"
)

# Uses IAM authorization for outbound auth by default
api_gateway_target = gateway.add_api_gateway_target("MyApiGatewayTarget",
    rest_api=api,
    api_gateway_tool_configuration=agentcore.ApiGatewayToolConfiguration(
        tool_filters=[agentcore.ApiGatewayToolFilter(
            filter_path="/pets/*",
            methods=[agentcore.ApiGatewayHttpMethod.GET]
        )
        ]
    )
)
```

#### Using static factory methods

Use static factory methods when working with imported gateways, creating targets in different constructs/stacks, or when you need more explicit control over the construct tree hierarchy.

Create Gateway target using static convenience methods.

* Lambda Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

lambda_function = lambda_.Function(self, "MyFunction",
    runtime=lambda_.Runtime.NODEJS_22_X,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
                exports.handler = async (event) => {
                    return {
                        statusCode: 200,
                        body: JSON.stringify({ message: 'Hello from Lambda!' })
                    };
                };
            """)
)

# Create a gateway target with Lambda and tool schema
target = agentcore.GatewayTarget.for_lambda(self, "MyLambdaTarget",
    gateway_target_name="my-lambda-target",
    description="Target for Lambda function integration",
    gateway=gateway,
    lambda_function=lambda_function,
    tool_schema=agentcore.ToolSchema.from_local_asset(
        path.join(__dirname, "schemas", "my-tool-schema.json"))
)
```

* OpenAPI Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

# outbound auth (Use AWS console to create it, Once Identity L2 construct is available you can use it to create identity)
api_key_identity_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
api_key_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

opneapi_schema = agentcore.ApiSchema.from_local_asset(path.join(__dirname, "mySchema.yml"))
opneapi_schema.bind(self)

# Create a gateway target with OpenAPI Schema
target = agentcore.GatewayTarget.for_open_api(self, "MyTarget",
    gateway_target_name="my-api-target",
    description="Target for external API integration",
    gateway=gateway,  # Note: you need to pass the gateway reference
    api_schema=opneapi_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.from_api_key_identity_arn(
            provider_arn=api_key_identity_arn,
            secret_arn=api_key_secret_arn
        )
    ]
)
```

* Smithy Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

smithy_schema = agentcore.ApiSchema.from_local_asset(
    path.join(__dirname, "models", "smithy-model.json"))
smithy_schema.bind(self)

# Create a gateway target with Smithy Model and OAuth
target = agentcore.GatewayTarget.for_smithy(self, "MySmithyTarget",
    gateway_target_name="my-smithy-target",
    description="Target for Smithy model integration",
    gateway=gateway,
    smithy_model=smithy_schema
)
```

* MCP Server Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

# OAuth2 authentication (recommended)
# Note: Create the OAuth provider using AWS console or Identity L2 construct when available
oauth_provider_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/oauth2credentialprovider/my-oauth"
oauth_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth-secret-abc123"

# Create a gateway target with MCP Server
mcp_target = agentcore.GatewayTarget.for_mcp_server(self, "MyMcpServer",
    gateway_target_name="my-mcp-server",
    description="External MCP server integration",
    gateway=gateway,
    endpoint="https://my-mcp-server.example.com",
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.from_oauth_identity_arn(
            provider_arn=oauth_provider_arn,
            secret_arn=oauth_secret_arn,
            scopes=["mcp-runtime-server/invoke"]
        )
    ]
)
```

* API Gateway Target

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

api = apigateway.RestApi(self, "MyApi",
    rest_api_name="my-api"
)

# Create a gateway target using the static factory method
api_gateway_target = agentcore.GatewayTarget.for_api_gateway(self, "MyApiGatewayTarget",
    gateway_target_name="my-api-gateway-target",
    description="Target for API Gateway REST API integration",
    gateway=gateway,
    rest_api=api,
    api_gateway_tool_configuration=agentcore.ApiGatewayToolConfiguration(
        tool_filters=[agentcore.ApiGatewayToolFilter(
            filter_path="/pets/*",
            methods=[agentcore.ApiGatewayHttpMethod.GET, agentcore.ApiGatewayHttpMethod.POST]
        )
        ]
    ),
    metadata_configuration=agentcore.MetadataConfiguration(
        allowed_request_headers=["X-User-Id"],
        allowed_query_parameters=["limit"]
    )
)
```

### Advanced Usage: Direct Configuration for gateway target

For advanced use cases where you need full control over the target configuration, you can create configurations manually using the static factory methods and use the GatewayTarget constructor directly.

#### Configuration Factory Methods

Each target type has a corresponding configuration class with a static `create()` method:

* **Lambda**: `LambdaTargetConfiguration.create(lambdaFunction, toolSchema)`
* **OpenAPI**: `OpenApiTargetConfiguration.create(apiSchema, validateSchema?)`
* **Smithy**: `SmithyTargetConfiguration.create(smithyModel)`
* **API Gateway**: `ApiGatewayTargetConfiguration.create(props)`

#### Example: Lambda Target with Custom Configuration

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

my_lambda_function = lambda_.Function(self, "MyFunction",
    runtime=lambda_.Runtime.NODEJS_22_X,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
            exports.handler = async (event) => ({ statusCode: 200 });
          """)
)

my_tool_schema = agentcore.ToolSchema.from_inline([
    name="my_tool",
    description="My custom tool",
    input_schema=agentcore.SchemaDefinition(
        type=agentcore.SchemaDefinitionType.OBJECT,
        properties={}
    )
])

# Create a custom Lambda configuration
custom_config = agentcore.LambdaTargetConfiguration.create(my_lambda_function, my_tool_schema)

# Use the GatewayTarget constructor directly
target = agentcore.GatewayTarget(self, "AdvancedTarget",
    gateway=gateway,
    gateway_target_name="advanced-target",
    target_configuration=custom_config,  # Manually created configuration
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.from_iam_role()
    ]
)
```

This approach gives you full control over the configuration but is typically not necessary for most use cases. The convenience methods (`GatewayTarget.forLambda()`, `GatewayTarget.forOpenApi()`, `GatewayTarget.forSmithy()`, `GatewayTarget.forApiGateway()`) handle all of this internally.

### Gateway Interceptors

Gateway interceptors allow you to run custom code during each gateway invocation to implement fine-grained access control, transform requests and responses, or implement custom authorization logic. A gateway can have at most one REQUEST interceptor and one RESPONSE interceptor.

**Interceptor Types:**

* **REQUEST interceptors**: Execute before the gateway calls the target. Useful for request validation, transformation, or custom authorization
* **RESPONSE interceptors**: Execute after the target responds but before the gateway sends the response back. Useful for response transformation, filtering, or adding custom headers

**Security Best Practices:**

1. Keep `passRequestHeaders` disabled unless absolutely necessary (default: false)
2. Implement idempotent Lambda functions (gateway may retry on failures)
3. Restrict gateway execution role to specific Lambda functions
4. Avoid logging sensitive information in your interceptor

For more information, see the [Gateway Interceptors documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-interceptors.html).

#### Adding Interceptors via Constructor

```python
# Create Lambda functions for interceptors
request_interceptor_fn = lambda_.Function(self, "RequestInterceptor",
    runtime=lambda_.Runtime.PYTHON_3_12,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
        def handler(event, context):
            # Validate and transform request
            return {
                "interceptorOutputVersion": "1.0",
                "mcp": {
                    "transformedGatewayRequest": event["mcp"]["gatewayRequest"]
                }
            }
          """)
)

response_interceptor_fn = lambda_.Function(self, "ResponseInterceptor",
    runtime=lambda_.Runtime.PYTHON_3_12,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
        def handler(event, context):
            # Filter or transform response
            return {
                "interceptorOutputVersion": "1.0",
                "mcp": {
                    "transformedGatewayResponse": event["mcp"]["gatewayResponse"]
                }
            }
          """)
)

# Create gateway with interceptors
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    interceptor_configurations=[
        agentcore.LambdaInterceptor.for_request(request_interceptor_fn,
            pass_request_headers=True
        ),
        agentcore.LambdaInterceptor.for_response(response_interceptor_fn)
    ]
)
```

**Automatic Permission Granting:**

When you add a Lambda interceptor to a gateway (either via constructor or `addInterceptor()`), the gateway's IAM role automatically receives `lambda:InvokeFunction` permission on the Lambda function. This permission grant happens internally during the bind process - you do not need to manually configure these IAM permissions.

#### Adding Interceptors Dynamically

```python
# Create a gateway first
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

# Create Lambda functions for interceptors
request_interceptor_fn = lambda_.Function(self, "RequestInterceptor",
    runtime=lambda_.Runtime.PYTHON_3_12,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
        def handler(event, context):
            # Custom request validation logic
            return {
                "interceptorOutputVersion": "1.0",
                "mcp": {
                    "transformedGatewayRequest": event["mcp"]["gatewayRequest"]
                }
            }
          """)
)

response_interceptor_fn = lambda_.Function(self, "ResponseInterceptor",
    runtime=lambda_.Runtime.PYTHON_3_12,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
        def handler(event, context):
            # Filter sensitive data from response
            return {
                "interceptorOutputVersion": "1.0",
                "mcp": {
                    "transformedGatewayResponse": event["mcp"]["gatewayResponse"]
                }
            }
          """)
)

gateway.add_interceptor(
    agentcore.LambdaInterceptor.for_request(request_interceptor_fn,
        pass_request_headers=False
    ))

gateway.add_interceptor(
    agentcore.LambdaInterceptor.for_response(response_interceptor_fn))
```

### Gateway Target IAM Permissions

The Gateway Target construct provides convenient methods for granting IAM permissions:

```python
# Create a gateway and target
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

smithy_schema = agentcore.ApiSchema.from_local_asset(
    path.join(__dirname, "models", "smithy-model.json"))
smithy_schema.bind(self)

# Create a gateway target with Smithy Model and OAuth
target = agentcore.GatewayTarget.for_smithy(self, "MySmithyTarget",
    gateway_target_name="my-smithy-target",
    description="Target for Smithy model integration",
    gateway=gateway,
    smithy_model=smithy_schema
)

# Create a role that needs access to the gateway target
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
target.grant_read(user_role)

# Grant manage permissions (Create, Update, Delete actions)
target.grant_manage(user_role)

# Grant specific custom permissions
target.grant(user_role, "bedrock-agentcore:GetGatewayTarget")

# Grants permission to invoke this Gateway
gateway.grant_invoke(user_role)
```

## Memory

Memory is a critical component of intelligence. While Large Language Models (LLMs) have impressive capabilities, they lack persistent memory across conversations. Amazon Bedrock AgentCore Memory addresses this limitation by providing a managed service that enables AI agents to maintain context over time, remember important facts, and deliver consistent, personalized experiences.

AgentCore Memory operates on two levels:

* **Short-Term Memory**: Immediate conversation context and session-based information that provides continuity within a single interaction or closely related sessions.
* **Long-Term Memory**: Persistent information extracted and stored across multiple conversations, including facts, preferences, and summaries that enable personalized experiences over time.

When you interact with the memory via the `CreateEvent` API, you store interactions in Short-Term Memory (STM) instantly. These interactions can include everything from user messages, assistant responses, to tool actions.

To write to long-term memory, you need to configure extraction strategies which define how and where to store information from conversations for future use. These strategies are asynchronously processed from raw events after every few turns based on the strategy that was selected. You can't create long term memory records directly, as they are extracted asynchronously by AgentCore Memory.

### Memory Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `memoryName` | `string` | No | The name of the memory. If not provided, a unique name will be auto-generated |
| `expirationDuration` | `Duration` | No | Short-term memory expiration in days (between 7 and 365). Default: 90 days |
| `description` | `string` | No | Optional description for the memory. Default: no description. |
| `kmsKey` | `IKey` | No | Custom KMS key to use for encryption. Default: Your data is encrypted with a key that AWS owns and manages for you |
| `memoryStrategies` | `MemoryStrategyBase[]` | No | Built-in extraction strategies to use for this memory. Default: No extraction strategies (short term memory only) |
| `executionRole` | `iam.IRole` | No | The IAM role that provides permissions for the memory to access AWS services. Default: A new role will be created. |
| `tags` | `{ [key: string]: string }` | No | Tags for memory. Default: no tags. |

### Basic Memory Creation

Below you can find how to configure a simple short-term memory (STM) with no long-term memory extraction strategies.
Note how you set `expirationDuration`, which defines the time the events will be stored in the short-term memory before they expire.

```python
# Create a basic memory with default settings, no LTM strategies
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="A memory for storing user interactions for a period of 90 days",
    expiration_duration=cdk.Duration.days(90)
)
```

Basic Memory with Custom KMS Encryption

```python
# Create a custom KMS key for encryption
encryption_key = kms.Key(self, "MemoryEncryptionKey",
    enable_key_rotation=True,
    description="KMS key for memory encryption"
)

# Create memory with custom encryption
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_encrypted_memory",
    description="Memory with custom KMS encryption",
    expiration_duration=cdk.Duration.days(90),
    kms_key=encryption_key
)
```

### LTM Memory Extraction Stategies

If you need long-term memory for context recall across sessions, you can setup memory extraction strategies
to extract the relevant memory from the raw events.

Amazon Bedrock AgentCore Memory has different memory strategies for extracting and organizing information:

* **Summarization**: to summarize interactions to preserve critical context and key insights.
* **Semantic Memory**: to extract general factual knowledge, concepts and meanings from raw conversations using vector embeddings.
  This enables similarity-based retrieval of relevant facts and context.
* **User Preferences**: to extract user behavior patterns from raw conversations.

You can use built-in extraction strategies for quick setup, or create custom extraction strategies with specific models and prompt templates.

### Memory with Built-in Strategies

The library provides four built-in LTM strategies. These are default strategies for organizing and extracting memory data,
each optimized for specific use cases.

For example: An agent helps multiple users with cloud storage setup. From these conversations,
see how each strategy processes users expressing confusion about account connection:

1. **Summarization Strategy** (`MemoryStrategy.usingBuiltInSummarization()`)
   This strategy compresses conversations into concise overviews, preserving essential context and key insights for quick recall.
   Extracted memory example: Users confused by cloud setup during onboarding.

   * Extracts concise summaries to preserve critical context and key insights
   * Namespace: `/strategies/{memoryStrategyId}/actors/{actorId}/sessions/{sessionId}`
2. **Semantic Memory Strategy** (`MemoryStrategy.usingBuiltInSemantic()`)
   Distills general facts, concepts, and underlying meanings from raw conversational data, presenting the information in a context-independent format.
   Extracted memory example: In-context learning = task-solving via examples, no training needed.

   * Extracts general factual knowledge, concepts and meanings from raw conversations
   * Namespace: `/strategies/{memoryStrategyId}/actors/{actorId}`
3. **User Preference Strategy** (`MemoryStrategy.usingBuiltInUserPreference()`)
   Captures individual preferences, interaction patterns, and personalized settings to enhance future experiences.
   Extracted memory example: User needs clear guidance on cloud storage account connection during onboarding.

   * Extracts user behavior patterns from raw conversations
   * Namespace: `/strategies/{memoryStrategyId}/actors/{actorId}`
4. **Episodic Memory Strategy** (`MemoryStrategy.usingBuiltInEpisodic()`)
   Captures meaningful slices of user and system interactions, preserve them into compact records after summarizing.
   Extracted memory example: User first asked about pricing on Monday, then requested feature comparison on Tuesday, finally made purchase decision on Wednesday.

   * Captures event sequences and temporal relationships
   * Namespace: `/strategy/{memoryStrategyId}/actor/{actorId}/session/{sessionId}`
   * Reflections: `/strategy/{memoryStrategyId}/actor/{actorId}`

```python
# Create memory with built-in strategies
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="Memory with built-in strategies",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[
        agentcore.MemoryStrategy.using_built_in_summarization(),
        agentcore.MemoryStrategy.using_built_in_semantic(),
        agentcore.MemoryStrategy.using_built_in_user_preference(),
        agentcore.MemoryStrategy.using_built_in_episodic()
    ]
)
```

The name generated for each built in memory strategy is as follows:

* For Summarization: `summary_builtin_cdk001`
* For Semantic:`semantic_builtin_cdk001>`
* For User Preferences: `preference_builtin_cdk001`
* For Episodic : `episodic_builtin_cdkGen0001`

### Memory with custom Strategies

With Long-Term Memory, organization is managed through Namespaces.

An `actor` refers to entity such as end users or agent/user combinations. For example, in a coding support chatbot,
the actor is usually the developer asking questions. Using the actor ID helps the system know which user the memory belongs to,
keeping each user's data separate and organized.

A `session` is usually a single conversation or interaction period between the user and the AI agent.
It groups all related messages and events that happen during that conversation.

A `namespace` is used to logically group and organize long-term memories. It ensures data stays neat, separate, and secure.

With AgentCore Memory, you need to add a namespace when you define a memory strategy. This namespace helps define where the long-term memory
will be logically grouped. Every time a new long-term memory is extracted using this memory strategy, it is saved under the namespace you set.
This means that all long-term memories are scoped to their specific namespace, keeping them organized and preventing any mix-ups with other
users or sessions. You should use a hierarchical format separated by forward slashes /. This helps keep memories organized clearly. As needed,
you can choose to use the below pre-defined variables within braces in the namespace based on your applications' organization needs:

* `actorId` – Identifies who the long-term memory belongs to, such as a user
* `memoryStrategyId` – Shows which memory strategy is being used. This strategy identifier is auto-generated when you create a memory using CreateMemory operation.
* `sessionId` – Identifies which session or conversation the memory is from.

For example, if you define the following namespace as the input to your strategy in CreateMemory operation:

```shell
/strategy/{memoryStrategyId}/actor/{actorId}/session/{sessionId}
```

After memory creation, this namespace might look like:

```shell
/strategy/summarization-93483043//actor/actor-9830m2w3/session/session-9330sds8
```

You can customise the namespace, i.e. where the memories are stored by using the following methods:

1. **Summarization Strategy** (`MemoryStrategy.usingSummarization(props)`)
2. **Semantic Memory Strategy** (`MemoryStrategy.usingSemantic(props)`)
3. **User Preference Strategy** (`MemoryStrategy.usingUserPreference(props)`)
4. **Episodic Memory Strategy** (`MemoryStrategy.usingEpisodic(props)`)

```python
# Create memory with custom strategies
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="Memory with custom strategies",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[
        agentcore.MemoryStrategy.using_user_preference(
            name="CustomerPreferences",
            namespaces=["support/customer/{actorId}/preferences"]
        ),
        agentcore.MemoryStrategy.using_semantic(
            name="CustomerSupportSemantic",
            namespaces=["support/customer/{actorId}/semantic"]
        ),
        agentcore.MemoryStrategy.using_episodic(
            name="customerJourneyEpisodic",
            namespaces=["/journey/customer/{actorId}/episodes"],
            reflection_configuration=agentcore.EpisodicReflectionConfiguration(
                namespaces=["/journey/customer/{actorId}/reflections"]
            )
        )
    ]
)
```

Custom memory strategies let you tailor memory extraction and consolidation to your specific domain or use case.
You can override the prompts for extracting and consolidating semantic, summary, or user preferences.
You can also choose the model that you want to use for extraction and consolidation.

The custom prompts you create are appended to a non-editable system prompt.

Since a custom strategy requires you to invoke certain FMs, you need a role with appropriate permissions. For that, you can:

* Let the L2 construct create a minimum permission role for you when use L2 Bedrock Foundation Models.
* Use a custom role with the overly permissive `AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy` managed policy.
* Use a custom role with your own custom policies.

#### Memory with Custom Execution Role

Keep in mind that memories that **do not** use custom strategies do not require a service role.
So even if you provide it, it will be ignored as it will never be used.

```python
# Create a custom execution role
execution_role = iam.Role(self, "MemoryExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy")
    ]
)

# Create memory with custom execution role
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="Memory with custom execution role",
    expiration_duration=cdk.Duration.days(90),
    execution_role=execution_role
)
```

In customConsolidation and customExtraction, the model property uses the [@aws-cdk/aws-bedrock-alph](https://www.npmjs.com/package/@aws-cdk/aws-bedrock-alpha) library which must be installed separately.

```python
# Create a custom semantic memory strategy
custom_semantic_strategy = agentcore.MemoryStrategy.using_semantic(
    name="customSemanticStrategy",
    description="Custom semantic memory strategy",
    namespaces=["/custom/strategies/{memoryStrategyId}/actors/{actorId}"],
    custom_consolidation=agentcore.OverrideConfig(
        model=bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        append_to_prompt="Custom consolidation prompt for semantic memory"
    ),
    custom_extraction=agentcore.OverrideConfig(
        model=bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        append_to_prompt="Custom extraction prompt for semantic memory"
    )
)

# Create memory with custom strategy
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my-custom-memory",
    description="Memory with custom strategy",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[custom_semantic_strategy]
)
```

### Memory with self-managed Strategies

A self-managed strategy in Amazon Bedrock AgentCore Memory gives you complete control over your memory extraction and consolidation pipelines.
With a self-managed strategy, you can build custom memory processing workflows while leveraging Amazon Bedrock AgentCore for storage and retrieval.

For additional information, you can refer to the [developer guide for self managed strategies](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory-self-managed-strategies.html).

Create the required AWS resources including:

* an S3 bucket in your account where Amazon Bedrock AgentCore will deliver batched event payloads.
* an SNS topic for job notifications. Use FIFO topics if processing order within sessions is important for your use case.

The construct will apply the correct permissions to the memory execution role to access these resources.

```python
bucket = s3.Bucket(self, "memoryBucket",
    bucket_name="test-memory",
    removal_policy=cdk.RemovalPolicy.DESTROY,
    auto_delete_objects=True
)

topic = sns.Topic(self, "topic")

# Create a custom semantic memory strategy
self_managed_strategy = agentcore.MemoryStrategy.using_self_managed(
    name="selfManagedStrategy",
    description="self managed memory strategy",
    historical_context_window_size=5,
    invocation_configuration=agentcore.InvocationConfiguration(
        topic=topic,
        s3_location=s3.Location(
            bucket_name=bucket.bucket_name,
            object_key="memory/"
        )
    ),
    trigger_conditions=agentcore.TriggerConditions(
        message_based_trigger=1,
        time_based_trigger=cdk.Duration.seconds(10),
        token_based_trigger=100
    )
)

# Create memory with custom strategy
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my-custom-memory",
    description="Memory with custom strategy",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[self_managed_strategy]
)
```

### Memory Strategy Methods

You can add new memory strategies to the memory construct using the `addMemoryStrategy()` method, for instance:

```python
# Create memory without initial strategies
memory = agentcore.Memory(self, "test-memory",
    memory_name="test_memory_add_strategy",
    description="A test memory for testing addMemoryStrategy method",
    expiration_duration=cdk.Duration.days(90)
)

# Add strategies after instantiation
memory.add_memory_strategy(agentcore.MemoryStrategy.using_built_in_summarization())
memory.add_memory_strategy(agentcore.MemoryStrategy.using_built_in_semantic())
```

## Policy Engine

A policy engine is a collection of policies that evaluates and authorizes agent tool calls. When associated with a gateway, the policy engine intercepts all agent requests and determines whether to allow or deny each action based on the defined policies.

For more information, see the [Policy in Amazon Bedrock AgentCore documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/policy.html).

### PolicyEngine Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `policyEngineName` | `string` | No | The name of the policy engine. Valid characters: a-z, A-Z, 0-9, _ (underscore). Must start with a letter, 1-48 characters. If not provided, a unique name will be auto-generated |
| `description` | `string` | No | Optional description for the policy engine (max 4,096 characters). Default: no description |
| `kmsKey` | `IKey` | No | Custom KMS key for encryption. **IMPORTANT**: Once set, cannot be changed (requires replacement). Must be symmetric ENCRYPT_DECRYPT key. If key becomes inaccessible, all authorization decisions will be DENIED. Default: AWS owned key |
| `tags` | `{ [key: string]: string }` | No | Tags for the policy engine (max 50 tags). Default: no tags |

### Understanding Cedar Policies in AgentCore

Policies are constructed using [Cedar language](https://www.cedarpolicy.com/en/tutorial), an open source language for writing and enforcing authorization policies.
Cedar policies in AgentCore follow a specific structure with three main components: **Principal**, **Action**, and **Resource**. Understanding how these components work together is critical for writing effective policies.

#### Policy Structure

Every Cedar policy has this basic structure:

```cedar
permit(              // or forbid
  principal,         // Who is making the request
  action,            // What operation they want to perform
  resource           // What Gateway/tool they want to access
)
when {               // Optional conditions
  // Additional constraints
};
```

Example Policy

```cedar
permit(
  principal,
  action == AgentCore::Action::"ApplicationToolTarget___create_application",
  resource == AgentCore::Gateway::"<gateway-arn>"
) when {
  context.input.coverage_amount <= 1000000
};
```

### Basic PolicyEngine and Policy Creation

Create a policy engine and add policies to it.

#### Policy Engine Mode

When associating a policy engine with a gateway, you can control the enforcement behavior using `PolicyEngineMode`:

* `PolicyEngineMode.LOG_ONLY` (default) — evaluates actions and adds traces but does not enforce decisions. Use this mode for testing and validation before enabling enforcement.
* `PolicyEngineMode.ENFORCE` — actively allows or denies agent operations based on Cedar policy evaluation.

```python
# Create a Policy engine
policy_engine = agentcore.PolicyEngine(self, "MyPolicyEngine",
    policy_engine_name="my_policy_engine",
    description="Policy engine for access control"
)

gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    policy_engine_configuration=agentcore.GatewayPolicyEngineConfig(
        policy_engine=policy_engine,
        mode=agentcore.PolicyEngineMode.ENFORCE
    )
)

# Add policy to policy engine
policy_engine.add_policy("AllowAllActions",
    definition=f"""
        permit(
          principal,
          action,
          resource == AgentCore::Gateway::\"{gateway.gatewayArn}\"
        );
      """,
    description="Allow all actions on specific gateway (development)",
    validation_mode=agentcore.PolicyValidationMode.IGNORE_ALL_FINDINGS
)

# you can add multiple policies to the policy engine
policy_engine.add_policy("SpecificToolPolicy",
    definition=f"""
        permit(
          principal is AgentCore::OAuthUser,
          action == AgentCore::Action::\"WeatherTool__get_forecast\",
          resource == AgentCore::Gateway::\"{gateway.gatewayArn}\"
        );
      """,
    description="Allow specific weather tool access",
    validation_mode=agentcore.PolicyValidationMode.FAIL_ON_ANY_FINDINGS
)
```

### Type-Safe Policy Builder

For a more type-safe approach, use the `PolicyStatement` builder instead of writing raw Cedar syntax.

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

policy_engine = agentcore.PolicyEngine(self, "MyPolicyEngine",
    policy_engine_name="my_policy_engine"
)

allow_all_policy = agentcore.Policy(self, "AllowAllPolicy",
    policy_engine=policy_engine,
    policy_name="allow_all",
    statement=agentcore.PolicyStatement.permit().for_all_principals().on_all_actions().on_resource("AgentCore::Gateway", gateway.gateway_arn),
    description="Allow all actions on specific gateway (development only)",
    validation_mode=agentcore.PolicyValidationMode.IGNORE_ALL_FINDINGS
)
```

#### Policy with Specific Actions

```python
# policy_engine: agentcore.PolicyEngine
# gateway: agentcore.Gateway


# Allow specific tool actions on specific gateway
# Action names follow pattern: "ToolName__operation"
policy_engine.add_policy("SpecificToolPolicy",
    statement=agentcore.PolicyStatement.permit().for_principal("AgentCore::OAuthUser::your-client-id").on_actions(["AgentCore::Action::WeatherTool__get_forecast", "AgentCore::Action::WeatherTool__get_current"
    ]).on_resource("AgentCore::Gateway", gateway.gateway_arn),
    description="Allow specific weather tool operations",
    validation_mode=agentcore.PolicyValidationMode.FAIL_ON_ANY_FINDINGS
)
```

#### Policy with Conditions

Use `when` clauses to add advanced conditions based on principal tags (from OAuth token) or context:

```python
# policy_engine: agentcore.PolicyEngine
# gateway: agentcore.Gateway


# Policy with when conditions using principal tags
conditional_policy = agentcore.Policy(self, "ConditionalPolicy",
    policy_engine=policy_engine,
    policy_name="conditional_access",
    statement=agentcore.PolicyStatement.permit().for_principal("AgentCore::OAuthUser").on_all_actions().on_resource("AgentCore::Gateway", gateway.gateway_arn).when().principal_attribute("department").equal_to("Engineering").and().context_attribute("input.priority").equal_to("high").done(),
    description="Allow engineers for high-priority requests",
    validation_mode=agentcore.PolicyValidationMode.FAIL_ON_ANY_FINDINGS
)
```

#### Policy with Exclusions (unless)

Use `unless` clauses to exclude specific conditions from a policy. The policy applies when the `unless` conditions are NOT met:

```python
# policy_engine: agentcore.PolicyEngine
# gateway: agentcore.Gateway


# Allow access unless the user is suspended
policy_with_unless = agentcore.Policy(self, "UnlessPolicy",
    policy_engine=policy_engine,
    policy_name="unless_suspended",
    statement=agentcore.PolicyStatement.permit().for_principal("AgentCore::OAuthUser").on_all_actions().on_resource("AgentCore::Gateway", gateway.gateway_arn).unless().principal_attribute("suspended").equal_to(True).done(),
    description="Allow all actions unless user is suspended",
    validation_mode=agentcore.PolicyValidationMode.FAIL_ON_ANY_FINDINGS
)
```

You can combine `when` and `unless` clauses in the same policy:

```python
# policy_engine: agentcore.PolicyEngine
# gateway: agentcore.Gateway


# Allow engineers unless they are on probation
policy_engine.add_policy("CombinedConditions",
    statement=agentcore.PolicyStatement.permit().for_principal("AgentCore::OAuthUser").on_all_actions().on_resource("AgentCore::Gateway", gateway.gateway_arn).when().principal_attribute("department").equal_to("Engineering").done().unless().principal_attribute("status").equal_to("probation").done(),
    description="Allow engineers unless on probation",
    validation_mode=agentcore.PolicyValidationMode.FAIL_ON_ANY_FINDINGS
)
```

#### Forbid (Deny) Policy

Use `forbid` to explicitly deny access. Forbid policies override permit policies.

```python
# policy_engine: agentcore.PolicyEngine
# gateway: agentcore.Gateway


# Explicitly deny dangerous tool operations
policy_engine.add_policy("DenyDangerous",
    statement=agentcore.PolicyStatement.forbid().for_all_principals().on_action("AgentCore::Action::DeleteTool__delete_all").on_resource("AgentCore::Gateway", gateway.gateway_arn),
    description="Forbid delete_all operation for all users",
    validation_mode=agentcore.PolicyValidationMode.FAIL_ON_ANY_FINDINGS
)
```

#### Raw Cedar for Advanced Cases

For advanced Cedar features not supported by the builder, use raw Cedar strings:

```python
# policy_engine: agentcore.PolicyEngine


# Option 1: Using definition property
advanced_policy = agentcore.Policy(self, "AdvancedPolicy",
    policy_engine=policy_engine,
    definition="permit(principal, action, resource) when { context.custom > 10 };",
    description="Advanced policy with custom Cedar logic"
)

# Option 2: Using fromCedar() with statement property
policy_engine.add_policy("CustomPolicy",
    statement=agentcore.PolicyStatement.from_cedar("forbid(principal, action, resource) when { resource.confidential == true };"),
    description="Custom policy from Cedar string"
)
```

**Note**: You must specify **either** `definition` (raw Cedar string) **or** `statement` (PolicyStatement builder), but not both.

#### Accessing Policies on PolicyEngine

You can access the list of policies added to a PolicyEngine using policyEngine.policies.

### PolicyEngine with KMS Encryption

Encrypt policy data with a custom KMS key.

```python
# Create a custom KMS key
policy_key = kms.Key(self, "PolicyEngineKey",
    enable_key_rotation=True,
    description="KMS key for policy engine encryption"
)

# Create policy engine with encryption
policy_engine = agentcore.PolicyEngine(self, "EncryptedEngine",
    policy_engine_name="encrypted_engine",
    description="Policy engine with KMS encryption",
    kms_key=policy_key
)
```

### Importing Existing PolicyEngine

Import an existing policy engine from its ARN:

```python
imported_engine = agentcore.PolicyEngine.from_policy_engine_attributes(self, "ImportedEngine",
    policy_engine_arn="policy-engine-arn",
    kms_key_arn="kms-arn"
)

# Use the imported engine
policy = agentcore.Policy(self, "PolicyForImportedEngine",
    policy_engine=imported_engine,
    definition="permit(principal, action, resource);"
)
```

### Importing Existing Policy

Import an existing policy from its ARN:

```python
imported_engine = agentcore.PolicyEngine.from_policy_engine_attributes(self, "ImportedEngine",
    policy_engine_arn="policy-engine/my-engine-id"
)

imported_policy = agentcore.Policy.from_policy_attributes(self, "ImportedPolicy",
    policy_arn="my-policy-arn",
    policy_engine=imported_engine
)

# Grant permissions to the imported policy
role = iam.Role(self, "PolicyRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

imported_policy.grant_read(role)
```

### PolicyEngine IAM Permissions

Grant various levels of access to policy engines:

```python
policy_engine = agentcore.PolicyEngine(self, "MyEngine",
    policy_engine_name="my_engine"
)

lambda_role = iam.Role(self, "LambdaRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions
policy_engine.grant_read(lambda_role)

# Grant evaluation permissions
policy_engine.grant_evaluate(lambda_role)
```

## Online Evaluation

The Online Evaluation construct enables continuous monitoring and assessment of your agent's performance using live traffic. It automatically samples agent traces from CloudWatch Logs or Agent Endpoints and applies built-in evaluators to assess quality metrics like helpfulness, correctness, and safety.

### Online Evaluation Properties

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `onlineEvaluationConfigName` | `string` | Yes | The name of the online evaluation configuration. Must start with a letter and can contain a-z, A-Z, 0-9, _ (underscore). Maximum 48 characters |
| `evaluators` | `EvaluatorReference[]` | Yes | The list of built-in evaluators to apply during evaluation. Minimum 1, maximum 10 |
| `dataSource` | `DataSourceConfig` | Yes | The data source configuration specifying where to read agent traces from |
| `executionRole` | `iam.IRole` | No | The IAM role for evaluation. If not provided, a role will be created automatically |
| `description` | `string` | No | Description of the evaluation configuration. Maximum 200 characters |
| `samplingPercentage` | `number` | No | Percentage of traces to sample (0.01-100). Default: 10 |
| `filters` | `FilterConfig[]` | No | Filters to determine which traces to evaluate. Use `FilterValue.string()`, `FilterValue.number()`, or `FilterValue.boolean()` for typed filter values. Maximum 5 |
| `sessionTimeout` | `Duration` | No | Duration of inactivity before a session is considered complete (1-1440 minutes). Default: `Duration.minutes(15)` |
| `tags` | `{ [key: string]: string }` | No | Tags for the evaluation configuration |

### Basic Online Evaluation Creation

Create an online evaluation configuration with built-in evaluators:

```python
evaluation = agentcore.OnlineEvaluationConfig(self, "MyEvaluation",
    online_evaluation_config_name="my_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS),
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.CORRECTNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_cloud_watch_logs(
        log_group_names=["/aws/bedrock-agentcore/my-agent"],
        service_names=["my-agent.default"]
    )
)
```

### Built-in Evaluators

Amazon Bedrock AgentCore provides 13 built-in evaluators that assess different aspects of agent performance:

**Session-Level Evaluators:**

* `GOAL_SUCCESS_RATE` - Evaluates whether the conversation successfully meets the user's goals

**Trace-Level Evaluators:**

* `HELPFULNESS` - How useful and valuable the agent's response is
* `CORRECTNESS` - Whether the information is factually accurate
* `FAITHFULNESS` - Whether the response is faithful to the provided context
* `HARMFULNESS` - Whether the response contains harmful content
* `STEREOTYPING` - Detects content that makes generalizations about individuals or groups
* `REFUSAL` - Whether the agent appropriately refuses harmful requests
* `COHERENCE` - Whether the response is logically coherent
* `RESPONSE_RELEVANCE` - Whether the response appropriately addresses the user's query
* `CONCISENESS` - Whether the response is appropriately concise
* `INSTRUCTION_FOLLOWING` - How well the agent follows system instructions

**Tool Call-Level Evaluators:**

* `TOOL_SELECTION_ACCURACY` - Whether the agent selected the appropriate tool
* `TOOL_PARAMETER_ACCURACY` - How accurately the agent extracts parameters from user queries

```python
evaluation = agentcore.OnlineEvaluationConfig(self, "ComprehensiveEval",
    online_evaluation_config_name="comprehensive_evaluation",
    evaluators=[
        # Session level
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.GOAL_SUCCESS_RATE),
        # Trace level - quality
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS),
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.CORRECTNESS),
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.COHERENCE),
        # Trace level - safety
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HARMFULNESS),
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.STEREOTYPING),
        # Tool call level
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.TOOL_SELECTION_ACCURACY)
    ],
    data_source=agentcore.DataSourceConfig.from_cloud_watch_logs(
        log_group_names=["/aws/bedrock-agentcore/my-agent"],
        service_names=["my-agent.default"]
    )
)
```

### Custom Evaluators

Custom evaluators let you define evaluation logic tailored to your specific use cases. You can create custom evaluators using two strategies:

* **LLM-as-a-Judge**: Uses a foundation model with custom instructions and a rating scale to assess agent performance.
* **Code-based**: Uses a Lambda function for custom evaluation logic.

| Property | Type | Required | Description |
|---|---|---|---|
| `evaluatorName` | `string` | Yes | Name of the evaluator. Must start with a letter, a-z, A-Z, 0-9, _ only. Maximum 48 characters |
| `evaluatorConfig` | `EvaluatorConfig` | Yes | Configuration defining how the evaluator assesses performance |
| `level` | `EvaluationLevel` | Yes | The level at which the evaluator operates: `TOOL_CALL`, `TRACE`, or `SESSION` |
| `description` | `string` | No | Description of the evaluator. Maximum 200 characters |

#### LLM-as-a-Judge Evaluator

Create a custom evaluator that uses a foundation model to assess agent performance:

```python
# LLM-as-a-Judge with categorical rating scale
categorical_evaluator = agentcore.Evaluator(self, "CategoricalEvaluator",
    evaluator_name="domain_accuracy_evaluator",
    level=agentcore.EvaluationLevel.SESSION,
    description="Evaluates domain-specific accuracy of agent responses",
    evaluator_config=agentcore.EvaluatorConfig.llm_as_aJudge(
        instructions="Evaluate whether the agent response is accurate within the healthcare domain.",
        model_id="us.anthropic.claude-sonnet-4-6",
        rating_scale=agentcore.EvaluatorRatingScale.categorical([label="Accurate", definition="The response contains factually correct healthcare information.", label="Inaccurate", definition="The response contains incorrect or misleading healthcare information."
        ])
    )
)

# LLM-as-a-Judge with numerical rating scale and inference config
numerical_evaluator = agentcore.Evaluator(self, "NumericalEvaluator",
    evaluator_name="response_quality_evaluator",
    level=agentcore.EvaluationLevel.TRACE,
    evaluator_config=agentcore.EvaluatorConfig.llm_as_aJudge(
        instructions="Rate the overall quality of the agent response on a scale of 1 to 5.",
        model_id="us.anthropic.claude-sonnet-4-6",
        rating_scale=agentcore.EvaluatorRatingScale.numerical([label="Poor", definition="Inadequate response.", value=1, label="Below Average", definition="Partially addresses the query.", value=2, label="Average", definition="Adequately addresses the query.", value=3, label="Good", definition="Well-structured and accurate response.", value=4, label="Excellent", definition="Outstanding response exceeding expectations.", value=5
        ]),
        inference_config=agentcore.EvaluatorInferenceConfig(
            max_tokens=1024,
            temperature=0.1
        )
    )
)
```

The `modelId` accepts standard Bedrock model IDs and cross-region inference profile IDs with region prefixes (e.g., `us.`, `eu.`, `global.`).

> **Instructions placeholders:** Instructions must contain placeholders appropriate for the evaluation level (e.g., `{context}`, `{available_tools}` for SESSION level). Evaluators using reference-input placeholders (e.g., `{expected_tool_trajectory}`, `{assertions}`) are only compatible with on-demand evaluation, not online evaluation. See the [custom evaluators documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/custom-evaluators.html) for allowed placeholders per level.

#### Code-Based Evaluator

Create a custom evaluator that uses a Lambda function for evaluation logic:

```python
# eval_function: lambda.IFunction


code_evaluator = agentcore.Evaluator(self, "CodeEvaluator",
    evaluator_name="custom_code_evaluator",
    level=agentcore.EvaluationLevel.TOOL_CALL,
    description="Evaluates tool call accuracy using custom logic",
    evaluator_config=agentcore.EvaluatorConfig.code_based(
        lambda_function=eval_function,
        timeout=cdk.Duration.seconds(30)
    )
)
```

For code-based evaluators, the construct automatically grants the `bedrock-agentcore.amazonaws.com` service principal permission to invoke the Lambda function, scoped to the specific evaluator resource with `aws:SourceAccount` and `aws:SourceArn` conditions for confused deputy prevention.

#### Using Custom Evaluators with Online Evaluation

Custom evaluators are used in `OnlineEvaluationConfig` via `EvaluatorReference.custom()`, alongside built-in evaluators:

```python
# custom_evaluator: agentcore.Evaluator


evaluation = agentcore.OnlineEvaluationConfig(self, "MixedEvaluation",
    online_evaluation_config_name="mixed_evaluation",
    evaluators=[
        # Built-in evaluators
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS),
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.CORRECTNESS),
        # Custom evaluator
        agentcore.EvaluatorReference.custom(custom_evaluator)
    ],
    data_source=agentcore.DataSourceConfig.from_cloud_watch_logs(
        log_group_names=["/aws/bedrock-agentcore/my-agent"],
        service_names=["my-agent.default"]
    )
)
```

### Data Source Configuration

Online evaluation supports two types of data sources:

**AgentCore Runtime Data Source (Recommended):**

For runtimes created within your CDK app, use `fromAgentRuntimeEndpoint()` which automatically derives the CloudWatch log group and service name:

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

runtime = agentcore.Runtime(self, "MyRuntime",
    runtime_name="my_agent",
    agent_runtime_artifact=agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")
)

# Using default endpoint (simplest)
evaluation = agentcore.OnlineEvaluationConfig(self, "RuntimeEval",
    online_evaluation_config_name="runtime_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_agent_runtime_endpoint(runtime)
)
```

You can also specify a specific endpoint:

```python
# runtime: agentcore.Runtime


# Using a specific endpoint construct
prod_endpoint = runtime.add_endpoint("PROD")
evaluation = agentcore.OnlineEvaluationConfig(self, "ProdEval",
    online_evaluation_config_name="prod_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.CORRECTNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_agent_runtime_endpoint(runtime, prod_endpoint)
)

# Or using endpoint name as string
staging_eval = agentcore.OnlineEvaluationConfig(self, "StagingEval",
    online_evaluation_config_name="staging_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.CORRECTNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_agent_runtime_endpoint_name(runtime, "STAGING")
)
```

**CloudWatch Logs Data Source:**

For external agents or when you need to specify log groups directly:

```python
evaluation = agentcore.OnlineEvaluationConfig(self, "CloudWatchEval",
    online_evaluation_config_name="cloudwatch_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_cloud_watch_logs(
        log_group_names=["/aws/bedrock-agentcore/agent1", "/aws/bedrock-agentcore/agent2"
        ],
        service_names=["agent1.default"]
    )
)
```

### Sampling and Filtering

Configure sampling percentage and filters to control which traces are evaluated:

```python
evaluation = agentcore.OnlineEvaluationConfig(self, "FilteredEval",
    online_evaluation_config_name="filtered_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_cloud_watch_logs(
        log_group_names=["/aws/bedrock-agentcore/my-agent"],
        service_names=["my-agent.default"]
    ),
    # Sample 25% of traces
    sampling_percentage=25,
    # Only evaluate traces matching these filters
    filters=[agentcore.FilterConfig(
        key="user.region",
        operator=agentcore.FilterOperator.EQUAL,
        value=agentcore.FilterValue.string("us-east-1")
    ), agentcore.FilterConfig(
        key="session.duration",
        operator=agentcore.FilterOperator.GREATER_THAN,
        value=agentcore.FilterValue.number(60)
    )
    ],
    # Consider sessions complete after 30 minutes of inactivity
    session_timeout=cdk.Duration.minutes(30)
)
```

### Online Evaluation with Custom Execution Role

Provide a custom IAM role for the evaluation execution:

```python
execution_role = iam.Role(self, "EvaluationRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    description="Custom role for online evaluation"
)

# Add required permissions
execution_role.add_to_policy(iam.PolicyStatement(
    actions=["logs:DescribeLogGroups", "logs:GetQueryResults", "logs:StartQuery"
    ],
    resources=["arn:aws:logs:*:*:log-group:/aws/bedrock-agentcore/*"]
))

evaluation = agentcore.OnlineEvaluationConfig(self, "CustomRoleEval",
    online_evaluation_config_name="custom_role_evaluation",
    evaluators=[
        agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS)
    ],
    data_source=agentcore.DataSourceConfig.from_cloud_watch_logs(
        log_group_names=["/aws/bedrock-agentcore/my-agent"],
        service_names=["my-agent.default"]
    ),
    execution_role=execution_role
)
```

### Online Evaluation IAM Permissions

Grant IAM permissions to manage or read evaluation configurations:

```python
# evaluation: agentcore.OnlineEvaluationConfig
# role: iam.IRole


# Grant specific permissions
evaluation.grant(role, "bedrock-agentcore:GetOnlineEvaluationConfig", "bedrock-agentcore:UpdateOnlineEvaluationConfig")
```
