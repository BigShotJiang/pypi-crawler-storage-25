"""
Tests for cli module
"""

from types import SimpleNamespace

import pytest
from context import mtr2mqtt
from mtr2mqtt import cli


def test_parser_with_mqtt_server_option_without_value():
    """
    Without a specified mqtt server the parser will exit.
    """
    with pytest.raises(SystemExit):
        parser = cli.create_parser()
        parser.parse_args(["--mqtt-host"])


def test_parser_with_mqtt_server():
    """
    The parser will not exit if it receives mqtt option and value
    """
    parser = cli.create_parser()
    args = parser.parse_args(["--mqtt-host", "localhost"])

    assert args.mqtt_host == "localhost"


def test_parser_defaults_without_arguments(monkeypatch):
    """
    Parser uses the built-in defaults when environment variables are not set.
    """
    monkeypatch.delenv("MTR2MQTT_SERIAL_PORT", raising=False)
    monkeypatch.delenv("MTR2MQTT_BAUDRATE", raising=False)
    monkeypatch.delenv("MTR2MQTT_SERIAL_TIMEOUT", raising=False)
    monkeypatch.delenv("MTR2MQTT_OFFLINE_TIMEOUT", raising=False)
    monkeypatch.delenv("MTR2MQTT_SUMMARY_DEBOUNCE_SECONDS", raising=False)
    monkeypatch.delenv("MTR2MQTT_SCL_ADDRESS", raising=False)
    monkeypatch.delenv("MTR2MQTT_MQTT_HOST", raising=False)
    monkeypatch.delenv("MTR2MQTT_MQTT_PORT", raising=False)
    monkeypatch.delenv("MTR2MQTT_METADATA_FILE", raising=False)
    monkeypatch.delenv("MTR2MQTT_OUTPUT", raising=False)
    monkeypatch.delenv("MTR2MQTT_HA_DISCOVERY", raising=False)
    monkeypatch.delenv("MTR2MQTT_HA_DISCOVERY_PREFIX", raising=False)
    monkeypatch.delenv("MTR2MQTT_HA_DISCOVERY_RETAIN", raising=False)
    monkeypatch.delenv("MTR2MQTT_HA_DISCOVERY_NODE_ID", raising=False)
    monkeypatch.delenv("MTR2MQTT_DEBUG", raising=False)
    monkeypatch.delenv("MTR2MQTT_QUIET", raising=False)

    parser = cli.create_parser()
    args = parser.parse_args([])

    assert args.serial_port is None
    assert args.baudrate == 9600
    assert args.serial_timeout == 1
    assert args.offline_timeout == 1800
    assert args.summary_debounce_seconds == 5
    assert args.scl_address == 126
    assert args.mqtt_host is None
    assert args.mqtt_port == 1883
    assert args.metadata_file is None
    assert args.output == "json"
    assert args.ha_discovery is False
    assert args.ha_discovery_prefix == "homeassistant"
    assert args.ha_discovery_retain is True
    assert args.ha_discovery_node_id is None
    assert args.debug is False
    assert args.quiet is False
    assert args.version is False


def test_parser_reads_environment_defaults(monkeypatch):
    """
    Parser uses supported environment variables as defaults.
    """
    monkeypatch.setenv("MTR2MQTT_SERIAL_PORT", "/dev/ttyUSB0")
    monkeypatch.setenv("MTR2MQTT_BAUDRATE", "115200")
    monkeypatch.setenv("MTR2MQTT_SERIAL_TIMEOUT", "5")
    monkeypatch.setenv("MTR2MQTT_OFFLINE_TIMEOUT", "120")
    monkeypatch.setenv("MTR2MQTT_SUMMARY_DEBOUNCE_SECONDS", "7")
    monkeypatch.setenv("MTR2MQTT_SCL_ADDRESS", "1")
    monkeypatch.setenv("MTR2MQTT_MQTT_HOST", "mqtt.example")
    monkeypatch.setenv("MTR2MQTT_MQTT_PORT", "1884")
    monkeypatch.setenv("MTR2MQTT_METADATA_FILE", "tests/metadata.yml")
    monkeypatch.setenv("MTR2MQTT_OUTPUT", "table")
    monkeypatch.setenv("MTR2MQTT_HA_DISCOVERY", "true")
    monkeypatch.setenv("MTR2MQTT_HA_DISCOVERY_PREFIX", "ha")
    monkeypatch.setenv("MTR2MQTT_HA_DISCOVERY_RETAIN", "false")
    monkeypatch.setenv("MTR2MQTT_HA_DISCOVERY_NODE_ID", "bridge-1")
    monkeypatch.setenv("MTR2MQTT_DEBUG", "true")
    monkeypatch.delenv("MTR2MQTT_QUIET", raising=False)

    parser = cli.create_parser()
    args = parser.parse_args([])

    assert args.serial_port == "/dev/ttyUSB0"
    assert args.baudrate == 115200
    assert args.serial_timeout == 5
    assert args.offline_timeout == 120
    assert args.summary_debounce_seconds == 7
    assert args.scl_address == 1
    assert args.mqtt_host == "mqtt.example"
    assert args.mqtt_port == 1884
    assert args.metadata_file == "tests/metadata.yml"
    assert args.output == "table"
    assert args.ha_discovery is True
    assert args.ha_discovery_prefix == "ha"
    assert args.ha_discovery_retain is False
    assert args.ha_discovery_node_id == "bridge-1"
    assert args.debug is True
    assert args.quiet is False


def test_parser_rejects_invalid_integer_environment_default(monkeypatch):
    """
    Invalid integer environment defaults raise a clear configuration error.
    """
    monkeypatch.setenv("MTR2MQTT_MQTT_PORT", "abc")

    with pytest.raises(cli.CliConfigurationError):
        cli.create_parser()


def test_parser_debug_flag_enables_debug():
    """
    The debug flag is parsed as a boolean store_true option.
    """
    parser = cli.create_parser()
    args = parser.parse_args(["--debug"])

    assert args.debug is True
    assert args.quiet is False
    assert args.version is False


def test_parser_quiet_flag_enables_quiet():
    """
    The quiet flag is parsed as a boolean store_true option.
    """
    parser = cli.create_parser()
    args = parser.parse_args(["--quiet"])

    assert args.quiet is True
    assert args.debug is False
    assert args.version is False


def test_parser_home_assistant_flags():
    """
    The parser accepts Home Assistant discovery options.
    """
    parser = cli.create_parser()
    args = parser.parse_args(
        [
            "--ha-discovery",
            "--ha-discovery-prefix",
            "ha",
            "--no-ha-discovery-retain",
            "--ha-discovery-node-id",
            "bridge-1",
        ]
    )

    assert args.ha_discovery is True
    assert args.ha_discovery_prefix == "ha"
    assert args.ha_discovery_retain is False
    assert args.ha_discovery_node_id == "bridge-1"


def test_parser_rejects_debug_and_quiet_together():
    """
    Mutually exclusive debug and quiet flags cannot be used together.
    """
    parser = cli.create_parser()

    with pytest.raises(SystemExit):
        parser.parse_args(["--debug", "--quiet"])


def test_parser_parses_common_options():
    """
    The parser accepts common numeric and file options.
    """
    parser = cli.create_parser()
    args = parser.parse_args(
        [
            "--mqtt-host",
            "localhost",
            "--mqtt-port",
            "1885",
            "--baudrate",
            "115200",
            "--serial-timeout",
            "2",
            "--scl-address",
            "0",
            "--metadata-file",
            "tests/metadata.yml",
            "--output",
            "table",
        ]
    )

    assert args.mqtt_host == "localhost"
    assert args.mqtt_port == 1885
    assert args.baudrate == 115200
    assert args.serial_timeout == 2
    assert args.scl_address == 0
    assert args.metadata_file == "tests/metadata.yml"
    assert args.output == "table"


def test_parser_rejects_invalid_scl_address():
    """
    The parser rejects unsupported SCL addresses.
    """
    parser = cli.create_parser()

    with pytest.raises(SystemExit):
        parser.parse_args(["--scl-address", "124"])


def test_create_discovery_publisher_returns_none_when_disabled():
    """
    Discovery publisher creation is skipped unless discovery is enabled.
    """
    args = SimpleNamespace(
        ha_discovery=False,
        ha_discovery_prefix="homeassistant",
        ha_discovery_retain=True,
        ha_discovery_node_id=None,
    )

    assert cli.create_discovery_publisher(args) is None


def test_create_discovery_publisher_uses_cli_configuration():
    """
    Discovery publisher creation preserves the configured prefix, retain, and node id.
    """
    args = SimpleNamespace(
        ha_discovery=True,
        ha_discovery_prefix="ha",
        ha_discovery_retain=False,
        ha_discovery_node_id="bridge-1",
    )

    publisher = cli.create_discovery_publisher(args)

    assert publisher.discovery_prefix == "ha"
    assert publisher.retain is False
    assert publisher.node_id == "bridge-1"


def test_main_exits_cleanly_when_runtime_startup_fails(monkeypatch):
    """
    CLI owns process exit behavior for runtime startup failures.
    """
    args = SimpleNamespace(version=False)
    captured = {}

    class FakeBridge:
        def __init__(self, *_args, **_kwargs):
            return None

        def run_forever(self):
            raise cli.BridgeError("startup failed")

    monkeypatch.setattr(
        cli,
        "create_parser",
        lambda: SimpleNamespace(parse_args=lambda: args),
    )
    monkeypatch.setattr(cli, "configure_logging", lambda _args: None)
    monkeypatch.setattr(cli, "load_metadata", lambda _args: None)
    monkeypatch.setattr(cli, "create_discovery_publisher", lambda _args: None)
    monkeypatch.setattr(cli, "MtrBridge", FakeBridge)
    monkeypatch.setattr(
        cli.logging,
        "fatal",
        lambda message: captured.setdefault("fatal", message),
    )

    with pytest.raises(SystemExit) as error:
        cli.main()

    assert error.value.code == -1
    assert captured["fatal"] == "startup failed"


def test_main_exits_cleanly_when_environment_defaults_are_invalid(monkeypatch, capsys):
    """
    CLI reports invalid environment defaults without a traceback.
    """
    monkeypatch.setenv("MTR2MQTT_MQTT_PORT", "abc")

    with pytest.raises(SystemExit) as error:
        cli.main()

    assert error.value.code == -1
    assert "MTR2MQTT_MQTT_PORT must be an integer" in capsys.readouterr().err
