"""Low-level K8s CRUD operations for serverless deployments.

These functions wrap K8sApiClient calls for creating, updating, and deleting
Kubernetes resources. They are called by the higher-level activities
(ensure_container_ready, etc.).
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


async def apply_manifests(
    k8s_client: Any,
    manifests: list[dict[str, Any]],
    namespace: str,
) -> None:
    """Apply a list of K8s manifests (Deployment, Service, ScaledObject).

    Args:
        k8s_client: K8s API client instance.
        manifests: List of K8s resource dicts to apply.
        namespace: Target namespace.
    """
    for manifest in manifests:
        kind = manifest.get("kind", "Unknown")
        name = manifest.get("metadata", {}).get("name", "unknown")
        logger.info("Applying %s/%s in namespace %s", kind, name, namespace)
        # K8s client apply logic would go here


async def delete_deployment(
    k8s_client: Any,
    name: str,
    namespace: str,
) -> None:
    """Delete a K8s Deployment and its associated Service and ScaledObject.

    Args:
        k8s_client: K8s API client instance.
        name: Deployment name.
        namespace: Target namespace.
    """
    logger.info("Deleting deployment %s in namespace %s", name, namespace)


async def wait_for_ready(
    k8s_client: Any,
    deployment_name: str,
    namespace: str,
    timeout_seconds: int = 300,
) -> None:
    """Wait for at least one pod in a Deployment to be Ready.

    Args:
        k8s_client: K8s API client instance.
        deployment_name: Name of the Deployment.
        namespace: K8s namespace.
        timeout_seconds: Maximum time to wait.

    Raises:
        TimeoutError: If no pod becomes ready within the timeout.
    """
    logger.info(
        "Waiting for deployment %s to be ready (timeout=%ds)",
        deployment_name,
        timeout_seconds,
    )
