"""Request dispatch activities for Temporal workflows.

Send serialized function arguments to container endpoints via HTTP
and return serialized results.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
        DispatchInput,
    )

try:
    from temporalio import activity
except ImportError:
    activity = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


async def _dispatch_request(input: DispatchInput) -> bytes:
    """Send serialized args to container endpoint, return serialized result.

    Makes an HTTP POST to the container's /invoke endpoint with the
    serialized function arguments. The container deserializes, executes,
    and returns the serialized result.

    Args:
        input: Dispatch configuration including endpoint URL, function name,
            serialized args, and timeout.

    Returns:
        Serialized function result as bytes.

    Raises:
        httpx.HTTPStatusError: If the container returns a non-2xx response.
        httpx.TimeoutException: If the request times out.
    """
    import httpx

    headers: dict[str, str] = {
        "X-Flow-Function": input.function_name,
        "Content-Type": "application/octet-stream",
    }
    if input.method:
        headers["X-Flow-Method"] = input.method

    async with httpx.AsyncClient(timeout=input.timeout_seconds) as client:
        response = await client.post(
            f"{input.endpoint}/invoke",
            content=input.args_serialized,
            headers=headers,
        )
        response.raise_for_status()
        return response.content


async def _dispatch_batch(
    endpoint: str,
    function_name: str,
    method: str,
    batch_serialized: bytes,
    batch_size: int,
    timeout_seconds: int = 3600,
) -> bytes:
    """Send a batch of inputs to a container for dynamic batching.

    Args:
        endpoint: Container service endpoint URL.
        function_name: Function name for routing.
        method: Method name for class-based functions.
        batch_serialized: Serialized batch of inputs.
        batch_size: Number of items in the batch.
        timeout_seconds: Request timeout.

    Returns:
        Serialized batch of results.
    """
    import httpx

    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        response = await client.post(
            f"{endpoint}/invoke_batch",
            content=batch_serialized,
            headers={
                "X-Flow-Function": function_name,
                "X-Flow-Method": method,
                "X-Flow-Batch-Size": str(batch_size),
                "Content-Type": "application/octet-stream",
            },
        )
        response.raise_for_status()
        return response.content


if activity is not None:
    dispatch_request = activity.defn(_dispatch_request)
    dispatch_batch = activity.defn(_dispatch_batch)
else:
    dispatch_request = _dispatch_request  # type: ignore[assignment]
    dispatch_batch = _dispatch_batch  # type: ignore[assignment]
