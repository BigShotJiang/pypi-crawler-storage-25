"""Hand-written Kubernetes cluster API client.

Replaces the auto-generated bindings (13K lines) with the three API calls
actually used by the codebase: list clusters, get cluster, list SSH keys.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

import httpx

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class KubernetesClusterStatus(str, Enum):
    AVAILABLE = "Available"
    PENDING = "Pending"
    TERMINATED = "Terminated"

    def __str__(self) -> str:
        return str(self.value)


@dataclass(frozen=True)
class KubernetesCluster:
    """Kubernetes cluster as returned by the Mithril API."""

    fid: str
    project: str
    name: str
    region: str
    created_at: str
    kube_host: str | None
    ssh_keys: list[str]
    instances: list[str]
    join_command: str | None
    status: KubernetesClusterStatus
    deleted_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "fid": self.fid,
            "project": self.project,
            "name": self.name,
            "region": self.region,
            "created_at": self.created_at,
            "kube_host": self.kube_host,
            "ssh_keys": self.ssh_keys,
            "instances": self.instances,
            "join_command": self.join_command,
            "status": self.status.value,
        }
        if self.deleted_at is not None:
            result["deleted_at"] = self.deleted_at
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> KubernetesCluster:
        return cls(
            fid=data["fid"],
            project=data["project"],
            name=data["name"],
            region=data["region"],
            created_at=data["created_at"],
            kube_host=data.get("kube_host"),
            ssh_keys=data.get("ssh_keys", []),
            instances=data.get("instances", []),
            join_command=data.get("join_command"),
            status=KubernetesClusterStatus(data["status"]),
            deleted_at=data.get("deleted_at"),
        )


@dataclass(frozen=True)
class SshKey:
    """SSH key as returned by the Mithril API."""

    fid: str
    name: str
    project: str
    public_key: str
    created_at: str
    required: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SshKey:
        return cls(
            fid=data["fid"],
            name=data["name"],
            project=data["project"],
            public_key=data["public_key"],
            created_at=data["created_at"],
            required=data.get("required", False),
        )


@dataclass(frozen=True)
class ValidationErrorDetail:
    """Single validation error entry from a 422 response."""

    loc: list[str]
    msg: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ValidationErrorDetail:
        return cls(loc=data.get("loc", []), msg=data.get("msg", ""))


class K8sApiError(Exception):
    """Raised when the Mithril K8s API returns an error."""

    def __init__(self, message: str, details: list[ValidationErrorDetail] | None = None):
        super().__init__(message)
        self.details = details or []


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


@dataclass
class K8sApiClient:
    """Minimal HTTP client for the Mithril Kubernetes and SSH key APIs.

    Provides both synchronous and asynchronous methods. Uses httpx directly
    with Bearer token authentication.
    """

    base_url: str
    token: str

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.token}"}

    def _handle_error(self, response: httpx.Response) -> None:
        if response.status_code == 422:
            body = response.json()
            raw_detail = body.get("detail", [])
            if isinstance(raw_detail, list):
                details = [ValidationErrorDetail.from_dict(d) for d in raw_detail]
                msgs = [f"{d.loc}: {d.msg}" for d in details]
            else:
                details = []
                msgs = [str(raw_detail)]
            raise K8sApiError(
                f"Validation error: {', '.join(msgs)}" if msgs else "Validation error from API",
                details=details,
            )
        response.raise_for_status()

    # -- Synchronous methods (used by context.py) ---------------------------

    def list_clusters_sync(self, project: str) -> list[KubernetesCluster]:
        """List all Kubernetes clusters for a project (synchronous)."""
        url = f"{self.base_url}/v2/kubernetes_clusters"
        with httpx.Client(timeout=_DEFAULT_TIMEOUT) as client:
            resp = client.get(url, headers=self._headers(), params={"project": project})
        self._handle_error(resp)
        return [KubernetesCluster.from_dict(item) for item in resp.json()]

    # -- Async methods (used by k8s/impl.py) --------------------------------

    async def list_clusters(self, project: str) -> list[KubernetesCluster]:
        """List all Kubernetes clusters for a project."""
        url = f"{self.base_url}/v2/kubernetes_clusters"
        async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT) as client:
            resp = await client.get(url, headers=self._headers(), params={"project": project})
        self._handle_error(resp)
        return [KubernetesCluster.from_dict(item) for item in resp.json()]

    async def get_cluster(self, cluster_fid: str) -> KubernetesCluster:
        """Get a single Kubernetes cluster by FID."""
        url = f"{self.base_url}/v2/kubernetes_clusters/{cluster_fid}"
        async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT) as client:
            resp = await client.get(url, headers=self._headers())
        self._handle_error(resp)
        return KubernetesCluster.from_dict(resp.json())

    async def list_ssh_keys(self, project: str) -> list[SshKey]:
        """List SSH keys for a project."""
        url = f"{self.base_url}/v2/ssh_keys"
        async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT) as client:
            resp = await client.get(url, headers=self._headers(), params={"project": project})
        self._handle_error(resp)
        return [SshKey.from_dict(item) for item in resp.json()]
