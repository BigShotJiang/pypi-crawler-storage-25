"""Pricing visibility command.

Summary-first views for:
- Market stats with 7d range and trend
- Billing price estimates (P50/P90/P95 heuristics)
- Runtime estimates at various limit prices (from 7d history)

Details are opt-in via flags; default output stays concise and actionable.
"""

import dataclasses
import json
import re
import ssl
from collections import defaultdict
from contextlib import nullcontext
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib import request as urlreq
from urllib.parse import urlencode, urljoin

import click

from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel
from flow.cli.utils.error_handling import cli_error_guard, render_auth_required_message
from flow.cli.utils.json_output import error_json, print_json
from flow.cli.utils.telemetry import Telemetry
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.domain.pricing.insights import (
    PriceTrend,
    _compute_durations,
    _parse_iso_timestamp,
    _weighted_percentile,
    aggregate_market_by_size,
    compute_market_summary,
    compute_price_trend,
    derive_recommendations_by_size,
    estimate_uptime,
    plan_by_budget,
    plan_by_runtime,
    suggest_limit_prices,
)
from flow.errors import AuthenticationError
from flow.utils.links import DocsLinks, WebLinks
from flow.utils.parsing import parse_cost_string

# GPUs to display by default when no --gpu filter is provided (in priority order)
PREFERRED_GPUS = ("b200", "h200", "h100", "a100")


# ---------- Mithril API helpers for price history ----------


def _resolve_api_context() -> tuple[str, str | None, str | None]:
    """Resolve Mithril API base URL, API key, and project from env/config."""
    import os

    api_base = os.getenv("MITHRIL_API_URL", "https://api.mithril.ai").rstrip("/") + "/"
    api_key = os.getenv("MITHRIL_API_KEY")
    project = os.getenv("MITHRIL_PROJECT_ID") or os.getenv("MITHRIL_PROJECT")

    if not api_key or not project:
        try:
            from flow.application.config.config import Config as _Cfg

            cfg = _Cfg.from_env(require_auth=False)
            if not api_key:
                api_key = cfg.auth_token or api_key
            if not project:
                project = (cfg.provider_config or {}).get("project") or project
            api_base = ((cfg.provider_config or {}).get("api_url") or api_base).rstrip("/") + "/"
        except Exception:  # noqa: BLE001
            pass

    return api_base, api_key, project


def _api_get_json(api_base: str, api_key: str | None, path: str, params: dict | None = None) -> Any:
    """HTTP GET against Mithril API, returns parsed JSON."""
    qs = f"?{urlencode(params)}" if params else ""
    url = urljoin(api_base, path.lstrip("/")) + qs
    headers: dict[str, str] = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urlreq.Request(url, headers=headers, method="GET")
    ctx = ssl.create_default_context()
    with urlreq.urlopen(req, context=ctx, timeout=15) as resp:
        data = resp.read()
        return json.loads(data.decode("utf-8"))


def _fetch_instance_type_map(api_base: str, api_key: str | None) -> dict[str, tuple[str, int, str]]:
    """Fetch instance types. Returns {fid: (display_name, gpu_count, gpu_type)}."""
    result: dict[str, tuple[str, int, str]] = {}
    itypes = _api_get_json(api_base, api_key, "/v2/instance-types")
    if not isinstance(itypes, list):
        return result

    for it in itypes:
        try:
            fid = it.get("fid") or it.get("id")
            name = it.get("name") or fid
            gpu_count = 0
            gpu_type = ""

            # Try new format first
            if it.get("gpu_type"):
                gpu_type = extract_gpu_info(str(it["gpu_type"]))[0]
                gpu_count = int(it.get("num_gpus") or 0)

            # Fallback to legacy gpus array
            if not gpu_type:
                for g in it.get("gpus", []) or []:
                    try:
                        gpu_count += int(g.get("count", 0) or 0)
                        if not gpu_type:
                            detected = extract_gpu_info(str(g.get("name") or ""))[0]
                            if detected != "default":
                                gpu_type = detected
                    except Exception:  # noqa: BLE001
                        continue

            if not gpu_type:
                gpu_type = extract_gpu_info(str(name))[0]

            if fid:
                result[str(fid)] = (str(name), gpu_count or 0, gpu_type)
        except Exception:  # noqa: BLE001
            continue

    return result


def _fetch_price_history(
    api_base: str,
    api_key: str | None,
    fid_map: dict[str, tuple[str, int, str]],
    gpu_filter: str | None,
    region_filter: str | None,
    target_regions: list[str] | None = None,
) -> dict[tuple[str, str, int], dict[str, Any]]:
    """Fetch price history for ALL instance types, keyed by (gpu_type, region, gpu_count).

    Each GPU count tier is a distinct market with its own price dynamics
    (e.g., B200 1x $0.01-$14/GPU vs B200 8x $0.00-$112.50/GPU).
    Returns data for every available tier so callers can display per-config rows.

    Prices are normalized to per-GPU USD/hr.
    """
    # Include ALL FIDs (all GPU counts), not one per GPU type
    fid_to_gpu: dict[str, tuple[str, int]] = {}
    for fid, (_name, gpu_count, gpu_type) in fid_map.items():
        if gpu_filter and gpu_type != gpu_filter.lower():
            continue
        gc = gpu_count if gpu_count > 0 else 8
        fid_to_gpu[fid] = (gpu_type, gc)

    if not fid_to_gpu:
        return {}

    regions_to_query = target_regions or ([region_filter] if region_filter else [None])
    all_fids = ",".join(fid_to_gpu.keys())
    result: dict[tuple[str, str, int], dict[str, Any]] = {}

    for rgn in regions_to_query:
        params: dict[str, Any] = {
            "instance_types": all_fids,
            "num_samples": 720,
        }
        if rgn:
            params["region"] = rgn

        try:
            resp = _api_get_json(api_base, api_key, "/v2/pricing/history", params)
        except Exception:  # noqa: BLE001
            continue

        series_list = resp if isinstance(resp, list) else resp.get("series", [resp])

        for series in series_list:
            raw_prices = series.get("spot_prices", [])
            timestamps = series.get("timestamps", [])
            series_fid = series.get("instance_type") or series.get("instance_type_id", "")
            series_region = series.get("region") or rgn or ""

            if not raw_prices:
                continue

            # Forward-fill (LOCF)
            filled_prices: list[float] = []
            filled_timestamps: list[str] = []
            last_valid: float | None = None
            for p, t in zip(raw_prices, timestamps[:len(raw_prices)], strict=True):
                if p is not None:
                    parsed = parse_cost_string(p, default=-1.0)
                    if parsed > 0:
                        last_valid = parsed
                if last_valid is not None:
                    filled_prices.append(last_valid)
                    filled_timestamps.append(t if isinstance(t, str) else str(t))

            if not filled_prices:
                continue

            # Match series to GPU type via FID
            gpu_type, gpu_count = "", 8
            if series_fid and series_fid in fid_to_gpu:
                gpu_type, gpu_count = fid_to_gpu[series_fid]
            elif len(fid_to_gpu) == 1:
                gpu_type, gpu_count = next(iter(fid_to_gpu.values()))
            else:
                continue

            key = (gpu_type, series_region, gpu_count)
            if key not in result:
                per_gpu_prices = [p / gpu_count for p in filled_prices]
                result[key] = {
                    "spot_prices": per_gpu_prices,
                    "timestamps": filled_timestamps,
                    "gpu_count": gpu_count,
                }

    return result


class PricingCommand(BaseCommand):
    @property
    def name(self) -> str:
        return "pricing"

    @property
    def help(self) -> str:
        return "Show market prices and recommendations"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option("--region", help="Filter market by region (e.g., us-central1-b)")
        @click.option("--gpu", help="Filter to a GPU (e.g., h100, a100)")
        @click.option(
            "--gpu-count", type=int, help="Target GPU count for per-instance limit prices"
        )
        @click.option(
            "--list", "show_list", is_flag=True, help="List raw market instances (verbose)"
        )
        @click.option("--explain", is_flag=True, help="Explain recommendations (verbose)")
        @click.option("--json", "as_json", is_flag=True, help="Output JSON for automation")
        @cli_error_guard(self)
        def pricing(
            region: str | None = None,
            gpu: str | None = None,
            gpu_count: int | None = None,
            show_list: bool = False,
            explain: bool = False,
            as_json: bool = False,
        ):
            """Display market summary (default)."""
            accent = theme_manager.get_color("accent")
            muted = theme_manager.get_color("muted")
            if not as_json:
                try:
                    console.print(f"[bold {accent}]Flow Pricing[/bold {accent}]")
                except Exception:  # noqa: BLE001
                    pass

            # Telemetry (best-effort)
            try:
                Telemetry().log_event(
                    "pricing_view_shown",
                    {
                        "view": "market",
                        "gpu": (gpu or ""),
                        "gpus": (gpu_count or 0),
                        "region": (region or ""),
                    },
                )
            except Exception:  # noqa: BLE001
                pass

            # ---- Rendering helpers ----

            def _momentum_arrow(delta: float | None, threshold: float = 10.0) -> str:
                """Convert a percentage delta to a colored directional arrow.

                From the buyer's perspective: price dropping (↓) is favorable.
                """
                if delta is None:
                    return "[dim]\u00b7[/dim]"
                if delta < -threshold:
                    return "[green]\u2193[/green]"
                if delta > threshold:
                    return "[yellow]\u2191[/yellow]"
                return "[dim]\u2192[/dim]"

            def _render_stats_panel(
                rows: list[dict[str, Any]],
                trends: dict[tuple[str, str], PriceTrend] | None = None,
            ) -> None:
                has_trends = trends and any(
                    trends.get((r.get("gpu", ""), r.get("region", ""), r.get("gpu_count", 8)))
                    for r in rows
                )

                stats_table = create_flow_table(
                    title=None, show_borders=True, padding=1, expand=True
                )
                stats_table.add_column("GPU", style=accent, no_wrap=True)
                stats_table.add_column("Region", style=muted, no_wrap=True)
                stats_table.add_column("Current", justify="right")
                if has_trends:
                    stats_table.add_column("Avg 1d", justify="right")
                    stats_table.add_column("Avg 7d", justify="right")
                    stats_table.add_column("Avg 30d", justify="right")
                    stats_table.add_column("7d Range", justify="right")
                    stats_table.add_column("Pctl", justify="right")
                    stats_table.add_column("Trend", justify="right")

                for r in rows:
                    row_gc = r.get("gpu_count", 8)
                    gpu_label = f"{r.get('gpu', '')} {row_gc}x"
                    row_cells = [
                        gpu_label,
                        r.get("region", ""),
                        r.get("current_fmt", "-"),
                    ]
                    if has_trends:
                        trend_key = (r.get("gpu", ""), r.get("region", ""), row_gc)
                        trend = (trends or {}).get(trend_key)
                        if trend:
                            avg_1d = f"${trend.mean_1d:.2f}"
                            avg_7d = f"${trend.mean_7d:.2f}"
                            avg_30d = f"${trend.mean_30d:.2f}"
                            range_str = f"${trend.min_7d:.2f}-${trend.max_7d:.2f}"
                            pctl_str = f"P{trend.percentile}"
                            arrows = (
                                f"{_momentum_arrow(trend.trend_pct)} "
                                f"{_momentum_arrow(trend.delta_6h)} "
                                f"{_momentum_arrow(trend.delta_1h)}"
                            )
                            row_cells.extend(
                                [avg_1d, avg_7d, avg_30d, range_str, pctl_str, arrows]
                            )
                        else:
                            row_cells.extend(["-", "-", "-", "-", "-", "-"])

                    stats_table.add_row(*row_cells)

                title_suffix = f" \u2022 {region}" if region else ""
                wrap_table_in_panel(stats_table, f"Market Stats{title_suffix}", console)

            def _render_caps_panel(
                rows: list[dict[str, Any]],
                *,
                counts: list[int],
                hist_recs: dict[tuple[str, str, int], float] | None = None,
            ) -> None:
                """Render recommended limit prices per instance.

                hist_recs: optional dict of (gpu, region, gpu_count) → per-GPU
                    historical P90×1.10 from duration-weighted history. Used
                    instead of the current-snapshot P90 when available.
                """
                caps_table = create_flow_table(
                    title=None, show_borders=True, padding=1, expand=True
                )
                caps_table.add_column("GPU", style=accent, no_wrap=True)
                caps_table.add_column("Region", style=muted, no_wrap=True)

                if len(counts) == 1:
                    caps_table.add_column("Limit Price", justify="right", no_wrap=True)
                else:
                    for c in counts:
                        caps_table.add_column(f"{c}x", justify="right", no_wrap=True)

                # Deduplicate rows by (gpu, region) for the caps table
                seen_caps: set[tuple[str, str]] = set()
                for r in rows:
                    dedup_key = (r.get("gpu", ""), r.get("region", ""))
                    if dedup_key in seen_caps:
                        continue
                    seen_caps.add(dedup_key)
                    cap_cells: list[str] = [r.get("gpu", ""), r.get("region", "")]
                    avail_counts = set(r.get("avail_counts", []) or [])
                    for c in counts:
                        # Prefer historical P90 over current-snapshot P90
                        hist_per_gpu = (hist_recs or {}).get(
                            (r.get("gpu", ""), r.get("region", ""), c)
                        )
                        if hist_per_gpu is not None and hist_per_gpu > 0:
                            inst_total = hist_per_gpu * c
                        else:
                            cap_by_count = r.get("cap_med_by_count") or {}
                            per_gpu = cap_by_count.get(c)
                            inst_total = (
                                float(per_gpu) * c
                                if isinstance(per_gpu, int | float)
                                else None
                            )
                        cap_cells.append(
                            f"${inst_total:.2f}"
                            if isinstance(inst_total, int | float)
                            and ((not avail_counts) or (c in avail_counts))
                            else "-"
                        )

                    caps_table.add_row(*cap_cells)

                title_suffix = f" \u2022 {region}" if region else ""
                wrap_table_in_panel(
                    caps_table,
                    f"Recommended Limit Price (per instance){title_suffix}",
                    console,
                )

            def _render_uptime_panel(
                estimates: list[Any],
                target_gpu_count: int,
                gpu_label: str,
            ) -> None:
                table = create_flow_table(title=None, show_borders=True, padding=1, expand=True)
                table.add_column("Limit Price", style=accent, no_wrap=True)
                table.add_column("Win Rate", justify="right", no_wrap=True)
                table.add_column("24h Runtime", justify="right", no_wrap=True)
                table.add_column("48h Runtime", justify="right", no_wrap=True)
                table.add_column("72h Runtime", justify="right", no_wrap=True)
                table.add_column("48h Cost", justify="right", no_wrap=True)

                for est in estimates:
                    table.add_row(
                        f"${est.limit_price:.2f}/GPU",
                        f"~{est.uptime_pct:.0f}%",
                        f"~{est.runtime_24h:.0f}h",
                        f"~{est.runtime_48h:.0f}h",
                        f"~{est.runtime_72h:.0f}h",
                        f"~${est.cost_48h:,.0f}",
                    )

                gpu_suffix = f" \u2022 {gpu_label.upper()} \u2022 {target_gpu_count} GPUs"
                wrap_table_in_panel(
                    table,
                    f"Price Eligibility Estimate (7d history{gpu_suffix})",
                    console,
                )

            # ---- Fetch current market data ----
            def _try_authenticated() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
                import flow.sdk.factory as sdk_factory

                client = sdk_factory.create_client(auto_init=True)
                req: dict[str, Any] = {}
                if region:
                    req["region"] = region
                instances = client.find_instances(req, limit=250)
                raw_rows: list[dict[str, Any]] = []
                for inst in instances:
                    gc = inst.gpu_count or 1
                    per_gpu = (
                        inst.price_per_hour / gc
                        if isinstance(inst.price_per_hour, int | float) and gc > 0
                        else inst.price_per_hour
                    )
                    raw_rows.append(
                        {
                            "region": inst.region,
                            "gpu_type": (inst.gpu_type or "")
                            or extract_gpu_info(inst.instance_type)[0],
                            "gpu_count": gc,
                            "price_per_hour": per_gpu,
                            "instance_type": inst.instance_type,
                            "available_quantity": inst.available_quantity,
                        }
                    )
                return raw_rows, raw_rows

            def _try_public() -> list[dict[str, Any]]:
                """Fetch market data via public endpoints using stdlib HTTP."""
                nonlocal cached_fid_map, cached_api_ctx
                from flow.cli.utils.parsing import parse_price as _parse_price

                api_base, api_key, project = _resolve_api_context()
                cached_api_ctx = (api_base, api_key)

                fid_map = _fetch_instance_type_map(api_base, api_key)
                cached_fid_map = fid_map
                id_to_name = {fid: info[0] for fid, info in fid_map.items()}
                id_to_gpus = {fid: info[1] for fid, info in fid_map.items()}
                id_to_gpu_type = {fid: info[2] for fid, info in fid_map.items()}

                params: dict[str, Any] = {"limit": 100}
                if region:
                    params["region"] = region
                if project:
                    params["project"] = project
                avail = _api_get_json(api_base, api_key, "/v2/spot/availability", params)
                if not isinstance(avail, list):
                    avail = []

                rows: list[dict[str, Any]] = []

                def _parse_gpus_from_name(name: str) -> int:
                    m = re.search(r"(\d+)x\b", str(name))
                    if m:
                        val = int(m.group(1))
                        return val if val > 0 else 0
                    return 0

                for a in avail:
                    try:
                        rgn = str(a.get("region", "") or "")
                        it_id = str(
                            a.get("instance_type")
                            or a.get("instanceType")
                            or a.get("instanceTypeId")
                            or ""
                        )
                        price_str = (
                            a.get("last_instance_price")
                            or a.get("current_price")
                            or a.get("price_per_hour")
                            or a.get("price")
                            or None
                        )
                        price = 0.0
                        if isinstance(price_str, int | float):
                            price = float(price_str)
                        elif isinstance(price_str, str):
                            price = _parse_price(price_str)

                        gpus = int(
                            a.get("gpu_count")
                            or a.get("gpus")
                            or id_to_gpus.get(it_id, 0)
                            or _parse_gpus_from_name(id_to_name.get(it_id, ""))
                            or _parse_gpus_from_name(it_id)
                            or 0
                        )
                        avail_count = None
                        for key in (
                            "available_quantity",
                            "available_count",
                            "capacity",
                            "quantity",
                        ):
                            v = a.get(key)
                            if isinstance(v, int | float):
                                avail_count = int(v)
                                break

                        per_gpu_price = (price / gpus) if (gpus and price) else 0.0

                        rows.append(
                            {
                                "region": rgn,
                                "gpu_type": id_to_gpu_type.get(it_id, extract_gpu_info(it_id)[0]),
                                "gpu_count": gpus or None,
                                "price_per_hour": per_gpu_price or price,
                                "instance_type": id_to_name.get(it_id, it_id),
                                "available_quantity": avail_count,
                            }
                        )
                    except Exception:  # noqa: BLE001
                        continue

                return rows

            raw_rows: list[dict[str, Any]] = []
            cached_fid_map: dict[str, tuple[str, int, str]] | None = None
            cached_api_ctx: tuple[str, str | None] | None = None
            auth_error: Exception | None = None
            public_error: Exception | None = None

            progress = (
                nullcontext()
                if as_json
                else AnimatedEllipsisProgress(
                    console, "Fetching market prices", transient=True, start_immediately=True
                )
            )
            with progress:
                try:
                    raw_rows, _ = _try_authenticated()
                except Exception as e:  # noqa: BLE001
                    auth_error = e
                    _provider = "mithril"
                    try:
                        from flow.application.config.config import Config as _Cfg

                        _provider = _Cfg.from_env(require_auth=False).provider
                    except Exception:  # noqa: BLE001
                        pass
                    if _provider == "mithril":
                        try:
                            raw_rows = _try_public()
                        except Exception as e2:  # pragma: no cover  # noqa: BLE001
                            public_error = e2

            # Resolve API base + key for supplemental history (SDK auth does not populate
            # cached_api_ctx; public path does). Needed so 7d trends load when token is in
            # ~/.flow/config.yaml but not in the environment.
            if raw_rows and cached_api_ctx is None:
                cached_api_ctx = _resolve_api_context()[:2]

            # If we have no live data, surface a clear message and exit early
            if not raw_rows:
                is_auth_error = isinstance(auth_error, AuthenticationError) or isinstance(
                    public_error, AuthenticationError
                )

                if is_auth_error:
                    render_auth_required_message(console, output_json=as_json)
                    return

                if as_json:
                    print_json(
                        error_json(
                            "Unable to fetch live pricing data",
                            hint=f"See live price charts: {WebLinks.price_chart()}",
                        )
                    )
                else:
                    console.print("")
                    console.print("[dim]Unable to fetch live pricing data.[/dim]")
                    console.print("")
                    console.print(f"See live price charts: {WebLinks.price_chart()}\n")
                return

            # Optional raw list view
            if show_list:
                gpu_req = (gpu or "").lower().strip()
                display_rows = raw_rows
                if gpu_req:
                    display_rows = [
                        r for r in raw_rows if (r.get("gpu_type") or "").lower() == gpu_req
                    ]

                table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
                table.add_column("Region", style=muted, no_wrap=True)
                table.add_column("GPU", style=accent, no_wrap=True)
                table.add_column("GPUs", style=muted, justify="right")
                table.add_column("Price/GPU", justify="right")
                table.add_column("Price/inst", justify="right")
                table.add_column("Avail", justify="right")

                display_rows.sort(
                    key=lambda x: (x.get("region", ""), float(x.get("price_per_hour") or 0))
                )
                for r in display_rows:
                    p = float(r.get("price_per_hour") or 0)
                    g = r.get("gpu_count") or 0
                    per_inst = (p * g) if (p and g) else 0.0
                    table.add_row(
                        r.get("region", ""),
                        r.get("gpu_type", ""),
                        str(g or "-"),
                        f"${p:.2f}/hr" if p else "-",
                        f"${per_inst:.2f}/hr" if per_inst else "-",
                        str(r.get("available_quantity") or "-"),
                    )
                wrap_table_in_panel(
                    table, f"Listings{' \u2022 ' + region if region else ''}", console
                )
                return

            # Build per-(gpu, region, gpu_count) current price map.
            # Each GPU count tier is a distinct market — separate rows in display.
            avail_size_map: dict[tuple[str, str], set[int]] = defaultdict(set)
            # Keyed by (gpu_type, region, gpu_count) → lowest per-GPU price
            current_by_config: dict[tuple[str, str, int], float] = {}
            for r in raw_rows:
                gk = str(r.get("gpu_type") or "").lower().strip()
                rgn = str(r.get("region") or "").strip()
                if not gk or not rgn:
                    continue
                gc_raw = r.get("gpu_count")
                if not isinstance(gc_raw, int | float) or int(gc_raw) <= 0:
                    continue
                gc_int = int(gc_raw)
                avail_size_map[(gk, rgn)].add(gc_int)
                p = float(r.get("price_per_hour") or 0)
                if p <= 0:
                    continue
                cfg_key = (gk, rgn, gc_int)
                existing = current_by_config.get(cfg_key)
                if existing is None or p < existing:
                    current_by_config[cfg_key] = p

            market_by_size = aggregate_market_by_size(raw_rows, target_gpu=None)
            recs_by_size = derive_recommendations_by_size(market_by_size)

            # GPUs to show: requested, else preferred if available, else first two
            gpu_req = (gpu or "").lower().strip()
            if gpu_req:
                gpu_keys = [gpu_req]
            else:
                preferred = [g for g in PREFERRED_GPUS if g in market_by_size]
                gpu_keys = preferred or sorted(market_by_size.keys())[:2]

            # Build one row per (gpu, region, gpu_count) — each config is its
            # own market with distinct per-GPU pricing dynamics.
            rows: list[dict[str, Any]] = []
            for gpu_key in gpu_keys:
                # Collect all (region, gpu_count) configs for this GPU
                configs: list[tuple[str, int, float]] = []
                for (gk, rgn, gc_int), price_val in current_by_config.items():
                    if gk != gpu_key:
                        continue
                    if region and rgn != region:
                        continue
                    if gpu_count and gc_int != gpu_count:
                        continue
                    configs.append((rgn, gc_int, price_val))
                configs.sort(key=lambda t: (t[0], t[1]))

                for rgn, gc_int, price_val in configs:
                    sizes_here = avail_size_map.get((gpu_key, rgn), set())
                    cap_med_by_count: dict[int, float] = {}
                    for gc in sizes_here:
                        sized = recs_by_size.get(gpu_key, {}).get(rgn, {}).get(gc)
                        med = sized.get("med") if sized else None
                        if isinstance(med, int | float):
                            cap_med_by_count[gc] = float(med)
                    rows.append(
                        {
                            "gpu": gpu_key,
                            "gpu_count": gc_int,
                            "region": rgn,
                            "current_fmt": f"${price_val:.2f}",
                            "cap_med_by_count": cap_med_by_count,
                            "avail_counts": sorted(sizes_here),
                        }
                    )

            # ---- Fetch price history (best-effort) ----
            # Keyed by (gpu_type, region, gpu_count) — one per config
            history_data: dict[tuple[str, str, int], dict[str, Any]] = {}
            trends: dict[tuple[str, str, int], PriceTrend] = {}
            uptime_estimates: dict[tuple[str, str, int], list[Any]] = {}

            # Collect regions shown in rows for targeted history fetch
            shown_regions = list({r.get("region", "") for r in rows if r.get("region")})

            try:
                api_base, api_key = cached_api_ctx or _resolve_api_context()[:2]
                if api_key:
                    fid_map = cached_fid_map or _fetch_instance_type_map(api_base, api_key)
                    history_data = _fetch_price_history(
                        api_base,
                        api_key,
                        fid_map,
                        gpu,
                        region,
                        target_regions=shown_regions or None,
                    )

                    for r in rows:
                        gpu_key = r.get("gpu", "")
                        rgn = r.get("region", "")
                        row_gc = r.get("gpu_count", 8)
                        hist_key = (gpu_key, rgn, row_gc)
                        hist = history_data.get(hist_key)
                        if not hist or hist_key in trends:
                            continue
                        spot_prices = hist["spot_prices"]
                        current_price = current_by_config.get(hist_key, 0.0)

                        hist_ts = hist.get("timestamps", [])
                        trends[hist_key] = compute_price_trend(
                            spot_prices, hist_ts, current_price
                        )

                        limit_tiers = suggest_limit_prices(
                            spot_prices,
                            timestamps=hist_ts,
                        )
                        if limit_tiers:
                            uptime_estimates[hist_key] = estimate_uptime(
                                spot_prices, limit_tiers, gpu_count=row_gc,
                                timestamps=hist_ts,
                            )
            except Exception:  # noqa: BLE001
                pass  # History is supplemental; never block the command

            # JSON output
            if as_json:
                payload: dict[str, Any] = {
                    "context": {
                        "region_filter": region,
                        "gpu_filter": gpu,
                        "target_gpus": gpu_count,
                    },
                    "raw_listings": raw_rows,
                    "market_by_size": market_by_size,
                    "recommendations_by_size": recs_by_size,
                    "top_rows": rows,
                }

                # Serialize tuple-keyed dicts with "gpu:region" string keys
                def _cfg_key(d: dict[tuple[str, str, int], Any]) -> dict[str, Any]:
                    return {f"{g}:{r}:{gc}x": v for (g, r, gc), v in d.items()}

                if history_data:
                    payload["price_history"] = _cfg_key(history_data)
                if trends:
                    payload["trends"] = {
                        f"{g}:{r}:{gc}x": dataclasses.asdict(t)
                        for (g, r, gc), t in trends.items()
                    }
                if uptime_estimates:
                    payload["uptime_estimates"] = {
                        f"{gk}:{rgn}:{gc}x": [
                            {
                                "limit_price": e.limit_price,
                                "uptime_pct": e.uptime_pct,
                                "runtime_24h": e.runtime_24h,
                                "runtime_48h": e.runtime_48h,
                                "runtime_72h": e.runtime_72h,
                                "cost_48h": e.cost_48h,
                            }
                            for e in ests
                        ]
                        for (gk, rgn, gc), ests in uptime_estimates.items()
                    }

                # Planning intelligence for Claude / programmatic consumers
                if history_data:
                    planning: dict[str, Any] = {}
                    for (gpu_key, rgn, gc), hist in history_data.items():
                        prices = hist["spot_prices"]
                        hist_ts = hist.get("timestamps", [])

                        summary = compute_market_summary(
                            prices, timestamps=hist_ts,
                        )
                        entry: dict[str, Any] = {
                            "gpu": gpu_key,
                            "region": rgn,
                            "gpu_count": gc,
                            "market_summary": {
                                "mean_price": summary.mean_price,
                                "volatility_pct": summary.volatility_pct,
                                "confidence": summary.confidence,
                            },
                        }

                        budget_scenarios: list[dict[str, Any]] = []
                        for b in [250, 500, 1000, 2500]:
                            plan = plan_by_budget(
                                prices, b, gpu_count=gc, window_hours=48,
                                timestamps=hist_ts,
                            )
                            if plan:
                                budget_scenarios.append(
                                    {
                                        "budget": b,
                                        "limit_price": plan.limit_price,
                                        "expected_runtime_hours": plan.expected_runtime_hours,
                                        "expected_cost": plan.expected_cost,
                                        "uptime_pct": plan.uptime_pct,
                                    }
                                )
                        entry["budget_scenarios"] = budget_scenarios

                        runtime_scenarios: list[dict[str, Any]] = []
                        for target in [24, 48, 72]:
                            plan = plan_by_runtime(
                                prices,
                                target,
                                gpu_count=gc,
                                window_hours=target,
                                timestamps=hist_ts,
                            )
                            if plan:
                                runtime_scenarios.append(
                                    {
                                        "target_hours": target,
                                        "window_hours": target,
                                        "limit_price": plan.limit_price,
                                        "expected_cost": plan.expected_cost,
                                        "uptime_pct": plan.uptime_pct,
                                        "achievable": plan.achievable,
                                    }
                                )
                        entry["runtime_scenarios"] = runtime_scenarios

                        planning[f"{gpu_key}:{rgn}:{gc}x"] = entry

                    if planning:
                        payload["planning"] = planning

                click.echo(json.dumps(payload, indent=2))
                return

            # ---- Render ----
            target_counts = [gpu_count] if gpu_count and gpu_count > 0 else [1, 4, 8]
            _render_stats_panel(rows, trends=trends or None)
            console.print(
                "[dim]Per-GPU USD/hr. Avg = mean clearing price over window."
                " Pctl = 7d percentile (lower = cheaper)."
                " Trend = 24h \u00b7 6h \u00b7 1h momentum vs median"
                " ([green]\u2193[/green] dropping,"
                " [dim]\u2192[/dim] stable,"
                " [yellow]\u2191[/yellow] rising).[/dim]"
            )

            # Compute 24h historical P90×1.10 recommendations (duration-weighted).
            # Uses 1d window so recommendations adapt quickly to market shifts.
            hist_recs: dict[tuple[str, str, int], float] = {}
            now_utc = datetime.now(tz=timezone.utc)
            w1d_start = now_utc - timedelta(hours=24)
            for (gpu_key, rgn, gc), hist in history_data.items():
                ts_raw = hist.get("timestamps", [])
                parsed_ts = [_parse_iso_timestamp(t) for t in ts_raw]
                if not all(parsed_ts):
                    continue
                valid_ts: list[datetime] = [t for t in parsed_ts if t is not None]
                dur_p, dur_h = _compute_durations(
                    hist["spot_prices"], valid_ts, w1d_start, now_utc,
                )
                if dur_p and dur_h:
                    p90 = _weighted_percentile(dur_p, dur_h, 90)
                    hist_recs[(gpu_key, rgn, gc)] = round(p90 * 1.10, 2)

            console.print("")
            _render_caps_panel(rows, counts=target_counts, hist_recs=hist_recs or None)
            console.print(
                "[dim]You pay the clearing price (second-price auction), not your limit."
                " Recommended = P90×1.10 per GPU based on 24h history;"
                " '-' = size not in availability.[/dim]"
            )

            # Price eligibility estimates (if history available)
            if uptime_estimates:
                console.print("")
                for (gpu_key, rgn, gc), ests in uptime_estimates.items():
                    label = f"{gpu_key} {gc}x \u2022 {rgn}" if rgn else f"{gpu_key} {gc}x"
                    _render_uptime_panel(ests, gc, label)
                console.print(
                    "[dim]Based on 7d price history. Win Rate = % of time spot price was below"
                    " your limit. Actual allocation depends on capacity and bid competition.[/dim]"
                )

            console.print("")
            console.print(f"[dim]Docs: {DocsLinks.spot_bids()}[/dim]")

            # Telemetry (best-effort)
            try:
                Telemetry().log_event(
                    "pricing_recommendation_shown",
                    {
                        "gpu": ",".join(gpu_keys),
                        "rows": len(rows),
                        "region_filter": bool(region),
                        "gpus": gpu_count or 0,
                        "has_history": bool(history_data),
                    },
                )
            except Exception:  # noqa: BLE001
                pass

            if explain:
                console.print(
                    "[dim]Heuristics: Low=P50x1.15  Med=P90x1.10  High=P95x1.25 (rounded)."
                    " Confidence rises with sample size.[/dim]"
                )

            console.print("")

        return pricing


# Export command instance
command = PricingCommand()
