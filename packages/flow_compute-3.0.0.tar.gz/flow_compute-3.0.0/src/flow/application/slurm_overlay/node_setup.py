"""Node setup and configuration for Slurm overlay clusters.

Provides cluster setup, script upload, worker registration, validation,
and rollback as free functions.
"""

from __future__ import annotations

import base64
import json
import logging
import shlex
from pathlib import Path

from flow.application.slurm_overlay.exceptions import (
    ClusterExistsError,
    RegionMismatchError,
    SlurmOverlayError,
    SSHExecutionError,
)
from flow.application.slurm_overlay.hardware import get_node_resources
from flow.application.slurm_overlay.ssh_ops import ResolvedInstance, run_ssh_command
from flow.sdk.models.slurm_overlay import SlurmOverlayMetadata

logger = logging.getLogger(__name__)

_OVERLAY_METADATA_PATH = "/etc/flow/slurm_overlay.json"
_SLURM_WORKER_BLOCK = "FLOW_COMPUTE_MANAGED_WORKERS"
_GRES_WORKER_BLOCK = "FLOW_COMPUTE_MANAGED_GRES"
_SLURM_CUSTOM_BLOCK = "FLOW_COMPUTE_CUSTOM_SLURM_CONF"


def _run_remote_python(
    instance: ResolvedInstance,
    script: str,
    *,
    timeout: int = 60,
    ssh_runner=None,
) -> None:
    """Execute a Python script on a remote node with sudo."""
    runner = ssh_runner or run_ssh_command
    encoded = base64.b64encode(script.encode("utf-8")).decode("ascii")
    runner(
        instance,
        f"echo {shlex.quote(encoded)} | base64 -d | sudo python3",
        timeout=timeout,
    )


def _rewrite_managed_block(
    instance: ResolvedInstance,
    path: str,
    block_name: str,
    body: str,
    *,
    timeout: int = 60,
    ssh_runner=None,
) -> None:
    """Replace a managed block inside a remote config file."""
    marker_start = f"# BEGIN {block_name}"
    marker_end = f"# END {block_name}"
    script = f"""
from pathlib import Path
import re

path = Path({path!r})
marker_start = {marker_start!r}
marker_end = {marker_end!r}
body = {body.rstrip()!r}
text = path.read_text() if path.exists() else ""
pattern = re.compile(
    re.escape(marker_start) + r"\\n.*?\\n" + re.escape(marker_end) + r"\\n?",
    re.DOTALL,
)
text = pattern.sub("", text).rstrip()

if body:
    if text:
        text += "\\n\\n"
    text += marker_start + "\\n" + body + "\\n" + marker_end + "\\n"
elif text:
    text += "\\n"

path.write_text(text)
"""
    _run_remote_python(instance, script, timeout=timeout, ssh_runner=ssh_runner)


def _read_overlay_metadata(
    instance: ResolvedInstance,
    *,
    ssh_runner=None,
) -> SlurmOverlayMetadata | None:
    """Read persisted overlay metadata from a node."""
    runner = ssh_runner or run_ssh_command
    output = runner(
        instance,
        f"sudo test -f {_OVERLAY_METADATA_PATH} && sudo cat {_OVERLAY_METADATA_PATH} || true",
        timeout=30,
    )
    raw = output.strip()
    if not raw:
        return None
    try:
        return SlurmOverlayMetadata.model_validate_json(raw)
    except Exception as e:
        raise SlurmOverlayError(
            f"Instance '{instance.name}' has invalid overlay metadata at {_OVERLAY_METADATA_PATH}: {e}"
        ) from e


def _wait_for_slurmctld_ready(controller: ResolvedInstance) -> None:
    import time as time_module

    logger.info("Waiting for slurmctld to be ready...")
    for attempt in range(15):
        try:
            output = run_ssh_command(
                controller,
                "sinfo --version 2>&1",
                timeout=15,
                retries=1,
            )
            if "slurm" in output.lower():
                logger.debug(f"slurmctld ready after {attempt + 1} attempts")
                return
        except SSHExecutionError:
            pass
        time_module.sleep(2)

    raise SSHExecutionError(
        f"slurmctld did not become ready on {controller.name} after config sync",
        returncode=-1,
        stderr="slurmctld readiness check timed out",
    )


def get_setup_script_path() -> Path:
    """Get the path to the slurm_overlay_setup.sh script."""
    import flow.resources

    resources_dir = Path(flow.resources.__file__).parent
    script_path = resources_dir / "scripts" / "slurm_overlay_setup.sh"
    if not script_path.exists():
        raise FileNotFoundError(f"Setup script not found at {script_path}")
    return script_path


def upload_and_run_script(
    instance: ResolvedInstance,
    role: str,
    setup_script_path: Path,
    controller_ip: str | None = None,
    partition: str = "gpu",
    max_time: str = "7-00:00:00",
    munge_key: bytes | None = None,
) -> str:
    """Upload and execute the setup script on an instance.

    Args:
        instance: Target instance.
        role: 'controller' or 'worker'.
        setup_script_path: Path to the local setup script.
        controller_ip: Controller IP (required for workers).
        partition: Slurm partition name.
        max_time: Maximum job time.
        munge_key: Munge key bytes (required for workers).

    Returns:
        Script output.
    """
    script_content = setup_script_path.read_text()

    if role == "controller":
        upload_cmd = (
            "cat > /tmp/slurm_overlay_setup.sh && "
            "chmod +x /tmp/slurm_overlay_setup.sh && "
            f"sudo /tmp/slurm_overlay_setup.sh controller '{partition}' '{max_time}'"
        )
        return run_ssh_command(
            instance,
            upload_cmd,
            stdin=script_content.encode("utf-8"),
            timeout=600,
        )
    else:
        if not controller_ip:
            raise ValueError("controller_ip required for worker role")
        if not munge_key:
            raise ValueError("munge_key required for worker role")

        upload_cmd = "cat > /tmp/slurm_overlay_setup.sh && chmod +x /tmp/slurm_overlay_setup.sh"
        run_ssh_command(
            instance,
            upload_cmd,
            stdin=script_content.encode("utf-8"),
        )

        run_cmd = f"sudo /tmp/slurm_overlay_setup.sh worker '{controller_ip}'"
        return run_ssh_command(
            instance,
            run_cmd,
            stdin=munge_key,
            timeout=600,
        )


def get_munge_key(controller: ResolvedInstance) -> bytes:
    """Retrieve the munge key from the controller.

    Args:
        controller: Resolved controller instance.

    Returns:
        Munge key as bytes.
    """
    output = run_ssh_command(
        controller,
        "sudo cat /etc/munge/munge.key | base64",
    )
    return base64.b64decode(output.strip())


def register_workers_on_controller(
    controller: ResolvedInstance,
    workers: list[ResolvedInstance],
) -> None:
    """Synchronize worker nodes in the controller's slurm.conf and gres.conf.

    Rewrites the Flow-managed worker blocks in both config files so repeated
    add/remove operations remain idempotent and stale workers are removed.

    Args:
        controller: Controller instance.
        workers: Full desired worker set.
    """
    logger.info("Synchronizing %d worker(s) on controller %s", len(workers), controller.name)

    node_lines = []
    gres_lines = []
    for worker in workers:
        resources = get_node_resources(worker)
        node_line = (
            f"NodeName={resources['hostname']} "
            f"NodeAddr={resources['private_ip']} "
            f"CPUs={resources['cpus']} "
            f"RealMemory={resources['real_memory']} "
            f"Gres=gpu:{resources['gpu_count']} "
            f"State=UNKNOWN"
        )
        node_lines.append(node_line)
        logger.debug(f"Worker node config: {node_line}")

        if resources["gpu_count"] > 0:
            last_gpu = resources["gpu_count"] - 1
            gres_line = f"NodeName={resources['hostname']} Name=gpu File=/dev/nvidia[0-{last_gpu}]"
            gres_lines.append(gres_line)
            logger.debug(f"Worker GRES config: {gres_line}")

    _rewrite_managed_block(
        controller,
        "/etc/slurm/slurm.conf",
        _SLURM_WORKER_BLOCK,
        "\n".join(node_lines),
        timeout=30,
    )
    _rewrite_managed_block(
        controller,
        "/etc/slurm/gres.conf",
        _GRES_WORKER_BLOCK,
        "\n".join(gres_lines),
        timeout=30,
    )

    logger.info("Reconfiguring slurmctld to serve updated config to workers...")
    run_ssh_command(
        controller,
        "sudo scontrol reconfigure",
        timeout=60,
    )
    _wait_for_slurmctld_ready(controller)


def apply_controller_overrides(controller: ResolvedInstance, slurm_conf_overrides: str) -> None:
    """Apply supported slurm.conf overrides on the controller."""
    if not slurm_conf_overrides.strip():
        return

    logger.info("Applying custom slurm.conf overrides on controller %s", controller.name)
    _rewrite_managed_block(
        controller,
        "/etc/slurm/slurm.conf",
        _SLURM_CUSTOM_BLOCK,
        slurm_conf_overrides,
        timeout=30,
    )
    run_ssh_command(
        controller,
        "sudo scontrol reconfigure",
        timeout=60,
    )
    _wait_for_slurmctld_ready(controller)


def update_instance_metadata(
    instance: ResolvedInstance,
    cluster_name: str,
    role: str,
    controller_ip: str,
    partition: str = "gpu",
    *,
    ssh_runner=None,
) -> None:
    """Update instance metadata with overlay cluster info.

    Persists cluster membership on the instance itself so exclusivity survives
    process restarts and lost local state.
    """
    runner = ssh_runner or run_ssh_command
    metadata = SlurmOverlayMetadata(
        cluster=cluster_name,
        role=role,
        controller_ip=controller_ip,
        partition=partition,
    )
    payload = metadata.model_dump(mode="json")
    encoded = base64.b64encode(
        (json.dumps(payload, sort_keys=True, indent=2) + "\n").encode("utf-8")
    ).decode("ascii")
    runner(
        instance,
        (
            "sudo install -d -m 0755 /etc/flow && "
            f"echo {shlex.quote(encoded)} | base64 -d | "
            f"sudo tee {_OVERLAY_METADATA_PATH} > /dev/null && "
            f"sudo chmod 0644 {_OVERLAY_METADATA_PATH}"
        ),
        timeout=30,
    )
    instance.metadata["slurm_overlay"] = payload
    logger.info("Instance %s joined cluster %s as %s", instance.name, cluster_name, role)


def clear_instance_metadata(
    instance: ResolvedInstance,
    *,
    ssh_runner=None,
) -> None:
    """Remove persisted overlay metadata from an instance."""
    runner = ssh_runner or run_ssh_command
    runner(
        instance,
        f"sudo rm -f {_OVERLAY_METADATA_PATH}",
        timeout=30,
    )
    instance.metadata.pop("slurm_overlay", None)


def check_instance_not_in_cluster(
    instance: ResolvedInstance,
    *,
    ssh_runner=None,
    allowed_cluster_name: str | None = None,
) -> None:
    """Check that an instance is not already in a cluster.

    Raises:
        ClusterExistsError: If the instance is already in a cluster.
    """
    overlay_meta = instance.metadata.get("slurm_overlay")
    remote_meta = _read_overlay_metadata(instance, ssh_runner=ssh_runner) if ssh_runner else None
    if remote_meta:
        if overlay_meta and overlay_meta.get("cluster") != remote_meta.cluster:
            raise SlurmOverlayError(
                f"Instance '{instance.name}' has conflicting overlay metadata: "
                f"local={overlay_meta.get('cluster')} remote={remote_meta.cluster}"
            )
        overlay_meta = remote_meta.model_dump(mode="json")
        instance.metadata["slurm_overlay"] = overlay_meta

    if overlay_meta:
        existing_cluster = overlay_meta.get("cluster", "unknown")
        if allowed_cluster_name and existing_cluster == allowed_cluster_name:
            return
        raise ClusterExistsError(
            f"Instance '{instance.name}' is already in cluster '{existing_cluster}'. "
            "Remove it first with 'flow cluster remove' or dissolve the existing overlay."
        )


def validate_instance_regions(
    controller: ResolvedInstance,
    workers: list[ResolvedInstance],
) -> None:
    """Validate that all instances are in the same region.

    Multi-node Slurm clusters require instances to be in the same region
    for network communication between nodes.

    Args:
        controller: Controller instance.
        workers: Worker instances.

    Raises:
        RegionMismatchError: If instances are in different regions.
    """
    if not workers:
        return

    all_instances = [controller] + workers
    regions_by_instance = {inst.name: inst.region for inst in all_instances}

    known_regions = {name: region for name, region in regions_by_instance.items() if region}

    if not known_regions:
        logger.warning(
            "Could not determine regions for instances. Proceeding without region validation."
        )
        return

    unique_regions = set(known_regions.values())
    if len(unique_regions) > 1:
        raise RegionMismatchError(known_regions)

    logger.info(f"All instances are in region: {next(iter(unique_regions))}")


def cleanup_stale_state(controller: ResolvedInstance) -> None:
    """Clean up stale Slurm state on controller before fresh setup.

    Prevents CLUSTER NAME MISMATCH errors when creating a new cluster
    on an instance that previously ran Slurm.

    Args:
        controller: Controller instance to clean up.
    """
    try:
        run_ssh_command(
            controller,
            "sudo rm -rf /var/spool/slurmctld/* /var/spool/slurmd/* 2>/dev/null; "
            "sudo systemctl stop slurmctld slurmd munge 2>/dev/null || true",
            timeout=60,
        )
        logger.debug(f"Cleaned up stale state on {controller.name}")
    except Exception as e:  # noqa: BLE001
        logger.debug(f"Cleanup failed on {controller.name} (may be OK): {e}")


def verify_cluster_health(
    controller: ResolvedInstance,
    expected_worker_count: int,
    max_wait: int = 30,
    poll_interval: float = 2.0,
) -> None:
    """Verify cluster is operational after setup.

    Polls slurmctld until it responds or timeout is reached.

    Args:
        controller: Controller instance.
        expected_worker_count: Number of workers expected.
        max_wait: Maximum time to wait for cluster readiness in seconds.
        poll_interval: Time between readiness polls in seconds.

    Raises:
        SSHExecutionError: If health check fails after timeout.
    """
    import time as time_module

    start_time = time_module.monotonic()
    expected_nodes = expected_worker_count + 1  # +1 for controller
    last_error: str = ""

    while time_module.monotonic() - start_time < max_wait:
        try:
            version_output = run_ssh_command(
                controller,
                "sinfo --version 2>&1 || echo 'sinfo-failed'",
                timeout=10,
                retries=1,
            )
            if "sinfo-failed" in version_output:
                last_error = "slurmctld not responding"
                time_module.sleep(poll_interval)
                continue

            output = run_ssh_command(
                controller,
                "sinfo --noheader -N 2>/dev/null | wc -l",
                timeout=10,
                retries=1,
            )
            try:
                node_count = int(output.strip())
                if node_count >= expected_nodes:
                    logger.info(f"Cluster verified: {node_count} nodes ready")
                    return
                last_error = f"Only {node_count}/{expected_nodes} nodes registered"
            except ValueError:
                last_error = f"Could not parse node count: {output}"

            time_module.sleep(poll_interval)

        except SSHExecutionError as e:
            last_error = str(e)
            time_module.sleep(poll_interval)

    elapsed = time_module.monotonic() - start_time
    detail = last_error or "Timed out waiting for slurmctld to report the expected nodes"
    raise SSHExecutionError(
        f"Cluster verification failed after {elapsed:.1f}s: {detail}",
        returncode=-1,
        stderr=detail,
    )


def rollback_create(
    controller: ResolvedInstance | None,
    workers: list[ResolvedInstance],
) -> None:
    """Rollback a failed cluster creation.

    Cleans up any Slurm installation that was done.

    Args:
        controller: Controller instance (if setup), or None.
        workers: List of worker instances that were set up.
    """
    for worker in workers:
        try:
            logger.info(f"Cleaning up worker {worker.name}...")
            run_ssh_command(
                worker,
                "sudo systemctl stop slurmd munge 2>/dev/null; "
                f"sudo rm -f /etc/slurm/slurm.conf /etc/munge/munge.key {_OVERLAY_METADATA_PATH}",
                timeout=60,
            )
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to clean up worker {worker.name}: {e}")

    if controller:
        try:
            logger.info(f"Cleaning up controller {controller.name}...")
            run_ssh_command(
                controller,
                "sudo systemctl stop slurmctld slurmd munge 2>/dev/null; "
                f"sudo rm -f /etc/slurm/slurm.conf /etc/munge/munge.key {_OVERLAY_METADATA_PATH}; "
                "sudo rm -rf /var/spool/slurmctld/* /var/spool/slurmd/*",
                timeout=60,
            )
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to clean up controller {controller.name}: {e}")

    logger.info("Rollback complete")
