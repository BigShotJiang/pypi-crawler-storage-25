# validate extraction JSON against the graphify schema before graph assembly
from __future__ import annotations

VALID_FILE_TYPES = {"code", "document", "paper", "image", "rationale"}
VALID_CONFIDENCES = {"EXTRACTED", "INFERRED", "AMBIGUOUS"}
REQUIRED_NODE_FIELDS = {"id", "label", "file_type", "source_file"}
REQUIRED_EDGE_FIELDS = {"source", "target", "relation", "confidence", "source_file"}


def validate_extraction(data: dict) -> list[str]:
    """
    Validate an extraction JSON dict against the graphify schema.
    Returns a list of error strings - empty list means valid.
    """
    if not isinstance(data, dict):
        return ["Extraction must be a JSON object"]

    errors: list[str] = []

    # Nodes
    if "nodes" not in data:
        errors.append("Missing required key 'nodes'")
    elif not isinstance(data["nodes"], list):
        errors.append("'nodes' must be a list")
    else:
        for i, node in enumerate(data["nodes"]):
            if not isinstance(node, dict):
                errors.append(f"Node {i} must be an object")
                continue
            for field in REQUIRED_NODE_FIELDS:
                if field not in node:
                    errors.append(f"Node {i} (id={node.get('id', '?')!r}) missing required field '{field}'")
            if "file_type" in node and node["file_type"] not in VALID_FILE_TYPES:
                errors.append(
                    f"Node {i} (id={node.get('id', '?')!r}) has invalid file_type "
                    f"'{node['file_type']}' - must be one of {sorted(VALID_FILE_TYPES)}"
                )

    # Edges - accept "links" (NetworkX <= 3.1) as fallback for "edges"
    edge_list = data.get("edges") if "edges" in data else data.get("links")
    if edge_list is None:
        errors.append("Missing required key 'edges'")
    elif not isinstance(edge_list, list):
        errors.append("'edges' must be a list")
    else:
        node_ids = {n["id"] for n in data.get("nodes", []) if isinstance(n, dict) and "id" in n}
        for i, edge in enumerate(edge_list):
            if not isinstance(edge, dict):
                errors.append(f"Edge {i} must be an object")
                continue
            for field in REQUIRED_EDGE_FIELDS:
                if field not in edge:
                    errors.append(f"Edge {i} missing required field '{field}'")
            if "confidence" in edge and edge["confidence"] not in VALID_CONFIDENCES:
                errors.append(
                    f"Edge {i} has invalid confidence '{edge['confidence']}' "
                    f"- must be one of {sorted(VALID_CONFIDENCES)}"
                )
            if "source" in edge and node_ids and edge["source"] not in node_ids:
                errors.append(f"Edge {i} source '{edge['source']}' does not match any node id")
            if "target" in edge and node_ids and edge["target"] not in node_ids:
                errors.append(f"Edge {i} target '{edge['target']}' does not match any node id")

    return errors


def assert_valid(data: dict) -> None:
    """Raise ValueError with all errors if extraction is invalid."""
    errors = validate_extraction(data)
    if errors:
        msg = f"Extraction JSON has {len(errors)} error(s):\n" + "\n".join(f"  • {e}" for e in errors)
        raise ValueError(msg)


# ---------------------------------------------------------------------------
# Extraction density validation
# ---------------------------------------------------------------------------

# Default thresholds: minimum nodes per word for each file type.
# Files below these thresholds are considered "low density" and should
# be re-extracted individually for better coverage.
DEFAULT_DENSITY_THRESHOLDS: dict[str, float] = {
    "document": 1 / 500,   # 1 node per 500 words
    "paper": 1 / 800,       # 1 node per 800 words (papers are sparser)
    # "code" and "image" are skipped — AST handles code deterministically,
    # and image extraction is unpredictable.
}


def validate_extraction_density(
    extraction: dict,
    file_word_counts: dict[str, int],
    thresholds: dict[str, float] | None = None,
) -> dict:
    """Check extraction density per source file and flag low-density files.

    Args:
        extraction: Extraction dict with 'nodes' and 'edges'.
        file_word_counts: Mapping of absolute file path → word count.
        thresholds: Override default density thresholds per file_type.

    Returns:
        {
            "low_density_files": [path, ...],   # below threshold
            "zero_node_files": [path, ...],     # had words but 0 nodes
            "file_stats": [
                {"path": ..., "words": N, "nodes": N, "density": float, "file_type": str, "low": bool},
                ...
            ],
        }
    """
    if thresholds is None:
        thresholds = DEFAULT_DENSITY_THRESHOLDS

    # Count nodes per source_file
    nodes_per_file: dict[str, int] = {}
    file_types: dict[str, str] = {}
    for node in extraction.get("nodes", []):
        if not isinstance(node, dict):
            continue
        src = node.get("source_file", "")
        if src:
            nodes_per_file[src] = nodes_per_file.get(src, 0) + 1
            if src not in file_types:
                file_types[src] = node.get("file_type", "document")

    # Build a lookup that maps filenames → list of source_file paths from nodes.
    # source_file in nodes may be relative (e.g. "video.md") while
    # file_word_counts keys are absolute paths — we match by suffix.
    from pathlib import Path as _Path

    def _match(src: str, fpath: str) -> bool:
        if src == fpath:
            return True
        # Suffix match: "/abs/path/video.md" matches "video.md"
        try:
            return fpath.endswith("/" + src) or fpath.endswith("\\" + src)
        except Exception:
            return False

    # Evaluate each file that has a word count
    low_density: list[str] = []
    zero_node: list[str] = []
    stats: list[dict] = []

    for fpath, words in file_word_counts.items():
        if words <= 0:
            continue

        # Find matching node count by direct key or suffix match
        n_nodes = nodes_per_file.get(fpath, 0)
        ft = file_types.get(fpath, "")
        if n_nodes == 0:
            for src, count in nodes_per_file.items():
                if _match(src, fpath):
                    n_nodes = count
                    ft = file_types.get(src, "document")
                    break
        if not ft:
            ft = "document"

        # Skip file types without a threshold
        if ft not in thresholds:
            continue

        density = n_nodes / words
        threshold = thresholds[ft]
        is_low = density < threshold

        entry = {
            "path": fpath,
            "words": words,
            "nodes": n_nodes,
            "density": round(density, 6),
            "file_type": ft,
            "low": is_low,
        }
        stats.append(entry)

        if n_nodes == 0:
            zero_node.append(fpath)
        elif is_low:
            low_density.append(fpath)

    return {
        "low_density_files": low_density,
        "zero_node_files": zero_node,
        "file_stats": stats,
    }


def flag_low_density_cached(
    cached_nodes: list[dict],
    cached_edges: list[dict],
    file_word_counts: dict[str, int],
    thresholds: dict[str, float] | None = None,
) -> list[str]:
    """Identify cached files whose extraction density is too low.

    Used by check_semantic_cache() to invalidate low-density cached
    results so they get re-extracted.

    Args:
        cached_nodes: Nodes loaded from cache.
        cached_edges: Edges loaded from cache (unused but kept for API consistency).
        file_word_counts: Mapping of absolute file path → word count.
        thresholds: Override default density thresholds per file_type.

    Returns:
        List of file paths that should be re-extracted.
    """
    extraction = {"nodes": cached_nodes, "edges": cached_edges}
    result = validate_extraction_density(extraction, file_word_counts, thresholds)
    return result["low_density_files"] + result["zero_node_files"]
