# MCP stdio server - exposes graph query tools to Claude and other agents
from __future__ import annotations
from collections import deque
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path
import networkx as nx
from networkx.readwrite import json_graph
from graphify.security import sanitize_label


def _resolve_graph_path(graph_path: str) -> str:
    """Resolve graph.json path using GRAPHIFY_WORKSPACE or fallbacks.

    Resolution order:
    1. Already absolute and exists → return as-is
    2. Relative and exists relative to CWD → return resolved
    3. GRAPHIFY_WORKSPACE / graph_path
    4. Fallback: return original (let _load_graph fail with clear error)
    """
    gp = Path(graph_path)
    if gp.is_absolute():
        if gp.exists():
            return str(gp)
        return graph_path

    cwd_candidate = Path.cwd() / graph_path
    if cwd_candidate.exists():
        return str(cwd_candidate.resolve())

    ws = _infer_workspace(graph_path) or os.environ.get("GRAPHIFY_WORKSPACE", "")
    if ws:
        candidate = Path(ws) / graph_path
        if candidate.exists():
            return str(candidate.resolve())

    return graph_path


def _infer_workspace(graph_path: str) -> str:
    """Infer workspace from graph.json path.

    If graph_path is .../graphify-out/graph.json, workspace = parent of graphify-out/.
    """
    gp = Path(graph_path)
    if gp.name == "graph.json" and gp.parent.name == "graphify-out":
        return str(gp.parent.parent)
    return ""


def _resolve_source_file(source_file: str, graph_dir: Path) -> str:
    """Resolve a source_file path to absolute using GRAPHIFY_WORKSPACE or fallbacks.

    Resolution order:
    1. Already absolute and file exists → return as-is (backward compat)
    2. Already absolute but missing → try GRAPHIFY_WORKSPACE suffix matching
    3. GRAPHIFY_WORKSPACE / source_file
    4. graph_dir / source_file
    5. CWD / source_file
    6. Fallback: GRAPHIFY_WORKSPACE / source_file (even if missing, for display)
    """
    if not source_file:
        return source_file
    sf_path = Path(source_file)

    ws = os.environ.get("GRAPHIFY_WORKSPACE", "")

    if sf_path.is_absolute():
        if sf_path.exists():
            return source_file
        # Absolute but missing (different machine) — try GRAPHIFY_WORKSPACE suffix match
        if ws:
            parts = sf_path.parts
            for i in range(1, len(parts)):
                candidate = Path(ws) / Path(*parts[i:])
                if candidate.exists():
                    return str(candidate.resolve())
        return source_file

    if ws:
        candidate = Path(ws) / source_file
        if candidate.exists():
            return str(candidate.resolve())

    candidate = graph_dir / source_file
    if candidate.exists():
        return str(candidate.resolve())

    candidate = Path.cwd() / source_file
    if candidate.exists():
        return str(candidate.resolve())

    if ws:
        return str(Path(ws).resolve() / source_file)
    return source_file


_TASK_MARKERS = (
    "哪些", "什么", "怎么", "如何", "排查", "应该", "哪里", "入口", "链路", "相关", "核心",
    "which", "what", "how", "where", "inspect", "check", "look", "core", "central", "related",
    "relevant", "entry", "workflow", "flow", "path", "components", "component", "types",
)

_STOP_TERMS = {
    "a", "an", "the", "and", "or", "but", "if", "then", "how", "what", "which", "where", "when",
    "why", "who", "whom", "whose", "should", "would", "could", "can", "do", "does", "did", "done",
    "is", "are", "was", "were", "be", "being", "been", "to", "for", "of", "on", "in", "at", "by",
    "from", "with", "into", "onto", "over", "under", "after", "before", "through", "i", "me", "my",
    "we", "our", "you", "your", "it", "this", "that", "these", "those", "should", "inspect", "look",
    "check", "start", "begin", "using", "use", "used", "handle", "handles", "central", "related",
    "relevant", "core", "types", "entry",
    "provides", "implements", "extends", "returns", "creates", "contains", "represents",
    "companion", "cloneoptions",
}


def _is_cjk_char(char: str) -> bool:
    codepoint = ord(char)
    return (
        0x3400 <= codepoint <= 0x4DBF  # CJK Unified Ideographs Extension A
        or 0x4E00 <= codepoint <= 0x9FFF  # CJK Unified Ideographs
        or 0xF900 <= codepoint <= 0xFAFF  # CJK Compatibility Ideographs
        or 0x3040 <= codepoint <= 0x30FF  # Hiragana + Katakana
        or 0xAC00 <= codepoint <= 0xD7AF  # Hangul Syllables
    )


def _contains_cjk(text: str) -> bool:
    return any(_is_cjk_char(char) for char in text)


def _dedupe_texts(texts: list[str]) -> list[str]:
    deduped: list[str] = []
    seen: set[str] = set()
    for text in texts:
        compact = re.sub(r"\s+", " ", str(text or "")).strip()
        if not compact:
            continue
        marker = compact.casefold()
        if marker in seen:
            continue
        deduped.append(compact)
        seen.add(marker)
    return deduped


def _english_term_variants(token: str) -> list[str]:
    variants = [token]
    if len(token) > 4 and token.endswith("ies"):
        variants.append(token[:-3] + "y")
    elif len(token) > 4 and token.endswith(("ses", "xes", "zes", "ches", "shes")):
        variants.append(token[:-2])
    elif len(token) > 3 and token.endswith("s") and not token.endswith("ss"):
        variants.append(token[:-1])
    deduped: list[str] = []
    seen: set[str] = set()
    for item in variants:
        if item and item not in seen:
            deduped.append(item)
            seen.add(item)
    return deduped


def _cjk_term_variants(token: str) -> list[str]:
    compact = token.replace(" ", "")
    if len(compact) < 2:
        return []
    variants: list[str] = []
    seen: set[str] = set()
    for size in range(min(len(compact), 4), 1, -1):
        for start in range(0, len(compact) - size + 1):
            piece = compact[start:start + size]
            if piece and piece not in seen:
                variants.append(piece)
                seen.add(piece)
    if len(compact) <= 4 and compact not in seen:
        variants.append(compact)
    return variants


def _load_graph(graph_path: str) -> nx.Graph:
    try:
        resolved = Path(graph_path).resolve()
        if resolved.suffix != ".json":
            raise ValueError(f"Graph path must be a .json file, got: {graph_path!r}")
        if not resolved.exists():
            raise FileNotFoundError(f"Graph file not found: {resolved}")
        safe = resolved
        data = json.loads(safe.read_text(encoding="utf-8"))
        if "links" not in data and "edges" in data:
            data = dict(data, links=data["edges"])
        try:
            G = json_graph.node_link_graph(data, edges="links")
        except TypeError:
            G = json_graph.node_link_graph(data)

        # Resolve relative source_file paths to absolute using GRAPHIFY_WORKSPACE
        graph_dir = resolved.parent
        for nid, ndata in G.nodes(data=True):
            sf = ndata.get("source_file", "")
            if sf:
                ndata["source_file"] = _resolve_source_file(sf, graph_dir)
        for u, v, edata in G.edges(data=True):
            sf = edata.get("source_file", "")
            if sf:
                edata["source_file"] = _resolve_source_file(sf, graph_dir)

        # Merge same-label nodes: multiple documents may create separate nodes
        # with the same label (e.g. "Entity" appears 48 times).  Merge them
        # into a single canonical node so that degree, neighbors, and
        # shortest_path reflect the true connectivity.
        G = _merge_same_label_nodes(G)

        return G
    except (ValueError, FileNotFoundError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as exc:
        print(f"error: graph.json is corrupted ({exc}). Re-run /graphify to rebuild.", file=sys.stderr)
        sys.exit(1)


def _communities_from_graph(G: nx.Graph) -> dict[int, list[str]]:
    """Reconstruct community dict from community property stored on nodes."""
    communities: dict[int, list[str]] = {}
    for node_id, data in G.nodes(data=True):
        cid = data.get("community")
        if cid is not None:
            communities.setdefault(int(cid), []).append(node_id)
    return communities


def _merge_same_label_nodes(G: nx.Graph) -> nx.Graph:
    """Merge nodes that share the same label into a single canonical node.

    When multiple documents extract the same concept (e.g. "Entity" from 48
    different .md files), the graph ends up with separate nodes that should
    be one.  This function:

    1. Groups nodes by label (cross-community merge for same label).
    2. For each group, picks the highest-degree node as the canonical ID,
       breaking ties by confidence (EXTRACTED > INFERRED > AMBIGUOUS).
    3. Merges source_file info from all duplicates into the canonical node.
    4. Rewires all edges from duplicate nodes to the canonical node,
       preserving duplicate edges via MultiGraph.
    5. Removes duplicate nodes.

    Returns a MultiGraph so that degree counts reflect true connectivity
    (multiple edges to the same neighbor are counted separately).
    """
    from collections import defaultdict

    _CONFIDENCE_RANK = {"EXTRACTED": 2, "INFERRED": 1, "AMBIGUOUS": 0}

    # Convert to MultiGraph to preserve duplicate edges after merge
    MG = nx.MultiGraph()
    MG.add_nodes_from(G.nodes(data=True))
    for u, v, data in G.edges(data=True):
        MG.add_edge(u, v, **data)

    # Group by label — merge across communities since same-label nodes
    # in different communities are the same concept extracted from
    # different documents.
    groups: dict[str, list[str]] = defaultdict(list)
    for nid, data in MG.nodes(data=True):
        label = data.get("label", "")
        if label:
            groups[label].append(nid)

    merge_count = 0
    for label, nids in groups.items():
        if len(nids) <= 1:
            continue

        # Pick canonical: highest degree, break ties by confidence rank
        def _canonical_key(nid: str) -> tuple[int, int]:
            deg = MG.degree(nid)
            conf = MG.nodes[nid].get("confidence", "")
            return (deg, _CONFIDENCE_RANK.get(conf, 0))

        nids_sorted = sorted(nids, key=_canonical_key, reverse=True)
        canonical = nids_sorted[0]
        duplicates = nids_sorted[1:]

        # Merge source_file info from all nodes in the group
        all_sources: list[str] = []
        for nid in nids_sorted:
            sf = MG.nodes[nid].get("source_file", "")
            if sf and sf not in all_sources:
                all_sources.append(sf)
        MG.nodes[canonical]["source_files"] = all_sources

        # Rewire edges from duplicates to canonical (MultiGraph preserves duplicates)
        for dup in duplicates:
            for neighbor in list(MG.neighbors(dup)):
                if neighbor == canonical:
                    continue
                for _key, edge_data in dict(MG[dup][neighbor]).items():
                    MG.add_edge(canonical, neighbor, **edge_data)
            MG.remove_node(dup)

        merge_count += len(duplicates)

    if merge_count:
        print(f"  [graphify] Merged {merge_count} same-label nodes", file=sys.stderr)
    return MG


def _strip_diacritics(text: str) -> str:
    import unicodedata
    nfkd = unicodedata.normalize("NFKD", text)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def _normalize_query_text(text: str) -> str:
    text = _strip_diacritics(text)
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    lowered = text.lower()
    normalized_chars: list[str] = []
    previous_kind = "space"
    for char in lowered:
        if char.isascii() and char.isalnum():
            current_kind = "latin"
        elif _is_cjk_char(char):
            current_kind = "cjk"
        else:
            current_kind = "space"

        if current_kind == "space":
            if normalized_chars and normalized_chars[-1] != " ":
                normalized_chars.append(" ")
            previous_kind = "space"
            continue

        if previous_kind in {"latin", "cjk"} and current_kind != previous_kind and normalized_chars and normalized_chars[-1] != " ":
            normalized_chars.append(" ")
        normalized_chars.append(char)
        previous_kind = current_kind
    return re.sub(r"\s+", " ", "".join(normalized_chars)).strip()


def _parse_query_variant_output(output: str) -> list[str]:
    stripped = output.strip()
    if not stripped:
        return []
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        return _dedupe_texts(stripped.splitlines())
    if isinstance(parsed, str):
        return _dedupe_texts([parsed])
    if isinstance(parsed, dict):
        variants = parsed.get("variants") or parsed.get("queries") or parsed.get("rewrites") or []
        if isinstance(variants, list):
            return _dedupe_texts([str(item) for item in variants])
        return []
    if isinstance(parsed, list):
        return _dedupe_texts([str(item) for item in parsed])
    return []


def _builtin_translate_to_english(text: str) -> str | None:
    """Try to translate non-English text to English using deep-translator.

    Returns the translated string, or None if translation is unavailable.
    deep-translator is an optional dependency — if not installed, returns None.
    """
    if not _contains_cjk(text):
        return None
    try:
        from deep_translator import GoogleTranslator  # type: ignore[import-untyped]
        translated = GoogleTranslator(source="auto", target="en").translate(text)
        if translated and str(translated).strip() != text:
            return str(translated).strip()
    except Exception:
        pass
    return None


def _external_query_variants(question: str) -> list[str]:
    command = os.environ.get("GRAPHIFY_QUERY_REWRITE_CMD", "").strip()
    if not command:
        return []
    timeout_ms_raw = os.environ.get("GRAPHIFY_QUERY_REWRITE_TIMEOUT_MS", "1500").strip() or "1500"
    try:
        timeout_ms = max(100, min(int(timeout_ms_raw), 10000))
    except ValueError:
        timeout_ms = 1500
    try:
        completed = subprocess.run(
            shlex.split(command),
            input=question,
            text=True,
            capture_output=True,
            timeout=timeout_ms / 1000.0,
            check=False,
        )
    except (OSError, ValueError, subprocess.SubprocessError):
        return []
    if completed.returncode != 0:
        return []
    return _parse_query_variant_output(completed.stdout)


def _query_variants(question: str, extra_variants: list[str] | None = None) -> list[str]:
    all_variants: list[str] = [question, *(extra_variants or [])]
    # External rewrite hook (highest priority)
    external = _external_query_variants(question)
    if external:
        all_variants.extend(external)
    # Built-in translation fallback for CJK queries
    if _contains_cjk(question) and not external:
        translated = _builtin_translate_to_english(question)
        if translated:
            all_variants.append(translated)
    return _dedupe_texts(all_variants)


def _normalized_label_forms(label: str) -> tuple[str, str]:
    spaced = _normalize_query_text(label)
    compact = spaced.replace(" ", "")
    return spaced, compact


def _extract_query_terms(question: str, extra_variants: list[str] | None = None) -> list[str]:
    """Extract useful retrieval terms from free-form user questions.

    Supports mixed Chinese/English prompts by pulling out embedded identifiers
    even when they are not surrounded by spaces.
    """
    terms: list[str] = []
    seen: set[str] = set()

    def _append_term(token: str) -> None:
        compact = token.replace(" ", "")
        if not compact:
            return
        if _contains_cjk(compact):
            for variant in _cjk_term_variants(compact):
                if variant not in seen:
                    terms.append(variant)
                    seen.add(variant)
            return
        if len(compact) <= 2 or compact in _STOP_TERMS:
            return
        for variant in _english_term_variants(compact):
            if variant not in seen and variant not in _STOP_TERMS:
                terms.append(variant)
                seen.add(variant)

    for variant_text in _query_variants(question, extra_variants):
        normalized = _normalize_query_text(variant_text)
        english_content_tokens: list[str] = []
        for token in normalized.split():
            compact = token.replace(" ", "")
            if _contains_cjk(compact):
                _append_term(compact)
                continue
            if len(compact) > 2 and compact not in _STOP_TERMS:
                english_content_tokens.append(compact)
            _append_term(compact)

        for idx in range(len(english_content_tokens) - 1):
            phrase = f"{english_content_tokens[idx]}{english_content_tokens[idx + 1]}"
            if len(phrase) > 6 and phrase not in seen:
                terms.append(phrase)
                seen.add(phrase)

        for token in re.findall(r"[A-Za-z][A-Za-z0-9_]+", variant_text):
            _append_term(_normalize_query_text(token).replace(" ", ""))

    return terms


def _classify_query_mode(question: str, terms: list[str] | None = None) -> str:
    terms = terms or _extract_query_terms(question)
    stripped = question.strip()
    normalized = _normalize_query_text(question)
    identifier_like = bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_\.]*", stripped))
    if identifier_like:
        return "entity"
    if any(marker in question for marker in _TASK_MARKERS[:10]) or any(marker in normalized for marker in _TASK_MARKERS[10:]):
        return "task"
    if len(terms) >= 4:
        return "task"
    if re.search(r"\b(api|apis|callback|callbacks|component|components|types?)\b", normalized):
        return "task"
    return "entity"


def _score_nodes(G: nx.Graph, terms: list[str]) -> list[tuple[float, str]]:
    scored = []
    norm_terms = [_normalize_query_text(t).replace(" ", "") for t in terms if _normalize_query_text(t)]
    for nid, data in G.nodes(data=True):
        label = data.get("label") or ""
        norm_label_spaced, norm_label_compact = _normalized_label_forms(data.get("norm_label") or label)
        source = _normalize_query_text(data.get("source_file") or "")
        source_compact = source.replace(" ", "")
        score = 0.0
        for t in norm_terms:
            if not t:
                continue
            if t == norm_label_compact:
                score += len(t)
            elif t in norm_label_compact:
                w = len(t) / 3.0
                score += w
            elif t in norm_label_spaced:
                score += len(t) / 4.0
            elif t in source_compact or t in source:
                score += len(t) / 6.0
        if score > 0:
            scored.append((score, nid))
    return sorted(scored, key=lambda x: x[0], reverse=True)


def _label_term_alignment_score(label: str, terms: list[str]) -> float:
    label_spaced, label_compact = _normalized_label_forms(label)
    label_tokens = set(label_spaced.split())
    score = 0.0
    for term in terms:
        normalized = _normalize_query_text(term)
        if not normalized:
            continue
        compact = normalized.replace(" ", "")
        if compact == label_compact:
            score += 2.0
            continue
        term_tokens = normalized.split()
        exact_hits = sum(1 for token in term_tokens if token in label_tokens)
        if exact_hits:
            score += exact_hits * 1.2
        elif compact and compact in label_compact:
            score += 0.4
    return score


def _query_role_alignment_score(label: str, terms: list[str]) -> float:
    """Score how well a label's role aligns with the query's intent.

    Instead of hard-coding role words (component, event, callback...),
    we find shared tokens between query and label that are NOT in the
    non-discriminative list.  Each shared specific token adds score;
    cross-role mismatches (query asks X, label is Y, both specific)
    subtract score.
    """
    label_tokens = set(_normalize_query_text(label).split())
    term_tokens: set[str] = set()
    for term in terms:
        term_tokens.update(_normalize_query_text(term).split())

    if not label_tokens or not term_tokens:
        return 0.0

    # Filter to discriminative tokens only (skip generic words)
    disc_label = label_tokens - _NON_DISCRIMINATIVE_TERMS
    disc_query = term_tokens - _NON_DISCRIMINATIVE_TERMS

    # Shared discriminative tokens = role alignment
    shared = disc_label & disc_query
    if shared:
        return len(shared) * 1.5

    # Cross-role penalty: query asks for a specific role, label has
    # a different specific role (both non-empty, no overlap)
    if disc_query and disc_label and not shared:
        return -1.2

    return 0.0


def _node_specificity_score(label: str, degree: int) -> float:
    spaced, compact = _normalized_label_forms(label)
    tokens = [token for token in spaced.split() if token]
    if not compact:
        return 0.0
    specificity = 0.0
    if len(compact) >= 8:
        specificity += 0.6
    if len(tokens) >= 2:
        specificity += 0.4
    if any(ch.isupper() for ch in label[1:]):
        specificity += 0.2
    if _is_generic_label(label):
        specificity -= 1.0
    specificity -= min(degree, 60) / 75.0
    return specificity


def _community_affinity_score(G: nx.Graph, node_id: str, reference_nodes: set[str]) -> float:
    if not reference_nodes:
        return 0.0
    node_community = G.nodes[node_id].get("community")
    reference_communities = {G.nodes[nid].get("community") for nid in reference_nodes if nid in G}
    score = 0.0
    if node_community in reference_communities:
        score += 0.8
    shared_neighbors = sum(1 for neighbor in G.neighbors(node_id) if neighbor in reference_nodes)
    score += min(shared_neighbors, 4) * 0.45
    return score


def _structural_seed_support_score(G: nx.Graph, node_id: str, lexical_frontier: set[str]) -> float:
    if not lexical_frontier:
        return 0.0
    support = _community_affinity_score(G, node_id, lexical_frontier - {node_id})
    support += min(G.degree(node_id), 20) / 25.0
    return support


def _parse_line_number(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    text = str(value)
    match = re.search(r"(\d+)", text)
    return int(match.group(1)) if match else None


def _node_line_span(data: dict) -> tuple[int | None, int | None]:
    start = _parse_line_number(data.get("start_line"))
    end = _parse_line_number(data.get("end_line"))
    source_location = str(data.get("source_location") or "")
    if start is None:
        match = re.search(r"L?(\d+)", source_location)
        if match:
            start = int(match.group(1))
    if end is None and source_location:
        match = re.search(r"L?(\d+)\D+L?(\d+)", source_location)
        if match:
            end = int(match.group(2))
    if end is None:
        end = start
    return start, end


def _node_raws(data: dict) -> list[str]:
    raws = data.get("raws")
    if isinstance(raws, list):
        return [str(item) for item in raws if str(item).strip()]
    raw = data.get("raw")
    if raw:
        return [str(raw)]
    return []


def _node_context(data: dict) -> str:
    return str(data.get("context") or data.get("file_type") or "")


def _node_authority_score(data: dict) -> float:
    context = _normalize_query_text(_node_context(data))
    source = _normalize_query_text(data.get("source_file") or "")
    score = 0.0
    if any(token in context for token in ("definition", "class", "interface", "api", "type")):
        score += 2.5
    if any(token in source for token in ("api", "core", "src", "reference", "resource", "ecs")):
        score += 0.8
    if any(token in context for token in ("reference", "usage")):
        score -= 0.4
    if any(token in source for token in ("sample", "example", "tutorial", "demo", "test")):
        score -= 1.2
    raws = " ".join(_node_raws(data)[:2]).lower()
    label = str(data.get("label") or "")
    if label and re.search(rf"\b(class|interface|struct|protocol|enum)\s+{re.escape(label)}\b", raws, re.IGNORECASE):
        score += 2.5
    return score


# ── Hub / generic-node detection (graph-structure based) ───────────────

_HUB_DEGREE_PERCENTILE = 0.95  # top 5% of nodes by degree are "hubs"
_HUB_MIN_DEGREE = 30           # absolute minimum degree to be a hub

# Minimal set of truly generic English tokens that carry no discriminative
# meaning regardless of graph structure.  Only used to filter query terms
# for discriminative_compacts — NOT for node-level filtering (which uses
# graph-derived hub_labels instead).
_NON_DISCRIMINATIVE_TERMS = frozenset({
    "component", "components", "system", "entity", "entities", "type", "types",
    "event", "events", "result", "results", "resource", "resources", "sample",
    "example", "examples", "interface", "api", "apis", "error", "state",
    "mode", "source", "callback", "control", "controller", "options", "config",
    "handler", "helper", "util", "utils", "data", "provider", "manager",
    "loading", "builder", "factory", "adapter", "wrapper", "constants",
})


def _compute_hub_labels(G: nx.Graph) -> set[str]:
    """Derive generic/hub labels from graph structure.

    Nodes in the top 5% by degree (and with degree >= _HUB_MIN_DEGREE)
    are hubs — their labels are too generic to be useful navigation targets
    (e.g., highly-connected hub nodes in a typical API graph).  This replaces
    the old hard-coded _GENERIC_LABELS table with a data-driven approach.
    """
    if G.number_of_nodes() == 0:
        return set()
    degrees = sorted(G.degree(n) for n in G.nodes)
    threshold_idx = max(0, int(len(degrees) * (1 - _HUB_DEGREE_PERCENTILE)))
    percentile_threshold = degrees[threshold_idx] if threshold_idx < len(degrees) else 0
    threshold = max(percentile_threshold, _HUB_MIN_DEGREE)
    hub_labels: set[str] = set()
    for nid in G.nodes:
        if G.degree(nid) >= threshold:
            label = str(G.nodes[nid].get("label") or "")
            _, compact = _normalized_label_forms(label)
            if compact:
                hub_labels.add(compact)
    return hub_labels


def _parse_god_labels_from_report(report_text: str) -> set[str]:
    """Parse god node labels from GRAPH_REPORT.md text.

    The god nodes section looks like:
        ## God Nodes (most connected - your core abstractions)
        1. `Client` - 26 edges
        2. `AsyncClient` - 25 edges

    Returns a set of label strings (e.g. {"Client", "AsyncClient"}).
    """
    god_labels: set[str] = set()
    in_god_section = False
    for line in report_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("## God Nodes"):
            in_god_section = True
            continue
        if in_god_section:
            if stripped.startswith("## ") or stripped == "":
                break
            m = re.match(r"^\d+\.\s+`([^`]+)`", stripped)
            if m:
                god_labels.add(m.group(1))
    return god_labels


def _is_generic_label(label: str, hub_labels: set[str] | None = None) -> bool:
    """Check if a label is too generic to be a useful navigation target.

    A label is generic if:
    - It matches a known non-discriminative term (short, context-free)
    - OR it's a short compact label (≤6 chars) that appears in hub_labels
    - OR all its tokens are non-discriminative

    Longer specific names (e.g., multi-token PascalCase) are
    NOT generic even if they appear in hub_labels — they have high
    degree because they are widely used, not because the label is vague.
    """
    spaced, compact = _normalized_label_forms(label)
    tokens = [token for token in spaced.split() if token]
    if not tokens:
        return True
    # Short labels matching non-discriminative terms are always generic
    if compact in _NON_DISCRIMINATIVE_TERMS:
        return True
    if len(tokens) == 1 and tokens[0].lower() in _NON_DISCRIMINATIVE_TERMS:
        return True
    if len(tokens) <= 2 and all(token.lower() in _NON_DISCRIMINATIVE_TERMS for token in tokens):
        return True
    # For hub_labels (graph-derived): only treat very short compact labels
    # as generic.  Specific names (multi-token PascalCase)
    # are NOT generic even if they are high-degree hubs.
    if hub_labels is not None and len(compact) <= 6 and compact in hub_labels:
        return True
    return False


def _is_noise_node(data: dict, hub_labels: set[str] | None = None) -> bool:
    label = str(data.get("label") or "")
    source = _normalize_query_text(data.get("source_file") or "")
    context = _normalize_query_text(_node_context(data))
    if _is_generic_label(label, hub_labels):
        return True
    if re.fullmatch(r"[a-z][a-z0-9_\- ]*", label) and _normalize_query_text(label) in _STOP_TERMS:
        return True
    if any(token in source for token in ("sample", "example", "tutorial", "demo", "test")):
        return True
    if any(token in context for token in ("sample", "example", "tutorial")):
        return True
    # Example code patterns: nodes defined inside doc-comment snippets
    # (e.g. "class CustomComponent : Component()" in a `* ` comment block)
    # rather than as real API definitions.
    raws = _node_raws(data)
    if raws and re.match(r"\s*\*\s*(class|interface|struct|enum)\s+", raws[0]):
        return True
    # Common example-class prefixes: Custom*, Sample*, Test*, Mock*, Stub*
    if re.match(r"^(Custom|Sample|Test|Mock|Stub|Fake|Dummy)[A-Z]", label):
        return True
    return False


def _edge_payload(G: nx.Graph, u: str, v: str) -> dict:
    raw = G[u][v]
    return next(iter(raw.values()), {}) if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)) else raw


def _get_out_neighbors(G: nx.Graph, node_id: str, relation: str | None = None) -> list[tuple[str, dict]]:
    """Get neighbors that are targets of outgoing edges from node_id.

    Uses _src/_tgt attributes to determine original edge direction.
    _src == node_id means the edge was originally node_id → neighbor (outgoing).
    """
    result = []
    for nb in G.neighbors(node_id):
        edge = _edge_payload(G, node_id, nb)
        if relation and edge.get("relation") != relation:
            continue
        if edge.get("_src") == node_id:
            result.append((nb, edge))
    return result


def _get_in_neighbors(G: nx.Graph, node_id: str, relation: str | None = None) -> list[tuple[str, dict]]:
    """Get neighbors that are sources of incoming edges to node_id.

    Uses _src/_tgt attributes to determine original edge direction.
    _tgt == node_id means the edge was originally neighbor → node_id (incoming).
    """
    result = []
    for nb in G.neighbors(node_id):
        edge = _edge_payload(G, node_id, nb)
        if relation and edge.get("relation") != relation:
            continue
        if edge.get("_tgt") == node_id:
            result.append((nb, edge))
    return result


def _relation_tokens(relation: str) -> set[str]:
    normalized = _normalize_query_text(relation)
    if not normalized:
        return set()
    tokens = set(normalized.split())
    compact = normalized.replace(" ", "")
    if compact:
        tokens.add(compact)
    return tokens


def _relation_family(relation: str) -> str:
    tokens = _relation_tokens(relation)
    if not tokens:
        return "association"
    if tokens & {"inherit", "inherits", "implement", "implements", "extend", "extends", "subclass", "override"}:
        return "hierarchy"
    if tokens & {"contain", "contains", "compose", "composes", "own", "owns", "member", "field", "method"}:
        return "structure"
    if tokens & {"use", "uses", "call", "calls", "invoke", "invokes", "render", "renders", "return", "returns", "emit", "emits", "listen", "listens", "attach", "attaches"}:
        return "behavior"
    if tokens & {"reference", "references", "import", "imports", "depend", "depends", "link", "links", "relate", "relates", "associate", "associates"}:
        return "association"
    if tokens & {"similar", "semantic", "analog", "analogy", "sameas", "equivalent"}:
        return "similarity"
    return "association"


def _relation_family_weight(relation: str, confidence: str = "") -> float:
    family = _relation_family(relation)
    base = {
        "hierarchy": 3.0,
        "structure": 2.5,
        "behavior": 2.0,
        "association": 1.4,
        "similarity": 0.7,
    }[family]
    confidence_bonus = {
        "EXTRACTED": 0.2,
        "INFERRED": 0.0,
        "AMBIGUOUS": -0.25,
    }.get(str(confidence or "").upper(), 0.0)
    return base + confidence_bonus


def _select_seed_nodes(G: nx.Graph, question: str, terms: list[str], top_k: int = 5, hub_labels: set[str] | None = None, god_labels: set[str] | None = None) -> list[dict[str, object]]:
    scored_nodes = _score_nodes(G, terms)
    if not scored_nodes:
        return []
    base_scores = {nid: score for score, nid in scored_nodes}
    lexical_frontier = {nid for _, nid in scored_nodes[: max(top_k * 3, 12)]}
    compact_question = _normalize_query_text(question).replace(" ", "")
    # Identify discriminative terms: those NOT matching generic/non-discriminative words.
    # Seeds that only match generic terms (e.g. "component") but miss
    # discriminative terms (e.g. "video") should be penalized.
    discriminative_compacts = set()
    for t in terms:
        tc = _normalize_query_text(t).replace(" ", "")
        if tc and tc not in _NON_DISCRIMINATIVE_TERMS and len(tc) > 2:
            discriminative_compacts.add(tc)
    scored: list[tuple[float, str, list[str]]] = []
    for nid, data in G.nodes(data=True):
        label = str(data.get("label") or "")
        _, label_compact = _normalized_label_forms(data.get("norm_label") or label)
        lexical_score = base_scores.get(nid, 0.0)
        score = lexical_score * 0.55
        reasons: list[str] = []
        if lexical_score > 0:
            reasons.append("direct lexical match")
        alignment = _label_term_alignment_score(label, terms)
        if alignment > 0:
            score += alignment * 0.5
            reasons.append("label aligns with task terms")
        role_alignment = _query_role_alignment_score(label, terms)
        if role_alignment != 0:
            score += role_alignment
            if role_alignment > 0:
                reasons.append("label matches the requested API role")
            else:
                reasons.append("label conflicts with the requested API role")
        if label_compact and label_compact in compact_question:
            score += len(label_compact) / 2.5
            reasons.append("exact label mentioned")
        authority = _node_authority_score(data)
        if authority > 0:
            score += min(authority, 2.2)
            reasons.append("definition-authority source")
        # Boost god nodes (most-connected nodes from GRAPH_REPORT.md)
        if god_labels and label in god_labels:
            score += 2.0
            reasons.append("god node (core abstraction)")
        specificity = _node_specificity_score(label, G.degree(nid))
        score += specificity
        if specificity > 0:
            reasons.append("label is specific enough to anchor a task")
        structural_support = _structural_seed_support_score(G, nid, lexical_frontier)
        if structural_support > 0:
            score += structural_support
            reasons.append("supported by nearby graph structure")
        if _is_noise_node(data, hub_labels):
            score -= 3.0
        # Enum/config types (ending in Mode, Flag, Type, etc.) make poor
        # navigation seeds — users ask about components, not enum values.
        if re.match(r".*(Mode|Flag|Type|Options|Config|Style|Format|Encoding|Space|Completed|Started|Stopped|Paused|Unknown)$", label):
            score -= 2.0
        # Penalize seeds that only match generic terms (e.g. "component")
        # but miss all discriminative terms (e.g. "video", "animation").
        if discriminative_compacts:
            label_spaced, label_compact = _normalized_label_forms(data.get("norm_label") or label)
            hits_discriminative = any(dt in label_compact or dt in label_spaced for dt in discriminative_compacts)
            if not hits_discriminative:
                score -= 5.0
        if score > 0:
            scored.append((score, nid, reasons))
    scored.sort(key=lambda item: item[0], reverse=True)
    if not scored:
        return []
    threshold = max(scored[0][0] * 0.65, 1.0)
    seeds: list[dict[str, object]] = []
    community_quota = max(top_k // 2, 2)
    community_count: dict[int, int] = {}
    for score, nid, reasons in scored:
        if len(seeds) >= top_k:
            break
        if score < threshold and seeds:
            break
        cid = G.nodes[nid].get("community")
        if cid is not None and community_count.get(cid, 0) >= community_quota:
            continue
        if cid is not None:
            community_count[cid] = community_count.get(cid, 0) + 1
        seeds.append({
            "node_id": nid,
            "seed_score": round(score, 4),
            "label": G.nodes[nid].get("label", nid),
            "reasons": reasons,
        })
    return seeds


def _expand_task_candidates(
    G: nx.Graph,
    seed_nodes: list[dict[str, object]],
    max_hops: int = 2,
    max_candidates: int = 50,
    max_degree: int = 0,
    discriminative_compacts: set[str] | None = None,
) -> dict[str, dict[str, object]]:
    discriminative_compacts = discriminative_compacts or set()
    candidates: dict[str, dict[str, object]] = {}
    seed_map = {str(seed["node_id"]): seed for seed in seed_nodes}
    for seed in seed_nodes:
        seed_id = str(seed["node_id"])
        seed_score = float(seed.get("seed_score", 0.0))
        queue: deque[tuple[str, int, list[str], list[dict[str, object]], float]] = deque()
        queue.append((seed_id, 0, [seed_id], [], 0.0))
        best_seen: dict[str, float] = {seed_id: 0.0}
        while queue:
            node_id, hops, path_nodes, relation_path, relation_score = queue.popleft()
            entry = candidates.setdefault(node_id, {
                "node_id": node_id,
                "seed_support": set(),
                "best_path_nodes": path_nodes,
                "best_relation_path": relation_path,
                "best_relation_score": relation_score,
                "best_seed_score": seed_score,
                "min_hops": hops,
            })
            entry["seed_support"].add(seed_id)
            if hops < int(entry["min_hops"]):
                entry["min_hops"] = hops
            if relation_score > float(entry["best_relation_score"]):
                entry["best_relation_score"] = relation_score
                entry["best_path_nodes"] = path_nodes
                entry["best_relation_path"] = relation_path
                entry["best_seed_score"] = seed_score
            if hops >= max_hops:
                continue
            for neighbor in G.neighbors(node_id):
                if neighbor in path_nodes:
                    continue
                if max_degree > 0 and G.degree(neighbor) > max_degree and neighbor not in seed_map:
                    continue
                edge = _edge_payload(G, node_id, neighbor)
                relation = str(edge.get("relation") or "")
                relation_family = _relation_family(relation)
                hop_gain = _relation_family_weight(relation, str(edge.get("confidence") or "")) - min(G.degree(neighbor), 50) / 60.0
                if _is_noise_node(G.nodes[neighbor]) and neighbor not in seed_map:
                    hop_gain -= 0.8
                next_score = relation_score + hop_gain
                if next_score <= best_seen.get(neighbor, float("-inf")) - 0.2:
                    continue
                best_seen[neighbor] = next_score
                queue.append((
                    neighbor,
                    hops + 1,
                    path_nodes + [neighbor],
                    relation_path + [{
                        "from": G.nodes[node_id].get("label", node_id),
                        "relation": relation,
                        "relation_family": relation_family,
                        "to": G.nodes[neighbor].get("label", neighbor),
                    }],
                    next_score,
                ))
    # Preserve 1-hop neighbors of seeds: they carry the core graph-hop
    # connectivity and must not be dropped by the candidate cap, even when
    # their high degree pushes them below the relation-score cutoff.
    # Also preserve 2-hop neighbors that pass through a query-relevant
    # 1-hop neighbor (e.g. Seed → specific node → related node).
    seed_1hop: set[str] = set()
    seed_2hop_relevant: set[str] = set()
    for seed in seed_nodes:
        sid = str(seed["node_id"])
        for nb in G.neighbors(sid):
            if nb != sid:
                seed_1hop.add(nb)
                # If this 1-hop neighbor matches query-discriminative terms,
                # also preserve its neighbors (2-hop from seed).
                nb_label = str(G.nodes[nb].get("label") or "")
                nb_norm = G.nodes[nb].get("norm_label") or nb_label
                nb_spaced, nb_compact = _normalized_label_forms(nb_norm)
                if any(dt in nb_compact or dt in nb_spaced for dt in discriminative_compacts):
                    for nb2 in G.neighbors(nb):
                        if nb2 != sid and nb2 not in seed_1hop:
                            seed_2hop_relevant.add(nb2)
    ranked_ids = sorted(
        candidates,
        key=lambda nid: (
            len(candidates[nid]["seed_support"]),
            float(candidates[nid]["best_relation_score"]),
            -int(candidates[nid]["min_hops"]),
        ),
        reverse=True,
    )
    # Always include 1-hop neighbors and query-relevant 2-hop neighbors
    # of seeds, even beyond max_candidates
    included: set[str] = set(ranked_ids[:max_candidates])
    for nid in ranked_ids[max_candidates:]:
        if nid in seed_1hop or nid in seed_2hop_relevant:
            included.add(nid)
    return {nid: candidates[nid] for nid in ranked_ids if nid in included}


def _semantic_tree_query(
    G: nx.Graph,
    init_nodes: list[str],
    discriminative_compacts: set[str],
    max_depth: int = 4,
    leaf_search_depth: int = 1,
    hub_labels: set[str] | None = None,
) -> list[dict[str, object]]:
    """Build a semantic tree from init_nodes and return leaf nodes in traversal order.

    Forward traversal: follow `uses` edges outward from init_nodes.
    Backward traversal: follow `inherits` edges upward to parent classes.
    Forward leaves come first (what the user is looking for),
    backward chain comes last (structural context, lower priority).

    Non-leaf intermediate nodes are deprioritized — only init_nodes and
    leaf nodes are primary results.

    leaf_search_depth: how many levels deep to check when determining
    if a node is a "leaf". Default 1 means only check immediate children.
    With leaf_search_depth=2, a node whose grandchildren all terminate
    (e.g., a concrete type → its leaf dependency → [noise]) is also
    considered a leaf, giving it higher ranking.
    """
    visited: set[str] = set()
    forward_results: list[dict[str, object]] = []
    backward_results: list[dict[str, object]] = []

    def _is_leaf_or_terminal(nid: str, remaining_depth: int | None = None) -> bool:
        """A node is a leaf if all forward `uses` paths terminate within
        leaf_search_depth levels. Checks recursively up to remaining_depth."""
        if remaining_depth is None:
            remaining_depth = leaf_search_depth
        for nb, edge in _get_out_neighbors(G, nid, "uses"):
            nb_data = G.nodes[nb]
            nb_label = str(nb_data.get("label", ""))
            if _is_noise_node(nb_data, hub_labels) or _is_generic_label(nb_label, hub_labels):
                continue
            # Found a non-noise, non-generic child
            if remaining_depth <= 1:
                # No more depth budget → this child proves nid is not a leaf
                return False
            # Recurse: if the child subtree also terminates, nid is still a leaf
            if not _is_leaf_or_terminal(nb, remaining_depth - 1):
                return False
        return True

    def _forward_expand(nid: str, depth: int, path: list[dict], parent_nid: str | None) -> None:
        """Pre-order forward traversal along `uses` edges."""
        if nid in visited or depth > max_depth:
            return
        visited.add(nid)
        data = G.nodes[nid]
        label = str(data.get("label") or "")
        is_init = nid in init_nodes

        # Get outgoing `uses` children
        children = []
        for nb, edge in _get_out_neighbors(G, nid, "uses"):
            nb_data = G.nodes[nb]
            nb_label = str(nb_data.get("label") or "")
            # Skip noise and generic labels
            if _is_noise_node(nb_data, hub_labels):
                continue
            if _is_generic_label(nb_label, hub_labels):
                continue
            children.append((nb, edge))

        # Determine if this is a leaf node
        is_leaf = len(children) == 0 or _is_leaf_or_terminal(nid)

        # Record non-init nodes (init_nodes are already known to the user)
        if not is_init:
            start_line, end_line = _node_line_span(data)
            entry = {
                "node_id": nid,
                "label": data.get("label", nid),
                "source_file": data.get("source_file", ""),
                "source_location": data.get("source_location", ""),
                "start_line": start_line,
                "end_line": end_line,
                "raws": _node_raws(data),
                "context": _node_context(data),
                "depth": depth,
                "is_leaf": is_leaf,
                "relation_path": path,
                "seed_support": [G.nodes[pn].get("label", pn) for pn in init_nodes if pn in G],
                "why_selected": [],
            }
            if is_leaf:
                entry["why_selected"].append("leaf node in semantic tree")
            else:
                entry["why_selected"].append("intermediate node in semantic tree")
            if path:
                entry["why_selected"].append("reached through query-relevant path")
            # Discriminative match bonus
            _, label_compact = _normalized_label_forms(data.get("norm_label") or label)
            if discriminative_compacts and any(dt in label_compact for dt in discriminative_compacts):
                entry["why_selected"].append("matches query keywords")
            forward_results.append(entry)

        # Recurse into children (pre-order: record self before children)
        for nb, edge in sorted(children, key=lambda x: str(G.nodes[x[0]].get("label", ""))):
            if nb in visited:
                continue
            step = {
                "from": label,
                "relation": "uses",
                "relation_family": "behavior",
                "to": str(G.nodes[nb].get("label", nb)),
            }
            _forward_expand(nb, depth + 1, path + [step], nid)

    def _backward_expand(nid: str, depth: int, path: list[dict]) -> None:
        """Follow `inherits` edges upward to parent classes."""
        if nid in visited or depth > 3:
            return
        # Follow inherits where _src == nid (nid is the child, parent is _tgt)
        for parent_nid, edge in _get_out_neighbors(G, nid, "inherits"):
            if parent_nid in visited:
                continue
            visited.add(parent_nid)
            parent_data = G.nodes[parent_nid]
            parent_label = str(parent_data.get("label") or "")
            start_line, end_line = _node_line_span(parent_data)
            step = {
                "from": str(G.nodes[nid].get("label", nid)),
                "relation": "inherits",
                "relation_family": "hierarchy",
                "to": parent_label,
            }
            new_path = path + [step]
            entry = {
                "node_id": parent_nid,
                "label": parent_label,
                "source_file": parent_data.get("source_file", ""),
                "source_location": parent_data.get("source_location", ""),
                "start_line": start_line,
                "end_line": end_line,
                "raws": _node_raws(parent_data),
                "context": _node_context(parent_data),
                "depth": depth,
                "is_leaf": False,
                "relation_path": new_path,
                "seed_support": [G.nodes[pn].get("label", pn) for pn in init_nodes if pn in G],
                "why_selected": ["parent class in inheritance chain"],
            }
            backward_results.append(entry)
            _backward_expand(parent_nid, depth + 1, new_path)

    # Forward traversal from each init_node
    # Note: _forward_expand adds nodes to visited itself (line 845),
    # so we must NOT pre-add init_nid here or _forward_expand will
    # skip it on the first `if nid in visited` check.
    for init_nid in init_nodes:
        if init_nid in visited:
            continue
        _forward_expand(init_nid, 0, [], None)

    # Include init_nodes as top results — they are the query's primary answers.
    init_entries: list[dict[str, object]] = []
    for init_nid in init_nodes:
        data = G.nodes[init_nid]
        label = str(data.get("label") or "")
        _, label_compact = _normalized_label_forms(data.get("norm_label") or label)
        start_line, end_line = _node_line_span(data)
        init_entries.append({
            "node_id": init_nid,
            "label": data.get("label", init_nid),
            "source_file": data.get("source_file", ""),
            "source_location": data.get("source_location", ""),
            "start_line": start_line,
            "end_line": end_line,
            "raws": _node_raws(data),
            "context": _node_context(data),
            "depth": 0,
            "is_leaf": False,
            "relation_path": [],
            "seed_support": [G.nodes[pn].get("label", pn) for pn in init_nodes if pn in G],
            "why_selected": ["seed node matching query keywords"],
            "_has_disc_match": any(dt in label_compact for dt in discriminative_compacts) if discriminative_compacts else False,
            "_is_enum_like": False,
        })

    # Reset visited for backward pass (allow revisiting forward nodes
    # since backward traversal goes in a different direction)
    backward_visited: set[str] = set(init_nodes)
    for init_nid in init_nodes:
        _backward_expand(init_nid, 1, [])

    # Merge: init_entries + forward results (sorted by discriminative match + depth),
    # then backward chain (structural context, lowest priority).
    #
    # Sorting priority for forward results:
    #   1. Discriminative keyword match (matches query intent)
    #   2. Depth (closer to init_node = more relevant)
    #   3. Leaf vs intermediate (leaves are more specific, slight bonus)
    #   4. Non-enum before enum (components > modes/flags)
    #
    # This ensures key targets with discriminative matches
    # rank above unrelated leaves.
    # Filter forward results: keep nodes that are either:
    #   - discriminative keyword matches (any depth)
    #   - depth ≤ 2 (close to init nodes, likely relevant)
    # This prunes deep branches that wandered into unrelated territory
    # (e.g., a hub node → its unrelated subtree → ...)
    filtered_forward = [
        r for r in forward_results
        if r.get("depth", 0) <= 2
        or any(dt in _normalized_label_forms(r.get("label", ""))[1] for dt in discriminative_compacts)
    ]

    # Combine init_entries + filtered_forward, set flags for sorting
    combined = init_entries + filtered_forward
    for r in combined:
        if "_has_disc_match" not in r:
            _, label_compact = _normalized_label_forms(r.get("label", ""))
            r["_has_disc_match"] = any(dt in label_compact for dt in discriminative_compacts) if discriminative_compacts else False
        if "_is_enum_like" not in r:
            _, label_compact = _normalized_label_forms(r.get("label", ""))
            r["_is_enum_like"] = bool(re.match(r".*(Mode|Flag|Type|Options|Config|Style|Format|Encoding|Space)$", label_compact, re.IGNORECASE))

    combined.sort(key=lambda r: (
        0 if r["_has_disc_match"] else 1,   # discriminative match first
        1 if r["_is_enum_like"] else 0,     # non-enum before enum at same disc level
        r.get("depth", 0),                    # closer to init = higher priority
        0 if r.get("is_leaf") else 1,         # at same depth+disc: leaves slightly preferred
    ))

    # Assign scores: forward results get highest, backward gets lowest
    # Discriminative match gets a large bonus (20 pts) so key targets
    # always rank above unrelated leaves.
    # Enum-like types get a small penalty since they're not "components".
    all_results: list[dict[str, object]] = []
    for i, r in enumerate(combined):
        disc_bonus = 20.0 if r.pop("_has_disc_match") else 0.0
        leaf_bonus = 1.0 if r.get("is_leaf") else 0.0
        enum_penalty = -5.0 if r.pop("_is_enum_like") else 0.0
        r["score"] = round(100.0 + disc_bonus + leaf_bonus + enum_penalty - i * 0.5 - r.get("depth", 0) * 2.0, 4)
        all_results.append(r)
    for i, r in enumerate(backward_results):
        r["score"] = round(10.0 - i * 0.5, 4)
        all_results.append(r)

    return all_results


def _rank_task_candidates(
    G: nx.Graph,
    question: str,
    terms: list[str],
    seeds: list[dict[str, object]],
    candidates: dict[str, dict[str, object]],
    limit: int = 10,
    discriminative_compacts: set[str] | None = None,
    hub_labels: set[str] | None = None,
) -> list[dict[str, object]]:
    del question
    discriminative_compacts = discriminative_compacts or set()
    direct_scores = {nid: score for score, nid in _score_nodes(G, terms)}
    seed_ids = {str(seed["node_id"]) for seed in seeds}
    seed_communities = {G.nodes[sid].get("community") for sid in seed_ids if sid in G}
    lexical_communities = {G.nodes[nid].get("community") for _, nid in _score_nodes(G, terms) if nid in G}
    ranked: list[dict[str, object]] = []
    for nid, meta in candidates.items():
        data = G.nodes[nid]
        label = str(data.get("label") or "")
        norm_label = data.get("norm_label") or label
        degree = G.degree(nid)
        label_spaced, label_compact = _normalized_label_forms(norm_label)

        # ── 1. Keyword relevance (primary gate) ──────────────────────
        # Nodes that don't match any query keyword should score ≈ 0,
        # regardless of graph connectivity.  This replaces hard-coded
        # noise / discriminative penalties with a principled gate.

        # 1a. Discriminative label match: how well does this node's label
        #     match the query-specific terms (e.g. "video", "animation")?
        #     This is the strongest signal — discriminative terms naturally
        #     separate relevant nodes from generic hub siblings.
        disc_match = 0.0
        for dt in discriminative_compacts:
            if dt in label_compact:
                disc_match += len(dt) / 2.5
            elif dt in label_spaced:
                disc_match += len(dt) / 3.0

        # 1b. Neighborhood discriminative match: for nodes whose own label
        #     doesn't match discriminative terms, check whether their graph
        #     neighbors (1-hop) include nodes that do match.  This captures
        #     the case where a non-matching node is adjacent to one that does
        #     match discriminative terms even if the best_relation_path goes through a
        #     generic hub.  The signal uses the best single discriminative
        #     neighbor match, boosted by having multiple such neighbors.
        #     Seeds and generic labels are excluded — adjacency to a seed
        #     alone should not create relevance.
        neighbor_disc = 0.0
        if not disc_match:
            disc_neighbor_count = 0
            best_disc_weight = 0.0
            for nb in G.neighbors(nid):
                if nb in seed_ids:
                    continue
                nb_label = str(G.nodes[nb].get("label", ""))
                if not nb_label or _is_generic_label(nb_label, hub_labels):
                    continue
                nb_spaced, nb_compact = _normalized_label_forms(nb_label)
                for dt in discriminative_compacts:
                    if dt in nb_compact:
                        best_disc_weight = max(best_disc_weight, len(dt) / 4.0)
                        disc_neighbor_count += 1
                        break
                    elif dt in nb_spaced:
                        best_disc_weight = max(best_disc_weight, len(dt) / 5.0)
                        disc_neighbor_count += 1
                        break
            if disc_neighbor_count >= 2:
                # Base signal from best matching neighbor, boosted by count
                # (2+ discriminative neighbors = stronger signal)
                neighbor_disc = best_disc_weight * min(disc_neighbor_count, 4) / 2.0

        # 1c. Generic term match (weak baseline): matching "component" alone
        #     should not push a node high.  It only provides a minimal floor
        #     so that seeds and direct neighbors aren't zeroed out entirely.
        generic_match = _label_term_alignment_score(label, terms) * 0.08

        # 1d. Role alignment (amplifier, not gate): a node whose label
        #     matches the requested role (e.g. "component" for a query
        #     asking for "components") should be amplified IF it already
        #     has keyword relevance.  It must NOT create relevance on its
        #     own — otherwise a generic node passes the gate just
        #     because it contains a common token.
        role_alignment = _query_role_alignment_score(label, terms)

        # Combined keyword relevance: discriminative match gates,
        # generic adds a tiny floor for seeds, role amplifies ONLY
        # direct discriminative match (not indirect neighbor match).
        keyword_relevance = max(disc_match, neighbor_disc)
        if disc_match > 0 and role_alignment > 0:
            keyword_relevance *= (1.0 + role_alignment * 0.25)
        keyword_relevance += generic_match

        # Seeds always pass the gate (they were selected for a reason)
        if nid in seed_ids:
            seed_kw = float(meta.get("best_seed_score", 0.0)) * 0.3
            keyword_relevance = max(keyword_relevance, 1.0, seed_kw)

        # Lexical backfill: these nodes matched terms directly in _score_nodes
        if meta.get("lexical_backfill") and direct_scores.get(nid, 0.0) > 0:
            backfill_kw = direct_scores.get(nid, 0.0) * 0.2
            node_community = data.get("community")
            if node_community is not None and node_community in lexical_communities:
                backfill_kw += 0.5
            keyword_relevance = max(keyword_relevance, backfill_kw)

        # ── 2. Specificity factor (degree-based dampening) ───────────
        # High-degree hubs are less specific navigation targets for a
        # particular query.  This replaces hard-coded degree penalties
        # with a smooth inverse function.
        specificity = 1.0 / (1.0 + min(degree, 60) / 30.0)
        # Extra dampening for labels that are entirely generic
        if _is_generic_label(label, hub_labels):
            specificity *= 0.3
        # Slight boost for specific labels (long, multi-token, camelCase)
        tokens = [t for t in label_spaced.split() if t]
        if len(label_compact) >= 8:
            specificity *= 1.15
        if len(tokens) >= 2:
            specificity *= 1.1

        # ── 3. Structural relevance (graph context amplifier) ─────────
        # Graph connectivity amplifies keyword-relevant nodes but cannot
        # override a zero keyword gate.
        expansion_score = float(meta.get("best_relation_score", 0.0))
        structural = 0.0
        # Seed support: how many seeds can reach this node, but only count
        # support via discriminative paths (direct edge or through a
        # non-generic intermediate).  Support via generic hubs (e.g.
        # specific_node → generic_hub → unrelated_node) is meaningless
        # because Component connects to everything.
        effective_seed_support = 0
        for sid in meta.get("seed_support", set()):
            # Direct neighbor always counts
            if sid in G and G.has_edge(nid, sid):
                effective_seed_support += 1
                continue
            # Indirect: count if this node has discriminative neighbors
            # (excluding seeds).  A discriminative neighbor means the node
            # is in a query-relevant part of the graph, not just reachable
            # through a generic hub.
            if neighbor_disc > 0:
                effective_seed_support += 1
        structural += effective_seed_support * 0.3
        # Community overlap with seeds
        if data.get("community") in seed_communities:
            structural += 0.5
        structural += _community_affinity_score(G, nid, seed_ids) * 0.3
        # Path quality
        structural += max(expansion_score, 0.0) * 0.15
        # Relation count
        structural += 0.15 * len(meta.get("best_relation_path", []))
        # Direct seed neighbor bonus
        if nid not in seed_ids:
            for sid in meta.get("seed_support", set()):
                if sid in G and G.has_edge(nid, sid):
                    slabel = str(G.nodes[sid].get("label") or "")
                    s_align = _label_term_alignment_score(slabel, terms)
                    s_deg = max(G.degree(sid), 1)
                    s_spec = s_align / s_deg
                    if s_spec > 0.02:
                        structural += s_spec * 15.0

        # ── 4. Authority bonus (additive, small) ─────────────────────
        authority = _node_authority_score(data) * 0.4

        # ── 5. Final score (keyword-gated multiplicative) ────────────
        # keyword_relevance is the gate: without meaningful keyword match,
        # score ≈ 0 regardless of structural connectivity.
        # A tiny keyword_relevance (e.g. 0.096 from generic "component"
        # match) should not be amplified by structural into a high score.
        if keyword_relevance < 0.5 and nid not in seed_ids:
            continue
        # structural amplifies keyword-relevant nodes
        # specificity dampens generic hubs
        final_score = keyword_relevance * (1.0 + structural) * specificity + authority

        # Filter out structural noise (doc snippets, example classes)
        if _is_noise_node(data) and nid not in seed_ids:
            continue
        if final_score <= 0:
            continue

        why_selected: list[str] = []
        if disc_match > 0:
            why_selected.append("matches query keywords")
        elif generic_match > 0:
            why_selected.append("matches query terms")
        if neighbor_disc > 0:
            why_selected.append("reached through query-relevant path")
        if nid in seed_ids:
            why_selected.append("selected as a high-confidence seed")
        if len(meta.get("seed_support", set())) > 1:
            why_selected.append(f"connected to {len(meta['seed_support'])} seed nodes")
        if authority > 0.4:
            why_selected.append("comes from a definition-authority source")
        if expansion_score > 1.5 and meta.get("best_relation_path"):
            why_selected.append("reached through high-value graph relations")
        ranked.append({
            "node_id": nid,
            "label": data.get("label", nid),
            "score": round(final_score, 4),
            "seed_score": round(float(meta.get("best_seed_score", 0.0)) + generic_match, 4),
            "expansion_score": round(expansion_score, 4),
            "authority_score": round(authority, 4),
            "relation_score": round(0.15 * len(meta.get("best_relation_path", [])), 4),
            "community_score": round(_community_affinity_score(G, nid, seed_ids), 4),
            "specificity_score": round(specificity, 4),
            "noise_penalty": 0.0,
            "why_selected": why_selected,
            "relation_path": meta.get("best_relation_path", []),
            "path_nodes": meta.get("best_path_nodes", [nid]),
            "min_hops": int(meta.get("min_hops", 0)),
            "seed_support": [G.nodes[sid].get("label", sid) for sid in sorted(meta.get("seed_support", set()))],
        })
        ranked.sort(key=lambda item: (float(item["score"]), -int(item["min_hops"])), reverse=True)
    # Result diversity: cap results per community so diverse regions appear.
    _COMMUNITY_CAP = 6
    exempt_ids = set(seed_ids)
    for sid in seed_ids:
        if sid in G:
            exempt_ids.update(str(nb) for nb in G.neighbors(sid))
    if discriminative_compacts:
        for item in ranked:
            nid = item["node_id"]
            if nid in exempt_ids:
                continue
            data = G.nodes[nid]
            label_spaced_d, label_compact_d = _normalized_label_forms(data.get("norm_label") or str(data.get("label") or ""))
            if any(dt in label_compact_d or dt in label_spaced_d for dt in discriminative_compacts):
                exempt_ids.add(nid)
    community_count: dict[int | None, int] = {}
    diverse: list[dict[str, object]] = []
    for item in ranked:
        nid = item["node_id"]
        cid = G.nodes[nid].get("community") if nid in G else None
        current = community_count.get(cid, 0)
        if current >= _COMMUNITY_CAP and nid not in exempt_ids:
            continue
        community_count[cid] = current + 1
        diverse.append(item)
    return diverse[:limit]


def _task_results_to_json(G: nx.Graph, question: str, terms: list[str], seeds: list[dict[str, object]], ranked_results: list[dict[str, object]]) -> dict[str, object]:
    results: list[dict[str, object]] = []
    for item in ranked_results:
        data = G.nodes[item["node_id"]]
        start_line, end_line = _node_line_span(data)
        result = {
            "node_id": item["node_id"],
            "label": data.get("label", item["node_id"]),
            "source_file": data.get("source_file", ""),
            "source_location": data.get("source_location", ""),
            "start_line": start_line,
            "end_line": end_line,
            "raws": _node_raws(data),
            "context": _node_context(data),
            "score": item["score"],
            "why_selected": item["why_selected"],
            "relation_path": item["relation_path"],
            "seed_support": item["seed_support"],
        }
        # Preserve semantic tree traversal fields if present
        for extra_key in ("is_leaf", "depth"):
            if extra_key in item:
                result[extra_key] = item[extra_key]
        results.append(result)
    return {
        "question": question,
        "query_mode": "task",
        "terms": terms,
        "seeds": [
            {
                "node_id": str(seed["node_id"]),
                "label": seed.get("label", seed["node_id"]),
                "score": seed.get("seed_score", 0.0),
                "reasons": seed.get("reasons", []),
            }
            for seed in seeds
        ],
        "results": results,
    }


def _task_results_to_text(payload: dict[str, object]) -> str:
    results = payload.get("results", [])
    if not results:
        return "No matching nodes found."
    seeds = ", ".join(seed.get("label", str(seed.get("node_id", ""))) for seed in payload.get("seeds", []))
    lines = [f"Task query | Seeds: {seeds}"]
    for index, result in enumerate(results, 1):
        source_file = str(result.get("source_file") or "")
        start_line = result.get("start_line")
        end_line = result.get("end_line")
        details: list[str] = []
        if source_file:
            details.append(source_file)
        if start_line is not None and end_line is not None:
            details.append(f"L{start_line}-{end_line}")
        elif start_line is not None:
            details.append(f"L{start_line}")
        detail_str = f" [{', '.join(details)}]" if details else ""
        lines.append(f"{index}. {sanitize_label(str(result.get('label', '')))}{detail_str}")
        # path omitted for cleaner output
    return "\n".join(lines)


def _query_graph(
    G: nx.Graph,
    question: str,
    traversal_mode: str = "bfs",
    depth: int = 2,
    token_budget: int = 2000,
    max_degree: int = 0,
    sort_by: str = "degree",
    json_output: bool = False,
    query_variants: list[str] | None = None,
    leaf_search_depth: int = 1,
    god_labels: set[str] | None = None,
) -> dict[str, object]:
    query_texts = _query_variants(question, query_variants)
    terms = _extract_query_terms(question, query_texts[1:])
    query_mode = _classify_query_mode(question, terms)
    # Compute hub labels from graph structure (replaces hard-coded _GENERIC_LABELS)
    hub_labels = _compute_hub_labels(G)
    if query_mode == "task":
        seeds = _select_seed_nodes(G, question, terms, top_k=5, hub_labels=hub_labels, god_labels=god_labels)
        if not seeds:
            return {
                "question": question,
                "query_variants": query_texts,
                "query_mode": query_mode,
                "terms": terms,
                "seeds": [],
                "results": [],
                "text": "No matching nodes found.",
            }
        # Compute discriminative terms for candidate expansion
        discriminative_compacts: set[str] = set()
        for t in terms:
            tc = _normalize_query_text(t).replace(" ", "")
            if tc and tc not in _NON_DISCRIMINATIVE_TERMS and len(tc) > 2:
                discriminative_compacts.add(tc)
        # Semantic tree traversal: follow uses/inherits edges from seeds
        seed_ids = [str(seed["node_id"]) for seed in seeds]
        ranked = _semantic_tree_query(G, seed_ids, discriminative_compacts, max_depth=min(depth, 4), leaf_search_depth=leaf_search_depth, hub_labels=hub_labels)
        # If tree traversal found too few results, fall back to BFS + ranking
        if len(ranked) < 3:
            candidates = _expand_task_candidates(G, seeds, max_hops=min(depth, 3), max_candidates=150, max_degree=max_degree, discriminative_compacts=discriminative_compacts)
            candidate_ids = set(candidates.keys())
            lexical_scored = _score_nodes(G, terms)
            for score, nid in lexical_scored:
                if nid not in candidate_ids and nid not in set(seed_ids):
                    candidates[nid] = {
                        "best_seed_score": 0.0,
                        "best_relation_score": 0.0,
                        "best_relation_path": [],
                        "best_path_nodes": [nid],
                        "min_hops": 3,
                        "seed_support": set(),
                        "lexical_backfill": True,
                    }
            ranked = _rank_task_candidates(G, question, terms, seeds, candidates, limit=50, discriminative_compacts=discriminative_compacts, hub_labels=hub_labels)
        payload = _task_results_to_json(G, question, terms, seeds, ranked)
        payload["query_variants"] = query_texts
        payload["text"] = _task_results_to_text(payload)
        return payload

    scored = _score_nodes(G, terms)
    if not scored:
        return {
            "question": question,
            "query_variants": query_texts,
            "query_mode": query_mode,
            "terms": terms,
            "start_nodes": [],
            "results": [],
            "text": "No matching nodes found.",
        }
    top_score = scored[0][0]
    threshold = top_score * 0.5
    start_nodes = [nid for s, nid in scored[:5] if s >= threshold]
    if not start_nodes:
        return {
            "question": question,
            "query_variants": query_texts,
            "query_mode": query_mode,
            "terms": terms,
            "start_nodes": [],
            "results": [],
            "text": "No matching nodes found.",
        }
    nodes, edges = (_dfs if traversal_mode == "dfs" else _bfs)(G, start_nodes, depth=depth, max_degree=max_degree)
    text = _subgraph_to_text(G, nodes, edges, token_budget=token_budget, sort_by=sort_by, start_nodes=start_nodes)
    results: list[dict[str, object]] = []
    for score, nid in scored[:10]:
        data = G.nodes[nid]
        start_line, end_line = _node_line_span(data)
        results.append({
            "node_id": nid,
            "label": data.get("label", nid),
            "source_file": data.get("source_file", ""),
            "source_location": data.get("source_location", ""),
            "start_line": start_line,
            "end_line": end_line,
            "raws": _node_raws(data),
            "context": _node_context(data),
            "score": round(score, 4),
            "why_selected": ["highest lexical match" if nid == start_nodes[0] else "lexical match"],
            "relation_path": [],
        })
    payload = {
        "question": question,
        "query_variants": query_texts,
        "query_mode": query_mode,
        "terms": terms,
        "start_nodes": [G.nodes[nid].get("label", nid) for nid in start_nodes],
        "results": results,
        "text": text if not json_output else text,
    }
    return payload


def _bfs(G: nx.Graph, start_nodes: list[str], depth: int, max_degree: int = 0) -> tuple[set[str], list[tuple]]:
    visited: set[str] = set(start_nodes)
    frontier = set(start_nodes)
    edges_seen: list[tuple] = []
    for _ in range(depth):
        next_frontier: set[str] = set()
        hub_nodes: set[str] = set()
        for n in frontier:
            for neighbor in G.neighbors(n):
                if neighbor not in visited and neighbor not in hub_nodes:
                    if max_degree > 0 and G.degree(neighbor) > max_degree:
                        hub_nodes.add(neighbor)
                    else:
                        next_frontier.add(neighbor)
                    edges_seen.append((n, neighbor))
        visited.update(next_frontier)
        visited.update(hub_nodes)
        frontier = next_frontier
    return visited, edges_seen


def _dfs(G: nx.Graph, start_nodes: list[str], depth: int, max_degree: int = 0) -> tuple[set[str], list[tuple]]:
    visited: set[str] = set()
    hub_visited: set[str] = set()
    edges_seen: list[tuple] = []
    stack = [(n, 0) for n in reversed(start_nodes)]
    while stack:
        node, d = stack.pop()
        if node in visited or d > depth:
            continue
        visited.add(node)
        for neighbor in G.neighbors(node):
            if neighbor in visited or neighbor in hub_visited:
                continue
            if max_degree > 0 and G.degree(neighbor) > max_degree:
                hub_visited.add(neighbor)
                edges_seen.append((node, neighbor))
                continue
            stack.append((neighbor, d + 1))
            edges_seen.append((node, neighbor))
    visited.update(hub_visited)
    return visited, edges_seen


def _subgraph_to_text(G: nx.Graph, nodes: set[str], edges: list[tuple], token_budget: int = 2000, sort_by: str = "degree", start_nodes: list[str] | None = None) -> str:
    """Render subgraph as text, cutting at token_budget (approx 3 chars/token).

    Args:
        sort_by: "degree" (default, hub nodes first) or "relevance" (start_nodes first,
                 then by degree). When "relevance" is used, start_nodes must be provided.
        start_nodes: Node IDs used as traversal starting points. Used only when
                     sort_by="relevance" to prioritize query targets.
    """
    char_budget = token_budget * 3
    lines = []

    if sort_by == "relevance" and start_nodes:
        start_set = set(start_nodes)
        # Start nodes first (in their original score order), then rest by degree
        ordered_start = [n for n in start_nodes if n in nodes]
        rest = sorted((n for n in nodes if n not in start_set), key=lambda n: G.degree(n), reverse=True)
        ordered = ordered_start + rest
    else:
        ordered = sorted(nodes, key=lambda n: G.degree(n), reverse=True)

    for nid in ordered:
        d = G.nodes[nid]
        line = f"NODE {sanitize_label(d.get('label', nid))} [src={d.get('source_file', '')} loc={d.get('source_location', '')} community={d.get('community', '')}]"
        lines.append(line)
    for u, v in edges:
        if u in nodes and v in nodes:
            raw = G[u][v]
            d = next(iter(raw.values()), {}) if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)) else raw
            line = f"EDGE {sanitize_label(G.nodes[u].get('label', u))} --{d.get('relation', '')} [{d.get('confidence', '')}]--> {sanitize_label(G.nodes[v].get('label', v))}"
            lines.append(line)
    output = "\n".join(lines)
    if len(output) > char_budget:
        output = output[:char_budget] + f"\n... (truncated to ~{token_budget} token budget)"
    return output


def _find_node(G: nx.Graph, label: str) -> list[str]:
    """Return node IDs whose label or ID matches the search term (diacritic-insensitive)."""
    term = _strip_diacritics(label).lower()
    return [nid for nid, d in G.nodes(data=True)
            if term in (d.get("norm_label") or _strip_diacritics(d.get("label") or "").lower())
            or term == nid.lower()]


def _filter_blank_stdin() -> None:
    """Filter blank lines from stdin before MCP reads it.

    Some MCP clients (Claude Desktop, etc.) send blank lines between JSON
    messages. The MCP stdio transport tries to parse every line as a
    JSONRPCMessage, so a bare newline triggers a Pydantic ValidationError.
    This installs an OS-level pipe that relays stdin while dropping blanks.
    """
    import os
    import threading

    r_fd, w_fd = os.pipe()
    saved_fd = os.dup(sys.stdin.fileno())

    def _relay() -> None:
        try:
            with open(saved_fd, "rb") as src, open(w_fd, "wb") as dst:
                for line in src:
                    if line.strip():
                        dst.write(line)
                        dst.flush()
        except Exception:
            pass

    threading.Thread(target=_relay, daemon=True).start()
    os.dup2(r_fd, sys.stdin.fileno())
    os.close(r_fd)
    sys.stdin = open(0, "r", closefd=False)


def serve(graph_path: str = "graphify-out/graph.json", workspace: str | None = None) -> None:
    """Start the MCP server. Requires pip install mcp."""
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        from mcp import types
        from mcp.types import AnyUrl
    except ImportError as e:
        raise ImportError("mcp not installed. Run: pip install mcp") from e

    # If --workspace is provided, set it as GRAPHIFY_WORKSPACE so all
    # path resolution functions pick it up without explicit parameter passing.
    if workspace:
        os.environ["GRAPHIFY_WORKSPACE"] = workspace

    G = _load_graph(_resolve_graph_path(graph_path))
    communities = _communities_from_graph(G)

    # Parse god node labels from GRAPH_REPORT.md for seed selection boost
    _resolved_graph_dir = Path(_resolve_graph_path(graph_path)).parent
    _report_path = _resolved_graph_dir / "GRAPH_REPORT.md"
    _god_labels: set[str] = set()
    if _report_path.exists():
        try:
            _god_labels = _parse_god_labels_from_report(_report_path.read_text(encoding="utf-8"))
        except Exception:
            pass  # Graceful fallback: no boost if report is malformed

    server = Server("graphify")

    @server.list_tools()
    async def list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name="query_graph",
                description="Search the knowledge graph using BFS or DFS. Returns relevant nodes and edges as text context.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "question": {"type": "string", "description": "Natural language question or keyword search"},
                        "mode": {"type": "string", "enum": ["bfs", "dfs"], "default": "bfs",
                                 "description": "bfs=broad context, dfs=trace a specific path"},
                        "depth": {"type": "integer", "default": 3, "description": "Traversal depth (1-6)"},
                        "token_budget": {"type": "integer", "default": 2000, "description": "Max output tokens"},
                        "max_degree": {"type": "integer", "default": 0, "description": "Stop traversal at nodes with degree > this value (0=unlimited). Filters hub/super nodes."},
                        "query_variants": {"type": "array", "items": {"type": "string"}, "description": "Optional alternate phrasings or rewrites of the same question. Useful for cross-language or terminology expansion."},
                        "sort_by": {"type": "string", "enum": ["degree", "relevance"], "default": "degree",
                                    "description": "Node sort order: 'degree' (hub nodes first) or 'relevance' (query targets first)"},
                    },
                    "required": ["question"],
                },
            ),
            types.Tool(
                name="get_node",
                description="Get full details for a specific node by label or ID.",
                inputSchema={
                    "type": "object",
                    "properties": {"label": {"type": "string", "description": "Node label or ID to look up"}},
                    "required": ["label"],
                },
            ),
            types.Tool(
                name="get_neighbors",
                description="Get all direct neighbors of a node with edge details.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "label": {"type": "string"},
                        "relation_filter": {"type": "string", "description": "Optional: filter by relation type"},
                    },
                    "required": ["label"],
                },
            ),
            types.Tool(
                name="get_community",
                description="Get all nodes in a community by community ID.",
                inputSchema={
                    "type": "object",
                    "properties": {"community_id": {"type": "integer", "description": "Community ID (0-indexed by size)"}},
                    "required": ["community_id"],
                },
            ),
            types.Tool(
                name="god_nodes",
                description="Return the most connected nodes - the core abstractions of the knowledge graph.",
                inputSchema={"type": "object", "properties": {"top_n": {"type": "integer", "default": 10}}},
            ),
            types.Tool(
                name="graph_stats",
                description="Return summary statistics: node count, edge count, communities, confidence breakdown.",
                inputSchema={"type": "object", "properties": {}},
            ),
            types.Tool(
                name="shortest_path",
                description="Find the shortest path between two concepts in the knowledge graph.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "source": {"type": "string", "description": "Source concept label or keyword"},
                        "target": {"type": "string", "description": "Target concept label or keyword"},
                        "max_hops": {"type": "integer", "default": 8, "description": "Maximum hops to consider"},
                    },
                    "required": ["source", "target"],
                },
            ),
            types.Tool(
                name="switch_workspace",
                description="Switch to a different graphify-out workspace (e.g. different version). Hot-reloads the graph without restarting the MCP server.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "workspace": {"type": "string", "description": "Path to the new workspace directory (contains graphify-out/)"},
                    },
                    "required": ["workspace"],
                },
            ),
        ]

    def _tool_query_graph(arguments: dict) -> str:
        question = arguments["question"]
        mode = arguments.get("mode", "bfs")
        depth = min(int(arguments.get("depth", 3)), 6)
        budget = int(arguments.get("token_budget", 2000))
        max_degree = int(arguments.get("max_degree", 0))
        sort_by = arguments.get("sort_by", "degree")
        query_variants = [str(item) for item in arguments.get("query_variants", []) if str(item).strip()]
        payload = _query_graph(
            G,
            question,
            traversal_mode=mode,
            depth=depth,
            token_budget=budget,
            max_degree=max_degree,
            sort_by=sort_by,
            query_variants=query_variants,
            god_labels=_god_labels,
        )
        if payload.get("query_mode") == "task":
            return str(payload.get("text", "No matching nodes found."))
        start_nodes = payload.get("start_nodes", [])
        results = payload.get("results", [])
        if not start_nodes:
            return "No matching nodes found."
        header = f"Traversal: {mode.upper()} depth={depth} max_degree={max_degree or '∞'} | Start: {start_nodes} | {len(results)} ranked matches\n\n"
        return header + str(payload.get("text", ""))

    def _tool_get_node(arguments: dict) -> str:
        label = arguments["label"].lower()
        matches = [(nid, d) for nid, d in G.nodes(data=True)
                   if label in (d.get("label") or "").lower() or label == nid.lower()]
        if not matches:
            return f"No node matching '{label}' found."
        # Pick the highest-degree node among same-label matches
        matches.sort(key=lambda x: G.degree(x[0]), reverse=True)
        nid, d = matches[0]
        # Show merged degree info when multiple same-label nodes exist
        same_label_nodes = [m for m in matches if (m[1].get("label") or "").lower() == label]
        degree_line = f"  Degree: {G.degree(nid)}"
        if len(same_label_nodes) > 1:
            merged = sum(G.degree(m[0]) for m in same_label_nodes)
            degree_line += f" (merged: {merged} across {len(same_label_nodes)} instances)"
        # Show merged sources when available
        source_files = d.get("source_files", [d.get("source_file", "")])
        source_line = f"  Source: {d.get('source_file', '')} {d.get('source_location', '')}"
        if len(source_files) > 1:
            source_line += f"\n  Merged from: {', '.join(source_files)}"
        return "\n".join([
            f"Node: {d.get('label', nid)}",
            f"  ID: {nid}",
            source_line,
            f"  Type: {d.get('file_type', '')}",
            f"  Community: {d.get('community', '')}",
            degree_line,
        ])

    def _tool_get_neighbors(arguments: dict) -> str:
        label = arguments["label"].lower()
        rel_filter = arguments.get("relation_filter", "").lower()
        matches = _find_node(G, label)
        if not matches:
            return f"No node matching '{label}' found."
        # Pick the highest-degree node among matches
        nid = max(matches, key=lambda m: G.degree(m))
        lines = [f"Neighbors of {G.nodes[nid].get('label', nid)}:"]
        seen_labels: set[str] = set()
        for neighbor in G.neighbors(nid):
            nb_label = G.nodes[neighbor].get('label', neighbor)
            d = _edge_payload(G, nid, neighbor)
            rel = d.get("relation", "")
            if rel_filter and rel_filter not in rel.lower():
                continue
            # Deduplicate same neighbor label (MultiGraph may have multiple edges)
            if nb_label in seen_labels:
                continue
            seen_labels.add(nb_label)
            lines.append(f"  --> {nb_label} [{rel}] [{d.get('confidence', '')}]")
        return "\n".join(lines)

    def _tool_get_community(arguments: dict) -> str:
        cid = int(arguments["community_id"])
        nodes = communities.get(cid, [])
        if not nodes:
            return f"Community {cid} not found."
        lines = [f"Community {cid} ({len(nodes)} nodes):"]
        for n in nodes:
            d = G.nodes[n]
            lines.append(f"  {d.get('label', n)} [{d.get('source_file', '')}]")
        return "\n".join(lines)

    def _tool_god_nodes(arguments: dict) -> str:
        from .analyze import god_nodes as _god_nodes
        nodes = _god_nodes(G, top_n=int(arguments.get("top_n", 10)))
        lines = ["God nodes (most connected):"]
        lines += [f"  {i}. {n['label']} - {n['degree']} edges" for i, n in enumerate(nodes, 1)]
        return "\n".join(lines)

    def _tool_graph_stats(_: dict) -> str:
        confs = [d.get("confidence", "EXTRACTED") for _, _, d in G.edges(data=True)]
        total = len(confs) or 1
        return (
            f"Nodes: {G.number_of_nodes()}\n"
            f"Edges: {G.number_of_edges()}\n"
            f"Communities: {len(communities)}\n"
            f"EXTRACTED: {round(confs.count('EXTRACTED')/total*100)}%\n"
            f"INFERRED: {round(confs.count('INFERRED')/total*100)}%\n"
            f"AMBIGUOUS: {round(confs.count('AMBIGUOUS')/total*100)}%\n"
        )

    def _tool_shortest_path(arguments: dict) -> str:
        src_scored = _score_nodes(G, [t.lower() for t in arguments["source"].split()])
        tgt_scored = _score_nodes(G, [t.lower() for t in arguments["target"].split()])
        if not src_scored:
            return f"No node matching source '{arguments['source']}' found."
        if not tgt_scored:
            return f"No node matching target '{arguments['target']}' found."
        # Among top-scored nodes, prefer highest degree to avoid picking
        # low-degree same-label instances (e.g. Entity deg=3 vs deg=473)
        top_src_score = src_scored[0][0]
        src_candidates = [nid for s, nid in src_scored if s >= top_src_score * 0.9]
        top_tgt_score = tgt_scored[0][0]
        tgt_candidates = [nid for s, nid in tgt_scored if s >= top_tgt_score * 0.9]
        src_nid = max(src_candidates, key=lambda n: G.degree(n))
        tgt_nid = max(tgt_candidates, key=lambda n: G.degree(n))
        max_hops = int(arguments.get("max_hops", 8))
        try:
            path_nodes = nx.shortest_path(G, src_nid, tgt_nid)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return f"No path found between '{G.nodes[src_nid].get('label', src_nid)}' and '{G.nodes[tgt_nid].get('label', tgt_nid)}'."
        hops = len(path_nodes) - 1
        if hops > max_hops:
            return f"Path exceeds max_hops={max_hops} ({hops} hops found)."
        segments = []
        for i in range(len(path_nodes) - 1):
            u, v = path_nodes[i], path_nodes[i + 1]
            edata = _edge_payload(G, u, v)
            rel = edata.get("relation", "")
            conf = edata.get("confidence", "")
            conf_str = f" [{conf}]" if conf else ""
            if i == 0:
                segments.append(G.nodes[u].get("label", u))
            segments.append(f"--{rel}{conf_str}--> {G.nodes[v].get('label', v)}")
        return f"Shortest path ({hops} hops):\n  " + " ".join(segments)

    def _tool_switch_workspace(arguments: dict) -> str:
        nonlocal G, communities, _god_labels
        ws_path = arguments["workspace"]
        new_graph_path = str(Path(ws_path) / "graphify-out" / "graph.json")
        try:
            os.environ["GRAPHIFY_WORKSPACE"] = ws_path
            G = _load_graph(_resolve_graph_path(new_graph_path))
        except Exception as exc:
            return f"Failed to load graph from {new_graph_path}: {exc}"
        communities = _communities_from_graph(G)
        # Reload god labels
        new_report = Path(_resolve_graph_path(new_graph_path)).parent / "GRAPH_REPORT.md"
        _god_labels = set()
        if new_report.exists():
            try:
                _god_labels = _parse_god_labels_from_report(new_report.read_text(encoding="utf-8"))
            except Exception:
                pass
        return f"Switched to workspace: {ws_path}\nNodes: {G.number_of_nodes()}, Edges: {G.number_of_edges()}, Communities: {len(communities)}"

    _handlers = {
        "query_graph": _tool_query_graph,
        "get_node": _tool_get_node,
        "get_neighbors": _tool_get_neighbors,
        "get_community": _tool_get_community,
        "god_nodes": _tool_god_nodes,
        "graph_stats": _tool_graph_stats,
        "shortest_path": _tool_shortest_path,
        "switch_workspace": _tool_switch_workspace,
    }

    def _load_community_labels() -> dict[int, str]:
        labels_path = _resolved_graph_dir / ".graphify_labels.json"
        if labels_path.exists():
            try:
                return {int(k): v for k, v in json.loads(labels_path.read_text(encoding="utf-8")).items()}
            except Exception:
                pass
        return {cid: f"Community {cid}" for cid in communities}

    @server.list_resources()
    async def list_resources() -> list[types.Resource]:
        return [
            types.Resource(uri=AnyUrl("graphify://report"), name="Graph Report", description="Full GRAPH_REPORT.md", mimeType="text/markdown"),
            types.Resource(uri=AnyUrl("graphify://stats"), name="Graph Stats", description="Node/edge/community counts and confidence breakdown", mimeType="text/plain"),
            types.Resource(uri=AnyUrl("graphify://god-nodes"), name="God Nodes", description="Top 10 most-connected nodes", mimeType="text/plain"),
            types.Resource(uri=AnyUrl("graphify://surprises"), name="Surprising Connections", description="Cross-community surprising connections", mimeType="text/plain"),
            types.Resource(uri=AnyUrl("graphify://audit"), name="Confidence Audit", description="EXTRACTED/INFERRED/AMBIGUOUS edge breakdown", mimeType="text/plain"),
            types.Resource(uri=AnyUrl("graphify://questions"), name="Suggested Questions", description="Suggested questions for this codebase", mimeType="text/plain"),
        ]

    @server.read_resource()
    async def read_resource(uri: AnyUrl) -> str:
        uri_str = str(uri)
        if uri_str == "graphify://report":
            report_path = _resolved_graph_dir / "GRAPH_REPORT.md"
            if report_path.exists():
                return report_path.read_text(encoding="utf-8")
            return "GRAPH_REPORT.md not found. Run graphify extract first."
        if uri_str == "graphify://stats":
            return _tool_graph_stats({})
        if uri_str == "graphify://god-nodes":
            return _tool_god_nodes({"top_n": 10})
        if uri_str == "graphify://surprises":
            try:
                from graphify.analyze import surprising_connections
                surprises = surprising_connections(G, communities, top_n=10)
                if not surprises:
                    return "No surprising connections found."
                lines = ["Surprising cross-community connections:"]
                for s in surprises:
                    lines.append(f"  {s.get('source', '')} <-> {s.get('target', '')} [{s.get('relation', '')}]")
                return "\n".join(lines)
            except Exception as exc:
                return f"Could not compute surprising connections: {exc}"
        if uri_str == "graphify://audit":
            confs = [d.get("confidence", "EXTRACTED") for _, _, d in G.edges(data=True)]
            total = len(confs) or 1
            return (
                f"Total edges: {total}\n"
                f"EXTRACTED: {confs.count('EXTRACTED')} ({round(confs.count('EXTRACTED')/total*100)}%)\n"
                f"INFERRED: {confs.count('INFERRED')} ({round(confs.count('INFERRED')/total*100)}%)\n"
                f"AMBIGUOUS: {confs.count('AMBIGUOUS')} ({round(confs.count('AMBIGUOUS')/total*100)}%)\n"
            )
        if uri_str == "graphify://questions":
            try:
                from graphify.analyze import suggest_questions
                community_labels = _load_community_labels()
                questions = suggest_questions(G, communities, community_labels, top_n=10)
                if not questions:
                    return "No suggested questions available."
                lines = ["Suggested questions:"]
                for q in questions:
                    if isinstance(q, dict):
                        lines.append(f"  - {q.get('question', '')}")
                    else:
                        lines.append(f"  - {q}")
                return "\n".join(lines)
            except Exception as exc:
                return f"Could not generate questions: {exc}"
        raise ValueError(f"Unknown resource: {uri_str}")

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
        handler = _handlers.get(name)
        if not handler:
            return [types.TextContent(type="text", text=f"Unknown tool: {name}")]
        try:
            return [types.TextContent(type="text", text=handler(arguments))]
        except Exception as exc:
            return [types.TextContent(type="text", text=f"Error executing {name}: {exc}")]

    import asyncio

    async def main() -> None:
        async with stdio_server() as streams:
            await server.run(streams[0], streams[1], server.create_initialization_options())

    _filter_blank_stdin()
    asyncio.run(main())


if __name__ == "__main__":
    graph_path = sys.argv[1] if len(sys.argv) > 1 else "graphify-out/graph.json"
    serve(graph_path)
