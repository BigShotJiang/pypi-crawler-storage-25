"""graphify doctor — self-check that everything is working correctly."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("graphify_vault")
except Exception:
    __version__ = "0.3.1"

# ─── Helpers ─────────────────────────────────────────────

_GREEN = "\033[0;32m"
_RED = "\033[0;31m"
_YELLOW = "\033[1;33m"
_NC = "\033[0m"

def _ok(msg: str) -> None:
    print(f"  {_GREEN}✓{_NC} {msg}")

def _fail(msg: str) -> None:
    print(f"  {_RED}✗{_NC} {msg}")

def _warn(msg: str) -> None:
    print(f"  {_YELLOW}!{_NC} {msg}")


# ─── Checks ─────────────────────────────────────────────

def _check_workspace() -> tuple[bool, str | None]:
    """Check GRAPHIFY_WORKSPACE is set and is a valid directory."""
    workspace = os.environ.get("GRAPHIFY_WORKSPACE", "")
    if not workspace:
        _warn("GRAPHIFY_WORKSPACE not set (optional — graphify will use graph.json parent directory for path resolution)")
        return True, None
    ws_path = Path(workspace)
    if not ws_path.is_dir():
        _warn(f"GRAPHIFY_WORKSPACE={workspace} is not a directory")
        return True, None
    _ok(f"GRAPHIFY_WORKSPACE={workspace}")
    return True, workspace


def _check_python() -> bool:
    """Check Python version >= 3.10."""
    major, minor = sys.version_info.major, sys.version_info.minor
    if (major, minor) >= (3, 10):
        _ok(f"Python {major}.{minor}")
        return True
    _fail(f"Python {major}.{minor} (need >= 3.10)")
    return False


def _check_graphify_installed() -> bool:
    """Check graphify CLI is available."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "graphify", "--help"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            _ok(f"graphify {__version__}")
            return True
    except Exception:
        pass
    _fail("graphify not found in current Python environment")
    return False


def _check_graph_json() -> tuple[bool, Path | None]:
    """Check graph.json exists and is valid."""
    candidates = [
        Path("graphify-out/graph.json"),
        Path("../graphify-out/graph.json"),
    ]
    # Also check GRAPHIFY_WORKSPACE
    ws = os.environ.get("GRAPHIFY_WORKSPACE", "")
    if ws:
        candidates.insert(0, Path(ws) / "graphify-out" / "graph.json")
    graph_path = None
    for c in candidates:
        if c.exists():
            graph_path = c.resolve()
            break

    if graph_path is None:
        _fail("graph.json not found (run 'graphify build .' first)")
        return False, None

    # Validate JSON structure
    try:
        data = json.loads(graph_path.read_text(encoding="utf-8"))
        nodes = data.get("nodes", [])
        edges = data.get("edges", data.get("links", []))
        if not nodes:
            _warn(f"graph.json exists but has 0 nodes ({graph_path})")
            return True, graph_path
        _ok(f"graph.json: {len(nodes)} nodes, {len(edges)} edges ({graph_path})")
        # Check path portability
        absolute_count = sum(1 for n in nodes
                           if n.get("source_file", "")
                           and Path(n["source_file"]).is_absolute())
        if absolute_count > 0:
            total = len([n for n in nodes if n.get("source_file")])
            _warn(f"graph.json has {absolute_count}/{total} nodes with absolute source_file (not portable)")
            _warn("Re-run 'graphify build .' to generate portable relative paths")
        else:
            _ok("graph.json uses relative source_file paths (portable)")
        return True, graph_path
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        _fail(f"graph.json is invalid JSON: {e}")
        return False, graph_path


def _check_mcp_server(graph_path: Path | None) -> bool:
    """Check MCP server can start (dry run: load graph and verify tools)."""
    if graph_path is None:
        _fail("MCP server: skipped (no graph.json)")
        return False

    try:
        from graphify.serve import _load_graph
        G = _load_graph(str(graph_path))
        _ok(f"MCP server: graph loaded ({G.number_of_nodes()} nodes, {G.number_of_edges()} edges)")
        return True
    except ImportError:
        _fail("MCP server: 'mcp' package not installed (run 'pip install graphifyy[mcp]')")
        return False
    except Exception as e:
        _fail(f"MCP server: failed to load graph: {e}")
        return False


def _check_mcp_config() -> bool:
    """Check MCP is configured in at least one IDE."""
    found = []

    # Check coco/Trae (support ta/traecli aliases)
    # CLI has no "mcp list" command, so check config files
    _trae_config_candidates = [
        Path.home() / ".trae" / "traecli.yaml",
        Path.home() / ".trae-cn" / "traecli.yaml",
    ]
    for _cfg in _trae_config_candidates:
        if _cfg.exists():
            try:
                content = _cfg.read_text(encoding="utf-8")
                if "spatial-knowledge-graph" in content:
                    found.append("Trae/Coco")
                    break
            except Exception:
                pass
    # Fallback: if coco/ta CLI exists but no config found, just note it's installed
    if "Trae/Coco" not in found:
        for cli in ("coco", "ta", "traecli"):
            if shutil.which(cli):
                _warn("Trae/Coco CLI found but spatial-knowledge-graph not in config — run install.sh to configure")
                break

    # Check Claude Code (CLI or config file)
    _claude_found = False
    try:
        result = subprocess.run(
            ["claude", "mcp", "list"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and "spatial-knowledge-graph" in result.stdout:
            found.append("Claude Code")
            _claude_found = True
    except Exception:
        pass
    if not _claude_found:
        # Fallback: check Claude Code config files
        for _claude_cfg in [
            Path.home() / ".claude.json",
            Path.home() / ".claude" / "settings.json",
        ]:
            if _claude_cfg.exists():
                try:
                    data = json.loads(_claude_cfg.read_text(encoding="utf-8"))
                    if "spatial-knowledge-graph" in data.get("mcpServers", {}):
                        found.append("Claude Code")
                        _claude_found = True
                        break
                except Exception:
                    pass

    # Check Cursor (project-level or global config)
    _cursor_found = False
    for _cursor_cfg in [
        Path(".cursor/mcp.json"),
        Path.home() / ".cursor" / "mcp.json",
    ]:
        if _cursor_cfg.exists():
            try:
                data = json.loads(_cursor_cfg.read_text(encoding="utf-8"))
                if "spatial-knowledge-graph" in data.get("mcpServers", {}):
                    found.append("Cursor")
                    _cursor_found = True
                    break
            except Exception:
                pass

    # Check Codex
    codex_config = Path.home() / ".codex" / "config.toml"
    if codex_config.exists():
        try:
            content = codex_config.read_text(encoding="utf-8")
            if "[mcp_servers.spatial-knowledge-graph]" in content:
                found.append("Codex")
        except Exception:
            pass

    if found:
        _ok(f"MCP configured in: {', '.join(found)}")
        return True
    _warn("MCP not configured in any IDE (run install.sh or configure manually)")
    return False


def _check_venv() -> bool:
    """Check running inside a virtual environment (skip for PyInstaller binary)."""
    # PyInstaller frozen app doesn't need a venv
    if getattr(sys, "frozen", False):
        _ok("Standalone binary (no venv needed)")
        return True
    in_venv = hasattr(sys, "real_prefix") or (
        hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix
    )
    if in_venv:
        _ok(f"Virtual environment: {sys.prefix}")
        return True
    _warn("Not running in a virtual environment (recommended: ~/.venv/graphify)")
    return False


# ─── Main ───────────────────────────────────────────────

def run_doctor() -> None:
    """Run all self-checks and report status."""
    print()
    print("graphify doctor — self-check")
    print("=" * 40)
    print()

    results = []

    print("[1/7] GRAPHIFY_WORKSPACE")
    ws_ok, ws_val = _check_workspace()
    results.append(ws_ok)

    print("[2/7] Python environment")
    results.append(_check_python())

    print("[3/7] Virtual environment")
    results.append(_check_venv())

    print("[4/7] graphify installation")
    results.append(_check_graphify_installed())

    print("[5/7] Knowledge graph")
    graph_ok, graph_path = _check_graph_json()
    results.append(graph_ok)

    print("[6/7] MCP server")
    results.append(_check_mcp_server(graph_path))

    print("[7/7] MCP IDE configuration")
    results.append(_check_mcp_config())

    print()
    passed = sum(results)
    total = len(results)

    if passed == total:
        print(f"{_GREEN}All {total} checks passed!{_NC} graphify is ready to use.")
    elif passed >= total - 1:
        print(f"{_YELLOW}{passed}/{total} checks passed.{_NC} Minor issues detected, graphify should still work.")
    else:
        print(f"{_RED}{passed}/{total} checks passed.{_NC} Please fix the issues above.")
        sys.exit(1)
    print()
