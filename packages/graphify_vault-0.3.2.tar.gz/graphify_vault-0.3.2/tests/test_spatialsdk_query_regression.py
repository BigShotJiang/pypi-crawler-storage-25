"""Integration-style query regression tests for the SpatialSDK markdown corpus.

Run with:
    pytest tests/test_spatialsdk_query_regression.py -v -s --corpus-dir=/path/to/SpatialSDK_API_Markdown

These tests verify that representative user questions can locate the expected
starting nodes after graph extraction. They intentionally cover varied question
styles instead of repeating a single template.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from graphify.serve import _load_graph, _query_graph, _extract_query_terms


QUERY_CASES = [
    # 中文场景问题：尽量贴近真实意图，少给英文提示
    ("中文", "播放视频", "视频播放的组件有哪些", ["VideoPlayerComponent", "VideoComponent"]),
    ("中文", "桌面放置", "做桌面放置时，平面识别应该用哪些组件", ["PlaneAnchor"]),
    ("中文", "手势交互", "做捏合、抓取这类交互时，手部关节点数据从哪里来", ["HandTrackingProvider", "HandJoint"]),
    ("中文", "视线交互", "想做凝视触发和视线悬停效果，眼动数据相关入口在哪", ["EyeTrackingProvider", "EyeTrackingData"]),
    ("中文", "传送门换场景", "做穿门切换房间时，传送门相关组件一般有哪些", ["PortalComponent", "PortalWorldComponent"]),

    # 英文场景问题：模拟英文开发者真实提问
    ("英文", "Play 3D video", "How do I play a 3D video on a mesh surface?", ["VideoMaterial", "MeshResource"]),
    ("英文", "Media playback control", "Which types handle low-level media playback state, seek, and pause control?", ["CypressMediaPlayer"]),
    ("英文", "Playback callbacks", "What callback interface should I inspect for playback completion and failure events?", ["CypressMediaPlayerCallback"]),
    ("英文", "Load 3D model", "How do I load and display a 3D model on an entity?", ["ModelComponent", "MeshResource"]),
    ("英文", "Rigid physics and collisions", "Which components are central for rigid-body physics and collision handling?", ["RigidBodyComponent", "CollisionComponent"]),

    # API list 问题：允许显式带关键词，考察直接 API 检索
    ("API", "Video APIs", "VideoPlayerComponent VideoComponent video playback APIs", ["VideoPlayerComponent", "VideoComponent"]),
    ("API", "Bundle API", "AssetBundle bundle loading API", ["AssetBundle"]),
    ("API", "Resize APIs", "ContainerResizeRestriction ContainerResizeType resize APIs", ["ContainerResizeRestriction", "ContainerResizeType"]),
    ("API", "Event APIs", "EventSource Event event system APIs", ["EventSource", "Event"]),
    ("API", "Spatial container APIs", "SpatialContainer WindowContainer layout APIs", ["SpatialContainer", "WindowContainer"]),

    # 综合疑难问题：多意图、多实体，给后续优化留出空间
    ("综合", "沉浸式视频场景", "如果我要做一个沉浸式媒体场景，既要把视频挂到模型表面，又要能控制播放状态，应该排查哪些核心类型", ["VideoMaterial", "MeshResource", "CypressMediaPlayer"]),
    ("综合", "扫描房间并放置物体", "先扫描房间拿到环境网格，再把物体稳定放到桌面上，这条链路里值得先看的 anchor 类型有哪些", ["MeshAnchor", "PlaneAnchor"]),
    ("综合", "从手势到物理反馈", "手势抓取一个物体后让它带刚体运动并产生碰撞反馈，相关的关键类型会有哪些", ["HandTrackingProvider", "RigidBodyComponent", "CollisionComponent"]),
    ("综合", "视线触发事件", "如果一个交互是由用户注视触发，再进入事件分发链路，应该从哪些基础类型开始追", ["EyeTrackingProvider", "EventSource", "Event"]),
    ("综合", "窗口与空间布局", "排查空间窗口尺寸限制和容器布局冲突时，哪些容器和 resize 类型最值得先看", ["WindowContainer", "SpatialContainer", "ContainerResizeRestriction", "ContainerResizeType"]),
]

RUN_LOGS: list[dict[str, object]] = []


def _top_labels(results: list[dict[str, object]], limit: int = 5) -> list[str]:
    return [str(item.get("label", item.get("node_id", ""))) for item in results[:limit]]


def _label_ranks(results: list[dict[str, object]], expected_labels: list[str], limit: int = 20) -> dict[str, int | None]:
    ranked_labels = [str(item.get("label", item.get("node_id", ""))) for item in results[:limit]]
    ranks: dict[str, int | None] = {}
    for label in expected_labels:
        try:
            ranks[label] = ranked_labels.index(label) + 1
        except ValueError:
            ranks[label] = None
    return ranks


def _working_set_recall(results: list[dict[str, object]], expected_labels: list[str], limit: int = 10) -> float:
    ranked_labels = {str(item.get("label", item.get("node_id", ""))) for item in results[:limit]}
    if not expected_labels:
        return 0.0
    hits = sum(1 for label in expected_labels if label in ranked_labels)
    return round(hits / len(expected_labels), 3)


def _definition_source_coverage(results: list[dict[str, object]], expected_labels: list[str], limit: int = 10) -> float:
    expected_set = set(expected_labels)
    matched = [
        item for item in results[:limit]
        if str(item.get("label", item.get("node_id", ""))) in expected_set
    ]
    if not matched:
        return 0.0
    covered = 0
    for item in matched:
        if item.get("source_file") and item.get("start_line") is not None and item.get("end_line") is not None:
            covered += 1
    return round(covered / len(matched), 3)


@pytest.fixture(scope="module", autouse=True)
def _print_query_summary():
    RUN_LOGS.clear()
    yield
    if not RUN_LOGS:
        return
    print("\n===== SpatialSDK Query Regression Summary =====")
    print(f"Total cases: {len(RUN_LOGS)}")
    by_category: dict[str, list[dict[str, object]]] = {}
    for item in RUN_LOGS:
        by_category.setdefault(str(item["category"]), []).append(item)
        print(
            f"- [{item['category']}][{item['case_id']}] matched={item['matched']} recall={item['working_set_recall']} source_cov={item['definition_source_coverage']} terms={item['terms']} expected={item['expected']} ranks={item['ranks']} top5={item['top5']}"
        )
    print("----- Category Summary -----")
    for category, items in by_category.items():
        matched = sum(1 for item in items if item["matched"])
        avg_recall = round(sum(float(item["working_set_recall"]) for item in items) / len(items), 3)
        avg_source_cov = round(sum(float(item["definition_source_coverage"]) for item in items) / len(items), 3)
        print(f"- {category}: {matched}/{len(items)} matched in top10 | avg recall={avg_recall} | avg source coverage={avg_source_cov}")


def _question_terms(question: str) -> list[str]:
    return _extract_query_terms(question)


@pytest.mark.parametrize(
    "category,case_id,question,expected_labels",
    QUERY_CASES,
    ids=[f"{category}-{case_id}" for category, case_id, _, _ in QUERY_CASES],
)
def test_spatialsdk_query_cases_can_find_expected_nodes(request, category: str, case_id: str, question: str, expected_labels: list[str]):
    corpus_dir = request.config.getoption("--corpus-dir")
    if corpus_dir is None:
        pytest.skip("No --corpus-dir specified for SpatialSDK query regression test")

    graph_path = Path(corpus_dir) / "graphify-out" / "graph.json"
    if not graph_path.exists():
        pytest.skip(f"graph.json not found: {graph_path}")

    G = _load_graph(str(graph_path))
    terms = _question_terms(question)
    payload = _query_graph(G, question, json_output=True)
    results = list(payload.get("results", []))

    top_labels = {str(item.get("label", item.get("node_id", ""))) for item in results[:10]}
    preview = _top_labels(results)
    ranks = _label_ranks(results, expected_labels)
    matched = any(label in top_labels for label in expected_labels)
    working_set_recall = _working_set_recall(results, expected_labels)
    definition_source_coverage = _definition_source_coverage(results, expected_labels)
    RUN_LOGS.append({
        "category": category,
        "case_id": case_id,
        "question": question,
        "query_mode": payload.get("query_mode"),
        "terms": terms,
        "expected": expected_labels,
        "ranks": ranks,
        "top5": preview,
        "matched": matched,
        "working_set_recall": working_set_recall,
        "definition_source_coverage": definition_source_coverage,
    })
    print(f"\n[CASE] {category}/{case_id}")
    print(f"Q: {question}")
    print(f"Mode: {payload.get('query_mode')}")
    print(f"Terms: {terms}")
    print(f"Expected: {expected_labels}")
    print(f"Ranks(top20): {ranks}")
    print(f"WorkingSetRecall(top10): {working_set_recall}")
    print(f"DefinitionSourceCoverage(top10): {definition_source_coverage}")
    print(f"Top5: {preview}")
    print(f"Matched(top10): {matched}")
    assert isinstance(results, list)


def test_spatialsdk_query_metrics_helpers():
    results = [
        {"label": "Alpha", "source_file": "a.md", "start_line": 1, "end_line": 3},
        {"label": "Beta", "source_file": "b.md", "start_line": 4, "end_line": 7},
        {"label": "Gamma", "source_file": "", "start_line": None, "end_line": None},
    ]
    assert _working_set_recall(results, ["Alpha", "Gamma"]) == 1.0
    assert _definition_source_coverage(results, ["Alpha", "Gamma"]) == 0.5


def test_spatialsdk_query_variants_can_bridge_cross_language_queries(request):
    corpus_dir = request.config.getoption("--corpus-dir")
    if corpus_dir is None:
        pytest.skip("No --corpus-dir specified for SpatialSDK query regression test")

    graph_path = Path(corpus_dir) / "graphify-out" / "graph.json"
    if not graph_path.exists():
        pytest.skip(f"graph.json not found: {graph_path}")

    G = _load_graph(str(graph_path))
    payload = _query_graph(
        G,
        "视频播放的组件有哪些",
        json_output=True,
        query_variants=["Which video playback components should I inspect?"],
    )
    results = list(payload.get("results", []))
    top_labels = {str(item.get("label", item.get("node_id", ""))) for item in results[:10]}
    assert payload.get("query_variants")[0] == "视频播放的组件有哪些"
    assert "Which video playback components should I inspect?" in payload.get("query_variants", [])
    assert {"VideoPlayerComponent", "VideoComponent"} & top_labels


def test_spatialsdk_query_cases_cover_distinct_labels():
    labels = {label for _, _, _, expected in QUERY_CASES for label in expected}
    assert len(QUERY_CASES) == 20
    assert len(labels) >= 20


def test_spatialsdk_query_cases_are_varied():
    prefixes = {q.split()[0] for _, _, q, _ in QUERY_CASES}
    assert len(prefixes) >= 10, "Questions should use varied real-world phrasings"


def test_spatialsdk_query_cases_have_balanced_categories():
    counts: dict[str, int] = {}
    for category, _, _, _ in QUERY_CASES:
        counts[category] = counts.get(category, 0) + 1
    assert counts == {"中文": 5, "英文": 5, "API": 5, "综合": 5}


def test_spatialsdk_query_cases_file_is_valid_json_free_python_data():
    payload = json.dumps(QUERY_CASES, ensure_ascii=False)
    assert "VideoComponent" in payload
