"""Tests for sort_by parameter in _subgraph_to_text and CLI query.

Compares sort_by="degree" vs sort_by="relevance" across diverse query targets
from a real knowledge graph.

Key insight: sort_by="degree" puts hub nodes first (high connectivity),
while sort_by="relevance" puts query start_nodes first (direct matches),
then remaining nodes by degree.
"""
import json
import pytest
import networkx as nx
from networkx.readwrite import json_graph
from pathlib import Path

from graphify.serve import (
    _score_nodes,
    _bfs,
    _dfs,
    _subgraph_to_text,
)

# ---------------------------------------------------------------------------
# Fixture: load graph once per session, requires --corpus-dir (conftest.py)
# ---------------------------------------------------------------------------


def _get_graph_path(request):
    corpus_dir = request.config.getoption("--corpus-dir")
    if corpus_dir:
        return Path(corpus_dir) / "graphify-out" / "graph.json"
    return None


@pytest.fixture(scope="session")
def sdk_graph(request):
    graph_path = _get_graph_path(request)
    if graph_path is None or not graph_path.exists():
        pytest.skip("Corpus graph not found — specify --corpus-dir")
    data = json.loads(graph_path.read_text(encoding="utf-8"))
    try:
        return json_graph.node_link_graph(data, edges="links")
    except TypeError:
        return json_graph.node_link_graph(data)


# ---------------------------------------------------------------------------
# Diverse query targets — one per source file, covering 25 different modules
# ---------------------------------------------------------------------------

QUERY_TARGETS = [
    # (query_terms, expected_label_substring, source_file_substring)
    ("CypressMediaPlayer", "CypressMediaPlayer", "video"),
    ("TimelinePlayerController", "TimelinePlayerController", "timeline"),
    ("Component", "Component", "ecs.md"),
    ("Resource", "Resource", "resource"),
    ("ContainerProperties", "ContainerProperties", "dsl"),
    ("Event", "Event", "event"),
    ("Quat", "Quat", "math"),
    ("MeshAnchor", "MeshAnchor", "mesh"),
    ("InteractionKind", "InteractionKind", "gesture.data"),
    ("TweenAnimation", "TweenAnimation", "animation"),
    ("Boolean", "Boolean", "threading"),
    ("SpatialTransformValue", "SpatialTransformValue", "gesture"),
    ("HandTrackingProvider", "HandTrackingProvider", "hand"),
    ("AudioStreamConfig", "AudioStreamConfig", "audio"),
    ("Rotation3D", "Rotation3D", "geometry"),
    ("PhysicalLengthConverter", "PhysicalLengthConverter", "platform"),
    ("PlaneAnchor", "PlaneAnchor", "plane"),
    ("EyeTrackingProvider", "EyeTrackingProvider", "eye"),
    ("ControllerTrackingProvider", "ControllerTrackingProvider", "controller"),
    ("DataProvider", "DataProvider", "tracking.md"),
    ("MotionTrackingProvider", "MotionTrackingProvider", "motion"),
    ("BodyJoint", "BodyJoint", "body"),
    ("SpatialContainer", "SpatialContainer", "container"),
    ("WorldTrackingManager", "WorldTrackingManager", "world"),
    ("Pipeline", "Pipeline", "securemr"),
]


# ---------------------------------------------------------------------------
# Helper: run a query and return (degree_text, relevance_text, start_nodes)
# ---------------------------------------------------------------------------

def _query_both_sort_modes(G, query_terms, max_degree=0, depth=2):
    """Run BFS query with both sort modes and return results + start_nodes."""
    terms = [t.lower() for t in query_terms.split() if len(t) > 2]
    scored = _score_nodes(G, terms)
    if not scored:
        return None, None, []

    top_score = scored[0][0]
    threshold = top_score * 0.5
    start_nodes = [nid for s, nid in scored[:5] if s >= threshold]
    if not start_nodes:
        return None, None, []

    nodes, edges = _bfs(G, start_nodes, depth=depth, max_degree=max_degree)

    text_degree = _subgraph_to_text(G, nodes, edges, sort_by="degree", start_nodes=start_nodes)
    text_relevance = _subgraph_to_text(G, nodes, edges, sort_by="relevance", start_nodes=start_nodes)

    return text_degree, text_relevance, start_nodes


def _first_node_label(text):
    """Extract the label of the first NODE line in the output."""
    for line in text.split("\n"):
        if line.startswith("NODE "):
            # Format: NODE LabelName [src=...]
            return line.split(" [")[0].replace("NODE ", "", 1)
    return None


def _node_order(text):
    """Extract ordered list of node labels from output."""
    labels = []
    for line in text.split("\n"):
        if line.startswith("NODE "):
            labels.append(line.split(" [")[0].replace("NODE ", "", 1))
    return labels


# ---------------------------------------------------------------------------
# Test 1-5: Unit tests on synthetic graph
# ---------------------------------------------------------------------------

def test_sort_by_degree_default(sdk_graph):
    """Default sort_by='degree' should produce same output as before."""
    G = sdk_graph
    scored = _score_nodes(G, ["video"])
    start_nodes = [nid for _, nid in scored[:3]]
    nodes, edges = _bfs(G, start_nodes, depth=2)

    text_default = _subgraph_to_text(G, nodes, edges, start_nodes=start_nodes)
    text_degree = _subgraph_to_text(G, nodes, edges, sort_by="degree", start_nodes=start_nodes)

    assert text_default == text_degree


def test_sort_by_relevance_puts_start_nodes_first(sdk_graph):
    """sort_by='relevance' should put start_nodes before non-start nodes."""
    G = sdk_graph
    scored = _score_nodes(G, ["videomaterial"])
    start_nodes = [nid for _, nid in scored[:3]]
    if not start_nodes:
        pytest.skip("No VideoMaterial node found")

    nodes, edges = _bfs(G, start_nodes, depth=2, max_degree=10)
    text = _subgraph_to_text(G, nodes, edges, sort_by="relevance", start_nodes=start_nodes)
    order = _node_order(text)

    # Start nodes should appear before any non-start node
    start_labels = {G.nodes[n].get("label", n) for n in start_nodes if n in nodes}
    first_non_start = None
    for label in order:
        if label not in start_labels:
            first_non_start = label
            break

    if first_non_start and len(start_labels) > 0:
        # All start labels should appear before the first non-start label
        start_positions = [order.index(l) for l in start_labels if l in order]
        non_start_pos = order.index(first_non_start)
        assert max(start_positions) < non_start_pos, \
            f"Start nodes {start_labels} should appear before {first_non_start}"


def test_sort_by_degree_puts_highest_degree_first(sdk_graph):
    """sort_by='degree' should put the highest-degree node first."""
    G = sdk_graph
    scored = _score_nodes(G, ["video"])
    start_nodes = [nid for _, nid in scored[:3]]
    nodes, edges = _bfs(G, start_nodes, depth=2)

    text = _subgraph_to_text(G, nodes, edges, sort_by="degree", start_nodes=start_nodes)
    order = _node_order(text)

    # The first node should have the highest degree in the subgraph
    if len(order) >= 2:
        first_nid = None
        for nid in nodes:
            if G.nodes[nid].get("label", "") == order[0]:
                first_nid = nid
                break
        first_deg = G.degree(first_nid) if first_nid else 0
        for label in order[1:]:
            for nid in nodes:
                if G.nodes[nid].get("label", "") == label:
                    assert G.degree(nid) <= first_deg
                    break


def test_sort_by_relevance_same_nodes_as_degree(sdk_graph):
    """Both sort modes should include the same set of nodes, just in different order."""
    G = sdk_graph
    text_d, text_r, start_nodes = _query_both_sort_modes(G, "animation", max_degree=10)
    if text_d is None:
        pytest.skip("No animation nodes found")

    order_d = set(_node_order(text_d))
    order_r = set(_node_order(text_r))

    assert order_d == order_r, "Both sort modes should return the same node set"


def test_sort_by_relevance_without_start_nodes_falls_back(sdk_graph):
    """sort_by='relevance' without start_nodes should fall back to degree sort."""
    G = sdk_graph
    scored = _score_nodes(G, ["resource"])
    start_nodes = [nid for _, nid in scored[:3]]
    nodes, edges = _bfs(G, start_nodes, depth=2, max_degree=10)

    text_rel_no_start = _subgraph_to_text(G, nodes, edges, sort_by="relevance", start_nodes=None)
    text_degree = _subgraph_to_text(G, nodes, edges, sort_by="degree", start_nodes=start_nodes)

    assert text_rel_no_start == text_degree, \
        "relevance without start_nodes should fall back to degree sort"


# ---------------------------------------------------------------------------
# Tests 6-30: Comprehensive comparison across 25 diverse query targets
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("query,label_substring,src_substring", QUERY_TARGETS,
                         ids=[f"{q}" for q, _, _ in QUERY_TARGETS])
def test_relevance_query_target_not_buried(query, label_substring, src_substring, sdk_graph):
    """With sort_by='relevance', the query target should not be buried behind hub nodes.

    This is the core test: when you query for X, X should appear early in the
    relevance-sorted output, not behind high-degree unrelated nodes.
    """
    text_d, text_r, start_nodes = _query_both_sort_modes(sdk_graph, query, max_degree=10)
    if text_d is None:
        pytest.skip(f"No nodes found for query '{query}'")

    order_r = _node_order(text_r)
    order_d = _node_order(text_d)

    # The query target should exist in both outputs
    assert label_substring in " ".join(order_r), \
        f"Query target '{label_substring}' not found in relevance output"

    # Find position of the query target in both sort modes
    pos_r = next((i for i, l in enumerate(order_r) if label_substring in l), -1)
    pos_d = next((i for i, l in enumerate(order_d) if label_substring in l), -1)

    # Print comparison detail (only visible with -s flag)
    improvement = ""
    if pos_d > pos_r:
        improvement = f"↑{pos_d - pos_r}"
    elif pos_d == pos_r:
        improvement = "="
    else:
        improvement = f"↓{pos_r - pos_d}"
    print(f"  [{label_substring}] degree=#{pos_d} relevance=#{pos_r} {improvement} ({len(order_r)} nodes)")

    # With relevance sort, the target should be at position 0 or very early
    assert pos_r <= 2, \
        f"'{label_substring}' at position {pos_r} in relevance sort (expected 0-2)"

    # With degree sort, the target might be further back (this documents current behavior)
    # We don't assert pos_d > pos_r because some targets ARE the highest-degree node
    # Just log the comparison for visibility
    if pos_d > pos_r:
        # Relevance sort improved the position — this is the expected improvement case
        pass


@pytest.fixture
def G(request, sdk_graph):
    """Extract the query-specific parameters from the test ID."""
    return sdk_graph


# ---------------------------------------------------------------------------
# Tests 31-35: Edge cases
# ---------------------------------------------------------------------------

def test_sort_by_invalid_value_defaults_to_degree(sdk_graph):
    """An invalid sort_by value should not crash — it falls back to degree sort."""
    G = sdk_graph
    scored = _score_nodes(G, ["video"])
    start_nodes = [nid for _, nid in scored[:3]]
    nodes, edges = _bfs(G, start_nodes, depth=2)

    # Invalid sort_by falls through to the else branch (degree sort)
    text = _subgraph_to_text(G, nodes, edges, sort_by="invalid_value", start_nodes=start_nodes)
    text_degree = _subgraph_to_text(G, nodes, edges, sort_by="degree", start_nodes=start_nodes)
    assert text == text_degree


def test_sort_by_relevance_empty_start_nodes(sdk_graph):
    """sort_by='relevance' with empty start_nodes should fall back to degree sort."""
    G = sdk_graph
    scored = _score_nodes(G, ["video"])
    start_nodes = [nid for _, nid in scored[:3]]
    nodes, edges = _bfs(G, start_nodes, depth=2)

    text_rel = _subgraph_to_text(G, nodes, edges, sort_by="relevance", start_nodes=[])
    text_degree = _subgraph_to_text(G, nodes, edges, sort_by="degree", start_nodes=start_nodes)
    assert text_rel == text_degree


def test_sort_by_relevance_single_node(sdk_graph):
    """sort_by='relevance' with a single node should work without error."""
    G = sdk_graph
    scored = _score_nodes(G, ["video"])
    if not scored:
        pytest.skip("No video nodes")
    start_nodes = [scored[0][1]]
    nodes = {start_nodes[0]}
    edges = []

    text = _subgraph_to_text(G, nodes, edges, sort_by="relevance", start_nodes=start_nodes)
    label = G.nodes[start_nodes[0]].get("label", start_nodes[0])
    assert label in text


def test_sort_by_preserves_edge_output(sdk_graph):
    """Both sort modes should produce the same EDGE lines (only NODE order differs)."""
    G = sdk_graph
    text_d, text_r, start_nodes = _query_both_sort_modes(G, "timeline", max_degree=10)
    if text_d is None:
        pytest.skip("No timeline nodes found")

    edges_d = [l for l in text_d.split("\n") if l.startswith("EDGE ")]
    edges_r = [l for l in text_r.split("\n") if l.startswith("EDGE ")]

    # Edges should be the same set (order doesn't matter)
    assert set(edges_d) == set(edges_r), "Edge output should be identical in both sort modes"


def test_sort_by_relevance_multiword_query(sdk_graph):
    """Multi-word queries like 'video material' should work with both sort modes."""
    G = sdk_graph
    text_d, text_r, start_nodes = _query_both_sort_modes(G, "video material", max_degree=10)
    if text_d is None:
        pytest.skip("No nodes found for 'video material'")

    # Both should produce valid output
    assert len(_node_order(text_d)) > 0
    assert len(_node_order(text_r)) > 0

    # Relevance sort should put "VideoMaterial" first
    first_r = _first_node_label(text_r)
    assert first_r is not None
    assert "VideoMaterial" in first_r or "video" in first_r.lower() or "material" in first_r.lower(), \
        f"Expected VideoMaterial or similar first, got '{first_r}'"
