"""Tests for serve.py - MCP graph query helpers (no mcp package required)."""
import json
import pytest
import networkx as nx
from networkx.readwrite import json_graph

from graphify.serve import (
    _classify_query_mode,
    _communities_from_graph,
    _compute_hub_labels,
    _expand_task_candidates,
    _extract_query_terms,
    _normalize_query_text,
    _relation_family,
    _relation_family_weight,
    _query_graph,
    _rank_task_candidates,
    _select_seed_nodes,
    _score_nodes,
    _bfs,
    _dfs,
    _subgraph_to_text,
    _load_graph,
)


def _make_graph() -> nx.Graph:
    G = nx.Graph()
    G.add_node("n1", label="extract", source_file="extract.py", source_location="L10", community=0)
    G.add_node("n2", label="cluster", source_file="cluster.py", source_location="L5", community=0)
    G.add_node("n3", label="build", source_file="build.py", source_location="L1", community=1)
    G.add_node("n4", label="report", source_file="report.py", source_location="L1", community=1)
    G.add_node("n5", label="isolated", source_file="other.py", source_location="L1", community=2)
    G.add_edge("n1", "n2", relation="calls", confidence="INFERRED")
    G.add_edge("n2", "n3", relation="imports", confidence="EXTRACTED")
    G.add_edge("n3", "n4", relation="uses", confidence="EXTRACTED")
    return G


def _make_task_graph() -> nx.Graph:
    G = nx.Graph()
    G.add_node(
        "render_pipeline",
        label="RenderPipeline",
        source_file="rendering.md",
        source_location="L10",
        start_line=10,
        end_line=48,
        context="definition",
        raws=["class RenderPipeline"],
        community=0,
    )
    G.add_node(
        "render_view",
        label="RenderView",
        source_file="rendering.md",
        source_location="L50",
        start_line=50,
        end_line=90,
        context="definition",
        raws=["class RenderView"],
        community=0,
    )
    G.add_node(
        "frame_controller",
        label="FrameController",
        source_file="control.md",
        source_location="L20",
        start_line=20,
        end_line=75,
        context="definition",
        raws=["class FrameController"],
        community=0,
    )
    G.add_node(
        "canvas_material",
        label="CanvasMaterial",
        source_file="resource.md",
        source_location="L5",
        start_line=5,
        end_line=35,
        context="definition",
        raws=["class CanvasMaterial : Material"],
        community=0,
    )
    G.add_node(
        "canvas_resource",
        label="CanvasResource",
        source_file="resource.md",
        source_location="L40",
        start_line=40,
        end_line=78,
        context="definition",
        raws=["class CanvasResource : Resource"],
        community=0,
    )
    G.add_node(
        "surface_texture",
        label="SurfaceTexture",
        source_file="surface.md",
        source_location="L12",
        start_line=12,
        end_line=44,
        context="definition",
        raws=["class SurfaceTexture"],
        community=0,
    )
    G.add_node(
        "sample_render_flow",
        label="SampleRenderFlow",
        source_file="sample_rendering.md",
        source_location="L1",
        start_line=1,
        end_line=30,
        context="sample",
        raws=["SampleRenderFlow()"],
        community=1,
    )
    G.add_edge("render_pipeline", "render_view", relation="uses", confidence="EXTRACTED")
    G.add_edge("render_pipeline", "frame_controller", relation="uses", confidence="EXTRACTED")
    G.add_edge("render_pipeline", "canvas_material", relation="renders_with", confidence="EXTRACTED")
    G.add_edge("canvas_material", "canvas_resource", relation="uses", confidence="EXTRACTED")
    G.add_edge("canvas_material", "surface_texture", relation="uses", confidence="EXTRACTED")
    G.add_edge("sample_render_flow", "render_pipeline", relation="example_of", confidence="EXTRACTED")
    return G


# --- _communities_from_graph ---

def test_communities_from_graph_basic():
    G = _make_graph()
    communities = _communities_from_graph(G)
    assert 0 in communities
    assert 1 in communities
    assert "n1" in communities[0]
    assert "n2" in communities[0]
    assert "n3" in communities[1]

def test_communities_from_graph_no_community_attr():
    G = nx.Graph()
    G.add_node("a", label="foo")  # no community attr
    communities = _communities_from_graph(G)
    assert communities == {}

def test_communities_from_graph_isolated():
    G = _make_graph()
    communities = _communities_from_graph(G)
    assert 2 in communities
    assert "n5" in communities[2]


# --- _score_nodes ---

def test_score_nodes_exact_label_match():
    G = _make_graph()
    scored = _score_nodes(G, ["extract"])
    nids = [nid for _, nid in scored]
    assert "n1" in nids
    assert scored[0][1] == "n1"  # highest score first

def test_score_nodes_no_match():
    G = _make_graph()
    scored = _score_nodes(G, ["xyzzy"])
    assert scored == []

def test_score_nodes_source_file_partial():
    G = _make_graph()
    # "cluster.py" contains "cluster" - should score 0.5 for source match
    scored = _score_nodes(G, ["cluster"])
    nids = [nid for _, nid in scored]
    assert "n2" in nids


def test_score_nodes_camel_case_query_matches_label_without_exact_case():
    G = nx.Graph()
    G.add_node("render_component", label="RenderComponent", source_file="rendering.md", source_location="L4520", community=0)
    scored = _score_nodes(G, ["rendercomponent"])
    assert scored
    assert scored[0][1] == "render_component"


def test_extract_query_terms_pulls_embedded_identifier_from_chinese_question():
    terms = _extract_query_terms("如果我要排查RenderBridgeComponent应该看哪个入口")
    assert "renderbridgecomponent" in terms


def test_normalize_query_text_preserves_cjk_tokens_and_splits_mixed_scripts():
    assert _normalize_query_text("RenderBridge组件") == "render bridge 组件"


def test_extract_query_terms_keeps_meaningful_cjk_terms():
    terms = _extract_query_terms("渲染画布的模块有哪些")
    assert "渲染画布" in terms
    assert "画布" in terms
    assert "模块" in terms


def test_extract_query_terms_keeps_meaningful_english_terms():
    terms = _extract_query_terms("Which render pipeline modules should I inspect?")
    assert "render" in terms
    assert "pipeline" in terms
    assert "modules" in terms
    assert "module" in terms
    assert "renderpipeline" in terms


def test_extract_query_terms_drops_english_question_stopwords():
    terms = _extract_query_terms("What callback interface should I inspect for playback completion and failure events?")
    assert "what" not in terms
    assert "should" not in terms
    assert "playback" in terms
    assert "callback" in terms


def test_extract_query_terms_merges_manual_query_variants_without_hardcoded_aliases():
    terms = _extract_query_terms(
        "渲染画布的模块有哪些",
        extra_variants=["Which render canvas modules should I inspect?"],
    )
    assert "渲染画布" in terms
    assert "render" in terms
    assert "canvas" in terms
    assert "rendercanvas" in terms


def test_classify_query_mode_detects_task_queries():
    assert _classify_query_mode("Which render pipeline modules should I inspect?") == "task"
    assert _classify_query_mode("RenderBridgeComponent") == "entity"


def test_relation_family_groups_generic_edge_semantics():
    assert _relation_family("inherits") == "hierarchy"
    assert _relation_family("contains") == "structure"
    assert _relation_family("calls") == "behavior"
    assert _relation_family("references") == "association"
    assert _relation_family("semantic_similar_to") == "similarity"


def test_relation_family_weight_prefers_structural_edges_over_similarity():
    assert _relation_family_weight("inherits", "EXTRACTED") > _relation_family_weight("references", "EXTRACTED")
    assert _relation_family_weight("references", "EXTRACTED") > _relation_family_weight("semantic_similar_to", "EXTRACTED")


def test_select_seed_nodes_prefers_definition_backed_nodes():
    G = _make_task_graph()
    question = "Which render canvas modules should I inspect?"
    terms = _extract_query_terms(question)
    seeds = _select_seed_nodes(G, question, terms)
    labels = [seed["label"] for seed in seeds]
    # At least one seed should match the "render canvas" query terms
    assert any(l in labels for l in ("RenderPipeline", "CanvasMaterial", "CanvasResource", "RenderView")), f"Seeds: {labels}"
    # Seeds should have non-zero scores (base_scores dict is correctly keyed by nid)
    assert all(seed.get("seed_score", 0) > 0 for seed in seeds), f"Seed scores: {[(s['label'], s.get('seed_score', 0)) for s in seeds]}"


def test_select_seed_nodes_returns_empty_without_any_lexical_anchor():
    G = _make_task_graph()
    question = "视频播放的组件有哪些"
    seeds = _select_seed_nodes(G, question, _extract_query_terms(question))
    assert seeds == []


def test_expand_task_candidates_reaches_core_working_set():
    G = _make_task_graph()
    question = "Which render canvas modules should I inspect?"
    seeds = _select_seed_nodes(G, question, _extract_query_terms(question))
    candidates = _expand_task_candidates(G, seeds, max_hops=2)
    labels = {G.nodes[nid]["label"] for nid in candidates}
    assert {"FrameController", "CanvasMaterial", "CanvasResource", "SurfaceTexture"}.issubset(labels)


def test_rank_task_candidates_returns_connected_core_types_before_samples():
    G = _make_task_graph()
    question = "Which render canvas modules should I inspect?"
    terms = _extract_query_terms(question)
    hub_labels = _compute_hub_labels(G)
    seeds = _select_seed_nodes(G, question, terms, hub_labels=hub_labels)
    candidates = _expand_task_candidates(G, seeds, max_hops=2)
    discriminative_compacts = set()
    for t in terms:
        tc = _normalize_query_text(t).replace(" ", "")
        if tc and tc not in hub_labels and len(tc) > 2:
            discriminative_compacts.add(tc)
    ranked = _rank_task_candidates(G, question, terms, seeds, candidates, limit=6, discriminative_compacts=discriminative_compacts, hub_labels=hub_labels)
    labels = [item["label"] for item in ranked]
    assert "SampleRenderFlow" not in labels
    # After fixing direct_scores dict, ranking is more accurate:
    # RenderPipeline should appear, RenderView may be displaced by other relevant nodes
    assert "RenderPipeline" in labels[:4], f"Top 4: {labels[:4]}"
    assert "CanvasMaterial" in labels


def test_query_graph_task_mode_returns_structured_navigation_cards():
    G = _make_task_graph()
    payload = _query_graph(G, "Which render canvas modules should I inspect?", json_output=True)
    assert payload["query_mode"] == "task"
    assert payload["query_variants"] == ["Which render canvas modules should I inspect?"]
    labels = [item["label"] for item in payload["results"][:6]]
    assert "RenderPipeline" in labels[:4], f"Top 4: {labels[:4]}"
    assert "CanvasMaterial" in labels
    first = payload["results"][0]
    assert first["source_file"]
    assert first["start_line"] in {5, 10, 40, 50}
    assert isinstance(first["relation_path"], list)


def test_query_graph_accepts_cross_language_query_variants_for_task_seeding():
    G = _make_task_graph()
    payload = _query_graph(
        G,
        "视频里渲染画布的核心组件有哪些",
        json_output=True,
        query_variants=["Which render canvas modules should I inspect?"],
    )
    assert payload["query_mode"] == "task"
    # Manual variant must be present; auto-translation may also be appended
    assert "Which render canvas modules should I inspect?" in payload["query_variants"]
    assert payload["query_variants"][0] == "视频里渲染画布的核心组件有哪些"
    labels = [item["label"] for item in payload["results"][:6]]
    assert "RenderPipeline" in labels


# --- _bfs ---

def test_bfs_depth_1():
    G = _make_graph()
    visited, edges = _bfs(G, ["n1"], depth=1)
    assert "n1" in visited
    assert "n2" in visited  # direct neighbor
    assert "n3" not in visited  # 2 hops away

def test_bfs_depth_2():
    G = _make_graph()
    visited, edges = _bfs(G, ["n1"], depth=2)
    assert "n3" in visited  # n1 -> n2 -> n3

def test_bfs_disconnected():
    G = _make_graph()
    visited, edges = _bfs(G, ["n5"], depth=3)
    assert visited == {"n5"}  # isolated node

def test_bfs_returns_edges():
    G = _make_graph()
    visited, edges = _bfs(G, ["n1"], depth=1)
    assert len(edges) >= 1
    assert any(u == "n1" or v == "n1" for u, v in edges)


# --- _dfs ---

def test_dfs_depth_1():
    G = _make_graph()
    visited, edges = _dfs(G, ["n1"], depth=1)
    assert "n1" in visited
    assert "n2" in visited
    assert "n3" not in visited

def test_dfs_full_chain():
    G = _make_graph()
    visited, edges = _dfs(G, ["n1"], depth=5)
    assert {"n1", "n2", "n3", "n4"}.issubset(visited)


# --- _subgraph_to_text ---

def test_subgraph_to_text_contains_labels():
    G = _make_graph()
    text = _subgraph_to_text(G, {"n1", "n2"}, [("n1", "n2")])
    assert "extract" in text
    assert "cluster" in text

def test_subgraph_to_text_truncates():
    G = _make_graph()
    # Very small budget forces truncation
    text = _subgraph_to_text(G, {"n1", "n2", "n3", "n4"}, [("n1", "n2")], token_budget=1)
    assert "truncated" in text

def test_subgraph_to_text_edge_included():
    G = _make_graph()
    text = _subgraph_to_text(G, {"n1", "n2"}, [("n1", "n2")])
    assert "EDGE" in text
    assert "calls" in text


# --- _load_graph ---

def test_load_graph_roundtrip(tmp_path):
    G = _make_graph()
    data = json_graph.node_link_data(G, edges="links")
    p = tmp_path / "graph.json"
    p.write_text(json.dumps(data))
    G2 = _load_graph(str(p))
    assert G2.number_of_nodes() == G.number_of_nodes()
    assert G2.number_of_edges() == G.number_of_edges()

def test_load_graph_missing_file(tmp_path):
    graphify_dir = tmp_path / "graphify-out"
    graphify_dir.mkdir()
    with pytest.raises(SystemExit):
        _load_graph(str(graphify_dir / "nonexistent.json"))
