import pytest
from graphify.validate import (
    validate_extraction, assert_valid,
    validate_extraction_density, flag_low_density_cached,
    DEFAULT_DENSITY_THRESHOLDS,
)

VALID = {
    "nodes": [
        {"id": "n1", "label": "Foo", "file_type": "code", "source_file": "foo.py"},
        {"id": "n2", "label": "Bar", "file_type": "document", "source_file": "bar.md"},
    ],
    "edges": [
        {"source": "n1", "target": "n2", "relation": "references",
         "confidence": "EXTRACTED", "source_file": "foo.py", "weight": 1.0},
    ],
}

def test_valid_passes():
    assert validate_extraction(VALID) == []

def test_missing_nodes_key():
    errors = validate_extraction({"edges": []})
    assert any("nodes" in e for e in errors)

def test_missing_edges_key():
    errors = validate_extraction({"nodes": []})
    assert any("edges" in e for e in errors)

def test_not_a_dict():
    errors = validate_extraction([])
    assert len(errors) == 1

def test_invalid_file_type():
    data = {
        "nodes": [{"id": "n1", "label": "X", "file_type": "video", "source_file": "x.mp4"}],
        "edges": [],
    }
    errors = validate_extraction(data)
    assert any("file_type" in e for e in errors)

def test_invalid_confidence():
    data = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"},
            {"id": "n2", "label": "B", "file_type": "code", "source_file": "b.py"},
        ],
        "edges": [
            {"source": "n1", "target": "n2", "relation": "calls",
             "confidence": "CERTAIN", "source_file": "a.py"},
        ],
    }
    errors = validate_extraction(data)
    assert any("confidence" in e for e in errors)

def test_dangling_edge_source():
    data = {
        "nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"}],
        "edges": [
            {"source": "missing_id", "target": "n1", "relation": "calls",
             "confidence": "EXTRACTED", "source_file": "a.py"},
        ],
    }
    errors = validate_extraction(data)
    assert any("source" in e and "missing_id" in e for e in errors)

def test_dangling_edge_target():
    data = {
        "nodes": [{"id": "n1", "label": "A", "file_type": "code", "source_file": "a.py"}],
        "edges": [
            {"source": "n1", "target": "ghost", "relation": "calls",
             "confidence": "EXTRACTED", "source_file": "a.py"},
        ],
    }
    errors = validate_extraction(data)
    assert any("target" in e and "ghost" in e for e in errors)

def test_missing_node_field():
    data = {
        "nodes": [{"id": "n1", "label": "A", "source_file": "a.py"}],  # missing file_type
        "edges": [],
    }
    errors = validate_extraction(data)
    assert any("file_type" in e for e in errors)

def test_assert_valid_raises_on_errors():
    with pytest.raises(ValueError, match="error"):
        assert_valid({"nodes": [], "edges": [], "oops": True, **{"nodes": "bad"}})

def test_assert_valid_passes_silently():
    assert_valid(VALID)  # should not raise


# ---------------------------------------------------------------------------
# Extraction density tests
# ---------------------------------------------------------------------------

def test_density_ok_document():
    """A document with enough nodes per word should not be flagged."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "document", "source_file": "/a.md"},
            {"id": "n2", "label": "B", "file_type": "document", "source_file": "/a.md"},
        ],
        "edges": [],
    }
    fwc = {"/a.md": 800}  # 2 nodes / 800 words = 1/400 > 1/500
    result = validate_extraction_density(extraction, fwc)
    assert "/a.md" not in result["low_density_files"]
    assert "/a.md" not in result["zero_node_files"]


def test_density_low_document():
    """A document with too few nodes per word should be flagged."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "document", "source_file": "/big.md"},
        ],
        "edges": [],
    }
    fwc = {"/big.md": 5000}  # 1 node / 5000 words = 1/5000 < 1/500
    result = validate_extraction_density(extraction, fwc)
    assert "/big.md" in result["low_density_files"]


def test_density_zero_nodes():
    """A file with words but zero extracted nodes."""
    extraction = {"nodes": [], "edges": []}
    fwc = {"/empty.md": 1000}
    result = validate_extraction_density(extraction, fwc)
    assert "/empty.md" in result["zero_node_files"]


def test_density_skips_code():
    """Code files should be skipped (no threshold)."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "code", "source_file": "/a.py"},
        ],
        "edges": [],
    }
    fwc = {"/a.py": 10000}
    result = validate_extraction_density(extraction, fwc)
    assert "/a.py" not in result["low_density_files"]
    assert "/a.py" not in result["zero_node_files"]


def test_density_paper_threshold():
    """Paper has a higher (looser) threshold than document."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "X", "file_type": "paper", "source_file": "/p.pdf"},
        ],
        "edges": [],
    }
    fwc = {"/p.pdf": 600}
    result = validate_extraction_density(extraction, fwc)
    # 1 node / 600 words = 1/600, paper threshold is 1/800, so this is OK
    assert "/p.pdf" not in result["low_density_files"]


def test_flag_low_density_cached():
    """flag_low_density_cached returns files needing re-extraction."""
    cached_nodes = [
        {"id": "n1", "label": "A", "file_type": "document", "source_file": "/sparse.md"},
    ]
    cached_edges = []
    fwc = {"/sparse.md": 5000}  # density = 1/5000 < 1/500
    result = flag_low_density_cached(cached_nodes, cached_edges, fwc)
    assert "/sparse.md" in result


def test_density_custom_thresholds():
    """Custom thresholds should override defaults."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "document", "source_file": "/a.md"},
        ],
        "edges": [],
    }
    fwc = {"/a.md": 800}
    # With default threshold (1/500): 1/800 < 1/500 → low density
    result_default = validate_extraction_density(extraction, fwc)
    assert "/a.md" in result_default["low_density_files"]

    # With custom loose threshold (1/1000): 1/800 > 1/1000 → OK
    result_custom = validate_extraction_density(extraction, fwc, thresholds={"document": 1 / 1000})
    assert "/a.md" not in result_custom["low_density_files"]


def test_density_path_suffix_matching():
    """Relative source_file in nodes should match absolute path in file_word_counts."""
    extraction = {
        "nodes": [
            {"id": "n1", "label": "A", "file_type": "document", "source_file": "video.md"},
        ],
        "edges": [],
    }
    # source_file is "video.md" but file_word_counts key is absolute
    fwc = {"/abs/path/to/video.md": 5000}
    result = validate_extraction_density(extraction, fwc)
    assert "/abs/path/to/video.md" in result["low_density_files"]
