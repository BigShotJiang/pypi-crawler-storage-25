"""Benchmark test: measure knowledge-graph build time for a real corpus.

Runs the graphify pipeline (detect → extract → build → cluster → export)
on a user-specified corpus directory, records elapsed time to a per-run txt
file, and compares with the previous run on the same corpus.

For pure-document corpora (no code files), AST extraction produces nothing,
so the test loads the pre-built extraction from graphify-out/graph.json
to exercise the build/cluster/analyze/export pipeline.

Run:
    pytest tests/test_graph_build_perf.py -v -s --corpus-dir=/path/to/corpus
"""
from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _path_tag(path: Path) -> str:
    """Short deterministic tag from a path, for result filenames."""
    h = hashlib.sha1(str(path.resolve()).encode()).hexdigest()[:8]
    stem = path.resolve().name.replace(" ", "_")[:20]
    return f"{stem}_{h}"


def _parse_result(path: Path) -> dict:
    """Parse a result txt file into a dict."""
    data: dict = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if ": " in line:
            key, val = line.split(": ", 1)
            data[key.strip()] = val.strip()
    return data


def _write_result(path: Path, info: dict) -> None:
    """Write result dict to a txt file."""
    lines = [f"{k}: {v}" for k, v in info.items()]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _load_extraction(corpus_dir: Path) -> dict:
    """Load extraction data from the corpus graphify-out directory."""
    graph_path = corpus_dir / "graphify-out" / "graph.json"
    if not graph_path.exists():
        pytest.skip(
            f"No graph.json found in {graph_path}. "
            "Run /graphify on the corpus directory first."
        )

    import networkx as nx
    from networkx.readwrite import json_graph as nx_json_graph

    data = json.loads(graph_path.read_text(encoding="utf-8"))
    G = nx_json_graph.node_link_graph(data, edges="links")

    nodes = []
    for nid, ndata in G.nodes(data=True):
        nodes.append({
            "id": nid,
            "label": ndata.get("label", nid),
            "file_type": ndata.get("file_type", "document"),
            "source_file": ndata.get("source_file", ""),
            "source_location": ndata.get("source_location"),
            "source_url": ndata.get("source_url"),
            "captured_at": ndata.get("captured_at"),
            "author": ndata.get("author"),
            "contributor": ndata.get("contributor"),
        })

    edges = []
    for u, v, edata in G.edges(data=True):
        edges.append({
            "source": u,
            "target": v,
            "relation": edata.get("relation", ""),
            "confidence": edata.get("confidence", "INFERRED"),
            "confidence_score": edata.get("confidence_score", 0.5),
            "source_file": edata.get("source_file", ""),
            "source_location": edata.get("source_location"),
            "weight": edata.get("weight", 1.0),
        })

    return {
        "nodes": nodes,
        "edges": edges,
        "hyperedges": [],
        "input_tokens": 0,
        "output_tokens": 0,
    }


def _build_graph(corpus_dir: Path, output_dir: Path) -> dict:
    """Run the full graphify pipeline and return timing/stats dict."""
    from graphify.detect import detect
    from graphify.extract import extract
    from graphify.build import build_from_json
    from graphify.cluster import cluster, score_all
    from graphify.analyze import god_nodes, surprising_connections
    from graphify.report import generate
    from graphify.export import to_json, to_html

    # Phase 1: detect
    t0 = time.perf_counter()
    detection = detect(corpus_dir)
    t_detect = time.perf_counter() - t0

    code_files = [Path(f) for f in detection["files"].get("code", [])]
    doc_files = detection["files"].get("document", [])
    total_files = detection.get("total_files", 0)
    total_words = detection.get("total_words", 0)

    # Phase 2: extract (AST for code + pre-built extraction for docs)
    t0 = time.perf_counter()
    extraction = _load_extraction(corpus_dir)
    if code_files:
        ast_result = extract(code_files)
        seen_ids = {n["id"] for n in extraction["nodes"]}
        for n in ast_result.get("nodes", []):
            if n["id"] not in seen_ids:
                extraction["nodes"].append(n)
                seen_ids.add(n["id"])
        extraction["edges"].extend(ast_result.get("edges", []))
    t_extract = time.perf_counter() - t0

    # Phase 3: build graph
    t0 = time.perf_counter()
    G = build_from_json(extraction)
    t_build = time.perf_counter() - t0

    # Phase 4: cluster
    t0 = time.perf_counter()
    communities = cluster(G)
    cohesion = score_all(G, communities)
    t_cluster = time.perf_counter() - t0

    # Phase 5: analyze
    t0 = time.perf_counter()
    gods = god_nodes(G)
    surprises = surprising_connections(G, communities)
    labels = {cid: "Community " + str(cid) for cid in communities}
    t_analyze = time.perf_counter() - t0

    # Phase 6: export
    t0 = time.perf_counter()
    output_dir.mkdir(parents=True, exist_ok=True)
    to_json(G, communities, str(output_dir / "graph.json"))
    report = generate(
        G, communities, cohesion, labels, gods, surprises,
        detection, {"input": 0, "output": 0}, str(corpus_dir),
    )
    (output_dir / "GRAPH_REPORT.md").write_text(report, encoding="utf-8")
    if G.number_of_nodes() <= 5000:
        to_html(G, communities, str(output_dir / "graph.html"), community_labels=labels)
    t_export = time.perf_counter() - t0

    t_total = t_detect + t_extract + t_build + t_cluster + t_analyze + t_export

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "corpus_dir": str(corpus_dir),
        "total_files": total_files,
        "total_words": total_words,
        "code_files": len(code_files),
        "doc_files": len(doc_files),
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "communities": len(communities),
        "time_detect_s": f"{t_detect:.3f}",
        "time_extract_s": f"{t_extract:.3f}",
        "time_build_s": f"{t_build:.3f}",
        "time_cluster_s": f"{t_cluster:.3f}",
        "time_analyze_s": f"{t_analyze:.3f}",
        "time_export_s": f"{t_export:.3f}",
        "time_total_s": f"{t_total:.3f}",
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
def test_graph_build_perf(request, tmp_path):
    """Build a knowledge graph from a corpus directory and record timing."""
    corpus_dir = request.config.getoption("--corpus-dir")
    if corpus_dir is None:
        pytest.skip("No --corpus-dir specified. Usage: pytest tests/test_graph_build_perf.py --corpus-dir=/path/to/corpus")
    corpus_dir = Path(corpus_dir)
    if not corpus_dir.exists():
        pytest.skip(f"Corpus directory not found: {corpus_dir}")

    info = _build_graph(corpus_dir=corpus_dir, output_dir=tmp_path / "graphify-out")

    # Basic sanity checks
    assert info["nodes"] > 0, "Graph should have nodes"
    assert float(info["time_total_s"]) > 0, "Should take measurable time"

    # Results go into the corpus's graphify-out/perf_results/ (not in the repo)
    tag = _path_tag(corpus_dir)
    results_dir = corpus_dir / "graphify-out" / "perf_results"
    results_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_file = results_dir / f"perf_{tag}_{ts}.txt"
    _write_result(result_file, info)

    # Compare with previous run on the same corpus (match by tag)
    all_results = sorted(results_dir.glob(f"perf_{tag}_*.txt"))
    if len(all_results) >= 2:
        prev_path = all_results[-2]
        prev = _parse_result(prev_path)
        prev_total = float(prev.get("time_total_s", 0))
        curr_total = float(info["time_total_s"])
        diff = curr_total - prev_total
        pct = (diff / prev_total * 100) if prev_total > 0 else 0

        if diff > 0.5:
            verdict = "SLOWER (degradation)"
        elif diff < -0.5:
            verdict = "FASTER (improvement)"
        else:
            verdict = "STABLE (no significant change)"

        print(f"\n{'='*60}")
        print(f"  Performance comparison with previous run")
        print(f"  Corpus:   {corpus_dir}")
        print(f"  Previous: {prev_path.name}  ({prev.get('timestamp', 'N/A')})")
        print(f"  Current:  {result_file.name}")
        print(f"  Previous total: {prev_total:.3f}s")
        print(f"  Current total:  {curr_total:.3f}s")
        print(f"  Delta: {diff:+.3f}s ({pct:+.1f}%)  -> {verdict}")
        print(f"{'='*60}\n")
    else:
        print(f"\n  First run recorded: {result_file.name}")
        print(f"  Run again to see comparison.\n")

    # Print current result summary
    print(f"  Nodes: {info['nodes']}, Edges: {info['edges']}, Communities: {info['communities']}")
    print(f"  Total time: {info['time_total_s']}s  "
          f"(detect={info['time_detect_s']}s, extract={info['time_extract_s']}s, "
          f"build={info['time_build_s']}s, cluster={info['time_cluster_s']}s, "
          f"analyze={info['time_analyze_s']}s, export={info['time_export_s']}s)")
