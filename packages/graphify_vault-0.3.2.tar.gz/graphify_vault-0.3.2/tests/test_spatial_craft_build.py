"""Tests for `scripts/build_spatial_craft.py`.

The script performs a one-shot full build over the Spatial-Craft corpus
(Markdown docs + Kotlin sources + XML manifests). These tests verify:

1. A unit test over a minimal temp fixture that mirrors Spatial-Craft's
   shape (a few .md / .kt / .kts / .xml files in nested dirs). This runs
   always and should be fast.
2. An optional integration test against a real Spatial-Craft checkout,
   opted-in via `--corpus-dir=/Users/bytedance/workspace/Spatial-Craft`.

Run:
    pytest tests/test_spatial_craft_build.py
    pytest tests/test_spatial_craft_build.py \
        --corpus-dir=/Users/bytedance/workspace/Spatial-Craft -v
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "scripts" / "build_spatial_craft.py"


# ---------- helpers ----------

def _write_fixture(root: Path) -> None:
    """Lay out a tiny Spatial-Craft-shaped corpus under `root`."""
    docs = root / "documentation"
    docs.mkdir(parents=True)
    (docs / "spatial-sdk_animation_overview.md").write_text(
        "# Animation System Overview\n\n"
        "The animation system is driven by these classes:\n\n"
        "```kotlin\n"
        "class AnimationComponent : Component\n"
        "class AnimationClip\n"
        "```\n\n"
        "Attach `AnimationComponent` to an entity to play animations;\n"
        "an `AnimationClip` stores keyframes.\n",
        encoding="utf-8",
    )
    (docs / "spatial-sdk_audio_overview.md").write_text(
        "# Audio Overview\n\n"
        "```kotlin\n"
        "class ChannelAudioComponent : Component\n"
        "```\n\n"
        "Use `ChannelAudioComponent` for 3D spatial audio sources.\n",
        encoding="utf-8",
    )

    src = root / "sources" / "com" / "pico" / "sample"
    src.mkdir(parents=True)
    (src / "Sample.kt").write_text(
        "package com.pico.sample\n\n"
        "class Sample {\n"
        "    fun play() { println(\"playing\") }\n"
        "}\n",
        encoding="utf-8",
    )

    tpl = root / "templates" / "basic-spatial-template"
    tpl.mkdir(parents=True)
    (tpl / "build.gradle.kts").write_text(
        "plugins { kotlin(\"android\") }\n",
        encoding="utf-8",
    )
    (tpl / "AndroidManifest.xml").write_text(
        "<?xml version='1.0' encoding='utf-8'?>\n"
        "<manifest package='com.pico.sample'/>\n",
        encoding="utf-8",
    )


def _patch_script_target(tmp_path: Path, target: Path) -> Path:
    """Copy build_spatial_craft.py into tmp_path and redirect TARGET."""
    script = SCRIPT.read_text(encoding="utf-8")
    patched = script.replace(
        'TARGET = Path("/Users/bytedance/workspace/Spatial-Craft")',
        f'TARGET = Path(r"{target}")',
    )
    dst = tmp_path / "build_spatial_craft_under_test.py"
    dst.write_text(patched, encoding="utf-8")
    return dst


# ---------- unit test: minimal fixture ----------

def test_build_spatial_craft_minimal_fixture(tmp_path: Path) -> None:
    """End-to-end smoke test on a tiny Spatial-Craft-shaped corpus."""
    corpus = tmp_path / "Spatial-Craft"
    corpus.mkdir()
    _write_fixture(corpus)

    script = _patch_script_target(tmp_path, corpus)
    result = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True,
        text=True,
        cwd=REPO_ROOT,
        timeout=120,
    )
    assert result.returncode == 0, (
        f"build script failed:\nSTDOUT={result.stdout}\nSTDERR={result.stderr}"
    )

    out = corpus / "graphify-out"
    assert (out / "graph.json").exists(), "graph.json was not written"
    assert (out / "GRAPH_REPORT.md").exists(), "GRAPH_REPORT.md was not written"

    data = json.loads((out / "graph.json").read_text(encoding="utf-8"))
    edges_key = "links" if "links" in data else "edges"
    nodes = data["nodes"]
    edges = data[edges_key]
    assert nodes, "no nodes produced"
    # Edges may legitimately be empty for pathological tiny corpora, but the
    # minimal fixture above should produce at least `contains` edges.
    assert edges, "no edges produced"

    file_types = {n.get("file_type") for n in nodes}
    assert "document" in file_types, f"no document nodes: {file_types}"
    assert "code" in file_types, f"no code nodes: {file_types}"

    labels = {n.get("label") for n in nodes}
    # Document structural extraction should surface these ## headings.
    assert "AnimationComponent" in labels, f"missing AnimationComponent: {labels}"
    assert "ChannelAudioComponent" in labels, f"missing ChannelAudioComponent"
    # Kotlin extractor should surface the class from Sample.kt.
    assert "Sample" in labels, f"missing Sample class: {labels}"


# ---------- integration test: real Spatial-Craft checkout ----------

def test_build_spatial_craft_real_corpus(request: pytest.FixtureRequest) -> None:
    """Optional integration test against a real Spatial-Craft checkout.

    Runs only when `--corpus-dir` points at a Spatial-Craft repo and a graph
    has already been built with scripts/build_spatial_craft.py. Verifies the
    resulting graph.json matches our expectations (doc+code nodes, non-empty
    edges, reasonable scale).
    """
    corpus_dir = request.config.getoption("--corpus-dir")
    if corpus_dir is None:
        pytest.skip("No --corpus-dir specified for Spatial-Craft build test")

    graph_path = Path(corpus_dir) / "graphify-out" / "graph.json"
    if not graph_path.exists():
        pytest.skip(
            f"graph.json not found under {graph_path}; run "
            "`python scripts/build_spatial_craft.py` first"
        )

    data = json.loads(graph_path.read_text(encoding="utf-8"))
    edges_key = "links" if "links" in data else "edges"
    nodes = data["nodes"]
    edges = data[edges_key]

    assert len(nodes) > 50, f"Spatial-Craft graph has too few nodes: {len(nodes)}"
    assert len(edges) > 10, f"Spatial-Craft graph has too few edges: {len(edges)}"

    file_types = {n.get("file_type") for n in nodes}
    assert "document" in file_types, "Spatial-Craft should have document nodes"
    assert "code" in file_types, "Spatial-Craft should have code nodes"

    source_files = {n.get("source_file", "") for n in nodes if n.get("source_file")}
    # Expect at least one Markdown file and one Kotlin file in the source set.
    assert any(s.endswith(".md") for s in source_files), "no .md source file"
    assert any(s.endswith((".kt", ".kts")) for s in source_files), "no kotlin source file"
