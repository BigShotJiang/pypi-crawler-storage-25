from pathlib import Path
from graphify.extract import (
    extract_python,
    extract,
    collect_files,
    _make_id,
    extract_document,
    _resolve_document_cross_references,
    merge_document_semantic_extracts,
    rerank_semantic_nodes_for_dedup,
)

FIXTURES = Path(__file__).parent / "fixtures"


def test_make_id_strips_dots_and_underscores():
    assert _make_id("_auth") == "auth"
    assert _make_id(".httpx._client") == "httpx_client"


def test_make_id_consistent():
    """Same input always produces same output."""
    assert _make_id("foo", "Bar") == _make_id("foo", "Bar")


def test_make_id_no_leading_trailing_underscores():
    result = _make_id("__init__")
    assert not result.startswith("_")
    assert not result.endswith("_")


def test_extract_python_finds_class():
    result = extract_python(FIXTURES / "sample.py")
    labels = [n["label"] for n in result["nodes"]]
    assert "Transformer" in labels


def test_extract_python_finds_methods():
    result = extract_python(FIXTURES / "sample.py")
    labels = [n["label"] for n in result["nodes"]]
    assert any("__init__" in l or "forward" in l for l in labels)


def test_extract_python_no_dangling_edges():
    """All edge sources must reference a known node (targets may be external imports)."""
    result = extract_python(FIXTURES / "sample.py")
    node_ids = {n["id"] for n in result["nodes"]}
    for edge in result["edges"]:
        assert edge["source"] in node_ids, f"Dangling source: {edge['source']}"


def test_structural_edges_are_extracted():
    """contains / method / inherits / imports edges must always be EXTRACTED."""
    result = extract_python(FIXTURES / "sample.py")
    structural = {"contains", "method", "inherits", "imports", "imports_from"}
    for edge in result["edges"]:
        if edge["relation"] in structural:
            assert edge["confidence"] == "EXTRACTED", f"Expected EXTRACTED: {edge}"


def test_extract_merges_multiple_files():
    files = list(FIXTURES.glob("*.py"))
    result = extract(files)
    assert len(result["nodes"]) > 0
    assert result["input_tokens"] == 0


def test_collect_files_from_dir():
    files = collect_files(FIXTURES)
    supported = {".py", ".js", ".ts", ".tsx", ".go", ".rs",
                 ".java", ".c", ".cpp", ".cc", ".cxx", ".rb",
                 ".cs", ".kt", ".kts", ".scala", ".php", ".h", ".hpp",
                 ".swift", ".lua", ".toc", ".zig", ".ps1", ".ex", ".exs",
                 ".m", ".mm"}
    assert all(f.suffix in supported for f in files)
    assert len(files) > 0


def test_collect_files_skips_hidden():
    files = collect_files(FIXTURES)
    for f in files:
        assert not any(part.startswith(".") for part in f.parts)


def test_collect_files_follows_symlinked_directory(tmp_path):
    real_dir = tmp_path / "real_src"
    real_dir.mkdir()
    (real_dir / "lib.py").write_text("x = 1")
    (tmp_path / "linked_src").symlink_to(real_dir)

    files_no = collect_files(tmp_path, follow_symlinks=False)
    files_yes = collect_files(tmp_path, follow_symlinks=True)

    assert [f.name for f in files_no].count("lib.py") == 1
    assert [f.name for f in files_yes].count("lib.py") == 2


def test_collect_files_handles_circular_symlinks(tmp_path):
    sub = tmp_path / "pkg"
    sub.mkdir()
    (sub / "mod.py").write_text("x = 1")
    (sub / "cycle").symlink_to(tmp_path)

    files = collect_files(tmp_path, follow_symlinks=True)
    assert any(f.name == "mod.py" for f in files)


def test_no_dangling_edges_on_extract():
    """After merging multiple files, no internal edges should be dangling."""
    files = list(FIXTURES.glob("*.py"))
    result = extract(files)
    node_ids = {n["id"] for n in result["nodes"]}
    internal_relations = {"contains", "method", "inherits", "calls"}
    for edge in result["edges"]:
        if edge["relation"] in internal_relations:
            assert edge["source"] in node_ids, f"Dangling source: {edge}"
            assert edge["target"] in node_ids, f"Dangling target: {edge}"


def test_calls_edges_emitted():
    """Call-graph pass must produce INFERRED calls edges."""
    result = extract_python(FIXTURES / "sample_calls.py")
    calls = [e for e in result["edges"] if e["relation"] == "calls"]
    assert len(calls) > 0, "Expected at least one calls edge"


def test_calls_edges_are_extracted():
    """AST-resolved call edges are deterministic and should be EXTRACTED/1.0."""
    result = extract_python(FIXTURES / "sample_calls.py")
    for edge in result["edges"]:
        if edge["relation"] == "calls":
            assert edge["confidence"] == "EXTRACTED"
            assert edge["weight"] == 1.0


def test_calls_no_self_loops():
    result = extract_python(FIXTURES / "sample_calls.py")
    for edge in result["edges"]:
        if edge["relation"] == "calls":
            assert edge["source"] != edge["target"], f"Self-loop: {edge}"


def test_run_analysis_calls_compute_score():
    """run_analysis() calls compute_score() - must appear as a calls edge."""
    result = extract_python(FIXTURES / "sample_calls.py")
    calls = {(e["source"], e["target"]) for e in result["edges"] if e["relation"] == "calls"}
    node_by_label = {n["label"]: n["id"] for n in result["nodes"]}
    src = node_by_label.get("run_analysis()")
    tgt = node_by_label.get("compute_score()")
    assert src and tgt, "run_analysis or compute_score node not found"
    assert (src, tgt) in calls, f"run_analysis -> compute_score not found in {calls}"


def test_run_analysis_calls_normalize():
    result = extract_python(FIXTURES / "sample_calls.py")
    calls = {(e["source"], e["target"]) for e in result["edges"] if e["relation"] == "calls"}
    node_by_label = {n["label"]: n["id"] for n in result["nodes"]}
    src = node_by_label.get("run_analysis()")
    tgt = node_by_label.get("normalize()")
    assert src and tgt
    assert (src, tgt) in calls


def test_method_calls_module_function():
    """Analyzer.process() calls run_analysis() - cross class→function calls edge."""
    result = extract_python(FIXTURES / "sample_calls.py")
    calls = {(e["source"], e["target"]) for e in result["edges"] if e["relation"] == "calls"}
    node_by_label = {n["label"]: n["id"] for n in result["nodes"]}
    src = node_by_label.get(".process()")
    tgt = node_by_label.get("run_analysis()")
    assert src and tgt
    assert (src, tgt) in calls


def test_calls_deduplication():
    """Same caller→callee pair must appear only once even if called multiple times."""
    result = extract_python(FIXTURES / "sample_calls.py")
    call_pairs = [(e["source"], e["target"]) for e in result["edges"] if e["relation"] == "calls"]
    assert len(call_pairs) == len(set(call_pairs)), "Duplicate calls edges found"


def test_extract_document_finds_symbols_from_headings_and_class_lines(tmp_path):
    doc = tmp_path / "org.example.lib.core.md"
    doc.write_text(
        """# org.example.lib.core
# Base
interface Base {
}
# Alpha
@MainThread class Alpha: Base {
}
# Beta
class Beta(controller: Gamma): Base {
}
""",
        encoding="utf-8",
    )

    result = extract_document(doc)
    labels = {n["label"]: n for n in result["nodes"]}

    assert "Alpha" in labels
    assert labels["Alpha"]["id"] == "core_alpha"
    assert labels["Alpha"]["context"] == "definition"
    assert labels["Alpha"]["start_line"] == 5
    assert labels["Alpha"]["end_line"] == 7
    assert labels["Alpha"]["raws"][0] == "# Alpha"
    assert any("class Alpha" in raw for raw in labels["Alpha"]["raws"])

    assert "Beta" in labels
    assert labels["Beta"]["id"] == "core_beta"
    assert labels["Beta"]["start_line"] == 8


def test_extract_document_emits_uses_edges_from_cross_file_references(tmp_path):
    """When a symbol's raws text mentions a known symbol from another file,
    a 'uses' edge should be emitted (e.g., Alpha mentions Delta)."""
    ext_doc = tmp_path / "org.example.lib.ext.md"
    ext_doc.write_text(
        """# org.example.lib.ext
# Delta
class Delta: Base {
}
# Epsilon
class Epsilon: Config {
}
# Zeta
class Zeta: Resource {
}
""",
        encoding="utf-8",
    )

    core_doc = tmp_path / "org.example.lib.core.md"
    core_doc.write_text(
        """# org.example.lib.core
# Base
interface Base {
}
# Alpha
class Alpha: Base {
    val a = Alpha(ctx, Delta)
    Delta.bind(Zeta)
    val cfg = Epsilon.getDefault()
}
""",
        encoding="utf-8",
    )

    # Use extract() which runs single-file extractors + cross-file resolution
    result = extract([ext_doc, core_doc], cache_root=tmp_path)
    uses_edges = [e for e in result["edges"] if e["relation"] == "uses"]
    uses_pairs = {(e["source"], e["target"]) for e in uses_edges}

    # Alpha should have "uses" edges to Delta, Epsilon,
    # and Zeta because those names appear in its raws text.
    assert ("core_alpha", "ext_delta") in uses_pairs, f"Alpha uses Delta not found in {uses_pairs}"
    assert ("core_alpha", "ext_epsilon") in uses_pairs, f"Alpha uses Epsilon not found in {uses_pairs}"
    assert ("core_alpha", "ext_zeta") in uses_pairs, f"Alpha uses Zeta not found in {uses_pairs}"
    # inherits edges should still exist
    inherits = [e for e in result["edges"] if e["relation"] == "inherits"]
    inherits_pairs = {(e["source"], e["target"]) for e in inherits}
    assert ("core_alpha", "core_base") in inherits_pairs
    # No self-referencing uses edges
    assert all(e["source"] != e["target"] for e in uses_edges)


def test_extract_document_emits_inherits_edges(tmp_path):
    doc = tmp_path / "org.example.lib.core.md"
    doc.write_text(
        """# org.example.lib.core
# Base
interface Base {
}
# Alpha
class Alpha: Base {
}
""",
        encoding="utf-8",
    )

    result = extract_document(doc)
    inherits = [e for e in result["edges"] if e["relation"] == "inherits"]
    assert ("core_alpha", "core_base") in {(e["source"], e["target"]) for e in inherits}
    assert all(e["confidence"] == "EXTRACTED" for e in inherits)
    assert all(e["confidence_score"] == 1.0 for e in inherits)


def test_merge_document_semantic_extracts_canonicalizes_unique_doc_definition():
    doc_extract = {
        "nodes": [
            {"id": "core_base", "label": "Base", "file_type": "document", "context": "definition", "source_file": "org.example.lib.core.md", "source_location": "L1071", "start_line": 1071, "end_line": 1073, "raws": ["interface Base {"]},
            {"id": "core_alpha", "label": "Alpha", "file_type": "document", "context": "definition", "source_file": "org.example.lib.core.md", "source_location": "L4520", "start_line": 4520, "end_line": 4524, "raws": ["class Alpha: Base {"]},
        ],
        "edges": [
            {"source": "core_alpha", "target": "core_base", "relation": "inherits", "confidence": "EXTRACTED", "confidence_score": 1.0, "source_file": "org.example.lib.core.md", "source_location": "L4520", "weight": 1.0},
        ],
        "hyperedges": [],
    }
    sem_extract = {
        "nodes": [
            {"id": "guide_alpha", "label": "Alpha", "file_type": "document", "context": "reference", "source_file": "Guide.md", "source_location": "L1987"},
        ],
        "edges": [
            {"source": "guide_alpha", "target": "core_base", "relation": "references", "confidence": "EXTRACTED", "confidence_score": 1.0, "source_file": "Guide.md", "source_location": "L1987", "weight": 1.0},
        ],
        "hyperedges": [],
        "input_tokens": 10,
        "output_tokens": 20,
    }

    merged = merge_document_semantic_extracts(doc_extract, sem_extract)
    labels = {n["label"]: n for n in merged["nodes"]}
    assert "Alpha" in labels
    assert labels["Alpha"]["id"] == "core_alpha"
    assert labels["Alpha"]["source_file"] == "org.example.lib.core.md"
    assert labels["Alpha"]["start_line"] == 4520
    assert labels["Alpha"]["end_line"] == 4524
    assert labels["Alpha"]["raws"] == ["class Alpha: Base {"]
    refs = [e for e in merged["edges"] if e["relation"] == "references"]
    assert refs[0]["source"] == "core_alpha"


def test_merge_document_semantic_extracts_keeps_multiple_definition_labels_separate():
    doc_extract = {
        "nodes": [
            {"id": "ext_eta", "label": "Eta", "file_type": "document", "context": "definition", "source_file": "org.example.lib.ext.md", "source_location": "L2449"},
            {"id": "core_eta", "label": "Eta", "file_type": "document", "context": "definition", "source_file": "org.example.lib.core.md", "source_location": "L41"},
        ],
        "edges": [],
        "hyperedges": [],
    }
    sem_extract = {
        "nodes": [
            {"id": "guide_eta", "label": "Eta", "file_type": "document", "context": "reference", "source_file": "Guide.md", "source_location": "L123"},
        ],
        "edges": [],
        "hyperedges": [],
        "input_tokens": 0,
        "output_tokens": 0,
    }

    merged = merge_document_semantic_extracts(doc_extract, sem_extract)
    ids = {n["id"] for n in merged["nodes"]}
    assert "ext_eta" in ids
    assert "core_eta" in ids
    assert "guide_eta" in ids


def test_rerank_semantic_nodes_for_dedup_prefers_definition_backed_source(tmp_path):
    resource_doc = tmp_path / "src" / "resource.md"
    resource_doc.parent.mkdir(parents=True)
    resource_doc.write_text("# RenderMaterial\nclass RenderMaterial: Material {\n}\n", encoding="utf-8")

    example_doc = tmp_path / "examples" / "video.md"
    example_doc.parent.mkdir(parents=True)
    example_doc.write_text("RenderMaterial(texture=videoTexture)\n", encoding="utf-8")

    nodes = [
        {
            "id": "resource_rendermaterial",
            "label": "RenderMaterial",
            "context": "reference",
            "source_file": "examples/video.md",
        },
        {
            "id": "resource_rendermaterial",
            "label": "RenderMaterial",
            "context": "reference",
            "source_file": "src/resource.md",
        },
        {
            "id": "ecs_component",
            "label": "Component",
            "context": "definition",
            "source_file": "src/resource.md",
        },
    ]

    ranked = rerank_semantic_nodes_for_dedup(nodes, root=tmp_path)
    assert ranked[0]["source_file"] == "src/resource.md"
    assert ranked[1]["source_file"] == "examples/video.md"
    assert ranked[2]["id"] == "ecs_component"


def test_rerank_semantic_nodes_for_dedup_uses_path_authority_when_no_definition_found(tmp_path):
    (tmp_path / "core").mkdir()
    (tmp_path / "examples").mkdir()
    (tmp_path / "core" / "render.md").write_text("RenderMaterial()\n", encoding="utf-8")
    (tmp_path / "examples" / "render.md").write_text("RenderMaterial()\n", encoding="utf-8")

    nodes = [
        {
            "id": "resource_rendermaterial",
            "label": "RenderMaterial",
            "context": "reference",
            "source_file": "examples/render.md",
        },
        {
            "id": "resource_rendermaterial",
            "label": "RenderMaterial",
            "context": "reference",
            "source_file": "core/render.md",
        },
    ]

    ranked = rerank_semantic_nodes_for_dedup(nodes, root=tmp_path)
    assert [node["source_file"] for node in ranked] == ["core/render.md", "examples/render.md"]


# ── TSX (JSX-aware) parsing ──────────────────────────────────────────────────
# .tsx files require tree-sitter-typescript's `language_tsx`, not the plain
# `language_typescript` grammar. Parsing JSX with the wrong grammar produces
# silent ERROR nodes and drops every function/call inside JSX trees.

def test_extract_tsx_finds_helpers_and_component():
    """Functions defined alongside a JSX-returning component must be captured."""
    from graphify.extract import extract_js
    result = extract_js(FIXTURES / "sample.tsx")
    labels = [n["label"] for n in result["nodes"]]
    assert any("fmtDate" in l for l in labels), f"fmtDate missing from {labels}"
    assert any("fmtCount" in l for l in labels), f"fmtCount missing from {labels}"
    assert any("App" in l for l in labels), f"App missing from {labels}"


def test_extract_tsx_jsx_expression_calls_resolve():
    """Calls inside JSX expressions like `{fmtDate(now)}` must yield call edges.

    Regression guard for the TSX language fix: with `language_typescript`,
    JSX is parsed as ERROR nodes and these call_expressions disappear.
    """
    from graphify.extract import extract_js
    result = extract_js(FIXTURES / "sample.tsx")
    nodes_by_id = {n["id"]: n for n in result["nodes"]}
    call_targets = {
        nodes_by_id[e["target"]]["label"]
        for e in result["edges"]
        if e["relation"] == "calls" and e["target"] in nodes_by_id
    }
    assert "fmtDate()" in call_targets, (
        f"JSX expression call to fmtDate() not captured. Targets: {call_targets}"
    )
    assert "fmtCount()" in call_targets, (
        f"JSX expression call to fmtCount() not captured. Targets: {call_targets}"
    )


def test_extract_tsx_uses_tsx_grammar():
    """Wiring check: the .tsx config must use tree-sitter's `language_tsx`."""
    from graphify.extract import _TSX_CONFIG, _TS_CONFIG
    assert _TSX_CONFIG.ts_language_fn == "language_tsx"
    assert _TS_CONFIG.ts_language_fn == "language_typescript"


def test_cross_file_call_remains_inferred_without_import_evidence(tmp_path):
    """A cross-file `calls` edge must stay INFERRED when there is no import
    edge — name collision alone is insufficient evidence."""
    caller = tmp_path / "caller.js"
    callee = tmp_path / "lib.js"
    # Caller does NOT require lib — same-name function happens to exist elsewhere
    caller.write_text("function run() { doUnique(); }\n")
    callee.write_text(
        "function doUnique() { return 1; }\n"
        "module.exports = { doUnique };\n"
    )
    result = extract([caller, callee], cache_root=tmp_path)
    nodes = {n["id"]: n for n in result["nodes"]}
    call_edges = [
        e for e in result["edges"]
        if e["relation"] == "calls"
        and nodes[e["source"]]["label"] == "run()"
        and nodes[e["target"]]["label"] == "doUnique()"
    ]
    assert len(call_edges) == 1
    assert call_edges[0]["confidence"] == "INFERRED"
