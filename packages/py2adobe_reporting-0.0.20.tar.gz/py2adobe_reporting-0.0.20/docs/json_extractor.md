# JSON Extractor v2

The JSON Extractor is a visual tool that extracts table and visualization metadata from Adobe CJA Analysis Workspace projects and automatically generates API request bodies for the CJA Reporting API.

## Overview

When working with Adobe Customer Journey Analytics, creating API request bodies manually can be tedious and error-prone. The JSON Extractor v2 solves this by:

1. **Importing** an existing Workspace project by its Project ID
2. **Extracting** metadata from all panels, freeform tables, and visualizations
3. **Mining** all project components (segments, metrics, dimensions, date ranges, data views)
4. **Generating** properly formatted API request bodies ready for use with the Reporting API

### What's New in v2

- **Full Visualization Support** – Now generates request bodies for 10+ visualization types, not just freeform tables
- **Smart Source Resolution** – Visualizations automatically inherit data from linked source tables
- **Panel Dimension Item Filters** – Extracts dimension item filters applied at the panel level
- **Metric-Level Date Ranges** – Handles comparison date ranges for Key Metric Summary visualizations
- **Component Mining** – Recursively extracts all components with usage-level classification
- **Enhanced UI** – Color-coded badges for segments, metrics, and dimensions with collapsible sections

---

## Quick Start

### Using with the Reporting Class

```python
from py2adobe_reporting.auth import s2sAuth, cja_oauth_headers
from py2adobe_reporting.cja_functions.reporting_management import Reporting

# Authenticate
env = s2sAuth("path/to/config.json")
headers = cja_oauth_headers("path/to/config.json", env.token)

# Initialize reporting and launch the JSON Extractor UI
reporting = Reporting()
url = reporting.json_extractor_launch(headers)
print(f"JSON Extractor running at: {url}")

# The browser will open automatically to the UI
# When done, stop the server:
reporting.json_extractor_stop()
```

### Using Directly (Jupyter Notebooks)

```python
from py2adobe_reporting.auth import s2sAuth, cja_oauth_headers
from py2adobe_reporting import json_extractor as je

# Authenticate
env = s2sAuth("path/to/config.json")
headers = cja_oauth_headers("path/to/config.json", env.token)

# Launch the extractor UI (returns tuple of url and server)
url, server = je.launch(headers)
print(f"JSON Extractor running at: {url}")

# When finished, shut down the server
server.shutdown()
```

---

## User Interface

Once launched, the JSON Extractor opens a web-based UI in your browser with a modern dark theme.

### Layout

| Section | Description |
|---------|-------------|
| **Top Bar** | Enter Project ID and click "Import" |
| **Left Panel – Entry List** | Scrollable list of all tables and visualizations (click to select) |
| **Left Panel – JSON Preview** | Displays the generated API request body for the selected entry |
| **Right Panel** | Collapsible metadata for project, panels, tables, and visualizations |

### Visual Indicators

The UI uses color-coded badges to help identify component types:

| Badge Color | Component Type |
|-------------|----------------|
| 🔵 Blue | Segments |
| 🟢 Green | Metrics / Calculated Metrics |
| 🟠 Orange | Dimensions / Dimension Items |

### Workflow

1. **Enter Project ID** – Find this in the URL when viewing a Workspace project  
   (e.g., `https://analytics.adobe.com/.../project/<PROJECT_ID>`)
2. **Click Import** – The tool fetches the project definition and extracts all metadata
3. **Review Metadata** – Right panel shows all panels with their segments, data views, date ranges, and entries
4. **Select an Entry** – Click any table or visualization in the left panel list to view its generated request body
5. **Copy & Use** – Copy the JSON body for use with `get_single_call_report()` or other API methods

---

## Supported Visualization Types

The extractor generates API request bodies for the following visualization types:

| Visualization Type | Body Builder | Notes |
|-------------------|--------------|-------|
| **Freeform Table** | `build_freeform_request_body` | Full support for dimensions, metrics, metric-level segments |
| **Key Metric Summary** | `build_key_metric_summary_body` | Supports primary and comparison date ranges |
| **Area Chart** | `build_area_or_combo_body` | Time-based dimension with `dimensionSort: asc` |
| **Combo Chart** | `build_area_or_combo_body` | Time-based dimension with `dimensionSort: asc` |
| **Horizontal Bar** | `build_area_or_combo_body` | Top 10 limit, excludes nones |
| **Bar Chart** | `build_search_body` | Uses locked selection for item IDs |
| **Stacked Bar** | `build_static_row_segment_body` | Includes search with item IDs |
| **Horizontal Stacked Bar** | `build_static_row_segment_body` | No search |
| **Summary Number** | `build_search_body` | Uses locked selection for item IDs |
| **Donut** | `build_static_row_segment_body` | No search |

### Unsupported Visualizations

Visualizations not in the list above will return `format: "UNSUPPORTED"` with a `body: null`. These may require manual request body creation.

---

## Source Resolution

Visualizations in Analysis Workspace often derive their data from nearby freeform tables. The extractor automatically resolves these source relationships:

### Resolution Order

1. **linkedSourceId** – Explicit pointer to a source freeform table (strongest match)
2. **Previous Freeform Table** – Falls back to the nearest earlier freeform table in the same panel
3. **Standalone** – No source found; visualization must define its own structure

### Inherited Properties

When a visualization is linked to a source table, it can inherit:

- **Dimension** – `table_dimension_id` and `table_dimension_name`
- **Metrics** – Full metric specifications including segments
- **Table Segments** – Segments applied at the table level

The metadata output includes `source_resolution` to indicate how the source was determined:

| Value | Meaning |
|-------|---------|
| `self` | Freeform table (is its own source) |
| `linkedSourceId` | Resolved via explicit linked source ID |
| `fallback_previous_freeform` | Resolved via nearest earlier freeform in same panel |
| `standalone` | No source found |

---

## Panel-Level Features

### Panel Segments

Segments applied at the panel level are automatically included in the `globalFilters` array of all generated request bodies for that panel.

### Panel Dimension Item Filters

The extractor now supports dimension item filters at the panel level. These appear in the metadata under `panel_dimension_item_filters`:

```json
{
  "panel_dimension_item_filters": [
    {
      "item_name": "United States",
      "item_id": "variables/geocountry::0"
    }
  ]
}
```

### Date Ranges

The extractor automatically converts Workspace preset date ranges to ISO format:

| Preset | Generated ISO Format Example |
|--------|------------------------------|
| This Month | `2026-04-01T00:00:00.000/2026-05-01T00:00:00.000` |
| Today | `2026-04-15T00:00:00.000/2026-04-16T00:00:00.000` |
| Yesterday | `2026-04-14T00:00:00.000/2026-04-15T00:00:00.000` |
| This Week | Monday of current week to Monday of next week |
| Last Week | Monday of previous week to Monday of current week |

> **Note:** Uses `America/Los_Angeles` timezone by default.

---

## Metric Specifications

Each metric extracted includes detailed information:

```json
{
  "metric_id": "metrics/visits",
  "metric_name": "Visits",
  "metric_type": "Metric",
  "metric_segment": [
    {
      "segment_id": "s300000938_1234567890",
      "segment_name": "Mobile Users"
    }
  ],
  "metric_date_ranges": []
}
```

### Metric-Level Segments (metricFilters)

When metrics have segments applied, the extractor generates `metricFilters` in the request body with unique filter IDs referenced by each metric.

### Metric-Level Date Ranges

For Key Metric Summary visualizations, the extractor captures:

- **Primary Date Range** – Main date range for the metric
- **Comparison Date Range** – Optional comparison period for trend analysis

---

## Component Mining

The extractor performs deep recursive mining of all project components:

### Component Categories

| Category | Description |
|----------|-------------|
| `dataviews` | Data views (report suites) used in panels |
| `date_ranges` | All date range entities |
| `segments` | Segment filters |
| `dimensions` | Dimension variables |
| `dimension_items` | Specific dimension values |
| `metrics` | Standard metrics |
| `calculated_metrics` | Calculated/derived metrics |

### Usage Levels

Each component is classified by where it appears:

| Level | Location |
|-------|----------|
| `panel_dataview` | Data view assigned to a panel |
| `panel_date_range` | Date range at panel level |
| `panel_segment` | Segment in panel segment groups |
| `table_dimension` | Primary dimension on a table |
| `breakdown_dimension` | Breakdown dimension |
| `static_row` | Static row configuration |
| `column_metric` | Metric in column tree |
| `metric_filter` | Segment applied to a metric |
| `locked_selection_row` | Locked selection row item |

---

## API Reference

### `launch(headers, host="127.0.0.1", port=0, open_browser=True)`

Start the Flask UI in a background thread.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `headers` | dict | required | OAuth headers from `cja_oauth_headers()` |
| `host` | str | `"127.0.0.1"` | Host address for the server |
| `port` | int | `0` | Port number (0 = auto-assign available port) |
| `open_browser` | bool | `True` | Whether to open browser automatically |

**Returns:** `tuple(url, server)`

- `url` – The URL where the UI is running (e.g., `http://127.0.0.1:52341/`)
- `server` – Server thread object with `.shutdown()` method

### Flask Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Renders the JSON Extractor UI |
| `/importProject` | POST | Imports a project and returns metadata |
| `/createBodies` | POST | Generates request bodies from metadata |

---

## Using Generated Bodies

Once you have a generated request body, use it with the Reporting class:

```python
from py2adobe_reporting.cja_functions.reporting_management import Reporting

reporting = Reporting()

# Use with get_single_call_report for simple requests
result = reporting.get_single_call_report(headers, body)

# Or use with get_all_rows_report for paginated requests
all_rows = reporting.get_all_rows_report(headers, body, rows_per_page=50000)
```

---

## Request Body Structure

Generated request bodies follow the CJA Reporting API structure:

```json
{
  "globalFilters": [
    {"type": "segment", "segmentId": "s300000938_..."},
    {"type": "dateRange", "dateRange": "2026-04-01T00:00:00.000/2026-05-01T00:00:00.000"}
  ],
  "metricContainer": {
    "metrics": [
      {"columnId": "0", "id": "metrics/visits", "filters": ["0"]},
      {"columnId": "1", "id": "metrics/visitors"}
    ],
    "metricFilters": [
      {"id": "0", "type": "segment", "segmentId": "s300000938_..."}
    ]
  },
  "dimension": "variables/page",
  "settings": {
    "countRepeatInstances": true,
    "includeAnnotations": true,
    "nonesBehavior": "return-nones",
    "limit": 50,
    "page": 0
  },
  "statistics": {"functions": ["col-max", "col-min"]},
  "capacityMetadata": {
    "associations": [
      {"name": "applicationName", "value": "Analysis Workspace UI"},
      {"name": "projectId", "value": "..."},
      {"name": "projectName", "value": "My Project"},
      {"name": "panelName", "value": "Panel 1"}
    ]
  },
  "dataId": "dv_1234567890abcdef"
}
```

---

## Troubleshooting

### Missing Fields

If the `missing_fields` array contains items, the generated body may be incomplete:

| Missing Field | Cause | Solution |
|--------------|-------|----------|
| `panel.dataview_id` | Data view not found in project | Verify project has a data view selected |
| `panel.date_range.iso_date` | Date range couldn't be parsed | Use a supported preset or custom ISO range |
| `table.table_dimension_id` | No dimension found on table | Ensure table has a dimension configured |

### Unsupported Visualization

If you see `format: "UNSUPPORTED"`:
- The visualization type is not yet supported
- Create the request body manually based on similar supported types
- Consider using the source table's body if the visualization is linked

### Visualization Missing Data

If a visualization shows missing dimensions or metrics:
1. Check `source_resolution` – if `standalone`, add data manually
2. Verify the source freeform table has the expected configuration
3. Review `source_table_*` fields in the metadata

### Static Row Limitations

Tables using static rows with segments may require manual adjustment of numeric `metricFilters` that cannot be fully derived from metadata.

### Server Won't Start

If the server fails to start:
1. Ensure no other process is using the port
2. Try specifying a different port: `je.launch(headers, port=5001)`
3. Check that Flask is installed: `pip install flask`

---

## Example Metadata Output

After importing a project, you'll see metadata structured like:

```json
{
  "project_metadata": {
    "project_name": "Q1 Performance Dashboard",
    "project_id": "proj_abc123"
  },
  "panels": [
    {
      "panel_name": "Overview Panel",
      "dataview_id": "dv_1234567890",
      "dataview_name": "Production Data View",
      "date_range": {
        "preset_date_range": "This Month",
        "iso_date": "2026-04-01T00:00:00.000/2026-05-01T00:00:00.000",
        "date_range_id": "..."
      },
      "panel_segments": [
        {"segment_name": "All Visitors", "segment_id": "s300000938_..."}
      ],
      "panel_dimension_item_filters": [],
      "tables": [
        {
          "table_name": "Page Performance",
          "entity_kind": "table",
          "visualization_type": "Freeform Table",
          "reportlet_type": "FreeformReportlet",
          "table_dimension_id": "variables/page",
          "table_dimension_name": "Page",
          "source_resolution": "self",
          "metrics": [...]
        },
        {
          "table_name": "Traffic Trend",
          "entity_kind": "visualization",
          "visualization_type": "AreaReportlet",
          "reportlet_type": "AreaReportlet",
          "source_resolution": "linkedSourceId",
          "source_table_name": "Page Performance",
          "metrics": [...]
        }
      ]
    }
  ],
  "mined_components": {
    "dataviews": [...],
    "segments": [...],
    "metrics": [...],
    "dimensions": [...],
    "calculated_metrics": [...]
  }
}
```

---

## Dependencies

- **Flask** – Web framework for the UI server
- **Werkzeug** – WSGI server implementation
- **zoneinfo** – Timezone handling (Python 3.9+)

Install with:
```bash
pip install flask
```
