### TESTING GUIDE

This guide assumes you have already set up python or are using an environment that is already set up with access to PyPi:

## Requirements
- Python >= 3.10
- Adobe CJA API credentials (OAuth 2.0 Server-to-Server)
- Flask==3.1.2
- numpy==2.4.1
- pandas==3.0.0
- plotly==6.5.0
- pytest==8.2.2
- pytz==2024.1
- Requests==2.32.5
- Werkzeug==3.1.5

## Installation - Windows

```bash
pip install py2adobe_reporting
```

## Installation - MacOS

```bash
pip3 install py2adobe_reporting
```

## Authentication 
Create a JSON configuration file with your Adobe credentials:
```json
{
  "client_secret": "your-client-secret",
  "company_id": "your-company-id",
  "ims_host": "ims",
  "token_url": "token_url",
  "default_headers": {
    "x-api-key": "your-api-key",
    "x-gw-ims-org-id": "your-org-id"
  },
  "scopes": "api_scopes",
}
```

```python
from py2adobe_reporting.auth import s2s_auth

# Authenticate and get environment object
env = s2s_auth("path/to/config.json")
```

## Generate Headers

```python
from py2adobe_reporting.auth import cja_oauth_headers

# Create headers for API calls
headers = cja_oauth_headers("path/to/config.json", env.token)
```

```python
from py2adobe_reporting.cja_functions.reporting_management import Reporting

# Initialize reporting class
reporting = Reporting()
```

## Run the following functions -Example values only

### Get daily time series report
```python
df = reporting.daily_time_series_report(
    headers=headers,
    data_view_id="your-data-view-id",
    start_date="2024-01-01",
    end_date="2024-01-31",
    metric="metrics/visits"
)
```

### Get Daily Visits
```python
df = reporting.daily_time_series_report(
    headers=headers,
    data_view_id="your-data-view-id",
    start_date="2024-01-01",
    end_date="2024-01-31",
    metric="metrics/visits"
)
```

### Get Monthly Visits

```python
df = reporting.monthly_time_series_report(
    headers=headers,
    data_view_id="dv_123",
    start_date="2024-01-01",
    end_date="2024-12-31",
    metric="metrics/visits"
)
```

### Breakdown by Multiple Dimensions

```python
df = reporting.breakdown_report(
    headers=headers,
    data_view_id="dv_123",
    start_date="2024-01-01",
    end_date="2024-01-31",
    dimension="variables/page",
    metric="metrics/visits",
    dim_rows_per_page=50,
    breakdown_dim="variables/browser",
    breakdown_rows_per_page=50
)
```

### Search for Dimension Items

```python
df = reporting.get_top_ten_dimension_items(
    headers=headers,
    data_view_id="dv_123",
    start_date="2024-01-01",
    end_date="2024-01-31",
    dimension="variables/page",
    search_type="contains",
    contains_term="( CONTAINS 'product' )"
)
```
