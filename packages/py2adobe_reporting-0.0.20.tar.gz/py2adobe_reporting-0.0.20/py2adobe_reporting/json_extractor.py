from __future__ import annotations

import json
import os
import threading
import time
import webbrowser
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Set, Tuple
from zoneinfo import ZoneInfo

from flask import Flask, jsonify, render_template, request
from py2adobe_reporting.http_client import DEFAULT_RETRY_COUNT, HttpClient
from werkzeug.serving import make_server


SUPPORTED_ENTITY_TYPES = {
    "ReportSuite",
    "DateRange",
    "Segment",
    "Dimension",
    "DimensionItem",
    "Metric",
    "CalculatedMetric",
}

ENTITY_TYPE_TO_GROUP = {
    "ReportSuite": "dataviews",
    "DateRange": "date_ranges",
    "Segment": "segments",
    "Dimension": "dimensions",
    "DimensionItem": "dimension_items",
    "Metric": "metrics",
    "CalculatedMetric": "calculated_metrics",
}

FREEFORM_DIMENSION_FALLBACK = "variables/daterangeday"


# -----------------------------
# Safe helpers
# -----------------------------
def as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def safe_get(node: Any, key: str, default: Any = "") -> Any:
    return node.get(key, default) if isinstance(node, dict) else default


def meta_name(node: Any) -> str:
    node = as_dict(node)
    meta = as_dict(node.get("__metaData__"))
    return meta.get("name") or node.get("name") or ""

def build_freeform_subpanel_index(panel: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """
    Index freeform subpanels in a panel by subpanel id.
    Visualizations can use linkedSourceId to point back to one of these.
    """
    index: Dict[str, Dict[str, Any]] = {}

    for subpanel in as_list(panel.get("subPanels")):
        subpanel_dict = as_dict(subpanel)
        subpanel_id = subpanel_dict.get("id", "")
        reportlet = as_dict(subpanel_dict.get("reportlet"))

        if not subpanel_id:
            continue

        if reportlet.get("type") == "FreeformReportlet":
            index[subpanel_id] = subpanel_dict

    return index


def find_previous_freeform_subpanel(
    panel: Dict[str, Any],
    current_subpanel_id: str,
) -> Optional[Dict[str, Any]]:
    """
    Fallback resolver:
    find the nearest previous freeform subpanel in the same panel.
    """
    previous_freeform: Optional[Dict[str, Any]] = None

    for subpanel in as_list(panel.get("subPanels")):
        subpanel_dict = as_dict(subpanel)
        if subpanel_dict.get("id") == current_subpanel_id:
            break

        reportlet = as_dict(subpanel_dict.get("reportlet"))
        if reportlet.get("type") == "FreeformReportlet":
            previous_freeform = subpanel_dict

    return previous_freeform


def resolve_visualization_source_subpanel(
    panel: Dict[str, Any],
    subpanel: Dict[str, Any],
    freeform_index: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Resolve a visualization to its source freeform table when possible.

    Resolution order:
    1. linkedSourceId -> freeform subpanel id
    2. nearest previous freeform subpanel in the same panel
    3. standalone / unresolved
    """
    subpanel = as_dict(subpanel)
    reportlet = as_dict(subpanel.get("reportlet"))
    reportlet_type = reportlet.get("type", "")
    linked_source_id = subpanel.get("linkedSourceId", "")

    # Freeform tables are their own source
    if reportlet_type == "FreeformReportlet":
        return {
            "source_subpanel": subpanel,
            "source_subpanel_id": subpanel.get("id", ""),
            "source_resolution": "self",
        }

    # Strongest match: explicit pointer
    if linked_source_id and linked_source_id in freeform_index:
        return {
            "source_subpanel": freeform_index[linked_source_id],
            "source_subpanel_id": linked_source_id,
            "source_resolution": "linkedSourceId",
        }

    # Fallback: nearest earlier freeform table in same panel
    fallback = find_previous_freeform_subpanel(panel, subpanel.get("id", ""))
    if fallback:
        return {
            "source_subpanel": fallback,
            "source_subpanel_id": fallback.get("id", ""),
            "source_resolution": "fallback_previous_freeform",
        }

    # No source found
    return {
        "source_subpanel": None,
        "source_subpanel_id": linked_source_id or "",
        "source_resolution": "standalone",
    }


def is_real_segment(seg: Dict[str, Any]) -> bool:
    sid = as_dict(seg).get("segment_id")
    return bool(sid) and "No " not in str(sid)
def collect_segments_anywhere(node: Any) -> List[Dict[str, Any]]:
    found: List[Dict[str, Any]] = []

    def walk(n: Any) -> None:
        if isinstance(n, dict):
            component = as_dict(n.get("component"))
            if component.get("type") == "Segment":
                found.append({
                    "segment_id": component.get("id", ""),
                    "segment_name": meta_name(component) or safe_get(n, "name"),
                })

            if n.get("__entity__") is True and n.get("type") == "Segment":
                found.append({
                    "segment_id": n.get("id", ""),
                    "segment_name": meta_name(n) or safe_get(n, "name"),
                })

            for value in n.values():
                walk(value)

        elif isinstance(n, list):
            for item in n:
                walk(item)

    walk(node)

    deduped: List[Dict[str, Any]] = []
    seen = set()
    for seg in found:
        key = (seg.get("segment_id"), seg.get("segment_name"))
        if key not in seen:
            seen.add(key)
            deduped.append(seg)

    return deduped


def flatten_metric_segments(metric_segment_field: Any) -> List[Dict[str, Any]]:
    if not metric_segment_field:
        return []
    if (
        isinstance(metric_segment_field, list)
        and len(metric_segment_field) == 1
        and isinstance(metric_segment_field[0], list)
    ):
        return metric_segment_field[0]
    if (
        isinstance(metric_segment_field, list)
        and (not metric_segment_field or isinstance(metric_segment_field[0], dict))
    ):
        return metric_segment_field
    return []



# -----------------------------
# Date range helpers
# -----------------------------
def generate_iso_date(date_name: str) -> str:
    now = datetime.now(ZoneInfo("America/Los_Angeles"))
    if date_name == "This Month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = start.replace(year=start.year + 1, month=1) if start.month == 12 else start.replace(month=start.month + 1)
    elif date_name == "Today":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
    elif date_name == "Yesterday":
        end = now.replace(hour=0, minute=0, second=0, microsecond=0)
        start = end - timedelta(days=1)
    elif date_name == "This Week":
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        start = today - timedelta(days=today.weekday())
        end = start + timedelta(days=7)
    elif date_name == "Last Week":
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = today - timedelta(days=today.weekday())
        start = end - timedelta(days=7)
    else:
        raise ValueError(f"Unsupported date range name: {date_name}")
    return f"{start.strftime('%Y-%m-%d')}T00:00:00.000/{end.strftime('%Y-%m-%d')}T00:00:00.000"


def normalize_date_range_entity(date_node: Dict[str, Any]) -> Dict[str, str]:
    node = as_dict(date_node)
    meta = as_dict(node.get("__metaData__"))
    date_id = node.get("id") or ""
    date_name = meta_name(node)
    iso_date = ""

    if meta.get("definition"):
        iso_date = meta.get("definition", "")
    elif date_name:
        try:
            iso_date = generate_iso_date(date_name)
        except Exception:
            iso_date = ""

    return {
        "date_range_id": date_id,
        "date_range_name": date_name,
        "date_range": iso_date,
    }


# -----------------------------
# Recursive miner
# -----------------------------
def classify_usage_level(path: str, entity_type: str) -> str:
    if ".panels[]" in path and path.endswith(".reportSuite"):
        return "panel_dataview"
    if ".panels[]" in path and path.endswith(".dateRange"):
        return "panel_date_range"
    if "segmentGroups" in path:
        return "panel_segment"
    if "freeformTable.dimensionSettings" in path or path.endswith(".freeformTable.dimension") or "freeformTable.dimensions[]" in path:
        return "table_dimension"
    if "freeformTable.breakdowns" in path and (".dimension" in path or ".dimensions[]" in path):
        return "breakdown_dimension"
    if "freeformTable.staticRows" in path:
        return "static_row"
    if "columnTree" in path:
        if entity_type == "Segment":
            return "metric_filter"
        if entity_type == "Metric":
            return "column_metric"
        if entity_type == "CalculatedMetric":
            return "column_calculated_metric"
        if entity_type == "Dimension":
            return "column_dimension"
        if entity_type == "DimensionItem":
            return "column_dimension_item"
        return "column_tree"
    if "advancedSettings.originalColumnTree" in path:
        if entity_type == "Segment":
            return "advanced_metric_filter"
        if entity_type == "Metric":
            return "advanced_column_metric"
        if entity_type == "CalculatedMetric":
            return "advanced_column_calculated_metric"
        return "advanced_column_tree"
    if "lockedSelection.selectedDataPoints[].rowItem" in path:
        return "locked_selection_row"
    if "checkpoints[].items[]" in path:
        return "checkpoint_item"
    if ".config." in path:
        return "config_component"
    return "discovered"


def mine_project_components_recursive(project_json: Dict[str, Any]) -> Dict[str, Any]:
    components_by_group: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    all_components: List[Dict[str, Any]] = []
    seen_records: Set[Tuple[str, str, str, str, str, str, str]] = set()

    def add_component(*, entity: Dict[str, Any], path: str, context: Dict[str, str], source_key: str, forced_level: Optional[str] = None) -> None:
        entity_type = entity.get("type", "")
        group = ENTITY_TYPE_TO_GROUP.get(entity_type)
        if not group:
            return

        entity_id = entity.get("id", "")
        if not entity_id:
            return

        level = forced_level or classify_usage_level(path, entity_type)
        record = {
            "group": group,
            "entity_type": entity_type,
            "id": entity_id,
            "name": meta_name(entity),
            "level": level,
            "panel_name": context.get("panel_name", ""),
            "table_name": context.get("table_name", ""),
            "workspace_name": context.get("workspace_name", ""),
            "reportlet_type": context.get("reportlet_type", ""),
            "path": path,
            "source_key": source_key,
        }
        dedupe_key = (
            group,
            entity_id,
            level,
            record["panel_name"],
            record["table_name"],
            record["workspace_name"],
            path,
        )
        if dedupe_key in seen_records:
            return
        seen_records.add(dedupe_key)
        components_by_group[group].append(record)
        all_components.append(record)

    def next_context_for_node(node: Any, parent_context: Dict[str, str]) -> Dict[str, str]:
        ctx = dict(parent_context)
        if not isinstance(node, dict):
            return ctx
        if "panels" in node and "id" in node and "name" in node and isinstance(node.get("panels"), list):
            ctx["workspace_name"] = node.get("name", "") or ""
        if "subPanels" in node and "reportSuite" in node:
            ctx["panel_name"] = node.get("name", "") or ""
        if "reportlet" in node and "name" in node:
            ctx["table_name"] = node.get("name", "") or ""
        reportlet = as_dict(node.get("reportlet"))
        if reportlet:
            ctx["reportlet_type"] = reportlet.get("type", "") or ""
        return ctx

    def walk(node: Any, path: str, context: Dict[str, str]) -> None:
        context = next_context_for_node(node, context)

        if isinstance(node, dict):
            component = as_dict(node.get("component"))
            if component.get("type") in SUPPORTED_ENTITY_TYPES and component.get("id"):
                add_component(entity=component, path=f"{path}.component" if path else "component", context=context, source_key="component")

            if node.get("__entity__") is True and node.get("type") in SUPPORTED_ENTITY_TYPES and node.get("id"):
                add_component(entity=node, path=path, context=context, source_key="direct_entity")

            for key in (
                "reportSuite",
                "dateRange",
                "dimension",
                "rowItem",
                "rootComponent",
                "subComponent",
                "entryComponent",
                "exitComponent",
                "exitPathingDimension",
                "focusDimensionItem",
                "successMetric",
            ):
                child = as_dict(node.get(key))
                if child.get("type") in SUPPORTED_ENTITY_TYPES and child.get("id"):
                    add_component(entity=child, path=f"{path}.{key}" if path else key, context=context, source_key="named_holder")

            for key in ("dimensions", "metrics", "segments", "items"):
                for child in as_list(node.get(key)):
                    child_dict = as_dict(child)
                    if child_dict.get("type") in SUPPORTED_ENTITY_TYPES and child_dict.get("id"):
                        add_component(entity=child_dict, path=f"{path}.{key}[]" if path else f"{key}[]", context=context, source_key="named_holder_list")

            for key, value in node.items():
                walk(value, f"{path}.{key}" if path else key, context)
        elif isinstance(node, list):
            for item in node:
                walk(item, f"{path}[]", context)

    walk(project_json, "", {"workspace_name": "", "panel_name": "", "table_name": "", "reportlet_type": ""})

    ids_by_group = {
        group: sorted({record["id"] for record in records if record.get("id")})
        for group, records in components_by_group.items()
    }
    all_ids = sorted({record["id"] for record in all_components if record.get("id")})

    return {
        "components": dict(components_by_group),
        "all_components": all_components,
        "ids_by_group": ids_by_group,
        "all_ids": all_ids,
    }


def mine_project_components(project_json: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    grouped = mine_project_components_recursive(project_json).get("components", {})
    return {
        "dataviews": grouped.get("dataviews", []),
        "date_ranges": grouped.get("date_ranges", []),
        "segments": grouped.get("segments", []),
        "dimensions": grouped.get("dimensions", []),
        "dimension_items": grouped.get("dimension_items", []),
        "metrics": grouped.get("metrics", []),
        "calculated_metrics": grouped.get("calculated_metrics", []),
    }


# -----------------------------
# Single-level metadata extraction for Flask UI
# -----------------------------
def extract_panel_segments(panel: Dict[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    panel_segments: List[Dict[str, str]] = []
    panel_dimension_item_filters: List[Dict[str, str]] = []

    for seg_group in as_list(panel.get("segmentGroups")):
        for option_key in ("componentOptions", "selectedComponentOptions"):
            for option in as_list(as_dict(seg_group).get(option_key)):
                component = as_dict(as_dict(option).get("component"))
                ctype = component.get("type")
                if ctype == "Segment":
                    panel_segments.append({
                        "segment_name": meta_name(component),
                        "segment_id": component.get("id", ""),
                    })
                elif ctype == "DimensionItem":
                    panel_dimension_item_filters.append({
                        "item_name": meta_name(component),
                        "item_id": component.get("id", ""),
                    })

    if not panel_segments:
        panel_segments.append({
            "segment_name": "No Panel level segments found",
            "segment_id": "No Panel level segments found",
        })

    return {
        "panel_segments": panel_segments,
        "panel_dimension_item_filters": panel_dimension_item_filters,
    }


def extract_metric_specs_from_column_nodes(nodes: Any) -> List[Dict[str, Any]]:
    specs: List[Dict[str, Any]] = []

    def append_metric(component: Dict[str, Any], parent_segments: List[Dict[str, str]], nested_nodes: Any) -> None:
        metric_date_ranges = []
        for child in as_list(nested_nodes):
            child_comp = as_dict(as_dict(child).get("component"))
            if child_comp.get("type") == "DateRange":
                metric_date_ranges.append(normalize_date_range_entity(child_comp))

        nested_segments = [
            seg for seg in collect_segments_anywhere(nested_nodes)
            if seg.get("segment_id") not in {s.get("segment_id") for s in parent_segments}
        ]

        specs.append({
            "metric_id": component.get("id", ""),
            "metric_name": meta_name(component),
            "metric_type": component.get("type", ""),
            "metric_segment": parent_segments + nested_segments,
            "metric_date_ranges": metric_date_ranges,
        })

    for node in as_list(nodes):
        component = as_dict(as_dict(node).get("component"))
        ctype = component.get("type")
        nested_nodes = as_dict(node).get("nodes")

        if ctype in ("Metric", "CalculatedMetric"):
            append_metric(component, [], nested_nodes)
        elif ctype == "Segment":
            parent_segment = [{
                "segment_name": meta_name(component),
                "segment_id": component.get("id", ""),
            }]
            for child in as_list(nested_nodes):
                child_comp = as_dict(as_dict(child).get("component"))
                if child_comp.get("type") in ("Metric", "CalculatedMetric"):
                    append_metric(child_comp, parent_segment, as_dict(child).get("nodes"))

    return specs


def infer_dimension_from_locked_selection(reportlet: Dict[str, Any]) -> Dict[str, Any]:
    locked = as_dict(reportlet.get("lockedSelection"))
    items = []
    item_ids = []
    dimension_id = ""
    dimension_name = ""

    for point in as_list(locked.get("selectedDataPoints")):
        row_item = as_dict(as_dict(point).get("rowItem"))
        if row_item.get("type") != "DimensionItem":
            continue
        item_name = meta_name(row_item)
        raw_id = row_item.get("id", "")
        item_id = raw_id.split("::", 1)[1] if "::" in raw_id else raw_id
        item_ids.append(item_id)
        items.append({"item_name": item_name, "item_id": raw_id})
        if not dimension_id and "::" in raw_id:
            dimension_id = raw_id.split("::", 1)[0]
            dimension_name = meta_name({"__metaData__": {"name": dimension_name}})

    return {
        "dimension_id": dimension_id,
        "dimension_name": dimension_name,
        "items": items,
        "item_ids": item_ids,
    }


def extract_visualization_metadata(table: Dict[str, Any], reportlet: Dict[str, Any], panel_name: str, source_info: Dict[str, Any]) -> Dict[str, Any]:
    reportlet_type = reportlet.get("type", "")
    linked_source_id = safe_get(table, "linkedSourceId", "")
    source_subpanel = source_info.get("source_subpanel")
    source_resolution = source_info.get("source_resolution", "standalone")
    source_subpanel_id = source_info.get("source_subpanel_id", "")
    source_meta = extract_source_table_metadata(source_subpanel)

    meta = {
        "table_name": safe_get(table, "name", "Unnamed"),
        "entity_kind": "table" if reportlet.get("type") == "FreeformReportlet" else "visualization",
        "visualization_type": reportlet.get("type") if reportlet.get("type") != "FreeformReportlet" else "Freeform Table",
        "reportlet_type": reportlet.get("type", ""),
        "visualization_source": safe_get(table, "linkedSourceId", ""),
        "source_panel_name": panel_name,

        "source_table_id": source_subpanel_id,
        "source_resolution": source_resolution,
        "source_table_name": source_meta.get("source_table_name", ""),
        "source_table_dimension_id": source_meta.get("source_table_dimension_id", ""),
        "source_table_dimension_name": source_meta.get("source_table_dimension_name", ""),
        "source_table_segments": source_meta.get("source_table_segments", []),
        "source_table_metrics": source_meta.get("source_table_metrics", []),

        "table_dimension_id": "",
        "table_dimension_name": "",
        "table_segments": [],
        "metrics": [],
        "search_item_ids": [],
        "search_dimension_id": "",
        "search_dimension_name": "",
    }

    freeform = as_dict(reportlet.get("freeformTable"))
    dim_settings = as_list(freeform.get("dimensionSettings"))
    if dim_settings:
        dim = as_dict(as_dict(dim_settings[0]).get("dimension"))
        meta["table_dimension_id"] = dim.get("id", "")
        meta["table_dimension_name"] = meta_name(dim)

    static_rows = freeform.get("staticRows")
    if static_rows:
        meta["table_segments"] = collect_segments_anywhere(static_rows)

    if not meta["table_dimension_id"]:
        for row in as_list(static_rows):
            comp = as_dict(row.get("component"))
            if comp.get("type") == "DimensionItem":
                raw_id = comp.get("id", "")
                if "::" in raw_id:
                    dim_id = raw_id.split("::", 1)[0]
                    meta["table_dimension_id"] = dim_id
                    meta["table_dimension_name"] = "Static Rows Dimension"
                    break

    metric_specs = extract_metric_specs_from_column_nodes(
        as_dict(reportlet.get("columnTree")).get("nodes")
    )

    if not metric_specs:
        config = as_dict(reportlet.get("config"))
        key_metric = as_dict(config.get("keyMetric"))
        if key_metric.get("type") in ("Metric", "CalculatedMetric"):
            metric_specs = [{
                "metric_id": key_metric.get("id", ""),
                "metric_name": meta_name(key_metric),
                "metric_type": key_metric.get("type", ""),
                "metric_segment": [],
                "metric_date_ranges": [
                    normalize_date_range_entity(as_dict(config.get("primaryDateRange")))
                ] if as_dict(config.get("primaryDateRange")).get("id") else [],
                "comparison_date_range": (
                    normalize_date_range_entity(as_dict(config.get("comparisonDateRange")))
                    if as_dict(config.get("comparisonDateRange")).get("id")
                    else None
                ),
            }]

    meta["metrics"] = metric_specs

    # Inherit from resolved source freeform table when the visualization
    # itself does not expose enough structure.
    if not meta["table_dimension_id"] and meta["source_table_dimension_id"]:
        meta["table_dimension_id"] = meta["source_table_dimension_id"]
        meta["table_dimension_name"] = meta["source_table_dimension_name"]

    if not meta["metrics"] and meta["source_table_metrics"]:
        meta["metrics"] = meta["source_table_metrics"]

    if not meta["table_segments"] and meta["source_table_segments"]:
        meta["table_segments"] = meta["source_table_segments"]

    if reportlet_type in ("BarReportlet", "BarStackedReportlet", "SummaryNumberReportlet"):
        locked = infer_dimension_from_locked_selection(reportlet)
        if locked["dimension_id"]:
            meta["table_dimension_id"] = locked["dimension_id"]
            meta["table_dimension_name"] = locked["dimension_name"] or meta["table_dimension_name"] or "Locked Selection"
            meta["search_item_ids"] = locked["item_ids"]
            meta["search_dimension_id"] = locked["dimension_id"]
            meta["search_dimension_name"] = meta["table_dimension_name"]

    if reportlet_type in ("AreaReportlet", "ComboReportlet", "KeyMetricSummaryReportlet") and not meta["table_dimension_id"]:
        meta["table_dimension_id"] = FREEFORM_DIMENSION_FALLBACK
        meta["table_dimension_name"] = "Day"

    return meta


def extract_source_table_metadata(source_subpanel: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Normalize the source freeform table into a lightweight metadata object
    that visualizations can reuse for body generation.
    """
    if not source_subpanel:
        return {
            "source_table_name": "",
            "source_table_id": "",
            "source_table_dimension_id": "",
            "source_table_dimension_name": "",
            "source_table_segments": [],
            "source_table_metrics": [],
        }

    source_subpanel = as_dict(source_subpanel)
    reportlet = as_dict(source_subpanel.get("reportlet"))
    freeform = as_dict(reportlet.get("freeformTable"))

    source_dimension_id = ""
    source_dimension_name = ""

    dim_settings = as_list(freeform.get("dimensionSettings"))
    if dim_settings:
        dim = as_dict(as_dict(dim_settings[0]).get("dimension"))
        source_dimension_id = dim.get("id", "")
        source_dimension_name = meta_name(dim)

    source_table_segments = []
    static_rows = freeform.get("staticRows")
    if static_rows:
        source_table_segments = collect_segments_anywhere(static_rows)

    source_metrics = extract_metric_specs_from_column_nodes(
        as_dict(reportlet.get("columnTree")).get("nodes")
    )

    return {
        "source_table_name": source_subpanel.get("name", ""),
        "source_table_id": source_subpanel.get("id", ""),
        "source_table_dimension_id": source_dimension_id,
        "source_table_dimension_name": source_dimension_name,
        "source_table_segments": source_table_segments,
        "source_table_metrics": source_metrics,
    }

def build_table_project_metadata(project_json: Dict[str, Any]) -> Dict[str, Any]:
    panel_list: List[Dict[str, Any]] = []
    json_output = {
        "project_metadata": {
            "project_name": project_json.get("name", "Unknown Project Name"),
            "project_id": project_json.get("id", "Unknown Project ID"),
        },
        "panels": panel_list,
        "mined_components": mine_project_components(project_json),
    }

    workspaces = as_list(as_dict(project_json.get("definition")).get("workspaces"))
    for workspace in workspaces:
        for panel in as_list(as_dict(workspace).get("panels")):
            freeform_index = build_freeform_subpanel_index(panel)
            panel_filter_info = extract_panel_segments(panel)
            panel_dict = {
                "panel_name": safe_get(panel, "name"),
                "panel_segments": panel_filter_info["panel_segments"],
                "panel_dimension_item_filters": panel_filter_info["panel_dimension_item_filters"],
                "dataview_id": safe_get(as_dict(panel.get("reportSuite")), "id"),
                "dataview_name": meta_name(as_dict(panel.get("reportSuite"))),
                "date_range": {"preset_date_range": "", "iso_date": "", "date_range_id": ""},
                "tables": [],
            }

            panel_date = as_dict(panel.get("dateRange"))
            try:
                date_name = meta_name(panel_date)
                panel_dict["date_range"] = {
                    "preset_date_range": date_name or "No Date Range Name found",
                    "iso_date": generate_iso_date(date_name) if date_name else as_dict(panel_date.get("__metaData__")).get("definition", "No ISO Date found"),
                    "date_range_id": panel_date.get("id", ""),
                }
            except Exception:
                panel_dict["date_range"] = {
                    "preset_date_range": "No Date Range Name found, ISO Date used",
                    "iso_date": as_dict(panel_date.get("__metaData__")).get("definition", "No ISO Date found"),
                    "date_range_id": panel_date.get("id", ""),
                }

            for subpanel in as_list(panel.get("subPanels")):
                subpanel = as_dict(subpanel)
                reportlet = as_dict(subpanel.get("reportlet"))
                if not reportlet:
                    continue

                source_info = resolve_visualization_source_subpanel(
                    panel=panel,
                    subpanel=subpanel,
                    freeform_index=freeform_index,
                )

                panel_dict["tables"].append(
                    extract_visualization_metadata(
                        table=subpanel,
                        reportlet=reportlet,
                        panel_name=panel_dict["panel_name"],
                        source_info=source_info,
                    )
                )

            panel_list.append(panel_dict)

    return json_output


# -----------------------------
# API body generation
# -----------------------------
def build_global_filters(panel_meta: Dict[str, Any]) -> List[Dict[str, Any]]:
    filters: List[Dict[str, Any]] = []

    for seg in panel_meta.get("panel_segments", []) or []:
        if is_real_segment(seg):
            filters.append({"type": "segment", "segmentId": seg["segment_id"]})

    date_range = as_dict(panel_meta.get("date_range"))
    iso_date = date_range.get("iso_date") or ""
    if iso_date and "No ISO" not in iso_date:
        dr_filter = {"type": "dateRange", "dateRange": iso_date}
        if date_range.get("date_range_id"):
            dr_filter["dateRangeId"] = date_range["date_range_id"]
        filters.append(dr_filter)

    return filters


def build_capacity_metadata(project_meta: Dict[str, Any], panel_name: str) -> Dict[str, Any]:
    project_info = as_dict(project_meta.get("project_metadata"))
    return {
        "associations": [
            {"name": "applicationName", "value": "Analysis Workspace UI"},
            {"name": "projectId", "value": project_info.get("project_id")},
            {"name": "projectName", "value": project_info.get("project_name")},
            {"name": "panelName", "value": panel_name},
        ]
    }


def add_metric_filters_for_segments(metric: Dict[str, Any], next_filter_id: int, metric_filters: List[Dict[str, Any]]) -> Tuple[List[str], int]:
    filter_ids: List[str] = []
    for seg in [s for s in flatten_metric_segments(metric.get("metric_segment")) if is_real_segment(s)]:
        fid = str(next_filter_id)
        next_filter_id += 1
        metric_filters.append({"id": fid, "type": "segment", "segmentId": seg["segment_id"]})
        filter_ids.append(fid)
    return filter_ids, next_filter_id


def build_freeform_request_body(project_meta: Dict[str, Any], panel_meta: Dict[str, Any], viz_meta: Dict[str, Any]) -> Dict[str, Any]:
    metric_filters: List[Dict[str, Any]] = []
    metrics_out: List[Dict[str, Any]] = []
    next_filter_id = 0

    dimension_id = (
    viz_meta.get("table_dimension_id")
    or viz_meta.get("source_table_dimension_id")
)

    metrics = (
        viz_meta.get("metrics")
        or viz_meta.get("source_table_metrics", [])
    )

    for idx, metric in enumerate(metrics):
        metric_entry: Dict[str, Any] = {"columnId": str(idx), "id": metric.get("metric_id")}
        filter_ids, next_filter_id = add_metric_filters_for_segments(metric, next_filter_id, metric_filters)
        if filter_ids:
            metric_entry["filters"] = filter_ids
        metrics_out.append(metric_entry)

    body = {
        "globalFilters": build_global_filters(panel_meta),
        "metricContainer": {"metrics": metrics_out},
        "dimension": dimension_id,
        "settings": {
            "countRepeatInstances": True,
            "includeAnnotations": True,
            "nonesBehavior": "return-nones",
            "limit": 50,
            "page": 0,
        },
        "statistics": {"functions": ["col-max", "col-min"]},
        "capacityMetadata": build_capacity_metadata(project_meta, viz_meta.get("table_name", "")),
        "dataId": panel_meta.get("dataview_id"),
    }
    if metric_filters:
        body["metricContainer"]["metricFilters"] = metric_filters
    return body


def build_key_metric_summary_body(project_meta: Dict[str, Any], panel_meta: Dict[str, Any], viz_meta: Dict[str, Any]) -> Dict[str, Any]:
    metric_filters: List[Dict[str, Any]] = []
    metrics_out: List[Dict[str, Any]] = []
    next_filter_id = 0

    for idx, metric in enumerate(viz_meta.get("metrics", []), start=1):
        filter_ids: List[str] = []
        for dr in metric.get("metric_date_ranges", []) or []:
            if dr.get("date_range"):
                fid = str(next_filter_id)
                next_filter_id += 1
                metric_filters.append({
                    "id": fid,
                    "type": "dateRange",
                    "dateRange": dr.get("date_range"),
                    "dateRangeId": dr.get("date_range_id", ""),
                })
                filter_ids.append(fid)

        comparison_dr = metric.get("comparison_date_range")
        if comparison_dr and comparison_dr.get("date_range"):
            fid = str(next_filter_id)
            next_filter_id += 1
            metric_filters.append({
                "id": fid,
                "type": "dateRange",
                "dateRange": comparison_dr.get("date_range"),
                "dateRangeId": comparison_dr.get("date_range_id", ""),
            })

        metrics_out.append({
            "columnId": str(idx),
            "id": metric.get("metric_id"),
            **({"filters": filter_ids} if filter_ids else {}),
        })

    body = {
        "globalFilters": build_global_filters(panel_meta),
        "metricContainer": {"metrics": metrics_out},
        "dimension": FREEFORM_DIMENSION_FALLBACK,
        "settings": {
            "countRepeatInstances": True,
            "includeAnnotations": True,
            "nonesBehavior": "exclude-nones",
            "limit": 400,
            "page": 0,
            "dimensionSort": "asc",
        },
        "statistics": {"functions": ["col-max", "col-min"]},
        "capacityMetadata": build_capacity_metadata(project_meta, viz_meta.get("visualization_source") or viz_meta.get("table_name", "")),
        "dataId": panel_meta.get("dataview_id"),
    }
    if metric_filters:
        body["metricContainer"]["metricFilters"] = metric_filters
    return body


def build_area_or_combo_body(project_meta: Dict[str, Any], panel_meta: Dict[str, Any], viz_meta: Dict[str, Any]) -> Dict[str, Any]:
    dimension_id = (
    viz_meta.get("table_dimension_id")
    or viz_meta.get("source_table_dimension_id")
    or FREEFORM_DIMENSION_FALLBACK
    )

    metrics = (
        viz_meta.get("metrics")
        or viz_meta.get("source_table_metrics", [])
    )
    metrics_out = []
    for idx, metric in enumerate(metrics):
        entry: Dict[str, Any] = {"columnId": str(idx), "id": metric.get("metric_id")}
        if idx == 4 and viz_meta.get("reportlet_type") == "HorizontalBarReportlet":
            entry["sort"] = "desc"
        metrics_out.append(entry)

    return {
        "globalFilters": build_global_filters(panel_meta),
        "metricContainer": {"metrics": metrics_out},
        "dimension": dimension_id,
        "settings": {
            "countRepeatInstances": True,
            "includeAnnotations": True,
            "nonesBehavior": "exclude-nones" if viz_meta.get("reportlet_type") == "HorizontalBarReportlet" else "exclude-nones" if viz_meta.get("reportlet_type") == "AreaReportlet" else "return-nones",
            "limit": 10 if viz_meta.get("reportlet_type") == "HorizontalBarReportlet" else 400,
            "page": 0,
            **({"dimensionSort": "asc"} if viz_meta.get("reportlet_type") in ("AreaReportlet", "ComboReportlet") else {}),
        },
        "statistics": {"functions": ["col-max", "col-min"]},
        "capacityMetadata": build_capacity_metadata(project_meta, viz_meta.get("visualization_source") or viz_meta.get("table_name", "")),
        "dataId": panel_meta.get("dataview_id"),
    }


def build_search_body(project_meta: Dict[str, Any], panel_meta: Dict[str, Any], viz_meta: Dict[str, Any]) -> Dict[str, Any]:
    metrics = (
    viz_meta.get("metrics")
    or viz_meta.get("source_table_metrics", [])
    )

    dimension_id = (
        viz_meta.get("search_dimension_id")
        or viz_meta.get("table_dimension_id")
        or viz_meta.get("source_table_dimension_id")
    )
    return {
        "globalFilters": build_global_filters(panel_meta),
        "metricContainer": {
            "metrics": [
                {"columnId": str(idx), "id": metric.get("metric_id")}
                for idx, metric in enumerate(metrics)
            ]
        },
        "dimension": dimension_id,
        "search": {"itemIds": viz_meta.get("search_item_ids", [])},
        "settings": {
            "countRepeatInstances": True,
            "includeAnnotations": True,
            "limit": 50000,
            "nonesBehavior": "exclude-nones",
        },
        "statistics": {"functions": ["col-max", "col-min"]},
        "capacityMetadata": {"associations": [{"name": "applicationName", "value": "Analysis Workspace UI"}]},
        "dataId": panel_meta.get("dataview_id"),
    }


def build_static_row_segment_body(project_meta: Dict[str, Any], panel_meta: Dict[str, Any], viz_meta: Dict[str, Any], include_search: bool) -> Dict[str, Any]:
    metric_filters: List[Dict[str, Any]] = []
    metrics_out: List[Dict[str, Any]] = []
    next_static_id = 1
    next_filter_id = 0

    metrics = (
    viz_meta.get("metrics")
    or viz_meta.get("source_table_metrics", [])
    )

    table_segments = (
        viz_meta.get("table_segments")
        or viz_meta.get("source_table_segments", [])
    )

    dimension_id = (
        viz_meta.get("search_dimension_id")
        or viz_meta.get("table_dimension_id")
        or viz_meta.get("source_table_dimension_id")
    )

    for metric in metrics:
        base_filter_ids: List[str] = []
        for seg in [s for s in flatten_metric_segments(metric.get("metric_segment")) if is_real_segment(s)]:
            fid = str(next_filter_id)
            next_filter_id += 1
            metric_filters.append({"id": fid, "type": "segment", "segmentId": seg["segment_id"]})
            base_filter_ids.append(fid)

        if table_segments:
            for seg in table_segments:
                if not is_real_segment(seg):
                    continue
                static_id = f"STATIC_ROW_COMPONENT_{next_static_id}"
                next_static_id += 2
                metric_filters.append({"id": static_id, "type": "segment", "segmentId": seg["segment_id"]})
                metrics_out.append({
                    "columnId": f"{metric.get('metric_id')}:::{len(metrics_out) * 2}",
                    "id": metric.get("metric_id"),
                    "filters": [static_id] + base_filter_ids,
                })
        else:
            metrics_out.append({
                "columnId": str(len(metrics_out)),
                "id": metric.get("metric_id"),
                **({"filters": base_filter_ids} if base_filter_ids else {}),
            })

    body = {
        "globalFilters": build_global_filters(panel_meta),
        "metricContainer": {"metrics": metrics_out},
        "settings": {"countRepeatInstances": True, "includeAnnotations": True},
        "statistics": {"functions": ["col-max", "col-min"]},
        "capacityMetadata": {"associations": [{"name": "applicationName", "value": "Analysis Workspace UI"}]},
        "dataId": panel_meta.get("dataview_id"),
    }
    if metric_filters:
        body["metricContainer"]["metricFilters"] = metric_filters
    if include_search:
        body["dimension"] = dimension_id
        body["search"] = {"itemIds": viz_meta.get("search_item_ids", [])}
        body["settings"].update({"limit": 50000, "nonesBehavior": "exclude-nones"})
    return body


def build_body_for_visualization(project_meta: Dict[str, Any], panel_meta: Dict[str, Any], viz_meta: Dict[str, Any]) -> Dict[str, Any]:
    reportlet_type = viz_meta.get("reportlet_type", "")
    missing: List[str] = []

    body_builder_map = {
        "FreeformReportlet": build_freeform_request_body,
        "KeyMetricSummaryReportlet": build_key_metric_summary_body,
        "AreaReportlet": build_area_or_combo_body,
        "ComboReportlet": build_area_or_combo_body,
        "HorizontalBarReportlet": build_area_or_combo_body,
        "SummaryNumberReportlet": build_search_body,
        "BarReportlet": build_search_body,
        "DonutReportlet": lambda p, pm, vm: build_static_row_segment_body(p, pm, vm, include_search=False),
        "BarStackedReportlet": lambda p, pm, vm: build_static_row_segment_body(p, pm, vm, include_search=True),
        "HorizontalBarStackedReportlet": lambda p, pm, vm: build_static_row_segment_body(p, pm, vm, include_search=False),
    }

    builder = body_builder_map.get(reportlet_type)
    if builder is None:
        return {
            "panel_name": panel_meta.get("panel_name"),
            "table_name": viz_meta.get("table_name"),
            "entity_kind": viz_meta.get("entity_kind"),
            "visualization_type": viz_meta.get("visualization_type"),
            "format": "UNSUPPORTED",
            "missing_fields": [f"Unsupported reportlet type: {reportlet_type}"],
            "body": None,
        }

    try:
        body = builder(project_meta, panel_meta, viz_meta)
    except Exception as exc:
        missing.append(str(exc))
        body = None

    return {
        "panel_name": panel_meta.get("panel_name"),
        "table_name": viz_meta.get("table_name"),
        "entity_kind": viz_meta.get("entity_kind"),
        "visualization_type": viz_meta.get("visualization_type"),
        "format": reportlet_type or "UNKNOWN",
        "missing_fields": missing,
        "body": body,
    }


def build_all_bodies_from_project_metadata(project_metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
    bodies: List[Dict[str, Any]] = []
    for panel_meta in project_metadata.get("panels", []) or []:
        for viz_meta in panel_meta.get("tables", []) or []:
            bodies.append(build_body_for_visualization(project_metadata, panel_meta, viz_meta))
    return bodies


# -----------------------------
# Flask app
# -----------------------------
def cja_json_extractor(headers: Dict[str, str]) -> Flask:
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    app = Flask(__name__, template_folder=template_dir)

    @app.route("/", methods=["GET", "POST"])
    def home():
        return render_template("jsonExtractionUi.html")

    @app.route("/importProject", methods=["GET", "POST"])
    def import_project():
        if not request.is_json:
            return jsonify(error="Request Content-Type must be 'application/json'"), 415
        data = request.get_json() or {}
        project_id = data.get("projectId")
        try:
            url = f"https://cja.adobe.io/projects/{project_id}?expansion=definition"
            res = HttpClient(url, headers, req_num=DEFAULT_RETRY_COUNT).get()
            project_json = json.loads(res.text)
        except Exception as e:
            return jsonify(error=str(e)), 500
        project_metadata = build_table_project_metadata(project_json)
        return jsonify(dict(project_metadata)), 200

    @app.route("/createBodies", methods=["GET", "POST"])
    def create_bodies():
        if not request.is_json:
            return jsonify(error="Request Content-Type must be 'application/json'"), 415
        data = request.get_json() or {}
        project_metadata = data.get("projectMetadata") or {}
        try:
            api_bodies = build_all_bodies_from_project_metadata(project_metadata)
        except Exception as e:
            return jsonify(error=str(e)), 500
        return jsonify({"request_bodies": api_bodies}), 200

    return app


class _ServerThread(threading.Thread):
    def __init__(self, app: Flask, host: str, port: int):
        super().__init__(daemon=True)
        self._server = make_server(host, port, app)
        self.port = self._server.server_port

    def run(self):
        self._server.serve_forever()

    def shutdown(self):
        self._server.shutdown()


def launch(headers: Dict[str, str], host: str = "127.0.0.1", port: int = 0, open_browser: bool = True):
    app = cja_json_extractor(headers)
    server = _ServerThread(app, host, port)
    server.start()
    url = f"http://{host}:{server.port}/"
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    return url, server
