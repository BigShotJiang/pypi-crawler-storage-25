document.addEventListener("DOMContentLoaded", () => {
  const projectIdInput = document.getElementById("projectId");
  const importBtn = document.getElementById("importBtn");
  const tableJsonPre = document.getElementById("tableJson");
  const metaDiv = document.getElementById("meta");
  const bodyListDiv = document.getElementById("bodyList");

  function escapeHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function setLeftJson(obj) {
    tableJsonPre.textContent =
      typeof obj === "string" ? obj : JSON.stringify(obj, null, 2);
  }

  function badge(text, kind) {
    const cls =
      kind === "segment"
        ? "badge badge-segment"
        : kind === "metric"
          ? "badge badge-metric"
          : kind === "dimension"
            ? "badge badge-dimension"
            : "badge";
    return `<span class="${cls}">${escapeHtml(text)}</span>`;
  }

  function renderBodyList(requestBodies) {
    if (!bodyListDiv) return;

    if (!Array.isArray(requestBodies) || requestBodies.length === 0) {
      bodyListDiv.innerHTML = `<div class="muted">No entries found.</div>`;
      return;
    }

    bodyListDiv.innerHTML = requestBodies
      .map((b, idx) => {
        const panelName = b.panel_name || `Panel ${b.panel_index ?? ""}`;
        const entryName = b.table_name || `Entry ${idx + 1}`;
        const vizType = b.visualization_type || b.format || "Unknown";
        const kind = b.entity_kind || "table";
        const prefix = kind === "visualization" ? "Visualization" : "Table";
        const missing =
          Array.isArray(b.missing_fields) && b.missing_fields.length
            ? ` • missing: ${b.missing_fields.length}`
            : "";

        return `
          <button type="button" data-idx="${idx}">
            <div class="title">${escapeHtml(panelName)}</div>
            <div class="subtitle">${prefix}: ${escapeHtml(entryName)} • ${escapeHtml(vizType)}${escapeHtml(missing)}</div>
          </button>
        `;
      })
      .join("");

    bodyListDiv.querySelectorAll("button[data-idx]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = Number(btn.getAttribute("data-idx"));
        const selected = requestBodies[idx];
        setLeftJson(selected?.body ?? selected ?? {});
      });
    });
  }

  function renderMeta(projectMeta) {
    if (!metaDiv) return;

    const pm = projectMeta.project_metadata || {};
    const projectName = pm.project_name || "(missing)";
    const projectId = pm.project_id || "(missing)";
    const panels = projectMeta.panels || [];

    let html = `
      <details open>
        <summary>Project</summary>
        <div class="row"><div class="key">Name</div><div class="value">${escapeHtml(projectName)}</div></div>
        <div class="row"><div class="key">Project ID</div><div class="value">${escapeHtml(projectId)}</div></div>
      </details>
    `;

    panels.forEach((panel, pIdx) => {
      const panelName = panel.panel_name || `Panel ${pIdx + 1}`;
      const dvId = panel.dataview_id || "(missing)";
      const dvName = panel.dataview_name || "(missing)";
      const dateRange = panel?.date_range?.iso_date || "(missing)";
      const panelDimFilters = panel.panel_dimension_item_filters || [];

      html += `
        <details open>
          <summary>Panel ${pIdx + 1}: ${escapeHtml(panelName)}</summary>
          <div class="row"><div class="key">DataView ID</div><div class="value">${escapeHtml(dvId)}</div></div>
          <div class="row"><div class="key">DataView Name</div><div class="value">${escapeHtml(dvName)}</div></div>
          <div class="row"><div class="key">Date Range</div><div class="value">${escapeHtml(dateRange)}</div></div>
      `;

      const panelSegments = panel.panel_segments || [];
      html += `
        <div class="row"><div class="key">Segments</div><div class="value"></div></div>
        ${
          panelSegments.length
            ? `<ul>${
                panelSegments
                  .map((s) => `<li>${badge(s.segment_name || "(missing)", "segment")} <span class="muted">${escapeHtml(s.segment_id || "")}</span></li>`)
                  .join("")
              }</ul>`
            : `<div class="muted">No panel-level segments found.</div>`
        }
      `;

      if (panelDimFilters.length) {
        html += `
          <div class="row"><div class="key">Panel Dimension Filters</div><div class="value"></div></div>
          <ul>${
            panelDimFilters
              .map((f) => `<li>${badge(f.item_name || "(missing)", "dimension")} <span class="muted">${escapeHtml(f.item_id || "")}</span></li>`)
              .join("")
          }</ul>
        `;
      }

      const entries = panel.tables || [];
      entries.forEach((entry, idx) => {
        const name = entry.table_name || `Entry ${idx + 1}`;
        const entityKind = entry.entity_kind || "table";
        const vizType = entry.visualization_type || entry.reportlet_type || "Unknown";
        const label = entityKind === "visualization" ? "Visualization" : "Table";

        const dimName = entry.table_dimension_name || "(missing)";
        const dimId = entry.table_dimension_id || "(missing)";

        html += `
          <details open>
            <summary>${label}: ${escapeHtml(name)}</summary>
            <div class="row"><div class="key">Type</div><div class="value">${escapeHtml(vizType)}</div></div>
            <div class="row">
              <div class="key">Dimension</div>
              <div class="value">${badge(dimName, "dimension")} <span class="muted">${escapeHtml(dimId)}</span></div>
            </div>
        `;

        const metrics = entry.metrics || [];
        if (metrics.length) {
          html += `<ul>`;
          metrics.forEach((m) => {
            const metricName = m.metric_name || "(missing)";
            const metricId = m.metric_id || "(missing)";
            const metricType = m.metric_type || "Metric";
            const metricSegments = m.metric_segment || [];

            const segHtml =
              metricSegments.length
                ? `<ul>${
                    metricSegments
                      .map((s) => `<li>${badge(s.segment_name || "(missing)", "segment")} <span class="muted">${escapeHtml(s.segment_id || "")}</span></li>`)
                      .join("")
                  }</ul>`
                : `<div class="muted">No table level segments found.</div>`;

            html += `
              <li>
                <div>${badge(metricType, "metric")} ${escapeHtml(metricName)}</div>
                <div class="muted">Metric ID: ${escapeHtml(metricId)}</div>
                ${segHtml}
              </li>
            `;
          });
          html += `</ul>`;
        } else {
          html += `<div class="muted">No metrics found.</div>`;
        }

        html += `</details>`;
      });

      html += `</details>`;
    });

    metaDiv.innerHTML = html;
  }

  importBtn.addEventListener("click", async () => {
    const projectId = projectIdInput.value?.trim();
    if (!projectId) {
      alert("Enter a Project ID first.");
      return;
    }

    setLeftJson({});
    if (bodyListDiv) bodyListDiv.innerHTML = `<div class="muted">Loading entries…</div>`;
    metaDiv.innerHTML = `<div class="empty-state">Loading metadata…</div>`;

    try {
      const metaResp = await fetch("/importProject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId }),
      });

      if (!metaResp.ok) {
        const errText = await metaResp.text();
        throw new Error(errText || "Import failed.");
      }

      const metadataPayload = await metaResp.json();
      renderMeta(metadataPayload);

      const bodiesResp = await fetch("/createBodies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectMetadata: metadataPayload }),
      });

      if (!bodiesResp.ok) {
        const errText = await bodiesResp.text();
        throw new Error(errText || "createBodies failed.");
      }

      const bodiesResult = await bodiesResp.json();
      const requestBodies = bodiesResult.request_bodies || [];

      renderBodyList(requestBodies);

      if (Array.isArray(requestBodies) && requestBodies.length) {
        setLeftJson(requestBodies[0]?.body ?? requestBodies[0]);
      } else {
        setLeftJson(metadataPayload);
      }
    } catch (e) {
      metaDiv.innerHTML = `<div class="empty-state">Error: ${escapeHtml(String(e))}</div>`;
      if (bodyListDiv) bodyListDiv.innerHTML = `<div class="muted">No entries found.</div>`;
    }
  });
});