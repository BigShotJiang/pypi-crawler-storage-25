from dataclasses import dataclass
from unittest.mock import MagicMock, mock_open

import duckdb
import pytest
from pytest_mock import MockerFixture

from tests.graph import GraphFixture


@dataclass
class InitMocks:
    connect: MagicMock
    os_path_exists: MagicMock


@dataclass
class RunMocks:
    _run: MagicMock


@dataclass
class ReadAdjacencyMocks:
    os_path_exists: MagicMock
    open: MagicMock


@pytest.fixture
def init_mocks(mocker: MockerFixture) -> InitMocks:
    connect_mock: MagicMock = mocker.patch("chatbot.utils.graph.duckdb.connect")
    connection: MagicMock = connect_mock.return_value
    connection.execute.return_value = connection
    return InitMocks(
        connect=connect_mock,
        os_path_exists=mocker.patch(
            "chatbot.utils.graph.os.path.exists", return_value=False
        ),
    )


@pytest.fixture
def run_mocks(mocker: MockerFixture, init_mocks: InitMocks) -> RunMocks:
    return RunMocks(
        _run=mocker.patch("chatbot.utils.graph.Graph._run"),
    )


@pytest.fixture
def read_adjacency_mocks(mocker: MockerFixture) -> ReadAdjacencyMocks:
    return ReadAdjacencyMocks(
        os_path_exists=mocker.patch(
            "chatbot.utils.graph.os.path.exists", return_value=True
        ),
        open=mocker.patch(
            "builtins.open",
            mock_open(read_data="foo\tbar baz\nqux\tquux\n"),
        ),
    )


class TestInit:
    @pytest.fixture
    def graph(self, init_mocks: InitMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_init_connects_to_duckdb(
        self, init_mocks: InitMocks, graph: GraphFixture
    ) -> None:
        init_mocks.connect.assert_called_once()

    def test_init_creates_adjacency_table(
        self, init_mocks: InitMocks, graph: GraphFixture
    ) -> None:
        init_mocks.connect.return_value.execute.assert_any_call(
            "CREATE TABLE adjacency (title VARCHAR PRIMARY KEY, targets VARCHAR[])"
        )

    def test_init_local_path_skips_httpfs(
        self, init_mocks: InitMocks, graph: GraphFixture
    ) -> None:
        init_mocks.connect.return_value.execute.assert_called_once_with(
            "CREATE TABLE adjacency (title VARCHAR PRIMARY KEY, targets VARCHAR[])"
        )

    def test_init_s3_path_loads_httpfs(self, init_mocks: InitMocks) -> None:
        GraphFixture("s3://bucket/foo.parquet")
        init_mocks.connect.return_value.execute.assert_any_call(
            "INSTALL httpfs; LOAD httpfs; SET s3_region = 'eu-west-2';"
        )

    def test_init_calls_load(self, init_mocks: InitMocks) -> None:
        init_mocks.os_path_exists.return_value = True
        GraphFixture("/tmp/foo.parquet")
        init_mocks.connect.return_value.cursor.return_value.execute.assert_any_call(
            "INSERT INTO adjacency SELECT * FROM '/tmp/foo.parquet'", None
        )


class TestAddEdges:
    @pytest.fixture
    def graph(self, run_mocks: RunMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_add_edges_deletes_existing_source(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar", "baz"])
        run_mocks._run.assert_any_call(
            "DELETE FROM adjacency WHERE title = ?", ("foo",)
        )

    def test_add_edges_inserts_new_row(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar", "baz"])
        run_mocks._run.assert_any_call(
            "INSERT INTO adjacency VALUES (?, ?)", ("foo", ["bar", "baz"])
        )

    def test_add_edges_applies_serialiser(self, run_mocks: RunMocks) -> None:
        graph: GraphFixture = GraphFixture(
            "/tmp/foo.parquet", str, lambda vertex: vertex.upper()
        )
        graph.add_edges("foo", ["bar", "baz"])
        run_mocks._run.assert_any_call(
            "DELETE FROM adjacency WHERE title = ?", ("FOO",)
        )
        run_mocks._run.assert_any_call(
            "INSERT INTO adjacency VALUES (?, ?)", ("FOO", ["BAR", "BAZ"])
        )

    def test_add_edges_sets_unsaved_flag(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar"])
        assert graph.save()


class TestGetVertices:
    @pytest.fixture
    def graph(self, run_mocks: RunMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_get_vertices_empty_graph_returns_empty(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchall.return_value = []
        assert graph.get_vertices() == []

    def test_get_vertices_returns_all_sources(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchall.return_value = [("foo",), ("baz",)]
        assert graph.get_vertices() == ["foo", "baz"]

    def test_get_vertices_applies_deserialiser(self, run_mocks: RunMocks) -> None:
        graph: GraphFixture = GraphFixture(
            "/tmp/foo.parquet", lambda vertex: vertex.upper()
        )
        run_mocks._run.return_value.fetchall.return_value = [("foo",), ("bar",)]
        assert graph.get_vertices() == ["FOO", "BAR"]


class TestHasVertex:
    @pytest.fixture
    def graph(self, run_mocks: RunMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_has_vertex_exists_returns_true(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchone.return_value = (1,)
        assert graph.has_vertex("foo")

    def test_has_vertex_missing_returns_false(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchone.return_value = None
        assert not graph.has_vertex("foo")

    def test_has_vertex_queries_by_title(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchone.return_value = None
        graph.has_vertex("foo")
        run_mocks._run.assert_called_with(
            "SELECT 1 FROM adjacency WHERE title = ?", ("foo",)
        )

    def test_has_vertex_applies_serialiser(self, run_mocks: RunMocks) -> None:
        graph: GraphFixture = GraphFixture(
            "/tmp/foo.parquet", str, lambda vertex: vertex.upper()
        )
        run_mocks._run.return_value.fetchone.return_value = None
        graph.has_vertex("foo")
        run_mocks._run.assert_called_with(
            "SELECT 1 FROM adjacency WHERE title = ?", ("FOO",)
        )


class TestGetConnectedVertices:
    @pytest.fixture
    def graph(self, run_mocks: RunMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_get_connected_vertices_returns_targets(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchone.return_value = (["bar", "baz"],)
        assert graph.get_connected_vertices("foo") == ["bar", "baz"]

    def test_get_connected_vertices_missing_source_raises_key_error(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        run_mocks._run.return_value.fetchone.return_value = None
        with pytest.raises(KeyError):
            graph.get_connected_vertices("foo")

    def test_get_connected_vertices_applies_deserialiser(
        self, run_mocks: RunMocks
    ) -> None:
        graph: GraphFixture = GraphFixture(
            "/tmp/foo.parquet", lambda vertex: vertex.upper()
        )
        run_mocks._run.return_value.fetchone.return_value = (["bar", "baz"],)
        assert graph.get_connected_vertices("foo") == ["BAR", "BAZ"]

    def test_get_connected_vertices_applies_serialiser(
        self, run_mocks: RunMocks
    ) -> None:
        graph: GraphFixture = GraphFixture(
            "/tmp/foo.parquet", str, lambda vertex: vertex.upper()
        )
        run_mocks._run.return_value.fetchone.return_value = (["bar"],)
        graph.get_connected_vertices("foo")
        run_mocks._run.assert_called_with(
            "SELECT targets FROM adjacency WHERE title = ?", ("FOO",)
        )


class TestRun:
    @pytest.fixture
    def graph(self, init_mocks: InitMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_run_replaces_path_in_query(
        self, init_mocks: InitMocks, graph: GraphFixture
    ) -> None:
        graph.run("SELECT * FROM 'path'")
        init_mocks.connect.return_value.cursor.return_value.execute.assert_called_with(
            "SELECT * FROM '/tmp/foo.parquet'", None
        )

    def test_run_passes_params(
        self, init_mocks: InitMocks, graph: GraphFixture
    ) -> None:
        graph.run("INSERT INTO adjacency VALUES (?, ?)", ("foo", ["bar"]))
        init_mocks.connect.return_value.cursor.return_value.execute.assert_called_with(
            "INSERT INTO adjacency VALUES (?, ?)", ("foo", ["bar"])
        )

    def test_run_returns_cursor_result(
        self, init_mocks: InitMocks, graph: GraphFixture
    ) -> None:
        expected: MagicMock = (
            init_mocks.connect.return_value.cursor.return_value.execute.return_value
        )
        assert graph.run("SELECT 1 FROM 'path'") == expected


class TestLoad:
    def test_load_s3_path_calls_probe_query(self, run_mocks: RunMocks) -> None:
        GraphFixture("s3://bucket/foo.parquet")
        run_mocks._run.assert_any_call("SELECT 1 FROM 'path' LIMIT 1")

    def test_load_s3_path_inserts_from_parquet(self, run_mocks: RunMocks) -> None:
        GraphFixture("s3://bucket/foo.parquet")
        run_mocks._run.assert_any_call("INSERT INTO adjacency SELECT * FROM 'path'")

    def test_load_s3_path_duckdb_error_skips_insert(self, run_mocks: RunMocks) -> None:
        run_mocks._run.side_effect = duckdb.Error()
        GraphFixture("s3://bucket/foo.parquet")
        run_mocks._run.assert_called_once_with("SELECT 1 FROM 'path' LIMIT 1")

    def test_load_local_path_not_exists_skips_run(self, run_mocks: RunMocks) -> None:
        GraphFixture("/tmp/foo.parquet")
        run_mocks._run.assert_not_called()

    def test_load_local_path_exists_clears_table(
        self, run_mocks: RunMocks, init_mocks: InitMocks
    ) -> None:
        init_mocks.os_path_exists.return_value = True
        GraphFixture("/tmp/foo.parquet")
        run_mocks._run.assert_any_call("DELETE FROM adjacency")

    def test_load_local_path_exists_inserts_from_parquet(
        self, run_mocks: RunMocks, init_mocks: InitMocks
    ) -> None:
        init_mocks.os_path_exists.return_value = True
        GraphFixture("/tmp/foo.parquet")
        run_mocks._run.assert_any_call("INSERT INTO adjacency SELECT * FROM 'path'")

    def test_load_explicit_call_reloads(
        self, run_mocks: RunMocks, init_mocks: InitMocks
    ) -> None:
        graph: GraphFixture = GraphFixture("/tmp/foo.parquet")
        run_mocks._run.assert_not_called()
        init_mocks.os_path_exists.return_value = True
        assert graph.load()
        run_mocks._run.assert_any_call("INSERT INTO adjacency SELECT * FROM 'path'")


class TestSave:
    @pytest.fixture
    def graph(self, run_mocks: RunMocks) -> GraphFixture:
        return GraphFixture("/tmp/foo.parquet")

    def test_save_no_changes_returns_false(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        assert not graph.save()

    def test_save_with_changes_returns_true(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar"])
        assert graph.save()

    def test_save_exports_to_parquet(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar"])
        graph.save()
        run_mocks._run.assert_any_call("COPY adjacency TO 'path' (FORMAT PARQUET)")

    def test_save_resets_unsaved_flag(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar"])
        graph.save()
        assert not graph.save()

    def test_save_second_call_after_new_edges_returns_true(
        self, run_mocks: RunMocks, graph: GraphFixture
    ) -> None:
        graph.add_edges("foo", ["bar"])
        graph.save()
        graph.add_edges("baz", ["qux"])
        assert graph.save()


class TestReadAdjacency:
    def test_read_adjacency_file_not_exists_returns_empty(
        self, read_adjacency_mocks: ReadAdjacencyMocks
    ) -> None:
        read_adjacency_mocks.os_path_exists.return_value = False
        assert GraphFixture.read_adjacency("/tmp/foo.tsv") == {}

    def test_read_adjacency_parses_tsv_format(
        self, read_adjacency_mocks: ReadAdjacencyMocks
    ) -> None:
        assert GraphFixture.read_adjacency("/tmp/foo.tsv") == {
            "foo": ["bar", "baz"],
            "qux": ["quux"],
        }

    def test_read_adjacency_empty_targets_returns_empty_list(
        self, read_adjacency_mocks: ReadAdjacencyMocks
    ) -> None:
        read_adjacency_mocks.open = MagicMock(
            side_effect=mock_open(read_data="foo\t\n")
        )
        with pytest.MonkeyPatch.context() as monkeypatch:
            monkeypatch.setattr("builtins.open", read_adjacency_mocks.open)
            assert GraphFixture.read_adjacency("/tmp/foo.tsv") == {
                "foo": [],
            }

    def test_read_adjacency_skips_malformed_lines(
        self, read_adjacency_mocks: ReadAdjacencyMocks
    ) -> None:
        read_adjacency_mocks.open = MagicMock(
            side_effect=mock_open(read_data="foo\tbar\nmalformed\nbaz\tqux\n")
        )
        with pytest.MonkeyPatch.context() as monkeypatch:
            monkeypatch.setattr("builtins.open", read_adjacency_mocks.open)
            assert GraphFixture.read_adjacency("/tmp/foo.tsv") == {
                "foo": ["bar"],
                "baz": ["qux"],
            }

    def test_read_adjacency_uses_correct_path(
        self, read_adjacency_mocks: ReadAdjacencyMocks
    ) -> None:
        GraphFixture.read_adjacency("/tmp/foo.tsv")
        read_adjacency_mocks.os_path_exists.assert_called_once_with("/tmp/foo.tsv")
