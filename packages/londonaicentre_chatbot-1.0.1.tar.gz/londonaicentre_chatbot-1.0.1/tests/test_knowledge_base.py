from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock, mock_open

import pytest
from langchain_core.documents import Document
from pytest_mock import MockerFixture
from qdrant_client.http.models import FieldCondition, MatchValue

from chatbot.types import Page
from tests.knowledge_base import KnowledgeBaseFixture


@dataclass
class InitMocks:
    HuggingFaceEmbeddings: MagicMock
    QdrantClient: MagicMock
    logger: MagicMock
    Graph: MagicMock


@dataclass
class VectorStoreMocks:
    _get_collection: MagicMock
    _collection_exists: MagicMock
    _get_collections: MagicMock
    sanitise_name: MagicMock
    _VectorStoreMocks__client: MagicMock
    QdrantVectorStore: MagicMock


@dataclass
class GetCollectionMocks:
    sanitise_name: MagicMock
    _GetCollectionMocks__client: MagicMock


@dataclass
class CollectionExistsMocks:
    sanitise_name: MagicMock
    _get_collections: MagicMock


@dataclass
class SplitDocumentMocks:
    RecursiveCharacterTextSplitter: MagicMock


@dataclass
class LoadWebDocumentsMocks:
    load_web_documents_from_list: MagicMock
    open: MagicMock


@dataclass
class StoreTitleMocks:
    _collection_exists_with_content: MagicMock
    _store_chunks: MagicMock


@dataclass
class StoreTitleAndKeywordsMocks:
    _collection_exists_with_content: MagicMock
    _store_chunks: MagicMock


@dataclass
class StoreChunksWithTitleMocks:
    _split_document: MagicMock
    _store_chunks: MagicMock


@dataclass
class LoadWebDocumentsFromListMocks:
    _store_title: MagicMock
    _store_title_and_keywords: MagicMock
    _store_chunks_with_title: MagicMock
    _collection_exists_with_content: MagicMock
    _non_empty_collection_exists: MagicMock
    _store_chunks: MagicMock
    _split_document: MagicMock
    WebBaseLoader: MagicMock
    LoadWebDocumentsFromListMocks__client: MagicMock
    _get_collection: MagicMock
    compare_digest: MagicMock
    _LoadWebDocumentsFromListMocks__graph_client: MagicMock


@dataclass
class GetMatchingPageTitleMocks:
    _get_documents: MagicMock
    doc: MagicMock
    _GetMatchingPageTitleMocks__graph_client: MagicMock


@dataclass
class RetrieveChunksMocks:
    _get_documents: MagicMock
    _get_collections: MagicMock


@dataclass
class LoadQADocumentsMocks:
    _store_chunks: MagicMock
    open: MagicMock


@pytest.fixture
def init_mocks(mocker: MockerFixture) -> InitMocks:
    graph_mock: MagicMock = mocker.patch("chatbot.knowledge_base.Graph")
    graph_mock.__getitem__.return_value = graph_mock
    return InitMocks(
        HuggingFaceEmbeddings=mocker.patch(
            "chatbot.knowledge_base.HuggingFaceEmbeddings"
        ),
        QdrantClient=mocker.patch("chatbot.knowledge_base.QdrantClient"),
        logger=mocker.patch("logging.getLogger"),
        Graph=graph_mock,
    )


@pytest.fixture
def vector_store_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> VectorStoreMocks:
    client_mock: MagicMock = MagicMock()
    init_mocks.QdrantClient.return_value = client_mock
    return VectorStoreMocks(
        _get_collection=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._get_collection"
        ),
        _collection_exists=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._collection_exists"
        ),
        _get_collections=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._get_collections"
        ),
        sanitise_name=mocker.patch(
            "chatbot.knowledge_base.Sanitiser.sanitise_name",
            side_effect=lambda name: name,
        ),
        _VectorStoreMocks__client=client_mock,
        QdrantVectorStore=mocker.patch("chatbot.knowledge_base.QdrantVectorStore"),
    )


@pytest.fixture
def get_collection_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> GetCollectionMocks:
    return GetCollectionMocks(
        sanitise_name=mocker.patch(
            "chatbot.knowledge_base.Sanitiser.sanitise_name",
            return_value="foo_sanitised",
        ),
        _GetCollectionMocks__client=init_mocks.QdrantClient.return_value,
    )


@pytest.fixture
def collection_exists_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> CollectionExistsMocks:
    return CollectionExistsMocks(
        sanitise_name=mocker.patch(
            "chatbot.knowledge_base.Sanitiser.sanitise_name",
            return_value="foo_sanitised",
        ),
        _get_collections=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._get_collections",
        ),
    )


@pytest.fixture
def split_document_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> SplitDocumentMocks:
    return SplitDocumentMocks(
        RecursiveCharacterTextSplitter=mocker.patch(
            "chatbot.knowledge_base.RecursiveCharacterTextSplitter"
        ),
    )


@pytest.fixture
def load_web_documents_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> LoadWebDocumentsMocks:
    return LoadWebDocumentsMocks(
        load_web_documents_from_list=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase.load_web_documents_from_list"
        ),
        open=mocker.patch("builtins.open", mock_open(read_data='{"foo": "bar"}')),
    )


@pytest.fixture
def store_title_mocks(mocker: MockerFixture, init_mocks: InitMocks) -> StoreTitleMocks:
    return StoreTitleMocks(
        _collection_exists_with_content=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._collection_exists_with_content",
            return_value=False,
        ),
        _store_chunks=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._store_chunks"
        ),
    )


@pytest.fixture
def store_title_and_keywords_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> StoreTitleAndKeywordsMocks:
    return StoreTitleAndKeywordsMocks(
        _collection_exists_with_content=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._collection_exists_with_content",
            return_value=False,
        ),
        _store_chunks=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._store_chunks"
        ),
    )


@pytest.fixture
def store_chunks_with_title_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> StoreChunksWithTitleMocks:
    split_document: MagicMock = mocker.patch(
        "chatbot.knowledge_base.KnowledgeBase._split_document"
    )
    chunk1: Document = Document("chunk1", metadata={"existing": "metadata"})
    chunk2: Document = Document("chunk2", metadata={})
    split_document.return_value = [chunk1, chunk2]
    store_chunks: MagicMock = mocker.patch(
        "chatbot.knowledge_base.KnowledgeBase._store_chunks"
    )
    store_chunks.return_value = True
    return StoreChunksWithTitleMocks(
        _split_document=split_document, _store_chunks=store_chunks
    )


@pytest.fixture
def load_web_documents_from_list_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> LoadWebDocumentsFromListMocks:
    split_document: MagicMock = mocker.patch(
        "chatbot.knowledge_base.KnowledgeBase._split_document"
    )
    split_document.return_value = [Document("qux")]
    web_base_loader: MagicMock = mocker.patch("chatbot.knowledge_base.WebBaseLoader")
    loader_mock: MagicMock = MagicMock()
    loader_mock.load.return_value = [Document("quux")]
    web_base_loader.return_value = loader_mock
    get_collection: MagicMock = mocker.patch(
        "chatbot.knowledge_base.KnowledgeBase._get_collection"
    )
    get_collection.return_value.config.metadata = {"raw_page_hash": "foo"}
    client_mock: MagicMock = init_mocks.QdrantClient.return_value
    graph_client_mock: MagicMock = init_mocks.Graph.return_value
    graph_client_mock.has_vertex.return_value = False
    return LoadWebDocumentsFromListMocks(
        _store_title=mocker.patch("chatbot.knowledge_base.KnowledgeBase._store_title"),
        _store_title_and_keywords=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._store_title_and_keywords"
        ),
        _store_chunks_with_title=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._store_chunks_with_title"
        ),
        _collection_exists_with_content=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._collection_exists_with_content",
            return_value=False,
        ),
        _non_empty_collection_exists=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._non_empty_collection_exists",
            return_value=False,
        ),
        _store_chunks=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._store_chunks"
        ),
        _split_document=split_document,
        WebBaseLoader=web_base_loader,
        _get_collection=get_collection,
        LoadWebDocumentsFromListMocks__client=client_mock,
        compare_digest=mocker.patch(
            "chatbot.knowledge_base.hmac.compare_digest", return_value=False
        ),
        _LoadWebDocumentsFromListMocks__graph_client=graph_client_mock,
    )


@pytest.fixture
def get_matching_page_title_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> GetMatchingPageTitleMocks:
    doc: MagicMock = MagicMock()
    doc.page_content = "foo"
    get_documents: MagicMock = mocker.patch(
        "chatbot.knowledge_base.KnowledgeBase._get_documents"
    )
    get_documents.return_value.asimilarity_search_with_score = mocker.AsyncMock(
        return_value=[(doc, 0.9)]
    )
    graph_client_mock: MagicMock = init_mocks.Graph.return_value
    graph_client_mock.has_vertex.return_value = False
    return GetMatchingPageTitleMocks(
        _get_documents=get_documents,
        doc=doc,
        _GetMatchingPageTitleMocks__graph_client=graph_client_mock,
    )


@pytest.fixture
def retrieve_chunks_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> RetrieveChunksMocks:
    get_documents: MagicMock = mocker.patch(
        "chatbot.chatbot.KnowledgeBase._get_documents"
    )
    get_documents.return_value.asimilarity_search = mocker.AsyncMock()
    return RetrieveChunksMocks(
        _get_documents=get_documents,
        _get_collections=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._get_collections"
        ),
    )


@pytest.fixture
def load_qa_documents_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> LoadQADocumentsMocks:
    return LoadQADocumentsMocks(
        _store_chunks=mocker.patch(
            "chatbot.knowledge_base.KnowledgeBase._store_chunks"
        ),
        open=mocker.patch(
            "builtins.open",
            mock_open(
                read_data='[{"title": "foo", "qas": [{"question": "bar", "answer": "baz"}]}]'
            ),
        ),
    )


class TestInit:
    def test_init_qdrant_path_set_uses_path(self, init_mocks: InitMocks) -> None:
        KnowledgeBaseFixture(qdrant_path="/tmp/foo")
        init_mocks.QdrantClient.assert_called_once_with(path="/tmp/foo")

    def test_init_qdrant_url_set_uses_url(self, init_mocks: InitMocks) -> None:
        KnowledgeBaseFixture(qdrant_url="http://foo")
        init_mocks.QdrantClient.assert_called_once_with(
            prefer_grpc=True, url="http://foo"
        )

    def test_init_qdrant_path_none_uses_memory(self, init_mocks: InitMocks) -> None:
        KnowledgeBaseFixture()
        init_mocks.QdrantClient.assert_called_once_with(":memory:")


class TestGetCollections:
    @pytest.fixture
    def knowledge_base(self, init_mocks: InitMocks) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_get_collections_returns_collection_names(
        self, init_mocks: InitMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        collection1: MagicMock = MagicMock()
        collection1.name = "foo"
        collection2: MagicMock = MagicMock()
        collection2.name = "bar"
        init_mocks.QdrantClient.return_value.get_collections.return_value.collections = [
            collection1,
            collection2,
        ]
        assert knowledge_base.get_collections() == ["foo", "bar"]

    def test_get_collections_empty_returns_empty_list(
        self, init_mocks: InitMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        init_mocks.QdrantClient.return_value.get_collections.return_value.collections = []
        assert knowledge_base.get_collections() == []


class TestGetCollection:
    @pytest.fixture
    def knowledge_base(
        self, get_collection_mocks: GetCollectionMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_get_collection_returns_collection_info(
        self,
        get_collection_mocks: GetCollectionMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        assert (
            knowledge_base.get_collection("foo")
            == get_collection_mocks._GetCollectionMocks__client.get_collection.return_value
        )

    def test_get_collection_passes_sanitised_name_to_client(
        self,
        get_collection_mocks: GetCollectionMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.get_collection("foo")
        get_collection_mocks._GetCollectionMocks__client.get_collection.assert_called_once_with(
            "foo_sanitised"
        )

    def test_get_collection_sanitises_input_name(
        self,
        get_collection_mocks: GetCollectionMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.get_collection("foo")
        get_collection_mocks.sanitise_name.assert_called_once_with("foo")


class TestCollectionExists:
    @pytest.fixture
    def knowledge_base(
        self, collection_exists_mocks: CollectionExistsMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_collection_exists_name_in_collections_returns_true(
        self,
        collection_exists_mocks: CollectionExistsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        collection_exists_mocks._get_collections.return_value = [
            "foo_sanitised",
            "bar",
        ]
        assert knowledge_base.collection_exists("foo")

    def test_collection_exists_name_not_in_collections_returns_false(
        self,
        collection_exists_mocks: CollectionExistsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        collection_exists_mocks._get_collections.return_value = ["bar", "baz"]
        assert not knowledge_base.collection_exists("foo")

    def test_collection_exists_empty_collections_returns_false(
        self,
        collection_exists_mocks: CollectionExistsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        collection_exists_mocks._get_collections.return_value = []
        assert not knowledge_base.collection_exists("foo")

    def test_collection_exists_sanitises_input_name(
        self,
        collection_exists_mocks: CollectionExistsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        collection_exists_mocks._get_collections.return_value = []
        knowledge_base.collection_exists("foo")
        collection_exists_mocks.sanitise_name.assert_called_once_with("foo")


class TestNonEmptyCollectionExists:
    @pytest.fixture
    def knowledge_base(
        self, vector_store_mocks: VectorStoreMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_non_empty_collection_exists_exists_with_points_returns_true(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        vector_store_mocks._get_collection.return_value.points_count = 10
        assert knowledge_base.non_empty_collection_exists("foo")

    def test_non_empty_collection_exists_not_exists_returns_false(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = False
        assert not knowledge_base.non_empty_collection_exists("foo")

    def test_non_empty_collection_exists_zero_points_returns_false(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        vector_store_mocks._get_collection.return_value.points_count = 0
        assert not knowledge_base.non_empty_collection_exists("foo")

    def test_non_empty_collection_exists_none_points_returns_false(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        vector_store_mocks._get_collection.return_value.points_count = None
        assert not knowledge_base.non_empty_collection_exists("foo")


class TestCollectionExistsWithContent:
    @pytest.fixture
    def knowledge_base(
        self, vector_store_mocks: VectorStoreMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_collection_exists_with_content_exists_with_matching_content_returns_true(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        vector_store_mocks._VectorStoreMocks__client.scroll.return_value = (
            [MagicMock()],
            None,
        )
        assert knowledge_base.collection_exists_with_content("foo", "bar")

    def test_collection_exists_with_content_not_exists_returns_false(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = False
        assert not knowledge_base.collection_exists_with_content("foo", "bar")

    def test_collection_exists_with_content_no_matching_content_returns_false(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        vector_store_mocks._VectorStoreMocks__client.scroll.return_value = ([], None)
        assert not knowledge_base.collection_exists_with_content("foo", "bar")

    def test_collection_exists_with_content_uses_correct_filter(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        vector_store_mocks._VectorStoreMocks__client.scroll.return_value = ([], None)
        knowledge_base.collection_exists_with_content("foo", "bar")
        call_kwargs: dict[str, Any] = (
            vector_store_mocks._VectorStoreMocks__client.scroll.call_args[1]
        )
        assert call_kwargs["collection_name"] == "foo"
        assert call_kwargs["limit"] == 1
        filter_condition: FieldCondition = call_kwargs["scroll_filter"].must[0]
        assert filter_condition.key == "page_content"
        assert isinstance(filter_condition.match, MatchValue)
        assert filter_condition.match.value == "bar"


class TestStoreChunks:
    @pytest.fixture
    def knowledge_base(
        self, vector_store_mocks: VectorStoreMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_store_chunks_new_collection_creates_collection(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = False
        knowledge_base.store_chunks("foo", [Document("bar")], Document("baz"))
        vector_store_mocks._VectorStoreMocks__client.create_collection.assert_called_once()

    def test_store_chunks_existing_collection_skips_creation(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        knowledge_base.store_chunks("foo", [Document("bar")], Document("baz"))
        vector_store_mocks._VectorStoreMocks__client.create_collection.assert_not_called()

    def test_store_chunks_adds_documents_to_vector_store(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = True
        chunks: list[Document] = [Document("bar"), Document("baz")]
        knowledge_base.store_chunks("foo", chunks, Document("qux"))
        vector_store_mocks.QdrantVectorStore.return_value.add_documents.assert_called_once_with(
            documents=chunks
        )

    def test_store_chunks_returns_true(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        vector_store_mocks._collection_exists.return_value = False
        assert knowledge_base.store_chunks("foo", [Document("bar")], Document("baz"))


class TestGetDocuments:
    @pytest.fixture
    def knowledge_base(
        self, vector_store_mocks: VectorStoreMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_get_documents_returns_vector_store(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        knowledge_base.get_documents("foo")
        vector_store_mocks.QdrantVectorStore.assert_called_once()

    def test_get_documents_uses_collection_name(
        self, vector_store_mocks: VectorStoreMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        knowledge_base.get_documents("bar")
        call_kwargs: dict[str, Any] = vector_store_mocks.QdrantVectorStore.call_args[1]
        assert call_kwargs["collection_name"] == "bar"


class TestSplitDocument:
    @pytest.fixture
    def knowledge_base(
        self, split_document_mocks: SplitDocumentMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_split_document_returns_chunks(
        self,
        split_document_mocks: SplitDocumentMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        expected_chunks: list[Document] = [Document("foo"), Document("bar")]
        split_document_mocks.RecursiveCharacterTextSplitter.return_value.split_documents.return_value = expected_chunks
        assert knowledge_base.split_document(Document("baz")) == expected_chunks

    def test_split_document_configures_splitter(
        self,
        split_document_mocks: SplitDocumentMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.split_document(Document("foo"))
        call_kwargs: dict[str, Any] = (
            split_document_mocks.RecursiveCharacterTextSplitter.call_args[1]
        )
        assert call_kwargs["chunk_size"] == 1000
        assert call_kwargs["chunk_overlap"] == 200
        assert call_kwargs["add_start_index"]


class TestLoadWebDocuments:
    @pytest.fixture
    def knowledge_base(
        self, load_web_documents_mocks: LoadWebDocumentsMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_load_web_documents_reads_file_and_calls_from_list(
        self,
        load_web_documents_mocks: LoadWebDocumentsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_mocks.load_web_documents_from_list.return_value = True
        knowledge_base.load_web_documents("foo.json", ("bar", "baz"))
        load_web_documents_mocks.load_web_documents_from_list.assert_called_once_with(
            {"foo": "bar"}, ("bar", "baz"), {}, None
        )

    def test_load_web_documents_returns_result(
        self,
        load_web_documents_mocks: LoadWebDocumentsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_mocks.load_web_documents_from_list.return_value = True
        assert knowledge_base.load_web_documents("foo.json", ("bar", "baz"))


class TestStoreTitle:
    @pytest.fixture
    def knowledge_base(
        self, store_title_mocks: StoreTitleMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_store_title_title_not_exists_stores_chunks(
        self, store_title_mocks: StoreTitleMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        knowledge_base.store_title("foo")
        store_title_mocks._store_chunks.assert_called_once()

    def test_store_title_title_exists_skips_storage(
        self, store_title_mocks: StoreTitleMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        store_title_mocks._collection_exists_with_content.return_value = True
        knowledge_base.store_title("foo")
        store_title_mocks._store_chunks.assert_not_called()

    def test_store_title_checks_collection_with_correct_args(
        self, store_title_mocks: StoreTitleMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        knowledge_base.store_title("bar")
        store_title_mocks._collection_exists_with_content.assert_called_once_with(
            "titles", "bar"
        )

    def test_store_title_stores_to_titles_collection(
        self, store_title_mocks: StoreTitleMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        knowledge_base.store_title("baz")
        assert store_title_mocks._store_chunks.call_args[0][0] == "titles"

    def test_store_title_stores_title_as_document_content(
        self, store_title_mocks: StoreTitleMocks, knowledge_base: KnowledgeBaseFixture
    ) -> None:
        knowledge_base.store_title("qux")
        stored_doc: Document = store_title_mocks._store_chunks.call_args[0][1][0]
        assert stored_doc.page_content == "qux"


class TestStoreTitleAndKeywords:
    @pytest.fixture
    def knowledge_base(
        self, store_title_and_keywords_mocks: StoreTitleAndKeywordsMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_store_title_and_keywords_title_and_keywords_not_exists_stores_chunks(
        self,
        store_title_and_keywords_mocks: StoreTitleAndKeywordsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.store_title_and_keywords("foo")
        store_title_and_keywords_mocks._store_chunks.assert_called_once()

    def test_store_title_and_keywords_title_and_keywords_exists_skips_storage(
        self,
        store_title_and_keywords_mocks: StoreTitleAndKeywordsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        store_title_and_keywords_mocks._collection_exists_with_content.return_value = (
            True
        )
        knowledge_base.store_title_and_keywords("foo")
        store_title_and_keywords_mocks._store_chunks.assert_not_called()

    def test_store_title_and_keywords_checks_collection_with_correct_args(
        self,
        store_title_and_keywords_mocks: StoreTitleAndKeywordsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.store_title_and_keywords("bar")
        store_title_and_keywords_mocks._collection_exists_with_content.assert_called_once_with(
            "titles-and-keywords", "bar"
        )

    def test_store_title_and_keywords_stores_to_titles_and_keywords_collection(
        self,
        store_title_and_keywords_mocks: StoreTitleAndKeywordsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.store_title_and_keywords("baz")
        assert (
            store_title_and_keywords_mocks._store_chunks.call_args[0][0]
            == "titles-and-keywords"
        )

    def test_store_title_and_keywords_stores_title_and_keywords_as_document_content(
        self,
        store_title_and_keywords_mocks: StoreTitleAndKeywordsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.store_title_and_keywords("qux")
        stored_doc: Document = store_title_and_keywords_mocks._store_chunks.call_args[
            0
        ][1][0]
        assert stored_doc.page_content == "qux"


class TestStoreChunksWithTitle:
    @pytest.fixture
    def knowledge_base(
        self, store_chunks_with_title_mocks: StoreChunksWithTitleMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_store_chunks_with_title_splits_document(
        self,
        store_chunks_with_title_mocks: StoreChunksWithTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        page: Document = Document("content")
        knowledge_base.store_chunks_with_title(page, "foo")
        store_chunks_with_title_mocks._split_document.assert_called_once_with(page)

    def test_store_chunks_with_title_adds_title_to_chunk_metadata(
        self,
        store_chunks_with_title_mocks: StoreChunksWithTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        page: Document = Document("content")
        knowledge_base.store_chunks_with_title(page, "bar")
        stored_chunks: list[Document] = (
            store_chunks_with_title_mocks._store_chunks.call_args[0][1]
        )
        assert all(chunk.metadata["title"] == "bar" for chunk in stored_chunks)

    def test_store_chunks_with_title_preserves_existing_metadata(
        self,
        store_chunks_with_title_mocks: StoreChunksWithTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        page: Document = Document("content")
        knowledge_base.store_chunks_with_title(page, "baz")
        stored_chunks: list[Document] = (
            store_chunks_with_title_mocks._store_chunks.call_args[0][1]
        )
        assert stored_chunks[0].metadata["existing"] == "metadata"
        assert stored_chunks[0].metadata["title"] == "baz"

    def test_store_chunks_with_title_uses_title_as_collection_name(
        self,
        store_chunks_with_title_mocks: StoreChunksWithTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        page: Document = Document("content")
        knowledge_base.store_chunks_with_title(page, "qux")
        assert store_chunks_with_title_mocks._store_chunks.call_args[0][0] == "qux"

    def test_store_chunks_with_title_returns_store_chunks_result(
        self,
        store_chunks_with_title_mocks: StoreChunksWithTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        page: Document = Document("content")
        assert knowledge_base.store_chunks_with_title(page, "quux")

    def test_store_chunks_with_title_passes_raw_page(
        self,
        store_chunks_with_title_mocks: StoreChunksWithTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        page: Document = Document("content")
        knowledge_base.store_chunks_with_title(page, "corge")
        call_args: tuple[Any, ...] = (
            store_chunks_with_title_mocks._store_chunks.call_args[0]
        )
        assert len(call_args) == 3
        assert call_args[2] == page


class TestLoadWebDocumentsFromList:
    @pytest.fixture
    def knowledge_base(
        self, load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture(refresh_embeddings_on_start=True)

    def test_load_web_documents_from_list_skips_existing_content(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
    ) -> None:
        load_web_documents_from_list_mocks._non_empty_collection_exists.return_value = (
            True
        )
        KnowledgeBaseFixture(
            refresh_embeddings_on_start=False
        ).load_web_documents_from_list({"foo": "http://bar"}, ("baz",))
        load_web_documents_from_list_mocks.WebBaseLoader.assert_not_called()

    def test_load_web_documents_from_list_skips_existing_title(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._collection_exists_with_content.return_value = True
        knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))
        assert all(
            call.args[0] != "titles"
            for call in load_web_documents_from_list_mocks._store_chunks.call_args_list
        )

    def test_load_web_documents_from_list_no_keyword_repo_stores_titles_and_content(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"}, ("baz", "qux")
        )
        load_web_documents_from_list_mocks._store_title.assert_called_once()
        load_web_documents_from_list_mocks._store_chunks_with_title.assert_called_once()

    def test_load_web_documents_from_list_no_keyword_repo_skips_titles_and_keywords(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"}, ("baz", "qux")
        )
        load_web_documents_from_list_mocks._store_title_and_keywords.assert_not_called()

    def test_load_web_documents_from_list_with_keyword_repo_stores_titles_keywords_and_content(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"},
            ("baz", "qux"),
            {},
            [Page(url="http://foo", title="foo", keywords=["bar"])],
        )
        load_web_documents_from_list_mocks._store_title.assert_called_once()
        load_web_documents_from_list_mocks._store_title_and_keywords.assert_called_once()
        load_web_documents_from_list_mocks._store_chunks_with_title.assert_called_once()

    def test_load_web_documents_from_list_with_keyword_repo_calls_store_title_and_keywords(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"},
            ("baz", "qux"),
            {},
            [Page(url="http://foo", title="foo", keywords=["bar"])],
        )
        load_web_documents_from_list_mocks._store_title_and_keywords.assert_called_once()

    def test_load_web_documents_from_list_with_keyword_repo_filters_keywords_by_title(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"},
            ("baz", "qux"),
            {},
            [
                Page(url="http://foo", title="foo", keywords=["garply"]),
                Page(url="http://bar", title="bar", keywords=["waldo"]),
            ],
        )
        title_and_keywords: str = (
            load_web_documents_from_list_mocks._store_title_and_keywords.call_args[0][0]
        )
        assert "garply" in title_and_keywords
        assert "waldo" not in title_and_keywords

    def test_load_web_documents_from_list_with_keyword_repo_uses_separator(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"},
            ("baz",),
            {},
            [Page(url="http://foo", title="foo", keywords=["garply", "waldo"])],
        )
        assert (
            load_web_documents_from_list_mocks._store_title_and_keywords.call_args[0][0]
            == "foo - garply waldo"
        )

    def test_load_web_documents_from_list_returns_true(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._collection_exists_with_content.return_value = True
        assert knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"}, ("baz",)
        )

    def test_load_web_documents_from_list_with_adjacency_adds_edges(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar", "quux": "http://qux"},
            ("baz",),
            {"http://bar": ["http://qux"]},
        )
        load_web_documents_from_list_mocks._LoadWebDocumentsFromListMocks__graph_client.add_edges.assert_any_call(
            "foo", ["quux"]
        )

    def test_load_web_documents_from_list_without_adjacency_skips_edges(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))
        load_web_documents_from_list_mocks._LoadWebDocumentsFromListMocks__graph_client.add_edges.assert_not_called()

    def test_load_web_documents_from_list_with_adjacency_existing_vertex_skips_edges(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._LoadWebDocumentsFromListMocks__graph_client.has_vertex.return_value = True
        knowledge_base.load_web_documents_from_list(
            {"foo": "http://bar"}, ("baz",), {"http://bar": ["http://qux"]}
        )
        load_web_documents_from_list_mocks._LoadWebDocumentsFromListMocks__graph_client.add_edges.assert_not_called()

    def test_load_web_documents_from_list_saves_graph(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))
        load_web_documents_from_list_mocks._LoadWebDocumentsFromListMocks__graph_client.save.assert_called_once()

    def test_load_web_documents_from_list_no_metadata_raises_error(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._non_empty_collection_exists.return_value = (
            True
        )
        load_web_documents_from_list_mocks._get_collection.return_value.config.metadata = None
        with pytest.raises(
            ValueError, match="non-empty collection foo has no page hash"
        ):
            knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))

    def test_load_web_documents_from_list_no_hash_in_metadata_raises_error(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._non_empty_collection_exists.return_value = (
            True
        )
        load_web_documents_from_list_mocks._get_collection.return_value.config.metadata = {}
        with pytest.raises(
            ValueError, match="non-empty collection foo has no page hash"
        ):
            knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))

    def test_load_web_documents_from_list_inconsistent_hash_deletes_collection(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._non_empty_collection_exists.return_value = (
            True
        )
        knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))
        load_web_documents_from_list_mocks.LoadWebDocumentsFromListMocks__client.delete_collection.assert_called_once_with(
            "foo"
        )

    def test_load_web_documents_from_list_consistent_hash_retains_collection(
        self,
        load_web_documents_from_list_mocks: LoadWebDocumentsFromListMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        load_web_documents_from_list_mocks._non_empty_collection_exists.return_value = (
            True
        )
        load_web_documents_from_list_mocks.compare_digest.return_value = True
        knowledge_base.load_web_documents_from_list({"foo": "http://bar"}, ("baz",))
        load_web_documents_from_list_mocks._get_collection.delete_collection.assert_not_called()


class TestGetMatchingPageTitle:
    @pytest.fixture
    def knowledge_base(
        self, get_matching_page_title_mocks: GetMatchingPageTitleMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    async def test_get_matching_page_title_returns_single_title(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        assert await knowledge_base.get_matching_page_title("bar") == ["foo"]

    async def test_get_matching_page_title_without_links_returns_only_matched_title(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        assert await knowledge_base.get_matching_page_title("bar", False) == ["foo"]

    async def test_get_matching_page_title_with_links_no_adjacency_returns_only_matched_title(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        assert await knowledge_base.get_matching_page_title("bar", True) == ["foo"]

    async def test_get_matching_page_title_with_links_and_adjacency_returns_linked_titles(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        get_matching_page_title_mocks._GetMatchingPageTitleMocks__graph_client.has_vertex.return_value = True
        get_matching_page_title_mocks._GetMatchingPageTitleMocks__graph_client.get_connected_vertices.return_value = [
            "baz",
            "qux",
        ]
        assert await knowledge_base.get_matching_page_title("bar", True) == [
            "foo",
            "baz",
            "qux",
        ]

    async def test_get_matching_page_title_uses_titles_collection(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        await knowledge_base.get_matching_page_title("bar")
        get_matching_page_title_mocks._get_documents.assert_called_once_with("titles")

    async def test_get_matching_page_title_with_keywords_uses_titles_and_keywords_collection(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        await knowledge_base.get_matching_page_title("bar", False, True)
        get_matching_page_title_mocks._get_documents.assert_called_once_with(
            "titles-and-keywords"
        )

    async def test_get_matching_page_title_with_keywords_normalizes_title_by_separator(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        get_matching_page_title_mocks.doc.page_content = "foo - keyword1 keyword2"
        assert await knowledge_base.get_matching_page_title("bar", False, True) == [
            "foo"
        ]

    async def test_get_matching_page_title_multiple_within_threshold_links_off_returns_top_title(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        doc2: MagicMock = MagicMock()
        doc2.page_content = "bar"
        get_matching_page_title_mocks._get_documents.return_value.asimilarity_search_with_score.return_value = [
            (get_matching_page_title_mocks.doc, 0.9),
            (doc2, 0.85),
        ]
        assert await knowledge_base.get_matching_page_title("baz", False) == ["foo"]

    async def test_get_matching_page_title_multiple_within_threshold_links_on_returns_all_titles(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        doc2: MagicMock = MagicMock()
        doc2.page_content = "bar"
        get_matching_page_title_mocks._get_documents.return_value.asimilarity_search_with_score.return_value = [
            (get_matching_page_title_mocks.doc, 0.9),
            (doc2, 0.85),
        ]
        assert await knowledge_base.get_matching_page_title("baz", True) == [
            "foo",
            "bar",
        ]

    async def test_get_matching_page_title_doc_below_threshold_excluded(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        doc2: MagicMock = MagicMock()
        doc2.page_content = "bar"
        doc3: MagicMock = MagicMock()
        doc3.page_content = "baz"
        get_matching_page_title_mocks._get_documents.return_value.asimilarity_search_with_score.return_value = [
            (get_matching_page_title_mocks.doc, 0.9),
            (doc2, 0.85),
            (doc3, 0.79),
        ]
        assert await knowledge_base.get_matching_page_title("qux", True) == [
            "foo",
            "bar",
        ]

    async def test_get_matching_page_title_doc_at_threshold_boundary_included(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        doc2: MagicMock = MagicMock()
        doc2.page_content = "bar"
        get_matching_page_title_mocks._get_documents.return_value.asimilarity_search_with_score.return_value = [
            (get_matching_page_title_mocks.doc, 0.9),
            (doc2, 0.8),
        ]
        assert await knowledge_base.get_matching_page_title("baz", True) == [
            "foo",
            "bar",
        ]

    async def test_get_matching_page_title_doc_just_below_threshold_excluded(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        doc2: MagicMock = MagicMock()
        doc2.page_content = "bar"
        get_matching_page_title_mocks._get_documents.return_value.asimilarity_search_with_score.return_value = [
            (get_matching_page_title_mocks.doc, 0.9),
            (doc2, 0.799),
        ]
        assert await knowledge_base.get_matching_page_title("baz", True) == ["foo"]

    async def test_get_matching_page_title_links_on_multiple_titles_all_adjacencies_included(
        self,
        get_matching_page_title_mocks: GetMatchingPageTitleMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        doc2: MagicMock = MagicMock()
        doc2.page_content = "bar"
        get_matching_page_title_mocks._get_documents.return_value.asimilarity_search_with_score.return_value = [
            (get_matching_page_title_mocks.doc, 0.9),
            (doc2, 0.85),
        ]
        get_matching_page_title_mocks._GetMatchingPageTitleMocks__graph_client.has_vertex.return_value = True
        get_matching_page_title_mocks._GetMatchingPageTitleMocks__graph_client.get_connected_vertices.side_effect = [
            ["baz"],
            ["qux"],
        ]
        assert await knowledge_base.get_matching_page_title("quux", True) == [
            "foo",
            "bar",
            "baz",
            "qux",
        ]


class TestRetrieveChunks:
    @pytest.fixture
    def knowledge_base(
        self, retrieve_chunks_mocks: RetrieveChunksMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    async def test_retrieve_chunks_multiple_collections_queries_each_title(
        self,
        retrieve_chunks_mocks: RetrieveChunksMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        retrieve_chunks_mocks._get_collections.return_value = ["titles", "foo"]
        chunk1: Document = Document("qux")
        chunk2: Document = Document("quux")
        retrieve_chunks_mocks._get_documents.return_value.asimilarity_search.return_value = [
            chunk1,
            chunk2,
        ]
        assert len(await knowledge_base.retrieve_chunks("bar", ["foo", "baz"])) == 4

    async def test_retrieve_chunks_single_collection_uses_default(
        self,
        retrieve_chunks_mocks: RetrieveChunksMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        retrieve_chunks_mocks._get_collections.return_value = ["default"]
        doc: Document = Document("doc")
        retrieve_chunks_mocks._get_documents.return_value.asimilarity_search.return_value = [
            doc
        ]
        await knowledge_base.retrieve_chunks("bar", ["foo"])
        retrieve_chunks_mocks._get_documents.assert_called_with("default")

    async def test_retrieve_chunks_multiple_collections_flattens_results(
        self,
        retrieve_chunks_mocks: RetrieveChunksMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        retrieve_chunks_mocks._get_collections.return_value = ["titles", "foo"]
        chunk1: Document = Document("qux")
        chunk2: Document = Document("quux")
        retrieve_chunks_mocks._get_documents.return_value.asimilarity_search.side_effect = [
            [chunk1],
            [chunk2],
        ]
        assert await knowledge_base.retrieve_chunks("bar", ["foo", "baz"]) == [
            chunk1,
            chunk2,
        ]

    async def test_retrieve_chunks_empty_titles_returns_empty(
        self,
        retrieve_chunks_mocks: RetrieveChunksMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        retrieve_chunks_mocks._get_collections.return_value = ["titles", "foo"]
        assert await knowledge_base.retrieve_chunks("bar", []) == []


class TestLoadQADocuments:
    @pytest.fixture
    def knowledge_base(
        self, load_qa_documents_mocks: LoadQADocumentsMocks
    ) -> KnowledgeBaseFixture:
        return KnowledgeBaseFixture()

    def test_load_qa_documents_multi_store_creates_title_collection(
        self,
        load_qa_documents_mocks: LoadQADocumentsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_qa_documents("foo.json", False)
        assert any(
            call[0][0] == "titles"
            for call in load_qa_documents_mocks._store_chunks.call_args_list
        )

    def test_load_qa_documents_single_store_uses_default(
        self,
        load_qa_documents_mocks: LoadQADocumentsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        knowledge_base.load_qa_documents("foo.json", True)
        assert all(
            call[0][0] == "default"
            for call in load_qa_documents_mocks._store_chunks.call_args_list
        )

    def test_load_qa_documents_returns_true(
        self,
        load_qa_documents_mocks: LoadQADocumentsMocks,
        knowledge_base: KnowledgeBaseFixture,
    ) -> None:
        assert knowledge_base.load_qa_documents("foo.json")
