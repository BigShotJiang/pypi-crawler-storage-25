from chatbot.utils.sanitise import Sanitiser


class TestSanitiseName:
    def test_sanitise_name_basic_characters_removed(self) -> None:
        assert Sanitiser.sanitise_name("foo bar") == "foo_bar"
        assert Sanitiser.sanitise_name("foo/bar") == "foo_bar"
        assert Sanitiser.sanitise_name("FOOBAR") == "foobar"

    def test_sanitise_name_special_characters_removed(self) -> None:
        assert Sanitiser.sanitise_name("foo@#$%bar") == "foobar"
        assert Sanitiser.sanitise_name("foo!bar?") == "foobar"
        assert Sanitiser.sanitise_name("foo(bar)baz") == "foobarbaz"

    def test_sanitise_name_spaces_and_slashes_removed(self) -> None:
        assert Sanitiser.sanitise_name("foo   bar") == "foo___bar"
        assert Sanitiser.sanitise_name("foo/bar/baz") == "foo_bar_baz"
        assert Sanitiser.sanitise_name("foo / bar") == "foo___bar"

    def test_sanitise_name_valid_characters_preserved(self) -> None:
        assert Sanitiser.sanitise_name("foo_bar-123") == "foo_bar-123"
        assert Sanitiser.sanitise_name("foo_bar") == "foo_bar"
        assert Sanitiser.sanitise_name("Foo-123_BAR") == "foo-123_bar"

    def test_sanitise_name_edge_cases_handled(self) -> None:
        assert Sanitiser.sanitise_name("") == ""
        assert Sanitiser.sanitise_name("___") == "___"
        assert Sanitiser.sanitise_name("123garply") == "123garply"
        assert Sanitiser.sanitise_name("!@#$%^&*()") == ""
        assert Sanitiser.sanitise_name("foo_baz\u00e9") == "foo_baz"
