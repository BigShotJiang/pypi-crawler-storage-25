from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock

import pytest
from langchain_core.documents import Document
from langchain_core.messages import ToolMessage
from pytest_mock import MockerFixture

from chatbot.types import QA, QAEvaluation, QuestionContextAnswer
from tests.chatbot import ChatbotFixture


@dataclass
class InitMocks:
    KnowledgeBase: MagicMock
    MemorySaver: MagicMock
    Settings: MagicMock
    logger: MagicMock


@dataclass
class LLMMocks(InitMocks):
    ChatBedrockConverse: MagicMock
    ChatNVIDIA: MagicMock


@dataclass
class RetrieveAndGeneratePublicMocks:
    _retrieve_and_generate: MagicMock
    uuid4: MagicMock


@dataclass
class RetrieveAndGenerateMocks:
    StateGraph: MagicMock
    llm: MagicMock
    Settings: MagicMock


@dataclass
class GraphStreamMocks:
    parent: RetrieveAndGenerateMocks
    ai_response: MagicMock
    stream: MagicMock


@dataclass
class EvaluateMocks:
    _retrieve_and_generate: MagicMock


@pytest.fixture
def base_mocks(mocker: MockerFixture) -> InitMocks:
    settings_mock: MagicMock = MagicMock()
    settings_mock.EMBEDDINGS_MODEL_NAME = "foo"
    settings_mock.QDRANT_PATH = None
    settings_mock.DUCKDB_PATH = "foo/bar"
    settings_mock.SIMILARITY_SCORE_TOLERANCE = 0.1
    return InitMocks(
        KnowledgeBase=mocker.patch("chatbot.chatbot.KnowledgeBase"),
        MemorySaver=mocker.patch("chatbot.chatbot.MemorySaver"),
        Settings=mocker.patch("chatbot.chatbot.Settings", return_value=settings_mock),
        logger=mocker.patch("logging.getLogger"),
    )


@pytest.fixture
def init_mocks(mocker: MockerFixture, base_mocks: InitMocks) -> InitMocks:
    mocker.patch("chatbot.chatbot.Chatbot._init_llm")
    return base_mocks


@pytest.fixture
def llm_mocks(mocker: MockerFixture, base_mocks: InitMocks) -> LLMMocks:
    return LLMMocks(
        KnowledgeBase=base_mocks.KnowledgeBase,
        MemorySaver=base_mocks.MemorySaver,
        Settings=base_mocks.Settings,
        logger=base_mocks.logger,
        ChatBedrockConverse=mocker.patch("chatbot.chatbot.ChatBedrockConverse"),
        ChatNVIDIA=mocker.patch("chatbot.chatbot.ChatNVIDIA"),
    )


@pytest.fixture
def retrieve_and_generate_public_mocks(
    mocker: MockerFixture, init_mocks: InitMocks
) -> RetrieveAndGeneratePublicMocks:
    return RetrieveAndGeneratePublicMocks(
        _retrieve_and_generate=mocker.patch(
            "chatbot.chatbot.Chatbot._retrieve_and_generate",
            new_callable=mocker.AsyncMock,
        ),
        uuid4=mocker.patch("chatbot.chatbot.uuid.uuid4"),
    )


@pytest.fixture
def retrieve_and_generate_mocks(
    mocker: MockerFixture, llm_mocks: LLMMocks
) -> RetrieveAndGenerateMocks:
    llm_mocks.Settings.return_value.LLM_MODEL_NAME = "foo/bar"
    llm_mocks.Settings.return_value.NVIDIA_API_KEY = "bar"
    llm_mocks.Settings.return_value.LLM.MAX_RETRIES = 3
    llm_mocks.Settings.return_value.LLM.SYSTEM_PROMPT_RESPOND = "baz"
    llm_mocks.Settings.return_value.LLM.SYSTEM_PROMPT_RETRIEVE = "qux"
    llm_mocks.Settings.return_value.LLM.NEGATIVE_RESPONSE = "quux"
    state_graph_mock: MagicMock = mocker.patch("chatbot.chatbot.StateGraph")
    state_graph_mock.return_value.compile.return_value = MagicMock()
    return RetrieveAndGenerateMocks(
        StateGraph=state_graph_mock,
        llm=llm_mocks.ChatNVIDIA,
        Settings=llm_mocks.Settings,
    )


@pytest.fixture
def graph_stream_mocks(
    retrieve_and_generate_mocks: RetrieveAndGenerateMocks,
) -> GraphStreamMocks:
    ai_response: MagicMock = MagicMock()
    ai_response.content = "bar"
    ai_response.type = "ai"
    ai_response.tool_calls = []
    stream: MagicMock = (
        retrieve_and_generate_mocks.StateGraph.return_value.compile.return_value.astream
    )

    async def async_iter(*args: Any, **kwargs: Any) -> Any:
        for item in [{"messages": [ai_response]}]:
            yield item

    stream.side_effect = async_iter
    return GraphStreamMocks(retrieve_and_generate_mocks, ai_response, stream)


@pytest.fixture
def evaluate_mocks(mocker: MockerFixture, init_mocks: InitMocks) -> EvaluateMocks:
    return EvaluateMocks(
        _retrieve_and_generate=mocker.patch(
            "chatbot.chatbot.Chatbot._retrieve_and_generate",
            new_callable=mocker.AsyncMock,
        ),
    )


class TestInit:
    def test_init_embeddings_model_name_set_uses_name(
        self, init_mocks: InitMocks
    ) -> None:
        ChatbotFixture()
        init_mocks.KnowledgeBase.assert_called_once_with(
            duckdb_path="foo/bar",
            embeddings_model_name="foo",
            similarity_score_tolerance=0.1,
        )

    def test_init_refresh_embeddings_on_start_set_set_refresh(
        self, init_mocks: InitMocks
    ) -> None:
        init_mocks.Settings.return_value.EMBEDDINGS_MODEL_NAME = "bar"
        ChatbotFixture()
        init_mocks.KnowledgeBase.assert_called_once_with(
            duckdb_path="foo/bar",
            embeddings_model_name="bar",
            similarity_score_tolerance=0.1,
        )

    def test_init_qdrant_path_set_uses_path(self, init_mocks: InitMocks) -> None:
        init_mocks.Settings.return_value.QDRANT_PATH = "/tmp/foo"
        ChatbotFixture()
        init_mocks.KnowledgeBase.assert_called_once_with(
            duckdb_path="foo/bar",
            embeddings_model_name="foo",
            similarity_score_tolerance=0.1,
            qdrant_path="/tmp/foo",
        )

    def test_init_qdrant_url_set_uses_url(self, init_mocks: InitMocks) -> None:
        init_mocks.Settings.return_value.QDRANT_PATH = "http://foo"
        ChatbotFixture()
        init_mocks.KnowledgeBase.assert_called_once_with(
            duckdb_path="foo/bar",
            embeddings_model_name="foo",
            similarity_score_tolerance=0.1,
            qdrant_url="http://foo",
        )

    def test_init_qdrant_path_none_uses_memory(self, init_mocks: InitMocks) -> None:
        init_mocks.Settings.return_value.QDRANT_PATH = None
        ChatbotFixture()
        init_mocks.KnowledgeBase.assert_called_once_with(
            duckdb_path="foo/bar",
            embeddings_model_name="foo",
            similarity_score_tolerance=0.1,
        )


class TestInitLLM:
    @pytest.mark.parametrize(
        "model_name",
        ["foo.bar.baz.00", "qux.quux.foobar.01"],
    )
    def test_init_llm_bedrock_model_creates_bedrock(
        self, llm_mocks: LLMMocks, model_name: str
    ) -> None:
        llm_mocks.Settings.return_value.LLM_MODEL_NAME = model_name
        llm_mocks.Settings.return_value.AWS_BEARER_TOKEN_BEDROCK = "foo"
        llm_mocks.Settings.return_value.AWS_REGION = "bar"
        ChatbotFixture()
        llm_mocks.ChatBedrockConverse.assert_called_once()
        llm_mocks.ChatNVIDIA.assert_not_called()

    @pytest.mark.parametrize("model_name", ["foo/bar-baz-00", "qux/quux-foobar-01"])
    def test_init_llm_nvidia_model_creates_nvidia(
        self, llm_mocks: LLMMocks, model_name: str
    ) -> None:
        llm_mocks.Settings.return_value.LLM_MODEL_NAME = model_name
        llm_mocks.Settings.return_value.NVIDIA_API_KEY = "foo"
        ChatbotFixture()
        llm_mocks.ChatNVIDIA.assert_called_once()
        llm_mocks.ChatBedrockConverse.assert_not_called()


class TestRetrieveAndGenerate:
    @pytest.fixture
    def chatbot(
        self, retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks
    ) -> ChatbotFixture:
        return ChatbotFixture()

    async def test_retrieve_and_generate_returns_answer_string(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        assert await chatbot.retrieve_and_generate("foo") == "bar"

    async def test_retrieve_and_generate_uses_provided_chat_id(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate("foo", "baz-id")
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, False, True, None
        )

    async def test_retrieve_and_generate_generates_uuid_when_no_chat_id(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        retrieve_and_generate_public_mocks.uuid4.return_value = "generated-uuid"
        await chatbot.retrieve_and_generate("foo")
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "generated-uuid", False, False, True, None
        )

    async def test_retrieve_and_generate_passes_use_adjacency(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate("foo", "baz-id", True)
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", True, False, True, None
        )

    async def test_retrieve_and_generate_passes_use_keywords(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate("foo", "baz-id", False, True)
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, True, True, None
        )

    async def test_retrieve_and_generate_passes_dynamic_prompt_content(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate("foo", "baz-id", False, False, True, "qux")
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, False, True, "qux"
        )

    async def test_retrieve_and_generate_passes_use_query_rewriting(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate("foo", "baz-id", False, False, False)
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, False, False, None
        )


class TestRetrieveAndGenerateWithContext:
    @pytest.fixture
    def chatbot(
        self, retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks
    ) -> ChatbotFixture:
        return ChatbotFixture()

    async def test_retrieve_and_generate_with_context_uses_provided_chat_id(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate_with_context("foo", "baz-id")
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, False, True, None
        )

    async def test_retrieve_and_generate_with_context_generates_uuid_when_no_chat_id(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        retrieve_and_generate_public_mocks.uuid4.return_value = "generated-uuid"
        await chatbot.retrieve_and_generate_with_context("foo")
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "generated-uuid", False, False, True, None
        )

    async def test_retrieve_and_generate_with_context_passes_use_adjacency(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate_with_context("foo", "baz-id", True)
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", True, False, True, None
        )

    async def test_retrieve_and_generate_with_context_passes_use_keywords(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate_with_context("foo", "baz-id", False, True)
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, True, True, None
        )

    async def test_retrieve_and_generate_with_context_passes_dynamic_prompt_content(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate_with_context(
            "foo", "baz-id", False, False, True, "qux"
        )
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, False, True, "qux"
        )

    async def test_retrieve_and_generate_with_context_passes_use_query_rewriting(
        self,
        retrieve_and_generate_public_mocks: RetrieveAndGeneratePublicMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        retrieve_and_generate_public_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        await chatbot.retrieve_and_generate_with_context(
            "foo", "baz-id", False, False, False
        )
        retrieve_and_generate_public_mocks._retrieve_and_generate.assert_called_once_with(
            "foo", "baz-id", False, False, False, None
        )


class TestBuildSystemPrompt:
    @pytest.fixture
    def chatbot(self, init_mocks: InitMocks) -> ChatbotFixture:
        init_mocks.Settings.return_value.LLM.SYSTEM_PROMPT_RETRIEVE = "foo"
        return ChatbotFixture()

    def test_build_system_prompt_both_prompts_joins_with_space(
        self, chatbot: ChatbotFixture
    ) -> None:
        tool_msg: ToolMessage = ToolMessage(content="qux", tool_call_id="1")
        assert chatbot.build_system_prompt([tool_msg], "bar") == "foo bar\n\nqux"

    def test_build_system_prompt_no_dynamic_content_uses_system_prompt_only(
        self, chatbot: ChatbotFixture
    ) -> None:
        tool_msg: ToolMessage = ToolMessage(content="qux", tool_call_id="1")
        assert chatbot.build_system_prompt([tool_msg], None) == "foo\n\nqux"

    def test_build_system_prompt_no_system_prompt_uses_dynamic_only(
        self, init_mocks: InitMocks
    ) -> None:
        init_mocks.Settings.return_value.LLM.SYSTEM_PROMPT_RETRIEVE = None
        chatbot: ChatbotFixture = ChatbotFixture()
        tool_msg: ToolMessage = ToolMessage(content="qux", tool_call_id="1")
        assert chatbot.build_system_prompt([tool_msg], "bar") == "bar\n\nqux"

    def test_build_system_prompt_multiple_tool_messages_joins_with_double_newlines(
        self, chatbot: ChatbotFixture
    ) -> None:
        tool_msgs: list[ToolMessage] = [
            ToolMessage(content="qux", tool_call_id="1"),
            ToolMessage(content="quux", tool_call_id="2"),
        ]
        assert chatbot.build_system_prompt(tool_msgs, "bar") == "foo bar\n\nqux\n\nquux"

    def test_build_system_prompt_empty_tool_messages_returns_prompt_with_empty_docs(
        self, chatbot: ChatbotFixture
    ) -> None:
        assert chatbot.build_system_prompt([], "bar") == "foo bar\n\n"


class TestRetrieveAndGenerateInternal:
    @pytest.fixture
    def chatbot(self, graph_stream_mocks: GraphStreamMocks) -> ChatbotFixture:
        return ChatbotFixture()

    async def test_retrieve_and_generate_builds_graph_with_nodes(
        self,
        graph_stream_mocks: GraphStreamMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        await chatbot._retrieve_and_generate("foo", "baz")
        graph_stream_mocks.parent.StateGraph.return_value.add_node.assert_called()

    async def test_retrieve_and_generate_returns_question_context_answer(
        self,
        graph_stream_mocks: GraphStreamMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        result, _ = await chatbot._retrieve_and_generate("foo", "baz")
        assert result.question == "foo"
        assert result.answer == "bar"

    async def test_retrieve_and_generate_with_context_includes_documents(
        self,
        graph_stream_mocks: GraphStreamMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        context_docs: list[Document] = [Document("doc1"), Document("doc2")]

        async def async_iter_with_context(*args: Any, **kwargs: Any) -> Any:
            for item in [
                {
                    "messages": [graph_stream_mocks.ai_response],
                    "context": context_docs,
                }
            ]:
                yield item

        graph_stream_mocks.stream.side_effect = async_iter_with_context
        result, _ = await chatbot._retrieve_and_generate("foo", "baz")
        assert len(result.context) == 2

    async def test_retrieve_and_generate_negative_response_excludes_context(
        self,
        graph_stream_mocks: GraphStreamMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        graph_stream_mocks.ai_response.content = "quux"
        context_docs: list[Document] = [Document("doc1")]

        async def async_iter_negative(*args: Any, **kwargs: Any) -> Any:
            for item in [
                {
                    "messages": [graph_stream_mocks.ai_response],
                    "context": context_docs,
                }
            ]:
                yield item

        graph_stream_mocks.stream.side_effect = async_iter_negative
        result, _ = await chatbot._retrieve_and_generate("foo", "baz")
        assert len(result.context) == 0

    async def test_retrieve_and_generate_returns_message_count(
        self,
        graph_stream_mocks: GraphStreamMocks,
        chatbot: ChatbotFixture,
    ) -> None:
        msg1: MagicMock = MagicMock()
        msg1.type = "human"

        async def async_iter_multi_msg(*args: Any, **kwargs: Any) -> Any:
            for item in [{"messages": [msg1, graph_stream_mocks.ai_response]}]:
                yield item

        graph_stream_mocks.stream.side_effect = async_iter_multi_msg
        _, count = await chatbot._retrieve_and_generate("foo", "baz")
        assert count == 2


class TestEvaluate:
    @pytest.fixture
    def chatbot(self, evaluate_mocks: EvaluateMocks) -> ChatbotFixture:
        return ChatbotFixture()

    async def test_evaluate_returns_qa_evaluations(
        self, evaluate_mocks: EvaluateMocks, chatbot: ChatbotFixture
    ) -> None:
        evaluate_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            3,
        )
        result: list[QA] = await chatbot.evaluate(["foo"])
        assert len(result) == 1
        assert isinstance(result[0], QAEvaluation)

    @pytest.mark.parametrize(
        "message_count,expected_rag", [(2, False), (3, True), (5, True)]
    )
    async def test_evaluate_sets_rag_based_on_message_count(
        self,
        evaluate_mocks: EvaluateMocks,
        chatbot: ChatbotFixture,
        message_count: int,
        expected_rag: bool,
    ) -> None:
        evaluate_mocks._retrieve_and_generate.return_value = (
            QuestionContextAnswer(question="foo", context=[], answer="bar"),
            message_count,
        )
        result: list[QA] = await chatbot.evaluate(["foo"])
        assert isinstance(result[0], QAEvaluation)
        assert result[0].rag == expected_rag

    async def test_evaluate_multiple_messages_returns_multiple_results(
        self, evaluate_mocks: EvaluateMocks, chatbot: ChatbotFixture
    ) -> None:
        evaluate_mocks._retrieve_and_generate.side_effect = [
            (QuestionContextAnswer(question="foo", context=[], answer="bar"), 3),
            (QuestionContextAnswer(question="baz", context=[], answer="qux"), 2),
        ]
        assert len(await chatbot.evaluate(["foo", "baz"])) == 2
