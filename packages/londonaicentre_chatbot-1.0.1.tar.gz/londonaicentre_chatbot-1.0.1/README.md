# chatbot

Wrapper around [LangChain](https://www.langchain.com/) functions, specifying:

- A two-step chunk lookup process: title search followed by content search

- Use of HuggingFace to obtain a local embeddings model

- Use of NVIDIA or Bedrock for a remote LLM (Llama/Claude)

- Use of Qdrant (server, memory or disk) as a vector store

- A LangGraph as follows:

    <img src="graph.png" width="150"/>

And adding:

- Support for a meta-graph of document relationships to aid retrieval

- Support for keywords in addition to titles for chunk lookup

## Getting started

### Configuration

Within a `.env.development` file (`.env` for production), specify values for the following, according to the stated constraints:

| Variable | Description | Required | Default |
| --- | --- | --- | --- |
| MAX_RETRIES | Number of times to retry the chat API if it is not responsive | Yes | 3 |
| QDRANT_PATH | On-disk or remote location to persist vector store collections | No | - |
| EMBEDDINGS_MODEL_NAME | Model used to vectorise documents in the vector store | Yes | `sentence-transformers/all-mpnet-base-v2` |
| LLM_MODEL_NAME | Name of the model. Models starting with `<provider>.` are assumed to be hosted on Bedrock (AWS). Others are assumed to be hosted by NVIDIA. | Yes | `eu.anthropic.claude-haiku-4-5-20251001-v1:0` (AWS Bedrock) |
| NVIDIA_API_KEY | Key for NVIDIA-hosted models | Yes (if using an NVIDIA model) | - |
| AWS_BEARER_TOKEN_BEDROCK | Key for Bedrock-hosted models | Yes (if using a Bedrock model) | - |
| AWS_REGION | Region for Bedrock-hosted models | Yes (if using a Bedrock model) | `eu-west-2` |
| LLM__EXPLANATION_OF_TERMS | Optional explanatory text to help the LLM interpret retrieved information (e.g., term definitions, context notes). Injected into the system prompt for retrieval tasks. | No | - |

### Recommended models

| Model | Provider | ID |
| --- | --- | --- |
| Llama 3.1 8B instruct (default) | NVIDIA | `meta/llama-3.1-8b-instruct` |
| Claude 4.5 Haiku | AWS Bedrock | `eu.anthropic.claude-haiku-4-5-20251001-v1:0` |

### Local installation

Add the following to the `pyproject.toml` of a consuming project in the monorepo:

```toml
[tool.uv.sources]
chatbot = { path = "../path/to/lib", editable = true }
[dependency-groups]
dev = [
    "chatbot",
    ...
]
```

## Usage

```python
from chatbot.knowledge_based import KnowledgeBase
from chatbot.chatbot import Chatbot
KnowledgeBase().load_web_documents(documents, classes)
Chatbot().retrieve_and_generate(message)
```

## Testing

1. Install dependencies

    ```bash
    uv sync
    ```

2. Run tests: `uv run pytest tests`

## License

This project uses the CC BY-NC-ND 4.0 license (see [LICENSE](LICENSE)).
