import re


class Sanitiser:
    @staticmethod
    def sanitise_name(name: str) -> str:
        """Sanitise a name for use as a collection or vertex identifier.

        Replaces spaces and forward slashes with underscores, converts to
        lowercase, and strips any characters that are not alphanumeric,
        underscores, or hyphens.

        Args:
            name (str): The raw name to sanitise.

        Returns:
            str: The sanitised name.

        """
        return re.sub(
            r"[^a-zA-Z0-9_-]", "", name.replace(" ", "_").replace("/", "_").lower()
        )
