import os
from logging import Logger, getLogger

import boto3
from botocore.exceptions import ClientError
from mypy_boto3_s3.type_defs import HeadObjectOutputTypeDef


class Bucket:
    """Wrapper functions for an S3 bucket

    Args:
        bucket (str): The name of the S3 bucket to use.

    """

    def __init__(self, name: str) -> None:
        self.__logger: Logger = getLogger(__name__)
        self.__name: str = name
        self.__client = boto3.client("s3")

    def download(self, key: str, local_path: str) -> bool:
        """Download a file from S3 if it does not exist locally or is outdated.

        Uses S3 object's LastModified timestamp to determine if the remote file
        is newer than the local copy.

        Args:
            key (str): The S3 object key to download.
            local_path (str): The local file path to save the downloaded file.

        Returns:
            bool: True if the file exists locally (either already present or
                successfully downloaded), False if download failed.

        """
        if self.is_remote_newer(key, local_path):
            try:
                self.__client.download_file(self.__name, key, local_path)
            except ClientError:
                self.__logger.exception(
                    "Failed to download %s from %s", key, self.__name
                )
                raise
        return True

    def is_remote_newer(self, key: str, local_path: str) -> bool:
        """Check if the remote S3 object is newer than the local file.

        Args:
            key (str): The S3 object key.
            local_path (str): The local file path.

        Returns:
            bool: True if local file doesn't exist or remote is newer.

        """
        if not os.path.exists(local_path):
            return True
        try:
            response: HeadObjectOutputTypeDef = self.__client.head_object(
                Bucket=self.__name, Key=key
            )
            return response["LastModified"].timestamp() > os.path.getmtime(local_path)
        except ClientError:
            self.__logger.exception("Failed to get metadata for %s", key)
            raise
