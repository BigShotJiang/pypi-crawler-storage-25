import logging
import os
from collections.abc import Callable
from typing import Generic, TypeVar

from duckdb import DuckDBPyConnection
import duckdb

V = TypeVar("V")


class Graph(Generic[V]):
    """A graph backed by a DuckDB parquet file.

    Args:
        duckdb_path (str): Path to the parquet file, local or S3.
        deserialiser (Callable[[str], V]): Converts stored strings
            back to vertex type V.
        serialiser (Callable[[V], str]): Converts vertex type V to a
            string for storage. Defaults to str.
        region (str): AWS region for S3 access. Defaults to 'eu-west-2'.

    """

    def __init__(
        self,
        duckdb_path: str,
        deserialiser: Callable[[str], V],
        serialiser: Callable[[V], str] = str,
        region: str = "eu-west-2",
    ):
        self.__logger: logging.Logger = logging.getLogger()
        self.__duckdb: DuckDBPyConnection = duckdb.connect()
        self.__duckdb_path: str = str(duckdb_path)
        if "s3" in self.__duckdb_path:
            self.__duckdb.execute(
                f"INSTALL httpfs; LOAD httpfs; SET s3_region = '{region}';"
            )
            if "AWS_ACCESS_KEY_ID" not in os.environ:
                self.__duckdb.execute(
                    "CREATE OR REPLACE SECRET (TYPE s3, PROVIDER credential_chain);"
                )
        self.__duckdb.execute(
            "CREATE TABLE adjacency (title VARCHAR PRIMARY KEY, targets VARCHAR[])"
        )
        self.__cursor: DuckDBPyConnection = self.__duckdb.cursor()
        self.__unsaved: bool = False
        self.__deserialiser: Callable[[str], V] = deserialiser
        self.__serialiser: Callable[[V], str] = serialiser
        self._load()

    def _run(self, query: str, params: object = None) -> DuckDBPyConnection:
        return self.__cursor.execute(query.replace("path", self.__duckdb_path), params)

    def add_edges(self, source: V, targets: list[V]) -> None:
        """Add or replace edges from a source vertex to target vertices.

        Args:
            source (V): The source vertex.
            targets (list[V]): The target vertices to connect from source.

        """
        serialised_source: str = self.__serialiser(source)
        self._run("DELETE FROM adjacency WHERE title = ?", (serialised_source,))
        self._run(
            "INSERT INTO adjacency VALUES (?, ?)",
            (serialised_source, [self.__serialiser(target) for target in targets]),
        )
        self.__unsaved = True

    def get_vertices(self) -> list[V]:
        """Return all vertices in the graph.

        Returns:
            list[V]: All source vertices.

        """
        return [
            self.__deserialiser(row[0])
            for row in self._run("SELECT title FROM adjacency").fetchall()
        ]

    def has_vertex(self, source: V) -> bool:
        """Check whether a vertex exists in the graph.

        Args:
            source (V): The vertex to look up.

        Returns:
            bool: True if the vertex exists, False otherwise.

        """
        return (
            self._run(
                "SELECT 1 FROM adjacency WHERE title = ?",
                (self.__serialiser(source),),
            ).fetchone()
            is not None
        )

    def get_connected_vertices(self, source: V) -> list[V]:
        """Return the vertices connected to a given source vertex.

        Args:
            source (V): The source vertex to look up.

        Returns:
            list[V]: The connected target vertices.

        """
        row: tuple[list[str]] | None = self._run(
            "SELECT targets FROM adjacency WHERE title = ?",
            (self.__serialiser(source),),
        ).fetchone()
        if row is None:
            raise KeyError(source)
        return [self.__deserialiser(target) for target in row[0]]

    def _load(self) -> bool:
        try:
            if "s3" in self.__duckdb_path:
                self._run("SELECT 1 FROM 'path' LIMIT 1")
            elif not os.path.exists(self.__duckdb_path):
                return False
        except duckdb.Error:
            self.__logger.warning("no existing adjacency database reachable")
            return False
        self._run("DELETE FROM adjacency")
        self._run("INSERT INTO adjacency SELECT * FROM 'path'")
        return True

    def save(self) -> bool:
        """Persist the graph to the configured parquet file.

        Returns:
            bool: True if saved, False if there were no unsaved changes.

        """
        if not self.__unsaved:
            return False
        self._run("COPY adjacency TO 'path' (FORMAT PARQUET)")
        self.__unsaved = False
        return True

    @staticmethod
    def read_adjacency(path: str) -> dict[str, list[str]]:
        """Read a TSV-like adjacency list file into a dictionary.

        Args:
            path (str): Path to the adjacency list file where each line contains
                a source URL and tab-separated target URLs (space-delimited).

        Returns:
            dict[str, list[str]]: A dictionary mapping each source URL to its
                list of target URLs. Returns an empty dictionary if the file
                does not exist.

        """
        adj: dict[str, list[str]] = {}
        if not os.path.exists(path):
            return adj
        with open(path, encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) != 2:
                    continue
                src, targets = parts
                adj[src] = targets.split(" ") if targets else []
        return adj
