from pydantic import BaseModel
from langgraph.graph import MessagesState
from langchain_core.documents import Document


class MessagesStateWithContext(MessagesState):
    context: list[Document]


class QuestionContextAnswer(BaseModel):
    question: str
    context: list[Document]
    answer: str


class QA(BaseModel):
    question: str
    answer: str

    def __str__(self) -> str:
        return f"Question: {self.question}\nAnswer: {self.answer}"


class QADocument(BaseModel):
    title: str
    qas: list[QA]


class QAEvaluation(QA):
    rag: bool


class Page(BaseModel):
    url: str
    title: str
    keywords: list[str] = []
    error: str | None = None
