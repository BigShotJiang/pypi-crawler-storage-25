from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
import os


class LLMSettings(BaseModel):
    MAX_RETRIES: int = 3
    INITIAL_SALUTATION: str = "Hello. Thank you for your query."
    FOLLOW_UP_SALUTATION: str = "Thank you for all your queries."
    SYSTEM_PROMPT_RESPOND: str = "If the user asks a question relevant to the tool available, call this tool. If the user does not ask a question relevant to the tool available, answer using three sentences maximum, keep the response concise and encourage the user to ask a question about genetic testing in the NHS. Always call the tool/function available 'GeNotes'"
    NEGATIVE_RESPONSE: str = (
        "I don't have that information right now, but I am learning all the time"
    )
    EXPLANATION_OF_TERMS: str | None = None

    @property
    def SYSTEM_PROMPT_RETRIEVE(self) -> str:
        return f"You are an assistant for question-answering tasks. Use the following information to answer the question. {f'To assist you in interpreting the information, please note the following: "{self.EXPLANATION_OF_TERMS}". ' if self.EXPLANATION_OF_TERMS is not None else ''}If the information does not contain the answer to the question, respond with only the following words: '{self.NEGATIVE_RESPONSE}'. If the information does contain the answer, use three sentences maximum and keep the response concise, being sure to always use British spelling. Always call the information 'the information I have available'."


class Settings(BaseSettings):
    LLM: LLMSettings = Field(default_factory=LLMSettings)
    QDRANT_PATH: str | None = Field(default=None)
    EMBEDDINGS_MODEL_NAME: str = "sentence-transformers/all-mpnet-base-v2"
    LLM_MODEL_NAME: str = "eu.anthropic.claude-haiku-4-5-20251001-v1:0"
    NVIDIA_API_KEY: str | None = Field(default=None)
    AWS_BEARER_TOKEN_BEDROCK: str | None = Field(default=None)
    AWS_REGION: str = "eu-west-2"
    DUCKDB_PATH: str = "adjacency.parquet"
    SIMILARITY_SCORE_TOLERANCE: float = 0.1

    model_config = SettingsConfigDict(
        env_file=(
            ".env"
            if os.getenv("ENV") == "prod"
            else f".env.{os.getenv('ENV', 'development')}"
        ),
        extra="allow",
        env_nested_delimiter="__",
    )
