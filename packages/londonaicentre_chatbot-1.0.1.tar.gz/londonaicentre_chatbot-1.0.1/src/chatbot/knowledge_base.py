import hashlib
import hmac
import json
import logging

import bs4
from langchain_community.document_loaders import WebBaseLoader
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_qdrant import QdrantVectorStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from qdrant_client import QdrantClient
from qdrant_client.http.models import Distance, VectorParams
from qdrant_client.http.models import Filter, FieldCondition, MatchValue
from qdrant_client.conversions.common_types import CollectionInfo
from langchain_core.documents import Document

from chatbot.types import (
    Page,
    QADocument,
)
from chatbot.utils.graph import Graph
from chatbot.utils.sanitise import Sanitiser


class KnowledgeBase:
    def __init__(
        self,
        embeddings_model_name: str,
        refresh_embeddings_on_start: bool = False,
        qdrant_path: str | None = None,
        qdrant_url: str | None = None,
        duckdb_path: str | None = None,
        similarity_score_tolerance: float = 0.1,
    ) -> None:
        self.__logger: logging.Logger = logging.getLogger()
        self.__embeddings: HuggingFaceEmbeddings = HuggingFaceEmbeddings(
            model_name=embeddings_model_name
        )
        self.__refresh_embeddings_on_start: bool = refresh_embeddings_on_start
        self.__similarity_score_tolerance: float = similarity_score_tolerance
        self.__client: QdrantClient = (
            QdrantClient(path=qdrant_path)
            if qdrant_path is not None
            else QdrantClient(url=qdrant_url, prefer_grpc=True)
            if qdrant_url is not None
            else QdrantClient(":memory:")
        )
        self.__graph_client: Graph[str] = Graph[str](
            str(duckdb_path), str, Sanitiser.sanitise_name
        )

    def _get_collections(self) -> list[str]:
        return [
            collection.name
            for collection in self.__client.get_collections().collections
        ]

    def _get_collection(self, name: str) -> CollectionInfo:
        return self.__client.get_collection(Sanitiser.sanitise_name(name))

    def _collection_exists(self, name: str) -> bool:
        return Sanitiser.sanitise_name(name) in self._get_collections()

    def _non_empty_collection_exists(self, name: str) -> bool:
        return (
            self._collection_exists(name)
            and (self._get_collection(name).points_count or 0) > 0
        )

    def _collection_exists_with_content(self, name: str, content: str) -> bool:
        return self._collection_exists(name) and bool(
            len(
                self.__client.scroll(
                    collection_name=Sanitiser.sanitise_name(name),
                    scroll_filter=Filter(
                        must=[
                            FieldCondition(
                                key="page_content", match=MatchValue(value=content)
                            )
                        ]
                    ),
                    limit=1,
                )[0]
            )
        )

    def _store_chunks(
        self,
        collection_name: str,
        all_chunks: list[Document],
        raw_page: Document | None = None,
    ) -> bool:
        if raw_page is None:
            raw_page = Document(collection_name)
        collection_name = Sanitiser.sanitise_name(collection_name)
        if not self._collection_exists(collection_name):
            self.__client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(size=768, distance=Distance.COSINE),
                metadata={
                    "raw_page_hash": hashlib.sha256(
                        raw_page.page_content.encode()
                    ).hexdigest()
                },
            )
        QdrantVectorStore(
            client=self.__client,
            collection_name=collection_name,
            embedding=self.__embeddings,
        ).add_documents(documents=all_chunks)
        return True

    def _get_documents(self, collection_name: str) -> QdrantVectorStore:
        return QdrantVectorStore(
            client=self.__client,
            collection_name=Sanitiser.sanitise_name(collection_name),
            embedding=self.__embeddings,
        )

    def _split_document(self, document: Document) -> list[Document]:
        """
        Split a document into chunks of size and overlap specified,
            respecting natural breaks (e.g. paragraphs)

        Args:
            docs (Document): document to split

        Returns:
            list[Document]: document chunks (as set of new documents)
        """
        text_splitter: RecursiveCharacterTextSplitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            add_start_index=True,
        )
        return text_splitter.split_documents([document])

    def load_web_documents(
        self,
        path: str,
        classes: tuple[str, ...],
        adjacency: dict[str, list[str]] = {},
        keyword_repo: list[Page] | None = None,
    ) -> bool:
        """Load web documents from a JSON file of titles and URLs.

        Args:
            path (str): Path to a JSON file mapping document titles to URLs.
            classes (tuple[str, ...]): HTML classes from which to extract
                page content.
            adjacency (dict[str, list[str]]): URL adjacency mapping for
                graph construction. Defaults to an empty dict.
            keyword_repo (list[Page] | None): Optional keyword metadata for
                title-augmented matching. Defaults to None.

        Returns:
            bool: True on successful loading.

        """
        with open(path) as documents:
            document_list: dict[str, str] = json.load(documents)
        return self.load_web_documents_from_list(
            document_list, classes, adjacency, keyword_repo
        )

    def _store_title(self, title: str) -> bool:
        if not self._collection_exists_with_content("titles", title):
            return self._store_chunks("titles", [Document(title)])
        return False

    def _store_title_and_keywords(self, title_and_keywords: str) -> bool:
        if not self._collection_exists_with_content(
            "titles-and-keywords", title_and_keywords
        ):
            return self._store_chunks(
                "titles-and-keywords", [Document(title_and_keywords)]
            )
        return False

    def _store_chunks_with_title(self, page: Document, title: str) -> bool:
        return self._store_chunks(
            title,
            [
                Document(
                    chunk.page_content,
                    metadata=chunk.metadata | {"title": title},
                )
                for chunk in self._split_document(page)
            ],  #  record unsanitised title in each chunk
            page,
        )

    def load_web_documents_from_list(
        self,
        document_list: dict[str, str],
        classes: tuple[str, ...],
        adjacency: dict[str, list[str]] = {},
        keyword_repo: list[Page] | None = None,
    ) -> bool:
        """
        Scrape and store guideline content from the web

        Args:
            path (str): path to a json file of the form `{<title>:<url>,...}`
                pointing to the web pages to retrieve
            classes (tuple[str, ...]): the HTML classes on the target pages from
                which to extract content
        """
        url_to_title: dict[str, str] = {}
        if len(adjacency.keys()):
            url_to_title = {url: title for title, url in document_list.items()}
        for title, url in document_list.items():
            # add for initial lookup
            self._store_title(title)

            # add for initial lookup with title and keywords (optional)
            if keyword_repo and (
                keywords_entry := next(
                    filter(lambda keyword: keyword.title == title, keyword_repo),
                    None,
                )
            ):
                title_and_keywords: str = (
                    f"{title} - {' '.join(keywords_entry.keywords)}"
                )
                self._store_title_and_keywords(title_and_keywords)

            # add for context lookup
            if (
                not self._non_empty_collection_exists(title)
                or self.__refresh_embeddings_on_start
            ):
                self.__logger.info(f"processing document: {title}")
                loader: WebBaseLoader = WebBaseLoader(
                    web_paths=(url,),
                    bs_kwargs=dict(parse_only=bs4.SoupStrainer(class_=classes)),
                )
                page: Document = loader.load()[0]
                if self._non_empty_collection_exists(title):
                    if (
                        metadata := self._get_collection(title).config.metadata
                    ) and "raw_page_hash" in metadata.keys():
                        if not hmac.compare_digest(
                            metadata["raw_page_hash"],
                            hashlib.sha256(page.page_content.encode()).hexdigest(),
                        ):
                            self.__client.delete_collection(
                                Sanitiser.sanitise_name(title)
                            )
                        else:
                            continue
                    else:
                        raise ValueError(
                            f"non-empty collection {title} has no page hash"
                        )
                else:
                    self._store_chunks_with_title(page, title)
            if len(adjacency.keys()) and not self.__graph_client.has_vertex(title):
                self.__graph_client.add_edges(
                    title,
                    [
                        url_to_title[target]
                        for target in adjacency.get(url, [])
                        if target in url_to_title.keys()
                    ],
                )
        self.__graph_client.save()
        return True

    def add_information_source(self, title: str, content: str, source: str) -> bool:
        return (
            self._store_title(title)
            and self._store_title_and_keywords(title)
            and self._store_chunks_with_title(
                Document(page_content=content, metadata={"source": source}), title
            )
        )

    async def get_matching_page_title(
        self, query: str, links: bool = False, keywords: bool = False
    ) -> list[str]:
        """Find the most similar page title(s) for a given query.

        Args:
            query (str): The search query.
            links (bool): Whether to include adjacent page titles via the
                graph. Defaults to False.
            keywords (bool): Whether to match against keyword-augmented
                titles. Defaults to False.

        Returns:
            list[str]: Matching page titles.

        """
        matching_documents: list[tuple[Document, float]] = await self._get_documents(
            "titles-and-keywords" if keywords else "titles"
        ).asimilarity_search_with_score(query)
        titles: list[str] = [
            matching_document[0].page_content.split(" - ")[0]
            for matching_document in matching_documents
            if matching_document[1]
            >= matching_documents[0][1] - self.__similarity_score_tolerance
        ]  # normalise in the presence of keywords
        self.__logger.debug(f"Matching documents:\n{titles}\n\n")
        return (
            list(
                dict.fromkeys(
                    titles
                    + [
                        connected_title
                        for connected_titles in [
                            self.__graph_client.get_connected_vertices(
                                adjacency_input_title
                            )
                            for adjacency_input_title in titles
                            if self.__graph_client.has_vertex(adjacency_input_title)
                        ]
                        for connected_title in connected_titles
                    ]
                )
            )
            if links
            else [titles[0]]
        )

    async def retrieve_chunks(self, query: str, titles: list[str]) -> list[Document]:
        """Retrieve similar document chunks for a query within given titles.

        Args:
            query (str): The search query.
            titles (list[str]): Page titles whose collections to search.

        Returns:
            list[Document]: Matching document chunks.

        """
        if len(self._get_collections()) > 1:
            return [
                chunk
                for chunks in [
                    (await self._get_documents(title).asimilarity_search(query))
                    for title in titles
                ]
                for chunk in chunks
            ]
        else:
            return await self._get_documents("default").asimilarity_search(query)

    def load_qa_documents(self, path: str, single_store: bool = False) -> bool:
        """Load QA-format documents from a JSON file into the vector store.

        Args:
            path (str): Path to the JSON file containing QA documents.
            single_store (bool): Whether to store all documents in a single
                'default' collection rather than per-title collections.
                Defaults to False.

        Returns:
            bool: True on successful loading.

        """
        with open(path) as documents:
            document_list: list[QADocument] = [
                QADocument.model_validate(document)
                for document in json.loads(documents.read())
            ]
        for document in document_list:
            if not single_store:
                self._store_chunks("titles", [Document(document.title)])
            self._store_chunks(
                document.title if not single_store else "default",
                [Document(str(QA)) for QA in document.qas],
            )
        return True
