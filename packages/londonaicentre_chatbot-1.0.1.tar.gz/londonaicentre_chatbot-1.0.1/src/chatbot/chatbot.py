import asyncio
import logging
import os
import re
from typing import Any
import uuid

from langchain_aws import ChatBedrockConverse
from langchain_core.documents import Document
from langchain_core.language_models.base import LanguageModelInput
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.runnables import Runnable
from langchain_core.tools import tool
from langchain_nvidia_ai_endpoints import ChatNVIDIA
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, MessagesState, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import ToolNode, tools_condition

from chatbot.knowledge_base import KnowledgeBase
from chatbot.settings import Settings
from chatbot.types import (
    QA,
    MessagesStateWithContext,
    QAEvaluation,
    QuestionContextAnswer,
)


class Chatbot:
    def __init__(self) -> None:
        self.__logger: logging.Logger = logging.getLogger()
        self.__config: Settings = Settings()
        kwargs: dict[str, Any] = {
            "embeddings_model_name": self.__config.EMBEDDINGS_MODEL_NAME,
            "duckdb_path": self.__config.DUCKDB_PATH,
            "similarity_score_tolerance": self.__config.SIMILARITY_SCORE_TOLERANCE,
        }
        if self.__config.QDRANT_PATH and "http" in self.__config.QDRANT_PATH:
            kwargs["qdrant_url"] = self.__config.QDRANT_PATH
        elif self.__config.QDRANT_PATH:
            kwargs["qdrant_path"] = self.__config.QDRANT_PATH
        self.__knowledge_base: KnowledgeBase = KnowledgeBase(**kwargs)
        self._init_llm()
        self.__memory_saver: MemorySaver = MemorySaver()

    def _init_llm(self) -> None:
        self.__llm: BaseChatModel
        if re.match(r"^[a-z0-9]+\.", self.__config.LLM_MODEL_NAME):  # bedrock
            os.environ["AWS_BEARER_TOKEN_BEDROCK"] = (
                self.__config.AWS_BEARER_TOKEN_BEDROCK or ""
            )
            os.environ["AWS_REGION"] = self.__config.AWS_REGION
            self.__llm = ChatBedrockConverse(
                model=self.__config.LLM_MODEL_NAME, temperature=0.0
            )
        else:  # nvidia
            os.environ["NVIDIA_API_KEY"] = self.__config.NVIDIA_API_KEY or ""
            self.__llm = ChatNVIDIA(model=self.__config.LLM_MODEL_NAME, temperature=0.0)

    async def retrieve_and_generate(
        self,
        message: str,
        chat_id: str | None = None,
        use_adjacency: bool = False,
        use_keywords: bool = False,
        use_query_rewriting: bool = True,
        dynamic_prompt_content: str | None = None,
    ) -> str:
        """Retrieve relevant documents and generate an answer for a message.

        Args:
            message (str): The user query to answer.
            chat_id (str | None): Conversation thread identifier. Defaults to
                None, in which case a new UUID is generated.
            use_adjacency (bool): Whether to include linked pages in
                retrieval. Defaults to False.
            use_keywords (bool): Whether to use keyword-augmented title
                matching. Defaults to False.
            use_query_rewriting (bool): Whether to allow the LLM to rewrite
                the query for retrieval. Defaults to True.
            dynamic_prompt_content (str | None): Additional content appended
                to the system prompt. Defaults to None.

        Returns:
            str: The generated answer string.

        """
        return (
            await self._retrieve_and_generate(
                message,
                chat_id or str(uuid.uuid4()),
                use_adjacency,
                use_keywords,
                use_query_rewriting,
                dynamic_prompt_content,
            )
        )[0].answer

    async def retrieve_and_generate_with_context(
        self,
        message: str,
        chat_id: str | None = None,
        use_adjacency: bool = False,
        use_keywords: bool = False,
        use_query_rewriting: bool = True,
        dynamic_prompt_content: str | None = None,
    ) -> QuestionContextAnswer:
        """Retrieve relevant documents and generate an answer with context.

        Args:
            message (str): The user query to answer.
            chat_id (str | None): Conversation thread identifier. Defaults to
                None, in which case a new UUID is generated.
            use_adjacency (bool): Whether to include linked pages in
                retrieval. Defaults to False.
            use_keywords (bool): Whether to use keyword-augmented title
                matching. Defaults to False.
            use_query_rewriting (bool): Whether to allow the LLM to rewrite
                the query for retrieval. Defaults to True.
            dynamic_prompt_content (str | None): Additional content appended
                to the system prompt. Defaults to None.

        Returns:
            QuestionContextAnswer: The question, retrieved context documents,
                and generated answer.

        """
        return (
            await self._retrieve_and_generate(
                message,
                chat_id or str(uuid.uuid4()),
                use_adjacency,
                use_keywords,
                use_query_rewriting,
                dynamic_prompt_content,
            )
        )[0]

    def _build_system_prompt(
        self, tool_messages: list[ToolMessage], dynamic_prompt_content: str | None
    ) -> str:
        docs_content: str = "\n\n".join(str(doc.content) for doc in tool_messages)
        prompt: str = " ".join(
            filter(
                None, [self.__config.LLM.SYSTEM_PROMPT_RETRIEVE, dynamic_prompt_content]
            )
        )
        return f"{prompt}\n\n{docs_content}"

    async def _retrieve_and_generate(
        self,
        message: str,
        chat_id: str,
        use_adjacency: bool = False,
        use_keywords: bool = False,
        use_query_rewriting: bool = True,
        dynamic_prompt_content: str | None = None,
    ) -> tuple[QuestionContextAnswer, int]:
        """
        Retrieve documents under a two-step process:
        (1) initial lookup: determine similarity of query
            with document titles, identifying single matching
                document
        (2) context lookup: determine similarity of query
            with chunks in resulting document, identifying
                multiple matching chunks
        """

        @tool(response_format="content_and_artifact")
        async def retrieve(query: str) -> tuple[str, list[Document]]:
            """Retrieve information related to a query."""
            effective_query: str = query if use_query_rewriting else message
            retrieved_chunks: list[
                Document
            ] = await self.__knowledge_base.retrieve_chunks(
                effective_query,
                await self.__knowledge_base.get_matching_page_title(
                    effective_query, use_adjacency, use_keywords
                ),
            )
            serialized: str = "\n\n".join(
                (f"Source: {chunk.metadata}\nContent: {chunk.page_content}")
                for chunk in retrieved_chunks
            )
            return serialized, retrieved_chunks

        async def query_or_respond(
            state: MessagesStateWithContext,
        ) -> dict[str, list[BaseMessage]]:
            llm_with_tools: Runnable[LanguageModelInput, BaseMessage] = (
                self.__llm.bind_tools([retrieve])
            )
            for attempt in range(int(self.__config.LLM.MAX_RETRIES)):
                try:
                    response: BaseMessage = await llm_with_tools.ainvoke(
                        state["messages"], {"configurable": {"thread_id": chat_id}}
                    )
                    return {"messages": [response]}
                except Exception as e:  # only generic exception thrown
                    if "429" in str(
                        e
                    ):  # no apparent consistent structure to exception content
                        self.__logger.warning("too many requests, retrying...")
                        await asyncio.sleep(
                            2**attempt
                        )  # best effort, as retry-after not available
                    else:
                        raise
            raise Exception("generation failed")

        async def generate(
            state: MessagesState,
        ) -> dict[str, list[BaseMessage] | list[Document]]:
            recent_tool_messages: list[ToolMessage] = []
            for message in reversed(state["messages"]):
                if message.type == "tool":
                    recent_tool_messages.append(message)  # ty: ignore
                else:
                    break
            tool_messages: list[ToolMessage] = list(reversed(recent_tool_messages))
            system_message_content: str = self._build_system_prompt(
                tool_messages, dynamic_prompt_content
            )
            conversation_messages: list[BaseMessage] = [
                message
                for message in state["messages"]
                if message.type in ("human")
                or (message.type == "ai" and not message.tool_calls)
            ]
            prompt: list[BaseMessage] = [
                SystemMessage(system_message_content)
            ] + conversation_messages
            for attempt in range(int(self.__config.LLM.MAX_RETRIES)):
                try:
                    response: BaseMessage = await self.__llm.ainvoke(
                        prompt, {"configurable": {"thread_id": chat_id}}
                    )
                    context: list[Document] = []
                    for tool_message in tool_messages:
                        context.extend(tool_message.artifact)
                    return {"messages": [response], "context": context}
                except Exception as e:  # only generic exception thrown
                    if "429" in str(e):
                        self.__logger.warning("too many requests, retrying...")
                        await asyncio.sleep(2**attempt)
                    else:
                        raise
            raise Exception("generation failed")

        graph_builder: StateGraph[MessagesState, None, MessagesState, MessagesState] = (
            StateGraph(state_schema=MessagesState, input_schema=MessagesState)  # ty: ignore
        )
        graph_builder.add_node(query_or_respond)
        graph_builder.add_node(ToolNode([retrieve]))
        graph_builder.add_node(generate)
        graph_builder.set_entry_point("query_or_respond")
        graph_builder.add_conditional_edges(
            "query_or_respond",
            tools_condition,
            {END: END, "tools": "tools"},
        )
        graph_builder.add_edge("tools", "generate")
        graph_builder.add_edge("generate", END)
        graph: CompiledStateGraph[MessagesState, None, MessagesState, MessagesState] = (
            graph_builder.compile(checkpointer=self.__memory_saver)
        )

        context: list[Document] = []
        async for step in graph.astream(
            MessagesState(
                messages=[
                    SystemMessage(content=self.__config.LLM.SYSTEM_PROMPT_RESPOND),
                    HumanMessage(content=message),
                ]
            ),
            stream_mode="values",
            config={"configurable": {"thread_id": chat_id}},
        ):
            self.__logger.debug(step)
            response: BaseMessage = step["messages"][-1]
            if (
                "context" in step.keys()
                and self.__config.LLM.NEGATIVE_RESPONSE not in response.content
            ):
                context = step["context"]
        self.__logger.debug(
            f"Question:\n{message}\n\nContext:\n{context}\n\nAnswer:{response.content}"
        )
        return (
            QuestionContextAnswer(
                question=message, context=context, answer=str(response.content)
            ),
            len(step["messages"]),
        )

    async def evaluate(self, messages: list[str]) -> list[QA]:
        """Get responses to a list of queries for evaluation,
            returning as QA pairs + whether RAG was used.

        Args:
            messages (list[str]): The user queries to format.

        Returns:
            list[QA]: Evaluation results containing each question, answer,
                and whether RAG was used.

        """
        output: list[QA] = []
        for message in messages:
            response_and_count = await self._retrieve_and_generate(
                message, str(uuid.uuid4())
            )
            output.append(
                QAEvaluation(
                    question=message,
                    answer=response_and_count[0].answer,
                    rag=True if response_and_count[1] > 2 else False,
                )
            )
        return output
