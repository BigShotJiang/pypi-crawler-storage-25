from __future__ import annotations

from typing import Optional

import click

from securedeploy.client.errors import CliError
from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.output import echo_cli_result


@cli.group()
def workspaces() -> None:
    """Manage workspaces."""


@workspaces.command("list")
@click.pass_context
@handle_errors
def workspaces_list(ctx: click.Context) -> None:
    echo_cli_result(ctx, ctx.obj.workspaces.list())


@workspaces.command("set-default")
@click.argument("slug", required=False)
@click.pass_context
@handle_errors
def workspaces_set_default(ctx: click.Context, slug: Optional[str]) -> None:
    if not slug:
        workspaces = ctx.obj.workspaces.list()
        if not workspaces:
            raise CliError(
                "No workspaces found; create one first.",
                error="cli_usage",
                exit_code=2,
            )
        slug = str(workspaces[0].get("slug") or "")
        if not slug:
            raise CliError(
                "First workspace in list has no slug; pass slug explicitly."
            )
    ctx.obj.workspaces.set_default(slug)
    click.echo(f"Default workspace set to {slug!r}")


@workspaces.command("get")
@click.argument("slug", required=False)
@click.pass_context
@handle_errors
def workspaces_get(ctx: click.Context, slug: Optional[str]) -> None:
    if slug:
        ws = ctx.obj.workspaces.get(slug)
    else:
        ws = ctx.obj.workspaces.get_default()
    echo_cli_result(ctx, ws.data)


@workspaces.command("create")
@click.option("--name", default=None, help="Workspace display name.")
@click.option("--slug", required=True, help="Workspace slug.")
@click.pass_context
@handle_errors
def workspaces_create(ctx: click.Context, name: Optional[str], slug: str) -> None:
    ws = ctx.obj.workspaces.create(slug=slug, name=name)
    echo_cli_result(ctx, ws.data)
