from __future__ import annotations

from typing import Optional

import click

from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.option_helps import _WORKSPACE_SLUG_OPTION_HELP
from securedeploy.cli.output import echo_cli_result


@cli.group()
def applications() -> None:
    """Manage applications."""


@applications.command("list")
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_list(ctx: click.Context, workspace: Optional[str]) -> None:
    echo_cli_result(ctx, ctx.obj.applications.list(workspace=workspace))


@applications.command("get")
@click.argument("slug", required=False)
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_get(
    ctx: click.Context, slug: Optional[str], workspace: Optional[str]
) -> None:
    app = ctx.obj.applications.get(slug, workspace=workspace)
    echo_cli_result(ctx, app.data)


@applications.command("create")
@click.option("--name", default=None, help="Application display name.")
@click.option("--slug", required=True, help="Application slug.")
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_create(
    ctx: click.Context,
    name: Optional[str],
    slug: str,
    workspace: Optional[str],
) -> None:
    app = ctx.obj.applications.create(name=name, slug=slug, workspace=workspace)
    echo_cli_result(ctx, app.data)


@applications.command("set-default")
@click.argument("slug")
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_set_default(
    ctx: click.Context, slug: str, workspace: Optional[str]
) -> None:
    ctx.obj.applications.set_default(slug, workspace=workspace)
    click.echo(f"Default application set to {slug!r}")
