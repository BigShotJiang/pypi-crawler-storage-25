from __future__ import annotations

_WORKSPACE_SLUG_OPTION_HELP = "Workspace slug (default: config)."
_APPLICATION_SLUG_OPTION_HELP = "Application slug (default: config)."
