from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from securedeploy.client.errors import (
    ApplicationNotFoundError,
    InvalidApiResponseError,
    ResourceNotFoundError,
    ValidationError,
)
from securedeploy.client.schemas import (
    ApplicationResource,
    as_application_resource,
    coerce_application_list,
)
from securedeploy.config.document import (
    APPLICATION,
    APPLICATION_WORKSPACE,
    WORKSPACE,
    profile_default,
)

if TYPE_CHECKING:
    from securedeploy.client.core import SecureDeploy


class _Applications:
    def __init__(self, client: SecureDeploy) -> None:
        self._client = client

    def list(self, *, workspace: Optional[str] = None) -> list[ApplicationResource]:
        ws = workspace or self._client._default_workspace_slug()
        raw = self._client._request("GET", f"/v1/workspaces/{ws}/applications")
        return coerce_application_list(raw)

    def get(
        self,
        slug: Optional[str] = None,
        workspace: Optional[str] = None,
    ) -> Application:
        if slug is None:
            slug = self._client._default_application_slug()
            ws = (
                self._client._default_application_workspace_slug()
                or self._client._default_workspace_slug()
            )
        else:
            ws = workspace or self._client._default_workspace_slug()
        data = self._client._request("GET", f"/v1/workspaces/{ws}/applications/{slug}")
        payload = data if isinstance(data, dict) else {}
        return Application(self._client, ws, slug, payload)

    def create(
        self,
        slug: str,
        name: Optional[str] = None,
        workspace: Optional[str] = None,
    ) -> Application:
        app_slug = slug.strip()
        if not app_slug:
            raise ValidationError(
                "applications.create requires a non-empty slug",
                error="missing_slug",
            )
        ws = workspace or self._client._default_workspace_slug()
        body: dict[str, Any] = {"slug": slug}
        if name is not None:
            n = name.strip()
            if n:
                body["name"] = n
        data = self._client._request(
            "POST", f"/v1/workspaces/{ws}/applications", json=body
        )
        if not isinstance(data, dict):
            raise InvalidApiResponseError(
                "Unexpected API response for application create"
            )
        app_slug = str(data.get("slug") or slug or "")
        if not app_slug:
            raise InvalidApiResponseError("API did not return an application slug")
        return Application(self._client, ws, app_slug, data)

    def set_default(
        self,
        slug: str,
        *,
        workspace: Optional[str] = None,
    ) -> None:
        ws = workspace or self._client._default_workspace_slug()
        try:
            self.get(slug, workspace=ws)
        except ResourceNotFoundError as exc:
            raise ApplicationNotFoundError(slug=slug, workspace=ws) from exc
        prof = profile_default(self._client._config.config)
        prof[APPLICATION] = slug
        if not prof.get(WORKSPACE) or ws == prof.get(WORKSPACE):
            prof[WORKSPACE] = ws
            prof.pop(APPLICATION_WORKSPACE, None)
        elif prof.get(WORKSPACE) != ws:
            prof[APPLICATION_WORKSPACE] = ws

        self._client._save_config()


class Application:
    # TODO: Field accessors duplicate Workspace; extract a small shared resource-view helper.

    def __init__(
        self,
        client: SecureDeploy,
        workspace_slug: str,
        slug: str,
        data: dict[str, Any],
    ) -> None:
        self._client = client
        self.workspace_slug = workspace_slug
        self.slug = slug
        self._data = as_application_resource(data if isinstance(data, dict) else {})

    @property
    def data(self) -> ApplicationResource:
        return self._data

    @property
    def id(self) -> str | None:
        v = self._data.get("id")
        return str(v) if v is not None else None

    @property
    def type(self) -> str | None:
        v = self._data.get("type")
        return str(v) if v is not None else None

    @property
    def created_at(self) -> str | None:
        v = self._data.get("created_at")
        return str(v) if v is not None else None

    @property
    def updated_at(self) -> str | None:
        v = self._data.get("updated_at")
        return str(v) if v is not None else None

    @property
    def created_by(self) -> str | None:
        v = self._data.get("created_by")
        return str(v) if v is not None else None

    @property
    def name(self) -> str | None:
        if "name" not in self._data:
            return None
        v = self._data["name"]
        return None if v is None else str(v)


class _ScopedApplications:
    def __init__(self, client: SecureDeploy, workspace_slug: str) -> None:
        self._client = client
        self._workspace = workspace_slug

    def list(self) -> list[ApplicationResource]:
        return self._client.applications.list(workspace=self._workspace)

    def get(self, slug: Optional[str] = None) -> Application:
        return self._client.applications.get(slug, workspace=self._workspace)

    def create(
        self,
        slug: str,
        name: Optional[str] = None,
    ) -> Application:
        return self._client.applications.create(
            slug=slug, name=name, workspace=self._workspace
        )

    def set_default(self, slug: str) -> None:
        self._client.applications.set_default(slug, workspace=self._workspace)
