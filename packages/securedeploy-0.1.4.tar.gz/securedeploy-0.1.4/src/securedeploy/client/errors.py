from __future__ import annotations

from typing import Any


class SecureDeployError(Exception):
    """Base exception with ``error`` and optional ``description``."""

    __slots__ = ("error", "description")

    def __init__(
        self,
        *,
        error: str,
        description: str | None = None,
    ) -> None:
        self.error = error
        self.description = description
        super().__init__(description if description is not None else "")

    def __str__(self) -> str:
        if self.description is not None:
            return self.description
        return self.error

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.error,
            "description": self.description,
        }


class HttpApiError(SecureDeployError):
    """HTTP error response from the SecureDeploy API."""

    __slots__ = (
        "url",
        "method",
        "request_content_type",
        "request_body",
        "status_code",
        "response_content_type",
        "response_body",
    )

    def __init__(
        self,
        *,
        error: str,
        description: str | None = None,
        url: str,
        method: str,
        request_content_type: str | None,
        request_body: str,
        status_code: int,
        response_content_type: str | None,
        response_body: str,
    ) -> None:
        super().__init__(error=error, description=description)
        self.url = url
        self.method = method
        self.request_content_type = request_content_type
        self.request_body = request_body
        self.status_code = status_code
        self.response_content_type = response_content_type
        self.response_body = response_body

    def to_dict(self) -> dict[str, Any]:
        out = super().to_dict()
        out.update(
            {
                "url": self.url,
                "method": self.method,
                "request_content_type": self.request_content_type,
                "request_body": self.request_body,
                "status_code": self.status_code,
                "response_content_type": self.response_content_type,
                "response_body": self.response_body,
            }
        )
        return out


def _status_to_error_key(status_code: int) -> str:
    return {
        400: "bad_request",
        401: "unauthorized",
        403: "forbidden",
        404: "resource_not_found",
        408: "request_timeout",
        409: "conflict",
        422: "unprocessable_entity",
        429: "too_many_requests",
        500: "internal_server_error",
        502: "bad_gateway",
        503: "service_unavailable",
    }.get(status_code, "http_error")


class ResourceNotFoundError(HttpApiError):
    __slots__ = ()

    def __init__(self, description: str | None = None, **kw: Any) -> None:
        super().__init__(error="resource_not_found", description=description, **kw)


class UnauthorizedError(HttpApiError):
    __slots__ = ()

    def __init__(self, description: str | None = None, **kw: Any) -> None:
        super().__init__(error="unauthorized", description=description, **kw)


class HttpResponseError(HttpApiError):
    """Failed API response that is not handled as a more specific type."""

    __slots__ = ()

    def __init__(self, *, description: str | None = None, **kw: Any) -> None:
        status_code = kw["status_code"]
        super().__init__(
            error=_status_to_error_key(status_code),
            description=description,
            **kw,
        )


class InvalidApiResponseError(SecureDeployError):
    __slots__ = ()

    def __init__(self, description: str | None = None) -> None:
        super().__init__(
            error="invalid_api_response",
            description=description,
        )


class ClientStateError(SecureDeployError):
    """Local client or config state does not allow the operation."""

    __slots__ = ()

    def __init__(self, *, error: str, description: str | None = None) -> None:
        super().__init__(error=error, description=description)


class ApplicationNotFoundError(SecureDeployError):
    __slots__ = ()

    def __init__(self, *, slug: str, workspace: str) -> None:
        super().__init__(
            error="application_not_found",
            description=(
                f"Application {slug!r} not found in workspace {workspace!r}"
            ),
        )


class ValidationError(SecureDeployError):
    __slots__ = ()

    def __init__(
        self, description: str | None = None, *, error: str = "validation_error"
    ) -> None:
        super().__init__(error=error, description=description)


class UpstreamConnectError(SecureDeployError):
    __slots__ = ()

    def __init__(self, description: str | None = None) -> None:
        super().__init__(error="upstream_unreachable", description=description)


class UpstreamTimeoutError(SecureDeployError):
    __slots__ = ()

    def __init__(self, description: str | None = None) -> None:
        super().__init__(error="upstream_timeout", description=description)


class CliError(SecureDeployError):
    """CLI usage or runtime message; ``exit_code`` matches Click (2=usage, 1=error)."""

    __slots__ = ("exit_code",)

    def __init__(
        self,
        description: str,
        *,
        error: str = "cli_error",
        exit_code: int = 1,
    ) -> None:
        super().__init__(error=error, description=description)
        self.exit_code = exit_code

    def to_dict(self) -> dict[str, Any]:
        out = super().to_dict()
        out["exit_code"] = self.exit_code
        return out


class CliAbort(SecureDeployError):
    """User cancelled an interactive prompt; the CLI layer maps this to ``click.Abort``."""

    __slots__ = ()

    def __init__(self) -> None:
        super().__init__(error="aborted", description=None)
