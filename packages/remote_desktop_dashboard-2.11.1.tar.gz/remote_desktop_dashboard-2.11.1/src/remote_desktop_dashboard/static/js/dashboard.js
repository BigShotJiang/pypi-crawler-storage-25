(function () {
  "use strict";

  const STORAGE_OPERATOR = "rdd_operator";
  const STORAGE_RDP_USER = "rdd_rdp_username";
  const STORAGE_RDP_DOMAIN = "rdd_rdp_domain";
  const STORAGE_USE_IP   = "rdd_use_ip";
  const HEARTBEAT_MS = 30000;

  // -- Top bar refs ---------------------------------------------------------
  const wsStatus      = document.getElementById("ws-status");
  const lastUpdate    = document.getElementById("last-update");
  const statusUpdated = document.getElementById("status-updated");
  const machineCount  = document.getElementById("machine-count");
  const operatorInput = document.getElementById("operator-name");
  const operatorList  = document.getElementById("operator-list");
  const rdpUserInput  = document.getElementById("rdp-username");
  const rdpDomainInput= document.getElementById("rdp-domain");
  const useIpInput    = document.getElementById("use-ip");
  const toastEl       = document.getElementById("toast");
  const serverBanner  = document.getElementById("server-banner");

  // -- Tab panels -----------------------------------------------------------
  const tabButtons     = document.querySelectorAll(".tab[data-tab]");
  const tabPanels      = document.querySelectorAll(".tab-panel[data-panel]");
  const statusRowsEl   = document.getElementById("status-rows");
  const inventoryRowsEl= document.getElementById("inventory-rows");
  const auditRowsEl    = document.getElementById("audit-rows");
  const detailPanelEl  = document.getElementById("detail-panel");

  // -- Audit filters --------------------------------------------------------
  const auditActionFilter   = document.getElementById("audit-action-filter");
  const auditMachineFilter  = document.getElementById("audit-machine-filter");
  const auditOperatorFilter = document.getElementById("audit-operator-filter");
  const auditRefreshBtn     = document.getElementById("audit-refresh");

  // -- Drawers --------------------------------------------------------------
  const manageDrawer   = document.getElementById("manage-drawer");
  const settingsDrawer = document.getElementById("settings-drawer");
  const toggleManageBtn  = document.getElementById("toggle-manage");
  const toggleSettingsBtn= document.getElementById("toggle-settings");

  let machines = [];
  let activeTab = "status";
  let selectedMachine = null;
  let auditCache = [];
  let serverMeta = {
    monitor_configured: true,
    users_can_connect: true,
    users_can_manage_machines: false,
    users_can_release_own_lock: true,
  };
  let heartbeatTimers = {};
  const pollingMachines = new Set();

  operatorInput.value = localStorage.getItem(STORAGE_OPERATOR) || "";
  rdpUserInput.value = localStorage.getItem(STORAGE_RDP_USER) || "";
  if (rdpDomainInput) {
    rdpDomainInput.value = localStorage.getItem(STORAGE_RDP_DOMAIN) || "";
  }
  if (useIpInput) {
    useIpInput.checked = localStorage.getItem(STORAGE_USE_IP) === "1";
    useIpInput.addEventListener("change", function () {
      localStorage.setItem(STORAGE_USE_IP, useIpInput.checked ? "1" : "0");
    });
  }

  function bindAutosave(el) {
    if (!el) return;
    el.addEventListener("input", function () {
      savePrefs();
      if (machines.length) render(machines);
    });
    el.addEventListener("change", savePrefs);
    el.addEventListener("blur", savePrefs);
  }
  bindAutosave(operatorInput);
  bindAutosave(rdpUserInput);
  bindAutosave(rdpDomainInput);

  // -- Operator preferences: auto-fill RDP user/domain from server -----------
  let operatorLookupTimer = null;
  async function lookupOperatorPrefs(name) {
    const trimmed = (name || "").trim();
    if (!trimmed) return;
    try {
      const res = await fetch("/api/v1/operators/" + encodeURIComponent(trimmed));
      if (!res.ok) return;
      const data = await res.json();
      if (!data || !data.known) return;
      // Only auto-fill empty fields so we never clobber what the user just typed.
      if (rdpUserInput && !rdpUserInput.value.trim() && data.rdp_username) {
        rdpUserInput.value = data.rdp_username;
        savePrefs();
      }
      if (rdpDomainInput && !rdpDomainInput.value.trim() && data.rdp_domain) {
        rdpDomainInput.value = data.rdp_domain;
        savePrefs();
      }
      if (useIpInput && data.use_hostname !== null && data.use_hostname !== undefined) {
        useIpInput.checked = data.use_hostname === false;
        localStorage.setItem(STORAGE_USE_IP, useIpInput.checked ? "1" : "0");
      }
    } catch (_) { /* network blip; ignore */ }
  }
  operatorInput.addEventListener("input", function () {
    if (operatorLookupTimer) clearTimeout(operatorLookupTimer);
    operatorLookupTimer = setTimeout(function () {
      lookupOperatorPrefs(operatorInput.value);
    }, 450);
  });
  operatorInput.addEventListener("blur", function () {
    lookupOperatorPrefs(operatorInput.value);
  });

  async function loadOperatorList() {
    if (!operatorList) return;
    try {
      const res = await fetch("/api/v1/operators?limit=50");
      if (!res.ok) return;
      const arr = await res.json();
      operatorList.innerHTML = arr
        .map(function (o) { return '<option value="' + escapeHtml(o.display_name) + '"></option>'; })
        .join("");
    } catch (_) {}
  }

  function savePrefs() {
    localStorage.setItem(STORAGE_OPERATOR, operatorInput.value.trim());
    localStorage.setItem(STORAGE_RDP_USER, rdpUserInput.value.trim());
    if (rdpDomainInput) {
      localStorage.setItem(STORAGE_RDP_DOMAIN, rdpDomainInput.value.trim());
    }
  }

  function getOperator() {
    return operatorInput.value.trim();
  }

  function normalizeOp(name) {
    return (name || "").trim().toLowerCase();
  }

  function operatorsMatch(a, b) {
    const x = normalizeOp(a);
    const y = normalizeOp(b);
    return x !== "" && x === y;
  }

  function enrichMachine(m) {
    const op = normalizeOp(getOperator());
    const locked = !!(m.is_locked && m.locked_by);
    const lockedBy = locked ? normalizeOp(m.locked_by) : "";
    const mine = locked && op && lockedBy === op;
    m._mine = mine;
    m.lock_available = !locked || mine;
    return m;
  }

  function getRdpDomain() {
    return rdpDomainInput ? rdpDomainInput.value.trim() : "";
  }

  function getRdpUser() {
    return rdpUserInput.value.trim();
  }

  function getRdpUsername() {
    const u = getRdpUser();
    if (!u) return null;
    const d = getRdpDomain();
    if (d && !u.includes("\\") && !u.includes("/") && !u.includes("@")) {
      return d + "\\" + u;
    }
    return u;
  }

  function missingRequiredFields() {
    const missing = [];
    if (!operatorInput.value.trim()) missing.push("Your name");
    if (rdpDomainInput && !rdpDomainInput.value.trim()) missing.push("RDP domain");
    if (!rdpUserInput.value.trim()) missing.push("RDP username");
    return missing;
  }

  function focusFirstMissing() {
    if (!operatorInput.value.trim()) {
      operatorInput.focus();
      return;
    }
    if (rdpDomainInput && !rdpDomainInput.value.trim()) {
      rdpDomainInput.focus();
      return;
    }
    if (!rdpUserInput.value.trim()) {
      rdpUserInput.focus();
    }
  }

  function wsUrl() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    return proto + "//" + location.host + "/ws/dashboard";
  }

  function showToast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.className = "toast" + (isError ? " toast-error" : "");
    setTimeout(function () {
      toastEl.className = "toast hidden";
    }, 5000);
  }

  const launchModal = document.getElementById("launch-modal");
  const launchTarget = document.getElementById("launch-target");
  const launchHint = document.getElementById("launch-hint");
  const launchCopyRdp = document.getElementById("launch-copy-rdp");
  const launchTryLocal = document.getElementById("launch-try-local");
  const launchCopyMstsc = document.getElementById("launch-copy-mstsc");
  const launchDownloadRdp = document.getElementById("launch-download-rdp");
  const launchClose = document.getElementById("launch-close");
  const launchBackdrop = document.getElementById("launch-backdrop");
  const useIpCheckbox = document.getElementById("use-ip");

  let lastLaunchData = null;

  function hideLaunchModal() {
    launchModal.className = "modal hidden";
    lastLaunchData = null;
  }

  function showLaunchModal(data) {
    lastLaunchData = data;
    launchTarget.textContent = data.machine_name + " (" + data.target_host + ")";
    launchHint.textContent =
      data.message ||
      "Launch on this PC, or download .rdp (uses each PC's own Windows App / msrdc).";
    if (launchCopyRdp) {
      launchCopyRdp.dataset.uri = data.launch_uri || data.rdp_uri || "";
    }
    if (launchDownloadRdp && data.rdp_download_url) {
      launchDownloadRdp.href = data.rdp_download_url;
      launchDownloadRdp.classList.remove("hidden");
    } else if (launchDownloadRdp) {
      launchDownloadRdp.classList.add("hidden");
    }
    launchModal.className = "modal";
  }

  function mergeMachineUpdate(updated) {
    if (!updated || !updated.name) return;
    const idx = machines.findIndex(function (m) {
      return m.name === updated.name;
    });
    if (idx >= 0) {
      machines[idx] = updated;
    } else {
      machines.push(updated);
    }
    render(machines);
  }

  async function tryLocalLaunch(url, timeoutMs) {
    if (!url) return null;
    const ms = timeoutMs || 3000;
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, ms);
    try {
      const r = await fetch(url, { method: "GET", mode: "cors", signal: ctrl.signal });
      clearTimeout(timer);
      if (!r.ok) return null;
      return r.json().catch(function () {
        return { ok: true, client: "unknown" };
      });
    } catch (e) {
      clearTimeout(timer);
      return null;
    }
  }

  function launchToast(client, target) {
    const dest = target ? " to " + target : "";
    if (client === "windows_app" || client === "windows365" || client === "msrdc") {
      showToast("Connecting directly" + dest + " via Windows App…", false);
    } else if (client === "mstsc") {
      showToast("Opening legacy Remote Desktop (mstsc). Install Windows App or set RDD_MSRDC_PATH.", true);
    } else {
      showToast("Opening remote session…", false);
    }
  }

  async function launchRemoteSession(data) {
    showLaunchModal(data);
    showToast(
      "Click Launch Windows App or Download .rdp — RDP password is entered in Windows.",
      false
    );
    return false;
  }

  function applyPermissionsUi() {
    // Manage / Settings buttons are only useful for admins (they perform
    // PIN-gated actions). We show them only when Admin mode is on; see
    // syncAdminUi() which actually toggles visibility via the body class.
    if (toggleManageBtn) {
      toggleManageBtn.title = "Manage machines (admin only)";
    }
    if (toggleSettingsBtn) {
      toggleSettingsBtn.title = "Server settings (admin only)";
    }
  }

  function updateServerBanner(meta) {
    if (!serverBanner) return;
    if (!meta || meta.monitor_configured !== false) {
      serverBanner.className = "server-banner hidden";
      serverBanner.textContent = "";
      return;
    }
    serverBanner.className = "server-banner";
    serverBanner.innerHTML =
      "<strong>Bench monitoring is not configured.</strong> " +
      "Open <strong>Settings</strong> and save the service account (admin.env is on the server).";
  }

  function on(el, event, fn) {
    if (el) el.addEventListener(event, fn);
  }

  on(launchTryLocal, "click", async function () {
    if (!lastLaunchData) return;
    if (lastLaunchData.local_launch_url) {
      const result = await tryLocalLaunch(lastLaunchData.local_launch_url);
      if (result && result.ok !== false) {
        launchToast(result.client || lastLaunchData.client, lastLaunchData.target_host);
        hideLaunchModal();
        return;
      }
    }
    showToast(
      "Could not launch Windows App on this PC. Install Microsoft Windows App or use Download .rdp.",
      true
    );
  });

  on(launchCopyRdp, "click", function () {
    if (!lastLaunchData) return;
    const uri = launchCopyRdp.dataset.uri || lastLaunchData.launch_uri || lastLaunchData.rdp_uri;
    if (!uri) return;
    navigator.clipboard.writeText(uri).then(function () {
      showToast("Copied RDP link", false);
    });
  });

  on(launchCopyMstsc, "click", function () {
    if (!lastLaunchData || !lastLaunchData.mstsc_command) return;
    navigator.clipboard.writeText(lastLaunchData.mstsc_command).then(function () {
      showToast("Copied: " + lastLaunchData.mstsc_command, false);
    });
  });

  on(launchClose, "click", hideLaunchModal);
  on(launchBackdrop, "click", hideLaunchModal);

  function fmt(value, fallback) {
    if (value === null || value === undefined || value === "") {
      return fallback || "\u2014";
    }
    if (Array.isArray(value)) {
      return value.length ? value.join(", ") : fallback || "\u2014";
    }
    return String(value);
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  function updateSummary(list) {
    const online = list.filter(function (m) { return m.is_online; }).length;
    const locked = list.filter(function (m) { return m.is_locked; }).length;
    const offline = list.length - online;
    if (machineCount) {
      // Mini summary chips, color-coded.
      machineCount.innerHTML =
        '<span style="color: var(--text)">' + list.length + ' machines</span>' +
        ' \u2022 <span style="color: var(--success)">' + online + ' online</span>' +
        ' \u2022 <span style="color: var(--warn)">' + locked + ' in use</span>' +
        ' \u2022 <span style="color: var(--danger)">' + offline + ' offline</span>';
    }
  }

  function rowOptional(label, value) {
    if (value === null || value === undefined || value === "") return "";
    if (Array.isArray(value) && !value.length) return "";
    return row(label, value, true);
  }

  function row(label, value, active) {
    const display = fmt(value, "\u2014");
    const cls =
      "row-value" + (display === "\u2014" ? " empty" : active ? " active" : "");
    return (
      '<div class="row"><span class="row-label">' +
      escapeHtml(label) +
      '</span><span class="' +
      cls +
      '">' +
      escapeHtml(display) +
      "</span></div>"
    );
  }

  function lockBadge(m) {
    if (!m.is_locked || !m.locked_by) return "";
    const mine = m._mine || operatorsMatch(m.locked_by, getOperator());
    return (
      '<div class="lock-badge' +
      (mine ? " lock-mine" : "") +
      '">In use: <strong>' +
      escapeHtml(m.locked_by) +
      "</strong></div>"
    );
  }

  function actionButtons(m) {
    const mine = !!m._mine;
    const locked = !!(m.is_locked && m.locked_by);
    const lockedByOther = locked && !mine;
    const name = escapeHtml(m.name);

    const connectLabel = mine ? "Reconnect" : "Connect";
    const connectDisabled = lockedByOther;
    const connectTitle = lockedByOther
      ? "In use by " + escapeHtml(m.locked_by) + ". They must release first."
      : mine
      ? "Reconnect to your locked session"
      : "Lock and connect to " + m.name;

    const releaseDisabled = !mine;
    const releaseTitle = mine
      ? "Release your lock on " + m.name
      : locked
      ? "Locked by " + escapeHtml(m.locked_by) + " — admin only can force release"
      : "No active lock to release";

    let html = '<div class="card-actions">';
    html +=
      '<button type="button" class="btn btn-primary' +
      (connectDisabled ? " is-inactive" : "") +
      '" data-action="connect" data-name="' +
      name +
      '" aria-disabled="' +
      (connectDisabled ? "true" : "false") +
      '" title="' +
      connectTitle +
      '">' +
      connectLabel +
      "</button>";
    html +=
      '<button type="button" class="btn btn-secondary' +
      (releaseDisabled ? " is-inactive" : "") +
      '" data-action="release" data-name="' +
      name +
      '" aria-disabled="' +
      (releaseDisabled ? "true" : "false") +
      '" title="' +
      releaseTitle +
      '">Release</button>';
    html += "</div>";
    return html;
  }

  function statusDotClass(label) {
    if (label === "in_use") return "in_use";
    if (label === "online" || label === "reachable") return "online";
    if (label === "unknown") return "unknown";
    return "offline";
  }

  function formatTtl(seconds) {
    if (seconds === null || seconds === undefined) return "\u2014";
    if (seconds <= 0) return "0s";
    if (seconds < 60) return seconds + "s";
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return m + "m " + s + "s";
  }

  // SVG icons used by row-action buttons (kept tiny so the row stays compact).
  const ICON_RDP =
    '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="2" y="4" width="20" height="14" rx="2"/>' +
      '<line x1="8" y1="22" x2="16" y2="22"/>' +
      '<line x1="12" y1="18" x2="12" y2="22"/>' +
    '</svg>';
  const ICON_RESERVE =
    '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<polyline points="20 6 9 17 4 12"/>' +
    '</svg>';
  const ICON_RELEASE =
    '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M3 12a9 9 0 1 0 3-6.7"/>' +
      '<polyline points="3 4 3 10 9 10"/>' +
    '</svg>';

  function rowActionsHtml(m) {
    const mine = !!m._mine;
    const locked = !!(m.is_locked && m.locked_by);
    const lockedByOther = locked && !mine;
    const name = escapeHtml(m.name);

    // RDP: connect + launch (or reconnect if mine).
    const rdpDisabled = lockedByOther;
    const rdpLabel = mine ? "Reconnect" : "RDP";
    const rdpTitle = lockedByOther
      ? "In use by " + escapeHtml(m.locked_by) + " — they must release first"
      : mine ? "Reopen your Windows App session" : "Reserve and launch Windows App";

    // Reserve: lock without launching RDP.
    const reserveDisabled = locked;  // already mine or someone else's
    const reserveTitle = mine
      ? "Already reserved by you"
      : lockedByOther
        ? "In use by " + escapeHtml(m.locked_by)
        : "Lock this bench under your name (no RDP yet)";

    // Release: only the lock owner can.
    const releaseDisabled = !mine;
    const releaseTitle = mine
      ? "Release your lock on " + escapeHtml(m.name)
      : locked
        ? "Only " + escapeHtml(m.locked_by) + " or an admin can release this"
        : "No active lock";

    const parts = [];
    parts.push(
      '<button type="button" class="btn btn-rdp btn-sm" data-action="connect" data-name="' + name + '"' +
        (rdpDisabled ? ' disabled' : '') +
        ' title="' + rdpTitle + '">' +
        ICON_RDP + '<span>' + rdpLabel + '</span></button>'
    );
    parts.push(
      '<button type="button" class="btn btn-reserve btn-sm" data-action="reserve" data-name="' + name + '"' +
        (reserveDisabled ? ' disabled' : '') +
        ' title="' + reserveTitle + '">' +
        ICON_RESERVE + '<span>Reserve</span></button>'
    );
    parts.push(
      '<button type="button" class="btn btn-release btn-sm" data-action="release" data-name="' + name + '"' +
        (releaseDisabled ? ' disabled' : '') +
        ' title="' + releaseTitle + '">' +
        ICON_RELEASE + '<span>Release</span></button>'
    );
    if (lockedByOther) {
      parts.push(
        '<button type="button" class="btn btn-secondary btn-sm admin-only" data-action="admin-release" data-name="' +
          name + '" title="Admin force release">Force</button>'
      );
    }
    return '<div class="row-actions">' + parts.join("") + "</div>";
  }

  async function reserveMachine(name) {
    const missing = missingRequiredFields();
    if (missing.length) {
      showToast("Required: " + missing.join(", "), true);
      focusFirstMissing();
      return;
    }
    const op = getOperator();
    savePrefs();
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/reserve",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Reserve failed", true);
        return;
      }
      mergeMachineUpdate(data);
      startHeartbeat(name);
      showToast("Reserved " + name + " under your name. Click RDP to launch.", false);
    } catch (err) {
      showToast("Reserve failed: " + err, true);
    }
  }

  function statusDotHtml(m) {
    const label = m.status_label || (m.is_online ? "online" : "offline");
    return '<span class="status-dot ' + statusDotClass(label) + '" title="' + escapeHtml(m.status_display || "") + '"></span>';
  }

  function renderStatusTable(list) {
    if (!statusRowsEl) return;
    if (!list.length) {
      statusRowsEl.innerHTML =
        '<tr class="empty"><td colspan="6" class="muted">No machines registered. Open the manage drawer to add one.</td></tr>';
      return;
    }
    const op = getOperator();
    statusRowsEl.innerHTML = list.map(function (m) {
      const reservedCellClass = m.is_locked ? "cell-reserved busy" : "cell-reserved free";
      const reservedText = m.is_locked
        ? escapeHtml(m.locked_by || "(unknown)") + (m._mine ? " (you)" : "")
        : "Free";
      const rdpUser = m.is_locked
        ? escapeHtml(m.lock_rdp_username || m.locked_by || "")
        : (m.logged_in_users && m.logged_in_users.length
            ? escapeHtml(m.logged_in_users[0])
            : '<span class="muted">\u2014</span>');
      const ttl = m.is_locked ? formatTtl(m.lock_ttl_seconds) : "\u2014";
      const ttlCls = m.is_locked && m.lock_ttl_seconds !== null && m.lock_ttl_seconds < 15
        ? "cell-ttl warning" : "cell-ttl";
      const desc = m.description ? '<div class="desc">' + escapeHtml(m.description) + '</div>' : "";
      const selected = selectedMachine === m.name ? " selected" : "";
      const statusLabel = m.status_label || (m.is_online ? "online" : "offline");
      const stripeCls = " row-" + statusDotClass(statusLabel);
      return (
        '<tr data-name="' + escapeHtml(m.name) + '" class="row-machine' + stripeCls + selected + '">' +
          '<td><div class="cell-machine">' +
            '<div class="name">' + statusDotHtml(m) + escapeHtml(m.name) + '</div>' +
            desc +
          '</div></td>' +
          '<td><span class="cell-host">' + escapeHtml(m.hostname || "") + '</span></td>' +
          '<td>' + rdpUser + '</td>' +
          '<td><span class="' + reservedCellClass + '">' + reservedText + '</span></td>' +
          '<td><span class="' + ttlCls + '">' + escapeHtml(ttl) + '</span></td>' +
          '<td class="actions-col">' + rowActionsHtml(m) + '</td>' +
        '</tr>'
      );
    }).join("");
    if (statusUpdated) {
      const now = new Date();
      statusUpdated.textContent = "Updated " + now.toLocaleTimeString();
    }
  }

  function renderInventoryTable(list) {
    if (!inventoryRowsEl) return;
    if (!list.length) {
      inventoryRowsEl.innerHTML = '<tr class="empty"><td colspan="7" class="muted">No machines yet.</td></tr>';
      return;
    }
    inventoryRowsEl.innerHTML = list.map(function (m) {
      const com = m.com_port_user
        ? escapeHtml(m.com_port_user)
        : '<span class="muted">\u2014</span>';
      const agentPill = m.bench_agent_online
        ? '<span class="status-pill online" title="' + escapeHtml(m.bench_agent_version || "") + '">online</span>'
        : (m.bench_agent_last_seen
            ? '<span class="status-pill offline">stale</span>'
            : '<span class="muted small">not installed</span>');
      return (
        '<tr data-name="' + escapeHtml(m.name) + '">' +
          '<td><div class="cell-machine">' +
            '<div class="name">' + escapeHtml(m.name) + '</div>' +
            (m.description ? '<div class="desc">' + escapeHtml(m.description) + '</div>' : "") +
          '</div></td>' +
          '<td><span class="cell-host">' + escapeHtml(m.hostname || "") + '</span></td>' +
          '<td><span class="cell-host">' + escapeHtml(m.ip_address || "") + '</span></td>' +
          '<td>' + (m.board ? escapeHtml(m.board) : '<span class="muted">\u2014</span>') + '</td>' +
          '<td>' + (m.access_note ? escapeHtml(m.access_note) : '<span class="muted">\u2014</span>') + '</td>' +
          '<td>' + com + '</td>' +
          '<td>' + agentPill + '</td>' +
        '</tr>'
      );
    }).join("");
  }

  function renderDetailPanel(name) {
    if (!detailPanelEl) return;
    if (!name) {
      detailPanelEl.innerHTML = '<div class="detail-empty muted small">Select a machine to see details.</div>';
      return;
    }
    const m = machines.find(function (x) { return x.name === name; });
    if (!m) {
      detailPanelEl.innerHTML = '<div class="detail-empty muted small">Machine not found.</div>';
      return;
    }
    const reserved = m.is_locked
      ? '<span class="detail-state busy">In use by ' + escapeHtml(m.locked_by || "?") + (m._mine ? " (you)" : "") + "</span>"
      : '<span class="detail-state free">Free</span>';
    const sessionUsers = (m.logged_in_users && m.logged_in_users.length)
      ? escapeHtml(m.logged_in_users.join(", "))
      : (m.is_reachable ? '<span class="muted">None / no active logons</span>' : '<span class="muted">unreachable</span>');
    const ttl = m.is_locked ? formatTtl(m.lock_ttl_seconds) : "\u2014";
    const agentLine = m.bench_agent_online
      ? '<span class="status-pill online">agent v' + escapeHtml(m.bench_agent_version || "?") + " online</span>"
      : (m.bench_agent_last_seen
          ? '<span class="status-pill offline">agent stale</span>'
          : '<span class="muted">agent not installed</span>');
    detailPanelEl.innerHTML =
      '<div class="detail-head">' +
        '<div><div class="machine-id">' + escapeHtml(m.name) + '</div>' +
          (m.description ? '<div class="muted small">' + escapeHtml(m.description) + '</div>' : "") +
        '</div>' +
        statusDotHtml(m) +
      '</div>' +
      '<div class="detail-section"><h4>Status</h4><div class="kv">' + reserved +
        (m.is_locked ? ' \u2022 Auto-release in <strong>' + escapeHtml(ttl) + '</strong>' : '') +
      '</div></div>' +
      '<div class="detail-section"><h4>Host</h4><div class="kv">' +
        '<div><code>' + escapeHtml(m.hostname || "") + '</code></div>' +
        '<div><code>' + escapeHtml(m.ip_address || "") + '</code></div>' +
      '</div></div>' +
      (m.board
        ? '<div class="detail-section"><h4>Board</h4><div class="kv">' + escapeHtml(m.board) + '</div></div>'
        : "") +
      (m.access_note
        ? '<div class="detail-section"><h4>Access</h4><div class="kv">' + escapeHtml(m.access_note) + '</div></div>'
        : "") +
      '<div class="detail-section"><h4>RDP sessions</h4><div class="kv">' + sessionUsers + '</div></div>' +
      (m.com_port_user
        ? '<div class="detail-section"><h4>COM ports</h4><div class="kv">' + escapeHtml(m.com_port_user) + '</div></div>'
        : "") +
      '<div class="detail-section"><h4>Bench agent</h4><div class="kv">' + agentLine + '</div></div>' +
      '<div class="detail-actions">' + rowActionsHtml(m).replace(/btn-sm/g, "") + '</div>' +
      '<div class="detail-section admin-only">' +
        '<h4>Admin tools</h4>' +
        '<div class="form-actions">' +
          '<button type="button" class="btn btn-secondary btn-sm" data-action="emergency-restore" data-name="' + escapeHtml(m.name) + '" ' +
            'title="Tell the bench agent to remove the custom firewall lock and re-enable built-in Remote Desktop rules.">' +
            'Restore native RDP' +
          '</button>' +
          (m.is_locked ? '<button type="button" class="btn btn-secondary btn-sm" data-action="admin-release" data-name="' + escapeHtml(m.name) + '">Force release</button>' : '') +
          '<button type="button" class="btn btn-secondary btn-sm" data-action="kick-others" data-name="' + escapeHtml(m.name) + '">Kick other RDP sessions</button>' +
        '</div>' +
      '</div>';
  }

  // ---- Audit log -----------------------------------------------------------
  async function loadAndRenderAudit() {
    if (!auditRowsEl) return;
    const qs = new URLSearchParams();
    if (auditActionFilter && auditActionFilter.value) qs.set("action", auditActionFilter.value);
    if (auditMachineFilter && auditMachineFilter.value.trim()) qs.set("machine", auditMachineFilter.value.trim().toUpperCase());
    if (auditOperatorFilter && auditOperatorFilter.value.trim()) qs.set("operator", auditOperatorFilter.value.trim());
    qs.set("limit", "300");
    auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Loading audit\u2026</td></tr>';
    try {
      const res = await fetch("/api/v1/audit?" + qs.toString());
      if (!res.ok) {
        auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Audit fetch failed.</td></tr>';
        return;
      }
      auditCache = await res.json();
      if (!auditCache.length) {
        auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">No audit events match these filters.</td></tr>';
        return;
      }
      auditRowsEl.innerHTML = auditCache.map(function (e) {
        const ts = e.created_at ? new Date(e.created_at).toLocaleString() : "";
        const actionCls = "audit-action-pill " + escapeHtml(e.action || "");
        return (
          "<tr>" +
            '<td class="audit-ts-col">' + escapeHtml(ts) + "</td>" +
            '<td><span class="' + actionCls + '">' + escapeHtml(e.action || "") + "</span></td>" +
            "<td>" + (e.machine_name ? escapeHtml(e.machine_name) : '<span class="muted">\u2014</span>') + "</td>" +
            "<td>" + (e.operator ? escapeHtml(e.operator) : '<span class="muted">\u2014</span>') + "</td>" +
            "<td>" + (e.detail ? escapeHtml(e.detail) : '<span class="muted">\u2014</span>') + "</td>" +
            '<td class="audit-ip-col">' + (e.client_ip ? escapeHtml(e.client_ip) : '<span class="muted">\u2014</span>') + "</td>" +
          "</tr>"
        );
      }).join("");
    } catch (err) {
      auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Network error.</td></tr>';
    }
  }

  // ---- Tab switching -------------------------------------------------------
  function setActiveTab(name) {
    activeTab = name;
    tabButtons.forEach(function (b) {
      const active = b.dataset.tab === name;
      b.classList.toggle("active", active);
      b.setAttribute("aria-selected", active ? "true" : "false");
    });
    tabPanels.forEach(function (p) {
      p.classList.toggle("hidden", p.dataset.panel !== name);
    });
    if (name === "audit") {
      loadAndRenderAudit();
    } else if (name === "inventory") {
      renderInventoryTable(machines);
    }
  }
  tabButtons.forEach(function (b) {
    b.addEventListener("click", function () { setActiveTab(b.dataset.tab); });
  });

  function render(list) {
    machines = list.map(enrichMachine);
    machines.sort(function (a, b) {
      return a.name.localeCompare(b.name, undefined, { numeric: true });
    });
    updateSummary(machines);
    renderStatusTable(machines);
    if (activeTab === "inventory") renderInventoryTable(machines);
    if (selectedMachine) renderDetailPanel(selectedMachine);
    if (lastUpdate) lastUpdate.textContent = "Updated " + new Date().toLocaleTimeString();
    syncHeartbeatsFromState();
  }

  // Re-tick TTL & "agent online" every 1s using last known machines snapshot.
  setInterval(function () {
    if (!machines.length) return;
    // Decrement TTL purely on the client until next push from server.
    machines.forEach(function (m) {
      if (m.is_locked && typeof m.lock_ttl_seconds === "number" && m.lock_ttl_seconds > 0) {
        m.lock_ttl_seconds = Math.max(0, m.lock_ttl_seconds - 1);
      }
    });
    if (activeTab === "status") renderStatusTable(machines);
    if (selectedMachine) renderDetailPanel(selectedMachine);
  }, 1000);

  // ---- Status table row clicks (selection + delegated buttons) -----------
  if (statusRowsEl) {
    statusRowsEl.addEventListener("click", function (ev) {
      const btn = ev.target.closest("button[data-action]");
      if (btn) return; // button handler below picks it up
      const row = ev.target.closest("tr.row-machine");
      if (!row) return;
      selectedMachine = row.dataset.name;
      renderStatusTable(machines);
      renderDetailPanel(selectedMachine);
    });
  }
  if (auditRefreshBtn) auditRefreshBtn.addEventListener("click", loadAndRenderAudit);
  [auditActionFilter, auditMachineFilter, auditOperatorFilter].forEach(function (el) {
    if (el) el.addEventListener("change", loadAndRenderAudit);
  });

  function syncHeartbeatsFromState() {
    const op = getOperator();
    const mine = new Set();
    if (op) {
      machines.forEach(function (m) {
        if (m._mine || (m.is_locked && operatorsMatch(m.locked_by, op))) {
          mine.add(m.name);
        }
      });
    }
    mine.forEach(function (name) {
      if (!heartbeatTimers[name]) startHeartbeat(name);
    });
    Object.keys(heartbeatTimers).forEach(function (name) {
      if (!mine.has(name)) stopHeartbeat(name);
    });
  }

  function setWsStatus(state, text) {
    if (!wsStatus) return;
    wsStatus.className = "status-pill status-" + state;
    wsStatus.textContent = text;
  }

  function sendHeartbeat(name) {
    const op = getOperator();
    if (!op) return;
    fetch("/api/v1/machines/" + encodeURIComponent(name) + "/lock/heartbeat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ operator: op }),
    }).catch(function () {});
  }

  function startHeartbeat(name) {
    stopHeartbeat(name);
    sendHeartbeat(name);
    heartbeatTimers[name] = setInterval(function () {
      sendHeartbeat(name);
    }, HEARTBEAT_MS);
  }

  function stopHeartbeat(name) {
    if (heartbeatTimers[name]) {
      clearInterval(heartbeatTimers[name]);
      delete heartbeatTimers[name];
    }
  }

  function stopAllHeartbeats() {
    Object.keys(heartbeatTimers).forEach(stopHeartbeat);
  }

  function showGuardStatus(name, guard) {
    if (!guard) return;
    if (guard.status === "agent") {
      showToast(
        "Access on " + name +
          " is enforced by the bench agent (Remote Desktop Users group + session kicks).",
        false
      );
      return;
    }
    if (!guard.enabled) {
      return;
    }
    if (guard.status === "skipped" || guard.status === "no_client_ip") {
      const reason =
        guard.reason ||
        "Add your PC's LAN IP to RDD_RDP_GUARD_EXTRA_IPS in admin.env, or set RDD_RDP_GUARD_ENABLED=false to silence this.";
      showToast(
        "Heads up: dashboard lock is active, but the direct-RDP block was skipped. " +
          reason,
        true
      );
      return;
    }
    if (guard.status === "pending" || guard.status === "running") {
      setTimeout(function () { pollGuardStatus(name, 1); }, 3000);
      return;
    }
  }

  async function pollGuardStatus(name, attempt) {
    const MAX_ATTEMPTS = 30;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/guard"
      );
      if (!res.ok) {
        if (attempt < MAX_ATTEMPTS) {
          setTimeout(function () { pollGuardStatus(name, attempt + 1); }, 3000);
        }
        return;
      }
      const g = await res.json();
      if (g.status === "ok") {
        showToast(
          "RDP locked on " +
            name +
            " — only " +
            (g.allow_ips || []).join(", ") +
            " can RDP.",
          false
        );
        return;
      }
      if (g.status === "failed" || g.status === "error") {
        showToast(
          "Direct-RDP block could not be applied on " +
            name +
            " (remote netsh blocked or monitor account isn't local admin). " +
            "The dashboard lock still prevents others from connecting through this dashboard. " +
            "To silence this warning, set RDD_RDP_GUARD_ENABLED=false in admin.env.",
          true
        );
        return;
      }
      if (attempt < MAX_ATTEMPTS) {
        setTimeout(function () { pollGuardStatus(name, attempt + 1); }, 3000);
      } else {
        showToast(
          "Direct-RDP block on " +
            name +
            " is still running on the server. The dashboard lock is active either way.",
          false
        );
      }
    } catch (e) {
      if (attempt < MAX_ATTEMPTS) {
        setTimeout(function () { pollGuardStatus(name, attempt + 1); }, 3000);
      }
    }
  }

  const inFlightConnects = new Set();

  function userMatchesActiveSession(machine) {
    const op = normalizeOp(getOperator());
    const rdpUser = (rdpUserInput.value || "").trim().toLowerCase();
    const candidates = new Set([op]);
    if (rdpUser) {
      candidates.add(rdpUser);
      const domain = getRdpDomain().toLowerCase();
      if (domain) candidates.add((domain + "\\" + rdpUser).toLowerCase());
    }
    candidates.delete("");
    const users = (machine.logged_in_users || []).map(function (u) {
      return (u || "").trim().toLowerCase();
    });
    for (const u of users) {
      const bare = u.includes("\\") ? u.split("\\").pop() : u;
      if (candidates.has(u) || candidates.has(bare)) return u;
    }
    return null;
  }

  async function connectMachine(name) {
    const missing = missingRequiredFields();
    if (missing.length) {
      showToast("Required: " + missing.join(", "), true);
      focusFirstMissing();
      return;
    }
    if (inFlightConnects.has(name)) {
      return;
    }
    const op = getOperator();
    const existing = machines.find(function (x) {
      return x.name === name;
    });

    if (existing && (existing.logged_in_users || []).length) {
      const match = userMatchesActiveSession(existing);
      if (match) {
        showToast(
          "You already have an active session on " +
            name +
            " (logged in as " +
            match +
            "). Reconnecting will join it.",
          false
        );
      } else if (!(existing.is_locked && existing._mine)) {
        const activeUsers = existing.logged_in_users.join(", ");
        const ok = window.confirm(
          name +
            " currently has active session(s): " +
            activeUsers +
            ".\n\nConnect anyway? You'll share the bench with " +
            activeUsers +
            "."
        );
        if (!ok) return;
      }
    }

    if (existing && existing.is_locked && existing.locked_by && !existing._mine) {
      showToast(
        "In use by " +
          existing.locked_by +
          ". Only the server admin can release this lock.",
        true
      );
      return;
    }
    savePrefs();
    inFlightConnects.add(name);
    showToast("Connecting to " + name + "…", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/connect",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Cannot connect", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      else loadDashboard();
      startHeartbeat(name);
      showGuardStatus(name, data.guard);
      if (data.local_launch_url) {
        tryLocalLaunch(data.local_launch_url, 2500).then(function (result) {
          if (result && result.ok !== false) {
            launchToast(result.client || data.client, data.target_host);
            hideLaunchModal();
          }
        });
      }
      await launchRemoteSession(data);
    } catch (e) {
      showToast("Connection failed: " + e.message, true);
    } finally {
      inFlightConnects.delete(name);
    }
  }

  function setMachinePolling(name, active) {
    if (active) {
      pollingMachines.add(name);
    } else {
      pollingMachines.delete(name);
    }
    if (machines.length) {
      render(machines);
    }
  }

  async function pollMachine(name) {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    setMachinePolling(name, true);
    showToast("Refreshing session for " + name + "…", false);
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 90000);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/poll-now" + q,
        { method: "POST", signal: ctrl.signal }
      );
      clearTimeout(timer);
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Poll failed", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      if (data.ok) {
        showToast("Session updated for " + name, false);
      } else {
        showToast(data.error || "Poll failed — check Server settings credentials", true);
      }
      loadDashboard();
    } catch (e) {
      clearTimeout(timer);
      if (e.name === "AbortError") {
        showToast("Poll still running — live update when ready", false);
      } else {
        showToast("Poll failed: " + e.message, true);
      }
    } finally {
      setMachinePolling(name, false);
    }
  }


  async function adminReleaseMachine(name) {
    const pin = window.prompt("Admin PIN required to force-release " + name + ":");
    if (!pin) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/admin-release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Admin release failed", true);
        return;
      }
      showToast("Lock released on " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Admin release failed", true);
    }
  }


  async function emergencyRestoreRdp(name) {
    const pin = await ensureAdminPin();
    if (!pin) {
      showToast("Admin PIN required.", true);
      return;
    }
    const ok = window.confirm(
      "Emergency restore of native RDP on " + name + "?\n\n" +
      "This tells the bench agent to:\n" +
      "  \u2022 Remove its custom firewall lock rule on TCP 3389\n" +
      "  \u2022 Re-enable the built-in Windows \u201cRemote Desktop\u201d rules\n" +
      "  \u2022 Release the dashboard lock\n\n" +
      "RDP on " + name + " will revert to its default Windows behaviour. " +
      "Use this only if something is wrong and you need to get RDP back."
    );
    if (!ok) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/emergency-restore-rdp",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Emergency restore failed.", true);
        return;
      }
      showToast(
        "Restore queued for " + name +
          ". Agent will revert within ~5s on next poll.",
        false
      );
      // Show the manual fallback in the diagnostic modal so admin has it
      // handy if the agent is offline.
      showDiagModal({
        machine_name: name,
        verdict: "Emergency restore queued",
        dashboard_view: {},
        config: {},
        smb_ok: true,
        config_present: true,
        log_present: true,
        log_tail: [
          "Restore queued. Agent will apply on next poll.",
          "",
          "If the agent is offline, run this on the bench (elevated PowerShell):",
          "",
          (data.manual_powershell || ""),
        ],
      });
    } catch (err) {
      showToast("Network error: " + err, true);
    }
  }

  async function kickOthersMachine(name) {
    if (
      !window.confirm(
        "Log off everyone connected to " +
          name +
          " except the current lock owner?\n\n" +
          "This only works if the bench agent is installed and running on " +
          name +
          "."
      )
    )
      return;
    const pin = window.prompt("Admin PIN required to kick others on " + name + ":");
    if (!pin) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/kick-others",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Kick request failed", true);
        return;
      }
      showToast(
        "Kick requested on " + name + " — unauthorized sessions will be logged off shortly.",
        false
      );
      loadDashboard();
    } catch (e) {
      showToast("Kick request failed", true);
    }
  }

  async function releaseMachine(name) {
    const op = getOperator();
    if (!op) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ operator: op }),
        }
      );
      if (!res.ok) {
        const data = await res.json();
        showToast(data.detail || "Release failed", true);
        return;
      }
      stopHeartbeat(name);
      showToast("Released " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Release failed", true);
    }
  }

  function loadDashboard() {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 20000);
    return fetch("/api/v1/dashboard/fast" + q, { signal: ctrl.signal })
      .then(function (r) {
        clearTimeout(timer);
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.monitor_configured !== undefined) {
          serverMeta.monitor_configured = data.monitor_configured;
          serverMeta.monitor_hint = data.monitor_hint;
          serverMeta.admin_pin_required = data.admin_pin_required;
          if (data.users_can_connect !== undefined) {
            serverMeta.users_can_connect = data.users_can_connect;
          }
          if (data.users_can_manage_machines !== undefined) {
            serverMeta.users_can_manage_machines = data.users_can_manage_machines;
          }
          updateServerBanner(serverMeta);
          applyPermissionsUi();
        }
        if (data.machines) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      })
      .catch(function (err) {
        clearTimeout(timer);
        if (err.name === "AbortError") {
          setWsStatus("err", "Slow");
          if (statusRowsEl) statusRowsEl.innerHTML =
            '<tr class="empty"><td colspan="6" class="muted">Server is taking too long to respond. Try refreshing.</td></tr>';
        } else {
          setWsStatus("err", "Offline");
          if (statusRowsEl) statusRowsEl.innerHTML =
            '<tr class="empty"><td colspan="6" class="muted">Cannot reach the dashboard server.</td></tr>';
        }
      });
  }

  const settingsForm = document.getElementById("settings-form");
  const setDomain = document.getElementById("set-domain");
  const setUsername = document.getElementById("set-username");
  const setPassword = document.getElementById("set-password");
  const setTestHost = document.getElementById("set-test-host");
  const setTestBtn = document.getElementById("set-test-btn");
  const settingsStatus = document.getElementById("settings-status");
  // PIN field has been removed from Settings as of 2.10.1; the cached admin
  // PIN from sessionStorage (set via the Admin sign-in modal) is sent instead.
  const setAdminPin = null;
  const setPinRow = null;
  const machineForm = document.getElementById("machine-form");
  const editMachineId = document.getElementById("edit-machine-id");
  const mfName = document.getElementById("mf-name");
  const mfHostname = document.getElementById("mf-hostname");
  const mfIp = document.getElementById("mf-ip");
  const mfDescription = document.getElementById("mf-description");
  const mfBoard = document.getElementById("mf-board");
  const mfAccess = document.getElementById("mf-access");
  const mfCancel = document.getElementById("mf-cancel");
  const machineAdminList = document.getElementById("machine-admin-list");

  // ---- Drawers (Manage Machines + Settings) ------------------------------
  function openDrawer(drawer) {
    if (!drawer) return;
    // Admin-only drawers: refuse to open without admin mode.
    if ((drawer === manageDrawer || drawer === settingsDrawer) && !isAdmin()) {
      showToast("Sign in as admin to open this panel.", true);
      openAdminModal();
      return;
    }
    drawer.classList.remove("hidden");
    drawer.setAttribute("aria-hidden", "false");
    if (drawer === manageDrawer) refreshAdminMachineList();
    if (drawer === settingsDrawer) {
      loadMonitorSettings();
      loadBenchAgents();
    }
  }
  function closeDrawer(drawer) {
    if (!drawer) return;
    drawer.classList.add("hidden");
    drawer.setAttribute("aria-hidden", "true");
  }
  if (toggleManageBtn) toggleManageBtn.addEventListener("click", function () { openDrawer(manageDrawer); });
  if (toggleSettingsBtn) toggleSettingsBtn.addEventListener("click", function () { openDrawer(settingsDrawer); });
  document.addEventListener("click", function (ev) {
    if (ev.target.matches("[data-close-drawer]")) {
      const d = ev.target.closest(".drawer");
      if (d) closeDrawer(d);
    }
  });
  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape") {
      [manageDrawer, settingsDrawer].forEach(function (d) {
        if (d && !d.classList.contains("hidden")) closeDrawer(d);
      });
    }
  });

  // Render the existing-machines list inside the Manage drawer.
  function refreshAdminMachineList() {
    if (!machineAdminList) return;
    if (!machines.length) {
      machineAdminList.innerHTML = '<p class="muted small">No machines yet. Add one above.</p>';
      return;
    }
    machineAdminList.innerHTML = machines.map(function (m) {
      return (
        '<div class="admin-row">' +
          '<div>' +
            '<div class="name">' + escapeHtml(m.name) + '</div>' +
            '<div class="meta">' + escapeHtml(m.hostname || "") + ' \u2022 ' + escapeHtml(m.ip_address || "") +
              (m.description ? ' \u2022 ' + escapeHtml(m.description) : "") +
            '</div>' +
          '</div>' +
          '<div class="row-actions">' +
            '<button type="button" class="btn btn-secondary btn-sm" data-action="edit" data-id="' + m.id + '" data-name="' + escapeHtml(m.name) + '">Edit</button>' +
            '<button type="button" class="btn btn-danger btn-sm" data-action="delete" data-name="' + escapeHtml(m.name) + '">Delete</button>' +
          '</div>' +
        '</div>'
      );
    }).join("");
  }

  // Legacy guard UI has been removed in 2.10.1 — the bench agent does the
  // hard lock locally now. The legacy guard endpoints still exist on the
  // server for back-compat but no UI surfaces them.

  const benchCopyCmdBtn = document.getElementById("bench-copy-cmd-btn");
  const benchDownloadBtn = document.getElementById("bench-download-installer-btn");
  const benchRefreshBtn = document.getElementById("bench-refresh-btn");
  const benchInstallCmdEl = document.getElementById("bench-install-cmd");
  const benchAgentListEl = document.getElementById("bench-agent-list");
  const benchUrlsEl = document.getElementById("bench-urls");
  const benchInstallerUrlEl = document.getElementById("bench-installer-url");
  const benchAgentUrlEl = document.getElementById("bench-agent-url");

  async function fetchInstallCommand(pin) {
    const q = pin ? "?admin_pin=" + encodeURIComponent(pin) : "";
    const res = await fetch("/api/v1/agent/install-command" + q);
    const data = await res.json().catch(function () { return {}; });
    if (!res.ok) {
      return { error: data.detail || "Could not get install command.", status: res.status };
    }
    return { data: data };
  }

  if (benchCopyCmdBtn) {
    benchCopyCmdBtn.addEventListener("click", async function () {
      let pin = await ensureAdminPin();
      if (serverMeta.admin_pin_required && !pin) {
        showToast("Admin PIN is required to reveal the install command.", true);
        return;
      }

      let result = await fetchInstallCommand(pin);
      while (result.error && result.status === 403) {
        setAdminPinCache("");
        syncAdminUi();
        showToast("Admin PIN was rejected. Sign in again.", true);
        pin = await ensureAdminPin();
        if (!pin) return;
        result = await fetchInstallCommand(pin);
      }
      if (result.error) {
        showToast(result.error, true);
        return;
      }
      const data = result.data;
      if (benchInstallCmdEl) {
        benchInstallCmdEl.textContent = data.command;
        benchInstallCmdEl.classList.remove("hidden");
      }
      if (benchUrlsEl && data.installer_url && data.agent_url) {
        benchInstallerUrlEl.textContent = "installer:  " + data.installer_url;
        benchAgentUrlEl.textContent = "agent:      " + data.agent_url;
        benchUrlsEl.classList.remove("hidden");
      }
      try {
        await navigator.clipboard.writeText(data.command);
        showToast("Install command copied. Paste into elevated PowerShell on each bench.", false);
      } catch (err) {
        showToast("Could not access clipboard — select and copy the text shown below.", true);
      }
    });
  }

  if (benchDownloadBtn) {
    benchDownloadBtn.addEventListener("click", async function () {
      const pin = await ensureAdminPin();
      if (serverMeta.admin_pin_required && !pin) return;
      const result = await fetchInstallCommand(pin);
      if (result.error) {
        showToast(result.error, true);
        return;
      }
      const url = result.data.installer_url;
      if (!url) {
        showToast("Installer URL not available.", true);
        return;
      }
      window.open(url, "_blank");
    });
  }

  async function loadBenchAgents() {
    if (!benchAgentListEl) return;
    benchAgentListEl.innerHTML = '<div class="muted small">Loading agents…</div>';
    try {
      const names = (machines || []).map(function (m) { return m.name; });
      const results = await Promise.all(
        names.map(function (n) {
          return fetch("/api/v1/machines/" + encodeURIComponent(n) + "/agent/status")
            .then(function (r) { return r.ok ? r.json() : null; })
            .catch(function () { return null; });
        })
      );
      const html = results
        .filter(function (x) { return x; })
        .map(function (s) {
          const cls = "agent-pill" +
            (s.online ? " online" : "") +
            (s.error ? " error" : "");
          let metaParts = [];
          if (!s.installed) {
            metaParts.push("not installed yet");
          } else {
            metaParts.push(
              s.online
                ? "online (" + Math.round(s.last_seen_seconds_ago || 0) + "s ago)"
                : "offline (last " + Math.round(s.last_seen_seconds_ago || 0) + "s ago)"
            );
            if (s.version) metaParts.push("v" + s.version);
            if (s.applied_users && s.applied_users.length) {
              metaParts.push("allow: " + s.applied_users.join(", "));
            }
          }
          if (s.error) metaParts.push("error: " + s.error);
          const installBtn =
            '<button type="button" class="btn btn-sm btn-primary" ' +
            'data-action="push-install" data-name="' + escapeHtml(s.machine_name) + '">' +
            (s.installed ? "Reinstall" : "Push install") + "</button>";
          const diagBtn =
            '<button type="button" class="btn btn-sm btn-secondary" ' +
            'data-action="diagnose" data-name="' + escapeHtml(s.machine_name) + '">' +
            "Diagnose</button>";
          const uninstallBtn = s.installed
            ? '<button type="button" class="btn btn-sm btn-secondary" ' +
              'data-action="push-uninstall" data-name="' + escapeHtml(s.machine_name) + '">' +
              "Remove</button>"
            : "";
          return (
            '<div class="' + cls + '">' +
              '<span class="agent-name">' + escapeHtml(s.machine_name) + "</span>" +
              '<span class="agent-meta">' + escapeHtml(metaParts.join(" · ")) + "</span>" +
              '<div class="agent-actions">' + installBtn + diagBtn + uninstallBtn + "</div>" +
            "</div>"
          );
        })
        .join("");
      benchAgentListEl.innerHTML = html ||
        '<div class="muted small">No machines configured.</div>';
    } catch (err) {
      benchAgentListEl.innerHTML =
        '<div class="muted small">Could not load agent status.</div>';
    }
  }

  // ---- Admin mode -----------------------------------------------------------
  // The Admin PIN is the server-wide PIN configured by whoever installed the
  // dashboard (RDD_ADMIN_PIN in admin.env). Regular users never see this field.
  // When the admin signs in here, we cache the PIN in sessionStorage (cleared
  // on tab close) and the body gets the `admin-mode` class which reveals
  // admin-only UI. Every PIN-gated action still re-validates server-side.
  const ADMIN_PIN_KEY = "rdd_admin_pin";

  function getAdminPin() {
    try { return sessionStorage.getItem(ADMIN_PIN_KEY) || ""; }
    catch (_) { return ""; }
  }
  function setAdminPinCache(pin) {
    try {
      if (pin) sessionStorage.setItem(ADMIN_PIN_KEY, pin);
      else sessionStorage.removeItem(ADMIN_PIN_KEY);
    } catch (_) {}
  }
  function isAdmin() {
    return !!getAdminPin();
  }
  function syncAdminUi() {
    document.body.classList.toggle("admin-mode", isAdmin());
    const btn = document.getElementById("toggle-admin");
    if (btn) {
      btn.setAttribute("aria-pressed", isAdmin() ? "true" : "false");
      btn.title = isAdmin() ? "Sign out of admin mode" : "Sign in as admin";
      const label = btn.querySelector(".admin-label");
      if (label) label.textContent = isAdmin() ? "Admin: ON" : "Admin";
    }
    // Re-render so admin-only buttons appear/disappear in detail panel.
    if (selectedMachine) renderDetailPanel(selectedMachine);
  }

  async function ensureAdminPin() {
    let pin = getAdminPin();
    if (pin) return pin;
    if (!serverMeta.admin_pin_required) return "";
    pin = (window.prompt(
      "Enter the admin PIN (value of RDD_ADMIN_PIN in admin.env on the server):",
      ""
    ) || "").trim();
    if (pin) setAdminPinCache(pin);
    syncAdminUi();
    return pin;
  }

  const adminModal     = document.getElementById("admin-modal");
  const adminForm      = document.getElementById("admin-form");
  const adminPinInput  = document.getElementById("admin-pin-input");
  const adminErrorEl   = document.getElementById("admin-error");
  const toggleAdminBtn = document.getElementById("toggle-admin");

  function openAdminModal() {
    if (!adminModal) return;
    if (adminErrorEl) adminErrorEl.textContent = "";
    if (adminPinInput) adminPinInput.value = "";
    adminModal.classList.remove("hidden");
    setTimeout(function () { if (adminPinInput) adminPinInput.focus(); }, 30);
  }
  function closeAdminModal() {
    if (adminModal) adminModal.classList.add("hidden");
  }
  if (toggleAdminBtn) {
    toggleAdminBtn.addEventListener("click", function () {
      if (isAdmin()) {
        setAdminPinCache("");
        syncAdminUi();
        showToast("Signed out of admin mode.", false);
        return;
      }
      openAdminModal();
    });
  }
  if (adminForm) {
    adminForm.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const pin = (adminPinInput && adminPinInput.value || "").trim();
      if (!pin) return;
      if (adminErrorEl) adminErrorEl.textContent = "Checking\u2026";
      try {
        const res = await fetch("/api/v1/admin/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        });
        if (!res.ok) {
          if (adminErrorEl) adminErrorEl.textContent = "PIN rejected. Check RDD_ADMIN_PIN in admin.env on the server.";
          return;
        }
        setAdminPinCache(pin);
        syncAdminUi();
        closeAdminModal();
        showToast("Signed in as admin.", false);
      } catch (err) {
        if (adminErrorEl) adminErrorEl.textContent = "Network error verifying PIN.";
      }
    });
  }
  document.addEventListener("click", function (ev) {
    if (ev.target.matches("[data-close-admin]")) closeAdminModal();
  });

  // ---- Share modal (how to open this dashboard from other PCs on the LAN) --
  const shareModal        = document.getElementById("share-modal");
  const toggleShareBtn    = document.getElementById("toggle-share");
  const shareIpsEl        = document.getElementById("share-ips");
  const shareIpSelect     = document.getElementById("share-ip-select");
  const shareDownloadEl   = document.getElementById("share-download-shortcut");
  const shareCopyLinkBtn  = document.getElementById("share-copy-link");
  const shareLinkPreview  = document.getElementById("share-link-preview");

  function shortcutUrlFor(ip) {
    if (!ip) return "/api/v1/server/shortcut";
    return "/api/v1/server/shortcut?ip=" + encodeURIComponent(ip);
  }

  function updateShareSelection(ip, port, scheme) {
    const target = ip || (location.hostname || "this-pc");
    const usePort = port || 8080;
    const useScheme = scheme || "http";
    const url = useScheme + "://" + target + ":" + usePort + "/";
    if (shareDownloadEl) shareDownloadEl.href = shortcutUrlFor(ip);
    if (shareLinkPreview) shareLinkPreview.textContent = "Shortcut opens: " + url;
    if (shareCopyLinkBtn) shareCopyLinkBtn.dataset.url = url;
  }

  async function openShareModal() {
    if (!shareModal) return;
    shareModal.classList.remove("hidden");
    if (shareIpsEl) shareIpsEl.innerHTML = "<li class='muted small'>Detecting\u2026</li>";
    if (shareIpSelect) shareIpSelect.innerHTML = "<option>Detecting\u2026</option>";
    try {
      const res = await fetch("/api/v1/server/info");
      if (!res.ok) throw new Error("HTTP " + res.status);
      const info = await res.json();
      const port = info.port || 8080;
      const scheme = info.scheme || (info.https_enabled ? "https" : "http");
      const ips = (info.lan_ips || []).slice();
      if (info.hostname && !ips.includes(info.hostname)) {
        ips.push(info.hostname);
      }

      // Port label + firewall command line for the One-time step.
      const portLabel = document.getElementById("share-port-label");
      if (portLabel) portLabel.textContent = String(port);
      const fwCmd = document.getElementById("share-firewall-cmd");
      if (fwCmd) {
        fwCmd.textContent =
          'New-NetFirewallRule -DisplayName "Remote Desktop Dashboard" ' +
          '-Direction Inbound -Protocol TCP -LocalPort ' + port +
          ' -Action Allow -Profile Any';
      }

      // Show/hide the HTTPS cert-install card depending on server mode.
      const httpsCard = document.getElementById("share-https-card");
      const stepUrls = document.getElementById("share-step-urls");
      if (httpsCard) {
        if (info.https_enabled) {
          httpsCard.classList.remove("hidden");
          if (stepUrls) stepUrls.textContent = "4";
        } else {
          httpsCard.classList.add("hidden");
          if (stepUrls) stepUrls.textContent = "3";
        }
      }

      if (shareIpSelect) {
        shareIpSelect.innerHTML = ips
          .map(function (ip) { return "<option value=\"" + escapeHtml(ip) + "\">" + escapeHtml(ip) + "</option>"; })
          .join("") || "<option value=\"\">(none detected)</option>";
        shareIpSelect.value = ips[0] || "";
        updateShareSelection(shareIpSelect.value, port, scheme);
        shareIpSelect.onchange = function () { updateShareSelection(shareIpSelect.value, port, scheme); };
      }
      if (shareIpsEl) {
        const items = ips.map(function (ip) {
          const url = scheme + "://" + ip + ":" + port + "/";
          return "<li><code>" + escapeHtml(url) + "</code>" +
            " <button type=\"button\" class=\"btn btn-ghost btn-xs share-ip-copy\" data-url=\"" + escapeHtml(url) + "\">Copy</button></li>";
        });
        shareIpsEl.innerHTML = items.length
          ? items.join("")
          : "<li class='muted small'>No LAN IPs detected on this server.</li>";
      }
    } catch (_) {
      if (shareIpsEl) shareIpsEl.innerHTML = "<li class='muted small'>Could not detect LAN IPs.</li>";
    }
  }
  function closeShareModal() {
    if (shareModal) shareModal.classList.add("hidden");
  }
  if (toggleShareBtn) toggleShareBtn.addEventListener("click", openShareModal);
  document.addEventListener("click", function (ev) {
    if (ev.target.matches("[data-close-share]")) closeShareModal();
    const copyBtn = ev.target.closest(".share-ip-copy");
    if (copyBtn) {
      const u = copyBtn.dataset.url;
      if (u) navigator.clipboard.writeText(u).then(function () { showToast("Copied " + u, false); });
    }
  });
  if (shareCopyLinkBtn) {
    shareCopyLinkBtn.addEventListener("click", function () {
      const u = shareCopyLinkBtn.dataset.url || "";
      if (!u) return;
      navigator.clipboard.writeText(u).then(function () { showToast("Copied " + u, false); });
    });
  }

  async function pushInstallAgent(name) {
    const pin = await ensureAdminPin();
    if (serverMeta.admin_pin_required && !pin) {
      showToast("Admin PIN required.", true);
      return;
    }
    showToast("Installing agent on " + name + "… (uses your monitor service account)", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/agent/install",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || data.error || "Install failed.", true);
        return;
      }
      const steps = (data.steps || [])
        .map(function (s) { return (s.ok ? "OK " : "FAIL ") + s.step; })
        .join(" -> ");
      if (data.ok) {
        showToast("Agent installed on " + name + ". " + steps, false);
      } else {
        showToast(
          (data.error || "Push install failed.") + "\n" + steps,
          true
        );
      }
      setTimeout(loadBenchAgents, 8000);
    } catch (err) {
      showToast("Network error pushing install: " + err, true);
    }
  }

  async function pushUninstallAgent(name) {
    const pin = await ensureAdminPin();
    if (serverMeta.admin_pin_required && !pin) {
      showToast("Admin PIN required.", true);
      return;
    }
    if (!window.confirm("Remove the bench agent from " + name + "?")) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/agent/uninstall",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || data.error || "Uninstall failed.", true);
        return;
      }
      showToast(
        data.ok ? "Agent removed from " + name : (data.error || "Uninstall partial."),
        !data.ok
      );
      setTimeout(loadBenchAgents, 1500);
    } catch (err) {
      showToast("Network error uninstalling: " + err, true);
    }
  }

  async function diagnoseAgent(name) {
    const pin = await ensureAdminPin();
    if (serverMeta.admin_pin_required && !pin) {
      showToast("Admin PIN required.", true);
      return;
    }
    showToast("Diagnosing " + name + "…", false);
    try {
      const q = pin ? "?admin_pin=" + encodeURIComponent(pin) : "";
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/agent/diagnostics" + q
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Diagnostics failed.", true);
        return;
      }
      showDiagModal(data);
    } catch (err) {
      showToast("Network error during diagnostics: " + err, true);
    }
  }

  function showDiagModal(d) {
    let modal = document.getElementById("diag-modal");
    if (!modal) {
      const html =
        '<div id="diag-modal" class="modal hidden" role="dialog" aria-modal="true">' +
          '<div class="modal-backdrop" data-action="close-diag"></div>' +
          '<div class="modal-box diag-box">' +
            '<h2 id="diag-title">Agent diagnostics</h2>' +
            '<div id="diag-body"></div>' +
            '<div class="form-actions">' +
              '<button type="button" class="btn btn-secondary" data-action="close-diag">Close</button>' +
            "</div>" +
          "</div>" +
        "</div>";
      document.body.insertAdjacentHTML("beforeend", html);
      modal = document.getElementById("diag-modal");
      modal.addEventListener("click", function (ev) {
        if (ev.target.dataset.action === "close-diag") {
          modal.classList.add("hidden");
        }
      });
    }

    const title = document.getElementById("diag-title");
    title.textContent = "Agent diagnostics — " + d.machine_name;

    const dv = d.dashboard_view || {};
    const cfg = d.config || {};

    const rows = [];
    rows.push(["Verdict",          d.verdict || "?"]);
    rows.push(["Dashboard sees agent",
      dv.online
        ? "ONLINE (heartbeat " + dv.seconds_ago + "s ago, v" + (dv.bench_agent_version || "?") + ")"
        : dv.last_seen
          ? "STALE (last heartbeat " + dv.seconds_ago + "s ago)"
          : "NEVER heard from"
    ]);
    rows.push(["SMB to bench",     d.smb_ok ? "OK" : ("FAIL: " + (d.smb_error || ""))]);
    rows.push(["config.json present", d.config_present ? "YES" : ("NO " + (d.config_error || ""))]);
    if (cfg.dashboard_url) rows.push(["config dashboard_url", cfg.dashboard_url]);
    if (cfg.machine_name)  rows.push(["config machine_name",  cfg.machine_name + (cfg.machine_name === d.machine_name ? " ✓" : " ✗ MISMATCH")]);
    rows.push(["bench-agent.log present", d.log_present ? "YES" : ("NO " + (d.log_error || ""))]);
    rows.push(["Scheduled task state",     d.task_state || (d.task_error ? "ERROR: " + d.task_error : "?")]);
    if (d.task_last_run)    rows.push(["Task last run",    d.task_last_run]);
    if (d.task_last_result) rows.push(["Task last result", d.task_last_result]);
    if (d.task_next_run)    rows.push(["Task next run",    d.task_next_run]);

    let html = '<table class="diag-table">';
    for (const [k, v] of rows) {
      html += "<tr><th>" + escapeHtml(k) + "</th><td>" + escapeHtml(String(v)) + "</td></tr>";
    }
    html += "</table>";

    if (d.log_tail && d.log_tail.length) {
      html +=
        '<h3 class="diag-subhead">bench-agent.log (last ' + d.log_tail.length + " lines)</h3>" +
        '<pre class="diag-log">' + escapeHtml(d.log_tail.join("\n")) + "</pre>";
    }

    document.getElementById("diag-body").innerHTML = html;
    modal.classList.remove("hidden");
  }

  if (benchAgentListEl) {
    benchAgentListEl.addEventListener("click", function (ev) {
      const btn = ev.target.closest("button[data-action]");
      if (!btn) return;
      const action = btn.dataset.action;
      const name = btn.dataset.name;
      if (!name) return;
      if (action === "push-install") pushInstallAgent(name);
      else if (action === "push-uninstall") pushUninstallAgent(name);
      else if (action === "diagnose") diagnoseAgent(name);
    });
  }

  if (benchRefreshBtn) {
    benchRefreshBtn.addEventListener("click", loadBenchAgents);
  }

  function loadMonitorSettings() {
    fetch("/api/v1/settings/monitor")
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (setDomain) setDomain.value = data.domain || "";
        if (setUsername) setUsername.value = data.username || "";
        if (setPassword) setPassword.value = "";
        if (settingsStatus) {
          settingsStatus.textContent = data.configured
            ? "Monitoring account is configured."
            : "Save the service account below to enable session details.";
        }
        if (data.monitor_configured !== undefined) {
          serverMeta.monitor_configured = data.configured;
          updateServerBanner(serverMeta);
        }
      })
      .catch(function () {});
  }

  if (settingsForm) {
    settingsForm.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const body = {
        domain: setDomain ? setDomain.value.trim() : "",
        username: setUsername ? setUsername.value.trim() : "",
        password: setPassword && setPassword.value ? setPassword.value : null,
        admin_pin: getAdminPin() || null,
      };
      try {
        const res = await fetch("/api/v1/settings/monitor", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        const data = await res.json().catch(function () {
          return {};
        });
        if (!res.ok) {
          showToast(data.detail || "Save failed", true);
          return;
        }
        serverMeta.monitor_configured = true;
        updateServerBanner(serverMeta);
        if (setPassword) setPassword.value = "";
        if (settingsStatus) settingsStatus.textContent = "Saved (encrypted on server).";
        showToast("Server credentials saved", false);
        loadDashboard();
      } catch (e) {
        showToast("Save failed", true);
      }
    });
  }

  if (setTestBtn) {
    setTestBtn.addEventListener("click", async function () {
      const host = setTestHost ? setTestHost.value.trim() : "";
      if (!host) {
        showToast("Enter a bench IP or hostname to test", true);
        return;
      }
      setTestBtn.disabled = true;
      if (settingsStatus) settingsStatus.textContent = "Testing (up to 60s)…";
      const ctrl = new AbortController();
      const timer = setTimeout(function () {
        ctrl.abort();
      }, 70000);
      try {
        const res = await fetch("/api/v1/settings/monitor/test", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: ctrl.signal,
          body: JSON.stringify({
            host: host,
            admin_pin: getAdminPin() || null,
          }),
        });
        clearTimeout(timer);
        const data = await res.json();
        if (!res.ok) {
          showToast(data.detail || "Test failed", true);
          return;
        }
        if (settingsStatus) settingsStatus.textContent = data.message || "";
        showToast(data.ok ? "Test OK" : data.message || "Test failed", !data.ok);
      } catch (e) {
        clearTimeout(timer);
        if (e.name === "AbortError") {
          showToast("Test timed out — server may still be busy; wait and retry", true);
        } else {
          showToast("Test failed: " + e.message, true);
        }
      } finally {
        setTestBtn.disabled = false;
      }
    });
  }

  function resetMachineForm() {
    editMachineId.value = "";
    mfName.value = "";
    mfName.disabled = false;
    mfHostname.value = "";
    mfIp.value = "";
    if (mfDescription) mfDescription.value = "";
    if (mfBoard) mfBoard.value = "";
    if (mfAccess) mfAccess.value = "";
  }

  function fillMachineForm(m) {
    editMachineId.value = String(m.id);
    mfName.value = m.name;
    mfName.disabled = true;
    mfHostname.value = m.hostname || "";
    mfIp.value = m.ip_address || "";
    if (mfDescription) mfDescription.value = m.description || "";
    if (mfBoard) mfBoard.value = m.board || "";
    if (mfAccess) mfAccess.value = m.access_note || "";
    mfHostname.focus();
  }

  if (mfCancel) mfCancel.addEventListener("click", resetMachineForm);

  if (machineForm) machineForm.addEventListener("submit", async function (ev) {
    ev.preventDefault();
    const payload = {
      name: mfName.value.trim().toUpperCase(),
      hostname: mfHostname.value.trim(),
      ip_address: mfIp.value.trim(),
      description: mfDescription ? mfDescription.value.trim() : null,
      board: mfBoard ? mfBoard.value.trim() : null,
      access_note: mfAccess ? mfAccess.value.trim() : null,
    };
    const id = editMachineId.value;
    try {
      let res;
      if (id) {
        res = await fetch("/api/v1/machines/" + id, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            hostname: payload.hostname,
            ip_address: payload.ip_address,
            description: payload.description,
            board: payload.board,
            access_note: payload.access_note,
          }),
        });
      } else {
        res = await fetch("/api/v1/machines", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        showToast(data.detail || "Save failed", true);
        return;
      }
      showToast(id ? "Updated " + payload.name : "Created " + payload.name, false);
      resetMachineForm();
      loadDashboard();
    } catch (e) {
      showToast("Save failed", true);
    }
  });

  async function deleteMachineByName(name) {
    if (!confirm("Delete machine " + name + " from the dashboard?")) return;
    try {
      const res = await fetch(
        "/api/v1/machines/by-name/" + encodeURIComponent(name),
        { method: "DELETE" }
      );
      if (!res.ok) {
        const data = await res.json().catch(function () {
          return {};
        });
        showToast(data.detail || "Delete failed", true);
        return;
      }
      showToast("Deleted " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Delete failed", true);
    }
  }

  function handleMachineAction(ev) {
    const btn = ev.target.closest("button[data-action]");
    if (!btn) return;
    const name = btn.getAttribute("data-name");
    const action = btn.getAttribute("data-action");
    if (btn.disabled || btn.getAttribute("aria-disabled") === "true") {
      const tip = btn.getAttribute("title");
      if (tip) showToast(tip, true);
      return;
    }
    if (action === "connect") connectMachine(name);
    if (action === "reserve") reserveMachine(name);
    if (action === "release") releaseMachine(name);
    if (action === "admin-release") adminReleaseMachine(name);
    if (action === "kick-others") kickOthersMachine(name);
    if (action === "emergency-restore") emergencyRestoreRdp(name);
    if (action === "delete") deleteMachineByName(name);
    if (action === "edit") {
      const m = machines.find(function (x) { return x.name === name; });
      if (m) {
        fillMachineForm(m);
        openDrawer(manageDrawer);
      }
    }
  }
  if (statusRowsEl)    statusRowsEl.addEventListener("click", handleMachineAction);
  if (detailPanelEl)   detailPanelEl.addEventListener("click", handleMachineAction);
  if (machineAdminList) machineAdminList.addEventListener("click", handleMachineAction);

  window.addEventListener("beforeunload", stopAllHeartbeats);

  function connect() {
    const socket = new WebSocket(wsUrl());
    socket.onopen = function () {
      setWsStatus("ok", "Live");
    };
    socket.onmessage = function (event) {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "machines_update" && Array.isArray(data.machines)) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      } catch (e) {
        /* ignore malformed websocket payloads */
      }
    };
    socket.onclose = function () {
      setWsStatus("warn", "Reconnecting…");
      setTimeout(connect, 3000);
    };
    socket.onerror = function () {
      setWsStatus("warn", "Reconnecting…");
    };
    setInterval(function () {
      if (socket.readyState === WebSocket.OPEN) socket.send("ping");
    }, 25000);
  }

  function refreshIntervalMs() {
    const op = getOperator();
    const mine = machines.some(function (m) {
      return m.is_locked && m.locked_by === op;
    });
    return mine ? 8000 : 20000;
  }

  let refreshTimer = null;
  function scheduleRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(function () {
      loadDashboard();
      scheduleRefresh();
    }, refreshIntervalMs());
  }

  function loadHealth() {
    const verEl = document.getElementById("app-version");
    fetch("/health")
      .then(function (r) {
        return r.json();
      })
      .then(function (h) {
        if (verEl && h.version) verEl.textContent = "v" + h.version;
        if (h.monitor_configured !== undefined) {
          serverMeta.monitor_configured = h.monitor_configured;
          serverMeta.monitor_hint = h.monitor_hint;
          serverMeta.admin_pin_required = h.admin_pin_required;
        }
        if (h.users_can_connect !== undefined) {
          serverMeta.users_can_connect = h.users_can_connect;
        }
        if (h.users_can_manage_machines !== undefined) {
          serverMeta.users_can_manage_machines = h.users_can_manage_machines;
        }
        updateServerBanner(serverMeta);
        applyPermissionsUi();
      })
      .catch(function () {});
  }

  if (statusRowsEl) {
    statusRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Loading machines\u2026</td></tr>';
  }
  setWsStatus("warn", "Connecting\u2026");
  syncAdminUi();
  loadHealth();
  loadOperatorList();
  loadDashboard().finally(function () {
    setTimeout(connect, 1500);
    scheduleRefresh();
  });
})();
