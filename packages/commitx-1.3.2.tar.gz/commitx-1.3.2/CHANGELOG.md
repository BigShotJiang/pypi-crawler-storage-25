# Changelog

All notable changes to **CommitX** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.2] - 2026-04-06

### Fixed
- **PyPI Upload Logic:** Corrected a `400 Bad Request` during upload caused by duplicate files in the ZIP archive (simplified `pyproject.toml` includes).

## [1.3.1] - 2026-04-06

### Fixed
- **Packaging Logic:** Resolved `ModuleNotFoundError` by correcting the `src` layout configuration in `pyproject.toml`.

## [1.3.0] - 2026-04-06

### Changed
- **Official Rebrand:** Project renamed from "Repo Committer" to **CommitX**.
- **CLI Command:** Global command changed from `repo-committer` to `commitx`.
- **UI Refresh:** Updated logo and branding across the dashboard.

## [1.2.0] - 2026-04-06

### Added
- **Official PyPI Release:** Now available via `pip install repo-committer`.
- **Global CLI Command:** Launch the tool from any terminal using `repo-committer`.
- **Auto-Browser Launch:** Automatically opens the dashboard in your default browser on startup.
- **MIT License:** Added official licensing for open-source distribution.

### Changed
- **Package Restructuring:** Migrated to a professional `src/` layout for better distribution.
- **Standardized Setup:** Replaced `requirements.txt` with modern `pyproject.toml` configuration.

## [1.1.0] - 2026-04-06

### Added
- **Batch Processing Mode:** New endpoint and UI tab to generate any number of random commits across a specified date range.
- **Premium CLI-GUI Design:** Complete visual overhaul with a technical coding aesthetic, terminal-style logs, and a futuristic workspace layout.
- **Incremental Commit Spacing:** Support for multiple commits at a single timestamp with automatic 1-minute sequential offsets.
- **Creator UI Integration:** Added author credits to the interface with direct links to the GitHub profile.

### Changed
- **UI Architecture:** Migrated to a dual-tab system for seamless switching between Single and Batch modes.
- **Enhanced Logging:** Replaced simple alerts with a high-fidelity terminal component for execution feedback.

## [1.0.0] - 2026-04-06

### Added
- **Initial Release:** Fully functional local Flask web app to backdate or forward-date GitHub commits.
- **Python Backend:** Included `app.py` utilizing the `subprocess` module to manipulate `GIT_AUTHOR_DATE` and `GIT_COMMITTER_DATE`.
- **Beautiful UI Frontend:** Added `templates/index.html` featuring a glassmorphism design, clean animations, and a sleek HTML5 `datetime-local` input picker.
- **Activity Log Tracking:** Implemented local `activity.log` file tracking to push timestamped string logs with every commit natively.
- **Comprehensive README:** Added a beautifully documented `README.md` with setup instructions and project details.

### Changed
- **Branding:** Renamed the initial concept from "Ripo Comiter" & "Time Travel Commits" to the official **Repo Committer**.

### Fixed
- Handled dynamic parsing of both default HTML5 `datetime-local` payloads and fallback date strings.
- Implemented robust error handling from UI (loading spinners, disabled buttons) downstream to Flask server-side subprocess responses.

---

*Authored by [n4od](https://github.com/n4od)*
