# CommitX ⏳

![CommitX UI](https://via.placeholder.com/800x400?text=CommitX+UI+Demo)

A premium CLI tool designed for developers to manage their Git contribution history with a sleek, modern desktop-web interface. **CommitX** allows you to seamlessly backdate or forward-date your commits using a high-fidelity "CLI-GUI" dashboard.

## Features ✨

- **Premium CLI-GUI Interface**: A distinctive "modern coding" aesthetic featuring responsive panels, terminal styling, and real-time process logs.
- **Single Commit Mode**: Execute pinpointed commits at any chosen timestamp, with support for multiple iterations (automatic 1-minute increments).
- **Batch Processing**: Distribute any number of commits randomly across a specified date range—ideal for populating your contribution graph at scale.
- **Git Hook Integration**: Modifies `GIT_AUTHOR_DATE` and `GIT_COMMITTER_DATE` to track an `activity.log` file without manual terminal configurations.
- **Lightweight & Portable**: Runs entirely within a local Flask environment, accessible via a global terminal command.

## Setup & Installation 🛠️

Ensure you have [Python 3.8+](https://www.python.org/) and Git installed.

```bash
pip install commitx
```

## Usage 🧠

Once installed, you can launch the tool from **any** repository directory on your machine:

1. Open your terminal and `cd` into your project.
2. Run the command:
   ```bash
   commitx
   ```
3. The application will automatically launch your default web browser to the control panel at `http://127.0.0.1:5000`.
4. Select your mode (**Single** or **Batch**), pick your dates, and hit "Execute Script".
5. Watch the real-time terminal logs confirm your commits!

## Important Note ⚠️

This application alters your local `.git` metadata for particular commits. To reflect these backdated changes on GitHub, you must run `git push origin [branch-name]`. Ensure your terminal has standard Git authorship (`user.email` and `user.name`) set correctly.

## Author & Credits 🚀

**CommitX** was created and brought to life by **[n4od](https://github.com/n4od)**.
If this tool made your Git history look a whole lot greener, consider giving the repo a ⭐️ and checking out my other projects!

---
*Built with passion by [@n4od](https://github.com/n4od).*

## License 📜

Distributed under the MIT License. See `LICENSE` for more information.
