from flask import Flask, render_template, request, jsonify
import subprocess
import os
import datetime
import random
import webbrowser
import threading

# Ensure Flask finds the templates folder when installed as a package
template_dir = os.path.join(os.path.dirname(__file__), 'templates')
app = Flask(__name__, template_folder=template_dir)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/commit', methods=['POST'])
def commit():
    date_str = request.form.get('date')
    num_commits_str = request.form.get('num_commits', '1')

    if not date_str:
        return jsonify({"status": "error", "message": "No date provided"}), 400

    try:
        num_commits = int(num_commits_str)
        if num_commits <= 0:
            return jsonify({"status": "error", "message": "Number of commits must be a positive integer"}), 400
    except ValueError:
        return jsonify({"status": "error", "message": "Invalid number of commits"}), 400

    try:
        # Expected format from HTML5 datetime-local: YYYY-MM-DDTHH:MM
        date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%dT%H:%M")
    except ValueError:
        try:
             date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
             return jsonify({"status": "error", "message": "Invalid date format"}), 400

    log_file = "activity.log"
    env = os.environ.copy()
    
    success_count = 0
    output_log = ""
    
    for i in range(num_commits):
        # Add 1 minute incremental spacing if generating multiple commits
        current_commit_time = date_obj + datetime.timedelta(minutes=i)
        formatted_date = current_commit_time.strftime("%Y-%m-%d %H:%M:%S")
        
        try:
            with open(log_file, "a") as f:
                f.write(f"Commit at {formatted_date}\n")
                
            env["GIT_AUTHOR_DATE"] = formatted_date
            env["GIT_COMMITTER_DATE"] = formatted_date
            
            subprocess.run(["git", "add", "activity.log"], check=True, cwd=os.getcwd(), capture_output=True, text=True)
            res = subprocess.run(
                ["git", "commit", "-m", f"Activity log update for {formatted_date}"],
                env=env,
                check=True,
                cwd=os.getcwd(),
                capture_output=True,
                text=True
            )
            success_count += 1
            output_log += f"Committed: {formatted_date}\n"
        except Exception as e:
            return jsonify({"status": "error", "message": f"Failed during commit generation: {str(e)}", "completed": success_count}), 500

    return jsonify({"status": "success", "message": f"Successfully backdated {success_count} commits starting at {date_obj.strftime('%Y-%m-%d %H:%M:%S')}.\n\n{output_log}"})

@app.route('/batch_commit', methods=['POST'])
def batch_commit():
    start_date_str = request.form.get('start_date')
    end_date_str = request.form.get('end_date')
    num_commits_str = request.form.get('num_commits')

    if not start_date_str or not end_date_str or not num_commits_str:
        return jsonify({"status": "error", "message": "Missing required fields"}), 400

    try:
        num_commits = int(num_commits_str)
        if num_commits <= 0:
            return jsonify({"status": "error", "message": "Number of commits must be a positive integer"}), 400
    except ValueError:
        return jsonify({"status": "error", "message": "Invalid number of commits"}), 400

    # Parse dates
    try:
        start_date = datetime.datetime.strptime(start_date_str, "%Y-%m-%dT%H:%M")
    except ValueError:
        try:
             start_date = datetime.datetime.strptime(start_date_str, "%Y-%m-%d")
        except ValueError:
             return jsonify({"status": "error", "message": "Invalid start date format"}), 400
             
    try:
        end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%dT%H:%M")
    except ValueError:
        try:
             end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%d")
        except ValueError:
             return jsonify({"status": "error", "message": "Invalid end date format"}), 400

    if start_date >= end_date:
        return jsonify({"status": "error", "message": "Start date must be before end date"}), 400

    time_diff = end_date - start_date
    diff_seconds = time_diff.total_seconds()
    
    success_count = 0
    log_file = "activity.log"
    env = os.environ.copy()
    
    # Generate random dates and sort them to keep commit history somewhat logical
    random_dates = []
    for _ in range(num_commits):
        random_second = random.uniform(0, diff_seconds)
        commit_date = start_date + datetime.timedelta(seconds=random_second)
        random_dates.append(commit_date)
        
    random_dates.sort()
    
    output_log = ""
    for commit_date in random_dates:
        formatted_date = commit_date.strftime("%Y-%m-%d %H:%M:%S")
        try:
            with open(log_file, "a") as f:
                f.write(f"Batch commit at {formatted_date}\n")
                
            env["GIT_AUTHOR_DATE"] = formatted_date
            env["GIT_COMMITTER_DATE"] = formatted_date
            
            subprocess.run(["git", "add", "activity.log"], check=True, cwd=os.getcwd(), capture_output=True, text=True)
            res = subprocess.run(
                ["git", "commit", "-m", f"Batch activity log update for {formatted_date}"],
                env=env,
                check=True,
                cwd=os.getcwd(),
                capture_output=True,
                text=True
            )
            success_count += 1
            output_log += f"Committed: {formatted_date}\n"
        except Exception as e:
            return jsonify({"status": "error", "message": f"Failed during batch commit: {str(e)}", "completed": success_count}), 500
            
    return jsonify({"status": "success", "message": f"Successfully backdated {success_count} commits between {start_date.strftime('%Y-%m-%d')} and {end_date.strftime('%Y-%m-%d')}.\n\n{output_log}"})

def main():
    url = "http://127.0.0.1:5000"
    print(f"Launching CommitX at {url}...")
    threading.Timer(1.25, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=5000, debug=False)

if __name__ == '__main__':
    main()
