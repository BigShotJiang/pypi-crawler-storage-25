"""AgentSpec — blueprint for an agent generated at runtime by the architect model."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import ClassVar


@dataclass
class AgentSpec:
    """Blueprint for an agent — generated at runtime by the architect model."""
    role: str
    goal: str
    domain: str          # "backend" | "frontend" | "devops" | "qa" | "architect"
    constraints: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)  # roles this agent waits for

    def to_system_prompt(self, project_context: str = "",
                         prior_outputs: dict[str, str] | None = None) -> str:
        lines = [
            f"You are a {self.role}.",
            f"Your goal: {self.goal}",
            "",
            "Constraints:",
            *[f"  - {c}" for c in self.constraints],
        ]
        if project_context:
            lines += ["", "Project context:", project_context]
        if prior_outputs:
            lines += ["", "Work done by other agents (use this as your foundation):"]
            for role, output in prior_outputs.items():
                lines += [f"\n[{role}]", output[:3000]]
        lines += [
            "",
            "Instructions:",
            "1. Use your tools to read existing code before writing anything.",
            "2. Write complete, working code — no placeholders.",
            "3. After writing files, verify they are correct.",
            "4. Return a brief summary of what you did.",
        ]
        return "\n".join(lines)


@dataclass
class AgentHandoff:
    """Structured handoff from one agent to the next.

    Instead of passing raw full output, agents communicate through
    a structured handoff that includes:
    - A summary of what was done
    - Files created/edited
    - What the next agent should focus on
    - Any decisions that constrain downstream work
    """
    from_role: str
    to_role: str | None = None  # None = broadcast to all downstream
    summary: str = ""
    files_created: list[str] = field(default_factory=list)
    files_edited: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)
    next_steps: str = ""

    # Maximum character budgets for each field in to_context_block()
    _SUMMARY_MAX: ClassVar[int] = 600
    _DECISIONS_MAX: ClassVar[int] = 200
    _FILES_MAX: ClassVar[int] = 150
    _NEXT_STEPS_MAX: ClassVar[int] = 120

    def to_context_block(self) -> str:
        """Render as a compact context block for the next agent.

        Each field is capped to keep the total output under ~1000 chars
        for typical use, regardless of how large the raw fields are.
        """
        parts = [f"[{self.from_role} → {self.to_role or 'all'}]"]

        if self.summary:
            s = self.summary
            if len(s) > self._SUMMARY_MAX:
                s = s[:self._SUMMARY_MAX] + "…"
            parts.append(f"Summary: {s}")

        if self.decisions:
            joined = "; ".join(self.decisions)
            if len(joined) > self._DECISIONS_MAX:
                joined = joined[:self._DECISIONS_MAX] + "…"
            parts.append(f"Decisions: {joined}")

        if self.files_created:
            joined = ", ".join(self.files_created)
            if len(joined) > self._FILES_MAX:
                joined = joined[:self._FILES_MAX] + "…"
            parts.append(f"Created: {joined}")

        if self.files_edited:
            joined = ", ".join(self.files_edited)
            if len(joined) > self._FILES_MAX:
                joined = joined[:self._FILES_MAX] + "…"
            parts.append(f"Edited: {joined}")

        if self.next_steps:
            ns = self.next_steps
            if len(ns) > self._NEXT_STEPS_MAX:
                ns = ns[:self._NEXT_STEPS_MAX] + "…"
            parts.append(f"Next: {ns}")

        return "\n".join(parts)
