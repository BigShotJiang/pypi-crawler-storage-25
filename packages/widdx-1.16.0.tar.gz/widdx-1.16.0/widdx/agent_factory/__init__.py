"""Dynamic agent factory — designs and runs multi-agent teams with real tool access."""
from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FuturesTimeoutError
from ..agents.registry import AgentRegistry
from ..ui.arabic import _d
from .runner import AgentRunner
from .spec import AgentHandoff, AgentSpec

# Re-export for backward compatibility
__all__ = ["AgentSpec", "AgentHandoff", "AgentRunner", "AgentFactory"]


class AgentFactory:
    """Designs and runs multi-agent teams where each agent has real tool access."""

    def __init__(self, router) -> None:
        self._router = router

    # ── Team design ────────────────────────────────────────────────────

    def generate_team(self, task_description: str, complexity: int) -> list[AgentSpec]:
        """Ask the architect model to design the optimal agent team."""
        system = self._team_designer_prompt()
        user = (
            f"Task: {task_description}\n"
            f"Complexity: {complexity}/5\n\n"
            f"Design the minimal effective agent team. Return valid JSON only."
        )
        result = self._router.call_architect(system, user, max_tokens=4096)
        if "error" in result:
            return self._fallback_team(task_description)

        specs = self._parse_specs(result.get("text", ""))
        return specs if specs else self._fallback_team(task_description)

    def _team_designer_prompt(self) -> str:
        available = ", ".join(AgentRegistry.domains())
        return f"""You are an AI agent team architect. Design minimal, effective teams.

Return a JSON array of agent specs:
[
  {{
    "role": "Backend Architect",
    "goal": "Build FastAPI endpoints with SQLAlchemy models",
    "domain": "backend",
    "constraints": ["Use async/await", "Pydantic v2 schemas"],
    "depends_on": []
  }},
  {{
    "role": "Frontend Developer",
    "goal": "Build React components that consume the backend API",
    "domain": "frontend",
    "constraints": ["TypeScript", "Tailwind CSS", "Handle loading/error states"],
    "depends_on": ["Backend Architect"]
  }}
]

Available domains (use these exact values): {available}
depends_on: list of role names this agent must wait for (empty = runs first)

Rules:
- complexity 1-2: 1 agent (fullstack)
- complexity 3: 2 agents max
- complexity 4-5: 3-4 agents max (architect first, then backend, then frontend, then qa)
- Each agent must have a distinct domain
- depends_on creates the execution order
- Return ONLY the JSON array"""

    def _parse_specs(self, raw: str) -> list[AgentSpec]:
        raw = raw.strip()
        # Strip markdown fences
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1].strip()
            if raw.endswith("```"):
                raw = raw[:-3].strip()
        # Find JSON array
        start = raw.find("[")
        end = raw.rfind("]")
        if start == -1 or end == -1:
            return []
        try:
            data = json.loads(raw[start:end + 1])
        except json.JSONDecodeError:
            return []
        specs = []
        for item in data:
            specs.append(AgentSpec(
                role=item.get("role", "Developer"),
                goal=item.get("goal", ""),
                domain=item.get("domain", "fullstack"),
                constraints=item.get("constraints", []),
                depends_on=item.get("depends_on", []),
            ))
        return specs

    def _fallback_team(self, task: str) -> list[AgentSpec]:
        return [AgentSpec(
            role="Full-Stack Developer",
            goal=task,
            domain="fullstack",
            constraints=["Write clean code", "Handle errors", "No placeholders"],
            depends_on=[],
        )]

    # ── Team execution ─────────────────────────────────────────────────

    def execute_agent(self, agent, task_context, model_choice="executor"):
        """Legacy compatibility wrapper. Use AgentRunner directly instead."""
        import logging
        logger = logging.getLogger(__name__)
        logger.warning("execute_agent is deprecated, use AgentRunner directly")
        runner = AgentRunner(agent, self._router)
        return runner.run(task_context)

    def execute_team(
        self,
        specs: list[AgentSpec],
        task: str,
        task_id: str,
        memory,
        project_context: str = "",
    ) -> str:
        """Execute agents with dependency-aware parallelism.

        Agents whose ``depends_on`` list is empty (or whose dependencies have
        already completed) are launched concurrently via a thread pool.
        Agents that depend on others wait until all their dependencies finish.

        Communication between agents uses AgentHandoff objects that summarise
        what was done, which files were touched, and what the next agent should
        focus on.
        """
        from .. import ui
        c = ui.get_console()

        completed: dict[str, str] = {}        # role → output text
        all_results: list[dict] = []
        handoffs: list[AgentHandoff] = []
        remaining = list(specs)

        def _run_agent(spec: AgentSpec, prior: dict[str, str]) -> dict:
            """Execute one agent and return its result dict."""
            runner = AgentRunner(spec, self._router, project_context)
            return runner.run(task, prior_outputs=prior if prior else None)

        while remaining:
            # Find all agents whose dependencies are satisfied
            ready = [
                s for s in remaining
                if all(dep in completed for dep in s.depends_on)
            ]
            if not ready:
                # Circular dependency guard — warn the user and run the first
                # remaining agent to avoid an infinite loop.
                c.print(
                    f"  [warning]⚠ Circular dependency detected among: "
                    f"{', '.join(s.role for s in remaining)}. "
                    f"Running '{remaining[0].role}' without waiting for its dependencies.[/]"
                )
                ready = [remaining[0]]

            # Remove ready agents from the queue before launching
            for s in ready:
                remaining.remove(s)

            # Build prior context for each ready agent
            prior_map: dict[str, dict[str, str]] = {}
            for spec in ready:
                prior = {role: completed[role] for role in spec.depends_on if role in completed}
                relevant_handoffs = [
                    h for h in handoffs
                    if h.to_role is None or h.to_role == spec.role
                ]
                enriched: dict[str, str] = dict(prior)
                for h in relevant_handoffs:
                    enriched[f"__handoff__{h.from_role}"] = h.to_context_block()
                prior_map[spec.role] = enriched

            # Announce all agents in this wave
            for spec in ready:
                c.print()
                c.print(f"  [brand]◆ Agent:[/] [highlight]{_d(spec.role)}[/] [dim]({_d(spec.domain)})[/]")
                c.print(f"  [dim]  Goal: {_d(spec.goal[:80])}[/]")
                relevant_handoffs = [
                    h for h in handoffs
                    if h.to_role is None or h.to_role == spec.role
                ]
                if relevant_handoffs:
                    c.print(f"  [dim]  Handoffs from: {', '.join(_d(h.from_role) for h in relevant_handoffs)}[/]")

            if len(ready) == 1:
                # Single agent — run directly (no thread overhead)
                spec = ready[0]
                result = _run_agent(spec, prior_map[spec.role])
                batch_results = [(spec, result)]
            else:
                # Multiple independent agents — run in parallel
                c.print(f"  [dim]  Running {len(ready)} agents in parallel…[/]")
                batch_results = []
                # 5-minute timeout per wave — prevents a hung agent from blocking forever
                _AGENT_TIMEOUT_SECS = 300
                with ThreadPoolExecutor(max_workers=len(ready)) as pool:
                    future_to_spec = {
                        pool.submit(_run_agent, spec, prior_map[spec.role]): spec
                        for spec in ready
                    }
                    try:
                        for future in as_completed(future_to_spec, timeout=_AGENT_TIMEOUT_SECS):
                            spec = future_to_spec[future]
                            try:
                                result = future.result()
                            except Exception as exc:
                                result = {
                                    "role": spec.role,
                                    "domain": spec.domain,
                                    "output": f"Agent failed: {exc}",
                                    "created_files": [],
                                    "edited_files": [],
                                    "latency_ms": 0,
                                    "tool_calls": 0,
                                }
                            batch_results.append((spec, result))
                    except FuturesTimeoutError:
                        # Collect results from futures that finished; mark timed-out ones as failed
                        for future, spec in future_to_spec.items():
                            if future.done():
                                try:
                                    result = future.result()
                                except Exception as exc:
                                    result = {
                                        "role": spec.role,
                                        "domain": spec.domain,
                                        "output": f"Agent failed: {exc}",
                                        "created_files": [],
                                        "edited_files": [],
                                        "latency_ms": _AGENT_TIMEOUT_SECS * 1000,
                                        "tool_calls": 0,
                                    }
                            else:
                                future.cancel()
                                result = {
                                    "role": spec.role,
                                    "domain": spec.domain,
                                    "output": f"Agent timed out after {_AGENT_TIMEOUT_SECS}s",
                                    "created_files": [],
                                    "edited_files": [],
                                    "latency_ms": _AGENT_TIMEOUT_SECS * 1000,
                                    "tool_calls": 0,
                                }
                                c.print(f"  [warning]⚠ Agent '{spec.role}' timed out after {_AGENT_TIMEOUT_SECS}s[/]")
                            # Avoid duplicates — only add if not already collected
                            if not any(r[1]["role"] == spec.role for r in batch_results):
                                batch_results.append((spec, result))

            # Process results from this wave
            for spec, result in batch_results:
                completed[spec.role] = result["output"]
                all_results.append(result)

                next_roles = [
                    s.role for s in specs
                    if spec.role in s.depends_on
                ]
                decisions, extracted_next = _extract_handoff_data(result["output"])
                composed_next = (
                    f"Focus on: {next_roles[0]}" if next_roles else ""
                )
                if extracted_next:
                    composed_next = (
                        f"{composed_next} | {extracted_next}"
                        if composed_next
                        else extracted_next
                    )
                handoff = AgentHandoff(
                    from_role=spec.role,
                    to_role=next_roles[0] if len(next_roles) == 1 else None,
                    summary=_summarize_for_handoff(result["output"]),
                    files_created=result.get("created_files", []),
                    files_edited=result.get("edited_files", []),
                    decisions=decisions,
                    next_steps=composed_next,
                )
                handoffs.append(handoff)

                memory.log_agent_run(
                    task_id=task_id,
                    agent_role=spec.role,
                    agent_goal=spec.goal,
                    model_used="deepseek",
                    success="error" not in result.get("output", "").lower(),
                    output_summary=handoff.summary,
                    latency_ms=result["latency_ms"],
                )

                created = result.get("created_files", [])
                edited = result.get("edited_files", [])
                if created or edited:
                    for f in created:
                        c.print(f"  [success]  ✚[/] [text]{f}[/]")
                    for f in edited:
                        c.print(f"  [warning]  ~[/] [text]{f}[/]")

                c.print(f"  [dim]  Done in {result['latency_ms']}ms | {result['tool_calls']} tool calls[/]")

        # ── Conflict detection ────────────────────────────────────
        conflicts = _detect_file_conflicts(all_results)
        if conflicts:
            c.print()
            c.print("  [warn]⚠ File conflicts detected:[/]")
            for fname, roles in conflicts.items():
                c.print(f"    [dim]{fname}:[/] [text]{', '.join(roles)}[/]")

        return _synthesize_final(all_results, handoffs, task, conflicts)

# ── Helpers ────────────────────────────────────────────────────────────────

def _summarize_for_handoff(output: str, max_chars: int = 600) -> str:
    """Compress agent output into a concise summary for handoff.

    Extracts the most relevant parts: first meaningful paragraph,
    file listings, and key decisions.
    """
    if len(output) <= max_chars:
        return output

    # Take first meaningful paragraph(s)
    lines = output.strip().split("\n")
    summary_lines: list[str] = []
    total = 0
    for line in lines:
        line = line.strip()
        if not line:
            if summary_lines:
                summary_lines.append("")
            continue
        # Skip markdown headers that are just formatting
        if line.startswith("```") or line.startswith("---"):
            continue
        if total + len(line) > max_chars:
            break
        summary_lines.append(line)
        total += len(line) + 1

    result = "\n".join(summary_lines).strip()
    if len(result) < len(output):
        result += f"\n... ({len(output)} chars total)"
    return result


def _extract_handoff_data(output: str) -> tuple[list[str], str]:
    """Extract structured decisions and next steps from agent output.

    Looks for ``## Decisions`` and ``## Next Steps`` sections.
    Returns (decisions_list, next_steps_string).
    """
    decisions: list[str] = []
    next_steps_parts: list[str] = []

    current_section: str | None = None
    for line in output.split("\n"):
        stripped = line.strip()
        lower = stripped.lower()

        if lower.startswith("## decisions"):
            current_section = "decisions"
            continue
        elif lower.startswith("## next steps") or lower.startswith("## next step"):
            current_section = "next"
            continue
        elif stripped.startswith("## "):
            current_section = None
            continue

        if current_section == "decisions":
            # Match "- Decision: ..." or "- **Decision:** ..." or just "- ..."
            if stripped.startswith("- "):
                text = stripped[2:].strip()
                # Remove bold markers
                text = text.removeprefix("**").removesuffix("**")
                if text.lower().startswith("decision:"):
                    text = text[len("decision:"):].strip()
                elif text.lower().startswith("decision"):
                    text = text[len("decision"):].strip().lstrip(":")
                decisions.append(text[:200])
        elif current_section == "next":
            if stripped.startswith("- "):
                text = stripped[2:].strip()
                text = text.removeprefix("**").removesuffix("**")
                if text.lower().startswith("next step:"):
                    text = text[len("next step:"):].strip()
                elif text.lower().startswith("next:"):
                    text = text[len("next:"):].strip()
                next_steps_parts.append(text[:120])

    next_steps = " | ".join(next_steps_parts) if next_steps_parts else ""
    return decisions, next_steps


def _detect_file_conflicts(results: list[dict]) -> dict[str, list[str]]:
    """Detect when multiple agents touch the same file.

    Returns {filename: [role1, role2, ...]} for files with conflicts.
    """
    file_owners: dict[str, list[str]] = {}
    for r in results:
        role = r.get("role", "unknown")
        for f in r.get("created_files", []):
            file_owners.setdefault(f, []).append(role)
        for f in r.get("edited_files", []):
            file_owners.setdefault(f, []).append(role)
    return {f: roles for f, roles in file_owners.items() if len(roles) > 1}


def _synthesize_final(
    results: list[dict],
    handoffs: list,
    task: str,
    conflicts: dict[str, list[str]],
) -> str:
    """Synthesize all agent results into a clean final summary."""
    parts = [f"# Multi-Agent Result: {task}\n"]

    # File manifest
    all_created: list[str] = []
    all_edited: list[str] = []
    for r in results:
        all_created.extend(r.get("created_files", []))
        all_edited.extend(r.get("edited_files", []))
    all_created = list(dict.fromkeys(all_created))
    all_edited = list(dict.fromkeys(all_edited))

    if all_created or all_edited:
        parts.append("## Files Changed\n")
        for f in all_created:
            parts.append(f"- ✚ `{f}` (created)")
        for f in all_edited:
            parts.append(f"- ~ `{f}` (edited)")
        parts.append("")

    # Conflict warning
    if conflicts:
        parts.append("## ⚠ File Conflicts\n")
        for fname, roles in conflicts.items():
            parts.append(f"- `{fname}` was touched by: {', '.join(roles)}")
        parts.append("")

    # Per-agent sections
    for r in results:
        role = r["role"]
        domain = r.get("domain", "?")
        output = r.get("output", "")
        latency = r.get("latency_ms", 0)
        tool_calls = r.get("tool_calls", 0)

        parts.append(f"## {role} ({domain})")
        parts.append(f"_{tool_calls} tool calls in {latency}ms_\n")
        parts.append(output.strip())
        parts.append("")

    # Stats footer
    total_latency = sum(r.get("latency_ms", 0) for r in results)
    total_tools = sum(r.get("tool_calls", 0) for r in results)
    parts.append("---")
    parts.append(f"**{len(results)} agents** | **{total_tools} total tool calls** | **{total_latency}ms total**")

    return "\n".join(parts)
