"""WIDDX CLI — Autonomous AI Orchestration System.

Powered by DeepSeek V4 + 5 Free Models + Google Gemini.
"""

from __future__ import annotations


def _get_version() -> str:
    """Read version from pyproject.toml or package metadata."""
    try:
        from pathlib import Path
        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject.exists():
            for line in pyproject.read_text(encoding="utf-8").splitlines():
                if line.startswith("version ="):
                    return line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    try:
        from importlib.metadata import version
        return version("widdx")
    except Exception:
        pass
    return "0.0.0"


__version__ = _get_version()
