"""WIDDX Orchestrator — the central brain coordinating all subsystems."""
from __future__ import annotations

from . import ui
from .agent_factory import AgentFactory
from .config import DEFAULT_MEMORY_DB_PATH, load_config
from .evolution import EvolutionEngine
from .git_ops import GitOps
from .indexer import ProjectIndexer
from .memory import MemoryStore
from .pipeline import ExecutionPipeline
from .router import AIRouter
from .tools import search as tools_search


class WIDDXOrchestrator:
    """Central orchestrator for the WIDDX CLI system."""

    def __init__(self) -> None:
        self._config = load_config()
        self._memory = MemoryStore(self._config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))
        self._router = AIRouter(self._config, self._memory)
        self._agent_factory = AgentFactory(self._router)
        self._evolution = EvolutionEngine(self._memory, self._config)
        self._pipeline = ExecutionPipeline(
            self._router, self._agent_factory, self._memory, self._evolution, self._config,
        )

    # ------------------------------------------------------------------
    # Command dispatchers
    # ------------------------------------------------------------------

    def run(self, task: str) -> None:
        """Run a task through the full pipeline (used by /agents, non-REPL mode)."""
        ui.task_start(task)
        self._check_api_keys()

        result = self._pipeline.run(task)

        ui.task_done(result)

    def build(self, project: str) -> None:
        self.run(f"Build a complete project: {project}. Include project structure, core modules, configuration, and a README.")

    def fix(self, issue: str) -> None:
        self.run(f"Fix the following issue: {issue}. Diagnose root cause, apply minimal fix, verify.")

    def improve(self) -> None:
        """Show improvement suggestions and routing recommendations."""
        ui.rule("Improve")
        tasks = self._memory.recent_tasks(20)
        if not tasks:
            ui.warn("No task history to learn from.")
            return

        ui.table(
            "Task History",
            ["Task ID", "Command", "C", "Status"],
            [[t["id"], t["command"][:60], str(t["complexity"]),
              "[success]✓[/]" if t["status"] == "completed" else "[warn]…[/]"]
             for t in tasks],
            ["dim", "highlight", "dim", "dim"],
        )

        routing_data: dict[str, list[dict]] = {}
        for t in tasks:
            task_type = self._router.infer_task_type(t["command"])
            stats = self._memory.routing_stats(task_type)
            routing_data[task_type] = stats

        if any(routing_data.values()):
            rows = []
            for task_type, stats in routing_data.items():
                for s in stats:
                    rows.append([task_type, s["model_selected"], str(s["count"]),
                                 f"{s['avg_score']:.2f}", f"{s['avg_latency']:.0f}ms"])
            ui.table("Routing Performance", ["Type", "Role", "Count", "Score", "Latency"], rows)

        best_roles: dict[str, str] = {}
        for task_type, stats in routing_data.items():
            recommendation = self._evolution.recommend_role(task_type)
            if recommendation:
                best_roles[task_type] = recommendation

        if best_roles:
            ui.get_console().print("\n  [brand]Recommendations:[/]")
            for tt, role in best_roles.items():
                ui.get_console().print(f"    {tt} -> [highlight]{role}[/]")

    def status(self) -> None:
        """Show system status (models, recent tasks, config)."""
        models = self._config.get("models", {})
        model_info = {
            "architect": models.get("architect", {}).get("model", "?"),
            "executor": models.get("executor", {}).get("model", "?"),
        }
        recent = self._memory.recent_tasks(5)
        ui.show_status(
            connected=self._router.is_ready,
            model_info=model_info,
            recent=recent,
            db_path=self._config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH),
            decisions=self._memory.count_decisions(),
            evolution=self._config.get("evolution", {}).get("enabled", True),
            threshold=self._config.get("pipeline", {}).get("complex_threshold", 3),
        )

    def show_memory(self) -> None:
        """Display stored knowledge entries."""
        ui.rule("Memory")
        knowledge = self._memory.list_knowledge()
        if knowledge:
            ui.table(
                "Stored Knowledge",
                ["Key", "Value", "Updated"],
                [[k["key"], k["value"][:80], k["updated_at"][:19]] for k in knowledge],
                ["highlight", "dim", "dim"],
            )
        else:
            ui.get_console().print("  [dim]No knowledge entries stored yet.[/]")

    # ── utility views ──────────────────────────────────────────

    def search(self, query: str) -> None:
        result = tools_search.tool_grep(query, directory=".")
        if result.get("error"):
            ui.fail(result["error"])
            return
        ui.show_search(query, result.get("matches", []), result.get("count", 0))

    def show_tools(self) -> None:
        ui.show_tools()

    def index_project(self) -> None:
        with ui.get_console().status("[dim]Scanning project...[/]"):
            indexer = ProjectIndexer()
            ctx = indexer.context_for_ai()
            idx = indexer._index
            lang_stats = idx.get("language_stats", {})
            top_lang = max(lang_stats, key=lang_stats.get) if lang_stats else "vanilla"
        ui.show_index(
            total_files=indexer.total_files,
            total_mb=indexer.total_size_mb,
            framework=top_lang,
            ctx=ctx,
        )

    def git_status(self) -> None:
        git = GitOps()
        if not git.is_repo:
            ui.get_console().print("  [dim]Not a git repository.[/]")
            return
        branch = git.current_branch()
        status = git.status()
        log = git.log(5)
        ui.show_git(
            branch=branch,
            changed=status.get("changed", 0),
            files=status.get("files", []),
            log=log.get("log", "").split("\n") if log.get("ok") else [],
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _check_api_keys(self) -> None:
        if not self._router.is_ready:
            ui.get_console().print()
            ui.fail("DEEPSEEK_API_KEY not set. Run: `$env:DEEPSEEK_API_KEY = 'sk-...'`")
