"""Project state — manages .widdx/ directory in the target project.

Tracks:
  - Framework and version
  - Phase completion (for resume across sessions)
  - Key architectural decisions
  - Created/edited files manifest
  - Session history
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_WIDDX_DIR_NAME = ".widdx"
_STATE_FILE = "project.json"
_SESSIONS_DIR = "sessions"


@dataclass
class ProjectState:
    version: int = 1
    framework: str = ""
    framework_version: str = ""
    project_name: str = ""
    phases_total: int = 0
    phases_completed: int = 0
    decisions: list[str] = field(default_factory=list)
    files_created: list[str] = field(default_factory=list)
    files_edited: list[str] = field(default_factory=list)
    last_phase_id: str = ""
    updated_at: str = ""


def get_widdx_dir(project_root: str | Path | None = None) -> Path:
    """Return the .widdx path (creates it if missing)."""
    root = Path(project_root or Path.cwd()).resolve()
    widdx_dir = root / _WIDDX_DIR_NAME
    widdx_dir.mkdir(parents=True, exist_ok=True)
    (widdx_dir / "skills").mkdir(exist_ok=True)
    (widdx_dir / _SESSIONS_DIR).mkdir(exist_ok=True)
    return widdx_dir


def load_state(project_root: str | Path | None = None) -> ProjectState | None:
    """Load project state from .widdx/project.json."""
    widdx_dir = get_widdx_dir(project_root)
    state_path = widdx_dir / _STATE_FILE
    if not state_path.exists():
        return None
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
        return ProjectState(**data)
    except (json.JSONDecodeError, TypeError, OSError) as exc:
        logger.warning("Failed to load project state: %s", exc)
        return None


def save_state(state: ProjectState, project_root: str | Path | None = None) -> None:
    """Persist project state to .widdx/project.json."""
    widdx_dir = get_widdx_dir(project_root)
    state_path = widdx_dir / _STATE_FILE
    state.updated_at = datetime.now(timezone.utc).isoformat()
    try:
        state_path.write_text(
            json.dumps(state.__dict__, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError as exc:
        logger.warning("Failed to save project state: %s", exc)


def save_session_snapshot(
    messages: list[dict],
    project_root: str | Path | None = None,
) -> str | None:
    """Save a session snapshot to .widdx/sessions/ for later resume."""
    widdx_dir = get_widdx_dir(project_root)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = widdx_dir / _SESSIONS_DIR / f"session_{ts}.json"
    try:
        path.write_text(
            json.dumps({
                "saved_at": datetime.now(timezone.utc).isoformat(),
                "message_count": len(messages),
                "messages": messages[-50:],  # Keep last 50 messages
            }, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return str(path)
    except OSError:
        return None


def list_snapshots(project_root: str | Path | None = None) -> list[dict]:
    """List available session snapshots."""
    widdx_dir = get_widdx_dir(project_root)
    sessions_dir = widdx_dir / _SESSIONS_DIR
    snapshots = []
    for f in sorted(sessions_dir.glob("session_*.json"),
                    key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            snapshots.append({
                "file": f.name,
                "saved_at": data.get("saved_at", ""),
                "messages": data.get("message_count", 0),
            })
        except (json.JSONDecodeError, OSError):
            continue
    return snapshots


__all__ = [
    "ProjectState", "get_widdx_dir", "load_state", "save_state",
    "save_session_snapshot", "list_snapshots",
]
