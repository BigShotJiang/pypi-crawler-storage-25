"""Self-learning methods for MemoryStore."""
from __future__ import annotations

from .schema import _utcnow


def log_learning_event(
    self,
    task_id: str,
    task_text: str,
    task_type: str,
    provider: str = "",
    success: bool = False,
    complexity: int = 1,
    tool_calls: int = 0,
    files_touched_json: str = "[]",
    domains_json: str = "[]",
    result_summary: str = "",
) -> None:
    """Record a learning event in the store.

    Args:
        task_id: Unique identifier for the task.
        task_text: Description of the task (truncated to 500 chars).
        task_type: Category of the task (truncated to 80 chars).
        provider: Model or tool provider (truncated to 80 chars).
        success: Whether the task completed successfully.
        complexity: Estimated complexity level (1-based).
        tool_calls: Number of tool invocations made.
        files_touched_json: JSON array of file paths touched.
        domains_json: JSON array of domain tags.
        result_summary: Brief result description (truncated to 1000 chars).
    """
    self._execute(
        "INSERT INTO learning_events "
        "(task_id, task_text, task_type, provider, success, complexity, tool_calls, "
        "files_touched, domains, result_summary, created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (
            task_id,
            task_text[:500],
            task_type[:80],
            provider[:80],
            int(success),
            complexity,
            tool_calls,
            files_touched_json,
            domains_json,
            result_summary[:1000],
            _utcnow(),
        ),
    )
    self._commit()


def recent_learning_events(self, limit: int = 20) -> list[dict]:
    """Return the most recent learning events.

    Args:
        limit: Maximum number of events to return (default 20).

    Returns:
        List of event dicts ordered by descending id, or empty list.
    """
    rows = self._execute(
        "SELECT * FROM learning_events ORDER BY id DESC LIMIT ?",
        (limit,),
    )
    if rows is None:
        return []
    return [dict(r) for r in rows.fetchall()]


def upsert_learning_pattern(
    self,
    fingerprint: str,
    pattern_type: str,
    scope: str,
    summary: str,
    source_task_id: str = "",
    metadata_json: str = "{}",
) -> dict | None:
    """Insert or update a learning pattern identified by fingerprint.

    New patterns start with confidence 0.5 and evidence_count 1; existing
    patterns increment evidence, boost confidence, and may promote to
    "candidate" status after 3 observations.

    Args:
        fingerprint: Unique hash identifying the pattern.
        pattern_type: Category of the pattern (truncated to 80 chars).
        scope: Context scope (truncated to 120 chars).
        summary: Description of the pattern (truncated to 500 chars).
        source_task_id: ID of the task that produced this evidence.
        metadata_json: JSON string of arbitrary metadata (truncated to 2000).

    Returns:
        The updated or created pattern dict, or None on failure.
    """
    existing = self.get_learning_pattern(fingerprint)
    now = _utcnow()
    if existing is None:
        self._execute(
            "INSERT INTO learning_patterns "
            "(fingerprint, pattern_type, scope, summary, evidence_count, confidence, status, "
            "source_task_id, metadata_json, first_seen, last_seen) "
            "VALUES (?,?,?,?,1,0.5,'observed',?,?,?,?)",
            (
                fingerprint,
                pattern_type[:80],
                scope[:120],
                summary[:500],
                source_task_id,
                metadata_json[:2000],
                now,
                now,
            ),
        )
        self._commit()
        return self.get_learning_pattern(fingerprint)

    evidence_count = int(existing.get("evidence_count", 0)) + 1
    confidence = min(0.95, 0.35 + evidence_count * 0.15)
    status = existing.get("status", "observed")
    if evidence_count >= 3 and status == "observed":
        status = "candidate"
    self._execute(
        "UPDATE learning_patterns "
        "SET summary=?, evidence_count=?, confidence=?, status=?, source_task_id=?, "
        "metadata_json=?, last_seen=? "
        "WHERE fingerprint=?",
        (
            summary[:500],
            evidence_count,
            confidence,
            status,
            source_task_id,
            metadata_json[:2000],
            now,
            fingerprint,
        ),
    )
    self._commit()
    return self.get_learning_pattern(fingerprint)


def get_learning_pattern(self, fingerprint: str) -> dict | None:
    """Retrieve a learning pattern by its fingerprint.

    Args:
        fingerprint: Unique hash identifying the pattern.

    Returns:
        The pattern dict, or None if not found.
    """
    row = self._execute(
        "SELECT * FROM learning_patterns WHERE fingerprint=?",
        (fingerprint,),
    )
    if row is None:
        return None
    r = row.fetchone()
    return dict(r) if r else None


def list_learning_patterns(self, limit: int = 20, min_evidence: int = 1) -> list[dict]:
    """List learning patterns filtered by minimum evidence count.

    Results are ordered by confidence descending, then evidence count,
    then last seen descending.

    Args:
        limit: Maximum number of patterns to return (default 20).
        min_evidence: Minimum evidence_count threshold (default 1).

    Returns:
        List of pattern dicts, or empty list.
    """
    rows = self._execute(
        "SELECT * FROM learning_patterns "
        "WHERE evidence_count >= ? "
        "ORDER BY confidence DESC, evidence_count DESC, last_seen DESC "
        "LIMIT ?",
        (min_evidence, limit),
    )
    if rows is None:
        return []
    return [dict(r) for r in rows.fetchall()]


def create_learning_asset(
    self,
    asset_type: str,
    name: str,
    summary: str,
    status: str = "draft",
    source_fingerprint: str = "",
    file_path: str = "",
) -> dict | None:
    """Create or update a learning asset (e.g. doc, template, snippet).

    If an asset with the same type and name already exists, its fields are
    updated and the timestamp refreshed.

    Args:
        asset_type: Category of the asset (truncated to 40 chars).
        name: Human-readable name (truncated to 120 chars).
        summary: Brief description (truncated to 500 chars).
        status: Lifecycle status (truncated to 40 chars, default "draft").
        source_fingerprint: Linked pattern fingerprint (truncated to 120).
        file_path: On-disk path if persisted (truncated to 500 chars).

    Returns:
        The created or updated asset dict, or None on failure.
    """
    existing = self.get_learning_asset(asset_type, name)
    now = _utcnow()
    if existing is not None:
        self._execute(
            "UPDATE learning_assets "
            "SET summary=?, status=?, source_fingerprint=?, file_path=?, updated_at=? "
            "WHERE asset_type=? AND name=?",
            (
                summary[:500],
                status[:40],
                source_fingerprint[:120],
                file_path[:500],
                now,
                asset_type,
                name,
            ),
        )
        self._commit()
        return self.get_learning_asset(asset_type, name)

    self._execute(
        "INSERT INTO learning_assets "
        "(asset_type, name, summary, status, source_fingerprint, file_path, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (
            asset_type[:40],
            name[:120],
            summary[:500],
            status[:40],
            source_fingerprint[:120],
            file_path[:500],
            now,
            now,
        ),
    )
    self._commit()
    return self.get_learning_asset(asset_type, name)


def get_learning_asset(self, asset_type: str, name: str) -> dict | None:
    """Retrieve a learning asset by type and name.

    Args:
        asset_type: Category of the asset.
        name: Human-readable name of the asset.

    Returns:
        The asset dict, or None if not found.
    """
    row = self._execute(
        "SELECT * FROM learning_assets WHERE asset_type=? AND name=?",
        (asset_type, name),
    )
    if row is None:
        return None
    r = row.fetchone()
    return dict(r) if r else None


def list_learning_assets(self, limit: int = 20, status: str | None = None) -> list[dict]:
    """List learning assets, optionally filtered by status.

    Results are ordered by updated_at and id descending.

    Args:
        limit: Maximum number of assets to return (default 20).
        status: Optional status filter (e.g. "draft", "published").

    Returns:
        List of asset dicts, or empty list.
    """
    if status:
        rows = self._execute(
            "SELECT * FROM learning_assets "
            "WHERE status=? "
            "ORDER BY updated_at DESC, id DESC "
            "LIMIT ?",
            (status, limit),
        )
    else:
        rows = self._execute(
            "SELECT * FROM learning_assets ORDER BY updated_at DESC, id DESC LIMIT ?",
            (limit,),
        )
    if rows is None:
        return []
    return [dict(r) for r in rows.fetchall()]
