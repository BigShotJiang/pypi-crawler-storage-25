"""Fix pattern methods for MemoryStore."""
from __future__ import annotations

from .schema import _utcnow


def add_fix_pattern(
    self, fingerprint: str, error_type: str, error_message: str,
    language: str, fix_template: str, file_pattern: str = "",
    max_patterns: int = 1000,
) -> str | None:
    """Store a new fix pattern, or return the existing fingerprint.

    If the store has reached `max_patterns` rows, the lowest-confidence
    pattern is evicted before insertion.

    Args:
        fingerprint: Unique hash for this error/fix pair.
        error_type: Broad category of the error.
        error_message: Full error text (truncated to 500 chars).
        language: Programming language of the fix.
        fix_template: Template or code snippet for the fix (2000 chars).
        file_pattern: Glob pattern matching affected files.
        max_patterns: Hard limit on total rows before eviction (default 1000).

    Returns:
        The fingerprint string if inserted or already present, else None.
    """
    existing = self.get_fix_pattern(fingerprint)
    if existing:
        return fingerprint

    row = self._execute("SELECT COUNT(*) as cnt FROM fix_patterns")
    if row:
        r = row.fetchone()
        if r and r["cnt"] >= max_patterns:
            self.evict_lowest_confidence_pattern()

    now = _utcnow()
    confidence = (0 + 1) / (0 + 0 + 2)
    self._execute(
        "INSERT INTO fix_patterns "
        "(fingerprint, error_type, error_message, language, fix_template, "
        "file_pattern, success_count, fail_count, confidence, first_seen, last_used) "
        "VALUES (?,?,?,?,?,?,0,0,?,?,?)",
        (fingerprint, error_type, error_message[:500], language,
         fix_template[:2000], file_pattern, confidence, now, now),
    )
    self._commit()
    return fingerprint


def get_fix_pattern(self, fingerprint: str) -> dict | None:
    """Retrieve a fix pattern by fingerprint.

    Args:
        fingerprint: Unique hash identifying the pattern.

    Returns:
        The pattern dict, or None if not found.
    """
    row = self._execute(
        "SELECT * FROM fix_patterns WHERE fingerprint=?", (fingerprint,)
    )
    if row is None:
        return None
    r = row.fetchone()
    return dict(r) if r else None


def find_fix_patterns(
    self, fingerprints: list[str], min_confidence: float = 0.0,
) -> list[dict]:
    """Look up multiple fix patterns by fingerprint with a confidence floor.

    Args:
        fingerprints: List of fingerprint hashes to search for.
        min_confidence: Minimum confidence threshold (default 0.0).

    Returns:
        List of matching pattern dicts ordered by confidence descending.
    """
    if not fingerprints:
        return []
    placeholders = ",".join("?" for _ in fingerprints)
    rows = self._execute(
        f"SELECT * FROM fix_patterns "
        f"WHERE fingerprint IN ({placeholders}) AND confidence >= ? "
        f"ORDER BY confidence DESC",
        tuple(fingerprints) + (min_confidence,),
    )
    if rows is None:
        return []
    return [dict(r) for r in rows.fetchall()]


def update_fix_pattern_result(self, fingerprint: str, success: bool) -> None:
    """Record the outcome of a fix pattern application and recalculate confidence.

    Uses Bayesian smoothing: confidence = (success_count + 1) / (total + 2).

    Args:
        fingerprint: Unique hash identifying the pattern.
        success: Whether the fix was successful.
    """
    now = _utcnow()
    if success:
        self._execute(
            "UPDATE fix_patterns SET success_count = success_count + 1, "
            "last_used = ? WHERE fingerprint = ?",
            (now, fingerprint),
        )
    else:
        self._execute(
            "UPDATE fix_patterns SET fail_count = fail_count + 1, "
            "last_used = ? WHERE fingerprint = ?",
            (now, fingerprint),
        )
    self._commit()

    row = self._execute(
        "SELECT success_count, fail_count FROM fix_patterns WHERE fingerprint = ?",
        (fingerprint,),
    )
    if row:
        r = row.fetchone()
        if r:
            s = r["success_count"]
            f = r["fail_count"]
            conf = (s + 1) / (s + f + 2)
            self._execute(
                "UPDATE fix_patterns SET confidence = ? WHERE fingerprint = ?",
                (conf, fingerprint),
            )
            self._commit()


def evict_lowest_confidence_pattern(self) -> None:
    """Remove the single lowest-confidence, least-recently-used pattern."""
    self._execute(
        "DELETE FROM fix_patterns WHERE id = ("
        "SELECT id FROM fix_patterns ORDER BY confidence ASC, last_used ASC LIMIT 1"
        ")"
    )
    self._commit()


def fix_pattern_count(self) -> int:
    """Return the total number of fix patterns in the store.

    Returns:
        Total count of fix_pattern rows.
    """
    row = self._execute("SELECT COUNT(*) as cnt FROM fix_patterns")
    if row is None:
        return 0
    r = row.fetchone()
    return r["cnt"] if r else 0


def fix_pattern_high_confidence_count(self, min_confidence: float) -> int:
    """Return the count of fix patterns meeting a confidence threshold.

    Args:
        min_confidence: Minimum confidence value to qualify.

    Returns:
        Count of patterns with confidence >= min_confidence.
    """
    row = self._execute(
        "SELECT COUNT(*) as cnt FROM fix_patterns WHERE confidence >= ?",
        (min_confidence,),
    )
    if row is None:
        return 0
    r = row.fetchone()
    return r["cnt"] if r else 0
