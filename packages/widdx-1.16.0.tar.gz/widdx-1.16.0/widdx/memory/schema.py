"""SQL schema and time helper for MemoryStore."""
from __future__ import annotations

from datetime import datetime, timezone

_MIGRATE_SQL = """
CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    command TEXT NOT NULL,
    intent TEXT,
    complexity INTEGER DEFAULT 1,
    status TEXT DEFAULT 'pending',
    created_at TEXT NOT NULL,
    completed_at TEXT
);
CREATE TABLE IF NOT EXISTS decisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    stage TEXT NOT NULL,
    decision_type TEXT NOT NULL,
    input_summary TEXT,
    output_summary TEXT,
    model_used TEXT,
    latency_ms INTEGER,
    tokens_used INTEGER,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS agent_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    agent_role TEXT NOT NULL,
    agent_goal TEXT,
    model_used TEXT,
    success INTEGER DEFAULT 0,
    output_summary TEXT,
    latency_ms INTEGER,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS routing_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_type TEXT NOT NULL,
    model_selected TEXT NOT NULL,
    success_score REAL DEFAULT 0.5,
    latency_ms INTEGER,
    tokens_used INTEGER,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS knowledge (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fix_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    fingerprint     TEXT NOT NULL UNIQUE,
    error_type      TEXT NOT NULL,
    error_message   TEXT NOT NULL,
    language        TEXT NOT NULL DEFAULT 'python',
    fix_template    TEXT NOT NULL,
    file_pattern    TEXT DEFAULT '',
    success_count   INTEGER DEFAULT 0,
    fail_count      INTEGER DEFAULT 0,
    confidence      REAL DEFAULT 0.5,
    first_seen      TEXT NOT NULL,
    last_used       TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS learning_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    task_text TEXT NOT NULL,
    task_type TEXT NOT NULL,
    provider TEXT,
    success INTEGER DEFAULT 0,
    complexity INTEGER DEFAULT 1,
    tool_calls INTEGER DEFAULT 0,
    files_touched TEXT DEFAULT '[]',
    domains TEXT DEFAULT '[]',
    result_summary TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS learning_patterns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fingerprint TEXT NOT NULL UNIQUE,
    pattern_type TEXT NOT NULL,
    scope TEXT NOT NULL,
    summary TEXT NOT NULL,
    evidence_count INTEGER DEFAULT 1,
    confidence REAL DEFAULT 0.5,
    status TEXT DEFAULT 'observed',
    source_task_id TEXT,
    metadata_json TEXT DEFAULT '{}',
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS learning_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_type TEXT NOT NULL,
    name TEXT NOT NULL,
    summary TEXT NOT NULL,
    status TEXT DEFAULT 'draft',
    source_fingerprint TEXT,
    file_path TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(asset_type, name)
);
CREATE INDEX IF NOT EXISTS idx_fix_patterns_fp ON fix_patterns(fingerprint);
CREATE INDEX IF NOT EXISTS idx_fix_patterns_conf ON fix_patterns(confidence);
CREATE INDEX IF NOT EXISTS idx_learning_events_task_type ON learning_events(task_type);
CREATE INDEX IF NOT EXISTS idx_learning_patterns_fp ON learning_patterns(fingerprint);
CREATE INDEX IF NOT EXISTS idx_learning_patterns_scope ON learning_patterns(scope);
"""


def _utcnow() -> str:
    """Return the current UTC time as an ISO-8601 string.

    Returns:
        ISO-formatted UTC timestamp, e.g. "2024-01-01T00:00:00.123456+00:00".
    """
    return datetime.now(timezone.utc).isoformat()
