"""Framework configuration definitions — extend this to add new framework support."""
from __future__ import annotations

from .models import FrameworkConfig, ScaffoldQuestion


_FRAMEWORKS: dict[str, FrameworkConfig] = {
    "laravel": FrameworkConfig(
        label="Laravel",
        install_cmd="composer create-project laravel/laravel:{version} . --no-interaction",
        versions=["11.x", "10.x", "12.x"],
        required_tools=["php", "composer"],
        post_install=[
            "php artisan key:generate",
            "php artisan storage:link",
        ],
        env_template={
            "DB_CONNECTION": "mysql",
            "DB_HOST": "127.0.0.1",
            "DB_PORT": "3306",
            "DB_DATABASE": "{project_name}",
            "DB_USERNAME": "root",
            "DB_PASSWORD": "",
        },
        questions=[
            ScaffoldQuestion(key="database", label="Database",
                             options=["MySQL", "PostgreSQL", "SQLite", "MariaDB"],
                             default="MySQL"),
            ScaffoldQuestion(key="auth", label="Authentication",
                             options=["Laravel Breeze", "Laravel Jetstream", "Sanctum", "None"],
                             default="Laravel Breeze"),
            ScaffoldQuestion(key="stack", label="Frontend stack",
                             options=["Blade + Tailwind", "Livewire + Alpine", "Inertia + Vue", "Inertia + React", "API only"],
                             default="Blade + Tailwind"),
        ],
    ),
    "django": FrameworkConfig(
        label="Django",
        install_cmd="pip install django=={version} && django-admin startproject {project_name} .",
        versions=["5.1", "5.0", "4.2"],
        required_tools=["python"],
        post_install=[
            "python manage.py migrate",
        ],
        env_template={
            "DEBUG": "True",
            "SECRET_KEY": "",
            "DATABASE_URL": "sqlite:///db.sqlite3",
        },
        questions=[
            ScaffoldQuestion(key="database", label="Database",
                             options=["SQLite", "PostgreSQL", "MySQL"],
                             default="SQLite"),
        ],
    ),
    "react": FrameworkConfig(
        label="React",
        install_cmd="npm create vite@latest . -- --template react-ts",
        versions=["latest"],
        required_tools=["node", "npm"],
        post_install=[
            "npm install",
        ],
        questions=[
            ScaffoldQuestion(key="router", label="Routing",
                             options=["React Router", "TanStack Router", "None"],
                             default="React Router"),
            ScaffoldQuestion(key="styling", label="Styling",
                             options=["Tailwind CSS", "CSS Modules", "Styled Components", "Plain CSS"],
                             default="Tailwind CSS"),
        ],
    ),
    "nextjs": FrameworkConfig(
        label="Next.js",
        install_cmd="npm create next@latest . -- --typescript --app --no-turbopack",
        versions=["latest", "14.x", "13.x"],
        required_tools=["node", "npm"],
        post_install=[
            "npm install",
        ],
        questions=[
            ScaffoldQuestion(key="styling", label="Styling",
                             options=["Tailwind CSS", "CSS Modules", "Plain CSS"],
                             default="Tailwind CSS"),
        ],
    ),
    "fastapi": FrameworkConfig(
        label="FastAPI",
        install_cmd="pip install 'fastapi=={version}' uvicorn",
        versions=["0.115", "0.114", "0.110"],
        required_tools=["python"],
        env_template={
            "APP_ENV": "development",
            "DEBUG": "True",
        },
        questions=[
            ScaffoldQuestion(key="database", label="Database",
                             options=["SQLAlchemy + PostgreSQL", "SQLAlchemy + SQLite", "SQLModel + SQLite"],
                             default="SQLAlchemy + SQLite"),
        ],
    ),
}


_FRAMEWORK_PATTERNS: list[tuple[str, str]] = [
    ("laravel", r"laravel"),
    ("django",  r"django"),
    ("react",   r"\breact\b"),
    ("nextjs",  r"next\.?js?\b"),
    ("fastapi", r"fastapi"),
    ("vue",     r"\bvue\b"),
    ("flask",   r"\bflask\b"),
    ("spring",  r"\bspring\b"),
    ("rails",   r"\brails\b"),
    ("express", r"\bexpress\b"),
]


def _ask_version(cfg: FrameworkConfig) -> str:
    """Prompt the user to pick a version via numbered list."""
    from widdx.ui.professional import confirm_with_options
    return confirm_with_options(
        f"{cfg.label} version",
        cfg.versions,
        default=cfg.versions[0],
    )


def _resolve_option(answer: str, question: ScaffoldQuestion) -> str:
    """Resolve a single-character answer to the full option name."""
    if not answer:
        return question.default or question.options[0]
    for opt in question.options:
        if answer.lower() == opt[0].lower() or answer.lower() == opt.lower():
            return opt
    return question.default or question.options[0]
