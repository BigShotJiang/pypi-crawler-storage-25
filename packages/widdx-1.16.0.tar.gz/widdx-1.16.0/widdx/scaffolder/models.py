"""Data classes for the scaffolder system."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ScaffoldQuestion:
    key: str
    label: str
    options: list[str]
    default: str | None = None


@dataclass
class FrameworkConfig:
    label: str
    install_cmd: str
    versions: list[str]
    questions: list[ScaffoldQuestion] = field(default_factory=list)
    post_install: list[str] = field(default_factory=list)
    required_tools: list[str] = field(default_factory=list)
    env_template: dict[str, str] = field(default_factory=dict)


@dataclass
class ScaffoldResult:
    framework: str
    version: str
    project_dir: str
    answers: dict[str, str] = field(default_factory=dict)
    installed: bool = False
    env_created: bool = False
    git_inited: bool = False
    widdx_dir_created: bool = False
    skipped: bool = False
    error: str = ""
