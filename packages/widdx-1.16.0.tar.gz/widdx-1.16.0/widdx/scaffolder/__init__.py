"""Project scaffolder — interactive framework installation and project initialisation.

Flow:
  1. Detect framework from task description
  2. Ask user for version and configuration choices
  3. Install the framework (composer create-project, npm create, etc.)
  4. Set up .env with database credentials
  5. Initialise git repository
  6. Create .widdx/ project state directory in the target project
  7. Return a ScaffoldResult with project metadata
"""
from __future__ import annotations

import logging
import os
import shlex
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Re-exports from submodules
# ---------------------------------------------------------------------------

from .models import (  # noqa: E402
    ScaffoldQuestion,
    FrameworkConfig,
    ScaffoldResult,
)

from .config import (  # noqa: E402
    _FRAMEWORKS,
    _FRAMEWORK_PATTERNS,
    _ask_version,
    _resolve_option,
)

from .helpers import (  # noqa: E402
    _setup_env,
    _init_git,
    _detect_via_llm,
    _silent_cmd,
    _generate_skills,
    _generate_hooks,
    _generate_mcp_config,
    _create_widdx_dir,
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def detect_framework(task: str) -> tuple[str, FrameworkConfig] | None:
    """Detect the framework the user wants from their task description."""
    import re
    lowered = task.lower()
    for key, pattern in _FRAMEWORK_PATTERNS:
        if re.search(pattern, lowered):
            cfg = _FRAMEWORKS.get(key)
            if cfg:
                return key, cfg
    return None


def ask_questions(cfg: FrameworkConfig) -> dict[str, str]:
    """Ask the user interactive configuration questions."""
    from widdx import ui

    answers: dict[str, str] = {}

    version_str = _ask_version(cfg)
    answers["version"] = version_str

    for question in cfg.questions:
        result = ui.confirm_with_options(
            f"{question.label}: which option?",
            question.options,
            default=question.default,
        )
        selected = _resolve_option(result, question)
        answers[question.key] = selected

    return answers


def scaffold(
    task: str,
    project_dir: str | None = None,
    answers: dict[str, str] | None = None,
    router: object = None,
) -> ScaffoldResult:
    """Run the full scaffolding flow.

    Args:
        task: The user's task description.
        project_dir: Target directory (defaults to CWD).
        answers: Pre-supplied answers (skips interactive questions).
        router: Optional LLM router for fallback framework detection.

    Returns:
        ScaffoldResult describing what was done.
    """
    from widdx import ui

    detected = detect_framework(task)
    if detected is None and router is not None and getattr(router, 'is_ready', False):
        detected = _detect_via_llm(task, router)

    if detected is None:
        return ScaffoldResult(
            framework="unknown",
            version="",
            project_dir=project_dir or os.getcwd(),
            skipped=True,
        )

    key, cfg = detected
    target = Path(project_dir or os.getcwd()).resolve()
    c = ui.get_console()

    from widdx.preflight import check_requirements, print_report
    preflight = check_requirements(cfg.required_tools)
    if not preflight.passed:
        print_report(preflight)
        return ScaffoldResult(
            framework=key,
            version=cfg.versions[0],
            project_dir=str(target),
            error=f"Missing tools: {', '.join(preflight.missing)}",
        )

    c.print(f"\n  [brand]\u25c6[/] [bold]Project scaffolding:[/] [text]{cfg.label}[/]")

    if answers is None:
        answers = ask_questions(cfg)

    version = answers.get("version", cfg.versions[0])
    if version not in cfg.versions:
        version = cfg.versions[0]
    project_name = target.name

    safe_version = shlex.quote(version)
    safe_project = shlex.quote(project_name)
    install_cmd = cfg.install_cmd.format(
        version=safe_version,
        project_name=safe_project,
    )

    c.print(f"  [dim]Installing {cfg.label} {version}...[/]")

    try:
        install_args = shlex.split(install_cmd)
    except ValueError:
        install_args = [install_cmd]

    try:
        proc = subprocess.run(
            install_args,
            capture_output=True,
            text=True,
            timeout=300,
            cwd=str(target),
        )
        if proc.returncode != 0:
            error_msg = (proc.stderr or proc.stdout or "").strip()[:500]
            logger.error("Scaffolding failed for %s: %s", key, error_msg)
            return ScaffoldResult(
                framework=key, version=version,
                project_dir=str(target),
                error=error_msg,
                answers=answers,
            )
    except subprocess.TimeoutExpired:
        return ScaffoldResult(
            framework=key, version=version,
            project_dir=str(target),
            error="Installation timed out after 300s",
            answers=answers,
        )
    except OSError as e:
        return ScaffoldResult(
            framework=key, version=version,
            project_dir=str(target),
            error=str(e),
            answers=answers,
        )

    c.print(f"  [success]\u2713[/] {cfg.label} {version} installed")

    for cmd in cfg.post_install:
        cmd_fmt = cmd.format(project_name=project_name)
        _silent_cmd(cmd_fmt, target)

    env_created = _setup_env(cfg, target, answers)
    git_inited = _init_git(target, cfg.label, version)
    _create_widdx_dir(target, key, version, answers)
    _generate_skills(target, key, cfg, answers, router)
    _generate_hooks(target, key, label=cfg.label)
    _generate_mcp_config(target)

    c.print(f"  [success]\u2713[/] Project ready in [text]{target}[/]")
    if git_inited:
        c.print("  [success]\u2713[/] Git repository initialised")

    return ScaffoldResult(
        framework=key,
        version=version,
        project_dir=str(target),
        answers=answers,
        installed=True,
        env_created=env_created,
        git_inited=git_inited,
        widdx_dir_created=True,
    )


__all__ = [
    "detect_framework", "ask_questions", "scaffold",
    "ScaffoldResult", "FrameworkConfig", "ScaffoldQuestion",
]
