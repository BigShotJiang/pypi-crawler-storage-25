"""Built-in agent library for WIDDX — specialized agents with personality and process."""
from .registry import BUILTIN_AGENTS, AgentRegistry

__all__ = ["AgentRegistry", "BUILTIN_AGENTS"]
