"""Git integration — status, diff, branches, smart commits, push, PR."""
from __future__ import annotations

import subprocess
from pathlib import Path


class GitOps:
    """Safe git operations with output parsing."""

    def __init__(self, repo_path: str = ".") -> None:
        try:
            resolved = Path(repo_path).resolve()
        except (PermissionError, OSError):
            resolved = Path(repo_path).absolute()
        self._root = self._find_repo_root(resolved)

    @staticmethod
    def _find_repo_root(path: Path) -> Path | None:
        for parent in [path, *path.parents]:
            if (parent / ".git").exists():
                return parent
        return None

    @property
    def is_repo(self) -> bool:
        return self._root is not None

    def _run(self, *args: str, timeout: int = 30) -> dict:
        if not self.is_repo:
            return {"error": "Not a git repository"}
        try:
            result = subprocess.run(
                ["git", "-C", str(self._root), *args],
                capture_output=True, text=True, timeout=timeout,
            )
            return {"ok": result.returncode == 0, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()}
        except subprocess.TimeoutExpired:
            return {"error": "Git command timed out"}
        except FileNotFoundError:
            return {"error": "Git not found on this system"}

    def _run_gh(self, *args: str) -> dict:
        """Run a gh CLI command."""
        try:
            result = subprocess.run(
                ["gh", *args],
                capture_output=True, text=True, timeout=60,
            )
            return {"ok": result.returncode == 0, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()}
        except FileNotFoundError:
            return {"error": "gh CLI not found"}

    def status(self) -> dict:
        r = self._run("status", "--porcelain")
        if r.get("error"):
            return r
        lines = [line for line in r["stdout"].split("\n") if line.strip()] if r["stdout"] else []
        return {"ok": True, "changed": len(lines), "files": lines[:50]}

    def diff(self, staged: bool = False) -> dict:
        args = ["diff"]
        if staged:
            args.append("--staged")
        r = self._run(*args)
        if r.get("error"):
            return r
        return {"ok": True, "diff": r["stdout"][:5000]}

    def current_branch(self) -> str:
        r = self._run("branch", "--show-current")
        return r.get("stdout", "unknown") if r.get("ok") else "unknown"

    def create_branch(self, name: str) -> dict:
        return self._run("checkout", "-b", name)

    def commit(self, message: str, files: list[str] | None = None, include_all: bool = False) -> dict:
        """Commit files.

        Args:
            message: Commit message.
            files: Specific files to stage and commit.
            include_all: If True (and files is None), runs ``git add -A``
                         so new (untracked) files are included.
        """
        if files:
            self._run("add", *files)
        elif include_all:
            self._run("add", "-A")
        else:
            self._run("add", "-u")
        return self._run("commit", "-m", message)

    def log(self, count: int = 10) -> dict:
        r = self._run("log", f"-{count}", "--oneline", "--decorate")
        if r.get("error"):
            return r
        return {"ok": True, "log": r["stdout"]}

    def push(self, remote: str = "origin", branch: str | None = None) -> dict:
        """Push current branch (or *branch*) to *remote*."""
        branch = branch or self.current_branch()
        return self._run("push", remote, branch, timeout=120)

    def pull(self, remote: str = "origin", branch: str | None = None) -> dict:
        """Pull from remote."""
        branch = branch or self.current_branch()
        return self._run("pull", remote, branch, timeout=120)

    def stash(self) -> dict:
        """Stash uncommitted changes."""
        return self._run("stash", "push", "-m", "widdx-auto-stash")

    def stash_pop(self) -> dict:
        """Restore most recent stash."""
        return self._run("stash", "pop")

    def add_all_tracked(self) -> dict:
        """Stage all changes to tracked files (safe: no untracked)."""
        return self._run("add", "-u")

    def has_changes(self) -> bool:
        """Return True if there are uncommitted changes (including untracked files)."""
        r = self.status()
        return r.get("changed", 0) > 0

    def create_pr(self, title: str, body: str = "", base: str = "main") -> dict:
        """Create a PR via gh CLI. Returns the PR URL on success."""
        r = self._run_gh("pr", "create",
                         "--title", title,
                         "--body", body or title,
                         "--base", base,
                         "--fill")
        if r.get("error"):
            return r
        return {"ok": True, "url": r.get("stdout", ""), "title": title}
