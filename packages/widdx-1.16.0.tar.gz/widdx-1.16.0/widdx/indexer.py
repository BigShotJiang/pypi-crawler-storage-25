"""Project indexer — scans and understands project structure."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any


class ProjectIndexer:
    """Scans project directory and builds a context-aware file tree."""

    IGNORE_PATTERNS = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        ".next", "dist", "build", ".cache", ".widdx",
        "*.pyc", "*.pyo", "*.class", "*.o", "*.so", "*.dylib",
        ".DS_Store", "Thumbs.db", "*.egg-info", ".mypy_cache",
        ".pytest_cache", ".ruff_cache", "coverage", ".tox",
    }

    IMPORTANT_EXTENSIONS = {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".yaml", ".yml", ".toml", ".json", ".md"}

    def __init__(self, root: str = ".") -> None:
        self._root = Path(root).resolve()
        self._index: dict[str, Any] = {}

    def scan(self) -> dict[str, Any]:
        """Full project scan. Returns structured index."""
        files: list[dict] = []
        total_size = 0

        try:
            walker = os.walk(self._root, onerror=self._on_walk_error)
        except OSError:
            return self._empty_index()

        for dirpath, dirnames, filenames in walker:
            dirnames[:] = [d for d in dirnames if not self._is_ignored(d)]

            for fname in filenames:
                if self._is_ignored(fname):
                    continue
                fpath = Path(dirpath) / fname
                try:
                    rel_dir = Path(dirpath).resolve().relative_to(self._root)
                except ValueError:
                    rel_dir = Path(dirpath)
                rel_path = str(rel_dir / fname) if str(rel_dir) != "." else fname
                try:
                    size = fpath.stat().st_size
                except OSError:
                    size = 0
                ext = fpath.suffix.lower()
                entry = {"path": rel_path, "size": size}
                if ext in self.IMPORTANT_EXTENSIONS:
                    entry["important"] = True
                files.append(entry)
                total_size += size

        files.sort(key=lambda f: (not f.get("important", False), f["path"]))

        self._index = {
            "root": str(self._root),
            "total_files": len(files),
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "important_files": [f for f in files if f.get("important")],
            "all_files": files[:200],
            "language_stats": self._language_stats(files),
        }
        return self._index

    def context_for_ai(self, max_files: int = 60) -> str:
        """Generate a compact context string for the AI model."""
        idx = self._index or self.scan()
        lines = [f"Project: {idx['root']}", f"Files: {idx['total_files']} ({idx['total_size_mb']}MB)", ""]

        # Group important files by directory for better structure awareness
        important = idx.get("important_files", [])
        dirs: dict[str, list[str]] = {}
        for f in important:
            d = str(Path(f["path"]).parent)
            dirs.setdefault(d, []).append(f["path"])

        if dirs:
            lines.append("Project structure:")
            shown = 0
            for d, files in sorted(dirs.items()):
                if shown >= max_files:
                    break
                prefix = "." if d == "." else d
                lines.append(f"  {prefix}/")
                for fp in files[:8]:  # max 8 files per dir
                    lines.append(f"    {Path(fp).name}")
                    shown += 1
                    if shown >= max_files:
                        break

        langs = idx.get("language_stats", {})
        if langs:
            top = sorted(langs.items(), key=lambda x: x[1], reverse=True)[:5]
            lines.append(f"\nLanguages: {', '.join(f'{k}({v})' for k, v in top)}")

        # Add config files hint
        config_files = [
            f["path"] for f in idx.get("all_files", [])
            if Path(f["path"]).name in {
                "package.json", "pyproject.toml", "go.mod", "Cargo.toml",
                "docker-compose.yml", "docker-compose.yaml", ".env.example",
                "Makefile", "requirements.txt", "tsconfig.json",
            }
        ]
        if config_files:
            lines.append(f"\nConfig files: {', '.join(config_files[:8])}")

        return "\n".join(lines)

    def _is_ignored(self, name: str) -> bool:
        for pattern in self.IGNORE_PATTERNS:
            if pattern.startswith("*."):
                if name.endswith(pattern[1:]):
                    return True
            elif name == pattern:
                return True
        return name.startswith(".")

    def _on_walk_error(self, err: OSError) -> None:
        import logging
        logging.getLogger("widdx.indexer").debug("Walk error: %s", err)

    def _empty_index(self) -> dict[str, Any]:
        self._index = {
            "root": str(self._root),
            "total_files": 0,
            "total_size_mb": 0.0,
            "important_files": [],
            "all_files": [],
            "language_stats": {},
        }
        return self._index

    @property
    def total_files(self) -> int:
        return int(self._index.get("total_files", 0))

    @property
    def total_size_mb(self) -> float:
        return float(self._index.get("total_size_mb", 0.0))

    def _language_stats(self, files: list[dict]) -> dict[str, int]:
        ext_map = {
            ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
            ".tsx": "TSX", ".jsx": "JSX", ".go": "Go", ".rs": "Rust",
            ".yaml": "YAML", ".yml": "YAML", ".toml": "TOML",
            ".json": "JSON", ".md": "Markdown", ".css": "CSS",
            ".html": "HTML", ".sql": "SQL", ".sh": "Shell",
        }
        stats: dict[str, int] = {}
        for f in files:
            ext = Path(f["path"]).suffix.lower()
            lang = ext_map.get(ext)
            if lang:
                stats[lang] = stats.get(lang, 0) + 1
        return stats
