"""Enhanced Progress Bars — animated progress indicators for long-running tasks."""
from __future__ import annotations

from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
)


class EnhancedProgressBar:
    """Wrapper around Rich Progress for enhanced visual feedback."""

    def __init__(self, console: Console, title: str = "Processing") -> None:
        self._console = console
        self._title = title
        self._progress: Progress | None = None
        self._task_id: TaskID | None = None

    def start(self, total: int = 100, description: str = "") -> None:
        """Start the progress bar."""
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeRemainingColumn(),
            console=self._console,
        )
        self._progress.start()
        desc = description or self._title
        self._task_id = self._progress.add_task(desc, total=total)

    def update(self, completed: int, description: str = "") -> None:
        """Update progress."""
        if self._progress and self._task_id is not None:
            if description:
                self._progress.update(self._task_id, description=description)
            self._progress.update(self._task_id, completed=completed)

    def advance(self, amount: int = 1, description: str = "") -> None:
        """Advance progress by amount."""
        if self._progress and self._task_id is not None:
            if description:
                self._progress.update(self._task_id, description=description)
            self._progress.update(self._task_id, advance=amount)

    def stop(self) -> None:
        """Stop the progress bar."""
        if self._progress:
            self._progress.stop()
            self._progress = None
            self._task_id = None

    def __enter__(self) -> EnhancedProgressBar:
        """Context manager entry."""
        return self

    def __exit__(self, *args) -> None:
        """Context manager exit."""
        self.stop()


class MultiProgressBar:
    """Multiple progress bars for parallel operations."""

    def __init__(self, console: Console) -> None:
        self._console = console
        self._progress: Progress | None = None
        self._tasks: dict[str, TaskID] = {}

    def start(self) -> None:
        """Start the multi-progress display."""
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=self._console,
        )
        self._progress.start()

    def add_task(self, task_id: str, description: str, total: int = 100) -> None:
        """Add a new task to track."""
        if self._progress:
            self._tasks[task_id] = self._progress.add_task(description, total=total)

    def update(self, task_id: str, completed: int, description: str = "") -> None:
        """Update a specific task."""
        if self._progress and task_id in self._tasks:
            if description:
                self._progress.update(self._tasks[task_id], description=description)
            self._progress.update(self._tasks[task_id], completed=completed)

    def advance(self, task_id: str, amount: int = 1, description: str = "") -> None:
        """Advance a specific task."""
        if self._progress and task_id in self._tasks:
            if description:
                self._progress.update(self._tasks[task_id], description=description)
            self._progress.update(self._tasks[task_id], advance=amount)

    def stop(self) -> None:
        """Stop all progress bars."""
        if self._progress:
            self._progress.stop()
            self._progress = None
            self._tasks.clear()

    def __enter__(self) -> MultiProgressBar:
        """Context manager entry."""
        self.start()
        return self

    def __exit__(self, *args) -> None:
        """Context manager exit."""
        self.stop()
