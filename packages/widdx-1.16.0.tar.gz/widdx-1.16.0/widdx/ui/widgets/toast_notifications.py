"""Toast Notifications — non-intrusive popup notifications."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text


class ToastLevel(Enum):
    """Toast notification level."""

    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"


@dataclass
class Toast:
    """Represents a single toast notification."""

    message: str
    level: ToastLevel = ToastLevel.INFO
    duration: float = 3.0  # seconds
    created_at: Optional[datetime] = field(default=None)

    def __post_init__(self) -> None:
        if self.created_at is None:
            self.created_at = datetime.now()

    @property
    def is_expired(self) -> bool:
        """Check if toast has expired."""
        if self.created_at is None:
            return False
        elapsed = (datetime.now() - self.created_at).total_seconds()
        return elapsed > self.duration

    @property
    def level_icon(self) -> str:
        """Return icon for toast level."""
        icons = {
            ToastLevel.INFO: "ℹ️",
            ToastLevel.SUCCESS: "✅",
            ToastLevel.WARNING: "⚠️",
            ToastLevel.ERROR: "❌",
        }
        return icons.get(self.level, "•")

    @property
    def level_color(self) -> str:
        """Return color for toast level."""
        colors = {
            ToastLevel.INFO: "cyan",
            ToastLevel.SUCCESS: "green",
            ToastLevel.WARNING: "yellow",
            ToastLevel.ERROR: "red",
        }
        return colors.get(self.level, "text")


class ToastNotificationManager:
    """Manages toast notifications."""

    def __init__(self, console: Console, max_toasts: int = 5) -> None:
        self._console = console
        self._max_toasts = max_toasts
        self._toasts: list[Toast] = []

    def show(
        self,
        message: str,
        level: ToastLevel = ToastLevel.INFO,
        duration: float = 3.0,
    ) -> None:
        """Show a toast notification."""
        toast = Toast(message=message, level=level, duration=duration)
        self._toasts.append(toast)

        # Keep only the latest max_toasts
        if len(self._toasts) > self._max_toasts:
            self._toasts = self._toasts[-self._max_toasts :]

        # Render immediately
        self._render_toast(toast)

    def info(self, message: str, duration: float = 3.0) -> None:
        """Show info toast."""
        self.show(message, ToastLevel.INFO, duration)

    def success(self, message: str, duration: float = 3.0) -> None:
        """Show success toast."""
        self.show(message, ToastLevel.SUCCESS, duration)

    def warning(self, message: str, duration: float = 4.0) -> None:
        """Show warning toast."""
        self.show(message, ToastLevel.WARNING, duration)

    def error(self, message: str, duration: float = 5.0) -> None:
        """Show error toast."""
        self.show(message, ToastLevel.ERROR, duration)

    def _render_toast(self, toast: Toast) -> None:
        """Render a single toast."""
        text = Text(f"{toast.level_icon}  {toast.message}", style=toast.level_color)
        panel = Panel(
            text,
            style=f"{toast.level_color} dim",
            padding=(0, 1),
            expand=False,
        )
        self._console.print(panel)

    def cleanup_expired(self) -> None:
        """Remove expired toasts."""
        self._toasts = [t for t in self._toasts if not t.is_expired]

    def clear(self) -> None:
        """Clear all toasts."""
        self._toasts.clear()
