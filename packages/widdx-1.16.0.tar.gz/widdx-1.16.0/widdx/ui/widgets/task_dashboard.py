"""Task Dashboard — displays running tasks with status, progress, and timing."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from rich.console import Console
from rich.table import Table


@dataclass
class Task:
    """Represents a single task in the dashboard."""

    task_id: str
    name: str
    status: str = "pending"  # pending, running, completed, failed
    progress: float = 0.0  # 0-100
    start_time: datetime = field(default_factory=datetime.now)
    end_time: datetime | None = None
    details: str = ""

    @property
    def elapsed_seconds(self) -> float:
        """Calculate elapsed time in seconds."""
        end = self.end_time or datetime.now()
        return (end - self.start_time).total_seconds()

    @property
    def status_icon(self) -> str:
        """Return status icon."""
        icons = {
            "pending": "⏳",
            "running": "⚙️",
            "completed": "✅",
            "failed": "❌",
        }
        return icons.get(self.status, "❓")


class TaskDashboard:
    """Dashboard for displaying and managing tasks."""

    def __init__(self, console: Console) -> None:
        self._console = console
        self._tasks: dict[str, Task] = {}

    def add_task(self, task_id: str, name: str, details: str = "") -> Task:
        """Add a new task to the dashboard."""
        task = Task(task_id=task_id, name=name, details=details)
        self._tasks[task_id] = task
        return task

    def update_task(
        self,
        task_id: str,
        status: str | None = None,
        progress: float | None = None,
        details: str | None = None,
    ) -> None:
        """Update task status."""
        if task_id not in self._tasks:
            return
        task = self._tasks[task_id]
        if status is not None:
            task.status = status
            if status == "completed" or status == "failed":
                task.end_time = datetime.now()
        if progress is not None:
            task.progress = max(0, min(100, progress))
        if details is not None:
            task.details = details

    def remove_task(self, task_id: str) -> None:
        """Remove a task from the dashboard."""
        if task_id in self._tasks:
            del self._tasks[task_id]

    def render(self) -> Table:
        """Render the dashboard as a Rich Table."""
        table = Table(
            title="[bold]Task Dashboard[/bold]",
            show_header=True,
            header_style="bold cyan",
            padding=(0, 1),
        )

        table.add_column("Status", style="dim", width=8)
        table.add_column("Task", style="text", width=25)
        table.add_column("Progress", width=20)
        table.add_column("Time", style="muted", width=10)
        table.add_column("Details", style="dim", width=30)

        for task in self._tasks.values():
            # Progress bar
            filled = int(task.progress / 5)  # 20 chars = 100%
            progress_bar = "█" * filled + "░" * (20 - filled)
            progress_text = f"[success]{progress_bar}[/] {task.progress:.0f}%"

            # Time
            time_text = f"{task.elapsed_seconds:.1f}s"

            # Details (truncated)
            details = task.details[:30] + "..." if len(task.details) > 30 else task.details

            table.add_row(
                f"{task.status_icon} {task.status}",
                task.name,
                progress_text,
                time_text,
                details,
            )

        return table

    def print(self) -> None:
        """Print the dashboard to console."""
        if self._tasks:
            self._console.print(self.render())
