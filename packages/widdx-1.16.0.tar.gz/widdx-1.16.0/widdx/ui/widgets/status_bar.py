"""Status Bar — sticky footer showing real-time system state."""
from __future__ import annotations

from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.text import Text


class StatusBar:
    """Sticky status bar displaying model, tokens, connection status, and time."""

    def __init__(self, console: Console) -> None:
        self._console = console
        self._model: str = "deepseek-v4-flash"
        self._tokens_input: int = 0
        self._tokens_output: int = 0
        self._cost: float = 0.0
        self._provider: str = "deepseek"
        self._is_connected: bool = True
        self._last_update: datetime = datetime.now()

    def update(
        self,
        model: str | None = None,
        tokens_input: int | None = None,
        tokens_output: int | None = None,
        cost: float | None = None,
        provider: str | None = None,
        is_connected: bool | None = None,
    ) -> None:
        """Update status bar state."""
        if model is not None:
            self._model = model
        if tokens_input is not None:
            self._tokens_input = tokens_input
        if tokens_output is not None:
            self._tokens_output = tokens_output
        if cost is not None:
            self._cost = cost
        if provider is not None:
            self._provider = provider
        if is_connected is not None:
            self._is_connected = is_connected
        self._last_update = datetime.now()

    def render(self) -> Panel:
        """Render the status bar as a Rich Panel."""
        # Connection status indicator
        conn_icon = "🟢" if self._is_connected else "🔴"
        conn_text = "Connected" if self._is_connected else "Disconnected"

        # Build status text
        status_parts = [
            f"[info]{conn_icon}[/] {conn_text}",
            "[dim]|[/]",
            f"[brand]Model:[/] {self._model}",
            "[dim]|[/]",
            f"[accent]Tokens:[/] ↑{self._tokens_input} ↓{self._tokens_output}",
            "[dim]|[/]",
            f"[success]Cost:[/] ${self._cost:.6f}",
            "[dim]|[/]",
            f"[muted]{self._last_update.strftime('%H:%M:%S')}[/]",
        ]

        status_text = Text(" ".join(status_parts))

        return Panel(
            status_text,
            title="[bold]Status[/bold]",
            title_align="left",
            style="dim",
            padding=(0, 1),
        )

    def print(self) -> None:
        """Print the status bar to console."""
        self._console.print(self.render())
