"""Chat mode display helpers."""
from __future__ import annotations

import sys

from .arabic import _d
from .drawing import rule
from .theme import get_console


def chat_welcome(framework: str = "vanilla", files: int = 0) -> None:
    """Display refined chat welcome panel."""
    c = get_console()
    rule("Chat Mode")
    c.print(f"    [dim]framework:[/dim] [info]{framework}[/]  [dim]files:[/dim] [accent]{files}[/]")
    c.print("    [dim]commands:[/dim] /build /fix /search /index /git /clear /exit")
    c.print()


def chat_user(text: str) -> None:
    """Display user message with refined styling."""
    c = get_console()
    c.print(f"  [brand]›[/] [text]{_d(text)}[/]")


def chat_assistant(text: str) -> None:
    """Display assistant message with refined styling."""
    c = get_console()
    c.print(f"  [success]●[/] [text]{_d(text)}[/]")


def chat_streaming_token(token: str) -> None:
    """Print a single streaming token — reshaping delegated to LiveStreamRenderer."""
    sys.stdout.write(token)
    sys.stdout.flush()
