"""Arabic script detection and reshaping — fully automatic for all terminals.

Zero-config RTL rendering: detects terminal capabilities and applies
the correct Arabic rendering strategy with no user intervention.

Strategy:
- All terminals: arabic_reshaper for letter joining (contextual shaping)
- Terminals WITHOUT bidi (xterm.js: VS Code, Cursor, Hyper...): manual RTL
- Terminals WITH bidi (Windows Terminal, iTerm2, Kitty, Gnome...): native RTL
"""
from __future__ import annotations

import logging
import os
import sys

logger = logging.getLogger(__name__)

# ── Arabic Unicode ranges ──
_ARABIC_RANGES = [
    (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
    (0xFB50, 0xFDFF), (0xFE70, 0xFEFF),
]

# Characters that should NOT be reshaped (numbers, punctuation, emoji, etc.).
_NEUTRAL_RANGES = [
    (0x0030, 0x0039),   # 0-9
    (0x0020, 0x002F),   # space ! " # $ % & ' ( ) * + , - . /
    (0x003A, 0x0040),   # : ; < = > ? @
    (0x005B, 0x0060),   # [ \ ] ^ _ `
    (0x007B, 0x007E),   # { | } ~
]

# ── Fully automatic terminal bidi detection ──
# No user configuration needed.  The system inspects environment
# variables that each terminal sets uniquely and decides whether
# manual RTL reordering is required.

# Terminals built on xterm.js (NO native bidi)
_TERMINALS_WITHOUT_BIDI = {
    "vscode", "cursor", "windsurf",   # VS Code family
    "hyper", "tabby",                  # Electron-based
    "jetbrains",                       # IntelliJ family
}

# Terminals with confirmed native bidi (fast path, avoid extra checks)
_TERMINALS_WITH_BIDI = {
    "apple_terminal",                  # macOS Terminal.app
    "iterm2",                          # macOS iTerm2
    "kitty",                           # Linux/macOS
    "wezterm",                         # Cross-platform
    "ghostty",                         # Cross-platform
    "alacritty",                       # Cross-platform
    "gnome-terminal",                  # Linux
    "konsole",                         # Linux KDE
    "xfce4-terminal",                  # Linux XFCE
    "lxterminal",                      # Linux LXDE
    "terminator",                      # Linux
    "tilix",                           # Linux
    "foot",                            # Linux Wayland
    "warp",                            # macOS
}


def _terminal_supports_bidi() -> bool:
    """Auto-detect whether the current terminal supports native bidi.

    Inspects well-known environment variables set by each terminal
    emulator.  No user configuration required — this runs silently
    on every Arabic text render.

    Returns:
        True:  terminal handles RTL natively (skip manual bidi)
        False: terminal lacks bidi (apply python-bidi fallback)
    """
    # ── Known bidi-capable terminals (fast positive match) ──
    # Windows Terminal
    if os.environ.get("WT_SESSION"):
        return True
    # iTerm2 (macOS)
    if os.environ.get("ITERM_SESSION_ID"):
        return True
    # Kitty
    if os.environ.get("KITTY_WINDOW_ID"):
        return True
    # WezTerm
    if os.environ.get("WEZTERM_EXECUTABLE"):
        return True
    # Ghostty
    if os.environ.get("GHOSTTY_SOCKET"):
        return True
    # Alacritty (Linux/macOS/Windows)
    if os.environ.get("ALACRITTY_LOG") or os.environ.get("ALACRITTY_SOCKET"):
        return True
    # KDE Konsole — sets KONSOLE_VERSION or KONSOLE_DBUS_SERVICE
    if os.environ.get("KONSOLE_VERSION"):
        return True
    # Gnome Terminal, Tilix, XFCE Terminal — set VTE_VERSION
    if os.environ.get("VTE_VERSION"):
        return True
    # Apple Terminal.app
    if os.environ.get("TERM_PROGRAM") == "Apple_Terminal":
        return True
    # Warp terminal (macOS)
    if os.environ.get("TERM_PROGRAM") == "WarpTerminal":
        return True
    # Foot terminal (Wayland)
    if os.environ.get("TERM") == "foot" or os.environ.get("TERM") == "foot-direct":
        return True

    # ── Known terminals WITHOUT bidi ──
    term_prog = os.environ.get("TERM_PROGRAM", "").lower()
    if term_prog in _TERMINALS_WITHOUT_BIDI:
        return False

    # VS Code forks / derivatives set VSCODE_* or VSCODE_IPC_HOOK_CLI
    if any(k.startswith("VSCODE_") for k in os.environ):
        return False

    # JetBrains IDEs (IntelliJ, PyCharm, etc.) use xterm.js-based terminal
    if os.environ.get("TERMINAL_EMULATOR", "").lower() == "jetbrains":
        return False
    if os.environ.get("JEDITERM_SOURCE"):  # JetBrains Jediterm
        return False

    # ── Known bidi-capable (TERM_PROGRAM based) ──
    if term_prog in _TERMINALS_WITH_BIDI:
        return True

    # ── Platform-aware fallback ──
    # On Windows: if we can't identify the terminal, it's likely
    # the old conhost (cmd.exe / standalone PowerShell) which has
    # poor bidi.  Apply manual RTL to be safe.
    # On Linux/macOS: assume modern terminal with native bidi.
    if sys.platform == "win32":
        return False
    return True


def _cp_is_arabic(cp: int) -> bool:
    """Check if a Unicode code point falls within Arabic ranges."""
    return any(lo <= cp <= hi for lo, hi in _ARABIC_RANGES)


def has_arabic(text: str) -> bool:
    """Return True if the text contains any Arabic character."""
    if not text:
        return False
    return any(_cp_is_arabic(ord(ch)) for ch in text)


def _is_arabic(text: str) -> bool:
    """Detect if text contains significant Arabic content (≥15%)."""
    if not text:
        return False
    arabic_chars = sum(1 for ch in text if _cp_is_arabic(ord(ch)))
    return (arabic_chars / len(text)) >= 0.15


def reshape(text: str) -> str:
    """Prepare Arabic text for terminal display — fully automatic.

    1. arabic_reshaper: contextual letter joining (always needed for connected glyphs)
    2. Rich markup protection: [tag] and [/] markers preserved, never reshaped
    3. Each Arabic text segment gets its own reshaping, mixed LTR/RTL preserved
    """
    if not text or not has_arabic(text):
        return text

    try:
        import arabic_reshaper
    except ImportError:
        return text

    # Step 1: Split text into Rich markup tags and Arabic text segments
    import re
    # Match [tag], [/tag], or bare [/] - keep Rich markup intact
    RICH_TAG = re.compile(r'\[/?[a-zA-Z_][a-zA-Z0-9_ -]*\]|\[/\]')
    segments: list[tuple[bool, str]] = []  # (should_reshape, content)
    pos = 0
    for m in RICH_TAG.finditer(text):
        if m.start() > pos:
            segments.append((True, text[pos:m.start()]))
        segments.append((False, m.group()))
        pos = m.end()
    if pos < len(text):
        segments.append((True, text[pos:]))

    # Step 2: Configure reshaper for proper contextual shaping
    config = {
        "delete_harakat": False,
        "support_zwj": True,
    }
    reshaper = arabic_reshaper.ArabicReshaper(config)

    # Step 3: Reshape only Arabic text segments, keep tags as-is
    parts: list[str] = []
    for should_reshape, chunk in segments:
        if should_reshape and has_arabic(chunk):
            try:
                shaped = reshaper.reshape(chunk)
            except Exception:
                logger.debug("Arabic text reshaping failed", exc_info=True)
                shaped = chunk
            parts.append(shaped)
        else:
            parts.append(chunk)

    return ''.join(parts)


def _d(text: str) -> str:
    """Reshape if Arabic, otherwise return as-is. Convenience wrapper."""
    return reshape(text) if has_arabic(text) else text


def reshape_strict(text: str) -> str:
    """Same as reshape — delegates to reshape() directly.

    Kept for backward compatibility; previously applied aggressive
    bidi reordering which is no longer needed.
    """
    return reshape(text)


def terminal_arabic_quality() -> str:
    """Rate the current terminal's Arabic rendering capability.

    Returns one of: 'native' (Windows Terminal/iTerm2/Kitty…),
    'basic' (modern terminal, unknown bidi), 'poor' (legacy Windows CMD).
    """
    if _terminal_supports_bidi():
        return "native"
    if sys.platform == "win32":
        term = os.environ.get("TERM", "")
        if not term:  # cmd.exe or standalone PowerShell
            return "poor"
    return "basic"


def terminal_arabic_warning() -> str | None:
    """Return a warning message if Arabic will display poorly, or None.

    The message is in Arabic so the user understands the issue.
    """
    quality = terminal_arabic_quality()
    if quality == "poor":
        return (
            "\u26A0\uFE0F \u062A\u0646\u0628\u064A\u0647: "
            "\u0627\u0644\u0637\u0631\u0641\u064A\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 "
            "\u0644\u0627 \u062A\u062F\u0639\u0645 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0628\u0634\u0643\u0644 \u0635\u062D\u064A\u062D.\n"
            "  \u064A\u064F\u0646\u0635\u064E\u062D \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 "
            "Windows Terminal \u0644\u062A\u062C\u0631\u0628\u0629 \u0639\u0631\u0628\u064A\u0629 \u0643\u0627\u0645\u0644\u0629.\n"
            "  \u0644\u062A\u062B\u0628\u064A\u062A\u0647: winget install Microsoft.WindowsTerminal\n"
            "  \u062B\u0645 \u0627\u0641\u062A\u062D\u0647 \u0648\u0634\u063A\u0651\u0644: python -m widdx"
        )
    return None
