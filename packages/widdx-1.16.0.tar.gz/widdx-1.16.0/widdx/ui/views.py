"""Specialised views: status, search, tools, index, git."""
from __future__ import annotations

from .arabic import _d
from .drawing import rule
from .theme import get_console

# ── Status ──────────────────────────────────────────────────────────

def show_status(connected: bool, model_info: dict, recent: list[dict],
                db_path: str, decisions: int, evolution: bool,
                threshold: int) -> None:
    """Display refined system status panel."""
    c = get_console()
    rule("System Status")

    status = "[success]● connected[/]" if connected else "[error]● disconnected[/]"
    c.print(f"    status:    {status}")
    c.print(f"    [dim]architect:[/]  [text]{model_info.get('architect', '?')}[/]")
    c.print(f"    [dim]executor:[/]   [text]{model_info.get('executor', '?')}[/]")

    if recent:
        c.print()
        c.print(f"    [dim]recent tasks ({len(recent)}):[/]")
        for i, t in enumerate(recent[:5], 1):
            icon = "[success]✓[/]" if t["status"] == "completed" else "[warning]·[/]"
            cmd = _d(t['command'][:55])
            c.print(f"      {i}. {icon} [muted]{t['id'][:8]}[/]  [text]{cmd}[/]")

    c.print()
    c.print(
        f"    [dim]db:[/]        [muted]{db_path}[/]\n"
        f"    [dim]decisions:[/] [accent]{decisions}[/]  "
        f"[dim]evolution:[/] [success]{evolution}[/]  "
        f"[dim]threshold:[/] [warning]≥{threshold}[/]"
    )
    c.print()


# ── Search ──────────────────────────────────────────────────────────

def show_search(query: str, matches: list[dict], count: int) -> None:
    """Display refined search results with file grouping."""
    c = get_console()
    rule(f"search: {_d(query)}")

    if not matches:
        c.print("  [warning]▲[/] no matches found")
        return

    c.print(f"  [accent]{count} match{'es' if count != 1 else ''}[/]")
    c.print()

    # Group by file for cleaner display
    by_file: dict[str, list[dict]] = {}
    for m in matches[:40]:
        by_file.setdefault(m['file'], []).append(m)

    for filepath, file_matches in list(by_file.items())[:10]:
        c.print(f"  [info]{filepath}[/]")
        for m in file_matches[:5]:
            text = _d(m['text'][:80].strip())
            c.print(f"    [dim]{m['line']:4d}[/]  [text]{text}[/]")
        if len(file_matches) > 5:
            c.print(f"    [dim]… {len(file_matches) - 5} more in this file[/]")
        c.print()

    if len(by_file) > 10:
        c.print(f"  [dim]… and {len(by_file) - 10} more files[/]")


# ── Tools ───────────────────────────────────────────────────────────

def show_tools() -> None:
    """Display available tools — matches actual TOOL_DEFINITIONS."""
    c = get_console()
    rule("Tools")
    tools = [
        ("Read",       "info",    "read file contents (offset, limit)"),
        ("Write",      "success", "create or overwrite a file"),
        ("Edit",       "warning", "exact string replacement"),
        ("Grep",       "accent",  "regex search across files"),
        ("Glob",       "accent",  "find files by pattern"),
        ("ListDir",    "muted",   "explore directory structure"),
        ("Bash",       "warning", "execute shell commands"),
        ("WebSearch",  "info",    "search the web"),
    ]
    c.print()
    for name, style, desc in tools:
        c.print(f"  [{style}]⏺[/] [text]{name:<12}[/] [dim]{desc}[/]")
    c.print()


# ── Index ───────────────────────────────────────────────────────────

def show_index(total_files: int, total_mb: float, framework: str = "",
               ctx: str = "") -> None:
    """Display refined project index."""
    c = get_console()
    rule("Project Index")
    c.print(f"    [accent]{total_files}[/] files  [accent]{total_mb}[/] MB")
    c.print(f"    [dim]framework:[/dim] [info]{framework or 'unknown'}[/]")
    if ctx:
        c.print()
        for line in ctx.split("\n")[:12]:
            if line.strip():
                c.print(f"    [text]{_d(line)}[/]")


# ── Git ─────────────────────────────────────────────────────────────

def show_git(branch: str, changed: int, files: list[str],
             log: list[str]) -> None:
    """Display refined git status."""
    c = get_console()
    rule(f"git: {branch}")

    if changed > 0:
        c.print(f"    [warning]{changed}[/] file{'s' if changed != 1 else ''} changed")
        for f in files[:12]:
            c.print(f"      [warning]~[/] [text]{_d(f)}[/]")
    else:
        c.print("    [success]✓[/] working tree clean")

    if log:
        c.print()
        for line in log[:5]:
            c.print(f"      [dim]{_d(line)}[/]")
