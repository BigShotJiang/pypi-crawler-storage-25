"""WIDDX Elite v2 — refined professional terminal UI with chat bubbles, 
live dashboard, smooth animations, and consistent #hex color system."""

from __future__ import annotations

import shutil
import time
import random
from datetime import datetime
from rich.console import Console
from rich.theme import Theme
from rich.style import Style
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.align import Align
from rich.box import ROUNDED, HEAVY, SIMPLE
from rich.layout import Layout
from rich.live import Live
from rich.progress import (
    Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
)
from rich.spinner import Spinner
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.columns import Columns
from rich.rule import Rule
from rich.tree import Tree


# ── Color System (consistent #hex, no named colors) ───────────────────

ELITE = {
    "primary":    "#5E9EFF",   # Electric blue
    "secondary":  "#A78BFA",   # Soft purple
    "ok":         "#00c896",   # Teal green — user messages
    "bad":        "#F87171",   # Soft red
    "warn":       "#f5a623",   # Amber — system notices
    "info":       "#7b7bff",   # Periwinkle — AI messages
    "t1":         "#F1F5F9",   # Primary text
    "t2":         "#94A3B8",   # Secondary
    "t3":         "#64748B",   # Tertiary
    "t4":         "#334155",   # Very dim
    "surface":    "#1E293B",   # Panel bg
    "border":     "#334155",   # Borders
}

THEME = Theme({k: v for k, v in ELITE.items()})

_console: Console | None = None

def get_console() -> Console:
    global _console
    if _console is None:
        tw = shutil.get_terminal_size().columns
        _console = Console(theme=THEME, width=min(max(tw, 80), 160),
                           highlight=False, soft_wrap=True)
    return _console


# ── Dividers ───────────────────────────────────────────────────────────

def hr(title: str = "", style: str = "t4") -> Rule:
    return Rule(title, style=style, align="center") if title else Rule(style=style)

def gap(n: int = 1) -> None:
    for _ in range(n): get_console().print()


# ── Message Bubbles (chat-style, with timestamps) ─────────────────────

def user_bubble(text: str) -> None:
    c = get_console()
    ts = datetime.now().strftime("%H:%M")
    head = Text()
    head.append(" YOU ", style=f"bold #7b7bff on #0d0d1f")
    head.append(f" {ts}", style="t3")
    c.print()
    c.print(head)
    c.print(Panel(Text(text, style="t1"), border_style="#7b7bff",
                   box=ROUNDED, padding=(0, 1)))


def ai_bubble(text: str, role: str = "AI") -> None:
    c = get_console()
    ts = datetime.now().strftime("%H:%M")
    head = Text()
    head.append(f" {role} ", style=f"bold #00c896 on #001a0f")
    head.append(f" {ts}", style="t3")
    c.print()
    c.print(head)
    c.print(Panel(Text.from_markup(text), border_style="#00c896",
                   box=ROUNDED, padding=(0, 1)))


def system_bubble(text: str) -> None:
    c = get_console()
    c.print()
    c.print(Panel(Text.from_markup(text, style=f"#f5a623"),
                   border_style="#f5a623", title="[#f5a623]system[/]",
                   title_align="left", box=ROUNDED, padding=(0, 1)))


# ── Tool Execution (animated) ─────────────────────────────────────────

def tool_anim(tools: list[str]) -> None:
    """Show tools executing with live animation → permanent checkmark."""
    c = get_console()
    for tool in tools:
        with Live(Text(f"  ▶ {tool}...", style="t3"), console=c,
                  refresh_per_second=10, transient=True):
            time.sleep(random.uniform(0.15, 0.4))
        c.print(Text(f"  ✓ {tool}", style="ok"))


# ── Thinking Spinner ──────────────────────────────────────────────────

def thinking_spinner(seconds: float = 1.2) -> None:
    c = get_console()
    with Live(
        Spinner("dots", text=Text(" thinking...", style="t3"), style="ok"),
        console=c, refresh_per_second=12, transient=True,
    ):
        time.sleep(seconds)


# ── Live Dashboard ─────────────────────────────────────────────────────

def dashboard_layout() -> Layout:
    layout = Layout()
    layout.split_column(Layout(name="header", size=3), Layout(name="body"), Layout(name="footer", size=3))
    layout["body"].split_row(Layout(name="left"), Layout(name="right"))
    return layout


def dash_header(title: str = "WIDDX") -> Panel:
    return Panel(Text(title, justify="center", style=f"bold {ELITE['primary']}"),
                 style=ELITE["primary"])


def dash_metrics(data: dict) -> Panel:
    t = Table(box=None, show_header=False, padding=(0, 2))
    t.add_column("k", style="t3", min_width=12)
    t.add_column("v", style="bold t1")
    for k, v in data.items():
        t.add_row(k, str(v))
    return Panel(t, title="[bold primary]Metrics[/]", border_style=ELITE["primary"])


def dash_log(lines: list[str]) -> Panel:
    LOG_STYLES = {
        "INFO": "t2", "SUCCESS": ELITE["ok"], "WARN": ELITE["warn"],
        "ERROR": ELITE["bad"], "DEBUG": "t3",
    }
    txt = Text()
    for line in lines[-20:]:
        for level, style in LOG_STYLES.items():
            if f"[{level}]" in line:
                txt.append(line + "\n", style=style)
                break
        else:
            txt.append(line + "\n", style="t3")
    return Panel(txt, title="[bold]Log[/]", border_style="t4")


def dash_board(items: list[dict]) -> Columns:
    panels = []
    for item in items:
        color = ELITE["ok"] if item.get("status") == "done" else ELITE["warn"]
        content = Text()
        content.append("Status: ", style="t3")
        content.append(item.get("status", "?"), style=f"bold {color}")
        panels.append(Panel(content, title=f"[bold]{item['name']}[/]", border_style=color, width=24))
    return Columns(panels)


def dash_progress(tasks: list[dict]) -> Progress:
    """Multi-task progress dashboard. Each task: {name, total, completed}."""
    return Progress(
        SpinnerColumn(), TextColumn("[bold]{task.description:<20}"),
        BarColumn(bar_width=30), TextColumn("[cyan]{task.completed:>3}/{task.total}"),
        TimeElapsedColumn(), console=get_console(), refresh_per_second=10,
    )


def dash_run(update_fn, refresh: float = 0.25) -> None:
    """Run a full-screen live dashboard with clean KeyboardInterrupt exit.

    update_fn(layout) is called each cycle to refresh panes.
    """
    layout = dashboard_layout()
    c = get_console()
    try:
        with Live(layout, refresh_per_second=4, screen=True, console=c) as live:
            while True:
                update_fn(layout)
                time.sleep(refresh)
    except (KeyboardInterrupt, SystemExit):
        c.print()
        c.print(hr(style="t4"))
        c.print(Align.center(Text("Dashboard closed", style="t3")))


# ── Boot Screen ───────────────────────────────────────────────────────

def elite_boot(framework: str = "python", files: int = 0,
               version: str = "1.15.0", model: str = "") -> None:
    c = get_console()
    tw = c.width or 80
    logo = Text()
    logo.append("╭──────────────────────────────────╮\n", style="t4")
    logo.append("│                                  │\n", style="t4")
    logo.append("│   ", style="t4")
    logo.append("▐▛▜▌", style=f"bold {ELITE['primary']}")
    logo.append("  ", style="t4")
    logo.append("W  I  D  D  X", style="bold t1")
    logo.append("   │\n", style="t4")
    logo.append("│                                  │\n", style="t4")
    logo.append("│   ", style="t4")
    logo.append("autonomous AI terminal", style="t2")
    logo.append("   │\n", style="t4")
    logo.append("│                                  │\n", style="t4")
    logo.append("╰", style="t4")
    logo.append(f"  {version}", style="t3")
    logo.append(" " * (24 - len(version)), style="")
    logo.append("╯\n", style="t4")
    c.print()
    c.print(Align.center(logo))
    info = Text()
    info.append(f" {framework} ", style=f"bold {ELITE['primary']}")
    info.append(" · ", style="t4")
    info.append(f"{files} files", style="t2")
    if model: info.append(" · " + model, style="t3")
    c.print(); c.print(Align.center(info))
    cmds = Text()
    for k, d in [("Esc", "skip"), ("↵", "start"), ("task", "work"), ("/help", "cmds")]:
        cmds.append(f" {k} ", style=f"bold {ELITE['primary']} on surface")
        cmds.append(f" {d}  ", style="t3")
    c.print(); c.print(Align.center(cmds)); c.print()


# ── Chat Welcome ──────────────────────────────────────────────────────

def welcome(framework: str, files: int) -> None:
    c = get_console()
    c.print()
    c.print(hr("Session"))
    c.print(f"  [t2]framework:[/] [primary]{framework}[/]  [t4]·[/]  [t2]files:[/] [primary]{files}[/]")
    c.print(f"  [t4]Type your task or [primary]/help[/] for commands.[/]")
    c.print()


# ── Status Messages ───────────────────────────────────────────────────

def ok(msg: str) -> None:
    get_console().print(f"  [{ELITE['ok']}]✓[/] [t1]{msg}[/]")

def fail(msg: str) -> None:
    get_console().print(f"  [{ELITE['ok']}]✗[/] [bad]{msg}[/]")

def warn(msg: str) -> None:
    get_console().print(f"  [{ELITE['ok']}]▲[/] [warn]{msg}[/]")


# ── Tool Calling ──────────────────────────────────────────────────────

_TOOLS = {
    "read": ("📖", ELITE["info"]), "write": ("✏️", ELITE["ok"]),
    "shell": ("⚡", ELITE["warn"]), "web": ("🌐", ELITE["secondary"]),
    "search": ("🔍", ELITE["info"]), "git": ("📦", ELITE["ok"]),
}

def tool(name: str, detail: str = "") -> str:
    nl = name.lower()
    for k, (icon, color) in _TOOLS.items():
        if k in nl: return f"  [t4]{icon}[/] [{color}]{name}[/][t3]{' ' + detail if detail else ''}[/]"
    return f"  [t4]◈[/] [info]{name}[/][t3]{' ' + detail if detail else ''}[/]"


# ── Syntax Highlighting ────────────────────────────────────────────────

def code(code_str: str, lang: str = "python", title: str = "") -> Panel:
    return Panel(Syntax(code_str, lang, theme="monokai", line_numbers=True),
                 title=f"[t3]{title}[/]" if title else None,
                 title_align="left", border_style="t4", box=ROUNDED, padding=(1, 2))


# ── Help Table ─────────────────────────────────────────────────────────

def help_table(commands: dict) -> None:
    c = get_console()
    t = Table(title=f"[bold {ELITE['primary']}]Commands[/]", border_style="t4",
              header_style=f"bold {ELITE['warn']}", box=SIMPLE)
    t.add_column("Command", style=f"bold {ELITE['primary']}", min_width=14)
    t.add_column("Description", style="t1")
    for cmd, desc in commands.items():
        t.add_row(cmd, desc)
    c.print(t)


# ── File Tree ──────────────────────────────────────────────────────────

def file_tree(paths: list[str], root_name: str = "project") -> Tree:
    tree = Tree(f"[bold primary]{root_name}/[/]")
    by_dir: dict[str, list[str]] = {}
    for p in sorted(paths):
        parts = p.replace("\\", "/").split("/")
        d = "/".join(parts[:-1]) if len(parts) > 1 else "."
        by_dir.setdefault(d, []).append(parts[-1])
    for d, files in sorted(by_dir.items()):
        node = tree
        if d != ".":
            for part in d.split("/"):
                node = next((c for c in node.children if c.label and part in str(c.label)), node.add(f"[info]{part}/[/]"))
        for f in files[:20]:
            ext = f.rsplit(".", 1)[-1] if "." in f else ""
            icon = {"py": "🐍", "js": "🟨", "ts": "🔷", "md": "📝", "json": "📋", "yaml": "⚙️"}.get(ext, "📄")
            node.add(f"[t3]{icon}[/] {f}")
    return tree
