"""Professional UI components — Markdown, Syntax, Spinners, Diffs, Trees, Dialogs."""
from __future__ import annotations

import difflib
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.layout import Layout
    from rich.live import Live

from .arabic import _d
from .theme import get_console

# ══════════════════════════════════════════════════════════════════════
# Markdown Rendering
# ══════════════════════════════════════════════════════════════════════

def render_markdown(text: str, *, code_theme: str = "one-dark") -> None:
    """Render markdown with syntax-highlighted code blocks."""
    from rich.markdown import Markdown
    c = get_console()
    try:
        c.print(Markdown(_d(text), code_theme=code_theme, inline_code_lexer="python"))
    except Exception:
        # Fallback if one-dark is not available
        c.print(Markdown(_d(text), code_theme="monokai", inline_code_lexer="python"))


def render_code(code: str, language: str = "python", *,
                line_numbers: bool = True, theme: str = "monokai") -> None:
    """Render a standalone code block with syntax highlighting."""
    from rich.panel import Panel
    from rich.syntax import Syntax
    c = get_console()
    c.print(Panel(
        Syntax(code, language, theme=theme, line_numbers=line_numbers, word_wrap=True),
        border_style="dim",
    ))


# ══════════════════════════════════════════════════════════════════════
# Progress Indicators
# ══════════════════════════════════════════════════════════════════════

@contextmanager
def spinner(description: str = "working", *, done_msg: str = "") -> Generator[None, None, None]:
    """Animated spinner that clears itself when done.

    Usage:
        with spinner("indexing project"):
            ...
        # → prints nothing on exit (transient)

        with spinner("indexing project", done_msg="✓ indexed"):
            ...
        # → prints done_msg after spinner clears
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn

    c = get_console()
    with Progress(
        SpinnerColumn(spinner_name="dots12", style="brand"),
        TextColumn("[dim]{task.description}[/]"),
        console=c,
        transient=True,          # clears the line when done
        refresh_per_second=15,
    ) as progress:
        progress.add_task(description=_d(description), total=None)
        yield

    if done_msg:
        c.print(f"  [success]✓[/] [dim]{_d(done_msg)}[/]")


@contextmanager
def progress_bar(total: int, description: str = "processing") -> Generator[object, None, None]:
    """Determinate progress bar."""
    from rich.progress import BarColumn, Progress, TextColumn, TimeRemainingColumn

    c = get_console()
    with Progress(
        TextColumn("[dim]{task.description}[/]"),
        BarColumn(bar_width=36, complete_style="success",
                  finished_style="success", pulse_style="brand"),
        TextColumn("[accent]{task.percentage:>3.0f}%[/]"),
        TimeRemainingColumn(compact=True, elapsed_when_finished=True),
        console=c,
        transient=False,
    ) as progress:
        task_id = progress.add_task(description=_d(description), total=total)

        class _Adapter:
            def advance(self, amount: int = 1) -> None:
                progress.advance(task_id, amount)
            def update(self, **kwargs) -> None:
                progress.update(task_id, **kwargs)

        yield _Adapter()


# ══════════════════════════════════════════════════════════════════════
# Diff Display
# ══════════════════════════════════════════════════════════════════════

def render_diff(old_text: str, new_text: str, *,
                old_label: str = "before", new_label: str = "after") -> None:
    """Full unified diff in a panel."""
    from rich.panel import Panel
    from rich.text import Text

    c = get_console()
    old_lines = old_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    diff_lines = list(difflib.unified_diff(old_lines, new_lines,
                                           fromfile=old_label, tofile=new_label))
    if not diff_lines:
        c.print("  [dim](no changes)[/]")
        return

    text = Text()
    for line in diff_lines[:300]:
        line = line.rstrip("\n\r")
        dl = _d(line)
        if line.startswith(("---", "+++")):
            text.append(f"  {dl}\n", style="dim")
        elif line.startswith("@@"):
            text.append(f"  {dl}\n", style="info")
        elif line.startswith("+"):
            text.append(f"  {dl}\n", style="success")
        elif line.startswith("-"):
            text.append(f"  {dl}\n", style="error")
        else:
            text.append(f"  {dl}\n", style="dim")

    if len(diff_lines) > 300:
        text.append(f"  … {len(diff_lines) - 300} more lines\n", style="dim")

    c.print(Panel(text, title=f"[brand]{old_label} → {new_label}[/]", border_style="dim"))


# ══════════════════════════════════════════════════════════════════════
# File Tree
# ══════════════════════════════════════════════════════════════════════

def file_tree(root_path: str | Path, *, max_depth: int = 3,
              show_hidden: bool = False) -> None:
    """Directory tree with file-type icons."""
    from rich.tree import Tree

    c = get_console()
    root = Path(root_path).expanduser().resolve()
    if not root.exists():
        c.print(f"  [error]✗[/] path not found: {root_path}")
        return

    _IGNORE = {
        "node_modules", "__pycache__", ".git", ".venv", "venv",
        ".next", "dist", "build", ".cache", ".egg-info",
        ".mypy_cache", ".ruff_cache", ".tox", ".pytest_cache",
        "coverage", "htmlcov",
    }

    tree = Tree(f"[brand]⏺ {root.name}/[/]")

    def _walk(dir_path: Path, branch: Tree, depth: int) -> None:
        if depth > max_depth:
            try:
                if any(True for _ in dir_path.iterdir()):
                    branch.add("[dim]···[/]")
            except (PermissionError, OSError):
                pass
            return
        try:
            entries = sorted(dir_path.iterdir(),
                             key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            branch.add("[error]✗ permission denied[/]")
            return

        dirs = files = 0
        for entry in entries:
            if entry.name in _IGNORE:
                continue
            if not show_hidden and entry.name.startswith("."):
                continue
            if entry.is_dir():
                dirs += 1
                if dirs > 50:
                    break
                sub = branch.add(f"[info]{entry.name}/[/]")
                _walk(entry, sub, depth + 1)
            else:
                files += 1
                if files > 100:
                    break
                sz = entry.stat().st_size
                sz_str = (f"{sz}B" if sz < 1024
                          else f"{sz/1024:.1f}KB" if sz < 1024*1024
                          else f"{sz/(1024*1024):.1f}MB")
                branch.add(f"[text]{get_file_icon(entry.name)} {entry.name}[/] [dim]{sz_str}[/]")

    _walk(root, tree, 0)
    c.print(tree)


# ══════════════════════════════════════════════════════════════════════
# Dialogs
# ══════════════════════════════════════════════════════════════════════

def get_file_icon(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    return {
        ".py": "py", ".pyw": "py",
        ".js": "js", ".ts": "ts", ".jsx": "jsx", ".tsx": "tsx",
        ".html": "html", ".htm": "html", ".css": "css",
        ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
        ".md": "md", ".txt": "txt",
        ".rs": "rs", ".go": "go", ".java": "java",
        ".c": "c", ".cpp": "cpp", ".h": "h",
        ".rb": "rb", ".php": "php", ".swift": "swift",
        ".sql": "sql", ".db": "db",
        ".sh": "sh", ".bash": "sh", ".ps1": "ps1",
        ".env": "env", ".gitignore": "git",
    }.get(ext, "file")


def confirm(message: str, *, default: bool = False) -> bool:
    """Yes/no prompt — uses prompt_toolkit if available for consistent styling."""
    c = get_console()
    hint = "Y/n" if default else "y/N"

    # Try prompt_toolkit first for consistent look
    try:
        from prompt_toolkit import prompt as pt_prompt
        from prompt_toolkit.formatted_text import HTML
        answer = pt_prompt(HTML(
            f'  <ansiyellow>?</ansiyellow> '
            f'<ansiwhite>{_d(message)}</ansiwhite> '
            f'<ansibrightblack>[{hint}]</ansibrightblack> '
        )).strip().lower()
    except Exception:
        c.print(f"  [warning]?[/] [text]{_d(message)}[/] [dim][{hint}][/]", end=" ")
        try:
            answer = input().strip().lower()
        except (KeyboardInterrupt, EOFError):
            return False

    if not answer:
        return default
    return answer.startswith("y")


def confirm_with_options(message: str, options: list[str],
                         default: str | None = None) -> str:
    """Multi-option prompt — shows a numbered list.

    User types a number (1,2,3…), the first letter, or the full name.
    """
    c = get_console()
    c.print(f"  [warning]?[/] [text]{_d(message)}[/]")
    for i, opt in enumerate(options, 1):
        marker = f"[bold]{i}[/]" if opt == default else f" {i}"
        c.print(f"  {marker}. {opt}")
    try:
        answer = input("  [dim]❯[/] ").strip()
    except (KeyboardInterrupt, EOFError):
        return default or options[0]

    if not answer and default:
        return default
    lower = answer.lower()
    for opt in options:
        if lower == opt.lower() or lower == opt[0].lower():
            return opt
    try:
        idx = int(answer) - 1
        if 0 <= idx < len(options):
            return options[idx]
    except ValueError:
        pass
    return default or options[0]


# ══════════════════════════════════════════════════════════════════════
# Status Line
# ══════════════════════════════════════════════════════════════════════

def status_line(parts: dict[str, str], *, progress: float | None = None) -> None:
    """Compact key·value status bar."""
    from rich import box
    from rich.panel import Panel
    from rich.text import Text

    c = get_console()
    text = Text()
    for i, (key, value) in enumerate(parts.items()):
        if i > 0:
            text.append("  ·  ", style="dim")
        text.append(f"{key}: ", style="dim")
        text.append(value, style="accent")

    if progress is not None and 0 <= progress <= 1:
        filled = int(20 * progress)
        bar = "█" * filled + "░" * (20 - filled)
        text.append(f"  [{bar}] {int(progress * 100)}%", style="brand")

    c.print(Panel(text, border_style="dim", padding=(0, 1), box=box.ROUNDED))


def create_layout() -> Layout:
    """Rich Layout with header / main / status areas."""
    from rich.layout import Layout as _Layout
    layout = _Layout()
    layout.split(
        _Layout(name="header", size=3),
        _Layout(name="main"),
        _Layout(name="status", size=3),
    )
    layout["main"].split_row(
        _Layout(name="chat", ratio=3),
        _Layout(name="sidebar", ratio=1, visible=False),
    )
    return layout


# ══════════════════════════════════════════════════════════════════════
# Live Streaming Renderer
# ══════════════════════════════════════════════════════════════════════

class LiveStreamRenderer:
    """Real-time streaming output — renders markdown as tokens arrive.

    Design:
    - Uses Rich Live with transient=False so output stays on screen.
    - finish() stops the Live context; the final render is already visible.
    - No double-print: finish() does NOT re-print the buffer.
    """

    def __init__(self, *, code_theme: str = "one-dark") -> None:
        self._code_theme = code_theme
        self._buffer: str = ""
        self._live: Live | None = None
        self._started = False

    def start(self) -> None:
        """Begin the live display."""
        from rich.live import Live
        from rich.markdown import Markdown

        c = get_console()
        self._live = Live(
            Markdown("", code_theme=self._code_theme),
            console=c,
            refresh_per_second=12,
            transient=False,          # keep output visible after stop()
            vertical_overflow="visible",
        )
        self._live.start()
        self._started = True

    def feed(self, token: str) -> None:
        """Append a token and refresh the live display."""
        from rich.markdown import Markdown

        self._buffer += token
        if self._live is not None:
            try:
                self._live.update(
                    Markdown(_d(self._buffer), code_theme=self._code_theme)
                )
            except Exception:
                pass

    def finish(self) -> str:
        """Stop the live display.

        The final rendered content is already on screen — no re-print needed.
        Returns the accumulated raw text.
        """
        if self._live is not None:
            try:
                self._live.stop()
            except Exception:
                pass
            self._live = None
        return self._buffer

    @property
    def text(self) -> str:
        return self._buffer
