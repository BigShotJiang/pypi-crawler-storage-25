"""SessionStart and TaskCompleted hook: log session and task events."""

import json
import logging
import os
import sys
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

LOG_DIR = os.path.expanduser("~/.widdx/logs")


def ensure_log_dir():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
    except OSError as e:
        logger.warning("Failed to create log directory %s: %s", LOG_DIR, e)


def log_session_start(data: dict) -> None:
    """Log session start event."""
    ensure_log_dir()
    session_id = data.get("session_id", "unknown")
    cwd = data.get("cwd", "")
    log_file = os.path.join(LOG_DIR, "sessions.log")

    entry = json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "SessionStart",
        "session_id": session_id,
        "cwd": cwd,
    })

    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(entry + "\n")
    except OSError as e:
        logger.warning("Failed to write session start log: %s", e)


def log_task_completed(data: dict) -> None:
    """Log task completion event."""
    ensure_log_dir()
    log_file = os.path.join(LOG_DIR, "tasks.log")

    entry = json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "TaskCompleted",
        "session_id": data.get("session_id", "unknown"),
    })

    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(entry + "\n")
    except OSError as e:
        logger.warning("Failed to write task completed log: %s", e)


def main():
    event = os.environ.get("WIDDX_HOOK_EVENT", "")
    if not event:
        # Try parsing from --event flag
        for arg in sys.argv:
            if arg.startswith("--event"):
                event = arg.split("=", 1)[-1]

    try:
        data = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        data = {}

    if event == "SessionStart":
        log_session_start(data)
    elif event == "TaskCompleted":
        log_task_completed(data)

    sys.exit(0)


if __name__ == "__main__":
    main()
