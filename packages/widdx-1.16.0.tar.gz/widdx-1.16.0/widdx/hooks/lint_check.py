"""PostToolUse hook: run lint checks on modified files after Edit/Write."""

import json
import os
import subprocess
import sys


def get_lint_args(file_path: str) -> list[str] | None:
    """Determine the appropriate lint command args based on file extension.

    Returns a list of arguments suitable for ``subprocess.run(..., shell=False)``.
    """
    ext = os.path.splitext(file_path)[1].lower()

    linters: dict[str, list[str]] = {
        ".py": ["python", "-m", "ruff", "check", file_path, "--quiet"],
        ".js": ["npx", "eslint", file_path, "--quiet"],
        ".ts": ["npx", "eslint", file_path, "--quiet"],
        ".tsx": ["npx", "eslint", file_path, "--quiet"],
        ".jsx": ["npx", "eslint", file_path, "--quiet"],
        ".css": ["npx", "stylelint", file_path, "--quiet"],
        ".go": ["go", "vet", file_path],
        ".rs": ["cargo", "clippy", "--manifest-path", file_path],
    }

    return linters.get(ext)


def main():
    try:
        hook_input = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        hook_input = {}

    file_path = hook_input.get("file_path", "")
    if not file_path:
        file_path = hook_input.get("tool_input", {}).get("file_path", "")
    if not file_path:
        file_path = os.environ.get("WIDDX_FILE_PATH", "")

    if not file_path:
        sys.exit(0)

    lint_args = get_lint_args(file_path)
    if lint_args is None:
        sys.exit(0)

    try:
        result = subprocess.run(
            lint_args,
            shell=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            output = (result.stdout + result.stderr).strip()
            if output:
                print(json.dumps({
                    "hookSpecificOutput": {
                        "hookEventName": "PostToolUse",
                        "additionalContext": f"Lint issues found in {file_path}:\n{output[:5000]}"
                    }
                }))
    except (subprocess.TimeoutExpired, OSError):
        pass

    sys.exit(0)


if __name__ == "__main__":
    main()
