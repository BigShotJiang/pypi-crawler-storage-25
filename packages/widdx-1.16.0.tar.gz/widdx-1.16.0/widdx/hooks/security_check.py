"""PreToolUse hook: block dangerous shell commands before execution."""

import json
import os
import re
import sys

DESTRUCTIVE_PATTERNS = [
    r"rm\s+-rf\s+/",
    r"rm\s+-rf\s+~",
    r"rm\s+-rf\s+\$HOME",
    r"del\s+/f\s+/s",
    r"format\s+[a-zA-Z]:",
    r">\s*/dev/sda",
    r"mkfs\.",
    r"dd\s+if=",
    r":(){ :|:& };:",       # fork bomb
    r"chmod\s+-R\s+777\s+/",
    r"chown\s+-R\s+root\s+/",
    r"DROP\s+(TABLE|DATABASE)",
    r"TRUNCATE\s+TABLE",
    r"ALTER\s+TABLE.*DROP",
    r"git\s+push\s+--force.*main",
    r"git\s+push\s+--force.*master",
    r"git\s+reset\s+--hard",
    r"docker\s+rm\s+-f",
    r"docker\s+system\s+prune",
    r"DROP\s+SCHEMA",
    r"REVOKE\s+ALL",
]

def is_destructive(command: str) -> tuple[bool, str]:
    """Check if a command matches destructive patterns."""
    for pattern in DESTRUCTIVE_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            return True, pattern
    return False, ""


def main():
    try:
        hook_input = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        hook_input = {}

    command = hook_input.get("command", "")
    if not command:
        command = hook_input.get("tool_input", {}).get("command", "")
    if not command:
        command = os.environ.get("WIDDX_COMMAND", "")

    if not command:
        sys.exit(0)

    destructive, pattern = is_destructive(command)

    if destructive:
        result = {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": f"Destructive command blocked. Matched pattern: {pattern}"
            }
        }
        json.dump(result, sys.stdout)
        sys.exit(2)

    sys.exit(0)


if __name__ == "__main__":
    main()
