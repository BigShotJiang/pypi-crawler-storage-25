"""
widdx/hooks/events.py — HookEvent enum (GAP-2)

Defines the lifecycle events that the hooks system can fire.
"""

from __future__ import annotations

from enum import Enum


class HookEvent(str, Enum):
    PRE_TOOL_USE   = "PreToolUse"
    POST_TOOL_USE  = "PostToolUse"
    SESSION_START  = "SessionStart"
    TASK_COMPLETED = "TaskCompleted"


__all__ = ["HookEvent"]
