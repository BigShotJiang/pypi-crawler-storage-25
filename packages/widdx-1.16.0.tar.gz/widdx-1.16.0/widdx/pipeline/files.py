"""File extraction from LLM output and validation."""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)


def _extract_and_save(self, command: str, output: str) -> str:
    """Extract code blocks from output and save files mentioned in the command.

    Handles multiple code fence blocks, naming extras with _2, _3 suffixes.
    Path traversal is blocked \u2014 files must stay within the project root.
    """
    saved: list[str] = []
    target_match = re.search(r'(?i)save\s+to\s+(\S+)', command)
    base_path = target_match.group(1) if target_match else None

    if not base_path:
        return ""

    project_root = Path.cwd().resolve()
    requested = Path(base_path)
    requested = (project_root / requested).resolve() if not requested.is_absolute() else requested.resolve()

    try:
        requested.relative_to(project_root)
    except ValueError:
        logger.warning(
            "Path traversal blocked: %s is outside project root %s", requested, project_root
        )
        return ""

    p = requested
    base_stem = p.stem
    base_ext = p.suffix

    fence_positions = [m.start() for m in re.finditer(r'```', output)]

    block_count = 0
    for i in range(0, len(fence_positions) - 1, 2):
        open_pos = fence_positions[i]
        close_pos = fence_positions[i + 1]

        after_open = output.find('\n', open_pos)
        if after_open == -1 or after_open >= close_pos:
            continue

        code = output[after_open + 1 : close_pos].strip()
        if len(code) < 3:
            continue

        block_count += 1
        file_path = str(p) if block_count == 1 else str(p.parent / f"{base_stem}_{block_count}{base_ext}")

        try:
            path = Path(file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(code, encoding="utf-8")
            saved.append(str(path))
            self._validate_extracted_code(str(path), code)
        except OSError:
            continue

    if not saved:
        code = output.strip()
        if len(code) >= 10:
            try:
                path = p
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(code, encoding="utf-8")
                saved.append(str(path))
            except OSError:
                return ""

    if not saved:
        return ""

    return "Files saved:\n" + "\n".join(f"  \u2192 {s}" for s in saved)


def _validate_extracted_code(self, file_path: str, code: str) -> None:
    """Basic syntax validation for extracted code. Logs warnings, never blocks."""
    ext = Path(file_path).suffix.lower()
    errors: list[str] = []
    if ext == ".py":
        try:
            compile(code, file_path, "exec")
        except SyntaxError as e:
            errors.append(f"Python syntax error: {e}")
    elif ext == ".json":
        try:
            json.loads(code)
        except json.JSONDecodeError as e:
            errors.append(f"JSON syntax error: {e}")

    for err in errors:
        logger.warning("Code extraction validation [%s]: %s", file_path, err)
