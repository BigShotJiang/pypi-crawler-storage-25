"""Simple execution path — lightweight tool-loop execution with framework awareness."""
from __future__ import annotations

import time
from typing import Any


def _execute_simple(self, command: str, task_id: str) -> dict[str, Any]:
    """Simple tool-enabled execution path with retry.
    Uses the ToolLoop (which provides Write/Read/etc. tools) so the model
    creates actual files instead of just generating text.
    """
    from widdx.tool_loop import ToolLoop
    from widdx.tool_loop.system_prompt import _detect_framework_from_task

    result_text = ""
    error_msg = ""

    for attempt in range(self._max_retries + 1):
        try:
            loop = ToolLoop(self._router, max_steps=20)
            loop.set_project_context(self._simple_system_prompt(command))
            detected = _detect_framework_from_task(command)
            if detected:
                loop.set_framework(detected[0])
            result_text = loop.run(command)
            if result_text and "error:" not in result_text.lower():
                break
            error_msg = result_text
        except Exception as exc:
            error_msg = str(exc)
            if attempt < self._max_retries:
                time.sleep(1.0 * (attempt + 1))
            else:
                break

    if error_msg and not result_text:
        result = {"error": error_msg}
    else:
        result = {"text": result_text}

    self._memory.log_decision(
        task_id, "execution", "direct", command,
        result.get("text", "")[:500] if not self._is_error(result) else str(result.get("error", ""))[:500],
        "deepseek",
    )
    return result


def _simple_system_prompt(self, command: str = "") -> str:
    """Build a simple system prompt, framework-aware when possible."""
    from widdx.tool_loop.system_prompt import _detect_framework_from_task, _framework_prompt_section

    base = (
        "You are WIDDX CLI, an AI coding agent.\n"
        "Rules: Use clear, readable code. Handle errors first.\n"
        "Use guard clauses. Functions=verbs, variables=nouns. No trivial comments.\n"
        "You have tools available: Write (create files), Read, Edit, Bash, Glob, Grep.\n"
        "Use the Write tool to create project files \u2014 do NOT just describe what to build.\n"
        "Actually write the files. Build complete, working projects."
    )

    if command:
        detected = _detect_framework_from_task(command)
        if detected:
            fw_key, lang = detected
            fw_rules = _framework_prompt_section(fw_key, lang)
            if fw_rules:
                return base + "\n" + fw_rules

    return base


def _get_project_context(self) -> str:
    """Get current project context from indexer."""
    try:
        from widdx.indexer import ProjectIndexer
        indexer = ProjectIndexer()
        return indexer.context_for_ai()
    except Exception:
        return ""
