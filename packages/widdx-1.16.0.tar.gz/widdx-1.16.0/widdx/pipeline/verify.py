"""Post-generation verification — catches common issues before tests run.

Language-agnostic: detects project languages from file extensions and
runs only the checks appropriate for each language.
"""
from __future__ import annotations

import ast
import json as _json
import re
from pathlib import Path
from typing import NamedTuple


class Issue(NamedTuple):
    severity: str  # "error" | "warning"
    file: str
    line: int
    message: str


# Sentinel — if a file starts with this shebang it counts for the language too
_SHEBANG_MAP: dict[str, str] = {
    "python": ("python", "python3"),
    "php": ("php",),
    "node": ("node", "nodejs"),
    "bash": ("bash", "sh", "zsh"),
    "ruby": ("ruby",),
}

_EXT_LANG_MAP: dict[str, str] = {
    ".py": "python",
    ".pyw": "python",
    ".php": "php",
    ".phtml": "php",
    ".js": "javascript",
    ".mjs": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".rb": "ruby",
    ".cs": "csharp",
    ".swift": "swift",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".scala": "scala",
    ".dart": "dart",
    ".ex": "elixir",
    ".exs": "elixir",
    ".cr": "crystal",
    ".zig": "zig",
    ".r": "r",
    ".lua": "lua",
    ".hs": "haskell",
    ".ml": "ocaml",
    ".sql": "sql",
    ".sh": "bash",
    ".bash": "bash",
    ".zsh": "bash",
    ".ps1": "powershell",
}


def _detect_languages(root: Path) -> set[str]:
    """Detect which programming languages are used in the project."""
    langs: set[str] = set()
    for f in root.rglob("*"):
        if not f.is_file():
            continue
        ext = f.suffix.lower()
        if ext in _EXT_LANG_MAP:
            langs.add(_EXT_LANG_MAP[ext])
        # Check shebangs
        if not ext or ext in (".sh", ".bash", ".zsh", ""):
            try:
                first = f.read_bytes()[:80].decode("utf-8", errors="ignore")
                if first.startswith("#!"):
                    for lang, interpreters in _SHEBANG_MAP.items():
                        if any(f" {i}" in first or f"/{i}" in first for i in interpreters):
                            langs.add(lang)
            except OSError:
                pass
    # Detect from project config files (no source code needed)
    _cfg_lang: dict[str, set[str]] = {
        "requirements*.txt": {"python"},
        "Pipfile": {"python"},
        "Pipfile.lock": {"python"},
        "pyproject.toml": {"python"},
        "setup.py": {"python"},
        "setup.cfg": {"python"},
        "tox.ini": {"python"},
        "Cargo.toml": {"rust"},
        "Cargo.lock": {"rust"},
        "go.mod": {"go"},
        "composer.json": {"php"},
        "package.json": {"javascript"},
        "yarn.lock": {"javascript"},
        "pnpm-lock.yaml": {"javascript"},
        "Gemfile": {"ruby"},
        "Gemfile.lock": {"ruby"},
        "mix.exs": {"elixir"},
        "pubspec.yaml": {"dart"},
        "*.sln": {"csharp"},
        "*.csproj": {"csharp"},
        "pom.xml": {"java"},
        "build.gradle": {"java"},
        "build.gradle.kts": {"java"},
        "stack.yaml": {"haskell"},
        "shard.yml": {"crystal"},
        "CMakeLists.txt": {"cpp"},
    }
    for pattern, language_set in _cfg_lang.items():
        if list(root.rglob(pattern)):
            langs.update(language_set)
    return langs


def verify_project(root: Path) -> list[Issue]:
    """Run verification checks appropriate for the project's languages.

    Args:
        root: Project root directory.

    Returns:
        List of issues found (empty if project looks good).
    """
    issues: list[Issue] = []
    langs = _detect_languages(root)

    # ── Generic checks (all languages) ────────────────────────────
    issues.extend(_check_inconsistent_indentation(root))
    issues.extend(_check_missing_newline(root))
    issues.extend(_check_empty_files(root))

    # ── Language-specific checks ──────────────────────────────────
    if "python" in langs:
        issues.extend(_check_import_paths(root))
        issues.extend(_check_bcrypt_compatibility(root))
        issues.extend(_check_datetime_usage(root))
        issues.extend(_check_pydantic_models(root))

    if "php" in langs:
        issues.extend(_check_php_namespace_paths(root))

    if "javascript" in langs or "typescript" in langs:
        issues.extend(_check_package_json(root))

    return issues


# ═══════════════════════════════════════════════════════════════════
# Generic checks (run for every project)
# ═══════════════════════════════════════════════════════════════════


def _check_inconsistent_indentation(root: Path) -> list[Issue]:
    """Warn on files that mix tabs and spaces."""
    issues: list[Issue] = []
    for f in _source_files(root):
        try:
            text = f.read_text(encoding="utf-8")
        except OSError:
            continue
        has_tabs = False
        has_spaces = False
        for line in text.splitlines():
            if line.startswith("\t"):
                has_tabs = True
            if line.startswith(" "):
                has_spaces = True
            if has_tabs and has_spaces:
                rel = f.relative_to(root)
                issues.append(Issue("warning", str(rel), 0, "File mixes tabs and spaces"))
                break
    return issues


def _check_missing_newline(root: Path) -> list[Issue]:
    """Warn on files missing a trailing newline."""
    issues: list[Issue] = []
    for f in _source_files(root):
        try:
            text = f.read_bytes()
        except OSError:
            continue
        if text and not text.endswith(b"\n"):
            rel = f.relative_to(root)
            issues.append(Issue("warning", str(rel), 0, "File is missing a trailing newline"))
    return issues


def _check_empty_files(root: Path) -> list[Issue]:
    """Warn on empty source files."""
    issues: list[Issue] = []
    for f in _source_files(root):
        try:
            if f.stat().st_size == 0:
                rel = f.relative_to(root)
                issues.append(Issue("warning", str(rel), 0, "File is empty"))
        except OSError:
            pass
    return issues


def _source_files(root: Path) -> list[Path]:
    """Return all source files (code + config) in the project."""
    exts = set(_EXT_LANG_MAP.keys()) | {".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".env.example"}
    return [f for f in root.rglob("*") if f.is_file() and f.suffix.lower() in exts]


# ═══════════════════════════════════════════════════════════════════
# Python checks
# ═══════════════════════════════════════════════════════════════════


def _check_import_paths(root: Path) -> list[Issue]:
    """Verify that Python import paths match actual directory structure."""
    issues: list[Issue] = []
    py_files = list(root.rglob("*.py"))
    available_modules: set[str] = set()
    for py_file in py_files:
        rel = py_file.relative_to(root)
        parts = list(rel.parts)
        parts[-1] = parts[-1].replace(".py", "")
        if parts[-1] == "__init__":
            parts = parts[:-1]
        if parts:
            available_modules.add(".".join(parts))
    for py_file in py_files:
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    _check_module_alias(alias.name, py_file, root, available_modules, issues)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    _check_module_alias(node.module, py_file, root, available_modules, issues)
    return issues


def _check_module_alias(module: str, py_file: Path, root: Path, available: set[str], issues: list[Issue]) -> None:
    if not module.startswith(("app.", "src.", "widdx.")):
        return
    parts = module.split(".")
    found = False
    for i in range(len(parts), 0, -1):
        candidate = ".".join(parts[:i])
        if candidate in available:
            found = True
            break
    if not found:
        rel_file = py_file.relative_to(root)
        issues.append(Issue("error", str(rel_file), _find_import_line(py_file, module), f"Import '{module}' does not match any existing module"))


def _find_import_line(py_file: Path, module: str) -> int:
    try:
        for i, line in enumerate(py_file.read_text(encoding="utf-8").splitlines(), 1):
            if module in line and ("import" in line or "from" in line):
                return i
    except OSError:
        pass
    return 0


def _check_bcrypt_compatibility(root: Path) -> list[Issue]:
    """Check for passlib + bcrypt version conflicts in requirements files."""
    issues: list[Issue] = []
    for req_file in root.rglob("requirements*.txt"):
        content = req_file.read_text(encoding="utf-8").lower()
        if "passlib" not in content or "bcrypt" not in content:
            continue
        match = re.search(r"bcrypt\s*([><=!~]+)\s*([\d.]+)", content)
        if match:
            op, version = match.groups()
            try:
                parts = version.split(".")
                if int(parts[0]) > 4 or (int(parts[0]) == 4 and len(parts) > 1 and int(parts[1]) >= 1):
                    if op in (">=", ">", "=="):
                        issues.append(Issue("error", str(req_file.relative_to(root)), 0, "passlib incompatible with bcrypt>=4.1.0 — pin bcrypt==4.0.1"))
            except ValueError:
                pass
        elif "bcrypt" in content:
            issues.append(Issue("warning", str(req_file.relative_to(root)), 0, "bcrypt version not pinned — passlib requires bcrypt==4.0.1"))
    return issues


def _check_datetime_usage(root: Path) -> list[Issue]:
    issues: list[Issue] = []
    for py_file in root.rglob("*.py"):
        try:
            text = py_file.read_text(encoding="utf-8")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"""') or stripped.startswith("'''"):
                continue
            if "datetime.now()" in line and "timezone" not in line:
                issues.append(Issue("warning", str(py_file.relative_to(root)), i, "Use datetime.now(timezone.utc) for timezone-aware datetimes"))
    return issues


def _check_pydantic_models(root: Path) -> list[Issue]:
    issues: list[Issue] = []
    for py_file in root.rglob("*.py"):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            is_pydantic = any(
                base.attr == "BaseModel" if isinstance(base, ast.Attribute)
                else base.id == "BaseModel" if isinstance(base, ast.Name)
                else False
                for base in node.bases
            )
            if not is_pydantic:
                continue
            for item in node.body:
                if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name) and item.target.id == "id":
                    if isinstance(item.annotation, ast.Name) and item.annotation.id == "str":
                        issues.append(Issue("warning", str(py_file.relative_to(root)), item.lineno or 0, "Model has `id: str` — if using UUID primary keys, use `id: UUID` instead"))
    return issues


# ═══════════════════════════════════════════════════════════════════
# PHP checks
# ═══════════════════════════════════════════════════════════════════


def _check_php_namespace_paths(root: Path) -> list[Issue]:
    """Verify that PHP namespaces match directory structure (PSR-4)."""
    issues: list[Issue] = []
    composer_json = root / "composer.json"
    if not composer_json.exists():
        return issues
    try:
        composer = _json.loads(composer_json.read_text(encoding="utf-8"))
        psr4 = composer.get("autoload", {}).get("psr-4", {})
    except (_json.JSONDecodeError, OSError):
        return issues

    for namespace_prefix, dirs in psr4.items():
        if isinstance(dirs, str):
            dirs = [dirs]
        for dir_rel in dirs:
            base_dir = (root / dir_rel).resolve()
            if not base_dir.exists():
                continue
            for php_file in base_dir.rglob("*.php"):
                try:
                    text = php_file.read_text(encoding="utf-8")
                except OSError:
                    continue
                m = re.search(r"namespace\s+([^;]+)", text)
                if not m:
                    continue
                declared_ns = m.group(1).strip()
                rel_path = php_file.relative_to(base_dir)
                expected_ns = namespace_prefix.rstrip("\\") + "\\" + str(rel_path.with_suffix("")).replace("/", "\\").replace("\\\\", "\\")
                expected_ns = expected_ns.strip("\\")
                if declared_ns != expected_ns:
                    issues.append(Issue("error", str(php_file.relative_to(root)), 1, f"Namespace mismatch: declared '{declared_ns}', expected '{expected_ns}'"))
    return issues


# ═══════════════════════════════════════════════════════════════════
# JS/TS checks
# ═══════════════════════════════════════════════════════════════════


def _check_package_json(root: Path) -> list[Issue]:
    """Verify package.json has expected fields."""
    issues: list[Issue] = []
    pkg = root / "package.json"
    if not pkg.exists():
        return issues
    try:
        data = _json.loads(pkg.read_text(encoding="utf-8"))
    except (_json.JSONDecodeError, OSError):
        issues.append(Issue("error", "package.json", 0, "Invalid JSON in package.json"))
        return issues
    if not data.get("name"):
        issues.append(Issue("warning", "package.json", 0, "package.json is missing the 'name' field"))
    if not data.get("version"):
        issues.append(Issue("warning", "package.json", 0, "package.json is missing the 'version' field"))
    if not data.get("scripts", {}).get("test"):
        issues.append(Issue("warning", "package.json", 0, "package.json is missing a 'test' script"))
    return issues
