"""Pre-flight health checks and scaffolding — tool detection, install, project setup."""
from __future__ import annotations

import logging
import shlex
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def _run_preflight(self, command: str) -> bool:
    """Run a pre-flight health check \u2014 only checks tools relevant to the task.
    Detects what language/framework is needed from the task description,
    then only checks those specific tools.  If tools are missing, offers
    to auto-install them before proceeding.
    """
    from widdx import ui
    from widdx.preflight import check_requirements, print_report

    lowered = command.lower()
    if not any(kw in lowered for kw in ["build", "create", "install", "generate", "new project"]):
        return True

    lang_keywords = {
        "python":   ["python", "pygame", "django", "flask", "fastapi"],
        "php":      ["php", "laravel", "wordpress", "symfony"],
        "node":     ["node", "javascript", "typescript", "react", "vue", "nextjs", "npm"],
        "go":       ["golang", "go lang"],
        "rust":     ["rust", "cargo"],
        "ruby":     ["ruby", "rails"],
    }

    required = ["git"]
    for lang, keywords in lang_keywords.items():
        if any(kw in lowered for kw in keywords):
            required.append(lang)

    if len(required) <= 1:
        required.append("python")

    result = check_requirements(required)
    if not result.passed:
        c = ui.get_console()
        c.print(f"  [warning]\u26a0 Missing tools needed for this project[/]")
        print_report(result)

        if result.missing:
            return self._handle_missing_tools(result.missing)

        from widdx.ui import confirm
        return confirm("Continue anyway?", default=False)

    return True


def _handle_missing_tools(self, missing: list[str]) -> bool:
    """Offer to auto-install missing development tools."""
    from widdx import ui
    from widdx.preflight import check_requirements
    from widdx.ui.professional import confirm_with_options
    c = ui.get_console()

    c.print()
    install_cmds = self._get_install_commands(missing)
    if not install_cmds:
        c.print(f"  [warning]\u26a0 No auto-install available for: {', '.join(missing)}[/]")
        c.print(f"  [dim]Install them manually, then restart WIDDX.[/]")
        return ui.confirm("Continue anyway?", default=False)

    c.print(f"  [brand]\u25c6[/] [text]Auto-install missing tools?[/]")
    for tool, cmd_list in install_cmds:
        primary = cmd_list[0] if cmd_list else "manual install required"
        methods = " \u2192 ".join(c[:50] for c in cmd_list[:2]) if len(cmd_list) > 1 else primary
        c.print(f"     [cyan]{tool}[/]: [dim]{methods}[/]")

    choice = confirm_with_options(
        "What would you like to do?",
        ["Install all missing tools", "Continue without installing", "Abort"],
        default="Install all missing tools",
    )

    if choice == "Abort":
        return False
    if choice == "Continue without installing":
        return True

    installed: list[str] = []
    failed: list[tuple[str, list[str]]] = []
    for tool, cmd_list in install_cmds:
        tool_ok = False
        for method_idx, cmd in enumerate(cmd_list):
            label = "winget" if "winget" in cmd else "choco" if "choco" in cmd else "brew" if "brew" in cmd else "apt" if "apt" in cmd else "manual"
            c.print(f"  [dim]\u23bf Installing {tool} via {label}...[/]")
            try:
                try:
                    cmd_list = shlex.split(cmd)
                except ValueError:
                    cmd_list = [cmd]
                proc = subprocess.run(
                    cmd_list, capture_output=True, text=True, timeout=300
                )
                if proc.returncode == 0:
                    c.print(f"  [success]\u2713 {tool} installed via {label}[/]")
                    installed.append(tool)
                    tool_ok = True
                    break
                c.print(f"  [dim]   {label} failed (exit {proc.returncode})[/]")
                if proc.stderr:
                    err = proc.stderr.strip()[:120]
                    if err:
                        c.print(f"  [dim]   {err}[/]")
            except Exception:
                logger.debug("Install attempt via %s failed", label, exc_info=True)
                c.print(f"  [dim]   {label} unavailable[/]")
        if not tool_ok:
            failed.append((tool, [c[:60] for c in cmd_list]))

    if failed:
        c.print()
        for tool, cmds in failed:
            c.print(f"  [error]\u2717 {tool} could not be auto-installed[/]")
            c.print(f"  [dim]  Install manually then restart WIDDX: {cmds[0] if cmds else 'N/A'}[/]")
        return ui.confirm("Some tools could not be installed. Continue anyway?", default=False)

    c.print(f"  [dim]\u23bf Verifying...[/]")
    result = check_requirements(installed)
    still_missing = [t for t in installed if t in result.missing]

    if still_missing:
        c.print(f"  [warning]\u26a0 Installation reported success but tools still not found[/]")
        c.print(f"  [dim]Missing after install: {', '.join(still_missing)}[/]")
        c.print(f"  [dim]You may need to restart your terminal and run WIDDX again.[/]")
        return ui.confirm("Continue anyway?", default=False)

    c.print(f"  [success]\u2713 All tools installed and verified[/]")
    return True


def _get_install_commands(missing: list[str]) -> list[tuple[str, list[str]]]:
    """Get OS-appropriate install commands for missing tools.
    Returns a list of (tool_name, [commands_to_try]) where commands are
    tried in order until one succeeds.
    """
    commands: list[tuple[str, list[str]]] = []

    tool_map: dict[str, list[str]] = {
        "python": [
            "winget install Python.Python.3.12 --accept-package-agreements",
            "choco install python -y",
            "brew install python",
            "apt-get install -y python3",
        ],
        "php": [
            "winget install PHP.PHP.8.3 --accept-package-agreements",
            "choco install php -y",
            "brew install php",
            "apt-get install -y php-cli",
        ],
        "composer": [
            "winget install Composer.Composer --accept-package-agreements",
            "choco install composer -y",
            "brew install composer",
            "apt-get install -y composer",
        ],
        "node": [
            "winget install OpenJS.NodeJS.LTS --accept-package-agreements",
            "choco install nodejs -y",
            "brew install node",
            "apt-get install -y nodejs npm",
        ],
        "git": [
            "winget install Git.Git --accept-package-agreements",
            "choco install git -y",
            "brew install git",
            "apt-get install -y git",
        ],
        "go": [
            "winget install GoLang.Go --accept-package-agreements",
            "choco install golang -y",
            "brew install go",
            "apt-get install -y golang-go",
        ],
        "rust": [
            "winget install Rustlang.Rustup --accept-package-agreements",
            "choco install rust -y",
            "brew install rustup-init",
            "apt-get install -y rustc cargo",
        ],
        "ruby": [
            "winget install RubyInstallerTeam.Ruby.3.3 --accept-package-agreements",
            "choco install ruby -y",
            "brew install ruby",
            "apt-get install -y ruby",
        ],
    }

    for tool in missing:
        cmds = tool_map.get(tool, [])
        if cmds:
            commands.append((tool, cmds))
        else:
            commands.append((tool, [f"echo 'No auto-install available for {tool}. Please install manually.'"]))

    return commands


def _run_scaffolding(self, command: str) -> None:
    """Detect framework in the task and scaffold the project if needed.
    Skips scaffolding if the project is not empty or already has a
    recognised framework structure.
    """
    from widdx import ui
    from widdx.scaffolder import scaffold

    project_files = list(Path.cwd().iterdir())
    non_hidden = [f for f in project_files if not f.name.startswith(".")]
    if non_hidden:
        return
    non_hidden = [f for f in project_files if not f.name.startswith(".")]
    if non_hidden:
        return

    result = scaffold(command, router=self._router)
    if result.error:
        c = ui.get_console()
        c.print(f"  [warning]\u26a0 Scaffolding issue: {result.error}[/]")
