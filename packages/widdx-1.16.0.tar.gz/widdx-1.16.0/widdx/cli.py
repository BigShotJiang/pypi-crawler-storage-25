#!/usr/bin/env python3
"""WIDDX CLI — Autonomous AI Orchestration System. Powered by DeepSeek.

    pip install widdx
    python -m widdx                # Always works
    widdx                          # Works if Python Scripts is in PATH
    widdx "task"                   # Run task in REPL mode
    widdx schedule add "0 9 * * 1" "task"  # Schedule a task
    widdx schedule list            # List scheduled tasks
    widdx schedule remove <id>     # Remove a scheduled task
    widdx schedule run             # Start the scheduler daemon
    widdx --help                   # Show help

All interactive commands are handled inside the interactive REPL.
"""

from __future__ import annotations

import logging
import shutil
import subprocess as _sp
import sys
from pathlib import Path

import click

from . import ui
from .config import DEFAULT_MEMORY_DB_PATH, load_config
from .memory import MemoryStore
from .repl import WIDDXRepl
from .router import AIRouter

logger = logging.getLogger("widdx.cli")

if sys.platform == "win32":
    _sp.run(["cmd", "/c", "chcp 65001"], check=False,
            stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]


class WIDDXGroup(click.Group):
    """Treat unknown subcommands as direct natural-language tasks."""

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        option_args: list[str] = []
        idx = 0
        while idx < len(args):
            arg = args[idx]
            if arg in ("-m", "--model"):
                option_args.append(arg)
                if idx + 1 < len(args):
                    option_args.append(args[idx + 1])
                    idx += 2
                    continue
            if arg == "--no-color":
                option_args.append(arg)
                idx += 1
                continue
            if arg.startswith("-"):
                return super().parse_args(ctx, args)
            break

        if idx < len(args) and args[idx] not in self.commands:
            ctx.meta["direct_task_args"] = list(args[idx:])
            return super().parse_args(ctx, option_args)
        return super().parse_args(ctx, args)


def _ensure_widdx_in_path() -> None:
    """Offer to add Python Scripts to PATH so `widdx` command works directly.

    On Windows, pip installs widdx.exe to PythonXX\\Scripts\\ which may not
    be in PATH. This detects the issue and offers a one-click fix.
    """
    if sys.platform != "win32":
        return
    try:
        widdx_path = shutil.which("widdx")
        if widdx_path:
            return  # Already in PATH — nothing to do
    except Exception:
        logger.debug("Could not check if widdx is in PATH")
        return

    # Find where pip installed widdx.exe
    scripts_dir = None
    for p in sys.path:
        scripts = Path(p) / "Scripts"
        if scripts.exists() and (scripts / "widdx.exe").exists():
            scripts_dir = scripts
            break

    if not scripts_dir:
        return  # Can't find widdx.exe

    ui.get_console().print()
    ui.get_console().print("  [warning]⚠ 'widdx' command not in PATH[/]")
    ui.get_console().print("  [dim]Add Python Scripts to PATH so you can just type 'widdx'?[/]")
    ui.get_console().print(f"  [dim]Directory: {scripts_dir}[/]")

    try:
        answer = input("  [dim]Add to PATH? [Y/n]:[/] ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        return

    if answer and not answer.startswith("y"):
        ui.get_console().print("  [dim]Use 'python -m widdx' to launch.[/]")
        return

    try:
        import subprocess
        result = subprocess.run(
            ["setx", "PATH", f"{scripts_dir};%PATH%"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            ui.get_console().print("  [success]✓ Added to user PATH. Restart terminal and type 'widdx'.[/]")
        else:
            ui.get_console().print("  [dim]Could not update PATH automatically.[/]")
            ui.get_console().print(f"  [dim]Run: setx PATH \"{scripts_dir};%PATH%\"[/]")
    except Exception:
        ui.get_console().print("  [dim]Could not update PATH. Use 'python -m widdx'.[/]")


@click.group(
    cls=WIDDXGroup,
    invoke_without_command=True,
    context_settings=dict(allow_extra_args=True, ignore_unknown_options=True),
)
@click.version_option(version=__import__("widdx").__version__, prog_name="widdx")
@click.option("--model", "-m", default=None, help="Model to use (architect/executor)")
@click.option("--no-color", is_flag=True, help="Disable colors")
@click.option("--fast", is_flag=True, help="Fast mode: skip interactive prompts, depth 1")
@click.option("--pipeline-depth", type=int, default=0,
              help="Pipeline depth: 1=simple, 2=plan+exec, 3=+verify, 4=full (0=auto)")
@click.pass_context
def main(ctx: click.Context, model: str | None, no_color: bool, fast: bool,
         pipeline_depth: int) -> None:
    """WIDDX CLI — Autonomous AI Software Engineering Operating System.

    A world-class AI coding agent in your terminal. Powered by DeepSeek v4.

    Usage:
      widdx                    Start interactive REPL
      widdx "fix auth bug"     Run task in REPL
      widdx schedule --help    Manage scheduled tasks
      widdx --help             Show all options
    """
    # ── Configure logging ────────────────────────────────────────
    import logging as _logging
    _logging.basicConfig(
        level=_logging.WARNING,
        format="[widdx] %(levelname)s %(name)s: %(message)s",
        stream=__import__("sys").stderr,
    )
    if no_color:
        ui.configure_console(no_color=True)

    # If a subcommand was invoked (e.g. `widdx schedule ...`), let it handle execution.
    if ctx.invoked_subcommand is not None:
        return

    # ── Elite boot screen ────────────────────────────────────────
    try:
        from .indexer import ProjectIndexer
        idx = ProjectIndexer()
        idx.scan()
        fw = "python"
        try:
            fw = idx.detect_framework() or "python"
        except Exception:
            pass
        total = idx.total_files or 0
    except Exception:
        fw = "python"; total = 0
    from .ui.elite import elite_boot
    elite_boot(framework=fw, files=total,
               version=__import__("widdx").__version__)

    # ── Check for updates (non-blocking) ────────────────────────
    _check_for_updates()

    # ── First-run PATH fix for Windows ─────────────────────────
    _ensure_widdx_in_path()

    # ctx.args holds direct natural-language input, e.g. ``widdx "fix auth"``.
    task_args: tuple[str, ...] = tuple(ctx.meta.get("direct_task_args", ctx.args))
    if not task_args:
        _start_repl(initial_task=None, model=model, fast=fast, pipeline_depth=pipeline_depth)
    else:
        task_text = " ".join(task_args)
        if task_text.startswith("/"):
            ui.get_console().print("  [dim]Starting REPL...[/]")
        _start_repl(initial_task=task_text, model=model, fast=fast, pipeline_depth=pipeline_depth)


def _first_run_setup(config: dict) -> None:
    """Elegant interactive first-run setup with Rich panels and progress."""
    c = ui.get_console()
    env = config.get("__env__", {})
    ds_key = env.get("deepseek_key") or config.get("deepseek_api_key")
    g_key = env.get("google_key") or config.get("google_api_key")

    if ds_key or g_key:
        return
    if Path.home().joinpath(".widdx", ".setup_skipped").exists():
        return

    from rich.panel import Panel
    from rich.table import Table
    from rich.align import Align
    from rich.box import HEAVY, ROUNDED

    # ═══════════════════════════════════════════════════════════════
    # HEADER PANEL
    # ═══════════════════════════════════════════════════════════════
    c.print()
    header = Panel(
        Align.center(
            "\n"
            "[bold brand]◆  W I D D X   S E T U P  ◆[/]\n\n"
            "[dim]Autonomous AI Software Engineering OS\n"
            f"v{__import__('widdx').__version__}  ·  Muhammad Muslih  ·  widdx.com[/]\n",
            vertical="middle",
        ),
        box=HEAVY,
        border_style="brand",
        padding=(1, 4),
    )
    c.print(header)

    # ═══════════════════════════════════════════════════════════════
    # PROVIDER COMPARISON TABLE
    # ═══════════════════════════════════════════════════════════════
    table = Table(
        box=ROUNDED,
        border_style="dim",
        show_header=True,
        header_style="bold white",
        title="\n[bold]Available AI Providers[/]\n",
        title_style="bold white",
    )
    table.add_column("Provider", style="bold cyan", width=16, no_wrap=True)
    table.add_column("Models", style="white", width=30)
    table.add_column("Cost", style="green", width=14, justify="center")
    table.add_column("Quality", style="yellow", width=10, justify="center")

    table.add_row(
        "DeepSeek",
        "deepseek-v4-pro\n[dim]deepseek-v4-flash[/]",
        "[yellow]$0.27/M[/]",
        "[yellow]\u2605\u2605\u2605\u2605\u2605[/]",
    )
    table.add_row(
        "Google Gemini",
        "gemini-2.5-pro\n[dim]gemini-2.0-flash[/]",
        "[green]Free tier[/]",
        "[yellow]\u2605\u2605\u2605\u2605[/]",
    )
    table.add_row(
        "OpenCode",
        "5 free models\n[dim]big-pickle + flash-free + ...[/]",
        "[green]FREE[/]",
        "[yellow]\u2605\u2605\u2605[/]",
    )
    c.print(table)

    c.print()
    c.print(
        Panel(
            "[white]OpenCode is [bold]always active[/] with 5 free models.\n"
            "Adding your own keys unlocks [bold cyan]DeepSeek[/] and "
            "[bold cyan]Google Gemini[/] for higher quality.[/]\n\n"
            "[dim]Keys are encrypted and stored locally in ~/.widdx/config.yaml\n"
            "You can skip and add keys later via [bold]/key[/] command.[/]",
            box=ROUNDED,
            border_style="grey50",
            padding=(1, 2),
        )
    )
    c.print()

    # ═══════════════════════════════════════════════════════════════
    # STEP 1: DEEPSEEK
    # ═══════════════════════════════════════════════════════════════
    c.print(Align.center("[bold]Step 1/2[/]  [bold cyan]DeepSeek[/] [dim]— Highest quality, paid[/]", width=80))
    c.print()
    ds_panel = Panel(
        "[cyan]\U0001f50d DeepSeek V4[/]\n\n"
        "[white]Best model for complex reasoning and code generation.\n"
        "[dim]Pricing: ~$0.27/M input tokens, ~$1.10/M output tokens.[/]\n\n"
        "[dim]Get a key:[/] [underline]https://platform.deepseek.com/api_keys[/]",
        box=ROUNDED,
        border_style="cyan",
        padding=(1, 2),
    )
    c.print(ds_panel)
    c.print()

    _prompt_key(c, provider="DeepSeek", config_key="deepseek_api_key", config=config)
    c.print()

    # ═══════════════════════════════════════════════════════════════
    # STEP 2: GOOGLE GEMINI
    # ═══════════════════════════════════════════════════════════════
    c.print(Align.center("[bold]Step 2/2[/]  [bold #4285f4]Google Gemini[/] [dim]— Free tier, fast setup[/]", width=80))
    c.print()
    gc_panel = Panel(
        "[#4285f4]\U0001f310 Google Gemini[/]\n\n"
        "[white]Fast, capable models with a generous free tier.\n"
        "[dim]Get a free key in 30 seconds — no credit card required.[/]\n\n"
        "[dim]Get a key:[/] [underline]https://aistudio.google.com/apikey[/]",
        box=ROUNDED,
        border_style="#4285f4",
        padding=(1, 2),
    )
    c.print(gc_panel)
    c.print()

    _prompt_key(c, provider="Google Gemini", config_key="google_api_key", config=config)
    c.print()

    # ═══════════════════════════════════════════════════════════════
    # SUMMARY DASHBOARD
    # ═══════════════════════════════════════════════════════════════
    c.print()
    summary = Table(
        box=ROUNDED,
        border_style="brand",
        show_header=True,
        header_style="bold white",
        title="\n[bold brand]\u25c6  SETUP COMPLETE  \u25c6[/]\n",
        title_style="bold brand",
    )
    summary.add_column("Provider", style="bold", width=16)
    summary.add_column("Status", style="bold", width=14, justify="center")
    summary.add_column("Models", style="dim", width=30)

    # Reload config to get saved keys
    from .config import load_config as _reload
    updated = _reload()
    env_u = updated.get("__env__", {})

    ds = env_u.get("deepseek_key") or updated.get("deepseek_api_key")
    gk = env_u.get("google_key") or updated.get("google_api_key")

    summary.add_row(
        "DeepSeek",
        "[success]\u2713 Active[/]" if ds else "[dim]\u25cb Skipped[/]",
        "deepseek-v4-pro + flash" if ds else "—",
    )
    summary.add_row(
        "Google Gemini",
        "[success]\u2713 Active[/]" if gk else "[dim]\u25cb Skipped[/]",
        "gemini-2.5-pro + flash" if gk else "—",
    )
    summary.add_row(
        "OpenCode",
        "[success]\u2713 Active[/]",
        "5 free models — always on",
    )
    c.print(summary)
    c.print()

    tip = Panel(
        "[dim]\U0001f4a1 [bold]/key[/] to change keys  ·  [bold]/providers[/] to manage  ·  "
        "[bold]/model[/] to see costs[/]",
        box=ROUNDED,
        border_style="grey50",
        padding=(0, 2),
    )
    c.print(tip)
    c.print()
    c.print(Align.center("[bold brand]Starting WIDDX...[/]", width=80))
    c.print()


def _prompt_key(c, provider: str, config_key: str, config: dict) -> bool:
    """Rich interactive key prompt. Returns True if key was saved."""
    from rich.prompt import Prompt

    try:
        c.print("  [dim]Enter to paste key, 'n' to skip, 'quit' to exit setup[/]")
        c.print()
        want = Prompt.ask(
            f"  [{_provider_color(provider)}]Add {provider} API key?[/]",
            choices=["y", "n", "quit"],
            default="y",
            show_choices=False,
            show_default=False,
        )
    except (KeyboardInterrupt, EOFError):
        return False

    if want == "quit":
        _mark_setup_skipped()
        c.print("  [dim]Setup exited. Use /key to add keys later.[/]")
        raise SystemExit(0)

    if want == "n":
        c.print(f"  [dim]\u25cb {provider} skipped.[/]")
        return False

    c.print(f"  [dim]Paste your {provider} API key (input hidden):[/]")
    try:
        from prompt_toolkit import prompt as pt_prompt
        from prompt_toolkit.formatted_text import HTML
        color = _provider_color(provider)
        key = pt_prompt(HTML(f"  <{color}>{provider} key: </{color}>"), is_password=True)
    except ImportError:
        try:
            key = input(f"  {provider} key: ").strip()
        except (KeyboardInterrupt, EOFError):
            return False

    if not key or not key.strip():
        c.print(f"  [dim]\u25cb {provider} skipped (empty).[/]")
        return False

    key = key.strip().strip("'\"")
    from .config import save_config_key
    save_config_key(config_key, key)
    config[config_key] = key
    env_key = "google_key" if config_key == "google_api_key" else "deepseek_key"
    if "__env__" not in config:
        config["__env__"] = {}
    config["__env__"][env_key] = key

    masked = key[:6] + "..." + key[-4:] if len(key) > 10 else "***"
    c.print(f"  [success]\u2713 {provider} key saved ([dim]{masked}[/])[/]")
    return True


def _provider_color(provider: str) -> str:
    return "cyan" if "DeepSeek" in provider else "#4285f4"


def _check_for_updates() -> None:
    """Check PyPI for newer versions — non-blocking, one line."""
    cache_file = Path.home() / ".widdx" / ".update_checked"
    try:
        if cache_file.exists():
            age = __import__("time").time() - cache_file.stat().st_mtime
            if age < 86400:  # checked in last 24h
                return
    except Exception:
        logger.debug("Update cache check failed, proceeding")
        return

    try:
        import json as _json
        import urllib.request as _ur
        req = _ur.Request(
            "https://pypi.org/pypi/widdx/json",
            headers={"User-Agent": "widdx-cli"},
        )
        with _ur.urlopen(req, timeout=3) as resp:
            data = _json.loads(resp.read().decode())
        latest = data.get("info", {}).get("version", "")
        current = __import__("widdx").__version__
        if latest and latest != current:
            c = ui.get_console()
            c.print(f"\n  [warning]\u26a0 Update available: widdx [bold]{latest}[/] (you have {current})[/]")
            c.print("  [dim]   pip install --upgrade widdx[/]")
            c.print()
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cache_file.touch()
    except Exception:
        logger.debug("Update check failed (possibly offline)")


def _check_crash_recovery() -> str | None:
    """Check if previous session crashed and offer recovery.
    Returns session filename if user wants to resume, or None."""
    crash_file = Path.home() / ".widdx" / ".crash_session"
    if not crash_file.exists():
        return None

    c = ui.get_console()
    c.print()
    c.print("  [warning]\u26a0 Previous session may have crashed.[/]")
    c.print(f"  [dim]Last session: {crash_file.read_text().strip()}[/]")

    try:
        answer = input("  Resume last session? [Y/n]: ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        answer = "n"

    crash_file.unlink(missing_ok=True)

    if not answer or answer.startswith("y"):
        return "crash_recovery"
    return None


def _self_check() -> None:
    """Run a comprehensive self-check of all WIDDX components."""
    c = ui.get_console()
    from rich.panel import Panel
    from rich.table import Table
    from rich.box import ROUNDED

    c.print()
    c.rule("[brand]\u25c6  SELF-CHECK  \u25c6[/]")
    c.print()

    checks: list[tuple[str, bool, str]] = []

    # Python version
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    checks.append(("Python", sys.version_info >= (3, 10), f"v{py_ver}"))

    # Core imports
    for mod_name, label in [
        ("widdx.router", "AI Router"),
        ("widdx.memory", "Memory Store"),
        ("widdx.tool_loop", "Tool Loop"),
        ("widdx.verifier", "Verifier"),
        ("widdx.scaffolder", "Scaffolder"),
        ("widdx.ui", "Terminal UI"),
        ("widdx.mcp", "MCP Protocol"),
        ("widdx.hooks", "Hooks System"),
        ("widdx.skills", "Skills System"),
    ]:
        try:
            __import__(mod_name)
            checks.append((label, True, "loaded"))
        except Exception as e:
            checks.append((label, False, str(e)[:50]))

    # Config
    config_path = Path.home() / ".widdx" / "config.yaml"
    checks.append(("Config", config_path.exists(), str(config_path)))

    # Memory DB
    db_path = Path.home() / ".widdx" / "memory.db"
    db_exists = db_path.exists()
    db_size = f"{db_path.stat().st_size / 1024:.1f}KB" if db_exists else "not created"
    checks.append(("Memory DB", db_exists, db_size))

    # Git
    git = shutil.which("git")
    checks.append(("Git", git is not None, git or "not found"))

    # CLI entry
    widdx_exe = shutil.which("widdx")
    checks.append(("widdx CLI", widdx_exe is not None, widdx_exe or "use python -m widdx"))

    table = Table(box=ROUNDED, border_style="dim", show_header=True, header_style="bold white")
    table.add_column("Component", style="bold", width=16)
    table.add_column("Status", justify="center", width=8)
    table.add_column("Info", style="dim")

    for name, ok, info in checks:
        status = "[success]\u2713[/]" if ok else "[error]\u2717[/]"
        table.add_row(name, status, info)

    c.print(table)

    passed = sum(1 for _, ok, _ in checks if ok)
    total = len(checks)
    c.print()
    if passed == total:
        c.print(Panel(
            f"[success]\u2713 All {total} checks passed — WIDDX is healthy[/]",
            border_style="green", box=ROUNDED,
        ))
    else:
        c.print(Panel(
            f"[warning]{passed}/{total} checks passed[/]",
            border_style="yellow", box=ROUNDED,
        ))
    c.print()


def _mark_setup_skipped() -> None:
    try:
        d = Path.home() / ".widdx"
        d.mkdir(parents=True, exist_ok=True)
        (d / ".setup_skipped").touch()
    except OSError:
        pass


def _start_repl(initial_task: str | None, model: str | None,
                fast: bool = False, pipeline_depth: int = 0) -> None:
    config = load_config()
    if model:
        config.setdefault("models", {})
        config["models"].setdefault("architect", {})
        config["models"].setdefault("executor", {})
        config["models"]["architect"]["model"] = model
        config["models"]["executor"]["model"] = model
        config["force_model"] = model
    memory = MemoryStore(config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))

    # ── Crash recovery check ────────────────────────────────────
    _check_crash_recovery()

    # ── First-run API key setup wizard ──────────────────────────
    _first_run_setup(config)

    # Reload config after setup (keys may have been saved)
    config = load_config()
    if model:
        config.setdefault("models", {})
        config["models"].setdefault("architect", {})
        config["models"].setdefault("executor", {})
        config["models"]["architect"]["model"] = model
        config["models"]["executor"]["model"] = model
        config["force_model"] = model
    router = AIRouter(config, memory)

    if not router.is_ready:
        ui.fail("No AI provider available.")
        return

    repl = WIDDXRepl(router, config, memory=memory, initial_task=initial_task,
                     fast_mode=fast, pipeline_depth=pipeline_depth)
    repl.run()


# ---------------------------------------------------------------------------
# schedule subcommand group
# ---------------------------------------------------------------------------

@click.group()
def schedule() -> None:
    """Manage scheduled tasks (cron-based)."""


@schedule.command("add")
@click.argument("cron")
@click.argument("task")
def schedule_add(cron: str, task: str) -> None:
    """Add a scheduled task.

    CRON is a standard 5-field cron expression (e.g. "0 9 * * 1").
    TASK is the task description or command to run when due.

    Example:
      widdx schedule add "0 9 * * 1" "weekly code review"
    """
    from .scheduler import TaskScheduler

    scheduler = TaskScheduler()
    task_id = scheduler.add(cron, task)
    click.echo(f"Schedule added — id: {task_id}")


@schedule.command("list")
def schedule_list() -> None:
    """List all saved scheduled tasks."""
    from .scheduler import TaskScheduler

    scheduler = TaskScheduler()
    schedules = scheduler.list_schedules()

    if not schedules:
        click.echo("No scheduled tasks found.")
        return

    # Header
    click.echo(f"{'ID':<10} {'CRON':<20} {'LAST RUN':<26} TASK")
    click.echo("-" * 80)
    for s in schedules:
        task_id = s.get("id", "")
        cron = s.get("cron", "")
        last_run = s.get("last_run") or "never"
        task_desc = s.get("task", "")
        click.echo(f"{task_id:<10} {cron:<20} {last_run:<26} {task_desc}")


@schedule.command("remove")
@click.argument("id")
def schedule_remove(id: str) -> None:
    """Remove a scheduled task by ID.

    ID is the 8-character hex task ID shown by `widdx schedule list`.
    """
    from .scheduler import TaskScheduler

    scheduler = TaskScheduler()
    removed = scheduler.remove(id)
    if removed:
        click.echo(f"Schedule {id} removed.")
    else:
        click.echo(f"No schedule found with id: {id}", err=True)
        sys.exit(1)


@schedule.command("run")
def schedule_run() -> None:
    """Start the scheduler daemon (blocking).

    Polls every 60 seconds and runs any task whose cron expression matches
    the current minute. Press Ctrl+C to stop.
    """
    from .scheduler import TaskScheduler

    config = load_config()
    memory = MemoryStore(config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))
    scheduler = TaskScheduler(memory=memory)
    scheduler.run_daemon()


# Register the schedule group on the main group.
main.add_command(schedule)


# ---------------------------------------------------------------------------
# bot subcommand
# ---------------------------------------------------------------------------

@click.group()
def bot() -> None:
    """Telegram Bot integration."""


@bot.command("start")
@click.option("--project-dir", "-d", default=None, help="Working directory for the bot")
def bot_start(project_dir: str | None) -> None:
    """Start the WIDDX Telegram bot daemon.

    Requires TELEGRAM_BOT_TOKEN environment variable or config.

    pip install widdx[telegram]
    $env:TELEGRAM_BOT_TOKEN = "123456:ABC-DEF..."
    widdx bot start --project-dir /path/to/project
    """
    from .telegram_bot import run_bot
    run_bot(project_dir=project_dir)


main.add_command(bot)


# ---------------------------------------------------------------------------
# web subcommand
# ---------------------------------------------------------------------------

@click.command("web")
@click.option("--port", "-p", default=8520, help="Port to listen on (default: 8520)")
@click.option("--no-open", is_flag=True, help="Don't open browser automatically")
def web_cmd(port: int, no_open: bool) -> None:
    """Start the WIDDX Web UI — professional browser-based interface.

    Opens http://localhost:8520 with a full dashboard:
      - Chat interface with streaming responses
      - File browser and preview
      - Tool execution display with diffs
      - Session stats and cost tracking

    Requires: pip install fastapi uvicorn
    """
    from widdx.web import start_web_server
    start_web_server(port=port, open_browser=not no_open)


main.add_command(web_cmd)


# ---------------------------------------------------------------------------
# self-upgrade subcommand
# ---------------------------------------------------------------------------

@click.command("self-upgrade")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def self_upgrade_cmd(yes: bool) -> None:
    """Cleanly upgrade widdx to the latest version.

    Removes the old package completely before installing the new one,
    preventing stale files. Your config, custom skills, and agents in
    ~/.widdx/ are preserved automatically.
    """
    import subprocess
    import sys

    from widdx import __version__

    click.echo(f"  Current version:  {__version__}")
    click.echo("  Latest on PyPI:   (checking...)")

    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", "widdx"],
            capture_output=True, text=True, timeout=15,
        )
        if r.returncode == 0:
            for line in r.stdout.splitlines():
                if "Available versions:" in line:
                    versions = line.split(":", 1)[1].strip()
                    latest = versions.split(",")[0].strip()
                    click.echo(f"  Latest on PyPI:   {latest}")
                    if latest == __version__:
                        click.echo(f"\n  ✔ Already up to date ({__version__})")
                        return
                    break
    except Exception:
        click.echo("  Latest on PyPI:   (could not check)")

    if not yes:
        click.confirm("\n  Upgrade widdx? This will uninstall then reinstall.", abort=True)

    click.echo("\n  Uninstalling old version...")
    subprocess.run(
        [sys.executable, "-m", "pip", "uninstall", "-y", "widdx"],
        capture_output=True,
    )

    click.echo("  Installing latest version...")
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "widdx"],
    )

    if r.returncode == 0:
        # Re-import to get new version
        import importlib
        import widdx as _
        importlib.reload(_)
        click.echo(f"\n  ✔ Upgraded to {_.__version__}")
    else:
        click.echo("\n  ✗ Upgrade failed. Check your internet connection.", err=True)
        raise SystemExit(1)


main.add_command(self_upgrade_cmd)


if __name__ == "__main__":
    main()
