"""WIDDX Telegram Bot — Control your AI agent from Telegram.

Start:
    widdx bot start --project-dir /path/to/project

Or set project dir in config:
    telegram:
      bot_token: "123456:ABC-DEF..."
      project_dir: "/home/user/my-project"
      allowed_users: []  # empty = anyone

Setup:
    1. Create a bot via @BotFather on Telegram
    2. Get your bot token
    3. Set TELEGRAM_BOT_TOKEN env var or ~/.widdx/config.yaml
"""
from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from telegram import Update
    from telegram.ext import ContextTypes

logger = logging.getLogger("widdx.telegram")

_MAX_FILE_SIZE = 50 * 1024 * 1024  # Telegram limit: 50MB
_MAX_TEXT_LEN = 4000  # Telegram message limit


class WiddxTelegramBot:
    """Telegram bot that forwards messages to WIDDX and returns results."""

    def __init__(self, token: str, router, config: dict[str, Any],
                 memory=None, allowed_users: list[int] | None = None,
                 project_dir: str | None = None) -> None:
        self._token = token
        self._router = router
        self._config = config
        self._memory = memory
        self._allowed_users = set(allowed_users) if allowed_users else None
        self._project_dir = Path(project_dir).resolve() if project_dir else Path.cwd()
        self._project_dir.mkdir(parents=True, exist_ok=True)

    @property
    def project_dir(self) -> Path:
        return self._project_dir

    async def start(self) -> None:
        """Start the bot (blocking)."""
        try:
            from telegram.ext import Application, CommandHandler, MessageHandler, filters
        except ImportError:
            logger.error(
                "python-telegram-bot not installed. "
                "Run: pip install widdx[telegram]"
            )
            return

        app = Application.builder().token(self._token).build()

        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("providers", self._cmd_providers))
        app.add_handler(CommandHandler("key", self._cmd_key))
        app.add_handler(CommandHandler("cd", self._cmd_cd))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_message))

        me = await app.bot.get_me()
        logger.info("WIDDX Telegram Bot started: @%s", me.username)
        print(f"  [success]✓[/] Telegram Bot @{me.username} is running")
        print(f"  [dim]Project dir: {self._project_dir}[/]")
        print(f"  [dim]Send messages to @{me.username} on Telegram[/]")

        try:
            await app.run_polling()
        except KeyboardInterrupt:
            logger.info("Bot stopped by user")

    # ── Security ──────────────────────────────────────────────────

    async def _check_access(self, update: Update) -> bool:
        if self._allowed_users is None:
            return True
        user_id = update.effective_user.id if update.effective_user else 0
        return user_id in self._allowed_users

    # ── Commands ───────────────────────────────────────────────────

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            await update.message.reply_text("⛔ Access denied.")
            return
        await update.message.reply_text(
            "🤖 *WIDDX AI Agent*\n\n"
            f"📁 Project: `{self._project_dir.name}`\n\n"
            "Send me any task and I'll build it.\n\n"
            "*Commands:*\n"
            "/help — Show all commands\n"
            "/status — Session status\n"
            "/providers — Manage AI providers\n"
            "/key — Set DeepSeek API key\n"
            "/cd <path> — Change project directory",
            parse_mode="Markdown",
        )

    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        providers = self._router.list_providers()
        active = sum(1 for p in providers if p["enabled"])
        dsk = self._config.get("__env__", {}).get("deepseek_key")
        key_status = "✓ set" if dsk else "not set"

        await update.message.reply_text(
            f"🤖 *WIDDX v1.6*\n\n"
            f"📁 Project: `{self._project_dir}`\n"
            f"📡 Providers: {active}/{len(providers)} active\n"
            f"🔑 Key: {key_status}\n\n"
            f"*Commands*\n"
            f"/start — Welcome\n"
            f"/help — This message\n"
            f"/status — Session stats\n"
            f"/providers — List providers\n"
            f"/key <sk-...> — Set API key\n"
            f"/cd <path> — Change project directory\n\n"
            f"*Or just send a task:*\n"
            f"\"create a REST API with FastAPI\"\n"
            f"\"fix the auth bug in login.py\"",
            parse_mode="Markdown",
        )

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        tokens = self._router.session_tokens
        cost = self._router.session_cost
        files = list(self._project_dir.glob("*"))
        await update.message.reply_text(
            f"📊 *Session Status*\n\n"
            f"📁 Project: `{self._project_dir}`\n"
            f"📄 Files: {len(files)}\n"
            f"Tokens: ↑{tokens['input']} ↓{tokens['output']}\n"
            f"Cost: ${cost:.4f}\n"
            f"Model: {self._config.get('models', {}).get('executor', {}).get('model', 'deepseek')}",
            parse_mode="Markdown",
        )

    async def _cmd_cd(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        new_dir = " ".join(context.args) if context.args else ""
        if not new_dir:
            await update.message.reply_text(
                f"📁 Current: `{self._project_dir}`\nUsage: /cd /path/to/project"
            )
            return

        path = Path(new_dir).expanduser().resolve()
        if not path.exists():
            try:
                path.mkdir(parents=True, exist_ok=True)
            except OSError:
                await update.message.reply_text("❌ Cannot create directory. Check permissions.")
                return
        if not path.is_dir():
            await update.message.reply_text(f"❌ Not a directory: {path}")
            return

        self._project_dir = path
        await update.message.reply_text(f"📁 Project changed to: `{path}`")

    async def _cmd_providers(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        providers = self._router.list_providers()
        lines = ["📡 *AI Providers*\n"]
        for p in providers:
            icon = "✅" if p["enabled"] else "❌"
            mc = p.get("model_count", 1)
            lines.append(f"{icon} *{p['name']}* ({mc} models)")
            lines.append(f"  `{p['executor_model']}`")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    async def _cmd_key(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        key = " ".join(context.args) if context.args else ""
        if not key:
            dsk = self._config.get("__env__", {}).get("deepseek_key")
            if dsk:
                masked = dsk[:8] + "..." + dsk[-4:]
                await update.message.reply_text(f"🔑 Key: `{masked}`\nSend `/key sk-...` to change.")
            else:
                await update.message.reply_text("🔑 No key set.\nSend `/key sk-...` to add DeepSeek.")
            return

        from widdx.config import save_config_key
        save_config_key("deepseek_api_key", key)
        self._config["deepseek_api_key"] = key
        self._config["__env__"]["deepseek_key"] = key
        await update.message.reply_text("✅ API key saved and active.")

    # ── Task handling ──────────────────────────────────────────────

    async def _handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            await update.message.reply_text("⛔ Access denied.")
            return

        task = update.message.text.strip()
        if not task:
            return

        # Show typing indicator
        await update.message.chat.send_action("typing")

        # Run task in thread pool
        result = await asyncio.to_thread(self._run_task, task)

        # Send result text
        if len(result["text"]) > _MAX_TEXT_LEN:
            text = result["text"][:_MAX_TEXT_LEN] + "\n\n… (truncated)"
        else:
            text = result["text"]
        await update.message.reply_text(text, parse_mode="Markdown")

        # Send created/edited files
        for filepath in result["files"]:
            try:
                path = Path(filepath)
                if path.exists() and path.stat().st_size < _MAX_FILE_SIZE:
                    await update.message.chat.send_action("upload_document")
                    await update.message.reply_document(
                        document=open(filepath, "rb"),
                        filename=path.name,
                        caption=f"📄 `{path.relative_to(self._project_dir)}`",
                    )
            except Exception:
                logger.debug("Failed to send file %s via Telegram", filepath, exc_info=True)

    def _run_task(self, task: str) -> dict:
        """Execute task via ToolLoop and return formatted result with files."""
        from .tool_loop import ToolLoop
        import time

        tool_loop = ToolLoop(self._router)
        original_cwd = os.getcwd()
        start = time.time()

        try:
            os.chdir(self._project_dir)
            output = tool_loop.run(task)
        except Exception as e:
            return {"text": f"❌ Error: {e}", "files": []}
        finally:
            os.chdir(original_cwd)

        elapsed = time.time() - start
        elapsed_str = f"{elapsed:.0f}s" if elapsed < 60 else f"{int(elapsed//60)}m{int(elapsed%60)}s"
        tool_count = tool_loop._tool_calls_count
        created = list(dict.fromkeys(tool_loop._created_files))
        edited = list(dict.fromkeys(tool_loop._edited_files))
        all_files = created + edited

        lines = []
        if all_files:
            lines.append(f"📁 *{len(all_files)} files changed*")
            for f in all_files[:15]:
                rel = str(Path(f).relative_to(self._project_dir)) if Path(f).is_relative_to(self._project_dir) else f
                icon = "✨" if f in created else "✏️"
                lines.append(f"  {icon} `{rel}`")

        result_text = output or "Done."
        if result_text:
            preview = result_text[:2000]
            if len(result_text) > 2000:
                preview += "\n\n… (truncated)"
            lines.append(f"\n{preview}")

        lines.append(f"\n⏱ {elapsed_str} · 🔧 {tool_count} tools · 📁 {len(all_files)} files")

        return {
            "text": "\n".join(lines),
            "files": all_files,
        }


# ── Entry point ─────────────────────────────────────────────────────

def run_bot(project_dir: str | None = None) -> None:
    """CLI entry point: widdx bot start [--project-dir PATH]"""
    from widdx.config import load_config

    config = load_config()
    tg_config = config.get("telegram", {})
    token = os.getenv("TELEGRAM_BOT_TOKEN") or tg_config.get("bot_token")

    if not token:
        print("  [error]✗ TELEGRAM_BOT_TOKEN not set.[/]")
        print("  [dim]Set env: $env:TELEGRAM_BOT_TOKEN = 'your-token'[/]")
        print("  [dim]Or add to ~/.widdx/config.yaml:[/]")
        print("  [dim]  telegram:[/]")
        print("  [dim]    bot_token: 'your-token'[/]")
        return

    work_dir = project_dir or tg_config.get("project_dir") or os.getcwd()

    from widdx.memory import MemoryStore
    from widdx.router import AIRouter

    mem_path = config.get("memory", {}).get("db_path", "~/.widdx/memory.db")
    memory = MemoryStore(mem_path)
    router = AIRouter(config, memory)

    allowed = tg_config.get("allowed_users")
    if allowed and not isinstance(allowed, list):
        allowed = [allowed]

    bot = WiddxTelegramBot(
        token=token,
        router=router,
        config=config,
        memory=memory,
        allowed_users=allowed,
        project_dir=work_dir,
    )

    asyncio.run(bot.start())


if __name__ == "__main__":
    run_bot()
