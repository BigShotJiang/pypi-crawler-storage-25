"""widdx/repair_memory.py -- Learns from past fix attempts to avoid redundant LLM calls.

Core loop:
  1. Error occurs in project verification
  2. Fingerprint the error (stable across paths/line numbers)
  3. Check if a known fix pattern exists with high confidence
  4. If yes: apply known fix directly (free, instant)
  5. If no: let LLM fix it, then store the successful pattern
"""
from __future__ import annotations

import hashlib
import logging
import re

logger = logging.getLogger("widdx.repair_memory")


class RepairMemory:
    """Learns from past fix attempts to avoid redundant LLM calls.

    Uses MemoryStore's fix_patterns table for persistence.
    All confidence calculations use Laplace smoothing.

    Typical confidence progression:
      - First success:  (1+1)/(1+0+2) = 0.67
      - Second success: (2+1)/(2+0+2) = 0.75  (crosses 0.7 threshold)
      - With 1 failure: (2+1)/(2+1+2) = 0.60
    """

    def __init__(self, memory_store, config: dict | None = None) -> None:
        self._memory = memory_store
        if config:
            rm_config = config.get("repair_memory", {})
            self._enabled = rm_config.get("enabled", True)
            self._min_confidence = rm_config.get("min_confidence", 0.7)
            self._max_patterns = rm_config.get("max_patterns", 1000)
        else:
            self._enabled = True
            self._min_confidence = 0.7
            self._max_patterns = 1000

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def lookup(self, errors: list[str], language: str = "python") -> list[dict]:
        """Find fix patterns matching the given errors.

        Args:
            errors: List of raw error strings from test output.
            language: Programming language of the project.

        Returns:
            List of matching pattern dicts with confidence >= min_confidence,
            sorted by confidence descending. Empty list if no match.
        """
        if not self._enabled or not errors:
            return []
        fingerprints = [fp["fingerprint"] for fp in self.fingerprint_errors(errors)]
        if not fingerprints:
            return []
        return list(self._memory.find_fix_patterns(fingerprints, self._min_confidence))

    def store(self, errors: list[str], fix_template: str,
              language: str = "python", file_pattern: str = "") -> str | None:
        """Store a fix pattern derived from errors and the applied fix.

        Uses the first error's fingerprint as the key.

        Returns:
            The fingerprint string, or None if storage failed.
        """
        if not self._enabled or not errors or not fix_template:
            return None
        fps = self.fingerprint_errors(errors)
        if not fps:
            return None
        fp = fps[0]
        self._memory.add_fix_pattern(
            fingerprint=fp["fingerprint"],
            error_type=fp["error_type"],
            error_message=fp["normalized"][:500],
            language=language,
            fix_template=fix_template[:2000],
            file_pattern=file_pattern,
            max_patterns=self._max_patterns,
        )
        return str(fp["fingerprint"])

    def record_success(self, fingerprint: str) -> None:
        """Record that a known fix pattern was applied successfully."""
        if not self._enabled or not fingerprint:
            return
        self._memory.update_fix_pattern_result(fingerprint, success=True)
        logger.debug("Fix pattern success: %s", fingerprint[:12])

    def record_failure(self, fingerprint: str) -> None:
        """Record that a known fix pattern was applied but failed."""
        if not self._enabled or not fingerprint:
            return
        self._memory.update_fix_pattern_result(fingerprint, success=False)
        logger.debug("Fix pattern failure: %s", fingerprint[:12])

    # ------------------------------------------------------------------
    # Error Fingerprinting
    # ------------------------------------------------------------------

    @classmethod
    def fingerprint_errors(cls, errors: list[str]) -> list[dict]:
        """Fingerprint each error.

        Returns:
            List of dicts with keys:
              - raw: original error string
              - error_type: e.g. "SyntaxError", "ImportError"
              - normalized: cleaned message (paths, line nums, hex removed)
              - fingerprint: deterministic hash of type + normalized message
        """
        results = []
        for err in errors:
            error_type, normalized = cls.normalize_error(err)
            if not normalized:
                continue
            fp = cls._compute_fingerprint(error_type, normalized)
            results.append({
                "raw": err,
                "error_type": error_type,
                "normalized": normalized,
                "fingerprint": fp,
            })
        return results

    @classmethod
    def normalize_error(cls, error: str) -> tuple[str, str]:
        """Normalize an error message to be stable across paths and line numbers.

        Steps:
          1. Extract error type (first colon-delimited word or known prefix).
          2. Strip absolute file paths (Unix and Windows).
          3. Replace line numbers like :123: with :LINE:.
          4. Replace hex addresses (0x...).
          5. Normalize whitespace.
          6. Truncate to 500 chars.

        Returns:
            (error_type, normalized_message)
        """
        if not error:
            return ("", "")
        text = error.strip()

        error_type = cls._extract_error_type(text)

        # Strip file paths: C:\\Users\\... or /home/user/...
        text = re.sub(
            r'(?:[A-Za-z]:)?[/\\][^\s:()]*[/\\][^\s:()]*',
            '<PATH>', text,
        )

        # Replace line numbers: :123: -> :LINE:
        text = re.sub(r':(\d+):', ':LINE:', text)
        text = re.sub(r'line\s+(\d+)', 'line LINE', text)

        # Replace hex addresses
        text = re.sub(r'0x[0-9a-fA-F]+', '0xHEX', text)

        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()

        # Truncate
        if len(text) > 500:
            text = text[:500]

        return (error_type, text)

    @staticmethod
    def _extract_error_type(text: str) -> str:
        """Extract the most specific error type from an error string."""
        known_types = [
            "SyntaxError", "IndentationError", "TabError",
            "ImportError", "ModuleNotFoundError",
            "NameError", "UnboundLocalError",
            "AttributeError", "TypeError", "ValueError",
            "KeyError", "IndexError", "LookupError",
            "RuntimeError", "RecursionError",
            "FileNotFoundError", "PermissionError",
            "OSError", "IOError",
            "AssertionError",
            "ZeroDivisionError", "OverflowError",
            "StopIteration", "StopAsyncIteration",
            "JSONDecodeError",
        ]
        for t in known_types:
            if t in text:
                return t

        if text.startswith("FAILED") or text.startswith("FAIL:"):
            return "TestFailure"
        if text.startswith("Error:"):
            return "Error"

        m = re.match(r'^(\w+):', text)
        if m:
            return m.group(1)

        return "UnknownError"

    @staticmethod
    def _compute_fingerprint(error_type: str, normalized: str) -> str:
        """SHA-256 based fingerprint for stable deduplication."""
        raw = f"{error_type}||{normalized}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

    # ------------------------------------------------------------------
    # Fix Template Extraction
    # ------------------------------------------------------------------

    @staticmethod
    def extract_fix_template(fix_text: str, files: list[str]) -> str:
        """Extract the fix pattern from an LLM response.

        Uses the same code-block parsing that _apply_fixes uses.
        Returns the last substantial code block.
        """
        if not fix_text:
            return ""
        pattern = r"(?:###?\s*([^\n]+)\s*\n)?```(?:[a-z]*\n)?(.*?)\n```"
        matches = re.findall(pattern, fix_text, re.DOTALL)
        if not matches:
            return ""

        best = ""
        for _, code in matches:
            stripped = code.strip()
            if len(stripped) > 10:
                best = stripped

        return best[:2000]

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def stats(self) -> dict:
        """Return statistics about stored fix patterns."""
        if not self._enabled:
            return {"enabled": False}
        total = self._memory.fix_pattern_count()
        hc = self._memory.fix_pattern_high_confidence_count(self._min_confidence)
        return {
            "enabled": True,
            "total_patterns": total,
            "high_confidence": hc,
            "min_confidence": self._min_confidence,
            "max_patterns": self._max_patterns,
        }

    def list_patterns(self, limit: int = 20, offset: int = 0) -> list[dict]:
        """List stored fix patterns for debugging/inspection."""
        if not self._enabled:
            return []
        rows = self._memory._execute(
            "SELECT fingerprint, error_type, error_message, language, "
            "success_count, fail_count, confidence, last_used "
            "FROM fix_patterns ORDER BY confidence DESC LIMIT ? OFFSET ?",
            (limit, offset),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    @property
    def is_enabled(self) -> bool:
        return bool(self._enabled)


__all__ = ["RepairMemory"]
