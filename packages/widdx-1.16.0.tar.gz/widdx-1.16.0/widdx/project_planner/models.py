"""Data models for the phased project planning system."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Phase:
    """One bounded unit of work within a project plan."""
    id: str
    number: int          # 1-based
    title: str
    goal: str
    deliverables: list[str]
    depends_on: list[str] = field(default_factory=list)
    status: str = "pending"   # pending | running | done | failed
    output_summary: str = ""
    files_created: list[str] = field(default_factory=list)
    files_edited: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> Phase:
        return cls(**d)


@dataclass
class ProjectPlan:
    """A full multi-phase execution plan."""
    id: str
    task: str
    phases: list[Phase]
    tech_stack: list[str] = field(default_factory=list)
    architecture_notes: str = ""
    created_at: str = ""
    status: str = "pending"

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        d["phases"] = [p.to_dict() for p in self.phases]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> ProjectPlan:
        phases = [Phase.from_dict(p) for p in d.pop("phases", [])]
        return cls(phases=phases, **d)

    @property
    def completed_phases(self) -> list[Phase]:
        return [p for p in self.phases if p.status == "done"]

    @property
    def pending_phases(self) -> list[Phase]:
        return [p for p in self.phases if p.status == "pending"]

    @property
    def next_phase(self) -> Phase | None:
        done_ids = {p.id for p in self.completed_phases}
        for p in self.phases:
            if p.status == "pending" and all(dep in done_ids for dep in p.depends_on):
                return p
        # Fallback: if we get stuck, return any pending phase
        for p in self.phases:
            if p.status == "pending":
                return p
        return None

    def progress_pct(self) -> int:
        if not self.phases:
            return 0
        done = sum(1 for p in self.phases if p.status == "done")
        return int(done / len(self.phases) * 100)
