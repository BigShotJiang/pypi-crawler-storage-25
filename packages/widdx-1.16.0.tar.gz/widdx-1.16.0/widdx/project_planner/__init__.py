"""widdx/project_planner — Phased execution for large, complex projects.

Solves three problems identified in the code review:
  1. Context overflow   — splits big tasks into bounded phases
  2. Cross-session loss — persists progress + decisions in MemoryStore
  3. No resume logic   — can restart from the last completed phase

Typical flow:
    planner = ProjectPlanner(router, memory)
    plan    = planner.create_plan("Build a SaaS e-commerce platform")
    planner.execute_plan(plan, agent_factory)
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import TYPE_CHECKING

from .models import Phase, ProjectPlan

if TYPE_CHECKING:
    from .agent_factory import AgentFactory
    from .memory import MemoryStore
    from .router import AIRouter

logger = logging.getLogger(__name__)

_MAX_PHASES = 7
_MIN_PHASES = 2
_COMPLEXITY_THRESHOLD = 3
_MAX_PHASE_RETRIES = 2


class ProjectPlanner:
    """Phased execution for large, complex projects.

    Usage::

        planner = ProjectPlanner(router, memory)

        # Create (or resume) a plan
        plan = planner.create_plan("Build SaaS e-commerce in FastAPI + React")
        # Or resume an interrupted project:
        plan = planner.resume_plan("plan_abc123")
    """

    def __init__(self, router: AIRouter, memory: MemoryStore, fast_mode: bool = False) -> None:
        self._router = router
        self._memory = memory
        self._fast_mode = fast_mode

    # ── Spec + Architecture ────────────────────────────────────────────────

    def create_spec(self, task: str, agent_factory: AgentFactory | None = None) -> str:
        """Create a detailed specification from a task description."""
        from widdx import ui

        c = ui.get_console()

        prefs = self._negotiate_tech_stack(task)
        tech_context = json.dumps(prefs) if prefs else "No preferences specified"

        project_context = self._freeze_project_state()

        system = self._planner_system_prompt(task, "spec")
        msg = (
            f"Task: {task}\n\n"
            f"Tech stack preferences: {tech_context}\n\n"
            f"Project context:\n{project_context}\n\n"
            "Create a detailed technical specification covering:\n"
            "1. Feature scope — what we're building, why (keep scope realistic)\n"
            "2. User stories / acceptance criteria\n"
            "3. Data models & schema (key entities, relationships)\n"
            "4. API design (endpoints, methods, request/response shapes)\n"
            "5. UI / UX requirements (screens, flows, states)\n"
            "6. Constraints — performance, security, compliance\n"
            "7. Out of scope — explicit boundaries\n\n"
            "Be thorough but practical. This spec drives all downstream planning."
        )
        c.print("  [dim]⎿ Creating specification...[/]")
        result = self._router.call_architect(system, msg, max_tokens=4096)
        spec = result.get("text", "") if "error" not in result else ""
        if spec:
            self._memory.set_knowledge(f"spec_{task[:30]}", spec[:2000])
        return spec

    def create_architecture(self, task: str, spec: str, agent_factory: AgentFactory | None = None) -> str:
        """Create architecture design from a task and specification."""
        from widdx import ui

        c = ui.get_console()

        system = self._planner_system_prompt(task, "arch")
        msg = (
            f"Task: {task}\n\n"
            f"Specification:\n{spec[:6000]}\n\n"
            "Create a detailed architecture design:\n"
            "1. System architecture diagram (ASCII or text)\n"
            "2. Component tree / module breakdown\n"
            "3. Data flow between components\n"
            "4. Database schema design (tables, relationships, indexes)\n"
            "5. Security architecture (auth, authorization, data protection)\n"
            "6. Performance considerations\n"
            "7. Scalability approach\n\n"
            "Focus on making concrete, implementable decisions."
        )
        c.print("  [dim]⎿ Designing architecture...[/]")
        result = self._router.call_architect(system, msg, max_tokens=4096)
        arch = result.get("text", "") if "error" not in result else ""
        if arch:
            self._memory.set_knowledge(f"arch_{task[:30]}", arch[:2000])
        return arch

    # ── Code Review + Retrospective ────────────────────────────────────────

    def run_code_review(self, phase: Phase, command: str) -> str:
        """Review output of a single phase for correctness, security, quality."""
        system = (
            "You are a senior code reviewer. Review the output of this phase.\n"
            "Check for: correctness, security (XSS, SQLi, CSRF, injection), "
            "performance, error handling, edge cases, and code style.\n"
            "Be strict — flag issues with severity (HIGH/MEDIUM/LOW). "
            "If clean, say 'Approved'."
        )
        msg = (
            f"Phase: {phase.title}\n"
            f"Goal: {phase.goal}\n"
            f"Files created: {', '.join(phase.files_created)}\n"
            f"Files edited: {', '.join(phase.files_edited)}\n"
            f"Output: {phase.output_summary[:3000]}"
        )
        result = self._router.call_executor(system, msg)
        review = result.get("text", "") if "error" not in result else ""
        return review

    def run_retrospective(self, plan: ProjectPlan) -> str:
        """Run a retrospective after the full plan completes."""
        if not plan or not plan.phases:
            return ""
        system = (
            "You are a process improvement coach. Review this completed project "
            "and identify: (1) what went well, (2) what could be improved, "
            "(3) process changes for next time. Be concise — 3-5 bullet points."
        )
        summary_lines = []
        for phase in plan.phases:
            summary_lines.append(f"- {phase.title} [{phase.status}]: {phase.output_summary[:200]}")
        msg = "Project Retrospective\n\n" + "\n".join(summary_lines)
        result = self._router.call_architect(system, msg, max_tokens=1024)
        return result.get("text", "") if "error" not in result else ""

    def save_progress_dashboard(self, plan: ProjectPlan) -> None:
        """Save a progress dashboard to .widdx so the user can see status."""
        from widdx import ui

        try:
            from .project_state import get_widdx_dir

            widdx_dir = get_widdx_dir()
            dashboard = {
                "plan_id": plan.id,
                "task": plan.task,
                "status": plan.status,
                "progress": plan.progress_pct(),
                "phases": [
                    {
                        "number": p.number,
                        "title": p.title,
                        "status": p.status,
                        "goal": p.goal[:120],
                    }
                    for p in plan.phases
                ],
                "total_phases": len(plan.phases),
                "completed_phases": plan.completed_phases,
            }
            dashboard_path = widdx_dir / "dashboard.json"
            dashboard_path.write_text(json.dumps(dashboard, indent=2), encoding="utf-8")
            c = ui.get_console()
            c.print(f"  [success]✓[/] Dashboard saved to [text].widdx/dashboard.json[/]")
            self._print_progress_bar(plan)
        except Exception as _e:
            logger.debug("Failed to save dashboard: %s", _e)

    def _print_progress_bar(self, plan: ProjectPlan) -> None:
        """Print a compact progress bar with timing."""
        from widdx import ui

        c = ui.get_console()
        pct = plan.progress_pct()
        bar_len = 20
        filled = int(bar_len * pct / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        c.print(f"  [dim]Progress: |{bar}| {pct}% ({len(plan.completed_phases)}/{len(plan.phases)} phases)[/]")

    # ── Planning ───────────────────────────────────────────────────────────

    def create_plan(self, task: str, complexity: int | None = None,
                    spec: str = "", arch: str = "") -> ProjectPlan:
        """Create a phased execution plan for a complex project task."""
        from widdx import ui

        c = ui.get_console()
        plan_id = uuid.uuid4().hex[:12]

        skills = self._load_relevant_skills(task)
        project_context = self._freeze_project_state()

        system = self._planner_system_prompt(task, "plan", spec=spec, arch=arch, skills=skills)
        msg = (
            f"Task: {task}\n\n"
            f"Complexity: {complexity if complexity else 'auto'}\n"
            f"Project context:\n{project_context}\n\n"
        )
        if skills:
            msg += f"Available skills:\n" + "\n".join(f"- {s}" for s in skills) + "\n\n"
        msg += "Generate a phased execution plan."
        c.print("  [dim]⎿ Creating plan...[/]")
        result = self._router.call_architect(system, msg, max_tokens=4096)

        if "error" in result:
            c.print("  [warning]⚠ Planner API error, using fallback plan[/]")
            return self._fallback_plan(plan_id, task, complexity or 3)

        raw_text = result.get("text", "")
        plan = self._parse_plan(raw_text, plan_id, task)
        if plan is None:
            c.print("  [warning]⚠ Could not parse plan, using fallback[/]")
            return self._fallback_plan(plan_id, task, complexity or 3)

        self._save_plan(plan)
        return plan

    def resume_plan(self, plan_id: str) -> ProjectPlan | None:
        """Resume a previously saved plan from its last completed phase."""
        from widdx import ui

        c = ui.get_console()
        try:
            from .project_state import get_widdx_dir

            plan_path = get_widdx_dir() / "plans" / f"{plan_id}.json"
            if not plan_path.exists():
                c.print(f"  [warning]⚠ Plan {plan_id} not found[/]")
                return None
            data = json.loads(plan_path.read_text(encoding="utf-8"))
            plan = ProjectPlan.from_dict(data)
            c.print(f"  [info]ℹ Resumed plan: {plan.task} ({plan.progress_pct()}% done)[/]")
            return plan
        except Exception as e:
            logger.warning("Failed to resume plan %s: %s", plan_id, e)
            return None

    def list_plans(self) -> list[dict]:
        """List all saved plans with their status and progress."""
        try:
            from .project_state import get_widdx_dir

            plans_dir = get_widdx_dir() / "plans"
            if not plans_dir.exists():
                return []
            plans = []
            for f in sorted(plans_dir.glob("*.json")):
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    plans.append({
                        "id": data.get("id", f.stem),
                        "task": data.get("task", "unknown"),
                        "status": data.get("status", "unknown"),
                        "progress": data.get("progress_pct", 0),
                    })
                except (json.JSONDecodeError, OSError):
                    continue
            return plans
        except Exception:
            return []

    # ── Execution ──────────────────────────────────────────────────────────

    def execute_plan(self, plan: ProjectPlan, agent_factory: AgentFactory | None = None) -> ProjectPlan:
        """Execute all phases in the right dependency order with code review gates.

        Each phase is executed by creating an agent with the right skills,
        running it, reviewing the output, and checkpointing to git.
        Failed phases are retried with a simplified scope.
        """
        from widdx import ui

        c = ui.get_console()

        plan.status = "running"
        self._save_plan(plan)

        while True:
            phase = plan.next_phase
            if phase is None:
                break

            phase.status = "running"
            self._save_plan(plan)
            c.print(f"\n  [bold][Phase {phase.number}/{len(plan.phases)}][/] [text]{phase.title}[/]")
            c.print(f"  [dim]Goal: {phase.goal[:120]}[/]")

            success = False
            for attempt in range(_MAX_PHASE_RETRIES + 1):
                if attempt > 0:
                    c.print(f"  [warning]⚠ Retry {attempt}/{_MAX_PHASE_RETRIES}...[/]")

                output = self._execute_phase(phase, plan, agent_factory)
                phase.output_summary = output[:2000]

                files = self._extract_files(output)
                if files:
                    phase.files_created.extend(files.get("created", []))

                # Code review gate
                review = self.run_code_review(phase, plan.task)

                if "Approved" in review or not files:
                    success = True
                    break

                c.print(f"  [warning]⚠ Code review flagged issues: {review[:200]}[/]")

                if attempt < _MAX_PHASE_RETRIES:
                    self._retry_phase_simplified(phase, plan, agent_factory, review)

            if not success:
                phase.status = "failed"
                c.print(f"  [error]✗ Phase {phase.number} failed after {_MAX_PHASE_RETRIES + 1} attempts[/]")
            else:
                phase.status = "done"
                decisions = self._extract_decisions(output)
                phase.decisions.extend(decisions)
                c.print(f"  [success]✓ Phase {phase.number} complete[/]")

            self._save_phase_decisions(phase, plan)
            self._git_checkpoint(phase, plan)
            self._save_plan(plan)

        # Determine final status
        failed = [p for p in plan.phases if p.status == "failed"]
        done = [p for p in plan.phases if p.status == "done"]
        pending = [p for p in plan.phases if p.status == "pending"]
        total = len(plan.phases)

        if failed:
            plan.status = "partial"
        elif pending:
            plan.status = "incomplete"
        else:
            plan.status = "done"
        self._save_plan(plan)

        if pending and not failed:
            c.print(f"\n  [warn]Plan paused: {len(done)}/{total} phases done, {len(pending)} remaining.[/]")
            c.print(f"  [dim]Type /resume or describe what to fix in the remaining phases.[/]")
        elif failed:
            c.print(f"\n  [warn]Plan completed with {len(failed)}/{total} failed phases, {len(done)} succeeded.[/]")
        else:
            c.print(f"\n  [ok]All {total}/{total} phases completed successfully.[/]")

        self.run_retrospective(plan)
        self.save_progress_dashboard(plan)

        return plan

    def _execute_phase(self, phase: Phase, plan: ProjectPlan,
                       agent_factory: AgentFactory | None) -> str:
        """Execute a single phase by creating an agent or calling the router."""
        from widdx.agent_factory.runner import AgentRunner
        from widdx.agent_factory.spec import AgentSpec

        if agent_factory:
            spec = AgentSpec(
                role=f"Phase {phase.number} Executor",
                goal=f"Execute: {phase.title} — {phase.goal}",
                domain="fullstack",
            )
            runner = AgentRunner(spec, self._router, self._freeze_project_state())
            task_desc = self._phase_task_description(phase, plan)
            result = runner.run(task_desc)
            return result.get("output", "") or ""

        from .tool_loop import ToolLoop

        system = self._planner_system_prompt(plan.task, "execute")
        msg = self._phase_task_description(phase, plan)
        loop = ToolLoop(self._router, max_steps=30)
        loop.set_project_context(system)
        return loop.run(msg)

    def _retry_phase_simplified(self, phase: Phase, plan: ProjectPlan,
                                agent_factory: AgentFactory | None,
                                review_feedback: str) -> None:
        """Retry a failed phase with a simplified scope."""
        from widdx import ui

        c = ui.get_console()
        system = (
            "You are the phase executor. The previous attempt had issues. "
            "Simplify the scope and fix the problems identified in the review.\n"
            f"Review feedback:\n{review_feedback[:2000]}"
        )
        msg = self._phase_task_description(phase, plan)
        loop = __import__("widdx.tool_loop", fromlist=["ToolLoop"]).ToolLoop(self._router, max_steps=15)
        loop.set_project_context(system)
        output_text = loop.run(msg)
        phase.output_summary = output_text[:2000]
        c.print(f"  [dim]Retry output: {output_text[:200]}...[/]")

    def _phase_task_description(self, phase: Phase, plan: ProjectPlan) -> str:
        """Build a task description for a phase, including context."""
        completed = plan.completed_phases
        context_parts = [f"Phase {phase.number}: {phase.title}"]
        context_parts.append(f"Goal: {phase.goal}")
        context_parts.append(f"Deliverables: {', '.join(phase.deliverables)}")
        if completed:
            context_parts.append("\nCompleted phases context:")
            for p in completed:
                context_parts.append(f"  - {p.title}: {p.output_summary[:200]}")
        if phase.depends_on:
            dep_phases = [p for p in plan.phases if p.id in phase.depends_on]
            for dp in dep_phases:
                if dp.output_summary:
                    context_parts.append(f"Dependency '{dp.title}' output: {dp.output_summary[:500]}")
        context_parts.append(self._build_arch_context(plan))
        return "\n".join(context_parts)

    def _git_checkpoint(self, phase: Phase, plan: ProjectPlan) -> None:
        """Checkpoint work to git after each completed phase."""
        import subprocess

        try:
            cwd = __import__("pathlib").Path.cwd()
            if not (cwd / ".git").exists():
                return
            subprocess.run(
                ["git", "add", "-A"],
                capture_output=True, text=True, timeout=30, cwd=str(cwd),
            )
            subprocess.run(
                ["git", "commit", "-m",
                 f"Phase {phase.number}/{len(plan.phases)}: {phase.title} [WIDDX]"],
                capture_output=True, text=True, timeout=30, cwd=str(cwd),
            )
        except Exception as _e:
            logger.debug("Failed to set git commit title: %s", _e)

    def _build_arch_context(self, plan: ProjectPlan) -> str:
        """Build architecture context string from plan."""
        if not plan.tech_stack and not plan.architecture_notes:
            return ""
        parts = []
        if plan.tech_stack:
            parts.append("Tech stack: " + ", ".join(plan.tech_stack))
        if plan.architecture_notes:
            parts.append(f"Architecture: {plan.architecture_notes[:300]}")
        return "\n".join(parts)

    def _save_phase_decisions(self, phase: Phase, plan: ProjectPlan) -> None:
        """Log decisions made during a phase to MemoryStore."""
        self._memory.log_decision(
            plan.id,
            "phase_execution",
            phase.title,
            f"Phase {phase.number}: {phase.goal[:100]}",
            phase.output_summary[:500],
            self._router.classify(plan.task),
        )

    def get_project_decisions(self, plan_id: str) -> list[dict]:
        """Get all decisions made during a project."""
        return self._memory.task_decisions(plan_id)

    # ── Project state ───────────────────────────────────────────────────────

    def _freeze_project_state(self) -> str:
        """Capture current project structure for the planning prompt."""
        from widdx.indexer import ProjectIndexer

        try:
            indexer = ProjectIndexer()
            return indexer.context_for_ai()
        except Exception:
            return ""

    # ── Persistence ─────────────────────────────────────────────────────────

    def _save_plan(self, plan: ProjectPlan) -> None:
        """Persist a plan to .widdx/plans/ so it can be resumed later."""
        try:
            from .project_state import get_widdx_dir

            plans_dir = get_widdx_dir() / "plans"
            plans_dir.mkdir(parents=True, exist_ok=True)
            plan_path = plans_dir / f"{plan.id}.json"
            plan_path.write_text(json.dumps(plan.to_dict(), indent=2), encoding="utf-8")
        except Exception:
            pass

    # ── LLM prompt ────────────────────────────────────────────────────────

    def _negotiate_tech_stack(self, task: str) -> dict[str, str]:
        """Ask the user about their tech stack preferences."""
        from widdx import ui
        from widdx.scaffolder import detect_framework

        prefs: dict[str, str] = {}
        detected = detect_framework(task)

        # Fast mode: auto-detect sensible defaults, no interactive prompts
        if self._fast_mode:
            if detected:
                key, cfg = detected
                prefs["framework"] = key
                prefs["database"] = "SQLite"
                prefs["deployment"] = "Docker"
                if key in ("laravel", "django", "rails"):
                    prefs["auth"] = {"laravel": "Sanctum", "django": "django-auth", "rails": "Devise"}.get(key, "Built-in")
            else:
                prefs["project_type"] = "Web App (frontend+backend)"
            return prefs

        if detected is None:
            choices = ui.confirm_with_options(
                "No framework detected. What kind of project?",
                ["Web App (frontend+backend)", "API / Backend", "Frontend only", "CLI / Script"],
                default="Web App (frontend+backend)",
            )
            prefs["project_type"] = choices
            return prefs

        key, cfg = detected
        ui.get_console().print(f"  [dim]Detected: {cfg.label}[/]")

        want = ui.confirm(f"Build a {cfg.label} project?", default=True)
        if not want:
            prefs["framework"] = "other"
            return prefs

        prefs["framework"] = key

        db = ui.confirm_with_options(
            "Which database?",
            ["SQLite", "PostgreSQL", "MySQL", "MongoDB"],
            default="SQLite",
        )
        prefs["database"] = db

        if key in ("laravel", "django", "rails"):
            auth_choices = {"laravel": ["Sanctum", "JWT", "Session"],
                           "django": ["django-auth", "djoser", "JWT"],
                           "rails": ["Devise", "JWT"]}
            auth = ui.confirm_with_options(
                "Authentication?",
                auth_choices.get(key, ["Built-in", "None"]),
                default=auth_choices.get(key, ["Built-in"])[0],
            )
            prefs["auth"] = auth

        deploy = ui.confirm_with_options(
            "Deployment target?",
            ["Docker", "Shared hosting", "VPS", "Serverless"],
            default="Docker",
        )
        prefs["deployment"] = deploy

        return prefs

    def _load_relevant_skills(self, task: str) -> list[str]:
        """Load skills that match the task before planning begins."""
        try:
            from .skills import SkillManager
            mgr = SkillManager()
            mgr.load()
            return mgr.match_skills(task, max_skills=5)
        except Exception:
            return []

    def _planner_system_prompt(self, task: str, mode: str,
                               spec: str = "", arch: str = "",
                               skills: list[str] | None = None) -> str:
        """Build the system prompt for the planner LLM call."""
        base = (
            "You are WIDDX Planner, an AI that plans and executes software projects.\n"
            "You split complex tasks into manageable phases with clear dependencies.\n\n"
            "Rules:\n"
            "- Each phase must produce working, testable code\n"
            "- Phases build on each other — later phases assume earlier ones are done\n"
            "- Keep each phase small enough for a single LLM context window\n"
            "- Use the Write tool to create files, the Bash tool to run commands\n"
            "- Do NOT edit files created in earlier phases without explicit need\n\n"
        )
        if mode == "spec":
            return base + (
                "You are writing a software specification. "
                "Focus on clarity, completeness, and actionable details. "
                "Include data models, API endpoints, user flows."
            )
        if mode == "arch":
            return base + (
                "You are designing system architecture. "
                "Focus on component boundaries, data flow, and technology choices. "
                "Make concrete decisions — avoid 'consider using X'."
            )
        if mode == "plan":
            plan_prompt = base + (
                "You are creating a phased execution plan. "
                "Split the project into {min_phases}-{max_phases} phases.\n\n"
                "Return ONLY valid JSON with this exact structure:\n"
                "{{\n"
                '  "phases": [\n'
                "    {{\n"
                '      "title": "Phase name",\n'
                '      "goal": "Single sentence goal",\n'
                '      "deliverables": ["file1.py", "file2.js"],\n'
                '      "depends_on": []\n'
                "    }}\n"
                "  ],\n"
                '  "tech_stack": ["Python", "FastAPI"],\n'
                '  "architecture_notes": "Key decisions"\n'
                "}}\n\n"
                "Do NOT wrap in markdown fences. Return PURE JSON."
            ).format(min_phases=_MIN_PHASES, max_phases=_MAX_PHASES)
            if spec:
                plan_prompt += f"\n\nSpecification:\n{spec[:3000]}"
            if arch:
                plan_prompt += f"\n\nArchitecture:\n{arch[:3000]}"
            if skills:
                plan_prompt += (
                    "\n\nAvailable skills (load before relevant phases):\n"
                    + "\n".join(f"- {s}" for s in skills)
                )
            return plan_prompt

        return base + "Execute the phase. Create files, run commands, deliver results."

    def _parse_plan(self, raw_text: str, plan_id: str, task: str) -> ProjectPlan | None:
        """Parse LLM plan output into a ProjectPlan."""
        text = raw_text.strip()

        extracted = self._extract_json(text)
        if extracted and extracted != text:
            text = extracted

        if text.startswith("{"):
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                return None
        else:
            return None

        phases_data = data.get("phases", [])
        if not phases_data:
            return None

        phases = []
        for i, pd in enumerate(phases_data):
            phase = Phase(
                id=f"phase_{i+1}",
                number=i + 1,
                title=pd.get("title", f"Phase {i+1}"),
                goal=pd.get("goal", ""),
                deliverables=pd.get("deliverables", []),
                depends_on=pd.get("depends_on", []),
            )
            phases.append(phase)

        return ProjectPlan(
            id=plan_id,
            task=task,
            phases=phases,
            tech_stack=data.get("tech_stack", []),
            architecture_notes=data.get("architecture_notes", ""),
        )

    def _fallback_plan(self, plan_id: str, task: str, complexity: int) -> ProjectPlan:
        """Generate a simple default plan when the LLM call fails."""
        num_phases = min(_MAX_PHASES, max(_MIN_PHASES, complexity))
        phases = []
        phase_templates = [
            ("Setup and Configuration", "Set up the project structure, dependencies, and configuration."),
            ("Core Data Models", "Implement the core data models and database schema."),
            ("Core Business Logic", "Implement the main business logic and API endpoints."),
            ("User Interface", "Build the user interface components."),
            ("Integration and Testing", "Integrate all components and add tests."),
            ("Documentation and Polish", "Add documentation and polish the application."),
            ("Deployment Configuration", "Set up deployment configuration."),
        ]
        for i in range(num_phases):
            title, goal = phase_templates[i] if i < len(phase_templates) else (f"Phase {i+1}", "Continue implementation.")
            phases.append(Phase(
                id=f"phase_{i+1}",
                number=i + 1,
                title=title,
                goal=goal,
                deliverables=[],
                depends_on=[f"phase_{j+1}" for j in range(i)] if i > 0 else [],
            ))
        return ProjectPlan(id=plan_id, task=task, phases=phases)

    @staticmethod
    def _extract_json(text: str) -> str:
        """Extract JSON from LLM output."""
        import re
        cleaned = re.sub(
            r"```(?:json)?\s*\n?(.*?)\n?\s*```",
            r"\1",
            text,
            flags=re.DOTALL,
        ).strip()
        brace_stack: list[str] = []
        json_start = -1
        for i, ch in enumerate(cleaned):
            if ch == "{":
                if not brace_stack:
                    json_start = i
                brace_stack.append(ch)
            elif ch == "}":
                if brace_stack:
                    brace_stack.pop()
                    if not brace_stack and json_start >= 0:
                        return cleaned[json_start:i + 1]
        return cleaned

    @staticmethod
    def _extract_decisions(output: str) -> list[str]:
        """Extract key architectural decisions from agent output."""
        decisions = []
        markers = ["Decision:", "Chose:", "Selected:", "Using:", "Opted for:"]
        for line in output.split("\n"):
            stripped = line.strip()
            for marker in markers:
                if stripped.startswith(f"- {marker}") or stripped.startswith(f"* {marker}"):
                    decisions.append(stripped.lstrip("-* ").strip())
                    break
        return decisions[:10]

    @staticmethod
    def _extract_files(output: str) -> dict[str, list[str]]:
        """Extract created/edited file paths from agent output."""
        import re
        created = re.findall(r"(?:Created|Created/Edited):?\s*(\S+)", output, re.IGNORECASE)
        edited = re.findall(r"(?:Edited):?\s*(\S+)", output, re.IGNORECASE)
        return {"created": created[:20], "edited": edited[:20]}

    @staticmethod
    def _estimate_complexity(task: str) -> int:
        """Quick local complexity estimate without LLM call."""
        task_lower = task.lower()
        # File-level tasks (1-2)
        if any(kw in task_lower for kw in ["tiny", "small", "simple", "quick"]):
            return 1
        if any(kw in task_lower for kw in ["fix", "bug", "typo", "rename", "refactor"]):
            return 2
        if any(kw in task_lower for kw in ["file", "function", "method", "class", "component"]):
            return 2
        # Project-level tasks (3-5)
        if any(kw in task_lower for kw in ["fullstack", "complete", "entire", "whole system", "saas", "platform"]):
            return 5
        if any(kw in task_lower for kw in ["frontend", "backend", "api", "database"]):
            return 4
        if any(kw in task_lower for kw in ["build", "create", "make", "project", "app", "application"]):
            return 3
        return 1
