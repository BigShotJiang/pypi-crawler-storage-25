"""WIDDX CLI — Entry point for `python -m widdx`."""
from .cli import main

if __name__ == "__main__":
    main()
