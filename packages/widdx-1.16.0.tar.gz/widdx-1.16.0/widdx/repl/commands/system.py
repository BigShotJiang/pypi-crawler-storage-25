"""System info commands — /agents, /memory, /learn, /skills, /hooks, /mcp, /bootstrap, /projects, /knowledge."""
from __future__ import annotations

import uuid

from widdx import ui
from widdx.ui.arabic import _d

_SEP = "\u2500" * 60


def _run_agents(self, task: str) -> None:
    if not task:
        ui.get_console().print("  [dim]Usage: /agents <task description>[/]")
        ui.get_console().print("  [dim]Example: /agents build a REST API with authentication and a React frontend[/]")
        return

    from widdx.agent_factory import AgentFactory

    c = ui.get_console()
    c.print()
    c.print("  [brand]\u25c6 Multi-Agent Mode[/]")
    c.print(f"  [dim]Task: {task}[/]")
    c.print()

    factory = AgentFactory(self._router)

    c.print("  [dim]Designing agent team...[/]")
    complexity = self._estimate_complexity(task)
    specs = factory.generate_team(task, complexity)

    c.print(f"  [success]Team:[/] {len(specs)} agent{'s' if len(specs) != 1 else ''}")
    for s in specs:
        deps = f" (after: {', '.join(s.depends_on)})" if s.depends_on else ""
        c.print(f"    [dim]\u2022[/] [highlight]{s.role}[/] [dim]\u2014 {s.goal[:60]}{deps}[/]")
    c.print()

    task_id = uuid.uuid4().hex[:12]
    self._memory.create_task(task_id, task, task, complexity)

    project_context = self._tool_loop._project_context
    result = factory.execute_team(specs, task, task_id, self._memory, project_context)

    self._memory.complete_task(task_id)

    c.print()
    c.print(f"  [dim]{_SEP}[/]")
    try:
        ui.render_markdown(result)
    except Exception:
        c.print(f"  [text]{ui.reshape(result[:2000])}[/]")


def _show_memory(self) -> None:
    c = ui.get_console()

    content = getattr(self, "_project_md", "")
    if not content:
        c.print("  [dim]No WIDDX.md loaded. Create a WIDDX.md (or CLAUDE.md) in your project root.[/]")
        return

    c.print()
    c.print("  [brand]WIDDX.md \u2014 Project Memory[/]")
    c.print(f"  [dim]{_SEP}[/]")
    try:
        ui.render_markdown(content)
    except Exception:
        c.print(f"  [text]{content}[/]")
    c.print()


def _show_learning(self) -> None:
    c = ui.get_console()

    learner = getattr(self, "_self_learning", None)
    if learner is None or not learner.is_enabled:
        c.print("  [dim]Self-learning is not enabled.[/]")
        return

    dashboard = learner.dashboard(limit=8)
    events = dashboard.get("events", [])
    patterns = dashboard.get("patterns", [])
    assets = dashboard.get("assets", [])

    c.print()
    c.print("  [brand]Learning Ledger[/]")
    c.print(f"  [dim]{_SEP}[/]")

    if events:
        c.print("  [highlight]Recent Events[/]")
        for event in events[:5]:
            status = "success" if event.get("success") else "warning"
            provider = event.get("provider") or "unknown"
            c.print(
                f"    [{status}]\u2022[/] [text]{event.get('task_type', 'general')}[/] "
                f"[dim]via {provider}[/]  "
                f"[dim]{str(event.get('task_text', ''))[:54]}[/]"
            )
    else:
        c.print("  [dim]No learning events recorded yet.[/]")

    c.print()
    if patterns:
        c.print("  [highlight]Recurring Patterns[/]")
        for pattern in patterns[:5]:
            c.print(
                f"    [dim]\u2022[/] [text]{pattern.get('scope', '')}[/]  "
                f"[dim]evidence={pattern.get('evidence_count', 0)} "
                f"confidence={float(pattern.get('confidence', 0.0)):.2f}[/]"
            )
    else:
        c.print("  [dim]No recurring patterns yet.[/]")

    c.print()
    if assets:
        c.print("  [highlight]Draft Assets[/]")
        for asset in assets[:5]:
            c.print(
                f"    [dim]\u2022[/] [text]{asset.get('asset_type', '')}:{asset.get('name', '')}[/]  "
                f"[dim]{asset.get('status', 'draft')}[/]"
            )
    else:
        c.print("  [dim]No draft skills/agents yet.[/]")
    c.print()


def _show_skills(self) -> None:
    c = ui.get_console()

    skill_manager = self._tool_loop._skill_manager
    skills = skill_manager.list_skills()

    if not skills:
        c.print()
        c.print("  [dim]No skills loaded.[/]")
        c.print("  [dim]Add skill files (*.md) to:[/]")
        c.print("  [dim]  ~/.widdx/skills/   (user-level)[/]")
        c.print("  [dim]  .widdx/skills/     (project-level)[/]")
        c.print()
        return

    c.print()
    c.print("  [brand]Available Skills:[/]")
    c.print(f"  [dim]{_SEP}[/]")

    skill_meta = {s["name"]: s.get("auto_invoke", False) for s in skill_manager._skills}

    for name, description in skills:
        auto = skill_meta.get(name, False)
        mode = "[success]auto[/]" if auto else "[dim]manual[/]"
        c.print(f"  [highlight]{_d(name)}[/]  [{mode}]  [text]{_d(description)}[/]")

    c.print()


def _show_hooks(self) -> None:
    c = ui.get_console()

    hook_manager = getattr(self._tool_loop, "_hook_manager", None)
    if hook_manager is None:
        c.print("  [dim]Hook manager not available.[/]")
        return

    hooks = hook_manager.all_hooks()

    if not hooks:
        c.print()
        c.print("  [dim]No hooks loaded.[/]")
        c.print("  [dim]Add a hooks.json to:[/]")
        c.print("  [dim]  ~/.widdx/hooks.json   (user-level)[/]")
        c.print("  [dim]  .widdx/hooks.json     (project-level)[/]")
        c.print()
        return

    c.print()
    c.print("  [brand]Loaded Hooks:[/]")
    c.print(f"  [dim]{_SEP}[/]")

    for event_name, hook_list in hooks.items():
        c.print(f"  [highlight]{event_name}[/]  [dim]({len(hook_list)} hook{'s' if len(hook_list) != 1 else ''})[/]")
        for hook in hook_list:
            hook_type = hook.get("type", "command")
            matcher = hook.get("matcher", "")
            is_async = hook.get("async", False)

            parts: list[str] = [f"[text]{hook_type}[/]"]
            if matcher:
                parts.append(f"[dim]matcher:[/] [text]{matcher}[/]")
            if is_async:
                parts.append("[dim]async[/]")

            c.print(f"    [dim]\u2022[/] {' '.join(parts)}")

    c.print()


def _show_mcp(self, arg: str) -> None:
    c = ui.get_console()

    mcp_registry = getattr(self._tool_loop, "_mcp_registry", None)
    if mcp_registry is None:
        c.print("  [dim]MCP registry not available.[/]")
        return

    if arg.startswith("add "):
        rest = arg[4:].strip()
        parts = rest.split(maxsplit=1)
        if len(parts) < 2:
            c.print("  [dim]Usage: /mcp add <name> <command>[/]")
            c.print("  [dim]Example: /mcp add github uvx mcp-server-github[/]")
            return
        server_name = parts[0]
        server_cmd = parts[1]
        try:
            mcp_registry.add_server(server_name, server_cmd)
            c.print(f"  [success]\u2713 MCP server '{server_name}' added and connected.[/]")
        except Exception as exc:
            c.print(f"  [error]\u2717 Failed to add MCP server '{server_name}': {exc}[/]")
        return

    if arg.startswith("remove "):
        server_name = arg[7:].strip()
        if not server_name:
            c.print("  [dim]Usage: /mcp remove <name>[/]")
            return
        removed = mcp_registry.remove_server(server_name)
        if removed:
            c.print(f"  [success]\u2713 MCP server '{server_name}' removed.[/]")
        else:
            c.print(f"  [warning]No MCP server named '{server_name}' is connected.[/]")
        return

    servers = mcp_registry.all_servers()

    if not servers:
        c.print()
        c.print("  [dim]No MCP servers connected.[/]")
        c.print("  [dim]Add a server with: /mcp add <name> <command>[/]")
        c.print("  [dim]Or configure ~/.widdx/mcp.json[/]")
        c.print()
        return

    c.print()
    c.print("  [brand]Connected MCP Servers:[/]")
    c.print(f"  [dim]{_SEP}[/]")

    for name, info in servers.items():
        status = "[success]\u25cf[/]" if info.get("connected") else "[error]\u25cb[/]"
        tools = info.get("tools", [])
        c.print(f"  {status} [highlight]{name}[/]  [dim]({len(tools)} tool{'s' if len(tools) != 1 else ''})[/]")
        for tool in tools[:10]:
            c.print(f"    [dim]\u2022[/] [text]{tool}[/]")
        if len(tools) > 10:
            c.print(f"    [dim]... and {len(tools) - 10} more[/]")

    c.print()


def _bootstrap(self, technology: str) -> None:
    from widdx.bootstrap import BootstrapManager

    c = ui.get_console()

    if not technology:
        c.print("  [dim]Usage: /bootstrap <technology>[/]")
        c.print("  [dim]Example: /bootstrap laravel[/]")
        c.print("  [dim]Example: /bootstrap nextjs[/]")
        c.print()
        c.print("  [dim]This will:[/]")
        c.print("  [dim]  1. Research the technology documentation[/]")
        c.print("  [dim]  2. Generate a skill file with conventions & patterns[/]")
        c.print("  [dim]  3. Generate an agent for the technology[/]")
        c.print("  [dim]  4. Generate hooks if applicable[/]")
        c.print("  [dim]  5. Save to .widdx/ in your project[/]")
        return

    c.print()
    c.print(f"  [brand]Bootstrapping:[/] [highlight]{technology}[/]")
    c.print("  [dim]Researching best practices, conventions, and patterns...[/]")

    manager = BootstrapManager(self._router)

    try:
        result = manager.bootstrap(technology)
    except Exception as exc:
        c.print(f"  [error]Bootstrap failed: {exc}[/]")
        return

    if result.skills_created or result.agents_created or result.hooks_created:
        c.print("  [success]Done. Created:[/]")
        for s in result.skills_created:
            c.print(f"    [success]+[/] [text]{s}[/]")
        for a in result.agents_created:
            c.print(f"    [success]+[/] [text]{a}[/]")
        for h in result.hooks_created:
            c.print(f"    [success]+[/] [text]{h}[/]")
        c.print()
        c.print(f"  [dim]{result.summary}[/]")
        self._tool_loop._skill_manager.load()
    else:
        c.print(f"  [warning]{result.summary}[/]")


def _list_projects(self) -> None:
    c = ui.get_console()
    plans = self._memory.get_project_plans(limit=15)

    if not plans:
        c.print("  [dim]No previous projects found.[/]")
        return

    c.print()
    c.print("  [bold]PREVIOUS PROJECTS[/]")
    for p in plans:
        status_icon = {"done": "[success]\u2713[/]", "failed": "[error]\u2717[/]",
                       "partial": "[warning]\u26a0[/]", "running": "[brand]\u25b6[/]"}
        icon = status_icon.get(p["status"], "[dim]?[/]")
        c.print(
            f"  {icon} [text]{p['task']}[/]"
            f"  [dim]\u00b7[/]  [dim]{p['done']}/{p['phases']} phases[/]"
            f"  [dim]\u00b7[/]  [dim]id: {p['id']}[/]"
        )
    c.print()


def _search_knowledge(self, query: str) -> None:
    c = ui.get_console()
    if not query:
        c.print("  [dim]Usage: /knowledge <search query>[/]")
        return

    results = self._memory.search_knowledge(query, limit=10)
    if not results:
        c.print(f"  [dim]No knowledge found for: {query}[/]")
        return

    c.print()
    c.print(f"  [bold]KNOWLEDGE: {query}[/]")
    for r in results:
        key = r.get("key", "")
        value = r.get("value", "")[:120]
        updated = (r.get("updated_at") or "")[:16]
        c.print(f"  [brand]\u25c6[/] [text]{key}[/]")
        c.print(f"    [dim]{value}[/]")
        c.print(f"    [dim]{updated}[/]")
    c.print()
