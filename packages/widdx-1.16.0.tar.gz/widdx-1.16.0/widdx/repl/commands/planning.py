"""Planning commands — /plan, /plans, /resume <plan_id>."""
from __future__ import annotations

from widdx import ui


def _resume_plan(self, plan_id: str) -> None:
    c = ui.get_console()
    from widdx.agent_factory import AgentFactory
    from widdx.project_planner import ProjectPlanner

    router = getattr(self._tool_loop, "_router", None)
    if not router:
        c.print("  [error]No router available.[/]")
        return

    planner = ProjectPlanner(router, self._memory)
    plan = planner.resume_plan(plan_id)

    if plan is None:
        c.print(f"  [warning]Plan '{plan_id}' not found.[/]")
        c.print("  [dim]Use /plans to list saved plans.[/]")
        return

    done = len(plan.completed_phases)
    total = len(plan.phases)
    c.print()
    c.print(f"  [brand]\u25c6 Resuming plan[/] [dim]{plan.id}[/]")
    c.print(f"  [text]{plan.task[:70]}[/]")
    c.print(f"  [dim]Progress: {done}/{total} phases  ({plan.progress_pct()}%)[/]")
    c.print()

    if plan.next_phase is None:
        c.print("  [success]\u2713 All phases already completed![/]")
        return

    planner.execute_plan(plan, AgentFactory(router))


def _plan_project(self, description: str) -> None:
    c = ui.get_console()

    if not description:
        c.print()
        c.print("  [dim]Usage: /plan <description>[/]")
        c.print("  [dim]Example: /plan Build a REST API with auth and a React frontend[/]")
        c.print()
        c.print("  [dim]Phases are executed sequentially with context passed between them.[/]")
        c.print("  [dim]Progress is saved \u2014 resume with: /resume <plan_id>[/]")
        c.print()
        return

    from widdx.agent_factory import AgentFactory
    from widdx.project_planner import ProjectPlanner

    router = getattr(self._tool_loop, "_router", None)
    if not router:
        c.print("  [error]No router available.[/]")
        return

    planner = ProjectPlanner(router, self._memory)
    agent_factory = AgentFactory(router)

    c.print()
    plan = planner.create_plan(description)
    c.print()

    c.print(f"  [bold text]{plan.task[:75]}[/]")
    if plan.tech_stack:
        c.print(f"  [dim]Stack: {', '.join(plan.tech_stack)}[/]")
    c.print(f"  [dim]Plan ID: {plan.id}[/]")
    c.print()

    for ph in plan.phases:
        c.print(f"  [dim]\u25cb[/] [text]Phase {ph.number}:[/] {ph.title}")
        for d in ph.deliverables[:3]:
            c.print(f"       [dim]\u00b7 {d}[/]")
        if len(ph.deliverables) > 3:
            c.print(f"       [dim]\u2026 +{len(ph.deliverables) - 3} more[/]")
    c.print()

    if not ui.confirm(f"Execute this {len(plan.phases)}-phase plan?"):
        c.print(f"  [dim]Saved. Resume with: /resume {plan.id}[/]")
        return

    c.print()
    planner.execute_plan(plan, agent_factory)


def _list_plans(self) -> None:
    c = ui.get_console()
    from widdx.project_planner import ProjectPlanner

    router = getattr(self._tool_loop, "_router", None)
    if not router:
        c.print("  [error]No router available.[/]")
        return

    plans = ProjectPlanner(router, self._memory).list_plans()

    if not plans:
        c.print()
        c.print("  [dim]No saved plans. Start one with: /plan <description>[/]")
        c.print()
        return

    c.print()
    ui.rule("Project Plans")
    c.print()

    status_style = {
        "done": "success", "running": "brand",
        "failed": "error", "partial": "warning",
    }
    for p in plans:
        done = p["done"]
        total = p["phases"]
        pct = int(done / total * 100) if total else 0
        bar = "\u2588" * (pct // 10) + "\u2591" * (10 - pct // 10)
        sty = status_style.get(p["status"], "dim")
        c.print(f"  [{sty}]\u25cf[/] [text]{p['task'][:58]}[/]")
        c.print(f"     [dim]{bar} {pct}%  \u00b7  {done}/{total} phases  \u00b7  {p['status']}[/]")
        c.print(f"     [dim]/resume {p['id']}[/]")
        c.print()
