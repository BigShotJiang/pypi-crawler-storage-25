let busy=false,thinkingEl=null,panelActive='files',outputEntries=0;
let monacoEditor=null,monacoReady=false,currentEditorPath=null;
let term=null,termInput='';
let openFiles=[]; // Track open files for tabs
let ws=null,wsSessionId='',wsReconnectTimer=null;

const agentIcons={'Backend Architect':'fa-server','Frontend Developer':'fa-palette','DevOps Automator':'fa-rocket','QA Engineer':'fa-flask','Software Architect':'fa-sitemap','Full-Stack Developer':'fa-code','Security Reviewer':'fa-shield-halved','Data Engineer':'fa-database','Code Reviewer':'fa-eye','Laravel Architect':'fa-bolt','Systems Architect':'fa-hexagon','Database Architect':'fa-database'};

// ===== SPLIT.JS INIT =====
let centerSplit, workspaceSplit;
function initSplits(){
  // Vertical split between Center (Editor/Term) and Chat
  workspaceSplit = Split(['#centerPane', '#chatPane'], {
    sizes: [70, 30], minSize: [400, 250], gutterSize: 4,
    onDrag: () => { if(monacoEditor) monacoEditor.layout() }
  });

  // Vertical split between Editor and Terminal
  centerSplit = Split(['#editorPane', '#terminalPane'], {
    direction: 'vertical', sizes: [75, 25], minSize: [100, 30], gutterSize: 4,
    onDrag: () => { if(monacoEditor) monacoEditor.layout() }
  });
}

// ===== XTERM.JS INIT =====
function initTerminal(){
  if(term)return;
  const el=document.getElementById('terminal');
  if(!el||typeof Terminal==='undefined')return;
  term=new Terminal({cursorBlink:true,cursorStyle:'block',fontSize:12,
    fontFamily:'var(--mono)',theme:{
    background:'#000000',foreground:'#e6edf3',cursor:'#00e5a0',
    cyan:'#38bdf8',green:'#00e5a0',red:'#ef4444',yellow:'#f59e0b',
    brightBlack:'#6e7681'}});
  term.open(el);
  term.write('\x1b[38;5;47mWIDDX Terminal Ready\x1b[0m\r\n');
}

function termWriteln(text,color){
  if(!term)initTerminal();
  if(term){
    const c=color||'2';
    term.write('\x1b['+c+'m'+text+'\x1b[0m\r\n');
  }
}

function termWriteTool(name,args){
  if(!term)initTerminal();
  const iconMap={'Read':'📄','Write':'✏️','Edit':'🔧','Bash':'💻','Grep':'🔍','Glob':'📂','WebSearch':'🌐'};
  const icon=iconMap[name]||'⚡';
  const label=args&&args.file_path?String(args.file_path).split('/').pop():
    args&&args.command?String(args.command).slice(0,50):'';
  term.write('\x1b[38;5;117m'+icon+' '+name+'\x1b[0m \x1b[2m'+label+'\x1b[0m\r\n');
}

function termWriteResult(name,output){
  if(!term)return;
  const status = (output && output.error) ? '\x1b[38;5;196m✘' : '\x1b[38;5;47m✔';
  term.write('  '+status+'\x1b[0m\r\n');
}

function toggleTerminal(){
  const sizes = centerSplit.getSizes();
  const icon = document.getElementById('termToggleIcon');
  if(sizes[1] < 10){
    centerSplit.setSizes([70, 30]);
    icon.className = 'fa-solid fa-chevron-down';
  } else {
    centerSplit.setSizes([96, 4]);
    icon.className = 'fa-solid fa-chevron-up';
  }
  if(monacoEditor) setTimeout(()=>monacoEditor.layout(), 100);
}

function clearTerminal(){
  if(term){term.clear();term.write('\x1b[38;5;47mTerminal Cleared\x1b[0m\r\n')}
}

// ===== MONACO EDITOR INIT =====
function initMonaco(){
  if(monacoReady)return;
  if(typeof require==='undefined'){setTimeout(initMonaco,500);return}
  require.config({paths:{vs:'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs'}});
  require(['vs/editor/editor.main'],()=>{
    monacoReady=true;
    monacoEditor=monaco.editor.create(document.getElementById('monacoContainer'),{
      value:'', language:'plaintext', theme:'vs-dark',
      fontSize:13, fontFamily:'var(--mono)', automaticLayout:true,
      minimap:{enabled:true}, scrollBeyondLastLine:false,
      lineNumbers:'on', renderWhitespace:'selection', tabSize:2,
      padding:{top:10}
    });
    
    monacoEditor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => saveCurrentFile());
    
    monacoEditor.onDidChangeCursorPosition(e => {
      document.getElementById('editorPos').textContent = `Ln ${e.position.lineNumber}, Col ${e.position.column}`;
    });
  });
}

let editorModified=false,originalContent='';
let diffEditor=null,diffMode=false;
async function openFileInEditor(path){
  if(!monacoReady){initMonaco();setTimeout(()=>openFileInEditor(path),800);return}
  
  // Add to tabs if not exists
  if(!openFiles.includes(path)) {
    openFiles.push(path);
    renderTabs();
  }
  
  currentEditorPath=path;
  document.getElementById('editorEmpty').style.display='none';
  
  try{
    const resp=await fetch('/api/file?path='+encodeURIComponent(path));
    const data=await resp.json();
    
    const ext=path.split('.').pop().toLowerCase();
    const langMap={py:'python',js:'javascript',ts:'typescript',tsx:'typescript',jsx:'javascript',html:'html',css:'css',json:'json',md:'markdown',yml:'yaml',yaml:'yaml',xml:'xml',sql:'sql',sh:'shell'};
    const lang=langMap[ext]||'plaintext';
    
    monaco.editor.setModelLanguage(monacoEditor.getModel(),lang);
    document.getElementById('editorLang').textContent = lang.toUpperCase();
    
    monacoEditor.setValue(data.content||'');
    originalContent = data.content||'';
    editorModified=false;
    updateTabStates();
    
    // Update context pill in chat
    updateChatContext(path);
    
    monacoEditor.onDidChangeModelContent(()=>{
      if(!editorModified){
        editorModified=true;
        updateTabStates();
      }
    });
  }catch(e){termWriteln('Failed to open: '+path,'38;5;196m')}
}

function renderTabs(){
  const container = document.getElementById('tabsScroll');
  container.innerHTML = openFiles.map(path => {
    const name = path.split('/').pop();
    const active = path === currentEditorPath ? 'active' : '';
    return `<div class="editor-tab ${active}" onclick="openFileInEditor('${path}')">
      <i class="fa-solid fa-file-code"></i>
      <span>${name}</span>
      <i class="fa-solid fa-xmark close-tab" onclick="event.stopPropagation();closeTab('${path}')"></i>
    </div>`;
  }).join('');
}

function updateTabStates(){
  renderTabs(); // Simple way to refresh UI
}

function closeTab(path){
  openFiles = openFiles.filter(p => p !== path);
  if(currentEditorPath === path){
    if(openFiles.length > 0) openFileInEditor(openFiles[openFiles.length-1]);
    else {
      currentEditorPath = null;
      document.getElementById('editorEmpty').style.display = 'flex';
      monacoEditor.setValue('');
    }
  }
  renderTabs();
}

async function saveCurrentFile(){
  if(!currentEditorPath||!monacoEditor)return;
  const content=monacoEditor.getValue();
  try{
    const resp=await fetch('/api/file/save',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:currentEditorPath,content:content})});
    if(resp.ok){
      editorModified=false;
      updateTabStates();
      showToast('File saved');
    }
  }catch(e){showToast('Save failed', 3000)}
}

// ===== WEBSOCKET CONNECTION =====
function connectWebSocket(){
  if(ws&&ws.readyState===WebSocket.OPEN)return;
  const proto=location.protocol==='https:'?'wss:':'ws:';
  ws=new WebSocket(proto+'//'+location.host+'/ws/chat');
  ws.onopen=()=>{
    if(wsReconnectTimer){clearTimeout(wsReconnectTimer);wsReconnectTimer=null}
    document.querySelector('.status-item:last-child').innerHTML='<i class="fa-solid fa-circle-check"></i> Connected';
  };
  ws.onmessage=(e)=>{
    try{handleEvent(JSON.parse(e.data))}catch(err){}
  };
  ws.onclose=()=>{
    document.querySelector('.status-item:last-child').innerHTML='<i class="fa-solid fa-circle-exclamation"></i> Reconnecting';
    wsReconnectTimer=setTimeout(connectWebSocket,3000);
  };
  ws.onerror=()=>{ws.close()};
}

function getSessionId(){
  wsSessionId=sessionStorage.getItem('wid')||Date.now().toString(36);
  sessionStorage.setItem('wid',wsSessionId);
  return wsSessionId;
}

// ===== CHAT LOGIC =====
function updateChatContext(path){
  const ctx=document.getElementById('chatContext');
  if(path){
    ctx.innerHTML='<div class="context-pill"><i class="fa-solid fa-file-code"></i> '+path.split('/').pop()+'</div>';
  }else{ctx.innerHTML=''}
}

async function sendTask(){
  const input=document.getElementById('taskInput'),task=input.value.trim();
  if(!task||busy)return;
  busy=true; input.value=''; input.style.height='auto';
  const welcome=document.querySelector('.ai-welcome');
  if(welcome)welcome.remove();
  addMessage('user',task);
  thinkingEl=addThinking();
  const sid=getSessionId();
  // Try WebSocket first, fallback to SSE
  if(ws&&ws.readyState===WebSocket.OPEN){
    showCancelBtn();
    ws.send(JSON.stringify({type:'start',task,session_id:sid}));
    currentSource='ws';
  }else{
    fallbackSSE(task,sid);
  }
}

let currentSource='sse';

async function fallbackSSE(task,sessionId){
  try{
    const resp=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({task,session_id:sessionId})});
    const reader=resp.body.getReader(),decoder=new TextDecoder();let buffer='';
    while(true){
      const{done,value}=await reader.read(); if(done)break;
      buffer+=decoder.decode(value,{stream:true});
      const lines=buffer.split('\n'); buffer=lines.pop()||'';
      for(const line of lines){
        if(line.startsWith('data: ')){
          try{handleEvent(JSON.parse(line.slice(6)))}catch(e){}
        }
      }
    }
  }catch(e){addMessage('system','Error: '+e.message)}
  finally{removeThinking(); hideCancelBtn(); busy=false;}
}

function cancelTask(){
  if(ws&&ws.readyState===WebSocket.OPEN){
    ws.send(JSON.stringify({type:'cancel',session_id:wsSessionId}));
    addMessage('system','Task cancelled');
  }
  removeThinking(); hideCancelBtn(); busy=false;
}

function showCancelBtn(){
  const btn=document.getElementById('cancelBtn');
  if(btn){btn.style.display='flex';btn.style.opacity='1'}
}
function hideCancelBtn(){
  const btn=document.getElementById('cancelBtn');
  if(btn){btn.style.display='none';btn.style.opacity='0'}
}

function handleEvent(e){
  switch(e.type){
    case'start': break;
    case'analysis': addMessage('system','Analyzed: '+e.task_type); break;
    case'agents_selected': addMessage('system','Agents: '+e.agents.map(a=>a.name).join(', ')); break;
    case'tool_call': removeThinking(); termWriteTool(e.name,e.args); break;
    case'tool_result': termWriteResult(e.name,e.output); break;
    case'done': removeThinking(); hideCancelBtn(); busy=false;
      if(e.result)addMessage('assistant',e.result); if(e.files)openFilePanel(); break;
    case'error': removeThinking(); hideCancelBtn(); busy=false;
      addMessage('system','Error: '+e.text); break;
    case'cancelled': hideCancelBtn(); busy=false; break;
    case'heartbeat': break;
  }
}

function addMessage(role,text){
  const m=document.getElementById('messages'),d=document.createElement('div');
  d.className='msg '+role;
  if(role==='system') d.innerHTML=text;
  else d.textContent=text;
  m.appendChild(d); m.scrollTop=m.scrollHeight;
}

function addThinking(){
  const m=document.getElementById('messages'),d=document.createElement('div');
  d.className='thinking'; d.innerHTML='<div class="spinner"></div>';
  m.appendChild(d); m.scrollTop=m.scrollHeight; return d;
}
function removeThinking(){thinkingEl&&(thinkingEl.remove(),thinkingEl=null)}

function clearChat(){
  document.getElementById('messages').innerHTML='<div class="ai-welcome"><i class="fa-solid fa-robot"></i><h3>Chat Cleared</h3></div>';
}

// ===== FILE PANEL =====
async function openFilePanel(dir){
  setPanelTitle('Explorer');
  const body=document.getElementById('panelBody');
  body.innerHTML='<div style="padding:20px;text-align:center;color:var(--dim)">Loading...</div>';
  try{
    const resp=await fetch('/api/files?path='+encodeURIComponent(dir||'.'));
    const data=await resp.json();
    let h='<div class="file-toolbar">'
      +'<button onclick="newFileDialog()" title="New File"><i class="fa-solid fa-file-circle-plus"></i></button>'
      +'<button onclick="newFolderDialog()" title="New Folder"><i class="fa-solid fa-folder-plus"></i></button>'
      +'<button onclick="openFilePanel()" title="Refresh"><i class="fa-solid fa-arrows-rotate"></i></button>'
      +'</div>';
    
    h+='<div class="tree-item dir" onclick="openFilePanel(\'..\')"><i class="fa-solid fa-level-up-alt"></i> ..</div>';
    for(const f of data.files||[]){
      const icon=getFileIcon(f.name,f.type==='dir');
      const faClass=f.type==='dir'?'fa-folder':icon;
      const pathEsc=f.path.replace(/'/g,"\\'").replace(/"/g,'\\"');
      h+=`<div class="tree-item ${f.type}" 
        onclick="${f.type==='dir'?`openFilePanel('${pathEsc}')`:`openFileInEditor('${pathEsc}')`}"
        oncontextmenu="showContextMenu(event,'${pathEsc}',${f.type==='dir'})">
        <i class="fa-solid ${faClass}"></i> <span>${f.name}</span>
      </div>`;
    }
    body.innerHTML=h;
    document.getElementById('statusCwd').innerHTML='<i class="fa-regular fa-folder-open"></i> '+(data.cwd||'--');
  }catch(e){body.innerHTML='<div class="error">Error loading files</div>'}
}

function setPanelTitle(t){document.getElementById('panelTitle').textContent=t}

// ===== OVERLAY / DASHBOARD =====
function showDashboard(){
  document.getElementById('dashboardOverlay').style.display = 'flex';
  loadDashboardData();
}
function hideDashboard(){
  document.getElementById('dashboardOverlay').style.display = 'none';
}
async function loadDashboardData(){
  try{
    const [agentResp,skillResp]=await Promise.all([fetch('/api/agents'),fetch('/api/skills')]);
    const agents=await agentResp.json(),skills=await skillResp.json();
    
    document.getElementById('agentCount').textContent='('+agents.length+')';
    document.getElementById('agentGrid').innerHTML = agents.map(a => `
      <div class="agent-card">
        <div class="agent-name">${a.name}</div>
        <div class="agent-desc">${a.desc}</div>
      </div>
    `).join('');
    
    document.getElementById('skillCount').textContent='('+skills.length+')';
    document.getElementById('skillGrid').innerHTML = skills.map(s => `
      <span class="skill-tag">${s.name || s[0]}</span>
    `).join('');
  }catch(e){}
}

// ===== UTILS =====
function showToast(msg,duration=3000){
  const t=document.getElementById('toast');
  t.textContent=msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),duration);
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded',()=>{
  initSplits();
  initTerminal();
  initMonaco();
  openFilePanel();
  connectWebSocket();
  checkSetup();
  loadGitStatus();
  setInterval(loadGitStatus, 15000);
  loadChatSessions();
  
  // Close context menu on click outside
  document.addEventListener('click', (e) => {
    const cm = document.getElementById('contextMenu');
    if (cm && !cm.contains(e.target)) cm.style.display = 'none';
  });
  
  // Activity bar switching
  document.querySelectorAll('.activity-icon').forEach(el=>{
    el.addEventListener('click',()=>{
      const panel=el.dataset.panel;
      document.querySelectorAll('.activity-icon').forEach(a=>a.classList.remove('active'));
      el.classList.add('active');
      
      if(panel === 'chat') {
        document.getElementById('taskInput').focus();
      } else if(panel === 'settings') {
        document.getElementById('setupOverlay').style.display = 'flex';
        loadConfigState();
      } else {
        panelActive = panel;
        if(panel==='files') openFilePanel();
        // Add search/agents panels if needed
      }
    });
  });

  // Input auto-resize
  const inp = document.getElementById('taskInput');
  inp.addEventListener('input', () => {
    inp.style.height = 'auto';
    inp.style.height = (inp.scrollHeight) + 'px';
  });
  inp.addEventListener('keydown', e => {
    if(e.key==='Enter' && !e.shiftKey) {
      e.preventDefault();
      sendTask();
    }
  });
});

// ===== FILE OPERATIONS =====
async function newFileDialog(){
  const name=prompt('Enter file name:','newfile.txt');
  if(!name)return;
  const path='./'+name;
  try{
    const resp=await fetch('/api/file/create',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:path})});
    const data=await resp.json();
    if(!resp.ok)throw new Error(data.error||'Create failed');
    showToast('File created');
    openFileInEditor(data.path);
    openFilePanel();
  }catch(e){showToast(e.message,3000)}
}

async function newFolderDialog(){
  const name=prompt('Enter folder name:','newfolder');
  if(!name)return;
  const path='./'+name;
  try{
    const resp=await fetch('/api/folder/create',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:path})});
    const data=await resp.json();
    if(!resp.ok)throw new Error(data.error||'Create failed');
    showToast('Folder created');
    openFilePanel();
  }catch(e){showToast(e.message,3000)}
}

// ===== SETUP / CONFIG =====
async function checkSetup(){
  try{
    const resp=await fetch('/api/config/status');
    const data=await resp.json();
    if(data.needs_setup){
      // Show setup overlay with slight delay
      setTimeout(()=>{
        document.getElementById('setupOverlay').style.display='flex';
        loadConfigState();
      },800);
    }
  }catch(e){}
}

async function loadConfigState(){
  try{
    const resp=await fetch('/api/config');
    const data=await resp.json();
    if(data.deepseek&&data.deepseek.configured){
      document.getElementById('deepseekStatus').textContent='Configured: '+data.deepseek.preview;
      document.getElementById('deepseekStatus').className='setup-status success';
    }
    if(data.google&&data.google.configured){
      document.getElementById('googleStatus').textContent='Configured: '+data.google.preview;
      document.getElementById('googleStatus').className='setup-status success';
    }
  }catch(e){}
}

async function saveKey(provider){
  const inputId=provider==='deepseek'?'deepseekKey':'googleKey';
  const btnId=provider==='deepseek'?'deepseekSaveBtn':'googleSaveBtn';
  const statusId=provider==='deepseek'?'deepseekStatus':'googleStatus';
  const apiKey=document.getElementById(inputId).value.trim();
  if(!apiKey||apiKey.length<10){
    document.getElementById(statusId).textContent='Invalid key (min 10 characters)';
    document.getElementById(statusId).className='setup-status error';
    return;
  }
  const btn=document.getElementById(btnId);
  btn.disabled=true; btn.textContent='Saving...';
  try{
    const resp=await fetch('/api/config/key',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({provider,api_key:apiKey})});
    const data=await resp.json();
    if(resp.ok){
      document.getElementById(statusId).textContent='Saved! '+data.preview;
      document.getElementById(statusId).className='setup-status success';
      document.getElementById(inputId).value='';
    }else{
      document.getElementById(statusId).textContent='Error: '+(data.error||'Failed');
      document.getElementById(statusId).className='setup-status error';
    }
  }catch(e){
    document.getElementById(statusId).textContent='Connection error';
    document.getElementById(statusId).className='setup-status error';
  }
  btn.disabled=false; btn.textContent='Save';
}

function closeSetup(){
  document.getElementById('setupOverlay').style.display='none';
  fetch('/api/status').then(r=>r.json()).then(d=>{
    const badge=document.getElementById('providerBadge');
    if(badge&&d.providers&&d.providers.length){
      badge.innerHTML='<i class="fa-solid fa-brain"></i> '+d.providers.join(', ');
    }
  }).catch(()=>{});
}

// ===== GIT STATUS =====
async function loadGitStatus(){
  try{
    const resp=await fetch('/api/git/status');
    const data=await resp.json();
    if(data.branch){
      document.getElementById('gitBranch').textContent=data.branch;
      document.getElementById('gitDirty').style.display=data.dirty?'inline':'none';
    }
  }catch(e){}
}

// ===== QUICK ACTIONS =====
function sendQuick(task){
  document.getElementById('taskInput').value=task;
  sendTask();
}

// ===== CHAT HISTORY =====
let chatSessions={};
function loadChatSessions(){
  try{chatSessions=JSON.parse(localStorage.getItem('widdxSessions')||'{}')}catch(e){chatSessions={}}
}
function saveCurrentSession(){
  const msgs=document.getElementById('messages');
  const history=[];
  msgs.querySelectorAll('.msg').forEach(m=>{
    history.push({role:m.classList.contains('user')?'user':m.classList.contains('assistant')?'assistant':'system',text:m.textContent.slice(0,2000)});
  });
  chatSessions[getSessionId()]={updated:Date.now(),messages:history.slice(-20)};
  localStorage.setItem('widdxSessions',JSON.stringify(chatSessions));
}
// Save session on page unload
window.addEventListener('beforeunload',saveCurrentSession);

// ===== CONTEXT MENU =====
let ctxTargetPath='';
function showContextMenu(e,path,isDir){
  e.preventDefault(); e.stopPropagation();
  ctxTargetPath=path;
  const cm=document.getElementById('contextMenu');
  cm.style.display='block';
  cm.style.left=(e.clientX+5)+'px';
  cm.style.top=(e.clientY+5)+'px';
  // Hide open for dirs, adjust rename for dirs
  cm.querySelector('.ctx-item:nth-child(1)').style.display=isDir?'none':'flex';
  cm.querySelector('.ctx-item:nth-child(2)').style.display='flex';
}
function ctxOpenFile(){ if(ctxTargetPath){openFileInEditor(ctxTargetPath)} hideContextMenu() }
function ctxRename(){ if(ctxTargetPath){renameDialog(ctxTargetPath)} hideContextMenu() }
function ctxDelete(){ if(ctxTargetPath){deleteConfirm(ctxTargetPath)} hideContextMenu() }
function hideContextMenu(){ document.getElementById('contextMenu').style.display='none' }

async function renameDialog(path){
  const oldName=path.split('/').pop();
  const newName=prompt('Rename '+oldName+':',oldName);
  if(!newName||newName===oldName)return;
  const parent=path.substring(0,path.lastIndexOf('/')+1);
  const newPath=parent+newName;
  try{
    const resp=await fetch('/api/file/rename',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({old_path:path,new_path:newPath})});
    const data=await resp.json();
    if(!resp.ok)throw new Error(data.error);
    showToast('Renamed to '+newName);
    if(currentEditorPath===path)openFileInEditor(newPath);
    openFilePanel();
  }catch(e){showToast(e.message,3000)}
}

async function deleteConfirm(path){
  const name=path.split('/').pop();
  if(!confirm('Delete '+name+'?'))return;
  try{
    const resp=await fetch('/api/file/delete',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:path})});
    if(!resp.ok)throw new Error((await resp.json()).error);
    showToast('Deleted');
    if(currentEditorPath===path){closeTab(path)}
    openFilePanel();
  }catch(e){showToast(e.message,3000)}
}

// ===== DIFF VIEWER =====
function toggleDiff(){
  if(!monacoReady||!currentEditorPath)return;
  if(diffMode){ exitDiffMode(); return }
  
  const modified=monacoEditor.getValue();
  if(modified===originalContent){ showToast('No changes to compare'); return }
  
  const container=document.getElementById('monacoContainer');
  const hint=document.createElement('div');
  hint.className='diff-mode-hint';
  hint.id='diffHint';
  hint.innerHTML='<span>Comparing: original vs modified</span><button onclick="exitDiffMode()"><i class="fa-solid fa-xmark"></i> Close</button>';
  container.parentNode.insertBefore(hint,container);
  
  // Hide normal editor, create diff editor
  monacoEditor.getDomNode().style.display='none';
  diffEditor=monaco.editor.createDiffEditor(container,{
    theme:'vs-dark',fontSize:13,fontFamily:'var(--mono)',automaticLayout:true,
    minimap:{enabled:false},readOnly:true,renderSideBySide:true,
    originalEditable:false
  });
  const lang=monacoEditor.getModel().getLanguageId();
  diffEditor.setModel({
    original:monaco.editor.createModel(originalContent,lang),
    modified:monaco.editor.createModel(modified,lang)
  });
  diffMode=true;
}

function exitDiffMode(){
  if(diffEditor){diffEditor.dispose();diffEditor=null}
  document.getElementById('diffHint')?.remove();
  if(monacoEditor)monacoEditor.getDomNode().style.display='';
  diffMode=false;
}

function getFileIcon(name,isDir){
  if(isDir) return 'fa-folder';
  const ext=name.split('.').pop().toLowerCase();
  const map={py:'fa-python',pyw:'fa-python',js:'fa-js',mjs:'fa-js',jsx:'fa-js',ts:'fa-js',tsx:'fa-js',
    html:'fa-code',css:'fa-css',json:'fa-json',md:'fa-markdown',yml:'fa-css',yaml:'fa-css',
    sql:'fa-database',sh:'fa-terminal',bash:'fa-terminal',go:'fa-code',rs:'fa-code',php:'fa-code'};
  return map[ext]||'fa-file-code';
}
