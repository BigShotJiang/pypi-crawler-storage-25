"""Self-learning ledger for recurring task patterns and draft assets."""
from __future__ import annotations

import json
from pathlib import Path


class SelfLearningEngine:
    """Records task outcomes and promotes repeated patterns into draft assets."""

    DOMAIN_KEYWORDS = {
        "python": {"python", "pytest", "fastapi", "django", "flask"},
        "typescript": {"typescript", "ts", "tsx", "react", "nextjs", "next"},
        "javascript": {"javascript", "node", "express", "js", "jsx"},
        "php": {"php", "laravel", "artisan", "blade"},
        "docker": {"docker", "dockerfile", "compose", "container"},
        "database": {"postgres", "postgresql", "mysql", "sqlite", "database", "sql"},
        "mcp": {"mcp", "model context protocol"},
        "frontend": {"frontend", "ui", "css", "html", "react", "vue"},
        "backend": {"backend", "api", "server", "auth"},
    }

    EXTENSION_DOMAINS = {
        ".py": "python",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".js": "javascript",
        ".jsx": "javascript",
        ".php": "php",
        ".sql": "database",
        ".html": "frontend",
        ".css": "frontend",
        ".scss": "frontend",
        ".dockerfile": "docker",
    }

    def __init__(self, memory_store, config: dict | None = None) -> None:
        self._memory = memory_store
        sl_config = (config or {}).get("self_learning", {})
        self._enabled = sl_config.get("enabled", True)
        self._draft_threshold = sl_config.get("draft_threshold", 3)

    def record_task(
        self,
        task_id: str,
        command: str,
        result_summary: str,
        provider: str,
        files_touched: list[str],
        tool_calls: int,
        success: bool,
        complexity: int = 1,
    ) -> None:
        """Record one task outcome and update recurring pattern candidates."""
        if not self._enabled:
            return

        task_type = self.infer_task_type(command)
        domains = self.infer_domains(command, files_touched)
        self._memory.log_learning_event(
            task_id=task_id,
            task_text=command,
            task_type=task_type,
            provider=provider,
            success=success,
            complexity=complexity,
            tool_calls=tool_calls,
            files_touched_json=json.dumps(files_touched),
            domains_json=json.dumps(domains),
            result_summary=result_summary,
        )
        if not success:
            return

        for domain in domains:
            metadata = json.dumps({
                "task_type": task_type,
                "provider": provider,
                "files_touched": files_touched[:10],
            })
            domain_pattern = self._memory.upsert_learning_pattern(
                fingerprint=f"domain::{domain}",
                pattern_type="domain",
                scope=domain,
                summary=f"Repeated successful tasks involving {domain}.",
                source_task_id=task_id,
                metadata_json=metadata,
            )
            workflow_pattern = self._memory.upsert_learning_pattern(
                fingerprint=f"workflow::{task_type}::{domain}",
                pattern_type="workflow",
                scope=f"{task_type}:{domain}",
                summary=f"Successful {task_type} workflow repeatedly observed for {domain}.",
                source_task_id=task_id,
                metadata_json=metadata,
            )
            self._promote_domain_assets(domain, domain_pattern)
            self._promote_workflow_asset(task_type, domain, workflow_pattern)

    def dashboard(self, limit: int = 10) -> dict:
        """Return a compact dashboard for REPL/UI inspection."""
        return {
            "events": self._memory.recent_learning_events(limit),
            "patterns": self._memory.list_learning_patterns(limit),
            "assets": self._memory.list_learning_assets(limit),
        }

    @classmethod
    def infer_task_type(cls, command: str) -> str:
        lowered = command.lower()
        if any(kw in lowered for kw in ["build", "create", "generate", "implement"]):
            return "build"
        if any(kw in lowered for kw in ["fix", "debug", "resolve", "repair"]):
            return "fix"
        if any(kw in lowered for kw in ["improve", "optimize", "refactor"]):
            return "improve"
        if any(kw in lowered for kw in ["design", "plan", "review"]):
            return "design"
        return "general"

    @classmethod
    def infer_domains(cls, command: str, files_touched: list[str]) -> list[str]:
        lowered = command.lower()
        domains: set[str] = set()

        for domain, keywords in cls.DOMAIN_KEYWORDS.items():
            if any(keyword in lowered for keyword in keywords):
                domains.add(domain)

        for file_path in files_touched:
            path = Path(file_path)
            suffix = path.suffix.lower()
            ext_domain = cls.EXTENSION_DOMAINS.get(suffix)
            if isinstance(ext_domain, str):
                domains.add(ext_domain)
            if path.name.lower() == "dockerfile":
                domains.add("docker")

        if not domains and files_touched:
            domains.add("project")
        if not domains:
            domains.add("general")

        return sorted(domains)

    def _promote_domain_assets(self, domain: str, pattern: dict | None) -> None:
        if pattern is None or pattern.get("evidence_count", 0) < self._draft_threshold:
            return
        count = int(pattern.get("evidence_count", 0))
        self._memory.create_learning_asset(
            asset_type="skill",
            name=f"auto-skill-{domain}",
            summary=f"Draft skill candidate for {domain} based on {count} successful tasks.",
            status="draft",
            source_fingerprint=str(pattern.get("fingerprint", "")),
        )
        self._memory.create_learning_asset(
            asset_type="agent",
            name=f"auto-agent-{domain}",
            summary=f"Draft agent candidate for {domain} based on {count} successful tasks.",
            status="draft",
            source_fingerprint=str(pattern.get("fingerprint", "")),
        )

    def _promote_workflow_asset(self, task_type: str, domain: str, pattern: dict | None) -> None:
        if pattern is None or pattern.get("evidence_count", 0) < self._draft_threshold:
            return
        count = int(pattern.get("evidence_count", 0))
        self._memory.create_learning_asset(
            asset_type="workflow",
            name=f"auto-workflow-{task_type}-{domain}",
            summary=(
                f"Draft workflow candidate for {task_type} tasks in {domain}, "
                f"observed {count} times."
            ),
            status="draft",
            source_fingerprint=str(pattern.get("fingerprint", "")),
        )

    @property
    def is_enabled(self) -> bool:
        return bool(self._enabled)


__all__ = ["SelfLearningEngine"]
