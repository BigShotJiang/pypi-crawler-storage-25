"""File operations tools — read, write, edit."""
from __future__ import annotations

import difflib
import os
import tempfile
from pathlib import Path

_PROJECT_ROOT: Path | None = None


def _safe_resolve(p: Path) -> Path:
    """Resolve a path safely, handling UNC path PermissionError on Windows."""
    try:
        return p.expanduser().resolve()
    except (PermissionError, OSError):
        return p.expanduser().absolute()


def _norm_path(p: Path) -> str:
    """Normalize a path for cross-platform prefix comparison (case-insensitive on Windows)."""
    raw = str(_safe_resolve(p))
    if os.name == "nt":
        raw = raw.lower().replace("\\\\", "\\")
    return raw.rstrip("\\").rstrip("/")


def _get_project_root() -> Path:
    """Detect project root from CWD or a known sentinel file."""
    global _PROJECT_ROOT
    if _PROJECT_ROOT is not None:
        return _PROJECT_ROOT
    root = _safe_resolve(Path.cwd())
    for parent in [root, *root.parents]:
        if (parent / ".git").exists() or (parent / ".widdx").exists():
            _PROJECT_ROOT = parent
            return _PROJECT_ROOT
    _PROJECT_ROOT = root
    return _PROJECT_ROOT


def _is_path_safe(path: Path) -> bool:
    """Return True if the path is safe to read or write.

    Autonomous mode still needs real file access, but the default boundary is:
    project root, ~/.widdx, and the OS temp directory.  Set
    WIDDX_ALLOW_OUTSIDE_PROJECT=1 to opt into wider filesystem edits.
    """
    resolved = _safe_resolve(path)
    if os.environ.get("WIDDX_ALLOW_OUTSIDE_PROJECT", "").lower() in {"1", "true", "yes"}:
        return True

    resolved_norm = _norm_path(resolved)
    home_widdx = _norm_path(Path.home() / ".widdx")
    if resolved_norm == home_widdx or resolved_norm.startswith(home_widdx + os.sep):
        return True

    project_root = _get_project_root()
    try:
        resolved.relative_to(project_root)
        return True
    except ValueError:
        pass

    temp_root = _safe_resolve(Path(tempfile.gettempdir()))
    try:
        resolved.relative_to(temp_root)
        return True
    except ValueError:
        return False


def tool_read_file(file_path: str, start_line: int = 0, end_line: int = -1) -> dict:
    """Read a file with optional line range."""
    path = _safe_resolve(Path(file_path))
    if not _is_path_safe(path):
        return {"error": "Path traversal blocked: file is outside the project root"}
    if not path.exists():
        return {"error": f"File not found: {file_path}"}
    if path.stat().st_size > 10 * 1024 * 1024:
        return {"error": "File exceeds 10 MB limit"}
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return {"error": "File is not valid UTF-8 text"}
    lines = content.splitlines()
    if end_line == -1:
        end_line = len(lines)
    selected = lines[start_line:end_line]
    return {
        "file_path": str(path),
        "total_lines": len(lines),
        "start_line": start_line,
        "end_line": min(end_line, len(lines)),
        "content": "\n".join(selected),
    }


def tool_write_file(file_path: str, content: str, overwrite: bool = False) -> dict:
    """Create or overwrite a file.

    By default refuses to overwrite existing files (safe mode).
    Pass overwrite=True to replace an existing file completely —
    useful when rewriting a module from scratch is cleaner than patching.
    """
    path = _safe_resolve(Path(file_path))
    if not _is_path_safe(path):
        return {"error": "Path traversal blocked: file is outside the project root"}
    if path.exists() and not overwrite:
        return {"error": f"File already exists; use edit for modifications or set overwrite=true: {file_path}"}
    path.parent.mkdir(parents=True, exist_ok=True)
    existed = path.exists()
    path.write_text(content, encoding="utf-8")
    action = "overwritten" if existed else "created"
    return {"file_path": str(path), "written": len(content), "status": action}


def tool_edit_file(file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> dict:
    """Edit an existing file using exact string replacement.

    If ``old_string`` is not found verbatim, a fuzzy match is attempted using
    difflib.  When a close-enough match exists (ratio ≥ 0.85), the error
    message includes the nearest matching block so the LLM can correct its
    ``old_string`` and retry without guessing.
    """
    path = _safe_resolve(Path(file_path))
    if not _is_path_safe(path):
        return {"error": "Path traversal blocked: file is outside the project root"}
    if not path.exists():
        return {"error": f"File not found: {file_path}"}
    content = path.read_text(encoding="utf-8")
    count = content.count(old_string)
    if count == 0:
        suggestion = _find_fuzzy_match(old_string, content)
        if suggestion is not None:
            return {
                "error": "old_string not found in file",
                "fuzzy_match": suggestion,
                "hint": (
                    "old_string did not match exactly. "
                    "The closest block found is in 'fuzzy_match'. "
                    "Use that exact text as old_string and retry."
                ),
            }
        return {"error": "old_string not found in file"}
    if count > 1 and not replace_all:
        return {"error": f"old_string matches {count} locations; set replace_all=true or provide more context"}
    new_content = content.replace(old_string, new_string) if replace_all else content.replace(old_string, new_string, 1)
    path.write_text(new_content, encoding="utf-8")
    return {"file_path": str(path), "replacements": count if replace_all else 1, "status": "edited"}


def tool_search_replace(file_path: str, search: str, replace: str) -> dict:
    """Replace *search* block with *replace* block using context-aware matching.

    Unlike ``tool_edit_file`` which matches a short ``old_string`` verbatim,
    this tool matches the full *search* block (including surrounding context
    lines) for unambiguous replacement across multiple hunks.

    The *search* block should include enough surrounding context lines to
    uniquely identify the location.  If the exact block is not found, a fuzzy
    match is attempted.  Returns an error with a ``fuzzy_match`` hint if the
    best fuzzy match is below the 0.85 threshold.

    On success, returns the file content before and after the change (for diff
    display) along with the number of replacements performed.
    """
    path = _safe_resolve(Path(file_path))
    if not _is_path_safe(path):
        return {"error": "Path traversal blocked: file is outside the project root"}
    if not path.exists():
        return {"error": f"File not found: {file_path}"}
    content = path.read_text(encoding="utf-8")

    count = content.count(search)
    if count == 0:
        suggestion = _find_fuzzy_match(search, content)
        if suggestion is not None:
            return {
                "error": "search block not found in file",
                "fuzzy_match": suggestion,
                "hint": (
                    "search block did not match exactly. "
                    "The closest block found is in 'fuzzy_match'. "
                    "Use that exact text as the search block and retry."
                ),
            }
        return {"error": "search block not found in file"}
    if count > 1:
        return {
            "error": f"search block matches {count} locations; add more context lines to disambiguate",
        }

    new_content = content.replace(search, replace, 1)
    path.write_text(new_content, encoding="utf-8")
    return {
        "file_path": str(path),
        "replacements": 1,
        "status": "edited",
        "_diff_old": content,
        "_diff_new": new_content,
    }


def _find_fuzzy_match(needle: str, haystack: str, threshold: float = 0.85) -> str | None:
    """Find the closest matching block in ``haystack`` for ``needle``.

    Splits the haystack into overlapping windows of the same line-count as the
    needle, scores each with SequenceMatcher, and returns the best match if its
    ratio meets the threshold.  Returns ``None`` if nothing is close enough.
    """
    needle_lines = needle.splitlines()
    haystack_lines = haystack.splitlines()
    window = len(needle_lines)

    if window == 0 or window > len(haystack_lines):
        # Single-string comparison for short needles
        ratio = difflib.SequenceMatcher(None, needle, haystack).ratio()
        return haystack if ratio >= threshold else None

    best_ratio = 0.0
    best_block: str | None = None

    for i in range(len(haystack_lines) - window + 1):
        candidate_lines = haystack_lines[i : i + window]
        candidate = "\n".join(candidate_lines)
        ratio = difflib.SequenceMatcher(None, needle, candidate).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_block = candidate

    return best_block if best_ratio >= threshold else None
