"""Search tools — grep and glob."""
from __future__ import annotations

import re
from pathlib import Path


def tool_grep(pattern: str, directory: str = ".", include: str = "", max_results: int = 50) -> dict:
    """Fast regex search across file contents."""
    root = Path(directory).expanduser().resolve()
    if not root.exists():
        return {"error": f"Directory not found: {directory}"}
    try:
        regex = re.compile(pattern)
    except re.error as exc:
        return {"error": f"Invalid regex: {exc}"}

    matches: list[dict] = []
    glob_pattern = include or "*"
    for file_path in root.rglob(glob_pattern):
        if len(matches) >= max_results:
            break
        if file_path.is_dir():
            continue
        if any(p.startswith(".") for p in file_path.parts):
            continue
        try:
            text = file_path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for idx, line in enumerate(text.splitlines(), start=1):
            if regex.search(line):
                matches.append({"file": str(file_path), "line": idx, "text": line.strip()[:200]})
                if len(matches) >= max_results:
                    break
    return {"pattern": pattern, "matches": matches, "count": len(matches)}


def tool_glob(pattern: str, directory: str = ".") -> dict:
    """Fast file-path pattern matching."""
    root = Path(directory).expanduser().resolve()
    if not root.exists():
        return {"error": f"Directory not found: {directory}"}
    results = []
    for file_path in root.rglob(pattern):
        if any(p.startswith(".") for p in file_path.parts):
            continue
        results.append(str(file_path))
    results.sort()
    return {"pattern": pattern, "files": results[:50], "count": len(results)}
