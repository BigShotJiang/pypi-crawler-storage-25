"""Shell execution tool — safe command execution with blacklist-based security.

Philosophy: WIDDX is a software engineering AI. It needs real shell access to
build, test, deploy, and debug. We block only truly dangerous system-level
commands and shell-injection patterns. The user-facing permission system
is the primary gate — it asks before every command execution.
"""
from __future__ import annotations

import shlex
import subprocess
import sys
import time

# Only system-destroying or privilege-escalation commands are blocked.
# Everything else a software engineer might need (rm, curl, chmod, etc.)
# is allowed — the permission system asks the user for approval first.
FORBIDDEN = {
    "shutdown",
    "reboot",
    "halt",
    "poweroff",
    "mkfs",
    "dd",
    "format",
    "sudo",
    "su",
}


def _has_shell_chaining(command: str) -> bool:
    """Check for shell chaining/piping metacharacters outside of quotes.

    The AI can issue separate tool calls for each command — there is no
    legitimate reason for chaining. Blocking chaining prevents even a
    compromised prompt from injecting extra commands via:
    - ``&&`` / ``||`` / ``|`` / ``;`` — standard chaining
    - ``& `` (background operator at end or between commands)
    - ```command` `` — backtick command substitution
    - ``$(command)`` — dollar-paren command substitution
    - ``\n`` / ``\r`` — newline injection into single-line commands

    Redirect operators that look like chaining to a naive scan are
    explicitly allowed:
    - ``2>&1``, ``>&2``, ``>file 2>&1`` — fd redirect (``&`` followed by a digit or ``>``)
    """
    in_single = False
    in_double = False
    i = 0
    while i < len(command):
        ch = command[i]
        if ch == "'" and not in_double:
            in_single = not in_single
        elif ch == '"' and not in_single:
            in_double = not in_double
        elif not in_single and not in_double:
            if ch == "&":
                # Allow redirect: 2>&1 (N>&M) or >& (redirect to fd)
                next_ch = command[i + 1] if i + 1 < len(command) else ""
                if next_ch.isdigit() or next_ch == ">":
                    i += 1
                    continue
                return True
            if ch in ("|", ";"):
                return True
            if ch in ("\n", "\r"):
                return True
            if ch == "`":
                return True
            if ch == "$" and i + 1 < len(command) and command[i + 1] == "(":
                return True
        i += 1
    return False


def _extract_base_command(command: str) -> str:
    """Extract the base command name from a shell command string."""
    try:
        tokens = shlex.split(command, posix=(sys.platform != "win32"))
        if tokens:
            return tokens[0].split("/")[-1].split("\\")[-1].lower()
    except ValueError:
        pass
    return command.strip().split()[0].lower() if command.strip() else ""


def _rewrite_cd_chain(command: str, working_dir: str) -> tuple[str, str]:
    """Detect ``cd X && Y`` / ``cd X & Y`` patterns and extract the working dir.

    Returns ``(rewritten_command, new_working_dir)``.  If no ``cd &&``
    pattern is found *command* and *working_dir* are returned unchanged.
    """
    import re
    m = re.match(
        r'^\s*cd\s+([^&]+)\s*&&\s*(.+)$',
        command,
        re.IGNORECASE,
    )
    if m:
        new_dir = m.group(1).strip().strip("'\"")
        rest = m.group(2).strip()
        return rest, new_dir
    return command, working_dir


def tool_shell(command: str, working_dir: str = ".", timeout_sec: int = 120,
               session_approved: bool = False) -> dict:
    """Execute a shell command and return result.

    Security model:
    - Blocks shell chaining/pipe metacharacters (``&&``, ``||``, ``;``) unless
      session_approved=True, in which case pipes (``|``) and redirections are
      allowed.
    - Blocks a small set of system-destroying commands (shutdown, mkfs, dd…).
    - On Unix: ``shell=False`` with ``shlex.split`` prevents injection.
    - On Windows: ``cmd /c <command>`` with ``shell=False`` keeps built-ins
      working without exposing shell-injection via metacharacters.
    - The permission system prompts the user before every execution — this
      is the primary safety measure.

    Auto-detects ``cd X && Y`` patterns and rewrites them to just ``Y``
    with ``working_dir=X``.  This lets AI agents use natural ``cd &&``
    idioms without triggering shell-chaining blocks.
    """
    if not command or not command.strip():
        return {"error": "Empty command"}

    # Rewrite cd X && Y → Y (using working_dir)
    command, working_dir = _rewrite_cd_chain(command, working_dir)

    if not session_approved and _has_shell_chaining(command):
        return {"error": "Command chaining (&&, ||, |, ;, &) is not allowed"}

    base = _extract_base_command(command)

    if base in FORBIDDEN:
        return {"error": f"Command '{base}' is forbidden for safety reasons"}

    start = time.perf_counter()
    try:
        if sys.platform == "win32":
            args = ["cmd", "/c", command]
            result = subprocess.run(
                args,
                shell=False,
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
        else:
            try:
                args = shlex.split(command)
            except ValueError as exc:
                return {"error": f"Could not parse command: {exc}"}
            result = subprocess.run(
                args,
                shell=False,
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
    except subprocess.TimeoutExpired:
        return {"error": f"Command timed out after {timeout_sec}s", "timeout_sec": timeout_sec}
    except OSError as e:
        return {"error": f"Command failed: {e}"}

    elapsed_ms = int((time.perf_counter() - start) * 1000)
    stdout = result.stdout[-4000:] if len(result.stdout) > 4000 else result.stdout
    stderr = result.stderr[-2000:] if len(result.stderr) > 2000 else result.stderr
    return {
        "command": command,
        "exit_code": result.returncode,
        "stdout": stdout,
        "stderr": stderr,
        "truncated": len(result.stdout) > 4000 or len(result.stderr) > 2000,
        "latency_ms": elapsed_ms,
    }
