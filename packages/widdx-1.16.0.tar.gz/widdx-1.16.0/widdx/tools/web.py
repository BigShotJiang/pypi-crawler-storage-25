"""Web search tool using DuckDuckGo with retry and multiple fallbacks."""
from __future__ import annotations

import json
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)

_USER_AGENT = "WIDDX-CLI/1.3"

# Retry configuration
_MAX_RETRIES = 3
_RETRY_BACKOFF = [1.0, 2.0, 4.0]  # seconds


def tool_web_search(query: str, max_results: int = 5) -> dict:
    """Search the web and return text results.

    Uses DuckDuckGo Instant Answer API with retry, falls back to
    DuckDuckGo Lite HTML search, then augmented query, then a
    helpful message.
    """
    # Try 1: DDG Instant Answer API with retry
    results, source = _search_duckduckgo(query, max_results)

    # Try 2: DDG Lite HTML search
    if not results:
        results, source = _search_duckduckgo_lite(query, max_results)

    # Try 3: Augmented query (add site: hints for technical queries)
    if not results:
        augmented = f"{query} site:stackoverflow.com OR site:github.com"
        results, source = _search_duckduckgo(augmented, max_results)
        if results:
            source = "duckduckgo-augmented"

    if not results:
        return {
            "query": query,
            "results": [{
                "title": f"Search: {query}",
                "snippet": (
                    "No results found for this query. Try a different search "
                    "or configure a search MCP server with `/mcp add search`.\n"
                    f"Manual search: https://duckduckgo.com/?q={urllib.parse.quote(query)}"
                ),
            }],
            "count": 1,
            "source": "none",
        }

    return {"query": query, "results": results, "count": len(results), "source": source}


# ── DDG Instant Answer API ──────────────────────────────────────────────────

def _search_duckduckgo(query: str, max_results: int) -> tuple[list[dict], str]:
    """Search DuckDuckGo Instant Answer API with retry and backoff."""
    url = f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}&format=json&no_html=1"

    for attempt in range(_MAX_RETRIES):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
            with urllib.request.urlopen(req, timeout=15) as resp:
                raw = resp.read()
            data = json.loads(raw)
            results = _parse_ddg_response(data, max_results)
            return results, "duckduckgo"
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                logger.debug("DDG rate-limited, attempt %d", attempt + 1)
            elif 500 <= exc.code < 600:
                logger.debug("DDG server error %d, attempt %d", exc.code, attempt + 1)
            else:
                logger.debug("DDG HTTP %d — not retrying", exc.code)
                return [], ""
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            logger.debug("DDG network error (attempt %d): %s", attempt + 1, exc)
        except json.JSONDecodeError as exc:
            logger.debug("DDG returned invalid JSON: %s", exc)
            return [], ""

        if attempt < _MAX_RETRIES - 1:
            time.sleep(_RETRY_BACKOFF[attempt])

    return [], ""


def _parse_ddg_response(data: dict, max_results: int) -> list[dict]:
    """Parse DuckDuckGo Instant Answer API response into results list."""
    results: list[dict] = []

    abstract = data.get("AbstractText", "")
    if abstract:
        abstract_url = data.get("AbstractURL", "")
        results.append({
            "title": abstract_url or "Abstract",
            "snippet": abstract[:500],
        })

    for item in data.get("RelatedTopics", [])[:max_results]:
        if "Text" in item:
            results.append({
                "title": item.get("FirstURL", ""),
                "snippet": item["Text"][:300],
            })
        elif "Topics" in item:
            for sub in item.get("Topics", [])[:3]:
                if "Text" in sub:
                    results.append({
                        "title": sub.get("FirstURL", ""),
                        "snippet": sub["Text"][:300],
                    })

    return results


# ── DDG Lite HTML fallback ───────────────────────────────────────────────────

def _search_duckduckgo_lite(query: str, max_results: int) -> tuple[list[dict], str]:
    """Fallback: scrape DuckDuckGo Lite HTML results.

    DuckDuckGo Lite (lite.duckduckgo.com) returns a simple HTML page
    that is stable enough for basic regex parsing without external deps.
    """
    url = f"https://lite.duckduckgo.com/lite/?q={urllib.parse.quote(query)}"

    for attempt in range(2):  # Fewer retries for Lite
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
            with urllib.request.urlopen(req, timeout=15) as resp:
                html = resp.read().decode("utf-8", errors="replace")
            break
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError):
            if attempt == 0:
                time.sleep(1.0)
            else:
                return [], ""

    if not html:
        return [], ""

    results: list[dict] = []

    # Lite results are in <tr> blocks with class containing "result"
    # Each block has a <a> link and a <td class="result-snippet">
    blocks = re.findall(
        r'<tr[^>]*class="[^"]*result[^"]*"[^>]*>(.*?)</tr>',
        html,
        re.DOTALL,
    )

    for block in blocks[:max_results]:
        # Extract link and title
        link_match = re.search(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', block, re.DOTALL)
        if not link_match:
            continue
        href = link_match.group(1)
        title = re.sub(r'<[^>]+>', '', link_match.group(2)).strip()

        # Extract snippet
        snippet_match = re.search(
            r'class="result-snippet"[^>]*>(.*?)</td>',
            block,
            re.DOTALL,
        )
        snippet = ""
        if snippet_match:
            snippet = re.sub(r'<[^>]+>', '', snippet_match.group(1)).strip()[:300]

        if title:
            results.append({"title": href, "snippet": snippet})

    return results, "duckduckgo-lite"
