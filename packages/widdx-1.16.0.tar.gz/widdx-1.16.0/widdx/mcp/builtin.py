"""Built-in MCP servers — in-process servers that require no external processes.

Each server implements the same interface as MCPClient/MCPHTTPClient
(connect, list_tools, call_tool, disconnect) so they work transparently
with the existing MCPRegistry without any special-case handling.
"""
from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class BuiltInMCPServer:
    """Base class for in-process MCP servers.

    Subclasses define ``_tools`` (list of tool schema dicts) and
    ``_dispatch(tool_name, args)`` to handle calls.
    """

    def __init__(self, name: str) -> None:
        self._name = name

    def connect(self) -> None:
        """No-op — in-process servers are always ready."""
        logger.debug("Built-in MCP server '%s' connected", self._name)

    def disconnect(self) -> None:
        """No-op."""

    def list_tools(self) -> list[dict]:
        """Return tool definitions in standard MCP format."""
        return list(self._tools)

    def call_tool(self, name: str, arguments: dict) -> dict:
        """Dispatch a tool call to the subclass handler.

        Returns a result dict in MCP content format.
        """
        try:
            result = self._dispatch(name, arguments)
            return {
                "content": [
                    {"type": "text", "text": json.dumps(result, ensure_ascii=False, default=str)}
                ]
            }
        except Exception as exc:
            logger.debug("Built-in MCP tool '%s/%s' failed: %s", self._name, name, exc)
            return {
                "content": [
                    {"type": "text", "text": json.dumps({"error": str(exc)}, ensure_ascii=False)}
                ],
                "isError": True,
            }

    # Subclasses override these ------------------------------------------------

    @property
    def _tools(self) -> list[dict]:
        """Override to return tool schema list."""
        return []

    def _dispatch(self, tool_name: str, args: dict) -> dict:
        """Override to handle tool calls."""
        raise NotImplementedError(f"Unknown tool: {tool_name}")


# ---------------------------------------------------------------------------
# Project Info Server — provides project metadata and stats
# ---------------------------------------------------------------------------

class ProjectInfoMCPServer(BuiltInMCPServer):
    """Exposes project metadata: file count, git info, config summary."""

    _TOOL_DEFS = [
        {
            "name": "project_stats",
            "description": "Return project statistics: file count, size, languages, framework.",
            "inputSchema": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
        {
            "name": "project_config",
            "description": "Return parsed project configuration (pyproject.toml, package.json, etc).",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string",
                        "description": "Config file to read (pyproject.toml, package.json, etc). Default: auto-detect.",
                    },
                },
                "required": [],
            },
        },
        {
            "name": "project_tree",
            "description": "Return the project directory tree up to a given depth.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "max_depth": {
                        "type": "integer",
                        "description": "Maximum directory depth. Default: 3.",
                        "default": 3,
                    },
                },
                "required": [],
            },
        },
    ]

    def __init__(self) -> None:
        super().__init__("project-info")
        self._root = Path.cwd()

    @property
    def _tools(self) -> list[dict]:
        return list(self._TOOL_DEFS)

    def _dispatch(self, tool_name: str, args: dict) -> dict:
        if tool_name == "project_stats":
            return self._get_stats()
        elif tool_name == "project_config":
            return self._get_config(args.get("file", ""))
        elif tool_name == "project_tree":
            return self._get_tree(args.get("max_depth", 3))
        raise NotImplementedError(f"Unknown tool: {tool_name}")

    def _get_stats(self) -> dict:
        """Collect project statistics."""
        from ..indexer import ProjectIndexer

        indexer = ProjectIndexer(str(self._root))
        idx = indexer.scan()

        # Git info
        git_info: dict = {}
        try:
            from ..git_ops import GitOps

            g = GitOps(str(self._root))
            if g.is_repo:
                git_info = {
                    "branch": g.current_branch(),
                    "changes": g.status().get("changed", 0),
                }
        except Exception:
            pass

        return {
            "root": idx["root"],
            "total_files": idx["total_files"],
            "total_size_mb": idx["total_size_mb"],
            "important_files_count": len(idx.get("important_files", [])),
            "languages": idx.get("language_stats", {}),
            "git": git_info,
        }

    def _get_config(self, file: str) -> dict:
        """Read a config file and return its parsed contents."""
        candidates = [file] if file else [
            "pyproject.toml", "package.json", "go.mod", "Cargo.toml",
            "docker-compose.yml", "docker-compose.yaml",
        ]
        for name in candidates:
            path = self._root / name
            if path.exists():
                try:
                    raw = path.read_text(encoding="utf-8")
                except OSError as exc:
                    return {"error": str(exc), "file": name}
                # Parse TOML / JSON / YAML
                result = _parse_config(raw, path.suffix)
                return {"file": name, "content": result}
        return {"error": "No recognized config file found", "tried": candidates}

    def _get_tree(self, max_depth: int) -> dict:
        """Return a lightweight directory tree."""
        _IGNORE = {
            "node_modules", "__pycache__", ".git", ".venv", "venv",
            ".next", "dist", "build", ".cache", ".egg-info",
            ".mypy_cache", ".pytest_cache", ".ruff_cache",
        }

        def _walk(dir_path: Path, depth: int) -> list[dict]:
            if depth > max_depth:
                return [{"name": "...", "type": "more"}]
            entries: list[dict] = []
            try:
                items = sorted(dir_path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            except PermissionError:
                return [{"name": "permission denied", "type": "error"}]
            for entry in items:
                if entry.name in _IGNORE or entry.name.startswith("."):
                    continue
                if entry.is_dir():
                    children = _walk(entry, depth + 1)
                    entries.append({"name": entry.name + "/", "type": "dir", "children": children[:50]})
                else:
                    entries.append({
                        "name": entry.name,
                        "type": "file",
                        "size": entry.stat().st_size,
                    })
            return entries[:100]

        tree = _walk(self._root, 0)
        return {"root": str(self._root.name), "tree": tree}


# ---------------------------------------------------------------------------
# UUID / Time Server — lightweight utilities
# ---------------------------------------------------------------------------

class UtilityMCPServer(BuiltInMCPServer):
    """Provides generation utilities: UUIDs, timestamps, hashes."""

    _TOOL_DEFS = [
        {
            "name": "generate_uuid",
            "description": "Generate a UUID v4 string.",
            "inputSchema": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
        {
            "name": "timestamp_now",
            "description": "Return the current UTC timestamp in ISO 8601 format.",
            "inputSchema": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
        {
            "name": "random_string",
            "description": "Generate a random hex string of a given length.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "length": {
                        "type": "integer",
                        "description": "Number of hex characters. Default: 16.",
                        "default": 16,
                    },
                },
                "required": [],
            },
        },
    ]

    def __init__(self) -> None:
        super().__init__("utility")

    @property
    def _tools(self) -> list[dict]:
        return list(self._TOOL_DEFS)

    def _dispatch(self, tool_name: str, args: dict) -> dict:
        if tool_name == "generate_uuid":
            return {"uuid": uuid.uuid4().hex}
        elif tool_name == "timestamp_now":
            return {"timestamp": datetime.now(timezone.utc).isoformat()}
        elif tool_name == "random_string":
            length = min(int(args.get("length", 16)), 128)
            return {"value": uuid.uuid4().hex[:length]}
        raise NotImplementedError(f"Unknown tool: {tool_name}")


# ---------------------------------------------------------------------------
# Registry of built-in server classes
# ---------------------------------------------------------------------------

BUILTIN_SERVERS: dict[str, type[BuiltInMCPServer]] = {
    "project-info": ProjectInfoMCPServer,
    "utility": UtilityMCPServer,
}


def create_builtin_server(name: str) -> BuiltInMCPServer | None:
    """Instantiate a built-in server by name."""
    cls = BUILTIN_SERVERS.get(name)
    if cls is None:
        return None
    return cls()  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_config(raw: str, suffix: str) -> dict | str:
    """Parse a config file string into a dict, or return the raw string."""
    if suffix in (".json",):
        try:
            return dict(json.loads(raw))
        except json.JSONDecodeError:
            return raw
    if suffix in (".yaml", ".yml"):
        try:
            import yaml
            return dict(yaml.safe_load(raw) or {})
        except Exception:
            return raw
    if suffix in (".toml",):
        try:
            # Python 3.11+ has tomllib
            import tomllib
            return dict(tomllib.loads(raw))
        except ImportError:
            pass
        except Exception:
            return raw
        try:
            import tomli
            return tomli.loads(raw)
        except ImportError:
            pass
        except Exception:
            return raw
    return raw


__all__ = [
    "BuiltInMCPServer",
    "ProjectInfoMCPServer",
    "UtilityMCPServer",
    "BUILTIN_SERVERS",
    "create_builtin_server",
]
