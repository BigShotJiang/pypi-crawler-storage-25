"""
widdx/mcp/__init__.py — MCP Protocol Support (GAP-1)

Manages connected MCP servers and their tools.
Servers are configured in ~/.widdx/mcp.json.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from widdx.mcp.config import MCPConfig, load_mcp_config, save_mcp_config

if TYPE_CHECKING:
    from widdx.mcp.client import MCPClient, MCPHTTPClient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# MCPRegistry
# ---------------------------------------------------------------------------


class MCPRegistry:
    """Manages connected MCP servers and their tools.

    Reads server definitions from mcp.json, connects to each server,
    and exposes their tools as WIDDX-compatible JSON Schema dicts.

    mcp.json format::

        {
          "mcpServers": {
            "github": {
              "command": "uvx",
              "args": ["mcp-server-github"],
              "env": { "GITHUB_TOKEN": "ghp_..." }
            }
          }
        }

    Tool names are namespaced as ``mcp__<server>__<tool>`` to avoid
    collisions with built-in WIDDX tools.
    """

    def __init__(self, config_path: str = "~/.widdx/mcp.json") -> None:
        self._config_path = Path(config_path).expanduser()
        # server name → MCPClient instance
        self._servers: dict[str, MCPClient | MCPHTTPClient] = {}
        # merged list of all MCP tool definitions (WIDDX JSON Schema format)
        self._tools: list[dict] = []

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Read mcp.json, connect to external servers, and load built-in servers.

        Built-in servers (project-info, utility) are always loaded —
        they require no configuration or external processes.
        External servers are loaded from mcp.json config files.
        Connection failures are logged as warnings; WIDDX continues with
        built-in tools only (REQ-1 criterion 4).
        """
        self._servers = {}
        self._tools = []

        # ── Load built-in servers first (always available) ──────────
        self._load_builtin_servers()

        # ── Load external servers from mcp.json ─────────────────────
        config: MCPConfig = load_mcp_config(self._config_path)

        for name, server_cfg in config.servers.items():
            if not isinstance(server_cfg, dict):
                logger.warning("Skipping invalid server config for %r", name)
                continue
            # Skip names that collide with built-in servers
            if name in self._servers:
                logger.warning("External server %r collides with built-in — skipping", name)
                continue
            self._connect_server(name, server_cfg)

    def _load_builtin_servers(self) -> None:
        """Instantiate and register all built-in MCP servers."""
        try:
            from widdx.mcp.builtin import BUILTIN_SERVERS, create_builtin_server  # noqa: PLC0415
        except ImportError:
            return

        for name in BUILTIN_SERVERS:
            try:
                server = create_builtin_server(name)
                if server is None:
                    continue
                server.connect()

                # Store the built-in server directly (duck-typing with MCPClient)
                self._servers[name] = server  # type: ignore[assignment]

                # Collect its tools
                raw_tools = server.list_tools()
                for tool in raw_tools:
                    namespaced = self._namespace_tool(name, tool)
                    if namespaced is not None:
                        self._tools.append(namespaced)

                logger.info("Built-in MCP server '%s' loaded — %d tool(s)", name, len(raw_tools))
            except Exception as exc:  # noqa: BLE001
                logger.warning("Failed to load built-in MCP server %r: %s", name, exc)

    def _connect_server(self, name: str, cfg: dict) -> None:
        """Instantiate and connect a single MCP server.

        Detects transport type from the config:
        - If ``cfg`` has a ``"url"`` key → use ``MCPHTTPClient`` (HTTP transport)
        - If ``cfg`` has ``"_disabled": true`` → skip this server
        - Otherwise → use ``MCPClient`` (stdio transport)

        On failure, logs a warning and skips the server so WIDDX continues
        with built-in tools only (REQ-1 criterion 4).
        """
        # Skip disabled servers (user toggled off)
        if cfg.get("_disabled", False):
            logger.info("MCP server %r is disabled — skipping", name)
            return

        # Import here (not at module level) so the module loads even when
        # client.py doesn't exist yet (task 6.2).
        try:
            from widdx.mcp.client import MCPClient, MCPHTTPClient  # noqa: PLC0415
        except ImportError:
            logger.warning(
                "MCPClient not available — skipping server %r (run task 6.2 to implement client.py)",
                name,
            )
            return

        # HTTP transport: config has a "url" key instead of "command".
        if "url" in cfg:
            url: str = cfg["url"]
            if not url:
                logger.warning("HTTP server %r has an empty 'url' — skipping", name)
                return
            headers: dict[str, str] | None = cfg.get("headers")
            client: MCPClient | MCPHTTPClient = MCPHTTPClient(
                name=name, url=url, headers=headers
            )
        else:
            # stdio transport
            command = cfg.get("command", "")
            if not command:
                logger.warning("Server %r has no 'command' — skipping", name)
                return
            args: list[str] = cfg.get("args", [])
            env: dict[str, str] | None = cfg.get("env")
            client = MCPClient(name=name, command=command, args=args, env=env)
        try:
            client.connect()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to connect to MCP server %r: %s", name, exc)
            return

        self._servers[name] = client

        # Collect tool definitions from this server and namespace them.
        try:
            raw_tools = client.list_tools()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to list tools from MCP server %r: %s", name, exc)
            return

        for tool in raw_tools:
            namespaced = self._namespace_tool(name, tool)
            if namespaced is not None:
                self._tools.append(namespaced)

        logger.info(
            "Connected to MCP server %r — %d tool(s) available",
            name,
            len(raw_tools),
        )

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    def tool_definitions(self) -> list[dict]:
        """Return all MCP tools as WIDDX-compatible JSON Schema dicts.

        Each tool name is prefixed with ``mcp__<server>__`` so the ToolLoop
        can route calls back to the correct server.
        """
        return list(self._tools)

    def _namespace_tool(self, server_name: str, tool: dict) -> dict | None:
        """Convert a raw MCP tool schema to a WIDDX-compatible definition.

        The tool name is rewritten to ``mcp__<server>__<original_name>``.
        Returns None if the tool dict is missing required fields.
        """
        original_name = tool.get("name", "")
        if not original_name:
            logger.warning("Skipping unnamed tool from server %r", server_name)
            return None

        namespaced_name = f"mcp__{server_name}__{original_name}"

        # MCP tools carry their schema under "inputSchema"; fall back to an
        # empty object schema if absent.
        input_schema = tool.get("inputSchema") or {
            "type": "object",
            "properties": {},
            "required": [],
        }

        return {
            "name": namespaced_name,
            "description": tool.get("description", f"MCP tool from server '{server_name}'"),
            "schema": input_schema,
        }

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(self, tool_name: str, args: dict) -> dict:
        """Route an ``mcp__<server>__<tool>`` call to the correct server.

        Automatically attempts to reconnect once if the call fails due to a
        broken connection (REQ-1 criterion 4 / task 6.9).

        Args:
            tool_name: Namespaced tool name, e.g. ``mcp__github__create_issue``.
            args:      Arguments dict to pass to the tool.

        Returns:
            Result dict from the MCP server, or an error dict.
        """
        parts = tool_name.split("__", 2)
        if len(parts) != 3 or parts[0] != "mcp":
            return {"error": f"Invalid MCP tool name format: {tool_name!r}"}

        _, server_name, original_tool = parts

        client = self._servers.get(server_name)
        if client is None:
            return {"error": f"MCP server {server_name!r} is not connected"}

        try:
            return client.call_tool(original_tool, args)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "MCP tool call %r failed: %s — attempting reconnect", tool_name, exc
            )
            # Attempt a single reconnect and retry (task 6.9)
            reconnected = self._reconnect_server(server_name)
            if reconnected:
                try:
                    client = self._servers[server_name]
                    return client.call_tool(original_tool, args)
                except Exception as retry_exc:  # noqa: BLE001
                    logger.warning(
                        "MCP tool call %r failed after reconnect: %s", tool_name, retry_exc
                    )
                    return {"error": f"MCP tool call failed after reconnect: {retry_exc}"}
            return {"error": f"MCP tool call failed: {exc}"}

    # ------------------------------------------------------------------
    # Reconnection (task 6.9)
    # ------------------------------------------------------------------

    def _reconnect_server(self, server_name: str) -> bool:
        """Attempt to reconnect a disconnected MCP server.

        Reads the server config from mcp.json, disconnects the old client
        (if any), and reconnects.  Returns True if reconnection succeeded.

        Args:
            server_name: The name of the server to reconnect.

        Returns:
            True if the server was successfully reconnected, False otherwise.
        """
        config = load_mcp_config(self._config_path)
        server_cfg = config.servers.get(server_name)
        if not server_cfg:
            logger.warning(
                "Cannot reconnect MCP server %r — not found in config", server_name
            )
            return False

        # Disconnect the old client cleanly (best-effort)
        old_client = self._servers.pop(server_name, None)
        if old_client is not None:
            try:
                old_client.disconnect()
            except Exception:  # noqa: BLE001
                pass

        # Remove stale tool definitions for this server
        self._tools = [
            t for t in self._tools
            if not t["name"].startswith(f"mcp__{server_name}__")
        ]

        # Reconnect
        logger.info("Reconnecting MCP server %r…", server_name)
        self._connect_server(server_name, server_cfg)
        return server_name in self._servers

    # ------------------------------------------------------------------
    # Introspection (for /mcp command — REQ-1 criterion 5)
    # ------------------------------------------------------------------

    def all_servers(self) -> dict[str, dict]:
        """Return server info for the /mcp display command.

        Returns a dict keyed by server name.  Each value contains:
          - ``connected``: bool
          - ``tools``: list of original (non-namespaced) tool names
        """
        result: dict[str, dict] = {}
        for name, client in self._servers.items():
            tool_names = [
                t["name"].split("__", 2)[2]
                for t in self._tools
                if t["name"].startswith(f"mcp__{name}__")
            ]
            result[name] = {
                "connected": True,
                "tools": tool_names,
            }
        return result

    # ------------------------------------------------------------------
    # Disconnect all servers
    # ------------------------------------------------------------------

    def disconnect(self) -> None:
        """Disconnect all connected MCP servers (called on shutdown)."""
        for name, client in list(self._servers.items()):
            try:
                client.disconnect()
            except Exception:
                pass
            self._servers.pop(name, None)
        self._tools.clear()

    # ------------------------------------------------------------------
    # Server removal (for /mcp remove)
    # ------------------------------------------------------------------

    def remove_server(self, name: str) -> bool:
        """Remove a connected server by name and persist the change.

        Returns True if the server was found and removed, False otherwise.
        """
        if name not in self._servers:
            return False
        del self._servers[name]
        self._tools = [
            t for t in self._tools
            if not t["name"].startswith(f"mcp__{name}__")
        ]
        cfg = load_mcp_config(self._config_path)
        cfg.servers.pop(name, None)
        save_mcp_config(cfg, self._config_path)
        return True

    # ------------------------------------------------------------------
    # Dynamic server management (for /mcp add — REQ-1 criterion 6)
    # ------------------------------------------------------------------

    def add_server(
        self,
        name: str,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        """Add a server, connect it, and persist the config to mcp.json.

        Args:
            name:    Unique server name (used as namespace prefix).
            command: Executable to launch the MCP server.
            args:    Optional list of command-line arguments.
            env:     Optional environment variables for the server process.
        """
        cfg: dict = {"command": command}
        if args:
            cfg["args"] = args
        if env:
            cfg["env"] = env

        # Connect the new server immediately.
        self._connect_server(name, cfg)

        # Persist to mcp.json so it loads on next startup.
        self._save_server(name, cfg)

    def _save_server(self, name: str, cfg: dict) -> None:
        """Write or update a server entry in mcp.json via save_mcp_config."""
        existing: MCPConfig = load_mcp_config(self._config_path)
        existing.servers[name] = cfg
        save_mcp_config(existing, self._config_path)


__all__ = ["MCPRegistry", "MCPConfig", "load_mcp_config", "save_mcp_config"]
