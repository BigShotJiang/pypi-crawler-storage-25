"""Permission system — secure by default, Claude Code style.

Shell commands require a single approval prompt at the start of each session.
Once the user approves, all non-destructive commands run freely for the rest
of the session.  Truly destructive patterns always require explicit confirmation
regardless of session state.

File writes are always allowed — the agent shows a change summary after.
"""
from __future__ import annotations

import fnmatch
import json
import logging
from pathlib import Path

logger = logging.getLogger("widdx.permissions")


class PermissionManager:
    """Secure-by-default permission manager.

    Default behaviour:
    - File writes: always allowed — the agent shows a change summary after.
    - Shell commands: blocked until the user grants session approval.
      The first dangerous shell command triggers a single Y/n prompt.
      After approval, all non-destructive commands run freely.
    - Truly destructive patterns (rm -rf, DROP TABLE, …) always ask,
      even inside an approved session.
    """

    # Patterns that always require explicit confirmation regardless of session state.
    _ALWAYS_CONFIRM = {
        "rm -rf", "rm -r", "del /f /s", "format c:",
        "DROP TABLE", "DROP DATABASE", "> /dev/sda",
    }

    # Shell commands that are considered safe enough to skip the first-time prompt.
    _SAFE_COMMANDS = {
        "echo", "ls", "dir", "cat", "type", "pwd", "git status",
        "git log", "git diff", "python --version", "node --version",
        "pip list", "npm list",
    }

    # MCP tool name patterns that always require destructive confirmation.
    _MCP_DESTRUCTIVE_PATTERNS = {
        "delete", "drop", "remove", "exec", "run", "kill",
        "stop", "restart", "deploy",
    }

    # MCP tool name patterns that are safe without prompting.
    _MCP_SAFE_PATTERNS = {
        "list", "read", "search", "get", "query", "find", "info", "stats",
    }

    def __init__(self, storage_path: str = "~/.widdx/permissions.json",
                 auto_approve: bool = True) -> None:
        self._path = Path(storage_path).expanduser()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._allowed_patterns: list[str] = []
        self._allowed_dirs: list[str] = []
        # Auto-approve by default for fully autonomous operation.
        # Set shell_require_approval: true in config.yaml to require manual approval.
        self._session_approved: bool = auto_approve
        self._session_denied: bool = False
        # Track whether we have already asked the user this session.
        self._asked_this_session: bool = False
        # Per-tool MCP approval: tool name → True/False for this session.
        self._mcp_tool_cache: dict[str, bool] = {}
        self._load()

    # ── Persistence ────────────────────────────────────────────────────

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            data = json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            return
        self._allowed_patterns = data.get("patterns", [])
        self._allowed_dirs = data.get("dirs", [])

    def _save(self) -> None:
        try:
            self._path.write_text(
                json.dumps({"patterns": self._allowed_patterns, "dirs": self._allowed_dirs}, indent=2)
            )
        except OSError:
            pass

    # ── Public API ─────────────────────────────────────────────────────

    def approve_session(self) -> None:
        """Explicitly grant shell access for this session (e.g. via /approve)."""
        self._session_approved = True
        self._session_denied = False
        self._asked_this_session = True

    def deny_session(self) -> None:
        """Block all shell commands for this session (e.g. via /deny)."""
        self._session_denied = True
        self._session_approved = False

    @property
    def is_session_approved(self) -> bool:
        return self._session_approved

    def ask(self, action: str, detail: str, category: str = "shell") -> str:
        """Return 'allow' or 'deny'.

        Decision tree:
        1. File writes → always allow.
        2. Session denied → always deny.
        3. Pre-approved pattern / directory → allow.
        4. Truly destructive command → always ask inline.
        5. MCP-destructive tool → confirm once per tool (per-session cache).
        6. Session already approved → allow (non-destructive).
        7. Safe read-only command → allow silently (no prompt needed).
        8. MCP-safe tool → allow without prompting.
        9. First shell/MCP command this session → ask once, remember answer.
        """
        # 1. File writes are always allowed.
        if category == "file":
            return "allow"

        # 2. Session-level deny (user ran /deny).
        if self._session_denied:
            return "deny"

        # 3. Pre-approved patterns / directories.
        if self._is_preapproved(action, detail, category):
            return "allow"

        # 4. Truly destructive — always confirm inline.
        if self._is_always_confirm(detail):
            return self._confirm_inline(action, detail)

        # 5. MCP-destructive tool — confirm once per tool (per-session).
        if category == "mcp" and self._is_mcp_destructive(detail):
            if detail not in self._mcp_tool_cache:
                self._mcp_tool_cache[detail] = self._confirm_inline(action, detail) == "allow"
            return "allow" if self._mcp_tool_cache[detail] else "deny"

        # 6. Session already approved by the user.
        if self._session_approved:
            return "allow"

        # 7. Safe read-only commands — allow silently without prompting.
        if self._is_safe_command(detail):
            return "allow"

        # 8. MCP-safe tools — allow without prompting.
        if category == "mcp" and self._is_mcp_safe(detail):
            return "allow"

        # 9. First shell/MCP command this session — ask once.
        if not self._asked_this_session:
            return self._ask_session_approval(detail, category)

        # If we already asked and the user said no, keep denying.
        return "deny"

    # ── Helpers ────────────────────────────────────────────────────────

    def _is_always_confirm(self, detail: str) -> bool:
        lowered = detail.lower()
        return any(pat.lower() in lowered for pat in self._ALWAYS_CONFIRM)

    def _is_mcp_destructive(self, tool_name: str) -> bool:
        tool_part = tool_name.split("__", 2)[-1].lower() if tool_name.count("__") >= 2 else tool_name.lower()
        return any(pat in tool_part for pat in self._MCP_DESTRUCTIVE_PATTERNS)

    def _is_mcp_safe(self, tool_name: str) -> bool:
        tool_part = tool_name.split("__", 2)[-1].lower() if tool_name.count("__") >= 2 else tool_name.lower()
        return any(pat in tool_part for pat in self._MCP_SAFE_PATTERNS)

    def is_mcp_tool_safe(self, tool_name: str) -> bool:
        tool_part = tool_name.split("__", 2)[-1].lower()
        return any(p in tool_part for p in self._MCP_SAFE_PATTERNS)

    def is_mcp_tool_destructive(self, tool_name: str) -> bool:
        tool_part = tool_name.split("__", 2)[-1].lower()
        return any(p in tool_part for p in self._MCP_DESTRUCTIVE_PATTERNS)

    def _is_safe_command(self, detail: str) -> bool:
        """Return True for obviously read-only commands that need no prompt.

        Checks the full command, not just the prefix, to prevent chaining attacks
        like ``python --version && rm -rf /`` from bypassing the safe-command list.
        """
        lowered = detail.lower().strip()
        # Reject anything that chains commands — these must go through normal approval.
        chain_operators = ("&&", "||", ";", "|", ">", ">>", "<")
        if any(op in lowered for op in chain_operators):
            return False
        return any(lowered.startswith(safe) for safe in self._SAFE_COMMANDS)

    def _ask_session_approval(self, detail: str, category: str = "shell") -> str:
        """Ask the user once whether to allow commands for this session."""
        self._asked_this_session = True
        label = "MCP tools" if category == "mcp" else "shell commands"
        try:
            from . import ui
            c = ui.get_console()
            c.print()
            c.print(f"  [warning]⚠[/] [bold]The agent wants to run {label}.[/]")
            c.print(f"  [dim]First command:[/] [text]{detail[:80]}[/]")
            c.print()
            c.print(f"  [dim]Allow {label} for this session? [Y/n]:[/] ", end="")
        except Exception as _e:
            logger.debug("Rich console unavailable, falling back to print: %s", _e)
            print(f"\n  ⚠ Agent wants to run {label}: {detail[:80]}")
            print(f"  Allow {label} for this session? [Y/n]: ", end="")

        try:
            choice = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "deny"

        if choice in ("", "y", "yes"):
            self._session_approved = True
            try:
                from . import ui
                ui.get_console().print(f"  [success]✓[/] [dim]{label} access granted for this session.[/]")
            except Exception as _e:
                logger.debug("Rich console unavailable: %s", _e)
                print(f"  ✓ {label} access granted for this session.")
            return "allow"

        self._session_denied = True
        try:
            from . import ui
            ui.get_console().print(f"  [error]✗[/] [dim]{label} access denied for this session.[/]")
        except Exception as _e:
            logger.debug("Rich console unavailable: %s", _e)
            print(f"  ✗ {label} access denied.")
        return "deny"

    def _confirm_inline(self, action: str, detail: str) -> str:
        """Minimal inline confirmation for destructive commands — one line, one keypress."""
        try:
            from . import ui
            ui.get_console().print(
                f"\n  [error]⚠ DESTRUCTIVE[/] [dim]{action}:[/] [text]{detail[:80]}[/]"
            )
            ui.get_console().print("  [dim]Allow this destructive command? [y/N]:[/] ", end="")
        except Exception as _e:
            logger.debug("Rich console unavailable: %s", _e)
            print(f"\n  ⚠ DESTRUCTIVE {action}: {detail[:80]}")
            print("  Allow? [y/N]: ", end="")

        try:
            choice = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "deny"

        return "allow" if choice in ("y", "yes") else "deny"

    def _is_preapproved(self, action: str, detail: str, category: str) -> bool:
        for pattern in self._allowed_patterns:
            if fnmatch.fnmatch(action, pattern):
                return True
        try:
            cwd = str(Path.cwd())
        except (PermissionError, OSError):
            cwd = str(Path.cwd().absolute())
        for d in self._allowed_dirs:
            if cwd.lower().startswith(d.lower()):
                return True
        return False

    def ask_with_edit(self, action: str, detail: str) -> tuple[str, str]:
        """Interactive approval that allows editing the command before execution."""
        if self._session_denied:
            return "deny", detail

        if self._session_approved and not self._is_always_confirm(detail):
            return "allow", detail

        try:
            from rich.panel import Panel

            from . import ui
            ui.get_console().print()
            ui.get_console().print(Panel(
                f"[text]{detail}[/]",
                title="[warning]⚠ Destructive Command Requested[/]",
                border_style="warning",
                padding=(1, 2)
            ))
            ui.get_console().print("  [dim]Press Enter to run, edit the command, or clear to cancel.[/]")

            try:
                from prompt_toolkit import prompt
                from prompt_toolkit.formatted_text import HTML
                edited = prompt(HTML("<ansiyellow><b>  ❯ </b></ansiyellow>"), default=detail)
            except ImportError:
                print(f"\n  Command: {detail}")
                edited = input("  ❯ Enter new command or leave empty to cancel: ")
                if not edited:
                    return "deny", detail

            edited = edited.strip()
            if not edited:
                return "deny", detail
            return "allow", edited

        except (KeyboardInterrupt, EOFError):
            return "deny", detail
