"""Pre-flight health check — validates tooling before project work."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path


# ── Common installation search paths (for tools not on PATH) ──────────

def _common_install_dirs(tool: str) -> list[Path]:
    """Return directories where a tool might be installed but not on PATH."""
    dirs: list[Path] = []
    if sys.platform == "win32":
        local_appdata = os.environ.get("LOCALAPPDATA", "")
        program_files = os.environ.get("ProgramFiles", "C:\\Program Files")
        # Winget packages
        winget_base = Path(local_appdata) / "Microsoft" / "WinGet" / "Packages"
        if winget_base.exists():
            for d in winget_base.iterdir():
                if d.is_dir() and d.name.lower().startswith(tool.lower()):
                    dirs.append(d)
        # Choco packages
        choco_base = Path("C:\\tools")
        if choco_base.exists():
            for d in choco_base.iterdir():
                if d.is_dir() and d.name.lower().startswith(tool.lower()):
                    dirs.append(d)
        # Manual installs
        dirs.append(Path(program_files) / tool)
        dirs.append(Path(f"C:\\{tool}"))
    else:
        dirs.append(Path(f"/usr/local/{tool}"))
        dirs.append(Path(f"/opt/{tool}"))
    return dirs


def _find_tool(name: str) -> str | None:
    """Find a tool executable — PATH first, then common install locations."""
    # PATH lookup
    path = shutil.which(name)
    if path:
        return path

    # Search common install directories
    exe = f"{name}.exe" if sys.platform == "win32" else name
    for base_dir in _common_install_dirs(name):
        if not base_dir.exists():
            continue
        candidate = base_dir / exe
        if candidate.is_file():
            return str(candidate)
        # Also check subdirectories (e.g. php/php.exe inside winget package)
        for sub in base_dir.rglob(exe):
            if sub.is_file():
                return str(sub)
            break  # Only first level

    return None


@dataclass
class ToolCheck:
    name: str
    installed: bool
    version: str = ""
    path: str = ""
    min_version: str | None = None
    meets_min: bool = True


@dataclass
class PreflightResult:
    passed: bool
    checks: list[ToolCheck] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    version_warnings: list[str] = field(default_factory=list)


# Known tools and their version flags
_TOOL_CHECKS: list[tuple[str, list[str], str | None]] = [
    ("git",       ["git", "--version"],       None),
    ("php",       ["php", "-v"],               "8.1"),
    ("composer",  ["composer", "-V"],          None),
    ("node",      ["node", "--version"],       "18.0"),
    ("npm",       ["npm", "--version"],        None),
    ("python",    [sys.executable, "--version"], "3.8"),
    ("go",        ["go", "version"],           None),
    ("rustc",     ["rustc", "--version"],      None),
    ("docker",    ["docker", "--version"],     None),
]


def run() -> PreflightResult:
    """Check all known tools and return a PreflightResult."""
    checks: list[ToolCheck] = []
    missing: list[str] = []
    version_warnings: list[str] = []

    for name, cmd, min_ver in _TOOL_CHECKS:
        path = _find_tool(name)
        if path is None:
            checks.append(ToolCheck(name=name, installed=False))
            missing.append(name)
            continue

        version_str = ""
        meets_min = True
        try:
            run_cmd = [path] + cmd[1:]  # Use full path to the executable
            proc = subprocess.run(run_cmd, capture_output=True, text=True, timeout=15)
            raw = (proc.stdout or proc.stderr or "").strip()
            version_str = _extract_version(raw)
            if min_ver and version_str:
                meets_min = _compare_versions(version_str, min_ver)
                if not meets_min:
                    version_warnings.append(
                        f"{name} {version_str} < required {min_ver}"
                    )
        except (subprocess.TimeoutExpired, OSError):
            version_str = "(unknown)"

        checks.append(ToolCheck(
            name=name,
            installed=True,
            version=version_str,
            path=path,
            min_version=min_ver,
            meets_min=meets_min,
        ))

    return PreflightResult(
        passed=len(missing) == 0 and len(version_warnings) == 0,
        checks=checks,
        missing=missing,
        version_warnings=version_warnings,
    )


def check_requirements(required: list[str]) -> PreflightResult:
    """Check only specific tools from the required list."""
    all_checks = run()
    filtered = [
        c for c in all_checks.checks
        if c.name in required
    ]
    missing = [c.name for c in filtered if not c.installed]
    version_warnings = [
        f"{c.name} {c.version} < required {c.min_version}"
        for c in filtered if c.installed and not c.meets_min
    ]
    return PreflightResult(
        passed=len(missing) == 0 and len(version_warnings) == 0,
        checks=filtered,
        missing=missing,
        version_warnings=version_warnings,
    )


def _extract_version(raw: str) -> str:
    """Extract a semver-like version string from arbitrary tool output."""
    import re
    m = re.search(r"(\d+\.\d+(?:\.\d+)?)", raw)
    return m.group(1) if m else ""


def _compare_versions(current: str, required: str) -> bool:
    """Return True if current >= required (semver-aware)."""
    def _parse(v: str) -> tuple[int, ...]:
        parts = v.split(".")
        return tuple(int(p) for p in parts)

    try:
        return _parse(current) >= _parse(required)
    except (ValueError, IndexError):
        return True


def print_report(result: PreflightResult) -> None:
    """Print a human-readable preflight report."""
    from widdx import ui
    c = ui.get_console()

    if result.passed:
        c.print("  [success]✓[/] All required tools available")
        return

    if result.missing:
        c.print("  [error]✗ Missing tools:[/]")
        for name in result.missing:
            c.print(f"    [dim]-[/] [warning]{name}[/]")

    for warning in result.version_warnings:
        c.print(f"  [warning]⚠ {warning}[/]")

    c.print()


__all__ = ["run", "check_requirements", "PreflightResult", "ToolCheck", "print_report"]
