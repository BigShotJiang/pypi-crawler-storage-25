"""Semantic code search — pure Python, zero compilation needed.

Uses sentence-transformers (all-MiniLM-L6-v2, ~80MB) for embeddings and
SQLite + numpy for vector storage. Runs entirely in-process — no server needed.
No C++ compiler required — works on all platforms.

Usage:
    index = SemanticIndex(persist_dir=".widdx/embeddings")
    index.index_project(Path("."))
    results = index.search("how does auth work", top_k=5)
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ── Chunking ──────────────────────────────────────────────────────────

_MAX_FILE_BYTES = 500_000
_CHUNK_SIZE = 800
_CHUNK_OVERLAP = 200

_INDEX_EXTS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java",
    ".rb", ".php", ".swift", ".kt", ".cs", ".scala", ".cpp", ".c",
    ".h", ".hpp", ".cc", ".cxx", ".vue", ".svelte", ".sql",
    ".md", ".txt", ".yaml", ".yml", ".toml", ".json", ".cfg",
    ".html", ".css", ".scss", ".less", ".sh", ".bash", ".ps1",
}


def _should_index(path: Path) -> bool:
    if path.is_dir():
        return False
    try:
        if path.stat().st_size > _MAX_FILE_BYTES:
            return False
    except OSError:
        return False
    suffix = path.suffix.lower()
    if suffix in _INDEX_EXTS:
        return True
    name = path.name.lower()
    return name in ("makefile", "dockerfile", ".gitignore", ".env.example")


def _chunk_code(content: str, file_path: str) -> list[dict[str, Any]]:
    chunks: list[dict[str, Any]] = []
    if not content.strip():
        return chunks
    sections = re.split(
        r'(?:(?:^|\n)(?:def |class |async def |function |func |public function '
        r'|export function |export class |const \w+ = |export const ))',
        content,
    )
    if len(sections) > 100 or all(len(s) < 100 for s in sections if s.strip()):
        return _fixed_chunks(content, file_path)
    pos = 0
    for i, section in enumerate(sections):
        text = section.strip()
        if not text or len(text) < 50:
            continue
        if len(text) > _CHUNK_SIZE + _CHUNK_OVERLAP:
            for sub in _fixed_chunks(text, file_path):
                sub["chunk_index"] = i
                chunks.append(sub)
        else:
            start_line = content[:pos].count('\n') + 1 if pos < len(content) else 1
            chunks.append({
                "text": text, "file": file_path, "chunk_index": i,
                "start_line": start_line, "source": f"{file_path}:{start_line}",
            })
            pos += len(section)
    return chunks


def _fixed_chunks(content: str, file_path: str) -> list[dict[str, Any]]:
    chunks: list[dict[str, Any]] = []
    lines = content.split('\n')
    current, start_line, line_idx = "", 1, 0
    for line in lines:
        if len(current) + len(line) > _CHUNK_SIZE and current:
            chunks.append({
                "text": current.strip(), "file": file_path,
                "chunk_index": len(chunks), "start_line": start_line,
                "source": f"{file_path}:{start_line}",
            })
            overlap_start = max(0, len(current) - _CHUNK_OVERLAP)
            current = current[overlap_start:]
            start_line = line_idx - current.count('\n')
        current += line + '\n'
        line_idx += 1
    if current.strip():
        chunks.append({
            "text": current.strip(), "file": file_path,
            "chunk_index": len(chunks), "start_line": start_line,
            "source": f"{file_path}:{start_line}",
        })
    return chunks


# ── Vector Store (SQLite + numpy, no C++ needed) ──────────────────────

def _pack_vector(vec: list[float]) -> bytes:
    return struct.pack(f'{len(vec)}f', *vec)


def _unpack_vector(data: bytes, dim: int) -> list[float]:
    return list(struct.unpack(f'{dim}f', data))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Pure Python cosine similarity — fast enough for <100K vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# ── Semantic Index ─────────────────────────────────────────────────────

class SemanticIndex:
    """Local semantic code search — pure Python, no C++ compiler needed."""

    def __init__(self, persist_dir: str = ".widdx/embeddings"):
        self._persist_dir = Path(persist_dir).resolve()
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        self._model = None
        self._db: sqlite3.Connection | None = None
        self._dim: int = 0
        self._file_hashes: dict[str, str] = {}
        self._ready = False

    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer('all-MiniLM-L6-v2')
        except ImportError:
            raise ImportError(
                "sentence-transformers required for RAG. pip install sentence-transformers"
            ) from None

    def _ensure_db(self) -> None:
        if self._db is not None:
            return
        db_path = self._persist_dir / "vectors.db"
        self._db = sqlite3.connect(str(db_path))
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id TEXT PRIMARY KEY,
                file TEXT NOT NULL,
                source TEXT,
                start_line INTEGER,
                text TEXT,
                vector BLOB,
                dim INTEGER
            )
        """)
        self._db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file)")
        self._db.commit()

    @property
    def is_ready(self) -> bool:
        return self._ready

    @property
    def chunk_count(self) -> int:
        if self._db is None:
            return 0
        row = self._db.execute("SELECT COUNT(*) FROM chunks").fetchone()
        return row[0] if row else 0

    # ── Indexing ────────────────────────────────────────────────────

    def index_project(self, root: Path, batch_size: int = 50) -> dict:
        self._ensure_model()
        self._ensure_db()

        t0 = time.time()
        files = []
        skip_parts = {'node_modules', '__pycache__', '.git', 'venv', '.venv',
                      '.widdx', 'graphify-out', 'dist', '.egg-info'}
        for path in root.rglob("*"):
            if any(p in skip_parts for p in path.parts):
                continue
            if _should_index(path):
                files.append(path)

        stats = {"files": 0, "chunks": 0, "skipped": 0, "elapsed": 0}
        all_texts, all_metas, all_ids = [], [], []

        for fpath in files:
            try:
                rel = str(fpath.relative_to(root))
            except ValueError:
                rel = str(fpath)

            file_hash = _file_hash(fpath)
            if self._file_hashes.get(rel) == file_hash:
                stats["skipped"] += 1
                continue

            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
            except OSError:
                stats["skipped"] += 1
                continue

            chunks = _chunk_code(content, rel)
            if not chunks:
                stats["skipped"] += 1
                continue

            self._db.execute("DELETE FROM chunks WHERE file = ?", (rel,))
            for chunk in chunks:
                cid = f"{rel}:{chunk['chunk_index']}"
                all_ids.append(cid)
                all_texts.append(chunk["text"])
                all_metas.append((cid, rel, chunk["source"], chunk["start_line"], chunk["text"]))

            self._file_hashes[rel] = file_hash
            stats["files"] += 1

            if len(all_texts) >= batch_size:
                embeddings = self._model.encode(all_texts, show_progress_bar=False)
                self._dim = embeddings.shape[1]
                self._db.executemany(
                    "INSERT OR REPLACE INTO chunks (id, file, source, start_line, text, vector, dim) VALUES (?,?,?,?,?,?,?)",
                    [(mid, mf, ms, ml, mt, _pack_vector(emb.tolist()), self._dim)
                     for (mid, mf, ms, ml, mt), emb in zip(all_metas, embeddings)],
                )
                self._db.commit()
                stats["chunks"] += len(all_texts)
                all_texts, all_metas, all_ids = [], [], []

        if all_texts:
            embeddings = self._model.encode(all_texts, show_progress_bar=False)
            self._dim = embeddings.shape[1]
            self._db.executemany(
                "INSERT OR REPLACE INTO chunks (id, file, source, start_line, text, vector, dim) VALUES (?,?,?,?,?,?,?)",
                [(mid, mf, ms, ml, mt, _pack_vector(emb.tolist()), self._dim)
                 for (mid, mf, ms, ml, mt), emb in zip(all_metas, embeddings)],
            )
            self._db.commit()
            stats["chunks"] += len(all_texts)

        stats["elapsed"] = round(time.time() - t0, 2)
        self._ready = True
        return stats

    # ── Search ───────────────────────────────────────────────────────

    def search(self, query: str, top_k: int = 10) -> list[dict]:
        self._ensure_model()
        self._ensure_db()

        count = self.chunk_count
        if count == 0:
            return []

        query_embedding = self._model.encode([query], show_progress_bar=False)[0].tolist()

        rows = self._db.execute(
            "SELECT id, file, source, start_line, text, vector, dim FROM chunks"
        ).fetchall()

        scored = []
        for row in rows:
            vec = _unpack_vector(row[5], row[6])
            score = _cosine_similarity(query_embedding, vec)
            scored.append((score, row))

        scored.sort(key=lambda x: -x[0])
        hits = []
        for score, row in scored[:top_k]:
            hits.append({
                "id": row[0], "file": row[1], "source": row[2],
                "start_line": row[3], "text": row[4][:1000],
                "score": round(score, 3),
            })
        return hits

    def search_context(self, query: str, top_k: int = 8, max_chars: int = 8000) -> str:
        hits = self.search(query, top_k=top_k)
        if not hits:
            return ""
        parts = []
        total = 0
        for hit in hits:
            block = f"=== {hit['source']} (score={hit['score']}) ===\n{hit['text']}\n\n"
            if total + len(block) > max_chars:
                break
            parts.append(block)
            total += len(block)
        return '\n'.join(parts)


def _file_hash(path: Path) -> str:
    try:
        st = path.stat()
        return hashlib.sha1(f"{st.st_size}:{st.st_mtime}".encode()).hexdigest()[:16]
    except OSError:
        return ""
