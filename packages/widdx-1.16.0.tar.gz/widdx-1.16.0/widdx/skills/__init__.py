"""
widdx/skills/__init__.py -- Skills System with token-aware lazy loading.

Skills are NOT loaded into context unless they match the current task.
This prevents token waste from loading irrelevant skills on every turn.
"""

from __future__ import annotations

import re
from pathlib import Path

from widdx.skills.loader import load_skill_file, parse_frontmatter

# Skills that always load regardless of task (keep these small)
AUTO_INVOKE_ALWAYS = {"tdd-workflow"}

# Max number of matched skills to inject per turn
MAX_MATCHED_SKILLS = 3

# Max total tokens per skill content (enforced by truncation)
MAX_SKILL_CONTENT_CHARS = 2500


class SkillManager:
    """Token-efficient skill discovery and matching.

    Strategy:
      - All skill names + descriptions load once (cheap, ~1 token each).
      - Full skill content loads only when:
        1. The task keywords match the skill description (auto-match).
        2. The skill is marked auto-invoke (always matches).
        3. The user manually invokes /skill-name.

    This keeps the system prompt lean while making all skills discoverable.
    """

    def __init__(self) -> None:
        self._skills: list[dict] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Scan builtin, user, and project skill directories.

        Order: builtin -> user -> project.
        Later directories override earlier ones by skill name.
        """
        self._skills = []

        search_dirs: list[Path] = [
            Path(__file__).resolve().parent / "builtin",
            Path("~/.widdx/skills").expanduser(),
            Path(".widdx/skills"),
        ]

        seen: dict[str, int] = {}

        for directory in search_dirs:
            if not directory.exists() or not directory.is_dir():
                continue

            for md_file in sorted(directory.glob("*.md")):
                skill = self._load_file(md_file)
                if skill is None:
                    continue

                name = skill["name"]
                if name in seen:
                    self._skills[seen[name]] = skill
                else:
                    seen[name] = len(self._skills)
                    self._skills.append(skill)

    def match_skills(self, task: str, max_skills: int = MAX_MATCHED_SKILLS) -> list[str]:
        """Return skill contents relevant to the given task.

        Matching logic:
          1. Skills in AUTO_INVOKE_ALWAYS are always included.
          2. Remaining slots are filled by keyword overlap between
             the task text and each skill's description + name.
          3. Capped at max_skills total.

        Args:
            task: The user's task description.
            max_skills: Maximum number of skills to return.

        Returns:
            List of skill content strings to inject into the system prompt.
        """
        if not self._skills:
            return []

        task_keywords = self._tokenize(task)
        if not task_keywords:
            return []

        scored: list[tuple[int, dict]] = []

        for skill in self._skills:
            skill_name = skill["name"]
            auto_invoke = skill.get("auto_invoke", False)

            # Auto-invoke skills get max score
            if auto_invoke or skill_name in AUTO_INVOKE_ALWAYS:
                scored.append((999, skill))
                continue

            # Score by keyword overlap with description + name
            target = f"{skill_name} {skill['description']}".lower()
            score = sum(1 for kw in task_keywords if kw in target)

            if score > 0:
                scored.append((score, skill))

        # Sort by score descending
        scored.sort(key=lambda x: x[0], reverse=True)

        # Take top N, truncate each to max length
        result: list[str] = []
        for _, skill in scored[:max_skills]:
            content = skill["content"]
            if len(content) > MAX_SKILL_CONTENT_CHARS:
                content = content[:MAX_SKILL_CONTENT_CHARS] + "\n... [truncated]"
            result.append(content)

        return result

    def missing_domains(self, task: str) -> list[str]:
        """Detect technologies/frameworks mentioned in the task that have no matching skill.

        Compares task keywords against known skill names and descriptions.
        Returns a list of suspected technologies that are not covered.

        Args:
            task: The user's task description.

        Returns:
            List of technology/framework names with no matching skill.
        """
        if not self._skills:
            return []

        task_lower = task.lower()

        # Known tech names that might appear in tasks
        tech_indicators = {
            "laravel", "symfony", "wordpress", "drupal", "magento",
            "nextjs", "next.js", "nuxt", "remix", "svelte", "qwik",
            "flutter", "react native", "expo", "swiftui",
            "django", "flask", "fastapi", "rails", "express",
            "spring", "asp.net", "phoenix", "elixir", "gin", "echo",
            "vue", "react", "angular", "ember", "jquery",
            "tailwind", "bootstrap", "material ui", "chakra",
            "redis", "kafka", "rabbitmq", "elasticsearch",
            "docker", "kubernetes", "terraform", "ansible",
            "graphql", "grpc", "websocket", "webhook",
            "postgresql", "mysql", "mongodb", "sqlite", "mariadb",
            "aws", "azure", "gcp", "firebase", "supabase",
            "prisma", "typeorm", "sequelize", "knex",
        }

        # Get all known skill/agent names
        known = {s["name"].lower() for s in self._skills}
        known.update(s.get("description", "").lower() for s in self._skills)

        unknown: list[str] = []
        for tech in tech_indicators:
            if tech in task_lower:
                # Check if any skill covers this tech
                covered = any(
                    tech in name or tech in desc
                    for name in known
                    for desc in [name]  # just check names
                )
                if not covered:
                    # Double-check: maybe a compound match
                    tech_words = set(tech.split())
                    skill_texts = {
                        f"{s['name']} {s.get('description', '')}".lower()
                        for s in self._skills
                    }
                    covered = any(
                        all(w in text for w in tech_words)
                        for text in skill_texts
                    )
                    if not covered:
                        unknown.append(tech)

        return unknown

    def get_skill(self, name: str) -> str | None:
        """Return skill content by name for manual /skill invocation.

        Args:
            name: The skill name (as defined in frontmatter).

        Returns:
            Skill content string, or None if not found.
        """
        for skill in self._skills:
            if skill["name"] == name:
                return str(skill["content"])
        return None

    def list_skills(self) -> list[tuple[str, str]]:
        """Return [(name, description), ...] for /skills listing.

        Only names and descriptions -- no content loaded.
        Cheap to call, safe for every turn.
        """
        return [(skill["name"], skill["description"]) for skill in self._skills]

    # Backward compatibility alias
    all_commands = list_skills

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        """Extract meaningful lowercase keywords from text."""
        words = re.findall(r"[a-zA-Z]{3,}", text.lower())
        # Remove common noise words
        noise = {"the", "and", "for", "with", "that", "this", "from", "have", "what"}
        return {w for w in words if w not in noise}

    def _load_file(self, path: Path) -> dict | None:
        return load_skill_file(path)


__all__ = ["SkillManager", "parse_frontmatter", "load_skill_file"]
