---
name: laravel
description: Laravel framework conventions, patterns, and best practices for building large PHP applications.
---

# Laravel Conventions

## Code Standards
- PSR-12 for all PHP files
- Class names: PascalCase (UserController, OrderService)
- Methods: camelCase (createOrder, sendNotification)
- Database tables: snake_case, plural (users, order_items)
- Foreign keys: {table}_id (user_id, order_id)
- Pivot tables: alphabetical singular (order_user)

## Eloquent Patterns
- Define $fillable or $guarded on every model
- Use accessors/mutators for data transformation
- Query scopes for reusable constraints (scopeActive, scopeForUser)
- Eager load with `with()` to prevent N+1
- Use `chunk()` or `lazy()` for large datasets
- Cast attributes (protected $casts = ['deleted_at' => 'datetime'])

## Controller Structure
- Keep controllers thin: validate, call service, return response
- Use FormRequest for validation logic
- Inject services via constructor DI
- Single responsibility: one CRUD resource per controller

## Service Classes
- Business logic lives in app/Services/
- One service per domain concept
- Inject repositories or Eloquent models
- Return typed values, never arrays

## Validation Rules
- Define rules in FormRequest classes
- Custom rules for domain-specific validation
- Use `sometimes` for optional fields
- Never trust client-side validation alone

## Security
- CSRF protection via VerifyCsrfToken middleware
- XSS: Blade auto-escapes, use {!! !!} only when trusted
- Mass assignment: use $fillable or $guarded
- Rate limiting on auth and API routes
- Encryption: use Crypt facade for sensitive data

## Artisan Commands
- Namespace: php artisan project:action
- Use constructor DI for dependencies
- Display output with $this->info(), ->error(), ->line()
- Use progress bars for batch operations

## Queue Jobs
- Implement ShouldQueue for async processing
- Set $tries and $backoff for retry logic
- Use job batching for related tasks
- Failed jobs: implement failed() method
- Keep job payloads small (pass model IDs, not models)
