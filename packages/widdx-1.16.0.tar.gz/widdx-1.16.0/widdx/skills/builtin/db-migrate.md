---
name: db-migrate
description: Create and manage database migrations. Use when changing database schema, adding tables, or modifying columns.
---

# Database Migrations

## Migration Rules

### Always
- Create a backup before running migrations in production
- Use transactions for DML changes
- Write both up and down migrations
- Test migrations on a copy of production data first
- Keep migrations small and focused

### Naming
- Use timestamp-based naming: YYYYMMDD_HHMMSS_description.sql
- Description should clearly state what the migration does

### Up Migration
- Add new tables, columns, indexes, constraints
- Backfill data if adding NOT NULL columns with defaults
- Use IF NOT EXISTS where supported

### Down Migration
- Reverse exactly what the up migration did
- Drop in reverse order of creation
- If data loss is unavoidable, document it clearly

### Safety
- Never drop columns or tables without explicit confirmation
- Add indexes concurrently on large tables (PostgreSQL)
- Lock tables for minimum time possible
- Test rollback before applying in production

### Example
```sql
-- Up
BEGIN;
ALTER TABLE users ADD COLUMN phone VARCHAR(20);
CREATE INDEX CONCURRENTLY idx_users_phone ON users(phone);
COMMIT;

-- Down
BEGIN;
DROP INDEX IF EXISTS idx_users_phone;
ALTER TABLE users DROP COLUMN phone;
COMMIT;
```
