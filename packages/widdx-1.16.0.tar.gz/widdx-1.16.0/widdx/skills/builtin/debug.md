---
name: debug
description: Systematic debugging approach. Use when encountering errors, unexpected behavior, or test failures.
---

# Debugging

## 1. Gather Information
- Read the full error message and stack trace
- Note the exact line where the error occurs
- Check: is this a new error or has it always been there?

## 2. Reproduce Reliably
- Find the minimal input that triggers the error
- Write a test case that reproduces it
- Document the exact steps

## 3. Isolate
- Binary search: comment out half the code, test, repeat
- Add logging at decision points
- Check assumptions: print values at each step

## 4. Root Cause Analysis
- Ask "why" five times
- Do not fix until you understand the cause
- Check: could this same issue exist elsewhere?

## 5. Fix and Verify
- Apply the minimal fix
- Run the reproduction test
- Run the full test suite
- Remove any debug logging added

## Common Pitfall Checks
- Off-by-one errors in loops
- None/null checks missing
- Type mismatches (string vs int)
- Mutable default arguments (Python)
- Race conditions (async/concurrent code)
- Incorrect indentation
- Variable shadowing
