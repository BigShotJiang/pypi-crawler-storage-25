---
name: docs-generate
description: Generate documentation for code. Use when asked to document code, create README, or write API docs.
---

# Documentation Generator

## Types of Documentation

### API Documentation
- Endpoint, method, URL
- Request parameters with types
- Request body example
- Response body example with types
- Error responses
- Authentication required

### Function Documentation
- What the function does (one line)
- Parameters with types and descriptions
- Return value with type
- Exceptions raised
- Usage example

### README
- Project title and one-line description
- Installation steps
- Quick start example
- Configuration options
- API overview
- Contributing guide

### Code Comments
- Explain WHY, not WHAT
- Document non-obvious behavior
- Reference issue numbers for workarounds
- Do not comment obvious code

## Style
- Short sentences
- Active voice
- Present tense
- Code examples for every concept
- Keep it concise - prefer one good example over three paragraphs
