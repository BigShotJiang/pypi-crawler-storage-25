---
name: code-review
description: Review code for security issues, performance problems, and code quality. Use when asked to review code or audit.
---

# Code Review

Review code systematically:

## 1. Security
- No hardcoded secrets or API keys
- SQL queries use parameterized statements
- XSS protection (output encoding)
- Input validation on all user-facing endpoints
- No dangerous functions with untrusted input (eval, exec, system)

## 2. Performance
- Database queries optimized (indexes, no N+1)
- No unnecessary loops or repeated operations
- Caching strategy where appropriate
- Lazy loading for heavy resources

## 3. Code Quality
- Clear naming for variables and functions
- Each function does one thing (SRP)
- No duplicated code (DRY)
- Proper error handling, no silent failures
- No magic numbers, use named constants

## 4. Testing
- Critical paths covered by tests
- Edge cases covered
- Error states tested

## Report Format

```
## Critical (fix immediately)
- [Issue] -> [Why critical] -> [Suggested fix]

## High Impact (best effort-to-impact ratio)
- [Issue] -> [Benefit] -> [Fix]

## Quick Wins
- [Small change with big impact]
```
