---
name: queue-jobs
description: Background job processing patterns for reliable async task execution in large applications.
---

# Queue and Job Processing

## When to Use Queues
- Sending emails
- Processing file uploads (images, CSVs)
- Calling external APIs (webhooks, SMS)
- Generating reports and exports
- Data cleanup and maintenance
- Any operation that takes more than 200ms

## Job Design
- Keep job payloads small: pass IDs, not objects
- Jobs should be idempotent (safe to run twice)
- Set appropriate timeout (longer than expected execution)
- Handle all exceptions explicitly
- Log at start and end of processing
- Use unique job IDs to prevent duplicates

## Retry Strategy
- Set $tries based on importance (email: 3, critical: 5)
- Use exponential backoff: $backoff = [30, 60, 120, 300]
- failed() method for cleanup on permanent failure
- Move problematic jobs to failed queue for inspection

## Batch Processing
- Use job batching for related tasks
- Monitor batch progress with Bus facade
- Set batch timeout and allow failures
- Run cleanup job after batch completion

## Monitoring
- Track queue size and processing rate
- Alert when queue depth exceeds threshold
- Monitor failed jobs and retry patterns
- Log processing time per job type
