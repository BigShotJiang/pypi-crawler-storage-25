---
name: testing
description: Comprehensive testing strategy for large projects. Unit, integration, E2E, and performance testing.
---

# Testing Strategy

## Test Pyramid
1. Unit tests: 70% of tests. Fast, isolated, test business logic.
2. Integration tests: 20%. Test API endpoints, database queries, middleware.
3. E2E tests: 10%. Critical user flows only.

## Unit Test Rules
- One assertion per test is ideal, but related assertions OK
- Test name: test_<method>_<scenario>_<expected_result>
- Use mocks for external services, never for internal logic
- Test both happy path and at least 3 error paths
- Use data providers for testing multiple inputs

## Integration Test Rules
- Test real database interactions (use test database)
- Test API response codes, headers, and body structure
- Test authentication and authorization flows
- Test validation errors return correct format

## Laravel Testing
- Feature tests extend Tests\TestCase
- Use RefreshDatabase trait for isolated tests
- Factory classes for test data
- actingAs() for authenticated user tests
- assertStatus(), assertJson(), assertRedirect()

## Coverage Targets
- Critical business logic: 90%+
- API endpoints: 80%+
- UI components: 60%+
- Configuration and wiring: 50%+
