---
name: api-design
description: Design REST and GraphQL APIs. Use when creating new APIs or reviewing API contracts.
---

# API Design

## REST API Principles

### Resource Naming
- Use plural nouns: /users, /orders
- Use nesting for relationships: /users/123/orders
- No verbs in URLs: use HTTP methods instead

### HTTP Methods
- GET: retrieve resources
- POST: create new resources
- PUT: replace entire resource
- PATCH: partial update
- DELETE: remove resource

### Status Codes
- 200: success
- 201: created
- 204: no content (delete success)
- 400: bad request (validation error)
- 401: unauthorized
- 403: forbidden
- 404: not found
- 422: unprocessable entity
- 429: rate limited
- 500: server error

### Response Format
```json
{
  "data": {},
  "error": null,
  "meta": { "page": 1, "total": 100 }
}
```

### Error Format
```json
{
  "data": null,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Human-readable description",
    "details": [{"field": "email", "issue": "Invalid format"}]
  }
}
```

### Best Practices
- Pagination on all list endpoints (cursor-based for large datasets)
- Versioning via URL prefix: /v1/users
- Filtering and sorting via query parameters
- Rate limiting headers on all responses
- Consistent date format: ISO 8601

## GraphQL

### Naming
- Types: PascalCase
- Fields: camelCase
- Mutations: verbNoun format (createUser, updateOrder)

### Schema Design
- Keep resolvers thin, move logic to services
- Use DataLoader for batching to avoid N+1
- Add descriptions to all types and fields
- Consider query complexity limits
