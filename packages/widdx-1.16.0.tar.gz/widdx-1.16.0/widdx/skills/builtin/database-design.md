---
name: database-design
description: Database schema design for large-scale applications. Indexing, normalization, migrations, and performance optimization.
---

# Database Design

## Schema Design Principles
- Normalize to 3NF by default
- Denormalize only with performance data proving the need
- Use appropriate types: INT for IDs, VARCHAR with limits, TEXT for long content
- TIMESTAMP for dates, DECIMAL for money (never FLOAT)
- Add CHECK constraints where the DB supports them
- Separate schemas for multi-tenant applications

## Indexing Strategy
- Index: primary keys (automatic), foreign keys, WHERE clause columns, ORDER BY columns, JOIN columns
- Composite indexes: equality columns first, range columns last
- Covering indexes when all queried columns are in the index
- Partial indexes for filtered queries on large tables
- Remove unused indexes (they slow writes)
- Analyze with EXPLAIN before deploying

## Migration Best Practices
- Each migration does ONE thing
- Always write a tested down() method
- Add columns with NULL + default first, backfill, then add NOT NULL
- Batch large UPDATE/DELETE with LIMIT in loops
- Never rename columns directly: add new, copy data, drop old
- Test on staging with production-size data

## Query Optimization
- Select only needed columns, never SELECT *
- Eager load relationships
- Use cursor-based pagination for large datasets
- Avoid queries in loops (N+1)
- Use query builder aggregates instead of loading + counting in code
- Set query timeouts to catch runaway queries
