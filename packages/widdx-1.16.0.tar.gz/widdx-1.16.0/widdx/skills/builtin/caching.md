---
name: caching
description: Multi-level caching strategy for high-performance applications. Cache invalidation, cache-aside, and distributed caching patterns.
---

# Caching Strategy

## Cache Levels
1. Browser: Cache-Control, ETag, Service Worker
2. CDN: static assets, API responses (short TTL)
3. Application: computed data, query results, rendered views
4. Database: query cache, connection pooling

## Cache-Aside Pattern
```
1. Check cache for key
2. If found (hit): return cached value
3. If not found (miss): fetch from source, store in cache, return
```

## Invalidation Strategy
- TTL-based: set a reasonable TTL for all cached items
- Event-based: invalidate when data changes
- Write-through: update cache on every write
- Cache stampede prevention: probabilistic early recomputation

## What to Cache
- Expensive queries (aggregates, reports)
- Frequently accessed reference data (categories, configs)
- API responses from external services
- Rendered partials and fragments
- Session data and user preferences

## What NOT to Cache
- Real-time data (stock prices, chat messages)
- User-specific sensitive data without encryption
- Large binary files (use CDN or object storage)
- Data that changes faster than TTL

## Laravel Cache
- Use Cache facade with appropriate driver (Redis for production)
- Cache::remember() for cache-aside pattern
- Cache tags for grouped invalidation
- Rate limiting with cache
- Queue jobs for cache warming
