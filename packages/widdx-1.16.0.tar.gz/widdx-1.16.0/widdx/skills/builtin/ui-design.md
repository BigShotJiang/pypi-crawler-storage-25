---
name: ui-design
description: Build professional web interfaces using modern CSS. Use when building UI components, pages, or styling.
---

# UI Design

## Principles
- Clarity: instant comprehension
- Consistency: same patterns, same places
- Hierarchy: guide the eye intentionally
- Responsive: works on all viewports
- Accessible: WCAG AA minimum

## Layout
- Use CSS Grid for page layout, Flexbox for components
- Max content width: 75ch for text blocks
- Spacing rhythm: multiples of 4px (0.25rem)

## Typography
- System font stack: `system-ui, -apple-system, sans-serif`
- Monospace for code: `JetBrains Mono, Fira Code, monospace`
- Line height: 1.5 for body, 1.2 for headings
- Font size: 16px minimum on inputs (prevents iOS zoom)

## Colors
- Primary: one distinctive color for actions
- Neutral: gray scale for text and backgrounds
- Ensure 4.5:1 contrast ratio for text (WCAG AA)
- Do not rely on color alone to convey information

## Components
- Buttons: distinct, with hover and focus states
- Cards: white background, subtle border, rounded corners
- Forms: label above input, inline validation errors
- Navigation: sticky, with clear active state
- Empty states: helpful message with a CTA

## Accessibility
- All interactive elements reachable via Tab
- Visible focus indicators on all elements
- Alt text on images, labels on inputs
- Touch targets minimum 44x44px
- Use semantic HTML (button for buttons, nav for navigation)

## Responsive
- Mobile-first approach
- Breakpoints: 576px, 768px, 992px, 1200px
- Test at 320px viewport (no horizontal scroll)
