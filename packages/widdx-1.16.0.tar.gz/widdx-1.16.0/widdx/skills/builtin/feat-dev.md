---
name: feat-dev
description: Develop a new feature from scratch. Use when asked to add a new feature or functionality.
---

# Feature Development

## 1. Plan
- Understand requirements completely
- Design the data structures needed
- Identify integration points with existing code
- Plan tests before starting

## 2. Implement bottom-up
1. Models/Data - Define structures and tables
2. Core logic - Service functions and operations
3. API/UI - Endpoints or components
4. Integration - Connect all layers
5. Tests - Unit, integration, end-to-end

## 3. Strict rules
- Read existing code before writing anything
- No incomplete code or placeholders
- Every line must have a reason
- Do not add unnecessary complexity
- Follow existing project patterns
