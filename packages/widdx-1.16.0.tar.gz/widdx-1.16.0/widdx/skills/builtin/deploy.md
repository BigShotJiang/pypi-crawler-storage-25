---
name: deploy
description: Deploy application to production. Use when asked to deploy, release, or ship code.
disable-model-invocation: true
---

# Deploy

Deploy the application to production:

## 1. Pre-deployment checks
- Run the full test suite
- Run linting and type checking
- Check for uncommitted changes
- Verify you are on the correct branch
- Review changes since last deploy

## 2. Build
- Build the application
- Verify build output is correct
- Check bundle size (frontend)

## 3. Deploy
- Push to deployment target
- Run database migrations if needed
- Clear caches

## 4. Verify
- Check health endpoint
- Verify critical paths work
- Check error logs for 5 minutes
- Confirm with user that deployment succeeded

## 5. Rollback plan
If deployment fails:
- Know the rollback command before deploying
- Have the previous version identifier ready
