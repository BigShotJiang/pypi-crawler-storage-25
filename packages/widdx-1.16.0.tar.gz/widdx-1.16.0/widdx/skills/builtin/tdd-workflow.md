---
name: tdd-workflow
description: Test-driven development workflow. Write tests first, then code. Use automatically when implementing any feature.
---

# Test-Driven Development

Follow the TDD cycle strictly:

## Cycle: RED -> GREEN -> REFACTOR

### 1. Write the test first (RED)
- Write a failing test
- Define expected behavior precisely
- Verify the test fails for the right reason

### 2. Make it pass (GREEN)
- Write the minimum code to pass the test
- Do not optimize yet
- Goal: pass the test, nothing more

### 3. Refactor (REFACTOR)
- Remove duplication
- Improve naming
- Extract helper functions
- Ensure tests remain green

## Rules
- Each test covers one behavior
- Test name describes the behavior: test_<what>_<expected_result>
- Use fixtures for repeated setup
- Test public behavior, not internal implementation details
