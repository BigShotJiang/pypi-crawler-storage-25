---
name: refactor
description: Refactor code for better structure without changing behavior. Use when code needs cleanup, restructuring, or simplification.
---

# Refactoring

## Before Starting
- Ensure tests exist and pass
- Commit or stash current changes
- Work in small, reversible steps

## Common Refactorings

### Extract Function
When a block of code has a clear purpose, extract it:
- Name describes what it does, not how
- Keep extracted functions small (under 20 lines)
- Pass dependencies as parameters

### Simplify Conditionals
- Replace complex boolean expressions with named functions
- Use early returns instead of deep nesting
- Replace switch/if-else chains with lookup tables

### Remove Duplication
- Same logic in two places: extract shared function
- Similar but not identical: parameterize the difference
- Copy-pasted configuration: extract to shared config

### Improve Names
- Functions: verb or verb+noun (process_payment, build_report)
- Variables: noun (user_count, not uc)
- Booleans: is_ or has_ prefix (is_active, has_permission)
- Collections: plural (users, not user_list)

### Split Large Modules
- One responsibility per module
- Group related functions together
- Extract shared utilities

## After Each Step
- Run tests to verify behavior unchanged
- Commit small, logical changes separately
