---
name: security-review
description: Comprehensive security audit. Use when asked for security review or vulnerability assessment.
---

# Security Audit

Check code against common vulnerability classes:

## OWASP Top 10

### Access Control
- Does every endpoint check permissions?
- Can a regular user access admin data?
- Are object IDs protected from tampering (IDOR)?

### Cryptography
- Are sensitive data encrypted at rest and in transit?
- Are passwords hashed with bcrypt/argon2?
- Are certificates and algorithms up to date?

### Injection
- SQL Injection: Are all queries parameterized?
- Command Injection: Do system commands use user input?
- NoSQL Injection: Are MongoDB queries secured?

### Configuration
- Do error messages reveal sensitive information?
- Are unnecessary ports and services closed?
- Is CORS configured correctly?

### Dependencies
- Are packages and libraries up to date?
- Run pip audit / npm audit

### Authentication
- Are weak passwords rejected?
- Do sessions expire?
- Is password reset secure?

## Report Format

```
## Summary
Level: [Critical/High/Medium/Low]
Vulnerabilities found: X

## Critical
[Vulnerability] -> [CVSS severity] -> [Exploitation] -> [Fix]

## Medium/Low
[Same format]

## Recommendations
[General security improvements]
```
