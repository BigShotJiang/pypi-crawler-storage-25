---
name: bugfix
description: Fix bugs methodically. Use when a bug is reported or a fix is requested.
---

# Bug Fix Workflow

## 1. Understand the bug
- Read the full error message
- Read the issue report if available
- Identify: expected behavior vs actual behavior

## 2. Reproduce the bug
- Run the code and confirm the bug exists
- Isolate the conditions that trigger it
- Write a test that fails because of this bug

## 3. Find the root cause
- Trace the code from the failure point
- Examine the full stack trace
- Fix the cause, not the symptoms

## 4. Apply the fix
- Write the smallest change that fixes the problem
- Verify the new test passes
- Verify existing tests still pass

## 5. Prevent recurrence
- Are there other places the same bug could occur?
- Does this type of bug need automated detection?
