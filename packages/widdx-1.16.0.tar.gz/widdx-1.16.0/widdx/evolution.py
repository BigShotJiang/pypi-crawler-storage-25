"""Routing preference tracker and prompt effectiveness optimizer."""
from __future__ import annotations

import json
from typing import Any


class EvolutionEngine:
    """Tracks routing performance and adjusts role-selection weights over time.

    Observes which model role (architect vs executor) produces better outcomes
    for each task type, and biases future routing decisions accordingly via
    exponential-decay weight updates.

    This is a routing preference tracker — it does not mutate prompts or run
    A/B experiments. Rename to ``RoutingOptimizer`` in a future major version
    once the interface is stable.
    """

    _DEFAULT_WEIGHT = 0.5
    _HISTORICAL_WEIGHT_FACTOR = 0.3
    _BASE_SCORE_FACTOR = 0.7
    _REWARD_SUCCESS = 0.15
    _REWARD_FAILURE = -0.10
    _LATENCY_THRESHOLD_MS = 30000
    _LATENCY_PENALTY = -0.02
    _MIN_WEIGHT = 0.1
    _MAX_WEIGHT = 1.0
    _EVALUATION_LATENCY_WARN_MS = 60000

    def __init__(self, memory, config: dict[str, Any]) -> None:
        self._memory = memory
        evo_config = config.get("evolution", {})
        self._enabled = evo_config.get("enabled", True)
        self._min_samples = evo_config.get("min_samples_for_optimization", 5)
        self._decay = evo_config.get("decay_factor", 0.9)
        self._weights: dict[str, float] = {}
        self._load_weights()

    @property
    def is_enabled(self) -> bool:
        return bool(self._enabled)

    def _load_weights(self) -> None:
        raw = self._memory.get_knowledge("evolution_weights")
        if raw:
            self._weights = json.loads(raw)

    def _save_weights(self) -> None:
        self._memory.set_knowledge("evolution_weights", json.dumps(self._weights))

    def recommend_role(self, task_type: str) -> str | None:
        """Recommend the best role (architect/executor) for a task type based on history."""
        if not self._enabled:
            return None
        stats = self._memory.routing_stats(task_type)
        if not stats:
            return None
        total_samples = sum(s["count"] for s in stats)
        if total_samples < self._min_samples:
            return None
        weighted = {}
        for s in stats:
            model = s["model_selected"]
            base_score = s["avg_score"]
            weight_key = f"{task_type}:{model}"
            historical_weight = self._weights.get(weight_key, self._DEFAULT_WEIGHT)
            weighted[model] = base_score * self._BASE_SCORE_FACTOR + historical_weight * self._HISTORICAL_WEIGHT_FACTOR
        if not weighted:
            return None
        return str(max(weighted, key=lambda k: weighted[k]))

    def update(self, task_type: str, model: str, success: bool, latency_ms: int) -> None:
        """Update strategy weights after a task completes."""
        if not self._enabled:
            return
        weight_key = f"{task_type}:{model}"
        old_weight = self._weights.get(weight_key, self._DEFAULT_WEIGHT)
        reward = self._REWARD_SUCCESS if success else self._REWARD_FAILURE
        latency_penalty = self._LATENCY_PENALTY if latency_ms > self._LATENCY_THRESHOLD_MS else 0.0
        new_weight = max(self._MIN_WEIGHT, min(self._MAX_WEIGHT, old_weight * self._decay + (self._DEFAULT_WEIGHT + reward + latency_penalty) * (1 - self._decay)))
        self._weights[weight_key] = new_weight
        self._save_weights()

    def evaluate(self, task_id: str, decisions: list[dict]) -> dict:
        """Evaluate a completed task and return improvement suggestions."""
        if not decisions:
            return {"total_latency_ms": 0, "model_count": 0, "decision_count": 0, "suggestion": None}
        total_latency = sum(d.get("latency_ms", 0) for d in decisions)
        model_switches = len({d.get("model_used") for d in decisions if d.get("model_used")})
        suggestion = None
        if total_latency > self._EVALUATION_LATENCY_WARN_MS:
            suggestion = "Consider reducing pipeline depth for similar tasks"
        return {
            "total_latency_ms": total_latency,
            "model_count": model_switches,
            "decision_count": len(decisions),
            "suggestion": suggestion,
        }
