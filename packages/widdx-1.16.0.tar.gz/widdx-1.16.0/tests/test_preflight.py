"""Tests for preflight health checks."""
from __future__ import annotations

import pytest


# ── PreflightResult dataclass ────────────────────────────────────────

def test_preflight_result_fields():
    """PreflightResult has correct default values for list fields."""
    from widdx.preflight import PreflightResult
    r = PreflightResult(passed=False)
    assert r.passed is False
    assert r.missing == []
    assert r.checks == []
    assert r.version_warnings == []


def test_preflight_result_passed_true():
    """PreflightResult can be marked as passed."""
    from widdx.preflight import PreflightResult
    r = PreflightResult(passed=True)
    assert r.passed is True


# ── check_requirements ───────────────────────────────────────────────

def test_check_requirements_python_exists():
    """Python is always available (running these tests)."""
    from widdx.preflight import check_requirements
    result = check_requirements(["python"])
    assert result.passed is True
    assert "python" not in result.missing


def test_check_requirements_git():
    """Git should be available on most dev machines."""
    from widdx.preflight import check_requirements
    result = check_requirements(["git"])
    assert isinstance(result.passed, bool)
    assert isinstance(result.missing, list)


def test_check_requirements_empty_list():
    """Empty requirement list passes."""
    from widdx.preflight import check_requirements
    result = check_requirements([])
    assert result.passed is True
    assert result.missing == []


def test_check_requirements_result_type():
    """Returns a PreflightResult."""
    from widdx.preflight import PreflightResult, check_requirements
    result = check_requirements(["python"])
    assert isinstance(result, PreflightResult)


# ── print_report ─────────────────────────────────────────────────────

def test_print_report_runs_without_error(capsys):
    """print_report doesn't crash."""
    from widdx.preflight import PreflightResult, print_report
    r = PreflightResult(
        passed=False,
        missing=["php", "node"],
        version_warnings=["git version too old"],
    )
    print_report(r)
    captured = capsys.readouterr()
    assert "Missing" in captured.out or "php" in captured.out


def test_print_report_passed(capsys):
    """print_report for passed result shows success."""
    from widdx.preflight import PreflightResult, print_report
    r = PreflightResult(passed=True)
    print_report(r)
    # Should not crash — output may vary
