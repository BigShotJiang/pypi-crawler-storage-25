"""Tests for widdx.pipeline.review — documentation, deployment, code review."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from widdx.pipeline.review import (
    _consolidate_memory,
    _evolution_patch,
    _review_output,
    _run_deployment_setup,
    _run_documentation,
    _run_final_code_review,
    _run_integration_test,
)


def _make_pipeline(tmp_path: Path, **kwargs):
    """Build a mock pipeline object with attributes injected by the pipeline."""
    pipeline = MagicMock()
    pipeline._router = MagicMock()
    pipeline._router.call_architect.return_value = {"text": "All good", "usage": {}}
    pipeline._router.call_executor.return_value = {"text": "done", "usage": {}}
    pipeline._is_error = lambda r: bool(r.get("error", False))
    pipeline._router.classify = MagicMock(return_value="architect")
    pipeline._router.infer_task_type = MagicMock(return_value="implementation")
    pipeline._memory = MagicMock()
    pipeline._memory.set_knowledge = MagicMock()
    pipeline._memory.complete_task = MagicMock()
    pipeline._memory.task_decisions = MagicMock(return_value=[
        {"output_summary": "ok", "latency_ms": 100},
        {"output_summary": "done", "latency_ms": 200},
    ])
    pipeline._evolution = MagicMock()
    pipeline._evolution.evaluate.return_value = {"health": "good"}
    pipeline._evolution.update = MagicMock()
    for k, v in kwargs.items():
        setattr(pipeline, k, v)
    return pipeline


class TestRunIntegrationTest:
    """_run_integration_test runs build verification."""

    def test_passes(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("widdx.verifier.ProjectVerifier") as MockVerifier:
            mock_v = MagicMock()
            mock_v.verify_build.return_value = {"passed": True}
            MockVerifier.return_value = mock_v
            _run_integration_test(pipeline, "build")
            mock_v.verify_build.assert_called_once()

    def test_fails_with_output(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("widdx.verifier.ProjectVerifier") as MockVerifier:
            mock_v = MagicMock()
            mock_v.verify_build.return_value = {"passed": False, "output": "build failed"}
            MockVerifier.return_value = mock_v
            _run_integration_test(pipeline, "build")

    def test_exception_handled(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("widdx.verifier.ProjectVerifier", side_effect=ImportError("no module")):
            _run_integration_test(pipeline, "build")


class TestRunFinalCodeReview:
    """_run_final_code_review calls architect model for review."""

    def test_reviews_files(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        review = _run_final_code_review(pipeline, "build", ["file1.py", "file2.py"])
        assert review == "All good"
        pipeline._router.call_architect.assert_called_once()

    def test_empty_files_returns_empty(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        review = _run_final_code_review(pipeline, "build", [])
        assert review == ""

    def test_error_result_returns_empty(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        pipeline._router.call_architect.return_value = {"error": "API error"}
        pipeline._is_error = lambda r: True
        review = _run_final_code_review(pipeline, "build", ["file.py"])
        assert review == ""


class TestRunDocumentation:
    """_run_documentation generates README.md and api.md."""

    def test_python_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "requirements.txt").write_text("flask\n")
        (tmp_path / "manage.py").write_text("# django")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_documentation(pipeline, "build", None)
            readme = tmp_path / "README.md"
            assert readme.exists()
            content = readme.read_text(encoding="utf-8")
            assert "pip install" in content
            assert "manage.py runserver" in content

    def test_node_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "package.json").write_text("{}")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_documentation(pipeline, "build", None)
            readme = tmp_path / "README.md"
            assert readme.exists()
            content = readme.read_text(encoding="utf-8")
            assert "npm install" in content
            assert "npm run dev" in content

    def test_php_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "composer.json").write_text("{}")
        (tmp_path / "artisan").write_text("#!/usr/bin/env php")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_documentation(pipeline, "build", None)
            readme = tmp_path / "README.md"
            assert readme.exists()
            content = readme.read_text(encoding="utf-8")
            assert "composer install" in content
            assert "php artisan serve" in content

    def test_unknown_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_documentation(pipeline, "build", None)
            readme = tmp_path / "README.md"
            assert readme.exists()
            content = readme.read_text(encoding="utf-8")
            assert "Check documentation" in content

    def test_exception_handled(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("pathlib.Path.cwd", side_effect=OSError("disk error")):
            _run_documentation(pipeline, "build", None)


class TestRunDeploymentSetup:
    """_run_deployment_setup generates Dockerfile + compose."""

    def test_existing_files_skip(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "Dockerfile").write_text("EXISTS")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").read_text() == "EXISTS"

    def test_python_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "app.py").write_text("print('hello')")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            assert (tmp_path / "docker-compose.yml").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "python:3.12-slim" in content

    def test_node_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "index.js").write_text("console.log('hi')")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "node:20-alpine" in content

    def test_go_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "go.mod").write_text("module app")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "golang" in content

    def test_php_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "index.php").write_text("<?php echo 'hi';")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "php:8.2-cli" in content

    def test_rust_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "Cargo.toml").write_text("[package]\nname = 'app'")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "rust" in content

    def test_ruby_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "Gemfile").write_text("source 'https://rubygems.org'")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "ruby" in content

    def test_dart_project(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "pubspec.yaml").write_text("name: app")
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert (tmp_path / "Dockerfile").exists()
            content = (tmp_path / "Dockerfile").read_text()
            assert "dart" in content

    def test_unknown_language_skips(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=tmp_path):
            _run_deployment_setup(pipeline, "build")
            assert not (tmp_path / "Dockerfile").exists()

    def test_generates_deploy_guide(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        (tmp_path / "app.py").write_text("print('hi')")
        widdx_dir = tmp_path / ".widdx"
        widdx_dir.mkdir(parents=True, exist_ok=True)
        with patch("pathlib.Path.cwd", return_value=tmp_path), \
             patch("widdx.project_state.get_widdx_dir", return_value=widdx_dir):
            _run_deployment_setup(pipeline, "build")
            assert (widdx_dir / "deploy.md").exists()

    def test_exception_handled(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        with patch("pathlib.Path.cwd", side_effect=OSError("disk error")):
            _run_deployment_setup(pipeline, "build")


class TestReviewOutput:
    """_review_output sends command output to architect for review."""

    def test_reviews_output(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        review = _review_output(pipeline, "build", "Build succeeded")
        assert review == "All good"
        pipeline._router.call_architect.assert_called_once()

    def test_error_result_returns_empty(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        pipeline._router.call_architect.return_value = {"error": "API error"}
        pipeline._is_error = lambda r: True
        review = _review_output(pipeline, "build", "output")
        assert review == ""


class TestConsolidateMemory:
    """_consolidate_memory persists task completion to memory."""

    def test_stores_knowledge(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        _consolidate_memory(pipeline, "task-1", "build project", "Build output here", "Looks good")
        pipeline._memory.complete_task.assert_called_once_with("task-1")
        pipeline._memory.set_knowledge.assert_called_once()


class TestEvolutionPatch:
    """_evolution_patch evaluates task decisions."""

    def test_evaluates_decisions(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        report = _evolution_patch(pipeline, "task-1", "build", 3)
        assert report == {"health": "good"}
        pipeline._evolution.evaluate.assert_called_once()
        pipeline._evolution.update.assert_called_once()

    def test_handles_errors_in_decisions(self, tmp_path: Path):
        pipeline = _make_pipeline(tmp_path)
        pipeline._memory.task_decisions.return_value = [
            {"output_summary": "error: something failed", "latency_ms": 100},
        ]
        report = _evolution_patch(pipeline, "task-1", "build", 1)
        assert report == {"health": "good"}
