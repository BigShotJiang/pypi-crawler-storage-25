"""Tests for tool execution — file_ops, shell, search."""
from __future__ import annotations

from pathlib import Path

import pytest

from widdx.tools import file_ops, shell, search


# ── file_ops.tool_read_file ────────────────────────────────────────────────

class TestReadFile:
    def test_reads_existing_file(self, sample_file):
        result = file_ops.tool_read_file(str(sample_file))
        assert "error" not in result
        assert "line one" in result["content"]
        assert result["total_lines"] == 3

    def test_error_on_missing_file(self, tmp_path):
        result = file_ops.tool_read_file(str(tmp_path / "nonexistent.txt"))
        assert "error" in result

    def test_line_range_respected(self, sample_file):
        result = file_ops.tool_read_file(str(sample_file), start_line=1, end_line=2)
        assert result["content"] == "line two"

    def test_returns_file_path(self, sample_file):
        result = file_ops.tool_read_file(str(sample_file))
        assert "file_path" in result


# ── file_ops.tool_write_file ───────────────────────────────────────────────

class TestWriteFile:
    def test_creates_new_file(self, tmp_path):
        p = tmp_path / "new.txt"
        result = file_ops.tool_write_file(str(p), "hello world")
        assert "error" not in result
        assert p.read_text() == "hello world"

    def test_refuses_overwrite_by_default(self, sample_file):
        result = file_ops.tool_write_file(str(sample_file), "new content")
        assert "error" in result

    def test_overwrite_flag_replaces_file(self, sample_file):
        result = file_ops.tool_write_file(str(sample_file), "replaced", overwrite=True)
        assert "error" not in result
        assert sample_file.read_text() == "replaced"

    def test_creates_parent_directories(self, tmp_path):
        p = tmp_path / "deep" / "nested" / "file.txt"
        result = file_ops.tool_write_file(str(p), "content")
        assert "error" not in result
        assert p.exists()


# ── file_ops.tool_edit_file ────────────────────────────────────────────────

class TestEditFile:
    def test_replaces_string(self, sample_file):
        result = file_ops.tool_edit_file(str(sample_file), "line two", "LINE TWO")
        assert "error" not in result
        assert "LINE TWO" in sample_file.read_text()

    def test_error_when_old_string_not_found(self, sample_file):
        result = file_ops.tool_edit_file(str(sample_file), "nonexistent text", "x")
        assert "error" in result

    def test_error_on_missing_file(self, tmp_path):
        result = file_ops.tool_edit_file(str(tmp_path / "ghost.txt"), "a", "b")
        assert "error" in result

    def test_error_on_multiple_matches_without_flag(self, tmp_path):
        p = tmp_path / "dup.txt"
        p.write_text("foo\nfoo\n")
        result = file_ops.tool_edit_file(str(p), "foo", "bar")
        assert "error" in result

    def test_replace_all_flag(self, tmp_path):
        p = tmp_path / "dup.txt"
        p.write_text("foo\nfoo\n")
        result = file_ops.tool_edit_file(str(p), "foo", "bar", replace_all=True)
        assert "error" not in result
        assert p.read_text() == "bar\nbar\n"


# ── shell.tool_shell ───────────────────────────────────────────────────────

class TestShellTool:
    def test_allowed_command_runs(self):
        result = shell.tool_shell("echo hello")
        assert "error" not in result
        assert result["exit_code"] == 0

    def test_forbidden_command_blocked(self):
        result = shell.tool_shell("shutdown /s")
        assert "error" in result
        assert "forbidden" in result["error"].lower()

    def test_normal_command_allowed(self):
        """Commands like whoami, curl, rm are allowed — the permission system is the gate."""
        result = shell.tool_shell("whoami")
        assert "error" not in result
        assert result["exit_code"] == 0

    def test_empty_command_returns_error(self):
        result = shell.tool_shell("")
        assert "error" in result

    def test_result_has_expected_keys(self):
        result = shell.tool_shell("echo test")
        for key in ("exit_code", "stdout", "stderr", "latency_ms"):
            assert key in result

    # ── Security: chaining metacharacter detection ─────────────────

    def test_chaining_ampersand_blocked(self):
        result = shell.tool_shell("git status & del important.txt")
        assert "error" in result
        assert "chaining" in result["error"].lower()

    def test_chaining_double_ampersand_blocked(self):
        result = shell.tool_shell("npm install && rm -rf /")
        assert "error" in result

    def test_chaining_pipe_blocked(self):
        result = shell.tool_shell("echo hello | rm file.txt")
        assert "error" in result

    def test_chaining_double_pipe_blocked(self):
        result = shell.tool_shell("git status || exit 1")
        assert "error" in result

    def test_chaining_semicolon_blocked(self):
        result = shell.tool_shell("echo a; echo b")
        assert "error" in result

    def test_inline_pipe_in_quotes_allowed(self):
        """A pipe inside quotes is not a shell pipe, it is a literal string."""
        result = shell.tool_shell("echo 'hello|world'")
        assert "error" not in result

    def test_inline_ampersand_in_quotes_allowed(self):
        result = shell.tool_shell('echo "a & b"')
        assert "error" not in result


# ── shell._has_shell_chaining ────────────────────────────────────────────

class TestHasShellChaining:
    @pytest.mark.parametrize("cmd", [
        "git & rm",
        "a && b",
        "x || y",
        "a | b",
        "echo; rm",
    ])
    def test_detects_chaining(self, cmd):
        assert shell._has_shell_chaining(cmd) is True

    @pytest.mark.parametrize("cmd", [
        "git status",
        "echo hello",
        "npm run build",
        "python script.py",
        "go test ./...",
    ])
    def test_allows_normal_commands(self, cmd):
        assert shell._has_shell_chaining(cmd) is False


# ── shell._extract_base_command ───────────────────────────────────────────

class TestExtractBaseCommand:
    @pytest.mark.parametrize("cmd,expected", [
        ("python script.py", "python"),
        ("git status", "git"),
        ("/usr/bin/python3 -m pip install", "python3"),
        ("npm run build", "npm"),
        ("echo 'hello world'", "echo"),
    ])
    def test_extracts_base(self, cmd, expected):
        assert shell._extract_base_command(cmd) == expected


# ── search.tool_grep ──────────────────────────────────────────────────────

class TestGrepTool:
    def test_finds_pattern(self, tmp_path):
        (tmp_path / "a.txt").write_text("hello world\n")
        result = search.tool_grep("hello", directory=str(tmp_path))
        assert "error" not in result
        assert result.get("count", 0) >= 1

    def test_no_matches_returns_empty(self, tmp_path):
        (tmp_path / "b.txt").write_text("nothing here\n")
        result = search.tool_grep("zzznomatch", directory=str(tmp_path))
        assert result.get("count", 0) == 0


# ── search.tool_glob ──────────────────────────────────────────────────────

class TestGlobTool:
    def test_finds_files_by_pattern(self, tmp_path):
        (tmp_path / "foo.py").write_text("")
        (tmp_path / "bar.py").write_text("")
        result = search.tool_glob("*.py", directory=str(tmp_path))
        assert "error" not in result
        assert result.get("count", 0) == 2

    def test_no_match_returns_empty(self, tmp_path):
        result = search.tool_glob("*.nonexistent", directory=str(tmp_path))
        assert result.get("count", 0) == 0
