"""Tests for AgentHandoff.to_context_block() compactness — task 2.3."""
from __future__ import annotations

import pytest
from widdx.agent_factory.spec import AgentHandoff


# ── Structural correctness ─────────────────────────────────────────────────

def test_includes_from_and_to_roles():
    h = AgentHandoff(from_role="Backend", to_role="Frontend")
    block = h.to_context_block()
    assert "Backend" in block
    assert "Frontend" in block


def test_broadcast_when_to_role_is_none():
    h = AgentHandoff(from_role="Backend", to_role=None)
    block = h.to_context_block()
    assert "all" in block


def test_includes_summary_when_set():
    h = AgentHandoff(from_role="A", to_role="B", summary="Built the API")
    block = h.to_context_block()
    assert "Built the API" in block


def test_omits_summary_when_empty():
    h = AgentHandoff(from_role="A", to_role="B", summary="")
    block = h.to_context_block()
    assert "Summary:" not in block


def test_includes_decisions_when_set():
    h = AgentHandoff(from_role="A", to_role="B", decisions=["Use async", "Pydantic v2"])
    block = h.to_context_block()
    assert "Use async" in block
    assert "Pydantic v2" in block


def test_omits_decisions_when_empty():
    h = AgentHandoff(from_role="A", to_role="B", decisions=[])
    block = h.to_context_block()
    assert "Decisions:" not in block


def test_includes_files_created():
    h = AgentHandoff(from_role="A", to_role="B", files_created=["main.py", "models.py"])
    block = h.to_context_block()
    assert "main.py" in block
    assert "models.py" in block


def test_includes_files_edited():
    h = AgentHandoff(from_role="A", to_role="B", files_edited=["config.py"])
    block = h.to_context_block()
    assert "config.py" in block


def test_omits_files_when_empty():
    h = AgentHandoff(from_role="A", to_role="B")
    block = h.to_context_block()
    assert "Created:" not in block
    assert "Edited:" not in block


def test_includes_next_steps_when_set():
    h = AgentHandoff(from_role="A", to_role="B", next_steps="Build the UI")
    block = h.to_context_block()
    assert "Build the UI" in block


def test_omits_next_steps_when_empty():
    h = AgentHandoff(from_role="A", to_role="B", next_steps="")
    block = h.to_context_block()
    assert "Next:" not in block


# ── Compactness / truncation ───────────────────────────────────────────────

def test_summary_truncated_at_600_chars():
    long_summary = "x" * 10_000
    h = AgentHandoff(from_role="A", to_role="B", summary=long_summary)
    block = h.to_context_block()
    # The summary line should not exceed 600 chars of content + "Summary: " prefix + ellipsis
    summary_line = [line for line in block.splitlines() if line.startswith("Summary:")][0]
    # "Summary: " is 9 chars, content is capped at 600, plus "…" (1 char) = 610 max
    assert len(summary_line) <= 9 + 600 + 1


def test_summary_not_truncated_when_short():
    short = "Built FastAPI endpoints"
    h = AgentHandoff(from_role="A", to_role="B", summary=short)
    block = h.to_context_block()
    assert short in block
    assert "…" not in block


def test_decisions_truncated_when_very_long():
    many_decisions = [f"Decision number {i} with some detail" for i in range(20)]
    h = AgentHandoff(from_role="A", to_role="B", decisions=many_decisions)
    block = h.to_context_block()
    decisions_line = [line for line in block.splitlines() if line.startswith("Decisions:")][0]
    # "Decisions: " is 11 chars, content capped at 200, plus "…" = 212 max
    assert len(decisions_line) <= 11 + 200 + 1


def test_files_created_truncated_when_very_long():
    many_files = [f"path/to/some/deeply/nested/file_{i}.py" for i in range(50)]
    h = AgentHandoff(from_role="A", to_role="B", files_created=many_files)
    block = h.to_context_block()
    created_line = [line for line in block.splitlines() if line.startswith("Created:")][0]
    # "Created: " is 9 chars, content capped at 150, plus "…" = 160 max
    assert len(created_line) <= 9 + 150 + 1


def test_next_steps_truncated_when_very_long():
    long_steps = "Do this very important thing " * 20
    h = AgentHandoff(from_role="A", to_role="B", next_steps=long_steps)
    block = h.to_context_block()
    next_line = [line for line in block.splitlines() if line.startswith("Next:")][0]
    # "Next: " is 6 chars, content capped at 120, plus "…" = 127 max
    assert len(next_line) <= 6 + 120 + 1


def test_typical_handoff_under_1000_chars():
    """A realistic handoff with all fields populated stays under 1000 chars."""
    h = AgentHandoff(
        from_role="Backend Architect",
        to_role="Frontend Developer",
        summary="Built FastAPI REST endpoints for tasks CRUD. Used SQLAlchemy async ORM "
                "with Pydantic v2 schemas. All endpoints tested with pytest.",
        files_created=["api/main.py", "api/models.py", "api/schemas.py", "api/routes/tasks.py"],
        files_edited=["requirements.txt", "pyproject.toml"],
        decisions=["SQLAlchemy async", "Pydantic v2", "JWT auth via python-jose"],
        next_steps="Build React components consuming /api/tasks — see OpenAPI at /docs",
    )
    block = h.to_context_block()
    assert len(block) < 1000, f"Block is {len(block)} chars, expected < 1000"


def test_worst_case_all_fields_maxed_under_1400_chars():
    """Even with all fields at their caps, total stays bounded."""
    h = AgentHandoff(
        from_role="A" * 50,
        to_role="B" * 50,
        summary="s" * 10_000,
        files_created=["f" * 30 for _ in range(100)],
        files_edited=["e" * 30 for _ in range(100)],
        decisions=["d" * 50 for _ in range(20)],
        next_steps="n" * 10_000,
    )
    block = h.to_context_block()
    # Theoretical max: header(~106) + summary(610) + decisions(212) +
    # created(160) + edited(159) + next(127) + newlines(5) ≈ 1379
    assert len(block) < 1400, f"Block is {len(block)} chars, expected < 1400"


def test_does_not_include_raw_full_output():
    """to_context_block() must not expose raw full output — only structured fields."""
    raw_output = "RAW_FULL_OUTPUT_MARKER_" + "x" * 5000
    # AgentHandoff has no 'raw_output' field — summary is the only text field
    # Passing a truncated summary should not leak the full raw text
    h = AgentHandoff(
        from_role="A",
        to_role="B",
        summary=raw_output[:600],  # only first 600 chars passed as summary
    )
    block = h.to_context_block()
    # The marker should appear (it's in the first 600 chars)
    assert "RAW_FULL_OUTPUT_MARKER_" in block
    # But the full 5000-char raw output should not be present
    assert len(block) < 2000
