"""Tests for widdx.hooks.session_log — session and task event logging."""
from __future__ import annotations

import json
import os
import sys
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from widdx.hooks.session_log import (
    LOG_DIR,
    ensure_log_dir,
    log_session_start,
    log_task_completed,
    main,
)


class TestEnsureLogDir:
    """ensure_log_dir creates the log directory."""

    def test_creates_directory(self, tmp_path: Path):
        with patch.object(os, "makedirs") as mock_makedirs:
            ensure_log_dir()
            mock_makedirs.assert_called_once_with(LOG_DIR, exist_ok=True)


class TestLogSessionStart:
    """log_session_start appends JSON to sessions.log."""

    def test_writes_session_entry(self, tmp_path: Path):
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch("widdx.hooks.session_log.ensure_log_dir"):
            log_session_start({"session_id": "abc123", "cwd": "/home/user"})
            log_file = tmp_path / "sessions.log"
            assert log_file.exists()
            lines = log_file.read_text(encoding="utf-8").strip().split("\n")
            assert len(lines) == 1
            entry = json.loads(lines[0])
            assert entry["event"] == "SessionStart"
            assert entry["session_id"] == "abc123"
            assert entry["cwd"] == "/home/user"
            assert "timestamp" in entry

    def test_default_session_id(self, tmp_path: Path):
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch("widdx.hooks.session_log.ensure_log_dir"):
            log_session_start({})
            log_file = tmp_path / "sessions.log"
            entry = json.loads(log_file.read_text(encoding="utf-8").strip())
            assert entry["session_id"] == "unknown"

    def test_appends_multiple(self, tmp_path: Path):
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch("widdx.hooks.session_log.ensure_log_dir"):
            log_session_start({"session_id": "s1"})
            log_session_start({"session_id": "s2"})
            lines = (tmp_path / "sessions.log").read_text(encoding="utf-8").strip().split("\n")
            assert len(lines) == 2


class TestLogTaskCompleted:
    """log_task_completed appends JSON to tasks.log."""

    def test_writes_task_entry(self, tmp_path: Path):
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch("widdx.hooks.session_log.ensure_log_dir"):
            log_task_completed({"session_id": "abc123"})
            log_file = tmp_path / "tasks.log"
            assert log_file.exists()
            entry = json.loads(log_file.read_text(encoding="utf-8").strip())
            assert entry["event"] == "TaskCompleted"
            assert entry["session_id"] == "abc123"
            assert "timestamp" in entry

    def test_default_session_id(self, tmp_path: Path):
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch("widdx.hooks.session_log.ensure_log_dir"):
            log_task_completed({})
            log_file = tmp_path / "tasks.log"
            entry = json.loads(log_file.read_text(encoding="utf-8").strip())
            assert entry["session_id"] == "unknown"

    def test_appends_multiple(self, tmp_path: Path):
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch("widdx.hooks.session_log.ensure_log_dir"):
            log_task_completed({"session_id": "t1"})
            log_task_completed({"session_id": "t2"})
            lines = (tmp_path / "tasks.log").read_text(encoding="utf-8").strip().split("\n")
            assert len(lines) == 2


class TestMain:
    """main() dispatches based on WIDDX_HOOK_EVENT."""

    def test_session_start_event(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("WIDDX_HOOK_EVENT", "SessionStart")
        stdin = StringIO(json.dumps({"session_id": "test123", "cwd": "/tmp"}))
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch.object(sys, "stdin", stdin), patch.object(sys, "exit"):
            main()
        log_file = tmp_path / "sessions.log"
        assert log_file.exists()
        entry = json.loads(log_file.read_text(encoding="utf-8").strip())
        assert entry["event"] == "SessionStart"
        assert entry["session_id"] == "test123"

    def test_task_completed_event(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("WIDDX_HOOK_EVENT", "TaskCompleted")
        stdin = StringIO(json.dumps({"session_id": "task123"}))
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch.object(sys, "stdin", stdin), patch.object(sys, "exit"):
            main()
        log_file = tmp_path / "tasks.log"
        assert log_file.exists()
        entry = json.loads(log_file.read_text(encoding="utf-8").strip())
        assert entry["event"] == "TaskCompleted"

    def test_unknown_event_does_nothing(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("WIDDX_HOOK_EVENT", "UnknownEvent")
        stdin = StringIO(json.dumps({}))
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch.object(sys, "stdin", stdin), patch.object(sys, "exit"):
            main()
        assert not (tmp_path / "sessions.log").exists()
        assert not (tmp_path / "tasks.log").exists()

    def test_no_event_does_nothing(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("WIDDX_HOOK_EVENT", raising=False)
        stdin = StringIO(json.dumps({}))
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch.object(sys, "stdin", stdin), patch.object(sys, "exit"):
            main()
        assert not (tmp_path / "sessions.log").exists()

    def test_invalid_json_handled(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("WIDDX_HOOK_EVENT", "SessionStart")
        stdin = StringIO("not json")
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), patch.object(sys, "stdin", stdin), patch.object(sys, "exit"):
            main()
        log_file = tmp_path / "sessions.log"
        assert log_file.exists()
        entry = json.loads(log_file.read_text(encoding="utf-8").strip())
        assert entry["session_id"] == "unknown"

    def test_event_from_argv_flag(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("WIDDX_HOOK_EVENT", raising=False)
        stdin = StringIO(json.dumps({"session_id": "cli123"}))
        with patch("widdx.hooks.session_log.LOG_DIR", str(tmp_path)), \
             patch.object(sys, "stdin", stdin), \
             patch.object(sys, "exit"), \
             patch.object(sys, "argv", ["script.py", "--event=TaskCompleted"]):
            main()
        log_file = tmp_path / "tasks.log"
        assert log_file.exists()
