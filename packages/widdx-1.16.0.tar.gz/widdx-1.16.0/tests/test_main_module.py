"""Tests for widdx.__main__ entry point."""
from __future__ import annotations

import importlib
import sys


class TestMainModule:
    """Test the `python -m widdx` entry point."""

    def test_module_can_be_imported(self):
        """__main__.py should be importable without errors."""
        import widdx.__main__  # noqa: F401

    def test_main_is_callable(self):
        """The main function imported from cli should exist."""
        from widdx.cli import main
        assert callable(main)

    def test_name_equals_main_imports_main(self):
        """Ensure __main__.py references cli.main."""
        # Clean reimport to verify structure
        if "widdx.__main__" in sys.modules:
            del sys.modules["widdx.__main__"]
        mod = importlib.import_module("widdx.__main__")
        assert hasattr(mod, "main")
        assert callable(mod.main)
