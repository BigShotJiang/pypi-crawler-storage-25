"""Tests for scaffolder.py — project scaffolding system."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from widdx.scaffolder import (
    FrameworkConfig,
    ScaffoldQuestion,
    ScaffoldResult,
    _FRAMEWORKS,
    _FRAMEWORK_PATTERNS,
    _resolve_option,
    _setup_env,
    detect_framework,
    scaffold,
)


# ── Data classes ────────────────────────────────────────────────────────

class TestScaffoldResult:
    def test_defaults(self):
        r = ScaffoldResult(framework="laravel", version="11.x", project_dir="/tmp/proj")
        assert r.framework == "laravel"
        assert r.answers == {}
        assert r.installed is False
        assert r.error == ""

    def test_success(self):
        r = ScaffoldResult(
            framework="react", version="latest",
            project_dir="/tmp/proj", installed=True, git_inited=True,
        )
        assert r.installed is True
        assert r.git_inited is True


class TestFrameworkConfig:
    def test_laravel_has_required_tools(self):
        cfg = _FRAMEWORKS["laravel"]
        assert cfg.required_tools == ["php", "composer"]

    def test_django_has_questions(self):
        cfg = _FRAMEWORKS["django"]
        assert len(cfg.questions) >= 1
        assert cfg.questions[0].key == "database"

    def test_all_frameworks_have_required_fields(self):
        for name, cfg in _FRAMEWORKS.items():
            assert cfg.required_tools, f"{name} missing required_tools"
            assert cfg.install_cmd, f"{name} missing install_cmd"
            assert cfg.versions, f"{name} missing versions"


# ── detect_framework ────────────────────────────────────────────────────

class TestDetectFramework:
    def test_laravel(self):
        result = detect_framework("create a laravel project")
        assert result is not None
        assert result[0] == "laravel"

    def test_django(self):
        result = detect_framework("build a django app")
        assert result is not None
        assert result[0] == "django"

    def test_react(self):
        result = detect_framework("make a react frontend")
        assert result is not None
        assert result[0] == "react"

    def test_nextjs(self):
        result = detect_framework("nextjs blog")
        assert result is not None
        assert result[0] == "nextjs"

    def test_fastapi(self):
        result = detect_framework("fastapi backend")
        assert result is not None
        assert result[0] == "fastapi"

    def test_unknown_returns_none(self):
        result = detect_framework("write a go program")
        assert result is None

    def test_case_insensitive(self):
        result = detect_framework("LARAVEL API")
        assert result is not None
        assert result[0] == "laravel"


# ── _resolve_option ────────────────────────────────────────────────────

class TestResolveOption:
    def test_full_name_match(self):
        q = ScaffoldQuestion(key="db", label="DB",
                             options=["MySQL", "PostgreSQL", "SQLite"])
        assert _resolve_option("MySQL", q) == "MySQL"

    def test_single_char_lowercase(self):
        q = ScaffoldQuestion(key="db", label="DB",
                             options=["MySQL", "PostgreSQL", "SQLite"])
        assert _resolve_option("p", q) == "PostgreSQL"

    def test_single_char_uppercase(self):
        q = ScaffoldQuestion(key="db", label="DB",
                             options=["MySQL", "PostgreSQL", "SQLite"])
        assert _resolve_option("S", q) == "SQLite"

    def test_empty_returns_default(self):
        q = ScaffoldQuestion(key="db", label="DB",
                             options=["MySQL", "PostgreSQL", "SQLite"],
                             default="SQLite")
        assert _resolve_option("", q) == "SQLite"

    def test_invalid_falls_back_to_default(self):
        q = ScaffoldQuestion(key="db", label="DB",
                             options=["MySQL", "PostgreSQL"],
                             default="MySQL")
        assert _resolve_option("x", q) == "MySQL"

    def test_empty_no_default_uses_first(self):
        q = ScaffoldQuestion(key="db", label="DB",
                             options=["MySQL", "PostgreSQL"])
        assert _resolve_option("", q) == "MySQL"


# ── _setup_env ─────────────────────────────────────────────────────────

class TestSetupEnv:
    def test_empty_template_returns_false(self, tmp_path):
        cfg = FrameworkConfig(label="Test", install_cmd="", versions=["1"],
                              env_template={})
        assert _setup_env(cfg, tmp_path, {}) is False

    def test_creates_env_file(self, tmp_path):
        cfg = FrameworkConfig(label="Test", install_cmd="", versions=["1"],
                              env_template={"KEY": "value", "DEBUG": "True"})
        result = _setup_env(cfg, tmp_path, {})
        assert result is True
        env_file = tmp_path / ".env"
        assert env_file.exists()
        content = env_file.read_text()
        assert "KEY=value" in content
        assert "DEBUG=True" in content

    def test_does_not_overwrite_existing_env(self, tmp_path):
        (tmp_path / ".env").write_text("EXISTING=1")
        cfg = FrameworkConfig(label="Test", install_cmd="", versions=["1"],
                              env_template={"NEW": "value"})
        result = _setup_env(cfg, tmp_path, {})
        assert result is False
        assert (tmp_path / ".env").read_text() == "EXISTING=1"

    def test_renders_project_name(self, tmp_path):
        cfg = FrameworkConfig(label="Test", install_cmd="", versions=["1"],
                              env_template={"DB": "{project_name}"})
        result = _setup_env(cfg, tmp_path, {})
        assert result is True
        assert f"DB={tmp_path.name}" in (tmp_path / ".env").read_text()


# ── _init_git ──────────────────────────────────────────────────────────

class TestInitGit:
    def test_runs_three_git_commands(self, tmp_path):
        with patch("widdx.scaffolder.subprocess.run") as run:
            run.return_value.returncode = 0
            from widdx.scaffolder import _init_git
            result = _init_git(tmp_path, "Laravel", "11.x")
            assert result is True
            assert run.call_count == 3

    def test_exception_returns_false(self, tmp_path):
        with patch("widdx.scaffolder.subprocess.run") as run:
            run.side_effect = OSError("git not found")
            from widdx.scaffolder import _init_git
            result = _init_git(tmp_path, "Test", "1.0")
            assert result is False


# ── _generate_hooks ────────────────────────────────────────────────────

class TestGenerateHooks:
    def test_hooks_have_flat_structure(self, tmp_path):
        with patch("widdx.scaffolder.subprocess.run"), \
             patch("widdx.scaffolder._silent_cmd"):
            from widdx.scaffolder import _generate_hooks
            _generate_hooks(tmp_path, "laravel", label="Laravel")
            hook_file = tmp_path / ".widdx" / "hooks.json"
            assert hook_file.exists()
            import json
            data = json.loads(hook_file.read_text())
            for hook_list in data.get("hooks", {}).values():
                for hook in hook_list:
                    assert "command" in hook, f"Hook missing command: {hook}"
                    assert "type" in hook, f"Hook missing type: {hook}"
                    assert "hooks" not in hook, f"Nested hooks found: {hook}"


# ── scaffold (full flow, mocked) ──────────────────────────────────────

class TestScaffold:
    def test_detects_laravel_and_returns_result(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check, \
             patch("widdx.scaffolder.ask_questions") as ask, \
             patch("widdx.scaffolder.subprocess.run") as run, \
             patch("widdx.scaffolder._setup_env") as setup_env, \
             patch("widdx.scaffolder._init_git") as init_git, \
             patch("widdx.scaffolder._create_widdx_dir"), \
             patch("widdx.scaffolder._generate_skills"), \
             patch("widdx.scaffolder._generate_hooks"), \
             patch("widdx.scaffolder._generate_mcp_config"):
            check.return_value.passed = True
            ask.return_value = {"version": "11.x", "database": "MySQL"}
            run.return_value.returncode = 0
            setup_env.return_value = True
            init_git.return_value = True

            result = scaffold("create a laravel project")
            assert result.framework == "laravel"
            assert result.installed is True
            assert result.version == "11.x"
            assert result.error == ""

    def test_unknown_framework_skips(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path):
            result = scaffold("build with cobol")
            assert result.skipped is True
            assert result.framework == "unknown"

    def test_missing_tools_returns_error(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check:
            check.return_value.passed = False
            check.return_value.missing = ["php"]
            result = scaffold("create a laravel project")
            assert result.error != ""
            assert "php" in result.error
            assert result.installed is False

    def test_install_failure_returns_error(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check, \
             patch("widdx.scaffolder.ask_questions") as ask, \
             patch("widdx.scaffolder.subprocess.run") as run:
            check.return_value.passed = True
            ask.return_value = {"version": "11.x"}
            run.return_value.returncode = 1
            run.return_value.stderr = "Composer error"

            result = scaffold("create a laravel project")
            assert result.error != ""
            assert result.installed is False

    def test_install_timeout_returns_error(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check, \
             patch("widdx.scaffolder.ask_questions") as ask, \
             patch("widdx.scaffolder.subprocess.run") as run:
            check.return_value.passed = True
            ask.return_value = {"version": "11.x"}
            from subprocess import TimeoutExpired
            run.side_effect = TimeoutExpired(cmd="test", timeout=300)

            result = scaffold("create a django app")
            assert "timed out" in result.error

    def test_preset_answers_skips_questions(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check, \
             patch("widdx.scaffolder.subprocess.run") as run, \
             patch("widdx.scaffolder._setup_env"), \
             patch("widdx.scaffolder._init_git"), \
             patch("widdx.scaffolder._create_widdx_dir"), \
             patch("widdx.scaffolder._generate_skills"), \
             patch("widdx.scaffolder._generate_hooks"), \
             patch("widdx.scaffolder._generate_mcp_config"), \
             patch("widdx.scaffolder.ask_questions") as ask:
            check.return_value.passed = True
            run.return_value.returncode = 0

            preset = {"version": "11.x", "database": "PostgreSQL"}
            result = scaffold("create a laravel project", answers=preset)
            assert result.answers["database"] == "PostgreSQL"
            ask.assert_not_called()

    def test_validates_version_against_allowed(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check, \
             patch("widdx.scaffolder.subprocess.run") as run, \
             patch("widdx.scaffolder._setup_env"), \
             patch("widdx.scaffolder._init_git"), \
             patch("widdx.scaffolder._create_widdx_dir"), \
             patch("widdx.scaffolder._generate_skills"), \
             patch("widdx.scaffolder._generate_hooks"), \
             patch("widdx.scaffolder._generate_mcp_config"):
            check.return_value.passed = True
            run.return_value.returncode = 0

            result = scaffold("create a laravel project",
                              answers={"version": "99.x"})
            assert result.installed is True

    def test_prefills_project_dir(self, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.preflight.check_requirements") as check, \
             patch("widdx.scaffolder.ask_questions") as ask, \
             patch("widdx.scaffolder.subprocess.run") as run, \
             patch("widdx.scaffolder._setup_env"), \
             patch("widdx.scaffolder._init_git"), \
             patch("widdx.scaffolder._create_widdx_dir"), \
             patch("widdx.scaffolder._generate_skills"), \
             patch("widdx.scaffolder._generate_hooks"), \
             patch("widdx.scaffolder._generate_mcp_config"):
            check.return_value.passed = True
            ask.return_value = {"version": "10.x"}
            run.return_value.returncode = 0

            custom_dir = tmp_path / "custom"
            custom_dir.mkdir()
            result = scaffold("create a laravel project",
                              project_dir=str(custom_dir))
            assert result.project_dir == str(custom_dir.resolve())
