"""Tests for widdx.permissions — deepen coverage from 41% to ~90%."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from widdx.permissions import PermissionManager


class TestInit:
    """PermissionManager.__init__ creates directory, loads existing data."""

    def test_default_init(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "perms.json"))
        assert pm._session_approved is True  # auto_approve=True by default
        assert pm._session_denied is False
        assert pm._asked_this_session is False
        assert pm._allowed_patterns == []
        assert pm._allowed_dirs == []

    def test_loads_existing_data(self, tmp_path: Path):
        path = tmp_path / "perms.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"patterns": ["npm *"], "dirs": ["/home"]}))
        pm = PermissionManager(str(path))
        assert pm._allowed_patterns == ["npm *"]
        assert pm._allowed_dirs == ["/home"]

    def test_load_corrupted_json(self, tmp_path: Path):
        path = tmp_path / "perms.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("not json")
        pm = PermissionManager(str(path))
        assert pm._allowed_patterns == []


class TestSave:
    """_save persists patterns and dirs."""

    def test_saves_patterns(self, tmp_path: Path):
        path = tmp_path / "perms.json"
        pm = PermissionManager(str(path))
        pm._allowed_patterns.append("git *")
        pm._save()
        data = json.loads(path.read_text())
        assert "git *" in data["patterns"]

    def test_saves_dirs(self, tmp_path: Path):
        path = tmp_path / "perms.json"
        pm = PermissionManager(str(path))
        pm._allowed_dirs.append("/tmp")
        pm._save()
        data = json.loads(path.read_text())
        assert "/tmp" in data["dirs"]


class TestSessionApproval:
    """approve_session / deny_session / is_session_approved."""

    def test_approve_session(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.approve_session()
        assert pm.is_session_approved is True
        assert pm._session_denied is False
        assert pm._asked_this_session is True

    def test_deny_session(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.deny_session()
        assert pm.is_session_approved is False
        assert pm._session_denied is True

    def test_is_session_approved_true_by_default(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm.is_session_approved is True  # auto_approve=True by default


class TestAlwaysConfirm:
    """_is_always_confirm detects destructive patterns."""

    def test_rm_rf(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_always_confirm("rm -rf /tmp") is True

    def test_drop_table(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_always_confirm("DROP TABLE users") is True

    def test_drop_database(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_always_confirm("DROP DATABASE prod") is True

    def test_case_insensitive(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_always_confirm("drop table users") is True

    def test_safe_command_not_always_confirm(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_always_confirm("echo hello") is False


class TestSafeCommand:
    """_is_safe_command identifies read-only commands."""

    def test_echo_is_safe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("echo hello") is True

    def test_ls_is_safe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("ls -la") is True

    def test_git_status_is_safe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("git status") is True

    def test_pip_list_is_safe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("pip list") is True

    def test_chain_operator_unsafe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("echo hello && rm -rf /") is False

    def test_semicolon_chain_unsafe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("ls; rm -rf /") is False

    def test_pipe_unsafe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("ls | cat") is False

    def test_destructive_command_unsafe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("rm -rf /tmp") is False

    def test_dir_is_safe(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm._is_safe_command("dir") is True


class TestIsPreapproved:
    """_is_preapproved checks patterns and directories."""

    def test_matching_pattern(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm._allowed_patterns = ["npm *"]
        assert pm._is_preapproved("npm install", "", "shell") is True

    def test_non_matching_pattern(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm._allowed_patterns = ["npm *"]
        assert pm._is_preapproved("git push", "", "shell") is False

    def test_cwd_in_allowed_dir(self, tmp_path: Path, monkeypatch):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm._allowed_dirs = [str(tmp_path)]
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            assert pm._is_preapproved("any", "", "shell") is True

    def test_cwd_not_in_allowed_dir(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm._allowed_dirs = ["/some/other/path"]
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            assert pm._is_preapproved("any", "", "shell") is False


class TestAsk:
    """ask() decision tree."""

    def test_file_always_allow(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        assert pm.ask("write", "file.py", category="file") == "allow"

    def test_session_denied_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.deny_session()
        assert pm.ask("run", "echo hello") == "deny"

    def test_session_approved_allows(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.approve_session()
        assert pm.ask("run", "echo hello") == "allow"

    def test_safe_command_allowed_without_ask(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        result = pm.ask("run", "ls -la")
        assert result == "allow"
        assert pm._asked_this_session is False

    def test_preapproved_pattern_allows(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm._allowed_patterns = ["git push"]
        assert pm.ask("git push", "git push origin main") == "allow"

    def test_destructive_always_confirms(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.approve_session()
        with patch("builtins.input", return_value="y"):
            result = pm.ask("shell", "rm -rf /tmp")
            assert result == "allow"

    def test_first_shell_asks_session_approval(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="y"):
            result = pm.ask("run", "npm install")
            assert result == "allow"
            assert pm._session_approved is True

    def test_first_shell_reject_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"), auto_approve=False)
        with patch("builtins.input", return_value="n"):
            result = pm.ask("run", "npm install")
            assert result == "deny"
            assert pm._session_denied is True

    def test_second_shell_after_deny(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"), auto_approve=False)
        with patch("builtins.input", return_value="n"):
            pm.ask("run", "npm install")
            result = pm.ask("run", "pip install")
            assert result == "deny"


class TestAskWithEdit:
    """ask_with_edit — destructive command with editing."""

    def test_session_denied_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.deny_session()
        result, detail = pm.ask_with_edit("run", "rm file.txt")
        assert result == "deny"

    def test_session_approved_no_destructive_allows(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        pm.approve_session()
        result, detail = pm.ask_with_edit("run", "echo hello")
        assert result == "allow"

    @pytest.mark.skip(reason="prompt_toolkit incompatible with non-Windows console in test env")
    def test_destructive_not_approved_asks(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="y"):
            result, detail = pm.ask_with_edit("run", "rm -rf /tmp")
            assert result == "allow"

    @pytest.mark.skip(reason="prompt_toolkit incompatible with non-Windows console in test env")
    def test_empty_edit_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value=""):
            result, detail = pm.ask_with_edit("run", "rm file.txt")
            assert result == "deny"

    @pytest.mark.skip(reason="prompt_toolkit incompatible with non-Windows console in test env")
    def test_keyboard_interrupt_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            result, detail = pm.ask_with_edit("run", "rm file.txt")
            assert result == "deny"


class TestConfirmInline:
    """_confirm_inline asks for destructive command confirmation."""

    def test_yes_allows(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="y"):
            assert pm._confirm_inline("run", "rm file.txt") == "allow"

    def test_no_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="n"):
            assert pm._confirm_inline("run", "rm file.txt") == "deny"

    def test_empty_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value=""):
            assert pm._confirm_inline("run", "rm file.txt") == "deny"

    def test_yes_uppercase_allows(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="YES"):
            assert pm._confirm_inline("run", "rm file.txt") == "allow"

    def test_eof_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", side_effect=EOFError):
            assert pm._confirm_inline("run", "rm file.txt") == "deny"


class TestAskSessionApproval:
    """_ask_session_approval prompts user once."""

    def test_yes_approves(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="y"):
            assert pm._ask_session_approval("npm install") == "allow"
            assert pm._session_approved is True

    def test_no_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="n"):
            assert pm._ask_session_approval("npm install") == "deny"
            assert pm._session_denied is True

    def test_empty_defaults_to_yes(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value=""):
            assert pm._ask_session_approval("npm install") == "allow"

    def test_yes_uppercase_approves(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", return_value="YES"):
            assert pm._ask_session_approval("npm install") == "allow"

    def test_eof_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", side_effect=EOFError):
            assert pm._ask_session_approval("npm install") == "deny"

    def test_keyboard_interrupt_denies(self, tmp_path: Path):
        pm = PermissionManager(str(tmp_path / "p.json"))
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            assert pm._ask_session_approval("npm install") == "deny"
