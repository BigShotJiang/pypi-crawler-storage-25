"""Tests for tool_loop/system_prompt.py framework detection and rules."""
from __future__ import annotations

import pytest

from widdx.tool_loop.system_prompt import (
    _detect_framework_from_task,
    _framework_prompt_section,
    _FRAMEWORK_RULES,
    _DEFAULT_FRAMEWORK_RULES,
)


class TestDetectFrameworkFromTask:
    def test_detect_laravel(self):
        assert _detect_framework_from_task("Laravel blog with admin panel") == ("laravel", "PHP")

    def test_detect_django(self):
        assert _detect_framework_from_task("Django project for e-commerce") == ("django", "Python")

    def test_detect_fastapi(self):
        assert _detect_framework_from_task("FastAPI microservice with PostgreSQL") == ("fastapi", "Python")

    def test_detect_react(self):
        assert _detect_framework_from_task("React frontend for dashboard") == ("react", "JavaScript")

    def test_detect_nextjs(self):
        assert _detect_framework_from_task("Next.js landing page") == ("nextjs", "JavaScript")

    def test_detect_vue(self):
        assert _detect_framework_from_task("Vue 3 composition api app") == ("vue", "JavaScript")

    def test_detect_angular(self):
        assert _detect_framework_from_task("Angular enterprise app") == ("angular", "JavaScript")

    def test_detect_svelte(self):
        assert _detect_framework_from_task("SvelteKit project with auth") == ("svelte", "JavaScript")

    def test_detect_svelte_bare(self):
        assert _detect_framework_from_task("Svelte component library") == ("svelte", "JavaScript")

    def test_detect_express(self):
        assert _detect_framework_from_task("Express.js API server") == ("express", "JavaScript")

    def test_detect_node(self):
        assert _detect_framework_from_task("Node.js backend service") == ("node", "JavaScript")

    def test_detect_spring(self):
        assert _detect_framework_from_task("Create a Spring Boot REST API") == ("spring", "Java")

    def test_detect_rails(self):
        assert _detect_framework_from_task("Build a Rails app with authentication") == ("rails", "Ruby")

    def test_detect_go(self):
        assert _detect_framework_from_task("Go REST API server") == ("go", "Go")

    def test_detect_golang(self):
        assert _detect_framework_from_task("Golang microservice") == ("go", "Go")

    def test_detect_gin(self):
        assert _detect_framework_from_task("Gin web framework app") == ("gin", "Go")

    def test_detect_flutter(self):
        assert _detect_framework_from_task("Flutter mobile app") == ("flutter", "Dart")

    def test_detect_wordpress(self):
        assert _detect_framework_from_task("WordPress plugin development") == ("wordpress", "PHP")

    def test_detect_symfony(self):
        assert _detect_framework_from_task("Symfony e-commerce site") == ("symfony", "PHP")

    def test_detect_flask(self):
        assert _detect_framework_from_task("Flask web application") == ("flask", "Python")

    def test_detect_rust(self):
        assert _detect_framework_from_task("build a rust CLI tool") == ("rust", "Rust")

    def test_detect_unknown(self):
        assert _detect_framework_from_task("Fix a bug in the code") is None

    def test_detect_case_insensitive(self):
        assert _detect_framework_from_task("LARAVEL API") == ("laravel", "PHP")
        assert _detect_framework_from_task("DJANGO APP") == ("django", "Python")


class TestFrameworkPromptSection:
    def test_every_framework_has_rules(self):
        """Every framework in _FRAMEWORK_RULES should have content."""
        for key, value in _FRAMEWORK_RULES.items():
            assert len(value) > 100, f"{key} rules too short ({len(value)} chars)"

    def test_laravel_rules(self):
        rules = _framework_prompt_section("laravel", "PHP")
        assert "Eloquent" in rules
        assert "Blade" in rules
        assert "Artisan" in rules

    def test_spring_rules(self):
        rules = _framework_prompt_section("spring", "Java")
        assert "Spring Boot" in rules
        assert "@RestController" in rules
        assert "Lombok" in rules

    def test_rails_rules(self):
        rules = _framework_prompt_section("rails", "Ruby")
        assert "Rails" in rules
        assert "Active Record" in rules
        assert "Gemfile" in rules

    def test_go_rules(self):
        rules = _framework_prompt_section("go", "Go")
        assert "goroutines" in rules.lower()
        assert "gofmt" in rules.lower()

    def test_svelte_rules(self):
        rules = _framework_prompt_section("svelte", "JavaScript")
        assert "Svelte" in rules
        assert "SvelteKit" in rules

    def test_flutter_rules(self):
        rules = _framework_prompt_section("flutter", "Dart")
        assert "Flutter" in rules
        assert "pubspec.yaml" in rules

    def test_default_language_rules_fallback(self):
        """When framework is unknown, falls back to language rules."""
        rules = _framework_prompt_section("unknown_framework", "Python")
        assert "PEP 8" in rules

    def test_default_ruby_rules(self):
        rules = _framework_prompt_section("unknown", "Ruby")
        assert "RSpec" in rules
        assert "Gemfile" in rules

    def test_default_java_rules(self):
        rules = _framework_prompt_section("unknown", "Java")
        assert "JUnit" in rules
        assert "Mockito" in rules

    def test_default_go_rules(self):
        rules = _framework_prompt_section("unknown", "Go")
        assert "gofmt" in rules

    def test_default_rules_have_content(self):
        """All default language rules should have content."""
        for lang, value in _DEFAULT_FRAMEWORK_RULES.items():
            assert len(value) > 50, f"{lang} default rules too short"


class TestFrameworkRegistry:
    def test_all_frameworks_have_detection_and_rules(self):
        """Every framework in _TASK_FRAMEWORK_PATTERNS should have rules."""
        from widdx.tool_loop.system_prompt import _TASK_FRAMEWORK_PATTERNS
        keys = {key for key, _, _ in _TASK_FRAMEWORK_PATTERNS}
        for key in keys:
            assert key in _FRAMEWORK_RULES, f"{key} has detection but no rules"

    def test_detect_go_ignores_going(self):
        """The word "going" should not match the "go" pattern."""
        assert _detect_framework_from_task("going to fix the code") is None
        assert _detect_framework_from_task("going forward with the build") is None
