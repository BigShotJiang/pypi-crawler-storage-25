"""Tests for pipeline/verify.py — post-generation static analysis."""
from __future__ import annotations

import pytest

from widdx.pipeline.verify import verify_project, Issue


class TestVerifyProject:
    def test_empty_project_returns_no_issues(self, tmp_path):
        issues = verify_project(tmp_path)
        assert issues == []


class TestBcryptCompatibility:
    def test_passlib_with_unpinned_bcrypt_warns(self, tmp_path):
        req = tmp_path / "requirements.txt"
        req.write_text("fastapi\npasslib[bcrypt]\nbcrypt\n", encoding="utf-8")
        issues = verify_project(tmp_path)
        bcrypt_issues = [i for i in issues if "bcrypt" in i.message.lower()]
        assert any(i.severity == "warning" for i in bcrypt_issues)

    def test_passlib_with_bcrypt_4_1_errors(self, tmp_path):
        req = tmp_path / "requirements.txt"
        req.write_text("fastapi\npasslib[bcrypt]\nbcrypt>=4.1.0\n", encoding="utf-8")
        issues = verify_project(tmp_path)
        bcrypt_issues = [i for i in issues if "bcrypt" in i.message.lower()]
        assert any(i.severity == "error" for i in bcrypt_issues)

    def test_passlib_with_bcrypt_4_0_1_ok(self, tmp_path):
        req = tmp_path / "requirements.txt"
        req.write_text("fastapi\npasslib[bcrypt]\nbcrypt==4.0.1\n", encoding="utf-8")
        issues = verify_project(tmp_path)
        bcrypt_issues = [i for i in issues if "bcrypt" in i.message.lower()]
        assert not bcrypt_issues


class TestDatetimeUsage:
    def test_datetime_now_without_timezone_warns(self, tmp_path):
        src = tmp_path / "app" / "main.py"
        src.parent.mkdir(parents=True)
        src.write_text("from datetime import datetime\nnow = datetime.now()\n", encoding="utf-8")
        issues = verify_project(tmp_path)
        datetime_issues = [i for i in issues if "timezone" in i.message.lower()]
        assert any(i.severity == "warning" for i in datetime_issues)

    def test_datetime_now_with_timezone_ok(self, tmp_path):
        src = tmp_path / "app" / "main.py"
        src.parent.mkdir(parents=True)
        src.write_text(
            "from datetime import datetime, timezone\nnow = datetime.now(timezone.utc)\n",
            encoding="utf-8",
        )
        issues = verify_project(tmp_path)
        datetime_issues = [i for i in issues if "timezone" in i.message.lower()]
        assert not datetime_issues


class TestPydanticModels:
    def test_id_str_in_pydantic_warns(self, tmp_path):
        src = tmp_path / "app" / "schemas.py"
        src.parent.mkdir(parents=True)
        src.write_text(
            "from pydantic import BaseModel\n\nclass UserResponse(BaseModel):\n    id: str\n    name: str\n",
            encoding="utf-8",
        )
        issues = verify_project(tmp_path)
        pydantic_issues = [i for i in issues if "UUID" in i.message]
        assert any(i.severity == "warning" for i in pydantic_issues)

    def test_id_uuid_in_pydantic_ok(self, tmp_path):
        src = tmp_path / "app" / "schemas.py"
        src.parent.mkdir(parents=True)
        src.write_text(
            "from pydantic import BaseModel\nfrom uuid import UUID\n\nclass UserResponse(BaseModel):\n    id: UUID\n    name: str\n",
            encoding="utf-8",
        )
        issues = verify_project(tmp_path)
        pydantic_issues = [i for i in issues if "UUID" in i.message]
        assert not pydantic_issues


class TestImportPaths:
    def test_nonexistent_module_errors(self, tmp_path):
        src = tmp_path / "app" / "main.py"
        src.parent.mkdir(parents=True)
        src.write_text("from app.repository.user_repository import UserRepository\n", encoding="utf-8")
        issues = verify_project(tmp_path)
        import_issues = [i for i in issues if "does not match" in i.message]
        assert any(i.severity == "error" for i in import_issues)

    def test_existing_module_ok(self, tmp_path):
        src = tmp_path / "app" / "main.py"
        src.parent.mkdir(parents=True)
        repo = tmp_path / "app" / "repositories" / "user_repository.py"
        repo.parent.mkdir(parents=True)
        repo.write_text("# UserRepository\n", encoding="utf-8")
        src.write_text("from app.repositories.user_repository import UserRepository\n", encoding="utf-8")
        issues = verify_project(tmp_path)
        import_issues = [i for i in issues if "does not match" in i.message]
        assert not import_issues
