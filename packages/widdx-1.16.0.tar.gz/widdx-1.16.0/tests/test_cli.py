"""Tests for widdx/__main__.py and widdx/cli.py (module-level, no LLM)."""
import sys
import pytest


class TestMainModule:
    def test_main_importable(self):
        import widdx.__main__

    def test_cli_importable(self):
        from widdx.cli import main

    def test_cli_group_exists(self):
        from widdx.cli import WIDDXGroup
        assert issubclass(WIDDXGroup, __import__("click").Group)

    def test_provider_color(self):
        from widdx.cli import _provider_color
        c = _provider_color("deepseek")
        assert isinstance(c, str) and c, "Should return non-empty string"

    def test_schedule_commands_exist(self):
        from widdx.cli import schedule, schedule_add, schedule_list, schedule_remove, schedule_run
        assert schedule is not None

    def test_bot_commands_exist(self):
        from widdx.cli import bot, bot_start
        assert bot is not None

    def test_web_command_exists(self):
        from widdx.cli import web_cmd
        assert web_cmd is not None

    def test_self_upgrade_command_exists(self):
        from widdx.cli import self_upgrade_cmd
        assert self_upgrade_cmd is not None


class TestFirstRunSetup:
    def test_module_functions_importable(self):
        from widdx.cli import (
            _first_run_setup,
            _prompt_key,
            _check_for_updates,
            _check_crash_recovery,
            _self_check,
            _mark_setup_skipped,
            _start_repl,
            _ensure_widdx_in_path,
        )

    def test_self_check_runs_without_error(self):
        from widdx.cli import _self_check
        _self_check()  # Should run without crashing

    def test_check_for_updates_no_crash(self):
        from widdx.cli import _check_for_updates
        _check_for_updates()  # Should handle gracefully

    def test_ensure_widdx_in_path_no_crash(self):
        from widdx.cli import _ensure_widdx_in_path
        try:
            _ensure_widdx_in_path()
        except Exception:
            pass  # May fail on restricted systems, but not crash unrecoverably

    def test_crash_recovery_returns_none_or_str(self):
        from widdx.cli import _check_crash_recovery
        import os
        # Suppress interactive prompt via env var
        os.environ["WIDDX_NONINTERACTIVE"] = "1"
        try:
            result = _check_crash_recovery()
            assert result is None or isinstance(result, str)
        except (OSError, EOFError):
            pytest.skip("Cannot test interactive function in CI")

    def test_first_run_setup_with_empty_config(self):
        pytest.skip("Requires interactive TTY — tested manually")

    def test_provider_key_prompt_exists(self):
        from widdx.cli import _prompt_key
        assert callable(_prompt_key)
