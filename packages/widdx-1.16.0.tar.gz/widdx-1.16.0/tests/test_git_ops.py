"""Tests for widdx/git_ops.py."""
import pytest
from widdx.git_ops import GitOps


class TestGitOpsNotInRepo:
    def test_creates_with_default_path(self):
        g = GitOps()
        assert isinstance(g.is_repo, bool)

    def test_not_repo_returns_error(self):
        g = GitOps(repo_path="/tmp/nonexistent_dir_xyz")
        if not g.is_repo:
            result = g.status()
            assert "error" in result

    def test_git_not_found_handled(self):
        from pathlib import Path
        import tempfile, os
        with tempfile.TemporaryDirectory() as td:
            g = GitOps(repo_path=td)
            # Not a git repo, but shouldn't crash
            assert g.is_repo is False

    def test_find_repo_root_nonexistent(self):
        from pathlib import Path
        result = GitOps._find_repo_root(Path("/tmp/nonexistent_dir_xyz"))
        assert result is None


class TestGitOpsCoreProperties:
    def test_class_exists(self):
        assert GitOps is not None

    def test_static_methods_exist(self):
        assert hasattr(GitOps, "_find_repo_root")
        assert callable(GitOps._find_repo_root)

    def test_instance_methods_exist(self):
        methods = ["status", "diff", "current_branch", "commit", "log",
                   "push", "pull", "stash", "stash_pop", "has_changes",
                   "create_branch", "add_all_tracked", "create_pr"]
        for m in methods:
            assert hasattr(GitOps, m), f"Missing method: {m}"

    def test_is_repo_property_exists(self):
        assert hasattr(GitOps, "is_repo")
