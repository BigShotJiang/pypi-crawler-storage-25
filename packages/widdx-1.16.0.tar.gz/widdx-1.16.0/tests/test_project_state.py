"""Tests for widdx.project_state — .widdx/ directory state management."""
from __future__ import annotations

import json
from pathlib import Path

from widdx.project_state import (
    ProjectState,
    get_widdx_dir,
    list_snapshots,
    load_state,
    save_session_snapshot,
    save_state,
)


class TestGetWiddxDir:
    """get_widdx_dir creates the directory structure."""

    def test_creates_directory(self, tmp_path: Path):
        wd = get_widdx_dir(tmp_path)
        assert wd.exists()
        assert wd.name == ".widdx"

    def test_creates_skills_subdir(self, tmp_path: Path):
        wd = get_widdx_dir(tmp_path)
        assert (wd / "skills").exists()

    def test_creates_sessions_subdir(self, tmp_path: Path):
        wd = get_widdx_dir(tmp_path)
        assert (wd / "sessions").exists()

    def test_idempotent(self, tmp_path: Path):
        wd1 = get_widdx_dir(tmp_path)
        wd2 = get_widdx_dir(tmp_path)
        assert wd1 == wd2

    def test_defaults_to_cwd(self):
        wd = get_widdx_dir()
        assert wd.name == ".widdx"


class TestSaveLoadState:
    """save_state / load_state round-trip."""

    def test_roundtrip(self, tmp_path: Path):
        state = ProjectState(
            framework="django", framework_version="4.2",
            project_name="myapp", phases_total=3, phases_completed=1,
            decisions=["use-postgres"],
        )
        save_state(state, tmp_path)
        loaded = load_state(tmp_path)
        assert loaded is not None
        assert loaded.framework == "django"
        assert loaded.framework_version == "4.2"
        assert loaded.project_name == "myapp"
        assert loaded.phases_total == 3
        assert loaded.phases_completed == 1
        assert loaded.decisions == ["use-postgres"]

    def test_updated_at_is_set(self, tmp_path: Path):
        state = ProjectState(framework="flask")
        save_state(state, tmp_path)
        loaded = load_state(tmp_path)
        assert loaded is not None
        assert loaded.updated_at != ""

    def test_load_missing_returns_none(self, tmp_path: Path):
        wd = tmp_path / ".widdx"
        wd.mkdir()
        # No project.json written
        assert load_state(tmp_path) is None

    def test_load_corrupted_returns_none(self, tmp_path: Path):
        wd = get_widdx_dir(tmp_path)
        (wd / "project.json").write_text("not json", encoding="utf-8")
        assert load_state(tmp_path) is None

    def test_load_no_widdx_dir_returns_none(self, tmp_path: Path):
        # Directory doesn't exist at all
        missing = tmp_path / "nonexistent"
        assert load_state(missing) is None


class TestSaveSessionSnapshot:
    """save_session_snapshot writes session files."""

    def test_writes_file(self, tmp_path: Path):
        messages = [{"role": "user", "content": "hello"}]
        path = save_session_snapshot(messages, tmp_path)
        assert path is not None
        assert Path(path).exists()
        assert "session_" in Path(path).name

    def test_includes_message_count(self, tmp_path: Path):
        messages = [{"role": "user", "content": "hi"}]
        path = save_session_snapshot(messages, tmp_path)
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        assert data["message_count"] == 1

    def test_truncates_to_last_50(self, tmp_path: Path):
        messages = [{"role": "user", "content": f"msg{i}"} for i in range(100)]
        path = save_session_snapshot(messages, tmp_path)
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        assert data["message_count"] == 100
        assert len(data["messages"]) == 50

    def test_empty_messages_still_writes(self, tmp_path: Path):
        path = save_session_snapshot([], tmp_path)
        assert path is not None
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        assert data["message_count"] == 0
        assert data["messages"] == []


class TestListSnapshots:
    """list_snapshots enumerates saved sessions."""

    def test_empty_returns_empty_list(self, tmp_path: Path):
        assert list_snapshots(tmp_path) == []

    def test_lists_snapshots(self, tmp_path: Path):
        import time
        save_session_snapshot([{"role": "user", "content": "a"}], tmp_path)
        time.sleep(1.1)  # ensure distinct timestamp filenames (1s resolution)
        save_session_snapshot([{"role": "user", "content": "b"}], tmp_path)
        snaps = list_snapshots(tmp_path)
        assert len(snaps) >= 2
        for s in snaps:
            assert "file" in s
            assert "saved_at" in s
            assert "messages" in s

    def test_handles_corrupted_file(self, tmp_path: Path):
        wd = get_widdx_dir(tmp_path)
        bad = wd / "sessions" / "session_bad.json"
        bad.write_text("not json", encoding="utf-8")
        # Also add a valid one
        save_session_snapshot([{"role": "user", "content": "ok"}], tmp_path)
        snaps = list_snapshots(tmp_path)
        assert len(snaps) == 1
