"""
tests/test_mcp.py — Unit tests for MCPRegistry (task 6.1)

Uses a lightweight mock MCPClient so tests run without any real MCP server.
"""

from __future__ import annotations

import json
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers — inject a fake widdx.mcp.client module so MCPRegistry can import
# MCPClient without task 6.2 being implemented yet.
# ---------------------------------------------------------------------------


def _make_fake_client_module(connect_raises=None, list_tools_return=None, call_tool_return=None):
    """Return a fake widdx.mcp.client module with a configurable MCPClient."""

    class FakeMCPClient:
        def __init__(self, name, command, args=None, env=None):
            self.name = name
            self.command = command
            self.args = args or []
            self.env = env

        def connect(self):
            if connect_raises:
                raise connect_raises

        def list_tools(self):
            return list_tools_return or []

        def call_tool(self, name, arguments):
            if call_tool_return is not None:
                return call_tool_return
            return {"result": f"called {name}"}

    class FakeMCPHTTPClient:
        def __init__(self, name, url, headers=None):
            self.name = name
            self.url = url
            self.headers = headers

        def connect(self):
            if connect_raises:
                raise connect_raises

        def list_tools(self):
            return list_tools_return or []

        def call_tool(self, name, arguments):
            if call_tool_return is not None:
                return call_tool_return
            return {"result": f"called {name}"}

    fake_module = types.ModuleType("widdx.mcp.client")
    fake_module.MCPClient = FakeMCPClient
    fake_module.MCPHTTPClient = FakeMCPHTTPClient
    return fake_module


def _patch_client(connect_raises=None, list_tools_return=None, call_tool_return=None):
    """Context manager: patch widdx.mcp.client with a fake implementation."""
    fake = _make_fake_client_module(connect_raises, list_tools_return, call_tool_return)
    return patch.dict(sys.modules, {"widdx.mcp.client": fake})


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mcp_json(tmp_path):
    """Write a minimal mcp.json and return its path."""

    def _write(servers: dict) -> Path:
        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({"mcpServers": servers}), encoding="utf-8")
        return cfg

    return _write


# ---------------------------------------------------------------------------
# MCPRegistry.__init__
# ---------------------------------------------------------------------------


class TestMCPRegistryInit:
    def test_default_config_path(self):
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry()
        assert reg._config_path == Path("~/.widdx/mcp.json").expanduser()

    def test_custom_config_path(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "custom.json"
        reg = MCPRegistry(config_path=str(cfg))
        assert reg._config_path == cfg

    def test_initial_state_empty(self):
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry()
        assert reg._servers == {}
        assert reg._tools == []


# ---------------------------------------------------------------------------
# MCPRegistry.load — config file handling
# ---------------------------------------------------------------------------


class TestMCPRegistryLoad:
    def test_missing_config_is_silent(self, tmp_path):
        """No mcp.json → load() succeeds and built-in servers are loaded."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path=str(tmp_path / "nonexistent.json"))
        reg.load()  # must not raise
        assert "project-info" in reg._servers
        assert "utility" in reg._servers
        assert len(reg._tools) > 0

    def test_malformed_json_is_logged_not_raised(self, tmp_path, caplog):
        from widdx.mcp import MCPRegistry

        bad = tmp_path / "mcp.json"
        bad.write_text("{not valid json", encoding="utf-8")
        reg = MCPRegistry(config_path=str(bad))
        import logging

        with caplog.at_level(logging.WARNING):
            reg.load()
        # Built-in servers still load even when external config is malformed
        assert "project-info" in reg._servers
        assert "utility" in reg._servers

    def test_missing_mcp_servers_key(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({}), encoding="utf-8")
        reg = MCPRegistry(config_path=str(cfg))
        reg.load()
        assert "project-info" in reg._servers
        assert "utility" in reg._servers

    def test_invalid_mcp_servers_type(self, tmp_path, caplog):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({"mcpServers": "not-a-dict"}), encoding="utf-8")
        reg = MCPRegistry(config_path=str(cfg))
        import logging

        with caplog.at_level(logging.WARNING):
            reg.load()
        assert "project-info" in reg._servers
        assert "utility" in reg._servers

    def test_server_without_command_is_skipped(self, tmp_path, caplog):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"bad": {"args": ["x"]}}}), encoding="utf-8"
        )
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client():
            import logging

            with caplog.at_level(logging.WARNING):
                reg.load()
        assert "bad" not in reg._servers

    def test_connection_failure_skips_server(self, tmp_path, caplog):
        """REQ-1 criterion 4: connection failure → log warning, continue."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"broken": {"command": "uvx", "args": ["bad"]}}}),
            encoding="utf-8",
        )
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(connect_raises=ConnectionError("refused")):
            import logging

            with caplog.at_level(logging.WARNING):
                reg.load()
        assert "broken" not in reg._servers
        assert "project-info" in reg._servers
        assert "utility" in reg._servers
        assert len(reg._tools) >= 6  # built-in servers contribute 6 tools

    def test_successful_load_populates_servers_and_tools(self, tmp_path):
        """REQ-1 criteria 1 & 2: servers connect and tools appear."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"gh": {"command": "uvx", "args": ["mcp-server-github"]}}}),
            encoding="utf-8",
        )
        fake_tools = [
            {
                "name": "create_issue",
                "description": "Create a GitHub issue",
                "inputSchema": {
                    "type": "object",
                    "properties": {"title": {"type": "string"}},
                    "required": ["title"],
                },
            }
        ]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools):
            reg.load()

        assert "gh" in reg._servers
        assert "project-info" in reg._servers
        assert "utility" in reg._servers
        assert len(reg._tools) == 7  # 6 built-in + 1 external
        # External tool should be namespaced correctly
        gh_tools = [t for t in reg._tools if t["name"].startswith("mcp__gh__")]
        assert gh_tools[0]["name"] == "mcp__gh__create_issue"


# ---------------------------------------------------------------------------
# MCPRegistry.tool_definitions
# ---------------------------------------------------------------------------


class TestToolDefinitions:
    def test_returns_copy_of_tools(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"srv": {"command": "cmd"}}}), encoding="utf-8"
        )
        fake_tools = [{"name": "ping", "description": "Ping", "inputSchema": {"type": "object"}}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools):
            reg.load()

        defs = reg.tool_definitions()
        assert isinstance(defs, list)
        srv_tools = [t for t in defs if t["name"].startswith("mcp__srv__")]
        assert srv_tools[0]["name"] == "mcp__srv__ping"

    def test_empty_when_no_servers(self, tmp_path):
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path=str(tmp_path / "none.json"))
        reg.load()
        # Built-in servers always contribute tools
        assert len(reg.tool_definitions()) >= 6

    def test_tool_schema_preserved(self, tmp_path):
        """The inputSchema from the MCP server is passed through unchanged."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"db": {"command": "uvx"}}}), encoding="utf-8"
        )
        schema = {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        }
        fake_tools = [{"name": "run_query", "description": "Run SQL", "inputSchema": schema}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools):
            reg.load()

        db_tools = [t for t in reg.tool_definitions() if t["name"].startswith("mcp__db__")]
        assert db_tools[0]["schema"] == schema

    def test_tool_without_input_schema_gets_empty_schema(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"s": {"command": "cmd"}}}), encoding="utf-8"
        )
        fake_tools = [{"name": "noop", "description": "Does nothing"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools):
            reg.load()

        s_tools = [t for t in reg.tool_definitions() if t["name"].startswith("mcp__s__")]
        tool_def = s_tools[0]
        assert tool_def["schema"]["type"] == "object"
        assert tool_def["schema"]["properties"] == {}


# ---------------------------------------------------------------------------
# MCPRegistry.execute
# ---------------------------------------------------------------------------


class TestMCPRegistryExecute:
    def _registry_with_server(self, tmp_path, server_name="gh", call_tool_return=None):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {server_name: {"command": "uvx"}}}), encoding="utf-8"
        )
        fake_tools = [{"name": "do_thing", "description": "Does a thing"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools, call_tool_return=call_tool_return):
            reg.load()
        return reg

    def test_routes_to_correct_server(self, tmp_path):
        """REQ-1 criterion 3: MCP tool call is routed and result returned."""
        reg = self._registry_with_server(tmp_path, call_tool_return={"data": "ok"})
        result = reg.execute("mcp__gh__do_thing", {"x": 1})
        assert result == {"data": "ok"}

    def test_invalid_tool_name_format(self, tmp_path):
        reg = self._registry_with_server(tmp_path)
        result = reg.execute("bad_name", {})
        assert "error" in result

    def test_unknown_server_returns_error(self, tmp_path):
        reg = self._registry_with_server(tmp_path)
        result = reg.execute("mcp__unknown__tool", {})
        assert "error" in result
        assert "unknown" in result["error"]

    def test_tool_call_exception_returns_error(self, tmp_path):
        """REQ-1 criterion 4: tool call failure → error dict, no exception."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"srv": {"command": "cmd"}}}), encoding="utf-8"
        )

        class ExplodingClient:
            def __init__(self, **kw):
                pass

            def connect(self):
                pass

            def list_tools(self):
                return [{"name": "boom", "description": "Explodes"}]

            def call_tool(self, name, args):
                raise RuntimeError("server crashed")

        fake_module = types.ModuleType("widdx.mcp.client")
        fake_module.MCPClient = ExplodingClient

        reg = MCPRegistry(config_path=str(cfg))
        with patch.dict(sys.modules, {"widdx.mcp.client": fake_module}):
            reg.load()

        result = reg.execute("mcp__srv__boom", {})
        assert "error" in result


# ---------------------------------------------------------------------------
# MCPRegistry.all_servers
# ---------------------------------------------------------------------------


class TestAllServers:
    def test_returns_connected_servers(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps(
                {
                    "mcpServers": {
                        "gh": {"command": "uvx"},
                        "db": {"command": "uvx"},
                    }
                }
            ),
            encoding="utf-8",
        )
        fake_tools = [{"name": "ping", "description": "Ping"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools):
            reg.load()

        servers = reg.all_servers()
        assert "gh" in servers
        assert "db" in servers
        assert servers["gh"]["connected"] is True
        assert "ping" in servers["gh"]["tools"]

    def test_empty_when_no_servers_connected(self, tmp_path):
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path=str(tmp_path / "none.json"))
        reg.load()
        # Built-in servers are always loaded
        assert "project-info" in reg.all_servers()
        assert "utility" in reg.all_servers()


# ---------------------------------------------------------------------------
# MCPRegistry.add_server
# ---------------------------------------------------------------------------


class TestAddServer:
    def test_add_server_connects_and_saves(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        fake_tools = [{"name": "list_repos", "description": "List repos"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client(list_tools_return=fake_tools):
            reg.add_server("gh", "uvx", args=["mcp-server-github"])

        assert "gh" in reg._servers
        # Config file must be written
        assert cfg.exists()
        saved = json.loads(cfg.read_text(encoding="utf-8"))
        assert "gh" in saved["mcpServers"]
        assert saved["mcpServers"]["gh"]["command"] == "uvx"

    def test_add_server_with_env(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client():
            reg.add_server("gh", "uvx", env={"GITHUB_TOKEN": "tok"})

        saved = json.loads(cfg.read_text(encoding="utf-8"))
        assert saved["mcpServers"]["gh"]["env"] == {"GITHUB_TOKEN": "tok"}

    def test_add_server_merges_with_existing(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"existing": {"command": "old"}}}), encoding="utf-8"
        )
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client():
            reg.add_server("new", "new-cmd")

        saved = json.loads(cfg.read_text(encoding="utf-8"))
        assert "existing" in saved["mcpServers"]
        assert "new" in saved["mcpServers"]

    def test_add_server_creates_parent_dirs(self, tmp_path):
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "deep" / "nested" / "mcp.json"
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_client():
            reg.add_server("s", "cmd")

        assert cfg.exists()


# ---------------------------------------------------------------------------
# Namespace helper (_namespace_tool)
# ---------------------------------------------------------------------------


class TestNamespaceTool:
    def test_namespaces_tool_name(self):
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry()
        tool = {"name": "create_issue", "description": "Create issue"}
        result = reg._namespace_tool("github", tool)
        assert result is not None
        assert result["name"] == "mcp__github__create_issue"

    def test_unnamed_tool_returns_none(self, caplog):
        from widdx.mcp import MCPRegistry
        import logging

        reg = MCPRegistry()
        with caplog.at_level(logging.WARNING):
            result = reg._namespace_tool("srv", {"description": "no name"})
        assert result is None

    def test_description_fallback(self):
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry()
        tool = {"name": "ping"}  # no description
        result = reg._namespace_tool("srv", tool)
        assert result is not None
        assert "srv" in result["description"]


# ---------------------------------------------------------------------------
# MCPHTTPClient — unit tests (task 6.3, REQ-1 criterion 8)
# ---------------------------------------------------------------------------


class TestMCPHTTPClientInit:
    def test_stores_name_url_and_headers(self):
        from widdx.mcp.client import MCPHTTPClient

        client = MCPHTTPClient("remote", "http://localhost:8080", headers={"X-Key": "val"})
        assert client._name == "remote"
        assert client._url == "http://localhost:8080"
        assert client._headers == {"X-Key": "val"}

    def test_trailing_slash_stripped_from_url(self):
        from widdx.mcp.client import MCPHTTPClient

        client = MCPHTTPClient("srv", "http://localhost:8080/")
        assert client._url == "http://localhost:8080"

    def test_headers_default_to_empty_dict(self):
        from widdx.mcp.client import MCPHTTPClient

        client = MCPHTTPClient("srv", "http://localhost:8080")
        assert client._headers == {}

    def test_disconnect_is_noop(self):
        from widdx.mcp.client import MCPHTTPClient

        client = MCPHTTPClient("srv", "http://localhost:8080")
        client.disconnect()  # must not raise


class TestMCPHTTPClientConnect:
    def _make_client(self, url="http://localhost:8080", headers=None):
        from widdx.mcp.client import MCPHTTPClient

        return MCPHTTPClient("srv", url, headers=headers)

    def test_connect_sends_initialize_and_succeeds(self):
        """connect() sends initialize and does not raise on a valid response."""
        from unittest.mock import patch, MagicMock
        import io

        response_body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"protocolVersion": "2024-11-05", "capabilities": {}},
        }).encode("utf-8")

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = response_body

        client = self._make_client()
        with patch("urllib.request.urlopen", return_value=mock_resp):
            client.connect()  # must not raise

    def test_connect_raises_on_server_error_response(self):
        """connect() raises RuntimeError when server returns a JSON-RPC error."""
        from unittest.mock import patch, MagicMock

        response_body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "error": {"code": -32600, "message": "Invalid Request"},
        }).encode("utf-8")

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = response_body

        client = self._make_client()
        with patch("urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(RuntimeError, match="rejected initialize"):
                client.connect()

    def test_connect_raises_on_url_error(self):
        """connect() raises RuntimeError when the server is unreachable."""
        import urllib.error
        from unittest.mock import patch

        client = self._make_client()
        with patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.URLError("Connection refused"),
        ):
            with pytest.raises(RuntimeError, match="unreachable"):
                client.connect()

    def test_connect_raises_on_http_error(self):
        """connect() raises RuntimeError on HTTP 4xx/5xx responses."""
        import urllib.error
        from unittest.mock import patch

        client = self._make_client()
        with patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.HTTPError(
                url="http://localhost:8080", code=500, msg="Internal Server Error",
                hdrs=None, fp=None,
            ),
        ):
            with pytest.raises(RuntimeError, match="HTTP 500"):
                client.connect()


class TestMCPHTTPClientListTools:
    def _client_with_mock_send(self, send_return):
        from widdx.mcp.client import MCPHTTPClient
        from unittest.mock import patch

        client = MCPHTTPClient("srv", "http://localhost:8080")
        client._send = lambda method, params=None: send_return
        return client

    def test_returns_tools_list(self):
        tools = [{"name": "search", "description": "Search"}]
        client = self._client_with_mock_send({"jsonrpc": "2.0", "id": 1, "result": {"tools": tools}})
        assert client.list_tools() == tools

    def test_raises_on_error_response(self):
        client = self._client_with_mock_send(
            {"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Not found"}}
        )
        with pytest.raises(RuntimeError, match="tools/list failed"):
            client.list_tools()

    def test_returns_empty_list_when_no_tools_key(self):
        client = self._client_with_mock_send({"jsonrpc": "2.0", "id": 1, "result": {}})
        assert client.list_tools() == []


class TestMCPHTTPClientCallTool:
    def _client_with_mock_send(self, send_return):
        from widdx.mcp.client import MCPHTTPClient

        client = MCPHTTPClient("srv", "http://localhost:8080")
        client._send = lambda method, params=None: send_return
        return client

    def test_returns_result_dict(self):
        client = self._client_with_mock_send(
            {"jsonrpc": "2.0", "id": 1, "result": {"data": "ok"}}
        )
        assert client.call_tool("search", {"q": "hello"}) == {"data": "ok"}

    def test_raises_on_error_response(self):
        client = self._client_with_mock_send(
            {"jsonrpc": "2.0", "id": 1, "error": {"code": -32000, "message": "Tool failed"}}
        )
        with pytest.raises(RuntimeError, match="tools/call 'search' failed"):
            client.call_tool("search", {})


class TestMCPHTTPClientCustomHeaders:
    def test_custom_headers_are_sent(self):
        """Headers from config are forwarded in the HTTP request."""
        from widdx.mcp.client import MCPHTTPClient
        from unittest.mock import patch, MagicMock, call
        import urllib.request

        response_body = json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "result": {"protocolVersion": "2024-11-05", "capabilities": {}},
        }).encode("utf-8")

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = response_body

        captured_requests: list[urllib.request.Request] = []

        def fake_urlopen(req, timeout=None):
            captured_requests.append(req)
            return mock_resp

        client = MCPHTTPClient(
            "srv", "http://localhost:8080",
            headers={"Authorization": "Bearer secret"},
        )
        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            client.connect()

        assert len(captured_requests) == 1
        req = captured_requests[0]
        assert req.get_header("Authorization") == "Bearer secret"


# ---------------------------------------------------------------------------
# MCPRegistry — HTTP server detection (task 6.3)
# ---------------------------------------------------------------------------


def _make_fake_http_client_module(
    connect_raises=None, list_tools_return=None, call_tool_return=None
):
    """Return a fake widdx.mcp.client module with both MCPClient and MCPHTTPClient."""

    class FakeMCPClient:
        def __init__(self, name, command, args=None, env=None):
            self.name = name
            self.transport = "stdio"

        def connect(self):
            if connect_raises:
                raise connect_raises

        def list_tools(self):
            return list_tools_return or []

        def call_tool(self, name, arguments):
            return call_tool_return or {}

    class FakeMCPHTTPClient:
        def __init__(self, name, url, headers=None):
            self.name = name
            self.url = url
            self.headers = headers
            self.transport = "http"

        def connect(self):
            if connect_raises:
                raise connect_raises

        def list_tools(self):
            return list_tools_return or []

        def call_tool(self, name, arguments):
            return call_tool_return or {}

    fake_module = types.ModuleType("widdx.mcp.client")
    fake_module.MCPClient = FakeMCPClient
    fake_module.MCPHTTPClient = FakeMCPHTTPClient
    return fake_module


def _patch_both_clients(connect_raises=None, list_tools_return=None, call_tool_return=None):
    fake = _make_fake_http_client_module(connect_raises, list_tools_return, call_tool_return)
    return patch.dict(sys.modules, {"widdx.mcp.client": fake})


class TestMCPRegistryHTTPTransport:
    def test_url_config_uses_http_client(self, tmp_path):
        """REQ-1 criterion 8: server with 'url' key connects via MCPHTTPClient."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({
                "mcpServers": {
                    "remote": {
                        "url": "http://localhost:8080",
                        "headers": {"Authorization": "Bearer tok"},
                    }
                }
            }),
            encoding="utf-8",
        )
        fake_tools = [{"name": "search", "description": "Search"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_both_clients(list_tools_return=fake_tools):
            reg.load()

        assert "remote" in reg._servers
        # The fake HTTP client sets transport="http"
        assert reg._servers["remote"].transport == "http"
        assert reg._servers["remote"].url == "http://localhost:8080"

    def test_url_config_passes_headers(self, tmp_path):
        """Headers from mcp.json are forwarded to MCPHTTPClient."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({
                "mcpServers": {
                    "remote": {
                        "url": "http://localhost:9000",
                        "headers": {"X-Api-Key": "abc123"},
                    }
                }
            }),
            encoding="utf-8",
        )
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_both_clients():
            reg.load()

        assert reg._servers["remote"].headers == {"X-Api-Key": "abc123"}

    def test_command_config_uses_stdio_client(self, tmp_path):
        """Servers with 'command' key still use MCPClient (stdio)."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"local": {"command": "uvx", "args": ["mcp-server"]}}}),
            encoding="utf-8",
        )
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_both_clients():
            reg.load()

        assert "local" in reg._servers
        assert reg._servers["local"].transport == "stdio"

    def test_empty_url_is_skipped(self, tmp_path, caplog):
        """A server config with an empty 'url' is skipped with a warning."""
        from widdx.mcp import MCPRegistry
        import logging

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"bad": {"url": ""}}}),
            encoding="utf-8",
        )
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_both_clients():
            with caplog.at_level(logging.WARNING):
                reg.load()

        assert "bad" not in reg._servers

    def test_http_server_tools_are_namespaced(self, tmp_path):
        """Tools from HTTP servers are namespaced the same as stdio tools."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"api": {"url": "http://localhost:8080"}}}),
            encoding="utf-8",
        )
        fake_tools = [{"name": "query", "description": "Run a query"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_both_clients(list_tools_return=fake_tools):
            reg.load()

        defs = reg.tool_definitions()
        assert len(defs) == 7  # 6 built-in + 1 HTTP
        api_tools = [t for t in defs if t["name"].startswith("mcp__api__")]
        assert api_tools[0]["name"] == "mcp__api__query"

    def test_mixed_stdio_and_http_servers(self, tmp_path):
        """Registry handles a mix of stdio and HTTP servers simultaneously."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({
                "mcpServers": {
                    "local": {"command": "uvx", "args": ["mcp-server"]},
                    "remote": {"url": "http://localhost:8080"},
                }
            }),
            encoding="utf-8",
        )
        fake_tools = [{"name": "ping", "description": "Ping"}]
        reg = MCPRegistry(config_path=str(cfg))
        with _patch_both_clients(list_tools_return=fake_tools):
            reg.load()

        assert "local" in reg._servers
        assert "remote" in reg._servers
        assert reg._servers["local"].transport == "stdio"
        assert reg._servers["remote"].transport == "http"
        # Each external server contributes one tool, plus 6 built-in tools
        assert len(reg.tool_definitions()) == 8


# ---------------------------------------------------------------------------
# widdx.mcp.config — MCPConfig, load_mcp_config, save_mcp_config (task 6.4)
# ---------------------------------------------------------------------------


class TestMCPConfig:
    def test_default_servers_is_empty_dict(self):
        from widdx.mcp.config import MCPConfig

        cfg = MCPConfig()
        assert cfg.servers == {}

    def test_servers_stored_correctly(self):
        from widdx.mcp.config import MCPConfig

        servers = {"gh": {"command": "uvx", "args": ["mcp-server-github"]}}
        cfg = MCPConfig(servers=servers)
        assert cfg.servers == servers


class TestLoadMCPConfig:
    def test_missing_file_returns_empty_config(self, tmp_path):
        from widdx.mcp.config import load_mcp_config

        result = load_mcp_config(tmp_path / "nonexistent.json")
        assert result.servers == {}

    def test_valid_file_returns_servers(self, tmp_path):
        from widdx.mcp.config import load_mcp_config

        cfg_file = tmp_path / "mcp.json"
        cfg_file.write_text(
            json.dumps({"mcpServers": {"gh": {"command": "uvx"}}}), encoding="utf-8"
        )
        result = load_mcp_config(cfg_file)
        assert result.servers == {"gh": {"command": "uvx"}}

    def test_malformed_json_returns_empty_config_with_warning(self, tmp_path, caplog):
        from widdx.mcp.config import load_mcp_config
        import logging

        bad = tmp_path / "mcp.json"
        bad.write_text("{not valid json", encoding="utf-8")
        with caplog.at_level(logging.WARNING):
            result = load_mcp_config(bad)
        assert result.servers == {}
        assert caplog.records  # a warning was logged

    def test_missing_mcp_servers_key_returns_empty_config(self, tmp_path):
        from widdx.mcp.config import load_mcp_config

        cfg_file = tmp_path / "mcp.json"
        cfg_file.write_text(json.dumps({}), encoding="utf-8")
        result = load_mcp_config(cfg_file)
        assert result.servers == {}

    def test_invalid_mcp_servers_type_returns_empty_config_with_warning(self, tmp_path, caplog):
        from widdx.mcp.config import load_mcp_config
        import logging

        cfg_file = tmp_path / "mcp.json"
        cfg_file.write_text(json.dumps({"mcpServers": "not-a-dict"}), encoding="utf-8")
        with caplog.at_level(logging.WARNING):
            result = load_mcp_config(cfg_file)
        assert result.servers == {}
        assert caplog.records

    def test_tilde_expansion_in_path(self, tmp_path, monkeypatch):
        """Path strings with ~ are expanded correctly."""
        from widdx.mcp.config import load_mcp_config

        # Point HOME to tmp_path so ~ expands there
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        monkeypatch.setenv("HOME", str(tmp_path))
        # File doesn't exist → should return empty config without raising
        result = load_mcp_config("~/mcp.json")
        assert result.servers == {}

    def test_multiple_servers_all_returned(self, tmp_path):
        from widdx.mcp.config import load_mcp_config

        cfg_file = tmp_path / "mcp.json"
        cfg_file.write_text(
            json.dumps({
                "mcpServers": {
                    "gh": {"command": "uvx", "args": ["mcp-server-github"]},
                    "db": {"command": "uvx", "args": ["mcp-server-postgres"]},
                }
            }),
            encoding="utf-8",
        )
        result = load_mcp_config(cfg_file)
        assert set(result.servers.keys()) == {"gh", "db"}


class TestSaveMCPConfig:
    def test_writes_servers_to_file(self, tmp_path):
        from widdx.mcp.config import MCPConfig, save_mcp_config

        cfg = MCPConfig(servers={"gh": {"command": "uvx"}})
        dest = tmp_path / "mcp.json"
        save_mcp_config(cfg, dest)

        data = json.loads(dest.read_text(encoding="utf-8"))
        assert data == {"mcpServers": {"gh": {"command": "uvx"}}}

    def test_creates_parent_directories(self, tmp_path):
        from widdx.mcp.config import MCPConfig, save_mcp_config

        dest = tmp_path / "deep" / "nested" / "mcp.json"
        save_mcp_config(MCPConfig(), dest)
        assert dest.exists()

    def test_empty_config_writes_empty_servers(self, tmp_path):
        from widdx.mcp.config import MCPConfig, save_mcp_config

        dest = tmp_path / "mcp.json"
        save_mcp_config(MCPConfig(), dest)
        data = json.loads(dest.read_text(encoding="utf-8"))
        assert data == {"mcpServers": {}}

    def test_overwrites_existing_file(self, tmp_path):
        from widdx.mcp.config import MCPConfig, save_mcp_config

        dest = tmp_path / "mcp.json"
        dest.write_text(json.dumps({"mcpServers": {"old": {"command": "old-cmd"}}}), encoding="utf-8")
        save_mcp_config(MCPConfig(servers={"new": {"command": "new-cmd"}}), dest)
        data = json.loads(dest.read_text(encoding="utf-8"))
        assert "old" not in data["mcpServers"]
        assert "new" in data["mcpServers"]

    def test_roundtrip_load_save_load(self, tmp_path):
        """save then load returns the same config."""
        from widdx.mcp.config import MCPConfig, load_mcp_config, save_mcp_config

        original = MCPConfig(servers={
            "gh": {"command": "uvx", "args": ["mcp-server-github"], "env": {"TOKEN": "abc"}},
        })
        dest = tmp_path / "mcp.json"
        save_mcp_config(original, dest)
        loaded = load_mcp_config(dest)
        assert loaded.servers == original.servers


class TestMCPConfigExports:
    def test_exports_from_config_module(self):
        from widdx.mcp.config import MCPConfig, load_mcp_config, save_mcp_config  # noqa: F401

    def test_exports_from_mcp_package(self):
        from widdx.mcp import MCPConfig, load_mcp_config, save_mcp_config  # noqa: F401


# ---------------------------------------------------------------------------
# ToolLoop integration — task 6.6
# REQ-1 criterion 2: MCP tools appear in TOOL_DEFINITIONS available to model
# ---------------------------------------------------------------------------


class TestToolLoopMCPIntegration:
    """Validates: Requirements REQ-1 criterion 2 (task 6.6)

    WHEN WIDDX connects to an MCP server THEN its tools appear in the tool
    list passed to the model.
    """

    def _make_registry_with_tools(self, tool_defs: list[dict]):
        """Return an MCPRegistry stub whose tool_definitions() returns tool_defs."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry.__new__(MCPRegistry)
        reg._tools = list(tool_defs)
        reg._servers = {}
        reg._config_path = None
        return reg

    def _make_tool_loop(self):
        """Return a ToolLoop with a minimal stub router (no real API calls)."""
        from widdx.tool_loop import ToolLoop

        router = MagicMock()
        # Prevent real MCP load during __init__
        with patch("widdx.mcp.MCPRegistry.load"):
            loop = ToolLoop(router, max_steps=1)
        return loop

    def test_set_mcp_registry_replaces_default(self):
        """set_mcp_registry() stores the provided registry on the instance."""
        loop = self._make_tool_loop()
        from widdx.mcp import MCPRegistry

        custom_reg = MCPRegistry.__new__(MCPRegistry)
        custom_reg._tools = []
        custom_reg._servers = {}
        loop.set_mcp_registry(custom_reg)
        assert loop._mcp_registry is custom_reg

    def test_mcp_tools_merged_into_all_tools(self):
        """MCP tool definitions are appended to TOOL_DEFINITIONS in run()."""
        from widdx.tool_loop.tools import TOOL_DEFINITIONS

        loop = self._make_tool_loop()

        mcp_tool = {
            "name": "mcp__gh__create_issue",
            "description": "Create a GitHub issue",
            "schema": {"type": "object", "properties": {}, "required": []},
        }
        reg = self._make_registry_with_tools([mcp_tool])
        loop.set_mcp_registry(reg)

        # Capture the tools list passed to call_with_tools_streaming
        captured: list = []

        def fake_stream(system, messages, tools):
            captured.append(tools)
            # Yield a minimal "done" event so run() exits cleanly
            yield {"type": "done", "usage": {}}

        loop._router.call_with_tools_streaming.side_effect = fake_stream
        loop._router._estimate_tokens.return_value = 100
        loop._router.PRICING = {}
        loop._router._executor_model = "test-model"

        loop.run("hello")

        assert len(captured) == 1
        passed_tools = captured[0]
        # All built-in tools must be present
        builtin_names = {t["name"] for t in TOOL_DEFINITIONS}
        passed_names = {t["name"] for t in passed_tools}
        assert builtin_names.issubset(passed_names)
        # MCP tool must also be present
        assert "mcp__gh__create_issue" in passed_names

    def test_no_mcp_servers_uses_only_builtin_tools(self):
        """When no MCP servers are configured, only built-in tools are passed."""
        from widdx.tool_loop.tools import TOOL_DEFINITIONS

        loop = self._make_tool_loop()
        reg = self._make_registry_with_tools([])  # empty MCP tools
        loop.set_mcp_registry(reg)

        captured: list = []

        def fake_stream(system, messages, tools):
            captured.append(tools)
            yield {"type": "done", "usage": {}}

        loop._router.call_with_tools_streaming.side_effect = fake_stream
        loop._router._estimate_tokens.return_value = 100
        loop._router.PRICING = {}
        loop._router._executor_model = "test-model"

        loop.run("hello")

        assert len(captured) == 1
        assert captured[0] == TOOL_DEFINITIONS

    def test_mcp_registry_loaded_on_init(self):
        """MCPRegistry.load() is called during ToolLoop.__init__()."""
        from widdx.tool_loop import ToolLoop

        router = MagicMock()
        with patch("widdx.mcp.MCPRegistry.load") as mock_load:
            ToolLoop(router, max_steps=1)
        mock_load.assert_called_once()


# ---------------------------------------------------------------------------
# MCPRegistry._reconnect_server — task 6.9
# ---------------------------------------------------------------------------


class TestReconnectServer:
    """Verify automatic reconnection on tool call failure (task 6.9)."""

    def _registry_with_failing_then_ok_client(self, tmp_path, server_name="srv"):
        """Build a registry whose client fails on first call_tool, succeeds on second."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {server_name: {"command": "uvx"}}}),
            encoding="utf-8",
        )

        call_count = [0]

        class FlakeyClient:
            def __init__(self, **kw):
                pass

            def connect(self):
                pass

            def list_tools(self):
                return [{"name": "ping", "description": "Ping"}]

            def call_tool(self, name, args):
                call_count[0] += 1
                if call_count[0] == 1:
                    raise RuntimeError("connection lost")
                return {"result": "pong"}

            def disconnect(self):
                pass

        fake_module = types.ModuleType("widdx.mcp.client")
        fake_module.MCPClient = FlakeyClient
        fake_module.MCPHTTPClient = FlakeyClient

        reg = MCPRegistry(config_path=str(cfg))
        with patch.dict(sys.modules, {"widdx.mcp.client": fake_module}):
            reg.load()

        return reg, fake_module, call_count

    def test_execute_retries_after_failure(self, tmp_path):
        """execute() reconnects and retries when the first call_tool raises."""
        reg, fake_module, call_count = self._registry_with_failing_then_ok_client(tmp_path)

        with patch.dict(sys.modules, {"widdx.mcp.client": fake_module}):
            result = reg.execute("mcp__srv__ping", {})

        # Should have retried and succeeded
        assert result == {"result": "pong"}
        assert call_count[0] == 2  # first call failed, second succeeded

    def test_execute_returns_error_when_reconnect_fails(self, tmp_path):
        """execute() returns an error dict when reconnection itself fails."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"srv": {"command": "uvx"}}}),
            encoding="utf-8",
        )

        class AlwaysFailingClient:
            def __init__(self, **kw):
                pass

            def connect(self):
                raise RuntimeError("cannot connect")

            def list_tools(self):
                return [{"name": "ping", "description": "Ping"}]

            def call_tool(self, name, args):
                raise RuntimeError("always fails")

            def disconnect(self):
                pass

        fake_module = types.ModuleType("widdx.mcp.client")
        fake_module.MCPClient = AlwaysFailingClient
        fake_module.MCPHTTPClient = AlwaysFailingClient

        # Manually set up a registry with a connected client that will fail
        reg = MCPRegistry(config_path=str(cfg))
        reg._tools = [{"name": "mcp__srv__ping", "description": "Ping", "schema": {"type": "object"}}]

        class FailingCallClient:
            def call_tool(self, name, args):
                raise RuntimeError("call failed")

            def disconnect(self):
                pass

        reg._servers["srv"] = FailingCallClient()

        with patch.dict(sys.modules, {"widdx.mcp.client": fake_module}):
            result = reg.execute("mcp__srv__ping", {})

        assert "error" in result

    def test_reconnect_server_returns_false_when_not_in_config(self, tmp_path):
        """_reconnect_server() returns False when server is not in mcp.json."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({"mcpServers": {}}), encoding="utf-8")
        reg = MCPRegistry(config_path=str(cfg))

        result = reg._reconnect_server("nonexistent")
        assert result is False

    def test_reconnect_removes_stale_tools(self, tmp_path):
        """_reconnect_server() removes old tool definitions before reconnecting."""
        from widdx.mcp import MCPRegistry

        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps({"mcpServers": {"srv": {"command": "uvx"}}}),
            encoding="utf-8",
        )

        class SimpleClient:
            def __init__(self, **kw):
                pass

            def connect(self):
                pass

            def list_tools(self):
                return [{"name": "new_tool", "description": "New"}]

            def disconnect(self):
                pass

        fake_module = types.ModuleType("widdx.mcp.client")
        fake_module.MCPClient = SimpleClient
        fake_module.MCPHTTPClient = SimpleClient

        reg = MCPRegistry(config_path=str(cfg))
        # Manually inject a stale tool
        reg._tools = [{"name": "mcp__srv__old_tool", "description": "Old", "schema": {}}]
        reg._servers["srv"] = SimpleClient()

        with patch.dict(sys.modules, {"widdx.mcp.client": fake_module}):
            reg._reconnect_server("srv")

        tool_names = [t["name"] for t in reg._tools]
        assert "mcp__srv__old_tool" not in tool_names
        assert "mcp__srv__new_tool" in tool_names


# ---------------------------------------------------------------------------
# /mcp command — task 6.8
# ---------------------------------------------------------------------------


class TestShowMCPCommand:
    """/mcp REPL command displays connected servers and tools."""

    def _make_repl_with_registry(self, tmp_path, servers=None):
        """Build a minimal REPL-like object with a real MCPRegistry."""
        from widdx.mcp import MCPRegistry
        from widdx.repl.commands import _show_mcp

        class FakeToolLoop:
            pass

        class FakeRepl:
            pass

        tool_loop = FakeToolLoop()
        reg = MCPRegistry.__new__(MCPRegistry)
        reg._tools = []
        reg._servers = {}
        reg._config_path = tmp_path / "mcp.json"

        if servers:
            for name, tools in servers.items():
                class FakeClient:
                    pass
                reg._servers[name] = FakeClient()
                for tool in tools:
                    reg._tools.append({
                        "name": f"mcp__{name}__{tool}",
                        "description": f"Tool {tool}",
                        "schema": {"type": "object"},
                    })

        tool_loop._mcp_registry = reg

        repl = FakeRepl()
        repl._tool_loop = tool_loop
        repl._show_mcp = lambda arg="": _show_mcp(repl, arg)
        return repl, reg

    def test_show_mcp_no_servers(self, tmp_path):
        """When no servers are connected, /mcp prints a helpful message."""
        repl, _ = self._make_repl_with_registry(tmp_path)
        # Should not raise
        repl._show_mcp()

    def test_show_mcp_lists_servers(self, tmp_path):
        """When servers are connected, /mcp shows them."""
        repl, reg = self._make_repl_with_registry(
            tmp_path, servers={"github": ["create_issue", "list_repos"]}
        )
        # Should not raise
        repl._show_mcp()

    def test_show_mcp_no_registry(self, tmp_path):
        """When _mcp_registry is absent, /mcp prints a graceful message."""
        from widdx.repl.commands import _show_mcp

        class FakeToolLoop:
            pass  # no _mcp_registry

        class FakeRepl:
            pass

        repl = FakeRepl()
        repl._tool_loop = FakeToolLoop()
        # Should not raise
        _show_mcp(repl, "")

    def test_show_mcp_add_usage_when_incomplete(self, tmp_path):
        """'/mcp add' without enough args prints usage."""
        repl, _ = self._make_repl_with_registry(tmp_path)
        # Should not raise
        repl._show_mcp("add")

    def test_show_mcp_remove_unknown_server(self, tmp_path):
        """'/mcp remove nonexistent' prints a warning."""
        repl, _ = self._make_repl_with_registry(tmp_path)
        # Should not raise
        repl._show_mcp("remove nonexistent")

    def test_all_servers_returns_tool_names(self, tmp_path):
        """all_servers() returns the correct tool names for each server."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry.__new__(MCPRegistry)
        reg._tools = [
            {"name": "mcp__gh__create_issue", "description": "Create issue", "schema": {}},
            {"name": "mcp__gh__list_repos", "description": "List repos", "schema": {}},
            {"name": "mcp__db__run_query", "description": "Run query", "schema": {}},
        ]

        class FakeClient:
            pass

        reg._servers = {"gh": FakeClient(), "db": FakeClient()}

        servers = reg.all_servers()
        assert set(servers["gh"]["tools"]) == {"create_issue", "list_repos"}
        assert servers["db"]["tools"] == ["run_query"]
        assert servers["gh"]["connected"] is True
        assert servers["db"]["connected"] is True


# ---------------------------------------------------------------------------
# MCPClient — real stdio client unit tests (mock subprocess)
# ---------------------------------------------------------------------------


class TestMCPClientInit:
    def test_stores_constructor_args(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient(
            "test-server", "uvx",
            args=["--flag", "value"],
            env={"TOKEN": "abc"},
        )
        assert client._name == "test-server"
        assert client._command == "uvx"
        assert client._args == ["--flag", "value"]
        assert client._env == {"TOKEN": "abc"}
        assert client._process is None
        assert client._id_counter == 0

    def test_args_defaults_to_empty_list(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        assert client._args == []

    def test_env_defaults_to_none(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        assert client._env is None


class TestMCPClientRequireConnected:
    def test_raises_when_process_none(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        with pytest.raises(RuntimeError, match="not connected"):
            client._require_connected()

    def test_raises_when_process_has_exited(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        client._process = MagicMock()
        client._process.poll.return_value = 0  # process has exited
        with pytest.raises(RuntimeError, match="not connected"):
            client._require_connected()


class TestMCPClientTerminate:
    def test_noop_when_process_none(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        client._terminate()  # must not raise

    def test_terminates_running_process(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        process = MagicMock()
        process.poll.return_value = None  # still running
        client._process = process
        client._terminate()
        process.terminate.assert_called_once()
        assert client._process is None

    def test_skips_terminate_if_already_exited(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        process = MagicMock()
        process.poll.return_value = 0  # already exited
        client._process = process
        client._terminate()
        process.terminate.assert_not_called()
        assert client._process is None

    def test_skips_kill_if_terminate_succeeds(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        process = MagicMock()
        process.poll.side_effect = [None, None]  # running before, running after terminate
        client._process = process
        client._terminate()
        process.terminate.assert_called_once()
        # wait should have been called with timeout=5
        process.wait.assert_called_once_with(timeout=5)
        process.kill.assert_not_called()  # wait succeeded so no kill needed

    def test_kills_if_terminate_times_out(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock
        import subprocess

        client = MCPClient("srv", "cmd")
        process = MagicMock()
        process.poll.side_effect = [None, None]  # running before and after terminate
        process.wait.side_effect = subprocess.TimeoutExpired("cmd", 5)
        client._process = process
        client._terminate()
        process.terminate.assert_called_once()
        process.wait.assert_called_once_with(timeout=5)
        process.kill.assert_called_once()

    def test_swallows_oserror(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        process = MagicMock()
        process.poll.side_effect = OSError("permission denied")
        client._process = process
        client._terminate()  # must not raise


class TestMCPClientNotify:
    def test_skips_when_process_none(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        client._notify("some/notification")  # must not raise

    def test_sends_notification_without_id(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        client._process = MagicMock()
        client._process.poll.return_value = None
        client._notify("some/event", {"key": "val"})

        written = client._process.stdin.write.call_args[0][0]
        msg = json.loads(written.decode("utf-8"))
        assert msg["jsonrpc"] == "2.0"
        assert msg["method"] == "some/event"
        assert msg["params"] == {"key": "val"}
        assert "id" not in msg

    def test_handles_broken_pipe_gracefully(self):
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        client._process = MagicMock()
        client._process.poll.return_value = None
        client._process.stdin.write.side_effect = BrokenPipeError()
        client._notify("some/event")  # must not raise


class TestMCPClientSend:
    def _make_connected_client(self):
        """Return an MCPClient whose _process appears connected."""
        from widdx.mcp.client import MCPClient
        from unittest.mock import MagicMock

        client = MCPClient("srv", "cmd")
        client._process = MagicMock()
        client._process.poll.return_value = None  # still running
        client._read_response = MagicMock(return_value={"result": {}})
        return client

    def test_builds_correct_json_rpc_message(self):
        client = self._make_connected_client()
        client._send("tools/list", {"limit": 10})

        written = client._process.stdin.write.call_args[0][0]
        msg = json.loads(written.decode("utf-8"))
        assert msg["jsonrpc"] == "2.0"
        assert msg["method"] == "tools/list"
        assert msg["params"] == {"limit": 10}
        assert isinstance(msg["id"], int)

    def test_increments_id_counter(self):
        client = self._make_connected_client()
        client._send("method_a")
        client._send("method_b")

        writes = client._process.stdin.write.call_args_list
        msg_a = json.loads(writes[0][0][0].decode("utf-8"))
        msg_b = json.loads(writes[1][0][0].decode("utf-8"))
        assert msg_b["id"] == msg_a["id"] + 1

    def test_send_without_params(self):
        client = self._make_connected_client()
        client._send("tools/list")

        written = client._process.stdin.write.call_args[0][0]
        msg = json.loads(written.decode("utf-8"))
        assert "params" not in msg

    def test_raises_runtime_error_on_broken_pipe(self):
        client = self._make_connected_client()
        client._process.stdin.write.side_effect = BrokenPipeError()

        with pytest.raises(RuntimeError, match="broken"):
            client._send("tools/list")

    def test_send_and_notify_use_lock(self):
        import threading
        client = self._make_connected_client()
        assert isinstance(client._lock, threading.Lock)


class TestMCPClientConnect:
    def test_raises_runtime_error_on_command_not_found(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "nonexistent-command-12345")
        with pytest.raises(RuntimeError, match="Failed to start"):
            client.connect()

    def test_raises_runtime_error_on_timeout(self):
        from widdx.mcp.client import MCPClient, _RESPONSE_TIMEOUT
        from unittest.mock import patch
        import subprocess

        client = MCPClient("srv", sys.executable, args=["-c", "import time; time.sleep(60)"])
        with patch("widdx.mcp.client._RESPONSE_TIMEOUT", 0.2):
            with pytest.raises(RuntimeError, match="handshake failed"):
                client.connect()

    def test_handshake_sends_initialize_and_initialized(self):
        from widdx.mcp.client import MCPClient
        import subprocess

        server_code = (
            "import sys, json;"
            "msg = json.loads(sys.stdin.readline());"
            "assert msg['method'] == 'initialize';"
            "sys.stdout.write(json.dumps({'jsonrpc':'2.0','id':msg['id'],'result':{}})+'\\n');"
            "sys.stdout.flush();"
            "sys.exit(0)"
        )
        client = MCPClient("srv", sys.executable, args=["-c", server_code])
        try:
            client.connect()
        except RuntimeError:
            pass  # may fail on second notification but handshake worked


class TestMCPClientListTools:
    def test_raises_when_not_connected(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        with pytest.raises(RuntimeError, match="not connected"):
            client.list_tools()


class TestMCPClientCallTool:
    def test_raises_when_not_connected(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        with pytest.raises(RuntimeError, match="not connected"):
            client.call_tool("foo", {})

    def test_disconnect_clears_process(self):
        from widdx.mcp.client import MCPClient

        client = MCPClient("srv", "cmd")
        client.disconnect()  # must not raise when not connected


# ---------------------------------------------------------------------------
# MCPHTTPClient._send — remaining coverage
# ---------------------------------------------------------------------------


class TestMCPHTTPClientSend:
    def _make_client(self, url="http://localhost:8080", headers=None):
        from widdx.mcp.client import MCPHTTPClient

        return MCPHTTPClient("srv", url, headers=headers)

    def test_raises_timeout_error_on_urllib_timeout(self):
        """_send() propagates TimeoutError from urlopen."""
        from unittest.mock import patch

        client = self._make_client()
        with patch("urllib.request.urlopen", side_effect=TimeoutError("timed out")):
            with pytest.raises(TimeoutError, match="did not respond"):
                client._send("ping")

    def test_raises_runtime_error_on_non_json_response(self):
        """_send() raises RuntimeError when the server returns non-JSON body."""
        from unittest.mock import patch, MagicMock

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = b"<html>not json</html>"

        client = self._make_client()
        with patch("urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(RuntimeError, match="non-JSON"):
                client._send("ping")

    def test_sets_content_type_and_accept_headers(self):
        """_send() sets Content-Type and Accept to application/json."""
        from unittest.mock import patch, MagicMock
        import urllib.request

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = b'{"jsonrpc":"2.0","id":1,"result":{}}'

        captured: list[urllib.request.Request] = []

        def fake_urlopen(req, timeout=None):
            captured.append(req)
            return mock_resp

        client = self._make_client()
        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            client._send("initialize", {})

        assert len(captured) == 1
        req = captured[0]
        # urllib normalizes "Content-Type" → "Content-type"
        assert req.get_header("Content-type") == "application/json"
        assert req.get_header("Accept") == "application/json"

    def test_increments_id_counter(self):
        """Each _send() call increments the request ID."""
        from unittest.mock import patch, MagicMock

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = b'{"jsonrpc":"2.0","id":1,"result":{}}'

        client = self._make_client()
        with patch("urllib.request.urlopen", return_value=mock_resp):
            client._send("method_a")
            client._send("method_b")

        assert client._id_counter == 2

    def test_passes_timeout_to_urlopen(self):
        """_send() passes _RESPONSE_TIMEOUT to urlopen."""
        from unittest.mock import patch, MagicMock

        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = b'{"jsonrpc":"2.0","id":1,"result":{}}'

        captured_timeout = [None]

        def fake_urlopen(req, timeout=None):
            captured_timeout[0] = timeout
            return mock_resp

        client = self._make_client()
        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            client._send("ping")

        assert captured_timeout[0] == 30.0
