"""Tests for AIRouter provider management."""
from __future__ import annotations

import pytest


@pytest.fixture
def router_no_key():
    """Router without any API key — 1 free provider (opencode, 5 entries)."""
    from widdx.router import AIRouter
    config = {"__env__": {"deepseek_key": None}, "models": {}}
    return AIRouter(config, None)


@pytest.fixture
def router_with_key():
    """Router with DeepSeek API key — 2 providers total (deepseek + opencode)."""
    from widdx.router import AIRouter
    config = {"__env__": {"deepseek_key": "sk-fake"}, "models": {}}
    return AIRouter(config, None)


# ── Provider building ────────────────────────────────────────────────

def test_build_providers_no_key(router_no_key):
    """Without API key, only opencode provider is built (4 model entries)."""
    providers = router_no_key._providers
    assert len(providers) == 4, f"Expected 4 entries, got {len(providers)}"
    names = {p["name"] for p in providers}
    assert names == {"opencode"}


def test_build_providers_with_key(router_with_key):
    """With API key, deepseek is added as first provider."""
    providers = router_with_key._providers
    assert providers[0]["name"] == "deepseek"
    assert providers[0].get("supports_thinking") is True


def test_provider_models_have_client(router_no_key):
    """Each provider entry has an OpenAI client."""
    for p in router_no_key._providers:
        assert p.get("client") is not None
        assert p.get("architect_model")
        assert p.get("executor_model")


def test_opencode_has_big_pickle_architect(router_no_key):
    """opencode architect model is big-pickle."""
    arch_models = {p["architect_model"] for p in router_no_key._providers if p["name"] == "opencode"}
    assert "big-pickle" in arch_models


def test_opencode_has_flash_free_executor(router_no_key):
    """opencode executor models include flash-free and nemotron."""
    exec_models = {p["executor_model"] for p in router_no_key._providers if p["name"] == "opencode"}
    assert "deepseek-v4-flash-free" in exec_models
    assert "nemotron-3-super-free" in exec_models


def test_opencode_executor_count(router_no_key):
    """opencode has 4 executor models + 1 shared architect model = 4 entries."""
    opencode_entries = [p for p in router_no_key._providers if p["name"] == "opencode"]
    assert len(opencode_entries) == 4


def test_no_duplicate_entries(router_no_key):
    """No duplicate (arch, exec) pairs."""
    seen = set()
    for p in router_no_key._providers:
        key = (p["architect_model"], p["executor_model"])
        assert key not in seen, f"Duplicate entry: {key}"
        seen.add(key)


# ── list_providers ───────────────────────────────────────────────────

def test_list_providers_deduplicated(router_no_key):
    """list_providers returns unique providers, not individual entries."""
    providers = router_no_key.list_providers()
    assert len(providers) == 1
    names = {p["name"] for p in providers}
    assert names == {"opencode"}


def test_list_providers_has_model_count(router_no_key):
    """Each listed provider shows its model count."""
    for p in router_no_key.list_providers():
        assert "model_count" in p
        assert p["model_count"] >= 1


def test_list_providers_all_enabled_by_default(router_no_key):
    """All providers start enabled."""
    for p in router_no_key.list_providers():
        assert p["enabled"] is True


def test_list_providers_with_paid(router_with_key):
    """With API key, deepseek appears in list alongside opencode."""
    providers = router_with_key.list_providers()
    assert len(providers) == 2
    names = {p["name"] for p in providers}
    assert names == {"deepseek", "opencode"}


def test_list_providers_last_used(router_no_key):
    """last_used field reflects which provider was last called."""
    for p in router_no_key.list_providers():
        assert isinstance(p.get("last_used"), bool)


# ── toggle_provider ──────────────────────────────────────────────────

def test_toggle_disables_provider(router_no_key):
    """Toggling a provider disables it."""
    result = router_no_key.toggle_provider("opencode")
    assert result is False  # disabled
    providers = router_no_key.list_providers()
    opencode = next(p for p in providers if p["name"] == "opencode")
    assert opencode["enabled"] is False


def test_toggle_enables_provider(router_no_key):
    """Toggling a disabled provider enables it."""
    router_no_key.toggle_provider("opencode")  # disable
    result = router_no_key.toggle_provider("opencode")  # enable
    assert result is True
    providers = router_no_key.list_providers()
    opencode = next(p for p in providers if p["name"] == "opencode")
    assert opencode["enabled"] is True


def test_toggle_all_entries_filtered(router_no_key):
    """Disabling a provider filters all its internal entries."""
    router_no_key.toggle_provider("opencode")  # disable
    exec_provs = router_no_key._providers_for_role("executor")
    assert len(exec_provs) == 0


def test_toggle_unknown_provider_no_error(router_no_key):
    """Toggling a non-existent provider doesn't crash."""
    result = router_no_key.toggle_provider("nonexistent")
    assert result is False


# ── enable_only ──────────────────────────────────────────────────────

def test_enable_only_single_provider(router_no_key):
    """enable_only works when only one provider exists."""
    router_no_key.enable_only("opencode")
    providers = router_no_key.list_providers()
    opencode = next(p for p in providers if p["name"] == "opencode")
    assert opencode["enabled"] is True


def test_enable_only_with_paid(router_with_key):
    """enable_only filters to one provider among multiple."""
    router_with_key.enable_only("opencode")
    providers = router_with_key.list_providers()
    deepseek = next(p for p in providers if p["name"] == "deepseek")
    opencode = next(p for p in providers if p["name"] == "opencode")
    assert deepseek["enabled"] is False
    assert opencode["enabled"] is True


# ── enable_all ───────────────────────────────────────────────────────

def test_enable_all_restores_all(router_no_key):
    """enable_all re-enables all providers."""
    router_no_key.toggle_provider("opencode")
    router_no_key.enable_all()
    for p in router_no_key.list_providers():
        assert p["enabled"] is True


def test_enable_all_restores_routing(router_no_key):
    """After enable_all, all entries are available for routing."""
    router_no_key.toggle_provider("opencode")
    router_no_key.enable_all()
    exec_provs = router_no_key._providers_for_role("executor")
    assert len(exec_provs) == 4


# ── Forced provider ──────────────────────────────────────────────────

def test_forced_provider_via_config(router_no_key):
    """When provider is forced in config, only that provider routes."""
    router_no_key._config["provider"] = "opencode"
    exec_provs = router_no_key._providers_for_role("executor")
    assert all(p["name"] == "opencode" for p in exec_provs)
    assert len(exec_provs) == 4


def test_forced_provider_per_role(router_no_key):
    """Role-specific provider override works."""
    router_no_key._config["models"] = {
        "executor": {"provider": "opencode"},
        "architect": {"provider": "opencode"},
    }
    exec_provs = router_no_key._providers_for_role("executor")
    arch_provs = router_no_key._providers_for_role("architect")
    assert all(p["name"] == "opencode" for p in exec_provs)
    assert all(p["name"] == "opencode" for p in arch_provs)


def test_forced_provider_auto_uses_all(router_no_key):
    """When provider is 'auto', all enabled providers are available."""
    router_no_key._config["provider"] = "auto"
    exec_provs = router_no_key._providers_for_role("executor")
    assert len(exec_provs) == 4


# ── Model selection ──────────────────────────────────────────────────

def test_model_for_provider_deepseek(router_with_key):
    """DeepSeek uses configured model names."""
    router_with_key._config["models"] = {
        "executor": {"model": "deepseek-v4-flash"},
    }
    exec_provs = router_with_key._providers_for_role("executor")
    assert any(p["name"] == "deepseek" for p in exec_provs)
