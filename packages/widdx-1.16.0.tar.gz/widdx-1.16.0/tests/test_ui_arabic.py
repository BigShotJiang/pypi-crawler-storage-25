"""Tests for Arabic reshaping and RTL display in ui/arabic.py."""
from __future__ import annotations

import pytest


# ── Detection ────────────────────────────────────────────────────────

def test_has_arabic_positive():
    """Detects Arabic text."""
    from widdx.ui.arabic import has_arabic
    assert has_arabic("مرحبا") is True
    assert has_arabic("هل تستطيع اكمال المشروع") is True
    assert has_arabic("hello مرحبا world") is True


def test_has_arabic_negative():
    """Returns False for non-Arabic text."""
    from widdx.ui.arabic import has_arabic
    assert has_arabic("hello world") is False
    assert has_arabic("12345") is False
    assert has_arabic("") is False


def test_has_arabic_none():
    """Handles None/empty gracefully."""
    from widdx.ui.arabic import has_arabic
    assert has_arabic("") is False


def test_cp_is_arabic():
    """Unicode code point detection works for Arabic ranges."""
    from widdx.ui.arabic import _cp_is_arabic
    assert _cp_is_arabic(0x0633) is True  # س
    assert _cp_is_arabic(0x0644) is True  # ل
    assert _cp_is_arabic(0x0041) is False  # A
    assert _cp_is_arabic(0x0031) is False  # 1


def test_is_arabic_significant():
    """_is_arabic returns True when >=15% of chars are Arabic."""
    from widdx.ui.arabic import _is_arabic
    assert _is_arabic("مرحبا") is True
    assert _is_arabic("مرحبا hello world test text here extra padding to dilute arabic percentage significantly below threshold") is False


# ── Reshaping (letter joining) ───────────────────────────────────────

def test_reshape_joins_letters():
    """Arabic letters are connected after reshaping."""
    from widdx.ui.arabic import reshape
    result = reshape("هل")
    # Reshaped text should be different from the raw isolated form
    # Raw: ه separate, ل separate
    # Reshaped: ﻫﻞ (connected)
    assert result != "هل"  # should be reshaped
    assert len(result) <= 3  # Arabic letters may combine


def test_reshape_preserves_non_arabic():
    """Non-Arabic text passes through unchanged."""
    from widdx.ui.arabic import reshape
    assert reshape("hello world") == "hello world"
    assert reshape("123 code") == "123 code"


def test_reshape_empty_string():
    """Empty string returns empty."""
    from widdx.ui.arabic import reshape
    assert reshape("") == ""


def test_reshape_mixed_content():
    """Mixed Arabic + English is reshaped correctly."""
    from widdx.ui.arabic import reshape
    result = reshape("hello مرحبا world")
    assert "hello" in result
    assert "world" in result
    assert result != "hello مرحبا world"  # Arabic part is reshaped


def test_reshape_returns_str():
    """reshape always returns str type."""
    from widdx.ui.arabic import reshape
    assert isinstance(reshape("مرحبا"), str)
    assert isinstance(reshape("hello"), str)


def test_reshape_full_sentence():
    """Full Arabic sentence is properly reshaped."""
    from widdx.ui.arabic import reshape
    result = reshape("هل تستطيع اكمال المشروع")
    assert len(result) > 0
    assert isinstance(result, str)
    # Should contain reshaped Arabic characters (in Arabic presentation forms)
    has_arabic_forms = any(0xFE70 <= ord(c) <= 0xFEFF for c in result)
    assert has_arabic_forms, "Expected Arabic presentation form characters"


# ── _d helper ────────────────────────────────────────────────────────

def test_d_reshapes_arabic():
    """_d reshapes Arabic text."""
    from widdx.ui.arabic import _d
    result = _d("مرحبا")
    assert result != "مرحبا"


def test_d_passes_non_arabic():
    """_d passes non-Arabic through unchanged."""
    from widdx.ui.arabic import _d
    assert _d("hello") == "hello"


# ── reshape_strict ───────────────────────────────────────────────────

def test_reshape_strict_delegates():
    """reshape_strict delegates to reshape."""
    from widdx.ui.arabic import reshape, reshape_strict
    assert reshape_strict("مرحبا") == reshape("مرحبا")
    assert reshape_strict("hello") == reshape("hello")


# ── Terminal bidi detection (unit) ────────────────────────────────────

def test_terminal_bidi_detection_exists():
    """_terminal_supports_bidi returns a boolean."""
    from widdx.ui.arabic import _terminal_supports_bidi
    result = _terminal_supports_bidi()
    assert isinstance(result, bool)


def test_terminal_bidi_detection_wt_session(monkeypatch):
    """Windows Terminal is detected as bidi-capable."""
    monkeypatch.setenv("WT_SESSION", "fake-session-id")
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is True


def test_terminal_bidi_detection_vscode(monkeypatch):
    """VS Code is detected as non-bidi."""
    monkeypatch.setenv("TERM_PROGRAM", "vscode")
    monkeypatch.delenv("WT_SESSION", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is False


def test_terminal_bidi_detection_iterm(monkeypatch):
    """iTerm2 is detected as bidi-capable."""
    monkeypatch.setenv("ITERM_SESSION_ID", "fake")
    monkeypatch.delenv("WT_SESSION", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is True


def test_terminal_bidi_alacritty(monkeypatch):
    """Alacritty is detected as bidi-capable."""
    monkeypatch.setenv("ALACRITTY_SOCKET", "/tmp/alacritty.sock")
    monkeypatch.delenv("WT_SESSION", raising=False)
    monkeypatch.delenv("ITERM_SESSION_ID", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is True


def test_terminal_bidi_konsole(monkeypatch):
    """KDE Konsole is detected as bidi-capable."""
    monkeypatch.setenv("KONSOLE_VERSION", "24.02")
    monkeypatch.delenv("WT_SESSION", raising=False)
    monkeypatch.delenv("ITERM_SESSION_ID", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is True


def test_terminal_bidi_gnome(monkeypatch):
    """Gnome Terminal is detected as bidi-capable via VTE_VERSION."""
    monkeypatch.setenv("VTE_VERSION", "7800")
    monkeypatch.delenv("WT_SESSION", raising=False)
    monkeypatch.delenv("ITERM_SESSION_ID", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is True


def test_terminal_bidi_apple(monkeypatch):
    """Apple Terminal.app is detected as bidi-capable."""
    monkeypatch.setenv("TERM_PROGRAM", "Apple_Terminal")
    monkeypatch.delenv("WT_SESSION", raising=False)
    monkeypatch.delenv("ITERM_SESSION_ID", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is True


def test_terminal_bidi_jetbrains(monkeypatch):
    """JetBrains is detected as non-bidi."""
    monkeypatch.setenv("TERMINAL_EMULATOR", "JetBrains")
    monkeypatch.delenv("WT_SESSION", raising=False)
    monkeypatch.delenv("ITERM_SESSION_ID", raising=False)
    from widdx.ui.arabic import _terminal_supports_bidi
    assert _terminal_supports_bidi() is False
