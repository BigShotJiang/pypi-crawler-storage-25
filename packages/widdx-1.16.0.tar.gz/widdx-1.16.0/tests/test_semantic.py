"""Tests for widdx/semantic_index.py."""
import pytest
from pathlib import Path

# Skip all tests if optional dependencies are not installed
try:
    import chromadb
    import sentence_transformers
    _HAS_RAG = True
except ImportError:
    _HAS_RAG = False



class TestChunking:
    def test_chunk_code_simple(self):
        from widdx.semantic_index import _chunk_code
        content = 'def a():\n    pass\n\ndef b():\n    return 1\n'
        chunks = _chunk_code(content, 'test.py')
        assert len(chunks) >= 1

    def test_chunk_code_empty(self):
        from widdx.semantic_index import _chunk_code
        chunks = _chunk_code('', 'test.py')
        assert chunks == []

    def test_fixed_chunks_small(self):
        from widdx.semantic_index import _fixed_chunks
        chunks = _fixed_chunks('hello world', 'test.py')
        assert len(chunks) >= 1
        assert chunks[0]['file'] == 'test.py'

    def test_should_index_py(self):
        import tempfile, os
        from widdx.semantic_index import _should_index
        with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as f:
            f.write(b'print("hello")')
            f.close()
            assert _should_index(Path(f.name)) is True
            os.unlink(f.name)

    def test_should_index_md(self):
        import tempfile, os
        from widdx.semantic_index import _should_index
        with tempfile.NamedTemporaryFile(suffix='.md', delete=False) as f:
            f.write(b'# Test')
            f.close()
            assert _should_index(Path(f.name)) is True
            os.unlink(f.name)

    def test_should_skip_dir(self):
        from widdx.semantic_index import _should_index
        assert _should_index(Path('.')) is False

    def test_should_skip_huge_file(self):
        from widdx.semantic_index import _should_index, _MAX_FILE_BYTES
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as f:
            f.truncate(_MAX_FILE_BYTES + 1)
            f.close()
            assert _should_index(Path(f.name)) is False
            os.unlink(f.name)

    def test_chunk_overlap(self):
        from widdx.semantic_index import _fixed_chunks
        # Content large enough to force multiple chunks
        lines = ['line ' + str(i) for i in range(200)]
        long_content = '\n'.join(lines)
        chunks = _fixed_chunks(long_content, 'test.py')
        assert len(chunks) >= 2


@pytest.mark.skipif(not _HAS_RAG, reason="chromadb + sentence-transformers required for semantic search")
class TestSemanticIndex:
    def test_init_creates_dir(self):
        import tempfile, shutil
        from widdx.semantic_index import SemanticIndex
        tmp = tempfile.mkdtemp()
        try:
            idx = SemanticIndex(persist_dir=tmp)
            assert Path(tmp).exists()
            assert idx.is_ready is False
            assert idx.chunk_count == 0
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_unready_search_returns_empty(self):
        import tempfile, shutil
        from widdx.semantic_index import SemanticIndex
        tmp = tempfile.mkdtemp()
        try:
            idx = SemanticIndex(persist_dir=tmp)
            results = idx.search("test query")
            assert results == []
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_search_context_empty(self):
        import tempfile, shutil
        from widdx.semantic_index import SemanticIndex
        tmp = tempfile.mkdtemp()
        try:
            idx = SemanticIndex(persist_dir=tmp)
            ctx = idx.search_context("auth")
            assert ctx == ""
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_file_hash_consistent(self):
        import tempfile, os
        from widdx.semantic_index import _file_hash
        with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as f:
            f.write(b'print("hello")')
            f.close()
            h1 = _file_hash(Path(f.name))
            h2 = _file_hash(Path(f.name))
            assert h1 == h2  # Same file, same hash
            os.unlink(f.name)
