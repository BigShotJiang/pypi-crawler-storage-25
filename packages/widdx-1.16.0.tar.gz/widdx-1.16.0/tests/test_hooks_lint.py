"""Tests for widdx.hooks.lint_check — file extension to linter mapping."""
from __future__ import annotations

import json
import subprocess
import sys
from io import StringIO
from unittest.mock import patch

from widdx.hooks.lint_check import get_lint_args, main


class TestGetLintArgs:
    """get_lint_args maps file extensions to lint commands."""

    def test_python(self):
        args = get_lint_args("file.py")
        assert args is not None
        assert "ruff" in args

    def test_javascript(self):
        args = get_lint_args("file.js")
        assert args is not None
        assert "eslint" in args

    def test_typescript(self):
        args = get_lint_args("file.ts")
        assert args is not None
        assert "eslint" in args

    def test_tsx(self):
        args = get_lint_args("file.tsx")
        assert args is not None
        assert "eslint" in args

    def test_jsx(self):
        args = get_lint_args("file.jsx")
        assert args is not None
        assert "eslint" in args

    def test_css(self):
        args = get_lint_args("file.css")
        assert args is not None
        assert "stylelint" in args

    def test_go(self):
        args = get_lint_args("file.go")
        assert args is not None
        assert "go" in args[0] or "vet" in str(args)

    def test_rust(self):
        args = get_lint_args("file.rs")
        assert args is not None
        assert "clippy" in str(args)

    def test_unknown_extension(self):
        assert get_lint_args("file.xyz") is None

    def test_no_extension(self):
        assert get_lint_args("Makefile") is None

    def test_case_insensitive(self):
        args = get_lint_args("file.PY")
        # Extension lowercasing is handled by os.path.splitext
        # On case-insensitive platforms, .splitext preserves case
        assert args is not None  # .py lowercased internally


class TestMain:
    """main() reads stdin, runs linter, prints results if any."""

    def test_no_file_path_exits_0(self):
        stdin = StringIO(json.dumps({}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit, \
             patch("subprocess.run"):
            main()
            mock_exit.assert_any_call(0)

    def test_unknown_extension_exits_0(self):
        stdin = StringIO(json.dumps({"tool_input": {"file_path": "file.xyz"}}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit, \
             patch("subprocess.run"):
            main()
            mock_exit.assert_any_call(0)

    def test_invalid_json_exits_0(self):
        stdin = StringIO("not json")
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit, \
             patch("subprocess.run"):
            main()
            mock_exit.assert_any_call(0)

    def test_lint_passes_no_output(self):
        stdin = StringIO(json.dumps({"tool_input": {"file_path": "test.py"}}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit, \
             patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            main()
            mock_exit.assert_called_once_with(0)

    def test_lint_fails_prints_issues(self):
        stdin = StringIO(json.dumps({"tool_input": {"file_path": "test.py"}}))
        out = StringIO()
        with patch.object(sys, "stdin", stdin), patch.object(sys, "stdout", out), patch.object(sys, "exit"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 1
            mock_run.return_value.stdout = "E501 line too long"
            mock_run.return_value.stderr = ""
            main()
            result = json.loads(out.getvalue())
            assert "Lint issues" in result["hookSpecificOutput"]["additionalContext"]

    def test_lint_timeout_silent(self):
        stdin = StringIO(json.dumps({"tool_input": {"file_path": "test.py"}}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit, \
             patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd=["ruff"], timeout=30)):
            main()
            mock_exit.assert_called_once_with(0)

    def test_lint_oserror_silent(self):
        stdin = StringIO(json.dumps({"tool_input": {"file_path": "test.py"}}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit, \
             patch("subprocess.run", side_effect=OSError("ruff not found")):
            main()
            mock_exit.assert_called_once_with(0)

    def test_gets_file_path_from_env(self, monkeypatch):
        monkeypatch.setenv("WIDDX_FILE_PATH", "test.py")
        stdin = StringIO(json.dumps({}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            main()
            mock_run.assert_called_once()
