"""Tests for bootstrap manager — result class and edge cases."""
from __future__ import annotations

from unittest.mock import MagicMock


# ── BootstrapResult ──────────────────────────────────────────────────

def test_bootstrap_result_defaults():
    """BootstrapResult starts empty."""
    from widdx.bootstrap import BootstrapResult
    r = BootstrapResult()
    assert r.tech == ""
    assert r.skills_created == []
    assert r.agents_created == []
    assert r.hooks_created == []
    assert r.summary == ""


def test_bootstrap_result_report_empty():
    """Empty result produces minimal report."""
    from widdx.bootstrap import BootstrapResult
    r = BootstrapResult()
    r.tech = "flutter"
    report = r.report()
    assert "flutter" in report


def test_bootstrap_result_report_full():
    """Full result includes all sections."""
    from widdx.bootstrap import BootstrapResult
    r = BootstrapResult()
    r.tech = "nextjs"
    r.skills_created = ["nextjs.md"]
    r.agents_created = ["nextjs.md"]
    r.hooks_created = ["hooks.json"]
    r.summary = "Bootstrapped successfully"
    report = r.report()
    assert "nextjs" in report
    assert "Skills" in report
    assert "Agents" in report
    assert "Hooks" in report
    assert "Bootstrapped successfully" in report


def test_bootstrap_result_unicode_tech():
    """BootstrapResult handles Unicode tech names."""
    from widdx.bootstrap import BootstrapResult
    r = BootstrapResult()
    r.tech = "django"
    r.summary = "مرحبا بالعالم"
    report = r.report()
    assert "django" in report
    assert "مرحبا بالعالم" in report


# ── BootstrapManager ─────────────────────────────────────────────────

def test_bootstrap_manager_init():
    """BootstrapManager initializes with router."""
    from widdx.bootstrap import BootstrapManager
    router = MagicMock()
    manager = BootstrapManager(router)
    assert manager._router is router


def test_bootstrap_result_boundary():
    """BootstrapResult handles edge cases."""
    from widdx.bootstrap import BootstrapResult
    r = BootstrapResult()
    r.tech = "a" * 100
    r.summary = ""
    report = r.report()
    assert len(report) > 0
