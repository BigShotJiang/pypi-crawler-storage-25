"""Tests for WIDDX.md project memory — REQ-5."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from widdx.repl.context import _load_project_md


# ── Helpers ────────────────────────────────────────────────────────────────

def _make_repl(tmp_path: Path) -> MagicMock:
    """Return a minimal mock REPL object that _load_project_md can be called on."""
    obj = MagicMock()
    obj._project_md = ""
    return obj


# ── REQ-5.1: Load WIDDX.md from cwd ───────────────────────────────────────

class TestLoadWiddxMd:
    def test_loads_widdx_md_from_cwd(self, tmp_path):
        """WIDDX.md in cwd is read and returned."""
        widdx_md = tmp_path / "WIDDX.md"
        widdx_md.write_text("# Project rules\nUse Python 3.12.", encoding="utf-8")

        obj = _make_repl(tmp_path)
        # Patch Path.cwd() to return tmp_path; use a MagicMock for cwd so / works
        cwd_mock = MagicMock()
        cwd_mock.__truediv__ = lambda self, name: tmp_path / name

        with patch("widdx.repl.context.Path") as mock_path_cls:
            mock_path_cls.cwd.return_value = cwd_mock
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock

            result = _load_project_md(obj)

        assert "Project rules" in result
        assert "Use Python 3.12." in result
        assert obj._project_md == result

    def test_sets_project_md_attribute(self, tmp_path):
        """_project_md attribute is set on self after loading."""
        (tmp_path / "WIDDX.md").write_text("content", encoding="utf-8")

        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            _load_project_md(obj)

        assert obj._project_md == "content"

    def test_returns_empty_when_no_files_exist(self, tmp_path):
        """Returns empty string when neither WIDDX.md nor CLAUDE.md exist."""
        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            result = _load_project_md(obj)

        assert result == ""
        assert obj._project_md == ""


# ── REQ-5.3: CLAUDE.md fallback ───────────────────────────────────────────

class TestClaudeMdFallback:
    def test_loads_claude_md_when_widdx_md_absent(self, tmp_path):
        """CLAUDE.md is read when WIDDX.md does not exist."""
        (tmp_path / "CLAUDE.md").write_text("# Claude rules\nBe concise.", encoding="utf-8")

        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            result = _load_project_md(obj)

        assert "Claude rules" in result
        assert "Be concise." in result

    def test_widdx_md_takes_precedence_over_claude_md(self, tmp_path):
        """When both exist, WIDDX.md is used and CLAUDE.md is ignored."""
        (tmp_path / "WIDDX.md").write_text("widdx content", encoding="utf-8")
        (tmp_path / "CLAUDE.md").write_text("claude content", encoding="utf-8")

        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            result = _load_project_md(obj)

        assert "widdx content" in result
        assert "claude content" not in result


# ── REQ-5.2: Merge user-level and project-level ────────────────────────────

class TestUserLevelMerge:
    def test_merges_user_and_project_md(self, tmp_path):
        """User-level and project-level content are both present in result."""
        project_md = tmp_path / "WIDDX.md"
        project_md.write_text("project rules", encoding="utf-8")

        user_md_path = tmp_path / "user_WIDDX.md"
        user_md_path.write_text("user rules", encoding="utf-8")

        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = True
            user_md_mock.read_text.return_value = "user rules"
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            result = _load_project_md(obj)

        assert "user rules" in result
        assert "project rules" in result

    def test_project_content_appears_after_user_content(self, tmp_path):
        """Project-level content is appended after user-level so it takes priority."""
        (tmp_path / "WIDDX.md").write_text("project rules", encoding="utf-8")

        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = True
            user_md_mock.read_text.return_value = "user rules"
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            result = _load_project_md(obj)

        user_pos = result.index("user rules")
        project_pos = result.index("project rules")
        assert project_pos > user_pos, "Project content must appear after user content"

    def test_only_user_md_when_no_project_file(self, tmp_path):
        """Returns only user-level content when no project file exists."""
        obj = _make_repl(tmp_path)
        with patch("widdx.repl.context.Path") as mock_path_cls:
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = True
            user_md_mock.read_text.return_value = "user global rules"
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            result = _load_project_md(obj)

        assert result == "user global rules"


# ── REQ-5.5: 10 KB size warning ───────────────────────────────────────────

class TestSizeWarning:
    def test_no_warning_for_small_file(self, tmp_path):
        """No warning printed when content is under 10 KB."""
        (tmp_path / "WIDDX.md").write_text("small content", encoding="utf-8")

        obj = _make_repl(tmp_path)
        mock_console = MagicMock()

        with patch("widdx.repl.context.Path") as mock_path_cls, \
             patch("widdx.ui.get_console", return_value=mock_console):
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            _load_project_md(obj)

        # No warning call should have been made
        for call in mock_console.print.call_args_list:
            args = call[0]
            if args:
                assert "tokens" not in str(args[0]).lower()

    def test_warning_triggered_for_large_file(self, tmp_path):
        """Warning is printed when content exceeds 10 KB."""
        large_content = "x" * (10 * 1024 + 1)  # just over 10 KB
        (tmp_path / "WIDDX.md").write_text(large_content, encoding="utf-8")

        obj = _make_repl(tmp_path)
        mock_console = MagicMock()

        with patch("widdx.repl.context.Path") as mock_path_cls, \
             patch("widdx.ui.get_console", return_value=mock_console):
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            _load_project_md(obj)

        printed_texts = [str(call[0][0]) for call in mock_console.print.call_args_list if call[0]]
        assert any("tokens" in t.lower() for t in printed_texts), (
            "Expected a token-consumption warning for files over 10 KB"
        )

    def test_warning_includes_kb_size(self, tmp_path):
        """Warning message includes the file size in KB."""
        large_content = "y" * (15 * 1024)  # 15 KB
        (tmp_path / "WIDDX.md").write_text(large_content, encoding="utf-8")

        obj = _make_repl(tmp_path)
        mock_console = MagicMock()

        with patch("widdx.repl.context.Path") as mock_path_cls, \
             patch("widdx.ui.get_console", return_value=mock_console):
            user_md_mock = MagicMock()
            user_md_mock.exists.return_value = False
            mock_path_cls.return_value.expanduser.return_value = user_md_mock
            mock_path_cls.cwd.return_value.__truediv__ = lambda self, name: tmp_path / name

            _load_project_md(obj)

        printed_texts = [str(call[0][0]) for call in mock_console.print.call_args_list if call[0]]
        assert any("KB" in t for t in printed_texts), (
            "Expected warning to include KB size"
        )


# ── REQ-5.4: /memory command ──────────────────────────────────────────────

class TestMemoryCommand:
    def test_show_memory_displays_content(self):
        """_show_memory prints the loaded _project_md content."""
        from widdx.repl.commands import _show_memory

        obj = MagicMock()
        obj._project_md = "# My Project\nUse strict typing."
        mock_console = MagicMock()

        with patch("widdx.ui.get_console", return_value=mock_console), \
             patch("widdx.ui.render_markdown") as mock_render:
            _show_memory(obj)

        mock_render.assert_called_once_with("# My Project\nUse strict typing.")

    def test_show_memory_prints_no_content_message_when_empty(self):
        """_show_memory prints a helpful message when _project_md is empty."""
        from widdx.repl.commands import _show_memory

        obj = MagicMock()
        obj._project_md = ""
        mock_console = MagicMock()

        with patch("widdx.ui.get_console", return_value=mock_console):
            _show_memory(obj)

        printed_texts = [str(call[0][0]) for call in mock_console.print.call_args_list if call[0]]
        assert any("WIDDX.md" in t for t in printed_texts)

    def test_show_memory_handles_missing_attribute(self):
        """_show_memory handles objects that don't have _project_md yet."""
        from widdx.repl.commands import _show_memory

        obj = MagicMock(spec=[])  # no attributes
        mock_console = MagicMock()

        with patch("widdx.ui.get_console", return_value=mock_console):
            # Should not raise
            _show_memory(obj)

        printed_texts = [str(call[0][0]) for call in mock_console.print.call_args_list if call[0]]
        assert any("WIDDX.md" in t for t in printed_texts)
