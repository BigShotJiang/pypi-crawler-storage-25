"""Tests for widdx/web/__init__.py — RateLimiter, WiddxWebServer."""
import pytest


class TestWebModuleImports:
    def test_has_web_flag(self):
        from widdx.web import HAS_WEB
        assert isinstance(HAS_WEB, bool)


class TestRateLimiter:
    def test_init_defaults(self):
        from widdx.web import RateLimiter
        rl = RateLimiter()
        assert rl._default_limit == 60
        assert rl._window == 60.0

    def test_init_custom(self):
        from widdx.web import RateLimiter
        rl = RateLimiter(default_limit=30, window=120.0)
        assert rl._default_limit == 30

    def test_check_allows_first_request(self):
        from widdx.web import RateLimiter
        rl = RateLimiter(default_limit=10000)  # Very high limit
        assert rl.check("192.168.1.1") is True

    def test_check_blocks_at_limit(self):
        from widdx.web import RateLimiter
        rl = RateLimiter(default_limit=2)
        ip = "10.0.0.1"
        assert rl.check(ip) is True
        assert rl.check(ip) is True
        assert rl.check(ip) is False  # Third request blocked

    def test_check_custom_limit(self):
        from widdx.web import RateLimiter
        rl = RateLimiter(default_limit=100)
        ip = "10.0.0.2"
        assert rl.check(ip, limit=2) is True
        assert rl.check(ip, limit=2) is True
        assert rl.check(ip, limit=2) is False


class TestWebHelpers:
    def test_mask_key(self):
        from widdx.web import _mask_key
        masked = _mask_key("sk-abc123def456")
        assert "sk-" in masked or "*" in masked or "..." in masked
        assert "abc123def456" not in masked  # Key should be partially hidden

    def test_mask_key_short(self):
        from widdx.web import _mask_key
        masked = _mask_key("abc")
        assert isinstance(masked, str)

    def test_mask_key_empty(self):
        from widdx.web import _mask_key
        masked = _mask_key("")
        assert isinstance(masked, str)

    def test_path_within_project(self):
        from widdx.web import _path_within_project
        from pathlib import Path
        # Should handle any path gracefully
        result = _path_within_project(Path("/tmp/test.txt"))
        assert isinstance(result, bool)

    def test_get_project_root(self):
        from widdx.web import _get_project_root
        root = _get_project_root()
        assert isinstance(root, __import__("pathlib").Path)


class TestWiddxWebServer:
    def test_class_exists(self):
        from widdx.web import WiddxWebServer
        assert WiddxWebServer is not None

    def test_start_web_server_signature(self):
        from widdx.web import start_web_server
        assert callable(start_web_server)
