"""Tests for widdx.hooks.security_check — destructive command blocking."""
from __future__ import annotations

import json
import sys
from io import StringIO
from unittest.mock import patch

from widdx.hooks.security_check import DESTRUCTIVE_PATTERNS, is_destructive, main


class TestIsDestructive:
    """Pure function: returns (bool, pattern) for destructive commands."""

    def test_safe_command(self):
        destructive, pattern = is_destructive("ls -la")
        assert destructive is False
        assert pattern == ""

    def test_safe_git_command(self):
        destructive, _ = is_destructive("git status")
        assert destructive is False

    def test_empty_command(self):
        destructive, pattern = is_destructive("")
        assert destructive is False
        assert pattern == ""

    def test_rm_rf_root(self):
        destructive, pattern = is_destructive("rm -rf /")
        assert destructive is True
        assert "rm" in pattern

    def test_rm_rf_home(self):
        destructive, _ = is_destructive("rm -rf ~")
        assert destructive is True

    def test_rm_rf_home_var(self):
        destructive, _ = is_destructive("rm -rf $HOME")
        assert destructive is True

    def test_fork_bomb(self):
        destructive, _ = is_destructive(":(){ :|:& };:")
        assert destructive is True

    def test_drop_table(self):
        destructive, _ = is_destructive("DROP TABLE users;")
        assert destructive is True

    def test_drop_database(self):
        destructive, _ = is_destructive("DROP DATABASE production;")
        assert destructive is True

    def test_truncate_table(self):
        destructive, _ = is_destructive("TRUNCATE TABLE logs;")
        assert destructive is True

    def test_alter_table_drop(self):
        destructive, _ = is_destructive("ALTER TABLE users DROP COLUMN email;")
        assert destructive is True

    def test_git_push_force_main(self):
        destructive, _ = is_destructive("git push --force origin main")
        assert destructive is True

    def test_git_push_force_master(self):
        destructive, _ = is_destructive("git push --force origin master")
        assert destructive is True

    def test_git_reset_hard(self):
        destructive, _ = is_destructive("git reset --hard HEAD~1")
        assert destructive is True

    def test_docker_rm_f(self):
        destructive, _ = is_destructive("docker rm -f container1")
        assert destructive is True

    def test_docker_system_prune(self):
        destructive, _ = is_destructive("docker system prune -af")
        assert destructive is True

    def test_chmod_777_root(self):
        destructive, _ = is_destructive("chmod -R 777 /")
        assert destructive is True

    def test_chown_root(self):
        destructive, _ = is_destructive("chown -R root /etc")
        assert destructive is True

    def test_drop_schema(self):
        destructive, _ = is_destructive("DROP SCHEMA public CASCADE;")
        assert destructive is True

    def test_revoke_all(self):
        destructive, _ = is_destructive("REVOKE ALL ON DATABASE mydb FROM user;")
        assert destructive is True

    def test_case_insensitive(self):
        destructive, _ = is_destructive("Drop Table Users")
        assert destructive is True

    def test_del_f_s(self):
        destructive, _ = is_destructive("del /f /s C:\\windows")
        assert destructive is True

    def test_format_drive(self):
        destructive, _ = is_destructive("format C:")
        assert destructive is True

    def test_mkfs(self):
        destructive, _ = is_destructive("mkfs.ext4 /dev/sda1")
        assert destructive is True

    def test_dd_if(self):
        destructive, _ = is_destructive("dd if=/dev/zero of=/dev/sda")
        assert destructive is True


class TestDestructivePatternsCoverage:
    """Ensure all patterns in DESTRUCTIVE_PATTERNS are exercised."""

    def test_all_patterns_tested(self):
        # The test methods above collectively cover all patterns.
        # This is a structural assertion to catch regressions.
        assert len(DESTRUCTIVE_PATTERNS) > 0
        # Every pattern should be a valid regex
        import re
        for p in DESTRUCTIVE_PATTERNS:
            re.compile(p)


class TestMain:
    """main() — reads stdin, checks command, exits appropriately."""

    def test_safe_command_exits_0(self):
        stdin = StringIO(json.dumps({"tool_input": {"command": "echo hello"}}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit:
            main()
            mock_exit.assert_called_once_with(0)

    def test_destructive_command_exits_2(self):
        stdin = StringIO(json.dumps({"tool_input": {"command": "rm -rf /"}}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "stdout", StringIO()), patch.object(sys, "exit") as mock_exit:
            main()
            mock_exit.assert_any_call(2)

    def test_destructive_command_prints_deny_json(self):
        stdin = StringIO(json.dumps({"tool_input": {"command": "DROP TABLE users;"}}))
        out = StringIO()
        with patch.object(sys, "stdin", stdin), patch.object(sys, "stdout", out), patch.object(sys, "exit"):
            main()
            result = json.loads(out.getvalue())
            assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_empty_input_exits_0(self):
        stdin = StringIO(json.dumps({}))
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit:
            main()
            mock_exit.assert_any_call(0)

    def test_invalid_json_exits_0(self):
        stdin = StringIO("not json")
        with patch.object(sys, "stdin", stdin), patch.object(sys, "exit") as mock_exit:
            main()
            mock_exit.assert_any_call(0)
