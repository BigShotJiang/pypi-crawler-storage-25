"""Tests for the keyword-based task classifier in ExecutionPipeline."""
from __future__ import annotations

import pytest


# We test _analyze_input in isolation by patching the router so no API call is made.

class _FakeRouter:
    """Minimal router stub — classify and call_architect never called in keyword path."""
    def classify(self, _): return "executor"
    def call_architect(self, *_a, **_kw): return {"text": '{"intent":"x","complexity":1}'}
    def call_executor(self, *_a, **_kw): return {"text": '{"intent":"x","complexity":1}'}
    def infer_task_type(self, task: str) -> str:
        lowered = task.lower()
        if any(kw in lowered for kw in ["build", "create", "generate", "implement"]):
            return "build"
        if any(kw in lowered for kw in ["fix", "debug", "resolve"]):
            return "fix"
        if any(kw in lowered for kw in ["improve", "optimize", "refactor"]):
            return "improve"
        if any(kw in lowered for kw in ["design", "architecture", "plan"]):
            return "design"
        return "general"
    def is_ready(self): return False
    PRICING = {}
    def _estimate_tokens(self, _): return 0


@pytest.fixture
def pipeline():
    from widdx.pipeline import ExecutionPipeline
    from widdx.memory import MemoryStore
    from widdx.evolution import EvolutionEngine
    from widdx.agent_factory import AgentFactory
    import tempfile, os

    with tempfile.TemporaryDirectory() as d:
        mem = MemoryStore(os.path.join(d, "mem.db"))
        router = _FakeRouter()
        factory = AgentFactory(router)
        evo = EvolutionEngine(mem, {})
        pipe = ExecutionPipeline(router, factory, mem, evo, {})
        yield pipe
        mem.close()


class TestKeywordClassifier:
    """_analyze_input must classify complexity purely from keywords — no API call."""

    @pytest.mark.parametrize("cmd,expected_min", [
        ("build a fullstack app", 4),
        ("create a complete saas platform", 3),
        ("implement a login endpoint", 2),
        ("fix the null pointer bug", 2),
        ("generate a REST API", 2),
        ("refactor the auth module", 3),
    ])
    def test_complexity_from_keywords(self, pipeline, cmd, expected_min):
        _, complexity = pipeline._analyze_input(cmd)
        assert complexity >= expected_min, (
            f"'{cmd}' expected complexity >= {expected_min}, got {complexity}"
        )

    def test_fullstack_keyword_gives_high_complexity(self, pipeline):
        _, c = pipeline._analyze_input("build a fullstack e-commerce site")
        assert c >= 4

    def test_fix_keyword_gives_moderate_complexity(self, pipeline):
        _, c = pipeline._analyze_input("fix the login bug")
        assert c >= 2

    def test_returns_tuple(self, pipeline):
        result = pipeline._analyze_input("create a REST API")
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_complexity_in_valid_range(self, pipeline):
        for cmd in ["build x", "fix y", "create z", "refactor w"]:
            _, c = pipeline._analyze_input(cmd)
            assert 1 <= c <= 5, f"Complexity {c} out of range for '{cmd}'"
