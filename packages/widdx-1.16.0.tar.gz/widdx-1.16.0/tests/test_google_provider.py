"""Quick test to verify Google Gemini provider integration."""
from widdx.router import AIRouter

# Test 1: With Google key
config = {
    "__env__": {"deepseek_key": None, "google_key": "AIza-fake-key-123"},
    "models": {},
}
r = AIRouter(config, None)

google_entries = [p for p in r._providers if p["name"] == "google"]
print(f"Google entries: {len(google_entries)}")
for e in google_entries:
    print(f"  arch={e['architect_model']}  exec={e['executor_model']}")

providers = r.list_providers()
names = {p["name"] for p in providers}
print(f"All providers: {names}")

assert "google" in names, "FAIL: Google not in providers!"
assert "opencode" in names, "FAIL: OpenCode not in providers!"
assert len(google_entries) == 2, f"FAIL: Expected 2 Google entries, got {len(google_entries)}"
assert google_entries[0]["architect_model"] == "gemini-2.5-pro"
assert google_entries[0]["executor_model"] == "gemini-2.0-flash"
assert google_entries[1]["executor_model"] == "gemini-2.5-flash"

print("\nTest 1 PASSED: Google provider built correctly with API key")

# Test 2: Without Google key
config2 = {
    "__env__": {"deepseek_key": None, "google_key": None},
    "models": {},
}
r2 = AIRouter(config2, None)
google_entries2 = [p for p in r2._providers if p["name"] == "google"]
assert len(google_entries2) == 0, f"FAIL: Google should not appear without key, got {len(google_entries2)}"
print("Test 2 PASSED: Google not built without API key")

# Test 3: Pricing
from widdx.router.pricing import PRICING
gemini_models = ["gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro"]
for m in gemini_models:
    assert m in PRICING, f"FAIL: {m} not in PRICING"
    assert PRICING[m]["input"] == 0.0
    assert PRICING[m]["output"] == 0.0
print("Test 3 PASSED: Gemini pricing registered correctly")

# Test 4: Config loader
from widdx.config import load_config
import os
os.environ["GOOGLE_API_KEY"] = "test-from-env"
cfg = load_config()
assert cfg["__env__"]["google_key"] == "test-from-env", "FAIL: GOOGLE_API_KEY env not loaded"
print("Test 4 PASSED: GOOGLE_API_KEY env var loaded by config")
del os.environ["GOOGLE_API_KEY"]

print("\nALL TESTS PASSED - Google Gemini is correctly integrated")
