"""Comprehensive tests for all 12 built-in agents and the AgentRegistry."""
import pytest
from widdx.agents.registry import AgentRegistry, BUILTIN_AGENTS, _ALIASES

REQUIRED_KEYS = ["name", "emoji", "domain", "description", "system_prompt"]
EXPECTED_DOMAINS = {
    "backend", "frontend", "devops", "qa", "architect",
    "fullstack", "security", "data", "reviewer",
    "laravel", "systems", "database",
}
EXPECTED_NAMES = [
    "Backend Architect",
    "Frontend Developer",
    "DevOps Automator",
    "QA Engineer",
    "Software Architect",
    "Full-Stack Developer",
    "Security Reviewer",
    "Data Engineer",
    "Code Reviewer",
    "Laravel Architect",
    "Systems Architect",
    "Database Architect",
]


class TestAgentDefinitions:
    def test_all_agents_registered(self):
        assert len(BUILTIN_AGENTS) == 12, f"Expected 12 agents, got {len(BUILTIN_AGENTS)}"

    def test_domains_match_expected(self):
        assert set(BUILTIN_AGENTS.keys()) == EXPECTED_DOMAINS

    def test_each_agent_has_required_keys(self):
        for domain, agent in BUILTIN_AGENTS.items():
            for key in REQUIRED_KEYS:
                assert key in agent, f"{domain}: missing key '{key}'"

    def test_no_empty_system_prompts(self):
        for domain, agent in BUILTIN_AGENTS.items():
            prompt = agent["system_prompt"]
            assert prompt, f"{domain}: empty system_prompt"
            assert len(prompt) > 100, f"{domain}: system_prompt too short ({len(prompt)} chars)"

    def test_no_empty_descriptions(self):
        for domain, agent in BUILTIN_AGENTS.items():
            assert agent["description"], f"{domain}: empty description"

    def test_each_agent_has_emoji(self):
        for domain, agent in BUILTIN_AGENTS.items():
            assert agent["emoji"], f"{domain}: missing emoji"

    def test_domain_field_matches_key(self):
        for domain, agent in BUILTIN_AGENTS.items():
            assert agent["domain"] == domain, f"{domain}: domain field mismatch ({agent['domain']})"

    def test_names_match_expected(self):
        actual_names = [agent["name"] for agent in BUILTIN_AGENTS.values()]
        # Some agents vary; check all 12 names are present
        missing = [n for n in EXPECTED_NAMES if n not in actual_names]
        assert not missing, f"Missing names: {missing}"

    def test_system_prompt_contains_role(self):
        for domain, agent in BUILTIN_AGENTS.items():
            prompt = agent["system_prompt"]
            name = agent["name"]
            # At minimum, the prompt should be substantial
            assert "You are" in prompt or "#" in prompt or "##" in prompt, \
                f"{domain}: system_prompt missing identity markers"


class TestAgentLookups:
    def test_get_by_domain(self):
        for domain in EXPECTED_DOMAINS:
            agent = AgentRegistry.get(domain)
            assert agent is not None, f"get('{domain}') returned None"
            assert agent["domain"] == domain

    def test_get_unknown_domain(self):
        assert AgentRegistry.get("nonexistent_xyz") is None

    def test_get_blank_domain(self):
        assert AgentRegistry.get("") is None

    def test_get_case_insensitive(self):
        assert AgentRegistry.get("BACKEND") is not None
        assert AgentRegistry.get("  backend  ") is not None

    def test_get_system_prompt(self):
        prompt = AgentRegistry.get_system_prompt("qa")
        assert "QA" in prompt or "test" in prompt.lower()
        assert len(prompt) > 100

    def test_get_system_prompt_fallback(self):
        prompt = AgentRegistry.get_system_prompt("nonexistent", fallback="fallback text")
        assert prompt == "fallback text"

    def test_get_system_prompt_empty_fallback(self):
        prompt = AgentRegistry.get_system_prompt("nonexistent")
        assert prompt == ""

    def test_list_agents(self):
        agents = AgentRegistry.list_agents()
        assert len(agents) == 12
        for a in agents:
            assert "name" in a
            assert "emoji" in a
            assert "domain" in a
            assert "description" in a

    def test_domains(self):
        domains = AgentRegistry.domains()
        assert len(domains) == 12
        assert set(domains) == EXPECTED_DOMAINS


class TestAliases:
    def test_alias_count(self):
        assert len(_ALIASES) >= 40, f"Expected 40+ aliases, got {len(_ALIASES)}"

    def test_all_aliases_map_to_valid_domains(self):
        for alias, domain in _ALIASES.items():
            assert domain in BUILTIN_AGENTS, f"Alias '{alias}' maps to unknown domain '{domain}'"

    def test_alias_lookup_works(self):
        assert AgentRegistry.get("backend engineer") is not None
        assert AgentRegistry.get("react developer") is not None
        assert AgentRegistry.get("pentester") is not None
        assert AgentRegistry.get("dba") is not None

    def test_common_aliases_exist(self):
        key_aliases = [
            "react developer", "pentester", "dba", "tester",
            "tech lead", "full-stack developer", "api developer",
            "platform engineer", "pr reviewer", "php developer",
        ]
        for alias in key_aliases:
            assert alias in _ALIASES, f"Missing alias: {alias}"

    def test_alias_returns_correct_agent(self):
        agent = AgentRegistry.get("react developer")
        assert agent is not None
        assert agent["domain"] == "frontend"

        agent = AgentRegistry.get("pentester")
        assert agent is not None
        assert agent["domain"] == "security"


class TestCrossAgentConsistency:
    def test_no_duplicate_names(self):
        names = [a["name"] for a in BUILTIN_AGENTS.values()]
        assert len(names) == len(set(names)), f"Duplicate names: {names}"

    def test_all_prompts_reference_their_domain(self):
        for domain, agent in BUILTIN_AGENTS.items():
            prompt = agent["system_prompt"].lower()
            name = agent["name"].lower()
            assert any(word in prompt for word in name.split()), \
                f"{domain}: prompt doesn't mention agent name"

    def test_vibe_field_present(self):
        vibed = sum(1 for a in BUILTIN_AGENTS.values() if a.get("vibe"))
        assert vibed >= 5, f"Only {vibed}/12 agents have vibe field"
