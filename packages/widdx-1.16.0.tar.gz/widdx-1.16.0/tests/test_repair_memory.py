"""Tests for the RepairMemory self-learning fix pattern system."""
from __future__ import annotations

import re
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from widdx.repair_memory import RepairMemory


# ============================================================================
# Error Normalization
# ============================================================================

class TestNormalizeError:
    """Unit tests for error message normalization."""

    def test_strips_windows_paths(self):
        error = r'File "C:\Users\bob\project\src\main.py", line 42'
        etype, norm = RepairMemory.normalize_error(error)
        assert "C:\\Users" not in norm
        assert r"C:\Users" not in norm

    def test_strips_unix_paths(self):
        error = 'File "/home/user/project/src/main.py", line 10'
        etype, norm = RepairMemory.normalize_error(error)
        assert "/home/user" not in norm

    def test_replaces_line_numbers(self):
        error = "main.py:42: SyntaxError: invalid syntax"
        etype, norm = RepairMemory.normalize_error(error)
        assert ":42:" not in norm

    def test_replaces_line_keyword(self):
        error = "line 123, in process_data"
        etype, norm = RepairMemory.normalize_error(error)
        assert "line 123" not in norm

    def test_replaces_hex_addresses(self):
        error = "at 0x7ffe1234ab in function"
        etype, norm = RepairMemory.normalize_error(error)
        assert "0x7ffe1234ab" not in norm

    def test_extracts_syntax_error_type(self):
        etype, _ = RepairMemory.normalize_error("SyntaxError: invalid syntax")
        assert etype == "SyntaxError"

    def test_extracts_import_error_type(self):
        etype, _ = RepairMemory.normalize_error("ModuleNotFoundError: No module named 'foo'")
        assert etype == "ModuleNotFoundError"

    def test_extracts_name_error_type(self):
        etype, _ = RepairMemory.normalize_error("NameError: name 'db' is not defined")
        assert etype == "NameError"

    def test_extracts_assertion_error_type(self):
        etype, _ = RepairMemory.normalize_error("AssertionError: assert 42 == 0")
        assert etype == "AssertionError"

    def test_empty_error(self):
        etype, norm = RepairMemory.normalize_error("")
        assert etype == ""
        assert norm == ""

    def test_whitespace_normalization(self):
        error = "  NameError:   name   'x'\n  is not   defined  "
        etype, norm = RepairMemory.normalize_error(error)
        assert "  " not in norm

    def test_truncates_long_errors(self):
        long_msg = "x" * 600
        etype, norm = RepairMemory.normalize_error(long_msg)
        assert len(norm) <= 500


# ============================================================================
# Fingerprint Stability
# ============================================================================

class TestFingerprint:
    """Unit tests for error fingerprinting stability."""

    def test_same_error_same_fingerprint(self):
        err1 = "NameError: name 'x' is not defined in <PATH>"
        err2 = "NameError: name 'x' is not defined in <PATH>"
        fps1 = RepairMemory.fingerprint_errors([err1])
        fps2 = RepairMemory.fingerprint_errors([err2])
        assert fps1[0]["fingerprint"] == fps2[0]["fingerprint"]

    def test_different_paths_same_fingerprint(self):
        err1 = r'File "C:\Users\alice\main.py", line 10: NameError: x'
        err2 = r'File "/home/bob/main.py", line 99: NameError: x'
        fp1 = RepairMemory.fingerprint_errors([err1])[0]["fingerprint"]
        fp2 = RepairMemory.fingerprint_errors([err2])[0]["fingerprint"]
        assert fp1 == fp2

    def test_different_line_numbers_same_fingerprint(self):
        err1 = "main.py:10: SyntaxError: bad"
        err2 = "main.py:999: SyntaxError: bad"
        fp1 = RepairMemory.fingerprint_errors([err1])[0]["fingerprint"]
        fp2 = RepairMemory.fingerprint_errors([err2])[0]["fingerprint"]
        assert fp1 == fp2

    def test_different_errors_different_fingerprints(self):
        err1 = "SyntaxError: invalid syntax"
        err2 = "ImportError: no module named foo"
        fp1 = RepairMemory.fingerprint_errors([err1])[0]["fingerprint"]
        fp2 = RepairMemory.fingerprint_errors([err2])[0]["fingerprint"]
        assert fp1 != fp2

    def test_fingerprint_is_deterministic(self):
        error = "TypeError: unsupported operand type(s) for +: 'int' and 'str'"
        first = RepairMemory.fingerprint_errors([error])[0]["fingerprint"]
        for _ in range(10):
            assert RepairMemory.fingerprint_errors([error])[0]["fingerprint"] == first


# ============================================================================
# Store and Lookup
# ============================================================================

class TestStoreAndLookup:
    """Integration tests for storing and retrieving fix patterns."""

    def test_store_new_pattern(self, repair_memory):
        errors = ["NameError: name 'db' is not defined"]
        fp = repair_memory.store(errors, "import db; db.init()", "python")
        assert fp is not None
        assert len(fp) == 32

    def test_lookup_returns_match(self, repair_memory):
        errors = ["NameError: name 'db' is not defined"]
        repair_memory.store(errors, "import db", "python")
        results = repair_memory.lookup(errors, "python")
        assert len(results) == 1
        assert results[0]["fix_template"] == "import db"

    def test_lookup_empty_when_no_match(self, repair_memory):
        repair_memory.store(
            ["NameError: name 'db' is not defined"],
            "import db", "python",
        )
        results = repair_memory.lookup(["TotallyDifferent: unknown"], "python")
        assert results == []

    def test_store_does_not_overwrite(self, repair_memory):
        errors = ["NameError: name 'x' is not defined"]
        fp1 = repair_memory.store(errors, "x = 1", "python")
        fp2 = repair_memory.store(errors, "x = 2", "python")
        patterns = repair_memory.lookup(errors, "python")
        assert len(patterns) == 1
        assert patterns[0]["fix_template"] == "x = 1"

    def test_multiple_errors_multiple_fingerprints(self, repair_memory):
        errors = [
            "NameError: name 'db' is not defined",
            "ImportError: no module named 'requests'",
        ]
        repair_memory.store(errors, "import db\nimport requests", "python")
        results = repair_memory.lookup(errors, "python")
        assert len(results) == 1  # first error's fingerprint
        results2 = repair_memory.lookup([errors[1]], "python")
        assert results2 == []  # second error wasn't stored

    def test_store_empty_errors_returns_none(self, repair_memory):
        fp = repair_memory.store([], "fix code", "python")
        assert fp is None

    def test_disabled_returns_empty(self, memory):
        rm = RepairMemory(memory, {"repair_memory": {"enabled": False}})
        rm.store(["NameError: x"], "fix", "python")
        assert rm.lookup(["NameError: x"], "python") == []


# ============================================================================
# Confidence Tracking
# ============================================================================

class TestConfidence:
    """Tests for Laplace-smoothed confidence calculation."""

    def test_initial_confidence_is_0_5(self, repair_memory):
        errors = ["SyntaxError: invalid syntax"]
        repair_memory.store(errors, "fix", "python")
        patterns = repair_memory.lookup(errors, "python")
        assert patterns[0]["confidence"] == pytest.approx(0.5)

    def test_record_success_increases_confidence(self, repair_memory):
        errors = ["SyntaxError: invalid syntax"]
        # Store with initial confidence
        fps = repair_memory.fingerprint_errors(errors)
        repair_memory.store(errors, "fix", "python")
        # Record 2 successes
        repair_memory.record_success(fps[0]["fingerprint"])
        repair_memory.record_success(fps[0]["fingerprint"])
        patterns = repair_memory.lookup(errors, "python")
        # After 2 successes: (2+1)/(2+0+2) = 0.75
        assert patterns[0]["confidence"] == pytest.approx(0.75)

    def test_record_failure_decreases_confidence(self, repair_memory):
        errors = ["SyntaxError: invalid syntax"]
        fps = repair_memory.fingerprint_errors(errors)
        repair_memory.store(errors, "fix", "python")
        repair_memory.record_success(fps[0]["fingerprint"])
        repair_memory.record_success(fps[0]["fingerprint"])
        repair_memory.record_failure(fps[0]["fingerprint"])
        patterns = repair_memory.lookup(errors, "python")
        # After 2S,1F: (2+1)/(2+1+2) = 0.60
        assert patterns[0]["confidence"] == pytest.approx(0.60)

    def test_confidence_approaches_1_with_repeated_success(self, repair_memory):
        errors = ["TypeError: bad type"]
        fps = repair_memory.fingerprint_errors(errors)
        repair_memory.store(errors, "fix", "python")
        for _ in range(10):
            repair_memory.record_success(fps[0]["fingerprint"])
        patterns = repair_memory.lookup(errors, "python")
        assert patterns[0]["confidence"] > 0.9

    def test_record_with_invalid_fingerprint(self, repair_memory):
        # Should not raise
        repair_memory.record_success("nonexistent_fingerprint")
        repair_memory.record_failure("nonexistent_fingerprint")


# ============================================================================
# Eviction
# ============================================================================

class TestEviction:
    """Tests for pattern eviction when at capacity."""

    def test_evicts_lowest_confidence_when_full(self, memory):
        rm = RepairMemory(memory, {"repair_memory": {"enabled": True, "min_confidence": 0.0, "max_patterns": 2}})
        # Store 2 patterns
        rm.store(["ErrorA: a"], "fix_a", "python")
        rm.store(["ErrorB: b"], "fix_b", "python")
        # Make first pattern fail (lower confidence)
        fps = rm.fingerprint_errors(["ErrorA: a"])
        rm.record_failure(fps[0]["fingerprint"])
        # Store 3rd pattern — should evict ErrorA (lowest confidence)
        fp3 = rm.store(["ErrorC: c"], "fix_c", "python")
        assert fp3 is not None
        stats = rm.stats()
        assert stats["total_patterns"] <= 2

    def test_eviction_does_not_crash_on_empty_table(self, repair_memory):
        stats = repair_memory.stats()
        assert stats["total_patterns"] == 0


# ============================================================================
# Fix Template Extraction
# ============================================================================

class TestFixTemplateExtraction:
    """Tests for extracting fix code from LLM responses."""

    def test_extracts_code_blocks(self):
        llm_output = (
            "Here's the fix:\n\n"
            "### src/main.py\n"
            "```python\nimport os\nimport sys\nx = 1\ny = 2\nz = 3\n```\n"
        )
        result = RepairMemory.extract_fix_template(llm_output, ["src/main.py"])
        assert "import os" in result

    def test_empty_input_returns_empty(self):
        assert RepairMemory.extract_fix_template("", []) == ""

    def test_ignores_short_blocks(self):
        llm_output = (
            "```\nshort\n```\n\n"
            "### file.py\n"
            "```python\ndef real_fix():\n    return True\n```\n"
        )
        result = RepairMemory.extract_fix_template(llm_output, ["file.py"])
        assert "real_fix" in result
        assert "short" not in result

    def test_takes_last_large_block(self):
        llm_output = (
            "### a.py\n```python\nfirst_fix = True\nx = 1\ny = 2\n```\n\n"
            "### b.py\n```python\nsecond_fix = True\na = 1\nb = 2\n```\n"
        )
        result = RepairMemory.extract_fix_template(llm_output, ["a.py", "b.py"])
        assert "second_fix" in result


# ============================================================================
# Verifier Integration
# ============================================================================

class TestIntegrationWithVerifier:
    """Tests for RepairMemory integration with ProjectVerifier."""

    def test_repair_memory_hit_skips_llm(self, tmp_path, memory):
        """When a known fix exists, fix is applied directly from RepairMemory."""
        from widdx.verifier import ProjectVerifier, VerifyResult
        from unittest.mock import patch

        test_file = tmp_path / "broken.py"
        test_file.write_text("x = undefined_var\n", encoding="utf-8")

        rm = RepairMemory(memory, {"repair_memory": {"enabled": True, "min_confidence": 0.0}})
        errors = ["NameError: name 'undefined_var' is not defined"]
        rm.store(errors, "### broken.py\n```python\nx = 42\ny = 1\nz = 2\n```\n", "python")

        verifier = ProjectVerifier(router=None, repair_memory=rm)

        # First _run_tests fails (triggers auto_fix), second succeeds (fix applied)
        with patch.object(verifier, '_run_tests') as mock_tests:
            with patch.object(verifier, '_syntax_check', return_value=[]):
                mock_tests.side_effect = [
                    VerifyResult(passed=False, errors=errors),
                    VerifyResult(passed=True),
                ]
                verifier.verify_step([str(test_file)], auto_fix=True)

        content = test_file.read_text(encoding="utf-8")
        assert "42" in content

    def test_llm_fix_stores_pattern(self, tmp_path, memory):
        """After LLM fix succeeds, a pattern is stored in RepairMemory."""
        from widdx.verifier import ProjectVerifier, VerifyResult
        from unittest.mock import patch

        test_file = tmp_path / "broken2.py"
        test_file.write_text("result = 1 / 0\n", encoding="utf-8")

        router = MagicMock()
        router.call_executor.return_value = {
            "text": (
                "### broken2.py\n"
                "```python\n"
                "try:\n"
                "    result = 1 / 1\n"
                "except ZeroDivisionError:\n"
                "    result = 0\n"
                "```\n"
            ),
        }

        rm = RepairMemory(memory, {"repair_memory": {"enabled": True, "min_confidence": 0.0}})
        verifier = ProjectVerifier(router=router, repair_memory=rm)

        errors = ["ZeroDivisionError: division by zero"]
        # First call fails (triggers auto_fix), second succeeds (fix applied)
        with patch.object(verifier, '_run_tests') as mock_tests:
            with patch.object(verifier, '_syntax_check', return_value=[]):
                mock_tests.side_effect = [
                    VerifyResult(passed=False, errors=errors),
                    VerifyResult(passed=True),
                ]
                verifier.verify_step([str(test_file)], auto_fix=True)

        stats = rm.stats()
        assert stats["total_patterns"] >= 1

    def test_disabled_repair_memory_skips_lookup(self, tmp_path, memory):
        """When disabled, verifier goes straight to LLM path."""
        from widdx.verifier import ProjectVerifier, VerifyResult
        from unittest.mock import patch

        test_file = tmp_path / "broken3.py"
        test_file.write_text("x = bad\n", encoding="utf-8")

        rm = RepairMemory(memory, {"repair_memory": {"enabled": False}})
        rm.store(["NameError: name 'bad' is not defined"], "x = 1\ny = 2\nz = 3", "python")

        router = MagicMock()
        router.call_executor.return_value = {
            "text": "### broken3.py\n```python\nx = 1\ny = 2\nz = 3\n```\n",
        }

        verifier = ProjectVerifier(router=router, repair_memory=rm)

        with patch.object(verifier, '_run_tests', return_value=VerifyResult(passed=False, errors=["NameError"])):
            with patch.object(verifier, '_syntax_check', return_value=[]):
                verifier.verify_step([str(test_file)], auto_fix=True)

        router.call_executor.assert_called()

    def test_verifier_accepts_no_repair_memory(self):
        """Verifier works without RepairMemory (backward compat)."""
        from widdx.verifier import ProjectVerifier
        verifier = ProjectVerifier(router=None, repair_memory=None)
        result = verifier.verify_step([], auto_fix=False)
        assert result.passed is True

    def test_known_fix_failure_falls_through_to_llm(self, tmp_path, memory):
        """When known fix fails, rollback + fall through to LLM."""
        from widdx.verifier import ProjectVerifier, VerifyResult
        from unittest.mock import patch

        test_file = tmp_path / "broken4.py"
        original = "x = undefined_var\n"
        test_file.write_text(original, encoding="utf-8")

        router = MagicMock()
        router.call_executor.return_value = {
            "text": "### broken4.py\n```python\nx = 42\ny = 1\nz = 2\n```\n",
        }

        rm = RepairMemory(memory, {"repair_memory": {"enabled": True, "min_confidence": 0.0}})
        errors = ["NameError: name 'undefined_var' is not defined"]
        rm.store(
            errors,
            "### broken4.py\n```python\nstill_broken = undefined_var\nx = 1\ny = 2\n```\n",
            "python",
        )

        verifier = ProjectVerifier(router=router, repair_memory=rm)

        # First _run_tests returns failure (known fix doesn't pass), second succeeds (LLM fix)
        with patch.object(verifier, '_run_tests') as mock_tests:
            with patch.object(verifier, '_syntax_check', return_value=[]):
                mock_tests.return_value = VerifyResult(passed=False, errors=errors)
                verifier.verify_step([str(test_file)], auto_fix=True)

        # Should have fallen through to LLM
        router.call_executor.assert_called()


# ============================================================================
# Stats & Introspection
# ============================================================================

class TestStats:
    """Tests for stats and listing methods."""

    def test_stats_empty(self, repair_memory):
        s = repair_memory.stats()
        assert s["enabled"] is True
        assert s["total_patterns"] == 0

    def test_stats_with_patterns(self, repair_memory):
        repair_memory.store(["ErrorA: a"], "fix_a", "python")
        s = repair_memory.stats()
        assert s["total_patterns"] == 1

    def test_list_patterns(self, repair_memory):
        repair_memory.store(["ErrorA: a"], "fix_a", "python")
        repair_memory.store(["ErrorB: b"], "fix_b", "python")
        lst = repair_memory.list_patterns(limit=10)
        assert len(lst) == 2

    def test_disabled_stats(self, memory):
        rm = RepairMemory(memory, {"repair_memory": {"enabled": False}})
        assert rm.stats() == {"enabled": False}


# ============================================================================
# Detect Language
# ============================================================================

class TestDetectLanguage:
    """Tests for language detection used by verifier integration."""

    def test_detects_python(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._detect_language(["main.py"]) == "python"

    def test_detects_javascript(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._detect_language(["app.js"]) == "javascript"

    def test_detects_typescript(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._detect_language(["App.tsx"]) == "typescript"

    def test_detects_php(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._detect_language(["index.php"]) == "php"

    def test_detects_from_first_file(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._detect_language(["script.py", "style.css"]) == "python"

    def test_defaults_to_python(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._detect_language([]) == "python"


class TestInferFilePattern:
    """Tests for file pattern inference."""

    def test_common_extension(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._infer_file_pattern(["a.py", "b.py"]) == "*.py"

    def test_mixed_extensions(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._infer_file_pattern(["a.py", "b.js"]) == ""

    def test_empty_files(self):
        from widdx.verifier import ProjectVerifier
        assert ProjectVerifier._infer_file_pattern([]) == ""
