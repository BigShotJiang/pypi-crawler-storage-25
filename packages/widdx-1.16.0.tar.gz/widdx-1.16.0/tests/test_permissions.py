"""Tests for the PermissionManager — secure-by-default behaviour."""
from __future__ import annotations

import pytest

from widdx.permissions import PermissionManager


# ── Fixtures ───────────────────────────────────────────────────────────────

@pytest.fixture
def perm(tmp_path):
    """Fresh PermissionManager with temp storage — manual approval mode."""
    return PermissionManager(storage_path=str(tmp_path / "perms.json"), auto_approve=False)


# ── Default state ──────────────────────────────────────────────────────────

class TestDefaultState:
    def test_session_not_approved_by_default(self, perm):
        assert perm.is_session_approved is False

    def test_file_writes_always_allowed(self, perm):
        assert perm.ask("write", "/some/file.py", category="file") == "allow"

    def test_file_writes_allowed_even_when_denied(self, perm):
        perm.deny_session()
        assert perm.ask("write", "/some/file.py", category="file") == "allow"


# ── Session approval / denial ──────────────────────────────────────────────

class TestSessionControl:
    def test_approve_session_grants_shell(self, perm):
        perm.approve_session()
        assert perm.ask("shell", "npm run build", category="shell") == "allow"

    def test_deny_session_blocks_shell(self, perm):
        perm.deny_session()
        assert perm.ask("shell", "npm run build", category="shell") == "deny"

    def test_deny_overrides_previous_approval(self, perm):
        perm.approve_session()
        perm.deny_session()
        assert perm.ask("shell", "echo hi", category="shell") == "deny"


# ── Safe commands ──────────────────────────────────────────────────────────

class TestSafeCommands:
    def test_echo_allowed_without_prompt(self, perm):
        result = perm.ask("shell", "echo hello", category="shell")
        assert result == "allow"

    def test_git_status_allowed_without_prompt(self, perm):
        result = perm.ask("shell", "git status", category="shell")
        assert result == "allow"

    def test_git_log_allowed_without_prompt(self, perm):
        result = perm.ask("shell", "git log --oneline", category="shell")
        assert result == "allow"


# ── Destructive commands ───────────────────────────────────────────────────

class TestDestructiveCommands:
    def test_rm_rf_denied_when_user_says_no(self, perm, monkeypatch):
        # Patch _confirm_inline to avoid rich console output in tests
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._confirm_inline",
            lambda self, action, detail: "deny",
        )
        perm.approve_session()
        result = perm.ask("shell", "rm -rf /tmp/test", category="shell")
        assert result == "deny"

    def test_rm_rf_allowed_when_user_confirms(self, perm, monkeypatch):
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._confirm_inline",
            lambda self, action, detail: "allow",
        )
        perm.approve_session()
        result = perm.ask("shell", "rm -rf /tmp/test", category="shell")
        assert result == "allow"

    def test_drop_table_always_requires_confirm(self, perm, monkeypatch):
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._confirm_inline",
            lambda self, action, detail: "deny",
        )
        perm.approve_session()
        result = perm.ask("sql", "DROP TABLE users", category="shell")
        assert result == "deny"


# ── First-time session prompt ──────────────────────────────────────────────

class TestFirstTimePrompt:
    def test_first_shell_command_asks_user_yes(self, perm, monkeypatch):
        def _allow(self, detail):
            self._asked_this_session = True
            self._session_approved = True
            return "allow"
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._ask_session_approval", _allow
        )
        result = perm.ask("shell", "npm run build", category="shell")
        assert result == "allow"
        assert perm.is_session_approved is True

    def test_first_shell_command_asks_user_no(self, perm, monkeypatch):
        def _deny(self, detail):
            self._asked_this_session = True
            self._session_denied = True
            return "deny"
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._ask_session_approval", _deny
        )
        result = perm.ask("shell", "npm run build", category="shell")
        assert result == "deny"
        assert perm.is_session_approved is False

    def test_second_shell_command_denied_after_no(self, perm, monkeypatch):
        def _deny(self, detail):
            self._asked_this_session = True
            self._session_denied = True
            return "deny"
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._ask_session_approval", _deny
        )
        perm.ask("shell", "npm run build", category="shell")
        # Second call — should not prompt again, just deny
        result = perm.ask("shell", "pip install requests", category="shell")
        assert result == "deny"

    def test_second_shell_command_allowed_after_yes(self, perm, monkeypatch):
        def _allow(self, detail):
            self._asked_this_session = True
            self._session_approved = True
            return "allow"
        monkeypatch.setattr(
            "widdx.permissions.PermissionManager._ask_session_approval", _allow
        )
        perm.ask("shell", "npm run build", category="shell")
        result = perm.ask("shell", "pip install requests", category="shell")
        assert result == "allow"
