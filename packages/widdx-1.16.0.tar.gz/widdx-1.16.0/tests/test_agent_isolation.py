"""Tests for agent context isolation — task 2.4.

Validates: Requirements REQ-3
  1. WHEN AgentFactory creates an agent THEN it gets a new ToolLoop with _messages = [] private to it
  3. WHEN two agents run in parallel THEN neither sees the other's messages
  5. GIVEN an agent fails THEN its failure does not affect other agents' context
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from unittest.mock import MagicMock, patch

import pytest

from widdx.agent_factory.runner import AgentRunner
from widdx.agent_factory.spec import AgentSpec

# ToolLoop is imported inside AgentRunner.run() via `from ..tool_loop import ToolLoop`.
# The correct patch target is the class in its defining module.
_TOOL_LOOP_PATH = "widdx.tool_loop.ToolLoop"


# ── Helpers ────────────────────────────────────────────────────────────────

def _make_spec(role: str = "Test Agent", domain: str = "fullstack") -> AgentSpec:
    return AgentSpec(
        role=role,
        goal="Do something",
        domain=domain,
        constraints=[],
        depends_on=[],
    )


def _make_mock_router() -> MagicMock:
    """Return a router mock that never makes real API calls."""
    router = MagicMock()
    router._estimate_tokens.return_value = 100
    return router


def _make_mock_tool_loop(output: str = "done") -> MagicMock:
    """Return a ToolLoop mock with the minimal attributes AgentRunner.run() reads."""
    loop = MagicMock()
    loop.run.return_value = output
    loop._created_files = []
    loop._edited_files = []
    loop._tool_calls_count = 0
    loop._messages = []
    return loop


# ── REQ-3.1: Each run() creates a fresh ToolLoop with _messages = [] ───────

class TestFreshToolLoopPerRun:
    """Each AgentRunner.run() call must instantiate a brand-new ToolLoop."""

    def test_tool_loop_instantiated_on_every_run(self):
        """run() must call ToolLoop() exactly once per invocation."""
        spec = _make_spec()
        router = _make_mock_router()
        runner = AgentRunner(spec, router)

        mock_loop = _make_mock_tool_loop()

        with patch(_TOOL_LOOP_PATH, return_value=mock_loop) as MockToolLoop:
            runner.run("task A")
            assert MockToolLoop.call_count == 1

    def test_two_sequential_runs_create_two_distinct_tool_loops(self):
        """Two sequential run() calls must produce two separate ToolLoop objects."""
        spec = _make_spec()
        router = _make_mock_router()
        runner = AgentRunner(spec, router)

        loop1 = _make_mock_tool_loop("output 1")
        loop2 = _make_mock_tool_loop("output 2")

        with patch(_TOOL_LOOP_PATH, side_effect=[loop1, loop2]) as MockToolLoop:
            runner.run("task A")
            runner.run("task B")
            assert MockToolLoop.call_count == 2
            # The two loops are different objects
            assert loop1 is not loop2

    def test_fresh_loop_starts_with_empty_messages(self):
        """The ToolLoop created by run() must start with _messages = []."""
        spec = _make_spec()
        router = _make_mock_router()
        runner = AgentRunner(spec, router)

        captured_loops: list[MagicMock] = []

        def capture_loop(*args, **kwargs):
            loop = _make_mock_tool_loop()
            captured_loops.append(loop)
            return loop

        with patch(_TOOL_LOOP_PATH, side_effect=capture_loop):
            runner.run("task A")

        assert len(captured_loops) == 1
        # _messages starts empty — isolation guarantee
        assert captured_loops[0]._messages == []


# ── REQ-3.3: Two parallel agents do not share _messages ────────────────────

class TestParallelAgentIsolation:
    """Two AgentRunner instances running concurrently must not share _messages."""

    def test_parallel_runs_create_independent_tool_loops(self):
        """Concurrent run() calls must each get their own ToolLoop instance."""
        spec_a = _make_spec("Agent A")
        spec_b = _make_spec("Agent B")
        router = _make_mock_router()

        runner_a = AgentRunner(spec_a, router)
        runner_b = AgentRunner(spec_b, router)

        created_loops: list[MagicMock] = []

        def capture_loop(*args, **kwargs):
            loop = _make_mock_tool_loop()
            created_loops.append(loop)
            return loop

        with patch(_TOOL_LOOP_PATH, side_effect=capture_loop):
            with ThreadPoolExecutor(max_workers=2) as pool:
                fut_a = pool.submit(runner_a.run, "task")
                fut_b = pool.submit(runner_b.run, "task")
                fut_a.result()
                fut_b.result()

        assert len(created_loops) == 2
        # Each run got a distinct ToolLoop object
        assert created_loops[0] is not created_loops[1]

    def test_messages_added_to_one_loop_do_not_appear_in_other(self):
        """Messages appended inside one ToolLoop must not leak into the other."""
        spec_a = _make_spec("Agent A")
        spec_b = _make_spec("Agent B")
        router = _make_mock_router()

        runner_a = AgentRunner(spec_a, router)
        runner_b = AgentRunner(spec_b, router)

        loop_a = _make_mock_tool_loop("output A")
        loop_b = _make_mock_tool_loop("output B")

        # Simulate Agent A accumulating messages during its run
        loop_a._messages = [{"role": "user", "content": "secret from A"}]

        loops = iter([loop_a, loop_b])

        with patch(_TOOL_LOOP_PATH, side_effect=lambda *a, **kw: next(loops)):
            with ThreadPoolExecutor(max_workers=2) as pool:
                fut_a = pool.submit(runner_a.run, "task")
                fut_b = pool.submit(runner_b.run, "task")
                fut_a.result()
                fut_b.result()

        # Agent B's loop must not contain Agent A's messages
        b_contents = [m.get("content", "") for m in loop_b._messages]
        assert "secret from A" not in b_contents

    def test_parallel_runs_return_independent_outputs(self):
        """Each parallel run() must return its own output, not the other's."""
        spec_a = _make_spec("Agent A")
        spec_b = _make_spec("Agent B")
        router = _make_mock_router()

        runner_a = AgentRunner(spec_a, router)
        runner_b = AgentRunner(spec_b, router)

        loop_a = _make_mock_tool_loop("output from A")
        loop_b = _make_mock_tool_loop("output from B")

        loops = iter([loop_a, loop_b])

        with patch(_TOOL_LOOP_PATH, side_effect=lambda *a, **kw: next(loops)):
            with ThreadPoolExecutor(max_workers=2) as pool:
                fut_a = pool.submit(runner_a.run, "task")
                fut_b = pool.submit(runner_b.run, "task")
                result_a = fut_a.result()
                result_b = fut_b.result()

        assert result_a["output"] == "output from A"
        assert result_b["output"] == "output from B"
        assert result_a["output"] != result_b["output"]


# ── REQ-3.5: A failed agent does not pollute other agents' context ──────────

class TestFailedAgentIsolation:
    """A failing agent must not corrupt the context of other agents."""

    def test_exception_in_one_agent_does_not_affect_other(self):
        """If one run() raises, the other run() still completes with clean state."""
        spec_a = _make_spec("Failing Agent")
        spec_b = _make_spec("Healthy Agent")
        router = _make_mock_router()

        runner_a = AgentRunner(spec_a, router)
        runner_b = AgentRunner(spec_b, router)

        failing_loop = MagicMock()
        failing_loop.run.side_effect = RuntimeError("API timeout")
        failing_loop._created_files = []
        failing_loop._edited_files = []
        failing_loop._tool_calls_count = 0
        failing_loop._messages = []

        healthy_loop = _make_mock_tool_loop("healthy output")

        loops = iter([failing_loop, healthy_loop])

        with patch(_TOOL_LOOP_PATH, side_effect=lambda *a, **kw: next(loops)):
            with pytest.raises(RuntimeError):
                runner_a.run("task")

            # Healthy agent runs independently — no contamination
            result_b = runner_b.run("task")

        assert result_b["output"] == "healthy output"
        # Healthy loop's messages are untouched by the failure
        assert healthy_loop._messages == []

    def test_failed_agent_loop_messages_do_not_bleed_into_new_run(self):
        """A new run() always gets a fresh ToolLoop regardless of prior failures."""
        spec = _make_spec()
        router = _make_mock_router()
        runner = AgentRunner(spec, router)

        failing_loop = MagicMock()
        failing_loop.run.side_effect = RuntimeError("crash")
        failing_loop._messages = [{"role": "user", "content": "polluted message"}]
        failing_loop._created_files = []
        failing_loop._edited_files = []
        failing_loop._tool_calls_count = 0

        fresh_loop = _make_mock_tool_loop("clean output")

        loops = iter([failing_loop, fresh_loop])

        with patch(_TOOL_LOOP_PATH, side_effect=lambda *a, **kw: next(loops)):
            with pytest.raises(RuntimeError):
                runner.run("task 1")

            # Second run gets a brand-new loop — no leftover messages
            result = runner.run("task 2")

        assert result["output"] == "clean output"
        assert fresh_loop._messages == []


# ── _build_isolated_context() unit tests ───────────────────────────────────

class TestBuildIsolatedContext:
    """Unit tests for AgentRunner._build_isolated_context()."""

    def _runner(self) -> AgentRunner:
        return AgentRunner(_make_spec(), _make_mock_router())

    def test_returns_empty_string_for_none(self):
        """None prior_outputs → empty string (no context injected)."""
        runner = self._runner()
        assert runner._build_isolated_context(None) == ""

    def test_returns_empty_string_for_empty_dict(self):
        """Empty dict prior_outputs → empty string."""
        runner = self._runner()
        assert runner._build_isolated_context({}) == ""

    def test_regular_output_included_in_context(self):
        """A regular role output must appear in the context block."""
        runner = self._runner()
        ctx = runner._build_isolated_context({"Backend": "Built the API"})
        assert "Backend" in ctx
        assert "Built the API" in ctx

    def test_handoff_block_separated_from_regular_output(self):
        """Handoff keys (prefixed __handoff__) must be rendered separately."""
        runner = self._runner()
        ctx = runner._build_isolated_context({
            "Backend": "raw output",
            "__handoff__Backend": "[Backend → Frontend]\nSummary: Built API",
        })
        # Handoff content must appear
        assert "Built API" in ctx
        # Raw output for a role already covered by a handoff must NOT appear
        # (runner deduplicates: handoff takes priority over raw output)
        assert "raw output" not in ctx

    def test_raw_output_included_when_no_handoff_for_role(self):
        """Raw output for a role with no corresponding handoff must be included."""
        runner = self._runner()
        ctx = runner._build_isolated_context({"QA": "All tests pass"})
        assert "All tests pass" in ctx

    def test_context_capped_at_max_chars(self):
        """Output must be capped at _MAX_CONTEXT_CHARS to avoid token waste."""
        from widdx.agent_factory.runner import _MAX_CONTEXT_CHARS
        runner = self._runner()
        huge_output = "x" * 100_000
        ctx = runner._build_isolated_context({"Backend": huge_output})
        assert len(ctx) <= _MAX_CONTEXT_CHARS + len("\n… (truncated)")

    def test_long_raw_output_truncated_at_500_chars(self):
        """Individual raw outputs are truncated at 500 chars before the global cap."""
        runner = self._runner()
        long_output = "A" * 10_000
        ctx = runner._build_isolated_context({"Backend": long_output})
        # The raw output section should not contain more than 500 A's
        a_count = ctx.count("A")
        assert a_count <= 500
