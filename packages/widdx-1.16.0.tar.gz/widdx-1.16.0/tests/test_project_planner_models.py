"""Tests for widdx.project_planner.models — Phase & ProjectPlan dataclasses."""
from __future__ import annotations

from widdx.project_planner.models import Phase, ProjectPlan


class TestPhase:
    """Phase dataclass — serialization and defaults."""

    def test_defaults(self):
        p = Phase(id="ph1", number=1, title="Setup", goal="Init project", deliverables=["README.md"])
        assert p.status == "pending"
        assert p.depends_on == []
        assert p.files_created == []
        assert p.files_edited == []
        assert p.decisions == []
        assert p.output_summary == ""

    def test_to_dict_returns_copy(self):
        p = Phase(id="ph1", number=1, title="Setup", goal="Init", deliverables=["a"])
        d = p.to_dict()
        d["status"] = "done"
        assert p.status == "pending"

    def test_from_dict_roundtrip(self):
        original = Phase(
            id="ph2", number=2, title="API", goal="Build API",
            deliverables=["routes.py"], depends_on=["ph1"],
            status="running", decisions=["use-fastapi"],
        )
        restored = Phase.from_dict(original.to_dict())
        assert restored.id == original.id
        assert restored.number == original.number
        assert restored.title == original.title
        assert restored.goal == original.goal
        assert restored.deliverables == original.deliverables
        assert restored.depends_on == original.depends_on
        assert restored.status == original.status
        assert restored.decisions == original.decisions


class TestProjectPlan:
    """ProjectPlan dataclass — serialization and computed properties."""

    def _make_phases(self) -> list[Phase]:
        return [
            Phase(id="ph1", number=1, title="Setup", goal="Init", deliverables=["README.md"], status="done"),
            Phase(id="ph2", number=2, title="Core", goal="Build", deliverables=["core.py"], depends_on=["ph1"], status="pending"),
            Phase(id="ph3", number=3, title="Deploy", goal="Ship", deliverables=["ci.yml"], depends_on=["ph2"], status="pending"),
        ]

    def test_to_dict_includes_phases(self):
        plan = ProjectPlan(id="plan1", task="Build API", phases=self._make_phases())
        d = plan.to_dict()
        assert len(d["phases"]) == 3
        assert d["phases"][0]["id"] == "ph1"

    def test_from_dict_roundtrip(self):
        plan = ProjectPlan(id="plan1", task="Build API", phases=self._make_phases(), tech_stack=["python"], status="running")
        restored = ProjectPlan.from_dict(plan.to_dict())
        assert restored.id == plan.id
        assert restored.task == plan.task
        assert len(restored.phases) == 3
        assert restored.phases[0].id == "ph1"
        assert restored.phases[1].depends_on == ["ph1"]
        assert restored.tech_stack == ["python"]
        assert restored.status == "running"

    def test_from_dict_empty_phases(self):
        plan = ProjectPlan.from_dict({"id": "p1", "task": "T", "phases": []})
        assert plan.phases == []

    def test_completed_phases(self):
        plan = ProjectPlan(id="plan1", task="T", phases=self._make_phases())
        assert len(plan.completed_phases) == 1
        assert plan.completed_phases[0].id == "ph1"

    def test_pending_phases(self):
        plan = ProjectPlan(id="plan1", task="T", phases=self._make_phases())
        assert len(plan.pending_phases) == 2
        assert {p.id for p in plan.pending_phases} == {"ph2", "ph3"}

    def test_next_phase_returns_first_ready(self):
        plan = ProjectPlan(id="plan1", task="T", phases=self._make_phases())
        nxt = plan.next_phase
        assert nxt is not None
        assert nxt.id == "ph2"

    def test_next_phase_skips_blocked(self):
        ph1 = Phase(id="ph1", number=1, title="A", goal="G", deliverables=[], status="pending")
        ph2 = Phase(id="ph2", number=2, title="B", goal="G", deliverables=[], depends_on=["ph1"], status="pending")
        plan = ProjectPlan(id="p1", task="T", phases=[ph1, ph2])
        nxt = plan.next_phase
        assert nxt is not None
        assert nxt.id == "ph1"

    def test_next_phase_returns_none_when_all_done(self):
        ph1 = Phase(id="ph1", number=1, title="A", goal="G", deliverables=[], status="done")
        plan = ProjectPlan(id="p1", task="T", phases=[ph1])
        assert plan.next_phase is None

    def test_next_phase_returns_none_when_all_blocked(self):
        ph1 = Phase(id="ph1", number=1, title="A", goal="G", deliverables=[], depends_on=["ph2"], status="pending")
        ph2 = Phase(id="ph2", number=2, title="B", goal="G", deliverables=[], depends_on=["ph1"], status="pending")
        plan = ProjectPlan(id="p1", task="T", phases=[ph1, ph2])
        assert plan.next_phase is None

    def test_progress_pct_empty(self):
        plan = ProjectPlan(id="p1", task="T", phases=[])
        assert plan.progress_pct() == 0

    def test_progress_pct_full(self):
        ph1 = Phase(id="ph1", number=1, title="A", goal="G", deliverables=[], status="done")
        ph2 = Phase(id="ph2", number=2, title="B", goal="G", deliverables=[], status="done")
        plan = ProjectPlan(id="p1", task="T", phases=[ph1, ph2])
        assert plan.progress_pct() == 100

    def test_progress_pct_partial(self):
        ph1 = Phase(id="ph1", number=1, title="A", goal="G", deliverables=[], status="done")
        ph2 = Phase(id="ph2", number=2, title="B", goal="G", deliverables=[], status="pending")
        ph3 = Phase(id="ph3", number=3, title="C", goal="G", deliverables=[], status="pending")
        plan = ProjectPlan(id="p1", task="T", phases=[ph1, ph2, ph3])
        assert plan.progress_pct() == 33

    def test_defaults(self):
        plan = ProjectPlan(id="p1", task="T", phases=[])
        assert plan.tech_stack == []
        assert plan.architecture_notes == ""
        assert plan.created_at == ""
        assert plan.status == "pending"
