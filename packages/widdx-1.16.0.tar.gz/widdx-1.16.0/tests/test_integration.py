"""Integration tests for WIDDX CLI — end-to-end flows with mocked LLM.

Validates:
  - Pipeline processes a task through planning and execution
  - AgentFactory generates and runs multi-agent teams
  - Hooks can block tool execution via PreToolUse prompt hooks
  - MCP tools and built-in tools coexist in the tool list
  - PromptHandler evaluates prompts via LLM (mocked)
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from widdx.agent_factory.spec import AgentSpec
from widdx.hooks.events import HookEvent
from widdx.hooks.handlers import HookResult, PromptHandler
from widdx.hooks import HookManager


# ── Helpers ──────────────────────────────────────────────────────────────────


def _mock_router(**kwargs):
    """Build a MagicMock router that never makes real API calls."""
    router = MagicMock()
    router._estimate_tokens.return_value = kwargs.get("estimate_tokens", 100)
    router.call_executor.return_value = kwargs.get(
        "call_executor", {"text": "ALLOW", "usage": {}, "role": "executor"}
    )
    router.call_architect.return_value = kwargs.get(
        "call_architect", {"text": "[]", "usage": {}, "role": "architect"}
    )
    router.call_with_tools_streaming.return_value = kwargs.get(
        "streaming", [{"type": "done", "usage": {}}]
    )
    router.PRICING = kwargs.get("pricing", {})
    router._config = kwargs.get("config", {"models": {}, "memory": {}})
    router._executor_model = kwargs.get("executor_model", "test-model")
    return router


def _mock_memory():
    """Build a MagicMock memory that satisfies the AgentFactory interface."""
    memory = MagicMock()
    memory.log_agent_run.return_value = None
    return memory


# ── Integration: Pipeline + ToolLoop ─────────────────────────────────────────


class TestPipelineIntegration:
    """ExecutionPipeline processes tasks through plan → execute → review."""

    def test_pipeline_run_returns_result(self):
        """ExecutionPipeline.run() returns a PipelineResult for simple tasks."""
        from widdx.pipeline import ExecutionPipeline

        router = _mock_router(
            call_executor={"text": "simple task output", "usage": {}},
        )
        agent_factory = MagicMock()
        memory = _mock_memory()
        memory.create_task.return_value = None
        memory.log_decision.return_value = None
        evolution = MagicMock()

        with patch("widdx.mcp.MCPRegistry.load"), \
             patch("widdx.hooks.HookManager.load"):
            pipeline = ExecutionPipeline(router, agent_factory, memory, evolution)

        result = pipeline.run("fix a bug in login")
        assert result is not None
        assert hasattr(result, "task_id")

    def test_extract_json_standalone(self):
        """_extract_json handles markdown fences, bare JSON, and nested objects."""
        from widdx.pipeline import _extract_json

        assert '"key"' in _extract_json('```json\n{"key": "value"}\n```')
        assert '"key"' in _extract_json('{"key": "value"}')
        result = _extract_json('prefix {"nested": {"a": 1}} suffix')
        assert '"nested"' in result
        assert '"a"' in result


# ── Integration: AgentFactory + Runner ───────────────────────────────────────


class TestAgentFactoryIntegration:
    """AgentFactory generates teams and runs them concurrently."""

    def test_fallback_team_when_llm_fails(self):
        """AgentFactory returns a single fullstack agent when architect call fails."""
        from widdx.agent_factory import AgentFactory

        router = _mock_router(call_architect={"error": "timeout", "text": ""})
        factory = AgentFactory(router)

        team = factory.generate_team("Build a login page", complexity=3)
        assert len(team) == 1
        assert team[0].domain == "fullstack"

    def test_single_agent_execution(self):
        """execute_team runs a single agent and returns its output."""
        from widdx.agent_factory import AgentFactory

        router = _mock_router()
        factory = AgentFactory(router)
        memory = _mock_memory()

        spec = AgentSpec(
            role="Test Agent", goal="Write a test", domain="fullstack",
            constraints=[], depends_on=[],
        )

        with patch("widdx.agent_factory.runner.AgentRunner.run") as mock_run:
            mock_run.return_value = {
                "role": "Test Agent",
                "output": "Test passed",
                "created_files": ["test.py"],
                "tool_calls": 2,
                "handoff": None,
                "latency_ms": 100,
            }
            result = factory.execute_team(
                [spec], "Write a test", task_id="t-1", memory=memory,
            )

        assert "Test Agent" in result
        assert "test.py" in result

    def test_multi_agent_dependency_order(self):
        """Agents with dependencies run in correct order."""
        from widdx.agent_factory import AgentFactory

        router = _mock_router()
        factory = AgentFactory(router)
        memory = _mock_memory()

        backend = AgentSpec(
            role="Backend", goal="Build API", domain="backend",
            constraints=[], depends_on=[],
        )
        frontend = AgentSpec(
            role="Frontend", goal="Build UI", domain="frontend",
            constraints=[], depends_on=["Backend"],
        )

        call_order = []

        def run_side_effect(task, prior_outputs=None):
            # Determine which agent this is from the call context
            return {
                "role": "Backend", "output": "Backend done",
                "created_files": [], "tool_calls": 1, "handoff": None,
                "latency_ms": 50,
            }

        with patch("widdx.agent_factory.runner.AgentRunner.run") as mock_run:
            mock_run.side_effect = run_side_effect
            factory.execute_team(
                [backend, frontend], "Build app", task_id="t-2", memory=memory,
            )

        # Single agent case — Backend runs with handoff to Frontend
        assert mock_run.call_count == 2

    def test_circular_dependency_guard(self):
        """Circular dependencies are detected and broken gracefully."""
        from widdx.agent_factory import AgentFactory

        router = _mock_router()
        factory = AgentFactory(router)
        memory = _mock_memory()

        a = AgentSpec(role="A", goal="Task A", domain="backend", constraints=[], depends_on=["B"])
        b = AgentSpec(role="B", goal="Task B", domain="backend", constraints=[], depends_on=["A"])

        with patch("widdx.agent_factory.runner.AgentRunner.run") as mock_run:
            mock_run.return_value = {
                "role": "A", "output": "done", "created_files": [],
                "tool_calls": 1, "handoff": None, "latency_ms": 30,
            }
            result = factory.execute_team(
                [a, b], "Circular test", task_id="t-3", memory=memory,
            )

        assert mock_run.called
        assert result is not None


# ── Integration: Hooks + Tool Execution ──────────────────────────────────────


class TestHooksIntegration:
    """Hooks integrate with ToolLoop to guard tool execution."""

    def test_pre_tool_use_blocking(self):
        """PreToolUse prompt hook returning DENY blocks tool execution."""
        hook_manager = HookManager()
        hook_manager._hooks[HookEvent.PRE_TOOL_USE.value] = [
            {"matcher": "Bash", "type": "prompt", "prompt": "Is this safe?"}
        ]

        with patch.object(PromptHandler, "run") as mock_run:
            mock_run.return_value = HookResult(
                event="PreToolUse", hook_type="prompt",
                success=True, output="Is this safe?", blocked=True,
            )
            results = hook_manager.fire("PreToolUse", {"tool": "Bash", "args": "rm -rf /"})

        assert len(results) == 1
        assert results[0].blocked is True

    def test_pre_tool_use_allows_safe_commands(self):
        """PreToolUse prompt hook returning ALLOW permits tool execution."""
        hook_manager = HookManager()
        hook_manager._hooks[HookEvent.PRE_TOOL_USE.value] = [
            {"matcher": "Bash", "type": "prompt", "prompt": "Check command safety."}
        ]

        with patch.object(PromptHandler, "run") as mock_run:
            mock_run.return_value = HookResult(
                event="PreToolUse", hook_type="prompt",
                success=True, output="Check command safety.", blocked=False,
            )
            results = hook_manager.fire("PreToolUse", {"tool": "Bash", "args": "git status"})

        assert len(results) == 1
        assert results[0].blocked is False

    def test_matcher_filtering(self):
        """Only hooks whose matcher regex matches the tool name are fired."""
        hook_manager = HookManager()
        hook_manager._hooks[HookEvent.PRE_TOOL_USE.value] = [
            {"matcher": "Write|Edit", "type": "prompt", "prompt": "Check file write."},
            {"matcher": "Bash", "type": "prompt", "prompt": "Check command."},
        ]

        with patch.object(PromptHandler, "run") as mock_run:
            mock_run.return_value = HookResult(
                event="PreToolUse", hook_type="prompt",
                success=True, output="ok", blocked=False,
            )
            results = hook_manager.fire("PreToolUse", {"tool": "Read", "args": "{}"})

        assert len(results) == 0

    def test_prompt_handler_with_mocked_router(self):
        """PromptHandler calls the router when one is provided."""
        router = _mock_router(
            call_executor={"text": "ALLOW", "usage": {}, "role": "executor"}
        )
        handler = PromptHandler(router=router)
        hook = {"prompt": "Is $tool safe?"}

        result = handler.run("PreToolUse", hook, {"tool": "Bash", "args": "ls"})

        assert result.success is True
        assert result.blocked is False
        router.call_executor.assert_called_once()

    def test_prompt_handler_denies_when_llm_says_deny(self):
        """PromptHandler blocks when the router response starts with DENY."""
        router = _mock_router(
            call_executor={"text": "DENY — destructive command", "usage": {}}
        )
        handler = PromptHandler(router=router)
        hook = {"prompt": "Check $tool safety."}

        result = handler.run("PreToolUse", hook, {"tool": "Bash", "args": "rm -rf /"})

        assert result.blocked is True

    def test_prompt_handler_fallback_without_router(self):
        """PromptHandler falls back to _prompt_response when no router is set."""
        handler = PromptHandler()
        hook = {"prompt": "Check safety."}

        result = handler.run("PreToolUse", hook, {"_prompt_response": "DENY"})
        assert result.blocked is True

        result = handler.run("PreToolUse", hook, {"_prompt_response": "ALLOW"})
        assert result.blocked is False

    def test_prompt_handler_defaults_to_deny_on_llm_error(self):
        """PromptHandler blocks when the LLM call raises an exception."""
        router = _mock_router()
        router.call_executor.side_effect = RuntimeError("API down")
        handler = PromptHandler(router=router)
        hook = {"prompt": "Check $tool safety."}

        result = handler.run("PreToolUse", hook, {"tool": "Bash", "args": "ls"})

        assert result.success is False
        assert result.blocked is True

    def test_context_interpolation(self):
        """PromptHandler replaces $KEY and ${KEY} placeholders with context values."""
        handler = PromptHandler()
        result = handler._interpolate("Tool: $tool, Args: ${args}", {"tool": "Bash", "args": "ls"})
        assert result == "Tool: Bash, Args: ls"


# ── Integration: MCP + Built-in tools ────────────────────────────────────────


class TestMCPBuiltinIntegration:
    """Built-in MCP servers coexist with external servers."""

    def test_builtin_servers_always_loaded(self, tmp_path):
        """Built-in servers load even with no mcp.json present."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path=str(tmp_path / "no-config.json"))
        reg.load()

        assert "project-info" in reg._servers
        assert "utility" in reg._servers
        assert len(reg._tools) == 6

    def test_builtin_tool_execution(self, tmp_path):
        """Built-in tools execute and return results."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path=str(tmp_path / "no-config.json"))
        reg.load()

        result = reg.execute("mcp__utility__generate_uuid", {})
        assert "content" in result
        content = json.loads(result["content"][0]["text"])
        assert "uuid" in content
        assert len(content["uuid"]) == 32

    def test_builtin_project_stats(self, tmp_path):
        """project_stats returns info about the current project."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path=str(tmp_path / "no-config.json"))
        reg.load()

        result = reg.execute("mcp__project-info__project_stats", {})
        assert "content" in result
        data = json.loads(result["content"][0]["text"])
        assert "root" in data
        assert "total_files" in data
        assert "languages" in data

    def test_builtin_tools_namespaced_correctly(self):
        """All built-in tools use the mcp__<server>__<tool> naming convention."""
        from widdx.mcp import MCPRegistry

        reg = MCPRegistry(config_path="~/.widdx/mcp.json")
        reg.load()

        for tool in reg.tool_definitions():
            assert tool["name"].startswith("mcp__")
            parts = tool["name"].split("__")
            assert len(parts) == 3
            assert parts[0] == "mcp"
            assert parts[1] in ("project-info", "utility")


# ── Integration: Skill + ToolLoop ────────────────────────────────────────────


class TestSkillIntegration:
    """Skills load and augment the tool loop."""

    def test_skill_manager_loads_defaults(self):
        """SkillManager loads skill files without error."""
        from widdx.skills import SkillManager

        manager = SkillManager()
        manager.load()
        commands = manager.list_skills()
        assert isinstance(commands, list)

    def test_skill_manager_in_tool_loop(self):
        """ToolLoop initializes with a SkillManager."""
        from widdx.tool_loop import ToolLoop

        router = _mock_router()
        with patch("widdx.mcp.MCPRegistry.load"), \
             patch("widdx.hooks.HookManager.load"):
            loop = ToolLoop(router, max_steps=1)

        assert loop._skill_manager is not None
        assert isinstance(loop._skill_manager.list_skills(), list)
