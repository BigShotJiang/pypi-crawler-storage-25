"""Tests for widdx.config — configuration loading and saving."""
from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import mock_open, patch

import pytest

from widdx.config import (
    DEFAULT_CONFIG,
    DEFAULT_MEMORY_DB_PATH,
    USER_CONFIG,
    _deep_merge,
    load_config,
    save_config_key,
    save_user_config,
)


class TestDeepMerge:
    """_deep_merge merges overlay dict into base in-place."""

    def test_scalar_overwrites(self):
        base = {"a": 1}
        _deep_merge(base, {"a": 2})
        assert base["a"] == 2

    def test_new_key_added(self):
        base = {"a": 1}
        _deep_merge(base, {"b": 2})
        assert base == {"a": 1, "b": 2}

    def test_nested_dict_merged(self):
        base = {"a": {"x": 1, "y": 2}}
        _deep_merge(base, {"a": {"y": 3, "z": 4}})
        assert base["a"] == {"x": 1, "y": 3, "z": 4}

    def test_nested_scalar_overwrites_dict(self):
        base = {"a": {"x": 1}}
        _deep_merge(base, {"a": "replaced"})
        assert base["a"] == "replaced"

    def test_deeply_nested(self):
        base = {"a": {"b": {"c": 1}}}
        _deep_merge(base, {"a": {"b": {"d": 2}}})
        assert base["a"]["b"] == {"c": 1, "d": 2}

    def test_empty_overlay(self):
        base = {"a": 1}
        _deep_merge(base, {})
        assert base == {"a": 1}


class TestLoadConfig:
    """load_config merges default + user configs and injects env vars."""

    def test_default_only(self, tmp_path: Path):
        import yaml
        default_cfg = tmp_path / "default.yaml"
        default_cfg.write_text(yaml.dump({"providers": {"deepseek": True}}), encoding="utf-8")
        user_cfg = tmp_path / "user.yaml"
        with patch("widdx.config.DEFAULT_CONFIG", default_cfg), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {}, clear=True):
            config = load_config()
            assert config.get("providers", {}).get("deepseek") is True

    def test_user_overrides_default(self, tmp_path: Path):
        import yaml
        default_cfg = tmp_path / "default.yaml"
        default_cfg.write_text(yaml.dump({"a": 1, "b": 2}), encoding="utf-8")
        user_cfg = tmp_path / "user.yaml"
        user_cfg.write_text(yaml.dump({"b": 3}), encoding="utf-8")
        with patch("widdx.config.DEFAULT_CONFIG", default_cfg), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {}, clear=True):
            config = load_config()
            assert config["a"] == 1
            assert config["b"] == 3

    def test_env_key_injected(self, tmp_path: Path):
        import yaml
        default_cfg = tmp_path / "default.yaml"
        default_cfg.write_text(yaml.dump({"providers": {}}), encoding="utf-8")
        user_cfg = tmp_path / "user.yaml"
        with patch("widdx.config.DEFAULT_CONFIG", default_cfg), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {"DEEPSEEK_API_KEY": "sk-test123"}, clear=False):
            config = load_config()
            assert config["__env__"]["deepseek_key"] == "sk-test123"

    def test_env_key_falls_back_to_config(self, tmp_path: Path):
        import yaml
        default_cfg = tmp_path / "default.yaml"
        default_cfg.write_text(yaml.dump({"deepseek_api_key": "sk-from-config"}), encoding="utf-8")
        user_cfg = tmp_path / "user.yaml"
        with patch("widdx.config.DEFAULT_CONFIG", default_cfg), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {}, clear=True):
            config = load_config()
            assert config["__env__"]["deepseek_key"] == "sk-from-config"

    def test_env_wins_over_config_key(self, tmp_path: Path):
        import yaml
        default_cfg = tmp_path / "default.yaml"
        default_cfg.write_text(yaml.dump({"deepseek_api_key": "sk-from-config"}), encoding="utf-8")
        user_cfg = tmp_path / "user.yaml"
        with patch("widdx.config.DEFAULT_CONFIG", default_cfg), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {"DEEPSEEK_API_KEY": "sk-from-env"}, clear=False):
            config = load_config()
            assert config["__env__"]["deepseek_key"] == "sk-from-env"

    def test_default_config_missing(self, tmp_path: Path):
        missing = tmp_path / "nonexistent.yaml"
        user_cfg = tmp_path / "user.yaml"
        with patch("widdx.config.DEFAULT_CONFIG", missing), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {}, clear=True):
            config = load_config()
            assert config["__env__"]["deepseek_key"] is None

    def test_default_config_empty(self, tmp_path: Path):
        default_cfg = tmp_path / "default.yaml"
        default_cfg.write_text("", encoding="utf-8")
        user_cfg = tmp_path / "user.yaml"
        with patch("widdx.config.DEFAULT_CONFIG", default_cfg), \
             patch("widdx.config.USER_CONFIG", user_cfg), \
             patch.dict(os.environ, {}, clear=True):
            config = load_config()
            assert isinstance(config, dict)


class TestSaveConfigKey:
    """save_config_key persists a single key to user config."""

    def test_writes_new_key(self, tmp_path: Path):
        with patch("widdx.config.USER_CONFIG", tmp_path / "config.yaml"):
            save_config_key("theme", "dark")
            import yaml
            data = yaml.safe_load((tmp_path / "config.yaml").read_text(encoding="utf-8"))
            assert data["theme"] == "dark"

    def test_preserves_existing_keys(self, tmp_path: Path):
        import yaml
        cfg = tmp_path / "config.yaml"
        cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(yaml.dump({"existing": "value"}), encoding="utf-8")
        with patch("widdx.config.USER_CONFIG", cfg):
            save_config_key("new_key", "new_value")
            data = yaml.safe_load(cfg.read_text(encoding="utf-8"))
            assert data["existing"] == "value"
            assert data["new_key"] == "new_value"

    def test_overwrites_existing_key(self, tmp_path: Path):
        import yaml
        cfg = tmp_path / "config.yaml"
        cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(yaml.dump({"key": "old"}), encoding="utf-8")
        with patch("widdx.config.USER_CONFIG", cfg):
            save_config_key("key", "new")
            data = yaml.safe_load(cfg.read_text(encoding="utf-8"))
            assert data["key"] == "new"


class TestSaveUserConfig:
    """save_user_config overwrites the full user config file."""

    def test_writes_full_config(self, tmp_path: Path):
        with patch("widdx.config.USER_CONFIG", tmp_path / "config.yaml"):
            save_user_config({"a": 1, "b": 2})
            import yaml
            data = yaml.safe_load((tmp_path / "config.yaml").read_text(encoding="utf-8"))
            assert data == {"a": 1, "b": 2}

    def test_overwrites_existing(self, tmp_path: Path):
        import yaml
        cfg = tmp_path / "config.yaml"
        cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(yaml.dump({"old": "config"}), encoding="utf-8")
        with patch("widdx.config.USER_CONFIG", cfg):
            save_user_config({"new": "config"})
            data = yaml.safe_load(cfg.read_text(encoding="utf-8"))
            assert "old" not in data
            assert data == {"new": "config"}
