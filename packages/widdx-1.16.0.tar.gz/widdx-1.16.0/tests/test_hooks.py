"""
tests/test_hooks.py — Tests for HookManager (GAP-2, task 4.1)
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from widdx.hooks import HookManager, HookResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def manager() -> HookManager:
    return HookManager()


@pytest.fixture()
def hooks_file(tmp_path: Path) -> Path:
    """Write a minimal hooks.json and return its path."""
    data = {
        "hooks": {
            "PostToolUse": [
                {
                    "matcher": "Write|Edit",
                    "type": "command",
                    "command": "echo post_tool_use_ran",
                    "async": False,
                }
            ],
            "PreToolUse": [
                {
                    "matcher": "Bash",
                    "type": "prompt",
                    "prompt": "Is this command safe? Reply ALLOW or DENY only.",
                }
            ],
            "SessionStart": [
                {
                    "type": "command",
                    "command": "echo session_started",
                }
            ],
        }
    }
    p = tmp_path / "hooks.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


class TestLoad:
    def test_load_from_explicit_path(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        hooks = manager.all_hooks()
        assert "PostToolUse" in hooks
        assert "PreToolUse" in hooks
        assert "SessionStart" in hooks

    def test_load_missing_file_is_silent(self, manager: HookManager, tmp_path: Path) -> None:
        manager.load(paths=[str(tmp_path / "nonexistent.json")])
        assert manager.all_hooks() == {}

    def test_load_invalid_json_is_silent(self, manager: HookManager, tmp_path: Path) -> None:
        bad = tmp_path / "hooks.json"
        bad.write_text("not json", encoding="utf-8")
        manager.load(paths=[str(bad)])
        assert manager.all_hooks() == {}

    def test_load_merges_multiple_files(self, manager: HookManager, tmp_path: Path) -> None:
        file_a = tmp_path / "a.json"
        file_b = tmp_path / "b.json"
        file_a.write_text(
            json.dumps({"hooks": {"SessionStart": [{"type": "command", "command": "echo a"}]}}),
            encoding="utf-8",
        )
        file_b.write_text(
            json.dumps({"hooks": {"SessionStart": [{"type": "command", "command": "echo b"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(file_a), str(file_b)])
        assert len(manager.all_hooks()["SessionStart"]) == 2

    def test_load_resets_previous_hooks(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        manager.load(paths=[])  # reload with no files
        assert manager.all_hooks() == {}

    def test_load_no_paths_uses_defaults(self, manager: HookManager) -> None:
        # Should not raise even when default paths don't exist
        manager.load()
        assert isinstance(manager.all_hooks(), dict)


# ---------------------------------------------------------------------------
# fire() — matcher filtering
# ---------------------------------------------------------------------------


class TestFireMatcher:
    def test_matcher_matches_tool(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PostToolUse", {"tool": "Write"})
        assert len(results) == 1

    def test_matcher_skips_non_matching_tool(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PostToolUse", {"tool": "Read"})
        assert results == []

    def test_no_matcher_always_fires(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("SessionStart", {})
        assert len(results) == 1

    def test_matcher_regex_pipe(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        # "Write|Edit" should match "Edit" too
        results = manager.fire("PostToolUse", {"tool": "Edit"})
        assert len(results) == 1

    def test_unknown_event_returns_empty(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("UnknownEvent", {})
        assert results == []


# ---------------------------------------------------------------------------
# fire() — command hooks
# ---------------------------------------------------------------------------


class TestCommandHook:
    def test_command_hook_returns_hook_result(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({"hooks": {"SessionStart": [{"type": "command", "command": "echo hello"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("SessionStart", {})
        assert len(results) == 1
        r = results[0]
        assert isinstance(r, HookResult)
        assert r.hook_type == "command"
        assert r.event == "SessionStart"

    def test_successful_command_sets_success_true(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({"hooks": {"E": [{"type": "command", "command": "echo ok"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        assert results[0].success is True

    def test_failing_command_sets_success_false(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({"hooks": {"E": [{"type": "command", "command": "exit 1"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        assert results[0].success is False

    def test_command_output_captured(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({"hooks": {"E": [{"type": "command", "command": "echo captured_output"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        assert "captured_output" in results[0].output

    def test_command_env_injection(self, manager: HookManager, tmp_path: Path) -> None:
        """Verify context values are injected as WIDDX_* env vars.

        Uses a Python one-liner so the test is cross-platform (Windows cmd
        does not expand $VAR syntax).
        """
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": "python -c \"import os; print(os.environ.get('WIDDX_TOOL', ''))\"",
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {"tool": "MyTool"})
        assert "MyTool" in results[0].output

    def test_missing_command_field_returns_failure(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({"hooks": {"E": [{"type": "command"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        assert results[0].success is False


# ---------------------------------------------------------------------------
# fire() — prompt hooks
# ---------------------------------------------------------------------------


class TestPromptHook:
    def test_prompt_hook_returns_hook_result(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PreToolUse", {"tool": "Bash"})
        assert len(results) == 1
        r = results[0]
        assert r.hook_type == "prompt"
        assert r.success is True

    def test_prompt_hook_output_contains_prompt_text(
        self, manager: HookManager, hooks_file: Path
    ) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PreToolUse", {"tool": "Bash"})
        assert "ALLOW or DENY" in results[0].output

    def test_prompt_hook_not_blocked_by_default(
        self, manager: HookManager, hooks_file: Path
    ) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PreToolUse", {"tool": "Bash"})
        assert results[0].blocked is False

    def test_prompt_hook_blocked_when_deny_response(
        self, manager: HookManager, hooks_file: Path
    ) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PreToolUse", {"tool": "Bash", "_prompt_response": "DENY"})
        assert results[0].blocked is True

    def test_prompt_hook_not_blocked_when_allow_response(
        self, manager: HookManager, hooks_file: Path
    ) -> None:
        manager.load(paths=[str(hooks_file)])
        results = manager.fire("PreToolUse", {"tool": "Bash", "_prompt_response": "ALLOW"})
        assert results[0].blocked is False

    def test_missing_prompt_field_returns_failure(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({"hooks": {"E": [{"type": "prompt"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        assert results[0].success is False


# ---------------------------------------------------------------------------
# fire_async()
# ---------------------------------------------------------------------------


class TestFireAsync:
    def test_fire_async_does_not_block(self, manager: HookManager, tmp_path: Path) -> None:
        p = tmp_path / "hooks.json"
        # Use a command that takes a moment
        p.write_text(
            json.dumps({"hooks": {"E": [{"type": "command", "command": "echo async_ok"}]}}),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        start = time.monotonic()
        manager.fire_async("E", {})
        elapsed = time.monotonic() - start
        # Should return almost immediately (well under 1 second)
        assert elapsed < 1.0

    def test_fire_async_runs_hook(self, manager: HookManager, tmp_path: Path) -> None:
        sentinel = tmp_path / "sentinel.txt"
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": f"echo done > {sentinel}",
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        manager.fire_async("E", {})
        # Give the background thread time to finish
        deadline = time.monotonic() + 5.0
        while not sentinel.exists() and time.monotonic() < deadline:
            time.sleep(0.05)
        assert sentinel.exists(), "Async hook did not create sentinel file in time"


# ---------------------------------------------------------------------------
# all_hooks()
# ---------------------------------------------------------------------------


class TestAllHooks:
    def test_all_hooks_returns_dict(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        result = manager.all_hooks()
        assert isinstance(result, dict)

    def test_all_hooks_contains_loaded_events(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        result = manager.all_hooks()
        assert set(result.keys()) == {"PostToolUse", "PreToolUse", "SessionStart"}

    def test_all_hooks_returns_copy(self, manager: HookManager, hooks_file: Path) -> None:
        manager.load(paths=[str(hooks_file)])
        result = manager.all_hooks()
        result["NewEvent"] = []
        # Mutation of the returned dict must not affect internal state
        assert "NewEvent" not in manager.all_hooks()


# ---------------------------------------------------------------------------
# HookResult dataclass
# ---------------------------------------------------------------------------


class TestHookResult:
    def test_hook_result_defaults(self) -> None:
        r = HookResult(event="E", hook_type="command", success=True)
        assert r.output == ""
        assert r.blocked is False

    def test_hook_result_fields(self) -> None:
        r = HookResult(event="PreToolUse", hook_type="prompt", success=True, output="prompt text", blocked=True)
        assert r.event == "PreToolUse"
        assert r.hook_type == "prompt"
        assert r.success is True
        assert r.output == "prompt text"
        assert r.blocked is True


# ---------------------------------------------------------------------------
# Hook wiring in _execute_tool() — tasks 4.5 and 4.6
# ---------------------------------------------------------------------------


class TestExecuteToolHookWiring:
    """Verify PreToolUse and PostToolUse hooks are wired into _execute_tool().

    Uses a minimal ToolLoop-like object that has _execute_tool injected,
    a real HookManager, and a stub PermissionManager.
    """

    def _make_loop(self, hooks_file: Path):
        """Build a minimal object that behaves like ToolLoop for _execute_tool."""
        from widdx.tool_loop.tools import _execute_tool, _parse_args
        from widdx.hooks import HookManager
        from widdx.permissions import PermissionManager

        class FakeLoop:
            pass

        loop = FakeLoop()
        loop._parse_args = lambda raw: _parse_args(loop, raw)
        loop._execute_tool = lambda name, raw: _execute_tool(loop, name, raw)
        loop._permissions = PermissionManager()
        loop._created_files = []
        loop._edited_files = []
        loop._hook_manager = HookManager()
        loop._hook_manager.load(paths=[str(hooks_file)])
        return loop

    # ── 4.5: PreToolUse blocks tool execution ────────────────────────

    def test_pretooluse_blocked_returns_error(self, tmp_path: Path) -> None:
        """A hook that returns blocked=True must prevent tool execution."""
        hooks_file = tmp_path / "hooks.json"
        hooks_file.write_text(
            json.dumps({
                "hooks": {
                    "PreToolUse": [
                        {
                            "matcher": "Bash",
                            "type": "prompt",
                            "prompt": "Block this.",
                        }
                    ]
                }
            }),
            encoding="utf-8",
        )
        loop = self._make_loop(hooks_file)
        # Inject a DENY response so the prompt hook blocks
        import widdx.hooks.handlers as _handlers
        original_run = _handlers.PromptHandler.run

        def blocking_run(self_h, event, hook, context):
            from widdx.hooks.handlers import HookResult
            return HookResult(event=event, hook_type="prompt", success=True,
                              output="DENY", blocked=True)

        _handlers.PromptHandler.run = blocking_run
        try:
            result = loop._execute_tool("Bash", json.dumps({"command": "echo hi"}))
        finally:
            _handlers.PromptHandler.run = original_run

        assert "error" in result
        assert "blocked" in result["error"].lower()

    def test_pretooluse_not_blocked_allows_execution(self, tmp_path: Path) -> None:
        """When no hook blocks, the tool executes normally."""
        hooks_file = tmp_path / "hooks.json"
        hooks_file.write_text(
            json.dumps({
                "hooks": {
                    "PreToolUse": [
                        {
                            "matcher": "Bash",
                            "type": "prompt",
                            "prompt": "Allow this.",
                        }
                    ]
                }
            }),
            encoding="utf-8",
        )
        loop = self._make_loop(hooks_file)
        result = loop._execute_tool("Bash", json.dumps({"command": "echo hello"}))
        # Should execute (not blocked) — result has no "blocked" error
        assert "blocked" not in result.get("error", "")

    def test_pretooluse_fires_for_every_tool(self, tmp_path: Path) -> None:
        """PreToolUse hook fires for non-Bash tools too (matcher-less hook)."""
        fired: list[str] = []
        hooks_file = tmp_path / "hooks.json"
        hooks_file.write_text(
            json.dumps({
                "hooks": {
                    "PreToolUse": [
                        {"type": "command", "command": "echo pre_fired"}
                    ]
                }
            }),
            encoding="utf-8",
        )
        loop = self._make_loop(hooks_file)

        # Patch fire() to record calls without actually running commands
        original_fire = loop._hook_manager.fire

        def recording_fire(event, context):
            fired.append(event)
            return []

        loop._hook_manager.fire = recording_fire
        loop._execute_tool("ListDir", json.dumps({"path": str(tmp_path)}))
        assert "PreToolUse" in fired

    # ── 4.6: PostToolUse fires async after execution ─────────────────

    def test_posttooluse_fires_after_execution(self, tmp_path: Path) -> None:
        """PostToolUse hook fires (async) after a successful tool call."""
        hooks_file = tmp_path / "hooks.json"
        hooks_file.write_text(json.dumps({"hooks": {}}), encoding="utf-8")
        loop = self._make_loop(hooks_file)

        fired_events: list[str] = []

        def recording_fire_async(event, context):
            fired_events.append(event)

        loop._hook_manager.fire_async = recording_fire_async
        loop._execute_tool("ListDir", json.dumps({"path": str(tmp_path)}))
        assert "PostToolUse" in fired_events

    def test_posttooluse_receives_tool_name_and_result(self, tmp_path: Path) -> None:
        """PostToolUse context includes 'tool' and 'result' keys."""
        hooks_file = tmp_path / "hooks.json"
        hooks_file.write_text(json.dumps({"hooks": {}}), encoding="utf-8")
        loop = self._make_loop(hooks_file)

        captured: list[dict] = []

        def capturing_fire_async(event, context):
            captured.append({"event": event, "context": context})

        loop._hook_manager.fire_async = capturing_fire_async
        loop._execute_tool("ListDir", json.dumps({"path": str(tmp_path)}))

        assert len(captured) == 1
        ctx = captured[0]["context"]
        assert ctx["tool"] == "ListDir"
        assert "result" in ctx

    def test_posttooluse_fires_even_on_error_result(self, tmp_path: Path) -> None:
        """PostToolUse fires even when the tool returns an error dict."""
        hooks_file = tmp_path / "hooks.json"
        hooks_file.write_text(json.dumps({"hooks": {}}), encoding="utf-8")
        loop = self._make_loop(hooks_file)

        fired_events: list[str] = []

        def recording_fire_async(event, context):
            fired_events.append(event)

        loop._hook_manager.fire_async = recording_fire_async
        # ListDir on a non-existent path returns an error
        loop._execute_tool("ListDir", json.dumps({"path": str(tmp_path / "nonexistent")}))
        assert "PostToolUse" in fired_events

    def test_no_hook_manager_does_not_crash(self, tmp_path: Path) -> None:
        """_execute_tool works fine when _hook_manager is absent (getattr guard)."""
        from widdx.tool_loop.tools import _execute_tool, _parse_args
        from widdx.permissions import PermissionManager

        class FakeLoop:
            pass

        loop = FakeLoop()
        loop._parse_args = lambda raw: _parse_args(loop, raw)
        loop._execute_tool = lambda name, raw: _execute_tool(loop, name, raw)
        loop._permissions = PermissionManager()
        loop._created_files = []
        loop._edited_files = []
        # Deliberately no _hook_manager attribute

        result = loop._execute_tool("ListDir", json.dumps({"path": str(tmp_path)}))
        assert "error" not in result


# ---------------------------------------------------------------------------
# fire() — async: true per-hook flag (task 4.9)
# ---------------------------------------------------------------------------


class TestFireAsyncFlag:
    """Verify that individual hooks with ``"async": true`` run in a background
    thread when called via the synchronous ``fire()`` method."""

    def test_async_hook_not_included_in_results(
        self, manager: HookManager, tmp_path: Path
    ) -> None:
        """fire() returns an empty list when the only hook is async."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": "echo async_hook",
                                "async": True,
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        # Async hooks are dispatched to a thread; no result is returned.
        assert results == []

    def test_async_hook_does_not_block(
        self, manager: HookManager, tmp_path: Path
    ) -> None:
        """fire() returns quickly even when the async hook takes time."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": "echo async_nonblocking",
                                "async": True,
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        start = time.monotonic()
        manager.fire("E", {})
        elapsed = time.monotonic() - start
        assert elapsed < 1.0

    def test_sync_hook_still_returns_result(
        self, manager: HookManager, tmp_path: Path
    ) -> None:
        """Hooks without ``async: true`` still run synchronously and return results."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": "echo sync_hook",
                                "async": False,
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        assert len(results) == 1
        assert results[0].success is True

    def test_mixed_async_and_sync_hooks(
        self, manager: HookManager, tmp_path: Path
    ) -> None:
        """When both async and sync hooks exist, only sync results are returned."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": "echo sync_one",
                                "async": False,
                            },
                            {
                                "type": "command",
                                "command": "echo async_one",
                                "async": True,
                            },
                            {
                                "type": "command",
                                "command": "echo sync_two",
                            },
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        results = manager.fire("E", {})
        # Two sync hooks → two results; the async hook is excluded.
        assert len(results) == 2
        outputs = [r.output for r in results]
        assert any("sync_one" in o for o in outputs)
        assert any("sync_two" in o for o in outputs)

    def test_async_hook_actually_executes(
        self, manager: HookManager, tmp_path: Path
    ) -> None:
        """The background thread spawned by fire() actually runs the hook."""
        sentinel = tmp_path / "async_flag.txt"
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps(
                {
                    "hooks": {
                        "E": [
                            {
                                "type": "command",
                                "command": f"echo done > {sentinel}",
                                "async": True,
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        manager.load(paths=[str(p)])
        manager.fire("E", {})
        # Wait for the background thread to finish (up to 5 s).
        deadline = time.monotonic() + 5.0
        while not sentinel.exists() and time.monotonic() < deadline:
            time.sleep(0.05)
        assert sentinel.exists(), "Async hook (via fire()) did not create sentinel file in time"


# ---------------------------------------------------------------------------
# REQ-2.8: /hooks command shows loaded hooks
# ---------------------------------------------------------------------------


class TestShowHooksCommand:
    """/hooks REPL command displays loaded hooks grouped by event name.

    Validates: REQ-2.8
    """

    def _make_repl_with_hooks(self, hooks_file):
        """Build a minimal WIDDXRepl-like object with a real HookManager."""
        from widdx.hooks import HookManager
        from widdx.repl.commands import _show_hooks

        class FakeToolLoop:
            pass

        class FakeRepl:
            pass

        tool_loop = FakeToolLoop()
        hook_manager = HookManager()
        hook_manager.load(paths=[str(hooks_file)])
        tool_loop._hook_manager = hook_manager

        repl = FakeRepl()
        repl._tool_loop = tool_loop
        repl._show_hooks = lambda: _show_hooks(repl)
        return repl

    def test_show_hooks_no_manager(self, capsys) -> None:
        """When _hook_manager is absent, /hooks prints a graceful message."""
        from widdx.repl.commands import _show_hooks
        from widdx import ui

        class FakeToolLoop:
            pass  # no _hook_manager attribute

        class FakeRepl:
            pass

        repl = FakeRepl()
        repl._tool_loop = FakeToolLoop()

        # Should not raise
        _show_hooks(repl)

    def test_show_hooks_empty(self, tmp_path: Path) -> None:
        """When no hooks are loaded, /hooks prints a 'no hooks' message."""
        from widdx.repl.commands import _show_hooks
        from widdx.hooks import HookManager

        class FakeToolLoop:
            pass

        class FakeRepl:
            pass

        tool_loop = FakeToolLoop()
        hook_manager = HookManager()
        hook_manager.load(paths=[])  # no hooks
        tool_loop._hook_manager = hook_manager

        repl = FakeRepl()
        repl._tool_loop = tool_loop

        # Should not raise
        _show_hooks(repl)

    def test_show_hooks_lists_events(self, hooks_file: Path) -> None:
        """all_hooks() returns the events that /hooks would display."""
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(hooks_file)])
        hooks = manager.all_hooks()

        # The fixture defines PostToolUse, PreToolUse, SessionStart
        assert "PostToolUse" in hooks
        assert "PreToolUse" in hooks
        assert "SessionStart" in hooks

    def test_show_hooks_counts_per_event(self, hooks_file: Path) -> None:
        """Each event in all_hooks() has the correct number of hook entries."""
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(hooks_file)])
        hooks = manager.all_hooks()

        assert len(hooks["PostToolUse"]) == 1
        assert len(hooks["PreToolUse"]) == 1
        assert len(hooks["SessionStart"]) == 1

    def test_show_hooks_includes_hook_type(self, hooks_file: Path) -> None:
        """Hook entries expose their 'type' field for display."""
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(hooks_file)])
        hooks = manager.all_hooks()

        post_hook = hooks["PostToolUse"][0]
        assert post_hook.get("type") == "command"

        pre_hook = hooks["PreToolUse"][0]
        assert pre_hook.get("type") == "prompt"

    def test_show_hooks_includes_matcher(self, hooks_file: Path) -> None:
        """Hook entries expose their 'matcher' field for display."""
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(hooks_file)])
        hooks = manager.all_hooks()

        post_hook = hooks["PostToolUse"][0]
        assert post_hook.get("matcher") == "Write|Edit"

    def test_show_hooks_async_flag_visible(self, tmp_path: Path) -> None:
        """Async hooks expose their 'async' flag so /hooks can display it."""
        from widdx.hooks import HookManager

        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "PostToolUse": [
                        {"type": "command", "command": "echo hi", "async": True}
                    ]
                }
            }),
            encoding="utf-8",
        )
        manager = HookManager()
        manager.load(paths=[str(p)])
        hooks = manager.all_hooks()

        hook = hooks["PostToolUse"][0]
        assert hook.get("async") is True


# ---------------------------------------------------------------------------
# REQ-2.9: SessionStart event fires at session start
# ---------------------------------------------------------------------------


class TestSessionStartHook:
    """SessionStart hooks fire when WIDDXRepl._setup() is called.

    Validates: REQ-2.9
    """

    def test_session_start_fires_on_setup(self, tmp_path: Path) -> None:
        """_setup() calls hook_manager.fire('SessionStart', {})."""
        from widdx.hooks import HookManager

        fired: list[str] = []

        class RecordingHookManager(HookManager):
            def fire(self, event, context):
                fired.append(event)
                return []

        manager = RecordingHookManager()

        # Simulate what _setup() does
        manager.fire("SessionStart", {})

        assert "SessionStart" in fired

    def test_session_start_hook_executes_command(self, tmp_path: Path) -> None:
        """A SessionStart command hook actually runs when fired."""
        sentinel = tmp_path / "session_started.txt"
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "SessionStart": [
                        {
                            "type": "command",
                            "command": f"echo started > {sentinel}",
                        }
                    ]
                }
            }),
            encoding="utf-8",
        )
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(p)])
        results = manager.fire("SessionStart", {})

        assert len(results) == 1
        assert results[0].success is True

    def test_session_start_no_matcher_required(self, tmp_path: Path) -> None:
        """SessionStart hooks fire without a matcher (no tool context needed)."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "SessionStart": [
                        {"type": "command", "command": "echo session_ok"}
                    ]
                }
            }),
            encoding="utf-8",
        )
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(p)])
        # Fire with empty context — no 'tool' key
        results = manager.fire("SessionStart", {})
        assert len(results) == 1
        assert results[0].success is True

    def test_session_start_fires_only_for_session_start_event(
        self, tmp_path: Path
    ) -> None:
        """SessionStart hooks do NOT fire for other events."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "SessionStart": [
                        {"type": "command", "command": "echo session_only"}
                    ]
                }
            }),
            encoding="utf-8",
        )
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(p)])

        # PostToolUse should not trigger SessionStart hooks
        results = manager.fire("PostToolUse", {"tool": "Write"})
        assert results == []

    def test_setup_fires_session_start_via_hook_manager(self, tmp_path: Path) -> None:
        """WIDDXRepl._setup() calls fire('SessionStart') on the hook_manager."""
        from widdx.hooks import HookManager

        fired_events: list[str] = []

        class SpyHookManager(HookManager):
            def fire(self, event, context):
                fired_events.append(event)
                return []

        # Simulate the _setup() logic that fires SessionStart
        hook_manager = SpyHookManager()
        # Replicate the guard from WIDDXRepl._setup():
        #   hook_manager = getattr(self._tool_loop, "_hook_manager", None)
        #   if hook_manager is not None:
        #       hook_manager.fire("SessionStart", {})
        if hook_manager is not None:
            hook_manager.fire("SessionStart", {})

        assert "SessionStart" in fired_events


# ---------------------------------------------------------------------------
# REQ-2.10: TaskCompleted event fires after each task
# ---------------------------------------------------------------------------


class TestTaskCompletedHook:
    """TaskCompleted hooks fire after WIDDXRepl._execute_task() completes.

    Validates: REQ-2.10
    """

    def test_task_completed_fires_async(self, tmp_path: Path) -> None:
        """_execute_task() calls fire_async('TaskCompleted', ...) after the task."""
        from widdx.hooks import HookManager

        fired_async: list[str] = []

        class SpyHookManager(HookManager):
            def fire_async(self, event, context):
                fired_async.append(event)

        hook_manager = SpyHookManager()

        # Replicate the _execute_task() logic:
        #   hook_manager = getattr(self._tool_loop, "_hook_manager", None)
        #   if hook_manager is not None:
        #       hook_manager.fire_async("TaskCompleted", {...})
        if hook_manager is not None:
            hook_manager.fire_async("TaskCompleted", {
                "task": "test task",
                "result": "done",
            })

        assert "TaskCompleted" in fired_async

    def test_task_completed_context_has_task_and_result(self, tmp_path: Path) -> None:
        """TaskCompleted context includes 'task' and 'result' keys."""
        from widdx.hooks import HookManager

        captured: list[dict] = []

        class SpyHookManager(HookManager):
            def fire_async(self, event, context):
                captured.append({"event": event, "context": context})

        hook_manager = SpyHookManager()
        task_text = "build a REST API"
        result_text = "Done. Created api.py."

        hook_manager.fire_async("TaskCompleted", {
            "task": task_text,
            "result": result_text[:200],
        })

        assert len(captured) == 1
        assert captured[0]["event"] == "TaskCompleted"
        assert captured[0]["context"]["task"] == task_text
        assert "result" in captured[0]["context"]

    def test_task_completed_hook_executes_command(self, tmp_path: Path) -> None:
        """A TaskCompleted command hook actually runs when fired."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "TaskCompleted": [
                        {"type": "command", "command": "echo task_done"}
                    ]
                }
            }),
            encoding="utf-8",
        )
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(p)])
        results = manager.fire("TaskCompleted", {"task": "test", "result": "ok"})

        assert len(results) == 1
        assert results[0].success is True
        assert "task_done" in results[0].output

    def test_task_completed_fires_only_for_task_completed_event(
        self, tmp_path: Path
    ) -> None:
        """TaskCompleted hooks do NOT fire for other events."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "TaskCompleted": [
                        {"type": "command", "command": "echo task_only"}
                    ]
                }
            }),
            encoding="utf-8",
        )
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(p)])

        # SessionStart should not trigger TaskCompleted hooks
        results = manager.fire("SessionStart", {})
        assert results == []

    def test_task_completed_fires_after_every_task(self, tmp_path: Path) -> None:
        """TaskCompleted fires once per task execution (multiple tasks = multiple fires)."""
        from widdx.hooks import HookManager

        fire_count = [0]

        class CountingHookManager(HookManager):
            def fire_async(self, event, context):
                if event == "TaskCompleted":
                    fire_count[0] += 1

        hook_manager = CountingHookManager()

        # Simulate 3 task completions
        for i in range(3):
            hook_manager.fire_async("TaskCompleted", {"task": f"task {i}", "result": "ok"})

        assert fire_count[0] == 3

    def test_task_completed_async_does_not_block(self, tmp_path: Path) -> None:
        """fire_async('TaskCompleted') returns immediately (non-blocking)."""
        p = tmp_path / "hooks.json"
        p.write_text(
            json.dumps({
                "hooks": {
                    "TaskCompleted": [
                        {"type": "command", "command": "echo done", "async": True}
                    ]
                }
            }),
            encoding="utf-8",
        )
        from widdx.hooks import HookManager

        manager = HookManager()
        manager.load(paths=[str(p)])

        start = time.monotonic()
        manager.fire_async("TaskCompleted", {"task": "test", "result": "ok"})
        elapsed = time.monotonic() - start

        assert elapsed < 1.0
