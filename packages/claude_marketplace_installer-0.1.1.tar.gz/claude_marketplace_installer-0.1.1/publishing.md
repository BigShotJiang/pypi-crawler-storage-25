# Publishing to PyPI

## Build the package

```bash
uv build
```

## Upload to PyPI

```bash
uv publish --token pypi-your-token-here
```

Get an API token from [pypi.org](https://pypi.org) under Account Settings.
