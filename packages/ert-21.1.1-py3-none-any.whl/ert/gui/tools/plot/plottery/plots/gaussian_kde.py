from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd
from scipy.stats import gaussian_kde

from ert.gui.tools.plot.plot_api import EnsembleObject, PlotApiKeyDefinition

from .plot_tools import ConditionalAxisFormatter, PlotTools

if TYPE_CHECKING:
    import numpy.typing as npt
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure

    from ert.gui.tools.plot.plottery import PlotConfig, PlotContext


class GaussianKDEPlot:
    def __init__(self) -> None:
        self.dimensionality = 1
        self.requires_observations = False

    @staticmethod
    def plot(
        figure: Figure,
        plot_context: PlotContext,
        ensemble_to_data_map: dict[EnsembleObject, pd.DataFrame],
        observation_data: pd.DataFrame,
        std_dev_images: dict[str, npt.NDArray[np.float32]],
        obs_loc: npt.NDArray[np.float32] | None,
        key_def: PlotApiKeyDefinition | None = None,
    ) -> None:
        plotGaussianKDE(figure, plot_context, ensemble_to_data_map, observation_data)


def _array_is_constant(data: pd.Series | pd.DataFrame) -> bool:
    array = data.to_numpy()
    return array.shape[0] == 0 or (array[0] == array).all()


def plotGaussianKDE(
    figure: Figure,
    plot_context: PlotContext,
    ensemble_to_data_map: dict[EnsembleObject, pd.DataFrame],
    _observation_data: Any,
) -> None:
    config = plot_context.plotConfig()
    axes = figure.add_subplot(111)

    plot_context.deactivateDateSupport()
    plot_context.x_axis = plot_context.VALUE_AXIS
    plot_context.y_axis = plot_context.DENSITY_AXIS

    for (ensemble, data), color_index in zip(
        ensemble_to_data_map.items(),
        plot_context.ensembles_color_indexes(),
        strict=False,
    ):
        config.setCurrentColor(color_index)
        if data.empty or not pd.api.types.is_numeric_dtype(data[0]):
            continue
        if not _array_is_constant(data[0]):
            _plotGaussianKDE(
                axes, config, data[0], f"{ensemble.experiment_name} : {ensemble.name}"
            )

    if plot_context.log_scale:
        axes.set_xscale("log")

    PlotTools.finalizePlot(
        plot_context, figure, axes, default_x_label="Value", default_y_label="Density"
    )


def _plotGaussianKDE(
    axes: Axes, plot_config: PlotConfig, data: pd.DataFrame, label: str
) -> None:
    style = plot_config.histogramStyle()

    sample_range = data.max() - data.min()
    indexes = np.linspace(
        data.min() - 0.5 * sample_range, data.max() + 0.5 * sample_range, 1000
    )
    gkde = gaussian_kde(data.values)
    evaluated_gkde = gkde.evaluate(indexes)

    axes.xaxis.set_major_formatter(ConditionalAxisFormatter())

    lines = axes.plot(
        indexes,
        evaluated_gkde,
        linewidth=style.width,
        color=style.color,
        alpha=style.alpha,
    )

    if len(lines) > 0:
        plot_config.addLegendItem(label, lines[0])
