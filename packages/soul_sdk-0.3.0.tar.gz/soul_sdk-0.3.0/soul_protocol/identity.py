"""SOUL Protocol — Agent Identity (DID:key, Ed25519 signing, canonical JSON)."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from nacl.exceptions import BadSignatureError
from nacl.signing import SigningKey, VerifyKey


JsonDict = Dict[str, Any]

_DID_PREFIX = "did:soul:z"
_MULTICODEC_ED25519_PREFIX = b"\xed\x01"
_BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_BASE58_INDEX = {ch: idx for idx, ch in enumerate(_BASE58_ALPHABET)}


# ── Canonical JSON ──────────────────────────────────────────────

def canonical_json(data: JsonDict) -> bytes:
    """Deterministic JSON serialization for hashing and signing."""
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")


def canonical_hash(data: JsonDict) -> str:
    """SHA-256 of canonical JSON."""
    return hashlib.sha256(canonical_json(data)).hexdigest()


# ── Base58btc ───────────────────────────────────────────────────

def _b58_encode(raw: bytes) -> str:
    number = int.from_bytes(raw, "big")
    encoded = ""
    while number > 0:
        number, remainder = divmod(number, 58)
        encoded = _BASE58_ALPHABET[remainder] + encoded
    leading_zeroes = len(raw) - len(raw.lstrip(b"\x00"))
    return ("1" * leading_zeroes) + (encoded or "1")


def _b58_decode(encoded: str) -> bytes:
    number = 0
    for char in encoded:
        if char not in _BASE58_INDEX:
            raise ValueError("Invalid base58btc character")
        number = number * 58 + _BASE58_INDEX[char]
    raw = number.to_bytes((number.bit_length() + 7) // 8, "big") if number else b""
    leading_ones = len(encoded) - len(encoded.lstrip("1"))
    return (b"\x00" * leading_ones) + raw


# ── DID Operations ──────────────────────────────────────────────

def public_key_to_did(public_key_hex: str) -> str:
    """Convert Ed25519 public key (hex) to did:soul:z... DID."""
    public_key = bytes.fromhex(str(public_key_hex))
    if len(public_key) != 32:
        raise ValueError("Ed25519 public key must be 32 bytes")
    return _DID_PREFIX + _b58_encode(_MULTICODEC_ED25519_PREFIX + public_key)


def resolve_did(did_string: str) -> bytes:
    """Extract 32-byte Ed25519 public key from a did:soul:z... DID."""
    did = str(did_string)
    if not did.startswith(_DID_PREFIX):
        raise ValueError(f"Unsupported DID format: {did[:20]}")
    decoded = _b58_decode(did[len(_DID_PREFIX):])
    if not decoded.startswith(_MULTICODEC_ED25519_PREFIX):
        raise ValueError("Unsupported DID multicodec")
    public_key = decoded[len(_MULTICODEC_ED25519_PREFIX):]
    if len(public_key) != 32:
        raise ValueError("Invalid Ed25519 public key length in DID")
    return public_key


# ── Key Generation ──────────────────────────────────────────────

def generate_keypair() -> Tuple[str, str]:
    """Generate a new Ed25519 keypair. Returns (private_key_hex, public_key_hex)."""
    signing_key = SigningKey.generate()
    return signing_key.encode().hex(), signing_key.verify_key.encode().hex()


# ── Signing ─────────────────────────────────────────────────────

def sign(private_key: str, data: JsonDict) -> str:
    """Sign a JSON-serializable dict. Returns hex signature."""
    message = canonical_json(data)
    return SigningKey(bytes.fromhex(private_key)).sign(message).signature.hex()


def verify(public_key: str, data: JsonDict, signature: str) -> bool:
    """Verify an Ed25519 signature over canonical JSON."""
    message = canonical_json(data)
    try:
        VerifyKey(bytes.fromhex(public_key)).verify(message, bytes.fromhex(signature))
        return True
    except (BadSignatureError, ValueError):
        return False


# ── Identity Class ──────────────────────────────────────────────

class Identity:
    """An agent's cryptographic identity — keypair + DID + manifest."""

    def __init__(
        self,
        name: str,
        private_key: Optional[str] = None,
        public_key: Optional[str] = None,
        keys_dir: str = "keys",
    ):
        self.name = name
        self._keys_dir = Path(keys_dir)

        if private_key:
            self._private_key = private_key
            self._public_key = public_key or SigningKey(
                bytes.fromhex(private_key)
            ).verify_key.encode().hex()
        else:
            self._load_or_generate()

    def _load_or_generate(self):
        """Load existing keys from disk or generate new ones."""
        self._keys_dir.mkdir(parents=True, exist_ok=True)
        priv_path = self._keys_dir / f"{self.name}.key"
        pub_path = self._keys_dir / f"{self.name}.pub"

        if priv_path.exists():
            self._private_key = priv_path.read_text().strip()
            self._public_key = pub_path.read_text().strip() if pub_path.exists() else (
                SigningKey(bytes.fromhex(self._private_key)).verify_key.encode().hex()
            )
        else:
            self._private_key, self._public_key = generate_keypair()
            priv_path.write_text(self._private_key)
            pub_path.write_text(self._public_key)

    @property
    def private_key(self) -> str:
        return self._private_key

    @property
    def public_key(self) -> str:
        return self._public_key

    @property
    def did(self) -> str:
        return public_key_to_did(self._public_key)

    def sign(self, data: JsonDict) -> str:
        """Sign data with this identity's private key."""
        return sign(self._private_key, data)

    def verify(self, data: JsonDict, signature: str) -> bool:
        """Verify a signature against this identity's public key."""
        return verify(self._public_key, data, signature)

    def manifest(self, capabilities: Optional[list] = None, **extra) -> JsonDict:
        """Generate a self-signed agent manifest."""
        manifest_data = {
            "soul_version": "0.1.0",
            "did": self.did,
            "name": self.name,
            "created": datetime.now(timezone.utc).isoformat(),
            "public_key": self._public_key,
            "capabilities": capabilities or [],
            **extra,
        }
        manifest_data["manifest_signature"] = self.sign(manifest_data)
        return manifest_data

    def __repr__(self) -> str:
        return f"Identity(name={self.name!r}, did={self.did!r})"
