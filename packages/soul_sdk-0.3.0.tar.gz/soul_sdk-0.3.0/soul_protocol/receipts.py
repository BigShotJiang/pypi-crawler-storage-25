"""SOUL Protocol — Receipt types and dual-signing."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from uuid import uuid4

from .identity import canonical_json, sign, verify


JsonDict = Dict[str, Any]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_task_id() -> str:
    return f"task-{uuid4().hex[:12]}"


# ── Receipt Type Dataclasses ────────────────────────────────────

@dataclass
class ReceiptTypeBase:
    task_id: str

    def validate(self) -> None:
        if not str(self.task_id).strip():
            raise ValueError("task_id is required")

    def as_data(self) -> JsonDict:
        self.validate()
        return {"task_id": self.task_id}


@dataclass
class TaskRequest(ReceiptTypeBase):
    description: str = ""
    budget: float = 0.0
    deadline: str = field(default_factory=_utc_now)

    def validate(self) -> None:
        super().validate()
        if not str(self.description).strip():
            raise ValueError("description is required")
        if float(self.budget) < 0:
            raise ValueError("budget must be non-negative")

    def as_data(self) -> JsonDict:
        self.validate()
        return {
            "task_id": self.task_id,
            "description": str(self.description),
            "budget": float(self.budget),
            "deadline": str(self.deadline),
        }


@dataclass
class TaskAccepted(ReceiptTypeBase):
    estimated_delivery: str = ""

    def validate(self) -> None:
        super().validate()
        if not str(self.estimated_delivery).strip():
            raise ValueError("estimated_delivery is required")

    def as_data(self) -> JsonDict:
        self.validate()
        return {
            "task_id": self.task_id,
            "estimated_delivery": str(self.estimated_delivery),
        }


@dataclass
class TaskDelivered(ReceiptTypeBase):
    artifact_hash: str = ""
    artifact_url: Optional[str] = None

    def validate(self) -> None:
        super().validate()
        if not str(self.artifact_hash).strip():
            raise ValueError("artifact_hash is required")

    def as_data(self) -> JsonDict:
        self.validate()
        payload: JsonDict = {
            "task_id": self.task_id,
            "artifact_hash": str(self.artifact_hash),
        }
        if self.artifact_url:
            payload["artifact_url"] = str(self.artifact_url)
        return payload


@dataclass
class TaskConfirmed(ReceiptTypeBase):
    rating: int = 0
    feedback: str = ""

    def validate(self) -> None:
        super().validate()
        if not (1 <= int(self.rating) <= 5):
            raise ValueError("rating must be between 1 and 5")
        if not str(self.feedback).strip():
            raise ValueError("feedback is required")

    def as_data(self) -> JsonDict:
        self.validate()
        return {
            "task_id": self.task_id,
            "rating": int(self.rating),
            "feedback": str(self.feedback),
        }


@dataclass
class TaskDisputed(ReceiptTypeBase):
    reason: str = ""

    def validate(self) -> None:
        super().validate()
        if not str(self.reason).strip():
            raise ValueError("reason is required")

    def as_data(self) -> JsonDict:
        self.validate()
        return {
            "task_id": self.task_id,
            "reason": str(self.reason),
        }


# ── Receipt Operations ──────────────────────────────────────────

class Receipt:
    """Create, sign, countersign, and verify SOUL receipts."""

    @staticmethod
    def signing_payload(receipt: JsonDict) -> JsonDict:
        """Extract the canonical payload that both parties sign."""
        return {
            "timestamp": str(receipt["timestamp"]),
            "event_type": str(receipt["event_type"]),
            "data": receipt["data"],
            "agent_a_pubkey": str(receipt["agent_a_pubkey"]),
            "agent_b_pubkey": str(receipt["agent_b_pubkey"]),
            "parent_receipt_hash": str(receipt.get("parent_receipt_hash", "")),
        }

    @staticmethod
    def proof_hash(receipt: JsonDict) -> str:
        """SHA-256 proof hash of a fully dual-signed receipt."""
        payload = {
            "timestamp": str(receipt["timestamp"]),
            "event_type": str(receipt["event_type"]),
            "data": receipt["data"],
            "parent_receipt_hash": str(receipt.get("parent_receipt_hash", "")),
            "agent_a_pubkey": str(receipt["agent_a_pubkey"]),
            "agent_a_signature": str(receipt["agent_a_signature"]),
            "agent_b_pubkey": str(receipt["agent_b_pubkey"]),
            "agent_b_signature": str(receipt["agent_b_signature"]),
        }
        return hashlib.sha256(canonical_json(payload)).hexdigest()

    @staticmethod
    def create(
        event_type: str,
        data: JsonDict,
        sender_private_key: str,
        sender_public_key: str,
        recipient_public_key: str,
        parent_receipt_hash: str = "",
    ) -> JsonDict:
        """Create a new receipt signed by agent A (sender)."""
        receipt = {
            "timestamp": _utc_now(),
            "event_type": event_type,
            "data": data,
            "agent_a_pubkey": sender_public_key,
            "agent_b_pubkey": recipient_public_key,
            "parent_receipt_hash": parent_receipt_hash,
            "agent_a_signature": "",
            "agent_b_signature": "",
        }
        payload = Receipt.signing_payload(receipt)
        receipt["agent_a_signature"] = sign(sender_private_key, payload)
        return receipt

    @staticmethod
    def countersign(receipt: JsonDict, recipient_private_key: str) -> JsonDict:
        """Countersign a receipt as agent B (recipient)."""
        payload = Receipt.signing_payload(receipt)

        # Verify agent A's signature first
        if not verify(receipt["agent_a_pubkey"], payload, receipt["agent_a_signature"]):
            raise ValueError("Agent A signature is invalid — cannot countersign")

        receipt = {**receipt}  # shallow copy
        receipt["agent_b_signature"] = sign(recipient_private_key, payload)
        return receipt

    @staticmethod
    def verify_dual(receipt: JsonDict) -> bool:
        """Verify both signatures on a receipt."""
        payload = Receipt.signing_payload(receipt)
        a_valid = verify(receipt["agent_a_pubkey"], payload, receipt["agent_a_signature"])
        b_valid = verify(receipt["agent_b_pubkey"], payload, receipt["agent_b_signature"])
        return a_valid and b_valid
