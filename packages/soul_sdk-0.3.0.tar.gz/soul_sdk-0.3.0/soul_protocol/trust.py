"""SOUL Protocol — Sybil-resistant trust scoring from receipt history."""

from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from typing import Any, Dict, List


JsonDict = Dict[str, Any]

# Trust score weights
WEIGHT_VOLUME = 0.15
WEIGHT_ON_TIME = 0.25
WEIGHT_RATING = 0.35
WEIGHT_DISPUTES = 0.10
WEIGHT_DIVERSITY = 0.15

# Sybil resistance thresholds
MIN_COUNTERPARTIES = 3
MAX_TRUST_BEFORE_DIVERSE = 0.5
DIVERSITY_CAP = 10
DECAY_HALF_LIFE_DAYS = 30


def _parse_time(value: Any) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


class TrustScorer:
    """Compute Sybil-resistant trust scores from receipt history."""

    def score(self, agent_pubkey: str, receipts: List[JsonDict]) -> JsonDict:
        """Build a trust report for an agent from their receipt history.

        Args:
            agent_pubkey: The public key of the agent to score.
            receipts: List of receipt dicts (from ledger.get_receipts()).

        Returns:
            Trust report with score (0.0-1.0), grade, and factor breakdown.
        """
        # Filter to receipts involving this agent
        relevant = []
        for row in receipts:
            data = row.get("data_json") or row.get("data", {})
            if isinstance(data, str):
                try:
                    data = json.loads(data)
                except json.JSONDecodeError:
                    data = {}
            if (str(row.get("agent_a_pubkey")) == agent_pubkey or
                    str(row.get("agent_b_pubkey")) == agent_pubkey):
                relevant.append({**row, "data": data if isinstance(data, dict) else {}})

        now = datetime.now(timezone.utc)

        # Counterparty diversity
        counterparties = set()
        for r in relevant:
            a, b = str(r.get("agent_a_pubkey", "")), str(r.get("agent_b_pubkey", ""))
            if a and a != agent_pubkey:
                counterparties.add(a)
            if b and b != agent_pubkey:
                counterparties.add(b)
        unique_counterparties = len(counterparties)
        diversity_score = min(unique_counterparties / DIVERSITY_CAP, 1.0)

        # Temporal decay
        def decay(row: JsonDict) -> float:
            ts = _parse_time(row.get("timestamp"))
            if ts is None:
                return 1.0
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            age_days = max((now - ts).total_seconds(), 0.0) / 86400.0
            return math.pow(0.5, age_days / DECAY_HALF_LIFE_DAYS)

        # Categorize receipts
        delivered = [r for r in relevant if str(r.get("event_type")) == "TaskDelivered"]
        confirmed = [r for r in relevant if str(r.get("event_type")) == "TaskConfirmed"]
        disputed = [r for r in relevant if str(r.get("event_type")) == "TaskDisputed"]

        # Weighted factors
        receipt_weights = [decay(r) for r in relevant]
        delivered_weights = [decay(r) for r in delivered]
        disputed_weights = [decay(r) for r in disputed]

        receipt_weight_total = sum(receipt_weights)
        delivered_weight_total = sum(delivered_weights)

        # On-time rate (weighted)
        on_time_rate = (delivered_weight_total / delivered_weight_total) if delivered_weight_total > 0 else 1.0

        # Rating (weighted by decay)
        rated_pairs = []
        for r in confirmed:
            val = r.get("data", {}).get("rating", "")
            if str(val).isdigit():
                rated_pairs.append((int(val), decay(r)))
        weighted_rating = sum(r * w for r, w in rated_pairs)
        rating_weight = sum(w for _, w in rated_pairs)
        average_rating = (weighted_rating / rating_weight) if rating_weight > 0 else 0.0
        rating_norm = min(max(average_rating / 5.0, 0.0), 1.0)

        # Dispute rate
        dispute_rate = (sum(disputed_weights) / receipt_weight_total) if receipt_weight_total > 0 else 0.0
        dispute_component = max(0.0, 1.0 - dispute_rate)

        # Volume
        volume_norm = min(receipt_weight_total / 20.0, 1.0)

        # Diversity weight
        diversity_weight = 0.5 + (0.5 * diversity_score)

        # Composite score
        raw_score = (
            WEIGHT_VOLUME * volume_norm +
            WEIGHT_ON_TIME * on_time_rate +
            WEIGHT_RATING * rating_norm +
            WEIGHT_DISPUTES * dispute_component +
            WEIGHT_DIVERSITY * diversity_score
        )
        score = raw_score * diversity_weight

        # Sybil cap
        if unique_counterparties < MIN_COUNTERPARTIES:
            score = min(score, MAX_TRUST_BEFORE_DIVERSE)

        score = round(min(max(score, 0.0), 1.0), 4)

        # Grade
        if score >= 0.9:
            grade = "A+"
        elif score >= 0.85:
            grade = "A"
        elif score >= 0.8:
            grade = "A-"
        elif score >= 0.75:
            grade = "B+"
        elif score >= 0.7:
            grade = "B"
        elif score >= 0.65:
            grade = "B-"
        elif score >= 0.6:
            grade = "C+"
        elif score >= 0.55:
            grade = "C"
        elif score >= 0.5:
            grade = "C-"
        elif score >= 0.4:
            grade = "D"
        else:
            grade = "F"

        return {
            "agent_pubkey": agent_pubkey,
            "score": score,
            "grade": grade,
            "factors": {
                "total_receipts": len(relevant),
                "delivered_receipts": len(delivered),
                "confirmed_receipts": len(confirmed),
                "disputed_receipts": len(disputed),
                "on_time_delivery_rate": round(on_time_rate, 4),
                "average_rating": round(average_rating, 4),
                "dispute_rate": round(dispute_rate, 4),
                "volume_normalized": round(volume_norm, 4),
                "diversity_score": round(diversity_score, 4),
                "unique_counterparties": unique_counterparties,
            },
            "computed_at": datetime.now(timezone.utc).isoformat(),
        }
