"""SOUL Protocol — E2E Encryption (NaCl Box over X25519)."""

from __future__ import annotations

import json
from typing import Any, Dict

from nacl import utils
from nacl.public import Box
from nacl.signing import SigningKey, VerifyKey


JsonDict = Dict[str, Any]


def encrypt_payload(
    payload: JsonDict,
    sender_private_key: str,
    recipient_public_key: str,
) -> JsonDict:
    """Encrypt a JSON payload using NaCl Box (X25519-XSalsa20-Poly1305).

    Keys are Ed25519 hex strings — automatically converted to Curve25519.
    """
    sender_signing = SigningKey(bytes.fromhex(sender_private_key))
    sender_curve = sender_signing.to_curve25519_private_key()
    recipient_curve = VerifyKey(bytes.fromhex(recipient_public_key)).to_curve25519_public_key()

    box = Box(sender_curve, recipient_curve)
    nonce = utils.random(Box.NONCE_SIZE)
    message = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ciphertext = box.encrypt(message, nonce).ciphertext

    return {
        "encrypted": True,
        "algorithm": "nacl.box.x25519-xsalsa20-poly1305",
        "sender_pubkey": sender_signing.verify_key.encode().hex(),
        "recipient_pubkey": recipient_public_key,
        "nonce": nonce.hex(),
        "ciphertext": ciphertext.hex(),
    }


def decrypt_payload(
    envelope: JsonDict,
    recipient_private_key: str,
) -> JsonDict:
    """Decrypt an encrypted envelope using the recipient's private key."""
    required = ["encrypted", "sender_pubkey", "nonce", "ciphertext"]
    missing = [f for f in required if f not in envelope]
    if missing:
        raise ValueError(f"Encrypted envelope missing: {', '.join(missing)}")

    sender_curve = VerifyKey(
        bytes.fromhex(envelope["sender_pubkey"])
    ).to_curve25519_public_key()
    recipient_curve = SigningKey(
        bytes.fromhex(recipient_private_key)
    ).to_curve25519_private_key()

    box = Box(recipient_curve, sender_curve)
    plaintext = box.decrypt(
        bytes.fromhex(envelope["ciphertext"]),
        bytes.fromhex(envelope["nonce"]),
    )
    decoded = json.loads(plaintext.decode("utf-8"))
    if not isinstance(decoded, dict):
        raise ValueError("Decrypted payload must be a JSON object")
    return decoded
