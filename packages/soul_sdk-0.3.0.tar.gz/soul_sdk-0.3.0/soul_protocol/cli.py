"""SOUL Protocol CLI — soul init, soul whoami, soul trust, soul anchor."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .agent import Agent


def _get_agent(args) -> Agent:
    return Agent(
        name=args.name,
        keys_dir=args.keys_dir,
        db_path=args.db_path,
    )


def cmd_init(args):
    """Initialize a new agent identity."""
    agent = _get_agent(args)
    manifest = agent.manifest(capabilities=["code", "research", "communicate"])
    print(f"Agent initialized:")
    print(f"  Name:       {agent.name}")
    print(f"  DID:        {agent.did}")
    print(f"  Public Key: {agent.public_key}")
    print(f"  Keys:       {args.keys_dir}/")
    print(f"  Database:   {args.db_path}")
    print(f"  Memory:     {agent.memory.base}/")
    print()
    print(json.dumps(manifest, indent=2))


def cmd_whoami(args):
    """Show current agent identity."""
    agent = _get_agent(args)
    print(f"{agent.name}")
    print(f"  DID:        {agent.did}")
    print(f"  Public Key: {agent.public_key}")


def cmd_trust(args):
    """Show trust score for self or a target agent."""
    agent = _get_agent(args)
    target = args.target if hasattr(args, "target") and args.target else None
    report = agent.trust_report(target_pubkey=target)
    print(json.dumps(report, indent=2))


def cmd_anchor(args):
    """Anchor latest receipt to Ethereum/Base/Sepolia."""
    agent = _get_agent(args)
    chain = args.chain if hasattr(args, "chain") else "base"

    receipts = agent.ledger.get_receipts(agent.public_key)
    if not receipts:
        print("No receipts to anchor.")
        return

    # Anchor the latest receipt
    latest = receipts[-1]
    # Reconstruct data from data_json if needed
    if "data" not in latest and "data_json" in latest:
        latest["data"] = json.loads(latest["data_json"])

    result = agent.anchor_receipt(latest, chain=chain)
    print(json.dumps(result, indent=2))


def cmd_anchor_all(args):
    """Batch-anchor all receipts."""
    agent = _get_agent(args)
    chain = args.chain if hasattr(args, "chain") else "base"
    result = agent.anchor_all(chain=chain)
    print(json.dumps(result, indent=2))


def cmd_history(args):
    """Show receipt history."""
    agent = _get_agent(args)
    receipts = agent.ledger.get_receipts(agent.public_key)
    if not receipts:
        print("No receipts yet.")
        return
    for r in receipts:
        ts = r.get("timestamp", "")[:19]
        event = r.get("event_type", "?")
        task = r.get("task_id", "")
        proof = r.get("proof_hash", "")[:12]
        print(f"  {ts}  {event:<16}  task={task or '-':<16}  proof={proof}...")


def cmd_export(args):
    """Export portable memory bundle."""
    agent = _get_agent(args)
    out = args.output if hasattr(args, "output") else f"./{agent.name}-soul-bundle"
    path = agent.export_memory(out)
    print(f"Memory bundle exported to: {path}")


def cmd_relay(args):
    """Start the relay server."""
    from .relay import run_relay
    host = args.host if hasattr(args, "host") else "0.0.0.0"
    port = args.port if hasattr(args, "port") else 8340
    run_relay(host=host, port=port)


def cmd_demo(args):
    """Run a live demo with simulated agents."""
    from .demo import run_demo
    num = args.agents if hasattr(args, "agents") else 6
    rounds = args.rounds if hasattr(args, "rounds") else 3
    port = args.port if hasattr(args, "port") else 8340
    no_browser = args.no_browser if hasattr(args, "no_browser") else False
    run_demo(num_agents=num, rounds=rounds, port=port, no_browser=no_browser)


def cmd_discover(args):
    """Discover agents on a relay."""
    from .relay_client import RelayClient
    agent = _get_agent(args)
    client = RelayClient(args.relay, agent)
    cap = args.capability if hasattr(args, "capability") and args.capability else None
    agents = client.discover(capability=cap)
    if not agents:
        print("No agents found.")
        return
    for a in agents:
        online = "●" if a.get("online") else "○"
        caps = ", ".join(a.get("capabilities", []))
        print(f"  {online} {a['name']:<16} {a['did'][:32]}...  [{caps}]")
    print(f"\n  {len(agents)} agent(s) found")


def cmd_send(args):
    """Send a message to another agent via relay."""
    from .relay_client import RelayClient
    agent = _get_agent(args)
    client = RelayClient(args.relay, agent)

    # Register if not already
    client.register(capabilities=["code", "research", "communicate"])

    payload = {"message": args.message, "from_name": agent.name}
    encrypt = args.encrypt if hasattr(args, "encrypt") else False
    result = client.send(to_did=args.to, payload=payload, encrypt=encrypt)
    status = result.get("status", "unknown")
    method = result.get("method", "")
    print(f"  Message {status}" + (f" via {method}" if method else ""))


def cmd_inbox(args):
    """Check inbox for pending messages."""
    from .relay_client import RelayClient
    agent = _get_agent(args)
    client = RelayClient(args.relay, agent)
    messages = client.inbox(clear=not args.peek if hasattr(args, "peek") else True)
    if not messages:
        print("  Inbox empty.")
        return
    for msg in messages:
        ts = msg.get("timestamp", "")[:19]
        sender = msg.get("from_name") or msg.get("from_did", "?")[:24]
        payload = msg.get("payload", {})
        text = payload.get("message", json.dumps(payload)[:80])
        print(f"  [{ts}] {sender}: {text}")
    print(f"\n  {len(messages)} message(s)")


def main():
    parser = argparse.ArgumentParser(
        prog="soul",
        description="SOUL Protocol — Identity, memory, trust, and verification for AI agents",
    )
    parser.add_argument("--name", default="Agent", help="Agent name (default: Agent)")
    parser.add_argument("--keys-dir", default="keys", help="Keys directory (default: keys)")
    parser.add_argument("--db-path", default="soul.db", help="Database path (default: soul.db)")

    sub = parser.add_subparsers(dest="command")

    # init
    sub.add_parser("init", help="Initialize a new agent identity")

    # whoami
    sub.add_parser("whoami", help="Show current agent identity")

    # trust
    trust_p = sub.add_parser("trust", help="Show trust score")
    trust_p.add_argument("--target", help="Target agent public key (default: self)")

    # anchor
    anchor_p = sub.add_parser("anchor", help="Anchor latest receipt to chain")
    anchor_p.add_argument("--chain", choices=["base", "ethereum", "sepolia"], default="base")

    # anchor-all
    anchor_all_p = sub.add_parser("anchor-all", help="Batch-anchor all receipts")
    anchor_all_p.add_argument("--chain", choices=["base", "ethereum", "sepolia"], default="base")

    # history
    sub.add_parser("history", help="Show receipt history")

    # export
    export_p = sub.add_parser("export", help="Export portable memory bundle")
    export_p.add_argument("--output", "-o", help="Output directory")

    # relay
    relay_p = sub.add_parser("relay", help="Start the relay server")
    relay_p.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    relay_p.add_argument("--port", type=int, default=8340, help="Bind port (default: 8340)")

    # demo
    demo_p = sub.add_parser("demo", help="Run a live demo with simulated agents")
    demo_p.add_argument("--agents", type=int, default=6, help="Number of agents (default: 6)")
    demo_p.add_argument("--rounds", type=int, default=3, help="Interaction rounds (default: 3)")
    demo_p.add_argument("--port", type=int, default=8340, help="Relay port (default: 8340)")
    demo_p.add_argument("--no-browser", action="store_true", help="Don't open browser")

    # discover
    discover_p = sub.add_parser("discover", help="Discover agents on a relay")
    discover_p.add_argument("--relay", default="http://localhost:8340", help="Relay URL")
    discover_p.add_argument("--capability", "-c", help="Filter by capability")

    # send
    send_p = sub.add_parser("send", help="Send a message via relay")
    send_p.add_argument("--relay", default="http://localhost:8340", help="Relay URL")
    send_p.add_argument("--to", required=True, help="Recipient DID")
    send_p.add_argument("--message", "-m", required=True, help="Message text")
    send_p.add_argument("--encrypt", "-e", action="store_true", help="E2E encrypt message")

    # inbox
    inbox_p = sub.add_parser("inbox", help="Check inbox for messages")
    inbox_p.add_argument("--relay", default="http://localhost:8340", help="Relay URL")
    inbox_p.add_argument("--peek", action="store_true", help="Don't clear messages after reading")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    commands = {
        "init": cmd_init,
        "whoami": cmd_whoami,
        "trust": cmd_trust,
        "anchor": cmd_anchor,
        "anchor-all": cmd_anchor_all,
        "history": cmd_history,
        "export": cmd_export,
        "relay": cmd_relay,
        "demo": cmd_demo,
        "discover": cmd_discover,
        "send": cmd_send,
        "inbox": cmd_inbox,
    }

    fn = commands.get(args.command)
    if fn:
        fn(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
