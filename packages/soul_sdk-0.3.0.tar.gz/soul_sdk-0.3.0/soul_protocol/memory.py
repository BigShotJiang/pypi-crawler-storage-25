"""SOUL Protocol — Portable agent memory (export/import bundles)."""

from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .identity import Identity, canonical_hash


JsonDict = Dict[str, Any]


class Memory:
    """Manage structured, portable agent memory.

    Memory tiers:
        identity/   — soul.md, voice.md, capabilities.md (permanent, rarely updated)
        memory/     — long-term.md, lessons.md, active-task.json, bridge.md, daily/
        trust/      — trust-report.json, receipts.db
    """

    def __init__(self, base_dir: str | Path) -> None:
        self.base = Path(base_dir)
        self.identity_dir = self.base / "identity"
        self.memory_dir = self.base / "memory"
        self.daily_dir = self.memory_dir / "daily"
        self.trust_dir = self.base / "trust"

    def init(self) -> None:
        """Create the memory directory structure."""
        for d in [self.identity_dir, self.memory_dir, self.daily_dir, self.trust_dir]:
            d.mkdir(parents=True, exist_ok=True)

    # ── Identity Tier ───────────────────────────────────────────

    def write_soul(self, content: str) -> None:
        self.identity_dir.mkdir(parents=True, exist_ok=True)
        (self.identity_dir / "soul.md").write_text(content)

    def read_soul(self) -> str:
        path = self.identity_dir / "soul.md"
        return path.read_text() if path.exists() else ""

    def write_voice(self, content: str) -> None:
        self.identity_dir.mkdir(parents=True, exist_ok=True)
        (self.identity_dir / "voice.md").write_text(content)

    def read_voice(self) -> str:
        path = self.identity_dir / "voice.md"
        return path.read_text() if path.exists() else ""

    # ── Memory Tier ─────────────────────────────────────────────

    def write_long_term(self, content: str) -> None:
        (self.memory_dir / "long-term.md").write_text(content)

    def read_long_term(self) -> str:
        path = self.memory_dir / "long-term.md"
        return path.read_text() if path.exists() else ""

    def write_lessons(self, content: str) -> None:
        (self.memory_dir / "lessons.md").write_text(content)

    def append_lesson(self, lesson: str) -> None:
        path = self.memory_dir / "lessons.md"
        existing = path.read_text() if path.exists() else ""
        path.write_text(existing.rstrip() + "\n\n" + lesson.strip() + "\n")

    def read_lessons(self) -> str:
        path = self.memory_dir / "lessons.md"
        return path.read_text() if path.exists() else ""

    def write_active_task(self, state: JsonDict) -> None:
        state["last_updated"] = datetime.now(timezone.utc).isoformat()
        (self.memory_dir / "active-task.json").write_text(
            json.dumps(state, indent=2, ensure_ascii=False)
        )

    def read_active_task(self) -> JsonDict:
        path = self.memory_dir / "active-task.json"
        if path.exists():
            return json.loads(path.read_text())
        return {}

    def write_bridge(self, entry: str) -> None:
        """Append to cross-runtime bridge log."""
        path = self.memory_dir / "bridge.md"
        existing = path.read_text() if path.exists() else "# Cross-Runtime Bridge\n"
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        path.write_text(existing.rstrip() + f"\n\n---\n\n### {timestamp}\n\n{entry.strip()}\n")

    def read_bridge(self) -> str:
        path = self.memory_dir / "bridge.md"
        return path.read_text() if path.exists() else ""

    # ── Daily Notes ─────────────────────────────────────────────

    def write_daily(self, content: str, date: Optional[str] = None) -> None:
        date = date or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        (self.daily_dir / f"{date}.md").write_text(content)

    def append_daily(self, entry: str, date: Optional[str] = None) -> None:
        date = date or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = self.daily_dir / f"{date}.md"
        existing = path.read_text() if path.exists() else f"# {date}\n"
        path.write_text(existing.rstrip() + "\n\n" + entry.strip() + "\n")

    def read_daily(self, date: Optional[str] = None) -> str:
        date = date or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = self.daily_dir / f"{date}.md"
        return path.read_text() if path.exists() else ""

    # ── Export / Import ─────────────────────────────────────────

    def export_bundle(self, output_dir: str | Path, identity: Identity) -> Path:
        """Export a portable memory bundle (excludes private key)."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        # Manifest
        manifest = identity.manifest()
        manifest["bundle_exported_at"] = datetime.now(timezone.utc).isoformat()
        (out / "manifest.json").write_text(json.dumps(manifest, indent=2))

        # Copy memory dirs
        for src_dir, name in [(self.identity_dir, "identity"), (self.memory_dir, "memory")]:
            if src_dir.exists():
                dst = out / name
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src_dir, dst)

        # Trust report
        trust_report = self.trust_dir / "trust-report.json"
        if trust_report.exists():
            (out / "trust").mkdir(exist_ok=True)
            shutil.copy2(trust_report, out / "trust" / "trust-report.json")

        return out

    @classmethod
    def from_bundle(cls, bundle_dir: str | Path, target_dir: str | Path) -> "Memory":
        """Import a memory bundle into a target directory."""
        bundle = Path(bundle_dir)
        target = Path(target_dir)
        target.mkdir(parents=True, exist_ok=True)

        for name in ["identity", "memory", "trust"]:
            src = bundle / name
            if src.exists():
                dst = target / name
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)

        manifest_src = bundle / "manifest.json"
        if manifest_src.exists():
            shutil.copy2(manifest_src, target / "manifest.json")

        return cls(target)
