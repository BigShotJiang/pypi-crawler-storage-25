"""SOUL Protocol — Relay Client (connect agents to a relay server)."""

from __future__ import annotations

import json
from typing import Any, Callable, Dict, List, Optional

from .identity import sign, verify, canonical_hash

JsonDict = Dict[str, Any]


class RelayClient:
    """Synchronous relay client for agent-to-agent communication.

    Usage:
        from soul_protocol import Agent
        from soul_protocol.relay_client import RelayClient

        agent = Agent(name="Mercury")
        client = RelayClient("http://localhost:8340", agent)

        # Register on the relay
        client.register(capabilities=["code", "research"])

        # Discover other agents
        agents = client.discover(capability="code")

        # Send a message
        client.send(to_did="did:soul:z...", payload={"task": "review code"})

        # Check inbox
        messages = client.inbox()
    """

    def __init__(self, relay_url: str, agent):
        """
        Args:
            relay_url: Base URL of the relay server (e.g. http://localhost:8340)
            agent: A soul_protocol.Agent instance
        """
        self.relay_url = relay_url.rstrip("/")
        self.agent = agent
        self._session = None

    def _http(self, method: str, path: str, json_data: dict = None) -> dict:
        """Make an HTTP request to the relay."""
        try:
            import httpx
        except ImportError:
            try:
                import requests
                resp = getattr(requests, method)(
                    f"{self.relay_url}{path}",
                    json=json_data,
                    timeout=10,
                )
                resp.raise_for_status()
                return resp.json()
            except ImportError:
                raise ImportError(
                    "Relay client requires httpx or requests: pip install soul-sdk[relay]"
                )

        with httpx.Client(timeout=10) as client:
            resp = getattr(client, method)(
                f"{self.relay_url}{path}",
                json=json_data,
            )
            resp.raise_for_status()
            return resp.json()

    def register(self, capabilities: List[str] = None, endpoint: str = None) -> dict:
        """Register this agent on the relay."""
        # Create a verifiable registration
        manifest_data = {
            "did": self.agent.did,
            "name": self.agent.name,
            "public_key": self.agent.public_key,
            "capabilities": capabilities or [],
        }
        signature = sign(self.agent.private_key, manifest_data)

        return self._http("post", "/register", {
            "did": self.agent.did,
            "name": self.agent.name,
            "public_key": self.agent.public_key,
            "capabilities": capabilities or [],
            "endpoint": endpoint,
            "manifest_signature": signature,
        })

    def discover(self, capability: str = None, min_trust: float = None, limit: int = 50) -> List[dict]:
        """Discover agents on the relay."""
        params = []
        if capability:
            params.append(f"capability={capability}")
        if min_trust is not None:
            params.append(f"min_trust={min_trust}")
        if limit != 50:
            params.append(f"limit={limit}")
        query = "?" + "&".join(params) if params else ""
        result = self._http("get", f"/discover{query}")
        return result.get("agents", [])

    def send(self, to_did: str, payload: dict, encrypt: bool = False) -> dict:
        """Send a signed message to another agent."""
        if encrypt:
            # Look up recipient's public key from relay
            agent_info = self._http("get", f"/agent/{to_did}")
            recipient_pubkey = agent_info["public_key"]
            from .crypto import encrypt_payload
            payload = encrypt_payload(payload, self.agent.private_key, recipient_pubkey)

        signature = sign(self.agent.private_key, payload)

        return self._http("post", "/send", {
            "from_did": self.agent.did,
            "to_did": to_did,
            "payload": payload,
            "signature": signature,
        })

    def inbox(self, clear: bool = True) -> List[dict]:
        """Retrieve pending messages."""
        clear_param = "true" if clear else "false"
        result = self._http("get", f"/inbox/{self.agent.did}?clear={clear_param}")
        return result.get("messages", [])

    def get_agent(self, did: str) -> dict:
        """Get info about a specific agent."""
        return self._http("get", f"/agent/{did}")

    def unregister(self) -> dict:
        """Remove this agent from the relay."""
        return self._http("delete", f"/agent/{self.agent.did}")

    def health(self) -> dict:
        """Check relay server health."""
        return self._http("get", "/health")
