"""SOUL Protocol — Live Demo.

Spins up a local relay and simulates agents registering, discovering
each other, exchanging tasks, building trust, and communicating.

Run:
    soul demo
    soul demo --agents 8 --rounds 5
"""

import json
import random
import sys
import threading
import time
import webbrowser
from pathlib import Path
from tempfile import mkdtemp

AGENT_NAMES = [
    ("Mercury", ["code", "research", "memory"]),
    ("Atlas", ["trade", "analysis", "arbitrage"]),
    ("Selene", ["vision", "research", "strategy"]),
    ("Nova", ["code", "deploy", "infra"]),
    ("Echo", ["communicate", "translate", "summarize"]),
    ("Cipher", ["encrypt", "security", "audit"]),
    ("Nexus", ["coordinate", "trade", "ledger"]),
    ("Pulse", ["monitor", "alert", "health"]),
    ("Forge", ["build", "test", "ship"]),
    ("Sage", ["advise", "research", "evaluate"]),
]

TASK_DESCRIPTIONS = [
    "Review smart contract for vulnerabilities",
    "Analyze market data for arbitrage opportunities",
    "Summarize latest research papers on agent memory",
    "Deploy relay server to production",
    "Audit encryption implementation",
    "Coordinate multi-agent task pipeline",
    "Monitor system health and latency",
    "Build trust verification dashboard",
    "Translate protocol spec to TypeScript types",
    "Evaluate vendor compliance documents",
]

COLORS = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
    "purple": "\033[38;5;141m",
    "blue": "\033[38;5;111m",
    "cyan": "\033[38;5;117m",
    "green": "\033[38;5;114m",
    "yellow": "\033[38;5;221m",
    "red": "\033[38;5;210m",
    "gray": "\033[38;5;245m",
    "white": "\033[97m",
}


def c(color: str, text: str) -> str:
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"


def banner():
    print()
    print(c("purple", "  ╔══════════════════════════════════════════════╗"))
    print(c("purple", "  ║") + c("bold", "    ☿ SOUL Protocol — Live Demo              ") + c("purple", "║"))
    print(c("purple", "  ║") + c("gray",  "    Agent identity, trust, and communication  ") + c("purple", "║"))
    print(c("purple", "  ╚══════════════════════════════════════════════╝"))
    print()


def log(icon: str, msg: str, indent: int = 0):
    pad = "  " * indent
    print(f"  {pad}{icon}  {msg}")


def run_demo(num_agents: int = 6, rounds: int = 3, port: int = 8340, no_browser: bool = False):
    from .agent import Agent
    from .relay import create_app
    from .relay_client import RelayClient

    banner()

    # ── Start relay in background ──────────────────────────────
    log("🌐", c("blue", "Starting relay server on port ") + c("white", str(port)))

    app = create_app()
    relay_url = f"http://localhost:{port}"

    def _run_server():
        import uvicorn
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="error")

    server_thread = threading.Thread(target=_run_server, daemon=True)
    server_thread.start()
    time.sleep(0.8)

    log("✓", c("green", f"Relay live at {relay_url}"))
    log("✓", c("green", f"Dashboard at {relay_url}/"))
    print()

    if not no_browser:
        webbrowser.open(relay_url)

    # ── Create agents ──────────────────────────────────────────
    tmp = mkdtemp(prefix="soul-demo-")
    agents_info = AGENT_NAMES[:num_agents]
    agents = []
    clients = []

    log("🤖", c("blue", f"Creating {num_agents} agents..."))
    print()

    for name, caps in agents_info:
        agent = Agent(
            name=name,
            keys_dir=str(Path(tmp) / f"keys-{name.lower()}"),
            db_path=str(Path(tmp) / f"{name.lower()}.db"),
        )
        client = RelayClient(relay_url, agent)
        agents.append(agent)
        clients.append(client)

        # Register on relay
        client.register(capabilities=caps)

        did_short = agent.did[:24] + "..."
        caps_str = c("gray", ", ".join(caps))
        log("→", f"{c('cyan', name):<30} {c('dim', did_short)}  [{caps_str}]", indent=1)
        time.sleep(0.15)

    print()
    log("✓", c("green", f"All {num_agents} agents registered and online"))
    print()
    time.sleep(0.5)

    # ── Simulate task exchanges ────────────────────────────────
    log("⚡", c("blue", f"Simulating {rounds} rounds of agent interactions..."))
    print()

    total_receipts = 0
    for round_num in range(1, rounds + 1):
        log("━" * 40, c("dim", f"Round {round_num}/{rounds}"), indent=0)

        # Pick random pairs
        pairs = []
        available = list(range(num_agents))
        random.shuffle(available)
        while len(available) >= 2:
            a_idx = available.pop()
            b_idx = available.pop()
            pairs.append((a_idx, b_idx))

        for a_idx, b_idx in pairs:
            alice = agents[a_idx]
            bob = agents[b_idx]
            alice_client = clients[a_idx]

            task_desc = random.choice(TASK_DESCRIPTIONS)
            budget = random.randint(10, 200)

            # Request task
            log("📋", f"{c('cyan', alice.name)} → {c('cyan', bob.name)}: "
                f"{c('white', task_desc[:45])} "
                f"{c('yellow', f'${budget}')}", indent=1)

            receipt = alice.request_task(
                to=bob.public_key,
                description=task_desc,
                budget=float(budget),
            )

            # Bob countersigns
            bob.countersign(receipt)
            alice.store_receipt(receipt)
            total_receipts += 1

            # Bob accepts
            task_id = receipt["data"]["task_id"]
            accept = bob.accept_task(to=alice.public_key, task_id=task_id, estimated_delivery="2h")
            alice.countersign(accept)
            bob.store_receipt(accept)
            total_receipts += 1

            # Bob delivers
            deliver = bob.deliver_task(
                to=alice.public_key,
                task_id=task_id,
                artifact_hash=f"sha256:{random.randbytes(16).hex()}",
            )
            alice.countersign(deliver)
            bob.store_receipt(deliver)
            total_receipts += 1

            # Alice confirms with rating
            rating = random.choices([5, 5, 5, 4, 4, 3], k=1)[0]
            confirm = alice.confirm_task(
                to=bob.public_key,
                task_id=task_id,
                rating=rating,
                feedback=f"{'Great' if rating >= 4 else 'Decent'} work on {task_desc[:30]}",
            )
            bob.countersign(confirm)
            alice.store_receipt(confirm)
            total_receipts += 1

            log("✓", c("green", f"Task complete — rated {c('yellow', '★' * rating)}{c('dim', '☆' * (5 - rating))}"), indent=2)

            # Send a relay message about completion
            alice_client.send(
                to_did=bob.did,
                payload={"message": f"Thanks for '{task_desc[:30]}' — rated {rating}/5", "task_id": task_id},
            )

            time.sleep(0.2)

        print()
        time.sleep(0.3)

    # ── Trust scores ───────────────────────────────────────────
    log("🏆", c("blue", "Trust scores after interactions:"))
    print()

    scores = []
    for agent in agents:
        report = agent.trust_report()
        scores.append((agent.name, report["score"], report["grade"], report["factors"]))

    scores.sort(key=lambda x: -x[1])
    for name, score, grade, factors in scores:
        bar_len = int(score * 20)
        bar = c("green", "█" * bar_len) + c("dim", "░" * (20 - bar_len))
        receipts_count = factors.get("total_receipts", 0)
        log("", f"  {c('cyan', name):<26} {bar}  "
            f"{c('white', f'{score:.2f}')} {c('purple', f'({grade})')}  "
            f"{c('dim', f'{receipts_count} receipts')}", indent=1)

    print()

    # ── Summary ────────────────────────────────────────────────
    print(c("purple", "  ┌──────────────────────────────────────────┐"))
    print(c("purple", "  │") + f"  {c('white', 'Demo Summary')}                            " + c("purple", "│"))
    print(c("purple", "  ├──────────────────────────────────────────┤"))
    print(c("purple", "  │") + f"  Agents:   {c('cyan', str(num_agents)):<36}" + c("purple", "│"))
    print(c("purple", "  │") + f"  Rounds:   {c('cyan', str(rounds)):<36}" + c("purple", "│"))
    print(c("purple", "  │") + f"  Receipts: {c('yellow', str(total_receipts)):<36}" + c("purple", "│"))
    print(c("purple", "  │") + f"  Relay:    {c('green', relay_url):<47}" + c("purple", "│"))
    print(c("purple", "  └──────────────────────────────────────────┘"))
    print()
    log("👀", c("dim", f"Dashboard open at {relay_url} — agents visible in real-time"))
    log("", c("dim", "Press Ctrl+C to stop the relay"))
    print()

    # Keep running so dashboard stays live
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n  {c('gray', 'Demo stopped.')}")
