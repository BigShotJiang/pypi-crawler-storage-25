"""SOUL Protocol — Local SQLite-backed receipt ledger."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List

from .identity import canonical_json, sign
from .receipts import Receipt


JsonDict = Dict[str, Any]


class Ledger:
    """SQLite-backed local storage for receipts and activity logs."""

    def __init__(self, path: str = "soul.db") -> None:
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_db()

    def _init_db(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                data_json TEXT NOT NULL,
                task_id TEXT,
                parent_receipt_hash TEXT,
                agent_a_pubkey TEXT NOT NULL,
                agent_a_signature TEXT NOT NULL,
                agent_b_pubkey TEXT NOT NULL,
                agent_b_signature TEXT NOT NULL,
                proof_hash TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_receipts_a ON receipts(agent_a_pubkey);
            CREATE INDEX IF NOT EXISTS idx_receipts_b ON receipts(agent_b_pubkey);
            CREATE INDEX IF NOT EXISTS idx_receipts_task ON receipts(task_id);
            CREATE INDEX IF NOT EXISTS idx_receipts_ts ON receipts(timestamp);
        """)
        self._conn.commit()

    def store_receipt(self, receipt: JsonDict) -> JsonDict:
        """Store a dual-signed receipt. Returns the stored record with id."""
        required = [
            "timestamp", "event_type", "data", "agent_a_pubkey",
            "agent_a_signature", "agent_b_pubkey", "agent_b_signature",
        ]
        missing = [f for f in required if f not in receipt]
        if missing:
            raise ValueError(f"Receipt missing: {', '.join(missing)}")

        data = receipt["data"]
        if not isinstance(data, dict):
            raise ValueError("receipt['data'] must be a dict")

        proof = receipt.get("proof_hash") or Receipt.proof_hash(receipt)
        task_id = str(data.get("task_id", "")).strip() or None
        parent_hash = str(receipt.get("parent_receipt_hash", ""))
        data_str = json.dumps(data, sort_keys=True, separators=(",", ":"))

        cur = self._conn.execute(
            """INSERT INTO receipts (
                timestamp, event_type, data_json, task_id, parent_receipt_hash,
                agent_a_pubkey, agent_a_signature, agent_b_pubkey, agent_b_signature, proof_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                str(receipt["timestamp"]), str(receipt["event_type"]), data_str,
                task_id, parent_hash,
                str(receipt["agent_a_pubkey"]), str(receipt["agent_a_signature"]),
                str(receipt["agent_b_pubkey"]), str(receipt["agent_b_signature"]),
                proof,
            ),
        )
        self._conn.commit()
        return {"id": cur.lastrowid, "proof_hash": proof, **receipt}

    def get_receipts(self, agent_pubkey: str | None = None) -> List[JsonDict]:
        """Get all receipts, optionally filtered by agent involvement."""
        if agent_pubkey:
            rows = self._conn.execute(
                "SELECT * FROM receipts WHERE agent_a_pubkey = ? OR agent_b_pubkey = ? ORDER BY id ASC",
                (agent_pubkey, agent_pubkey),
            ).fetchall()
        else:
            rows = self._conn.execute("SELECT * FROM receipts ORDER BY id ASC").fetchall()
        return [dict(r) for r in rows]

    def get_task_chain(self, task_id: str) -> List[JsonDict]:
        """Get all receipts for a specific task, ordered by creation."""
        rows = self._conn.execute(
            "SELECT * FROM receipts WHERE task_id = ? ORDER BY id ASC",
            (task_id.strip(),),
        ).fetchall()
        return [dict(r) for r in rows]

    def close(self) -> None:
        self._conn.close()
