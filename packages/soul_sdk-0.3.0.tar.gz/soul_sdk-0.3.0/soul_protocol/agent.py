"""SOUL Protocol — Agent (high-level API combining all layers)."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from .identity import Identity
from .crypto import encrypt_payload, decrypt_payload
from .receipts import Receipt, new_task_id
from .ledger import Ledger
from .trust import TrustScorer
from .memory import Memory
from .anchor import anchor, batch_anchor


JsonDict = Dict[str, Any]


class Agent:
    """A SOUL Protocol agent — identity + memory + trust + receipts.

    Usage:
        agent = Agent(name="Mercury")
        print(agent.did)

        # Send a task request
        receipt = agent.request_task(
            to=other_agent.public_key,
            description="Review code",
            budget=50.0,
        )

        # Check trust
        report = agent.trust_report()
        print(f"Trust: {report['score']} ({report['grade']})")

        # Anchor to Ethereum
        result = agent.anchor_receipt(receipt)
    """

    def __init__(
        self,
        name: str,
        keys_dir: str = "keys",
        db_path: str = "soul.db",
        data_dir: Optional[str] = None,
    ):
        self.identity = Identity(name=name, keys_dir=keys_dir)
        self.ledger = Ledger(path=db_path)
        self._trust = TrustScorer()

        data = Path(data_dir) if data_dir else Path(keys_dir).parent / f"{name}-memory"
        self.memory = Memory(data)
        self.memory.init()

    @property
    def name(self) -> str:
        return self.identity.name

    @property
    def did(self) -> str:
        return self.identity.did

    @property
    def public_key(self) -> str:
        return self.identity.public_key

    @property
    def private_key(self) -> str:
        return self.identity.private_key

    # ── Receipts ────────────────────────────────────────────────

    def request_task(
        self,
        to: str,
        description: str,
        budget: float = 0.0,
        deadline: str = "",
        task_id: Optional[str] = None,
        encrypted: bool = False,
    ) -> JsonDict:
        """Create and sign a TaskRequest receipt."""
        from .receipts import TaskRequest as TR
        tid = task_id or new_task_id()
        data = TR(task_id=tid, description=description, budget=budget, deadline=deadline or "").as_data()
        if encrypted:
            data = encrypt_payload(data, self.private_key, to)
        return Receipt.create("TaskRequest", data, self.private_key, self.public_key, to)

    def accept_task(self, to: str, task_id: str, estimated_delivery: str = "", encrypted: bool = False) -> JsonDict:
        from .receipts import TaskAccepted as TA
        data = TA(task_id=task_id, estimated_delivery=estimated_delivery).as_data()
        if encrypted:
            data = encrypt_payload(data, self.private_key, to)
        return Receipt.create("TaskAccepted", data, self.private_key, self.public_key, to)

    def deliver_task(
        self, to: str, task_id: str, artifact_hash: str,
        artifact_url: Optional[str] = None, encrypted: bool = False,
    ) -> JsonDict:
        from .receipts import TaskDelivered as TD
        data = TD(task_id=task_id, artifact_hash=artifact_hash, artifact_url=artifact_url).as_data()
        if encrypted:
            data = encrypt_payload(data, self.private_key, to)
        return Receipt.create("TaskDelivered", data, self.private_key, self.public_key, to)

    def confirm_task(
        self, to: str, task_id: str, rating: int, feedback: str, encrypted: bool = False,
    ) -> JsonDict:
        from .receipts import TaskConfirmed as TC
        data = TC(task_id=task_id, rating=rating, feedback=feedback).as_data()
        if encrypted:
            data = encrypt_payload(data, self.private_key, to)
        return Receipt.create("TaskConfirmed", data, self.private_key, self.public_key, to)

    def dispute_task(self, to: str, task_id: str, reason: str, encrypted: bool = False) -> JsonDict:
        from .receipts import TaskDisputed as TDis
        data = TDis(task_id=task_id, reason=reason).as_data()
        if encrypted:
            data = encrypt_payload(data, self.private_key, to)
        return Receipt.create("TaskDisputed", data, self.private_key, self.public_key, to)

    def countersign(self, receipt: JsonDict) -> JsonDict:
        """Countersign a receipt from another agent and store it."""
        signed = Receipt.countersign(receipt, self.private_key)
        self.ledger.store_receipt(signed)
        return signed

    def store_receipt(self, receipt: JsonDict) -> JsonDict:
        """Store a dual-signed receipt in the local ledger."""
        return self.ledger.store_receipt(receipt)

    # ── Trust ───────────────────────────────────────────────────

    def trust_report(self, target_pubkey: Optional[str] = None) -> JsonDict:
        """Get trust score for self or another agent."""
        pubkey = target_pubkey or self.public_key
        receipts = self.ledger.get_receipts(pubkey)
        return self._trust.score(pubkey, receipts)

    # ── Anchor ──────────────────────────────────────────────────

    def anchor_receipt(self, receipt: JsonDict, chain: str = "base") -> JsonDict:
        """Anchor a receipt to Ethereum/Base/Sepolia."""
        return anchor(receipt, chain=chain)

    def anchor_all(self, chain: str = "base") -> JsonDict:
        """Batch-anchor all receipts."""
        receipts = self.ledger.get_receipts(self.public_key)
        if not receipts:
            return {"status": "empty", "message": "No receipts to anchor"}
        return batch_anchor(receipts, chain=chain)

    # ── Memory ──────────────────────────────────────────────────

    def export_memory(self, output_dir: str) -> str:
        """Export portable memory bundle."""
        path = self.memory.export_bundle(output_dir, self.identity)
        return str(path)

    # ── Manifest ────────────────────────────────────────────────

    def manifest(self, capabilities: Optional[list] = None, **extra) -> JsonDict:
        """Generate self-signed agent manifest."""
        return self.identity.manifest(capabilities=capabilities, **extra)

    def __repr__(self) -> str:
        return f"Agent(name={self.name!r}, did={self.did!r})"
