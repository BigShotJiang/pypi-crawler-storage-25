"""SOUL Protocol — Ethereum receipt anchoring (Base/mainnet/Sepolia)."""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, List, Optional
from urllib import request
from urllib.error import URLError

from .identity import canonical_json


CHAINS = {
    "base": {"rpc": "https://mainnet.base.org", "chain_id": 8453, "explorer": "https://basescan.org"},
    "ethereum": {"rpc": "https://ethereum-rpc.publicnode.com", "chain_id": 1, "explorer": "https://etherscan.io"},
    "sepolia": {"rpc": "https://ethereum-sepolia-rpc.publicnode.com", "chain_id": 11155111, "explorer": "https://sepolia.etherscan.io"},
}


class AnchorError(RuntimeError):
    pass


def receipt_hash(receipt: Dict[str, Any]) -> str:
    """SHA-256 hash of a receipt for on-chain anchoring."""
    payload = {
        "timestamp": str(receipt.get("timestamp", "")),
        "event_type": str(receipt.get("event_type", "")),
        "data": receipt.get("data", {}),
        "agent_a_pubkey": str(receipt.get("agent_a_pubkey", "")),
        "agent_b_pubkey": str(receipt.get("agent_b_pubkey", "")),
        "agent_a_signature": str(receipt.get("agent_a_signature", "")),
        "agent_b_signature": str(receipt.get("agent_b_signature", "")),
        "parent_receipt_hash": str(receipt.get("parent_receipt_hash", "")),
    }
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def _rpc(url: str, method: str, params: list) -> Any:
    body = json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}).encode()
    req = request.Request(url, data=body, headers={"Content-Type": "application/json"})
    try:
        with request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
            if "error" in result:
                raise AnchorError(f"RPC error: {result['error']}")
            return result.get("result")
    except URLError as e:
        raise AnchorError(f"RPC connection failed: {e}") from e


def anchor(
    receipt: Dict[str, Any],
    *,
    private_key: Optional[str] = None,
    chain: str = "base",
) -> Dict[str, Any]:
    """Anchor a receipt hash to Ethereum/Base/Sepolia.

    Sends a self-transfer (value=0) with the receipt hash in calldata.
    Falls back to local proof if no private key is provided.
    """
    key = private_key or os.getenv("SOUL_ETH_PRIVATE_KEY", "")
    proof = receipt_hash(receipt)

    if not key:
        return {
            "status": "local_only",
            "receipt_hash": proof,
            "message": "No ETH key — proof generated locally. Set SOUL_ETH_PRIVATE_KEY to anchor on-chain.",
        }

    try:
        from eth_account import Account
    except ImportError:
        raise AnchorError("Install ethereum support: pip install 'soul-protocol[ethereum]'") from None

    chain_info = CHAINS.get(chain, CHAINS["base"])
    rpc_url = chain_info["rpc"]
    calldata = "0x" + proof.encode("utf-8").hex()

    account = Account.from_key(key if key.startswith("0x") else f"0x{key}")
    sender = account.address

    nonce = int(_rpc(rpc_url, "eth_getTransactionCount", [sender, "latest"]), 16)
    gas_price = int(_rpc(rpc_url, "eth_gasPrice", []), 16)

    tx = {
        "nonce": nonce,
        "to": sender,
        "value": 0,
        "gas": 50000,
        "gasPrice": gas_price,
        "data": calldata,
        "chainId": chain_info["chain_id"],
    }

    signed = account.sign_transaction(tx)
    raw_tx = "0x" + signed.raw_transaction.hex()
    tx_hash = _rpc(rpc_url, "eth_sendRawTransaction", [raw_tx])

    return {
        "status": "anchored",
        "receipt_hash": proof,
        "tx_hash": tx_hash,
        "chain": chain,
        "explorer_url": f"{chain_info['explorer']}/tx/{tx_hash}",
        "sender": sender,
    }


def verify_hash(receipt: Dict[str, Any], expected: str) -> bool:
    """Verify a receipt matches its expected hash."""
    return receipt_hash(receipt) == expected.strip().lower()


def batch_anchor(receipts: List[Dict[str, Any]], **kwargs) -> Dict[str, Any]:
    """Anchor multiple receipts in a single transaction."""
    if not receipts:
        raise AnchorError("No receipts to anchor")
    hashes = [receipt_hash(r) for r in receipts]
    combined = hashlib.sha256("|".join(hashes).encode()).hexdigest()
    batch = {
        "timestamp": receipts[-1].get("timestamp", ""),
        "event_type": "batch_anchor",
        "data": {"receipt_count": len(receipts), "combined_hash": combined, "individual_hashes": hashes},
        "agent_a_pubkey": receipts[0].get("agent_a_pubkey", ""),
        "agent_b_pubkey": receipts[0].get("agent_b_pubkey", ""),
        "agent_a_signature": "", "agent_b_signature": "",
        "parent_receipt_hash": "",
    }
    result = anchor(batch, **kwargs)
    result["batch_info"] = {"receipt_count": len(receipts), "combined_hash": combined, "individual_hashes": hashes}
    return result
