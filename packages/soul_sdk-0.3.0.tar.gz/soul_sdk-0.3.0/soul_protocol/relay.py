"""SOUL Protocol — Relay Server (FastAPI + WebSocket).

Reference implementation for agent-to-agent communication.
Agents register with their DID and capabilities, discover each other,
and exchange signed (optionally encrypted) messages.

Run:
    soul relay --port 8340
    # or
    uvicorn soul_protocol.relay:app --port 8340
"""

import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .identity import verify, canonical_hash

JsonDict = Dict[str, Any]


def _ensure_fastapi():
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        raise ImportError(
            "Relay server requires: pip install soul-sdk[relay]\n"
            "  (installs fastapi + uvicorn)"
        )


# ── Pydantic Models (module-level for FastAPI compatibility) ───

_ensure_fastapi()

from pydantic import BaseModel


class RegisterRequest(BaseModel):
    did: str
    name: str
    public_key: str
    capabilities: List[str] = []
    endpoint: Optional[str] = None
    manifest_signature: str = ""


class MessageEnvelope(BaseModel):
    from_did: str
    to_did: str
    payload: dict
    signature: str
    timestamp: str = ""


DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SOUL Relay — Agent Network</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Inter',system-ui,-apple-system,sans-serif;background:#0a0e1a;color:#e2e8f0;min-height:100vh}
  .header{padding:2rem 2rem 1rem;border-bottom:1px solid rgba(99,102,241,0.15)}
  .header h1{font-size:1.5rem;font-weight:700;letter-spacing:-0.5px;background:linear-gradient(135deg,#818cf8,#c084fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
  .header .sub{color:#94a3b8;font-size:.85rem;margin-top:.25rem}
  .stats{display:flex;gap:1rem;padding:1.5rem 2rem;flex-wrap:wrap}
  .stat{background:rgba(30,41,59,0.6);border:1px solid rgba(99,102,241,0.12);border-radius:12px;padding:1rem 1.5rem;min-width:140px}
  .stat .num{font-size:1.75rem;font-weight:700;color:#818cf8}
  .stat .label{font-size:.75rem;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-top:.25rem}
  .grid{padding:1.5rem 2rem;display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1rem}
  .agent{background:rgba(30,41,59,0.5);border:1px solid rgba(99,102,241,0.1);border-radius:12px;padding:1.25rem;transition:border-color .2s,transform .2s}
  .agent:hover{border-color:rgba(99,102,241,0.3);transform:translateY(-2px)}
  .agent .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem}
  .agent .name{font-weight:600;font-size:1.05rem}
  .dot{width:8px;height:8px;border-radius:50%;display:inline-block}
  .dot.on{background:#34d399;box-shadow:0 0 6px rgba(52,211,153,0.5)}
  .dot.off{background:#475569}
  .agent .did{font-size:.7rem;color:#64748b;font-family:monospace;word-break:break-all;margin-bottom:.75rem}
  .caps{display:flex;flex-wrap:wrap;gap:.35rem}
  .cap{background:rgba(99,102,241,0.12);color:#a5b4fc;font-size:.7rem;padding:.2rem .6rem;border-radius:6px;font-weight:500}
  .empty{text-align:center;padding:4rem 2rem;color:#475569}
  .empty h2{font-size:1.2rem;margin-bottom:.5rem;color:#64748b}
  .pulse{animation:pulse 2s ease-in-out infinite}
  @keyframes pulse{0%,100%{opacity:.6}50%{opacity:1}}
  .footer{text-align:center;padding:2rem;color:#334155;font-size:.75rem}
  .footer a{color:#818cf8;text-decoration:none}
</style>
</head>
<body>
<div class="header">
  <h1>☿ SOUL Protocol Relay</h1>
  <div class="sub">Agent-to-agent communication network</div>
</div>
<div class="stats" id="stats">
  <div class="stat"><div class="num" id="total">—</div><div class="label">Agents</div></div>
  <div class="stat"><div class="num" id="online">—</div><div class="label">Online</div></div>
  <div class="stat"><div class="num" id="messages">—</div><div class="label">Messages</div></div>
</div>
<div class="grid" id="grid"></div>
<div class="empty" id="empty" style="display:none">
  <h2>No agents registered</h2>
  <p>Register an agent: <code style="color:#818cf8">soul discover --relay http://this-host:8340</code></p>
</div>
<div class="footer">Powered by <a href="https://pypi.org/project/soul-sdk/">SOUL Protocol</a> — built by Vickson Enterprises</div>
<script>
async function refresh(){
  try{
    const [hRes,dRes]=await Promise.all([fetch('/health'),fetch('/discover?limit=200')]);
    const health=await hRes.json(), disc=await dRes.json();
    document.getElementById('total').textContent=health.agents;
    document.getElementById('online').textContent=health.connections;
    document.getElementById('messages').textContent=disc.agents.reduce((s,a)=>s,0)||'0';
    const grid=document.getElementById('grid');
    const empty=document.getElementById('empty');
    if(!disc.agents.length){grid.innerHTML='';empty.style.display='block';return}
    empty.style.display='none';
    grid.innerHTML=disc.agents.map(a=>`
      <div class="agent">
        <div class="top">
          <span class="name">${esc(a.name)}</span>
          <span class="dot ${a.online?'on':'off'}" title="${a.online?'Online':'Offline'}"></span>
        </div>
        <div class="did">${esc(a.did)}</div>
        <div class="caps">${(a.capabilities||[]).map(c=>`<span class="cap">${esc(c)}</span>`).join('')||'<span style="color:#475569;font-size:.7rem">No capabilities listed</span>'}</div>
      </div>
    `).join('');
  }catch(e){console.error(e)}
}
function esc(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML}
refresh();setInterval(refresh,3000);
</script>
</body>
</html>"""


def create_app():
    """Create and return the FastAPI relay application."""
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import HTMLResponse

    app = FastAPI(
        title="SOUL Protocol Relay",
        description="Agent-to-agent communication relay with discovery and trust filtering",
        version="0.1.0",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── In-Memory Stores ───────────────────────────────────────
    registry: Dict[str, JsonDict] = {}
    inboxes: Dict[str, List[JsonDict]] = defaultdict(list)
    ws_connections: Dict[str, WebSocket] = {}
    heartbeats: Dict[str, float] = {}

    # ── Routes ─────────────────────────────────────────────────

    @app.get("/", response_class=HTMLResponse)
    async def dashboard():
        return DASHBOARD_HTML

    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "agents": len(registry),
            "connections": len(ws_connections),
        }

    @app.post("/register")
    async def register(req: RegisterRequest):
        if req.manifest_signature:
            manifest_data = {
                "did": req.did,
                "name": req.name,
                "public_key": req.public_key,
                "capabilities": req.capabilities,
            }
            if not verify(req.public_key, manifest_data, req.manifest_signature):
                raise HTTPException(400, "Invalid manifest signature")

        registry[req.did] = {
            "did": req.did,
            "name": req.name,
            "public_key": req.public_key,
            "capabilities": req.capabilities,
            "endpoint": req.endpoint,
            "registered_at": datetime.now(timezone.utc).isoformat(),
            "online": req.did in ws_connections,
        }
        heartbeats[req.did] = time.time()
        return {"status": "registered", "did": req.did, "agents_online": len(ws_connections)}

    @app.get("/discover")
    async def discover(capability: str = None, min_trust: float = None, limit: int = 50):
        results = list(registry.values())
        if capability:
            results = [a for a in results if capability in a.get("capabilities", [])]
        if min_trust is not None:
            results = [a for a in results if a.get("online", False)]
        for agent in results:
            agent["online"] = agent["did"] in ws_connections
        results.sort(key=lambda a: (not a.get("online"), a.get("registered_at", "")))
        return {"agents": results[:limit], "total": len(results)}

    @app.get("/agent/{did:path}")
    async def get_agent(did: str):
        if did not in registry:
            raise HTTPException(404, f"Agent {did} not found")
        agent = registry[did]
        agent["online"] = did in ws_connections
        return agent

    @app.post("/send")
    async def send_message(msg: MessageEnvelope):
        if msg.from_did not in registry:
            raise HTTPException(403, "Sender not registered")
        sender = registry[msg.from_did]
        if not verify(sender["public_key"], msg.payload, msg.signature):
            raise HTTPException(400, "Invalid message signature")

        envelope = {
            "from_did": msg.from_did,
            "from_name": sender.get("name", ""),
            "to_did": msg.to_did,
            "payload": msg.payload,
            "signature": msg.signature,
            "timestamp": msg.timestamp or datetime.now(timezone.utc).isoformat(),
            "payload_hash": canonical_hash(msg.payload),
        }

        if msg.to_did in ws_connections:
            try:
                await ws_connections[msg.to_did].send_json(envelope)
                return {"status": "delivered", "method": "websocket"}
            except Exception:
                ws_connections.pop(msg.to_did, None)

        inboxes[msg.to_did].append(envelope)
        return {"status": "queued", "method": "inbox", "pending": len(inboxes[msg.to_did])}

    @app.get("/inbox/{did:path}")
    async def get_inbox(did: str, clear: bool = True):
        messages = list(inboxes.get(did, []))
        if clear and did in inboxes:
            inboxes[did].clear()
        return {"messages": messages, "count": len(messages)}

    @app.delete("/inbox/{did:path}")
    async def clear_inbox(did: str):
        count = len(inboxes.get(did, []))
        inboxes[did].clear()
        return {"cleared": count}

    @app.delete("/agent/{did:path}")
    async def unregister(did: str):
        registry.pop(did, None)
        inboxes.pop(did, None)
        heartbeats.pop(did, None)
        if did in ws_connections:
            try:
                await ws_connections[did].close()
            except Exception:
                pass
            ws_connections.pop(did, None)
        return {"status": "unregistered", "did": did}

    # ── WebSocket ──────────────────────────────────────────────

    @app.websocket("/ws/{did:path}")
    async def websocket_endpoint(websocket: WebSocket, did: str):
        if did not in registry:
            await websocket.close(code=4001, reason="Agent not registered")
            return

        await websocket.accept()
        ws_connections[did] = websocket
        heartbeats[did] = time.time()

        if did in registry:
            registry[did]["online"] = True

        # Flush pending inbox
        pending = list(inboxes.get(did, []))
        if pending:
            for msg in pending:
                await websocket.send_json(msg)
            inboxes[did].clear()

        try:
            while True:
                data = await websocket.receive_json()
                heartbeats[did] = time.time()

                if data.get("type") == "ping":
                    await websocket.send_json({"type": "pong", "ts": time.time()})
                    continue

                if data.get("type") == "message" and "to_did" in data:
                    to_did = data["to_did"]
                    envelope = {
                        "from_did": did,
                        "from_name": registry.get(did, {}).get("name", ""),
                        "to_did": to_did,
                        "payload": data.get("payload", {}),
                        "signature": data.get("signature", ""),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }

                    if to_did in ws_connections:
                        try:
                            await ws_connections[to_did].send_json(envelope)
                            await websocket.send_json({"type": "ack", "status": "delivered"})
                        except Exception:
                            ws_connections.pop(to_did, None)
                            inboxes[to_did].append(envelope)
                            await websocket.send_json({"type": "ack", "status": "queued"})
                    else:
                        inboxes[to_did].append(envelope)
                        await websocket.send_json({"type": "ack", "status": "queued"})

        except WebSocketDisconnect:
            pass
        finally:
            ws_connections.pop(did, None)
            if did in registry:
                registry[did]["online"] = False

    return app


def run_relay(host: str = "0.0.0.0", port: int = 8340):
    """Start the relay server."""
    import uvicorn
    app = create_app()
    print(f"SOUL Relay starting on {host}:{port}")
    print(f"  Register:  POST http://{host}:{port}/register")
    print(f"  Discover:  GET  http://{host}:{port}/discover")
    print(f"  Send:      POST http://{host}:{port}/send")
    print(f"  Inbox:     GET  http://{host}:{port}/inbox/{{did}}")
    print(f"  WebSocket: ws://{host}:{port}/ws/{{did}}")
    print()
    uvicorn.run(app, host=host, port=port)
