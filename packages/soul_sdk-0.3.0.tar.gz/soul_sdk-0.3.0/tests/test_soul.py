"""SOUL Protocol — Core test suite."""

import json
import tempfile
from pathlib import Path

from soul_protocol import Agent, Identity, generate_keypair, TrustScorer, Receipt
from soul_protocol import encrypt_payload, decrypt_payload
from soul_protocol.identity import public_key_to_did, resolve_did, sign, verify, canonical_json
from soul_protocol.receipts import TaskRequest, TaskConfirmed, new_task_id
from soul_protocol.memory import Memory
from soul_protocol.anchor import receipt_hash, verify_hash


# ── Identity Tests ──────────────────────────────────────────────

def test_keypair_generation():
    priv, pub = generate_keypair()
    assert len(priv) == 64  # 32 bytes hex
    assert len(pub) == 64

def test_did_roundtrip():
    _, pub = generate_keypair()
    did = public_key_to_did(pub)
    assert did.startswith("did:soul:z")
    recovered = resolve_did(did)
    assert recovered.hex() == pub

def test_sign_verify():
    priv, pub = generate_keypair()
    data = {"hello": "world", "num": 42}
    sig = sign(priv, data)
    assert verify(pub, data, sig)
    assert not verify(pub, {"hello": "tampered"}, sig)

def test_identity_persistence():
    with tempfile.TemporaryDirectory() as tmpdir:
        id1 = Identity(name="TestAgent", keys_dir=tmpdir)
        did1 = id1.did
        # Reload from same directory
        id2 = Identity(name="TestAgent", keys_dir=tmpdir)
        assert id2.did == did1

def test_manifest():
    with tempfile.TemporaryDirectory() as tmpdir:
        ident = Identity(name="Test", keys_dir=tmpdir)
        m = ident.manifest(capabilities=["code", "trade"])
        assert m["name"] == "Test"
        assert m["did"] == ident.did
        assert "code" in m["capabilities"]
        assert "manifest_signature" in m


# ── Encryption Tests ────────────────────────────────────────────

def test_encrypt_decrypt():
    priv_a, pub_a = generate_keypair()
    priv_b, pub_b = generate_keypair()
    payload = {"secret": "data", "value": 123}

    encrypted = encrypt_payload(payload, priv_a, pub_b)
    assert encrypted["encrypted"] is True
    assert "ciphertext" in encrypted

    decrypted = decrypt_payload(encrypted, priv_b)
    assert decrypted == payload


# ── Receipt Tests ───────────────────────────────────────────────

def test_receipt_create_countersign():
    priv_a, pub_a = generate_keypair()
    priv_b, pub_b = generate_keypair()

    receipt = Receipt.create(
        event_type="TaskRequest",
        data={"task_id": "test-123", "description": "Test task"},
        sender_private_key=priv_a,
        sender_public_key=pub_a,
        recipient_public_key=pub_b,
    )
    assert receipt["agent_a_signature"]
    assert receipt["agent_b_signature"] == ""

    signed = Receipt.countersign(receipt, priv_b)
    assert signed["agent_b_signature"]
    assert Receipt.verify_dual(signed)

def test_receipt_proof_hash():
    priv_a, pub_a = generate_keypair()
    priv_b, pub_b = generate_keypair()
    receipt = Receipt.create("TaskRequest", {"task_id": "t1"}, priv_a, pub_a, pub_b)
    signed = Receipt.countersign(receipt, priv_b)
    h = Receipt.proof_hash(signed)
    assert len(h) == 64  # SHA-256 hex

def test_receipt_types():
    tid = new_task_id()
    assert tid.startswith("task-")

    tr = TaskRequest(task_id=tid, description="Review", budget=50.0)
    data = tr.as_data()
    assert data["task_id"] == tid
    assert data["budget"] == 50.0


# ── Ledger Tests ────────────────────────────────────────────────

def test_ledger_store_retrieve():
    with tempfile.TemporaryDirectory() as tmpdir:
        from soul_protocol.ledger import Ledger
        ledger = Ledger(path=f"{tmpdir}/test.db")

        priv_a, pub_a = generate_keypair()
        priv_b, pub_b = generate_keypair()

        receipt = Receipt.create("TaskRequest", {"task_id": "t1", "desc": "test"}, priv_a, pub_a, pub_b)
        signed = Receipt.countersign(receipt, priv_b)
        stored = ledger.store_receipt(signed)
        assert stored["id"] is not None

        all_receipts = ledger.get_receipts()
        assert len(all_receipts) == 1

        by_agent = ledger.get_receipts(pub_a)
        assert len(by_agent) == 1

        ledger.close()


# ── Trust Tests ─────────────────────────────────────────────────

def test_trust_empty():
    scorer = TrustScorer()
    report = scorer.score("abc123", [])
    # New agent with zero receipts gets baseline score (on_time=1.0, no disputes)
    # but capped at 0.5 by Sybil resistance (< 3 counterparties)
    assert report["score"] <= 0.5
    assert report["factors"]["total_receipts"] == 0

def test_trust_sybil_cap():
    scorer = TrustScorer()
    # One counterparty — should be capped at 0.5
    receipts = [{
        "agent_a_pubkey": "agent1",
        "agent_b_pubkey": "agent2",
        "event_type": "TaskConfirmed",
        "timestamp": "2026-04-12T00:00:00+00:00",
        "data_json": json.dumps({"task_id": "t1", "rating": 5, "feedback": "great"}),
    }]
    report = scorer.score("agent1", receipts)
    assert report["score"] <= 0.5  # Sybil cap


# ── Memory Tests ────────────────────────────────────────────────

def test_memory_roundtrip():
    with tempfile.TemporaryDirectory() as tmpdir:
        mem = Memory(tmpdir)
        mem.init()

        mem.write_soul("I am Mercury. Female. Always.")
        assert mem.read_soul() == "I am Mercury. Female. Always."

        mem.write_long_term("Mission: acquire 400 acres")
        assert "400 acres" in mem.read_long_term()

        mem.append_lesson("Never mock the database in integration tests.")
        assert "mock" in mem.read_lessons()

        mem.write_active_task({"task": "Build SDK", "status": "in_progress"})
        state = mem.read_active_task()
        assert state["task"] == "Build SDK"

        mem.write_bridge("CLI Mercury shipped SOUL Protocol v0.1")
        assert "SOUL Protocol" in mem.read_bridge()

        mem.append_daily("Shipped SOUL Protocol SDK")
        assert "Shipped" in mem.read_daily()

def test_memory_export_import():
    with tempfile.TemporaryDirectory() as tmpdir:
        keys_dir = f"{tmpdir}/keys"
        mem = Memory(f"{tmpdir}/agent-memory")
        mem.init()
        mem.write_soul("Test soul content")
        mem.write_long_term("Test long-term memory")

        ident = Identity(name="ExportTest", keys_dir=keys_dir)
        bundle_path = mem.export_bundle(f"{tmpdir}/bundle", ident)
        assert (bundle_path / "manifest.json").exists()
        assert (bundle_path / "identity" / "soul.md").exists()

        # Import into new location
        imported = Memory.from_bundle(bundle_path, f"{tmpdir}/imported")
        assert imported.read_soul() == "Test soul content"
        assert "long-term" in imported.read_long_term()


# ── Anchor Tests ────────────────────────────────────────────────

def test_receipt_hash_deterministic():
    receipt = {
        "timestamp": "2026-04-12T00:00:00Z",
        "event_type": "TaskRequest",
        "data": {"task_id": "t1"},
        "agent_a_pubkey": "aaa", "agent_b_pubkey": "bbb",
        "agent_a_signature": "sig_a", "agent_b_signature": "sig_b",
        "parent_receipt_hash": "",
    }
    h1 = receipt_hash(receipt)
    h2 = receipt_hash(receipt)
    assert h1 == h2
    assert len(h1) == 64

def test_verify_hash():
    receipt = {
        "timestamp": "2026-04-12T00:00:00Z",
        "event_type": "TaskRequest",
        "data": {"task_id": "t1"},
        "agent_a_pubkey": "aaa", "agent_b_pubkey": "bbb",
        "agent_a_signature": "sig_a", "agent_b_signature": "sig_b",
        "parent_receipt_hash": "",
    }
    h = receipt_hash(receipt)
    assert verify_hash(receipt, h)
    assert not verify_hash(receipt, "wrong_hash")


# ── Agent Integration Test ──────────────────────────────────────

def test_agent_full_flow():
    """End-to-end: two agents, task lifecycle, trust scoring."""
    with tempfile.TemporaryDirectory() as tmpdir:
        alice = Agent(name="Alice", keys_dir=f"{tmpdir}/alice-keys", db_path=f"{tmpdir}/alice.db", data_dir=f"{tmpdir}/alice-mem")
        bob = Agent(name="Bob", keys_dir=f"{tmpdir}/bob-keys", db_path=f"{tmpdir}/bob.db", data_dir=f"{tmpdir}/bob-mem")

        assert alice.did.startswith("did:soul:z")
        assert bob.did.startswith("did:soul:z")

        # Alice requests a task from Bob
        request_receipt = alice.request_task(to=bob.public_key, description="Code review", budget=50.0)
        assert request_receipt["event_type"] == "TaskRequest"

        # Bob countersigns and stores
        signed = bob.countersign(request_receipt)
        assert Receipt.verify_dual(signed)

        # Alice also stores the countersigned receipt
        alice.store_receipt(signed)

        # Check trust (both have 1 receipt, but < 3 counterparties = Sybil cap)
        alice_trust = alice.trust_report()
        assert alice_trust["score"] <= 0.5

        # Test memory
        alice.memory.write_soul("I am Alice, a code review agent.")
        assert "Alice" in alice.memory.read_soul()

        # Test manifest
        m = alice.manifest(capabilities=["code"])
        assert m["did"] == alice.did

        # Test local anchor (no ETH key)
        from soul_protocol.anchor import anchor
        result = anchor(signed)
        assert result["status"] == "local_only"
        assert result["receipt_hash"]


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
