"""Tests for SOUL Protocol relay server and client."""

import pytest
import threading
import time

# Skip all tests if fastapi/httpx not installed
fastapi = pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")

from fastapi.testclient import TestClient
from soul_protocol import Agent
from soul_protocol.relay import create_app
from soul_protocol.relay_client import RelayClient
from soul_protocol.identity import sign


@pytest.fixture
def app():
    return create_app()


@pytest.fixture
def client(app):
    return TestClient(app)


@pytest.fixture(autouse=True)
def tmp_workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def mercury(tmp_path):
    return Agent(name="Mercury", keys_dir=str(tmp_path / "keys-m"), db_path=str(tmp_path / "m.db"))


@pytest.fixture
def atlas(tmp_path):
    return Agent(name="Atlas", keys_dir=str(tmp_path / "keys-a"), db_path=str(tmp_path / "a.db"))


# ── Dashboard ─────────────────────────────────────────────────

def test_dashboard(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "SOUL Protocol Relay" in resp.text
    assert "text/html" in resp.headers["content-type"]


# ── Health ─────────────────────────────────────────────────────

def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert data["agents"] == 0


# ── Register ───────────────────────────────────────────────────

def test_register(client, mercury):
    manifest_data = {
        "did": mercury.did,
        "name": mercury.name,
        "public_key": mercury.public_key,
        "capabilities": ["code"],
    }
    sig = sign(mercury.private_key, manifest_data)

    resp = client.post("/register", json={
        "did": mercury.did,
        "name": "Mercury",
        "public_key": mercury.public_key,
        "capabilities": ["code"],
        "manifest_signature": sig,
    })
    assert resp.status_code == 200
    assert resp.json()["status"] == "registered"


def test_register_bad_signature(client, mercury):
    resp = client.post("/register", json={
        "did": mercury.did,
        "name": "Mercury",
        "public_key": mercury.public_key,
        "capabilities": ["code"],
        "manifest_signature": "deadbeef" * 16,
    })
    assert resp.status_code == 400


# ── Discover ───────────────────────────────────────────────────

def _register(client, agent, capabilities):
    manifest_data = {
        "did": agent.did,
        "name": agent.name,
        "public_key": agent.public_key,
        "capabilities": capabilities,
    }
    sig = sign(agent.private_key, manifest_data)
    client.post("/register", json={
        "did": agent.did,
        "name": agent.name,
        "public_key": agent.public_key,
        "capabilities": capabilities,
        "manifest_signature": sig,
    })


def test_discover_all(client, mercury, atlas):
    _register(client, mercury, ["code", "research"])
    _register(client, atlas, ["trade"])
    resp = client.get("/discover")
    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] == 2


def test_discover_by_capability(client, mercury, atlas):
    _register(client, mercury, ["code", "research"])
    _register(client, atlas, ["trade"])
    resp = client.get("/discover?capability=code")
    data = resp.json()
    assert data["total"] == 1
    assert data["agents"][0]["name"] == "Mercury"


# ── Get Agent ──────────────────────────────────────────────────

def test_get_agent(client, mercury):
    _register(client, mercury, ["code"])
    resp = client.get(f"/agent/{mercury.did}")
    assert resp.status_code == 200
    assert resp.json()["name"] == "Mercury"


def test_get_agent_not_found(client):
    resp = client.get("/agent/did:soul:zNOBODY")
    assert resp.status_code == 404


# ── Send + Inbox ───────────────────────────────────────────────

def test_send_and_inbox(client, mercury, atlas):
    _register(client, mercury, ["code"])
    _register(client, atlas, ["code"])

    payload = {"message": "hello atlas", "from_name": "Mercury"}
    sig = sign(mercury.private_key, payload)

    resp = client.post("/send", json={
        "from_did": mercury.did,
        "to_did": atlas.did,
        "payload": payload,
        "signature": sig,
    })
    assert resp.status_code == 200
    assert resp.json()["status"] == "queued"

    # Check Atlas's inbox
    resp = client.get(f"/inbox/{atlas.did}")
    assert resp.status_code == 200
    messages = resp.json()["messages"]
    assert len(messages) == 1
    assert messages[0]["payload"]["message"] == "hello atlas"

    # Inbox should be cleared
    resp = client.get(f"/inbox/{atlas.did}")
    assert resp.json()["count"] == 0


def test_send_unregistered_sender(client, mercury, atlas):
    _register(client, atlas, ["code"])
    payload = {"message": "hello"}
    sig = sign(mercury.private_key, payload)
    resp = client.post("/send", json={
        "from_did": mercury.did,
        "to_did": atlas.did,
        "payload": payload,
        "signature": sig,
    })
    assert resp.status_code == 403


def test_send_bad_signature(client, mercury, atlas):
    _register(client, mercury, ["code"])
    _register(client, atlas, ["code"])
    payload = {"message": "hello"}
    resp = client.post("/send", json={
        "from_did": mercury.did,
        "to_did": atlas.did,
        "payload": payload,
        "signature": "bad" * 21 + "b",
    })
    assert resp.status_code == 400


# ── Inbox Peek ─────────────────────────────────────────────────

def test_inbox_peek(client, mercury, atlas):
    _register(client, mercury, ["code"])
    _register(client, atlas, ["code"])

    payload = {"message": "persistent"}
    sig = sign(mercury.private_key, payload)
    client.post("/send", json={
        "from_did": mercury.did,
        "to_did": atlas.did,
        "payload": payload,
        "signature": sig,
    })

    # Peek — should NOT clear
    resp = client.get(f"/inbox/{atlas.did}?clear=false")
    assert resp.json()["count"] == 1

    # Still there
    resp = client.get(f"/inbox/{atlas.did}?clear=false")
    assert resp.json()["count"] == 1


# ── Unregister ─────────────────────────────────────────────────

def test_unregister(client, mercury):
    _register(client, mercury, ["code"])
    resp = client.delete(f"/agent/{mercury.did}")
    assert resp.status_code == 200

    resp = client.get(f"/agent/{mercury.did}")
    assert resp.status_code == 404


# ── WebSocket ──────────────────────────────────────────────────

def test_websocket_receive(client, mercury, atlas):
    _register(client, mercury, ["code"])
    _register(client, atlas, ["code"])

    with client.websocket_connect(f"/ws/{atlas.did}") as ws:
        # Send a message while Atlas is connected
        payload = {"message": "realtime hello"}
        sig = sign(mercury.private_key, payload)
        resp = client.post("/send", json={
            "from_did": mercury.did,
            "to_did": atlas.did,
            "payload": payload,
            "signature": sig,
        })
        assert resp.json()["status"] == "delivered"

        # Atlas should receive it via WebSocket
        data = ws.receive_json()
        assert data["payload"]["message"] == "realtime hello"
        assert data["from_did"] == mercury.did


def test_websocket_ping_pong(client, mercury):
    _register(client, mercury, ["code"])
    with client.websocket_connect(f"/ws/{mercury.did}") as ws:
        ws.send_json({"type": "ping"})
        data = ws.receive_json()
        assert data["type"] == "pong"


def test_websocket_unregistered(client):
    with pytest.raises(Exception):
        with client.websocket_connect("/ws/did:soul:zNOBODY") as ws:
            ws.receive_json()


def test_websocket_flushes_inbox(client, mercury, atlas):
    """Messages queued before WebSocket connect should flush on connect."""
    _register(client, mercury, ["code"])
    _register(client, atlas, ["code"])

    # Queue a message while Atlas is offline
    payload = {"message": "you were offline"}
    sig = sign(mercury.private_key, payload)
    client.post("/send", json={
        "from_did": mercury.did,
        "to_did": atlas.did,
        "payload": payload,
        "signature": sig,
    })

    # Atlas connects — should get the queued message
    with client.websocket_connect(f"/ws/{atlas.did}") as ws:
        data = ws.receive_json()
        assert data["payload"]["message"] == "you were offline"
