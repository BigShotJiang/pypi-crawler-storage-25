from typing import Optional, Union

from pydantic_core import PydanticUndefined, PydanticUndefinedType

from galtea.domain.exceptions.entity_not_found_exception import EntityNotFoundException
from galtea.domain.models.endpoint_connection import (
    BackoffStrategy,
    EndpointConnection,
    EndpointConnectionAuthType,
    EndpointConnectionBase,
    EndpointConnectionType,
    EndpointConnectionUpdate,
    HttpMethod,
    TestConnectionResult,
)
from galtea.infrastructure.clients.http_client import Client
from galtea.utils.sort_order import SortOrder, normalize_sort_order
from galtea.utils.string import build_query_params
from galtea.utils.timestamp import normalize_timestamp


class EndpointConnectionService:
    """
    Service for managing Endpoint Connections.
    An Endpoint Connection defines how to communicate with an external API endpoint
    for direct inference workflows.

    See https://docs.galtea.ai/concepts/product/endpoint-connection
    """

    def __init__(self, client: Client):
        self.__client = client

    def create(
        self,
        name: str,
        product_id: str,
        url: str,
        type: Union[str, EndpointConnectionType],
        http_method: Union[str, HttpMethod] = HttpMethod.POST,
        auth_type: Union[str, EndpointConnectionAuthType] = EndpointConnectionAuthType.BEARER,
        auth_token: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        headers: Optional[dict[str, str]] = None,
        input_template: Optional[str] = None,
        output_mapping: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
        rate_limit: Optional[int] = None,
        retry_enabled: Optional[bool] = None,
        retry_max_attempts: Optional[int] = None,
        retry_initial_delay_ms: Optional[int] = None,
        retry_backoff_strategy: Optional[Union[str, BackoffStrategy]] = None,
        retry_max_delay_ms: Optional[int] = None,
        retryable_status_codes: Optional[list[int]] = None,
    ) -> Optional[EndpointConnection]:
        """
        Create a new endpoint connection.

        Args:
            name (str): Name of the endpoint connection. Must be unique per product.
            product_id (str): ID of the product this connection belongs to.
            url (str): The endpoint URL (HTTPS only). For multi-step session lifecycles,
                the URL supports a ``{{ session_id }}`` placeholder for dynamic session IDs
                (e.g., ``https://api.example.com/v1/threads/{{ session_id }}/messages``).
                Only available when an INITIALIZATION endpoint connection returns a ``session_id``.
                See https://docs.galtea.ai/concepts/product/endpoint-connection#multi-step-session-lifecycle-advanced
            type (str | EndpointConnectionType): Type of endpoint connection.
                Valid values: INITIALIZATION, CONVERSATION, FINALIZATION.
                CONVERSATION is required for all products. INITIALIZATION and FINALIZATION
                are only needed for complex session management (e.g., when your API requires
                a separate setup call that returns a session ID, or a cleanup call after the
                conversation ends). See https://docs.galtea.ai/concepts/product/endpoint-connection#multi-step-session-lifecycle-advanced
            http_method (str | HttpMethod): HTTP method. Defaults to POST.
                Valid values: GET, POST, PUT, PATCH, DELETE.
            auth_type (str | EndpointConnectionAuthType): Authentication type. Defaults to BEARER.
                Valid values: NONE, BEARER, API_KEY, BASIC.
            auth_token (str, optional): Authentication token. Required for BEARER and API_KEY auth types.
            username (str, optional): Username for BASIC authentication.
            password (str, optional): Password for BASIC authentication.
            headers (dict[str, str], optional): Custom headers as key-value pairs.
                Supports credential placeholders (e.g., ``{{ bearer_token }}``, ``{{ api_key }}``).
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#custom-headers
            input_template (str, optional): Input template with Jinja2 placeholders.
                Required for CONVERSATION type. Must contain ``{{ input }}``.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#input-template
            output_mapping (dict[str, str], optional): Output mapping using JSONPath expressions.
                Required for INITIALIZATION (needs ``session_id``) and CONVERSATION (needs ``output``) types.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#output-mapping
            timeout (int, optional): Request timeout in seconds.
            rate_limit (int, optional): Maximum requests per minute.
            retry_enabled (bool, optional): Whether automatic retry is enabled. Defaults to false.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#retry-configuration
            retry_max_attempts (int, optional): Maximum retry attempts (0-10). Defaults to 3.
            retry_initial_delay_ms (int, optional): Initial delay in milliseconds before first retry.
                Defaults to 1000.
            retry_backoff_strategy (str | BackoffStrategy, optional): Backoff strategy.
                Valid values: FIXED, EXPONENTIAL, LINEAR.
            retry_max_delay_ms (int, optional): Maximum delay cap in milliseconds. Defaults to 30000.
            retryable_status_codes (list[int], optional): HTTP status codes that trigger retry.
                Defaults to [429, 500, 502, 503, 504].

        Returns:
            Optional[EndpointConnection]: The created endpoint connection, or None if an error occurs.
        """
        type = type.value if isinstance(type, EndpointConnectionType) else type
        http_method = http_method.value if isinstance(http_method, HttpMethod) else http_method
        auth_type = auth_type.value if isinstance(auth_type, EndpointConnectionAuthType) else auth_type
        retry_backoff_strategy = (
            retry_backoff_strategy.value
            if isinstance(retry_backoff_strategy, BackoffStrategy)
            else retry_backoff_strategy
        )

        try:
            endpoint_connection = EndpointConnectionBase(
                name=name,
                product_id=product_id,
                url=url,
                type=type,
                http_method=http_method,
                auth_type=auth_type,
                auth_token=auth_token,
                username=username,
                password=password,
                headers=headers,
                input_template=input_template,
                output_mapping=output_mapping,
                timeout=timeout,
                rate_limit=rate_limit,
                retry_enabled=retry_enabled,
                retry_max_attempts=retry_max_attempts,
                retry_initial_delay_ms=retry_initial_delay_ms,
                retry_backoff_strategy=retry_backoff_strategy,
                retry_max_delay_ms=retry_max_delay_ms,
                retryable_status_codes=retryable_status_codes,
            )

            endpoint_connection.model_validate(endpoint_connection.model_dump())
            response = self.__client.post(
                "endpointConnections",
                json=endpoint_connection.model_dump(by_alias=True, exclude_none=True),
            )
            return EndpointConnection(**response.json())
        except Exception as e:
            print(f"Error creating EndpointConnection: {e}")
            return None

    def get(self, endpoint_connection_id: str) -> EndpointConnection:
        """
        Retrieve an endpoint connection by its ID.

        Args:
            endpoint_connection_id (str): ID of the endpoint connection to retrieve.

        Returns:
            EndpointConnection: The retrieved endpoint connection object.
        """
        response = self.__client.get(f"endpointConnections/{endpoint_connection_id}")
        return EndpointConnection(**response.json())

    def get_by_name(self, name: str, product_id: str) -> EndpointConnection:
        """
        Retrieve an endpoint connection by its name within a product.

        Args:
            name (str): Name of the endpoint connection to retrieve.
            product_id (str): ID of the product the connection belongs to.

        Returns:
            EndpointConnection: The retrieved endpoint connection object.

        Raises:
            EntityNotFoundException: If no endpoint connection with the given name is found.
        """
        query_params = build_query_params(names=[name], productIds=[product_id])
        response = self.__client.get(f"endpointConnections?{query_params}")
        endpoint_connections = [EndpointConnection(**ec) for ec in response.json()]

        if not endpoint_connections:
            raise EntityNotFoundException(f"Endpoint connection with name {name} does not exist.")

        return endpoint_connections[0]

    def update(
        self,
        endpoint_connection_id: str,
        name: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        url: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        http_method: Union[str, HttpMethod, None, PydanticUndefinedType] = PydanticUndefined,
        auth_type: Union[str, EndpointConnectionAuthType, None, PydanticUndefinedType] = PydanticUndefined,
        auth_token: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        username: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        password: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        headers: Union[dict[str, str], None, PydanticUndefinedType] = PydanticUndefined,
        input_template: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        output_mapping: Union[dict[str, str], None, PydanticUndefinedType] = PydanticUndefined,
        timeout: Union[int, None, PydanticUndefinedType] = PydanticUndefined,
        rate_limit: Union[int, None, PydanticUndefinedType] = PydanticUndefined,
        retry_enabled: Union[bool, None, PydanticUndefinedType] = PydanticUndefined,
        retry_max_attempts: Union[int, None, PydanticUndefinedType] = PydanticUndefined,
        retry_initial_delay_ms: Union[int, None, PydanticUndefinedType] = PydanticUndefined,
        retry_backoff_strategy: Union[str, BackoffStrategy, None, PydanticUndefinedType] = PydanticUndefined,
        retry_max_delay_ms: Union[int, None, PydanticUndefinedType] = PydanticUndefined,
        retryable_status_codes: Union[list[int], None, PydanticUndefinedType] = PydanticUndefined,
    ) -> EndpointConnection:
        """
        Update an existing endpoint connection.

        Args:
            endpoint_connection_id (str): ID of the endpoint connection to update.
            name (str | None | Undefined): New name for the endpoint connection.
            url (str | None | Undefined): New endpoint URL. For multi-step session lifecycles,
                supports a ``{{ session_id }}`` placeholder (requires an INITIALIZATION endpoint).
            http_method (str | HttpMethod | None | Undefined): New HTTP method.
            auth_type (str | EndpointConnectionAuthType | None | Undefined): New authentication type.
            auth_token (str | None | Undefined): New authentication token.
            username (str | None | Undefined): New username for BASIC authentication.
            password (str | None | Undefined): New password for BASIC authentication.
            headers (dict[str, str] | None | Undefined): New custom headers.
                Supports credential placeholders (e.g., ``{{ bearer_token }}``, ``{{ api_key }}``).
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#custom-headers
            input_template (str | None | Undefined): New input template with Jinja2 placeholders.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#input-template
            output_mapping (dict[str, str] | None | Undefined): New output mapping using JSONPath expressions.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#output-mapping
            timeout (int | None | Undefined): New request timeout in seconds.
            rate_limit (int | None | Undefined): New maximum requests per minute.
            retry_enabled (bool | None | Undefined): Whether automatic retry is enabled.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#retry-configuration
            retry_max_attempts (int | None | Undefined): New maximum retry attempts.
            retry_initial_delay_ms (int | None | Undefined): New initial delay in milliseconds.
            retry_backoff_strategy (str | BackoffStrategy | None | Undefined): New backoff strategy.
            retry_max_delay_ms (int | None | Undefined): New maximum delay cap in milliseconds.
            retryable_status_codes (list[int] | None | Undefined): New retryable HTTP status codes.

        Returns:
            EndpointConnection: The updated endpoint connection object.

        Note:
            Pass PydanticUndefined (default) to exclude a field from the update.
            Pass None to explicitly set a field to null.
            Pass a value to update the field to that value.
        """
        # Normalize enum values to strings
        if isinstance(http_method, HttpMethod):
            http_method = http_method.value
        if isinstance(auth_type, EndpointConnectionAuthType):
            auth_type = auth_type.value
        if isinstance(retry_backoff_strategy, BackoffStrategy):
            retry_backoff_strategy = retry_backoff_strategy.value

        update_data = {
            "name": name,
            "url": url,
            "http_method": http_method,
            "auth_type": auth_type,
            "auth_token": auth_token,
            "username": username,
            "password": password,
            "headers": headers,
            "input_template": input_template,
            "output_mapping": output_mapping,
            "timeout": timeout,
            "rate_limit": rate_limit,
            "retry_enabled": retry_enabled,
            "retry_max_attempts": retry_max_attempts,
            "retry_initial_delay_ms": retry_initial_delay_ms,
            "retry_backoff_strategy": retry_backoff_strategy,
            "retry_max_delay_ms": retry_max_delay_ms,
            "retryable_status_codes": retryable_status_codes,
        }

        # Remove keys explicitly set to PydanticUndefined so they are not
        # considered 'set' by pydantic.
        filtered_data = {k: v for k, v in update_data.items() if v is not PydanticUndefined}

        update_model = EndpointConnectionUpdate(**filtered_data)
        payload = update_model.model_dump(by_alias=True, exclude_unset=True)

        response = self.__client.patch(f"endpointConnections/{endpoint_connection_id}", json=payload)
        return EndpointConnection(**response.json())

    def delete(self, endpoint_connection_id: str) -> None:
        """
        Delete an endpoint connection by its ID.

        Args:
            endpoint_connection_id (str): ID of the endpoint connection to delete.
        """
        self.__client.delete(f"endpointConnections/{endpoint_connection_id}")

    def list(
        self,
        product_ids: Optional[list[str]] = None,
        names: Optional[list[str]] = None,
        name: Optional[str] = None,
        url: Optional[str] = None,
        types: Optional[list[Union[str, EndpointConnectionType]]] = None,
        http_methods: Optional[list[Union[str, HttpMethod]]] = None,
        auth_types: Optional[list[Union[str, EndpointConnectionAuthType]]] = None,
        from_created_at: Optional[Union[str, int]] = None,
        to_created_at: Optional[Union[str, int]] = None,
        sort_by_created_at: Optional[Union[str, SortOrder]] = None,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> list[EndpointConnection]:
        """
        Get a list of endpoint connections.

        Args:
            product_ids (list[str], optional): Filter by product IDs.
            names (list[str], optional): Filter by exact endpoint connection names.
            name (str, optional): Filter by partial name match.
            url (str, optional): Filter by partial URL match.
            types (list[str | EndpointConnectionType], optional): Filter by endpoint connection types.
            http_methods (list[str | HttpMethod], optional): Filter by HTTP methods.
            auth_types (list[str | EndpointConnectionAuthType], optional): Filter by authentication types.
            from_created_at (str | int, optional): Filter connections created at or after this timestamp.
                Accepts ISO 8601 string (e.g., '2024-01-01T00:00:00Z') or Unix timestamp (seconds).
            to_created_at (str | int, optional): Filter connections created at or before this timestamp.
                Accepts ISO 8601 string (e.g., '2024-12-31T23:59:59Z') or Unix timestamp (seconds).
            sort_by_created_at (str | SortOrder, optional): Sort by created at. Valid values are 'asc' and 'desc'.
            offset (int, optional): Offset for pagination.
            limit (int, optional): Limit for pagination.

        Returns:
            list[EndpointConnection]: List of endpoint connections.
        """
        sort_by_created_at = normalize_sort_order(sort_by_created_at) if sort_by_created_at is not None else None

        from_created_at_normalized = normalize_timestamp(from_created_at)
        to_created_at_normalized = normalize_timestamp(to_created_at)

        # Normalize enum values in filter lists
        normalized_types = [t.value if isinstance(t, EndpointConnectionType) else t for t in types] if types else None
        normalized_http_methods = (
            [m.value if isinstance(m, HttpMethod) else m for m in http_methods] if http_methods else None
        )
        normalized_auth_types = (
            [a.value if isinstance(a, EndpointConnectionAuthType) else a for a in auth_types] if auth_types else None
        )

        query_params = build_query_params(
            productIds=product_ids,
            names=names,
            name=name,
            url=url,
            types=normalized_types,
            httpMethods=normalized_http_methods,
            authTypes=normalized_auth_types,
            fromCreatedAt=from_created_at_normalized,
            toCreatedAt=to_created_at_normalized,
            offset=offset,
            limit=limit,
            sort=["createdAt", sort_by_created_at] if sort_by_created_at else None,
        )
        response = self.__client.get(f"endpointConnections?{query_params}")
        return [EndpointConnection(**ec) for ec in response.json()]

    def test(
        self,
        id: Optional[str] = None,
        url: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        http_method: Union[str, HttpMethod, None, PydanticUndefinedType] = PydanticUndefined,
        input_template: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        auth_type: Union[str, EndpointConnectionAuthType, None, PydanticUndefinedType] = PydanticUndefined,
        auth_token: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        username: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        password: Union[str, None, PydanticUndefinedType] = PydanticUndefined,
        headers: Union[dict[str, str], None, PydanticUndefinedType] = PydanticUndefined,
        output_mapping: Union[dict[str, str], None, PydanticUndefinedType] = PydanticUndefined,
        type: Union[str, EndpointConnectionType, None, PydanticUndefinedType] = PydanticUndefined,
        timeout: Union[int, None, PydanticUndefinedType] = PydanticUndefined,
    ) -> TestConnectionResult:
        """
        Test an endpoint connection by making a sample request.

        Can be used in two modes:
        1. Without an ID: all connection fields are required (creation flow).
        2. With an ID: fetches the stored connection and applies any provided fields as overrides.

        See https://docs.galtea.ai/concepts/product/endpoint-connection

        Example:
            >>> # Test an existing connection
            >>> endpoint = galtea.endpoint_connections.create(...)
            >>> result = galtea.endpoint_connections.test(id=endpoint.id)

            >>> # Test before saving (creation flow)
            >>> result = galtea.endpoint_connections.test(
            ...     url="https://my-api.com/chat",
            ...     http_method=HttpMethod.POST,
            ...     auth_type=EndpointConnectionAuthType.BEARER,
            ...     auth_token="sk-...",
            ... )

        Args:
            id (str, optional): ID of an existing endpoint connection to test.
                When provided, stored connection data is used as base and remaining fields act as overrides.
            url (str | None | Undefined): The endpoint URL to test. For multi-step session lifecycles,
                supports a ``{{ session_id }}`` placeholder (requires an INITIALIZATION endpoint).
            http_method (str | HttpMethod | None | Undefined): HTTP method.
            input_template (str | None | Undefined): Input template with Jinja2 placeholders.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#input-template
            auth_type (str | EndpointConnectionAuthType | None | Undefined): Authentication type.
            auth_token (str | None | Undefined): Authentication token.
            username (str | None | Undefined): Username for BASIC authentication.
            password (str | None | Undefined): Password for BASIC authentication.
            headers (dict[str, str] | None | Undefined): Custom headers.
                Supports credential placeholders (e.g., ``{{ bearer_token }}``, ``{{ api_key }}``).
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#custom-headers
            output_mapping (dict[str, str] | None | Undefined): Output mapping using JSONPath expressions.
                See https://docs.galtea.ai/concepts/product/endpoint-connection-configuration#output-mapping
            type (str | EndpointConnectionType | None | Undefined): Endpoint connection type.
                CONVERSATION is required for all products. INITIALIZATION and FINALIZATION
                are only needed for complex session management.
            timeout (int | None | Undefined): Request timeout in seconds.

        Returns:
            TestConnectionResult: The test connection result including success status,
                status code, latency, response data, and any extraction results.

        Note:
            Pass PydanticUndefined (default) to exclude a field from the request.
            Pass None to explicitly send null (useful to override a stored value when testing with an ID).
            Pass a value to include it in the test request.
        """
        # Normalize enum values
        if isinstance(http_method, HttpMethod):
            http_method = http_method.value
        if isinstance(auth_type, EndpointConnectionAuthType):
            auth_type = auth_type.value
        if isinstance(type, EndpointConnectionType):
            type = type.value

        payload_data: dict[str, object] = {}
        if id is not None:
            payload_data["id"] = id

        override_data = {
            "url": url,
            "httpMethod": http_method,
            "inputTemplate": input_template,
            "authType": auth_type,
            "authToken": auth_token,
            "username": username,
            "password": password,
            "headers": headers,
            "outputMapping": output_mapping,
            "type": type,
            "timeout": timeout,
        }
        payload_data.update({k: v for k, v in override_data.items() if v is not PydanticUndefined})

        response = self.__client.post("endpointConnections/testConnection", json=payload_data)
        return TestConnectionResult(**response.json())
