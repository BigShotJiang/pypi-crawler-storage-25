from typing import Optional, Union

from galtea.application.services.product_service import ProductService
from galtea.domain.exceptions.entity_not_found_exception import EntityNotFoundException
from galtea.domain.models.version import Version, VersionBase
from galtea.infrastructure.clients.http_client import Client
from galtea.utils.sort_order import SortOrder, normalize_sort_order
from galtea.utils.string import build_query_params
from galtea.utils.timestamp import normalize_timestamp


class VersionService:
    """
    Service for managing Versions.
    A Version is a specific iteration of a product, allowing for tracking improvements and regressions over time.
    """

    def __init__(self, client: Client, product_service: ProductService):
        self.__client = client
        self.__product_service = product_service

    def create(
        self,
        product_id: str,
        name: str,
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
        model_id: Optional[str] = None,
        dataset_description: Optional[str] = None,
        dataset_uri: Optional[str] = None,
        endpoint_connection_id: Optional[str] = None,
        conversation_endpoint_connection_id: Optional[str] = None,
        initialization_endpoint_connection_id: Optional[str] = None,
        finalization_endpoint_connection_id: Optional[str] = None,
        guardrails: Optional[str] = None,
    ) -> Optional[Version]:
        """
        Create a new version for a product. A version represents a specific iteration of a product.

        Args:
            product_id (str): ID of the product to associate the version with.
            name (str): Name for the new version.
            description (str, optional): Version description.
            system_prompt (str, optional): System prompt used for the version.
            model_id (str, optional): Reference to a model configured in the Galtea Platform with cost information.
            dataset_description (str, optional): Description of the dataset used for training.
            dataset_uri (str, optional): URI to the dataset.
            conversation_endpoint_connection_id (str, optional): ID of the endpoint connection used for
                conversational interactions with your AI product.
            initialization_endpoint_connection_id (str, optional): ID of the endpoint connection executed
                before the conversation begins. Used to initialize a session and obtain a session ID.
            finalization_endpoint_connection_id (str, optional): ID of the endpoint connection executed
                after the conversation ends. Used to clean up resources.
            endpoint_connection_id (str, optional): Deprecated. Use conversation_endpoint_connection_id instead.
                ID of the conversation endpoint connection for API access. Maintained for backwards compatibility.
            guardrails (str, optional): Configuration for safety guardrails provided to the model.

        Returns:
            Optional[Version]: The created version object.
        """
        if endpoint_connection_id:
            import warnings

            warnings.warn(
                "endpoint_connection_id is deprecated and will be removed in a future version. "
                "Use conversation_endpoint_connection_id instead.",
                DeprecationWarning,
                stacklevel=2,
            )

        # Handle backwards compatibility: endpoint_connection_id maps to conversation_endpoint_connection_id
        effective_conversation_id: Optional[str] = conversation_endpoint_connection_id or endpoint_connection_id

        try:
            version = VersionBase(
                name=name,
                product_id=product_id,
                description=description,
                system_prompt=system_prompt,
                model_id=model_id,
                dataset_description=dataset_description,
                dataset_uri=dataset_uri,
                conversation_endpoint_connection_id=effective_conversation_id,
                initialization_endpoint_connection_id=initialization_endpoint_connection_id,
                finalization_endpoint_connection_id=finalization_endpoint_connection_id,
                guardrails=guardrails,
            )
            version.model_validate(version.model_dump())
            response = self.__client.post("versions", json=version.model_dump(by_alias=True))
            version_response = Version(**response.json())
            return version_response
        except Exception as e:
            print(f"Error creating version {name}: {e}")

    def get(self, version_id: str):
        """
        Retrieve a version by its ID.

        Args:
            version_id (str): ID of the version to retrieve.

        Returns:
            Version: The retrieved version object.
        """
        response = self.__client.get(f"versions/{version_id}")
        return Version(**response.json())

    def get_by_name(self, product_id: str, version_name: str):
        """
        Retrieve a version by its name and the product ID it is associated with.

        Args:
            product_id (str): ID of the product.
            version_name (str): Name of the version.

        Returns:
            Version: The retrieved version object.
        """
        query_params = build_query_params(productIds=[product_id], names=[version_name])
        response = self.__client.get(f"versions?{query_params}")
        versions = [Version(**version) for version in response.json()]

        if not versions:
            try:
                self.__product_service.get(product_id)
            except Exception:
                raise EntityNotFoundException(f"Product with ID {product_id} does not exist.")

        if not versions:
            raise EntityNotFoundException(f"Version with name {version_name} does not exist.")

        return versions[0]

    def list(
        self,
        product_id: Union[str, list[str]],
        from_created_at: Optional[Union[str, int]] = None,
        to_created_at: Optional[Union[str, int]] = None,
        sort_by_created_at: Optional[Union[str, SortOrder]] = None,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
    ):
        """
        Get a list of versions for a given product.

        Args:
            product_id (str | list[str]): ID or IDs of the product to retrieve versions from.
            from_created_at (str | int, optional): Filter versions created at or after this timestamp.
                Accepts ISO 8601 string (e.g., '2024-01-01T00:00:00Z') or Unix timestamp (seconds).
            to_created_at (str | int, optional): Filter versions created at or before this timestamp.
                Accepts ISO 8601 string (e.g., '2024-12-31T23:59:59Z') or Unix timestamp (seconds).
            sort_by_created_at (str | SortOrder, optional): Sort by created at. Valid values are 'asc' and 'desc'.
            offset (int, optional): Offset for pagination. This refers to the number of items to skip before
                starting to collect the result set. The default value is 0.
            limit (int, optional): Limit for pagination. This refers to the maximum number of items to collect
                in the result set.

        Returns:
            List[Version]: List of version objects.
        """
        # 1. Validate IDs filter parameters
        product_ids = [product_id] if isinstance(product_id, str) else product_id
        # 2. Validate sort parameters
        sort_by_created_at = normalize_sort_order(sort_by_created_at) if sort_by_created_at is not None else None

        # 3. Normalize date filter parameters
        from_created_at_normalized = normalize_timestamp(from_created_at)
        to_created_at_normalized = normalize_timestamp(to_created_at)

        query_params = build_query_params(
            productIds=product_ids,
            fromCreatedAt=from_created_at_normalized,
            toCreatedAt=to_created_at_normalized,
            offset=offset,
            limit=limit,
            sort=["createdAt", sort_by_created_at] if sort_by_created_at else None,
        )
        response = self.__client.get(f"versions?{query_params}")
        versions = [Version(**version) for version in response.json()]

        if not versions:
            for product_id in product_ids:
                try:
                    self.__product_service.get(product_id)
                except Exception:  # noqa: PERF203
                    raise EntityNotFoundException(f"Product with ID {product_id} does not exist.")

        return versions

    def delete(self, version_id: str):
        """
        Delete a version by its ID.

        Args:
            version_id (str): ID of the version to delete.

        Returns:
            None: None.
        """
        self.__client.delete(f"versions/{version_id}")
