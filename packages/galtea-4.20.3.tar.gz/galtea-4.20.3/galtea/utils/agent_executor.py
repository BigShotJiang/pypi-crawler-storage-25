"""
Agent executor utilities for calling agents with different interfaces.

This module provides low-level helpers for agent signature detection, async handling,
and response normalization. The high-level agent execution (including context resolution)
lives in InferenceResultService._call_agent().
"""

import asyncio
import inspect
from typing import Any, Union

from galtea.utils.agent import (
    AgentInput,
    AgentResponse,
    ChatHistory,
    ConversationMessage,
)


def is_async_callable(obj: Any) -> bool:
    """Check if an object is an async callable (coroutine function).

    Handles both regular async functions and callable objects with async __call__.

    Args:
        obj: The object to check.

    Returns:
        bool: True if the object is an async callable, False otherwise.

    Example:
        ```python
        async def my_async_func():
            pass


        def my_sync_func():
            pass


        is_async_callable(my_async_func)  # True
        is_async_callable(my_sync_func)  # False
        ```
    """
    if asyncio.iscoroutinefunction(obj):
        return True

    # Check for callable objects with async __call__ method
    # callable(obj) guarantees __call__ exists
    if callable(obj):
        return asyncio.iscoroutinefunction(obj.__call__)

    return False


def _expects_agent_input(func: Any) -> bool:
    """Check if an agent function expects an AgentInput parameter.

    Inspects the function signature to determine if the first parameter
    has a type hint of `AgentInput`, which indicates the structured
    callable signature that mirrors Agent.call().

    Args:
        func: The agent function to inspect.

    Returns:
        bool: True if the agent function expects AgentInput, False otherwise.
    """
    try:
        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        if not params:
            return False

        first_param = params[0]
        hint = first_param.annotation

        if hint is inspect.Parameter.empty:
            return False

        if hint is AgentInput:
            return True

        return False
    except (ValueError, TypeError):
        return False


def _expects_string_input(func: Any) -> bool:
    """Check if an agent function expects a single string parameter (vs chat history).

    Inspects the function signature to determine the expected input type.
    If the first parameter has a type hint of `str`, returns True.
    If the first parameter has a type hint of `list` or similar, returns False.
    If no type hints, defaults to False (assumes chat history format).

    Args:
        func: The agent function to inspect.

    Returns:
        bool: True if the agent function expects a single string, False otherwise.
    """
    try:
        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        if not params:
            return False

        first_param = params[0]
        hint = first_param.annotation

        if hint is inspect.Parameter.empty:
            return False

        # Check if it's a string type
        if hint is str:
            return True

        # Handle string types from typing module
        origin = getattr(hint, "__origin__", None)
        if origin is None and hint is str:
            return True

        return False
    except (ValueError, TypeError):
        return False


def _run_async_callable(callable_agent: Any, arg: Union[str, ChatHistory, AgentInput]) -> Any:
    """Execute an async agent function and return the result.

    Handles the complexity of running async code from sync context,
    including when already inside an event loop.

    Args:
        callable_agent: The async agent function to execute.
        arg: The argument to pass to the agent function (string, chat history, or AgentInput).

    Returns:
        Any: The result from the agent function (str, dict, or AgentResponse).
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None:
        # Already in an event loop - run in a separate thread
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(asyncio.run, callable_agent(arg))
            return future.result()
    else:
        # No event loop - can run directly
        return asyncio.run(callable_agent(arg))


def _normalize_callable_result(result: Any) -> AgentResponse:
    """Normalize an agent function result to AgentResponse.

    Args:
        result: The result from an agent function (str, dict, or AgentResponse).

    Returns:
        AgentResponse: The normalized response.

    Raises:
        ValueError: If the result type is not supported.
    """
    if isinstance(result, str):
        return AgentResponse(content=result)
    elif isinstance(result, dict):
        return AgentResponse(**result)
    elif isinstance(result, AgentResponse):
        return result
    else:
        raise ValueError(f"Agent function must return str, dict, or AgentResponse, got {type(result).__name__}")


def _convert_messages_to_dict(messages: list[ConversationMessage]) -> ChatHistory:
    """Convert ConversationMessage list to chat history dict format.

    Args:
        messages: List of ConversationMessage objects.

    Returns:
        ChatHistory: List of dicts with 'role' and 'content' keys.
    """
    return [{"role": m.role, "content": m.content} for m in messages]
