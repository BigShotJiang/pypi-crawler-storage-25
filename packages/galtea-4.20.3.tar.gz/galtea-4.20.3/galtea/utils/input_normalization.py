"""
Utilities for normalizing and unwrapping structured JSON input/context fields.

The API stores input and context as JSON objects:
- input: {"user_message": "...", ...} where "user_message" is the primary text
- context: {"value": "...", ...} where "value" is the primary text

The SDK exposes two access patterns for each:
- ``.input`` / ``.context``: the ``user_message`` / ``value`` string (or None)
- ``.input_data`` / ``.context_data``: the full JSON object as a dict
"""

from typing import Any, Optional


def normalize_input_to_json(value: Any) -> Optional[dict[str, Any]]:
    """Wraps a string input as {"user_message": "..."}, passes dicts through.

    Args:
        value: The input value (string, dict, or None).

    Returns:
        A JSON-compatible dict or None.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return {"user_message": value}
    if isinstance(value, dict):
        return value
    return None


def normalize_context_to_json(value: Any) -> Optional[dict[str, Any]]:
    """Wraps a string context as {"value": "..."}, passes dicts through.

    Args:
        value: The context value (string, dict, or None).

    Returns:
        A JSON-compatible dict or None.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return {"value": value}
    if isinstance(value, dict):
        return value
    return None


def unwrap_input(input_value: Optional[dict[str, Any]]) -> Optional[str]:
    """Extract the ``user_message`` string from a JSON input object.

    Always returns just the ``user_message`` value as a plain string,
    regardless of how many other keys the dict contains. Returns ``None``
    when there is no ``user_message`` key.

    Args:
        input_value: The JSON input object from the API, a plain string,
            or None.

    Returns:
        The ``user_message`` string, or None.
    """
    if input_value is None:
        return None
    if isinstance(input_value, str):
        return input_value
    if isinstance(input_value, dict):
        user_message = input_value.get("user_message")
        if isinstance(user_message, str):
            return user_message
        return None
    return None


def unwrap_context(context_value: Optional[dict[str, Any]]) -> Optional[str]:
    """Extract the ``value`` string from a JSON context object.

    Always returns just the ``value`` value as a plain string,
    regardless of how many other keys the dict contains. Returns ``None``
    when there is no ``value`` key.

    Args:
        context_value: The JSON context object from the API, a plain string,
            or None.

    Returns:
        The ``value`` string, or None.
    """
    if context_value is None:
        return None
    if isinstance(context_value, str):
        return context_value
    if isinstance(context_value, dict):
        val = context_value.get("value")
        if isinstance(val, str):
            return val
        return None
    return None
