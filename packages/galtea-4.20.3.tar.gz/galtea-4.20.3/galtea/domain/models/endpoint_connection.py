from enum import Enum
from typing import Any, Optional

from galtea.utils.case_insensitive_enum import CaseInsensitiveEnumMixin
from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel


class HttpMethod(CaseInsensitiveEnumMixin, str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class EndpointConnectionType(CaseInsensitiveEnumMixin, str, Enum):
    INITIALIZATION = "INITIALIZATION"
    CONVERSATION = "CONVERSATION"
    FINALIZATION = "FINALIZATION"


class EndpointConnectionAuthType(CaseInsensitiveEnumMixin, str, Enum):
    NONE = "NONE"
    BEARER = "BEARER"
    API_KEY = "API_KEY"
    BASIC = "BASIC"


class BackoffStrategy(CaseInsensitiveEnumMixin, str, Enum):
    FIXED = "FIXED"
    EXPONENTIAL = "EXPONENTIAL"
    LINEAR = "LINEAR"


class EndpointConnectionBase(FromCamelCaseBaseModel):
    name: str
    product_id: str
    url: str
    http_method: HttpMethod = HttpMethod.POST
    type: EndpointConnectionType
    auth_type: EndpointConnectionAuthType = EndpointConnectionAuthType.BEARER
    auth_token: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    headers: Optional[dict[str, str]] = None
    input_template: Optional[str] = None
    output_mapping: Optional[dict[str, str]] = None
    timeout: Optional[int] = None
    rate_limit: Optional[int] = None
    retry_enabled: Optional[bool] = None
    retry_max_attempts: Optional[int] = None
    retry_initial_delay_ms: Optional[int] = None
    retry_backoff_strategy: Optional[BackoffStrategy] = None
    retry_max_delay_ms: Optional[int] = None
    retryable_status_codes: Optional[list[int]] = None


class EndpointConnection(EndpointConnectionBase):
    id: str
    has_auth_token: bool = False
    has_password: bool = False
    created_at: str
    deleted_at: Optional[str] = None


class EndpointConnectionUpdate(FromCamelCaseBaseModel):
    """Model for updating endpoint connections with all optional fields (PATCH operation)."""

    name: Optional[str] = None
    url: Optional[str] = None
    http_method: Optional[HttpMethod] = None
    auth_type: Optional[EndpointConnectionAuthType] = None
    auth_token: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    headers: Optional[dict[str, str]] = None
    input_template: Optional[str] = None
    output_mapping: Optional[dict[str, str]] = None
    timeout: Optional[int] = None
    rate_limit: Optional[int] = None
    retry_enabled: Optional[bool] = None
    retry_max_attempts: Optional[int] = None
    retry_initial_delay_ms: Optional[int] = None
    retry_backoff_strategy: Optional[BackoffStrategy] = None
    retry_max_delay_ms: Optional[int] = None
    retryable_status_codes: Optional[list[int]] = None


class TestConnectionResult(FromCamelCaseBaseModel):
    success: bool
    status_code: int
    latency: float
    response: Any = None
    error: Optional[str] = None
    extracted_output: Optional[dict[str, Any]] = None
    extraction_error: Optional[str] = None
