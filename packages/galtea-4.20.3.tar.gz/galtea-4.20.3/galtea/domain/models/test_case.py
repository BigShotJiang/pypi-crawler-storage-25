from typing import Any, Optional, Union

from pydantic import model_validator

from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel
from galtea.utils.input_normalization import unwrap_context, unwrap_input


class _TestCaseCommon(FromCamelCaseBaseModel):
    """Fields shared by all test case models (excluding ``input`` and ``context``,
    whose types differ between write and read models)."""

    test_id: str

    # ACCURACY / SAFETY Test Case
    expected_output: Optional[str] = None
    expected_tools: Optional[list[str]] = None
    variant: Optional[str] = None
    strategy: Optional[str] = None

    # BEHAVIOR Test Case
    user_persona: Optional[str] = None
    scenario: Optional[str] = None
    goal: Optional[str] = None
    max_iterations: Optional[int] = None
    stopping_criterias: Optional[list[str]] = None

    # COMMON FIELDS
    source: Optional[str] = None
    is_augmented: Optional[bool] = False
    reviewed_by_id: Optional[str] = None
    language_code: Optional[str] = None
    user_score: Optional[int] = None
    user_score_reason: Optional[str] = None
    confidence: Optional[float] = None
    confidence_reason: Optional[str] = None


class TestCaseBase(_TestCaseCommon):
    """Write model for creating test cases.

    The ``input`` and ``context`` fields accept strings or dicts.
    ``model_dump()`` preserves the original value for the API's JSONB columns.
    """

    input: Optional[Union[str, dict[str, Any]]] = None
    context: Optional[Union[str, dict[str, Any]]] = None


class TestCase(_TestCaseCommon):
    """Read model for a test case returned by the API.

    Two pairs of fields provide access to input and context:

    **Input:**

    - ``input`` (str | None): the ``user_message`` value as a plain string,
      or ``None`` if the input has no ``user_message`` key.
    - ``input_data`` (dict | None): the full structured input object with all
      fields (e.g. ``user_message``, ``chat_type``, ``priority``).

    **Context:**

    - ``context`` (str | None): the ``value`` value as a plain string,
      or ``None`` if the context has no ``value`` key.
    - ``context_data`` (dict | None): the full structured context object with
      all fields (e.g. ``value``, ``customer_tier``, ``language``).

    Example::

        tc = client.test_cases.get(test_case_id)

        # Quick access to the primary values
        print(tc.input)  # "hello"
        print(tc.context)  # "some context"

        # Full structured objects
        print(tc.input_data)  # {"user_message": "hello", "chat_type": "support"}
        print(tc.context_data)  # {"value": "some context", "customer_tier": "premium"}
    """

    id: str
    created_at: str
    deleted_at: Optional[str] = None
    input: Optional[str] = None
    context: Optional[str] = None

    # Raw JSON objects from the API (for structured input/context access)
    input_data: Optional[dict[str, Any]] = None
    context_data: Optional[dict[str, Any]] = None

    @model_validator(mode="before")
    @classmethod
    def _unwrap_json_fields(cls, data: Any) -> Any:
        """Auto-unwrap JSON input/context from the API into backward-compatible strings."""
        if not isinstance(data, dict):
            return data

        if "input" in data:
            raw_input = data["input"]
        elif "initialPrompt" in data:
            raw_input = data["initialPrompt"]
        else:
            raw_input = data.get("initial_prompt")
        if isinstance(raw_input, dict):
            data["input_data"] = raw_input
            data["input"] = unwrap_input(raw_input)
        elif isinstance(raw_input, str):
            data["input"] = raw_input

        raw_context = data.get("context")
        if isinstance(raw_context, dict):
            data["context_data"] = raw_context
            data["context"] = unwrap_context(raw_context)
        elif isinstance(raw_context, str):
            data["context"] = raw_context

        return data
