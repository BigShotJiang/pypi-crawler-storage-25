import warnings
from enum import Enum
from typing import Any, Optional, Union

from pydantic import model_validator

from galtea.utils.case_insensitive_enum import CaseInsensitiveEnumMixin
from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel
from galtea.utils.input_normalization import unwrap_input

__all__ = ["InferenceResult", "InferenceResultBase", "InferenceResultStatus", "InferenceResultUpdate"]


class InferenceResultStatus(CaseInsensitiveEnumMixin, str, Enum):
    PENDING = "PENDING"
    GENERATED = "GENERATED"
    FAILED = "FAILED"


class CostInfoProperties(FromCamelCaseBaseModel):
    cost_per_input_token: Optional[float] = None
    cost_per_output_token: Optional[float] = None
    cost_per_cache_read_input_token: Optional[float] = None
    cost: Optional[float] = None


class UsageInfoProperties(FromCamelCaseBaseModel):
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cache_read_input_tokens: Optional[int] = None
    tokens: Optional[int] = None


class _InferenceResultCommon(CostInfoProperties, UsageInfoProperties):
    """Fields shared by all inference result models (excluding ``input``,
    whose type differs between write and read models)."""

    session_id: str
    status: Optional[InferenceResultStatus] = InferenceResultStatus.GENERATED
    actual_output: Optional[str] = None
    retrieval_context: Optional[str] = None
    latency: Optional[float] = None
    conversation_simulator_version: Optional[str] = None


class InferenceResultBase(_InferenceResultCommon):
    """Write model for creating inference results.

    The ``input`` field accepts a string or dict. ``model_dump()`` preserves
    the original value so the API can store it as JSONB.
    """

    input: Optional[Union[str, dict[str, Any]]] = None


class InferenceResult(_InferenceResultCommon):
    """Read model for inference results returned by the API.

    Two fields provide access to the input:

    - ``input`` (str | None): the ``user_message`` value as a plain string,
      or ``None`` if the input has no ``user_message`` key.
    - ``input_data`` (dict | None): the full structured input object with
      all fields (e.g. ``user_message``, ``chat_type``, ``reasoning_level``).

    Example::

        result = client.inference_results.get(ir_id)

        # The user message as a string
        print(result.input)  # "hello"

        # The full structured input
        print(result.input_data)  # {"user_message": "hello", "chat_type": "support"}
    """

    id: str
    index: int
    input: Optional[str] = None

    # Raw JSON object from the API (for structured input access)
    input_data: Optional[dict[str, Any]] = None

    @property
    def actual_input(self) -> Optional[str]:
        """Deprecated: use ``input`` directly. Returns the same string value."""
        warnings.warn(
            "InferenceResult.actual_input is deprecated. Use InferenceResult.input directly.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.input

    @model_validator(mode="before")
    @classmethod
    def _normalize_input_field(cls, data: Any) -> Any:
        """Accept ``actualInput``/``actual_input`` and unwrap JSON input objects."""
        if not isinstance(data, dict):
            return data

        # Migrate legacy actualInput/actual_input keys to input
        for legacy_key in ("actualInput", "actual_input"):
            if legacy_key in data and "input" not in data:
                data["input"] = data.pop(legacy_key)
            elif legacy_key in data:
                data.pop(legacy_key)

        # Unwrap JSON input objects to strings
        raw_input = data.get("input")
        if isinstance(raw_input, dict):
            data["input_data"] = raw_input
            data["input"] = unwrap_input(raw_input)

        return data


class InferenceResultUpdate(FromCamelCaseBaseModel):
    """Write model for updating inference results (PATCH operation).

    Fields are Optional (defaulting to None) so they can be excluded from serialization
    if not set (via exclude_unset=True in the service). The ``input`` field accepts
    a plain string or a dict, matching the API's JSONB column.
    """

    # Overridden from CostInfoProperties
    cost_per_input_token: Optional[float] = None
    cost_per_output_token: Optional[float] = None
    cost_per_cache_read_input_token: Optional[float] = None
    cost: Optional[float] = None

    # Overridden from UsageInfoProperties
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cache_read_input_tokens: Optional[int] = None
    tokens: Optional[int] = None

    # Fields specific to InferenceResultUpdate
    session_id: Optional[str] = None
    status: Optional[InferenceResultStatus] = None
    input: Optional[Union[str, dict[str, Any]]] = None
    actual_output: Optional[str] = None
    retrieval_context: Optional[str] = None
    latency: Optional[float] = None
    conversation_simulator_version: Optional[str] = None
    index: Optional[int] = None
    created_at: Optional[str] = None
    deleted_at: Optional[str] = None
