"""
Zeq OS Galaxy Tools — Molecular & Scientific Connectors for Galaxy
==================================================================

Six production-ready Galaxy ToolShed tools for molecular biology,
structural biology, cheminformatics, and spectroscopy — all powered
by the Zeq API (https://www.zeq.dev) with 1.287 Hz HulyaPulse
synchronization and CKO envelope verification.

Tools included:
    - zeq_pubchem_3d:    PubChem 3D molecular structures & properties
    - zeq_rcsb_pdb:      RCSB PDB experimental protein structures
    - zeq_alphafold:     AlphaFold predicted protein structures
    - zeq_chembl:        ChEMBL bioactivity & pharmacology data
    - zeq_md_simulator:  Molecular dynamics simulation engine
    - zeq_nist_spectral: NIST spectral emission line analysis

Requirements:
    - Python 3.8+
    - Zeq API key from https://www.zeq.dev/dashboard
    - No external dependencies (stdlib only)

Zeq OS Framework:
    - HulyaPulse: 1.287 Hz
    - Zeqond: 0.777 s
    - KO42 Metric Tensioner: Prime Directive
    - Paper DOI: https://doi.org/10.5281/zenodo.18158152
    - Framework DOI: https://doi.org/10.5281/zenodo.15825138

Author: Zeq. H - Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

__version__ = "1.287.5"
__author__ = "Zeq. H"
__email__ = "zeq@1.287hz.com"
__license__ = "CC-BY-4.0"
__url__ = "https://hulyas.org"

HULYAPULSE_FREQUENCY = 1.287  # Hz
ZEQOND_PERIOD = 0.777  # seconds
KO42_VERSION = "1.287.5"

TOOLS = [
    "zeq_pubchem_3d",
    "zeq_rcsb_pdb",
    "zeq_alphafold",
    "zeq_chembl",
    "zeq_md_simulator",
    "zeq_nist_spectral",
]
