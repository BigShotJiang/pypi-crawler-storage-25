#!/usr/bin/env python3
"""
Zeq OS AlphaFold Structure Fetching Tool
========================================
Tool ID: zeq_alphafold
Version: 1.287.5
Profile: Zeq OS ML Dashboard Production v1.287

PURPOSE:
  Fetches AlphaFold predicted protein structures from EMBL-EBI and extracts
  structural metrics including atomic coordinates, confidence scores (pLDDT),
  and residue composition. All HulyaPulse modulation and CKO envelope generation
  is routed through the Zeq API.

ZEQOND CONSTANTS:
  HULYAPULSE_FREQ = 1.287 Hz
  ZEQOND = 0.777 s (deterministic phase-lock interval)

DEPENDENCIES:
  Python 3.6+ (stdlib only: urllib, json, csv, math, argparse, sys, time)
  zeq_client.py (Zeq API client)

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Full source code (open, not a black box):
  https://github.com/hulyasmath/zeq-hulyas-framework-v1287-python

Paper DOI: https://doi.org/10.5281/zenodo.18158152
Framework DOI: https://doi.org/10.5281/zenodo.15825138
SDK: https://sdk.1.287hz.com/

AUTHOR: Zeq. H — Zeq OS 1.287 Hz Limited
LICENSE: CC BY 4.0
"""

import urllib.request
import urllib.error
import json
import csv
import math
import argparse
import sys
import time

try:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC
except ImportError:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC

# Zeq OS Constants
KO42_PRIME = "Metric Tensioner Prime Directive"

# AlphaFold EBI URLs
AF_BASE_URL = "https://alphafold.ebi.ac.uk/files/AF-{uniprot}-F1-model_{version}.pdb"
VERSION_FALLBACK = ["v6", "v4", "v3", "v2"]


def fetch_pdb_file(uniprot_id):
    """
    Fetch PDB file from AlphaFold EBI with version fallback.

    Args:
        uniprot_id (str): UniProt accession ID (e.g., P69905)

    Returns:
        tuple: (pdb_content, version_used) or (None, None) if all attempts fail
    """
    for version in VERSION_FALLBACK:
        url = AF_BASE_URL.format(uniprot=uniprot_id, version=version)
        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                pdb_content = response.read().decode('utf-8')
                return pdb_content, version
        except (urllib.error.HTTPError, urllib.error.URLError, Exception) as e:
            continue

    return None, None


def parse_pdb_atoms(pdb_content):
    """
    Parse ATOM lines from PDB format.

    Args:
        pdb_content (str): Raw PDB file content

    Returns:
        list: List of dicts with keys:
              atom_num, atom_name, residue_name, chain, residue_num,
              x, y, z, occupancy, b_factor, element
    """
    atoms = []
    for line in pdb_content.split('\n'):
        if line.startswith('ATOM'):
            try:
                atom_dict = {
                    'atom_num': int(line[6:11].strip()),
                    'atom_name': line[12:16].strip(),
                    'residue_name': line[17:20].strip(),
                    'chain': line[21].strip(),
                    'residue_num': int(line[22:26].strip()),
                    'x': float(line[30:38].strip()),
                    'y': float(line[38:46].strip()),
                    'z': float(line[46:54].strip()),
                    'occupancy': float(line[54:60].strip()),
                    'b_factor': float(line[60:66].strip()),
                    'element': line[76:78].strip()
                }
                atoms.append(atom_dict)
            except (ValueError, IndexError):
                continue
    return atoms


def compute_structure_metrics(atoms):
    """
    Compute structural metrics from parsed atoms.

    Args:
        atoms (list): List of atom dictionaries

    Returns:
        dict: Metrics including counts, pLDDT stats, distribution
    """
    if not atoms:
        return None

    atom_count = len(atoms)
    residue_nums = set(atom['residue_num'] for atom in atoms)
    residue_count = len(residue_nums)

    b_factors = [atom['b_factor'] for atom in atoms]
    avg_plddt = sum(b_factors) / len(b_factors) if b_factors else 0.0

    # pLDDT distribution
    very_high = sum(1 for bf in b_factors if bf > 90)
    confident = sum(1 for bf in b_factors if 70 <= bf <= 90)
    low = sum(1 for bf in b_factors if 50 <= bf < 70)
    very_low = sum(1 for bf in b_factors if bf < 50)

    return {
        'atom_count': atom_count,
        'residue_count': residue_count,
        'average_plddt': round(avg_plddt, 2),
        'plddt_distribution': {
            'very_high_gt90': very_high,
            'confident_70_90': confident,
            'low_50_70': low,
            'very_low_lt50': very_low
        },
        'min_plddt': round(min(b_factors), 2) if b_factors else 0.0,
        'max_plddt': round(max(b_factors), 2) if b_factors else 0.0,
        'median_plddt': round(sorted(b_factors)[len(b_factors)//2], 2) if b_factors else 0.0
    }


def write_atoms_tsv(atoms, output_file):
    """
    Write atoms to tab-delimited file.

    Args:
        atoms (list): List of atom dictionaries
        output_file (str): Path to output TSV file
    """
    if not atoms:
        return

    with open(output_file, 'w', newline='') as f:
        fieldnames = ['atom_num', 'atom_name', 'residue_name', 'chain',
                      'residue_num', 'x', 'y', 'z', 'b_factor', 'element']
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter='\t')
        writer.writeheader()
        for atom in atoms:
            writer.writerow({k: atom[k] for k in fieldnames})


def write_confidence_tsv(atoms, output_file):
    """
    Write per-residue confidence summary (B-factor/pLDDT).

    Args:
        atoms (list): List of atom dictionaries
        output_file (str): Path to output TSV file
    """
    if not atoms:
        return

    # Group by residue
    residues = {}
    for atom in atoms:
        res_key = (atom['chain'], atom['residue_num'], atom['residue_name'])
        if res_key not in residues:
            residues[res_key] = []
        residues[res_key].append(atom['b_factor'])

    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['chain', 'residue_num', 'residue_name', 'avg_plddt', 'min_plddt', 'max_plddt', 'atom_count'])
        for (chain, res_num, res_name), b_factors in sorted(residues.items()):
            writer.writerow([
                chain,
                res_num,
                res_name,
                round(sum(b_factors) / len(b_factors), 2),
                round(min(b_factors), 2),
                round(max(b_factors), 2),
                len(b_factors)
            ])


def write_json_output(data, output_file):
    """
    Write output as JSON.

    Args:
        data (dict): Data to serialize
        output_file (str): Path to output JSON file
    """
    with open(output_file, 'w') as f:
        json.dump(data, f, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description='Zeq OS AlphaFold Structure Fetching Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --zeq_api_key zeq_ak_... --uniprot_id P69905
  %(prog)s --zeq_api_key zeq_ak_... --uniprot_id P69905 --mode structure --output_atoms atoms.tsv
  %(prog)s --zeq_api_key zeq_ak_... --uniprot_id P69905 --mode all --output_json summary.json --hulyapulse
        """
    )

    parser.add_argument('--zeq_api_key', type=str, required=True,
                        help='Zeq API key (REQUIRED). Get your key at https://www.zeq.dev/dashboard')
    parser.add_argument('--uniprot_id', required=True,
                        help='UniProt accession ID (e.g., P69905)')
    parser.add_argument('--mode', choices=['structure', 'confidence', 'summary', 'all'],
                        default='all',
                        help='Output mode: structure (atoms), confidence (per-residue), summary (JSON), all (default: all)')
    parser.add_argument('--output_atoms', type=str,
                        help='Output file for atomic coordinates (TSV)')
    parser.add_argument('--output_confidence', type=str,
                        help='Output file for per-residue confidence (TSV)')
    parser.add_argument('--output_json', type=str,
                        help='Output file for summary JSON')
    parser.add_argument('--hulyapulse', action='store_true',
                        help='Enable HulyaPulse 1.287 Hz modulation (routes through Zeq API)')

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    # Fetch PDB
    print(f"[Zeq OS] Fetching AlphaFold structure for {args.uniprot_id}...", file=sys.stderr)
    pdb_content, version = fetch_pdb_file(args.uniprot_id)

    if not pdb_content:
        print(f"[Zeq OS] ERROR: Could not fetch PDB for {args.uniprot_id}", file=sys.stderr)
        sys.exit(1)

    print(f"[Zeq OS] Successfully fetched using version {version}", file=sys.stderr)

    # Parse atoms
    atoms = parse_pdb_atoms(pdb_content)
    if not atoms:
        print(f"[Zeq OS] ERROR: No ATOM records found in PDB", file=sys.stderr)
        sys.exit(1)

    print(f"[Zeq OS] Parsed {len(atoms)} atoms", file=sys.stderr)

    # Compute metrics
    metrics = compute_structure_metrics(atoms)

    # Apply HulyaPulse modulation via Zeq API if enabled
    phase = None
    if args.hulyapulse:
        b_factors = [atom['b_factor'] for atom in atoms]
        modulated_values, result = client.modulate_values(b_factors)
        if result:
            zeq_state = result.get("zeqState", {})
            phase = zeq_state.get("phase", 0.0)
        else:
            t = time.time()
            phase = (t % ZEQOND_SEC) / ZEQOND_SEC
        print(f"[Zeq OS] HulyaPulse modulation applied, phase: {phase:.4f}", file=sys.stderr)

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()

    # Write outputs based on mode
    if args.mode in ['structure', 'all']:
        if args.output_atoms:
            write_atoms_tsv(atoms, args.output_atoms)
            print(f"[Zeq OS] Wrote atomic coordinates to {args.output_atoms}", file=sys.stderr)

    if args.mode in ['confidence', 'all']:
        if args.output_confidence:
            write_confidence_tsv(atoms, args.output_confidence)
            print(f"[Zeq OS] Wrote confidence data to {args.output_confidence}", file=sys.stderr)

    if args.mode in ['summary', 'all']:
        if args.output_json:
            output_data = {
                'uniprot_id': args.uniprot_id,
                'pdb_version': version,
                'zeq_os': {
                    'hulyapulse_freq': HULYAPULSE_HZ,
                    'zeqond': ZEQOND_SEC,
                    'ko42': KO42_PRIME,
                    'phase': phase
                },
                'metrics': metrics,
                'cko_envelope': cko_envelope
            }
            write_json_output(output_data, args.output_json)
            print(f"[Zeq OS] Wrote summary to {args.output_json}", file=sys.stderr)

    # Console output (stderr for Galaxy compatibility)
    if metrics:
        print(f"\n=== Zeq OS AlphaFold Analysis ===", file=sys.stderr)
        print(f"UniProt ID: {args.uniprot_id}", file=sys.stderr)
        print(f"PDB Version: {version}", file=sys.stderr)
        print(f"Atoms: {metrics['atom_count']}", file=sys.stderr)
        print(f"Residues: {metrics['residue_count']}", file=sys.stderr)
        print(f"Average pLDDT: {metrics['average_plddt']}", file=sys.stderr)
        print(f"pLDDT Range: {metrics['min_plddt']} - {metrics['max_plddt']}", file=sys.stderr)
        print(f"Distribution:", file=sys.stderr)
        print(f"  Very High (>90):  {metrics['plddt_distribution']['very_high_gt90']}", file=sys.stderr)
        print(f"  Confident (70-90): {metrics['plddt_distribution']['confident_70_90']}", file=sys.stderr)
        print(f"  Low (50-70):       {metrics['plddt_distribution']['low_50_70']}", file=sys.stderr)
        print(f"  Very Low (<50):    {metrics['plddt_distribution']['very_low_lt50']}", file=sys.stderr)
        if args.hulyapulse and phase is not None:
            print(f"HulyaPulse Phase (via Zeq API): {phase:.4f}", file=sys.stderr)

    # Daemon tick
    client.daemon_tick()

    sys.exit(0)


if __name__ == '__main__':
    main()
