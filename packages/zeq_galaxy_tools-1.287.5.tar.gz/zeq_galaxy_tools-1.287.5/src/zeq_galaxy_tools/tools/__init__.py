"""Zeq OS Galaxy Tools — individual tool modules."""
