#!/usr/bin/env python
"""
Zeq OS NIST Spectral Emission Line Analysis Tool
Version 1.287.5
Analyzes spectral emission lines for 16 common elements with built-in database.
All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Full source code (open, not a black box):
  https://github.com/hulyasmath/zeq-hulyas-framework-v1287-python

Paper DOI: https://doi.org/10.5281/zenodo.18158152
Framework DOI: https://doi.org/10.5281/zenodo.15825138
SDK: https://sdk.1.287hz.com/

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import sys
import json
import csv
import math
import time

try:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC
except ImportError:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC

# Built-in NIST emission line database
# Format: element: [(wavelength_nm, relative_intensity, series), ...]
EMISSION_DATABASE = {
    "H": [
        (656.3, 100.0, "Balmer Ha"),
        (486.1, 65.0, "Balmer Hb"),
        (434.0, 40.0, "Balmer Hg"),
        (410.2, 25.0, "Balmer Hd"),
    ],
    "He": [
        (587.6, 100.0, "Helium Yellow"),
        (501.6, 70.0, "Helium Cyan"),
        (667.8, 85.0, "Helium Red"),
        (706.5, 60.0, "Helium Far-Red"),
    ],
    "Li": [
        (670.8, 100.0, "Lithium Red"),
        (610.4, 80.0, "Lithium Orange"),
        (460.3, 65.0, "Lithium Blue"),
    ],
    "Be": [
        (313.0, 100.0, "Beryllium UV"),
        (332.1, 90.0, "Beryllium UV"),
        (234.9, 70.0, "Beryllium Far-UV"),
    ],
    "B": [
        (249.7, 100.0, "Boron UV"),
        (249.8, 95.0, "Boron UV"),
        (208.9, 75.0, "Boron Far-UV"),
    ],
    "C": [
        (247.9, 100.0, "Carbon UV"),
        (193.1, 85.0, "Carbon Far-UV"),
        (165.7, 70.0, "Carbon Extreme-UV"),
    ],
    "N": [
        (746.8, 100.0, "Nitrogen Red"),
        (744.2, 98.0, "Nitrogen Red"),
        (868.0, 75.0, "Nitrogen Far-Red"),
        (862.9, 73.0, "Nitrogen Far-Red"),
    ],
    "O": [
        (777.2, 100.0, "Oxygen Triplet"),
        (777.4, 100.0, "Oxygen Triplet"),
        (844.6, 85.0, "Oxygen Far-Red"),
        (615.8, 80.0, "Oxygen Orange"),
    ],
    "Na": [
        (589.0, 100.0, "Sodium D1"),
        (589.6, 100.0, "Sodium D2"),
        (330.2, 65.0, "Sodium UV"),
        (330.3, 65.0, "Sodium UV"),
    ],
    "Mg": [
        (285.2, 100.0, "Magnesium UV"),
        (280.3, 95.0, "Magnesium UV"),
        (518.4, 70.0, "Magnesium Green"),
    ],
    "Al": [
        (396.2, 100.0, "Aluminum Violet"),
        (394.4, 98.0, "Aluminum Violet"),
        (309.3, 75.0, "Aluminum UV"),
    ],
    "Si": [
        (251.6, 100.0, "Silicon UV"),
        (288.2, 85.0, "Silicon UV"),
        (390.6, 70.0, "Silicon Violet"),
    ],
    "Fe": [
        (371.9, 100.0, "Iron Violet"),
        (374.6, 95.0, "Iron Violet"),
        (382.0, 90.0, "Iron Violet"),
        (385.6, 85.0, "Iron Violet"),
        (404.6, 80.0, "Iron Violet"),
    ],
    "Cu": [
        (324.8, 100.0, "Copper UV"),
        (327.4, 95.0, "Copper UV"),
        (510.6, 75.0, "Copper Green"),
        (515.3, 70.0, "Copper Green"),
    ],
    "Zn": [
        (213.9, 100.0, "Zinc Far-UV"),
        (330.3, 85.0, "Zinc UV"),
        (334.5, 80.0, "Zinc UV"),
        (481.1, 70.0, "Zinc Blue"),
    ],
    "Br": [
        (478.6, 100.0, "Bromine Blue"),
        (481.7, 98.0, "Bromine Blue"),
        (614.8, 75.0, "Bromine Orange"),
    ],
}


def gaussian(x, center, fwhm, intensity):
    """
    Calculate Gaussian profile value.

    Args:
        x: wavelength position
        center: line center wavelength
        fwhm: full width at half maximum
        intensity: peak intensity

    Returns:
        Gaussian value at x
    """
    sigma = fwhm / (2.0 * math.sqrt(2.0 * math.log(2.0)))
    exponent = -((x - center) ** 2) / (2.0 * sigma ** 2)
    return intensity * math.exp(exponent)


def generate_spectrum(lines, wavelength_min, wavelength_max, fwhm=0.5, step=0.1):
    """
    Generate simulated broadened spectrum from emission lines.

    Args:
        lines: list of (wavelength, intensity, series) tuples
        wavelength_min: minimum wavelength (nm)
        wavelength_max: maximum wavelength (nm)
        fwhm: Gaussian full width at half maximum (nm)
        step: wavelength sampling step (nm)

    Returns:
        list of (wavelength, intensity) tuples
    """
    spectrum = []
    wavelength = wavelength_min

    while wavelength <= wavelength_max:
        intensity = 0.0
        for line_wl, line_intensity, _ in lines:
            intensity += gaussian(wavelength, line_wl, fwhm, line_intensity)
        spectrum.append((wavelength, intensity))
        wavelength += step

    return spectrum


def get_filtered_lines(element, wavelength_min, wavelength_max):
    """
    Get emission lines for element filtered by wavelength range.

    Args:
        element: element symbol (e.g., "Fe")
        wavelength_min: minimum wavelength (nm)
        wavelength_max: maximum wavelength (nm)

    Returns:
        list of (wavelength, intensity, series) tuples
    """
    if element not in EMISSION_DATABASE:
        return []

    lines = EMISSION_DATABASE[element]
    filtered = [
        (wl, intensity, series)
        for wl, intensity, series in lines
        if wavelength_min <= wl <= wavelength_max
    ]
    return filtered


def write_lines_table(lines, element, output_file):
    """Write emission lines to tab-delimited table."""
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['element', 'wavelength_nm', 'relative_intensity', 'series'])
        for wl, intensity, series in lines:
            writer.writerow([element, f"{wl:.1f}", f"{intensity:.1f}", series])


def write_spectrum_table(spectrum, output_file):
    """Write simulated spectrum to tab-delimited table."""
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['wavelength', 'intensity'])
        for wl, intensity in spectrum:
            writer.writerow([f"{wl:.1f}", f"{intensity:.4f}"])


def write_json_summary(data, output_file):
    """Write JSON summary."""
    with open(output_file, 'w') as f:
        json.dump(data, f, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description="Zeq OS NIST Spectral Emission Line Analysis Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Available elements: H, He, Li, Be, B, C, N, O, Na, Mg, Al, Si, Fe, Cu, Zn, Br

Modes:
  lines    - Output emission lines table only
  spectrum - Output simulated broadened spectrum
  compare  - Compare two elements (requires --compare_element)
  all      - Output all results (default)

Example:
  %(prog)s --zeq_api_key YOUR_KEY --element Fe --mode lines --output_lines output.csv
  %(prog)s --zeq_api_key YOUR_KEY --element H --mode spectrum --output_spectrum spec.csv
  %(prog)s --zeq_api_key YOUR_KEY --element Fe --compare_element H --mode compare --output_json out.json
        """
    )

    parser.add_argument('--zeq_api_key', type=str, required=True,
                        help='Zeq API Key (required). Get your key at https://www.zeq.dev/dashboard')
    parser.add_argument('--element', type=str, default='Fe',
                        help='Element symbol (default: Fe)')
    parser.add_argument('--mode', type=str, choices=['lines', 'spectrum', 'compare', 'all'],
                        default='all', help='Analysis mode (default: all)')
    parser.add_argument('--wavelength_min', type=float, default=200.0,
                        help='Minimum wavelength in nm (default: 200.0)')
    parser.add_argument('--wavelength_max', type=float, default=900.0,
                        help='Maximum wavelength in nm (default: 900.0)')
    parser.add_argument('--compare_element', type=str, default=None,
                        help='Second element for comparison (optional)')
    parser.add_argument('--output_lines', type=str, default=None,
                        help='Output file for emission lines table')
    parser.add_argument('--output_spectrum', type=str, default=None,
                        help='Output file for simulated spectrum')
    parser.add_argument('--output_json', type=str, default=None,
                        help='Output file for JSON summary')
    parser.add_argument('--hulyapulse', action='store_true',
                        help='Apply HulyaPulse 1.287 Hz modulation via Zeq API')

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    # Validate element
    if args.element not in EMISSION_DATABASE:
        print(f"[Zeq OS] ERROR: Unknown element '{args.element}'", file=sys.stderr)
        print(f"[Zeq OS] Available elements: {', '.join(sorted(EMISSION_DATABASE.keys()))}", file=sys.stderr)
        sys.exit(1)

    print(f"[Zeq OS] Analyzing spectral emission lines for {args.element}", file=sys.stderr)

    # Get filtered lines for primary element
    primary_lines = get_filtered_lines(args.element, args.wavelength_min, args.wavelength_max)

    if not primary_lines:
        print(f"[Zeq OS] WARNING: No emission lines found for {args.element} in range "
              f"{args.wavelength_min}-{args.wavelength_max} nm", file=sys.stderr)
    else:
        print(f"[Zeq OS] Found {len(primary_lines)} emission lines in range", file=sys.stderr)

    # Initialize JSON summary
    summary = {
        "element": args.element,
        "mode": args.mode,
        "wavelength_range_nm": [args.wavelength_min, args.wavelength_max],
        "lines_count": len(primary_lines),
        "hulyapulse_modulation": args.hulyapulse,
        "hulyapulse_frequency_hz": HULYAPULSE_HZ,
        "zeqond_period_s": ZEQOND_SEC,
        "timestamp": time.time(),
    }

    # Generate outputs based on mode
    timestamp = time.time()

    if args.mode in ['lines', 'all']:
        if args.output_lines:
            lines_to_write = primary_lines
            if args.hulyapulse:
                # Extract intensities and modulate via API
                intensities = [intensity for _, intensity, _ in lines_to_write]
                modulated_intensities, _ = client.modulate_values(intensities)
                lines_to_write = [
                    (wl, modulated_intensities[i], series)
                    for i, (wl, _, series) in enumerate(lines_to_write)
                ]
                print(f"[Zeq OS] HulyaPulse modulation applied to emission lines", file=sys.stderr)
            write_lines_table(lines_to_write, args.element, args.output_lines)
            print(f"[Zeq OS] Wrote emission lines to {args.output_lines}", file=sys.stderr)
            summary["lines_output"] = args.output_lines

    if args.mode in ['spectrum', 'all']:
        if args.output_spectrum:
            spectrum = generate_spectrum(primary_lines, args.wavelength_min, args.wavelength_max)
            if args.hulyapulse:
                # Extract intensities and modulate via API
                intensities = [intensity for _, intensity in spectrum]
                modulated_intensities, _ = client.modulate_values(intensities)
                spectrum = [
                    (wl, modulated_intensities[i])
                    for i, (wl, _) in enumerate(spectrum)
                ]
                print(f"[Zeq OS] HulyaPulse modulation applied to spectrum", file=sys.stderr)
            write_spectrum_table(spectrum, args.output_spectrum)
            print(f"[Zeq OS] Wrote spectrum to {args.output_spectrum}", file=sys.stderr)
            summary["spectrum_output"] = args.output_spectrum

    if args.mode in ['compare', 'all']:
        if args.compare_element:
            if args.compare_element not in EMISSION_DATABASE:
                print(f"[Zeq OS] ERROR: Unknown compare element '{args.compare_element}'", file=sys.stderr)
                sys.exit(1)

            compare_lines = get_filtered_lines(args.compare_element, args.wavelength_min, args.wavelength_max)

            summary["compare_element"] = args.compare_element
            summary["compare_lines_count"] = len(compare_lines)

            # Find overlapping lines (within 2 nm tolerance)
            overlaps = []
            for wl1, int1, series1 in primary_lines:
                for wl2, int2, series2 in compare_lines:
                    if abs(wl1 - wl2) < 2.0:
                        overlaps.append({
                            "element1": args.element,
                            "wavelength1_nm": wl1,
                            "element2": args.compare_element,
                            "wavelength2_nm": wl2,
                            "difference_nm": abs(wl1 - wl2),
                        })

            summary["overlapping_lines"] = overlaps
            summary["overlap_count"] = len(overlaps)

    # Get CKO envelope from API
    cko_envelope = client.get_cko_envelope()
    summary["cko_envelope"] = cko_envelope

    # Write JSON summary
    if args.output_json:
        write_json_summary(summary, args.output_json)
        print(f"[Zeq OS] Wrote JSON summary to {args.output_json}", file=sys.stderr)

    # Daemon tick
    client.daemon_tick()
    print(f"[Zeq OS] Spectral analysis complete for {args.element}", file=sys.stderr)


if __name__ == '__main__':
    main()
