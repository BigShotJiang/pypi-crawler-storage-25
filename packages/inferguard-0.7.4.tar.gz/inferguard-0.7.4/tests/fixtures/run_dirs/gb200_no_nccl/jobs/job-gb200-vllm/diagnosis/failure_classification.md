# Failure classification

- [measured] none
