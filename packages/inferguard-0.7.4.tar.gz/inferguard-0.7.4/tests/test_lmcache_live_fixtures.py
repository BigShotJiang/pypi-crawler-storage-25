from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import pytest

from inferguard.disagg.adapters.lmcache import parse_lmcache_prometheus

LIVE_FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "lmcache_live"
PACKET_A_DIR = LIVE_FIXTURE_ROOT / "packet_a"

# Packet A launch/config proof uses compact command artifacts already emitted by
# scripts/lmcache_mp_modal_packet_lab.py at the run root. Accepted live fixtures
# must copy these files verbatim or as sanitized JSON lists with the same names.
PACKET_A_REQUIRED_FILES = (
    "fixture_manifest.json",
    "lmcache_command.json",
    "lmcache_env.json",
    "vllm_command.json",
    "vllm_metrics_loaded.prom",
    "lmcache_metrics_loaded.prom",
    "packet_manifest.json",
    "lmcache_compat_report.json",
    "observability_coverage.json",
    "bottleneck_diagnosis.json",
    "lmcache_http_evidence.json",
    "lmcache_log_evidence.json",
    "lmcache_trace_evidence.json",
    "lmcache_trace_replay_evidence.json",
)
PACKET_B_REQUIRED_FILES = (
    *PACKET_A_REQUIRED_FILES,
    "workload_manifest.json",
    "traffic_requests.jsonl",
    "packet-b-lifecycle-evidence.json",
    "agent_kv_offload_report.json",
)
PACKET_C_REQUIRED_FILES = (
    *PACKET_A_REQUIRED_FILES,
    "workload_manifest.json",
    "traffic_requests.jsonl",
    "lmcache_l2_config.json",
)
PACKET_D_REQUIRED_FILES = (
    *PACKET_A_REQUIRED_FILES,
    "workload_manifest.json",
    "traffic_requests.jsonl",
    "lmcache_otel.jsonl",
    "lmcache_otel_evidence.json",
)
PACKET_E_REQUIRED_FILES = (
    *PACKET_A_REQUIRED_FILES,
    "workload_manifest.json",
    "traffic_requests.jsonl",
)
PACKET_F_REQUIRED_FILES = (
    *PACKET_A_REQUIRED_FILES,
    "workload_manifest.json",
    "traffic_requests.jsonl",
    "lmcache_lookup_hash_evidence.json",
)
PACKET_H1_REQUIRED_FILES = (
    "fixture_manifest.json",
    "primary_engine_command.json",
    "primary_engine_env.json",
    "runner_launch_proof.json",
    "engine_metrics_loaded.prom",
    "packet_manifest.json",
    "lmcache_compat_report.json",
    "observability_coverage.json",
    "bottleneck_diagnosis.json",
    "lmcache_log_evidence.json",
)
PACKET_H3_REQUIRED_FILES = (
    "fixture_manifest.json",
    "primary_engine_command.json",
    "primary_engine_env.json",
    "runner_launch_proof.json",
    "engine_metrics_loaded.prom",
    "lmcache_blend_metrics.prom",
    "packet_manifest.json",
    "lmcache_compat_report.json",
    "observability_coverage.json",
    "bottleneck_diagnosis.json",
    "lmcache_log_evidence.json",
    "lmcache_otel.jsonl",
    "lmcache_otel_evidence.json",
    "lmcache_retrieve_layer_no_keys_patch.json",
    "vllm_cacheblend_model_tracker_patch.json",
)
PACKET_B_REQUIRED_FAMILIES = (
    "lookup_reuse",
    "lookup_hits",
    "l1_lifecycle",
    "l0_lifecycle",
    "real_reuse",
    "l1_eviction",
    "l0_l1_throughput",
)

_SECRET_PATTERN = re.compile(
    r"(HF_TOKEN|OPENAI_API_KEY|ANTHROPIC_API_KEY|PASSWORD|SECRET|CREDENTIAL|AUTH_TOKEN)",
    re.IGNORECASE,
)
_RAW_PROMPT_PATTERN = re.compile(r'"prompt"\s*:|"messages"\s*:', re.IGNORECASE)
_RAW_HASH_PATTERN = re.compile(r"raw-secret-hash|raw_hash|raw-hash", re.IGNORECASE)


def test_landed_live_fixtures_are_sanitized_and_pass_acceptance_contract() -> None:
    """Validate accepted live fixtures if present without inventing a fake one.

    Workstream 1/B1 prep should land this executable gate before any Modal artifact is
    imported. With no fixture present, this test proves the gate is armed but does not
    move score. Once `tests/fixtures/lmcache_live/packet_a/fixture_manifest.json` is
    imported with `acceptance_status=accepted`, the same test enforces the B1 contract.
    """

    for fixture_dir in _accepted_live_fixture_dirs():
        if fixture_dir.name == "packet_a":
            _assert_packet_a_b1_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_b":
            _assert_packet_b_c1_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_c":
            _assert_packet_c_d1_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_d":
            _assert_packet_d_e1_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_e":
            _assert_packet_e_e2_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_f":
            _assert_packet_f_f1_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_h1":
            _assert_packet_h1_acceptance(fixture_dir)
        elif fixture_dir.name == "packet_h3":
            _assert_packet_h3_acceptance(fixture_dir)
        else:
            raise AssertionError(f"unknown accepted LMCache live fixture: {fixture_dir}")


def test_packet_a_acceptance_contract_rejects_non_live_or_incomplete_fixture(tmp_path: Path) -> None:
    fixture_dir = tmp_path / "packet_a"
    fixture_dir.mkdir()
    _write_json(
        fixture_dir / "fixture_manifest.json",
        {
            "row_id": "B1",
            "packet_id": "a",
            "source": "synthetic_unit_test",
            "score_points": 10,
            "redacted": True,
            "raw_hashes_removed": True,
            "raw_prompts_removed": True,
            "acceptance_status": "accepted",
        },
    )

    with pytest.raises(AssertionError, match="live_modal_h100"):
        _assert_packet_a_manifest(_read_json(fixture_dir / "fixture_manifest.json"))

    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    manifest["source"] = "live_modal_h100"
    _write_json(fixture_dir / "fixture_manifest.json", manifest)

    with pytest.raises(AssertionError, match="missing required B1 fixture artifact"):
        _assert_packet_a_b1_acceptance(fixture_dir)


def test_packet_b_acceptance_contract_rejects_incomplete_lifecycle_fixture(tmp_path: Path) -> None:
    fixture_dir = tmp_path / "packet_b"
    fixture_dir.mkdir()
    _write_json(
        fixture_dir / "fixture_manifest.json",
        {
            "row_id": "C1",
            "packet_id": "b",
            "benchmark_id": "LC1",
            "workload_profile": "long_context_agent_kv_offload",
            "raw_prompts_recorded": False,
            "source": "live_modal_h100",
            "score_points": 6,
            "redacted": True,
            "raw_hashes_removed": True,
            "raw_prompts_removed": True,
            "acceptance_status": "accepted",
        },
    )

    with pytest.raises(AssertionError, match="missing required C1 fixture artifact"):
        _assert_packet_b_c1_acceptance(fixture_dir)


def test_g1_diagnostic_calibration_is_pinned_by_accepted_live_packet_diagnoses() -> None:
    """G1 must be backed by accepted live packet diagnoses, not parser-only docs."""

    expected = {
        "packet_a": {"row_id": "B1", "rule_fired": "lmcache_mp_empty_cache_salt", "claim_status": "inferred"},
        "packet_b": {"row_id": "C1", "rule_fired": "lmcache_mp_l1_failures", "claim_status": "measured"},
        "packet_c": {"row_id": "D1", "rule_fired": "lmcache_mp_l1_eviction_pressure", "claim_status": "measured"},
        "packet_d": {"row_id": "E1", "rule_fired": "vllm_external_prefix_no_hits", "claim_status": "inferred"},
        "packet_e": {"row_id": "E2", "rule_fired": "lmcache_mp_empty_cache_salt", "claim_status": "inferred"},
        "packet_f": {"row_id": "F1", "rule_fired": "vllm_external_prefix_no_hits", "claim_status": "inferred"},
    }

    for fixture_dir in _accepted_live_fixture_dirs():
        if fixture_dir.name not in expected:
            continue
        manifest = _read_json(fixture_dir / "fixture_manifest.json")
        diagnosis = _read_json(fixture_dir / "bottleneck_diagnosis.json")
        expected_row = expected[fixture_dir.name]
        assert manifest.get("source") == "live_modal_h100"
        assert manifest.get("row_id") == expected_row["row_id"]
        assert diagnosis.get("schema_version") == "inferguard-bottleneck-diagnosis/v1"
        assert diagnosis.get("rule_fired") == expected_row["rule_fired"]
        assert diagnosis.get("claim_status") == expected_row["claim_status"]
        assert diagnosis.get("verdict") == "not_enough_evidence"
        metric_values = diagnosis.get("metric_values", {})
        assert any(str(key).startswith("lmcache_compat") for key in metric_values), (
            f"{fixture_dir.name} diagnosis must preserve LMCache compatibility evidence"
        )


def _accepted_live_fixture_dirs() -> list[Path]:
    if not LIVE_FIXTURE_ROOT.exists():
        return []
    dirs: list[Path] = []
    for manifest_path in sorted(LIVE_FIXTURE_ROOT.glob("*/fixture_manifest.json")):
        manifest = _read_json(manifest_path)
        if manifest.get("acceptance_status") == "accepted":
            dirs.append(manifest_path.parent)
    return dirs


def _assert_packet_a_b1_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    _assert_packet_a_manifest(manifest)
    _assert_required_files(fixture_dir, PACKET_A_REQUIRED_FILES)
    _assert_fixture_sanitized(fixture_dir)
    _assert_shared_mp_artifact_metric_acceptance(fixture_dir)


def _assert_packet_h1_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    assert manifest.get("row_id") == "H1"
    assert manifest.get("packet_id") == "h1"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("acceptance_status") == "accepted"
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    _assert_required_files(fixture_dir, PACKET_H1_REQUIRED_FILES)
    _assert_fixture_sanitized(fixture_dir)

    command = _read_json_list(fixture_dir / "primary_engine_command.json")
    env = _read_json(fixture_dir / "primary_engine_env.json")
    proof = _read_json(fixture_dir / "runner_launch_proof.json")
    packet_manifest = _read_json(fixture_dir / "packet_manifest.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    coverage = _read_json(fixture_dir / "observability_coverage.json")
    log_evidence = _read_json(fixture_dir / "lmcache_log_evidence.json")

    assert "--kv-transfer-config" in command
    transfer_config = json.loads(command[command.index("--kv-transfer-config") + 1])
    assert transfer_config == {"kv_connector": "LMCacheConnectorV1", "kv_role": "kv_both"}
    assert env.get("PROMETHEUS_MULTIPROC_DIR")
    assert proof.get("expect_lmcache_mode") == "embedded"

    metrics_text = (fixture_dir / "engine_metrics_loaded.prom").read_text(encoding="utf-8")
    assert "lmcache:num_retrieve_requests_total" in metrics_text
    assert "lmcache:num_store_requests_total" in metrics_text
    assert "lmcache_mp_" not in metrics_text
    assert "lmcache_mp." not in metrics_text

    assert packet_manifest.get("detected_mode") == "embedded"
    assert packet_manifest.get("claim_status") == "measured"
    assert packet_manifest.get("compat_summary", {}).get("failure_reasons") == []
    assert compat.get("detected_mode") == "embedded"
    assert compat.get("failure_reasons") == []
    assert compat.get("detected_architecture", {}).get("label") == "vllm_embedded_lmcache"
    assert compat.get("detected_architecture", {}).get("claim_status") == "measured"
    assert compat.get("observed", {}).get("lmcache_embedded") is True
    assert compat.get("observed", {}).get("lmcache_mp") is False
    assert coverage.get("detected_lmcache_mode") == "embedded"
    assert log_evidence.get("booleans", {}).get("has_store") is True
    assert log_evidence.get("booleans", {}).get("has_retrieve") is True
    _assert_positive(log_evidence.get("event_counts", {}).get("store"), "lmcache_log_evidence.store")
    _assert_positive(log_evidence.get("event_counts", {}).get("retrieve"), "lmcache_log_evidence.retrieve")


def _assert_packet_h3_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    assert manifest.get("row_id") == "H3"
    assert manifest.get("packet_id") == "h3-cacheblend"
    assert manifest.get("workload") == "cacheblend_reuse"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 3
    assert manifest.get("acceptance_status") == "accepted"
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    _assert_required_files(fixture_dir, PACKET_H3_REQUIRED_FILES, row_id="H3")
    _assert_fixture_sanitized(fixture_dir)

    command = _read_json_list(fixture_dir / "primary_engine_command.json")
    proof = _read_json(fixture_dir / "runner_launch_proof.json")
    packet_manifest = _read_json(fixture_dir / "packet_manifest.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    coverage = _read_json(fixture_dir / "observability_coverage.json")
    diagnosis = _read_json(fixture_dir / "bottleneck_diagnosis.json")
    otel = _read_json(fixture_dir / "lmcache_otel_evidence.json")
    retrieve_patch = _read_json(fixture_dir / "lmcache_retrieve_layer_no_keys_patch.json")
    model_patch = _read_json(fixture_dir / "vllm_cacheblend_model_tracker_patch.json")

    assert command[:3] == ["vllm", "serve", "Qwen/Qwen3-0.6B"]
    transfer_config = json.loads(command[command.index("--kv-transfer-config") + 1])
    assert transfer_config == {"kv_connector": "LMCacheConnectorV1", "kv_role": "kv_both"}
    assert _cmd_value(command, "--collect-detailed-traces") == "all"
    assert proof.get("expected_engine") == "vllm"
    assert proof.get("expect_lmcache_mode") == "auto"
    assert "lmcache_blend_* metrics" in proof.get("required_live_proof", [])
    assert "cb.* OTel spans" in proof.get("required_live_proof", [])

    metrics_text = (fixture_dir / "lmcache_blend_metrics.prom").read_text(encoding="utf-8")
    assert "lmcache_blend_lookup_requests_total" in metrics_text
    assert "lmcache_blend_retrieve_requests_total" in metrics_text
    assert "lmcache_mp_" not in metrics_text
    assert "lmcache_mp." not in metrics_text

    assert packet_manifest.get("detected_mode") == "embedded_cacheblend"
    assert packet_manifest.get("claim_status") == "measured"
    assert packet_manifest.get("compat_summary", {}).get("failure_reasons") == []
    assert compat.get("detected_mode") == "embedded_cacheblend"
    assert compat.get("failure_reasons") == []
    assert compat.get("detected_architecture", {}).get("label") == "vllm_embedded_cacheblend"
    assert compat.get("detected_architecture", {}).get("claim_status") == "measured"
    assert compat.get("observed", {}).get("lmcache_cacheblend") is True
    assert compat.get("observed", {}).get("lmcache_cacheblend_metrics") is True
    assert compat.get("observed", {}).get("lmcache_cacheblend_evidence") is True
    assert compat.get("observed", {}).get("lmcache_mp") is False
    assert coverage.get("detected_lmcache_mode") == "embedded_cacheblend"

    family_rows = {
        (row.get("surface"), row.get("family")): row
        for row in compat.get("families", [])
        if isinstance(row, dict)
    }
    for family in ("lookup", "retrieve"):
        row = family_rows.get(("lmcache_cacheblend", family))
        assert row and row.get("status") == "populated", f"compat report missing CacheBlend {family}"
        assert row.get("matched_metrics"), f"CacheBlend family has no matched metric: {family}"
    for family in ("storage_manager", "lookup_tokens", "l1_counters", "l1_memory"):
        row = family_rows.get(("lmcache_mp", family))
        assert row and row.get("status") == "not_applicable", f"H3 must not require MP {family}"

    assert otel.get("claim_status") == "measured"
    _assert_positive(otel.get("cacheblend_span_count"), "lmcache_otel_evidence.cacheblend_span_count")
    assert otel.get("span_counts", {}).get("cb.lookup", 0) > 0
    assert otel.get("span_counts", {}).get("cb.retrieve", 0) > 0
    assert diagnosis.get("claim_status") == "measured"
    assert diagnosis.get("metric_values", {}).get("lmcache_compat.detected_mode") == "embedded_cacheblend"
    assert retrieve_patch.get("changed") is True
    assert model_patch.get("schema_version") == "inferguard-h3-cacheblend-vllm-patch/v1"


def _assert_shared_mp_artifact_metric_acceptance(fixture_dir: Path) -> None:
    packet_manifest = _read_json(fixture_dir / "packet_manifest.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    coverage = _read_json(fixture_dir / "observability_coverage.json")
    diagnosis = _read_json(fixture_dir / "bottleneck_diagnosis.json")
    trace = _read_json(fixture_dir / "lmcache_trace_evidence.json")
    trace_replay = _read_json(fixture_dir / "lmcache_trace_replay_evidence.json")
    lmcache_command = _read_json_list(fixture_dir / "lmcache_command.json")
    lmcache_env = _read_json(fixture_dir / "lmcache_env.json")
    vllm_command = _read_json_list(fixture_dir / "vllm_command.json")

    _assert_packet_a_launch_proof(
        lmcache_command=lmcache_command,
        lmcache_env=lmcache_env,
        vllm_command=vllm_command,
    )

    metrics = parse_lmcache_prometheus(
        (fixture_dir / "lmcache_metrics_loaded.prom").read_text(encoding="utf-8")
    )
    assert metrics.lmcache_mp_mode_enabled is True
    _assert_positive(metrics.lmcache_sm_read_requests, "lmcache_sm_read_requests")
    _assert_positive(metrics.lmcache_sm_write_requests, "lmcache_sm_write_requests")
    _assert_positive(metrics.lmcache_l1_read_keys, "lmcache_l1_read_keys")
    _assert_positive(metrics.lmcache_l1_write_keys, "lmcache_l1_write_keys")
    _assert_positive(metrics.lmcache_l1_memory_usage_bytes, "lmcache_l1_memory_usage_bytes")
    _assert_positive(metrics.lmcache_lookup_requested_tokens, "lmcache_lookup_requested_tokens")
    _assert_positive(metrics.lmcache_lookup_hit_tokens, "lmcache_lookup_hit_tokens")

    assert packet_manifest.get("detected_mode") == "mp"
    assert packet_manifest.get("l2_configured") is False
    assert compat.get("detected_mode") == "mp"
    assert compat.get("l2_configured") is False
    assert compat.get("detected_architecture", {}).get("label") == "vllm_mp_lmcache"
    assert compat.get("detected_architecture", {}).get("claim_status") in {"measured", "inferred"}
    assert coverage.get("detected_lmcache_mode") == "mp"
    assert coverage.get("config", {}).get("l2_configured") is False

    assert trace.get("claim_status") == "measured"
    _assert_positive(trace.get("record_count"), "lmcache_trace_evidence.record_count")
    assert trace_replay.get("claim_status") == "measured"

    finding_codes = {
        item.get("code")
        for item in diagnosis.get("findings", []) + diagnosis.get("diagnostic_findings", [])
        if isinstance(item, dict)
    }
    if diagnosis.get("rule_fired"):
        finding_codes.add(diagnosis["rule_fired"])
    metric_values = diagnosis.get("metric_values", {})
    has_lmcache_diagnosis = any(str(code).startswith("lmcache") for code in finding_codes)
    has_lmcache_arch_confirmation = (
        metric_values.get("lmcache_compat.detected_architecture", {}).get("label")
        == "vllm_mp_lmcache"
    )
    assert has_lmcache_diagnosis or has_lmcache_arch_confirmation, (
        "B1 diagnosis must include an LMCache-specific finding/rule or measured architecture confirmation"
    )


def _assert_packet_b_c1_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    _assert_packet_b_manifest(manifest)
    _assert_required_files(fixture_dir, PACKET_B_REQUIRED_FILES, row_id="C1")
    _assert_fixture_sanitized(fixture_dir)

    _assert_shared_mp_artifact_metric_acceptance(fixture_dir)
    workload = _read_json(fixture_dir / "workload_manifest.json")
    evidence = _read_json(fixture_dir / "packet-b-lifecycle-evidence.json")
    lmcache_command = _read_json_list(fixture_dir / "lmcache_command.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")

    assert workload.get("packet_id") == "b"
    assert workload.get("sdlc_row_id") == "C1"
    assert workload.get("benchmark_id") == "LC1"
    assert workload.get("workload") == "reuse_eviction"
    assert workload.get("workload_profile") == "long_context_agent_kv_offload"
    assert str(workload.get("trace_source", "")).startswith("traces/isb1-dsv4-agent")
    assert workload.get("metrics_sample_rate") == 1.0
    assert workload.get("raw_prompts_recorded") is False
    _assert_packet_b_traffic_rows_metadata_only(fixture_dir / "traffic_requests.jsonl")
    assert [phase.get("phase") for phase in workload.get("phases", [])] == [
        "warm",
        "pressure",
        "retest",
    ]
    assert _cmd_value(lmcache_command, "--metrics-sample-rate") == "1.0"
    assert _cmd_value(lmcache_command, "--l1-size-gb") == str(workload.get("l1_size_gb"))

    assert evidence.get("schema_version") == "inferguard-lmcache-mp-packet-b-lifecycle/v1"
    assert evidence.get("claim_status") == "measured"
    assert evidence.get("metrics_sample_rate") == 1.0
    assert evidence.get("missing_required_families") == []
    families = evidence.get("required_families")
    assert isinstance(families, dict)
    for family in PACKET_B_REQUIRED_FAMILIES:
        row = families.get(family)
        assert isinstance(row, dict), f"missing Packet B family row: {family}"
        assert row.get("status") == "populated", f"Packet B family not populated: {family}"
        assert row.get("matched_metrics"), f"Packet B family has no matched metric: {family}"

    family_rows = {
        (row.get("surface"), row.get("family")): row
        for row in compat.get("families", [])
        if isinstance(row, dict)
    }
    for family in ("l1_lifecycle", "l0_lifecycle", "real_reuse", "l0_l1_throughput"):
        row = family_rows.get(("lmcache_mp", family))
        assert row and row.get("status") == "populated", f"compat report missing Packet B {family}"


def _assert_packet_c_d1_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    _assert_packet_c_manifest(manifest)
    _assert_required_files(fixture_dir, PACKET_C_REQUIRED_FILES, row_id="D1")
    _assert_fixture_sanitized(fixture_dir)

    workload = _read_json(fixture_dir / "workload_manifest.json")
    l2_config = _read_json(fixture_dir / "lmcache_l2_config.json")
    lmcache_command = _read_json_list(fixture_dir / "lmcache_command.json")
    packet_manifest = _read_json(fixture_dir / "packet_manifest.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    coverage = _read_json(fixture_dir / "observability_coverage.json")
    trace = _read_json(fixture_dir / "lmcache_trace_evidence.json")
    trace_replay = _read_json(fixture_dir / "lmcache_trace_replay_evidence.json")

    assert workload.get("packet_id") == "c"
    assert workload.get("workload") == "l2_reuse"
    assert workload.get("raw_prompts_recorded") is False
    _assert_packet_b_traffic_rows_metadata_only(fixture_dir / "traffic_requests.jsonl")

    assert _cmd_value(lmcache_command, "--l2-store-policy") == "skip_l1"
    assert _cmd_value(lmcache_command, "--l2-prefetch-policy") == "default"
    adapter = json.loads(_cmd_value(lmcache_command, "--l2-adapter"))
    assert adapter == {"type": "mock", "max_size_gb": 80, "mock_bandwidth_gb": 4}
    assert l2_config.get("adapter") == adapter

    assert packet_manifest.get("detected_mode") == "mp"
    assert packet_manifest.get("l2_configured") is True
    assert compat.get("failure_reasons") == []
    assert compat.get("detected_mode") == "mp"
    assert compat.get("l2_configured") is True
    assert coverage.get("detected_lmcache_mode") == "mp"
    assert coverage.get("config", {}).get("l2_configured") is True

    family_rows = {
        (row.get("surface"), row.get("family")): row
        for row in compat.get("families", [])
        if isinstance(row, dict)
    }
    for family in ("l2_counters", "l2_throughput"):
        row = family_rows.get(("lmcache_mp", family))
        assert row and row.get("status") == "populated", f"compat report missing Packet C {family}"
        assert row.get("matched_metrics"), f"Packet C family has no matched metric: {family}"
    l2_summary = compat.get("lmcache_l2_summary", {})
    _assert_positive(l2_summary.get("store_tasks"), "lmcache_l2_summary.store_tasks")
    _assert_positive(l2_summary.get("store_completed"), "lmcache_l2_summary.store_completed")
    _assert_positive(l2_summary.get("load_completed"), "lmcache_l2_summary.load_completed")

    assert trace.get("claim_status") == "measured"
    _assert_positive(trace.get("record_count"), "lmcache_trace_evidence.record_count")
    assert trace_replay.get("claim_status") == "measured"


def _assert_packet_d_e1_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    _assert_packet_d_manifest(manifest)
    _assert_required_files(fixture_dir, PACKET_D_REQUIRED_FILES, row_id="E1")
    _assert_fixture_sanitized(fixture_dir)

    workload = _read_json(fixture_dir / "workload_manifest.json")
    lmcache_command = _read_json_list(fixture_dir / "lmcache_command.json")
    lmcache_env = _read_json(fixture_dir / "lmcache_env.json")
    packet_manifest = _read_json(fixture_dir / "packet_manifest.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    coverage = _read_json(fixture_dir / "observability_coverage.json")
    otel = _read_json(fixture_dir / "lmcache_otel_evidence.json")
    diagnosis = _read_json(fixture_dir / "bottleneck_diagnosis.json")

    assert workload.get("packet_id") == "d"
    assert workload.get("workload") == "otel_reuse"
    assert workload.get("raw_prompts_recorded") is False
    _assert_packet_b_traffic_rows_metadata_only(fixture_dir / "traffic_requests.jsonl")

    assert "--enable-tracing" in lmcache_command
    assert _cmd_value(lmcache_command, "--otlp-endpoint") == "http://127.0.0.1:4317"
    assert lmcache_env.get("OTEL_SERVICE_NAME") == "lmcache-mp-packet-d"

    assert packet_manifest.get("detected_mode") == "mp"
    assert packet_manifest.get("claim_status") == "measured"
    assert packet_manifest.get("compat_summary", {}).get("failure_reasons") == []
    assert compat.get("failure_reasons") == []
    assert compat.get("detected_mode") == "mp"
    assert compat.get("observed", {}).get("lmcache_mp_evidence") is True
    assert compat.get("observed", {}).get("lmcache_mp_metrics_prometheus_unavailable") is True
    assert coverage.get("detected_lmcache_mode") == "mp"

    assert otel.get("claim_status") == "measured"
    _assert_positive(otel.get("span_count"), "lmcache_otel_evidence.span_count")
    _assert_positive(otel.get("mp_span_count"), "lmcache_otel_evidence.mp_span_count")
    _assert_positive(otel.get("request_span_count"), "lmcache_otel_evidence.request_span_count")
    assert diagnosis.get("claim_status") in {"measured", "inferred"}


def _assert_packet_e_e2_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    _assert_packet_e_manifest(manifest)
    _assert_required_files(fixture_dir, PACKET_E_REQUIRED_FILES, row_id="E2")
    _assert_fixture_sanitized(fixture_dir)

    workload = _read_json(fixture_dir / "workload_manifest.json")
    packet_manifest = _read_json(fixture_dir / "packet_manifest.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    coverage = _read_json(fixture_dir / "observability_coverage.json")
    trace_replay = _read_json(fixture_dir / "lmcache_trace_replay_evidence.json")

    assert workload.get("packet_id") == "e"
    assert workload.get("workload") == "trace_replay"
    assert workload.get("raw_prompts_recorded") is False
    _assert_packet_b_traffic_rows_metadata_only(fixture_dir / "traffic_requests.jsonl")

    assert packet_manifest.get("detected_mode") == "mp"
    assert packet_manifest.get("claim_status") == "measured"
    assert compat.get("failure_reasons") == []
    assert compat.get("detected_mode") == "mp"
    assert coverage.get("detected_lmcache_mode") == "mp"
    assert trace_replay.get("claim_status") == "measured"
    assert trace_replay.get("failed_rows") == 0
    _assert_positive(trace_replay.get("rows_seen"), "lmcache_trace_replay_evidence.rows_seen")
    _assert_positive(trace_replay.get("duration_s"), "lmcache_trace_replay_evidence.duration_s")


def _assert_packet_f_f1_acceptance(fixture_dir: Path) -> None:
    manifest = _read_json(fixture_dir / "fixture_manifest.json")
    _assert_packet_f_manifest(manifest)
    _assert_required_files(fixture_dir, PACKET_F_REQUIRED_FILES, row_id="F1")
    _assert_fixture_sanitized(fixture_dir)

    workload = _read_json(fixture_dir / "workload_manifest.json")
    lmcache_command = _read_json_list(fixture_dir / "lmcache_command.json")
    compat = _read_json(fixture_dir / "lmcache_compat_report.json")
    lookup_hash = _read_json(fixture_dir / "lmcache_lookup_hash_evidence.json")

    assert workload.get("packet_id") == "f"
    assert workload.get("workload") == "cache_salt_isolated_lru"
    assert workload.get("workload_profile") == "cache_salt_isolated_lru"
    assert workload.get("eviction_policy") == "IsolatedLRU"
    assert workload.get("raw_prompts_recorded") is False
    _assert_packet_b_traffic_rows_metadata_only(fixture_dir / "traffic_requests.jsonl")

    assert _cmd_value(lmcache_command, "--eviction-policy") == "IsolatedLRU"
    assert "--lookup-hash-log-dir" in lmcache_command
    assert compat.get("failure_reasons") == []
    assert compat.get("detected_mode") == "mp"
    observability = compat.get("lmcache_mp_observability", {})
    assert observability.get("cache_salt_values") == ["tenant-0", "tenant-1"]
    assert observability.get("cache_salt_cardinality") == 2
    assert observability.get("cache_salt_cardinality_risk") is False

    assert lookup_hash.get("claim_status") == "measured"
    assert lookup_hash.get("present") is True
    _assert_positive(lookup_hash.get("row_count"), "lmcache_lookup_hash_evidence.row_count")
    for file_row in lookup_hash.get("files", []):
        assert file_row.get("claim_status") == "measured"
        assert file_row.get("malformed_rows") == 0
        assert file_row.get("chunk_hash_count", {}).get("count", 0) > 0

    rows = [
        json.loads(line)
        for line in (fixture_dir / "traffic_requests.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert {row.get("cache_salt") for row in rows} == {"tenant-0", "tenant-1"}


def _assert_packet_b_traffic_rows_metadata_only(path: Path) -> None:
    required = {
        "request_index",
        "phase",
        "prefix_group",
        "prompt_chars",
        "trace_id",
        "synthetic_redaction_status",
        "cache_salt",
    }
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert rows, "Packet B traffic request log must contain metadata rows"
    for row in rows:
        assert "prompt" not in row
        assert "messages" not in row
        assert "secret" not in {str(key).lower() for key in row}
        assert required.issubset(row), f"Packet B traffic row missing metadata keys: {row}"
        assert row.get("raw_prompt_recorded") is False


def _assert_packet_a_launch_proof(
    *,
    lmcache_command: list[Any],
    lmcache_env: dict[str, Any],
    vllm_command: list[Any],
) -> None:
    assert lmcache_command[:2] == ["lmcache", "server"]
    assert _cmd_value(lmcache_command, "--host") == "127.0.0.1"
    assert _cmd_value(lmcache_command, "--port") == "6555"
    assert _cmd_value(lmcache_command, "--http-port") == "8080"
    assert _cmd_value(lmcache_command, "--prometheus-port") == "9090"
    assert _cmd_value(lmcache_command, "--trace-level") == "storage"
    assert "--trace-output" in lmcache_command
    assert "--lookup-hash-log-dir" in lmcache_command
    assert _cmd_value(lmcache_command, "--eviction-policy") == "LRU"
    assert _cmd_value(lmcache_command, "--metrics-sample-rate") == "1.0"
    assert _cmd_value(lmcache_command, "--event-bus-queue-size") == "10000"
    assert "LMCACHE_CONFIG_FILE" not in lmcache_env, "Packet A must remain L1-only; no L2 config"

    assert vllm_command[:3] == ["vllm", "serve", "Qwen/Qwen3-8B"]
    kv_transfer_config = json.loads(_cmd_value(vllm_command, "--kv-transfer-config"))
    assert kv_transfer_config["kv_connector"] == "LMCacheMPConnector"
    assert kv_transfer_config["kv_role"] == "kv_both"
    assert kv_transfer_config["kv_load_failure_policy"] == "recompute"
    assert kv_transfer_config["kv_connector_extra_config"] == {
        "lmcache.mp.host": "tcp://127.0.0.1",
        "lmcache.mp.port": 6555,
        "lmcache.mp.mq_timeout": 10,
    }
    assert "--disable-hybrid-kv-cache-manager" in vllm_command


def _assert_packet_a_manifest(manifest: dict[str, Any]) -> None:
    assert manifest.get("row_id") == "B1"
    assert manifest.get("packet_id") == "a"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 10
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    assert manifest.get("acceptance_status") == "accepted"


def _assert_packet_b_manifest(manifest: dict[str, Any]) -> None:
    assert manifest.get("row_id") == "C1"
    assert manifest.get("packet_id") == "b"
    assert manifest.get("benchmark_id") == "LC1"
    assert manifest.get("workload_profile") == "long_context_agent_kv_offload"
    assert manifest.get("raw_prompts_recorded", False) is False
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 6
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    assert manifest.get("acceptance_status") == "accepted"


def _assert_packet_c_manifest(manifest: dict[str, Any]) -> None:
    assert manifest.get("row_id") == "D1"
    assert manifest.get("packet_id") == "c"
    assert manifest.get("workload") == "l2_reuse"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 6
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    assert manifest.get("acceptance_status") == "accepted"


def _assert_packet_e_manifest(manifest: dict[str, Any]) -> None:
    assert manifest.get("row_id") == "E2"
    assert manifest.get("packet_id") == "e"
    assert manifest.get("workload") == "trace_replay"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 4
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    assert manifest.get("acceptance_status") == "accepted"


def _assert_packet_d_manifest(manifest: dict[str, Any]) -> None:
    assert manifest.get("row_id") == "E1"
    assert manifest.get("packet_id") == "d"
    assert manifest.get("workload") == "otel_reuse"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 4
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    assert manifest.get("acceptance_status") == "accepted"


def _assert_packet_f_manifest(manifest: dict[str, Any]) -> None:
    assert manifest.get("row_id") == "F1"
    assert manifest.get("packet_id") == "f"
    assert manifest.get("workload") == "cache_salt_isolated_lru"
    assert manifest.get("source") == "live_modal_h100"
    assert manifest.get("score_points") == 4
    assert manifest.get("redacted") is True
    assert manifest.get("raw_hashes_removed") is True
    assert manifest.get("raw_prompts_removed") is True
    assert manifest.get("acceptance_status") == "accepted"


def _assert_required_files(
    fixture_dir: Path, rel_paths: tuple[str, ...], *, row_id: str = "B1"
) -> None:
    for rel_path in rel_paths:
        path = fixture_dir / rel_path
        assert path.exists(), f"missing required {row_id} fixture artifact: {rel_path}"
        assert path.stat().st_size > 0, f"empty required {row_id} fixture artifact: {rel_path}"


def _assert_fixture_sanitized(fixture_dir: Path) -> None:
    for path in fixture_dir.rglob("*"):
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        assert not _SECRET_PATTERN.search(text), f"secret-like token found in {path}"
        assert not _RAW_PROMPT_PATTERN.search(text), f"raw prompt/message payload found in {path}"
        text_without_manifest_receipts = text.replace("raw_hashes_removed", "")
        assert not _RAW_HASH_PATTERN.search(
            text_without_manifest_receipts
        ), f"raw chunk hash marker found in {path}"


def _assert_positive(value: int | float | None, label: str) -> None:
    assert value is not None and value > 0, f"expected positive {label}, got {value!r}"


def _cmd_value(command: list[Any], flag: str) -> str:
    assert flag in command, f"missing command flag {flag}"
    index = command.index(flag)
    assert index + 1 < len(command), f"missing value for command flag {flag}"
    value = command[index + 1]
    assert isinstance(value, str), f"expected string value for {flag}, got {value!r}"
    return value


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(payload, dict), f"expected JSON object in {path}"
    return payload


def _read_json_list(path: Path) -> list[Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(payload, list), f"expected JSON list in {path}"
    return payload


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
