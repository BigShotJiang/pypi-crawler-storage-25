# Failure classification
