import logging

from diskcache import Cache
import ee
import geopandas as gpd
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from .sentinel import get_sentinel_properties
from .worldclim import get_average_temperature_and_precipation
import sys
sys.setrecursionlimit(2000)
logger = logging.getLogger(__name__)
path_root = Path(__file__).resolve().parent

EE_PROJECT_HELP = (
    "To find your project name:\n"
    "  1. Go to https://console.cloud.google.com\n"
    "  2. At the top of the page, click the project selector\n"
    "  3. Copy the 'Project ID' (e.g. 'my-project-123')\n"
)


def autenticateEE(project: str | None = None) -> None:
    if project is None:
        raise ValueError(
            "A Google Cloud project name is required.\n" + EE_PROJECT_HELP
        )
    ee.Authenticate()
    ee.Initialize(project=project)
    
    
def check_ee_authenticated() -> bool:
    try:
        ee.Number(1).getInfo()
        return True
    except ee.EEException:
        return False
    


def get_environment_data(
    gdf: gpd.GeoDataFrame,
    ndvi: bool = True,
    ndwi: bool = True,
    temperature: bool = True,
    precipitation: bool = True,
) -> pd.DataFrame:
    if not check_ee_authenticated():
        raise RuntimeError(
            "Earth Engine is not authenticated. Please run:\n\n"
            "    import ecoenv\n"
            "    ecoenv.autenticateEE(project='your-project')\n\n"
            + EE_PROJECT_HELP
        )
        
    if not (ndvi or ndwi or temperature or precipitation):
        raise ValueError(
            "At least one of the following parameters must be True: "
            "ndvi, ndwi, temperature, precipitation."
        )

    try:
        logger.info("Fetching fresh data from sources...")

        sentinel_future = None
        climate_future = None

        with ThreadPoolExecutor(max_workers=2) as executor:
            if ndvi or ndwi:
                sentinel_future = executor.submit(
                    get_sentinel_properties, gdf, 250, ndvi, ndwi
                )

            if temperature or precipitation:
                climate_future = executor.submit(
                    get_average_temperature_and_precipation,
                    gdf, batch_size=5000, temperature=temperature, precipitation=precipitation
                )

        sentinel_data = sentinel_future.result() if sentinel_future else None
        climate_data = climate_future.result() if climate_future else None

        if sentinel_data is not None and climate_data is not None:
            env_data = sentinel_data.merge(climate_data, how="left", on=["latitude", "longitude"], suffixes=("", "_y"))
        
            env_data = env_data.drop(columns=[c for c in env_data.columns if c.endswith("_y")])
            return env_data
        else:
            if sentinel_data is None: 
                return climate_data
            else: 
                return sentinel_data

    except Exception as e:
        logger.error(f"Critical error retrieving environment data: {e}", exc_info=True)
        return pd.DataFrame()
    
    
def clear_cache(sentinel: bool = True, worldclim: bool = True):
    """Remove os dados em cache da biblioteca."""
    if sentinel:
        Cache(path_root / ".sentinel_cache").clear()
    if worldclim:
        Cache(path_root / ".worldclim_cache").clear()