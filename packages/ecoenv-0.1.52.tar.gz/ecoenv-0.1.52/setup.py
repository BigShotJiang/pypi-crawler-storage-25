from setuptools import setup, find_packages

setup(
    name='ecoenv',
    version='0.1.52',
    description='A Python library for ecological data collection and environmental analysis',
    long_description=open('USAGE.md').read(),
    long_description_content_type='text/markdown',
    author='Ane Simões',
    author_email='anes.2017@alunos.utfpr.edu.br',
    packages=find_packages(),
    install_requires=[
        "earthengine-api",
        "pandas",
        "requests",
        "python-dotenv",
    ],
    license='MIT',
    python_requires='>=3.7',
)