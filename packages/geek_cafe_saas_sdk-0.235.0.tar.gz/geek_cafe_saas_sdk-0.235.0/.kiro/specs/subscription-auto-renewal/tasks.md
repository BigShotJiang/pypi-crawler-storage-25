# Implementation Plan: Subscription Auto-Renewal

## Overview

Incrementally add renewal eligibility checks, contiguous period calculation, idempotency guards, atomic TransactWrite operations, and the `superseded` status to the existing `SubscriptionService` and `Subscription` models. Each task builds on the previous, ending with full integration and wiring.

## Tasks

- [ ] 1. Add "superseded" status to Subscription models
  - [ ] 1.1 Add "superseded" to SDK Subscription model valid statuses and add `is_superseded()` method
    - In `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/models/subscription.py`, add `"superseded"` to the `valid_statuses` list in the `status` setter
    - Add `is_superseded()` method that returns `self._status == "superseded"`
    - _Requirements: 7.1, 7.2_

  - [ ] 1.2 Add "superseded" to Aplos Subscription model valid statuses
    - In `Aplos-SaaS-Models/src/aplos_saas_models/subscription/__init__.py`, add `"superseded"` to the `valid_statuses` list in the `status` setter
    - _Requirements: 7.3, 6.3, 6.4_

  - [ ]* 1.3 Write property test for `is_superseded` correctness (Property 6)
    - **Property 6: is_superseded correctness**
    - Generate subscriptions with all valid statuses, verify `is_superseded()` returns True iff status is `"superseded"`
    - Create test in `geek-cafe-saas-sdk/tests/properties/test_subscription_renewal.py`
    - **Validates: Requirements 7.2**

  - [ ]* 1.4 Write unit tests for superseded status in both models
    - Test setting status to `"superseded"` on SDK Subscription does not raise
    - Test setting status to `"superseded"` on Aplos Subscription does not raise
    - Test `is_superseded()` returns True/False correctly
    - Create tests in `geek-cafe-saas-sdk/tests/test_subscription_renewal.py`
    - _Requirements: 7.1, 7.2, 7.3_

- [ ] 2. Implement renewal eligibility check
  - [ ] 2.1 Add `check_renewal_eligibility()` method to `SubscriptionService`
    - In `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`, add method accepting a `Subscription` and returning `ServiceResult`
    - Check `cancel_at_period_end` first → error code `RENEWAL_CANCELED`
    - Check status `"disabled"` → `RENEWAL_DISABLED`
    - Check status `"past_due"` → `RENEWAL_PAST_DUE`
    - Check status `"canceled"` or `"expired"` → `RENEWAL_INELIGIBLE`
    - Return success only if status is `"active"` or `"trial"` and `cancel_at_period_end` is False
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

  - [ ]* 2.2 Write property test for eligibility gate (Property 1)
    - **Property 1: Eligibility gate**
    - Generate subscriptions with random statuses and cancel flags; verify eligibility result matches expected logic
    - Add to `geek-cafe-saas-sdk/tests/properties/test_subscription_renewal.py`
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5**

  - [ ]* 2.3 Write unit tests for eligibility edge cases
    - Test each rejection path returns correct error code
    - Test active + not-canceled returns success
    - Test trial + not-canceled returns success
    - Add to `geek-cafe-saas-sdk/tests/test_subscription_renewal.py`
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

- [ ] 3. Implement contiguous period calculation
  - [ ] 3.1 Add `_calculate_contiguous_period()` to `SubscriptionService`
    - Accepts old subscription, returns `(new_start, new_end, next_billing)` tuple
    - `new_start` = old subscription's `current_period_end_utc_ts`
    - Use `dateutil.relativedelta` for calendar-accurate month/year arithmetic
    - Reject if `current_period_end_utc_ts` is None or 0 → error code `INVALID_PERIOD`
    - `next_billing` = `new_end`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

  - [ ]* 3.2 Write property test for contiguous period calculation (Property 2)
    - **Property 2: Contiguous period calculation**
    - Generate random valid period-end timestamps and billing intervals; verify `new_start == old_end`, `new_end` is exactly 1 month/year later, `next_billing == new_end`
    - Add to `geek-cafe-saas-sdk/tests/properties/test_subscription_renewal.py`
    - **Validates: Requirements 2.1, 2.2, 2.3, 2.4**

  - [ ]* 3.3 Write unit test for invalid period rejection
    - Test subscription with null/zero `current_period_end_utc_ts` returns `INVALID_PERIOD`
    - Add to `geek-cafe-saas-sdk/tests/test_subscription_renewal.py`
    - _Requirements: 2.5_

- [ ] 4. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 5. Implement idempotency and renewal builder helpers
  - [ ] 5.1 Add `_compute_idempotency_key()` and `_find_existing_renewal()` to `SubscriptionService`
    - `_compute_idempotency_key(tenant_id, period_start_ts)` returns `f"{tenant_id}#{int(period_start_ts)}"`
    - `_find_existing_renewal(tenant_id, period_start_ts)` queries GSI1 for a subscription matching the target period start; returns `Subscription | None`
    - _Requirements: 5.1, 5.2_

  - [ ]* 5.2 Write property test for idempotency key determinism (Property 4)
    - **Property 4: Idempotency key determinism**
    - Generate random tenant IDs and timestamps; verify same inputs produce same key, different inputs produce different keys
    - Add to `geek-cafe-saas-sdk/tests/properties/test_subscription_renewal.py`
    - **Validates: Requirements 5.1**

  - [ ] 5.3 Add `_build_renewal_subscription()` to `SubscriptionService`
    - Accepts old subscription, new_start, new_end, next_billing; returns new `Subscription`
    - Copies `plan_code`, `plan_name`, `plan_id`, `price_cents`, `currency`, `billing_interval`, `seat_count`, `payment_method`, `external_subscription_id`, `external_customer_id`, `active_addons`, `addon_metadata`
    - Sets status to `"active"`, period timestamps to new values
    - _Requirements: 3.1, 3.2_

  - [ ]* 5.4 Write property test for renewal output invariants (Property 3)
    - **Property 3: Renewal output invariants**
    - Generate random eligible subscriptions with varied plan fields; verify all copied fields match and status is `"active"`
    - Add to `geek-cafe-saas-sdk/tests/properties/test_subscription_renewal.py`
    - **Validates: Requirements 3.1, 3.2, 3.3, 3.4**

- [ ] 6. Implement TransactWrite helper and refactor `_update_active_pointer()`
  - [ ] 6.1 Add `_execute_transact_write()` to `SubscriptionService`
    - Accepts `list[dict]` of TransactWrite operations
    - Calls `self.dynamodb.transact_write_items()` with error handling
    - Returns `ServiceResult` with error code `TRANSACTION_FAILED` on exception
    - _Requirements: 4.1, 4.2, 4.4_

  - [ ] 6.2 Refactor `_update_active_pointer()` to return a TransactWrite operation dict
    - Instead of performing a direct `put_item`, return the pointer item dict suitable for inclusion in a TransactWrite `Put` operation
    - Keep backward compatibility by adding an `execute` parameter (default True) — when True, performs the put directly (existing behavior); when False, returns the operation dict
    - _Requirements: 4.1, 4.3_

- [ ] 7. Implement `renew_subscription()` main method
  - [ ] 7.1 Add `renew_subscription()` to `SubscriptionService`
    - Accepts `subscription_id: str`, returns `ServiceResult[Subscription]`
    - Flow: get active subscription → `check_renewal_eligibility()` → `_compute_idempotency_key()` → `_find_existing_renewal()` (return existing if found) → `_calculate_contiguous_period()` → `_build_renewal_subscription()` → build TransactWrite operations (Put new sub, Update old sub → expired, Put pointer) → `_execute_transact_write()`
    - Return `ServiceResult` with new subscription on success
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 4.1, 4.2, 5.2, 5.3_

  - [ ]* 7.2 Write unit tests for `renew_subscription()` happy path and error paths
    - Test happy path with mocked DynamoDB returns new subscription
    - Test idempotency returns existing subscription with "already processed" message
    - Test transaction failure returns `TRANSACTION_FAILED`
    - Test ineligible subscription triggers no DynamoDB writes
    - Add to `geek-cafe-saas-sdk/tests/test_subscription_renewal.py`
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 4.2, 5.2, 5.3_

- [ ] 8. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 9. Upgrade `activate_subscription()` for atomic TransactWrite and superseded handling
  - [ ] 9.1 Modify `activate_subscription()` to use TransactWrite and mark old subscription as superseded
    - Replace sequential writes with a single TransactWrite containing: Put new subscription, Update old subscription → `"superseded"` with notes `"Superseded by: <new_id>"`, Put active pointer
    - Use `_update_active_pointer(execute=False)` to get the pointer operation dict
    - Use `_execute_transact_write()` for the atomic commit
    - Keep tenant `plan_tier` update after the transaction (non-critical)
    - _Requirements: 4.3, 6.1, 6.2_

  - [ ]* 9.2 Write property test for superseded invariants on mid-cycle upgrade (Property 5)
    - **Property 5: Superseded invariants on mid-cycle upgrade**
    - Generate random active subscriptions; mock DynamoDB; call `activate_subscription` with new plan; verify old subscription status is `"superseded"` and notes contain `"Superseded by: <new_id>"`
    - Add to `geek-cafe-saas-sdk/tests/properties/test_subscription_renewal.py`
    - **Validates: Requirements 6.1, 6.2**

  - [ ]* 9.3 Write unit test verifying `activate_subscription` calls `transact_write_items`
    - Mock DynamoDB and verify `transact_write_items` is called instead of sequential writes
    - Add to `geek-cafe-saas-sdk/tests/test_subscription_renewal.py`
    - _Requirements: 4.3_

- [ ] 10. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific examples and edge cases
- All code is Python; property tests use Hypothesis
