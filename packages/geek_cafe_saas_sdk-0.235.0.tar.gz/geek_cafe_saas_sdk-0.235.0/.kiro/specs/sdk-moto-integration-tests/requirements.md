# Requirements Document

## Introduction

The geek-cafe-saas-sdk currently tests `UserService` with `MagicMock` and patching, which misses real integration issues between DynamoDB records and Cognito user identities. The SDK's `tests/conftest.py` already provides moto-backed DynamoDB and S3 fixtures, but lacks Cognito user pool fixtures and integration tests that exercise the full user CRUD lifecycle through the Lambda handler layer.

This feature adds moto-based Cognito fixtures to the existing test infrastructure and creates integration tests that call Lambda handlers with realistic API Gateway event payloads. Each test verifies that both the DynamoDB record and the Cognito user are created, updated, disabled, or re-enabled correctly — using moto's emulated AWS services instead of mocks or patches.

The Aplos-SaaS-Core project's `tests/conftest.py` provides a reference pattern for creating moto-backed Cognito user pools with custom attributes (`custom:user_id`, `custom:tenant_id`, `custom:roles`).

## Glossary

- **Test_Conftest**: The shared pytest configuration file (`geek-cafe-saas-sdk/tests/conftest.py`) that provides session-scoped environment setup, moto-backed DynamoDB/S3 fixtures, and request context fixtures.
- **Cognito_User_Pool_Fixture**: A pytest fixture that creates a moto-backed Cognito user pool with the custom attribute schema (`custom:user_id`, `custom:tenant_id`, `custom:roles`) required by `CognitoUtility`.
- **CognitoUtility_Fixture**: A pytest fixture that provides a `CognitoUtility` instance wired to the moto-backed Cognito service, suitable for injection into `UserService`.
- **UserService**: The SDK service class (`geek_cafe_saas_sdk.modules.users.services.user_service.UserService`) that manages user CRUD operations against DynamoDB with optional Cognito synchronization.
- **CognitoUtility**: The SDK utility class (`geek_cafe_saas_sdk.utilities.cognito_utility.CognitoUtility`) that wraps AWS Cognito Identity Provider API calls.
- **Lambda_Handler**: The Lambda entry point functions (create, update, delete) in `geek_cafe_saas_sdk.modules.users.handlers.users` that accept API Gateway event payloads and delegate to `UserService`.
- **API_Gateway_Event**: A dictionary matching the AWS API Gateway proxy integration event format, containing `httpMethod`, `body`, `pathParameters`, `requestContext` with `authorizer.claims`, and `headers`.
- **Moto_Mock_AWS**: The `moto.mock_aws` decorator/context manager that intercepts boto3 calls and routes them to in-memory emulated AWS services.
- **DynamoDB_Record**: A user item stored in the moto-backed DynamoDB table with primary key (`pk`, `sk`) and GSI attributes.
- **Cognito_User**: A user identity in the moto-backed Cognito user pool, identified by email (username) and carrying custom attributes.
- **Soft_Delete**: The SDK's deletion pattern where `deleted_utc_ts` is set on the DynamoDB_Record rather than physically removing the item.
- **Moto_Dependency**: The `moto` package used for AWS service emulation in tests, currently installed in the virtual environment but not declared in `pyproject.toml`.

## Requirements

### Requirement 1: Declare Moto as a Test Dependency

**User Story:** As an SDK developer, I want `moto` declared as a test dependency in `pyproject.toml`, so that the test environment is reproducible and new contributors can install all test dependencies from the project manifest.

#### Acceptance Criteria

1. THE pyproject.toml SHALL declare `moto` in a `test` optional-dependencies group alongside other test dependencies (`pytest`, `python-dotenv`, `hypothesis`, `moto`).
2. WHEN a developer runs `pip install -e ".[test]"`, THE package manager SHALL install `moto` and all other test dependencies.

### Requirement 2: Add COGNITO_USER_POOL_ID to Test Environment

**User Story:** As a test author, I want the `COGNITO_USER_POOL_ID` environment variable available in the test environment, so that `UserService` can auto-detect Cognito configuration during integration tests.

#### Acceptance Criteria

1. THE `.env.mock` file SHALL contain a `COGNITO_USER_POOL_ID` variable with a placeholder value.
2. WHEN the `load_test_environment` fixture loads `.env.mock`, THE `COGNITO_USER_POOL_ID` environment variable SHALL be available to all tests via `os.getenv`.

### Requirement 3: Create Cognito User Pool Fixture

**User Story:** As a test author, I want a pytest fixture that creates a moto-backed Cognito user pool with the SDK's custom attribute schema, so that integration tests can exercise real Cognito operations without hitting AWS.

#### Acceptance Criteria

1. THE Cognito_User_Pool_Fixture SHALL create a Cognito user pool using `boto3.client("cognito-idp")` within a `moto.mock_aws` context.
2. THE Cognito_User_Pool_Fixture SHALL register the custom attributes `custom:user_id` (String, Mutable), `custom:tenant_id` (String, Mutable), and `custom:roles` (String, Mutable) on the user pool schema.
3. THE Cognito_User_Pool_Fixture SHALL set `email` as a required attribute with `AutoVerifiedAttributes` including `email`.
4. THE Cognito_User_Pool_Fixture SHALL yield the `user_pool_id` string returned by the `create_user_pool` API response.
5. THE Cognito_User_Pool_Fixture SHALL share the same `moto.mock_aws` context as the DynamoDB fixture so that a single test can operate on both services.

### Requirement 4: Create CognitoUtility Fixture

**User Story:** As a test author, I want a pytest fixture that provides a `CognitoUtility` instance connected to the moto-backed Cognito, so that I can inject it into `UserService` for integration tests.

#### Acceptance Criteria

1. THE CognitoUtility_Fixture SHALL instantiate a `CognitoUtility` with `aws_region` set to the test region (`us-east-1`).
2. THE CognitoUtility_Fixture SHALL operate within the same `moto.mock_aws` context as the Cognito_User_Pool_Fixture and DynamoDB fixture.
3. WHEN the CognitoUtility_Fixture is injected into a `UserService`, THE `UserService` SHALL be able to call `admin_create_user`, `search_cognito`, `admin_disable_user`, and `admin_enable_user` against the moto-backed Cognito service.

### Requirement 5: Create UserService Integration Fixture

**User Story:** As a test author, I want a pytest fixture that provides a fully wired `UserService` with both moto-backed DynamoDB and Cognito, so that integration tests can exercise the complete user lifecycle.

#### Acceptance Criteria

1. THE UserService integration fixture SHALL create a `UserService` instance with `dynamodb` from the moto-backed DynamoDB fixture, `cognito_utility` from the CognitoUtility_Fixture, and `user_pool_id` from the Cognito_User_Pool_Fixture.
2. THE UserService integration fixture SHALL accept a `request_context` parameter (defaulting to a tenant admin context) so that tests can exercise different authorization scenarios.
3. THE UserService integration fixture SHALL use the standard test table name (`test-geek-cafe-table`) and the standard table schema with 10 GSIs.

### Requirement 6: Test Create User via Lambda Handler

**User Story:** As an SDK developer, I want an integration test that creates a user through the Lambda handler and verifies both the DynamoDB record and Cognito user exist, so that I can confirm the full create flow works end-to-end.

#### Acceptance Criteria

1. WHEN the create Lambda_Handler is invoked with a valid API_Gateway_Event containing user data (email, first_name, last_name), THE Lambda_Handler SHALL return a response with HTTP status 201.
2. WHEN the create Lambda_Handler returns successfully, THE DynamoDB table SHALL contain a user record with the provided email, first_name, and last_name.
3. WHEN the create Lambda_Handler returns successfully, THE Cognito user pool SHALL contain a user with the provided email as the username.
4. WHEN the create Lambda_Handler returns successfully, THE Cognito user SHALL have `custom:user_id` set to the created user's ID, `custom:tenant_id` set to the tenant ID, and `custom:roles` set to the user's roles.

### Requirement 7: Test Update User via Lambda Handler

**User Story:** As an SDK developer, I want an integration test that updates a user through the Lambda handler and verifies both the DynamoDB record and Cognito attributes are synced, so that I can confirm the update flow works end-to-end.

#### Acceptance Criteria

1. WHEN the update Lambda_Handler is invoked with a valid API_Gateway_Event containing updated roles, THE Lambda_Handler SHALL return a response with HTTP status 200.
2. WHEN the update Lambda_Handler returns successfully, THE DynamoDB_Record SHALL reflect the updated roles.
3. WHEN the update Lambda_Handler returns successfully, THE Cognito_User's `custom:roles` attribute SHALL reflect the updated roles.

### Requirement 8: Test Delete User via Lambda Handler

**User Story:** As an SDK developer, I want an integration test that deletes a user through the Lambda handler and verifies the DynamoDB record is soft-deleted and the Cognito user is disabled, so that I can confirm the delete flow works end-to-end.

#### Acceptance Criteria

1. WHEN the delete Lambda_Handler is invoked with a valid API_Gateway_Event for an existing user, THE Lambda_Handler SHALL return a response with HTTP status 204.
2. WHEN the delete Lambda_Handler returns successfully, THE DynamoDB_Record SHALL have a non-null `deleted_utc_ts` field (Soft_Delete).
3. WHEN the delete Lambda_Handler returns successfully, THE Cognito_User SHALL be in a disabled state (Enabled=False).

### Requirement 9: Test Restore User Re-enables Cognito

**User Story:** As an SDK developer, I want an integration test that restores a soft-deleted user and verifies the Cognito user is re-enabled, so that I can confirm the restore flow works end-to-end.

#### Acceptance Criteria

1. WHEN `UserService.restore_user` is called for a soft-deleted user, THE UserService SHALL return a successful ServiceResult.
2. WHEN the restore succeeds, THE DynamoDB_Record SHALL have `deleted_utc_ts` set to None.
3. WHEN the restore succeeds, THE Cognito_User SHALL be in an enabled state (Enabled=True).

### Requirement 10: Test Create User Rolls Back on Cognito Failure

**User Story:** As an SDK developer, I want an integration test that verifies the DynamoDB record is rolled back when Cognito user creation fails, so that I can confirm the rollback mechanism prevents orphaned records.

#### Acceptance Criteria

1. WHEN `UserService.create` is called and the Cognito `admin_create_user` call fails (e.g., due to a duplicate email already in Cognito), THE UserService SHALL raise the Cognito exception.
2. WHEN the Cognito creation fails and the exception is raised, THE DynamoDB table SHALL NOT contain a user record for the attempted creation (rollback completed).

### Requirement 11: Test Update Creates Cognito User When Missing

**User Story:** As an SDK developer, I want an integration test that verifies updating a user who has no Cognito identity causes a Cognito user to be created, so that I can confirm the create-if-missing behavior works for pre-existing DynamoDB-only users.

#### Acceptance Criteria

1. WHEN `UserService.update` is called for a user that exists in DynamoDB but has no corresponding Cognito_User, THE UserService SHALL create a Cognito_User for that email.
2. WHEN the update completes, THE Cognito user pool SHALL contain a user with the email of the updated user and the correct `custom:user_id` and `custom:tenant_id` attributes.
