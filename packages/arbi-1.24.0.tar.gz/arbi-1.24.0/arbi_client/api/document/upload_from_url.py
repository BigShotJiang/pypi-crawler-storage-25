from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.upload_documents_response import UploadDocumentsResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    urls: list[str],
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_urls = urls


    params["urls"] = json_urls

    params["shared"] = shared

    json_config_ext_id: None | str | Unset
    if isinstance(config_ext_id, Unset):
        json_config_ext_id = UNSET
    else:
        json_config_ext_id = config_ext_id
    params["config_ext_id"] = json_config_ext_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/document/upload-url",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | UploadDocumentsResponse | None:
    if response.status_code == 200:
        response_200 = UploadDocumentsResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    urls: list[str],
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,

) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    """ Upload Documents From Url

     Download and upload documents from URLs to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        urls (list[str]): URLs to download documents from
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadDocumentsResponse]
     """


    kwargs = _get_kwargs(
        urls=urls,
shared=shared,
config_ext_id=config_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    urls: list[str],
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,

) -> HTTPValidationError | UploadDocumentsResponse | None:
    """ Upload Documents From Url

     Download and upload documents from URLs to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        urls (list[str]): URLs to download documents from
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadDocumentsResponse
     """


    return sync_detailed(
        client=client,
urls=urls,
shared=shared,
config_ext_id=config_ext_id,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    urls: list[str],
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,

) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    """ Upload Documents From Url

     Download and upload documents from URLs to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        urls (list[str]): URLs to download documents from
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadDocumentsResponse]
     """


    kwargs = _get_kwargs(
        urls=urls,
shared=shared,
config_ext_id=config_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    urls: list[str],
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,

) -> HTTPValidationError | UploadDocumentsResponse | None:
    """ Upload Documents From Url

     Download and upload documents from URLs to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        urls (list[str]): URLs to download documents from
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadDocumentsResponse
     """


    return (await asyncio_detailed(
        client=client,
urls=urls,
shared=shared,
config_ext_id=config_ext_id,

    )).parsed
