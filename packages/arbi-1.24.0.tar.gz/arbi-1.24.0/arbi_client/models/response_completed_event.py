from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.response_completed_payload import ResponseCompletedPayload
  from ..models.token_budget_context import TokenBudgetContext





T = TypeVar("T", bound="ResponseCompletedEvent")



@_attrs_define
class ResponseCompletedEvent:
    """ OpenAI response.completed: terminal event with full response.

        Attributes:
            sequence_number (int): Monotonic sequence number for event ordering
            response (ResponseCompletedPayload): The ``response`` dict in a ``response.completed`` SSE event.
            t (float | None | Unset): Seconds elapsed since stream start.
            type_ (Literal['response.completed'] | Unset):  Default: 'response.completed'.
            context (None | TokenBudgetContext | Unset): Final token budget context snapshot.
     """

    sequence_number: int
    response: ResponseCompletedPayload
    t: float | None | Unset = UNSET
    type_: Literal['response.completed'] | Unset = 'response.completed'
    context: None | TokenBudgetContext | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.token_budget_context import TokenBudgetContext
        from ..models.response_completed_payload import ResponseCompletedPayload
        sequence_number = self.sequence_number

        response = self.response.to_dict()

        t: float | None | Unset
        if isinstance(self.t, Unset):
            t = UNSET
        else:
            t = self.t

        type_ = self.type_

        context: dict[str, Any] | None | Unset
        if isinstance(self.context, Unset):
            context = UNSET
        elif isinstance(self.context, TokenBudgetContext):
            context = self.context.to_dict()
        else:
            context = self.context


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "sequence_number": sequence_number,
            "response": response,
        })
        if t is not UNSET:
            field_dict["t"] = t
        if type_ is not UNSET:
            field_dict["type"] = type_
        if context is not UNSET:
            field_dict["context"] = context

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.response_completed_payload import ResponseCompletedPayload
        from ..models.token_budget_context import TokenBudgetContext
        d = dict(src_dict)
        sequence_number = d.pop("sequence_number")

        response = ResponseCompletedPayload.from_dict(d.pop("response"))




        def _parse_t(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        t = _parse_t(d.pop("t", UNSET))


        type_ = cast(Literal['response.completed'] | Unset , d.pop("type", UNSET))
        if type_ != 'response.completed'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'response.completed', got '{type_}'")

        def _parse_context(data: object) -> None | TokenBudgetContext | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                context_type_0 = TokenBudgetContext.from_dict(data)



                return context_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TokenBudgetContext | Unset, data)

        context = _parse_context(d.pop("context", UNSET))


        response_completed_event = cls(
            sequence_number=sequence_number,
            response=response,
            t=t,
            type_=type_,
            context=context,
        )


        response_completed_event.additional_properties = d
        return response_completed_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
