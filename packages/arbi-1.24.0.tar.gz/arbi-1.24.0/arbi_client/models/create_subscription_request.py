from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="CreateSubscriptionRequest")



@_attrs_define
class CreateSubscriptionRequest:
    """ Request to create a new subscription checkout session.

        Attributes:
            price_id (str):
     """

    price_id: str





    def to_dict(self) -> dict[str, Any]:
        price_id = self.price_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "price_id": price_id,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        price_id = d.pop("price_id")

        create_subscription_request = cls(
            price_id=price_id,
        )

        return create_subscription_request

