from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.non_developer_config_agents import NonDeveloperConfigAgents
  from ..models.non_developer_upload_config import NonDeveloperUploadConfig





T = TypeVar("T", bound="NonDeveloperConfig")



@_attrs_define
class NonDeveloperConfig:
    """ Limited configuration response for non-developer users

        Attributes:
            agents (NonDeveloperConfigAgents):
            upload (NonDeveloperUploadConfig | None | Unset):
     """

    agents: NonDeveloperConfigAgents
    upload: NonDeveloperUploadConfig | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.non_developer_upload_config import NonDeveloperUploadConfig
        from ..models.non_developer_config_agents import NonDeveloperConfigAgents
        agents = self.agents.to_dict()

        upload: dict[str, Any] | None | Unset
        if isinstance(self.upload, Unset):
            upload = UNSET
        elif isinstance(self.upload, NonDeveloperUploadConfig):
            upload = self.upload.to_dict()
        else:
            upload = self.upload


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "Agents": agents,
        })
        if upload is not UNSET:
            field_dict["Upload"] = upload

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.non_developer_config_agents import NonDeveloperConfigAgents
        from ..models.non_developer_upload_config import NonDeveloperUploadConfig
        d = dict(src_dict)
        agents = NonDeveloperConfigAgents.from_dict(d.pop("Agents"))




        def _parse_upload(data: object) -> NonDeveloperUploadConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                upload_type_0 = NonDeveloperUploadConfig.from_dict(data)



                return upload_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NonDeveloperUploadConfig | None | Unset, data)

        upload = _parse_upload(d.pop("Upload", UNSET))


        non_developer_config = cls(
            agents=agents,
            upload=upload,
        )


        non_developer_config.additional_properties = d
        return non_developer_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
