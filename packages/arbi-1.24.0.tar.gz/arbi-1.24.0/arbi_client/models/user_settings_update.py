from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.table_view import TableView
  from ..models.trial_update import TrialUpdate





T = TypeVar("T", bound="UserSettingsUpdate")



@_attrs_define
class UserSettingsUpdate:
    """ User settings update request - allows partial updates.

    Note: stripe_customer_id and status are not patchable.
    trial_expires can only be set once (to start trial).

        Attributes:
            subscription (None | TrialUpdate | Unset):
            pinned_workspaces (list[str] | None | Unset):
            pinned_templates (list[str] | None | Unset):
            tableviews (list[TableView] | None | Unset):
            show_document_navigator (bool | None | Unset):
            show_thread_visualization (bool | None | Unset):
            show_security_settings (bool | None | Unset):
            show_invite_tab (bool | None | Unset):
            show_help_page (bool | None | Unset):
            show_templates (bool | None | Unset):
            show_pa_mode (bool | None | Unset):
            show_agent_sessions (bool | None | Unset):
            hide_online_status (bool | None | Unset):
            muted_users (list[str] | None | Unset):
            premium_model (None | str | Unset):
            picture (None | str | Unset):
     """

    subscription: None | TrialUpdate | Unset = UNSET
    pinned_workspaces: list[str] | None | Unset = UNSET
    pinned_templates: list[str] | None | Unset = UNSET
    tableviews: list[TableView] | None | Unset = UNSET
    show_document_navigator: bool | None | Unset = UNSET
    show_thread_visualization: bool | None | Unset = UNSET
    show_security_settings: bool | None | Unset = UNSET
    show_invite_tab: bool | None | Unset = UNSET
    show_help_page: bool | None | Unset = UNSET
    show_templates: bool | None | Unset = UNSET
    show_pa_mode: bool | None | Unset = UNSET
    show_agent_sessions: bool | None | Unset = UNSET
    hide_online_status: bool | None | Unset = UNSET
    muted_users: list[str] | None | Unset = UNSET
    premium_model: None | str | Unset = UNSET
    picture: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.table_view import TableView
        from ..models.trial_update import TrialUpdate
        subscription: dict[str, Any] | None | Unset
        if isinstance(self.subscription, Unset):
            subscription = UNSET
        elif isinstance(self.subscription, TrialUpdate):
            subscription = self.subscription.to_dict()
        else:
            subscription = self.subscription

        pinned_workspaces: list[str] | None | Unset
        if isinstance(self.pinned_workspaces, Unset):
            pinned_workspaces = UNSET
        elif isinstance(self.pinned_workspaces, list):
            pinned_workspaces = self.pinned_workspaces


        else:
            pinned_workspaces = self.pinned_workspaces

        pinned_templates: list[str] | None | Unset
        if isinstance(self.pinned_templates, Unset):
            pinned_templates = UNSET
        elif isinstance(self.pinned_templates, list):
            pinned_templates = self.pinned_templates


        else:
            pinned_templates = self.pinned_templates

        tableviews: list[dict[str, Any]] | None | Unset
        if isinstance(self.tableviews, Unset):
            tableviews = UNSET
        elif isinstance(self.tableviews, list):
            tableviews = []
            for tableviews_type_0_item_data in self.tableviews:
                tableviews_type_0_item = tableviews_type_0_item_data.to_dict()
                tableviews.append(tableviews_type_0_item)


        else:
            tableviews = self.tableviews

        show_document_navigator: bool | None | Unset
        if isinstance(self.show_document_navigator, Unset):
            show_document_navigator = UNSET
        else:
            show_document_navigator = self.show_document_navigator

        show_thread_visualization: bool | None | Unset
        if isinstance(self.show_thread_visualization, Unset):
            show_thread_visualization = UNSET
        else:
            show_thread_visualization = self.show_thread_visualization

        show_security_settings: bool | None | Unset
        if isinstance(self.show_security_settings, Unset):
            show_security_settings = UNSET
        else:
            show_security_settings = self.show_security_settings

        show_invite_tab: bool | None | Unset
        if isinstance(self.show_invite_tab, Unset):
            show_invite_tab = UNSET
        else:
            show_invite_tab = self.show_invite_tab

        show_help_page: bool | None | Unset
        if isinstance(self.show_help_page, Unset):
            show_help_page = UNSET
        else:
            show_help_page = self.show_help_page

        show_templates: bool | None | Unset
        if isinstance(self.show_templates, Unset):
            show_templates = UNSET
        else:
            show_templates = self.show_templates

        show_pa_mode: bool | None | Unset
        if isinstance(self.show_pa_mode, Unset):
            show_pa_mode = UNSET
        else:
            show_pa_mode = self.show_pa_mode

        show_agent_sessions: bool | None | Unset
        if isinstance(self.show_agent_sessions, Unset):
            show_agent_sessions = UNSET
        else:
            show_agent_sessions = self.show_agent_sessions

        hide_online_status: bool | None | Unset
        if isinstance(self.hide_online_status, Unset):
            hide_online_status = UNSET
        else:
            hide_online_status = self.hide_online_status

        muted_users: list[str] | None | Unset
        if isinstance(self.muted_users, Unset):
            muted_users = UNSET
        elif isinstance(self.muted_users, list):
            muted_users = self.muted_users


        else:
            muted_users = self.muted_users

        premium_model: None | str | Unset
        if isinstance(self.premium_model, Unset):
            premium_model = UNSET
        else:
            premium_model = self.premium_model

        picture: None | str | Unset
        if isinstance(self.picture, Unset):
            picture = UNSET
        else:
            picture = self.picture


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if subscription is not UNSET:
            field_dict["subscription"] = subscription
        if pinned_workspaces is not UNSET:
            field_dict["pinned_workspaces"] = pinned_workspaces
        if pinned_templates is not UNSET:
            field_dict["pinned_templates"] = pinned_templates
        if tableviews is not UNSET:
            field_dict["tableviews"] = tableviews
        if show_document_navigator is not UNSET:
            field_dict["show_document_navigator"] = show_document_navigator
        if show_thread_visualization is not UNSET:
            field_dict["show_thread_visualization"] = show_thread_visualization
        if show_security_settings is not UNSET:
            field_dict["show_security_settings"] = show_security_settings
        if show_invite_tab is not UNSET:
            field_dict["show_invite_tab"] = show_invite_tab
        if show_help_page is not UNSET:
            field_dict["show_help_page"] = show_help_page
        if show_templates is not UNSET:
            field_dict["show_templates"] = show_templates
        if show_pa_mode is not UNSET:
            field_dict["show_pa_mode"] = show_pa_mode
        if show_agent_sessions is not UNSET:
            field_dict["show_agent_sessions"] = show_agent_sessions
        if hide_online_status is not UNSET:
            field_dict["hide_online_status"] = hide_online_status
        if muted_users is not UNSET:
            field_dict["muted_users"] = muted_users
        if premium_model is not UNSET:
            field_dict["premium_model"] = premium_model
        if picture is not UNSET:
            field_dict["picture"] = picture

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.table_view import TableView
        from ..models.trial_update import TrialUpdate
        d = dict(src_dict)
        def _parse_subscription(data: object) -> None | TrialUpdate | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                subscription_type_0 = TrialUpdate.from_dict(data)



                return subscription_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TrialUpdate | Unset, data)

        subscription = _parse_subscription(d.pop("subscription", UNSET))


        def _parse_pinned_workspaces(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                pinned_workspaces_type_0 = cast(list[str], data)

                return pinned_workspaces_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        pinned_workspaces = _parse_pinned_workspaces(d.pop("pinned_workspaces", UNSET))


        def _parse_pinned_templates(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                pinned_templates_type_0 = cast(list[str], data)

                return pinned_templates_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        pinned_templates = _parse_pinned_templates(d.pop("pinned_templates", UNSET))


        def _parse_tableviews(data: object) -> list[TableView] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tableviews_type_0 = []
                _tableviews_type_0 = data
                for tableviews_type_0_item_data in (_tableviews_type_0):
                    tableviews_type_0_item = TableView.from_dict(tableviews_type_0_item_data)



                    tableviews_type_0.append(tableviews_type_0_item)

                return tableviews_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TableView] | None | Unset, data)

        tableviews = _parse_tableviews(d.pop("tableviews", UNSET))


        def _parse_show_document_navigator(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_document_navigator = _parse_show_document_navigator(d.pop("show_document_navigator", UNSET))


        def _parse_show_thread_visualization(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_thread_visualization = _parse_show_thread_visualization(d.pop("show_thread_visualization", UNSET))


        def _parse_show_security_settings(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_security_settings = _parse_show_security_settings(d.pop("show_security_settings", UNSET))


        def _parse_show_invite_tab(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_invite_tab = _parse_show_invite_tab(d.pop("show_invite_tab", UNSET))


        def _parse_show_help_page(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_help_page = _parse_show_help_page(d.pop("show_help_page", UNSET))


        def _parse_show_templates(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_templates = _parse_show_templates(d.pop("show_templates", UNSET))


        def _parse_show_pa_mode(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_pa_mode = _parse_show_pa_mode(d.pop("show_pa_mode", UNSET))


        def _parse_show_agent_sessions(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_agent_sessions = _parse_show_agent_sessions(d.pop("show_agent_sessions", UNSET))


        def _parse_hide_online_status(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        hide_online_status = _parse_hide_online_status(d.pop("hide_online_status", UNSET))


        def _parse_muted_users(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                muted_users_type_0 = cast(list[str], data)

                return muted_users_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        muted_users = _parse_muted_users(d.pop("muted_users", UNSET))


        def _parse_premium_model(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        premium_model = _parse_premium_model(d.pop("premium_model", UNSET))


        def _parse_picture(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        picture = _parse_picture(d.pop("picture", UNSET))


        user_settings_update = cls(
            subscription=subscription,
            pinned_workspaces=pinned_workspaces,
            pinned_templates=pinned_templates,
            tableviews=tableviews,
            show_document_navigator=show_document_navigator,
            show_thread_visualization=show_thread_visualization,
            show_security_settings=show_security_settings,
            show_invite_tab=show_invite_tab,
            show_help_page=show_help_page,
            show_templates=show_templates,
            show_pa_mode=show_pa_mode,
            show_agent_sessions=show_agent_sessions,
            hide_online_status=hide_online_status,
            muted_users=muted_users,
            premium_model=premium_model,
            picture=picture,
        )


        user_settings_update.additional_properties = d
        return user_settings_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
