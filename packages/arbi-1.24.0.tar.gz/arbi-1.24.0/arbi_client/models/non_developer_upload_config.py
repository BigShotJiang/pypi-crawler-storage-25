from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="NonDeveloperUploadConfig")



@_attrs_define
class NonDeveloperUploadConfig:
    """ Upload-related settings exposed to non-developer users.

        Attributes:
            skip_duplicates (bool):
            auto_rename (bool):
            auto_rename_instruction (str):
            metadata_tags (list[Any]):
     """

    skip_duplicates: bool
    auto_rename: bool
    auto_rename_instruction: str
    metadata_tags: list[Any]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        skip_duplicates = self.skip_duplicates

        auto_rename = self.auto_rename

        auto_rename_instruction = self.auto_rename_instruction

        metadata_tags = self.metadata_tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "SKIP_DUPLICATES": skip_duplicates,
            "AUTO_RENAME": auto_rename,
            "AUTO_RENAME_INSTRUCTION": auto_rename_instruction,
            "METADATA_TAGS": metadata_tags,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        skip_duplicates = d.pop("SKIP_DUPLICATES")

        auto_rename = d.pop("AUTO_RENAME")

        auto_rename_instruction = d.pop("AUTO_RENAME_INSTRUCTION")

        metadata_tags = cast(list[Any], d.pop("METADATA_TAGS"))


        non_developer_upload_config = cls(
            skip_duplicates=skip_duplicates,
            auto_rename=auto_rename,
            auto_rename_instruction=auto_rename_instruction,
            metadata_tags=metadata_tags,
        )


        non_developer_upload_config.additional_properties = d
        return non_developer_upload_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
