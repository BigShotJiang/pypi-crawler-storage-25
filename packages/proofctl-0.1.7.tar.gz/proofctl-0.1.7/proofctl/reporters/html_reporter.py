from __future__ import annotations

import html
import json
from collections import Counter
from datetime import datetime, timezone

from ..models import Finding, Severity

_SEV_COLOR = {
    "ERROR":   "#ef4444",
    "WARNING": "#f59e0b",
    "INFO":    "#6b7280",
}

_CSS = """
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  background:#0f172a;color:#e2e8f0;font-size:14px;line-height:1.5}
a{color:#60a5fa}
header{padding:24px 32px 0;border-bottom:1px solid #1e293b}
header h1{font-size:22px;font-weight:700;color:#f8fafc;letter-spacing:-.3px}
header h1 span{color:#60a5fa}
header p{color:#64748b;font-size:12px;margin-top:2px;padding-bottom:16px}

.cards{display:flex;gap:12px;padding:24px 32px}
.card{background:#1e293b;border:1px solid #334155;border-radius:8px;
  padding:16px 24px;min-width:110px}
.card .n{font-size:28px;font-weight:700;line-height:1}
.card .l{font-size:11px;font-weight:600;letter-spacing:.6px;
  text-transform:uppercase;margin-top:4px;opacity:.7}
.card.total .n{color:#f8fafc}
.card.error .n{color:#ef4444}
.card.warning .n{color:#f59e0b}
.card.info .n{color:#9ca3af}

.toolbar{display:flex;align-items:center;gap:10px;
  padding:0 32px 16px;flex-wrap:wrap}
#search{background:#1e293b;border:1px solid #334155;border-radius:6px;
  color:#e2e8f0;font-size:13px;padding:6px 12px;width:280px;outline:none}
#search:focus{border-color:#60a5fa}
#search::placeholder{color:#475569}
.sev-btn{background:#1e293b;border:1px solid #334155;border-radius:6px;
  color:#94a3b8;cursor:pointer;font-size:12px;font-weight:600;
  letter-spacing:.4px;padding:5px 12px;text-transform:uppercase;transition:all .15s}
.sev-btn:hover{border-color:#60a5fa;color:#f8fafc}
.sev-btn.active{color:#0f172a}
.sev-btn[data-sev="ALL"].active{background:#60a5fa;border-color:#60a5fa;color:#0f172a}
.sev-btn[data-sev="ERROR"].active{background:#ef4444;border-color:#ef4444}
.sev-btn[data-sev="WARNING"].active{background:#f59e0b;border-color:#f59e0b}
.sev-btn[data-sev="INFO"].active{background:#6b7280;border-color:#6b7280}
#count-label{margin-left:auto;color:#475569;font-size:12px}

.wrap{padding:0 32px 40px;overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13px}
thead th{background:#1e293b;color:#94a3b8;font-size:11px;font-weight:600;
  letter-spacing:.5px;padding:8px 12px;text-align:left;
  text-transform:uppercase;white-space:nowrap;border-bottom:1px solid #334155}
tbody tr{border-bottom:1px solid #1e293b;transition:background .1s}
tbody tr:hover{background:#1e293b}
tbody tr.hidden{display:none}
td{padding:10px 12px;vertical-align:top}

.badge{border-radius:4px;font-size:10px;font-weight:700;
  letter-spacing:.5px;padding:2px 7px;text-transform:uppercase;white-space:nowrap}
.badge-ERROR{background:rgba(239,68,68,.15);color:#ef4444;border:1px solid rgba(239,68,68,.3)}
.badge-WARNING{background:rgba(245,158,11,.12);color:#f59e0b;border:1px solid rgba(245,158,11,.3)}
.badge-INFO{background:rgba(107,114,128,.15);color:#9ca3af;border:1px solid rgba(107,114,128,.3)}

.rule-id{color:#f8fafc;font-weight:600;font-family:'SF Mono',Consolas,monospace;font-size:12px}
.rule-name{color:#64748b;font-size:11px;margin-top:2px}
.loc{color:#60a5fa;font-family:'SF Mono',Consolas,monospace;font-size:12px}
.msg{color:#cbd5e1;margin-top:2px}
.hint{color:#475569;font-size:11px;margin-top:3px;font-style:italic}

.empty{padding:64px 32px;text-align:center;color:#475569;font-size:15px}
.empty span{font-size:32px;display:block;margin-bottom:8px}
"""

_JS = """
(function(){
  const rows = Array.from(document.querySelectorAll('tbody tr'));
  const searchEl = document.getElementById('search');
  const btns = Array.from(document.querySelectorAll('.sev-btn'));
  const countEl = document.getElementById('count-label');
  let activeSev = 'ALL';

  function update(){
    const q = searchEl.value.toLowerCase();
    let visible = 0;
    rows.forEach(r => {
      const sevMatch = activeSev === 'ALL' || r.dataset.sev === activeSev;
      const textMatch = !q || r.textContent.toLowerCase().includes(q);
      const show = sevMatch && textMatch;
      r.classList.toggle('hidden', !show);
      if(show) visible++;
    });
    countEl.textContent = visible + ' of ' + rows.length + ' finding' + (rows.length !== 1 ? 's' : '');
  }

  btns.forEach(b => b.addEventListener('click', () => {
    btns.forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    activeSev = b.dataset.sev;
    update();
  }));

  searchEl.addEventListener('input', update);
  update();
})();
"""


class HtmlReporter:
    def render(self, findings: list[Finding]) -> str:
        counts = Counter(f.severity for f in findings)
        total = len(findings)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

        cards = (
            f'<div class="card total"><div class="n">{total}</div>'
            f'<div class="l">Total</div></div>'
            f'<div class="card error"><div class="n">{counts[Severity.ERROR]}</div>'
            f'<div class="l">Error</div></div>'
            f'<div class="card warning"><div class="n">{counts[Severity.WARNING]}</div>'
            f'<div class="l">Warning</div></div>'
            f'<div class="card info"><div class="n">{counts[Severity.INFO]}</div>'
            f'<div class="l">Info</div></div>'
        )

        if not findings:
            body_content = '<div class="empty"><span>✓</span>No findings.</div>'
            table_section = ""
        else:
            rows = "\n".join(self._row(f) for f in findings)
            table_section = f"""
<div class="toolbar">
  <input id="search" placeholder="Search findings…" type="search" autocomplete="off">
  <button class="sev-btn active" data-sev="ALL">All</button>
  <button class="sev-btn" data-sev="ERROR">Error</button>
  <button class="sev-btn" data-sev="WARNING">Warning</button>
  <button class="sev-btn" data-sev="INFO">Info</button>
  <span id="count-label"></span>
</div>
<div class="wrap">
  <table>
    <thead>
      <tr>
        <th>Sev</th><th>Rule</th><th>Location</th><th>Finding</th>
      </tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>
</div>
<script>{_JS}</script>"""
            body_content = table_section

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>proofctl report</title>
<style>{_CSS}</style>
</head>
<body>
<header>
  <h1>proof<span>ctl</span></h1>
  <p>Generated {html.escape(ts)}</p>
</header>
<div class="cards">{cards}</div>
{body_content}
</body>
</html>"""

    @staticmethod
    def _row(f: Finding) -> str:
        sev = f.severity.label()
        loc = f"{f.file}:{f.line}" if f.line else f.file
        hint_html = (
            f'<div class="hint">→ {html.escape(f.hint)}</div>' if f.hint else ""
        )
        return (
            f'<tr data-sev="{sev}">'
            f'<td><span class="badge badge-{sev}">{sev}</span></td>'
            f'<td><div class="rule-id">{html.escape(f.rule_id)}</div>'
            f'<div class="rule-name">{html.escape(f.rule_name)}</div></td>'
            f'<td><div class="loc">{html.escape(loc)}</div></td>'
            f'<td><div class="msg">{html.escape(f.message)}</div>{hint_html}</td>'
            f'</tr>'
        )
