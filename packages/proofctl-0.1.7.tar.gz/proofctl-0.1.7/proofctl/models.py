from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class Severity(IntEnum):
    INFO = 0
    WARNING = 1
    ERROR = 2

    def label(self) -> str:
        return self.name

    @classmethod
    def from_str(cls, value: str) -> "Severity":
        try:
            return cls[value.upper()]
        except KeyError:
            valid = ", ".join(m.name for m in cls)
            raise ValueError(f"Invalid severity '{value}'. Valid values: {valid}")


@dataclass
class Finding:
    file: str
    line: int | None
    col: int | None
    rule_id: str       # e.g. "PROOFCTL-P-001"
    rule_name: str     # e.g. "Unimplemented function body"
    severity: Severity
    message: str
    hint: str = ""
    authority: str = ""
    docs_url: str = ""
    fixable: bool = False

    def dedup_key(self) -> tuple:
        return (self.file, self.line, self.col, self.rule_id)

    @property
    def family(self) -> str:
        """Returns the family letter, e.g. 'P' from 'PROOFCTL-P-001'."""
        parts = self.rule_id.split("-")
        return parts[1] if len(parts) >= 3 else ""
