from __future__ import annotations

import ast
import json
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker, DirectoryChecker

_CACHE_DIR = Path.home() / ".cache" / "proofctl" / "pypi"
_CACHE_TTL = 86_400  # 24 hours
_PYPI_TIMEOUT = 3    # seconds

# Packages known to be frequent AI hallucination targets
_HIGH_RISK_NAMES: frozenset[str] = frozenset({
    "boto4", "aiohttp-extras", "langchain-enhanced", "openai-utils",
    "anthropic-client", "fastapi-helpers", "requests-async",
    "sqlalchemy-utils-extended", "pydantic-extras", "flask-utils",
    "django-extras", "numpy-utils", "pandas-extras", "torch-utils",
    "tensorflow-extras", "scikit-learn-utils", "celery-extras",
})

# requirements.txt line: optional extras, then version specifier, then env markers / comments
_REQ_LINE_RE = re.compile(
    r"^\s*([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)"  # PEP 508 name
    r"(\[.*?\])?"                                         # optional extras
    r"\s*([~<>=!][^\s;#]*)?"                              # optional version specifier
)


def _parse_requirements(text: str) -> list[tuple[str, str | None, int]]:
    """Parse requirements.txt; returns (name, version_spec_or_None, lineno)."""
    results = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("-"):
            continue
        m = _REQ_LINE_RE.match(stripped)
        if m:
            results.append((m.group(1), m.group(4) or None, lineno))
    return results


def _parse_pyproject_deps(text: str) -> list[tuple[str, str | None, int]]:
    """Lightweight parser for [project] dependencies in pyproject.toml."""
    results = []
    in_deps = False
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if re.match(r"^dependencies\s*=\s*\[", stripped):
            in_deps = True
            continue
        if in_deps:
            if stripped.startswith("]"):
                in_deps = False
                continue
            # Quoted dep string: "boto4>=1.0" or 'boto4'
            m = re.match(r'["\']([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)(\[.*?\])?([^"\']*)["\']', stripped)
            if m:
                name = m.group(1)
                spec = m.group(4).strip() or None
                results.append((name, spec, lineno))
    return results

# mypy error patterns indicating phantom method calls
_MYPY_ATTR_RE = re.compile(
    r'^(.+):(\d+):\s+error:\s+(?:Item\s+"[^"]+"\s+of\s+)?"([^"]+)"\s+has\s+no\s+attribute\s+"([^"]+)"'
    r'|^(.+):(\d+):\s+error:\s+Module\s+"[^"]+"\s+has\s+no\s+attribute\s+"([^"]+)"'
)


def _normalize_pkg_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


# ── I-002 pattern matching ────────────────────────────────────────────────────

# Popular packages whose canonical PyPI name is the short form (no python- prefix).
# Only include packages where the base name alone is the correct PyPI identifier
# so that legitimate python-X packages (python-dateutil, python-dotenv, etc.)
# are NOT flagged — their base names (dateutil, dotenv) are absent from this set.
_POPULAR_PACKAGES: frozenset[str] = frozenset({
    # HTTP / web clients
    "requests", "httpx", "aiohttp", "urllib3",
    # Web frameworks
    "flask", "django", "fastapi", "starlette", "tornado", "sanic",
    # ASGI / WSGI servers
    "uvicorn", "gunicorn",
    # Data science
    "numpy", "pandas", "scipy", "matplotlib", "seaborn", "plotly",
    # ML / AI — highest hallucination density
    "torch", "tensorflow", "keras", "transformers", "openai", "anthropic",
    "langchain", "cohere", "datasets",
    # Databases / ORMs
    "sqlalchemy", "sqlalchemy-utils", "alembic",
    "pymongo", "redis", "psycopg2", "asyncpg", "motor", "pymysql",
    "elasticsearch",
    # Cloud
    "boto3",
    # Task queues
    "celery", "rq",
    # Validation / config
    "pydantic", "attrs", "marshmallow",
    # CLI / UI
    "click", "typer", "rich",
    # Auth / crypto
    "cryptography", "passlib", "bcrypt", "pyjwt", "authlib",
    # Testing
    "pytest", "hypothesis", "faker", "factory-boy",
    # Tooling
    "mypy", "ruff", "black", "isort", "bandit",
    # Serialization
    "orjson", "ujson",
    # Misc popular
    "pillow", "loguru", "tenacity", "jinja2", "pyyaml", "paramiko",
})

# Suffixes that carry no semantic meaning and that AI appends to real package names.
# Kept intentionally tight: words like "login", "cors", "mock", "toolbelt" are
# used in legitimate packages (flask-login, flask-cors, pytest-mock, requests-toolbelt)
# and must NOT appear here.
_SUSPICIOUS_SUFFIXES: frozenset[str] = frozenset({
    "utils", "extras", "helpers", "enhanced", "extended",
    "new", "plus", "pro",
})


def _suspicious_variant_of(name: str) -> str | None:
    """Return the probable real base package if name matches a hallucination pattern.

    Returns None when the name appears legitimate.  Four patterns checked:
      1. python-{X}   where X is a standalone popular package
      2. {X}-python / {X}-py
      3. {X}-{meaningless_suffix}  where suffix is in _SUSPICIOUS_SUFFIXES
      4. {X}{N}  where {X}{N-1} is a known popular package (e.g. boto4 → boto3)
    """
    n = _normalize_pkg_name(name)

    # Already a known popular package — not a variant.
    if n in _POPULAR_PACKAGES:
        return None

    # Pattern 1: python-{X} where X is a standalone popular package.
    # Intentionally excludes python-dateutil / python-dotenv because 'dateutil'
    # and 'dotenv' are not in _POPULAR_PACKAGES.
    if n.startswith("python-"):
        base = n[7:]
        if base in _POPULAR_PACKAGES:
            return base

    # Pattern 2: {X}-python or {X}-py
    for trailing in ("python", "py"):
        if n.endswith(f"-{trailing}"):
            base = n[:-(len(trailing) + 1)]
            if base in _POPULAR_PACKAGES:
                return base

    # Pattern 3: {X}-{suffix} where suffix is in _SUSPICIOUS_SUFFIXES.
    # rpartition splits at the LAST hyphen, so multi-hyphen names like
    # langchain-community-extras split as ("langchain-community", "extras").
    base, sep, suffix = n.rpartition("-")
    if sep and suffix in _SUSPICIOUS_SUFFIXES and base in _POPULAR_PACKAGES:
        return base

    # Pattern 4: digit-incremented variant.
    # Only flag when the predecessor name is explicitly in _POPULAR_PACKAGES
    # (prevents false positives from arbitrary numeric suffixes).
    m = re.match(r"^([a-z][a-z0-9-]*)(\d+)$", n)
    if m:
        base_name, digit = m.group(1), int(m.group(2))
        prev = f"{base_name}{digit - 1}"
        if prev in _POPULAR_PACKAGES:
            return prev

    return None


# Static fallback list: packages that don't fit the structural patterns above
# but are confirmed hallucination targets (keeps pattern rules tight).
_HIGH_RISK_DEPS: frozenset[str] = frozenset(
    _normalize_pkg_name(n) for n in _HIGH_RISK_NAMES
)


def _pypi_exists(name: str) -> bool | None:
    """Returns True if the package exists on PyPI, False if not, None on network error."""
    normalized = _normalize_pkg_name(name)
    cache_file = _CACHE_DIR / f"{normalized}.json"

    if cache_file.exists():
        try:
            data = json.loads(cache_file.read_text())
            if time.time() - data["ts"] < _CACHE_TTL:
                return data["exists"]
        except (json.JSONDecodeError, KeyError):
            pass

    try:
        from .. import __version__
        req = urllib.request.Request(
            f"https://pypi.org/simple/{normalized}/",
            headers={"User-Agent": f"proofctl/{__version__} (AI slop linter; security research)"},
        )
        urllib.request.urlopen(req, timeout=_PYPI_TIMEOUT)
        exists = True
    except urllib.error.HTTPError as e:
        exists = e.code != 404
    except Exception:
        return None  # network unavailable — skip, don't false-positive

    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(json.dumps({"exists": exists, "ts": time.time()}))
    return exists


def _stdlib_names() -> frozenset[str]:
    if hasattr(sys, "stdlib_module_names"):
        return frozenset(sys.stdlib_module_names)
    # Fallback for Python < 3.10: common stdlib modules
    return frozenset({
        "abc", "ast", "asyncio", "builtins", "collections", "contextlib",
        "copy", "dataclasses", "datetime", "enum", "fnmatch", "functools",
        "hashlib", "http", "importlib", "inspect", "io", "itertools", "json",
        "logging", "math", "operator", "os", "pathlib", "pickle", "platform",
        "queue", "random", "re", "shutil", "signal", "socket", "sqlite3",
        "string", "struct", "subprocess", "sys", "tempfile", "textwrap",
        "threading", "time", "traceback", "types", "typing", "unittest",
        "urllib", "uuid", "warnings", "weakref", "xml", "zipfile",
        "_thread", "__future__",
    })


def _local_packages(root: Path) -> frozenset[str]:
    """Top-level importable names within the scanned project."""
    names: set[str] = set()
    try:
        children = list(root.iterdir())
    except (OSError, PermissionError):
        return frozenset()
    for child in children:
        if child.is_dir() and (child / "__init__.py").exists():
            names.add(child.name)
        elif child.suffix == ".py" and child.name != "__init__.py":
            names.add(child.stem)
    # Also check src/ layout
    src = root / "src"
    if src.is_dir():
        for child in src.iterdir():
            if child.is_dir() and (child / "__init__.py").exists():
                names.add(child.name)
            elif child.suffix == ".py":
                names.add(child.stem)
    return frozenset(names)


def _extract_imports(tree: ast.Module) -> list[tuple[str, int, int]]:
    """Returns (top-level package name, lineno, col_offset) for every import."""
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                pkg = alias.name.split(".")[0]
                imports.append((pkg, node.lineno, node.col_offset))
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:  # skip relative imports
                pkg = node.module.split(".")[0]
                imports.append((pkg, node.lineno, node.col_offset))
    return imports


class ImportChecker(FileChecker):
    def __init__(
        self,
        local_namespaces: list[str] | None = None,
        extra_indexes: list[str] | None = None,
        check_pypi: bool = True,
    ) -> None:
        self._local_namespaces = tuple(local_namespaces or [])
        self._check_pypi = check_pypi
        self._stdlib = _stdlib_names()

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is not None:
            findings.extend(self._i001(path, tree))
        return findings

    def _i001(self, path: Path, tree: ast.Module) -> list[Finding]:
        # Infer project root by walking up to the nearest pyproject.toml / setup.py.
        # Stop at the filesystem root to avoid scanning /. Default to parent dir.
        root = path.parent
        candidate = root
        for _ in range(8):  # max 8 levels up
            if (candidate / "pyproject.toml").exists() or (candidate / "setup.py").exists():
                root = candidate
                break
            if candidate.parent == candidate:
                break
            candidate = candidate.parent
        local = _local_packages(root)

        findings = []
        seen: set[str] = set()

        for pkg, lineno, col in _extract_imports(tree):
            if pkg in seen:
                continue
            seen.add(pkg)

            if pkg in self._stdlib:
                continue
            if pkg in local:
                continue
            if self._local_namespaces and pkg.startswith(self._local_namespaces):
                continue

            if not self._check_pypi:
                continue

            exists = _pypi_exists(pkg)
            if exists is False:
                findings.append(Finding(
                    file=str(path),
                    line=lineno,
                    col=col,
                    rule_id="PROOFCTL-I-001",
                    rule_name="Hallucinated import",
                    severity=Severity.ERROR,
                    message=f"Package '{pkg}' not found on PyPI — possible AI hallucination",
                    hint=(
                        f"Verify '{pkg}' exists and is spelled correctly. "
                        "If it's a private package, add it to local_namespaces in .proofctl.yaml."
                    ),
                    authority="Slopsquatting research — AI-hallucinated package names",
                ))

        return findings


class DependencyChecker(DirectoryChecker):
    """PROOFCTL-I-002: Hallucination-prone package name in project dependency files."""

    def __init__(self, extra_high_risk: list[str] | None = None) -> None:
        extra = frozenset(_normalize_pkg_name(p) for p in (extra_high_risk or []))
        self._high_risk = _HIGH_RISK_DEPS | extra

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        findings = []
        for dep_file in self._find_dep_files(root):
            findings.extend(self._check_dep_file(dep_file))
        return findings

    def _find_dep_files(self, root: Path) -> list[Path]:
        files: list[Path] = []
        files.extend(root.glob("requirements*.txt"))
        files.extend(root.glob("requirements/*.txt"))
        pyproject = root / "pyproject.toml"
        if pyproject.exists():
            files.append(pyproject)
        return files

    def _check_dep_file(self, path: Path) -> list[Finding]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []

        if path.suffix == ".toml":
            deps = _parse_pyproject_deps(text)
        else:
            deps = _parse_requirements(text)

        findings = []
        for name, spec, lineno in deps:
            normalized = _normalize_pkg_name(name)

            # Static list: confirmed hallucination targets that don't fit patterns.
            if normalized in self._high_risk:
                reason = "matches known AI-hallucination-prone package list"
            else:
                # Structural pattern matching: broader coverage, no network needed.
                base_pkg = _suspicious_variant_of(name)
                if base_pkg is None:
                    continue
                reason = f"looks like a hallucinated variant of '{base_pkg}'"

            is_pinned = spec is not None and "==" in spec
            sev = Severity.WARNING if is_pinned else Severity.ERROR
            findings.append(Finding(
                file=str(path),
                line=lineno,
                col=0,
                rule_id="PROOFCTL-I-002",
                rule_name="High-risk dependency name",
                severity=sev,
                message=(
                    f"'{name}' {reason}"
                    + (" (pinned)" if is_pinned else " — unpinned, squatting risk")
                ),
                hint=(
                    f"Verify '{name}' is the intended package. "
                    "AI models commonly hallucinate plausible-sounding package names."
                ),
                authority="Slopsquatting research — AI-hallucinated package names",
            ))
        return findings


class MethodChecker(DirectoryChecker):
    """PROOFCTL-M-001: Phantom method calls detected by a single mypy invocation.

    Running mypy once on all files is orders of magnitude faster than once per
    file: mypy's startup and import-resolution cost is paid once, not N times.
    """

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        if not shutil.which("mypy") or not py_files:
            return []
        return self._run_mypy(py_files)

    def _run_mypy(self, py_files: list[Path]) -> list[Finding]:
        try:
            result = subprocess.run(
                [
                    "mypy",
                    "--ignore-missing-imports",
                    "--no-error-summary",
                    "--no-pretty",
                    *[str(p) for p in py_files],
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
        except (subprocess.TimeoutExpired, OSError):
            return []

        # Index scoped files for quick membership check after path normalisation.
        scoped = {str(p.resolve()) for p in py_files}

        findings = []
        for line in result.stdout.splitlines():
            m = _MYPY_ATTR_RE.match(line)
            if not m:
                continue

            if m.group(1):
                file_path, lineno_str = m.group(1), m.group(2)
                obj_type, attr = m.group(3), m.group(4)
                msg = f"'{obj_type}' has no attribute '{attr}'"
            else:
                file_path, lineno_str = m.group(5), m.group(6)
                attr = m.group(7)
                msg = f"Module has no attribute '{attr}'"

            # Skip findings for files outside the scan scope (e.g. installed libs).
            try:
                if str(Path(file_path).resolve()) not in scoped:
                    continue
            except OSError:
                continue

            try:
                lineno = int(lineno_str)
            except ValueError:
                lineno = None

            findings.append(Finding(
                file=file_path,
                line=lineno,
                col=None,
                rule_id="PROOFCTL-M-001",
                rule_name="Phantom method call",
                severity=Severity.ERROR,
                message=msg,
                hint="Check the library's documentation for the correct method name.",
                authority="mypy attr-defined — AI calls methods that don't exist",
                docs_url="https://mypy.readthedocs.io/en/stable/error_codes.html",
            ))

        return findings
