"""Shell script AI-slop checker — PROOFCTL-SH-* rules."""
from __future__ import annotations

import re
from pathlib import Path

from ..models import Finding, Severity
from .base import ShellFileChecker

# ── patterns ──────────────────────────────────────────────────────────────────

_SHEBANG_RE = re.compile(r"^#!\s*/(?:usr/(?:local/)?)?bin/(?:env\s+)?(?:bash|sh|zsh|ksh)\b")
_BASH_SHEBANG_RE = re.compile(r"^#!\s*/(?:usr/(?:local/)?)?bin/(?:env\s+)?bash\b")

_SET_E_RE = re.compile(
    r"(?:^|\s)set\s+(?:-[a-zA-Z]*e[a-zA-Z]*|-o\s+errexit)", re.MULTILINE
)
_PIPEFAIL_RE = re.compile(r"(?:^|\s)set\s+(?:-[a-zA-Z]*o\s+pipefail|.*pipefail)", re.MULTILINE)
_PIPE_RE = re.compile(r"[^|]\|[^|]")

_CURL_BASH_RE = re.compile(
    r"(?:curl|wget)\s+[^\n|]+\|\s*(?:sudo\s+)?(?:bash|sh|zsh)\b", re.MULTILINE
)
_RM_RF_VAR_RE = re.compile(r"\brm\s+-rf\s+/\$[{]?[A-Za-z_]", re.MULTILINE)

# Placeholder variable assignments
_PLACEHOLDER_VAR_RE = re.compile(
    r"""^\s*([A-Z_][A-Z0-9_]*)\s*=\s*["']?"""
    r"""(?:your[-_]?(?:project|bucket|region|cluster|account|secret|key|domain|org|repo|service|name|value|password|token|id)|"""
    r"""CHANGEME|CHANGE_ME|REPLACE_ME|REPLACE_WITH_YOUR|INSERT_YOUR|YOUR_[A-Z_]+|"""
    r"""<[A-Z][A-Z0-9_\-]+>|placeholder|example-[a-z]|my-project|MY_PROJECT)["']?""",
    re.IGNORECASE | re.MULTILINE,
)
_ANGLE_BRACKET_VAR_RE = re.compile(
    r"""^\s*[A-Z_][A-Z0-9_]*\s*=\s*["']?[^"'\n]*<[A-Za-z][A-Za-z0-9_\-]+>""",
    re.MULTILINE,
)

_TODO_RE = re.compile(r"#\s*(?:TODO|FIXME|HACK|PLACEHOLDER)\b[\s:]", re.IGNORECASE)

# Cross-cloud confusion: gcloud + aws in the same script
_GCLOUD_RE = re.compile(r"\bgcloud\b")
_AWS_CLI_RE = re.compile(r"\baws\s+[a-z]")

# AWS region format (us-east-1) — wrong in a GCP-focused script
_AWS_REGION_IN_SCRIPT_RE = re.compile(
    r"""["']?(us-east-[12]|us-west-[12]|eu-west-[1-3]|ap-southeast-[12]|ap-northeast-[12])["']?""",
    re.IGNORECASE,
)


class _ShellCheckerImpl(ShellFileChecker):
    def check(self, path: Path, source: str) -> list[Finding]:
        findings: list[Finding] = []
        lines = source.splitlines()

        findings.extend(_sh001_shebang(path, source, lines))
        findings.extend(_sh002_strict_mode(path, source, lines))
        findings.extend(_sh003_pipefail(path, source, lines))
        findings.extend(_sh004_curl_bash(path, source, lines))
        findings.extend(_sh005_rm_rf_var(path, source, lines))
        findings.extend(_sh006_placeholder_vars(path, lines))
        findings.extend(_sh007_todo_comments(path, lines))
        findings.extend(_sh008_cross_cloud(path, source, lines))
        return findings


def _f(
    path: Path,
    line: int | None,
    rule_id: str,
    rule_name: str,
    severity: Severity,
    message: str,
    hint: str = "",
    authority: str = "",
    docs_url: str = "",
) -> Finding:
    return Finding(
        file=str(path),
        line=line,
        col=None,
        rule_id=rule_id,
        rule_name=rule_name,
        severity=severity,
        message=message,
        hint=hint,
        authority=authority,
        docs_url=docs_url,
    )


def _sh001_shebang(path: Path, source: str, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-001 — Missing shebang line."""
    if not lines:
        return []
    if not _SHEBANG_RE.match(lines[0]):
        return [_f(
            path, 1,
            "PROOFCTL-SH-001", "Missing shebang",
            Severity.WARNING,
            f"'{path.name}' has no shebang — OS may execute with wrong interpreter",
            hint="Add #!/usr/bin/env bash as the first line.",
            authority="Google Shell Style Guide – File Header",
            docs_url="https://google.github.io/styleguide/shellguide.html#file-header",
        )]
    return []


def _sh002_strict_mode(path: Path, source: str, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-002 — Missing set -e (errexit)."""
    if not lines or not _BASH_SHEBANG_RE.match(lines[0]):
        return []
    if not _SET_E_RE.search(source):
        return [_f(
            path, 1,
            "PROOFCTL-SH-002", "Missing errexit",
            Severity.WARNING,
            "Bash script has no 'set -e' — a failed command silently allows the script to continue",
            hint="Add 'set -euo pipefail' immediately after the shebang.",
            authority="MIT Safe Shell Guide",
            docs_url="https://sipb.mit.edu/doc/safe-shell/",
        )]
    return []


def _sh003_pipefail(path: Path, source: str, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-003 — Pipelines without pipefail."""
    if not lines or not _BASH_SHEBANG_RE.match(lines[0]):
        return []
    if not _PIPE_RE.search(source):
        return []
    if not _PIPEFAIL_RE.search(source):
        return [_f(
            path, 1,
            "PROOFCTL-SH-003", "Missing pipefail",
            Severity.WARNING,
            "Script uses pipes but lacks 'set -o pipefail' — intermediate failures are silently swallowed",
            hint="Add 'set -euo pipefail' after the shebang.",
            authority="MIT Safe Shell Guide",
            docs_url="https://sipb.mit.edu/doc/safe-shell/",
        )]
    return []


def _sh004_curl_bash(path: Path, source: str, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-004 — curl/wget piped to bash."""
    findings: list[Finding] = []
    for m in _CURL_BASH_RE.finditer(source):
        lineno = source[: m.start()].count("\n") + 1
        findings.append(_f(
            path, lineno,
            "PROOFCTL-SH-004", "Remote code execution via curl|bash",
            Severity.ERROR,
            f"curl/wget piped directly to bash — executes unverified remote code",
            hint="Download to a temp file, verify its SHA256 checksum, then execute.",
            authority="Google Shell Style Guide / CWE-78",
            docs_url="https://cwe.mitre.org/data/definitions/78.html",
        ))
    return findings


def _sh005_rm_rf_var(path: Path, source: str, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-005 — rm -rf /$VARIABLE (root wipe if var is empty)."""
    findings: list[Finding] = []
    for m in _RM_RF_VAR_RE.finditer(source):
        lineno = source[: m.start()].count("\n") + 1
        findings.append(_f(
            path, lineno,
            "PROOFCTL-SH-005", "Dangerous rm -rf on variable path",
            Severity.ERROR,
            "rm -rf on a path starting with '/$VAR' — if variable is empty this deletes root",
            hint="Guard with: [[ -n \"$VAR\" ]] && rm -rf \"/$VAR\"",
            authority="MIT Safe Shell Guide",
            docs_url="https://sipb.mit.edu/doc/safe-shell/",
        ))
    return findings


def _sh006_placeholder_vars(path: Path, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-006 — Placeholder variable values."""
    findings: list[Finding] = []
    seen: set[int] = set()
    source = "\n".join(lines)
    for pattern in (_PLACEHOLDER_VAR_RE, _ANGLE_BRACKET_VAR_RE):
        for m in pattern.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            if lineno in seen:
                continue
            seen.add(lineno)
            snippet = lines[lineno - 1].strip()[:60]
            findings.append(_f(
                path, lineno,
                "PROOFCTL-SH-006", "Placeholder variable value",
                Severity.WARNING,
                f"Unfilled AI-generated placeholder: {snippet}",
                hint="Replace with the real value or read from a secrets manager / environment.",
                authority="Google Shell Style Guide",
                docs_url="https://google.github.io/styleguide/shellguide.html",
            ))
    return findings


def _sh007_todo_comments(path: Path, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-007 — TODO/FIXME sentinel comments in shell scripts."""
    findings: list[Finding] = []
    for i, line in enumerate(lines, start=1):
        if _TODO_RE.search(line):
            findings.append(_f(
                path, i,
                "PROOFCTL-SH-007", "TODO sentinel in shell script",
                Severity.WARNING,
                f"Unresolved TODO/FIXME in infrastructure script: {line.strip()[:60]}",
                hint="Resolve before committing — TODOs in shell scripts cause silent runtime failures.",
                authority="The Pragmatic Programmer – No Broken Windows",
                docs_url="https://pragprog.com/titles/tpp20/the-pragmatic-programmer-20th-anniversary-edition/",
            ))
    return findings


def _sh008_cross_cloud(path: Path, source: str, lines: list[str]) -> list[Finding]:
    """PROOFCTL-SH-008 — AWS CLI mixed with gcloud in the same script."""
    if _GCLOUD_RE.search(source) and _AWS_CLI_RE.search(source):
        return [_f(
            path, 1,
            "PROOFCTL-SH-008", "Cross-cloud CLI confusion",
            Severity.WARNING,
            "Script uses both 'gcloud' and 'aws' CLI — likely AI cross-contamination between cloud providers",
            hint="Verify this is intentional multi-cloud usage, not an AI error mixing provider CLIs.",
            authority="Google Cloud Architecture Best Practices",
            docs_url="https://cloud.google.com/architecture/framework",
        )]
    return []


ShellRulesChecker = _ShellCheckerImpl
