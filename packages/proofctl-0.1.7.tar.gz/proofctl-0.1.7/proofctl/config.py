from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .models import Severity

_DEFAULT_EXCLUDES: list[str] = [
    "**/.venv/**",
    "**/venv/**",
    "**/node_modules/**",
    "**/.git/**",
    "**/__pycache__/**",
    "**/*.egg-info/**",
    "**/dist/**",
    "**/build/**",
    "**/.terragrunt-cache/**",
    "**/.terraform/**",
]

# Top-level config keys recognised by `.proofctl.yaml`. Anything else triggers
# a friendly error at load time so typos like `disabled:` (instead of
# `disable:`) don't silently no-op.
_KNOWN_TOP_LEVEL_KEYS: frozenset[str] = frozenset({
    "exclude_paths",
    "exclude_paths_extend",
    "exclude_paths_replace",   # boolean: when True, exclude_paths replaces defaults
    "disable",
    "severity_overrides",
    "rules",
})

_KNOWN_RULE_BLOCKS: frozenset[str] = frozenset({
    "PROOFCTL-P-002",
    "PROOFCTL-Q-003",
    "PROOFCTL-V-002",
    "PROOFCTL-I-001",
    "PROOFCTL-I-002",
    "PROOFCTL-TF-T013",
})


class ConfigError(ValueError):
    """Raised when `.proofctl.yaml` contains invalid keys or values."""


@dataclass
class ProofctlConfig:
    exclude_paths: list[str] = field(default_factory=lambda: list(_DEFAULT_EXCLUDES))
    disable: list[str] = field(default_factory=list)
    severity_overrides: dict[str, str] = field(default_factory=dict)
    # PROOFCTL-P-002
    todo_allowed_formats: list[str] = field(default_factory=list)
    todo_exclude_paths: list[str] = field(default_factory=lambda: ["tests/", "migrations/", "scripts/"])
    # PROOFCTL-Q-003
    any_threshold: int = 3
    # PROOFCTL-V-002
    similarity_threshold: float = 0.80
    similarity_min_lines: int = 30
    # PROOFCTL-I-001
    pypi_extra_indexes: list[str] = field(default_factory=list)
    local_namespaces: list[str] = field(default_factory=list)
    check_pypi: bool = True
    # PROOFCTL-I-002
    i002_extra_high_risk: list[str] = field(default_factory=list)
    # PROOFCTL-TF-T013
    tf_required_labels: list[str] = field(default_factory=list)

    def is_disabled(self, rule_id: str) -> bool:
        return rule_id in self.disable

    def effective_severity(self, rule_id: str, default: Severity) -> Severity:
        raw = self.severity_overrides.get(rule_id)
        if raw:
            return Severity.from_str(raw)
        return default

    def todo_is_allowed(self, comment_text: str) -> bool:
        if not self.todo_allowed_formats:
            return False
        return any(re.search(pat, comment_text) for pat in self.todo_allowed_formats)


def _validate_severity_overrides(overrides: dict, source: Path) -> None:
    """Reject any severity_overrides value that isn't ERROR/WARNING/INFO.

    Catches typos at load time rather than at first finding (the original H-8
    bug had `from_str` raise mid-scan with no file context).
    """
    if not isinstance(overrides, dict):
        raise ConfigError(
            f"{source}: 'severity_overrides' must be a mapping, got {type(overrides).__name__}"
        )
    valid = {"ERROR", "WARNING", "INFO"}
    for rule_id, sev in overrides.items():
        if not isinstance(sev, str) or sev.upper() not in valid:
            raise ConfigError(
                f"{source}: severity_overrides[{rule_id!r}]={sev!r} is invalid. "
                f"Must be one of: ERROR, WARNING, INFO."
            )


def _validate_top_level_keys(raw: dict, source: Path) -> None:
    unknown = set(raw) - _KNOWN_TOP_LEVEL_KEYS
    if unknown:
        suggestions: list[str] = []
        for key in sorted(unknown):
            best = _suggest_key(key, _KNOWN_TOP_LEVEL_KEYS)
            if best:
                suggestions.append(f"{key!r} (did you mean {best!r}?)")
            else:
                suggestions.append(repr(key))
        raise ConfigError(
            f"{source}: unknown top-level key(s): {', '.join(suggestions)}. "
            f"Recognised keys: {', '.join(sorted(_KNOWN_TOP_LEVEL_KEYS))}."
        )


def _suggest_key(typo: str, known: frozenset[str]) -> str | None:
    """Find a near-match for an unknown key (catches typos like `disabled` vs `disable`)."""
    typo_l = typo.lower()
    for candidate in known:
        c = candidate.lower()
        # Substring on either side, or only one char different.
        if c in typo_l or typo_l in c:
            return candidate
        if abs(len(c) - len(typo_l)) <= 1 and _close_enough(c, typo_l):
            return candidate
    return None


def _close_enough(a: str, b: str) -> bool:
    """Cheap edit-distance approximation for the suggestion path."""
    if a == b:
        return True
    if abs(len(a) - len(b)) > 2:
        return False
    # Count differing positions in aligned prefix; allow 1 mismatch.
    diff = sum(1 for x, y in zip(a, b) if x != y) + abs(len(a) - len(b))
    return diff <= 2


def load_config(root: Path) -> ProofctlConfig:
    cfg_file = root / ".proofctl.yaml"
    if not cfg_file.exists():
        return ProofctlConfig()

    with cfg_file.open() as f:
        raw = yaml.safe_load(f) or {}

    if not isinstance(raw, dict):
        raise ConfigError(
            f"{cfg_file}: top-level must be a mapping, got {type(raw).__name__}"
        )

    _validate_top_level_keys(raw, cfg_file)
    _validate_severity_overrides(raw.get("severity_overrides", {}), cfg_file)

    # ── exclude_paths semantics (H-9) ─────────────────────────────────────────
    # The historical behaviour was "user `exclude_paths` replaces defaults",
    # which silently dropped the .venv/.git/__pycache__ excludes the moment a
    # user added their own. We now default to *extending* the defaults, with
    # `exclude_paths_replace: true` available as an opt-out.
    user_excludes = raw.get("exclude_paths", [])
    extra_excludes = raw.get("exclude_paths_extend", [])
    replace_mode = bool(raw.get("exclude_paths_replace", False))

    if not isinstance(user_excludes, list) or not isinstance(extra_excludes, list):
        raise ConfigError(
            f"{cfg_file}: 'exclude_paths' / 'exclude_paths_extend' must be lists of strings."
        )

    if replace_mode:
        excludes = list(user_excludes)
    elif user_excludes and not extra_excludes:
        # Backwards-compat: a bare `exclude_paths:` was historically the
        # replacement form. Preserve that behaviour but extend with defaults
        # so new users don't silently lose .venv/.git protection.
        # If a user explicitly wants the old replace semantics, set
        # `exclude_paths_replace: true`.
        excludes = list(_DEFAULT_EXCLUDES) + list(user_excludes)
    else:
        excludes = list(_DEFAULT_EXCLUDES) + list(user_excludes) + list(extra_excludes)

    # ── per-rule blocks ──────────────────────────────────────────────────────
    rules = raw.get("rules", {})
    if not isinstance(rules, dict):
        raise ConfigError(f"{cfg_file}: 'rules' must be a mapping")
    unknown_rule_blocks = set(rules) - _KNOWN_RULE_BLOCKS
    if unknown_rule_blocks:
        raise ConfigError(
            f"{cfg_file}: unknown rule block(s) under 'rules:': {sorted(unknown_rule_blocks)}. "
            f"Known: {sorted(_KNOWN_RULE_BLOCKS)}."
        )

    p002 = rules.get("PROOFCTL-P-002", {})
    q003 = rules.get("PROOFCTL-Q-003", {})
    v002 = rules.get("PROOFCTL-V-002", {})
    i001 = rules.get("PROOFCTL-I-001", {})

    return ProofctlConfig(
        exclude_paths=excludes,
        disable=raw.get("disable", []),
        severity_overrides=raw.get("severity_overrides", {}),
        todo_allowed_formats=p002.get("allowed_formats", []),
        todo_exclude_paths=p002.get("exclude_paths", ["tests/", "migrations/", "scripts/"]),
        any_threshold=q003.get("any_threshold", 3),
        similarity_threshold=v002.get("similarity_threshold", 0.80),
        similarity_min_lines=v002.get("min_file_lines", 30),
        pypi_extra_indexes=i001.get("extra_indexes", []),
        local_namespaces=i001.get("local_namespaces", []),
        i002_extra_high_risk=rules.get("PROOFCTL-I-002", {}).get("extra_high_risk", []),
        tf_required_labels=rules.get("PROOFCTL-TF-T013", {}).get("required_labels", []),
    )
