"""Regression tests for AUDIT_AND_ROADMAP Phase 2 (H-1..H-10) fixes."""
from __future__ import annotations

import ast
import json
import re
import subprocess
import tempfile
from pathlib import Path

import pytest

from proofctl import _globmatch
from proofctl.baseline import (
    _normalise_message,
    filter_new_findings,
    load_baseline,
    save_baseline,
)
from proofctl.config import ConfigError, ProofctlConfig, load_config
from proofctl.engine import _changed_files_all, run_check
from proofctl.fixer import _fix_mutable_defaults, apply_fixes_detailed
from proofctl.models import Finding, Severity


# ── H-3: gitignore-style matcher ──────────────────────────────────────────────

@pytest.mark.parametrize("pattern,path,expected", [
    ("**/.venv/**", "src/.venv/lib/x.py", True),
    ("**/.venv/**", "src/lib/x.py", False),
    ("**/migrations/**", "app/migrations/0001_init.py", True),
    ("tests/**", "tests/sub/foo.py", True),
    ("tests/**", "src/tests/foo.py", False),  # anchored
    ("*.pyc", "deeply/nested/foo.pyc", True),  # basename anywhere
    ("a/**/b", "a/b", True),
    ("a/**/b", "a/x/y/b", True),
    ("a/**/b", "x/a/b", False),  # anchored
])
def test_h3_gitignore_matcher(pattern: str, path: str, expected: bool) -> None:
    match = _globmatch.compile_globs([pattern])
    assert match(path) is expected


def test_h3_engine_excludes_nested_pattern(tmp_path):
    """Configured `**/migrations/**` excludes findings inside nested migrations dirs.
    Pre-fix `fnmatch` returned False on these paths."""
    bad = tmp_path / "app" / "migrations" / "0001_init.py"
    bad.parent.mkdir(parents=True)
    bad.write_text("def foo(items=[]): pass\n")
    cfg = ProofctlConfig()
    cfg.exclude_paths = ["**/migrations/**"]
    findings = run_check(tmp_path, cfg, families=["Q"])
    assert all("migrations" not in f.file for f in findings)


# ── H-2: POSIX path normalisation ─────────────────────────────────────────────

def test_h2_finding_paths_use_forward_slashes(tmp_path):
    """Findings and suppression keys must use POSIX separators regardless of OS."""
    sub = tmp_path / "src" / "api"
    sub.mkdir(parents=True)
    (sub / "auth.py").write_text("def login(items=[]): pass\n")
    findings = run_check(tmp_path, ProofctlConfig(), families=["Q"])
    assert findings, "expected at least one Q-001 finding"
    for f in findings:
        assert "\\" not in f.file, f"path '{f.file}' contains backslash"


# ── H-4: per-format inline suppression ────────────────────────────────────────

def test_h4_inline_suppress_in_yaml(tmp_path):
    """`# proofctl: ignore[…]` in YAML must be honoured (was Python-only)."""
    (tmp_path / "deploy.yaml").write_text(
        "apiVersion: extensions/v1beta1  # proofctl: ignore[PROOFCTL-YAML-AI-001]\n"
        "kind: Deployment\n"
        "metadata:\n"
        "  name: x\n"
        "spec: {}\n"
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["YAML"])
    rule_ids = [f.rule_id for f in findings]
    assert "PROOFCTL-YAML-AI-001" not in rule_ids


def test_h4_inline_suppress_in_dockerfile(tmp_path):
    (tmp_path / "Dockerfile").write_text(
        "FROM ubuntu:latest  # proofctl: ignore[PROOFCTL-DF-001]\n"
        "CMD echo hi\n"
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["DF"])
    assert all(f.rule_id != "PROOFCTL-DF-001" for f in findings)


def test_h4_inline_suppress_in_shell(tmp_path):
    (tmp_path / "deploy.sh").write_text(
        "#!/bin/bash  # proofctl: ignore[PROOFCTL-SH-002]\n"
        "echo hi\n"
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["SH"])
    assert all(f.rule_id != "PROOFCTL-SH-002" for f in findings)


def test_h4_double_slash_suppress_in_hcl(tmp_path):
    """HCL accepts both `#` and `//` comments — both forms must suppress."""
    (tmp_path / "main.tf").write_text(
        'resource "aws_security_group_rule" "open" {\n'
        '  type        = "ingress"\n'
        '  from_port   = 22\n'
        '  to_port     = 22\n'
        '  cidr_blocks = ["0.0.0.0/0"]  // proofctl: ignore[PROOFCTL-TF-T004]\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert all(f.rule_id != "PROOFCTL-TF-T004" for f in findings), (
        f"T-004 should be suppressed but was emitted: {[f.rule_id for f in findings]}"
    )


def test_h4_hash_suppress_in_hcl(tmp_path):
    """HCL `#` comment style suppresses just like Python's."""
    (tmp_path / "main.tf").write_text(
        'resource "aws_security_group_rule" "open" {\n'
        '  type        = "ingress"\n'
        '  from_port   = 22\n'
        '  to_port     = 22\n'
        '  cidr_blocks = ["0.0.0.0/0"]  # proofctl: ignore[PROOFCTL-TF-T004]\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert all(f.rule_id != "PROOFCTL-TF-T004" for f in findings)


# ── H-5: internal error visibility + --strict ────────────────────────────────

def test_h5_checker_crash_emits_internal_finding(tmp_path, monkeypatch):
    """When a checker raises, the engine must emit PROOFCTL-INTERNAL-001
    instead of silently swallowing the failure."""
    from proofctl.checkers import security as sec_mod

    class _Boom:
        def check(self, path, source, tree):
            raise RuntimeError("synthetic checker failure for test")

    monkeypatch.setattr(
        "proofctl.engine._build_file_checkers",
        lambda config, families: [_Boom()],
    )

    (tmp_path / "x.py").write_text("x = 1\n")
    findings = run_check(tmp_path, ProofctlConfig())
    internal = [f for f in findings if f.rule_id == "PROOFCTL-INTERNAL-001"]
    assert len(internal) == 1, f"expected one internal finding, got {len(internal)}"
    assert internal[0].severity == Severity.INFO, "non-strict default is INFO"


def test_h5_strict_escalates_internal_to_error(tmp_path, monkeypatch):
    class _Boom:
        def check(self, path, source, tree):
            raise RuntimeError("synthetic crash")

    monkeypatch.setattr(
        "proofctl.engine._build_file_checkers",
        lambda config, families: [_Boom()],
    )
    (tmp_path / "x.py").write_text("x = 1\n")
    findings = run_check(tmp_path, ProofctlConfig(), strict=True)
    internal = [f for f in findings if f.rule_id == "PROOFCTL-INTERNAL-001"]
    assert len(internal) == 1
    assert internal[0].severity == Severity.ERROR


# ── H-7: fixer tracks succeeded vs skipped ────────────────────────────────────

def test_h7_multiline_default_skipped_no_phantom_guard():
    """The fixer must not emit a sentinel guard for a default it cannot rewrite,
    nor double-count it. AUDIT H-7."""
    src = (
        "def f(items=[\n"
        "    1,\n"
        "    2,\n"
        "]):\n"
        "    return items\n"
    )
    new_src, result = _fix_mutable_defaults(src, ast.parse(src), "test.py")
    assert result.succeeded == 0
    assert result.skipped == 1
    assert "if items is None:" not in new_src, (
        "fixer must not insert guard for skipped multi-line default"
    )


def test_h7_mixed_single_and_multiline_defaults():
    src = (
        "def f(a=[], b=[\n"
        "    1,\n"
        "]):\n"
        "    return a, b\n"
    )
    new_src, result = _fix_mutable_defaults(src, ast.parse(src), "test.py")
    assert result.succeeded == 1
    assert result.skipped == 1
    assert "if a is None:" in new_src
    assert "if b is None:" not in new_src


# ── H-8: eager config validation ──────────────────────────────────────────────

def test_h8_unknown_top_level_key_raises_at_load(tmp_path):
    (tmp_path / ".proofctl.yaml").write_text("disabled: [PROOFCTL-S-001]\n")  # typo
    with pytest.raises(ConfigError, match="disabled"):
        load_config(tmp_path)


def test_h8_invalid_severity_override_raises_at_load(tmp_path):
    (tmp_path / ".proofctl.yaml").write_text(
        "severity_overrides:\n  PROOFCTL-P-001: VERY_BAD\n"
    )
    with pytest.raises(ConfigError, match="invalid"):
        load_config(tmp_path)


def test_h8_unknown_rule_block_raises_at_load(tmp_path):
    (tmp_path / ".proofctl.yaml").write_text(
        "rules:\n  PROOFCTL-NOPE-999:\n    foo: bar\n"
    )
    with pytest.raises(ConfigError, match="unknown rule block"):
        load_config(tmp_path)


# ── H-9: exclude_paths_extend semantics ───────────────────────────────────────

def test_h9_extend_keeps_defaults(tmp_path):
    """`exclude_paths_extend` adds to defaults instead of replacing them."""
    (tmp_path / ".proofctl.yaml").write_text(
        "exclude_paths_extend:\n  - '**/generated/**'\n"
    )
    cfg = load_config(tmp_path)
    assert "**/generated/**" in cfg.exclude_paths
    assert "**/.venv/**" in cfg.exclude_paths, "default excludes must survive"


def test_h9_replace_drops_defaults(tmp_path):
    """`exclude_paths_replace: true` opts back into the legacy replace semantics."""
    (tmp_path / ".proofctl.yaml").write_text(
        "exclude_paths_replace: true\n"
        "exclude_paths:\n  - '**/just_this/**'\n"
    )
    cfg = load_config(tmp_path)
    assert cfg.exclude_paths == ["**/just_this/**"]


# ── H-10: smarter baseline fingerprint ────────────────────────────────────────

def test_h10_normalise_strips_numbers_and_quotes():
    a = "'visit_Call' has cyclomatic complexity 23 (threshold: 10)"
    b = "'do_thing'   has cyclomatic complexity 41 (threshold: 10)"
    assert _normalise_message(a) == _normalise_message(b)


def test_h10_baseline_suppresses_when_complexity_number_changes():
    """A trivial code edit that nudges the complexity number from 11 to 12
    should not re-surface the finding as 'new'. AUDIT H-10."""
    f1 = Finding(
        file="x.py", line=10, col=0,
        rule_id="PROOFCTL-Q-005", rule_name="High cyclomatic complexity",
        severity=Severity.WARNING,
        message="'foo' has cyclomatic complexity 11 (threshold: 10)",
        hint="", authority="", docs_url="",
    )
    f2 = Finding(
        file="x.py", line=10, col=0,
        rule_id="PROOFCTL-Q-005", rule_name="High cyclomatic complexity",
        severity=Severity.WARNING,
        message="'foo' has cyclomatic complexity 12 (threshold: 10)",
        hint="", authority="", docs_url="",
    )
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        save_baseline([f1], root)
        baseline = load_baseline(root)
        new = filter_new_findings([f2], baseline)
        assert new == [], "tiny numeric drift must not surface as new finding"


def test_h10_legacy_v1_baseline_still_suppresses(tmp_path):
    """A schema_version-less baseline written by 0.1.5 must still suppress
    findings exactly as it did under v1 fingerprinting (exact-message match)."""
    legacy = {
        "created": "2026-01-01T00:00:00+00:00",
        "proofctl_version": "0.1.5",
        "count": 1,
        "findings": [{
            "rule_id": "PROOFCTL-P-001",
            "file": "x.py",
            "message": "'foo' body is pass",
        }],
    }
    (tmp_path / ".proofctl-baseline.json").write_text(json.dumps(legacy))
    baseline = load_baseline(tmp_path)
    assert baseline is not None
    assert baseline["schema_version"] == 1  # backfilled

    f = Finding(
        file="x.py", line=1, col=0,
        rule_id="PROOFCTL-P-001", rule_name="Unimplemented function body",
        severity=Severity.ERROR,
        message="'foo' body is pass",
        hint="", authority="", docs_url="",
    )
    new = filter_new_findings([f], baseline)
    assert new == [], "v1 baseline must suppress exact-message match"
