import logging
import os
import re
import time
from abc import ABC
from dataclasses import dataclass, field, fields, replace
from pathlib import Path
from threading import RLock
from typing import Optional, Any, Type, ClassVar, TypeVar, TYPE_CHECKING, Callable, Union

from databricks.sdk import AccountClient as DAC, WorkspaceClient as DWC
from databricks.sdk.client_types import ClientType
from databricks.sdk.config import Config

from yggdrasil.concurrent.threading import Job
from yggdrasil.dataclasses import WaitingConfigArg, WaitingConfig, ExpiringDict
from yggdrasil.io.bytes_io import BytesIO
from yggdrasil.data.enums import MimeTypes, Scheme
from yggdrasil.io.url import URL, URLBased
from yggdrasil.version import __version__ as ygg_version

if TYPE_CHECKING:
    from .iam import IAM
    from .sql.engine import SQLEngine
    from .sql.tables import Tables
    from .sql.views import Views
    from .sql.columns import Columns
    from .sql.catalogs import Catalogs
    from .sql.schemas import Schemas
    from .warehouse.service import Warehouses
    from .compute.service import Compute
    from .secrets.service import Secrets
    from .workspaces import Workspaces, Workspace
    from .fs.service import FileSystem
    from .fs.path import DatabricksPath
    from .ai.genie import Genie
    from .tags.service import EntityTags

__all__ = [
    "DatabricksClient",
    "DatabricksService",
    "DatabricksResource"
]

LOGGER = logging.getLogger(__name__)
CURRENT_BASE_CLIENT: Optional["DatabricksClient"] = None
CURRENT_BASE_CLIENT_LOCK: RLock = RLock()

T = TypeVar("T")
TC = TypeVar("TC", bound="DatabricksClient")
TS = TypeVar("TS", bound="DatabricksService")

_ALLOWED = re.compile(r"^[\d \w\+\-=\.:/@]*$")  # noqa
_SANITIZE = re.compile(r"[^\d \w\+\-=\.:/@]+")  # noqa


def getenv(name: str) -> Optional[str]:
    v = os.getenv(name)
    return v if v not in (None, "") else None


def getenv_factory(name: str):
    def factory():
        return getenv(name)
    return factory


def env_field(
    name: str,
    *,
    repr_: bool = False,
    compare: bool = True,
    hash_: bool = True,
):
    return field(
        default_factory=getenv_factory(name),
        repr=repr_,
        compare=compare,
        hash=hash_,
    )


@dataclass
class DatabricksClient(URLBased):
    """
    Thin wrapper around databricks.sdk.config.Config.

    URL-addressable through the :class:`URLBased` base: ``cls.scheme``
    is :attr:`Scheme.DATABRICKS` (``dbks``), so a single
    ``dbks://[client_id[:secret]@]<host>[?profile=...&account_id=...]``
    URL round-trips a client through :meth:`from_url` /
    :meth:`to_url`. The userinfo carries the credential — a bare
    ``:<token>@`` for a PAT, ``<client_id>:<client_secret>@`` for an
    OAuth service principal — and the query string carries every
    other ``DatabricksClient`` field that ``__init__`` accepts.
    Sensitive fields (``host``, ``token``, ``client_id``,
    ``client_secret``) are kept out of the query so they don't get
    duplicated when the URL is logged or persisted.

    Public state is intentionally minimal:
      - config: Config

    Extra wrapper-only metadata is kept separately.

    Cross-process / cross-host serialization is supported via
    :meth:`__getstate__` / :meth:`__setstate__`. SDK clients, Configs,
    and lazy sub-service caches are dropped (all rebuild on demand from
    the dataclass fields). A best-effort *session token snapshot* is
    carried alongside so the receiving side can warm-start without
    re-running the auth dance (browser flow, MSI probe, gcloud, etc).

    If the deserializing host is itself a Databricks runtime (driver
    node), the carried credentials are discarded and ``auth_type`` is
    forced to ``"runtime"`` — DBR's notebook-scoped auth is short-lived,
    identity-correct, and the right default in that environment.
    """

    # URLBased registration: ``dbks://`` URLs route to this class.
    scheme: ClassVar[Scheme] = Scheme.DATABRICKS

    # Databricks / generic
    host: Optional[str] = env_field("DATABRICKS_HOST", repr_=True)
    account_id: Optional[str] = env_field("DATABRICKS_ACCOUNT_ID", repr_=False)
    workspace_id: Optional[str] = env_field("DATABRICKS_WORKSPACE_ID", repr_=False)
    token: Optional[str] = env_field("DATABRICKS_TOKEN", repr_=False)
    client_id: Optional[str] = env_field("DATABRICKS_CLIENT_ID", repr_=False)
    client_secret: Optional[str] = env_field("DATABRICKS_CLIENT_SECRET", repr_=False)
    token_audience: Optional[str] = env_field("DATABRICKS_TOKEN_AUDIENCE", repr_=False)
    cluster_id: Optional[str] = env_field("DATABRICKS_CLUSTER_ID", repr_=False)
    serverless_compute_id: Optional[str] = env_field("DATABRICKS_SERVERLESS_COMPUTE_ID", repr_=False)

    # Azure
    azure_workspace_resource_id: Optional[str] = env_field("ARM_RESOURCE_ID", repr_=False)
    azure_use_msi: bool | None = field(default=None, repr=False)
    azure_client_secret: Optional[str] = env_field("ARM_CLIENT_SECRET", repr_=False)
    azure_client_id: Optional[str] = env_field("ARM_CLIENT_ID", repr_=False)
    azure_tenant_id: Optional[str] = env_field("ARM_TENANT_ID", repr_=False)
    azure_environment: Optional[str] = env_field("ARM_ENVIRONMENT", repr_=False)

    # GCP
    google_credentials: Optional[str] = env_field("GOOGLE_CREDENTIALS", repr_=False)
    google_service_account: Optional[str] = env_field("DATABRICKS_GOOGLE_SERVICE_ACCOUNT", repr_=False)

    # Config profile
    profile: Optional[str] = env_field("DATABRICKS_CONFIG_PROFILE", repr_=False, compare=False, hash_=False)
    config_file: Optional[str] = env_field("DATABRICKS_CONFIG_FILE", repr_=False, compare=False, hash_=False)

    # HTTP / client behavior
    auth_type: str | None = None
    http_timeout_seconds: Optional[int] = field(default=None, repr=False)
    retry_timeout_seconds: Optional[int] = field(default=None, repr=False)
    debug_truncate_bytes: Optional[int] = field(default=None, repr=False)
    debug_headers: bool | None = field(default=None, repr=False)
    rate_limit: Optional[int] = field(default=None, repr=False)

    # Extras
    product: Optional[str] = field(default="yggdrasil", repr=False)
    product_version: Optional[str] = field(default=ygg_version, repr=False)
    custom_tags: Optional[dict] = field(default=None, repr=False)

    # Internal cached SDK clients
    _was_connected: bool = field(default=False, init=False, repr=False, compare=False, hash=False)
    _workspace_config: Optional[Config] = field(default=None, init=False, repr=False, compare=False, hash=False)
    _workspace_client: Optional[DWC] = field(default=None, init=False, repr=False, compare=False, hash=False)
    _account_config: Optional[Config] = field(default=None, init=False, repr=False, compare=False, hash=False)
    _account_client: Optional[DAC] = field(default=None, init=False, repr=False, compare=False, hash=False)

    # Serializable session-token snapshot, populated on __getstate__ and
    # consumed on __setstate__. Off-cluster only — DBR runtime ignores it.
    _session_token: Optional[dict[str, Any]] = field(
        default=None, init=False, repr=False, compare=False, hash=False
    )

    # ----- transport policy -------------------------------------------------

    # Attributes that must NOT cross a process / host boundary verbatim.
    # SDK clients hold sockets and threads; cached Configs hold credential
    # providers bound to the *source* host's filesystem (token-cache.json,
    # ~/.databrickscfg, IMDS, gcloud DAC, etc). Sub-service caches hold
    # back-references to ``self`` and re-hydrate lazily via @property.
    _TRANSIENT_STATE: ClassVar[frozenset[str]] = frozenset({
        "_workspace_client",
        "_account_client",
        "_workspace_config",
        "_account_config",
        "_was_connected",
        "_workspace", "_sql", "_entity_tags", "_warehouses", "_compute",
        "_secrets", "_iam", "_tables", "_views", "_columns_svc",
        "_catalogs", "_schemas", "_genie", "_filesystem",
    })

    # Config attributes worth snapshotting for warm restart on another host.
    # PAT / OAuth secret fields already live on DatabricksClient itself and
    # round-trip via normal dataclass state — no need to duplicate them here.
    _SESSION_TOKEN_KEYS: ClassVar[tuple[str, ...]] = (
        "token",
        "token_audience",
        "auth_type",
    )

    def __post_init__(self):
        if self.account_id:
            if not self.host:
                object.__setattr__(self, "host", "https://accounts.cloud.databricks.com")

        if self.host:
            normalized = self.host.split("://")[-1].split("/")[0]
            object.__setattr__(self, "host", f"https://{normalized}")

    # -------------------------------------------------------------------------
    # Serialization
    # -------------------------------------------------------------------------

    def __getstate__(self):
        """
        Serialize for transport across processes / hosts.

        Drops SDK clients, Configs, and lazy sub-service caches (they all
        rebuild from the dataclass fields on demand). Captures a session
        token snapshot from the live Config so the receiving side can warm
        start without re-running an interactive or environment-bound auth.
        """
        state = self.__dict__.copy()

        for key in self._TRANSIENT_STATE:
            state.pop(key, None)

        # Best-effort. We don't *construct* a Config here — pickling must
        # never trigger a browser flow or network round-trip.
        state["_session_token"] = self._snapshot_session_token()

        return state

    def __setstate__(self, state):
        """
        Rehydrate after transport.

        Inside a Databricks runtime (driver node), DBR's notebook-scoped
        credentials win unconditionally: we force ``auth_type="runtime"``
        and clear any sender-bound credential fields that would otherwise
        bias ``_make_base_config`` toward the wrong path.

        Off-cluster, the carried session token is restored onto ``self``
        so the next ``make_config()`` call picks it up via the normal
        field path — no Config exists yet at unpickle time.
        """
        # Initialize transient slots so attribute access is safe even if
        # the pickle pre-dates a field addition.
        for key in self._TRANSIENT_STATE:
            self.__dict__[key] = None
        self.__dict__["_session_token"] = None

        self.__dict__.update(state)

        if self.is_in_databricks_environment():
            self.auth_type = "runtime"
            self.token = None
            self.client_id = None
            self.client_secret = None
            self.profile = None
            self.config_file = None
            self._session_token = None
            return

        self._restore_session_token(state.get("_session_token"))

    def _snapshot_session_token(self) -> Optional[dict[str, Any]]:
        """
        Capture a minimal, transportable view of the active session token.

        Returns the previously stored snapshot (if any) when no Config has
        been materialized yet — pickling must not trigger Config construction.
        """
        config = self._workspace_config or self._account_config
        if config is None:
            return self._session_token

        snap: dict[str, Any] = {}
        for key in self._SESSION_TOKEN_KEYS:
            value = getattr(config, key, None)
            if value is not None:
                snap[key] = value

        # Some SDK versions cache the resolved Authorization header on the
        # Config; grab it if present, but never call authenticate() — that
        # could hit the network mid-pickle.
        try:
            headers = getattr(config, "_inner", None)
            if isinstance(headers, dict) and "Authorization" in headers:
                snap["authorization"] = headers["Authorization"]
        except Exception:  # noqa: BLE001 - snapshot is best-effort
            pass

        return snap or None

    def _restore_session_token(self, snap: Optional[dict[str, Any]]) -> None:
        """
        Apply a snapshot produced by :meth:`_snapshot_session_token`.

        Only fills fields that are not already set on ``self`` —
        explicit constructor-provided values win over a stale carried token.
        """
        if not snap:
            return

        if not self.token and "token" in snap:
            self.token = snap["token"]
        if not self.token_audience and "token_audience" in snap:
            self.token_audience = snap["token_audience"]
        if not self.auth_type and "auth_type" in snap:
            self.auth_type = snap["auth_type"]

        # Forward the full snapshot so a downstream re-pickle can pass it on
        # even before make_config() runs on this host.
        self._session_token = snap

    # -------------------------------------------------------------------------
    # URLBased — round-trip through ``dbks://`` URLs
    # -------------------------------------------------------------------------

    @property
    def base_url(self):
        if not self.host:
            return URL.from_str(self.make_config().host)
        return URL.from_str(self.host)

    @property
    def explore_url(self) -> URL:
        """Workspace UI root for the Catalog Explorer (``/explore/data``).

        Mirrors :attr:`Catalog.explore_url` / :attr:`Schema.explore_url` so
        the whole resource hierarchy advertises a deep-link in one place.
        """
        return self.base_url.with_path("/explore/data")

    def to_url(self, scheme: str | None = None) -> URL:
        """Render this client as a ``dbks://...`` URL.

        Pack everything ``__init__`` would need to rebuild the client
        into the URL: the workspace host as the URL host, the
        credential (PAT or OAuth client_id/secret) as userinfo, and
        every other non-default field as query items. Sensitive
        fields (``host``, ``token``, ``client_id``,
        ``client_secret``) are intentionally kept *out* of the query
        so they don't get duplicated alongside the userinfo.

        ``scheme`` overrides :attr:`scheme` for callers that want a
        different URL scheme (e.g. ``"https"`` for the bare workspace
        URL); defaults to :attr:`Scheme.DATABRICKS`.
        """
        query: dict[str, Any] = {}
        keys = [
            f.name
            for f in fields(self)
            if f.init and f.name not in (
                "host", "token", "client_id", "client_secret"
            )
        ]

        for key in keys:
            value = getattr(self, key)
            if value is not None:
                query[key] = value

        if self.token:
            user, password = None, self.token
        elif self.client_id and self.client_secret:
            user, password = self.client_id, self.client_secret
        else:
            user, password = None, None

        return (
            self.base_url
            .with_scheme(scheme or type(self).scheme.value)
            .with_query_items(query)
            .with_user_password(user=user, password=password)
        )

    @classmethod
    def from_url(cls: Type[TC], url: "URL | str", **kwargs: Any) -> TC:
        """Build a client from a ``dbks://...`` URL.

        Reads:

        - the workspace host from ``url.host`` (preferred) or a
          ``host=`` query param;
        - credentials from ``url.userinfo`` —
          ``<client_id>:<client_secret>@`` for OAuth, ``:<token>@``
          (or anything-as-password) for a PAT;
        - every other init field of :class:`DatabricksClient` from
          the query string (``profile``, ``auth_type``,
          ``account_id``, ``workspace_id``, ``http_timeout_seconds``,
          …).

        ``kwargs`` overrides anything the URL provides so callers can
        layer programmatic overrides on top of a parsed URL without
        an extra ``replace`` call.
        """
        u = URL.from_(url)

        parsed: dict[str, Any] = {}
        for key, value in u.query_items():
            parsed[key] = value

        host = parsed.pop("host", None) or (
            f"https://{u.host}/" if u.host else None
        )
        if not host:
            raise ValueError(
                f"Host is required for {cls.__name__} URL: {u!r}. "
                f"Pass it as the URL host (``dbks://workspace.example/``) "
                f"or as a ``host=`` query item."
            )

        user, password = u.user, u.password
        if user and password:
            parsed["client_id"] = user
            parsed["client_secret"] = password
        elif password:
            parsed["token"] = password

        # Caller-supplied ``kwargs`` win over URL-derived values.
        merged = {"host": host, **parsed, **kwargs}
        return cls(**merged)

    #: Legacy alias for :meth:`from_url`. Kept so existing callers
    #: (notably :class:`DatabricksService.from_parsed_url`) keep
    #: working without an audit pass.
    from_parsed_url = from_url

    @classmethod
    def parse(cls, obj: Any):
        if isinstance(obj, cls):
            return obj
        elif isinstance(obj, URL):
            return cls.from_url(obj)
        elif isinstance(obj, str):
            url = URL.from_str(obj, default_scheme="https")
            return cls.from_url(url)
        elif isinstance(obj, dict):
            return cls(**obj)
        else:
            raise ValueError(
                f"Cannot parse {cls.__name__} from object of type {type(obj)}: {obj!r}"
            )

    # -------------------------------------------------------------------------
    # Singleton helpers
    # -------------------------------------------------------------------------

    @classmethod
    def current(cls, reset: bool = False, **overrides: Any) -> "DatabricksClient":
        global CURRENT_BASE_CLIENT

        if reset or CURRENT_BASE_CLIENT is None:
            with CURRENT_BASE_CLIENT_LOCK:
                if reset or CURRENT_BASE_CLIENT is None:
                    client = cls(**overrides)
                    CURRENT_BASE_CLIENT = client

        return CURRENT_BASE_CLIENT

    @classmethod
    def set_current(cls, workspace: Optional["DatabricksClient"]) -> None:
        global CURRENT_BASE_CLIENT
        with CURRENT_BASE_CLIENT_LOCK:
            CURRENT_BASE_CLIENT = workspace

    # -------------------------------------------------------------------------
    # Repr / context manager
    # -------------------------------------------------------------------------

    def __repr__(self):
        return f"{self.__class__.__name__}(host={self.host!r}, auth_type={self.auth_type!r})"

    def __str__(self):
        return self.__repr__()

    def __enter__(self) -> TC:
        object.__setattr__(self, "_was_connected", self.connected)
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if not self._was_connected:
            self.close()

    # -------------------------------------------------------------------------
    # Connection lifecycle
    # -------------------------------------------------------------------------

    @property
    def config(self):
        if self._workspace_config is None or self._account_config is None:
            config = self.make_config()
            ct = config.client_type

            if ct == ClientType.WORKSPACE:
                object.__setattr__(self, "_workspace_config", config)
            elif ct == ClientType.ACCOUNT:
                object.__setattr__(self, "_account_config", config)
            else:
                try:
                    return self.workspace_config
                except Exception:
                    return self.account_config
        return self._workspace_config or self._account_config

    @property
    def workspace_config(self) -> Config:
        if self._workspace_config is None:
            config = self.make_config(client_type=ClientType.WORKSPACE)
            object.__setattr__(self, "_workspace_config", config)
        return self._workspace_config

    @property
    def account_config(self) -> Config:
        if self._account_config is None:
            config = self.make_config(client_type=ClientType.ACCOUNT)
            object.__setattr__(self, "_account_config", config)
        return self._account_config

    @property
    def default_client_type(self) -> ClientType:
        return self.config.client_type

    def _make_base_config(
        self,
        client_type: Optional[ClientType] = None,
    ):
        if client_type == ClientType.ACCOUNT:
            host = "https://accounts.cloud.databricks.com"

            if not self.account_id:
                self.account_id = self.get_account_id()
        else:
            host = self.host

        if not self.cluster_id and not self.serverless_compute_id:
            self.serverless_compute_id = "auto"

        try:
            config = Config(
                host=host,
                token=self.token,
                client_id=self.client_id,
                client_secret=self.client_secret,
                account_id=self.account_id,
                cluster_id=self.cluster_id,
                serverless_compute_id=self.serverless_compute_id,
                token_audience=self.token_audience,
                azure_workspace_resource_id=self.azure_workspace_resource_id,
                azure_use_msi=self.azure_use_msi,
                azure_client_secret=self.azure_client_secret,
                azure_client_id=self.azure_client_id,
                azure_tenant_id=self.azure_tenant_id,
                azure_environment=self.azure_environment,
                google_credentials=self.google_credentials,
                google_service_account=self.google_service_account,
                profile=self.profile,
                config_file=self.config_file,
                auth_type=self.auth_type,
                http_timeout_seconds=self.http_timeout_seconds,
                retry_timeout_seconds=self.retry_timeout_seconds,
                debug_truncate_bytes=self.debug_truncate_bytes,
                debug_headers=self.debug_headers,
                rate_limit=self.rate_limit,
                product=self.product,
                product_version=self.product_version,
            )
        except Exception as e:
            raise ValueError(self._diagnose_config_error(e, client_type, host)) from e

        return config

    def _diagnose_config_error(
        self,
        error: Exception,
        client_type: Optional[ClientType],
        host: Optional[str],
    ) -> str:
        """Build an actionable error message explaining why Config() failed."""
        target = "account" if client_type == ClientType.ACCOUNT else "workspace"
        lines = [f"Failed to build Databricks {target} config: {error}"]

        if not host:
            lines.append(
                "  - host is missing. Set DATABRICKS_HOST "
                "(e.g. 'https://adb-1234567890123456.7.azuredatabricks.net') "
                "or pass host=... to DatabricksClient(...)."
            )

        if client_type == ClientType.ACCOUNT and not self.account_id:
            lines.append(
                "  - account_id is missing. Set DATABRICKS_ACCOUNT_ID "
                "or pass account_id=... (required for account-level clients)."
            )

        has_pat = bool(self.token)
        has_oauth = bool(self.client_id and self.client_secret)
        has_azure_sp = bool(self.azure_client_id and self.azure_client_secret and self.azure_tenant_id)
        has_azure_msi = self.azure_use_msi is True
        has_gcp = bool(self.google_credentials or self.google_service_account)
        has_profile = bool(self.profile)
        in_runtime = self.is_in_databricks_environment()

        if not any((has_pat, has_oauth, has_azure_sp, has_azure_msi, has_gcp, has_profile, in_runtime)):
            lines.append(
                "  - no credentials found. Provide one of:\n"
                "      * DATABRICKS_TOKEN (PAT)\n"
                "      * DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET (OAuth M2M)\n"
                "      * ARM_CLIENT_ID + ARM_CLIENT_SECRET + ARM_TENANT_ID (Azure SP)\n"
                "      * GOOGLE_CREDENTIALS or DATABRICKS_GOOGLE_SERVICE_ACCOUNT (GCP)\n"
                "      * DATABRICKS_CONFIG_PROFILE pointing to a profile in ~/.databrickscfg"
            )

        if self.client_id and not self.client_secret:
            lines.append("  - client_id is set but client_secret is missing (OAuth requires both).")
        if self.client_secret and not self.client_id:
            lines.append("  - client_secret is set but client_id is missing (OAuth requires both).")

        if self.auth_type:
            lines.append(
                f"  - auth_type explicitly set to {self.auth_type!r} — "
                f"clear it to let the SDK auto-detect."
            )

        if self.profile and self.config_file:
            lines.append(
                f"  - using profile {self.profile!r} from {self.config_file!r}; "
                f"verify the profile exists and has valid fields."
            )
        elif self.profile:
            lines.append(
                f"  - using profile {self.profile!r} from ~/.databrickscfg; "
                f"verify the profile exists."
            )

        return "\n".join(lines)

    def make_config(self, client_type: Optional[ClientType] = None):
        try:
            config = self._make_base_config(client_type=client_type)
        except Exception as first_err:
            if self.auth_type is not None:
                raise

            fallback_auth = "runtime" if self.is_in_databricks_environment() else "external-browser"
            object.__setattr__(self, "auth_type", fallback_auth)

            try:
                config = self._make_base_config(client_type=client_type)
            except Exception as second_err:
                raise ValueError(
                    f"Failed to build Databricks config with auto-detected auth.\n"
                    f"  initial attempt (auth_type=None): {first_err}\n"
                    f"  fallback attempt (auth_type={fallback_auth!r}): {second_err}"
                ) from second_err

        for key in (
            "auth_type",
            "token", "client_id", "client_secret", "account_id", "token_audience",
            "azure_workspace_resource_id", "azure_use_msi", "azure_client_secret",
            "azure_client_id", "azure_tenant_id", "azure_environment",
            "google_credentials", "google_service_account",
            "http_timeout_seconds", "retry_timeout_seconds", "debug_truncate_bytes",
            "debug_headers", "rate_limit",
        ):
            value = getattr(config, key, None)
            if value is not None:
                object.__setattr__(self, key, value)

        return config

    @property
    def local_config_folder(self):
        return Path.home() / ".config" / "databricks-sdk-py"

    @property
    def connected(self) -> bool:
        return self._workspace_client is not None or self._account_client is not None

    def connect(self, *, reset: bool = False) -> "DatabricksClient":
        if reset:
            self.close()

        config = self.config

        if config.client_type == ClientType.ACCOUNT:
            self.account_client()
        else:
            self.workspace_client()

        return self

    def close(self) -> None:
        for key in ("_workspace_client", "_account_client"):
            object.__setattr__(self, key, None)

        object.__setattr__(self, "_was_connected", False)

    def workspace_client(self) -> DWC:
        if self._workspace_client is None:
            object.__setattr__(self, "_workspace_client", DWC(config=self.workspace_config))
        return self._workspace_client

    def account_client(self) -> DAC:
        if self._account_client is None:
            object.__setattr__(self, "_account_client", DAC(config=self.account_config))
        return self._account_client

    def get_workspace_id(self) -> int:
        if self.workspace_id:
            return self.workspace_id

        self.workspace_id = int(self.workspace_client().get_workspace_id())
        return self.workspace_id

    def get_account_id(self) -> str:
        from yggdrasil.lazy_imports import polars as pl

        if self.account_id:
            return self.account_id

        local_cache = self.local_config_folder / "workspaces_latest.parquet"
        buff = BytesIO(local_cache, copy=False)
        workspace_id = self.get_workspace_id()

        if local_cache.exists() and local_cache.stat().st_size > 0:
            # TODO: fix
            existing_data = buff.as_media(MimeTypes.PARQUET).read_polars_frame()
            filtered = existing_data.filter(pl.col("workspace_id") == workspace_id)

            for record in filtered.to_dicts():
                self.set_account_id(record.get("account_id"))
                return self.account_id
        else:
            existing_data = None

        new_data = self.sql.execute(
            "select distinct account_id, cast(workspace_id as bigint) as workspace_id, workspace_url"
            " from system.access.workspaces_latest"
            " where status = 'RUNNING'"
        ).to_polars()

        if existing_data is not None:
            new_data = pl.concat([existing_data, new_data]).unique()

        buff.truncate()
        buff.seek(0)
        buff.as_media(MimeTypes.PARQUET).write_arrow_table(new_data.to_arrow())
        buff.close()

        filtered = new_data.filter(pl.col("workspace_id") == workspace_id)

        for record in filtered.to_dicts():
            self.set_account_id(record.get("account_id"))
            return self.account_id

        raise ValueError(
            f"Could not find account_id for workspace_id {workspace_id!r} in "
            f"system.access.workspaces_latest. Verify the current identity has "
            f"SELECT on system.access.workspaces_latest, that the workspace is "
            f"in RUNNING status, or set DATABRICKS_ACCOUNT_ID explicitly."
        )

    def set_account_id(self, account_id: str) -> "DatabricksClient":
        if account_id:
            object.__setattr__(self, "account_id", account_id)

            if self._workspace_config is not None:
                object.__setattr__(self._workspace_config, "account_id", account_id)

            if self._account_client is not None:
                self._account_client.config.account_id = account_id

        return self

    @staticmethod
    def is_in_databricks_environment() -> bool:
        return getenv("DATABRICKS_RUNTIME_VERSION") is not None

    def default_tags(self, update: bool = True):
        """Return default resource tags for Databricks assets.

        Returns:
            A dict of default tags.
        """
        if update:
            base = dict()
        else:
            base = {
                k: self.safe_tag_value(v)
                for k, v in (
                    ("Product", self.product),
                    ("ProductVersion", self.product_version),
                )
                if v
            }

        if self.custom_tags:
            base.update(self.custom_tags)

        return base

    @staticmethod
    def safe_tag_value(value: str, *, repl: str = "-") -> str:
        """
        Sanitize a tag string to match: ^[\\d \\w\\+\\-=:.:/@]*$
        Replaces any illegal characters with `repl` and collapses repeats.
        """
        if value is None:
            return ""

        s = str(value).strip()

        # fast path
        if _ALLOWED.fullmatch(s):
            return s

        # replace illegal chars (e.g. '#', '?', '&', '%') with repl
        s = _SANITIZE.sub(repl, s)

        # collapse repeated repl and trim edges
        if repl:
            s = re.sub(re.escape(repl) + r"{2,}", repl, s).strip(repl + " ")

        return s

    # ------------------------------------------------------------------ Path

    def dbfs_path(
        self,
        parts: Union[list[str], str],
        temporary: bool = False,
    ):
        """Create a DatabricksPath in this workspace.

        Args:
            parts: Path parts or string to parse.
            temporary: Temporary path

        Returns:
            A DatabricksPath instance.
        """
        from .fs.path import DatabricksPath

        return DatabricksPath.from_(
            obj=parts,
            client=self,
            temporary=temporary,
        )

    @staticmethod
    def _base_tmp_path(
        catalog_name: str | None = None,
        schema_name: str | None = None,
        volume_name: str | None = None,
    ) -> str:
        if catalog_name and schema_name:
            base_path = "/Volumes/%s/%s/%s" % (
                catalog_name, schema_name, volume_name or "tmp"
            )
        else:
            base_path = "/Workspace/Shared/.ygg/tmp"

        return base_path

    def tmp_path(
        self,
        suffix: str | None = None,
        extension: str | None = None,
        max_lifetime: float | None = None,
        catalog_name: str | None = None,
        schema_name: str | None = None,
        volume_name: str | None = None,
        base_path: str | None = None,
    ) -> "DatabricksPath":
        """
        Shared cache base under Volumes for the current user.

        Args:
            suffix: Optional suffix
            extension: Optional extension suffix to append.
            max_lifetime: Max lifetime of temporary path
            catalog_name: Unity catalog name for volume path
            schema_name: Unity schema name for volume path
            volume_name: Unity volume name for volume path
            base_path: Base temporary path

        Returns:
            A DatabricksPath pointing at the shared cache location.
        """
        start = int(time.time())
        max_lifetime = int(max_lifetime or 48 * 3600)
        end = max(0, int(start + max_lifetime))

        base_path = base_path or self._base_tmp_path(
            catalog_name=catalog_name,
            schema_name=schema_name,
            volume_name=volume_name,
        )

        rnd = os.urandom(4).hex()
        temp_path = f"tmp-{start}-{end}-{rnd}"

        if suffix:
            temp_path += suffix

        if extension:
            temp_path += ".%s" % extension

        self.clean_tmp_folder(
            raise_error=False,
            wait=False,
            base_path=base_path,
        )

        return self.dbfs_path(f"{base_path}/{temp_path}")

    def clean_tmp_folder(
        self,
        raise_error: bool = True,
        wait: WaitingConfigArg = True,
        catalog_name: str | None = None,
        schema_name: str | None = None,
        volume_name: str | None = None,
        base_path: str | None = None,
    ):
        wait = WaitingConfig.from_(wait)

        base_path = base_path or self._base_tmp_path(
            catalog_name=catalog_name,
            schema_name=schema_name,
            volume_name=volume_name,
        )

        if is_checked_tmp_path(
            host=self.base_url.to_string(),
            base_path=base_path,
        ):
            return self

        if wait.timeout:
            base_path = self.dbfs_path(base_path)

            LOGGER.debug("Cleaning temp path %s", base_path)

            for path in base_path.ls(recursive=False, allow_not_found=True):
                if path.name.startswith("tmp"):
                    parts = path.name.split("-")

                    if len(parts) > 2 and parts[0] == "tmp" and parts[1].isdigit() and parts[2].isdigit():
                        end = int(parts[2])

                        if end and time.time() > end:
                            path.remove(recursive=True)

            LOGGER.info("Cleaned temp path %s", base_path)
        else:
            (
                Job
                .make(self.clean_tmp_folder, raise_error=raise_error, base_path=base_path)
                .fire_and_forget()
            )

        return self

    # Sub services with optional caching for default workspace

    @staticmethod
    def lazy_property(
        self,
        *,
        cache_attr: str,
        factory: Callable[[], T],
        use_cache: bool,
    ) -> T:
        if use_cache:
            cached = getattr(self, cache_attr, None)
            if cached is not None:
                return cached

            created = factory()
            object.__setattr__(self, cache_attr, created)
            return created

        return factory()

    @property
    def workspaces(self) -> "Workspaces":
        from .workspaces.service import Workspaces

        return Workspaces(client=self)

    @property
    def workspace(self) -> "Workspace":
        from .workspaces import Workspace

        return self.lazy_property(
            self,
            cache_attr="_workspace",
            factory=lambda: Workspace(
                **{
                    f.name: getattr(self, f.name)
                    for f in fields(self)
                    if f.init
                }
            ),
            use_cache=True,
        )

    @property
    def sql(self) -> "SQLEngine":
        from .sql.engine import SQLEngine

        return self.lazy_property(
            self,
            cache_attr="_sql",
            factory=lambda: SQLEngine(client=self),
            use_cache=True,
        )

    @property
    def entity_tags(self) -> "EntityTags":
        from .tags.service import EntityTags

        return self.lazy_property(
            self,
            cache_attr="_entity_tags",
            factory=lambda: EntityTags(client=self),
            use_cache=True,
        )

    @property
    def warehouses(self) -> "Warehouses":
        from yggdrasil.databricks.warehouse.service import Warehouses

        return self.lazy_property(
            self,
            cache_attr="_warehouses",
            factory=lambda: Warehouses(client=self),
            use_cache=True,
        )

    @property
    def compute(self) -> "Compute":
        """Default cluster helper for this client."""
        from .compute.service import Compute

        return self.lazy_property(
            self,
            cache_attr="_compute",
            factory=lambda: Compute(client=self),
            use_cache=True,
        )

    @property
    def secrets(self) -> "Secrets":
        """Default secrets helper for this client."""
        from .secrets.service import Secrets

        return self.lazy_property(
            self,
            cache_attr="_secrets",
            factory=lambda: Secrets(client=self),
            use_cache=True,
        )

    @property
    def iam(self) -> "IAM":
        from .iam import IAM

        return self.lazy_property(
            self,
            cache_attr="_iam",
            factory=lambda: IAM(client=self),
            use_cache=True,
        )

    @property
    def tables(self) -> "Tables":
        """Collection-level Unity Catalog table service for this client."""
        from .sql.tables import Tables

        return self.lazy_property(
            self,
            cache_attr="_tables",
            factory=lambda: Tables(client=self),
            use_cache=True,
        )

    @property
    def views(self) -> "Views":
        """Collection-level Unity Catalog view service for this client."""
        from .sql.views import Views

        return self.lazy_property(
            self,
            cache_attr="_views",
            factory=lambda: Views(client=self),
            use_cache=True,
        )

    @property
    def columns(self) -> "Columns":
        """Collection-level Unity Catalog column service for this client."""
        from .sql.columns import Columns

        return self.lazy_property(
            self,
            cache_attr="_columns_svc",
            factory=lambda: Columns(client=self),
            use_cache=True,
        )

    @property
    def catalogs(self) -> "Catalogs":
        """Collection-level Unity Catalog hierarchy service for this client.

        Provides dict-like access to catalogs, schemas, and tables::

            client.catalogs["main"]                   # Catalog
            client.catalogs["main"]["sales"]          # Schema
            client.catalogs["main"]["sales"]["orders"]  # Table
        """
        from .sql.catalogs import Catalogs

        return self.lazy_property(
            self,
            cache_attr="_catalogs",
            factory=lambda: Catalogs(client=self),
            use_cache=True,
        )

    @property
    def schemas(self) -> "Schemas":
        """Collection-level Unity Catalog schema service for this client.

        Provides dict-like access to schemas and tables::

            client.schemas["main.sales"]             # Schema
            client.schemas["main.sales.orders"]      # Table
            client.schemas(catalog_name="main")      # Schemas scoped to "main"
        """
        from .sql.schemas import Schemas

        return self.lazy_property(
            self,
            cache_attr="_schemas",
            factory=lambda: Schemas(client=self),
            use_cache=True,
        )

    @property
    def genie(self) -> "Genie":
        """Genie conversation and space management helper for this client."""
        from .ai.genie import Genie

        return self.lazy_property(
            self,
            cache_attr="_genie",
            factory=lambda: Genie(client=self),
            use_cache=True,
        )

    @property
    def filesystem(self) -> "FileSystem":
        """OS-style Databricks filesystem helper for this client."""
        from .fs.service import FileSystem

        return self.lazy_property(
            self,
            cache_attr="_filesystem",
            factory=lambda: FileSystem(client=self),
            use_cache=True,
        )

    @property
    def fs(self) -> "FileSystem":
        """Short alias for :attr:`filesystem`."""
        return self.filesystem

    def spark_connect(self):
        from databricks.connect import DatabricksSession  # noqa

        session = (
            DatabricksSession().builder
            .sdkConfig(self.workspace_config)
            .getOrCreate()
        )

        return session


DATABRICKS_CLIENT_INIT_NAMES = frozenset(f.name for f in fields(DatabricksClient) if f.init)
CHECKED_TMP_WORKSPACES: ExpiringDict[str, set[str]] = ExpiringDict()


def is_checked_tmp_path(host: str, base_path: str):
    existing = CHECKED_TMP_WORKSPACES.get(host)

    if existing is None:
        CHECKED_TMP_WORKSPACES[host] = set(base_path)
        return False

    if base_path in existing:
        return True

    existing.add(base_path)
    return False


@dataclass
class DatabricksService(ABC):
    client: DatabricksClient = field(
        default_factory=DatabricksClient.current,
        repr=False, compare=False, hash=False,
    )

    _current: ClassVar[Optional["DatabricksService"]] = None

    def __post_init__(self):
        pass

    def __getstate__(self):
        return {"client": self.client}

    def __setstate__(self, state):
        self.client = state["client"]

    @staticmethod
    def check_client(
        client: Optional[DatabricksClient] = None,
        **client_kwargs: Any,
    ):
        if client is None and not client_kwargs:
            return DatabricksClient.current()

        client = client or DatabricksClient.current()
        return replace(client, **client_kwargs)

    def __call__(self, *args, **kwargs):
        return self

    def __enter__(self) -> TS:
        self.client.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.client.__exit__(exc_type, exc_val, exc_tb)

    def connect(self):
        return self

    def close(self):
        pass

    @classmethod
    def service_name(cls) -> str:
        return cls.__name__.lower()

    @classmethod
    def url_scheme(cls) -> str:
        return f"dbks+{cls.service_name()}"

    @classmethod
    def current(cls, reset: bool = False) -> TS:
        if reset or cls._current is None:
            cls._current = cls(client=DatabricksClient.current())
        return cls._current

    @classmethod
    def from_parsed_url(cls, url: URL):
        mod = __import__(f"yggdrasil.databricks.{cls.service_name()}", fromlist=[cls.__name__])
        service_cls = getattr(mod, cls.__name__)

        return service_cls(client=DatabricksClient.from_parsed_url(url))

    def to_url(self, scheme: str | None = None) -> URL:
        return (
            self.client
            .to_url(scheme=scheme or self.url_scheme())
            .with_path(f"/{self.service_name()}")
        )

    def is_in_databricks_environment(self):
        return self.client.is_in_databricks_environment()

    def default_tags(self, update: bool = True):
        """Return default resource tags for Databricks assets.

        Returns:
            A dict of default tags.
        """
        base = self.client.default_tags(update=update)
        base["ServiceName"] = self.service_name()

        return base

    @property
    def sql(self) -> "SQLEngine":
        return self.client.sql

    @property
    def warehouses(self) -> "Warehouses":
        return self.client.warehouses

    @property
    def compute(self) -> "Compute":
        return self.client.compute

    @property
    def secrets(self) -> "Secrets":
        return self.client.secrets

    @property
    def tables(self) -> "Tables":
        """Collection-level Unity Catalog table service (shorthand for ``client.tables``)."""
        return self.client.tables

    @property
    def views(self) -> "Views":
        """Collection-level Unity Catalog view service (shorthand for ``client.views``)."""
        return self.client.views

    @property
    def catalogs(self) -> "Catalogs":
        """Collection-level Unity Catalog hierarchy service (shorthand for ``client.catalogs``)."""
        return self.client.catalogs

    @property
    def schemas(self) -> "Schemas":
        """Collection-level Unity Catalog schema service (shorthand for ``client.schemas``)."""
        return self.client.schemas

    @property
    def genie(self) -> "Genie":
        """Genie service (shorthand for ``client.genie``)."""
        return self.client.genie

    @property
    def filesystem(self) -> "FileSystem":
        """Filesystem service (shorthand for ``client.filesystem``)."""
        return self.client.filesystem

    @property
    def fs(self) -> "FileSystem":
        """Short alias for :attr:`filesystem`."""
        return self.client.fs


class DatabricksResource(ABC):
    service: DatabricksService = field(
        default_factory=DatabricksService.current,
        repr=False, compare=False, hash=False,
    )

    def __getstate__(self):
        state = super().__getstate__()
        state["service"] = self.service
        return state

    def __setstate__(self, state):
        object.__setattr__(self, "service", state["service"])
        super().__setstate__(state)

    def __init__(self, service=None, *args, **kwargs):
        self.service = DatabricksService.current() if service is None else service
        super().__init__(*args, **kwargs)

    @property
    def client(self) -> DatabricksClient:
        return self.service.client

    @property
    def sql(self) -> "SQLEngine":
        """Shorthand for ``self.service.client.sql`` — the active :class:`SQLEngine`."""
        return self.client.sql