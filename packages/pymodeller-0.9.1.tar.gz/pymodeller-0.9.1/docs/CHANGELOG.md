# CHANGELOG

<!-- version list -->

## v0.9.1 (2026-05-14)

### Bug Fixes

- Update settings.json
  ([`45fd25d`](https://github.com/pymodeller/PyModeller/commit/45fd25d24564c2ef65ac1bc66e9bbb0388eaa13c))

- Update settings.json
  ([`58f8b63`](https://github.com/pymodeller/PyModeller/commit/58f8b63f042879dcd1016c1f4870088acd237063))


## v0.9.0 (2026-05-14)

### Bug Fixes

- Update command check
  ([`d836b93`](https://github.com/pymodeller/PyModeller/commit/d836b93fac03b53e20d151f518ffdc83b40faef5))

- Update models loader
  ([`eab741c`](https://github.com/pymodeller/PyModeller/commit/eab741c9933efac9998c187acfd147b8ec125e09))

- Update tests
  ([`3a797eb`](https://github.com/pymodeller/PyModeller/commit/3a797eb710187164daa8700669bbbeae4758a9c4))

### Features

- Added new feature generation .env files from environments.yaml
  ([`7341fad`](https://github.com/pymodeller/PyModeller/commit/7341fad10e18c6cb5b7366b814f265c64bf1195c))

### Testing

- Fixing tests
  ([`eb4a37a`](https://github.com/pymodeller/PyModeller/commit/eb4a37a00481aa0b5c6f94a6dc188a4d6ca15032))

- Update tests
  ([`8b87085`](https://github.com/pymodeller/PyModeller/commit/8b870857c4ee8760ab4d4fb19fb782cd9358d45d))

- Update tests
  ([`41ec804`](https://github.com/pymodeller/PyModeller/commit/41ec804bcea4412e1603affddd99d1a8af7d0783))

- Update tests again
  ([`fadf057`](https://github.com/pymodeller/PyModeller/commit/fadf0576138d2e2e42b3055ceb17d0f31b13f4c3))

- Update tests for dev_tools
  ([`41f2638`](https://github.com/pymodeller/PyModeller/commit/41f263899c87ecc7b109b63142ef18ae45c24cbc))


## v0.8.1 (2026-05-13)

### Bug Fixes

- Update configuration toml
  ([`dd65640`](https://github.com/pymodeller/PyModeller/commit/dd65640d9430af4a485f7cc32ca74df41edebabd))


## v0.8.0 (2026-05-13)

### Bug Fixes

- Update configuration toml
  ([`501afee`](https://github.com/pymodeller/PyModeller/commit/501afee94681470495936efb7c6523f377c580d3))

- Update template
  ([`c0aea85`](https://github.com/pymodeller/PyModeller/commit/c0aea8545d2048ecd3cee97084ec61ed295ae7e1))

### Features

- Added exception generator
  ([`201b000`](https://github.com/pymodeller/PyModeller/commit/201b000372b2f39f3576e83b20594f1a7885c5df))

- Reading configuration from tool.pymodeller -> pyproject.toml
  ([`d07f0ac`](https://github.com/pymodeller/PyModeller/commit/d07f0acedc797a3757df2d363f1ca5059af0531d))


## v0.7.4 (2026-05-13)

### Bug Fixes

- Added feature generate environment yaml
  ([`b35c2c3`](https://github.com/pymodeller/PyModeller/commit/b35c2c32e620dcbb0983f5c62d3a832230cebf42))

- Added feature generate environment yaml and fix tests
  ([`4d8f84c`](https://github.com/pymodeller/PyModeller/commit/4d8f84c1a4b89732b3f8a3dad6fcab469d38b0a8))

### Testing

- Update tests
  ([`d5aa29e`](https://github.com/pymodeller/PyModeller/commit/d5aa29e56077af1e1d81fb976916b5930981ae6e))


## v0.7.3 (2026-05-12)

### Bug Fixes

- Update yaml env source template
  ([`42e6976`](https://github.com/pymodeller/PyModeller/commit/42e6976f42b6b7dd397952f02a84151b28b4d26f))


## v0.7.2 (2026-05-12)

### Bug Fixes

- Added environments yaml reading & setting
  ([`6dc2757`](https://github.com/pymodeller/PyModeller/commit/6dc27576d04fe64b6a5c77bcb0ae4773437991ac))

- Added source env jinja
  ([`0c2b8db`](https://github.com/pymodeller/PyModeller/commit/0c2b8db8f0716047dd482f9412beef54571b8531))

- Added source env jinja
  ([`e41821e`](https://github.com/pymodeller/PyModeller/commit/e41821eed6ec15d1a801e31ba56b750d52d00f6e))

- Ignore __main__ in sonar
  ([`4b227ac`](https://github.com/pymodeller/PyModeller/commit/4b227acbd4c21694c3fe3317d09bc342567efb85))

- Pretty qa
  ([`1d85787`](https://github.com/pymodeller/PyModeller/commit/1d85787a511c14576c888add2810fd31aa59295b))

- Pretty qa
  ([`a2de471`](https://github.com/pymodeller/PyModeller/commit/a2de47114ec63a3ec9ae66d5bd7a695f17c2f498))

- Pretty qa
  ([`5231516`](https://github.com/pymodeller/PyModeller/commit/523151621b811499e0abee9b4b8ceda3df09dd0e))

- Update generate vars in .env.example
  ([`7b19c57`](https://github.com/pymodeller/PyModeller/commit/7b19c57762f08f62aeb9c9f5ac0b7af960836e00))


## v0.7.1 (2026-05-02)

### Bug Fixes

- Added any option and fix in source master_pydantic.jinja
  ([`3ece8ec`](https://github.com/pymodeller/PyModeller/commit/3ece8ec7036fd343ca80c9c6ae528b5dfcedb4fb))


## v0.7.0 (2026-04-30)

### Bug Fixes

- Added pre-hooks
  ([`6217831`](https://github.com/pymodeller/PyModeller/commit/62178316059007e772ba4dc0d2fc16c8e30d056f))

- Update CONVENTIONS.md
  ([`ba8fc7f`](https://github.com/pymodeller/PyModeller/commit/ba8fc7f5f9ce10d364d249f77d9d2fe039fc6cad))

- Update exclude value in fields
  ([`af1ae01`](https://github.com/pymodeller/PyModeller/commit/af1ae01e4ab7512b9b4488ffcf7f9290a259322a))

- Update pre-hook names
  ([`11ed85b`](https://github.com/pymodeller/PyModeller/commit/11ed85b1936b7552d88eb5e2d5266aac596bc6f9))

- Update skill conventions
  ([`e80ee9b`](https://github.com/pymodeller/PyModeller/commit/e80ee9b3fee73697e3d11201805593d043c1f159))

- Update style
  ([`4450ebd`](https://github.com/pymodeller/PyModeller/commit/4450ebd0c7412c4bb8883ba15472d405d86cbfdf))

### Features

- Added agent files
  ([`9a872ef`](https://github.com/pymodeller/PyModeller/commit/9a872ef1c99ba5c815b24559637751cca6ff967b))

- Update files
  ([`23b04aa`](https://github.com/pymodeller/PyModeller/commit/23b04aa8f7b6b1e6b51cc471880ba85a0370f3a5))


## v0.6.3 (2026-04-28)

### Bug Fixes

- Added include_init_settings option
  ([`67316e4`](https://github.com/pymodeller/PyModeller/commit/67316e4ed69f2725985c2944aea9982f5ba17f7e))


## v0.6.2 (2026-04-28)

### Bug Fixes

- Update master_pydantic.jinja template
  ([`67c5fbe`](https://github.com/pymodeller/PyModeller/commit/67c5fbe064dcf7cdb2eb30b27513455d68803de3))


## v0.6.1 (2026-04-28)

### Bug Fixes

- Update base_settings and loader check duplicates
  ([`2a68251`](https://github.com/pymodeller/PyModeller/commit/2a682517c3dd6d51f521b14cf05e88b44924589b))


## v0.6.0 (2026-04-27)

### Features

- Added parser default values
  ([`33fef7f`](https://github.com/pymodeller/PyModeller/commit/33fef7f8a077d78d940d3e1220879a96381fde96))


## v0.5.5 (2026-04-27)

### Bug Fixes

- Update actions
  ([`06d44b7`](https://github.com/pymodeller/PyModeller/commit/06d44b7d64135133fc56ef503b1623cc0541bc42))


## v0.5.4 (2026-04-27)

### Bug Fixes

- Update types mode default value
  ([`3d52dfc`](https://github.com/pymodeller/PyModeller/commit/3d52dfcbbb67751cad2fd416a04e2acf6ac2def5))


## v0.5.3 (2026-04-26)

### Bug Fixes

- Remove comments
  ([`b44b905`](https://github.com/pymodeller/PyModeller/commit/b44b905112ae3ba8c7113ec7121f9123fe1fce4c))

- Remove hash file
  ([`4800c19`](https://github.com/pymodeller/PyModeller/commit/4800c199ef4e0c408f321dc88d7c18a1abf9af1b))


## v0.5.2 (2026-04-26)

### Bug Fixes

- Creating new version
  ([`f03638e`](https://github.com/pymodeller/PyModeller/commit/f03638e42ce1d446e1784a557614b37a8ab9203d))

### Documentation

- Update docs
  ([`e513746`](https://github.com/pymodeller/PyModeller/commit/e513746072145ce2327b1c5e7cc0e53127496218))


## v0.5.1 (2026-04-24)

### Bug Fixes

- Added ruff format commands
  ([`a137fbe`](https://github.com/pymodeller/PyModeller/commit/a137fbe1b9d724511180f422850704e254537c01))

- Remove no used packages
  ([`ff5578d`](https://github.com/pymodeller/PyModeller/commit/ff5578dca3a300db3396628f1a05265b1b70ef55))


## v0.1.0 (2026-04-24)

- Initial Release

## v0.3.1 (2026-04-23)

### Bug Fixes

- Generated import fix in pydantic models
  ([`3359c18`](https://github.com/pymodeller/PyModeller/commit/3359c18a349b9a1800e7c5ebf19502f0d49d3c82))


## v0.3.0 (2026-04-23)

### Continuous Integration

- Update sonar-project.properties
  ([`c0e7750`](https://github.com/pymodeller/PyModeller/commit/c0e7750d5613b48b8cb8f39bfd043cf8f06fa981))

### Features

- Added peewee_generator.py.py from jinja
  ([`d3dc14f`](https://github.com/pymodeller/PyModeller/commit/d3dc14f6878e26dbc16c4fce67fe80d158adab4f))

- Added pydantic_generator.py from jinja
  ([`bb26a48`](https://github.com/pymodeller/PyModeller/commit/bb26a484ceb019b77894d1ebce659c73fc74b00e))

- Load data from yaml, and save origins in pydantic_generator
  ([`84f9c3f`](https://github.com/pymodeller/PyModeller/commit/84f9c3f9d49060dc9f084cf9b76627cef3efcf52))

### Testing

- Added tests
  ([`b18c259`](https://github.com/pymodeller/PyModeller/commit/b18c2597e36159978360480215a4d3a4cc99bfce))

- Code generator fix test
  ([`911c102`](https://github.com/pymodeller/PyModeller/commit/911c102b8286ef7587ce3beef9704dd78c3bfc53))


## v0.2.7 (2026-04-22)

### Bug Fixes

- Update configuration
  ([`d0d05c5`](https://github.com/pymodeller/PyModeller/commit/d0d05c5f8c3a6b739b5344f8419f93e001ab25b5))


## v0.2.6 (2026-04-22)

### Bug Fixes

- Added more tests
  ([`93138ca`](https://github.com/pymodeller/PyModeller/commit/93138ca45fe658ef9ee8646429bab15936efcd3b))

### Continuous Integration

- Sonarqube.yaml update
  ([`863ecf9`](https://github.com/pymodeller/PyModeller/commit/863ecf9b03e5902e8da4ced3680b39cafd2eacf3))

- Update organization key in sonar-project.properties
  ([`1abd352`](https://github.com/pymodeller/PyModeller/commit/1abd352d29afaf08a452f68f24d3cd6fe26ce3dc))

- Update secrets
  ([`bdc6941`](https://github.com/pymodeller/PyModeller/commit/bdc6941595219b1817a6162b2f4bbce66db32bc5))

- Update workflows
  ([`87740ae`](https://github.com/pymodeller/PyModeller/commit/87740aed48cf64e4762461421a0010ba7756c36a))


## v0.2.5 (2026-04-22)


## v0.2.5-rc.2 (2026-04-22)

### Bug Fixes

- Added sonar badges and sonar-project.properties
  ([`cd2e30a`](https://github.com/pymodeller/PyModeller/commit/cd2e30ac9f232e2d962c4b147960ec1a1ec72038))


## v0.2.5-rc.1 (2026-04-22)

### Bug Fixes

- Fixing sonarqube and readme
  ([`7454cd8`](https://github.com/pymodeller/PyModeller/commit/7454cd8f9e36a91b2271f81bab484cc2e15ff25b))

- Pretty qa
  ([`49c9659`](https://github.com/pymodeller/PyModeller/commit/49c965906da732bd7ab7ddc496f86e6006b192bc))


## v0.2.4 (2026-04-22)

### Bug Fixes

- Fixing sonarqube
  ([`344cb23`](https://github.com/pymodeller/PyModeller/commit/344cb234b3b99ff4fd6a8fb85b53f5d3965d27fe))


## v0.2.3 (2026-04-22)

### Bug Fixes

- Update docs
  ([`2e35268`](https://github.com/pymodeller/PyModeller/commit/2e352683f72d43d4c9240672cf2dc00bb1dbae80))


## v0.2.2 (2026-04-22)

### Bug Fixes

- Fixed security spot sonarqube
  ([`2f09cb2`](https://github.com/pymodeller/PyModeller/commit/2f09cb2963454ec1b38160a9187f8417c74b41d4))

### Continuous Integration

- Resolve token conflict
  ([`e236eff`](https://github.com/pymodeller/PyModeller/commit/e236efff891d97c4d3a109b3516f18918bb6db76))

- Update workflow in test and semantic-release.yaml
  ([`7ca5384`](https://github.com/pymodeller/PyModeller/commit/7ca53841f48c590c65832278bb9a9c536f0b3a05))


## v0.2.1 (2026-04-21)

### Bug Fixes

- Update ci environment
  ([`29da46f`](https://github.com/pymodeller/PyModeller/commit/29da46fb85c7a1d47e1c6471a82f4e34803057d0))


## v0.2.1-rc.2 (2026-04-21)

### Bug Fixes

- Added job step for release workflow
  ([`a06edd1`](https://github.com/pymodeller/PyModeller/commit/a06edd10c8613424318d4894bcf62ce42b8cc679))


## v0.2.1-rc.1 (2026-04-21)

### Bug Fixes

- Remove workflow
  ([`40f0621`](https://github.com/pymodeller/PyModeller/commit/40f062154ff74282d3bc65f034711444acafee49))

### Continuous Integration

- Added approve-release guardian
  ([`da6ef3a`](https://github.com/pymodeller/PyModeller/commit/da6ef3a9f5ecce162d0755f7cf5074d6be407ce4))

- Cleaning comments
  ([`d58e719`](https://github.com/pymodeller/PyModeller/commit/d58e71945ffafd6bdfbdc208a40e1df35aeb27a7))

- Update conditions publish
  ([`0fea6c5`](https://github.com/pymodeller/PyModeller/commit/0fea6c5eb454f07455197fa1a6e4714bcf115d65))

- Update generate docs conditions
  ([`1fcc95e`](https://github.com/pymodeller/PyModeller/commit/1fcc95e3725a502e91eb7b9b942d444b178aa417))


## v0.2.0 (2026-04-21)


## v0.2.0-rc.1 (2026-04-21)

### Bug Fixes

- Fix imports
  ([`c6e5f8d`](https://github.com/pymodeller/PyModeller/commit/c6e5f8d5d8eb4c9836ace279fbb69b7cf3f52e6f))

### Continuous Integration

- Remove "call" from job names
  ([`c4407e8`](https://github.com/pymodeller/PyModeller/commit/c4407e8f631d476edcd580e1a1d7967edef05959))

- Update main workflow for publish stage
  ([`afaf0a6`](https://github.com/pymodeller/PyModeller/commit/afaf0a676bcb8f97c0b9ae120c7df5c226ff2fbf))

- Update needs in job "call"
  ([`1125f64`](https://github.com/pymodeller/PyModeller/commit/1125f64cdacfae78fa4188b21390392bf855292d))

### Documentation

- Update readme
  ([`3ee1c34`](https://github.com/pymodeller/PyModeller/commit/3ee1c346bfb06e7b805ce225fe1785b0a712a42a))

### Features

- Added enum generator
  ([`ccc5760`](https://github.com/pymodeller/PyModeller/commit/ccc57600797c5c7730fc5aa094f1331389835d45))

### Testing

- Fix setup command result
  ([`0dae3c7`](https://github.com/pymodeller/PyModeller/commit/0dae3c70adfabcac5258562ccf8581da57e35c92))

- Fix setup command result
  ([`fdde17c`](https://github.com/pymodeller/PyModeller/commit/fdde17ce16508f2215d8f8d36db0d580f81ccea1))


## v0.1.5-rc.1 (2026-04-20)

### Bug Fixes

- Update ci
  ([`f3bcafe`](https://github.com/pymodeller/PyModeller/commit/f3bcafe6c928357b005e43501661725425974f23))


## v0.1.4 (2026-04-20)

### Bug Fixes

- Added exit commands
  ([`7db92df`](https://github.com/pymodeller/PyModeller/commit/7db92df1e442f7a354e6cc535ab02d60912b497f))

- Added exit commands
  ([`8a7c4ac`](https://github.com/pymodeller/PyModeller/commit/8a7c4accb85a9c4d13e760f983b8d5e477427e25))


## v0.1.3 (2026-04-20)

### Bug Fixes

- Get latest changes in publish
  ([`2d91214`](https://github.com/pymodeller/PyModeller/commit/2d91214559e69633ba8142e938cbe5ec2e2ca830))


## v0.1.2 (2026-04-20)

### Bug Fixes

- Added pyyaml as dependency
  ([`9cc2303`](https://github.com/pymodeller/PyModeller/commit/9cc2303a710d9f72da24916a3c28f1a51c2ec5fc))

### Continuous Integration

- Added environment
  ([`eea5281`](https://github.com/pymodeller/PyModeller/commit/eea52817364826c78e1c4e1107c8d20006469498))

- Update main.yaml
  ([`f4dcd16`](https://github.com/pymodeller/PyModeller/commit/f4dcd168498826e283cb66782e90f485a15fb59d))

- Update main.yaml
  ([`2daf41d`](https://github.com/pymodeller/PyModeller/commit/2daf41d9b52121bae94af8ca594c38dba4bcbd4a))

- Update workflow with pypi
  ([`76ff5e8`](https://github.com/pymodeller/PyModeller/commit/76ff5e8806f52fa32a83ffeff191891bc979a2ca))


## v0.1.1 (2026-04-20)

### Bug Fixes

- Added trusted publish package
  ([`3e784f2`](https://github.com/pymodeller/PyModeller/commit/3e784f26a86ca6efe22aeb336e296c4426d81c1d))


## v0.1.0 (2026-04-20)

### Features

- Update sample py_modeller.yaml
  ([`e2c10ae`](https://github.com/pymodeller/PyModeller/commit/e2c10aecbc04f34148ef670226be44ae8e6f877c))


## v0.0.3-rc.2 (2026-04-20)

### Bug Fixes

- Update actions.yaml
  ([`83f084e`](https://github.com/pymodeller/PyModeller/commit/83f084eca13c21de09f577be5a477e018773159b))


## v0.0.3-rc.1 (2026-04-20)

### Bug Fixes

- Update configuration toml semantic-releae
  ([`c0538dc`](https://github.com/pymodeller/PyModeller/commit/c0538dcf138eace9cdde57ff6c93e0d10bfa66ac))

### Documentation

- Update README.md
  ([`36177f3`](https://github.com/pymodeller/PyModeller/commit/36177f39e654af125de9348f6e675305c671bee0))

- Update README.md
  ([`5bda8a6`](https://github.com/pymodeller/PyModeller/commit/5bda8a6875d9cf0074637cde82ab2ae524c3cea7))


## v0.0.2 (2026-04-20)

### Bug Fixes

- Update docs
  ([`e6f51f7`](https://github.com/pymodeller/PyModeller/commit/e6f51f738357462910949c9f4861a154c120daf3))


## v0.0.1 (2026-04-20)

- Initial Release

## v0.0.1-rc.1 (2026-04-20)

- Initial Release
