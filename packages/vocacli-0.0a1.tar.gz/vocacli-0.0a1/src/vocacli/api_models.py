from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel
from pydantic.fields import Field


class Album(BaseModel):
    additional_names: str | None = Field(alias="additionalNames", default=None)
    description: str | None = None
    artist_string: str | None = Field(alias="artistString", default=None)
    id: int
    name: str | None = None
    release_date: DateTime = Field(alias="releaseDate")
    rating: float = Field(alias="ratingAverage")
    tags: list[AlbumResultTag] | None = None
    weblinks: list[WebLink] | None = Field(alias="webLinks", default=None)


class Song(BaseModel):
    additional_names: str | None = Field(alias="additionalNames", default=None)
    artist_string: str | None = Field(alias="artistString", default=None)
    id: int
    name: str | None = None
    publish_date: str | None = Field(alias="publishDate", default=None)
    rating: float = Field(alias="ratingScore")
    tags: list[AlbumResultTag] | None = None
    weblinks: list[WebLink] | None = Field(alias="webLinks", default=None)


class AlbumSearch(BaseModel):
    items: list[Album]
    total_count: int = Field(alias="totalCount")


class SongSearch(BaseModel):
    items: list[Song]


class Artist(BaseModel):
    additional_names: str = Field(alias="additionalNames")
    id: int
    name: str


class ArtistForAlbumSearch(BaseModel):
    categories: ArtistCategory
    roles: ArtistRole
    name: str | None = None


class ArtistCategory(StrEnum):
    Nothing = "Nothing"
    Vocalist = "Vocalist"
    Producer = "Producer"
    Animator = "Animator"
    Label = "Label"
    Circle = "Circle"
    Other = "Other"
    Band = "Band"
    Illustrator = "Illustrator"
    Subject = "Subject"


class ArtistRole(StrEnum):
    Default = "Default"
    Animator = "Animator"
    Arranger = "Arranger"
    Composer = "Composer"
    Distributor = "Distributor"
    Illustrator = "Illustrator"
    Instrumentalist = "Instrumentalist"
    Lyricist = "Lyricist"
    Mastering = "Mastering"
    Publisher = "Publisher"
    Vocalist = "Vocalist"
    VoiceManipulator = "VoiceManipulator"
    Other = "Other"
    Mixer = "Mixer"
    Chorus = "Chorus"
    Encoder = "Encoder"
    VocalDataProvider = "VocalDataProvider"
    RecordingEngineer = "RecordingEngineer"


class DateTime(BaseModel):
    is_empty: bool = Field(alias="isEmpty")
    day: int | None = None
    month: int | None = None
    year: int | None = None


class AlbumResultTag(BaseModel):
    tag: Tag


class Tag(BaseModel):
    category_name: str = Field(alias="categoryName")
    id: int
    name: str


class WebLink(BaseModel):
    url: str | None = None
    description: str | None = None
