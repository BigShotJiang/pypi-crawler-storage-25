from vocacli.main import run

if __name__ == "__main__":
    run()
