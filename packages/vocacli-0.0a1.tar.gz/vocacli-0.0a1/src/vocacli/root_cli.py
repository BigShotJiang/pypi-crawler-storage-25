import importlib.metadata
import logging
import sys
from enum import StrEnum
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field

from vocacli.album import ALBUM_HELP, CliAlbum
from vocacli.helpers import deserialize, docopt, todo
from vocacli.song import SONG_HELP, CliSong

# ruff: disable[E501]
ROOT_HELP: str = """\
Usage: vocacli [-l LEVEL | --log-level LEVEL] [-h | --help] COMMAND [ARGS...]
       vocacli [-v | --version]

Query Vocaloid related data from the command line.

COMMAND:
    album           Search for an album from VocaDB.
    song            Search for a song from VocaDB.
    artist          Not yet implemented
    collection      Not yet implemented
    event           Not yet implemented
    help [COMMAND]  Show help for a COMMAND
See `vocacli help COMMAND` or `vocacli COMMAND --help` for detailed help on a command

Options:
    -l LEVEL, --log-level LEVEL  Set lowest log level that will be displayed
                                 (One of: DEBUG, INFO, WARN, ERROR) [default: WARN]
    -h, --help                   Print this help
    -v, --version                Print version information
"""

_SONG_USAGE: str = """\
Usage: vocacli song [-h |--help] [ARGS]

Options:
    -h, --help  Print this help
"""

_ARTIST_USAGE: str = """\
Usage: vocacli artist [-h |--help] [ARGS]

Options:
    -h, --help  Print this help
"""

_COLLECTION_USAGE: str = """\
Usage: vocacli collection [-h |--help] [ARGS]

Options:
    -h, --help  Print this help
"""

_EVENT_USAGE: str = """\
Usage: vocacli event [-h |--help] [ARGS]

Options:
    -h, --help  Print this help
"""


HELP_HELP: str = """\
Usage: vocacli help [-h |--help] [COMMAND]

Get help for VocaCli or a specified COMMAND.

COMMAND:
    album       Search for an album on VocaDB
    song        Search for a song on VocaDB
    artist      Not yet implemented
    collection  Not yet implemented
    event       Not yet implemented
    help

Options:
    -h, --help  Print this help
"""
# ruff: enable[E501]


class Help:
    SONG: str = _SONG_USAGE
    ARTIST: str = _ARTIST_USAGE
    COLLECTION: str = _COLLECTION_USAGE
    EVENT: str = _EVENT_USAGE


class Command(StrEnum):
    ALBUM = "album"
    SONG = "song"
    ARTIST = "artist"
    COLLECTION = "collection"
    EVENT = "event"
    HELP = "help"


# Use logging.getLevelName
class LogLevel(StrEnum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"


class CliRoot(BaseModel):
    log_level: LogLevel = Field(validation_alias="--log-level")
    help: bool = Field(validation_alias="--help")
    version: bool = Field(validation_alias="--version")
    command: Command | None = Field(validation_alias="COMMAND")
    command_args: list[str] | None = Field(validation_alias="ARGS")

    model_config: ClassVar[ConfigDict] = ConfigDict(extra="forbid")


class CliArtist(BaseModel):
    pass


class CliCollection(BaseModel):
    pass


class CliEvent(BaseModel):
    pass


class CliHelp(BaseModel):
    command: Command | None = Field(validation_alias="COMMAND")
    help: bool = Field(validation_alias="--help")
    # This field is not useful at all
    private_help: bool = Field(validation_alias="help")


def get_args() -> tuple[
    CliAlbum | CliSong | CliArtist | CliCollection | CliEvent | CliHelp,
    int,
]:
    cli = deserialize(CliRoot, docopt(ROOT_HELP, options_first=True))

    if cli.version:
        print(f"VocaCLI v{importlib.metadata.version('vocacli')}")
        sys.exit(0)

    if cli.help or cli.command is None:
        print(ROOT_HELP)
        sys.exit(0)

    # Set level via the command line arg given, this relies
    # on this function being called before any logging occurs.
    level = logging.getLevelNamesMapping()[cli.log_level]

    command_args = cli.command_args or []
    match cli.command:
        case Command.ALBUM:
            command_args = ["album", *command_args]
            return deserialize(
                CliAlbum,
                docopt(ALBUM_HELP, argv=command_args, options_first=True),
            ), level
        case Command.SONG:
            command_args = ["song", *command_args]
            return deserialize(
                CliSong,
                docopt(SONG_HELP, argv=command_args, options_first=True),
            ), level
        case Command.ARTIST:
            todo()
            command_args = ["artist", *command_args]
            return deserialize(
                CliArtist,
                docopt(Help.ARTIST, argv=command_args),
            ), level
        case Command.COLLECTION:
            todo()
            command_args = ["collection", *command_args]
            return deserialize(
                CliCollection,
                docopt(Help.COLLECTION, argv=command_args),
            ), level
        case Command.EVENT:
            todo()
            command_args = ["event", *command_args]
            return deserialize(
                CliEvent,
                docopt(Help.EVENT, argv=command_args),
            ), level
        case Command.HELP:
            command_args = ["help", *command_args]
            return deserialize(
                CliHelp,
                docopt(HELP_HELP, argv=command_args),
            ), level
