# ruff: disable[W505, E501]
"""\
Usage: vocacli [-l LEVEL | --log-level LEVEL] [-h | --help] COMMAND [ARGS...]
       vocacli [-v | --version]

Query Vocaloid related data from the command line.

COMMAND:
    album           Search for an album from VocaDB.
    song            Search for a song from VocaDB.
    artist          Not yet implemented
    collection      Not yet implemented
    event           Not yet implemented
    help [COMMAND]  Show help for a COMMAND
See `vocacli help COMMAND` or `vocacli COMMAND --help` for detailed help on a command

Options:
    -l LEVEL, --log-level LEVEL  Set lowest log level that will be displayed
                                 (One of: DEBUG, INFO, WARN, ERROR) [default: WARN]
    -h, --help                   Print this help
    -v, --version                Print version information
"""

# ruff: enable[W505, E501]

import asyncio
import sys
from typing import NoReturn

from vocacli.album import ALBUM_HELP, CliAlbum, handle_album
from vocacli.helpers import todo
from vocacli.log import init_logger
from vocacli.root_cli import (
    HELP_HELP,
    ROOT_HELP,
    CliHelp,
    Command,
    Help,
    get_args,
)
from vocacli.song import CliSong, handle_song


async def main() -> None:
    args, log_level = get_args()
    logger = init_logger(__name__, log_level)

    logger.debug(f"Processing command-line arguments: {args}")
    match args:
        case CliAlbum():
            await handle_album(args)
        case CliSong():
            await handle_song(args)
        # case CliArtist():
        #     pass
        # case CliCollection():
        #     pass
        # case CliEvent():
        #     pass
        case CliHelp():
            handle_help(args)
        case _:
            todo()


def handle_help(args: CliHelp) -> NoReturn:
    match args.command:
        case None:
            print(ROOT_HELP)
        case Command.HELP:
            print(HELP_HELP)
        case Command.ALBUM:
            print(ALBUM_HELP)
        case Command.SONG:
            print(Help.SONG)
        case Command.ARTIST:
            todo()
            print(Help.ARTIST)
        case Command.COLLECTION:
            todo()
            print(Help.COLLECTION)
        case Command.EVENT:
            todo()
            print(Help.EVENT)
    sys.exit(0)


def run() -> None:
    asyncio.run(main())


if __name__ == "__main__":
    run()
