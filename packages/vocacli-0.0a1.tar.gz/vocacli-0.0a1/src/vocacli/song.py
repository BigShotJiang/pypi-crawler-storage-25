from __future__ import annotations

import sys
from enum import StrEnum
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from vocacli.api_models import Song, SongSearch
from vocacli.helpers import (
    deserialize,
    docopt,
    get_client,
    handle_validation_error,
    todo,
)
from vocacli.log import init_logger

logger = init_logger(__name__)

SONG_HELP: str = """\
Usage: vocacli song [-h |--help] SUBCOMMAND [ARGS...]

SUBCOMMAND:
    top     Not yet implemented.
    search  Search for a song in the VocaDB API.
See `vocacli album SUBCOMMAND --help` for detailed help on a subcommand

Options:
    -h, --help  Print this help
"""

# TODO(valerie): Make search formatting better  # noqa: TD003
# i.e. with templates or f-strings
SEARCH_HELP: str = """\
Usage: vocacli song search [options] [QUERY]

Search for a song in the VocaDB API.

Options:
    -h, --help
        Print this help
    --format FORMAT
        Specify a printf-style format string.
    -f FIELDS
        Specify one or more comma-seperated extra fields.

Format:
    There are placeholders that can be inserted to customize the output of
    vocacli. Depending on the extra fields specified, not all of these may be
    available. These follow Python's printf style formatting. Seperate newlines
    with \\n. (Other valid Python string escapes are also accepted.)

    %(additional_names)s  Any additional names that the song may be known as.
    %(artist_string)s     The name of the artist.
    %(id)d                The ID of the song within VocaDB.
    %(rating)f            The average rating (out of 5) for the song.
    %(name)s              The name of the song.
    %(publish_date)s      The date the song was published.
    %(tags)s              A comma-seperated list of the tags.
    %(weblinks)s          A newline-seperated list of the weblinks.

    Default format string:
        %(name)s by %(artist_string)s (Also known as %(additional_names)s)
        Published: %(publish_date)s
        Rating: %(rating)2f

        Links:
        %(weblinks)s


Extra Fields:
    Note that it is not guaranteed that the associated data is available. In the
    case that it is not available, VocaCLI will not raise an error, instead
    substituting `None`.

    AdditionalNames  Any additional names the song may be known as.
    Tags             Tags associated with the song. (Only names are fetched.)
    WebLinks         Links to listen to the song.
"""

DEFAULT_FMT = """
%(name)s by %(artist_string)s (Also known as %(additional_names)s)
Published: %(publish_date)s
Rating: %(rating)2f

Links:
%(weblinks)s
"""

TOP_HELP: str = """
"""


class CliSong(BaseModel):
    subcommand: Command | None = Field(validation_alias="SUBCOMMAND")
    help: bool = Field(validation_alias="--help")
    args: list[str] | None = Field(validation_alias="ARGS")
    # This field is not useful at all
    none: bool = Field(validation_alias="song")
    model_config: ClassVar[ConfigDict] = ConfigDict(extra="forbid")


class Command(StrEnum):
    Top = "top"
    Search = "search"

    # Yes this is hacky but whatever
    Help = "--help"
    ShortHelp = "-h"


class CliSearch(BaseModel):
    help: bool = Field(validation_alias="--help")
    format: str | None = Field(validation_alias="--format")
    fields: str | None = Field(validation_alias="-f")
    query: str | None = Field(validation_alias="QUERY")


class ExtraField(StrEnum):
    AdditionalNames = "AdditionalNames"
    Description = "Description"
    PVs = "PVs"
    Tags = "Tags"
    WebLinks = "WebLinks"


class CliTop(BaseModel):
    pass


async def handle_song(args: CliSong) -> None:
    match args.subcommand:
        case Command.Top:
            logger.warning(
                "Attempted subcommand `top` that has not been implemented!",
            )
            todo()
            subcommand_args = ["song", "top"]
            if args.args:
                subcommand_args += args.args
            await handle_top(
                deserialize(
                    CliTop,
                    docopt(TOP_HELP, subcommand_args, options_first=False),
                ),
            )
        case Command.Search:
            subcommand_args = ["song", "search"]
            if args.args:
                subcommand_args += args.args
            await handle_search(
                deserialize(
                    CliSearch,
                    docopt(SEARCH_HELP, subcommand_args, options_first=False),
                ),
            )
        case Command.Help | Command.ShortHelp | None:
            print(SONG_HELP)
            sys.exit(0)


async def handle_search(args: CliSearch) -> None:
    if args.help:
        print(SEARCH_HELP)
        sys.exit(0)
    params = {
        "status": "approved",  # Filter out spam content
    }
    if args.query:
        params["query"] = args.query

    if args.fields:
        ta = TypeAdapter(list[ExtraField])
        try:
            params["fields"] = ",".join(
                ta.validate_python(args.fields.split(",")),
            )
        except ValidationError as e:
            handle_validation_error(e)

    async with get_client() as client:
        logger.debug("Making request")
        response = await client.get("/songs", params=params)
        try:
            results = SongSearch.model_validate_json(response.content)
        except ValidationError:
            logger.exception(
                "Please contact me at <valerie@ouppy.gay> with this traceback.",
            )
            sys.exit(1)

    for song in results.items:
        fmt_string = bytes(args.format or DEFAULT_FMT, "utf-8").decode(
            "unicode_escape",
        )
        res = format_song(song, fmt_string)
        print(res)


def format_song(song: Song, fmt_string: str) -> str:
    fmt_map = song.model_dump()

    if song.weblinks:
        fmt_map["weblinks"] = "\n".join(
            [a.url for a in song.weblinks if a.url],
        )
    else:
        fmt_map["weblinks"] = None

    if song.tags:
        fmt_map["tags"] = ",".join([t.tag.name for t in song.tags])
    else:
        fmt_map["tags"] = None

    return fmt_string % fmt_map


async def handle_top(_args: CliTop) -> None:
    pass
