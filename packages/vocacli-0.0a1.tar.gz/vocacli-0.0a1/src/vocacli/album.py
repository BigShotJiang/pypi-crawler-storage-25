"""\
Usage: vocacli album [-h |--help] SUBCOMMAND [ARGS...]

SUBCOMMAND:
    recent  Not yet implemented.
    search  Search for an album in the VocaDB API.
See `vocacli album SUBCOMMAND --help` for detailed help on a subcommand

Options:
    -h, --help  Print this help
"""

from __future__ import annotations

import sys
from enum import StrEnum
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from vocacli.api_models import Album, AlbumSearch
from vocacli.helpers import (
    deserialize,
    docopt,
    get_client,
    handle_validation_error,
    todo,
)
from vocacli.log import init_logger

logger = init_logger(__name__)


class CliAlbum(BaseModel):
    subcommand: Command | None = Field(validation_alias="SUBCOMMAND")
    help: bool = Field(validation_alias="--help")
    args: list[str] | None = Field(validation_alias="ARGS")
    # This field is not useful at all
    none: bool = Field(validation_alias="album")

    model_config: ClassVar[ConfigDict] = ConfigDict(extra="forbid")


ALBUM_HELP: str = """\
Usage: vocacli album [-h |--help] SUBCOMMAND [ARGS...]

SUBCOMMAND:
    recent  Not yet implemented.
    search  Search for an album in the VocaDB API.
See `vocacli album SUBCOMMAND --help` for detailed help on a subcommand

Options:
    -h, --help  Print this help
"""


# TODO(valerie): Make search formatting better  # noqa: TD003
# i.e. with templates or f-strings
SEARCH_HELP: str = """\
Usage: vocacli album search [options] [QUERY]

Search for an album in the VocaDB API.

Options:
    -h, --help
        Print this help
    --format FORMAT
        Specify a printf-style format string.
    -f FIELDS
        Specify one or more comma-seperated extra fields.

Format:
    There are placeholders that can be inserted to customize the output of
    vocacli. Depending on the extra fields specified, not all of these may be
    available. These follow Python's printf style formatting. Seperate newlines
    with \\n. (Other valid Python string escapes are also accepted.)

    %(additional_names)s  Any additional names that the album may be known as.
    %(artist_string)s     The name of the artist.
    %(description)s       Description of the album.
    %(id)d                The ID of the album within VocaDB.
    %(rating)f            The average rating (out of 5) for the album.
    %(name)s              The name of the album.
    %(day)s               The day of album release.
    %(month)s             The month of album release.
    %(year)s              The month of album release.
    %(tags)s              A comma-seperated list of the tags.
    %(weblinks)s          A newline-seperated list of the weblinks.

    Default format string:
        Album [id=%(id)d]

        %(name)s by %(artist_string)s (Also known as %(additional_names)s)
        Released: %(year)s-%(month)s-%(day)s
        Rating: %(rating)2f

        Links:
        %(weblinks)s


Extra Fields:
    Note that it is not guaranteed that the associated data is available. In the
    case that it is not available, VocaCLI will not raise an error, instead
    substituting `None`.

    AdditionalNames  Any additional names the album may be known as.
    Description      Desscription of the album.
    Tags             Tags associated with the album. (Only names are fetched.)
    WebLinks         Links to listen to the album.
"""

DEFAULT_FMT = """
Album [id=%(id)d]

%(name)s by %(artist_string)s (Also known as %(additional_names)s)
Released: %(year)s-%(month)s-%(day)s
Rating: %(rating)2f

Links:
%(weblinks)s
"""

RECENT_HELP: str = """\
Usage: vocacli album recent [-h | --help] [-n N]

Options:
    -h, --help  Print this help
    -n N        Limit results to N albums. [default: 3]
"""


class Command(StrEnum):
    Recent = "recent"
    Search = "search"

    # Yes this is hacky but whatever
    Help = "--help"
    ShortHelp = "-h"


class CliSearch(BaseModel):
    help: bool = Field(validation_alias="--help")
    format: str | None = Field(validation_alias="--format")
    fields: str | None = Field(validation_alias="-f")
    query: str | None = Field(validation_alias="QUERY")


class CliRecent(BaseModel):
    album: bool
    recent: bool
    help: bool = Field(validation_alias="--help")
    limit: int = Field(validation_alias="-n")


async def handle_album(args: CliAlbum) -> None:
    match args.subcommand:
        case Command.Recent:
            logger.warning(
                "Attempted subcommand `recent` that has not been implemented!",
            )
            todo()
            subcommand_args = ["album", "recent"]
            if args.args:
                subcommand_args += args.args
            await handle_recent(
                deserialize(
                    CliRecent,
                    docopt(RECENT_HELP, subcommand_args, options_first=False),
                ),
            )
        case Command.Search:
            subcommand_args = ["album", "search"]
            if args.args:
                subcommand_args += args.args
            await handle_search(
                deserialize(
                    CliSearch,
                    docopt(SEARCH_HELP, subcommand_args, options_first=False),
                ),
            )
        case Command.Help | Command.ShortHelp | None:
            print(ALBUM_HELP)
            sys.exit(0)


class ExtraField(StrEnum):
    AdditionalNames = "AdditionalNames"
    Description = "Description"
    PVs = "PVs"
    Tags = "Tags"
    WebLinks = "WebLinks"


async def handle_search(args: CliSearch) -> None:
    if args.help:
        print(SEARCH_HELP)
        sys.exit(0)

    params = {
        "status": "approved",  # Filter out spam content
    }

    if args.query:
        params["query"] = args.query

    if args.fields:
        ta = TypeAdapter(list[ExtraField])
        try:
            params["fields"] = ",".join(
                ta.validate_python(args.fields.split(",")),
            )
        except ValidationError as e:
            handle_validation_error(e)

    async with get_client() as client:
        logger.debug("Making request")
        response = await client.get("/albums", params=params)
        try:
            results = AlbumSearch.model_validate_json(response.content)
        except ValidationError:
            logger.exception(
                "Please contact me at <valerie@ouppy.gay> with this traceback.",
            )
            sys.exit(1)

    for album in results.items:
        fmt_string = bytes(args.format or DEFAULT_FMT, "utf-8").decode(
            "unicode_escape",
        )
        res = format_album(album, fmt_string)
        print(res)


async def handle_recent(args: CliRecent) -> None:
    if args.help:
        print(RECENT_HELP)


def format_album(album: Album, fmt_string: str) -> str:
    fmt_map = album.model_dump()

    if album.weblinks:
        fmt_map["weblinks"] = "\n".join(
            [a.url for a in album.weblinks if a.url],
        )
    else:
        fmt_map["weblinks"] = None
    date = album.release_date

    if not date.is_empty:
        fmt_map["day"] = date.day
        fmt_map["month"] = date.month
        fmt_map["year"] = date.year
    else:
        fmt_map["day"] = None
        fmt_map["month"] = None
        fmt_map["year"] = None

    if album.tags:
        fmt_map["tags"] = ",".join([t.tag.name for t in album.tags])
    else:
        fmt_map["tags"] = None

    return fmt_string % fmt_map
