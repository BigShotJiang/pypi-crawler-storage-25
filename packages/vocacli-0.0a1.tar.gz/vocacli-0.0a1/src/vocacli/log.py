from __future__ import annotations

import logging
import os
import sys
from typing import override

from typing_extensions import Writer


# termcolor/termcolor
def _can_colorize() -> bool:
    environ = os.environ
    if environ.get("ANSI_COLORS_DISABLED") or environ.get("NO_COLOR"):
        return False
    if environ.get("FORCE_COLOR"):
        return True

    if environ.get("TERM") == "dumb" or not hasattr(sys.stdout, "fileno"):
        return False

    try:
        return os.isatty(sys.stdout.fileno())
    except OSError:
        return sys.stdout.isatty()


CAN_COLORIZE = _can_colorize()


class Formatter(logging.Formatter):
    RESET: str = "\x1b[0m"

    BOLD: str = "\x1b[1m"
    DIM: str = "\x1b[2m"

    RED: str = "\x1b[31;20m"
    GREEN: str = "\x1b[32;20m"
    YELLOW: str = "\x1b[33;20m"
    BLUE: str = "\x1b[34;20m"

    if CAN_COLORIZE:
        DATETIME: str = DIM + "%(asctime)s" + RESET
        LOGGER_INFO: str = BLUE + "%(name)s:%(lineno)d" + RESET
    else:
        DATETIME = "%(asctime)s"
        LOGGER_INFO = "%(name)s:%(lineno)d"

    LEVEL: str = " | %(levelname) -8s | "
    MESSAGE: str = " - %(message)s"

    DEFAULT_FMT: logging.PercentStyle = logging.PercentStyle(
        DATETIME + LEVEL + LOGGER_INFO + MESSAGE,
    )

    COLOR_FORMATS: dict[int, logging.PercentStyle] = {  # noqa: RUF012
        logging.DEBUG: logging.PercentStyle(
            DATETIME
            + DIM
            + LEVEL
            + RESET
            + LOGGER_INFO
            + DIM
            + MESSAGE
            + RESET,
        ),
        logging.INFO: logging.PercentStyle(
            DATETIME
            + GREEN
            + LEVEL
            + RESET
            + LOGGER_INFO
            + GREEN
            + MESSAGE
            + RESET,
        ),
        logging.WARNING: logging.PercentStyle(
            DATETIME
            + YELLOW
            + LEVEL
            + RESET
            + LOGGER_INFO
            + YELLOW
            + MESSAGE
            + RESET,
        ),
        logging.ERROR: logging.PercentStyle(
            DATETIME
            + RED
            + LEVEL
            + RESET
            + LOGGER_INFO
            + RED
            + MESSAGE
            + RESET,
        ),
        logging.CRITICAL: logging.PercentStyle(
            DATETIME
            + BOLD
            + RED
            + LEVEL
            + RESET
            + LOGGER_INFO
            + BOLD
            + RED
            + MESSAGE
            + RESET,
        ),
    }

    FORMATS: dict[int, logging.PercentStyle] = (
        COLOR_FORMATS
        if CAN_COLORIZE
        else dict.fromkeys(COLOR_FORMATS, DEFAULT_FMT)
    )

    DATEFMT: str = "%Y-%m-%d %H:%M:%S"

    def __init__(self) -> None:
        # Init without fmt arg, overwrite style anyways
        super().__init__(datefmt=self.DATEFMT)

    @override
    def format(self, record: logging.LogRecord) -> str:
        self._style: logging.PercentStyle = self.FORMATS[record.levelno]
        return super().format(record)


class Handler(logging.StreamHandler[Writer[str]]):
    def __init__(
        self,
        stream: Writer[str] = sys.stderr,
    ) -> None:
        logging.Handler.__init__(self)
        self.stream: Writer[str] = stream
        self.setFormatter(Formatter())


LEVEL = 30  # Default WARN


def init_logger(
    name: str,
    level: int = LEVEL,
    stream: Writer[str] = sys.stderr,
) -> logging.Logger:
    global LEVEL  # noqa: PLW0603
    if level != LEVEL:
        LEVEL = level

    logger = logging.getLogger(name)

    logger.setLevel(LEVEL)
    logger.addHandler(Handler(stream))

    return logger
