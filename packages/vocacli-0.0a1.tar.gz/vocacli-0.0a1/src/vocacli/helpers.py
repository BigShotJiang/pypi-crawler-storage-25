"""
Miscellaneous helper functions for this program
"""

import contextlib
import importlib.metadata
import sys
from collections.abc import AsyncGenerator
from typing import NoReturn

import httpx
from pydantic import BaseModel, ValidationError

import vocacli.external.docopt as _docopt
from vocacli.log import init_logger

logger = init_logger(__name__)


def eprint(
    *values: object,
    sep: str | None = " ",
    end: str | None = "\n",
) -> None:
    """
    Prints the values to `sys.stderr`.

    sep
      string inserted between values, default a space.
    end
      string appended after the last value, default a newline.
    """
    print(*values, sep=sep, end=end, file=sys.stderr)


def todo() -> NoReturn:
    """
    Python equivalent of the Rust std::todo!() macro.

    Indicates unfinished code.
    """
    eprint("not yet implemented")
    sys.exit(1)


def docopt(
    doc: str,
    argv: list[str] | None = None,
    *,
    help: bool = False,
    version: object | None = None,
    options_first: bool = True,
) -> dict[str, str | bool | None]:
    """
    Type annotated wrapper around `docopt.docopt` which also handles
    parse errors by printing the full help instead of usage.
    """
    logger.debug("Trying to parse command line arguments...")
    try:
        return _docopt.docopt(doc, argv, help, version, options_first)
    except _docopt.DocoptExit:
        eprint(doc)
        sys.exit(0)
    except _docopt.DocoptLanguageError:
        logger.exception(
            "Please contact me at <valerie@ouppy.gay> with this traceback.",
        )
        sys.exit(1)


def deserialize[T: BaseModel](
    type: type[T],
    value: dict[str, str | bool | None],
) -> T:
    """
    Given a pydantic model `T` and a dictionary `value`, try to
    derialise value into a `T`
    """
    logger.debug(
        f"Trying to derialize {value} into a {type}",
    )
    try:
        return type(**value)
    except ValidationError as e:
        handle_validation_error(e)


def handle_validation_error(e: ValidationError) -> NoReturn:
    for err in e.errors(include_url=False):
        locations = (str(loc) for loc in err["loc"])
        logger.critical(
            f"Input error at {', '.join(locations)}. {err['msg']}, but got '{err['input']}'",  # noqa: E501
        )
    eprint("Run `vocacli --help` for usage help")
    sys.exit(1)


# In global space to not create them every time get_client() called
TIMEOUT = httpx.Timeout(5.0, read=20.0)
API_URL = "https://vocadb.net/api"
HEADERS = {
    "user-agent": f"vocacli/{importlib.metadata.version('vocacli')}",
}


@contextlib.asynccontextmanager
async def get_client() -> AsyncGenerator[httpx.AsyncClient]:
    """
    Return preconfigured AsyncClient
    """

    client = httpx.AsyncClient(
        headers=HEADERS,
        timeout=TIMEOUT,
        base_url=API_URL,
        follow_redirects=True,
    )
    try:
        yield client
    finally:
        await client.aclose()
