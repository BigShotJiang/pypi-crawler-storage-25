# VocaCLI

A CLI for accessing VocaDB.

This project is in very early alpha! Breaking changes are likely to occur.

## Run

From PyPi:

```sh
pipx vocacli
```

Or from source:

```sh
git clone https://git.ouppy.gay/valerie/vocacli
cd vocacli
python -m venv .venv
pip install -r pyproject.toml
python src/vocacli
```

## Usage

Run `vocacli --help` for help.
