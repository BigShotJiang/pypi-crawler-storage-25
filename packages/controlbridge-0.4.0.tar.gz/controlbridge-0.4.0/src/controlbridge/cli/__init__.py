"""ControlBridge command-line interface."""
