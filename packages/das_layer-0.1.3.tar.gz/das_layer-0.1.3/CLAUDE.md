# das-cli — agent instructions

## Architecture Decision Records (ADRs)

Significant architectural choices live in `docs/adrs/` as MADR-format files
(Status / Context / Decision / Alternatives considered / Consequences).
Numbered sequentially.

### Lifecycle

ADRs harden at the main-branch boundary, not at authoring time:

- **On a feature branch, not yet merged to main:** ADRs are free to evolve.
  Add, edit, renumber, split, merge, or delete them as understanding develops.
- **Once merged to main:** the Decision and Context sections are immutable.
  The only in-place edit allowed is the Status field. Renumbering is forbidden.
  To change a merged decision, author a new ADR with
  `Status: Supersedes ADR-NNNN` and update the old one's status to
  `Superseded by ADR-MMMM`.

### Pre-merge ADR check

Before opening or merging a PR that adds, removes, or renumbers an ADR:

1. Rebase on `main` and confirm no ADR file number on the branch collides
   with one already on `main`. If a collision exists, renumber the branch's
   ADR(s) before opening the PR (renumbering is allowed pre-merge per the
   lifecycle policy above).
2. Run `head -1 docs/adrs/0*.md` and confirm every ADR file has a matching
   row in `docs/adrs/README.md` whose title equals the file's `# NNNN.`
   heading verbatim.
3. Confirm `docs/adrs/README.md` has no rows referring to ADR numbers that
   don't exist as files.

### Before changing architectural behavior

1. Read the relevant ADR(s). Search by topic in `docs/adrs/`.
2. If your change contradicts an ADR that is already in main, surface the
   conflict to the user before implementing. Then either: (a) write the
   superseding ADR, or (b) abandon the change.
3. If the relevant ADR is still on the current feature branch, edit it directly.

### When to file a new ADR

Write one when the change has alternatives worth recording — typically:

- New dependency or destination
- New pipeline phase or stage
- New contract format or naming convention
- Change to schema-enforcement, change-detection, or state-management
- Cross-cutting infrastructural choice (config flow, auth mechanism, test layout)

Skip ADRs for: bug fixes, refactors that preserve behavior, dependency version
bumps within a major.

### ADR file template

```markdown
# NNNN. <Short title in imperative mood>

- **Status:** Accepted | Superseded by ADR-MMMM
- **Date:** YYYY-MM-DD
- **Deciders:** <who>

## Context
<What forces are in play? What problem are we solving?>

## Decision
<What did we choose? Be specific and unambiguous.>

## Alternatives considered
<Bullet list of options we rejected, with one-line rationale each.>

## Consequences
<Positive, negative, neutral. What does it lock in or out?>
```

### Code references

When code embodies an ADR, reference it inline:

```python
# See ADR-0003: P1 blob pattern.
columns={"_data": {"data_type": "json", "nullable": False}}
```

This is the only kind of code comment we encourage liberally — pointer-to-ADR
comments are cheap and prevent context loss.
