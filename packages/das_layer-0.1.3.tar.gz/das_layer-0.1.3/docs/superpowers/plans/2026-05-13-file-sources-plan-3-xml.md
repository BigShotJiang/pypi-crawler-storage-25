# File-based sources Plan #3: XML reader

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add XML support to the `type: filesystem` umbrella so XML files can be ingested with xpath-driven record extraction, namespace-aware element matching, and streaming via `lxml.etree.iterparse` with the `elem.clear()` memory-discipline pattern.

**Architecture:** New `dlt_glue/file_readers/xml.py` uses `lxml.etree.iterparse(..., events=('end',), tag=...)` to stream matched elements, then clears them (plus previous-sibling pruning) to keep RSS bounded. Each row = element attributes merged with child-element `{tag: text}`. The bootstrap walker grows an `.xml` branch that requires an explicit `--xpath` flag at bootstrap time (no auto-discovery; XML's structure is too free-form to safely infer). `_select_file_reader` dispatches `format=xml`.

**Tech Stack:** Python 3.12, dlt filesystem source, lxml (iterparse streaming), pytest. Adds optional `[xml]` extra.

**Spec:** `docs/superpowers/specs/2026-05-12-file-based-sources-design.md` (xml sections).

**Issue:** [#39](https://github.com/mattiasthalen/das-cli/issues/39) (xml child of #49). Umbrella + ADR-0022/0023 already on the branch from Plan #1.

---

## Tasks at a glance

1. Add `lxml` to `[xml]` optional extra + dev dep
2. `file_readers/xml.py` — streaming reader (iterparse + elem.clear)
3. Wire `xml` into `_select_file_reader`
4. Bootstrap `.xml` walker + `--xpath` CLI flag
5. E2E: `tests/e2e/sources/test_xml_to_duckdb.py` — namespaced XML
6. README — add XML row + quickstart

---

### Task 1: Add `lxml` to the `[xml]` optional extra

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Inspect the current optional-dependencies + dev structure**

Run: `grep -n "optional-dependencies\|excel\|openpyxl\|lxml" pyproject.toml`
Expected: `[project.optional-dependencies]` already exists with `excel = ["openpyxl>=3.1"]` (added in Plan #2); no `lxml` entry yet.

- [ ] **Step 2: Add the `[xml]` extra**

Edit `pyproject.toml`. In the `[project.optional-dependencies]` table, add a new line:

```toml
[project.optional-dependencies]
excel = ["openpyxl>=3.1"]
xml = ["lxml>=5.2"]
```

(If `excel` is on its own line, leave it; just add the `xml` line below.)

Also add `lxml>=5.2` and `lxml-stubs>=0.5` to the `dev` list inside `[dependency-groups]` so tests and mypy run cleanly without users opting in:

```toml
[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "pytest-xdist>=3.5",
    "responses>=0.25",
    "ruff>=0.5",
    "mypy>=1.10",
    "pre-commit>=3.7",
    "types-PyYAML>=6.0",
    "types-requests>=2.31",
    "testcontainers[oracle,mssql]>=4.0",
    "oracledb>=2.0",
    "pyodbc>=5.0",
    "openpyxl>=3.1",
    "lxml>=5.2",
    "lxml-stubs>=0.5",
]
```

(If the dev list has additional entries from earlier work, leave them and add the two `lxml` lines.)

- [ ] **Step 3: Sync the lockfile and verify**

Run: `uv sync --all-extras`
Expected: lockfile updates; lxml resolves.

Run: `uv run python -c "from lxml import etree; print(etree.LXML_VERSION)"`
Expected: prints a version tuple ≥ `(5, 2, ...)`.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "$(cat <<'EOF'
feat(deps): add lxml as [xml] optional + dev dep

Plan #3 of the file-based sources umbrella needs lxml's iterparse
streaming API. Lives under the [xml] optional extra (users opt in);
pinned in the dev group so unit + e2e tests run on default 'uv sync'.
lxml-stubs ships with the dev deps so mypy passes on iterparse calls.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 5: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD; previous HEAD (`2729db9`, the Plan #2 ruff-format cleanup) directly below.

---

### Task 2: `file_readers/xml.py` — streaming reader

**Files:**
- Create: `src/das_cli/dlt_glue/file_readers/xml.py`
- Test: `tests/unit/dlt_glue/file_readers/test_xml.py`

The reader signature mirrors CSV/Excel: `read_rows(file_item, spec_ref) -> Iterator[dict]`. Per-spec_ref selectors: `xpath` (required), `namespaces` (optional dict). Streams matched elements via `lxml.etree.iterparse(events=('end',), tag=<resolved_tag>)`, applies `elem.clear()` plus previous-sibling pruning after each yield to keep memory bounded.

Each row is the element's attributes merged with `{child_tag: child_text}` for each direct child element. Namespace prefixes are stripped from child tags so column names stay clean.

**Xpath restriction for v1:** only simple "last-segment" xpaths are supported — `//customer`, `/root/customer`, `//ns:customer`. Anything with predicates (`//customer[@active='true']`) or descendant-or-self mid-paths raises `NotImplementedError`. The user can write more complex xpaths in a future plan iteration.

- [ ] **Step 1: Write the failing XML reader tests**

Create `tests/unit/dlt_glue/file_readers/test_xml.py`:

```python
"""Unit tests for the XML file reader. See ADR-0022."""

from __future__ import annotations

import io
from pathlib import Path

import pytest

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.xml import read_rows


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict — supports `open(mode='rb')` + `file_name`."""

    def __init__(self, body: bytes, file_name: str = "x.xml"):
        self._body = body
        self.file_name = file_name
        self.file_url = f"file:///fake/{file_name}"
        self.modification_date = "2026-05-13T00:00:00+00:00"

    def open(self, mode: str = "rb") -> io.BytesIO:
        assert mode == "rb"
        return io.BytesIO(self._body)


def _spec(xpath: str = "//customer", **overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {
        "kind": "filesystem",
        "format": "xml",
        "path": "*.xml",
        "xpath": xpath,
    }
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_simple_records() -> None:
    body = b"""<?xml version="1.0"?>
<customers>
  <customer><id>1</id><name>Alice</name></customer>
  <customer><id>2</id><name>Bob</name></customer>
</customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [
        {"id": "1", "name": "Alice"},
        {"id": "2", "name": "Bob"},
    ]


def test_attributes_become_columns() -> None:
    body = b"""<?xml version="1.0"?>
<customers>
  <customer id="1" active="true"><name>Alice</name></customer>
</customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": "1", "active": "true", "name": "Alice"}]


def test_child_text_falls_back_to_empty_string_when_missing() -> None:
    """A child element with no text content yields an empty string for that column."""
    body = b"""<?xml version="1.0"?>
<customers>
  <customer><id>1</id><name/></customer>
</customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": "1", "name": ""}]


def test_namespaced_elements() -> None:
    body = b"""<?xml version="1.0"?>
<ns:customers xmlns:ns="http://example.com/x">
  <ns:customer><ns:id>1</ns:id><ns:name>Alice</ns:name></ns:customer>
</ns:customers>"""
    fi = _FakeFileItem(body)
    out = list(
        read_rows(
            fi,
            _spec(xpath="//ns:customer", namespaces={"ns": "http://example.com/x"}),
        )
    )
    assert out == [{"id": "1", "name": "Alice"}]


def test_namespace_required_when_xpath_uses_prefix() -> None:
    body = b'<?xml version="1.0"?><ns:r xmlns:ns="http://x"/>'
    fi = _FakeFileItem(body)
    with pytest.raises(ValueError, match="namespace prefix 'ns' is not declared"):
        list(read_rows(fi, _spec(xpath="//ns:r")))


def test_complex_xpath_rejected() -> None:
    fi = _FakeFileItem(b"<r/>")
    with pytest.raises(
        NotImplementedError, match="only simple xpath forms are supported"
    ):
        list(read_rows(fi, _spec(xpath="//customer[@active='true']")))


def test_xpath_required() -> None:
    """The reader rejects spec_ref without xpath (validator catches earlier but reader defends too)."""
    body = b"<root/>"
    fi = _FakeFileItem(body)
    sr = FilesystemSpecRef.model_validate(
        {"kind": "filesystem", "format": "xml", "path": "*.xml"}
    )
    with pytest.raises(ValueError, match="xml reader requires spec_ref.xpath"):
        list(read_rows(fi, sr))


def test_inject_basename(tmp_path: Path) -> None:
    body = b"""<?xml version="1.0"?>
<customers><customer><id>1</id></customer></customers>"""
    fi = _FakeFileItem(body, "exports-2024-01.xml")
    out = list(read_rows(fi, _spec(inject={"src": "basename"})))
    assert out == [{"id": "1", "src": "exports-2024-01.xml"}]


def test_streaming_clears_elements() -> None:
    """Reader yields lazily and clears each element after emission.

    We can't easily assert RSS in a unit test, but we can verify lazy generation:
    pulling one record leaves the rest unmaterialized.
    """
    body = b"""<?xml version="1.0"?>
<customers>
  <customer><id>1</id></customer>
  <customer><id>2</id></customer>
  <customer><id>3</id></customer>
</customers>"""
    fi = _FakeFileItem(body)
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": "1"}
    rest = list(gen)
    assert rest == [{"id": "2"}, {"id": "3"}]


def test_empty_xpath_match_yields_nothing() -> None:
    body = b"""<?xml version="1.0"?>
<customers><other/></customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == []
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_xml.py -v`
Expected: FAIL with `ImportError: cannot import name 'read_rows' from 'das_cli.dlt_glue.file_readers.xml'`.

- [ ] **Step 3: Write the XML reader**

Create `src/das_cli/dlt_glue/file_readers/xml.py`:

```python
"""XML file reader. See ADR-0022.

Streams matched elements via lxml.etree.iterparse with events=('end',) and a
resolved tag filter. After yielding each row, the matched element is cleared
and prior siblings are pruned — without that discipline, lxml accumulates the
full DOM and RSS grows unboundedly.

Xpath support is intentionally minimal for v1: only simple last-segment forms
are accepted (`//tag`, `/root/tag`, `//ns:tag`). Predicates and complex paths
raise NotImplementedError with a clear message.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject

# Simple xpath form: optional leading // or /, optional path segments,
# final segment is a bare name or "prefix:name". No predicates, no wildcards.
_SIMPLE_XPATH = re.compile(r"^/?/?([\w-]+:)?[\w-]+(/[\w-]+(:[\w-]+)?)*$")


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per element matched by `spec_ref.xpath`.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; `xpath` is required, `namespaces` is optional.

    Raises:
        ValueError: when xpath is missing or names an undeclared namespace prefix.
        NotImplementedError: when xpath uses predicates or other complex forms.
    """
    from lxml import etree

    if not spec_ref.xpath:
        raise ValueError("xml reader requires spec_ref.xpath")
    xpath = spec_ref.xpath
    namespaces = dict(spec_ref.namespaces or {})

    if not _SIMPLE_XPATH.match(xpath):
        raise NotImplementedError(
            f"xml reader: only simple xpath forms are supported in v1 "
            f"(`//tag`, `/root/tag`, `//ns:tag`). Got: {xpath!r}"
        )

    target_tag = _resolve_tag(xpath, namespaces)

    context = _build_inject_context(file_item)

    with file_item.open(mode="rb") as binary:
        events = etree.iterparse(binary, events=("end",), tag=target_tag)
        yield from apply_inject(
            _stream_rows(events),
            inject=spec_ref.inject,
            context=context,
        )


def _resolve_tag(xpath: str, namespaces: dict[str, str]) -> str:
    """Extract the target element tag from an xpath, resolving namespace prefix.

    Returns a Clark-notation tag (`{<uri>}localname`) when the xpath uses a
    namespace prefix, else just the local name.
    """
    # Last path segment is the target.
    last = xpath.split("/")[-1]
    if ":" in last:
        prefix, _, local = last.partition(":")
        if prefix not in namespaces:
            raise ValueError(
                f"xml reader: namespace prefix {prefix!r} is not declared in "
                f"spec_ref.namespaces (declared: {sorted(namespaces)})"
            )
        return f"{{{namespaces[prefix]}}}{local}"
    return last


def _stream_rows(events: Any) -> Iterator[dict[str, Any]]:
    """Iterate over (event, element) pairs, yield a row per matched element,
    and clean up after each yield."""
    for _event, elem in events:
        yield _element_to_row(elem)
        # Memory discipline: clear this element and prune earlier siblings so
        # lxml can release the accumulated parent tree.
        elem.clear()
        prev = elem.getprevious()
        parent = elem.getparent()
        while prev is not None and parent is not None:
            del parent[0]
            prev = elem.getprevious()


def _element_to_row(elem: Any) -> dict[str, Any]:
    """Build a row dict from element attributes + direct-child {tag: text}.

    Namespace prefixes are stripped from both attribute and child tags so
    column names stay clean. Child elements without text are emitted as
    empty strings rather than None to match CSV semantics.
    """
    row: dict[str, Any] = {}
    for attr_name, attr_value in elem.attrib.items():
        row[_localname(attr_name)] = attr_value
    for child in elem:
        # An lxml element with no text is `None`; coerce to "" for CSV-like
        # consistency.
        row[_localname(child.tag)] = child.text if child.text is not None else ""
    return row


def _localname(tag: str) -> str:
    """Strip a Clark-notation namespace (`{uri}name`) down to its local name."""
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag


def _build_inject_context(file_item: Any) -> dict[str, Any]:
    file_name = getattr(file_item, "file_name", None)
    if file_name is None and hasattr(file_item, "get"):
        file_name = file_item.get("file_name", "")
    file_name = file_name or ""

    file_url = getattr(file_item, "file_url", None)
    if file_url is None and hasattr(file_item, "get"):
        file_url = file_item.get("file_url", "")
    file_url = file_url or ""

    mtime = getattr(file_item, "modification_date", None)
    if mtime is None and hasattr(file_item, "get"):
        mtime = file_item.get("modification_date")

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
    }
```

- [ ] **Step 4: Run the tests and verify they pass**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_xml.py -v`
Expected: 10 passed.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/file_readers/xml.py tests/unit/dlt_glue/file_readers/test_xml.py
git commit -m "$(cat <<'EOF'
feat(file_readers): XML reader with iterparse streaming + namespaces

lxml.etree.iterparse(events=('end',), tag=...) streams matched
elements row-by-row. After each yield, elem.clear() plus
previous-sibling pruning keep memory bounded (without this discipline
lxml accumulates the full DOM).

Each row = element attributes merged with {child_tag: child_text}.
Namespace prefixes are stripped from column names. The xpath validator
accepts only simple last-segment forms (//tag, /root/tag, //ns:tag) in
v1; predicates and complex paths raise NotImplementedError with a
clear message.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 6: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD; previous task's commit directly below.

---

### Task 3: Dispatch `xml` in `_select_file_reader`

**Files:**
- Modify: `src/das_cli/dlt_glue/source_factory.py` (`_select_file_reader`)
- Test: `tests/unit/test_source_factory_filesystem.py` (extend existing)

The factory currently dispatches `csv` and `excel` (Plans #1, #2). Add `xml`.

- [ ] **Step 1: Write the failing dispatch test**

Append to `tests/unit/test_source_factory_filesystem.py`:

```python
def test_filesystem_xml_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: drop an XML file in tmp_path, dispatch via format=xml, assert blobs."""
    (tmp_path / "customers.xml").write_text(
        '<?xml version="1.0"?>\n'
        "<customers>\n"
        "  <customer><id>1</id><name>Alice</name></customer>\n"
        "  <customer><id>2</id><name>Bob</name></customer>\n"
        "</customers>\n"
    )

    contracts = [
        _make_fs_contract(
            "customers",
            spec_ref={
                "kind": "filesystem",
                "format": "xml",
                "path": "customers.xml",
                "xpath": "//customer",
            },
        )
    ]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": "1", "name": "Alice"}},
        {"_data": {"id": "2", "name": "Bob"}},
    ]
```

- [ ] **Step 2: Run the failing test**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py::test_filesystem_xml_resource_yields_blob_wrapped_rows -v`
Expected: FAIL — `_select_file_reader` raises `ValueError: No file reader for format 'xml'`.

- [ ] **Step 3: Extend `_select_file_reader`**

Edit `src/das_cli/dlt_glue/source_factory.py`. Replace the existing function:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    if format_name == "excel":
        from das_cli.dlt_glue.file_readers import excel as excel_reader

        return excel_reader.read_rows
    # xml, qvd land in future format PRs under ADR-0022.
    raise ValueError(
        f"No file reader for format '{format_name}'. Supported: csv, excel. "
        "(xml/qvd are planned follow-ups.)"
    )
```

with:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    if format_name == "excel":
        from das_cli.dlt_glue.file_readers import excel as excel_reader

        return excel_reader.read_rows
    if format_name == "xml":
        from das_cli.dlt_glue.file_readers import xml as xml_reader

        return xml_reader.read_rows
    # qvd lands in a future format PR under ADR-0022.
    raise ValueError(
        f"No file reader for format '{format_name}'. Supported: csv, excel, xml. "
        "(qvd is a planned follow-up.)"
    )
```

- [ ] **Step 4: Run the test and verify it passes**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py -v`
Expected: 6 passed (5 existing + 1 new).

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/source_factory.py tests/unit/test_source_factory_filesystem.py
git commit -m "$(cat <<'EOF'
feat(source_factory): dispatch format=xml to file_readers.xml

Extends _select_file_reader with the xml branch; updates the
'unsupported format' message (csv + excel + xml supported; qvd
still planned).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 6: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 4: Bootstrap `.xml` walker + `--xpath` CLI flag

**Files:**
- Modify: `src/das_cli/bootstrap/filesystem.py`
- Modify: `src/das_cli/cli.py` (`contract_bootstrap`)
- Test: `tests/unit/test_bootstrap_filesystem.py` (extend existing)
- Test: `tests/unit/test_cli_bootstrap_filesystem.py` (extend existing)

The walker needs an `xpath` parameter (optional, but required when `.xml` files are present). For each `.xml` file, open and stream until the first matched element to derive column names, then emit a contract. The CLI gains a `--xpath` flag on `contract bootstrap`.

- [ ] **Step 1: Write the failing bootstrap walker tests**

Append to `tests/unit/test_bootstrap_filesystem.py`:

```python
def test_xml_emits_one_contract_per_file(tmp_path: Path) -> None:
    (tmp_path / "customers.xml").write_text(
        '<?xml version="1.0"?>\n<customers>\n'
        "  <customer><id>1</id><name>Alice</name></customer>\n"
        "</customers>\n"
    )
    (tmp_path / "orders.xml").write_text(
        '<?xml version="1.0"?>\n<orders>\n'
        "  <customer><order_id>10</order_id></customer>\n"
        "</orders>\n"
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders"]


def test_xml_columns_taken_from_first_element(tmp_path: Path) -> None:
    (tmp_path / "x.xml").write_text(
        '<?xml version="1.0"?>\n<root>\n'
        '  <customer id="1"><name>Alice</name><email>a@x</email></customer>\n'
        "</root>\n"
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    schema = contracts[0].contract.primary_schema
    assert sorted(p.name for p in schema.properties) == ["email", "id", "name"]


def test_xml_types_default_to_string(tmp_path: Path) -> None:
    (tmp_path / "x.xml").write_text(
        '<?xml version="1.0"?>\n<root><customer><id>1</id></customer></root>'
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string"]


def test_xml_spec_ref_records_xpath_and_filename(tmp_path: Path) -> None:
    from das_cli.contracts.custom_properties import get_das_value

    (tmp_path / "customers.xml").write_text(
        '<?xml version="1.0"?>\n<root><customer><id>1</id></customer></root>'
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    spec_ref = get_das_value(
        contracts[0].contract.custom_properties, "das.spec_ref"
    )
    assert spec_ref == {
        "kind": "filesystem",
        "format": "xml",
        "path": "customers.xml",
        "xpath": "//customer",
    }


def test_xml_no_xpath_raises_when_xml_present(tmp_path: Path) -> None:
    (tmp_path / "x.xml").write_text("<root/>")
    with pytest.raises(ValueError, match="--xpath is required"):
        bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")


def test_xml_no_match_emits_empty_schema(tmp_path: Path) -> None:
    """A file where xpath matches nothing produces a contract with no properties."""
    (tmp_path / "x.xml").write_text(
        '<?xml version="1.0"?>\n<root><other/></root>'
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    assert len(contracts) == 1
    assert contracts[0].contract.primary_schema.properties == []
```

You'll also need a `pytest` import if not already present at the top of `tests/unit/test_bootstrap_filesystem.py`. Check the file — Plan #1 left it without one for the csv tests since none of those used `pytest.raises`. Add `import pytest` to the imports if missing.

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v -k xml`
Expected: All 6 new tests FAIL — `bootstrap_filesystem_contracts` doesn't accept `xpath=` yet, and `.xml` files aren't walked.

- [ ] **Step 3: Extend the bootstrap walker for `.xml`**

Edit `src/das_cli/bootstrap/filesystem.py`. Change the function signature and body of `bootstrap_filesystem_contracts`. Find:

```python
def bootstrap_filesystem_contracts(
    scfg: SourceConfig,
    *,
    source_name: str,
) -> list[LoadedContract]:
```

and replace with:

```python
def bootstrap_filesystem_contracts(
    scfg: SourceConfig,
    *,
    source_name: str,
    xpath: str | None = None,
) -> list[LoadedContract]:
```

Update the docstring (just below the signature) to mention the xpath param:

```python
    """Walk `scfg.endpoint` and emit one ODCS contract per discoverable file.

    Plan #1 supports CSV; Plan #2 supports Excel; Plan #3 supports XML.
    QVD discovery lands in Plan #4.

    `xpath` (optional) is the XPath expression used to extract records from
    each .xml file. Required only if the endpoint contains .xml files;
    csv/xlsx don't use it.

    Local paths only at the moment; blob endpoints (`az://`, `s3://`) require
    fsspec wiring and are deferred to a follow-up.
    """
```

Then, inside the `for path in sorted(root.iterdir())` loop, replace:

```python
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        elif suffix == ".xlsx":
            out.extend(_build_excel_contracts(path, source_name=source_name))
        # xml/qvd dispatch lands in their follow-up plans under ADR-0022.
```

with:

```python
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        elif suffix == ".xlsx":
            out.extend(_build_excel_contracts(path, source_name=source_name))
        elif suffix == ".xml":
            if not xpath:
                raise ValueError(
                    "--xpath is required for filesystem bootstrap with .xml files"
                )
            out.append(
                _build_xml_contract(path, source_name=source_name, xpath=xpath)
            )
        # qvd dispatch lands in its follow-up plan under ADR-0022.
```

At the end of the file (after `_make_excel_contract`), append:

```python
def _build_xml_contract(
    file_path: Path, *, source_name: str, xpath: str
) -> LoadedContract:
    """Emit one LoadedContract for an .xml file by inspecting the first xpath match."""
    resource_name = snake_case(file_path.stem)
    columns = _read_xml_columns(file_path, xpath=xpath)
    properties = [
        OdcsProperty(name=col, logicalType="string") for col in sorted(columns)
    ]
    spec_ref_value = {
        "kind": "filesystem",
        "format": "xml",
        "path": file_path.name,
        "xpath": xpath,
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[
            CustomProperty(property="das.spec_ref", value=spec_ref_value)
        ],
    )
    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _read_xml_columns(file_path: Path, *, xpath: str) -> list[str]:
    """Inspect the first xpath match in `file_path` and return its column names.

    Returns [] when the file has no matches.
    """
    from lxml import etree

    # Last path segment is the target tag.
    last = xpath.split("/")[-1]
    if ":" in last:
        # Namespaced xpath at bootstrap time isn't supported in v1 — the
        # walker has no spec_ref.namespaces to resolve the prefix against.
        # Users with namespaced XML hand-write the contract after bootstrap.
        return []
    target_tag = last

    with file_path.open("rb") as fh:
        events = etree.iterparse(fh, events=("end",), tag=target_tag)
        for _event, elem in events:
            attrs = list(elem.attrib.keys())
            children = [child.tag for child in elem]
            # Strip namespace prefixes if any sneaked through.
            cols = [
                t.split("}", 1)[1] if t.startswith("{") else t
                for t in [*attrs, *children]
            ]
            elem.clear()
            return cols
    return []
```

- [ ] **Step 4: Run the bootstrap tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v`
Expected: all xml tests pass + previous csv/xlsx tests still pass.

- [ ] **Step 5: Write the failing CLI test for `--xpath`**

Append to `tests/unit/test_cli_bootstrap_filesystem.py`:

```python
def test_filesystem_bootstrap_xml_with_xpath(tmp_path: Path) -> None:
    """`das contract bootstrap --xpath //customer` discovers xml contracts."""
    (tmp_path / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "customers.xml").write_text(
        '<?xml version="1.0"?>\n<root>\n'
        "  <customer><id>1</id><name>Alice</name></customer>\n"
        "</root>\n"
    )

    src_dir = tmp_path / "contracts" / "files"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: filesystem\n"
        f"endpoint: {data_dir}\n"
        "spec:\n  kind: filesystem\n"
        "auth:\n  type: none\n"
    )

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--config",
            str(tmp_path / "das.yaml"),
            "contract",
            "bootstrap",
            "files",
            "--xpath",
            "//customer",
        ],
    )
    assert result.exit_code == 0, result.stdout
    written = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]


def test_filesystem_bootstrap_xml_without_xpath_fails(tmp_path: Path) -> None:
    """Bootstrap with an xml file but no --xpath errors out."""
    (tmp_path / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "x.xml").write_text("<root/>")

    src_dir = tmp_path / "contracts" / "files"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: filesystem\nendpoint: {data_dir}\n"
        "spec:\n  kind: filesystem\nauth:\n  type: none\n"
    )

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["--config", str(tmp_path / "das.yaml"), "contract", "bootstrap", "files"],
    )
    assert result.exit_code != 0
    assert "xpath" in result.output.lower()
```

- [ ] **Step 6: Run the failing CLI tests**

Run: `uv run pytest tests/unit/test_cli_bootstrap_filesystem.py -v -k xml`
Expected: both new tests FAIL — `contract bootstrap` doesn't accept `--xpath` yet.

- [ ] **Step 7: Add `--xpath` to `contract_bootstrap`**

Edit `src/das_cli/cli.py`. Find the `contract_bootstrap` function (around line 421). Its signature looks like:

```python
@contract_app.command("bootstrap")
def contract_bootstrap(
    ctx: typer.Context,
    source: Annotated[str, typer.Argument(help="Source name (must exist under contracts/).")],
    from_: Annotated[
        str,
        typer.Option("--from", help="Bootstrap source: spec | sample"),
    ] = "spec",
    only: Annotated[
        str | None,
        typer.Option("--only", help="Comma-separated resource names to limit output."),
    ] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
    force: Annotated[bool, typer.Option("--force")] = False,
) -> None:
```

Add an `xpath` parameter just before `dry_run`:

```python
@contract_app.command("bootstrap")
def contract_bootstrap(
    ctx: typer.Context,
    source: Annotated[str, typer.Argument(help="Source name (must exist under contracts/).")],
    from_: Annotated[
        str,
        typer.Option("--from", help="Bootstrap source: spec | sample"),
    ] = "spec",
    only: Annotated[
        str | None,
        typer.Option("--only", help="Comma-separated resource names to limit output."),
    ] = None,
    xpath: Annotated[
        str | None,
        typer.Option(
            "--xpath",
            help="XPath for filesystem .xml record extraction (e.g. //customer).",
        ),
    ] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
    force: Annotated[bool, typer.Option("--force")] = False,
) -> None:
```

Then in the function body, find the existing filesystem dispatch:

```python
    elif scfg.spec.kind == "filesystem":
        # See ADR-0022.
        from das_cli.bootstrap.filesystem import bootstrap_filesystem_contracts

        loaded = bootstrap_filesystem_contracts(scfg, source_name=source)
```

and replace with:

```python
    elif scfg.spec.kind == "filesystem":
        # See ADR-0022.
        from das_cli.bootstrap.filesystem import bootstrap_filesystem_contracts

        loaded = bootstrap_filesystem_contracts(
            scfg, source_name=source, xpath=xpath
        )
```

- [ ] **Step 8: Run the CLI tests and verify they pass**

Run: `uv run pytest tests/unit/test_cli_bootstrap_filesystem.py -v`
Expected: all pass (the existing csv tests + the 2 new xml tests).

- [ ] **Step 9: Run the bootstrap + cli filesystem suite together**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py tests/unit/test_cli_bootstrap_filesystem.py -v`
Expected: all green.

- [ ] **Step 10: Commit**

```bash
git add src/das_cli/bootstrap/filesystem.py src/das_cli/cli.py tests/unit/test_bootstrap_filesystem.py tests/unit/test_cli_bootstrap_filesystem.py
git commit -m "$(cat <<'EOF'
feat(bootstrap,cli): xml discovery with --xpath flag

bootstrap_filesystem_contracts gains an optional `xpath` param; when
.xml files are present, xpath is required (raises ValueError otherwise).
Each .xml file → one ODCS contract; columns are inferred from the first
xpath-matched element's attributes + direct-child tags. Namespaced
xpaths at bootstrap time produce an empty schema (user hand-edits).

CLI: `das contract bootstrap --xpath '//customer' <source>` plumbs the
flag through. Other source types (odata, openapi, sql, csv/xlsx) ignore
it.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 11: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 5: E2E — XML to DuckDB

**Files:**
- Create: `tests/e2e/sources/test_xml_to_duckdb.py`
- Create: `tests/e2e/fixtures/xml/customers.xml`

XML is plain text, so the fixture goes in git under `tests/e2e/fixtures/xml/`. The e2e test follows the csv/excel pattern: workspace fixture → source add → bootstrap → manual contract edit → extract → load → DuckDB assertions.

- [ ] **Step 1: Create the fixture XML file**

Create `tests/e2e/fixtures/xml/customers.xml` with exactly this content:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<customers xmlns:das="http://example.com/das">
  <customer id="1">
    <name>Alice</name>
    <signup_month>2024-01</signup_month>
  </customer>
  <customer id="2">
    <name>Bob</name>
    <signup_month>2024-01</signup_month>
  </customer>
  <customer id="3">
    <name>Charlie</name>
    <signup_month>2024-02</signup_month>
  </customer>
</customers>
```

The `xmlns:das="..."` namespace is declared but not used by the records; it's there to exercise the reader's namespace-declaration path.

- [ ] **Step 2: Write the failing e2e test**

Create `tests/e2e/sources/test_xml_to_duckdb.py`:

```python
"""E2E: das against a local XML file, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Reads the fixture from tests/e2e/fixtures/xml/.
Uses the shared `workspace` + `cli_runner` fixtures from tests/conftest.py.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import duckdb
from typer.testing import CliRunner

from das_cli.cli import app

FIXTURE_DIR = Path(__file__).parent.parent / "fixtures" / "xml"


def test_xml_to_duckdb_with_provenance(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """XPath-driven extraction into a single staging table with provenance."""

    data_dir = workspace / "data"
    data_dir.mkdir()
    shutil.copy(FIXTURE_DIR / "customers.xml", data_dir)

    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    add = cli_runner.invoke(
        app,
        ["source", "add", "files", "--type", "filesystem", "--url", str(data_dir)],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    boot = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "files", "--xpath", "//customer"],
    )
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]

    # Hand-edit the contract: set primary key on id, refine types, add inject.
    (contracts_dir / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: signup_month\n"
        "        logicalType: string\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: xml\n"
        "      path: 'customers.xml'\n"
        "      xpath: '//customer'\n"
        "      inject:\n"
        "        source_file: basename\n"
    )

    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute(
            'SELECT id, name, signup_month, source_file FROM "das__files".customers '
            "ORDER BY id"
        ).fetchall()
    finally:
        db.close()

    assert rows == [
        (1, "Alice", "2024-01", "customers.xml"),
        (2, "Bob", "2024-01", "customers.xml"),
        (3, "Charlie", "2024-02", "customers.xml"),
    ]
```

- [ ] **Step 3: Run the e2e test**

Run: `uv run pytest tests/e2e/sources/test_xml_to_duckdb.py -m e2e -v`
Expected: PASS.

If the test fails on type coercion (CSV's e2e shows string `"1"` → integer column works fine via `pipelines/load.py::_project_record`; same path applies here since XML also emits strings), report `DONE_WITH_CONCERNS` with the specific failure.

- [ ] **Step 4: Sanity sweep**

Run: `uv run pytest -q -m "not e2e"`
Expected: all filesystem tests pass; pre-existing test_progress.py / midnight-flake failures are unrelated.

Run: `uv run pytest -m e2e -v -k xml`
Expected: 1 passed.

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/fixtures/xml/ tests/e2e/sources/test_xml_to_duckdb.py
git commit -m "$(cat <<'EOF'
test(e2e): XML-to-DuckDB edge with xpath + provenance

Verifies the filesystem source umbrella for xml: a single customers.xml
becomes one staging table via xpath '//customer' record extraction.
The fixture file declares an unused namespace to exercise the
namespace-declaration parsing path. The contract uses inject for
source_file provenance.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 6: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 6: README — add XML to the verified sources table

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Append the XML row to the verified-sources table**

Edit `README.md`. Find the "Verified sources (against DuckDB)" table. After the Excel row added in Plan #2, append:

```markdown
| XML (local)         | lxml iterparse streaming (ADR-0022); xpath-driven records  |
```

- [ ] **Step 2: Add an XML quickstart snippet**

After the Excel quickstart code-block in the README (the "For an Excel source..." block + its `bash` fence), insert:

````markdown
For an XML source (local files), provide an XPath to identify each
record element. The reader streams matched elements via lxml's
iterparse; column names come from the element's attributes + direct
child elements. Namespaced documents are supported by declaring
`namespaces` in the contract's `das.spec_ref`.

```bash
uv tool install das-cli --with lxml

das source add catalog \
  --type filesystem \
  --url ./data/catalog/

das contract bootstrap catalog --xpath '//customer'
# Edit contracts/catalog/*.odcs.yaml — set primary keys, refine types.

das ingest catalog
```
````

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): document XML file source + verified-edge row

Adds the XML row to the verified sources table (DuckDB destination
edge covered by tests/e2e/sources/test_xml_to_duckdb.py) and a
quickstart snippet showing the --xpath flag at bootstrap time.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 4: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

## Post-plan verification

After all tasks land, run:

- [ ] `uv run pytest -q` — unit + integration (e2e excluded by default).
- [ ] `uv run pytest -m e2e -v` — opt-in e2e suite, including csv, excel, and the new xml edge.
- [ ] `uv run pre-commit run --all-files` — ruff format/lint + mypy.

## What's left for Plan #4

- **Plan #4 (QVD):** library-research spike up front (streaming-capable parser); new `file_readers/qvd.py`; bootstrap reads embedded XML metadata header for both names *and* types; add the chosen parser to `[qvd]` extra; e2e edge.
